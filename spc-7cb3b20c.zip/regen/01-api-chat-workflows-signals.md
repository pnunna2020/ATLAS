# Phase 8 API Spec — Chat, Workflows, Workflow-Signals, Webhooks

ATOMIC regeneration spec. Behavioral parity bar. Reproduce EXACTLY.

Sources:
- `olympus-api/src/routers/chat.py` (5 endpoints)
- `olympus-api/src/routers/workflows.py` (4 endpoints)
- `olympus-api/src/routers/workflow_signals.py` (1 endpoint; reads signal inbox)
- `olympus-api/src/routers/webhooks.py` (1 endpoint; FIRES Temporal signals)

Supporting (reproduced where signal-firing / non-trivial):
- `olympus-api/src/services/workflow_health.py` (list/detail/restart/fail)
- `olympus-api/src/services/signal_inbox.py` (list_pending / enqueue / mark_queued)
- `olympus-api/src/services/git_service.py::GitService.parse_branch_name` + `olympus-contracts/olympus_contracts/git_types.py::BRANCH_PATTERN`
- `olympus-api/src/routers/portfolio.py::find_portfolio_by_repo`
- `olympus-api/src/middleware/auth.py` (`CurrentUser`, `get_current_user`, `require_role`)
- `olympus-api/src/models/workflow.py` (workflow models)

---

## 0. ROUTER MOUNT ORDER (`olympus-api/src/main.py`)

⚠️ GOTCHA: FastAPI matches routes in registration order. The four routers in this spec mount in this relative order:
- L195 `app.include_router(workflow_signals_router)` — prefix `/api/v1/workflow-signals`
- L203 `app.include_router(chat_router)` — no prefix (paths absolute on each route)
- L206 `app.include_router(webhooks_router)` — prefix `/api/v1/webhooks`
- L207 `app.include_router(workflows_router)` — prefix `/api/v1/workflows`

None of these four share path prefixes with each other, so there are no cross-router shadowing hazards among them. Preserve order anyway for parity. (Full app order context: `traceability_router` at L199 precedes `artifacts_router` at L200 for a different reason — out of scope here.)

---

## 1. SHARED AUTH PRIMITIVES (`olympus-api/src/middleware/auth.py`)

### `RBACRole` enum (`olympus-api/src/models/common.py:47`) — string enum
```
PORTFOLIO_ADMIN   = "portfolio_admin"
PORTFOLIO_MANAGER = "portfolio_manager"
TECH_LEAD         = "tech_lead"
ARCH_LEAD         = "arch_lead"
COMPLIANCE_LEAD   = "compliance_lead"
OPERATIONS_LEAD   = "operations_lead"
SAFETY_BOARD      = "safety_board"
VIEWER            = "viewer"
SERVICE           = "service"
```

### `CurrentUser` (`auth.py:32`)
Attrs: `sub: str`, `roles: list[RBACRole]`, `claims: dict`. Method `has_role(*roles) -> bool` = `any(r in self.roles for r in roles)`.

### `get_current_user(request: Request) -> CurrentUser` (`auth.py:52`)
Module globals: `_AUTH_SKIP_VERIFICATION = env AUTH_SKIP_VERIFICATION (default "true") == "true"`; `_DEV_AUTH_BYPASS = env DEV_AUTH_BYPASS (default "") == "true"`.
Logic:
```
if _DEV_AUTH_BYPASS: return CurrentUser(sub="local-dev", roles=list(RBACRole), claims={"sub":"local-dev","dev_bypass":True})
token = Bearer token from Authorization header (strip "Bearer ", else None)
if token is None: raise HTTPException(401, "Missing authorization token")
options = {} ; if _AUTH_SKIP_VERIFICATION: options = {verify_signature:False, verify_exp:False, verify_aud:False}
try payload = jwt.decode(token, _JWT_SECRET, algorithms=[_JWT_ALGORITHM], options=options)
except JWTError: raise HTTPException(401, "Invalid or expired token")
sub = payload.get("sub","anonymous"); raw_roles = payload.get("roles",[])
roles = [RBACRole(r) for r in raw_roles if valid]  # unknown role -> log "unknown_role_in_token", skip
if not roles: roles = [RBACRole.VIEWER]
return CurrentUser(sub, roles, payload)
```

### `require_role(*required_roles) -> dependency` (`auth.py:106`)
Returns async `_check(user=Depends(get_current_user))`:
```
if not user.has_role(*required_roles): raise HTTPException(403, f"Requires one of: {[r.value for r in required_roles]}")
return user
```

### Portfolio-access verifiers (`olympus-api/src/dependencies.py`) — used by chat
- `verify_portfolio_access(db, user, portfolio_id: UUID)` — L105
- `verify_application_portfolio_access(db, user, app_id: UUID)` — L184
- `verify_gate_portfolio_access(db, user, gate_id: UUID)` — L356
These enforce W20 membership. In chat handlers they are called inside `try/except ValueError: pass` (malformed UUID swallowed; existing 404 path surfaces it). Their internal raise behavior (403/404 on non-membership) is out of scope for this file but MUST exist.

---

## 2. ROUTER: chat.py — `router = APIRouter(tags=["Chat"])` (no prefix)

Module constants:
- `CHAT_MODEL_ID = env CHAT_MODEL_ID or "us.anthropic.claude-sonnet-4-6"` (chat.py:69)
- `A2A_AGENT_BASE_URL = env A2A_AGENT_BASE_URL or ""` (chat.py:901)
- `A2A_TIMEOUT_SECONDS = int(env A2A_CHAT_TIMEOUT or "60")` (chat.py:902)
- `VIEWER_PLUS` (chat.py:43) = `[VIEWER, TECH_LEAD, ARCH_LEAD, COMPLIANCE_LEAD, OPERATIONS_LEAD, SAFETY_BOARD, PORTFOLIO_MANAGER, PORTFOLIO_ADMIN]` (NOTE: excludes `SERVICE`)
- `CLEAR_HISTORY_ROLES` (chat.py:57) = `[TECH_LEAD, ARCH_LEAD, COMPLIANCE_LEAD, OPERATIONS_LEAD, SAFETY_BOARD, PORTFOLIO_MANAGER, PORTFOLIO_ADMIN]` (NOTE: excludes `VIEWER` and `SERVICE` — clearing is a write/destructive action)

### `SYSTEM_PROMPTS` dict (chat.py:77) — keyed by context_type, verbatim strings
- `"gate"`: "You are a Discovery analyst reviewing modernization evidence for a gate review. Answer the reviewer's question based on the evidence provided. Be specific, cite findings from the evidence, and be concise. Use markdown formatting for readability."
- `"application"`: "You are an application modernization analyst. Answer questions about this application's technology profile, discovery analysis findings, risk assessment, and modernization progress. Be specific, cite data from the context provided, and be concise. Use markdown formatting for readability."
- `"portfolio"`: "You are a portfolio modernization strategist. Answer questions about portfolio health, application status distribution, modernization progress, risk distribution, and pending actions. Be specific, cite data from the context provided, and be concise. Use markdown formatting for readability."

### Pydantic models
```python
class ChatRequest(BaseModel):                  # chat.py:105
    message: str
    artifact_context: str | None = None

class UnifiedChatRequest(BaseModel):           # chat.py:112
    context_type: Literal["gate","application","portfolio"]
    context_id: str
    section: str | None = None                 # portfolio-scoped discriminator; ignored for gate/application
    message: str
    artifact_context: str | None = None

class ChatSource(BaseModel):                   # chat.py:127
    artifact: str
    section: str | None = None
    finding_id: str | None = None
    file: str | None = None
    line: int | None = None

class ChatResponse(BaseModel):                 # chat.py:137
    response: str
    model_used: str = ""
    sources: list[ChatSource] | None = None

class ChatMessageOut(BaseModel):               # chat.py:145
    id: str
    role: str                                  # "reviewer" | "agent"
    content: str
    sources: list[dict] | None = None
    model_used: str | None = None
    created_at: str

class ChatHistoryResponse(BaseModel):          # chat.py:156
    messages: list[ChatMessageOut]
    context_type: str
    context_id: str
```

### Citation regexes + `parse_source_citations(text) -> list[ChatSource]` (chat.py:191-231)
⚠️ GOTCHA: regex order and dedup keys are load-bearing.
```
_ARTIFACT_CITATION_RE = re.compile(r"(?<!\w)([\w\-./]+):([\w\-]+):([\w\-]+)(?!\w)")   # {artifact}:{section}:{finding-id}
_REPO_CITATION_RE     = re.compile(r"(?<!\w)([\w\-]+/[\w\-]+):([\w\-./]+):(\d+)(?!\w)") # {repo}:{file}:{line}

parse_source_citations(text):
    sources=[]; seen=set()
    for m in _ARTIFACT_CITATION_RE.finditer(text):
        artifact,section,finding_id = m.groups()
        key=f"artifact:{artifact}:{section}:{finding_id}"
        if key not in seen: seen.add(key); sources.append(ChatSource(artifact=artifact, section=section, finding_id=finding_id))
    for m in _REPO_CITATION_RE.finditer(text):
        repo,file_path,line_str = m.groups()
        key=f"repo:{repo}:{file_path}:{line_str}"
        if key not in seen: seen.add(key); sources.append(ChatSource(artifact=repo, file=file_path, line=int(line_str)))
    return sources
```

### Persistence helpers
**`_scoped_context_id(context_type, context_id, section) -> str`** (chat.py:234) ⚠️ GOTCHA composite key:
```
if context_type != "portfolio": return context_id
section_key = section or "overview"
return f"{context_id}::{section_key}"   # separator is "::" (NOT single ":", which appears in section values like "wave:<id>")
```
**`_persist_message(db, *, context_type, context_id, role, content, section=None, gate_id=None, app_id=None, sources=None, model_used=None, token_usage=None) -> str`** (chat.py:261):
```
msg_id = str(uuid.uuid4())
scoped_id = _scoped_context_id(context_type, context_id, section)
INSERT INTO chat_message (id, context_type, context_id, role, content, gate_id, app_id, sources, model_used, token_usage)
  VALUES (:id, :context_type, :context_id(=scoped_id), :role, :content, :gate_id, :app_id,
          CAST(:sources AS jsonb), :model_used, CAST(:token_usage AS jsonb))
  # sources = json.dumps(sources) if sources else None ; token_usage = json.dumps(token_usage) if token_usage else None
await db.commit(); return msg_id
```
**`_get_chat_history(db, context_type, context_id, section=None) -> list[ChatMessageOut]`** (chat.py:308):
```
scoped_id = _scoped_context_id(context_type, context_id, section)
SELECT id, role, content, sources, model_used, created_at FROM chat_message
  WHERE context_type=:context_type AND context_id=:context_id(=scoped_id) ORDER BY created_at ASC
-> [ChatMessageOut(id=str(id), role, content, sources=row[sources], model_used, created_at=created_at.isoformat() if created_at else "")]
```

### Context builders (best-effort; failures inside swallowed)
**`_build_evidence_summary(evidence) -> str`** (chat.py:348):
```
if not hasattr(evidence, "artifacts"): return "No evidence available."
if getattr(evidence,"wave_id",None): subject_label="Wave"; subject_name = evidence.wave_name or "Unknown"
else: subject_label="Application"; subject_name = evidence.app_name or "Unknown"
parts = [f"Gate: {evidence.gate_type} — {evidence.assembly_line}", f"{subject_label}: {subject_name}"]
unit_artifact_types = {"discovery_pass","rationalization_step"}
for artifact in evidence.artifacts:
    if artifact.artifact_type not in unit_artifact_types: continue
    analysis = artifact.data.get("analysis","") if artifact.data else ""
    if not analysis: continue
    if len(analysis) > 3000: analysis = analysis[:3000] + "... [truncated]"
    parts.append(f"\n--- {artifact.title} ---\n{analysis}")
return "\n".join(parts)
```
⚠️ GOTCHA: include BOTH `discovery_pass` AND `rationalization_step` unit-artifact types; filtering to only `discovery_pass` silently empties wave-gate bundles.

**`_build_gate_context(db, gate_id, artifact_context) -> str`** (chat.py:398):
```
evidence = await gate_svc.get_gate_evidence(db, uuid.UUID(gate_id))
summary = _build_evidence_summary(evidence)
parts = ["=== Evidence ===", summary]
if artifact_context: parts.append(f"\n=== Currently Viewing ===\n{artifact_context}")
return "\n".join(parts)
```

**`_build_application_context(app_id, db=None) -> str`** (chat.py:413):
```
parts=[]
catalog = await read_mcp_resource(f"catalog://{app_id}")
if catalog: parts += ["=== Application Catalog ===", json.dumps(catalog, indent=2, default=str)[:4000]]
analysis = await read_mcp_resource(f"analysis://{app_id}")
if analysis:
    parts.append("\n=== Discovery Analysis ===")
    s = json.dumps(analysis, indent=2, default=str)
    if len(s) > 6000: s = s[:6000] + "\n... [truncated]"
    parts.append(s)
disposition = await read_mcp_resource(f"disposition://{app_id}")
if disposition: parts += ["\n=== Disposition ===", json.dumps(disposition, indent=2, default=str)[:2000]]
# Consolidation-target source folding (only when db is not None):
if db is not None:
    try: source_rows = SELECT al.source_app_id, a.name AS source_name, al.relationship
                        FROM application_lineage al JOIN application a ON a.id=al.source_app_id
                        WHERE al.target_app_id=:app_id AND al.retired_at IS NULL
                          AND al.source_app_id <> al.target_app_id ORDER BY a.name ASC
    except Exception: source_rows = []   # best-effort
    if source_rows:
        parts.append(f"\n=== Consolidation Sources ({len} app{'s' if len!=1 else ''} feeding this target) ===")
        parts.append("This is a consolidation target. Discovery and Rationalization ran on the source applications below — use their artifacts to answer questions about what was consolidated and why. Each source's analysis is summarised; refer to the underlying repos for full depth.")
        for src in source_rows:
            src_id=str(src.source_app_id); parts += [f"\n--- Source: {src.source_name} ({src_id}) ---", f"Relationship: {src.relationship}"]
            src_catalog = read_mcp_resource(catalog://src_id) -> if: ["Catalog:", json.dumps(...)[:1500]]
            src_analysis = read_mcp_resource(analysis://src_id) -> if: ["Discovery Analysis (truncated):", json.dumps(...) trunc@3000 + "\n... [truncated]"]
            src_disp = read_mcp_resource(disposition://src_id) -> if: ["Disposition:", json.dumps(...)[:1500]]
if not parts: parts.append("No application data available from MCP resources.")
return "\n".join(parts)
```

**`_build_portfolio_context(db, portfolio_id, *, section=None) -> str`** (chat.py:528):
```
parts=[]
if portfolio_id == "default":
    first = SELECT id,name,status FROM portfolio ORDER BY created_at LIMIT 1
    if not first: return "No portfolios exist yet. Create a portfolio and onboard applications to get started."
    portfolio_id = str(first.id); row = first
else:
    row = SELECT name,status FROM portfolio WHERE id=:pid
if not row: return "Portfolio not found."
parts += [f"=== Portfolio: {row.name} ===", f"Status: {row.status}"]
apps = SELECT name,current_status,current_line,disposition,risk_tier FROM application WHERE portfolio_id=:pid ORDER BY name
parts.append(f"\n=== Applications ({len(apps)} total) ===")
for app in apps: parts.append(f"- {app.name}: status={app.current_status}, line={app.current_line}, disposition={app.disposition}, risk_tier={app.risk_tier}")
status_counts={}; for app: status_counts[app.current_status or "unknown"] += 1
parts.append("\n=== Status Distribution ==="); for s,count in sorted(status_counts.items()): parts.append(f"- {s}: {count}")
gate_count = SELECT count(*) FROM gate g JOIN application a ON g.application_id=a.id WHERE a.portfolio_id=:pid AND g.status='pending'  (or 0)
parts.append(f"\n=== Pending Gates: {gate_count} ===")
if gate_count > 0:
    gates = SELECT g.gate_type, a.name as app_name, g.sla_deadline FROM gate g JOIN application a ON g.application_id=a.id
            WHERE a.portfolio_id=:pid AND g.status='pending' ORDER BY g.requested_at
    for g: parts.append(f"- {g.gate_type} for {g.app_name} (SLA: {g.sla_deadline or 'none'})")
if section:
    block = await _build_section_context(db, portfolio_id, section)
    if block: parts += [f"\n=== Viewing: {section} ===", block]
return "\n".join(parts)
```

**`_build_section_context(db, portfolio_id, section) -> str`** (chat.py:649) — branch-by-branch (reproduce ALL branches; unknown returns ""):
```
if section == "waves":
    rows = SELECT w.name, w.status, w.workflow_id,
                  (SELECT count(*) FROM wave_application wa WHERE wa.wave_id=w.id) AS app_count
           FROM wave w WHERE w.portfolio_id=:pid ORDER BY w.created_at DESC
    if not rows: return "No waves defined for this portfolio yet."
    lines=[f"Total waves: {len(rows)}"]; for r: lines.append(f"- {r.name}: status={r.status}, apps={r.app_count}, workflow={r.workflow_id or 'none'}")
    return "\n".join(lines)

if section == "gate-queue":
    rows = SELECT g.gate_type, a.name AS app_name, g.status, g.sla_deadline, g.requested_at
           FROM gate g JOIN application a ON g.application_id=a.id
           WHERE a.portfolio_id=:pid AND g.status IN ('pending','escalated')
           ORDER BY g.sla_deadline NULLS LAST, g.requested_at LIMIT 50
    if not rows: return "Gate queue is empty — no pending or escalated gates."
    lines=[f"Pending/escalated gates: {len(rows)}"]; for r: lines.append(f"- {r.gate_type} for {r.app_name}: status={r.status}, SLA={r.sla_deadline or 'none'}")
    return "\n".join(lines)

if section == "skills":
    rows = SELECT COALESCE(skill_id, split_part(task_type,'-',1)) AS skill_id, count(*) AS dispatches, max(completed_at) AS last_run
           FROM agent_task WHERE application_id IN (SELECT id FROM application WHERE portfolio_id=:pid)
           GROUP BY 1 ORDER BY count(*) DESC LIMIT 20
    if not rows: return "No skill dispatches recorded against this portfolio yet."
    lines=["Skill dispatch activity (top 20):"]; for r: lines.append(f"- {r.skill_id}: dispatches={r.dispatches}, last_run={r.last_run or 'n/a'}")
    return "\n".join(lines)

if section == "analytics":
    total = SELECT count(*) FROM application WHERE portfolio_id=:pid  (or 0)
    tiers = SELECT risk_tier, count(*) AS c FROM application WHERE portfolio_id=:pid GROUP BY risk_tier ORDER BY risk_tier
    dispo = SELECT COALESCE(disposition,'(none)') AS d, count(*) AS c FROM application WHERE portfolio_id=:pid GROUP BY 1 ORDER BY 2 DESC
    lines=[f"Applications: {total}"]
    if tiers: lines.append("Risk tier distribution:"); for t: lines.append(f"- Tier {t.risk_tier or 'unset'}: {t.c}")
    if dispo: lines.append("Disposition spread:"); for d: lines.append(f"- {d.d}: {d.c}")
    return "\n".join(lines)

if section == "admin":
    row = SELECT name, status, artifact_repo_url, created_at FROM portfolio WHERE id=:pid
    if not row: return ""
    return f"Portfolio: {row.name} (id={portfolio_id})\nStatus: {row.status}\nArtifact repo: {row.artifact_repo_url or '(none)'}\nCreated: {row.created_at}"

if section == "applications":
    return ""   # full app rows already in rollup; deliberately empty to avoid bloat

if section.startswith("wave:"):
    wave_id = section.split(":",1)[1]
    wave = SELECT name,status,workflow_id FROM wave WHERE id::text=:wid AND portfolio_id=:pid
    if not wave: return f"Wave {wave_id} not found in this portfolio."
    apps = SELECT a.name,a.current_status,a.current_line,a.disposition,a.risk_tier FROM application a
           JOIN wave_application wa ON wa.application_id=a.id WHERE wa.wave_id::text=:wid ORDER BY a.name
    lines=[f"Wave: {wave.name}", f"Status: {wave.status}", f"Workflow: {wave.workflow_id or 'none'}", f"Applications in wave: {len(apps)}"]
    for a: lines.append(f"- {a.name}: status={a.current_status}, line={a.current_line}, disposition={a.disposition or 'n/a'}, risk_tier={a.risk_tier or 'n/a'}")
    return "\n".join(lines)

if section.startswith("assembly-line:"):
    line_id = section.split(":",1)[1]
    rows = SELECT name,current_status,current_step,risk_tier,disposition FROM application
           WHERE portfolio_id=:pid AND lower(current_line::text)=lower(:line) ORDER BY name
    if not rows: return f"No applications currently in the {line_id} line for this portfolio."
    lines=[f"Applications in {line_id} line: {len(rows)}"]; for r: lines.append(f"- {r.name}: status={r.current_status}, step={r.current_step or 'n/a'}, disposition={r.disposition or 'n/a'}")
    return "\n".join(lines)

return ""   # overview / unknown
```

### A2A dispatch helpers
**`_get_gate_agent_url(db, gate_id) -> str | None`** (chat.py:904):
```
row = SELECT evidence_data->'agent_url' as agent_url FROM gate WHERE id=:gate_id  (first)
if row and row.agent_url:
    url = row.agent_url; return url.strip('"') if isinstance(url,str) else None   # JSONB text may carry quotes
return A2A_AGENT_BASE_URL or None
```
**`_dispatch_a2a_chat(agent_url, message, context, history) -> ChatResponse | None`** (chat.py:922):
```
conversation = [{"role": msg.role, "content": msg.content} for msg in history]
payload = {"task":"chat", "context":{"evidence_summary": context, "conversation_history": conversation}, "message": message, "model_preference":"tier-2"}
try:
    async with httpx.AsyncClient(timeout=A2A_TIMEOUT_SECONDS) as client:
        resp = await client.post(f"{agent_url}/a2a/chat", json=payload); resp.raise_for_status(); data = resp.json()
    response_text = data.get("response",""); model_used = data.get("model_used","")
    if not response_text: return None
    sources = parse_source_citations(response_text)
    return ChatResponse(response=response_text, model_used=model_used, sources=sources if sources else None)
except Exception: logger.warning("chat_a2a_dispatch_error", exc_info=True); return None   # -> Bedrock fallback
```

### Bedrock invocation
**`_get_bedrock_client()`** (chat.py:980): `boto3.client("bedrock-runtime", region_name=env AWS_REGION or "us-east-1")`.
**`_invoke_bedrock(system_prompt, user_message) -> ChatResponse`** (chat.py:986):
```
try:
    client = _get_bedrock_client()
    response = client.invoke_model(modelId=CHAT_MODEL_ID, contentType="application/json", accept="application/json",
        body=json.dumps({"anthropic_version":"bedrock-2023-05-31", "max_tokens":2048, "system": system_prompt,
                         "messages":[{"role":"user","content": user_message}]}))
    result = json.loads(response["body"].read())
    response_text = "".join(block["text"] for block in result.get("content",[]) if block.get("type")=="text")
    if not response_text: response_text = "I wasn't able to generate a response. Please try rephrasing your question."
    sources = parse_source_citations(response_text)
    return ChatResponse(response=response_text, model_used=result.get("model", CHAT_MODEL_ID), sources=sources if sources else None)
except Exception: logger.warning("chat_bedrock_error", exc_info=True)
    return ChatResponse(response="An error occurred while contacting the model. Please try again.")
```

---

### ENDPOINT C1 — POST /api/v1/gates/{gate_id}/chat (chat.py:1049)
- **Method/Path**: `POST /api/v1/gates/{gate_id}/chat`
- **Path param**: `gate_id: uuid.UUID`
- **Auth**: `_user: CurrentUser = Depends(require_role(*VIEWER_PLUS))`
- **Request body**: `body: ChatRequest` (`message: str`, `artifact_context: str | None`)
- **Response model**: `ChatResponse`; **status 200**
- **DB dep**: `db = Depends(get_db)`
- Logic:
```
gate_id_str = str(gate_id)
context = await _build_gate_context(db, gate_id_str, body.artifact_context)
await _persist_message(db, context_type="gate", context_id=gate_id_str, role="reviewer", content=body.message, gate_id=gate_id_str)
history = await _get_chat_history(db, "gate", gate_id_str)
agent_url = await _get_gate_agent_url(db, gate_id_str)
chat_response = None
if agent_url: chat_response = await _dispatch_a2a_chat(agent_url, body.message, context, history)
if chat_response is None:
    user_message = f"{context}\n\n=== Question ===\n{body.message}"
    chat_response = _invoke_bedrock(SYSTEM_PROMPTS["gate"], user_message)
sources_dicts = [s.model_dump(exclude_none=True) for s in chat_response.sources] if chat_response.sources else None
await _persist_message(db, context_type="gate", context_id=gate_id_str, role="agent", content=chat_response.response,
                       gate_id=gate_id_str, sources=sources_dicts, model_used=chat_response.model_used)
return chat_response
```
- ⚠️ GOTCHA: legacy endpoint does NOT call `verify_gate_portfolio_access` (unlike the unified/history endpoints). Order: persist-user → build-history → A2A → bedrock-fallback → persist-agent.

### ENDPOINT C2 — POST /api/v1/chat (chat.py:1112)
- **Method/Path**: `POST /api/v1/chat`
- **Auth**: TWO deps — `_user = Depends(require_role(*VIEWER_PLUS))` AND `user = Depends(get_current_user)` (the second supplies the user object for membership checks)
- **Request body**: `body: UnifiedChatRequest`
- **Response model**: `ChatResponse`; **status 200**
- **DB dep**: `db = Depends(get_db)`
- Logic:
```
# W20 portfolio scoping up-front (each in try/except ValueError: pass):
if body.context_type=="gate":        await verify_gate_portfolio_access(db, user, uuid.UUID(body.context_id))
elif body.context_type=="application": await verify_application_portfolio_access(db, user, uuid.UUID(body.context_id))
elif body.context_type=="portfolio" and body.context_id != "default": await verify_portfolio_access(db, user, uuid.UUID(body.context_id))

gate_id = body.context_id if context_type=="gate" else None
app_id  = body.context_id if context_type=="application" else None
await _persist_message(db, context_type=body.context_type, context_id=body.context_id, section=body.section,
                       role="reviewer", content=body.message, gate_id=gate_id, app_id=app_id)

# Build context:
if gate:        context = await _build_gate_context(db, body.context_id, body.artifact_context)
elif application: context = await _build_application_context(body.context_id, db=db)
                  if body.artifact_context: context += f"\n\n=== Additional Context ===\n{body.artifact_context}"
elif portfolio: context = await _build_portfolio_context(db, body.context_id, section=body.section)
else:           context = "No context available."

chat_response = None
if context_type=="gate":
    history = await _get_chat_history(db, "gate", body.context_id)
    agent_url = await _get_gate_agent_url(db, body.context_id)
    if agent_url: chat_response = await _dispatch_a2a_chat(agent_url, body.message, context, history)
if chat_response is None:
    user_message = f"{context}\n\n=== Question ===\n{body.message}"
    system_prompt = SYSTEM_PROMPTS.get(body.context_type, SYSTEM_PROMPTS["gate"])
    chat_response = _invoke_bedrock(system_prompt, user_message)
sources_dicts = [s.model_dump(exclude_none=True) for s in chat_response.sources] if chat_response.sources else None
await _persist_message(db, context_type=body.context_type, context_id=body.context_id, section=body.section,
                       role="agent", content=chat_response.response, gate_id=gate_id, app_id=app_id,
                       sources=sources_dicts, model_used=chat_response.model_used)
return chat_response
```
- ⚠️ GOTCHA: only `gate` context attempts A2A; `application`/`portfolio` go straight to Bedrock. `section` is only persisted/used for `portfolio` (folded into context_id via `_scoped_context_id`); for gate/application it is threaded but `_scoped_context_id` ignores it.

### ENDPOINT C3 — GET /api/v1/gates/{gate_id}/chat/history (chat.py:1216)
- **Method/Path**: `GET /api/v1/gates/{gate_id}/chat/history`
- **Path param**: `gate_id: uuid.UUID`
- **Auth**: `_user = Depends(require_role(*VIEWER_PLUS))` AND `user = Depends(get_current_user)`
- **Response model**: `ChatHistoryResponse`; **status 200**
- Logic:
```
await verify_gate_portfolio_access(db, user, gate_id)   # NOT wrapped in try/except here — gate_id already validated UUID
gate_id_str = str(gate_id)
messages = await _get_chat_history(db, "gate", gate_id_str)
return ChatHistoryResponse(messages=messages, context_type="gate", context_id=gate_id_str)
```

### ENDPOINT C4 — GET /api/v1/chat/history (chat.py:1237)
- **Method/Path**: `GET /api/v1/chat/history`
- **Query params**: `context_type: str` (required), `context_id: str` (required), `section: str | None` (optional)
- **Auth**: `_user = Depends(require_role(*VIEWER_PLUS))` AND `user = Depends(get_current_user)`
- **Response model**: `ChatHistoryResponse`; **status 200**
- Logic:
```
# W20 scoping (each try/except ValueError: pass):
if gate: verify_gate_portfolio_access(db,user,UUID(context_id))
elif application: verify_application_portfolio_access(db,user,UUID(context_id))
elif portfolio and context_id != "default": verify_portfolio_access(db,user,UUID(context_id))
messages = await _get_chat_history(db, context_type, context_id, section)
return ChatHistoryResponse(messages=messages, context_type=context_type, context_id=context_id)
```

### ENDPOINT C5 — DELETE /api/v1/chat/history (chat.py:1278)
- **Method/Path**: `DELETE /api/v1/chat/history`
- **Query params**: `context_type: str` (required), `context_id: str` (required), `section: str | None` (optional)
- **Auth**: `_user = Depends(require_role(*CLEAR_HISTORY_ROLES))` (⚠️ stricter — excludes VIEWER) AND `user = Depends(get_current_user)`
- **Response**: `Response` object; **status 204**; sets header `X-Cleared-Count: <int>`
- Logic:
```
# W20 scoping (each try/except ValueError: pass): gate / application / (portfolio and != "default")
scoped_id = _scoped_context_id(context_type, context_id, section)
result = DELETE FROM chat_message WHERE context_type=:ctype AND context_id=:cid(=scoped_id)
await db.commit()
cleared = getattr(result, "rowcount", None) or 0
logger.info("chat_history_cleared", context_type=..., context_id=scoped_id, cleared=cleared)
return Response(status_code=204, headers={"X-Cleared-Count": str(cleared)})
```
- ⚠️ GOTCHA: idempotent (count=0 still returns 204). No "clear all" — scope is always (context_type, context_id, section?). Hard delete.

---

## 3. ROUTER: workflows.py — `router = APIRouter(prefix="/api/v1/workflows", tags=["Workflows"])`

### Workflow models (`olympus-api/src/models/workflow.py`)
```python
WorkflowHealthStatus = Literal["RUNNING","COMPLETED","FAILED","CANCELED","TERMINATED","CONTINUED_AS_NEW","TIMED_OUT","UNKNOWN"]

class WorkflowSummary(BaseModel):                # workflow.py:28
    workflow_id: str
    run_id: str | None = None
    workflow_type: str
    status: WorkflowHealthStatus
    app_id: UUID | None = None
    app_name: str | None = None
    start_time: datetime | None = None
    close_time: datetime | None = None
    elapsed_seconds: float | None = None
    task_queue: str | None = None
    history_length: int | None = None
    temporal_ui_url: str | None = None

class WorkflowListResponse(BaseModel):           # workflow.py:45
    running: list[WorkflowSummary] = []
    failed: list[WorkflowSummary] = []
    temporal_unreachable: bool = False

class WorkflowFailureDetail(BaseModel):          # workflow.py:53
    failing_activity: str | None = None
    last_error: str | None = None
    retry_count: int | None = None
    stack_trace: str | None = None

class WorkflowDetail(BaseModel):                 # workflow.py:62  (WorkflowSummary fields + the following two)
    ... all WorkflowSummary fields ...
    failure: WorkflowFailureDetail | None = None
    temporal_unreachable: bool = False

class WorkflowActionRequest(BaseModel):          # workflow.py:81
    reason: str | None = None

class WorkflowActionResponse(BaseModel):         # workflow.py:90
    workflow_id: str
    action: Literal["restart","fail"]
    new_workflow_id: str | None = None
    detail: str
```

### ENDPOINT W1 — GET /api/v1/workflows (workflows.py:33)
- **Method/Path**: `GET /api/v1/workflows`
- **Query**: `limit: int = Query(50, ge=1, le=200)`
- **Auth**: NONE declared (no `require_role`/`get_current_user` dependency on this route — only `db` + `temporal`). ⚠️ GOTCHA: list/detail routes are unauthenticated at the router level; only restart/fail require a role.
- **Deps**: `db = Depends(get_db)`, `temporal: Client = Depends(get_temporal_client)`; `config = get_config()` (called in body)
- **Response model**: `WorkflowListResponse`; **status 200**
- Body: `return await workflow_health.list_workflows(db, temporal, config, limit=limit)`

### ENDPOINT W2 — GET /api/v1/workflows/{workflow_id} (workflows.py:44)
- **Method/Path**: `GET /api/v1/workflows/{workflow_id}`
- **Path param**: `workflow_id: str`
- **Auth**: NONE declared.
- **Deps**: `db`, `temporal`; `config = get_config()`
- **Response model**: `WorkflowDetail`; **status 200**
- Body: `return await workflow_health.get_workflow_detail(db, workflow_id, temporal, config)`

### ENDPOINT W3 — POST /api/v1/workflows/{workflow_id}/restart (workflows.py:55)
- **Method/Path**: `POST /api/v1/workflows/{workflow_id}/restart`
- **Path param**: `workflow_id: str`
- **Auth**: `_user: Annotated[CurrentUser, Depends(require_role(RBACRole.OPERATIONS_LEAD, RBACRole.PORTFOLIO_ADMIN))]`
- **Deps**: `db`, `temporal`; `config = get_config()`
- **Request body**: none
- **Response model**: `WorkflowActionResponse`; **status 202** (declared `status_code=202`)
- Body: `return await workflow_health.restart_workflow(db, workflow_id, temporal, config)`

### ENDPOINT W4 — POST /api/v1/workflows/{workflow_id}/fail (workflows.py:74)
- **Method/Path**: `POST /api/v1/workflows/{workflow_id}/fail`
- **Path param**: `workflow_id: str`
- **Auth**: `_user: Annotated[CurrentUser, Depends(require_role(RBACRole.OPERATIONS_LEAD, RBACRole.PORTFOLIO_ADMIN))]`
- **Request body**: `body: WorkflowActionRequest | None = None`
- **Deps**: `db`, `temporal`
- **Response model**: `WorkflowActionResponse`; **status 200** (no `status_code` override)
- Body: `reason = body.reason if body else None; return await workflow_health.fail_workflow(db, workflow_id, temporal, reason)`

### Service: workflow_health.py (drives W1–W4)
Module helpers (preserve exactly):
- `_FAILED_STATUSES = (FAILED, TERMINATED, TIMED_OUT)` — CANCELED intentionally excluded.
- `_status_name(status)` → `"UNKNOWN"` if None else `status.name`.
- `_temporal_ui_url(config, wf_id)` → `f"{config.temporal_ui_base_url.rstrip('/')}/namespaces/{config.temporal_namespace}/workflows/{wf_id}"`.
- `_elapsed(start, close)` → None if start is None; else `end=close or now(utc)`; tz-normalize both to utc if naive; `max(0.0, (end-start).total_seconds())`.
- `_extract_app_id_from_workflow_id(wf_id)` → split on "-"; for each window of 5 consecutive parts, join with "-"; if `len==36` try `uuid.UUID(candidate)`, return first parse; else None. ⚠️ GOTCHA: workflow_ids are `{line}-{app_uuid}-{run_ts}`; UUID is middle 5 hex groups.
- `_extract_app_id(wf)` → `_extract_app_id_from_workflow_id(getattr(wf,"id","") or "")`.
- `_app_names(db, app_ids)` → `{}` if empty else `SELECT id,name FROM application WHERE id = ANY(:ids)` → dict id→name.
- `_summarize(wf, config, app_names)` → builds `WorkflowSummary` from wf attrs (`id`, `run_id`, `workflow_type` or "", `_status_name(status)`, extracted app_id, app_name lookup, start/close, `_elapsed`, `task_queue`, `history_length`, `_temporal_ui_url`).

**`list_workflows(db, temporal, config, *, limit=50)`** (workflow_health.py:136):
```
running_raw=[]; failed_raw=[]; unreachable=False
try:
    async for wf in temporal.list_workflows("ExecutionStatus = 'Running'", page_size=limit):
        running_raw.append(wf); if len>=limit: break
except RPCError: logger.warning("workflow_list.running_failed", ...); unreachable=True
failed_query = "ExecutionStatus = 'Failed' OR ExecutionStatus = 'Terminated' OR ExecutionStatus = 'TimedOut'"
try:
    async for wf in temporal.list_workflows(failed_query, page_size=limit):
        failed_raw.append(wf); if len>=limit: break
except RPCError: logger.warning("workflow_list.failed_failed", ...); unreachable=True
app_ids = {aid for wf in running_raw+failed_raw if (aid:=_extract_app_id(wf)) is not None}
app_names = await _app_names(db, app_ids)
running = [await _summarize(wf, config, app_names) for wf in running_raw]
failed  = [await _summarize(wf, config, app_names) for wf in failed_raw]
return WorkflowListResponse(running=running, failed=failed, temporal_unreachable=unreachable)
```

**`_latest_failure_event(handle)`** (workflow_health.py:191):
```
try: history = handle.fetch_history_events(event_filter_type=WorkflowHistoryEventFilterType.ALL_EVENT)
except RPCError: logger.warning("history_fetch.failed",...); return None
last_activity_failed=None; last_workflow_failed=None
try:
    async for event in history:
        attrs = event.activity_task_failed_event_attributes
        if attrs and attrs.failure:
            last_activity_failed = {activity_type: None, message: attrs.failure.message,
                                    retry_count: attrs.scheduled_event_id, stack_trace: attrs.failure.stack_trace}
        wf_failed = event.workflow_execution_failed_event_attributes
        if wf_failed and wf_failed.failure:
            last_workflow_failed = {message: wf_failed.failure.message, stack_trace: wf_failed.failure.stack_trace}
except RPCError: logger.warning("history_iter.failed",...)
# prefer workflow-level (terminal) over activity-level:
if last_workflow_failed: return {failing_activity:None, last_error:msg, retry_count:None, stack_trace:...}
if last_activity_failed: return {failing_activity:activity_type, last_error:msg, retry_count:scheduled_event_id, stack_trace:...}
return None
```
⚠️ GOTCHA: `activity_type` is always None (scheduled-event lookup deliberately skipped); `retry_count` is reused to carry `scheduled_event_id`.

**`_build_aged_out_workflow_detail(db, workflow_id, config)`** (workflow_health.py:244) — DB fallback when Temporal returns NOT_FOUND:
```
app_id = _extract_app_id_from_workflow_id(workflow_id)
parts = workflow_id.split("-", 1); workflow_type_guess = "" then prefix-map:
    {"architecture":"ArchitectureWorkflow","data":"DataWorkflow","discovery":"DiscoveryWorkflow",
     "modernization":"ModernizationWorkflow","validation":"ValidationWorkflow","deployment":"DeploymentWorkflow",
     "wave":"WaveRationalizationWorkflow","disposition":"DispositionExecutionWorkflow"}.get(parts[0], "")
app_status=None; app_name=None
if app_id: row = SELECT name,current_status,current_line FROM application WHERE id=:app_id (first)
           if row: app_name=row.name; app_status=row.current_status
status_str = "COMPLETED"
if app_status in ("failed","stuck","stuck-awaiting-recovery"): status_str="FAILED"
elif app_status in ("cancelled","canceled"): status_str="CANCELED"
elif app_status in ("in_progress","running"): status_str="TERMINATED"   # Temporal has no record -> don't claim live
start_close = SELECT MIN(started_at) AS first_started, MAX(completed_at) AS last_completed FROM step_execution WHERE workflow_id=:wid (first)
start = start_close.first_started; close = start_close.last_completed
return WorkflowDetail(workflow_id, run_id=None, workflow_type=workflow_type_guess, status=status_str,
                      app_id, app_name, start_time=start, close_time=close, elapsed_seconds=_elapsed(start,close),
                      task_queue=None, history_length=None, temporal_ui_url=_temporal_ui_url(config,workflow_id),
                      failure=None, temporal_unreachable=False)   # NOT unreachable — just past retention TTL
```

**`get_workflow_detail(db, workflow_id, temporal, config)`** (workflow_health.py:337):
```
handle = temporal.get_workflow_handle(workflow_id)
unreachable=False; aged_out=False; desc=None
try: desc = await handle.describe()
except RPCError as e:
    is_not_found = (e.status == RPCStatusCode.NOT_FOUND or "workflow not found" in str(e).lower() or "workflow execution not found" in str(e).lower())
    if is_not_found: aged_out=True; logger.info("workflow_detail.workflow_aged_out", ...)
    else: unreachable=True; logger.warning("workflow_detail.describe_failed", ...)
if desc is None:
    if aged_out:
        db_detail = await _build_aged_out_workflow_detail(db, workflow_id, config)
        if db_detail is not None: return db_detail
    return WorkflowDetail(workflow_id, workflow_type="", status="UNKNOWN",
                          temporal_ui_url=_temporal_ui_url(config,workflow_id), temporal_unreachable=unreachable)
app_id = _extract_app_id(desc); names = await _app_names(db, {app_id} if app_id else set())
status_name = _status_name(desc.status); failure=None
if status_name in ("FAILED","TERMINATED","TIMED_OUT"):
    raw = await _latest_failure_event(handle)
    if raw: failure = WorkflowFailureDetail(failing_activity=..., last_error=..., retry_count=..., stack_trace=...)
return WorkflowDetail(workflow_id, run_id=desc.run_id, workflow_type=desc.workflow_type or "", status=status_name,
                      app_id, app_name=names.get(app_id) if app_id else None, start_time=desc.start_time, close_time=desc.close_time,
                      elapsed_seconds=_elapsed(...), task_queue=desc.task_queue, history_length=desc.history_length,
                      temporal_ui_url=_temporal_ui_url(config,workflow_id), failure=failure, temporal_unreachable=False)
```

**`restart_workflow(db, workflow_id, temporal, config)`** (workflow_health.py:429):
```
handle = temporal.get_workflow_handle(workflow_id)
try: desc = await handle.describe()
except RPCError: raise OlympusHTTPException(404, "WORKFLOW_NOT_FOUND", f"Workflow {workflow_id} not found.")
workflow_type = desc.workflow_type; task_queue = desc.task_queue
if not workflow_type or not task_queue: raise OlympusHTTPException(422, "WORKFLOW_UNRESTARTABLE", "Workflow metadata is incomplete; cannot restart automatically.")
original_input = None
try:
    history = handle.fetch_history_events(event_filter_type=ALL_EVENT)
    async for event in history:
        attrs = event.workflow_execution_started_event_attributes
        if attrs: original_input = (attrs.input.payloads or []); break
except RPCError: logger.warning("restart.history_fetch_failed", ...)
run_ts = int(now(utc).timestamp()); new_workflow_id = f"{workflow_id}-restart-{run_ts}"
try: await temporal.start_workflow(workflow_type, original_input, id=new_workflow_id, task_queue=task_queue)
except RPCError as e: raise OlympusHTTPException(500, "WORKFLOW_RESTART_FAILED", f"Failed to start replacement workflow: {e}")
return WorkflowActionResponse(workflow_id, action="restart", new_workflow_id=new_workflow_id,
        detail=f"Started replacement workflow {new_workflow_id}. Original run {workflow_id} left in terminal state for post-mortem.")
```
⚠️ GOTCHA: restart starts a NEW workflow_id `{orig}-restart-{epoch_ts}`; original is left intact. Errors map to OlympusHTTPException codes 404 / 422 / 500.

**`fail_workflow(db, workflow_id, temporal, reason)`** (workflow_health.py:500):
```
handle = temporal.get_workflow_handle(workflow_id)
try: await handle.terminate(reason=reason or "operator-initiated fail")
except RPCError as e:
    if e.status.name == "NOT_FOUND": raise OlympusHTTPException(404, "WORKFLOW_NOT_FOUND", f"Workflow {workflow_id} not found.")
    raise OlympusHTTPException(500, "WORKFLOW_FAIL_FAILED", f"Failed to terminate workflow: {e}")
return WorkflowActionResponse(workflow_id, action="fail", new_workflow_id=None, detail=f"Workflow {workflow_id} terminated.")
```
⚠️ GOTCHA: uses `handle.terminate()` (no cleanup) not cancel; default reason "operator-initiated fail".

---

## 4. ROUTER: workflow_signals.py — `router = APIRouter(prefix="/api/v1/workflow-signals", tags=["Workflow Signals"])`

⚠️ NOTE (workflow_signals.py:1): there is intentionally NO POST on this router — the only writer of the inbox is the API layer itself (`dispatch_architecture`). This router only EXPOSES pending/queued rows. (`signal_inbox.enqueue_signal` / `mark_queued` are the write path, reproduced below for completeness; they are invoked by other routers, not here.)

`VIEWER_PLUS` (workflow_signals.py:23) = `[VIEWER, TECH_LEAD, ARCH_LEAD, COMPLIANCE_LEAD, OPERATIONS_LEAD, SAFETY_BOARD, PORTFOLIO_MANAGER, PORTFOLIO_ADMIN]`.

```python
class PendingSignalEntry(BaseModel):             # workflow_signals.py:38
    id: str
    workflow_id: str
    signal_name: str
    payload: dict = Field(default_factory=dict)
    status: str
    created_at: datetime | None = None
    consumed_at: datetime | None = None

class PendingSignalsResponse(BaseModel):         # workflow_signals.py:50
    entries: list[PendingSignalEntry] = Field(default_factory=list)
```

### ENDPOINT WS1 — GET /api/v1/workflow-signals/pending (workflow_signals.py:56)
- **Method/Path**: `GET /api/v1/workflow-signals/pending`
- **Query**: `workflow_id: str | None = Query(None, ...)`, `limit: int = Query(100, ge=1, le=500)`
- **Auth**: `_user = Depends(require_role(*VIEWER_PLUS))`
- **Deps**: `db = Depends(get_db)`
- **Response model**: `PendingSignalsResponse`; **status 200**
- Logic:
```
rows = await signal_inbox.list_pending(db, workflow_id=workflow_id, limit=limit)
entries = [PendingSignalEntry(id=str(r["id"]), workflow_id=r["workflow_id"], signal_name=r["signal_name"],
                              payload=r["payload"] or {}, status=r["status"],
                              created_at=r.get("created_at"), consumed_at=r.get("consumed_at")) for r in rows]
return PendingSignalsResponse(entries=entries)
```

### Service: signal_inbox.py
**`list_pending(db, workflow_id=None, limit=100)`** (signal_inbox.py:82):
```
where = "status IN ('pending', 'queued')"     # 'sent' rows excluded (Temporal already accepted them)
params = {"lim": limit}
if workflow_id: where += " AND workflow_id = :wfid"; params["wfid"]=workflow_id
rows = SELECT id, workflow_id, signal_name, payload, status, created_at, consumed_at
       FROM workflow_signal_inbox WHERE {where} ORDER BY created_at ASC LIMIT :lim
return [dict(r) for r in rows]
```
**`enqueue_signal(db, workflow_id, signal_name, payload=None, status="sent") -> uuid.UUID`** (signal_inbox.py:26) — WRITE path used by OTHER routers:
```
row_id = uuid.uuid4()
INSERT INTO workflow_signal_inbox (id, workflow_id, signal_name, payload, status)
  VALUES (:id, :wfid, :sig, CAST(:payload AS jsonb), :status)   # payload = json.dumps(payload or {})
# Does NOT commit — caller owns the transaction boundary.
return row_id
```
**`mark_queued(db, row_id)`** (signal_inbox.py:65): `UPDATE workflow_signal_inbox SET status='queued' WHERE id=:id`. (Flip 'sent'→'queued' after a Temporal signal failure; preserves audit trail.)

---

## 5. ROUTER: webhooks.py — `router = APIRouter(prefix="/api/v1/webhooks", tags=["webhooks"])`

This router FIRES Temporal signals. Reproduce every branch.

### Helpers
**`_verify_signature(payload: bytes, signature: str, secret: str) -> bool`** (webhooks.py:38):
```
if not signature.startswith("sha256="): return False
expected = hmac.new(secret.encode(), payload, hashlib.sha256).hexdigest()
return hmac.compare_digest(f"sha256={expected}", signature)
```
**`_workflow_id_from_branch(branch) -> str | None`** (webhooks.py:55):
```
parts = GitService.parse_branch_name(branch)
if parts is None: return None
return f"{parts['line']}-{parts['app_id']}"
```
**`_gate_id_from_branch(branch) -> str | None`** (webhooks.py:67):
```
parts = GitService.parse_branch_name(branch)
if parts is None: return None
return parts["step"]
```
**`GitService.parse_branch_name(branch) -> dict | None`** (git_service.py:855) uses `BRANCH_PATTERN` (`olympus-contracts/.../git_types.py:14`):
```
BRANCH_PATTERN = re.compile(r"^olympus/(?P<line>[a-z][a-z0-9-]*)/(?P<app_id>[a-z0-9][a-z0-9-]*)/(?P<step>[a-z0-9][a-z0-9-]*)$")
# convention: olympus/{line}/{app_id}/{step}; returns groupdict {line, app_id, step} or None
```
**`find_portfolio_by_repo(repo_full_name) -> dict | None`** (portfolio.py:280): linear scan of in-memory `_portfolios.values()`, returns first record whose `artifact_repo_url == repo_full_name`, else None.

### ENDPOINT WH1 — POST /api/v1/webhooks/github (webhooks.py:84)
- **Method/Path**: `POST /api/v1/webhooks/github`
- **Auth/dependency**: NO RBAC. Authenticated by HMAC signature instead.
  - `config: AppConfig = Depends(get_config)`
  - `temporal: Client = Depends(get_temporal_client)`
  - `x_hub_signature_256: str = Header("")` (maps to header `X-Hub-Signature-256`)
  - `x_github_event: str = Header("")` (maps to header `X-GitHub-Event`)
- **Request body**: raw bytes (`await request.body()`), parsed as JSON (no Pydantic model).
- **Response**: `dict[str, Any]`; **status 200** (default). 401 raised on signature mismatch.
- Full handler logic (REPRODUCE EXACTLY — fires signals):
```
body = await request.body()
import json
payload: dict = json.loads(body)
action = payload.get("action", "")

# --- Multi-repo signature validation ---
repo_full_name = payload.get("repository", {}).get("full_name", "")
portfolio = find_portfolio_by_repo(repo_full_name)
secret = portfolio.get("webhook_secret","") if portfolio else config.github_webhook_secret
if secret:
    if not _verify_signature(body, x_hub_signature_256, secret):
        raise HTTPException(status_code=401, detail="Invalid webhook signature")
result = {"received": True, "event": x_github_event, "action": action}

# --- Branch A: pull_request_review submitted ---
if x_github_event == "pull_request_review" and action == "submitted":
    review = payload.get("review", {})
    state = review.get("state","").lower()
    pr = payload.get("pull_request", {})
    branch = pr.get("head", {}).get("ref", "")
    reviewer = review.get("user", {}).get("login", "unknown")
    workflow_id = _workflow_id_from_branch(branch)
    gate_id = _gate_id_from_branch(branch)
    if workflow_id and gate_id:
        try:
            handle = temporal.get_workflow_handle(workflow_id)
            if state == "approved":
                await handle.signal("gate_approved", {"gate_id": gate_id, "approved_by": reviewer, "justification": review.get("body","")})
                result["signal"] = "gate_approved"
            elif state == "changes_requested":
                await handle.signal("gate_rejected", {"gate_id": gate_id, "rejected_by": reviewer, "reason": review.get("body","")})
                result["signal"] = "gate_rejected"
        except RPCError as exc:
            logger.warning("Temporal signal failed for workflow %s: %s", workflow_id, exc)
            result["signal_error"] = str(exc)
        result["workflow_id"] = workflow_id
        result["gate_id"] = gate_id

# --- Branch B: pull_request closed ---
elif x_github_event == "pull_request" and action == "closed":
    pr = payload.get("pull_request", {})
    merged = pr.get("merged", False)
    branch = pr.get("head", {}).get("ref", "")
    merger = pr.get("merged_by", {}).get("login", "unknown") if merged else ""
    workflow_id = _workflow_id_from_branch(branch)
    gate_id = _gate_id_from_branch(branch)
    if merged and workflow_id and gate_id:
        try:
            handle = temporal.get_workflow_handle(workflow_id)
            await handle.signal("gate_approved", {"gate_id": gate_id, "approved_by": merger, "justification": "PR merged"})
            result["signal"] = "gate_approved"
        except RPCError as exc:
            logger.warning("Temporal signal failed for workflow %s: %s", workflow_id, exc)
            result["signal_error"] = str(exc)
        result["workflow_id"] = workflow_id
        result["gate_id"] = gate_id

logger.info("Processed GitHub webhook: %s/%s", x_github_event, action)
return result
```
⚠️ GOTCHAs:
- **Signal names fired**: `"gate_approved"` (on review state `approved`, and on PR merge) and `"gate_rejected"` (on review state `changes_requested`). These are the Temporal workflow signal handlers consumed by the gate-awaiting workflows.
- **Payload shapes differ per path**: `gate_approved` from review uses key `justification`; `gate_rejected` uses `reason`; merge `gate_approved` uses `justification: "PR merged"`. Approver field: `approved_by`/`rejected_by` set to reviewer login (review) or merger login (merge), defaulting to `"unknown"`.
- **Signature optional-by-config**: if no `secret` (no portfolio match AND empty global `config.github_webhook_secret`), signature check is SKIPPED entirely — request proceeds unauthenticated. Multi-repo: per-portfolio `webhook_secret` wins over global.
- **Workflow-not-found is non-fatal**: `RPCError` from `get_workflow_handle`/`signal` is caught, logged, and recorded as `result["signal_error"]`; the endpoint still returns 200 with the dict.
- **No signal fired** when `workflow_id`/`gate_id` is None (non-Olympus branch) or, for Branch B, when `merged` is False (PR closed without merge). `result` then omits `signal`/`workflow_id`/`gate_id`.
- `workflow_id` derived as `{line}-{app_id}`; `gate_id` is the `{step}` branch segment.
