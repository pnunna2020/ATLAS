# 09 — Regeneration Order (THE CAPSTONE)

> **ATOMIC regeneration spec — the dependency-correct rebuild plan.** Premise: the codebase
> is deleted; the `regen/` spec set is the only surviving artifact. This file is the
> **capstone**: the order in which to rebuild the ENTIRE Olympus system from the other regen
> docs such that, followed alone, it reconstructs the platform end-to-end with no forward
> dependencies — never building a thing before the thing it imports/needs exists.
>
> **How to use this file.** Execute the phases **top to bottom**. Each phase names: (a) **what
> to build**, (b) the **regen doc(s)** that fully specify it, (c) what it **DEPENDS ON** (must
> already be green), and (d) its **PROOF GATE** — the exact command / test / behavioral
> assertion that proves the phase is faithful before you advance. Do not advance past a phase
> whose proof gate is red. The order is derived from the verified inter-package import graph
> (`00-overview.md` §4) and the bring-up sequence (`00b-environment.md` §8).
>
> **Repo root:** `/Users/pnunna/Documents/GitHub/foundry`. ⚠️ IGNORE `/.claude/worktrees/`.
> Citations are `path:line` or `regen/<doc>` references.
>
> **Vocabulary.** "Green" = the phase's proof gate passes. "Spine" = the canonical regen ordering
> the prompt anticipated; this file confirms and instantiates it with proof gates.

---

## 0. The spine in one breath (then the detail)

```
P0 environment substrate  →  P1 contracts (olympus-contracts)  →  P2 JSON schemas
   →  P3 data layer (alembic)  →  P4 framework registries (6 extension points)
   →  P5 FAA profile + loaders  →  P6 agent runtime + skill registry/skills
   →  P7 activities  →  P8 workflows + LineWorkflowBase  →  P9 generation engine (Ralph Loop)
   →  P10 olympus-api  →  P11 olympus-cli + mcp-server  →  P12 dashboard
   →  P13 CI / anti-drift gates  →  P14 END-TO-END behavioral-parity proof
```

⚠️ **GOTCHA — the build graph is NOT the boot graph.** Two different orderings coexist and
must not be conflated:
- **Build/import order** (what depends on what at import time): `olympus-contracts` →
  `olympus-workflows` (`temporal/`) → {`olympus-worker`, `olympus-api`, `olympus-mcp-server`}
  → {`olympus-agent-runtime`, `olympus-cli`, `dashboard`} (`00-overview.md` §4.3). The agent
  runtime / cli / dashboard have **HTTP-only** edges (no Python import) so they can be authored
  in parallel once the API *contract* is fixed.
- **Runtime/boot order** (what must be up before what at runtime): postgres → db-init →
  db-migrate → temporal-server → namespace-init → {api, worker, mcp} → {dashboard, agent-runtime
  pool, agent LB} (`00b-environment.md` §1, the `depends_on` conditions).

This capstone follows the **build/import order** for phases P1–P12 (you cannot test a worker
without the workflows it hosts), then asserts the **boot order** at P14. The DB schema
(P3) is a *runtime peer* that no package imports but every service touches; it is sequenced
early because every persistence proof needs it.

⚠️ **GOTCHA — three external/private prerequisites gate P4 onward** (`00-overview.md` §6,
`00b-environment.md` §0). `foundry-temporal>=1.3.0` and `foundry-strands-agents>=0.4.0` are
**not in this repo** and **not on public PyPI**; `olympus-contracts` IS in this repo (P1) but is
*also* shipped as a vendored wheel. All three live in `vendor/wheels/` (exactly 3 wheels:
`foundry_strands_agents-0.4.0`, `foundry_temporal-1.3.0`, `olympus_contracts-0.3.0`) as the
local-dev fallback before pip reaches `PIP_EXTRA_INDEX_URL` (Artifactory). **The behavior of
`foundry_temporal` / `foundry_strands_agents` is OUT OF SCOPE for these regen docs** — they
must be sourced from the foundry monorepo. `foundry_temporal` provides `@foundry_activity`
(`regen/03b-activities/line_transitions-0-helpers-decorator.md` §0), `HILSignalsMixin`
(`regen/03-workflows/_HILSignalsMixin.md`), `create_worker_with_defaults`, `FoundryWorkerConfig`,
and the logging/error substrate. You CANNOT pass P8 (workers register workflows) without these.

---

## PHASE P0 — Environment substrate (containers, volumes, bring-up, NO app logic)

- **Build:** `docker-compose.yml` (13 services, 4 named volumes), `Makefile` (24 targets),
  `.env.example`, the 5 service `Dockerfile`s + `db/Dockerfile` + `dashboard/Dockerfile`,
  `db/init/01-create-databases.sh`, `infra/temporal/dynamicconfig.yaml` (blobSize override),
  `infra/haproxy/agent-lb.cfg`, `vendor/wheels/` (the 3 fallback wheels), `scripts/seed_*`
  + `scripts/demo_smoke.py` + `scripts/seed_service_tokens.py`.
- **Driver docs:** `regen/00-overview.md` (repo map, §3 topology, §4 dep graph, §6 private deps),
  `regen/00b-environment.md` (every service/env/volume/Make target, §8 from-zero runbook).
- **Depends on:** nothing (this is the floor). The container *images* will fail to build until
  their package source exists (P1+), so at P0 you build only the **non-application** scaffolding:
  compose file, Dockerfiles, init scripts, env, vendored wheels, Make targets, seed/smoke scripts.
- **PROOF GATE (substrate only, no app):**
  1. `docker compose config` parses clean and lists exactly **13 services** + **4 volumes**.
  2. `docker compose up -d postgres redis localstack temporal-server temporal-namespace-init temporal-ui`
     reaches: `postgres` healthy → `db/init/01-create-databases.sh` created DBs `olympus`,
     `temporal`, `temporal_visibility` (psql `\l` shows all three); `temporal-server` healthy;
     `temporal-namespace-init` exits 0 having pinned `default` retention to **720h**
     (`temporal operator namespace describe -n default | grep RetentionTtl` shows 720h0m0s);
     Temporal UI reachable at `:8080`.
  3. `make help` prints all 24 `##`-annotated targets.
- ⚠️ GOTCHAs to reproduce (else later phases mis-boot): bootstrap DB is `postgres` NOT `olympus`
  (`00b §1.1`); `db/init` runs ONLY on empty data dir (`00b §4`); the agent LB healthcheck uses
  `127.0.0.1` not `localhost` (alpine IPv6, `00b §1.12`); `--scale olympus-agent=8` scales the
  **LB** not the runtime pool — the pool scales via `AGENT_REPLICAS`/`--scale olympus-agent-runtime`
  (`00b §3.3`); blobSize raised 2→4 MiB or Discovery terminates on large gate evidence (`00b §3.4`).

---

## PHASE P1 — `olympus-contracts` (the universal base)

- **Build:** the `olympus-contracts` package — `enums.py` (8 enums + 2 lookup tables + 2 resolvers),
  `signals.py` (3 Temporal signal dataclasses), `git_types.py` (BRANCH_PATTERN + 4 dataclasses +
  `GitServiceError`), `errors.py` (3 merge-error subclasses), `assembly_lines.py` (THE LOADER: 9
  frozen dataclasses + YAML→dataclass pipeline + query API + load invariants), `__init__.py`
  re-export surface, `pyproject.toml` (incl. the `package-data` YAML stanza), and the **10
  authoritative line YAMLs** under `olympus_contracts/data/assembly-lines/`.
- **Driver docs:** `regen/06-contracts.md` (entry: enums/signals/git_types/errors/loader +
  anti-drift tests) and `regen/06-contracts/*.md` (the 10 per-line `<line>-steps.md` reproducing
  each YAML field-by-field; `schemas-inventory.md` is consumed in P2).
- **Depends on:** P0 (Python 3.11+ toolchain present). **No internal package dependency** —
  only `pyyaml>=6.0`.
- **PROOF GATE:**
  1. `python -c "import olympus_contracts; print(olympus_contracts.__version__)"` prints **`0.2.0`**
     (⚠️ NOT 0.3.0 — `__init__.py:62` vs `pyproject.toml:6` disagree; **reproduce the drift**, do
     not unify — `regen/06-contracts.md:101`).
  2. `from olympus_contracts import list_lines; assert len(list_lines()) == 10` and
     `get_line("discovery")` / `get_step(...)` / `skill_for_step(...)` resolve; the loader raises
     `RuntimeError("no assembly-line contracts found …")` if the YAML package-data is missing
     (proves the `package-data` stanza is correct — `06-contracts.md:87`).
  3. The contracts test suite is green: `cd olympus-contracts && pytest`
     (`tests/test_assembly_lines.py`, `tests/test_no_hardcoded_step_lists.py`,
     `tests/test_skill_manifest.py`). ⚠️ No coverage floor on this package (`00-overview.md §8`).
- ⚠️ GOTCHAs: hard-requires Python ≥3.11 (`StrEnum` + `dataclass(slots=)` — import fails on 3.9/3.10,
  `06-contracts.md:84-86`); `step_weights` is in `__init__.__all__` but NOT
  `assembly_lines.__all__`; `EntityNotFound`-style errors double-quote via `KeyError.__str__`
  (relevant once registries import this in P4).

---

## PHASE P2 — JSON Schemas (`schemas/` + `olympus-contracts/schemas/`)

- **Build:** all **86 `*.schema.json`** (84 under `schemas/` + 2 under `olympus-contracts/schemas/`)
  and **24 `*.sample.json`** = 110 JSON files, plus `schemas/validate.sh`.
- **Driver doc:** `regen/06-contracts/schemas-inventory.md` (every `$id`, dialect, `title`,
  `required`, top-level shape; the two validation code paths; the `$id`-host inconsistencies).
- **Depends on:** P0 (for `make validate-schemas`), P1 (the 2 contracts-side schemas ship with the
  contracts tree). Schemas are otherwise free-standing JSON.
- **PROOF GATE:**
  1. `make validate-schemas` passes (`schemas/validate.sh`: presence of `$schema`/`$id`/`title`/
     `description` on each schema; samples valid JSON with a `$schema` key).
  2. CI-equivalent metaschema check passes: `check-jsonschema --check-metaschema schemas/**/*.schema.json`
     (covers all 84 — every schema is exactly one level deep) AND the 24 samples validate against
     their `$id`-keyed schemas via `Draft202012Validator` + `RefResolver`.
- ⚠️ GOTCHAs (load-bearing for `$ref` resolution): FOUR distinct `$id` hosts coexist
  (`olympus.framework` ×68, `olympus.faa.gov` ×3, `olympus.dev` ×2, no-host ×14) + 24 hostless
  samples; TWO dialects (2020-12 ×69, draft-07 ×17). `make validate-schemas` ≠ CI: the local
  loop **omits `schemas/design/`** (6 schemas never touched locally); one sample
  (`disposition-recommendation.sample.json`) has no `$schema` and is silently skipped by CI.
  Name collision: `discovery/business-logic.schema.json` exists under BOTH roots with different
  `$id`/`required`/shape — do not merge.

---

## PHASE P3 — Data layer (`db/alembic`, the derived query schema)

- **Build:** the Alembic project `db/alembic/` — **65 migration files** (`001`–`054`, then
  **`055` intentionally absent**, then `056`–`066`; head = **`066`**), `env.py`, `alembic.ini`,
  `script.py.mako`, `db/requirements.txt`, `db/seeds/initial-data.sql`. Creates **13 enum types**
  (12 in `001` + `archetype_enum` in `021`) and **53 tables**.
- **Driver docs:** `regen/04-data-layer.md` (SPINE: enums, the 65-migration DAG ledger, the
  Git→PG projection model, seeds) + `regen/04-data-layer-core-tables.md`,
  `-workflow-tables.md`, `-rationalization-tables.md`, `-sweep-tables.md`, `-platform-tables.md`
  (column-by-column specs for 48 of 53 tables).
- **Depends on:** P0 (postgres + db-init created the `olympus` DB). The migrations use the
  **synchronous psycopg2** driver (asyncpg is the app driver). No package import edge.
- **PROOF GATE:**
  1. `docker compose up db-migrate` exits 0; `alembic current` == **`066`** (head).
  2. `\dT` lists all **13** enum types; `gate_status_enum` has 7 values in sort order
     `pending, approved, rejected, overridden, escalated, preparing, merge_blocked` (proves the 3
     `ALTER TYPE … ADD VALUE` migrations ran in revision order 013→019→040).
  3. `\dt` lists all **53** tables; `056.down_revision == "054"` confirms the `055` gap;
     `039` has 4 parents (`"034","035","037","038"`).
  4. `sql-schema-drift` CI job is green (SQL ↔ alembic consistency).
  5. Seeds load: `db/seeds/initial-data.sql` applies clean (data-only baseline).
- ⚠️⚠️ **GATE-9 FAIL — CARRY THESE FORWARD (`regen/_gate/gate9-data-layer-verification.md`).** The
  data-layer spec is FAIL on completeness: **5 tables have NO column-by-column spec** and MUST be
  rebuilt directly from their migration files (do not trust the spine prose for them):
  - `gate_approval` — `062_rbac_gate_approval.py:52-116` (8 cols, FK→gate CASCADE,
    `UNIQUE(gate_id,approved_by)`).
  - `skill_metrics` — `060_create_skill_metrics.py:53-96` (5 cols, PK `skill_id` String(150), no FK).
  - `viewer_event` — `061_create_viewer_event.py:58-123` (7 cols, two indexes).
  - `design_annotation` — `065_create_design_annotation.py:37-94` (10 cols + 2 CHECKs:
    `length(annotation_text)>0`; `action IN ('flag_for_revision','mark_reviewed','note_only')`).
  - `interview_session` — `066_create_interview_session.py:37-127` (14 cols + 2 CHECKs:
    `status IN ('active','completed','expired')`, `phase>=1 AND phase<=5` + 2 JSONB:
    `transcript` `'[]'`, `partial_artifact` `'{}'`).
  Also: the spine **prose** says "14 enum types / 13 in 001" — **WRONG, it is 13 total / 12 in 001**
  (the spine's own §1.1/§1.2 tables are correct; trust the tables). Build 13 enums, not 14.

---

## PHASE P4 — Framework: the 6 extension-point registries (`temporal/.../registries/`)

- **Build:** `temporal/olympus_workflows/registries/` — `engine.py` (shared `Registry[T]`
  substrate + errors + semver), the six registries (`assembly_line.py`, `disposition.py`,
  `analysis_pass.py`, `scoring_dimension.py`, `gate_provider.py`, `skill_composition.py`),
  `profile_overrides.py` (the single `apply_profile` seam), `worker_bootstrap.py`
  (`bootstrap_profile_from_env`), `__init__.py`, plus `registries/defaults/`. Also the package
  skeleton: `temporal/olympus_workflows/types.py`, `retry_policies.py`, `worker.py` (which will
  export `ALL_WORKFLOWS`/`ALL_ACTIVITIES` once P7/P8 land), `utils/`.
- **Driver docs:** `regen/07-framework.md` PART A (the substrate + 6 registries +
  `profile_overrides` + `worker_bootstrap`, byte-for-byte) and PART B (line-to-line contract) /
  PART D (risk/disposition/gate models).
- **Depends on:** P1 (`olympus_contracts` — the registries' default loaders read the packaged
  line YAMLs at import: `assembly_line.py:156-178`, `analysis_pass.py:116-162`), and the external
  `foundry_temporal` (P0 vendored wheel) once `types.py`/workflows import it.
- **PROOF GATE:**
  1. `python -c "from olympus_workflows.registries import ASSEMBLY_LINE_REGISTRY, DISPOSITION_REGISTRY, ANALYSIS_PASS_REGISTRY, SCORING_DIMENSION_REGISTRY, GATE_PROVIDER_REGISTRY, SKILL_COMPOSITION_REGISTRY"`
     succeeds; the first five are **populated at import** (defaults loaded) and
     `SKILL_COMPOSITION_REGISTRY` is **empty** at import (no defaults — `skill_composition.py:194`).
  2. `parse_semver`/`bump_semver` behave per `engine.py:100-141` (incl. `lstrip("vV")` stripping
     all leading v/V; `-` stripped before `+`); `VersionRecord` validates eagerly in `__post_init__`.
  3. `cd temporal && pytest` exercises the registry tests; the
     `reset_registries_to_defaults` test path (re-`__init__` then re-register) works — proving the
     **no-freeze-flag** design was reproduced (`07-framework.md §A.0`).
- ⚠️ GOTCHA — the determinism contract is **procedural, not enforced**: defaults at import +
  `apply_profile` once at startup; there is NO lock/freeze boolean. A rebuild that adds a runtime
  guard breaks the reset test path and the API CRUD router — reproduce the no-flag design.
  `CircularDependencyError` is omitted from `engine.__all__` but re-exported from the package
  `__init__`. `VersionRecord` is the one mutable (non-frozen) structure, stored parallel to (never
  on) the frozen entities.

---

## PHASE P5 — FAA profile bundle + the 4 loaders

- **Build:** the `profiles/faa/` bundle (`profile.yaml`, `compliance.yaml`,
  `risk-classification.yaml`, `gates.yaml`, `scoring.yaml`, `technology.yaml`, `wave-planning.yaml`,
  `delegation.yaml`, `objectives.yaml`, `config/` 17 YAMLs, `skills/` 55 entries, `branding/`,
  `context-priors/`, `regulatory-knowledge/`, `baselines/2024.yaml`), `profiles/test-generic/`
  (portability), and the **4 loaders**: API typed loader+activation
  (`olympus-api/src/services/profile_loader.py` + `profile_activation.py`), worker minimal parser
  (`worker_bootstrap.py`, built in P4), mission-context loader
  (`olympus-agent-runtime/src/services/profile_context.py`), skill bootstrap
  (`olympus-api/src/services/skill_bootstrap.py`).
- **Driver docs:** `regen/07-framework-faa-profile.md` (PART C — field-level bundle + 4 loaders +
  CAN/CANNOT-override boundary). Note loaders 1 & 4 are authored with their host services (P6/P10)
  but the **bundle data + the worker loader contract** are validated here.
- **Depends on:** P1 (enums/contracts), P4 (`apply_profile` + registries the profile mutates),
  P2 (`objectives.yaml` validates against schema + registries).
- **PROOF GATE:**
  1. `make validate-objectives` passes (`profiles/*/objectives.yaml` against schema + registries).
  2. Worker-side bootstrap proof (no full worker yet): `OLYMPUS_PROFILE=faa` +
     `OLYMPUS_PROFILES_DIR=<repo>/profiles` → `bootstrap_profile_from_env()` runs `apply_profile`
     and the scoring/gate/skill-composition registries reflect FAA overrides; the skill-composition
     named `faa-profile-skills` exists.
  3. `make render-exec` renders the FAA objectives microsite (proves `objectives.yaml` + branding
     parse end-to-end); `make render-exec-generic` proves profile portability via `test-generic`.
- ⚠️⚠️ GOTCHA — **FOUR loaders, FOUR env-var conventions, NO shared code path/cache** (`07-faa §C.0`):
  loaders 1&2 take id `OLYMPUS_PROFILE` + parent `OLYMPUS_PROFILES_DIR`; loader 3 takes the dir
  itself in `OLYMPUS_PROFILE_ROOT`; loader 4 takes repo root in `SKILLS_ROOT`. Confusing them
  silently disables a facet (e.g. unset `OLYMPUS_PROFILE_ROOT` → agents lose SOO mission framing,
  but registries still override). Only **3 registries** actually mutate via `apply_profile`
  (scoring, gate, skill-composition); everything else (compliance/tiers/tech/SLA/objectives/
  branding) is data consumed by API/dashboard/prompts/microsite, not by workflow registries.

---

## PHASE P6 — Agent runtime + skill registry + skills (the A2A executor & its contract)

- **Build:** `olympus-agent-runtime/` (FastAPI A2A executor: `main.py`, `routers/a2a.py` +
  `health.py`, `services/{agent_executor,output_validator,model_selector,skill_loader,
  profile_context,task_recorder}.py`, `config/models.yaml` + `skill_mapping.yaml`); the worker-side
  dispatch plumbing it contracts with (`olympus-worker/src/agent_client.py`,
  `src/testing/mock_agent_runtime.py`, `src/config.py` — `AGENT_RUNTIME_MODE` gate); and the
  **skill content**: `cross-cutting/skills/` (167 registry entries / 178 core `SKILL.md`) +
  `cross-cutting/skills/registry.yaml` + per-skill `fixtures/` (mock-mode canned responses) +
  `profiles/faa/skills/` (15).
- **Driver docs:** `regen/02-agent-runtime.md` (the `execute_skill` 17-step pipeline +
  `build_system_prompt` 9-section envelope + model selection + 503 saturation + live/mock routing),
  `regen/skill-authoring-contract.md` (the standalone SKILL.md authoring contract),
  `regen/11-skill-registry.md` (the 167-skill INDEX + `output_schemas` contract) +
  `regen/11-skill-registry-wiring.md` (per-line step→skill→schema wiring).
- **Depends on:** P2 (skills validate outputs against `schemas/`; the runtime's `output_validator`
  resolves `schemas/...` via `OLYMPUS_SCHEMA_ROOT`), P5 (mission-context loader reads the FAA
  profile via `OLYMPUS_PROFILE_ROOT`). The runtime has **no Python import edge** to other packages
  — it HTTP-calls `olympus-api` (`SKILL_API_URL`) for skill lookup, which means **its `/a2a/tasks`
  pipeline can be unit-tested with fixtures before the API exists**, but its live skill-load path
  is proven in P10.
- **PROOF GATE:**
  1. `cd olympus-agent-runtime && pytest` green at the **90%** floor; the live-inference deps
     (`claude-agent-sdk`, `anthropic[bedrock]`) are the `agent` extra and are OMITTED from the test
     image (mock path exercised).
  2. Mock-runtime fixture proof (DECISION-018): every fixture under
     `cross-cutting/skills/<skill>/fixtures/` validates against that skill's pydantic contract **at
     test collection**. `skill-catalog` CI gate green (registry ↔ SKILL.md consistency; P4-S7.H1:
     every workflow-dispatched skill has a registry entry + a SKILL.md on disk).
  3. `build_system_prompt` emits the exact 9-section envelope (mission-first, feedback-last,
     sections 7+8 unconditional) — the contract every SKILL.md matches.
- ⚠️⚠️ GOTCHA — **two services, one contract** (`02 §0`): `AGENT_RUNTIME_MODE` lives in the
  **worker**, not the runtime; the runtime always executes via the Claude Agent SDK. Production
  refuses to start in mock mode (`MockInProductionError`). **`output_schemas` validation is DORMANT
  on the live API-load path** (`regen/.workflows/GATE5-verification-findings.md`): `SkillDetail` has no
  `output_schemas` field and the `skill` table has no such column (**21** fields/columns, not 22),
  so `data.get("output_schemas")` is always `None`→`[]` on the API path → A2A-dispatch validation
  short-circuits. `output_schemas` IS live-enforced via the human-paired-agent RETURN validator
  (`return_payload_validator.py`) for any of the ~35 declaring skills (the 6 Rationalization-line
  skills are the explicitly-swept set). Reproduce the dormancy exactly.

---

## PHASE P7 — Activities (`temporal/.../activities/`, ~57 functions)

- **Build:** all 16 activity files under `temporal/olympus_workflows/activities/` — agent dispatch
  (`agent_dispatch.py`), git ops (`git_operations.py`), gate ops (`gate_operations.py` +
  `gate_pre_review.py`), scoring (`scoring.py`), classification (`classification.py`), the
  projection/`persist_*` family (`line_transitions.py` — 8217 lines), wave ops
  (`wave_operations.py`), bundle activities (`bundle_activities.py`), artifact validation,
  arch/data registry signals, disposition outputs, governance/traceability, context priors.
- **Driver docs:** `regen/03b-activities/*.md` (21 files — the `@foundry_activity` decorator
  semantics in `line_transitions-0-helpers-decorator.md`; the projection model's shared SQL
  builders `_SIDE_EFFECT_COLUMNS`/`_JSONB_COLUMNS`/`_NATIVE_COLUMNS`/`_merge_application_metadata`/
  `_build_update_sql`; each `persist_*` column-mapping table).
- **Depends on:** P1 (contracts/enums/signals/errors), P3 (every `persist_*` writes the tables built
  in P3 — the projection target schema must exist), P4 (`types.py`/`retry_policies.py`), P6 (the
  agent-dispatch activity drives the runtime). External `foundry_temporal` (`@foundry_activity`,
  errors, logging) is required.
- **PROOF GATE:**
  1. `cd temporal && pytest` green at the **78%** floor (⚠️ artificially low/transitional —
     intended target ≥87; reproduce 78 but understand why, `00-overview.md §2.5`).
  2. **Projection round-trip proof:** each `persist_*` activity, given an artifact JSON, writes the
     exact `table.column` set its `regen/03b-activities/*` spec maps — GATE-4 verified PASS for ALL
     persist activities (`regen/03b-activities/GATE4-verification-line_transitions-persist.md`):
     every code-written column is present in a spec; the dynamic `_build_update_sql` whitelist
     iteration, the modernization per-row `bounded_context` assignments, and the sustainment
     per-app lifecycle UPDATE all reproduced.
  3. `@foundry_activity` error classification reproduced: `WorkflowError`/`ApplicationError`
     pass-through unchanged; `_is_retryable_error` → `RetryableError`; else `NonRetryableError`.
- ⚠️ GOTCHA — `@foundry_activity` is NOT `@activity.defn`: a plain rebuild loses observability
  logging + retryable/non-retryable classification (both mandatory). The config's timeout/retry
  fields are NOT forwarded to the activity def — timeouts/retries are set by the **workflow** at
  `execute_activity(...)` call time. Schema validation in `validate_artifact_against_schema`
  degrades to a warning (does not fail) if `OLYMPUS_SCHEMAS_DIR` is unset (`00b §1.9`).

---

## PHASE P8 — Workflows + `LineWorkflowBase` + `HILSignalsMixin` (18 workflows)

- **Build:** the 25 files under `temporal/olympus_workflows/workflows/` — `base.py`
  (`LineWorkflowBase`, the shared engine for the **seven** per-app line workflows), the routers
  (`architecture_patterns_router`, `code_generation_router`, `data_router`,
  `discovery_patterns_router`), and the 18 registered workflows: PortfolioWorkflow, WaveWorkflow,
  AppWorkflow, DiscoveryWorkflow, RationalizationWorkflow, WaveRationalizationWorkflow,
  WaveArchitectureWorkflow, ArchitectureWorkflow, DataWorkflow, ModernizationWorkflow,
  GenerateBCWorkflow, ValidationWorkflow, DeploymentWorkflow, DispositionWorkflow,
  SustainmentWorkflow, GovernanceWorkflow, SmokeTestAgentDispatchWorkflow, BundleReaperWorkflow.
  Then wire `temporal/olympus_workflows/worker.py` to export `ALL_WORKFLOWS` (18) + `ALL_ACTIVITIES`
  (~57), and build `olympus-worker/` (`src/worker.py` thin host, `agent_client.py`,
  `agent_registry.py`, `model_resolver.py`, `fallback_adapter.py`, `config/agents.yaml`).
- **Driver docs:** `regen/03-workflows/*.md` (32 files: `_LineWorkflowBase.md`, `_HILSignalsMixin.md`,
  and one per workflow, several split into multiple parts e.g. WaveRationalization ×6,
  Modernization ×2, Architecture ×2).
- **Depends on:** P7 (workflows `execute_activity` the P7 activities), P4 (`types.py`,
  `retry_policies.py`, registries), P1 (contracts/signals). External `foundry_temporal`
  (`HILSignalsMixin`, `create_worker_with_defaults`, `FoundryWorkerConfig`) required.
- **PROOF GATE:**
  1. `cd olympus-worker && pytest` green at the **90%** floor; `cd temporal && pytest -n auto`
     green (workflow suite runs `-n auto` — each `WorkflowEnvironment.start_time_skipping()` spawns
     a Rust sidecar; serial CI is 30+ min vs 6 min).
  2. **Worker registers all 18 workflows + ~57 activities:** boot `olympus-temporal-worker` against
     the live Temporal (P0) and assert in the Temporal UI that the worker is polling `olympus-main`
     with a derived identity `olympus-worker-olympus-main-<host>-<pid>`; `ALL_WORKFLOWS` has length
     18, `ALL_ACTIVITIES` ≈ 57 (`00b §3.6`).
  3. **Gate-signal determinism proof:** a `WaveRationalizationWorkflow` test where `gate_approved`
     fires BEFORE `create_gate_record` returns does NOT drop the signal (buffered via
     `_pending_signals_by_gate_id`) — the fixed signal race (`00-overview.md §2.5`).
- ⚠️ GOTCHA — `LineWorkflowBase` has the seven line-workflow inheritors; `WaveWorkflow` and
  `PortfolioWorkflow` inherit `HILSignalsMixin` **directly, NOT** `LineWorkflowBase`, and define
  their OWN `gate_approved`/`get_status` with different bodies (WaveWorkflow buffers a dict;
  LineWorkflowBase buffers a 5-tuple) — do not mix the surfaces
  (`regen/03-workflows/WaveWorkflow.md` GOTCHA-INHERIT). All `olympus_workflows.types`/activity
  imports MUST be inside `with workflow.unsafe.imports_passed_through():` or the Temporal sandbox
  re-executes them on replay. The child `GenerateBCWorkflow` is spawned with
  `task_queue=workflow.info().task_queue` → it MUST be on the same queue as its parent.

---

## PHASE P9 — Generation engine (Extract→Design→Generate + the Ralph Loop)

- **Build:** this is the behavioral core of two workflows already *registered* in P8 —
  `ModernizationWorkflow` (the Extract→Design→Generate factory + BC fan-out) and
  `GenerateBCWorkflow` (the Ralph Loop carrier) — plus `code_generation_router.select_code_generation_skill`.
  P8 stands them up structurally; **P9 is the proof gate that their loop/stop-condition behavior is
  faithful**, because this subsystem was absent from the prior spec and every claim is load-bearing.
- **Driver doc:** `regen/13-generation-engine.md` (every loop, stop-condition, branch, early-return,
  exception path; the trust boundary; the constants).
- **Depends on:** P8 (the workflows + base + activities). No new package.
- **PROOF GATE (GATE-7 verified PASS — `regen/_gate/gate7-generation-engine-verdict.md`):**
  1. Constants exact: `MAX_RALPH_ITERATIONS=10` (`types.py:134`), `MAX_BC_CHILDREN_PER_APP=12`
     (`types.py:133`, NOT the stale "5" in docstrings), `MAX_REWORK_ITERATIONS=3`
     (`modernization.py:190`).
  2. Ralph loop is `while self._iteration < 10` with `+=1` as the FIRST body statement → **exactly
     10 iterations** then escalate (do not off-by-one). Rework is strict `>` → a gate may be
     rejected 3× and still recover on the 4th.
  3. **Behavioral assertion (the spine of DONE):** a `GenerateBCWorkflow` test under
     `MockAgentRuntime` where `test-validation` reports `COMPLETED` with no error on iteration N
     returns success at N (the first such iteration); exhausting 10 iterations creates an escalation
     and blocks on the resolution signal; `ABANDON` → terminal `"abandoned"` that fails the parent.
- ⚠️⚠️ GOTCHA — **the single most important parity fact:** all three Ralph steps
  (tdd-generation, code-generation-*, test-validation) are **agent dispatches**; tests are "run" by
  the `test-validation` *agent*, not a real pytest subprocess. The loop trusts the agent's
  self-reported `status`. A rebuild that shells out to real pytest changes the behavior.

---

## PHASE P10 — `olympus-api` (the platform API; 225 + 6 endpoints)

- **Build:** `olympus-api/` — `src/main.py` (`create_app` factory: `_lifespan` activates the
  profile FATALLY then bootstraps skills + hydrates portfolios non-fatally; ordered middleware;
  **38 `include_router` calls**), `config.py`, `database.py`, `dependencies.py`,
  `startup_state.py`, `auth/`, `middleware/`, `models/`, the **36 router files**, the **43 service
  modules** (incl. `profile_loader`+`profile_activation` from P5, `skill_bootstrap` from P5, the
  scoring/gate/git_service logic).
- **Driver docs:** `regen/01-api.md` (INDEX: bootstrap + ordered router mount table + tally) +
  the 11 `regen/01-api-*.md` sibling files (per-endpoint detail) + `regen/01-api-services-logic.md`
  (scoring/gate/merge math, branch-complete).
- **Depends on:** P1 (contracts under `models/`,`services/`), P4 (`registries.py` router imports
  `olympus_workflows.registries`; `waves.py` imports `parse_agent_json`), P8 (`waves.py`/
  `governance.py` start workflows + signal gates via the Temporal client), P3 (the DB schema it
  queries via asyncpg/SQLAlchemy), P5 (profile activation at startup), P6 (skill lookup endpoint).
  External `foundry_temporal`. ⚠️ `bcrypt>=4.1,<6` used directly (passlib broken on Py3.13);
  `jsonschema` promoted dev→runtime for the strict return-payload validator.
- **PROOF GATE (GATE-8 verified PASS — `regen/_gate/gate8-api-surface-verdict.md`):**
  1. `cd olympus-api && pytest` green at the **87%** floor (integration suite excluded by default
     via `--ignore=tests/integration`; run it separately with real Postgres).
  2. **Endpoint surface complete:** the app exposes exactly **225 `@router.*` endpoints + 6
     secondary-router endpoints (231 path ops) + 1 WebSocket** (`/api/v1/events/ws`). ⚠️ A
     regenerator counting only `@router.*` under-builds by 6 — the 6 secondaries are
     `wave_gates_router` (1), `line_start_router` (3: architecture/data/modernization `/start`),
     `portfolio_profile_router` (2). Per-router counts must match the GATE-8 table.
  3. **Gate-signal → Temporal firing path** works end-to-end: `POST` approve/reject a gate →
     `send_gate_temporal_signal` fires `gate_approved`/`GateApprovedSignal` (reject→`gate_rejected`,
     merge_retry→`merge_retry`) to the workflow handle, incl. the G-DA dual-signal
     (`stakeholder_approved`/`StakeholderApprovedSignal(scope="g-da")`). Fire-and-forget; DB-commit
     THEN signal.
  4. `GET /health/ready` returns JSON `status=="ready"` once Temporal `check_health()` ok AND
     `get_skill_count()>0`. ⚠️ It ALWAYS returns HTTP 200 — readiness is in the JSON body, never
     the status code (`00b §5.5`).
- ⚠️ GOTCHA — middleware registration order is load-bearing (last-registered = innermost);
  `activate_profile()` failure at startup is FATAL (do not start half-configured) but
  skill-bootstrap/portfolio-hydrate DB failures are non-fatal. `_AUTH_SKIP_VERIFICATION` defaults
  true in dev (signature/exp/aud unverified); `DEV_AUTH_BYPASS=true` in compose bypasses auth
  entirely; `RATE_LIMIT_ENABLED=false` locally (dashboard fires 15-20 req/page-nav).

---

## PHASE P11 — `olympus-cli` + `olympus-mcp-server` (HTTP-only API consumers)

- **Build:** `olympus-cli/` (`olympus_cli/`: `main.py`, `api.py`, `bundle.py`, `skill_install.py`,
  `hashing.py`, `output.py`, `config.py` — a pure `httpx`+`click` client, **no `olympus_contracts`
  dep**) and `mcp-server/` (`olympus_mcp/`: `server.py`, `db.py`, `resources/`, `tools/` — imports
  `olympus_contracts` under `resources/`, does direct `asyncpg` DB reads, and HTTP-proxies the
  `olympus.api.*` tool family to `olympus-api`).
- **Driver docs:** covered structurally by `regen/00-overview.md §2.4/§2.6` (file inventories,
  console scripts, coverage floors). ⚠️ **No dedicated atomic regen doc exists for the CLI or MCP
  internals** — see §"Undetermined" below. The MCP resource/tool surface mirrors the read endpoints
  specified in `regen/01-api-*.md`.
- **Depends on:** P10 (both are HTTP clients of the API; MCP also reads the P3 DB directly), P1
  (MCP imports contracts).
- **PROOF GATE:**
  1. `cd mcp-server && pytest` green at the **90%** floor; the MCP server boots
     (`python3 -m olympus_mcp.server`), responds on `:3001`, and its `olympus.api.*` tools proxy a
     read to a live API.
  2. `cd olympus-cli && pytest` green (⚠️ **no coverage floor** — the only Python package without
     one); `olympus --help` lists the command surface; a fetch/accept/return human-paired-agent
     task round-trips against the API.
- ⚠️ GOTCHA — distribution name `olympus-mcp` but import package `olympus_mcp`; MCP requires
  Python ≥3.11 (lower than API/worker's 3.13). The CLI is standalone — do not give it a contracts
  dependency.

---

## PHASE P12 — `dashboard` (React + USWDS; 61 routes)

- **Build:** `dashboard/` — `main.tsx`/`App.tsx` (provider stack + QueryClient + the 61-route
  `<Routes>` block), `api/client.ts` (axios singleton + interceptors + the ~265 typed endpoint
  functions), the 26 page dirs, components, the USWDS design-token CSS, the chart/viewer subsystem,
  `scripts/parse-line-contracts.mjs` (generates frontend line-contract sequences).
- **Driver docs:** `regen/05-dashboard.md` (entry: route table + pages + state model + shell),
  `regen/05-dashboard-components.md` (component props/state catalog),
  `regen/05-dashboard-design-system.md` (USWDS tokens + axios client + fixtures).
- **Depends on:** P10 (consumes the API over HTTP/WS — `VITE_API_BASE_URL`/`VITE_WS_BASE_URL`;
  build-time it reads `docs/phase1-continuity-matrix.md`). **No Python edge.** Can be authored in
  parallel with P11 once the P10 contract is fixed.
- **PROOF GATE:**
  1. `cd dashboard && npm run lint` clean; `npm test` (Vitest) green; `npm run test:coverage`
     meets floors **lines 81 / branches 70 / functions 76 / statements 78**.
  2. `npm run build` (`tsc -b && vite build`) succeeds; `build:line-contracts`
     (`parse-line-contracts.mjs`) runs and the `line-contracts-consistency` CI job is green
     (frontend line contracts ↔ backend YAMLs).
  3. `npm run test:e2e` (Playwright, incl. `@visual`/`@layout`/`@a11y`) passes against a running
     stack: the dashboard renders the FAA portfolio, drills into an app, and approves a gate.
- ⚠️ GOTCHA — `VITE_*` vars are **browser-facing** (`localhost`) while `API_URL` is the in-network
  name; they MUST differ. The dashboard runs as a **Vite dev server** locally (HMR via bind-mounted
  `src`), not a prod build. The root `package.json` is the **demo-recording Playwright harness, NOT
  the dashboard** (different React version) — do not conflate.

---

## PHASE P13 — CI / anti-drift gates (the consistency harness that keeps regen faithful)

- **Build:** `.github/workflows/ci.yml` (jobs: `preflight`, `branch-naming`, `contracts`,
  `skill-catalog`, `agency-objectives`, `step-registry-consistency`, `sql-schema-drift`,
  `line-contracts-consistency`, `profile-portability`, `python` matrix per-package), plus
  `deploy.yml`, `pages-publish-traceability.yml`, `traceability-check.yml`, and the per-package
  ruff configs.
- **Driver doc:** `regen/08-build-ci.md` (the authoritative CI/build spec — §0 inventory of all 5
  workflow files, §1 the full per-job `ci.yml` graph, §2 the coverage-floor table, §4 schema
  validation, §5 anti-drift guards, §6 `deploy.yml` / `branch-protection-sync.yml` /
  `pages-publish-traceability.yml` / `traceability-check.yml`), supplemented by
  `regen/00b-environment.md §5-6` for the Make targets and seeds/smoke/tokens.
- **Depends on:** P1–P12 (CI runs every package's tests + the cross-cutting consistency checks; it
  cannot be green until all packages build).
- **PROOF GATE:**
  1. A full CI run is green: every per-package `python` matrix leg meets its coverage floor
     (api 87, worker 90, agent-runtime 90, mcp 90, temporal 78, dashboard 81/70/76/78; cli + contracts
     have none); `contracts`, `skill-catalog`, `agency-objectives`, `step-registry-consistency`,
     `sql-schema-drift`, `line-contracts-consistency`, `profile-portability` all pass.
  2. `branch-naming` accepts `phase-*/`,`feat/`,`fix/` and rejects others.
- ⚠️ GOTCHA — **coverage floors only move UP, never down** (DECISION-017). Lowering a floor to
  unblock a PR is not an option; reproduce the **exact committed** numbers (several are
  transitional/artificially low — temporal 78 vs target ≥87). The `profile-portability` job runs the
  `test-generic` profile integration test — proves the framework is profile-agnostic.

---

## PHASE P14 — END-TO-END behavioral-parity proof (the DONE gate)

- **Build:** nothing new — this phase **proves the whole assembly works together** by booting the
  full stack and running the canonical FAA demo path.
- **Driver docs:** `regen/00b-environment.md §8` (from-zero runbook),
  `specifications/demo-golden-path.md` (the seed/recorder contract + app-state coverage).
- **Depends on:** P0–P13 (everything).
- **PROOF GATE — `make demo-up` reaches smoke-pass:**
  1. `cp .env.example .env` (fill `GITHUB_TOKEN`, ensure `~/.aws` for Bedrock), then `make demo-up`:
     `docker compose up -d --scale olympus-agent=8` → postgres init (3 DBs) → `db-migrate`
     001→066 → temporal auto-setup + retention 720h → api/worker/mcp/dashboard/agent-runtime/LB up
     → `demo-wait` (poll `/health/ready` HTTP 200) → `demo-seed` (`seed_all.py --reset`: FAA "Test
     Portfolio 4" ~19 apps + "Modernization Corpus" 14 apps) → **`demo-smoke` exits 0** (asserts
     `/health/ready` JSON `status=="ready"` AND both portfolios have apps).
  2. UIs reachable: dashboard `:3000`, API `:8000` (`/docs`), Temporal UI `:8080`.

See §DONE below for the full behavioral-parity definition this gate instantiates.

---

## A. CRITICAL-PATH GRAPH (dependency edges between phases)

Arrows mean **"must be green before"**. Read top-to-bottom; a node may not start until ALL its
in-edges are satisfied.

```
                         ┌─────────────────────────────────────────────────────┐
                         │  P0  ENVIRONMENT SUBSTRATE                            │
                         │  (compose, Dockerfiles, db-init, vendored wheels,     │
                         │   Make targets, seeds/smoke) — postgres+temporal up   │
                         └───────────────────────────┬─────────────────────────┘
                                                     │
                 ┌───────────────────────────────────┼───────────────────────────────┐
                 ▼                                   ▼                                   │
        ┌─────────────────┐                 ┌─────────────────┐                         │
        │ P1 CONTRACTS    │                 │ P3 DATA LAYER   │ (needs only P0's        │
        │ olympus-contracts│◄────────┐      │ db/alembic 001→ │  olympus DB; no import) │
        │ (pyyaml base)   │          │      │ 066, 13 enums,  │                         │
        └───────┬─────────┘          │      │ 53 tables       │                         │
                │                    │      └───────┬─────────┘                         │
                ▼                    │              │                                   │
        ┌─────────────────┐          │              │   (P2 schemas: needs P0+P1)       │
        │ P2 JSON SCHEMAS │          │              │   ┌─────────────────┐             │
        │ 86 schemas+24   │──────────┼──────────────┼──►│ used by P6,P7   │             │
        │ samples         │          │              │   └─────────────────┘             │
        └───────┬─────────┘          │              │                                   │
                │                    │              │                                   │
                ▼                    │              │                                   │
        ┌─────────────────┐          │              │                                   │
        │ P4 FRAMEWORK    │  imports olympus_contracts (P1) + foundry_temporal (P0 wheel)│
        │ 6 registries +  │          │              │                                   │
        │ types/retry     │          │              │                                   │
        └───────┬─────────┘          │              │                                   │
                │                    │              │                                   │
                ▼                    │              │                                   │
        ┌─────────────────┐          │              │                                   │
        │ P5 FAA PROFILE  │  apply_profile→P4 registries; objectives→P2 schemas         │
        │ + 4 loaders     │          │              │                                   │
        └───────┬─────────┘          │              │                                   │
                │                    │              │                                   │
                ▼                    │              │                                   │
        ┌─────────────────┐          │              │                                   │
        │ P6 AGENT RUNTIME│  outputs→P2 schemas; mission ctx→P5; HTTP→API(P10)           │
        │ + skills/registry│         │              │                                   │
        └───────┬─────────┘          │              │                                   │
                │                    │              │                                   │
                ▼                    ▼              ▼                                    │
        ┌──────────────────────────────────────────────────┐                           │
        │ P7 ACTIVITIES  (~57)                               │                          │
        │  needs: P1 contracts, P3 schema (persist_*),       │                          │
        │         P4 types/retry, P6 dispatch target,        │                          │
        │         foundry_temporal (@foundry_activity)       │                          │
        └───────────────────────────┬──────────────────────┘                           │
                                     ▼                                                   │
        ┌──────────────────────────────────────────────────┐                           │
        │ P8 WORKFLOWS (18) + LineWorkflowBase + HILMixin    │                          │
        │  worker.py exports ALL_WORKFLOWS/ALL_ACTIVITIES    │                          │
        │  needs: P7 activities, P4, P1, foundry_temporal    │                          │
        └───────────────────────────┬──────────────────────┘                           │
                                     ▼                                                   │
        ┌──────────────────────────────────────────────────┐                           │
        │ P9 GENERATION ENGINE (Ralph Loop)                  │                          │
        │  behavioral proof of Modernization/GenerateBC (P8) │                          │
        └───────────────────────────┬──────────────────────┘                           │
                                     ▼                                                   │
        ┌──────────────────────────────────────────────────┐                           │
        │ P10 olympus-api (225+6 endpoints)                  │◄─────────────────────────┘
        │  needs: P1, P3(schema), P4(registries),            │  (P3 schema queried at runtime)
        │         P5(activation), P6(skill lookup),          │
        │         P8(start/signal workflows)                 │
        └─────────────┬───────────────────────┬─────────────┘
                      │                        │
                      ▼                        ▼
        ┌─────────────────────┐     ┌─────────────────────┐
        │ P11 CLI + MCP-SERVER │     │ P12 DASHBOARD        │
        │ HTTP clients of API  │     │ HTTP/WS client of API│
        │ (MCP also reads P3)  │     │ (no Python edge)     │
        └─────────────┬────────┘     └──────────┬──────────┘
                      │                          │
                      └────────────┬─────────────┘
                                   ▼
                         ┌─────────────────────┐
                         │ P13 CI / ANTI-DRIFT │  runs every package's tests + consistency
                         │ (needs P1..P12)     │  gates (schema/skill/step/sql/line/profile)
                         └──────────┬──────────┘
                                    ▼
                         ┌─────────────────────────────────────────────┐
                         │ P14 END-TO-END  `make demo-up` → smoke-pass  │
                         │ FAA wave runs; gates signal; artifacts        │
                         │ commit→Git & project→PG; Ralph generates a BC │
                         └─────────────────────────────────────────────┘
```

**Parallelism the graph permits** (independent once their in-edges are green):
- P2 (schemas) and P3 (data layer) can proceed concurrently after P0/P1 (P3 needs only P0's DB +
  P1 is not a hard import for migrations).
- P6 (agent runtime + skills) can be authored/tested with fixtures any time after P2+P5 — its
  Python has no import edge to P7/P8; only its *live* skill-load path waits for P10.
- P11 (cli/mcp) and P12 (dashboard) are siblings off P10 — both pure HTTP consumers.

---

## B. DONE — the behavioral-parity test (NOT a coverage threshold)

The rebuild is **faithful** when the following concrete end-to-end behavior reproduces on a clean
machine. This is the union of the P9 + P14 proof gates expressed as one observable scenario; it is
the canonical FAA demo path (`specifications/demo-golden-path.md`, `regen/00b-environment.md §8`).

> **DONE ≡** From `git clone` → `cp .env.example .env` → `make demo-up`, the stack boots
> (postgres creates `olympus`/`temporal`/`temporal_visibility`; alembic migrates `001`→`066`;
> Temporal `default` namespace pinned to 720h; api/worker/mcp/dashboard/agent-runtime/LB all
> healthy), and:
>
> 1. **The FAA profile loads and activates.** API startup `activate_profile()` succeeds (FATAL if
>    not); the worker's `bootstrap_profile_from_env()` applies FAA overrides to the scoring/gate/
>    skill-composition registries before accepting tasks; agents receive the SOO mission context.
>    `GET /api/v1/profiles` enumerates the bundle; `GET /health/ready` returns JSON
>    `status=="ready"` (Temporal healthy AND skill_count>0).
>
> 2. **`demo-smoke` passes** — both seeded portfolios ("Test Portfolio 4" ~19 FAA apps, and
>    "Modernization Corpus" 14 onboarded apps) exist and have applications; the dashboard at `:3000`
>    renders them and drills into an app + a gate.
>
> 3. **A wave runs the assembly-line flow.** Starting a wave drives
>    `WaveRationalizationWorkflow` (cross-portfolio redundancy → fan-out disposition recs → per-app
>    synthesis → gate staging) then `WaveWorkflow` (fan-out one `AppWorkflow` per app under the
>    concurrency semaphore with failure isolation), which runs Discovery →
>    {Architecture/Data → Modernization → Validation → Deployment, or Disposition Execution} per the
>    line-to-line contract. Lines hand off **versioned, schema-validated artifacts**.
>
> 4. **Gates signal via Temporal.** Approving/rejecting a gate in the dashboard/API fires the
>    correct signal (`gate_approved`/`GateApprovedSignal`, `gate_rejected`/`GateRejectedSignal`,
>    `merge_retry`/`GateMergeRetrySignal`, the G-DA dual `stakeholder_approved`) to the workflow
>    handle; the workflow advances (merge on approval, rework-loop on rejection up to 3 recoverable
>    rejections). Signals fired before the gate record exists are buffered, not dropped.
>
> 5. **Artifacts commit to Git and project to PG identically.** Each line's `commit-artifacts`/
>    `create-pr` git activities write artifacts to the Git artifact repo (branch-per-task, PR-as-
>    gate), and the matching `persist_*` activity projects the artifact JSON into the **exact
>    `table.column` set** its spec maps (GATE-4 PASS). PG is a faithful, rebuildable projection of
>    Git — dropping `postgres-data` and re-running the workflows re-projects every row.
>
> 6. **The Ralph Loop generates a bounded context that passes test-validation.** In Modernization's
>    Generate phase, `ModernizationWorkflow` fans out one `GenerateBCWorkflow` per bounded context
>    (≤12), each running `while iteration < 10`: write tests (tdd-generation) → generate code
>    (code-generation-*) → run tests (test-validation, an **agent**, not a real pytest), returning
>    success the first iteration `test-validation` reports `COMPLETED` with no error; on exhausting
>    10 iterations it escalates and blocks on a human resolution signal (`ABANDON` → terminal
>    "abandoned" fails the parent).
>
> When all six reproduce — profile activation, smoke-pass, the wave pipeline, Temporal gate
> signalling, Git↔PG projection equivalence, and a Ralph-generated BC reaching test-validation
> success — the rebuild has **behavioral parity** with the original Olympus, regardless of any
> per-package coverage number.

⚠️ **Caveat carried from the gate verdicts.** Behavioral parity for the DONE scenario does NOT
require the 5 GATE-9 tables (P3) to come from a regen prose spec — that gap must be closed from the
**migration source files** directly (see §Undetermined). The CI surface (P13) IS fully specified by
the authoritative `regen/08-build-ci.md` (per-job `ci.yml` graph, coverage floors, schema
validation, anti-drift guards, deploy/branch-protection/traceability workflows). The DONE scenario
also runs in **mock** agent mode for CI (`MockAgentRuntime` + fixtures, DECISION-018); the *live*
Bedrock path (real inference) is an environmental prerequisite (`~/.aws`, `CLAUDE_CODE_USE_BEDROCK`),
not a regeneration artifact.

---

## C. Regen-doc placement ledger (every doc in the set, mapped to a phase)

| Regen doc | Phase(s) placed |
|---|---|
| `00-overview.md` | P0 (repo map, topology, dep graph, private deps) + P13 (CI surface §7) |
| `00b-environment.md` | P0 (bring-up, services, env, volumes) + P13 (Make/seeds §5-6) + P14 (§8 runbook) |
| `06-contracts.md` + `06-contracts/<10 line>-steps.md` | P1 |
| `06-contracts/schemas-inventory.md` | P2 |
| `04-data-layer.md` + `04-data-layer-{core,workflow,rationalization,sweep,platform}-tables.md` | P3 |
| `_gate/gate9-data-layer-verification.md` | P3 (FAIL gaps carried) |
| `07-framework.md` (PART A/B/D) | P4 |
| `07-framework-faa-profile.md` (PART C) | P5 |
| `02-agent-runtime.md` + `skill-authoring-contract.md` | P6 |
| `11-skill-registry.md` + `11-skill-registry-wiring.md` | P6 |
| `.workflows/GATE5-verification-findings.md` | P6 (output_schemas dormancy) |
| `03b-activities/*.md` (21 files) | P7 |
| `03b-activities/GATE4-verification-line_transitions-persist.md` | P7 (projection PASS) |
| `03-workflows/*.md` (32 files incl. `_LineWorkflowBase`, `_HILSignalsMixin`) | P8 |
| `13-generation-engine.md` | P9 |
| `_gate/gate7-generation-engine-verdict.md` | P9 (Ralph PASS) |
| `01-api.md` + `01-api-*.md` (11) + `01-api-services-logic.md` | P10 |
| `_gate/gate8-api-surface-verdict.md` | P10 (225+6 PASS) |
| `05-dashboard.md` + `05-dashboard-components.md` + `05-dashboard-design-system.md` | P12 |
| `08-build-ci.md` | P13 (per-job `ci.yml` graph, coverage floors, schema validation, anti-drift, deploy/branch-protection/traceability) |

**Docs NOT in the set but named by the task / required by a phase:**
- `olympus-cli` / `mcp-server` internal atomic specs — **do not exist**; P11 sourced from
  `00-overview.md §2.4/§2.6` + the API read surface in `01-api-*.md`.

---

## D. Undetermined / open items (flag, do not invent)

1. **No dedicated CLI or MCP-server atomic spec.** `olympus-cli/` and `mcp-server/` internals are
   only inventoried (files, console scripts, coverage floors) in `00-overview.md §2.4/§2.6`, not
   reproduced as branch-complete pseudocode. P11's proof gate is "tests green + boots + proxies a
   read," which is weaker than the P1–P10 gates. The MCP resource/tool handler bodies and the CLI
   command bodies would need re-derivation from the API contract (`01-api-*.md`) — flagged as the
   thinnest regeneration coverage in the set.
2. **GATE-9 (data layer) is a FAIL, not a PASS.** 5 tables (`gate_approval`, `skill_metrics`,
   `viewer_event`, `design_annotation`, `interview_session`) have no column spec in the regen set;
   rebuild them from `db/alembic/versions/{062,060,061,065,066}_*.py` directly. The enum-count
   **prose** in `04-data-layer.md` says "14"; the correct count is **13** (the doc's own tables are
   right). Carried into P3's proof gate.
3. **`foundry_temporal` / `foundry_strands_agents` behavior is out of scope.** These private
   Artifactory/vendored packages provide `@foundry_activity`, `HILSignalsMixin`,
   `create_worker_with_defaults`, `FoundryWorkerConfig`, and the logging/error substrate. They gate
   P4–P10 but are NOT reproducible from this repo — they must be sourced from the foundry monorepo
   (`00-overview.md §6`).
4. **Live Bedrock inference is an environmental, not a regeneration, prerequisite.** LocalStack does
   not emulate Bedrock; the DONE scenario's *agent* steps run under `MockAgentRuntime` in CI. A live
   end-to-end (real Claude inference) needs `~/.aws` + `CLAUDE_CODE_USE_BEDROCK=1` + a reachable
   Bedrock region — out of scope for the spec, in scope for a production cutover.
5. **`olympus_contracts.__version__` drift (`0.2.0` vs pyproject `0.3.0`) is intentional** and must
   be preserved (P1). Likewise the `LineWorkflowBase` docstring "eight line workflows" vs the live
   **seven** inheritors, and the Modernization "max 5 children" docstrings vs the authoritative
   `MAX_BC_CHILDREN_PER_APP=12` — reproduce the code value, carry the doc drift as a comment.
