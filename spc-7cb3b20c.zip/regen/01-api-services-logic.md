# Phase 8 — API Service Layer Logic (Atomic Regeneration Spec)

> Scope: `olympus-api/src/services/*.py` — the SERVICE layer, not routers. The 6
> high-complexity modules (`scoring.py`, `gate.py`, `git_service.py`, `wave.py`,
> `step_mapping.py`, `application.py`) are reproduced as **pseudocode preserving
> every branch**. The other ~34 modules get a 2-3 line responsibility + entry-point
> contract. All citations are `path:line` against
> `/Users/pnunna/Documents/GitHub/foundry/olympus-api/src/services/`.
>
> Conventions across this layer:
> - Every async service takes a SQLAlchemy `AsyncSession db` and issues **raw SQL**
>   via `sqlalchemy.text(...)` (no ORM models). asyncpg binds; `:name` params.
> - Services do NOT manage transactions unless noted — routers call `db.commit()`.
>   (Exceptions: many services DO call `await db.commit()` internally; noted per fn.)
> - Errors raise `src.middleware.error_handler.OlympusHTTPException(status, CODE, message[, details])`.
>   Bundle service uses bare `fastapi.HTTPException(status_code, detail={code,message})`.
> - `portfolio_ids` = membership-driven allowlist injected by router for non-admin
>   callers; empty list ⇒ short-circuit empty; `portfolio_id` = explicit filter; both
>   compose (intersect). This pattern recurs everywhere.

---

## Router endpoint counts (context only — routers are NOT specced here)

`olympus-api/src/routers/*.py`, `@router.{get,post,put,patch,delete}` decorator counts:

⚠️ Counts below REFRESHED to HEAD `7cb3b20c` (`@router.*` decorator counts; bold = changed since the prior baseline):
```
router=activity:1   router=admin:1   router=admin_audit:1 ⚠️NEW  router=admin_bundles:2  router=agent_roles:1
router=agent_runs:1 router=agents:2  router=analytics:13 ⚠️(+2) router=applications:30 ⚠️(+8)
router=artifacts:4  router=auth:10   router=bundles:7            router=chat:5
router=escalations:4 router=events:1 router=gates:9 ⚠️(+1)       router=git:1
router=governance:12 ⚠️(+3) router=health:4  router=human_paired_agent:3  router=lines:4
router=me:1         router=portfolio:4  router=portfolio_members:3  router=profiles:4
router=registries:32 router=renditions:2 router=skills:11        router=system:4
router=systems:12   router=traceability:7  router=users:6        router=waves:32
router=webhooks:1   router=workflow_signals:1  router=workflows:4
```
Total router FILES: **37** (`__init__.py` has 0; `admin_audit.py` NEW at HEAD). Sum of `@router.*` (the GATE-8 grep number) = **240** (was 225). Actual mounted path-ops = 240 + 6 secondary-router ops (wave_gates 1, line_start 3, portfolio_profile 2) = **246** (was 231). ⚠️ The old "≈254" figure was a loose estimate; the exact gate number is now 240.

---

# PART A — HIGH-COMPLEXITY MODULES (full pseudocode)

---

## A1. `scoring.py` (1078 lines) — readiness/portfolio scoring engine

### Module constants (`scoring.py:42`)

`GATE_TYPE_TO_ASSEMBLY_LINE` — single source of truth mapping gate_type → line
(the `gate` table has NO `assembly_line` column; this map IS the column):
```
G-DC→Discovery; G-RR→Rationalization; G-DA→Rationalization; G-02→Architecture;
G-DT→Data; G-04a/G-04b/G-04c→Modernization; G-DE-1/G-DE-2→Disposition Execution;
G-V1/G-V2/G-V3→Validation; G-DP-1/G-DP-2→Deployment
```
⚠️ GOTCHA: kept in sync with `insights.py` (`get_decisions`/`_fetch_line_progress`
imports this constant directly at `insights.py:539`).

`DEFAULT_DIMENSIONS` (`scoring.py:88`) — the 6 scoring dimensions + weights, MUST sum to 1.0:
```
code_quality=0.20, test_coverage=0.15, security_posture=0.20,
documentation=0.10, dependency_currency=0.15, architecture_clarity=0.20
```
`DIMENSION_DESCRIPTIONS` (`scoring.py:97`) — human text per dimension.
`_dimension_registry` (`scoring.py:107`) — MODULE-LEVEL MUTABLE `dict(DEFAULT_DIMENSIONS)`.
⚠️ GOTCHA: mutated in place by `update_dimension_weights`; profile-override singleton.

### `_aggregate_pass_rates_by_line(rows) -> list[dict]` (`scoring.py:61`)
Reproduces an old `GROUP BY g.assembly_line` (nonexistent column) in Python:
```
buckets = {}                                  # line -> {total, first_pass}
for r in rows:
    line = GATE_TYPE_TO_ASSEMBLY_LINE.get(str(r["gate_type"]))
    if line is None: continue                 # unknown gate_type → drop
    b = buckets.setdefault(line, {"total":0,"first_pass":0})
    b["total"] += 1
    if r["status"]=="approved" and int(r["retry_count"] or 0)==0:
        b["first_pass"] += 1
return [{"assembly_line":line,"total":b["total"],"first_pass":b["first_pass"]}
        for line,b in sorted(buckets.items())]   # ⚠️ sorted alphabetically (preserves old ORDER BY)
```

### `get_dimension_registry() -> DimensionRegistryResponse` (`scoring.py:110`)
```
entries = [DimensionRegistryEntry(name, weight, description=DIMENSION_DESCRIPTIONS.get(name,""))
           for name,weight in _dimension_registry.items()]
total = sum(_dimension_registry.values())
return DimensionRegistryResponse(dimensions=entries, total_weight=round(total,4),
                                 valid = abs(total-1.0) < 0.001)
```

### `update_dimension_weights(weights) -> DimensionRegistryResponse` (`scoring.py:128`)
```
total = sum(weights.values())
if abs(total-1.0) >= 0.001:
    raise OlympusHTTPException(400,"INVALID_WEIGHTS", f"Dimension weights must sum to 1.0, got {total:.4f}")
_dimension_registry.clear(); _dimension_registry.update(weights)   # ⚠️ mutates module global
return get_dimension_registry()
```

### `_normalize_score(raw) -> float|None` (`scoring.py:147`) — ⚠️ CRITICAL heuristic
Coerces three coexisting score conventions (fraction 0-1, Likert 1-5, percent 0-100)
into 0.0–1.0. (Fix for P5-AUDIT-003 "410% readiness".) EXACT branch order:
```
if raw is None: return None
try: value = float(raw)
except (TypeError,ValueError): return None
if value < 0:   return 0.0          # clamp negatives
if value <= 1.0: return value       # already a fraction
if value <= 5.0: return value / 5.0 # Likert 1–5  (handles (1,5])
if value <= 100.0: return value / 100.0   # percent
return 1.0                          # >100 clamps to 1.0
```

### `get_all_readiness_scores(db,*,portfolio_id=None,portfolio_ids=None) -> list[dict]` (`scoring.py:184`)
Flat per-app readiness for dashboard `ReadinessScoreEntry`.
```
clauses=[]; params={}
if portfolio_ids is not None:
    if not portfolio_ids: return []          # empty allowlist → []
    clauses.append("portfolio_id = ANY(:pf_ids)"); params["pf_ids"]=portfolio_ids
if portfolio_id is not None:
    clauses.append("portfolio_id = :portfolio_id"); params["portfolio_id"]=portfolio_id
where = "WHERE "+ " AND ".join(clauses) if clauses else ""
apps = SELECT id,name FROM application {where} ORDER BY name
results=[]
for app in apps:
    # latest score per dimension, excluding 'overall'
    rows = SELECT DISTINCT ON (dimension) dimension, score
           FROM score_history
           WHERE application_id=:app_id AND dimension != 'overall'
           ORDER BY dimension, recorded_at DESC
    scores_map={}
    for r in rows:
        n=_normalize_score(r["score"])
        if n is not None: scores_map[r["dimension"]]=n
    # weighted overall from registry weights
    weighted_sum=0.0; total_weight=0.0
    for name,weight in _dimension_registry.items():
        weighted_sum += scores_map.get(name,0.0)*weight; total_weight += weight
    overall = weighted_sum/total_weight if total_weight>0 else None
    results.append({app_id:str, app_name: name or str(id),
        overall: round(overall,4) if overall is not None else None,
        code_quality/test_coverage/security_posture/documentation/
        dependency_currency/architecture_clarity: scores_map.get(<dim>)})  # may be None
return results
```

### `calculate_readiness_score(db, app_id, dimension_filter=None) -> ReadinessScoreResponse` (`scoring.py:268`)
```
if app_id is None: return ReadinessScoreResponse(app_id=None, overall=0.0, dimensions=[], calculated_at=None)
rows = SELECT DISTINCT ON (dimension) dimension,score,recorded_at FROM score_history
       WHERE application_id=:app_id AND dimension!='overall'
       ORDER BY dimension, recorded_at DESC
scores_map = {dim: _normalize_score(score) for non-None}
calculated_at = str(rows[0]["recorded_at"]) if rows else None
dimensions=[]; weighted_sum=0.0; total_weight=0.0
for name,weight in _dimension_registry.items():
    if dimension_filter and name not in dimension_filter: continue
    score = scores_map.get(name, 0.0)             # missing dim → 0.0
    dimensions.append(DimensionScore(name,score,weight))
    weighted_sum += score*weight; total_weight += weight
overall = weighted_sum/total_weight if total_weight>0 else 0.0
return ReadinessScoreResponse(app_id, overall=round(overall,2), dimensions, calculated_at)
```
⚠️ Note: `get_all_readiness_scores` rounds overall to **4**; this rounds to **2**.

### `_resolve_portfolio_id(db, portfolio_id, portfolio_ids=None) -> UUID|None` (`scoring.py:335`)
```
if portfolio_id is not None: return portfolio_id
if portfolio_ids is not None:
    if not portfolio_ids: return None
    return SELECT id FROM portfolio WHERE id=ANY(:pf_ids) ORDER BY created_at LIMIT 1
return SELECT id FROM portfolio ORDER BY created_at LIMIT 1   # default: first portfolio
```

### `calculate_overlap_matrix(db, portfolio_id, portfolio_ids=None) -> OverlapMatrixResponse` (`scoring.py:369`)
Pairwise overlap from shared `traceability_link.target_artifact`.
```
portfolio_id = _resolve_portfolio_id(...)
if portfolio_id is None: return OverlapMatrixResponse(portfolio_id=None, pairs=[], total_pairs=0)
apps = SELECT id,name FROM application WHERE portfolio_id=:pid ORDER BY name
if len(apps) < 2: return OverlapMatrixResponse(portfolio_id, pairs=[], total_pairs=0)
pairs=[]
for i in range(len(apps)):
  for j in range(i+1, len(apps)):           # ⚠️ O(n²) pair loop, each pair = 3 SQL queries
    a,b = apps[i], apps[j]
    shared = SELECT count(DISTINCT a.target_artifact)
             FROM traceability_link a JOIN traceability_link b
               ON a.target_artifact=b.target_artifact
             WHERE a.app_id=:a AND b.app_id=:b              # (or 0)
    total_a = SELECT count(DISTINCT target_artifact) FROM traceability_link WHERE app_id=:a  # (or 0)
    total_b = SELECT count(DISTINCT target_artifact) ... :b                                  # (or 0)
    max_total = max(total_a, total_b, 1)
    composite = round(shared/max_total*100, 2) if max_total>0 else 0.0
    pairs.append(OverlapPair(app_a_id,app_b_id,app_a_name,app_b_name, composite_overlap=composite))
return OverlapMatrixResponse(portfolio_id, pairs, total_pairs=len(pairs))
```

### `calculate_portfolio_health(db, portfolio_id, portfolio_ids=None) -> PortfolioHealthResponse` (`scoring.py:470`)
⚠️ CRITICAL composite-health math — reproduce exactly.
```
portfolio_id = _resolve_portfolio_id(...)
if None: return PortfolioHealthResponse(all zeros, portfolio_id=None)
total_apps     = SELECT count(*) FROM application WHERE portfolio_id=:pid              # or 0
completed_apps = SELECT count(*) FROM application WHERE portfolio_id=:pid AND current_status='completed'  # or 0
disposition_pct = round(completed_apps/total_apps*100, 2) if total_apps>0 else 0.0
# avg of LATEST 'overall' score per app (correlated subquery picks max recorded_at)
avg_score_row = SELECT avg(sh.score) FROM score_history sh JOIN application a ON a.id=sh.application_id
                WHERE a.portfolio_id=:pid AND sh.dimension='overall'
                  AND sh.recorded_at = (SELECT max(sh2.recorded_at) FROM score_history sh2
                                        WHERE sh2.application_id=sh.application_id AND sh2.dimension='overall')
avg_score = round(float(avg_score_row),2) if avg_score_row else 0.0
# stale artifacts: distinct source_artifact whose recorded source_version != app.analyzed_commit_sha
stale_count = SELECT count(DISTINCT tl.source_artifact) FROM traceability_link tl
              JOIN application a ON a.id=tl.app_id
              WHERE a.portfolio_id=:pid AND a.analyzed_commit_sha IS NOT NULL
                AND tl.source_version IS NOT NULL AND tl.source_version != a.analyzed_commit_sha   # or 0
drift_penalty = min(stale_count * 2.0, 20.0)        # ⚠️ max 20% penalty
overall = max(0.0,
              disposition_pct * 0.5
            + (avg_score / 5.0 * 100) * 0.3          # ⚠️ avg_score treated as 0-5 Likert → pct
            + (100.0 - drift_penalty) * 0.2)
return PortfolioHealthResponse(portfolio_id, overall_health=round(min(overall,100.0),2),
        disposition_progress_pct=disposition_pct, avg_readiness_score=avg_score,
        stale_artifact_count=stale_count, apps_total=total_apps, apps_completed=completed_apps)
```

### `calculate_disposition_confidence(db, app_id) -> DispositionConfidenceResponse` (`scoring.py:571`)
⚠️ CRITICAL confidence formula.
```
if app_id is None: return DispositionConfidenceResponse(all zeros/None, detail="No app specified")
disposition = (SELECT disposition FROM application WHERE id=:id)  # or None
evidence_count   = SELECT count(*) FROM traceability_link WHERE app_id=:app_id          # or 0
gate_pass_count  = SELECT count(*) FROM gate WHERE application_id=:app_id AND status='approved'  # or 0
confidence = 0.0
if disposition: confidence += 30.0                  # base
confidence += min(evidence_count * 2.0, 40.0)       # up to 40 from evidence
confidence += min(gate_pass_count * 10.0, 30.0)     # up to 30 from gates
confidence = min(confidence, 100.0)
detail_parts=[]
if not disposition: detail_parts.append("No disposition set")
if evidence_count==0: detail_parts.append("no traceability evidence")
if gate_pass_count==0: detail_parts.append("no gates passed")
detail = "; ".join(detail_parts) if detail_parts else "Strong evidence base"
return DispositionConfidenceResponse(app_id, disposition, confidence_pct=round(confidence,2),
        evidence_count, gate_pass_count, detail)
```

### `calculate_compound_growth(db, portfolio_id, portfolio_ids=None) -> CompoundGrowthResponse` (`scoring.py:651`)
```
portfolio_id = _resolve_portfolio_id(...);  if None: return all-zero CompoundGrowthResponse
# gate pass rate — denominator only DECIDED gates (approved/rejected)
total_gates = SELECT count(*) FROM gate g JOIN application a ON a.id=g.application_id
              WHERE a.portfolio_id=:pid AND g.status IN ('approved','rejected')           # or 0
first_attempt_passes = ... AND g.status='approved' AND g.retry_count=0                     # or 0
gate_pass_rate = round(first_attempt_passes/total_gates,4) if total_gates>0 else 0.0
total_waves = SELECT count(*) FROM wave WHERE portfolio_id=:pid                            # or 0
total_completed = SELECT count(*) FROM application WHERE portfolio_id=:pid AND current_status='completed'  # or 0
wave_velocity = round(total_completed/total_waves,2) if total_waves>0 else 0.0
total_apps = SELECT count(*) FROM application WHERE portfolio_id=:pid                       # or 0
# pattern reuse: apps citing a target_artifact shared by >1 app
apps_with_shared = SELECT count(DISTINCT tl.app_id) FROM traceability_link tl
                   JOIN application a ON a.id=tl.app_id
                   WHERE a.portfolio_id=:pid AND tl.target_artifact IN (
                       SELECT target_artifact FROM traceability_link
                       GROUP BY target_artifact HAVING count(DISTINCT app_id) > 1)          # or 0
pattern_reuse = round(apps_with_shared/total_apps,4) if total_apps>0 else 0.0
return CompoundGrowthResponse(portfolio_id, pattern_reuse_rate, gate_pass_rate, wave_velocity,
        total_gates, gates_passed_first_attempt=first_attempt_passes, total_waves, total_apps_completed=total_completed)
```

### `calculate_gate_pass_rate(db, portfolio_id, portfolio_ids=None) -> GatePassRateResponse` (`scoring.py:775`)
```
portfolio_id = _resolve_portfolio_id(...);  if None: return GatePassRateResponse(portfolio_id=None)
total_decided   = count gate JOIN application WHERE portfolio AND status IN ('approved','rejected')   # or 0
total_first_pass= ... AND status='approved' AND retry_count=0                                          # or 0
overall_rate = round(total_first_pass/total_decided,4) if total_decided>0 else 0.0
# per gate_type breakdown (SQL FILTER)
by_type_rows = SELECT g.gate_type, count(*) total,
                 count(*) FILTER (WHERE g.status='approved' AND g.retry_count=0) first_pass
               FROM gate g JOIN application a ON a.id=g.application_id
               WHERE a.portfolio_id=:pid AND g.status IN ('approved','rejected')
               GROUP BY g.gate_type ORDER BY g.gate_type
by_gate_type = [GateTypePassRate(gate_type,total,first_pass, rate=round(first_pass/total,4) if total>0 else 0.0)]
# per assembly_line: derive in Python from gate_type via _aggregate_pass_rates_by_line
by_line_src_rows = SELECT g.gate_type, g.status, COALESCE(g.retry_count,0) retry_count
                   FROM gate g JOIN application a ... WHERE portfolio AND status IN ('approved','rejected')
by_line_rows = _aggregate_pass_rates_by_line(by_line_src_rows)
by_assembly_line = [AssemblyLinePassRate(assembly_line,total,first_pass, rate=round(first_pass/total,4) if total>0 else 0.0)]
return GatePassRateResponse(portfolio_id, overall_rate, total_decided, total_first_pass, by_gate_type, by_assembly_line)
```

### `get_score_history(db, app_id, dimension=None, limit=100) -> ScoreHistoryResponse` (`scoring.py:893`)
```
where="application_id=:app_id"; params={app_id, limit}
if dimension: where += " AND dimension=:dimension"; params["dimension"]=dimension
rows = SELECT dimension,score,recorded_at,source_artifact,governance_cycle FROM score_history
       WHERE {where} ORDER BY recorded_at DESC LIMIT :limit
entries = [ScoreHistoryEntry(dimension, score=float(score), recorded_at=str, source_artifact, governance_cycle)]
return ScoreHistoryResponse(app_id, entries, total=len(entries))
```
⚠️ NOTE: score returned RAW (`float(score)`), NOT normalized — time-series shows original values.

### `_normalize_portfolio_score(raw) -> dict` (`scoring.py:950`)
Coerce `application.portfolio_score` JSONB (dict OR JSON string OR None) → dict; `{}` on malformed.

### `get_portfolio_scoring_heat_map(db, portfolio_id=None, portfolio_ids=None) -> PortfolioScoringHeatMapResponse` (`scoring.py:971`)
Reads `application.portfolio_score` JSONB (populated by `persist_portfolio_score` activity).
```
clauses/params per standard allowlist pattern; empty allowlist → PortfolioScoringHeatMapResponse(applications=[])
rows = SELECT id,name,risk_tier,complexity_tier,disposition,current_line,portfolio_score
       FROM application {where} ORDER BY name
entries=[]; scored=0
for row in rows:
    payload = _normalize_portfolio_score(row["portfolio_score"])
    raw_dims = payload.get("scores") or {}
    dimensions = {}
    for dim_name,dim_value in raw_dims.items():
        if not isinstance(dim_value,dict): continue
        dimensions[dim_name] = PortfolioScoreDimension(
            score = float(dim_value["score"]) if dim_value.get("score") is not None else None,
            rationale = str(dim_value["rationale"]) if not None,
            evidence = [str(e) for e in (dim_value.get("evidence") or [])])
    overall = payload.get("overall_weighted")
    if isinstance(overall,(int,float)): overall_val=float(overall); scored += 1
    else: overall_val=None
    entries.append(PortfolioScoringHeatMapEntry(app_id, app_name=name or str(id), overall_weighted=overall_val,
        risk_tier, complexity_tier, disposition, current_line, dimensions,
        methodology_version=str(payload["methodology_version"]) if not None,
        computed_at=str(payload["computed_at"]) if not None))
return PortfolioScoringHeatMapResponse(portfolio_id, entries, total=len(entries), scored=scored)
```
⚠️ Apps with no portfolio_score row still appear (overall_weighted=None, empty dimensions).

---

## A2. `gate.py` (2574 lines at HEAD `7cb3b20c`) — gate orchestration / state machine / evidence builder

> ⚠️ **NEW at HEAD (P6-S6.4 quorum):** `record_gate_approval` (gate.py:496), `_load_gate_approvals` (gate.py:446), `_build_pending_approvals` (gate.py:464), `list_pending_wave_gates` (gate.py:243), `get_gate_type_and_portfolio` (gate.py:282), `get_gate_evidence_for_application` (gate.py:1848). The `/approve` + wave-batch paths now insert `gate_approval` rows and advance only on quorum+oversight; the legacy single-shot `approve_gate` (gate.py:373) remains for `submit_gate_decision`'s approve path. Full reproduction of these + the gate_rbac policy layer is in **`01-api-gates-escalations.md`** (this file's gate.py citations below were refreshed: most service fns shifted +400–600 lines).

### Gate status state machine (derived from all transitions)
States: `preparing` → `pending` → {`approved` | `rejected` | `escalated`}; plus
`merge_blocked` (post-approval merge failure) and `escalated`→{`pending`|`rejected`} via
escalation resolution. Decision functions reject if status != expected (409). ⚠️ Approve is now quorum-gated: a `pending` gate with recorded-but-insufficient approvals stays `pending` (see `record_gate_approval`).

### Actor-kind enrichment (Phase 5 task #150)

`_coerce_local_agent_descriptor(raw) -> LocalAgentDescriptor|None` (`gate.py:43`):
requires dict with non-empty str `tool`; else None. Carries optional str `version`,`model`.

`_build_actor_index_for_scope(db,*,application_id,wave_id) -> dict[skill_id→{actor_kind,local_agent_descriptor,human_user_id}]` (`gate.py:57`):
```
if application_id is None and wave_id is None: return {}
where = "application_id=:scope" if application_id else "wave_id=:scope"
scope = application_id if application_id else wave_id
rows = SELECT DISTINCT ON (skill_id) skill_id, actor_kind, local_agent_descriptor, human_user_id,
         COALESCE(completed_at,started_at,dispatched_at) AS recency_ts
       FROM agent_task WHERE {where} AND skill_id IS NOT NULL
       ORDER BY skill_id, COALESCE(completed_at,started_at,dispatched_at) DESC NULLS LAST
out = {sid: {actor_kind: r.actor_kind or "olympus_agent",
             local_agent_descriptor: _coerce_local_agent_descriptor(...), human_user_id} for str sid}
```

`_apply_actor_kind_to_artifacts(artifacts, actor_index) -> list` (`gate.py:117`):
```
if not actor_index: return artifacts          # backward-compat
for art in artifacts:
    skill_id = art.data.get("skill_id") if isinstance(art.data,dict) else None
    if isinstance(skill_id,str) and skill_id in actor_index:
        emit art.model_copy(update={actor_kind, local_agent_descriptor, human_user_id})
    else: keep art unchanged   # defaults actor_kind='olympus_agent'
```

### `list_pending_gates(db, params, portfolio_id=None, portfolio_ids=None, wave_id=None, status="pending") -> (list[GateSummary], int)` (`gate.py:153`)
⚠️ GOTCHA: ordering and FALSE-clause branches.
```
bind={}; clauses=[]
if status != "all": clauses.append("g.status=:status"); bind["status"]=status
if portfolio_ids is not None:
    if not portfolio_ids: clauses.append("FALSE")          # ⚠️ literal FALSE so SQL still runs
    else: clauses.append("g.portfolio_id=ANY(:pf_ids)"); bind["pf_ids"]=...
if portfolio_id is not None: clauses.append("g.portfolio_id=:portfolio_id"); bind[...]
if wave_id is not None: clauses.append("g.wave_id=:wave_id"); bind[...]
where = "WHERE "+ " AND ".join(clauses) if clauses else ""
total = SELECT count(*) FROM gate g {where}                # or 0
bind["limit"]=params.per_page; bind["offset"]=params.offset
order_by = "ORDER BY g.decided_at DESC NULLS LAST" if status=="rejected"   # ⚠️ rejected: newest rework first
           else "ORDER BY g.requested_at ASC"                              # else: oldest first
rows = SELECT g.*, a.name app_name, w.name wave_name FROM gate g
       LEFT JOIN application a ON a.id=g.application_id
       LEFT JOIN wave w ON w.id=g.wave_id {where} {order_by} LIMIT :limit OFFSET :offset
gates = [GateSummary(id, gate_type, app_id=application_id, wave_id, app_name=app_name or "",
                     wave_name=wave_name or "", status)]
return gates, total
```

### `_get_gate_or_404(db, gate_id) -> dict` (`gate.py:239`): `SELECT * FROM gate WHERE id=:id`; None→404 `GATE_NOT_FOUND`.
### `_gate_detail_from_row(row) -> GateDetail` (`gate.py:252`): maps id,gate_type,app_id(=application_id),wave_id,status,decided_at,decided_by,created_at(=requested_at),justification,reject_reason_category,merge_failure_detail.

### `_persist_card_review(db, gate_id, existing_evidence, card_decisions, reviewer_notes, sort_applied, bulk_approved)` (`gate.py:268`)
W8 card-per-check persistence under `evidence_data.review`.
```
if (not card_decisions and reviewer_notes is None and sort_applied is None and bulk_approved is None): return  # no-op
evidence = dict(existing_evidence or {}); review_block = dict(evidence.get("review") or {})
if card_decisions: review_block["card_decisions"]=card_decisions
if reviewer_notes is not None: review_block["reviewer_notes"]=reviewer_notes
if sort_applied is not None: review_block["sort_applied"]=sort_applied
if bulk_approved is not None: review_block["bulk_approved"]=bulk_approved
evidence["review"]=review_block
UPDATE gate SET evidence_data = CAST(:ev AS JSONB) WHERE id=:id      # ev = json.dumps(evidence)
```

### `approve_gate(db, gate_id, approved_by, comment=None, approve_reason_category=None, card_decisions=None, reviewer_notes=None, sort_applied=None, bulk_approved=None) -> GateDetail` (`gate.py:315`)
```
row = _get_gate_or_404(...)
if row["status"] != "pending": raise 409 GATE_ALREADY_DECIDED
now = utcnow()
UPDATE gate SET status='approved', decided_at=:now, decided_by=:by, justification=:comment WHERE id=:id   # comment or ""
_persist_card_review(db, gate_id, row.get("evidence_data"), card_decisions, reviewer_notes, sort_applied, bulk_approved)
await db.commit()
if approve_reason_category is not None: logger.info("gate_approved_with_reason", ...)   # ⚠️ NOT persisted, log only
if card_decisions: logger.info("gate_approved_with_card_decisions", ...)
row.update(status='approved', decided_at=now, decided_by=approved_by)
return _gate_detail_from_row(row)
```

### `reject_gate(db, gate_id, rejected_by, feedback, reason_category=None, card_decisions=None, ...) -> GateDetail` (`gate.py:388`)
```
row=_get_gate_or_404; if status!='pending': 409 GATE_ALREADY_DECIDED
UPDATE gate SET status='rejected', decided_at=:now, decided_by=:by, justification=:feedback,
                reject_reason_category=:category WHERE id=:id      # ⚠️ category IS persisted (unlike approve)
_persist_card_review(...); commit
if card_decisions: logger.info("gate_rejected_with_card_decisions",...)
return _gate_detail_from_row(row updated to rejected)
```

### `send_gate_temporal_signal(db, gate_id, action, actor, message="", reason_category=None, card_decisions=None, reviewer_notes=None)` (`gate.py:459`)
⚠️ CRITICAL Temporal signal dispatch + G-DA dual-signal. Whole body in try/except (failures only logged).
```
try:
  row = SELECT workflow_id, gate_type FROM gate WHERE id=UUID(gate_id)  (.mappings().first())
  if not row or not row["workflow_id"]: logger.warning("temporal_signal_skipped_no_workflow_id"); return
  workflow_id = row["workflow_id"]; gate_type = row.get("gate_type")   # ⚠️ .get() not [], tolerate missing
  client = await get_temporal_client()       # from src.dependencies
  if action=="approve":
      client.get_workflow_handle(workflow_id).signal("gate_approved",
          GateApprovedSignal(gate_id, approved_by=actor, justification=message,
                             card_decisions=card_decisions or [], reviewer_notes))
      if gate_type == "G-DA":                 # ⚠️ DUAL-SIGNAL: G-DA also needs StakeholderApprovedSignal
          from olympus_workflows.types import StakeholderApprovedSignal
          handle.signal("stakeholder_approved",
              StakeholderApprovedSignal(approval_id=f"gda-{gate_id}", stakeholder=actor, scope="g-da"))
          logger.info("gda_stakeholder_signal_sent",...)
  elif action=="reject":
      handle.signal("gate_rejected", GateRejectedSignal(gate_id, rejected_by=actor, reason=message,
          reason_category, card_decisions or [], reviewer_notes))
  elif action=="merge_retry":
      handle.signal("merge_retry", GateMergeRetrySignal(gate_id, retried_by=actor, note=message or None))
except Exception:
  logger.warning("temporal_signal_failed", exc_info=True)   # ⚠️ swallows ALL exceptions; DB state already updated
```

### Evidence-builder dispatch constants
- `_DISCOVERY_ORDER()` (`gate.py:580`) = `pass_order("Discovery")` from olympus_contracts.
- `_RATIONALIZATION_ORDER()` (`gate.py:584`) = `pass_order("Rationalization")`.
- `_GUIDANCE_BY_GATE` (`gate.py:587`) — reviewer guidance text for G-DC, G-RR, G-DA (default fallback below).
- `_STEP_BASED_LINE_CONFIG` (`gate.py:1082`) — line name → `(line_prefix, unit_artifact_type, unit_key_label)`:
  ```
  Rationalization→(rationalization,rationalization_step,step_name); Architecture→(architecture,architecture_step,step_name)
  Data→(data,data_step,step_name); Modernization→(modernization,modernization_step,step_name)
  Disposition Execution→(disposition_execution,disposition_step,step_name); Validation→(validation,validation_step,step_name)
  Deployment→(deployment,deployment_step,step_name); Sustainment→(sustainment,sustainment_step,step_name); Governance→(governance,governance_step,step_name)
  ```
  ⚠️ Discovery is INTENTIONALLY ABSENT (special-cased under `passes`). A `steps`-shaped
  payload whose `assembly_line` isn't here collapses to generic findings (the G-DT/G-02 bug).
- `_APP_STATUS_ADVANCE` (`gate.py:1582`) — `{line}_in_progress` → `{line}_complete` for all 10 lines.

### `_build_generic_findings_artifacts(evidence_data, gate_type, app_id) -> list[GateEvidenceArtifact]` (`gate.py:605`)
For every gate not using passes/steps. Emits a leading `gate_summary` card + one `gate_finding` per finding.
```
line_prefix = gate_type.lower().replace("-","_")
findings=evidence_data.get("findings") or []; recommendations=... or []; summary_score=...; summary_text=... or ""
artifacts=[GateEvidenceArtifact(artifact_type="gate_summary", title="Review Summary",
    artifact_path=f"{line_prefix}/{app_id}/summary.json", schema_version="1.0",
    data={summary, recommendations, summary_score, findings_count:len(findings)},
    metadata=None, step_name="summary", step_title="Review Summary")]
for finding in findings:
    if not dict: continue
    fid=str(finding.get("id") or "F"); severity=str(finding.get("severity","medium")); title=str(finding.get("title") or f"Finding {fid}")
    supporting=[SupportingArtifact(**sa) for sa in finding.get("supporting_artifacts",[]) if dict; skip malformed]
    artifacts.append(GateEvidenceArtifact(artifact_type="gate_finding", title,
        artifact_path=f"{line_prefix}/{app_id}/findings/{fid}.json", schema_version="1.0",
        data={finding_id:fid, severity, title, detail, evidence_refs}, metadata={severity},
        step_name=fid, step_title=title, supporting_artifacts=supporting))
return artifacts
```

### `_substitute_app_names(text_in, app_name_map) -> str` (`gate.py:700`)
Replace literal app UUID strings with names in rendered content (no-op if empty); `result.replace(app_id_str, name)` skipping when `app_id_str==name`.

### `_parse_pr_number_from_url(url) -> int|None` (`gate.py:732`): trailing path segment → int, else None.

### `_resolve_evidence_branch(svc, gate_row) -> str` (`gate.py:749`)
PR-branch resolution so evidence hydrates while gate still pending (artifacts on PR head, not main).
```
pr_number = _parse_pr_number_from_url(gate_row.get("evidence_package_url") or "")
if None: return "main"
try: pr = svc._repo.get_pull(pr_number); return (pr.head.ref or "").strip() or "main"
except: logger.info("gate_evidence.branch_resolve_failed"); return "main"
```

### `_hydrate_slim_evidence_contents(db, evidence_data, gate_row, config)` (`gate.py:776`)
Fetches full file bodies for slim `file_artifacts` (path+encoding+size only) from artifact repo at read time.
```
scope_app=gate_row.application_id; scope_wave=gate_row.wave_id
assembly_line=evidence_data.get("assembly_line") or ""
if evidence_data.get("passes"): units=passes; line_prefix="discovery"
else: units=steps; line_prefix = _STEP_BASED_LINE_CONFIG.get(assembly_line)[0] or ""
if not units or not line_prefix: return
scope_id = scope_app or scope_wave;  if not scope_id: return
slim_entries=[]   # collect file_artifacts where content empty/missing
for unit_name,unit_info in units.items():
  for file_info in unit_info.get("file_artifacts") or []:
    if file_info.get("content"): continue        # ⚠️ idempotent: skip already-fat
    path=file_info.get("path"); if not path: continue
    full_path=f"{line_prefix}/{scope_id}/files/{unit_name}/{path}"; slim_entries.append((line_prefix,full_path,file_info))
if not slim_entries: return
# resolve portfolio_id (gate_row.portfolio_id, else app/wave lookup); need github_token
if not portfolio_id or config None or no github_token: logger.info("gate_evidence.hydrate_skipped"); return
artifact_repo = SELECT artifact_repo_url FROM portfolio WHERE id=:id ; if empty return
build GitService(token, repo=artifact_repo, base_url); on GitServiceError return
branch_ref = _resolve_evidence_branch(svc, gate_row)
# parallel fetch each file via asyncio.to_thread(svc.read_file, path=full_path, branch=branch_ref)
#   bytes→utf-8 decode; on GitServiceError or any exc → file_info.setdefault("content","")  (best-effort)
await asyncio.gather(*[_fetch_one(...)])
```
⚠️ GOTCHA: per-file failures tolerated; whole response always succeeds.

### `_build_unit_artifacts(units, unit_order, app_id, line_prefix, unit_artifact_type, unit_key_label, app_name_map=None) -> list` (`gate.py:958`)
Renders Discovery `passes` or other-line `steps` as cards.
```
seen_file_names=set()
unknown_units = sorted(set(units) - set(unit_order))
if unknown_units: logger.warning("gate_evidence_unit_order_drift", ...)   # ⚠️ name-drift detection
for unit_name in unit_order:                       # ⚠️ iterate in CONTRACT order, not dict order
    unit_info = units.get(unit_name)
    if not unit_info or not unit_info.get("output"): continue
    metadata = unit_info.get("metadata",{}); unit_title=unit_info.get("title",unit_name)
    raw_files = unit_info.get("file_artifacts",[]); file_paths_set={f.path}
    supporting=[]
    for file_info in raw_files:
        base,ext=splitext(path)
        if ext==".json" and (base+".md") in file_paths_set: continue   # ⚠️ dedupe JSON when .md sibling exists
        if path in seen_file_names: continue
        seen_file_names.add(path)
        content = _substitute_app_names(file_info.get("content",""), app_name_map)
        supporting.append(SupportingArtifact(file_artifact, title=basename,
            artifact_path=f"{line_prefix}/{app_id}/files/{unit_name}/{file_path}",
            data={file_path, content, encoding, <unit_key_label>:unit_name}))
    card_metadata = {model_used,duration_ms,token_usage_input,token_usage_output,cost_estimate_usd} if metadata else {}
    if _unit_is_summary(line_prefix, unit_name): card_metadata["is_summary"]=True   # ⚠️ pins summary to top of list
    artifacts.append(GateEvidenceArtifact(unit_artifact_type, title=unit_title,
        artifact_path=f"{line_prefix}/{app_id}/{unit_info.get('artifact', unit_name+'.json')}",
        data={analysis: _substitute_app_names(unit_info["output"],map), skill_id, <unit_key_label>:unit_name},
        metadata=card_metadata or None, step_name=unit_name, step_title=unit_title, supporting_artifacts=supporting))
return artifacts
```

### `_line_config_for_prefix(line_prefix) -> str|None` (`gate.py:1099`): reverse lookup of `_STEP_BASED_LINE_CONFIG`.
### `_unit_is_summary(line_prefix, unit_name) -> bool` (`gate.py:1109`): contract `get_line(name).summary_step()`; map prefix `discovery→Discovery` else `_line_config_for_prefix`; False if unknown/KeyError.

### `get_gate_evidence(db, gate_id, config=None) -> GateEvidencePackage` (`gate.py:1127`)  ⚠️ CRITICAL orchestration
```
row = _get_gate_or_404(...)
app_name=""; wave_name=""; app_name_map={}
if row.application_id:
    app_name = SELECT name FROM application WHERE id=:id  (or "Unknown Application")
    app_name_map[str(application_id)] = name
elif row.wave_id:
    wave_name = SELECT name FROM wave WHERE id=:id  (or "Unknown Wave")
    app_rows = SELECT a.id,a.name FROM application a JOIN wave_application wa ON wa.application_id=a.id WHERE wa.wave_id=:wid
    for ar: app_name_map[str(ar.id)] = ar.name          # ⚠️ all wave apps for UUID substitution
evidence_data = row.evidence_data
if evidence_data is dict: await _hydrate_slim_evidence_contents(db, evidence_data, row, config)
scope_id = row.application_id or row.wave_id
assembly_line = gate_assembly_line(row.gate_type)       # ⚠️ canonical mapping (P5-AUDIT-014 fix)
if evidence_data is dict:
    assembly_line = evidence_data.get("assembly_line") or assembly_line
    passes=evidence_data.get("passes"); steps=evidence_data.get("steps")
    if passes:
        artifacts = _build_unit_artifacts(passes, _DISCOVERY_ORDER(), scope_id, "discovery", "discovery_pass", "pass_name", app_name_map)
    elif steps:
        line_config = _STEP_BASED_LINE_CONFIG.get(assembly_line)
        if line_config is None:
            logger.warning("gate_evidence_unknown_assembly_line"); artifacts = _build_generic_findings_artifacts(...)
        else:
            (line_prefix, unit_artifact_type, unit_key_label) = line_config
            try: unit_order = pass_order(assembly_line)
            except KeyError: logger.warning("gate_evidence_missing_line_contract"); unit_order = tuple(steps.keys())
            artifacts = _build_unit_artifacts(steps, unit_order, scope_id, line_prefix, unit_artifact_type, unit_key_label, app_name_map)
    else:
        artifacts = _build_generic_findings_artifacts(evidence_data, row.gate_type, scope_id)
    # dedupe by artifact_path (keep path-less ones)
    seen_paths=set(); unique=[]; for a in artifacts: if a.artifact_path and not seen: keep; elif not path: keep
    artifacts = unique
    reviewer_guidance = _GUIDANCE_BY_GATE.get(row.gate_type, "Review the attached evidence for completeness and accuracy.")
else:
    reviewer_guidance = "No evidence data available. This gate may have been created before evidence collection was enabled."
# P5-AUDIT-015 synthesized fallback when 0 artifacts
if not artifacts:
    evidence_url = row.evidence_package_url or ""
    artifacts = [GateEvidenceArtifact("gate_package", title=gate_friendly_name(gate_type), artifact_path=evidence_url,
        data={evidence_package_url: url or None, guidance: reviewer_guidance}, metadata={synthesized:True})]
# AI pre-review recommendation
ai_rec_data = evidence_data.get("ai_recommendation") if evidence_data else None
ai_recommendation = AIRecommendation(**ai_rec_data) if ai_rec_data else None
# prior rejection history: same (application_id|wave_id)+gate_type, status='rejected', id != current, LIMIT 5 DESC
scope_col = "application_id" if row.application_id else "wave_id"; scope_id = ...
previous_feedback = (SELECT id,decided_at,decided_by,justification,reject_reason_category FROM gate
    WHERE {scope_col}=:scope_id AND gate_type=:gate_type AND status='rejected' AND id<>:current_id
    ORDER BY decided_at DESC LIMIT 5) → list of dicts (decided_at.isoformat())  (else None)
# advisory validation_warnings: normalize dict[str,list[str]] keep only string keys+list values; else None
# actor-kind stamping
actor_index = _build_actor_index_for_scope(db, application_id, wave_id)
artifacts = _apply_actor_kind_to_artifacts(artifacts, actor_index)
# rationalization_capabilities: list of dicts from evidence_data; filter non-dicts; else None
return GateEvidencePackage(gate_id, gate_type, app_id, wave_id, app_name, wave_name, assembly_line, artifacts,
    pr_url=evidence_package_url, reviewer_guidance, previous_attempts=row.retry_count or 0, previous_feedback,
    ai_recommendation, validation_warnings, rationalization_capabilities=rat_caps)
```

### `set_gate_merge_blocked(db, gate_id, failure_detail: dict) -> GateDetail` (`gate.py:1455`)
W17. Reviewer approval preserved (decided_at/by untouched); only status→`merge_blocked`, set `merge_failure_detail` JSONB.
Idempotent. Logs `gate_merge_blocked`. Commits. (Called by Temporal activity; no RBAC here.)

### `retry_merge_gate(db, gate_id, retried_by, note=None) -> GateDetail` (`gate.py:1519`)
```
row=_get_gate_or_404; if status != 'merge_blocked': raise 409 GATE_NOT_MERGE_BLOCKED
UPDATE gate SET status='approved', merge_failure_detail=NULL WHERE id=:id    # ⚠️ reverts to approved (reviewer already decided)
commit
await send_gate_temporal_signal(db, str(gate_id), "merge_retry", retried_by, note or "")
return GateDetail(status='approved', merge_failure_detail=None)
```

### `_verify_gate_evidence_exists(row, config) -> bool` (`gate.py:1596`)
```
evidence_url = row.evidence_package_url; if not: return False
if not config.github_token: return False
parse url .../<owner>/<repo>/pull/<n>: require len(parts)>=7 and parts[-2]=="pull"; else False; ValueError/IndexError→False
build GitService; svc._repo.get_pull(pr_number); return True; any Exception → False
```

### `force_advance_gate(db, gate_id, advanced_by, comment, bypass_evidence_check, config) -> GateDetail` (`gate.py:1648`)
CHAPS fixup: workflow created gate+PR but died before `mark_gate_ready_for_review`.
```
row=_get_gate_or_404
if status != 'preparing': raise 409 GATE_NOT_PREPARING (use /approve or /reject)
if not bypass_evidence_check:
    if not await _verify_gate_evidence_exists(row, config): raise 409 GATE_EVIDENCE_NOT_FOUND
UPDATE gate SET status='approved', decided_at=:now, decided_by=:by, justification=:comment WHERE id=:id
advanced_app_status=None
if row.application_id:
    current = SELECT current_status FROM application WHERE id=:id
    advance_to = _APP_STATUS_ADVANCE.get(current)
    if advance_to: UPDATE application SET current_status=:new_status, updated_at=:now WHERE id=:id; advanced_app_status=advance_to
# audit_log forensic record (action='gate.force_advance')
INSERT INTO audit_log (actor, actor_type='human', action, resource_type='gate', resource_id, details JSONB)
commit; logger.warning("gate_force_advanced")
return GateDetail(status='approved', decided_at, decided_by, justification=comment)
```

### `resolve_escalation(db, gate_id, resolved_by, resolution_category, notes=None) -> GateDetail` (`gate.py:1787`)
```
row=_get_gate_or_404; if status != 'escalated': raise 409 GATE_NOT_ESCALATED
justification = notes or f"Escalation resolved: {resolution_category}"
if resolution_category == "rejected-as-escalated": new_status="rejected"   # hard reject
else: new_status="pending"   # re-extract / manual-augment / re-disposition reopen for review
UPDATE gate SET status=:status, decided_at=:now, decided_by=:by, justification=:reason WHERE id=:id
    # ⚠️ now = utcnow if new_status!='pending' else None  (reopened gate has null decided_at)
commit; logger.info("escalation_resolved")
return GateDetail(status, decided_at=(now if !='pending' else None), decided_by, justification)
```

### Capability-lineage row rework (Phase 5 PR #4)

`_persist_capability_lineage_rework_block(db, gate_id, row_summary)` (`gate.py:1854`):
no-op if ratified==0 and rejected==0; else write `evidence_data.review.capability_lineage_rework`
= {ratified_count, rejected_count, rejected_rows}; commit.

`_apply_capability_lineage_row_decisions(db, decided_by, capability_lineage_decisions) -> summary` (`gate.py:1897`):
```
summary = {ratified:0, rejected:0, rework_feedback:[]}
if not decisions: return summary
for cld in decisions:
    lineage_id = UUID(cld["lineage_id"])   # skip malformed (KeyError/ValueError/TypeError)
    if cld.decision=="approve":
        row = system_svc.ratify_capability_lineage_row(db, lineage_id, decided_by, notes=None)
        summary.ratified += 1; logger.info("capability_lineage_row_ratified_via_gate")
    elif cld.decision=="reject":
        feedback=(cld.feedback or "").strip(); if not feedback: continue   # router enforces; defensive skip
        row = system_svc.reject_capability_lineage_row(db, lineage_id, decided_by, feedback)
        summary.rejected += 1; summary.rework_feedback.append({lineage_id, source/target_capability,
            source/target_system, relationship, feedback})
        logger.info("capability_lineage_row_rejected_via_gate")
return summary
```

### `submit_gate_decision(db, gate_id, decided_by, action, notes=None, escalation_reason=None, reason_category=None, approve_reason_category=None, card_decisions=None, reviewer_notes=None, sort_applied=None, bulk_approved=None, capability_lineage_decisions=None) -> GateDetail` (`gate.py:1988`)
Unified approve/reject/escalate facade. ⚠️ row decisions applied FIRST.
```
row_summary = await _apply_capability_lineage_row_decisions(db, decided_by, capability_lineage_decisions)
# augment notes + reviewer_notes with row-rework feedback block (append, never replace)
if row_summary.rework_feedback:
    rework_block = "\n".join(f"- [{src or '?'} → {tgt or '(none)'}]: {feedback}" per item)
    suffix = "\n\n--- capability_lineage row rework ---\n" + rework_block
    augmented_reviewer_notes = (reviewer_notes or "")+suffix if reviewer_notes is not None else suffix.lstrip("\n")
    augmented_notes = (notes or "")+suffix if notes is not None else suffix.lstrip("\n")
else: augmented_* = original
if action=="approve":
    result = await approve_gate(db, gate_id, decided_by, augmented_notes, approve_reason_category, card_decisions, augmented_reviewer_notes, sort_applied, bulk_approved)
    await _persist_capability_lineage_rework_block(db, gate_id, row_summary); return result
elif action=="reject":
    feedback = augmented_notes or "Rejected without notes"
    result = await reject_gate(db, gate_id, decided_by, feedback, reason_category, card_decisions, augmented_reviewer_notes, sort_applied, bulk_approved)
    await _persist_capability_lineage_rework_block(...); return result
elif action=="escalate":
    row=_get_gate_or_404; if status!='pending': raise 409 GATE_ALREADY_DECIDED
    reason = escalation_reason or notes or ""
    UPDATE gate SET status='escalated', decided_at=:now, decided_by=:by, justification=:reason WHERE id=:id
    _persist_card_review(db, gate_id, evidence_data, card_decisions, augmented_reviewer_notes, sort_applied, bulk_approved)
    commit; await _persist_capability_lineage_rework_block(...); logger.info("gate_escalated")
    return GateDetail(status='escalated', decided_at=now, decided_by)
else: raise 400 INVALID_ACTION
```
⚠️ NOTE: `submit_gate_decision` does NOT call `send_gate_temporal_signal` itself — the
router fires the Temporal signal separately after the DB transition.

---

## A3. `git_service.py` (865 lines) — GitHub-backed branch/commit/PR + merge/reconcile

Backed by **PyGithub**. Imports `BRANCH_PATTERN, CommitResult, FileReadResult, GitServiceConfig,
GitServiceError, MergeBranchProtectionRejected, MergeConflict, MergeDivergenceUnresolved, PRResult`
from `olympus_contracts`. Stateless; instantiate per portfolio/request.

### `_is_pr_already_exists(exc: GithubException) -> bool` (`git_service.py:38`)
True iff status==422 AND any `data.errors[].message` (case-insensitive) contains "already exists".

### `@dataclass RebaseResult` (`git_service.py:61`): `rebase_ran: bool`, `final_mergeable_state: str`.
### `@dataclass ReconcileMergeResult` (`git_service.py:80`): `merged, merge_sha, initial_mergeable_state, rebase_performed, final_mergeable_state`.

### `_UNMERGEABLE_STATE_TO_ERROR` (`git_service.py:106`) — ⚠️ CRITICAL mergeable_state classification:
```
"dirty"  → MergeConflict                  (content conflict — non-retryable)
"behind" → MergeDivergenceUnresolved      (PR behind base — retryable after rebase)
"blocked"→ MergeBranchProtectionRejected  (branch protection — non-retryable)
```
(`clean` = success; `unknown`/`draft` = transient lag handled by polling.)

### `GitService.__init__(config)` (`git_service.py:120`)
```
auth = Auth.Token(config.token); kwargs={"auth":auth}
if config.base_url and != "https://api.github.com": kwargs["base_url"]=config.base_url  # GH Enterprise
self._github = Github(**kwargs)
repo_slug = config.repo; strip "https://"/"http://" (→ owner/repo); strip("/"); strip trailing ".git"
try: self._repo = github.get_repo(repo_slug)
except GithubException: 404 → GitServiceError("not found or token lacks access"); else GitServiceError("Cannot connect")
```

### `create_branch(branch_name, base_branch="main") -> str (base_sha)` (`git_service.py:156`)
get_git_ref(heads/base) (404→GitServiceError "Base branch not found"); base_sha=ref.object.sha;
create_git_ref(refs/heads/branch, base_sha) (422→GitServiceError "already exists"; else "Failed").

### `_ensure_branch(branch, base_branch="main")` (`git_service.py:188`)
get_git_ref(heads/branch)→return if exists (404 falls through; other status re-raise);
else create from base; 422 (race) → return; else GitServiceError.

### `commit_file(branch, path, content, commit_message) -> CommitResult` (`git_service.py:213`)
```
if branch != "main": _ensure_branch(branch)
try: existing = get_contents(path, ref=branch); if list → GitServiceError "is a directory"
     result = update_file(path, message, content, sha=existing.sha, branch)
except GithubException: if 404 → result = create_file(path, message, content, branch); else GitServiceError "Failed to commit"
return CommitResult(commit_sha=result["commit"].sha, path, branch)
```

### `commit_files(branch, files: list[(path,content)], commit_message) -> CommitResult` (`git_service.py:255`)
Batch via blob+tree+commit (3-4 API calls regardless of N).
```
if not files: GitServiceError "requires at least one file"
if branch!="main": _ensure_branch(branch)
base_ref=get_git_ref(heads/branch); base_commit=get_git_commit(base_ref.object.sha); base_tree=base_commit.tree
for (path,content): blob=create_git_blob(content,"utf-8"); elements.append(InputGitTreeElement(path,mode="100644",type="blob",sha=blob.sha))
new_tree=create_git_tree(elements, base_tree=base_tree)
new_commit=create_git_commit(message, tree=new_tree, parents=[base_commit])
base_ref.edit(new_commit.sha)
(GithubException → GitServiceError "Batch commit failed")
return CommitResult(new_commit.sha, files[0][0], branch)
```

### `read_file(path, branch="main", commit_sha="") -> FileReadResult` (`git_service.py:317`)
```
ref = commit_sha if commit_sha else branch
contents = get_contents(path, ref=ref)  (GithubException → GitServiceError "not found on ref")
if list → GitServiceError "is a directory"
decoded = contents.decoded_content.decode("utf-8")
ref_sha = commit_sha if commit_sha else get_branch(branch).commit.sha
return FileReadResult(content=decoded, commit_sha=ref_sha, path)
```

### `create_pull_request(source_branch, target_branch, title, body, reviewers=None, labels=None) -> PRResult` (`git_service.py:353`)
Idempotent on duplicate-open-PR.
```
try: pr = create_pull(title, body, head=source_branch, base=target_branch); created=True
except GithubException as exc:
    if _is_pr_already_exists(exc):
        existing = _find_open_pr(source_branch, target_branch); if None → GitServiceError "Failed to create PR"
        try: existing.edit(title=title, body=body)   # refresh metadata
        except GithubException: logger.warning
        pr=existing; created=False
    else: GitServiceError "Failed to create PR"
if reviewers: pr.create_review_request(reviewers=...) (GithubException→warn)
if labels: pr.set_labels(*labels) (GithubException→warn)
return PRResult(pr_number, pr_url=pr.html_url, source_branch, target_branch)
```

### `_find_open_pr(source_branch, target_branch)` (`git_service.py:428`)
`head_spec=f"{repo.owner.login}:{source_branch}"`; `get_pulls(state="open", head=head_spec, base=target_branch)`; first or None (GithubException→None).

### `merge_pull_request(pr_number, merge_method="merge") -> dict{merged,merge_sha}` (`git_service.py:451`)
```
pr = _await_mergeability(pr_number)
if pr.merged: return {merged:True, merge_sha: pr.merge_commit_sha or ""}
if not pr.mergeable:
    state = pr.mergeable_state or "unknown"; error_cls = _UNMERGEABLE_STATE_TO_ERROR.get(state, GitServiceError)
    raise error_cls(f"PR #{n} is not mergeable (state: {state})")
result = pr.merge(merge_method=merge_method)   (GithubException → GitServiceError)
return {merged: result.merged, merge_sha: result.sha or ""}
```

### Mergeability polling (`git_service.py:507`): `_MERGEABILITY_POLL_ATTEMPTS=8`, `_MERGEABILITY_POLL_DELAY_SECONDS=1.5`
### `_await_mergeability(pr_number)` (`git_service.py:510`)
```
pr = get_pull(pr_number)  (GithubException → GitServiceError "not found")
if pr.merged: return pr
for attempt in range(8):
    state = pr.mergeable_state or "unknown"
    if pr.mergeable is not None and state != "unknown": return pr      # ⚠️ computed → return
    logger.info(...); time.sleep(1.5); pr = get_pull(pr_number)        # ⚠️ blocking sleep (sync call)
    if pr.merged: return pr
return pr   # still unknown after 8 → caller raises with real state
```
⚠️ Fixes 2026-05-05 Mezzanine bug: fresh PRs report mergeable=None/unknown until GitHub backend catches up.

### `rebase_pr_onto_base(pr_number) -> RebaseResult` (`git_service.py:549`)
```
pr = get_pull(pr_number)  (404→GitServiceError)
rebase_ran=False
try: rebase_ran = bool(pr.update_branch())                  # PUT /pulls/{n}/update-branch (202)
except GithubException as exc:
    if exc.status==422 and "up to date" in message.lower(): rebase_ran=False   # benign no-op
    else: GitServiceError "Failed to rebase"
refreshed = get_pull(pr_number)   (GithubException→GitServiceError "Failed to re-read after rebase")
final_state = refreshed.mergeable_state or "unknown"
return RebaseResult(rebase_ran, final_state)
```

### `reconcile_and_merge(pr_number, merge_method="merge") -> ReconcileMergeResult` (`git_service.py:606`)  ⚠️ CRITICAL merge orchestration
```
pr = _await_mergeability(pr_number)                # poll first
if pr.merged: return ReconcileMergeResult(merged=True, merge_sha=pr.merge_commit_sha or "", initial=pr.mergeable_state or "unknown", rebase_performed=False, final=...)
initial_state = pr.mergeable_state or "unknown"; rebase_performed=False; final_state=initial_state
if initial_state == "dirty":   raise MergeConflict(...)                    # non-retryable
if initial_state == "blocked": raise MergeBranchProtectionRejected(...)    # non-retryable
if initial_state == "behind":
    rebase = rebase_pr_onto_base(pr_number); rebase_performed=rebase.rebase_ran; final_state=rebase.final_mergeable_state
    if final_state=="behind":  raise MergeDivergenceUnresolved(...)        # raced — retryable
    if final_state=="dirty":   raise MergeConflict("conflicts after rebase")
    if final_state=="blocked": raise MergeBranchProtectionRejected("blocked after rebase")
# state should be "clean" (or optimistic "unknown") → hand to merge_pull_request
merge_result = merge_pull_request(pr_number, merge_method)
return ReconcileMergeResult(merged=merge_result["merged"], merge_sha=merge_result.get("merge_sha",""),
    initial_mergeable_state=initial_state, rebase_performed, final_mergeable_state=final_state)
```

### `validate_repo_access(*, require_push=True)` (`git_service.py:699`)
```
perms = self._repo.permissions; if perms is None: return   # ⚠️ some installs don't populate → treat as pass
if not perms.pull: GitServiceError "lacks read access"
if require_push and not perms.push: GitServiceError "lacks write access"
(GithubException: 404 → "not found or token lacks access"; else "Cannot access")
```

### `@staticmethod build_branch_name(line, app_id, step) -> str` (`git_service.py:740`): `f"olympus/{line}/{app_id}/{step}"`.

### `@staticmethod provision_repository(config, repo_slug, initial_readme="", private=True) -> (html_url, created)` (`git_service.py:748`)
W19 — backs `provision_target_repo`. Idempotent on slug.
```
if "/" not in repo_slug: GitServiceError "must be 'owner/name'"
owner,name = repo_slug.split("/",1)
gh = Github(auth, [base_url])
try: existing=gh.get_repo(repo_slug); return existing.html_url, False    # short-circuit reuse
except GithubException: if !=404 → GitServiceError "Cannot check repository"
try: org=gh.get_organization(owner); target=org
except GithubException: if !=404 → GitServiceError; else target=gh.get_user()   # user fallback
new_repo = target.create_repo(name, private, auto_init=True, description="Olympus modernization target repo …")
    (GithubException → GitServiceError "Failed to create repository")
if initial_readme: overwrite auto-init README.md (get sha, update_file) (GithubException→warn)
return new_repo.html_url, True
```

### `@staticmethod parse_branch_name(branch) -> dict|None` (`git_service.py:855`): `BRANCH_PATTERN.match(branch).groupdict()` → keys `line, app_id, step`; None if no match.

---

## A4. `wave.py` (2604 lines at HEAD) — wave lifecycle / assignment / progress / resume

Imports `temporalio.client.Client/WorkflowHandle`, `temporalio.service.RPCError/RPCStatusCode`,
`src.services.application as app_svc`. Most fns commit internally.

### Wave lifecycle state machine
`draft` → `ready` (mark_wave_ready) → `in_progress` (start_*) → {`completed`|`failed`|`stuck-awaiting-recovery`}.
Plus `cancelled` (from draft), revert `ready`→`draft`, reset `failed`/`stuck`→`ready`,
cancel-rationalization `in_progress`→`ready`, resume `stuck-awaiting-recovery`→`architecture-in-flight`.
Post-G-DA arch handoff statuses: `awaiting-architecture-dispatch`, `architecture-coordinator-started`,
`architecture-dispatched`, `architecture-in-flight`, `architecture-complete`.

### `get_or_create_draft_wave(db, portfolio_id) -> dict` (`wave.py:41`)
```
draft = SELECT id,portfolio_id,name,wave_number,status FROM wave WHERE portfolio_id=:pid AND status='draft' ORDER BY wave_number ASC LIMIT 1
if draft: return dict(draft)
max_num = SELECT COALESCE(MAX(wave_number),0) FROM wave WHERE portfolio_id=:pid   (or 0)
wave_number = max_num+1; wave_id=uuid4(); default_name=f"Wave {wave_number}"
INSERT INTO wave (id,portfolio_id,wave_number,name,status) VALUES (...,'draft')
return {id, portfolio_id:UUID(portfolio_id), name, wave_number, status:'draft'}   # ⚠️ caller commits
```

### `_load_draft_wave_for_onboard(db, portfolio_id, wave_id) -> dict` (`wave.py:103`)
404 WAVE_NOT_FOUND; 400 WAVE_PORTFOLIO_MISMATCH (str compare); 400 WAVE_NOT_DRAFT (status != 'draft').

### `bulk_onboard_apps(db, portfolio_id, application_ids, target_wave_id=None) -> WaveDetail` (`wave.py:145`)
```
if not application_ids: raise 400 EMPTY_APPLICATION_LIST
wave_row = _load_draft_wave_for_onboard(...) if target_wave_id else get_or_create_draft_wave(...)
wave_id = wave_row["id"]
# portfolio-mismatch guard
mismatched = SELECT id FROM application WHERE id=ANY(:ids) AND (portfolio_id IS NULL OR portfolio_id != :pid)
             # ⚠️ ids bound as [str(a) ...] (asyncpg rejects array-literal strings — F21 fix)
if mismatched: raise 400 APPLICATION_PORTFOLIO_MISMATCH
for app_id: INSERT INTO wave_application (wave_id,application_id) VALUES (...) ON CONFLICT DO NOTHING  # idempotent
commit
final_app_ids = SELECT application_id FROM wave_application WHERE wave_id=:wid
return WaveDetail(id, portfolio_id, name, wave_number, status, app_count=len, application_ids)
```

### `mark_wave_ready(db, wave_id, stakeholder) -> WaveDetail` (`wave.py:246`)
404 if missing; idempotent if already 'ready'; else if status!='draft' raise 400 WAVE_NOT_DRAFT;
else `UPDATE wave SET status='ready', updated_at=:now WHERE id=:id AND status='draft'`; commit;
returns WaveDetail(status='ready') with app_ids.

### `cancel_wave(db, wave_id, stakeholder="") -> WaveDetail` (`wave.py:319`)
404; idempotent on 'cancelled'; only 'draft' cancellable else 400 WAVE_NOT_CANCELLABLE;
`UPDATE … status='cancelled' WHERE id AND status='draft'`; commit; returns status='cancelled'.

### `revert_wave_to_draft(db, wave_id, stakeholder="") -> WaveDetail` (`wave.py:392`)
404; idempotent on 'draft'; only 'ready' revertible else 400 WAVE_NOT_REVERTIBLE; ⚠️ also 400
WAVE_NOT_REVERTIBLE if `workflow_id` set (safety net under live workflow); `UPDATE … status='draft' WHERE id AND status='ready'`; commit.

### `start_wave_rationalization(db, wave_id, temporal_client, task_queue, stakeholder="") -> WaveStartResponse` (`wave.py:476`)
```
row = SELECT id,portfolio_id,name,status,workflow_id FROM wave WHERE id=:id; None→404
if status not in ('draft','ready'): raise 400 WAVE_NOT_STARTABLE
if workflow_id: raise 409 WAVE_ALREADY_RUNNING
app_ids = SELECT application_id FROM wave_application WHERE wave_id=:wid
if not app_ids: raise 400 WAVE_EMPTY
artifact_repo = SELECT artifact_repo_url FROM portfolio WHERE id=:id  (or "")
workflow_id = f"wave-rationalization-{wave_id}"
input_dict = {wave_id:str, wave_name, portfolio_id:str, app_ids, artifact_repo, stakeholder}
await temporal_client.start_workflow("WaveRationalizationWorkflow", input_dict, id=workflow_id, task_queue)
UPDATE wave SET workflow_id=:wfid, status='in_progress', actual_start=:actual_start, updated_at=:updated_at WHERE id=:id
    # ⚠️ actual_start = now.date() (DATE col), updated_at = now (timestamptz) — SEPARATE params (asyncpg type deduce)
commit; logger.info
return WaveStartResponse(workflow_id, temporal_ui_url="http://localhost:8080/namespaces/default/workflows/{id}", status="started")
```

### `cancel_wave_rationalization(db, wave_id, temporal_client, config, stakeholder="") -> WaveCancelRationalizationResponse` (`wave.py:598`)
```
row = SELECT id,portfolio_id,name,wave_number,status,description,workflow_id WHERE id; None→404
if status != 'in_progress' or not workflow_id: raise 409 WAVE_NOT_RUNNING
handle = temporal_client.get_workflow_handle(workflow_id)
try: await handle.signal("cancel_workflow")           # signal-first (clean unwind)
except RPCError: logger.warning (continue — DB reset still happens)
# hammer fallback (fire-and-forget asyncio.create_task)
async _hammer(): sleep(config.workflow_cancel_grace_seconds); if describe().status.name=="RUNNING": handle.cancel()
asyncio.create_task(_hammer())
UPDATE wave SET status='ready', workflow_id=NULL, actual_start=NULL, updated_at=:now WHERE id=:id   # ⚠️ resets to 'ready' (cohort locked)
commit; logger.info
return WaveCancelRationalizationResponse(wave_id, workflow_id, requested=True, detail=...)
```

### `retry_wave_rationalization(db, wave_id, temporal_client, task_queue, config, stakeholder="") -> WaveStartResponse` (`wave.py:727`)
404; if in_progress+workflow_id: try cancel_wave_rationalization (swallow WAVE_NOT_RUNNING, re-raise others);
then `return await start_wave_rationalization(...)`.

### `reset_wave_to_ready(db, wave_id, stakeholder="") -> WaveResetResponse` (`wave.py:780`)
```
row = SELECT … WHERE id; None→404
if status not in ('failed','stuck-awaiting-recovery'): raise 409 WAVE_NOT_FAILED
previous_workflow_id = row.workflow_id
UPDATE wave SET status='ready', workflow_id=NULL, failed_at=NULL, failure_reason=NULL, actual_start=NULL, updated_at=:now
       WHERE id=:id AND status IN ('failed','stuck-awaiting-recovery')   # ⚠️ guarded against concurrent flip
commit; logger.info
return WaveResetResponse(wave_id, previous_workflow_id, status="ready", detail=...)
```

### `start_wave(db, wave_id, temporal_client, task_queue, max_apps_per_wave=10) -> WaveStartResponse` (`wave.py:878`)
Starts `WaveWorkflow` (per-app pipeline coordinator, distinct from WaveRationalizationWorkflow).
Same guards as start_wave_rationalization (404 / 400 WAVE_NOT_STARTABLE / 409 WAVE_ALREADY_RUNNING);
workflow_id = `f"wave-{wave_id}"`; input adds `max_apps_per_wave`; same UPDATE+commit; returns WaveStartResponse.

### `get_wave_app_progress(db, wave_id) -> WaveAppProgressResponse` (`wave.py:1009`)
```
from src.services.application import STEP_PROGRESS    # local import (cycle break)
wave = SELECT id,status FROM wave WHERE id; None→404
if status != 'in_progress': raise 400 WAVE_NOT_IN_PROGRESS
rows = SELECT a.id,a.name,a.current_line,a.current_step,a.current_status FROM application a
       JOIN wave_application wa ON wa.application_id=a.id WHERE wa.wave_id=:wid ORDER BY a.name
for r: progress_pct = STEP_PROGRESS.get((current_line,current_step)) if both set else None   # None ⇒ UI shows dash
return WaveAppProgressResponse(wave_id, apps=[WaveAppProgress(app_id,app_name,current_line,current_status,progress_pct)])
```

### `_count_apps_in_wave(db, wave_id) -> int` (`wave.py:1097`): `SELECT COUNT(*) FROM wave_application WHERE wave_id=:wid`.

### `assign_apps_to_wave(db, target_wave_id, application_ids, stakeholder="") -> WaveDetail` (`wave.py:1110`)
P5-S28 PR3 cohort-lock move.
```
if not application_ids: raise 400 EMPTY_APPLICATION_LIST
target = SELECT id,portfolio_id,name,wave_number,status WHERE id; None→404
if target.status != 'draft': raise 400 WAVE_NOT_DRAFT
str_ids = [str(a)...]
mismatched = SELECT id FROM application WHERE id=ANY(:ids) AND (portfolio_id IS NULL OR != :pid); if any → 400 APPLICATION_PORTFOLIO_MISMATCH
# cohort-lock: source waves (other than target) must all be draft
source_rows = SELECT DISTINCT w.id,w.status FROM wave_application wa JOIN wave w ON w.id=wa.wave_id
              WHERE wa.application_id=ANY(:ids) AND w.id != :target
locked = [w.id for w in source_rows if status != 'draft']; if locked → raise 400 SOURCE_WAVE_LOCKED
DELETE FROM wave_application WHERE application_id=ANY(:ids) AND wave_id != :target   # detach from draft sources
for app_id: INSERT INTO wave_application VALUES (target, app_id) ON CONFLICT DO NOTHING
commit; logger.info
return WaveDetail(target.., app_count, application_ids)
```

### `remove_apps_from_wave(db, wave_id, application_ids, stakeholder="") -> WaveDetail` (`wave.py:1255`)
400 EMPTY_APPLICATION_LIST; 404; 400 WAVE_NOT_DRAFT if not draft;
`DELETE FROM wave_application WHERE wave_id=:wid AND application_id=ANY(:ids)`; commit; returns updated WaveDetail.

### Progress panel (Task #95)
`_truncate_error(msg, limit=500)` (`wave.py:1339`): truncate to 500 + "…".
`_load_step_timeline(db, wave_id, workflow_id) -> list[WaveProgressStep]` (`wave.py:1355`):
```
rows = SELECT step_id,line_id,status::text,started_at,completed_at,duration_ms,step_kind::text,agent_task_id
       FROM step_execution WHERE wave_id=:wave_id OR workflow_id=:workflow_id   # ⚠️ union by wave_id OR workflow_id
       ORDER BY started_at ASC NULLS LAST, step_id ASC
if not rows: return []
# batch-resolve agent_task (task_type, skill_id) by agent_task_id (single round-trip, avoid N+1)
task_meta = SELECT id,task_type,skill_id FROM agent_task WHERE id=ANY(:ids)
return [WaveProgressStep(step_id,line_id,status.lower(),started_at,completed_at,duration_ms=int,skill_id,task_type,step_kind)]
```
`_extract_failure_reason(db, workflow_id, wave_id) -> str|None` (`wave.py:1441`):
latest non-empty `step_execution.last_error` (wave_id OR workflow_id, ORDER BY completed_at DESC), then fallback
`agent_task.last_error` (status IN failed/timed_out). ⚠️ deliberately NOT full Temporal history scan (too heavy for 5s polling).
`_temporal_ui_url(config, workflow_id)` (`wave.py:1497`): `{config.temporal_ui_base_url}/namespaces/{ns}/workflows/{id}`.
`_REPORTED_STATUS_TO_TEMPORAL` (`wave.py:1509`): completed→COMPLETED, failed→FAILED, cancelled/canceled→CANCELED,
stuck-awaiting-recovery→FAILED, in_progress/architecture-in-flight→RUNNING, ready/draft→None.

### `get_wave_progress(db, wave_id, temporal, config) -> WaveProgressResponse` (`wave.py:1533`)  ⚠️ CRITICAL Temporal-vs-DB reconciliation
```
wave_row = SELECT id,status,workflow_id,actual_start,updated_at,created_at,
    CASE WHEN created_at IS NOT NULL THEN EXTRACT(EPOCH FROM (NOW()-created_at))::bigint ELSE NULL END AS wave_elapsed_seconds
    FROM wave WHERE id; None→404
workflow_id = wave_row.workflow_id; if not: raise 409 WAVE_WORKFLOW_NOT_STARTED
current_step_elapsed = SELECT EXTRACT(EPOCH FROM (NOW()-started_at))::bigint FROM agent_task
    WHERE workflow_id=:wf AND started_at NOT NULL AND completed_at IS NULL AND status IN ('queued','running','dispatched')
    ORDER BY started_at DESC LIMIT 1    (else None)
response = WaveProgressResponse(wave_id:UUID, workflow_id, reported_status=status, temporal_ui_url,
    step_timeline=_load_step_timeline(...), wave_elapsed_seconds, current_step_elapsed_seconds)
handle = temporal.get_workflow_handle(workflow_id)
try: desc = await handle.describe()
except RPCError as e:
    is_not_found = e.status==NOT_FOUND or "workflow not found"/"workflow execution not found" in str(e).lower()
    if is_not_found:                              # ⚠️ aged-out of retention → synthesize from DB
        response.status = _temporal_status_from_reported(status)
        response.last_error = _extract_failure_reason(...) if status in (FAILED,TIMED_OUT) else None
        return response
    response.temporal_unreachable = True; return response   # genuine outage
response.status = desc.status.name; response.started_at = desc.start_time
if started_at: response.duration_seconds = int((now - start.tz-aware).total_seconds())
try: status = await handle.query("get_status")
except RPCError: status=None
if isinstance(status,dict):
    response.current_step = status.get("current_step") or None
    response.progress_pct = float(progress_pct) if numeric
    response.updated_at = datetime.fromisoformat(updated_at.replace("Z","+00:00")) if str (ValueError→None)
if temporal_status in (FAILED,TIMED_OUT): response.last_error = _extract_failure_reason(...)
if response.updated_at is None: response.updated_at = wave_row.updated_at
return response
```

### Fan-out gate queue
`_PENDING_GATE_STATUSES` (`wave.py:1748`) = (`pending`,`preparing`,`escalated`,`merge_blocked`) — excludes terminal.
`_FANOUT_GATE_TYPES` (`wave.py:1759`) = (`G-02`,`G-DT`).
`list_pending_fanout_gates(db, wave_id) -> WavePendingGatesResponse` (`wave.py:1762`)
```
wave = SELECT id FROM wave WHERE id; None→404
sql = WITH fanout_gates AS (
   SELECT g.id FROM gate g WHERE g.wave_id=:wave_id AND gate_type=ANY(:gate_types) AND status=ANY(:statuses)   -- direct (defensive)
   UNION
   SELECT g.id FROM gate g JOIN wave_application wa ON wa.application_id=g.application_id WHERE wa.wave_id=:wave_id AND ...  -- apps in wave
   UNION
   SELECT g.id FROM gate g JOIN application_lineage al ON al.target_app_id=g.application_id
       JOIN wave_application wa ON wa.application_id=al.source_app_id WHERE wa.wave_id=:wave_id AND ...   -- target-app lineage (projection lag)
) SELECT g.id gate_id, g.gate_type, g.application_id, a.name application_name, g.evidence_package_url pr_url, g.requested_at opened_at
  FROM gate g LEFT JOIN application a ON a.id=g.application_id WHERE g.id IN (SELECT id FROM fanout_gates)
  ORDER BY g.requested_at ASC NULLS LAST, g.id ASC
return WavePendingGatesResponse(pending=[WavePendingGateEntry(.., reviewer_scope_required=[])])
```

### Cancel-all-children routing
`_RATIONALIZATION_OWNED_CANCEL_STATUSES` (`wave.py:1883`) = {draft, ready, in_progress, rationalization-rework}.
`_ARCHITECTURE_OWNED_CANCEL_STATUSES` (`wave.py:1891`) = {awaiting-architecture-dispatch, architecture-coordinator-started, architecture-dispatched, architecture-in-flight, architecture-complete}.
`cancel_all_wave_children(db, wave_id, temporal_client, config, stakeholder="") -> WaveCancelAllChildrenResponse` (`wave.py:1902`)
```
row = SELECT id,workflow_id,architecture_workflow_id,status WHERE id; None→404
if status in ARCH_OWNED: target=architecture_workflow_id; if None → raise 409 ARCHITECTURE_COORDINATOR_NOT_STARTED
elif status in RAT_OWNED: target=workflow_id; if None → raise 409 WAVE_HAS_NO_WORKFLOW
else: raise 409 WAVE_NOT_CANCELLABLE
handle.signal("cancel_all_children")  (RPCError → warn, idempotent); logger.info
return WaveCancelAllChildrenResponse(wave_id, cancelled_at=now)
```

### Resume fan-out (operator recovery)
`_target_workflow_is_live(temporal_client, workflow_id) -> (is_live, status_name)` (`wave.py:2015`): describe();
RPCError→(False,None); else `(status.name=="RUNNING", status.name)`.
`_seed_lineage_from_artifacts(db, wave_uuid, portfolio_id, artifact_repo, config, filter_target_ids) -> list[dict]` (`wave.py:2037`):
delegates to `wave_target_provisioning.seed_targets_from_artifacts`; flushes inserts (`db.flush()`); returns lineage-shaped rows.
`_lineage_relationship_for_seeded(disposition)` (`wave.py:2115`): Replace→"replace", Consolidate→"consolidate", else f"{disposition.lower()}-of".

### `resume_wave_fanout(db, wave_id, temporal_client, task_queue, request=None, config=None) -> WaveResumeResponse` (`wave.py:2124`)  ⚠️ CRITICAL respawn loop
```
wave_row = SELECT id,portfolio_id,name,status WHERE id; None→404
artifact_repo = SELECT artifact_repo_url FROM portfolio WHERE id=:pid (or "")
filter_ids = [str(tid)...] if request.target_app_ids else []
lineage_sql = SELECT DISTINCT al.target_app_id, al.source_app_id, al.relationship,
    t.name target_name, t.target_repo_url, t.current_status target_status, s.name source_name
    FROM application_lineage al JOIN wave_application wa ON wa.application_id=al.source_app_id
    JOIN application t ON t.id=al.target_app_id JOIN application s ON s.id=al.source_app_id
    WHERE wa.wave_id=:wid [AND al.target_app_id=ANY(:targets)]
    # ⚠️ target repo = t.target_repo_url, NOT t.repo_url (source/legacy URL)
lineage_rows = exec(...)
if not lineage_rows:
    lineage_rows = await _seed_lineage_from_artifacts(...)    # Task #86 A1: seed from disposition-recommendation artifacts
    if not lineage_rows: raise 409 WAVE_NO_ARTIFACTS_TO_SEED
# collapse by target (Consolidate has N sources per target)
targets = {tid: {target_app_id, target_name, target_repo_url, target_status, source_app_ids:[...]}}
run_ts = int(now.timestamp()); respawned=already_running=failed=0; results=[]
for target in targets.values():
    if target_status == "consolidated_into_target":   # skip Consolidate source rows
        results.append(WaveResumeTargetResult(architecture_action="skipped", data_action="skipped", detail=...)); continue
    arch_wf_id=f"architecture-{tid}-{run_ts}"; data_wf_id=f"data-{tid}-{run_ts}"
    app_row = SELECT workflow_id FROM application WHERE id=:tid
    canonical_arch_id = app_row.workflow_id if startswith("architecture-") else None
    existing_arch = canonical_arch_id or arch_wf_id; arch_live,_ = _target_workflow_is_live(existing_arch)
    data_probe_ids = [data_wf_id] (+ canonical_arch_id.replace("architecture-","data-",1) prepended if canonical)
    data_live = any(_target_workflow_is_live(probe) for probe in data_probe_ids)
    arch_action = "already-running" if arch_live else "respawned"; data_action similarly
    if arch_live and data_live: already_running+=2; results.append(...both RUNNING...); continue
    data_prior = for each source: ["discovery/{src}/data-domains.json", "discovery/{src}/shared-db-analysis.json"]
    arch_input = {app_id:tid, app_name, wave_id, portfolio_id, artifact_repo, target_repo_url, disposition:None, peer_workflow_ids:{Data:data_wf_id}}
    data_input = {... peer_workflow_ids:{Architecture:arch_wf_id}, prior_artifacts:data_prior}
    try:
        if not arch_live: start_workflow("ArchitectureWorkflow", arch_input, id=arch_wf_id, task_queue); respawned+=1
        if not data_live: start_workflow("DataWorkflow", data_input, id=data_wf_id, task_queue); respawned+=1
        if arch_live: already_running+=1; if data_live: already_running+=1
        results.append(WaveResumeTargetResult(arch_action, data_action, detail))
    except Exception: failed+=2; logger.warning("wave.resume.spawn_failed"); results.append(...failed...)
if wave_row.status=="stuck-awaiting-recovery" and (respawned+already_running)>0:
    UPDATE wave SET status='architecture-in-flight', updated_at=:now WHERE id AND status='stuck-awaiting-recovery'   # ⚠️ unstuck
    commit  (deliberately does NOT clear failure_reason/failed_at — audit trail; only /reset clears those)
return WaveResumeResponse(wave_id, targets=results, respawned_count, already_running_count, failed_count, detail)
```

### `get_wave_app_activity(db, wave_id: UUID) -> WaveAppActivityResponse` (`wave.py:2476`)
Per-app capability/system grain + latest agent activity (Phase 5 #149+#150).
```
wave = SELECT id FROM wave WHERE id; None→404
app_rows = SELECT a.id,a.name FROM wave_application wa JOIN application a ON a.id=wa.application_id WHERE wa.wave_id=:wid ORDER BY a.name
for r:
    target_systems = await app_svc.fetch_target_systems_for_app(db, app_id)
    realizes_capability = await app_svc.fetch_realizes_capability_for_app(db, app_id)
    per_line = await app_svc.fetch_agent_activity_by_line(db, app_id)
    latest = max(per_line, key=lambda s: s.completed_at or s.started_at or datetime.min(tz=utc)) if per_line else None
    items.append(WaveAppActivityRow(application_id, application_name, target_systems, realizes_capability, latest_activity=latest))
return WaveAppActivityResponse(wave_id, items)
```

---

## A5. `step_mapping.py` (986 lines at HEAD) — (line,step) → skill / task_type / gate registry

⚠️ Mirrors `dashboard/src/components/WorkflowStepper/stepRegistry.ts`; CI lint
`scripts/verify-step-registry.ts`/`verify_step_registry.py` keeps them in sync.
No DDL: derives relevant task_types per step from these maps (does not add line/step cols to agent_task).

### Contract-driven step lists
`_LINE_NAME_BY_ENUM` (`step_mapping.py:42`): `AssemblyLine` enum → title-case name (all 10).
`_steps_for_contract(line)` (`step_mapping.py:56`): `_get_line_contract(name).step_ids()` from olympus_contracts, [] if unknown.
`LINE_STEP_IDS` (`step_mapping.py:63`): `{line: _steps_for_contract(line)}` — workflow superset, contract-driven at import.
`UI_STEP_IDS` (`step_mapping.py:76`): per-line UI-stepper subset. Most lines = `list(LINE_STEP_IDS[line])`. EXCEPTIONS:
- `MODERNIZATION` = `["extract","design","generate"]` (3 aggregated phases; contract has 33 substeps).
- `DISPOSITION_EXECUTION` = explicit 41-element literal (flat union of per-disposition substeps in frontend splice order — see file for exact ordering: pre-gate union → G-DE-1 boundary → post-gate union → G-DE-2 boundary → persist).

### Registries (hand-mapped, `step_mapping.py:165`–879)
- `_TASK_TYPES: dict[(AssemblyLine,step) → list[str]]` — `agent_task.task_type` strings per step.
  Naming pattern `{line}-{step_id}` (e.g. `discovery-catalog`, `architecture-target-state-mapping`,
  `validation-functional-parity`). Wave/Rationalization use `wave-*` / `wave-per-app-*` / `rationalization-*`.
  Disposition uses `disposition-{disposition}-{step}` (a step may map to MULTIPLE variants, e.g.
  `data-migration` → `[disposition-replace-data-migration, disposition-replatform-data-migration]`).
  Git/gate/code steps → `[]`. `ai-pre-review*` steps → `["gate-pre-review"]` (or line-specific `architecture-ai-pre-review`).
- `_SKILLS: dict[(AssemblyLine,step) → list[str]]` — skill IDs per step (e.g. Discovery catalog → `[catalog-application]`;
  Modernization extract → `[extraction, cross-validation]`, design → `[module-design, api-specification, data-modeling]`,
  generate → `[tdd-generation, test-validation, style-greenfield, style-brownfield]`). Code/git/gate steps → `[]`.
- `_GATES: dict[(AssemblyLine,step) → GateType]` (`step_mapping.py:859`) — only gate-bearing steps:
  ```
  (Discovery,gate-review)→G_DC; (Rationalization,gate-review-rr)→G_RR; (Rationalization,gate-review-da)→G_DA;
  (Architecture,gate-review-02)→G_02; (Data,gate-review-dt)→G_DT;
  (Modernization,extract)→G_04A; (Modernization,design)→G_04B; (Modernization,generate)→G_04C;
  (DispositionExecution,gate-review-de1)→G_DE_1; (…gate-review-de2)→G_DE_2;
  (Validation,functional-parity)→G_V1; (…security-compliance)→G_V2; (…safety-assurance)→G_V3;
  (Deployment,gate-review-dp1)→G_DP_1; (…gate-review-dp2)→G_DP_2
  ```
  ⚠️ Modernization gates attach to the agent step (extract/design/generate), NOT separate gate-review steps.

### Public helpers
- `is_known_step(line, step) -> bool` (`step_mapping.py:887`): `step in LINE_STEP_IDS.get(line, [])`.
- `steps_for(line) -> list[str]` (`step_mapping.py:892`): `list(LINE_STEP_IDS.get(line, []))` (workflow superset).
- `ui_steps_for(line) -> list[str]` (`step_mapping.py:902`): `list(UI_STEP_IDS.get(line, []))` (UI subset).
- `task_types_for(line, step) -> list[str]` (`step_mapping.py:912`): `list(_TASK_TYPES.get((line,step), []))`.
- `skills_for(line, step) -> list[str]` (`step_mapping.py:921`): `list(_SKILLS.get((line,step), []))`.
- `gate_for(line, step) -> GateType|None` (`step_mapping.py:926`): `_GATES.get((line,step))`.
- `task_type_to_line_map() -> dict[str, AssemblyLine]` (`step_mapping.py:931`): invert `_TASK_TYPES`; first line wins on collision (`setdefault`, deterministic via StrEnum order).

---

## A6. `application.py` (1835 lines at HEAD) — application CRUD + step execution aggregation

### `_load_step_progress() -> dict[(line,step) → float]` (`application.py:41`)
```
for name in line_names():                      # olympus_contracts
    for step_id,pct in _line_progress(name).items(): mapping[(name,step_id)]=float(pct)
    mapping[(name,"completed")] = 100.0        # ⚠️ synthetic terminal at 100
```
`STEP_PROGRESS` (`application.py:60`) = `_load_step_progress()` — built at import; contract-driven (CI drift guard
rejects hardcoded copies). ⚠️ Also imported by `wave.get_wave_app_progress`.

### `_fetch_latest_scores(db, app_id) -> ReadinessScores|None` (`application.py:63`)
```
rows = SELECT dimension,score FROM score_history WHERE application_id=:app_id
       AND recorded_at = (SELECT MAX(recorded_at) FROM score_history WHERE application_id=:app_id)
if not rows: return None
scores = {dimension: float(score)}
return ReadinessScores(overall, code_quality, test_coverage, security_posture, documentation,
                       dependency_currency, architecture_clarity)   # .get each — None if absent
```
⚠️ NOTE: returns RAW scores (no `_normalize_score`), unlike scoring.py.

### `fetch_target_systems_for_app(db, app_id) -> list[SystemRef]` (`application.py:96`)
```
SELECT s.id,s.name,s.external_id,s.kind,sa.role FROM system_application sa JOIN system s ON s.id=sa.system_id
WHERE sa.application_id=:app_id AND s.retired_at IS NULL
ORDER BY CASE sa.role WHEN 'primary' THEN 0 WHEN 'contributing' THEN 1 WHEN 'deprecated' THEN 2 ELSE 3 END,
         COALESCE(s.external_id,s.name) ASC
→ [SystemRef(id,name,external_id,kind,role)]
```

### `fetch_realizes_capability_for_app(db, app_id) -> CapabilityRef|None` (`application.py:139`)
```
meta = SELECT metadata FROM application WHERE id=:id
capability_id = UUID(metadata["capability_id"]) if metadata is dict and str (else None)
if capability_id is None: return None            # ⚠️ relies solely on metadata.capability_id
cap_row = SELECT c.id,c.name,c.external_id,c.system_id,c.primary_disposition,c.secondary_disposition,
          s.name system_name,s.external_id system_external_id FROM capability c JOIN system s ON s.id=c.system_id
          WHERE c.id=:id AND c.retired_at IS NULL; if None return None
# M:N target systems (this capability is source; dedup by target system)
target_rows = SELECT DISTINCT ts.id,ts.name,ts.external_id,ts.kind FROM capability_lineage cl
   JOIN capability tc ON tc.id=cl.target_capability_id JOIN system ts ON ts.id=tc.system_id
   WHERE cl.source_capability_id=:cap_id AND cl.target_capability_id IS NOT NULL AND ts.retired_at IS NULL
   ORDER BY COALESCE(ts.external_id,ts.name) ASC
return CapabilityRef(id,name,external_id,system_id,system_name,system_external_id,primary/secondary_disposition, target_systems)
```

### `_coerce_local_agent_descriptor(raw)` (`application.py:249`): identical to gate.py:43 (dict, non-empty str tool).

### `fetch_agent_activity_by_line(db, app_id) -> list[AgentActivitySummary]` (`application.py:269`)
```
rows = SELECT DISTINCT ON (COALESCE(se.line_id,'unknown')) at.id task_id, se.line_id, at.skill_id,
        at.task_type, at.status, at.actor_kind, at.local_agent_descriptor, at.human_user_id,
        at.started_at, at.completed_at, COALESCE(at.completed_at,at.started_at,at.dispatched_at) recency_ts
       FROM agent_task at LEFT JOIN step_execution se ON se.agent_task_id=at.id WHERE at.application_id=:app_id
       ORDER BY COALESCE(se.line_id,'unknown'), COALESCE(at.completed_at,at.started_at,at.dispatched_at) DESC NULLS LAST
line_slug_to_name = {n.lower().replace(" ","-"): n for n in AssemblyLineName}    # discovery→Discovery etc.
for r:
    line_raw = r.line_id; line=None
    if str and != "unknown": line = line_slug_to_name.get(line_raw) or try AssemblyLineName(line_raw) (ValueError→None)
    summaries.append(AgentActivitySummary(task_id, line, skill_id, task_type, status,
        actor_kind=at.actor_kind or "olympus_agent", local_agent_descriptor=_coerce(...), human_user_id, started_at, completed_at))
summaries.sort(key=lambda s: (s.line is None, s.line or ""))   # real lines first (alpha), unknown last
```

### `_resolve_capability_id(db, *, capability_id, capability_external_id, target_system_id, portfolio_id) -> UUID|None` (`application.py:357`)
```
if capability_id is not None:
    if target_system_id is not None:
        row = SELECT system_id FROM capability WHERE id=:id AND retired_at IS NULL
        if None: raise 422 CAPABILITY_NOT_FOUND
        if row.system_id != target_system_id: raise 422 CAPABILITY_SYSTEM_MISMATCH
    return capability_id
if not capability_external_id: return None
if target_system_id is not None: row = SELECT id FROM capability WHERE external_id=:ext AND system_id=:sid AND retired_at IS NULL
else: row = SELECT c.id FROM capability c JOIN system s ON s.id=c.system_id WHERE c.external_id=:ext AND s.portfolio_id=:pid AND both retired_at IS NULL LIMIT 1
if None: raise 422 CAPABILITY_EXTERNAL_ID_NOT_FOUND
return row.id
```

### `_validate_source_repo(body, config)` (`application.py:448`)
```
token = body.source_git_token or config.github_token; base_url = body.source_git_base_url or config.github_base_url
if not token: raise 422 GIT_NOT_CONFIGURED
try: GitService(GitServiceConfig(token, repo=body.repository_url, base_url)).validate_repo_access(require_push=False)
except GitServiceError as exc: raise 422 REPO_VALIDATION_FAILED (str(exc))
except Exception: logger.error; raise 422 REPO_VALIDATION_FAILED
```

### `create_application(db, body, portfolio_id, *, app_id=None, intake_result=None) -> ApplicationDetail` (`application.py:483`)
```
is_non_git = body.source_type != SourceType.GIT
if not is_non_git and not body.skip_repo_validation: _validate_source_repo(body, AppConfig())
app_id = app_id or uuid4(); now=utcnow()
effective_repo_url = intake_result.local_path if intake_result else body.repository_url   # non-git → local path
resolved_capability_id = await _resolve_capability_id(db, capability_id=body.realizes_capability_id, external=..., target_system_id, portfolio_id)
if body.target_system_id is not None:
    sys_row = SELECT id FROM system WHERE id=:id AND portfolio_id=:pid AND retired_at IS NULL; if None → 422 SYSTEM_NOT_FOUND
initial_metadata = {"capability_id": str(resolved_capability_id)} if resolved else {}
INSERT INTO application (id,portfolio_id,name,description,repo_url,source_git_token,source_git_base_url,
    risk_tier,complexity_tier,current_status='onboarded',metadata=CAST(:json AS JSONB),created_at,updated_at)
    # ⚠️ source_git_token/base_url left NULL for non-git; risk_tier = str(body.risk_tier.value) if set
if body.target_system_id: INSERT INTO system_application (system_id,application_id,role='primary',created_at) ON CONFLICT DO NOTHING
commit
return ApplicationDetail(id, name, description, repository_url=effective_repo_url, risk_tier,
    risk_tier_source="auto" if set else None, complexity_tier, complexity_tier_source="auto" if set,
    status="onboarded", tags=body.tags, created_at=now, updated_at=now)
```

### `list_applications(db, pagination=None, portfolio_id=None, portfolio_ids=None) -> tuple|list` (`application.py:649`)
Standard allowlist clauses (empty allowlist → `clauses.append("FALSE")`). count = `SELECT count(*) FROM application {where}`.
With pagination: `SELECT * … ORDER BY created_at DESC LIMIT :limit OFFSET :offset` → `(items, total)`; else all rows → `items`.
Maps each row to `ApplicationDetail(id,name,description,repository_url=repo_url,target_repo_url,target_git_base_url,
disposition,risk_tier=int if set,risk_tier_source,complexity_tier,complexity_tier_source,current_line,status=current_status,metadata or {},created_at,updated_at)`.

### `get_application(db, app_id) -> ApplicationDetail` (`application.py:735`)
`SELECT * FROM application WHERE id`; None→404 APP_NOT_FOUND. Enriches (each best-effort): `_fetch_latest_scores`,
`fetch_target_systems_for_app`, `fetch_realizes_capability_for_app`, `fetch_agent_activity_by_line`. Returns ApplicationDetail
with `scores, target_systems, realizes_capability, agent_activity_by_line`.

### `update_application(db, app_id, body) -> ApplicationDetail` (`application.py:789`)
`SELECT id`; None→404. Build field_map from non-None body fields (name, description, repo_url, target_repo_url,
target_git_token, target_git_base_url, risk_tier=str(value), complexity_tier=value, disposition=value). If field_map:
`UPDATE application SET <cols>, updated_at=:now WHERE id`; commit. Returns `get_application(db, app_id)`.

### `get_application_status(db, app_id) -> ApplicationStatus` (`application.py:841`)  ⚠️ HARDENED (P5-AUDIT-002)
```
row = SELECT * FROM application WHERE id; None→404
gate_rows = SELECT * FROM gate WHERE application_id=:app_id ORDER BY requested_at
gates=[]
for g in gate_rows:
    try: gates.append(GateSummaryForStatus(id,gate_type,status,sla_deadline,decided_at,reject_reason_category,justification))
    except Exception: logger.warning("application_status.skip_unrecognised_gate"); continue   # ⚠️ skip bad enum rows, never 500
pending_gate = first gate where status=='pending' → gate_type (try/except→None)
current_line=row.current_line; current_step=row.current_step
progress_pct = STEP_PROGRESS.get((current_line,current_step)) if both set else None
try: return ApplicationStatus(app_id, current_line, current_step, progress_pct, pending_gate,
        workflow_status=current_status, workflow_id, gates, updated_at)
except Exception: logger.warning("application_status.fallback_envelope")    # ⚠️ last-ditch: empty-but-valid envelope
     return ApplicationStatus(app_id, current_line=None, current_step=None, progress_pct=None, pending_gate=None,
        workflow_status="pending", workflow_id, gates=[], updated_at)
```

### `start_discovery(db, app_id, temporal_client, task_queue) -> DiscoverResponse` (`application.py:970`)
```
row = SELECT id,name,portfolio_id,current_status,repo_url FROM application WHERE id; None→404
if current_status == "discovery_in_progress": raise 409 DISCOVERY_ALREADY_RUNNING
artifact_repo = SELECT artifact_repo_url FROM portfolio WHERE id=:id (or "")
run_ts=int(now.timestamp()); workflow_id=f"discovery-{app_id}-{run_ts}"
await temporal_client.start_workflow("DiscoveryWorkflow", {app_id:str, app_name, wave_id:"", portfolio_id:str, artifact_repo, source_repo: repo_url or ""}, id=workflow_id, task_queue)
UPDATE application SET current_status='discovery_in_progress', current_line='Discovery', current_step='catalog-dispatch', workflow_id=:wfid, updated_at=:now WHERE id
commit
return DiscoverResponse(workflow_id, temporal_ui_url="http://localhost:8080/namespaces/default/workflows/{id}")
```

### Step execution aggregation helpers
`_looks_like_artifact_path(value) -> bool` (`application.py:1054`): reject prose; True iff non-empty, ≤512 chars, no newline,
and not (has space without `/`,`\`, or `.ext`).
`_artifact_from_ref(ref, artifact_type) -> StepArtifactRef|None` (`application.py:1074`): str → path filter then ref; dict → path/url, title=basename, created_at parse.
`_status_from_task_rows(rows) -> str` (`application.py:1107`): ⚠️ status precedence:
```
if not rows: "not_started"
if "failed" in statuses: "failed"
if "timed_out": "timed_out"
if running|dispatched present: "running"
if "queued" and no (completed/failed/timed_out/running/dispatched): "queued"
if statuses ⊆ {completed}: "completed"
else "running"
```
`_LINE_ORDER` (`application.py:1130`): 10-line canonical order list.
`_infer_status_from_progress(line, step, app_current_line, app_current_step) -> str|None` (`application.py:1144`):
for orchestration-only steps (no agent_task). steps=steps_for(line); if step not in steps→None. If app moved to LATER
line → "completed" (else None). Same line: step_idx < current → "completed"; == → "running"; else None.
`_envelope_artifact_refs(raw, kind) -> list[StepArtifactRef]` (`application.py:1187`): JSONB `[{path,...}]` → StepArtifactRef(artifact_type=ext or kind, title=basename, path).

### `_step_execution_from_envelope(db, app_id, line, step, row) -> StepExecutionRecord` (`application.py:1218`)
Layer-B envelope projection. `_coerce_json` (str→json.loads). payload/input_artifacts/output_artifacts coerced;
`output_artifact = output_list[0] if any`. If `agent_task_id`: append to agent_task_ids; fetch token_usage+cost_estimate.
token_totals fallback from payload.token_usage; cost from payload.cost_estimate_usd. Gate summary from `gate_id` FK.
escalations_count from `escalation` table. retry_count = `max(attempt-1, 0)`. Returns StepExecutionRecord with
step_kind, payload, attempt (envelope-only fields).

### `get_step_execution(db, app_id, line, step) -> StepExecutionRecord` (`application.py:1366`)  ⚠️ CRITICAL dual-path (envelope → legacy fallback)
```
app_row = SELECT id,current_line,current_step FROM application WHERE id; None→404 APP_NOT_FOUND
if not step_mapping.is_known_step(line, step): raise 422 UNKNOWN_STEP (valid=steps_for(line))
# Layer B envelope path: line_id matches lowercase-kebab OR enum display value
envelope_row = SELECT execution_id,step_kind,status,started_at,completed_at,duration_ms,attempt,last_error,
    input_artifacts,output_artifacts,payload,agent_task_id,gate_id FROM step_execution
    WHERE app_id=:app_id AND (line_id=:line_lower OR line_id=:line_enum) AND step_id=:step_id
    ORDER BY started_at DESC NULLS LAST, completed_at DESC NULLS LAST LIMIT 1
if envelope_row: return await _step_execution_from_envelope(...)
# ── Legacy agent_task-merge fallback ──
task_types = step_mapping.task_types_for(line, step)
task_rows = SELECT id,task_type,status,dispatched_at,completed_at,duration_ms,retry_count,last_error,
    input_artifact_refs,output_artifact_ref,token_usage,cost_estimate FROM agent_task
    WHERE application_id=:app_id AND task_type=ANY(:task_types) ORDER BY dispatched_at ASC NULLS LAST   (if task_types)
status = _status_from_task_rows(task_rows)
if status=="not_started": status = _infer_status_from_progress(line, step, app_current_line, app_current_step) or status
started_at = first non-null dispatched_at; completed_at = max if ALL completed; duration_ms = sum if ALL non-null
retry_count = sum(retry_count); last_error = last non-null (reversed)
token_totals = sum input/output/total across rows; cost_estimate = sum
input_artifacts = dedupe by path; output_artifact = last _artifact_from_ref(output_artifact_ref)
gate_type = step_mapping.gate_for(line, step)
if gate_type: gate_row = SELECT id,gate_type,status FROM gate WHERE application_id AND gate_type ORDER BY requested_at DESC LIMIT 1
    if gate_row: gate_summary=...; if status=='pending' and status!='failed': status="running"
escalations_count = SELECT COUNT(*) FROM escalation WHERE application_id AND line AND step
return StepExecutionRecord(app_id, line, step, status, started_at, completed_at, duration_ms, retry_count,
    last_error, agent_task_ids=[r.id], token_usage, cost_estimate, input_artifacts, output_artifact, gate=gate_summary, escalations_count)
```

---

# PART B — REMAINING SERVICE MODULES (responsibility + entry points)

> Format: `module.py` (lines) — responsibility; key entry points with 1-line contract.

### `system.py` (857) — System/capability/business-domain read + capability_lineage row review + compliance rollup (SF1/SF3, migration 050). Read-only except lineage row writes.
- `list_systems(db, portfolio_id) -> list[SystemSummary]` — non-retired systems, ORDER kind, ext_id/name.
- `get_system(db, system_id) -> SystemDetail` — system + realizing apps + capability/domain counts; 404 SYSTEM_NOT_FOUND.
- `list_capabilities_for_system(db, system_id) -> list[CapabilitySummary]`; `get_capability(db, capability_id) -> CapabilityRead` (404 CAPABILITY_NOT_FOUND).
- `get_capability_lineage(db, capability_id) -> CapabilityLineageView` — both-direction edges (sources/targets); 404 if missing.
- `list_business_domains_for_system(db, system_id) -> list[BusinessDomainSummary]`; `get_system_lineage(db, system_id) -> SystemLineageView`.
- `ratify_capability_lineage_row(db, lineage_id, ratified_by, notes=None) -> CapabilityLineageRowView` — sets ratified_by/at, appends `[APPROVED…]` to notes; commits. Idempotent.
- `reject_capability_lineage_row(db, lineage_id, rejected_by, feedback) -> ...` — clears ratified_by/at, appends `[REJECTED…]` feedback to notes; commits.
- `get_lineage_row(db, lineage_id)`; `list_wave_capability_lineage(db, wave_id) -> WaveCapabilityLineageView` (rows whose source/target capability's system has an app in the wave).
- `_classify_compliance_status(meta) -> "compliant"|"needs-review"|"unknown"` — mirrors `CompliancePosture.tsx` (token match: compliant/pass/certified vs review/advisory/pending/fail/violation).
- `get_portfolio_compliance_rollup(db, portfolio_id) -> PortfolioComplianceRollup` — system-grain aggregate of `application.metadata.compliance` over `system_application`; per-system status precedence: needs-review > unknown > compliant (mixed compliant+unknown → needs-review); + ratified_capability counts. 404 PORTFOLIO_NOT_FOUND.

### `bundle.py` (918) — Delegated-bundle lifecycle CRUD + atomic claim/submit/validate (W20). Most fns commit + use `FOR UPDATE`. Errors = `HTTPException(detail={code,message})`.
- `get_bundle(db, bundle_id) -> BundleDetail` (404 BUNDLE_NOT_FOUND) — full envelope (inputs/outputs/sessions/validation_history).
- `list_bundles(db, *, portfolio_ids, user_id, status, scope_kind, application_id, wave_id, mine_only, limit, offset) -> list[BundleSummary]` — empty allowlist → []; mine_only filters claimed_by.
- `dispatch(db, *, contract, fallback_policy, expires_in_hours, created_by_user_id) -> UUID` — INSERT status='offered' + input/output refs; stashes `_expires_in_hours` in descriptor; commits.
- `claim(db, *, bundle_id, user_id, local_agent_descriptor) -> BundleDetail` — atomic FOR UPDATE; terminal→409 BUNDLE_TERMINAL; already-claimed same user→idempotent return, other user→409 BUNDLE_ALREADY_CLAIMED; offered→status='claimed', expires_at=now+ttl (default 7d), merge descriptor.
- `release(db, *, bundle_id, user_id, is_admin, reason) -> BundleDetail` — owner or admin only (403 BUNDLE_NOT_OWNER); terminal→409; status='released'; reason→session_artifact.
- `_validate_against_schemas(payload, output_specs) -> list[Violation]` — MISSING_REQUIRED_OUTPUT / EMPTY_ARTIFACT_REF / SCHEMA_REF_MISSING (file exists check) / UNKNOWN_OUTPUT_KIND.
- `validate_payload(db, *, bundle_id, payload) -> BundleValidationResult` — dry-run, no state change.
- `submit(db, *, bundle_id, user_id, is_admin, payload) -> (BundleDetail, BundleValidationResult)` — FOR UPDATE; not claimed/submitted→409 BUNDLE_NOT_CLAIMED; not owner→403; persist sessions always; on violations stay 'claimed' + history='rejected'; on success fill output refs, status='accepted', history='accepted'; commits.
- `expire_due_bundles(db) -> list[UUID]` — reaper: claimed past expires_at → 'expired' RETURNING id; commits.
- `get_audit_narrative(db, bundle_id) -> BundleAuditNarrative` — plain-English actor sentence + sessions + history.

### `bundle_contract.py` (522) — Materialize deterministic `BundleContract` from `(scope_kind, target_id, app|wave)` (W20 §3.3). Data-driven dict registry.
- `_GATE_OUTPUTS` — gate_id → required output artifacts+schema_refs (G-DC,G-RR,G-DA,G-DT,G-04a/b/c,G-V1/2/3,G-DP-1/2). ⚠️ G-02 and G-DE-1/2 OMITTED (internal-only; resolve raises 400).
- `_LINE_STEP_OUTPUTS` — step_id → outputs (discovery.*, modernization.extract/design).
- `known_gate_targets()/known_step_targets() -> list[str]`.
- `resolve(db, *, scope_kind, target_id, application_id, wave_id) -> BundleContract` — 400 BUNDLE_SCOPE_REQUIRED if neither id; resolves portfolio_id/risk_tier; `_outputs_for` (400 BUNDLE_UNKNOWN_GATE/STEP); default inputs = artifact-repo handle.

### `insights.py` (716) — Read-model aggregator for Application Detail Insights + decisions timeline. Pure read; empty inputs → empty cards.
- `get_insights(db, app_id, config=None) -> InsightsResponse` (404 APP_NOT_FOUND) — composes score_history (maturity dims w/ trend up/down/flat), architecture (decomposition_map → structural-analysis.json artifact fallback → source-app aggregation), tech_stack, line_progress, metrics. `_fetch_line_progress` imports `scoring.GATE_TYPE_TO_ASSEMBLY_LINE`.
- `_normalize_score_to_fraction(v)` — ≤1 passthrough, else /5.0 (0-5 ordinal → fraction).
- `get_decisions_timeline(db, app_id) -> DecisionsTimelineResponse` (404) — reverse-chron gate decisions + rework iterations (retry_count>0) + escalation open/resolved events; sorted by (timestamp,id) DESC.

### `workflow_control.py` (475) — Per-app workflow start/cancel/retry/describe; signal-first cancel. Commits.
- `_LINE_TO_WORKFLOW` — 7 factory lines → workflow class names (Sustainment/Governance/DispositionExecution raise WORKFLOW_NOT_IMPLEMENTED).
- `_LINE_PREREQS` — Modernization needs {Refactor,Rearchitect}; DispositionExecution needs {Retire,Retain,Replace,Replatform,Consolidate}.
- `start_line_workflow(db, app_id, line, temporal, task_queue, config) -> WorkflowStartResponse` — 422 WORKFLOW_NOT_IMPLEMENTED; 409 WORKFLOW_ALREADY_RUNNING (status endswith _in_progress); 422 INVALID_LINE_PREREQS; starts workflow id=`{line}-{app_id}-{run_ts}`, sets status `{line}_in_progress`.
- `cancel_workflow(db, app_id, temporal, config) -> WorkflowActionResponse` — 409 WORKFLOW_NOT_RUNNING; signal `cancel_workflow` then hammer after grace; status='cancelled'.
- `retry_workflow(db, app_id, temporal, task_queue, config, from_line=None) -> WorkflowStartResponse` — best-effort cancel then start from current/Discovery.
- `get_workflow_details(db, app_id, temporal, config) -> WorkflowDetailsResponse` — describe(); NOT_FOUND→synthesize status from `_APP_STATUS_TO_TEMPORAL`; staleness via get_status updated_at + `workflow_staleness_minutes` (gate waits never stale).

### `workflow_health.py` (531) — Cross-workflow health from Temporal visibility; restart/fail out-of-band. Independent of workflow_control.
- `_FAILED_STATUSES` = FAILED/TERMINATED/TIMED_OUT (CANCELED excluded).
- `_extract_app_id_from_workflow_id(wf_id)` — parse middle 5 hex groups → UUID.
- `list_workflows(db, temporal, config, *, limit=50) -> WorkflowListResponse` — running + failed via `list_workflows(query)`; app_names batch lookup; `temporal_unreachable` on RPCError.
- `get_workflow_detail(db, workflow_id, temporal, config) -> WorkflowDetail` — describe + `_latest_failure_event` history scan (prefer workflow-failed over activity-failed); NOT_FOUND→`_build_aged_out_workflow_detail` (DB-projected from app row + step_execution timestamps; workflow_type guessed from id prefix).
- `restart_workflow(...) -> WorkflowActionResponse` — recover input from WorkflowExecutionStarted event; new id `{wf}-restart-{ts}`; 404/422/500.
- `fail_workflow(db, workflow_id, temporal, reason) -> WorkflowActionResponse` — `handle.terminate(reason)`; 404 if NOT_FOUND.

### `wave_target_provisioning.py` (513) — Seed `application_lineage` from disposition-recommendation artifacts when wave coordinator died (task #86 A1). DB+GitHub, no Temporal; caller controls txn.
- `_lineage_relationship_for(disposition)` — Replace→replace, Consolidate→consolidate, else `{disp}-of`.
- `_parse_agent_json(raw)` — clean JSON → ``` fence → first balanced `{...}` block.
- `_TARGET_EQUALS_SOURCE_DISPOSITIONS`={Retain,Refactor,Rearchitect,Replatform}; `_NEW_TARGET_DISPOSITIONS`={Replace,Consolidate}.
- `seed_targets_from_artifacts(db, wave_id, portfolio_id, artifact_repo, config) -> ArtifactSeedResult` — reads `rationalization/wave-{wid}/{app}/disposition-recommendation.json` (.md sidecar fallback); Consolidate peers folded into anchor; Retire skipped; new-target dispositions INSERT application+wave_application+lineage, else update source target_repo_url + self-lineage; provisions repos (idempotent). Raises ValueError on missing artifact_repo/token.

### `skill_bootstrap.py` (551) — Parse SKILL.md files → DB at startup; idempotent upsert. Re-exports registry constants.
- `parse_skill_md(path) -> dict` — frontmatter (name/description/agent/allowed_tools) + body system_prompt.
- `_determine_enrichment_level(dir)` — full (refs + assets/config/scripts) / partial / minimal.
- `_title_case(skill_id)` — kebab → title w/ `_TITLE_ACRONYMS` (AI/ML/API…) + `_TITLE_MIXED_CASE` (cato→cATO).
- `collect_skills(repo_root) -> list[dict]` — phase 1 `cross-cutting/skills`, phase 2 `profiles/faa/skills` (standalone wins over core; overlay merges refs/assets/scripts/config onto core).
- `upsert_skills(db, skills) -> int` — `_UPSERT_SQL` ON CONFLICT(skill_id) DO UPDATE; commits.
- `bootstrap_skills(db) -> int` — `_find_skills_root` (SKILLS_ROOT env / /app/repo / parents[3]); 0 if not found.

### `skill.py` (553) — Skill CRUD + per-line skill-dispatch metrics aggregation. Commits on writes.
- `list_skills(db, pagination, assembly_line=None, source=None, status=None) -> (list[SkillDetail], int)`.
- `get_skill(db, skill_id) -> SkillDetail` (404 SKILL_NOT_FOUND); `create_skill` (409 SKILL_EXISTS); `update_skill` (JSONB cols json.dumps'd); `delete_skill`.
- `get_skill_by_dispatch_id(db, dispatch_id) -> SkillDetail` — `dispatch_ids @> [id]` GIN, status='active'; 404.
- `list_line_skill_metrics(db) -> dict` — per-line + per-skill dispatch counters (completed/failed/timed_out, avg_duration, avg/total cost, models). Sources: `step_execution` (step_kind='agent', primary) + `agent_task` fallback (task_type→line via step_mapping; dedup by agent_task_id). Always returns all 10 lines.

### `human_paired_agent.py` (556) — agent_task discriminator columns + session artifacts (migration 050). Powers /me/tasks + /return + audit narrative. Strict output-spec validation wired.
- `list_my_tasks(db, *, human_user_id, include_claimable=True, portfolio_id=None, limit=50) -> MyTasksResponse` — actor_kind IN (human, human_with_agent); claimable = human_user_id NULL; excludes terminal; optional portfolio scope.
- `return_task(db, *, task_id, payload, human_user_id) -> TaskReturnResponse` — 404 TASK_NOT_FOUND; 400 TASK_NOT_HUMAN_PAIRED (olympus_agent); 403 TASK_OWNED_BY_OTHER; structural `_validate_return_payload` → soft validation_errors; strict `return_payload_validator.validate_return_output_payload` → 400 OUTPUT_SPEC_VIOLATION; updates status (completed/needs_help), persists session artifacts.
- `_validate_return_payload(payload, *, actor_kind) -> list[str]` — completed needs notes/results; human_with_agent needs session; human must NOT have session.
- `render_task_audit_narrative(db, *, task_id) -> TaskAuditNarrative` (404) — actor sentence + session refs.

### `return_payload_validator.py` (418) — Strict output-spec validation for `/agent-tasks/{id}/return` (task #145). jsonschema 2020-12.
- In-scope: 6 Rationalization skills with `output_schemas` in SKILL.md frontmatter. Out-of-scope (9 lines): skips silently.
- `load_output_schemas_for_skill(skill_id) -> tuple[dict]` (lru_cache 256) — parses `cross-cutting/skills/{id}/SKILL.md` frontmatter.
- `_PRIMARY_PATH_BY_SKILL` — skill → primary structured output filename.
- `validate_return_output_payload(*, skill_id, output_payload, payload_path=None) -> (violations, debug_info)` — skip if no skill/payload/schema; else Draft202012Validator.iter_errors; special-case "missing capability_id for non-Retire disposition" (disposition-recommender) → `required_field_missing`.
- `reset_cache()` — test hook (cache_clear).

### `profile_loader.py` (568) — Parse profile YAML bundle → immutable `Profile` dataclasses + validate (P4-S4, DECISION-010). Fail-loud.
- `load_profile(profile_root) -> Profile` — requires all 6 YAML (profile/compliance/risk-classification/gates/scoring/technology); risk tiers exactly {tier_1,tier_2,tier_3}; scoring weights sum to 1.0 (±0.001); raises `ProfileLoadError`.
- `discover_profile_root(profile_id, repo_root=None) -> Path` — OLYMPUS_PROFILES_DIR env → repo_root → walk up.

### `source_intake.py` (619) — Non-Git source intake provider interface + zip/s3 (W13). Path-traversal defence non-negotiable.
- `SourceProvider.unpack(*, destination, **kwargs) -> SourceIntakeResult` (ABC).
- `ZipSourceProvider` — streams through `_LimitedReader` (max bytes, Content-Length pre-check → UPLOAD_TOO_LARGE); `_is_unsafe_zip_entry` rejects absolute/drive/`..` (UNSAFE_ZIP_ENTRY); strips common prefix; resolved-path-escape check.
- `S3SourceProvider` — boto3 credential chain (no creds via API); walks `s3://bucket/prefix`; same path defence (UNSAFE_S3_KEY); S3_PREFIX_EMPTY if 0 objects.
- `_ScaffoldProvider` subclasses (Confluence/SharePoint/GDrive/GCS) → `SourceIntakeNotImplemented` (SOURCE_TYPE_NOT_IMPLEMENTED → HTTP 501).
- `build_provider(source_type, *, max_upload_bytes, s3_region=None, s3_client_factory=None) -> SourceProvider` — GIT rejected (NOT_A_NON_GIT_SOURCE).
- `destination_for(root, application_id) -> Path` = `Path(root)/str(app_id)`.

### `traceability.py` (463) — Citation parse/index/trace/staleness/coverage/cross-validate/gate-threshold. Commits on index.
- `parse_citations(text_content, source_artifact) -> list[Citation]` — explicit `[[ref:…]]`/`[cite:…]`, artifact `{a}:{section}:{finding}`, repo `{owner/repo}:{file}:{line}`; dedup; skip http/https/ftp/mailto.
- `index_citations(db, app_id, source_artifact, citations, *, source_version=None, produced_by=None) -> int` — INSERT traceability_link ON CONFLICT DO NOTHING; commits.
- `forward_trace`/`backward_trace(db, app_id, artifact, element=None) -> *TraceResult`.
- `detect_staleness(db, app_id=None, portfolio_ids=None) -> list[StaleArtifact]` — source_version != app.analyzed_commit_sha.
- `compute_coverage(db, app_id) -> CoverageResult` — traced/total artifacts pct.
- `cross_validate(db, app_id) -> list[CrossValidationIssue]` — target_element referenced by >1 source.
- `GATE_TRACEABILITY_THRESHOLDS` (G-DC/G-RR 90, G-04a/b 95, G-04c 98; default 90); `TIER_1_THRESHOLD_BOOST`=4.0 (capped 100).
- `validate_gate_traceability(db, app_id, gate_type, risk_tier=None) -> GateTraceabilityResult` — coverage ≥ threshold (Tier-1 +4%).

### `target_state_rollup.py` (297) — Portfolio target-state rollup from per-wave `wave-outcome-synthesis.json` (W11/P5-S12). Computed at read time, never stored.
- `_DISPOSITIONS` — 7 canonical. `_synthesis_path(wave_id)` = `rationalization/wave-{id}/wave-outcome-synthesis.json`.
- `_aggregate(synth_list) -> dict` — sums counts/impact; ⚠️ disposition_mix re-derived from `pct × app_count` per wave (never average percentages), then re-cast to percent distribution.
- `get_target_state_rollup(db, portfolio_id, config) -> dict` — 404 PORTFOLIO_NOT_FOUND / PORTFOLIO_NOT_CONFIGURED; 500 GIT_NOT_CONFIGURED; 502 GIT_READ_FAILED; waves with missing synthesis omitted (never invents numbers); per-wave read failure degrades to `waves_omitted` reason='read-failed'.

### `user.py` (436) — `user_account` raw-SQL CRUD (migration 026). Caller owns txn (writes don't commit). Password/OIDC delegated.
- `list_users(db, *, offset, limit, include_inactive=False) -> (list[UserProfile], int)`; `get_user`; `get_user_by_login(db, email_or_username) -> dict|None` (includes password_hash); `get_user_by_external_identity(db, provider_id, external_id) -> dict|None`.
- `create_user(db, *, username, email, full_name, roles, identity_provider=LOCAL, external_id, password) -> UserProfile` — local needs password + null external_id; OIDC needs external_id + null password; hashes via `password.hash_password`.
- `update_user`/`set_password` (ValueError on OIDC)/`deactivate_user`/`record_login`.
- `upsert_oidc_user(db, *, provider_id, external_id, email, username, full_name, default_roles) -> UserProfile` — idempotent per (provider,sub); refreshes display attrs, preserves roles.

### `oidc.py` (438) — IdP-agnostic OIDC auth-code + PKCE (P4-S1.11). OKTA NOT hardcoded — pure OIDC via profile config.
- `OIDCProviderConfig` (frozen) — issuer/client_id/urls/scopes/role_mapping/groups_claim; `get_client_secret()` reads env (`client_secret_env`).
- `OIDCClient.generate_pkce() -> (verifier, challenge)` (RFC 7636 S256); `get_authorization_url`; `exchange_code(code, verifier) -> dict`; `validate_id_token(id_token) -> OIDCUserClaims` (JWKS fetch+cache, signature/issuer/audience verify); `resolve_roles(claims) -> list[RBACRole]` (group→role mapping, default_role fallback).
- `MockOIDCProvider` — in-memory test double (seed_token/link_code).
- `load_identity_config(profile_root) -> OIDCProviderConfig|None` — reads `config/identity.yaml`; None if absent or identity_mode='local'; raises OIDCConfigError on partial/malformed.

### `performance_report.py` (452) — Wave performance rollup (step_execution + agent_task timings) for Performance tab (task #94). Read-only, ~4 SQL.
- `get_wave_performance_report(db, wave_id) -> WavePerformanceReport` (404) — wall_clock (MIN started → MAX completed), per-step rollup (count/total/avg/p50/p95 via percentile_cont), per-agent LLM/tool breakdown (`agent_task.token_usage.timing` JSONB), per-line app-count + percentiles. `_detect_bottlenecks` — slowest step per line (≥2× next), cross-line agent-LLM + agent-tool leaders.

### `agent_roles.py` (385) — Agent Registry: `olympus-worker/config/agents.yaml` roles joined with agent_task activity. Degrades to [] if config not found.
- `load_agent_roles_config(path=None) -> list[dict]` — `_worker_config_dir` (OLYMPUS_WORKER_CONFIG_DIR env / walk up / container paths).
- `get_agent_roles(db, portfolio_id=None, portfolio_ids=None, *, config_path=None) -> list[AgentRoleSummary]` — `_aggregate_per_skill` (tasks_total/30d/success/terminal; portfolio-scoped uses INNER JOIN application, excludes wave-scoped); `_combine_per_role` sums per-role skill_ids; status active/declared-inactive by tasks_30d.

### `skill_registry.py` (331) — Parse `cross-cutting/skills/registry.yaml` → typed `Registry`; process-cached. Replaces hand-maintained LINE_MAP/DISPATCH_TO_DIR.
- `load_registry(path=None) -> Registry` — `_default_registry_path` (SKILL_REGISTRY_PATH env / /app/repo / parents[3]); FileNotFoundError if missing.
- `Registry.find(skill_id)`; `.resolve_dispatch(name) -> str` (skill id or alias; KeyError if unknown — fail loud).
- `get_registry() -> Registry` (cached); `reset_cache()`.
- Lazy module globals via `__getattr__`: `LINE_MAP` (skill→line), `DISPATCH_TO_DIR`, `DIR_TO_DISPATCH`, `FALLBACK_DESCRIPTION`/`FALLBACK_AGENT` (3 faa-* legacy skills), `AGENT_TO_TIER`={opus:tier-1, sonnet:tier-2, haiku:tier-3}.

### `lines.py` (281) — Read-only assembly-line registry (descriptions/deps/gates static; steps/skills from skill_registry) + runtime status/throughput.
- `_LINE_DESCRIPTIONS`/`_LINE_DEPENDENCIES`/`_LINE_GATES` — 10-line static maps from overview.md.
- `list_lines() -> list[LineInfo]`; `get_line(name) -> LineInfo|None`.
- `get_line_status(db, line, portfolio_id=None, portfolio_ids=None) -> dict` (KeyError if unknown line) — apps_in_progress/completed/blocked (blocked = open escalation OR pending gate).
- `get_line_throughput(db, line, days=7, ...) -> dict` — apps_per_week + avg_duration_hours from completed agent_task in window.

### `rationale.py` (229) — Read aggregator: retrospective traceability for target apps (F2). Emits artifact REFERENCES, not content.
- `_RATIONALE_GATE_TYPES` = (G-DC, G-RR, G-DA).
- `get_application_rationale(db, app_id) -> ApplicationRationaleResponse` (404) — inbound lineage edges; per source: `_load_rationalization_gates` (chain + inferred wave_id from latest G-DA/G-RR) + `_artifact_refs_for_source` (6 wave-scoped artifact paths; empty if wave_id unknown). is_target=False if no inbound edges.

### `wave_assignment.py` (161) — Wave assignment algorithm: group UNASSIGNED apps into PERSISTED draft waves (F22 — now persists, was pure proposer). Commits.
- `_sort_key(app)` — (risk_tier asc Tier-1 first, complexity desc, name).
- `assign_waves(db, portfolio_id, max_apps_per_wave=10) -> dict` — fetch apps NOT in wave_application, sort, chunk by max, INSERT draft wave + wave_application rows per chunk; returns {waves, waves_created, waves_unchanged:0, apps_assigned}.

### `model_usage.py` (171) — Model-tier telemetry: aggregate agent_task by model_used (P5-S26, replaces /agents list). Safe on missing table.
- `_KNOWN_MODELS` — claude-haiku-4-5/sonnet-4-6/opus-4-7 → (tier, display); `_classify` pattern-matches opus/sonnet/haiku substrings.
- `get_model_usage(db, portfolio_id=None, portfolio_ids=None) -> ModelUsageResponse` — group by model_used; tasks_total/30d, success/failure/terminal, avg_duration, total_cost; portfolio-scoped INNER JOIN application (excludes wave-scoped).

### `agents.py` (141) — Agent telemetry WRITE side (read rollups retired → model_usage.py). Commits.
- `record_task_start(db, req: AgentTaskStartRequest)` — INSERT agent_task status='running' ON CONFLICT(id) DO NOTHING (idempotent).
- `record_task_complete(db, task_id, req) -> bool` — UPDATE terminal fields; merges `timing` block into `token_usage` JSONB via `jsonb_set(…, '{timing}', …, true)`; False if no row matched (→404).

### `agent_client.py` (213) — Provider-agnostic A2A dispatch client (imported by Temporal worker activity). httpx/JSON-RPC.
- `AGENT_RETRY_POLICY` — RetryPolicy(5s initial, 2.0 backoff, 60s max, 3 attempts).
- `dispatch_via_a2a(agent_url, task_input, model_used="") -> AgentTaskResult` — POST `{agent_url}/a2a/tasks` {task, context, model_preference}; `_extract_result` maps response → AgentTaskResult (output_artifacts/files, token_usage, cost, model_used from runtime). ⚠️ model_preference left "" if unset (runtime reads skill tier — sending "tier-2" clobbers Opus skills).
- **⚠️ CHANGED at HEAD `7cb3b20c` (#594) — `_extract_result` status mapping:** maps BOTH `status in ("failed","timeout","timed_out")` → `TaskStatus.FAILED` / `TaskStatus.TIMED_OUT` (`timeout`/`timed_out` → `TIMED_OUT`, synthesizing an error when the runtime supplies none); previously ONLY `"failed"` mapped and `"timeout"` fell through to the default `COMPLETED` with no output_files. ⚠️ This same fix is duplicated in the **bundled `olympus-worker/src` copy** of agent_client (the deployed worker imports that one, not `olympus_api`). Downstream: `agent_dispatch.dispatch_agent_task` raises `RetryableError` on `TIMED_OUT` (just like `FAILED`) so Temporal retries — a transient skill timeout (e.g. the PRA step's 1800s budget) no longer collapses into a non-retryable empty-output wave failure (`EmptyPortfolioRedundancyPlan`, #590).

### `agent_dispatch.py` — Temporal activity wrapper around `dispatch_via_a2a` (resolves agent URL, records agent_task, raises on failure).
- `dispatch_agent_task(...)` — ⚠️ **CHANGED at HEAD (#594):** raises `RetryableError` when the AgentTaskResult status is `FAILED` **OR `TIMED_OUT`** (was FAILED-only). A `TIMED_OUT` agent run is now a retryable activity error so Temporal retries with a fresh attempt instead of returning a "successful" empty result that downstream steps with a non-retryable empty-output guard turn into a whole-wave failure.

### `agent_runs.py` (92) — Recent agent-run errors for Agent Registry panel. Read-only.
- `list_recent_errors(db, *, limit=20, portfolio_id=None, portfolio_ids=None) -> AgentRunErrorListResponse` — agent_task status IN (failed,timed_out) joined to application; INNER JOIN when portfolio-scoped; ORDER completed_at DESC.

### `disposition_output.py` (156) — Read per-disposition `disposition-output.json` bundle from artifact repo (W12/P5-S13). Read-only.
- `get_disposition_output(db, app_id, config) -> dict` — path `dispositions/{portfolio}/{app}/disposition-output.json`; 404 APP_NOT_FOUND / PORTFOLIO_NOT_CONFIGURED / DISPOSITION_OUTPUT_NOT_EMITTED (file missing); 500 GIT_NOT_CONFIGURED / DISPOSITION_OUTPUT_MALFORMED; 502 GIT_READ_FAILED.

### `portfolio.py` (147) — Portfolio summary/manifest reads. Falls back to first portfolio if no ID.
- `get_portfolio_summary(db, portfolio_id=None) -> PortfolioSummary|None` — app/wave counts + wave_progress.
- `get_portfolio_manifest(db, portfolio_id=None) -> PortfolioManifest|None` — applications + waves (per-wave app_count).

### `portfolio_membership.py` (171) — `portfolio_membership` read/write (W20 §4.2 default-deny). Commits on writes.
- `is_member(db, portfolio_id, user_id) -> bool`; `list_user_portfolio_ids(db, user_id) -> list[UUID]`; `list_portfolio_members(db, portfolio_id) -> list[PortfolioMembership]`.
- `add_member(db, portfolio_id, user_id, role, granted_by) -> PortfolioMembership` — UPSERT ON CONFLICT(portfolio_id,user_id) DO UPDATE (idempotent); commits.
- `remove_member(db, portfolio_id, user_id) -> bool`.

### `lineage.py` (112) — `application_lineage` read service (F1 target-state view). Read-only (writes in Architecture activity).
- `get_application_lineage(db, app_id) -> ApplicationLineageResponse` (404) — sources (this app is target) + targets (this app is source, w/ target_repo_url+disposition).

### `signal_inbox.py` (112) — DB-backed workflow signal inbox (task #86 A1). Caller controls txn (enqueue doesn't commit).
- `enqueue_signal(db, workflow_id, signal_name, payload=None, status="sent") -> UUID` — INSERT workflow_signal_inbox.
- `mark_queued(db, row_id)` — flip 'sent' → 'queued' after Temporal failure.
- `list_pending(db, workflow_id=None, limit=100) -> list[dict]` — status IN (pending, queued), ORDER created_at ASC.

### `profile_activation.py` (126) — Wire profile_loader → workflow registries; activate once at startup/switch (P4-S4.3/4.4). Thread-safe singleton.
- `active_profile() -> Profile|None`; `activate_profile(profile_id=None, *, profile_root=None) -> Profile|None` — OLYMPUS_PROFILE env; `apply_profile(profile)` to registries; None if unresolvable; ProfileActivationError on failure.
- `deactivate_profile()` — `reset_registries_to_defaults()`.

### `identity_config.py` (90) — Active-profile `config/identity.yaml` → cached OIDCProviderConfig (P4-S1.11). Thread-safe cache.
- `get_identity_config() -> OIDCProviderConfig|None` (lazy cached); `refresh_identity_config()` (after profile switch); `set_identity_config_for_test()`.

### `password.py` (70) — bcrypt hash/verify (P4-S1.11). bcrypt direct (passlib incompatible w/ bcrypt≥4.3 on py3.13).
- `hash_password(password) -> str` — `BCRYPT_COST` env (default 12, range 4-15); 72-byte max (PasswordError); empty→error.
- `verify_password(password, hashed) -> bool` — False on missing/malformed hash (never raises into auth path).

### `mcp_client.py` (64) — Thin async MCP-server client. JSON-RPC 2.0 over HTTP.
- `read_mcp_resource(uri, base_url=None) -> dict|None` — POST `{url}/` `resources/read` {uri}; returns `result.data`; None on error (logged).

---

## NEW SERVICE MODULES AT HEAD `7cb3b20c` (responsibility + entry points)

### `gate_rbac.py` (227) — ⚠️ NEW. Pure gate-type → reviewer-role POLICY resolution (P6-S6.3/.4, `rbac-model.md` §5). NO DB, NO auth (router enforces).
- `MANAGEMENT_ROLES = (portfolio_manager, portfolio_admin)` (gate_rbac.py:31); `_PLATFORM_DEFAULTS` (gate_rbac.py:40) = gate_type → (required_reviewer_roles, minimum_approvals) — e.g. `G-V3 → ([safety_board], 2)`; unknown → `_UNKNOWN_GATE_DEFAULT` (gate_rbac.py:64).
- `GateReviewPolicy` (frozen dc, gate_rbac.py:77): `gate_type, required_reviewer_roles, minimum_approvals=1, oversight_role=None, management_override_allowed=True, extension_roles`; `.allowed_approver_roles()` adds MANAGEMENT_ROLES iff `management_override_allowed`.
- `evaluate_approver(policy, scoped_role) -> ApproverDecision{allowed, is_oversight, is_management_override}` (gate_rbac.py:122) — reviewer→allowed; management→allowed+override iff `management_override_allowed`; else denied.
- `resolve_gate_review_policy(gate_type, *, profile=None) -> GateReviewPolicy` (gate_rbac.py:175) — merges profile `overrides[gate].rbac` block over platform default; `oversight_role`/`management_override_allowed` come ONLY from the profile block.

### `audit_log.py` (223) — ⚠️ NEW. Read-only RBAC audit aggregation projection (P6-S6.6, `rbac-model.md` §8). Backs `GET /api/v1/admin/audit-log`.
- `EVENT_TYPES = (approval, rejection, escalation, force_advance, membership_grant)` (audit_log.py:27).
- `query_audit_events(db, *, portfolio_id, event_type, actor, from_ts, to_ts, limit, offset) -> (events, total)` (audit_log.py:44) — UNIONs 4 source tables IN PYTHON: gate_approval (approval), gate status='rejected' (rejection), audit_log action gate.escalate/gate.force_advance (escalation/force_advance), portfolio_membership (membership_grant); in-memory `_match` filter + sort `occurred_at` DESC (None→datetime.min); `total`=post-filter count; page=`[offset:offset+limit]`. ⚠️ escalation/force_advance carry `portfolio_id=None` so they're dropped when `portfolio_id` is supplied.

### `viewer_analytics.py` (160) — ⚠️ NEW. Artifact-viewer dwell telemetry (P5-S30.11). Safe on missing `viewer_event` table (migration 061).
- `record_events(db, events: list[ViewerEventIngest]) -> int` (viewer_analytics.py:61) — empty→0; truncates artifact_type[:150]/section[:200]; executemany INSERT; `_missing_relation`→0 (no-op); ⚠️ COMMITS internally on success; returns row count.
- `summarize(db, artifact_type, limit) -> ViewerAnalyticsSummaryResponse` (viewer_analytics.py:107) — GROUP BY (artifact_type, section), ORDER total_dwell_ms DESC LIMIT :limit; `_safe_execute` tolerates missing table → empty. `_missing_relation(exc)` (viewer_analytics.py:38): "does not exist" | ("undefined"&"relation") | ("column"&("does not exist"|"undefined")).

### `skill_metrics.py` (110) — ⚠️ NEW. `skill_metrics` projection keyed by canonical skill_id (P5-S30.9). Replaces live `agent_task`-by-`module_name` aggregation.
- `recompute_skill_metrics(db, skill_id)` (skill_metrics.py:31) — INSERT…SELECT upsert (recompute, NOT incremental) `ON CONFLICT (skill_id) DO UPDATE`; `gate_pass_rate = completed / terminal(completed+failed+timed_out)` (NULL when no terminal rows); `avg_quality_score = AVG(quality_score)`. Called from `agents.record_task_complete`; caller owns commit.
- `get_skill_metrics(db, skill_id) -> dict` (skill_metrics.py:80) — read projection → `{skill_id, invocations_total:int, gate_pass_rate:float|None, avg_quality_score:float|None}`; zero/NULL when no row.

### `governance_schedule.py` (125) — ⚠️ NEW. Governance-sweep Temporal Schedule mgmt (P6-S8.6). All best-effort.
- `CADENCE_CRON = {weekly:"0 7 * * MON", quarterly:"0 7 1 */3 *"}` (governance_schedule.py:28); `schedule_id_for(pid, cadence="weekly") = f"gov-{cadence}-{pid}"` (governance_schedule.py:34).
- `create_governance_schedule(temporal, portfolio_id, *, cadence="weekly", task_queue, paused=False) -> str` (governance_schedule.py:38) — builds `Schedule(ScheduleActionStartWorkflow("GovernanceWorkflow", {...}, id=f"governance-{pid}-{cadence}", task_queue), ScheduleSpec(cron_expressions=[cron]), ScheduleState(paused))`; `temporal.create_schedule(sid, schedule)`; idempotent (`ScheduleAlreadyRunningError` swallowed).
- `delete_governance_schedule(temporal, portfolio_id, *, cadence="weekly")` (governance_schedule.py:86) — `get_schedule_handle(sid).delete()` in `except Exception` (logs, never raises). `set_governance_schedule_paused(temporal, pid, *, cadence, paused)` (governance_schedule.py:111) — handle.pause/unpause.

### `evidence_export.py` (226) — ⚠️ NEW. Assemble OSCAL-flavored compliance-evidence ZIP/PDF (P6-S8.10). Pure builders (no DB/Temporal).
- `AppEvidence` (dc, evidence_export.py:19): `app_id, app_name, system_name, ssp_json/sar_json/poam_json: str|None`.
- `build_pdf_summary(portfolio_id, apps, ...) -> bytes` (evidence_export.py:51) — minimal PDF narrative (`_escape_pdf_text`, `_slug`).
- `build_evidence_zip(*, portfolio_id, portfolio_summary, apps, fmt) -> bytes` (evidence_export.py:152) — assembles per-app `.cato` OSCAL JSON + README + (oscal|pdf|zip per `fmt`) into a zip; `_readme` (evidence_export.py:204).

### `interview.py` (718) — ⚠️ NEW. Async multi-turn requirements-elicitation session (Build-mode Discovery, P6-S5.12, greenfield-build-line.md §3.3/§12.1). DB-persisted partial artifact; fires `interview_completed` signal.
- `ELICITATION_SKILL = "requirements-elicitation"` (interview.py:66). `validate_requirements_capability(artifact) -> list[str]` (interview.py:120) — every must-have capability needs ≥1 acceptance criterion.
- `start_interview(db, app_id, body, user_sub) -> InterviewSessionState` (interview.py:292) — 404 APP_NOT_FOUND; resumes the active session if one exists; returns session id + first `_phase_question` + empty preview.
- `submit_turn(db, app_id, body) -> InterviewSessionState` (interview.py:420) — 404 APP_NOT_FOUND/INTERVIEW_NOT_FOUND; `_accumulate` answer into partial `requirements-capability` artifact (persisted), advance phase, next question.
- `get_session(db, app_id) -> InterviewSessionState` (interview.py:487) — current state (404 APP_NOT_FOUND/INTERVIEW_NOT_FOUND).
- `complete_interview(db, app_id, user_sub, *, signal_emitter=None) -> CompleteInterviewResponse` (interview.py:542) — `_finalize_artifact` then `validate_requirements_capability`; on errors returns 200 `artifact_valid=false` + errors (NOT 4xx); on success dispatches `requirements-elicitation` (DECISION-018) and fires `interview_completed` to the waiting Discovery workflow (default emitter = Temporal signal).

### `design_review.py` (291) — ⚠️ NEW. Standalone design-review surface (Phase 6 W9, P6-S9.3/.4, design §4.5/§5.3). Reuses gate-review structured-feedback shape; NO gate record touched.
- `list_design_artifacts(db, app_id, pagination, *, line=None, artifact_type=None) -> DesignArtifactsResponse` (design_review.py:89) — filters the app's artifacts to the design "promotion list" (architecture/API/data/UX-UI via `_type_for_path`/`_canonical_line`); paginated.
- `submit_design_feedback(db, app_id, body, user_sub) -> DesignFeedbackResponse` (design_review.py:176) — persists annotations; for each `flag_for_revision` annotation records an app-scoped `agent_task` telemetry row + dispatches rework to the originating agent via the A2A skill-dispatch path (same path a gate rejection uses); ⚠️ line is NOT blocked, no gate touched. Returns `{dispatched:int, dispatched:[DesignFeedbackDispatch], detail}`.

---

## Cross-cutting GOTCHAS summary
1. ⚠️ `scoring._dimension_registry` is a MODULE-LEVEL MUTABLE dict — `update_dimension_weights` mutates it process-wide.
2. ⚠️ `_normalize_score` branch order is load-bearing (1-5 Likert vs 0-100 percent vs 0-1 fraction). Used by scoring; insights has its OWN `_normalize_score_to_fraction` (different: ≤1 passthrough else /5).
3. ⚠️ The `gate` table has NO `assembly_line` column — `GATE_TYPE_TO_ASSEMBLY_LINE` (scoring.py) is the single source, imported by insights.py.
4. ⚠️ Gate evidence `steps`-shaped payloads MUST have their `assembly_line` in `_STEP_BASED_LINE_CONFIG` or cards collapse to generic findings (the G-DT/G-02 empty-card bug). Discovery uses `passes`, intentionally absent.
5. ⚠️ G-DA approval fires DUAL signals (`gate_approved` + `StakeholderApprovedSignal scope="g-da"`) — single approver unblocks both.
6. ⚠️ `git_service._await_mergeability` uses BLOCKING `time.sleep(1.5)` ×8 (sync PyGithub) — callers run it via `asyncio.to_thread` from async code.
7. ⚠️ `reconcile_and_merge` classification: dirty→MergeConflict (non-retry), behind→rebase then retry/MergeDivergenceUnresolved, blocked→MergeBranchProtectionRejected (non-retry).
8. ⚠️ Wave `actual_start` (DATE) and `updated_at` (timestamptz) MUST bind as SEPARATE params (asyncpg "inconsistent types deduced").
9. ⚠️ `bulk_onboard_apps`/`assign_apps_to_wave` bind UUID arrays as `[str(a)...]` lists (asyncpg rejects synthetic array-literal strings — F21 fix).
10. ⚠️ `application.STEP_PROGRESS` & `step_mapping.LINE_STEP_IDS` are built at IMPORT from olympus_contracts — adding/renaming a step requires editing the contract YAML; CI drift guards block hardcoded copies.
11. ⚠️ Aged-out Temporal workflows (history past retention TTL) are reconciled DB-first in `wave.get_wave_progress`, `workflow_control.get_workflow_details`, `workflow_health.get_workflow_detail` via `_*_STATUS_TO_TEMPORAL` synthesis maps — NOT_FOUND ≠ unreachable.
12. ⚠️ `get_application_status` (P5-AUDIT-002) skips un-deserializable gate rows + has a fallback empty envelope — never 500s the Portfolio Overview.
