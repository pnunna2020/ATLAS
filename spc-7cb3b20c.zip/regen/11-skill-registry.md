# 11 — Skill Registry (ATOMIC regeneration spec, INDEX ONLY)

> **Scope.** This file is the authoritative INDEX of every Olympus skill: its registry
> metadata + the `output_schemas` contract declared in each skill's `SKILL.md` frontmatter.
> **It deliberately does NOT reproduce skill prompt bodies** — those live in a separate
> Claude Agent SDK environment and are out of scope for regeneration here. To regenerate a
> prompt body you regenerate the `SKILL.md` `# Purpose / Inputs / Outputs / ...` sections
> against this contract.
>
> **Companion file:** `regen/11-skill-registry-wiring.md` contains the per-assembly-line
> `step → skill → output-schema` wiring (Task §4). Split out because table + wiring exceeds
> one readable file.
>
> **Authoritative sources (re-verified 2026-06-15 @ HEAD `7cb3b20c`):**
> - Registry metadata: `cross-cutting/skills/registry.yaml` (2950 lines; root key `skills:` at `:54`).
> - Per-skill `agent` + `output_schemas`: each `cross-cutting/skills/<id>/SKILL.md` (and
>   `profiles/faa/skills/<id>/SKILL.md`) YAML frontmatter.
> - Schema resolution target: `schemas/<area>/<name>.schema.json` (**96** `.schema.json` files,
>   was 84 — +12 incl. the new `schemas/build/` area; see §4a).
> - Registry schema/conventions doc: `cross-cutting/skills/CONVENTIONS.md` (`§7` registry shape at
>   `:173`; `§2` skill-vs-step naming at `:28`; `:184` documents `is_orchestration`).
> - Loaded at runtime by `olympus_api.services.skill_registry.load_registry()`
>   (`registry.yaml:8`). CI gate **P4-S7.H1** enforces: every workflow-dispatched skill has a
>   registry entry AND a `SKILL.md` on disk (`registry.yaml:12`).
>
> **⚠️ CHANGED since prior baseline (HEAD `7cb3b20c`).** +3 net-new core skills for the new
> **Build** assembly line (Phase 6 W5): `requirements-doc-ingester`, `requirements-elicitation`
> (Discovery Build-mode intake, `registry.yaml:87`/`:104`) and `spec-from-requirements`
> (Build Step 1, `registry.yaml:1791`). Registry top-level **167 → 170**; core `SKILL.md`
> **178 → 181**; declared schema paths **36 → 38** (the two new `schemas/build/*.schema.json`).
> There is now an **11th line YAML** (`build.yaml`). 0 skills removed. The DevSecOps additions
> mentioned at the platform level (`validate-devsecops-baseline`) are **NOT skill-backed** — no
> registry entry, no `SKILL.md`; that baseline check is a code activity, so it does not appear in
> this index or the wiring file. `iac-scaffolding-generator` and `security-scan-review` are
> unchanged skills (the latter is now ALSO dispatched by the new Build `generate` step — see
> companion).

---

## 1. Headline counts (EXACT, re-verified)

| Quantity | Count | How verified |
|---|---|---|
| Registry **top-level** entries (`^  - id:`) | **170** | `grep -c '^  - id:' registry.yaml` |
| Registry **variant** ids (nested `- id:` under `variants:`) | **24** | parsed; see §6 |
| Registry total `- id:` tokens (all indents) | **194** | 170 + 24 = 194 |
| Distinct **categories** (`category:` field) | **19** | §3 |
| Core `SKILL.md` on disk (`cross-cutting/skills/<id>/SKILL.md`) | **181** | `find … | wc -l` |
| FAA profile `SKILL.md` (`profiles/faa/skills/<id>/SKILL.md`) | **15** | `find … | wc -l` |
| `SKILL.md` declaring ≥1 frontmatter `output_schemas` path | **38** (all core; **0 FAA**) | §2, §4 |
| Distinct schema paths declared in frontmatter | **38** | §4 |
| Declared schema paths that **fail to resolve** under `schemas/` | **0** | §4 |
| Skills marked `is_orchestration: true` | **1** (`drift-detection`, `registry.yaml:2437`) | §5 ⚠️ |

> ⚠️ **CHANGED:** every count in the top three rows + core-`SKILL.md` + the two schema rows moved
> by the +3 Build skills. **170** top-level (was 167), **194** total `- id:` (was 191), **181**
> core `SKILL.md` (was 178), **38** `SKILL.md`-with-`output_schemas` (was 35), **38** distinct
> declared schema paths (was 36). The three new skills each declare exactly one frontmatter schema
> and all three resolve, so "fail to resolve" stays **0**. Variant count, category count, and FAA
> count are **unchanged**.

> ⚠️ **GOTCHA — the "113 SKILL.md declare schema paths" premise is WRONG.** Only **38**
> `SKILL.md` files declare a frontmatter `output_schemas:` block (38 distinct paths; all 38
> resolve). The likely source of any inflated number: `SKILL.md` files contain the bare substring
> `schemas/` *somewhere* in the body prose (`grep -rl 'schemas/'`), and many match a loose
> `schema:` regex (which also hits Fastify-route `schema:` examples and prose). Neither is the
> contract. The contract is the YAML `output_schemas` list in frontmatter only. Regeneration MUST
> use the frontmatter list, not a substring scan.

### Frontmatter `output_schemas` shape (the contract)

```yaml
---
name: migration-strategy-advisor
agent: opus
allowed-tools: [Read, Write, Grep]
output_schemas:
  - path: cloud-pattern.json                              # artifact filename the agent emits
    schema: schemas/architecture/cloud-pattern.schema.json # repo-root-relative schema path
---
```
- `output_schemas` is a **list**; each item has `path` (output artifact filename) + `schema`
  (repo-root-relative `schemas/...` path). A skill MAY declare multiple items.
- ⚠️ One schema may be declared under **two `path`s** when the same skill emits two artifact
  filenames governed by one schema — e.g. `redundancy-analyzer` declares
  `redundancy-matrix.json` AND `intra-app-redundancy.json` both → `redundancy-matrix.schema.json`
  (`cross-cutting/skills/redundancy-analyzer/SKILL.md` frontmatter). Counted once as a distinct
  schema; the dual-path is intentional (cross-app vs intra-app scope).
- The 38 distinct schema paths span **5** areas now: `discovery/` (6), `data/` (5),
  `architecture/` (11), `rationalization/` (14), and **`build/` (2 — NEW)**. ⚠️ **CHANGED:** the
  Build skills add the first-ever skill-frontmatter `build/` references
  (`schemas/build/requirements-capability.schema.json` shared by both intake skills, and
  `schemas/build/scenario-spec.schema.json` from `spec-from-requirements`). **No skill declares a
  `gates/`, `common/`, `cross-cutting/`, `dispositions/`, `modernization/`, `design/`,
  `compliance/`, or `profiles/` schema in frontmatter** — those schemas are used by
  activities/validators, not skill outputs.

---

## 2. THREE-WAY RECONCILIATION (registry 170 ↔ core 181 ↔ FAA 15)

This is the high-value section. Every number below was recomputed from disk on 2026-06-15 @ HEAD
`7cb3b20c`. ⚠️ **CHANGED:** registry 167→**170**, core 181 (was 178); the +3 are all Build-line
core skills (no FAA, no variants), so they land cleanly in the "core-backed top-level" bucket and
the FAA/variant arithmetic is otherwise identical to the prior baseline.

### 2a. Registry's 170 top-level entries decompose as:

```
170 registry top-level ids
 = 161  entries that have a core SKILL.md  (cross-cutting/skills/<id>/SKILL.md)   ← was 158 (+3 Build)
 +   9  entries whose ONLY SKILL.md is FAA-located (profiles/faa/skills/<id>/SKILL.md, no core base)
 +   0  entries with NO SKILL.md anywhere
```

- The **+3 core-backed** new entries: `requirements-doc-ingester` (`registry.yaml:87`),
  `requirements-elicitation` (`registry.yaml:104`), `spec-from-requirements`
  (`registry.yaml:1791`). All three have a core `SKILL.md`
  (`cross-cutting/skills/<id>/SKILL.md`, 5477 / 7784 / 9679 bytes) and `agent: opus` frontmatter.
- ⚠️ **`drift-detection` is the lone `is_orchestration: true` entry (registry.yaml:2431-2445)
  yet it STILL has a core `SKILL.md`** (`cross-cutting/skills/drift-detection/SKILL.md`,
  7098 bytes). This **contradicts the registry's own convention comment** (`registry.yaml:21-27`:
  "is_orchestration: true … does NOT have SKILL.md on disk"). In practice `drift-detection` is a
  fan-out aggregator skill (depends_on the 5 `drift-detection-*` category sub-skills) that both
  orchestrates AND has a prompt. So it is counted inside the 161 "has core SKILL.md", not as a
  disk-less orchestration entry. **Net: 0 registry entries are disk-less.** Treat the
  `is_orchestration` flag here as advisory, not as "no SKILL.md".

- The **9 FAA-only** registered ids (no core base) are:
  `aerospace-medical-certification-mapper`, `ame-decision-workflow-scaffolder`,
  `faa-code-standards`, `faa-form-schema-generator`, `faa-style-brownfield`,
  `faa-style-greenfield`, `form-8710-validator`, `medxpress-confirmation-binder`,
  `pilot-certification-domain-modeler`. They live ONLY under `profiles/faa/skills/`.

### 2b. The 15 FAA `SKILL.md` decompose as:

```
15 FAA SKILL.md
 =  9  FAA-only skills (no core base) — counted in the 170 registry top-level (above)
 +  6  FAA *profile overrides* of a core skill that ALSO has a base SKILL.md in core
```

- The **6 dual-located** ids (base in `cross-cutting/skills/`, override in `profiles/faa/skills/`)
  each carry `profile_overrides: [faa]` in the registry:
  `cato-compliance` (`registry.yaml` Architecture block), `cato-evidence-validator`,
  `design-system`, `ea-compliance`, `safety-critical-verifier`, `traffic-shift`.
- ⚠️ **For these 6, the registry entry is counted as "core" (it has a base SKILL.md).** The FAA
  copy is a profile-layer override, NOT a separate registry row. So FAA contributes only **+9**
  net-new ids to the 170, never +15.
- ⚠️ All **15 FAA `SKILL.md` declare ZERO frontmatter `output_schemas`** — even
  `faa-form-schema-generator`, whose *description prose* says "Output validates against
  schemas/design/faa-form-schema.schema.json" but has no `output_schemas:` block (see §4 flag).

### 2c. The 181 core `SKILL.md` decompose as:

```
181 core SKILL.md (cross-cutting/skills/<id>/SKILL.md)
 = 161  directories matching a registry top-level id (incl. drift-detection, +3 Build)   ← was 158
 +  20  directories matching a registry *variant* id (variant has its own SKILL.md on disk)
 +   0  unregistered SKILL.md (no registry entry, not a variant)
```

- **161 + 20 = 181.** ✓ No orphan/unregistered core `SKILL.md`. No registry top-level id is
  missing its core file except the 9 FAA-only ones (which are correctly under `profiles/`).
  ⚠️ **CHANGED:** the top-level-with-disk count is 161 (was 158) — the +3 Build skills; the 20
  variant-with-disk count is unchanged.
- The **20 variants-with-disk** are the realized members of 4 base+variant families
  (code-generation, data-product-design, discovery-patterns, target-architecture-blueprint) plus
  `extraction-dotnet`. See §6.

### 2d. Reconciliation summary table

| Set | Count | Notes |
|---|---|---|
| Registry top-level ids | 170 | 161 core-backed + 9 FAA-only (was 167) |
| └ with core SKILL.md | 161 | incl. `drift-detection` (orch-flagged but has prompt); +3 Build |
| └ FAA-only (no core base) | 9 | live under `profiles/faa/skills/` (unchanged) |
| └ disk-less | 0 | — |
| Core SKILL.md dirs | 181 | 161 top-level + 20 variant + 0 orphan (was 178) |
| └ = registered top-level | 161 | |
| └ = registered variant | 20 | of 24 declared variants (unchanged) |
| └ = unregistered | 0 | **no drift** |
| FAA SKILL.md dirs | 15 | 9 FAA-only + 6 profile overrides (unchanged) |
| Registry variant ids | 24 | 20 on disk + 4 disk-less (extraction family) ⚠️ §6 (unchanged) |
| **Total distinct skill identities** | **194** | 170 top-level + 24 variants (was 191) |
| **Total SKILL.md files on disk** | **196** | 181 core + 15 FAA (was 193) |

---

## 3. EXACT count per category (all 19) — sums to 170

Categories are the `category:` **field** on each entry (NOT the section-comment headers in
`registry.yaml`, which group by *line* — see GOTCHA below). Counts via
`grep -E '^    category:' registry.yaml | sort | uniq -c`.

⚠️ **CHANGED:** two categories grew (the +3 Build skills): **Data Fetching & Analysis 17 → 19**
(`requirements-doc-ingester` + `requirements-elicitation`, both `category: Data Fetching &
Analysis`) and **Business Process & Automation 30 → 31** (`spec-from-requirements`). Both now tie
Code Scaffolding & Templates at 31 for the top slot. All other 17 category counts unchanged.

| # | Category | Count |
|---|---|---|
| 1 | Code Scaffolding & Templates | 31 |
| 2 | Business Process & Automation | 31 |
| 3 | Product Verification | 20 |
| 4 | Data Fetching & Analysis | 19 |
| 5 | Legacy Analysis | 16 |
| 6 | Library & API Reference | 12 |
| 7 | Runbooks & Operations | 11 |
| 8 | Infrastructure Operations | 6 |
| 9 | Code Quality & Review | 6 |
| 10 | Meta-Tooling | 4 |
| 11 | Cross-Cutting | 3 |
| 12 | CI/CD & Deployment | 3 |
| 13 | Identity & Auth | 2 |
| 14 | Synthesis | 1 |
| 15 | Documentation | 1 |
| 16 | Data Modeling & Schema Design | 1 |
| 17 | Compliance & Evidence | 1 |
| 18 | Architecture & Design | 1 |
| 19 | Analysis & Assessment | 1 |
| | **TOTAL** | **170** |

> ⚠️ **GOTCHA — two different "category" axes.** `registry.yaml` is physically organized by
> **assembly-line section comments** (`# Discovery` `:56`, `# Rationalization` `:499`,
> `# Architecture` `:744`, `# Data` `:1067`, `# Modernization — Extract/Design/Generate`
> `:1172/:1297/:1416`, **`# Build (Phase 6 W5)` `:1779` (NEW)**, `# Validation` `:1808`,
> `# Deployment` `:1953`, `# Disposition Execution` `:2044`, `# Sustainment` `:2323`,
> `# Governance` `:2385`, `# Cross-Cutting` `:2559`). These comments are **organizational only**
> (and the line numbers shifted with the +3 Build entries). The authoritative taxonomy is the
> per-entry `category:` field (the 19 above), which is a *capability* taxonomy orthogonal to the
> `line:` field. Do not conflate them. (`CLAUDE.md` mentions "137 skills across 12 categories" —
> both numbers are **stale**; the live values are **170** entries / 19 categories.)

---

## 4. SCHEMA-RESOLUTION FLAGS (Task §2)

### 4a. Frontmatter `output_schemas` — all 38 RESOLVE ✓ (zero unresolved)

Every one of the 38 distinct schema paths declared in a `SKILL.md` `output_schemas` block
**exists on disk** under `schemas/`. There are **0 broken frontmatter schema references**.
⚠️ **CHANGED:** +2 paths since prior baseline — the new `schemas/build/*` entries (last two rows
below). Full list (all verified present):

```
schemas/architecture/accessibility-review.schema.json      ✓
schemas/architecture/ai-ml-integration.schema.json         ✓
schemas/architecture/architecture-blueprint.schema.json    ✓
schemas/architecture/architecture-target-plan.schema.json  ✓
schemas/architecture/cloud-pattern.schema.json             ✓
schemas/architecture/cost-estimate.schema.json             ✓
schemas/architecture/design-system.schema.json             ✓
schemas/architecture/ea-compliance.schema.json             ✓
schemas/architecture/integration-arch.schema.json          ✓
schemas/architecture/security-arch.schema.json             ✓
schemas/architecture/well-architected-review.schema.json   ✓
schemas/build/requirements-capability.schema.json          ✓  ← NEW (requirements-doc-ingester + requirements-elicitation)
schemas/build/scenario-spec.schema.json                    ✓  ← NEW (spec-from-requirements)
schemas/data/data-architecture.schema.json                 ✓
schemas/data/data-domains.schema.json                      ✓
schemas/data/data-migration-plan.schema.json               ✓
schemas/data/data-product-design.schema.json               ✓
schemas/data/decomposition-strategy.schema.json            ✓
schemas/discovery/business-logic.schema.json               ✓
schemas/discovery/capability-catalog.schema.json           ✓
schemas/discovery/catalog.schema.json                      ✓
schemas/discovery/discovery-synthesis.schema.json          ✓
schemas/discovery/quality-risk.schema.json                 ✓
schemas/discovery/ux-accessibility.schema.json             ✓
schemas/rationalization/business-rule-redundancy.schema.json        ✓
schemas/rationalization/capability-consolidation-plan.schema.json   ✓
schemas/rationalization/classification.schema.json                  ✓
schemas/rationalization/disposition-governance.schema.json          ✓
schemas/rationalization/disposition-recommendation.schema.json      ✓
schemas/rationalization/integration-graph.schema.json               ✓
schemas/rationalization/portfolio-score.schema.json                 ✓
schemas/rationalization/rationalization-clustering-plan.schema.json ✓
schemas/rationalization/redundancy-matrix.schema.json               ✓
schemas/rationalization/user-impact-analysis.schema.json            ✓
schemas/rationalization/ux-overlap-matrix.schema.json               ✓
schemas/rationalization/wave-outcome-synthesis.schema.json          ✓
schemas/rationalization/wave-plan-validation.schema.json            ✓
schemas/rationalization/wave-plan.schema.json                       ✓
```

### 4b. ⚠️ FLAG — FAA *prose* schema references that DO NOT resolve

These are **not** frontmatter `output_schemas` (so they are NOT in the 36 above and are NOT
enforced by the loader), but FAA skill descriptions name a schema in prose
("Output validates against …"). 3 of 6 such prose references are **dangling** — the schema file
does not exist. Regeneration should either create the schema or correct the prose.

| FAA skill | Prose-referenced schema | Resolves? |
|---|---|---|
| `faa-form-schema-generator` | `schemas/design/faa-form-schema.schema.json` | ❌ **MISSING** |
| `aerospace-medical-certification-mapper` (medxpress) | `schemas/cross-cutting/medxpress-confirmation-binding.schema.json` | ❌ **MISSING** |
| `ame-decision-workflow-scaffolder` | `schemas/design/ame-decision-tree.schema.json` | ❌ **MISSING** |
| `pilot-certification-domain-modeler` | `schemas/design/faa-pilot-cert-domain.schema.json` | ✓ present |
| `form-8710-validator` | `schemas/design/form-8710-rules.schema.json` | ✓ present |
| `aerospace-medical-certification-mapper` | `schemas/design/medical-cert-class.schema.json` | ✓ present |

> `schemas/design/` on disk contains: `8710-field-dependency-graph`, `application-state-machine`,
> `faa-pilot-cert-domain`, `form-8710-rules`, `medical-cert-class`, `principal-mapping`
> (`.schema.json` each). The 3 missing ones above are referenced only in prose and never created.

### 4c. ⚠️ FLAG — multi-skill steps where only the PRIMARY skill carries a schema

In the wiring (companion file), most multi-skill steps emit ONE schema-validated artifact from
the **first/primary** skill; secondary skills in the same step have no frontmatter
`output_schemas` (they contribute to the same artifact or emit free-form notes). This is
**by design** (artifact-per-step), but it is drift-prone: adding a secondary skill that *should*
produce a validated artifact must add an `output_schemas` block. Examples:
`cloud-pattern-selection` step (`migration-strategy-advisor` → `cloud-pattern.schema.json`;
`deployment-topology`, `target-architecture-blueprint` → none); `integration-arch` step
(`api-contract-validator` → `integration-arch.schema.json`; `event-contract`,
`resilience-designer` → none). See companion file.

---

## 5. DRIFT FINDINGS (consolidated)

| # | Finding | Severity | Evidence |
|---|---|---|---|
| D1 | `drift-detection` is `is_orchestration: true` but HAS a core `SKILL.md` — violates the registry's own convention comment (orch ⇒ no SKILL.md). | ⚠️ convention | `registry.yaml:2431` (flag) + `cross-cutting/skills/drift-detection/SKILL.md` exists |
| D2 | 4 registered `extraction-*` variants have **NO SKILL.md on disk**: `extraction-cobol`, `extraction-coldfusion`, `extraction-java`, `extraction-python`. Declared in `registry.yaml:1182-1196` and named in `modernization.yaml:157` prose, but only `extraction-dotnet` has a file. | ⚠️ missing files | §6 |
| D3 | 3 FAA prose schema references are dangling (no schema file): `faa-form-schema-generator` → `schemas/design/faa-form-schema.schema.json`; `aerospace-medical-certification-mapper`/`medxpress-confirmation-binder` → `schemas/cross-cutting/medxpress-confirmation-binding.schema.json`; `ame-decision-workflow-scaffolder` → `schemas/design/ame-decision-tree.schema.json`. Unchanged from prior baseline. | ⚠️ broken ref | §4b |
| D4 | `CLAUDE.md` says "137 skills across 12 categories" — both numbers stale (live: **170** entries / 19 categories). | doc-staleness | `CLAUDE.md` Key Technical Concepts |
| D5 | 0 unregistered core `SKILL.md`; 0 disk-less registry entries; all **38** frontmatter schemas resolve (incl. the 2 new `schemas/build/`). | ✅ clean | §2c, §4a |
| D6 | ⚠️ **NEW** — the two Build-mode intake skills (`requirements-doc-ingester`, `requirements-elicitation`) carry `line: Discovery, step: Step 3 — Requirements Discovery (Build mode)` in the registry (`registry.yaml:96-97` / `:113-114`) but are **NOT wired as discrete `discovery.yaml` step skills** — `discovery.yaml` still has its original 14 steps with no `requirements-*` skill. They are dispatched via the **API-driven Build-mode Discovery fork** (interview/doc-ingest flow in `olympus-api/src/services/interview.py:66`,`:586` and `routers/applications.py:441+`), so they live in the wiring file's cross-line/non-step-wired section, not in the Discovery step table. | ⚠️ wiring-vs-registry | companion file |

**Net drift count: 5 actionable findings (D1–D4, D6) + 1 all-clear (D5).**

---

## 6. VARIANTS (24 declared; 20 on disk, 4 disk-less)

Variants are conditional sub-skills declared under a base skill's `variants:` list with a `when:`
predicate (tech-stack / language / disposition router). They are NOT separate registry top-level
rows. Dispatched by the workflow's per-family router (e.g. `discovery_patterns_router`,
code-gen language router, blueprint-by-disposition router).

| variant id | parent (base) | SKILL.md on disk | agent | `when:` predicate (registry) |
|---|---|---|---|---|
| `discovery-patterns-mainframe` | `discovery-patterns` | yes | opus | `tech_family: mainframe` |
| `discovery-patterns-oracle` | `discovery-patterns` | yes | sonnet | `database: oracle` |
| `discovery-patterns-sqlserver` | `discovery-patterns` | yes | sonnet | `database: sqlserver` |
| `discovery-patterns-dotnet` | `discovery-patterns` | yes | sonnet | `tech_family/language: dotnet` |
| `discovery-patterns-doc-only` | `discovery-patterns` | yes | opus | doc-only corpus |
| `extraction-cobol` | `extraction` | ❌ **NO** | — | `language: COBOL` |
| `extraction-coldfusion` | `extraction` | ❌ **NO** | — | `language: ColdFusion` |
| `extraction-dotnet` | `extraction` | yes | opus | `language: [csharp, vbnet, dotnet]` |
| `extraction-java` | `extraction` | ❌ **NO** | — | `language: Java` |
| `extraction-python` | `extraction` | ❌ **NO** | — | `language: Python` |
| `code-generation-springboot` | `code-generation` | yes | sonnet | Spring Boot target |
| `code-generation-dotnet` | `code-generation` | yes | sonnet | .NET target |
| `code-generation-fastapi` | `code-generation` | yes | sonnet | FastAPI target |
| `code-generation-node` | `code-generation` | yes | sonnet | Node target |
| `code-generation-react` | `code-generation` | yes | sonnet | React target |
| `code-generation-cobol-to-java` | `code-generation` | yes | opus | COBOL→Java |
| `code-generation-natural-to-springboot` | `code-generation` | yes | opus | NATURAL→Spring Boot |
| `data-product-design-mainframe` | `data-product-specification` | yes | opus | mainframe source |
| `data-product-design-oracle` | `data-product-specification` | yes | opus | Oracle source |
| `data-product-design-postgres` | `data-product-specification` | yes | opus | Postgres source |
| `data-product-design-sqlserver` | `data-product-specification` | yes | opus | SQL Server source |
| `target-architecture-blueprint-rearchitect` | `target-architecture-blueprint` | yes | opus | disposition=Rearchitect |
| `target-architecture-blueprint-refactor` | `target-architecture-blueprint` | yes | opus | disposition=Refactor |
| `target-architecture-blueprint-replatform` | `target-architecture-blueprint` | yes | opus | disposition=Replatform |

> ⚠️ **D2 detail (line cites refreshed).** The `extraction` base+variant family
> (`registry.yaml:1181-1199`; the 4 variant `- id:` at `:1182/:1185/:1191/:1194` + `-dotnet` at
> `:1188`) is the canonical "base + per-language variant" pattern, but 4 of 5 language variants
> are **registry-declared yet have no `SKILL.md`**. Only `extraction-dotnet` was realized. None of
> the 4 disk-less variants are dispatched by id in any line YAML (the modernization Extract step
> lists only `extraction`, `ux-flow-derivation`, `ux-page-specification`); the language fan-out is
> described in `modernization.yaml:157` prose but not wired as discrete step skills. Regeneration
> MUST either create the 4 `SKILL.md` files or drop the variant declarations. **Unchanged finding;
> only the registry line numbers shifted.**

---

## 7. FULL PER-SKILL TABLE (one row per registry top-level entry; grouped by category)

**Column legend.** `id` — registry id (`⟨FAA⟩` = FAA-only, no core base; `⟨po:faa⟩` = has FAA
profile-override layer per `profile_overrides`). `ver` — `version` (semver). `line` — `line:`
field. `step` — `step:` field (free text). `agent` — `agent:` from the skill's `SKILL.md`
frontmatter (`—` = none declared / FAA-only files that omit it). `enr` — `enrichment`. `orch` —
`is_orchestration` (**Y** if true). `output_schema(s)` — path(s) from `SKILL.md`
`output_schemas`, with the `schemas/` prefix stripped (so `discovery/catalog.schema.json` =
`schemas/discovery/catalog.schema.json`). `resolves` — yes / **NO** / `n/a` (no schema declared).

> All 170 rows below were generated by parsing `registry.yaml` + each `SKILL.md` frontmatter on
> 2026-06-15 @ HEAD `7cb3b20c`. Rows are grouped by `category` (the 19 of §3); within a group,
> order follows registry order. `(N)` after each category = row count. ⚠️ **CHANGED:** +3 rows —
> two in **Data Fetching & Analysis** (`requirements-doc-ingester`, `requirements-elicitation`)
> and one in **Business Process & Automation** (`spec-from-requirements`); all flagged ✨NEW below.

#### Data Fetching & Analysis (19)

| id | ver | line | step | agent | enr | depends_on | orch | output_schema(s) | resolves |
|---|---|---|---|---|---|---|---|---|---|
| `regulatory-knowledge-ingestion` | 1.0.0 | Discovery | Pre-Discovery — Regulatory Knowledge Ingestion | opus | partial | — |  | — | n/a |
| `catalog-application` | 1.0.0 | Discovery | Step 1 — Catalog | sonnet | minimal | — |  | discovery/catalog.schema.json | yes |
| `requirements-doc-ingester` ✨NEW | 1.0.0 | Discovery | Step 3 — Requirements Discovery (Build mode, doc-driven) | opus | partial | catalog-application |  | build/requirements-capability.schema.json | yes |
| `requirements-elicitation` ✨NEW | 1.0.0 | Discovery | Step 3 — Requirements Discovery (Build mode, interview-driven) | opus | partial | catalog-application |  | build/requirements-capability.schema.json | yes |
| `dependency-mapper` ⟨po:faa⟩ | 1.1.0 | Discovery | Step 4 — Dependency Mapping | opus | minimal | — |  | — | n/a |
| `tco-analyzer` ⟨po:faa⟩ | 1.0.0 | Discovery | Step 5 — TCO Baseline | sonnet | partial | — |  | — | n/a |
| `cocomo-cosmic-analysis` | 1.0.0 | Rationalization | On-demand — cost & effort estimation | — | partial | — |  | — | n/a |
| `discovery-synthesizer` | 1.1.0 | Discovery | Step 5 — Synthesis | opus | partial | legacy-architecture-mapper, legacy-business-rule-extractor, quality-risk-assessor, ux-accessibility-assessor |  | discovery/discovery-synthesis.schema.json | yes |
| `redundancy-analyzer` | 1.0.0 | Rationalization | Steps 1a/1b — Cross-App & Intra-App Redundancy | opus | partial | legacy-business-rule-extractor |  | rationalization/redundancy-matrix.schema.json *(dual path: redundancy-matrix.json + intra-app-redundancy.json)* | yes |
| `portfolio-scorer` | 1.0.0 | Rationalization | Step 9 — Portfolio Scoring | opus | full | legacy-business-rule-extractor |  | rationalization/portfolio-score.schema.json | yes |
| `compare-ux-overlap` | 1.1.0 | Rationalization | Step 1c — UX Overlap Analysis | opus | partial | ux-accessibility-assessor |  | rationalization/ux-overlap-matrix.schema.json | yes |
| `assess-user-impact` | 1.0.0 | Rationalization | Step 7 — User Impact Analysis | sonnet | partial | disposition-recommender, ux-accessibility-assessor |  | rationalization/user-impact-analysis.schema.json | yes |
| `wave-outcome-synthesizer` | 1.0.0 | Rationalization | Step 8 — Wave Outcome Synthesis | opus | partial | disposition-recommender, disposition-governance, tco-analyzer, assess-user-impact, classify-application, redundancy-analyzer, sequencer |  | rationalization/wave-outcome-synthesis.schema.json | yes |
| `portfolio-integration-mapper` ⟨po:faa⟩ | 1.0.0 | Rationalization | Portfolio Integration Mapping (pre-disposition) | sonnet | partial | catalog-application, dependency-mapper, legacy-architecture-mapper |  | rationalization/integration-graph.schema.json | yes |
| `analyze-portfolio-redundancy` ⟨po:faa⟩ | 1.0.0 | Rationalization | Portfolio Redundancy Synthesis (pre-disposition) | sonnet | partial | redundancy-analyzer, portfolio-integration-mapper |  | rationalization/rationalization-clustering-plan.schema.json | yes |
| `cross-app-business-rule-analyzer` ⟨po:faa⟩ | 1.0.0 | Rationalization | Cross-App Business Rule Synthesis (pre-disposition) | opus | partial | legacy-business-rule-extractor |  | rationalization/business-rule-redundancy.schema.json | yes |
| `portfolio-manifest-generator` | 1.0.0 | Rationalization | Portfolio Manifest (final wave close-out) | opus | partial | wave-outcome-synthesizer, disposition-recommender, catalog-application |  | — | n/a |
| `requirement-aggregation` | 1.0.0 | Modernization | Step 1 — Extract (modern requirement harvest) | opus | partial | — |  | — | n/a |
| `adoption-analytics` | 1.0.0 | Deployment | Step 4 — Adoption Verification | sonnet | minimal | user-adoption-coordinator |  | — | n/a |

#### Legacy Analysis (16)

| id | ver | line | step | agent | enr | depends_on | orch | output_schema(s) | resolves |
|---|---|---|---|---|---|---|---|---|---|
| `legacy-architecture-mapper` | 1.0.0 | Discovery | Step 3 — Pass 1 (Application & Data Mapping) | opus | minimal | — |  | — | n/a |
| `discovery-patterns` ⟨po:faa⟩ | 1.0.0 | Discovery | Step 3 — Pass 1 (tech-stack patterns) | sonnet | partial | catalog-application, legacy-architecture-mapper |  | — | n/a |
| `legacy-business-rule-extractor` | 1.1.0 | Discovery | Step 3 — Pass 2 (Business Logic) | opus | partial | — |  | discovery/business-logic.schema.json | yes |
| `capability-extraction` ⟨po:faa⟩ | 1.0.0 | Discovery | Step 3 — Pass 6 (Capability + System Grain) | sonnet | partial | catalog-application, legacy-architecture-mapper, data-domain-patterns |  | discovery/capability-catalog.schema.json | yes |
| `quality-risk-assessor` | 1.2.0 | Discovery | Step 3 — Pass 3 (Quality & Risk) | sonnet | partial | — |  | discovery/quality-risk.schema.json | yes |
| `ux-accessibility-assessor` | 1.0.0 | Discovery | Step 3 — Pass 4 (UX & Accessibility) | sonnet | minimal | accessibility-checker |  | discovery/ux-accessibility.schema.json | yes |
| `legacy-language-reader` | 1.0.0 | Discovery | Step 3 — Pass 1 (language detection + reader dispatch) | sonnet | partial | catalog-application |  | — | n/a |
| `legacy-database-archaeologist` ⟨po:faa⟩ | 1.0.0 | Discovery | Step 3 — Pass 1 (database archaeology) | opus | full | catalog-application, legacy-architecture-mapper |  | — | n/a |
| `legacy-data-flow-tracer` ⟨po:faa⟩ | 1.0.0 | Discovery | Step 3 — Pass 1 (data-flow tracing) | opus | partial | legacy-architecture-mapper, legacy-database-archaeologist |  | — | n/a |
| `identity-landscape-analyzer` ⟨po:faa⟩ | 1.0.0 | Discovery | Step 3 — Portfolio identity pass (NIST 800-63) | opus | partial | catalog-application |  | — | n/a |
| `compliance-citation-mapper` ⟨po:faa⟩ | 1.0.0 | Discovery | Step 3 — Regulatory citation scan | sonnet | full | catalog-application |  | — | n/a |
| `tiff-corpus-assessor` ⟨po:faa⟩ | 1.0.0 | Discovery | Step 3 — Conditional image-corpus assessment | opus | full | catalog-application, legacy-architecture-mapper |  | — | n/a |
| `decomposition-patterns` ⟨po:faa⟩ | 1.1.0 | Data | Steps 2–3 — Shared-DB Analysis + Decomposition Strategy | opus | minimal | — |  | data/decomposition-strategy.schema.json | yes |
| `business-rule-reconciliation` | 1.0.0 | Modernization | Step 1 — Extract (rule reconciliation) | opus | partial | extraction, legacy-business-rule-extractor, requirement-aggregation |  | — | n/a |
| `ux-flow-derivation` | 1.0.0 | Modernization | Step 1 — Extract (UX flow derivation) | opus | full | extraction, legacy-architecture-mapper |  | — | n/a |
| `aerospace-medical-certification-mapper` ⟨FAA⟩ | 0.1.0 | Modernization | Step 2 — Design (FAA medical class definitions) | opus | minimal | legacy-business-rule-extractor |  | — | n/a |

#### Product Verification (20)

| id | ver | line | step | agent | enr | depends_on | orch | output_schema(s) | resolves |
|---|---|---|---|---|---|---|---|---|---|
| `accessibility-checker` ⟨po:faa⟩ | 1.0.0 | Discovery | Step 3 — Pass 4 (UX & Accessibility) | sonnet | partial | — |  | — | n/a |
| `api-contract-validator` ⟨po:faa⟩ | 1.0.0 | Architecture | Step 4 — Integration Architecture | sonnet | partial | migration-strategy-advisor |  | architecture/integration-arch.schema.json | yes |
| `accessibility-reviewer` | 1.0.0 | Architecture | Step 8 — Accessibility Review | sonnet | partial | design-system |  | architecture/accessibility-review.schema.json | yes |
| `well-architected-reviewer` ⟨po:faa⟩ | 1.0.0 | Architecture | Step 10c — Well-Architected Review | opus | partial | blueprint-assembly |  | architecture/well-architected-review.schema.json | yes |
| `cross-validation` | 1.0.0 | Modernization | Step 1 — Extract (validation pass) | sonnet | minimal | extraction |  | — | n/a |
| `traceability-audit` | 1.1.0 | Modernization | Step 2 — Design (audit) | sonnet | partial | module-design, api-specification, data-modeling, target-schema-ddl |  | — | n/a |
| `test-validation` | 1.1.0 | Modernization | Step 3 — Generate (test verification) | sonnet | partial | tdd-generation |  | — | n/a |
| `parity-verifier` | 1.1.0 | Validation | Stream 1 — Functional Parity | sonnet | full | — |  | — | n/a |
| `acceptable-divergences` | 1.0.0 | Validation | Stream 1 — Functional Parity | sonnet | minimal | parity-verifier |  | — | n/a |
| `safety-critical-verifier` ⟨po:faa⟩ | 2.1.0 | Validation | Stream 4 — Safety Assurance | opus | partial | — |  | — | n/a |
| `formal-test-plan-generator` ⟨po:faa⟩ | 1.0.0 | Validation | Stream 1 — Functional Parity (formal test plan, T1/T2 pre-G-V1) | sonnet | partial | parity-verifier, traceability-checker, blueprint-assembly |  | — | n/a |
| `validation-cutover` | 1.0.0 | Disposition Execution | Replatform — Validation & Cut-over | sonnet | minimal | component-configuration |  | — | n/a |
| `test-coverage-uplift` | 1.0.0 | Disposition Execution | Retain — Quality | sonnet | minimal | — |  | — | n/a |
| `drift-detection` | 1.0.0 | Governance | Activity 2 — Drift Detection | sonnet | minimal | drift-detection-architecture, drift-detection-compliance, drift-detection-performance, drift-detection-cost, drift-detection-adoption | **Y** | — | n/a |
| `drift-detection-architecture` | 1.0.0 | Governance | Activity 2 — Drift Detection | sonnet | minimal | — |  | — | n/a |
| `drift-detection-compliance` ⟨po:faa⟩ | 1.0.0 | Governance | Activity 2 — Drift Detection | sonnet | minimal | accessibility-checker |  | — | n/a |
| `drift-detection-performance` | 1.0.0 | Governance | Activity 2 — Drift Detection | sonnet | minimal | — |  | — | n/a |
| `drift-detection-cost` | 1.0.0 | Governance | Activity 2 — Drift Detection | sonnet | minimal | tco-analyzer |  | — | n/a |
| `drift-detection-adoption` | 1.0.0 | Governance | Activity 2 — Drift Detection | sonnet | minimal | adoption-analytics |  | — | n/a |
| `spec-reviewer` | 1.0.0 | Modernization | Step 3 — Generate (post-generation) | opus | full | tdd-plan-writer, code-generation |  | — | n/a |

#### Business Process & Automation (31)

| id | ver | line | step | agent | enr | depends_on | orch | output_schema(s) | resolves |
|---|---|---|---|---|---|---|---|---|---|
| `spec-from-requirements` ✨NEW | 1.0.0 | **Build** | Step 1 — Spec-from-Requirements | opus | partial | requirements-elicitation, requirements-doc-ingester |  | build/scenario-spec.schema.json | yes |
| `srs-from-discovery` | 1.0.0 | Discovery | Step 5 — SRS derivation (pre-G-DC) | opus | partial | legacy-architecture-mapper, legacy-business-rule-extractor, discovery-synthesizer |  | — | n/a |
| `disposition-recommender` | 1.0.0 | Rationalization | Step 5 — Disposition Recommendation | opus | partial | legacy-business-rule-extractor, redundancy-analyzer, portfolio-scorer |  | rationalization/disposition-recommendation.schema.json | yes |
| `disposition-governance` | 1.0.0 | Rationalization | Step 6 — Disposition Governance | sonnet | partial | disposition-recommender |  | rationalization/disposition-governance.schema.json | yes |
| `classify-application` ⟨po:faa⟩ | 1.0.0 | Rationalization | Step 8 — Classification & Risk Tiering | opus | partial | — |  | rationalization/classification.schema.json | yes |
| `sequencer` | 1.1.0 | Rationalization | Step 10 — Wave Planning | opus | partial | disposition-recommender, classify-application, portfolio-scorer |  | rationalization/wave-plan.schema.json<br>rationalization/wave-plan-validation.schema.json | yes |
| `classify-complexity` | 1.0.0 | Rationalization | Classification & Risk Tiering (sibling) | sonnet | partial | catalog-application, legacy-architecture-mapper, portfolio-integration-mapper |  | — | n/a |
| `capability-consolidation-advisor` ⟨po:faa⟩ | 1.0.0 | Rationalization | Capability Consolidation Advisory | opus | partial | portfolio-integration-mapper, disposition-recommender, disposition-governance |  | rationalization/capability-consolidation-plan.schema.json | yes |
| `target-state-mapper` | 1.0.0 | Architecture | Step 1 — Target-State Mapping | opus | partial | disposition-recommender, disposition-governance, redundancy-analyzer |  | architecture/architecture-target-plan.schema.json | yes |
| `blueprint-assembly` | 1.0.0 | Architecture | Step 10 — Blueprint Assembly | opus | partial | target-state-mapper, migration-strategy-advisor, ea-compliance, api-contract-validator, event-contract, security-posture-analyzer, cato-compliance, design-system, accessibility-reviewer, ai-ml-integration, target-architecture-blueprint, resilience-designer, deployment-topology |  | architecture/architecture-blueprint.schema.json | yes |
| `target-architecture-blueprint` ⟨po:faa⟩ | 1.1.0 | Architecture | Step 2b — Target Architecture Blueprint | opus | partial | target-state-mapper, migration-strategy-advisor |  | — | n/a |
| `cloud-cost-estimator` ⟨po:faa⟩ | 1.0.0 | Architecture | Step 10b — Cloud Cost Estimate | sonnet | partial | blueprint-assembly |  | architecture/cost-estimate.schema.json | yes |
| `escalation-handler` | 1.0.0 | Modernization | Step 3 — Generate (Ralph Loop escalation) | sonnet | minimal | — |  | — | n/a |
| `gate-review-package` ⟨po:faa⟩ | 1.1.0 | Modernization | All gates | sonnet | partial | — |  | — | n/a |
| `user-adoption-coordinator` ⟨po:faa⟩ | 2.0.0 | Deployment | Step 4 — Adoption Verification | sonnet | minimal | — |  | — | n/a |
| `user-transition-planning` | 1.0.0 | Disposition Execution | Pre-cutover — User Transition Planning | sonnet | minimal | — |  | — | n/a |
| `data-archival-planning` | 1.0.0 | Disposition Execution | Pre-cutover — Data Archival Planning | sonnet | minimal | — |  | — | n/a |
| `consumer-migration-planning` | 1.0.0 | Disposition Execution | Pre-cutover — Consumer Migration Planning | sonnet | minimal | dependency-mapper |  | — | n/a |
| `vendor-evaluation` | 1.0.0 | Disposition Execution | Replace — Vendor/COTS Evaluation | opus | minimal | redundancy-analyzer |  | — | n/a |
| `platform-selection` | 1.0.0 | Disposition Execution | Replatform — Platform Selection | opus | minimal | — |  | — | n/a |
| `target-selection` | 1.0.0 | Disposition Execution | Consolidate — Target Selection | opus | minimal | — |  | — | n/a |
| `feature-gap-analysis` | 1.0.0 | Disposition Execution | Consolidate — Feature Gap Analysis | sonnet | minimal | target-selection |  | — | n/a |
| `data-reconciliation-planning` | 1.0.0 | Disposition Execution | Consolidate — Data Reconciliation Planning | sonnet | minimal | target-selection |  | — | n/a |
| `enhancement-planning` | 1.0.0 | Disposition Execution | Consolidate — Enhancement Planning | sonnet | minimal | feature-gap-analysis |  | — | n/a |
| `requirements-derivation` | 1.0.0 | Disposition Execution | Replace — Requirements Derivation | sonnet | minimal | — |  | — | n/a |
| `integration-specification` | 1.0.0 | Disposition Execution | Replace — Integration Specification | sonnet | minimal | vendor-evaluation |  | — | n/a |
| `workflow-mapping` | 1.0.0 | Disposition Execution | Replatform — Workflow Mapping | sonnet | minimal | platform-selection |  | — | n/a |
| `component-configuration` | 1.0.0 | Disposition Execution | Replatform — Component Configuration | sonnet | minimal | workflow-mapping |  | — | n/a |
| `data-migration-planning` | 1.0.0 | Disposition Execution | Replace/Replatform — Data Migration Planning | sonnet | minimal | — |  | — | n/a |
| `change-conflict-resolver` | 1.0.0 | Sustainment | Activity 2 — Coordination | sonnet | minimal | — |  | — | n/a |
| `wave-status-report` | 1.0.0 | Governance | Activity 6 — Reporting | sonnet | minimal | — |  | — | n/a |

#### Cross-Cutting (3)

| id | ver | line | step | agent | enr | depends_on | orch | output_schema(s) | resolves |
|---|---|---|---|---|---|---|---|---|---|
| `migration-strategy-advisor` | 1.1.0 | Architecture | Step 2 — Target Architecture Strategy | opus | minimal | target-state-mapper |  | architecture/cloud-pattern.schema.json | yes |
| `gate-pre-review` | 1.1.0 | Cross-Cutting | All 15 gates | sonnet | partial | — |  | — | n/a |
| `olympus-collaboration` | 1.0.0 | Cross-Cutting | Human-paired-agent dispatch + return | — | full | — |  | — | n/a |

#### Library & API Reference (12)

| id | ver | line | step | agent | enr | depends_on | orch | output_schema(s) | resolves |
|---|---|---|---|---|---|---|---|---|---|
| `ea-compliance` ⟨po:faa⟩ | 2.0.0 | Architecture | Step 3 — EA Compliance Verification | sonnet | partial | migration-strategy-advisor |  | architecture/ea-compliance.schema.json | yes |
| `ai-ml-integration` ⟨po:faa⟩ | 1.1.0 | Architecture | Step 9 — AI/ML Integration | opus | minimal | target-state-mapper, migration-strategy-advisor |  | architecture/ai-ml-integration.schema.json | yes |
| `security-posture-analyzer` ⟨po:faa⟩ | 1.0.0 | Architecture | Step 6 — Security Architecture | opus | minimal | — |  | — | n/a |
| `cato-compliance` ⟨po:faa⟩ | 2.0.0 | Architecture | Step 6 — Security Architecture | sonnet | partial | — |  | architecture/security-arch.schema.json | yes |
| `design-system` ⟨po:faa⟩ | 2.1.0 | Architecture | Step 7 — Design System Mapping | sonnet | partial | — |  | architecture/design-system.schema.json | yes |
| `data-mesh-architecture` ⟨po:faa⟩ | 1.1.0 | Data | Reference-only (no dispatch) | opus | minimal | — |  | — | n/a |
| `cato-evidence-validator` ⟨po:faa⟩ | 2.0.0 | Validation | Stream 2 — Security & Compliance | sonnet | minimal | cato-compliance |  | — | n/a |
| `faa-code-standards` ⟨FAA⟩ | 1.0.0 | Modernization | Step 3 — Generate | — | minimal | — |  | — | n/a |
| `faa-style-greenfield` ⟨FAA⟩ | 1.0.0 | Modernization | Step 3 — Generate | — | minimal | — |  | — | n/a |
| `faa-style-brownfield` ⟨FAA⟩ | 1.0.0 | Sustainment | Activity 1 — O&M | — | minimal | — |  | — | n/a |
| `faa-form-schema-generator` ⟨FAA⟩ | 0.1.0 | Modernization | Step 2 — Design (FAA form single-source schemas) | sonnet | minimal | — |  | — *(prose ref `schemas/design/faa-form-schema.schema.json` — ❌ MISSING, §4b)* | n/a |
| `form-8710-validator` ⟨FAA⟩ | 0.1.0 | Modernization | Step 2 — Design (FAA Form 8710 validators) | sonnet | minimal | — |  | — | n/a |

#### Code Scaffolding & Templates (31)

| id | ver | line | step | agent | enr | depends_on | orch | output_schema(s) | resolves |
|---|---|---|---|---|---|---|---|---|---|
| `event-contract` ⟨po:faa⟩ | 1.0.0 | Architecture | Step 4 — Integration Architecture | sonnet | minimal | migration-strategy-advisor |  | — | n/a |
| `data-domain-patterns` | 1.1.0 | Data | Step 1 — Data Domain Discovery | opus | minimal | — |  | data/data-domains.schema.json | yes |
| `data-migration-planner` | 1.0.0 | Data | Step 4 — Migration Planning | opus | minimal | decomposition-patterns |  | data/data-migration-plan.schema.json | yes |
| `data-product-specification` | 1.2.0 | Data | Step 5 — Data Product Design | opus | minimal | data-domain-patterns |  | data/data-product-design.schema.json | yes |
| `extraction` | 1.1.0 | Modernization | Step 1 — Extract | opus | partial | legacy-business-rule-extractor |  | — | n/a |
| `batch-extraction` | 1.0.0 | Modernization | Step 1 — Extract (batch archetype) | opus | minimal | — |  | — | n/a |
| `ux-page-specification` | 1.0.0 | Modernization | Step 1 — Extract (UX page specification) | opus | full | ux-flow-derivation, extraction, legacy-architecture-mapper |  | — | n/a |
| `module-design` | 1.1.0 | Modernization | Step 2 — Design | opus | full | extraction |  | — | n/a |
| `ux-component-specification` ⟨po:faa⟩ | 1.0.0 | Modernization | Step 2 — Design (UX component specification) | opus | full | ux-page-specification, extraction |  | — | n/a |
| `api-specification` ⟨po:faa⟩ | 1.0.0 | Modernization | Step 2 — Design | sonnet | full | module-design |  | — | n/a |
| `batch-design` ⟨po:faa⟩ | 1.0.0 | Modernization | Step 2 — Design (batch archetype) | sonnet | minimal | batch-extraction |  | — | n/a |
| `target-schema-ddl` | 1.0.0 | Modernization | Step 2 — Design (Data Model — DDL authoring) | sonnet | full | data-modeling |  | — | n/a |
| `gfi-pp-scenarios` ⟨po:faa⟩ | 1.0.0 | Modernization | Factory Configuration — test-data provisioning | sonnet | minimal | target-schema-ddl |  | — | n/a |
| `tdd-generation` | 1.2.1 | Modernization | Step 3 — Generate (test authoring — Ralph Loop step 1) | sonnet | full | module-design, api-specification |  | — | n/a |
| `code-generation` ⟨po:faa⟩ | 1.1.0 | Modernization | Step 3 — Generate (implementation — Ralph Loop step 2) | sonnet | minimal | tdd-generation, module-design, api-specification |  | — | n/a |
| `batch-generation` | 1.0.0 | Modernization | Step 3 — Generate (batch archetype) | sonnet | minimal | batch-design |  | — | n/a |
| `code-synthesis` | 1.0.1 | Modernization | Step 3 — Generate (cross-context merge) | opus | minimal | tdd-generation, module-design, api-specification |  | — | n/a |
| `form-rules-engine-scaffolder` | 0.1.0 | Modernization | Step 2 — Design (form conditional rules) | sonnet | minimal | legacy-business-rule-extractor |  | — | n/a |
| `temporal-workflow-scaffolder` | 0.1.0 | Modernization | Step 3 — Generate (durable workflow) | sonnet | minimal | xstate-fsm-generator, legacy-business-rule-extractor |  | — | n/a |
| `xstate-fsm-generator` | 0.1.0 | Modernization | Step 3 — Generate (FSM scaffold) | sonnet | minimal | module-design |  | — | n/a |
| `sse-broadcaster-scaffolder` | 0.1.0 | Modernization | Step 3 — Generate (real-time push) | sonnet | minimal | event-contract |  | — | n/a |
| `outbox-pattern-scaffolder` | 0.1.0 | Modernization | Step 3 — Generate (transactional outbox) | sonnet | minimal | event-contract, data-modeling |  | — | n/a |
| `schema-driven-wizard-generator` | 0.1.0 | Modernization | Step 3 — Generate (multi-section wizard) | sonnet | minimal | xstate-fsm-generator, form-rules-engine-scaffolder |  | — | n/a |
| `audit-immutability-trigger-generator` | 0.1.0 | Modernization | Step 3 — Generate (audit append-only) | sonnet | minimal | data-modeling |  | — | n/a |
| `validation-rule-template` | 1.0.0 | Modernization | Step 1 — Extract | sonnet | full | extraction |  | — | n/a |
| `workflow-state-machine-template` | 1.0.0 | Modernization | Step 2 — Design | sonnet | full | legacy-business-rule-extractor, srs-from-discovery |  | — | n/a |
| `gherkin-scenario-generator` | 1.0.0 | Modernization | Step 3 — Generate | sonnet | full | extraction, validation-rule-template, workflow-state-machine-template |  | — | n/a |
| `tdd-plan-writer` | 1.0.0 | Modernization | Step 3 — Generate | sonnet | full | extraction, validation-rule-template, workflow-state-machine-template |  | — | n/a |
| `iac-scaffolding-generator` | 1.0.0 | Modernization | Step 3 — Generate (infrastructure) | sonnet | full | phase2-constraint-loader, api-specification, event-contract |  | — | n/a |
| `medxpress-confirmation-binder` ⟨FAA⟩ | 0.1.0 | Modernization | Step 3 — Generate (MedXPress integration) | sonnet | minimal | aerospace-medical-certification-mapper |  | — | n/a |
| `ame-decision-workflow-scaffolder` ⟨FAA⟩ | 0.1.0 | Modernization | Step 3 — Generate (AME decision workflow) | sonnet | minimal | aerospace-medical-certification-mapper, temporal-workflow-scaffolder |  | — *(prose ref `schemas/design/ame-decision-tree.schema.json` — ❌ MISSING, §4b)* | n/a |

#### Infrastructure Operations (6)

| id | ver | line | step | agent | enr | depends_on | orch | output_schema(s) | resolves |
|---|---|---|---|---|---|---|---|---|---|
| `deployment-topology` ⟨po:faa⟩ | 1.0.0 | Architecture | Step 2 — Target Architecture Strategy | sonnet | partial | migration-strategy-advisor, target-state-mapper |  | — | n/a |
| `resilience-designer` ⟨po:faa⟩ | 1.0.0 | Architecture | Step 4 — Integration Architecture | opus | partial | migration-strategy-advisor |  | — | n/a |
| `environment-cleanup` | 1.0.0 | Deployment | Step 5 — Legacy Decommission | sonnet | minimal | legacy-decommission |  | — | n/a |
| `portfolio-health-check` | 1.0.0 | Governance | Activity 1 — Health | sonnet | minimal | — |  | — | n/a |
| `factory-health-check` | 1.0.0 | Governance | Activity 6 — Factory Analytics | sonnet | minimal | — |  | — | n/a |
| `factory-capacity-manager` | 1.0.0 | Governance | Activity 6 — Capacity | opus | minimal | — |  | — | n/a |

#### Code Quality & Review (6)

| id | ver | line | step | agent | enr | depends_on | orch | output_schema(s) | resolves |
|---|---|---|---|---|---|---|---|---|---|
| `architecture-traceability-validator` | 1.0.0 | Architecture | Step 10d — Traceability Validation (pre-G-02) | sonnet | partial | blueprint-assembly |  | — | n/a |
| `adversarial-review` | 1.0.0 | Modernization | Step 3 — Generate (review) | sonnet | minimal | tdd-generation |  | — | n/a |
| `security-posture-review` ⟨po:faa⟩ | 1.0.0 | Modernization | Step 3 — Generate (security posture) | sonnet | minimal | code-synthesis |  | — | n/a |
| `traceability-checker` | 1.0.0 | Validation | Streams 1, 4 — Traceability | sonnet | minimal | — |  | — | n/a |
| `security-scan-review` ⟨po:faa⟩ | 1.0.0 | Validation | Stream 2 — Security & Compliance (scan triage) | sonnet | minimal | — |  | — | n/a |
| `security-anomaly-resolution` ⟨po:faa⟩ | 1.0.0 | Validation | Stream 2 — Security & Compliance (anomaly resolution, pre-G-V2) | opus | partial | security-scan-review, security-posture-analyzer, cato-compliance |  | — | n/a |

#### Synthesis (1)

| id | ver | line | step | agent | enr | depends_on | orch | output_schema(s) | resolves |
|---|---|---|---|---|---|---|---|---|---|
| `data-modeling` | 2.0.0 | Data | Step 6 — Data Architecture Synthesis | opus | minimal | data-domain-patterns, decomposition-patterns, data-migration-planner, data-product-specification |  | data/data-architecture.schema.json | yes |

#### Identity & Auth (2)

| id | ver | line | step | agent | enr | depends_on | orch | output_schema(s) | resolves |
|---|---|---|---|---|---|---|---|---|---|
| `jwt-claim-mapper` | 0.1.0 | Modernization | Step 2 — Design (auth principal mapping) | sonnet | minimal | oidc-server-integration, data-modeling |  | — | n/a |
| `oidc-server-integration` | 0.1.0 | Modernization | Step 3 — Generate (OIDC server config) | sonnet | minimal | identity-landscape-analyzer |  | — | n/a |

#### Compliance & Evidence (1)

| id | ver | line | step | agent | enr | depends_on | orch | output_schema(s) | resolves |
|---|---|---|---|---|---|---|---|---|---|
| `oscal-fragment-emitter` | 0.1.0 | Modernization | Step 3 — Generate (cATO evidence) | sonnet | minimal | — |  | — | n/a |

#### CI/CD & Deployment (3)

| id | ver | line | step | agent | enr | depends_on | orch | output_schema(s) | resolves |
|---|---|---|---|---|---|---|---|---|---|
| `deploy-modernized-app` ⟨po:faa⟩ | 1.0.0 | Deployment | Step 1 — Deployment Orchestration | sonnet | minimal | — |  | — | n/a |
| `traffic-shift` ⟨po:faa⟩ | 2.0.0 | Deployment | Step 2 — Traffic Shifting | sonnet | minimal | — |  | — | n/a |
| `parallel-run-monitor` | 1.0.0 | Deployment | Step 3 — Parallel Run | sonnet | minimal | — |  | — | n/a |

#### Runbooks & Operations (11)

| id | ver | line | step | agent | enr | depends_on | orch | output_schema(s) | resolves |
|---|---|---|---|---|---|---|---|---|---|
| `legacy-decommission` ⟨po:faa⟩ | 1.0.0 | Deployment | Step 5 — Legacy Decommission | sonnet | minimal | — |  | — | n/a |
| `security-decommission` | 1.0.0 | Disposition Execution | Retire — Security Decommission | sonnet | minimal | — |  | — | n/a |
| `license-reclamation` | 1.0.0 | Disposition Execution | Retire — License Reclamation | sonnet | minimal | — |  | — | n/a |
| `security-remediation-planning` | 1.0.0 | Disposition Execution | Retain — Security | sonnet | minimal | security-posture-analyzer |  | — | n/a |
| `documentation-remediation` | 1.0.0 | Disposition Execution | Retain — Documentation | sonnet | minimal | — |  | — | n/a |
| `monitoring-bootstrap` | 1.0.0 | Disposition Execution | Retain — Observability | sonnet | minimal | — |  | — | n/a |
| `sustainment-handoff` | 1.1.0 | Disposition Execution | Retain — Handoff | sonnet | partial | — |  | — | n/a |
| `incident-response` ⟨po:faa⟩ | 1.0.0 | Sustainment | Activity 1 — O&M | sonnet | minimal | — |  | — | n/a |
| `patch-assessment` ⟨po:faa⟩ | 1.0.0 | Sustainment | Activity 1 — O&M | sonnet | minimal | — |  | — | n/a |
| `sla-breach-investigation` ⟨po:faa⟩ | 1.0.0 | Sustainment | Activity 1 — O&M | sonnet | minimal | — |  | — | n/a |
| `cost-anomaly-investigation` ⟨po:faa⟩ | 1.0.0 | Sustainment | Activity 3 — AIOps | sonnet | minimal | — |  | — | n/a |

#### Meta-Tooling (4)

| id | ver | line | step | agent | enr | depends_on | orch | output_schema(s) | resolves |
|---|---|---|---|---|---|---|---|---|---|
| `model-benchmark` | 1.0.0 | Governance | Activity 6 — Factory Analytics | opus | minimal | — |  | — | n/a |
| `skill-builder` | 1.0.0 | Governance | Activity 5 — Pattern Extraction | opus | minimal | — |  | — | n/a |
| `decomposition-skill-writer` | 1.0.0 | Governance | Activity 5 — Skill Lifecycle | opus | Full | — |  | — | n/a |
| `skill-validator` | 1.0.0 | Governance | Activity 5 — Skill Lifecycle | sonnet | minimal | skill-builder |  | — | n/a |

#### Architecture & Design (1)

| id | ver | line | step | agent | enr | depends_on | orch | output_schema(s) | resolves |
|---|---|---|---|---|---|---|---|---|---|
| `phase2-constraint-loader` | 1.0.0 | Architecture | Step 1 — Constraint Definition | sonnet | full | — |  | — | n/a |

#### Documentation (1)

| id | ver | line | step | agent | enr | depends_on | orch | output_schema(s) | resolves |
|---|---|---|---|---|---|---|---|---|---|
| `user-guide-generator` | 1.0.0 | Modernization | Step 2 — Design | opus | full | gherkin-scenario-generator, extraction, smart-defaults-analyzer |  | — | n/a |

#### Analysis & Assessment (1)

| id | ver | line | step | agent | enr | depends_on | orch | output_schema(s) | resolves |
|---|---|---|---|---|---|---|---|---|---|
| `smart-defaults-analyzer` | 1.0.0 | Modernization | Step 2 — Design | sonnet | full | extraction, legacy-business-rule-extractor |  | — | n/a |

#### Data Modeling & Schema Design (1)

| id | ver | line | step | agent | enr | depends_on | orch | output_schema(s) | resolves |
|---|---|---|---|---|---|---|---|---|---|
| `pilot-certification-domain-modeler` ⟨FAA⟩ | 0.1.0 | Modernization | Step 2 — Design (FAA pilot cert schema) | opus | minimal | data-modeling |  | — *(prose ref `schemas/design/faa-pilot-cert-domain.schema.json` — ✓ present)* | n/a |

> **Row count check:** 19+16+20+31+3+12+31+6+6+1+2+1+3+11+4+1+1+1+1 = **170** ✓
> (Δ vs prior baseline: Data Fetching 17→19, Business Process 30→31.)

---

## 8. Regeneration notes

- To regenerate `registry.yaml`: emit the 170 top-level entries (with the §3 category
  distribution) + 24 nested variants, preserving each entry's `version`, `category`, `line`,
  `step`, `enrichment`, `is_orchestration`, `variants`, `profile_overrides`, `depends_on`, and
  (for FAA-only entries) `profile: faa`. The loader
  (`olympus_api.services.skill_registry.load_registry`) ignores unknown nested fields, so optional
  `currency` / `validation_commands` / `supported_stacks` / `failure_classes` / `benchmark_tags`
  blocks (`registry.yaml:29-52`) may be present on some entries.
- To regenerate each `SKILL.md` frontmatter: it MUST carry `name` (= id) and `agent`
  (`opus`|`sonnet`; some FAA files omit it — treat as default). **38** core files additionally
  carry an `output_schemas:` list (the 38 paths of §4a) — incl. the 3 Build skills, whose
  frontmatter also declares a `required_outputs:` list (e.g. `spec-from-requirements` requires
  `scenario-spec.json` + `business-rules-catalog.yaml` + `traceability-matrix.md`, but only
  `scenario-spec.json` is schema-bound). FAA files carry extra benchmark fields
  (`enrichment_level`, `phase`, `validation_commands`, `supported_stacks`) — see
  `faa-form-schema-generator` frontmatter as the worked example.
- ⚠️ Keep schema paths repo-root-relative (`schemas/<area>/<name>.schema.json`). The loader/
  validator resolves them from repo root, NOT from the skill directory.
- ⚠️ The `agent` field is the model tier, NOT a runtime endpoint. Mapping to Bedrock model ids
  is done by the agent-runtime (see `regen/02-agent-runtime.md`), not here.
