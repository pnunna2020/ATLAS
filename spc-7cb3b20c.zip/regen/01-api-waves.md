# Regeneration Spec — Phase 8 API: Waves Router (`waves.py`)

**Source of truth:** `/Users/pnunna/Documents/GitHub/foundry/olympus-api/src/routers/waves.py` (3300 lines).
**Mount:** `router = APIRouter(prefix="/api/v1/waves", tags=["Waves"])` (waves.py:106). All paths below are **full paths** (prefix included).
**Endpoint count:** 32 (`@router.*` decorators at lines 178, 268, 344, 385, 426, 451, 474, 497, 520, 546, 566, 590, 620, 644, 665, 692, 721, 749, 778, 808, 838, 879, 923, 951, 1024, 1946, 1969, 2318, 2801, 2913, 3058, 3153). ⚠️ REFRESHED to HEAD `7cb3b20c`: the `/{wave_id}/start` handler gained a `delegation` parameter (paired-work / multi-provider dispatch, +2 lines), shifting every endpoint after [6] by +2 from the prior baseline; all `waves.py:N` citations ≥452 were re-anchored.
**Router-mount order = decorator order** below. Preserve it exactly (FastAPI matches first-declared first; `/assign`, `/bulk-onboard` are declared *after* `/{wave_id}` variants but use distinct verbs/paths so no shadowing — `POST /assign` is line 474, well after `GET/PUT/DELETE /{wave_id}`; the literal segment wins over `{wave_id}` for GET/PUT/DELETE but POST `/assign` has no `POST /{wave_id}` competitor).

---

## 0. Shared Auth / Dependency Primitives

### RBACRole role sets (waves.py:86-104)
```python
VIEWER_PLUS = [VIEWER, TECH_LEAD, ARCH_LEAD, COMPLIANCE_LEAD, OPERATIONS_LEAD,
               SAFETY_BOARD, PORTFOLIO_MANAGER, PORTFOLIO_ADMIN]
MANAGER_ROLES = [PORTFOLIO_MANAGER, PORTFOLIO_ADMIN]
ADMIN_ROLES   = [PORTFOLIO_ADMIN]
```
`RBACRole` is an enum (string values). Role values come from JWT `roles` claim.

### `require_role(*roles)` (auth.py:106-119)
Returns a FastAPI dependency. Inner `_check(user=Depends(get_current_user))`:
```
if not user.has_role(*required_roles):   # has_role = ANY of roles in user.roles
    raise HTTPException(403, detail=f"Requires one of: {[r.value for r in required_roles]}")
return user
```
`CurrentUser` (auth.py:32-41): `.sub:str`, `.roles:list[RBACRole]`, `.claims:dict`, `.has_role(*roles)->bool`.
`get_current_user` (auth.py:52-103): decodes Bearer JWT. If `DEV_AUTH_BYPASS=true` → user `sub="local-dev"` with ALL roles. Missing token → 401. JWTError → 401. Empty roles → defaults `[VIEWER]`.

### `require_wave_member` path-dependency (dependencies.py:160-169)
```
if user.has_role(PORTFOLIO_ADMIN): return user      # admin short-circuit, no DB hit
await verify_wave_portfolio_access(db, user, wave_id) # resolves wave→portfolio→membership; 404 if wave missing, 403 PORTFOLIO_NOT_MEMBER
return user
```
Used as `dependencies=[Depends(require_wave_member)]` on all `/{wave_id}/...` routes (resolves `wave_id` from `Path`).

### `verify_portfolio_access(db, user, portfolio_id)` (dependencies.py:105-133)
Service-level (body/query param) membership check.
```
if user.has_role(PORTFOLIO_ADMIN): return
if await membership_svc.is_member(db, portfolio_id, user.sub): return
raise HTTPException(403, detail={"code":"PORTFOLIO_NOT_MEMBER","message":"Caller is not a member of this portfolio. Ask a portfolio_admin to grant access."})
```

### `filter_portfolio_ids_by_membership(db, user)` (dependencies.py:389)
Returns `None` for admins (= no filter / all portfolios), else `list[uuid]` of member portfolio ids (possibly empty).

### `get_temporal_client()` (dependencies.py:34) → `temporalio.client.Client`. `get_config()` (dependencies.py:29) → `AppConfig`.

### `OlympusHTTPException(status, code, message)` (middleware/error_handler) — the canonical error raise used throughout. `(int status, str code, str message)`.

### ⚠️ GOTCHA — dual auth on every endpoint
Most endpoints carry BOTH `Depends(require_role(...))` (role check) AND `dependencies=[Depends(require_wave_member)]` (membership check). The `require_role` result is bound to a param named either `_user` (unused) or `user` (used for `.sub`). **`PORTFOLIO_ADMIN` bypasses membership but still must satisfy role gate** (admin is in all three role lists, so it always passes both).

### ⚠️ GOTCHA — indentation typo in source (NOT a bug)
Many `dependencies=[Depends(require_wave_member)]` lines have a leading single-space mis-indent (e.g. waves.py:647, 668, 695, 724, 753, 781, 811, 842, 883, 926, 955, 1949, 1972, 2322, 2804, 2917, 3061, 3157). Cosmetic only; reproduce as standard 4-space kwarg. Do not let this confuse parsing.

---

## 1. Request / Response Models (`src/models/wave.py`)

All `BaseModel`. Fields with defaults are optional in the request/response.

| Model | Fields (name: type = default) | Source |
|---|---|---|
| **WaveCreate** (req) | `name:str`; `portfolio_id:UUID`; `description:str\|None=None`; `application_ids:list[UUID]\|None=None` | wave.py:17 |
| **WaveUpdate** (req) | `name:str\|None=None`; `status:str\|None=None`; `description:str\|None=None` | wave.py:26 |
| **WaveDetail** (resp) | `id:UUID`; `portfolio_id:UUID`; `name:str`; `wave_number:int`; `status:str`; `description:str\|None=None`; `workflow_id:str\|None=None`; `app_count:int=0`; `discovery_ready_count:int=0`; `application_ids:list[UUID]=[]`; `planned_start:date\|None`; `planned_end:date\|None`; `actual_start:date\|None`; `actual_end:date\|None`; `created_at:datetime\|None`; `updated_at:datetime\|None` | wave.py:34 |
| **WaveStartRequest** (req) | `max_apps_per_wave:int=Field(default=10, ge=1, le=50)` | wave.py:63 |
| **WaveStartResponse** (resp) | `workflow_id:str`; `temporal_ui_url:str`; `status:str="started"` | wave.py:69 |
| **WaveCancelRationalizationResponse** (resp) | `wave_id:UUID`; `workflow_id:str`; `requested:bool=True`; `detail:str` | wave.py:77 |
| **WaveResetResponse** (resp) | `wave_id:UUID`; `previous_workflow_id:str\|None=None`; `status:str="ready"`; `detail:str` | wave.py:94 |
| **WaveResumeRequest** (req) | `target_app_ids:list[UUID]=[]` | wave.py:111 |
| **WaveResumeTargetResult** | `target_app_id:UUID`; `architecture_action:str` (∈ already-running/respawned/skipped/failed); `data_action:str` (same enum); `detail:str=""` | wave.py:129 |
| **WaveResumeResponse** (resp) | `wave_id:UUID`; `targets:list[WaveResumeTargetResult]`; `respawned_count:int`; `already_running_count:int`; `failed_count:int`; `detail:str` | wave.py:140 |
| **WaveAssignmentRequest** (req) | `portfolio_id:UUID`; `max_apps_per_wave:int=10` | wave.py:157 |
| **WaveAssignmentResult** (resp) | `waves:list[dict]`; `waves_created:int=0`; `waves_unchanged:int=0`; `apps_assigned:int=0` | wave.py:164 |
| **WaveBulkOnboardRequest** (req) | `portfolio_id:UUID`; `application_ids:list[UUID]=Field(min_length=1)`; `wave_id:UUID\|None=None` | wave.py:185 |
| **WaveAssignAppsRequest** (req) | `application_ids:list[UUID]=Field(min_length=1)` | wave.py:205 |
| **WaveRemoveAppsRequest** (req) | `application_ids:list[UUID]=Field(min_length=1)` | wave.py:219 |
| **WaveReadyRequest** (req) | `stakeholder:str\|None=None` | wave.py:230 |
| **WaveAppProgress** | `app_id:UUID`; `app_name:str`; `current_line:str\|None=None`; `current_status:str\|None=None`; `progress_pct:float\|None=None` | wave.py:242 |
| **WaveAppProgressResponse** (resp) | `wave_id:UUID`; `apps:list[WaveAppProgress]=[]` | wave.py:267 |
| **WaveProgressStep** | `step_id:str`; `line_id:str`; `status:str`; `started_at:datetime\|None`; `completed_at:datetime\|None`; `duration_ms:int\|None`; `skill_id:str\|None`; `task_type:str\|None`; `step_kind:str\|None` | wave.py:284 |
| **WaveProgressResponse** (resp) | `wave_id:UUID`; `workflow_id:str\|None`; `status:str\|None`; `reported_status:str\|None`; `current_step:str\|None`; `progress_pct:float\|None`; `started_at:datetime\|None`; `updated_at:datetime\|None`; `duration_seconds:int\|None`; `last_error:str\|None`; `step_timeline:list[WaveProgressStep]=[]`; `temporal_unreachable:bool=False`; `temporal_ui_url:str\|None`; `wave_elapsed_seconds:int\|None`; `current_step_elapsed_seconds:int\|None` | wave.py:304 |
| **WavePendingGateEntry** | `gate_id:UUID`; `gate_type:str`; `application_id:UUID\|None`; `application_name:str\|None`; `pr_url:str\|None`; `opened_at:datetime\|None`; `reviewer_scope_required:list[str]=[]` | wave.py:360 |
| **WavePendingGatesResponse** (resp) | `pending:list[WavePendingGateEntry]=[]` | wave.py:378 |
| **WaveCancelAllChildrenResponse** (resp) | `wave_id:UUID`; `cancelled_at:datetime` | wave.py:384 |
| **WavePerfStep** | `step_id:str`; `step_kind:str\|None`; `agent_skill:str\|None`; `invocation_count:int=0`; `total_ms:int=0`; `avg_ms:float\|None`; `p50_ms:float\|None`; `p95_ms:float\|None`; `total_agent_llm_ms:int\|None`; `total_agent_tool_ms:int\|None`; `avg_tool_calls_per_invocation:float\|None`; `total_input_tokens:int\|None`; `total_output_tokens:int\|None`; `total_cost_estimate:float\|None` | wave.py:402 |
| **WavePerfLine** | `line_id:str`; `app_count:int=0`; `total_ms:int=0`; `p50_app_ms:float\|None`; `p95_app_ms:float\|None`; `steps:list[WavePerfStep]=[]` | wave.py:432 |
| **WavePerfBottleneck** | `category:str` (agent-llm/agent-tool/step-wall/fanout); `line_id:str\|None`; `step_id:str\|None`; `median_ms:float\|None`; `description:str` | wave.py:453 |
| **WavePerformanceReport** (resp) | `wave_id:UUID`; `wall_clock_total_ms:int\|None`; `lines:list[WavePerfLine]=[]`; `bottlenecks:list[WavePerfBottleneck]=[]` | wave.py:468 |
| **WaveAppActivityRow** | `application_id:UUID`; `application_name:str`; `target_systems:list[SystemRef]=[]`; `realizes_capability:CapabilityRef\|None`; `latest_activity:AgentActivitySummary\|None` | wave.py:498 |
| **WaveAppActivityResponse** (resp) | `wave_id:UUID`; `items:list[WaveAppActivityRow]=[]` | wave.py:520 |

**Embedded sub-models (`src/models/application.py`):**
- **SystemRef** (app.py:32): `id:UUID`; `name:str`; `external_id:str\|None`; `kind:str\|None`; `role:str\|None`.
- **CapabilityRef** (app.py:49): `id:UUID`; `name:str`; `external_id:str\|None`; `system_id:UUID`; `system_name:str`; `system_external_id:str\|None`; `primary_disposition:str\|None`; `secondary_disposition:str\|None`; `target_systems:list[SystemRef]=[]`.
- **AgentActivitySummary** (app.py:71): `task_id:UUID`; `line:AssemblyLineName\|None`; `skill_id:str\|None`; `task_type:str\|None`; `status:str\|None`; `actor_kind:ActorKind="olympus_agent"`; `local_agent_descriptor:LocalAgentDescriptor\|None`; `human_user_id:str\|None`; `started_at:datetime\|None`; `completed_at:datetime\|None`.

**Inline models declared inside `waves.py`** (used only by the dispatch/tier-1 surface): see §3 model block.

---

## 2. CRUD + Lifecycle Endpoints (1–24)

> Convention: "auth = `require_role(X)` + member-dep" means the route has `Depends(require_role(X))` plus `dependencies=[Depends(require_wave_member)]` (path waves only). "thin delegate" = handler just forwards to `wave_svc`/`perf_svc` (logic lives in that service spec).

### [1] `POST /api/v1/waves` — create_wave (waves.py:178-265)
- **status_code=201**, `response_model=WaveDetail`.
- **Auth:** `_user=Depends(require_role(*MANAGER_ROLES))`, `user=Depends(get_current_user)`, `db=Depends(get_db)`. (NO member-dep — wave doesn't exist yet; membership checked on body's portfolio_id.)
- **Body:** `WaveCreate`.
- **Logic (reproduce all branches):**
```
await verify_portfolio_access(db, user, body.portfolio_id)        # 403 if not member
dupe = SELECT 1 FROM wave WHERE portfolio_id=:pid AND lower(name)=lower(:name) LIMIT 1
if dupe: raise OlympusHTTPException(409, "WAVE_NAME_EXISTS", f"A wave named '{body.name}' already exists in this portfolio.")
max_num = SELECT COALESCE(MAX(wave_number),0) FROM wave WHERE portfolio_id=:pid   (or 0)
wave_number = max_num + 1
wave_id = uuid4()
INSERT INTO wave (id, portfolio_id, wave_number, name, description, status) VALUES (..., 'draft')
app_ids = []
if body.application_ids:
    for app_id in body.application_ids:
        INSERT INTO wave_application (wave_id, application_id) VALUES (:wid,:aid)
        app_ids.append(app_id)
await db.commit()
return WaveDetail(id, portfolio_id, name, wave_number, status='draft', description, app_count=len(app_ids), application_ids=app_ids)
```
- **Status codes:** 201 ok; 403 PORTFOLIO_NOT_MEMBER; 409 WAVE_NAME_EXISTS; 422 validation.
- ⚠️ GOTCHA: name uniqueness is **case-insensitive, portfolio-scoped** (`lower(name)`).

### [2] `GET /api/v1/waves` — list_waves (waves.py:268-341)
- **No explicit response_model** → returns `dict` (paginated envelope).
- **Auth:** query `portfolio_id:uuid|None=None`; `pagination=Depends(get_pagination)` (PaginationParams: `per_page`, `offset`, `page`); `_user=Depends(require_role(*VIEWER_PLUS))`; `user=Depends(get_current_user)`; `db`.
- **Logic:**
```
if portfolio_id is not None: await verify_portfolio_access(db, user, portfolio_id)
member_ids = await filter_portfolio_ids_by_membership(db, user)   # None for admin
clauses=[]; params={limit:per_page, offset:offset}
if member_ids is not None:
    if not member_ids: clauses.append("FALSE")            # member of nothing → empty result
    else: clauses.append("w.portfolio_id = ANY(:pf_ids)"); params[pf_ids]=member_ids
if portfolio_id: clauses.append("w.portfolio_id = :pid"); params[pid]=portfolio_id
where = "WHERE "+ " AND ".join(clauses) if clauses else ""
total = SELECT count(*) FROM wave w {where}    (or 0)
rows  = SELECT w.* FROM wave w {where} ORDER BY w.wave_number ASC LIMIT :limit OFFSET :offset
waves=[]
for r in rows:
    app_count = SELECT count(*) FROM wave_application WHERE wave_id=:wid   (or 0)
    discovery_ready_count = await _count_discovery_ready(db, row.id)
    waves.append(_wave_detail_from_row(row, app_count, discovery_ready_count).model_dump(mode="json"))
return paginated_response(waves, total, pagination)
```
- ⚠️ GOTCHA: ordered `wave_number ASC`. Non-admin sees only member portfolios; admin sees all.

### [3] `GET /api/v1/waves/{wave_id}` — get_wave (waves.py:344-382)
- `response_model=WaveDetail`; member-dep.
- **Auth:** `_user=Depends(require_role(*VIEWER_PLUS))`, member-dep, db.
- **Logic:**
```
row = SELECT * FROM wave WHERE id=:id
if row is None: raise OlympusHTTPException(404, "WAVE_NOT_FOUND", f"Wave {wave_id} not found")
app_rows = SELECT application_id FROM wave_application WHERE wave_id=:wid
application_ids = [r.application_id ...]
discovery_ready_count = await _count_discovery_ready(db, wave_id)
return _wave_detail_from_row(row, app_count=len(application_ids), application_ids, discovery_ready_count)
```
- 200 ok; 404 WAVE_NOT_FOUND; 403 (member-dep).

### [4] `PUT /api/v1/waves/{wave_id}` — update_wave (waves.py:385-423)
- `response_model=WaveDetail`; member-dep; `_user=Depends(require_role(*MANAGER_ROLES))`.
- **Body:** `WaveUpdate`.
- **Logic:**
```
row = SELECT * FROM wave WHERE id=:id
if row is None: 404 WAVE_NOT_FOUND
updates=dict(row); set_clauses=[]; params={id:wave_id}
if body.name is not None:   set_clauses+= "name = :name";   params[name]=...; updates[name]=...
if body.status is not None: set_clauses+= "status = :status"; params[status]=...; updates[status]=...
if set_clauses:
    set_clauses.append("updated_at = now()")
    UPDATE wave SET {set_clauses} WHERE id=:id
    await db.commit()
return _wave_detail_from_row(updates)
```
- ⚠️ GOTCHA: `body.description` is in the model but is **NOT written** here (only name + status). No-op when both name and status are None (no commit; returns current row).

### [5] `DELETE /api/v1/waves/{wave_id}` — delete_wave (waves.py:426-448)
- **status_code=204**; member-dep; `_user=Depends(require_role(*ADMIN_ROLES))` (PORTFOLIO_ADMIN only).
- **Logic:**
```
row = SELECT id FROM wave WHERE id=:id
if row is None: 404 WAVE_NOT_FOUND
DELETE FROM wave WHERE id=:id     # wave_application FK cascade cleans junction
await db.commit()
return None
```
- 204 ok; 404; 403 (admin only).

### [6] `POST /api/v1/waves/{wave_id}/start` — start_wave (waves.py:451-471)
- **status_code=202**, `response_model=WaveStartResponse`; member-dep; `_user=Depends(require_role(*MANAGER_ROLES))`; `temporal=Depends(get_temporal_client)`.
- **Body:** `WaveStartRequest | None = None` (optional). ⚠️ At HEAD `WaveStartRequest` carries `max_apps_per_wave` AND a new optional `delegation` field (paired-work / multi-provider dispatch directive forwarded to the workflow).
- **Logic (thin delegate — STARTS Temporal `WaveWorkflow`):**
```
config = get_config()
max_apps = body.max_apps_per_wave if body else 10
delegation = body.delegation if body else None              # ⚠️ NEW at HEAD — paired-work delegation directive
return await wave_svc.start_wave(db, str(wave_id), temporal, config.temporal_task_queue, max_apps,
                                 delegation=delegation)
```
- ⚠️ Fires Temporal: launches the **legacy per-app fan-out `WaveWorkflow`** (kept for backward compat; rationalization uses `/rationalize`). The `delegation` directive (when present) is threaded into the workflow start input.

### [7] `POST /api/v1/waves/assign` — assign_waves_endpoint (waves.py:474-494)
- `response_model=WaveAssignmentResult`. **No member-dep** (body-scoped). `_user=Depends(require_role(*MANAGER_ROLES))`; `user=Depends(get_current_user)`.
- **Body:** `WaveAssignmentRequest`.
- **Logic:**
```
await verify_portfolio_access(db, user, body.portfolio_id)
result = await assign_waves(db, str(body.portfolio_id), body.max_apps_per_wave)   # from src.services.wave_assignment
return WaveAssignmentResult(**result)
```
- ⚠️ GOTCHA (F22): `assign_waves` PERSISTS draft waves + `wave_application` links in one transaction and reports truthful `waves_created`/`apps_assigned`. Not a pure proposer.

### [8] `POST /api/v1/waves/bulk-onboard` — bulk_onboard (waves.py:497-517)
- **status_code=201**, `response_model=WaveDetail`. No member-dep (body-scoped). `_user=Depends(require_role(*MANAGER_ROLES))`; `user=Depends(get_current_user)`.
- **Body:** `WaveBulkOnboardRequest`.
- **Logic:**
```
await verify_portfolio_access(db, user, body.portfolio_id)
return await wave_svc.bulk_onboard_apps(db, str(body.portfolio_id),
        [str(a) for a in body.application_ids],
        target_wave_id=str(body.wave_id) if body.wave_id else None)
```
- Service contract: attaches apps to portfolio's draft wave (creates one if none); idempotent; targeted wave must be `draft` else 400 WAVE_NOT_DRAFT.

### [9] `POST /api/v1/waves/{wave_id}/ready` — mark_ready (waves.py:520-543)
- `response_model=WaveDetail`; member-dep; `user=Depends(require_role(*MANAGER_ROLES))` (note bound to `user`, used).
- **Body:** `WaveReadyRequest | None = None`.
- **Logic:**
```
stakeholder = body.stakeholder if (body and body.stakeholder) else user.sub
return await wave_svc.mark_wave_ready(db, str(wave_id), stakeholder)
```
- Flips `draft → ready`. Service enforces all-apps-Discovery-ready guard.

### [10] `POST /api/v1/waves/{wave_id}/cancel` — cancel_wave (waves.py:546-563)
- `response_model=WaveDetail`; member-dep; `user=Depends(require_role(*MANAGER_ROLES))`.
- **No body.**
- **Logic:** `return await wave_svc.cancel_wave(db, str(wave_id), stakeholder=user.sub)`
- Service: **draft waves only** (P5-S28 Q22). Rationalized/completed cannot cancel.

### [11] `POST /api/v1/waves/{wave_id}/revert` — revert_wave_to_draft (waves.py:566-587)
- `response_model=WaveDetail`; member-dep; `user=Depends(require_role(*MANAGER_ROLES))`. No body.
- **Logic:** `return await wave_svc.revert_wave_to_draft(db, str(wave_id), stakeholder=user.sub)`
- Service: only valid while `ready` and `workflow_id` unset; else 400 WAVE_NOT_REVERTIBLE.

### [12] `POST /api/v1/waves/{wave_id}/assign-apps` — assign_apps (waves.py:590-617)
- `response_model=WaveDetail`; member-dep; `user=Depends(require_role(*MANAGER_ROLES))`.
- **Body:** `WaveAssignAppsRequest`.
- **Logic:** `return await wave_svc.assign_apps_to_wave(db, str(wave_id), [str(a) for a in body.application_ids], stakeholder=user.sub)`
- Service: target wave must be `draft` (400 WAVE_NOT_DRAFT); any source wave must be `draft` (400 SOURCE_WAVE_LOCKED).

### [13] `POST /api/v1/waves/{wave_id}/remove-apps` — remove_apps (waves.py:620-641)
- `response_model=WaveDetail`; member-dep; `user=Depends(require_role(*MANAGER_ROLES))`.
- **Body:** `WaveRemoveAppsRequest`.
- **Logic:** `return await wave_svc.remove_apps_from_wave(db, str(wave_id), [str(a) for a in body.application_ids], stakeholder=user.sub)`
- Service: wave must be `draft` (400 WAVE_NOT_DRAFT); idempotent.

### [14] `GET /api/v1/waves/{wave_id}/app-progress` — get_wave_app_progress (waves.py:644-662)
- `response_model=WaveAppProgressResponse`; member-dep; `_user=Depends(require_role(*VIEWER_PLUS))`.
- **Logic:** `return await wave_svc.get_wave_app_progress(db, str(wave_id))`
- Only valid for `in_progress` waves; else 400 WAVE_NOT_IN_PROGRESS.

### [15] `GET /api/v1/waves/{wave_id}/app-activity` — get_wave_app_activity (waves.py:665-689)
- `response_model=WaveAppActivityResponse`; member-dep; `_user=Depends(require_role(*VIEWER_PLUS))`.
- **Logic:** `return await wave_svc.get_wave_app_activity(db, wave_id)`  (passes raw UUID, not str)
- 404 WAVE_NOT_FOUND for unknown ids.

### [16] `GET /api/v1/waves/{wave_id}/progress` — get_wave_progress (waves.py:692-718)
- `response_model=WaveProgressResponse`; member-dep; `_user=Depends(require_role(*VIEWER_PLUS))`; `temporal=Depends(get_temporal_client)`.
- **Logic:** `config=get_config(); return await wave_svc.get_wave_progress(db, str(wave_id), temporal, config)`
- Surfaces `WaveRationalizationWorkflow` state. 404 WAVE_NOT_FOUND; 409 WAVE_WORKFLOW_NOT_STARTED (no workflow_id); 200 with `temporal_unreachable=true` + `reported_status` from DB when describe RPC fails.

### [17] `GET /api/v1/waves/{wave_id}/performance-report` — get_wave_performance_report (waves.py:721-746)
- `response_model=WavePerformanceReport`; member-dep; `_user=Depends(require_role(*VIEWER_PLUS))`.
- **Logic:** `return await perf_svc.get_wave_performance_report(db, str(wave_id))` (from `src.services.performance_report`).
- Read-only. 404 WAVE_NOT_FOUND; empty `lines` when no steps executed.

### [18] `POST /api/v1/waves/{wave_id}/rationalize` — start_rationalization (waves.py:749-775)
- **status_code=202**, `response_model=WaveStartResponse`; member-dep; `user=Depends(require_role(*MANAGER_ROLES))`; `temporal`.
- **No body.**
- **Logic (STARTS Temporal `WaveRationalizationWorkflow`):**
```
config = get_config()
return await wave_svc.start_wave_rationalization(db, str(wave_id), temporal, config.temporal_task_queue, stakeholder=user.sub)
```
- Only `draft`/`ready` waves. Produces one cross-portfolio redundancy matrix; fires gates **G-RR** and **G-DA** at wave scope.

### [19] `POST /api/v1/waves/{wave_id}/cancel-rationalization` — cancel_wave_rationalization (waves.py:778-805)
- `response_model=WaveCancelRationalizationResponse`; member-dep; `user=Depends(require_role(*MANAGER_ROLES))`; `temporal`.
- **Logic:** `config=get_config(); return await wave_svc.cancel_wave_rationalization(db, str(wave_id), temporal, config, stakeholder=user.sub)`
- ⚠️ Fires Temporal cancel signal + forced cancel after grace; resets wave to `ready`, `workflow_id`→NULL, `actual_start`→NULL. 409 WAVE_NOT_RUNNING when no live workflow.

### [20] `POST /api/v1/waves/{wave_id}/reset` — reset_wave (waves.py:808-835)
- `response_model=WaveResetResponse`; member-dep; `user=Depends(require_role(*MANAGER_ROLES))`. No temporal, no body.
- **Logic:** `return await wave_svc.reset_wave_to_ready(db, str(wave_id), stakeholder=user.sub)`
- Service: `failed → ready`; clears `workflow_id`,`failed_at`,`failure_reason`,`actual_start`. 409 WAVE_NOT_FAILED on any non-failed status.

### [21] `POST /api/v1/waves/{wave_id}/resume` — resume_wave_fanout (waves.py:838-876)
- **status_code=202**, `response_model=WaveResumeResponse`; member-dep; `_user=Depends(require_role(*MANAGER_ROLES))`; `temporal`.
- **Body:** `WaveResumeRequest | None = None`.
- **Logic (may RESPAWN Temporal Arch/Data workflows):**
```
config = get_config()
return await wave_svc.resume_wave_fanout(db, str(wave_id), temporal, config.temporal_task_queue, request=body, config=config)
```
- Idempotent; RUNNING workflows reported `already-running`. Relies on arch_data_signal_registry (migration 046) + `arch-data-sibling-lifecycle-v1` patch.

### [22] `POST /api/v1/waves/{wave_id}/retry-rationalization` — retry_wave_rationalization (waves.py:879-915)
- **status_code=202**, `response_model=WaveStartResponse`; member-dep; `user=Depends(require_role(*MANAGER_ROLES))`; `temporal`.
- **Logic (cancel + STARTS new `WaveRationalizationWorkflow`):**
```
config = get_config()
return await wave_svc.retry_wave_rationalization(db, str(wave_id), temporal, config.temporal_task_queue, config, stakeholder=user.sub)
```
- If `in_progress` w/ live wf → best-effort cancel, then relaunch. Non-startable statuses bubble 400/409.

### [23] `GET /api/v1/waves/{wave_id}/pending-gates` — list_wave_pending_gates (waves.py:923-948)
- `response_model=WavePendingGatesResponse`; member-dep; `_user=Depends(require_role(*VIEWER_PLUS))`.
- **Logic:** `return await wave_svc.list_pending_fanout_gates(db, str(wave_id))`
- Aggregated G-02/G-DT reviewer queue across the wave's apps; rows ordered `opened_at ASC`.

### [24] `POST /api/v1/waves/{wave_id}/cancel-all-children` — cancel_all_children (waves.py:951-981)
- **status_code=202**, `response_model=WaveCancelAllChildrenResponse`; member-dep; `user=Depends(require_role(*MANAGER_ROLES))`; `temporal`.
- **Logic:** `config=get_config(); return await wave_svc.cancel_all_wave_children(db, str(wave_id), temporal, config, stakeholder=user.sub)`
- ⚠️ Fires single `cancel_all_children` Temporal signal to wave's orchestrator. 404 WAVE_NOT_FOUND; 409 WAVE_HAS_NO_WORKFLOW; 202 w/ `wave_id`+`cancelled_at` otherwise.

---

## 3. Wave Artifact Read-Through + Dispatch Surface (25–32)

### Inline models declared in waves.py

| Model | Fields | Source |
|---|---|---|
| **WaveArtifactResponse** (resp) | `wave_id:UUID`; `path:str`; `commit_sha:str`; `content:str`; `data:dict\|list\|None=None` | waves.py:989 |
| **DispatchArchitectureTargetRequest** (v1 entry) | `source_app_id:str`; `target_app_name:str`; `target_repo:str`; `default_branch:str="main"` | waves.py:1139 |
| **DispatchArchitectureRequest** (v1 body) | `targets:list[DispatchArchitectureTargetRequest]=[]` | waves.py:1153 |
| **DispatchArchitectureTargetV2Request** (v2 entry) | `target_app_id:str`; `target_service_id:str`; `target_app_name:str`; `target_repo:str`; `relationship:str`; `source_app_ids:list[str]=[]`; `default_branch:str="main"` | waves.py:1159 |
| **DispatchArchitectureRequestV2** (v2 body) | `targets:list[DispatchArchitectureTargetV2Request]=[]` | waves.py:1178 |
| **DispatchPreviewTargetEntry** | `target_app_id:str`; `target_service_id:str=""`; `target_name_seed:str=""`; `target_repo_slug:str=""`; `relationship:str=""`; `source_app_ids:list[str]=[]`; `source_app_names:list[str]=[]`; `rationale:str=""` | waves.py:1186 |
| **DispatchPreviewTargetResponse** (resp) | `wave_id:UUID`; `entries:list[DispatchPreviewTargetEntry]=[]` | waves.py:1204 |
| **DispatchArchitectureResponse** (resp) | `wave_id:UUID`; `workflow_id:str`; `dispatched:int`; `skipped_retire:int=0`; `status:str="dispatched"`; `detail:str=""` | waves.py:1211 |
| **DispatchPreviewEntry** | `source_app_id:str`; `source_app_name:str`; `disposition:str`; `needs_target_input:bool`; `peer_source_app_ids:list[str]=[]`; `peer_source_app_names:list[str]=[]` | waves.py:1229 |
| **DispatchPreviewResponse** (resp) | `wave_id:UUID`; `entries:list[DispatchPreviewEntry]=[]` | waves.py:1245 |
| **DispatchTargetStatusItem** | `source_app_id:str=""`; `source_app_ids:list[str]=[]`; `source_app_names:list[str]=[]`; `target_app_id:str=""`; `target_app_name:str=""`; `target_repo:str=""`; `disposition:str=""`; `line:str=""`; `step:str=""`; `status:str="pending"`; `error:str=""`; `architecture_workflow_id:str=""`; `architecture_workflow_status:str=""`; `data_workflow_id:str=""`; `data_workflow_status:str=""`; `temporal_ui_url:str=""` | waves.py:1252 |
| **DispatchStatusResponse** (resp) | `wave_id:UUID`; `status:str`; `targets:list[DispatchTargetStatusItem]=[]` | waves.py:1277 |
| **DispatchRetryRequest** (req) | `source_app_id:str`; `target_app_name:str`; `target_repo:str`; `default_branch:str="main"` | waves.py:1285 |
| **DispatchRetryResponse** (resp) | `wave_id:UUID`; `source_app_id:str`; `status:str="retry-queued"` | waves.py:1294 |
| **Tier1PendingItem** | `app_id:str`; `app_name:str`; `risk_tier:str="1"`; `classification_path:str`; `awaiting_since:str\|None=None` | waves.py:3022 |
| **Tier1PendingResponse** (resp) | `wave_id:UUID`; `workflow_id:str\|None=None`; `items:list[Tier1PendingItem]=[]` | waves.py:3034 |
| **Tier1ApprovalRequest** (req) | `app_id:str`; `approval_id:str\|None=None`; `rationale:str\|None=None`; `stakeholder:str\|None=None` | waves.py:3040 |
| **Tier1ApprovalResponse** (resp) | `wave_id:UUID`; `workflow_id:str`; `app_id:str`; `approval_id:str`; `status:str`; `detail:str=""` | waves.py:3049 |

### Helper functions (logic reproduced where load-bearing)

**`_count_discovery_ready(db, wave_id)` (waves.py:136-175)** — used by list/get:
```sql
SELECT COUNT(*) AS n FROM application a
JOIN wave_application wa ON wa.application_id = a.id
WHERE wa.wave_id = :wid
  AND a.current_line IS NOT NULL
  AND (a.current_line != 'Discovery' OR a.current_status IN ('completed','discovery_complete'))
```
Returns `int(n)` or 0. ⚠️ NULL `current_line` → not-ready.

**`_wave_detail_from_row(row, app_count=0, application_ids=None, discovery_ready_count=0)` (waves.py:109-133)** — builds WaveDetail; `name = row.get("name") or ""`.

**`_reject_path_traversal(path)` (waves.py:1005-1021):**
```
if not path: 400 INVALID_PATH "path query parameter is required"
if path.startswith("/") or path.startswith("\\"): 400 INVALID_PATH "path must be relative"
segments = path.replace("\\","/").split("/")
if any(seg == ".." or seg == "" for seg in segments): 400 INVALID_PATH "path must not contain '..' or empty segments"
```

**`_resolve_wave_context(db, wave_id)` (waves.py:1308-1354)** → `(wave_row, apps)`:
```
wave_row = SELECT id, portfolio_id, name, status, workflow_id, architecture_workflow_id FROM wave WHERE id=:id
if wave_row is None: 404 WAVE_NOT_FOUND
app_rows = SELECT a.id app_id, a.name app_name FROM application a JOIN wave_application wa ON wa.application_id=a.id WHERE wa.wave_id=:wid
apps = [{app_id:str(id), app_name:name or ""} ...]
return dict(wave_row), apps
```

**`_resolve_artifact_repo(db, portfolio_id)` (waves.py:1357-1371):** `SELECT artifact_repo_url FROM portfolio WHERE id=:id` → str or "".

**Disposition preview loader chain (waves.py:1374-1943)** — load-bearing for v1 dispatch + dispatch-preview:
- `_apply_portfolio_consolidation_fallback(per_app_artifacts, apps, portfolio_clusters)` (1372): Part C. For each cluster in `consolidation_candidates[]`: skip if `<2` members, or any member not in wave, or any member's disposition != "Consolidate", or any member already has `target_hint.peer_app_ids`. Else pick anchor = `cluster.anchor_app_id` → `canonical_target_candidate` → `members[0]` (must be in wave else `members[0]`); `peer_app_ids = members - anchor`; inject `anchor_art["target_hint"]={"kind":"consolidate-target","peer_app_ids":...}` + `_recovered_from_portfolio_matrix=True`. Returns NEW dict.
- `_build_preview_from_artifacts(apps, per_app_artifacts, portfolio_clusters=None)` (1463): if clusters → apply Part C first. Compute `consumed_as_peer` set from all `target_hint.kind=="consolidate-target"` peer lists. For each app not consumed: `disposition = art.recommended_disposition or art.disposition or ""`; peers from hint; `needs_input = bool(disposition) and disposition != "Retire"`; emit `DispatchPreviewEntry`. ⚠️ Consolidate peers folded into anchor row; Retire rows emitted with `needs_target_input=False`.
- `_VALID_DISPOSITIONS` (1544): `(Retire, Retain, Refactor, Rearchitect, Replatform, Replace, Consolidate)`.
- `_MD_DISPOSITION_PATTERN` (1578) + `_extract_disposition_from_markdown(md)` (1590): regex matches `Recommendation`/`Recommended Disposition` then `:`OR`|` then one of 7 verbs (case-insensitive; returns canonical TitleCase).
- `_MD_PEERS_PATTERN` (1619), `_PEERS_SPLIT_PATTERN` (1635, splits on `,` or `+`), `_extract_peers_from_markdown(md)` (1638): harvest peer roster line.
- `_UUID_HINT_PATTERN` (1670) + `_resolve_peer_entries_to_app_ids(raw, apps, self_app_id)` (1676): UUID-shaped → match `app_id` (lower); else match `app_name` (lower, first-declared wins on collision); drops `self_app_id` + dedups.
- `_md_fallback_artifact(disposition, peer_app_ids=None)` (1721): `{recommended_disposition: disposition}`; if Consolidate + peers → add `target_hint` + `_recovered_from_markdown=True`.
- `_load_single_preview_artifact(git_svc, json_path, app_id, apps=None)` (1747): read json via `parse_agent_json` (markdown-fence-tolerant); if dict w/ disposition key → return. Else fall back to `.md` sibling (`json_path[:-len(".json")]+".md"`); extract disposition; if none → log + return parsed; for Consolidate w/ apps → reconstruct peers; return `_md_fallback_artifact(...)`.
- `_load_preview_entries(db, wave_row, apps, config)` (1850): resolve artifact_repo; if no repo or no github_token → stub rows (all None) via `_build_preview_from_artifacts`. Else GitService, per-app path `rationalization/wave-{id}/{app_id}/disposition-recommendation.json`, then Part C clusters from `_load_portfolio_consolidation_clusters`, return `_build_preview_from_artifacts(apps, per_app, portfolio_clusters)`.
- `_load_portfolio_consolidation_clusters(git_svc, wave_id)` (1909): read `rationalization/wave-{id}/portfolio-redundancy-matrix.json`; any failure → `[]`; return `consolidation_candidates` list (dicts only).

---

### [25] `GET /api/v1/waves/{wave_id}/artifacts` — get_wave_artifact (waves.py:1024-1130)
- `response_model=WaveArtifactResponse`; member-dep; `_user=Depends(require_role(*VIEWER_PLUS))`.
- **Query:** `path:str = Query(..., description=...)` (REQUIRED; relative to `rationalization/wave-{wave_id}/`).
- **Logic:**
```
_reject_path_traversal(path)
wave_row = SELECT id, portfolio_id FROM wave WHERE id=:id
if None: 404 WAVE_NOT_FOUND
portfolio_row = SELECT artifact_repo_url FROM portfolio WHERE id=:portfolio_id
artifact_repo = (portfolio_row.artifact_repo_url or "") if portfolio_row else ""
if not artifact_repo: 404 ARTIFACT_REPO_NOT_CONFIGURED
config = get_config()
if not config.github_token: 503 GIT_TOKEN_MISSING
full_path = f"rationalization/wave-{wave_id}/{path}"
try:
    git_svc = GitService(GitServiceConfig(token, repo=artifact_repo, base_url=github_base_url))
    result = git_svc.read_file(path=full_path)
except GitServiceError as exc:
    if "not found" in str(exc).lower(): 404 ARTIFACT_NOT_FOUND
    else: log + 502 GIT_READ_FAILED
data = None
if path.endswith(".json"):
    try: parsed = json.loads(result.content); if dict|list: data = parsed
    except JSONDecodeError: log warning "wave_artifact_malformed_json"  # data stays None
return WaveArtifactResponse(wave_id, path, commit_sha=result.commit_sha, content=result.content, data=data)
```
- 200; 400 INVALID_PATH; 404 WAVE_NOT_FOUND / ARTIFACT_REPO_NOT_CONFIGURED / ARTIFACT_NOT_FOUND; 502 GIT_READ_FAILED; 503 GIT_TOKEN_MISSING.

### [26] `GET /api/v1/waves/{wave_id}/dispatch-preview` — dispatch_preview (waves.py:1946-1966)
- `response_model=DispatchPreviewResponse`; member-dep; `_user=Depends(require_role(*VIEWER_PLUS))`.
- **Logic:**
```
config = get_config()
wave_row, apps = await _resolve_wave_context(db, wave_id)       # 404 WAVE_NOT_FOUND
entries = await _load_preview_entries(db, wave_row, apps, config)
return DispatchPreviewResponse(wave_id, entries)
```

### [27] `GET /api/v1/waves/{wave_id}/dispatch-target-preview` — dispatch_target_preview (waves.py:1969-2104)
- `response_model=DispatchPreviewTargetResponse`; member-dep; `_user=Depends(require_role(*VIEWER_PLUS))`.
- **Logic:**
```
wave_row, _apps = await _resolve_wave_context(db, wave_id)
artifact_repo = await _resolve_artifact_repo(db, wave_row.portfolio_id)
if not artifact_repo: return DispatchPreviewTargetResponse(wave_id, entries=[])   # not-ready empty state
config = get_config()
if not config.github_token: 503 GIT_TOKEN_MISSING
plan_path = f"architecture/wave-{wave_id}/architecture-target-plan.json"
try: git_svc.read_file(plan_path)
except GitServiceError as exc:
    if "not found" in msg.lower(): return empty (awaiting-coordinator state)
    else: log + 502 GIT_READ_FAILED
try: plan = json.loads(result.content)
except JSONDecodeError: log + 502 GIT_READ_FAILED
plan_targets = plan.get("targets") if dict else None
if not list: return empty
# collect all source_app_ids → one query SELECT id,name FROM application WHERE id = ANY(:ids)
# build name_by_id
for item in plan_targets (dict only):
    source_app_ids = [str(s) for s in item.source_app_ids if str]
    entries.append(DispatchPreviewTargetEntry(
        target_app_id, target_service_id, target_name_seed=item.target_name,
        target_repo_slug, relationship, source_app_ids,
        source_app_names=[name_by_id.get(sid,"") ...], rationale))
return DispatchPreviewTargetResponse(wave_id, entries)
```
- ⚠️ GOTCHA: "not found" git error and malformed-plan are handled differently — not-found → empty 200 (awaiting), parse-fail → 502.

### [28] `POST /api/v1/waves/{wave_id}/dispatch-architecture` — dispatch_architecture (waves.py:2318-2518)
- **status_code=202**, `response_model=DispatchArchitectureResponse`; member-dep; `user=Depends(require_role(*MANAGER_ROLES))`; `temporal`.
- **Body:** `dict[str, Any]` (raw — shape-sniffed at runtime).
- **Shape sniff** `_is_v2_dispatch_body(raw)` (waves.py:2303): `targets` is non-empty list AND `targets[0]` is dict with key `"target_app_id"` → v2.
- **Logic:**
```
if _is_v2_dispatch_body(body):
    return await _dispatch_architecture_v2(wave_id, DispatchArchitectureRequestV2.model_validate(body), user, db, temporal)
# ---- v1 path ----
parsed_body = DispatchArchitectureRequest.model_validate(body)
config = get_config()
wave_row, apps = await _resolve_wave_context(db, wave_id)
if wave_row.status != "awaiting-architecture-dispatch": 409 WAVE_NOT_AWAITING_DISPATCH (msg includes current status)
if not wave_row.workflow_id: 409 WAVE_WORKFLOW_NOT_STARTED
preview_entries = await _load_preview_entries(db, wave_row, apps, config)
preview_by_app = {e.source_app_id: e ...}
requested_ids = {t.source_app_id for t in parsed_body.targets}
missing_disposition = [p.source_app_id for p in preview_entries if p.source_app_id in requested_ids and not p.disposition]
if missing_disposition:
    portfolio_artifact_repo = await _resolve_artifact_repo(db, wave_row.portfolio_id)
    raise OlympusHTTPException(409, "DISPATCH_MISSING_DISPOSITION", <long msg w/ repo + sorted app_ids>)
skipped_retire = 0; augmented_targets = []
for target in parsed_body.targets:
    preview = preview_by_app.get(target.source_app_id)
    if preview is None: 400 UNKNOWN_SOURCE_APP
    disposition = preview.disposition
    if disposition == "Retire": skipped_retire += 1; continue
    if not target.target_repo: 400 TARGET_REPO_REQUIRED (msg: every modernization target gets own repo, incl Refactor/Rearchitect/Replatform/Retain)
    peer_source_app_ids = list(preview.peer_source_app_ids) if disposition=="Consolidate" else []
    augmented_targets.append({source_app_id, target_app_name, target_repo, default_branch, disposition, peer_source_app_ids})
# inbox-before-wire
signal_payload = {"targets": augmented_targets}
inbox_id = await signal_inbox.enqueue_signal(db, workflow_id=wave_row.workflow_id, signal_name="dispatch_architecture", payload=signal_payload, status="sent")
dispatch_status="dispatched"; dispatch_detail=""
try:
    handle = temporal.get_workflow_handle(wave_row.workflow_id)
    await handle.signal("dispatch_architecture", signal_payload)
except Exception as exc:
    await signal_inbox.mark_queued(db, inbox_id)
    dispatch_status="queued"; dispatch_detail=f"Temporal signal failed ({exc!r}); queued for next live workflow"; log warning
await db.commit(); log info
return DispatchArchitectureResponse(wave_id, workflow_id=wave_row.workflow_id, dispatched=len(augmented_targets), skipped_retire, status=dispatch_status, detail=dispatch_detail)
```
- ⚠️ FIRES Temporal signal `dispatch_architecture` (to rationalization `workflow_id`). Inbox row written BEFORE wire send; on signal failure → `status="queued"` but still 202.

**`_dispatch_architecture_v2(wave_id, body:V2, user, db, temporal)` (waves.py:2108-2300):**
```
wave_row, _apps = await _resolve_wave_context(db, wave_id)
if wave_row.status != "awaiting-architecture-dispatch": 409 WAVE_NOT_AWAITING_DISPATCH
architecture_workflow_id = wave_row.get("architecture_workflow_id") or ""
if not architecture_workflow_id: 409 ARCHITECTURE_COORDINATOR_NOT_STARTED ("has G-DA approved?")
skipped_retire=0; plan_targets=[]
for t in body.targets:
    relationship = (t.relationship or "").lower()
    if relationship == "retire": skipped_retire += 1; continue
    if not t.target_repo: 400 TARGET_REPO_REQUIRED
    if not t.source_app_ids: 400 TARGET_SOURCE_APPS_REQUIRED
    plan_targets.append({target_app_id, target_service_id, target_name=t.target_app_name, target_repo_slug=t.target_repo, relationship, source_app_ids=list(t.source_app_ids), rationale:""})
plan = {$schema, wave_id:str, generated_at: utc ISO w/ Z, targets: plan_targets, target_app_count: len, summary:"Operator-confirmed plan from pre-dispatch UI"}
artifact_repo = await _resolve_artifact_repo(db, wave_row.portfolio_id)
if not artifact_repo: 409 ARTIFACT_REPO_NOT_CONFIGURED
config = get_config()
if not config.github_token: 503 GIT_TOKEN_MISSING
plan_path = f"architecture/wave-{wave_id}/architecture-target-plan.json"
try: git_svc.commit_file(branch="main", path=plan_path, content=json.dumps(plan, indent=2), commit_message=f"Wave {wave_id}: pre-dispatch confirmed plan")
except GitServiceError: log + 502 GIT_WRITE_FAILED
confirmed_by = user.sub or ""
signal_payload = {"confirmed_by": confirmed_by}
inbox_id = await signal_inbox.enqueue_signal(db, workflow_id=architecture_workflow_id, signal_name="pre_dispatch_confirmed", payload=signal_payload, status="sent")
dispatch_status="dispatched"; dispatch_detail=""
try:
    handle = temporal.get_workflow_handle(architecture_workflow_id)
    await handle.signal("pre_dispatch_confirmed", signal_payload)
except Exception as exc:
    await signal_inbox.mark_queued(db, inbox_id); dispatch_status="queued"; dispatch_detail=...; log warning(shape="v2")
await db.commit(); log info(shape="v2")
return DispatchArchitectureResponse(wave_id, workflow_id=architecture_workflow_id, dispatched=len(plan_targets), skipped_retire, status=dispatch_status, detail=dispatch_detail)
```
- ⚠️ GOTCHA: v2 writes the operator-edited plan to git `main` BEFORE signalling `pre_dispatch_confirmed` (coordinator re-reads git as source of truth; wire payload is only `{confirmed_by}`). v2 targets `architecture_workflow_id` (migration 054 column); v1 targets `workflow_id`.

### Dispatch-status helpers (load-bearing for [30])

**`_WF_STATUS_TO_LINE_STATUS` (waves.py:2530):** `RUNNING→in-progress, COMPLETED→complete, FAILED/CANCELED/TERMINATED/TIMED_OUT→failed, CONTINUED_AS_NEW→in-progress`.

**`_coalesce_target_status(arch, data)` (waves.py:2541):**
```
if arch=="failed" or data=="failed": return "failed"
if arch=="complete" and data=="complete": return "completed"
if arch=="in-progress" or data=="in-progress": return "in-progress"
if arch=="complete" or data=="complete": return "in-progress"   # partial
return "pending"
```

**`_lineage_targets_for_wave(db, wave_id)` (waves.py:2566-2633):** dedup-on-`target_app_id` query joining `application_lineage`→`wave_application`→`application` (target t, source s), excluding `t.current_status='consolidated_into_target'`; accumulates `source_app_ids`/`source_app_names`; `target_repo = target_target_repo_url or target_repo_url or ""`. Returns `[]` when none.

**`_latest_workflow_for_prefix(temporal, prefix)` (waves.py:2636-2695):** maps prefix → WorkflowType (`architecture-`→`ArchitectureWorkflow`, `data-`→`DataWorkflow`, else None→return None). Query `WorkflowType = '...'`, page_size=100, filter `id.startswith(prefix)` in Python, pick latest `start_time`. ⚠️ GOTCHA: NO `ORDER BY` in the Temporal visibility query (standard PG backend rejects it); sort in Python. Returns `(wf_id, status_name)` or None on exception/empty.

**`_temporal_ui_url(config, workflow_id)` (waves.py:2698):** `""` if empty; else `f"{temporal_ui_base_url.rstrip('/')}/namespaces/{temporal_namespace}/workflows/{workflow_id}"`.

**`_build_authoritative_targets(temporal, config, lineage_targets)` (waves.py:2707-2783):** per target, probe `architecture-{tid}-` + `data-{tid}-`; map to line statuses (`"pending"` only when no status string, else `""`); choose `line_label` (Architecture if arch in {in-progress,failed,pending}; elif Data; elif both complete→"Done"; else ""); `status=_coalesce_target_status(...)`; `ui_wf_id = arch_wf_id or data_wf_id`; emit `DispatchTargetStatusItem` (source_app_id = sources[0] if any).

**`_wave_workflow_status_is_stale(status)` (waves.py:2786):** True if status ∈ `{TERMINATED, FAILED, COMPLETED, CANCELED, TIMED_OUT}`.

### [29] `GET /api/v1/waves/{wave_id}/dispatch-status` — dispatch_status (waves.py:2801-2910)
- `response_model=DispatchStatusResponse`; member-dep; `_user=Depends(require_role(*VIEWER_PLUS))`; `temporal`; `config=Depends(get_config)`.
- **Logic:**
```
wave_row, _apps = await _resolve_wave_context(db, wave_id)
lineage_targets = await _lineage_targets_for_wave(db, wave_id)
if lineage_targets:    # PRIMARY authoritative path
    targets = await _build_authoritative_targets(temporal, config, lineage_targets)
    return DispatchStatusResponse(wave_id, status=wave_row.status, targets)
# SECONDARY fallback: workflow-query path
targets = []
if wave_row.workflow_id:
    wave_wf_status=""
    try: desc = await handle.describe(); if desc.status: wave_wf_status=desc.status.name
    except: log warning
    if _wave_workflow_status_is_stale(wave_wf_status): log info "suppressing_stale_query"   # return empty targets
    else:
        try: raw = await handle.query("dispatch_results")
        except: log warning; raw=[]
        for entry in raw or []:
            if isinstance(entry, dict): targets.append(DispatchTargetStatusItem(**entry))
            else: targets.append(DispatchTargetStatusItem(<attr-by-attr getattr fallback>))
return DispatchStatusResponse(wave_id, status=wave_row.status, targets)
```
- ⚠️ Reads Temporal: `handle.describe()` + `handle.query("dispatch_results")`. Stale (terminal) rationalization wf → empty targets (don't trust frozen snapshot).

### [30] `POST /api/v1/waves/{wave_id}/dispatch-retry` — dispatch_retry (waves.py:2913-2972)
- **status_code=202**, `response_model=DispatchRetryResponse`; member-dep; `_user=Depends(require_role(*MANAGER_ROLES))`; `temporal`.
- **Body:** `DispatchRetryRequest`.
- **Logic:**
```
wave_row, _apps = await _resolve_wave_context(db, wave_id)
if not wave_row.workflow_id: 409 WAVE_WORKFLOW_NOT_STARTED
if wave_row.status not in ("architecture-in-flight","data-in-flight","awaiting-architecture-dispatch"): 409 WAVE_NOT_IN_DISPATCH_PHASE
handle = temporal.get_workflow_handle(wave_row.workflow_id)
await handle.signal("retry_target_dispatch", {source_app_id, target_app_name, target_repo, default_branch})
log info
return DispatchRetryResponse(wave_id, source_app_id=body.source_app_id, status="retry-queued")
```
- ⚠️ FIRES Temporal signal `retry_target_dispatch`. NOTE: no inbox row here (direct signal; raises on failure unlike dispatch-architecture).

### Tier-1 helpers
**`_TIER1_AWAITING_PREFIX = "awaiting-tier1-approval-"` (waves.py:3004).**
**`_extract_tier1_pending_app_id(current_step)` (waves.py:3007):** None if falsy or not prefixed; else `current_step[len(prefix):]` or None.
**`_TIER1_APPROVAL_OK_STATUSES` (waves.py:3142):** frozenset `{in_progress, awaiting-architecture-dispatch, architecture-in-flight, data-in-flight, stuck-awaiting-recovery}`.
**`_now_epoch_ms()` (waves.py:3284):** `int(datetime.now(utc).timestamp()*1000)`.
**`_user_sub(user)` (waves.py:3291):** dict → `user.get("sub") or "unknown"`; else `getattr(user,"sub")` if str else `"unknown"`.

### [31] `GET /api/v1/waves/{wave_id}/tier1-pending` — tier1_pending (waves.py:3058-3134)
- `response_model=Tier1PendingResponse`; member-dep; `_user=Depends(require_role(*VIEWER_PLUS))`; `temporal`.
- **Logic:**
```
wave_row, apps = await _resolve_wave_context(db, wave_id)
workflow_id = wave_row.workflow_id
if not workflow_id: return Tier1PendingResponse(wave_id, workflow_id=None, items=[])
try: status = await handle.query("get_status")
except: log warning; return empty (with workflow_id)
# parse current_step + updated_at from dict OR attribute
pending_app_id = _extract_tier1_pending_app_id(current_step)
if not pending_app_id: return empty (with workflow_id)
name_by_id = {a.app_id: a.app_name ...}
item = Tier1PendingItem(app_id=pending_app_id, app_name=name_by_id.get(pending_app_id,""), risk_tier="1",
        classification_path=f"rationalization/wave-{wave_row.id}/{pending_app_id}/classification.json", awaiting_since=updated_at)
return Tier1PendingResponse(wave_id, workflow_id, items=[item])
```
- ⚠️ Reads Temporal query `get_status`. Returns 0-or-1 row (workflow loops tier-1 apps sequentially).

### [32] `POST /api/v1/waves/{wave_id}/tier1-approval` — tier1_approval (waves.py:3153-3281)
- **status_code=202**, `response_model=Tier1ApprovalResponse`; member-dep; `user=Depends(require_role(*MANAGER_ROLES))`; `temporal`.
- **Body:** `Tier1ApprovalRequest`.
- **Logic:**
```
wave_row, apps = await _resolve_wave_context(db, wave_id)
if not any(a.app_id == body.app_id for a in apps): 404 APP_NOT_IN_WAVE
if not wave_row.workflow_id: 409 WAVE_WORKFLOW_NOT_STARTED
if wave_row.status not in _TIER1_APPROVAL_OK_STATUSES: 409 WAVE_NOT_AWAITING_TIER1
workflow_id = wave_row.workflow_id
approval_id = body.approval_id or f"tier1-{body.app_id}-{int(_now_epoch_ms())}"
stakeholder = (body.stakeholder or "").strip() or _user_sub(user)
signal_payload = {"scope":"tier-1-classification", "approval_id":approval_id, "stakeholder":stakeholder}
inbox_payload = dict(signal_payload)
if body.rationale: inbox_payload["rationale"]=body.rationale
inbox_payload["app_id"] = body.app_id
inbox_id = await signal_inbox.enqueue_signal(db, workflow_id, signal_name="stakeholder_approved", payload=inbox_payload, status="sent")
dispatch_status="sent"; dispatch_detail=""
try:
    handle = temporal.get_workflow_handle(workflow_id)
    await handle.signal("stakeholder_approved", signal_payload)
except Exception as exc:
    await signal_inbox.mark_queued(db, inbox_id); dispatch_status="queued"; dispatch_detail=...; log warning
await db.commit(); log info
return Tier1ApprovalResponse(wave_id, workflow_id, app_id=body.app_id, approval_id, status=dispatch_status, detail=dispatch_detail)
```
- ⚠️ FIRES Temporal signal `stakeholder_approved` (`StakeholderApprovedSignal`: only `scope`,`approval_id`,`stakeholder` on the wire — `rationale` rides on inbox row ONLY, never the wire). Inbox-before-wire; signal failure → `status="queued"` still 202. Default `approval_id = tier1-{app_id}-{utc-epoch-ms}`.
- **Status codes:** 202 (sent OR queued); 404 WAVE_NOT_FOUND / APP_NOT_IN_WAVE; 409 WAVE_WORKFLOW_NOT_STARTED / WAVE_NOT_AWAITING_TIER1.

---

## 4. Temporal-Signal / Workflow-Launch Endpoint Index (parity-critical)

| Endpoint | Temporal action | Signal / call name |
|---|---|---|
| [6] `/start` | STARTS `WaveWorkflow` (legacy fan-out) | via `wave_svc.start_wave` |
| [16] `/progress` | describe + `get_status` query | read-only |
| [18] `/rationalize` | STARTS `WaveRationalizationWorkflow` (fires G-RR, G-DA) | via `wave_svc.start_wave_rationalization` |
| [19] `/cancel-rationalization` | cancel signal + forced cancel | via `wave_svc.cancel_wave_rationalization` |
| [21] `/resume` | RESPAWNS Arch/Data workflows | via `wave_svc.resume_wave_fanout` |
| [22] `/retry-rationalization` | cancel + STARTS new rationalization | via `wave_svc.retry_wave_rationalization` |
| [24] `/cancel-all-children` | signal `cancel_all_children` | via `wave_svc.cancel_all_wave_children` |
| [28] `/dispatch-architecture` (v1) | signal `dispatch_architecture` → `workflow_id` (inbox-first) | direct in handler |
| [28] `/dispatch-architecture` (v2) | git-commit plan + signal `pre_dispatch_confirmed` → `architecture_workflow_id` (inbox-first) | `_dispatch_architecture_v2` |
| [29] `/dispatch-status` | describe + `dispatch_results` query | read-only |
| [30] `/dispatch-retry` | signal `retry_target_dispatch` (NO inbox; raises on failure) | direct in handler |
| [31] `/tier1-pending` | `get_status` query | read-only |
| [32] `/tier1-approval` | signal `stakeholder_approved` (inbox-first; rationale stays off-wire) | direct in handler |

**Inbox pattern (28 v1/v2, 32):** `signal_inbox.enqueue_signal(db, workflow_id, signal_name, payload, status="sent")` BEFORE wire; on `Exception` → `signal_inbox.mark_queued(db, inbox_id)` and flip `status="queued"`; always `db.commit()`; always return 202. `/dispatch-retry` (30) is the exception — no inbox, direct signal that propagates failures.

---

## 5. Undetermined / cross-spec dependencies (logic lives elsewhere)
- Service bodies for `wave_svc.*` (start_wave, mark_wave_ready, cancel_wave, revert_wave_to_draft, assign_apps_to_wave, remove_apps_from_wave, get_wave_app_progress, get_wave_app_activity, get_wave_progress, start_wave_rationalization, cancel_wave_rationalization, reset_wave_to_ready, resume_wave_fanout, retry_wave_rationalization, list_pending_fanout_gates, cancel_all_wave_children, bulk_onboard_apps) — `src/services/wave.py` (separate spec). `perf_svc.get_wave_performance_report` — `src/services/performance_report.py`. `assign_waves` — `src/services/wave_assignment.py`. `signal_inbox.enqueue_signal`/`mark_queued` — `src/services/signal_inbox.py`. `GitService.read_file`/`commit_file` — `src/services/git_service.py`. `parse_agent_json` — `olympus_workflows.utils`. `membership_svc.is_member`, `filter_portfolio_ids_by_membership` body — `src/dependencies.py`. `PaginationParams`/`get_pagination`/`paginated_response` — `src/middleware/pagination.py`. The `StakeholderApprovedSignal` dataclass shape — `temporal/olympus_workflows/types.py`.
- These are referenced by name + contract (args + documented error codes) above so the router can be regenerated; their internals belong to their own phase-8 service spec.
