# Phase 8 — API Spec: Skills & Analytics Routers (ATOMIC)

Regeneration spec for two FastAPI routers and their service layers. Behavioral parity target. Cite `path:line`. ⚠️ marks fragile/ordering-dependent behavior.

Sources:
- `olympus-api/src/routers/skills.py` — **11 endpoints** (`@router.*` count unchanged at HEAD `7cb3b20c`; A9 `/{skill_id}/metrics` REWIRED to the `skill_metrics` projection — see A9)
- `olympus-api/src/routers/analytics.py` — **13 endpoints** at HEAD `7cb3b20c` (grew from 11; +2 viewer-analytics endpoints B12/B13, P5-S30.11). ⚠️ The module docstring (`analytics.py:1-15`) now lists 13 but STILL OMITS `GET /portfolio-scoring` (B4) — that route is real and undocumented in the header; the docstring's 13th line documents `viewer-events/summary`. Actual `@router.*` decorator count = **13** (`analytics.py:69,109,122,135,158,173,186,199,212,222,238,267,284`).

---

## 0. Shared infrastructure (must exist before either router)

### 0.1 RBAC roles — `src/models/common.py:47-57`
`RBACRole(str, enum.Enum)` with members (value strings exact):
```
PORTFOLIO_ADMIN   = "portfolio_admin"
PORTFOLIO_MANAGER = "portfolio_manager"
TECH_LEAD         = "tech_lead"
ARCH_LEAD         = "arch_lead"
COMPLIANCE_LEAD   = "compliance_lead"
OPERATIONS_LEAD   = "operations_lead"
SAFETY_BOARD      = "safety_board"
VIEWER            = "viewer"
SERVICE           = "service"
```

### 0.2 Auth dependency — `src/middleware/auth.py`
- `CurrentUser` (`auth.py:32-41`): ctor `(sub: str, roles: list[RBACRole], claims: dict)`; method `has_role(*roles) -> bool` = `any(r in self.roles for r in roles)`.
- `get_current_user(request) -> CurrentUser` (`auth.py:52-103`):
  - Env: `JWT_SECRET` (default `"olympus-dev-secret"`), `JWT_ALGORITHM` (default `HS256`), `AUTH_SKIP_VERIFICATION` (default `"true"` → bool), `DEV_AUTH_BYPASS` (default `""` → bool).
  - If `DEV_AUTH_BYPASS` true → return `CurrentUser(sub="local-dev", roles=list(RBACRole) [ALL roles], claims={"sub":"local-dev","dev_bypass":True})`.
  - Else extract `Bearer ` token (`_extract_token`, `auth.py:44-49`); missing → `HTTPException(401, "Missing authorization token")`.
  - `jwt.decode`; if `AUTH_SKIP_VERIFICATION` true pass `options={"verify_signature":False,"verify_exp":False,"verify_aud":False}`. `JWTError` → `HTTPException(401, "Invalid or expired token")`.
  - `sub = payload.get("sub","anonymous")`; iterate `payload.get("roles",[])`, coerce each to `RBACRole`, skip unknown (warn). If none resolved → `roles=[RBACRole.VIEWER]`.
- `require_role(*required_roles)` (`auth.py:106-119`): returns async dep `_check(user=Depends(get_current_user))`; if NOT `user.has_role(*required_roles)` → `HTTPException(403, detail=f"Requires one of: {[r.value for r in required_roles]}")`; else return user.

### 0.3 Pagination — `src/middleware/pagination.py`
- `PaginationParams` dataclass (`pagination.py:16-25`): fields `page:int`, `per_page:int`; property `offset = (page-1)*per_page`.
- `get_pagination(page:int=Query(1, ge=1), per_page:int=Query(20, ge=1, le=100)) -> PaginationParams` (`pagination.py:28-33`).
- `paginated_response(items, total, params) -> dict` (`pagination.py:36-47`):
  ```
  total_pages = max(1, math.ceil(total / params.per_page))
  return {"data": items,
          "pagination": {"page": params.page, "per_page": params.per_page,
                         "total": total, "total_pages": total_pages}}
  ```

### 0.4 Error handling — `src/middleware/error_handler.py`
- `OlympusHTTPException(StarletteHTTPException)` (`error_handler.py:20-32`): ctor `(status_code:int, code:str, message:str, details:dict|None=None)`; sets `self.code`, `self.error_details`; `super().__init__(status_code=status_code, detail=message)`.
- Global handlers (`register_error_handlers`, `error_handler.py:49-107`) wrap responses as `{"error":{"code","message","details","request_id"}}`. StarletteHTTPException code map: `400→BAD_REQUEST,401→UNAUTHORIZED,403→FORBIDDEN,404→NOT_FOUND,409→CONFLICT,422→VALIDATION_ERROR,429→RATE_LIMITED`, else `ERROR`. Unhandled `Exception → 500 INTERNAL_ERROR`.

### 0.5 Portfolio-membership dependency helpers — `src/dependencies.py`
Used by analytics (NOT skills). All short-circuit (return early / `None`) for `RBACRole.PORTFOLIO_ADMIN`.
- `verify_portfolio_access(db, user, portfolio_id) -> None` (`dependencies.py:105-133`): admin → return; `membership_svc.is_member(db, portfolio_id, user.sub)` true → return; else `HTTPException(403, detail={"code":"PORTFOLIO_NOT_MEMBER","message":"Caller is not a member of this portfolio. Ask a portfolio_admin to grant access."})`.
- `verify_application_portfolio_access(db, user, application_id) -> uuid.UUID|None` (`dependencies.py:184-213`): admin → return `None`; `SELECT portfolio_id FROM application WHERE id=:aid`; row None → `HTTPException(404,"Application not found")`; else `verify_portfolio_access(...)` and return portfolio_id.
- `filter_portfolio_ids_by_membership(db, user, candidate_portfolio_ids=None) -> list[uuid.UUID]|None` (`dependencies.py:389-411`): admin → return `None` (= "no filter"); else `member_ids = membership_svc.list_user_portfolio_ids(db, user.sub)`; if `candidate_portfolio_ids is None` return `member_ids`; else return intersection list `[pid for pid in candidate if pid in set(member_ids)]`.

### 0.6 AssemblyLine enum — `olympus-contracts/olympus_contracts/enums.py:222-234`
`StrEnum`, declaration order (load-bearing for deterministic line iteration): `Discovery, Rationalization, Architecture, Data, Modernization, Disposition Execution, Validation, Deployment, Sustainment, Governance` (10 values). Re-exported as `AssemblyLineName` from `src/models/common.py:13`.

---

# ROUTER A — Skills

`src/routers/skills.py:50` → `router = APIRouter(prefix="/api/v1/skills", tags=["Skills"])`

Two role-set constants (skills.py:33-48):
- `VIEWER_PLUS = [VIEWER, TECH_LEAD, ARCH_LEAD, COMPLIANCE_LEAD, OPERATIONS_LEAD, SAFETY_BOARD, PORTFOLIO_MANAGER, PORTFOLIO_ADMIN, SERVICE]` — ⚠️ NOTE: skills' VIEWER_PLUS **includes `SERVICE`** (analytics' does NOT).
- `MANAGER_ROLES = [PORTFOLIO_MANAGER, PORTFOLIO_ADMIN]`

**⚠️ ROUTE MOUNT ORDER (load-bearing):** literal/static paths are declared BEFORE the parametrized `/{skill_id}` routes so FastAPI matches them first. Order: `""` GET, `""` POST, `/categories`, `/metrics`, `/metrics/by-line`, `/dispatch/{dispatch_id}`, `/{skill_id}` GET, `/{skill_id}/variants`, `/{skill_id}/metrics`, `/{skill_id}` PUT, `/{skill_id}` DELETE. If `/{skill_id}` were declared before `/categories` etc., `"categories"` would be captured as a skill_id. Preserve this order.

Request/response models — `src/models/skill.py`:
- `SkillCreate` (skill.py:11-32): `skill_id:str(req)`, `name:str(req)`, `description:str|None=None`, `category:str|None=None`, `assembly_line:str|None=None`, `enrichment_level:str="minimal"`, `model_tier:str|None=None`, `source:str="core"`, `content:str|None=None`, `system_prompt:str|None=None`, `references_data:dict|None=None`, `assets_data:dict|None=None`, `scripts_data:dict|None=None`, `config_data:dict|None=None`, `allowed_tools:list[str]|None=None`, `dispatch_ids:list[str]|None=None`, `skill_path:str|None=None`.
- `SkillUpdate` (skill.py:35-54): ALL optional (`|None=None`): `name, description, category, assembly_line, enrichment_level, model_tier, source, content, status, system_prompt, references_data, assets_data, scripts_data, config_data, allowed_tools, dispatch_ids, skill_path`. (Note: `status` present here, NOT on SkillCreate.)
- `SkillDetail` (skill.py:57-81): `id:UUID`, `skill_id:str`, `name:str`, `description:str|None`, `category:str|None`, `assembly_line:str|None`, `enrichment_level:str`, `model_tier:str|None`, `source:str`, `content:str|None`, `status:str`, `system_prompt:str|None`, `references_data:dict|None`, `assets_data:dict|None`, `scripts_data:dict|None`, `config_data:dict|None`, `allowed_tools:list[str]|None`, `dispatch_ids:list[str]|None`, `skill_path:str|None`, `created_at:datetime|None`, `updated_at:datetime|None`.

---

### A1. `GET /api/v1/skills` — list skills — `skills.py:53-68`
- **Auth:** `Depends(require_role(*VIEWER_PLUS))`.
- **Query params:** `assembly_line:str|None=None`, `source:str|None=None`, `status:str|None=None`, `pagination:PaginationParams=Depends(get_pagination)` (→ `page`, `per_page`).
- **Returns:** `dict` (paginated envelope, NO `response_model`). Status 200.
- **Handler:**
  ```
  items, total = skill_svc.list_skills(db, pagination, assembly_line=, source=, status=)
  return paginated_response([s.model_dump(mode="json") for s in items], total, pagination)
  ```
- **Service `skill_svc.list_skills`** (`src/services/skill.py:44-81`):
  ```
  where_clauses=[]; params={}
  if assembly_line: where += "assembly_line = :assembly_line"; params[...]=assembly_line
  if source:        where += "source = :source"; params[...]=source
  if status:        where += "status = :status"; params[...]=status
  where = " WHERE " + " AND ".join(clauses) if clauses else ""
  count = SELECT count(*) FROM skill{where}        -> scalar_one
  rows  = SELECT * FROM skill{where} ORDER BY assembly_line, skill_id LIMIT :limit OFFSET :offset
          (limit=per_page, offset=pagination.offset)
  return [_row_to_detail(r) for r in rows], int(count)
  ```
  `_row_to_detail` (skill.py:18-41) maps row→`SkillDetail` (uses `row.get(...)` for nullable cols).

### A2. `POST /api/v1/skills` — create skill — `skills.py:71-78`
- **Auth:** `Depends(require_role(*MANAGER_ROLES))`.
- **Body:** `SkillCreate`.
- **`response_model=SkillDetail`, `status_code=201`.**
- **Handler:** `return await skill_svc.create_skill(db, body)`.
- **Service `create_skill`** (`skill.py:99-154`):
  ```
  existing = SELECT id FROM skill WHERE skill_id=:skill_id
  if existing: raise OlympusHTTPException(409, "SKILL_EXISTS", f"Skill '{skill_id}' already exists")
  new_id = uuid.uuid4()
  INSERT INTO skill (id, skill_id, name, description, category, assembly_line,
      enrichment_level, model_tier, source, content, status, system_prompt,
      references_data, assets_data, scripts_data, config_data, allowed_tools,
      dispatch_ids, skill_path) VALUES (...)
    -- status hardcoded "active"
    -- references_data/assets_data/scripts_data/config_data/allowed_tools/dispatch_ids:
    --   json.dumps(value) if value else None   (⚠️ JSONB cols serialized to JSON text)
  await db.commit()
  return await get_skill(db, body.skill_id)
  ```

### A3. `GET /api/v1/skills/categories` — categories with counts — `skills.py:81-100`
- **Auth:** `Depends(require_role(*VIEWER_PLUS))`. `db` injected but **unused** in handler.
- **Returns:** `dict` (no response_model). Status 200.
- **⚠️ Source = REGISTRY, not DB.** Reads in-process `get_registry()` (registry.yaml), NOT the `skill` table — so it stays aligned with the YAML even if DB rows are stale.
- **Handler:**
  ```
  registry = get_registry()
  counts = {}
  for s in registry.skills: counts[s.category] = counts.get(s.category,0)+1
  data = [{"category": cat, "count": counts[cat]} for cat in sorted(counts)]   # alpha-sorted
  return {"data": data}
  ```

### A4. `GET /api/v1/skills/metrics` — global dispatch metrics — `skills.py:103-142`
- **Auth:** `Depends(require_role(*VIEWER_PLUS))`. `db` used.
- **Returns:** `dict` (no response_model). Status 200.
- **Source:** `agent_task` table. Single aggregate query:
  ```
  SELECT count(*) AS total,
         SUM(CASE WHEN status='completed' THEN 1 ELSE 0 END) AS completed,
         SUM(CASE WHEN status='failed'    THEN 1 ELSE 0 END) AS failed,
         SUM(CASE WHEN status='timed_out' THEN 1 ELSE 0 END) AS timed_out,
         AVG(duration_ms) AS avg_duration_ms,
         AVG(cost_estimate) AS avg_cost
  FROM agent_task
  -> .mappings().first() or {}
  return {"total_dispatches": int(total or 0), "completed": int(completed or 0),
          "failed": int(failed or 0), "timed_out": int(timed_out or 0),
          "avg_duration_ms": float(avg_duration_ms or 0),
          "avg_cost_estimate": float(avg_cost or 0)}
  ```

### A5. `GET /api/v1/skills/metrics/by-line` — per-line skill aggregation (P5-S6.3) — `skills.py:145-170`
- **Auth:** `Depends(require_role(*VIEWER_PLUS))`. `db` used.
- **Returns:** `dict` (no response_model). Status 200.
- **Handler:** `return await skill_svc.list_line_skill_metrics(db)`.
- **Service `list_line_skill_metrics`** (`skill.py:350-553`) — REPRODUCE EXACTLY (non-trivial dedup + dual-source merge):

  Helpers:
  - `_line_ids_for(line)` (skill.py:261-268) → `(line.value.lower().replace(" ","-"), line.value)` — kebab + display.
  - `_task_type_to_line()` (skill.py:271-277) → `step_mapping.task_type_to_line_map()` (inverts `(line,step)→task_types` registry; first line wins per task_type; deterministic by StrEnum order — see step_mapping.py:931-945).
  - `_empty_skill_row(skill_id)` (skill.py:280-293) → `{"skill_id","total_dispatches":0,"completed":0,"failed":0,"timed_out":0,"avg_duration_ms":0.0,"avg_cost_usd":0.0,"total_cost_usd":0.0,"models":{},"sources":{"envelope":0,"agent_task":0}}`.
  - `_empty_line_block(line)` (skill.py:296-309) → `{"assembly_line":line.value,"line_id":kebab,"total_dispatches":0,"completed":0,"failed":0,"timed_out":0,"avg_duration_ms":0.0,"avg_cost_usd":0.0,"total_cost_usd":0.0,"skills":[]}`.
  - `_accumulate_counters(bucket, status, duration_ms, cost_usd)` (skill.py:312-335):
    ```
    bucket["total_dispatches"] += 1
    if status=="completed": bucket["completed"]+=1
    elif status=="failed":  bucket["failed"]+=1
    elif status=="timed_out": bucket["timed_out"]+=1
    if duration_ms is not None:
        bucket.setdefault("_duration_sum",0.0); bucket.setdefault("_duration_n",0)
        bucket["_duration_sum"] += float(duration_ms); bucket["_duration_n"] += 1
    if cost_usd is not None:
        bucket["total_cost_usd"] += float(cost_usd)
    ```
  - `_finalize_bucket(bucket)` (skill.py:338-347):
    ```
    n = bucket.pop("_duration_n",0); total = bucket.pop("_duration_sum",0.0)
    bucket["avg_duration_ms"] = round(total/n,2) if n else 0.0
    total_d = bucket["total_dispatches"]
    bucket["avg_cost_usd"] = round(bucket["total_cost_usd"]/total_d,6) if total_d else 0.0
    bucket["total_cost_usd"] = round(bucket["total_cost_usd"],6)
    ```

  Main body:
  ```
  # 1. Pre-build a block + empty per-skill map for EVERY AssemblyLine (all 10)
  lines = {}; line_skills = {}
  for line in AssemblyLine:
      lines[line] = _empty_line_block(line); line_skills[line] = {}
  source_counts = {"envelope":0, "agent_task":0}
  seen_agent_task_ids = set()

  # 2. ENVELOPE PATH (primary). Only step_kind='agent' rows.
  envelope_rows = SELECT line_id, status, duration_ms, agent_task_id, payload
                  FROM step_execution WHERE step_kind='agent'
  # Build line_id lookup accepting BOTH kebab and display forms:
  line_id_to_enum = {}
  for line in AssemblyLine:
      kebab, display = _line_ids_for(line)
      line_id_to_enum[kebab]=line; line_id_to_enum[display]=line
  for row in envelope_rows:
      line_enum = line_id_to_enum.get(row.line_id or "")
      if line_enum is None: continue          # ⚠️ unknown line_id → SKIP (don't crash)
      payload = row.payload or {}
      if isinstance(payload,str): payload = json.loads(payload) except -> {}
      skill_id = payload.get("skill_id") or "(unknown)"
      model    = payload.get("model_used")
      cost     = payload.get("cost_estimate_usd")
      status   = str(row.status or "")
      _accumulate_counters(lines[line_enum], status, row.duration_ms, cost)
      skill_bucket = line_skills[line_enum].setdefault(skill_id, _empty_skill_row(skill_id))
      _accumulate_counters(skill_bucket, status, row.duration_ms, cost)
      skill_bucket["sources"]["envelope"] += 1
      if model: skill_bucket["models"][model] = skill_bucket["models"].get(model,0)+1
      source_counts["envelope"] += 1
      atid = row.agent_task_id
      if atid is not None: seen_agent_task_ids.add(atid)   # ⚠️ dedup key

  # 3. AGENT_TASK FALLBACK.
  task_rows = SELECT id, task_type, skill_id, status, duration_ms, cost_estimate, model_used
              FROM agent_task
  task_type_to_line = _task_type_to_line()
  for row in task_rows:
      if row.id is not None and row.id in seen_agent_task_ids: continue  # ⚠️ already counted via envelope
      line_enum = task_type_to_line.get(row.task_type or "")
      if line_enum is None: continue          # ⚠️ unknown task_type → SKIP (legacy rows)
      skill_id = row.skill_id or row.task_type   # fallback to task_type when skill_id NULL
      model = row.model_used; cost = row.cost_estimate; status = str(row.status or "")
      _accumulate_counters(lines[line_enum], status, row.duration_ms, cost)
      skill_bucket = line_skills[line_enum].setdefault(skill_id, _empty_skill_row(skill_id))
      _accumulate_counters(skill_bucket, status, row.duration_ms, cost)
      skill_bucket["sources"]["agent_task"] += 1
      if model: skill_bucket["models"][model] = skill_bucket["models"].get(model,0)+1
      source_counts["agent_task"] += 1

  # 4. FINALIZE — iterate AssemblyLine in enum order
  totals = {"total_dispatches":0,"completed":0,"failed":0,"timed_out":0,"total_cost_usd":0.0}
  line_blocks = []
  for line in AssemblyLine:
      block = lines[line]; _finalize_bucket(block)
      skill_rows = []
      for sid, sbucket in sorted(line_skills[line].items()):   # ⚠️ per-skill rows sorted by skill_id
          _finalize_bucket(sbucket); skill_rows.append(sbucket)
      block["skills"] = skill_rows
      totals["total_dispatches"] += block["total_dispatches"]
      totals["completed"]        += block["completed"]
      totals["failed"]           += block["failed"]
      totals["timed_out"]        += block["timed_out"]
      totals["total_cost_usd"]   += block["total_cost_usd"]
      line_blocks.append(block)
  totals["total_cost_usd"] = round(totals["total_cost_usd"], 6)
  return {"source_breakdown": source_counts, "totals": totals, "lines": line_blocks}
  ```
  **⚠️ GOTCHAs:** (a) all 10 lines always present (even zero-count); (b) dedup: an `agent_task` row whose id appears in any envelope's `agent_task_id` is excluded from the fallback so each dispatch is counted once — envelope wins; (c) `line_id` accepted in BOTH kebab and display forms; (d) `lines[].skills[]` ordered alphabetically by skill_id; line blocks in enum order.

### A6. `GET /api/v1/skills/dispatch/{dispatch_id}` — skill by dispatch id — `skills.py:173-180`
- **Auth:** `Depends(require_role(*VIEWER_PLUS))`. Path param `dispatch_id:str`.
- **`response_model=SkillDetail`.** Status 200 / 404.
- **Handler:** `return await skill_svc.get_skill_by_dispatch_id(db, dispatch_id)`.
- **Service `get_skill_by_dispatch_id`** (`skill.py:205-229`):
  ```
  row = SELECT * FROM skill
        WHERE dispatch_ids @> CAST(:dispatch_ids AS jsonb) AND status='active'
        params: {"dispatch_ids": json.dumps([dispatch_id])}   # ⚠️ JSONB containment, GIN-indexed
  if row is None: raise OlympusHTTPException(404,"SKILL_NOT_FOUND", f"No active skill with dispatch ID '{dispatch_id}'")
  return _row_to_detail(row)
  ```
  ⚠️ Only matches `status='active'` skills.

### A7. `GET /api/v1/skills/{skill_id}` — skill detail — `skills.py:183-190`
- **Auth:** `Depends(require_role(*VIEWER_PLUS))`. Path `skill_id:str`.
- **`response_model=SkillDetail`.** Status 200 / 404.
- **Handler:** `return await skill_svc.get_skill(db, skill_id)`.
- **Service `get_skill`** (`skill.py:84-96`): `SELECT * FROM skill WHERE skill_id=:skill_id`; None → `OlympusHTTPException(404,"SKILL_NOT_FOUND", f"Skill '{skill_id}' not found")`; else `_row_to_detail(row)`.

### A8. `GET /api/v1/skills/{skill_id}/variants` — skill variants — `skills.py:193-214`
- **Auth:** `Depends(require_role(*VIEWER_PLUS))`. `db` injected but **unused**. Path `skill_id:str`.
- **Returns:** `dict` (no response_model). Status 200 / 404.
- **⚠️ Source = REGISTRY (registry.yaml), not DB.**
- **Handler:**
  ```
  registry = get_registry()
  entry = registry.find(skill_id)              # SkillEntry|None, skill_registry.py:82-87
  if entry is None: raise OlympusHTTPException(404,"SKILL_NOT_FOUND", f"Skill {skill_id!r} not found in registry")
  variants = [{"id": v.id, "when": dict(v.when)} for v in entry.variants]
  return {"skill_id": skill_id, "data": variants}
  ```
  `SkillVariant` shape: `id:str`, `when:dict[str,str]` (`skill_registry.py:34-39`).

### A9. `GET /api/v1/skills/{skill_id}/metrics` — per-skill metrics — `skills.py:218-235` ⚠️ CHANGED at HEAD
- **Auth:** `Depends(require_role(*VIEWER_PLUS))`. `db` used. Path `skill_id:str`.
- **Returns:** `dict` (no response_model). Status 200.
- **⚠️ CHANGED (P5-S30.9):** Was a LIVE aggregation over `agent_task WHERE module_name=:skill_id`. NOW reads the dedicated **`skill_metrics` projection table** keyed by canonical `skill_id`. New import `from src.services import skill_metrics as skill_metrics_svc` (`skills.py:31`).
- **Handler:** `return await skill_metrics_svc.get_skill_metrics(db, skill_id)`.
- **Service `get_skill_metrics(db, skill_id)`** (`src/services/skill_metrics.py:80-109`):
  ```
  row = SELECT invocations_total, gate_pass_rate, avg_quality_score
        FROM skill_metrics WHERE skill_id=:skill_id
        -> .mappings().first() or {}
  pass_rate = row.get("gate_pass_rate"); quality = row.get("avg_quality_score")
  return {"skill_id": skill_id,
          "invocations_total": int(row.get("invocations_total") or 0),
          "gate_pass_rate":    float(pass_rate) if pass_rate is not None else None,
          "avg_quality_score": float(quality)   if quality   is not None else None}
  ```
  ⚠️ NEW response shape: `{skill_id, invocations_total, gate_pass_rate|None, avg_quality_score|None}` — NOT the old `{total_dispatches, completed, failed, avg_duration_ms, avg_cost_estimate}`. Zero/NULL when no projected row exists.
- **Projection writer `recompute_skill_metrics(db, skill_id)`** (`skill_metrics.py:31-77`) — INSERT…SELECT upsert (recompute, NOT incremental; Olympus principle 4 derived-projection). Re-aggregates ALL `agent_task` rows for the skill and `ON CONFLICT (skill_id) DO UPDATE`:
  ```
  INSERT INTO skill_metrics (skill_id, invocations_total, gate_pass_rate, avg_quality_score, updated_at)
  SELECT :skill_id, count(*),
         CASE WHEN count(*) FILTER (WHERE status IN ('completed','failed','timed_out')) = 0 THEN NULL
              ELSE count(*) FILTER (WHERE status='completed')::numeric
                   / count(*) FILTER (WHERE status IN ('completed','failed','timed_out'))::numeric END,
         AVG(quality_score), now()
  FROM agent_task WHERE skill_id = :skill_id
  ON CONFLICT (skill_id) DO UPDATE SET invocations_total=EXCLUDED..., gate_pass_rate=EXCLUDED..., avg_quality_score=EXCLUDED..., updated_at=EXCLUDED...
  ```
  ⚠️ Called on every task completion from `services/agents.record_task_complete` (commit there flushes the terminal `agent_task` update + this upsert atomically). Caller owns the transaction boundary. `gate_pass_rate`/`avg_quality_score` are NULL when no terminal/scored rows.

### A10. `PUT /api/v1/skills/{skill_id}` — update skill — `skills.py:257-265`
- **Auth:** `Depends(require_role(*MANAGER_ROLES))`. Path `skill_id:str`. Body `SkillUpdate`.
- **`response_model=SkillDetail`.** Status 200 / 404.
- **Handler:** `return await skill_svc.update_skill(db, skill_id, body)`.
- **Service `update_skill`** (`skill.py:163-192`):
  ```
  await get_skill(db, skill_id)          # raises 404 if absent
  updates = body.model_dump(exclude_none=True)
  if not updates: return await get_skill(db, skill_id)    # no-op on empty body
  for col in _JSONB_COLUMNS: if col in updates: updates[col] = json.dumps(updates[col])
        # _JSONB_COLUMNS (skill.py:157-160) = {references_data, assets_data, scripts_data,
        #                                       config_data, allowed_tools, dispatch_ids}
  set_clauses = ", ".join(f"{k} = :{k}" for k in updates)
  updates["skill_id"] = skill_id; updates["_now"] = "now()"   # ⚠️ "_now" set but UNUSED in SQL
  UPDATE skill SET {set_clauses}, updated_at = now() WHERE skill_id = :skill_id
  await db.commit()
  return await get_skill(db, skill_id)
  ```

### A11. `DELETE /api/v1/skills/{skill_id}` — delete skill — `skills.py:268-275`
- **Auth:** `Depends(require_role(*MANAGER_ROLES))`. Path `skill_id:str`.
- **`status_code=204`.** Returns `None` (empty body). 404 if absent.
- **Service `delete_skill`** (`skill.py:195-202`):
  ```
  await get_skill(db, skill_id)     # raises 404 if not found
  DELETE FROM skill WHERE skill_id = :skill_id
  await db.commit()
  ```

---

# ROUTER B — Analytics

`src/routers/analytics.py:61` → `router = APIRouter(prefix="/api/v1/analytics", tags=["Analytics"])`

Role-set constants (analytics.py:45-59):
- `VIEWER_PLUS = [VIEWER, TECH_LEAD, ARCH_LEAD, COMPLIANCE_LEAD, OPERATIONS_LEAD, SAFETY_BOARD, PORTFOLIO_MANAGER, PORTFOLIO_ADMIN]` — ⚠️ **does NOT include `SERVICE`** (differs from skills').
- `MANAGER_PLUS = [PORTFOLIO_MANAGER, PORTFOLIO_ADMIN]`

**Route mount order** (all under prefix): `/readiness-scores` GET, `/overlap-matrix` GET, `/portfolio-health` GET, `/portfolio-scoring` GET, `/disposition-confidence` GET, `/compound-growth` GET, `/gate-pass-rate` GET, `/score-history` GET, `/dimension-registry` GET, `/dimension-registry` PUT, `/model-usage` GET. All static paths (no path params) so ordering is not collision-sensitive, but preserve for OpenAPI stability.

Response models — `src/models/analytics.py`:
- `DimensionScore` (analytics.py model:10-15): `name:str`, `score:float(ge=0,le=5)`, `weight:float(ge=0,le=1)`.
- `ReadinessScoreResponse` (18-24): `app_id:UUID|None=None`, `overall:float(req)`, `dimensions:list[DimensionScore]=[]`, `calculated_at:str|None=None`.
- `DimensionRegistryEntry` (27-32): `name:str`, `weight:float`, `description:str=""`.
- `DimensionRegistryResponse` (35-40): `dimensions:list[DimensionRegistryEntry]=[]`, `total_weight:float(req)`, `valid:bool(req)`.
- `OverlapPair` (43-54): `app_a_id:UUID`, `app_b_id:UUID`, `app_a_name:str=""`, `app_b_name:str=""`, `entity_overlap_pct:float=0.0`, `operation_overlap_pct:float=0.0`, `technology_overlap_pct:float=0.0`, `persona_overlap_pct:float=0.0`, `composite_overlap:float=0.0`.
- `OverlapMatrixResponse` (57-62): `portfolio_id:UUID|None=None`, `pairs:list[OverlapPair]=[]`, `total_pairs:int=0`.
- `PortfolioHealthResponse` (65-76): `portfolio_id:UUID|None=None`, `overall_health:float(ge=0,le=100)`, `disposition_progress_pct:float=0.0`, `avg_readiness_score:float=0.0`, `stale_artifact_count:int=0`, `apps_total:int=0`, `apps_completed:int=0`.
- `DispositionConfidenceResponse` (79-89): `app_id:UUID|None=None`, `disposition:str|None=None`, `confidence_pct:float(ge=0,le=100)`, `evidence_count:int=0`, `gate_pass_count:int=0`, `detail:str=""`.
- `CompoundGrowthResponse` (92-108): `portfolio_id:UUID|None=None`, `pattern_reuse_rate:float=0.0`, `gate_pass_rate:float=0.0`, `wave_velocity:float=0.0`, `total_gates:int=0`, `gates_passed_first_attempt:int=0`, `total_waves:int=0`, `total_apps_completed:int=0`.
- `GateTypePassRate` (111-117): `gate_type:str`, `total:int=0`, `first_pass:int=0`, `rate:float=0.0`.
- `AssemblyLinePassRate` (120-126): `assembly_line:str`, `total:int=0`, `first_pass:int=0`, `rate:float=0.0`.
- `GatePassRateResponse` (129-139): `portfolio_id:UUID|None=None`, `overall_rate:float=0.0`, `total_decided:int=0`, `total_first_pass:int=0`, `by_gate_type:list[GateTypePassRate]=[]`, `by_assembly_line:list[AssemblyLinePassRate]=[]`.
- `ScoreHistoryEntry` (142-149): `dimension:str`, `score:float`, `recorded_at:str`, `source_artifact:str|None=None`, `governance_cycle:str|None=None`.
- `ScoreHistoryResponse` (152-157): `app_id:UUID`, `entries:list[ScoreHistoryEntry]=[]`, `total:int=0`.
- `PortfolioScoreDimension` (168-175): `score:float|None=None`, `rationale:str|None=None`, `evidence:list[str]=[]`.
- `PortfolioScoringHeatMapEntry` (178-195): `app_id:UUID`, `app_name:str`, `overall_weighted:float|None=None`, `risk_tier:str|None=None`, `complexity_tier:str|None=None`, `disposition:str|None=None`, `current_line:str|None=None`, `dimensions:dict[str,PortfolioScoreDimension]={}`, `methodology_version:str|None=None`, `computed_at:str|None=None`.
- `PortfolioScoringHeatMapResponse` (198-204): `portfolio_id:UUID|None=None`, `entries:list[PortfolioScoringHeatMapEntry]=[]`, `total:int=0`, `scored:int=0`.
- `ModelUsageRow` (212-232): `model_id:str`, `tier:str|None=None`, `display_name:str|None=None`, `tasks_total:int=0`, `tasks_last_30d:int=0`, `success_count_30d:int=0`, `failure_count_30d:int=0`, `success_rate_30d:float|None=Field(None, ge=0, le=1)`, `avg_duration_ms:float|None=None`, `total_cost_estimate:float|None=None`.
- `ModelUsageResponse` (235-239): `data:list[ModelUsageRow]=[]`, `portfolio_id:UUID|None=None`.

Module-level scoring registry — `src/services/scoring.py`:
- `DEFAULT_DIMENSIONS` (scoring.py:88-95): `{code_quality:0.20, test_coverage:0.15, security_posture:0.20, documentation:0.10, dependency_currency:0.15, architecture_clarity:0.20}` (sum=1.0).
- `DIMENSION_DESCRIPTIONS` (scoring.py:97-104): per-dim human strings (see source).
- `_dimension_registry: dict[str,float] = dict(DEFAULT_DIMENSIONS)` (scoring.py:107) — ⚠️ **mutable module-global**, mutated by the PUT endpoint (process-wide, not per-request/tenant).
- `GATE_TYPE_TO_ASSEMBLY_LINE` (scoring.py:42-58): `{G-DC:Discovery, G-RR:Rationalization, G-DA:Rationalization, G-02:Architecture, G-DT:Data, G-04a:Modernization, G-04b:Modernization, G-04c:Modernization, G-DE-1:Disposition Execution, G-DE-2:Disposition Execution, G-V1:Validation, G-V2:Validation, G-V3:Validation, G-DP-1:Deployment, G-DP-2:Deployment}`.

---

### B1. `GET /api/v1/analytics/readiness-scores` — `analytics.py:64-101`
- **Auth:** `user:CurrentUser = Depends(require_role(*VIEWER_PLUS))`.
- **Query:** `app_id:uuid.UUID|None=Query(None)`, `portfolio_id:uuid.UUID|None=Query(None)`, `dimensions:str|None=Query(None)` (comma-separated).
- **Returns:** `ReadinessScoreResponse | list[dict]` (no `response_model` — dual shape). Status 200 / 403 / 404.
- **Handler (every branch):**
  ```
  if app_id is None:
      if portfolio_id is not None: await verify_portfolio_access(db, user, portfolio_id)   # 403 if not member
      member_ids = await filter_portfolio_ids_by_membership(db, user)   # None for admin
      return await scoring_svc.get_all_readiness_scores(db, portfolio_id=portfolio_id, portfolio_ids=member_ids)  # list[dict]
  # single-app form:
  await verify_application_portfolio_access(db, user, app_id)   # 404 missing app / 403 not member
  dim_filter = dimensions.split(",") if dimensions else None
  return await scoring_svc.calculate_readiness_score(db, app_id, dim_filter)   # ReadinessScoreResponse
  ```
- **`_normalize_score(raw)`** (scoring.py:147-181) — used by both readiness paths; coerces score to 0–1 band:
  ```
  if raw is None: return None
  value = float(raw)  (TypeError/ValueError -> return None)
  if value < 0: return 0.0
  if value <= 1.0: return value
  if value <= 5.0: return value/5.0      # Likert 1–5
  if value <= 100.0: return value/100.0  # percent
  return 1.0
  ```
- **`get_all_readiness_scores(db, *, portfolio_id, portfolio_ids)`** (scoring.py:184-265):
  ```
  clauses=[]; params={}
  if portfolio_ids is not None:
      if not portfolio_ids: return []            # empty allowlist -> []
      clauses+= "portfolio_id = ANY(:pf_ids)"; params[pf_ids]=portfolio_ids
  if portfolio_id is not None: clauses+= "portfolio_id = :portfolio_id"; params[...]=portfolio_id
  where = "WHERE "+ " AND ".join(clauses) if clauses else ""
  apps = SELECT id,name FROM application {where} ORDER BY name
  for app in apps:
      rows = SELECT DISTINCT ON (dimension) dimension, score FROM score_history
             WHERE application_id=:app_id AND dimension!='overall'
             ORDER BY dimension, recorded_at DESC      # latest per dimension
      scores_map = { r.dimension: _normalize_score(r.score) for r if normalized not None }
      weighted_sum=0.0; total_weight=0.0
      for name,weight in _dimension_registry.items():
          score = scores_map.get(name, 0.0)           # missing -> 0.0
          weighted_sum += score*weight; total_weight += weight
      overall = weighted_sum/total_weight if total_weight>0 else None
      append {"app_id": str(app_id), "app_name": app.name or str(app_id),
              "overall": round(overall,4) if overall is not None else None,
              "code_quality":..., "test_coverage":..., "security_posture":...,
              "documentation":..., "dependency_currency":..., "architecture_clarity":...}  # each = scores_map.get(dim) (may be None)
  return results
  ```
- **`calculate_readiness_score(db, app_id, dimension_filter=None)`** (scoring.py:268-327):
  ```
  if app_id is None: return ReadinessScoreResponse(app_id=None, overall=0.0, dimensions=[], calculated_at=None)
  rows = SELECT DISTINCT ON (dimension) dimension, score, recorded_at FROM score_history
         WHERE application_id=:app_id AND dimension!='overall' ORDER BY dimension, recorded_at DESC
  scores_map = {r.dimension: _normalize_score(r.score) for r if not None}
  calculated_at = str(rows[0].recorded_at) if rows else None   # ⚠️ rows[0] after DISTINCT ON ordering, not "newest"
  dimensions=[]; weighted_sum=0.0; total_weight=0.0
  for name,weight in _dimension_registry.items():
      if dimension_filter and name not in dimension_filter: continue
      score = scores_map.get(name, 0.0)
      dimensions.append(DimensionScore(name=name, score=score, weight=weight))
      weighted_sum += score*weight; total_weight += weight
  overall = weighted_sum/total_weight if total_weight>0 else 0.0
  return ReadinessScoreResponse(app_id=app_id, overall=round(overall,2), dimensions=dimensions, calculated_at=calculated_at)
  ```

### B2. `GET /api/v1/analytics/overlap-matrix` — `analytics.py:104-114`
- **Auth:** `Depends(require_role(*VIEWER_PLUS))`. **`response_model=OverlapMatrixResponse`.**
- **Query:** `portfolio_id:uuid.UUID|None=Query(None)`.
- **Handler:**
  ```
  if portfolio_id is not None: await verify_portfolio_access(db, user, portfolio_id)
  member_ids = await filter_portfolio_ids_by_membership(db, user)
  return await scoring_svc.calculate_overlap_matrix(db, portfolio_id, member_ids)
  ```
- **`_resolve_portfolio_id(db, portfolio_id, portfolio_ids=None)`** (scoring.py:335-366) — used by B2/B3/B5/B6/B7:
  ```
  if portfolio_id is not None: return portfolio_id
  if portfolio_ids is not None:
      if not portfolio_ids: return None
      return SELECT id FROM portfolio WHERE id=ANY(:pf_ids) ORDER BY created_at LIMIT 1   (scalar)
  return SELECT id FROM portfolio ORDER BY created_at LIMIT 1   (scalar; first portfolio = default)
  ```
- **`calculate_overlap_matrix(db, portfolio_id, portfolio_ids=None)`** (scoring.py:369-462):
  ```
  portfolio_id = _resolve_portfolio_id(...)
  if portfolio_id is None: return OverlapMatrixResponse(portfolio_id=None, pairs=[], total_pairs=0)
  apps = SELECT id,name FROM application WHERE portfolio_id=:portfolio_id ORDER BY name
  if len(apps) < 2: return OverlapMatrixResponse(portfolio_id=portfolio_id, pairs=[], total_pairs=0)
  pairs=[]
  for i in range(len(apps)):
    for j in range(i+1, len(apps)):       # ⚠️ upper-triangle only, no self/duplicate pairs
       shared = SELECT count(DISTINCT a.target_artifact)
                FROM traceability_link a JOIN traceability_link b
                  ON a.target_artifact=b.target_artifact
                WHERE a.app_id=:app_a AND b.app_id=:app_b           (or 0)
       total_a = SELECT count(DISTINCT target_artifact) FROM traceability_link WHERE app_id=:app_a  (or 0)
       total_b = SELECT count(DISTINCT target_artifact) FROM traceability_link WHERE app_id=:app_b  (or 0)
       max_total = max(total_a, total_b, 1)
       composite = round(shared/max_total*100, 2) if max_total>0 else 0.0
       pairs.append(OverlapPair(app_a_id, app_b_id, app_a_name, app_b_name, composite_overlap=composite))
       # ⚠️ entity/operation/technology/persona_overlap_pct left at default 0.0 (not computed)
  return OverlapMatrixResponse(portfolio_id, pairs, total_pairs=len(pairs))
  ```

### B3. `GET /api/v1/analytics/portfolio-health` — `analytics.py:117-127`
- **Auth:** `Depends(require_role(*VIEWER_PLUS))`. **`response_model=PortfolioHealthResponse`.** Query `portfolio_id:uuid.UUID|None`.
- **Handler:** verify_portfolio_access if portfolio_id set; `member_ids = filter_portfolio_ids_by_membership(...)`; `return calculate_portfolio_health(db, portfolio_id, member_ids)`.
- **`calculate_portfolio_health`** (scoring.py:470-563):
  ```
  portfolio_id = _resolve_portfolio_id(...)
  if portfolio_id is None: return PortfolioHealthResponse(portfolio_id=None, overall_health=0.0, ...all zeros...)
  total_apps     = SELECT count(*) FROM application WHERE portfolio_id=:pid                              (or 0)
  completed_apps = SELECT count(*) FROM application WHERE portfolio_id=:pid AND current_status='completed' (or 0)
  disposition_pct = round(completed_apps/total_apps*100, 2) if total_apps>0 else 0.0
  avg_score_row = SELECT avg(sh.score) FROM score_history sh JOIN application a ON a.id=sh.application_id
                  WHERE a.portfolio_id=:pid AND sh.dimension='overall'
                    AND sh.recorded_at = (SELECT max(sh2.recorded_at) FROM score_history sh2
                         WHERE sh2.application_id=sh.application_id AND sh2.dimension='overall')
  avg_score = round(float(avg_score_row), 2) if avg_score_row else 0.0
  stale_count = SELECT count(DISTINCT tl.source_artifact) FROM traceability_link tl
                JOIN application a ON a.id=tl.app_id
                WHERE a.portfolio_id=:pid AND a.analyzed_commit_sha IS NOT NULL
                  AND tl.source_version IS NOT NULL AND tl.source_version != a.analyzed_commit_sha   (or 0)
  drift_penalty = min(stale_count*2.0, 20.0)                    # ⚠️ capped 20
  overall = max(0.0, disposition_pct*0.5 + (avg_score/5.0*100)*0.3 + (100.0-drift_penalty)*0.2)
            # ⚠️ weights 0.5 / 0.3 / 0.2; avg_score assumed 0–5 (scaled /5*100)
  return PortfolioHealthResponse(portfolio_id, overall_health=round(min(overall,100.0),2),
         disposition_progress_pct=disposition_pct, avg_readiness_score=avg_score,
         stale_artifact_count=stale_count, apps_total=total_apps, apps_completed=completed_apps)
  ```

### B4. `GET /api/v1/analytics/portfolio-scoring` — heat map (P3.5-U3.2) — `analytics.py:130-150`
- **Auth:** `Depends(require_role(*VIEWER_PLUS))`. **`response_model=PortfolioScoringHeatMapResponse`.** Query `portfolio_id:uuid.UUID|None`.
- ⚠️ NOTE: this route is REAL but is OMITTED from the module docstring header list.
- **Handler:** verify_portfolio_access if set; `member_ids = filter_portfolio_ids_by_membership(...)`; `return get_portfolio_scoring_heat_map(db, portfolio_id, member_ids)`.
- **`_normalize_portfolio_score(raw)`** (scoring.py:950-968): dict→dict; str→`json.loads` (dict else {}); else `{}`.
- **`get_portfolio_scoring_heat_map(db, portfolio_id=None, portfolio_ids=None)`** (scoring.py:971-1078):
  ```
  clauses=[]; params={}
  if portfolio_ids is not None:
      if not portfolio_ids: return PortfolioScoringHeatMapResponse(applications=[])   # ⚠️ BUG: kwarg 'applications' not a field (model has 'entries'); empty-allowlist branch would raise. Reproduce literally for parity.
      clauses+= "portfolio_id = ANY(:pf_ids)"; params[pf_ids]=portfolio_ids
  if portfolio_id is not None: clauses+= "portfolio_id = :portfolio_id"; params[...]=portfolio_id
  where = "WHERE "+ " AND ".join(clauses) if clauses else ""
  if not clauses:
      rows = SELECT id,name,risk_tier,complexity_tier,disposition,current_line,portfolio_score
             FROM application ORDER BY name
  else:
      rows = SELECT (same cols) FROM application {where} ORDER BY name   (params)
  entries=[]; scored=0
  for row in rows:
      payload = _normalize_portfolio_score(row.portfolio_score)
      raw_dims = payload.get("scores") or {}
      dimensions = {}
      for dim_name, dim_value in raw_dims.items():
          if not isinstance(dim_value, dict): continue
          dimensions[dim_name] = PortfolioScoreDimension(
              score = float(dim_value["score"]) if dim_value.get("score") is not None else None,
              rationale = str(dim_value["rationale"]) if dim_value.get("rationale") is not None else None,
              evidence = [str(e) for e in (dim_value.get("evidence") or [])])
      overall = payload.get("overall_weighted")
      if isinstance(overall, (int,float)): overall_val=float(overall); scored+=1
      else: overall_val=None
      entries.append(PortfolioScoringHeatMapEntry(app_id=row.id, app_name=row.name or str(row.id),
          overall_weighted=overall_val, risk_tier=row.risk_tier, complexity_tier=row.complexity_tier,
          disposition=row.disposition, current_line=row.current_line, dimensions=dimensions,
          methodology_version = str(payload["methodology_version"]) if payload.get("methodology_version") is not None else None,
          computed_at = str(payload["computed_at"]) if payload.get("computed_at") is not None else None))
  return PortfolioScoringHeatMapResponse(portfolio_id=portfolio_id, entries=entries, total=len(entries), scored=scored)
  ```
  Source col: `application.portfolio_score` JSONB (written by `persist_portfolio_score` activity). Apps without a score still appear with `overall_weighted=None`.

### B5. `GET /api/v1/analytics/disposition-confidence` — `analytics.py:153-165`
- **Auth:** `Depends(require_role(*VIEWER_PLUS))`. **`response_model=DispositionConfidenceResponse`.** Query `app_id:uuid.UUID|None`.
- **Handler:** `if app_id is not None: await verify_application_portfolio_access(db, user, app_id)`; `return calculate_disposition_confidence(db, app_id)`.
- **`calculate_disposition_confidence(db, app_id)`** (scoring.py:571-643):
  ```
  if app_id is None: return DispositionConfidenceResponse(app_id=None, disposition=None, confidence_pct=0.0,
                            evidence_count=0, gate_pass_count=0, detail="No app specified")
  app_row = SELECT disposition FROM application WHERE id=:id  (.mappings().first())
  disposition = app_row.disposition if app_row else None
  evidence_count   = SELECT count(*) FROM traceability_link WHERE app_id=:app_id  (or 0)
  gate_pass_count  = SELECT count(*) FROM gate WHERE application_id=:app_id AND status='approved'  (or 0)
  confidence = 0.0
  if disposition: confidence += 30.0
  confidence += min(evidence_count*2.0, 40.0)
  confidence += min(gate_pass_count*10.0, 30.0)
  confidence = min(confidence, 100.0)
  detail_parts=[]
  if not disposition: detail_parts.append("No disposition set")
  if evidence_count==0: detail_parts.append("no traceability evidence")
  if gate_pass_count==0: detail_parts.append("no gates passed")
  detail = "; ".join(detail_parts) if detail_parts else "Strong evidence base"
  return DispositionConfidenceResponse(app_id, disposition, confidence_pct=round(confidence,2),
         evidence_count, gate_pass_count, detail)
  ```

### B6. `GET /api/v1/analytics/compound-growth` — `analytics.py:168-178`
- **Auth:** `Depends(require_role(*VIEWER_PLUS))`. **`response_model=CompoundGrowthResponse`.** Query `portfolio_id:uuid.UUID|None`.
- **Handler:** verify_portfolio_access if set; member_ids; `return calculate_compound_growth(db, portfolio_id, member_ids)`.
- **`calculate_compound_growth`** (scoring.py:651-767):
  ```
  portfolio_id = _resolve_portfolio_id(...)
  if portfolio_id is None: return CompoundGrowthResponse(portfolio_id=None, ...all zeros...)
  total_gates = SELECT count(*) FROM gate g JOIN application a ON a.id=g.application_id
                WHERE a.portfolio_id=:pid AND g.status IN ('approved','rejected')   (or 0)  # decided only
  first_attempt_passes = SELECT count(*) FROM gate g JOIN application a ON a.id=g.application_id
                WHERE a.portfolio_id=:pid AND g.status='approved' AND g.retry_count=0  (or 0)
  gate_pass_rate = round(first_attempt_passes/total_gates, 4) if total_gates>0 else 0.0
  total_waves = SELECT count(*) FROM wave WHERE portfolio_id=:pid  (or 0)
  total_completed = SELECT count(*) FROM application WHERE portfolio_id=:pid AND current_status='completed' (or 0)
  wave_velocity = round(total_completed/total_waves, 2) if total_waves>0 else 0.0
  total_apps = SELECT count(*) FROM application WHERE portfolio_id=:pid  (or 0)
  apps_with_shared = SELECT count(DISTINCT tl.app_id) FROM traceability_link tl
       JOIN application a ON a.id=tl.app_id
       WHERE a.portfolio_id=:pid AND tl.target_artifact IN (
            SELECT target_artifact FROM traceability_link
            GROUP BY target_artifact HAVING count(DISTINCT app_id) > 1)   (or 0)
  pattern_reuse = round(apps_with_shared/total_apps, 4) if total_apps>0 else 0.0
  return CompoundGrowthResponse(portfolio_id, pattern_reuse_rate=pattern_reuse, gate_pass_rate,
         wave_velocity, total_gates, gates_passed_first_attempt=first_attempt_passes,
         total_waves, total_apps_completed=total_completed)
  ```

### B7. `GET /api/v1/analytics/gate-pass-rate` — `analytics.py:181-191`
- **Auth:** `Depends(require_role(*VIEWER_PLUS))`. **`response_model=GatePassRateResponse`.** Query `portfolio_id:uuid.UUID|None`.
- **Handler:** verify_portfolio_access if set; member_ids; `return calculate_gate_pass_rate(db, portfolio_id, member_ids)`.
- **`_aggregate_pass_rates_by_line(rows)`** (scoring.py:61-81):
  ```
  buckets={}
  for r in rows:
      line = GATE_TYPE_TO_ASSEMBLY_LINE.get(str(r.gate_type))
      if line is None: continue
      b = buckets.setdefault(line, {"total":0,"first_pass":0})
      b["total"] += 1
      if r.status=="approved" and int(r.retry_count or 0)==0: b["first_pass"] += 1
  return [{"assembly_line":line,"total":b.total,"first_pass":b.first_pass} for line,b in sorted(buckets.items())]  # alpha
  ```
- **`calculate_gate_pass_rate`** (scoring.py:775-885):
  ```
  portfolio_id = _resolve_portfolio_id(...)
  if portfolio_id is None: return GatePassRateResponse(portfolio_id=None)   # all model defaults
  total_decided = SELECT count(*) FROM gate g JOIN application a ON a.id=g.application_id
                  WHERE a.portfolio_id=:pid AND g.status IN ('approved','rejected')  (or 0)
  total_first_pass = SELECT count(*) ... WHERE a.portfolio_id=:pid AND g.status='approved' AND g.retry_count=0  (or 0)
  overall_rate = round(total_first_pass/total_decided, 4) if total_decided>0 else 0.0
  by_type_rows = SELECT g.gate_type, count(*) AS total,
                   count(*) FILTER (WHERE g.status='approved' AND g.retry_count=0) AS first_pass
                 FROM gate g JOIN application a ON a.id=g.application_id
                 WHERE a.portfolio_id=:pid AND g.status IN ('approved','rejected')
                 GROUP BY g.gate_type ORDER BY g.gate_type
  by_gate_type = [GateTypePassRate(gate_type, total, first_pass,
                   rate=round(first_pass/total,4) if total>0 else 0.0) for r in by_type_rows]
  by_line_src_rows = SELECT g.gate_type, g.status, COALESCE(g.retry_count,0) AS retry_count
                     FROM gate g JOIN application a ON a.id=g.application_id
                     WHERE a.portfolio_id=:pid AND g.status IN ('approved','rejected')
  by_line_rows = _aggregate_pass_rates_by_line(by_line_src_rows)   # ⚠️ line derived in Python from gate_type (no DB column)
  by_assembly_line = [AssemblyLinePassRate(assembly_line, total, first_pass,
                       rate=round(first_pass/total,4) if total>0 else 0.0) for r in by_line_rows]
  return GatePassRateResponse(portfolio_id, overall_rate, total_decided, total_first_pass,
         by_gate_type, by_assembly_line)
  ```

### B8. `GET /api/v1/analytics/score-history` — `analytics.py:194-204`
- **Auth:** `Depends(require_role(*VIEWER_PLUS))`. **`response_model=ScoreHistoryResponse`.**
- **Query:** `app_id:uuid.UUID=Query(...)` (**REQUIRED**), `dimension:str|None=Query(None)`, `limit:int=Query(100, ge=1, le=1000)`.
- **Handler:** `await verify_application_portfolio_access(db, user, app_id)`; `return get_score_history(db, app_id, dimension, limit)`.
- **`get_score_history(db, app_id, dimension=None, limit=100)`** (scoring.py:893-936):
  ```
  params={"app_id":app_id,"limit":limit}; where="application_id = :app_id"
  if dimension: where += " AND dimension = :dimension"; params["dimension"]=dimension
  rows = SELECT dimension, score, recorded_at, source_artifact, governance_cycle
         FROM score_history WHERE {where} ORDER BY recorded_at DESC LIMIT :limit
  entries = [ScoreHistoryEntry(dimension=r.dimension, score=float(r.score),
             recorded_at=str(r.recorded_at), source_artifact=r.source_artifact,
             governance_cycle=r.governance_cycle) for r in rows]
  return ScoreHistoryResponse(app_id=app_id, entries=entries, total=len(entries))   # total = page count, NOT grand total
  ```

### B9. `GET /api/v1/analytics/dimension-registry` — `analytics.py:207-214`
- **Auth:** `user:CurrentUser = Depends(require_role(*VIEWER_PLUS))`. **NO `db` dependency.** **`response_model=DimensionRegistryResponse`.**
- **Handler:** `return scoring_svc.get_dimension_registry()` (synchronous; handler is async, returns sync result).
- **`get_dimension_registry()`** (scoring.py:110-125):
  ```
  entries = [DimensionRegistryEntry(name=name, weight=weight, description=DIMENSION_DESCRIPTIONS.get(name,""))
             for name,weight in _dimension_registry.items()]
  total = sum(_dimension_registry.values())
  return DimensionRegistryResponse(dimensions=entries, total_weight=round(total,4), valid=abs(total-1.0)<0.001)
  ```

### B10. `PUT /api/v1/analytics/dimension-registry` — `analytics.py:217-225`
- **Auth:** `user:CurrentUser = Depends(require_role(*MANAGER_PLUS))`. **NO `db` dependency.** **`response_model=DimensionRegistryResponse`.**
- **Body:** `weights: dict[str, float]` (raw JSON object body, NOT a named Pydantic model).
- **Handler:** `return scoring_svc.update_dimension_weights(weights)`.
- **`update_dimension_weights(weights)`** (scoring.py:128-139):
  ```
  total = sum(weights.values())
  if abs(total - 1.0) >= 0.001:
      raise OlympusHTTPException(400, "INVALID_WEIGHTS", f"Dimension weights must sum to 1.0, got {total:.4f}")
  _dimension_registry.clear(); _dimension_registry.update(weights)   # ⚠️ mutates process-global registry, replaces ALL dims
  return get_dimension_registry()
  ```
  ⚠️ GOTCHA: mutation is process-wide and persists across requests (no DB, no per-tenant scope). Replaces the whole dict — keys not in `weights` are dropped.

### B11. `GET /api/v1/analytics/model-usage` — per-model-tier rollup (P5-S26) — `analytics.py:233-254`
- **Auth (⚠️ TWO user deps):** `_user:CurrentUser = Depends(require_role(*VIEWER_PLUS))` (enforces RBAC) **AND** `user:CurrentUser = Depends(get_current_user)` (the one actually used for membership checks). **`response_model=ModelUsageResponse`.**
- **Query:** `portfolio_id:uuid.UUID|None=Query(None)`.
- **Handler:**
  ```
  if portfolio_id is not None: await verify_portfolio_access(db, user, portfolio_id)
  member_ids = await filter_portfolio_ids_by_membership(db, user)
  return await model_usage_svc.get_model_usage(db, portfolio_id, member_ids)
  ```
- **`_classify(model_id)`** (`src/services/model_usage.py:39-52`):
  ```
  if not model_id: return ("unknown","Unknown",None)
  _KNOWN_MODELS = {"claude-haiku-4-5":("haiku","Claude Haiku 4.5"),
                   "claude-sonnet-4-6":("sonnet","Claude Sonnet 4.6"),
                   "claude-opus-4-7":("opus","Claude Opus 4.7")}
  if model_id in _KNOWN_MODELS: tier,display=_KNOWN_MODELS[model_id]; return (model_id, display, tier)
  lower = model_id.lower()
  for fragment,tier in (("opus","opus"),("sonnet","sonnet"),("haiku","haiku")):
      if fragment in lower: return (model_id, model_id, tier)
  return (model_id, model_id, None)
  ```
  Returns `(model_id, display_name, tier)`.
- **`_safe_execute(db, sql, params)`** (model_usage.py:55-68): runs SELECT; on `ProgrammingError|DBAPIError` whose message contains `"does not exist"` / (`"undefined"` & `"relation"`) OR (`"column"` & (`"does not exist"`|`"undefined"`)) → return `[]` (tolerates missing table/column on fresh DB); else re-raise.
- **`get_model_usage(db, portfolio_id=None, portfolio_ids=None)`** (model_usage.py:71-171):
  ```
  now = datetime.now(timezone.utc); since_30d = now - timedelta(days=30)
  params = {"since_30d": since_30d}; portfolio_join=""; portfolio_filter=""
  if portfolio_ids is not None:
      if not portfolio_ids: return ModelUsageResponse(items=[])   # ⚠️ BUG: kwarg 'items' not a field (model has 'data'); empty-allowlist branch would raise. Reproduce literally for parity.
      portfolio_join = "JOIN application a ON a.id = at.application_id"
      portfolio_filter = "AND a.portfolio_id = ANY(:pf_ids)"; params["pf_ids"]=portfolio_ids
  if portfolio_id is not None:
      portfolio_join = "JOIN application a ON a.id = at.application_id"
      portfolio_filter = f"{portfolio_filter} AND a.portfolio_id = :portfolio_id" if portfolio_filter else "AND a.portfolio_id = :portfolio_id"
      params["portfolio_id"]=portfolio_id
  rows = _safe_execute(db, f"""
      SELECT at.model_used AS model_used,
        COUNT(*) AS tasks_total,
        COUNT(*) FILTER (WHERE at.started_at >= :since_30d) AS tasks_30d,
        COUNT(*) FILTER (WHERE at.started_at >= :since_30d AND at.status='completed') AS success_30d,
        COUNT(*) FILTER (WHERE at.started_at >= :since_30d AND at.status='failed') AS failure_30d,
        COUNT(*) FILTER (WHERE at.started_at >= :since_30d AND at.status IN ('completed','failed','timed_out')) AS terminal_30d,
        AVG(at.duration_ms) FILTER (WHERE at.status='completed') AS avg_duration_ms,
        SUM(at.cost_estimate) AS total_cost
      FROM agent_task at {portfolio_join}
      WHERE at.model_used IS NOT NULL {portfolio_filter}
      GROUP BY at.model_used ORDER BY tasks_total DESC, at.model_used ASC""", params)
  data=[]
  for r in rows:
      model_id, display, tier = _classify(r.model_used or "")
      terminal_30d=int(r.terminal_30d or 0); success_30d=int(r.success_30d or 0)
      success_rate = success_30d/terminal_30d if terminal_30d else None
      avg_duration = r.avg_duration_ms
      data.append(ModelUsageRow(model_id, tier, display_name=display,
          tasks_total=int(r.tasks_total or 0), tasks_last_30d=int(r.tasks_30d or 0),
          success_count_30d=success_30d, failure_count_30d=int(r.failure_30d or 0),
          success_rate_30d=success_rate,
          avg_duration_ms=float(avg_duration) if avg_duration is not None else None,
          total_cost_estimate=float(r.total_cost) if r.total_cost is not None else None))
  return ModelUsageResponse(data=data, portfolio_id=portfolio_id)
  ```
  ⚠️ GOTCHAs: (a) portfolio-scoped branch uses INNER JOIN application → wave-scoped agent_task rows (`application_id IS NULL`) are excluded by design; (b) `success_rate_30d` denominator is `terminal_30d` (completed+failed+timed_out), numerator `completed` only; (c) `avg_duration_ms` is over `completed` rows only; (d) ORDER BY `tasks_total DESC, model_used ASC`.
  ⚠️ `_KNOWN_MODELS` (model_usage.py:40-44) at HEAD: `{claude-haiku-4-5:(haiku,"Claude Haiku 4.5"), claude-sonnet-4-6:(sonnet,"Claude Sonnet 4.6"), claude-opus-4-7:(opus,"Claude Opus 4.7")}`.

### B12. `POST /api/v1/analytics/viewer-events` — ingest dwell telemetry (P5-S30.11) — `analytics.py:267-281` ⚠️ NEW at HEAD
- **Auth:** `_user:CurrentUser = Depends(require_role(*VIEWER_PLUS))` — any VIEWER_PLUS user records events; `db` used.
- **Body:** `payload: ViewerEventIngest | list[ViewerEventIngest]` — accepts a single event OR a batch (the viewer batches).
- **Returns:** `dict[str,int]` (no response_model) → `{"recorded": <count>}`. Status 200.
- **Handler:**
  ```
  events = payload if isinstance(payload, list) else [payload]
  recorded = await viewer_analytics_svc.record_events(db, events)
  return {"recorded": recorded}
  ```
- **`ViewerEventIngest`** (`src/models/analytics.py`): fields `artifact_type:str`, `section:str`, `gate_id`, `app_id`, `dwell_ms`.
- **Service `record_events(db, events)`** (`src/services/viewer_analytics.py:61-104`):
  ```
  if not events: return 0
  rows = [{artifact_type: e.artifact_type[:150], section: e.section[:200],   # ⚠️ defensive truncation to migration-061 col widths
           gate_id: e.gate_id, app_id: e.app_id, dwell_ms: e.dwell_ms} for e in events]
  try: db.execute(INSERT INTO viewer_event (artifact_type, section, gate_id, app_id, dwell_ms) VALUES (...), rows)  # executemany
  except (ProgrammingError, DBAPIError) as exc:
      if _missing_relation(exc): return 0   # ⚠️ table absent (migration 061 not applied) → no-op, telemetry never breaks caller
      raise
  await db.commit()                          # ⚠️ service commits (NOT the router) when the insert succeeds
  return len(rows)
  ```
  `_missing_relation(exc)` (viewer_analytics.py:38-45): true when msg has `"does not exist"` OR (`"undefined"` & `"relation"`) OR (`"column"` & (`"does not exist"`|`"undefined"`)).

### B13. `GET /api/v1/analytics/viewer-events/summary` — dwell rollup by section (P5-S30.11) — `analytics.py:284-301` ⚠️ NEW at HEAD
- **Auth:** `_user:CurrentUser = Depends(require_role(*VIEWER_PLUS))`. **`response_model=ViewerAnalyticsSummaryResponse`.** `db` used.
- **Query:** `artifact_type:str|None=Query(None)`, `limit:int=Query(50, le=500)` (⚠️ `le=500`, no `ge`).
- **Handler:** `return await viewer_analytics_svc.summarize(db, artifact_type, limit)`.
- **Service `summarize(db, artifact_type, limit)`** (`viewer_analytics.py:107-159`):
  ```
  params={"limit":limit}; artifact_filter=""
  if artifact_type is not None: artifact_filter="WHERE artifact_type = :artifact_type"; params["artifact_type"]=artifact_type
  rows = _safe_execute(db, """
      SELECT artifact_type, section, COUNT(*) AS event_count,
             SUM(dwell_ms) AS total_dwell_ms, AVG(dwell_ms) AS avg_dwell_ms
      FROM viewer_event {artifact_filter}
      GROUP BY artifact_type, section ORDER BY total_dwell_ms DESC LIMIT :limit""", params)   # ⚠️ ordered by total dwell DESC
  # _safe_execute tolerates missing viewer_event → [] (empty on fresh DB)
  sections=[]; total_events=0
  for r in rows:
      count = int(r.get("event_count") or 0); total_events += count
      sections.append(ViewerSectionStat(artifact_type=r.get("artifact_type") or "", section=r.get("section") or "",
          event_count=count, total_dwell_ms=int(r.get("total_dwell_ms") or 0),
          avg_dwell_ms=float(r.get("avg_dwell_ms") or 0.0)))
  return ViewerAnalyticsSummaryResponse(sections=sections, total_events=total_events)
  ```
- **`ViewerAnalyticsSummaryResponse`** (`models/analytics.py`): `sections:list[ViewerSectionStat]`, `total_events:int`. **`ViewerSectionStat`**: `artifact_type:str`, `section:str`, `event_count:int`, `total_dwell_ms:int`, `avg_dwell_ms:float`.

---

## Cross-router GOTCHA summary
1. **VIEWER_PLUS differs:** skills includes `SERVICE`, analytics does NOT. (skills.py:33-43 vs analytics.py:45-54)
2. **Registry-vs-DB sources:** `/skills/categories` and `/skills/{skill_id}/variants` read from `registry.yaml` (in-process), NOT the `skill` DB table — intentional divergence.
3. **`_dimension_registry` is mutable process-global** mutated by `PUT /dimension-registry`; affects all readiness math process-wide; not persisted/per-tenant.
4. **Two empty-allowlist latent bugs (preserve literally):** `get_portfolio_scoring_heat_map` returns `PortfolioScoringHeatMapResponse(applications=[])` and `get_model_usage` returns `ModelUsageResponse(items=[])` — both use non-existent kwargs (correct fields are `entries` / `data`), so the empty-non-admin-membership branch would raise a Pydantic error. Reproduce as-is for parity.
5. **`by-line` skill metrics dedup** (A5): envelope `agent_task_id`s are collected and excluded from the agent_task fallback so each dispatch counts once; line_id accepted in kebab AND display form; all 10 lines always emitted; per-skill rows sorted by skill_id.
6. **Route mount order in skills** (A1-A11): static segments before `/{skill_id}` — must be preserved or `/categories`, `/metrics`, `/dispatch` would be swallowed by the path param.
7. **Float coercion convention:** metrics endpoints coerce `count/avg/sum` via `int(x or 0)` / `float(x or 0)`; gate/portfolio math rounds (2, 4, or 6 dp as noted per fn).
