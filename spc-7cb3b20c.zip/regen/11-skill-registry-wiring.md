# 11 — Skill Registry: Per-Line STEP → SKILL → OUTPUT-SCHEMA Wiring

> Companion to `regen/11-skill-registry.md`. This file is the **step-level dispatch wiring**:
> for every step of every assembly line, which skill(s) the step dispatches and the
> output-schema each schema-bearing skill produces — the full `step → skill → schema` chain.
>
> **Authoritative source:** the assembly-line definition YAMLs under
> `olympus-contracts/olympus_contracts/data/assembly-lines/<line>.yaml` (the `steps:` list,
> field `skills:` per step). These are the SAME files the Phase-1 contract docs
> (`regen/06-contracts/<line>-steps.md`) cite as `<line>.yaml:<line-no>`, and the same data the
> running `WaveWorkflow` / line workflows dispatch. Each step also has `kind`, `agent_role`,
> `gate`. Schema column resolved from each skill's `SKILL.md` frontmatter (see companion §4a).
>
> **Re-verified 2026-06-15 @ HEAD `7cb3b20c`** by parsing all **11** line YAMLs + **196**
> `SKILL.md` frontmatters.
>
> **⚠️ CHANGED since prior baseline (HEAD `7cb3b20c`):**
> - **NEW 11th line YAML — `build.yaml`** (the Build assembly line, Phase 6 W5). Added below as a
>   full step table. It dispatches the new `spec-from-requirements` skill (Step 1) and **reuses
>   Modernization's source-agnostic Design + Generate skills unchanged** — including
>   `security-scan-review`, which is therefore now dispatched by BOTH the Validation line AND the
>   Build `generate` step.
> - **Build-mode Discovery intake** — `requirements-doc-ingester` / `requirements-elicitation` are
>   dispatched by an API-driven Discovery fork, NOT as discrete `discovery.yaml` step skills; they
>   are listed in the cross-line/non-step-wired section (see end + companion D6).
> - All 10 pre-existing line tables below are **unchanged** at HEAD (re-verified step-by-step):
>   Discovery 14 steps, Rationalization 21, Architecture 19, Data 13, Modernization 33,
>   Validation 20, Deployment 18, Disposition Execution 13, Sustainment 8, Governance 10.
> - `validate-devsecops-baseline` is **NOT skill-backed** (no registry entry / no `SKILL.md`) and
>   appears in **no** line YAML as a step skill — it is a code activity, so it is absent here.
>   `iac-scaffolding-generator` remains a composed/router-dispatched scaffolder (not a discrete
>   step skill in any line YAML).

## How to read these tables

- **kind** — `agent` (dispatches skills to an agent), `code` (deterministic activity, no skill),
  `git` (commit/PR/merge activity, no skill), `gate` (human sign-off, no skill).
- **skills** — exact `skills:` list from the step (order preserved). A step may list MANY skills
  (the *available* set + variants); see GOTCHAs for which are actually executed vs routed.
- **→ schema** — the `output_schemas` path from that skill's `SKILL.md`. `—` = the skill declares
  no frontmatter schema (emits free-form artifact or contributes to the primary skill's artifact).
- ⚠️ **Primary-skill-carries-schema pattern.** In multi-skill `agent` steps, typically only the
  FIRST skill declares the schema for the step's gate-critical artifact; the rest are composed
  helpers. This is intentional (one validated artifact per step) but drift-prone.
- ⚠️ **Variant skills** (`*-mainframe`, `*-oracle`, code-gen targets, etc.) appear in the step
  `skills:` list as the *available* router set; the workflow's router fires exactly one per
  application based on tech-stack/language/disposition. None carry frontmatter schemas.

---

## LINE: Discovery — `discovery.yaml` (14 steps, gate G-DC)

| # | step id | kind | agent_role | gate | skills → schema |
|---|---|---|---|---|---|
| 0 | `catalog` | agent | Analysis Agent | — | `catalog-application` → `discovery/catalog.schema.json` |
| 1 | `structural-analysis` | agent | Analysis Agent | — | `legacy-architecture-mapper`→—; `legacy-language-reader`→—; `legacy-database-archaeologist`→—; `legacy-data-flow-tracer`→—; `identity-landscape-analyzer`→—; `compliance-citation-mapper`→—; `tiff-corpus-assessor`→—; `discovery-patterns`→—; **+5 variants** `discovery-patterns-mainframe/-oracle/-sqlserver/-dotnet/-doc-only`→— |
| 2 | `business-logic-extraction` | agent | Business Logic Extractor | — | `legacy-business-rule-extractor` → `discovery/business-logic.schema.json` |
| 3 | `quality-risk-assessment` | agent | Analysis Agent | — | `quality-risk-assessor` → `discovery/quality-risk.schema.json` |
| 4 | `ux-accessibility-assessment` | agent | UX Journey Analyzer | — | `ux-accessibility-assessor` → `discovery/ux-accessibility.schema.json` |
| 5 | `data-domain-discovery` | agent | Data Landscape Analyst | — | `data-domain-patterns` → `data/data-domains.schema.json` |
| 6 | `shared-database-analysis` | agent | Data Landscape Analyst | — | `decomposition-patterns` → `data/decomposition-strategy.schema.json` |
| 7 | `capability-extraction` | agent | Analysis Agent | — | `capability-extraction` → `discovery/capability-catalog.schema.json` |
| 8 | `synthesis` | agent | Synthesis Agent | — | `discovery-synthesizer` → `discovery/discovery-synthesis.schema.json`; `srs-from-discovery`→— |
| 9 | `tco-baseline` | agent | TCO Analyzer | — | `tco-analyzer`→— |
| 10 | `commit-artifacts` | git | — | — | (none) |
| 11 | `create-pr` | git | — | — | (none) |
| 12 | `gate-readiness-check` | agent | Pre-Review Agent | — | `gate-pre-review`→— |
| 13 | `gate-review` | gate | — | **G-DC** | (none) |

> ⚠️ GOTCHA (matches `06-contracts/discovery-steps.md`): step 1's 13-skill list is the *available*
> set, NOT all dispatched. `tiff-corpus-assessor` fires only when catalog sets
> `has_image_corpus: true`; `discovery-patterns-*` variants are router-selected by tech-stack.
> Only the base `discovery-patterns` handles the default/unknown-stack path. Step 8 has TWO
> skills: `discovery-synthesizer` (merge → schema) THEN `srs-from-discovery` (descriptive→SRS, no
> schema). Do not drop the second.

---

## LINE: Rationalization — `rationalization.yaml` (21 steps, gates G-RR, G-DA)

| # | step id | kind | agent_role | gate | skills → schema |
|---|---|---|---|---|---|
| 0 | `cross-app-redundancy` | agent | Rationalization Analyst | — | `redundancy-analyzer` → `rationalization/redundancy-matrix.schema.json` |
| 1 | `intra-app-redundancy` | agent | Rationalization Analyst | — | `redundancy-analyzer` → `rationalization/redundancy-matrix.schema.json` *(same schema, intra-app-redundancy.json artifact)* |
| 2 | `compare-ux-overlap` | agent | UX Journey Analyzer | — | `compare-ux-overlap` → `rationalization/ux-overlap-matrix.schema.json` |
| 3 | `portfolio-integration-mapping` | agent | Portfolio Integration Analyst | — | `portfolio-integration-mapper` → `rationalization/integration-graph.schema.json` |
| 4 | `analyze-portfolio-redundancy` | agent | Portfolio Redundancy Analyst | — | `analyze-portfolio-redundancy` → `rationalization/rationalization-clustering-plan.schema.json` |
| 5 | `commit-redundancy-artifacts` | git | — | — | (none) |
| 6 | `create-grr-pr` | git | — | — | (none) |
| 7 | `gate-review-rr` | gate | — | **G-RR** | (none) |
| 8 | `disposition-recommendation` | agent | Analysis Agent | — | `disposition-recommender` → `rationalization/disposition-recommendation.schema.json` |
| 9 | `disposition-governance` | agent | Validation Agent | — | `disposition-governance` → `rationalization/disposition-governance.schema.json` |
| 10 | `user-impact-analysis` | agent | Impact Analyzer | — | `assess-user-impact` → `rationalization/user-impact-analysis.schema.json` |
| 11 | `classification` | agent | Classification Agent | — | `classify-application` → `rationalization/classification.schema.json`; `classify-complexity`→— |
| 12 | `portfolio-scoring` | agent | Scoring Model | — | `portfolio-scorer` → `rationalization/portfolio-score.schema.json` |
| 13 | `capability-consolidation-advisory` | agent | Capability Consolidation Advisor | — | `capability-consolidation-advisor` → `rationalization/capability-consolidation-plan.schema.json` |
| 14 | `wave-planning` | agent | Sequencing Optimizer | — | `sequencer` → `rationalization/wave-plan.schema.json` + `rationalization/wave-plan-validation.schema.json` |
| 15 | `factory-routing` | code | — | — | (none) |
| 16 | `commit-disposition-artifacts` | git | — | — | (none) |
| 17 | `create-gda-pr` | git | — | — | (none) |
| 18 | `gate-review-da` | gate | — | **G-DA** | (none) |
| 19 | `wave-outcome-synthesis` | agent | Rationalization Analyst | — | `wave-outcome-synthesizer` → `rationalization/wave-outcome-synthesis.schema.json` |
| 20 | `portfolio-manifest-generation` | agent | Portfolio Close-out Analyst | — | `portfolio-manifest-generator`→— |

> Note: `redundancy-analyzer` is dispatched twice (cross-app step 0, intra-app step 1) — same
> skill, same schema, different artifact filename. `sequencer` (step 14) is the only step
> declaring two distinct schemas (plan + plan-validation). `cross-app-business-rule-analyzer`
> (registry, Cross-App Business Rule Synthesis) is NOT a discrete step id in this YAML — it is a
> pre-disposition synthesis dispatched outside the linear step list (see companion table).

---

## LINE: Architecture — `architecture.yaml` (19 steps, gate G-02)

| # | step id | kind | agent_role | gate | skills → schema |
|---|---|---|---|---|---|
| 0 | `target-state-mapping` | agent | Target-State Architect | — | `target-state-mapper` → `architecture/architecture-target-plan.schema.json` |
| 1 | `cloud-pattern-selection` | agent | Cloud Architect | — | `migration-strategy-advisor` → `architecture/cloud-pattern.schema.json`; `deployment-topology`→—; `target-architecture-blueprint`→— **(+3 disposition variants `-rearchitect/-refactor/-replatform`)** |
| 2 | `ea-compliance` | agent | EA Compliance Reviewer | — | `ea-compliance` → `architecture/ea-compliance.schema.json` |
| 3 | `integration-arch` | agent | Integration Architect | — | `api-contract-validator` → `architecture/integration-arch.schema.json`; `event-contract`→—; `resilience-designer`→— |
| 4 | `data-architecture` | code | — | — | (none) — handshake to Data line |
| 5 | `security-arch` | agent | Security Architect | — | `cato-compliance` → `architecture/security-arch.schema.json`; `security-posture-analyzer`→— |
| 6 | `design-system` | agent | Design System Architect | — | `design-system` → `architecture/design-system.schema.json` |
| 7 | `accessibility-review` | agent | Accessibility Reviewer | — | `accessibility-reviewer` → `architecture/accessibility-review.schema.json` |
| 8 | `ai-ml-integration` | agent | AI/ML Solutions Architect | — | `ai-ml-integration` → `architecture/ai-ml-integration.schema.json` |
| 9 | `blueprint-assembly` | agent | Architecture Synthesizer | — | `blueprint-assembly` → `architecture/architecture-blueprint.schema.json` |
| 10 | `cloud-cost-estimate` | agent | Cloud Cost Analyst | — | `cloud-cost-estimator` → `architecture/cost-estimate.schema.json` |
| 11 | `well-architected-review` | agent | Architecture Quality Reviewer | — | `well-architected-reviewer` → `architecture/well-architected-review.schema.json` |
| 12 | `traceability-validation` | agent | Traceability Validator | — | `architecture-traceability-validator`→— |
| 13 | `commit-blueprint-artifacts` | git | — | — | (none) |
| 14 | `create-g-02-pr` | git | — | — | (none) |
| 15 | `ai-pre-review` | agent | Gate Pre-Reviewer | — | `gate-pre-review`→— |
| 16 | `gate-review-02` | gate | — | **G-02** | (none) |
| 17 | `persist-architecture-side-effects` | code | — | — | (none) |
| 18 | `merge-blueprint-pr` | git | — | — | (none) |

> ⚠️ Step 1 `cloud-pattern-selection` dispatches `migration-strategy-advisor` (pattern/strategy,
> → schema) plus `target-architecture-blueprint` whose `-rearchitect/-refactor/-replatform`
> variants are disposition-routed. Blueprint *synthesis* moved to dedicated `blueprint-assembly`
> (step 9) per the 2026-04-30 contract — `migration-strategy-advisor` no longer does synthesis.

---

## LINE: Data — `data.yaml` (13 steps, gate G-DT)

| # | step id | kind | agent_role | gate | skills → schema |
|---|---|---|---|---|---|
| 0 | `wait-for-target-provisioned` | code | — | — | (none) |
| 1 | `domain-discovery` | agent | Data Architecture Lead | — | `data-domain-patterns` → `data/data-domains.schema.json` |
| 2 | `shared-db-analysis` | agent | Data Decomposition Architect | — | `decomposition-patterns` → `data/decomposition-strategy.schema.json` |
| 3 | `decomposition-strategy` | agent | Data Decomposition Architect | — | `decomposition-patterns` → `data/decomposition-strategy.schema.json` *(reused — same skill/schema as step 2)* |
| 4 | `migration-planning` | agent | Data Migration Planner | — | `data-migration-planner` → `data/data-migration-plan.schema.json` |
| 5 | `data-product-design` | agent | Data Product Designer | — | `data-product-specification` → `data/data-product-design.schema.json` **(+4 source variants `-mainframe/-oracle/-postgres/-sqlserver`)** |
| 6 | `data-synthesis` | agent | Data Architecture Lead | — | `data-modeling` → `data/data-architecture.schema.json` |
| 7 | `commit-data-artifacts` | git | — | — | (none) |
| 8 | `create-g-dt-pr` | git | — | — | (none) |
| 9 | `ai-pre-review` | agent | Gate Pre-Reviewer | — | `gate-pre-review`→— |
| 10 | `gate-review-dt` | gate | — | **G-DT** | (none) |
| 11 | `persist-data-side-effects` | code | — | — | (none) |
| 12 | `merge-data-pr` | git | — | — | (none) |

> ⚠️ `decomposition-patterns` is dispatched at both step 2 (shared-db analysis) and step 3
> (decomposition strategy) — same skill/schema. `data-product-specification` variants are
> source-DB-routed. `data-mesh-architecture` (registry, Library & API Reference) is
> **reference-only — no dispatch** in this YAML.

---

## LINE: Modernization — `modernization.yaml` (33 steps, gates G-04a, G-04b, G-04c)

Three-phase factory: **Extract (steps 1–9) → Design (10–20) → Generate (21–32)** with per-gate
PR/merge cycles. Step 22 is the **Ralph Loop** (per-BC TDD cycle).

| # | step id | kind | agent_role | gate | skills → schema |
|---|---|---|---|---|---|
| 0 | `wait-for-upstream-ready` | code | — | — | (none) — waits for Architecture + Data |
| 1 | `pre-processing` | agent | Extraction Lead | — | `dependency-mapper`→— |
| 2 | `extraction` | agent | Business Logic Extractor | — | `extraction`→—; `ux-flow-derivation`→—; `ux-page-specification`→— **(language variants `extraction-cobol/-java/-python/-coldfusion/-dotnet` routed — ⚠️ only `-dotnet` has a SKILL.md, see companion D2)** |
| 3 | `cross-validation` | agent | Cross-Validator | — | `cross-validation`→— |
| 4 | `commit-extract-artifacts` | git | — | — | (none) |
| 5 | `create-g-04a-pr` | git | — | — | (none) |
| 6 | `extract-pre-review` | agent | Gate Pre-Reviewer | — | `gate-pre-review`→— |
| 7 | `gate-review-04a` | gate | — | **G-04a** | (none) |
| 8 | `persist-extract-side-effects` | code | — | — | (none) |
| 9 | `merge-extract-pr` | git | — | — | (none) |
| 10 | `domain-modeling` | agent | Design Lead | — | `module-design`→—; `ux-component-specification`→— |
| 11 | `api-design` | agent | API Designer | — | `api-specification`→—; `event-contract`→— |
| 12 | `data-model-design` | agent | Data Modeler | — | `data-modeling` → `data/data-architecture.schema.json` |
| 13 | `batch-design` | agent | Batch Architect | — | `batch-design`→— |
| 14 | `traceability-audit` | agent | Design Lead | — | `traceability-audit`→— |
| 15 | `commit-design-artifacts` | git | — | — | (none) |
| 16 | `create-g-04b-pr` | git | — | — | (none) |
| 17 | `design-pre-review` | agent | Gate Pre-Reviewer | — | `gate-pre-review`→— |
| 18 | `gate-review-04b` | gate | — | **G-04b** | (none) |
| 19 | `persist-design-side-effects` | code | — | — | (none) |
| 20 | `merge-design-pr` | git | — | — | (none) |
| 21 | `bc-fanout` | code | — | — | (none) — fan-out per bounded context |
| 22 | `generate-bc-ralph-loop` | code | Ralph Loop Controller | — | `tdd-generation`→—; `code-generation`→—; **+7 code-gen variants** `code-generation-springboot/-dotnet/-fastapi/-node/-react/-cobol-to-java/-natural-to-springboot`→—; `test-validation`→—; `escalation-handler`→— |
| 23 | `code-synthesis` | agent | Synthesis Agent | — | `code-synthesis`→— |
| 24 | `security-posture-review` | agent | Security Reviewer | — | `security-posture-review`→— |
| 25 | `adversarial-review` | agent | Adversarial Reviewer | — | `adversarial-review`→— |
| 26 | `gate-review-package` | agent | Gate Pre-Reviewer | — | `gate-review-package`→— |
| 27 | `commit-generate-artifacts` | git | — | — | (none) |
| 28 | `create-g-04c-pr` | git | — | — | (none) |
| 29 | `generate-pre-review` | agent | Gate Pre-Reviewer | — | `gate-pre-review`→— |
| 30 | `gate-review-04c` | gate | — | **G-04c** | (none) |
| 31 | `persist-generate-side-effects` | code | — | — | (none) |
| 32 | `merge-generate-pr` | git | — | — | (none) |

> ⚠️ Step 22 (Ralph Loop) lists all 7 code-gen target variants + base `code-generation`; the
> language router picks one. NO modernization skill declares a frontmatter `output_schemas` block
> EXCEPT `data-modeling` (step 12, reused from Data line). All Modernization artifacts
> (extraction.json, module-design, api-spec, generated code) are validated by activities/contract
> checks, not by skill-frontmatter schemas. Many Code-Scaffolding skills (`xstate-fsm-generator`,
> `sse-broadcaster-scaffolder`, `oscal-fragment-emitter`, `jwt-claim-mapper`, the 7 FAA-domain
> scaffolders, etc.) are conditionally composed within Design/Generate but are NOT discrete top-
> level step ids in this YAML — they are dispatched by the design/generate agents as sub-skills.

---

## LINE: Build — `build.yaml` (15 steps, gates G-NEW-1, G-NEW-2, G-NEW-3) ✨NEW (Phase 6 W5)

The **Build** line is the third downstream execution line (alongside Modernization and
Disposition Execution), selected by the `Build` disposition for net-new greenfield apps with no
legacy source. Spec-driven new construction: **Spec-from-Requirements (Step 1) → Design (Step 2)
→ Generate (Step 3)**, with gates G-NEW-1/2/3 (equivalents of Modernization's G-04a/b/c). Strict
upstream `depends_on: [Architecture, Rationalization]`; trigger
`architecture-g02-approved-and-data-g-dt-approved`. Steps 2–3 **reuse Modernization's
source-agnostic skills verbatim**; only Step 1's `spec-from-requirements` is net-new.

| # | step id | kind | agent_role | gate | skills → schema |
|---|---|---|---|---|---|
| 0 | `spec-from-requirements` | agent | olympus-agent | — | `spec-from-requirements` → `build/scenario-spec.schema.json` |
| 1 | `commit-spec-artifacts` | git | — | — | (none) |
| 2 | `create-g-new-1-pr` | git | — | — | (none) |
| 3 | `spec-gate-readiness-check` | agent | olympus-agent | — | `gate-pre-review`→— |
| 4 | `gate-review-new-1` | gate | — | **G-NEW-1** | (none) |
| 5 | `design` | agent | olympus-agent | — | `module-design`→—; `api-specification`→—; `data-modeling` → `data/data-architecture.schema.json`; `traceability-audit`→— |
| 6 | `commit-design-artifacts` | git | — | — | (none) |
| 7 | `create-g-new-2-pr` | git | — | — | (none) |
| 8 | `design-gate-readiness-check` | agent | olympus-agent | — | `gate-pre-review`→— |
| 9 | `gate-review-new-2` | gate | — | **G-NEW-2** | (none) |
| 10 | `generate` | agent | olympus-agent | — | `tdd-generation`→—; `code-synthesis`→—; `adversarial-review`→—; `security-scan-review`→—; `escalation-handler`→— |
| 11 | `commit-generate-artifacts` | git | — | — | (none) |
| 12 | `create-g-new-3-pr` | git | — | — | (none) |
| 13 | `generate-gate-readiness-check` | agent | olympus-agent | — | `gate-pre-review`→— |
| 14 | `gate-review-new-3` | gate | — | **G-NEW-3** | (none) |

> ⚠️ GOTCHA — **Build reuses Modernization skills, with two consequences.** (1) The only
> schema-bearing skill in the Build line is `data-modeling` at Step 5 `design` (same skill/schema
> reused from the Data + Modernization lines → `data/data-architecture.schema.json`).
> `spec-from-requirements` at Step 0 also carries a schema (`build/scenario-spec.schema.json`),
> making Build the second line (after Rationalization) where the FIRST step's skill is the
> schema-bearing one. (2) `security-scan-review` (registry `line: Validation`,
> `profile_overrides: [faa]`) is now dispatched HERE in the Build `generate` step
> (`build.yaml:473`) **in addition to** its Validation-line Stream 2 home — a cross-line reuse.
> ⚠️ GOTCHA — **`agent_role` is the literal string `olympus-agent`** for every Build agent step
> (`build.yaml:82/194/282/390/475/589`), NOT the human-readable role labels ("Design Lead", etc.)
> the other 10 lines use. The Build line was authored against the generic agent role.

---

## LINE: Validation — `validation.yaml` (20 steps, gates G-V1, G-V2, G-V3)

Four streams: Functional Parity (G-V1), Security & Compliance (G-V2), Safety Assurance (G-V3).

| # | step id | kind | agent_role | gate | skills → schema |
|---|---|---|---|---|---|
| 0 | `intake` | code | — | — | (none) |
| 1 | `formal-test-plan-authoring` | agent | Validation Lead (Test Plan Author) | — | `formal-test-plan-generator`→— |
| 2 | `functional-parity` | agent | Parity Verification Agent | — | `parity-verifier`→—; `acceptable-divergences`→— |
| 3 | `security-compliance` | agent | Security & Compliance Agent | — | `security-scan-review`→—; `cato-evidence-validator`→— |
| 4 | `accessibility-ux` | agent | Accessibility Auditor | — | `accessibility-checker`→—; `design-system` → `architecture/design-system.schema.json` |
| 5 | `security-anomaly-resolution` | agent | Security Anomaly Resolver | — | `security-anomaly-resolution`→— |
| 6 | `bundle-g-v1-evidence` | code | — | — | (none) |
| 7 | `create-g-v1-pr` | git | — | — | (none) |
| 8 | `gate-review-v1` | gate | — | **G-V1** | (none) |
| 9 | `bundle-g-v2-evidence` | code | — | — | (none) |
| 10 | `create-g-v2-pr` | git | — | — | (none) |
| 11 | `ai-pre-review-v2` | agent | Gate Pre-Reviewer | — | `gate-pre-review`→— |
| 12 | `gate-review-v2` | gate | — | **G-V2** | (none) |
| 13 | `safety-assurance` | agent | Safety Assurance Agent | — | `safety-critical-verifier`→—; `traceability-checker`→— |
| 14 | `bundle-g-v3-evidence` | code | — | — | (none) |
| 15 | `create-g-v3-pr` | git | — | — | (none) |
| 16 | `ai-pre-review-v3` | agent | Gate Pre-Reviewer | — | `gate-pre-review`→— |
| 17 | `gate-review-v3` | gate | — | **G-V3** | (none) |
| 18 | `persist-validation-side-effects` | code | — | — | (none) |
| 19 | `merge-final-gate-pr` | git | — | — | (none) |

> ⚠️ Step 4 reuses `design-system` (the Architecture skill, → design-system schema) for the
> accessibility/UX audit — the only schema-bearing skill in the Validation line. All other
> validation outputs (parity reports, compliance evidence, safety attestations) are free-form /
> activity-validated, not skill-schema-validated.

---

## LINE: Deployment — `deployment.yaml` (18 steps, gates G-DP-1, G-DP-2)

| # | step id | kind | agent_role | gate | skills → schema |
|---|---|---|---|---|---|
| 0 | `intake` | code | — | — | (none) |
| 1 | `orchestration` | agent | Deployment Orchestrator | — | `deploy-modernized-app`→—; `monitoring-bootstrap`→— |
| 2 | `traffic-shifting` | agent | Traffic Shift Controller | — | `traffic-shift`→— |
| 3 | `parallel-run` | agent | Parallel Run Monitor | — | `parallel-run-monitor`→— |
| 4 | `adoption-verification` | agent | Adoption Tracker | — | `adoption-analytics`→—; `user-adoption-coordinator`→— |
| 5 | `bundle-g-dp1-evidence` | code | — | — | (none) |
| 6 | `create-g-dp1-pr` | git | — | — | (none) |
| 7 | `ai-pre-review-dp1` | agent | Gate Pre-review Agent | — | `gate-pre-review`→— |
| 8 | `gate-review-dp1` | gate | — | **G-DP-1** | (none) |
| 9 | `merge-g-dp1-pr` | git | — | — | (none) |
| 10 | `legacy-decommission` | agent | Decommission Orchestrator | — | `legacy-decommission`→—; `environment-cleanup`→— |
| 11 | `cost-certification` | agent | Cost Savings Certifier | — | `tco-analyzer`→— |
| 12 | `bundle-g-dp2-evidence` | code | — | — | (none) |
| 13 | `create-g-dp2-pr` | git | — | — | (none) |
| 14 | `ai-pre-review-dp2` | agent | Gate Pre-review Agent | — | `gate-pre-review`→— |
| 15 | `gate-review-dp2` | gate | — | **G-DP-2** | (none) |
| 16 | `persist-deployment-side-effects` | code | — | — | (none) |
| 17 | `merge-final-gate-pr` | git | — | — | (none) |

> Note: `tco-analyzer` reused at step 11 (cost certification) — Discovery→Deployment reuse, no
> schema. No Deployment skill declares a frontmatter schema.

---

## LINE: Disposition Execution — `disposition-execution.yaml` (13 steps, gates G-DE-1, G-DE-2)

The 13 linear steps are a gate-and-PR skeleton; the **per-disposition strategy skills**
(Retire/Retain/Replace/Replatform/Consolidate families) are dispatched *inside* the
`pre-gate-strategy` and `post-gate-execution` agent steps (which list NO `skills:` in the YAML —
strategy skills are routed by the Disposition Strategy Registry, not hard-coded into steps).

| # | step id | kind | agent_role | gate | skills → schema |
|---|---|---|---|---|---|
| 0 | `pre-gate-strategy` | agent | Disposition Execution Agent | — | (none in YAML — strategy skills routed by disposition; see below) |
| 1 | `bundle-pre-gate-evidence` | code | — | — | (none) |
| 2 | `create-g-de1-pr` | git | — | — | (none) |
| 3 | `ai-pre-review-de1` | agent | Gate Pre-Reviewer | — | `gate-pre-review`→— |
| 4 | `gate-review-de1` | gate | — | **G-DE-1** | (none) |
| 5 | `merge-g-de1-pr` | git | — | — | (none) |
| 6 | `post-gate-execution` | agent | Disposition Execution Agent | — | (none in YAML — strategy skills routed by disposition; see below) |
| 7 | `bundle-post-gate-evidence` | code | — | — | (none) |
| 8 | `create-g-de2-pr` | git | — | — | (none) |
| 9 | `ai-pre-review-de2` | agent | Gate Pre-Reviewer | — | `gate-pre-review`→— |
| 10 | `gate-review-de2` | gate | — | **G-DE-2** | (none) |
| 11 | `persist-disposition-side-effects` | code | — | — | (none) |
| 12 | `merge-g-de2-pr` | git | — | — | (none) |

> ⚠️ GOTCHA — the disposition strategy skills are NOT wired as step `skills:` in this YAML. They
> are dispatched by the disposition router based on the per-app disposition decision. The full set
> (all → no frontmatter schema), grouped by disposition (from companion table `line: Disposition
> Execution`):
> - **Retire:** `security-decommission`, `license-reclamation`
> - **Retain:** `test-coverage-uplift`, `security-remediation-planning`, `documentation-remediation`, `monitoring-bootstrap`, `sustainment-handoff`
> - **Replace:** `vendor-evaluation`, `requirements-derivation`, `integration-specification`
> - **Replatform:** `platform-selection`, `workflow-mapping`, `component-configuration`, `validation-cutover`
> - **Consolidate:** `target-selection`, `feature-gap-analysis`, `data-reconciliation-planning`, `enhancement-planning`
> - **Replace/Replatform shared:** `data-migration-planning`
> - **Pre-cutover (all):** `user-transition-planning`, `data-archival-planning`, `consumer-migration-planning`

---

## LINE: Sustainment — `sustainment.yaml` (8 steps, no gate — continuous sweep)

| # | step id | kind | agent_role | gate | skills → schema |
|---|---|---|---|---|---|
| 0 | `intake` | code | — | — | (none) |
| 1 | `cve-triage` | agent | Patch Manager | — | `patch-assessment`→— |
| 2 | `incident-response` | agent | Incident Responder | — | `incident-response`→— |
| 3 | `sla-monitoring` | agent | SLA Monitor | — | `sla-breach-investigation`→— |
| 4 | `change-conflict-detection` | agent | Change Conflict Resolver | — | `change-conflict-resolver`→— |
| 5 | `cost-anomaly-detection` | agent | Cost Optimizer | — | `cost-anomaly-investigation`→— |
| 6 | `persist-sustainment-sweep-side-effects` | code | — | — | (none) |
| 7 | `commit-sweep-summary` | code | — | — | (none) |

> Note: `faa-style-brownfield` (registry, `line: Sustainment, Activity 1 — O&M`) is an FAA style
> skill composed within O&M activities, not a discrete step id here. No Sustainment skill declares
> a schema.

---

## LINE: Governance & Improvement — `governance.yaml` (10 steps, no gate — continuous sweep)

| # | step id | kind | agent_role | gate | skills → schema |
|---|---|---|---|---|---|
| 0 | `intake` | code | — | — | (none) |
| 1 | `drift-detection` | agent | Governance Drift Monitor | — | `drift-detection`→— **(fan-out aggregator; depends_on 5 sub-skills `drift-detection-architecture/-compliance/-performance/-cost/-adoption`, all →—)** |
| 2 | `pattern-extraction` | agent | Pattern Extractor | — | `skill-builder`→— |
| 3 | `health-report` | agent | Portfolio Health Checker | — | `portfolio-health-check`→— |
| 4 | `skill-evolution` | agent | Skill Evolution Agent | — | `skill-builder`→— *(reused — same skill as step 2)* |
| 5 | `factory-capacity` | agent | Factory Capacity Planner | — | `factory-capacity-manager`→— |
| 6 | `model-evaluation` | agent | Model Evaluator | — | `model-benchmark`→— |
| 7 | `propagate-patterns` | code | — | — | (none) — propagate to Modernization |
| 8 | `persist-governance-sweep-side-effects` | code | — | — | (none) |
| 9 | `commit-sweep-summary` | code | — | — | (none) |

> ⚠️ Step 1 `drift-detection` is the `is_orchestration: true` aggregator (companion D1): it
> dispatches the 5 `drift-detection-*` category sub-skills (each its own SKILL.md + registry
> entry) and synthesizes a portfolio drift report. `skill-builder` is dispatched twice (steps 2
> and 4). Governance skills `wave-status-report`, `factory-health-check`, `skill-validator`,
> `decomposition-skill-writer` (companion table, `line: Governance`) are composed within
> Activities 5/6 but are NOT discrete step ids in this YAML.

---

## Cross-line / non-step-wired skills (dispatched, but not a discrete line-YAML step)

These registry skills are real and dispatched, but appear as composed sub-skills or
router-selected entries rather than top-level `steps[].skills` in any line YAML:

| skill | line (registry) | how dispatched | schema |
|---|---|---|---|
| `gate-pre-review` | Cross-Cutting | every gate's AI pre-review step (appears in 8+ steps across lines) | — |
| `olympus-collaboration` | Cross-Cutting | human-paired-agent dispatch+return wrapper (HCD) | — |
| `cocomo-cosmic-analysis` | Rationalization | on-demand cost/effort estimation (not in linear steps) | — |
| `cross-app-business-rule-analyzer` | Rationalization | pre-disposition cross-app synthesis | `rationalization/business-rule-redundancy.schema.json` |
| `requirements-doc-ingester` ✨NEW | Discovery (Build mode) | API-driven Discovery fork on `source_type=requirements_doc` — normalizes uploaded doc; NOT a `discovery.yaml` step (companion D6) | `build/requirements-capability.schema.json` |
| `requirements-elicitation` ✨NEW | Discovery (Build mode) | API-driven interview flow on `source_type=interview` (`olympus-api/src/services/interview.py:66`,`:586`); dispatched at interview completion, NOT a `discovery.yaml` step (companion D6) | `build/requirements-capability.schema.json` |
| `requirement-aggregation`, `business-rule-reconciliation` | Modernization | composed in Extract | — |
| 7 FAA-domain scaffolders + 8 generic scaffolders (incl. `iac-scaffolding-generator`) | Modernization | composed in Design/Generate by archetype/IaC router — never a discrete step skill | — |
| Disposition strategy skills (20) | Disposition Execution | disposition router (see Disposition section) | — |
| `faa-style-brownfield/-greenfield`, `faa-code-standards` | Modern/Sustainment | composed style skills | — |

> ⚠️ This is expected: the line-YAML `steps[].skills` lists the *gate-critical, schema-bearing or
> always-run* skills; archetype/router-selected and composed-helper skills are dispatched
> programmatically by the agent or registry router, not enumerated per step. ⚠️ **CHANGED:** the
> two Build-mode intake skills are a NEW class of router-dispatched skill — they DO carry a
> frontmatter schema yet are still not step-wired (the Build-mode Discovery fork is driven from
> the API/interview service, not the `discovery.yaml` step list). The companion table
> (`11-skill-registry.md` §7) is the complete set of **170**; THIS file is the step-level subset
> hard-wired into the **11** line definitions (now incl. `build.yaml`).
