# Regeneration Spec — Data Layer: Sustainment & Governance Sweep Tables

**Scope:** ATOMIC, behavioral-parity spec for the 11 portfolio-scoped, sweep-keyed projection tables written by the two `persist_*_sweep_side_effects` activities. Bar: the schema must be rebuildable EXACTLY (column-by-column, constraint-for-constraint), and the Git→DB projection model must be reproducible from the activity behavior alone.

**The 11 tables:**

| Table | Created by migration | Written by activity |
|---|---|---|
| `incident_log` | `037_create_sustainment_tables.py` | `persist_sustainment_sweep_side_effects` |
| `sla_compliance_record` | `037` | `persist_sustainment_sweep_side_effects` |
| `patching_compliance` | `037` | `persist_sustainment_sweep_side_effects` |
| `cost_anomaly_record` | `037` | `persist_sustainment_sweep_side_effects` |
| `do_not_modify_flag` | `037` | `persist_sustainment_sweep_side_effects` (UPSERT) |
| `sustainment_override_log` | `037` | `persist_sustainment_sweep_side_effects` |
| `drift_alert` | `025_create_governance_tables.py` | `persist_governance_sweep_side_effects` |
| `pattern` | `025` | `persist_governance_sweep_side_effects` (INSERT + reuse_count UPDATE) |
| `health_check` | `025` | `persist_governance_sweep_side_effects` |
| `factory_capacity_plan` | `038_add_governance_sweep_tables.py` | `persist_governance_sweep_side_effects` |
| `model_benchmark_result` | `038` | `persist_governance_sweep_side_effects` (QUARTERLY only) |

**Absolute migration directory:** `/Users/pnunna/Documents/GitHub/foundry/db/alembic/versions/` (56 migration files; numbered 001–066 with a gap — see Migration DAG below).

---

## 0. KEY FINDINGS (read first)

1. **ZERO CHECK constraints across all 11 tables.** A full grep of all 56 migrations for `CheckConstraint` / `check(` matching any of these tables returns NONE (verified). The enum-like value sets (`drift_alert` severity & type, `model_benchmark_result.tier`, incident severities, CVE severity keys) are enforced **only in the Python extractor helpers** (frozenset whitelists), NOT by the database. ⚠️ **GOTCHA for rebuild:** Do NOT add DB CHECK constraints — the table accepts any string in those columns; the gate is application-layer. Adding a CHECK would diverge from behavior (e.g. `incident_log.severity` keeps non-whitelisted values; the whitelist test is a documented no-op).

2. **NO enum→varchar+CHECK migration touched these tables.** None of these 11 tables ever used a PostgreSQL ENUM type. They were born as `VARCHAR(n)` (or numeric/bool/jsonb) and never altered. The "flexibility migration" gotcha (enum→varchar) does not apply here — all the string columns (`severity`, `status`, `tier`, `type`, `override_type`, `category`, etc.) are plain `VARCHAR` from creation with NO constraint. Contrast: the `application`/`wave`/`gate` enum→varchar churn lives in migrations 022/023/042/043/045/047/049/059 and does not reach these tables.

3. **NO SQLAlchemy ORM models.** These tables have no declarative model class. They are written by **raw asyncpg** parameterized INSERT/UPDATE inside the two projection activities (`temporal/olympus_workflows/activities/line_transitions.py`). Server-side defaults (`gen_random_uuid()`, `now()`, `0`, `false`, `true`, `'[]'::jsonb`) are the migration-declared `server_default`s and are the authoritative defaults — there is no Python-side `default=`. The API read-side Pydantic models (`olympus-api/src/routers/governance.py:90`–`125`) only shape the read of `drift_alert`/`pattern`/`health_check`.

4. **All FKs target `application.id`.** Two cascade styles: `ON DELETE CASCADE` (mass-delete risk — see §Cascade Audit) and `ON DELETE SET NULL`. No `ON UPDATE` clause is declared anywhere (so `ON UPDATE NO ACTION`, the PostgreSQL default). `portfolio_id` and `sweep_id`/`wave_id` are **bare UUID/VARCHAR columns with NO foreign key** (portfolio is not a table FK here; `sweep_id` is a Temporal schedule id string, not a row id).

5. **`gen_random_uuid()` requires `pgcrypto`/pg13+.** All PKs default `server_default=sa.text("gen_random_uuid()")`. The extension must be available (migration 001 / bootstrap, see `00b-environment.md`). Not re-declared per table.

6. **Idempotency split:** `do_not_modify_flag` is the ONLY idempotent table (UPSERT on `(portfolio_id, app_id)`). All other 10 are INSERT-only with NO unique key on `sweep_id` → re-running a sweep DUPLICATES rows. `pattern.reuse_count` UPDATE is additive (double-counts on re-run). This is by design (best-effort, cron-once-per-sweep).

---

## 1. Migration DAG (relevant slice) + per-migration ledger

The full version graph is a single linear chain with one diamond merge (039) and one numbering gap (no `055`).

```
... 024 → 025 (health_check, drift_alert, pattern)
              ↓
         ... 032 → 033 (step_execution)
                     ├─→ 034 (disposition cols)        ┐
                     ├─→ 035 (validation cols)         │
                     ├─→ 036 (deployment cols) → 037   │  four W19 heads
                     │                          (6 sustainment tables + 2 app cols)
                     └─→ 038 (factory_capacity_plan,    │
                              model_benchmark_result)   ┘
                     (037 chains 036→037; 038 branches directly off 033)
                                   ↓
              039  MERGE (Revises: 034, 035, 037, 038)  — NO-OP, no DDL, no seed
                                   ↓
              040 … 049 → 050 → 051 → 052 → 053 → 054 → 056 → 057 → 058 → 059
                                   → 060 → 061 → 062 → 063 → 064 → 065 → 066
```

**⚠️ Numbering gap:** there is **no migration `055`**. The chain skips from `054_add_architecture_workflow_id_to_wave` (revision `"054"`) to `056_create_portfolio_membership` whose `down_revision = "054"` (verified `056:28`). Alembic revision ids are strings; the gap is cosmetic and does not break the linear chain.

**Per-migration ledger (only migrations touching the 11 tables):**

| Migration file | revision / down_revision | DDL on target tables |
|---|---|---|
| `025_create_governance_tables.py` | `025` / `024` | CREATE `health_check`, `drift_alert`, `pattern` (+ their indexes). `025:1` docstring: "Create governance tables: health_check, drift_alert, pattern." DDL only, no seed. |
| `037_create_sustainment_tables.py` | `037` / `036` | CREATE `patching_compliance`, `incident_log`, `sla_compliance_record`, `do_not_modify_flag`, `cost_anomaly_record`, `sustainment_override_log` (+ indexes + 1 unique constraint); ADD `application.sustainment_current_status`, `application.sustainment_last_sweep_at`. DDL only (`037:43`). |
| `038_add_governance_sweep_tables.py` | `038` / `033` | CREATE `factory_capacity_plan`, `model_benchmark_result` (+ indexes). DDL only (`038:7`). Docstring `038:28` explicitly notes the 025 tables (`drift_alert`/`pattern`/`health_check`) are UNCHANGED by 038. |
| `039_merge_w19_reconciliation_heads.py` | `039` / `("034","035","037","038")` | **NO DDL** — empty `upgrade()`/`downgrade()` merge bookkeeping only (`039:36`–`41`). |

**Verified:** No other migration (001–024, 026–036, 040–066) issues any `op.*` against these 11 table names. The earlier grep hits on the literal word "pattern" in 018/021/030/031/033 are false positives — they reference `architecture_pattern` / `data_pattern` columns on `application` (030:85, 031:106) and a `pattern` VARCHAR column on a different (target-service) table (031:136), plus prose comments — NOT the `pattern` table. Confirmed by reading each match.

---

## 2. Column-by-column table definitions

Legend for **Default** column: value shown is the SQL `server_default` text exactly as emitted; "—" = no server default (column is `NULL`-able with no default, or required-from-writer). **FK** column: "→ table.col (ON DELETE …)"; no `ON UPDATE` is ever declared (PostgreSQL default `NO ACTION`).

---

### 2.1 `incident_log` — 9 columns (migration 037, `op.create_table` at `037:116`–`142`)

One row per incident processed during a sweep (per-app, per-sweep). Append-only.

| # | Column | Type | Nullable | Default | FK (→table.col, ON DELETE/UPDATE) | Added by |
|---|---|---|---|---|---|---|
| 1 | `id` | `UUID` | NO (PK) | `gen_random_uuid()` | — | `037:118` |
| 2 | `portfolio_id` | `UUID` | NO | — | — (bare UUID, NOT a FK) | `037:124` |
| 3 | `sweep_id` | `VARCHAR(255)` | NO | — | — (Temporal schedule id string) | `037:125` |
| 4 | `app_id` | `UUID` | YES | — | → `application.id` **ON DELETE SET NULL** | `037:126`–`131` |
| 5 | `severity` | `VARCHAR(16)` | NO | — | — | `037:132` |
| 6 | `symptom` | `VARCHAR(255)` | YES | — | — | `037:133` |
| 7 | `status` | `VARCHAR(32)` | NO | — | — | `037:134` |
| 8 | `resolution_summary` | `TEXT` | YES | — | — | `037:135` |
| 9 | `recorded_at` | `TIMESTAMP WITH TIME ZONE` | NO | `now()` | — | `037:136`–`141` |

**Indexes (037):**
- `ix_incident_log_portfolio` on `(portfolio_id, recorded_at)` (`037:143`).
- `ix_incident_log_app` on `(app_id)` **PARTIAL** `WHERE app_id IS NOT NULL` (`037:148`–`153`).

**Unique constraints:** none.
**CHECK constraints:** none. ⚠️ `severity` is whitelist-validated only in Python (`_INCIDENT_SEVERITIES = {"P1","P2","P3","P4","critical","high","medium","low"}`, `037`-activity constants `4373`), but the check is a **documented no-op** — non-whitelisted severities are still inserted (truncated to 16 chars; empty → literal `"unknown"`). No DB enforcement.

---

### 2.2 `sla_compliance_record` — 9 columns (migration 037, `op.create_table` at `037:156`–`199`)

One row per app per sweep with availability / response-time / incident-resolution readings. Append-only.

| # | Column | Type | Nullable | Default | FK (→table.col, ON DELETE/UPDATE) | Added by |
|---|---|---|---|---|---|---|
| 1 | `id` | `UUID` | NO (PK) | `gen_random_uuid()` | — | `037:158` |
| 2 | `portfolio_id` | `UUID` | NO | — | — | `037:164` |
| 3 | `sweep_id` | `VARCHAR(255)` | NO | — | — | `037:165` |
| 4 | `app_id` | `UUID` | **NO** | — | → `application.id` **ON DELETE CASCADE** | `037:166`–`171` |
| 5 | `availability_pct` | `NUMERIC(5,3)` | YES | — | — | `037:172`–`176` |
| 6 | `response_time_p95_ms` | `NUMERIC(10,2)` | YES | — | — | `037:177`–`181` |
| 7 | `incident_resolution_mean_hours` | `NUMERIC(10,2)` | YES | — | — | `037:182`–`186` |
| 8 | `breach_count` | `INTEGER` | NO | `0` (`server_default="0"`) | — | `037:187`–`192` |
| 9 | `recorded_at` | `TIMESTAMP WITH TIME ZONE` | NO | `now()` | — | `037:193`–`198` |

**Indexes (037):**
- `ix_sla_compliance_portfolio` on `(portfolio_id, recorded_at)` (`037:200`).
- `ix_sla_compliance_app` on `(app_id, recorded_at)` (`037:205`).

**Unique constraints:** none. **CHECK constraints:** none.
⚠️ **GOTCHA — CASCADE + NOT NULL `app_id`:** deleting an `application` row mass-deletes all its `sla_compliance_record` rows (see Cascade Audit §3).

---

### 2.3 `patching_compliance` — 9 columns (migration 037, `op.create_table` at `037:63`–`108`)

One row per sweep with portfolio-wide open-CVE counts + SLA compliance percentage. Append-only. (No per-app `app_id` — this is portfolio-grain.)

| # | Column | Type | Nullable | Default | FK | Added by |
|---|---|---|---|---|---|---|
| 1 | `id` | `UUID` | NO (PK) | `gen_random_uuid()` | — | `037:65` |
| 2 | `portfolio_id` | `UUID` | NO | — | — | `037:71` |
| 3 | `sweep_id` | `VARCHAR(255)` | NO | — | — | `037:72` |
| 4 | `critical_open_count` | `INTEGER` | NO | `0` | — | `037:73`–`78` |
| 5 | `high_open_count` | `INTEGER` | NO | `0` | — | `037:79`–`84` |
| 6 | `medium_open_count` | `INTEGER` | NO | `0` | — | `037:85`–`90` |
| 7 | `low_open_count` | `INTEGER` | NO | `0` | — | `037:91`–`96` |
| 8 | `sla_compliance_pct` | `NUMERIC(5,2)` | YES | — | — | `037:97`–`101` |
| 9 | `evaluated_at` | `TIMESTAMP WITH TIME ZONE` | NO | `now()` | — | `037:102`–`107` |

**Indexes (037):** `ix_patching_compliance_portfolio` on `(portfolio_id, evaluated_at)` (`037:109`).
**Unique constraints:** none. **CHECK constraints:** none. **FKs:** none (portfolio-grain, no `app_id`).

---

### 2.4 `cost_anomaly_record` — 9 columns (migration 037, `op.create_table` at `037:267`–`298`)

One row per app per sweep with baseline vs. observed spend + variance flag. Append-only.

| # | Column | Type | Nullable | Default | FK (→table.col, ON DELETE/UPDATE) | Added by |
|---|---|---|---|---|---|---|
| 1 | `id` | `UUID` | NO (PK) | `gen_random_uuid()` | — | `037:269` |
| 2 | `portfolio_id` | `UUID` | NO | — | — | `037:275` |
| 3 | `sweep_id` | `VARCHAR(255)` | NO | — | — | `037:276` |
| 4 | `app_id` | `UUID` | **NO** | — | → `application.id` **ON DELETE CASCADE** | `037:277`–`282` |
| 5 | `baseline_usd` | `NUMERIC(14,2)` | YES | — | — | `037:283` |
| 6 | `observed_usd` | `NUMERIC(14,2)` | YES | — | — | `037:284` |
| 7 | `variance_pct` | `NUMERIC(7,2)` | YES | — | — | `037:285` |
| 8 | `flagged` | `BOOLEAN` | NO | `false` (`sa.text("false")`) | — | `037:286`–`291` |
| 9 | `recorded_at` | `TIMESTAMP WITH TIME ZONE` | NO | `now()` | — | `037:292`–`297` |

**Indexes (037):**
- `ix_cost_anomaly_portfolio` on `(portfolio_id, recorded_at)` (`037:299`).
- `ix_cost_anomaly_flagged` on `(portfolio_id, flagged)` **PARTIAL** `WHERE flagged = true` (`037:304`–`308`).

**Unique constraints:** none. **CHECK constraints:** none.
⚠️ CASCADE + NOT NULL `app_id`: same mass-delete behavior as `sla_compliance_record`.

---

### 2.5 `do_not_modify_flag` — 8 columns (migration 037, `op.create_table` at `037:212`–`258`)

Current-state register for apps entering Modernization. **UPSERT** target (the only idempotent table). Modernization's Extract step reads this at entry.

| # | Column | Type | Nullable | Default | FK (→table.col, ON DELETE/UPDATE) | Added by |
|---|---|---|---|---|---|---|
| 1 | `id` | `UUID` | NO (PK) | `gen_random_uuid()` | — | `037:214` |
| 2 | `portfolio_id` | `UUID` | NO | — | — (part of UQ + conflict key) | `037:220` |
| 3 | `app_id` | `UUID` | **NO** | — | → `application.id` **ON DELETE CASCADE**; part of UQ + conflict key | `037:221`–`226` |
| 4 | `flagged_at` | `TIMESTAMP WITH TIME ZONE` | NO | `now()` | — | `037:227`–`232` |
| 5 | `wave_id` | `UUID` | YES | — | — (bare UUID, NOT a FK) | `037:233`–`237` |
| 6 | `expires_at` | `TIMESTAMP WITH TIME ZONE` | YES | — | — | `037:238`–`242` |
| 7 | `active` | `BOOLEAN` | NO | `true` (`sa.text("true")`) | — | `037:243`–`248` |
| 8 | `override_count` | `INTEGER` | NO | `0` (`server_default="0"`) | — | `037:249`–`254` |

**Unique constraints:**
- `uq_do_not_modify_flag_portfolio_app` UNIQUE `(portfolio_id, app_id)` (`037:255`–`257`). This is the UPSERT conflict target.

**Indexes (037):** `ix_do_not_modify_flag_active` on `(portfolio_id, active)` **PARTIAL** `WHERE active = true` (`037:259`–`263`).
**CHECK constraints:** none.

⚠️ **UPSERT semantics (from the writing activity):** `INSERT … ON CONFLICT (portfolio_id, app_id) DO UPDATE SET wave_id=EXCLUDED.wave_id, expires_at=EXCLUDED.expires_at, active=EXCLUDED.active, override_count=EXCLUDED.override_count`. On conflict, `flagged_at` is **NOT** updated (preserves original flag time). `override_count` is **OVERWRITTEN** from the artifact's declared value (NOT incremented from the DB) — the docstring's "preserve override_count" intent is realized only because the change-conflict skill re-declares the current register including the running `override_count`. Cross-ref: `regen/03b-activities/line_transitions-5-sustainment-governance.md:206`–`222`.

---

### 2.6 `sustainment_override_log` — 8 columns (migration 037, `op.create_table` at `037:312`–`337`)

One row per `override_approved` signal consumed by a sweep. Append-only.

| # | Column | Type | Nullable | Default | FK (→table.col, ON DELETE/UPDATE) | Added by |
|---|---|---|---|---|---|---|
| 1 | `id` | `UUID` | NO (PK) | `gen_random_uuid()` | — | `037:314` |
| 2 | `portfolio_id` | `UUID` | NO | — | — | `037:320` |
| 3 | `app_id` | `UUID` | YES | — | → `application.id` **ON DELETE SET NULL** | `037:321`–`326` |
| 4 | `gate_id` | `VARCHAR(255)` | YES | — | — | `037:327` |
| 5 | `override_by` | `VARCHAR(255)` | NO | — | — | `037:328` |
| 6 | `justification` | `TEXT` | YES | — | — | `037:329` |
| 7 | `override_type` | `VARCHAR(64)` | NO | — | — | `037:330` |
| 8 | `recorded_at` | `TIMESTAMP WITH TIME ZONE` | NO | `now()` | — | `037:331`–`336` |

**Indexes (037):** `ix_sustainment_override_log_portfolio` on `(portfolio_id, recorded_at)` (`037:338`).
**Unique constraints:** none. **CHECK constraints:** none.

---

### 2.7 `drift_alert` — 8 columns (migration 025, `op.create_table` at `025:55`–`85`)

One row per drift alert. Append-only. ⚠️ **No `severity` column** — severity is folded into the `details` JSONB by the writer.

| # | Column | Type | Nullable | Default | FK (→table.col, ON DELETE/UPDATE) | Added by |
|---|---|---|---|---|---|---|
| 1 | `id` | `UUID` | NO (PK) | `gen_random_uuid()` | — | `025:57` |
| 2 | `type` | `VARCHAR(100)` | NO | — | — | `025:63` |
| 3 | `application_id` | `UUID` | YES | — | → `application.id` **ON DELETE CASCADE** | `025:64`–`69` |
| 4 | `details` | `JSONB` | YES | — | — | `025:70` |
| 5 | `acknowledged` | `BOOLEAN` | NO | `false` (`sa.text("false")`) | — | `025:71`–`76` |
| 6 | `acknowledged_by` | `VARCHAR(255)` | YES | — | — | `025:77` |
| 7 | `acknowledged_at` | `TIMESTAMP WITH TIME ZONE` | YES | — | — | `025:78` |
| 8 | `created_at` | `TIMESTAMP WITH TIME ZONE` | NO | `now()` | — | `025:79`–`84` |

**Indexes (025):** `ix_drift_alert_acknowledged` on `(acknowledged)` (`025:86`).
**Unique constraints:** none. **CHECK constraints:** none. ⚠️ `type` is whitelisted in Python (`_DRIFT_TYPES = {"architecture","compliance","performance","cost","adoption"}`) and `severity` (inside `details`) against `_DRIFT_SEVERITIES = {"critical","high","medium","low"}` — rows failing either are SKIPPED by the extractor (logged + `continue`), so they never reach the DB. No DB CHECK. Cross-ref: activities md `5083`–`5089`, `5092`.

**`details` JSONB shape** (written by activity, `json.dumps(...)::jsonb`):
```json
{
  "severity": "critical|high|medium|low",
  "...": "any keys from the artifact entry's own `details` dict, merged AFTER severity (so an artifact details.severity would override the folded one)"
}
```
Minimal form when artifact has no extra details: `{"severity": "high"}`. API read model (`governance.py:102`) treats `details` as `dict[str, Any] = {}`.

---

### 2.8 `pattern` — 9 columns (migration 025, `op.create_table` at `025:94`–`120`)

Reuse pattern catalog. INSERT (one per extracted pattern) + bulk `reuse_count` UPDATE. Append-only for inserts.

| # | Column | Type | Nullable | Default | FK | Added by |
|---|---|---|---|---|---|---|
| 1 | `id` | `UUID` | NO (PK) | `gen_random_uuid()` | — | `025:96` |
| 2 | `name` | `VARCHAR(255)` | NO | — | — | `025:102` |
| 3 | `category` | `VARCHAR(100)` | NO | — | — | `025:103` |
| 4 | `description` | `TEXT` | YES | — | — | `025:104` |
| 5 | `wave_id` | `UUID` | YES | — | — (bare UUID, NOT a FK) | `025:105` |
| 6 | `source_apps` | `JSONB` | NO | `'[]'::jsonb` (`sa.text("'[]'::jsonb")`) | — | `025:106`–`111` |
| 7 | `reuse_count` | `INTEGER` | NO | `0` (`server_default="0"`) | — | `025:112` |
| 8 | `content` | `JSONB` | YES | — | — | `025:113` |
| 9 | `created_at` | `TIMESTAMP WITH TIME ZONE` | NO | `now()` | — | `025:114`–`119` |

**Indexes (025):**
- `ix_pattern_category` on `(category)` (`025:121`).
- `ix_pattern_wave_id` on `(wave_id)` (`025:122`).

**Unique constraints:** none — ⚠️ **`name` is NOT unique.** The reuse_count UPDATE matches by `name` only, so duplicate names ALL get incremented. **CHECK constraints:** none.

⚠️ **Insert writes `reuse_count` as a hard-coded literal `0`** (NOT a param) regardless of the column's server_default; it is later bumped by the separate `UPDATE pattern SET reuse_count = reuse_count + $delta WHERE name = $name` path (in-place additive increment for race-safety). Cross-ref: activities md `5481`–`5514`.

**`source_apps` JSONB shape:** JSON array of application-id strings (UUID strings). API read model `PatternDetail.source_apps: list[uuid.UUID]` (`governance.py:122`). Default `[]`.
**`content` JSONB shape:** free-form object (the extracted pattern body) — `dict` of arbitrary keys. API read model `PatternDetail.content: dict[str, Any] = {}` (`governance.py:124`). Written via `json.dumps(row["content"])` where extractor coerces non-dict → `{}`.

---

### 2.9 `health_check` — 5 columns (migration 025, `op.create_table` at `025:28`–`46`)

One portfolio-health snapshot per sweep. Append-only.

| # | Column | Type | Nullable | Default | FK | Added by |
|---|---|---|---|---|---|---|
| 1 | `id` | `UUID` | NO (PK) | `gen_random_uuid()` | — | `025:30` |
| 2 | `portfolio_id` | `UUID` | YES | — | — | `025:36` |
| 3 | `date` | `DATE` | NO | — | — | `025:37` |
| 4 | `health_index` | `NUMERIC(4,3)` | NO | — | — | `025:38` |
| 5 | `checks` | `JSONB` | NO | `'[]'::jsonb` (`sa.text("'[]'::jsonb")`) | — | `025:39` |
| 6 | `created_at` | `TIMESTAMP WITH TIME ZONE` | NO | `now()` | — | `025:40`–`45` |

(6 columns total — numbered 1–6 above; the heading "5 columns" counts non-audit business cols; full DDL emits 6 incl. `created_at`. Authoritative count: **6 columns**.)

**Indexes (025):** `ix_health_check_date` on `(date)` (`025:47`).
**Unique constraints:** none. **CHECK constraints:** none.
⚠️ `health_index` is `NUMERIC(4,3)` NOT NULL — so values are 0.000–9.999 precision; the API read model constrains `0 ≤ health_index ≤ 1` (`governance.py:93`) but the **DB does not** (no CHECK). The extractor skips the row entirely (returns `None`, no sentinel insert) when the artifact's index is non-numeric — so the NOT-NULL is never violated. ⚠️ Extractor uses `idx = artifact.get("portfolio_health_index") or artifact.get("health_index")` — a literal `0.0` is falsy and falls through (edge case, preserve `or` semantics). Cross-ref: activities md `5196`–`5198`.

**`checks` JSONB shape:** JSON array of per-dimension finding objects, e.g.:
```json
[
  { "dimension": "<string>", "status": "<string>", "...": "arbitrary finding keys" }
]
```
Sourced from `artifact["per_dimension_findings"] or artifact["checks"] or []`. API read model `HealthCheck.checks: list[dict[str, Any]] = []` (`governance.py:95`). Default `[]`. (Note: API model also exposes an `alerts` field but the DB table has NO `alerts` column — it is a read-time derivation.)

---

### 2.10 `factory_capacity_plan` — 12 columns (migration 038, `op.create_table` at `038:47`–`76`)

One row per sweep; the concurrent-wave-max recommendation + compound-growth metrics. Rationalization reads the most recent row when planning waves. Append-only.

| # | Column | Type | Nullable | Default | FK | Added by |
|---|---|---|---|---|---|---|
| 1 | `id` | `UUID` | NO (PK) | `gen_random_uuid()` | — | `038:49` |
| 2 | `portfolio_id` | `UUID` | **YES** | — | — | `038:55` |
| 3 | `sweep_id` | `VARCHAR(255)` | NO | — | — | `038:56` |
| 4 | `concurrent_wave_max` | `INTEGER` | YES | — | — | `038:57` |
| 5 | `throughput_apps_per_month` | `NUMERIC(10,2)` | YES | — | — | `038:58`–`60` |
| 6 | `cost_per_app_usd` | `NUMERIC(12,2)` | YES | — | — | `038:61` |
| 7 | `gate_first_pass_rate` | `NUMERIC(5,4)` | YES | — | — | `038:62` |
| 8 | `ralph_loop_iteration_avg` | `NUMERIC(6,2)` | YES | — | — | `038:63`–`65` |
| 9 | `escalation_rate` | `NUMERIC(5,4)` | YES | — | — | `038:66` |
| 10 | `pattern_reuse_rate` | `NUMERIC(5,4)` | YES | — | — | `038:67` |
| 11 | `automation_ratio` | `NUMERIC(5,4)` | YES | — | — | `038:68` |
| 12 | `time_to_modernize_days` | `NUMERIC(8,2)` | YES | — | — | `038:69` |
| 13 | `computed_at` | `TIMESTAMP WITH TIME ZONE` | NO | `now()` | — | `038:70`–`75` |

(13 columns total incl. `computed_at`; "12" counts the id+12 fields heading loosely — authoritative count: **13 columns**.)

**Indexes (038):**
- `ix_factory_capacity_plan_portfolio_id` on `(portfolio_id)` (`038:77`, `unique=False`).
- `ix_factory_capacity_plan_computed_at` on `(computed_at)` (`038:83`, `unique=False`).

**Unique constraints:** none. **CHECK constraints:** none. **FKs:** none.
⚠️ `portfolio_id` is **nullable** here (contrast the sustainment tables where it's NOT NULL). The activity always writes it (resolved `portfolio_uuid`), but the schema permits NULL. ⚠️ `concurrent_wave_max` is the ONLY field the extractor int-coerces; all other scalars are float-coerced — the column types reflect this (`INTEGER` vs `NUMERIC`). Cross-ref: activities md `5231`–`5234`, `5538`.

---

### 2.11 `model_benchmark_result` — 11 columns (migration 038, `op.create_table` at `038:91`–`125`)

One row per `(model_id, task_suite)` pair per sweep. **Populated on QUARTERLY sweeps ONLY.** Orchestration reads the most recent rows for skill-to-model routing. Append-only.

| # | Column | Type | Nullable | Default | FK | Added by |
|---|---|---|---|---|---|---|
| 1 | `id` | `UUID` | NO (PK) | `gen_random_uuid()` | — | `038:93` |
| 2 | `portfolio_id` | `UUID` | **YES** | — | — | `038:99` |
| 3 | `sweep_id` | `VARCHAR(255)` | NO | — | — | `038:100` |
| 4 | `model_id` | `VARCHAR(255)` | NO | — | — | `038:101` |
| 5 | `tier` | `VARCHAR(20)` | NO | — | — | `038:102` |
| 6 | `task_suite` | `VARCHAR(255)` | NO | — | — | `038:103` |
| 7 | `pass_rate` | `NUMERIC(5,4)` | YES | — | — | `038:104` |
| 8 | `cost_per_call_usd` | `NUMERIC(12,6)` | YES | — | — | `038:105` |
| 9 | `latency_p95_ms` | `INTEGER` | YES | — | — | `038:106` |
| 10 | `regression_flag` | `BOOLEAN` | NO | `false` (`sa.text("false")`) | — | `038:107`–`112` |
| 11 | `refresh_recommended` | `BOOLEAN` | NO | `false` (`sa.text("false")`) | — | `038:113`–`118` |
| 12 | `benchmarked_at` | `TIMESTAMP WITH TIME ZONE` | NO | `now()` | — | `038:119`–`124` |

(12 columns total incl. `benchmarked_at`; authoritative count: **12 columns**.)

**Indexes (038):**
- `ix_model_benchmark_result_portfolio_id` on `(portfolio_id)` (`038:126`).
- `ix_model_benchmark_result_model_id` on `(model_id)` (`038:132`).
- `ix_model_benchmark_result_benchmarked_at` on `(benchmarked_at)` (`038:138`).

**Unique constraints:** none. **CHECK constraints:** none. ⚠️ `tier` is whitelisted only in Python (`_MODEL_TIERS = {"Tier-1","Tier-2","Tier-3"}`); invalid-tier rows are SKIPPED by the extractor (logged + `continue`), never inserted. No DB CHECK; `tier` is `VARCHAR(20)`. Cross-ref: activities md `5085`, `5263`–`5297`.
⚠️ `portfolio_id` nullable (same as `factory_capacity_plan`).

---

## 3. Cascade audit (mass-delete risk)

All FKs target `application.id`. Deleting an `application` row triggers:

| Table | FK column | ON DELETE | Effect on app delete |
|---|---|---|---|
| `sla_compliance_record` | `app_id` (NOT NULL) | **CASCADE** | ⚠️ **all rows for that app DELETED** |
| `cost_anomaly_record` | `app_id` (NOT NULL) | **CASCADE** | ⚠️ **all rows for that app DELETED** |
| `do_not_modify_flag` | `app_id` (NOT NULL) | **CASCADE** | ⚠️ **the flag for that app DELETED** |
| `drift_alert` | `application_id` (nullable) | **CASCADE** | ⚠️ **all alerts for that app DELETED** |
| `incident_log` | `app_id` (nullable) | **SET NULL** | rows retained, `app_id` → NULL (orphaned-but-kept) |
| `sustainment_override_log` | `app_id` (nullable) | **SET NULL** | rows retained, `app_id` → NULL |

`patching_compliance`, `pattern`, `factory_capacity_plan`, `health_check`, `model_benchmark_result` have **no FK** → unaffected by application deletion. `portfolio_id` / `sweep_id` / `wave_id` are bare columns (no FK) on every table → deleting a portfolio/wave row (if such tables exist) does NOT cascade here.

⚠️ **Rebuild must preserve the exact CASCADE vs SET NULL split per column** — it is intentional: history-of-record tables (`incident_log`, `sustainment_override_log`) keep their audit rows on app deletion (SET NULL), while current-state/metrics tables (`sla`, `cost`, `do_not_modify`, `drift`) cascade away.

---

## 4. Nullable-with-no-default surprises

Columns that are `NOT NULL` but have **no server default** (the writer MUST supply a value — a bare INSERT omitting them fails):

- `portfolio_id` (all sustainment tables + `drift_alert.type` etc.) — NOT NULL, no default.
- `sweep_id` (every sweep table) — NOT NULL, no default; supplied as `input.schedule_id`.
- `incident_log.severity`, `incident_log.status` — NOT NULL, no default (writer supplies `"unknown"`/`"open"` fallbacks in Python, NOT DB).
- `sla_compliance_record.app_id`, `cost_anomaly_record.app_id`, `do_not_modify_flag.app_id` — NOT NULL FK, no default (writer `continue`s the row if app_id empty, so it never inserts a NULL).
- `sustainment_override_log.override_by`, `sustainment_override_log.override_type` — NOT NULL, no default.
- `drift_alert.type` — NOT NULL, no default.
- `pattern.name`, `pattern.category` — NOT NULL, no default.
- `health_check.date`, `health_check.health_index` — NOT NULL, no default.
- `factory_capacity_plan.sweep_id`, `model_benchmark_result.{sweep_id,model_id,tier,task_suite}` — NOT NULL, no default.

⚠️ `boolean` NOT NULL columns DO have server defaults (`flagged`/`acknowledged`/`regression_flag`/`refresh_recommended` → `false`; `active` → `true`), and integer counters default `0` (`breach_count`, `*_open_count`, `override_count`, `pattern.reuse_count`) — so those CAN be omitted from an INSERT. The `*_at` timestamps default `now()`. The writer nonetheless explicitly passes most of these.

---

## 5. Git-as-source-of-truth → DB projection model

**Principle (DECISION-004 / CLAUDE.md "Git is source of truth"):** these 11 tables are a **derived, disposable query layer**. The authoritative artifacts are JSON files committed to Git by the sustainment/governance cron workflows; the rows here are a projection produced by two best-effort activities so dashboards/APIs can query without re-reading Git. Dropping and rebuilding these tables loses no source-of-record data (it is re-derivable by replaying sweeps, though historical sweep rows are not auto-backfilled).

### 5.1 The two projection activities

Both live in `temporal/olympus_workflows/activities/line_transitions.py` and are documented atomically in `regen/03b-activities/line_transitions-5-sustainment-governance.md`.

| Activity | Source line | Tables written | Cross-ref |
|---|---|---|---|
| `persist_sustainment_sweep_side_effects` | `4747` (decorator `4746`) | `patching_compliance`, `incident_log`, `sla_compliance_record`, `do_not_modify_flag` (UPSERT), `cost_anomaly_record`, `sustainment_override_log`, + `application` (2 lifecycle cols UPDATE) | activities md §2, lines `95`–`425` |
| `persist_governance_sweep_side_effects` | `5362` (decorator `5361`) | `drift_alert`, `pattern` (INSERT + reuse_count UPDATE), `health_check`, `factory_capacity_plan`, `model_benchmark_result` | activities md §3, lines `429`–`686` |

### 5.2 Projection mechanics (both activities)

1. **Input** is a dataclass carrying `portfolio_id`, `schedule_id` (→ `sweep_id`), and one **raw JSON string per artifact** (the Git-committed sweep artifact contents passed in by the workflow), e.g. sustainment: `cve_triage_json` → `patching_compliance`, `incident_response_json` → `incident_log`, `sla_monitoring_json` → `sla_compliance_record`, `change_conflict_json` → `do_not_modify_flag`, `cost_anomaly_json` → `cost_anomaly_record`, plus an `override_decisions: list[dict]` (signal list, NOT a parsed artifact) → `sustainment_override_log`. Governance: `drift_detection_json`, `pattern_extraction_json`, `health_report_json`, `factory_capacity_json`, `model_evaluation_json`, plus `pattern_reuse_acks: list[dict]` → reuse_count UPDATE. (Full field lists: activities md `100`–`131` and `439`–`453`.)
2. Each artifact string is parsed by `_try_parse_json(...)` (unparseable → empty → contributes no rows).
3. **Pure extractor helpers** (one per table) map the artifact JSON → list[dict] (or dict|None) of column-value rows, applying key-fallbacks, type-coercion, whitelist filters, and per-row skip rules. These are the canonical column derivations — reproduce EXACTLY (activities md §2.6 `266`–`331`, §3.6 `546`–`605`).
4. **Empty short-circuit:** if NO extractor produced anything, the activity logs "nothing extractable", emits a code-step complete with `columns_written=[]`, and returns a zero-count result **without opening a DB connection** (activities md `164`/`481`).
5. Otherwise: `conn = await asyncpg.connect(_db_url())`; **one `async with conn.transaction():`** wraps ALL writes for that activity; `finally: conn.close()`. Single transaction → full-projection-or-nothing (no partial commit). The cron workflow **swallows** any exception so the sweep-summary.json commit still proceeds (best-effort projection).
6. Result dataclass carries per-table row counts (field names must match exactly — see activities md `127`–`135`, `456`–`468`).

### 5.3 What is committed to Git vs projected to DB

| Git artifact (source of truth) | → DB projection table | Extractor (activities md) |
|---|---|---|
| CVE/patch triage sweep artifact | `patching_compliance` (1 row, or skipped if all-zero & null pct) | `_extract_patching_compliance_row` (`4382`) |
| incident-response artifact `incidents[]`/`processed_incidents[]` | `incident_log` (1 row/incident) | `_extract_incident_log_rows` (`4447`) |
| SLA-monitoring artifact `apps[]`/`measurements[]`/`sla_records[]` | `sla_compliance_record` (1 row/app w/ app_id) | `_extract_sla_compliance_rows` (`4493`) |
| change-conflict artifact `do_not_modify_flags[]`/`flags[]` | `do_not_modify_flag` (UPSERT/app) | `_extract_do_not_modify_rows` (`4558`) |
| cost-anomaly artifact `anomalies[]`/`apps[]`/`findings[]` | `cost_anomaly_record` (1 row/app w/ app_id) | `_extract_cost_anomaly_rows` (`4606`) |
| `override_approved` signal list | `sustainment_override_log` (1 row/decision) | `_extract_sustainment_override_log_rows` (`4656`) |
| derived from above rows (status ladder) | `application.sustainment_current_status` / `_last_sweep_at` | `_extract_application_lifecycle_updates` (`4682`) |
| drift-detection artifact `alerts[]` | `drift_alert` (1 row/valid alert; severity→details) | `_extract_drift_alert_side_effects` (`5092`) |
| pattern-extraction artifact `patterns[]` | `pattern` (1 row/valid pattern, reuse_count=0) | `_extract_pattern_side_effects` (`5147`) |
| `pattern_reuse_acks` list | `pattern.reuse_count` += delta WHERE name | `_apply_pattern_reuse_count_updates` (`5335`) |
| health-report artifact `portfolio_health_index`+`per_dimension_findings`/`checks` | `health_check` (1 row, or skipped if non-numeric index) | `_extract_health_check_side_effects` (`5196`) |
| factory-capacity artifact (9 scalar metrics) | `factory_capacity_plan` (1 row, or skipped if no numeric scalar) | `_extract_factory_capacity_side_effects` (`5231`) |
| model-evaluation artifact `results[]` (QUARTERLY only) | `model_benchmark_result` (1 row/(model,suite)) | `_extract_model_benchmark_side_effects` (`5263`) |

### 5.4 JSONB column write idioms (reproduce exactly)

- `drift_alert.details` = `json.dumps({"severity": <whitelisted severity>, **(artifact_details or {})})` bound as `$3::jsonb` (activities md `499`). Severity is folded in here — there is NO severity column.
- `pattern.source_apps` = `json.dumps(row["source_apps"])` (list, default `[]`) bound `$5::jsonb`; `pattern.content` = `json.dumps(row["content"])` (dict, default `{}`) bound `$6::jsonb` (activities md `508`).
- `health_check.checks` = `json.dumps(health_row["checks"])` (list, default `[]`) bound `$4::jsonb` (activities md `522`).

### 5.5 `application` lifecycle UPDATE (sustainment only)

The sustainment activity additionally issues a per-app dynamic `UPDATE application SET [sustainment_current_status = $n,] sustainment_last_sweep_at = $n, updated_at = $n WHERE id = $n` (activities md `243`–`264`). `sustainment_current_status` is set ONLY when the status ladder assigned the app a status (`attention-required` sticky-wins over `monitoring`); `sustainment_last_sweep_at` and `updated_at` are always written. `app_updates_applied` counts only command tags ending in `" 1"`. These two `application` columns were added by the same migration `037:345`–`360` (both `nullable=True`, no default). `application.updated_at` is the pre-existing NOT-NULL col from `002:55`.

---

## 6. Verbatim DDL reconstruction notes

To rebuild these 11 tables byte-faithfully:
- Emit migration `025` (health_check, drift_alert, pattern) with `down_revision="024"`.
- Emit migration `037` (6 sustainment tables + 2 `application` columns) with `down_revision="036"`.
- Emit migration `038` (factory_capacity_plan, model_benchmark_result) with `down_revision="033"` (it branches off 033, NOT 037).
- Emit the no-op merge `039` with `down_revision=("034","035","037","038")`.
- All `UUID` columns are `from sqlalchemy.dialects.postgresql import UUID` with `UUID(as_uuid=True)`.
- All `JSONB` columns are `from sqlalchemy.dialects.postgresql import JSONB`.
- Timestamp columns: 037 uses `sa.TIMESTAMP(timezone=True)`; 025 and 038 use `sa.DateTime(timezone=True)` — both render to `TIMESTAMP WITH TIME ZONE` in PostgreSQL (functionally identical; preserve the source spelling per migration for diff-parity).
- `server_default` for integer counters in 037/025 is the bare string `"0"`; for booleans/uuid/now it is `sa.text("...")`. Preserve which form each column uses (see per-column tables above).
- Partial indexes use `postgresql_where=sa.text("...")` — three exist: `ix_incident_log_app` (`app_id IS NOT NULL`), `ix_do_not_modify_flag_active` (`active = true`), `ix_cost_anomaly_flagged` (`flagged = true`).
- Add NO CHECK constraints. Add NO unique constraint except `uq_do_not_modify_flag_portfolio_app` on `do_not_modify_flag(portfolio_id, app_id)`.

---

## 7. Seeds

**None.** All three migrations (025, 037, 038) are explicitly **DDL-only, no seed data**, per the migration-seeding separation rule (`025:8`, `037:43`, `038:7`). There are no fixture/seed inserts for any of these 11 tables in any migration. Rows are produced exclusively at runtime by the two projection activities during sustainment/governance cron sweeps.
