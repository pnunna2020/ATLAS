# 08 — Build, CI & Anti-Drift Gates (ATOMIC REGEN SPEC)

Source of truth for this document: `.github/workflows/*.yml` (5 files), the seven per-package
`pyproject.toml` files, `dashboard/package.json` + `dashboard/vitest.config.ts` +
`dashboard/eslint.config.js` + `dashboard/tsconfig.json`, `Makefile`, `schemas/validate.sh`,
`scripts/validate_*.py` / `scripts/verify_*.py` / `scripts/check_doc_sync.py`, and the anti-drift
test modules. Every claim cites `path:line`.

> **⚠️ TOP-LEVEL GOTCHA — COVERAGE FLOORS IN THE TASK PROMPT AND `CLAUDE.md` ARE WRONG.**
> The authoritative floors are the `--cov-fail-under=` values in each `pyproject.toml`. The
> regen prompt and `CLAUDE.md` disagree with the on-disk truth in **four** places. The table in
> §2 is derived from a direct `grep -rn 'cov-fail-under'` and is the binding spec. When
> regenerating, reproduce the `pyproject` numbers below, NOT the prose.

---

## 0. Inventory of CI / build artifacts

| File | Bytes | Purpose |
|---|---|---|
| `.github/workflows/ci.yml` | 48799 | Main CI pipeline — preflight path-classification + ~20 gated jobs |
| `.github/workflows/deploy.yml` | 11022 | EKS Helm deploy (dev auto, staging promote, prod dispatch-only) |
| `.github/workflows/branch-protection-sync.yml` | 3117 | Reconcile `main` branch protection from declarative policy |
| `.github/workflows/pages-publish-traceability.yml` | 1996 | Regenerate `traceability/traceability.json` on push to main |
| `.github/workflows/traceability-check.yml` | 3277 | PR-time traceability appendix diff signals (advisory) |
| `.github/branch-protection.yml` | 1032 | Declarative branch-protection policy (consumed by sync workflow) |
| `.gitleaks.toml` | 2032 | gitleaks config used by the Secrets Scan job |
| `Makefile` | — | `validate-schemas`, `validate-objectives`, `check-docs`, `demo-*` targets |
| `schemas/validate.sh` | — | Bash metaschema/shape validator invoked by `make validate-schemas` |

Per-package build config (build-backend = `setuptools.build_meta`, `requires=["setuptools>=68.0","wheel"]` for every Python package):

| Package | `pyproject.toml` | requires-python | ruff target | Notes |
|---|---|---|---|---|
| `olympus-api` | present | `>=3.13` | `py313` | depends on private `foundry-temporal>=1.3.0` |
| `olympus-worker` | present | `>=3.13` | `py313` | depends on `olympus-workflows`, `foundry-temporal` |
| `olympus-agent-runtime` | present | `>=3.13` | `py313` | optional extras: `agent`, `openai`, `all-providers` |
| `mcp-server` (pkg `olympus-mcp`) | present | `>=3.11` | (no `[tool.ruff]`) | console script `olympus-mcp` |
| `temporal` (pkg `olympus-workflows`) | present | `>=3.11` | `py311` | dev extra includes `pytest-xdist>=3.5` |
| `olympus-contracts` | present | `>=3.11` | `py311` | v0.4.0; ships `data/assembly-lines/*.yaml` as package-data |
| `olympus-cli` | present | `>=3.11` | `py311` | console script `olympus`; `addopts="-q"` (NO coverage) |
| `dashboard` (`olympus-dashboard`) | `package.json` | node 20/22 | eslint flat | vitest + playwright |

---

## 1. `ci.yml` — full job graph (the big one)

`name: CI`. **Triggers** (`ci.yml:3-13`):
- `pull_request` → branches `[main]`
- `push` → branches `[main]`
- `schedule` → `cron: "0 7 * * *"` (nightly 07:00 UTC ≈ 03:00 ET) — runs the full heavy-scan suite

**Concurrency** (`ci.yml:17-19`): group `ci-${{ github.workflow }}-${{ PR number || ref }}`;
`cancel-in-progress` only on `pull_request` (push-to-main runs keyed on `github.sha` never cancel
each other).

**Permissions** (`ci.yml:21-24`): `contents: read`, `pull-requests: read`.

### 1.1 Job graph (job → `needs` → gate → purpose)

```
preflight ──┬─> contracts                 (if contracts_changed)
            ├─> skill-catalog             (if skill_catalog_changed)
            ├─> doc-sync                  (if doc_sync_changed)
            ├─> agency-objectives         (if objectives_changed)
            ├─> step-registry-consistency (if step_registry_changed)
            ├─> sql-schema-drift          (if sql_schema_changed)
            ├─> line-contracts-consistency(if line_contracts_changed)
            ├─> profile-portability       (if api||temporal||contracts_pkg changed)
            ├─> stack-spin-smoke          (if stack_spin_changed)
            ├─> python (5-leg matrix)     (if python_any_changed; per-leg 2nd gate)
            ├─> python-integration        (if api_changed)
            ├─> frontend                  (if dashboard_changed)
            ├─> helm-lint (8-chart matrix)(if helm_changed || push || schedule)
            ├─> terraform-validate (16x)  (if terraform_changed || push || schedule)
            └─> kubeval-argocd            (if argocd_changed || push || schedule)

branch-naming      (if event==pull_request)        — NO needs
secrets-scan       (always)                         — NO needs
codeql (2x)        (if push || schedule)            — NO needs
trivy-fs           (if push || schedule)            — NO needs
sbom               (if push || schedule)            — NO needs, continue-on-error
trivy-image (4x)   (if push || schedule)            — NO needs, continue-on-error
```

`branch-naming`, `secrets-scan`, `codeql`, `trivy-fs`, `sbom`, `trivy-image` do **not** `needs: preflight`
— they run independently of path classification. Everything else depends on `preflight`.

⚠️ GOTCHA: There is **no** `build-push` job — it is commented out (`ci.yml:1208-1220`): "DISABLED
until the deployment pipeline is wired up end-to-end." So `branch-protection.yml`'s required
context `build` (see §6) currently maps to a non-existent job.

### 1.2 `preflight` — path classification (`ci.yml:33-241`)

`runs-on: ubuntu-latest`. Checks out with `fetch-depth: 0` (`ci.yml:59-61`). One step `id: classify`
sets **21 boolean outputs** (`ci.yml:36-57`):
`docs_only, run_all, contracts_changed, skill_catalog_changed, objectives_changed, doc_sync_changed,
step_registry_changed, sql_schema_changed, line_contracts_changed, api_changed, worker_changed,
agent_runtime_changed, mcp_changed, temporal_changed, contracts_pkg_changed, dashboard_changed,
helm_changed, terraform_changed, argocd_changed, python_any_changed, stack_spin_changed`.

Classification logic (`ci.yml:71-241`), in order:
1. **Force-full on `schedule` or `push`** (`ci.yml:78-94`): every output → `true`, `run_all=true`,
   `docs_only=false`. The fast-lane (diff-based gating) applies **only to PRs**.
2. **Resolve BASE/HEAD** (`ci.yml:96-103`): PR uses `pull_request.base.sha`..`head.sha`; otherwise
   `github.event.before`..`github.sha`. If BASE is all-zeros/empty → `git merge-base origin/main HEAD`.
3. **No base resolvable** (`ci.yml:104-123`): `::warning::` + force full CI (safe fallback).
4. `CHANGED = git diff --name-only BASE HEAD` (`ci.yml:125`).
5. **docs_only** (`ci.yml:129-136`): true iff every changed path is `*.md`/`*.mdx` OR under
   `specifications/ docs/ reference/ .claude/ .agents/`.
6. **Workflow change force-full** (`ci.yml:138-157`): any change under `.github/workflows/` →
   all outputs `true`. ⚠️ This is why editing `ci.yml` itself triggers the entire matrix.
7. `match()` helper (`ci.yml:160-166`): grep -Eq path regex → `true`/`false`.

Per-surface regexes (`ci.yml:168-186`):
| Output | Regex (path prefix patterns) |
|---|---|
| `contracts_changed` | `^schemas/`, `^specifications/api/`, `^olympus-contracts/` |
| `skill_catalog_changed` | `^cross-cutting/skills/`, `scripts/validate_skill_registry.py`, `tests/test_validate_skill_registry.py` |
| `objectives_changed` | `profiles/*/objectives.yaml`, `schemas/profiles/objectives.schema.json`, `schemas/cross-cutting/metric.schema.json`, `scripts/validate_objectives.py`, `tests/test_validate_objectives.py`, `cross-cutting/*.ya?ml`, `assembly-lines/*.ya?ml` |
| `doc_sync_changed` | `README.md`, `CLAUDE.md`, `reference/terminology.md`, `cross-cutting/extensibility/README.md`, `cross-cutting/skills/registry.yaml`, `olympus-contracts/olympus_contracts/enums.py`, `presentation/`, `scripts/check_doc_sync.py`, `tests/test_check_doc_sync.py` |
| `step_registry_changed` | `olympus-api/src/services/step_mapping/`, `dashboard/src/*step*`, `scripts/verify_step_registry.py`, `specifications/phase-5/assembly-line-contracts/` |
| `sql_schema_changed` | `db/alembic/`, `olympus-api/src/`, `scripts/verify_sql_schema.py`, `tests/test_verify_sql_schema.py` |
| `line_contracts_changed` | `specifications/phase-5/assembly-line-contracts/`, `dashboard/scripts/parse-line-contracts.mjs`, `dashboard/package-lock.json` |
| `api/worker/agent_runtime/mcp/temporal/contracts_pkg/dashboard_changed` | `^olympus-api/` / `^olympus-worker/` / `^olympus-agent-runtime/` / `^mcp-server/` / `^temporal/` / `^olympus-contracts/` / `^dashboard/` |
| `helm/terraform/argocd_changed` | `^infra/helm/` / `^infra/terraform/` / `^infra/argocd/` |

**Shared-Python fan-out** (`ci.yml:192-199`): if any of `olympus-contracts/`, `tests/`, `scripts/`,
`pyproject.toml`, `requirements*.txt`, `.pre-commit-config.yaml` changed → force `api/worker/
agent_runtime/mcp/temporal _changed = true` (consumed transitively by every package).
`python_any_changed` (`ci.yml:201-207`) = OR of api/worker/agent_runtime/mcp/temporal/contracts_pkg.

**stack_spin_changed** (`ci.yml:209-214`): the 4 runtime packages + `temporal/` + `olympus-contracts/`
+ `docker-compose.ya?ml` + `db/` + `scripts/seed_*.py` + `scripts/seed_all.py` +
`scripts/seed_service_tokens.py` + `scripts/demo_smoke.py` + `Makefile` + any `*/Dockerfile`.

### 1.3 `branch-naming` (`ci.yml:243-257`)
`if: github.event_name == 'pull_request'`. One step asserts `github.head_ref` matches
`^(phase-[0-9][a-z]|feat|fix|refactor|docs|ci|chore|dependabot|integration)/` (`ci.yml:251`).
On failure: `::error::` + `exit 1`. **This is the branch-naming gate** referenced by `CLAUDE.md`.

### 1.4 `contracts` — Validate Contracts (`ci.yml:259-341`)
Gate: `contracts_changed`. Node 22 + Python 3.13. Steps:
- **OpenAPI lint** (`ci.yml:276-278`): `npx @redocly/cli lint specifications/api/openapi.yaml`
  (only if file exists via `hashFiles`).
- **OpenAPI bundle + re-lint** (`ci.yml:280-284`): bundle → `openapi.bundled.yaml` → lint the output.
- **JSON-schema metaschema** (`ci.yml:286-297`): `pip install check-jsonschema jsonschema`; loop
  `schemas/**/*.schema.json` → `check-jsonschema --check-metaschema "$schema"`.
- **Sample artifacts** (`ci.yml:299-341`): inline Python builds a `$id`-keyed schema store from all
  `*.schema.json`, then validates each `schemas/samples/*.json` against its `$schema`-referenced
  schema with `Draft202012Validator` + `RefResolver`. Exit 1 on any error.

### 1.5 `skill-catalog` — Skill Catalog Consistency (`ci.yml:343-360`)
Gate: `skill_catalog_changed`. Python 3.13 + `pip install pyyaml`. Runs
`python3 scripts/validate_skill_registry.py` (see §5.1 — 10 invariants).

### 1.6 `doc-sync` — Doc / Reality Sync (`ci.yml:362-388`)
Gate: `doc_sync_changed`. Python 3.13 + `pip install pyyaml pytest`. Two steps:
`python3 scripts/check_doc_sync.py` then `pytest tests/test_check_doc_sync.py -v`. Guards the
"~65 → 137 → 167 skills" drift (`ci.yml:362-368`; see §5.4).

### 1.7 `agency-objectives` — Agency Objectives Consistency (`ci.yml:390-414`)
Gate: `objectives_changed`. Python 3.13 + `pip install pyyaml jsonschema pytest`. Runs
`python3 scripts/validate_objectives.py` then `pytest tests/test_validate_objectives.py -v`
(see §5.2 — 7 invariants). Phase AO-0 contract check.

### 1.8 `step-registry-consistency` (`ci.yml:416-433`)
Gate: `step_registry_changed`. Python 3.13 + `pip install -e olympus-contracts`. Runs
`python3 scripts/verify_step_registry.py` — verifies the frontend `stepRegistry.ts` ↔ backend
`step_mapping.py` step IDs agree (see §5.5).

### 1.9 `sql-schema-drift` (`ci.yml:435-455`)
Gate: `sql_schema_changed`. Python 3.13 + `pip install pytest`. Runs
`python3 scripts/verify_sql_schema.py` then `pytest tests/test_verify_sql_schema.py -v` — static
analyzer comparing raw `text("…")` SQL in `olympus-api/src/` against the alembic schema replay
(no DB). Catches the `actual_start`/`updated_at` Date-vs-DateTime bind bug (see §5.6).

### 1.10 `line-contracts-consistency` (`ci.yml:457-476`)
Gate: `line_contracts_changed`. Node 22 + `npm ci` in `dashboard/`. Runs
`node dashboard/scripts/parse-line-contracts.mjs --validate-only` — projects the authoritative
yaml line contracts (`olympus-contracts/.../data/assembly-lines/*.yaml`) into the dashboard JSON
shape and validates without writing (`--validate-only` flag at `parse-line-contracts.mjs:245`).

### 1.11 `profile-portability` (`ci.yml:478-512`)
Gate: `api_changed || temporal_changed || contracts_pkg_changed` (`ci.yml:482-485`). Python 3.13,
`working-directory: olympus-api`. Installs `olympus-contracts` + `temporal` + `olympus-api[dev]`
(editable) using `PIP_EXTRA_INDEX_URL` = the private jfrog Artifactory index (`ci.yml:502`). Runs
`pytest tests/test_generic_profile_portability.py -v --no-cov` with `AGENT_RUNTIME_MODE=mock`,
`APP_ENV=test`. Capstone acceptance test P4-S6.G5.6.

### 1.12 `stack-spin-smoke` (`ci.yml:514-599`)
Gate: `stack_spin_changed`. Boots the core stack via docker compose, seeds, asserts portfolio shape.
Env (`ci.yml:528-541`): `DATABASE_HOST=localhost DATABASE_PORT=5432 DATABASE_USER=olympus
DATABASE_PASSWORD=olympus_dev DATABASE_NAME=olympus API_URL=http://localhost:8000
JWT_SECRET=olympus-ci-smoke-secret AGENT_RUNTIME_MODE=mock DEMO_PORTFOLIO_NAME="Test Portfolio 4"
READY_RETRIES=90 READY_INTERVAL=4`. Steps:
1. `pip install -e ./olympus-contracts` + `python-jose[cryptography]>=3.3.0 pydantic>=2.0,<3.0
   asyncpg>=0.29.0 PyYAML>=6.0,<7.0` (`ci.yml:550-566`). ⚠️ GOTCHA: deliberately does NOT
   `pip install -e ./olympus-api` — that pulls `foundry-temporal` from a private index this job
   doesn't wire (`ci.yml:559-563`).
2. `python3 scripts/seed_service_tokens.py` (mint tokens).
3. `docker compose --env-file .service-tokens.env up -d --build --scale olympus-agent-runtime=1
   postgres db-migrate temporal-server temporal-namespace-init redis olympus-api
   olympus-temporal-worker olympus-agent-runtime` (`ci.yml:571-582`).
4. `make demo-wait` (poll readiness), `python3 scripts/seed_all.py --reset`,
   `python3 scripts/demo_smoke.py`.
5. `if: failure()` → `docker compose logs --tail=200`; `if: always()` → `docker compose down -v`.

### 1.13 `python` — 5-leg matrix (`ci.yml:601-730`)
Job gate: `python_any_changed`. `strategy.fail-fast: false`. Matrix legs (`ci.yml:620-640`):

| package | `cov_source` | python_version | flag |
|---|---|---|---|
| `olympus-api` | `src` | 3.13 | `api_changed` |
| `temporal` | `olympus_workflows` | **3.12** | `temporal_changed` |
| `olympus-agent-runtime` | `src` | 3.13 | `agent_runtime_changed` |
| `olympus-worker` | `src` | 3.13 | `worker_changed` |
| `mcp-server` | `olympus_mcp` | **3.12** | `mcp_changed` |

`working-directory: ${{ matrix.package }}` (`ci.yml:641-643`). Steps:
- **Second gate** `id: gate` (`ci.yml:647-658`): maps `matrix.flag` to the preflight output; sets
  `steps.gate.outputs.skip`. Every later step is `if: steps.gate.outputs.skip == 'false'` — so a
  temporal-only PR still skips api/worker/agent-runtime/mcp legs even though the job ran.
- **Install** (`ci.yml:666-688`): editable `olympus-contracts` + `temporal`, then
  `./${matrix.package}[dev]` + `ruff`, with `PIP_EXTRA_INDEX_URL` = private jfrog index.
  ⚠️ For the `temporal` leg only: also `pip install -e ./olympus-worker --ignore-requires-python`
  and `pip install -e ./olympus-api --ignore-requires-python` (`ci.yml:679-686`) — the temporal
  harness imports `src.agent_registry` / `src.testing.mock_agent_runtime` from the worker and
  bundle modules from the api; the worker/api pin `>=3.13` but this leg runs 3.12, so
  `--ignore-requires-python` is required.
- **Lint** (`ci.yml:690-692`): `ruff check .`
- **Test with coverage** (`ci.yml:694-723`): env `AGENT_RUNTIME_MODE=mock APP_ENV=test`. Runs
  `pytest $XDIST_FLAGS --cov=${cov_source} --cov-report=term-missing --cov-report=xml:coverage.xml
  --tb=short -q`. ⚠️ For `temporal` only `XDIST_FLAGS="-n 4"` (`ci.yml:714-717`) — each test spawns
  a fresh `WorkflowEnvironment` Rust sidecar; `-n 4` is pinned deliberately (`-n auto`
  over-subscribes and desyncs sidecars: "Expired workflow task: expectedHistorySize=3,
  actualHistorySize=7"). The `--cov-fail-under` floor comes from each package's `pyproject.toml`
  (the CLI `--cov` does not re-specify the floor — `addopts` supplies it). See §2.
- **Upload coverage** (`ci.yml:725-730`): artifact `coverage-${package}` → `coverage.xml`.

### 1.14 `python-integration` — olympus-api real-Postgres (`ci.yml:732-781`)
Gate: `api_changed`. `working-directory: olympus-api`. Service container `postgres:16` (user
`olympus`, pw `olympus_dev`, db `olympus`, port 5432, `pg_isready` healthcheck). Installs
`olympus-api[dev,integration]`. Lints `tests/integration/` then runs
`pytest tests/integration/ -v --no-cov --tb=short` with
`OLYMPUS_INTEGRATION_DATABASE_URL=postgresql://olympus:olympus_dev@localhost:5432/olympus
AGENT_RUNTIME_MODE=mock APP_ENV=test` (`ci.yml:776-781`). No coverage floor (integration is
`--no-cov`).

### 1.15 `frontend` — Frontend Checks (`ci.yml:783-820`)
Gate: `dashboard_changed`. `working-directory: dashboard`. **Node 20** (`ci.yml:794-798`; the
`line-contracts-consistency` and `contracts` jobs use Node 22 — version split). `npm ci`. Steps
(all `--if-present`): `npm run lint` (eslint), `npm run typecheck`, `npm run build`, then
`npx vitest run --coverage` (`ci.yml:813`). Coverage thresholds enforced by `vitest.config.ts`
(see §2 / §3.4). Uploads `coverage-dashboard` → `dashboard/coverage/`.
⚠️ `package.json` defines `lint` and `build` scripts but **no `typecheck` script** — the
`--if-present` flag makes `npm run typecheck` a silent no-op. `build` runs `tsc -b && vite build`
so type errors are still caught via the build step.

### 1.16 `secrets-scan` — Secrets Scan (`ci.yml:822-883`)
No `needs`, always runs. `fetch-depth: 0`. Caches `gitleaks` binary v8.21.2 (`ci.yml:839-844`).
- **PR fast-lane** (`ci.yml:861-869`): `gitleaks protect --source=. --config=.gitleaks.toml --redact
  --no-banner --log-opts="$BASE_SHA..$HEAD_SHA" --report-format=sarif --report-path=gitleaks.sarif`
  (diff-only).
- **push/nightly full history** (`ci.yml:871-875`): `gitleaks detect --source=. --config=.gitleaks.toml
  --redact --no-banner ...` (walks the entire log).
- Uploads `gitleaks-sarif` artifact (`if-no-files-found: ignore`). Config file: `.gitleaks.toml`.

### 1.17 `codeql` — 2-language matrix (`ci.yml:885-916`)
`if: push || schedule` (nightly/main only — not per-PR). `permissions: security-events: write`.
Matrix `language: [python, javascript]`. `codeql-action/init@v3` with `queries:
security-and-quality`, then `analyze@v3`. **Blocking** as of P6-S8.7 (advisory `continue-on-error`
removed).

### 1.18 `trivy-fs` — SCA filesystem (`ci.yml:918-984`)
`if: push || schedule`. Caches trivy v0.59.1. Install step is `continue-on-error: true` and sets
`installed=false` + `::warning::` if the download is unreachable (`ci.yml:938-957`) — the scan
steps are gated on `installed == 'true'`. The scan itself is **blocking**:
`trivy fs . --severity CRITICAL,HIGH --exit-code 1 --format sarif --output trivy-fs.sarif`
(`ci.yml:968-976`).

### 1.19 `sbom` — CycloneDX (`ci.yml:986-1049`)
`if: push || schedule`, `continue-on-error: true` (advisory). Generates `sbom.cdx.json` via
`trivy fs . --format cyclonedx`, uploads as 90-day artifact, and attaches to a GitHub Release on
`refs/tags/` (`softprops/action-gh-release@v2`).

### 1.20 `trivy-image` — 4-service container CVE matrix (`ci.yml:1051-1093`)
`if: push || schedule`, `continue-on-error: true` (advisory). Matrix `service: [olympus-api,
olympus-worker, olympus-agent-runtime, mcp-server]`. Builds `olympus/${service}:ci` from
`${service}/Dockerfile` then `aquasecurity/trivy-action@0.24.0` with `severity: CRITICAL,HIGH`,
`exit-code: "0"` (non-blocking). ⚠️ There is no standalone image-publish `build` job, so images
are built locally here (`ci.yml:1051-1056`).

### 1.21 `helm-lint` — 8-chart matrix (`ci.yml:1095-1141`)
Gate: `helm_changed || push || schedule`. Charts: `olympus-api, olympus-worker,
olympus-agent-runtime, olympus-mcp-server, olympus-dashboard, db-migrate, ingress, olympus-umbrella`.
`azure/setup-helm@v4` v3.14.0. For `olympus-umbrella`: `helm dependency update` first, then `helm
template` per `values-{dev,staging,prod}.yaml`. All charts: `helm lint` + `helm template > /dev/null`.

### 1.22 `terraform-validate` — 16-path matrix (`ci.yml:1143-1186`)
Gate: `terraform_changed || push || schedule`. `hashicorp/setup-terraform@v3` v1.7.5. Paths
(`ci.yml:1154-1170`): modules `vpc, eks, rds, redis, ecr, s3, secrets, gfi-mirror, dms,
dms-endpoint` + environments `dev, staging, prod, phase3-dms, dev-csn-fargate,
olympus-demo-fargate`. Each: `terraform fmt -check -recursive`, `init -backend=false`, `validate`.

### 1.23 `kubeval-argocd` (`ci.yml:1188-1206`)
Gate: `argocd_changed || push || schedule`. Python 3.13 + `pip install yamllint`. Runs
`yamllint -d '{extends: relaxed, rules: {line-length: disable, comments: disable, truthy: disable,
indentation: disable}}' infra/argocd/`.

---

## 2. Coverage floors — DEFINITIVE TABLE (binding spec)

Derived from `grep -rn 'cov-fail-under' --include=pyproject.toml` and `dashboard/vitest.config.ts`.

| Suite | Floor | Source (`path:line`) | Prompt/`CLAUDE.md` claim | Drift? |
|---|---|---|---|---|
| `olympus-api` | **87** | `olympus-api/pyproject.toml:80` (`--cov-fail-under=87`) | prompt & CLAUDE.md say **90** | ⚠️ **YES — prompt+CLAUDE wrong** |
| `olympus-worker` | **90** | `olympus-worker/pyproject.toml:39` | prompt says **87** | ⚠️ **YES — prompt wrong** |
| `olympus-agent-runtime` | **90** | `olympus-agent-runtime/pyproject.toml:58` | prompt says 90 | OK |
| `mcp-server` | **90** | `mcp-server/pyproject.toml:41` | prompt says 90 | OK |
| `temporal` | **78** | `temporal/pyproject.toml:115` | prompt says 78; **CLAUDE.md says 87** | ⚠️ **YES — CLAUDE.md wrong** |
| `dashboard` lines | **81** | `dashboard/vitest.config.ts:62` | prompt says 81 | OK |
| `dashboard` branches | **70** | `dashboard/vitest.config.ts:63` | prompt says 70 | OK |
| `dashboard` functions | **76** | `dashboard/vitest.config.ts:64` | prompt says 76 | OK |
| `dashboard` statements | **78** | `dashboard/vitest.config.ts:65` | prompt says **79** | ⚠️ **YES — prompt wrong** |
| `olympus-cli` | none | `olympus-cli/pyproject.toml:42` (`addopts="-q"`, no `--cov`) | n/a | (no coverage gate) |
| `olympus-contracts` | none | no `[tool.pytest.ini_options]` in `olympus-contracts/pyproject.toml` | n/a | (no coverage gate) |

**Net: 4 documented floors are wrong in the prose.** Authoritative = the `pyproject`/`vitest.config`
numbers above.

⚠️ **temporal floor history** (`temporal/pyproject.toml:54-115`): the inline comments record a long
descent `87 → 85 → 83 → 82 → 80 → 79 → 78`, each step annotated with the workstream that added
under-covered async workflow code the time-skipping harness can't drive in GitHub-hosted CI
(WaveArch, bundle factory, rat-cap clustering, line_transitions). This **violates the spirit** of
DECISION-017 ("floors only move up") — it is an explicitly documented, sanctioned exception staged
to be restored once a self-hosted runner with a pre-baked Temporal binary lands. The `addopts`
floor (78) is the only binding value; the comments are rationale.

⚠️ **dashboard statements** (`vitest.config.ts:58-60`): P5-S26 dropped statements `79 → 78` to match
main-branch drift (main CI was failing at ~78.89%). Same sanctioned-exception pattern.

**DECISION-017 rule** (`CLAUDE.md`, F8a/F8b): "Coverage floors only move up, never down. Lowering a
threshold to unblock a PR is not an option. CI fails the build if coverage drops below the floor."
The temporal + dashboard descents are the documented tension with this rule. The aspirational
targets are: api/worker/agent-runtime/mcp = **90**; temporal = **87** (hence CLAUDE.md's stale
number); dashboard = **90/80/85/90** (`vitest.config.ts:50-54`).

### Where each floor is enforced in CI
- Python floors: the `python` matrix `Test with coverage` step (`ci.yml:718-723`) runs `pytest
  --cov=<src>` and the `--cov-fail-under` in each package's `addopts` fails the leg.
- Dashboard: `frontend` job `npx vitest run --coverage` (`ci.yml:813`) → `vitest.config.ts`
  `coverage.thresholds` (`vitest.config.ts:61-66`).
- olympus-cli and olympus-contracts are **not** in the `python` matrix at all, so their suites only
  run when invoked directly / via the shared-Python fan-out installs; no coverage floor exists for
  either.

---

## 3. Lint / type configuration

### 3.1 Ruff (Python) — identical block in every Python package that defines it
`[tool.ruff] line-length = 100`; `[tool.ruff.lint] select = ["E", "F", "I", "W"]`
(E=pycodestyle errors, F=pyflakes, I=isort, W=pycodestyle warnings).
`target-version`: `py313` for api/worker/agent-runtime (`olympus-api/pyproject.toml:90-95`,
`olympus-worker/pyproject.toml:49-54`, `olympus-agent-runtime/pyproject.toml:48-53`); `py311` for
temporal/contracts/cli (`temporal/pyproject.toml:125-130`, `olympus-contracts/pyproject.toml:12-17`,
`olympus-cli/pyproject.toml:44-49`).
⚠️ `mcp-server/pyproject.toml` has **NO `[tool.ruff]` block** — ruff isn't configured there and the
`python` matrix `ruff check .` step (`ci.yml:692`) runs with ruff defaults for the mcp leg.
CI runs `ruff check .` per leg; integration job adds `ruff check tests/integration/` (`ci.yml:773-774`).
No mypy / pyright / pre-commit type-checking config is present anywhere in the Python tree.

### 3.2 ESLint (dashboard) — `dashboard/eslint.config.js` (flat config)
Extends `@eslint/js` recommended + `typescript-eslint` recommended (`eslint.config.js:10`).
`files: ["**/*.{ts,tsx}"]`, `ignores: ["dist"]`, `ecmaVersion: 2020`, `globals.browser`. Plugins
`react-hooks` (recommended rules) + `react-refresh` (`only-export-components: warn`,
`allowConstantExport: true`). Run: `npm run lint` = `eslint .` (`package.json:11`).

### 3.3 TypeScript — `dashboard/tsconfig.json`
`target: ES2020`, `module: ESNext`, `moduleResolution: bundler`, `jsx: react-jsx`, `noEmit: true`,
**`strict: true`**, plus `noUnusedLocals`, `noUnusedParameters`, `noFallthroughCasesInSwitch`,
`noUncheckedIndexedAccess`, `forceConsistentCasingInFileNames` (`tsconfig.json:15-20`). `include:
["src","vite-env.d.ts"]`, `exclude: ["src/test"]`. Build = `tsc -b && vite build` (`package.json:8`).

### 3.4 Vitest — `dashboard/vitest.config.ts`
`environment: jsdom`, `globals: true`, `setupFiles: ["./src/test/setup.ts"]`,
`testTimeout: 15000` (axe a11y sweeps run 4-8s on shared runners — `vitest.config.ts:10-16`).
`exclude` includes `**/tests-e2e/**` (Playwright, separate runner) and `**/worktrees/**`
(`vitest.config.ts:20-32`). Coverage provider `v8`, `include: ["src/**/*.{ts,tsx}"]`, excludes
`src/test/**`, `src/main.tsx`, `*.test.*`, `src/data/**`. Thresholds: see §2.

### 3.5 Playwright — `dashboard/playwright.config.ts` (E2E, not in CI's frontend job)
Driven by `npm run test:e2e`; grep-tagged variants `@visual`/`@layout`/`@a11y` (`package.json:15-19`).
Not invoked by `ci.yml` (no `test:e2e` step). Toolchain: `@playwright/test`, `@axe-core/playwright`,
`jest-axe`.

---

## 4. Schema / contract validation (Makefile targets)

### 4.1 `make validate-schemas` → `bash schemas/validate.sh` (`Makefile:125-126`)
`schemas/validate.sh` (`set -e`):
- **Metaschema/shape pass** (`validate.sh:10-34`): for each `*.schema.json` in the enumerated
  category dirs (`common discovery rationalization architecture data modernization build gates
  cross-cutting compliance profiles dispositions`), an inline Python check asserts the file is
  valid JSON AND contains `$schema`, `$id`, `title`, `description` keys. ⚠️ This is a **shape/key
  presence** check — it does NOT run the file against the JSON Schema 2020-12 metaschema (despite
  the echo banner saying "against … metaschema"). The true metaschema validation
  (`check-jsonschema --check-metaschema`) lives in the CI `contracts` job (§1.4), not here.
- **Sample pass** (`validate.sh:37-55`): each `samples/*.sample.json` must be valid JSON and contain
  a `$schema` reference (presence only — no structural validation against the schema here).
- **Summary** (`validate.sh:57-70`): counts schemas (excl. samples) + samples; `exit 1` if any
  `ERRORS`. ⚠️ The category-dir glob is a fixed list; a NEW top-level schema directory not in the
  `validate.sh:11` list is silently un-validated.

### 4.2 `make validate-objectives` → `python scripts/validate_objectives.py` (`Makefile:128-129`)
See §5.2. Note `render-exec` / `render-exec-generic` depend on `validate-objectives`
(`Makefile:142-146`), so the exec microsite never renders against invalid objectives.

### 4.3 `make check-docs` / `make fix-docs` → `scripts/check_doc_sync.py` (`Makefile:131-135`)
See §5.4. `--fix` rewrites drifted numbers in place.

### 4.4 CI metaschema validation (in `contracts` job, NOT a Makefile target)
`ci.yml:286-297`: `pip install check-jsonschema jsonschema` → loop
`check-jsonschema --check-metaschema "$schema"` over `schemas/**/*.schema.json`. This is the real
"validate against the 2020-12 metaschema" gate; plus the sample-against-schema validator at
`ci.yml:299-341` using `Draft202012Validator` + `RefResolver` over a `$id`-keyed store.

---

## 5. Anti-drift guards (the heart of the spec)

These are the tests/scripts that assert "registry == disk", "no orphan", and
"step-list-not-hardcoded". Each catches a specific drift and fails loudly.

### 5.1 `scripts/validate_skill_registry.py` — 10 invariants (CI: `skill-catalog`)
File header `validate_skill_registry.py:1-45`. `validate()` (`:159-333`) returns a list of
violation strings; non-empty → `exit 1` listing each (`:352-359`). Invariants:
1. **(:182-197)** Every non-orchestration registry skill id has a `SKILL.md` on disk under
   `cross-cutting/skills/<id>/` OR `profiles/<profile>/skills/<id>/` (orchestration skills skipped,
   `is_orchestration: true`).
2. **(:199-207)** Reverse: every `SKILL.md` directory on disk has a registry entry (top-level id OR
   declared variant id). **This is the registry==disk check.**
3. **(:209-217)** Every skill has a `depends_on` field present (may be empty).
4. **(:218-224)** Every `depends_on` target resolves to a real top-level skill id.
5. **(:226-239)** Every dispatch alias `resolves_to` a real skill id (and has the field).
6. **(:241-248)** No alias name collides with a `SKILL.md` directory name (ambiguous dispatch).
7. **(:250-261)** No non-orchestration skill id starts with reserved prefixes `plan-`/`step-`/
   `execute-` (`RESERVED_PREFIXES`, `:64`).
8. **(:263-276)** Every skill id referenced in an assembly-line README `## Skills` table is a
   registered id (top-level/variant) or a dispatch alias — catches README refs to renamed/deleted
   skills. Line slugs scanned: `_LINE_README_SLUGS` (`:68-80`).
8b. **(:278-316)** REVERSE README check — every registered skill is listed in its consuming line's
    README `## Skills` table, OR exempt (`line == "Cross-Cutting"`, or a variant documented via its
    base). Hard gate as of P5-S30.10 (was 75 unlisted before P5-S30.4 backfilled).
9. **(:318-331)** `olympus-worker/config/agents.yaml` stays a generic catch-all — every agent has
   empty `skill_ids`. A non-empty `skill_ids` resurrects the per-skill registry↔agents drift
   retired in P5-S26.
On success prints `Skill catalog OK: N skills … M SKILL.md files on disk … K dispatch aliases`
(`:361-374`). **Failure mode:** missing-on-disk / orphan-dir / unresolved dep or alias / reserved
prefix / README mismatch / per-skill agent mapping → exit 1 with the structured violation list.

### 5.2 `scripts/validate_objectives.py` — 7 invariants (CI: `agency-objectives`)
Header `validate_objectives.py:1-41`. `validate(repo_root, strict)` returns `(violations,
warnings)` (`:426-462`); violations → `exit 1` (`:489-496`). Invariants:
1. **(:323-333)** Every `profiles/<id>/objectives.yaml` schema-validates against
   `schemas/profiles/objectives.schema.json` (`jsonschema.validate`). On schema failure, deeper
   checks are skipped for that file.
2. **(:339-344)** Every objective id is namespaced `<profile-id>.*`.
3. **(:346-359)** Every metric ref (primary + secondary) resolves in
   `cross-cutting/metrics/registry.yaml` — but only when that registry exists (None = skip, AO-0
   ships before AO-1; `:174-185`).
4. **(:287-292)** Every `contributes_from.lines` id resolves against `assembly-lines/` dir names.
5. **(:294-300)** Every `contributes_from.skills` id resolves against the skill registry or a
   profile-scoped skill dir.
6. **(:372-384, :219-272)** Every `{placeholder}` in `narrative_template` is bindable — in the
   fixed token set (`_FIXED_NARRATIVE_TOKENS`, `:79-117`), a `count:`/`pct:` parameterized form
   (`_PARAMETERIZED_TOKEN_RE`, `:121-123`), a referenced gate id, or a kpi secondary label/metric
   last-segment.
7. **(:389-423)** `contributes_to:` reverse tags on any YAML under `cross-cutting/` or
   `assembly-lines/` reference real objective ids. **Warning** in AO-0; `--strict` promotes to
   failure (`:457-461`). The CI job does NOT pass `--strict` (`ci.yml:411`), so reverse-tag misses
   are advisory today.

### 5.3 `olympus-contracts/tests/test_no_hardcoded_step_lists.py` — step-list-not-hardcoded
File header `test_no_hardcoded_step_lists.py:1-23`. Guards the **2026-05-05 gate-review bug** where
a stale literal `_DISCOVERY_ORDER` in `olympus-api/src/services/gate.py` dropped 4 of 7 cards.
- Scans `olympus-api/src`, `olympus-worker/src`, `temporal/olympus_workflows` (`SCAN_DIRS`,
  `:37-41`); skips `.venv __pycache__ build .agents .codex tests registries/defaults`
  (`SKIP_PATTERNS`, `:44-52`).
- Source of truth: `_collect_step_ids()` reads `olympus_contracts.list_lines()` and collects each
  line's step id set (`:71-77`). **This is the contract-driven anti-drift anchor.**
- **Windowed cluster detector** (`:104-105`, `:112-171`): `CLUSTER_WINDOW=10`, `CLUSTER_THRESHOLD=5`
  — a file that quotes ≥5 step-id literals for one line within any 10-line window is flagged as a
  hardcoded step list. Individual scattered `self._set_step("catalog", …)` producer writes pass.
- **Waivers**: `# allow: step-list-literal — <reason>` on the same/preceding line
  (`ALLOWLIST_RE`, `:56-59`); `# allow-file: step-list-literal — <reason>` anywhere in the file
  (`FILE_ALLOWLIST_RE`, `:65-68`). Reason must be non-empty.
- **Failure mode**: `assert not violations` with the file + line-range of the first live cluster.
- ⚠️ NOT in a dedicated CI job — runs inside the `python` matrix legs for olympus-contracts (via the
  shared-Python fan-out that flips every package flag) and wherever olympus-contracts tests execute.

### 5.4 `scripts/check_doc_sync.py` — doc/reality count sync (CI: `doc-sync`)
Header `check_doc_sync.py:1-41`. Derives canonical counts from source of truth and compares against
enrolled `MANAGED_CLAIMS` sites (file + line-pattern + metric); `exit 1` on drift, `--fix` rewrites.
Derivers: `_count_registry_skills` reads `cross-cutting/skills/registry.yaml` `skills:` list
(`:70-80`); `_count_enum_members` textually parses a `StrEnum` block in
`olympus-contracts/olympus_contracts/enums.py` (gates/lines/dispositions, `:83-110`);
`_count_assembly_line_dirs` counts `assembly-lines/` dirs (`:113-`). Only explicitly-enrolled
sites are checked — historical/lineage numbers ("49 skills" for ATLAS, per-line "5 skills") are
deliberately NOT rewritten (`:23-27`). CI also runs `pytest tests/test_check_doc_sync.py`
(`ci.yml:388`). Guards the "~65 → 137 → 167 skills" drift.

### 5.5 `scripts/verify_step_registry.py` — frontend↔backend step parity (CI: `step-registry-consistency`)
Header `verify_step_registry.py:1-18`. Two sources of truth (`:26-28`):
`dashboard/src/components/WorkflowStepper/stepRegistry.ts` and
`olympus-api/src/services/step_mapping.py` (`UI_STEP_IDS`). `LINES` maps 10 lines to their TS const
name + Python `AssemblyLine` enum member (`:31-42`). Fails (non-zero) when: a line has different
step IDs/count across the two sources; a step ID recurs within a line (except `data-migration` /
`legacy-decommission` in Disposition Execution across Replace/Replatform branches, accepted if the
stepRegistry entries carry distinct `disposition` values); or a referenced gate ID is not a known
`GateType`. Resolves the TS spread-operator composition of `DISPOSITION_EXECUTION_STEPS`
(`:45-`).

### 5.6 `scripts/verify_sql_schema.py` — SQL↔alembic drift (CI: `sql-schema-drift`)
Header `verify_sql_schema.py:1-40`. Static analyzer, no DB. AST-replays
`db/alembic/versions/*.py` (`op.create_table/add_column/drop_column/rename_table/alter_column` +
raw `op.execute` ALTERs) into `{table: {column: type_category}}`, then AST-walks
`olympus-api/src/` for `sqlalchemy.text("…")` literals and checks SELECT/INSERT/UPDATE column +
table existence. Flags the **`actual_start`/`updated_at` Date-vs-DateTime bug**: same bind param
assigned to two columns of differing alembic type categories in an UPDATE SET. CI also runs
`pytest tests/test_verify_sql_schema.py` (`ci.yml:455`). Scope: only raw `text("…")` SQL — ORM
`select()`/`Query` out of scope; f-string placeholders neutralized to avoid false positives.

### 5.7 `olympus-contracts/tests/test_skill_manifest.py` — SKILL.md frontmatter contract
Header `test_skill_manifest.py:1-18`. Lints every `cross-cutting/skills/*/SKILL.md`:
- `test_every_skill_has_parseable_frontmatter` / `…_has_name_and_description` (`:73-91`):
  frontmatter parses as YAML and has `name` + `description`.
- `test_output_schemas_is_list_of_mappings_when_present` (`:98-134`): optional `output_schemas`
  must be a list of `{path, schema}` string mappings.
- `test_wired_schemas_resolve_on_disk` (`:136-158`): every wired `schema:` path **resolves to a
  real file** — regression guard so a rename doesn't silently turn validation into a no-op.
- `test_critical_path_skills_have_schemas_wired` (`:160-249`): a hardcoded `required_wiring` map of
  ~40 critical-path skills (disposition-recommender → disposition-recommendation.json, etc.) MUST
  declare `output_schemas`. ⚠️ This map itself is a drift surface — adding a critical skill requires
  updating it.
- `test_redundancy_analyzer_wires_both_scopes` / `test_sequencer_wires_both_outputs` (`:251-304`):
  skills that emit two artifacts must wire both paths.

### 5.8 `olympus-api/tests/test_skill_registry.py` — registry loader + production assertions
Covers the typed loader (`:103-173`) and **production-registry structural anti-drift**
(`TestProductionRegistry`, `:181-234`):
- `test_all_skills_have_depends_on` (`:186-192`) and `test_depends_on_targets_exist` (`:194-202`).
- `test_alias_targets_exist` (`:204-212`) — every dispatch alias resolves to a real id.
- `test_gate_pre_review_is_cross_cutting` (`:214-219`) — regression pin.
- **`test_no_orphan_line_assignments` (`:221-234`)** — every skill's `line` ∈ the 11 valid lines
  (Discovery, Rationalization, Architecture, Data, Modernization, Validation, Deployment,
  Disposition Execution, Sustainment, Governance, **Build**) + `Cross-Cutting`. **This is the
  no-orphan-line guard.**
Backwards-compat shims (`LINE_MAP`, `DISPATCH_TO_DIR`, `DIR_TO_DISPATCH`, `AGENT_TO_TIER` =
{opus→tier-1, sonnet→tier-2, haiku→tier-3}) tested at `:242-293`.

### 5.9 `temporal/tests/test_devsecops_baseline_commit_contract.py` — DevSecOps baseline contract
Header `:1-14` (Phase 6 W11). Pins three pure-logic pieces:
- **Commit contract** (`route_generate_file` / `is_root_bound`, `:37-88`): baseline + app files →
  repo root verbatim (incl. `.github/` dot preserved — regression against `lstrip('./')`); workflow
  metadata JSON → namespaced `modernization/<app>/generate/files/[<BC>/]…` prefix.
- **Validator** (`validate_baseline`, `:120-219`): a complete baseline (all `REQUIRED_BASELINE_FILES`
  + all `REQUIRED_CI_JOBS` present in the generated `ci.yml`) passes; missing file, missing required
  CI job, un-rendered `{{placeholder}}` (but `${{ ... }}` GHA expressions allowed), wrong SAST tool,
  or malformed iac-manifest fails. **This guards the gate-G-04c baseline that every generated app's
  CI must satisfy** — i.e., generated repos get the same required-jobs contract.
- **Profile resolution** (`resolve_baseline_params`, `:227-276`): FAA → codeql/aws/distroless/
  Apache-2.0/python/terraform; defaults apply when no profile root; a non-FAA profile (semgrep/azure)
  composes with no hardcoded-FAA leakage.

### 5.10 Other contract/registry anti-drift tests (same family, lower-traffic)
- `olympus-contracts/tests/test_assembly_lines.py` — authoritative line-contract loader tests:
  `test_every_line_has_unique_step_ids` (`:43`), `…_at_least_one_step` (`:50`), `…_valid_kind`
  (`:54`), `test_pass_order_matches_evidence_steps` (`:139`), `test_every_analysis_step_has_a_skill`
  (`:116`), `test_frozen` (`:169`). First line of defence — fails before api/worker can misbehave.
- `olympus-api/tests/test_gate_naming.py` — every `GateType` has a non-empty `GATE_FRIENDLY_NAMES`
  entry + a `GATE_ASSEMBLY_LINES` mapping; no stray keys; signed-off name/line tables pinned to
  expected values (`:28-116`).
- `temporal/tests/test_build_line_registration.py` — pins the Build line contract
  (`olympus-contracts/.../data/assembly-lines/build.yaml`): `Build` is the 8th `Disposition`
  (`:19-31`), deps resolve / no cycle, Spec→Design→Generate steps + G-NEW-1/2/3 gates present,
  Design/Generate reuse Modernization's source-agnostic skills (no forked copies).
- `tests/test_validate_skill_registry.py`, `tests/test_check_doc_sync.py`,
  `tests/test_verify_sql_schema.py`, `tests/test_validate_objectives.py` — the unit tests for the
  validators themselves, run directly by the corresponding CI jobs.

---

## 6. `deploy.yml`, `branch-protection-sync.yml`, traceability workflows

### 6.1 `deploy.yml` — Deploy (`deploy.yml:1-269`)
**Triggers** (`:3-18`): `workflow_run` (workflows `[CI]`, types `[completed]`, branches `[main]`)
and `workflow_dispatch` with `target_env` choice `dev|staging|prod` (default `dev`).
`permissions: id-token: write, contents: read` (`:20-22`) — OIDC into AWS.
- **`deploy-dev`** (`:31-133`): `if` = (workflow_run conclusion success) OR (dispatch + target=dev).
  `environment: dev`. Steps: configure-aws-credentials (assume `AWS_DEPLOY_ROLE_ARN`), ECR login,
  setup kubectl + Helm v3.14.0, `aws eks update-kubeconfig`, run db-migrate helm chart (TAG =
  `workflow_run.head_sha || github.sha`), then `helm upgrade --install olympus
  infra/helm/olympus-umbrella -f values-dev.yaml … --wait --timeout 600s`. **Smoke test** (`:100-133`)
  polls for the ALB hostname (12×10s), checks `https://$ALB_URL/health/live` returns 200, else
  `::error::` + exit 1 (previously only `::warning::` — now hard-fails).
- **`deploy-staging`** (`:145-205`): `needs: deploy-dev`, `if: always() && ((workflow_run &&
  deploy-dev.result==success) || (dispatch && target=staging))`. `environment: staging`. ⚠️ The
  `always()` pattern lets a staging dispatch run even when `deploy-dev` is skipped — avoiding the
  "skipped because dependency was skipped" trap (`:135-144`).
- **`deploy-prod`** (`:215-269`): dispatch-only (`if: dispatch && target=prod`), **no `needs`**.
  `environment: prod` with required-reviewers gate (`:219`). TAG = `github.sha`.

### 6.2 `branch-protection-sync.yml` (`:1-91`)
**Triggers**: push to `main` touching `.github/branch-protection.yml` or this workflow; plus
`workflow_dispatch`. One job `sync` reads `.github/branch-protection.yml`, builds the protection
body, and `gh api --method PUT /repos/{repo}/branches/{branch}/protection`. ⚠️ Needs a
`BRANCH_PROTECTION_TOKEN` secret (admin:write — default `GITHUB_TOKEN` can't edit protection); when
absent the job **no-ops with a warning** (`:37-40`), declarative file stays source of truth.

⚠️ **GOTCHA — branch-protection contexts ≠ actual CI job names.** `.github/branch-protection.yml`
required contexts are: `lint / Python`, `lint / Dashboard`, `test / Python`, `test / Dashboard`,
`build`, `CodeQL: python`, `CodeQL: javascript`, `SCA: Trivy fs`, `Secrets Scan`. But the real
`ci.yml` jobs are named `Python: olympus-api`, `Frontend Checks`, etc., and there is **no `build`
job** (commented out). Only `CodeQL: *`, `SCA: Trivy fs`, `Secrets Scan` match real check names.
The `lint / *`, `test / *`, `build` contexts are **stale/aspirational** — if synced verbatim they'd
require checks that never report. SBOM + 4 Image-CVE contexts are commented out pending the 14-day
advisory window (`branch-protection.yml:19-26`).

### 6.3 `pages-publish-traceability.yml` (`:1-60`)
Push to `main` touching the appendix / traceability scripts / index.html / this workflow, or
dispatch. `permissions: contents: write`. Regenerates `traceability/traceability.json` via
`scripts/traceability/build_dashboard_json.py --appendix specifications/phase-3-traceability-
appendix.md`, and commits it back with `[skip ci]` so it doesn't retrigger (`:49-59`). Python 3.12.

### 6.4 `traceability-check.yml` (`:1-91`)
PR-time, paths include `specifications/** temporal/** dashboard/** cross-cutting/** profiles/**
docs/** schemas/** olympus-agent-runtime/** scripts/traceability/**`. `permissions:
pull-requests: write`. Runs `scripts/traceability/check.py --base … --head …` producing three
signals (status-progression, impact, coverage-gap). Upserts a PR comment only when
`has_signal == true` (`:56-72`). A **status backslide** (Supported→Partial / anything→Gap) emits a
`::warning::` (`:82-85`); coverage gaps emit `::notice::` (`:87-90`). ⚠️ All signals are **advisory
— this workflow does NOT fail CI** (`:8-9`).

---

## 7. Regeneration order (build/CI bootstrap)

To rebuild CI from this spec, the install dependency order (mirrors every CI install step) is:
1. `pip install -e ./olympus-contracts` (v0.4.0; no deps beyond pyyaml; ships
   `data/assembly-lines/*.yaml`) — **everything depends on it**.
2. `pip install -e ./temporal` (pkg `olympus-workflows`; pulls private `foundry-temporal>=1.3.0`
   from `PIP_EXTRA_INDEX_URL=https://jfrog-platform.bah-ss-nonprod.te-test-domain.com/artifactory/
   api/pypi/agentic-ai-pypi/simple`).
3. `pip install -e ./<package>[dev]` for each runtime package. ⚠️ The temporal CI leg additionally
   installs worker + api with `--ignore-requires-python` (3.12 leg, 3.13-pinned packages).
4. `pip install ruff` (every Python leg lints with `ruff check .`).
5. Dashboard: `npm ci` then `npx vitest run --coverage`.

Private-index dependency (⚠️): `olympus-api`, `olympus-worker`, `temporal` all require
`foundry-temporal>=1.3.0`, available **only** from the Booz Allen jfrog Artifactory. CI wires it via
`PIP_EXTRA_INDEX_URL` env on the install steps (`ci.yml:502, 670, 766`). The `stack-spin-smoke` job
deliberately avoids installing those packages on the host (§1.12 gotcha).

---

## 8. Undetermined / not-fully-resolved

- **`scripts/traceability/check.py`, `build_dashboard_json.py`, `parse_matrix.py`** — referenced by
  `traceability-check.yml` / `pages-publish-traceability.yml` but their bodies were not read; only
  their CLI contracts (`--base/--head/--output/--json`; `--appendix/--out`) are captured here.
- **`check_doc_sync.py` full `MANAGED_CLAIMS` table** — only the deriver functions and policy
  (`:1-115`) were read; the exact enrolled (file, pattern, metric) sites were not enumerated.
- **`verify_step_registry.py` / `verify_sql_schema.py` deep parsers** — purpose + failure modes
  captured from docstrings + LINES table; the full statement-splitter / AST-walk internals were not
  transcribed.
- **`olympus-cli` and `olympus-contracts` have NO coverage floor** — confirmed (no `--cov` in their
  `addopts`/no `[tool.pytest.ini_options]`); they are not in the CI `python` matrix, so their tests
  run only via the shared-Python fan-out or direct invocation. No CI job explicitly runs
  `cd olympus-cli && pytest` or `cd olympus-contracts && pytest`.
- **`.gitleaks.toml` contents** — exists (2032 bytes), used by both gitleaks modes; rule contents
  not transcribed.
- **MCP-server ruff** — no `[tool.ruff]` block in `mcp-server/pyproject.toml`; the matrix
  `ruff check .` step runs with ruff defaults for that leg (line-length 88, default rule set) —
  inconsistent with the line-length-100 / `E,F,I,W` config in the other six packages.
