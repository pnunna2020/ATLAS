# Regen Spec 01 — Applications API Router

ATOMIC regeneration spec for `olympus-api/src/routers/applications.py`. Behavioral-parity target. All paths absolute from repo root `/Users/pnunna/Documents/GitHub/foundry`.

Source file: `olympus-api/src/routers/applications.py` (802 lines).

---

## 0. Router construction & cross-cutting

`olympus-api/src/routers/applications.py:61`
```python
router = APIRouter(prefix="/api/v1/applications", tags=["Applications"])
```
- Every path below is the **router prefix `/api/v1/applications` + the decorator path**.
- ⚠️ GOTCHA — **mount order matters**: FastAPI matches in declaration order. The literal route `POST /upload` (line 203) is declared BEFORE the `{app_id}` path routes, so `/upload` is never swallowed by `/{app_id}`. Preserve this exact ordering. Within `{app_id}` sub-routes, `GET /{app_id}/steps/{line}/{step}` and the explicit `discovery/...` paths are all distinct enough not to collide, but keep the file order to be safe.
- **30 endpoints total** at HEAD `7cb3b20c` (was 22; +8 — counted by `@router.<verb>` decorators). New since the 22-endpoint baseline: **E23** `GET /{app_id}/design-artifacts` (370), **E24** `POST /{app_id}/design-feedback` (395), **E25** `POST /{app_id}/interview` (430), **E26** `GET /{app_id}/interview` (451), **E27** `POST /{app_id}/interview/turns` (464), **E28** `POST /{app_id}/interview/complete` (483), **E29** `POST /{app_id}/workflow/reset` (847), **E30** `GET /{app_id}/gate-evidence` (907). ⚠️ Many E1–E22 line citations also SHIFTED (e.g. E2 `create_application` is now `applications.py:144`, E3 `/upload` `220`, E11 `/discover` `659`). The new interview/design-feedback ones go through `interview_svc` / `design_review_svc` (services-logic spec).
  Full live `@router` decorator list (method path [line]): GET `` [81]; POST `` [144]; POST `/upload` [220]; GET `/{app_id}` [310]; PATCH `/{app_id}` [323]; GET `/{app_id}/status` [337]; GET `/{app_id}/lineage` [350]; GET `/{app_id}/design-artifacts` [370]; POST `/{app_id}/design-feedback` [395]; POST `/{app_id}/interview` [430]; GET `/{app_id}/interview` [451]; POST `/{app_id}/interview/turns` [464]; POST `/{app_id}/interview/complete` [483]; GET `/{app_id}/source-artifacts-index` [535]; GET `/{app_id}/rationale` [625]; GET `/{app_id}/steps/{line}/{step}` [645]; POST `/{app_id}/discover` [659]; POST `/{app_id}/discovery/start` [702]; POST `/{app_id}/discovery/retry` [719]; POST `/{app_id}/discovery/rerun` [742]; GET `/{app_id}/workflow` [775]; POST `/{app_id}/workflow/start` [790]; POST `/{app_id}/workflow/cancel` [809]; POST `/{app_id}/workflow/retry` [824]; POST `/{app_id}/workflow/reset` [847]; GET `/{app_id}/insights` [887]; GET `/{app_id}/gate-evidence` [907]; GET `/{app_id}/decisions` [928]; GET `/{app_id}/disposition-output` [941]; GET `/{app_id}/dispositions` [966].

### 0.1 Auth model (`olympus-api/src/middleware/auth.py`)
- `get_current_user(request)` — FastAPI dependency. NOT an OAuth2 scope model; it is a Bearer-JWT decoder.
  - If env `DEV_AUTH_BYPASS=true` → returns `CurrentUser(sub="local-dev", roles=list(RBACRole), claims={"sub":"local-dev","dev_bypass":True})` (ALL roles). `auth.py:61-66`.
  - Else extract `Authorization: Bearer <token>`; missing → `HTTPException(401, "Missing authorization token")`. `auth.py:68-70`.
  - Decode via `jose.jwt.decode`, secret `JWT_SECRET` (default `"olympus-dev-secret"`), alg `JWT_ALGORITHM` (default `HS256`). If `AUTH_SKIP_VERIFICATION=true` (default true) → options `{verify_signature:False, verify_exp:False, verify_aud:False}`. `JWTError` → `HTTPException(401, "Invalid or expired token")`. `auth.py:72-88`.
  - `sub = payload.get("sub","anonymous")`; roles parsed from `payload["roles"]`, unknown role strings logged+skipped; if none resolve → `roles=[RBACRole.VIEWER]`. `auth.py:90-103`.
- `CurrentUser.has_role(*roles)` → `any(r in self.roles for r in roles)`. `auth.py:40-41`.
- `RBACRole` (`olympus-api/src/models/common.py:47-56`): `portfolio_admin, portfolio_manager, tech_lead, arch_lead, compliance_lead, operations_lead, safety_board, viewer, service`.

### 0.2 Route-level auth dependency `require_application_member`
`olympus-api/src/dependencies.py:136-157`. Applied via `dependencies=[Depends(require_application_member)]` on most `{app_id}` routes. Reads `app_id` from the path.
```
def require_application_member(app_id: Path, user=Depends(get_current_user), db=Depends(get_db)) -> CurrentUser:
    if user.has_role(PORTFOLIO_ADMIN):           # short-circuit, no DB hit
        return user
    await verify_application_portfolio_access(db, user, app_id)
    return user
```
`verify_application_portfolio_access` (`dependencies.py:184-213`):
```
if user.has_role(PORTFOLIO_ADMIN): return None
row = SELECT portfolio_id FROM application WHERE id = :aid
if row is None: raise HTTPException(404, "Application not found")   # ⚠️ plain detail string, NOT Olympus envelope
portfolio_id = row["portfolio_id"]
await verify_portfolio_access(db, user, portfolio_id)              # 403 PORTFOLIO_NOT_MEMBER if not member
return portfolio_id
```
`verify_portfolio_access` (`dependencies.py:105-133`):
```
if user.has_role(PORTFOLIO_ADMIN): return
if await membership_svc.is_member(db, portfolio_id, user.sub): return
raise HTTPException(403, detail={"code":"PORTFOLIO_NOT_MEMBER","message":"Caller is not a member of this portfolio. Ask a portfolio_admin to grant access."})
```
⚠️ GOTCHA — `require_application_member` is added as a **route dependency**, so it runs even though most handlers do NOT take `user` as a parameter. It still resolves `get_current_user` (401 if no token) AND membership. It also does its own 404 (plain `"Application not found"` detail) which can race the handler's structured 404 — whichever runs first wins; the dependency runs first.

### 0.3 Error envelope (`olympus-api/src/middleware/error_handler.py`)
- `OlympusHTTPException(status_code, code, message, details=None)` → rendered as:
  ```json
  {"error":{"code":"<code>","message":"<message>","details":{...or {}},"request_id":"<id>"}}
  ```
  (`error_handler.py:35-46, 52-59`).
- Plain `HTTPException` (from dependencies) → mapped by `code_map` to `{400:BAD_REQUEST,401:UNAUTHORIZED,403:FORBIDDEN,404:NOT_FOUND,409:CONFLICT,422:VALIDATION_ERROR,429:RATE_LIMITED}` else `ERROR`. When detail is a dict (e.g. PORTFOLIO_NOT_MEMBER), it is stringified into `message` via `str(exc.detail)`. `error_handler.py:61-73`.
- `RequestValidationError` → 422 `VALIDATION_ERROR`, `details.errors` sanitized. `error_handler.py:75-102`.
- Any unhandled `Exception` → 500 `INTERNAL_ERROR`. `error_handler.py:104-107`.

### 0.4 Config dependency
`get_config()` (`dependencies.py:28-31`) returns singleton `AppConfig()`. Fields referenced by this router: `temporal_task_queue`, `temporal_ui_base_url`, `temporal_namespace`, `temporal_host`, `github_token`, `github_base_url`, `source_intake_root`, `source_intake_max_upload_bytes`, `source_intake_s3_region`, `workflow_cancel_grace_seconds`, `workflow_staleness_minutes`.
`get_temporal_client()` (`dependencies.py:34-43`) — lazily connects `Client.connect(temporal_host, namespace=temporal_namespace)`, cached in module global.

### 0.5 Pagination (`olympus-api/src/middleware/pagination.py`)
- `get_pagination(page=Query(1,ge=1), per_page=Query(20,ge=1,le=100)) -> PaginationParams(page, per_page)`. `.offset = (page-1)*per_page`.
- `paginated_response(items, total, params)` → `{"data":[...], "pagination":{"page","per_page","total","total_pages"}}` where `total_pages = max(1, ceil(total/per_page))`.

### 0.6 Shared enum values (`olympus-contracts/olympus_contracts/enums.py`, re-exported via `olympus-api/src/models/common.py`)
- `AssemblyLineName` / `AssemblyLine` (StrEnum): `Discovery, Rationalization, Architecture, Data, Modernization, Disposition Execution, Validation, Deployment, Sustainment, Governance`.
- `Disposition` (StrEnum): `Retire, Retain, Refactor, Rearchitect, Replace, Replatform, Consolidate`.
- `RiskTier` (IntEnum): `1, 2, 3`.
- `ComplexityTier` (StrEnum): `simple, moderate, complex`.
- `TierSource` (StrEnum): `auto, confirmed, overridden`.
- `GateType` (StrEnum): `G-DC, G-RR, G-DA, G-02, G-DT, G-04a, G-04b, G-04c, G-DE-1, G-DE-2, G-V1, G-V2, G-V3, G-DP-1, G-DP-2`.
- `GateStatus` (StrEnum): `preparing, pending, approved, rejected, overridden, escalated, merge_blocked`.
- `SourceType` (str Enum, `common.py:26-44`): `git, zip, s3, confluence, sharepoint, gdrive, gcs`.

---

## ENDPOINTS

### E1 — GET `/api/v1/applications` (list_applications)
`applications.py:64-90`. **No route-level auth dependency**; auth via the `user` param.
- **Auth**: `user: CurrentUser = Depends(get_current_user)` (401 if no token). NOT admin-gated; non-admins get membership-filtered results.
- **Query params**:
  - `portfolio_id: uuid.UUID | None = Query(None)`
  - `pagination: PaginationParams = Depends(get_pagination)` → `page` (default 1, ge 1), `per_page` (default 20, ge 1, le 100).
- **Request body**: none.
- **Response**: `dict` (paginated envelope, NOT a declared `response_model`): `{"data":[ApplicationDetail-as-json...], "pagination":{page,per_page,total,total_pages}}`. Each item is `ApplicationDetail.model_dump(mode="json")` (see §A1).
- **Status**: 200.
- **Handler logic** (`applications.py:77-90`):
```
if portfolio_id is not None:
    await verify_portfolio_access(db, user, portfolio_id)        # 403 PORTFOLIO_NOT_MEMBER (admin bypass)
member_ids = await filter_portfolio_ids_by_membership(db, user)  # None for admin; else list[UUID] of user's portfolios
apps, total = await app_svc.list_applications(db, pagination, portfolio_id=portfolio_id, portfolio_ids=member_ids)
return paginated_response([a.model_dump(mode="json") for a in apps], total, pagination)
```
- `filter_portfolio_ids_by_membership` (`dependencies.py:389-411`): admin → `None`; else `member_ids = membership_svc.list_user_portfolio_ids(db, user.sub)`; if `candidate is None` return member_ids.
- `app_svc.list_applications` (`olympus-api/src/services/application.py:649-732`) — SQL with composable WHERE:
```
clauses=[]; params={}
if portfolio_ids is not None:
    if not portfolio_ids: clauses.append("FALSE")          # ⚠️ empty allowlist ⇒ no rows
    else: clauses.append("portfolio_id = ANY(:pf_ids)"); params["pf_ids"]=portfolio_ids
if portfolio_id is not None: clauses.append("portfolio_id = :portfolio_id"); params["portfolio_id"]=portfolio_id
where = "WHERE "+" AND ".join(clauses) if clauses else ""
total = SELECT count(*) FROM application {where}
rows  = SELECT * FROM application {where} ORDER BY created_at DESC LIMIT :limit OFFSET :offset
return ([ApplicationDetail(... mapped from row ...)], total)
```
  Row→model mapping (`application.py:708-728`): `risk_tier=int(row["risk_tier"]) if row["risk_tier"] else None`; `repository_url=row["repo_url"]`; `status=row["current_status"]`; `metadata=row.get("metadata") or {}`. (List items do NOT populate `scores`, `target_systems`, `realizes_capability`, `agent_activity_by_line` — those are detail-only.)
- ⚠️ GOTCHA: when `portfolio_id` is given AND non-admin, BOTH `portfolio_id = :portfolio_id` AND `portfolio_id = ANY(:pf_ids)` clauses apply (intersection). If the explicit portfolio isn't in the membership allowlist → empty result, not 403 (the 403 only fires from `verify_portfolio_access` at line 78 when the user isn't a member of the *explicitly requested* portfolio — so for an explicit non-member portfolio you actually get 403 first).

---

### E2 — POST `/api/v1/applications` (create_application)
`applications.py:127-200`. `@router.post("", response_model=ApplicationDetail, status_code=201)`.
- **Auth**: `user: CurrentUser = Depends(get_current_user)`. Membership enforced inside handler via `verify_portfolio_access`.
- **Request body**: `ApplicationCreate` (§A2).
- **Response model**: `ApplicationDetail` (§A1). For `s3`/scaffold types the handler may instead return a raw `JSONResponse` (501) — see below.
- **Status**: 201 success; 404/400/415/422/501 error branches.
- **Handler logic** (`applications.py:154-200`):
```
portfolio_id = await _resolve_portfolio_id(db, body.portfolio_id)   # §H1
await verify_portfolio_access(db, user, portfolio_id)               # 403 PORTFOLIO_NOT_MEMBER (admin bypass)
config = get_config()

if body.source_type == GIT:
    return await app_svc.create_application(db, body, portfolio_id)  # §H3

if body.source_type == ZIP:
    raise OlympusHTTPException(415, "ZIP_REQUIRES_MULTIPART",
        "Zip intake must be sent as multipart/form-data to POST /api/v1/applications/upload.")

# Non-Git, non-Zip (s3, confluence, sharepoint, gdrive, gcs):
app_id = uuid.uuid4()
destination = source_intake.destination_for(config.source_intake_root, app_id)   # Path(root)/str(app_id)
try:
    provider = source_intake.build_provider(body.source_type,
                   max_upload_bytes=config.source_intake_max_upload_bytes,
                   s3_region=config.source_intake_s3_region or None)
    intake_result = provider.unpack(destination=destination, source_uri=body.source_uri)
except source_intake.SourceIntakeNotImplemented as exc:          # confluence/sharepoint/gdrive/gcs
    return JSONResponse(status_code=501,
        content={"error":{"code":exc.code,"message":exc.message,
                          "details":{"source_type":body.source_type.value},"request_id":""}},
        headers={"X-Implementation-Status":"scaffold"})
except source_intake.SourceIntakeError as exc:                   # any other intake failure (e.g. s3)
    raise OlympusHTTPException(422, exc.code, exc.message)
return await app_svc.create_application(db, body, portfolio_id, app_id=app_id, intake_result=intake_result)
```
- ⚠️ GOTCHA — the 501 scaffold path returns a **hand-rolled `JSONResponse`** (NOT `OlympusHTTPException`); `request_id` is the empty string `""` and header `X-Implementation-Status: scaffold` is set. Preserve both exactly.
- ⚠️ GOTCHA — `ApplicationCreate` model-validator (`application.py:184-208`) runs at body parse: GIT requires `repository_url` (else 422 VALIDATION_ERROR); ZIP skips validation; every other type requires `source_uri`.
- `build_provider` codes: S3 success path; `SourceIntakeNotImplemented(code="SOURCE_TYPE_NOT_IMPLEMENTED")` for the 4 scaffolds (`source_intake.py:499-503`). Errors from S3 intake bubble as `SourceIntakeError` → 422 (codes: `SOURCE_URI_MISSING, BAD_S3_URI, UNSAFE_S3_KEY, S3_FETCH_FAILED, S3_PREFIX_EMPTY, BOTO3_MISSING`). See §S1.

---

### E3 — POST `/api/v1/applications/upload` (upload_application_zip)
`applications.py:203-290`. `@router.post("/upload", response_model=ApplicationDetail, status_code=201)`.
- **Auth**: `user: CurrentUser = Depends(get_current_user)`. Membership enforced inside via `verify_portfolio_access`.
- **Request — multipart/form-data** (`File`/`Form`):
  - `file: UploadFile = File(..., description="Zip archive of the application source")` — required.
  - `name: str = Form(...)` — required.
  - `description: str | None = Form(None)`
  - `portfolio_id: uuid.UUID | None = Form(None)`
  - `risk_tier: int | None = Form(None)`
  - `complexity_tier: str | None = Form(None)`
  - `tags: str | None = Form(None, description="Optional JSON-encoded tags dictionary")`
  - `request: Request` (for Content-Length).
- **Response model**: `ApplicationDetail` (§A1). **Status**: 201; errors 404/400/422/413.
- **Handler logic** (`applications.py:230-290`):
```
resolved_portfolio = await _resolve_portfolio_id(db, portfolio_id)   # §H1 (404/400)
await verify_portfolio_access(db, user, resolved_portfolio)          # 403
config = get_config()

parsed_tags = {}
if tags:
    try:
        parsed = json.loads(tags)
        if not isinstance(parsed, dict): raise ValueError("tags must be a JSON object")
        parsed_tags = {str(k): str(v) for k,v in parsed.items()}
    except (ValueError, JSONDecodeError) as exc:
        raise OlympusHTTPException(422, "BAD_TAGS", f"Invalid tags JSON: {exc}")

app_id = uuid.uuid4()
destination = source_intake.destination_for(config.source_intake_root, app_id)

declared_size = None
cl = request.headers.get("content-length")
if cl is not None:
    try: declared_size = int(cl)
    except ValueError: declared_size = None

try:
    provider = source_intake.build_provider(ZIP, max_upload_bytes=config.source_intake_max_upload_bytes)
    intake_result = provider.unpack(destination=destination, upload_stream=file.file, declared_size=declared_size)
except source_intake.SourceIntakeError as exc:
    status = 413 if exc.code == "UPLOAD_TOO_LARGE" else 422
    raise OlympusHTTPException(status, exc.code, exc.message)

body = ApplicationCreate(name=name, description=description, source_type=ZIP,
                         portfolio_id=resolved_portfolio, risk_tier=risk_tier,
                         complexity_tier=complexity_tier, tags=parsed_tags)
return await app_svc.create_application(db, body, resolved_portfolio, app_id=app_id, intake_result=intake_result)
```
- ⚠️ GOTCHA — tags parsed BEFORE touching disk so gibberish fails 422 `BAD_TAGS` first.
- ⚠️ GOTCHA — `UPLOAD_TOO_LARGE` → **413**, every other intake error → 422. Zip intake codes (`source_intake.py`): `UPLOAD_MISSING, UPLOAD_TOO_LARGE(413), UNSAFE_ZIP_ENTRY, BAD_ZIP`. See §S1.
- ⚠️ GOTCHA — `risk_tier`/`complexity_tier` passed through to `ApplicationCreate` which coerces them to `RiskTier`/`ComplexityTier` enums; invalid values raise pydantic `ValidationError` at this constructor call (becomes 500 INTERNAL_ERROR since it's not in a request-parse context — it's a direct constructor call). Source has `# type: ignore[arg-type]` on these (`applications.py:283-284`).

---

### E4 — GET `/api/v1/applications/{app_id}` (get_application)
`applications.py:293-303`. `response_model=ApplicationDetail`, `dependencies=[Depends(require_application_member)]`.
- **Auth**: route dep `require_application_member` (401/403/404). No `user` param.
- **Path**: `app_id: uuid.UUID`.
- **Response**: `ApplicationDetail` (§A1). **Status**: 200; 404 `APP_NOT_FOUND`.
- **Logic**: `return await app_svc.get_application(db, app_id)` (§H4).

---

### E5 — PATCH `/api/v1/applications/{app_id}` (update_application)
`applications.py:306-317`. `response_model=ApplicationDetail`, `dependencies=[Depends(require_application_member)]`.
- **Auth**: route dep. **Path**: `app_id: uuid.UUID`. **Body**: `ApplicationUpdate` (§A3).
- **Response**: `ApplicationDetail` (§A1). **Status**: 200; 404 `APP_NOT_FOUND`.
- **Logic**: `return await app_svc.update_application(db, app_id, body)` (§H5).

---

### E6 — GET `/api/v1/applications/{app_id}/status` (get_application_status)
`applications.py:320-330`. `response_model=ApplicationStatus`, `dependencies=[Depends(require_application_member)]`.
- **Auth**: route dep. **Path**: `app_id`. **Response**: `ApplicationStatus` (§A4). **Status**: 200; 404 `APP_NOT_FOUND`.
- **Logic**: `return await app_svc.get_application_status(db, app_id)` (§H6 — defensive, never 500s on bad gate rows).

---

### E7 — GET `/api/v1/applications/{app_id}/lineage` (get_application_lineage)
`applications.py:333-350`. `response_model=ApplicationLineageResponse`, `dependencies=[Depends(require_application_member)]`.
- **Auth**: route dep. **Path**: `app_id`. **Response**: `ApplicationLineageResponse` (§A5). **Status**: 200; 404 `APP_NOT_FOUND`.
- **Logic**: `return await lineage_svc.get_application_lineage(db, app_id)` (§H7).

---

### E8 — GET `/api/v1/applications/{app_id}/source-artifacts-index` (get_source_artifacts_index)
`applications.py:383-470`. `dependencies=[Depends(require_application_member)]`. Returns `JSONResponse` (no declared `response_model`).
- **Auth**: route dep. **Path**: `app_id`. Extra deps: `config=Depends(get_config)`.
- **Response**: raw JSON object — the parsed `source-artifacts-index.json` with an added `_meta` key. **Status**: 200; multiple 404 codes; 500 `INDEX_MALFORMED`.
- **Handler logic** (`applications.py:406-470`):
```
row = SELECT a.id, a.name, a.source_app_ids, p.artifact_repo_url,
             (SELECT wave_id FROM wave_application WHERE application_id=a.id LIMIT 1) AS wave_id
      FROM application a JOIN portfolio p ON p.id=a.portfolio_id WHERE a.id=:app_id
if row is None: raise OlympusHTTPException(404, "APP_NOT_FOUND", f"Application {app_id} not found")
source_app_ids = row.get("source_app_ids") or []
if not source_app_ids:
    raise OlympusHTTPException(404, "NOT_A_TARGET",
        "Application has no source_app_ids; source-artifacts-index is only emitted for Consolidate / Replace targets.")
wave_id = row.get("wave_id"); artifact_repo = row.get("artifact_repo_url") or ""
if not wave_id or not artifact_repo:
    raise OlympusHTTPException(404, "INDEX_UNAVAILABLE", "Target is missing wave binding or artifact repo config.")
svc = _build_git_service_for_artifact_repo(config, artifact_repo)   # §H2 → None when token/repo missing or init fails
if svc is None:
    raise OlympusHTTPException(404, "INDEX_UNAVAILABLE", "GitService unavailable (missing token or init failed).")
index_path = f"rationalization/wave-{wave_id}/targets/{app_id}/source-artifacts-index.json"
try:
    result = svc.read_file(path=index_path, branch="main")
except GitServiceError:
    raise OlympusHTTPException(404, "INDEX_NOT_FOUND", f"Index not committed yet at {index_path!r}")
try:
    payload = json.loads(result.content)
except (TypeError, ValueError):
    raise OlympusHTTPException(500, "INDEX_MALFORMED", "Index file is not valid JSON.")
payload["_meta"] = {"path": index_path, "commit_sha": result.commit_sha}
return JSONResponse(content=payload)
```
- ⚠️ GOTCHA — four distinct 404 codes (`APP_NOT_FOUND`, `NOT_A_TARGET`, `INDEX_UNAVAILABLE`, `INDEX_NOT_FOUND`) plus a 500 (`INDEX_MALFORMED`). Branch order is load-bearing.

---

### E9 — GET `/api/v1/applications/{app_id}/rationale` (get_application_rationale)
`applications.py:473-490`. `response_model=ApplicationRationaleResponse`, `dependencies=[Depends(require_application_member)]`.
- **Auth**: route dep. **Path**: `app_id`. **Response**: `ApplicationRationaleResponse` (§A6). **Status**: 200; 404 `APP_NOT_FOUND`.
- **Logic**: `return await rationale_svc.get_application_rationale(db, app_id)` (§H8).

---

### E10 — GET `/api/v1/applications/{app_id}/steps/{line}/{step}` (get_step_execution)
`applications.py:493-504`. `response_model=StepExecutionRecord`, `dependencies=[Depends(require_application_member)]`.
- ⚠️ GOTCHA — source has malformed indentation on the decorator line: `\n dependencies=[Depends(require_application_member)],)` (line 496). Functionally identical; reproduce the dependency regardless of formatting.
- **Auth**: route dep. **Path**: `app_id: uuid.UUID`, `line: AssemblyLineName` (enum-validated path param — invalid value → 422), `step: str`.
- **Response**: `StepExecutionRecord` (§A7). **Status**: 200; 404 `APP_NOT_FOUND`; 422 `UNKNOWN_STEP`.
- **Logic**: `return await app_svc.get_step_execution(db, app_id, line, step)` (§H9 — envelope-first then agent_task fallback).

---

### E11 — POST `/api/v1/applications/{app_id}/discover` (start_discovery)  ⟶ fires Temporal workflow
`applications.py:507-522`. `response_model=DiscoverResponse`, `status_code=202`, `dependencies=[Depends(require_application_member)]`.
- **Auth**: route dep. **Path**: `app_id`. Deps: `temporal: Client = Depends(get_temporal_client)`.
- **Body**: none. **Response**: `DiscoverResponse` (§A8). **Status**: 202; 404 `APP_NOT_FOUND`; 409 `DISCOVERY_ALREADY_RUNNING`.
- **Logic**: `config=get_config(); return await app_svc.start_discovery(db, app_id, temporal, config.temporal_task_queue)` (§H10 — starts `DiscoveryWorkflow`).
- "legacy shortcut over /workflow/start" (docstring).

---

### E12 — POST `/api/v1/applications/{app_id}/discovery/start` (start_discovery_alias)  ⟶ fires Temporal workflow
`applications.py:550-564`. `response_model=DiscoverResponse`, `status_code=202`, `dependencies=[Depends(require_application_member)]` (malformed-indent decorator, line 554).
- **Auth/Path/Deps/Body/Response/Status**: identical to E11.
- **Logic**: identical to E11 — `app_svc.start_discovery(...)`. 409 `DISCOVERY_ALREADY_RUNNING` if already running.

---

### E13 — POST `/api/v1/applications/{app_id}/discovery/retry` (retry_discovery)  ⟶ cancels + fires Temporal workflow
`applications.py:567-587`. `response_model=DiscoverResponse`, `status_code=202`, `dependencies=[Depends(require_application_member)]` (malformed-indent, line 571).
- **Auth**: route dep. **Path**: `app_id`. Deps: `temporal`. **Body**: none. **Response**: `DiscoverResponse`. **Status**: 202.
- **Logic** (`applications.py:578-587`):
```
config = get_config()
start = await workflow_control.retry_workflow(db, app_id, temporal, config.temporal_task_queue, config,
                                              from_line=AssemblyLineName.DISCOVERY)
return _to_discover_response(start)
```
- `_to_discover_response(start)` (`applications.py:541-547`): `DiscoverResponse(workflow_id=start.workflow_id, temporal_ui_url=start.temporal_ui_url, status="started")`.
- `retry_workflow` → §H13 (cancel-then-start from Discovery).

---

### E14 — POST `/api/v1/applications/{app_id}/discovery/rerun` (rerun_discovery)  ⟶ fires Temporal workflow
`applications.py:590-615`. `response_model=DiscoverResponse`, `status_code=202`, `dependencies=[Depends(require_application_member)]` (malformed-indent, line 594).
- **Auth/Path/Deps/Body/Response/Status**: as E13.
- **Logic** (`applications.py:606-615`):
```
config = get_config()
start = await workflow_control.start_line_workflow(db, app_id, AssemblyLineName.DISCOVERY,
                                                   temporal, config.temporal_task_queue, config)
return _to_discover_response(start)
```
- Starts a fresh Discovery WITHOUT terminating any running workflow. `start_line_workflow` raises 409 `WORKFLOW_ALREADY_RUNNING` if one is in flight. → §H11.

---

### E15 — GET `/api/v1/applications/{app_id}/workflow` (get_workflow)
`applications.py:623-635`. `response_model=WorkflowDetailsResponse`, `dependencies=[Depends(require_application_member)]`.
- **Auth**: route dep. **Path**: `app_id`. Deps: `temporal`. **Body**: none.
- **Response**: `WorkflowDetailsResponse` (§A9). **Status**: 200; 404 `APP_NOT_FOUND`.
- **Logic**: `config=get_config(); return await workflow_control.get_workflow_details(db, app_id, temporal, config)` (§H14 — Temporal describe + staleness math).

---

### E16 — POST `/api/v1/applications/{app_id}/workflow/start` (start_workflow)  ⟶ fires Temporal workflow
`applications.py:638-653`. `response_model=WorkflowStartResponse`, `status_code=202`, `dependencies=[Depends(require_application_member)]` (malformed-indent, line 642).
- **Auth**: route dep. **Path**: `app_id`. **Body**: `WorkflowStartRequest` (§A10: `{line: AssemblyLineName}`). Deps: `temporal`.
- **Response**: `WorkflowStartResponse` (§A11). **Status**: 202; 404 `APP_NOT_FOUND`; 409 `WORKFLOW_ALREADY_RUNNING`; 422 `WORKFLOW_NOT_IMPLEMENTED` / `INVALID_LINE_PREREQS`.
- **Logic**: `config=get_config(); return await workflow_control.start_line_workflow(db, app_id, body.line, temporal, config.temporal_task_queue, config)` (§H11).

---

### E17 — POST `/api/v1/applications/{app_id}/workflow/cancel` (cancel_workflow_route)  ⟶ fires Temporal cancel signal
`applications.py:656-668`. `response_model=WorkflowActionResponse`, `dependencies=[Depends(require_application_member)]`.
- **Auth**: route dep. **Path**: `app_id`. Deps: `temporal`. **Body**: none.
- **Response**: `WorkflowActionResponse` (§A12). **Status**: 200 (no explicit `status_code`); 404 `APP_NOT_FOUND`; 409 `WORKFLOW_NOT_RUNNING`.
- **Logic**: `config=get_config(); return await workflow_control.cancel_workflow(db, app_id, temporal, config)` (§H12 — signal `cancel_workflow` then scheduled hammer).

---

### E18 — POST `/api/v1/applications/{app_id}/workflow/retry` (retry_workflow_route)  ⟶ cancels + fires Temporal workflow
`applications.py:671-691`. `response_model=WorkflowStartResponse`, `status_code=202`, `dependencies=[Depends(require_application_member)]` (malformed-indent, line 675).
- **Auth**: route dep. **Path**: `app_id`. **Body**: `WorkflowRetryRequest | None = None` (§A13: `{from_line: AssemblyLineName | None}`); body is OPTIONAL. Deps: `temporal`.
- **Response**: `WorkflowStartResponse` (§A11). **Status**: 202; 404 `APP_NOT_FOUND`; 422 (prereq/not-implemented).
- **Logic** (`applications.py:683-691`):
```
config = get_config()
return await workflow_control.retry_workflow(db, app_id, temporal, config.temporal_task_queue, config,
                                             from_line=(body.from_line if body else None))
```
- → §H13.

---

### E19 — GET `/api/v1/applications/{app_id}/insights` (get_application_insights)
`applications.py:699-716`. `response_model=InsightsResponse`, `dependencies=[Depends(require_application_member)]`.
- **Auth**: route dep. **Path**: `app_id`. Deps: `config=Depends(get_config)`.
- **Response**: `InsightsResponse` (§A14). **Status**: 200.
- **Logic**: `return await insights_svc.get_insights(db, app_id, config=config)`. (Service in a separate module — `olympus-api/src/services/insights.py` — NOT reproduced here; falls back to reading `structural-analysis.json` when DB `decomposition_map` is sparse. Document its endpoint contract via the `InsightsResponse` shape.)

---

### E20 — GET `/api/v1/applications/{app_id}/decisions` (get_application_decisions)
`applications.py:719-729`. `response_model=DecisionsTimelineResponse`, `dependencies=[Depends(require_application_member)]`.
- **Auth**: route dep. **Path**: `app_id`. **Response**: `DecisionsTimelineResponse` (§A15). **Status**: 200.
- **Logic**: `return await insights_svc.get_decisions_timeline(db, app_id)`. (Service `insights.py` — reverse-chronological gate/escalation/rework timeline; contract = `DecisionsTimelineResponse`.)

---

### E21 — GET `/api/v1/applications/{app_id}/disposition-output` (get_application_disposition_output)
`applications.py:732-754`. **No `response_model`**; OpenAPI shape published via `responses={200: {"model": DispositionOutputBundle}}`. `dependencies=[Depends(require_application_member)]` (malformed-indent, line 740). Returns `dict` (raw bundle verbatim).
- **Auth**: route dep. **Path**: `app_id`.
- **Response**: raw JSON bundle matching `DispositionOutputBundle` (§A16). **Status**: 200; 404 `APP_NOT_FOUND` / `PORTFOLIO_NOT_CONFIGURED` / `DISPOSITION_OUTPUT_NOT_EMITTED`; 500 `GIT_NOT_CONFIGURED` / `DISPOSITION_OUTPUT_MALFORMED`; 502 `GIT_READ_FAILED`.
- **Logic**: `return await disposition_output_svc.get_disposition_output(db, app_id, get_config())` (§H15).

---

### E22 — GET `/api/v1/applications/{app_id}/dispositions` (get_application_dispositions)
`applications.py:757-801`. `response_model=AppDispositionResponse`, `dependencies=[Depends(require_application_member)]` (malformed-indent, line 760).
- **Auth**: route dep. **Path**: `app_id`. **Response**: `AppDispositionResponse` (§A17). **Status**: 200 (never 404 — empty rollup returns empty payload).
- **Handler logic** (inline, `applications.py:775-801`):
```
row = SELECT application_id, dispositions, target_services, rationalization_capability_ids
      FROM application_disposition WHERE application_id = :app_id
if row is None:
    return AppDispositionResponse(application_id=app_id)   # empty arrays default
return AppDispositionResponse(
    application_id=row["application_id"],
    dispositions=list(row["dispositions"] or []),
    target_services=list(row["target_services"] or []),
    rationalization_capability_ids=[str(rid) for rid in (row["rationalization_capability_ids"] or [])],
)
```
- ⚠️ GOTCHA — reads from a derived SQL VIEW `application_disposition` (migration 052). Absence ⇒ empty payload, NOT 404, so the UI falls back to the legacy `application.disposition` column.

---

## NEW ENDPOINTS AT HEAD `7cb3b20c` (E23–E30)

### E23 — GET `/api/v1/applications/{app_id}/design-artifacts` (list_design_artifacts) — Phase 6 W9 (P6-S9.3)
`applications.py:370-392`. `@router.get(..., response_model=DesignArtifactsResponse, dependencies=[Depends(require_application_member)])`.
- **Query**: `line: str|None=Query(None)`, `artifact_type: str|None=Query(None)`, `pagination=Depends(get_pagination)`. **Auth**: route dep only (`db` injected).
- **Handler**: `return await design_review_svc.list_design_artifacts(db, app_id, pagination, line=line, artifact_type=artifact_type)`. Filters the app's artifacts to the design "promotion list" (architecture/API/data/UX-UI), paginated (design §4.5). See services-logic spec for `design_review` body.

### E24 — POST `/api/v1/applications/{app_id}/design-feedback` (submit_design_feedback) — Phase 6 W9 (P6-S9.4)
`applications.py:395-415`. `@router.post(..., response_model=DesignFeedbackResponse, dependencies=[Depends(require_application_member)])`.
- **Body**: `DesignFeedbackRequest`. **Auth**: route dep + `user=Depends(get_current_user)`.
- **Handler**: `return await design_review_svc.submit_design_feedback(db, app_id, body, user.sub)`. ⚠️ Reuses the gate-review structured-feedback shape; `flag_for_revision` annotations are dispatched to the originating agent via the A2A skill-dispatch path; the line is NOT blocked and NO gate record is touched (design §5.3).

### E25 — POST `/api/v1/applications/{app_id}/interview` (start_interview) — Phase 6 W5 follow-on (P6-S5.12)
`applications.py:430-448`. `@router.post(..., response_model=InterviewSessionState, dependencies=[Depends(require_application_member)])`.
- **Body**: `StartInterviewRequest`. **Auth**: route dep + `user=Depends(get_current_user)`.
- **Handler**: `return await interview_svc.start_interview(db, app_id, body, user.sub)`. Starts OR resumes the active requirements-elicitation session (returns session id, first agent question, empty live artifact preview). ⚠️ Resumes the active session if one exists (pause/resume, design §3.3).

### E26 — GET `/api/v1/applications/{app_id}/interview` (get_interview) — P6-S5.12
`applications.py:451-461`. `@router.get(..., response_model=InterviewSessionState, dependencies=[Depends(require_application_member)])`.
- **Handler**: `return await interview_svc.get_session(db, app_id)`. Current interview session state for the live preview panel.

### E27 — POST `/api/v1/applications/{app_id}/interview/turns` (submit_interview_turn) — P6-S5.12
`applications.py:464-480`. `@router.post(..., response_model=InterviewSessionState, dependencies=[Depends(require_application_member)])`.
- **Body**: `SubmitTurnRequest`. **Handler**: `return await interview_svc.submit_turn(db, app_id, body)`. Appends the answer to the transcript, accumulates the partial `requirements-capability` artifact (persisted for pause/resume), advances the phase, returns the next question.

### E28 — POST `/api/v1/applications/{app_id}/interview/complete` (complete_interview) — P6-S5.12 ⟶ fires `interview_completed` signal
`applications.py:483-503`. `@router.post(..., response_model=CompleteInterviewResponse, dependencies=[Depends(require_application_member)])`.
- **Auth**: route dep + `user=Depends(get_current_user)`. **Handler**: `return await interview_svc.complete_interview(db, app_id, user.sub)`.
- ⚠️ Validates the accumulated `requirements-capability` artifact is conformant (every must-have capability has ≥1 acceptance criterion, design §3.3) BEFORE completing. On success: dispatches the `requirements-elicitation` skill (DECISION-018) and signals the waiting Discovery (Build-mode) workflow's `interview_completed` handler. Returns **200** with `artifact_valid=false` + validation errors when not complete enough (NOT a 4xx). See services-logic spec for the `interview` body.

### E29 — POST `/api/v1/applications/{app_id}/workflow/reset` (reset_workflow_route) — Phase 6 ⟶ Temporal reset/replay
`applications.py:847-873`. `@router.post(..., response_model=WorkflowResetResponse, dependencies=[Depends(require_application_member)])`.
- **Body**: `WorkflowResetRequest | None = None` (defaulted to `WorkflowResetRequest()` when omitted). **Deps**: `db`, `temporal=Depends(get_temporal_client)`; `config=get_config()`.
- **Handler**: `body = body or WorkflowResetRequest(); return await workflow_control.reset_workflow(db, app_id, temporal, ..., config=config)`.
- ⚠️ Unlike `retry` (E18 — kills the run, restarts the line from step 1), reset REWINDS the SAME run to a chosen `WORKFLOW_TASK_COMPLETED` event and replays forward, preserving prior completed work. Defaults to `before_failure` (resume just before the failed activity). See `specifications/phase-6/workflow-reset-resume.md`.

### E30 — GET `/api/v1/applications/{app_id}/gate-evidence` (get_application_gate_evidence) — perf #260
`applications.py:907-925`. `@router.get(..., response_model=list[GateEvidencePackage], dependencies=[Depends(require_application_member)])`.
- **Deps**: `db`, `config=Depends(get_config)`. **Handler**: `return await gate_svc.get_gate_evidence_for_application(db, app_id, config=config)`.
- ⚠️ Batches the per-gate evidence package for EVERY gate on the app into ONE request (newest-first), replacing N calls to `/gates/{id}/evidence`. Service `gate.get_gate_evidence_for_application` (`gate.py:1848`).

---

## ROUTER-LOCAL HELPERS

### §H1 `_resolve_portfolio_id(db, body_portfolio_id)` — `applications.py:93-124`
```
if body_portfolio_id:
    row = SELECT id FROM portfolio WHERE id = :id
    if row is None: raise OlympusHTTPException(404, "PORTFOLIO_NOT_FOUND", f"Portfolio {body_portfolio_id} not found.")
    return row["id"]
row = SELECT id FROM portfolio LIMIT 1
if row is None: raise OlympusHTTPException(400, "NO_PORTFOLIO", "No portfolio exists. Create a portfolio first.")
return row["id"]
```
Shared by E2 and E3 (identical lookup semantics).

### §H2 `_build_git_service_for_artifact_repo(config, repo)` — `applications.py:353-380`
```
if not repo or not getattr(config, "github_token", ""): return None
from src.services.git_service import GitService, GitServiceConfig, GitServiceError
try:
    return GitService(GitServiceConfig(token=config.github_token, repo=repo, base_url=config.github_base_url))
except GitServiceError:
    logger.exception("source_artifacts_index.git_service_init_failed", repo=repo); return None
```
Returns `None` (→ structured 404) instead of bubbling a 500.

### `_to_discover_response(start)` — `applications.py:541-547` (covered in E13).

---

## SERVICE LOGIC — Temporal-firing & non-trivial

### §H3 `application.create_application(db, body, portfolio_id, *, app_id=None, intake_result=None)` — `application.py:483-646`
```
is_non_git = body.source_type != GIT
if not is_non_git and not body.skip_repo_validation:
    _validate_source_repo(body, AppConfig())          # §H3a — 422 GIT_NOT_CONFIGURED / REPO_VALIDATION_FAILED
app_id = app_id or uuid.uuid4()
now = datetime.now(timezone.utc)
effective_repo_url = intake_result.local_path if intake_result is not None else body.repository_url

# Phase 5 capability resolution (fail-fast before INSERT):
resolved_capability_id = await _resolve_capability_id(db,
    capability_id=body.realizes_capability_id, capability_external_id=body.realizes_capability_external_id,
    target_system_id=body.target_system_id, portfolio_id=portfolio_id)   # §H3b → 422 codes

if body.target_system_id is not None:
    sys_row = SELECT id FROM system WHERE id=:id AND portfolio_id=:pid AND retired_at IS NULL
    if sys_row is None: raise OlympusHTTPException(422, "SYSTEM_NOT_FOUND",
        f"target_system_id {body.target_system_id} does not belong to this portfolio.")

initial_metadata = {}
if resolved_capability_id is not None: initial_metadata["capability_id"] = str(resolved_capability_id)

INSERT INTO application (id, portfolio_id, name, description, repo_url, source_git_token, source_git_base_url,
    risk_tier, complexity_tier, current_status, metadata, created_at, updated_at)
VALUES (:id, :portfolio_id, :name, :description, :repo_url, :source_git_token, :source_git_base_url,
    :risk_tier, :complexity_tier, 'onboarded', CAST(:metadata AS JSONB), :now, :now)
  -- source_git_token/base_url are NULL for non-Git sources
  -- risk_tier = str(body.risk_tier.value) if set else None ; complexity_tier = body.complexity_tier.value if set else None
  -- metadata = json.dumps(initial_metadata)

if body.target_system_id is not None:
    INSERT INTO system_application (system_id, application_id, role, created_at)
    VALUES (:sid, :app_id, 'primary', :now) ON CONFLICT (system_id, application_id) DO NOTHING

await db.commit()
return ApplicationDetail(id=app_id, name=body.name, description=body.description,
    repository_url=effective_repo_url, risk_tier=body.risk_tier,
    risk_tier_source="auto" if body.risk_tier else None,
    complexity_tier=body.complexity_tier, complexity_tier_source="auto" if body.complexity_tier else None,
    status="onboarded", tags=body.tags, created_at=now, updated_at=now)
```
- ⚠️ GOTCHA — `current_status` is the literal `'onboarded'`. Initial `risk_tier_source`/`complexity_tier_source` are `"auto"` only when a tier was supplied.
- ⚠️ GOTCHA — the returned `ApplicationDetail` does NOT re-read the row; it echoes inputs. `target_systems`/`realizes_capability`/`agent_activity_by_line`/`scores` are empty on the create response.

#### §H3a `_validate_source_repo(body, config)` — `application.py:448-480`
```
token = body.source_git_token or config.github_token
base_url = body.source_git_base_url or config.github_base_url
if not token: raise OlympusHTTPException(422, "GIT_NOT_CONFIGURED",
    "No Git credentials available. Provide app-specific credentials or configure GITHUB_TOKEN.")
try:
    git_svc = GitService(GitServiceConfig(token=token, repo=body.repository_url, base_url=base_url))
    git_svc.validate_repo_access(require_push=False)     # read-only check for source repos
except GitServiceError as exc: raise OlympusHTTPException(422, "REPO_VALIDATION_FAILED", str(exc))
except Exception as exc:
    logger.error(...); raise OlympusHTTPException(422, "REPO_VALIDATION_FAILED",
        f"Could not validate repository '{body.repository_url}': {exc}")
```

#### §H3b `_resolve_capability_id(db, *, capability_id, capability_external_id, target_system_id, portfolio_id)` — `application.py:357-445`
```
if capability_id is not None:
    if target_system_id is not None:
        row = SELECT system_id FROM capability WHERE id=:id AND retired_at IS NULL
        if row is None: raise 422 CAPABILITY_NOT_FOUND
        if row["system_id"] != target_system_id: raise 422 CAPABILITY_SYSTEM_MISMATCH
    return capability_id
if not capability_external_id: return None
if target_system_id is not None:
    row = SELECT id FROM capability WHERE external_id=:ext AND system_id=:sid AND retired_at IS NULL
else:
    row = SELECT c.id FROM capability c JOIN system s ON s.id=c.system_id
          WHERE c.external_id=:ext AND s.portfolio_id=:pid AND c.retired_at IS NULL AND s.retired_at IS NULL LIMIT 1
if row is None: raise 422 CAPABILITY_EXTERNAL_ID_NOT_FOUND
return row["id"]
```

### §H4 `application.get_application(db, app_id)` — `application.py:735-786`
```
row = SELECT * FROM application WHERE id=:id
if row is None: raise OlympusHTTPException(404, "APP_NOT_FOUND", ...)
scores = await _fetch_latest_scores(db, app_id)               # §H4a
target_systems = await fetch_target_systems_for_app(db, app_id)        # §H4b
realizes_capability = await fetch_realizes_capability_for_app(db, app_id)  # §H4c
agent_activity = await fetch_agent_activity_by_line(db, app_id)        # §H4d
return ApplicationDetail(id, name, description, repository_url=row["repo_url"], target_repo_url, target_git_base_url,
    disposition=row["disposition"], risk_tier=int(row["risk_tier"]) if row["risk_tier"] else None,
    risk_tier_source, complexity_tier, complexity_tier_source, current_line=row["current_line"],
    status=row["current_status"], metadata=row.get("metadata") or {}, scores=scores,
    target_systems, realizes_capability, agent_activity_by_line=agent_activity,
    created_at, updated_at)
```
- §H4a `_fetch_latest_scores` (`application.py:63-93`): `SELECT dimension, score FROM score_history WHERE application_id=:app_id AND recorded_at=(SELECT MAX(recorded_at) ...)`; maps dims → `ReadinessScores(overall, code_quality, test_coverage, security_posture, documentation, dependency_currency, architecture_clarity)`; `None` if no rows.
- §H4b `fetch_target_systems_for_app` (`application.py:96-136`): join `system_application` → `system`, `retired_at IS NULL`, ORDER BY role (primary=0,contributing=1,deprecated=2,else 3) then `COALESCE(external_id,name)`; → `list[SystemRef]`.
- §H4c `fetch_realizes_capability_for_app` (`application.py:139-246`): reads `application.metadata.capability_id` (UUID); if absent → `None`; else loads the `capability` (+ system) row; then loads M:N target systems via `capability_lineage` where `source_capability_id=:cap_id`; returns `CapabilityRef`.
- §H4d `fetch_agent_activity_by_line` (`application.py:269-354`): `SELECT DISTINCT ON (COALESCE(se.line_id,'unknown')) ...` from `agent_task at LEFT JOIN step_execution se ON se.agent_task_id=at.id WHERE at.application_id=:app_id` newest-first; maps line slug→`AssemblyLineName`; `actor_kind` defaults `"olympus_agent"`; sorts lines-with-value first (alphabetical), unknown last. → `list[AgentActivitySummary]`.
- ⚠️ All four enrichments are best-effort per docstring (failure to fetch a surface ⇒ empty value, not 500) — but as written each is a plain `await` with no try/except, so a raised exception WOULD propagate. Preserve the call order.

### §H5 `application.update_application(db, app_id, body)` — `application.py:789-838`
```
row = SELECT id FROM application WHERE id=:id
if row is None: raise OlympusHTTPException(404, "APP_NOT_FOUND", ...)
field_map = {}   # only non-None ApplicationUpdate fields, mapped to DB columns:
  name->name, description->description, repository_url->repo_url, target_repo_url->target_repo_url,
  target_git_token->target_git_token, target_git_base_url->target_git_base_url,
  risk_tier->str(risk_tier.value), complexity_tier->complexity_tier.value, disposition->disposition.value
if field_map:
    set_clauses = ", ".join(f"{col} = :{col}") + ", updated_at = :now"
    UPDATE application SET {set_clauses} WHERE id=:id; await db.commit()
return await get_application(db, app_id)     # §H4 — full enriched re-read
```
- ⚠️ GOTCHA — when `body` has all-None fields, no UPDATE runs but the function still returns the enriched detail (no error). `disposition`/tiers stored as enum `.value` strings.

### §H6 `application.get_application_status(db, app_id)` — `application.py:841-967`
Hardened against 500s (P5-AUDIT-002).
```
row = SELECT * FROM application WHERE id=:id
if row is None: raise OlympusHTTPException(404, "APP_NOT_FOUND", ...)
gate_rows = SELECT * FROM gate WHERE application_id=:app_id ORDER BY requested_at
gates = []
for g in gate_rows:
    try: gates.append(GateSummaryForStatus(id, gate_type, status, sla_deadline, decided_at,
                                            reject_reason_category, justification))
    except Exception as exc: logger.warning("application_status.skip_unrecognised_gate", ...); continue   # ⚠️ skip bad gate
pending_gate = None
for g in gate_rows:
    if g["status"] == "pending":
        try: pending_gate = g["gate_type"]
        except Exception: pending_gate = None
        break
current_line=row["current_line"]; current_step=row["current_step"]
progress_pct = STEP_PROGRESS.get((current_line, current_step)) if current_line and current_step else None
try:
    return ApplicationStatus(app_id=row["id"], current_line, current_step, progress_pct, pending_gate,
        workflow_status=row["current_status"], workflow_id=row.get("workflow_id"), gates=gates, updated_at=row["updated_at"])
except Exception as exc:
    logger.warning("application_status.fallback_envelope", ...)
    return ApplicationStatus(app_id=row["id"], current_line=None, current_step=None, progress_pct=None,
        pending_gate=None, workflow_status="pending", workflow_id=row.get("workflow_id"), gates=[], updated_at=row.get("updated_at"))
```
- `STEP_PROGRESS` = `_load_step_progress()` (`application.py:41-60`): for each line, `(line, step_id) -> float(pct)` from contracts + a synthetic `(line, "completed") -> 100.0`.
- ⚠️ GOTCHA — two-layer defence: bad gate rows are skipped individually; if the envelope itself fails validation, a degraded `workflow_status="pending"` envelope is returned. Never 500 on a real app.

### §H7 `lineage.get_application_lineage(db, app_id)` — `lineage.py:25-112`
```
exists = SELECT 1 FROM application WHERE id=:id
if exists is None: raise OlympusHTTPException(404, "APP_NOT_FOUND", ...)
source_rows = SELECT al.source_app_id AS related_app_id, a.name AS related_app_name, al.relationship,
              al.created_at, al.retired_at FROM application_lineage al JOIN application a ON a.id=al.source_app_id
              WHERE al.target_app_id=:app_id ORDER BY al.created_at ASC, a.name ASC
target_rows = SELECT al.target_app_id AS related_app_id, a.name AS related_app_name, al.relationship,
              al.created_at, al.retired_at, a.target_repo_url, a.disposition FROM application_lineage al
              JOIN application a ON a.id=al.target_app_id WHERE al.source_app_id=:app_id
              ORDER BY al.created_at ASC, a.name ASC
return ApplicationLineageResponse(app_id,
    sources=[LineageEdge(related_app_id, related_app_name, relationship, created_at, retired_at) for r in source_rows],
    targets=[LineageEdge(..., target_repo_url, disposition) for r in target_rows])
```
- ⚠️ `sources` edges DON'T carry `target_repo_url`/`disposition` (null); `targets` edges DO.

### §H8 `rationale.get_application_rationale(db, app_id)` — `rationale.py:49-229`
```
exists = SELECT 1 FROM application WHERE id=:id
if exists is None: raise OlympusHTTPException(404, "APP_NOT_FOUND", ...)
source_rows = SELECT al.source_app_id, a.name AS source_app_name, a.disposition, al.relationship
              FROM application_lineage al JOIN application a ON a.id=al.source_app_id
              WHERE al.target_app_id=:app_id ORDER BY al.created_at ASC, a.name ASC
if not source_rows: return ApplicationRationaleResponse(app_id, is_target=False, sources=[])
blocks=[]
for src in source_rows:
    gates, wave_id = await _load_rationalization_gates(db, src["source_app_id"])   # below
    artifacts = _artifact_refs_for_source(src["source_app_id"], wave_id)           # below
    blocks.append(RationaleSourceBlock(source_app_id, source_app_name, disposition, relationship, gates, artifacts))
return ApplicationRationaleResponse(app_id, is_target=True, sources=blocks)
```
- `_RATIONALE_GATE_TYPES = ("G-DC","G-RR","G-DA")`.
- `_load_rationalization_gates` (`rationale.py:116-182`): `SELECT g.id, g.gate_type, g.status, g.decided_at, g.decided_by, g.justification, g.reject_reason_category AS reason_category, g.evidence_package_url, g.wave_id, g.application_id FROM gate g WHERE g.gate_type = ANY(:types) AND (g.application_id=:app_id OR (g.wave_id IS NOT NULL AND (g.application_id IS NULL OR g.application_id=:app_id))) ORDER BY g.requested_at ASC`; `wave_id` = most-recent non-null wave_id scanning `reversed(rows)` (prefers G-DA, falls back to G-RR). Returns `(list[RationaleGateEntry], wave_id)`.
- `_artifact_refs_for_source` (`rationale.py:185-229`): if `wave_id is None` → `[]`; else 6 `RationaleArtifactRef` rows under `rationalization/wave-{wave_id}`: `{app_id}/disposition-recommendation.json`, `{app_id}/disposition-governance.json`, `{app_id}/classification.json`, `{app_id}/user-impact-analysis.json`, `redundancy-matrix.json`, `business-rule-redundancy.json`.

### §H9 `application.get_step_execution(db, app_id, line, step)` — `application.py:1366-1585`
```
app_row = SELECT id, current_line, current_step FROM application WHERE id=:id
if app_row is None: raise OlympusHTTPException(404, "APP_NOT_FOUND", ...)
if not step_mapping.is_known_step(line, step):
    valid = step_mapping.steps_for(line)
    raise OlympusHTTPException(422, "UNKNOWN_STEP", f"Unknown step '{step}' for line '{line.value}'. Valid steps: {valid}")

# ── Layer B envelope path ──
envelope_row = SELECT execution_id, step_kind, status, started_at, completed_at, duration_ms, attempt,
    last_error, input_artifacts, output_artifacts, payload, agent_task_id, gate_id FROM step_execution
    WHERE app_id=:app_id AND (line_id=:line_lower OR line_id=:line_enum) AND step_id=:step_id
    ORDER BY started_at DESC NULLS LAST, completed_at DESC NULLS LAST LIMIT 1
    -- line_lower = line.value.lower().replace(" ","-") ; line_enum = line.value
if envelope_row is not None:
    return await _step_execution_from_envelope(db, app_id, line, step, dict(envelope_row))   # §H9a

# ── Legacy agent_task-merge fallback ──
task_types = step_mapping.task_types_for(line, step)
task_rows = [] ; if task_types: task_rows = SELECT id, task_type, status, dispatched_at, completed_at,
    duration_ms, retry_count, last_error, input_artifact_refs, output_artifact_ref, token_usage, cost_estimate
    FROM agent_task WHERE application_id=:app_id AND task_type = ANY(:task_types) ORDER BY dispatched_at ASC NULLS LAST
status = _status_from_task_rows(task_rows)         # §H9b
if status == "not_started":
    inferred = _infer_status_from_progress(line, step, app_row.current_line, app_row.current_step)  # §H9c
    if inferred is not None: status = inferred
started_at = first non-null dispatched_at
completed_at = max(completed_at) IF all rows have completed_at else None
duration_ms = sum(duration_ms) IF all rows have duration_ms else None
retry_count = sum(retry_count or 0)
last_error = last non-null last_error scanning reversed(task_rows)
token_totals/cost_estimate = summed across rows when present
input_artifacts = dedup by path via _artifact_from_ref(item,"input")   # §H9d
output_artifact = last _artifact_from_ref(output_artifact_ref,"output")
gate_summary = None ; gate_type = step_mapping.gate_for(line, step)
if gate_type is not None:
    gate_row = SELECT id, gate_type, status FROM gate WHERE application_id=:app_id AND gate_type=:gate_type
               ORDER BY requested_at DESC LIMIT 1
    if gate_row: gate_summary = StepGateSummary(...); if status=='pending'... actually: if gate_row["status"]=="pending" and status!="failed": status="running"
escalations_count = SELECT COUNT(*) FROM escalation WHERE application_id=:app_id AND line=:line AND step=:step
return StepExecutionRecord(app_id, line, step, status, started_at, completed_at, duration_ms, retry_count,
    last_error, agent_task_ids=[r["id"]...], token_usage=token_totals, cost_estimate, input_artifacts,
    output_artifact, gate=gate_summary, escalations_count)
```
- §H9a `_step_execution_from_envelope` (`application.py:1218-1363`): projects the envelope row; `_coerce_json` JSON-decodes string columns; `input_artifacts`/`output_artifacts` via `_envelope_artifact_refs` (output_artifact = first of output list); token/cost from linked `agent_task` (fallback to payload `token_usage`/`cost_estimate_usd`); gate via `gate_id` FK; `escalations_count` scoped to line+step; `retry_count = max(attempt-1, 0)`; sets `step_kind`, `payload`, `attempt`.
- §H9b `_status_from_task_rows` (`application.py:1107-1124`): `[] → "not_started"`; `failed`∈ → `"failed"`; `timed_out`∈ → `"timed_out"`; `running`/`dispatched`∈ → `"running"`; `queued` only → `"queued"`; all `completed` → `"completed"`; else `"running"`.
- §H9c `_infer_status_from_progress` (`application.py:1144-1184`): uses `step_mapping.steps_for(line)` ordering + `_LINE_ORDER`; later-line ⇒ `"completed"`; same-line earlier step ⇒ `"completed"`, same step ⇒ `"running"`, else `None`.
- §H9d `_artifact_from_ref` (`application.py:1074-1104`) + `_looks_like_artifact_path` (`application.py:1054-1071`): rejects prose; str refs → title = basename; dict refs → path from `path`|`url`.

### §H10 `application.start_discovery(db, app_id, temporal_client, task_queue)` — `application.py:970-1046`  ⟶ STARTS WORKFLOW
```
row = SELECT id, name, portfolio_id, current_status, repo_url FROM application WHERE id=:id
if row is None: raise OlympusHTTPException(404, "APP_NOT_FOUND", ...)
if row["current_status"] == "discovery_in_progress":
    raise OlympusHTTPException(409, "DISCOVERY_ALREADY_RUNNING", "Discovery workflow is already running for this application.")
portfolio_row = SELECT artifact_repo_url FROM portfolio WHERE id=:id
artifact_repo = (portfolio_row["artifact_repo_url"] or "") if portfolio_row else ""
run_ts = int(datetime.now(timezone.utc).timestamp())
workflow_id = f"discovery-{app_id}-{run_ts}"
await temporal_client.start_workflow("DiscoveryWorkflow",
    {"app_id": str(app_id), "app_name": row["name"], "wave_id": "", "portfolio_id": str(row["portfolio_id"]),
     "artifact_repo": artifact_repo, "source_repo": row["repo_url"] or ""},
    id=workflow_id, task_queue=task_queue)
UPDATE application SET current_status='discovery_in_progress', current_line='Discovery',
    current_step='catalog-dispatch', workflow_id=:workflow_id, updated_at=:now WHERE id=:id
await db.commit()
return DiscoverResponse(workflow_id=workflow_id,
    temporal_ui_url=f"http://localhost:8080/namespaces/default/workflows/{workflow_id}")
```
- ⚠️ GOTCHA — workflow started by **string name** `"DiscoveryWorkflow"`; payload dict serialized to JSON (worker deserializes to `LineWorkflowInput`). `current_step` set to literal `'catalog-dispatch'`.
- ⚠️ GOTCHA — `temporal_ui_url` here is HARDCODED `http://localhost:8080/namespaces/default/...` (unlike workflow_control which uses `config.temporal_ui_base_url`). Preserve the hardcode for this path.

### §H11 `workflow_control.start_line_workflow(db, app_id, line, temporal, task_queue, config)` — `workflow_control.py:147-234`  ⟶ STARTS WORKFLOW
```
workflow_name = _workflow_name_for(line)     # _LINE_TO_WORKFLOW; else 422 WORKFLOW_NOT_IMPLEMENTED
row = await _fetch_app_row(db, app_id)        # SELECT id,name,portfolio_id,current_status,current_line,current_step,workflow_id,repo_url,updated_at; 404 APP_NOT_FOUND
if row["current_status"] and str(row["current_status"]).endswith("_in_progress"):
    raise OlympusHTTPException(409, "WORKFLOW_ALREADY_RUNNING", "A workflow is already running for this application. Cancel it first.")
required = _LINE_PREREQS.get(line)            # MODERNIZATION:{Refactor,Rearchitect}; DISPOSITION_EXECUTION:{Retire,Retain,Replace,Replatform,Consolidate}
if required:
    disposition = await _fetch_disposition(db, app_id)   # SELECT disposition FROM application
    if disposition not in required:
        raise OlympusHTTPException(422, "INVALID_LINE_PREREQS",
            f"{line.value} requires the application's disposition to be one of {sorted(required)}; current disposition is {disposition!r}.")
portfolio_row = SELECT artifact_repo_url FROM portfolio WHERE id=:id
artifact_repo = (portfolio_row["artifact_repo_url"] or "") if portfolio_row else ""
run_ts = int(datetime.now(timezone.utc).timestamp())
workflow_id = f"{line.value.lower().replace(' ', '-')}-{app_id}-{run_ts}"
await temporal.start_workflow(workflow_name,
    {"app_id": str(app_id), "app_name": row["name"], "wave_id": "", "portfolio_id": str(row["portfolio_id"]),
     "artifact_repo": artifact_repo, "source_repo": row["repo_url"] or ""}, id=workflow_id, task_queue=task_queue)
now = datetime.now(timezone.utc)
UPDATE application SET current_status=:status, current_line=:line, current_step=NULL, workflow_id=:workflow_id, updated_at=:now WHERE id=:id
   -- status = f"{line.value.lower().replace(' ', '_')}_in_progress" ; line = line.value
await db.commit()
return WorkflowStartResponse(workflow_id=workflow_id, line=line, temporal_ui_url=await _temporal_ui_url(config, workflow_id))
```
- `_LINE_TO_WORKFLOW` (`workflow_control.py:51-59`): Discovery→`DiscoveryWorkflow`, Rationalization→`RationalizationWorkflow`, Architecture→`ArchitectureWorkflow`, Data→`DataWorkflow`, Modernization→`ModernizationWorkflow`, Validation→`ValidationWorkflow`, Deployment→`DeploymentWorkflow`. (Disposition Execution, Sustainment, Governance NOT mapped ⇒ 422 `WORKFLOW_NOT_IMPLEMENTED`.)
- `_temporal_ui_url(config, wf_id)` (`workflow_control.py:140-144`): `f"{config.temporal_ui_base_url.rstrip('/')}/namespaces/{config.temporal_namespace}/workflows/{workflow_id}"`.
- ⚠️ GOTCHA — `workflow_id` format differs from §H10: here `{line-slug}-{app_id}-{ts}` (Discovery slug = `"discovery"`, matching `discovery-...`); status format `{line_underscored}_in_progress`. `current_step` set to `NULL` (unlike §H10's `catalog-dispatch`).

### §H12 `workflow_control.cancel_workflow(db, app_id, temporal, config)` — `workflow_control.py:237-296`  ⟶ FIRES `cancel_workflow` SIGNAL
```
row = await _fetch_app_row(db, app_id)        # 404 APP_NOT_FOUND
workflow_id = row.get("workflow_id")
if not workflow_id: raise OlympusHTTPException(409, "WORKFLOW_NOT_RUNNING", "No workflow is associated with this application.")
handle = temporal.get_workflow_handle(workflow_id)
try: await handle.signal("cancel_workflow")                # signal the HILSignalsMixin first
except RPCError as e: logger.warning("cancel_signal_failed", ...)   # swallow
# scheduled hammer:
async def _hammer():
    await asyncio.sleep(config.workflow_cancel_grace_seconds)
    try:
        desc = await handle.describe()
        if desc.status is not None and desc.status.name == "RUNNING":
            await handle.cancel(); logger.info("cancel_hammer_invoked", ...)
    except RPCError as e: logger.warning("cancel_hammer_failed", ...)
asyncio.create_task(_hammer())     # fire-and-forget
now = datetime.now(timezone.utc)
UPDATE application SET current_status='cancelled', updated_at=:now WHERE id=:id ; await db.commit()
return WorkflowActionResponse(workflow_id=workflow_id, requested=True,
    detail=f"Cancellation requested. The workflow will stop within {config.workflow_cancel_grace_seconds}s.")
```
- ⚠️ GOTCHA — signal name is the literal string `"cancel_workflow"`. The DB status is set to `'cancelled'` (double-L) immediately, before the hammer runs. The hammer is a detached `asyncio.create_task` (`# noqa: RUF006`) — exceptions logged, never block response.

### §H13 `workflow_control.retry_workflow(db, app_id, temporal, task_queue, config, from_line=None)` — `workflow_control.py:299-325`  ⟶ CANCEL + START
```
row = await _fetch_app_row(db, app_id)        # 404 APP_NOT_FOUND
target_line = from_line or _parse_line(row.get("current_line")) or AssemblyLineName.DISCOVERY
if row.get("workflow_id") and str(row.get("current_status","")).endswith("_in_progress"):
    try: await cancel_workflow(db, app_id, temporal, config)        # §H12
    except OlympusHTTPException as e:
        if e.code != "WORKFLOW_NOT_RUNNING": raise                  # swallow only "not running"
return await start_line_workflow(db, app_id, target_line, temporal, task_queue, config)   # §H11
```
- `_parse_line(value)` (`workflow_control.py:328-334`): `AssemblyLineName(value)` or `None` on ValueError/empty.
- ⚠️ GOTCHA — cancel sets status `'cancelled'` (not `*_in_progress`) before the subsequent `start_line_workflow`, so the 409 ALREADY_RUNNING guard passes. Default target line is Discovery when none given/parseable.

### §H14 `workflow_control.get_workflow_details(db, app_id, temporal, config)` — `workflow_control.py:337-441`
```
row = await _fetch_app_row(db, app_id)        # 404 APP_NOT_FOUND
workflow_id = row.get("workflow_id")
response = WorkflowDetailsResponse(app_id, workflow_id, reported_status=row.get("current_status"),
    current_line=_parse_line(row.get("current_line")), current_step=row.get("current_step"),
    recent_errors=await _recent_errors(db, app_id))     # §H14a
if not workflow_id: return response
handle = temporal.get_workflow_handle(workflow_id)
try: desc = await handle.describe()
except RPCError as e:
    is_not_found = (getattr(e,"status",None)==RPCStatusCode.NOT_FOUND
        or "workflow not found" in str(e).lower() or "workflow execution not found" in str(e).lower())
    if is_not_found:
        response.temporal_status = _temporal_status_from_app_status(row.get("current_status"))   # map below
        response.temporal_ui_url = await _temporal_ui_url(config, workflow_id)
        return response
    response.temporal_unreachable = True ; return response
response.temporal_status = desc.status.name if desc.status else None
response.started_at = desc.start_time
response.history_length = desc.history_length
response.temporal_ui_url = await _temporal_ui_url(config, workflow_id)
# best-effort get_status query:
last_event_at=None; pending_gate=None
try:
    status = await handle.query("get_status")
    if isinstance(status, dict):
        raw = status.get("updated_at"); if isinstance(raw,str): last_event_at = datetime.fromisoformat(raw.replace("Z","+00:00")) (or None on ValueError)
        gate_raw = status.get("pending_gate"); if isinstance(gate_raw,str) and gate_raw: pending_gate = gate_raw
except RPCError: pass
response.last_event_at = last_event_at
now = datetime.now(timezone.utc)
if response.started_at: response.duration_seconds = int((now - response.started_at).total_seconds())
reference_ts = last_event_at or row.get("updated_at") or response.started_at
if reference_ts:
    if reference_ts.tzinfo is None: reference_ts = reference_ts.replace(tzinfo=timezone.utc)
    staleness = int((now - reference_ts).total_seconds())
    response.staleness_seconds = staleness
    response.is_stale = (response.temporal_status == "RUNNING" and pending_gate is None
                         and staleness > config.workflow_staleness_minutes * 60)
return response
```
- `_temporal_status_from_app_status` via `_APP_STATUS_TO_TEMPORAL` (`workflow_control.py:117-137`): `completed→COMPLETED, failed→FAILED, cancelled/canceled→CANCELED, stuck/stuck-awaiting-recovery→FAILED, in_progress/running/ready/draft→None`.
- §H14a `_recent_errors` (`workflow_control.py:444-475`): `SELECT id, task_type, status, last_error, completed_at, retry_count FROM agent_task WHERE application_id=:app_id AND status IN ('failed','timed_out') ORDER BY completed_at DESC NULLS LAST LIMIT 5` → `list[WorkflowRecentError]`.
- ⚠️ GOTCHA — NOT_FOUND from Temporal is the routine "history aged out" case → synthesize status from app row (does NOT set `temporal_unreachable`). Any other RPCError → `temporal_unreachable=True`. Gate-waiting workflows (`pending_gate` set) are NEVER flagged stale.

### §H15 `disposition_output.get_disposition_output(db, app_id, config)` — `disposition_output.py:76-156`
```
portfolio_id, artifact_repo = await _load_app_portfolio(db, app_id)   # below
token = config.github_token
if not token: raise OlympusHTTPException(500, "GIT_NOT_CONFIGURED", "GITHUB_TOKEN is not set on the API service.")
path = f"dispositions/{portfolio_id}/{app_id}/disposition-output.json"
try:
    git_svc = GitService(GitServiceConfig(token=token, repo=artifact_repo, base_url=config.github_base_url))
    result = git_svc.read_file(path=path, branch="main")
except GitServiceError as exc:
    message = str(exc)
    if "not found on ref" in message or " 404" in message:
        raise OlympusHTTPException(404, "DISPOSITION_OUTPUT_NOT_EMITTED", "Disposition output bundle has not been emitted yet.")
    logger.warning("disposition_output_git_read_failed", ...)
    raise OlympusHTTPException(502, "GIT_READ_FAILED", f"Could not read disposition output: {message}")
try: bundle = json.loads(result.content)
except json.JSONDecodeError as exc:
    logger.error("disposition_output_malformed", ...)
    raise OlympusHTTPException(500, "DISPOSITION_OUTPUT_MALFORMED", "Disposition output bundle exists but is not valid JSON.")
return bundle    # raw dict, returned verbatim
```
- `_load_app_portfolio` (`disposition_output.py:38-73`): `SELECT a.portfolio_id, p.artifact_repo_url FROM application a JOIN portfolio p ON a.portfolio_id=p.id WHERE a.id=:app_id`; None → 404 `APP_NOT_FOUND`; empty artifact_repo → 404 `PORTFOLIO_NOT_CONFIGURED`.
- ⚠️ GOTCHA — "file missing" is detected by substring match on the exception message (`"not found on ref"` or `" 404"`) → 404; everything else → 502.

---

## §S1 — source_intake providers (`olympus-api/src/services/source_intake.py`)
Error class `SourceIntakeError(code, message)`; subclass `SourceIntakeNotImplemented` (scaffolds).
- `build_provider(source_type, *, max_upload_bytes, s3_region=None, s3_client_factory=None)` (`source_intake.py:571-610`): `GIT` → raises `SourceIntakeError("NOT_A_NON_GIT_SOURCE",...)`; `ZIP`→`ZipSourceProvider`; `S3`→`S3SourceProvider`; `confluence/sharepoint/gdrive/gcs`→scaffold providers (raise `SourceIntakeNotImplemented("SOURCE_TYPE_NOT_IMPLEMENTED",...)` on `unpack`).
- `destination_for(root, app_id)` → `Path(root) / str(app_id)`.
- `_LimitedReader` (`source_intake.py:118-157`): raises `SourceIntakeError("UPLOAD_TOO_LARGE",...)` if `declared_size > limit` up front, or if streamed bytes exceed `limit`.
- ZipSourceProvider.unpack (`source_intake.py:218-318`): codes `UPLOAD_MISSING` (no stream), `UPLOAD_TOO_LARGE`, `UNSAFE_ZIP_ENTRY` (abs path / drive / `..`), `BAD_ZIP`. Strips single common top-level dir; rejects entries escaping root. Returns `SourceIntakeResult(source_type, local_path=str(destination), byte_size, file_count, notes)`.
- S3SourceProvider.unpack (`source_intake.py:399-476`): codes `SOURCE_URI_MISSING`, `BAD_S3_URI`, `UNSAFE_S3_KEY`, `S3_FETCH_FAILED`, `S3_PREFIX_EMPTY`, `BOTO3_MISSING`. Walks `s3://bucket/prefix` via boto3 paginator, strips prefix, rejects unsafe keys.

---

## APPENDIX A — Pydantic models (`olympus-api/src/models/application.py` unless noted)

### §A1 `ApplicationDetail` (`application.py:243-306`) — response_model for E2/E3/E4/E5; list items in E1
`id: UUID`; `name: str`; `description: str|None=None`; `repository_url: str|None=None`; `target_repo_url: str|None=None`; `target_git_base_url: str|None=None`; `disposition: Disposition|None=None`; `risk_tier: RiskTier|None=None`; `risk_tier_source: TierSource|None=None`; `complexity_tier: ComplexityTier|None=None`; `complexity_tier_source: TierSource|None=None`; `current_line: AssemblyLineName|None=None`; `status: str|None=None`; `wave_id: UUID|None=None`; `scores: ReadinessScores|None=None`; `tags: dict[str,str]={}`; `metadata: dict={}` (JSONB extensibility); `created_at: datetime|None=None`; `updated_at: datetime|None=None`; `target_systems: list[SystemRef]=[]`; `realizes_capability: CapabilityRef|None=None`; `agent_activity_by_line: list[AgentActivitySummary]=[]`.
- `SystemRef` (`application.py:32-46`): `id: UUID; name: str; external_id: str|None; kind: str|None; role: str|None`.
- `CapabilityRef` (`application.py:49-68`): `id: UUID; name: str; external_id: str|None; system_id: UUID; system_name: str; system_external_id: str|None; primary_disposition: str|None; secondary_disposition: str|None; target_systems: list[SystemRef]=[]`.
- `AgentActivitySummary` (`application.py:71-91`): `task_id: UUID; line: AssemblyLineName|None; skill_id: str|None; task_type: str|None; status: str|None; actor_kind: ActorKind="olympus_agent"; local_agent_descriptor: LocalAgentDescriptor|None; human_user_id: str|None; started_at: datetime|None; completed_at: datetime|None`.
- `ReadinessScores` (`common.py:120-127`): `overall, code_quality, test_coverage, security_posture, documentation, dependency_currency, architecture_clarity` — all `float|None=None`.

### §A2 `ApplicationCreate` (`application.py:94-208`) — request body E2
`name: str`; `description: str|None=None`; `source_type: SourceType=GIT`; `repository_url: str|None=None`; `source_uri: str|None=None`; `portfolio_id: UUID|None=None`; `source_git_token: str|None=None`; `source_git_base_url: str|None=None`; `skip_repo_validation: bool=False`; `risk_tier: RiskTier|None=None`; `complexity_tier: ComplexityTier|None=None`; `tags: dict[str,str]={}`; `target_system_id: UUID|None=None`; `realizes_capability_id: UUID|None=None`; `realizes_capability_external_id: str|None=None`.
- **model_validator(after)** `_validate_source` (`application.py:184-208`): GIT ⇒ `repository_url` required (else ValueError → 422); ZIP ⇒ skip; else ⇒ `source_uri` required.

### §A3 `ApplicationUpdate` (`application.py:228-240`) — request body E5
All optional: `name: str|None`; `description: str|None`; `repository_url: str|None`; `target_repo_url: str|None`; `target_git_token: str|None`; `target_git_base_url: str|None`; `risk_tier: RiskTier|None`; `complexity_tier: ComplexityTier|None`; `disposition: Disposition|None`; `tags: dict[str,str]|None`.

### §A4 `ApplicationStatus` (`application.py:364-376`) — response E6
`app_id: UUID`; `current_line: AssemblyLineName|None`; `current_step: str|None`; `progress_pct: float|None`; `pending_gate: GateType|None`; `workflow_status: str|None`; `workflow_id: str|None`; `gates: list[GateSummaryForStatus]=[]`; `started_at: datetime|None`; `updated_at: datetime|None`.
- `GateSummaryForStatus` (`application.py:346-361`): `id: UUID; gate_type: GateType; status: GateStatus; sla_deadline: datetime|None; decided_at: datetime|None; reject_reason_category: str|None; justification: str|None`.

### §A5 `ApplicationLineageResponse` (`application.py:637-648`) — response E7
`app_id: UUID`; `sources: list[LineageEdge]=[]`; `targets: list[LineageEdge]=[]`.
- `LineageEdge` (`application.py:614-635`): `related_app_id: UUID; related_app_name: str; relationship: str (LineageRelationship); created_at: datetime; retired_at: datetime|None; target_repo_url: str|None; disposition: str|None`.

### §A6 `ApplicationRationaleResponse` (`application.py:695-711`) — response E9
`app_id: UUID`; `is_target: bool=False`; `sources: list[RationaleSourceBlock]=[]`.
- `RationaleSourceBlock` (`application.py:679-692`): `source_app_id: UUID; source_app_name: str; disposition: str|None; relationship: str; gates: list[RationaleGateEntry]=[]; artifacts: list[RationaleArtifactRef]=[]`.
- `RationaleGateEntry` (`application.py:656-666`): `gate_id: UUID; gate_type: GateType; status: GateStatus; decided_at: datetime|None; decided_by: str|None; justification: str|None; reason_category: str|None; evidence_package_url: str|None`.
- `RationaleArtifactRef` (`application.py:669-676`): `label: str; path: str; kind: str|None`.

### §A7 `StepExecutionRecord` (`application.py:413-447`) — response E10
`app_id: UUID`; `line: AssemblyLineName`; `step: str`; `status: str="not_started"`; `started_at: datetime|None`; `completed_at: datetime|None`; `duration_ms: int|None`; `retry_count: int=0`; `last_error: str|None`; `agent_task_ids: list[UUID]=[]`; `token_usage: dict|None`; `cost_estimate: float|None`; `input_artifacts: list[StepArtifactRef]=[]`; `output_artifact: StepArtifactRef|None`; `gate: StepGateSummary|None`; `escalations_count: int=0`; `step_kind: str|None`; `payload: dict|None`; `attempt: int=1`.
- `StepArtifactRef` (`application.py:395-401`): `artifact_type: str; title: str; path: str; url: str|None; created_at: datetime|None`.
- `StepGateSummary` (`application.py:405-410`): `id: UUID; gate_type: GateType; status: GateStatus`.

### §A8 `DiscoverResponse` (`application.py:379-384`) — response E11/E12/E13/E14
`workflow_id: str`; `temporal_ui_url: str`; `status: str="started"`.

### §A9 `WorkflowDetailsResponse` (`application.py:494-512`) — response E15
`app_id: UUID`; `workflow_id: str|None`; `temporal_status: str|None`; `reported_status: str|None`; `current_line: AssemblyLineName|None`; `current_step: str|None`; `started_at: datetime|None`; `last_event_at: datetime|None`; `duration_seconds: int|None`; `staleness_seconds: int|None`; `is_stale: bool=False`; `history_length: int|None`; `pending_signals: int|None`; `recent_errors: list[WorkflowRecentError]=[]`; `temporal_unreachable: bool=False`; `temporal_ui_url: str|None`.
- `WorkflowRecentError` (`application.py:483-491`): `task_id: UUID; task_type: str; status: str; last_error: str|None; failed_at: datetime|None; retry_count: int=0`.

### §A10 `WorkflowStartRequest` (`application.py:455-458`) — request body E16
`line: AssemblyLineName`.

### §A11 `WorkflowStartResponse` (`application.py:467-472`) — response E16/E18
`workflow_id: str`; `line: AssemblyLineName`; `temporal_ui_url: str`.

### §A12 `WorkflowActionResponse` (`application.py:475-480`) — response E17
`workflow_id: str`; `requested: bool=True`; `detail: str`.

### §A13 `WorkflowRetryRequest` (`application.py:461-464`) — request body E18 (optional)
`from_line: AssemblyLineName|None=None`.

### §A14 `InsightsResponse` (`application.py:570-581`) — response E19
`app_id: UUID`; `has_data: bool=False`; `description: str|None`; `architecture: ArchitectureInsight|None`; `tech_stack: list[str]=[]`; `maturity: list[MaturityDimension]=[]`; `decisions: DecisionsSummary=DecisionsSummary()`; `metrics: InsightsMetrics=InsightsMetrics()`; `line_progress: list[LineProgressEntry]=[]`.
- `ArchitectureInsight` (`application.py:561-567`): `summary: str|None; diagram_url: str|None; major_components: list[str]=[]; integrations: list[str]=[]`.
- `MaturityDimension` (`application.py:520-527`): `dimension: str; latest: float|None; previous: float|None; delta: float|None; trend: str="flat"; sample_count: int=0`.
- `DecisionsSummary` (`application.py:541-547`): `disposition: Disposition|None; risk_tier: int|None; complexity_tier: str|None; last_changed_at: datetime|None`.
- `InsightsMetrics` (`application.py:550-558`): `loc: int|None; test_coverage_pct: float|None; dependency_currency_pct: float|None; open_escalations: int=0; resolved_escalations: int=0; agent_cost_to_date: float|None`.
- `LineProgressEntry` (`application.py:531-538`): `line: AssemblyLineName; status: str="not_started"; last_event_at: datetime|None; gate_status: GateStatus|None; pending_gate: GateType|None`.

### §A15 `DecisionsTimelineResponse` (`application.py:597-601`) — response E20
`app_id: UUID`; `entries: list[DecisionEntry]=[]`.
- `DecisionEntry` (`application.py:584-594`): `id: str; kind: str; timestamp: datetime; actor: str|None; title: str; detail: str|None; status: str|None; gate_type: GateType|None`.

### §A16 `DispositionOutputBundle` (`olympus-api/src/models/disposition_output.py:167-202`) — published shape E21
Envelope (`extra="forbid"`): `application_id: UUID; application_name: str(min1); portfolio_id: UUID; wave_id: UUID; disposition: Literal[Retire,Retain,Refactor,Rearchitect,Replace,Replatform,Consolidate]; status: Literal[completed,partial,rolled-back,abandoned]; started_at: datetime; completed_at: datetime; disposition_decision_ref: str(min1); approvals: list[BundleApproval](min1); realized_net_impact: BundleRealizedNetImpact; payload: DispositionPayload`.
- `BundleApproval`: `gate: str(min1); approved_at: datetime; approved_by: str(min1); record_ref: str(min1)`.
- `BundleRealizedNetImpact`: `tco_delta: BundleTcoDelta; users_affected_actual: int|None; users_affected_estimate_ref: str|None`. `BundleTcoDelta`: `annual_savings_usd: float|None; one_time_cost_usd: float|None; baseline_ref: str|None`.
- `DispositionPayload` = discriminated `Union` on `disposition` over Retire/Retain/Refactor/Rearchitect/Replace/Replatform/Consolidate payloads, each `extra="allow"` (permissive). Field lists per `disposition_output.py:78-146`.
- ⚠️ Service returns the raw parsed JSON `dict` verbatim — this model is only the published OpenAPI shape, NOT enforced at runtime.

### §A17 `AppDispositionResponse` (`application.py:309-343`) — response E22
`application_id: UUID`; `dispositions: list[str]=[]`; `target_services: list[str]=[]`; `rationalization_capability_ids: list[str]=[]`.
