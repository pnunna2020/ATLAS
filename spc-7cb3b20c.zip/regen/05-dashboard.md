# 05 — Dashboard: Routes, Pages & State Model (ATOMIC regeneration spec)

> **Scope of THIS doc** — the dashboard's **entry document**: the complete route
> table, every page directory (purpose + which route renders it + the API
> endpoints it loads + tab/sub-structure), the **state-management model**
> (React Query + context providers + auth), and the **app shell / Layout /
> navigation / routing guards**.
>
> **Companion docs** (not all yet written): component-level props/state catalog,
> the full USWDS design-token CSS, and the chart/viewer subsystem live (or will
> live) in sibling `05-*` docs. The **API endpoints** named here are specified
> in `regen/01-api*.md` (cross-references inline). The **agent chat backend** is
> in `regen/01-api-chat-workflows-signals.md`.
>
> **Bar = BEHAVIORAL PARITY.** Rebuild so it looks and behaves the same. When in
> doubt, OVER-specify. Citations are `path:line` relative to repo root
> `/Users/pnunna/Documents/GitHub/foundry`.

---

## 0. Tech stack & bootstrap (atomic)

| Concern | Choice | Source |
| --- | --- | --- |
| Framework | **React 18** (`StrictMode`) | `dashboard/src/main.tsx:1,10` |
| Bundler/dev | **Vite** | `dashboard/src/*` uses `import.meta.env.*` |
| Router | **react-router-dom** `BrowserRouter` | `dashboard/src/App.tsx:5,125` |
| Server-state | **@tanstack/react-query** (`QueryClient`/`QueryClientProvider`) | `dashboard/src/App.tsx:6,110,121` |
| HTTP | **axios** singleton w/ interceptors | `dashboard/src/api/client.ts:6,12` |
| Toasts | **sonner** `<Toaster>` | `dashboard/src/App.tsx:7,126` |
| Design system | **USWDS** via `@trussworks/react-uswds` + `@uswds/uswds` CSS | `Layout.tsx:6-13`; `styles/base.css:6` |
| Fonts | **Inter** (Google Fonts) | `styles/base.css:7` |
| Charts | Recharts (themed via `useChartTheme`) | `hooks/useChartTheme.ts`; many pages |

### 0.1 `main.tsx` — entry point (full, `dashboard/src/main.tsx`)

```tsx
import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import App from "./App";
import "./styles/index.css";

const rootElement = document.getElementById("root");
if (!rootElement) throw new Error("Root element not found");

createRoot(rootElement).render(<StrictMode><App /></StrictMode>);
```

- Mounts `<App />` into DOM node id `root`. Throws if missing.
- Imports the **single CSS manifest** `styles/index.css` (see §6).

### 0.2 `App.tsx` — provider stack + QueryClient (`dashboard/src/App.tsx`)

**QueryClient config (`App.tsx:110-117`)** — ⚠️ GOTCHA: reproduce exactly:
```ts
new QueryClient({ defaultOptions: { queries: {
  staleTime: 30_000,            // 30s — data considered fresh for 30s
  refetchOnWindowFocus: true,   // refetch when tab regains focus
}}})
```

**Provider nesting (`App.tsx:121-125`, outermost → innermost):**
```
QueryClientProvider (client=queryClient)
└ ArtifactContextProvider        (hooks/useArtifactContext.tsx)
  └ PortfolioProvider            (hooks/usePortfolioContext.tsx)
    └ BreadcrumbProvider         (hooks/useBreadcrumbContext.tsx)
      └ BrowserRouter
        ├ <Toaster position="top-right" richColors closeButton />   (App.tsx:126)
        ├ <DemoModeIndicator />                                     (App.tsx:127)
        └ <Routes> … </Routes>                                      (App.tsx:128-309)
```
⚠️ GOTCHA: order matters — `useChatContext` (consumed in Layout) calls
`usePortfolioContext`, so PortfolioProvider MUST wrap the router. Breadcrumb
state is innermost (only pages + Layout use it).

**Module-load side effect (`App.tsx:74-76`):** `installDemoToastGuard(toast)` is
called at import time (before `App` renders) so every `toast(...)` call site
routes through the demo suppressor. No-op unless `VITE_DEMO_MODE` set. See §7.

---

## 1. THE FULL ROUTE TABLE (all 61 routes)

Defined in one `<Routes>` block, `dashboard/src/App.tsx:128-309`. Three groups:
**(A) public** (outside Layout), **(B) demo-only** (outside Layout), **(C)
Layout-wrapped** (nested under `<Route element={<Layout/>}>` at `App.tsx:148`,
closing `:308`). The Layout adds the header/sidebar/breadcrumbs shell + `<Outlet/>`.

> ⚠️ GOTCHA — **NO `basename` and NO route-level auth guard.** There is no
> `<ProtectedRoute>` wrapper. "Auth protection" is purely the axios interceptor
> attaching a bearer token + the API 401ing; the SPA itself renders every
> Layout route regardless of session (see §5.4). The only redirect-to-login is
> in `CurrentUserMenu` sign-out and `OidcCallback` failure.

> Paths below are written **as in source** (no leading slash on the JSX `path`
> prop; the effective URL has a leading `/`). `index` ⇒ `/`.

### Group A — Public (outside Layout)

| # | URL | `path` prop | Component | Params | Cite |
| --- | --- | --- | --- | --- | --- |
| 1 | `/login` | `login` | `Login` (pages/Auth) | — | `App.tsx:132` |
| 2 | `/auth/callback` | `auth/callback` | `OidcCallback` (pages/Auth) | — (reads `#access_token` fragment) | `App.tsx:133` |

### Group B — Demo-only (outside Layout; not linked from nav)

| # | URL | `path` prop | Component | Notes | Cite |
| --- | --- | --- | --- | --- | --- |
| 3 | `/demo/one-stop-shop` | `demo/one-stop-shop` | `OneStopShopDemo` | standalone federal mockup, Scene 5 | `App.tsx:140` |
| 4 | `/demo/cold-open` | `demo/cold-open` | `DemoColdOpen` | full-screen ribbon; `?close=true` adds closing strap | `App.tsx:146` |

### Group C — Layout-wrapped (the app shell)

Parent: `<Route element={<Layout />}>` (`App.tsx:148`). All rows below are children.

#### C.1 Portfolio section

| # | URL | `path` prop | Component | Params | Cite |
| --- | --- | --- | --- | --- | --- |
| 5 | `/` (index) | `index` | `PortfolioOverview` | — | `App.tsx:150` |
| 6 | `/portfolios/:portfolioId/applications` | `portfolios/:portfolioId/applications` | `ApplicationsPage` | `:portfolioId` | `App.tsx:151-154` |
| 7 | `/applications/:id` | `applications/:id` | `ApplicationDetail` | `:id` | `App.tsx:155` |
| 8 | `/applications/:appId/design-review` | `applications/:appId/design-review` | `DesignReview` | `:appId` | `App.tsx:159-162` |
| 9 | `/portfolios/:portfolioId/applications/:appId/interview` | `…/applications/:appId/interview` | `Interview` | `:portfolioId`,`:appId` | `App.tsx:165-168` |
| 10 | `/applications/:appId/interview` | `applications/:appId/interview` | `Interview` | `:appId` | `App.tsx:169-172` |
| 11 | `/applications/:appId/build` | `applications/:appId/build` | `BuildProgress` | `:appId` | `App.tsx:173-176` |
| 12 | `/gates` | `gates` | `GateQueue` | — | `App.tsx:177` |
| 13 | `/gates/:gateId/review` | `gates/:gateId/review` | `GateReview` | `:gateId` | `App.tsx:178` |
| 14 | `/escalations` | `escalations` | `EscalationQueue` | — | `App.tsx:179` |
| 15 | `/me/tasks` | `me/tasks` | `MyTasks` | — | `App.tsx:186` |
| 16 | `/me/tasks/:taskId` | `me/tasks/:taskId` | `MyTaskDetail` | `:taskId` | `App.tsx:187` |
| 17 | `/me/bundles` | `me/bundles` | `MyBundles` | — | `App.tsx:189` |
| 18 | `/bundles/:bundleId` | `bundles/:bundleId` | `BundleDetail` | `:bundleId` | `App.tsx:190` |
| 19 | `/waves` | `waves` | `WaveManagement` | — | `App.tsx:191` |
| 20 | `/waves/:waveId` | `waves/:waveId` | `WaveDetail` | `:waveId` | `App.tsx:192` |
| 21 | `/waves/:waveId/plan` | `waves/:waveId/plan` | **`WavePlanRedirect`** → `/waves/:waveId#plan` | `:waveId` | `App.tsx:196-199` |
| 22 | `/portfolios/:portfolioId/waves/:waveId/redundancy-matrix` | (full) | `RedundancyMatrix` | `:portfolioId`,`:waveId` | `App.tsx:200-203` |
| 23 | `/portfolios/:portfolioId/waves/:waveId/plan` | (full) | **`LegacyPortfolioWavePlanRedirect`** → `/waves/:waveId#plan` | `:portfolioId`,`:waveId` | `App.tsx:208-211` |
| 24 | `/analytics/scoring-heat-map` | `analytics/scoring-heat-map` | `ScoringHeatMap` | — | `App.tsx:212` |

#### C.2 Assembly Lines section

| # | URL | Component | Params | Cite |
| --- | --- | --- | --- | --- |
| 25 | `/assembly-lines` | `AssemblyLinesIndex` | — | `App.tsx:215` |
| 26 | `/assembly-lines/:lineId` | `AssemblyLineDashboard` | `:lineId` | `App.tsx:216` |
| 27 | `/assembly-lines/:lineId/anatomy` | `LineAnatomyPage` | `:lineId` | `App.tsx:217-220` |

#### C.3 Skills section (+ legacy `/agents/*` redirects)

| # | URL | Component / target | Params | Cite |
| --- | --- | --- | --- | --- |
| 28 | `/skills` | `SkillCatalog` | — | `App.tsx:227` |
| 29 | `/skills/:skillId` | `SkillDetail` | `:skillId` | `App.tsx:228` |
| 30 | `/skills/evaluation` | `SkillEvaluation` | — | `App.tsx:229` |
| 31 | `/agents` | `<Navigate to="/analytics/model-usage" replace/>` | — | `App.tsx:232-235` |
| 32 | `/agents/performance` | `<Navigate to="/analytics/model-usage" replace/>` | — | `App.tsx:236-239` |
| 33 | `/agents/skills` | `<Navigate to="/skills" replace/>` | — | `App.tsx:240-243` |
| 34 | `/agents/skills/:skillId` | **`LegacySkillRedirect`** → `/skills/:skillId` | `:skillId` | `App.tsx:244-247` |
| 35 | `/agents/evaluation` | `<Navigate to="/skills/evaluation" replace/>` | — | `App.tsx:248-251` |

> ⚠️ GOTCHA — #30 `/skills/evaluation` and #29 `/skills/:skillId` both match
> `skills/<seg>`. React-router v6 ranks **static segments over dynamic**, so
> `/skills/evaluation` wins. Order in source is `:skillId` then `evaluation`
> (`App.tsx:228-229`) — relies on ranking, not declaration order. Keep both.

#### C.4 Analytics section

| # | URL | Component | Cite |
| --- | --- | --- | --- |
| 36 | `/analytics/readiness` | `ReadinessScores` | `App.tsx:254` |
| 37 | `/analytics/growth` | `CompoundGrowth` | `App.tsx:255` |
| 38 | `/analytics/velocity` | `FactoryVelocity` | `App.tsx:256` |
| 39 | `/analytics/cost` | `CostDashboard` | `App.tsx:257` |
| 40 | `/analytics/model-usage` | `ModelUsage` | `App.tsx:258` |

> Note: `/analytics/scoring-heat-map` (#24) lives in the Portfolio block in
> source but is presented under the Analytics sidebar (`navConfig.ts:109`).

#### C.5 Admin section

| # | URL | Component | Cite |
| --- | --- | --- | --- |
| 41 | `/admin/profile` | `ClientProfile` | `App.tsx:261` |
| 42 | `/admin/profile/compare` | `ProfileComparison` | `App.tsx:262` |
| 43 | `/admin/system` | `SystemStatus` | `App.tsx:263` |
| 44 | `/admin/workflow-health` | `WorkflowHealth` | `App.tsx:264` |
| 45 | `/admin/config` | `Configuration` | `App.tsx:265` |
| 46 | `/admin/scoring` | `ScoringConfig` | `App.tsx:266` |
| 47 | `/admin/registries` | `ExtensibilityRegistry` | `App.tsx:267` |
| 48 | `/admin/users` | `UserManagement` | `App.tsx:268` |
| 49 | `/admin/portfolio-members` | `PortfolioMembers` | `App.tsx:270` |
| 50 | `/admin/delegation` | `Delegation` | `App.tsx:271` |

#### C.6 Compliance & Security section

| # | URL | Component | Params | Cite |
| --- | --- | --- | --- | --- |
| 51 | `/compliance` | `CompliancePosture` | — | `App.tsx:274` |
| 52 | `/compliance/cato` | `CatoEvidence` | — | `App.tsx:281` |
| 53 | `/compliance/:appId` | `ApplicationCompliance` | `:appId` | `App.tsx:285` |
| 54 | `/security` | `SecurityPosture` | — | `App.tsx:286` |

> ⚠️ GOTCHA — #52 `/compliance/cato` vs #53 `/compliance/:appId`: static
> `cato` outranks dynamic `:appId` in v6. An app literally named `cato` is
> unreachable via this route. Keep static declared (it is, `:281` before `:285`).

#### C.7 Capability/System grain, Traceability, About

| # | URL | Component | Cite |
| --- | --- | --- | --- |
| 55 | `/target-architecture` | `TargetArchitecture` | `App.tsx:293` |
| 56 | `/capability-lineage` | `CapabilityLineage` | `App.tsx:294` |
| 57 | `/traceability` | `TraceabilityExplorerPage` | `App.tsx:297` |
| 58 | `/about` | `AboutOverview` | `App.tsx:304` |
| 59 | `/getting-started` | `GettingStarted` | `App.tsx:305` |
| 60 | `*` (catch-all under Layout) | `NotFound` | `App.tsx:307` |

**Route 61 — the Layout wrapper route itself** (`<Route element={<Layout/>}>`,
`App.tsx:148`) is the parent layout route. (61 `<Route>` elements total: 2
public + 2 demo + 1 Layout parent + 56 children incl. catch-all = **61**.)

### 1.1 Inline redirect helper components (`App.tsx`)

| Component | Behavior | Cite |
| --- | --- | --- |
| `LegacySkillRedirect` | reads `:skillId`, `<Navigate to={/skills/${skillId ?? ""}} replace/>` | `App.tsx:82-85` |
| `WavePlanRedirect` | reads `:waveId`, → `/waves/${waveId}#plan` | `App.tsx:94-97` |
| `LegacyPortfolioWavePlanRedirect` | reads `:waveId` (ignores `:portfolioId`), → `/waves/${waveId}#plan` | `App.tsx:105-108` |

⚠️ GOTCHA: the hash `#plan` scrolls the WaveDetail page to its embedded
wave-plan section (`WavePlanEmbed` component); the standalone plan page was
tombstoned (P5-S28 PR 6). Reproduce hash-redirect + embed, not a separate page.

---

## 2. PAGE DIRECTORY CATALOG (28 dirs under `dashboard/src/pages/`)

Each page dir has an `index.ts` barrel re-exporting its component(s). The `App`
import sites are `App.tsx:14-68`. The **API helper names** below are exported
from `dashboard/src/api/client.ts` (115KB; the single typed-client module) or
`dashboard/src/api/bundlesApi.ts`; their HTTP routes are in `regen/01-api*.md`.
Hook names (`use*`) are from `dashboard/src/hooks/` (§4).

### 2.1 `PortfolioOverview/` → route #5 (`/`, index)
- **Purpose:** landing dashboard — portfolio KPIs, health, recent activity, pending gates, wave roll-up. Can create a portfolio if none.
- **Component:** `PortfolioOverview.tsx`.
- **API loaded:** `fetchPortfolios` (via `usePortfolioContext`), `fetchApplications`, `fetchPortfolioHealth`, `fetchDetailedHealth`, `fetchGatePassRate`, `fetchPendingGates`, `fetchReadinessScores`, `fetchRecentActivity`, `fetchWaves`, `fetchWorkflowHealthList`, `createPortfolio`. (grep `pages/PortfolioOverview/`)
- **Sub-structure:** single page; renders summary cards + `NeedsMyAttention` + `MyTasksSummaryCard` style widgets.

### 2.2 `Applications/` → route #6 (`/portfolios/:portfolioId/applications`)
- **Purpose:** portfolio-scoped application table (search/filter/sort), per-app readiness.
- **Component:** `ApplicationsPage.tsx`.
- **API:** `fetchApplications`, `fetchReadinessScores`. Uses `usePortfolioContext`, `useNavigate` (row → `/applications/:id`).

### 2.3 `ApplicationDetail/` → route #7 (`/applications/:id`)
- **Purpose:** the deep per-application workbench — disposition pipeline, scores, artifacts, decisions, traceability, insights, outcome.
- **Component:** `ApplicationDetail.tsx` + **`tabs/`** subdir (10 visible tabs).
- **Tabs** (`ApplicationDetail.tsx:79-95` TABS array; default `activeTab="insights"` `:137`; rendered via `TabNav`+`TabPanel` `:46,900`):

  | tab id | label | tab component | source |
  | --- | --- | --- | --- |
  | `insights` | Insights | `InsightsTab` | `tabs/InsightsTab.tsx` |
  | `pipeline` | Pipeline | `StatusTab` | `tabs/StatusTab.tsx` |
  | `decisions` | Decisions | `DecisionsTimeline` | `tabs/DecisionsTimeline.tsx` |
  | `scores` | Scores | `ScoresTab` | `tabs/ScoresTab.tsx` |
  | `artifacts` | Artifacts | `ArtifactsTab` | `tabs/ArtifactsTab.tsx` |
  | `duplication` | Internal Duplication | `InternalDuplicationTab` | `tabs/InternalDuplicationTab.tsx` |
  | `traceability` | Traceability | `TraceabilityTab` | `tabs/TraceabilityTab.tsx` |
  | `impact` | User Impact | `UserImpactTab` | `tabs/UserImpactTab.tsx` |
  | `rationale` | Rationale | `RationaleTab` | `tabs/RationaleTab.tsx` |
  | `outcome` | Outcome | `OutcomeTab` | `tabs/OutcomeTab.tsx` |

  ⚠️ GOTCHA: the `id="pipeline"` tab renders `StatusTab` (label/id ≠ component name). `InternalDuplicationTab` receives `active={activeTab === "duplication"}` so it lazy-loads only when selected (`:969`).
- **API loaded:** `fetchApplicationDetail`, `fetchApplicationStatus`, `fetchApplicationInsights`, `fetchApplicationDecisions`, `fetchApplicationRationale`, `fetchApplicationGateEvidence`, `fetchApplicationLineage`, `fetchReadinessScores`, `fetchScoreHistory`, `fetchStructuralAnalysis`, `fetchCrossValidation`, `fetchDispositionOutput`, `fetchRenditions`, `fetchSourceArtifactsIndex`, `fetchTraceability`, `fetchTraceabilityCoverage`, `fetchWaveArtifact`, `fetchWaveDetail`, `startDiscovery`, `startLineWorkflow`, `cancelWorkflow`.
- **Hooks:** `useBreadcrumbContext` (injects app name + line into breadcrumb), `useChartTheme`, `useWorkflowDetails` (from `components/WorkflowControl/hooks/`).

### 2.4 `GateQueue/` → route #12 (`/gates`)
- **Purpose:** pending-gate review queue (SLA-sorted), live updates.
- **Components:** `GateQueue.tsx`, local `EmptyState.tsx`.
- **API:** `fetchPendingGates`. **Hooks:** `usePortfolioContext`, `useWebSocket` (live gate events). Row → `/gates/:gateId/review`.

### 2.5 `GateReview/` → route #13 (`/gates/:gateId/review`)
- **Purpose:** single-gate decision surface — evidence package, checks, approve/reject/escalate.
- **Component:** `GateReview.tsx`.
- **Data:** **React Query hooks** `useGateEvidence(gateId)` + `useSubmitGateDecision(gateId)` (the ONLY pages besides Design/Interview/Build that use `hooks/useQueries`); `useWebSocket` for live status. ⚠️ Demo-mode short-circuits the decision POST (§7; `useQueries.ts:217-243`).

### 2.6 `Escalations/` → route #14 (`/escalations`)
- **Purpose:** escalated-gate queue (gates needing higher authority).
- **Component:** `EscalationQueue.tsx`. **API:** `fetchPendingGates` (filtered). **Hooks:** `usePortfolioContext`, `useWebSocket`.

### 2.7 `Waves/` → route #19 (`/waves`)
- **Purpose:** wave management board — list/create/cancel waves, kick rationalization, telemetry.
- **Component:** `WaveManagement.tsx` (⚠️ GOTCHA: **no `index.ts`** in this dir; `App.tsx:20` imports `./pages/Waves/WaveManagement` directly). Helper `waveActions.ts`.
- **API:** `fetchWaves`, `fetchApplications`, `createWave`, `cancelWave`, `startRationalization`. **Hooks:** `usePortfolioContext`, `useChartTheme`, `useWaveTelemetry`, `useSearchParams`.

### 2.8 `WaveDetail/` → route #20 (`/waves/:waveId`)
- **Purpose:** single-wave detail — progress panel, fan-out status, per-app activity, embedded wave-plan section (`#plan` target), recovery/failure banners.
- **Component:** `WaveDetail.tsx` (+ `WaveDetail.css`).
- **API:** `fetchWaveDetail`, `fetchWaveProgress`, `fetchWaveAppActivity`, `fetchApplications`, `fetchApplicationLineage`, `startRationalization`, `cancelWave`, `cancelWaveRationalization`, `cancelAllWaveChildren`. **Hooks:** `useWaveTelemetry`; renders `WavePlanEmbed`, `WaveWorkflowProgress`, `WaveRecoveryBanner`, `WorkflowFailureBanner`.
- ⚠️ Progress panel uses `useWaveProgress` semantics (polls every 5s while `RUNNING`; swallows 409 `WAVE_WORKFLOW_NOT_STARTED` → null/empty-state — `useQueries.ts:88-117`). The page itself calls `fetchWaveProgress` directly per grep; reproduce the 409-as-empty behavior.

### 2.9 `RedundancyMatrix/` → route #22 (`/portfolios/:portfolioId/waves/:waveId/redundancy-matrix`)
- **Purpose:** cross-portfolio redundancy heat matrix from the wave's rationalization artifact.
- **Component:** `RedundancyMatrix.tsx` (+ css). **API:** `fetchWaveArtifact`. **Hooks:** `useBreadcrumbContext`.

### 2.10 `ScoringHeatMap/` → route #24 (`/analytics/scoring-heat-map`)
- **Purpose:** portfolio scoring heat map across dimensions × apps.
- **Component:** `ScoringHeatMap.tsx` (+ css). **API:** `fetchPortfolioScoringHeatMap`. **Hooks:** `usePortfolioContext`, `useChartTheme`.

### 2.11 `AssemblyLines/` → routes #25-27 (`/assembly-lines`, `/:lineId`, `/:lineId/anatomy`)
- **Purpose:** assembly-line pipeline dashboards — line throughput, status, governance drift/patterns, model usage; per-line anatomy diagram.
- **Components:** `AssemblyLinesIndex.tsx`, `AssemblyLineDashboard.tsx`, `LineAnatomyPage.tsx`, plus `LineSpotlight.tsx`; config `assemblyLineConfig.ts` + `assemblyLineLiveConfig.ts`.
- **API:** `fetchLineStatus`, `fetchLineThroughput`, `fetchApplications`, `fetchPendingGates`, `fetchModelUsage`, `fetchGovernanceDriftAlerts`, `fetchGovernanceLatestHealthCheck`, `fetchGovernancePatterns`. **Hooks:** `useChartTheme`, `usePortfolioContext`.

### 2.12 `Skills/` → routes #28-30 (`/skills`, `/:skillId`, `/skills/evaluation`)
- **Purpose:** SKILL.md registry browser + per-skill detail + evaluation/metrics.
- **Components:** `SkillCatalog.tsx`, `SkillDetail.tsx`, `SkillEvaluation.tsx`; helper `skillSource.ts`.
- **API:** `fetchSkills`, `fetchSkill`, `fetchSkillMetricsByLine`, `createSkill`. **Hooks:** `useChartTheme`.

### 2.13 `Analytics/` → routes #36-40 (`/analytics/{readiness,growth,velocity,cost,model-usage}`)
- **Purpose:** five analytics views.
- **Components:** `ReadinessScores.tsx`, `CompoundGrowth.tsx`, `FactoryVelocity.tsx`, `CostDashboard.tsx`, `ModelUsage.tsx`.
- **API (union):** `fetchReadinessScores`, `fetchCompoundGrowth`, `fetchGatePassRate`, `fetchModelUsage`, `fetchApplications`, `fetchWaves`. **Hooks:** `useChartTheme`, `usePortfolioContext`. (`ModelUsage` is also the redirect target for retired `/agents` pages.)

### 2.14 `Admin/` → routes #41-50 (`/admin/*`)
- **Purpose:** profile, profile-comparison, system status, workflow health, configuration, scoring config, extensibility registry, user management, portfolio members, delegation.
- **Components:** `ClientProfile.tsx`, `ProfileComparison.tsx`, `SystemStatus.tsx`, `WorkflowHealth.tsx`, `Configuration.tsx`, `ScoringConfig.tsx`, `ExtensibilityRegistry.tsx`, `UserManagement.tsx`, `PortfolioMembers.tsx`, `Delegation.tsx`; shared `SkillRoutingSection.tsx`.
- **API:** `fetchActiveProfile`, `fetchProfiles`, `fetchCompare`, `fetchDetailedHealth`, `fetchWorkflowHealthList`, `fetchWorkflowHealthDetail`, `fetchRegistriesIndex`, `fetchRegistryEntries`, `fetchDimensionRegistry`, `fetchUsers`, `createUser`, `fetchRoles`, `fetchSkills`; **bundles** delegation from `api/bundlesApi.ts`. **Hooks:** `useChartTheme`, `usePortfolioContext`, `useSearchParams`.

### 2.15 `Compliance/` → routes #51,52,53,54
- **Purpose:** portfolio compliance posture (#51), cATO/OSCAL evidence rollup (#52), per-app SSP/POA&M viewer (#53), security posture (#54).
- **Components:** `CompliancePosture.tsx`, `CatoEvidence.tsx`, `ApplicationCompliance.tsx`, `SecurityPosture.tsx`.
- **API:** `fetchPortfolioComplianceSystemRollup`, `fetchPortfolioCatoEvidence`, `fetchGovernanceDriftAlerts`, `fetchGovernanceLatestHealthCheck`, `fetchApplications`, `startGovernanceSweep`. **Hooks:** `usePortfolioContext`. Renders `ComplianceDashboard` component.

### 2.16 `TargetArchitecture/` → route #55 (`/target-architecture`)
- **Purpose:** SF3 S1–S11 target systems + SF1 legacy systems for the active portfolio.
- **Component:** `TargetArchitecture.tsx`. **API:** `fetchSystems`, `fetchSystemDetail`. **Hooks:** `usePortfolioContext`.

### 2.17 `CapabilityLineage/` → route #56 (`/capability-lineage`)
- **Purpose:** source→target capability edges incl. M:N cases.
- **Component:** `CapabilityLineage.tsx`. **API:** `fetchSystems`, `fetchSystemCapabilities`, `fetchCapabilityLineage`. **Hooks:** `usePortfolioContext`.

### 2.18 `Traceability/` → route #57 (`/traceability`)
- **Purpose:** Traceability Explorer — citation graph, coverage, stale artifacts.
- **Component:** `TraceabilityExplorerPage.tsx`. **API:** `fetchTraceability`, `fetchTraceabilityCoverage`, `fetchStaleArtifacts`, `fetchApplications`. **Hooks:** `usePortfolioContext`. Renders `TraceabilityExplorer` + `StaleArtifactsCard`.

### 2.19 `AboutOverview/` → route #58 (`/about`)
- **Purpose:** durable "what is Olympus" platform overview.
- **Component:** `AboutOverview.tsx` (+ css). **API:** `fetchActiveProfile` only.

### 2.20 `GettingStarted/` → route #59 (`/getting-started`)
- **Purpose:** how-to-get-rolling guide; launches the `OnboardingWizard`.
- **Component:** `GettingStarted.tsx` (+ css). **API:** none (uses `useState` only; wizard does its own calls).

### 2.21 `MyTasks/` → routes #15,16 (`/me/tasks`, `/me/tasks/:taskId`)
- **Purpose:** human-paired-agent task inbox (#15) + per-task detail w/ audit narrative + return action (#16).
- **Components:** `MyTasks.tsx`, `MyTaskDetail.tsx`.
- **API:** `fetchMyTasks`, `fetchTaskAuditNarrative`, `submitTaskReturn`. **Hooks:** `usePortfolioContext`.

### 2.22 `DesignReview/` → route #8 (`/applications/:appId/design-review`)
- **Purpose:** standalone design-artifact browse + annotate (outside a gate).
- **Component:** `DesignReview.tsx` (+ css).
- **Data:** **React Query** `useDesignArtifacts(appId, {line, artifactType})` + `useSubmitDesignFeedback(appId)` (`useQueries.ts:350-383`). **Hooks:** `useSearchParams` (category filter).

### 2.23 `Interview/` → routes #9,10 (`/applications/:appId/interview`)
- **Purpose:** Requirements Interview UI (interview-driven Build intake) — turn-by-turn Q&A + live preview.
- **Component:** `Interview.tsx` (+ css).
- **Data:** **React Query** `useInterviewSession`, `useStartInterview`, `useSubmitInterviewTurn`, `useCompleteInterview` (`useQueries.ts:392-441`). ⚠️ `useInterviewSession` sets `refetchOnWindowFocus:false` (session mutated turn-by-turn locally; no background poll).

### 2.24 `BuildProgress/` → route #11 (`/applications/:appId/build`)
- **Purpose:** greenfield Build-line progress surface (`build.*` telemetry).
- **Component:** `BuildProgress.tsx`; renders `components/BuildLineProgress`.
- **Data:** **React Query** `useApplicationDetail(appId)` + `useApplicationStatus(appId)` (`BuildProgress.tsx:17-18,50-51`). Derives `BuildProgressData` via `useMemo`. Reads `:appId` from `useParams`.

### 2.25 `MyBundles/` → routes #17,18 (`/me/bundles`, `/bundles/:bundleId`)
- **Purpose:** delegated-bundle pair-facing list (#17) + bundle detail w/ submit (#18).
- **Components:** `MyBundles.tsx`, `BundleDetail.tsx`; helper `scopeLabel.ts`.
- **API:** from **`api/bundlesApi.ts`** — `submitBundle` (+ list/detail fetchers in bundlesApi). **Hooks:** `usePortfolioContext`.

### 2.26 `OneStopShopDemo/` → route #3 (`/demo/one-stop-shop`, public/demo)
- **Purpose:** standalone federal product mockup for the demo tape (Scene 5). Renders OUTSIDE Layout.
- **Component:** `OneStopShopDemo.tsx` (+ css); **fixture data** `mockData.ts` (no live API).

### 2.27 `DemoColdOpen/` → route #4 (`/demo/cold-open`, public/demo)
- **Purpose:** full-screen animated process-ribbon splash (Scenes 1 & 11). `?close=true` adds the closing "High Confidence" strap. OUTSIDE Layout.
- **Component:** `DemoColdOpen.tsx` (+ css). No API.

### 2.28 `Auth/` → routes #1,2 (`/login`, `/auth/callback`, public)
- **Purpose:** local + OIDC sign-in (#1) and OIDC fragment-token handler (#2). Render OUTSIDE Layout (ships a minimal guest shell).
- **Components:** `Login.tsx`, `OidcCallback.tsx`.
- **`Login`** (`pages/Auth/Login.tsx`): on mount `fetchAuthConfig()` (`/api/v1/auth/config`) → decides whether the SSO button shows (`authConfig.oidc_enabled`). Local submit → `loginLocal({email_or_username,password})` → `setAuthToken(token.access_token)` → `navigate("/")` (`:61-66`). SSO → `window.location.href = ${apiBase}${oidc_login_url}?redirect_after=…/auth/callback` (`:76-83`). ⚠️ Failed `/auth/config` is non-fatal: falls back to local-only config (`:42-48`).
- **`OidcCallback`** (`pages/Auth/OidcCallback.tsx`): parses `window.location.hash` for `access_token`; if present `setAuthToken` + `navigate("/",{replace})`; else `navigate("/login",{replace})` (`:17-29`).

### 2.29 Loose page files (not dirs)
- `pages/NotFound.tsx` → route #60 (catch-all `*`).
- `pages/PlaceholderPage.tsx` — generic placeholder (imported by some pages; not directly routed).

---

## 3. STATE-MANAGEMENT MODEL

Three layers: **(1) server state** via React Query, **(2) global UI/session
state** via 3 React Contexts + 2 localStorage-backed hooks, **(3) local
component state** via `useState`/`useMemo`.

### 3.1 Server state — two patterns coexist (⚠️ GOTCHA)

There are **two parallel data-fetching styles**; both are live:

**(a) React Query hooks** in `dashboard/src/hooks/useQueries.ts` — used by a
**minority** of pages (GateReview, DesignReview, Interview, BuildProgress) and
by `WaveDetail`'s progress (semantics). These get caching + background refetch +
the `staleTime:30_000` / `refetchOnWindowFocus:true` defaults.

**(b) Direct imperative axios calls** — most list/detail pages call
`fetch*`/`submit*`/`create*`/`cancel*`/`start*` functions from
`api/client.ts` inside `useEffect` and stash results in local `useState`. They
do **not** participate in the React Query cache. (See §2 per-page API lists —
any page importing `from "../../api/client"` but not `useQueries` is pattern-b.)

**React Query keys** (`useQueries.ts:56-73`) — ⚠️ portfolio-scoped keys embed
`portfolio_id` so switching the portfolio picker auto-refetches (P5-AUDIT-016):
```
portfolios               = ["portfolios"]
applications(params)     = ["applications", params]   // params incl. portfolio_id
applicationDetail(id)    = ["application", id]
applicationStatus(id)    = ["application", id, "status"]
pendingGates(pid)        = ["gates","pending", pid ?? null]
gateEvidence(gateId)     = ["gate", gateId, "evidence"]
waveDetail(waveId)       = ["wave", waveId]
waveProgress(waveId)     = ["wave", waveId, "progress"]
waveGates(waveId)        = ["wave", waveId, "gates"]
designArtifacts(appId,p) = ["application", appId, "design-artifacts", p ?? null]
interview(appId)         = ["application", appId, "interview"]
```

**Query hooks** (all `useQueries.ts`): `usePortfolios`, `useApplications`,
`useApplicationDetail`, `useApplicationStatus`, `usePendingGates`,
`useWaveGates`, `useGateEvidence`, `useWaveProgress`, `useDesignArtifacts`,
`useInterviewSession`. **Mutation hooks**: `useSubmitGateDecision`,
`useStartDiscovery`, `useUpdateApplication`, `useCancelWaveRationalization`,
`useRetryWaveRationalization`, `useResetWave`, `useSubmitDesignFeedback`,
`useStartInterview`, `useSubmitInterviewTurn`, `useCompleteInterview`.

**Mutation invalidation conventions** (reproduce exactly):
- `useSubmitGateDecision.onSuccess` → invalidates `["gates","pending"]` (unscoped prefix, refreshes every portfolio's queue) + `gateEvidence(gateId)` (`:231-241`).
- `useStartDiscovery.onSuccess` → invalidates `applicationDetail` + `applicationStatus` (`:249-258`).
- `useUpdateApplication.onSuccess` → `setQueryData(applicationDetail, data)` (optimistic write) (`:266-271`).
- Wave cancel/retry → invalidate `waveDetail`; `useResetWave` also invalidates `waveProgress` (`:281-341`).
- Interview start/turn → `setQueryData(interview, state)`; complete → invalidate `interview` (`:402-441`).

⚠️ GOTCHA — `useWaveProgress` (`:88-117`): `refetchInterval` is a **function** —
returns `5000` only while `data.status === "RUNNING"`, else `false` (stop). It
catches 409 `WAVE_WORKFLOW_NOT_STARTED`/`409` and returns `null` (empty-state),
not an error. `refetchIntervalInBackground:false`.

### 3.2 Global state — 3 React Contexts

| Provider | Hook | State | Purpose | Source |
| --- | --- | --- | --- | --- |
| `PortfolioProvider` | `usePortfolioContext` | `portfolios[]`, `activePortfolio`, `setActivePortfolioId`, `loading`, `refresh` | active portfolio selection; **localStorage** key `olympus-active-portfolio`; loads list via `fetchPortfolios` on mount; auto-selects first if stored id invalid | `hooks/usePortfolioContext.tsx:19,42-110` |
| `ArtifactContextProvider` | `useArtifactContext` | `artifactContext`, `setArtifactContext`, `openChatSignal`, `requestOpenChat` | feeds the global ChatDrawer artifact context; `openChatSignal` is a monotonically-increasing counter pages bump to programmatically open the chat | `hooks/useArtifactContext.tsx:33-59` |
| `BreadcrumbProvider` | `useBreadcrumbContext` | `segments{appName,assemblyLine,leaf,waveName}`, `setBreadcrumbContext`, `clearBreadcrumbContext` | pages inject extra breadcrumb segments (e.g. app name + line) while mounted; Layout reads them | `hooks/useBreadcrumbContext.tsx:24-72` |

⚠️ GOTCHA — `PortfolioProvider.load` has `useCallback(…, [])` with
`eslint-disable react-hooks/exhaustive-deps` and reads `activeId` via closure
(`:53-75`). It runs **once** on mount; it does NOT reload when `activeId`
changes (that's handled by `setActivePortfolioId` writing localStorage + state).
Reproduce the single-shot load.

### 3.3 Auth state (no context — module-level localStorage)

Auth is **not** a context/provider. It's plain localStorage + axios interceptor:
- Token key `"olympus:auth:token"` (`api/client.ts:29`). Helpers `setAuthToken`/`clearAuthToken`/`getAuthToken` (`:31-53`).
- **Request interceptor** attaches `Authorization: Bearer <token>` on every request when a token exists (`api/client.ts:55-63`).
- **Response interceptor** normalizes errors into `Error` w/ message; resolution order: Olympus envelope `error.message` → FastAPI `detail` string → `message` → Pydantic `detail[]` (flattened `field: msg`) → `Server error (STATUS)`; network failure → `Unable to reach API at <base>` (`:75-129`).
- `CurrentUserMenu` fetches `fetchCurrentUser()` on mount → shows name + roles, or a "Sign in" link when both user is null AND `getAuthToken()` is null (`Layout/CurrentUserMenu.tsx:26-65`). Sign-out → `logoutSession()` then `clearAuthToken()` then `navigate("/login")` (`:42-49`).
- `logoutSession` itself also clears the token (`api/client.ts:2046-2050`).

⚠️ GOTCHA — **theme & portfolio use DIFFERENT localStorage key conventions**
than auth: `olympus-theme`, `olympus-active-portfolio` (hyphenated) vs
`olympus:auth:token` (colon-namespaced). Preserve all three keys verbatim.

### 3.4 Other UI-state hooks (`dashboard/src/hooks/`)

| Hook | Role | localStorage | Source |
| --- | --- | --- | --- |
| `useTheme` | light/dark; sets `data-theme` on `<html>`; applied **before** React hydrates to prevent flash | `olympus-theme`; default `light` | `hooks/useTheme.ts:12-43` |
| `useChartTheme` | maps theme → Recharts color tokens | — | `hooks/useChartTheme.ts` |
| `useChatContext` | derives chat `{contextType,contextId,section,suggestedQuestions}` from current route (used by Layout's ChatDrawer) | — | `hooks/useChatContext.ts:41-211` |
| `useWebSocket` | event stream w/ exp-backoff reconnect + **SSE fallback** after 5 fails; keeps last `maxEvents` (default 50) | — | `hooks/useWebSocket.ts:27-151` |
| `usePollingBackoff` | adaptive poll: minMs→midMs→maxMs (3s/5s/10s) after N unchanged ticks; resets on change; demo-aware | — | `hooks/usePollingBackoff.ts:48-144` |
| `useWaveTelemetry` | wave-page telemetry emit | — | `hooks/useWaveTelemetry.ts` |
| `useSectionDwell` | dwell-time instrumentation | — | `hooks/useSectionDwell.ts` |

⚠️ GOTCHA — `useTheme.ts:23-24` runs `document.documentElement.setAttribute("data-theme", initial)` at **module load** (top-level side effect), before any component renders, to avoid a flash-of-wrong-theme.

⚠️ GOTCHA — `useWebSocket` env: WS base `VITE_WS_BASE_URL ?? "ws://localhost:8000"`, SSE/API base `VITE_API_BASE_URL ?? "http://localhost:8000"`. WS path `/api/v1/events/ws`; SSE path `/api/v1/events`. Exp-backoff delay `min(1000*2^retries, 30_000)`; after 5 closes → `connectSSE()`.

### 3.5 `useChatContext` route → chat-context mapping (`hooks/useChatContext.ts`)

The global ChatDrawer's session is keyed by route. ⚠️ Order-sensitive matching:
1. `/gates/:gateId/review` → `{contextType:"gate", contextId:gateId}` (`:47-58`).
2. `/applications/:id` → `{contextType:"application", contextId:id}` (`:62-73`).
3. portfolio-scoped (rest): `contextId = activePortfolio?.id ?? "default"`, `contextType:"portfolio"`, `section` discriminator:
   - `/assembly-lines/…` → `section:"assembly-line:<lineId>"` (`:83-95`)
   - `/skills` → `"skills"`; `/analytics` → `"analytics"`; `/admin` → `"admin"` (`:98-137`)
   - `/waves/:id` → `"wave:<id>"` (⚠️ **must** run before bare `/waves` check, `:144-156`); `/waves` → `"waves"` (`:159-170`)
   - `/portfolios/…/applications` → `"applications"` (`:173-184`)
   - `/gates` (exact) → `"gate-queue"` (`:187-198`)
   - default → `"overview"` (`:201-210`)
Each branch supplies `suggestedQuestions[]` shown as starter chips.

---

## 4. APP SHELL / LAYOUT / NAVIGATION (`dashboard/src/components/Layout/`)

`Layout.tsx` is the wrapper route element (`App.tsx:148`). It renders: a
skip-nav link, the USWDS `<Header basic>`, a context-sensitive sidebar, a
breadcrumb bar, the `<Outlet/>`, and the global `<ChatDrawer/>`.

### 4.1 Header (`Layout.tsx:209-250`)
- USWDS `Header basic` with `showMobileOverlay={mobileNavOpen}`.
- `usa-logo` → `<Link to="/">` with custom inline-SVG `BrandIcon` (a temple/network glyph, cyan `#23D2D7` nodes on dark `#211D1E`, `Layout.tsx:61-81`) + text "Olympus".
- `PrimaryNav items={navItems}` — one `NavLink` per `NAV_SECTIONS` entry (`Layout.tsx:190-201`); active class `usa-current` when `section.id === activeSection.id` OR NavLink `isActive`.
- `header-right-group` (`Layout.tsx:230-247`): `<PortfolioPicker/>`, `<ActiveProfileBadge/>`, a **connection indicator** (green/grey dot + "Live"/"Offline" driven by `useWebSocket().connected`, `:233-244`), `<ThemeToggle theme onToggle/>`, `<CurrentUserMenu/>`.

### 4.2 Top-nav sections (`navConfig.ts:28-164`) — `NAV_SECTIONS`
6 sections, each `{id,label,matchPrefix,topNavPath,extraPrefixes?,items[]}`:

| id | label | matchPrefix | topNavPath | extraPrefixes |
| --- | --- | --- | --- | --- |
| `portfolio` | Portfolio | `/` | `/` | — |
| `assembly-lines` | Assembly Lines | `/assembly-lines` | `/assembly-lines` | — |
| `skills` | Skills | `/skills` | `/skills` | — |
| `analytics` | Analytics | `/analytics` | `/analytics/readiness` | — |
| `admin` | Admin | `/admin` | `/admin/profile` | — |
| `about` | About | `/about` | `/about` | `["/getting-started"]` |

**Sidebar items per section** (the secondary nav, `navConfig.ts`):
- **Portfolio** (`:34-67`): Overview `/`, My Tasks `/me/tasks`, My Bundles `/me/bundles`, Wave Management `/waves`, Gate Queue `/gates`, Escalations `/escalations`, Target Architecture `/target-architecture`, Capability Lineage `/capability-lineage`, Traceability `/traceability`, Compliance Posture `/compliance`, cATO Evidence `/compliance/cato`, Security Posture `/security`. ⚠️ `SidebarNav` **injects** an "Applications" item at index 1 → `/portfolios/<activePortfolioId>/applications` only when an active portfolio exists (`SidebarNav.tsx:19-30`).
- **Assembly Lines** (`:74-86`): Overview + 10 lines (discovery, rationalization, architecture, data, modernization, disposition-execution, validation, deployment, sustainment, governance).
- **Skills** (`:97-100`): Skill Catalog `/skills`, Skill Evaluation `/skills/evaluation`.
- **Analytics** (`:107-114`): Readiness `/analytics/readiness`, Scoring Heat Map `/analytics/scoring-heat-map`, Compound Growth, Factory Velocity, Cost Dashboard, Model Usage.
- **Admin** (`:121-138`): Client Profile, Profile Comparison, System Status, Workflow Health, Configuration, Scoring Config, Extensibility Registry, User Management, Portfolio Members, Delegation.
- **About** (`:151-162`): Platform Overview `/about`, Getting Started `/getting-started`.

Each item has an `icon` string consumed by `SidebarIcon.tsx` (grid/user/package/wave/lock/shield/box/search/check-circle/database/cpu/play/upload/refresh/book/trending/bar-chart/zap/dollar/bot/activity/settings/filter).

### 4.3 Active-section resolution (`navConfig.ts:170-187`)
`resolveActiveSection(pathname)`: sorts sections by `matchPrefix.length` DESC,
**skips** the `/` section, returns the first whose `matchPrefix` (or
`extraPrefixes`) is a `startsWith` match; else falls back to `NAV_SECTIONS[0]`
(portfolio). ⚠️ This longest-prefix-wins is why `/assembly-lines/...` doesn't
fall through to `/`.

### 4.4 Sidebar (`SidebarNav.tsx`) + collapse
- `SidebarNav` renders the active section's items via USWDS `SideNav`. Active item = `pathname === path || pathname.startsWith(path + "/")` (`SidebarNav.tsx:32-42`). ⚠️ Trailing-slash guard prevents `/gates` matching `/gates-foo`.
- **Collapsed mode** (`collapsed` prop): icons only, no labels, no section title (`SidebarNav.tsx:44-59`). Layout owns the `sidebarCollapsed` boolean + a `sidebar-collapse-toggle` button with `CollapseIcon` (`Layout.tsx:174,258-266`).
- Mobile: `mobileNavOpen` toggled by `NavMenuButton` (`Layout.tsx:173,220-223`).

### 4.5 Breadcrumbs (`Layout.tsx:85-168, 270-283`)
`breadcrumbsForPath(pathname, contextSegments)` builds a trail always rooted at
`{label:"Portfolio", href:"/", icon:true}` then appends per-route crumbs.
⚠️ For `/applications/*` it consumes `BreadcrumbContext.segments` to render
`Portfolio > [waveName] > [appName] > [assemblyLine] > [leaf]` (`:93-107`).
Rendered with USWDS `BreadcrumbBar`/`Breadcrumb`/`BreadcrumbLink`; last crumb
gets `current` (`:271-282`).

### 4.6 Global ChatDrawer (`Layout.tsx:289-297`)
Rendered once per Layout. `key` = `${contextType}-${contextId}-${section}` so it
**remounts** (resets conversation) when route-derived chat context changes.
Props: `contextType`, `contextId`, `section`, `artifactContext` (from
ArtifactContext), `suggestedQuestions`, `openSignal` (from
`ArtifactContext.openChatSignal`). Backend chat endpoints: see
`regen/01-api-chat-workflows-signals.md`. Components:
`components/Chat/ChatDrawer.tsx` + `AgentChatPanel.tsx`.

### 4.7 Routing guards — there are none at the route layer (⚠️)
No `<RequireAuth>`/loader/guard. The whole Layout subtree renders without a
session; the API 401s and the response interceptor turns that into error
messages pages surface. Login redirection only happens via `CurrentUserMenu`
sign-out and `OidcCallback`. **To reproduce parity: do NOT add a route guard.**

---

## 5. USWDS / BRANDING DESIGN-TOKEN SYSTEM (the LOOK)

CSS is one manifest, imported by `main.tsx`. Order is load-bearing (USWDS base
first, Olympus overrides after).

### 5.1 CSS manifest (`styles/index.css`) — import order
```
./base.css            // imports @uswds/uswds/css/uswds.css + Inter font, then tokens
./layout.css          // header/sidebar/main shell
./components.css       // shared widget styles
./gate-review.css
../components/GateReviewCards/GateReviewCards.css
./app-detail.css
./chat.css
./assembly-lines.css
```
⚠️ GOTCHA: `base.css:6` imports the full USWDS stylesheet first; every Olympus
rule below relies on overriding USWDS defaults, so import order must be kept.

### 5.2 Brand tokens (`styles/base.css:10-29`, `:root`)
```
--olympus-primary: #211D1E   (near-black/brand ink)
--olympus-teal:    #177480
--olympus-cyan:    #23D2D7
--olympus-accent:  #00A5B5   (h2 underline, info-alert accent)
--olympus-gate:    #6B4FBB   (violet — gate phase boundaries, unused by any status)
--olympus-bg:      #F2F7F7
--olympus-bg-card: #ffffff
--olympus-text:    #211D1E   /  --olympus-text-light: #464646  /  --olympus-text-inverse: #ffffff
--olympus-border:  #E8E8E8
--olympus-shadow / --olympus-shadow-md  (layered box-shadows)
--olympus-radius:  8px
--olympus-sidebar-width: 240px
--olympus-topnav-height: 56px
```

### 5.3 Dark theme (`styles/base.css:32-46`, `[data-theme="dark"]`)
Overrides the same vars: `--olympus-primary:#ffffff`, `--olympus-bg:#161213`,
`--olympus-bg-card:#211D1E`, `--olympus-text:#E8E8E8`, `--olympus-border:#352F30`,
`--olympus-cyan:#5CE0E4`, `--olympus-gate:#B49CF0`, etc. Driven by `data-theme`
attribute on `<html>` set by `useTheme` (§3.4).

### 5.4 Typography & misc base rules
- Body font: `'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif`; bg `var(--olympus-bg)` (`base.css:49-53`).
- `h1` 1.75rem brand-colored; `h2` 1.25rem with 2px `--olympus-accent` bottom-border (`base.css:65-86`).
- ⚠️ Visited links pinned to USWDS blue `#005ea2` (light) / cyan (dark) so repeat-navigated entities don't look stale (`base.css:124-139`).
- `.empty-state`, `.onboarding-form`, `.discovery-action`, `.placeholder-page` patterns + a USWDS `[type=search]` float/width neutralizer (`base.css:88-228`).
- Responsive: `@media (max-width:1024px){.olympus-main{padding:20px}}` (`base.css:231-235`).

> The full layout/component/gate-review/app-detail/chat/assembly-lines CSS
> partitions (the rest of the visual system) are large; capture them in a
> companion `05-*` design-token doc for byte-level parity. Token vars + import
> order here are sufficient to reproduce the palette + theming behavior.

---

## 6. DEMO MODE (cross-cutting; `dashboard/src/demo-mode.ts`)

Gated by `VITE_DEMO_MODE`. Public API (`demo-mode.ts`):
- `IS_DEMO_MODE` / `isDemoMode()` (`:59,87`); `FIXED_DEMO_CLOCK_ISO="2026-05-08T14:22:00Z"` (`:73`); `useDemoClock()` (`:99`).
- `DEMO_FIXTURE_PATH="/test-data/demo/atlas-challenge"` (`:80`); `getDemoFixture` (imported by `client.ts:7`).
- `shouldPollTick()` (`:123`) — `usePollingBackoff` skips ticks when demo + tab hidden.
- `shouldShortCircuitGateDecision()` (`:170`) — `useSubmitGateDecision` returns a **synthetic** approved/rejected/escalated `GateDetail` instead of POSTing (`useQueries.ts:189-229`).
- `installDemoToastGuard(toast)` (`:211`) — called at `App.tsx:74`; suppresses toasts during recording; `toastForDemo` passthrough escape hatch (`:265`).
- `<DemoModeIndicator/>` rendered in App (`App.tsx:127`).

⚠️ GOTCHA: demo mode must be a NO-OP when the env var is unset (live dashboards
poll normally, toast normally, POST gate decisions for real). Reproduce all
guard call-sites or live behavior subtly changes.

---

## 7. ENV VARS (Vite `import.meta.env`)

| Var | Default | Used by |
| --- | --- | --- |
| `VITE_API_BASE_URL` | `http://localhost:8000` | axios base (`client.ts:9`), SSE base (`useWebSocket.ts:11`), Login OIDC redirect (`Login.tsx:79`) |
| `VITE_WS_BASE_URL` | `ws://localhost:8000` | WebSocket (`useWebSocket.ts:9`) |
| `VITE_DEMO_MODE` | unset | demo-mode guards (`demo-mode.ts`) |

---

## 8. REBUILD CHECKLIST (parity gate)

1. `main.tsx`: mount `<StrictMode><App/></StrictMode>` on `#root`; import `styles/index.css`.
2. `App.tsx`: QueryClient `{staleTime:30_000, refetchOnWindowFocus:true}`; provider nest QueryClient→Artifact→Portfolio→Breadcrumb→BrowserRouter; `<Toaster top-right richColors closeButton>` + `<DemoModeIndicator/>`; call `installDemoToastGuard(toast)` at module load.
3. **All 61 routes** per §1, including 5 redirect components and the hash-redirect-to-embed for wave plan. Static-vs-dynamic ranking gotchas (#29/30, #52/53) preserved.
4. Public + demo routes OUTSIDE Layout; everything else nested under the Layout wrapper route.
5. 3 contexts (Portfolio/Artifact/Breadcrumb) + localStorage keys `olympus-active-portfolio`, `olympus-theme`, `olympus:auth:token` verbatim.
6. Auth = localStorage token + axios bearer interceptor + error-normalizer interceptor; NO route guard.
7. Layout: USWDS Header w/ BrandIcon SVG, PrimaryNav from NAV_SECTIONS, header-right-group (PortfolioPicker, ActiveProfileBadge, WS connection dot, ThemeToggle, CurrentUserMenu), collapsible context sidebar, breadcrumb bar (context-aware for app detail), global keyed ChatDrawer.
8. React Query hooks vs imperative-axios split preserved per §2/§3.1.
9. Token vars + dark-theme + CSS import order per §5.

---

## UNDETERMINED / DEFERRED
- **Component-level props/state** for the ~60 shared components in `dashboard/src/components/` (e.g. `WorkflowControl`, `GateReviewCards`, charts, viewers) are NOT catalogued here — entry-doc scope is routes/pages/state. Needs a companion `05-components` doc.
- **Full CSS** of layout/components/gate-review/app-detail/chat/assembly-lines partitions captured only at the token/import-order level (§5); byte-level reproduction needs a companion design-token doc.
- **Exact HTTP method/path/response shape** for every `fetch*`/`submit*` helper is in `regen/01-api*.md` (cross-referenced by name), not re-derived here.
- `api/client.ts` is 115KB (~hundreds of exported helpers); §2 lists the subset each page imports, not the full export inventory.
