# 01-api — Olympus API Surface (INDEX / Entry Doc)

> **Atomic regeneration spec — entry point for the `olympus-api` FastAPI service.**
> Premise: the codebase is gone; this spec is the only surviving artifact. Optimize for behavioral parity.
> This file is the **INDEX**: app bootstrap, the ordered router mount table, and the global endpoint tally.
> Per-endpoint detail (method/path/auth/request/response/status/path:line) lives in the `01-api-*.md` sibling files
> referenced in §3. Service-layer logic (scoring/gate/merge math) lives in `01-api-services-logic.md`.

**Service:** `olympus-api/` — FastAPI backend (Python). Port **8000**. Started with
`uvicorn src.main:create_app --factory --reload --port 8000` (`olympus-api/src/main.py:3-5`).

**Application factory:** `create_app()` at `olympus-api/src/main.py:139-223`.

---

## 1. App Bootstrap — `create_app()` as Pseudocode

Source: `olympus-api/src/main.py:139-223`. Reproduce **exactly** in this order — middleware
registration order, error-handler registration, and the 39 `include_router` calls are all
ordering-sensitive (see GOTCHAs).

```
# olympus-api/src/main.py

logger = structlog.get_logger()                                   # main.py:64

function _configure_logging(log_level):                           # main.py:67-88
    structlog.configure(processors=[
        merge_contextvars, filter_by_level, add_logger_name,
        add_log_level, PositionalArgumentsFormatter,
        TimeStamper(fmt="iso"), StackInfoRenderer, format_exc_info,
        UnicodeDecoder, ConsoleRenderer,                          # dev console renderer
    ],
      wrapper_class = structlog.stdlib.BoundLogger,
      context_class = dict,
      logger_factory = structlog.stdlib.LoggerFactory(),
      cache_logger_on_first_use = True)
    logging.basicConfig(level = getattr(logging, log_level.upper(), logging.INFO))

@asynccontextmanager
async function _lifespan(app):                                    # main.py:91-128  (STARTUP)
    # Deferred imports (avoid circulars at module load):
    from src.routers.portfolio import hydrate_portfolios_from_db
    from src.services.profile_activation import ProfileActivationError, activate_profile
    from src.services.skill_bootstrap import bootstrap_skills

    # (1) Activate the configured client profile (env OLYMPUS_PROFILE).
    #     Populates the 6 extensibility registries BEFORE any request is served.
    #     Missing/invalid profile is FATAL — re-raise, do not start half-configured.
    try:
        activate_profile()                                        # main.py:106
    except ProfileActivationError:
        logger.exception("profile_activation.failed"); raise      # main.py:107-109  ⚠️ FATAL

    # (2) Bootstrap skills into DB + hydrate portfolios. DB failure is NON-fatal.
    count = 0
    try:
        async for db in get_db():                                 # main.py:113  (one iteration)
            try:
                count = await bootstrap_skills(db)                # main.py:115
            except Exception:
                logger.exception("skill_bootstrap.failed"); count = 0   # main.py:116-118
            try:
                hydrated = await hydrate_portfolios_from_db(db)   # main.py:120
                logger.info("portfolio_hydrate.complete", count=hydrated)
            except Exception:
                logger.exception("portfolio_hydrate.failed")      # main.py:122-123
            break                                                 # main.py:124  ⚠️ only first db yielded
    except Exception:
        logger.exception("skill_bootstrap.db_unavailable")        # main.py:125-126

    set_skill_count(count)                                        # main.py:128  -> src/startup_state.py
    if count == 0:
        logger.error("startup.no_skills",                        # main.py:130-134
                     msg="No skills loaded — system will report as unhealthy")
    yield                                                         # main.py:136  (no shutdown logic)

function create_app() -> FastAPI:                                 # main.py:139-223
    config = AppConfig()                                          # main.py:141  (src/config.py)
    _configure_logging(config.log_level)                          # main.py:142
    init_db(config)                                               # main.py:145  ⚠️ DB init BEFORE lifespan runs

    app = FastAPI(                                                # main.py:147-152
        title       = "Olympus API",
        description = "Olympus platform backend — portfolio management and orchestration",
        version     = config.version,                            # default "0.1.0" (config.py:20)
        lifespan    = _lifespan)

    # ---- Middleware (registration order is LOAD-BEARING) ----  # main.py:153-170
    # Starlette executes middleware in registration order; LAST-registered = INNERMOST.
    # Desired runtime order (outermost -> innermost):
    #     CORS -> RequestId -> RateLimit -> Metrics -> routes
    # Rationale (main.py:153-160): request_id available inside rate-limit errors;
    # metrics sees final response status; rate limiter short-circuits before business logic.
    app.add_middleware(CORSMiddleware,                            # main.py:162-168  (OUTERMOST)
        allow_origins     = config.cors_origins,                 # default ["http://localhost:3000"] (config.py:49)
        allow_credentials = True,
        allow_methods     = ["*"],
        allow_headers     = ["*"])
    app.add_middleware(RequestIdMiddleware)                       # main.py:169
    app.add_middleware(RateLimitMiddleware)                       # main.py:170
    app.add_middleware(MetricsMiddleware)                         # main.py:171  (INNERMOST middleware)

    register_error_handlers(app)                                 # main.py:174  (see §2)

    # ---- Routers: 39 include_router calls, THIS EXACT ORDER ----  # main.py:177-221  (see §3)
    # ⚠️ CHANGED at HEAD 7cb3b20c: admin_audit_router added at main.py:213; all calls after it +1.
    app.include_router(health_router)            # ... 39 calls ...
    ...
    app.include_router(human_paired_agent_router)

    return app                                                   # main.py:223
```

> ⚠️ **GOTCHA — middleware order.** The four `add_middleware` calls at `main.py:162-171` must be in
> the order CORS, RequestId, RateLimit, Metrics. Starlette wraps in registration order so the LAST
> registered runs innermost. Reordering changes which middleware sees the final status / sets the
> request id first. Do not reorder.
>
> ⚠️ **GOTCHA — `init_db` before lifespan.** `init_db(config)` is called inside `create_app` at
> `main.py:145`, *before* the app object exists and before `_lifespan` runs. The lifespan's
> `get_db()` (main.py:113) depends on this having already run.
>
> ⚠️ **GOTCHA — profile activation is fatal, skill bootstrap is not.** `activate_profile()` failure
> re-raises and aborts startup (main.py:107-109). DB / skill-bootstrap / portfolio-hydrate failures
> are caught and logged; the app still starts but reports unhealthy when `count == 0` (the health
> router reads `get_skill_count()`).
>
> ⚠️ **GOTCHA — single DB iteration.** The `async for db in get_db(): ... break` (main.py:113-124)
> intentionally consumes exactly one yielded session. `get_db()` is an async generator dependency.

**Startup state:** `set_skill_count(count)` writes to a module-global in `olympus-api/src/startup_state.py`.
Health/metrics endpoints read it via `get_skill_count()`. A skill count of 0 => system reports unhealthy.

---

## 2. Exception Handlers — `register_error_handlers(app)`

Source: `olympus-api/src/middleware/error_handler.py:49-107`. Four handlers registered, all
emit the **standard error envelope**:

```
{ "error": { "code": <str>, "message": <str>, "details": {<...>}, "request_id": <str|None> } }
```
built by `_error_response(status_code, code, message, details)` at `error_handler.py:35-46`
(reads `get_request_id()` from `request_id.py`).

Handlers (registration order, `error_handler.py:52-107`):

1. **`OlympusHTTPException`** (`error_handler.py:52-59`) — app-level exception carrying a
   machine-readable `code` + optional `error_details` dict. Class def `error_handler.py:20-32`
   (subclasses `starlette.exceptions.HTTPException`). Emits its own `code`, `detail`, `error_details`.
2. **`StarletteHTTPException`** (`error_handler.py:61-73`) — maps status -> code via:
   `{400:BAD_REQUEST, 401:UNAUTHORIZED, 403:FORBIDDEN, 404:NOT_FOUND, 409:CONFLICT, 422:VALIDATION_ERROR, 429:RATE_LIMITED}`,
   default `"ERROR"` (error_handler.py:63-72).
3. **`RequestValidationError`** (`error_handler.py:75-102`) — status **422**, code
   `VALIDATION_ERROR`, message `"Request validation failed"`, `details.errors` = sanitized
   `exc.errors()`. ⚠️ **GOTCHA:** non-JSON-serializable `ctx` values and non-primitive `input`
   values are stringified/`repr()`'d (error_handler.py:81-100) so the envelope never blows up
   mid-serialization on multipart routes or pydantic model-validator `ctx.error` instances.
4. **`Exception`** (catch-all, `error_handler.py:104-107`) — status **500**, code
   `INTERNAL_ERROR`, message `"An internal error occurred"`; logs `unhandled_exception` with
   `exc_info=True`. Detail is intentionally generic (no leak).

---

## 3. Ordered Mount Table — 39 `include_router` Calls

Source order: `olympus-api/src/main.py:177-221`. **Preserve this exact order.** Each row gives the
include line, the router symbol, its `APIRouter(prefix=...)`, and the `01-api-*.md` spec file that
documents its endpoints. ⚠️ **CHANGED at HEAD `7cb3b20c`:** `admin_audit_router` added at row 33 (`main.py:213`); every mount AFTER it shifted +1 (so `human_paired_agent_router` is now `main.py:221`). Count is **39** (was 38).

> ⚠️ **GOTCHA — mount order affects routing.** Three ordering constraints are intentional:
> 1. **Traceability before Artifacts** (lines 199-200): `traceability_router` must mount before
>    `artifacts_router` so specific paths like `/api/v1/artifacts/stale` match before the generic
>    UUID-validated `/api/v1/artifacts/{app_id}` (comment at main.py:196-198).
> 2. **`wave_gates_router` after `gates_router`** (lines 186-187): the `/api/v1/waves/{id}/gates/approve-pending`
>    op lives on a second router with a `/api/v1/waves` prefix.
> 3. **`line_start_router` / `portfolio_profile_router`** are second routers from `lines.py` /
>    `profiles.py` mounted under a different prefix than their primary router.

| # | main.py:line | Router symbol | Source file | `prefix` | Tag(s) | Owning spec file |
|---|---|---|---|---|---|---|
| 1 | 177 | `health_router` | `routers/health.py:25` | *(none)* | `health` | `01-api-portfolio-lines-misc.md` |
| 2 | 178 | `system_router` | `routers/system.py:41` | *(none)* | `System` | `01-api-portfolio-lines-misc.md` |
| 3 | 180 | `systems_router` | `routers/systems.py:64` | `/api/v1` | `Systems` | `01-api-governance-systems.md` |
| 4 | 181 | `auth_router` | `routers/auth.py:69` | `/api/v1/auth` | `Auth` | `01-api-auth.md` |
| 5 | 182 | `portfolio_router` | `routers/portfolio.py:37` | `/api/v1/portfolio` | `portfolio` | `01-api-portfolio-lines-misc.md` |
| 6 | 183 | `profiles_router` | `routers/profiles.py:50` | `/api/v1/profiles` | `profiles` | `01-api-portfolio-lines-misc.md` |
| 7 | 184 | `portfolio_profile_router` | `routers/profiles.py:530` | `/api/v1/portfolio` | `portfolio` | `01-api-portfolio-lines-misc.md` |
| 8 | 185 | `registries_router` | `routers/registries.py:57` | `/api/v1/registries` | `registries` | `01-api-registries.md` |
| 9 | 186 | `applications_router` | `routers/applications.py:78` | `/api/v1/applications` | `Applications` | `01-api-applications.md` |
| 10 | 187 | `gates_router` | `routers/gates.py:86` | `/api/v1/gates` | `Gates` | `01-api-gates-escalations.md` |
| 11 | 188 | `wave_gates_router` | `routers/gates.py:92-95` | `/api/v1/waves` | `Gates`,`Waves` | `01-api-gates-escalations.md` |
| 12 | 189 | `events_router` | `routers/events.py:21` | `/api/v1/events` | `Events` | `01-api-portfolio-lines-misc.md` |
| 13 | 190 | `activity_router` | `routers/activity.py:18` | `/api/v1/activity` | `Activity` | `01-api-portfolio-lines-misc.md` |
| 14 | 191 | `analytics_router` | `routers/analytics.py:66` | `/api/v1/analytics` | `Analytics` | `01-api-skills-analytics.md` |
| 15 | 192 | `waves_router` | `routers/waves.py:106` | `/api/v1/waves` | `Waves` | `01-api-waves.md` |
| 16 | 193 | `git_router` | `routers/git.py:32` | `/api/v1/git` | `Git` | `01-api-portfolio-lines-misc.md` |
| 17 | 194 | `lines_router` | `routers/lines.py:64` | `/api/v1/lines` | `Assembly Lines` | `01-api-portfolio-lines-misc.md` |
| 18 | 195 | `line_start_router` | `routers/lines.py:68` | `/api/v1` | `Assembly Lines` | `01-api-portfolio-lines-misc.md` |
| 19 | 196 | `workflow_signals_router` | `routers/workflow_signals.py:35` | `/api/v1/workflow-signals` | `Workflow Signals` | `01-api-chat-workflows-signals.md` |
| 20 | 200 | `traceability_router` | `routers/traceability.py:47` | `/api/v1` | `Traceability` | `01-api-traceability-bundles.md` |
| 21 | 201 | `artifacts_router` | `routers/artifacts.py:55` | `/api/v1/artifacts` | `Artifacts` | `01-api-portfolio-lines-misc.md` |
| 22 | 202 | `escalations_router` | `routers/escalations.py:49` | `/api/v1/escalations` | `Escalations` | `01-api-gates-escalations.md` |
| 23 | 203 | `governance_router` | `routers/governance.py:82` | `/api/v1/governance` | `Governance` | `01-api-governance-systems.md` |
| 24 | 204 | `chat_router` | `routers/chat.py:67` | *(none)* | `Chat` | `01-api-chat-workflows-signals.md` |
| 25 | 205 | `renditions_router` | `routers/renditions.py:16` | `/api/v1/applications` | `Renditions` | `01-api-portfolio-lines-misc.md` |
| 26 | 206 | `skills_router` | `routers/skills.py:51` | `/api/v1/skills` | `Skills` | `01-api-skills-analytics.md` |
| 27 | 207 | `webhooks_router` | `routers/webhooks.py:30` | `/api/v1/webhooks` | `webhooks` | `01-api-chat-workflows-signals.md` |
| 28 | 208 | `workflows_router` | `routers/workflows.py:30` | `/api/v1/workflows` | `Workflows` | `01-api-chat-workflows-signals.md` |
| 29 | 209 | `agent_runs_router` | `routers/agent_runs.py:23` | `/api/v1/agent-runs` | `Agent Runs` | `01-api-portfolio-lines-misc.md` |
| 30 | 210 | `agents_router` | `routers/agents.py:36` | `/api/v1/agents` | `Agents` | `01-api-portfolio-lines-misc.md` |
| 31 | 211 | `agent_roles_router` | `routers/agent_roles.py:43` | `/api/v1/agent-roles` | `Agent Roles` | `01-api-auth.md` |
| 32 | 212 | `admin_router` | `routers/admin.py:38` | `/api/v1/admin` | `Admin` | `01-api-portfolio-lines-misc.md` |
| 33 | 213 | **admin_audit_router** ⚠️NEW | `routers/admin_audit.py:31` | `/api/v1/admin` | `Admin` | `01-api-portfolio-lines-misc.md` |
| 34 | 214 | `portfolio_members_router` | `routers/portfolio_members.py:36` | `/api/v1/admin` | `Admin` | `01-api-portfolio-lines-misc.md` |
| 35 | 215 | `bundles_router` | `routers/bundles.py:57` | `/api/v1` | `Bundles` | `01-api-traceability-bundles.md` |
| 36 | 216 | `admin_bundles_router` | `routers/admin_bundles.py:36` | `/api/v1/admin` | `Admin` | `01-api-traceability-bundles.md` |
| 37 | 217 | `users_router` | `routers/users.py:45` | `/api/v1/users` | `Users` | `01-api-auth.md` |
| 38 | 218 | `me_router` | `routers/me.py:27` | `/api/v1/me` | `Me` | `01-api-auth.md` |
| 39 | 221 | `human_paired_agent_router` | `routers/human_paired_agent.py:37` | `/api/v1` | `Human-Paired Agent` | `01-api-portfolio-lines-misc.md` |

**Imports** of all 39 symbols: `main.py:23-61`. Note `gates.py`, `lines.py`, and `profiles.py`
each export **two** routers (`main.py:38-39, 44-45, 49-50` respectively). `admin_audit_router`
imported at `main.py:25`.

> ⚠️ **GOTCHA — 36 router *files*, 39 `include_router` calls (CHANGED at HEAD `7cb3b20c`).** There are
> now **36** `.py` router modules (was 35; `admin_audit.py` added), and **39** mount calls (was 38)
> because 3 files (`gates.py`, `lines.py`, `profiles.py`) each export a second `APIRouter` with a
> different prefix. The mount count is **39**.

---

## 4. Global Endpoint Tally (Ground Truth)

> **TWO NUMBERS, both real — do not conflate them (REFRESHED to HEAD `7cb3b20c`):**
> - **240** = the count produced by `grep -cE "@router\.(get|post|put|patch|delete)"` summed across
>   all router files (was 225). This is the GATE-8 counting method (`regen/.workflows/phase-8.js:101`)
>   and the number the workflow calls "ground truth." It counts **only** decorators named `@router.*`.
> - **246** = the **actual** number of HTTP path-operations mounted on the app (was 231). Verified by AST walk
>   over `olympus-api/src/routers/*.py` (count of `*.{get,post,put,patch,delete}(...)` decorators on
>   all `APIRouter` instances). No duplicate `(path, method)` pairs; no `include_in_schema=False`;
>   no `deprecated=True`. All 246 are live and in-schema.
>
> ⚠️ **What grew (225→240 grep):** admin_audit +1, analytics +2 (viewer-events), applications +8 (interview/design/reset/gate-evidence), gates +1 (reviewer-roles), governance +3 (compliance-evidence-export, POST/DELETE schedule). 225 + 1 + 2 + 8 + 1 + 3 = **240**.

### 4.1 The 240 ↔ 246 reconciliation (EXACT)

The 6-operation gap is entirely the **secondary routers** that use a non-`@router` decorator name and
are therefore invisible to `grep -cE "@router\."` (UNCHANGED — still 6):

| Secondary router | File:line | Decorator name | Ops | Paths (full, incl. prefix) |
|---|---|---|---|---|
| `wave_gates_router` | `gates.py:92`; decl `:640` | `@wave_gates_router.*` | 1 | `POST /api/v1/waves/{wave_id}/gates/approve-pending` (gates.py:640-643) |
| `line_start_router` | `lines.py:68`; decls `:395,:410,:425` | `@line_start_router.*` | 3 | `POST /api/v1/architecture/start` (lines.py:395-399), `POST /api/v1/data/start` (lines.py:410-414), `POST /api/v1/modernization/start` (lines.py:425-429) |
| `portfolio_profile_router` | `profiles.py:530`; decls `:615,:753` | `@portfolio_profile_router.*` | 2 | `GET /api/v1/portfolio/{portfolio_id}/profile-bundle` (profiles.py:615-621), `PUT /api/v1/portfolio/{portfolio_id}/profile` (profiles.py:753-757) |

`240 (@router-only) + 1 + 3 + 2 = 246 actual mounted operations.`

> ⚠️ **GOTCHA — the gate UNDERCOUNTS by 6.** GATE-8 greps `@router\.` per file (phase-8.js:101),
> which silently drops the 6 ops above. When verifying parity, the regenerated app must expose
> **246** path-operations, not 240. The owning spec files (`01-api-gates-escalations.md`,
> `01-api-portfolio-lines-misc.md`) MUST document these 6 secondary-router endpoints even though the
> gate's grep won't count them.

### 4.2 Per-router endpoint counts

Counts below are the **`@router`-only grep count** (the gate's number) per file, matching how
phase-8.js assigns owning spec files. The **Actual** column adds secondary-router ops where they
exist. Routers sorted by mount-table order.

| Router file | Symbol(s) | grep `@router` | + secondary | **Actual** | Owning spec file |
|---|---|---:|---:|---:|---|
| `health.py` | `health_router` | 4 | — | 4 | `01-api-portfolio-lines-misc.md` |
| `system.py` | `system_router` | 4 | — | 4 | `01-api-portfolio-lines-misc.md` |
| `systems.py` | `systems_router` | 12 | — | 12 | `01-api-governance-systems.md` |
| `auth.py` | `auth_router` | 10 | — | 10 | `01-api-auth.md` |
| `portfolio.py` | `portfolio_router` | 4 | — | 4 | `01-api-portfolio-lines-misc.md` |
| `profiles.py` | `profiles_router` (+ `portfolio_profile_router`) | 4 | +2 | **6** | `01-api-portfolio-lines-misc.md` |
| `registries.py` | `registries_router` | 32 | — | 32 | `01-api-registries.md` |
| `applications.py` | `applications_router` | **30 ⚠️(+8)** | — | **30** | `01-api-applications.md` |
| `gates.py` | `gates_router` (+ `wave_gates_router`) | **9 ⚠️(+1)** | +1 | **10** | `01-api-gates-escalations.md` |
| `events.py` | `events_router` | 1 | — | 1 | `01-api-portfolio-lines-misc.md` |
| `activity.py` | `activity_router` | 1 | — | 1 | `01-api-portfolio-lines-misc.md` |
| `analytics.py` | `analytics_router` | **13 ⚠️(+2)** | — | **13** | `01-api-skills-analytics.md` |
| `waves.py` | `waves_router` | 32 | — | 32 | `01-api-waves.md` |
| `git.py` | `git_router` | 1 | — | 1 | `01-api-portfolio-lines-misc.md` |
| `lines.py` | `lines_router` (+ `line_start_router`) | 4 | +3 | **7** | `01-api-portfolio-lines-misc.md` |
| `workflow_signals.py` | `workflow_signals_router` | 1 | — | 1 | `01-api-chat-workflows-signals.md` |
| `traceability.py` | `traceability_router` | 7 | — | 7 | `01-api-traceability-bundles.md` |
| `artifacts.py` | `artifacts_router` | 4 | — | 4 | `01-api-portfolio-lines-misc.md` |
| `escalations.py` | `escalations_router` | 4 | — | 4 | `01-api-gates-escalations.md` |
| `governance.py` | `governance_router` | **12 ⚠️(+3)** | — | **12** | `01-api-governance-systems.md` |
| `chat.py` | `chat_router` | 5 | — | 5 | `01-api-chat-workflows-signals.md` |
| `renditions.py` | `renditions_router` | 2 | — | 2 | `01-api-portfolio-lines-misc.md` |
| `skills.py` | `skills_router` | 11 | — | 11 | `01-api-skills-analytics.md` |
| `webhooks.py` | `webhooks_router` | 1 | — | 1 | `01-api-chat-workflows-signals.md` |
| `workflows.py` | `workflows_router` | 4 | — | 4 | `01-api-chat-workflows-signals.md` |
| `agent_runs.py` | `agent_runs_router` | 1 | — | 1 | `01-api-portfolio-lines-misc.md` |
| `agents.py` | `agents_router` | 2 | — | 2 | `01-api-portfolio-lines-misc.md` |
| `agent_roles.py` | `agent_roles_router` | 1 | — | 1 | `01-api-auth.md` |
| `admin.py` | `admin_router` | 1 | — | 1 | `01-api-portfolio-lines-misc.md` |
| `admin_audit.py` ⚠️NEW | `admin_audit_router` | 1 | — | 1 | `01-api-portfolio-lines-misc.md` |
| `portfolio_members.py` | `portfolio_members_router` | 3 | — | 3 | `01-api-portfolio-lines-misc.md` |
| `bundles.py` | `bundles_router` | 7 | — | 7 | `01-api-traceability-bundles.md` |
| `admin_bundles.py` | `admin_bundles_router` | 2 | — | 2 | `01-api-traceability-bundles.md` |
| `users.py` | `users_router` | 6 | — | 6 | `01-api-auth.md` |
| `me.py` | `me_router` | 1 | — | 1 | `01-api-auth.md` |
| `human_paired_agent.py` | `human_paired_agent_router` | 3 | — | 3 | `01-api-portfolio-lines-misc.md` |
| **TOTAL** | | **240** | **+6** | **246** | |

> ⚠️ **GOTCHA — FOUR `/api/v1/admin`-prefixed routers (was three).** `admin.py`, `admin_audit.py` (NEW),
> `portfolio_members.py`, and `admin_bundles.py` all use `prefix="/api/v1/admin"` and tag `Admin`. They
> are separate modules; their endpoints share the namespace. Mount order (`main.py:212, 213, 214, 216`)
> governs path-match precedence within `/api/v1/admin/*`. `admin_audit` owns `GET /api/v1/admin/audit-log`.
>
> ⚠️ **GOTCHA — `renditions.py` shares `applications.py`'s prefix.** Both use
> `prefix="/api/v1/applications"`. `applications_router` mounts first (`main.py:186`), `renditions_router`
> later (`main.py:205`).

---

## 5. Owning Spec Files (where per-endpoint detail lives)

The detailed per-endpoint specs are produced as these sibling files under `regen/` (group→file map
from `regen/.workflows/phase-8.js:55-67`):

| Spec file | Routers covered | Endpoints (actual) | Notes |
|---|---|---:|---|
| `01-api-waves.md` | `waves` | 32 | Largest router (`waves.py`, ~3300 lines). Many ops fire Temporal signals (gate decisions, dispatch). |
| `01-api-registries.md` | `registries` | 32 | The 6-extension-point registry API surface. |
| `01-api-applications.md` | `applications` | **30 ⚠️(+8)** | NEW at HEAD: design-artifacts, design-feedback, interview×4, workflow/reset, gate-evidence (E23–E30). |
| `01-api-governance-systems.md` | `governance` (**12 ⚠️+3**), `systems` (12) | **24** | governance +3 (compliance-evidence-export, POST/DELETE schedule); fires Temporal (sweep + schedule). |
| `01-api-skills-analytics.md` | `skills` (11), `analytics` (**13 ⚠️+2**) | **24** | analytics +2 viewer-events (B12/B13); skills A9 rewired to `skill_metrics` projection. |
| `01-api-auth.md` | `auth` (10), `users` (6), `me` (1), `agent_roles` (1) | 18 | **Owns the AUTH DEEP-DIVE**: JWT/OIDC flow, scopes, token validation, how scopes guard endpoints; auth dependency/middleware (`src/middleware/auth.py`, `src/dependencies.py`) as pseudocode. |
| `01-api-gates-escalations.md` | `gates` (**9 ⚠️+1** + `wave_gates_router` 1 = 10), `escalations` (4) | **14** | ⚠️ P6-S6 RBAC overhaul (quorum/oversight, gate_rbac); +1 `reviewer-roles`. gate-decision→signal path reproduced. **Owns the 1 `wave_gates_router` op.** |
| `01-api-traceability-bundles.md` | `traceability` (7), `bundles` (7, fires signals), `admin_bundles` (2) | 16 | |
| `01-api-chat-workflows-signals.md` | `chat` (5), `workflows` (4), `workflow_signals` (1, signals), `webhooks` (1, signals) | 11 | Reproduces the `workflow_signals` + `webhooks` signal-firing paths. |
| `01-api-portfolio-lines-misc.md` | `portfolio` (4), `portfolio_members` (3), **`admin_audit` (1 ⚠️NEW)**, `lines` (4 + `line_start_router` 3 = 7, signals), `profiles` (4 + `portfolio_profile_router` 2 = 6), `system` (4, signals), `health` (4), `artifacts` (4), `renditions` (2), `agents` (2, signals), `agent_runs` (1), `admin` (1), `activity` (1), `events` (1), `git` (1), `human_paired_agent` (3) | **45** | The remaining routers. **Owns the NEW `admin_audit` op, the 3 `line_start_router` ops + 2 `portfolio_profile_router` ops.** |
| `01-api-services-logic.md` | *(service layer, not routers)* | — | PSEUDOCODE of non-trivial logic: `scoring.py`, `gate.py`(+`gate_rbac.py`,quorum), `git_service.py`, `wave.py`, `step_mapping.py`, `application.py`; + NEW modules `audit_log/viewer_analytics/skill_metrics/governance_schedule/evidence_export/interview/design_review`; 2-3 line contracts for the rest. |

Sum of "actual" endpoint counts across the 10 router spec files: 32+32+30+24+24+18+14+16+11+45 = **246**. ✔

---

## 6. Cross-References

- **App identity, config/env, DB layer, DI, middleware internals, models, services, Docker, testing,
  coverage floor:** see the pre-existing companion `specifications/regeneration/01-olympus-api.md`
  (single-file reference; §2-§13). This `regen/01-api.md` set supersedes its router tables with the
  exhaustive per-endpoint `01-api-*.md` files.
- **Middleware (Request ID / Rate limit / Metrics / Pagination):** `olympus-api/src/middleware/*.py`
  (request_id.py, rate_limit.py, metrics.py, pagination.py, error_handler.py, auth.py).
- **Config defaults:** `olympus-api/src/config.py` — `version="0.1.0"` (:20), `log_level="INFO"` (:21),
  `cors_origins=["http://localhost:3000"]` (:49).
- **Startup state shim:** `olympus-api/src/startup_state.py` (`set_skill_count` / `get_skill_count`).
- **Temporal signal firing (gate decisions, dispatch, line start):** detail in `01-api-gates-escalations.md`,
  `01-api-waves.md`, `01-api-chat-workflows-signals.md`, and `01-api-portfolio-lines-misc.md`.

---

## 7. Atomic Rebuild Checklist (this index)

1. **`create_app()` factory** — build per §1 pseudocode. Acceptance: `uvicorn src.main:create_app --factory`
   boots; `GET /health` responds.
2. **Middleware stack** — register CORS→RequestId→RateLimit→Metrics in that order (main.py:161-170).
   Acceptance: a 429 response carries an `X-Request-ID`-derived `request_id` in its error envelope.
3. **Lifespan** — profile activation fatal, skill bootstrap / portfolio hydrate non-fatal; `set_skill_count`
   called (§1). Acceptance: invalid `OLYMPUS_PROFILE` aborts startup; DB-down still boots but reports unhealthy.
4. **Exception handlers** — 4 handlers, standard envelope (§2). Acceptance: a validation error returns
   422 with `error.code == "VALIDATION_ERROR"` and JSON-serializable `details.errors`.
5. **39 router mounts** — exact order/prefixes per §3. Acceptance: `len([r for r in app.routes if hasattr(r,"methods")])`
   path-operations == **246** (NOT 240); `/api/v1/artifacts/stale` resolves before `/api/v1/artifacts/{app_id}`.
6. **Endpoint tally** — per-router counts match §4.2 "Actual" column; the 6 secondary-router ops (§4.1)
   are present. Acceptance: AST/OpenAPI route count == 246; the 3 secondary routers each contribute
   their ops (wave_gates 1, line_start 3, portfolio_profile 2). `@router`-only grep == 240.
