# 04 — Data Layer (SPINE / Entry Doc)

> **Atomic regeneration spec.** Premise: the codebase is deleted; this is the only surviving artifact. Optimize for behavioral parity — the schema must be rebuildable EXACTLY. This file is the **spine**: it owns the enum types, the full migration DAG ledger, the Git‑as‑source‑of‑truth + projection model, the seeds, and an index of the per‑table‑group files. Column‑by‑column table specs live in the sibling files indexed in §6.

**Authoritative sources (rebuild these EXACTLY):**

- Migrations: `/Users/pnunna/Documents/GitHub/foundry/db/alembic/versions/*.py` — **65 files** (`001`–`054`, then **055 is intentionally absent**, then `056`–`066`).
- Alembic harness: `/Users/pnunna/Documents/GitHub/foundry/db/alembic/env.py`, `/Users/pnunna/Documents/GitHub/foundry/db/alembic.ini`, `/Users/pnunna/Documents/GitHub/foundry/db/alembic/script.py.mako`.
- DB bootstrap: `/Users/pnunna/Documents/GitHub/foundry/db/init/01-create-databases.sh`, `/Users/pnunna/Documents/GitHub/foundry/db/Dockerfile`, `/Users/pnunna/Documents/GitHub/foundry/db/requirements.txt`.
- Seeds: `/Users/pnunna/Documents/GitHub/foundry/db/seeds/initial-data.sql`, `/Users/pnunna/Documents/GitHub/foundry/db/seeds/README.md`.
- Projection layer (Git→PG): `/Users/pnunna/Documents/GitHub/foundry/regen/03b-activities/` (the `persist_*` activities) — see §5 for the per‑function cross‑reference table.

> ⚠️ **PROMPT‑DRIFT CORRECTIONS (verified against the files).** The driving prompt said "56 migrations" and "15 enum types." The repository actually has **65 migration files** and **13 enum types**. Specifically:
> - **65 migrations** numbered `001`–`066` with **`055` missing** (no `055_*.py` exists; `056`'s `down_revision` is `"054"`). Count files: `001`–`054` = 54, `056`–`066` = 11 → **65**.
> - **13 enum types**, not 15: **12** created in `001_create_enum_types.py` + **1** (`archetype_enum`) created in `021_add_application_archetype.py:37`.
> - The merge migration `039` has **4 parents** (`"034", "035", "037", "038"`), not 2 — see §3/§4.
> - The 3 `ALTER TYPE … ADD VALUE` statements (all on `gate_status_enum`) match the prompt: `'escalated'` (013), `'preparing'` (019), `'merge_blocked'` (040).
> A faithful rebuild MUST reproduce 65 migrations with the 055 gap and 13 enums (12 in `001` + `archetype_enum` in `021`). Do not "fix" the gap by renumbering.

---

## 0. WHAT THIS LAYER IS (one paragraph)

PostgreSQL is the Olympus **query layer** — a *derived, disposable* projection of artifacts that live in Git. Git (the artifact repos, branch‑per‑task, PRs‑as‑gates) is the **source of truth**; Postgres exists so the dashboard and API can issue fast relational/JSONB queries without walking Git trees (`db/README.md:1-5`, CLAUDE.md Core Principle #4). Temporal uses a **separate** database — these migrations cover only the Olympus application schema (`db/README.md:5`). The schema is built by **Alembic** (DDL‑only migrations; data normalization is the rare exception, e.g. `022`), seeded separately (§4), and populated at runtime by the `persist_*` Temporal **activities** that project artifact JSON → table rows (§5). Postgres can be dropped and rebuilt at any time: `alembic upgrade head` recreates the schema, seeds load a baseline, and re‑running the assembly‑line workflows re‑projects every row from the Git artifacts.

---

## 1. ENUM TYPES (13 total)

All enum types are PostgreSQL `CREATE TYPE … AS ENUM`. **12** are created up front in `001_create_enum_types.py:21-98`; the 13th (`archetype_enum`) is created in `021`. Tables reference them via `sqlalchemy.dialects.postgresql.ENUM(..., create_type=False)` so SQLAlchemy never re‑emits `CREATE TYPE` (`002_create_core_tables.py:16-18`).

> **DDL/seed separation:** `001` is DDL‑only by rule — it defines types, inserts no data (`001:8`).

### 1.1 The 12 enums created in `001` — FINAL value sets

`001` ordering is significant only for `downgrade()` (drops in reverse). Value order within each `CREATE TYPE` is the canonical sort order PostgreSQL assigns.

| # | Enum type | Final value set (in declared order) | Source | Notes |
|---|-----------|-------------------------------------|--------|-------|
| 1 | `risk_tier_enum` | `'1'`, `'2'`, `'3'` | `001:22-24` | Tier **strings** (not ints). Tier 1 = highest criticality. Used by `application.risk_tier`. |
| 2 | `complexity_tier_enum` | `'simple'`, `'moderate'`, `'complex'` | `001:26-30` | `application.complexity_tier`. |
| 3 | `tier_source_enum` | `'auto'`, `'confirmed'`, `'overridden'` | `001:32-36` | Provenance of a classified value: auto = computed by skill, confirmed = stakeholder sign‑off, overridden = stakeholder supplied a different value (`021:7-13`). Reused by `risk_tier_source`, `complexity_tier_source`, `archetype_source`. |
| 4 | `disposition_enum` | `'Retire'`, `'Retain'`, `'Refactor'`, `'Rearchitect'`, `'Replace'`, `'Replatform'`, `'Consolidate'` | `001:38-43` | The **7 canonical dispositions** (CLAUDE.md). Capitalized exactly as shown. |
| 5 | `gate_type_enum` | `'G-DC'`, `'G-RR'`, `'G-DA'`, `'G-02'`, `'G-DT'`, `'G-04a'`, `'G-04b'`, `'G-04c'`, `'G-DE-1'`, `'G-DE-2'`, `'G-V1'`, `'G-V2'`, `'G-V3'`, `'G-DP-1'`, `'G-DP-2'` | `001:45-53` | The **15 standard gates** (CLAUDE.md). |
| 6 | `gate_status_enum` | `'pending'`, `'approved'`, `'rejected'`, `'overridden'`, **`'escalated'`** (013), **`'preparing'`** (019), **`'merge_blocked'`** (040) | `001:55-59` + ADD VALUEs | **4 base values + 3 added later.** See §1.3 for the ⚠️ ADD VALUE gotcha. |
| 7 | `assembly_line_enum` | `'Discovery'`, `'Rationalization'`, `'Architecture'`, `'Data'`, `'Modernization'`, `'Disposition Execution'`, `'Validation'`, `'Deployment'`, `'Sustainment'`, `'Governance'` | `001:61-67` | The **10 assembly lines**. Note `'Disposition Execution'` has a space. |
| 8 | `task_status_enum` | `'queued'`, `'dispatched'`, `'running'`, `'completed'`, `'failed'`, `'timed_out'` | `001:69-74` | `agent_task.status`. |
| 9 | `escalation_status_enum` | `'open'`, `'investigating'`, `'resolved'` | `001:76-80` | `escalation.status`. |
| 10 | `escalation_type_enum` | `'Technical'`, `'Domain'`, `'Strategic'`, `'Safety'`, `'Infrastructure'` | `001:82-86` | `escalation.escalation_type`. |
| 11 | `escalation_severity_enum` | `'Critical'`, `'Standard'`, `'Low'` | `001:88-92` | `escalation.severity`. |
| 12 | `actor_type_enum` | `'human'`, `'agent'`, `'system'` | `001:94-98` | Audit / chat actor classification. |

### 1.2 The 13th enum — created in `021`

| # | Enum type | Final value set | Source | Notes |
|---|-----------|-----------------|--------|-------|
| 13 | `archetype_enum` | `'web-app'`, `'batch-etl'`, `'api-service'`, `'scheduled-job'`, `'hybrid'` | `021:36-41` | `application.archetype`. Created in the SAME migration that adds the column (`021` uses `create_type=False` on the column‑side `sa.Enum(...)` to avoid double creation — `021:36-41` runs the bare `CREATE TYPE` first, then `021:46-55` adds the column with `create_type=False`). `archetype_source` reuses `tier_source_enum` (`021:56-67`). |

> The driving prompt's "15 enums" is wrong. There are **13** (12 in `001` + `archetype_enum` in `021`). (If a 14th/15th was ever expected, it does not exist in the migration tree — do not invent one.)

### 1.3 ⚠️ THE `ALTER TYPE … ADD VALUE` GOTCHA (gate_status_enum)

**`gate_status_enum` is the ONLY enum extended after creation.** Three values are added by three separate migrations, each with `ADD VALUE IF NOT EXISTS`:

| Migration | Statement | Source | Value position |
|-----------|-----------|--------|----------------|
| `013` | `ALTER TYPE gate_status_enum ADD VALUE IF NOT EXISTS 'escalated'` | `013:21` | appended after `'overridden'` |
| `019` | `ALTER TYPE gate_status_enum ADD VALUE IF NOT EXISTS 'preparing'` | `019:24` | appended after `'escalated'` |
| `040` | `ALTER TYPE gate_status_enum ADD VALUE IF NOT EXISTS 'merge_blocked'` | `040:48-50` | appended after `'preparing'` |

**FINAL `gate_status_enum` value set (7 values, in this exact sort order):**
```
'pending', 'approved', 'rejected', 'overridden', 'escalated', 'preparing', 'merge_blocked'
```

⚠️ **GOTCHA — why this is fragile and must be reproduced verbatim:**

1. **NON‑TRANSACTIONAL.** Postgres forbids `ALTER TYPE … ADD VALUE` inside a transaction block that *then uses the new value*; historically `ADD VALUE` could not run inside a txn at all. Alembic wraps each migration's `upgrade()` in a transaction (`env.py:100,117` → `context.begin_transaction()`). Because these three migrations **only** issue the `ADD VALUE` (no use of the new value in the same migration), Postgres ≥12 permits them inside the txn. **A rebuild MUST keep each ADD VALUE in its own migration and MUST NOT, in the same migration, both add a value and insert/compare rows using it.** Splitting one migration into "add value" + "use value" steps (separate migrations) is the safe pattern; these three already do that implicitly (the values are consumed only by later workflow code, never by the migration).

2. **ORDERING‑SENSITIVE.** Enum sort order = insertion order. `'escalated'` (013) sorts before `'preparing'` (019) before `'merge_blocked'` (040). Any query that does `ORDER BY status::gate_status_enum` or range comparisons depends on this order. **Reproduce the ADD VALUE statements in revision order (013 → 019 → 040)** or the sort order changes. (Do NOT batch all three into `001` — that would reorder them relative to `'overridden'` and is a different type.)

3. **IDEMPOTENCY.** Each uses `IF NOT EXISTS` (`013:21`, `019:24`, `040:49`) so re‑runs in test/dev environments don't fail (`040:46-47` comment). Keep `IF NOT EXISTS`.

4. **IRREVERSIBLE downgrade.** Postgres cannot remove an enum value. All three `downgrade()`s are no‑ops / leave the value in place (`013:24-27`, `040:59-63`). `040`'s downgrade drops only the `merge_failure_detail` column; the enum value stays (`040:60-63`). A rebuild's downgrades must mirror this (do not attempt to recreate the type without the value unless you also rewrite every dependent column).

---

## 2. ENUM CROSS‑REFERENCE — which columns use which enum

(Spot‑reference; full column specs in the per‑group files §6.)

| Enum | Columns (table.column) | Added by |
|------|------------------------|----------|
| `assembly_line_enum` | `application.current_line` | `002:86` |
| `risk_tier_enum` | `application.risk_tier` | `002:89` |
| `complexity_tier_enum` | `application.complexity_tier` | `002:91` |
| `tier_source_enum` | `application.risk_tier_source`, `application.complexity_tier_source`, `application.archetype_source` | `002:90,92`; `021:56-67` |
| `disposition_enum` | `application.disposition` (+ disposition/capability‑grain columns added in `029`/`058`/`052`) | `002:96`; see §6 rationalization group |
| `archetype_enum` | `application.archetype` | `021:46-55` |
| `gate_type_enum` | `gate.gate_type` | `003` (workflow group) |
| `gate_status_enum` | `gate.status` | `003` (workflow group) |
| `task_status_enum` | `agent_task.status` | `003` (workflow group) |
| `escalation_status_enum` / `escalation_type_enum` / `escalation_severity_enum` | `escalation.*` | `003` (workflow group) |
| `actor_type_enum` | audit / chat actor columns | `004` / `014` (see groups) |

---

## 3. THE FULL MIGRATION DAG — ordered ledger (65 migrations)

**Revision id format:** plain zero‑padded numeric strings (`"001"`…`"066"`). `file_template = %%(rev)s_%%(slug)s` (`alembic.ini`). **Current head: `066`** (the only revision that is no other migration's `down_revision`).

> ⚠️ **The chain is LINEAR except for one branch+merge around `033`–`039`.** See §3.1 for the branch. Everything `001`→`033` is a straight line; `034`/`035`/`036`/`038` fan out from `033`; `037` chains off `036`; `039` merges; `040`→`066` is a straight line again. **`055` does not exist** — `056.down_revision = "054"`.

| Rev | down_revision | One‑line purpose | File |
|-----|---------------|------------------|------|
| `001` | `None` (base) | Create 12 enum types (DDL only) | `001_create_enum_types.py` |
| `002` | `001` | Core tables: `portfolio`, `wave`, `application`, `wave_application` | `002_create_core_tables.py` |
| `003` | `002` | Workflow tables: `gate`, `agent_task`, `escalation` | `003_create_workflow_tables.py` |
| `004` | `003` | Analytics tables: `model_config`, `model_override`, `score_history`, `traceability_link`, `audit_log` | `004_create_analytics_tables.py` |
| `005` | `004` | Indexes for dashboard query patterns | `005_create_indexes.py` |
| `006` | `005` | Add `name`, `created_at`, `updated_at` to `wave` | `006_add_wave_name_timestamps.py` |
| `007` | `006` | Add `workflow_id` to `wave` | `007_add_wave_workflow_id.py` |
| `008` | `007` | Add `artifact_repo_url` to `portfolio` | `008_add_portfolio_artifact_repo_url.py` |
| `009` | `008` | Add `source_git_token`, `source_git_base_url` to `application` | `009_add_application_git_columns.py` |
| `010` | `009` | Add `workflow_id` to `application` | `010_add_application_workflow_id.py` |
| `011` | `010` | Add `workflow_id`, `sla_deadline`, `evidence_package_url` to `gate` | `011_add_gate_workflow_columns.py` |
| `012` | `011` | Add `evidence_data` JSONB to `gate` | `012_add_gate_evidence_data.py` |
| `013` | `012` | **ADD VALUE** `'escalated'` → `gate_status_enum` | `013_add_gate_escalated_status.py` |
| `014` | `013` | Create `chat_message` table | `014_create_chat_message_table.py` |
| `015` | `014` | Create `skill` table | `015_create_skill_table.py` |
| `016` | `015` | Add `description` + target‑repo columns to `application` | `016_add_application_edit_columns.py` |
| `017` | `016` | Add structured columns to `skill` (runtime enrichment) | `017_add_skill_structured_columns.py` |
| `018` | `017` | Add `scripts_data` JSONB to `skill` | `018_add_skill_scripts_data.py` |
| `019` | `018` | **ADD VALUE** `'preparing'` → `gate_status_enum` | `019_add_gate_preparing_status.py` |
| `020` | `019` | Add `reject_reason_category` to `gate` | `020_add_gate_reject_reason_category.py` |
| `021` | `020` | Create `archetype_enum`; add `archetype` + `archetype_source` to `application` | `021_add_application_archetype.py` |
| `022` | `021` | **DATA MIGRATION** — normalize legacy `wave.status` (`planned`→`draft`, `active`→`in_progress`) | `022_normalize_wave_status_values.py` |
| `023` | `022` | `wave.status` lifecycle: flip default `planned`→`draft`; add `wave_status_lifecycle_chk` CHECK | `023_wave_status_lifecycle.py` |
| `024` | `023` | Add `portfolio_score` JSONB to `application` | `024_add_application_portfolio_score.py` |
| `025` | `024` | Governance tables: `health_check`, `drift_alert`, `pattern` | `025_create_governance_tables.py` |
| `026` | `025` | Create `user_account` + password credential tables (Auth & Roles) | `026_create_user_table.py` |
| `027` | `026` | Extend `agent_task` with agent‑performance columns + benchmark view | `027_extend_agent_task_for_metrics.py` |
| `028` | `027` | Add Discovery side‑effect projection columns to `application` | `028_add_discovery_side_effect_columns.py` |
| `029` | `028` | Add Rationalization disposition projection columns to `application` | `029_add_rationalization_disposition_columns.py` |
| `030` | `029` | Add Architecture projection columns + `application_lineage` table | `030_add_architecture_projection_columns.py` |
| `031` | `030` | Add Data projection columns + `shared_db_cluster` table | `031_add_data_projection_columns.py` |
| `032` | `031` | Add Modernization projection columns + `bounded_context` table | `032_add_modernization_projection_columns.py` |
| `033` | `032` | Create `step_execution` table (Layer B execution envelope) — **BRANCH POINT** | `033_create_step_execution_table.py` |
| `034` | **`033`** | Add Disposition Execution projection columns to `application` | `034_add_disposition_projection_columns.py` |
| `035` | **`033`** | Add Validation side‑effect projection columns | `035_add_validation_projection_columns.py` |
| `036` | **`033`** | Add Deployment side‑effect projection columns | `036_add_deployment_projection_columns.py` |
| `037` | **`036`** | Create Sustainment sweep tables + application lifecycle columns | `037_create_sustainment_tables.py` |
| `038` | **`033`** | Add Governance sweep tables: `factory_capacity_plan`, `model_benchmark_result` | `038_add_governance_sweep_tables.py` |
| `039` | **`("034","035","037","038")`** | **MERGE** the W19 reconciliation heads (see §3.1) | `039_merge_w19_reconciliation_heads.py` |
| `040` | `039` | **ADD VALUE** `'merge_blocked'` → `gate_status_enum`; add `gate.merge_failure_detail` JSONB | `040_add_gate_merge_blocked.py` |
| `041` | `040` | Add `wave.description` | `041_add_wave_description.py` |
| `042` | `041` | Wave‑scoped gates: `gate.application_id`→nullable, add `gate.wave_id` FK, `gate_application_or_wave_ck`, index | `042_gate_wave_scoped.py` |
| `043` | `042` | `wave.status` add `'failed'` (extend CHECK); add `wave.failed_at`, `wave.failure_reason` | `043_wave_failed_status.py` |
| `044` | `043` | Wave‑scoped `agent_task`: `application_id`→nullable, add `wave_id` FK, `agent_task_application_or_wave_ck`, index | `044_agent_task_wave_scoped.py` |
| `045` | `044` | `wave.status` add fan‑out statuses (`awaiting-architecture-dispatch`, `architecture-in-flight`, `data-in-flight`) | `045_wave_architecture_fanout_statuses.py` |
| `046` | `045` | Create `arch_data_signal_registry` table (decouple peer workflow IDs) | `046_create_arch_data_signal_registry.py` |
| `047` | `046` | Document + partial‑index `consolidated_into_target` `current_status` (COMMENT + partial index; NO CHECK change) | `047_add_consolidated_into_target_status.py` |
| `048` | `047` | Create `workflow_signal_inbox` table (DB‑backed signal durability) | `048_create_workflow_signal_inbox.py` |
| `049` | `048` | `wave.status` add `'stuck-awaiting-recovery'` (extend CHECK) | `049_add_stuck_awaiting_recovery_wave_status.py` |
| `050` | `049` | Capability + system grain tables (`system`, `system_application`, `capability`, `business_domain`, + lineage/join tables, `agent_task_session_artifact`) | `050_capability_system_grain.py` |
| `051` | `050` | Add `metadata` JSONB to `application` | `051_add_application_metadata.py` |
| `052` | `051` | Rationalization capability layer: `rationalization_capability` table | `052_rationalization_capability.py` |
| `053` | `052` | Add `target_service_id` to `application` | `053_add_target_service_id_to_application.py` |
| `054` | `053` | Add `architecture_workflow_id` to `wave` | `054_add_architecture_workflow_id_to_wave.py` |
| `056` | **`054`** | Create `portfolio_membership` table (**055 is skipped**) | `056_create_portfolio_membership.py` |
| `057` | `056` | Create `delegated_bundle` + 4 child tables | `057_create_delegated_bundle.py` |
| `058` | `057` | Redefine `application_disposition` for capability‑grain dispositions | `058_application_disposition_capability_grain.py` |
| `059` | `058` | `wave.status` add Modernization statuses (`modernization-in-flight`, `modernization-complete`) | `059_wave_modernization_statuses.py` |
| `060` | `059` | Create `skill_metrics` table | `060_create_skill_metrics.py` |
| `061` | `060` | Create `viewer_event` table (viewer‑analytics telemetry) | `061_create_viewer_event.py` |
| `062` | `061` | Create `gate_approval` table + multi‑approval columns on `gate` (RBAC) | `062_rbac_gate_approval.py` |
| `063` | `062` | Add `dispatching_workflow_id` to `delegated_bundle` | `063_bundle_dispatching_workflow.py` |
| `064` | `063` | Add provider columns to `agent_task` | `064_agent_task_provider.py` |
| `065` | `064` | Create `design_annotation` table | `065_create_design_annotation.py` |
| `066` | `065` | Create `interview_session` table — **HEAD** | `066_create_interview_session.py` |

### 3.1 ⚠️ THE BRANCH + MERGE (`033` → `039`) — reproduce exactly

The W19 reconciliation work landed four parallel feature branches, all forked from `033`. This produced **four Alembic heads** that `039` merges. Reproduce the **down_revision wiring** exactly:

```
                                 033  (step_execution — branch point)
                                  │
        ┌──────────────┬──────────┼──────────────┐
        ▼              ▼          ▼              ▼
       034            035        036            038
   (disposition)  (validation) (deployment)  (governance sweep)
                                  │
                                  ▼
                                 037
                              (sustainment)
        │              │          │           │
        └──────────────┴────┬─────┴───────────┘
                            ▼
              039  down_revision = ("034", "035", "037", "038")     ← 4‑PARENT MERGE
                            │
                            ▼
                           040 … 066 (linear) → HEAD
```

**Exact merge declaration (`039_merge_w19_reconciliation_heads.py`):**
```python
revision: str = "039"
down_revision: Union[str, Sequence[str], None] = ("034", "035", "037", "038")
```

> ⚠️ **Subtlety:** the four merge parents are `034, 035, 037, 038` — **`036` is NOT a direct parent.** `036` is reachable through `037` (`037.down_revision == "036"`), so listing `037` transitively pulls in `036`. There are exactly **4** open heads at the moment of merge (`034`, `035`, `037`, `038`); `036` is not a head because `037` already descends from it. A merge migration is an empty/no‑op `upgrade()`/`downgrade()` whose sole purpose is to rejoin the heads — reproduce it as a no‑op body with the 4‑tuple `down_revision`. The prompt said "both parents"; the truth is **four**. Reproduce all four or `alembic upgrade head` will report multiple heads and refuse a single‑head upgrade.

---

## 3.2 CHECK CONSTRAINTS — the evolving sets (spine‑level; full per‑column detail in §6 groups)

The spine owns the one constraint that **evolves across the most migrations**: `wave_status_lifecycle_chk`. Other table‑local CHECKs (in `033`, `048`, `050`, `052`, `057`, `065`, `066`, plus the two "exactly‑one" wave‑scope CHECKs) are enumerated in the relevant §6 group; the two wave‑scope CHECKs are reproduced here because they cross the core/workflow boundary.

### `wave_status_lifecycle_chk` on `wave(status)` — FINAL value set (after `059`)

Created in `023`, then drop‑and‑recreate (stable name) in `043`, `045`, `049`, `059`. **`047` does NOT touch this constraint** (it only adds an `application.current_status` COMMENT + partial index — `047:57-70`). The constraint is always `CHECK (status IN (<values>))`.

**FINAL allowed set (12 values, order as built by `059:41-54`):**
```
'draft', 'ready', 'in_progress',
'awaiting-architecture-dispatch', 'architecture-in-flight', 'data-in-flight',
'modernization-in-flight', 'modernization-complete',
'completed', 'cancelled', 'failed', 'stuck-awaiting-recovery'
```

Evolution ledger (each step is `DROP CONSTRAINT IF EXISTS wave_status_lifecycle_chk` then `ADD CONSTRAINT … CHECK (status IN (…))`):

| Migration | Set after this migration | Source |
|-----------|--------------------------|--------|
| `023` | `draft, ready, in_progress, completed, cancelled` (5) — also flips server_default `planned`→`draft` | `023:35,39-44` |
| `043` | + `failed` (6) — also adds `wave.failed_at`, `wave.failure_reason` | `043:42-49,59-79` |
| `045` | + `awaiting-architecture-dispatch, architecture-in-flight, data-in-flight` (9) | `045:45-55,66-72` |
| `049` | + `stuck-awaiting-recovery` (10) | `049:53-64,78-84` |
| `059` | + `modernization-in-flight, modernization-complete` (12) | `059:41-54,69-75` |

> ⚠️ The constraint **name is stable** (`wave_status_lifecycle_chk`) across all five migrations (`023:34`, `043:41`, `045:44`, `049:52`, `059:40`) so diagnostics and downstream migrations keep recognizing it. Each downgrade narrows the set and will FAIL if rows hold a now‑disallowed status (the migrations deliberately do not coerce; operator must quiesce first — `045:75-79`, `049:87-94`, `059:78-84`). The one‑time legacy normalization (`planned`→`draft`, `active`→`in_progress`) is in the **separate** data migration `022:27-29` (so `023` can add the CHECK without rejecting pre‑existing rows).

### Wave‑scope "exactly‑one" CHECKs (cross core/workflow boundary)

| Constraint | Table | Predicate | Source |
|------------|-------|-----------|--------|
| `gate_application_or_wave_ck` | `gate` | `(application_id IS NOT NULL AND wave_id IS NULL) OR (application_id IS NULL AND wave_id IS NOT NULL)` | `042:63-68` |
| `agent_task_application_or_wave_ck` | `agent_task` | `(application_id IS NOT NULL AND wave_id IS NULL) OR (application_id IS NULL AND wave_id IS NOT NULL)` | `044:69-74` |

Both migrations also relax the respective `application_id` to nullable, add a `wave_id UUID NULL FK wave(id) ON DELETE CASCADE`, and index `wave_id` (`042:47-71`, `044:53-77`). Reason: `WaveRationalizationWorkflow` creates wave‑scoped G‑RR/G‑DA gates and ~11 wave‑scoped agent tasks; before these migrations the workflow stuffed `f"wave-{wave_id}"` into a UUID column and crashed on `uuid.UUID(...)` (`042:9-20`, `044:11-23`).

> ⚠️ **`application.current_status` has NO CHECK constraint.** It is free‑form `VARCHAR(50)` (`002:88`). Its canonical values (`onboarded`, `*_in_progress`, `sustainment_active`, `cancelled`, `consolidated_into_target`, …) are documented only in a `COMMENT ON COLUMN` set in `047:41-61`. A rebuild must NOT add a CHECK here — code relies on it being free‑form.

---

## 4. SEEDS & DB BOOTSTRAP

### 4.1 Migration ↔ seed separation (the rule)

Every migration docstring asserts **"DDL only — no seed data per the migration‑seeding separation rule"** (e.g. `001:8`, `002:7`, `021:19`). The **sole** exception is the data‑normalization migration `022` (it issues `UPDATE wave …`, not `INSERT` of new domain data — `022:27-29`). Seeds are loaded by a **separate** mechanism, never by Alembic.

### 4.2 Database bootstrap (`db/init/01-create-databases.sh`)

Run once by the Postgres container via `/docker-entrypoint-initdb.d/` (`db/init/01-create-databases.sh:3-5`). Creates **three** databases and grants:
```sql
CREATE DATABASE olympus;
CREATE DATABASE temporal;
CREATE DATABASE temporal_visibility;
GRANT ALL PRIVILEGES ON DATABASE olympus            TO $POSTGRES_USER;
GRANT ALL PRIVILEGES ON DATABASE temporal           TO $POSTGRES_USER;
GRANT ALL PRIVILEGES ON DATABASE temporal_visibility TO $POSTGRES_USER;
```
`temporal` / `temporal_visibility` are Temporal's own persistence DBs (out of scope for these migrations; `db/README.md:5`). Only `olympus` is migrated by Alembic.

**Two least‑privilege users** (`db/README.md:43-70`): `olympus_migration` (DDL+DML, used by Alembic) and `olympus_app` (DML‑only, used by the API/worker at runtime). `env.py` prefers `DATABASE_MIGRATION_USER`/`DATABASE_MIGRATION_PASSWORD`, falling back to `DATABASE_USER`/`DATABASE_PASSWORD` (`env.py:50-58`). `ALTER DEFAULT PRIVILEGES` ensures future migration‑created tables are reachable by the app user (`db/README.md:66-69`).

### 4.3 Alembic runner

`db/Dockerfile` builds a one‑shot runner: `python:3.14-slim`, installs `db/requirements.txt` (`alembic>=1.13,<2.0`, `psycopg2-binary>=2.9,<3.0`, `sqlalchemy>=2.0,<3.0`), copies `alembic.ini` + `alembic/`, `CMD ["alembic","upgrade","head"]`. In Docker Compose this is the `db-migrate` one‑shot service; API + worker `depends_on` its success (`db/README.md:74-85`). `env.py` builds the URL from component env vars (host/port/name/user/password), URL‑encodes the password, never logs it, and fails fast listing every missing var (`env.py:28-88`). `NullPool` for migrations (`env.py:112`).

### 4.4 `db/seeds/initial-data.sql`

A `pg_dump --data-only` snapshot captured **at alembic head `050`, 2026‑05‑20** (`db/seeds/README.md:11-13`). It is **data‑only** — schema must already exist (apply Alembic first). It loads these tables with these row counts (`db/seeds/README.md:12-13`):

| Table | Rows |
|-------|------|
| `skill` | 157 |
| `application` | 20 |
| `portfolio` | 2 |
| `wave` | 1 |
| `wave_application` | 8 |
| `chat_message` | 4 |
| `score_history` | 12 |

(File on disk is ~3.5 MB — `db/seeds/initial-data.sql`, dominated by the 157 `skill` rows + their JSONB payloads.) Applied to a fresh RDS by `scripts/csn-fargate/migrate-local-data.sh` → uploads to S3 → runs the `foundry-dev-data-migrate` ECS task which `psql -f`s the file inside the VPC (`db/seeds/README.md:15-20`). Purpose: give a freshly‑deployed RDS a working baseline so the dashboard isn't an empty portfolio (`db/seeds/README.md:3-7`). Refresh procedure (`pg_dump … --data-only -t skill -t application … | grep -v '^\(restrict\|unrestrict\) '`) in `db/seeds/README.md:24-35` (the `grep -v` strips psql‑only meta‑commands so the file stays portable).

> ⚠️ The seed was captured at head **`050`**, but the schema head is now **`066`**. Rebuild order: `alembic upgrade head` (→`066`) **then** `psql -f initial-data.sql`. The seed's `INSERT`s target columns that all existed at `050`; columns added in `051`–`066` are left at their defaults/NULL on seeded rows. This is fine — those rows are re‑projected by re‑running workflows (§5).

> **Note:** the seed is the ONLY non‑Git source of baseline rows. It is a *convenience snapshot*, not the source of truth — the source of truth for `skill` is `cross-cutting/skills/**/SKILL.md`, and for `application`/`portfolio`/`wave` it is the Git artifact repos. The seed exists purely so demos start non‑empty.

---

## 5. GIT‑AS‑SOURCE‑OF‑TRUTH + THE PROJECTION MODEL

### 5.1 The contract

- **Authoritative (source of truth): Git.** Artifacts (discovery reports, rationalization recommendations, architecture/data/modernization outputs, gate evidence, skills) are committed to artifact repos as versioned files; branch‑per‑task + PRs are the quality gates (CLAUDE.md Core Principle #4; `regen/03b-activities/git_operations.md`). The `GitService` (`olympus-api/src/services/git_service.py`, 866 lines) and the `read_artifact`/`write_artifact`/`create_pr`/`merge_pr`/`reconcile_and_merge_pr` activities own all branch/commit/PR/merge sequencing (`regen/03b-activities/git_operations.md` PREAMBLE + body).
- **Derived (disposable): PostgreSQL.** Every domain row in the §6 tables is a **projection** of an artifact (or of workflow state). The DB can be dropped and rebuilt: `alembic upgrade head` recreates schema; re‑running the assembly‑line workflows re‑emits every `persist_*` projection from the Git artifacts. Nothing in PG is lost‑forever data **except** telemetry rows (`agent_task`, `step_execution`, `viewer_event`) which are observational and best‑effort.

### 5.2 How projection works — the shared SQL‑assembly substrate

The projection machinery lives in `temporal/olympus_workflows/activities/line_transitions.py` and is documented in full in `regen/03b-activities/line_transitions-0-helpers-decorator.md`. The mechanics every `persist_*_side_effects` activity shares:

1. A per‑line `_extract_<line>(artifact_json) -> dict` reads the **artifact JSON** (the Git‑committed output of that line) and emits a **flat `projections` dict** whose keys are a subset of `_SIDE_EFFECT_COLUMNS` (`line_transitions-0-helpers-decorator.md:508,510-511`).
2. `_SIDE_EFFECT_COLUMNS` (a `tuple[str,...]`, **order‑significant**, lines 788–874 of the source) is **the authoritative whitelist of projectable `application` columns** — a key not in this tuple is silently ignored (`line_transitions-0-helpers-decorator.md:510-529`). This is the single gate for "which columns the projection layer can write."
3. `_JSONB_COLUMNS` (876–892) lists columns whose values are `json.dumps`‑encoded before binding; everything else binds the raw Python value (asyncpg encodes `datetime`/`list[UUID]`/`Decimal`/`str` natively). `_NATIVE_COLUMNS` (894–919) is documentation‑only, never read (`line_transitions-0-helpers-decorator.md:531-541`).
4. `_build_update_sql(projections) -> (sql, params)` (1111–1144) iterates `_SIDE_EFFECT_COLUMNS` **in tuple order**, emits `col = $N` for each present key (JSONB‑encoding iff in `_JSONB_COLUMNS`), **always appends `updated_at = now()`**, and produces a parameterized `UPDATE application SET … WHERE id = $where_idx`. Callers append the app UUID as the final param (`line_transitions-0-helpers-decorator.md:543-571`). The `$N` numbering is order‑sensitive — off‑by‑one breaks every projection.
5. `_merge_application_metadata` (1058–1108) merges into the `application.metadata` JSONB (added in `051`) rather than overwriting.

> Projections are **partial UPDATEs**: absent fields keep prior DB values. They are idempotent — re‑running a line re‑projects the same columns. This is what makes PG disposable.

### 5.3 The `persist_*` activity → table cross‑reference

Each maps an artifact (or sweep result) JSON → specific table rows/columns. Full behavior in the cited `regen/03b-activities/` files; line numbers are the source‑file line of the function (per those specs).

| `persist_*` activity | Primary target table(s) / columns | 03b spec file (cite) |
|----------------------|-----------------------------------|----------------------|
| `persist_decomposition_map` | `application.decomposition_map` (JSONB) | `line_transitions-0-helpers-decorator.md` (L407) |
| `persist_discovery_side_effects` | up to 14 `application` cols + `application.metadata` merge + `updated_at` | `line_transitions-1-discovery-decomp-capability.md` (L1148) |
| `persist_capability_catalog` / `persist_capability_lineage_rework_block` | `capability`, `capability_lineage`, `system`/`system_application` (grain tables from `050`) | `line_transitions-1-discovery-decomp-capability.md` |
| `persist_classification` | `application.risk_tier(_source)`, `complexity_tier(_source)`, `archetype(_source)` | `classification.md` |
| `persist_rationalization_side_effects` | `application.disposition` + rationalization projection cols (`029`) | `line_transitions-2-rationalization.md` (L2862) |
| `persist_rationalization_capabilities` / `persist_rationalization_capability_dispositions` | `rationalization_capability` (`052`), `application_disposition` (capability‑grain, `058`) | `line_transitions-2-rationalization.md` |
| `persist_architecture_side_effects` | Architecture projection cols (`030`) + `application_lineage` | `line_transitions-3-architecture-data.md` (L3138) |
| `persist_data_side_effects` | Data projection cols (`031`) + `shared_db_cluster` | `line_transitions-3-architecture-data.md` (L3493) |
| `persist_modernization_side_effects` | Modernization projection cols (`032`) + `bounded_context` | `line_transitions-4-modernization-validation.md` (L3855) |
| `persist_validation_side_effects` / `persist_validation_history` | Validation projection cols (`035`) | `line_transitions-4-modernization-validation.md` (L4244) |
| `persist_deployment_side_effects` | Deployment projection cols (`036`) | `line_transitions-6-deployment-disposition-projection.md` (L5852) |
| `persist_disposition_side_effects` | Disposition Execution projection cols (`034`) | `line_transitions-6-deployment-disposition-projection.md` (L6127); `disposition_outputs.md` |
| `persist_sustainment_sweep_side_effects` | Sustainment tables (`037`): `patching_compliance`, `incident_log`, `sla_compliance_record`, `do_not_modify_flag`, `cost_anomaly_record`, `sustainment_override_log` | `line_transitions-5-sustainment-governance.md` (L4747) |
| `persist_governance_sweep_side_effects` | Governance sweep tables (`038`): `factory_capacity_plan`, `model_benchmark_result`; + `health_check`/`drift_alert`/`pattern` (`025`) | `line_transitions-5-sustainment-governance.md` (L5362); `governance_traceability.md` |
| `persist_portfolio_score` | `application.portfolio_score` (JSONB, `024`); `score_history` (`004`) | `scoring.md` |
| `persist_wave_failure` / `persist_failure` | `wave.failed_at`, `wave.failure_reason` (`043`); wave status | `wave_operations.md` |
| gate operations (`create_gate_record`, etc.) | `gate` (+ `gate.evidence_data` `012`, `merge_failure_detail` `040`); `gate_approval` (`062`) | `gate_operations.md`, `gate_pre_review.md` |
| agent dispatch | `agent_task` (telemetry; `027`/`044`/`064`) | `agent_dispatch.md` |
| bundle activities | `delegated_bundle` + 4 child tables (`057`), `dispatching_workflow_id` (`063`) | `bundle_activities.md` |
| signal durability | `workflow_signal_inbox` (`048`); `arch_data_signal_registry` (`046`) | `wave_operations.md`, `arch_data_registry.md` |
| step/execution telemetry | `step_execution` (`033`) — best‑effort, never fails the activity | every git/code activity; `git_operations.md` PREAMBLE 2 |
| `persist_session_artifacts` | `agent_task_session_artifact` (`050`), `delegated_bundle_session_artifact` (`057`) | `agent_dispatch.md`, `bundle_activities.md` |

> The error‑classification + observability decorator `@foundry_activity` wraps **every** activity above (`line_transitions-0-helpers-decorator.md:§0`; `git_operations.md` PREAMBLE 1). It does NOT set Temporal timeouts/retries — those come from the calling workflow. Telemetry projections (`step_execution`, `agent_task`) are best‑effort and swallow DB errors so a telemetry failure never fails the business activity (`git_operations.md` PREAMBLE 2).

---

## 6. INDEX OF TABLE‑GROUP FILES

Column‑by‑column specs (name · type · nullable · default · FK + ON DELETE/UPDATE · the migration that added each column · every CHECK in full · JSONB shapes) are split into the sibling files below. The **53 created tables** map to groups as follows (every table created by a `CREATE TABLE` across the 65 migrations is routed to exactly one group file, and each is specced there at full fidelity — including `gate_approval`/`design_annotation`/`interview_session` in the workflow group and `skill_metrics`/`viewer_event` in the platform group). **Each group file is a sibling of this spine and MUST be authored to the same fidelity bar.**

> Naming convention for the sibling files (author these): `04a-core.md`, `04b-rationalization.md`, `04c-workflow.md`, `04d-sweep.md`, `04e-platform.md`. If a different file split is chosen, keep this index in sync.

### 6a. CORE (`04a-core.md`)
The portfolio/wave/application backbone + their projection columns.

| Table | Created | Notable later columns |
|-------|---------|-----------------------|
| `portfolio` | `002:47-58` | `artifact_repo_url` (`008`) |
| `wave` | `002:61-73` | `name`/`created_at`/`updated_at` (`006`), `workflow_id` (`007`), `description` (`041`), `failed_at`/`failure_reason` (`043`), `architecture_workflow_id` (`054`); `wave_status_lifecycle_chk` (§3.2) |
| `application` | `002:76-104` | git cols (`009`), `workflow_id` (`010`), edit cols (`016`), `archetype`/`archetype_source` (`021`), `portfolio_score` (`024`), Discovery/Rat/Arch/Data/Mod/Disp/Val/Deploy projection cols (`028`–`036`), `metadata` (`051`), `target_service_id` (`053`); `current_status` COMMENT+partial index (`047`) |
| `wave_application` | `002:107-115` | (composite‑PK junction) |
| `portfolio_membership` | `056` | — |
| `application_lineage` | `030` | — |
| `system`, `system_application`, `business_domain`, `system_lineage`, `business_domain_lineage` | `050` | capability/system grain |

### 6b. RATIONALIZATION (`04b-rationalization.md`)
Capability/disposition‑grain layer.

| Table | Created |
|-------|---------|
| `capability`, `capability_business_domain`, `capability_lineage` | `050` |
| `rationalization_capability` | `052` |
| `application_disposition` (capability‑grain redefinition) | `058` (built on prior disposition cols `029`) |
| `agent_task_session_artifact` | `050` |

### 6c. WORKFLOW (`04c-workflow.md`)
Gates, agent tasks, escalations, execution envelope, signals, bundles, auth.

| Table | Created | Notable later columns |
|-------|---------|-----------------------|
| `gate` | `003` | `workflow_id`/`sla_deadline`/`evidence_package_url` (`011`), `evidence_data` (`012`), `reject_reason_category` (`020`), `wave_id`+`gate_application_or_wave_ck` (`042`), `merge_failure_detail` (`040`), multi‑approval cols (`062`) |
| `agent_task` | `003` | metrics cols (`027`), `wave_id`+`agent_task_application_or_wave_ck` (`044`), provider cols (`064`) |
| `escalation` | `003` | — |
| `gate_approval` | `062` | RBAC multi‑approval |
| `step_execution` | `033` | Layer B execution envelope; table‑local CHECKs `033:158,162` |
| `workflow_signal_inbox` | `048` | CHECK `048:95` |
| `arch_data_signal_registry` | `046` | — |
| `delegated_bundle` (+ `_input_ref`, `_output_ref`, `_session_artifact`, `_validation_history`) | `057` (+ `dispatching_workflow_id` `063`) | CHECKs `057:103-125,266,300` |
| `chat_message` | `014` | — |
| `user_account` (+ password credential table) | `026` | Auth & Roles |
| `interview_session` | `066` (HEAD) | CHECKs `066:113,117` |
| `design_annotation` | `065` | CHECKs `065:80,84` |

### 6d. SWEEP (`04d-sweep.md`)
Sustainment + Governance continuous‑line projection tables.

| Table | Created |
|-------|---------|
| `health_check`, `drift_alert`, `pattern` | `025` |
| `patching_compliance`, `incident_log`, `sla_compliance_record`, `do_not_modify_flag`, `cost_anomaly_record`, `sustainment_override_log` | `037` |
| `factory_capacity_plan`, `model_benchmark_result` | `038` |

### 6e. PLATFORM / ANALYTICS (`04e-platform.md`)
Skills, scoring, traceability, audit, telemetry, model config.

| Table | Created | Notable later columns |
|-------|---------|-----------------------|
| `model_config`, `model_override`, `score_history`, `traceability_link`, `audit_log` | `004` | — |
| `skill` | `015` | structured cols (`017`), `scripts_data` JSONB (`018`) |
| `skill_metrics` | `060` | — |
| `viewer_event` | `061` | viewer‑analytics telemetry |
| `shared_db_cluster` | `031` | — |
| `bounded_context` | `032` | — |

> **Note:** `004` also created a benchmark **view** extension is added in `027` (agent‑performance benchmark view) — views are not tables; the §6e group file documents it alongside `agent_task` metrics.

---

## 7. JSONB COLUMNS — spine‑level catalog (shapes detailed in §6 groups)

Every JSONB column is a projection of a slice of an artifact. The §6 group files give the exact JSON object shape per column. The catalog of JSONB columns and the migration that added each:

| Column | Migration | Shape summary (full in §6) |
|--------|-----------|----------------------------|
| `application.decomposition_map` | `002:93` | component/dependency decomposition from Discovery |
| `application.user_context` | `002:94` | HCD user‑context object |
| `application.ux_assessment` | `002:95` | UX assessment object |
| `application.user_impact` | `002:97` | disposition user‑impact object |
| `gate.evidence_data` | `012` | gate evidence package payload |
| `gate.merge_failure_detail` | `040:19-21` | `{reason, failure_type, conflicting_files?, base_sha?, head_sha?, detected_at}` |
| `skill.scripts_data` | `018` | embedded skill scripts/config |
| `application.portfolio_score` | `024` | portfolio scoring breakdown |
| `application.metadata` | `051` | free‑form merge target (via `_merge_application_metadata`) |
| (+ JSONB cols on projection/sweep/bundle tables — `028`–`038`, `046`, `048`, `050`, `057`, `060`, `061`, `065`, `066`) | various | per §6 group files |

Encoding rule (§5.2): a JSONB column is written via `json.dumps` iff it is in `_JSONB_COLUMNS` in `line_transitions.py` (`line_transitions-0-helpers-decorator.md:531-537`); otherwise asyncpg's native codec applies. Reproduce that whitelist exactly.

---

## 8. REBUILD CHECKLIST (behavioral parity)

1. Bootstrap: run `db/init/01-create-databases.sh` → `olympus` + `temporal` + `temporal_visibility`; create `olympus_migration` (DDL+DML) and `olympus_app` (DML‑only) with the grants in `db/README.md:52-70`.
2. Recreate **65** migration files `001`–`066` with **055 absent**; reproduce every `revision`/`down_revision` exactly, including the 4‑tuple merge at `039` (§3.1).
3. Reproduce **13** enum types (12 in `001`, `archetype_enum` in `021`); reproduce the 3 `ADD VALUE` statements on `gate_status_enum` in revision order (013→019→040) with `IF NOT EXISTS`, each in its own migration (§1.3).
4. Reproduce `wave_status_lifecycle_chk` evolution to its 12‑value final set, stable name, drop‑and‑recreate each step (§3.2); keep `application.current_status` free‑form (no CHECK) with the `047` COMMENT.
5. `alembic upgrade head` → head `066`. Then `psql -f db/seeds/initial-data.sql` for a baseline (seed captured at `050`; later columns default/NULL).
6. Treat Git as authoritative; PG as disposable. Wire the `persist_*` activities (§5.3) so re‑running workflows re‑projects every domain row through `_build_update_sql` over the `_SIDE_EFFECT_COLUMNS` whitelist.

---

### Provenance note for the spine

- Enum facts: `001_create_enum_types.py:21-114`, `021_add_application_archetype.py:33-73`, `013:21`, `019:24`, `040:44-50`.
- DAG facts: `revision`/`down_revision` headers of all 65 files (verified: single head `066`; merge parents of `039` = `("034","035","037","038")`).
- CHECK facts: `023:34-44`, `043:41-96`, `045:44-85`, `049:52-99`, `059:40-89`, `047:41-75`, `042:47-80`, `044:53-88`.
- Bootstrap/seed facts: `db/init/01-create-databases.sh:8-17`, `db/Dockerfile`, `db/requirements.txt`, `db/README.md:43-105`, `db/seeds/README.md:1-35`.
- Projection facts: `regen/03b-activities/line_transitions-0-helpers-decorator.md` (§0 decorator; §7 SQL substrate, lines 508–571), `regen/03b-activities/git_operations.md` (PREAMBLE 1 + 2), and the per‑line `line_transitions-*` / `*_outputs` / `scoring` / `gate_operations` / `agent_dispatch` / `bundle_activities` specs.
