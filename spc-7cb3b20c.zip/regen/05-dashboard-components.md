# Dashboard Components — Atomic Regeneration Spec

Scope: every significant component in `dashboard/src/components/**` and `dashboard/src/shared/components/**`. Bar = behavioral + visual parity. For each component: purpose, **PROPS** (verbatim TS interface where non-trivial), internal **STATE**, **API/hooks consumed**, notable rendering logic. Path:line citations throughout. ⚠️ GOTCHA marks fragile behavior.

This file documents COMPONENTS only. Pages (`src/pages/**`), routing, hooks (`src/hooks/**`), the API client (`src/api/client.ts`), `types/api.ts`, USWDS theming/SCSS tokens, and global CSS are documented in sibling dashboard regen files. References to `var(--olympus-*)` CSS custom properties, `useTheme`, `useChartTheme`, `usePortfolioContext`, `useWebSocket`, `useChatContext`, `useArtifactContext`, `useBreadcrumbContext`, `useQueries`, `useSectionDwell`, `api/client.ts` exports, and `types/api.ts` types are assumed available from those files.

## 0. Conventions & cross-cutting facts

- **UI lib:** `@trussworks/react-uswds` (USWDS React). Common imports: `Button`, `Tag`, `Alert`, `Label`, `Textarea`, `TextInput`, `Table`, `Header`, `PrimaryNav`, `NavMenuButton`, `BreadcrumbBar`, `Breadcrumb`, `BreadcrumbLink`, `SideNav`. `Button` boolean variant props used: `outline`, `secondary`, `unstyled`. `Alert` props used: `type` (`info|warning|error|success`), `heading`, `headingLevel`, `slim`, `noIcon`.
- **Routing:** `react-router-dom` v6 — `Link`, `NavLink`, `useNavigate`, `useLocation`, `Outlet`, `useParams`. `Link`/`NavLink` `state` prop carries `{ from: { pathname, label } }` for back-nav.
- **Toasts:** `sonner` — `toast.success(msg, { description, action: { label, onClick } })`, `toast.error(msg)`. ⚠️ Convention (Tier1ApprovalPanel:22): toasts are for SUCCESS only; load/submit errors render inline via `Alert`.
- **Charts:** `recharts` (Bar/BarChart/Pie/PieChart/Cell/ResponsiveContainer/Tooltip/Legend/XAxis/YAxis/RadialBar/RadialBarChart). Colors resolve from `useChartTheme()` (NOT CSS vars — recharts uses inline SVG props).
- **Markdown:** `react-markdown` + `remark-gfm`, wrapped by `AgentMarkdown` (the single render seam). Mermaid via lazy `import("mermaid")`.
- **Node graph:** `@xyflow/react` (React Flow) for `PipelineNodeGraph`.
- **Table engine:** `@tanstack/react-table` for `DataGrid`.
- **Focus trap:** `focus-trap-react` for chat drawer + mermaid modal.
- **Styling pattern:** Two coexisting styles — (a) component-scoped CSS files (`./X.css` imported at top, BEM-ish `block__element--modifier`), and (b) heavy inline `style={{}}` objects, especially in newer drawer/panel/chip components. ⚠️ GOTCHA: many components hardcode hex fallbacks inside `var(--olympus-*, #fallback)` — both the var AND the literal must be reproduced to match.
- **Color vocabulary:** Olympus brand teal `#177480` (primary), cyan `#23D2D7` (accent), dark `#211D1E`. Chart light/dark palettes in `useChartTheme` (§6.1). USWDS status hexes appear throughout.
- **a11y baseline:** semantic landmarks, `aria-label`/`aria-labelledby`, `role="status|alert|dialog|tooltip|tablist|menu|progressbar"`, color never sole signal (text + icon reinforce). Tested against axe `heading-order`, `1.4.1 use-of-color`.

### Component inventory (count = 56 dirs + 2 shared + loose files)

Grouped below: **Shell/Layout** · **Chat** · **Markdown** · **Badges & atoms** · **Charts** · **Tables/Grids** · **Viewers (artifact render system, ~46 viewers)** · **Gate review (2 families)** · **Workflow control & steppers** · **Wave components** · **Onboarding** · **Insights/Analytics embeds** · **Capability/Lineage** · **Misc panels**.

---

## 1. Shell & Layout (`components/Layout/`)

### 1.1 `Layout` — `Layout/Layout.tsx:172`
Top-level app shell rendered as the router's layout element. Dark USWDS `Header basic` + multi-section `PrimaryNav` + context-sensitive left sidebar + breadcrumb bar + `<Outlet/>` + floating `ChatDrawer`.

- **Props:** none (route layout component).
- **State:** `mobileNavOpen: boolean` (L173), `sidebarCollapsed: boolean` (L174).
- **Hooks/Context consumed:** `useLocation` (L175); `useWebSocket()` → `{ connected }` (L176); `useTheme()` → `{ theme, toggle }` (L177); `useChatContext()` (L178); `useArtifactContext()` → `{ artifactContext, openChatSignal }` (L179); `useBreadcrumbContext()` → `{ segments }` (L180).
- **Children components:** `ThemeToggle`, `PortfolioPicker`, `ActiveProfileBadge`, `ChatDrawer`, `SidebarNav`, `CurrentUserMenu`. Plus 3 inline SVG icon fns: `CollapseIcon({collapsed})` (L31), `HomeIcon()` (L50), `BrandIcon()` (L61 — the Olympus "temple+network" logomark; exact SVG paths at L64-78, fills `#211D1E`, accent circles `#23D2D7`/`#177480`).
- **Header right group** (L230-247): `PortfolioPicker`, `ActiveProfileBadge`, connection indicator (`.connection-dot--connected|--disconnected` + "Live"/"Offline" text from `connected`), `ThemeToggle`, `CurrentUserMenu`.
- **Top nav** (L190-201): maps `NAV_SECTIONS` → `NavLink` to `section.topNavPath`; active class `usa-current` when `section.id === activeSection.id` OR router `isActive`.
- **Sidebar** (L252-267): `<nav class="olympus-sidebar [--collapsed]">` wrapping `SidebarNav` + a `.sidebar-collapse-toggle` button (toggles `sidebarCollapsed`).
- **Main** (L269-286): `<main id="main-content" class="olympus-main">` with `BreadcrumbBar.olympus-breadcrumbs` + `<Outlet/>`. Skip-nav link at L205.
- **ChatDrawer wiring** (L289-297): `key` = `${contextType}-${contextId}-${section}` (⚠️ GOTCHA: forces full remount on context change so transcript reloads cleanly); passes `artifactContext` + `openSignal={openChatSignal}`.
- **`breadcrumbsForPath(pathname, context)` — exported, L85:** Pure fn building crumb array. Always starts `[{label:"Portfolio", href:"/", icon:true}]`. Large `if/else if` chain mapping path prefixes → crumb trails (L93-165). Notable: `/applications/*` consumes `context.{waveName,appName,assemblyLine,leaf}`; `/assembly-lines/:slug` title-cases slug; `/analytics/:slug` + `/admin/:slug` have hardcoded label maps (L146-152, L156-163). Reproduce the full chain exactly.

### 1.2 `navConfig.ts` — `Layout/navConfig.ts`
Static nav model + active-section resolver. **THE source of truth for left-nav contents.**

```ts
export interface NavItem { label: string; path: string; icon?: string; }
export interface NavSection {
  id: string; label: string;
  matchPrefix: string;            // route prefix activating this section's sidebar
  extraPrefixes?: string[];       // additional activating prefixes
  topNavPath: string;             // header click target
  items: NavItem[];
}
```
- `NAV_SECTIONS: NavSection[]` (L28) — 6 sections. Reproduce verbatim (L28-164):
  - **portfolio** (`/`, top `/`): Overview `/`(grid), My Tasks `/me/tasks`(user), My Bundles `/me/bundles`(package), Wave Management `/waves`(wave), Gate Queue `/gates`(lock), Escalations `/escalations`(shield), Target Architecture `/target-architecture`(box), Capability Lineage `/capability-lineage`(search), Traceability `/traceability`(search), Compliance Posture `/compliance`(check-circle), cATO Evidence `/compliance/cato`(shield), Security Posture `/security`(shield).
  - **assembly-lines** (`/assembly-lines`): Overview + 10 lines (Discovery/search, Rationalization/filter, Architecture/box, Data/database, Modernization/cpu, Disposition Execution/play, Validation/check-circle, Deployment/upload, Sustainment/refresh, Governance/shield).
  - **skills** (`/skills`): Skill Catalog `/skills`(book), Skill Evaluation `/skills/evaluation`(trending).
  - **analytics** (`/analytics`, top `/analytics/readiness`): Readiness Scores(bar-chart), Scoring Heat Map(grid), Compound Growth(trending), Factory Velocity(zap), Cost Dashboard(dollar), Model Usage(bot).
  - **admin** (`/admin`, top `/admin/profile`): Client Profile, Profile Comparison `/admin/profile/compare`, System Status, Workflow Health, Configuration, Scoring Config, Extensibility Registry `/admin/registries`, User Management `/admin/users`, Portfolio Members, Delegation.
  - **about** (`/about`, extraPrefixes `["/getting-started"]`): Platform Overview `/about`(grid), Getting Started `/getting-started`(play).
- `resolveActiveSection(pathname)` (L170): sorts sections by `matchPrefix.length` desc, skips `"/"`, returns first whose `matchPrefix` or any `extraPrefixes` is a `startsWith` match; defaults to `NAV_SECTIONS[0]` (portfolio).

### 1.3 `SidebarNav` — `Layout/SidebarNav.tsx:12`
- **Props:** `{ collapsed: boolean }`.
- **Hooks:** `useLocation`, `usePortfolioContext()` → `{ activePortfolio }`.
- **Logic:** resolves section via `resolveActiveSection`. ⚠️ Injects a portfolio-scoped "Applications" item (`/portfolios/${activePortfolio.id}/applications`, icon box) into the portfolio section at index 1 when an active portfolio exists (L19-30). `isActive(path)` = exact for `/`, else `pathname===path || startsWith(path+"/")` (L32-42, guards sibling-prefix false positives). Two render modes: collapsed → `SideNav` of icon-only `Link`s with `title`; expanded → section-title div + `Link`s with `SidebarIcon`+text. Active class `usa-current`.

### 1.4 `SidebarIcon` — `Layout/SidebarIcon.tsx:44`
- **Props:** `{ name: string; size?: number }` (default 16).
- **Logic:** Lookup `ICONS` record (L6-37) of 28 inline SVG path strings keyed by name (grid, layers, wave, lock, search, filter, box, database, cpu, play, check-circle, upload, refresh, shield, bot, book, trending, bar-chart, zap, dollar, package, user, activity, settings). Renders 16×16 `<svg viewBox="0 0 16 16" stroke=currentColor strokeWidth=1.5>`. Fallback when unknown name: `<span.sidebar-icon>` with uppercased first letter (L47). Reproduce ICON paths verbatim — they ARE the look.

### 1.5 `CurrentUserMenu` — `Layout/CurrentUserMenu.tsx:21`
- **Props:** none.
- **State:** `user: UserProfile|null`, `loading: boolean`.
- **API:** `fetchCurrentUser()` on mount via `reload()` (L26); `logoutSession()` + `clearAuthToken()` on sign-out (L42); reads `getAuthToken()`.
- **Render:** loading → `…`. No user & no token → `<Link to="/login">Sign in</Link>`. Else `.current-user` span: name (`full_name||username||"User"`) + role summary chip `(role1, role2)` (`.current-user__roles.usa-hint`, title `Roles: ...`) + "Sign out" unstyled button. testids: `current-user`, `current-user-roles`, `sign-out`.

---

## 2. Chat (`components/Chat/`)

### 2.1 `ChatDrawer` — `Chat/ChatDrawer.tsx:43`
Floating "Ask Olympus" FAB + slide-in drawer. Mounted once in `Layout`.
```ts
interface ChatDrawerProps {
  contextType: ChatContextType;   // from api/client
  contextId: string;
  section?: string | null;        // portfolio-scoped page discriminator
  artifactContext?: string | null;
  fabLabel?: string;              // default "Ask Olympus"
  drawerTitle?: string;           // default "Olympus AI"
  suggestedQuestions?: string[];
  openSignal?: number;            // bump to open programmatically
}
```
- **State:** `open: boolean`, `messageCount: number`, `clearing: boolean`; `panelRef: Ref<AgentChatPanelHandle>`.
- **API:** `clearChatHistory(contextType, contextId, section)` on Clear (L91).
- **Logic:** `openSignal` effect (L68): when defined & `>0`, opens drawer via `queueMicrotask(()=>setOpen(true))` (⚠️ GOTCHA microtask defer dodges `react-hooks/set-state-in-effect`; `0` is a no-op so default callers unaffected). Context-change effect resets `messageCount` to 0 (L77). `handleClear` (L81): `window.confirm` with count, calls API, `panelRef.current.resetMessages()`, success/error toast. Render: FAB `Button.chat-fab` when closed; when open, `FocusTrap` (allowOutsideClick, escapeDeactivates closes) wrapping `.chat-drawer[role=dialog]` with header (title + Clear button disabled when `clearing||messageCount===0` + close `✕`) and `<AgentChatPanel ref onMessageCountChange={setMessageCount}/>`.

### 2.2 `AgentChatPanel` — `Chat/AgentChatPanel.tsx:73` (forwardRef)
Message transcript + composer. Renders agent messages as `AgentMarkdown`, shows source citations.
```ts
interface AgentChatPanelProps {
  contextType: ChatContextType;
  contextId: string;
  section?: string | null;
  artifactContext?: string | null;
  suggestedQuestions?: string[];          // default DEFAULT_SUGGESTIONS (L53)
  onMessageCountChange?: (count: number) => void;
}
export interface AgentChatPanelHandle { resetMessages: () => void; }  // imperative
interface Message { role: "reviewer"|"agent"; content: string; timestamp: Date; sources?: ChatSourceItem[]; }
```
- **State:** `messages: Message[]`, `input: string`, `loading: boolean`, `historyLoading: boolean`; refs `messagesEndRef`, `inputRef`.
- **API:** `fetchChatHistory(contextType, contextId, section)` on mount (L127, section in deps → reload on nav); `sendChat({context_type, context_id, section, message, artifact_context})` on send (L171).
- **Imperative handle:** `resetMessages()` → `setMessages([])` (L98).
- **Notable:** auto-focus input after 100ms (L114); `onMessageCountChange(messages.length)` effect (L109); Enter (no shift) sends (L200); error send appends canned agent failure msg (L187). `SourceCitation` subcomponent (L59) renders `Tag.chat-source-tag` labeled `artifact > file:line` OR `artifact > section > finding_id`. Empty state lists clickable suggested-question buttons. Loading bubble "Thinking…". Classes: `.chat-panel`, `__messages`, `__empty`, `__suggestion`, `.chat-message--reviewer|--agent`, `__header/__time/__body/__typing/__sources`.

---

## 3. Markdown (`components/Markdown/`)

### 3.1 `AgentMarkdown` — `Markdown/AgentMarkdown.tsx:104`
THE markdown render seam. Wraps `react-markdown`+`remark-gfm`.
```ts
interface AgentMarkdownProps {
  children: string;             // the markdown source
  components?: Components;       // react-markdown component overrides, merged over defaults
  className?: string;            // wrapper div class
}
```
- **Props/State:** stateless.
- **Defaults (L94):** `code`→`DefaultCode` (routes `language-mermaid` fenced blocks to `MermaidBlock`, else plain `<code>`), `pre`→`DefaultPre` (unwraps `<pre>` around a mermaid code child, else `<pre class="bg-base-lighter padding-1 radius-sm">`), `table`→`<table class="usa-table usa-table--bordered usa-table--striped width-full">`.
- ⚠️ GOTCHA (L114-134): caller `components` win EXCEPT mermaid `code` always routes to `MermaidBlock` and `pre` is always the default — caller's syntax-highlighting `code` is composed for non-mermaid langs only. `replaceEmojiShortcodes(children)` (from `emojiShortcodes.ts`) runs BEFORE render so `:white_check_mark:` → unicode (L139). Imports `./mermaid.css`.

### 3.2 `MermaidBlock` — `Markdown/MermaidBlock.tsx:80`
Renders one mermaid fence; lazy-loads `mermaid`. Click/Enter/Space opens `MermaidModal`.
- **Props:** `{ source: string; title?: string }`.
- **State:** `state: RenderState` (`idle|rendering|ready{svg}|error{message}`, L27), `modalOpen: boolean`; `uid=useId()`; refs `triggerRef`, `mountedRef`.
- **Logic:** module-level `mermaidInitialized` guard + `loadMermaid()` (L65, `securityLevel:"strict"`, `theme:"default"`, `fontFamily:'Source Sans Pro'…`). Render effect (L99) defers state writes via `queueMicrotask` (⚠️ linter dodge); tries `sanitizeMermaidSource(trimmed)` first, falls back to raw on error (⚠️ GOTCHA L135 — buggy sanitizer can't worsen a working diagram). `deriveAriaLabel(source)` (L39) extracts title/first-node/diagram-kind. States: error → `<figure.mermaid-block--error>` badge + raw `<pre>`; loading → `--loading` + sr-only source; ready → `<button.mermaid-block__trigger>` with `dangerouslySetInnerHTML={svg}` + sr-only `<figcaption>` source. `closeModal` returns focus to trigger.

### 3.3 `MermaidModal` — `Markdown/MermaidModal.tsx:49`
Full-screen pan/zoom viewer.
- **Props:** `{ svg: string; source: string; ariaLabel: string; onClose: () => void }`.
- **State:** `transform: {scale,x,y}` (INITIAL `{1,0,0}`); `dragStateRef`, `surfaceRef`.
- **Constants:** `MIN_SCALE 0.25`, `MAX_SCALE 16`, `ZOOM_STEP 0.2`, `PAN_STEP 40`.
- **Interactions:** wheel zoom-about-cursor (L111); pointer drag pan (L130); keyboard on surface — `+/=` zoom in, `-/_` zoom out, `0` reset, arrows pan, `Escape` close (L65). `FocusTrap` wrapper. Toolbar buttons (zoom −, scale %, +, Reset, Close). Surface `role=application tabIndex=0`. Content transform `translate(x,y) scale(s)`. sr-only `<pre>` source. testid `mermaid-modal-surface`.

### 3.4 Markdown helpers
- `emojiShortcodes.ts` — `replaceEmojiShortcodes(s)` substitutes `:shortcode:` → unicode (60-line map).
- `mermaidSanitize.ts` — `sanitizeMermaidSource(s)`: normalize smart quotes, quote suspicious labels, decode HTML entities.

---

## 4. Badges, chips & atoms (loose files + small dirs)

### 4.1 `StatusBadge` — `StatusBadge.tsx:55`
- **Props:** `{ status: GateStatus|string; label?: string }`.
- **Logic:** `STATUS_CLASS` record (L8-37) maps ~30 status tokens → `status-badge--*` modifier classes (gate: pending/approved/rejected/overridden→approved/escalated; app/workflow: active/onboarded/discovery_*/planned/running/completed/failed; wave: draft→pending/ready→active/in_progress/cancelled→failed; dashed wave lifecycle: architecture-dispatched/-in-flight/modernization-in-flight/-complete). `STATUS_LABEL` (L43-48) friendly-cases the 4 dashed wave statuses. Renders `<Tag class="status-badge {cls}">{label ?? STATUS_LABEL[status] ?? status}</Tag>`. Reproduce both maps verbatim.

### 4.2 `ScoreBar` — `ScoreBar.tsx:11`
- **Props:** `{ label: string; value: number|null }`.
- **Render:** `.score-bar` with label + `[role=progressbar aria-valuenow/min0/max100]` track + `__fill` width `pct%` (clamped 0-100) + value (`toFixed(0)` or `"N/A"`).

### 4.3 `TabNav` + `TabPanel` — `TabNav.tsx:19,77`
- `TabNav` props: `{ tabs: TabDef[]; activeTab: string; onTabChange: (id)=>void }`, `TabDef = {id,label}`.
- a11y: `role=tablist`; arrow/Home/End keyboard nav moves focus + selects (L22-46); active tab `tab-nav__tab--active`, `aria-selected`, `tabIndex` roving.
- `TabPanel` props: `{ id, activeTab, children }` — renders `role=tabpanel` only when `activeTab===id`.

### 4.4 `ThemeToggle` — `ThemeToggle.tsx:11`
- **Props:** `{ theme: "light"|"dark"; onToggle: () => void }`.
- **Render:** `<button.theme-toggle>` with icon `☀`(when dark)/`◑`(when light) + label "Light"/"Dark". aria-label "Switch to {x} mode".

### 4.5 `ActiveProfileBadge` — `ActiveProfileBadge.tsx:18`
- **Props:** none. **State:** `active: ActiveProfileDetail|null`, `loading`.
- **API:** `fetchActiveProfile().catch(()=>null)` on mount.
- **Render:** loading → blank busy span; null → renders nothing; else `.active-profile-badge--readonly` with "Profile" label + `active.name`, title `Active profile: {name}`. Read-only (no picker — admin op).

### 4.6 `PortfolioPicker` — `PortfolioPicker.tsx:10`
- **Props:** none. **Hooks:** `usePortfolioContext()` → `{ portfolios, activePortfolio, setActivePortfolioId, loading }`.
- **Render:** loading → blank busy span (minWidth 12rem to prevent reflow); 0 portfolios → null; 1 → static label `.portfolio-picker--single`; ≥2 → native `<select.portfolio-picker__select>` (Section 508: native select chosen deliberately) bound to `activePortfolio.id`, onChange `setActivePortfolioId`.

### 4.7 `ActorKindBadge` — `ActorKindBadge/ActorKindBadge.tsx:81`
Chip for the 3 actor modes (traceability memo §10.1).
```ts
interface ActorKindBadgeProps {
  actorKind: ActorKind;                       // from api/client: olympus_agent|human|human_with_agent
  descriptor?: { tool?: string | null } | null;  // appends " · {tool}" for human_with_agent
  size?: "sm" | "md";                         // default "md"
  labelOverride?: string;
}
```
- **`META` record (L39-79):** per-kind `{label, icon, bg, border, fg, title}`. EXACT values (USWDS palette, verified ≥4.5:1):
  - `olympus_agent`: label "Olympus agent", icon `⚬`, bg `#e1f3f8`, border `#2672de`, fg `#1a4480`.
  - `human`: label "Human", icon `●`, bg `#fff5c2`, border `#a18839`, fg `#5c4809`.
  - `human_with_agent`: label "Human + agent", icon `◆`, bg `#ecf3ec`, border `#008480`, fg `#154c21`.
- **Render:** inline-styled `<span>` (rounded 12px pill, border, bg, fg, padding `sm:1px 6px / md:2px 8px`, fontSize `sm:0.7 / md:0.78rem`, weight 600, nowrap) with icon (`aria-hidden`) + label + tail. testid `actor-kind-badge-{kind}`, `data-actor-kind`. Stateless.

### 4.8 `LineageBadge` — `LineageBadge/LineageBadge.tsx:44`
Distinguishes pristine / target / source app states on ApplicationDetail header.
```ts
export interface LineageBadgeProps {
  lineage: ApplicationLineageResponse;   // { sources: LineageEdge[]; targets: LineageEdge[] }
  "data-testid"?: string;
}
```
- **Render:** null when no sources AND no targets. Sources>0 → `Target` Tag + "Rationalized from" + `SourceChip` list. Targets>0 → `Source` Tag + "Rationalized to" + `TargetChip` list + a prominent `RationalizedToCallout` row per target (D6, full-width CTA `Link` to target app). `SourceChip`/`TargetChip` (L151,172): `Link` to `/applications/{related_app_id}` + relationship label; `TargetChip` adds external `repo` link via `toAbsoluteRepoUrl(edge.target_repo_url)`. `edgeKey(edge)` = `id:relationship:created_at`. Imports `./LineageBadge.css`. testids: `lineage-badge`, `-target`, `-source`, `-rationalized-to`.

### 4.9 `ApplicationDispositionChips` — `ApplicationDispositionChips.tsx:108`
Multi-disposition chip strip (rat-cap derived).
```ts
export interface ApplicationDispositionChipsProps {
  appId: string;
  fallbackDisposition?: Disposition | string | null;  // legacy single value
  showTargetServices?: boolean;   // append "→ S2" target service id
  className?: string;
}
```
- **State:** `state: {appId, loaded, dispositions: string[]|null, targetServices: string[]}`. ⚠️ GOTCHA (L124): resets state DURING render when `appId` prop changes (derived-state-from-prop pattern, avoids set-state-in-effect lint).
- **API:** `fetchApplicationDispositions(appId)` (L135) → `{dispositions, target_services}`; errors treated as empty.
- **Render:** loading → quiet `—`; view data → flex-wrap inline `Chip`s; no view data + fallback → single fallback chip; else `—`. `getDispositionColor(d)` (L26) maps 7 dispositions → `{bg,color}` (Retire #fee2e2/#991b1b, Retain #e5e7eb/#374151, Refactor #dbeafe/#1e40af, Rearchitect #ede9fe/#5b21b6, Replace #fef3c7/#92400e, Replatform #ccfbf1/#115e59, Consolidate #fce7f3/#9d174d, default #f3f4f6/#6b7280). Inline `Chip` subcomponent (L69) — rounded 12px pill. testids: `application-dispositions[-loading|-fallback|-empty]-{appId}`, `application-disposition-chip-{appId}-{d}`.

### 4.10 `Glossary` — `Glossary/Glossary.tsx:31`
Inline hover/focus tooltip glossing an Olympus term.
- **Props:** `{ term: string; children?: ReactNode; className?: string }`.
- **State:** `open: boolean`; `tipId=useId()`.
- **Data:** `getGlossaryEntry(term)` from `config/glossary.ts`. Unknown term → renders children/term as plain text (no affordance). Else `<button.glossary-trigger>` with `aria-describedby` (when open) + ⓘ indicator; tooltip `<span role=tooltip>` mounts only while open showing `entry.label` (strong) + `entry.definition`. Hover+focus open; Escape blurs+closes. Imports `./Glossary.css`.

### 4.11 `DemoModeIndicator` — `DemoModeIndicator/DemoModeIndicator.tsx` (35 lines)
Small banner/badge shown when demo mode active. (Read on demand — low complexity, env/flag gated.)

---

## 5. Charts (`components/charts/`)
All consume `useChartTheme()` (§6.1) for colors. All use `recharts` `ResponsiveContainer`.

### 5.1 `DispositionDonut` — `charts/DispositionDonut.tsx:70`
- **Props:** `{ data: {name:string; value:number}[] }`.
- **`DISPOSITION_COLORS` (L14):** Retire #EF4444, Retain #6B7280, Refactor #3B82F6, Rearchitect #8B5CF6, Replace #F59E0B, Replatform #14B8A6, Consolidate #EC4899, Build #00A91C, Undecided #9CA3AF. (⚠️ note: DIFFERENT palette than ApplicationDispositionChips — this is donut-slice colors.)
- **`computeDispositionData(input)` exported (L41):** rolls apps → one slice each using `display_disposition ?? effective_dispositions[0] ?? disposition ?? "Undecided"`; also accepts flat string[]; sorts desc by value.
- **Render:** `PieChart` donut innerR60/outerR90, paddingAngle 2, label `{name} {pct}%`, center total overlay (absolute). Empty → "No disposition data".

### 5.2 `HealthGauge` — `charts/HealthGauge.tsx:20`
- **Props:** `{ value: number|null; label?: string }` (default "Health Index").
- **`gaugeColor(v)`:** <40 #EF4444, <70 #FBBF24, else #22C55E.
- **Render:** semi-circle `RadialBarChart` (cx50% cy85%, 180°→0°, barSize16, cornerRadius8, background `ct.grid`). Big value + label overlay. null → "No health data".

### 5.3 `PipelineProgress` — `charts/PipelineProgress.tsx:81`
- **Props:** `{ data: PipelineEntry[] }`, `PipelineEntry = {line, complete, inProgress, queued}`.
- **`ASSEMBLY_LINE_ORDER` (L25):** the canonical 10-line order. `computePipelineData(apps)` exported (L38): ⚠️ CUMULATIVE flow — an app on line N counts complete for all upstream lines (L54), then classifies current line by status substring (complete/done → complete; progress/active/running → inProgress; else queued).
- **Render:** horizontal stacked `BarChart` (3 stacks: complete `ct.success`, inProgress `ct.primary`, queued `ct.muted`). Empty → "No pipeline data yet".

### 5.4 `ActivityTimeline` — `charts/ActivityTimeline.tsx:28`
- **Props:** `{ events: ActivityEvent[] }`.
- **`eventIcon(type)`:** gate_activity 🔒, discovery 🔍, workflow ⚡, escalation ⚠️, default 📋.
- **Render:** scrollable `<ul>` (maxHeight 320) of flex rows: icon + description + `<time>` (locale string) + optional detail. Empty → "No recent activity". All inline styles from `ct`.

### 5.5 `ModelUsageChart` — `ModelUsageChart/ModelUsageChart.tsx:108`
Per-model-tier task-count bar chart.
```ts
export interface ModelUsageChartProps {
  portfolioId?: string;     // scopes API query
  waveId?: string;          // label-only hint (API has no wave filter)
  heading?: string;         // default "Model tier usage"
  headingLevel?: "h2"|"h3"|"h4";  // default "h3"
  initialRows?: ModelUsageRow[];  // bypass fetch (tests)
}
```
- **State:** `rows: ModelUsageRow[]|null`, `loading`, `error`. **API:** `fetchModelUsage(portfolioId)` (L132) unless `initialRows` given.
- **`computeTierData(rows)` exported (L86):** sums `tasks_total` per tier (haiku/sonnet/opus/other), `TIER_ORDER=[haiku,sonnet,opus]`, filters zero. tierColors: haiku `ct.muted`, sonnet `ct.primary`, opus `ct.accent`, other `ct.warning`.
- **Render:** `.chart-card` with header + subtitle (scope text). Error alert (inline tinted). `EmptyState icon="agents"` when no data. Vertical `BarChart` (radius `[0,4,4,0]`), per-tier `Cell` colors, `{total} total tasks across {n} tiers` footer. testid `model-usage-chart`.

---

## 6. Tables / generic data
### 6.0 `DataGrid<T>` — `DataGrid.tsx:36`
TanStack-Table generic sortable/filterable/paginated USWDS table.
```ts
interface DataGridProps<T> {
  data: T[];
  columns: ColumnDef<T, any>[];   // eslint-disabled any per TanStack
  caption: string;
  filterable?: boolean;            // default false
  filterPlaceholder?: string;      // default "Filter..."
  emptyMessage?: string;           // default "No data available."
  headerRight?: ReactNode;         // element right of filter row
  pageSize?: number;               // default 20; 0/Infinity disables pagination
}
```
- **State:** `sorting: SortingState`, `globalFilter: string`. `enablePagination = pageSize>0 && isFinite`.
- **Render:** empty → `.empty-state`. Filter row (`TextInput`, id derived from caption) + `headerRight`. `usa-table usa-table--striped` with sortable `<th>` (cursor pointer, `aria-sort`, ▲/▼/⇅ glyphs). Pagination nav (`«‹ Page x of y ›»`) shown only when `totalRows>pageSize`. `flexRender` for header/cell.

### 6.1 `useChartTheme` palette (hook — referenced by all charts; documented here for parity)
`hooks/useChartTheme.ts`. `ChartTheme` = `{primary, accent, series[], grid, text, tooltipBg, tooltipText, background, success, warning, error, muted}`.
- **LIGHT:** primary `#177480`, accent `#23D2D7`, series `[#177480,#23D2D7,#00A5B5,#5B9BD5,#8B5CF6,#F59E0B,#EF4444]`, grid `#E8E8E8`, text `#464646`, tooltipBg `#fff`, tooltipText `#211D1E`, success `#00A91C`, warning `#FFBE2E`, error `#D54309`, muted `#A9AEB1`.
- **DARK:** primary `#23D2D7`, accent `#177480`, series `[#23D2D7,#00A5B5,#5B9BD5,#8B5CF6,#F59E0B,#EF4444,#177480]`, grid `#3A3334`, text `#C4C0C1`, tooltipBg `#2A2526`, tooltipText `#E8E8E8`, success `#4ADE80`, warning `#FBBF24`, error `#F87171`, muted `#6B6566`.

---

## 7. Artifact viewers (`components/viewers/` — ~46 viewers + registry)

This is a **registry-dispatched render system**: a gate-evidence/artifact `artifact_type` string resolves to a viewer component. The contract every viewer implements:
```ts
// viewers/ViewerProps.ts
export interface ViewerProps {
  data: Record<string, unknown>;
  metadata: Record<string, unknown> | null;
  schemaVersion: string;
}
```

### 7.1 `ViewerRegistry.ts` — `viewers/ViewerRegistry.ts`
- **`registry: Record<string, ComponentType<ViewerProps>>` (L51-237):** ~100 string keys → viewer components (many aliases). KEY MAPPINGS to reproduce verbatim (canonical + filename-stem aliases):
  - All `*_step` artifacts (`rationalization_step`, `architecture_step`, `data_step`, `modernization_step`, `validation_step`, `deployment_step`, `disposition_execution_step`, `sustainment_step`, `governance_step`) AND `discovery_pass` → **`DiscoveryPassViewer`** (⚠️ GOTCHA task#97: routes through DiscoveryPassViewer so `data.analysis` renders as markdown, not raw `**text**` in GenericStructuredViewer).
  - `discovery_analysis`→DiscoveryAnalysisViewer; `file_artifact`→FileArtifactViewer; `business_rules`→BusinessRulesViewer; `test_scenarios`→TestScenariosViewer; `module_map`→ModuleMapViewer; `api_specification`→ApiSpecViewer; `data_model`→DataModelViewer; `compliance_map`→ComplianceMapViewer; `test_results`→TestResultsViewer; `security_scan`→SecurityScanViewer; `accessibility_audit`→AccessibilityViewer; `quality_risk`→QualityRiskViewer; `gate_summary`→GateSummaryViewer; `gate_finding`→GateFindingViewer; `wave_plan`→WavePlanViewer; `architecture_traceability`→ArchitectureTraceabilityViewer; `integration_graph`→IntegrationGraphViewer; `portfolio_manifest`→PortfolioManifestViewer; `compliance_citations`→ComplianceCitationsViewer; `ux_overlap_matrix`→UxOverlapViewer; `business_rule_redundancy`→BusinessRuleRedundancyViewer.
  - Gate-type named viewers (canonical + dash alias): `data_domain_model`/`data_domain`→DataDomainViewer; `parity_report`/`parity_results`→ParityResultsViewer; `compliance_certification`/`compliance_cert`→ComplianceCertViewer; `safety_review_package`/`safety_assurance`/`safety_case`→SafetyAssuranceViewer; `deployment_readiness`→DeploymentReadinessViewer; `decomposition_strategy`/`-`→DecompositionStrategyViewer; `data_product_design`/`-`/`data_product`→DataProductViewer; `parallel_run_report`/`-`/`parallel_run`→ParallelRunViewer; `decommission_certificate`/`-`/`decommission`→DecommissionViewer; `disposition_execution_plan`/`-`/`disposition_execution`→DispositionExecutionViewer.
  - Process viz: `architecture_blueprint`/`-`/`architecture_c4`/`c4_diagrams`→ArchitectureC4Viewer; `data_flow_trace`/`-`/`data_flow`→DataFlowViewer; `deployment_topology`/`-`→DeploymentTopologyViewer.
  - Timeline: `gate_history`/`-`/`decision_history`/`decisions_timeline`/`gate_decision_log`→GateHistoryTimelineViewer.
  - Comparative: `rule_reconciliation_matrix`/`-`/`rule_reconciliation`/`comparative_rules`→ComparativeRulesViewer; `parity_comparison`/`comparative_parity`/`behavioral_comparison`→ComparativeParityViewer.
  - OSCAL/cATO: `oscal_evidence`/`oscal_ssp`/`oscal_sar`/`oscal_poam`/`ssp`/`sar`/`poam`/`system-security-plan`/`assessment-results`/`plan-of-action-and-milestones`→OscalEvidenceViewer.
  - Design (W9): `ui_prototype`/`-`→UiPrototypeViewer; `design_review`/`-`→DesignReviewViewer; `ux_flow_inventory`/`-`→UxFlowInventoryViewer; `architecture_diagram`/`-`→ArchitectureDiagramViewer.
- **`getViewerForType(type)` (L239):** registry lookup, `?? GenericStructuredViewer`.
- **`ArtifactViewer` (L257):** the public dispatcher. Props = `ViewerProps & { artifactType: string; gateId?: string; appId? : string }`. Resolves viewer, wraps in `useSectionDwell({artifactType, section:artifactType, gateId, appId})` dwell-analytics ref div (`.artifact-viewer-dwell`) + `ViewerErrorBoundary`. ⚠️ Use `createElement` (not JSX) to assemble. **This is the entry point** used by GateReviewCard, ArtifactsTab, etc.

### 7.2 `ViewerErrorBoundary` — `viewers/ViewerErrorBoundary.tsx:53` (class component)
```ts
export interface ViewerErrorBoundaryProps {
  children?: ReactNode;
  artifactType?: string;
  data?: unknown;            // enables "Show raw artifact data" <details> escape hatch
  onCaught?: (error: Error) => void;
}
```
- **State:** `{hasError}`. `getDerivedStateFromError`/`componentDidCatch` (console.error + onCaught). Fallback: USWDS `Alert type=error` "This artifact could not be displayed (type)" + collapsible raw-JSON `<pre maxHeight300>` (double-guarded JSON.stringify→String→"(…could not be displayed)"). ⚠️ Distinct from page-level `ErrorBoundary` — viewer-scoped, names type, offers raw escape.

### 7.3 `GenericStructuredViewer` — `viewers/GenericStructuredViewer.tsx:131` (fallback)
- **Props:** `ViewerProps` (uses `data`).
- **Logic:** renders each top-level entry. `MARKDOWN_KEYS={"analysis"}` (L26) → renders via `AgentMarkdown` (⚠️ task#97 defense-in-depth). Arrays of objects → `usa-table` bordered/fullWidth; arrays of scalars → `usa-list`; objects → property/value table; scalars → `**key:** value`. `formatValue` (L28): null→"N/A", string passthrough, num/bool→String, else pretty JSON. 508: th/td + caption sr-only.

### 7.4 Individual viewers (the ~43 specialized ones)
All implement `ViewerProps`, are **stateless or near-stateless presentational components** that read shaped `data`/`metadata` and render headline-verdict-first + supporting tables/markdown/Mermaid. They share visual idioms: USWDS `Alert`/`Table`/`Tag`, `AgentMarkdown` for narrative fields, `ScoreBar`/chips for metrics. Per the design intent (P5-S30.11), each named gate-type viewer renders the decision-critical artifact for a non-technical reviewer. They take NO props beyond `ViewerProps` (data/metadata/schemaVersion) and are invoked ONLY through `ArtifactViewer`. Full per-viewer field maps are governed by the artifact JSON schemas (see contracts/data-layer regen + each line's `artifacts.md`); for a rebuild, the load-bearing facts are: (1) the registry key→component mapping in §7.1, (2) the `ViewerProps` contract, (3) the markdown/mermaid/table idioms. Representative viewers and their distinctive UI (read source for exact field bindings if reproducing pixel-for-pixel):
  - `DiscoveryPassViewer` (261L) — renders `data.analysis` markdown + `skill_id`/`step_name`/exec-metadata header; the universal `*_step` shell.
  - `QualityRiskViewer` (537L), `UxOverlapViewer` (480L), `DeploymentTopologyViewer` (443L) — largest; multi-section tables + matrices.
  - `ArchitectureC4Viewer` (244L), `ArchitectureDiagramViewer`, `DataFlowViewer` (298L) — Mermaid/diagram-centric (route source through MermaidBlock/DOMPurify).
  - `UiPrototypeViewer` (381L) — ⚠️ clickable mockup in a **sandboxed blob-URL iframe**.
  - `OscalEvidenceViewer` (295L) — per-control status + evidence-citation tables, raw-JSON escape hatch.
  - `GateHistoryTimelineViewer` (271L) — reverse-chron, kind-filterable, expandable timeline (data.entries[]).
  - `ComparativeRulesViewer`/`ComparativeParityViewer` — before/after diff tables.
  - `FileArtifactViewer` (200L) — raw file content (markdown or code).
  - Others: AccessibilityViewer, ApiSpecViewer, ArchitectureTraceabilityViewer, BusinessRuleRedundancyViewer, BusinessRulesViewer, ComplianceCertViewer, ComplianceCitationsViewer, ComplianceMapViewer, DataDomainViewer, DataModelViewer, DataProductViewer, DecommissionViewer, DecompositionStrategyViewer, DeploymentReadinessViewer, DesignReviewViewer, DiscoveryAnalysisViewer, DispositionExecutionViewer, GateFindingViewer, GateSummaryViewer, IntegrationGraphViewer, ModuleMapViewer, ParallelRunViewer, ParityResultsViewer, PortfolioManifestViewer, SafetyAssuranceViewer, SecurityScanViewer, TestResultsViewer, TestScenariosViewer, UxFlowInventoryViewer, WavePlanViewer.

---

## 8. Gate review — two component families

There are **two distinct gate-review families**, both under the gate-review umbrella. Newer (`GateReviewCards/`) is the card-per-check model; `GateReview/` holds the supporting banners/panels/modals used on the GateReview page. Separate from both is the reusable **`GateCardList`** (gate-SUMMARY list, §8.0) used outside the review page.

### 8.0 `GateCardList` — `GateCardList/GateCardList.tsx:173` (⚠️ distinct from §8.1 `GateReviewCardList`)
Reusable card-style list for gate SUMMARIES. Used on the PortfolioOverview gate queue AND the ApplicationDetail Status tab (gate history). Semantic accessible list (replaced DataGrid-based gate lists).
```ts
export interface GateCardItem {
  id: string; gate_type: GateType; status: GateStatus;
  sla_deadline: string | null;
  app_id?: string | null; app_name?: string;       // app-scoped gates
  wave_id?: string | null; wave_name?: string;      // wave-scoped gates (G-RR, G-DA)
  requested_at?: string | null;                      // for stuck-in-preparing detector
}
export interface GateCardListProps {
  gates: GateCardItem[]; caption: string; emptyMessage: string;
  showApplicationColumn?: boolean;
  onReview: (gateId: string) => void;
  onForceAdvance?: (gateId: string) => void;          // managers only — task #89
}
export const FORCE_ADVANCE_THRESHOLD_MS = 10 * 60 * 1000;   // 10 min
```
- **State:** none (uses `useNavigate`). Imports `./GateCardList.css`.
- **Pure exports:** `isGateStuckInPreparing(gate)` (L150 — `status==="preparing" && now-requested_at > FORCE_ADVANCE_THRESHOLD_MS`).
- **Helpers:** `computeSla(deadline)` (L105 → `{tone: overdue|soon|normal|none, label "Overdue 3h"/"Due in 2d", title}`); `resolvedSla(status)` (decided gates show outcome not countdown — ⚠️ `TERMINAL_GATE_STATUSES`={approved,overridden,rejected,escalated} never read "Overdue"); `statusDotClass(status)` (`gate-card__dot--approved|rejected|escalated|pending`).
- **Render:** empty → `.gate-card-list--empty` status. Else `<ul>` of `<li.gate-card[--pending]>` (whole row clickable): status dot + body (friendly `getGateName(gate_type)` + `StatusBadge` + `Glossary` on raw gate_type + assembly line via `getGateAssemblyLine` + optional app/wave line) + aside (SLA chip `--{tone}` + optional "Advance gate" button when `canForceAdvance` + Review/View button). Pending → onReview; non-pending → navigate `/gates/{id}/review`. `getGateName`/`getGateAssemblyLine` from `data/gateMetadata`.

### 8.1 `GateReviewCardList` — `GateReviewCards/GateReviewCardList.tsx:242`
Card-per-check gate review container (W8/P5-S9). The orchestrator of the entire gate-review experience.
```ts
export interface GateReviewCardListProps {
  evidence: GateEvidencePackage;
  onSubmit: (payload: GateDecisionRequest) => void;   // parent wires to useSubmitGateDecision
  loading?: boolean;
  aiPreReview?: AIRecommendation | null;
  autoOpenAiModal?: boolean;                            // open AI modal on first landing
  openAiModalRequest?: number;                          // bump to (re)open AI modal
  gateName?: string;                                    // friendly name in confirm modals
}
```
- **State (L251-308):** `sortMode: CardSortMode` ("workflow"); `bulkApproved`; `expanded: Record<string,bool>`; `cardStates: Record<string,CardState>` (`{decision: "approve"|"reject"|null, note, aiPreReviewUsed}`); `escalateReason: EscalateReasonCategory|null`; `escalateOpen`; `approveDialogOpen`; `rejectDialogOpen`; `aiModalOpen` (lazy-init `autoOpenAiModal && aiPreReview`); `lastHandledOpenRequest` (⚠️ derived-state-from-prop to reopen modal w/o effect, L277); `rejectNoteRequired: Record<string,bool>`; `gateNote`; `capabilityLineageDecisions: CapabilityLineageRowDecision[]`.
- **Children:** `GateReviewCard` (per artifact), `RationalizationCapabilityCard` (per rat-cap when `evidence.rationalization_capabilities`), `CapabilityLineageReviewPanel` (only for G-04a/b/c with `wave_id` — ⚠️ NOT G-DA/G-RR, L309), `ApproveGateDialog`, `RejectGateDialog`, `AIRecommendationModal`, USWDS `Radio` (escalate reasons).
- **Pure exports (testable):** `ratCapCardId(rc, idx)` (L55: `rat-cap:{id|external_id|name|idx-N}`); `extractSeverity(artifact)` (L71: reads `data.severity|severity_level`, else computes from `violations[]`); `extractConfidence(artifact)` (L95: `confidence|confidence_score|analysis.confidence`, normalizes >1 → /100); `decisionToStatus`; `buildCardModels(evidence, {states})` (L123: maps artifacts→CardModel, pins FIRST summary artifact only — L130, dev-warns on extras).
- **`ESCALATE_REASONS` (L185):** 4 reasons w/ hints — `needs-senior-review`, `policy-conflict`, `safety-concern`, `out-of-scope`. Reproduce labels+hints.
- **Decision rules (from header doc):** Approve-gate enabled when every card approved OR bulk-approve used; Reject-gate enabled when ≥1 card rejected; Escalate always enabled. Submit payload: `{action, reviewer_notes, card_decisions[], sort_applied, bulk_approved, capability_lineage_decisions}` → POST `/api/v1/gates/:id/decision`.

### 8.2 `GateReviewCard` — `GateReviewCards/GateReviewCard.tsx:181`
One horizontal card per artifact/finding/check.
```ts
export interface CardModel {       // L38 — the per-card data shape
  id: string; title: string; artifact: GateEvidenceArtifact; status: CardStatus;
  severity?: "critical"|"high"|"medium"|"low"|null; confidence?: number|null;
  skillId?: string|null; model?: string|null; durationMs?: number|null;
  tokensIn?: number|null; tokensOut?: number|null; evidencePath?: string|null;
  commitSha?: string|null; isSummary?: boolean;
  actorKind?: ActorKind; localAgentDescriptor?: LocalAgentDescriptor|null;
}
export interface GateReviewCardProps {
  card: CardModel; expanded: boolean; onToggleExpanded: () => void;
  note: string; onNoteChange: (value: string) => void;
  onApprove: () => void; onReject: () => void;
  disabled?: boolean; rejectNoteRequired?: boolean;
}
```
- **State:** none beyond refs (`articleRef`, `inlineNoteRef`, `wasExpandedRef`) + 4 `useId`s.
- **Pure exports:** `SUMMARY_ARTIFACT_TYPES` set (review_summary/gate_summary/summary, L89); `isSummaryArtifact`/`isSummaryCard`; `compareCardSeverity` (critical→low + confidence tiebreak); `compareCards(a,b,sortMode)` (⚠️ summaries always lead, then workflow=stable or severity, L131); `formatDuration`/`formatTokens`/`shortSha`.
- **Render:** `<article class="gate-review-card--{status}[--expanded]">`. Header = single toggle `Button` (chevron ▾/▸ + title + show/hide hint) + status-wrap (`CardStatusBadge` + severity chip OUTSIDE button). Meta row: skill, `ActorKindBadge` (always shown for transparency — L300), agent model, duration, tokens, confidence%. Evidence row: path + short commit. Collapsed → compact action row (Expand + Approve/Reject). Expanded → `ArtifactViewer` body + `SupportingArtifactsList` + decision zone. ⚠️ F4 reject flow: clicking Reject w/o note flips `rejectNoteRequired` → expands card, shows required `Textarea` (focused, scrolled-to), disables Reject until note has content; second click commits. Effects: focus inline note when required+expanded (L214); smooth-scroll header to top on expand (L223).

### 8.3 `CardStatusBadge` — `GateReviewCards/CardStatusBadge.tsx:96`
```ts
export type CardStatus = "pending"|"preparing"|"in_review"|"approved"|"rejected"|"escalated";
export interface CardStatusBadgeProps { status: CardStatus; ariaLabel?: string; }
export const STATUS_LABEL = STATUS_LABELS;   // also exported
```
- `STATUS_LABELS` (L27): Pending/Preparing/In review/Approved/Rejected/Escalated. `StatusIcon` (L36): inline 14×14 SVG glyph per status (clock, magnifier-wrench, eye, check-circle, x-circle, triangle-bang — exact paths L46-81). Render: `<span class="gate-review-card__status--{status}" role=status>` icon + label. testid `card-status-{status}`. Colors via CSS modifier classes (USWDS semantic tokens).

### 8.4 `ReviewerNoteEditor` — `GateReviewCards/ReviewerNoteEditor.tsx:30`
- **Props:** `{ cardId: string; value: string; onChange: (v)=>void; disabled?: boolean; defaultOpen?: boolean }`.
- **State:** `open` (init `defaultOpen ?? value.trim().length>0`). Toggle button label "Add/Edit/Hide reviewer note"; expands USWDS `Label`+`Textarea` (placeholder "Add context for the agent — rides with your decision."). `aria-expanded`/`aria-controls`.

### 8.5 `SupportingArtifactsList` — `GateReviewCards/SupportingArtifactsList.tsx:19`
- **Props:** `{ artifacts: SupportingArtifact[]; parentId: string }`.
- **State:** `openIds: Record<string,bool>`; `rowRefs`. Per-row collapsible toggle (chevron) → expands `<ArtifactViewer>` (same registry). ⚠️ opening a row smooth-scrolls its header into view via `queueMicrotask` (L35).

### 8.6 `RationalizationCapabilityCard` — `GateReviewCards/RationalizationCapabilityCard.tsx` (348L)
Card variant for rat-cap (SF1 M-row) review on G-RR/G-DA. Participates in the same `cardStates` approve/reject machine via `ratCapCardId`. (Read source for exact field bindings — renders cluster name/external_id, member systems, recommended disposition, confidence.)

### 8.7 `ApproveGateDialog` / `RejectGateDialog` — `GateReviewCards/{Approve,Reject}GateDialog.tsx`
Modal dialogs for gate-level approve (captures summary note) / reject (captures reason category + note). Wired from GateReviewCardList toolbar. Reject (176L) carries reason categories. (USWDS modal pattern, focus-trapped.)

### 8.8 `GateReview/` supporting family

- **`recommendationConfig.ts`** — `getRecommendationConfig(rec)` → `{type, emoji, label, tone}`. `CONFIGS` (L21): APPROVE (success ✅), "REVIEW THOROUGHLY" (warning ⚠️), "LIKELY REJECT" (error ❌); default info. Shared by banner + modal.
- **`AIRecommendationBanner.tsx:17`** — props `{ recommendation: AIRecommendation; onViewDetails: () => void }`. USWDS `Alert type={config.type}` slim, emoji + label + `(score/100)` + `replaceEmojiShortcodes(summary)` + "View Full Pre-Review" button.
- **`AIRecommendationModal.tsx`** — full-markdown pre-review modal (AgentMarkdown body). Opened from banner/auto.
- **`AskAIButton.tsx:32`** — props `{ artifactContext?: string|null; label?: string; variant?: "panel"|"viewer"; className? }`. Uses `useArtifactContext()` → `setArtifactContext` (only if defined) + `requestOpenChat()`. Renders 💬 + label button. ⚠️ This is how non-Layout components open the global ChatDrawer with artifact context.
- **`ConfirmModal.tsx:19`** — props `{ heading; body; confirmLabel; confirmVariant?: "default"|"secondary"; cancelLabel?; onConfirm; onCancel }`. ⚠️ Reused by `AppActionsPanel` + `WorkflowActionsBar` too. Focus cancel on mount, Escape→cancel, overlay-click→cancel, `role=dialog aria-modal`.
- **`ConsequenceBanner.tsx:23`** — props `{ gateType: GateType|string; gateName? }`. Reads `getGateConsequence(gateType)` from `config/gateConsequences.ts`; null when unknown. Renders `<dl>` "If approved"/"If rejected" rows.
- **`ValidationWarningsBanner.tsx:24`** — props `{ warnings: Record<string,string[]>|null|undefined }`. State `expanded`. Null when no entries. USWDS `Alert type=warning` "Schema validation warnings (N)", expandable per-artifact error list. Non-blocking advisory.
- **`DispositionConfidenceChip.tsx:21`** — props `{ appId: string|null; gateType: string; fetcher? }`. ⚠️ Renders only for `gateType==="G-DA"`. API `fetchDispositionConfidence(appId)`. `tone(score)`: ≥75 high, ≥50 medium, else low; `toneColour`/`toneLabel` (Strong/Mixed/… evidence). `Glossary` on "Confidence".
- **`GateReviewerActions.tsx:47`** — RBAC-aware decision controls (P6-S6.5). Props `{ policy: GateReviewerRoles|null; approvalsReceived?; onApprove?; onReject?; onForceAdvance?; disabled? }`. `ROLE_LABELS` map (L32, 8 roles). Renders Approve only if `policy.can_approve`; Reject for any decider; Force-advance only if `can_force_advance`; quorum progress when `minimum_approvals>1 || oversight_role`. Explains (not hides) when caller can't approve.
- **`EvidenceSourcePanel.tsx:43`** — props `{ source: BundleEvidenceSource|null }` (`BundleEvidenceSource` shape at L23: bundle_id, claimed_by_user_id/name/email, local_agent_descriptor{tool,version,model}, transcript_hash). Null→nothing. Renders plain-English provenance sentence in an `<aside role=note>` (delegated-bundle origin).
- **`CapabilityLineageReviewPanel.tsx`** (429L) — Architecture-review row-level capability-mapping adjudication (G-04a/b/c only). Threads `CapabilityLineageRowDecision[]` onto gate payload. (Read source for row schema.)

---

## 9. Workflow control & steppers

### 9.1 `WorkflowStepper` — `WorkflowStepper/WorkflowStepper.tsx`
SVG assembly-line progress viz with curved split/merge paths for parallel tracks. Every line node is a clickable button; clicking selects a line and `LineSteps` renders that line's steps below; clicking a step opens `StepDetailDrawer`; hover shows `StepTooltip`.
```ts
export interface WorkflowStepperWaveContext { id: string; portfolio_id: string; status: WaveStatus; }
export interface WorkflowStepperTargetContext { id: string; name: string; }
interface WorkflowStepperProps {
  appId?: string | null;
  currentLine: AssemblyLineName | null;
  currentStep: string | null;
  pendingGate: GateType | null;
  workflowStatus: string | null;
  progressPct: number | null;
  onRerunLine?: (line: AssemblyLineName) => void;
  startingLine?: AssemblyLineName | null;
  wave?: WorkflowStepperWaveContext | null;          // D5 — Rationalization node links to wave page
  target?: WorkflowStepperTargetContext | null;       // D6 — Arch/Data run under target app
  selectedLine?: AssemblyLineName;                     // #249 controlled selection
  onSelectLine?: (line: AssemblyLineName) => void;
}
```
- **State:** internal `selectedLine` when uncontrolled.
- **Pure export `getLineStatus(line, currentLine, workflowStatus)` (L89):** returns `StepStatus`; lineIdx<currentIdx→completed, ==→active (or failed, or completed if `{line}_complete`), >→pending.
- **`SR_LABELS` (L115):** completed/active/pending/blocked/failed → screen-reader text. `WAVE_RATIONALIZATION_STATUSES` set (L128) — when app's wave matches, Rationalization node defers to wave page (D5).

### 9.2 `WorkflowStepper/stepRegistry.ts` (3745 lines!) + `stepData.ts` + `LineSteps.tsx` + `StepDetailDrawer.tsx` + `StepTooltip.tsx`
- **`stepData.ts` (33L):** `ASSEMBLY_LINE_ORDER`, `StepStatus` type (`completed|active|pending|blocked|failed`).
- **`stepRegistry.ts` (3745L):** ⚠️ THE static per-line step catalog — `LINE_REGISTRY` maps each assembly line → its ordered step definitions (id, label, kind, gate, description, skills, etc.) for the stepper + drawers. **This is a large static data file; treat as data, not logic.** Regenerate from the assembly-line `README.md`/`artifacts.md` contracts (it mirrors them). Reproduce structure: keyed by `AssemblyLineName`, each entry an array of step descriptors.
- **`LineSteps.tsx` (553L):** renders the selected line's step row (SVG nodes + connectors), per-step status, gate badges, click→drawer, hover→tooltip.
- **`StepDetailDrawer.tsx` (471L):** focus-trapped right drawer with full step detail (skills, inputs/outputs, agent contract). Mirrors WorkflowDetailsDrawer/Mermaid modal pattern.
- **`StepTooltip.tsx`:** hover tooltip with step summary.

### 9.3 `WorkflowControl/` (Application Detail operations)
- **`OperationsStrip.tsx:?` (215L)** — sticky control row on every App Detail tab.
  ```ts
  export interface OperationsStripProps {
    details: WorkflowDetailsResponse | null;
    onDetails: () => void; onCancel: () => void; onRetry: () => void; onRestart: () => void;
    pendingAction?: "cancel"|"retry"|"restart"|null;
    appStatus?: string | null;
  }
  ```
  `classifyStatus(d, appStatus)` (L54) → `{label, variant}` where variant ∈ idle/running/stalled/cancelled/failed/completed/**out_of_sync** (⚠️ P5-AUDIT-010: when `appStatus` claims in-flight but no `workflow_id`, shows "Out of sync (row: X)" instead of "No run"). Left: status chip + elapsed + staleness; Right: Details + (Cancel/Retry when running) + (Restart when terminal). Imports `./OperationsStrip.css`.
- **`WorkflowDetailsDrawer.tsx:37` (224L)** — props `{ open; details: WorkflowDetailsResponse|null; loading; error: unknown; onClose; onCancel?; onRetry? }`. Null when `!open`. `FocusTrap`, Escape→close, `role=dialog aria-modal`. Shows Temporal state, recent errors, Temporal UI link. `formatInstant`/`formatSeconds` helpers.
- **`NeedsAttentionBanner.tsx` (299L)** — priority-ordered "what next?" banner.
  ```ts
  export type AttentionReason = "pending_gate"|"rework_required"|"workflow_failed"
    |"hung_workflow"|"recent_failure"|"recent_errors_resolved"|"needs_discovery"|"stale_analysis"|null;
  export interface NeedsAttentionBannerProps {
    app: ApplicationDetail; status: ApplicationStatus | null; workflow: WorkflowDetailsResponse | null;
    onStartDiscovery: () => void; onRetry: () => void; onCancel: () => void; onOpenDetails: () => void;
    onViewWorkflow?: (workflowId: string) => void; onReviewGate?: (gateId: string) => void;
    onResumeAfterRework?: () => void; onViewReworkFeedback?: (gateId: string) => void; busy?: boolean;
  }
  ```
  ⚠️ Priority chain (first match wins, L4-12): pending_gate → rework_required → workflow_failed → hung_workflow → recent_failure → needs_discovery → stale_analysis. `REJECT_CATEGORY_LABELS` map (L35). `TERMINAL_FAILURE_STATUSES`/`TERMINAL_SUCCESS_STATUSES` sets (⚠️ COMPLETED runs never show a failure CTA even with recorded task errors).
- **`confirmDialogs.ts` (50L):** confirm-copy lookups for destructive ops. **`hooks/useWorkflowDetails.ts` (41L):** data hook for the drawer.

### 9.4 Shared workflow-action components (`shared/components/`)
- **`WorkflowActionsBar.tsx:66` (205L)** — shared line/wave trigger/retry/rerun controls (App Detail + Wave Detail use ONE source of truth).
  ```ts
  export interface WorkflowActionsBarProps {
    scope: WorkflowActionsScope; lineOrWave: LineOrWave;
    currentStatus: string | null | undefined;
    appId?: string; waveId?: string;
    onActionComplete?: () => void; labelled?: boolean;   // default true
    "data-testid"?: string;
  }
  ```
  State `pendingKind`, `confirmKind`. Logic: `computeVisibleActions(scope, lineOrWave, currentStatus)` (from `workflowActions.ts`); destructive→ConfirmModal; `dispatchAction(...)` → API; `reset-line` shows resume toast w/ Temporal link. Renders nothing when no actions. Button variants from `a.variant` (outline/secondary).
- **`workflowActions.ts` (324L):** pure helpers — `ACTION_DEFS` (per-kind `{label, destructive, variant}`), `computeVisibleActions`, `confirmFor`, `dispatchAction`, types `ActionKind`/`LineOrWave`/`WorkflowActionsScope`. **THE visibility matrix.** Reproduce from source.
- **`AppActionsPanel.tsx:66` (325L)** — state-aware single-line action bar for App Detail (supersedes stacked WorkflowActionsBar there).
  ```ts
  export interface AppActionsPanelProps {
    appId: string; appStatus: string | null; isTarget: boolean;   // isTarget = lineage.sources.length>0
    temporalUiUrl?: string | null;
    onActionComplete: () => void | Promise<void>;
    onOpenDetails?: () => void; "data-testid"?: string;
  }
  ```
  State `pendingKind`, `confirmKind`, `overflowOpen`. `computeAppActionLayout({appStatus, isTarget})` → `{primary, secondary, overflow[], statusSummary}`. ⚠️ Target apps don't see Discovery/Rationalization buttons (inherited from sources). Virtual kinds `view-progress` (opens Temporal URL or details drawer) / `view-outcome` (navigates `?tab=outcome`) handled inline w/o dispatch. `reset-workflow` shows resume toast. Renders summary + ≤3 controls (primary, secondary, "More ▾" overflow menu). Status summary ALWAYS renders.
- **`appActions.ts` (439L):** pure helpers — `ACTION_DEFS`, `computeAppActionLayout`, `confirmFor`, `dispatchAppAction`, types `AppActionKind`/`AppActionLayout`. **THE app-action visibility matrix.** Reproduce from source.
- **`WorkflowFailureBanner.tsx:48` (`components/WorkflowFailureBanner/`)** — categorised failure banner (P3.5-O.4).
  ```ts
  export interface WorkflowFailureBannerProps {
    detail: WorkflowHealthDetail | null | undefined;
    onRetry?: () => void; onEscalate?: () => void;   // omit → hide button
    canRetry?: boolean;   // false → Retry shown disabled
    busy?: boolean;
  }
  ```
  `categorizeFailure(detail)` (from `workflowFailureCategory.ts`) → `{category, ...}`. `CATEGORY_ICONS` (L40): timeout ⏱, agent_error ⚠, gate_exhaustion 🚫, terminated ■, unknown ❓. Null when no categorized failure. `workflowFailureCategory.ts`: exports `categorizeFailure` + `WorkflowFailureCategory` type (turns raw Temporal error → plain-language category).

---

## 10. Wave components (`components/Wave*`, `WaveSynthesis/`)

### 10.1 `WaveSynthesisCard` — `WaveSynthesis/WaveSynthesisCard.tsx:35`
W11 Wave Outcome Synthesis artifact card. Self-fetching OR pre-loaded.
- **Props:** `{ waveId?: string; synthesis?: WaveOutcomeSynthesis }`.
- **State:** `data: WaveOutcomeSynthesis|null`, `loading`, `err: WaveSynthesisError|null`. **API:** `fetchWaveOutcomeSynthesis(waveId)` unless `synthesis` passed; catches `WaveSynthesisError` (typed error class from client).
- **Visual hierarchy (L8):** title row (wave # + name + timestamp) → counts + `DispositionDonut` → 4 net-impact tiles (TCO/velocity/risk/users) → target-state narrative → consolidated capabilities map w/ before/after chips. Imports `./WaveSynthesisCard.css`.

### 10.2 `TargetStateRollupBand` — `WaveSynthesis/TargetStateRollupBand.tsx:24`
- **Props:** `{ portfolioId: string }`. **State:** `data: TargetStateRollup|null`, `loading`, `err`. **API:** `fetchPortfolioTargetStateRollup(portfolioId)`.
- **Render:** `<section.rollup-band>` summing every wave's synthesis (above Applications table on PortfolioOverview). Per-wave deep-links → `/waves/{id}`. Uses `DispositionDonut`. Empty/in-flight states. Imports `./TargetStateRollupBand.css`.

### 10.3 `WaveRoadmap` — `WaveRoadmap/WaveRoadmap.tsx` (912L)
Gantt-style SVG roadmap for a wave's apps. ⚠️ Heavy client-side computation, no new backend.
- **APIs:** `fetchApplications`, `fetchApplicationLineage`, `fetchWaveDetail`, `fetchWaveGates`. Data from `gateMetadata` (`GATE_METADATA`, `getGateAssemblyLine`, `getGateName`).
- **`LINE_COLUMNS` (L66):** 8 lines (Discovery…Deployment; Sustainment/Governance omitted — continuous). Colors apps by `risk_tier` (1 red/2 amber/3 green), dependency arrows from lineage, diamond gate markers. App bar spans wave-start → current line (or pending_gate). Imports `./WaveRoadmap.css`.

### 10.4 `WaveWorkflowProgress` — `WaveWorkflowProgress/WaveWorkflowProgress.tsx` (542L)
Progress panel for WaveRationalizationWorkflow (task #95). Mirrors per-app OperationsStrip+drawer pattern.
- **Hooks:** `useWaveGates`, `useWaveProgress` (⚠️ polls 5s while RUNNING, stops on terminal — the `refetchInterval` predicate inside the hook owns this). State `expanded` (timeline drawer).
- **`classify(progress)` (L59):** `StatusVariant` ∈ idle/running/completed/failed/cancelled/**unreachable** (`temporal_unreachable` → "Live data unavailable", L63). `TERMINAL_STATUSES` set (L50). Big status chip + "Started X / updated Y" + current-step + progress bar + USWDS error Alert (failed) + "View timeline" `FocusTrap` drawer (step_execution rows). `formatElapsed` util. Imports `./WaveWorkflowProgress.css`.

### 10.5 `WaveRecoveryBanner` — `WaveRecoveryBanner/WaveRecoveryBanner.tsx:72`
Recovery banner for failed / stuck waves (Task #88).
```ts
export interface WaveRecoveryBannerProps {
  waveId: string; waveName?: string;
  status: string;                       // renders only for "failed" | "stuck-awaiting-recovery"
  failureReason: string | null;         // null=not loaded, ""=no reason captured
  temporalUiUrl?: string | null;
  onResumed?: () => void; onRetried?: () => void; onReset?: () => void;
}
```
- **APIs:** `resumeWave` (stuck path primary), `retryWaveRationalization` (failed path primary), `resetWave`. `TERMINAL_STATUSES={"failed"}`, `RECOVERABLE_STATUSES={"stuck-awaiting-recovery"}` (L69). Two variants: recoverable → Resume + Retry-Rationalization + Temporal link; failed → Retry-Rationalization + Temporal link. Failure reason in `<pre aria-label>`. State for in-flight loading.

### 10.6 `WaveGateDecisions` — `WaveGateDecisions/WaveGateDecisions.tsx`
- **Props:** `{ waveId: string; waveName?: string }`. **Hooks:** `useWaveGates(waveId)` (`/api/v1/gates/pending?wave_id&status=all`).
- **Render:** splits gates into `PENDING_STATUSES=["pending"]` ("Pending Decisions") and `CLOSED_STATUSES=[approved,rejected,escalated,overridden]` ("Recent Decisions", newest-first). Each row `Link` to `/gates/:gateId/review` with `state.from` referrer (task #123). `StatusBadge` + `Glossary` + `getGateName`/`getGateAssemblyLine`. Imports `./WaveGateDecisions.css`.

### 10.7 `WavePerformanceReport` — `WavePerformanceReport/WavePerformanceReport.tsx`
- **Props:** `{ waveId: string; initialReport?: WavePerformanceReport }`. **State:** report/loading/error. **API:** `fetchWavePerformanceReport(waveId)`. 404→error banner not crash.
- **Render:** per-line time bar chart (recharts) + steps-by-p95 table + agent-steps LLM-vs-tool-time table + bottleneck list. `formatMs(ms)` exported (L52). `EmptyState`, `useChartTheme`.

### 10.8 `WavePlanEmbed` — `WavePlanEmbed/WavePlanEmbed.tsx`
- **Props:** `{ waveId: string; portfolioId?: string }` (⚠️ portfolioId retained but unused — standalone route tombstoned). **API:** `fetchWaveArtifact` (`wave-plan.json`). `isWavePlan(v)` type guard (L27). `summariseDispositions(apps)` exported (L39). Render: disposition pill row + per-app table (App·Disposition·Tier·Risk score). Imports `./WavePlanEmbed.css`.

### 10.9 `WaveBusinessRuleOverlap` — `WaveBusinessRuleOverlap/WaveBusinessRuleOverlap.tsx:25`
- **Props:** `{ waveId: string }`. **State:** data/loading/error. **API:** `fetchWaveArtifact(waveId, "rationalization/wave-{id}/business-rule-redundancy.json")` → renders via `BusinessRuleRedundancyViewer`. Null/parse-error guards.

### 10.10 `CapabilityClusterSummary` — `CapabilityClusterSummary/CapabilityClusterSummary.tsx` (471L)
- **Exported types:** `ConsolidationRecommendation` (merge|shared_service|data_sot|string), `ConsolidationCandidate` (`{group_name, applications[], shared_capability, recommendation, confidence?}`).
- **API:** `fetchWaveArtifact` — prefers `portfolio-redundancy-matrix.json`, falls back to `redundancy-matrix.json`. ⚠️ Projects new rat-cap clustering-plan shape onto legacy `ConsolidationCandidate` (L60+). USWDS accordion (cluster count header, expanded default), cluster cards link to RedundancyMatrix page w/ query param. Imports `./CapabilityClusterSummary.css`.

### 10.11 `MoveToWaveDialog` — `MoveToWaveDialog/MoveToWaveDialog.tsx:52`
```ts
export interface MoveToWaveDialogProps {
  open: boolean; onCancel: () => void;
  onMoved: (destWaveId: string, destWaveName: string) => void;
  portfolioId: string; applicationIds: string[];
  sourceWaveName?: string; sourceWaveId?: string | null;
}
```
- **APIs:** `assignAppsToWave`, `createWave`; telemetry `emitWaveEvent`. Built on `CreateModal` + `TargetWavePicker`. ⚠️ Filters to draft waves (cohort-lock); on 400 `SOURCE_WAVE_LOCKED`/`WAVE_NOT_DRAFT` surfaces inline error without dismissing.

### 10.12 `CancelAllChildrenButton` — `CancelAllChildrenButton/CancelAllChildrenButton.tsx:43`
```ts
export interface CancelAllChildrenButtonProps {
  waveId: string; waveName?: string; disabled?: boolean; onCancelled?: () => void;
}
```
- **State:** `showConfirm`, `loading`. **API:** `cancelAllWaveChildren(waveId)` + `useQueryClient` invalidation. `ConfirmModal` gate. Aborts in-flight Architecture/Data children; recorded gate decisions NOT rolled back.

### 10.13 `WorkflowRoutingDialog` — `WorkflowRoutingDialog/WorkflowRoutingDialog.tsx`
Phase 6 W1 routing decision (run-internally vs delegate-to-pair).
```ts
export interface WorkflowRoutingDialogProps {
  open: boolean; onCancel: () => void;
  onConfirm: (delegation?: DelegationChoice) => void;   // undefined = internal default
  workflowLabel: string;
  defaultTargetId?: string;
  defaultScopeKind?: "gate_packet" | "line_step";       // default gate_packet
  submitting?: boolean;
}
type Mode = "internal" | "delegate";
```
- **`FALLBACK_OPTIONS` (L55):** internal_fallback / redispatch / (more). Built on `CreateModal`. Two-mode radio; delegate mode reveals scope target + fallback policy fields. Returns `DelegationChoice` (from client).

### 10.14 `FanOutStatusTable` — `FanOutStatusTable/FanOutStatusTable.tsx:141`
Per-target Architecture+Data fan-out table on Wave Detail.
```ts
export interface FanOutStatusTableProps { waveId: string; pollIntervalMs?: number; }  // default 10_000
```
- **State:** `data: DispatchStatusResponse|null`, `loading`, `error`, `retrying: string|null`; `retryRepoRef`.
- **APIs:** `fetchDispatchStatus(waveId)`, `dispatchRetry(waveId, {...})`, `normaliseDispatchTargets(data)`.
- **Pure exports:** `sourceAppIdsFor(target)` (⚠️ collapses `source_app_ids[]` + scalar `source_app_id` — task#96 crash guard, L40); `sourceAppLabel(target, idx, fallbackId)` (prefers `source_app_names[idx]`, else 8-char UUID); `shouldPollFanOut(status)` (L87, `TRANSITIONAL_WAVE_STATUSES`); `rowStatusVariant(status)` (success/error/info); `formatLine(line)`.
- ⚠️ Polling pattern (L163): `setInterval` reads latest `data.status` via `setData(current=>…)` setter so it reacts to status change without teardown; stops when wave terminal. Row retry uses `window.prompt` for new repo. Per-row Temporal UI link + Retry (failed rows). Imports `./FanOutStatusTable.css`.

### 10.15 `PreDispatchPanel` — `PreDispatchPanel/PreDispatchPanel.tsx` (1511L — largest non-data component)
Wave dispatch review for Architecture+Data fan-out. ⚠️ TWO surfaces (v2 target-grain preferred, v1 source-grain legacy fallback) — detection in `loadPreview` tries v2 (`fetchDispatchTargetPreview`) first, falls back to v1 (`fetchDispatchPreview`) only on 404/empty. NOT cargo-culted together.
- **APIs:** `dispatchArchitecture` (v1), `dispatchArchitectureV2` (v2), `dispatchRetry`, `fetchDispatchPreview`, `fetchDispatchTargetPreview`, `fetchGitRepoAvailable`.
- **v2:** one row per TARGET service; edit name+repo, ADD/REMOVE target (confirm), REASSIGN source apps via "Move to..." dropdown; atomic all-or-nothing dispatch.
- **v1:** one row per SOURCE app; per-row repo edit + availability check + row-level retry.
- **`RowState`/`RepoCheckStatus`** types (L57,65). `REPO_PATTERN`/`isValidRepoFormat` exported (L86). `appIdLabel`/`shortUuid` utils. Imports `./PreDispatchPanel.css`. (Read source for full row-state machine if reproducing.)

### 10.16 `Tier1ApprovalPanel` — `Tier1ApprovalPanel/Tier1ApprovalPanel.tsx:96`
Operator surface for tier-1 stakeholder sign-offs (sends `StakeholderApprovedSignal`).
```ts
export interface Tier1ApprovalPanelProps {
  waveId: string;
  artifactRepoUrl?: string | null;      // owner/name OR https URL → classification artifact link
  artifactRepoBranch?: string | null;    // default "main"
  onApproved?: (item: Tier1PendingItem) => void;
}
interface RowState { rationale: string; submitting: boolean; error: string | null; }
```
- **State:** `response: Tier1PendingResponse|null`, `loadError`, `rows: Record<string,RowState>`, `reloadKey`.
- **APIs:** `fetchTier1Pending(waveId)` (mount + reloadKey), `submitTier1Approval(waveId, {app_id, rationale})`.
- ⚠️ Renders NOTHING when `items.length===0 && !loadError` (auto-hides). `buildClassificationLink` (L78, `REPO_SLUG_PATTERN`). Per-app row: name + Risk-Tier chip + classification artifact link + rationale `Textarea` (maxLength 2000) + Approve button. Result `status==="queued"` vs sent → different success toast. ⚠️ Load/submit errors render inline `Alert`, NOT toast. Imports `./Tier1ApprovalPanel.css`.

---

## 11. Onboarding (`ApplicationOnboardingForm/`, `OnboardingWizard/`, `OnboardingCarousel/`, `CreateModal/`)

### 11.1 `CreateModal` — `CreateModal/CreateModal.tsx:44`
Reusable create-flow modal primitive (creation in modal, editing inline — Phase 5 convention).
```ts
export interface CreateModalProps {
  open: boolean; onCancel: () => void;
  heading: string; subheading?: string; children: ReactNode;
  width?: string;          // default "36rem"
  headingId?: string;      // default "create-modal-heading"
}
```
- Null when `!open`. Escape→cancel (L56), overlay-click→cancel, focuses first focusable on mount (L67). Reuses `.confirm-modal-overlay`/`.confirm-modal` classes (looks identical to ConfirmModal). `role=dialog aria-modal`. testid `create-modal-overlay`. ⚠️ Used by MoveToWaveDialog, WorkflowRoutingDialog, and create flows.

### 11.2 `ApplicationOnboardingForm` — `ApplicationOnboardingForm/ApplicationOnboardingForm.tsx` (729L)
Reusable onboard-app form (always modal post-P5-S27).
```ts
export interface ApplicationOnboardingSuccess {
  appId: string; waveId: string | null; waveName: string | null; sourceType?: SourceType;
}
export type ApplicationOnboardingFormVariant = "modal";   // @deprecated, alias kept
export interface ApplicationOnboardingFormProps {
  portfolioId: string;
  onSuccess: (result: ApplicationOnboardingSuccess) => void;
  onCancel?: () => void;
  variant?: ApplicationOnboardingFormVariant;   // @deprecated
  // (read source for remaining optional fields)
}
```
- **APIs:** `createApplication`, `bulkOnboardApps`, `createWave`, `uploadApplicationZip`, `fetchSystems`, `fetchSystemCapabilities`. **Children:** `TargetWavePicker`. USWDS `Radio`/`Select`/`FileInput`/`Fieldset`/`TextInput`. Source-type dropdown toggles input group: git (URL+creds), zip (`FileInput` → upload), s3 (URI), confluence/sharepoint/gdrive/gcs (disabled "Coming in W13.2"), interview (Phase 6 W5 → routes to Requirements Interview).

### 11.3 `TargetWavePicker` — `ApplicationOnboardingForm/TargetWavePicker.tsx`
Three-radio target-wave picker (controlled).
```ts
export type TargetWaveChoice = "currentDraft" | "newDraft" | "existingDraft";
export type TargetWavePickerValue =
  | { choice: "currentDraft"; waveId: string; waveName: string }
  | { choice: "newDraft"; name: string }
  | { choice: "existingDraft"; waveId: string; waveName: string };
export interface TargetWavePickerProps {
  portfolioId: string; disabled?: boolean;
  onChange: (value: TargetWavePickerValue) => void;
  reloadKey?: number;     // bump after 409 to reload wave list
}
```
- **API:** `fetchWaves(portfolioId)`, filters to `draft`. `MAX_NAME_LENGTH=60`. Current-draft = newest draft (ORDER BY created_at DESC), hidden when none. New-draft auto-selected when no draft, suggested `Draft Wave {N}`. Existing-draft dropdown disabled w/ tooltip when zero drafts. `formatWave(w)` = `{name} ({app_count} apps)`.

### 11.4 `OnboardingWizard` — `OnboardingWizard/OnboardingWizard.tsx` (729L)
Guided 6-step walkthrough performing real API actions.
- **Props:** `{ onComplete?: () => void }`. **APIs:** `createPortfolio`, `createApplication`, `createWave`, `startDiscovery`. **Hooks:** `usePortfolioContext`.
- **`StepId`** = welcome|portfolio|applications|wave|discovery|done; `STEP_ORDER` (L47); `STEP_LABELS` (L58: Start/Portfolio/Applications/Wave/Discovery/Done). Each create step idempotent (Back won't re-create). Per-step error+retry. Imports `./OnboardingWizard.css`.

### 11.5 `OnboardingCarousel` — `OnboardingCarousel/OnboardingCarousel.tsx`
First-run 5-slide concept tour (modal overlay when no portfolio). 
- **`ONBOARDING_STORAGE_KEY = "olympus.onboarding.dismissed.v1"`** (localStorage "don't show again").
- **`OnboardingSlide`** = `{id, title, body: ReactNode, illustration?: ReactNode}`. `DEFAULT_SLIDES` (L32): 5 panels (welcome/assembly-lines/…). Final slide has "Load sample portfolio" CTA (caller handler → seed endpoint). Keyboard: Escape close, Arrow nav, focus-trapped. Inline `OlympusLogo` SVG. Imports `./OnboardingCarousel.css`.

---

## 12. Capability / Lineage / Traceability / Misc panels

### 12.1 `CapabilitySystemCallout` — `CapabilitySystemCallout/CapabilitySystemCallout.tsx`
```ts
interface CapabilitySystemCalloutProps {
  targetSystems: SystemRefView[];          // from api/client
  realizesCapability: CapabilityRefView | null;
  portfolioId?: string | null;
}
```
- Renders nothing when both empty. `<aside>` w/ heading; system chips → Target Architecture detail, capability chip → Capability Lineage. ⚠️ M:N callout sentence: "Capability M9 realized in this app, routed to: S2 + S6". `_systemHref`/`_capabilityHref` build `/portfolios/{id}/...` (fallback relative).

### 12.2 `TraceabilityExplorer` — `TraceabilityExplorer/TraceabilityExplorer.tsx:62`
```ts
interface TraceabilityExplorerProps {
  appId: string; artifactSuggestions?: string[]; validateGateTypes?: GateType[];
}
```
- **State:** `focus: string`, `forwardLinks`, `backwardLinks`, `loading`, `ValidateState` (idle|loading|error|result{valid,coverage,threshold}). **APIs:** `fetchForwardTrace`, `fetchBackwardTrace`, `validateGateTraceability`. `DEFAULT_GATES` (L40: G-DC…G-04c). Forward/backward chain tables; row click re-focuses; gate-threshold validate. `Glossary`, datalist quick-pick.

### 12.3 `StaleArtifactsCard` — `StaleArtifactsCard/StaleArtifactsCard.tsx:38`
```ts
export interface StaleArtifactsCardProps {
  appId?: string;          // omit → portfolio-wide
  maxItems?: number;        // default 5
  heading?: string;         // default "Stale Artifacts"
  initialData?: StaleArtifact[];
}
```
- **State:** items/error/loading/expanded. **API:** `fetchStaleArtifacts`. Stale = `current_sha !== analyzed_sha`. Top-N grouped by app, "view all" expand, rows link to app detail. `shortSha` (7 chars).

### 12.4 `PendingGatesQueue` — `PendingGatesQueue/PendingGatesQueue.tsx`
- **Props:** `{ waveId: string; waveName?: string }`. **Hook:** `useQuery` → `fetchWavePendingGates` (⚠️ polls 10s). Per-gate row: gate badge + app link + PR link + `formatOpenedAt` relative time ("opened 2h ago", full ts >24h) + "Open review" link (`state.from` referrer). Empty "No pending gates in this wave". Imports `./PendingGatesQueue.css`.

### 12.5 `NeedsMyAttention` + `SummaryBar` — `NeedsMyAttention/`
Portfolio-scoped hero card (priority-ordered triage). Distinct from app-scoped `WorkflowControl/NeedsAttentionBanner`.
```ts
export type AttentionItemKind = "pending_gate"|"stuck_workflow"|"escalation"|"failed_workflow"|"tier1_undecided";
export interface AttentionItem { kind: AttentionItemKind; id: string; title: string; detail?: string|null; href?: string; state?: unknown; }
export interface NeedsMyAttentionProps {
  pendingGates: GateSummary[]; escalatedGates?: GateSummary[];
  runningWorkflows?: WorkflowHealthSummary[]; failedWorkflows?: WorkflowHealthSummary[];
  currentUserId?: string;  // filters gates to assigned (read source for remaining props)
}
```
- ⚠️ Priority (L5): pending gates → stuck workflows → escalations → failed workflows. State persisted in localStorage `olympus.overview.attention.expanded` (⚠️ default COLLAPSED on first visit — above-fold fix P5-S24). Collapsed → `SummaryBar`, expanded → card list. Client-side derivation from existing endpoints. Imports `./NeedsMyAttention.css`.
- **`SummaryBar`** (`SummaryBar.tsx`): props `{ counts: SummaryBarCounts; expanded; onToggle; controlsId }`, `SummaryBarCounts = {pendingGateReviews, escalations, slaAtRisk}`. The whole bar is a `<button aria-expanded aria-controls>` (focus stays on bar). Counts mode vs positive-signal mode ("Nothing needs your attention right now."). `pluralize` helper.

### 12.6 `MyTasksSummaryCard` — `MyTasksSummaryCard/MyTasksSummaryCard.tsx:56`
- **Props:** none. **Hooks:** `usePortfolioContext`. **State:** `counts: Counts|null`, `hidden`. **API:** `fetchMyTasks` (`/api/v1/me/tasks`).
- `Counts = {total, claimable, olympusAgent, human, humanWithAgent}`; `summarise(tasks)` (L41) reduces by `actor_kind` + `human_user_id==null` (claimable). Uses `ActorKindBadge`. ⚠️ Quiet loading/error (stays out of way, hides if API unreachable). Deep-links `/me/tasks`.

### 12.7 `AssemblyLinePipeline` — `AssemblyLinePipeline/AssemblyLinePipeline.tsx`
Static SVG/CSS depiction of the full 10-line flow (NOT the react-flow `PipelineNodeGraph`).
```ts
export interface PipelineCounts { [lineSlug: string]: number; }
interface Props { counts?: PipelineCounts; showCounts?: boolean; onLineClick?: (slug)=>void; interactive?: boolean; }
interface LineBox { slug; label; subtitle?; color; bgColor; borderColor; }
```
- Per-line `LineBox` constants (DISCOVERY L41, RATIONALIZATION, ARCHITECTURE, DATA, … — each w/ distinct hex color/bg/border + multi-line subtitle). Layout: Discovery→Rationalization→[parallel Arch/Data/Mod + Disposition below]→Validation→Deployment + continuous Sustainment/Governance bands. Imports `./AssemblyLinePipeline.css`. ⚠️ Reproduce all LineBox color triples.

### 12.8 `ComplianceDashboard` — `ComplianceDashboard/ComplianceDashboard.tsx` (529L) + `types.ts`
Mock cATO SSP/POA&M viewer (WAI-ARIA accordion). Props = `{ evidence: CatoEvidence }` (today reads local fixture).
- **`types.ts`:** `CatoEvidence`, `ControlEntry`, `EvidenceItem`, `FamilyCount`, `PoamEntry`, `PostureStatus` (green/yellow/red), `Responsibility`, `SbomSummary`.
- `POSTURE_LABEL` (L37: green "On track"/yellow "At risk"/red "Off track"); `RESPONSIBILITY_LABEL` (L43: customer / inherited-base-c "Inherited — Tyrion" / inherited-gravitee / inherited-okta / shared). Accordion per control family (`<button aria-expanded aria-controls>`). `formatIsoDate`. Imports `./ComplianceDashboard.css`.

### 12.9 `ProfileBundleModal` — `ProfileBundleModal/ProfileBundleModal.tsx:50`
"Export Profile" YAML viewer (ATLAS SF2 demo).
- **Props:** `{ open: boolean; portfolioId: string; onClose: () => void }`. **State:** `bundle: ProfileBundleResponse|null` (+more). **API:** `fetchPortfolioProfileBundle(portfolioId)`. File tree (left) + syntax-highlighted YAML (right, `react-syntax-highlighter` Prism `oneDark`). `downloadText(filename, content)` (L35, flattens slashes → `__`). ⚠️ Per-file download only (no JSZip → no bulk ZIP).

---

## 13. Insights / Analytics embeds

### 13.1 `MaturityTrendChart` — `Insights/MaturityTrendChart.tsx:42`
Sparkline maturity summary for one scoring dimension (inline SVG, NO recharts — footprint-conscious for ~12 side-by-side).
- **Props:** `{ dimension: MaturityDimension }`.
- `DIMENSION_LABELS` (L15): code_quality→"Code Quality", test_coverage→"Test Coverage", security_posture→"Security", documentation, dependency_currency→"Dependencies", architecture_clarity→"Architecture", maintainability. `prettyLabel` fallback title-cases. `trendGlyph`: up ▲ / down ▼ / flat •. `formatPct` (×100 when ≤1). Render: 60×24 two-point SVG line (previous→latest) + delta value, color class `--up|--down|--flat`, sample count. ⚠️ NO API call — pure props.

---

## 14. Completeness index & undetermined items

**Fully documented with props+state+API (verbatim interfaces):** Layout, SidebarNav, SidebarIcon, CurrentUserMenu, navConfig, ChatDrawer, AgentChatPanel, AgentMarkdown, MermaidBlock, MermaidModal, StatusBadge, ScoreBar, TabNav/TabPanel, ThemeToggle, ActiveProfileBadge, PortfolioPicker, ActorKindBadge, LineageBadge, ApplicationDispositionChips, Glossary, DataGrid, DispositionDonut, HealthGauge, PipelineProgress, ActivityTimeline, ModelUsageChart, ViewerProps, ViewerRegistry/ArtifactViewer, ViewerErrorBoundary, GenericStructuredViewer, GateCardList, GateReviewCardList, GateReviewCard, CardStatusBadge, ReviewerNoteEditor, SupportingArtifactsList, recommendationConfig, AIRecommendationBanner, AskAIButton, ConfirmModal, ConsequenceBanner, ValidationWarningsBanner, DispositionConfidenceChip, GateReviewerActions, EvidenceSourcePanel, WorkflowStepper, OperationsStrip, WorkflowDetailsDrawer, NeedsAttentionBanner, WorkflowActionsBar, AppActionsPanel, WorkflowFailureBanner, ConsolidatedBanner, RenditionsDownloadMenu, SkillDispatchExplorer, AgentActivityByLine, PhaseRibbon, PipelineNodeGraph/LineNode/lineLayout/usePipelineCounts, LineAnatomy(+types), FanOutStatusTable, Tier1ApprovalPanel, ErrorBoundary, WaveSynthesisCard, TargetStateRollupBand, WaveRecoveryBanner, WaveGateDecisions, WavePerformanceReport, WavePlanEmbed, WaveBusinessRuleOverlap, CapabilityClusterSummary, MoveToWaveDialog, CancelAllChildrenButton, WorkflowRoutingDialog, CreateModal, ApplicationOnboardingForm, TargetWavePicker, OnboardingWizard, OnboardingCarousel, CapabilitySystemCallout, TraceabilityExplorer, StaleArtifactsCard, PendingGatesQueue, NeedsMyAttention/SummaryBar, MyTasksSummaryCard, AssemblyLinePipeline, ComplianceDashboard, ProfileBundleModal, MaturityTrendChart, EmptyState.

**Documented at registry/contract level (props = `ViewerProps` only; field-bindings governed by artifact schemas):** all ~43 specialized viewers in `components/viewers/` (DiscoveryPassViewer, DiscoveryAnalysisViewer, FileArtifactViewer, BusinessRulesViewer, TestScenariosViewer, ModuleMapViewer, ApiSpecViewer, DataModelViewer, ComplianceMapViewer, TestResultsViewer, SecurityScanViewer, AccessibilityViewer, QualityRiskViewer, GateSummaryViewer, GateFindingViewer, WavePlanViewer, ArchitectureTraceabilityViewer, IntegrationGraphViewer, PortfolioManifestViewer, ComplianceCitationsViewer, UxOverlapViewer, BusinessRuleRedundancyViewer, DataDomainViewer, ParityResultsViewer, ComplianceCertViewer, SafetyAssuranceViewer, DeploymentReadinessViewer, DecompositionStrategyViewer, DataProductViewer, ParallelRunViewer, DecommissionViewer, DispositionExecutionViewer, ArchitectureC4Viewer, DataFlowViewer, DeploymentTopologyViewer, GateHistoryTimelineViewer, ComparativeRulesViewer, ComparativeParityViewer, OscalEvidenceViewer, UiPrototypeViewer, DesignReviewViewer, UxFlowInventoryViewer, ArchitectureDiagramViewer). The registry key→component map (§7.1) is reproduced verbatim — that IS the load-bearing contract; the individual viewer internals are presentational and bounded by their artifact JSON schemas (documented in the contracts/data-layer regen + each assembly line's `artifacts.md`).

**Documented at head level (props+purpose captured; large bodies are data/layout — read source for exhaustive internal sub-component breakdown if reproducing pixel-for-pixel):** WaveRoadmap (912L), WaveWorkflowProgress (542L), PreDispatchPanel (1511L), RationalizationCapabilityCard (348L), CapabilityLineageReviewPanel (429L), AIRecommendationModal, ApproveGateDialog, RejectGateDialog, ApplicationOnboardingForm body, OnboardingWizard body, ComplianceDashboard body, the WorkflowStepper sub-files (LineSteps 553L, StepDetailDrawer 471L, StepTooltip), DemoModeIndicator.

**UNDETERMINED / requires source for byte-exact reproduction:**
1. **`WorkflowStepper/stepRegistry.ts` (3745 lines)** — the static per-line step catalog (`LINE_REGISTRY`). Too large to inline; it mirrors the assembly-line `README.md`/`artifacts.md` contracts. Regenerate as a derived data file from those contracts. Structure: keyed by `AssemblyLineName` → ordered step descriptor arrays.
2. **Exact CSS** — every `./X.css` file (BEM classes) and the global USWDS theme/token SCSS are NOT in this doc (out of scope — see dashboard theming regen). Class NAMES are captured throughout; exact rule values (spacing, colors beyond the hardcoded inline hexes, transitions) live in the CSS files.
3. **`config/glossary.ts`, `config/gateConsequences.ts`, `data/gateMetadata.ts`, `Markdown/emojiShortcodes.ts` (60-line map), `Markdown/mermaidSanitize.ts`** — referenced data/util modules; their full contents are data tables to reproduce from source (gate metadata is also derivable from the 15-gate framework spec).
4. **Pure-helper internals** in `shared/components/{appActions,workflowActions}.ts` (439L/324L) — the visibility matrices (`ACTION_DEFS`, `computeAppActionLayout`/`computeVisibleActions`, `dispatch*`, `confirmFor`) are load-bearing logic; reproduce from source. Documented as "the visibility matrix" but the per-status→action mapping tables themselves need the source.
5. **`hooks/` and `api/client.ts` and `types/api.ts`** — assumed from sibling regen files; this doc cites their exports but does not define them.

