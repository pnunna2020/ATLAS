# Phase 8 — API Spec: Traceability + Delegated Bundles + Admin Bundles

ATOMIC regeneration spec. Behavioral parity bar. Three routers:

| Router | File | Prefix | Tags | Endpoints |
|---|---|---|---|---|
| Traceability | `olympus-api/src/routers/traceability.py` | `/api/v1` | `["Traceability"]` | **7** |
| Bundles (pair-facing) | `olympus-api/src/routers/bundles.py` | `/api/v1` | `["Bundles"]` | **7** |
| Admin bundles | `olympus-api/src/routers/admin_bundles.py` | `/api/v1/admin` | `["Admin"]` | **2** |

**Router mount order** (`olympus-api/src/main.py`) — preserve exactly; affects route-resolution precedence vs. sibling routers:
- `traceability_router` → `main.py:199`
- `bundles_router` → `main.py:213` (after `portfolio_members_router:212`)
- `admin_bundles_router` → `main.py:214`

Imports for these routers in `main.py`: `admin_bundles_router` (`main.py:25`), `bundles_router` (`main.py:33`), `traceability_router` (`main.py:55`).

> ⚠️ **GOTCHA — "fires signals" is NOT implemented in this code.** The task brief and the bundles.py module docstring (`bundles.py:13-14`) and `bundle.py:12-13`, `bundle.py:860-861` all *say* submit/expire emit a Temporal signal "via the workflow integration layer in chunk D." **No Temporal client is imported or invoked anywhere in `bundles.py`, `admin_bundles.py`, or `services/bundle.py`.** `submit_bundle` only mutates DB state via `bundle_svc.submit`. There is no `get_temporal_client()` call, no `signal()` call, no `start_workflow`. To preserve parity: do NOT add signal-firing to these handlers. The signal wiring lives elsewhere (not in scope of these three files). Treat the docstrings as aspirational documentation only.

---

## Shared auth / dependency primitives

### `CurrentUser` (`olympus-api/src/middleware/auth.py:32-41`)
```
class CurrentUser:
    def __init__(self, sub: str, roles: list[RBACRole], claims: dict)
    self.sub: str
    self.roles: list[RBACRole]
    self.claims: dict
    def has_role(self, *roles: RBACRole) -> bool:
        return any(r in self.roles for r in roles)
```

### `get_current_user(request: Request) -> CurrentUser` (`auth.py:52-103`)
- If env `DEV_AUTH_BYPASS=="true"` → returns `CurrentUser(sub="local-dev", roles=list(RBACRole), claims={"sub":"local-dev","dev_bypass":True})`. (DEV_AUTH_BYPASS read at `auth.py:29`, default falsey.)
- Else extract Bearer token from `Authorization` header (`auth.py:44-49`); `None` → **401** `"Missing authorization token"`.
- Decode JWT with `_JWT_SECRET` (env `JWT_SECRET`, default `"olympus-dev-secret"`), alg `_JWT_ALGORITHM` (env `JWT_ALGORITHM`, default `"HS256"`). If env `AUTH_SKIP_VERIFICATION=="true"` (default true), decode options `{verify_signature:False, verify_exp:False, verify_aud:False}`.
- `JWTError` → **401** `"Invalid or expired token"`.
- `sub = payload.get("sub","anonymous")`; roles parsed from `payload["roles"]` (unknown role strings logged + skipped); if no valid roles → `roles=[RBACRole.VIEWER]`.

### `require_role(*required_roles)` (`auth.py:106-119`)
Returns an async dependency `_check(user=Depends(get_current_user))`: if `not user.has_role(*required_roles)` → **403** `detail=f"Requires one of: {[r.value for r in required_roles]}"`. Else returns the user.

### `RBACRole` enum (`olympus-api/src/models/common.py:47-57`)
`portfolio_admin, portfolio_manager, tech_lead, arch_lead, compliance_lead, operations_lead, safety_board, viewer, service` (9 members; values = the lowercase strings).

### `VIEWER_PLUS` (traceability.py:36-45) — used by ALL traceability endpoints
```
VIEWER_PLUS = [VIEWER, TECH_LEAD, ARCH_LEAD, COMPLIANCE_LEAD,
               OPERATIONS_LEAD, SAFETY_BOARD, PORTFOLIO_MANAGER, PORTFOLIO_ADMIN]
```
> ⚠️ **GOTCHA:** `RBACRole.SERVICE` is **excluded** from `VIEWER_PLUS`. Service tokens are rejected (403) on traceability endpoints.

### `require_application_member` (path dependency) (`dependencies.py:136-157`)
Async dep; reads `app_id: Annotated[uuid.UUID, Path(...)]`, `user=Depends(get_current_user)`, `db=Depends(get_db)`. If `user.has_role(PORTFOLIO_ADMIN)` → return user (no DB hit). Else `await verify_application_portfolio_access(db, user, app_id)` then return user.

### `verify_application_portfolio_access(db, user, application_id) -> uuid.UUID | None` (`dependencies.py:184-213`)
- `PORTFOLIO_ADMIN` → return `None` (short-circuit, no query).
- `SELECT portfolio_id FROM application WHERE id = :aid`; no row → **404** `"Application not found"`.
- `await verify_portfolio_access(db, user, portfolio_id)`; return `portfolio_id`.

### `verify_portfolio_access(db, user, portfolio_id) -> None` (`dependencies.py:105-133`)
- `PORTFOLIO_ADMIN` → return (bypass).
- `membership_svc.is_member(db, portfolio_id, user.sub)` true → return.
- Else **403** `{"code":"PORTFOLIO_NOT_MEMBER","message":"Caller is not a member of this portfolio. Ask a portfolio_admin to grant access."}`.

### `filter_portfolio_ids_by_membership(db, user, candidate=None) -> list[uuid.UUID] | None` (`dependencies.py:389-411`)
- `PORTFOLIO_ADMIN` → returns **`None`** (= "no filter").
- Else `member_ids = membership_svc.list_user_portfolio_ids(db, user.sub)`; if `candidate is None` return `member_ids`; else return intersection `[pid for pid in candidate if pid in set(member_ids)]`.

### `OlympusHTTPException` (`olympus-api/src/middleware/error_handler.py:20-32`)
```
OlympusHTTPException(status_code: int, code: str, message: str, details: dict | None = None)
  -> super().__init__(status_code=status_code, detail=message); self.code=code; self.error_details=details
```
Serialized by the app exception handler to: `{"error": {"code":..., "message":..., "details": details or {}, "request_id":...}}` (`error_handler.py:35-42`).

### `get_db` → `AsyncSession` (FastAPI dep, `src.database.get_db`). All handlers inject it.

---

# ROUTER 1 — Traceability (`olympus-api/src/routers/traceability.py`) — 7 endpoints

`router = APIRouter(prefix="/api/v1", tags=["Traceability"])` (traceability.py:47)

> ⚠️ **GOTCHA — docstring undercount.** The module docstring (traceability.py:1-9) lists only 6 routes and OMITS `GET .../traceability/cross-validate`. There are **7** `@router.get` decorators. The gate counts 7. Do not drop `cross-validate`.

> ⚠️ **GOTCHA — double auth on most routes.** Endpoints 1-6 carry BOTH a route-level `dependencies=[Depends(require_application_member)]` AND a handler param `user: CurrentUser = Depends(require_role(*VIEWER_PLUS))`. Both run. `require_application_member` enforces portfolio membership on `{app_id}`; `require_role(*VIEWER_PLUS)` enforces role. Reproduce both — order in source is route-level dep, then handler dep. Endpoint 7 (`/artifacts/stale`) has **no** route-level dep (membership enforced in-handler instead).

### Traceability response models (`olympus-api/src/models/traceability.py`)

`TraceabilityLink` (lines 23-36): `id: UUID; app_id: UUID; source_artifact: str; source_element: str|None=None; source_version: str|None=None; target_artifact: str; target_element: str|None=None; target_version: str|None=None; relationship: str; produced_by: dict|None=None; validated_at: dict|None=None`

`ForwardTraceResult` (39-46): `app_id: UUID; source_artifact: str; source_element: str|None=None; links: list[TraceabilityLink]=[]; total: int=0`

`BackwardTraceResult` (49-56): `app_id: UUID; target_artifact: str; target_element: str|None=None; links: list[TraceabilityLink]=[]; total: int=0`

`CoverageResult` (59-69): `app_id: UUID; total_artifacts: int; traced_artifacts: int; coverage_pct: float (desc "Percentage of artifacts with at least one trace link"); untraced_artifacts: list[str]=[]`

`StaleArtifact` (72-79): `app_id: UUID; artifact: str; analyzed_version: str|None=None; current_version: str|None=None; reason: str="source_changed"`

`CrossValidationIssue` (82-89): `app_id: UUID; finding_element: str; artifacts: list[str]; issue_type: str (desc "contradiction, inconsistency, or gap"); detail: str`

`GateTraceabilityResult` (92-100): `app_id: UUID; gate_type: str; coverage_pct: float; threshold_pct: float; passed: bool; detail: str`

`TraceabilityResponse` (103-109): `app_id: UUID; forward_traces: list[TraceabilityLink]=[]; backward_traces: list[TraceabilityLink]=[]; coverage: CoverageResult|None=None`

`StaleArtifactsResponse` (112-117): `stale_artifacts: list[StaleArtifact]=[]; total: int=0`

`Citation` (10-21, not a response model here but in module): `source_artifact: str; source_element: str|None=None; target_artifact: str; target_element: str|None=None; relationship: str="references"`

---

### T1. `GET /api/v1/applications/{app_id}/traceability` — `get_traceability` (traceability.py:50-81)
- **Path params:** `app_id: uuid.UUID`
- **Query params:** `source_artifact: str|None = Query(None, desc "Filter forward traces by source")`; `target_artifact: str|None = Query(None, desc "Filter backward traces by target")`
- **Auth:** route-level `Depends(require_application_member)` (line 53) + handler `user = Depends(require_role(*VIEWER_PLUS))` (line 59)
- **Response model:** `TraceabilityResponse` — **200**
- **Handler logic (reproduce all branches):**
```
forward_links = []
backward_links = []
if source_artifact:                         # truthy non-empty
    fwd = await trace_svc.forward_trace(db, app_id, source_artifact)
    forward_links = fwd.links
if target_artifact:
    bwd = await trace_svc.backward_trace(db, app_id, target_artifact)
    backward_links = bwd.links
coverage = await trace_svc.compute_coverage(db, app_id)   # ALWAYS computed
return TraceabilityResponse(app_id=app_id,
    forward_traces=forward_links, backward_traces=backward_links, coverage=coverage)
```
> ⚠️ Note `forward_trace`/`backward_trace` here are called WITHOUT the `source_element`/`target_element` arg (positional 3-arg form), unlike the dedicated forward/backward endpoints.

### T2. `GET /api/v1/applications/{app_id}/traceability/forward` — `get_forward_trace` (traceability.py:84-97)
- **Path:** `app_id: uuid.UUID`
- **Query:** `source_artifact: str = Query(..., desc "Source artifact path")` **(required)**; `source_element: str|None = Query(None, desc "Source element within artifact")`
- **Auth:** route-level `require_application_member` (87) + `require_role(*VIEWER_PLUS)` (93)
- **Response model:** `ForwardTraceResult` — **200**
- **Logic:** `return await trace_svc.forward_trace(db, app_id, source_artifact, source_element)`

### T3. `GET /api/v1/applications/{app_id}/traceability/backward` — `get_backward_trace` (traceability.py:100-113)
- **Path:** `app_id: uuid.UUID`
- **Query:** `target_artifact: str = Query(..., desc "Target artifact path")` **(required)**; `target_element: str|None = Query(None, desc "Target element within artifact")`
- **Auth:** route-level `require_application_member` (103) + `require_role(*VIEWER_PLUS)` (109)
- **Response model:** `BackwardTraceResult` — **200**
- **Logic:** `return await trace_svc.backward_trace(db, app_id, target_artifact, target_element)`

### T4. `GET /api/v1/applications/{app_id}/traceability/coverage` — `get_coverage` (traceability.py:116-127)
- **Path:** `app_id: uuid.UUID`
- **Query:** none
- **Auth:** route-level `require_application_member` (119) + `require_role(*VIEWER_PLUS)` (123)
- **Response model:** `CoverageResult` — **200**
- **Logic:** `return await trace_svc.compute_coverage(db, app_id)`

### T5. `GET /api/v1/applications/{app_id}/traceability/validate` — `validate_gate_traceability` (traceability.py:130-143)
- **Path:** `app_id: uuid.UUID`
- **Query:** `gate_type: str = Query(..., desc "Gate type (e.g., G-DC, G-04c)")` **(required)**; `risk_tier: str|None = Query(None, desc "Application risk tier (1, 2, 3)")`
- **Auth:** route-level `require_application_member` (133) + `require_role(*VIEWER_PLUS)` (139)
- **Response model:** `GateTraceabilityResult` — **200**
- **Logic:** `return await trace_svc.validate_gate_traceability(db, app_id, gate_type, risk_tier)`

### T6. `GET /api/v1/applications/{app_id}/traceability/cross-validate` — `get_cross_validation` (traceability.py:146-157)
- **Path:** `app_id: uuid.UUID`
- **Query:** none
- **Auth:** route-level `require_application_member` (149) + `require_role(*VIEWER_PLUS)` (153)
- **Response model:** `list[CrossValidationIssue]` — **200**
- **Logic:** `return await trace_svc.cross_validate(db, app_id)`

### T7. `GET /api/v1/artifacts/stale` — `list_stale_artifacts` (traceability.py:160-179)
- **Path:** none
- **Query:** `app_id: uuid.UUID|None = Query(None, desc "Filter by application ID")`
- **Auth:** handler-only `user = Depends(require_role(*VIEWER_PLUS))` (166). **NO** route-level `require_application_member`. Membership enforced inside handler.
- **Response model:** `StaleArtifactsResponse` — **200**
- **Handler logic (reproduce all branches):**
```
from src.dependencies import filter_portfolio_ids_by_membership   # local import inside handler
if app_id is not None:
    await verify_application_portfolio_access(db, user, app_id)   # 404 if app missing; 403 if not member
member_ids = await filter_portfolio_ids_by_membership(db, user)   # None for admin, else list (maybe [])
stale = await trace_svc.detect_staleness(db, app_id, portfolio_ids=member_ids)
return StaleArtifactsResponse(stale_artifacts=stale, total=len(stale))
```
> ⚠️ **GOTCHA:** For admins, `member_ids` is `None` (no filter → all portfolios). For members it's the (possibly empty) membership list. `detect_staleness` must honor `portfolio_ids=None` as "unfiltered".

---

# ROUTER 2 — Bundles, pair-facing (`olympus-api/src/routers/bundles.py`) — 7 endpoints

`router = APIRouter(prefix="/api/v1", tags=["Bundles"])` (bundles.py:57)

**Auth model for this router:** every handler injects `user: Annotated[CurrentUser, Depends(get_current_user)]` (authentication only — no role gate). Authorization is done **in-handler** via portfolio membership against the *bundle's* portfolio (not the bundle id), because the membership target isn't a path id (bundles.py:23-25 docstring). Helper below.

### Shared helper `_load_bundle_with_portfolio_check` (bundles.py:98-105)
```
async def _load_bundle_with_portfolio_check(db, user, bundle_id) -> BundleDetail:
    detail = await bundle_svc.get_bundle(db, bundle_id)        # 404 if missing
    await verify_portfolio_access(db, user, detail.portfolio_id)  # 403 if not member (admin bypass)
    return detail
```

### Bundle models referenced (`olympus-api/src/models/bundle.py`)

**Enums:**
- `BundleScopeKind` (30-39): `GATE_PACKET="gate_packet"`, `LINE_STEP="line_step"`.
- `BundleStatus` (42-61): `OFFERED="offered"`, `CLAIMED="claimed"`, `SUBMITTED="submitted"`, `ACCEPTED="accepted"`, `REJECTED="rejected"`, `EXPIRED="expired"`, `RELEASED="released"`.
- `BundleFallbackPolicy` (64-76): `INTERNAL_FALLBACK="internal_fallback"`, `ESCALATE="escalate"`, `FAIL="fail"`, `REDISPATCH="redispatch"`.
- `SessionArtifactKind` (79-85): `TRANSCRIPT="transcript"`, `PROMPT="prompt"`, `DIFF="diff"`, `SUMMARY="summary"`.

**`BundleArtifactRef` (93-109):** `artifact_kind: str (req); artifact_ref: str (req); description: str|None=None`

**`BundleOutputRefView` (181-189):** `artifact_kind: str; schema_ref: str; required: bool; description: str|None=None; submitted_artifact_ref: str|None=None; submitted_at: datetime|None=None`

**`BundleSessionArtifactView` (161-169):** `id: UUID; kind: SessionArtifactKind; artifact_ref: str; hash: str|None=None; captured_at: datetime`

**`BundleValidationHistoryView` (171-178):** `id: UUID; submitted_at: datetime; submitted_by: str; outcome: str ('accepted'|'rejected'); violations: list[dict]|None=None`

**`BundleSummary` (192-205) [response for /me/bundles]:** `id: UUID; portfolio_id: UUID; application_id: UUID|None=None; wave_id: UUID|None=None; scope_kind: BundleScopeKind; target_id: str; status: BundleStatus; claimed_by_user_id: str|None=None; claimed_at: datetime|None=None; expires_at: datetime|None=None; created_at: datetime`

**`BundleDetail` (208-230) [response for get/claim/release/validate-load/audit-precheck]:** `id: UUID; portfolio_id: UUID; application_id: UUID|None=None; wave_id: UUID|None=None; scope_kind: BundleScopeKind; target_id: str; status: BundleStatus; claimed_by_user_id: str|None=None; claimed_at: datetime|None=None; expires_at: datetime|None=None; submitted_at: datetime|None=None; accepted_at: datetime|None=None; fallback_policy: BundleFallbackPolicy; local_agent_descriptor: dict|None=None; inputs: list[BundleArtifactRef]; outputs: list[BundleOutputRefView]; session_artifacts: list[BundleSessionArtifactView]=[]; validation_history: list[BundleValidationHistoryView]=[]; created_by_user_id: str; created_at: datetime`

**`BundleClaimRequest` (238-252):** `local_agent_descriptor: dict|None = Field(default=None, ...)` — entire body optional (handler types `body: BundleClaimRequest | None`).

**`BundleReleaseRequest` (255-262):** `reason: str|None = Field(default=None, max_length=2000, ...)`.

**`BundleSessionPayload` (265-276):** `kind: SessionArtifactKind; artifact_ref: str; hash: str|None = Field(default=None, ...)`.

**`BundleSubmitRequest` (279-294) [body for /submit AND /validate]:** `outputs: dict[str,str] = Field(..., desc "Map artifact_kind → submitted artifact_ref")` **(required)**; `session: list[BundleSessionPayload]|None = None`.

**`BundleValidationViolation` (320-345):** `artifact_kind: str|None=None; field_path: str|None=None; code: str (req); message: str`.

**`BundleValidationResult` (348-352) [response for /validate]:** `valid: bool; violations: list[BundleValidationViolation]=[]`.

**`BundleAuditNarrative` (360-370) [response for /audit]:** `actor_sentence: str; session_artifacts: list[BundleSessionArtifactView]; validation_history: list[BundleValidationHistoryView]`.

---

### B1. `GET /api/v1/me/bundles` — `list_my_bundles` (bundles.py:65-90)
- **Path:** none
- **Query:** `status: BundleStatus|None = Query(None)`; `scope_kind: BundleScopeKind|None = Query(None)`; `application_id: uuid.UUID|None = Query(None)`; `wave_id: uuid.UUID|None = Query(None)`; `mine_only: bool = Query(False)`; `limit: int = Query(100, ge=1, le=500)`; `offset: int = Query(0, ge=0)`
- **Auth:** `user = Depends(get_current_user)` (authn only)
- **Response model:** `list[BundleSummary]` — **200**
- **Handler logic:**
```
portfolio_ids = await filter_portfolio_ids_by_membership(db, user)   # None=admin, else list (maybe [])
return await bundle_svc.list_bundles(db,
    portfolio_ids=portfolio_ids, user_id=user.sub, status=status, scope_kind=scope_kind,
    application_id=application_id, wave_id=wave_id, mine_only=mine_only, limit=limit, offset=offset)
```
- **Service `list_bundles` (bundle.py:242-301):**
```
if portfolio_ids is not None and not portfolio_ids: return []   # member of nothing → empty
build dynamic WHERE from non-None filters:
    portfolio_ids -> "portfolio_id = ANY(:portfolio_ids)"
    status        -> "status = :status" (status.value)
    scope_kind    -> "scope_kind = :scope_kind" (scope_kind.value)
    application_id-> "application_id = :app_id"
    wave_id       -> "wave_id = :wave_id"
    mine_only     -> if user_id is None: return []; else "claimed_by_user_id = :uid"
ORDER BY created_at DESC LIMIT :limit OFFSET :offset
map rows via _row_to_summary
```

### B2. `GET /api/v1/bundles/{bundle_id}` — `get_bundle` (bundles.py:108-114)
- **Path:** `bundle_id: uuid.UUID`
- **Auth:** `Depends(get_current_user)` + in-handler portfolio check
- **Response model:** `BundleDetail` — **200**
- **Logic:** `return await _load_bundle_with_portfolio_check(db, user, bundle_id)` (404 if missing; 403 if not member)
> ⚠️ **GOTCHA — name collision:** the *handler* is named `get_bundle` and shadows `bundle_svc.get_bundle`; the handler calls the service via `bundle_svc.get_bundle` (through the helper), not itself. Keep the local/service distinction.

### B3. `GET /api/v1/bundles/{bundle_id}/audit` — `get_bundle_audit` (bundles.py:117-125)
- **Path:** `bundle_id: uuid.UUID`
- **Auth:** `Depends(get_current_user)` + in-handler portfolio check
- **Response model:** `BundleAuditNarrative` — **200**
- **Logic:**
```
await _load_bundle_with_portfolio_check(db, user, bundle_id)   # membership pre-check
return await bundle_svc.get_audit_narrative(db, bundle_id)
```
- **`get_audit_narrative` (bundle.py:910-918):** loads `detail = get_bundle`, returns `BundleAuditNarrative(actor_sentence=_format_actor_sentence(detail), session_artifacts=detail.session_artifacts, validation_history=detail.validation_history)`.
- **`_format_actor_sentence` (bundle.py:885-907):**
```
if detail.claimed_by_user_id is None: return "Bundle has not been claimed."
desc = detail.local_agent_descriptor or {}
tool, version, model = desc.get("tool"), desc.get("version"), desc.get("model")
parts = [f"Claimed by {claimed_by_user_id}"]
if tool:
    suffix = f" using {tool}"
    if version: suffix += f" {version}"
    if model:   suffix += f" on {model}"
    parts.append(suffix)
transcripts = [s for s in session_artifacts if s.kind is TRANSCRIPT and s.hash]
if transcripts: parts.append(f". Transcript hash {transcripts[0].hash}")
return "".join(parts) + "."
```

### B4. `POST /api/v1/bundles/{bundle_id}/claim` — `claim_bundle` (bundles.py:133-150)
- **Path:** `bundle_id: uuid.UUID`
- **Body:** `body: BundleClaimRequest | None` (optional)
- **Auth:** `Depends(get_current_user)` + in-handler portfolio check
- **Response model:** `BundleDetail` — **200** (idempotent same-user; **409** collision/terminal)
- **Handler logic:**
```
await _load_bundle_with_portfolio_check(db, user, bundle_id)   # check membership BEFORE FOR UPDATE
descriptor = body.local_agent_descriptor if body else None
return await bundle_svc.claim(db, bundle_id=bundle_id, user_id=user.sub, local_agent_descriptor=descriptor)
```
- **Service `claim` (bundle.py:404-500) — reproduce every branch:**
```
row = SELECT status, claimed_by_user_id, local_agent_descriptor
      FROM delegated_bundle WHERE id=:bid FOR UPDATE        # row lock
if row is None: 404 {"code":"BUNDLE_NOT_FOUND","message":f"Bundle {bundle_id} not found."}
if row.status in ("accepted","rejected","expired","released"):
    409 {"code":"BUNDLE_TERMINAL","message":f"Bundle is in terminal state {status!r} and cannot be claimed."}
if row.status in ("claimed","submitted"):
    if row.claimed_by_user_id == user_id: return await get_bundle(db, bundle_id)   # idempotent
    409 {"code":"BUNDLE_ALREADY_CLAIMED","message":f"Bundle is already claimed by {claimed_by_user_id!r}."}
# else status == "offered":
descriptor = row.local_agent_descriptor or {}; if str -> json.loads
expires_in_hours = descriptor.get("_expires_in_hours") or (24*7)   # 7d default
merged = {k:v for k,v in descriptor.items() if not k.startswith("_")}   # drop internal keys
if local_agent_descriptor: merged.update(local_agent_descriptor)
now = datetime.now(utc); expires_at = now + timedelta(hours=int(expires_in_hours))
UPDATE delegated_bundle SET status='claimed', claimed_by_user_id=:uid, claimed_at=:now,
    expires_at=:expires_at, local_agent_descriptor=CAST(:desc AS JSONB), updated_at=:now WHERE id=:bid
    # :desc = json.dumps(merged) if merged else None
commit; return await get_bundle(db, bundle_id)
```
> ⚠️ **GOTCHA:** `expires_at` is computed at **claim** time, not dispatch. The dispatch-time TTL is stashed in `local_agent_descriptor._expires_in_hours` (an internal key starting with `_`) and merged out on claim. `or (24*7)` means a stashed value of `0` falls back to 7 days.

### B5. `POST /api/v1/bundles/{bundle_id}/release` — `release_bundle` (bundles.py:153-168)
- **Path:** `bundle_id: uuid.UUID`
- **Body:** `body: BundleReleaseRequest | None` (optional)
- **Auth:** `Depends(get_current_user)` + in-handler portfolio check
- **Response model:** `BundleDetail` — **200** (**403** non-owner, **409** terminal)
- **Handler logic:**
```
await _load_bundle_with_portfolio_check(db, user, bundle_id)
return await bundle_svc.release(db, bundle_id=bundle_id, user_id=user.sub,
    is_admin=user.has_role(RBACRole.PORTFOLIO_ADMIN), reason=(body.reason if body else None))
```
- **Service `release` (bundle.py:508-582) — reproduce every branch:**
```
row = SELECT status, claimed_by_user_id FROM delegated_bundle WHERE id=:bid FOR UPDATE
if row is None: 404 detail="Bundle not found"   # NOTE: plain-string detail, not coded dict
if row.status in ("accepted","rejected","expired","released"):
    409 {"code":"BUNDLE_TERMINAL","message":f"Bundle is already in terminal state {status!r}."}
if not is_admin and row.claimed_by_user_id != user_id:
    403 {"code":"BUNDLE_NOT_OWNER","message":"Only the claiming user or a portfolio_admin may release a claimed bundle."}
now = datetime.now(utc)
UPDATE delegated_bundle SET status='released', updated_at=:now WHERE id=:bid
if reason:
    INSERT INTO delegated_bundle_session_artifact (bundle_id, kind, artifact_ref)
        VALUES (:bid, 'summary', :ref)   # :ref = f"release_reason://{reason}"
commit; return await get_bundle(db, bundle_id)
```
> ⚠️ **GOTCHA:** release reason is NOT written to the validation ledger (outcome is constrained to accepted/rejected). It is captured as a `summary`-kind session_artifact with ref `release_reason://<reason>` (bundle.py:564-580).

### B6. `POST /api/v1/bundles/{bundle_id}/validate` — `validate_bundle` (bundles.py:171-184)
- **Path:** `bundle_id: uuid.UUID`
- **Body:** `body: BundleSubmitRequest` **(required)** — reuses submit body
- **Auth:** `Depends(get_current_user)` + in-handler portfolio check
- **Response model:** `BundleValidationResult` — **200** (dry-run, no state change)
- **Handler logic:**
```
await _load_bundle_with_portfolio_check(db, user, bundle_id)
return await bundle_svc.validate_payload(db, bundle_id=bundle_id, payload=body)
```
- **Service `validate_payload` (bundle.py:687-702):**
```
output_specs = SELECT artifact_kind, schema_ref, required FROM delegated_bundle_output_ref WHERE bundle_id=:bid
if not output_specs: await get_bundle(db, bundle_id)   # raises 404 if bundle missing
violations = _validate_against_schemas(payload, output_specs)
return BundleValidationResult(valid=not violations, violations=violations)
```

### B7. `POST /api/v1/bundles/{bundle_id}/submit` — `submit_bundle` (bundles.py:187-227)
- **Path:** `bundle_id: uuid.UUID`
- **Body:** `body: BundleSubmitRequest` **(required)**
- **Injected:** `response: Response` (used to set 200 on success path)
- **Auth:** `Depends(get_current_user)` + in-handler portfolio check
- **Response model:** **none declared** → returns `dict`. Default success status **200** (set explicitly via `response.status_code = 200`). Failure → **422** raised.
- **Handler logic (reproduce all branches):**
```
await _load_bundle_with_portfolio_check(db, user, bundle_id)
detail, result = await bundle_svc.submit(db, bundle_id=bundle_id, user_id=user.sub,
    is_admin=user.has_role(RBACRole.PORTFOLIO_ADMIN), payload=body)
if not result.valid:
    raise OlympusHTTPException(status_code=422, code="BUNDLE_VALIDATION_FAILED",
        message="Submitted outputs failed validation; bundle remains claimed. See violations for field-level detail.",
        details={"violations": [v.model_dump() for v in result.violations],
                 "bundle": detail.model_dump(mode="json")})
response.status_code = 200
return {"bundle": detail.model_dump(mode="json"), "validation": result.model_dump()}
```
> ⚠️ **GOTCHA — no Temporal signal here.** Docstring (bundles.py:13-14) claims "a Temporal signal is fired (chunk D)" on accept. **The handler does NOT fire any signal.** Parity = DB transition only.
> ⚠️ **GOTCHA — success body shape:** `{"bundle": <BundleDetail json>, "validation": <BundleValidationResult dict>}`. Failure body is the `OlympusHTTPException` error envelope with `details.violations` and `details.bundle`.

- **Service `submit` (bundle.py:754-849) — reproduce every branch:**
```
bundle_row = SELECT status, claimed_by_user_id FROM delegated_bundle WHERE id=:bid FOR UPDATE
if bundle_row is None: 404 detail="Bundle not found"   # plain string
if bundle_row.status not in ("claimed","submitted"):
    409 {"code":"BUNDLE_NOT_CLAIMED","message":f"Bundle status {status!r} cannot accept a submission."}
if not is_admin and bundle_row.claimed_by_user_id != user_id:
    403 {"code":"BUNDLE_NOT_OWNER","message":"Only the claiming user may submit this bundle."}

output_specs = _load_required_outputs(db, bundle_id)
violations = _validate_against_schemas(payload, output_specs)
now = datetime.now(utc)
await _persist_session_artifacts(db, bundle_id, payload.session)   # ALWAYS, even on failure

if violations:
    await _persist_validation_history(db, bundle_id, user_id, "rejected", violations)
    commit
    detail = await get_bundle(db, bundle_id)
    return detail, BundleValidationResult(valid=False, violations=violations)   # bundle STAYS claimed

# success path:
for kind, ref in payload.outputs.items():
    UPDATE delegated_bundle_output_ref SET submitted_artifact_ref=:ref, submitted_at=:now
        WHERE bundle_id=:bid AND artifact_kind=:kind
UPDATE delegated_bundle SET status='accepted', submitted_at=:now, accepted_at=:now, updated_at=:now WHERE id=:bid
await _persist_validation_history(db, bundle_id, user_id, "accepted", None)
commit
detail = await get_bundle(db, bundle_id)
return detail, BundleValidationResult(valid=True, violations=[])
```

- **`_validate_against_schemas` (bundle.py:605-684) — multi-artifact validation, reproduce every branch:**
```
violations = []
submitted_kinds = set(payload.outputs.keys())
for spec in output_specs:           # iterate CONTRACT outputs
    kind, required, schema_ref = spec.artifact_kind, bool(spec.required), spec.schema_ref
    ref = payload.outputs.get(kind)
    if required and ref is None:
        violations += BundleValidationViolation(artifact_kind=kind, code="MISSING_REQUIRED_OUTPUT",
            message=f"Required output {kind!r} not present in submission.")
        continue
    if ref is None: continue        # optional + absent → ok
    if not isinstance(ref, str) or not ref.strip():
        violations += BundleValidationViolation(artifact_kind=kind, code="EMPTY_ARTIFACT_REF",
            message=f"Submitted ref for {kind!r} must be a non-empty string.")
        continue
    schema_path = _resolve_schema_path(schema_ref)
    if not schema_path.exists():
        violations += BundleValidationViolation(artifact_kind=kind, code="SCHEMA_REF_MISSING",
            message=f"Schema file {schema_ref!r} not found on disk; submitted artifact cannot be validated.")
# extra-kind rejection:
contract_kinds = {s.artifact_kind for s in output_specs}
extra = submitted_kinds - contract_kinds
for kind in sorted(extra):
    violations += BundleValidationViolation(artifact_kind=kind, code="UNKNOWN_OUTPUT_KIND",
        message=f"Output kind {kind!r} is not part of this bundle's contract.")
return violations
```
> ⚠️ **GOTCHA — violation codes are an exact contract:** `MISSING_REQUIRED_OUTPUT`, `EMPTY_ARTIFACT_REF`, `SCHEMA_REF_MISSING`, `UNKNOWN_OUTPUT_KIND`. (The model docstring at bundle.py:341-343 mentions `SCHEMA_VIOLATION`/`CROSS_ARTIFACT_CONSTRAINT_FAILED` as *roadmap* examples — they are NOT emitted by v1 code.)
> ⚠️ **GOTCHA — schema is checked for EXISTENCE only** (`schema_path.exists()`). The artifact CONTENTS are never fetched/validated by the API (bundle.py:613-616).

- **`_resolve_schema_path` (bundle.py:61-77):** `_SCHEMAS_ROOT = Path(__file__).resolve().parents[3] / "schemas"` (computed once at import, bundle.py:56-58). Reject `..` → **500** `{"code":"BUNDLE_SCHEMA_REF_INVALID",...}`. Else `rel = schema_ref.removeprefix("schemas/")`; return `_SCHEMAS_ROOT / rel`.
> ⚠️ **GOTCHA — `_SCHEMAS_ROOT` is `parents[3]` of `services/bundle.py`** (i.e. monorepo `schemas/`, two levels above `olympus-api/`). Hardcoded path; preserve directory depth.

- **`_persist_session_artifacts` (bundle.py:705-725):** for each `BundleSessionPayload` → `INSERT INTO delegated_bundle_session_artifact (bundle_id, kind, artifact_ref, hash) VALUES (:bid, kind.value, ref, hash)`. No-op if `sessions` falsey.
- **`_persist_validation_history` (bundle.py:728-751):** `INSERT INTO delegated_bundle_validation_history (bundle_id, submitted_by, outcome, violations) VALUES (:bid,:by,:outcome, CAST(:violations AS JSONB))` where `:violations = json.dumps([v.model_dump() for v in violations]) if violations else None`.

- **`get_bundle` service (bundle.py:148-239)** — 404 `{"code":"BUNDLE_NOT_FOUND","message":f"Bundle {bundle_id} not found."}` if missing; else 5 queries: main row + `delegated_bundle_input_ref` (ORDER BY artifact_kind) + `delegated_bundle_output_ref` (ORDER BY artifact_kind) + `delegated_bundle_session_artifact` (ORDER BY captured_at) + `delegated_bundle_validation_history` (ORDER BY submitted_at). `local_agent_descriptor` json-parsed if str. Assembles `BundleDetail`.

---

# ROUTER 3 — Admin bundles (`olympus-api/src/routers/admin_bundles.py`) — 2 endpoints

`router = APIRouter(prefix="/api/v1/admin", tags=["Admin"])` (admin_bundles.py:36)

**Auth model:** both endpoints require `RBACRole.PORTFOLIO_ADMIN` via `user: Annotated[CurrentUser, Depends(require_role(RBACRole.PORTFOLIO_ADMIN))]` (handler param, not route-level). `require_role` → **403** `"Requires one of: ['portfolio_admin']"` if missing.

### A1. `POST /api/v1/admin/portfolios/{portfolio_id}/bundles` — `admin_create_bundle` (admin_bundles.py:39-84)
- **Path:** `portfolio_id: Annotated[uuid.UUID, Path(...)]`
- **Body:** `body: BundleDispatchRequest` **(required)**
- **Auth:** `Depends(require_role(RBACRole.PORTFOLIO_ADMIN))`
- **Response model:** `BundleDetail`; **status_code=201** (declared on decorator, admin_bundles.py:42)
- **`BundleDispatchRequest` (bundle.py:297-312):** `scope_kind: BundleScopeKind (req); target_id: str = Field(..., min_length=1, max_length=128); application_id: UUID|None=None; wave_id: UUID|None=None; expires_in_hours: int|None = Field(default=24*7, ge=1, le=24*30, "TTL from claim time. Default 7 days; max 30 days."); fallback_policy: BundleFallbackPolicy = INTERNAL_FALLBACK`
- **Handler logic (reproduce all branches):**
```
contract = await bundle_contract.resolve(db, scope_kind=body.scope_kind, target_id=body.target_id,
    application_id=body.application_id, wave_id=body.wave_id)
if contract.metadata.portfolio_id != portfolio_id:
    raise HTTPException(status_code=400, detail={"code":"BUNDLE_PORTFOLIO_MISMATCH",
        "message":"The referenced application/wave belongs to a different portfolio than the URL portfolio_id."})
bundle_id = await bundle_svc.dispatch(db, contract=contract, fallback_policy=body.fallback_policy,
    expires_in_hours=body.expires_in_hours, created_by_user_id=user.sub)
return await bundle_svc.get_bundle(db, bundle_id)
```
> ⚠️ **GOTCHA — uses plain `fastapi.HTTPException` with a `detail` *dict*** (not `OlympusHTTPException`). The 400 body's `detail` is the coded dict above. (Contrast: bundles.py submit uses `OlympusHTTPException`.)
- **`bundle_contract.resolve` (bundle_contract.py:466-520+):** if `application_id is None and wave_id is None` → **400** `{"code":"BUNDLE_SCOPE_REQUIRED","message":"Either application_id or wave_id must be set on a bundle dispatch."}`. Resolves `portfolio_id`(+`risk_tier` for app) from app/wave, builds default inputs, `outputs = _outputs_for(scope_kind, target_id)`, sets `gate_id=target_id` iff GATE_PACKET else None, `step_id=target_id` iff LINE_STEP else None.
- **Service `dispatch` (bundle.py:309-396):**
```
bundle_id = uuid.uuid4()
INSERT INTO delegated_bundle (id, portfolio_id, application_id, wave_id, scope_kind, target_id,
    status='offered', fallback_policy, created_by_user_id) VALUES (...)
for inp in contract.inputs: INSERT INTO delegated_bundle_input_ref (bundle_id, artifact_kind, artifact_ref, description)
for out in contract.outputs: INSERT INTO delegated_bundle_output_ref (bundle_id, artifact_kind, schema_ref, required, description)
if expires_in_hours is not None:
    UPDATE delegated_bundle SET local_agent_descriptor = jsonb_build_object('_expires_in_hours', :hours) WHERE id=:id
commit; return bundle_id
```
> ⚠️ **GOTCHA:** dispatch records status `'offered'`, `expires_at` NULL; TTL stashed under `local_agent_descriptor._expires_in_hours` for the claim handler to consume.

### A2. `POST /api/v1/admin/bundles/{bundle_id}/force-release` — `admin_force_release` (admin_bundles.py:87-108)
- **Path:** `bundle_id: uuid.UUID`
- **Body:** `body: BundleReleaseRequest | None` (optional)
- **Auth:** `Depends(require_role(RBACRole.PORTFOLIO_ADMIN))`
- **Response model:** `BundleDetail` — **200**
- **Handler logic:**
```
return await bundle_svc.release(db, bundle_id=bundle_id, user_id=user.sub, is_admin=True,
    reason=(body.reason if body and body.reason else "admin force-release"))
```
> ⚠️ **GOTCHA:** always passes `is_admin=True` (bypasses owner check in `release`). Default reason `"admin force-release"` when body/reason absent. Same `release` service branches as B5 apply (404 plain-string / 409 BUNDLE_TERMINAL; owner-check skipped since is_admin).

---

## Status-code summary (per endpoint)

| Endpoint | Success | Error branches |
|---|---|---|
| T1-T6 | 200 | 401 (no token) / 403 (role not in VIEWER_PLUS, or not member) / 404 (app missing, via require_application_member) |
| T7 stale | 200 | 401 / 403 (role) / 404 (app missing if app_id given) / 403 (not member) |
| B1 list | 200 | 401 |
| B2 get | 200 | 401 / 404 (BUNDLE_NOT_FOUND) / 403 (PORTFOLIO_NOT_MEMBER) |
| B3 audit | 200 | 401 / 404 / 403 |
| B4 claim | 200 | 401 / 403 (member) / 404 (BUNDLE_NOT_FOUND) / 409 (BUNDLE_TERMINAL, BUNDLE_ALREADY_CLAIMED) |
| B5 release | 200 | 401 / 403 (member; BUNDLE_NOT_OWNER) / 404 / 409 (BUNDLE_TERMINAL) |
| B6 validate | 200 | 401 / 403 (member) / 404 |
| B7 submit | 200 | 401 / 403 (member; BUNDLE_NOT_OWNER) / 404 / 409 (BUNDLE_NOT_CLAIMED) / 422 (BUNDLE_VALIDATION_FAILED) |
| A1 create | 201 | 401 / 403 (not portfolio_admin) / 400 (BUNDLE_PORTFOLIO_MISMATCH, BUNDLE_SCOPE_REQUIRED) / 500 (BUNDLE_SCHEMA_REF_INVALID via validate, not on create) |
| A2 force-release | 200 | 401 / 403 (not portfolio_admin) / 404 / 409 (BUNDLE_TERMINAL) |

> ⚠️ Error-detail SHAPE differs by exception type: `OlympusHTTPException` → `{"error":{code,message,details,request_id}}`; coded `HTTPException(detail={...})` → detail-as-dict; plain `HTTPException(detail="...")` (404 in release/submit) → string detail mapped by the generic handler.
