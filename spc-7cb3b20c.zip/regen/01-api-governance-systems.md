# Regen Spec — Phase 8 API: Governance + Systems Routers

ATOMIC regeneration spec. Behavioral-parity bar. Two FastAPI routers:

| Router | File | Prefix | Endpoint count |
|--------|------|--------|----------------|
| Governance | `olympus-api/src/routers/governance.py` | `/api/v1/governance` (4 endpoints override to `/api/v1/governance/portfolios/...`) | **12** at HEAD `7cb3b20c` (was 9; +3) |
| Systems | `olympus-api/src/routers/systems.py` | `/api/v1` | **12** |

> ⚠️ **GOVERNANCE GREW 9 → 12 at HEAD `7cb3b20c`.** New endpoints: A10 `GET .../portfolios/{id}/compliance-evidence-export` (P6-S8.10, OSCAL ZIP), A11 `POST /governance/schedule` (P6-S8.6, upsert recurring schedule), A12 `DELETE /governance/schedule/{portfolio_id}` (P6-S8.6, deregister). Several A7–A9 line citations also SHIFTED (governance.py grew). `@router` decorator count = **12** (`governance.py:169,215,249,291,339,395,511,586,815,1104,1235,1282`).
>
> ⚠️ **GOTCHA — the prompt note "systems fires signals" is INACCURATE.** The **systems** router fires NO Temporal signals or workflow starts. Its ratify/reject service functions ONLY persist DB row state (`systems.py:212`, `services/system.py:548-551`). The endpoints that DO touch Temporal are in **governance**: `POST /sweep` (`temporal.start_workflow("GovernanceWorkflow", ...)`, `governance.py:550`) and `POST /governance/schedule` (`create_governance_schedule(...)`, `governance.py:1257`) + `DELETE /governance/schedule/{id}` (`delete_governance_schedule(...)`, `governance.py:1297`). Reproduce the workflow-start/schedule ops exactly (see §A7/§A11/§A12).

---

## 0. Shared infrastructure (cite-backed, used by both routers)

### 0.1 RBAC roles — `src/models/common.py:47-57`
`RBACRole(str, enum.Enum)`, **9 members** (string values):
```
PORTFOLIO_ADMIN  = "portfolio_admin"
PORTFOLIO_MANAGER= "portfolio_manager"
TECH_LEAD        = "tech_lead"
ARCH_LEAD        = "arch_lead"
COMPLIANCE_LEAD  = "compliance_lead"
OPERATIONS_LEAD  = "operations_lead"
SAFETY_BOARD     = "safety_board"
VIEWER           = "viewer"
SERVICE          = "service"
```

### 0.2 Auth dependencies — `src/middleware/auth.py`
- `CurrentUser` (`auth.py:32-41`): attrs `sub: str`, `roles: list[RBACRole]`, `claims: dict`; method `has_role(*roles) -> bool` returns `any(r in self.roles for r in roles)`.
- `get_current_user(request)` (`auth.py:52-103`): If `DEV_AUTH_BYPASS=true` → returns `CurrentUser(sub="local-dev", roles=list(RBACRole), claims={...,"dev_bypass":True})`. Else extracts `Bearer` token (`auth.py:44-49`); missing → **401** `{"detail":"Missing authorization token"}`. Decodes JWT via `jose.jwt.decode` with secret `JWT_SECRET` (default `"olympus-dev-secret"`), alg `JWT_ALGORITHM` (default `HS256`); if `AUTH_SKIP_VERIFICATION=true` (default true) sets options `verify_signature/exp/aud=False`. `JWTError` → **401** `"Invalid or expired token"`. `sub = payload["sub"]` (default `"anonymous"`); roles parsed from `payload["roles"]`, unknown role strings logged + skipped; if no roles → `[RBACRole.VIEWER]`.
- `require_role(*required_roles)` (`auth.py:106-119`): returns an async dependency `_check` that raises **403** `{"detail": f"Requires one of: {[r.value for r in required_roles]}"}` (NOTE: plain `HTTPException`, so envelope code is `FORBIDDEN` — see §0.5) unless `user.has_role(*required_roles)`. Returns the `CurrentUser` on success.

### 0.3 Pagination — `src/middleware/pagination.py`
- `PaginationParams` dataclass: `page:int`, `per_page:int`; property `offset = (page-1)*per_page` (`pagination.py:16-25`).
- `get_pagination(page:int=Query(1,ge=1), per_page:int=Query(20,ge=1,le=100)) -> PaginationParams` (`pagination.py:28-33`). ⚠️ `per_page` capped at **100**, min 1; `page` min 1.
- `paginated_response(items, total, params) -> dict` (`pagination.py:36-47`): returns
  ```json
  {"data": items, "pagination": {"page":..,"per_page":..,"total":..,"total_pages": max(1, ceil(total/per_page))}}
  ```
  ⚠️ `total_pages` is `max(1, ...)` — always ≥1 even when total=0.

### 0.4 Portfolio-membership dependencies — `src/dependencies.py`
All membership checks **bypass for `RBACRole.PORTFOLIO_ADMIN`** (return immediately/`None`). Helper `verify_portfolio_access(db, user, portfolio_id)` (`dependencies.py:105-133`): admin → pass; else `membership_svc.is_member(...)` → pass; else raise **403** `HTTPException(detail={"code":"PORTFOLIO_NOT_MEMBER","message":"Caller is not a member of this portfolio. Ask a portfolio_admin to grant access."})`. ⚠️ This detail is a **dict**, so the envelope's `message` becomes the stringified dict; `code` is `FORBIDDEN` (see §0.5).

Path-style `Depends(...)` dependencies (each reads its id from the URL `Path`, short-circuits for admin, then resolves portfolio via a SQL lookup and calls `verify_portfolio_access`; resolver 404s if the id row is absent):
- `require_system_member` (`dependencies.py:320-329`) — resolves `system.portfolio_id` (`verify_system_portfolio_access` `:243-262`; 404 `"System not found"`).
- `require_capability_member` (`dependencies.py:332-341`) — resolves via `capability JOIN system` (`verify_capability_portfolio_access` `:265-289`; 404 `"Capability not found"`).
- `require_capability_lineage_member` (`dependencies.py:344-353`) — resolves via `capability_lineage JOIN capability(target) JOIN system` (`verify_capability_lineage_portfolio_access` `:292-317`; 404 `"Capability lineage not found"`). ⚠️ Joins on `target_capability_id`; a lineage row whose `target_capability_id IS NULL` (relationship `dropped`) will NOT resolve a portfolio → resolver returns row `None` → **404 "Capability lineage not found"** for non-admins even though the row exists.
- `require_wave_member` (`dependencies.py:160-169`) — resolves `wave.portfolio_id` (`verify_wave_portfolio_access` `:216-240`; 404 `"Wave not found"`).
- `filter_portfolio_ids_by_membership(db, user, candidate=None)` (`dependencies.py:389-411`): admin → `None` (means "no filter"); else returns `membership_svc.list_user_portfolio_ids(...)` (intersected with `candidate` if given).
- `get_temporal_client()` (`dependencies.py:34-43`): lazy module-global `Client.connect(config.temporal_host, namespace=config.temporal_namespace)`.
- `get_config()` (`dependencies.py:28-31`): `@lru_cache` singleton `AppConfig()`.

### 0.5 Error envelope — `src/middleware/error_handler.py`
`OlympusHTTPException(status_code, code, message, details=None)` (`error_handler.py:20-32`) → handler emits (`:35-46,:52-59`):
```json
{"error": {"code": <code>, "message": <message>, "details": <details or {}>, "request_id": <id>}}
```
Plain `StarletteHTTPException`/`HTTPException` mapped by status (`:61-73`): 400→`BAD_REQUEST`, 401→`UNAUTHORIZED`, 403→`FORBIDDEN`, 404→`NOT_FOUND`, 409→`CONFLICT`, 422→`VALIDATION_ERROR`, 429→`RATE_LIMITED`, else `ERROR`; `message = str(exc.detail)`. Pydantic `RequestValidationError` → **422** `VALIDATION_ERROR` with sanitized `details.errors[]` (`:75-102`). Unhandled `Exception` → **500** `INTERNAL_ERROR` (`:104-107`).

---

# PART A — GOVERNANCE ROUTER (`src/routers/governance.py`)

Router decl: `APIRouter(prefix="/api/v1/governance", tags=["Governance"])` (`governance.py:63`).
Tables: `health_check`, `drift_alert`, `pattern` (migration 025). Endpoints return **empty-state** payloads (not 404) when tables exist-but-empty or missing.

### A.0 Role groups — `governance.py:47-61`
```
VIEWER_PLUS  = [VIEWER, TECH_LEAD, ARCH_LEAD, COMPLIANCE_LEAD, OPERATIONS_LEAD, SAFETY_BOARD, PORTFOLIO_MANAGER, PORTFOLIO_ADMIN]   # 8 roles (NOT service)
MANAGER_PLUS = [PORTFOLIO_MANAGER, PORTFOLIO_ADMIN]                                                                                # 2 roles
```

### A.0.1 Missing-table tolerance helpers
- `_safe_execute_rows(db, sql, params) -> list[dict]` (`governance.py:114-131`): runs SELECT, returns `[dict(r) for r in result.mappings().all()]`. On `(ProgrammingError, DBAPIError)` whose lowercased msg contains (`"undefined"` AND `"relation"`) OR `"does not exist"` → returns `[]`; otherwise **re-raises**. ⚠️ Narrow match — genuine DB errors still 500.
- `_safe_execute_scalar(db, sql, params) -> Any` (`governance.py:134-142`): runs SELECT, returns `result.scalar()`. Same exception tolerance → returns `None`; else re-raises.

### A.0.2 Pydantic response models (governance.py)
- `HealthCheck` (`:71-76`): `id: UUID`, `date: dt_date`, `health_index: float = Field(ge=0, le=1)`, `alerts: list[dict[str,Any]]=[]`, `checks: list[dict[str,Any]]=[]`.
- `DriftAlert` (`:79-85`): `id: UUID`, `type: str`, `app_id: UUID|None=None`, `details: dict[str,Any]={}`, `acknowledged: bool`, `created_at: datetime`.
- `PatternSummary` (`:88-94`): `id: UUID`, `name: str`, `category: str`, `wave_id: UUID|None=None`, `reuse_count: int`, `created_at: datetime`.
- `PatternDetail` (`:97-106`): `id: UUID`, `name: str`, `category: str`, `description: str=""`, `wave_id: UUID|None=None`, `source_apps: list[UUID]=[]`, `reuse_count: int`, `content: dict[str,Any]={}`, `created_at: datetime`.
- `GovernanceSweepRequest` (`:428-452`): `portfolio_id: UUID` (required), `cadence: Literal["weekly","quarterly"]=Field(default="weekly")`.
- `GovernanceSweepResponse` (`:455-469`): `workflow_id: str`, `schedule_id: str`, `cadence: Literal["weekly","quarterly"]`, `portfolio_id: UUID`, `started_at: datetime`, `status: str="running"`, `temporal_ui_url: str|None=None`.
- `GovernanceSweepSummary` (`:472-489`): `workflow_id: str`, `portfolio_id: UUID|None=None`, `started_at: datetime`, `completed_at: datetime|None=None`, `cadence: str|None=None`, `schedule_id: str|None=None`, `status: str`, `health_index: float|None=None`.
- `CatoControlEvidence` (`:647-678`): `control_id: str`, `family: str`, `title: str=""`, `status: Literal["implemented","partial","planned","not-applicable","unknown"]="unknown"`, `last_assessed: datetime|None=None`, `source: str|None=None`.
- `SystemCatoEvidence` (`:681-695`): `system_id: UUID`, `system_name: str`, `system_external_id: str|None=None`, `cato_state: Literal["not-started","in-progress","transition","inheriting","certified","expired","unknown"]="unknown"`, `cato_certified: bool=False`, `application_count: int=0`, `cato_certified_application_count: int=0`, `controls: list[CatoControlEvidence]=[]`, `last_assessed: datetime|None=None`.
- `PortfolioCatoEvidenceTotals` (`:698-708`): `system_count:int=0`, `cato_certified_systems:int=0`, `application_count:int=0`, `cato_certified_applications:int=0`, `controls_implemented:int=0`, `controls_partial:int=0`, `controls_planned:int=0`, `controls_unknown:int=0`.
- `PortfolioCatoEvidence` (`:711-733`): `portfolio_id: UUID`, `systems: list[SystemCatoEvidence]=[]`, `totals: PortfolioCatoEvidenceTotals=default_factory`, `generated_at: datetime`.

---

## A1. `GET /api/v1/governance/health-checks` — `list_health_checks` (`governance.py:150-193`)
- **Auth**: `_user = Depends(require_role(*VIEWER_PLUS))`. `db = Depends(get_db)`.
- **Query params**: `date: dt_date|None=None`; `pagination = Depends(get_pagination)` (`page`,`per_page`).
- **Response**: `dict` → `paginated_response(data, total, pagination)`; `data[]` = `HealthCheck.model_dump(mode="json")`.
- **Status**: 200; 401/403 per auth.
- **Logic** (preserve exactly):
```
where = ""
params = {"limit": pagination.per_page, "offset": pagination.offset}
if date: where = "WHERE date = :date"; params["date"] = date
total = int(_safe_execute_scalar(db, f"SELECT count(*) FROM health_check {where}", params) or 0)
rows = _safe_execute_rows(db, f"""
    SELECT id, date, health_index, checks FROM health_check {where}
    ORDER BY date DESC, created_at DESC LIMIT :limit OFFSET :offset""", params)
data = [ HealthCheck(id=r["id"], date=r["date"], health_index=float(r["health_index"]),
                     checks = r.get("checks") if isinstance(r.get("checks"), list) else [],
                     alerts=[]).model_dump(mode="json")  for r in rows ]
return paginated_response(data, total, pagination)
```
⚠️ `alerts` always `[]` here (not read from DB). `checks` coerced to `[]` if not a list.

## A2. `GET /api/v1/governance/health-checks/latest` — `latest_health_check` (`governance.py:196-222`)
- **Auth**: `require_role(*VIEWER_PLUS)`; `db`.
- **Response**: `dict`. If no rows → `{"data": None, "empty_state": True}`. Else a single `HealthCheck.model_dump(mode="json")` (NOT wrapped in `data`).
- **Status**: 200.
- **Logic**:
```
rows = _safe_execute_rows(db, "SELECT id, date, health_index, checks FROM health_check
                                ORDER BY date DESC, created_at DESC LIMIT 1", {})
if not rows: return {"data": None, "empty_state": True}
r = rows[0]
return HealthCheck(id=r["id"], date=r["date"], health_index=float(r["health_index"]),
                   checks = r.get("checks") if isinstance(r.get("checks"), list) else [],
                   alerts=[]).model_dump(mode="json")
```

## A3. `GET /api/v1/governance/drift-alerts` — `list_drift_alerts` (`governance.py:230-269`)
- **Auth**: `require_role(*VIEWER_PLUS)`; `pagination`; `db`.
- **Response**: `dict` → `paginated_response`; `data[]` = `DriftAlert.model_dump(mode="json")`.
- **Status**: 200.
- **Logic** (only **unacknowledged** alerts):
```
total = int(_safe_execute_scalar(db, "SELECT count(*) FROM drift_alert WHERE acknowledged = false", {}) or 0)
rows = _safe_execute_rows(db, """
    SELECT id, type, application_id, details, acknowledged, created_at
    FROM drift_alert WHERE acknowledged = false
    ORDER BY created_at DESC LIMIT :limit OFFSET :offset""",
    {"limit": pagination.per_page, "offset": pagination.offset})
data = [ DriftAlert(id=r["id"], type=r["type"], app_id=r.get("application_id"),
                    details = r.get("details") if isinstance(r.get("details"), dict) else {},
                    acknowledged=bool(r["acknowledged"]), created_at=r["created_at"]).model_dump(mode="json")
         for r in rows ]
return paginated_response(data, total, pagination)
```
⚠️ DB column is `application_id`, mapped to model field `app_id`.

## A4. `POST /api/v1/governance/drift-alerts/{alert_id}/acknowledge` — `acknowledge_drift_alert` (`governance.py:272-312`)
- **Path**: `alert_id: uuid.UUID`.
- **Auth**: `user = Depends(require_role(*MANAGER_PLUS))` (⚠️ manager/admin only). `db`.
- **Response model**: `DriftAlert` (`response_model=DriftAlert`, `:272`). **Status 200**.
- **Errors**: row absent → `OlympusHTTPException(404, "ALERT_NOT_FOUND", f"Drift alert {alert_id} not found")`.
- **Logic** (mutates + commits):
```
row = (SELECT * FROM drift_alert WHERE id = :id).mappings().first()
if row is None: raise OlympusHTTPException(404,"ALERT_NOT_FOUND", f"Drift alert {alert_id} not found")
now = datetime.now(timezone.utc)
UPDATE drift_alert SET acknowledged=true, acknowledged_by=:by, acknowledged_at=:at WHERE id=:id
   -- params {"id": alert_id, "by": user.sub, "at": now}
db.commit()
return DriftAlert(id=row["id"], type=row["type"], app_id=row.get("application_id"),
                  details = row.get("details") if isinstance(row.get("details"), dict) else {},
                  acknowledged=True, created_at=row["created_at"])
```
⚠️ Does NOT use `_safe_execute_*` — a missing `drift_alert` table here yields a 500, unlike the list endpoints.

## A5. `GET /api/v1/governance/patterns` — `list_patterns` (`governance.py:320-373`)
- **Auth**: `require_role(*VIEWER_PLUS)`; `pagination`; `db`.
- **Query params**: `category: str|None=None`, `wave_id: uuid.UUID|None=None`.
- **Response**: `dict` → `paginated_response`; `data[]` = `PatternSummary.model_dump(mode="json")`.
- **Logic** (dynamic WHERE):
```
where_clauses = []; params = {"limit": per_page, "offset": offset}
if category: where_clauses.append("category = :category"); params["category"]=category
if wave_id:  where_clauses.append("wave_id = :wave_id");   params["wave_id"]=wave_id
where_sql = ("WHERE " + " AND ".join(where_clauses)) if where_clauses else ""
total = int(_safe_execute_scalar(db, f"SELECT count(*) FROM pattern {where_sql}", params) or 0)
rows = _safe_execute_rows(db, f"""
    SELECT id, name, category, wave_id, reuse_count, created_at FROM pattern {where_sql}
    ORDER BY reuse_count DESC, created_at DESC LIMIT :limit OFFSET :offset""", params)
data = [ PatternSummary(id=r["id"], name=r["name"], category=r["category"], wave_id=r.get("wave_id"),
                        reuse_count=int(r["reuse_count"]), created_at=r["created_at"]).model_dump(mode="json")
         for r in rows ]
return paginated_response(data, total, pagination)
```

## A6. `GET /api/v1/governance/patterns/{pattern_id}` — `get_pattern` (`governance.py:376-413`)
- **Path**: `pattern_id: uuid.UUID`. **Auth**: `require_role(*VIEWER_PLUS)`; `db`.
- **Response model**: `PatternDetail` (`:376`). **Status 200**.
- **Errors**: absent → `OlympusHTTPException(404, "PATTERN_NOT_FOUND", f"Pattern {pattern_id} not found")`.
- **Logic** (note `source_apps` defensive UUID parse):
```
row = (SELECT * FROM pattern WHERE id = :id).mappings().first()
if row is None: raise OlympusHTTPException(404,"PATTERN_NOT_FOUND", f"Pattern {pattern_id} not found")
source_apps_raw = row.get("source_apps") or []
source_apps = []
if isinstance(source_apps_raw, list):
    for entry in source_apps_raw:
        try: source_apps.append(uuid.UUID(str(entry)))
        except (ValueError, TypeError): continue   # skip malformed entries
return PatternDetail(id=row["id"], name=row["name"], category=row["category"],
    description = row.get("description") or "", wave_id=row.get("wave_id"),
    source_apps=source_apps, reuse_count=int(row["reuse_count"]),
    content = row.get("content") if isinstance(row.get("content"), dict) else {},
    created_at=row["created_at"])
```
⚠️ Does NOT use `_safe_execute_*` (missing table → 500).

## A7. `POST /api/v1/governance/sweep` — `start_governance_sweep` (`governance.py:511-583`) — **TEMPORAL WORKFLOW START**
- **Decorator**: `@router.post("/sweep", response_model=GovernanceSweepResponse, status_code=202)`.
- **Body**: `GovernanceSweepRequest` (`portfolio_id` required, `cadence` default `"weekly"`).
- **Auth/deps**: `user = Depends(require_role(*MANAGER_PLUS))`; `temporal: Client = Depends(get_temporal_client)`; `db = Depends(get_db)`.
- **Response model**: `GovernanceSweepResponse`. **Success status: 202**.
- **Errors**: membership 403 (via `verify_portfolio_access`); workflow-start failure → `OlympusHTTPException(502, "TEMPORAL_START_WORKFLOW_FAILED", f"Failed to start GovernanceWorkflow: {exc!r}")`.
- **Logic — reproduce EVERY line (deterministic id construction + start_workflow):**
```
await verify_portfolio_access(db, user, body.portfolio_id)          # 403 if not member (admin bypass)
config = get_config()
now = datetime.now(timezone.utc)
schedule_id = f"gov-{body.cadence}-adhoc-{now.strftime('%Y%m%dT%H%M%S')}"
workflow_id = f"governance-{body.portfolio_id}-{schedule_id}"
input_dict = {
    "portfolio_id": str(body.portfolio_id),
    "schedule_id": schedule_id,
    "triggered_at": now.isoformat(),
    "activities": [],                       # ⚠️ ALWAYS empty list; cadence is encoded ONLY in schedule_id
}
try:
    await temporal.start_workflow(
        "GovernanceWorkflow",               # workflow type name (string)
        input_dict,                         # single positional arg
        id=workflow_id,
        task_queue=config.temporal_task_queue,
    )
except Exception as exc:                    # noqa: BLE001 — catch-all
    raise OlympusHTTPException(502, "TEMPORAL_START_WORKFLOW_FAILED",
                               f"Failed to start GovernanceWorkflow: {exc!r}")
temporal_ui_url = None
base = getattr(config, "temporal_ui_base_url", None) or ""
if base:
    namespace = getattr(config, "temporal_namespace", "default")
    temporal_ui_url = f"{base.rstrip('/')}/namespaces/{namespace}/workflows/{workflow_id}"
return GovernanceSweepResponse(
    workflow_id=workflow_id, schedule_id=schedule_id, cadence=body.cadence,
    portfolio_id=body.portfolio_id, started_at=now, status="running",
    temporal_ui_url=temporal_ui_url)
```
⚠️ GOTCHAS: (1) `schedule_id` uses second-resolution timestamp `%Y%m%dT%H%M%S` — two triggers within the same second produce an identical `workflow_id` → Temporal rejects the 2nd as a duplicate → caught → **502**. (2) Workflow downstream selects its activity set from the `gov-weekly-`/`gov-quarterly-` prefix in `schedule_id`, NOT from `activities` (always `[]`). (3) `start_workflow` failure (incl. `WorkflowAlreadyStartedError`) → 502, never 409.

## A8. `GET /api/v1/governance/sweeps` — `list_governance_sweeps` (`governance.py:586-658`)
- **Auth/deps**: `_user = Depends(require_role(*VIEWER_PLUS))` AND `user = Depends(get_current_user)` (⚠️ TWO user deps — `_user` enforces role, `user` is the identity used for membership filtering). `pagination`; `db`.
- **Query**: `portfolio_id: uuid.UUID|None=None`.
- **Response**: `dict` → `paginated_response`; `data[]` = `GovernanceSweepSummary.model_dump(mode="json")`. **Sourced from `health_check` rows** (one per completed sweep).
- **Logic** (membership filter via `filter_portfolio_ids_by_membership`):
```
if portfolio_id is not None: await verify_portfolio_access(db, user, portfolio_id)
member_ids = await filter_portfolio_ids_by_membership(db, user)   # None for admin
clauses = []; params = {"limit": per_page, "offset": offset}
if member_ids is not None:
    if not member_ids: return paginated_response([], 0, pagination)   # ⚠️ early empty exit: non-admin with zero memberships
    clauses.append("portfolio_id = ANY(:pf_ids)"); params["pf_ids"] = member_ids
if portfolio_id is not None:
    clauses.append("portfolio_id = :portfolio_id"); params["portfolio_id"] = portfolio_id
where = f"WHERE {' AND '.join(clauses)}" if clauses else ""
total = int(_safe_execute_scalar(db, f"SELECT count(*) FROM health_check {where}", params) or 0)
rows = _safe_execute_rows(db, f"""
    SELECT id, portfolio_id, date, health_index, checks, created_at FROM health_check {where}
    ORDER BY created_at DESC LIMIT :limit OFFSET :offset""", params)
data = [ GovernanceSweepSummary(
            workflow_id=str(r["id"]),               # ⚠️ workflow_id == health_check row id (NOT the Temporal wf id)
            portfolio_id=r.get("portfolio_id"),
            started_at=r["created_at"], completed_at=r["created_at"],   # ⚠️ both = created_at
            cadence=None, schedule_id=None, status="completed",         # ⚠️ status hard-coded "completed"
            health_index = float(r["health_index"]) if r.get("health_index") is not None else None
         ).model_dump(mode="json") for r in rows ]
return paginated_response(data, total, pagination)
```

## A9. `GET /api/v1/governance/portfolios/{portfolio_id}/cato-evidence` — `get_portfolio_cato_evidence` (`governance.py:815-1071`)
- **Decorator**: `@router.get("/portfolios/{portfolio_id}/cato-evidence", response_model=PortfolioCatoEvidence, tags=["Compliance"])`. ⚠️ **Full path is `/api/v1/governance/portfolios/{portfolio_id}/cato-evidence`** (router prefix `/api/v1/governance` still applies — the literal decorator path is `/portfolios/...`). Tag override `Compliance`.
- **Path**: `portfolio_id: uuid.UUID`. **Auth/deps**: `_user = Depends(require_role(*VIEWER_PLUS))` AND `user = Depends(get_current_user)`; `db`.
- **Response model**: `PortfolioCatoEvidence`. **Status 200**.
- **Errors**: membership 403; portfolio absent → `OlympusHTTPException(404,"PORTFOLIO_NOT_FOUND", f"Portfolio {portfolio_id} not found")`.

### A9.1 Module constants/helpers
`_DEFAULT_CATO_CONTROLS` (`:741-753`) — ordered list of 11 dicts `{"id","family","title"}`:
```
AC-2/AC/Account Management, AC-3/AC/Access Enforcement, AU-2/AU/Auditable Events,
AU-12/AU/Audit Generation, IA-2/IA/Identification & Authentication (Org Users),
IA-5/IA/Authenticator Management, RA-5/RA/Vulnerability Scanning,
SC-7/SC/Boundary Protection, SC-12/SC/Cryptographic Key Establishment,
SI-2/SI/Flaw Remediation, SI-4/SI/System Monitoring
```
`_classify_control_status(meta) -> str` (`:756-783`):
```
if not isinstance(meta, dict): return "unknown"
comp = meta.get("compliance");  if not isinstance(comp, dict): return "unknown"
cato = comp.get("cato_state")
if cato == "certified":   return "implemented"
if cato == "in-progress": return "partial"
if cato == "transition":  return "planned"
return "unknown"
```

### A9.2 Handler logic — reproduce EVERY branch (scoring/rollup math):
```
await verify_portfolio_access(db, user, portfolio_id)
exists = (SELECT 1 FROM portfolio WHERE id = :id).first()
if exists is None: raise OlympusHTTPException(404,"PORTFOLIO_NOT_FOUND", f"Portfolio {portfolio_id} not found")

rows = (SELECT s.id AS system_id, s.name AS system_name, s.external_id AS system_external_id,
               a.id AS application_id, a.metadata AS application_metadata
        FROM system s
        LEFT JOIN system_application sa ON sa.system_id = s.id
        LEFT JOIN application a ON a.id = sa.application_id
        WHERE s.portfolio_id = :portfolio_id AND s.retired_at IS NULL
        ORDER BY s.kind ASC, COALESCE(s.external_id, s.name) ASC).mappings().all()

# --- Phase 1: bucket per system (insertion-ordered by query) ---
by_system = {}                      # sid -> bucket dict
for r in rows:
    sid = r["system_id"]
    bucket = by_system.setdefault(sid, {
        "system_id": sid, "system_name": r["system_name"], "system_external_id": r["system_external_id"],
        "application_count": 0, "cato_certified_application_count": 0,
        "control_status_counts": {"implemented":0,"partial":0,"planned":0,"unknown":0},
        "last_assessed": None })
    if r["application_id"] is None:           # system with no realizing app — keep bucket, skip counting
        continue
    bucket["application_count"] += 1
    meta = r["application_metadata"] or {}
    if isinstance(meta, dict):
        comp = meta.get("compliance") if isinstance(meta, dict) else None
        if isinstance(comp, dict):
            if comp.get("certified") or comp.get("cato_certified"):
                bucket["cato_certified_application_count"] += 1
            ts = comp.get("last_assessed")
            if isinstance(ts, str):
                try:
                    parsed_ts = datetime.fromisoformat(ts.replace("Z","+00:00"))
                    if bucket["last_assessed"] is None or parsed_ts > bucket["last_assessed"]:
                        bucket["last_assessed"] = parsed_ts        # keep MAX timestamp
                except (TypeError, ValueError): pass
    status = _classify_control_status(meta)
    bucket["control_status_counts"][status] = bucket["control_status_counts"].get(status,0) + 1

# --- Phase 2: per-system cATO state + per-control evidence ---
systems = []
totals_implemented = totals_partial = totals_planned = totals_unknown = 0
cato_certified_systems = 0
for sid, bucket in by_system.items():
    ccac = bucket["cato_certified_application_count"]
    # cATO state precedence (FIRST match wins):
    if ccac > 0 and ccac == bucket["application_count"]:
        cato_state = "certified"; cato_certified = True; cato_certified_systems += 1
    elif bucket["control_status_counts"]["partial"] > 0:
        cato_state = "in-progress"; cato_certified = False
    elif bucket["control_status_counts"]["planned"] > 0:
        cato_state = "transition"; cato_certified = False
    elif bucket["application_count"] == 0:
        cato_state = "not-started"; cato_certified = False
    else:
        cato_state = "unknown"; cato_certified = False

    controls = []
    for spec in _DEFAULT_CATO_CONTROLS:          # 11 controls; status derived from system cato_state
        if   cato_state == "certified":   cstatus="implemented"; totals_implemented += 1
        elif cato_state == "in-progress": cstatus="partial";     totals_partial += 1
        elif cato_state == "transition":  cstatus="planned";     totals_planned += 1
        else:                             cstatus="unknown";      totals_unknown += 1
        controls.append(CatoControlEvidence(
            control_id=spec["id"], family=spec["family"], title=spec["title"], status=cstatus,
            last_assessed=bucket["last_assessed"],
            source=("Architecture" if cato_state in ("certified","in-progress")
                    else "Discovery" if cato_state == "transition" else None)))
    systems.append(SystemCatoEvidence(
        system_id=bucket["system_id"], system_name=bucket["system_name"],
        system_external_id=bucket["system_external_id"], cato_state=cato_state,
        cato_certified=cato_certified, application_count=bucket["application_count"],
        cato_certified_application_count=ccac, controls=controls, last_assessed=bucket["last_assessed"]))

totals = PortfolioCatoEvidenceTotals(
    system_count=len(systems), cato_certified_systems=cato_certified_systems,
    application_count=sum(s.application_count for s in systems),
    cato_certified_applications=sum(s.cato_certified_application_count for s in systems),
    controls_implemented=totals_implemented, controls_partial=totals_partial,
    controls_planned=totals_planned, controls_unknown=totals_unknown)
return PortfolioCatoEvidence(portfolio_id=portfolio_id, systems=systems, totals=totals,
                             generated_at=datetime.now(timezone.utc))
```
⚠️ GOTCHAS: (1) **⚠️ CHANGED at HEAD (Phase 6 W8, governance.py:962-1037):** per-control evidence now takes PRECEDENCE over the uniform default-set rollup. When the system's apps carry real per-control records (`metadata.compliance.controls` keyed by control id, written by the Validation cATO writer), `controls[]` is built from `sorted(controls_index)` with each record's own `status`/`family`/`title`/`last_assessed` and `source="Validation"`; otherwise it falls back to the 11 `_DEFAULT_CATO_CONTROLS` (FAA SF3 §4) with a UNIFORM status derived from `cato_state` and `source` Architecture/Discovery/None. `_classify_control_status(meta, control_id=None)` (governance.py:775) also consults `comp["controls"][control_id]["status"]` first when a `control_id` is supplied. (2) Totals are control-COUNTS across whichever set was emitted (`not-applicable` is excluded from the totals). (3) `cato_state` enum literals `"inheriting"`/`"expired"` are valid on the model but never produced by this handler. (4) `"certified"` requires **all** apps cato-certified AND ≥1 app. (5) "in-progress"/"transition" use `control_status_counts` derived from `_classify_control_status` of each app's metadata.

---

## A10. `GET /api/v1/governance/portfolios/{portfolio_id}/compliance-evidence-export` — `export_compliance_evidence` (`governance.py:1104-1206`) — ⚠️ NEW at HEAD (P6-S8.10)
- **Decorator**: `@router.get("/portfolios/{portfolio_id}/compliance-evidence-export", tags=["Compliance"])`. ⚠️ Full path `/api/v1/governance/portfolios/{portfolio_id}/compliance-evidence-export` (router prefix still applies). Returns a raw `Response` (NO response_model — streams a ZIP).
- **Auth:** `_user = Depends(require_role(*EXPORT_ROLES))` PLUS `user = Depends(get_current_user)` (the one used for membership). `EXPORT_ROLES` (`governance.py:60-64`) = `[COMPLIANCE_LEAD, PORTFOLIO_MANAGER, PORTFOLIO_ADMIN]` (design §10.2 — narrower than VIEWER_PLUS).
- **Path/query:** `portfolio_id: uuid.UUID`; `app_id: uuid.UUID|None=Query(None)` (single app; omit for portfolio-wide); `format: Literal["oscal","pdf","zip"]=Query("zip")` (oscal=OSCAL JSON only; pdf=narrative only; zip=both). Extra deps `db`, `config=Depends(get_config)`.
- **Returns:** `application/zip` Response with `Content-Disposition: attachment; filename="compliance-evidence-{portfolio_id}-{ts}.zip"`. Status 200; 403; 404 `PORTFOLIO_NOT_FOUND`.
- **Handler logic:**
  ```
  await verify_portfolio_access(db, user, portfolio_id)
  repo_row = SELECT artifact_repo_url FROM portfolio WHERE id=:id  (.mappings().first())
  if repo_row is None: raise OlympusHTTPException(404,"PORTFOLIO_NOT_FOUND", f"Portfolio {portfolio_id} not found")
  repo = repo_row.get("artifact_repo_url") or ""
  app_clause = "AND a.id = :app_id" if app_id else ""
  rows = SELECT a.id AS app_id, a.name AS app_name, s.name AS system_name
         FROM system s JOIN system_application sa ON sa.system_id=s.id JOIN application a ON a.id=sa.application_id
         WHERE s.portfolio_id=:portfolio_id AND s.retired_at IS NULL {app_clause} ORDER BY s.name, a.name
  svc = _export_git_service(config, repo)        # GitService or None (None when no repo/token, governance.py:1079)
  apps = []
  for r in rows:
      aid = str(r["app_id"]); ev = AppEvidence(app_id=aid, app_name=r["app_name"] or aid, system_name=r["system_name"] or "system")
      if svc is not None:                         # best-effort read of committed .cato/{aid}/ artifacts (governance.py:1096)
          ev.ssp_json  = _read_cato_file(svc, f".cato/{aid}/ssp.json")
          ev.sar_json  = _read_cato_file(svc, f".cato/{aid}/sar.json")
          ev.poam_json = _read_cato_file(svc, f".cato/{aid}/poam.json")
      apps.append(ev)
  summary = {portfolio_id:str(...), application_count:len(apps), generated_at: utcnow().isoformat(), format}
  archive = build_evidence_zip(portfolio_id=str(portfolio_id), portfolio_summary=summary, apps=apps, fmt=format)   # src/services/evidence_export.py:152
  return Response(content=archive, media_type="application/zip", headers={Content-Disposition: ...})
  ```
  ⚠️ GOTCHA — `_read_cato_file(svc, path)` (governance.py:1096) reads `svc.read_file(path, branch="main").content`, returning `None` on `GitServiceError` (missing artifact). `_export_git_service` returns `None` when `repo`/`config.github_token` absent (so apps still appear but with empty SSP/SAR/POA&M). eMASS packaging is deferred (design §10.1). `build_evidence_zip`/`build_pdf_summary`/`AppEvidence` live in `src/services/evidence_export.py` (`AppEvidence`:19, `build_pdf_summary`:51, `build_evidence_zip`:152).

## A11. `POST /api/v1/governance/schedule` — `upsert_governance_schedule` (`governance.py:1235-1279`) — ⚠️ NEW at HEAD (P6-S8.6) — TEMPORAL SCHEDULE
- **Decorator**: `@router.post("/schedule", response_model=GovernanceScheduleResponse, status_code=201)`.
- **Auth:** `user = Depends(require_role(*MANAGER_PLUS))`. Extra deps `temporal=Depends(get_temporal_client)`, `db`.
- **Body:** `GovernanceScheduleRequest` (`governance.py:1214`): `portfolio_id: uuid.UUID`; `cadence: Literal["weekly","quarterly"]="weekly"`; `enabled: bool=True`.
- **Returns:** `GovernanceScheduleResponse` `{schedule_id, portfolio_id, cadence, enabled}`. Status 201; 403; 502 `TEMPORAL_SCHEDULE_FAILED`.
- **Handler logic:**
  ```
  await verify_portfolio_access(db, user, body.portfolio_id)
  config = get_config(); pid = str(body.portfolio_id)
  try:
      await create_governance_schedule(temporal, pid, cadence=body.cadence, task_queue=config.temporal_task_queue, paused=not body.enabled)
      if not body.enabled:
          await set_governance_schedule_paused(temporal, pid, cadence=body.cadence, paused=True)
  except Exception as exc:  # noqa: BLE001
      raise OlympusHTTPException(502,"TEMPORAL_SCHEDULE_FAILED", f"Failed to create governance schedule: {exc!r}")
  return GovernanceScheduleResponse(schedule_id=schedule_id_for(pid, body.cadence), portfolio_id=body.portfolio_id, cadence=body.cadence, enabled=body.enabled)
  ```
  ⚠️ GOTCHA — unlike the auto-create in `create_portfolio` (best-effort, swallows failures), THIS endpoint surfaces a Temporal failure as 502. `create_governance_schedule` is idempotent (`ScheduleAlreadyRunningError` swallowed). `schedule_id_for(pid, cadence) = f"gov-{cadence}-{pid}"`. `CADENCE_CRON = {weekly:"0 7 * * MON", quarterly:"0 7 1 */3 *"}` (`governance_schedule.py:28`). Functions imported from `src/services/governance_schedule.py` (`governance.py:52-57`).

## A12. `DELETE /api/v1/governance/schedule/{portfolio_id}` — `deregister_governance_schedule` (`governance.py:1282-1300`) — ⚠️ NEW at HEAD (P6-S8.6)
- **Decorator**: `@router.delete("/schedule/{portfolio_id}", status_code=204)`. Returns `Response(status_code=204)`.
- **Auth:** `user = Depends(require_role(*MANAGER_PLUS))`. Path `portfolio_id: uuid.UUID`; query `cadence: Literal["weekly","quarterly"]="weekly"`; deps `temporal`, `db`.
- **Handler logic:**
  ```
  await verify_portfolio_access(db, user, portfolio_id)
  await delete_governance_schedule(temporal, str(portfolio_id), cadence=cadence)   # best-effort: missing schedule treated as already-deregistered
  return Response(status_code=204)
  ```
  ⚠️ `delete_governance_schedule` (`governance_schedule.py:86`) is best-effort — `temporal.get_schedule_handle(sid).delete()` wrapped in `except Exception` → logs `governance_schedule_delete_failed` and returns (still 204). Called on portfolio delete / from portfolio settings.

---

# PART B — SYSTEMS ROUTER (`src/routers/systems.py`)

Router decl: `APIRouter(prefix="/api/v1", tags=["Systems"])` (`systems.py:64`).
Surfaces capability/system grain (SF1 M1-M19, SF3 S1-S11), migration 050. **No Temporal interaction.**

### B.0 Reviewer roles — `systems.py:54-62`
```
REVIEWER_ROLES = [TECH_LEAD, ARCH_LEAD, COMPLIANCE_LEAD, OPERATIONS_LEAD, SAFETY_BOARD, PORTFOLIO_MANAGER, PORTFOLIO_ADMIN]   # 7 roles (NO viewer, NO service)
```

### B.0.1 Pydantic models — `src/models/system.py` (shared literals at `:24-55`)
Literals: `SystemKind = "legacy"|"target"|"mixed"`; `SystemApplicationRole = "primary"|"contributing"|"deprecated"`; `CapabilityKind = "legacy"|"derived"|"net_new"`; `CapabilityDisposition = Retire|Retain|Refactor|Rearchitect|Replace|Replatform|Consolidate`; `LineageRelationship = "absorbed"|"partial"|"transformed"|"dropped"`; `SystemLineageRelationship = "consolidate"|"rearchitect-of"|"replace"|"retire"`.

- `SystemSummary` (`:63-71`): `id:UUID`, `portfolio_id:UUID`, `name:str`, `kind:SystemKind`, `external_id:str|None=None`, `description:str|None=None`.
- `SystemRead(SystemSummary)` (`:74-79`): + `created_at:datetime`, `updated_at:datetime`, `retired_at:datetime|None=None`.
- `SystemApplicationLink` (`:82-87`): `application_id:UUID`, `application_name:str`, `role:SystemApplicationRole`.
- `SystemDetail(SystemRead)` (`:90-95`): + `applications: list[SystemApplicationLink]=[]`, `capability_count:int=0`, `business_domain_count:int=0`.
- `CapabilitySummary` (`:103-114`): `id:UUID`, `system_id:UUID`, `system_external_id:str|None=None`, `system_name:str`, `name:str`, `external_id:str|None=None`, `kind:CapabilityKind`, `primary_disposition:CapabilityDisposition|None=None`, `secondary_disposition:CapabilityDisposition|None=None`.
- `CapabilityRead(CapabilitySummary)` (`:117-123`): + `description:str|None=None`, `created_at:datetime`, `updated_at:datetime`, `retired_at:datetime|None=None`.
- `CapabilityLineageEdge` (`:126-145`): `id:UUID`, `target_capability_id:UUID|None=None`, `target_capability_name:str|None=None`, `target_capability_external_id:str|None=None`, `target_system_external_id:str|None=None`, `source_capability_id:UUID`, `source_capability_name:str`, `source_capability_external_id:str|None=None`, `source_system_external_id:str|None=None`, `relationship:LineageRelationship`, `notes:str|None=None`, `confidence:Decimal|None=None`, `agent_emitted:bool`, `ratified_by:str|None=None`, `ratified_at:datetime|None=None`, `created_at:datetime`.
- `CapabilityLineageView` (`:148-167`): `capability_id:UUID`, `sources: list[CapabilityLineageEdge]=[]` (edges where this cap is **target**), `targets: list[CapabilityLineageEdge]=[]` (edges where this cap is **source**).
- `BusinessDomainSummary` (`:175-181`): `id:UUID`, `system_id:UUID`, `name:str`, `external_id:str|None=None`.
- `SystemLineageEdge` (`:198-208`): `target_system_id:UUID`, `target_system_name:str`, `target_system_external_id:str|None=None`, `source_system_id:UUID`, `source_system_name:str`, `source_system_external_id:str|None=None`, `relationship:SystemLineageRelationship`, `created_at:datetime`.
- `SystemLineageView` (`:211-216`): `system_id:UUID`, `sources: list[SystemLineageEdge]=[]`, `targets: list[SystemLineageEdge]=[]`.
- `CapabilityLineageRatifyRequest` (`:224-245`): `notes: str|None=Field(default=None)`.
- `CapabilityLineageRejectRequest` (`:248-268`): `feedback: str=Field(min_length=1)` (⚠️ required, non-empty → empty string yields 422).
- `CapabilityLineageRowView` (`:310-338`): `id:UUID`, `target_capability_id:UUID|None=None`, `target_capability_name:str|None=None`, `target_capability_external_id:str|None=None`, `target_system_id:UUID|None=None`, `target_system_name:str|None=None`, `target_system_external_id:str|None=None`, `source_capability_id:UUID`, `source_capability_name:str`, `source_capability_external_id:str|None=None`, `source_system_id:UUID`, `source_system_name:str`, `source_system_external_id:str|None=None`, `relationship:LineageRelationship`, `notes:str|None=None`, `confidence:Decimal|None=None`, `agent_emitted:bool`, `ratified_by:str|None=None`, `ratified_at:datetime|None=None`, `created_at:datetime`.
- `WaveCapabilityLineageView` (`:341-352`): `wave_id:UUID`, `rows: list[CapabilityLineageRowView]=[]`.
- `SystemComplianceEntry` (`:360-395`): `system_id:UUID`, `system_name:str`, `system_external_id:str|None=None`, `system_kind:SystemKind`, `application_count:int=0`, `compliant_count:int=0`, `needs_review_count:int=0`, `unknown_count:int=0`, `cato_certified_count:int=0`, `status:Literal["compliant","needs-review","unknown"]`, `ratified_capability_count:int=Field(default=0)`.
- `PortfolioComplianceRollup` (`:398-414`): `portfolio_id:UUID`, `systems: list[SystemComplianceEntry]=[]`, `totals: dict=default_factory(dict)`.
- (Defined but UNUSED by these routers: `CapabilityLineageRowDecision` `:271-307`, `BusinessDomainRead` `:184-190`.)

---

## B1. `GET /api/v1/systems` — `list_systems` (`systems.py:67-77`)
- **Decorator**: `@router.get("/systems", response_model=list[SystemSummary])`.
- **Query**: `portfolio_id: uuid.UUID = Query(..., description="Portfolio scoping the systems list — required.")` (**required**).
- **Deps**: `user = Depends(get_current_user)`; `db`. ⚠️ No `require_role` — any authenticated user; access enforced by `verify_portfolio_access` (403 if not member, admin bypass).
- **Response**: `list[SystemSummary]`. **Status 200**.
- **Logic**: `await verify_portfolio_access(db, user, portfolio_id); return await system_service.list_systems(db, portfolio_id)`.
- **Service** `list_systems` (`services/system.py:48-65`): `SELECT id, portfolio_id, name, kind, external_id, description FROM system WHERE portfolio_id=:portfolio_id AND retired_at IS NULL ORDER BY kind ASC, COALESCE(external_id, name) ASC` → `[SystemSummary(**dict(r)) ...]`.

## B2. `GET /api/v1/systems/{system_id}` — `get_system` (`systems.py:80-89`)
- **Decorator**: `@router.get("/systems/{system_id}", response_model=SystemDetail, dependencies=[Depends(require_system_member)])`.
- **Path**: `system_id: uuid.UUID`. **Deps**: route-level `require_system_member` (membership + 404 "System not found" if absent for non-admin); `db`. No handler-level user param.
- **Response**: `SystemDetail`. **Status 200**.
- **Logic**: `return await system_service.get_system(db, system_id)`.
- **Service** `get_system` (`services/system.py:68-133`): fetch `SELECT id,portfolio_id,name,kind,external_id,description,created_at,updated_at,retired_at FROM system WHERE id=:id AND retired_at IS NULL` → if `None` raise `OlympusHTTPException(404,"SYSTEM_NOT_FOUND", f"System {system_id} not found")`. Then realizing apps `SELECT sa.application_id, a.name AS application_name, sa.role FROM system_application sa JOIN application a ON a.id=sa.application_id WHERE sa.system_id=:system_id ORDER BY sa.role ASC, a.name ASC`. `capability_count = COUNT(*) FROM capability WHERE system_id=:system_id AND retired_at IS NULL`; `domain_count = COUNT(*) FROM business_domain WHERE system_id=:system_id AND retired_at IS NULL`. Returns `SystemDetail(**dict(sys_row), applications=[SystemApplicationLink(**dict(r)) ...], capability_count=int(...or 0), business_domain_count=int(...or 0))`.

## B3. `GET /api/v1/systems/{system_id}/capabilities` — `list_capabilities_for_system` (`systems.py:92-101`)
- **Decorator**: `@router.get("/systems/{system_id}/capabilities", response_model=list[CapabilitySummary], dependencies=[Depends(require_system_member)])`.
- **Path**: `system_id: uuid.UUID`; **Deps**: route-level `require_system_member`; `db`.
- **Response**: `list[CapabilitySummary]`. **Status 200**.
- **Logic**: `return await system_service.list_capabilities_for_system(db, system_id)`.
- **Service** (`services/system.py:141-185`): first `SELECT id,name,external_id FROM system WHERE id=:id AND retired_at IS NULL` → `None` raises 404 `SYSTEM_NOT_FOUND`. Then `SELECT c.id, c.system_id, :system_name AS system_name, :system_external_id AS system_external_id, c.name, c.external_id, c.kind, c.primary_disposition, c.secondary_disposition FROM capability c WHERE c.system_id=:system_id AND c.retired_at IS NULL ORDER BY COALESCE(c.external_id, c.name) ASC` (system name/external_id bound from prior row) → `[CapabilitySummary(**dict(r)) ...]`.

## B4. `GET /api/v1/systems/{system_id}/business-domains` — `list_business_domains_for_system` (`systems.py:104-113`)
- **Decorator**: `@router.get("/systems/{system_id}/business-domains", response_model=list[BusinessDomainSummary], dependencies=[Depends(require_system_member)])`.
- **Path**: `system_id`; **Deps**: route-level `require_system_member`; `db`.
- **Response**: `list[BusinessDomainSummary]`. **Status 200**.
- **Service** (`services/system.py:321-351`): `SELECT 1 FROM system WHERE id=:id AND retired_at IS NULL` → `None` raises 404 `SYSTEM_NOT_FOUND`. Then `SELECT id, system_id, name, external_id FROM business_domain WHERE system_id=:system_id AND retired_at IS NULL ORDER BY COALESCE(external_id, name) ASC` → `[BusinessDomainSummary(**dict(r)) ...]`.

## B5. `GET /api/v1/systems/{system_id}/lineage` — `get_system_lineage` (`systems.py:116-123`)
- **Decorator**: `@router.get("/systems/{system_id}/lineage", response_model=SystemLineageView, dependencies=[Depends(require_system_member)])`.
- **Path**: `system_id`; **Deps**: route-level `require_system_member`; `db`.
- **Response**: `SystemLineageView`. **Status 200**.
- **Service** `get_system_lineage` (`services/system.py:359-421`): `SELECT 1 FROM system WHERE id=:id` (⚠️ no `retired_at` filter here) → `None` raises 404 `SYSTEM_NOT_FOUND`. `edge_select` projects `sl.target_system_id, ts.name AS target_system_name, ts.external_id AS target_system_external_id, sl.source_system_id, ss.name AS source_system_name, ss.external_id AS source_system_external_id, sl.relationship, sl.created_at`. **sources** = `FROM system_lineage sl JOIN system ts ON ts.id=sl.target_system_id JOIN system ss ON ss.id=sl.source_system_id WHERE sl.target_system_id=:id AND sl.retired_at IS NULL ORDER BY sl.created_at ASC`. **targets** = same but `WHERE sl.source_system_id=:id AND sl.retired_at IS NULL`. Returns `SystemLineageView(system_id, sources=[SystemLineageEdge(**dict(r))...], targets=[...])`.

## B6. `GET /api/v1/capabilities/{capability_id}` — `get_capability` (`systems.py:126-135`)
- **Decorator**: `@router.get("/capabilities/{capability_id}", response_model=CapabilityRead, dependencies=[Depends(require_capability_member)])`.
- **Path**: `capability_id: uuid.UUID`; **Deps**: route-level `require_capability_member` (membership via capability→system; 404 "Capability not found" if absent for non-admin); `db`.
- **Response**: `CapabilityRead`. **Status 200**.
- **Service** `get_capability` (`services/system.py:188-224`): `SELECT c.id, c.system_id, s.name AS system_name, s.external_id AS system_external_id, c.name, c.description, c.external_id, c.kind, c.primary_disposition, c.secondary_disposition, c.created_at, c.updated_at, c.retired_at FROM capability c JOIN system s ON s.id=c.system_id WHERE c.id=:id AND c.retired_at IS NULL` → `None` raises `OlympusHTTPException(404,"CAPABILITY_NOT_FOUND", f"Capability {capability_id} not found")`. Returns `CapabilityRead(**dict(row))`.

## B7. `GET /api/v1/capabilities/{capability_id}/lineage` — `get_capability_lineage` (`systems.py:138-147`)
- **Decorator**: `@router.get("/capabilities/{capability_id}/lineage", response_model=CapabilityLineageView, dependencies=[Depends(require_capability_member)])`.
- **Path**: `capability_id`; **Deps**: route-level `require_capability_member`; `db`.
- **Response**: `CapabilityLineageView`. **Status 200**.
- **Service** `get_capability_lineage` (`services/system.py:227-313`): `SELECT 1 FROM capability WHERE id=:id` → `None` raises 404 `CAPABILITY_NOT_FOUND`. `edge_select` projects `cl.id, cl.target_capability_id, tc.name AS target_capability_name, tc.external_id AS target_capability_external_id, ts.external_id AS target_system_external_id, cl.source_capability_id, sc.name AS source_capability_name, sc.external_id AS source_capability_external_id, ss.external_id AS source_system_external_id, cl.relationship, cl.notes, cl.confidence, cl.agent_emitted, cl.ratified_by, cl.ratified_at, cl.created_at`. **sources** (this cap is target): `FROM capability_lineage cl LEFT JOIN capability tc ON tc.id=cl.target_capability_id LEFT JOIN system ts ON ts.id=tc.system_id JOIN capability sc ON sc.id=cl.source_capability_id JOIN system ss ON ss.id=sc.system_id WHERE cl.target_capability_id=:id AND cl.retired_at IS NULL ORDER BY cl.created_at ASC`. **targets** (this cap is source): same joins, `WHERE cl.source_capability_id=:id AND cl.retired_at IS NULL`. Returns `CapabilityLineageView(capability_id, sources=[CapabilityLineageEdge(**dict(r))...], targets=[...])`.

## B8. `GET /api/v1/capability-lineage/{lineage_id}` — `get_capability_lineage_row` (`systems.py:155-165`)
- **Decorator**: `@router.get("/capability-lineage/{lineage_id}", response_model=CapabilityLineageRowView, dependencies=[Depends(require_capability_lineage_member)])`.
- **Path**: `lineage_id: uuid.UUID`; **Deps**: route-level `require_capability_lineage_member`; `db`.
- **Response**: `CapabilityLineageRowView`. **Status 200**.
- **Logic**: `return await system_service.get_lineage_row(db, lineage_id)`.
- **Service** `get_lineage_row` (`services/system.py:581-586`) → `_get_lineage_row_or_404`.

### B8-shared. `_get_lineage_row_or_404` + `_LINEAGE_ROW_SELECT` (`services/system.py:431-486`)
`_LINEAGE_ROW_SELECT` projects: `cl.id, cl.target_capability_id, tc.name AS target_capability_name, tc.external_id AS target_capability_external_id, tc.system_id AS target_system_id, ts.name AS target_system_name, ts.external_id AS target_system_external_id, cl.source_capability_id, sc.name AS source_capability_name, sc.external_id AS source_capability_external_id, sc.system_id AS source_system_id, ss.name AS source_system_name, ss.external_id AS source_system_external_id, cl.relationship, cl.notes, cl.confidence, cl.agent_emitted, cl.ratified_by, cl.ratified_at, cl.created_at`.
```
row = (SELECT {_LINEAGE_ROW_SELECT}
       FROM capability_lineage cl
       LEFT JOIN capability tc ON tc.id = cl.target_capability_id
       LEFT JOIN system     ts ON ts.id = tc.system_id
       JOIN capability sc ON sc.id = cl.source_capability_id
       JOIN system     ss ON ss.id = sc.system_id
       WHERE cl.id = :id AND cl.retired_at IS NULL).mappings().first()
if row is None: raise OlympusHTTPException(404,"CAPABILITY_LINEAGE_NOT_FOUND", f"capability_lineage row {lineage_id} not found")
return dict(row)
```
`_row_view(row) = CapabilityLineageRowView(**row)` (`:485-486`).

## B9. `POST /api/v1/capability-lineage/{lineage_id}/ratify` — `ratify_capability_lineage_row` (`systems.py:168-193`)
- **Decorator**: `@router.post("/capability-lineage/{lineage_id}/ratify", response_model=CapabilityLineageRowView, dependencies=[Depends(require_capability_lineage_member)])`.
- **Path**: `lineage_id`. **Body**: `body: CapabilityLineageRatifyRequest | None = None` (⚠️ **optional body** — request with no body is valid; `notes` defaults `None`).
- **Deps**: route-level `require_capability_lineage_member` AND handler `user = Depends(require_role(*REVIEWER_ROLES))`; `db`. ⚠️ DUAL gate: membership AND reviewer role.
- **Response**: `CapabilityLineageRowView`. **Status 200**.
- **Handler logic**: `notes = body.notes if body else None; return await system_service.ratify_capability_lineage_row(db, lineage_id, user.sub, notes)`.
- **Service** `ratify_capability_lineage_row` (`services/system.py:489-531`) — reproduce exactly:
```
row = await _get_lineage_row_or_404(db, lineage_id)          # 404 if absent/retired
now = datetime.now(timezone.utc)
new_notes = row.get("notes")
if notes:
    prefix = f"[APPROVED by {ratified_by} at {now.isoformat()}] "
    addition = prefix + notes
    new_notes = f"{new_notes}\n{addition}" if new_notes else addition
UPDATE capability_lineage SET ratified_by=:by, ratified_at=:now, notes=:notes WHERE id=:id
    -- params {"by": ratified_by, "now": now, "notes": new_notes, "id": lineage_id}
db.commit()
row["ratified_by"]=ratified_by; row["ratified_at"]=now; row["notes"]=new_notes
return _row_view(row)
```
⚠️ GOTCHAS: (1) NOT idempotent on storage — re-ratify by a different reviewer overwrites `ratified_by`/`ratified_at` to latest (the docstring's "409 if already ratified by a different reviewer" in the request model `:230-231` is **NOT implemented** — code accepts and overwrites). (2) When `notes` is falsy, the `notes` column is set to its prior value (unchanged), NOT cleared.

## B10. `POST /api/v1/capability-lineage/{lineage_id}/reject` — `reject_capability_lineage_row` (`systems.py:196-221`)
- **Decorator**: `@router.post("/capability-lineage/{lineage_id}/reject", response_model=CapabilityLineageRowView, dependencies=[Depends(require_capability_lineage_member)])`.
- **Path**: `lineage_id`. **Body**: `body: CapabilityLineageRejectRequest` (**required**, `feedback` min_length=1 → 422 if missing/empty).
- **Deps**: route-level `require_capability_lineage_member` AND handler `user = Depends(require_role(*REVIEWER_ROLES))`; `db`.
- **Response**: `CapabilityLineageRowView`. **Status 200**.
- **Handler**: `return await system_service.reject_capability_lineage_row(db, lineage_id, user.sub, body.feedback)`.
- **Service** `reject_capability_lineage_row` (`services/system.py:534-578`) — reproduce exactly:
```
row = await _get_lineage_row_or_404(db, lineage_id)          # 404 if absent/retired
now = datetime.now(timezone.utc)
prefix = f"[REJECTED by {rejected_by} at {now.isoformat()}] "
addition = prefix + feedback
new_notes = f"{row.get('notes')}\n{addition}" if row.get("notes") else addition
UPDATE capability_lineage SET ratified_by=NULL, ratified_at=NULL, notes=:notes WHERE id=:id
    -- params {"notes": new_notes, "id": lineage_id}
db.commit()
row["ratified_by"]=None; row["ratified_at"]=None; row["notes"]=new_notes
return _row_view(row)
```
⚠️ GOTCHAS: (1) Reject **always clears** any prior `ratified_by`/`ratified_at` (course-correction). (2) Appends `[REJECTED ...]` to existing notes (accumulates across rejections). (3) Service does NOT forward feedback to any agent/workflow — purely a DB write (no Temporal signal). (4) `body.feedback` empty string → 422 at validation (never reaches service).

## B11. `GET /api/v1/waves/{wave_id}/capability-lineage` — `list_wave_capability_lineage` (`systems.py:224-239`)
- **Decorator**: `@router.get("/waves/{wave_id}/capability-lineage", response_model=WaveCapabilityLineageView, dependencies=[Depends(require_wave_member)])`.
- **Path**: `wave_id: uuid.UUID`; **Deps**: route-level `require_wave_member` (membership via wave→portfolio; 404 "Wave not found" if absent for non-admin); `db`.
- **Response**: `WaveCapabilityLineageView`. **Status 200**.
- **Service** `list_wave_capability_lineage` (`services/system.py:589-639`) — scope via `system_application` + `wave_application`:
```
rows = SELECT {_LINEAGE_ROW_SELECT}
       FROM capability_lineage cl
       LEFT JOIN capability tc ON tc.id = cl.target_capability_id
       LEFT JOIN system     ts ON ts.id = tc.system_id
       JOIN capability sc ON sc.id = cl.source_capability_id
       JOIN system     ss ON ss.id = sc.system_id
       WHERE cl.retired_at IS NULL
         AND ( tc.system_id IN (SELECT sa.system_id FROM system_application sa
                                JOIN wave_application wa ON wa.application_id = sa.application_id
                                WHERE wa.wave_id = :wave_id)
            OR sc.system_id IN (SELECT sa.system_id FROM system_application sa
                                JOIN wave_application wa ON wa.application_id = sa.application_id
                                WHERE wa.wave_id = :wave_id) )
       ORDER BY cl.created_at ASC
return WaveCapabilityLineageView(wave_id=wave_id, rows=[_row_view(dict(r)) for r in rows])
```
⚠️ No 404 for empty wave — returns empty `rows[]`. Row included if EITHER source OR target capability's system has ≥1 app in the wave.

## B12. `GET /api/v1/portfolios/{portfolio_id}/compliance/system-rollup` — `get_portfolio_compliance_system_rollup` (`systems.py:247-267`)
- **Decorator**: `@router.get("/portfolios/{portfolio_id}/compliance/system-rollup", response_model=PortfolioComplianceRollup)`.
- **Path**: `portfolio_id: uuid.UUID`. **Deps**: `user = Depends(get_current_user)`; `db`. ⚠️ No `require_role`, no route-level dep — access via `verify_portfolio_access` in handler.
- **Response**: `PortfolioComplianceRollup`. **Status 200**.
- **Handler**: `await verify_portfolio_access(db, user, portfolio_id); return await system_service.get_portfolio_compliance_rollup(db, portfolio_id)`.

### B12.1 Service helpers
`_classify_compliance_status(meta) -> str` (`services/system.py:647-671`):
```
if not meta: return "unknown"
comp = meta.get("compliance") if isinstance(meta, dict) else None
if not isinstance(comp, dict): return "unknown"
raw = comp.get("status")
if not isinstance(raw, str) or not raw: return "unknown"
lowered = raw.lower()
if any(t in lowered for t in ("compliant","pass","certified")): return "compliant"
if any(t in lowered for t in ("review","advisory","pending","fail","violation")): return "needs-review"
return "unknown"
```
`_is_cato_certified(meta) -> bool` (`:674-680`): `isinstance(meta,dict)` AND `meta["compliance"]` is dict AND `bool(comp.get("certified") or comp.get("cato_certified"))`.

### B12.2 Service `get_portfolio_compliance_rollup` (`services/system.py:683-857`) — reproduce EVERY branch:
```
exists = (SELECT 1 FROM portfolio WHERE id=:id).first()
if exists is None: raise OlympusHTTPException(404,"PORTFOLIO_NOT_FOUND", f"Portfolio {portfolio_id} not found")

rows = SELECT s.id AS system_id, s.name AS system_name, s.external_id AS system_external_id,
              s.kind AS system_kind, a.id AS application_id, a.metadata AS application_metadata
       FROM system s
       LEFT JOIN system_application sa ON sa.system_id = s.id
       LEFT JOIN application a ON a.id = sa.application_id
       WHERE s.portfolio_id=:portfolio_id AND s.retired_at IS NULL
       ORDER BY s.kind ASC, COALESCE(s.external_id, s.name) ASC

ratified_rows = SELECT tc.system_id AS system_id, COUNT(*) AS ratified_count
                FROM capability_lineage cl
                JOIN capability tc ON tc.id = cl.target_capability_id
                JOIN system s ON s.id = tc.system_id
                WHERE cl.retired_at IS NULL AND cl.ratified_at IS NOT NULL
                  AND s.portfolio_id=:portfolio_id
                GROUP BY tc.system_id
ratified_counts = { r["system_id"]: int(r["ratified_count"]) for r in ratified_rows }
                  # ⚠️ rows with target_capability_id NULL (relationship 'dropped') excluded by the INNER JOIN

# --- aggregate per system ---
by_system = {}
for r in rows:
    sid = r["system_id"]
    bucket = by_system.setdefault(sid, {
        "system_id":sid, "system_name":r["system_name"], "system_external_id":r["system_external_id"],
        "system_kind":r["system_kind"], "application_count":0, "compliant_count":0,
        "needs_review_count":0, "unknown_count":0, "cato_certified_count":0 })
    if r["application_id"] is None:   # system with no realizing app — keep bucket, skip
        continue
    bucket["application_count"] += 1
    meta = r["application_metadata"] or {}
    status = _classify_compliance_status(meta)
    if   status == "compliant":    bucket["compliant_count"] += 1
    elif status == "needs-review": bucket["needs_review_count"] += 1
    else:                          bucket["unknown_count"] += 1
    if _is_cato_certified(meta):   bucket["cato_certified_count"] += 1

# --- per-system status precedence ---
entries = []
for sid, bucket in by_system.items():
    if bucket["needs_review_count"] > 0:                                  status="needs-review"
    elif bucket["compliant_count"] > 0 and bucket["unknown_count"] == 0:  status="compliant"
    elif bucket["compliant_count"] > 0:                                   status="needs-review"  # mixed compliant+unknown → needs-review
    else:                                                                 status="unknown"
    entries.append(SystemComplianceEntry(
        system_id=bucket["system_id"], system_name=bucket["system_name"],
        system_external_id=bucket["system_external_id"], system_kind=bucket["system_kind"],
        application_count=bucket["application_count"], compliant_count=bucket["compliant_count"],
        needs_review_count=bucket["needs_review_count"], unknown_count=bucket["unknown_count"],
        cato_certified_count=bucket["cato_certified_count"], status=status,
        ratified_capability_count=ratified_counts.get(sid, 0)))

totals = {
    "system_count": len(entries),
    "application_count": sum(e.application_count for e in entries),
    "compliant": sum(e.compliant_count for e in entries),
    "needs_review": sum(e.needs_review_count for e in entries),
    "unknown": sum(e.unknown_count for e in entries),
    "cato_certified": sum(e.cato_certified_count for e in entries),
    "ratified_capabilities": sum(e.ratified_capability_count for e in entries) }
return PortfolioComplianceRollup(portfolio_id=portfolio_id, systems=entries, totals=totals)
```
⚠️ GOTCHAS: (1) Status precedence: needs-review > (compliant & no unknown) > (compliant & some unknown → needs-review) > unknown. So ANY needs-review app, OR any unknown app alongside compliant apps, forces system to `needs-review`. (2) System with zero apps → `unknown`. (3) `totals` is a plain `dict` with EXACTLY these 7 keys (no `pydantic` model). (4) `ratified_capability_count` keyed on TARGET system only; `dropped` lineage (null target) never counted.

---

## ENDPOINT COUNT VERIFICATION (gate)
**Governance = 12** at HEAD (was 9): A1 health-checks, A2 health-checks/latest, A3 drift-alerts, A4 drift-alerts/{id}/acknowledge, A5 patterns, A6 patterns/{id}, A7 sweep, A8 sweeps, A9 portfolios/{id}/cato-evidence, **A10 portfolios/{id}/compliance-evidence-export ⚠️NEW, A11 POST schedule ⚠️NEW, A12 DELETE schedule/{portfolio_id} ⚠️NEW**.
**Systems = 12**: B1 systems, B2 systems/{id}, B3 systems/{id}/capabilities, B4 systems/{id}/business-domains, B5 systems/{id}/lineage, B6 capabilities/{id}, B7 capabilities/{id}/lineage, B8 capability-lineage/{id}, B9 capability-lineage/{id}/ratify, B10 capability-lineage/{id}/reject, B11 waves/{id}/capability-lineage, B12 portfolios/{id}/compliance/system-rollup.

## CROSS-CUTTING GOTCHAS
- ⚠️ Router mount order: both routers documented in file/decorator order above; within FastAPI, more-specific literal paths must mount before parameterized — both files already declare them in a non-conflicting order. Governance's `cato-evidence` lives under the `/api/v1/governance` prefix despite its `/portfolios/...` decorator path.
- ⚠️ `require_role(...)` raises plain `HTTPException` (envelope code `FORBIDDEN`); `verify_portfolio_access` raises `HTTPException` with a **dict** detail (`{"code":"PORTFOLIO_NOT_MEMBER",...}`) → handler stringifies it into `message`, envelope code stays `FORBIDDEN`. `OlympusHTTPException` preserves the custom `code` (e.g. `SYSTEM_NOT_FOUND`).
- ⚠️ Governance list endpoints (A1/A3/A5/A8) tolerate missing tables (→ empty); the single-row fetch endpoints (A4 acknowledge, A6 get_pattern) do NOT and will 500 on a missing table.
- ⚠️ Every service `commit()` is in the service layer (ratify/reject/acknowledge), not the handler.
