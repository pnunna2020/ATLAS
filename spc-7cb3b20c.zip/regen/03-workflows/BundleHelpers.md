# `BundleAwareMixin` (bundle_helpers) — Delegated-Bundle Await/Signal Mixin (ATOMIC regeneration spec)

> **Source of truth:** `temporal/olympus_workflows/workflows/bundle_helpers.py` (191 lines).
> Every `bundle_helpers.py:line` citation below is against that file.
>
> **What this is:** a **workflow mixin** — NOT a `@workflow.defn` class, NOT a router, NOT a
> standalone workflow. It bundles the signal-handler + `wait_condition` wiring that any workflow
> dispatching a *delegated bundle* (Phase 5 W20 chunk D) needs, so that pattern lives in ONE place
> instead of being copy-pasted into every bundle-integrating workflow (`bundle_helpers.py:12-20`).
> Workflows **opt in** by adding `BundleAwareMixin` to their base list, e.g.
> `class MyWorkflow(BundleAwareMixin)` or alongside `HILSignalsMixin` /`LineWorkflowBase`
> (`bundle_helpers.py:14-16, 27`).
>
> **Inherits / mixes:** nothing of its own — it is a leaf mixin whose `__init__` only calls
> `super().__init__()` (`bundle_helpers.py:90`) and then sets three dicts. It is designed to be
> **mixed in alongside** `HILSignalsMixin` (see `_HILSignalsMixin.md`) and/or `LineWorkflowBase`
> (see `_LineWorkflowBase.md`); it does NOT subclass either. The `super().__init__()` it calls is
> the cooperative-MRO hand-off that lets `HILSignalsMixin.__init__` / `LineWorkflowBase.__init__`
> still run (GOTCHA-INIT1 below).
>
> **Relationship to the base specs:** this mixin adds a *fourth+fifth* `@workflow.signal`
> (`bundle_completed`, `bundle_expired`) and *two* `@workflow.query` handlers (`get_bundle_outcome`,
> `get_bundle_outputs`) to whatever workflow mixes it in — these are **additive** and **distinct
> in name** from the four base gate signals (`gate_approved`/`gate_rejected`/`escalation_resolved`/
> `merge_retry`) and the base `get_status` query specified in `_LineWorkflowBase.md` §3/§16, and
> distinct from the six HIL signals in `_HILSignalsMixin.md` §2. There is NO name collision; a
> workflow can carry ALL of them simultaneously. This mixin does NOT override any base/HIL method.
>
> **Module-level constant:** `BundleOutcome = Literal["accepted", "rejected", "expired",
> "released", "timeout"]` (`bundle_helpers.py:65`) — the closed return-value set of
> `await_bundle_completion`. A rebuild MUST treat these five strings as the only legal outcomes.
>
> **Determinism note:** every method is either a synchronous attribute mutation (signal handlers
> are `async def` but contain no `await`, no `workflow.now()`, no I/O) or a single
> `workflow.wait_condition` with a Temporal timer. NO wall-clock, NO random, NO external I/O. The
> only time-bearing primitive is the `timeout=timedelta(seconds=...)` on the wait_condition, which
> Temporal converts to a durable timer (deterministic under replay).

---

## 0. Imports & module shape (`bundle_helpers.py:52-65`)

```text
from __future__ import annotations                       # bundle_helpers.py:52
from typing import Literal                                # bundle_helpers.py:54
from temporalio import workflow                           # bundle_helpers.py:56

with workflow.unsafe.imports_passed_through():            # bundle_helpers.py:58
    from olympus_workflows.types import (
        BundleCompletedSignal,                            # bundle_helpers.py:60
        BundleExpiredSignal,                              # bundle_helpers.py:61
    )

BundleOutcome = Literal["accepted", "rejected", "expired", "released", "timeout"]  # :65
```

- ⚠️ **GOTCHA-IMP1 (signal-type imports MUST be inside `imports_passed_through()`):** the two
  dataclass imports are gated behind `with workflow.unsafe.imports_passed_through():`
  (`bundle_helpers.py:58`) — same rule as `_LineWorkflowBase.md` §0 GOTCHA-IMPORTS. A rebuild that
  hoists them to module top risks Temporal-sandbox re-import/nondeterminism. `from __future__
  import annotations` (`:52`) makes the `dict[str, str]` etc. annotations lazy strings, so they do
  not force eager evaluation at class-body time.
- The mixin imports **no activities** and **no `RETRY_POLICIES`** — it dispatches **zero
  activities** and **zero child workflows**. All state transitions come from inbound *signals*
  fired by OTHER components (see §7). This is the single most important structural fact: there is
  nothing to retry, no timeout policy, no `non_retryable_errors` here — only signal buffering and a
  `wait_condition`.

### 0.1 The two inbound signal payload dataclasses (defined in `types.py`, NOT here)

Sourced from `temporal/olympus_workflows/types.py:357-385`. Reproduced so a rebuild can construct
identical payloads:

```text
@dataclass
class BundleCompletedSignal:                # types.py:357
    bundle_id: str                          # types.py:367
    outcome: str                            # types.py:368   'accepted' | 'rejected'
    outputs: dict[str, str] = field(default_factory=dict)   # types.py:369  artifact_kind → artifact_ref
    validation_summary: str = ""            # types.py:370   short audit string

@dataclass
class BundleExpiredSignal:                   # types.py:373
    bundle_id: str                           # types.py:384
    reason: str = "expired"                  # types.py:385
```

- ⚠️ **GOTCHA-PAY1 (`outcome`/`reason` are free-form `str`, not enums):** both carry plain strings
  (`types.py:368, 385`); the mixin is responsible for normalizing/validating them (it does — see
  §2/§3). A rebuild MUST keep them as `str` with `outputs` and `validation_summary` having the
  documented defaults (`{}` via `field(default_factory=dict)`, and `""`), because the
  `bundle_completed` handler reads `signal.outputs` / `signal.validation_summary` and would
  `AttributeError` if a sender omitted them and they had no default.

---

## 1. STATE — every instance var in `__init__` (`bundle_helpers.py:84-93`)

```text
def __init__(self) -> None:
    super().__init__()                                          # bundle_helpers.py:90
    self._bundle_outcomes: dict[str, str] = {}                  # bundle_helpers.py:91
    self._bundle_outputs: dict[str, dict[str, str]] = {}        # bundle_helpers.py:92
    self._bundle_validation_summaries: dict[str, str] = {}      # bundle_helpers.py:93
```

| Var | Type | Initial | Line | Mutated by → value | When |
|-----|------|---------|------|---------------------|------|
| `_bundle_outcomes` | `dict[str, str]` | `{}` | 91 | `bundle_completed` → `[bundle_id]=outcome` (`:112`); `bundle_expired` → `[bundle_id]=reason` (`:134`) | on inbound signal; **read by** `await_bundle_completion` predicate (`:165`), result read (`:170`), and `get_bundle_outcome` query (`:185`) |
| `_bundle_outputs` | `dict[str, dict[str, str]]` | `{}` | 92 | `bundle_completed` → `[bundle_id]=dict(signal.outputs)` ONLY if `signal.outputs` truthy (`:113-114`) | on `accepted`/`rejected` signal **with** non-empty outputs; **read by** `get_bundle_outputs` query (`:190`) and by callers as gate evidence (docstring `:45`, `:78`) |
| `_bundle_validation_summaries` | `dict[str, str]` | `{}` | 93 | `bundle_completed` → `[bundle_id]=signal.validation_summary` ONLY if truthy (`:115-118`) | on signal **with** non-empty summary; read for failure narratives (docstring `:80-82`) — never read inside this module |

> ⚠️ **GOTCHA-INIT1 (`super().__init__()` FIRST, then set dicts — and do NOT reset on re-entry):**
> `__init__` calls `super().__init__()` as its first statement (`bundle_helpers.py:90`) so that in a
> multi-base workflow (`class W(BundleAwareMixin, HILSignalsMixin, LineWorkflowBase)`) the
> downstream `__init__`s run via the MRO. The docstring (`:84-89`) explicitly notes that because
> all three dicts are *local* (no reliance on superclass state) the order is safe, and "If the
> consuming workflow calls super().__init__() (e.g. HILSignalsMixin) the dict attributes are kept
> since this initializer doesn't reset them." A rebuild MUST: (a) call `super().__init__()` first,
> (b) initialize the three dicts to **fresh empty** dicts AFTER it, (c) NOT guard with `if not
> hasattr(...)` — the dicts are unconditionally `{}` at construction. (Tested implicitly:
> `test_bundle_completed_records_accepted` constructs `_W(BundleAwareMixin)` with no other base and
> the dicts exist —`test_bundle_activities.py:463-477`.)
> ⚠️ **GOTCHA-INIT2 (three dicts, all `bundle_id`-keyed, independent lifecycles):** `_bundle_outputs`
> and `_bundle_validation_summaries` are populated ONLY conditionally (only on a signal that carries
> them), whereas `_bundle_outcomes` is the authoritative terminal-state map and is set on EVERY
> accepted/rejected/expired/released signal that passes the empty-string guard. A rebuild MUST NOT
> assume a `bundle_id` present in `_bundle_outcomes` is also in `_bundle_outputs`. The
> `get_bundle_outputs` query is built to return `{}` for that exact gap (`:190`).

---

## 2. SIGNAL HANDLER — `bundle_completed(self, signal: BundleCompletedSignal) -> None` (`bundle_helpers.py:99-118`)

Fired by the **API service layer** when a bundle reaches `accepted` via `POST /bundles/{id}/submit`
(types.py:337-343; see §7). `@workflow.signal`, `async def` (no `await` inside — async only for
signature symmetry with the base async signals).

```text
@workflow.signal
async def bundle_completed(self, signal):
    outcome = (signal.outcome or "").strip().lower()      # bundle_helpers.py:109
    if not outcome:                                       # bundle_helpers.py:110  BRANCH 1
        return                                            # bundle_helpers.py:111  ← empty outcome → IGNORE signal
    self._bundle_outcomes[signal.bundle_id] = outcome     # bundle_helpers.py:112
    if signal.outputs:                                    # bundle_helpers.py:113  BRANCH 2
        self._bundle_outputs[signal.bundle_id] = dict(signal.outputs)   # bundle_helpers.py:114
    if signal.validation_summary:                         # bundle_helpers.py:115  BRANCH 3
        self._bundle_validation_summaries[signal.bundle_id] = (         # bundle_helpers.py:116-118
            signal.validation_summary
        )
```

**Branch inventory (3):**
1. `if not outcome:` (`:110`) — after `(signal.outcome or "").strip().lower()` normalization, an
   empty/whitespace-only/`None` outcome → **`return` early, mutate NOTHING** (`:111`). The
   `bundle_id` is NOT recorded; a subsequent `await_bundle_completion` will keep waiting (or time
   out). ⚠️ This is a SILENT drop.
2. `if signal.outputs:` (`:113`) — only copy outputs when the payload's `outputs` dict is truthy
   (non-empty). Stored as a **shallow copy** `dict(signal.outputs)` (`:114`), never the original
   reference.
3. `if signal.validation_summary:` (`:115`) — only store the audit summary when non-empty.

**What it buffers / mutates:** writes `_bundle_outcomes[bundle_id] = <normalized outcome>` (the
state the await-helper's predicate consumes), and conditionally `_bundle_outputs[bundle_id]` and
`_bundle_validation_summaries[bundle_id]`. It does NOT bump any timestamp, does NOT touch
`_updated_at` (unlike the base gate signals), and does NOT call any activity.

**Docstring semantics (`:101-108`):** the handler records `rejected` cleanly too even though v1 of
the API only fires this signal for `accepted` — "the handler still records the outcome so a future
`rejected` terminal-state would round-trip cleanly without further changes." So both `accepted` and
`rejected` flow through identically; the **distinction is made downstream** by the caller examining
the returned outcome, not here.

> ⚠️ **GOTCHA-BC1 (normalize = `(x or "").strip().lower()`):** the `or ""` guards a `None` outcome
> (a `BundleCompletedSignal` whose `outcome` somehow is `None`); `.strip()` removes stray
> whitespace; `.lower()` canonicalizes case. So `"Accepted "` and `"ACCEPTED"` both become
> `"accepted"`. A rebuild MUST apply the exact `(signal.outcome or "").strip().lower()` chain — a
> caller that later does `if outcome == "accepted"` depends on it. (Verified:
> `test_bundle_completed_records_accepted` passes `outcome="accepted"` and asserts
> `_bundle_outcomes["b-1"] == "accepted"` — `test_bundle_activities.py:467-475`.)
> ⚠️ **GOTCHA-BC2 (empty outcome is dropped, NOT recorded as `""`):** because of BRANCH 1, an empty
> outcome leaves `_bundle_outcomes` unchanged. Contrast with `bundle_expired` which defaults the
> reason to `"expired"` (§3) — there is NO default outcome here. A rebuild MUST `return` before the
> assignment, not store `""`.
> ⚠️ **GOTCHA-BC3 (`outputs` stored as a fresh dict copy):** `dict(signal.outputs)` (`:114`) copies
> the payload dict so later mutation of the signal object (or replay aliasing) can't corrupt stored
> state. A rebuild MUST copy, not alias. (Verified: `_bundle_outputs["b-1"] == {"k": "v"}` —
> `test_bundle_activities.py:476`.)
> ⚠️ **GOTCHA-BC4 (MUST NOT be overridden by a subclass workflow):** `bundle_completed` is
> registered as a `@workflow.signal` under the wire name `"bundle_completed"` (the method name).
> Temporal raises on duplicate signal registration for the same name. A workflow that mixes in
> `BundleAwareMixin` MUST NOT define its own `@workflow.signal` named `bundle_completed`; it inherits
> this one. (Same rule the base specs assert for `gate_approved` etc. — `_LineWorkflowBase.md`
> GOTCHA-SIG0.) Additionally a subclass MUST NOT redefine the method even *without* the decorator if
> it expects the await-helper to work — the helper reads `_bundle_outcomes` which only this handler
> (and `bundle_expired`) populates.

---

## 3. SIGNAL HANDLER — `bundle_expired(self, signal: BundleExpiredSignal) -> None` (`bundle_helpers.py:120-134`)

Fired by the **bundle-reaper cron workflow** for any `claimed` bundle past `expires_at`, and by the
**admin force-release path**. `@workflow.signal`, `async def` (no `await` inside).

```text
@workflow.signal
async def bundle_expired(self, signal):
    reason = (signal.reason or "expired").strip().lower()   # bundle_helpers.py:128
    if reason not in ("expired", "released"):               # bundle_helpers.py:132  BRANCH 1
        reason = "expired"                                  # bundle_helpers.py:133  ← normalize unknowns
    self._bundle_outcomes[signal.bundle_id] = reason        # bundle_helpers.py:134
```

**Branch inventory (1):**
1. `if reason not in ("expired", "released"):` (`:132`) → coerce `reason = "expired"` (`:133`). Any
   value outside the two recognized terminal reasons is normalized to `"expired"` "for safety"
   (`:130-131`).

**What it buffers / mutates:** writes `_bundle_outcomes[bundle_id] = reason` (`:134`) where reason ∈
`{"expired", "released"}`. Does NOT touch `_bundle_outputs` or `_bundle_validation_summaries`
(expiry/release carry no outputs). Does NOT bump any timestamp.

**Docstring semantics (`:121-127`):** `signal.reason == "expired"` is the cron/reaper path;
`"released"` is the admin force-release path. "Both are terminal for the bundle row — the workflow's
fallback_policy decides what to do." So `expired` and `released` are *distinct* outcomes the
downstream caller can branch on, while everything else collapses to `expired`.

> ⚠️ **GOTCHA-BE1 (default reason `"expired"`, contrast `bundle_completed`'s drop):** the
> normalization `(signal.reason or "expired").strip().lower()` (`:128`) DEFAULTS a `None`/empty
> reason to `"expired"` — unlike `bundle_completed`, which DROPS an empty outcome (GOTCHA-BC2). So
> an empty-reason expiry signal STILL records `_bundle_outcomes[bundle_id]="expired"`. A rebuild
> MUST use the `or "expired"` default here and the `or ""` + early-return there — they are
> deliberately asymmetric.
> ⚠️ **GOTCHA-BE2 (the membership normalization is `not in {"expired","released"}` → `"expired"`):**
> `"weird-state"` → `"expired"` (verified: `test_bundle_expired_normalises_unknown_reason` asserts
> `_bundle_outcomes["b-3"] == "expired"` for `reason="weird-state"` —
> `test_bundle_activities.py:504-508`). A rebuild MUST keep BOTH `expired` AND `released` as the
> allow-list, and coerce everything else to `expired`. (Verified happy path: `reason="expired"` →
> `"expired"`, `test_bundle_activities.py:489-492`.)
> ⚠️ **GOTCHA-BE3 (MUST NOT be overridden):** same rule as GOTCHA-BC4 — registered as
> `@workflow.signal` under wire name `"bundle_expired"`; a subclass MUST NOT redefine it (the
> external reaper fires exactly that name — see §7 / `bundle_reaper.py:99`).
> ⚠️ **GOTCHA-BE4 (LAST-WRITER-WINS across the two signals):** both handlers write the SAME key
> `_bundle_outcomes[bundle_id]`. There is no guard against a `bundle_expired` arriving AFTER a
> `bundle_completed` (or vice-versa) for the same `bundle_id`. Whichever signal is delivered later
> overwrites the outcome. In practice the API/reaper coordinate so only one fires, but the mixin
> imposes NO ordering protection. A rebuild MUST NOT add idempotency/first-writer-wins guarding —
> the handlers are plain last-writer-wins assignments. (The await-helper's predicate fires on the
> FIRST appearance of the key, so whichever lands first unblocks the wait; a later overwrite changes
> only the value read at `:170` if the helper hasn't yet read it — an ordering quirk a rebuild must
> reproduce by NOT adding locking.)

---

## 4. AWAIT HELPER — `await_bundle_completion(self, bundle_id, timeout_seconds) -> BundleOutcome` (`bundle_helpers.py:140-176`) ★ CORE

The only blocking method. Called by a consumer workflow's `run()` AFTER it dispatches a bundle
(`bundle_helpers.py:41-43` usage example). Blocks until the bundle's terminal outcome lands as a
signal, OR `timeout_seconds` elapses. Returns one of the five `BundleOutcome` literals.

```text
async def await_bundle_completion(self, bundle_id, timeout_seconds) -> BundleOutcome:
    from datetime import timedelta as _td                 # bundle_helpers.py:161  ← LOCAL import

    try:                                                   # bundle_helpers.py:163
        await workflow.wait_condition(                     # bundle_helpers.py:164
            lambda: bundle_id in self._bundle_outcomes,    # bundle_helpers.py:165  ★PREDICATE
            timeout=_td(seconds=timeout_seconds),          # bundle_helpers.py:166
        )
    except TimeoutError:                                   # bundle_helpers.py:168  BRANCH 1
        return "timeout"                                   # bundle_helpers.py:169  ← timer fired, no signal
    outcome = self._bundle_outcomes.get(bundle_id, "")     # bundle_helpers.py:170
    if outcome not in ("accepted", "rejected", "expired", "released"):  # bundle_helpers.py:174  BRANCH 2
        return "timeout"                                   # bundle_helpers.py:175  ← defensive normalize
    return outcome  # type: ignore[return-value]           # bundle_helpers.py:176
```

**Branch inventory (2 + the predicate):**
1. `except TimeoutError:` (`:168`) → `return "timeout"` (`:169`). When `workflow.wait_condition`'s
   `timeout=` elapses BEFORE `bundle_id` appears in `_bundle_outcomes`, Temporal raises
   `asyncio.TimeoutError` (caught here) and the helper returns the literal `"timeout"`.
2. `if outcome not in ("accepted", "rejected", "expired", "released"):` (`:174`) → `return
   "timeout"` (`:175`). Defensive: after the wait succeeds, re-reads the outcome and — if it is
   somehow not one of the four valid terminal values — also returns `"timeout"`. Otherwise returns
   the actual `outcome` (`:176`).

**The `wait_condition` predicate (`:165`):** `lambda: bundle_id in self._bundle_outcomes`. The wait
unblocks the instant EITHER signal handler inserts `bundle_id` into `_bundle_outcomes`. The
predicate is evaluated on every workflow-task replay after each signal; it is a pure membership
test (no mutation, deterministic).

**Return-value map (the routing this method performs):**
| `_bundle_outcomes[bundle_id]` after wait | Returned `BundleOutcome` | Set by |
|------------------------------------------|--------------------------|--------|
| `"accepted"` | `"accepted"` | `bundle_completed` (`:112`) |
| `"rejected"` | `"rejected"` | `bundle_completed` (`:112`) |
| `"expired"` | `"expired"` | `bundle_expired` (`:134`) |
| `"released"` | `"released"` | `bundle_expired` (`:134`) |
| key never appeared within `timeout_seconds` | `"timeout"` | timer (BRANCH 1) |
| key present but value outside the 4 (should be impossible given the handlers) | `"timeout"` | BRANCH 2 |

**How the caller routes on the result** (from the usage example `bundle_helpers.py:44-49`):
```text
outcome = await self.await_bundle_completion(bundle_id, timeout_seconds=...)
if outcome == "accepted":
    # use self._bundle_outputs[bundle_id] as gate evidence
    ...
elif outcome in ("expired", "timeout"):
    # apply the portfolio fallback_policy (internal_fallback / escalate / fail / redispatch)
    ...
```
(`"rejected"` and `"released"` are also possible; the consuming workflow's `fallback_policy` decides
— types.py:347-349, 379-382. The mixin itself does NO fallback; it only returns the outcome.)

> ⚠️ **GOTCHA-AW1 (`timeout_seconds` is a SEPARATE safety net from the bundle's own `expires_at`):**
> the docstring (`:152-159`) is explicit: this Temporal timer is "independent of the bundle's own
> expires_at (which is enforced by the reaper)." A workflow MAY pick a LONGER timeout than the
> bundle TTL when `fallback_policy == "redispatch"` (so it survives multiple bundle cycles), or a
> SHORTER one for adversarial/safety-critical paths. So `"timeout"` and `"expired"` are NOT the same
> event: `"expired"` = the reaper fired `bundle_expired`; `"timeout"` = this workflow's own timer
> elapsed with NO signal at all. A rebuild MUST keep them as distinct outcomes and MUST NOT couple
> `timeout_seconds` to the bundle's `expires_at`.
> ⚠️ **GOTCHA-AW2 (catches `TimeoutError`, which is `asyncio.TimeoutError`):** `workflow.wait_condition`
> with a `timeout=` raises `asyncio.TimeoutError` on expiry; in Python 3.11+ the builtin
> `TimeoutError` is an alias for `asyncio.TimeoutError`, so the bare `except TimeoutError`
> (`:168`) catches it. A rebuild MUST catch `TimeoutError` (or `asyncio.TimeoutError`) specifically —
> NOT a broad `except Exception` (which would swallow `CancelledError` and break workflow cancel),
> and NOT forget the try/except (which would let the timeout propagate and fail the workflow).
> ⚠️ **GOTCHA-AW3 (the LOCAL `from datetime import timedelta as _td`):** `timedelta` is imported
> INSIDE the function body (`:161`), aliased `_td`, NOT at module top. This is deliberate — it keeps
> the workflow module's top-level import surface minimal and avoids any sandbox concern about a
> top-level `datetime` import. A rebuild may import `timedelta` at module top OR locally; behavior is
> identical, BUT note the original does it locally — replicate to be faithful. The timer value is
> `timedelta(seconds=timeout_seconds)` — `timeout_seconds` is a plain `int` seconds count.
> ⚠️ **GOTCHA-AW4 (the predicate does NOT include `self.cancelled`):** unlike the base
> `_wait_for_gate_decision`/`_reconcile_and_merge_with_retry_loop` predicates (which OR in
> `self.cancelled` — `_HILSignalsMixin.md` GOTCHA-1, `_LineWorkflowBase.md` GOTCHA-WG1/MR5), THIS
> wait condition is `lambda: bundle_id in self._bundle_outcomes` ONLY (`:165`). It is therefore NOT
> short-circuited by a `cancel_workflow` signal. If the consuming workflow needs the bundle wait to
> be cancellable, the workflow author must EITHER set a finite `timeout_seconds` OR wrap/observe
> cancellation at the `run()` level — the mixin does not do it. A rebuild MUST reproduce the
> cancel-agnostic predicate exactly (do NOT silently add `or self.cancelled`); changing it alters
> replay/cancel semantics. (Temporal will still deliver a hard workflow-cancellation
> `CancelledError` through the `await`, but a soft `cancel_workflow` HIL signal flips
> `self.cancelled` without unblocking this wait.)
> ⚠️ **GOTCHA-AW5 (BRANCH 2 is belt-and-suspenders — but load-bearing for the type contract):** the
> signal handlers already constrain `_bundle_outcomes` values to the four valid strings (BC1+BE2
> normalization), so `outcome not in (...)` "should" never be true after a successful wait. The
> comment (`:171-173`) calls it "Defensive normalisation … downstream code shouldn't have to
> re-validate." A rebuild MUST keep BRANCH 2 — it guarantees the function's declared
> `-> BundleOutcome` return type holds even if a future signal-handler change leaked an unexpected
> value. The `# type: ignore[return-value]` on `:176` is because the static checker can't prove the
> narrowed `str` is one of the `Literal` members — purely a typing annotation, no runtime effect.
> ⚠️ **GOTCHA-AW6 (returns FAST if the signal already arrived — buffered-before-call safety):**
> because `bundle_completed`/`bundle_expired` can fire BEFORE `await_bundle_completion` is even
> called (the bundle could be accepted between dispatch and the await), the predicate `bundle_id in
> self._bundle_outcomes` will already be `True` and `wait_condition` returns on the first evaluation
> with no actual blocking. This mirrors the base "decisions buffered before the wait" pattern
> (`_LineWorkflowBase.md` GOTCHA-WG1). A rebuild MUST use a membership-on-state predicate (NOT a
> one-shot event/future) so an early signal is not lost.

---

## 5. QUERY HANDLERS — dashboard/debug read-only (`bundle_helpers.py:182-190`)

Two `@workflow.query` handlers (synchronous, read-only — queries MUST NOT mutate state).

### 5.1 `get_bundle_outcome(self, bundle_id: str) -> str` — `bundle_helpers.py:182-185`
```text
@workflow.query
def get_bundle_outcome(self, bundle_id):
    return self._bundle_outcomes.get(bundle_id, "")    # bundle_helpers.py:185
```
- Returns the terminal outcome for a bundle, or `""` if unknown (no signal yet / dropped empty
  outcome). The empty-string sentinel lets a dashboard distinguish "not yet decided" from a real
  outcome. Single `.get(..., "")` — **no branch**, but the default-arg is the routing fallback.

### 5.2 `get_bundle_outputs(self, bundle_id: str) -> dict[str, str]` — `bundle_helpers.py:187-190`
```text
@workflow.query
def get_bundle_outputs(self, bundle_id):
    return dict(self._bundle_outputs.get(bundle_id, {}))   # bundle_helpers.py:190
```
- Returns the accepted bundle's outputs map, or `{}` if the bundle wasn't accepted / carried no
  outputs (GOTCHA-INIT2). Returns a **copy** (`dict(...)`) so the query result can't be used to
  mutate workflow state.

> ⚠️ **GOTCHA-Q1 (queries return COPIES / sentinels, never raise on unknown id):** both queries use
> `.get(id, <default>)` and `get_bundle_outputs` wraps in `dict(...)` (`:190`). A rebuild MUST NOT
> raise `KeyError` for an unknown `bundle_id` — return the empty default. And MUST return a defensive
> copy from `get_bundle_outputs` (queries are read-only; returning the live dict would let a caller
> alias workflow state). (Verified by `test_query_helpers_return_state` — `test_bundle_activities.py:510+`.)
> ⚠️ **GOTCHA-Q2 (MUST NOT be redefined by subclasses; names distinct from base `get_status`):**
> these register under wire names `"get_bundle_outcome"` / `"get_bundle_outputs"` — distinct from the
> base `get_status` query (`_LineWorkflowBase.md` §16). A workflow mixing in BOTH carries all three
> queries with no collision. A subclass MUST NOT redefine these names (duplicate-query registration
> would raise). There is NO `get_bundle_validation_summary` query — `_bundle_validation_summaries`
> is exposed via NO query and read by NO method in this module; it exists purely for a consuming
> workflow's `run()` to read directly when building a failure narrative (docstring `:80-82`).

---

## 6. CONTROL-FLOW SUMMARY — what the mixin does end-to-end

The mixin has **no `run()`** and dispatches **no activities/child workflows**. Its full behavioral
surface is: (a) two signal handlers that record terminal state, (b) one await helper that blocks on
that state with a timer, (c) two read-only queries. The orchestration that USES it lives in the
consuming workflow's `run()` (per the usage example `bundle_helpers.py:22-49`):

```text
# (consuming workflow, NOT in this module — shown for routing fidelity)
bundle_id = await workflow.execute_activity(dispatch_delegated_bundle, args=[...],
                                            start_to_close_timeout=timedelta(seconds=30))   # :30-40
outcome   = await self.await_bundle_completion(bundle_id, timeout_seconds=24*3600*7)        # :41-43
if outcome == "accepted":                                                                   # :44
    # use self._bundle_outputs[bundle_id] as gate/step evidence                             # :45-46
    ...
elif outcome in ("expired", "timeout"):                                                     # :47
    # apply per-portfolio fallback_policy                                                   # :48-49
    ...
```
- ⚠️ The `dispatch_delegated_bundle` activity (30s start_to_close in the example) is invoked by the
  CONSUMING workflow, NOT by this mixin. The mixin only awaits the resulting signal. A rebuild of a
  *consumer* must persist the returned `bundle_id` (docstring step 1, `:6`) and pass it to
  `await_bundle_completion`.

---

## 7. WHO FIRES THESE SIGNALS (external producers — for fidelity, do not re-spec)

- **`bundle_completed`** — fired by the **API service layer** when a bundle reaches `accepted` via
  `POST /bundles/{id}/submit` (types.py:337-343). The API constructs `BundleCompletedSignal(bundle_id,
  outcome="accepted", outputs={...}, validation_summary=...)` and signals the parent workflow handle.
- **`bundle_expired`** — fired by the **bundle-reaper cron workflow** (`bundle_reaper.py`). The
  reaper sweeps `claimed` bundles past `expires_at`, then for each with a known `workflow_id` does
  `handle = workflow.get_external_workflow_handle(wfid); await handle.signal("bundle_expired",
  BundleExpiredSignal(bundle_id=bundle_id, reason="expired"))` (`bundle_reaper.py:96-104`). Note it
  fires the signal **by string name `"bundle_expired"`** — this is exactly why the mixin's handler
  MUST keep that method/wire name (GOTCHA-BE3). The reaper swallows the signal exception when the
  external workflow is already complete/cancelled (`bundle_reaper.py:105-109`) — so a completed
  consumer never receives a stale expiry.
- The **admin force-release path** fires `bundle_expired` with `reason="released"` (types.py
  docstring; mixin docstring `:124-125`).

> The mixin is the **consumer** of these signals; the API service (`olympus-api/src/services/bundle.py`)
> and the reaper (`bundle_reaper.py`) are the **producers**. A rebuild of the mixin need only ensure
> the two `@workflow.signal` wire names and payload fields match what those producers send.

---

## 8. RESILIENCE summary

- **Timeouts:** exactly ONE — the `workflow.wait_condition(..., timeout=timedelta(seconds=
  timeout_seconds))` in `await_bundle_completion` (`:166`). It is a Temporal durable timer; on expiry
  → `TimeoutError` → return `"timeout"`. There are NO activity timeouts (no activities) and NO
  start_to_close/heartbeat config in this module.
- **Heartbeats:** none (no activities).
- **continue-as-new:** none. The mixin holds bounded per-bundle state in three dicts; a consuming
  workflow that awaits MANY bundles over a long life is responsible for its own continue-as-new — the
  mixin does nothing.
- **Idempotency:** signal handlers are idempotent in effect for a fixed payload (re-delivering the
  same `bundle_completed` re-writes the same key→value). NO `activity_id` (no activities). The
  await-helper is replay-safe because its predicate is pure membership on persisted state and its
  only side-bearing primitive is the deterministic Temporal timer.
- **Compensation / rollback:** none. On `"timeout"`/`"expired"`/`"rejected"`/`"released"` the mixin
  simply returns the outcome; the CONSUMING workflow's `fallback_policy` (internal_fallback /
  redispatch / escalate / fail — types.py:347-349, 379-382) owns any compensating action. The mixin
  performs NO rollback and emits NO failure projection.
- **Cancellation:** the await predicate does NOT include `self.cancelled` (GOTCHA-AW4) — a soft
  `cancel_workflow` HIL signal will NOT unblock the wait; only the timer, an inbound bundle signal,
  or a hard Temporal workflow-cancellation (`CancelledError` through the `await`) ends it.

---

## 9. Behavioral parity checklist

A rebuilt `BundleAwareMixin` MUST satisfy ALL of the following:

1. It is a **plain mixin class** (NOT `@workflow.defn`), designed to be mixed in ALONGSIDE
   `HILSignalsMixin`/`LineWorkflowBase` (`class W(BundleAwareMixin, ...)`), and overrides NOTHING on
   those bases. `__init__` calls `super().__init__()` as its **first** statement (`:90`), then sets
   `_bundle_outcomes={}`, `_bundle_outputs={}`, `_bundle_validation_summaries={}` to fresh empties,
   with NO `hasattr` guard. (GOTCHA-INIT1/INIT2)
2. Activity/RETRY-POLICY imports: NONE. The two payload dataclasses (`BundleCompletedSignal`,
   `BundleExpiredSignal`) are imported from `olympus_workflows.types` INSIDE
   `with workflow.unsafe.imports_passed_through():` (`:58-61`). (GOTCHA-IMP1)
3. `BundleOutcome` is `Literal["accepted","rejected","expired","released","timeout"]` (`:65`) — the
   closed set of `await_bundle_completion` return values.
4. **Exactly two** `@workflow.signal` handlers, both `async def`, both pure attribute mutation (no
   `await`, no `workflow.now()`, no I/O, no activity), registered under wire names `"bundle_completed"`
   and `"bundle_expired"`. Neither is EVER redefined by a consuming subclass. (GOTCHA-BC4/BE3)
5. `bundle_completed`: normalize `outcome=(signal.outcome or "").strip().lower()`; if falsy →
   `return` early recording NOTHING (`:110-111`); else set `_bundle_outcomes[bundle_id]=outcome`;
   if `signal.outputs` truthy → set `_bundle_outputs[bundle_id]=dict(signal.outputs)` (a COPY); if
   `signal.validation_summary` truthy → set `_bundle_validation_summaries[bundle_id]=...`. Records
   BOTH `accepted` and `rejected` identically. (GOTCHA-BC1/BC2/BC3 — 3 branches)
6. `bundle_expired`: normalize `reason=(signal.reason or "expired").strip().lower()` (DEFAULTS to
   `"expired"`, unlike `bundle_completed`); if `reason not in ("expired","released")` → `reason=
   "expired"`; set `_bundle_outcomes[bundle_id]=reason`. (GOTCHA-BE1/BE2 — 1 branch)
7. Last-writer-wins across the two handlers on the shared `_bundle_outcomes` key; NO ordering/
   idempotency guard added. (GOTCHA-BE4)
8. `await_bundle_completion(bundle_id, timeout_seconds)`: local `from datetime import timedelta as
   _td` (`:161`); `try: await workflow.wait_condition(lambda: bundle_id in self._bundle_outcomes,
   timeout=_td(seconds=timeout_seconds))`; `except TimeoutError: return "timeout"`; then
   `outcome=self._bundle_outcomes.get(bundle_id,"")`; if `outcome not in
   ("accepted","rejected","expired","released"): return "timeout"`; else `return outcome`. The
   predicate is membership-only and does NOT include `self.cancelled`. (GOTCHA-AW1..AW6 — 2 branches
   + predicate)
9. `"timeout"` (own timer) and `"expired"` (reaper signal) are DISTINCT outcomes; `timeout_seconds`
   is decoupled from the bundle's `expires_at`. (GOTCHA-AW1)
10. **Exactly two** `@workflow.query` handlers (synchronous, read-only): `get_bundle_outcome(id)` →
    `_bundle_outcomes.get(id,"")`; `get_bundle_outputs(id)` → `dict(_bundle_outputs.get(id,{}))` (a
    COPY). Neither raises on unknown id; both register under names distinct from the base `get_status`
    and are never redefined by subclasses. There is NO query for `_bundle_validation_summaries`.
    (GOTCHA-Q1/Q2)
11. The mixin dispatches ZERO activities and ZERO child workflows, has ONE timeout (the wait_condition
    timer), NO heartbeats, NO continue-as-new, NO compensation. All fallback behavior is owned by the
    CONSUMING workflow's `fallback_policy`, not the mixin. (§8)
12. Total branch count reproduced: `bundle_completed` (3) + `bundle_expired` (1) +
    `await_bundle_completion` (2) = **6 explicit branch-points**, plus the membership-test lambda
    predicate and the two query `.get(...)` default fallbacks. A rebuild that reproduces fewer than
    these 6 branches has FAILED.
