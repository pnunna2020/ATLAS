# `architecture_patterns_router` — Architecture-Blueprint Skill-Variant Router (ATOMIC regeneration spec)

> **Source of truth:** `temporal/olympus_workflows/workflows/architecture_patterns_router.py` (107 lines).
> Every `architecture_patterns_router.py:line` citation below is against that file.
>
> **What this is:** a **pure-Python routing/helper MODULE** — NOT a `@workflow.defn` class. It has
> **no `run()`/`_execute()`, no state, no signals, no queries, no activities, no child workflows,
> and no gate handling**. It is a single deterministic lookup function plus one private normalizer
> and two module-level constants. It lives in the `workflows/` package by convention (alongside the
> sibling routers `discovery_patterns_router`, `code_generation_router`, `data_router`) but is
> deliberately **below the Temporal workflow boundary** so it can be unit-tested directly
> (`architecture_patterns_router.py:36-37`: *"Keep this module pure Python with no Temporal imports
> so it can be exercised by unit tests directly — we're below the workflow boundary."*).
>
> **Purpose:** chooses the correct `target-architecture-blueprint-*` skill variant for the
> Architecture line's **blueprint-assembly step (step 10)** based on the target **disposition**
> produced by Rationalization (`architecture_patterns_router.py:1-7`). Mirrors the pattern used by
> `discovery_patterns_router` (tech-fingerprint keyed) and `code_generation_router` (framework
> keyed) — but this router is **disposition keyed**.
>
> **Determinism:** the function is a pure mapping over a frozen module-level dict + a string
> normalizer. No wall-clock, no randomness, no I/O, no module-level mutable state mutated at call
> time. Safe to call inside a Temporal workflow (`ArchitectureWorkflow._dispatch`) without violating
> determinism, AND safe to call from unit tests with no harness.

---

## 0. Inheritance / base-spec relationship

This module **does not inherit from `LineWorkflowBase` or `HILSignalsMixin`** and **overrides none
of their methods.** It is not a workflow. See `_LineWorkflowBase.md` and `_HILSignalsMixin.md` only
to understand the *caller* (`ArchitectureWorkflow`), which IS a `LineWorkflowBase` subclass. The
router itself is called from inside that subclass's **own override** of `_dispatch_agent`
(`architecture.py:1916-1999`) — see §6 "Call site".

> ⚠️ **GOTCHA-AR0 (no Temporal imports — must stay pure):** the module's closing docstring line
> (`architecture_patterns_router.py:36-37`) is a hard constraint, not a suggestion. A rebuild MUST
> NOT add `from temporalio import workflow` or any activity/type import that would pull in the
> Temporal sandbox. Adding such an import would (a) break the standalone unit tests that import this
> module directly (`tests/test_architecture_patterns_router.py:19-23`), and (b) risk being
> re-executed under the workflow sandbox. The only `__future__` import present is
> `from __future__ import annotations` (`architecture_patterns_router.py:40`) — keep it (it makes
> the `str | None` annotations lazy/forward-compatible on older Python).

---

## 1. MODULE-LEVEL STATE (constants — immutable after import)

There is **no instance state** (no class). The module exposes two top-level names plus the public
function. Both constants are evaluated once at import time and are **never mutated** by the function.

### 1.1 `DISPOSITION_BLUEPRINT_MAP: dict[str, str | None]` — `architecture_patterns_router.py:46-62`

The disposition→specialist mapping. **Keys are pre-lowercased** (the function lowercases the input
before lookup; the keys here are already lowercase, so a rebuild MUST store lowercase keys or the
`in` test fails). Reproduce EXACTLY:

| Key (lowercase) | Value | Line | Meaning |
|-----------------|-------|------|---------|
| `"refactor"` | `"target-architecture-blueprint-refactor"` | 47 | Refactor preserves topology → refactor specialist |
| `"replatform"` | `"target-architecture-blueprint-replatform"` | 48 | Replatform swaps middleware → replatform specialist |
| `"rearchitect"` | `"target-architecture-blueprint-rearchitect"` | 49 | Rearchitect decomposes → rearchitect specialist |
| `"replace"` | `"target-architecture-blueprint-rearchitect"` | 54 | Net-new target; decomposition-first semantics match Rearchitect |
| `"consolidate"` | `"target-architecture-blueprint-rearchitect"` | 55 | Multi-source merge; bounded-context reconciliation via Rearchitect |
| `"retire"` | `None` | 60 | No blueprint — caller MUST skip the step entirely |
| `"retain"` | `None` | 61 | No blueprint — caller MUST skip the step entirely |

> ⚠️ **GOTCHA-AR1 (the value type is `str | None` — `None` is a LEGITIMATE in-map value, NOT a
> "missing key"):** `"retire"` and `"retain"` are **present in the dict** but map to `None`
> (`architecture_patterns_router.py:60-61`). This is the single most fragile aspect of the router.
> The lookup branch (`if key in DISPOSITION_BLUEPRINT_MAP`) tests **key membership**, and then
> returns `DISPOSITION_BLUEPRINT_MAP[key]` — which may be `None`. So `select_architecture_blueprint_skill("Retire")`
> returns `None` (a deliberate "skip the step" signal), whereas an **unknown** disposition (key
> NOT in the dict) returns the base default skill string. A rebuild that uses
> `DISPOSITION_BLUEPRINT_MAP.get(key, DEFAULT)` would be WRONG: `.get("retire", DEFAULT)` returns
> `None` correctly, BUT `.get("totally-unknown", DEFAULT)` returns `DEFAULT` correctly too — so
> `.get(key, DEFAULT)` actually *would* reproduce the observable behavior. HOWEVER the source does
> NOT use `.get`; it uses an explicit `if key in MAP: return MAP[key]` then a fall-through return
> (`architecture_patterns_router.py:102-106`). Reproduce the explicit-membership form to preserve
> line-for-line behavioral parity and the documented "unknown → base, in-map-None → None"
> distinction. The semantic contract is: **in-map → return its value (even if `None`); not-in-map →
> base default.**

> ⚠️ **GOTCHA-AR2 (Replace + Consolidate intentionally share the Rearchitect variant):** three
> distinct dispositions (`rearchitect`, `replace`, `consolidate`) all map to the SAME skill id
> `"target-architecture-blueprint-rearchitect"` (`architecture_patterns_router.py:49,54,55`). This
> is by design — the comment (`architecture_patterns_router.py:50-53`) states the Rearchitect
> specialist's SKILL.md `supported_dispositions` explicitly lists Replace + Consolidate. A rebuild
> MUST map all three to the identical string; do not invent `-replace`/`-consolidate` variants.

### 1.2 `ARCHITECTURE_BLUEPRINT_DEFAULT_SKILL: str` — `architecture_patterns_router.py:66`

```python
ARCHITECTURE_BLUEPRINT_DEFAULT_SKILL: str = "target-architecture-blueprint"
```

The generic base skill id. Returned in two cases (see §3 branches B1-false and B2-false): (a) empty
/ missing / whitespace-only disposition, and (b) a disposition string that normalizes to a key not
present in `DISPOSITION_BLUEPRINT_MAP`.

> ⚠️ **GOTCHA-AR3 (unknown disposition returns the BASE, never raises):** the closing comment
> (`architecture_patterns_router.py:104-106`) explains this is deliberate — *"Unknown disposition —
> return the base rather than error so legacy / custom profile dispositions still get a blueprint."*
> A rebuild MUST NOT raise `KeyError`/`ValueError` on an unrecognized disposition; it returns the
> base skill string so a custom-profile disposition still produces an artifact.

---

## 2. SIGNALS / QUERIES / UPDATES

**NONE.** This module has no Temporal surface. No `@workflow.signal`, `@workflow.query`,
`@workflow.update`, no `wait_condition`, no buffered state. (Documented here per the mandatory
template: this section is intentionally empty because the module is below the workflow boundary —
`architecture_patterns_router.py:36-37`.) A rebuild adds no handlers here; the gate/HIL surface
lives entirely on `ArchitectureWorkflow` / `LineWorkflowBase` (see those specs).

---

## 3. CONTROL-FLOW PSEUDOCODE — every branch preserved

There are **3 in-module branch-points** total: 1 in `_normalize`, 2 in
`select_architecture_blueprint_skill`. ALL are reproduced below. (A 4th, caller-side branch pair
lives in `architecture.py` and is reproduced in §6 because it is what consumes the `None` return.)

### 3.1 `_normalize(value: str | None) -> str` — `architecture_patterns_router.py:69-73`

Lower-cases and strips a disposition token for comparison.

```text
def _normalize(value: str | None) -> str:
    if not value:                       # architecture_patterns_router.py:71  ── BRANCH N1
        return ""                       # architecture_patterns_router.py:72
    return value.strip().lower()        # architecture_patterns_router.py:73
```

**Branch N1 (`if not value:`, line 71):**
- TRUE when `value` is `None` **or** the empty string `""` (both are falsy) → returns `""`.
- FALSE for any non-empty string (including a whitespace-only string like `"   "`, which is truthy)
  → returns `value.strip().lower()`.

> ⚠️ **GOTCHA-AR4 (`not value` catches BOTH `None` and `""`, but NOT `"   "`):** a whitespace-only
> string `"   "` is **truthy**, so it does NOT take the early-return branch; it falls to
> `value.strip().lower()` which yields `""` (strip removes all whitespace). So `_normalize("   ")`
> → `""` too, but via the **second** line, not the first. The net effect (empty string) is
> identical, and the caller's `if not key:` (§3.2 B1) then treats it as "missing". A rebuild MUST
> `strip()` BEFORE the membership test so `"  Refactor  "` normalizes to `"refactor"` and matches.
> Order matters: `.strip().lower()` — strip first then lower (either order is equivalent here since
> whitespace is unaffected by case, but reproduce `.strip().lower()` exactly).

> ⚠️ **GOTCHA-AR5 (case-folding is `.lower()`, not `.casefold()`):** `architecture_patterns_router.py:73`
> uses `.lower()`. For ASCII disposition tokens these are equivalent, but a rebuild should use
> `.lower()` verbatim to match the existing test expectations (`test_case_insensitive_disposition_input`
> exercises `"refactor"`, `"REARCHITECT"`, `"rePlAtFoRm"` — `tests/test_architecture_patterns_router.py:79-89`).

### 3.2 `select_architecture_blueprint_skill(disposition: str | None) -> str | None` — `architecture_patterns_router.py:76-106`

The single public entry point. Returns a skill id string, OR `None` (skip the blueprint step).

```text
def select_architecture_blueprint_skill(disposition: str | None) -> str | None:
    key = _normalize(disposition)                       # architecture_patterns_router.py:99
    if not key:                                         # architecture_patterns_router.py:100 ── BRANCH B1
        return ARCHITECTURE_BLUEPRINT_DEFAULT_SKILL     # architecture_patterns_router.py:101
    if key in DISPOSITION_BLUEPRINT_MAP:                # architecture_patterns_router.py:102 ── BRANCH B2
        return DISPOSITION_BLUEPRINT_MAP[key]           # architecture_patterns_router.py:103  (may be None!)
    # Unknown disposition — return the base rather than error so legacy /
    # custom profile dispositions still get a blueprint.
    return ARCHITECTURE_BLUEPRINT_DEFAULT_SKILL         # architecture_patterns_router.py:106
```

**Resolution order — three terminal outcomes:**

1. **BRANCH B1 TRUE** (`if not key:`, line 100): `key` is `""` (input was `None`, `""`, or
   whitespace-only after normalization) → **return `ARCHITECTURE_BLUEPRINT_DEFAULT_SKILL`**
   (`"target-architecture-blueprint"`), line 101. This is the **legacy-caller / missing-disposition
   path** (`architecture_patterns_router.py:84,100` and docstring 11-13, 30-34).

2. **BRANCH B2 TRUE** (`if key in DISPOSITION_BLUEPRINT_MAP:`, line 102): the normalized key is one
   of the 7 canonical dispositions → **return `DISPOSITION_BLUEPRINT_MAP[key]`** (line 103). This
   value is:
   - `"target-architecture-blueprint-refactor"` for `refactor`
   - `"target-architecture-blueprint-replatform"` for `replatform`
   - `"target-architecture-blueprint-rearchitect"` for `rearchitect`, `replace`, OR `consolidate`
   - **`None`** for `retire` OR `retain` (explicit skip signal — GOTCHA-AR1)

3. **BRANCH B2 FALSE → fall-through** (line 106): the key is non-empty but NOT in the map (unknown /
   custom-profile disposition) → **return `ARCHITECTURE_BLUEPRINT_DEFAULT_SKILL`** (the base),
   line 106. Never raises (GOTCHA-AR3).

> ⚠️ **GOTCHA-AR6 (B1 and B2 are mutually exclusive and ordered — empty-check FIRST):** the
> empty-key check (B1, line 100) runs BEFORE the membership check (B2, line 102). This matters
> because `""` is not a key in `DISPOSITION_BLUEPRINT_MAP`, so without B1 an empty input would fall
> through to the same base default anyway — BUT the source keeps B1 as an explicit early return
> (and the docstring lists it as resolution step 3). A rebuild should keep the explicit ordering;
> collapsing B1 into the fall-through would still return the same value for `""` but loses the
> documented three-step resolution structure and the line-for-line citation. Reproduce both
> `if` statements.

**Truth table (every input class the tests exercise — `tests/test_architecture_patterns_router.py`):**

| Input `disposition` | `_normalize` → `key` | Branch taken | Return |
|---------------------|----------------------|--------------|--------|
| `"Refactor"` | `"refactor"` | B2 true | `"target-architecture-blueprint-refactor"` |
| `"refactor"` | `"refactor"` | B2 true | `"target-architecture-blueprint-refactor"` |
| `"Replatform"` / `"rePlAtFoRm"` | `"replatform"` | B2 true | `"target-architecture-blueprint-replatform"` |
| `"Rearchitect"` / `"REARCHITECT"` | `"rearchitect"` | B2 true | `"target-architecture-blueprint-rearchitect"` |
| `"Replace"` | `"replace"` | B2 true | `"target-architecture-blueprint-rearchitect"` |
| `"Consolidate"` | `"consolidate"` | B2 true | `"target-architecture-blueprint-rearchitect"` |
| `"Retire"` | `"retire"` | B2 true | **`None`** |
| `"Retain"` | `"retain"` | B2 true | **`None`** |
| `"SomeCustomDisposition"` | `"somecustomdisposition"` | B2 false → fall-through | `"target-architecture-blueprint"` |
| `""` | `""` | B1 true | `"target-architecture-blueprint"` |
| `None` | `""` (via N1) | B1 true | `"target-architecture-blueprint"` |
| `"   "` | `""` (via N1 second line) | B1 true | `"target-architecture-blueprint"` |

---

## 4. ACTIVITY & CHILD-WORKFLOW CALLS

**NONE.** The router invokes no Temporal activities and starts no child workflows. It performs a
pure dict lookup. There are no retry policies, timeouts, `non_retryable_errors`, `gather`, or
sequential/parallel concerns at this layer. (The skill id this function *returns* is later handed to
`ArchitectureWorkflow._dispatch_agent`'s `dispatch_agent_task` activity — see §6 and the
`ArchitectureWorkflow` spec for that activity's retry/timeout.)

---

## 5. GATE HANDLING / REWORK LOOP / COUNTERS

**NONE in this module.** No evidence assembly, no gate wait, no approve/reject/merge-blocked/rework
routing, no rework counters. Those live entirely in `LineWorkflowBase._wait_for_gate_decision` /
`_reconcile_and_merge_with_retry_loop` / `_bump_rework` (see `_LineWorkflowBase.md` §13/§14/§17) and
in the `ArchitectureWorkflow.run()` G-02 rework loop (see the `ArchitectureWorkflow` spec).

> Note for the caller: the rework feedback that the Architecture workflow forwards on re-dispatch is
> keyed `"G-02"` (`architecture.py:1937`), and this router is **re-invoked unchanged on every rework
> cycle** for the `blueprint-assembly` step. If a reviewer's rework changed the disposition
> upstream, the router would pick a different variant on the next cycle — but the disposition is a
> workflow-input field (`self._disposition`), not something the gate decision mutates, so in
> practice the routed skill is stable across G-02 rework iterations.

---

## 6. CALL SITE — who calls this, and how the `None` return is consumed

**Sole caller in the codebase:** `ArchitectureWorkflow._dispatch_agent`
(`architecture.py:1916-1999`), which is `ArchitectureWorkflow`'s **override** of the base
`_dispatch_agent`. The import is lazy / sandbox-passthrough at the top of the workflow module
(`architecture.py:123-125`, inside `with workflow.unsafe.imports_passed_through():`).

The relevant slice (`architecture.py:1935-1952`), reproduced with EVERY caller-side branch:

```text
step_def = ARCHITECTURE_STEPS[step_name]                       # architecture.py:1935
context: dict = {}
fb = self._rework_feedback.get("G-02")                         # architecture.py:1937
if fb is not None:                                             # architecture.py:1938  (caller branch — rework)
    context["rework_feedback"] = fb                            # architecture.py:1939

skill_id = step_def["skill_id"]                                # architecture.py:1948  default = declared skill
if step_name == "blueprint-assembly":                          # architecture.py:1949  ── CALLER BRANCH C1
    routed = select_architecture_blueprint_skill(self._disposition)   # architecture.py:1950  ← ROUTER CALL
    if routed is not None:                                     # architecture.py:1951  ── CALLER BRANCH C2
        skill_id = routed                                      # architecture.py:1952
# else: skill_id stays step_def["skill_id"]  (router None → keep declared base skill)
```

**CALLER BRANCH C1 (`if step_name == "blueprint-assembly":`, `architecture.py:1949`):** the router
is ONLY consulted for the `"blueprint-assembly"` step (step 10). Every other architecture step uses
its declared `step_def["skill_id"]` unchanged. A rebuild of the *caller* must gate the router call
behind this exact step-name check.

**CALLER BRANCH C2 (`if routed is not None:`, `architecture.py:1951`):** this is the crucial
consumer of the router's `None` contract. When the router returns `None` (Retire / Retain), the
caller **does NOT override `skill_id`** — it leaves `skill_id = step_def["skill_id"]`
(`"target-architecture-blueprint"`, the declared base) as a **safety net**. The comment
(`architecture.py:1940-1947`) is explicit: *"when the router returns None (Retire / Retain
dispositions) it fell through — those dispositions should skip the step entirely at the caller
level, so fall back to the declared skill_id as a safety net."*

> ⚠️ **GOTCHA-AR7 (the `None` return means "skip the step", but the caller's safety net dispatches
> the BASE skill if the step runs anyway):** the router's own docstring
> (`architecture_patterns_router.py:29-34, 56-59`) says Retire/Retain callers MUST skip
> blueprint-assembly entirely. In a *healthy* workflow a Retire/Retain app never reaches the
> Architecture line at all, so this code path is not exercised. But `ArchitectureWorkflow._dispatch_agent`
> does NOT itself skip — it treats `None` as "use the declared base skill" (C2-false →
> `skill_id` unchanged). So the two layers have a **defense-in-depth** contract: (1) the line-level
> orchestration is expected to skip the step for Retire/Retain (the router signals this via `None`),
> and (2) if some caller ignores the skip rule (e.g. a disposition override during rework —
> `architecture_patterns_router.py:57-59`), the safety net dispatches the generic base blueprint
> rather than crashing on a `None` skill_id. A rebuild MUST preserve BOTH: the router returns `None`
> for Retire/Retain, AND the caller's `if routed is not None:` guard so a `None` never propagates
> into `AgentTaskInput.skill_id`.

> ⚠️ **GOTCHA-AR8 (`self._disposition` is the input the router keys on):** the caller passes
> `self._disposition` (`architecture.py:1950`) — an `ArchitectureWorkflow` instance var hydrated
> from the workflow input (the Rationalization disposition). It may be a `Disposition` enum value
> string like `"Refactor"`, a lower-cased variant, or `None`/empty for legacy callers / test
> fixtures / pre-wiring upstream runs (`architecture_patterns_router.py:9-13, 86-91`). The router's
> `_normalize` is what makes all three forms work. A rebuild must pass the workflow's disposition
> field, not the step name or skill id.

**Other references (non-call):** `architecture.py:407` is a comment cross-reference only (no call);
`tests/conftest.py:85` and `tests/test_architecture_workflow.py:313,1039` are test fixtures/comments
that document the router's role (no production call). The standalone unit suite
(`tests/test_architecture_patterns_router.py`, 13 tests) imports and exercises the function directly
with no Temporal harness.

---

## 7. RESILIENCE

- **Timeouts / heartbeats / continue-as-new:** N/A — synchronous pure function, no awaits, no
  activities, returns immediately.
- **Idempotency:** trivially idempotent and deterministic — same input always yields same output;
  no side effects; no mutation of `DISPOSITION_BLUEPRINT_MAP` (it is read-only at call time). Safe to
  call repeatedly across Temporal replays (it is effectively a constant lookup, so replay sees an
  identical result without any recorded history event).
- **Compensation / rollback:** N/A — no state to roll back.
- **Failure modes:** the function cannot raise under any input of type `str | None` — `_normalize`
  guards `None`/`""`, and the membership test plus fall-through cover every other string. (Passing a
  non-string non-`None` value, e.g. an int, would raise `AttributeError` on `.strip()` in the
  `_normalize` second branch — but the type contract is `str | None` and no caller violates it.)

> ⚠️ **GOTCHA-AR9 (deterministic & replay-safe precisely because it's pure):** because the router
> takes no `workflow.*` calls and reads only frozen module state, calling it inside
> `ArchitectureWorkflow._dispatch_agent` (which runs in the Temporal sandbox) is determinism-safe:
> it produces no command, no activity, no history event, and yields the identical skill id on
> original execution and on every replay. A rebuild MUST keep it pure for this reason — converting
> it to read a registry via an activity (the way a "dynamic" router might) would inject
> nondeterminism / an activity round-trip into the dispatch path.

---

## 8. Behavioral parity checklist

A rebuilt `architecture_patterns_router` MUST satisfy ALL of the following:

1. **Pure module, no Temporal imports.** Only `from __future__ import annotations`. Importable and
   callable with no Temporal worker / sandbox. (GOTCHA-AR0)
2. **Exactly two module-level names + one public function:** `DISPOSITION_BLUEPRINT_MAP`
   (`dict[str, str | None]`), `ARCHITECTURE_BLUEPRINT_DEFAULT_SKILL` (`str`), and
   `select_architecture_blueprint_skill(disposition: str | None) -> str | None`. A private
   `_normalize(value: str | None) -> str` helper.
3. **`DISPOSITION_BLUEPRINT_MAP` keys are lowercase** and map exactly: `refactor`→
   `target-architecture-blueprint-refactor`; `replatform`→`target-architecture-blueprint-replatform`;
   `rearchitect`/`replace`/`consolidate`→`target-architecture-blueprint-rearchitect`;
   `retire`→`None`; `retain`→`None`. (GOTCHA-AR1, AR2)
4. **`ARCHITECTURE_BLUEPRINT_DEFAULT_SKILL == "target-architecture-blueprint"`.**
5. **`_normalize`** returns `""` for `None` and `""` (the `if not value:` branch), else
   `value.strip().lower()`. `_normalize("   ")` returns `""` via the second line; `_normalize("  Refactor  ")`
   returns `"refactor"`. Uses `.strip().lower()` and `.lower()` (not `.casefold()`). (GOTCHA-AR4, AR5)
6. **`select_architecture_blueprint_skill` reproduces all 3 branch outcomes in order:**
   (B1) empty key → base default; (B2 true) key in map → `DISPOSITION_BLUEPRINT_MAP[key]` **including
   returning `None` for retire/retain**; (B2 false / fall-through) unknown key → base default.
   Uses the explicit `if key in MAP: return MAP[key]` form, not `.get(key, DEFAULT)`. (GOTCHA-AR1,
   AR3, AR6)
7. **Case-insensitive & whitespace-tolerant:** `"Refactor"`, `"refactor"`, `"REARCHITECT"`,
   `"rePlAtFoRm"`, `"  Refactor  "` all resolve to their specialist; `"   "` resolves to base.
8. **Never raises** on any `str | None` input. Unknown disposition → base default string, NOT an
   exception. (GOTCHA-AR3)
9. **`None` is a first-class return value** meaning "skip the blueprint step" (retire/retain), and is
   distinct from the base-default string returned for unknown/empty inputs.
10. **Determinism / replay safety:** no `workflow.*`, no I/O, no randomness, no mutation of the map.
    Same input → same output on original run and every replay; produces no Temporal history event.
    (GOTCHA-AR9)
11. **Caller-side contract (for the `ArchitectureWorkflow._dispatch_agent` rebuild, NOT this module):**
    the router is called ONLY for `step_name == "blueprint-assembly"` (`architecture.py:1949`), with
    `self._disposition`, and the `None` return is guarded by `if routed is not None: skill_id = routed`
    (`architecture.py:1951-1952`) so a `None` falls back to the declared base `skill_id`
    (`step_def["skill_id"]`) as a safety net. A `None` MUST NEVER reach `AgentTaskInput.skill_id`.
    (GOTCHA-AR7, AR8)
12. **Regression guard:** all 7 canonical lowercase keys (`refactor`, `rearchitect`, `replatform`,
    `replace`, `consolidate`, `retire`, `retain`) remain present in `DISPOSITION_BLUEPRINT_MAP`
    (mirrors `tests/test_architecture_patterns_router.py:124-137`).
