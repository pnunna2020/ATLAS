# `SustainmentWorkflow` — Portfolio-Wide Cron Sweep (ATOMIC regeneration spec)

> **Source of truth:** `temporal/olympus_workflows/workflows/sustainment.py` (665 lines). Every
> `sustainment.py:line` citation below is against that file.
>
> **What this is:** the continuous, portfolio-wide Sustainment-line workflow. Runs on a Temporal
> **Schedule** (NOT `@workflow.cron_schedule`) to keep legacy + modernized apps operational. Each
> scheduled invocation is **one discrete, bounded sweep** (not a long-running loop): intake →
> fan-out 5 agent activities in parallel → persist DB side-effects → commit a portfolio-wide
> summary + fire a completion signal. Returns `"completed"` or `"failed"` (`sustainment.py:216-217`).
>
> ⚠️ **GOTCHA-INHERIT (this does NOT extend `LineWorkflowBase`):** `SustainmentWorkflow` extends
> **`HILSignalsMixin` DIRECTLY** (`sustainment.py:170` — `class SustainmentWorkflow(HILSignalsMixin)`),
> NOT `LineWorkflowBase`. Consequences a rebuild MUST honor:
> - It does **NOT** inherit `gate_approved` / `gate_rejected` / `escalation_resolved` / `merge_retry`
>   (those live on `LineWorkflowBase`, see `_LineWorkflowBase.md` §3). **Sustainment has NO gates**
>   (`sustainment.py:634` — `pending_gate=None  # Sustainment has no gates.`). There is no gate wait,
>   no rework loop, no rework counter, no merge-blocked loop, no `_reconcile_and_merge_with_retry_loop`.
> - It **DOES** inherit the six HIL signals from `HILSignalsMixin` (`approve`, `cancel_workflow`,
>   `approve_plan`, `provide_plan_feedback`, `approve_research`, `provide_feedback`) and the eight
>   HIL state vars + the `reset_*` / `is_*_decision_received` helpers + the `create_*_signal`
>   factories. See `_HILSignalsMixin.md`. **None of these inherited signals are consumed by any
>   `wait_condition` in this workflow** — there are no blocking waits at all (see §3). They are
>   registered (so the workflow doesn't reject them) but functionally inert here, EXCEPT that a
>   rebuild MUST still keep `cancel_workflow` registered (parity: every Olympus workflow exposes it).
> - It defines its OWN `__init__`, `run`, `get_status`, `_set_step`, and one NEW signal
>   `override_approved` (NOT inherited). It does **not** override any `LineWorkflowBase` method
>   because it does not inherit from `LineWorkflowBase`. Where this spec says "overrides", it means
>   "shadows the conceptually-similar `LineWorkflowBase` member with a from-scratch implementation"
>   — the signatures/behaviors below are authoritative and INDEPENDENT of `_LineWorkflowBase.md`.
>
> **Determinism invariants:** the only time source is `_now_iso()` → `workflow.now().isoformat()`
> (`sustainment.py:662-664`). `json.dumps(..., indent=2)` is used for all artifact serialization
> (deterministic). Two `workflow.patched(...)` IDs gate the batch-vs-single write path. Activity
> imports are inside `with workflow.unsafe.imports_passed_through():` (`sustainment.py:58-80`).

---

## 0. Imports, module constants, and helper functions (`sustainment.py:49-166`, `651-664`)

### 0.1 Imports (`sustainment.py:49-80`)
- Top-level: `asyncio`, `json`, `from datetime import timedelta`, `from foundry_temporal.signals import
  HILSignalsMixin`, `from temporalio import workflow` (`sustainment.py:49-56`).
- ⚠️ **GOTCHA-IMP1 (sandbox-gated activity + type imports):** inside
  `with workflow.unsafe.imports_passed_through():` (`sustainment.py:58`): the activities
  `dispatch_agent_task`, `write_artifact`, `write_artifacts_batch`,
  `persist_sustainment_sweep_side_effects`; `RETRY_POLICIES`; and the types
  `AgentTaskInput`, `AgentTaskResult`, `AssemblyLine`, `CronWorkflowInput`, `OverrideApprovedSignal`,
  `PersistSustainmentSweepSideEffectsInput`, `SustainmentSweepCompletedSignal`, `WorkflowStatus`,
  `WorkflowStatusResponse`, `WriteArtifactInput`, `WriteArtifactsBatchInput` (`sustainment.py:59-80`).
  A rebuild MUST keep these inside `imports_passed_through()` so the Temporal sandbox doesn't
  re-import/re-execute them on replay.

### 0.2 `SUSTAINMENT_ACTIVITIES` — per-activity registry (`sustainment.py:86-107`)
`dict[str, dict[str, str]]` mapping activity-id → `{"skill_id", "artifact"}`. ⚠️ **The skill_id is
NOT always equal to the activity-id** — reproduce these mappings EXACTLY:

| activity-id (key) | `skill_id` | `artifact` (filename) |
|---|---|---|
| `cve-triage` | `patch-assessment` | `cve-triage.json` |
| `incident-response` | `incident-response` | `incident-response.json` |
| `sla-monitoring` | `sla-breach-investigation` | `sla-monitoring.json` |
| `change-conflict-detection` | `change-conflict-resolver` | `change-conflict.json` |
| `cost-anomaly-detection` | `cost-anomaly-investigation` | `cost-anomaly.json` |

> ⚠️ **GOTCHA-REG1 (artifact filename ≠ activity id for two activities):** `change-conflict-detection`
> writes `change-conflict.json` (not `change-conflict-detection.json`) and `cost-anomaly-detection`
> writes `cost-anomaly.json` (`sustainment.py:99-106`). A rebuild must use the literal `artifact`
> value, never derive the filename from the activity id.

### 0.3 `ACTIVITY_ORDER` — canonical order (`sustainment.py:113-119`)
`list[str] = ["cve-triage", "incident-response", "sla-monitoring", "change-conflict-detection",
"cost-anomaly-detection"]`. This is **the canonical iteration/serialization order** used by:
(a) `_activities_for_schedule` filter (preserves this order), (b) the sweep-summary `activities`
dict comprehension (`sustainment.py:493-503`), and (c) the `finding_counts` comprehension in the
completion signal (`sustainment.py:561-564`). ⚠️ **GOTCHA-ORD1:** the dashboard sparkline/trend
relies on a stable order across sweeps; a rebuild MUST iterate `ACTIVITY_ORDER`, never `dict.keys()`
of `SUSTAINMENT_ACTIVITIES` or the active set, when building summary/signal payloads.

### 0.4 `CANONICAL_STEPS` (`sustainment.py:124-129`)
`["intake", *ACTIVITY_ORDER, "persist-sustainment-sweep-side-effects", "commit-sweep-summary"]`
— the 8-step shape, documentary only (defines the FE stepRegistry alignment). Intake=seq 1; the 5
activities share seq 2 (parallel); persist=seq 3; commit-sweep-summary=seq 4. Not read by control
flow except via individual `_set_step(...)` calls.

### 0.5 `_SCHEDULE_CADENCE` — prefix→default activities (`sustainment.py:136-139`)
`dict[str, list[str]]`:
- `"sus-daily"` → `["cve-triage", "incident-response"]` (2 activities)
- `"sus-weekly"` → `list(ACTIVITY_ORDER)` (all 5)

### 0.6 `_activities_for_schedule(schedule_id, override=None) -> list[str]` (`sustainment.py:142-166`)
Module-level pure function. Resolves the active activity set. **5 branch-points** — reproduce ALL:

```text
def _activities_for_schedule(schedule_id, override=None):
    sid = (schedule_id or "").lower()                         # sustainment.py:155  (None-safe + lowercased)
    if sid.startswith("sus-adhoc"):                            # sustainment.py:156  BRANCH 1
        if override:                                           # sustainment.py:157  BRANCH 2 (truthy: non-empty list)
            picked = [a for a in ACTIVITY_ORDER if a in set(override)]   # sustainment.py:159  ← filter, KEEP canonical order
            return picked if picked else list(ACTIVITY_ORDER)  # sustainment.py:160  BRANCH 3 (ternary)
        return list(ACTIVITY_ORDER)                            # sustainment.py:161  (adhoc w/ no override → all 5)
    for prefix, cadence in _SCHEDULE_CADENCE.items():          # sustainment.py:162  LOOP
        if sid.startswith(prefix):                             # sustainment.py:163  BRANCH 4
            return list(cadence)                               # sustainment.py:164
    return list(ACTIVITY_ORDER)                                # sustainment.py:166  BRANCH 5 (unknown prefix → all 5, back-compat)
```

- **BRANCH 1** `sid.startswith("sus-adhoc")` → adhoc path.
  - **BRANCH 2** `if override:` — truthy check. An **empty** override list is falsy → falls through
    to `return list(ACTIVITY_ORDER)` (`sustainment.py:161`). A non-empty override enters the filter.
  - **BRANCH 3** `picked if picked else list(ACTIVITY_ORDER)` — if the override filtered to nothing
    (i.e. override contained only unknown activity names), fall back to all 5
    (`sustainment.py:160`). Otherwise return the filtered list **in `ACTIVITY_ORDER` order**.
- **BRANCH 4** prefix loop: first `_SCHEDULE_CADENCE` prefix that `sid` starts with wins — `sus-daily`
  → 2 activities, `sus-weekly` → 5. Returns a **copy** (`list(cadence)`).
- **BRANCH 5** none matched → `list(ACTIVITY_ORDER)` (all 5). ⚠️ **GOTCHA-SCH1 (unknown prefix ⇒ all
  5, NOT empty):** a `schedule_id` that matches no prefix (including empty string `""` after the
  `or ""`) defaults to all 5 activities for pre-W19 back-compat. A rebuild MUST default to all 5,
  never to empty/none.
- ⚠️ **GOTCHA-SCH2 (`set(override)` membership but `ACTIVITY_ORDER` ordering):** the filter is
  `[a for a in ACTIVITY_ORDER if a in set(override)]` — it iterates the canonical order and tests
  membership in the override set. So override ordering is irrelevant; canonical ordering is always
  preserved (`sustainment.py:159`). Duplicate names in override are de-duped by virtue of iterating
  `ACTIVITY_ORDER`. A rebuild must NOT iterate `override` directly.
- ⚠️ **GOTCHA-SCH3 (prefix match, not equality):** uses `str.startswith`, so `sus-daily-2026-06-14`,
  `sus-daily-fast`, etc. all match `"sus-daily"`. Likewise `"sus-adhoc"` matches `sus-adhoc-anything`.

### 0.7 `_sustainment_repo(portfolio_id) -> str` (`sustainment.py:651-659`)
`return f"olympus/{portfolio_id}-sustainment"`. ⚠️ **GOTCHA-REPO1:** the docstring says the
deployment "overrides this via the workflow input; the default value below is only used by tests"
— BUT **the code path always calls this helper**; `CronWorkflowInput` has no repo field
(`sustainment.py:2491-2504` in types.py: only `portfolio_id`, `schedule_id`, `triggered_at`,
`activities`). So in this code the repo is ALWAYS `f"olympus/{portfolio_id}-sustainment"`. A rebuild
must use this exact template. (The "override via input" is aspirational/doc-only; no input field
backs it.)

### 0.8 `_now_iso() -> str` (`sustainment.py:662-664`)
`return workflow.now().isoformat()`. Deterministic. ⚠️ Used everywhere a timestamp is stamped
(`_started_at`, `_updated_at`, `timestamp` fields, `sweep_completed_at`, `completed_at`, override
`timestamp`). NEVER use `datetime.now()`.

---

## 1. STATE — every instance var in `__init__` (`sustainment.py:183-205`)

`__init__` calls `super().__init__()` **first** (`sustainment.py:184`) so the 8 HIL vars from
`_HILSignalsMixin.md` (`approved`, `plan_approved`, `plan_feedback_received`,
`plan_feedback_comments`, `document_approved`, `document_feedback_received`,
`document_feedback_comments`, `cancelled`, all `False`/`""`) are initialized before the
Sustainment-specific state below. ⚠️ **GOTCHA-INIT1:** the `super().__init__()` call MUST be the
first statement (cooperative MI; see `_HILSignalsMixin.md` GOTCHA-0).

| Var | Type | Initial | Line | Mutated by → value | When |
|-----|------|---------|------|---------------------|------|
| `_portfolio_id` | `str` | `""` | 185 | `run()` → `input.portfolio_id` (`sustainment.py:221`) | run start |
| `_schedule_id` | `str` | `""` | 186 | `run()` → `input.schedule_id or "adhoc"` (`sustainment.py:222`) | run start |
| `_status` | `WorkflowStatus` | `WorkflowStatus.PENDING` | 187 | `run()`: `RUNNING` (218), `COMPLETED` (247), `FAILED` (252) | run start / end |
| `_current_step` | `str` | `""` | 188 | `_set_step` → `step` (`sustainment.py:646`); `run()` → `"completed"`/`"failed"` (248,253) | each step / end |
| `_progress_pct` | `float` | `0.0` | 189 | `_set_step` → `progress` (`sustainment.py:647`); `run()` → `100.0` (246) | each step / end |
| `_started_at` | `str` | `""` | 190 | `run()` → `_now_iso()` (`sustainment.py:219`) | run start |
| `_updated_at` | `str` | `""` | 191 | `run()` (219,249,254); `_set_step` (648); `override_approved` (619) | many |
| `_findings` | `dict[str, list[str]]` | `{}` | 194 | `_execute_parallel_activities._run_activity` → `[activity]=result.output_artifacts` (`sustainment.py:295`) | per activity |
| `_activity_metadata` | `dict[str, dict]` | `{}` | 195 | `_dispatch_activity` → `[activity]={model_used,duration_ms,token_usage_input/output,cost_estimate_usd}` (`sustainment.py:334-340`) | per dispatch |
| `_activity_artifacts` | `dict[str, str]` | `{}` | 199 | `_commit_activity_artifact` → `[activity]=content` (raw JSON str) (`sustainment.py:382`) | per commit |
| `_active_activities` | `list[str]` | `[]` | 202 | `_intake` → `_activities_for_schedule(...)` (`sustainment.py:274`) | intake |
| `_override_decisions` | `list[dict]` | `[]` | 205 | `override_approved` signal → `.append({...})` (`sustainment.py:608-618`) | on each override signal |

> ⚠️ **GOTCHA-STATE1 (`_completion_signal` is set but NOT declared in `__init__`):** the attribute
> `self._completion_signal` is assigned in `_fire_sweep_completed_signal` (`sustainment.py:589`) but
> is **never declared/initialized in `__init__`**. So before step 8 runs, the attribute does not
> exist. There is no query that reads it (the comment at `sustainment.py:586-588` calls it "the query
> path" but **no `@workflow.query` reads `_completion_signal`** in this file). It exists purely as a
> latch on workflow state for a future router. A rebuild MUST set `self._completion_signal =
> signal_payload` at exactly the same point and MUST NOT pre-declare it in `__init__` if it wants
> byte-parity with this code (functionally harmless either way, but no reader depends on it).
> ⚠️ **GOTCHA-STATE2 (`_activity_artifacts` is the read-side-cache that avoids a git round-trip):**
> `_commit_activity_artifact` caches the exact JSON string it commits into `_activity_artifacts`
> (`sustainment.py:381-382`) so step 7 (`_persist_sweep_side_effects`) can pass it to the DB-projection
> activity WITHOUT a `read_artifact` round-trip. A rebuild MUST populate this cache during the
> commit, keyed by activity id, with the **identical** string passed to the write activity.

---

## 2. SIGNALS / QUERIES — handlers (`sustainment.py:595-637`)

### 2.1 `override_approved(self, signal: OverrideApprovedSignal) -> None` — `@workflow.signal`, `sustainment.py:595-619`
**NEW signal, defined on this workflow** (not inherited). ⚠️ **GOTCHA-SIG-ASYNC:** it is declared
`async def` (`sustainment.py:596`) — unlike the HIL mixin's synchronous handlers — but contains no
`await`. Payload `OverrideApprovedSignal` (fields: `gate_id: str`, `override_by: str`,
`justification: str`, `override_type: OverrideType`; `types.py:144-151`).

```text
async def override_approved(self, signal):
    self._override_decisions.append({                          # sustainment.py:608
        "gate_id":       signal.gate_id,                       # sustainment.py:609
        "override_by":   signal.override_by,                   # sustainment.py:610
        "justification": signal.justification,                 # sustainment.py:611
        "override_type": (                                     # sustainment.py:612-616  BRANCH
            signal.override_type.value
            if hasattr(signal.override_type, "value")
            else str(signal.override_type)
        ),
        "timestamp": _now_iso(),                               # sustainment.py:617
    })
    self._updated_at = _now_iso()                              # sustainment.py:619
```

- **1 branch** (`sustainment.py:612-616`): `signal.override_type.value if hasattr(signal.override_type,
  "value") else str(signal.override_type)`. ⚠️ **GOTCHA-OVR1 (enum-or-string normalization):** the
  signal type annotation is `OverrideType` (an `(str, enum.Enum)` with values `critical_patch`,
  `executive_override`, `time_sensitive`; `types.py:108-113`). But the handler defensively accepts a
  plain string too: if the value has a `.value` attribute (i.e. it IS the enum), use `.value`; else
  `str(...)`. A rebuild MUST keep this `hasattr(...,"value")` fork so a string-valued override (sent
  by an older client / serialized form) still records correctly as a lowercase string.
- **Buffers:** appends a 6-key dict to `self._override_decisions` (a `list[dict]`). Each entry:
  `gate_id`, `override_by`, `justification`, `override_type` (normalized string), `timestamp`
  (ISO via `_now_iso()`). Also bumps `_updated_at`.
- ⚠️ **GOTCHA-OVR2 (consumed by TWO downstream readers, NEVER by a wait_condition):**
  `_override_decisions` is read by (a) step 7 `_persist_sweep_side_effects` →
  `override_decisions=list(self._override_decisions)` (`sustainment.py:449`), and (b) step 8
  `_commit_sweep_summary` → `"override_decisions": self._override_decisions` (`sustainment.py:504`)
  and the `critical_findings` roll-up in `_fire_sweep_completed_signal` (`sustainment.py:565-570`).
  There is **NO `wait_condition` waiting on this signal**. The signal is fire-and-forget: whatever
  overrides arrive **before** steps 7/8 run get recorded; later arrivals are lost (the sweep has
  already committed). A rebuild must NOT add a wait for this signal — the sweep does not block on
  human override; overrides are opportunistically folded into the summary if they arrived in time.
- ⚠️ **GOTCHA-OVR3 (`list(...)` snapshot at persist, live ref at commit):** step 7 passes a **copy**
  (`list(self._override_decisions)`, `sustainment.py:449`); step 8 embeds the **live list reference**
  in the summary dict (`sustainment.py:504`). Both run after the parallel gather, so in practice they
  see the same set; the copy at persist is defensive. A rebuild should reproduce the `list(...)` copy
  at persist and the direct reference at commit (both serialize identically via `json.dumps`).

### 2.2 Inherited HIL signals (from `HILSignalsMixin`, registered, functionally inert here)
`approve`, `cancel_workflow`, `approve_plan`, `provide_plan_feedback`, `approve_research`,
`provide_feedback` are inherited and registered as `@workflow.signal`. ⚠️ **GOTCHA-HIL-INERT:** none
of the eight HIL state vars they mutate (incl. `cancelled`) is read by ANY `wait_condition` or branch
in this workflow — there are no blocking waits (§3). Even `cancelled` does nothing here: setting it
does not interrupt the synchronous step chain. A rebuild MUST still register `cancel_workflow`
(parity with the rest of the platform; clients may send it) but is NOT required to thread `cancelled`
into anything, because the original doesn't. Do **not** redefine these (duplicate registration would
crash — see `_HILSignalsMixin.md`).

### 2.3 `get_status(self) -> WorkflowStatusResponse` — `@workflow.query`, `sustainment.py:625-637`
**Defined on this workflow** (it does NOT inherit `LineWorkflowBase.get_status` since it doesn't
extend that base). Synchronous, read-only.

```text
@workflow.query
def get_status(self):
    return WorkflowStatusResponse(
        workflow_id  = workflow.info().workflow_id,    # sustainment.py:629
        status       = self._status,                   # sustainment.py:630
        current_line = AssemblyLine.SUSTAINMENT,        # sustainment.py:631  ← hard-coded enum, not a classvar
        current_step = self._current_step,             # sustainment.py:632
        progress_pct = self._progress_pct,             # sustainment.py:633
        pending_gate = None,                            # sustainment.py:634  ← ALWAYS None (no gates)
        started_at   = self._started_at,               # sustainment.py:635
        updated_at   = self._updated_at,                # sustainment.py:636
    )
```

- ⚠️ **GOTCHA-Q1 (`current_line` is hard-coded `AssemblyLine.SUSTAINMENT`, `pending_gate` is hard-coded
  `None`):** unlike `LineWorkflowBase.get_status` which reads `self.ASSEMBLY_LINE` / `self._pending_gate`,
  this one passes the literal enum value and literal `None` (`sustainment.py:631,634`). Sustainment has
  no `_pending_gate` instance var at all. A rebuild MUST hard-code both.
- ⚠️ **GOTCHA-Q2 (reads live mutable state):** returns current `_status`/`_current_step`/`_progress_pct`/
  `_updated_at`. A dashboard polling during the parallel-activity phase sees `status=RUNNING`,
  `current_step=<one of the 5 activities>` (whichever `_run_activity` last called `_set_step` — see
  GOTCHA-PARALLEL2), `progress_pct=<self._progress_pct as it was at intake — see GOTCHA-PARALLEL1>`.
- No other queries. No update handlers.

---

## 3. CONTROL FLOW — `run()` and the step chain (`sustainment.py:211-255`)

> **No blocking `wait_condition` anywhere in this workflow.** The entire run is a linear `await`
> chain of activity calls (with one `asyncio.gather` fan-out). The only suspension points are the
> activity executions themselves. There is no gate wait, no signal wait, no continue-as-new.

### 3.1 `run(self, input: CronWorkflowInput) -> str` — `@workflow.run`, `sustainment.py:211-255`

```text
@workflow.run
async def run(self, input):
    self._status = WorkflowStatus.RUNNING            # sustainment.py:218
    self._started_at = _now_iso()                    # sustainment.py:219
    self._updated_at = self._started_at              # sustainment.py:220
    self._portfolio_id = input.portfolio_id          # sustainment.py:221
    self._schedule_id = input.schedule_id or "adhoc" # sustainment.py:222  ← BRANCH (falsy → "adhoc")

    try:                                             # sustainment.py:224
        await self._intake(input)                                  # sustainment.py:229  Step 1
        await self._execute_parallel_activities(input)             # sustainment.py:232  Steps 2-6
        await self._persist_sweep_side_effects(input)              # sustainment.py:238  Step 7
        await self._commit_sweep_summary(input)                    # sustainment.py:244  Step 8

        self._progress_pct = 100.0                   # sustainment.py:246
        self._status = WorkflowStatus.COMPLETED      # sustainment.py:247
        self._current_step = "completed"             # sustainment.py:248
        self._updated_at = _now_iso()                # sustainment.py:249
        return "completed"                           # sustainment.py:250
    except Exception:                                # sustainment.py:251  BRANCH (catch-all)
        self._status = WorkflowStatus.FAILED         # sustainment.py:252
        self._current_step = "failed"                # sustainment.py:253
        self._updated_at = _now_iso()                # sustainment.py:254
        raise                                        # sustainment.py:255  ← RE-RAISES
```

**Branch inventory in `run()` (2):**
1. `input.schedule_id or "adhoc"` (`sustainment.py:222`) — if `schedule_id` is falsy (empty/`""`),
   defaults to the literal `"adhoc"`. ⚠️ **GOTCHA-RUN1:** `"adhoc"` (no `sus-` prefix) does NOT match
   any `_SCHEDULE_CADENCE` prefix and does NOT start with `"sus-adhoc"`, so `_activities_for_schedule`
   falls to BRANCH 5 → **all 5 activities** (back-compat). I.e. an unscheduled/manual run executes the
   full sweep. A rebuild MUST default the schedule id to the literal `"adhoc"` (which then drives the
   "run all 5" back-compat path), not to empty.
2. `except Exception: ... raise` (`sustainment.py:251-255`) — catch-all that sets terminal FAILED
   status + step then **re-raises** the original exception so Temporal records the workflow as failed.

> ⚠️ **GOTCHA-RUN2 (ordering of terminal mutations on failure):** on the failure path the order is
> `_status=FAILED` → `_current_step="failed"` → `_updated_at=_now_iso()` → `raise`. The `raise` is
> unconditional and re-raises whatever propagated out of any step. A rebuild MUST set the three state
> vars BEFORE re-raising, so a final `get_status` query (Temporal still answers queries on a failed
> workflow's last state) shows `FAILED`/`"failed"`.
> ⚠️ **GOTCHA-RUN3 (no rollback / no compensation):** there is no try/except/finally compensation. If
> step 8 fails after step 7 persisted DB rows, those rows stay (step 7 is best-effort anyway — see
> §3.4). The only "cleanup" is the FAILED status. A rebuild adds no rollback.
> ⚠️ **GOTCHA-RUN4 (steps are strictly sequential; only 2-6 fan out internally):** `run()` awaits the
> four step methods in order. The parallelism is entirely INSIDE `_execute_parallel_activities`. A
> rebuild MUST keep intake → (parallel 5) → persist → commit strictly ordered; e.g. persist must see
> all `_activity_artifacts` populated, which requires the gather to have fully completed first.

### 3.2 Step 1 — `_intake(self, input)` (`sustainment.py:261-282`)
Code-kind step. No agent dispatch, no artifact write, no `wait_condition`.

```text
async def _intake(self, input):
    self._set_step("intake", 5.0)                              # sustainment.py:272
    override = list(input.activities) if input.activities else None   # sustainment.py:273  BRANCH (ternary)
    self._active_activities = _activities_for_schedule(        # sustainment.py:274
        self._schedule_id, override)
    workflow.logger.info("sustainment intake: portfolio=%s schedule=%s activities=%s",
        input.portfolio_id, self._schedule_id, self._active_activities)   # sustainment.py:277-282
```

- **1 branch** (`sustainment.py:273`): `override = list(input.activities) if input.activities else None`.
  An empty `input.activities` (the default; `CronWorkflowInput.activities` defaults to `[]`,
  `types.py:2504`) → `override=None`. A non-empty list → a **copy** of it.
- ⚠️ **GOTCHA-INTAKE1 (`override` is a copy, then `_activities_for_schedule` makes ANOTHER copy):** the
  `list(input.activities)` defensively copies before passing to the resolver, which itself returns a
  fresh list. `_active_activities` is thus independent of the input. A rebuild should copy here.
- Calls `_set_step("intake", 5.0)` → sets `_current_step="intake"`, `_progress_pct=5.0`, bumps
  `_updated_at`.

### 3.3 Steps 2-6 — `_execute_parallel_activities(self, input)` (`sustainment.py:288-304`)

```text
async def _execute_parallel_activities(self, input):
    async def _run_activity(activity):                         # sustainment.py:292  inner coro
        self._set_step(activity, self._progress_pct)           # sustainment.py:293  ← passes CURRENT pct
        result = await self._dispatch_activity(activity, input) # sustainment.py:294
        self._findings[activity] = result.output_artifacts     # sustainment.py:295
        await self._commit_activity_artifact(activity, result, input)   # sustainment.py:296

    if self._active_activities:                                # sustainment.py:301  BRANCH
        await asyncio.gather(                                  # sustainment.py:302
            *[_run_activity(a) for a in self._active_activities])   # sustainment.py:303
```

- **1 branch** (`sustainment.py:301`): `if self._active_activities:` — only gathers if the active set
  is non-empty. ⚠️ **GOTCHA-PARALLEL0 (empty set ⇒ no-op):** if `_active_activities` is empty, the
  gather is skipped entirely and zero activities run. Given GOTCHA-SCH1 (unknown/empty schedule → all
  5) and GOTCHA-SCH3, the only realistic way to reach an empty set is an adhoc schedule whose override
  filtered to nothing — but BRANCH 3 of `_activities_for_schedule` falls back to all 5 in that case
  too. So in practice the set is non-empty; the guard is defensive. Reproduce it anyway.
- **Per-activity inner coroutine `_run_activity(activity)`** does, in order: (1) `_set_step(activity,
  self._progress_pct)`, (2) `await _dispatch_activity(...)`, (3) record `_findings[activity] =
  result.output_artifacts`, (4) `await _commit_activity_artifact(...)`.
- ⚠️ **GOTCHA-PARALLEL1 (`_set_step` passes `self._progress_pct` — progress does NOT advance during
  fan-out):** each `_run_activity` calls `_set_step(activity, self._progress_pct)` — i.e. it re-uses
  the CURRENT `_progress_pct` (which is `5.0` from intake, or whatever a concurrently-running sibling
  last set it to) as the new progress. **Progress does not climb through the 5 activities.** The 5
  coroutines all read+write the same `_progress_pct`, so it just churns at ~5.0. The next real
  progress jump is step 7 (`92.0`). A rebuild MUST pass `self._progress_pct` (not a per-activity
  computed value) here, to match the (intentionally flat) progress behavior during the parallel strip.
- ⚠️ **GOTCHA-PARALLEL2 (concurrent mutation of shared dicts is SAFE under Temporal's single-threaded
  event loop):** all 5 `_run_activity` coroutines mutate `self._findings`, `self._activity_metadata`,
  `self._activity_artifacts`, `self._current_step`, `self._progress_pct`, `self._updated_at`. This is
  safe because Temporal workflow coroutines run cooperatively on ONE thread — only one coroutine runs
  between `await` points; there is no preemption and no data race. Each coroutine writes its OWN key in
  the dicts (`[activity]=...`), so even interleaving at `await` boundaries can't corrupt another
  activity's entry. ⚠️ The LAST coroutine to execute its `_set_step` before the gather resolves
  determines the final `_current_step` value — this is **nondeterministic in wall-clock terms but
  DETERMINISTIC under Temporal replay** (the event-loop scheduling order is recorded in history). A
  rebuild MUST run these as concurrent coroutines via `asyncio.gather`, NOT serialize them, or the
  recorded interleaving (and thus the activity-start ordering in history) changes.
- ⚠️ **GOTCHA-PARALLEL3 (gather has no `return_exceptions` — first failure cancels the rest & fails the
  workflow):** `asyncio.gather(*coros)` is called WITHOUT `return_exceptions=True` (`sustainment.py:302`).
  So if any one `_run_activity` raises (e.g. its `dispatch_agent_task` exhausts the `agent_failure`
  retries, or its `write_artifact` exhausts `transient`), `gather` propagates that exception, the other
  coroutines are cancelled, and the exception bubbles to `run()`'s `except Exception` → workflow
  FAILED. There is NO per-activity error isolation in the sweep. A rebuild MUST NOT add
  `return_exceptions=True` — a failing critical activity (e.g. CVE triage) is meant to fail the sweep.

### 3.3.1 `_dispatch_activity(self, activity, input) -> AgentTaskResult` (`sustainment.py:306-341`)

```text
async def _dispatch_activity(self, activity, input):
    act_def = SUSTAINMENT_ACTIVITIES[activity]                 # sustainment.py:310
    task_input = AgentTaskInput(
        task_type    = f"sustainment-{activity}",              # sustainment.py:312
        app_id       = "",                                     # sustainment.py:313  ← portfolio-scoped, no app
        skill_id     = act_def["skill_id"],                    # sustainment.py:314
        input_artifacts = [],                                  # sustainment.py:315
        artifact_repo   = "",                                  # sustainment.py:316
        artifact_ref    = "",                                  # sustainment.py:317
        workspace_key   = f"sustainment-{input.portfolio_id}-{self._schedule_id}",  # sustainment.py:318-320
        context = {                                            # sustainment.py:321-325
            "portfolio_id": input.portfolio_id,
            "schedule_id":  self._schedule_id,
            "triggered_at": input.triggered_at,
        },
    )
    result = await workflow.execute_activity(                  # sustainment.py:327
        dispatch_agent_task, task_input,
        start_to_close_timeout = timedelta(hours=1),           # sustainment.py:330
        retry_policy = RETRY_POLICIES["agent_failure"],        # sustainment.py:331
        activity_id  = f"sustainment-{activity}",              # sustainment.py:332
    )
    self._activity_metadata[activity] = {                      # sustainment.py:334-340
        "model_used":         result.model_used,
        "duration_ms":        result.duration_ms,
        "token_usage_input":  result.token_usage_input,
        "token_usage_output": result.token_usage_output,
        "cost_estimate_usd":  result.cost_estimate_usd,
    }
    return result
```

- **No branches.** Pure dispatch + metadata recording.
- ⚠️ **GOTCHA-DISP1 (`app_id=""`, no `execution_context`, no `wave_id`):** Sustainment is
  portfolio-scoped, so `app_id=""` and the dataclass's `wave_id` defaults to `""`. **`execution_context`
  is NOT set** (defaults to `None`, `types.py:504`). Unlike `LineWorkflowBase._dispatch_agent` which
  threads `execution_context=self._execution_ctx(...)`, this dispatch emits NO Layer-B `step_execution`
  row (there's no `_execution_ctx` helper on this workflow at all). A rebuild MUST leave
  `execution_context` unset (None) here. (The dashboard renders the per-activity strip from the
  `step_execution` rows the activities emit by other means / from the artifact, per the module
  docstring's "per_activity_parallel FanoutBlock" note — but THIS code does not construct one.)
- ⚠️ **GOTCHA-DISP2 (`task_type` = `sustainment-{activity}`, `activity_id` = `sustainment-{activity}`):**
  both the agent `task_type` (`sustainment.py:312`) and the Temporal `activity_id` (`sustainment.py:332`)
  are `f"sustainment-{activity}"` (e.g. `sustainment-cve-triage`). The deterministic `activity_id`
  makes each agent dispatch idempotent/replay-stable per activity. A rebuild MUST use this exact id.
- ⚠️ **GOTCHA-DISP3 (`workspace_key` = `sustainment-{portfolio_id}-{schedule_id}`):** all 5 activities
  in one sweep SHARE the same workspace key (`sustainment.py:318-320`) — they operate on the shared
  portfolio inventory in one agent workspace. A rebuild MUST use the portfolio+schedule-scoped key,
  identical across the 5 dispatches of a sweep.
- **`_activity_metadata[activity]`** records 5 fields (NO `output_files` — unlike
  `LineWorkflowBase._dispatch_agent` which records 6 fields incl. `output_files`). A rebuild MUST
  record exactly these 5 keys.

**Activity call:** `dispatch_agent_task(task_input)`; `start_to_close_timeout=1 hour`; retry
`agent_failure` (initial 5s, backoff 2.0, max 60s, **3 attempts**; `retry_policies.py:37-42`);
`activity_id=f"sustainment-{activity}"`. No `non_retryable_error_types`. No heartbeat.

### 3.3.2 `_commit_activity_artifact(self, activity, result, input)` (`sustainment.py:343-414`)

```text
async def _commit_activity_artifact(self, activity, result, input):
    act_def  = SUSTAINMENT_ACTIVITIES[activity]                # sustainment.py:355
    repo     = _sustainment_repo(input.portfolio_id)           # sustainment.py:356  → olympus/{pid}-sustainment
    branch   = f"sustainment/{input.portfolio_id}/{self._schedule_id}"        # sustainment.py:357
    path     = f"sustainment/{input.portfolio_id}/{self._schedule_id}/{act_def['artifact']}"  # sustainment.py:358-361
    metadata = self._activity_metadata.get(activity, {})       # sustainment.py:362

    content = json.dumps({                                     # sustainment.py:364-379
        "activity":      activity,
        "skill_id":      act_def["skill_id"],
        "portfolio_id":  input.portfolio_id,
        "schedule_id":   self._schedule_id,
        "triggered_at":  input.triggered_at,
        "findings":      result.output_artifacts,
        "model_used":    metadata.get("model_used", ""),
        "duration_ms":   metadata.get("duration_ms", 0),
        "token_usage":   {"input":  metadata.get("token_usage_input", 0),
                          "output": metadata.get("token_usage_output", 0)},
        "cost_estimate_usd": metadata.get("cost_estimate_usd", 0.0),
        "timestamp":     workflow.now().isoformat(),           # sustainment.py:378  deterministic
    }, indent=2)

    self._activity_artifacts[activity] = content               # sustainment.py:382  ← cache for step 7

    if workflow.patched("sustainment-batch-writes-v1"):        # sustainment.py:384  BRANCH (patch gate)
        await workflow.execute_activity(
            write_artifacts_batch,
            WriteArtifactsBatchInput(repo=repo, branch=branch,
                files=[(path, content)],
                commit_message=f"sustainment({input.portfolio_id}): {activity} sweep"),  # sustainment.py:392-393
            start_to_close_timeout=timedelta(seconds=120),     # sustainment.py:395
            retry_policy=RETRY_POLICIES["transient"],          # sustainment.py:396
            activity_id=f"commit-sustainment-{activity}",      # sustainment.py:397
        )
    else:
        await workflow.execute_activity(
            write_artifact,
            WriteArtifactInput(repo=repo, branch=branch, path=path, content=content,
                commit_message=f"sustainment({input.portfolio_id}): {activity} sweep"),  # sustainment.py:402-409
            start_to_close_timeout=timedelta(seconds=60),      # sustainment.py:411
            retry_policy=RETRY_POLICIES["transient"],          # sustainment.py:412
            activity_id=f"commit-sustainment-{activity}",      # sustainment.py:413
        )
```

- **1 branch** (`sustainment.py:384`): `if workflow.patched("sustainment-batch-writes-v1"):` —
  **patch-gated** choice between the batch-write activity and the single-write activity.
  - ⚠️ **GOTCHA-PATCH1 (patch ID verbatim & load-bearing):** `workflow.patched("sustainment-batch-writes-v1")`
    (`sustainment.py:384`, also at `sustainment.py:507`). A rebuild MUST use this EXACT string in BOTH
    `_commit_activity_artifact` and `_commit_sweep_summary`. Pre-patch in-flight runs replay on the
    `write_artifact` (single) path; post-patch runs use `write_artifacts_batch`. Changing/removing the
    patch ID breaks replay determinism for in-flight histories.
  - **Patched (true) branch:** `write_artifacts_batch` with `WriteArtifactsBatchInput(repo, branch,
    files=[(path, content)], commit_message=...)`; **120s** timeout; `transient` retry;
    `activity_id=f"commit-sustainment-{activity}"`. (Single-element `files` list — batch API with one
    file.)
  - **Unpatched (false) branch:** `write_artifact` with `WriteArtifactInput(repo, branch, path, content,
    commit_message=...)`; **60s** timeout; `transient` retry; SAME `activity_id=f"commit-sustainment-{activity}"`.
  - ⚠️ **GOTCHA-PATCH2 (same `activity_id`, different timeout, both branches):** both branches use the
    identical `activity_id=f"commit-sustainment-{activity}"` but different timeouts (120s batch vs 60s
    single). A rebuild MUST keep the activity_id identical across branches (so the commit is the "same"
    logical activity regardless of patch state) and the per-branch timeouts as listed.
- ⚠️ **GOTCHA-COMMIT1 (`commit_message` has the literal `{activity}` substituted, NOT the artifact name):**
  `f"sustainment({input.portfolio_id}): {activity} sweep"` (`sustainment.py:392-393, 407-409`) — uses the
  activity id (e.g. `cve-triage`), not the filename. Reproduce exactly.
- ⚠️ **GOTCHA-COMMIT2 (`metadata.get(...)` defaults must match):** the JSON uses `metadata.get("model_used","")`,
  `.get("duration_ms",0)`, `.get("token_usage_input",0)`, `.get("token_usage_output",0)`,
  `.get("cost_estimate_usd",0.0)` — string default `""`, int defaults `0`, float default `0.0`. Since
  `_dispatch_activity` always populates `_activity_metadata[activity]` BEFORE this method runs (same
  coroutine, sequential), the `.get` defaults are effectively dead — but a rebuild MUST keep the exact
  default literals so a hypothetical missing-key case serializes byte-identically.
- ⚠️ **GOTCHA-COMMIT3 (artifact `timestamp` uses `workflow.now().isoformat()` inline, NOT `_now_iso()`):**
  `sustainment.py:378` calls `workflow.now().isoformat()` directly (not the `_now_iso()` helper). They
  are identical in effect; reproduce either — both are deterministic. Noted only because the rest of
  the file uses `_now_iso()`.
- **Branch/path layout:** repo=`olympus/{pid}-sustainment`; branch=`sustainment/{pid}/{schedule_id}`;
  path=`sustainment/{pid}/{schedule_id}/{artifact-filename}`. ⚠️ **GOTCHA-COMMIT4:** branch and path
  prefix are identical except path appends the filename; all 5 activities commit to the SAME branch.
  A rebuild MUST use this branch/path scheme exactly (the Sustainment repo is the compliance system of
  record). NOTE there is NO `execution_context` on either write input here (defaults `None`).

### 3.4 Step 7 — `_persist_sweep_side_effects(self, input)` (`sustainment.py:420-463`)
Best-effort DB projection.

```text
async def _persist_sweep_side_effects(self, input):
    self._set_step("persist-sustainment-sweep-side-effects", 92.0)   # sustainment.py:431
    payload = PersistSustainmentSweepSideEffectsInput(
        portfolio_id        = input.portfolio_id,                    # sustainment.py:433
        schedule_id         = self._schedule_id,                     # sustainment.py:434
        sweep_completed_at  = _now_iso(),                            # sustainment.py:435
        cve_triage_json     = self._activity_artifacts.get("cve-triage", ""),         # sustainment.py:436
        incident_response_json = self._activity_artifacts.get("incident-response", ""),  # sustainment.py:437-439
        sla_monitoring_json = self._activity_artifacts.get("sla-monitoring", ""),     # sustainment.py:440-442
        change_conflict_json = self._activity_artifacts.get("change-conflict-detection", ""),  # sustainment.py:443-445
        cost_anomaly_json   = self._activity_artifacts.get("cost-anomaly-detection", ""),  # sustainment.py:446-448
        override_decisions  = list(self._override_decisions),        # sustainment.py:449
    )
    try:                                                             # sustainment.py:451
        await workflow.execute_activity(
            persist_sustainment_sweep_side_effects, payload,
            start_to_close_timeout=timedelta(seconds=60),            # sustainment.py:455
            retry_policy=RETRY_POLICIES["transient"],                # sustainment.py:456
            activity_id="persist-sustainment-sweep-side-effects",    # sustainment.py:457
        )
    except Exception as exc:                                         # sustainment.py:459  BRANCH (best-effort swallow)
        workflow.logger.warning(
            "persist_sustainment_sweep_side_effects failed — continuing: %s", exc)  # sustainment.py:460-463
```

- **1 branch** (`sustainment.py:459`): `except Exception as exc:` — ⚠️ **GOTCHA-PERSIST1 (best-effort,
  swallows ALL exceptions):** the entire activity call is wrapped in try/except that logs a warning and
  **continues** — it does NOT re-raise. So a DB failure here does NOT fail the sweep; step 8 still runs.
  This mirrors the Discovery/Rationalization side-effect-projection pattern (`sustainment.py:425-429`).
  A rebuild MUST swallow the exception (broad `except Exception`) and continue. Note the `# noqa: BLE001`
  in source acknowledges the intentional blind-except.
- ⚠️ **GOTCHA-PERSIST2 (the JSON-field mapping uses ACTIVITY-ID keys, not skill ids):** the
  `_activity_artifacts.get(...)` keys are the activity ids (`cve-triage`, `incident-response`,
  `sla-monitoring`, `change-conflict-detection`, `cost-anomaly-detection`) — each mapped to a
  SPECIFICALLY-NAMED payload field (`cve_triage_json`, `incident_response_json`, `sla_monitoring_json`,
  `change_conflict_json`, `cost_anomaly_json`). ⚠️ The payload field names are abbreviated for two:
  `change_conflict_json` (key `change-conflict-detection`) and `cost_anomaly_json` (key
  `cost-anomaly-detection`). A rebuild MUST wire each activity-id key to its exact payload field; an
  activity that didn't run this sweep yields `""` (the `.get(..., "")` default).
- ⚠️ **GOTCHA-PERSIST3 (`sweep_completed_at` here is a SEPARATE `_now_iso()` from step 8's):** step 7
  stamps `sweep_completed_at=_now_iso()` (`sustainment.py:435`) and step 8 also stamps its own
  `completed_at`/`sweep_completed_at` via `_now_iso()` (`sustainment.py:491, 574`). These are taken at
  different points in the run, so they may differ slightly. A rebuild must call `_now_iso()` at each
  site independently — do NOT compute one timestamp and reuse it across steps.
- Calls `_set_step("persist-sustainment-sweep-side-effects", 92.0)` first → progress jumps to 92.0.

**Activity call:** `persist_sustainment_sweep_side_effects(payload)`; **60s** timeout; `transient`
retry (3 attempts); `activity_id="persist-sustainment-sweep-side-effects"`. Wrapped in try/except
(best-effort). The activity itself is also documented best-effort (swallows DB failures) per
`PersistSustainmentSweepSideEffectsInput` docstring (`types.py:2507-2529`) — projects into 6 tables
(`patching_compliance`, `incident_log`, `sla_compliance_record`, `do_not_modify_flag`,
`cost_anomaly_record`, `sustainment_override_log`) plus rolls `application.sustainment_current_status`
+ `sustainment_last_sweep_at`.

### 3.5 Step 8 — `_commit_sweep_summary(self, input)` (`sustainment.py:469-545`)

```text
async def _commit_sweep_summary(self, input):
    self._set_step("commit-sweep-summary", 96.0)               # sustainment.py:480
    repo   = _sustainment_repo(input.portfolio_id)             # sustainment.py:481
    branch = f"sustainment/{input.portfolio_id}/{self._schedule_id}"   # sustainment.py:482
    path   = f"sustainment/{input.portfolio_id}/{self._schedule_id}/sweep-summary.json"  # sustainment.py:483-486
    summary = {                                                # sustainment.py:487-505
        "portfolio_id":     input.portfolio_id,
        "schedule_id":      self._schedule_id,
        "triggered_at":     input.triggered_at,
        "completed_at":     _now_iso(),                        # sustainment.py:491
        "active_activities": list(self._active_activities),    # sustainment.py:492
        "activities": {                                        # sustainment.py:493-503  DICT-COMPREHENSION over ACTIVITY_ORDER
            activity: {
                "artifact":       SUSTAINMENT_ACTIVITIES[activity]["artifact"],
                "skill_id":       SUSTAINMENT_ACTIVITIES[activity]["skill_id"],
                "findings_count": len(self._findings.get(activity, [])),     # sustainment.py:497-499
                "ran":            activity in self._active_activities,        # sustainment.py:500  BRANCH (membership)
            }
            for activity in ACTIVITY_ORDER                     # sustainment.py:502  ← ALL 5, not just active
        },
        "override_decisions": self._override_decisions,        # sustainment.py:504  ← live ref
    }
    summary_content = json.dumps(summary, indent=2)            # sustainment.py:506
    if workflow.patched("sustainment-batch-writes-v1"):        # sustainment.py:507  BRANCH (patch gate)
        await workflow.execute_activity(
            write_artifacts_batch,
            WriteArtifactsBatchInput(repo=repo, branch=branch, files=[(path, summary_content)],
                commit_message=f"sustainment({input.portfolio_id}): {self._schedule_id} sweep summary"),  # sustainment.py:514-517
            start_to_close_timeout=timedelta(seconds=120),     # sustainment.py:519
            retry_policy=RETRY_POLICIES["transient"],          # sustainment.py:520
            activity_id="commit-sweep-summary",                # sustainment.py:521
        )
    else:
        await workflow.execute_activity(
            write_artifact,
            WriteArtifactInput(repo=repo, branch=branch, path=path, content=summary_content,
                commit_message=f"sustainment({input.portfolio_id}): {self._schedule_id} sweep summary"),  # sustainment.py:530-533
            start_to_close_timeout=timedelta(seconds=60),      # sustainment.py:536
            retry_policy=RETRY_POLICIES["transient"],          # sustainment.py:537
            activity_id="commit-sweep-summary",                # sustainment.py:538
        )

    await self._fire_sweep_completed_signal(input, summary)    # sustainment.py:545
```

- **2 branches:**
  1. `"ran": activity in self._active_activities` (`sustainment.py:500`) — per-activity boolean inside
     the comprehension. ⚠️ **GOTCHA-SUMMARY1 (summary enumerates ALL 5 activities, `ran` marks which
     executed):** the `activities` dict iterates `ACTIVITY_ORDER` (all 5), NOT `_active_activities`
     (`sustainment.py:502`). For each, `ran` is `True` iff it was in the active set. So a daily sweep's
     summary lists all 5 with `ran: true` for `cve-triage`/`incident-response` and `ran: false` for the
     other 3. `findings_count` for a non-run activity is `len([])==0` (its `_findings` key was never
     set; `.get(activity, [])`). A rebuild MUST enumerate all 5 in canonical order with per-activity
     `ran` flags, not just the active subset.
  2. `if workflow.patched("sustainment-batch-writes-v1"):` (`sustainment.py:507`) — same patch gate as
     §3.3.2 (GOTCHA-PATCH1). Patched → `write_artifacts_batch` (120s); unpatched → `write_artifact`
     (60s). Both use `activity_id="commit-sweep-summary"`.
- ⚠️ **GOTCHA-SUMMARY2 (`commit_message` for the summary uses `{schedule_id}`, not the activity):**
  `f"sustainment({input.portfolio_id}): {self._schedule_id} sweep summary"` (`sustainment.py:514-517,
  530-533`). Reproduce exactly.
- ⚠️ **GOTCHA-SUMMARY3 (summary written to `sweep-summary.json` on the SAME branch as the 5 activity
  artifacts):** path=`sustainment/{pid}/{schedule_id}/sweep-summary.json`; same repo/branch
  (`sustainment.py:481-486`). The summary is the 6th file on that branch. A rebuild MUST write it to
  this exact path.
- After the write, ALWAYS calls `_fire_sweep_completed_signal(input, summary)` (`sustainment.py:545`)
  — see §3.6. ⚠️ **GOTCHA-SUMMARY4 (signal fired AFTER the commit succeeds):** the signal/state latch
  happens only after the summary write returns (i.e. if the write fails and exhausts `transient`, the
  exception propagates to `run()` and the signal is never fired/latched). A rebuild MUST order the
  commit before the signal fire.
- Calls `_set_step("commit-sweep-summary", 96.0)` first → progress 96.0 (then `run()` sets 100.0 on
  success).

### 3.6 `_fire_sweep_completed_signal(self, input, summary)` (`sustainment.py:547-589`)

```text
async def _fire_sweep_completed_signal(self, input, summary):
    finding_counts = {                                         # sustainment.py:561-564  DICT-COMPREHENSION over ACTIVITY_ORDER
        activity: summary["activities"][activity]["findings_count"]
        for activity in ACTIVITY_ORDER
    }
    critical_findings = sum(                                   # sustainment.py:565-570
        1
        for dec in self._override_decisions
        if (dec.get("override_type") or "").lower()            # sustainment.py:568-569  BRANCH (membership test)
           in {"critical_patch", "executive_override"}
    )
    signal_payload = SustainmentSweepCompletedSignal(          # sustainment.py:571-577
        portfolio_id       = input.portfolio_id,
        schedule_id        = self._schedule_id,
        sweep_completed_at = _now_iso(),                       # sustainment.py:574
        finding_counts     = finding_counts,
        critical_findings  = critical_findings,
    )
    workflow.logger.info("sustainment sweep completed signal: ...",
        signal_payload.portfolio_id, signal_payload.schedule_id,
        signal_payload.finding_counts, signal_payload.critical_findings)   # sustainment.py:578-585
    self._completion_signal = signal_payload                   # sustainment.py:589  ← LATCH on workflow state
```

- **1 branch** (`sustainment.py:568-569`): the generator's `if (dec.get("override_type") or
  "").lower() in {"critical_patch", "executive_override"}` — counts how many override decisions are of
  type `critical_patch` OR `executive_override`. ⚠️ **GOTCHA-SIGFIRE1 (only 2 of 3 override types count
  as "critical"):** `OverrideType` has THREE values (`critical_patch`, `executive_override`,
  `time_sensitive`; `types.py:108-113`), but `critical_findings` counts ONLY `critical_patch` and
  `executive_override` — `time_sensitive` is NOT counted. A rebuild MUST use exactly this 2-element set.
  The `(dec.get("override_type") or "").lower()` defensively handles a missing/None override_type
  (→ `""`, not in the set) and normalizes case (already lowercased by `override_approved`, but
  re-lowered defensively).
- ⚠️ **GOTCHA-SIGFIRE2 (this does NOT actually `signal_external_workflow`):** despite the method name
  "fire ... signal", it does **NOT** call `workflow.signal_external_workflow` or
  `get_external_workflow_handle(...).signal(...)`. It only (a) builds the `SustainmentSweepCompletedSignal`
  payload, (b) logs it, and (c) stores it on `self._completion_signal` (`sustainment.py:589`). The
  docstring (`sustainment.py:552-560, 586-588`) explains: there's no known external target (Governance
  may or may not be running), so the payload is captured in workflow state for a future router /
  scheduler to forward via `signal_external_workflow` "once Governance subscribes". TODAY it is a
  no-op beyond the state latch + log. A rebuild MUST NOT emit an external signal here; it MUST latch
  the payload on `self._completion_signal` and log. (This is the only "emission" — behavioral parity =
  state latch + log, NOT an actual cross-workflow signal.)
- ⚠️ **GOTCHA-SIGFIRE3 (`finding_counts` mirrors `summary["activities"][a]["findings_count"]` for all
  5):** built by re-reading the summary dict that step 8 just constructed, over `ACTIVITY_ORDER`
  (`sustainment.py:561-564`). So `finding_counts` always has all 5 keys (non-run activities → 0). A
  rebuild MUST key it over all 5 in canonical order.
- ⚠️ **GOTCHA-SIGFIRE4 (`sweep_completed_at` is yet ANOTHER `_now_iso()`):** taken here
  (`sustainment.py:574`), distinct from step 7's and step 8's. See GOTCHA-PERSIST3.
- `SustainmentSweepCompletedSignal` fields (`types.py:308-328`): `portfolio_id: str`, `schedule_id:
  str`, `sweep_completed_at: str`, `finding_counts: dict[str,int]={}`, `critical_findings: int=0`.

### 3.7 `_set_step(self, step, progress)` (`sustainment.py:643-648`)
⚠️ **GOTCHA-SETSTEP1 (this is SYNCHRONOUS, unlike `LineWorkflowBase._set_step` which is async):**

```text
def _set_step(self, step, progress):                           # sustainment.py:643  (def, NOT async def)
    self._current_step  = step                                 # sustainment.py:646
    self._progress_pct  = progress                             # sustainment.py:647
    self._updated_at    = _now_iso()                           # sustainment.py:648
```

- **No branches.** Pure state mutation. ⚠️ **GOTCHA-SETSTEP2 (NO DB write — Sustainment has no per-app
  status row):** unlike `LineWorkflowBase._set_step` which `await self._update_app_status(...)` when
  `_app_id` is set, this version does **NOT** push to the DB at all (`sustainment.py:644-645` comment:
  "no DB write — Sustainment has no per-app application status row"). It is therefore not a coroutine.
  A rebuild MUST make it synchronous and DB-free. (Callers `await` nothing on it — they call it
  directly, e.g. `self._set_step("intake", 5.0)`.)
- ⚠️ **GOTCHA-SETSTEP3 (does NOT mutate `_status`):** like the base, `_set_step` never changes
  `_status`; `run()` owns `RUNNING`/`COMPLETED`/`FAILED`.

**Progress map (the `progress` arg per `_set_step` call):** intake → `5.0` (`sustainment.py:272`);
each parallel activity → `self._progress_pct` (i.e. ~5.0, flat — GOTCHA-PARALLEL1) (`sustainment.py:293`);
persist → `92.0` (`sustainment.py:431`); commit-sweep-summary → `96.0` (`sustainment.py:480`); then
`run()` sets `100.0` on success (`sustainment.py:246`).

---

## 4. ACTIVITY & CHILD-WORKFLOW CALLS — full inventory (in execution order)

**No child workflows.** Sustainment is a leaf workflow (it dispatches agents + writes git + projects
DB; it starts no child workflows and does not continue-as-new).

| # | Activity | When / order | Args | Timeout (start_to_close) | Retry policy | `activity_id` | Parallel? | non_retryable |
|---|----------|--------------|------|--------------------------|--------------|---------------|-----------|----------------|
| 1 | `dispatch_agent_task` | Step 2-6, one per active activity | `AgentTaskInput(task_type="sustainment-{a}", app_id="", skill_id=<reg>, input_artifacts=[], artifact_repo="", artifact_ref="", workspace_key="sustainment-{pid}-{sid}", context={portfolio_id, schedule_id, triggered_at})` | **1 hour** | `agent_failure` (3 attempts, 5→60s) | `sustainment-{a}` | **YES** — all active activities via `asyncio.gather` | none |
| 2 | `write_artifacts_batch` **OR** `write_artifact` | Per activity, right after its dispatch | batch: `WriteArtifactsBatchInput(repo, branch, files=[(path, content)], commit_message)` / single: `WriteArtifactInput(repo, branch, path, content, commit_message)` | **120s** (batch) / **60s** (single) | `transient` (3 attempts) | `commit-sustainment-{a}` | within each activity's coroutine, after its dispatch; the 5 run concurrently | none |
| 3 | `persist_sustainment_sweep_side_effects` | Step 7 (after gather completes) | `PersistSustainmentSweepSideEffectsInput(portfolio_id, schedule_id, sweep_completed_at, cve_triage_json, incident_response_json, sla_monitoring_json, change_conflict_json, cost_anomaly_json, override_decisions)` | **60s** | `transient` (3 attempts) | `persist-sustainment-sweep-side-effects` | sequential (after gather) | none — wrapped in try/except (best-effort) |
| 4 | `write_artifacts_batch` **OR** `write_artifact` | Step 8 (after persist) | batch/single as #2 but `files=[(path, summary_content)]` / single content=`summary_content`; path=`.../sweep-summary.json` | **120s** (batch) / **60s** (single) | `transient` (3 attempts) | `commit-sweep-summary` | sequential | none |

- **Retry policy specifics:**
  - `agent_failure` = `AGENT_FAILURE_RETRY_POLICY`: initial 5s, backoff 2.0, max 60s, **3 attempts**, no
    non_retryable list (`retry_policies.py:37-42`).
  - `transient` = `HTTP_RETRY_POLICY` (foundry-temporal): per `_LineWorkflowBase.md` initial 1s, backoff
    2.0, max 15s, **3 attempts** (`retry_policies.py:33`).
- ⚠️ **GOTCHA-ACT1 (the commit activity (#2) selection is patch-gated PER CALL):** every per-activity
  commit AND the summary commit re-evaluates `workflow.patched("sustainment-batch-writes-v1")`. All
  calls in a single replay see the same patch result (patch decisions are recorded once in history),
  so a given run is consistently all-batch or all-single. A rebuild evaluates the patch at each call
  site (matches source) — they will agree within a run.
- ⚠️ **GOTCHA-ACT2 (no `execution_context` on ANY write/dispatch in this workflow):** every
  `AgentTaskInput`/`WriteArtifactInput`/`WriteArtifactsBatchInput` leaves `execution_context` at its
  `None` default. So this workflow emits NO Layer-B `step_execution` rows from the workflow side. A
  rebuild MUST leave it unset (None) on all four activity-input types.

---

## 5. GATE HANDLING

**NONE.** ⚠️ **GOTCHA-GATE0 (Sustainment has zero gates):** there is no gate PR creation, no evidence
assembly, no `_wait_for_gate_decision`, no rework loop, no rework counter, no merge-blocked loop, no
`gate_approved`/`gate_rejected` signals (it does not inherit them — §0/GOTCHA-INHERIT). `get_status`
hard-codes `pending_gate=None` (`sustainment.py:634`). The `override_approved` signal (§2.1) is the
ONLY human-decision surface, and it is **non-blocking** (the sweep never waits for it — GOTCHA-OVR2).
A rebuild MUST NOT add any gate machinery. The "override" concept here is purely an audit record folded
into the summary + DB, NOT a gate that pauses execution.

> Contrast with `_LineWorkflowBase.md` §13/§14/§17 (gate wait / merge loop / rework counter): NONE of
> that applies to Sustainment. If a rebuild inherits from a shared base, it must ensure those gate
> paths are simply never invoked for this workflow.

---

## 6. RESILIENCE

- **Timeouts (start_to_close):** `dispatch_agent_task` 1 hour; per-activity commit 120s (batch) / 60s
  (single); `persist_sustainment_sweep_side_effects` 60s; summary commit 120s (batch) / 60s (single).
- **Heartbeats:** none configured. Relies on start_to_close timeouts.
- **continue-as-new:** NONE. Each sweep is a single bounded run; cadence comes from the external
  Temporal Schedule, not from continue-as-new or `@workflow.cron_schedule` (`sustainment.py:35-42`).
- **Idempotency / replay-stability:** deterministic `activity_id`s — `sustainment-{activity}` (dispatch),
  `commit-sustainment-{activity}` (per-activity commit), `persist-sustainment-sweep-side-effects`,
  `commit-sweep-summary`. All timestamps via `_now_iso()`/`workflow.now()`. Patch IDs
  (`sustainment-batch-writes-v1`) gate the write-path choice. A rebuild MUST keep all activity ids
  and patch ids verbatim.
- **Best-effort / swallowed failures:** ONLY step 7 (`_persist_sweep_side_effects`) swallows exceptions
  (try/except + warning, continue — GOTCHA-PERSIST1). Everything else propagates: a dispatch or commit
  failure (after exhausting retries) fails the whole sweep via `gather` (GOTCHA-PARALLEL3) → `run()`
  `except` → FAILED + re-raise.
- **Compensation / rollback:** NONE (GOTCHA-RUN3). No cleanup beyond setting `_status=FAILED`. DB rows
  written by step 7 are not rolled back if step 8 fails (and step 7 is best-effort anyway).
- **Cancellation:** `cancel_workflow` is inherited and registered, but `self.cancelled` is read by NO
  `wait_condition`/branch here (GOTCHA-HIL-INERT) — there are no blocking waits to interrupt. A cancel
  request thus has no in-workflow effect beyond Temporal's own cancellation scope handling of the
  in-flight activity. A rebuild keeps the signal registered for parity but is not required to thread
  `cancelled` anywhere (the source doesn't).
- **Determinism quirk — parallel interleaving:** the 5 `_run_activity` coroutines' interleaving order
  is recorded in history and replayed identically; a rebuild MUST use `asyncio.gather` (not a serial
  loop, not threads) so the activity-scheduling order in history matches (GOTCHA-PARALLEL2).

---

## 7. OVERRIDE/SHADOW MATRIX vs `LineWorkflowBase`/`HILSignalsMixin`

Since `SustainmentWorkflow` does NOT extend `LineWorkflowBase`, the table below clarifies which
conceptually-similar members it re-implements from scratch vs inherits from `HILSignalsMixin`.

| Member | In `SustainmentWorkflow` | Source of behavior |
|--------|--------------------------|--------------------|
| `__init__` | **own** (`sustainment.py:183-205`) | calls `super().__init__()` (HILSignalsMixin) then sets 12 own vars |
| `run` / `@workflow.run` | **own** (`sustainment.py:211-255`) | from-scratch; `LineWorkflowBase` has none |
| `get_status` / `@workflow.query` | **own** (`sustainment.py:625-637`) | from-scratch; hard-codes line+`pending_gate=None` (NOT inherited from base) |
| `_set_step` | **own, SYNCHRONOUS, DB-free** (`sustainment.py:643-648`) | differs from base's async/DB version (GOTCHA-SETSTEP1/2) |
| `override_approved` / `@workflow.signal` | **own NEW signal** (`sustainment.py:595-619`) | not in base or mixin |
| `approve`, `cancel_workflow`, `approve_plan`, `provide_plan_feedback`, `approve_research`, `provide_feedback` | **inherited** from `HILSignalsMixin` | registered, functionally inert here (GOTCHA-HIL-INERT) |
| `reset_*` / `is_*_decision_received` / `create_*_signal` | **inherited** (unused) | `HILSignalsMixin` |
| `gate_approved` / `gate_rejected` / `escalation_resolved` / `merge_retry` | **NOT present** | only on `LineWorkflowBase`; Sustainment has no gates |
| `_dispatch_agent` / `_commit_step_artifacts` / `_wait_for_gate_decision` / `_reconcile_and_merge_with_retry_loop` / `_build_evidence_data` / `_execution_ctx` / `_update_app_status` / `_bump_rework` | **NOT present** | base-only; Sustainment uses its own `_dispatch_activity`/`_commit_activity_artifact` |

---

## 8. Behavioral parity checklist

A rebuilt `SustainmentWorkflow` MUST satisfy ALL of the following:

1. **Inheritance:** `class SustainmentWorkflow(HILSignalsMixin)` — NOT `LineWorkflowBase`. `__init__`
   calls `super().__init__()` FIRST, then initializes exactly these 12 vars to: `_portfolio_id=""`,
   `_schedule_id=""`, `_status=PENDING`, `_current_step=""`, `_progress_pct=0.0`, `_started_at=""`,
   `_updated_at=""`, `_findings={}`, `_activity_metadata={}`, `_activity_artifacts={}`,
   `_active_activities=[]`, `_override_decisions=[]`. `_completion_signal` is NOT declared in `__init__`
   (set later in step 8). (GOTCHA-INHERIT, GOTCHA-INIT1, GOTCHA-STATE1)
2. **No gates, no waits:** zero `wait_condition` calls; no gate signals; `get_status` hard-codes
   `current_line=AssemblyLine.SUSTAINMENT` and `pending_gate=None`. `override_approved` never blocks
   the run. (GOTCHA-GATE0, GOTCHA-Q1, GOTCHA-OVR2)
3. **`run()`** sets `RUNNING`+`_started_at`+`_updated_at`+`_portfolio_id`, sets
   `_schedule_id = input.schedule_id or "adhoc"`, then awaits `_intake` → `_execute_parallel_activities`
   → `_persist_sweep_side_effects` → `_commit_sweep_summary` strictly in order; on success sets
   `progress=100.0`/`COMPLETED`/`"completed"` and returns `"completed"`; on ANY exception sets
   `FAILED`/`"failed"`/`_updated_at` and **re-raises**. (GOTCHA-RUN1..4)
4. **Activity selection** via `_activities_for_schedule(schedule_id, override)`: lowercases+None-safes
   the id; `sus-adhoc*` → filtered override (canonical-ordered) or all-5 fallback (empty/all-unknown);
   `sus-daily*` → `[cve-triage, incident-response]`; `sus-weekly*` → all 5; any other (incl. `"adhoc"`,
   empty) → all 5. The override filter iterates `ACTIVITY_ORDER` testing membership in `set(override)`.
   (GOTCHA-SCH1/2/3, GOTCHA-RUN1)
5. **`SUSTAINMENT_ACTIVITIES` registry** exact: `cve-triage→patch-assessment/cve-triage.json`,
   `incident-response→incident-response/incident-response.json`,
   `sla-monitoring→sla-breach-investigation/sla-monitoring.json`,
   `change-conflict-detection→change-conflict-resolver/change-conflict.json`,
   `cost-anomaly-detection→cost-anomaly-investigation/cost-anomaly.json`. `ACTIVITY_ORDER` = those 5
   keys in this order. (GOTCHA-REG1, GOTCHA-ORD1)
6. **Intake** calls `_set_step("intake", 5.0)`; `override = list(input.activities) if input.activities
   else None`; sets `_active_activities = _activities_for_schedule(_schedule_id, override)`; logs.
7. **Parallel fan-out:** `if self._active_activities: await asyncio.gather(*[_run_activity(a) for a in
   _active_activities])` — NO `return_exceptions`. Each `_run_activity(a)` calls
   `_set_step(a, self._progress_pct)` (flat progress), awaits `_dispatch_activity`, sets
   `_findings[a]=result.output_artifacts`, awaits `_commit_activity_artifact`. (GOTCHA-PARALLEL0..3)
8. **`_dispatch_activity`** builds `AgentTaskInput(task_type=f"sustainment-{a}", app_id="",
   skill_id=reg.skill_id, input_artifacts=[], artifact_repo="", artifact_ref="",
   workspace_key=f"sustainment-{pid}-{sid}", context={portfolio_id, schedule_id, triggered_at})`,
   `execution_context` unset; dispatches `dispatch_agent_task` with **1h** timeout, `agent_failure`
   retry, `activity_id=f"sustainment-{a}"`; records `_activity_metadata[a]` = 5 fields
   (`model_used, duration_ms, token_usage_input, token_usage_output, cost_estimate_usd`). Returns
   result. (GOTCHA-DISP1/2/3, GOTCHA-ACT2)
9. **`_commit_activity_artifact`** computes repo=`olympus/{pid}-sustainment`,
   branch=`sustainment/{pid}/{sid}`, path=`sustainment/{pid}/{sid}/{artifact}`; builds the 11-key JSON
   (`activity, skill_id, portfolio_id, schedule_id, triggered_at, findings, model_used, duration_ms,
   token_usage{input,output}, cost_estimate_usd, timestamp`) via `json.dumps(..., indent=2)` with the
   exact `.get` defaults; **caches it into `_activity_artifacts[a]`**; then patch-gated
   (`sustainment-batch-writes-v1`) writes via `write_artifacts_batch` (120s) or `write_artifact` (60s),
   both `transient`, both `activity_id=f"commit-sustainment-{a}"`,
   commit_message=`sustainment({pid}): {a} sweep`. (GOTCHA-STATE2, GOTCHA-COMMIT1..4, GOTCHA-PATCH1/2)
10. **Step 7 `_persist_sweep_side_effects`** calls `_set_step("persist-sustainment-sweep-side-effects",
    92.0)`; builds `PersistSustainmentSweepSideEffectsInput` mapping each activity-id key →
    its named JSON field (`cve-triage→cve_triage_json`, `incident-response→incident_response_json`,
    `sla-monitoring→sla_monitoring_json`, `change-conflict-detection→change_conflict_json`,
    `cost-anomaly-detection→cost_anomaly_json`, each via `_activity_artifacts.get(k,"")`),
    `sweep_completed_at=_now_iso()`, `override_decisions=list(self._override_decisions)`; calls
    `persist_sustainment_sweep_side_effects` (60s, `transient`, `activity_id=
    "persist-sustainment-sweep-side-effects"`) inside a **try/except that swallows and logs**, never
    re-raising. (GOTCHA-PERSIST1/2/3)
11. **Step 8 `_commit_sweep_summary`** calls `_set_step("commit-sweep-summary", 96.0)`; builds the
    summary dict with `completed_at=_now_iso()`, `active_activities=list(self._active_activities)`, an
    `activities` dict-comprehension over **ACTIVITY_ORDER (all 5)** with per-activity
    `{artifact, skill_id, findings_count=len(_findings.get(a,[])), ran=(a in _active_activities)}`, and
    `override_decisions=self._override_decisions`; `json.dumps(..., indent=2)`; patch-gated writes to
    path `sustainment/{pid}/{sid}/sweep-summary.json` via batch (120s) or single (60s),
    `activity_id="commit-sweep-summary"`, commit_message=`sustainment({pid}): {sid} sweep summary`;
    THEN awaits `_fire_sweep_completed_signal(input, summary)`. (GOTCHA-SUMMARY1..4)
12. **`_fire_sweep_completed_signal`** builds `finding_counts` over ACTIVITY_ORDER from
    `summary["activities"][a]["findings_count"]`; computes `critical_findings = sum(1 for dec in
    _override_decisions if (dec.get("override_type") or "").lower() in {"critical_patch",
    "executive_override"})` (only those TWO types; NOT `time_sensitive`); builds
    `SustainmentSweepCompletedSignal(portfolio_id, schedule_id, sweep_completed_at=_now_iso(),
    finding_counts, critical_findings)`; logs it; **stores it on `self._completion_signal`**. It does
    NOT call `signal_external_workflow` — emission == state latch + log only. (GOTCHA-SIGFIRE1..4)
13. **`override_approved`** is an `async def @workflow.signal` taking `OverrideApprovedSignal`; appends
    a 6-key dict (`gate_id, override_by, justification, override_type` [`.value` if enum else `str()`],
    `timestamp=_now_iso()`) to `_override_decisions`; bumps `_updated_at`. Never consumed by a wait.
    (GOTCHA-OVR1/2/3, GOTCHA-SIG-ASYNC)
14. **`get_status`** is the only `@workflow.query`, synchronous, returns `WorkflowStatusResponse(
    workflow_id=workflow.info().workflow_id, status=_status, current_line=AssemblyLine.SUSTAINMENT,
    current_step=_current_step, progress_pct=_progress_pct, pending_gate=None, started_at=_started_at,
    updated_at=_updated_at)`. (GOTCHA-Q1/Q2)
15. **`_set_step`** is SYNCHRONOUS (`def`), DB-free, sets `_current_step`/`_progress_pct`/`_updated_at`
    only; never touches `_status`. (GOTCHA-SETSTEP1/2/3)
16. **Patch IDs verbatim:** `"sustainment-batch-writes-v1"` at BOTH commit sites. Activity imports inside
    `with workflow.unsafe.imports_passed_through():`. All timestamps via `_now_iso()`/`workflow.now()`.
17. **Progress sequence:** intake 5.0 → activities flat (`self._progress_pct`, ~5.0) → persist 92.0 →
    commit-sweep-summary 96.0 → 100.0 on success. (GOTCHA-PARALLEL1)
18. **No child workflows, no continue-as-new, no heartbeats, no rollback.** First activity failure in
    the parallel gather (after retries) fails the whole sweep; step-7 DB failure is the ONLY swallowed
    failure. (§6, GOTCHA-PARALLEL3, GOTCHA-RUN3)
