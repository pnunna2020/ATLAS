# `RationalizationWorkflow` — Rationalization Assembly Line (ATOMIC regeneration spec)

> **Source of truth:** `temporal/olympus_workflows/workflows/rationalization.py` (789 lines).
> Every `rationalization.py:line` citation below is against that file.
>
> **What this is:** the per-app workflow that drives the Rationalization assembly line:
> Redundancy Analysis → Gate **G-RR** → Disposition Recommendation → Disposition Governance →
> User Impact (Retire/Replace only) → Classification (+ Tier-1 stakeholder pause) → Gate **G-DA**
> (`rationalization.py:1-15`, `102-119`). Despite the module docstring calling it "cross-portfolio"
> (`rationalization.py:2-4`), the **live `run()` is per-app**: it reads `input.app_id` and threads
> a single `app_id` through every step (`rationalization.py:167-176`). The wave-wide N×N analysis
> lives in the separate `WaveRationalizationWorkflow`; this class is the per-app inheritor named in
> `_LineWorkflowBase.md` §0.
>
> **Inherits:** `class RationalizationWorkflow(LineWorkflowBase)` (`rationalization.py:103`), which
> inherits `HILSignalsMixin`. **Read `_LineWorkflowBase.md` and `_HILSignalsMixin.md` for all
> inherited behavior** — this spec reproduces ONLY this subclass's own code (`__init__`, `run`,
> `_execute_rationalization`, the `_rework_gate_key_for_step` override, the extra
> `stakeholder_approved` signal, the two PR-body builders, and three module-level helpers) and
> states exactly which base methods it overrides.
>
> **Determinism:** uses `_now_iso()` (= `workflow.now().isoformat()`, imported from
> `olympus_workflows.workflows.base`, `rationalization.py:27`) for every timestamp; activity
> imports are gated behind `with workflow.unsafe.imports_passed_through():` (`rationalization.py:29-49`).
> Two `workflow.patched(...)` gates appear (`"gda-dual-signal-v1"`, `rationalization.py:559,582`).

---

## 0. Decorator, MRO, and what is/ isn't overridden

- `@workflow.defn` (`rationalization.py:102`), `class RationalizationWorkflow(LineWorkflowBase)`
  (`rationalization.py:103`).

### 0.1 Base methods this subclass OVERRIDES

| Method | Base default (`_LineWorkflowBase.md`) | This override | Cite |
|--------|----------------------------------------|---------------|------|
| `_rework_gate_key_for_step(step_name)` | returns `self.SINGLE_GATE_KEY` (or `None`) | `return "G-RR" if step_name == "redundancy-analysis" else "G-DA"` | `rationalization.py:133-135` |
| `__init__` | sets 19 line-state vars after `super().__init__()` | calls `super().__init__()` then adds 4 subclass vars (§2) | `rationalization.py:137-151` |
| `run()` / `_execute()` | **absent on base** (every subclass supplies its own) | `@workflow.run run()` (§4) delegating to `_execute_rationalization` (§5) | `rationalization.py:153-664` |

> ⚠️ **GOTCHA-RAT-OV1 (`_rework_gate_key_for_step` is a TWO-gate map, NOT `SINGLE_GATE_KEY`):**
> this workflow does **not** set `SINGLE_GATE_KEY`. It overrides the hook so that ONLY the
> `redundancy-analysis` step routes its rework feedback to `G-RR`; **every other step**
> (`disposition-recommendation`, `disposition-governance`, `user-impact`, `classification`) routes
> to `G-DA` (`rationalization.py:133-135`). Because `_dispatch_agent` (base §8) reads
> `_rework_gate_key_for_step(step)` then `_rework_feedback.get(gate)` to decide whether to attach
> `context["rework_feedback"]`, this map is what makes a G-DA rejection's structured feedback flow
> into the re-dispatched disposition/governance/impact steps — and a G-RR rejection's feedback flow
> only into the re-dispatched redundancy step. A rebuild MUST reproduce this exact string map; using
> `SINGLE_GATE_KEY` would mis-route feedback.

### 0.2 Base methods this subclass does NOT override (uses base default)

`_task_type_prefix` (→ `ARTIFACT_ROOT="rationalization"`), `_primary_skill_for_step`
(→ `STEPS[step]["skill_id"]`; works because every step here has a scalar `skill_id`),
`_evidence_step_metadata`, `_evidence_steps_iter` (→ `STEPS.items()`), `_execution_ctx`,
`_set_step`, `_update_app_status`, `_dispatch_agent`, `_commit_step_artifacts`, `_create_gate_pr`,
`_submit_gate_evidence`, `_run_gate_pre_review`, `_wait_for_gate_decision`,
`_reconcile_and_merge_with_retry_loop`, `_build_evidence_data`, `_rework_count`, `_bump_rework`,
`get_status` (the ONLY base query). All used as documented in `_LineWorkflowBase.md`.

> ⚠️ **GOTCHA-RAT-OV2 (MUST NOT redefine the 4 base gate signals or `get_status`):** per
> `_LineWorkflowBase.md` GOTCHA-SIG0 / GOTCHA-Q1, `gate_approved`, `gate_rejected`,
> `escalation_resolved`, `merge_retry`, and `get_status` are registered on the base. This subclass
> adds exactly ONE new `@workflow.signal` — `stakeholder_approved` (§3) — and **does not** redefine
> any of those five. A rebuild that re-decorates them crashes on duplicate registration. (Note: the
> docstring at `rationalization.py:79-87` even comments that `_evidence_steps_iter` is NOT overridden
> here despite "Rationalization excludes governance" claims elsewhere — in THIS file all 5 steps stay
> in `STEPS` and the default iterator is used.)

---

## 1. CLASSVARS — the base-config knobs (`rationalization.py:122-127`) + module constants

| Classvar | Value | Cite |
|----------|-------|------|
| `ASSEMBLY_LINE` | `AssemblyLine.RATIONALIZATION` | `rationalization.py:122` |
| `ARTIFACT_ROOT` | `"rationalization"` | `rationalization.py:123` |
| `LINE_LABEL` | `"Rationalization"` | `rationalization.py:124` |
| `STATUS_PREFIX` | `"rationalization"` | `rationalization.py:125` |
| `STEPS` | `RATIONALIZATION_SKILLS` (5-entry dict, below) | `rationalization.py:126` |
| `STEP_WEIGHTS` | module `STEP_WEIGHTS` (7-entry dict, below) | `rationalization.py:127` |
| `SINGLE_GATE_KEY` | **NOT set** (overrides `_rework_gate_key_for_step` instead) | — |

### 1.1 `RATIONALIZATION_SKILLS` — `STEPS` map (`rationalization.py:56-77`)

Keys are the `step_name` strings passed to `_dispatch_agent`; each value is
`{skill_id, artifact}`. The `skill_id` is what `_primary_skill_for_step` returns; `artifact` is the
JSON filename committed.

| step_name | `skill_id` | `artifact` |
|-----------|-----------|-----------|
| `redundancy-analysis` | `redundancy-analyzer` | `redundancy-matrix.json` |
| `disposition-recommendation` | `disposition-recommender` | `disposition-recommendation.json` |
| `disposition-governance` | `disposition-governance` | `disposition-governance.json` |
| `user-impact` | `assess-user-impact` | `user-impact-analysis.json` |
| `classification` | `classify-application` | `classification.json` |

> Note (`rationalization.py:51-55`): step 1 uses `redundancy-analyzer`'s three-perspective method
> (entity / operation / persona overlap). The prior duplicate `analyze-portfolio-redundancy` skill
> was removed in P3.5-R1.7. ⚠️ **GOTCHA-RAT-CV1:** the `artifact` value in `STEPS` is **not** read by
> the per-step commit calls in `run()` — `run()` builds artifact paths from string literals (e.g.
> `f"rationalization/{app_id}/redundancy-matrix.json"`, `rationalization.py:219`). The `artifact`
> field is consumed by base `_evidence_step_metadata`/`_build_evidence_data` (the reviewer card
> label), not by the commit path. A rebuild must keep BOTH (the literal paths AND the `STEPS`
> `artifact` values) in sync — they happen to match by filename.

### 1.2 `STEP_WEIGHTS` — progress weights (`rationalization.py:88-96`)

Sum = 100. **Read only by this subclass's `run()` to compute the `progress` arg to `_set_step`** —
base never reads `STEP_WEIGHTS` (base GOTCHA-CV1).

| key | weight | role in progress math |
|-----|--------|------------------------|
| `detect-redundancy` | 20.0 | step-1 start = 0.0; after-G-RR base |
| `gate-review-rr` | 15.0 | added after G-RR approval |
| `recommend-disposition` | 18.0 | disposition step |
| `disposition-governance` | 8.0 | silent sub-phase of recommend-disposition |
| `assess-user-impact` | 12.0 | user-impact step |
| `classification` | 10.0 | classification step |
| `gate-review-da` | 17.0 | G-DA review |

> ⚠️ **GOTCHA-RAT-CV2 (UI step-id coupling):** these keys MUST equal the dashboard step-registry IDs
> in `dashboard/src/components/WorkflowStepper/stepRegistry.ts` so the stepper can match the
> `current_step` written by `_set_step` (`rationalization.py:79-87`). The one exception is
> `disposition-governance`: it is a **silent sub-phase** — the workflow keeps `current_step` as the
> string `"recommend-disposition"` across BOTH the disposition AND governance dispatches
> (`rationalization.py:358-365`), only ticking `progress` up. The `disposition-governance` weight
> (8.0) is consumed numerically but never emitted as a `current_step` string. A rebuild must keep the
> exact step-id strings AND keep governance visible to the UI as `recommend-disposition`.

> ⚠️ **GOTCHA-RAT-CV3 (`STEP_WEIGHTS` keys ≠ `STEPS` keys):** the two dicts use DIFFERENT key
> vocabularies. `STEPS` keys are `step_name`s passed to `_dispatch_agent`
> (`redundancy-analysis`, `disposition-recommendation`, …). `STEP_WEIGHTS` keys are UI step-ids
> (`detect-redundancy`, `recommend-disposition`, …). `_set_step(step, progress)` is called with the
> **UI step-id** as `step`, while `_dispatch_agent(step_name=…)` is called with the **STEPS key**.
> e.g. `_set_step("detect-redundancy", 0.0)` then `_dispatch_agent(step_name="redundancy-analysis")`
> (`rationalization.py:207-215`). A rebuild MUST keep these two vocabularies distinct and use the
> right one in each call.

### 1.3 `MAX_REWORK_ITERATIONS = 3` (`rationalization.py:99`)

The rework ceiling. Both gate loops compare `_rework_count(gate) > MAX_REWORK_ITERATIONS`
(strictly greater). ⚠️ **GOTCHA-RAT-MAX:** because `_bump_rework` is called FIRST and then compared
with `>` (not `>=`), the workflow tolerates rework iterations 1, 2, 3 and **fails on the 4th
rejection** (when the count becomes 4 > 3). See §6.5 / §7.7 for exact counter semantics.

---

## 2. STATE — instance vars (`__init__`, `rationalization.py:137-151`)

`__init__` calls `super().__init__()` FIRST (`rationalization.py:138`) — this initializes the 8 HIL
vars (`_HILSignalsMixin.md` §1) **and** the 19 `LineWorkflowBase` line-state vars
(`_LineWorkflowBase.md` §2). Then it sets **four** subclass-specific vars:

| Var | Type | Initial | Line | Mutated by → value | When |
|-----|------|---------|------|--------------------|------|
| `_stakeholder_approved` | `bool` | `False` | 140 | `stakeholder_approved` (non-tier-1 scope) → `True` (`:690`); G-DA approval branch consumes → `False` (`:569`); G-DA reject branch (patched) → `False` (`:583`) | G-DA stakeholder sign-off lifecycle |
| `_stakeholder_info` | `str` | `""` | 141 | `stakeholder_approved` (non-tier-1) → `f"{signal.stakeholder} approved scope: {signal.scope}"` (`:691`) | recorded on G-DA sign-off; informational only (never read by control flow) |
| `_tier1_approved_by` | `str \| None` | `None` | 148 | `stakeholder_approved` (scope == `"tier-1-classification"`) → `signal.stakeholder` (`:688`) | Tier-1 classification pause unblock; later passed to `confirm_classification_tier_1` |
| `_dispositions` | `dict[str, str]` | `{}` | 151 | **never written in this file** (declared "populated during recommendation step" but no assignment exists) | — |

> ⚠️ **GOTCHA-RAT-S1 (`_dispositions` is dead state):** declared at `rationalization.py:150-151`
> with the comment "Disposition results per app (populated during recommendation step)" but **no code
> path assigns to it** in this file. It stays `{}` for the whole run. A rebuild should declare it for
> structural parity but must not expect it to be populated — the actual disposition string used by
> control flow comes from `input.disposition` (the inbound `LineWorkflowInput`), not from this dict.

> ⚠️ **GOTCHA-RAT-S2 (inherited state set by `run()`):** `run()` hydrates several BASE vars from
> `input`: `_status=RUNNING`, `_started_at`/`_updated_at`=`_now_iso()` (`:163-165`), `_app_id`,
> `_portfolio_id`, `_wave_id` (`:168-170`). It does **NOT** set `_risk_tier` (it stays `None`) — and
> both gate-evidence calls pass `forward_risk_tier=False` (§6.3 / §7.3), so `_risk_tier` is never
> forwarded. A rebuild must NOT forward risk_tier for this line.

---

## 3. SIGNAL — the one subclass-added signal: `stakeholder_approved` (`rationalization.py:670-692`)

```text
@workflow.signal
async def stakeholder_approved(self, signal: StakeholderApprovedSignal) -> None:
    if signal.scope == "tier-1-classification":          # rationalization.py:687   BRANCH 1
        self._tier1_approved_by = signal.stakeholder     # rationalization.py:688
    else:                                                # rationalization.py:689
        self._stakeholder_approved = True                # rationalization.py:690
        self._stakeholder_info = (                       # rationalization.py:691
            f"{signal.stakeholder} approved scope: {signal.scope}")
    self._updated_at = _now_iso()                        # rationalization.py:692
```

- **Payload** `StakeholderApprovedSignal` (`types.py:164-170`): fields `approval_id: str`,
  `stakeholder: str`, `scope: str`. (`approval_id` is accepted but unused by the handler.)
- **Wire signal name:** `stakeholder_approved` (Temporal uses the method name).
- **Branch 1** `scope == "tier-1-classification"` (`:687`): buffer `signal.stakeholder` into
  `_tier1_approved_by`. This unblocks the Tier-1 classification pause whose predicate is
  `lambda: self._tier1_approved_by is not None or self.cancelled` (`:470-472`, §6.10).
- **Branch 2 (else)** any other scope, conventionally `scope == "g-da"` (`:689-691`): set
  `_stakeholder_approved=True` and store an info string. This satisfies the G-DA dual-signal gate
  whose predicate is `lambda: self._stakeholder_approved or self.cancelled` (`:560-562`, §7.4).
- Always bumps `_updated_at` (`:692`).

> ⚠️ **GOTCHA-RAT-SIG1 (one signal, TWO distinct wait sites — disambiguated by `scope`):** the SAME
> `stakeholder_approved` signal feeds two different `wait_condition`s. `scope == "tier-1-classification"`
> drives the classification pause; anything else drives the G-DA stakeholder sign-off. A rebuild MUST
> branch on the literal string `"tier-1-classification"` (`:687`) — sending `scope="g-da"` while the
> workflow is waiting for the tier-1 confirmation would set `_stakeholder_approved` but leave
> `_tier1_approved_by` `None`, so the tier-1 wait would NOT unblock. The two scopes are not
> interchangeable.

> ⚠️ **GOTCHA-RAT-SIG2 (`async def` but pure mutation):** the handler is declared `async def`
> (`:671`) yet performs only attribute writes + `_now_iso()` — no `await`, no activity. This matches
> the base gate-signal style (async, single-task). A rebuild keeps it `async def` with no yield point.

> ⚠️ **GOTCHA-RAT-SIG3 (G-DA needs BOTH this signal AND the base `gate_approved`):** the docstring
> (`:683-685`) and the G-DA approval branch (`:549-577`) make explicit that G-DA closure requires
> **two distinct decisions from two distinct roles**: (a) a PM `gate_approved` signal (consumed by
> `_wait_for_gate_decision` → `"approved"`) AND (b) a `stakeholder_approved` (non-tier-1) signal
> (consumed by the post-approval `wait_condition`). Neither can unilaterally close the gate. This
> dual-signal requirement is patch-gated (§7.4). A rebuild must enforce both under the patch.

---

## 4. `run(self, input: LineWorkflowInput) -> str` — top-level entry (`rationalization.py:153-190`)

`@workflow.run` (`rationalization.py:153`). Sets initial status, derives the branch + workspace
keys, then delegates the body to `_execute_rationalization` inside a try/except that records FAILED
on any exception.

```text
@workflow.run
async def run(self, input):
    self._status = WorkflowStatus.RUNNING        # rationalization.py:163
    self._started_at = _now_iso()                # rationalization.py:164
    self._updated_at = self._started_at          # rationalization.py:165

    app_id = input.app_id                        # rationalization.py:167
    self._app_id = app_id                        # rationalization.py:168
    self._portfolio_id = input.portfolio_id      # rationalization.py:169
    self._wave_id = input.wave_id                # rationalization.py:170
    repo = input.artifact_repo                   # rationalization.py:171

    wf_id = workflow.info().workflow_id          # rationalization.py:173
    run_suffix = wf_id.rsplit("-", 1)[-1] if "-" in wf_id else wf_id[:8]   # :174  BRANCH
    branch = f"olympus/rationalization/{app_id}/{run_suffix}"              # :175
    workspace_key = f"rationalization-{app_id}-{run_suffix}"               # :176

    try:                                                                   # :178
        return await self._execute_rationalization(
            input, app_id, repo, branch, workspace_key)                    # :179
    except Exception:                                                      # :180  BRANCH (catch-all)
        self._status = WorkflowStatus.FAILED                               # :181
        self._current_step = "failed"                                      # :182
        self._updated_at = _now_iso()                                      # :183
        try:                                                               # :184
            await self._update_app_status(
                app_id, "rationalization_failed", "failed", "Rationalization")  # :185-187
        except Exception:                                                  # :188
            pass  # Best-effort                                            # :189
        raise                                                              # :190  ← re-raise
```

**Branches (3):**
1. `run_suffix = wf_id.rsplit("-", 1)[-1] if "-" in wf_id else wf_id[:8]` (`:174`) — derive a stable
   short id from the workflow id: take the substring after the LAST `-` if a `-` exists, else the
   first 8 chars. ⚠️ **GOTCHA-RAT-RUN1 (deterministic branch/workspace naming):** the git branch
   `olympus/rationalization/{app_id}/{run_suffix}` and `workspace_key` are derived purely from
   `workflow.info().workflow_id` (deterministic under replay). A rebuild MUST derive these the same
   way; a random/wall-clock suffix would break replay and produce duplicate branches.
2. `except Exception:` (`:180`) — outer catch-all: set `_status=FAILED`, `_current_step="failed"`,
   bump `_updated_at`, then best-effort push `"rationalization_failed"` to the app row, then
   **re-raise** so Temporal marks the run failed.
3. inner `try/except: pass` (`:184-189`) — the DB status push is best-effort; its failure must NOT
   mask the original exception. ⚠️ **GOTCHA-RAT-RUN2 (re-raise the ORIGINAL, not the DB error):** the
   `raise` at `:190` is bare, re-raising the exception caught at `:180`, NOT anything from the inner
   try. A rebuild must keep the bare `raise` outside the inner try.

> ⚠️ **GOTCHA-RAT-RUN3 (returns a STRING, not None):** `run()` returns one of the literal strings
> `"completed"` / `"cancelled"` / `"failed"` (propagated from `_execute_rationalization`), or
> re-raises on unexpected exception. The four explicit string returns inside the body are: `"failed"`
> (max-rework, §6.5/§7.7 — returned normally, NOT raised), `"cancelled"` (cancel at any gate/pause),
> `"completed"` (success). A rebuild must surface these exact strings.

---

## 5. `_execute_rationalization(...)` — the core body (`rationalization.py:192-664`)

Signature: `async def _execute_rationalization(self, input, app_id, repo, branch, workspace_key) -> str`
(`rationalization.py:192-199`). This is the orchestration spine. Reproduced below as ordered phases;
EVERY branch is preserved. Pseudocode is sequential top-to-bottom; all dispatches/commits/gate-PR/
evidence/pre-review/gate-wait/merge helpers behave exactly as in `_LineWorkflowBase.md`.

### 5.0 Phase map (linear)

```
Step 1  Redundancy Analysis      → dispatch + commit                         §6.1-6.2
Gate    G-RR loop (while True)    → PR/record/evidence/pre-review/wait/route  §6.3-6.6
Step 3  Disposition Recommend     → dispatch + commit                         §6.7
Step 4  Disposition Governance    → dispatch + commit (silent sub-phase)      §6.8
Step 5  User Impact (cond.)       → dispatch + commit IFF Retire/Replace      §6.9
Step 6  Classification            → dispatch + commit + persist               §6.10
        Tier-1 pause (cond.)      → wait IFF persist_result.tier_1_flag       §6.10
Gate    G-DA loop (while True)    → PR/record/evidence/pre-review/wait +
                                     dual-signal + route + rework re-dispatch  §7
        Completed                 → status COMPLETED, progress 100            §8
```

---

## 6. STEP 1 → GATE G-RR (`rationalization.py:202-332`)

### 6.1 Step 1 dispatch (`rationalization.py:207-216`)

```text
await self._set_step("detect-redundancy", 0.0)                        # :207
redundancy_result = await self._dispatch_agent(
    app_id=app_id, step_name="redundancy-analysis",
    input_artifacts=list(input.prior_artifacts),                       # :211
    workspace_key=workspace_key, artifact_repo=repo, artifact_ref=branch)   # :208-214
self._step_results["redundancy-analysis"] = redundancy_result.output_artifacts   # :216
```
- `_set_step` UI step = `"detect-redundancy"`, progress `0.0`.
- `_dispatch_agent` (base §8): skill `redundancy-analyzer`, `task_type="rationalization-redundancy-analysis"`,
  `input_artifacts = list(input.prior_artifacts)` (the Discovery outputs). On the FIRST pass there is
  no rework feedback; `_rework_gate_key_for_step("redundancy-analysis")` returns `"G-RR"` but
  `_rework_feedback.get("G-RR")` is `None`, so no feedback is attached. 1-hour timeout, `agent_failure`
  policy, `activity_id="agent-redundancy-analysis"`.
- ⚠️ **GOTCHA-RAT-S3 (`_step_results` written by subclass):** per base GOTCHA-S2, the subclass MUST
  do `self._step_results[step] = result.output_artifacts` after every dispatch — done here at `:216`
  (and after each subsequent dispatch). A rebuild that skips this leaves empty `"output"` fields in
  the evidence bundle.

### 6.2 Step 1 commit (`rationalization.py:218-227`)

```text
artifact_path = f"rationalization/{app_id}/redundancy-matrix.json"     # :219
await self._commit_step_artifacts(
    repo, branch, app_id, "redundancy-analysis", redundancy_result, artifact_path)   # :220-227
```
- `_commit_step_artifacts` (base §9): one batched `write_artifacts_batch` commit to `branch`, sets
  `self._step_committed_paths["redundancy-analysis"]`. `artifact_path` is the literal
  `rationalization/{app_id}/redundancy-matrix.json` (NOT derived from `STEPS`).

### 6.3 Gate G-RR loop — `while True` (`rationalization.py:230-332`)

The G-RR loop. Each iteration: dedup paths → create PR → create gate record → submit evidence →
pre-review → wait → route. On reject: bump counter, check ceiling, re-dispatch step 1, loop.

```text
while True:                                                            # rationalization.py:230
    grr_artifact_paths = dedup_paths(
        list(self._step_committed_paths.get("redundancy-analysis", [])))   # :231-233

    pr_result = await self._create_gate_pr(
        repo, branch, app_id, gate_type="G-RR",
        title=f"Gate G-RR: Rationalization Review — {app_id}",
        body=self._build_grr_pr_body(app_id))                          # :236-243

    gate_record = await workflow.execute_activity(
        create_gate_record,
        CreateGateRecordInput(
            gate_type="G-RR", app_id=app_id,
            portfolio_id=input.portfolio_id,
            workflow_id=workflow.info().workflow_id,
            evidence_package_url=pr_result.pr_url),
        start_to_close_timeout=timedelta(seconds=30),
        retry_policy=RETRY_POLICIES["transient"])                      # :246-257

    await self._submit_gate_evidence(
        gate_id=gate_record.gate_id, gate_type=GateType.G_RR, app_id=app_id,
        artifact_paths=grr_artifact_paths, pr_url=pr_result.pr_url,
        assembly_line="Rationalization", step="redundancy-analysis",
        forward_risk_tier=False)                                       # :262-271

    await self._run_gate_pre_review(
        gate_record.gate_id, "G-RR", grr_artifact_paths,
        artifact_repo=repo, artifact_ref=branch)                       # :274-280

    await self._set_step("gate-review-rr", STEP_WEIGHTS["detect-redundancy"])   # :283
    decision = await self._wait_for_gate_decision(GateType.G_RR)       # :284

    if decision == "cancelled":                                        # :286  BRANCH A
        return "cancelled"                                             # :287

    if decision == "approved":                                         # :289  BRANCH B
        await self._reconcile_and_merge_with_retry_loop(
            repo=repo, pr_number=pr_result.pr_number,
            gate_id=gate_record.gate_id, merge_method="merge")         # :292-297
        break                                                          # :298  ← exit loop

    # decision == "rejected" — rework                                  # :300
    self._bump_rework("G-RR")                                          # :301
    if self._rework_count("G-RR") > MAX_REWORK_ITERATIONS:             # :302  BRANCH C
        self._status = WorkflowStatus.FAILED                           # :303
        self._current_step = "max-rework-exceeded-grr"                 # :304
        self._updated_at = _now_iso()                                  # :305
        await self._update_app_status(
            app_id, "rationalization_failed", "max-rework-exceeded-grr",
            "Rationalization")                                         # :306-311
        return "failed"                                                # :312

    # re-run redundancy with feedback                                  # :314
    await self._set_step("detect-redundancy", 0.0)                     # :315
    redundancy_result = await self._dispatch_agent(
        app_id=app_id, step_name="redundancy-analysis",
        input_artifacts=list(input.prior_artifacts),
        workspace_key=workspace_key, artifact_repo=repo, artifact_ref=branch)   # :316-323
    self._step_results["redundancy-analysis"] = redundancy_result.output_artifacts   # :324
    await self._commit_step_artifacts(
        repo, branch, app_id, "redundancy-analysis", redundancy_result, artifact_path)   # :325-332
    # loop back to top of while
```

**Branch inventory in the G-RR loop (4):** `while True` (`:230`); `if decision == "cancelled"`
(`:286`); `if decision == "approved"` (`:289`); `if self._rework_count("G-RR") > MAX_REWORK_ITERATIONS`
(`:302`). The implicit fall-through (decision neither cancelled nor approved ⇒ rejected) is the
rework path (`:300-332`).

### 6.4 G-RR activity & helper calls (per loop iteration, in order)

| # | Call | Args | Timeout | Retry | non_retryable | activity_id |
|---|------|------|---------|-------|---------------|-------------|
| 1 | `_create_gate_pr` (→ `create_pr`) | repo, branch, app_id, `gate_type="G-RR"` (string), title, body=`_build_grr_pr_body(app_id)` | 60s (base) | transient | — | — |
| 2 | `create_gate_record` | `CreateGateRecordInput(gate_type="G-RR", app_id, portfolio_id=input.portfolio_id, workflow_id, evidence_package_url=pr_result.pr_url)` | 30s | transient | — | — |
| 3 | `_submit_gate_evidence` (→ `check_gate_criteria` + `submit_gate_evidence`) | gate_id, `GateType.G_RR`, app_id, `grr_artifact_paths`, pr_url, `assembly_line="Rationalization"`, `step="redundancy-analysis"`, **`forward_risk_tier=False`** | 60s each (base) | transient | — | — |
| 4 | `_run_gate_pre_review` (→ `dispatch_agent_task` + `store_gate_pre_review` + patched `mark_gate_ready_for_review`) | gate_id, `"G-RR"`, paths, `artifact_repo=repo`, `artifact_ref=branch` | 10m / 30s / 30s (base) | transient | — | — |
| 5 | `_wait_for_gate_decision(GateType.G_RR)` | — | (signal wait) | — | — | — |
| 6 (approve) | `_reconcile_and_merge_with_retry_loop` (→ `reconcile_and_merge_pr`, maybe `set_gate_merge_blocked`) | `repo`, `pr_number=pr_result.pr_number`, `gate_id`, `merge_method="merge"` | 60s/30s (base) | **git_merge** on merge | MergeConflict / MergeDivergenceUnresolved / MergeBranchProtectionRejected | — |
| 7 (reject) | `_dispatch_agent` + `_commit_step_artifacts` (re-run step 1) | as §6.1/6.2 | 1h / 120s | agent_failure / transient | — | `agent-redundancy-analysis` / `commit-redundancy-analysis` |

> ⚠️ **GOTCHA-RAT-GRR1 (`gate_type` is a STRING for the PR/record but an ENUM for evidence/wait):**
> `_create_gate_pr` and `CreateGateRecordInput` receive the **string** `"G-RR"`
> (`:240`, `:249`), whereas `_submit_gate_evidence` and `_wait_for_gate_decision` receive the **enum**
> `GateType.G_RR` (`:264`, `:284`). This mirrors base GOTCHA-GP1. A rebuild must keep the string vs
> enum split exactly — `_create_gate_pr` lowercases the string for the execution-context step id and
> uses it as a PR label.

> ⚠️ **GOTCHA-RAT-GRR2 (`forward_risk_tier=False` — Rationalization predates F3 risk plumbing):**
> the comment (`:259-261`) records that Rationalization omits `evidence_data` + `risk_tier` from
> `check_gate_criteria`. So `_submit_gate_evidence` builds the bare 4-field `CheckGateCriteriaInput`
> (base GOTCHA-SE2). A rebuild MUST pass `forward_risk_tier=False` for both G-RR and G-DA here.

> ⚠️ **GOTCHA-RAT-GRR3 (`_set_step` AFTER pre-review, BEFORE wait):** progress is set to
> `STEP_WEIGHTS["detect-redundancy"]` (= 20.0) right before `_wait_for_gate_decision` (`:283-284`).
> So while the gate is open the dashboard shows `current_step="gate-review-rr"`, `progress=20.0`,
> `status=WAITING_FOR_SIGNAL`, `pending_gate=G-RR` (the last three from base `_wait_for_gate_decision`).
> A rebuild must set the step at exactly this point, not earlier.

> ⚠️ **GOTCHA-RAT-GRR4 (re-dispatch uses `input.prior_artifacts`, NOT the prior committed paths):**
> both the first dispatch (`:211`) and the rework re-dispatch (`:319`) feed
> `input_artifacts=list(input.prior_artifacts)` — the original Discovery artifacts — NOT the redundancy
> matrix from the prior iteration. The rework FEEDBACK (the reviewer's rejection) is what changes the
> output, threaded via `context["rework_feedback"]["G-RR"]` by `_dispatch_agent` (because
> `_rework_gate_key_for_step("redundancy-analysis")=="G-RR"` and `_wait_for_gate_decision` set
> `_rework_feedback["G-RR"]` on the reject). A rebuild must keep `prior_artifacts` as the input, not
> swap in the committed matrix.

### 6.5 G-RR routing summary (the four reviewer outcomes)

`_wait_for_gate_decision` returns one of THREE strings; this loop maps them + the merge_blocked state:

- **cancelled** (`decision == "cancelled"`, `:286-287`): immediately `return "cancelled"` (no status
  mutation here — base `_wait_for_gate_decision` already set `_status=CANCELLED`).
- **approved** (`:289-298`): merge the PR via `_reconcile_and_merge_with_retry_loop`. That helper
  internally handles **merge_blocked** (structured `MergeConflict`/`MergeDivergenceUnresolved`/
  `MergeBranchProtectionRejected` → set gate merge_blocked, wait for `merge_retry` signal, loop) and
  **cancel during merge_blocked** (returns cleanly). After it returns, `break` exits the G-RR loop and
  control proceeds to Step 3.
- **rejected** (fall-through, `:300-332`): the rework path.

### 6.6 G-RR rework counter & ceiling (`rationalization.py:301-312`)

```text
self._bump_rework("G-RR")                                 # :301  count := count+1 for key "G-RR"
if self._rework_count("G-RR") > MAX_REWORK_ITERATIONS:    # :302  i.e. > 3
    -> FAILED, current_step="max-rework-exceeded-grr", DB="rationalization_failed", return "failed"
```
- `_bump_rework` is the BASE method (base §17). It is bumped HERE in the subclass on the rejected
  branch (base GOTCHA-RW1), NOT inside `_wait_for_gate_decision`.
- ⚠️ **GOTCHA-RAT-GRR5 (bump-then-`>`-compare ⇒ 3 reworks tolerated, fail on 4th reject):** first
  rejection → count 1 (1>3 false → rework). … third rejection → count 3 (3>3 false → rework). fourth
  rejection → count 4 (4>3 true → `return "failed"`). A rebuild MUST bump first and compare with
  strict `>` against `MAX_REWORK_ITERATIONS=3`; using `>=` would fail one iteration too early.
- ⚠️ **GOTCHA-RAT-GRR6 (max-rework returns `"failed"` — it does NOT raise):** the ceiling path sets
  `_status=FAILED` and `return "failed"` (`:312`) which propagates up through `run()`'s `try` and is
  returned as the workflow result (NOT routed through the `except` → re-raise path). The workflow
  completes "successfully" from Temporal's view with result string `"failed"`. A rebuild must `return`
  the string, not raise, on max-rework.

---

## 7. STEPS 3-6 → GATE G-DA (`rationalization.py:334-655`)

After the G-RR loop `break`, control runs four steps then the G-DA gate loop.

### 7.1 Step 3 — Disposition Recommendation (`rationalization.py:334-356`)

```text
progress_after_grr = STEP_WEIGHTS["detect-redundancy"] + STEP_WEIGHTS["gate-review-rr"]   # :335  = 35.0
await self._set_step("recommend-disposition", progress_after_grr)                         # :336

disposition_result = await self._dispatch_agent(
    app_id=app_id, step_name="disposition-recommendation",
    input_artifacts=self._step_committed_paths.get("redundancy-analysis", []),            # :341
    workspace_key=workspace_key, artifact_repo=repo, artifact_ref=branch)                 # :338-345
self._step_results["disposition-recommendation"] = disposition_result.output_artifacts    # :346

disp_artifact_path = f"rationalization/{app_id}/disposition-recommendation.json"          # :348
await self._commit_step_artifacts(
    repo, branch, app_id, "disposition-recommendation", disposition_result, disp_artifact_path)   # :349-356
```
- Input artifacts = the COMMITTED redundancy paths (`_step_committed_paths["redundancy-analysis"]`),
  NOT `prior_artifacts`. `_dispatch_agent` resolves skill `disposition-recommender`,
  `task_type="rationalization-disposition-recommendation"`. Because
  `_rework_gate_key_for_step("disposition-recommendation")=="G-DA"`, on a G-DA rework iteration this
  dispatch picks up `context["rework_feedback"]["G-DA"]`.

### 7.2 Step 4 — Disposition Governance (silent sub-phase) (`rationalization.py:358-385`)

```text
progress_after_disp = progress_after_grr + STEP_WEIGHTS["recommend-disposition"]   # :364  = 53.0
await self._set_step("recommend-disposition", progress_after_disp)                 # :365  ← SAME ui step

governance_result = await self._dispatch_agent(
    app_id=app_id, step_name="disposition-governance",
    input_artifacts=self._step_committed_paths.get("disposition-recommendation", []),   # :370
    workspace_key=workspace_key, artifact_repo=repo, artifact_ref=branch)               # :367-374
self._step_results["disposition-governance"] = governance_result.output_artifacts        # :375

gov_artifact_path = f"rationalization/{app_id}/disposition-governance.json"              # :377
await self._commit_step_artifacts(
    repo, branch, app_id, "disposition-governance", governance_result, gov_artifact_path)   # :378-385
```
- ⚠️ **GOTCHA-RAT-GOV1 (`current_step` stays `"recommend-disposition"` across BOTH steps):** governance
  is dispatched as `step_name="disposition-governance"` (skill `disposition-governance`,
  `task_type="rationalization-disposition-governance"`) but `_set_step` is called with the UI step-id
  `"recommend-disposition"` again (`:365`), only the progress ticks up to 53.0. The
  `disposition-governance` WEIGHT (8.0) is added to `progress`, but the string is never emitted as a
  `current_step`. See GOTCHA-RAT-CV2. A rebuild must keep the UI string stable here.
- Input = committed `disposition-recommendation` paths.

### 7.3 Step 5 — User Impact (CONDITIONAL: Retire/Replace only) (`rationalization.py:387-410`)

```text
progress_after_gov = progress_after_disp + STEP_WEIGHTS["disposition-governance"]   # :388  = 61.0
await self._set_step("assess-user-impact", progress_after_gov)                      # :389

if _is_retire_or_replace(input.disposition):                                        # :391  BRANCH
    impact_result = await self._dispatch_agent(
        app_id=app_id, step_name="user-impact",
        input_artifacts=self._step_committed_paths.get("disposition-recommendation", []),   # :395
        workspace_key=workspace_key, artifact_repo=repo, artifact_ref=branch)               # :392-399
    self._step_results["user-impact"] = impact_result.output_artifacts              # :400
    impact_artifact_path = f"rationalization/{app_id}/user-impact-analysis.json"    # :402
    await self._commit_step_artifacts(
        repo, branch, app_id, "user-impact", impact_result, impact_artifact_path)   # :403-410
```
- **Branch** `if _is_retire_or_replace(input.disposition):` (`:391`) — see §9.2 for the helper. Only
  for disposition string in `("Retire", "Replace")` is the user-impact step dispatched+committed.
- ⚠️ **GOTCHA-RAT-UI1 (`_set_step("assess-user-impact")` ALWAYS runs, dispatch only if Retire/Replace):**
  the `_set_step` at `:389` is OUTSIDE the `if`, so progress moves to 61.0 + UI shows `assess-user-impact`
  even when the step is skipped. Only the agent dispatch + commit are gated. A rebuild must keep the
  `_set_step` unconditional and the dispatch conditional.
- ⚠️ **GOTCHA-RAT-UI2 (skipping leaves `_step_committed_paths["user-impact"]` unset):** when the
  branch is false, `self._step_committed_paths.get("user-impact", [])` returns `[]` later in the
  G-DA evidence assembly (`:494-497`) and the G-DA PR body marks it "N/A" (§7.10). A rebuild must
  tolerate the missing key.

### 7.4 Step 6 — Classification + persist + Tier-1 pause (`rationalization.py:412-487`)

```text
await self._set_step("classification",
    progress_after_gov + STEP_WEIGHTS.get("assess-user-impact", 15.0))   # :419-422  = 61.0 + 12.0 = 73.0

classification_inputs = self._step_committed_paths.get("disposition-recommendation", [])   # :424
classification_result = await self._dispatch_agent(
    app_id=app_id, step_name="classification",
    input_artifacts=classification_inputs,
    workspace_key=workspace_key, artifact_repo=repo, artifact_ref=branch)   # :425-432
self._step_results["classification"] = classification_result.output_artifacts   # :433
classification_artifact_path = f"rationalization/{app_id}/classification.json"  # :434
await self._commit_step_artifacts(
    repo, branch, app_id, "classification", classification_result, classification_artifact_path)   # :435-442

persist_result = await workflow.execute_activity(
    persist_classification,
    PersistClassificationInput(
        app_id=app_id,
        classification_artifact_path=classification_artifact_path,
        classification_json=(
            classification_result.output_artifacts[0]
            if classification_result.output_artifacts else ""),          # :452-457  BRANCH (inline)
    ),
    start_to_close_timeout=timedelta(seconds=60),
    retry_policy=RETRY_POLICIES["transient"])                            # :448-461

if persist_result.tier_1_flag:                                           # :467  BRANCH
    self._current_step = "classification-awaiting-tier1-approval"        # :468
    self._updated_at = _now_iso()                                        # :469
    await workflow.wait_condition(
        lambda: self._tier1_approved_by is not None or self.cancelled)   # :470-472  ★PREDICATE
    if self.cancelled:                                                   # :473  BRANCH
        self._status = WorkflowStatus.CANCELLED                          # :474
        self._updated_at = _now_iso()                                    # :475
        return "cancelled"                                               # :476
    await workflow.execute_activity(
        confirm_classification_tier_1,
        ConfirmClassificationInput(
            app_id=app_id, approved_by=self._tier1_approved_by),         # :481-483
        start_to_close_timeout=timedelta(seconds=30),
        retry_policy=RETRY_POLICIES["transient"])                        # :479-487
```

**Branches (3):**
1. `classification_json = result.output_artifacts[0] if result.output_artifacts else ""` (`:452-457`)
   — pass the first output artifact (the classification JSON) to the persist activity, or `""` if the
   agent produced none.
2. `if persist_result.tier_1_flag:` (`:467`) — Tier-1 risk requires a human confirmation pause.
3. `if self.cancelled:` (`:473`) inside the pause — cancel during the Tier-1 wait → `CANCELLED`,
   `return "cancelled"`.

**Activity calls:**
- `_set_step` UI step `"classification"`, progress `73.0` (note: uses `STEP_WEIGHTS.get("assess-user-impact", 15.0)`
  with a fallback `15.0` — but the key exists (=12.0), so 12.0 is used; the 15.0 default is dead).
- `persist_classification` — `PersistClassificationInput(app_id, classification_artifact_path,
  classification_json)`; **60s**; `transient`. Returns `PersistClassificationResult` with
  `tier_1_flag: bool` (`types.py:1235-1248`). ⚠️ The activity parses the agent output, writes
  `risk_tier`/`complexity_tier`/`archetype` columns with `source="auto"`, and returns whether Tier 1.
- `confirm_classification_tier_1` — `ConfirmClassificationInput(app_id, approved_by=self._tier1_approved_by)`;
  **30s**; `transient`. ONLY after the Tier-1 wait unblocks (not cancelled). Flips `risk_tier_source`
  `"auto"`→`"confirmed"` and records the approver.

> ⚠️ **GOTCHA-RAT-CLS1 (`STEP_WEIGHTS.get("assess-user-impact", 15.0)` — the 15.0 is a dead fallback):**
> `:421` uses `.get(..., 15.0)` but the key is present (12.0), so 12.0 wins; progress = 73.0. A rebuild
> should keep the `.get` with the 15.0 default for byte-parity but know the live value is 12.0.

> ⚠️ **GOTCHA-RAT-CLS2 (Tier-1 pause predicate uses `_tier1_approved_by is not None`, NOT a bool flag):**
> the wait at `:470-472` is `lambda: self._tier1_approved_by is not None or self.cancelled`. The
> `stakeholder_approved` handler with `scope=="tier-1-classification"` sets `_tier1_approved_by` to the
> stakeholder string (§3 branch 1). A rebuild MUST gate on `is not None` (an empty string `""` would
> also satisfy `is not None`, but the handler always sets a real stakeholder). A `scope="g-da"` signal
> does NOT unblock this wait (it sets `_stakeholder_approved`, not `_tier1_approved_by`).

> ⚠️ **GOTCHA-RAT-CLS3 (`_current_step="classification-awaiting-tier1-approval"` is set DIRECTLY, not via
> `_set_step`):** `:468` assigns `_current_step` directly (and `_updated_at` at `:469`) WITHOUT calling
> `_set_step` — so it does NOT push a DB status update and does NOT change `_progress_pct` (stays 73.0).
> A rebuild must set the attribute directly here, not call `_set_step`, to match the "no DB write / no
> progress change during the pause" behavior. (`get_status` will report `status=RUNNING` — NOT
> `WAITING_FOR_SIGNAL` — because this pause is a raw `wait_condition`, not `_wait_for_gate_decision`.)

> ⚠️ **GOTCHA-RAT-CLS4 (cancel during Tier-1 pause returns BEFORE `confirm_classification_tier_1`):**
> `:473-476` checks `self.cancelled` immediately after the wait and returns `"cancelled"` WITHOUT
> running the confirm activity. A rebuild must check cancel before the confirm call so a cancelled run
> doesn't flip the tier source.

> ⚠️ **GOTCHA-RAT-CLS5 (no Tier-1 confirmation needed ⇒ fall straight through to G-DA):** when
> `persist_result.tier_1_flag` is False, the entire `if` block (`:467-487`) is skipped and control
> drops directly into the G-DA loop. A rebuild must NOT wait for any stakeholder signal here when the
> app is not Tier 1.

### 7.5 Gate G-DA loop — `while True` (`rationalization.py:489-655`)

The G-DA loop. Each iteration: assemble GDA paths (recommendation + governance + user-impact, deduped)
→ create PR → create record → submit evidence → pre-review → wait → route (with dual-signal) → on
reject, re-dispatch steps 3+4+(5 if Retire/Replace), loop.

```text
while True:                                                            # rationalization.py:490
    gda_artifact_paths = []                                           # :491
    for step_name in ["disposition-recommendation",
                      "disposition-governance", "user-impact"]:       # :492-496  LOOP
        gda_artifact_paths.extend(self._step_committed_paths.get(step_name, []))   # :497
    gda_artifact_paths = dedup_paths(gda_artifact_paths)              # :498

    pr_result = await self._create_gate_pr(
        repo, branch, app_id, gate_type="G-DA",
        title=f"Gate G-DA: Disposition Approval — {app_id}",
        body=self._build_gda_pr_body(app_id, input.disposition))      # :500-507

    gate_record = await workflow.execute_activity(
        create_gate_record,
        CreateGateRecordInput(
            gate_type="G-DA", app_id=app_id, portfolio_id=input.portfolio_id,
            workflow_id=workflow.info().workflow_id,
            evidence_package_url=pr_result.pr_url),
        start_to_close_timeout=timedelta(seconds=30),
        retry_policy=RETRY_POLICIES["transient"])                     # :509-520

    await self._submit_gate_evidence(
        gate_id=gate_record.gate_id, gate_type=GateType.G_DA, app_id=app_id,
        artifact_paths=gda_artifact_paths, pr_url=pr_result.pr_url,
        assembly_line="Rationalization", step="disposition-approval",
        forward_risk_tier=False)                                      # :522-531

    await self._run_gate_pre_review(
        gate_record.gate_id, "G-DA", gda_artifact_paths,
        artifact_repo=repo, artifact_ref=branch)                      # :534-540

    progress_after_impact = progress_after_gov + STEP_WEIGHTS["assess-user-impact"]   # :542  = 73.0
    await self._set_step("gate-review-da", progress_after_impact)     # :543
    decision = await self._wait_for_gate_decision(GateType.G_DA)      # :544

    if decision == "cancelled":                                       # :546  BRANCH A
        return "cancelled"                                            # :547

    if decision == "approved":                                        # :549  BRANCH B
        if workflow.patched("gda-dual-signal-v1"):                    # :559  BRANCH B1 (patch gate)
            await workflow.wait_condition(
                lambda: self._stakeholder_approved or self.cancelled) # :560-562  ★PREDICATE
            if self.cancelled:                                        # :563  BRANCH B2
                self._status = WorkflowStatus.CANCELLED               # :564
                self._updated_at = _now_iso()                         # :565
                return "cancelled"                                    # :566
            self._stakeholder_approved = False                        # :569  ← consume
        await self._reconcile_and_merge_with_retry_loop(
            repo=repo, pr_number=pr_result.pr_number,
            gate_id=gate_record.gate_id, merge_method="merge")        # :571-576
        break                                                         # :577  ← exit loop

    # decision == "rejected" — rework                                 # :579
    if workflow.patched("gda-dual-signal-v1"):                        # :582  BRANCH C (patch gate)
        self._stakeholder_approved = False                            # :583  ← drop stale flag
    self._bump_rework("G-DA")                                         # :584
    if self._rework_count("G-DA") > MAX_REWORK_ITERATIONS:            # :585  BRANCH D
        self._status = WorkflowStatus.FAILED                          # :586
        self._current_step = "max-rework-exceeded-gda"                # :587
        self._updated_at = _now_iso()                                 # :588
        await self._update_app_status(
            app_id, "rationalization_failed", "max-rework-exceeded-gda",
            "Rationalization")                                        # :589-594
        return "failed"                                               # :595

    # re-run disposition + governance + impact with feedback          # :597
    await self._set_step("recommend-disposition", progress_after_grr) # :598  ← back to 35.0
    disposition_result = await self._dispatch_agent(
        app_id=app_id, step_name="disposition-recommendation",
        input_artifacts=self._step_committed_paths.get("redundancy-analysis", []),
        workspace_key=workspace_key, artifact_repo=repo, artifact_ref=branch)   # :599-606
    self._step_results["disposition-recommendation"] = disposition_result.output_artifacts   # :607
    await self._commit_step_artifacts(
        repo, branch, app_id, "disposition-recommendation", disposition_result, disp_artifact_path)   # :608-615

    governance_result = await self._dispatch_agent(
        app_id=app_id, step_name="disposition-governance",
        input_artifacts=self._step_committed_paths.get("disposition-recommendation", []),
        workspace_key=workspace_key, artifact_repo=repo, artifact_ref=branch)   # :617-624
    self._step_results["disposition-governance"] = governance_result.output_artifacts   # :625
    await self._commit_step_artifacts(
        repo, branch, app_id, "disposition-governance", governance_result, gov_artifact_path)   # :626-633

    if _is_retire_or_replace(input.disposition):                      # :635  BRANCH E
        impact_result = await self._dispatch_agent(
            app_id=app_id, step_name="user-impact",
            input_artifacts=self._step_committed_paths.get("disposition-recommendation", []),
            workspace_key=workspace_key, artifact_repo=repo, artifact_ref=branch)   # :636-645
        self._step_results["user-impact"] = impact_result.output_artifacts   # :646
        await self._commit_step_artifacts(
            repo, branch, app_id, "user-impact", impact_result,
            f"rationalization/{app_id}/user-impact-analysis.json")    # :647-654
    # loop back to top of while
```

**Branch inventory in the G-DA loop (9):** `while True` (`:490`); the `for step_name in [...]` loop
(`:492`); `if decision == "cancelled"` (`:546`); `if decision == "approved"` (`:549`); the dual-signal
`if workflow.patched("gda-dual-signal-v1")` on approve (`:559`) and its nested `if self.cancelled`
(`:563`); the reject-path `if workflow.patched("gda-dual-signal-v1")` (`:582`); `if
self._rework_count("G-DA") > MAX_REWORK_ITERATIONS` (`:585`); `if _is_retire_or_replace(input.disposition)`
in the rework re-dispatch (`:635`).

### 7.6 G-DA evidence assembly (`rationalization.py:491-498`)

The GDA evidence path list is built by extending across **three** steps in fixed order then deduping:
```text
gda_artifact_paths = []
for step_name in ["disposition-recommendation", "disposition-governance", "user-impact"]:
    gda_artifact_paths.extend(self._step_committed_paths.get(step_name, []))
gda_artifact_paths = dedup_paths(gda_artifact_paths)
```
- ⚠️ **GOTCHA-RAT-GDA1 (G-DA evidence EXCLUDES the redundancy matrix and classification.json):** the
  loop iterates exactly `["disposition-recommendation", "disposition-governance", "user-impact"]`
  (`:492-496`). It does NOT include `"redundancy-analysis"` or `"classification"`. So the G-DA gate's
  `artifact_paths` (the `evidence_paths` for `check_gate_criteria`/`submit_gate_evidence`) cover only
  those three. A rebuild must use this exact 3-step list — not all committed paths.
- `dedup_paths` (`utils/__init__.py:21-23`) = `list(dict.fromkeys(paths))` — order-preserving dedup.
  `"user-impact"` contributes `[]` when the step was skipped (non Retire/Replace).

### 7.7 G-DA activity & helper calls (per loop iteration, in order)

Same shapes as G-RR (§6.4) but `gate_type="G-DA"` / `GateType.G_DA`, body `_build_gda_pr_body(app_id,
input.disposition)`, `step="disposition-approval"`, evidence paths = `gda_artifact_paths`,
`forward_risk_tier=False`. Plus the dual-signal wait on the approve path. The reject path re-dispatches
steps 3, 4, and conditionally 5 (each via `_dispatch_agent` 1h/`agent_failure`/`activity_id=agent-{step}`
+ `_commit_step_artifacts` 120s/`transient`/`activity_id=commit-{step}`).

> ⚠️ **GOTCHA-RAT-GDA2 (G-DA progress is 73.0 — SAME as classification step):** `:542` computes
> `progress_after_impact = progress_after_gov + STEP_WEIGHTS["assess-user-impact"]` = 61.0 + 12.0 = 73.0,
> the SAME value the classification step used (§7.4). So progress does NOT advance between classification
> and the G-DA wait; it jumps to 100 only on completion (§8). The 17.0 `gate-review-da` weight and the
> 10.0 `classification` weight are NOT added into the progress arithmetic anywhere — total progress
> reached before completion is 73.0, not 90 or 100. A rebuild must reproduce this exact (under-counted)
> progress value, not "fix" it to sum to 90/100.

### 7.8 G-DA approve path — the DUAL-SIGNAL gate (`rationalization.py:549-577`)

```text
if decision == "approved":
    if workflow.patched("gda-dual-signal-v1"):                  # :559
        await workflow.wait_condition(
            lambda: self._stakeholder_approved or self.cancelled)   # :560-562
        if self.cancelled:                                      # :563
            self._status = WorkflowStatus.CANCELLED; ...; return "cancelled"   # :564-566
        self._stakeholder_approved = False                      # :569
    await self._reconcile_and_merge_with_retry_loop(...)        # :571-576
    break
```
- ⚠️ **GOTCHA-RAT-GDA3 (PM `gate_approved` ALONE does NOT close G-DA — patched dual-signal):** the
  `decision == "approved"` only means the PM's `gate_approved` signal was consumed by
  `_wait_for_gate_decision`. Under `workflow.patched("gda-dual-signal-v1")`, the workflow ADDITIONALLY
  waits for `self._stakeholder_approved` (set by a non-tier-1 `stakeholder_approved` signal, §3) before
  merging. Two roles, two decisions (`:550-558`). A rebuild MUST enforce this second wait under the
  patch.
- ⚠️ **GOTCHA-RAT-GDA4 (patch ID `"gda-dual-signal-v1"` is load-bearing & verbatim — appears TWICE):**
  the SAME patch string gates BOTH the approve-path extra wait (`:559`) AND the reject-path flag drop
  (`:582`). A rebuild MUST use the exact string in BOTH places. Pre-patch in-flight runs (which had no
  dual-signal requirement) replay deterministically because `workflow.patched` returns False for them,
  skipping both blocks. Changing or omitting the string breaks replay.
- ⚠️ **GOTCHA-RAT-GDA5 (consume the stakeholder flag AFTER passing the wait, BEFORE merge):** `:569`
  sets `_stakeholder_approved=False` immediately after the wait succeeds (and is NOT cancelled), so a
  subsequent G-DA rework cycle requires a FRESH stakeholder sign-off (`:567-568` comment). A rebuild
  must reset the flag here, inside the patched block, after the cancel check.
- ⚠️ **GOTCHA-RAT-GDA6 (cancel during the dual-signal wait returns cleanly):** `:563-566` returns
  `"cancelled"` if cancel landed during the stakeholder wait, without merging. A rebuild must include
  `self.cancelled` in the predicate (`:561`) and return on it.

### 7.9 G-DA reject path — flag drop + rework (`rationalization.py:579-654`)

```text
# (fall-through: decision == "rejected")
if workflow.patched("gda-dual-signal-v1"):    # :582
    self._stakeholder_approved = False        # :583  ← drop any flag set against the rejected iteration
self._bump_rework("G-DA")                     # :584
if self._rework_count("G-DA") > MAX_REWORK_ITERATIONS:   # :585  > 3
    -> FAILED, current_step="max-rework-exceeded-gda", DB="rationalization_failed", return "failed"
# else re-dispatch steps 3,4,(5)
```
- ⚠️ **GOTCHA-RAT-GDA7 (reject drops the stakeholder flag under the patch):** `:582-583` — if a
  stakeholder happened to fire `scope="g-da"` against the iteration that the PM then rejected, that
  stale `_stakeholder_approved=True` is cleared so the NEXT pass requires a fresh sign-off alongside
  the re-approval (`:579-581` comment). A rebuild MUST drop the flag on reject under the patch.
- ⚠️ **GOTCHA-RAT-GDA8 (G-DA rework re-runs 3 steps, NOT classification, NOT redundancy):** the reject
  re-dispatch (`:597-654`) re-runs ONLY `disposition-recommendation`, `disposition-governance`, and
  conditionally `user-impact`. It does NOT re-run the redundancy analysis (already merged via G-RR) NOR
  re-run classification/persist/tier-1 (already done). The `_set_step` resets to `"recommend-disposition"`
  at `progress_after_grr` (35.0, `:598`). A rebuild must re-dispatch exactly these 3 steps and rewind
  progress to 35.0.
- ⚠️ **GOTCHA-RAT-GDA9 (the conditional user-impact uses an INLINE literal path on rework):** the rework
  user-impact commit (`:647-654`) passes the literal `f"rationalization/{app_id}/user-impact-analysis.json"`
  inline, whereas the first-pass commit (§7.3) uses the local var `impact_artifact_path`. Same value;
  a rebuild may use either form but the path must be identical.
- The rework re-dispatch of `disposition-recommendation` / `disposition-governance` / `user-impact` all
  map (via `_rework_gate_key_for_step`) to gate `"G-DA"`, so each picks up
  `context["rework_feedback"]["G-DA"]` (set by `_wait_for_gate_decision` on the reject). A rebuild must
  ensure the rework feedback flows to all three.

### 7.10 G-DA routing summary

- **cancelled** (`:546-547`): `return "cancelled"`.
- **approved** (`:549-577`): under patch, wait for stakeholder (cancel-aware), consume flag, then merge
  via `_reconcile_and_merge_with_retry_loop` (handles merge_blocked + retry + cancel), then `break` →
  proceed to Completed.
- **rejected** (`:579-654`): under patch drop stakeholder flag; bump G-DA counter; if `>3` fail; else
  re-dispatch 3 steps and loop.

---

## 8. COMPLETED (`rationalization.py:656-664`)

Reached only by `break` from the G-DA approve path.
```text
await self._update_app_status(
    app_id, "rationalization_complete", "completed", "Rationalization")   # :657-659
self._status = WorkflowStatus.COMPLETED       # :660
self._progress_pct = 100.0                    # :661
self._current_step = "completed"              # :662
self._updated_at = _now_iso()                 # :663
return "completed"                            # :664
```
- ⚠️ **GOTCHA-RAT-DONE1 (progress jumps 73.0 → 100.0 on completion):** `_progress_pct` is set directly
  to 100.0 here (`:661`), NOT via `_set_step`. The DB status push uses status `"rationalization_complete"`,
  step `"completed"`. A rebuild must set these four attributes directly + push the app status, then
  `return "completed"`.

---

## 9. PR-body builders + module-level disposition helpers

### 9.1 `_build_grr_pr_body(self, app_id) -> str` (`rationalization.py:698-717`)

```text
rework_iter = self._rework_count("G-RR")               # :700
body = ("## Gate G-RR Review: Rationalization Review\n\n"
        f"**Application:** {app_id}\n\n"
        "### Rationalization Steps Completed\n"
        "- [x] Redundancy Analysis (redundancy-analyzer)\n\n"
        "### Artifacts\n"
        f"- `rationalization/{app_id}/redundancy-matrix.json`\n\n"
        "### Review Checklist\n"
        "- [ ] Pairwise overlap scores are accurate\n"
        "- [ ] Entity, operation, technology, persona overlaps identified\n"
        "- [ ] No false positives in redundancy detection\n")   # :701-714
if rework_iter > 0:                                    # :715  BRANCH
    body += f"\n**Rework iteration:** {rework_iter}\n"  # :716
return body                                            # :717
```
- **Branch** `if rework_iter > 0:` (`:715`) — append a "Rework iteration: N" footer only on rework
  passes. Uses the live `_rework_count("G-RR")`.

### 9.2 `_build_gda_pr_body(self, app_id, disposition: Disposition | None) -> str` (`rationalization.py:719-762`)

```text
disp_label = _disposition_label(disposition)           # :721
body = ("## Gate G-DA Review: Disposition Approval\n\n"
        f"**Application:** {app_id}\n"
        f"**Recommended Disposition:** {disp_label}\n\n"
        "### Rationalization Steps Completed\n"
        "- [x] Redundancy Analysis\n"
        "- [x] Disposition Recommendation\n"
        "- [x] Disposition Governance Validation\n")    # :722-730

if _is_retire_or_replace(disposition):                 # :732  BRANCH 1
    body += "- [x] User Impact Analysis\n"             # :733
else:                                                   # :734
    body += "- [ ] User Impact Analysis (N/A — not Retire/Replace)\n"   # :735

body += ("\n### Artifacts\n"
         f"- `rationalization/{app_id}/disposition-recommendation.json`\n"
         f"- `rationalization/{app_id}/disposition-governance.json`\n")   # :737-743

if _is_retire_or_replace(disposition):                 # :745  BRANCH 2
    body += f"- `rationalization/{app_id}/user-impact-analysis.json`\n"   # :746

body += ("\n### Stakeholder Sign-Off Checklist\n"
         "- [ ] Business owner reviewed disposition recommendation\n"
         "- [ ] Impact analysis reviewed (if applicable)\n"
         "- [ ] Governance policy compliance verified\n"
         "- [ ] Stakeholder approval granted\n"
         "\n**Approval requires BOTH:** PM merges this PR (`gate_approved` signal) "
         'AND stakeholder fires a `StakeholderApprovedSignal` with `scope="g-da"`.\n')   # :748-757

rework_iter_da = self._rework_count("G-DA")            # :759
if rework_iter_da > 0:                                 # :760  BRANCH 3
    body += f"\n**Rework iteration:** {rework_iter_da}\n"   # :761
return body                                            # :762
```
- **Branch 1** `_is_retire_or_replace(disposition)` (`:732`): checked-vs-N/A for the User Impact step
  in the "Steps Completed" list.
- **Branch 2** `_is_retire_or_replace(disposition)` (`:745`): include the user-impact artifact path only
  for Retire/Replace.
- **Branch 3** `if rework_iter_da > 0:` (`:760`): rework footer.
- ⚠️ **GOTCHA-RAT-GDABODY1 (the PR body documents the dual-signal contract verbatim):** `:754-756`
  literally states approval needs BOTH the PM merge (`gate_approved`) AND a `StakeholderApprovedSignal`
  with `scope="g-da"`. This is the human-facing mirror of GOTCHA-RAT-GDA3. A rebuild should keep this
  text so reviewers know to fire both.

### 9.3 `_normalize_disposition(disposition) -> str | None` (`rationalization.py:765-776`)

```text
if disposition is None:                       # :770  BRANCH 1
    return None                               # :771
if isinstance(disposition, Disposition):      # :772  BRANCH 2
    return disposition.value                  # :773
if isinstance(disposition, list):             # :774  BRANCH 3
    return "".join(str(x) for x in disposition)   # :775
return str(disposition)                       # :776  (else)
```
- ⚠️ **GOTCHA-RAT-DISP1 (Temporal serialization may yield enum / str / LIST):** the comment (`:766-769`)
  warns that Temporal deserialization can return the `Disposition` enum as a **list** (e.g. a list of
  characters) or a string. **Branch 3** (`:774-775`) rejoins a list into a string via `"".join(...)` so
  a disposition that arrived as `["R","e","t","i","r","e"]` normalizes back to `"Retire"`. A rebuild
  MUST handle all three shapes (None / Disposition enum / list / other-stringable) in this exact order,
  or `_is_retire_or_replace` will mis-classify a list-shaped disposition and skip the user-impact step.

### 9.4 `_is_retire_or_replace(disposition) -> bool` (`rationalization.py:779-782`)

```text
val = _normalize_disposition(disposition)     # :781
return val in ("Retire", "Replace")           # :782
```
- The single gate for the user-impact step (§7.3, §7.9) and the G-DA PR-body branches (§9.2). Compares
  the NORMALIZED string against the literal tuple `("Retire", "Replace")`. A rebuild must compare against
  these exact two title-cased strings.

### 9.5 `_disposition_label(disposition) -> str` (`rationalization.py:785-788`)

```text
val = _normalize_disposition(disposition)     # :787
return val if val else "TBD"                  # :788  BRANCH
```
- **Branch** `val if val else "TBD"` (`:788`): if normalize returns `None` or empty, the label is the
  literal `"TBD"`. Used in the G-DA PR-body "Recommended Disposition" line.

---

## 10. RESILIENCE

- **Timeouts (start_to_close):** `create_gate_record` 30s; `persist_classification` 60s;
  `confirm_classification_tier_1` 30s. All inherited helper timeouts per `_LineWorkflowBase.md` §19
  (dispatch 1h; commit batch 120s; create_pr 60s; check/submit evidence 60s each; pre-review dispatch
  10m / store 30s / ready-flip 30s; merge 60s; set_gate_merge_blocked 30s; `_update_app_status` 30s).
- **Retry policies:** every direct `workflow.execute_activity` in this file uses
  `RETRY_POLICIES["transient"]` (3 attempts). Inherited dispatch uses `agent_failure`; inherited merge
  uses `git_merge` (with the 3 non_retryable merge error types). NO call in this file uses a no-retry
  policy.
- **Heartbeats:** none configured (relies on start_to_close timeouts).
- **continue-as-new:** none — the workflow runs to terminal status in a single execution. Both gate
  loops are bounded by `MAX_REWORK_ITERATIONS=3` (fail on 4th reject), so the history cannot grow
  unboundedly via rework. The merge_blocked + Tier-1 + dual-signal waits are signal-bounded.
- **Idempotency:** deterministic git branch / workspace_key from `workflow.info().workflow_id`
  (GOTCHA-RAT-RUN1); deterministic activity_ids inherited from `_dispatch_agent`/`_commit_step_artifacts`;
  `_now_iso()`=`workflow.now()` everywhere.
- **Cancellation:** `self.cancelled` (set by inherited `cancel_workflow` signal, a one-way latch) is
  threaded into every blocking wait: the two `_wait_for_gate_decision` calls (base predicate), the
  Tier-1 pause (`:471`), the G-DA dual-signal wait (`:561`), and the inherited merge_blocked wait. Cancel
  drains each to a `"cancelled"` return. ⚠️ A cancel during a gate wait returns `"cancelled"` WITHOUT
  consuming a gate decision or advancing the cursor (base GOTCHA-WG2).
- **Compensation / rollback:** none. Failure semantics: the outer `run()` try/except sets `_status=FAILED`,
  `_current_step="failed"`, best-effort pushes `"rationalization_failed"`, and re-raises (§4). Max-rework
  on either gate is a NORMAL `return "failed"` (not a raise) after setting FAILED + the gate-specific
  `max-rework-exceeded-{grr|gda}` step and DB status. Best-effort activities inside inherited helpers
  (context-priors, mirror, output-ref patch, pre-review, ready-flip) swallow exceptions.

---

## 11. Behavioral parity checklist

A rebuilt `RationalizationWorkflow` MUST satisfy ALL of the following:

1. `@workflow.defn class RationalizationWorkflow(LineWorkflowBase)`; classvars exactly:
   `ASSEMBLY_LINE=AssemblyLine.RATIONALIZATION`, `ARTIFACT_ROOT="rationalization"`,
   `LINE_LABEL="Rationalization"`, `STATUS_PREFIX="rationalization"`, `STEPS=RATIONALIZATION_SKILLS`
   (the 5-entry map §1.1), `STEP_WEIGHTS` (the 7-entry map §1.2). `SINGLE_GATE_KEY` is NOT set.
2. Overrides `_rework_gate_key_for_step` to `"G-RR" if step=="redundancy-analysis" else "G-DA"`
   (GOTCHA-RAT-OV1). Overrides NOTHING else from the base except `__init__` and supplies its own
   `run`/`_execute_rationalization`. Does NOT redefine `gate_approved`/`gate_rejected`/
   `escalation_resolved`/`merge_retry`/`get_status` (GOTCHA-RAT-OV2).
3. `__init__` calls `super().__init__()` first, then sets `_stakeholder_approved=False`,
   `_stakeholder_info=""`, `_tier1_approved_by=None`, `_dispositions={}` (the latter never written —
   GOTCHA-RAT-S1).
4. Defines exactly ONE extra `@workflow.signal stakeholder_approved(signal: StakeholderApprovedSignal)`
   (`async def`, pure mutation): `scope=="tier-1-classification"` → set `_tier1_approved_by=signal.stakeholder`;
   else → `_stakeholder_approved=True` and `_stakeholder_info=f"{stakeholder} approved scope: {scope}"`;
   always bump `_updated_at`. (GOTCHA-RAT-SIG1/2/3)
5. `run()` sets `_status=RUNNING`, `_started_at`/`_updated_at`, hydrates `_app_id`/`_portfolio_id`/
   `_wave_id` from input; derives `run_suffix = wf_id.rsplit("-",1)[-1] if "-" in wf_id else wf_id[:8]`,
   `branch="olympus/rationalization/{app_id}/{run_suffix}"`, `workspace_key="rationalization-{app_id}-{run_suffix}"`;
   wraps `_execute_rationalization` in try/except that on ANY exception sets `_status=FAILED`,
   `_current_step="failed"`, best-effort `_update_app_status(...,"rationalization_failed","failed",...)`,
   and **re-raises**. (GOTCHA-RAT-RUN1/2/3)
6. **STEP 1**: `_set_step("detect-redundancy", 0.0)`; `_dispatch_agent(step_name="redundancy-analysis",
   input_artifacts=list(input.prior_artifacts))`; `_step_results["redundancy-analysis"]=result.output_artifacts`;
   `_commit_step_artifacts(..., "redundancy-analysis", ..., "rationalization/{app_id}/redundancy-matrix.json")`.
7. **G-RR loop** (`while True`): dedup `_step_committed_paths["redundancy-analysis"]`; `_create_gate_pr(gate_type="G-RR",
   body=_build_grr_pr_body)`; `create_gate_record(CreateGateRecordInput(gate_type="G-RR", ...))` 30s/transient;
   `_submit_gate_evidence(GateType.G_RR, step="redundancy-analysis", forward_risk_tier=False)`;
   `_run_gate_pre_review(..., "G-RR", ...)`; `_set_step("gate-review-rr", 20.0)`;
   `decision=_wait_for_gate_decision(GateType.G_RR)`. Route: `"cancelled"`→`return "cancelled"`;
   `"approved"`→`_reconcile_and_merge_with_retry_loop(merge_method="merge")` then `break`; else (rejected)→
   `_bump_rework("G-RR")`, if `>3` set FAILED + `current_step="max-rework-exceeded-grr"` +
   `_update_app_status(...,"max-rework-exceeded-grr",...)` + `return "failed"`, else re-dispatch+re-commit
   step 1 and loop. (GOTCHA-RAT-GRR1..6)
8. **STEP 3**: `progress_after_grr=20.0+15.0=35.0`; `_set_step("recommend-disposition", 35.0)`;
   `_dispatch_agent(step_name="disposition-recommendation", input_artifacts=_step_committed_paths["redundancy-analysis"])`;
   commit to `disposition-recommendation.json`.
9. **STEP 4** (silent sub-phase): `progress_after_disp=35.0+18.0=53.0`; `_set_step("recommend-disposition", 53.0)`
   (SAME UI step string — GOTCHA-RAT-GOV1); `_dispatch_agent(step_name="disposition-governance",
   input_artifacts=_step_committed_paths["disposition-recommendation"])`; commit to `disposition-governance.json`.
10. **STEP 5** (conditional): `progress_after_gov=53.0+8.0=61.0`; `_set_step("assess-user-impact", 61.0)`
    UNCONDITIONALLY; only IF `_is_retire_or_replace(input.disposition)`: `_dispatch_agent(step_name="user-impact",
    input_artifacts=_step_committed_paths["disposition-recommendation"])` + commit to `user-impact-analysis.json`.
    (GOTCHA-RAT-UI1/2)
11. **STEP 6**: `_set_step("classification", 61.0+12.0=73.0)`; `_dispatch_agent(step_name="classification",
    input_artifacts=_step_committed_paths["disposition-recommendation"])` + commit to `classification.json`;
    `persist_classification(PersistClassificationInput(app_id, classification_artifact_path,
    classification_json=result.output_artifacts[0] if result.output_artifacts else ""))` 60s/transient.
    (GOTCHA-RAT-CLS1)
12. **Tier-1 pause** (conditional): IF `persist_result.tier_1_flag`: set `_current_step=
    "classification-awaiting-tier1-approval"` directly (no `_set_step`) + bump `_updated_at`; `await
    wait_condition(lambda: self._tier1_approved_by is not None or self.cancelled)`; if cancelled →
    `_status=CANCELLED`, `return "cancelled"` (BEFORE confirm); else `confirm_classification_tier_1(
    ConfirmClassificationInput(app_id, approved_by=self._tier1_approved_by))` 30s/transient. When NOT
    Tier 1, fall straight through. (GOTCHA-RAT-CLS2/3/4/5)
13. **G-DA loop** (`while True`): build `gda_artifact_paths` by extending exactly
    `["disposition-recommendation","disposition-governance","user-impact"]` (NOT redundancy/classification —
    GOTCHA-RAT-GDA1) then `dedup_paths`; `_create_gate_pr(gate_type="G-DA", body=_build_gda_pr_body(app_id,
    input.disposition))`; `create_gate_record(gate_type="G-DA")` 30s/transient; `_submit_gate_evidence(
    GateType.G_DA, step="disposition-approval", forward_risk_tier=False)`; `_run_gate_pre_review(..., "G-DA", ...)`;
    `_set_step("gate-review-da", 73.0)` (GOTCHA-RAT-GDA2); `decision=_wait_for_gate_decision(GateType.G_DA)`.
14. **G-DA approve**: `if workflow.patched("gda-dual-signal-v1")`: `await wait_condition(lambda:
    self._stakeholder_approved or self.cancelled)`; if cancelled → CANCELLED + `return "cancelled"`; else
    `_stakeholder_approved=False`. Then `_reconcile_and_merge_with_retry_loop(merge_method="merge")` and
    `break`. (GOTCHA-RAT-GDA3/4/5/6)
15. **G-DA reject**: `if workflow.patched("gda-dual-signal-v1")`: `_stakeholder_approved=False`;
    `_bump_rework("G-DA")`; if `>3` set FAILED + `current_step="max-rework-exceeded-gda"` +
    `_update_app_status(...,"max-rework-exceeded-gda",...)` + `return "failed"`; else `_set_step(
    "recommend-disposition", 35.0)` and re-dispatch+re-commit `disposition-recommendation` then
    `disposition-governance` then (IF Retire/Replace) `user-impact`, and loop. (GOTCHA-RAT-GDA4/7/8/9)
16. **Completed**: only after G-DA approve+merge `break`: `_update_app_status(app_id,
    "rationalization_complete","completed","Rationalization")`; `_status=COMPLETED`; `_progress_pct=100.0`
    (direct, not `_set_step`); `_current_step="completed"`; bump `_updated_at`; `return "completed"`.
    (GOTCHA-RAT-DONE1)
17. `_build_grr_pr_body`: fixed markdown + `if _rework_count("G-RR")>0` appends a rework footer.
    `_build_gda_pr_body`: fixed markdown with `_disposition_label(disposition)`; Retire/Replace toggles the
    User Impact line `[x]` vs `[ ] (N/A — not Retire/Replace)` AND whether the user-impact artifact path is
    listed; documents the dual-signal requirement verbatim; `if _rework_count("G-DA")>0` appends a rework
    footer. (GOTCHA-RAT-GDABODY1)
18. `_normalize_disposition` handles None→None, `Disposition`→`.value`, `list`→`"".join(str(x) for x)`,
    else→`str(...)` IN THAT ORDER (GOTCHA-RAT-DISP1). `_is_retire_or_replace` returns
    `_normalize_disposition(d) in ("Retire","Replace")`. `_disposition_label` returns the normalized value
    or `"TBD"` when falsy.
19. ALL `workflow.patched(...)` IDs reproduced VERBATIM: `"gda-dual-signal-v1"` (appears at `:559` and
    `:582`). (Inherited helpers additionally carry `"context-priors-v1"`, `"patch-output-artifact-ref-v1"`,
    `"mark-gate-ready-for-review-v1"` per the base spec.)
20. `_risk_tier` is never set and never forwarded (both gates pass `forward_risk_tier=False`); progress
    monotonically reaches at most 73.0 before the completion jump to 100.0 (GOTCHA-RAT-GDA2). All activity
    imports inside `with workflow.unsafe.imports_passed_through():`. All timestamps via `_now_iso()`.
