# `WaveWorkflow` — Single-Wave App Fan-Out Orchestrator (ATOMIC regeneration spec)

> **Source of truth:** `temporal/olympus_workflows/workflows/wave.py` (247 lines, HEAD `7cb3b20c`).
> Every `wave.py:line` citation below is against that file at HEAD.
>
> **What this is:** the per-wave coordinator. It fans out one `AppWorkflow` **child
> workflow** per application id in the wave, under an `asyncio.Semaphore` concurrency cap
> (default 10), with **failure isolation** (one app failing does not block the rest). It
> also accepts a small surface of signals (gate decisions, app removal, override /
> escalation / stakeholder / wave-patterns) and exposes two queries (`get_status`,
> `get_app_status`). It does **NOT** itself run any gate, dispatch any agent, commit any
> artifact, or merge any PR — those are the child workflows' jobs.
>
> ⚠️ **CHANGED-SINCE-OLD-SPEC (gate model is now point-to-point, NOT a Phase-2 TODO):** the
> previous baseline carried a `_pending_gate_signals` buffer and two `# TODO(Phase 2): Forward
> gate signals to active child workflows` comments. **Both are GONE.** Per **P5-S30.6 (decided
> 2026-06-09)** gates are delivered point-to-point: the API (`send_gate_temporal_signal`)
> signals the workflow that *created* the gate (looked up by `workflow_id` on the gate row).
> There is no wave-grain gate today and nothing awaits one. Consequently:
> (a) the `_pending_gate_signals: list[dict]` field was **deleted** from `__init__`;
> (b) `gate_approved` / `gate_rejected` no longer buffer any dict — they are now **inert
> "accept-and-ignore" no-ops** that only bump `_updated_at` (`wave.py:151-159`);
> (c) the wave-level gate `G-WAVE-DC` is **intentionally NOT implemented** and is documented as
> such (`wave.py:125-132`, `:142-150`), not left as a bare TODO.
> A rebuild MUST reproduce the new behavior: **no buffer, no forward, six timestamp-only signal
> no-ops** (see §2, §4). Anyone porting the OLD spec MUST delete `_pending_gate_signals` and the
> dict-append bodies.
>
> **Inherits:** `class WaveWorkflow(HILSignalsMixin)` (`wave.py:33`). ⚠️ **It does NOT
> inherit `LineWorkflowBase`.** See `_HILSignalsMixin.md` for the six inherited HIL signals
> (`approve_plan`, `provide_plan_feedback`, `approve_research`, `provide_feedback`,
> `approve`, `cancel_workflow`), the inherited HIL state vars, the `reset_*` /
> `is_*_decision_received` helpers, and the `create_*_signal` factories. WaveWorkflow's
> `__init__` calls `super().__init__()` first (`wave.py:48`) so those HIL vars are
> initialized before the wave-specific state.
>
> ⚠️ **GOTCHA-INHERIT (this is NOT a `LineWorkflowBase` subclass — do not import base
> behavior):** `_LineWorkflowBase.md` describes `gate_approved`, `gate_rejected`,
> `escalation_resolved`, `get_status`, `_wait_for_gate_decision`, `_dispatch_agent`, etc. as
> *base* methods that line workflows MUST NOT redefine. **None of that applies here.**
> WaveWorkflow is a sibling of `LineWorkflowBase`, not a descendant. It defines its **own**
> `gate_approved` / `gate_rejected` / `escalation_resolved` / `get_status` with **different
> bodies** from the `LineWorkflowBase` versions. ⚠️ As of HEAD, WaveWorkflow's `gate_approved`/
> `gate_rejected` are now *timestamp-only no-ops* — they no longer buffer anything — whereas
> `LineWorkflowBase.gate_approved` buffers a 5-tuple onto `_gate_decisions`. A rebuild MUST NOT
> mix the two surfaces. There is no `_gate_decisions`, no `_pending_gate_signals`, no
> `_rework_feedback`, no `_wait_for_gate_decision`, no merge loop, no `_dispatch_agent`, no
> `ARTIFACT_ROOT`/`STEPS`/`STATUS_PREFIX` classvars on WaveWorkflow.

---

## 0. Imports, decorator, time helper

- `from __future__ import annotations` at top (`wave.py:8`).
- `import asyncio` (`wave.py:10`) — used for `asyncio.Semaphore`, `asyncio.ensure_future`,
  `asyncio.gather`.
- `from foundry_temporal.signals import HILSignalsMixin` (`wave.py:12`) — the base mixin.
- `from temporalio import workflow` (`wave.py:13`).
- ⚠️ **GOTCHA-IMPORTS:** all `olympus_workflows.types` imports are gated behind
  `with workflow.unsafe.imports_passed_through():` (`wave.py:15-29`) so the Temporal sandbox
  does not re-import/re-execute them on replay. The imported names: `AppStatusResponse`,
  `AppWorkflowInput`, `EscalationResolvedSignal`, `GateApprovedSignal`, `GateRejectedSignal`,
  `OverrideApprovedSignal`, `RemoveAppFromWaveSignal`, `StakeholderApprovedSignal`,
  `WavePatternsReadySignal`, `WaveStatusResponse`, `WaveWorkflowInput`, `WorkflowStatus`. A
  rebuild that moves these to module top level risks sandbox nondeterminism. ⚠️ NOTE the import
  list NO LONGER needs any pending-gate-signal type — the gate signal types
  (`GateApprovedSignal`, `GateRejectedSignal`) are still imported only because the two inert
  handlers type-annotate their `signal` param.
- `@workflow.defn` on the class (`wave.py:32`).
- **Time helper** — module-level `_now_iso() -> str` (`wave.py:244-246`):
  ```text
  def _now_iso():
      return workflow.now().isoformat()        # wave.py:246  ← deterministic under replay
  ```
  ⚠️ **GOTCHA-TIME:** every timestamp in this workflow goes through `_now_iso()` →
  `workflow.now().isoformat()`. NEVER `datetime.now()`. Deterministic under Temporal replay.
  It is a **module-level function**, not a method (same shape as the base specs' `_now_iso`).

---

## 1. STATE — every instance var (`__init__`, `wave.py:47-59`)

`__init__` calls `super().__init__()` **first** (`wave.py:48`) — initializing the inherited HIL
vars (see `_HILSignalsMixin.md` §1) — then sets the following wave-specific vars. Types are the
literal annotations in source.

⚠️ **CHANGED-SINCE-OLD-SPEC:** the old spec listed **nine** wave vars including
`_pending_gate_signals: list[dict] = []` at `wave.py:53`. That field is **DELETED**. There are
now **eight** wave vars, and `_wave_gate_status` has moved to `wave.py:53`.

| Var | Type | Initial | Line | Mutated by → value | When |
|-----|------|---------|------|---------------------|------|
| `_status` | `WorkflowStatus` | `WorkflowStatus.PENDING` | 50 | `run()` → `RUNNING` (`wave.py:71`) then `COMPLETED` (`wave.py:134`) | run start / run end |
| `_app_statuses` | `dict[str, WorkflowStatus]` | `{}` | 51 | `run()` seeds each app `PENDING` (`:79`); `run_one_app` → `RUNNING` (`:90`) / `COMPLETED` (`:109`) / `FAILED` (`:117`); `remove_app` → `CANCELLED` (`:166`) | run start, per-app lifecycle, remove |
| `_removed_apps` | `set[str]` | `set()` | 52 | `remove_app` adds `app_id` (`wave.py:165`) | on `remove_app` signal |
| `_wave_gate_status` | `str \| None` | `None` | 53 | **never written anywhere in wave.py** | — (declared, unused; see GOTCHA-WGS) |
| `_started_at` | `str` | `""` | 54 | `run()` → `_now_iso()` (`wave.py:72`) | run start |
| `_updated_at` | `str` | `""` | 55 | `run()` (`:73,110,118,135`), `run_one_app` per transition, every signal handler (`:154,159,167,181,186,191,196`) | many |
| `_wave_id` | `str` | `""` | 58 | `run()` → `input.wave_id` (`wave.py:74`) | run start; read by `remove_app`, `get_app_status`, `get_status` |
| `_portfolio_id` | `str` | `""` | 59 | `run()` → `input.portfolio_id` (`wave.py:75`) | run start; stored for query handlers (currently unread by queries) |

> ⚠️ **GOTCHA-NO-PGS (`_pending_gate_signals` NO LONGER EXISTS):** the old baseline had a
> write-only `_pending_gate_signals` list that `gate_approved`/`gate_rejected` appended dicts
> to. **It is gone.** The gate handlers store NOTHING now (§4.1/§4.2). A rebuild MUST NOT
> reintroduce this field or any gate-signal buffering — that would diverge from HEAD, where the
> deliberate design (P5-S30.6) is that the wave consumes no wave-level gate state. Do **not**
> confuse this with `LineWorkflowBase._gate_decisions` (a different var on a different class).
> ⚠️ **GOTCHA-WGS (`_wave_gate_status` is dead state):** declared `str | None = None`
> (`wave.py:53`) and **never assigned** anywhere. It exists for the future `G-WAVE-DC`
> wave-gate (which is intentionally not implemented, `wave.py:125-132`). A rebuild declares it
> as `None` and never writes it.
> ⚠️ **GOTCHA-HILUNUSED (inherited HIL state is present but unused by wave logic):** the HIL
> vars from `super().__init__()` exist (so `approve`/`cancel_workflow`/etc. are live wire
> signals on this workflow), but **the wave `run()` never reads `self.cancelled` or any HIL
> flag** — there is no `wait_condition` in this workflow at all (see §3 / GOTCHA-NOWAIT). So
> sending `cancel_workflow` flips `self.cancelled=True` but does NOT interrupt the fan-out; the
> only effective cancel surface is `remove_app` per-app (§4.3) or Temporal-level workflow
> cancellation. A rebuild MUST keep the inherited signals registered (they come for free via
> the mixin) but MUST NOT wire `self.cancelled` into the fan-out — matching the live behavior
> where it has no effect on `run()`.

---

## 2. SIGNALS / QUERIES — surface inventory

WaveWorkflow exposes, in total:
- **6 inherited HIL signals** (from `HILSignalsMixin`, NOT redefined): `approve_plan`,
  `provide_plan_feedback`, `approve_research`, `provide_feedback`, `approve`,
  `cancel_workflow`. See `_HILSignalsMixin.md`. ⚠️ These come for free via inheritance; a
  rebuild MUST NOT redefine them, and (GOTCHA-HILUNUSED) the wave logic ignores their state.
- **7 own `@workflow.signal` handlers** (defined on this class — §4): `gate_approved`,
  `gate_rejected`, `remove_app`, `override_approved`, `escalation_resolved`,
  `stakeholder_approved`, `wave_patterns_ready`.
- **2 own `@workflow.query` handlers** (defined on this class — §5): `get_status`,
  `get_app_status`.
- **0 updates.**

⚠️ **CHANGED-SINCE-OLD-SPEC (now SIX timestamp-only no-op signals, was four):** in the old
baseline, `gate_approved`/`gate_rejected` did real buffering work and only the other four
(`override_approved`, `escalation_resolved`, `stakeholder_approved`, `wave_patterns_ready`)
were no-ops. At HEAD, `gate_approved`/`gate_rejected` are ALSO inert
(`wave.py:151-159`) — so **six of the seven own signals are pure `self._updated_at = _now_iso()`
no-ops**, and only `remove_app` (§4.3) does real work (it awaits an external child cancel).

⚠️ **GOTCHA-ASYNCSIG (every own signal handler is `async def`):** all seven own signal
handlers are declared `async def` (`wave.py:151,156,161,178,183,188,193`), unlike the
synchronous HIL mixin handlers. Only `remove_app` actually awaits anything (an external
handle cancel, §4.3); the other six are async but body-synchronous (just a `_now_iso()` bump).
A rebuild should declare them `async def` to match (so the `await` in `remove_app` is
well-formed and the signal-registration shape matches), even though six of them do not await.

⚠️ **GOTCHA-NODUP (these are NOT the LineWorkflowBase signals — name collision is fine):**
WaveWorkflow defines `gate_approved`, `gate_rejected`, `escalation_resolved` with the SAME
names as `LineWorkflowBase`'s, but because WaveWorkflow does NOT inherit `LineWorkflowBase`,
there is no duplicate-registration crash. These are the **only** definitions of those names on
this class's MRO (the MRO is `WaveWorkflow → HILSignalsMixin → object`, and the mixin defines
none of them). A rebuild must define them directly on the wave class with the bodies below —
do NOT inherit them, do NOT skip them expecting a base to supply them.

---

## 3. `run(input: WaveWorkflowInput) -> str` — fan-out orchestration (`wave.py:62-136`) ★ CORE

The `@workflow.run` entrypoint (`wave.py:61-62`). Seeds per-app status, builds a concurrency
semaphore, defines a nested `run_one_app` coroutine, fans out all apps via
`asyncio.gather(..., return_exceptions=True)`, then marks the wave complete. **Returns the
literal string `"completed"`** (always, on the happy path — see GOTCHA-RETURN).

### 3.1 Input type — `WaveWorkflowInput` (`types.py:1149-1158`)
```text
@dataclass
class WaveWorkflowInput:
    wave_id: str
    wave_name: str
    portfolio_id: str
    artifact_repo: str = ""                       # flows down from portfolio
    app_ids: list[str] = field(default_factory=list)
    max_apps_per_wave: int = MAX_APPS_PER_WAVE     # MAX_APPS_PER_WAVE = 10  (types.py:132)
```
The fields `run()` reads: `wave_id`, `portfolio_id`, `app_ids`, `max_apps_per_wave`,
`artifact_repo`. (`wave_name` is accepted but unread by `run()`.)

### 3.2 `run()` pseudocode (preserve EVERY statement/branch/loop)

```text
@workflow.run
async def run(self, input: WaveWorkflowInput) -> str:
    # ── Phase A: initialize wave-level state ──────────────────────────
    self._status      = WorkflowStatus.RUNNING        # wave.py:71
    self._started_at  = _now_iso()                    # wave.py:72
    self._updated_at  = self._started_at              # wave.py:73  (same value, not a 2nd now())
    self._wave_id     = input.wave_id                 # wave.py:74
    self._portfolio_id = input.portfolio_id           # wave.py:75

    # Seed per-app status to PENDING
    for app_id in input.app_ids:                      # wave.py:78   LOOP 1
        self._app_statuses[app_id] = WorkflowStatus.PENDING   # wave.py:79

    # ── Phase B: build concurrency limiter ────────────────────────────
    semaphore = asyncio.Semaphore(input.max_apps_per_wave)    # wave.py:82

    # ── Phase C: per-app coroutine (defined inline; see §3.3) ─────────
    async def run_one_app(app_id: str) -> str: ...    # wave.py:84-119

    # ── Phase D: fan out ALL apps, isolate failures ───────────────────
    tasks = [asyncio.ensure_future(run_one_app(app_id))       # wave.py:122  LOOP 2 (comprehension)
             for app_id in input.app_ids]
    await asyncio.gather(*tasks, return_exceptions=True)      # wave.py:123  ★ return_exceptions=True

    # P5-S30.6 NOTE (wave.py:125-132): a wave-level gate (G-WAVE-DC) before
    # Rationalization was scoped here but is INTENTIONALLY NOT IMPLEMENTED —
    # gates are delivered point-to-point (API signals the gate-creating
    # workflow by workflow_id); nothing awaits a wave-grain gate. NOT a TODO.

    # ── Phase E: mark wave complete ───────────────────────────────────
    self._status     = WorkflowStatus.COMPLETED       # wave.py:134
    self._updated_at  = _now_iso()                    # wave.py:135
    return "completed"                                # wave.py:136
```

**Branch / loop inventory in `run()` proper (excluding the nested coroutine):**
- **LOOP 1** — `for app_id in input.app_ids: self._app_statuses[app_id] = PENDING`
  (`wave.py:78-79`). Seeds the status dict in input order.
- **LOOP 2** — the list comprehension `[asyncio.ensure_future(run_one_app(app_id)) for app_id
  in input.app_ids]` (`wave.py:122`). Schedules every app's coroutine as a Task.
- (No `if`/`elif`/`else`/`try`/`except` at the `run()` top level — all conditionals live in
  the nested `run_one_app`, §3.3.)

> ⚠️ **CHANGED-SINCE-OLD-SPEC (the inter-phase TODO is now an architectural NOTE):** between
> `gather` and the COMPLETED write there used to be a single
> `# TODO(Phase 2): wave-level gate signal (G-WAVE-DC)` line. At HEAD this is an 8-line block
> comment (`wave.py:125-132`) explaining that `G-WAVE-DC` is **intentionally not implemented**
> and gates are point-to-point. It is documentation only; it changes no control flow. A rebuild
> MUST NOT add any gate wait / signal here — the gather→COMPLETED→`return "completed"` sequence
> is unbroken.
> ⚠️ **GOTCHA-GATHER (`return_exceptions=True` is the failure-isolation mechanism at the
> gather level):** `asyncio.gather(*tasks, return_exceptions=True)` (`wave.py:123`). With
> `return_exceptions=True`, if any `run_one_app` task raised, the exception is **returned as a
> result element** instead of being re-raised out of `gather`. Combined with the per-coroutine
> `try/except` (§3.3) — which already swallows child-workflow failures and returns `"failed"` —
> this is belt-and-suspenders: even an exception that escapes `run_one_app` (e.g. the
> `_now_iso()`/status writes) would not abort the whole wave. A rebuild MUST pass
> `return_exceptions=True`; a bare `await asyncio.gather(*tasks)` would propagate the first
> failure and fail the whole wave, violating the failure-isolation contract (`wave.py:4-5`,
> `:112-119`).
> ⚠️ **GOTCHA-ENSURE-FUTURE (schedule-all-then-gather, not gather-of-coros):** the code wraps
> each coroutine in `asyncio.ensure_future(...)` to create Tasks **before** awaiting `gather`
> (`wave.py:122-123`). Functionally under `asyncio.gather` this is equivalent to passing
> coroutines, but the explicit `ensure_future` materializes the Tasks list. A rebuild may pass
> the coroutines directly to `gather`, but to be faithful keep the `ensure_future` wrap. NOTE:
> the semaphore (not the scheduling) is what bounds concurrency — all N tasks are *scheduled*
> immediately, but only `max_apps_per_wave` get past `async with semaphore` at once (§3.3).
> ⚠️ **GOTCHA-RETURN (`run()` ALWAYS returns `"completed"`):** there is no failure return path
> from `run()`. Even if every child app failed, `run()` sets `_status = COMPLETED` and returns
> `"completed"` (`wave.py:134-136`). The wave "completing" means "the fan-out finished", NOT
> "all apps succeeded". Per-app success/failure is reflected only in `_app_statuses` (queried
> via `get_status`/`get_app_status`). A rebuild MUST return the literal `"completed"`
> unconditionally here and MUST NOT raise or return `"failed"` from `run()` on child failure.
> ⚠️ **GOTCHA-STARTED-AT (started_at reused for first updated_at):** `_updated_at =
> self._started_at` (`wave.py:73`) assigns the SAME string value, not a second `_now_iso()`
> call. So at run start `_started_at == _updated_at` exactly. A rebuild must reuse the value,
> not call `_now_iso()` twice (which under replay would still be equal, but reuse is the
> literal code).
> ⚠️ **GOTCHA-NOWAIT (no `wait_condition`, no continue-as-new, no gate wait in the wave):**
> `run()` has NO `workflow.wait_condition(...)`, NO `continue_as_new`, NO gate-decision wait,
> NO `workflow.sleep`. The only suspension point is `await asyncio.gather(...)` over the child
> workflows. Consequently `self.cancelled` (from `cancel_workflow`) has no effect on `run()`
> (GOTCHA-HILUNUSED). The wave-level gate (`G-WAVE-DC`) that *would* introduce a
> `wait_condition` is intentionally unimplemented (`wave.py:125-132`). A rebuild MUST NOT add a
> `wait_condition` here.

### 3.3 `run_one_app(app_id: str) -> str` — nested per-app coroutine (`wave.py:84-119`) ★ CORE

Defined **inside** `run()` so it closes over `input` and `semaphore` and `self`. Acquires the
semaphore, short-circuits if the app was removed, marks RUNNING, spawns the `AppWorkflow`
child, and translates success/failure into `_app_statuses` + a return string. **Branch-heavy.**

```text
async def run_one_app(app_id: str) -> str:
    async with semaphore:                                         # wave.py:86  ★ concurrency gate
        if app_id in self._removed_apps:                          # wave.py:87  BRANCH 1 (removed?)
            return "removed"                                      # wave.py:88  ← early return, never spawns child

        self._app_statuses[app_id] = WorkflowStatus.RUNNING       # wave.py:90
        self._updated_at = _now_iso()                             # wave.py:91

        try:                                                      # wave.py:93  BRANCH 2 (try)
            child_input = AppWorkflowInput(                       # wave.py:94-100
                app_id        = app_id,
                app_name      = app_id,           # ← AppWorkflow will resolve real name (wave.py:96)
                wave_id       = input.wave_id,
                portfolio_id  = input.portfolio_id,
                artifact_repo = input.artifact_repo,
            )
            await workflow.execute_child_workflow(                # wave.py:102-107  ★ CHILD WORKFLOW
                "AppWorkflow",
                child_input,
                id        = f"app-{app_id}-wave-{input.wave_id}",     # wave.py:105  ★ deterministic id
                task_queue= workflow.info().task_queue,               # wave.py:106  ← inherit parent's queue
            )
            self._app_statuses[app_id] = WorkflowStatus.COMPLETED # wave.py:109
            self._updated_at = _now_iso()                         # wave.py:110
            return "completed"                                    # wave.py:111
        except Exception:                                         # wave.py:112  BRANCH 3 (except — failure isolation)
            # Failure isolation: one app failing must not block others.
            # If the app was removed via signal mid-flight, keep CANCELLED
            # rather than overwriting with FAILED.
            if app_id not in self._removed_apps:                  # wave.py:116  BRANCH 4 (removed guard)
                self._app_statuses[app_id] = WorkflowStatus.FAILED   # wave.py:117
            self._updated_at = _now_iso()                         # wave.py:118
            return "failed"                                       # wave.py:119
```

**Branch inventory in `run_one_app` (4):**
1. **`if app_id in self._removed_apps:`** (`wave.py:87`) → `return "removed"` immediately,
   INSIDE the semaphore but BEFORE marking RUNNING and BEFORE spawning the child. So an app
   removed before its turn never spawns an `AppWorkflow` child.
2. **`try:`** (`wave.py:93`) → wraps the child-workflow spawn + the success status writes.
3. **`except Exception:`** (`wave.py:112`) → failure isolation. Catches ANY exception from the
   child workflow (or the status writes inside the try).
4. **`if app_id not in self._removed_apps:`** (`wave.py:116`) inside the `except` → only
   overwrite the status to `FAILED` if the app was NOT removed. If it WAS removed (concurrent
   `remove_app` signal set it to `CANCELLED` and added it to `_removed_apps`), the
   `CANCELLED` status is preserved (the `if` is False, so the `FAILED` write is skipped).

> ⚠️ **GOTCHA-SEM (the semaphore — scheduled-all but bounded-running):** `semaphore =
> asyncio.Semaphore(input.max_apps_per_wave)` (`wave.py:82`, default 10 via `MAX_APPS_PER_WAVE`
> = `types.py:132`). Every app's coroutine is *scheduled* immediately (`ensure_future`,
> `wave.py:122`), but `async with semaphore` (`wave.py:86`) admits at most
> `max_apps_per_wave` coroutines into the body concurrently. The `if app_id in
> self._removed_apps` check (`wave.py:87`) is INSIDE the semaphore — so a removal that lands
> while an app is queued behind the semaphore will short-circuit it to `"removed"` the moment
> it acquires the slot, without spawning a child. A rebuild MUST: (a) size the semaphore from
> `input.max_apps_per_wave`, (b) put the `removed` check INSIDE `async with semaphore`, not
> before scheduling. ⚠️ **Determinism note:** `asyncio.Semaphore` is deterministic under
> Temporal's single-threaded event loop (Temporal drives the loop); admission order follows the
> Task-scheduling order, which follows the comprehension order, which follows `input.app_ids`
> order. A rebuild MUST preserve `app_ids` ordering for replay determinism.
> ⚠️ **GOTCHA-CHILD-ID (deterministic child workflow id):** `id=f"app-{app_id}-wave-{input.wave_id}"`
> (`wave.py:105`). This id is **the contract** with two other parts of the system:
> (1) `remove_app` reconstructs the exact same id to cancel the child via
> `get_external_workflow_handle` (`wave.py:171-173`); (2) `get_app_status` returns this exact id
> as `workflow_id` (`wave.py:240`). A rebuild MUST use this EXACT template
> `app-{app_id}-wave-{wave_id}` verbatim — any divergence breaks both the cancel path and the
> status query, and (because child ids are part of workflow history) breaks replay determinism
> for in-flight waves.
> ⚠️ **GOTCHA-CHILD-NAME (`app_name=app_id` is intentional):** the child input sets
> `app_name=app_id` (`wave.py:96`) — i.e. the app's UUID is passed as the name placeholder; the
> comment notes "AppWorkflow will resolve name". A rebuild MUST pass `app_id` as `app_name`
> here, not look up the real name (that resolution is the child's job).
> ⚠️ **GOTCHA-TASKQUEUE (child inherits parent's task queue):** `task_queue=workflow.info().task_queue`
> (`wave.py:106`) routes the child to the SAME task queue as this wave workflow. A rebuild MUST
> inherit the parent's queue, not hard-code one — the worker fleet that runs waves also runs
> apps. (No retry policy, timeout, or `id_reuse_policy` is specified on `execute_child_workflow`
> — see GOTCHA-CHILD-DEFAULTS.)
> ⚠️ **GOTCHA-CHILD-DEFAULTS (no explicit retry/timeout/cancellation-type on the child spawn):**
> the `execute_child_workflow` call passes ONLY `workflow_type`, `arg`, `id`, `task_queue`
> (`wave.py:102-107`). It specifies **no** `retry_policy`, **no** `execution_timeout`, **no**
> `id_reuse_policy`, **no** `parent_close_policy`, **no** `cancellation_type`. So Temporal
> defaults apply (child workflows by default have NO retry policy → a child failure surfaces as
> a single exception to the parent, which the `except Exception` then isolates). A rebuild MUST
> NOT add a child retry policy or timeouts here — that would change how/whether a failing app is
> retried before the parent isolates it.
> ⚠️ **GOTCHA-EXCEPT-BARE (`except Exception` catches CancelledError? — NO):** `except
> Exception` (`wave.py:112`) catches `Exception` subclasses. In Python `asyncio.CancelledError`
> is a `BaseException` (not an `Exception`) since 3.8, and Temporal's child-cancellation /
> workflow-cancellation surfaces accordingly — so a Temporal-level cancel of THIS wave workflow
> would NOT be swallowed by this `except` and would propagate to cancel the wave. But a normal
> child-workflow *failure* (the child raised / failed) surfaces as a Temporal
> `ChildWorkflowError` (an `Exception`), which IS caught here. A rebuild MUST use `except
> Exception` (not `except BaseException`) so cooperative cancel of the wave still works while
> child *failures* are isolated.
> ⚠️ **GOTCHA-REMOVE-RACE (the `not in _removed_apps` guard in the except is the cancel/fail
> tiebreaker):** `remove_app` (§4.3) does THREE things: adds to `_removed_apps`, sets status
> `CANCELLED`, and `await`s a cancel of the child. Cancelling the child causes the
> `execute_child_workflow` await in `run_one_app` to raise → the `except` runs. WITHOUT the `if
> app_id not in self._removed_apps` guard (`wave.py:116`), the except would overwrite the
> `CANCELLED` status with `FAILED`. WITH the guard, the `FAILED` write is skipped and
> `CANCELLED` survives. A rebuild MUST keep this guard EXACTLY — it is the difference between a
> user-removed app showing as `CANCELLED` vs. `FAILED`. (The coroutine still returns `"failed"`
> at `wave.py:119` even when removed — the RETURN string is not consumed by anyone, only the
> `_app_statuses` value is observable; see GOTCHA-RETURNVAL.)
> ⚠️ **GOTCHA-RETURNVAL (the per-app return strings are never read):** `run_one_app` returns
> `"removed"` / `"completed"` / `"failed"`, but `asyncio.gather(..., return_exceptions=True)`
> (`wave.py:123`) discards the results (the gather's return value is not assigned). The
> *observable* per-app outcome is `_app_statuses`, mutated in-place. A rebuild may return these
> strings for clarity but MUST drive observable state through `_app_statuses`, not the return
> values. (Keep the strings to match source; they're harmless.)

---

## 4. SIGNAL HANDLERS (own — `@workflow.signal`, all `async def`)

> ⚠️ **CHANGED-SINCE-OLD-SPEC (read first):** §4.1 and §4.2 (`gate_approved` / `gate_rejected`)
> have been **rewritten at HEAD**. They no longer buffer dicts onto `_pending_gate_signals` —
> that field is gone (§1 GOTCHA-NO-PGS). Both are now bare "accept-and-ignore" handlers whose
> ONLY effect is `self._updated_at = _now_iso()`. The class-level comment block at
> `wave.py:142-150` documents WHY (gates are point-to-point per P5-S30.6; children own and await
> their own gates directly; the handlers are retained so a mis-addressed signal is a benign
> no-op rather than an "unhandled signal" error). A rebuild MUST drop the old dict-append bodies.

### 4.1 `gate_approved(self, signal: GateApprovedSignal) -> None` — `wave.py:151-154`
Payload `GateApprovedSignal` (`olympus-contracts/olympus_contracts/signals.py:24-43`):
`gate_id`, `approved_by`, `justification=""`, `card_decisions: List[dict]=[]`,
`reviewer_notes: Optional[str]=None`.
```text
@workflow.signal
async def gate_approved(self, signal):
    """Accept-and-ignore: gates are signalled point-to-point (see class comment)."""
    self._updated_at = _now_iso()       # wave.py:154   ← ONLY effect (no buffering, no forward)
```
- ⚠️ **GOTCHA-GA1 (inert; stores NOTHING — CHANGED):** the handler reads NO fields off `signal`
  and stores nothing. This is the deliberate point-to-point design (`wave.py:142-150`,
  P5-S30.6). The OLD spec's 6-key dict append (`{"type":"approved", ...}`) is GONE. A rebuild
  registers the signal (so a sender doesn't get "unknown signal") and only bumps `_updated_at`.
- ⚠️ **GOTCHA-GA2 (still NOT `LineWorkflowBase.gate_approved`):** the base version appends a
  5-tuple to `_gate_decisions`. THIS version does nothing but bump the timestamp. A rebuild must
  reproduce THIS inert body on WaveWorkflow, not the base tuple and not the old dict.

### 4.2 `gate_rejected(self, signal: GateRejectedSignal) -> None` — `wave.py:156-159`
Payload `GateRejectedSignal` (`olympus-contracts/olympus_contracts/signals.py:46-68`):
`gate_id`, `rejected_by`, `reason`, `reason_category: Optional[str]=None`,
`card_decisions: List[dict]=[]`, `reviewer_notes: Optional[str]=None`.
```text
@workflow.signal
async def gate_rejected(self, signal):
    """Accept-and-ignore: gates are signalled point-to-point (see class comment)."""
    self._updated_at = _now_iso()       # wave.py:159   ← ONLY effect (no buffering, no forward)
```
- ⚠️ **GOTCHA-GR1 (inert; stores NOTHING — CHANGED):** identical inert shape to `gate_approved`.
  The OLD spec's `{"type":"rejected", ...}` dict append is GONE. A rebuild bumps `_updated_at`
  only.

### 4.3 `remove_app(self, signal: RemoveAppFromWaveSignal) -> None` — `wave.py:161-176` ★
Payload `RemoveAppFromWaveSignal` (`types.py:173-179`): `app_id`, `reason=""`,
`removed_by=""`. This is the ONLY own signal that does real work (it awaits a cancel).
```text
@workflow.signal
async def remove_app(self, signal):
    app_id = signal.app_id                              # wave.py:164
    self._removed_apps.add(app_id)                      # wave.py:165  ← mark removed
    self._app_statuses[app_id] = WorkflowStatus.CANCELLED   # wave.py:166  ← status CANCELLED
    self._updated_at = _now_iso()                       # wave.py:167

    # Attempt to cancel the in-flight child workflow (best-effort)
    try:                                                # wave.py:170  BRANCH (try)
        child_handle = workflow.get_external_workflow_handle(   # wave.py:171-173
            f"app-{app_id}-wave-{self._wave_id}"        # wave.py:172  ← SAME id template as spawn
        )
        await child_handle.cancel()                     # wave.py:174  ★ await external cancel
    except Exception:                                   # wave.py:175  BRANCH (except — best-effort)
        pass    # child may not exist yet or already completed   # wave.py:176
```
**Branch inventory (1 try / 1 except):**
- **`try:`** (`wave.py:170`) wrapping the handle lookup + `await child_handle.cancel()`.
- **`except Exception: pass`** (`wave.py:175-176`) — swallows ALL exceptions. The child may
  not have been spawned yet (the app is still queued behind the semaphore) or may already have
  completed; either way the cancel is best-effort.

> ⚠️ **GOTCHA-RA1 (three writes BEFORE the cancel — order matters for the race):** `remove_app`
> mutates state in this exact order: `_removed_apps.add(app_id)` → `_app_statuses[app_id] =
> CANCELLED` → `_updated_at` → then awaits the child cancel (`wave.py:165-174`). Because the
> `_removed_apps.add` and the `CANCELLED` write happen BEFORE the `await`, they are committed in
> the same workflow task synchronously. If the child cancel causes `run_one_app`'s
> `execute_child_workflow` await to raise, `run_one_app`'s `except` then checks `app_id not in
> self._removed_apps` (`wave.py:116`) — which is now FALSE (we just added it) — so the
> `CANCELLED` status survives (GOTCHA-REMOVE-RACE). A rebuild MUST perform the `add` + status
> write BEFORE the `await cancel()`, or the race resolves to `FAILED` instead of `CANCELLED`.
> ⚠️ **GOTCHA-RA2 (`get_external_workflow_handle`, NOT a child handle):** the cancel uses
> `workflow.get_external_workflow_handle(child_id)` (`wave.py:171`) — by **workflow id string**
> — not a handle captured from `execute_child_workflow`. This is deliberate: `run_one_app` does
> not store the child handle anywhere the signal handler can reach (it's a local in a different
> coroutine), so the signal reconstructs the id and gets an *external* handle to it. A rebuild
> MUST use `get_external_workflow_handle(f"app-{app_id}-wave-{self._wave_id}")` with
> `self._wave_id` (the instance var set in `run()`), matching the spawn id template
> (GOTCHA-CHILD-ID).
> ⚠️ **GOTCHA-RA3 (cancel of a not-yet-started child is swallowed):** if the removed app is
> still queued behind the semaphore, no child exists yet; `get_external_workflow_handle(...)`
> may succeed (handles are lazy) but `cancel()` targets a non-existent workflow, raising — and
> the `except Exception: pass` swallows it. The app still gets short-circuited to `"removed"`
> when it later acquires the semaphore (the `if app_id in self._removed_apps` check at
> `wave.py:87` is now True). A rebuild MUST keep the broad `except ... pass` so a remove of a
> queued app does not crash the signal handler.
> ⚠️ **GOTCHA-RA4 (no removal of `app_id` from `_app_statuses`):** `remove_app` does NOT delete
> the app from `_app_statuses`; it sets its value to `CANCELLED`. So `total_apps` in
> `get_status` still counts it, and it counts toward `apps_blocked` (CANCELLED is in the blocked
> set, §5.1). A rebuild MUST set CANCELLED, not delete the key.

### 4.4 `override_approved(self, signal: OverrideApprovedSignal) -> None` — `wave.py:178-181`
Payload `OverrideApprovedSignal` (`types.py:144-151`): `gate_id`, `override_by`,
`justification`, `override_type: OverrideType`.
```text
async def override_approved(self, signal):
    self._updated_at = _now_iso()       # wave.py:181   ← ONLY effect
```
⚠️ **GOTCHA-NOOP1:** no-op except the `_updated_at` bump. The payload is **not stored**
anywhere. A rebuild registers the signal (so a sender doesn't get an "unknown signal" error)
and only bumps `_updated_at`.

### 4.5 `escalation_resolved(self, signal: EscalationResolvedSignal) -> None` — `wave.py:183-186`
Payload `EscalationResolvedSignal` (`types.py:154-161`): `escalation_id`, `resolved_by`,
`resolution_type: ResolutionType`, `resolution`.
```text
async def escalation_resolved(self, signal):
    self._updated_at = _now_iso()       # wave.py:186   ← ONLY effect ("currently stores for later use")
```
⚠️ **GOTCHA-NOOP2:** no-op except `_updated_at`. Same shape as
`LineWorkflowBase.escalation_resolved` (also no-op-plus-timestamp) but defined independently
here (WaveWorkflow does not inherit the base). A rebuild bumps `_updated_at` only.

### 4.6 `stakeholder_approved(self, signal: StakeholderApprovedSignal) -> None` — `wave.py:188-191`
Payload `StakeholderApprovedSignal` (`types.py:164-170`): `approval_id`, `stakeholder`,
`scope`.
```text
async def stakeholder_approved(self, signal):
    self._updated_at = _now_iso()       # wave.py:191   ← ONLY effect
```
⚠️ **GOTCHA-NOOP3:** no-op except `_updated_at`. Payload not stored. A rebuild bumps
`_updated_at` only.

### 4.7 `wave_patterns_ready(self, signal: WavePatternsReadySignal) -> None` — `wave.py:193-196`
Payload `WavePatternsReadySignal` (`types.py:182-187`): `wave_id`, `patterns: list[str]=[]`.
```text
async def wave_patterns_ready(self, signal):
    self._updated_at = _now_iso()       # wave.py:196   ← ONLY effect ("currently a no-op")
```
⚠️ **GOTCHA-NOOP4:** explicit no-op except `_updated_at`. A rebuild bumps `_updated_at` only.

> ⚠️ **GOTCHA-SIX-NOOPS (CHANGED: now SIX timestamp-only no-ops, was four):** `gate_approved`,
> `gate_rejected`, `override_approved`, `escalation_resolved`, `stakeholder_approved`,
> `wave_patterns_ready` (`wave.py:151-159` + `:178-196`) ALL do exactly
> `self._updated_at = _now_iso()` and store NO payload. They exist purely so the wave workflow
> accepts the wire signals without error and refreshes `_updated_at` (so the dashboard sees
> "activity"). Only `remove_app` (§4.3) does real work. A rebuild MUST register all six as live
> `@workflow.signal async def` handlers, each doing exactly the timestamp bump. Omitting any
> would cause a sender to hit "unhandled signal" semantics; adding logic (e.g. re-adding the old
> gate-signal buffer) would diverge from the live behavior.

---

## 5. QUERY HANDLERS (own — `@workflow.query`, synchronous read-only)

### 5.1 `get_status(self) -> WaveStatusResponse` — `wave.py:202-230` ★
Aggregates per-app counts from `_app_statuses` into a `WaveStatusResponse`.
```text
@workflow.query
def get_status(self) -> WaveStatusResponse:
    completed = sum(1 for s in self._app_statuses.values()
                    if s == WorkflowStatus.COMPLETED)          # wave.py:205-207  GEN-BRANCH A
    in_progress = sum(1 for s in self._app_statuses.values()
                      if s == WorkflowStatus.RUNNING)          # wave.py:208-210  GEN-BRANCH B
    blocked = sum(1 for s in self._app_statuses.values()
                  if s in (WorkflowStatus.WAITING_FOR_SIGNAL,  # wave.py:211-219  GEN-BRANCH C
                           WorkflowStatus.FAILED,
                           WorkflowStatus.CANCELLED))
    return WaveStatusResponse(                                 # wave.py:221-230
        wave_id          = self._wave_id,
        status           = self._status,
        total_apps       = len(self._app_statuses),            # wave.py:224  ← count of ALL apps
        apps_completed   = completed,
        apps_in_progress = in_progress,
        apps_blocked     = blocked,
        started_at       = self._started_at,
        updated_at       = self._updated_at,
    )
```
**Generator-conditional inventory (3 counting predicates):**
- **A.** `completed` = count of apps whose status `== COMPLETED` (`wave.py:206`).
- **B.** `in_progress` = count of apps whose status `== RUNNING` (`wave.py:209`).
- **C.** `blocked` = count of apps whose status `in (WAITING_FOR_SIGNAL, FAILED, CANCELLED)`
  (`wave.py:214-218`).

> ⚠️ **GOTCHA-COUNTS (PENDING is uncounted; the three buckets are NOT exhaustive):** an app in
> `WorkflowStatus.PENDING` (its seed value, `wave.py:79`) matches NONE of the three predicates
> — it is not completed, not in_progress, not blocked. So `apps_completed + apps_in_progress +
> apps_blocked` does NOT necessarily equal `total_apps`; the remainder is the count of
> still-PENDING apps (apps scheduled but not yet admitted past the semaphore). A rebuild MUST
> NOT "fix" this by adding PENDING to any bucket, and MUST compute `total_apps =
> len(self._app_statuses)` independently (not as the sum of buckets). ⚠️ Note WAITING_FOR_SIGNAL
> is counted as `blocked` even though NO wave-level code ever sets an app to
> WAITING_FOR_SIGNAL (the wave never gates) — it is defensive against a future wave-gate / a
> child status mirrored up. Keep it in the blocked set verbatim.
> ⚠️ **GOTCHA-QUERY-PURE (query is synchronous + read-only):** `get_status` is a
> `@workflow.query` (`wave.py:202`), declared `def` (NOT `async def`), and mutates NOTHING — it
> only reads `_app_statuses` / `_wave_id` / `_status` / `_started_at` / `_updated_at`. Temporal
> forbids mutation in query handlers. A rebuild MUST keep it pure and synchronous.
> ⚠️ **GOTCHA-RESP-FIELDS (`WaveStatusResponse` shape):** the response
> (`types.py:438-449`) is `wave_id, status, total_apps, apps_completed, apps_in_progress,
> apps_blocked, started_at, updated_at`. A rebuild must map exactly these eight fields.

### 5.2 `get_app_status(self, app_id: str) -> AppStatusResponse` — `wave.py:232-241`
Returns the status of one app within the wave.
```text
@workflow.query
def get_app_status(self, app_id: str) -> AppStatusResponse:
    status = self._app_statuses.get(app_id, WorkflowStatus.PENDING)   # wave.py:235  ← default PENDING
    return AppStatusResponse(                                          # wave.py:236-241
        app_id      = app_id,
        app_name    = app_id,                                          # wave.py:238  ← name = id (same as spawn)
        status      = status,
        workflow_id = f"app-{app_id}-wave-{self._wave_id}",            # wave.py:240  ← SAME id template
    )
```
> ⚠️ **GOTCHA-GAS1 (unknown app id → PENDING, not error):** `_app_statuses.get(app_id,
> WorkflowStatus.PENDING)` (`wave.py:235`) — querying an app id NOT in the wave returns a
> response with `status=PENDING` (and a synthesized `workflow_id`), it does NOT raise. A rebuild
> MUST use `.get(app_id, PENDING)`, not `[app_id]`.
> ⚠️ **GOTCHA-GAS2 (`app_name=app_id` + the canonical `workflow_id`):** like the spawn and
> `get_status`, this returns `app_name=app_id` (the UUID, `wave.py:238`) and
> `workflow_id=f"app-{app_id}-wave-{self._wave_id}"` (`wave.py:240`) — the SAME id template as
> the child spawn (GOTCHA-CHILD-ID) and `remove_app` (GOTCHA-RA2). The `AppStatusResponse`
> dataclass (`types.py:407-420`) has many optional fields (`disposition`, `risk_tier`,
> `complexity_tier`, `current_line`, `current_step`, `pending_gate`) that this query LEAVES AT
> THEIR DEFAULTS (`None` / `""` / `PENDING`). A rebuild must populate ONLY `app_id`, `app_name`,
> `status`, `workflow_id` and let the rest default.

---

## 6. ACTIVITY & CHILD-WORKFLOW CALLS — full inventory

WaveWorkflow makes **ZERO activity calls.** It makes exactly:

| Call | Where | Type | Args | Retry / timeout / queue | Sequential vs parallel |
|------|-------|------|------|--------------------------|------------------------|
| `workflow.execute_child_workflow("AppWorkflow", child_input, id=…, task_queue=…)` | `run_one_app`, `wave.py:102-107` | **child workflow** | `child_input: AppWorkflowInput`; `id=f"app-{app_id}-wave-{input.wave_id}"`; `task_queue=workflow.info().task_queue` | **No** retry_policy, **no** execution_timeout, **no** id_reuse_policy, **no** parent_close_policy specified — Temporal defaults (GOTCHA-CHILD-DEFAULTS). Inherits parent task queue. | **Parallel** — one per app, all scheduled via `ensure_future` then `gather`, bounded to `max_apps_per_wave` concurrent by the semaphore (GOTCHA-SEM/GOTCHA-GATHER). |
| `workflow.get_external_workflow_handle(f"app-{app_id}-wave-{self._wave_id}").cancel()` | `remove_app`, `wave.py:171-174` | **external handle cancel** | child workflow id string | wrapped in `try/except Exception: pass` (best-effort, GOTCHA-RA3) | N/A (fired from signal handler) |

- **No** `dispatch_agent_task`, **no** `write_artifacts_batch`, **no** `create_pr`, **no**
  `check_gate_criteria`, **no** `submit_gate_evidence`, **no** `reconcile_and_merge_pr`, **no**
  `persist_*` activities. (Those belong to the child `AppWorkflow` and the line workflows.)
- ⚠️ **GOTCHA-NO-RETRY-POLICIES:** because WaveWorkflow calls no `execute_activity`, the
  `RETRY_POLICIES` table (`transient`/`agent_failure`/`git_merge`/…) is **irrelevant** to this
  workflow — it does not even import it. A rebuild MUST NOT add activity calls or retry policies
  here.

---

## 7. GATE HANDLING

⚠️ **WaveWorkflow does NOT perform any gate, and (CHANGED) it does NOT buffer gate signals
either.** There is no evidence assembly, no `_submit_gate_evidence`, no
`_wait_for_gate_decision`, no approve/reject/merge-blocked/rework routing, no rework loop, and
no rework counters anywhere in this workflow. As of HEAD the two gate signals it accepts
(`gate_approved`, `gate_rejected`) are **inert timestamp-only no-ops** — they store NOTHING
(the old `_pending_gate_signals` buffer was removed; §1 GOTCHA-NO-PGS, §4.1/§4.2). Per **P5-S30.6
(2026-06-09)** gates are delivered point-to-point by the API to the gate-creating workflow
(looked up by `workflow_id` on the gate row); WaveWorkflow's children (AppWorkflow →
DiscoveryWorkflow, and the per-line workflows spawned by `WaveRationalizationWorkflow`) own and
await their own gates directly. The wave-level gate `G-WAVE-DC` is **intentionally not
implemented** and documented as such at `wave.py:125-132` and `wave.py:142-150` — it is NOT a
TODO.

For the gate-routing / rework-loop / merge-blocked semantics that the **child** workflows
implement, see `_LineWorkflowBase.md` — but DO NOT attribute any of it to WaveWorkflow. A
rebuild of WaveWorkflow MUST NOT implement gate routing and MUST NOT buffer gate signals.

---

## 8. RESILIENCE

- **Timeouts:** none configured. The only suspension is `await asyncio.gather` over child
  workflows, and the child spawn specifies no `execution_timeout` (GOTCHA-CHILD-DEFAULTS) — a
  child runs until it completes/fails/is-cancelled.
- **Heartbeats:** none (no activities).
- **continue-as-new:** none. The wave runs to gather-completion then returns `"completed"`
  (GOTCHA-NOWAIT). ⚠️ For very large waves this means the wave's history grows with the number
  of child-workflow events; the live code does NOT continue-as-new and a rebuild MUST NOT add
  it (would change history/replay).
- **Idempotency / determinism:**
  - Child workflow id is deterministic: `app-{app_id}-wave-{wave_id}` (GOTCHA-CHILD-ID) — so a
    replay re-derives the identical child ids.
  - `_now_iso()` = `workflow.now()` is deterministic under replay (GOTCHA-TIME).
  - The `asyncio.Semaphore` admission order follows Task-scheduling order, which follows
    `input.app_ids` order (GOTCHA-SEM) — deterministic provided `app_ids` ordering is stable.
  - No `workflow.patched(...)` gates exist in this workflow (it has no optional/versioned
    activity additions). A rebuild adds none.
- **Failure isolation / compensation:**
  - **Two-layer isolation:** the per-app `try/except Exception` in `run_one_app` (`wave.py:112`)
    converts a child failure into a `FAILED` status + `"failed"` return; the
    `asyncio.gather(..., return_exceptions=True)` (`wave.py:123`) ensures even an escaped
    exception does not abort the gather. Net: a single app failing leaves the others running and
    the wave still completes (GOTCHA-GATHER / GOTCHA-RETURN).
  - **No rollback / compensation** — there is no undo of spawned children on failure; failed
    apps simply carry `FAILED` status.
  - **Cancel surfaces:** (a) `remove_app` cancels ONE child best-effort and marks it
    `CANCELLED` (§4.3); (b) Temporal-level cancellation of the wave propagates (the bare
    `except Exception` does NOT swallow `CancelledError`/`BaseException`, GOTCHA-EXCEPT-BARE);
    (c) `cancel_workflow` (inherited HIL signal) sets `self.cancelled=True` but the wave logic
    ignores it (GOTCHA-HILUNUSED) — it is NOT an effective cancel for the fan-out.
  - **No `persist_wave_failure`** — that activity belongs to `WaveRationalizationWorkflow`,
    NOT to this `WaveWorkflow`. A rebuild of THIS workflow must not call it.

---

## 9. Behavioral parity checklist

A rebuilt `WaveWorkflow` MUST satisfy ALL of the following (verified against HEAD `7cb3b20c`):

1. **Inheritance:** `class WaveWorkflow(HILSignalsMixin)` decorated `@workflow.defn`; `__init__`
   calls `super().__init__()` as its **first** statement, then sets the **8** wave vars to:
   `_status=WorkflowStatus.PENDING`, `_app_statuses={}`, `_removed_apps=set()`,
   `_wave_gate_status=None`, `_started_at=""`, `_updated_at=""`, `_wave_id=""`,
   `_portfolio_id=""`. There is **NO `_pending_gate_signals`** (deleted). It does **NOT** inherit
   `LineWorkflowBase` and defines no `ARTIFACT_ROOT`/`STEPS`/`_gate_decisions`/`_rework_*`.
   (GOTCHA-INHERIT / GOTCHA-NO-PGS)
2. **`run()` phase A:** sets `_status=RUNNING`, `_started_at=_now_iso()`,
   `_updated_at=self._started_at` (REUSE, not a 2nd `now()`), `_wave_id=input.wave_id`,
   `_portfolio_id=input.portfolio_id`, then seeds `_app_statuses[app_id]=PENDING` for each
   `app_id in input.app_ids` (in order). (GOTCHA-STARTED-AT)
3. **Concurrency:** builds `semaphore = asyncio.Semaphore(input.max_apps_per_wave)`; every app's
   `run_one_app` body runs inside `async with semaphore`; at most `max_apps_per_wave` apps spawn
   children concurrently. (GOTCHA-SEM)
4. **Fan-out:** schedules ALL apps via `[asyncio.ensure_future(run_one_app(a)) for a in
   input.app_ids]` then `await asyncio.gather(*tasks, return_exceptions=True)`. The gather's
   return value is discarded. (GOTCHA-GATHER / GOTCHA-ENSURE-FUTURE / GOTCHA-RETURNVAL)
5. **`run()` terminal:** after gather, sets `_status=COMPLETED`, `_updated_at=_now_iso()`, and
   returns the literal string `"completed"` — UNCONDITIONALLY, even if every child failed. No
   failure return / raise from `run()`. The block between gather and COMPLETED is a documentation
   comment only (P5-S30.6), no control flow. (GOTCHA-RETURN)
6. **No wait/cas/sleep/gate in `run()`:** no `workflow.wait_condition`, no `continue_as_new`, no
   `workflow.sleep`, no gate logic; `self.cancelled` does not affect `run()`. (GOTCHA-NOWAIT /
   GOTCHA-HILUNUSED)
7. **`run_one_app` branch 1 (removed short-circuit):** inside the semaphore, `if app_id in
   self._removed_apps: return "removed"` BEFORE marking RUNNING / spawning the child.
8. **`run_one_app` happy path:** sets `_app_statuses[app_id]=RUNNING`, `_updated_at=_now_iso()`;
   builds `AppWorkflowInput(app_id=app_id, app_name=app_id, wave_id=input.wave_id,
   portfolio_id=input.portfolio_id, artifact_repo=input.artifact_repo)`; awaits
   `workflow.execute_child_workflow("AppWorkflow", child_input,
   id=f"app-{app_id}-wave-{input.wave_id}", task_queue=workflow.info().task_queue)` with NO
   retry/timeout/reuse-policy; on success sets `_app_statuses[app_id]=COMPLETED`,
   `_updated_at=_now_iso()`, returns `"completed"`. (GOTCHA-CHILD-ID / GOTCHA-CHILD-NAME /
   GOTCHA-TASKQUEUE / GOTCHA-CHILD-DEFAULTS)
9. **`run_one_app` except (failure isolation):** `except Exception:` (NOT `BaseException`); `if
   app_id not in self._removed_apps: self._app_statuses[app_id]=FAILED`; always
   `_updated_at=_now_iso()`; returns `"failed"`. The `not in _removed_apps` guard preserves a
   concurrently-set `CANCELLED` status. (GOTCHA-EXCEPT-BARE / GOTCHA-REMOVE-RACE)
10. **Own signals = 7, all `@workflow.signal async def`:** `gate_approved`, `gate_rejected`,
    `remove_app`, `override_approved`, `escalation_resolved`, `stakeholder_approved`,
    `wave_patterns_ready`. (GOTCHA-ASYNCSIG / GOTCHA-NODUP)
11. **`gate_approved` (CHANGED → inert):** does ONLY `self._updated_at = _now_iso()`; stores
    NOTHING; does NOT buffer/forward/consume. (GOTCHA-GA1/GA2)
12. **`gate_rejected` (CHANGED → inert):** does ONLY `self._updated_at = _now_iso()`; stores
    NOTHING; does NOT buffer/forward/consume. (GOTCHA-GR1)
13. **`remove_app`:** `_removed_apps.add(app_id)` → `_app_statuses[app_id]=CANCELLED` →
    `_updated_at=_now_iso()` → `try: await
    workflow.get_external_workflow_handle(f"app-{app_id}-wave-{self._wave_id}").cancel() except
    Exception: pass`. State writes BEFORE the await; broad except swallows missing/finished
    child. (GOTCHA-RA1/RA2/RA3/RA4)
14. **Six timestamp-only no-op signals (CHANGED, was four):** `gate_approved`, `gate_rejected`,
    `override_approved`, `escalation_resolved`, `stakeholder_approved`, `wave_patterns_ready`
    each do ONLY `self._updated_at = _now_iso()` and store no payload. (GOTCHA-SIX-NOOPS)
15. **NO gate-signal buffer; `_wave_gate_status` is never written.** There is no
    `_pending_gate_signals` field at all. (GOTCHA-NO-PGS / GOTCHA-WGS)
16. **Queries = 2, synchronous read-only `@workflow.query`:** `get_status`, `get_app_status`.
17. **`get_status`:** `completed=sum(1 for s if s==COMPLETED)`,
    `in_progress=sum(1 for s if s==RUNNING)`, `blocked=sum(1 for s if s in
    (WAITING_FOR_SIGNAL, FAILED, CANCELLED))`; returns `WaveStatusResponse(wave_id=self._wave_id,
    status=self._status, total_apps=len(self._app_statuses), apps_completed=completed,
    apps_in_progress=in_progress, apps_blocked=blocked, started_at=self._started_at,
    updated_at=self._updated_at)`. PENDING is uncounted; `total_apps` is `len(...)` not a bucket
    sum. (GOTCHA-COUNTS / GOTCHA-QUERY-PURE / GOTCHA-RESP-FIELDS)
18. **`get_app_status(app_id)`:** `status=self._app_statuses.get(app_id, PENDING)`; returns
    `AppStatusResponse(app_id=app_id, app_name=app_id, status=status,
    workflow_id=f"app-{app_id}-wave-{self._wave_id}")` with all other fields defaulted. Unknown
    app id → PENDING, no raise. (GOTCHA-GAS1/GAS2)
19. **Zero activity calls; one child-workflow spawn per app; one best-effort external cancel.**
    No `RETRY_POLICIES`, no `workflow.patched(...)`, no `persist_wave_failure`, no
    `continue_as_new`. (GOTCHA-NO-RETRY-POLICIES / GOTCHA-CHILD-DEFAULTS)
20. **`_now_iso()` is a module-level function returning `workflow.now().isoformat()`** — used
    for every timestamp; never `datetime.now()`. (GOTCHA-TIME)
21. **Imports of `olympus_workflows.types` are inside `with
    workflow.unsafe.imports_passed_through():`.** (GOTCHA-IMPORTS)
22. **The string `"completed"` is the sole `run()` return; the per-app return strings
    (`"removed"`/`"completed"`/`"failed"`) are produced but discarded by the gather.**
    (GOTCHA-RETURN / GOTCHA-RETURNVAL)
