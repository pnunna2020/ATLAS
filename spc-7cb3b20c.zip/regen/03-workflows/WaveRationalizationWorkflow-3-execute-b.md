# `WaveRationalizationWorkflow._execute()` — SECOND HALF + `_handoff_to_architecture_coordinator` (ATOMIC regen spec)

> **Source of truth:** `temporal/olympus_workflows/workflows/wave_rationalization.py` (6129 lines,
> HEAD 7cb3b20c). Every `wr.py:line` citation is against that file. **This file OWNS lines
> 2386–3351 ONLY.** Earlier ranges (state init, `run()`, sequence-1/2 dispatches, the G-RR
> open/wait, the cross-app rework re-dispatch + re-commit) are covered by sibling specs:
>
> ⚠️ **REFRESH NOTE (HEAD 7cb3b20c vs old 5969-line baseline):** the file grew to 6129 lines and
> everything in this spec's scope shifted **down ~95-101 lines**. The behavioral logic in MY scope
> (PRA rework tail, per-app/classify/score fan-outs, wave-plan, factory-routing, G-DA loop, wave
> synthesis, arch terminal routing, `_handoff`) is **unchanged** EXCEPT: (1) the PRA rework block
> now starts at `wr.py:2386` (was 2250 — the cross-app rework re-commit at `:2342-2384` is now in
> sibling `-2-execute-a`); (2) `_build_factory_routing` (sibling `-5`) gained a **`Build`**
> disposition → new `build` route bucket; (3) `_run_gate_pre_review` (sibling `-5`) gained an
> `optional_evidence_paths` kwarg — the **G-DA caller here passes none** (it has no optional
> companion), so the G-DA pre-review call shape is unchanged. All path:line citations below are
> refreshed to HEAD. **Old→new offset for this scope: + ~101 lines.**
> `WaveRationalizationWorkflow-1-*.md` / `-2-*.md` (state, `run()`, `_execute` head). Helper
> bodies (`_open_gate_pr`, `_wait_for_gate`, `_commit_artifact`, `_commit_output_files`,
> `_primary_output_content`, `_validate_artifact_or_warn`, `_set_step`, `_execution_ctx`,
> `_run_gate_pre_review`, `_reconcile_and_merge_with_retry_loop`,
> `_merge_capability_lineage_row_rework`, `_project_per_app_side_effects`, `_register_gate_key`,
> `_build_*`, and all `@workflow.signal` / `@workflow.query` handlers) live in
> `WaveRationalizationWorkflow-helpers-*.md` / `-signals-*.md`. I REFERENCE them here with
> enough contract to verify call-shape parity, but their internal pseudocode is NOT reproduced
> here except where the inline call demands it.
>
> **What this file covers (the `_execute` tail, in run order):**
> 1. **Tail of the G-RR rework loop** — `wr.py:2386–2579`: the **PRA rework re-dispatch**
>    (patch-guarded, rat-cap-aware), companion commits, and the rat-cap re-persist. (The *head* of
>    this loop — the `while`, the `_wait_for_gate("G-RR")` branch, the scope/skip computation, the
>    cross-app re-dispatch AND its re-commit at `:2342-2384` — is in the sibling `-execute-a` spec;
>    this spec picks up at the PRA rework decision at `wr.py:2386`.)
> 2. **Per-app fan-out** — `wr.py:2581–2596` (`_per_app_pipeline` gather).
> 3. **Classification fan-out** — `wr.py:2598–2619` (`_classify_app` gather, Tier-1 pause lives
>    inside `_classify_app`).
> 4. **Portfolio scoring fan-out** — `wr.py:2621–2644` (`_score_app` gather).
> 5. **Scoring methodology digest commit** — `wr.py:2646–2658`.
> 6. **Wave planning dispatch + commit** — `wr.py:2660–2730`.
> 7. **Factory-routing commit** — `wr.py:2732–2748`.
> 8. **Gate G-DA loop** (dual-signal + merge-retry + rework) — `wr.py:2750–3076`. ★ CORE.
> 9. **Wave Outcome Synthesis** — `wr.py:3078–3221`.
> 10. **Architecture coordinator / dispatch terminal routing** — `wr.py:3223–3271`.
> 11. **`_handoff_to_architecture_coordinator(...)`** — `wr.py:3273–3351`.
>
> **Inheritance:** `class WaveRationalizationWorkflow(HILSignalsMixin)` (`wr.py:1078`). It
> **does NOT** inherit `LineWorkflowBase`. So unlike the per-app lines it **re-implements**
> (does not inherit) `_set_step`, `_execution_ctx`, `_run_gate_pre_review`,
> `_reconcile_and_merge_with_retry_loop`, `gate_approved`, `gate_rejected`, `merge_retry`,
> `get_status`, and the gate-wait (here `_wait_for_gate`, NOT `_wait_for_gate_decision`). It
> INHERITS the six HIL signals from `HILSignalsMixin` (`_HILSignalsMixin.md`) — notably
> `cancel_workflow` (sets `self.cancelled`) which is the universal kill switch consumed by every
> `wait_condition` in this scope. The base-spec gate handlers (`_LineWorkflowBase.md` §3) are
> the *pattern* the inlined handlers mirror, but the wave handlers differ: **per-gate keyed
> queues + a pre-record signal buffer** (see §A.0 below). The base's `_wait_for_gate_decision`
> uses a single flat list + scalar cursor; the wave's `_wait_for_gate` uses `dict[gate_key →
> list]` + `dict[gate_key → cursor]`.
>
> **Determinism note:** all timestamps via `_now_iso()` = `workflow.now().isoformat()`
> (`wr.py:134-135`). No wall clock, no random. All parallelism is `asyncio.gather` over
> `workflow.execute_activity(...)` coroutines (Temporal schedules on await — gather is what
> makes them concurrent; see GOTCHA-PAR). Every optional code path is gated by a verbatim
> `workflow.patched(...)` string — these are load-bearing for replay (GOTCHA-PATCH).

---

## A. STATE consumed/mutated in THIS scope

This scope reads and mutates instance vars initialized in `__init__` (`wr.py:1087-1236`). The
full state table is in the `-1-state` sibling spec; here is **only what lines 2386–3351
touch**, with the exact mutation site.

| Var | Type | Read in scope | Mutated in scope → value | Site |
|-----|------|---------------|--------------------------|------|
| `_rework_iterations_grr` | `int` | rework-commit messages + activity_ids (`wr.py:2366,2446,2517,2570`) | — (incremented in `-execute-a` head, before 2386) | — |
| `_rework_feedback` | `dict[str,dict]` | `.get("G-RR")` (`wr.py:2347,2469`) | set/popped by `_wait_for_gate`; `_merge_capability_lineage_row_rework` merges `["G-DA"]` | 3054 |
| `_rework_iterations_gda` | `int` | gate-PR body, activity_ids | `+= 1` on G-DA reject (`wr.py:3037`); compared to `MAX_REWORK_ITERATIONS` | 3037-3038 |
| `_stakeholder_approved` | `bool` | dual-signal `wait_condition` (`wr.py:3011`) | `False` after consume (`3016`); `False` on reject (`3036`) | 3016,3036 |
| `cancelled` (inherited) | `bool` | every gate / dual-signal / merge wait | — (set ONLY by inherited `cancel_workflow`) | — |
| `_status` | `WorkflowStatus` | — | `CANCELLED` (3013), `FAILED` (3039), `COMPLETED` (3242,3257,3267) | several |
| `_current_step` | `str` | — | `"max-rework-exceeded-gda"` (3040), `terminal` (3244), `"architecture-dispatched"`/terminal (3261-3263), `"completed"` (3269) | several |
| `_progress_pct` | `float` | — | `100.0` at terminal (3243,3260,3268) | several |
| `_updated_at` | `str` | — | `_now_iso()` at terminal (3245,3264,3270) | several |
| `_validation_warnings` | `dict[str,list[str]]` | `dict(self._validation_warnings)` into G-DA evidence (`wr.py:2968`) | populated by `_validate_artifact_or_warn` calls (2510,2529,3202) | 2968 |
| `_tier1_approval_records` | `dict[str,dict]` | sorted into G-DA evidence (`2976-2978`) + pre-review (`5629-5631`) | populated by `stakeholder_approved` signal (not in scope) | — |
| `_tier1_approved_apps` | `set[str]` | passed to `_project_per_app_side_effects` (via `self`, read at 3973) | populated by `stakeholder_approved` signal | — |
| `_pending_gate` | `GateType\|None` | — | set/reset inside `_wait_for_gate` (helper) | — |
| `_gate_decisions` / `_gate_decisions_consumed` | `dict` | consumed by `_wait_for_gate` | — | — |
| `_merge_retry_signalled` | `bool` | merge loop `wait_condition` | reset/await inside `_reconcile_and_merge_with_retry_loop` (helper) | — |

> ⚠️ **GOTCHA-STATE-TWO-COUNTERS:** this workflow keeps **two separate scalar rework
> counters** — `_rework_iterations_grr` and `_rework_iterations_gda` (`wr.py:1153-1154`) — NOT
> the base's `_rework_iterations: dict[gate→int]`. The G-DA loop in this scope bumps
> `_rework_iterations_gda` directly with `+= 1` (`wr.py:3037`), then compares to the
> **module-level** `MAX_REWORK_ITERATIONS = 3` (`wr.py:759`). A rebuild MUST use a dedicated
> integer per gate, increment with `+= 1` (not `_bump_rework`), and compare `>` (strictly
> greater) against 3 — see GOTCHA-GDA-MAXREWORK.

### A.0 Signal-handler contract this scope DEPENDS ON (reproduced for the wait predicates)

These handlers are defined later in the file but their behavior is what the `wait_condition`s
in this scope consume. Reproduced verbatim-equivalent so a rebuild wires the predicates right.

- **`stakeholder_approved(signal: StakeholderApprovedSignal)`** (`wr.py:5915-5947`): if
  `signal.scope == "tier-1-classification"` → parse `app_id` from `approval_id` prefix
  `"tier1-"` and add to `_tier1_approved_apps` + record into `_tier1_approval_records[app_id]`;
  **else** (`"g-da"` or anything non-tier-1) → `self._stakeholder_approved = True` and
  `self._stakeholder_info = f"{signal.stakeholder} approved scope: {signal.scope}"`. Always
  bumps `_updated_at`. **This is the signal the G-DA dual-signal wait at `wr.py:3011`
  consumes.** ⚠️ The G-DA dual-signal predicate keys off `_stakeholder_approved`, which is set
  ONLY by the `else` branch — a `scope="tier-1-classification"` signal does NOT satisfy the
  G-DA wait.
- **`gate_approved` / `gate_rejected`** (`wr.py:5792-5844`): buffer a **5-tuple** `(status,
  actor, reason/justification, reason_category, card_decisions)` into
  `_gate_decisions[gate_key]` IF `_gate_id_to_key[signal.gate_id]` is known, ELSE into
  `_pending_signals_by_gate_id[gate_id]` for later flush by `_register_gate_key`. `gate_approved`
  hard-codes `reason_category=None, card_decisions=[]` even if the signal carried them (mirrors
  base GOTCHA-SIG1). `gate_rejected` reads both defensively via `getattr(..., default)`.
- **`merge_retry(signal)`** (`wr.py:5768-5772`): `self._merge_retry_signalled = True`;
  `_updated_at = _now_iso()`. Unconditional set (idempotent). Consumed by the merge loop.
- **`cancel_workflow()`** (inherited from `HILSignalsMixin`, `signals.py:75-78`): `self.cancelled
  = True`. One-way latch; never reset. Drains every wait in this scope.

> ⚠️ **GOTCHA-SIG-NO-REDEFINE:** `gate_approved`, `gate_rejected`, `merge_retry`, `get_status`
> are **re-declared on THIS class** (not inherited from `LineWorkflowBase`, which the class does
> not extend). They are still each decorated exactly once. A rebuild that *did* inherit
> `LineWorkflowBase` would crash on duplicate registration — but this class deliberately does
> not, so it owns its own copies. Do not double-register.

---

## B. CONTROL FLOW — `_execute()` lines 2386–3351 (structured pseudocode)

> Convention: `await act(F, IN, sc=…, rp=…, aid=…)` ≡
> `workflow.execute_activity(F, IN, start_to_close_timeout=timedelta(seconds=…),
> retry_policy=RETRY_POLICIES[…], activity_id=…)`. `rp="agent_failure"` = 3 attempts, 5→60s
> backoff. `rp="transient"` = 3 attempts, 1→15s (= foundry `HTTP_RETRY_POLICY`). `rp="git_merge"`
> = 3 attempts, 5→30s, `non_retryable=[MergeConflict, MergeDivergenceUnresolved,
> MergeBranchProtectionRejected]` (`retry_policies.py:94-104`).

### B.1 — Tail of the G-RR rework loop body: PRA rework re-dispatch (`wr.py:2386–2579`)

> **Entry context (from `-execute-a`, recap only — DO NOT re-spec):** we are *inside* the
> `while True` G-RR rework loop, on the **rejected** branch, after `_rework_iterations_grr` was
> bumped, the cross-app-redundancy rework dispatch ran, AND its result was re-committed (matrix +
> companions, `wr.py:2331-2384`, **all now owned by sibling `-execute-a`**). The local vars in
> scope at line 2386 include: `repo`, `branch`, `workspace_key`, `matrix_path`,
> `portfolio_redundancy_path`, `cross_skill`, `pra_skill`, the `cross_result` awaited value, and
> the rework-scoping booleans `scope_to_targets`, `rework_targets`, `skip_cross_app`,
> `do_portfolio_synthesis`, `do_rat_cap_clustering`. **This spec picks up at the PRA rework
> decision (`wr.py:2386`).**
>
> ⚠️ **REFRESH NOTE:** the cross-app rework re-commit block (old `wr.py:2250-2294`) moved into the
> sibling `-execute-a` spec because the file-boundary shifted to `:2384`. The
> **GOTCHA-RWK-FEEDBACK-INJECTED** note (cross-app rework injects
> `self._rework_feedback.get("G-RR")` into context at `wr.py:2347`) now lives there too. This
> spec starts clean at the PRA rework decision.

The **PRA rework re-dispatch** decision (`wr.py:2386` onward):

```text
    # -- Re-run analyze-portfolio-redundancy (PRA) on the fresh pair matrix.  wr.py:2386-2400 (comment)
    skip_pra = (                                                    # wr.py:2401-2405
        scope_to_targets
        and "analyze-portfolio-redundancy" not in rework_targets
        and skip_cross_app
    )
    if (                                                            # wr.py:2406-2412  ★BRANCH B1
        do_portfolio_synthesis
        and workflow.patched("wave-rationalization-grr-rework-pra-v1")
        and not skip_pra
    ):
        await self._set_step("analyze-portfolio-redundancy",
                             STEP_WEIGHTS["cross-app-redundancy"])  # wr.py:2413-2416

        # -- Rat-cap roster reload (best-effort) --                wr.py:2417-2424 (comment)
        rework_rat_cap_context = {                                  # wr.py:2425-2429
            "prior_rat_caps": [], "wave_capability_grain": [], "wave_capability_count": 0}
        if do_rat_cap_clustering:                                   # wr.py:2430  ★BRANCH B2
            try:
                _rework_grain = await act(                          # wr.py:2432-2448
                    load_wave_rationalization_capabilities,
                    LoadWaveRationalizationCapabilitiesInput(
                        portfolio_id=input.portfolio_id, wave_id=input.wave_id,
                        execution_context=self._execution_ctx("analyze-portfolio-redundancy")),
                    sc=30s, rp="transient",
                    aid=f"load-rat-cap-grain-rework-{input.wave_id}-{self._rework_iterations_grr}")
                rework_rat_cap_context["prior_rat_caps"]      = _rework_grain.prior_rat_caps      # 2449
                rework_rat_cap_context["wave_capability_grain"] = _rework_grain.wave_capabilities  # 2452
                rework_rat_cap_context["wave_capability_count"] = len(_rework_grain.wave_capabilities)  # 2455
            except Exception:                                       # wr.py:2458  ★BRANCH B3 (best-effort)
                workflow.logger.exception("load_wave_rationalization_capabilities failed on G-RR rework; "
                    "PRA re-dispatch will run without prior-rat-cap reuse context")

        _rework_pra_context = {                                     # wr.py:2466-2470
            "wave_id": input.wave_id, "app_ids": input.app_ids,
            "rework_feedback": self._rework_feedback.get("G-RR")}
        if do_rat_cap_clustering:                                   # wr.py:2471  ★BRANCH B4
            _rework_pra_context.update(rework_rat_cap_context)      # wr.py:2472

        pra_rework_result = await act(                              # wr.py:2473-2504
            dispatch_agent_task,
            AgentTaskInput(
                task_type="wave-analyze-portfolio-redundancy",
                skill_id=pra_skill["skill_id"], app_id="", wave_id=input.wave_id,
                workspace_key=workspace_key, artifact_repo=repo, artifact_ref=branch,
                context = await _with_context_priors(               # wr.py:2483-2490
                    _with_fixture_scenario(_rework_pra_context, pra_skill["skill_id"],
                                           input.fixture_scenarios),
                    pra_skill["skill_id"]),
                input_artifacts = _portfolio_redundancy_input_artifacts(input.wave_id, input.app_ids),  # 2491
                timeout_seconds = 3600,
                execution_context = self._execution_ctx("analyze-portfolio-redundancy",
                    input_artifact_paths=_portfolio_redundancy_input_artifacts(input.wave_id, input.app_ids))),
            sc=3600s (=1h), rp="agent_failure")                     # wr.py:2502-2503

        pra_rework_raw = self._primary_output_content(pra_rework_result, pra_skill["artifact"])   # 2507
        await self._validate_artifact_or_warn(                      # wr.py:2510-2514
            artifact_filename="portfolio-redundancy-matrix.json",
            raw_content=pra_rework_raw, wave_id=input.wave_id)
        pra_rework_msg = f"Wave {input.wave_id}: portfolio redundancy matrix (rework {self._rework_iterations_grr})"  # 2515
        await self._commit_artifact(repo, branch, portfolio_redundancy_path, pra_rework_raw, pra_rework_msg)  # 2519

        for f in getattr(pra_rework_result, "output_files", []) or []:   # wr.py:2526  ★LOOP B5
            fname = getattr(f, "path", "") or ""                    # wr.py:2527
            if fname.endswith("shared-identity-report.json"):       # wr.py:2528  ★BRANCH B6
                await self._validate_artifact_or_warn(              # wr.py:2529-2533
                    artifact_filename="shared-identity-report.json",
                    raw_content=getattr(f, "content", "") or "", wave_id=input.wave_id)
                break                                               # wr.py:2534  ← validate first match only
        await self._commit_output_files(                           # wr.py:2535-2542
            repo, branch, pra_rework_result,
            primary_path=portfolio_redundancy_path, wave_id=input.wave_id,
            commit_message_prefix=pra_rework_msg + " companion")

        # -- Rat-cap re-persist (best-effort) --                   wr.py:2544-2549 (comment)
        if do_rat_cap_clustering and pra_rework_raw:                # wr.py:2550  ★BRANCH B7
            try:
                await act(persist_rationalization_capabilities,     # wr.py:2552-2572
                    PersistRationalizationCapabilitiesInput(
                        portfolio_id=input.portfolio_id, wave_id=input.wave_id,
                        clustering_plan_json=pra_rework_raw,
                        clustering_plan_artifact_ref=portfolio_redundancy_path,
                        execution_context=self._execution_ctx("analyze-portfolio-redundancy")),
                    sc=60s, rp="transient",
                    aid=f"persist-rat-caps-rework-{input.wave_id}-{self._rework_iterations_grr}")
            except Exception:                                       # wr.py:2573  ★BRANCH B8 (best-effort)
                workflow.logger.exception("persist_rationalization_capabilities failed on G-RR rework; "
                    "rat-cap rows reflect prior run's plan, not the rework")
    # (end if B1) — loops back to top of `while True` G-RR loop (head in -execute-a)
```

> ⚠️ **NOTE (NO empty-plan guard on the rework path):** unlike the *primary* PRA dispatch (sibling
> `-execute-a`, `wr.py:1906-1919`), the PRA **rework** re-dispatch does NOT apply the
> `_primary_output_is_empty` / `wave-rationalization-pra-nonempty-v1` hard-fail — an empty rework
> plan is validated-and-committed (advisory) like before, not raised. A rebuild must NOT add the
> nonempty guard to the rework path.
> ⚠️ **GOTCHA-SKIP-PRA (the 3-AND skip predicate):** `skip_pra` (`wr.py:2401-2405`) is `True`
> ONLY when ALL three hold: the reject was card-scoped (`scope_to_targets`) AND PRA was NOT one
> of the rework targets (`"analyze-portfolio-redundancy" not in rework_targets`) AND cross-app
> was also skipped (`skip_cross_app`). In that case the prior PRA artifact stays valid and PRA
> is NOT re-run. The PRA-rerun branch B1 then requires `do_portfolio_synthesis` AND the verbatim
> patch `"wave-rationalization-grr-rework-pra-v1"` AND `not skip_pra`. A rebuild MUST keep this
> exact 3-term skip plus the patch gate — the comment (`wr.py:2396-2400`) notes PRA must rerun
> whenever EITHER cross-app reran (its output is PRA's input) OR PRA itself was rejected.
> ⚠️ **GOTCHA-PRA-CONTEXT-PRIORS:** the PRA rework dispatch wraps its context in BOTH
> `_with_fixture_scenario(...)` AND `await _with_context_priors(...)` (`wr.py:2483-2490`) — note
> `_with_context_priors` is **`await`ed** (it runs a `load_context_priors` activity, 10s,
> transient, best-effort). The cross-app rework dispatch (sibling `-execute-a`, `wr.py:2342`) uses
> **only** `_with_fixture_scenario`, NOT context-priors. A rebuild must not add priors to the
> cross-app rework, nor drop them from PRA.
> ⚠️ **GOTCHA-RATCAP-ACTIVITY-IDS:** the rat-cap reload and re-persist use deterministic
> `activity_id`s that embed BOTH `wave_id` AND `_rework_iterations_grr`
> (`wr.py:2443-2447,2567-2571`). This makes each rework iteration's activity idempotent on replay
> AND distinct across iterations. A rebuild MUST embed the iteration counter — omitting it would
> collide activity ids across rework rounds and cause replay nondeterminism.
> ⚠️ **GOTCHA-SHARED-IDENTITY-BREAK:** the companion-validate loop (`wr.py:2526-2534`) validates
> ONLY the **first** `output_files` entry whose path ends in `shared-identity-report.json`, then
> `break`s. It does NOT validate other companions. A rebuild must keep the `break`.

### B.2 — Per-app fan-out (`wr.py:2581–2596`)

```text
    # -- Per-app fanout: disposition → governance → user-impact --   wr.py:2581-2583 (comment)
    await self._set_step("disposition-recommendation",
                         progress_after_redundancy + STEP_WEIGHTS["gate-review-rr"])   # wr.py:2584-2587
    per_app_pipelines = [                                           # wr.py:2588-2591
        self._per_app_pipeline(app_id, input, repo, branch, workspace_key)
        for app_id in input.app_ids]
    per_app_pipeline_results = await asyncio.gather(*per_app_pipelines)   # wr.py:2592
    per_app_results = {                                             # wr.py:2593-2596
        app_id: result
        for app_id, result in zip(input.app_ids, per_app_pipeline_results)}
```

- `progress_after_redundancy` is a local computed in `-execute-a` (the post-G-RR-merge progress
  base). Treat as opaque float here.
- `_per_app_pipeline(app_id, input, repo, branch, workspace_key)` (default `rework=False`,
  `wr.py:3357`) returns a dict per app with keys this scope later reads: `disposition`,
  `disposition_path`, `disposition_json`, `disposition_narrative`, `governance_json`,
  `governance_narrative`, `user_impact_json`, `user_impact_narrative`, `app_name`/`name`.
  It runs disposition-recommender → governance → (Retire/Replace-only)
  user-impact per app. **Reproduced in the `-perapp` sibling spec.**

> ⚠️ **GOTCHA-PAR (gather is mandatory for fan-out):** `asyncio.gather(*coros)` runs all per-app
> pipelines concurrently. `[await c for c in coros]` would serialize (each
> `workflow.execute_activity` coroutine only schedules its activity when awaited). The comment
> at `wr.py:3057-3062` and `wr.py:1467-1473` is explicit. A rebuild MUST use `gather`. This
> applies identically to the classify (B.3), score (B.4), rework (B.8e), and side-effects
> (`_project_*`) fan-outs.

### B.3 — Classification fan-out (`wr.py:2598–2619`)

```text
    await self._set_step("classification",                         # wr.py:2603-2610
        progress_after_redundancy
        + STEP_WEIGHTS["gate-review-rr"] + STEP_WEIGHTS["disposition-recommendation"]
        + STEP_WEIGHTS["disposition-governance"] + STEP_WEIGHTS["user-impact-analysis"])
    classify_tasks = [self._classify_app(app_id, input, repo, branch, workspace_key)
                      for app_id in input.app_ids]                  # wr.py:2611-2614
    classify_results = await asyncio.gather(*classify_tasks)        # wr.py:2615
    classification_results = {app_id: result                       # wr.py:2616-2619
        for app_id, result in zip(input.app_ids, classify_results)}
```

- `_classify_app` returns `{"app_id", "cls_json", "cls_path", "cls_narrative", …}`
  (`wr.py:3711-…`). **The Tier-1 stakeholder pause lives INSIDE `_classify_app`** (it waits on
  `_tier1_approved_apps` membership for tier-1-flagged apps) — NOT in `_execute`. Reproduced in
  the `-perapp` sibling spec. This scope only consumes the returned `cls_json` / `cls_narrative`.

### B.4 — Portfolio scoring fan-out + methodology commit (`wr.py:2621–2658`)

```text
    await self._set_step("portfolio-scoring",                      # wr.py:2627-2635
        progress_after_redundancy
        + STEP_WEIGHTS["gate-review-rr"] + STEP_WEIGHTS["disposition-recommendation"]
        + STEP_WEIGHTS["disposition-governance"] + STEP_WEIGHTS["user-impact-analysis"]
        + STEP_WEIGHTS["classification"])
    score_tasks = [self._score_app(app_id, input, repo, branch, workspace_key)
                   for app_id in input.app_ids]                     # wr.py:2636-2639
    score_results = await asyncio.gather(*score_tasks)             # wr.py:2640
    portfolio_scores = {app_id: result                            # wr.py:2641-2644
        for app_id, result in zip(input.app_ids, score_results)}

    methodology_path = f"rationalization/wave-{input.wave_id}/scoring-methodology.md"   # wr.py:2651
    await self._commit_artifact(repo, branch, methodology_path,    # wr.py:2652-2658
        self._build_scoring_methodology(input, portfolio_scores),
        f"Wave {input.wave_id}: scoring methodology digest")
```

- `_score_app` returns `{"app_id", "score_json", "artifact_path", "overall_weighted",
  "dimensions", "score_narrative", …}` (`wr.py:3820-…`). Runs `portfolio-scorer` per app AFTER
  classification (so the skill can cite `risk_tier`).
- `_build_scoring_methodology` (`wr.py:5280-5330`) is a **pure** markdown builder (no activity).
  `_commit_artifact` defaults `step_id="commit-redundancy-artifacts"` (helper `wr.py:5065`).

### B.5 — Wave planning dispatch + commit (`wr.py:2660–2730`)

```text
    await self._set_step("wave-planning",                          # wr.py:2661-2670
        progress_after_redundancy
        + STEP_WEIGHTS["gate-review-rr"] + ... + STEP_WEIGHTS["classification"]
        + STEP_WEIGHTS["portfolio-scoring"])
    wave_plan_skill = SKILLS["wave-plan"]                          # wr.py:2671  → {skill_id:"sequencer", artifact:"wave-plan.json"}
    wave_plan_result = await act(dispatch_agent_task,              # wr.py:2672-2703
        AgentTaskInput(
            task_type="wave-plan", skill_id=wave_plan_skill["skill_id"],
            app_id="", wave_id=input.wave_id, workspace_key=workspace_key,
            artifact_repo=repo, artifact_ref=branch,
            context=_with_fixture_scenario(
                {
                    "wave_id": input.wave_id, "app_ids": input.app_ids,
                    "per_app_dispositions": {                       # wr.py:2686-2689
                        app_id: per_app_results.get(app_id, {}).get("disposition", "")
                        for app_id in input.app_ids},
                    "per_app_readiness": {                          # wr.py:2690-2693
                        app_id: portfolio_scores.get(app_id, {}).get("overall_weighted")
                        for app_id in input.app_ids},
                },
                wave_plan_skill["skill_id"], input.fixture_scenarios),
            timeout_seconds=3600,
            execution_context=self._execution_ctx("wave-planning")),
        sc=3600s (=1h), rp="agent_failure")                        # wr.py:2701-2702
    wave_plan_path = f"rationalization/wave-{input.wave_id}/{wave_plan_skill['artifact']}"   # wr.py:2711-2713  ⚠️CHANGED
    await self._commit_artifact(repo, branch, wave_plan_path,      # wr.py:2714-2722
        self._primary_output_content(wave_plan_result, wave_plan_skill["artifact"]),
        f"Wave {input.wave_id}: wave plan (critical path + sequencing)")
    await self._commit_output_files(repo, branch, wave_plan_result,   # wr.py:2723-2730
        primary_path=wave_plan_path, wave_id=input.wave_id,
        commit_message_prefix=f"Wave {input.wave_id}: wave plan companion")
```

> ⚠️ **GOTCHA-WAVEPLAN-PATH (⚠️ CHANGED since baseline — now under `rationalization/`):** the old
> baseline put `wave_plan_path` (and `factory-routing.json`) under `planning/{wave_id}/…`. **HEAD
> moves both to `rationalization/wave-{wave_id}/…`** (`wr.py:2711-2713`, `:2739-2741`). The source
> comment (`wr.py:2704-2710`, P5-S30.7/#270) records why: the wave-artifact read-through endpoint
> (`waves.py get_wave_artifact`) and `governance.py` both expect the `rationalization/wave-{id}/`
> prefix; the old `planning/{id}/` prefix left `wave-plan.json` and `factory-routing.json`
> unreadable on the artifact-repo main. A rebuild MUST commit BOTH under
> `rationalization/wave-{wave_id}/…` now (NOT `planning/…`). `_commit_output_files` normalizes
> bare-filename companions to `rationalization/wave-{wave_id}/…` (helper `wr.py:5148-5157`), which
> now matches the primary's root.

### B.6 — Factory-routing commit (`wr.py:2732–2748`)

```text
    factory_routing_path = f"rationalization/wave-{input.wave_id}/factory-routing.json"   # wr.py:2739-2741  ⚠️CHANGED
    await self._commit_artifact(repo, branch, factory_routing_path,           # wr.py:2742-2748
        self._build_factory_routing(input, per_app_results),
        f"Wave {input.wave_id}: factory routing")
```

- `_build_factory_routing` (`wr.py:5332-5394`) is **pure** (local `import json`); it buckets each
  app by disposition. ⚠️ **CHANGED — now 5 route buckets (was 4):**
  `{Refactor,Rearchitect,Replace,Replatform}→modernization`; **NEW `Build`→`build`** (the Phase-6
  W5 Build line — no legacy source to extract); `{Retire,Consolidate}→disposition_execution`;
  `Retain→retain`; else→`unknown`. The `routes`/`summary` dicts gained a `build`/`build_count`
  key. No activity. (Full mapping + GOTCHA-WR-FR1 in sibling `-5-fanout-gates-merge`.)

### B.7 — Gate G-DA loop (`wr.py:2750–3076`) ★ CORE

This is the gate that approves all per-app dispositions. **Dual-signal** (PM merge +
stakeholder), **merge-retry-aware**, **rework loop**. Reproduced exhaustively.

```text
    progress_before_gda = (                                        # wr.py:2751-2760
        progress_after_redundancy
        + STEP_WEIGHTS["gate-review-rr"] + STEP_WEIGHTS["disposition-recommendation"]
        + STEP_WEIGHTS["disposition-governance"] + STEP_WEIGHTS["user-impact-analysis"]
        + STEP_WEIGHTS["classification"] + STEP_WEIGHTS["portfolio-scoring"]
        + STEP_WEIGHTS["wave-planning"])

    while True:                                                     # wr.py:2761  ★G-DA LOOP
        gda_pr = await self._open_gate_pr(                          # wr.py:2762-2769
            repo, branch, input, "G-DA",
            f"Gate G-DA: Wave {input.wave_id} Disposition Approval",
            self._build_gda_body(input, per_app_results))           # pure body builder, wr.py:5240
        gate_record = await act(create_gate_record,                 # wr.py:2770-2781
            CreateGateRecordInput(
                gate_type="G-DA", wave_id=input.wave_id, portfolio_id=input.portfolio_id,
                workflow_id=workflow.info().workflow_id,
                evidence_package_url=gda_pr.pr_url),
            sc=30s, rp="transient")
        self._register_gate_key(gate_record.gate_id, "G-DA")        # wr.py:2782  ← flush pre-record signals

        # -- Assemble artifact_paths (wave-level + per-app) --      wr.py:2783-2791 (comment)
        artifact_paths = [matrix_path, ux_path, methodology_path,   # wr.py:2792-2798
                          wave_plan_path, factory_routing_path]
        for app_id in input.app_ids:                                # wr.py:2799  ★LOOP
            artifact_paths.extend([                                 # wr.py:2800-2808
                f"rationalization/wave-{input.wave_id}/{app_id}/{SKILLS['disposition-recommendation']['artifact']}",
                f"rationalization/wave-{input.wave_id}/{app_id}/{SKILLS['disposition-governance']['artifact']}",
                f"rationalization/wave-{input.wave_id}/{app_id}/{SKILLS['classification']['artifact']}",
                f"rationalization/wave-{input.wave_id}/{app_id}/{SKILLS['portfolio-score']['artifact']}",
                f"rationalization/wave-{input.wave_id}/{app_id}/{SKILLS['intra-app-redundancy']['artifact']}"])

        # -- Nested closure: per-app rollup card builder --          wr.py:2825-2888
        def _per_app_rollup(*, title, skill_id, artifact_filename, key, narrative_key=""):
            file_artifacts = []; body_sections = []
            for app_id in input.app_ids:                            # wr.py:2835  ★LOOP
                per_app = per_app_results.get(app_id, {}) or {}     # wr.py:2836
                content = ""; narrative = ""
                if   key == "disposition_json":                     # wr.py:2844  ★MATCH key
                    content   = per_app.get("disposition_json", "") or ""        # 2845
                    narrative = per_app.get(narrative_key, "") or ""             # 2846
                elif key == "governance_json":                      # wr.py:2847
                    content   = per_app.get("governance_json", "") or ""
                    narrative = per_app.get(narrative_key, "") or ""
                elif key == "user_impact_json":                     # wr.py:2850
                    content   = per_app.get("user_impact_json", "") or ""
                    narrative = per_app.get(narrative_key, "") or ""
                elif key == "cls_json":                             # wr.py:2853
                    cls_record = classification_results.get(app_id, {}) or {}    # 2854
                    content   = cls_record.get("cls_json", "") or ""
                    narrative = cls_record.get(narrative_key, "") or ""
                elif key == "score_json":                           # wr.py:2857
                    score_record = portfolio_scores.get(app_id, {}) or {}        # 2858
                    content   = score_record.get("score_json", "") or ""
                    narrative = score_record.get(narrative_key, "") or ""
                section_parts = [f"### {app_id}"]                   # wr.py:2861
                if narrative:                                       # wr.py:2862  ★BRANCH
                    section_parts.append(narrative)
                if content:                                         # wr.py:2864  ★BRANCH
                    section_parts.append(f"#### Artifact: `{artifact_filename}`")   # 2868
                    section_parts.append("```json")                  # 2870
                    section_parts.append(content)                    # 2871
                    section_parts.append("```")                      # 2872
                body_sections.append("\n\n".join(section_parts))    # wr.py:2873
                file_artifacts.append({                             # wr.py:2874-2881
                    "path": f"rationalization/wave-{input.wave_id}/{app_id}/{artifact_filename}",
                    "content": content, "encoding": "utf-8"})
            return {"title": title, "skill_id": skill_id, "artifact": artifact_filename,
                    "output": "\n\n".join(body_sections), "file_artifacts": file_artifacts}   # 2882-2888

        disp_skill_meta  = SKILLS["disposition-recommendation"]     # wr.py:2890
        cls_skill_meta   = SKILLS["classification"]                 # wr.py:2891
        score_skill_meta = SKILLS["portfolio-score"]                # wr.py:2892
        wave_plan_entry  = _build_rationalization_step_entry(       # wr.py:2893-2898 (module fn)
            title="Wave Planning", skill_id=SKILLS["wave-plan"]["skill_id"],
            artifact_filename=SKILLS["wave-plan"]["artifact"], result=wave_plan_result)
        gov_skill_meta = SKILLS["disposition-governance"]           # wr.py:2905
        ui_skill_meta  = SKILLS["user-impact"]                      # wr.py:2906
        gda_steps = {                                               # wr.py:2907-2951
            "disposition-recommendation": _per_app_rollup(title="Disposition Recommendation",
                skill_id=disp_skill_meta["skill_id"], artifact_filename=disp_skill_meta["artifact"],
                key="disposition_json", narrative_key="disposition_narrative"),
            "disposition-governance": _per_app_rollup(title="Disposition Governance",
                skill_id=gov_skill_meta["skill_id"], artifact_filename=gov_skill_meta["artifact"],
                key="governance_json", narrative_key="governance_narrative"),
            "user-impact-analysis": _per_app_rollup(title="User Impact Analysis",
                skill_id=ui_skill_meta["skill_id"], artifact_filename=ui_skill_meta["artifact"],
                key="user_impact_json", narrative_key="user_impact_narrative"),
            "classification": _per_app_rollup(title="Classification & Risk Tiering",
                skill_id=cls_skill_meta["skill_id"], artifact_filename=cls_skill_meta["artifact"],
                key="cls_json", narrative_key="cls_narrative"),
            "portfolio-scoring": _per_app_rollup(title="Portfolio Scoring",
                skill_id=score_skill_meta["skill_id"], artifact_filename=score_skill_meta["artifact"],
                key="score_json", narrative_key="score_narrative"),
            "wave-planning": wave_plan_entry,
        }

        await act(submit_gate_evidence,                             # wr.py:2952-2984
            SubmitGateEvidenceInput(
                gate_id=gate_record.gate_id, gate_type=GateType.G_DA,
                app_id=f"wave-{input.wave_id}", artifact_paths=artifact_paths,
                pr_url=gda_pr.pr_url,
                evidence_data={
                    "wave_id": input.wave_id, "app_ids": input.app_ids,
                    "assembly_line": "Rationalization",
                    "per_app": per_app_results, "steps": gda_steps,
                    "validation_warnings": dict(self._validation_warnings),   # wr.py:2968
                    "tier1_approvals": [                            # wr.py:2976-2978
                        self._tier1_approval_records[app_id]
                        for app_id in sorted(self._tier1_approval_records)]}),
            sc=60s, rp="transient")

        if workflow.patched("wave-rationalization-gate-pre-review-v1"):   # wr.py:2990  ★BRANCH (patch)
            await self._run_gate_pre_review(                        # wr.py:2991-2997
                gate_record.gate_id, "G-DA", artifact_paths,
                artifact_repo=repo, artifact_ref=branch)             # ← NO optional_evidence_paths (G-DA has none)
        await act(mark_gate_ready_for_review, gate_record.gate_id,  # wr.py:2998-3003 (positional)
                  sc=30s, rp="transient")

        await self._set_step("gate-review-da", progress_before_gda)  # wr.py:3005
        decision = await self._wait_for_gate("G-DA")                # wr.py:3006  ★GATE WAIT
        if decision == "cancelled":                                 # wr.py:3007  ★BRANCH G-DA-1
            return "cancelled"                                      # wr.py:3008
        if decision == "approved":                                  # wr.py:3009  ★BRANCH G-DA-2
            await workflow.wait_condition(                          # wr.py:3011  ★DUAL-SIGNAL WAIT
                lambda: self._stakeholder_approved or self.cancelled)
            if self.cancelled:                                      # wr.py:3012  ★BRANCH G-DA-2a
                self._status = WorkflowStatus.CANCELLED             # wr.py:3013
                return "cancelled"                                  # wr.py:3014
            self._stakeholder_approved = False                      # wr.py:3016  ← consume the flag
            await self._reconcile_and_merge_with_retry_loop(        # wr.py:3018-3022  ★MERGE LOOP
                repo=repo, pr_number=gda_pr.pr_number, gate_id=gate_record.gate_id)
            await self._project_per_app_side_effects(               # wr.py:3028-3033
                input, classification_results, per_app_results, portfolio_scores)
            break                                                   # wr.py:3034  ← EXIT G-DA loop (approved+merged)
        # decision == "rejected":                                   # falls through
        self._stakeholder_approved = False                          # wr.py:3036  ← reset stakeholder
        self._rework_iterations_gda += 1                            # wr.py:3037
        if self._rework_iterations_gda > MAX_REWORK_ITERATIONS:     # wr.py:3038  ★BRANCH G-DA-3 (max rework)
            self._status = WorkflowStatus.FAILED                    # wr.py:3039
            self._current_step = "max-rework-exceeded-gda"          # wr.py:3040
            return "failed"                                         # wr.py:3041
        await self._merge_capability_lineage_row_rework(            # wr.py:3054-3056
            gate_record.gate_id)
        rework_pipelines = [                                        # wr.py:3063-3073
            self._per_app_pipeline(app_id, input, repo, branch, workspace_key, rework=True)
            for app_id in input.app_ids]
        rework_results = await asyncio.gather(*rework_pipelines)    # wr.py:3074
        for app_id, result in zip(input.app_ids, rework_results):   # wr.py:3075  ★LOOP
            per_app_results[app_id] = result                        # wr.py:3076
        # loop back to top of `while True` → re-open G-DA PR with refreshed per_app_results
```

**G-DA loop branch inventory (≈14 branch/loop points in 2750–3076):** `while True` (2761);
`for app_id … artifact_paths.extend` (2799); inside `_per_app_rollup`: `for app_id` (2835),
the 5-way `if/elif` on `key` (2844/2847/2850/2853/2857), `if narrative` (2862), `if content`
(2864); `if workflow.patched("…gate-pre-review-v1")` (2990); `if decision=="cancelled"` (3007);
`if decision=="approved"` (3009); `if self.cancelled` (3012); `if
self._rework_iterations_gda > MAX_REWORK_ITERATIONS` (3038); `for app_id … rework_results`
(3075).

> ⚠️ **GOTCHA-GDA-DUAL-SIGNAL (TWO independent gates → approve):** approval of the G-DA gate
> requires **BOTH** (a) `_wait_for_gate("G-DA")` returns `"approved"` (PM merged the gate PR /
> fired `gate_approved`) AND (b) a separate `await workflow.wait_condition(lambda:
> self._stakeholder_approved or self.cancelled)` (`wr.py:3011`) succeeds because a
> `StakeholderApprovedSignal` with `scope != "tier-1-classification"` arrived. These are two
> sequential waits: the gate decision FIRST, then the stakeholder flag. The stakeholder flag is
> **consumed** (set `False`, `wr.py:3016`) so a subsequent rework cycle requires a *fresh*
> stakeholder signal. A rebuild MUST keep both waits in this order and MUST reset
> `_stakeholder_approved=False` after consuming AND on the reject path (`wr.py:3036`). Omitting
> the reset would let a stale stakeholder approval auto-satisfy the next cycle.
> ⚠️ **GOTCHA-GDA-CANCEL-TWO-SITES:** cancel can short-circuit at TWO points: (1) inside
> `_wait_for_gate` → returns `"cancelled"` → `return "cancelled"` (`wr.py:3007-3008`, status set
> to CANCELLED inside the helper); (2) during the dual-signal wait → `if self.cancelled:` sets
> `_status=CANCELLED` and `return "cancelled"` (`wr.py:3012-3014`). A rebuild must thread
> `self.cancelled` into BOTH waits (the gate-wait predicate is inside `_wait_for_gate`; the
> dual-signal predicate is explicit here).
> ⚠️ **GOTCHA-GDA-MAXREWORK (`>`, not `>=`):** `self._rework_iterations_gda += 1` is applied
> BEFORE the comparison, then `if self._rework_iterations_gda > MAX_REWORK_ITERATIONS` (3)
> (`wr.py:3037-3038`). So the loop allows rework iterations 1, 2, 3 and FAILS on the 4th
> rejection (when the counter reaches 4 > 3). Terminal: `_status=FAILED`,
> `_current_step="max-rework-exceeded-gda"`, return `"failed"` — **no DB persist here** (the
> outer `run()` try/except does the `persist_wave_failure` on the raised path, but THIS return
> does NOT raise — it returns `"failed"` cleanly; `run()` does NOT wrap a clean return, so a
> max-rework G-DA exit lands the workflow as COMPLETED-with-result-"failed" at the Temporal
> level, NOT a Temporal-FAILED run). A rebuild MUST use strict `>`, set those exact terminal
> vars, and `return "failed"` (not raise).
> ⚠️ **GOTCHA-GDA-EVIDENCE-DIRECT (no `_submit_gate_evidence` helper):** unlike the base lines,
> this scope calls `submit_gate_evidence` activity **directly** (`wr.py:2952`) with a fully
> hand-built `evidence_data` dict (per-app rollup cards + validation_warnings + tier1_approvals)
> — it does NOT go through `LineWorkflowBase._submit_gate_evidence` (no `check_gate_criteria`
> call here, no slim/enriched split). A rebuild must reproduce the direct call with the exact
> `evidence_data` shape; do NOT insert a `check_gate_criteria` call.
> ⚠️ **GOTCHA-GDA-READY-FLIP-ALWAYS:** `mark_gate_ready_for_review` (`wr.py:2998`) is called
> **unconditionally** AFTER the (patch-gated) pre-review — it is NOT inside the patch guard and
> NOT in a `finally`. Contrast the base's `_run_gate_pre_review` which flips ready inside its own
> `finally` under `mark-gate-ready-for-review-v1`. Here the wave's inlined `_run_gate_pre_review`
> (`wr.py:5571-5685`) does **NOT** flip ready (no `finally` block); the `_execute` body owns the
> ready-flip explicitly at `wr.py:2998`. A rebuild MUST NOT put a ready-flip inside the wave's
> `_run_gate_pre_review`, and MUST call `mark_gate_ready_for_review` unconditionally after it.
> ⚠️ **GOTCHA-GDA-PREREVIEW-NO-OPTIONAL (the G-DA call passes no optional evidence):** the G-DA
> pre-review call (`wr.py:2991-2997`) passes `gate_id, "G-DA", artifact_paths, artifact_repo,
> artifact_ref` and **omits** the new `optional_evidence_paths` kwarg — G-DA's evidence has no
> sometimes-missing companion (the `shared-identity-report.json` optional split is a **G-RR-only**
> concern, sibling `-execute-a`). So the G-DA call shape is unchanged from baseline; a rebuild
> must NOT add optional paths here.
> ⚠️ **GOTCHA-GDA-TIER1-SORTED:** `tier1_approvals` in evidence (`wr.py:2976-2978`) and the
> pre-review context iterate `sorted(self._tier1_approval_records)` — sorted by app_id key for a
> **deterministic** evidence_data shape under replay. A rebuild MUST sort; iterating dict order
> would be replay-safe in CPython 3.7+ but the code sorts explicitly and a rebuild should match.
> ⚠️ **GOTCHA-GDA-MERGE-DELEGATED:** post-approval merge is delegated to the inlined
> `_reconcile_and_merge_with_retry_loop` (`wr.py:5687-5762`) — it merges `gda_pr.pr_number` via
> `reconcile_and_merge_pr` (60s, **`git_merge`** policy), and on a structured merge error
> (`MergeConflict`/`MergeDivergenceUnresolved`/`MergeBranchProtectionRejected` unwrapped from
> `ActivityError.__cause__`) it sets the gate `merge_blocked` and `wait_condition(lambda:
> self._merge_retry_signalled or self.cancelled)`, looping until merge succeeds or cancel. See
> the helper spec for the full loop; behavior matches `_LineWorkflowBase.md` §14 (GOTCHA-MR1..6),
> but it is **inlined**, not inherited. `_project_per_app_side_effects` runs ONLY after the merge
> loop returns successfully (i.e. NOT on cancel-inside-merge — but note: cancel inside the merge
> loop `return`s from the helper, and execution then continues to
> `_project_per_app_side_effects` at `wr.py:3028`! See GOTCHA-MERGE-CANCEL-FALLTHROUGH).

> ⚠️ **GOTCHA-MERGE-CANCEL-FALLTHROUGH (subtle):** `_reconcile_and_merge_with_retry_loop`
> returns `None` BOTH on successful merge AND on cancel-during-merge_blocked (`wr.py:5761-5762`:
> `if self.cancelled: return`). The `_execute` G-DA approve branch does NOT re-check
> `self.cancelled` after the merge loop — it unconditionally proceeds to
> `_project_per_app_side_effects(...)` then `break` (`wr.py:3028-3034`). So if a cancel arrives
> while merge is blocked, the wave still runs the side-effects projection (best-effort, each app
> independent) and breaks out as if approved, then proceeds to wave-outcome-synthesis. The wave
> does NOT short-circuit to "cancelled" once it has passed the dual-signal wait. A rebuild MUST
> reproduce this: no cancel re-check between the merge loop and the side-effects projection.
> (This is arguably a latent bug, but parity requires reproducing it.)

`_project_per_app_side_effects(input, classification_results, per_app_results, portfolio_scores)`
(`wr.py:3934-3996`) — reproduced because it is the W19 transactional-boundary projection invoked
on G-DA approval:

```text
    projection_tasks = []
    for app_id in input.app_ids:                                   # wr.py:3957
        cls   = classification_results.get(app_id, {})
        disp  = per_app_results.get(app_id, {})
        score = portfolio_scores.get(app_id, {})
        projection_tasks.append(workflow.execute_activity(         # wr.py:3962-3978
            persist_rationalization_side_effects,
            PersistRationalizationSideEffectsInput(
                app_id=app_id,
                classification_json = cls.get("cls_json","") or "",
                portfolio_score_json = score.get("score_json","") or "",
                disposition_recommendation_json = disp.get("disposition_json","") or "",
                disposition_rationale_ref = disp.get("disposition_path","") or "",
                tier_1_approved = app_id in self._tier1_approved_apps),    # wr.py:3973
            sc=60s, rp="transient"))
    results = await asyncio.gather(*projection_tasks, return_exceptions=True)   # wr.py:3981
    for app_id, result in zip(input.app_ids, results):             # wr.py:3982
        if isinstance(result, BaseException):                       # wr.py:3983  ★BRANCH (best-effort)
            workflow.logger.warning("persist_rationalization_side_effects failed for app",
                extra={"app_id":…, "wave_id":…, "error":repr(result)})
```

> ⚠️ **GOTCHA-SIDEEFFECTS-BESTEFFORT:** `gather(..., return_exceptions=True)` (`wr.py:3981`) —
> per-app projection failures are CAUGHT (returned as exception objects), logged, and do NOT
> propagate. The wave proceeds to wave-outcome-synthesis regardless. A rebuild MUST pass
> `return_exceptions=True` and NOT re-raise; the comment (`wr.py:3950-3953`) is explicit that one
> malformed artifact must not block the rest of the wave.
> ⚠️ **GOTCHA-SIDEEFFECTS-AFTER-MERGE:** these DB writes happen AFTER G-DA merges
> (`wr.py:3023-3025` comment: "G-DA is the transactional boundary for Rationalization's DB
> ownership"). So a rebuild must NOT project classification/score/disposition to `application`
> rows mid-flow; only here, post-approval. (The legacy mid-flow `persist_classification` /
> `persist_portfolio_score` were retired — W19 PR 3.)

### B.8 — Wave Outcome Synthesis (`wr.py:3078–3221`)

Runs after the G-DA `while True` loop `break`. G-DA approved; consolidate into the executive
`wave-outcome-synthesis.json`.

```text
    progress_before_synthesis = (                                  # wr.py:3084-3094
        progress_after_redundancy
        + STEP_WEIGHTS["gate-review-rr"] + ... + STEP_WEIGHTS["wave-planning"]
        + STEP_WEIGHTS["gate-review-da"])
    await self._set_step("wave-outcome-synthesis", progress_before_synthesis)   # wr.py:3095
    synthesis_skill = SKILLS["wave-outcome-synthesis"]             # wr.py:3096 → {"wave-outcome-synthesizer", "wave-outcome-synthesis.json"}

    per_app_artifact_refs = {                                      # wr.py:3105-3133
        app_id: {
            "disposition":     f"rationalization/wave-{input.wave_id}/{app_id}/{SKILLS['disposition-recommendation']['artifact']}",
            "governance":      f"rationalization/wave-{input.wave_id}/{app_id}/{SKILLS['disposition-governance']['artifact']}",
            "classification":  f"rationalization/wave-{input.wave_id}/{app_id}/{SKILLS['classification']['artifact']}",
            "portfolio_score": f"rationalization/wave-{input.wave_id}/{app_id}/{SKILLS['portfolio-score']['artifact']}",
            "user_impact":     f"rationalization/wave-{input.wave_id}/{app_id}/{SKILLS['user-impact']['artifact']}",
            "disposition_output_bundle": f"dispositions/{input.portfolio_id}/{app_id}/disposition-output.json",
        }
        for app_id in input.app_ids}
    candidate_bundle_paths = [refs["disposition_output_bundle"]    # wr.py:3140-3143
                              for refs in per_app_artifact_refs.values()]

    synthesis_result = await act(dispatch_agent_task,              # wr.py:3144-3188
        AgentTaskInput(
            task_type="rationalization-wave-outcome-synthesis",
            skill_id=synthesis_skill["skill_id"], app_id="", wave_id=input.wave_id,
            workspace_key=workspace_key, artifact_repo=repo, artifact_ref=branch,
            input_artifacts=[],                                     # wr.py:3154  ← EMPTY (deliberate)
            optional_input_artifacts=candidate_bundle_paths,        # wr.py:3155  ← bundles may 404
            execution_context=self._execution_ctx("wave-outcome-synthesis",
                input_artifact_paths=candidate_bundle_paths),
            context=_with_fixture_scenario(
                {
                    "wave_id": input.wave_id, "wave_name": input.wave_name,
                    "portfolio_id": input.portfolio_id, "app_ids": input.app_ids,
                    "per_app_artifact_refs": per_app_artifact_refs,
                    "disposition_output_bundle_refs": {             # wr.py:3170-3175
                        app_id: per_app_artifact_refs[app_id]["disposition_output_bundle"]
                        for app_id in input.app_ids},
                    "wave_level_artifact_refs": {                   # wr.py:3176-3179
                        "redundancy_matrix": matrix_path, "wave_plan": wave_plan_path},
                },
                synthesis_skill["skill_id"], input.fixture_scenarios),
            timeout_seconds=3600),
        sc=3600s (=1h), rp="agent_failure")

    synthesis_path = f"rationalization/wave-{input.wave_id}/{synthesis_skill['artifact']}"   # wr.py:3189
    synthesis_raw = self._primary_output_content(synthesis_result, synthesis_skill["artifact"])   # wr.py:3196
    await self._validate_artifact_or_warn(                          # wr.py:3202-3206
        artifact_filename=synthesis_skill["artifact"], raw_content=synthesis_raw, wave_id=input.wave_id)
    await self._commit_artifact(repo, branch, synthesis_path, synthesis_raw,   # wr.py:3207-3213
        f"Wave {input.wave_id}: outcome synthesis")
    await self._commit_output_files(repo, branch, synthesis_result,   # wr.py:3214-3221
        primary_path=synthesis_path, wave_id=input.wave_id,
        commit_message_prefix=f"Wave {input.wave_id}: outcome synthesis companion")
```

> ⚠️ **GOTCHA-SYNTH-OPTIONAL-INPUTS:** `input_artifacts=[]` (empty) but
> `optional_input_artifacts=candidate_bundle_paths` (`wr.py:3154-3155`). The disposition-output
> bundles (`dispositions/{portfolio_id}/{app_id}/disposition-output.json`) are emitted by the
> *Disposition Execution* line which runs AFTER rationalization — so on the first synthesis pass
> they GENUINELY DO NOT EXIST. Putting them in `optional_input_artifacts` makes the agent runtime
> treat a 404 as "not present yet" instead of failing the dispatch. A rebuild MUST use
> `optional_input_artifacts` for the bundle paths, not `input_artifacts`, or every first-pass
> synthesis fails.
> ⚠️ **GOTCHA-SYNTH-NO-CONTEXT-PRIORS:** this dispatch uses `_with_fixture_scenario` only — NOT
> `_with_context_priors`. (Only the PRA dispatches use priors.)

### B.9 — Architecture coordinator / dispatch terminal routing (`wr.py:3223–3271`) ★ TERMINAL

The final block: choose the handoff path, set terminal state, return a terminal string. **Three
mutually-exclusive patch-gated arms + a default.**

```text
    if workflow.patched("wave-arch-coordinator-v1"):               # wr.py:3240  ★ARM 1 (current path)
        terminal = await self._handoff_to_architecture_coordinator(input)   # wr.py:3241
        self._status       = WorkflowStatus.COMPLETED              # wr.py:3242
        self._progress_pct = 100.0                                 # wr.py:3243
        self._current_step = terminal                             # wr.py:3244
        self._updated_at   = _now_iso()                            # wr.py:3245
        return terminal                                            # wr.py:3246
                                                                   #   terminal ∈ {"architecture-coordinator-started",
                                                                   #               "architecture-coordinator-start-failed"}

    if workflow.patched("wave-rationalization-architecture-dispatch-v1"):   # wr.py:3248  ★ARM 2 (legacy inline fan-out)
        terminal = await self._execute_architecture_data_fanout(   # wr.py:3249-3252
            input, per_app_results)                                #   (NOT in this scope — sibling -fanout spec)
        if terminal in ("completed", "dispatched"):                # wr.py:3256  ★BRANCH
            self._status = WorkflowStatus.COMPLETED                # wr.py:3257
        else:                                                      # wr.py:3258
            self._status = WorkflowStatus.FAILED                   # wr.py:3259
        self._progress_pct = 100.0                                 # wr.py:3260
        self._current_step = ("architecture-dispatched"           # wr.py:3261-3263
                              if terminal == "dispatched" else terminal)
        self._updated_at = _now_iso()                              # wr.py:3264
        return terminal                                            # wr.py:3265

    # No patch → bare completion (oldest path)                     # wr.py:3267-3271  ★ARM 3 (default)
    self._status       = WorkflowStatus.COMPLETED
    self._progress_pct = 100.0
    self._current_step = "completed"
    self._updated_at   = _now_iso()
    return "completed"
```

> ⚠️ **GOTCHA-ARCH-ARM-ORDER (first-match wins):** the two patch arms are tested in order;
> `wave-arch-coordinator-v1` (ARM 1) is checked FIRST and returns, so on any history where it is
> patched-on it ALWAYS wins — ARM 2 (`wave-rationalization-architecture-dispatch-v1`) is dead for
> new runs (comment `wr.py:3234-3238`: "New runs always take the coordinator path"). ARM 2 exists
> ONLY for in-flight pre-coordinator replay determinism. A rebuild MUST keep BOTH `if`s in this
> exact order (NOT `elif` — they are separate `if` statements, but ARM 1 returns so ARM 2 is
> unreachable when ARM 1 fires). Reordering or merging them changes replay history.
> ⚠️ **GOTCHA-ARCH-ARM2-STATUS-MAP:** ARM 2 maps `_execute_architecture_data_fanout`'s string
> return: `{"completed","dispatched"}→COMPLETED`, anything else→FAILED (`wr.py:3256-3259`); and
> `_current_step` is `"architecture-dispatched"` iff the return was `"dispatched"`, else the raw
> terminal (`wr.py:3261-3263`). But the **returned value** is the raw `terminal`, NOT
> "architecture-dispatched". A rebuild must distinguish the return value (`terminal`) from
> `_current_step`.
> ⚠️ **GOTCHA-ARCH-TERMINAL-COMPLETED-ALWAYS (ARM 1):** ARM 1 sets `_status=COMPLETED`
> **regardless** of whether the coordinator started successfully — even when
> `_handoff_to_architecture_coordinator` returns `"architecture-coordinator-start-failed"`. The
> docstring (`wr.py:3287-3290`) is explicit: coordinator-start failure does NOT roll back
> Rationalization's success. A rebuild MUST set COMPLETED unconditionally in ARM 1 and return the
> handoff's string verbatim (it becomes `_current_step`).

---

## C. `_handoff_to_architecture_coordinator(self, input)` (`wr.py:3273–3351`)

Spawns the `WaveArchitectureWorkflow` coordinator child with **ABANDON** close policy and
persists its handle. Returns a terminal string; **never raises** (both failure modes are
caught).

```text
async def _handoff_to_architecture_coordinator(self, input) -> str:
    coordinator_workflow_id = f"wave-architecture-{input.wave_id}"   # wr.py:3292
    coordinator_input = WaveArchitectureWorkflowInput(             # wr.py:3293-3301
        wave_id=input.wave_id, wave_name=input.wave_name,
        portfolio_id=input.portfolio_id,
        app_ids=list(input.app_ids),                              # ← copy, not alias
        artifact_repo=input.artifact_repo,
        stakeholder=input.stakeholder,
        fixture_scenarios=dict(input.fixture_scenarios))          # ← copy, not alias
    try:                                                          # wr.py:3302
        await workflow.start_child_workflow(                      # wr.py:3303-3308
            "WaveArchitectureWorkflow", coordinator_input,
            id=coordinator_workflow_id,
            parent_close_policy=workflow.ParentClosePolicy.ABANDON)   # ★ABANDON
    except Exception as exc:                                       # wr.py:3309  ★BRANCH C1 (start failed)
        workflow.logger.error("wave-arch-coordinator start failed",
            extra={"wave_id":…, "coordinator_workflow_id":…, "error":repr(exc)})
        return "architecture-coordinator-start-failed"            # wr.py:3318  ← EARLY RETURN

    try:                                                          # wr.py:3320
        await act(update_wave_architecture_workflow_id,           # wr.py:3321-3330
            UpdateWaveArchitectureWorkflowIdInput(
                wave_id=input.wave_id,
                architecture_workflow_id=coordinator_workflow_id),
            sc=30s, rp="transient",
            aid=f"persist-arch-coordinator-id-{input.wave_id}")
    except Exception as exc:                                       # wr.py:3331  ★BRANCH C2 (persist failed, best-effort)
        workflow.logger.warning("update_wave_architecture_workflow_id failed",
            extra={"wave_id":…, "coordinator_workflow_id":…, "error":repr(exc)})
        # NO return — falls through to the info log + success return.

    workflow.logger.info("wave-arch-coordinator handed off",       # wr.py:3344-3350
        extra={"wave_id":…, "coordinator_workflow_id":…})
    return "architecture-coordinator-started"                     # wr.py:3351
```

**Branch inventory (2):** `except Exception` on `start_child_workflow` (3309) → early-return
`"architecture-coordinator-start-failed"`; `except Exception` on `update_wave_architecture_
workflow_id` (3331) → log-and-continue (NO return). Distinct outcomes.

> ⚠️ **GOTCHA-HANDOFF-ABANDON:** the coordinator is started with
> `parent_close_policy=workflow.ParentClosePolicy.ABANDON` (`wr.py:3307`). This lets the
> coordinator OUTLIVE this rationalization workflow — Rationalization completes cleanly at G-DA
> approval while `WaveArchitectureWorkflow` continues independently. A rebuild MUST use ABANDON;
> the default (TERMINATE/REQUEST_CANCEL) would kill the coordinator when this workflow returns.
> ⚠️ **GOTCHA-HANDOFF-CHILD-NOT-AWAITED:** `start_child_workflow` is awaited only for the
> *start* (it returns a handle once the child is started), NOT for the child's completion. The
> handle is discarded. A rebuild must NOT `await handle.result()` — that would block
> Rationalization on the entire downstream Architecture line.
> ⚠️ **GOTCHA-HANDOFF-NAME-STRING:** the child is started by the **string** name
> `"WaveArchitectureWorkflow"` (`wr.py:3304`), not a class reference. A rebuild must register that
> workflow under exactly that name and start it by string (matches how the wave workflows are
> registered with the worker).
> ⚠️ **GOTCHA-HANDOFF-DETERMINISTIC-ID:** `coordinator_workflow_id = f"wave-architecture-
> {input.wave_id}"` (`wr.py:3292`) is deterministic per wave. If a coordinator with that id
> already exists, `start_child_workflow` raises `WorkflowAlreadyStartedError` → caught by C1 →
> returns `"architecture-coordinator-start-failed"` (docstring `wr.py:3287-3290` mentions
> "pre-existing handle collision"). A rebuild must use this exact id format and let the collision
> surface through C1.
> ⚠️ **GOTCHA-HANDOFF-INPUT-COPIES:** `app_ids=list(input.app_ids)` and
> `fixture_scenarios=dict(input.fixture_scenarios)` (`wr.py:3297,3300`) defensively COPY the
> collections so the child can't alias the parent's mutable state across the workflow boundary.
> Functionally moot under Temporal serialization but a rebuild should copy for parity.
> ⚠️ **GOTCHA-HANDOFF-PERSIST-BESTEFFORT:** persisting the coordinator id
> (`update_wave_architecture_workflow_id`) is best-effort (C2) — failure logs a WARNING and the
> handoff still returns `"architecture-coordinator-started"` (success), because the coordinator
> is already running and discoverable via Temporal directly. A rebuild MUST NOT return failure on
> a persist error; only a *start* error returns failure.

---

## D. ACTIVITY & CHILD-WORKFLOW CALL TABLE (this scope, in execution order)

| # | Site | Activity / child | Input | sc (timeout) | retry | activity_id / notes |
|---|------|------------------|-------|--------------|-------|---------------------|
| 1 | 2432 | `load_wave_rationalization_capabilities` | `LoadWaveRationalizationCapabilitiesInput(portfolio_id, wave_id, exec_ctx)` | 30s | transient | `load-rat-cap-grain-rework-{wave}-{grr_iter}`; **try/except best-effort** |
| 2 | 2473 | `dispatch_agent_task` (PRA rework) | `AgentTaskInput(task_type="wave-analyze-portfolio-redundancy", skill="analyze-portfolio-redundancy", context via fixture+priors)` | **1h** | agent_failure | input_artifacts=`_portfolio_redundancy_input_artifacts` |
| 3 | 2510 | `validate_artifact_against_schema` | `ValidateArtifactInput("portfolio-redundancy-matrix.json", raw)` | 30s | transient | inside `_validate_artifact_or_warn`; `except ActivityError` → log (advisory) |
| 4 | 2519 | `write_artifact`/`write_artifacts_batch` | via `_commit_artifact` (patch `wave-rationalization-batch-writes-v1`) | 60s/120s | transient | PRA rework matrix |
| 5 | 2529 | `validate_artifact_against_schema` | `("shared-identity-report.json", …)` | 30s | transient | only for first matching companion |
| 6 | 2535 | `write_artifact[s_batch]` | via `_commit_output_files` (per companion) | 60s/120s | transient | best-effort per file |
| 7 | 2552 | `persist_rationalization_capabilities` | `PersistRationalizationCapabilitiesInput(plan_json, plan_ref, exec_ctx)` | 60s | transient | `persist-rat-caps-rework-{wave}-{grr_iter}`; **try/except best-effort** |
| 8 | 2589 | *(child coros)* `_per_app_pipeline` ×N | — | — | — | `asyncio.gather` (each runs disposition/governance/user-impact dispatches internally) |
| 9 | 2612 | `_classify_app` ×N | — | — | — | `gather`; Tier-1 pause inside |
| 10 | 2637 | `_score_app` ×N | — | — | — | `gather` |
| 11 | 2652 | `write_artifact[s_batch]` | methodology.md via `_commit_artifact` | 60s/120s | transient | pure builder content |
| 12 | 2672 | `dispatch_agent_task` (wave-plan) | `AgentTaskInput(task_type="wave-plan", skill="sequencer")` | **1h** | agent_failure | — |
| 13 | 2714 | `write_artifact[s_batch]` | wave-plan.json via `_commit_artifact` | 60s/120s | transient | ⚠️ path now under `rationalization/wave-{wave}/` (was `planning/`) |
| 14 | 2723 | `write_artifact[s_batch]` | wave-plan companions via `_commit_output_files` | 60s/120s | transient | best-effort |
| 15 | 2742 | `write_artifact[s_batch]` | factory-routing.json via `_commit_artifact` | 60s/120s | transient | pure builder; ⚠️ now under `rationalization/wave-{wave}/`; routes include NEW `build` bucket |
| 16 | 2762 | `create_pr` (G-DA) | via `_open_gate_pr` → `CreatePRInput(target="main")` | 60s | transient | returns `gda_pr` (pr_url, pr_number) |
| 17 | 2770 | `create_gate_record` | `CreateGateRecordInput("G-DA", wave, portfolio, wf_id, pr_url)` | 30s | transient | returns `gate_record.gate_id` |
| 18 | 2952 | `submit_gate_evidence` | `SubmitGateEvidenceInput(G_DA, app="wave-{id}", artifact_paths, evidence_data{per_app, steps, validation_warnings, tier1_approvals})` | 60s | transient | **direct call, no check_gate_criteria** |
| 19 | 2991 | `dispatch_agent_task` (pre-review) | via `_run_gate_pre_review` (skill `gate-pre-review`) | **10m** | transient | ONLY under patch `…gate-pre-review-v1`; best-effort try/except; + `store_gate_pre_review` 30s/transient; G-DA passes NO optional_evidence_paths |
| 20 | 2998 | `mark_gate_ready_for_review` | positional `gate_record.gate_id` | 30s | transient | **unconditional** (not patch-gated, not in finally) |
| 21 | 3018 | `reconcile_and_merge_pr` | via merge loop → `MergePRInput(gda_pr.pr_number)` | 60s | **git_merge** | loop; on structured err → `set_gate_merge_blocked` (30s/transient, positional `args=[gate_id, detail]`) + wait |
| 22 | 2963 | `persist_rationalization_side_effects` ×N | `PersistRationalizationSideEffectsInput(...)` | 60s | transient | via `_project_per_app_side_effects` (`wr.py:3962`); `gather(return_exceptions=True)` best-effort |
| 23 | 3054 | `fetch_gate_capability_lineage_rework` | `FetchGateCapabilityLineageReworkInput(gate_id)` | 30s | transient | via `_merge_capability_lineage_row_rework`; `aid=fetch-capability-lineage-rework-{gate}-iter-{gda_iter}`; best-effort |
| 24 | 3063 | *(child coros)* `_per_app_pipeline(rework=True)` ×N | — | — | — | `gather` on G-DA reject |
| 25 | 3144 | `dispatch_agent_task` (synthesis) | `AgentTaskInput(task_type="rationalization-wave-outcome-synthesis", skill="wave-outcome-synthesizer", input_artifacts=[], optional_input_artifacts=bundles)` | **1h** | agent_failure | — |
| 26 | 3202 | `validate_artifact_against_schema` | `("wave-outcome-synthesis.json", raw)` | 30s | transient | advisory |
| 27 | 3207 | `write_artifact[s_batch]` | synthesis.json via `_commit_artifact` | 60s/120s | transient | — |
| 28 | 3214 | `write_artifact[s_batch]` | synthesis companions via `_commit_output_files` | 60s/120s | transient | best-effort |
| 29 | 3303 | **child** `start_child_workflow("WaveArchitectureWorkflow")` | `WaveArchitectureWorkflowInput(...)` | — | — | `id="wave-architecture-{wave}"`, **ABANDON**; try/except → fail string |
| 30 | 3321 | `update_wave_architecture_workflow_id` | `UpdateWaveArchitectureWorkflowIdInput(wave, arch_wf_id)` | 30s | transient | `aid=persist-arch-coordinator-id-{wave}`; best-effort |

> ⚠️ **GOTCHA-DISPATCH-TIMEOUT-DUAL:** every `dispatch_agent_task` here sets BOTH the
> `AgentTaskInput.timeout_seconds=3600` field AND `start_to_close_timeout=timedelta(hours=1)`.
> The first is the agent's internal budget; the second is Temporal's activity timeout. A rebuild
> must set both — they are not redundant.
> ⚠️ **GOTCHA-COMMIT-PATCH (batch vs single write):** `_commit_artifact` (helper `wr.py:5057-5100`)
> branches on `workflow.patched("wave-rationalization-batch-writes-v1")`: patched →
> `write_artifacts_batch` (120s); else → `write_artifact` (60s). Every commit in this scope goes
> through `_commit_artifact`, so this patch governs ALL of them. A rebuild MUST gate the
> write-activity choice on this verbatim patch id.

---

## E. GATE HANDLING SUMMARY (G-DA) — evidence, wait, routing

1. **Evidence assembly** (`wr.py:2783-2984`): `artifact_paths` = 5 wave-level
   (`matrix_path, ux_path, methodology_path, wave_plan_path, factory_routing_path`) + 5 per-app
   (disposition / governance / classification / portfolio-score / intra-app-redundancy). The
   `evidence_data` carries `per_app` (full per-app result dicts), `steps` (six
   `_per_app_rollup` cards + `wave_plan_entry`), `validation_warnings` (snapshot of
   `_validation_warnings`), and `tier1_approvals` (sorted records). **Direct
   `submit_gate_evidence` call — no `check_gate_criteria`.**
2. **Pre-review** (`wr.py:2990`): patch-gated `_run_gate_pre_review` (best-effort, NO
   `optional_evidence_paths` for G-DA), then **unconditional** `mark_gate_ready_for_review`.
3. **The wait** (`wr.py:3006`): `_wait_for_gate("G-DA")` (helper, `wr.py:5405-5480`) consumes the
   per-key decision queue (5-tuple/3-tuple tolerant), sets `_rework_feedback["G-DA"]` on reject
   (with `rework_targets` resolved from card_decisions), pops it on approve; returns one of
   `"approved" / "rejected" / "cancelled"`.
4. **Routing of the 4 reviewer outcomes:**
   - **cancelled** → `return "cancelled"` (`wr.py:3007-3008`).
   - **approved** → SECOND wait for `_stakeholder_approved` (or cancel) → merge loop → side-effects
     → `break` (`wr.py:3009-3034`). (merge_blocked is handled INSIDE the merge loop, looping on
     `merge_retry` signal.)
   - **rejected** → reset stakeholder flag; `_rework_iterations_gda += 1`; if `> 3` → FAILED +
     return `"failed"`; else merge row-level rework feedback; re-run `_per_app_pipeline(rework=True)`
     fan-out; loop (`wr.py:3035-3076`).
5. **Rework counter:** `_rework_iterations_gda`, bumped at `wr.py:3037`, ceiling
   `MAX_REWORK_ITERATIONS=3`, strict `>`.

> Note: **G-RR** gate (open + wait + the head of its rework loop) is in the `-execute-a` sibling
> spec; THIS spec only owns the **tail** of the G-RR rework body (the PRA re-dispatch, §B.1).

---

## F. RESILIENCE (this scope)

- **Timeouts:** agent dispatches 1h (`agent_failure`); pre-review dispatch 10m; gate-record /
  status / validate / merge_blocked / lineage-fetch / arch-id-persist 30s; create_pr /
  submit_evidence / side-effects / persist-rat-caps / write_artifacts_batch / merge 60s
  (`reconcile_and_merge_pr` 60s git_merge); batch write 120s under the batch patch.
- **Heartbeats:** none configured.
- **continue-as-new:** none in this scope.
- **Idempotency:** deterministic `activity_id`s embedding `wave_id` + iteration counter for the
  rat-cap reload/persist (`-{grr_iter}`), the lineage fetch (`-iter-{gda_iter}`), and the
  arch-id persist; all timestamps via `_now_iso()`. Patch IDs gate every optional path.
- **Compensation / rollback:** NONE in the happy path. Failure semantics:
  - best-effort try/except swallow: rat-cap reload (B3) & persist (B8), companion commits,
    side-effects projection (return_exceptions), lineage-rework merge, arch-id persist (C2),
    pre-review (inside helper), validate_artifact (advisory).
  - structured merge errors → `merge_blocked` + reviewer-retry wait loop (delegated).
  - `MAX_REWORK_ITERATIONS` exceeded at G-DA → terminal `FAILED` + return `"failed"` (clean
    return, NOT a raise — see GOTCHA-GDA-MAXREWORK).
  - any uncaught exception inside `_execute` propagates to `run()`'s try/except
    (`wr.py:1258-1344`, NOT in this scope), which classifies via `classify_failure(exc)` →
    `persist_wave_failure` + flips wave to `failed` or `stuck-awaiting-recovery`, then re-raises.
- **Patch IDs used in THIS scope (verbatim, load-bearing):**
  `"wave-rationalization-grr-rework-pra-v1"` (2408), `"wave-rationalization-gate-pre-review-v1"`
  (2990), `"wave-arch-coordinator-v1"` (3240),
  `"wave-rationalization-architecture-dispatch-v1"` (3248), plus those inside called helpers:
  `"wave-rationalization-batch-writes-v1"` (`_commit_artifact`), and (read in §B.1 head)
  `do_rat_cap_clustering`/`do_portfolio_synthesis` flags (set in `-execute-a`). A rebuild MUST
  reproduce each string exactly.

---

## G. Behavioral parity checklist (this scope MUST satisfy ALL)

1. **G-RR rework tail (B.1):** (the cross-app rework dispatch + its matrix/companion re-commit are
   now in sibling `-execute-a`, `wr.py:2331-2384`.) THIS scope starts at the PRA rework decision
   (`wr.py:2386`): compute `skip_pra = scope_to_targets and "analyze-portfolio-redundancy" not in
   rework_targets and skip_cross_app`. Re-run PRA ONLY when `do_portfolio_synthesis AND
   workflow.patched("wave-rationalization-grr-rework-pra-v1") AND not skip_pra`. ⚠️ The rework PRA
   path does NOT apply the `pra-nonempty-v1` empty-plan guard (that is primary-dispatch-only).
   (GOTCHA-SKIP-PRA)
2. **PRA rework dispatch** carries `_rework_feedback.get("G-RR")` in context, is wrapped in BOTH
   `_with_fixture_scenario` and `await _with_context_priors`, uses
   `_portfolio_redundancy_input_artifacts`, 1h/`agent_failure`. (GOTCHA-PRA-CONTEXT-PRIORS)
3. **Rat-cap reload/persist** (when `do_rat_cap_clustering`): both best-effort try/except, with
   `activity_id`s embedding `wave_id` AND `_rework_iterations_grr`. Persist only when
   `do_rat_cap_clustering AND pra_rework_raw`. (GOTCHA-RATCAP-ACTIVITY-IDS)
4. **Companion-validate loop** validates only the FIRST `shared-identity-report.json` match then
   `break`. (GOTCHA-SHARED-IDENTITY-BREAK)
5. **Four fan-outs** (per-app pipeline, classify, score, G-DA rework) use `asyncio.gather` over
   the coroutine list, then `zip(app_ids, results)` into dicts keyed by app_id. (GOTCHA-PAR)
6. **`_set_step` progress** is computed as the running sum of `STEP_WEIGHTS[...]` exactly as
   transcribed at each call (2584, 2603, 2627, 2661, 2751, 3005, 3084, 3095). Clamped to [0,100]
   inside `_set_step`.
7. **methodology / factory-routing / scoring** content built by the PURE builders
   (`_build_scoring_methodology`, `_build_factory_routing`) — no activity, deterministic
   `_now_iso()` timestamp in factory-routing. ⚠️ `_build_factory_routing` now has a `build` route
   bucket for the `Build` disposition (5 buckets). Committed via `_commit_artifact`.
8. ⚠️ **CHANGED — wave-plan + factory-routing now under `rationalization/wave-{wave}/…`** (were
   `planning/{wave}/…`): `rationalization/wave-{wave}/wave-plan.json` and
   `rationalization/wave-{wave}/factory-routing.json`; everything else also under
   `rationalization/wave-{wave}/…`. (GOTCHA-WAVEPLAN-PATH)
9. **G-DA loop is `while True`** that: opens PR → creates gate record → `_register_gate_key` →
   builds `artifact_paths` (5 wave + 5×N per-app) → builds `gda_steps` via the nested
   `_per_app_rollup` closure (5-way `if/elif` on `key`, narrative-then-content card body) +
   `wave_plan_entry` → `submit_gate_evidence` (DIRECT, with the exact evidence_data dict incl.
   `validation_warnings` and SORTED `tier1_approvals`) → patch-gated pre-review →
   **unconditional** `mark_gate_ready_for_review` → `_wait_for_gate("G-DA")`.
   (GOTCHA-GDA-EVIDENCE-DIRECT, GOTCHA-GDA-READY-FLIP-ALWAYS, GOTCHA-GDA-TIER1-SORTED)
10. **G-DA approve** requires the dual signal: `_wait_for_gate=="approved"` THEN
    `wait_condition(_stakeholder_approved or cancelled)`. Consume `_stakeholder_approved=False`
    after. Then the merge loop, then side-effects projection, then `break`. Cancel handled at both
    waits. (GOTCHA-GDA-DUAL-SIGNAL, GOTCHA-GDA-CANCEL-TWO-SITES)
11. **No cancel re-check** between the merge loop and `_project_per_app_side_effects`; the wave
    proceeds to synthesis even if cancel arrived during merge_blocked. (GOTCHA-MERGE-CANCEL-FALLTHROUGH)
12. **G-DA reject:** reset `_stakeholder_approved=False`; `_rework_iterations_gda += 1`; if
    `> MAX_REWORK_ITERATIONS (3)` → `_status=FAILED`, `_current_step="max-rework-exceeded-gda"`,
    **return `"failed"` (no raise)**; else `_merge_capability_lineage_row_rework(gate_id)` →
    `_per_app_pipeline(rework=True)` gather → overwrite `per_app_results` → loop.
    (GOTCHA-GDA-MAXREWORK)
13. **`_project_per_app_side_effects`** fans out `persist_rationalization_side_effects` per app
    with `tier_1_approved = app_id in self._tier1_approved_apps`, `gather(return_exceptions=True)`,
    logs and swallows failures. Runs ONLY post-G-DA-merge. (GOTCHA-SIDEEFFECTS-BESTEFFORT/AFTER-MERGE)
14. **Wave outcome synthesis** dispatch: `input_artifacts=[]`,
    `optional_input_artifacts=candidate_bundle_paths` (the `dispositions/{portfolio}/{app}/
    disposition-output.json` set), context carries `per_app_artifact_refs` +
    `disposition_output_bundle_refs` + `wave_level_artifact_refs`. Resolve→validate→commit→
    commit-companions. (GOTCHA-SYNTH-OPTIONAL-INPUTS)
15. **Terminal routing:** check `workflow.patched("wave-arch-coordinator-v1")` FIRST → handoff,
    set COMPLETED/100/step=terminal, return terminal (UNCONDITIONALLY COMPLETED even on
    start-failed). Else check `workflow.patched("wave-rationalization-architecture-dispatch-v1")`
    → `_execute_architecture_data_fanout`, map `{completed,dispatched}→COMPLETED` else FAILED,
    step=`"architecture-dispatched"` iff dispatched else terminal, return raw terminal. Else
    default → COMPLETED/100/step="completed"/return "completed". Two SEPARATE `if`s in this order.
    (GOTCHA-ARCH-ARM-ORDER, GOTCHA-ARCH-ARM2-STATUS-MAP, GOTCHA-ARCH-TERMINAL-COMPLETED-ALWAYS)
16. **`_handoff_to_architecture_coordinator`:** id `f"wave-architecture-{wave}"`;
    `start_child_workflow("WaveArchitectureWorkflow", …, parent_close_policy=ABANDON)`; on start
    exception → return `"architecture-coordinator-start-failed"` (early); else best-effort
    `update_wave_architecture_workflow_id` (`aid=persist-arch-coordinator-id-{wave}`) whose failure
    is logged-and-ignored; return `"architecture-coordinator-started"`. Copies `app_ids`/
    `fixture_scenarios`. Never raises; never awaits child completion.
    (GOTCHA-HANDOFF-ABANDON/CHILD-NOT-AWAITED/NAME-STRING/DETERMINISTIC-ID/INPUT-COPIES/PERSIST-BESTEFFORT)
17. **Every patch string reproduced verbatim** (§F). **Every `dispatch_agent_task` sets both
    `timeout_seconds=3600` and 1h `start_to_close_timeout`** (GOTCHA-DISPATCH-TIMEOUT-DUAL). All
    commits flow through `_commit_artifact` gated on `"wave-rationalization-batch-writes-v1"`
    (GOTCHA-COMMIT-PATCH).
18. **Determinism:** all timestamps `_now_iso()`; `tier1_approvals` and pre-review tier1 context
    iterate `sorted(self._tier1_approval_records)`; no wall clock / random anywhere.
