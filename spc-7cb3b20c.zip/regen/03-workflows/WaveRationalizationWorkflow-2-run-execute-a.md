# `WaveRationalizationWorkflow` — `run()` + `_execute()` part A (ATOMIC regeneration spec)

> **Source of truth:** `temporal/olympus_workflows/workflows/wave_rationalization.py`
> (6129 lines, HEAD 7cb3b20c). Every `wave_rationalization.py:line` citation below is against
> that file.
>
> **THIS FILE OWNS LINES 1238–2384.** That is: the entire `@workflow.run run()` method
> (1238–1344) and the **first half** of `_execute()` (1346–2384, up to the start of the PRA
> rework re-dispatch). `_execute()` continues past 2384 in sibling files (the PRA rework
> re-dispatch tail, the per-app disposition fan-out, the G-DA loop, wave-outcome synthesis,
> the Architecture/Data dispatch hold).
>
> ⚠️ **REFRESH NOTE (HEAD 7cb3b20c vs old 5969-line baseline):** the file grew to 6129 lines.
> `run()` (1238–1344) and `__init__` (1087–1236) are **byte-identical** to the prior baseline —
> only `_execute` Sequence-2 and the G-RR loop changed, and every helper/signal moved down ~145
> lines. The behavioral deltas in MY range: (1) **NEW** empty-PRA-plan hard-fail guard
> (`_primary_output_is_empty` + patch `wave-rationalization-pra-nonempty-v1`, `:1906-1919`);
> (2) **NEW** rat-cap persist read-back warning (patch
> `wave-rationalization-ratcap-persist-readback-v1`, `:2002-2043`, captures `persist_out`);
> (3) **NEW** `_primary_output_is_empty` static helper (`:5022-5055`); (4) G-RR pre-review now
> passes `optional_evidence_paths=grr_pre_review_optional` (the `shared-identity-report.json`
> companion, `:2247,2255,2271`) and `_run_gate_pre_review` gained an `optional_evidence_paths`
> kwarg (`:5579`). Sibling-spec deltas (not in my range but flagged for cross-ref): the new
> **`Build` disposition** routes to a new `build` factory bucket in `_build_factory_routing`,
> and `_run_gate_pre_review` threads `optional_input_artifacts`. All path:line citations below
> are refreshed to HEAD.
> Helper methods (`_set_step`, `_wait_for_gate`, `_open_gate_pr`, `_commit_artifact`,
> `_commit_output_files`, `_primary_output_content`, `_validate_artifact_or_warn`,
> `_run_gate_pre_review`, `_reconcile_and_merge_with_retry_loop`, `_execution_ctx`,
> `_register_gate_key`), the signal handlers, the queries, and `__init__` live elsewhere in
> the file (and are owned by sibling specs), but because they are **load-bearing for the
> control flow and gate routing in my range**, I reproduce their bodies (or contracts) here
> in §1–§3 and §6 so a rebuild of lines 1238–2250 is self-contained.

---

## 0. CRITICAL inheritance fact — this workflow does NOT extend `LineWorkflowBase`

```text
@workflow.defn                                         # wave_rationalization.py:1077
class WaveRationalizationWorkflow(HILSignalsMixin):     # wave_rationalization.py:1078
```

⚠️ **GOTCHA-INHERIT (read `_HILSignalsMixin.md`, NOT `_LineWorkflowBase.md`, for the
inherited surface):** unlike the seven per-app line workflows, `WaveRationalizationWorkflow`
extends **`HILSignalsMixin` directly** (`wave_rationalization.py:1078`), **not**
`LineWorkflowBase`. Consequences a rebuild MUST honor:

1. It inherits the **8 HIL state vars** + **6 HIL signals** (`approve_plan`,
   `provide_plan_feedback`, `approve_research`, `provide_feedback`, `approve`,
   `cancel_workflow`) + helpers (`reset_*`, `is_*_decision_received`) from `HILSignalsMixin`
   (see `_HILSignalsMixin.md`). The only one actually consumed in my scope is **`self.cancelled`**
   (set by `cancel_workflow`), which gates `_wait_for_gate`'s and the merge loop's
   `wait_condition`.
2. It does **NOT** inherit any of `LineWorkflowBase`'s engine helpers. It **re-implements
   its own** `_set_step`, `_execution_ctx`, `_wait_for_gate` (analog of base
   `_wait_for_gate_decision`), `_run_gate_pre_review`, `_reconcile_and_merge_with_retry_loop`,
   `gate_approved`, `gate_rejected`, `merge_retry`, `get_status`. The docstrings explicitly
   say "inlined port … because WaveRationalizationWorkflow deliberately doesn't inherit from
   LineWorkflowBase" (`wave_rationalization.py:5583-5586`, `5695-5699`, `4848-4851`). A
   rebuild MUST define these methods **on this class**, not assume they come from a base.
3. Its `_gate_decisions` / `_gate_decisions_consumed` are **per-gate-key dicts**
   (`dict[str, list]` / `dict[str, int]`), NOT the flat list-and-int the base uses. This is a
   genuine behavioral divergence (see §1, GOTCHA-S-DICT).
4. Its gate-decision routing is **by gate-row UUID** via `_gate_id_to_key`, with a
   **pre-arrival buffer** `_pending_signals_by_gate_id` — the base routes by a flat cursor.
5. It overrides `merge_retry` / `gate_approved` / `gate_rejected` as fresh `@workflow.signal`
   methods on this class (not inherited from base — there is no base). No GOTCHA-SIG0
   duplicate-registration concern here precisely *because* there is no base defining them.

---

## 1. STATE — every instance var (set in `__init__`, `wave_rationalization.py:1087-1236`)

`__init__` calls `super().__init__()` **first** (`:1088`) so the 8 `HILSignalsMixin` vars
(`approved`, `plan_approved`, …, `cancelled`) are initialized. Then it sets the following.
**Vars used or mutated within my scope (1238–2250) are flagged ★USED-IN-SCOPE.** The others
are listed for completeness (init contract) but mutate only in sibling-owned code.

| Var | Type | Initial | Line | Mutated by → value | In scope? |
|-----|------|---------|------|---------------------|-----------|
| `_wave_id` | `str` | `""` | 1089 | `run()` → `input.wave_id` (`:1245`) | ★USED-IN-SCOPE |
| `_portfolio_id` | `str` | `""` | 1092 | `run()` → `input.portfolio_id` (`:1246`); **gates `_execution_ctx`** (returns `None` if empty) | ★USED-IN-SCOPE |
| `_status` | `WorkflowStatus` | `PENDING` | 1093 | `run()`→`RUNNING`(`:1244`)/`FAILED`(`:1261`); `_wait_for_gate`→`WAITING_FOR_SIGNAL`/`CANCELLED`/`RUNNING`; `_execute` rework→`FAILED`(`:2294`) | ★USED-IN-SCOPE |
| `_current_step` | `str` | `""` | 1094 | `run()`→`"failed"`(`:1262`); `_set_step`→`step`; `_execute` rework→`"max-rework-exceeded-grr"`(`:2295`) | ★USED-IN-SCOPE |
| `_progress_pct` | `float` | `0.0` | 1095 | `_set_step`→`clamp(progress,0,100)` | ★USED-IN-SCOPE |
| `_pending_gate` | `GateType\|None` | `None` | 1096 | `_wait_for_gate`→`GateType(gate_key)` then `None` | ★USED-IN-SCOPE (via `_wait_for_gate`) |
| `_started_at` | `str` | `""` | 1097 | `run()`→`_now_iso()` (`:1247`) | ★USED-IN-SCOPE |
| `_updated_at` | `str` | `""` | 1098 | `run()`(`:1248,1263`); `_set_step`; `_wait_for_gate`; signals; many | ★USED-IN-SCOPE |
| `_gate_decisions` | `dict[str, list[tuple]]` | `{}` | 1106 | `gate_approved`/`gate_rejected` append 5-tuple to `[gate_key]`; `_register_gate_key` flushes buffer; consumed by `_wait_for_gate` | ★USED-IN-SCOPE (G-RR) |
| `_gate_decisions_consumed` | `dict[str, int]` | `{}` | 1107 | `_wait_for_gate` → `[gate_key]=consumed+1` | ★USED-IN-SCOPE |
| `_gate_id_to_key` | `dict[str, str]` | `{}` | 1116 | `_register_gate_key` → `[gate_id]=gate_key` | ★USED-IN-SCOPE (via `_register_gate_key("G-RR")`) |
| `_pending_signals_by_gate_id` | `dict[str, list[tuple[GateStatus,str,str]]]` | `{}` | 1128 | `gate_approved`/`gate_rejected` buffer on key-miss; `_register_gate_key` pops+flushes | ★USED-IN-SCOPE (via `_register_gate_key`) |
| `_stakeholder_approved` | `bool` | `False` | 1133 | `stakeholder_approved` (non-tier1 scope) → `True` | no (G-DA, sibling) |
| `_stakeholder_info` | `str` | `""` | 1134 | `stakeholder_approved` → text | no |
| `_tier1_approval_records` | `dict[str,dict[str,str]]` | `{}` | 1150 | `stakeholder_approved` (tier1) per app | no (read by `_run_gate_pre_review` for G-DA only) |
| `_tier1_approved_apps` | `set[str]` | `set()` | 1151 | `stakeholder_approved` (tier1) | no |
| `_rework_iterations_grr` | `int` | `0` | 1153 | `_execute` G-RR reject → `+= 1` (`:2292`) | ★USED-IN-SCOPE |
| `_rework_iterations_gda` | `int` | `0` | 1154 | sibling (G-DA loop) | no |
| `_rework_feedback` | `dict[str, dict]` | `{}` | 1155 | `_wait_for_gate`: `pop` on approve, set structured dict on reject; read by `_execute` (`:2308,2347`) | ★USED-IN-SCOPE |
| `_approval_feedback` | `dict[str, dict]` | `{}` | 1170 | `_wait_for_gate`: set/pop on approve, pop on reject | ★USED-IN-SCOPE (via `_wait_for_gate`) |
| `_validation_warnings` | `dict[str, list[str]]` | `{}` | 1178 | `_validate_artifact_or_warn` → append; **NEW** rat-cap-persist read-back → append (`:2028`); read into G-RR evidence (`:2219`) | ★USED-IN-SCOPE |
| `_merge_retry_signalled` | `bool` | `False` | 1183 | `merge_retry`→`True`; `_reconcile_and_merge_with_retry_loop`→`False` before block | ★USED-IN-SCOPE (via merge loop) |
| `_architecture_child_handles` | `list[tuple[str,Any]]` | `[]` | 1197 | dispatch path / `cancel_all_children` | no (sibling) |
| `_cancel_all_children_requested` | `bool` | `False` | 1202 | `cancel_all_children` → `True` | no |
| `_dispatch_received` | `bool` | `False` | 1208 | `dispatch_architecture*` → `True` | no (sibling hold) |
| `_dispatch_payload` | `DispatchArchitecturePayload\|None` | `None` | 1209 | dispatch signals → normalized | no |
| `_dispatch_status` | `dict[str, DispatchTargetStatus]` | `{}` | 1212 | sibling fan-out | no |
| `_pending_dispatch_entries` | `list[PendingDispatchEntry]` | `[]` | 1217 | sibling (pre-dispatch hold) | no |
| `_pending_target_dispatch_entries` | `list[PendingTargetDispatchEntry]` | `[]` | 1224 | sibling | no |
| `_v2_dispatch_meta` | `dict[str,dict[str,str]]` | `{}` | 1231 | dispatch signals → `_extract_v2_metadata` | no |
| `_pending_retries` | `list[RetryTargetDispatchPayload]` | `[]` | 1236 | `retry_target_dispatch` → append | no |

> ⚠️ **GOTCHA-S-DICT (per-gate-key decision queues — NOT the base flat cursor):**
> `_gate_decisions` is `dict[str, list[tuple]]` keyed by gate_key string ("G-RR" / "G-DA")
> (`:1100-1107`), and `_gate_decisions_consumed` is `dict[str, int]`. This is **different from
> `LineWorkflowBase`** (flat `list` + single `int`). The reason (per the source comment
> `:1100-1102`): G-RR and G-DA decisions must not collide if both gates somehow have activity
> in flight. A rebuild MUST use **per-key** queues and per-key consume cursors, or a G-DA
> decision could be consumed by a waiting G-RR (and vice versa).
>
> ⚠️ **GOTCHA-S-UUID (gate routing is by UUID, with a pre-arrival buffer):** signals carry
> `signal.gate_id` (a **UUID**, not a prefixed string). The handlers map UUID→key via
> `_gate_id_to_key` (`:1109-1116`). If the UUID isn't mapped yet (signal raced ahead of
> `create_gate_record`), the decision is buffered into `_pending_signals_by_gate_id` keyed by
> UUID (`:1118-1130`) and **flushed in arrival order** by `_register_gate_key` once the gate
> record exists. The source comment (`:1112-1115`) records the original bug: pre-0.2 code
> tried to parse a prefix out of `gate_id`, but gate_ids are UUIDs, so **every signal was
> dropped** and the workflow hung in `_wait_for_gate` forever. A rebuild MUST route by
> UUID-lookup + buffer-and-flush, never by string-prefix parse.

---

## 2. SIGNALS / QUERIES consumed by code in my scope (defined elsewhere; contracts here)

My scope (1238–2250) does not *define* signals, but its control flow **depends on** these.
Full handler bodies are owned by a sibling spec; the load-bearing contracts:

### 2.1 `cancel_workflow(self)` — inherited from `HILSignalsMixin` (`signals.py:75-78`)
Sets `self.cancelled = True`. ⚠️ This is the ONLY way `_wait_for_gate`'s and the merge loop's
`wait_condition` return without a positive decision. (`_HILSignalsMixin.md` GOTCHA-1/5.)

### 2.2 `gate_approved(self, signal: GateApprovedSignal)` — `wave_rationalization.py:5792-5820`
`async def`. Builds `entry = (GateStatus.APPROVED, signal.approved_by, signal.justification,
None, [])` (5-tuple, `:5806-5812`). Looks up `gate_key = self._gate_id_to_key.get(signal.gate_id)`
(`:5813`). **BRANCH:** if `gate_key is None` (`:5814`) → buffer `entry` into
`_pending_signals_by_gate_id[signal.gate_id]` (`:5815-5817`); **else** → append to
`_gate_decisions[gate_key]` (`:5819`). Always bumps `_updated_at` (`:5820`).
⚠️ approvals hard-code `reason_category=None`, `card_decisions=[]` even though the signal may
carry a `justification`; the justification text *is* carried (position 3) and `_wait_for_gate`
re-purposes it as "approval guidance".

### 2.3 `gate_rejected(self, signal: GateRejectedSignal)` — `wave_rationalization.py:5822-5844`
`async def`. `card_decisions = list(getattr(signal, "card_decisions", []) or [])` (`:5828`,
defensive); `reason_category = getattr(signal, "reason_category", None)` (`:5829`). Builds
`entry = (GateStatus.REJECTED, signal.rejected_by, signal.reason, reason_category,
card_decisions)` (`:5830-5836`). Same UUID-lookup + buffer/append BRANCH as `gate_approved`
(`:5837-5843`). Bumps `_updated_at`.

### 2.4 `merge_retry(self, signal: GateMergeRetrySignal)` — `wave_rationalization.py:5768-5772`
`async def`. Sets `self._merge_retry_signalled = True` (unconditional) and `_updated_at`.
Consumed by `_reconcile_and_merge_with_retry_loop`'s wait (`:5758-5759`).

### 2.5 `get_status(self)` query — `wave_rationalization.py:6111-6122`
`@workflow.query`, read-only. Returns `WorkflowStatusResponse(workflow_id=…,
status=self._status, current_line=AssemblyLine.RATIONALIZATION, current_step=…, progress_pct=…,
pending_gate=self._pending_gate, started_at=…, updated_at=…)`. A dashboard polling during the
G-RR wait sees `status=WAITING_FOR_SIGNAL`, `pending_gate=GateType.G_RR`.

> ⚠️ **GOTCHA-SIG-NO-RESET:** `_register_gate_key(gate_id, gate_key)` (`:5774-5790`) is what
> flushes the pre-arrival buffer. It does `self._gate_id_to_key[gate_id] = gate_key`, then
> `pending = self._pending_signals_by_gate_id.pop(gate_id, [])`, and **only if `pending`** does
> `self._gate_decisions.setdefault(gate_key, []).extend(pending)` + bump `_updated_at`. My
> scope calls `_register_gate_key(gate_record.gate_id, "G-RR")` at `:2108` immediately after
> `create_gate_record`. A rebuild MUST call it at that exact site, or buffered early signals
> never reach the queue and `_wait_for_gate("G-RR")` hangs.

---

## 3. Helper methods called from my scope (bodies reproduced for self-containment)

These methods are defined later in the file (sibling-owned) but are invoked inside 1238–2250.
Their exact behavior is required for parity of my control flow. Reproduced verbatim-as-pseudocode.

### 3.1 `_set_step(self, step, progress)` — `wave_rationalization.py:5400-5403`
```text
async def _set_step(self, step, progress):
    self._current_step = step                             # :5401
    self._progress_pct = max(0.0, min(100.0, progress))   # :5402  ← CLAMPS to [0,100]
    self._updated_at = _now_iso()                         # :5403
```
⚠️ **GOTCHA-SETSTEP (no DB write, clamps):** unlike `LineWorkflowBase._set_step`, this
override does **NOT** call `_update_app_status` (wave-scoped, no single app). It only mutates
local state and **clamps progress to [0,100]**. A rebuild must clamp and must NOT emit a DB
status write here.

### 3.2 `_execution_ctx(self, step_id, *, app_id="", gate_id="", input_artifact_paths=None)` — `:4838-4863`
```text
def _execution_ctx(self, step_id, *, app_id="", gate_id="", input_artifact_paths=None):
    if not self._portfolio_id:               # :4853  BRANCH
        return None                          # :4854  ← best-effort no-op
    return StepExecutionContext(
        portfolio_id=self._portfolio_id,
        line_id="rationalization",           # :4857  ← HARD-CODED literal (not kebab of label)
        step_id=step_id,
        app_id=app_id,                       # :4859  default "" (NOT None-sentinel)
        wave_id=self._wave_id,
        gate_id=gate_id,
        input_artifact_paths=list(input_artifact_paths or []),
    )
```
⚠️ **GOTCHA-EC-WAVE:** `line_id` is the **hard-coded string `"rationalization"`** (`:4857`),
not derived from a `LINE_LABEL`. `app_id`/`gate_id` default to `""` (not `None` sentinel). A
rebuild must use the literal and `if not self._portfolio_id: return None`.

### 3.3 `_validate_artifact_or_warn(self, *, artifact_filename, raw_content, wave_id, app_id="")` — `:4865-4939`
```text
async def _validate_artifact_or_warn(self, *, artifact_filename, raw_content, wave_id, app_id=""):
    if not raw_content:                       # :4890  BRANCH
        return                                # :4891  ← empty content = no-op
    try:
        result = await workflow.execute_activity(
            validate_artifact_against_schema,
            ValidateArtifactInput(artifact_filename=artifact_filename, raw_content=raw_content),
            start_to_close_timeout=timedelta(seconds=30),    # :4899
            retry_policy=RETRY_POLICIES["transient"])        # :4900
    except ActivityError as exc:               # :4902  BRANCH (schema-missing/packaging defect)
        workflow.logger.warning(...); return   # :4907-4916  ← advisory: NEVER fatal
    if not result.errors:                      # :4917  BRANCH
        return                                 # :4918  ← clean
    warning_key = app_id or f"wave-{wave_id}"  # :4919
    if result.validated:                       # :4927  BRANCH
        workflow.logger.warning(f"{artifact_filename} schema validation failed", ...)  # :4928
    else:                                      # :4932
        workflow.logger.warning(f"{artifact_filename} could not be parsed", ...)       # :4933
    self._validation_warnings.setdefault(warning_key, []).extend(result.errors)        # :4937
```
Activity: `validate_artifact_against_schema` — `ValidateArtifactInput`; **30s**; `transient`.
⚠️ **GOTCHA-VAL (advisory, never blocks):** an `ActivityError` (schema missing / NonRetryable)
is caught and **swallowed** (`:4801-4815`); only `result.errors` populate
`_validation_warnings`. The warning key is `app_id` if given else `wave-{wave_id}`. A rebuild
must keep this advisory (non-blocking) and accumulate errors keyed exactly this way.

### 3.4 `_primary_output_content(result, primary_filename)` — `@staticmethod`, `:4966-5019`
```text
@staticmethod
def _primary_output_content(result, primary_filename):
    if result is None: return ""              # :4995
    files = getattr(result, "output_files", None) or []   # :4997
    for out_file in files:                    # :4998  LOOP
        if isinstance(out_file, dict):        # :4999  BRANCH (dict vs dataclass)
            raw_path = out_file.get("path","") or ""; content = out_file.get("content","") or ""
        else:
            raw_path = getattr(out_file,"path","") or ""; content = getattr(out_file,"content","") or ""
        if not raw_path: continue             # :5005
        if raw_path.rsplit("/",1)[-1] == primary_filename:   # :5010  BRANCH (basename match)
            return content                    # :5011
    artifacts = getattr(result, "output_artifacts", None) or []   # :5016
    if artifacts: return artifacts[0] or ""   # :5017-5018  ← fallback to narrative
    return ""                                 # :5019
```
⚠️ **GOTCHA-POC (workspace file beats narrative):** resolves the committed content from
`output_files` by **basename** match, falling back to `output_artifacts[0]` (agent narrative)
only if the file is absent. The bug fix at `:4985-4993` records why: committing
`output_artifacts[0]` straight to a `.json` path wrote *prose narrative* into JSON artifacts.
A rebuild must prefer the workspace file by basename.

### 3.4b ⚠️ NEW — `_primary_output_is_empty(raw)` — `@staticmethod`, `:5022-5055`
```text
@staticmethod
def _primary_output_is_empty(raw) -> bool:
    import json                               # :5041  (local import, sandbox rule)
    if not raw or not raw.strip(): return True            # :5043-5044  blank/whitespace
    try:
        parsed = json.loads(raw)              # :5046
    except (ValueError, TypeError):           # :5047  BRANCH (non-JSON prose)
        return True                           # :5050
    if parsed is None: return True            # :5051-5052
    if isinstance(parsed, (dict, list)) and len(parsed) == 0: return True   # :5053-5054
    return False                              # :5055
```
⚠️ **GOTCHA-EMPTY-PLAN (NEW since baseline — the Wave-1 rat-cap break guard):** "empty" =
blank/whitespace OR JSON that parses to `{}`/`[]`/`null` OR a non-JSON narrative string (the
primary artifact is contractually JSON, so prose where JSON is expected counts as empty). This
helper gates the **NEW** hard-fail at `:1906-1919` (see §6.2). A rebuild MUST treat all four of
those as empty, and do the `json.loads` inside a `try` (a non-JSON string is empty, never an
exception out of this helper).

### 3.5 `_commit_artifact(self, repo, branch, path, content, message, *, step_id="commit-redundancy-artifacts", app_id="")` — `:5057-5100`
```text
async def _commit_artifact(self, repo, branch, path, content, message, *, step_id="commit-redundancy-artifacts", app_id=""):
    if workflow.patched("wave-rationalization-batch-writes-v1"):   # :5068  BRANCH (patch gate)
        await workflow.execute_activity(
            write_artifacts_batch,
            WriteArtifactsBatchInput(repo=repo, branch=branch,
                files=[(path, content or "{}")],                   # :5074  ← defaults empty to "{}"
                commit_message=message,
                execution_context=self._execution_ctx(step_id, app_id=app_id)),
            start_to_close_timeout=timedelta(seconds=120),          # :5081
            retry_policy=RETRY_POLICIES["transient"])               # :5082
    else:                                                           # :5084  (pre-patch path)
        await workflow.execute_activity(
            write_artifact,
            WriteArtifactInput(repo=repo, branch=branch, path=path, content=content or "{}",
                commit_message=message,
                execution_context=self._execution_ctx(step_id, app_id=app_id)),
            start_to_close_timeout=timedelta(seconds=60),           # :5098
            retry_policy=RETRY_POLICIES["transient"])               # :5099
```
⚠️ **GOTCHA-COMMIT (patch-gated single-file vs batch + `or "{}"`):** under patch
`"wave-rationalization-batch-writes-v1"` it uses `write_artifacts_batch` (120s); the pre-patch
replay path uses `write_artifact` (60s). Both default `content or "{}"`. A rebuild MUST
reproduce the patch string **verbatim** and keep both timeouts.

### 3.6 `_commit_output_files(self, repo, branch, result, *, primary_path, wave_id, app_id="", step_id="commit-redundancy-artifacts", commit_message_prefix)` — `:5102-5176`
```text
async def _commit_output_files(self, repo, branch, result, *, primary_path, wave_id, app_id="", step_id="commit-redundancy-artifacts", commit_message_prefix):
    if not result or not getattr(result, "output_files", None):   # :5132  BRANCH
        return
    wave_prefix = f"rationalization/wave-{wave_id}"                # :5134
    for out_file in result.output_files:                          # :5135  LOOP
        # dict-or-dataclass extract (same as POC)                 # :5136-5141
        if not raw_path or not content: continue                  # :5142  BRANCH (skip empty)
        if raw_path.startswith(wave_prefix):     final_path = raw_path                 # :5148 BRANCH
        elif "/" not in raw_path:                # bare filename  # :5150 BRANCH
            final_path = f"{wave_prefix}/{app_id}/{raw_path}" if app_id else f"{wave_prefix}/{raw_path}"  # :5152-5155
        else:                                    final_path = raw_path                 # :5156-5157
        if final_path == primary_path: continue   # :5158  BRANCH (caller handled primary)
        try:
            await self._commit_artifact(repo, branch, final_path, content,
                f"{commit_message_prefix}: {final_path.rsplit('/',1)[-1]}", step_id=step_id, app_id=app_id)  # :5162-5170
        except Exception:                          # :5171  BRANCH (best-effort)
            workflow.logger.warning("Failed to commit output_file ... (non-fatal)", ...)  # :5172
```
⚠️ **GOTCHA-COF (companion files, best-effort, skip primary):** commits every *other* output
file (markdown companions etc.), path-normalizing bare filenames under the wave/app dir, and
**skips the file equal to `primary_path`** (the caller already committed it). Per-file failures
are swallowed. A rebuild must reproduce the path-normalization branches and the
skip-primary + swallow-failure semantics.

### 3.7 `_open_gate_pr(self, repo, branch, input, gate, title, body)` — `:5178-5201`
```text
async def _open_gate_pr(self, repo, branch, input, gate, title, body):
    return await workflow.execute_activity(
        create_pr,
        CreatePRInput(repo=repo, source_branch=branch, target_branch="main",   # :5192  always main
            title=title, body=body,
            execution_context=self._execution_ctx(f"create-{gate.lower()}-pr")),  # :5195-5197
        start_to_close_timeout=timedelta(seconds=60),    # :5199
        retry_policy=RETRY_POLICIES["transient"])        # :5200
```
Returns `CreatePRResult` (`.pr_number`, `.pr_url`). Activity `create_pr`; **60s**; `transient`.
⚠️ Unlike base `_create_gate_pr`, this sets **no labels**. Targets `main`. Step id is
`create-{gate.lower()}-pr` → `create-g-rr-pr`.

### 3.8 `_wait_for_gate(self, gate_key)` — `wave_rationalization.py:5405-5480` ★CORE for my routing
This is the wave-specific analog of base `_wait_for_gate_decision`. **Reproduced in full**
because my scope's G-RR routing is entirely driven by its return value + side effects.
(Body unchanged from baseline; only line numbers shifted +147.)
```text
async def _wait_for_gate(self, gate_key) -> str:
    # set pending-gate enum if the key is a valid GateType value, else None
    self._pending_gate = GateType(gate_key) if gate_key in GateType._value2member_map_ else None  # :5411 BRANCH
    self._status = WorkflowStatus.WAITING_FOR_SIGNAL                # :5412
    self._updated_at = _now_iso()                                   # :5413

    self._gate_decisions.setdefault(gate_key, [])                   # :5415
    self._gate_decisions_consumed.setdefault(gate_key, 0)           # :5416
    consumed = self._gate_decisions_consumed[gate_key]              # :5417  ← snapshot cursor

    await workflow.wait_condition(                                  # :5419
        lambda: len(self._gate_decisions[gate_key]) > consumed or self.cancelled)  # :5420 ★PREDICATE

    if self.cancelled:                                             # :5422  BRANCH A
        self._status = WorkflowStatus.CANCELLED                    # :5423
        self._updated_at = _now_iso()
        return "cancelled"                                         # :5425  ← WITHOUT consuming

    entry = self._gate_decisions[gate_key][consumed]               # :5426
    if len(entry) == 5:                                            # :5430  BRANCH B (5-tuple)
        decision, actor, reason, reason_category, card_decisions = entry          # :5431
    else:                                                          # :5432  (3-tuple legacy)
        decision, actor, reason = entry[0], entry[1], entry[2]; reason_category=None; card_decisions=[]  # :5433-5435
    self._gate_decisions_consumed[gate_key] = consumed + 1         # :5436  ← advance cursor
    self._pending_gate = None                                      # :5437
    self._status = WorkflowStatus.RUNNING                          # :5438
    self._updated_at = _now_iso()

    if decision == GateStatus.APPROVED:                            # :5440  BRANCH C (approve)
        self._rework_feedback.pop(gate_key, None)                  # :5441  ← clear rework feedback
        stripped_reason = (reason or "").strip()                   # :5447
        if stripped_reason:                                        # :5448  BRANCH D (approve-with-guidance)
            self._approval_feedback[gate_key] = {                  # :5449-5454
                "gate": gate_key, "approved_by": actor,
                "guidance": stripped_reason, "approved_at": _now_iso()}
        else:                                                      # :5455
            self._approval_feedback.pop(gate_key, None)            # :5456  ← clean approval clears guidance
        return "approved"                                          # :5457

    # else: rejection
    self._approval_feedback.pop(gate_key, None)                    # :5462  ← walk back prior approval guidance
    rework_targets = rework_targets_from_card_decisions(card_decisions)   # :5470
    self._rework_feedback[gate_key] = {                            # :5471-5479
        "gate": gate_key, "rejected_by": actor, "reason": reason,
        "reason_category": reason_category, "card_decisions": card_decisions,
        "rework_targets": rework_targets, "rejected_at": _now_iso()}
    return "rejected"                                              # :5480
```
**Returns one of `"cancelled"` / `"approved"` / `"rejected"`.** Side effects per branch:
- **cancelled** (A): `_status=CANCELLED`; cursor NOT advanced.
- **approved** (C/D): cursor advanced; `_rework_feedback[gate_key]` popped; `_approval_feedback`
  set if reason non-blank else popped.
- **rejected**: cursor advanced; `_approval_feedback` popped; `_rework_feedback[gate_key]` set
  with a **7-key dict** that ALSO includes `"rework_targets"` (computed by
  `rework_targets_from_card_decisions(card_decisions)`, `:5470`).

> ⚠️ **GOTCHA-WG-WAVE1 (cursor pattern, per-key):** snapshot `consumed` BEFORE the wait
> (`:5417`); predicate is `len(self._gate_decisions[gate_key]) > consumed or self.cancelled`
> (`:5420`). Race-safe against signals that arrive before `_wait_for_gate` is called (they were
> buffered/flushed by §2's handlers). A rebuild MUST snapshot-then-index-then-advance
> **per gate_key**.
> ⚠️ **GOTCHA-WG-WAVE2 (`_pending_gate` set only for real GateType values):** `:5411` guards
> `gate_key in GateType._value2member_map_` — for "G-RR"/"G-DA" this resolves to the enum; an
> unknown key would set `None`. A rebuild must reproduce this guarded set.
> ⚠️ **GOTCHA-WG-WAVE3 (the rework-targets enrichment):** unlike the base, the rejection branch
> computes `rework_targets` and stuffs it into the feedback dict (`:5470,5477`). This is what
> drives the **card-scoped rework boundary** in my scope (`:2308-2313`). A rebuild MUST compute
> and store `rework_targets`.
> ⚠️ **GOTCHA-WG-WAVE4 (does NOT bump `_rework_iterations_grr`):** the counter is bumped by the
> `_execute` rework loop on the `"rejected"` branch (`:2292`), NOT here. A rebuild must NOT
> increment inside `_wait_for_gate`.

### 3.9 ⚠️ CHANGED — `_run_gate_pre_review(self, gate_id, gate_type_value, evidence_paths, *, artifact_repo="", artifact_ref="", optional_evidence_paths=None)` — `:5571-5685`
Advisory AI pre-review, best-effort. **No `finally` ready-flip** (the caller flips).
⚠️ **SIGNATURE CHANGED since baseline:** gained a new keyword-only param
`optional_evidence_paths: list[str] | None = None` (`:5579`), threaded into the dispatch as
`optional_input_artifacts=list(optional_evidence_paths or [])` (`:5651`). Contract:
```text
async def _run_gate_pre_review(self, gate_id, gate_type_value, evidence_paths, *,
                               artifact_repo="", artifact_ref="", optional_evidence_paths=None):  # :5571-5580
    pre_review_context = {"gate_id": gate_id, "gate_type": gate_type_value}    # :5624-5627
    if gate_type_value == "G-DA":          # :5628  BRANCH — adds tier1_approvals + downstream_artifact_kinds
        ...                                # (G-DA only; not exercised by my G-RR caller)
    try:
        pre_review_result = await workflow.execute_activity(
            dispatch_agent_task,
            AgentTaskInput(skill_id="gate-pre-review", app_id="", wave_id=self._wave_id,
                task_type="gate-pre-review", input_artifacts=evidence_paths,
                optional_input_artifacts=list(optional_evidence_paths or []),     # :5651  ★NEW
                artifact_repo=artifact_repo, artifact_ref=artifact_ref, context=pre_review_context,
                execution_context=self._execution_ctx(f"ai-pre-review-{gate_type_value.lower()}",
                    gate_id=gate_id, input_artifact_paths=evidence_paths)),
            start_to_close_timeout=timedelta(minutes=10),     # :5661
            retry_policy=RETRY_POLICIES["transient"])         # :5662
        agent_markdown = pre_review_result.output_artifacts[0] if pre_review_result.output_artifacts else ""  # :5664-5668 BRANCH
        if not agent_markdown: raise ValueError("Gate pre-review produced no output")   # :5669-5670 BRANCH
        await workflow.execute_activity(store_gate_pre_review,
            StoreGatePreReviewInput(gate_id=gate_id, agent_output=agent_markdown),
            start_to_close_timeout=timedelta(seconds=30), retry_policy=RETRY_POLICIES["transient"])  # :5671-5679
    except Exception:                       # :5680  BRANCH (best-effort)
        workflow.logger.warning(f"Gate pre-review failed for {gate_type_value}; continuing ...")    # :5681
```
Activities: `dispatch_agent_task` (skill `gate-pre-review`, **10 min**, `transient`);
`store_gate_pre_review` (**30s**, `transient`). ⚠️ **GOTCHA-PR-WAVE (no `finally` ready-flip):**
this inlined version does **NOT** flip the gate ready-for-review (unlike base). The caller in
my scope does `mark_gate_ready_for_review` separately at `:2273-2278`. A rebuild must keep the
ready-flip in the **caller**, not in this helper.
⚠️ **GOTCHA-PR-WAVE-OPTIONAL (NEW — optional evidence):** `optional_evidence_paths` go into the
agent runtime's `optional_input_artifacts` so a missing file is *skipped* (404 = "not present
yet") instead of raising `FileNotFoundError` and taking down the whole pre-review. My G-RR
caller passes `optional_evidence_paths=grr_pre_review_optional` (the `shared-identity-report.json`
companion, which the rat-cap-rewritten PRA skill no longer always emits — `:2247,2255,2271`).
The G-DA caller (sibling) passes none. A rebuild MUST add this kwarg and route it to
`optional_input_artifacts`, or a wave whose PRA didn't emit the companion lands reviewers on an
empty AI-recommendation panel.

### 3.10 `_reconcile_and_merge_with_retry_loop(self, *, repo, pr_number, gate_id, merge_method="merge")` — `:5687-5762`
Inlined port of the base merge loop. **Reproduced in full** (called from my G-RR approve path).
(Body unchanged from baseline; only line numbers shifted +160.)
```text
async def _reconcile_and_merge_with_retry_loop(self, *, repo, pr_number, gate_id, merge_method="merge"):
    merge_failure_types = {"MergeConflict", "MergeDivergenceUnresolved", "MergeBranchProtectionRejected"}  # :5701-5705
    merge_ctx = self._execution_ctx(f"merge-pr-{pr_number}", gate_id=gate_id)   # :5707
    while True:                                                                 # :5711  ★LOOP
        try:
            await workflow.execute_activity(reconcile_and_merge_pr,
                MergePRInput(repo=repo, pr_number=pr_number, merge_method=merge_method, execution_context=merge_ctx),
                start_to_close_timeout=timedelta(seconds=60),      # :5721
                retry_policy=RETRY_POLICIES["git_merge"])          # :5722  3 attempts + non_retryable
            return                                                 # :5724  ← SUCCESS exits
        except (ActivityError, ApplicationError) as outer_exc:     # :5725  BRANCH
            inner = outer_exc
            while (not isinstance(inner, ApplicationError) and getattr(inner, "__cause__", None) is not None):  # :5727 LOOP unwrap
                inner = inner.__cause__                            # :5731
            if not isinstance(inner, ApplicationError): raise      # :5732-5733  ← can't unwrap → propagate
            failure_type = inner.type or ""                        # :5734
            if failure_type not in merge_failure_types: raise      # :5735-5736  ← not a merge error → propagate
            detail = {"failure_type": failure_type, "reason": str(inner), "pr_number": pr_number, "detected_at": _now_iso()}  # :5737-5742
            workflow.logger.warning("merge_blocked", extra={...})  # :5743-5750
            self._merge_retry_signalled = False                    # :5751  ★ reset BEFORE block
            await workflow.execute_activity(set_gate_merge_blocked, args=[gate_id, detail],   # :5752-5754 positional args
                start_to_close_timeout=timedelta(seconds=30), retry_policy=RETRY_POLICIES["transient"])  # :5755-5756
            await workflow.wait_condition(lambda: self._merge_retry_signalled or self.cancelled)  # :5758-5759 ★PREDICATE
            if self.cancelled: return                              # :5761-5762  ← cancel exits loop
            # loop back → retry merge
```
Activities per iteration: `reconcile_and_merge_pr` (**60s**, **`git_merge`** policy:
`maximum_attempts=3`, `non_retryable_error_types=["MergeConflict","MergeDivergenceUnresolved",
"MergeBranchProtectionRejected"]` — see `retry_policies.py:GIT_MERGE_RETRY_POLICY`); then on
structured merge error `set_gate_merge_blocked` (positional `args=[gate_id, detail]`, **30s**,
`transient`); then `wait_condition(merge_retry_signalled or cancelled)`. ⚠️ Same GOTCHAs as base
MR1–MR6: walk `__cause__` to find the `ApplicationError`; two re-raise escapes; reset
`_merge_retry_signalled=False` BEFORE the block; cancel returns cleanly; positional `args=`.

---

## 4. Module-level helper functions used in my scope (`wave_rationalization.py`)

These are pure module functions (deterministic; no `workflow.now()` except `_now_iso`).

- **`_now_iso()`** (`:134-135`): `return workflow.now().isoformat()`. Deterministic.
- **`_with_fixture_scenario(context, skill_id, fixture_scenarios)`** (`:998-1018`): returns
  `context` unchanged unless `fixture_scenarios.get(skill_id)` is truthy, in which case returns
  a shallow copy with `["fixture_scenario"]=scenario`. ⚠️ Prod passes an empty map → no-op.
  Threaded through **every** `AgentTaskInput.context` so `MockAgentRuntime` can resolve
  multi-fixture skills (DECISION-018).
- **`_with_context_priors(context, skill_id)`** (`async`, `:953-995`): wraps a
  `load_context_priors` activity (`LoadContextPriorsInput(skill_id)`, **10s**, `transient`),
  best-effort `try/except` (returns `context` unchanged on failure, `:978-984`). If
  `result.priors` non-empty, returns `dict(context)` + `["context_priors"]=priors`, else
  `context` unchanged. **Used only on the PRA dispatch** in my scope (sequential `:1857`,
  legacy parallel `:1774`).
- **`_business_logic_artifact(app_id)`** (`:768-776`): `f"discovery/{app_id}/business-logic.json"`.
- **`_business_logic_artifacts_for_wave(app_ids)`** (`:779-781`): list of the above per app.
- **`_ux_overlap_input_artifacts(app_ids)`** (`:784-803`): per app
  `[discovery/{a}/ux-accessibility.json, discovery/{a}/catalog.json]`.
- **`_portfolio_integration_input_artifacts(app_ids)`** (`:892-904`): per app
  `[discovery/{a}/catalog.json, discovery/{a}/structural-analysis.json]`.
- **`_portfolio_redundancy_input_artifacts(wave_id, app_ids)`** (`:907-924`):
  `[rationalization/wave-{w}/redundancy-matrix.json, …/integration-graph.json]` + per app
  `[…/{a}/intra-app-redundancy.json, discovery/{a}/business-logic.json]`.
- **`_cross_app_business_rule_input_artifacts(app_ids)`** (`:927-936`): business-logic per app.
- **`_build_rationalization_step_entry(title, skill_id, artifact_filename, result)`**
  (`:1021-1074`): builds an `evidence_data.steps` map entry; `output=result.output_artifacts[0]`
  (or `""`), `file_artifacts` from `result.output_files` (dict-or-dataclass extraction; skips
  empty `path`), `metadata` = 5 model/cost fields. Used to build `grr_steps` (`:2070-2111`).
- **`rework_targets_from_card_decisions(card_decisions)`** (`:683-721`): for each dict entry with
  `decision=="reject"`, map `artifact_type`→step_id (`_step_id_for_artifact`), fall back to
  `card_id` if it's a known step, then union `rework_targets_for(step_id)`; returns steps in
  `RATIONALIZATION_STEPS` insertion order. (Called inside `_wait_for_gate`, §3.8.)
- **`classify_failure(exc)`** (`:327-377`): walks the `__cause__`/`__context__` chain reading
  `activity_type`/`activity_name`/`_activity_type`; returns `"recoverable"` if a name is in
  `RECOVERABLE_FAILURE_ACTIVITIES`, `"terminal"` if in `TERMINAL_FAILURE_ACTIVITIES`,
  **else `"terminal"`** (safe default). Used in `run()`'s except (§5).

### Module constants used in scope
- `SKILLS` dict (`:384-464`): keys → `{"skill_id", "artifact"[, "companion_artifact"]}`. Scope
  reads `cross-app-redundancy` (`redundancy-analyzer`/`redundancy-matrix.json`),
  `compare-ux-overlap` (`compare-ux-overlap`/`ux-overlap-matrix.json`), `intra-app-redundancy`
  (`redundancy-analyzer`/`intra-app-redundancy.json`), `portfolio-integration-mapping`
  (`portfolio-integration-mapper`/`integration-graph.json`), `analyze-portfolio-redundancy`
  (`analyze-portfolio-redundancy`/`portfolio-redundancy-matrix.json` + companion
  `shared-identity-report.json`), `cross-app-business-rule-analysis`
  (`cross-app-business-rule-analyzer`/`business-rule-redundancy.json`).
- `STEP_WEIGHTS` dict (`:728-756`, asserts sum==100 at `:757`): the progress weights read by
  `_set_step` calls. Scope-relevant: `cross-app-redundancy=8.0`, `intra-app-redundancy=5.0`,
  `compare-ux-overlap=5.0`, `portfolio-integration-mapping=4.0`, `analyze-portfolio-redundancy=5.0`,
  `cross-app-business-rule-analysis=3.0`, `gate-review-rr=7.0`.
- `MAX_REWORK_ITERATIONS = 3` (`:759`): the G-RR/G-DA rework ceiling.

---

## 5. `run()` — CONTROL FLOW (`wave_rationalization.py:1238-1344`) — EXHAUSTIVE

```text
@workflow.run
async def run(self, input: WaveRationalizationInput) -> str:           # :1238-1239
    if isinstance(input, dict):                       # :1241  BRANCH 1 (dict-coercion)
        input = WaveRationalizationInput(**input)     # :1242

    self._status = WorkflowStatus.RUNNING             # :1244
    self._wave_id = input.wave_id                     # :1245
    self._portfolio_id = input.portfolio_id           # :1246
    self._started_at = _now_iso()                     # :1247
    self._updated_at = self._started_at               # :1248

    if not input.app_ids:                             # :1250  BRANCH 2 (empty-wave guard)
        raise ValueError(                             # :1251  ← raised BEFORE try; fails the run hard
            "WaveRationalizationWorkflow requires at least one app_id")

    wf_id = workflow.info().workflow_id               # :1253
    run_suffix = wf_id.rsplit("-", 1)[-1] if "-" in wf_id else wf_id[:8]   # :1254  BRANCH 3 (suffix derive)
    branch = f"olympus/rationalization/wave-{input.wave_id}/{run_suffix}"  # :1255
    workspace_key = f"wave-rationalization-{input.wave_id}-{run_suffix}"   # :1256

    try:                                              # :1258
        return await self._execute(input, branch, workspace_key)   # :1259  ← the whole pipeline
    except Exception as exc:                          # :1260  BRANCH 4 (failure handler)
        self._status = WorkflowStatus.FAILED          # :1261
        self._current_step = "failed"                 # :1262
        self._updated_at = _now_iso()                 # :1263
        classification = classify_failure(exc)        # :1277  → "recoverable" | "terminal"
        reason = str(exc)[:500]                        # :1278  ← truncate to 500 chars
        try:                                          # :1287  (best-effort persist)
            if classification == "recoverable":       # :1288  BRANCH 5
                await workflow.execute_activity(       # :1299-1308
                    persist_wave_failure,
                    PersistWaveFailureInput(wave_id=input.wave_id, reason=reason,
                        workflow_id=workflow.info().workflow_id),
                    start_to_close_timeout=timedelta(seconds=30),
                    retry_policy=RETRY_POLICIES["transient"])
                await workflow.execute_activity(       # :1312-1321  ← then flip to recoverable status
                    update_wave_status,
                    UpdateWaveStatusInput(wave_id=input.wave_id,
                        new_status="stuck-awaiting-recovery", reason=reason),
                    start_to_close_timeout=timedelta(seconds=30),
                    retry_policy=RETRY_POLICIES["transient"])
            else:                                     # :1322  BRANCH 6 (terminal)
                await workflow.execute_activity(       # :1323-1332
                    persist_wave_failure,
                    PersistWaveFailureInput(wave_id=input.wave_id, reason=reason,
                        workflow_id=workflow.info().workflow_id),
                    start_to_close_timeout=timedelta(seconds=30),
                    retry_policy=RETRY_POLICIES["transient"])
        except Exception:                             # :1333  BRANCH 7 (swallow secondary)
            workflow.logger.warning(                   # :1337-1343
                "persist_wave_failure swallowed secondary exception", extra={...})
        raise                                         # :1344  ← re-raise ORIGINAL exc to Temporal
```

**Branch inventory in `run()` (7):** dict-coercion (1241); empty-wave `raise` (1250); suffix
derive ternary (1254); outer `except Exception` (1260); `classification == "recoverable"`
(1288); `else` terminal (1322); inner `except Exception` swallow (1333).

**Activity calls in `run()`'s except (order depends on branch):**
- recoverable: `persist_wave_failure` (30s, `transient`) **then** `update_wave_status`
  (`new_status="stuck-awaiting-recovery"`, 30s, `transient`).
- terminal: `persist_wave_failure` only (30s, `transient`).

> ⚠️ **GOTCHA-RUN1 (empty-wave guard raises BEFORE the try):** `:1250-1251` raises
> `ValueError` *before* the `try` at `:1258`, so it is NOT caught by the failure handler and
> NOT persisted — it fails the run immediately with no `persist_wave_failure`. A rebuild must
> place this guard before the try.
> ⚠️ **GOTCHA-RUN2 (recoverable does TWO activities in order — persist-then-flip):** the
> source comment (`:1288-1311`) explains: `persist_wave_failure` writes `status='failed'` +
> `failure_reason` + `failed_at`; then `update_wave_status` flips status to
> `stuck-awaiting-recovery` (because `update_wave_status` doesn't touch the `failure_reason`
> column). A rebuild MUST issue both, in this exact order, for the recoverable path; terminal
> issues only `persist_wave_failure`.
> ⚠️ **GOTCHA-RUN3 (secondary-exception swallow is intentional):** the inner `try/except`
> (`:1287-1343`) swallows any failure of the persist activities so the **original** `exc` is
> what propagates to Temporal via the final `raise` (`:1344`). Losing the DB projection is
> preferable to masking the real failure. A rebuild MUST swallow + re-raise the original.
> ⚠️ **GOTCHA-RUN4 (`reason` truncated to 500):** `reason = str(exc)[:500]` (`:1278`). A
> rebuild must truncate.
> ⚠️ **GOTCHA-RUN5 (run_suffix determinism):** `run_suffix` is derived from
> `workflow.info().workflow_id` (`:1253-1254`) — deterministic under replay. `branch` and
> `workspace_key` are pure functions of `wave_id` + `run_suffix`. A rebuild must derive both
> from `workflow_id`, never from a fresh uuid/random.

---

## 6. `_execute()` part A — CONTROL FLOW (`wave_rationalization.py:1346-2250`) — EXHAUSTIVE

`_execute(self, input, branch, workspace_key) -> str`. `repo = input.artifact_repo` (`:1352`).
The body is: **Sequence 1** (three parallel redundancy passes + commits) → **Sequence 2**
(portfolio synthesis trio, patch-gated) → **Gate G-RR loop** (which begins the rework `while`
and runs into my boundary). I reproduce each in order.

### 6.1 Sequence 1 — three parallel redundancy passes (`:1354-1554`)

```text
await self._set_step("cross-app-redundancy", 0.0)         # :1365
cross_skill = SKILLS["cross-app-redundancy"]              # :1366
ux_skill    = SKILLS["compare-ux-overlap"]                # :1367
intra_skill = SKILLS["intra-app-redundancy"]              # :1368

# --- schedule (do NOT await yet) three dispatches ---
cross_future = workflow.execute_activity(                 # :1370-1400
    dispatch_agent_task,
    AgentTaskInput(task_type="wave-cross-app-redundancy", skill_id=cross_skill["skill_id"],
        app_id="", wave_id=input.wave_id, workspace_key=workspace_key,
        artifact_repo=repo, artifact_ref=branch,
        context=_with_fixture_scenario({"scope":"cross-app","wave_id":…,"app_ids":…},
            cross_skill["skill_id"], input.fixture_scenarios),
        input_artifacts=_business_logic_artifacts_for_wave(input.app_ids),
        timeout_seconds=3600,
        execution_context=self._execution_ctx("cross-app-redundancy",
            input_artifact_paths=_business_logic_artifacts_for_wave(input.app_ids))),
    start_to_close_timeout=timedelta(hours=1), retry_policy=RETRY_POLICIES["agent_failure"])

ux_future = workflow.execute_activity(                    # :1401-1437
    dispatch_agent_task,
    AgentTaskInput(task_type="wave-compare-ux-overlap", skill_id=ux_skill["skill_id"],
        app_id="", wave_id=…, workspace_key=workspace_key, artifact_repo=repo, artifact_ref=branch,
        context=_with_fixture_scenario({"wave_id":…,"app_ids":…}, ux_skill["skill_id"], input.fixture_scenarios),
        input_artifacts=_ux_overlap_input_artifacts(input.app_ids),
        timeout_seconds=3600,
        execution_context=self._execution_ctx("compare-ux-overlap",
            input_artifact_paths=_ux_overlap_input_artifacts(input.app_ids))),
    start_to_close_timeout=timedelta(hours=1), retry_policy=RETRY_POLICIES["agent_failure"])

intra_tasks = [                                           # :1438-1465  LOOP (one dispatch per app)
    workflow.execute_activity(
        dispatch_agent_task,
        AgentTaskInput(task_type="wave-intra-app-redundancy", skill_id=intra_skill["skill_id"],
            app_id=app_id, workspace_key=f"{workspace_key}-{app_id}",      # :1445 per-app workspace
            artifact_repo=repo, artifact_ref=branch,
            context=_with_fixture_scenario({"scope":"intra-app","wave_id":…}, intra_skill["skill_id"], input.fixture_scenarios),
            input_artifacts=[_business_logic_artifact(app_id)],
            timeout_seconds=3600,
            execution_context=self._execution_ctx("intra-app-redundancy", app_id=app_id,
                input_artifact_paths=[_business_logic_artifact(app_id)])),
        start_to_close_timeout=timedelta(hours=1), retry_policy=RETRY_POLICIES["agent_failure"])
    for app_id in input.app_ids
]

cross_result, ux_result = await asyncio.gather(cross_future, ux_future)   # :1474  ★PARALLEL (cross+ux)

# --- commit cross-app redundancy matrix ---
matrix_path = f"rationalization/wave-{input.wave_id}/{cross_skill['artifact']}"   # :1476
matrix_raw  = self._primary_output_content(cross_result, cross_skill["artifact"]) # :1482
await self._validate_artifact_or_warn(artifact_filename=cross_skill["artifact"],  # :1487-1491
        raw_content=matrix_raw, wave_id=input.wave_id)
await self._commit_artifact(repo, branch, matrix_path, matrix_raw,
        f"Wave {input.wave_id}: cross-app redundancy matrix")                     # :1492-1498
await self._commit_output_files(repo, branch, cross_result, primary_path=matrix_path,
        wave_id=input.wave_id, commit_message_prefix=f"Wave {…}: cross-app redundancy companion")  # :1499-1506

# --- commit UX overlap matrix ---
ux_path = f"rationalization/wave-{input.wave_id}/{ux_skill['artifact']}"           # :1508
await self._commit_artifact(repo, branch, ux_path,
        self._primary_output_content(ux_result, ux_skill["artifact"]),
        f"Wave {input.wave_id}: UX overlap matrix")                               # :1509-1515
await self._commit_output_files(repo, branch, ux_result, primary_path=ux_path,
        wave_id=input.wave_id, commit_message_prefix=f"Wave {…}: UX overlap companion")  # :1516-1523

await self._set_step("intra-app-redundancy", STEP_WEIGHTS["cross-app-redundancy"])  # :1525-1528  (progress=8.0)
intra_results = await asyncio.gather(*intra_tasks)        # :1534  ★PARALLEL (all per-app intra)
for app_id, result in zip(input.app_ids, intra_results):  # :1535  LOOP (commit each)
    path = f"rationalization/wave-{input.wave_id}/{app_id}/{intra_skill['artifact']}"  # :1536
    await self._commit_artifact(repo, branch, path,
        self._primary_output_content(result, intra_skill["artifact"]),
        f"Wave {input.wave_id} / {app_id}: intra-app redundancy")                 # :1537-1543
    await self._commit_output_files(repo, branch, result, primary_path=path,
        wave_id=input.wave_id, app_id=app_id,
        commit_message_prefix=f"Wave {…} / {app_id}: intra-app redundancy companion")  # :1544-1554
```

**Sequence-1 branch/loop inventory:** the `intra_tasks` comprehension loop (`:1438-1465`,
1-per-app); the `for app_id, result in zip(...)` commit loop (`:1535`). Plus all the branches
*inside* the helpers (`_primary_output_content`, `_commit_artifact`, `_commit_output_files`,
`_validate_artifact_or_warn`) per §3.

**Sequence-1 activity calls (in order):** `dispatch_agent_task`×(2 scheduled + N intra
scheduled, then `gather(cross,ux)`) → `validate_artifact_against_schema` (cross) → commits
(cross primary + companions) → commits (ux primary + companions) → `gather(*intra)` → per-app
commits. All dispatches: **1 hour** start_to_close, `agent_failure` (3 attempts). All commits
via `_commit_artifact` (patch-gated 120s/60s, `transient`).

> ⚠️ **GOTCHA-EXEC-GATHER (gather is load-bearing for parallelism):** `:1467-1473` and
> `:1529-1533` comments are explicit: `workflow.execute_activity(...)` returns a coroutine that
> **only schedules** when awaited; awaiting `cross_future` then `ux_future` sequentially would
> serialize them. `asyncio.gather` is what actually fans them out. A rebuild MUST schedule all
> futures first, then `asyncio.gather`, NOT `await` them one at a time. (Same applies to
> `intra_tasks`.)
> ⚠️ **GOTCHA-EXEC-WS (per-app workspace suffix):** intra dispatches use
> `workspace_key=f"{workspace_key}-{app_id}"` (`:1445`) — distinct workspace per app. cross/ux
> use the bare `workspace_key`. A rebuild must reproduce the per-app suffix.
> ⚠️ **GOTCHA-EXEC-VAL (only cross-app matrix is validated in Seq-1):** `_validate_artifact_or_warn`
> is called for the cross-app redundancy matrix (`:1487`) but NOT for ux or intra in Seq-1.
> A rebuild must match which artifacts get advisory validation.

### 6.2 Sequence 2 — portfolio-scope synthesis trio (patch-gated) (`:1556-1993`)

```text
pim_skill = SKILLS["portfolio-integration-mapping"]       # :1578
pra_skill = SKILLS["analyze-portfolio-redundancy"]        # :1579
br_skill  = SKILLS["cross-app-business-rule-analysis"]    # :1580
integration_graph_path      = f"rationalization/wave-{w}/{pim_skill['artifact']}"           # :1581-1583
portfolio_redundancy_path   = f"rationalization/wave-{w}/{pra_skill['artifact']}"           # :1584-1586
shared_identity_path        = f"rationalization/wave-{w}/{pra_skill['companion_artifact']}" # :1587-1590
business_rule_redundancy_path = f"rationalization/wave-{w}/{br_skill['artifact']}"          # :1591-1593
pim_result = None; pra_result = None; br_result = None    # :1594-1596

do_portfolio_synthesis = workflow.patched("wave-rationalization-portfolio-synthesis-v1")    # :1597-1599  PATCH GATE
do_cross_app_br        = workflow.patched("wave-rationalization-cross-app-br-analyzer-v1")  # :1603-1605  PATCH GATE
do_rat_cap_clustering  = workflow.patched("wave-rationalization-rat-cap-clustering-v1")     # :1615-1617  PATCH GATE
pim_progress = STEP_WEIGHTS["cross-app-redundancy"] + STEP_WEIGHTS["intra-app-redundancy"]  # :1618-1621  (=13.0)

if do_portfolio_synthesis:                                # :1622  BRANCH (entire Seq-2 gated)
    await self._set_step("portfolio-integration-mapping", pim_progress)   # :1623

    pim_input_artifacts = _portfolio_integration_input_artifacts(input.app_ids)         # :1625
    pra_input_artifacts = _portfolio_redundancy_input_artifacts(input.wave_id, input.app_ids)  # :1628
    br_input_artifacts  = _cross_app_business_rule_input_artifacts(input.app_ids)       # :1631

    rat_cap_context = {"prior_rat_caps": [], "wave_capability_grain": [], "wave_capability_count": 0}  # :1643-1647
    if do_rat_cap_clustering:                             # :1648  BRANCH (rat-cap load)
        try:
            grain_result = await workflow.execute_activity(load_wave_rationalization_capabilities,
                LoadWaveRationalizationCapabilitiesInput(portfolio_id=…, wave_id=…,
                    execution_context=self._execution_ctx("analyze-portfolio-redundancy")),
                start_to_close_timeout=timedelta(seconds=30), retry_policy=RETRY_POLICIES["transient"],
                activity_id=f"load-rat-cap-grain-{input.wave_id}")                       # :1650-1662
            rat_cap_context["prior_rat_caps"]       = grain_result.prior_rat_caps         # :1663-1665
            rat_cap_context["wave_capability_grain"]= grain_result.wave_capabilities      # :1666-1668
            rat_cap_context["wave_capability_count"]= len(grain_result.wave_capabilities) # :1669-1671
        except Exception:                                # :1672  BRANCH (best-effort load)
            workflow.logger.exception("load_wave_rationalization_capabilities failed; ...")  # :1673

    sequential_pim = workflow.patched("wave-rationalization-pim-before-pra-v1")          # :1691-1693  PATCH GATE

    pim_future = workflow.execute_activity(dispatch_agent_task,                          # :1694-1721
        AgentTaskInput(task_type="wave-portfolio-integration-mapping", skill_id=pim_skill["skill_id"],
            app_id="", wave_id=…, workspace_key=workspace_key, artifact_repo=repo, artifact_ref=branch,
            context=_with_fixture_scenario({"wave_id":…,"app_ids":…}, pim_skill["skill_id"], input.fixture_scenarios),
            input_artifacts=pim_input_artifacts, timeout_seconds=3600,
            execution_context=self._execution_ctx("portfolio-integration-mapping", input_artifact_paths=pim_input_artifacts)),
        start_to_close_timeout=timedelta(hours=1), retry_policy=RETRY_POLICIES["agent_failure"])

    br_future = None                                     # :1722
    if do_cross_app_br:                                  # :1723  BRANCH (BR dispatch)
        br_future = workflow.execute_activity(dispatch_agent_task,                       # :1724-1751
            AgentTaskInput(task_type="wave-cross-app-business-rule-analysis", skill_id=br_skill["skill_id"],
                app_id="", wave_id=…, workspace_key=workspace_key, artifact_repo=repo, artifact_ref=branch,
                context=_with_fixture_scenario({"wave_id":…,"app_ids":…}, br_skill["skill_id"], input.fixture_scenarios),
                input_artifacts=br_input_artifacts, timeout_seconds=3600,
                execution_context=self._execution_ctx("cross-app-business-rule-analysis", input_artifact_paths=br_input_artifacts)),
            start_to_close_timeout=timedelta(hours=1), retry_policy=RETRY_POLICIES["agent_failure"])

    pra_future_parallel = None                           # :1756
    if not sequential_pim:                               # :1757  BRANCH (LEGACY parallel PRA)
        _legacy_pra_context = {"wave_id":…, "app_ids":…}                                  # :1758-1761
        if do_rat_cap_clustering:                        # :1762  BRANCH
            _legacy_pra_context.update(rat_cap_context)  # :1763
        pra_future_parallel = workflow.execute_activity(dispatch_agent_task,             # :1764-1791
            AgentTaskInput(task_type="wave-analyze-portfolio-redundancy", skill_id=pra_skill["skill_id"],
                app_id="", wave_id=…, workspace_key=workspace_key, artifact_repo=repo, artifact_ref=branch,
                context=await _with_context_priors(
                    _with_fixture_scenario(_legacy_pra_context, pra_skill["skill_id"], input.fixture_scenarios),
                    pra_skill["skill_id"]),
                input_artifacts=pra_input_artifacts, timeout_seconds=3600,
                execution_context=self._execution_ctx("analyze-portfolio-redundancy", input_artifact_paths=pra_input_artifacts)),
            start_to_close_timeout=timedelta(hours=1), retry_policy=RETRY_POLICIES["agent_failure"])

    if sequential_pim:                                   # :1793  BRANCH (NEW path: PIM[+BR] now, PRA later)
        if br_future is not None:                        # :1796  BRANCH
            pim_result, br_result = await asyncio.gather(pim_future, br_future)   # :1797-1799  ★PARALLEL
        else:                                            # :1800
            pim_result = await pim_future                # :1801
    else:                                                # :1802  (LEGACY path: gather all at once)
        if br_future is not None:                        # :1804  BRANCH
            pim_result, pra_result, br_result = await asyncio.gather(pim_future, pra_future_parallel, br_future)  # :1805-1807
        else:                                            # :1808
            pim_result, pra_result = await asyncio.gather(pim_future, pra_future_parallel)  # :1809-1811

    # commit PIM integration graph (always, after PIM resolves)
    await self._commit_artifact(repo, branch, integration_graph_path,
        self._primary_output_content(pim_result, pim_skill["artifact"]),
        f"Wave {input.wave_id}: portfolio integration graph")                     # :1813-1821
    await self._commit_output_files(repo, branch, pim_result, primary_path=integration_graph_path,
        wave_id=…, commit_message_prefix=f"Wave {…}: portfolio integration graph companion")  # :1822-1831

    if sequential_pim:                                   # :1833  BRANCH (Stage 2: dispatch PRA now)
        await self._set_step("analyze-portfolio-redundancy",
            pim_progress + STEP_WEIGHTS["portfolio-integration-mapping"])         # :1837-1840  (=17.0)
        _pra_context = {"wave_id":…, "app_ids":…}                                 # :1841-1844
        if do_rat_cap_clustering:                        # :1845  BRANCH
            _pra_context.update(rat_cap_context)         # :1846
        pra_result = await workflow.execute_activity(dispatch_agent_task,         # :1847-1874
            AgentTaskInput(task_type="wave-analyze-portfolio-redundancy", skill_id=pra_skill["skill_id"],
                app_id="", wave_id=…, workspace_key=workspace_key, artifact_repo=repo, artifact_ref=branch,
                context=await _with_context_priors(
                    _with_fixture_scenario(_pra_context, pra_skill["skill_id"], input.fixture_scenarios),
                    pra_skill["skill_id"]),
                input_artifacts=pra_input_artifacts, timeout_seconds=3600,
                execution_context=self._execution_ctx("analyze-portfolio-redundancy", input_artifact_paths=pra_input_artifacts)),
            start_to_close_timeout=timedelta(hours=1), retry_policy=RETRY_POLICIES["agent_failure"])
    else:                                                # :1875  (legacy: PRA already gathered above)
        await self._set_step("analyze-portfolio-redundancy",
            pim_progress + STEP_WEIGHTS["portfolio-integration-mapping"])         # :1876-1879

    pra_raw = self._primary_output_content(pra_result, pra_skill["artifact"])     # :1887-1889
    # ⚠️ NEW — empty-plan HARD FAIL (the Wave-1 rat-cap break guard)
    if (do_portfolio_synthesis                                                    # :1906  BRANCH (NEW)
            and workflow.patched("wave-rationalization-pra-nonempty-v1")          # :1908  PATCH GATE (NEW)
            and self._primary_output_is_empty(pra_raw)):                          # :1909
        raise ApplicationError(                                                   # :1911-1919  ← NON-RETRYABLE
            "analyze-portfolio-redundancy produced an empty clustering plan ...",
            type="EmptyPortfolioRedundancyPlan", non_retryable=True)
    await self._validate_artifact_or_warn(artifact_filename="portfolio-redundancy-matrix.json",
        raw_content=pra_raw, wave_id=input.wave_id)                               # :1924-1928
    await self._commit_artifact(repo, branch, portfolio_redundancy_path, pra_raw,
        f"Wave {input.wave_id}: portfolio redundancy matrix")                     # :1929-1935

    for f in getattr(pra_result, "output_files", []) or []:    # :1940  LOOP (validate companion)
        fname = getattr(f, "path", "") or ""                   # :1941
        if fname.endswith("shared-identity-report.json"):      # :1942  BRANCH
            await self._validate_artifact_or_warn(artifact_filename="shared-identity-report.json",
                raw_content=getattr(f, "content", "") or "", wave_id=input.wave_id)   # :1943-1947
            break                                              # :1948  ← stop after first match
    await self._commit_output_files(repo, branch, pra_result, primary_path=portfolio_redundancy_path,
        wave_id=…, commit_message_prefix=f"Wave {…}: portfolio redundancy companion")   # :1949-1958

    if do_rat_cap_clustering and pra_raw:                # :1968  BRANCH (persist rat-caps)
        try:
            persist_out = await workflow.execute_activity(persist_rationalization_capabilities,  # :1970-1988  ★captures result (NEW)
                PersistRationalizationCapabilitiesInput(portfolio_id=…, wave_id=…,
                    clustering_plan_json=pra_raw, clustering_plan_artifact_ref=portfolio_redundancy_path,
                    execution_context=self._execution_ctx("analyze-portfolio-redundancy")),
                start_to_close_timeout=timedelta(seconds=60), retry_policy=RETRY_POLICIES["transient"],
                activity_id=f"persist-rat-caps-{input.wave_id}")
            # ⚠️ NEW — zero-row / validation-error read-back (surface a silent no-op persist)
            if workflow.patched("wave-rationalization-ratcap-persist-readback-v1"):   # :2002-2004  PATCH GATE (NEW)
                errs     = list(getattr(persist_out, "validation_errors", []) or [])  # :2005-2007
                inserted = getattr(persist_out, "rat_caps_inserted", 0) or 0          # :2008-2010
                updated  = getattr(persist_out, "rat_caps_updated", 0) or 0           # :2011-2013
                if errs or (inserted + updated) == 0:                                 # :2014  BRANCH (NEW)
                    warning_key = f"wave-{input.wave_id}"                             # :2015
                    msgs = [<"rat-cap clustering plan did NOT persist ..." header>]   # :2016-2023
                    msgs.extend(f"portfolio-redundancy-matrix.json: {e}" for e in errs[:8])  # :2024-2027
                    self._validation_warnings.setdefault(warning_key, []).extend(msgs)  # :2028-2030  ← into G-RR evidence
                    workflow.logger.error("persist_rationalization_capabilities wrote 0 rat-cap rows ...", errs[:5])  # :2031-2036
        except Exception:                                # :2037  BRANCH (best-effort persist)
            workflow.logger.exception("persist_rationalization_capabilities failed; ...")  # :2038-2043

    if br_result is not None:                            # :2045  BRANCH (commit BR redundancy)
        await self._set_step("cross-app-business-rule-analysis",
            pim_progress + STEP_WEIGHTS["portfolio-integration-mapping"]
            + STEP_WEIGHTS["analyze-portfolio-redundancy"])  # :2046-2051  (=22.0)
        await self._commit_artifact(repo, branch, business_rule_redundancy_path,
            self._primary_output_content(br_result, br_skill["artifact"]),
            f"Wave {input.wave_id}: cross-app business rule redundancy")            # :2052-2060
        await self._commit_output_files(repo, branch, br_result, primary_path=business_rule_redundancy_path,
            wave_id=…, commit_message_prefix=f"Wave {…}: cross-app business rule redundancy companion")  # :2061-2071
```

**Sequence-2 branch inventory (within my scope):** `if do_portfolio_synthesis` (1622);
`if do_rat_cap_clustering` (1648); its `except` (1672); `if do_cross_app_br` (1723);
`if not sequential_pim` (1757) + inner `if do_rat_cap_clustering` (1762);
`if sequential_pim` (1793) + `if br_future is not None` (1796) + `else` (1800);
`else` legacy (1802) + `if br_future is not None` (1804) + `else` (1808);
`if sequential_pim` Stage-2 (1833) + `if do_rat_cap_clustering` (1845) + `else` (1875);
**NEW** empty-plan guard `if do_portfolio_synthesis and patched(pra-nonempty-v1) and
_primary_output_is_empty` (1906);
the shared-identity `for`-loop (1940) + `if fname.endswith(...)` (1942) + `break` (1948);
`if do_rat_cap_clustering and pra_raw` (1968) + **NEW** readback `if patched(ratcap-persist-
readback-v1)` (2002) + inner `if errs or (inserted+updated)==0` (2014) + its `except` (2037);
`if br_result is not None` (2045). **(≈22 branch points in Seq-2 — was ≈18.)**

**Sequence-2 activity calls (in order, gated):** `load_wave_rationalization_capabilities`
(30s, `transient`, `activity_id=load-rat-cap-grain-{wave_id}`, **only** under
`do_rat_cap_clustering`, best-effort) → `dispatch_agent_task` (PIM) → `dispatch_agent_task` (BR,
if `do_cross_app_br`) → `dispatch_agent_task` (PRA — either in the legacy gather or the
sequential Stage-2 call) → *(NEW)* `_primary_output_is_empty(pra_raw)` empty-plan guard (pure,
no activity; raises `ApplicationError(EmptyPortfolioRedundancyPlan, non_retryable=True)` under
`pra-nonempty-v1`) → `validate_artifact_against_schema` (portfolio-redundancy-matrix +
optionally shared-identity-report) → commits → `persist_rationalization_capabilities` (60s,
`transient`, `activity_id=persist-rat-caps-{wave_id}`, **only** under
`do_rat_cap_clustering and pra_raw`, best-effort, **now captures `persist_out`**) → *(NEW)*
zero-row read-back into `_validation_warnings` under `ratcap-persist-readback-v1` → BR commits
(if `br_result`).

> ⚠️ **GOTCHA-EXEC-PATCH (6 verbatim patch IDs gate Seq-2 — was 4):** a rebuild MUST reproduce
> these EXACT strings, because they gate replay determinism for in-flight pre-patch runs:
> `"wave-rationalization-portfolio-synthesis-v1"` (1597),
> `"wave-rationalization-cross-app-br-analyzer-v1"` (1603),
> `"wave-rationalization-rat-cap-clustering-v1"` (1615),
> `"wave-rationalization-pim-before-pra-v1"` (1691),
> **NEW** `"wave-rationalization-pra-nonempty-v1"` (1908),
> **NEW** `"wave-rationalization-ratcap-persist-readback-v1"` (2002). If `do_portfolio_synthesis`
> is False, the entire Sequence-2 block (`:1622-2071`) is skipped and `pim_result`/`pra_result`/
> `br_result` stay `None`. A rebuild must keep the whole block under that one outer patch gate.
> ⚠️ **GOTCHA-EXEC-PRA-NONEMPTY (NEW — empty-plan is a HARD FAIL):** when `do_portfolio_synthesis
> AND workflow.patched("wave-rationalization-pra-nonempty-v1") AND
> self._primary_output_is_empty(pra_raw)` (`:1906-1909`), the workflow **raises**
> `ApplicationError(type="EmptyPortfolioRedundancyPlan", non_retryable=True)` (`:1911-1919`) —
> this propagates out of `_execute` to `run()`'s except (§5), where `classify_failure` lands it.
> The source comment (`:1890-1905`) records the 2026-06-14 Wave-1 break: an empty clustering plan
> committed as `"{}"` poisoned every downstream per-app disposition (which fabricated synthetic
> rat-caps). This is the ONLY place in my scope that deliberately raises mid-pipeline. A rebuild
> MUST gate the raise on all three terms and use the exact `type=`/`non_retryable=True`.
> ⚠️ **GOTCHA-EXEC-RATCAP-READBACK (NEW — silent zero-row persist surfaced as a warning):** the
> persist now captures `persist_out` (`:1970`) and, under
> `workflow.patched("wave-rationalization-ratcap-persist-readback-v1")` (`:2002`), reads
> `validation_errors` / `rat_caps_inserted` / `rat_caps_updated` off it (defensive `getattr`).
> When `errs or (inserted+updated)==0` (`:2014`) it appends a header + up to 8 error lines into
> `self._validation_warnings["wave-{wave_id}"]` (`:2028-2030`) — which then flows into the G-RR
> evidence's `validation_warnings` snapshot — and logs an `error`. The persist activity is itself
> best-effort (never raises on a schema-invalid plan), so without this read-back a wave would sail
> to G-RR with a populated clustering artifact on the branch but ZERO rat-cap rows in the DB. A
> rebuild MUST keep the read-back patch-gated, defensive-`getattr`, and append to the SAME
> `wave-{wave_id}` warning key.
> ⚠️ **GOTCHA-EXEC-PIM-PRA (sequential vs legacy PRA — the 404 fix):** when `sequential_pim` is
> True (`:1793`), PRA is dispatched in **Stage 2** (`:1847`) AFTER PIM's `integration-graph.json`
> is committed (`:1813`), because PRA lists it as an input. When `sequential_pim` is False
> (legacy), all three are gathered up front (`:1805`/`:1809`) and PRA's result is already
> resolved. The source comment (`:1687-1690`) records the bug: pre-patch all three were
> dispatched in one gather, which 404'd when PRA tried to read PIM's output before PIM committed
> it. A rebuild MUST gate PRA's dispatch ordering on `sequential_pim`.
> ⚠️ **GOTCHA-EXEC-PRA-PRIORS (PRA dispatch wraps context in `_with_context_priors`):** both PRA
> dispatch sites (`:1774`, `:1857`) wrap the context with `await _with_context_priors(...)` —
> PRA is the **only** Seq-1/2 dispatch that loads context priors. A rebuild must apply priors to
> PRA only.
> ⚠️ **GOTCHA-EXEC-RATCAP (rat-cap context threaded into PRA context, persist after commit):**
> `rat_cap_context` is loaded ONCE (`:1648-1678`) and `.update()`-merged into the PRA context on
> BOTH the legacy (`:1763`) and sequential (`:1846`) paths, but ONLY when `do_rat_cap_clustering`.
> The persist (`:1968-1988`) runs only when `do_rat_cap_clustering and pra_raw` and is
> best-effort. A rebuild must load-once-thread-twice and persist best-effort.
> ⚠️ **GOTCHA-EXEC-SHAREDID (shared-identity validate loops then breaks):** the companion
> `shared-identity-report.json` is validated by walking `pra_result.output_files` and breaking on
> the first basename match (`:1940-1948`). The commit of all companions happens via
> `_commit_output_files` (`:1949`) regardless. A rebuild must validate-on-first-match-then-break,
> commit-all separately.

### 6.3 Gate G-RR loop — entry, evidence, pre-review, wait, routing (`:2073-2384`)

> ⚠️ **REFRESH NOTE:** the whole G-RR block shifted +78 lines (`while True` was 2009, now 2087)
> AND the pre-review branch gained an `optional_evidence_paths` list (the `shared-identity-report.json`
> companion is now an *optional* pre-review evidence path, not a required one). All citations
> below are HEAD.

```text
progress_after_redundancy = STEP_WEIGHTS["cross-app-redundancy"] + STEP_WEIGHTS["intra-app-redundancy"]  # :2074-2077  (=13.0)
if do_portfolio_synthesis:                               # :2078  BRANCH (progress accounting)
    progress_after_redundancy += STEP_WEIGHTS["portfolio-integration-mapping"] + STEP_WEIGHTS["analyze-portfolio-redundancy"]  # :2079-2082  (+9 → 22.0)
    if do_cross_app_br:                                  # :2083  BRANCH
        progress_after_redundancy += STEP_WEIGHTS["cross-app-business-rule-analysis"]   # :2084-2086  (+3 → 25.0)

while True:                                              # :2087  ★G-RR REWORK LOOP
    gr_pr = await self._open_gate_pr(repo, branch, input, "G-RR",                       # :2088-2095
        f"Gate G-RR: Wave {input.wave_id} Redundancy Review", self._build_grr_body(input))
    gate_record = await workflow.execute_activity(create_gate_record,                   # :2096-2107
        CreateGateRecordInput(gate_type="G-RR", wave_id=…, portfolio_id=…,
            workflow_id=workflow.info().workflow_id, evidence_package_url=gr_pr.pr_url),
        start_to_close_timeout=timedelta(seconds=30), retry_policy=RETRY_POLICIES["transient"])
    self._register_gate_key(gate_record.gate_id, "G-RR")    # :2108  ★ flush buffered early signals

    # --- build the per-step evidence "steps" bundle ---
    intra_steps_entry = {                                   # :2115-2147  (hand-built; per-app rollup)
        "title": "Intra-App Redundancy", "skill_id": intra_skill["skill_id"], "artifact": intra_skill["artifact"],
        "output": "\n\n".join(f"### {app_id}\n\n{(r.output_artifacts[0] if r.output_artifacts else '')}"   # :2121-2124 LOOP/BRANCH
                              for app_id, r in zip(input.app_ids, intra_results)),
        "file_artifacts": [{"path": f"rationalization/wave-{w}/{app_id}/{intra_skill['artifact']}",         # :2125-2140 LOOP
                            "content": self._primary_output_content(r, intra_skill["artifact"]),
                            "encoding": "utf-8"}
                           for app_id, r in zip(input.app_ids, intra_results)],
        "metadata": {"duration_ms": sum(r.duration_ms for r in intra_results),                              # :2141-2146
                     "cost_estimate_usd": sum(r.cost_estimate_usd for r in intra_results)}}
    grr_steps = {                                           # :2148-2162
        "cross-app-redundancy": _build_rationalization_step_entry(title="Cross-App Redundancy",
            skill_id=cross_skill["skill_id"], artifact_filename=cross_skill["artifact"], result=cross_result),
        "compare-ux-overlap": _build_rationalization_step_entry(title="UX Overlap Analysis",
            skill_id=ux_skill["skill_id"], artifact_filename=ux_skill["artifact"], result=ux_result),
        "intra-app-redundancy": intra_steps_entry}
    if do_portfolio_synthesis and pim_result is not None:   # :2163  BRANCH
        grr_steps["portfolio-integration-mapping"] = _build_rationalization_step_entry(...)   # :2164-2171
    if do_portfolio_synthesis and pra_result is not None:   # :2172  BRANCH
        grr_steps["analyze-portfolio-redundancy"] = _build_rationalization_step_entry(...)    # :2173-2180
    if do_portfolio_synthesis and br_result is not None:    # :2181  BRANCH
        grr_steps["cross-app-business-rule-analysis"] = _build_rationalization_step_entry(...)# :2182-2189

    grr_artifact_paths = [matrix_path, ux_path]             # :2190
    if do_portfolio_synthesis:                              # :2191  BRANCH
        grr_artifact_paths.extend([integration_graph_path, portfolio_redundancy_path, shared_identity_path])  # :2192-2198
        if br_result is not None:                           # :2199  BRANCH
            grr_artifact_paths.append(business_rule_redundancy_path)   # :2200

    await workflow.execute_activity(submit_gate_evidence,   # :2201-2224
        SubmitGateEvidenceInput(gate_id=gate_record.gate_id, gate_type=GateType.G_RR,
            app_id=f"wave-{input.wave_id}", artifact_paths=grr_artifact_paths, pr_url=gr_pr.pr_url,
            evidence_data={"wave_id":…, "app_ids":…, "assembly_line":"Rationalization",
                "steps": grr_steps, "validation_warnings": dict(self._validation_warnings)}),  # :2219 snapshot
        start_to_close_timeout=timedelta(seconds=60), retry_policy=RETRY_POLICIES["transient"])

    if workflow.patched("wave-rationalization-gate-pre-review-v1"):   # :2235  BRANCH (PATCH GATE — pre-review)
        grr_pre_review_paths = [matrix_path, ux_path]       # :2236
        grr_pre_review_optional = []                        # :2247  ★NEW (optional evidence list)
        if do_portfolio_synthesis:                          # :2248  BRANCH
            grr_pre_review_paths.extend([integration_graph_path, portfolio_redundancy_path])  # :2249-2254  (NO shared_identity here)
            grr_pre_review_optional.append(shared_identity_path)   # :2255  ★NEW (companion is OPTIONAL)
            if br_result is not None:                       # :2256  BRANCH
                grr_pre_review_paths.append(business_rule_redundancy_path)   # :2257-2259
        for app_id in input.app_ids:                        # :2260  LOOP
            grr_pre_review_paths.append(f"rationalization/wave-{w}/{app_id}/{intra_skill['artifact']}")  # :2261-2264
        await self._run_gate_pre_review(gate_record.gate_id, "G-RR", grr_pre_review_paths,
            artifact_repo=repo, artifact_ref=branch,
            optional_evidence_paths=grr_pre_review_optional)   # :2265-2272  ★NEW kwarg

    await workflow.execute_activity(mark_gate_ready_for_review, gate_record.gate_id,    # :2273-2278
        start_to_close_timeout=timedelta(seconds=30), retry_policy=RETRY_POLICIES["transient"])

    await self._set_step("gate-review-rr", progress_after_redundancy)    # :2280
    decision = await self._wait_for_gate("G-RR")            # :2281  ★ BLOCKS for gate decision

    if decision == "cancelled":                             # :2282  BRANCH ROUTE A
        return "cancelled"                                  # :2283  ← terminates _execute → run returns "cancelled"
    if decision == "approved":                              # :2284  BRANCH ROUTE B
        await self._reconcile_and_merge_with_retry_loop(    # :2286-2290  ← merge with merge_blocked loop
            repo=repo, pr_number=gr_pr.pr_number, gate_id=gate_record.gate_id)
        break                                               # :2291  ← exits the while True; proceeds to disposition fan-out (SIBLING)

    # decision == "rejected" → ROUTE C (rework)
    self._rework_iterations_grr += 1                        # :2292  ★ BUMP rework counter
    if self._rework_iterations_grr > MAX_REWORK_ITERATIONS: # :2293  BRANCH (ceiling=3)
        self._status = WorkflowStatus.FAILED                # :2294
        self._current_step = "max-rework-exceeded-grr"      # :2295
        return "failed"                                     # :2296  ← terminates _execute → run returns "failed"

    rework_targets = set((self._rework_feedback.get("G-RR") or {}).get("rework_targets", []))  # :2308-2312
    scope_to_targets = bool(rework_targets)                 # :2313

    skip_cross_app = scope_to_targets and "cross-app-redundancy" not in rework_targets   # :2320-2323  BRANCH
    if skip_cross_app:                                      # :2324  BRANCH
        workflow.logger.info("G-RR rework: skipping cross-app-redundancy rerun ...", ...)  # :2325-2329
    else:                                                   # :2330
        await self._set_step("cross-app-redundancy", 0.0)   # :2331
        cross_result = await workflow.execute_activity(     # :2332-2363
            dispatch_agent_task,
            AgentTaskInput(task_type="wave-cross-app-redundancy", skill_id=cross_skill["skill_id"],
                app_id="", wave_id=input.wave_id, workspace_key=workspace_key,
                artifact_repo=repo, artifact_ref=branch,
                context=_with_fixture_scenario({... "rework_feedback": self._rework_feedback.get("G-RR")}, ...),  # :2342-2351
                ...))
        # ... cross-app rework re-commit (:2364-2384) ...
    # >>> MY SCOPE ENDS AT LINE 2384 (the PRA rework re-dispatch from :2386 is owned by sibling -3-execute-b) <<<
```

**Gate-G-RR-loop branch/route inventory (within my scope):** `if do_portfolio_synthesis`
(2078) + inner `if do_cross_app_br` (2083); the `while True` (2087); the `output` join
comprehension + inline ternary (2121-2124); the `file_artifacts` comprehension (2125-2140);
`if do_portfolio_synthesis and pim_result is not None` (2163); `… pra_result …` (2172);
`… br_result …` (2181); `if do_portfolio_synthesis` (2191) + `if br_result is not None`
(2199); `if workflow.patched("wave-rationalization-gate-pre-review-v1")` (2235) + inner
`if do_portfolio_synthesis` (2248) + `if br_result is not None` (2256) + `for app_id` loop
(2260); the three decision routes — `if decision == "cancelled"` (2282), `if decision ==
"approved"` (2284), implicit rejected; `if self._rework_iterations_grr > MAX_REWORK_ITERATIONS`
(2293); `skip_cross_app` (2320); `if skip_cross_app` (2324) / `else` (2330).

**Gate-G-RR-loop activity calls (per iteration, in order):**
1. `create_pr` (via `_open_gate_pr`) — 60s, `transient`, no labels, step `create-g-rr-pr`.
2. `create_gate_record` — `CreateGateRecordInput(gate_type="G-RR", …, evidence_package_url=pr_url)`;
   **30s**; `transient`. → returns `gate_record.gate_id`.
3. `submit_gate_evidence` — `SubmitGateEvidenceInput(gate_id, GateType.G_RR,
   app_id=f"wave-{wave_id}", artifact_paths=grr_artifact_paths, pr_url, evidence_data=…)`; **60s**;
   `transient`.
4. *(patch-gated)* `_run_gate_pre_review` → `dispatch_agent_task` (gate-pre-review, 10m) +
   `store_gate_pre_review` (30s), best-effort.
5. `mark_gate_ready_for_review` — positional `gate_record.gate_id`; **30s**; `transient`.
6. `_wait_for_gate("G-RR")` — blocks (no activity; `wait_condition`).
7. On approve: `_reconcile_and_merge_with_retry_loop` (`reconcile_and_merge_pr` 60s/`git_merge`,
   then `set_gate_merge_blocked` 30s/`transient` on merge error, then wait).
8. On reject (rerun, partly past boundary): `dispatch_agent_task` (cross-app rework) + commits.

> ⚠️ **GOTCHA-GRR-ROUTING (the three-way route + counter + ceiling):** `_wait_for_gate` returns
> exactly `"cancelled"` / `"approved"` / `"rejected"`. The loop routes:
> - `"cancelled"` (`:2282`) → `return "cancelled"` (whole `_execute` returns; `run` returns it).
> - `"approved"` (`:2284`) → merge loop, then `break` out of `while True` (proceeds to the
>   disposition fan-out in the SIBLING spec). The merge happens INSIDE the loop before break.
> - `"rejected"` (fall-through) → `self._rework_iterations_grr += 1` (`:2292`), and if
>   `> MAX_REWORK_ITERATIONS (3)` → set `_status=FAILED`, `_current_step=
>   "max-rework-exceeded-grr"`, `return "failed"`. Else re-run the affected steps and loop.
>   A rebuild MUST bump the counter on reject (NOT inside `_wait_for_gate`), compare strictly
>   `>` against 3, and use the exact status/step strings.
> ⚠️ **GOTCHA-GRR-CARDSCOPE (card-scoped rework boundary):** on reject, `rework_targets` is read
> from `self._rework_feedback["G-RR"]["rework_targets"]` (populated by `_wait_for_gate` via
> `rework_targets_from_card_decisions`, §3.8). `scope_to_targets = bool(rework_targets)`. If
> non-empty AND `"cross-app-redundancy"` is NOT in it, `skip_cross_app=True` → the cross-app
> rerun is SKIPPED (a `logger.info`), preserving the prior `cross_result`. Otherwise the
> cross-app pass re-dispatches with `context["rework_feedback"] = self._rework_feedback.get("G-RR")`
> (`:2347`). Empty `rework_targets` = legacy whole-gate reject → full
> rerun. A rebuild MUST gate each rerun step on membership in `rework_targets` (when non-empty),
> and fall back to full rerun when empty. (The PRA rework re-dispatch that follows the cross-app
> rerun, with its own `skip_pra` 3-AND predicate, is owned by sibling `-3-execute-b`, `:2386+`.)
> ⚠️ **GOTCHA-GRR-EVIDENCE-WARNINGS (validation warnings folded into evidence):** the G-RR
> evidence's `evidence_data["validation_warnings"]` is `dict(self._validation_warnings)`
> (`:2219`) — a snapshot copy of the warnings accumulated during Seq-1/Seq-2 dispatch, **now
> including the NEW rat-cap zero-row read-back warnings** (`:2028`, §6.2). A rebuild
> must include this snapshot.
> ⚠️ **GOTCHA-GRR-EVIDENCE-STEPS (steps bundle is gated by which results exist):** `grr_steps`
> always includes cross/ux/intra; PIM/PRA/BR are added ONLY when `do_portfolio_synthesis and
> <result> is not None` (`:2163,2172,2181`). Likewise `grr_artifact_paths` extends the
> synthesis paths only under `do_portfolio_synthesis`, and the BR path only when `br_result is
> not None`. The pre-review path list mirrors this gating AND additionally appends every
> per-app intra path (`:2260-2264`). A rebuild must reproduce each conditional inclusion.
> ⚠️ **GOTCHA-GRR-PREREVIEW-OPTIONAL (NEW — shared-identity is OPTIONAL pre-review evidence):**
> unlike the *evidence* list (`grr_artifact_paths`, which still includes `shared_identity_path`
> as a required entry at `:2192-2198`), the *pre-review* path list now puts `shared_identity_path`
> into a separate `grr_pre_review_optional` list (`:2247,2255`) passed as
> `optional_evidence_paths=` to `_run_gate_pre_review` (`:2271`). The rat-cap-rewritten PRA skill
> no longer always emits the companion; a required missing path made the pre-review agent's
> `_fetch_input_artifacts` raise `FileNotFoundError`, which the pre-review swallowed and left the
> reviewer on an empty AI-recommendation panel. A rebuild MUST split the pre-review evidence into
> required (`grr_pre_review_paths`) and optional (`grr_pre_review_optional` = just
> `shared_identity_path`, only when `do_portfolio_synthesis`), and pass the optional set as the
> new kwarg. (See §3.9 GOTCHA-PR-WAVE-OPTIONAL.)
> ⚠️ **GOTCHA-GRR-PREREVIEW-PATCH (pre-review is patch-gated separately):** the AI pre-review is
> behind `workflow.patched("wave-rationalization-gate-pre-review-v1")` (`:2235`) — pre-existing
> in-flight workflows never scheduled it and take the skip branch on replay. The
> `mark_gate_ready_for_review` flip (`:2273`) is NOT patch-gated and always runs. A rebuild must
> keep the verbatim patch string and run `mark_gate_ready_for_review` unconditionally (outside
> the patch gate, after the optional pre-review).
> ⚠️ **GOTCHA-GRR-REGISTER (register_gate_key right after create_gate_record):** `:2108` flushes
> any early-arriving buffered signals into the G-RR queue. Without this call at this exact site,
> a reviewer/test that signalled before the gate record existed would have its decision stuck in
> `_pending_signals_by_gate_id` and `_wait_for_gate("G-RR")` would hang. (See GOTCHA-S-UUID /
> GOTCHA-SIG-NO-RESET.)
> ⚠️ **GOTCHA-GRR-REGEN-IN-LOOP (gate PR + gate record recreated each iteration):** because
> `_open_gate_pr` and `create_gate_record` are INSIDE the `while True`, every rework iteration
> opens a **new** PR and a **new** gate record (with a new UUID, re-registered via
> `_register_gate_key`). A rebuild must NOT hoist these out of the loop — each iteration's
> decision is consumed against the latest gate's UUID-routed queue.

---

## 7. RESILIENCE summary (for my scope)

- **Timeouts (start_to_close):** every `dispatch_agent_task` = **1 hour**; `create_pr` 60s;
  `create_gate_record` 30s; `submit_gate_evidence` 60s; `mark_gate_ready_for_review` 30s;
  `validate_artifact_against_schema` 30s; `load_wave_rationalization_capabilities` 30s;
  `persist_rationalization_capabilities` 60s; `persist_wave_failure` 30s; `update_wave_status`
  30s; `_commit_artifact` 120s (batch patch) / 60s (legacy); `reconcile_and_merge_pr` 60s;
  `set_gate_merge_blocked` 30s; pre-review dispatch 10m; `store_gate_pre_review` 30s.
- **Retry policies:** dispatches → `agent_failure` (3 attempts, 5–60s backoff). Everything else
  in scope → `transient` (HTTP policy, 3 attempts, 1–15s) EXCEPT the merge → **`git_merge`** (3
  attempts + non_retryable merge errors).
- **Heartbeats:** none configured.
- **continue-as-new:** none in this range.
- **Idempotency:** deterministic `activity_id`s for the rat-cap load
  (`load-rat-cap-grain-{wave_id}`) and persist (`persist-rat-caps-{wave_id}`). `_now_iso()` =
  `workflow.now()` deterministic. `branch`/`workspace_key`/`run_suffix` derived from
  `workflow_id`. Patch IDs gate optional activity additions (replay-stable) — now **6** in Seq-2
  (the 4 originals + NEW `pra-nonempty-v1` + NEW `ratcap-persist-readback-v1`).
- **Best-effort (swallowed) activities in scope:** context-priors load (§4); rat-cap grain load
  (`:1672`); rat-cap persist (`:2037`, now also reads `persist_out` for the zero-row read-back);
  schema validation (`_validate_artifact_or_warn`, ActivityError swallowed); output-file companion
  commits (`_commit_output_files`, per-file swallow); the entire `run()` failure-persist block
  (`:1333`). None of these block the pipeline. ⚠️ **EXCEPTION (NEW):** the empty-PRA-plan guard
  (`:1906-1919`) is the ONE place in Seq-2 that **deliberately raises** (NonRetryable
  `ApplicationError`) instead of swallowing — it propagates to `run()`'s except.
- **Compensation / rollback:** none. Failure path is `run()`'s except → classify → persist wave
  status (`failed` vs `stuck-awaiting-recovery`) → re-raise. The merge_blocked loop is the only
  "wait and retry" recovery (driven by the `merge_retry` signal).
- **Cancel:** `self.cancelled` (set by inherited `cancel_workflow`) drains `_wait_for_gate`
  (returns `"cancelled"` → `return "cancelled"`) and the merge loop (returns). There is also a
  separate `cancel_all_children` signal (sibling-owned) that aborts Architecture child handles
  and flips `_status=CANCELLED` — but it does NOT affect my G-RR wait directly (it's for the
  post-G-DA fan-out).

---

## 8. Behavioral parity checklist (assertions a rebuild of lines 1238–2384 MUST pass)

1. **Inheritance:** `class WaveRationalizationWorkflow(HILSignalsMixin)` — NOT `LineWorkflowBase`.
   `__init__` calls `super().__init__()` first, then sets all 32 instance vars in §1 to the
   listed initial values. `_gate_decisions`/`_gate_decisions_consumed` are **per-gate-key dicts**.
   (GOTCHA-INHERIT, GOTCHA-S-DICT)
2. **`run()` order:** dict-coercion → set RUNNING/wave/portfolio/timestamps → **empty-`app_ids`
   `raise ValueError` BEFORE the try** → derive `run_suffix` from `workflow_id`, build `branch`
   = `olympus/rationalization/wave-{wave_id}/{run_suffix}` and `workspace_key` =
   `wave-rationalization-{wave_id}-{run_suffix}` → `try: return await self._execute(...)`.
   (GOTCHA-RUN1, GOTCHA-RUN5)
3. **`run()` failure handler:** on any `Exception` from `_execute`: set `_status=FAILED`,
   `_current_step="failed"`, `_updated_at`; `classification=classify_failure(exc)`;
   `reason=str(exc)[:500]`; in an inner try, if recoverable → `persist_wave_failure` THEN
   `update_wave_status(new_status="stuck-awaiting-recovery")`, else (terminal) →
   `persist_wave_failure` only; swallow any secondary exception; **re-raise the original**.
   (GOTCHA-RUN2/3/4)
4. **`classify_failure`** walks `__cause__`/`__context__`, probes `activity_type`/`activity_name`/
   `_activity_type`, returns `"recoverable"` for names in `RECOVERABLE_FAILURE_ACTIVITIES`,
   `"terminal"` for `TERMINAL_FAILURE_ACTIVITIES`, **else `"terminal"`**.
5. **Sequence 1:** `_set_step("cross-app-redundancy", 0.0)`; schedule cross + ux + N-intra
   `dispatch_agent_task` futures (1h/`agent_failure`); `asyncio.gather(cross, ux)`; commit cross
   matrix (after `_validate_artifact_or_warn` on it) + companions; commit ux matrix + companions;
   `_set_step("intra-app-redundancy", 8.0)`; `asyncio.gather(*intra)`; per-app commit + companions.
   intra workspace = `{workspace_key}-{app_id}`. (GOTCHA-EXEC-GATHER, GOTCHA-EXEC-WS,
   GOTCHA-EXEC-VAL)
6. **Sequence 2 is gated** by `workflow.patched("wave-rationalization-portfolio-synthesis-v1")`;
   when False the whole block is skipped and PIM/PRA/BR stay `None`. The **six** verbatim patch IDs
   (synthesis, cross-app-br, rat-cap-clustering, pim-before-pra, **NEW** pra-nonempty,
   **NEW** ratcap-persist-readback) are reproduced exactly. (GOTCHA-EXEC-PATCH)
7. **Seq-2 PRA ordering:** with `sequential_pim` True, PIM (+BR if `do_cross_app_br`) is gathered,
   PIM committed, THEN PRA dispatched in Stage 2 (after integration-graph is on the branch); with
   `sequential_pim` False (legacy), all enabled dispatches gathered up front. PRA context is
   wrapped in `_with_context_priors` on BOTH sites. (GOTCHA-EXEC-PIM-PRA, GOTCHA-EXEC-PRA-PRIORS)
8. **Seq-2 rat-cap:** `load_wave_rationalization_capabilities` runs only under
   `do_rat_cap_clustering` (best-effort, `activity_id=load-rat-cap-grain-{wave_id}`); its result
   `.update()`-merges into PRA context on both paths; `persist_rationalization_capabilities` runs
   only when `do_rat_cap_clustering and pra_raw` (best-effort, `activity_id=
   persist-rat-caps-{wave_id}`). (GOTCHA-EXEC-RATCAP)
9. **Seq-2 validation + NEW guards:** *(NEW)* before validate, if `do_portfolio_synthesis AND
   patched("wave-rationalization-pra-nonempty-v1") AND _primary_output_is_empty(pra_raw)` →
   **raise** `ApplicationError(type="EmptyPortfolioRedundancyPlan", non_retryable=True)`; else
   `portfolio-redundancy-matrix.json` validated before commit; `shared-identity-report.json`
   validated by looping `pra_result.output_files` and breaking on first basename match; all
   companions committed via `_commit_output_files`. *(NEW)* the rat-cap persist captures
   `persist_out` and, under `patched("wave-rationalization-ratcap-persist-readback-v1")`, appends
   a zero-row/validation-error warning into `_validation_warnings["wave-{wave_id}"]`.
   (GOTCHA-EXEC-SHAREDID, GOTCHA-EXEC-PRA-NONEMPTY, GOTCHA-EXEC-RATCAP-READBACK, GOTCHA-EMPTY-PLAN)
10. **G-RR loop is a `while True`** that, EACH iteration: opens a fresh PR (`_open_gate_pr`,
    no labels, target `main`), creates a fresh `create_gate_record(gate_type="G-RR", …)`,
    calls `_register_gate_key(gate_id, "G-RR")` immediately, builds `grr_steps` (cross/ux/intra
    always; PIM/PRA/BR only when `do_portfolio_synthesis and <result> is not None`), builds
    `grr_artifact_paths` (matrix+ux always; synthesis paths + BR path conditionally), submits
    `submit_gate_evidence` (GateType.G_RR, app_id=`wave-{wave_id}`, evidence_data with `steps` +
    `validation_warnings` snapshot), optionally runs `_run_gate_pre_review` under
    `workflow.patched("wave-rationalization-gate-pre-review-v1")` (pre-review *required* path
    appends every per-app intra path; **NEW** the `shared-identity-report.json` companion goes
    into a separate `grr_pre_review_optional` list passed as `optional_evidence_paths=`), runs
    `mark_gate_ready_for_review` unconditionally, `_set_step("gate-review-rr",
    progress_after_redundancy)`, then `decision = await
    _wait_for_gate("G-RR")`. (GOTCHA-GRR-REGEN-IN-LOOP, GOTCHA-GRR-REGISTER,
    GOTCHA-GRR-EVIDENCE-STEPS, GOTCHA-GRR-EVIDENCE-WARNINGS, GOTCHA-GRR-PREREVIEW-PATCH,
    GOTCHA-GRR-PREREVIEW-OPTIONAL)
11. **`_wait_for_gate` semantics:** per-key snapshot-cursor wait
    `len(_gate_decisions[gate_key]) > consumed or self.cancelled`; cancel → `_status=CANCELLED`,
    return `"cancelled"` WITHOUT advancing; else read entry (5-tuple or 3-tuple), advance cursor,
    `_status=RUNNING`, `_pending_gate=None`; APPROVED → pop `_rework_feedback[gate_key]`, set/pop
    `_approval_feedback[gate_key]` on non-blank/blank reason, return `"approved"`; REJECTED → pop
    `_approval_feedback[gate_key]`, set `_rework_feedback[gate_key]` (7-key dict incl
    `rework_targets`), return `"rejected"`. Does NOT bump `_rework_iterations_grr`.
    (GOTCHA-WG-WAVE1/2/3/4)
12. **G-RR routing:** `"cancelled"` → `return "cancelled"`; `"approved"` →
    `_reconcile_and_merge_with_retry_loop(repo, gr_pr.pr_number, gate_record.gate_id)` then
    `break`; `"rejected"` → `_rework_iterations_grr += 1`, if `> 3` set `_status=FAILED` +
    `_current_step="max-rework-exceeded-grr"` + `return "failed"`, else compute
    `rework_targets` from `_rework_feedback["G-RR"]`, `scope_to_targets=bool(rework_targets)`,
    and `skip_cross_app = scope_to_targets and "cross-app-redundancy" not in rework_targets`
    (skip-with-log vs re-dispatch cross-app with `context["rework_feedback"]`). (GOTCHA-GRR-ROUTING,
    GOTCHA-GRR-CARDSCOPE)
13. **Merge loop:** `while True` merging via `reconcile_and_merge_pr` (60s, `git_merge`); on
    `(ActivityError, ApplicationError)` unwrap `__cause__` to find `ApplicationError`, re-raise
    if none or if `.type` not in {MergeConflict, MergeDivergenceUnresolved,
    MergeBranchProtectionRejected}; else reset `_merge_retry_signalled=False`, call
    `set_gate_merge_blocked` (positional `args=[gate_id, detail]`, 30s/`transient`), wait
    `_merge_retry_signalled or self.cancelled`, return on cancel, else loop.
14. **`_set_step` clamps progress to [0,100]** and does NOT do a DB status write. (GOTCHA-SETSTEP)
15. **`_execution_ctx`** returns `None` iff `_portfolio_id` empty; otherwise `line_id` is the
    literal `"rationalization"`. (GOTCHA-EC-WAVE)
16. **All verbatim patch IDs** reproduced exactly: `wave-rationalization-portfolio-synthesis-v1`,
    `wave-rationalization-cross-app-br-analyzer-v1`, `wave-rationalization-rat-cap-clustering-v1`,
    `wave-rationalization-pim-before-pra-v1`, **`wave-rationalization-pra-nonempty-v1`** (NEW),
    **`wave-rationalization-ratcap-persist-readback-v1`** (NEW),
    `wave-rationalization-gate-pre-review-v1`,
    `wave-rationalization-batch-writes-v1` (in `_commit_artifact`). Activity imports under
    `with workflow.unsafe.imports_passed_through():`.
17. **All `dispatch_agent_task` calls** use `start_to_close_timeout=timedelta(hours=1)` and
    `retry_policy=RETRY_POLICIES["agent_failure"]`, and thread `_with_fixture_scenario(...)` into
    `context`, and `execution_context=self._execution_ctx(...)`.
18. **MAX_REWORK_ITERATIONS == 3** and the comparison is strictly `>` (so iterations 1,2,3 are
    allowed; the 4th reject fails). The rework counter is the **per-class** `_rework_iterations_grr`,
    bumped only on the `"rejected"` branch in `_execute`.
