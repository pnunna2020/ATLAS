# `AppWorkflow` — Single-Application Sequential Orchestrator (ATOMIC regeneration spec)

> **Source of truth:** `temporal/olympus_workflows/workflows/application.py` (182 lines). Every
> `application.py:line` citation below is against that file **at HEAD `7cb3b20c`**.
>
> **What this is:** the per-application entry-point workflow. One `AppWorkflow` instance exists
> per application that has been onboarded and kicked off. Its job in the **current (Phase-3)
> implementation** is intentionally minimal: run **Discovery** as a child workflow, then complete.
> Everything downstream (Rationalization, Architecture, Data, Modernization, Disposition
> Execution, Validation, Deployment) is **NOT** orchestrated from here — it is wave-scoped and
> driven by `WaveRationalizationWorkflow` / `WaveWorkflow` (`application.py:107-113`,
> `application.py:50-57`). The docstring's elaborate line-ordering text describes the *eventual*
> design, NOT what `run()` does today. **Reproduce what `run()` does, not the docstring.**
>
> **Inherits:** `class AppWorkflow(HILSignalsMixin)` (`application.py:43`). The mixin is imported
> from the **`foundry_temporal` package** — `from foundry_temporal.signals import HILSignalsMixin`
> (`application.py:22`), NOT from a local `base.py`. See `_HILSignalsMixin.md` for the inherited HIL
> signal surface (`approve_plan`, `provide_plan_feedback`, `approve_research`, `provide_feedback`,
> `approve`, `cancel_workflow`, the `reset_*` / `is_*_decision_received` helpers, and the
> `create_*_signal` factories).
> ⚠️ **It does NOT inherit `LineWorkflowBase`.** Do not import any `_LineWorkflowBase.md` behavior
> into this workflow as inherited — `AppWorkflow` is a *direct* `HILSignalsMixin` subclass and
> redefines (locally, from scratch) its own `gate_approved`/`gate_rejected`/`escalation_resolved`
> signals and its own `get_status` query. See §0.1 (Inheritance contrast) — this is the single
> most important fact in this spec.
>
> **Determinism:** the only time source is the module-level `_now_iso()` →
> `workflow.now().isoformat()` (`application.py:179-181`). No `datetime.now()`, no I/O in handlers,
> no randomness. The one `await` in `run()` is the child-workflow execution (`application.py:100`).
>
> ---
>
> ## ⚠️⚠️ HEAD DELTA — what CHANGED since the previous spec baseline ⚠️⚠️
>
> The previous version of this spec described a `_gate_signals: list[dict]` write-only buffer that
> three signal handlers (`gate_approved`, `gate_rejected`, `override_approved`) appended structured
> dicts to. **That state and that behavior NO LONGER EXIST at HEAD.** They were removed by
> **PR #543 — "fix(wave): … retire dead gate-signal accumulators"** (commit `b9f75d01`). At HEAD:
>
> 1. **`__init__` no longer declares `_gate_signals`** — there are now **FIVE** instance vars, not
>    six (`application.py:62-67`). See §1.
> 2. **`gate_approved`, `gate_rejected`, `override_approved` are now PURE no-ops** that only bump
>    `_updated_at` — they no longer build or append any dict. All six locally-defined signals are
>    now behaviorally identical (timestamp bump only). See §3. This is the headline change:
>    **`AppWorkflow` no longer buffers ANY gate-signal payload.**
> 3. **New "accept-and-ignore" design rationale** (P5-S30.6, decided 2026-06-09) is documented in
>    the source at `application.py:124-130`: `AppWorkflow` runs Discovery and exits — it awaits no
>    gates of its own; the gate-bearing child (`DiscoveryWorkflow`) owns and awaits its gate, and the
>    API signals **that** child directly by the `workflow_id` on the gate row. These handlers exist
>    only so a mis-addressed signal is a benign no-op rather than an unhandled-signal error.
> 4. **All line citations shifted** (file shrank from 211 → 182 lines). Every `application.py:N`
>    below is re-verified against HEAD.
>
> If a reviewer or test still asserts a `_gate_signals` buffer or dict shapes, that assertion is
> **stale** and must be dropped — the contract at HEAD is "these six signals are inert no-ops."

---

## 0. Class shape, branch budget, and the inheritance contrast

```text
@workflow.defn                                            # application.py:42
class AppWorkflow(HILSignalsMixin):                       # application.py:43
    def __init__(self): ...                               # application.py:60-67
    @workflow.run async def run(self, input): ...         # application.py:70-118
    @workflow.signal async def gate_approved(self, s)     # application.py:131-134
    @workflow.signal async def gate_rejected(self, s)     # application.py:136-139
    @workflow.signal async def override_approved(self, s) # application.py:141-144
    @workflow.signal async def escalation_resolved(self, s)# application.py:146-149
    @workflow.signal async def stakeholder_approved(self, s)# application.py:151-154
    @workflow.signal async def wave_patterns_ready(self, s)# application.py:156-159
    @workflow.query     def get_status(self)              # application.py:165-176

# module level:
def _now_iso() -> str                                     # application.py:179-181
```

**Branch budget for this scope: ZERO `if/elif/else`, ZERO loops, ZERO `try/except`, ZERO
`match/case`.** I assert this explicitly because the task says "reproduce ALL of them" — there are
none in statement form. `run()` is a strictly linear statement sequence (`application.py:80-118`).
Each signal handler is now a single-statement timestamp bump (no conditionals, no list-append).
`get_status` contains one **conditional expression** (not a statement branch):
`100.0 if self._status == WorkflowStatus.COMPLETED else 0.0` (`application.py:173`) — reproduced
verbatim in §4. **That ternary is the ONLY decision point in the entire file**, and it lives inside
a read-only query expression. Everything else is unconditional.

⚠️ **GOTCHA-BRANCH (linearity is load-bearing):** because `run()` has no branches and exactly one
`await`, this workflow has exactly one yield point and a fixed, deterministic event history:
*start → execute_child(DiscoveryWorkflow) → complete*. A rebuild MUST keep `run()` linear. Adding
a branch (e.g. "if disposition == Retire skip Discovery") would change replay history for every
in-flight `AppWorkflow` and is explicitly NOT what this version does.

### 0.1 Inheritance contrast — `AppWorkflow` vs the seven `LineWorkflowBase` subclasses

This is the highest-value fact in the spec. The seven per-line workflows inherit
`LineWorkflowBase` and therefore inherit base versions of `gate_approved` / `gate_rejected` /
`escalation_resolved` / `merge_retry` that they **MUST NOT redefine** (`_LineWorkflowBase.md`
§3, GOTCHA-SIG0). `AppWorkflow` is **different**:

| Aspect | `LineWorkflowBase` subclasses | `AppWorkflow` (this file, HEAD) |
|--------|-------------------------------|---------------------------|
| Base class | `LineWorkflowBase(HILSignalsMixin)` | **`HILSignalsMixin` directly** (`application.py:43`, imported from `foundry_temporal.signals` at `application.py:22`) |
| `gate_approved` | inherited from base; appends a **5-tuple** to `_gate_decisions`; **must not redefine** | **defined locally** (`application.py:131-134`); **PURE no-op** — only `self._updated_at = _now_iso()`. This IS the only definition |
| `gate_rejected` | inherited; appends 5-tuple; must not redefine | defined locally (`application.py:136-139`); **PURE no-op** — only `_updated_at` bump |
| `override_approved` | (not a base concern in the same way) | defined locally (`application.py:141-144`); **PURE no-op** — only `_updated_at` bump |
| `escalation_resolved` | inherited; no-op + `_updated_at` | defined locally (`application.py:146-149`); no-op + `_updated_at` (same effect, different file) |
| `merge_retry` | inherited; sets `_merge_retry_signalled=True` | **NOT defined** — `AppWorkflow` has no `merge_retry` signal at all (it never merges) |
| `_gate_signals` / `_gate_decisions` / `_rework_*` | base has `_gate_decisions` machinery | **ABSENT** — none of the gate-decision/gate-signal buffering exists here (⚠️ `_gate_signals` was REMOVED by #543 — see HEAD DELTA) |
| Gate-wait helpers (`_wait_for_gate_decision`, `_reconcile_and_merge_with_retry_loop`) | present | **absent** — `AppWorkflow` never waits on a gate and never merges |
| `get_status` query | inherited from base; returns `current_line = self.ASSEMBLY_LINE` (classvar) | **defined locally** (`application.py:165-176`); returns `current_line = self._current_line` (instance var) — **different field source** |
| HIL signals (`approve`, `cancel_workflow`, `approve_plan`, `provide_plan_feedback`, `approve_research`, `provide_feedback`) | inherited from `HILSignalsMixin` | inherited from `HILSignalsMixin` (same) |

⚠️ **GOTCHA-INHERIT (do not "deduplicate" against the base):** because `AppWorkflow` does NOT
extend `LineWorkflowBase`, its locally-defined `gate_approved` / `gate_rejected` /
`override_approved` / `escalation_resolved` / `get_status` are **not** duplicate registrations —
there is no base definition to collide with. A rebuild MUST define all of these here, with the
**pure-`_updated_at`-bump** bodies shown below (NOT the 5-tuple / `_gate_decisions` bodies from
`_LineWorkflowBase.md`, and NOT the old dict-append bodies from the pre-#543 spec). Conversely, a
rebuild MUST NOT make `AppWorkflow` inherit `LineWorkflowBase`, because that would (a) introduce a
duplicate-`gate_approved`-registration crash and (b) silently swap the no-op behavior for the
5-tuple buffering behavior.

⚠️ **GOTCHA-HIL (the six HIL signals ARE live here):** `approve`, `cancel_workflow`, `approve_plan`,
`provide_plan_feedback`, `approve_research`, `provide_feedback` are inherited from `HILSignalsMixin`
and ARE registered on `AppWorkflow` (Temporal walks the MRO). So `AppWorkflow` actually exposes
**12 signals total**: 6 inherited HIL + 6 locally-defined (gate_approved, gate_rejected,
override_approved, escalation_resolved, stakeholder_approved, wave_patterns_ready) + (no
merge_retry). The 6 locally-defined ones are now all timestamp-bump no-ops. The inherited 6 are
additional and still wire-reachable. A rebuild must keep the `HILSignalsMixin` inheritance so
`cancel_workflow`/`approve` remain callable, even though `run()` never reads `self.cancelled` or
`self.approved` (see GOTCHA-CANCEL).

---

## 1. STATE — every instance var (`__init__`, `application.py:60-67`)

`__init__` calls `super().__init__()` **first** (`application.py:61`) — this initializes the 8
HIL state vars from `_HILSignalsMixin.md` §1 (`approved`, `plan_approved`,
`plan_feedback_received`, `plan_feedback_comments`, `document_approved`,
`document_feedback_received`, `document_feedback_comments`, `cancelled`, all `False`/`""`). Then it
sets the following **five** AppWorkflow-local vars (⚠️ **`_gate_signals` is NO LONGER among them —
removed by #543**):

| Var | Type (literal annotation) | Initial | Set at line | Mutated by → value | When |
|-----|---------------------------|---------|-------------|--------------------|------|
| `_status` | `WorkflowStatus` | `WorkflowStatus.PENDING` | 63 | `run()` → `RUNNING` (80), then → `COMPLETED` (114) | run start; run end |
| `_current_line` | `AssemblyLine \| None` | `None` | 64 | `run()` → `AssemblyLine.DISCOVERY` (85), then → `None` (116) | Discovery start; Discovery complete |
| `_current_step` | `str` | `""` | 65 | `run()` → `"discovery"` (86), then → `"discovery_complete"` (115) | Discovery start; Discovery complete |
| `_started_at` | `str` | `""` | 66 | `run()` → `_now_iso()` (81) | run start; never changes after |
| `_updated_at` | `str` | `""` | 67 | `run()` → `_now_iso()` (82, 87, 117); every signal handler → `_now_iso()` | run start; each step; each signal |

> ⚠️ **GOTCHA-STATE0 (`_gate_signals` REMOVED at HEAD — this is the headline behavioral change):**
> the previous spec documented `_gate_signals: list[dict] = []` initialized in `__init__` and a
> `TODO(Phase 2): Forward gate signals to active child workflows` comment. **Both the field and the
> comment are GONE at HEAD** (PR #543 retired the dead accumulator). `__init__` now ends at
> `application.py:67` (`self._updated_at = ""`) with no further assignment. A rebuild MUST NOT
> declare `_gate_signals` (or any gate-payload buffer); doing so re-introduces dead state the
> codebase deliberately deleted, and would make `gate_approved`/`gate_rejected`/`override_approved`
> diverge from their HEAD no-op behavior.

> ⚠️ **GOTCHA-STATE2 (`_current_line` is an INSTANCE var, not a classvar):** unlike
> `LineWorkflowBase` which exposes `ASSEMBLY_LINE` as a `ClassVar` read by its `get_status`,
> `AppWorkflow` tracks the live line in the **instance** var `_current_line` and its `get_status`
> returns *that* (`application.py:171`). The value transitions `None → DISCOVERY → None`. A rebuild
> must make `get_status` read the instance var, and must reset it to `None` at completion
> (`application.py:116`) — a `get_status` after completion reports `current_line=None`, not
> `DISCOVERY`.

> ⚠️ **GOTCHA-STATE3 (`_status` transitions are owned by `run()` only):** no signal handler touches
> `_status`. The only writes are in `run()`: `PENDING` (init) → `RUNNING` (80) → `COMPLETED` (114).
> There is **no `WAITING_FOR_SIGNAL`, no `FAILED`, no `CANCELLED`** transition anywhere in this
> file. (Contrast `LineWorkflowBase._wait_for_gate_decision` which round-trips
> `WAITING_FOR_SIGNAL`/`RUNNING`/`CANCELLED`.) A rebuild must NOT add status transitions in
> handlers; `_status` is `RUNNING` for essentially the entire (brief) life of the workflow and
> flips to `COMPLETED` only at the final statement before `return`.

---

## 2. `run(self, input: AppWorkflowInput) -> str` — control flow (`application.py:70-118`)

Input type `AppWorkflowInput` (`types.py:1162-1172`): fields `app_id: str`, `app_name: str`,
`wave_id: str`, `portfolio_id: str`, `artifact_repo: str=""`, `disposition: Disposition|None=None`,
`risk_tier: RiskTier|None=None`, `complexity_tier: ComplexityTier|None=None`.

Returns the literal string `"completed"` (`application.py:118`).

### 2.1 Exact pseudocode (NO branches — strictly linear)

```text
async def run(self, input: AppWorkflowInput) -> str:        # application.py:70

    # ---- Phase: mark RUNNING, stamp start time ----
    self._status      = WorkflowStatus.RUNNING              # application.py:80
    self._started_at  = _now_iso()                          # application.py:81  (workflow.now().isoformat())
    self._updated_at  = self._started_at                    # application.py:82  (same value, NOT a 2nd now() call)

    # ---- Step 1: Discovery — set live progress vars ----
    self._current_line = AssemblyLine.DISCOVERY             # application.py:85
    self._current_step = "discovery"                        # application.py:86
    self._updated_at   = _now_iso()                         # application.py:87  (fresh now() — DISTINCT from line 82)

    # ---- Build the child input by field-copy from AppWorkflowInput → LineWorkflowInput ----
    discovery_input = LineWorkflowInput(                    # application.py:89-98
        app_id          = input.app_id,                     #   90
        app_name        = input.app_name,                   #   91
        wave_id         = input.wave_id,                    #   92
        portfolio_id    = input.portfolio_id,               #   93
        artifact_repo   = input.artifact_repo,              #   94
        disposition     = input.disposition,                #   95
        risk_tier       = input.risk_tier,                  #   96
        complexity_tier = input.complexity_tier,            #   97
    )
    # NOTE: source_repo, source_repos, target_repo_url, prior_artifacts,
    # peer_workflow_ids, target_framework/frontend, primary_language,
    # target_service_id, relationship, source_app_ids, tech_fingerprint
    # are LEFT AT THEIR LineWorkflowInput DEFAULTS (empty / None) — NOT
    # forwarded. See GOTCHA-RUN2.

    # ---- The single await: run Discovery as a CHILD workflow ----
    await workflow.execute_child_workflow(                  # application.py:100-105
        "DiscoveryWorkflow",                                #   101  (string name, not class ref)
        discovery_input,                                    #   102  (single positional arg)
        id            = f"discovery-{input.app_id}",        #   103  (deterministic child id)
        task_queue    = workflow.info().task_queue,         #   104  (inherit parent's queue)
    )
    # ^ no retry_policy, no execution_timeout, no parent_close_policy,
    #   no id_reuse_policy, no cancellation_type specified → all Temporal
    #   defaults. See GOTCHA-RUN3 / GOTCHA-RUN4.

    # ---- AppWorkflow STOPS after Discovery (by design) ----
    self._status       = WorkflowStatus.COMPLETED           # application.py:114
    self._current_step = "discovery_complete"               # application.py:115
    self._current_line = None                               # application.py:116  (clear the line)
    self._updated_at   = _now_iso()                         # application.py:117
    return "completed"                                      # application.py:118
```

### 2.2 Activity & child-workflow calls in order

There are **NO `execute_activity` calls** in `AppWorkflow`. The sole orchestration call is one
**child workflow**:

| # | Call | Type | Args | id | task_queue | retry / timeout / policies | Sequential/parallel |
|---|------|------|------|----|-----------|-----------------------------|---------------------|
| 1 | `"DiscoveryWorkflow"` | `execute_child_workflow` (`application.py:100`) | `discovery_input` (a `LineWorkflowInput`), single positional | `f"discovery-{input.app_id}"` (`application.py:103`) | `workflow.info().task_queue` (`application.py:104`) — **inherits parent queue** | **NONE specified** → Temporal defaults: default retry policy for child workflows, no execution timeout, `parent_close_policy=TERMINATE` (default), `id_reuse_policy=ALLOW_DUPLICATE` (default) | single (the only call; `run()` blocks on it) |

> ⚠️ **GOTCHA-RUN1 (`await execute_child_workflow` blocks until the child COMPLETES):** the
> coroutine returned by `execute_child_workflow(...)` is awaited directly (`application.py:100`),
> so `run()` does NOT proceed to the `COMPLETED` transition until `DiscoveryWorkflow` finishes.
> (Contrast `start_child_workflow`, which returns a handle without waiting — NOT used here.) The
> return value of the child is **discarded** — `run()` does not bind it. A rebuild MUST `await` the
> execution (not `start_`), and MUST NOT depend on the child's return value.

> ⚠️ **GOTCHA-RUN2 (selective field forwarding — only 8 of `LineWorkflowInput`'s fields are set):**
> `discovery_input` copies exactly `app_id, app_name, wave_id, portfolio_id, artifact_repo,
> disposition, risk_tier, complexity_tier` (`application.py:90-97`). All other `LineWorkflowInput`
> fields — `source_repo` (`types.py:1184`), `source_repos` (`types.py:1193`), `target_repo_url`
> (`types.py:1202`), `prior_artifacts` (`types.py:1206`), `peer_workflow_ids` (`types.py:1212`),
> `target_framework`/`target_frontend`/`primary_language` (`types.py:1221-1223`), `target_service_id`
> (`types.py:1231`), `relationship` (`types.py:1235`), `source_app_ids` (`types.py:1240`),
> `tech_fingerprint` (`types.py:1250`) — are left at their dataclass defaults (empty strings /
> `None` / empty collections). This is correct: Discovery is the first line and needs none of the
> target/consolidate routing context. A rebuild MUST forward exactly these 8 fields and leave the
> rest defaulted; forwarding extra fields would change the serialized child input payload and the
> child's behavior.

> ⚠️ **GOTCHA-RUN3 (deterministic child id `discovery-{app_id}`):** the child id is
> `f"discovery-{input.app_id}"` (`application.py:103`). This is deterministic and stable across
> replay (no `uuid`, no timestamp). It also collides intentionally with the id the rest of the
> platform expects for an app's Discovery run (other code references `discovery-{app_id}`). A
> rebuild MUST use this exact template. ⚠️ Because the default `id_reuse_policy` is
> `ALLOW_DUPLICATE`, re-running `AppWorkflow` for the same `app_id` after the prior Discovery
> closed will start a *new* `discovery-{app_id}` execution; a rebuild must not silently switch to
> `REJECT_DUPLICATE` / `ALLOW_DUPLICATE_FAILED_ONLY`.

> ⚠️ **GOTCHA-RUN4 (child inherits the parent's task queue):** `task_queue =
> workflow.info().task_queue` (`application.py:104`) pins `DiscoveryWorkflow` to the SAME queue
> `AppWorkflow` is running on. A rebuild MUST read it from `workflow.info()`, not hard-code a queue
> name — the platform runs workers that register both workflows on one queue, and pinning is what
> keeps a child schedulable on the same worker fleet.

> ⚠️ **GOTCHA-RUN5 (workflow name is a STRING literal, not a class import):**
> `"DiscoveryWorkflow"` (`application.py:101`) is passed by name, not as `DiscoveryWorkflow` the
> class. This deliberately avoids importing the `DiscoveryWorkflow` symbol into `application.py`
> (no import exists for it). A rebuild MUST register `DiscoveryWorkflow` under exactly the string
> `"DiscoveryWorkflow"` on the worker, or the child start fails with "workflow type not registered".

> ⚠️ **GOTCHA-RUN6 (two `_now_iso()` calls vs one shared value):** line 82 sets
> `_updated_at = self._started_at` (reuses the line-81 value — they are byte-identical), but line 87
> calls `_now_iso()` **again** (a distinct `workflow.now()` read) and line 117 a third time. Under
> Temporal replay each `workflow.now()` call returns the time of the workflow-task that first
> executed it, so the three timestamps may differ. A rebuild must keep this exact call pattern:
> `_started_at`/first `_updated_at` share one value; the Discovery-start `_updated_at` and the
> completion `_updated_at` are separate `_now_iso()` calls. Collapsing them to a single timestamp
> would change observable `get_status` output.

> ⚠️ **GOTCHA-CANCEL (this workflow is effectively un-cancellable via `cancel_workflow`):** `run()`
> never reads `self.cancelled`. The inherited `cancel_workflow` signal still sets
> `self.cancelled = True` (HIL mixin GOTCHA-1/GOTCHA-5), but because `run()` has no
> `wait_condition` that ORs in `self.cancelled` and only awaits the child workflow, a
> `cancel_workflow` signal does **nothing** to the control flow — the workflow still proceeds to
> completion once Discovery returns. (True cancellation would have to come via Temporal's native
> `handle.cancel()` raising `CancelledError` through the child await, NOT via the HIL signal.) A
> rebuild MUST reproduce this: do NOT add a `self.cancelled` check to `run()`; the HIL
> `cancel_workflow` signal is inherited-but-inert here. This is a real behavioral property, not a
> bug to fix.

---

## 3. SIGNALS — six locally-defined handlers (`@workflow.signal`), all now PURE no-ops

⚠️ **HEAD CHANGE:** at HEAD, **all six** locally-defined signal handlers have **identical bodies**:
a single `self._updated_at = _now_iso()` statement. The pre-#543 distinction between three
"buffering" handlers (gate_approved/gate_rejected/override_approved) and three "no-op" handlers is
GONE — there is no `_gate_signals` buffer anymore, so there is nothing to append to. Every handler
is an accept-and-ignore timestamp bump.

All six are **`async def`** (matching the base-style gate signals, NOT the synchronous HIL mixin
signals). Each performs only the `_updated_at` mutation; none `await`, none call any activity, none
read other state, none have conditionals. Temporal registers each under its **method name** as the
wire signal name.

The shared design rationale is documented at `application.py:124-130` (P5-S30.6, decided
2026-06-09): *"Gate-decision signals. Accepted but intentionally inert … AppWorkflow runs Discovery
and exits — it awaits no gates of its own. The gate-bearing child (DiscoveryWorkflow) owns and
awaits its gate, and the API signals THAT workflow directly by the `workflow_id` on the gate row.
These handlers are kept so a mis-addressed signal is a benign no-op rather than an unhandled-signal
error; they store nothing because nothing here consumes the state."*

### 3.1 `gate_approved(self, signal: GateApprovedSignal) -> None` — `application.py:131-134`

Payload `GateApprovedSignal` (`olympus_contracts/signals.py:25-43`): `gate_id: str`,
`approved_by: str`, `justification: str=""`, `card_decisions: List[dict]=[]` (`signals.py:42`),
`reviewer_notes: Optional[str]=None` (`signals.py:43`).

```text
async def gate_approved(self, signal):                      # application.py:131
    """Accept-and-ignore: the gate-owning child is signalled directly."""
    self._updated_at = _now_iso()                           # application.py:134
```

**PURE no-op except `_updated_at` bump.** Does NOT read or store any field of `signal`.

⚠️ **GOTCHA-SIG-APP1 (CHANGED — no longer buffers a dict):** the previous spec said this handler
appended a 6-key dict (`{"type":"approved", gate_id, approved_by, justification, card_decisions,
reviewer_notes}`) to `_gate_signals`. **At HEAD it does none of that** — the entire dict-build was
deleted by #543. A rebuild MUST NOT re-introduce any append; the body is exactly the one
`_updated_at` line. The `signal.card_decisions` / `signal.reviewer_notes` fields still exist on the
dataclass but `AppWorkflow` no longer touches them.

### 3.2 `gate_rejected(self, signal: GateRejectedSignal) -> None` — `application.py:136-139`

Payload `GateRejectedSignal` (`olympus_contracts/signals.py:47-68`): `gate_id: str`,
`rejected_by: str`, `reason: str`, `reason_category: Optional[str]=None` (`signals.py:66`),
`card_decisions: List[dict]=[]` (`signals.py:67`), `reviewer_notes: Optional[str]=None`
(`signals.py:68`).

```text
async def gate_rejected(self, signal):                      # application.py:136
    """Accept-and-ignore: the gate-owning child is signalled directly."""
    self._updated_at = _now_iso()                           # application.py:139
```

**PURE no-op except `_updated_at` bump.** Does NOT read or store any field of `signal`.

⚠️ **GOTCHA-SIG-REJ1 (CHANGED — no longer buffers a dict):** the previous spec said this handler
appended a 6-key dict (omitting `reason_category`) to `_gate_signals`. **At HEAD it does none of
that** — the dict-build was deleted by #543. The old GOTCHA about "`reason_category` is not
buffered" is moot because nothing is buffered. A rebuild's body is exactly the one `_updated_at`
line.

### 3.3 `override_approved(self, signal: OverrideApprovedSignal) -> None` — `application.py:141-144`

Payload `OverrideApprovedSignal` (`types.py:144-151`): `gate_id: str`, `override_by: str`,
`justification: str`, `override_type: OverrideType` (`types.py:151`).

```text
async def override_approved(self, signal):                  # application.py:141
    """Accept-and-ignore: see the gate-signal note above."""
    self._updated_at = _now_iso()                           # application.py:144
```

**PURE no-op except `_updated_at` bump.** Does NOT read or store any field of `signal`.

⚠️ **GOTCHA-SIG-OVR1 (CHANGED — no longer buffers a dict):** the previous spec said this handler
appended a 4-key dict (`{"type":"override", gate_id, override_by, justification}`) to
`_gate_signals`. **At HEAD it does none of that** — deleted by #543. A rebuild's body is exactly the
one `_updated_at` line; `override_type` (and every other field) is simply ignored.

### 3.4 `escalation_resolved(self, signal: EscalationResolvedSignal) -> None` — `application.py:146-149`

Payload `EscalationResolvedSignal` (`types.py:154-161`): `escalation_id: str`, `resolved_by: str`,
`resolution_type: ResolutionType`, `resolution: str`.

```text
async def escalation_resolved(self, signal):                # application.py:146
    """Handle escalation resolution — currently stores for later use."""
    self._updated_at = _now_iso()                           # application.py:149
```

**No-op except `_updated_at` bump.** Mirrors `LineWorkflowBase.escalation_resolved` behavior
(`_LineWorkflowBase.md` §3.3 / GOTCHA-SIG3) — same effect, locally defined here. The docstring
(`application.py:148`) says "currently stores for later use" but the body stores nothing beyond the
timestamp. A rebuild reproduces exactly the `_updated_at` bump and nothing else.

### 3.5 `stakeholder_approved(self, signal: StakeholderApprovedSignal) -> None` — `application.py:151-154`

Payload `StakeholderApprovedSignal` (`types.py:164-170`): `approval_id: str`, `stakeholder: str`,
`scope: str`.

```text
async def stakeholder_approved(self, signal):               # application.py:151
    """Store stakeholder approval signal."""
    self._updated_at = _now_iso()                           # application.py:154
```

**No-op except `_updated_at` bump.** (Docstring says "Store stakeholder approval signal" but it
stores only the timestamp — `application.py:153-154`.) A rebuild reproduces only the `_updated_at`
bump.

### 3.6 `wave_patterns_ready(self, signal: WavePatternsReadySignal) -> None` — `application.py:156-159`

Payload `WavePatternsReadySignal` (`types.py:182-187`): `wave_id: str`,
`patterns: list[str]=[]` (`types.py:187`).

```text
async def wave_patterns_ready(self, signal):                # application.py:156
    """Handle wave patterns ready signal — currently a no-op."""
    self._updated_at = _now_iso()                           # application.py:159
```

**Explicit no-op except `_updated_at` bump** (docstring `application.py:158`: "currently a
no-op"). A rebuild reproduces only the `_updated_at` bump.

> ⚠️ **GOTCHA-SIG-DOC (docstrings overstate three handlers, but the bodies are uniform):**
> `gate_approved`/`gate_rejected` docstrings say "Accept-and-ignore"; `escalation_resolved` says
> "stores for later use"; `stakeholder_approved` says "Store …". **All six bodies are identical
> one-line `_updated_at` bumps.** **The code is authoritative.** A rebuild must NOT add any
> buffering to ANY of the six based on docstring prose — none of them store anything beyond the
> timestamp at HEAD.

> ⚠️ **GOTCHA-SIG-ASYNC (handlers are `async def` but never `await`):** all six are declared
> `async def` (`application.py:131,136,141,146,151,156`) yet contain no `await`. Temporal requires
> the signal *coroutine* but the bodies complete synchronously within a single workflow task. A
> rebuild MUST declare them `async def` to match registration semantics; the absence of an `await`
> inside is fine and matches the source. (The inherited HIL signals, by contrast, are plain `def`
> — `_HILSignalsMixin.md` §2 — so `AppWorkflow` mixes sync inherited and async local signals; both
> are valid.)

> ⚠️ **GOTCHA-SIG-DETERMINISM (`_now_iso()` inside signal handlers):** every handler calls
> `_now_iso()` → `workflow.now()` (`application.py:134,139,144,149,154,159`). This is the only
> not-purely-attribute operation in the handlers and is deterministic under replay (`workflow.now()`
> is replay-safe). A rebuild MUST use `workflow.now()`, never `datetime.now()`, inside the handlers.

---

## 4. QUERIES — one local query handler

### 4.1 `get_status(self) -> WorkflowStatusResponse` — `application.py:165-176`

Synchronous (`def`, not `async`), read-only — Temporal queries must not mutate state, and this one
does not. Registered under the wire name `get_status`.

```text
@workflow.query
def get_status(self) -> WorkflowStatusResponse:             # application.py:165-166
    return WorkflowStatusResponse(                          # application.py:168
        workflow_id  = workflow.info().workflow_id,         # application.py:169
        status       = self._status,                        # application.py:170
        current_line = self._current_line,                  # application.py:171  ← INSTANCE var (None / DISCOVERY / None)
        current_step = self._current_step,                  # application.py:172
        progress_pct = 100.0 if self._status == WorkflowStatus.COMPLETED else 0.0,   # application.py:173  ★ TERNARY
        started_at   = self._started_at,                    # application.py:174
        updated_at   = self._updated_at,                    # application.py:175
    )
```

`WorkflowStatusResponse` fields (`types.py:394-404`): `workflow_id`, `status`,
`current_line=None` (`types.py:399`), `current_step=""` (400), `progress_pct=0.0` (401),
`pending_gate=None` (402), `started_at=""` (403), `updated_at=""` (404).

⚠️ **GOTCHA-Q-PROGRESS (binary progress — 0% or 100%, nothing in between):** the only branch-like
construct in the file is the conditional expression `100.0 if self._status ==
WorkflowStatus.COMPLETED else 0.0` (`application.py:173`). So `get_status` reports `progress_pct =
0.0` for the entire PENDING+RUNNING lifetime and `100.0` the instant `_status` becomes `COMPLETED`.
There is **no fractional progress** (contrast `LineWorkflowBase` which reads
`self._progress_pct` set by `_set_step` from `STEP_WEIGHTS`). A rebuild MUST reproduce the exact
ternary keyed on `_status == COMPLETED`; do not compute weighted progress.

⚠️ **GOTCHA-Q-PENDINGGATE (`pending_gate` is NEVER set → always defaults to `None`):**
`get_status` does NOT pass `pending_gate`, so it takes the `WorkflowStatusResponse` default `None`
(`types.py:402`). `AppWorkflow` never waits on a gate, so this is correct — a dashboard polling
`AppWorkflow.get_status` always sees `pending_gate=None`. (Contrast the base `get_status` which
passes `pending_gate=self._pending_gate`.) A rebuild must omit `pending_gate` (or pass `None`).

⚠️ **GOTCHA-Q-CURRENTLINE (read from instance var, not classvar):** see GOTCHA-STATE2.
`current_line = self._current_line` (`application.py:171`) — reflects the live `None → DISCOVERY →
None` transition. After `run()` completes, a query returns `current_line=None`,
`current_step="discovery_complete"`, `status=COMPLETED`, `progress_pct=100.0`. A rebuild must wire
the instance var here.

⚠️ **GOTCHA-Q-NOREDEF-NOTAPPLICABLE:** `_LineWorkflowBase.md` GOTCHA-Q1 forbids subclasses from
redefining `get_status`. That rule does NOT apply to `AppWorkflow` — it is NOT a `LineWorkflowBase`
subclass, so there is no inherited `get_status` to collide with. Defining `get_status` here
(`application.py:165`) is the **only** registration of that query for this workflow and is correct.
A rebuild defines it locally.

---

## 5. `_now_iso()` — module-level time helper (`application.py:179-181`)

```text
def _now_iso() -> str:                                      # application.py:179
    """Return current time as ISO string — deterministic via workflow.now()."""
    return workflow.now().isoformat()                       # application.py:181
```

Identical in spirit to `LineWorkflowBase._now_iso()` but defined **at module scope in
`application.py`**, not on a class. Deterministic under replay. Used by `run()` (×3 fresh calls + 1
reuse of `_started_at`) and all six signal handlers. ⚠️ A rebuild MUST use
`workflow.now().isoformat()`, never `datetime.now()` / `datetime.utcnow()` — wall-clock would break
determinism on replay.

---

## 6. RESILIENCE summary

- **Timeouts:** none configured. The single child-workflow call (`application.py:100-105`) sets no
  `execution_timeout` / `run_timeout` / `task_timeout` — Discovery runs under Temporal defaults
  (effectively unbounded execution). There are no activities, hence no `start_to_close` timeouts.
- **Retry policies:** none specified on the child call → Temporal's default child-workflow retry
  policy applies. `RETRY_POLICIES` is imported (`application.py:26`) but is `# noqa: F401`
  (imported-for-side-effect / future use) and **never referenced** in this file. A rebuild keeps
  the import but does not wire a retry policy onto the child.
- **Heartbeats:** N/A (no activities).
- **continue-as-new:** none. `run()` is short and terminates after one child; no history-size
  pressure. A rebuild must NOT add continue-as-new.
- **Idempotency / determinism:** the child id `discovery-{app_id}` is deterministic
  (GOTCHA-RUN3); `task_queue` is read from `workflow.info()` (GOTCHA-RUN4); all timestamps use
  `workflow.now()` (GOTCHA-SIG-DETERMINISM); `run()` is branch-free with a single yield point
  (GOTCHA-BRANCH). Replay history is fixed: *start → execute_child(DiscoveryWorkflow) → complete*.
- **Cancellation:** the HIL `cancel_workflow` signal sets `self.cancelled=True` but `run()` never
  reads it → inert (GOTCHA-CANCEL). Native Temporal cancellation (`handle.cancel()`) would raise
  through the child `await`, but no `try/except CancelledError` exists here, so cancellation would
  propagate as a workflow failure/cancellation with no cleanup. There is **no compensation /
  rollback** path — nothing to roll back (no DB writes, no commits, no merges in this workflow).
- **Failure semantics:** if `DiscoveryWorkflow` fails (after its own retries), the child
  `await` raises a `ChildWorkflowError` out of `run()`; `AppWorkflow` does NOT catch it (no
  `try/except`), so `AppWorkflow` itself fails. `_status` is left at `RUNNING` (the
  `COMPLETED` transition at lines 114-116 is never reached). ⚠️ **GOTCHA-FAIL:** there is
  no `WorkflowStatus.FAILED` write anywhere — on child failure a `get_status` query (still
  answerable while the workflow is failing/in retry) reports `status=RUNNING`,
  `current_line=DISCOVERY`, `progress_pct=0.0`. A rebuild MUST NOT add a `FAILED` projection or a
  catch-all `try/except` around the child call — neither exists in this version.

---

## 7. Behavioral parity checklist

A rebuilt `AppWorkflow` MUST satisfy ALL of the following (✅ items 10–14 are the ones that CHANGED
at HEAD vs the prior spec):

1. **Inheritance:** `@workflow.defn class AppWorkflow(HILSignalsMixin)` — extends `HILSignalsMixin`
   **directly** (imported from `foundry_temporal.signals`, `application.py:22`), NOT
   `LineWorkflowBase`. `__init__` calls `super().__init__()` first (initializes the 8 HIL state
   vars), then sets `_status=PENDING`, `_current_line=None`, `_current_step=""`, `_started_at=""`,
   `_updated_at=""`. **No `_gate_signals`.** (§1, GOTCHA-INHERIT, GOTCHA-STATE0)
2. **Inherited HIL signals are live:** `approve`, `cancel_workflow`, `approve_plan`,
   `provide_plan_feedback`, `approve_research`, `provide_feedback` are reachable via inheritance and
   are NOT redefined. (GOTCHA-HIL)
3. **`run()` is strictly linear — zero branches, zero loops, zero try/except, exactly one
   `await`.** Sequence: set `_status=RUNNING`; `_started_at=_now_iso()`;
   `_updated_at=_started_at`; set `_current_line=DISCOVERY`, `_current_step="discovery"`,
   `_updated_at=_now_iso()`; build `discovery_input`; `await execute_child_workflow(...)`; set
   `_status=COMPLETED`, `_current_step="discovery_complete"`, `_current_line=None`,
   `_updated_at=_now_iso()`; `return "completed"`. (§2.1, GOTCHA-BRANCH)
4. **Child call:** `await workflow.execute_child_workflow("DiscoveryWorkflow", discovery_input,
   id=f"discovery-{input.app_id}", task_queue=workflow.info().task_queue)` — string workflow name,
   single positional `LineWorkflowInput` arg, deterministic id, inherited task queue, NO retry
   policy / NO timeouts / NO id_reuse_policy specified. `await` (blocks until child completes);
   child return value discarded. (§2.2, GOTCHA-RUN1/RUN3/RUN4/RUN5)
5. **`discovery_input` field forwarding:** copies exactly `app_id, app_name, wave_id, portfolio_id,
   artifact_repo, disposition, risk_tier, complexity_tier` from `AppWorkflowInput` into a
   `LineWorkflowInput`; all other `LineWorkflowInput` fields left at defaults. (GOTCHA-RUN2)
6. **Returns the literal string `"completed"`.** (`application.py:118`)
7. **`_status` transitions PENDING→RUNNING→COMPLETED ONLY, all inside `run()`.** No
   `WAITING_FOR_SIGNAL`, `FAILED`, or `CANCELLED` write anywhere. No handler mutates `_status`.
   (GOTCHA-STATE3)
8. **`_current_line` is an instance var transitioning `None → DISCOVERY → None`** (set to `None` at
   completion, `application.py:116`). (GOTCHA-STATE2)
9. **Exactly SIX locally-defined `@workflow.signal` handlers, all `async def`:** `gate_approved`,
   `gate_rejected`, `override_approved`, `escalation_resolved`, `stakeholder_approved`,
   `wave_patterns_ready`. **No `merge_retry` signal exists.** (§0, §3)
10. ✅ **CHANGED — `gate_approved` is now a PURE no-op:** body is exactly `self._updated_at =
    _now_iso()`. It does NOT append to any buffer (the old `_gate_signals` dict-append was removed by
    #543). (§3.1, GOTCHA-SIG-APP1)
11. ✅ **CHANGED — `gate_rejected` is now a PURE no-op:** body is exactly `self._updated_at =
    _now_iso()`. No dict, no buffer. (§3.2, GOTCHA-SIG-REJ1)
12. ✅ **CHANGED — `override_approved` is now a PURE no-op:** body is exactly `self._updated_at =
    _now_iso()`. No dict, no buffer. (§3.3, GOTCHA-SIG-OVR1)
13. **`escalation_resolved`, `stakeholder_approved`, `wave_patterns_ready`** each do ONLY
    `_updated_at = _now_iso()` — they do NOT buffer anything (despite docstrings). (§3.4–3.6,
    GOTCHA-SIG-DOC)
14. ✅ **CHANGED — `_gate_signals` DOES NOT EXIST:** all six locally-defined signals are uniform
    timestamp-bump no-ops; no gate-payload buffer is declared or written anywhere. A rebuild MUST NOT
    re-introduce `_gate_signals` or any dict-append. (GOTCHA-STATE0, GOTCHA-SIG-DOC)
15. **`get_status` is a synchronous `@workflow.query`**, locally defined, read-only, returning
    `WorkflowStatusResponse(workflow_id=workflow.info().workflow_id, status=self._status,
    current_line=self._current_line, current_step=self._current_step, progress_pct=(100.0 if
    self._status==COMPLETED else 0.0), started_at=self._started_at, updated_at=self._updated_at)`.
    `pending_gate` is NOT passed (defaults to `None`). (§4.1, GOTCHA-Q-PROGRESS/PENDINGGATE/CURRENTLINE)
16. **`progress_pct` is binary** — `100.0` iff `_status == COMPLETED`, else `0.0`. No fractional
    progress. (GOTCHA-Q-PROGRESS)
17. **`_now_iso()`** is a module-level function returning `workflow.now().isoformat()`; used by
    `run()` (three distinct calls + one reuse of `_started_at`) and all six handlers; never
    `datetime.now()`. (§5, GOTCHA-RUN6, GOTCHA-SIG-DETERMINISM)
18. **`cancel_workflow` is inert** for control flow — `run()` never reads `self.cancelled`; no
    `wait_condition` exists. (GOTCHA-CANCEL)
19. **No activities, no retry policy wired, no timeouts, no continue-as-new, no try/except, no
    compensation.** `RETRY_POLICIES` is imported but unused. (§6)
20. **On child (`DiscoveryWorkflow`) failure**, the error propagates out of `run()` (no catch) and
    `AppWorkflow` fails with `_status` still `RUNNING`; no `FAILED` projection. (GOTCHA-FAIL)
