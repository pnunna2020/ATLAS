# `DeploymentWorkflow` — Deployment Assembly Line (ATOMIC regeneration spec)

> **Source of truth:** `temporal/olympus_workflows/workflows/deployment.py` (1291 lines).
> Every `deployment.py:line` citation is against that file.
>
> **Inherits:** `class DeploymentWorkflow(LineWorkflowBase)` (`deployment.py:264-265`).
> `LineWorkflowBase(HILSignalsMixin)`. For all inherited engine behavior — `_dispatch_agent`,
> `_commit_step_artifacts`, `_create_gate_pr`, `_submit_gate_evidence`, `_run_gate_pre_review`,
> `_wait_for_gate_decision`, `_reconcile_and_merge_with_retry_loop`, `_set_step`,
> `_update_app_status`, `_build_evidence_data`, `get_status`, `_rework_count`/`_bump_rework`,
> the four base gate signals (`gate_approved`/`gate_rejected`/`escalation_resolved`/`merge_retry`),
> and the six HIL signals — see `_LineWorkflowBase.md` and `_HILSignalsMixin.md`. This spec
> reproduces ONLY what `DeploymentWorkflow` adds or overrides.
>
> **What this workflow is:** the per-application Deployment line. It runs AFTER Validation
> (modernization path → `ValidationApprovedSignal`) or AFTER Disposition Execution
> (non-modernization path → `DispositionExecutedSignal`). The reconciled shape (W19 Deployment,
> P5-S19.21) is a **canonical 18-step sequence** with per-disposition-path branching at intake.
> Two gates: **G-DP-1 (Cutover Go)** and **G-DP-2 (Deployment Complete)**, each with a Tier-1
> triple-signal augmentation on top of the base PM `gate_approved`. Two rework loops (max 3
> iterations each). Returns the literal string `"completed"`, `"cancelled"`, or `"failed"`.

---

## 0. Module-level constants & helper (`deployment.py:74-261`, `1264-1291`)

These are read by the workflow body. A rebuild MUST reproduce the exact values and the
helper's branch behavior.

| Constant | Value | Source | Used by |
|----------|-------|--------|---------|
| `DEPLOYMENT_STEPS` | dict of 6 agent steps → `{title, skill_id, artifact}` | `deployment.py:115-149` | `STEPS` classvar; `_run_deploy_and_shift`, `_run_gdp1_with_rework`, `_run_gdp2_with_rework` build `artifact_path` |
| `PRIMARY_STEP_ORDER` | `["orchestration","traffic-shifting","parallel-run","adoption-verification","legacy-decommission","cost-certification"]` | `deployment.py:154-161` | `_inputs_for_step` prior-artifact accumulation; G-DP-2 `evidence_steps` |
| `CANONICAL_STEP_ORDER` | 18-element list (see below) | `deployment.py:169-188` | `PATH_ACTIVE_STEPS` default; `_progress_for_gate`; intake `active_steps` |
| `PATH_ACTIVE_STEPS` | dict: 5 dispositions → full 18; `Retire` → 9-step subset | `deployment.py:194-214` | intake to compute `active_steps` |
| `STEP_WEIGHTS` | 18 keys summing to 100.0 | `deployment.py:220-239` | `STEP_WEIGHTS` classvar; cumulative-progress arithmetic; `_progress_for_gate` |
| `PARALLEL_RUN_DAYS` | `{1:90, 2:30, 3:14}` | `deployment.py:246-250` | `_parallel_run_days()` |
| `DEFAULT_PARALLEL_RUN_DAYS` | `30` | `deployment.py:251` | `_parallel_run_days()` fallback |
| `MAX_REWORK_ITERATIONS` | `3` | `deployment.py:253` | both rework loops |
| `ENTRY_SIGNAL_WAIT_SECONDS` | `30 * 60` = 1800 | `deployment.py:261` | `_resolve_entry_path` timeout |

### 0.1 `DEPLOYMENT_STEPS` exact content (`deployment.py:115-149`)
```text
"orchestration":          {title:"Deployment Orchestration",      skill_id:"deploy-modernized-app",       artifact:"deployment-manifest.json"}
"traffic-shifting":       {title:"Traffic Shifting",             skill_id:"traffic-shift",               artifact:"traffic-shift-log.json"}
"parallel-run":           {title:"Parallel Run",                 skill_id:"parallel-run-monitor",        artifact:"parallel-run-report.json"}
"adoption-verification":  {title:"Adoption Verification",        skill_id:"adoption-analytics",          artifact:"adoption-verification.json"}
"legacy-decommission":    {title:"Legacy Decommission",          skill_id:"legacy-decommission",         artifact:"decommission-certificate.json"}
"cost-certification":     {title:"Cost Savings Certification",   skill_id:"tco-analyzer",                artifact:"cost-savings-certification.json"}
```
⚠️ **GOTCHA-STEPS (only 6 of 18 steps are in `DEPLOYMENT_STEPS`):** `STEPS` carries only the
agent-dispatch steps. The 12 code/git/gate steps (`intake`, `bundle-g-dp*-evidence`,
`create-g-dp*-pr`, `ai-pre-review-dp*`, `gate-review-dp*`, `merge-*-pr`,
`persist-deployment-side-effects`) are NOT in `STEPS` — they are handled inline. But ALL 18 ARE
in `STEP_WEIGHTS` and `CANONICAL_STEP_ORDER`. A rebuild that puts the inline steps into `STEPS`
would break `_build_evidence_data` (it iterates `STEPS.items()` via `_evidence_steps_iter`,
which Deployment does NOT override) by emitting evidence cards for non-agent steps.

### 0.2 `CANONICAL_STEP_ORDER` (`deployment.py:169-188`)
```text
[ "intake"(1), "orchestration"(2), "traffic-shifting"(3), "parallel-run"(4),
  "adoption-verification"(5), "bundle-g-dp1-evidence"(6), "create-g-dp1-pr"(7),
  "ai-pre-review-dp1"(8), "gate-review-dp1"(9), "merge-g-dp1-pr"(10),
  "legacy-decommission"(11), "cost-certification"(12), "bundle-g-dp2-evidence"(13),
  "create-g-dp2-pr"(14), "ai-pre-review-dp2"(15), "gate-review-dp2"(16),
  "persist-deployment-side-effects"(17), "merge-final-gate-pr"(18) ]
```

### 0.3 `PATH_ACTIVE_STEPS` (`deployment.py:194-214`)
```text
"Refactor"   -> list(CANONICAL_STEP_ORDER)        # all 18
"Rearchitect"-> list(CANONICAL_STEP_ORDER)        # all 18
"Replace"    -> list(CANONICAL_STEP_ORDER)        # all 18
"Replatform" -> list(CANONICAL_STEP_ORDER)        # all 18
"Consolidate"-> list(CANONICAL_STEP_ORDER)        # all 18
"Retire"     -> [ "intake"(1), "legacy-decommission"(11), "cost-certification"(12),
                  "bundle-g-dp2-evidence"(13), "create-g-dp2-pr"(14), "ai-pre-review-dp2"(15),
                  "gate-review-dp2"(16), "persist-deployment-side-effects"(17),
                  "merge-final-gate-pr"(18) ]    # SKIPS steps 2-10 entirely
```
⚠️ **GOTCHA-RETIRE (Retire skips Steps 2-10 = no deploy, no G-DP-1):** Retire's active set omits
orchestration / traffic-shifting / parallel-run / adoption-verification AND the entire G-DP-1
gate (steps 6-10). The control flow tests `if "orchestration" in active_steps`
(`deployment.py:455`) — for Retire this is False, so `_run_deploy_and_shift` AND
`_run_gdp1_with_rework` are both skipped; Retire jumps straight to the G-DP-2 loop. There is NO
"Retain" key — Retain never reaches Deployment (it exits at Disposition's G-DE-1). A `dict.get`
with a full-canonical default (`deployment.py:445-447`) means ANY unknown disposition label runs
all 18 steps.

### 0.4 `STEP_WEIGHTS` (`deployment.py:220-239`) — sum to 100.0
```text
intake 2.0 | orchestration 10.0 | traffic-shifting 10.0 | parallel-run 14.0 |
adoption-verification 12.0 | bundle-g-dp1-evidence 2.0 | create-g-dp1-pr 2.0 |
ai-pre-review-dp1 2.0 | gate-review-dp1 6.0 | merge-g-dp1-pr 2.0 |
legacy-decommission 12.0 | cost-certification 10.0 | bundle-g-dp2-evidence 2.0 |
create-g-dp2-pr 2.0 | ai-pre-review-dp2 2.0 | gate-review-dp2 6.0 |
persist-deployment-side-effects 2.0 | merge-final-gate-pr 2.0
```

### 0.5 Module helper `_parallel_run_days(input_tier, resolved_tier=None) -> int` (`deployment.py:1264-1290`)
```text
def _parallel_run_days(input_tier, resolved_tier=None):
    candidates = [resolved_tier, input_tier]          # deployment.py:1281  ← resolved FIRST
    for candidate in candidates:                      # deployment.py:1282  LOOP
        if candidate is None:                         # deployment.py:1283  BRANCH
            continue                                  # deployment.py:1284
        try:
            tier = int(candidate)                     # deployment.py:1286
        except (TypeError, ValueError):               # deployment.py:1287  BRANCH
            continue                                  # deployment.py:1288  ← unparseable → next candidate
        return PARALLEL_RUN_DAYS.get(tier, DEFAULT_PARALLEL_RUN_DAYS)   # deployment.py:1289
    return DEFAULT_PARALLEL_RUN_DAYS                  # deployment.py:1290  ← both None/unparseable
```
- **4 branch points:** the `for` loop (1282); `if candidate is None: continue` (1283); the
  `except (TypeError, ValueError): continue` (1287); the implicit fall-through `return` (1290).
- ⚠️ **GOTCHA-PRD1 (resolved_tier wins over input_tier):** `[resolved_tier, input_tier]` order
  (`deployment.py:1281`) means the workflow's signal-resolved `self._risk_tier` takes precedence
  over `input.risk_tier`. The caller in `_run_deploy_and_shift` passes
  `_parallel_run_days(input.risk_tier, self._risk_tier)` (`deployment.py:652-654`) — note the
  POSITIONAL order is `(input_tier=input.risk_tier, resolved_tier=self._risk_tier)`, and inside
  the helper `resolved_tier` is checked first. A rebuild MUST preserve this precedence or a
  Tier-1 modernization run that resolved tier from a signal could pick the wrong duration.
- ⚠️ **GOTCHA-PRD2 (`int()` accepts `RiskTier` enum):** `RiskTier` is a `str`-enum;
  `int(RiskTier.TIER_1)` works only if the enum's value is an int-coercible string. The
  `try/except (TypeError, ValueError)` catches the case where it isn't and falls through to the
  next candidate, eventually `DEFAULT_PARALLEL_RUN_DAYS=30`. A rebuild keeps the try/except.

---

## 1. CLASSVAR configuration (`deployment.py:276-281`)

| Classvar | Value | Note |
|----------|-------|------|
| `ASSEMBLY_LINE` | `AssemblyLine.DEPLOYMENT` | drives `get_status().current_line` |
| `ARTIFACT_ROOT` | `"deployment"` | path prefix for commits + PR labels |
| `LINE_LABEL` | `"Deployment"` | `_set_step` line name; `_execution_ctx` line_id → `"deployment"` |
| `STATUS_PREFIX` | `"deployment"` | DB status → `deployment_in_progress` |
| `STEPS` | `DEPLOYMENT_STEPS` | the 6 agent steps |
| `STEP_WEIGHTS` | `STEP_WEIGHTS` (module) | 18 weights |

> ⚠️ **GOTCHA-CV (`SINGLE_GATE_KEY` NOT set → base default returns None, but this subclass
> OVERRIDES `_rework_gate_key_for_step`):** Deployment does not set `SINGLE_GATE_KEY`, so the
> base default would return `None`. But Deployment is MULTI-gate (G-DP-1 + G-DP-2) and OVERRIDES
> `_rework_gate_key_for_step` (§5). So `_dispatch_agent`'s rework-feedback forwarding uses the
> override, not `None`. (See §5 and `_LineWorkflowBase.md` §4.2 / GOTCHA-H1.)

---

## 2. STATE — instance vars added in `__init__` (`deployment.py:283-320`)

`__init__` calls `super().__init__()` first (`deployment.py:284`), initializing all 8 HIL vars +
19 base line vars, THEN sets these 12 Deployment-specific vars:

| Var | Type | Initial | Line | Mutated by → value | When |
|-----|------|---------|------|---------------------|------|
| `_bundle_approvals` | `list[dict[str,str]]` | `[]` | 287 | `_run_gate` appends `{gate, approved_at, approved_by, record_ref}` on each gate approval (`deployment.py:1079-1086`) | each gate approve |
| `_validation_signal` | `ValidationApprovedSignal \| None` | `None` | 292 | `validation_approved` signal handler → signal (`deployment.py:331`) | entry signal (modernization) |
| `_disposition_signal` | `DispositionExecutedSignal \| None` | `None` | 293 | `disposition_executed` signal handler → signal (`deployment.py:339`) | entry signal (non-modernization) |
| `_stakeholder_ops_approved` | `bool` | `False` | 298 | `stakeholder_approved` handler when `scope in ("g-dp1-ops","g-dp2-ops")` → `True` (`deployment.py:364`) | Tier-1 gate |
| `_stakeholder_safety_approved` | `bool` | `False` | 299 | `stakeholder_approved` when `scope == "g-dp1-safety"` → `True` (`deployment.py:366`) | Tier-1 G-DP-1 |
| `_stakeholder_cert_approved` | `bool` | `False` | 300 | `stakeholder_approved` when `scope == "g-dp2-cert"` → `True` (`deployment.py:368`) | Tier-1 G-DP-2 |
| `_manifest_json` | `str` | `""` | 308 | `_run_deploy_and_shift`: set to `result.output_artifacts[0]` after `orchestration` dispatch (`deployment.py:645-649`) | step 2 |
| `_decommission_certificate_json` | `str` | `""` | 309 | `_run_gdp2_with_rework`: `result.output_artifacts[0]` after `legacy-decommission` (`deployment.py:764-768`) | step 11 |
| `_license_reclamation_json` | `str` | `""` | 310 | `_run_gdp2_with_rework`: `result.output_artifacts[1]` (secondary) after `legacy-decommission` (`deployment.py:771-775`) | step 11 |
| `_cost_certification_json` | `str` | `""` | 311 | `_run_gdp2_with_rework`: `result.output_artifacts[0]` after `cost-certification` (`deployment.py:776-781`) | step 12 |
| `_parallel_run_duration_days` | `int` | `0` | 316 | `_run_deploy_and_shift`: set to resolved tier days before `workflow.sleep` (`deployment.py:655`) | step 4 |
| `_disposition_label` | `str` | `""` | 320 | `_resolve_entry_path`: set from `input.disposition.value` OR signal OR `"Refactor"` default | intake |

> ⚠️ **GOTCHA-ST1 (JSON-capture vars feed the terminal projection, not Git re-reads):** the four
> `_*_json` vars hold agent-returned artifact JSON so `_persist_side_effects` /`_fail` can pass a
> single dict to `persist_deployment_side_effects` WITHOUT re-reading Git (`deployment.py:303-311`).
> Critically `_manifest_json`, `_decommission_certificate_json`, etc. default to `""` and stay
> `""` for any step that didn't run (e.g. Retire never sets `_manifest_json`). A rebuild must
> keep them as instance vars captured at dispatch time, defaulting to `""`.
> ⚠️ **GOTCHA-ST2 (license reclamation is `output_artifacts[1]`, a SECONDARY artifact):**
> `_license_reclamation_json` reads index **1** of `legacy-decommission`'s output_artifacts
> (`deployment.py:771-775`), guarded by `len(result.output_artifacts) > 1`. The decommission step
> emits TWO artifacts: `[0]`=decommission-certificate, `[1]`=license-reclamation. A rebuild must
> read index 1 (with the length guard) for license reclamation.

---

## 3. SIGNALS / QUERIES / UPDATES

Deployment adds **3 new `@workflow.signal` handlers** and **NO new queries/updates**. It
INHERITS the four base gate signals and `get_status` query unchanged (and MUST NOT redefine
them — see `_LineWorkflowBase.md` GOTCHA-SIG0 / GOTCHA-Q1).

### 3.1 `validation_approved(self, signal: ValidationApprovedSignal) -> None` — `deployment.py:326-332`
```text
async def validation_approved(self, signal):
    self._validation_signal = signal      # deployment.py:331
    self._updated_at = _now_iso()          # deployment.py:332
```
- Modernization-path entry signal. Payload `ValidationApprovedSignal` (fields: `target_app_id`,
  `portfolio_id`, `validation_output_refs=[]`, `approved_at=""`, `risk_tier=""`).
- **Buffers** the whole signal onto `_validation_signal`. **Consumed by** the `wait_condition`
  predicate in `_resolve_entry_path` (`deployment.py:548-552`):
  `self._validation_signal is not None or self._disposition_signal is not None or self.cancelled`.
- `async def` (unlike the synchronous HIL signals) — but performs no `await`.

### 3.2 `disposition_executed(self, signal: DispositionExecutedSignal) -> None` — `deployment.py:334-340`
```text
async def disposition_executed(self, signal):
    self._disposition_signal = signal      # deployment.py:339
    self._updated_at = _now_iso()          # deployment.py:340
```
- Non-modernization-path entry signal. Payload `DispositionExecutedSignal` (fields: `app_id`,
  `disposition`, `disposition_output_ref`, `portfolio_id`, `executed_at`).
- **Buffers** onto `_disposition_signal`. Consumed by the same `_resolve_entry_path` predicate.

### 3.3 `stakeholder_approved(self, signal: StakeholderApprovedSignal) -> None` — `deployment.py:346-369`
```text
async def stakeholder_approved(self, signal):
    scope = signal.scope                                   # deployment.py:362
    if scope in ("g-dp1-ops", "g-dp2-ops"):                # deployment.py:363  BRANCH A
        self._stakeholder_ops_approved = True              # deployment.py:364
    elif scope == "g-dp1-safety":                          # deployment.py:365  BRANCH B
        self._stakeholder_safety_approved = True           # deployment.py:366
    elif scope == "g-dp2-cert":                            # deployment.py:367  BRANCH C
        self._stakeholder_cert_approved = True             # deployment.py:368
    self._updated_at = _now_iso()                          # deployment.py:369
```
- Payload `StakeholderApprovedSignal` (fields: `approval_id`, `stakeholder`, `scope`).
- **3 scope branches** (A/B/C). Note `g-dp1-ops` AND `g-dp2-ops` BOTH set the SAME
  `_stakeholder_ops_approved` flag (`deployment.py:363-364`).
- ⚠️ **GOTCHA-STK1 (shared ops flag across two gates):** there is ONE `_stakeholder_ops_approved`
  flag for both gates' Operations-Lead sign-off. So if a reviewer sends `g-dp1-ops` during
  G-DP-1, the flag stays `True` through to G-DP-2 — meaning G-DP-2's ops requirement is
  ALREADY satisfied by the G-DP-1 ops signal. The flag is NEVER reset between gates. A rebuild
  MUST use a single shared `_stakeholder_ops_approved` flag (not per-gate), or it changes the
  triple-signal arithmetic for Tier-1 G-DP-2.
- ⚠️ **GOTCHA-STK2 (unknown scopes are silently ignored):** any `scope` not in the three
  branches falls through (only `_updated_at` bumps). No error. A rebuild keeps the silent
  no-op for unrecognized scopes.
- ⚠️ **GOTCHA-STK3 (Tier-2/3 accept-but-ignore):** the docstring (`deployment.py:359-360`) notes
  Tier-2/Tier-3 still ACCEPT these signals (flags get set) but the gate `wait_condition` for
  non-Tier-1 only requires the PM `gate_approved` path (`_wait_for_gate_decision_with_tier_1`
  short-circuits to base wait when `_risk_tier != 1`, §6). So the flags are set but never read
  outside Tier-1. A rebuild keeps the handler tier-agnostic; tier gating happens at the wait.

> ⚠️ **GOTCHA-SIG-NO-REDEF:** Deployment does NOT redefine `gate_approved`, `gate_rejected`,
> `escalation_resolved`, `merge_retry`, or `get_status`. Those four signals + `get_status` query
> are inherited from the base. Adding any of them here would crash Temporal with duplicate
> registration. The three signals above all have UNIQUE names. (`_LineWorkflowBase.md` GOTCHA-SIG0.)

---

## 4. OVERRIDE MATRIX — what this subclass overrides vs. inherits

| Base method | Deployment | How it differs |
|-------------|-----------|----------------|
| `run()` / `_execute()` | **DEFINES** `run()` + `_execute_deployment()` (base has none) | full 18-step orchestration (§7) |
| `_rework_gate_key_for_step` | **OVERRIDES** (`deployment.py:375-383`) | step→gate map (§5); base default returns `SINGLE_GATE_KEY` (here would be `None`) |
| `_task_type_prefix` | inherits (`= ARTIFACT_ROOT = "deployment"`) | task_type = `"deployment-{step}"` |
| `_primary_skill_for_step` | inherits (`STEPS[step]["skill_id"]`) | all 6 agent steps carry `skill_id` |
| `_evidence_step_metadata` | inherits | skill_id-shaped |
| `_evidence_steps_iter` | inherits (`STEPS.items()`) | iterates only the 6 agent steps |
| `gate_approved`/`gate_rejected`/`escalation_resolved`/`merge_retry` | inherits (MUST NOT redefine) | base behavior |
| `get_status` | inherits (MUST NOT redefine) | base query |
| `_wait_for_gate_decision` | inherits, but WRAPPED by new `_wait_for_gate_decision_with_tier_1` (§6) | Tier-1 adds stakeholder triple-signal wait AFTER base PM wait |

New Deployment-only helpers (not overrides): `_resolve_entry_path`, `_resolve_prior_artifacts`,
`_run_deploy_and_shift`, `_run_gdp1_with_rework`, `_run_gdp2_with_rework`, `_persist_side_effects`,
`_emit_output_bundle`, `_inputs_for_step`, `_run_gate`, `_wait_for_gate_decision_with_tier_1`,
`_tier_1_stakeholders_ready`, `_progress_for_gate`, `_fail`, `_build_gdp1_pr_body`,
`_build_gdp2_pr_body`.

### 4.1 `_rework_gate_key_for_step(self, step_name) -> str | None` OVERRIDE (`deployment.py:375-383`)
```text
def _rework_gate_key_for_step(self, step_name):
    if step_name in ("legacy-decommission", "cost-certification"):   # deployment.py:381  BRANCH
        return "G-DP-2"                                              # deployment.py:382
    return "G-DP-1"                                                  # deployment.py:383
```
- **1 branch.** legacy-decommission / cost-certification → `"G-DP-2"`; **everything else** →
  `"G-DP-1"` (including orchestration/traffic-shifting/parallel-run/adoption-verification).
- ⚠️ **GOTCHA-RWK (default-to-G-DP-1 means rework feedback for the FOUR deploy steps comes from
  G-DP-1):** because the `else` returns `"G-DP-1"`, the four pre-G-DP-1 agent steps pick up
  `_rework_feedback["G-DP-1"]` via `_dispatch_agent`. The two post-G-DP-1 steps pick up
  `_rework_feedback["G-DP-2"]`. This is exactly the rework routing in the docstring
  (`deployment.py:64-67`): "G-DP-1 rejection → rerun adoption-verification only; G-DP-2 rejection
  → rerun legacy-decommission + cost-certification". A rebuild MUST map by these two membership
  sets, with the `else` defaulting to G-DP-1.

---

## 5. CONTROL FLOW — `run()` (`deployment.py:389-430`)

```text
@workflow.run
async def run(self, input: LineWorkflowInput) -> str:
    self._status = WorkflowStatus.RUNNING          # deployment.py:396
    self._started_at = _now_iso()                  # deployment.py:397
    self._updated_at = self._started_at            # deployment.py:398

    app_id = input.app_id                          # deployment.py:400
    self._app_id = app_id                          # deployment.py:401
    self._risk_tier = int(input.risk_tier) if input.risk_tier is not None else None   # deployment.py:402-404  BRANCH
    repo = input.artifact_repo                     # deployment.py:405

    wf_id = workflow.info().workflow_id            # deployment.py:407
    run_suffix = wf_id.rsplit("-",1)[-1] if "-" in wf_id else wf_id[:8]   # deployment.py:408  BRANCH
    branch = f"olympus/deployment/{app_id}/{run_suffix}"   # deployment.py:409
    workspace_key = f"deployment-{app_id}-{run_suffix}"    # deployment.py:410

    try:
        return await self._execute_deployment(input, app_id, repo, branch, workspace_key)   # deployment.py:413-415
    except Exception:                              # deployment.py:416  BRANCH (terminal failure)
        self._status = WorkflowStatus.FAILED       # deployment.py:417
        self._current_step = "failed"              # deployment.py:418
        self._updated_at = _now_iso()              # deployment.py:419
        try:
            await self._update_app_status(app_id, "deployment_in_progress", "failed", "Deployment")   # deployment.py:425-427
        except Exception:                          # deployment.py:428  BRANCH (best-effort)
            pass                                   # deployment.py:429
        raise                                      # deployment.py:430  ← re-raise original
```

**Branch inventory (4):**
- `int(input.risk_tier) if input.risk_tier is not None else None` (402-404) — populate `_risk_tier`.
- `wf_id.rsplit("-",1)[-1] if "-" in wf_id else wf_id[:8]` (408) — derive `run_suffix` for branch.
- outer `except Exception:` (416) — set FAILED + best-effort status push + `raise`.
- inner `except Exception: pass` (428) — swallow the status-push failure.

> ⚠️ **GOTCHA-RUN1 (`run()` is a thin wrapper; all logic is in `_execute_deployment`):** the
> outer `try/except` exists ONLY to flip `_status=FAILED`, push a best-effort
> `deployment_in_progress`/`failed` status row, and **re-raise** the original exception
> (`deployment.py:430`). The Temporal workflow itself FAILS (the exception propagates). A rebuild
> MUST `raise` after the status push, not swallow. Note the status row marks status
> `"deployment_in_progress"` with step `"failed"` — it does NOT advance lifecycle to
> `sustainment_active`.
> ⚠️ **GOTCHA-RUN2 (`_fail()` path vs. exception path are DIFFERENT):** the rework-exhaustion path
> returns the string `"failed"` via `self._fail(...)` (which runs `persist_deployment_side_effects`
> with `deployment_current_status="failed"` then returns) — it does NOT raise, so the outer
> `except` here is NOT triggered. The outer `except` only fires on UNEXPECTED exceptions (activity
> failures that exhausted retries, etc.). A rebuild must keep two distinct failure surfaces: a
> graceful `"failed"` return (rework exhausted, §10 `_fail`) and a hard re-raise (unexpected).
> ⚠️ **GOTCHA-RUN3 (branch name uses run_suffix, NOT a fixed slug):** `branch =
> f"olympus/deployment/{app_id}/{run_suffix}"` where run_suffix is the last `-`-segment of the
> workflow id (or first 8 chars if no `-`). A rebuild MUST reproduce this exact template — gate
> PRs are opened from this branch.

### 5.1 `_execute_deployment(...)` — core orchestration (`deployment.py:432-518`)

```text
async def _execute_deployment(self, input, app_id, repo, branch, workspace_key) -> str:
    # ---- Step 1: Intake ----
    await self._set_step("intake", 0.0)                              # deployment.py:442
    await self._resolve_entry_path(input)                           # deployment.py:443  (§8)
    prior_artifacts = self._resolve_prior_artifacts(input)          # deployment.py:444  (§9)
    active_steps = PATH_ACTIVE_STEPS.get(self._disposition_label, list(CANONICAL_STEP_ORDER))   # deployment.py:445-447

    cumulative = STEP_WEIGHTS["intake"]                             # deployment.py:449  (= 2.0)

    # ---- Steps 2-5 + 6-10: modernization-path deploy + G-DP-1 ----
    if "orchestration" in active_steps:                            # deployment.py:455  BRANCH 1
        cumulative = await self._run_deploy_and_shift(             # deployment.py:456-459  (§ Steps 2-4, returns updated cumulative)
            app_id, repo, branch, workspace_key, prior_artifacts, cumulative, input)

        gdp1_outcome = await self._run_gdp1_with_rework(           # deployment.py:462-465  (§ Step 5 + 6-10)
            input, app_id, repo, branch, workspace_key, prior_artifacts, cumulative)
        if gdp1_outcome == "cancelled":                            # deployment.py:466  BRANCH 2
            return "cancelled"                                     # deployment.py:467
        if gdp1_outcome == "failed":                               # deployment.py:468  BRANCH 3
            return await self._fail("max-rework-exceeded-gdp1", app_id)   # deployment.py:469
        cumulative += sum(STEP_WEIGHTS[s] for s in (               # deployment.py:470-479
            "adoption-verification","bundle-g-dp1-evidence","create-g-dp1-pr",
            "ai-pre-review-dp1","gate-review-dp1","merge-g-dp1-pr"))

    # ---- Steps 11-12 + 13-16: G-DP-2 ----
    gdp2_outcome = await self._run_gdp2_with_rework(               # deployment.py:482-485
        input, app_id, repo, branch, workspace_key, prior_artifacts, cumulative)
    if gdp2_outcome == "cancelled":                               # deployment.py:486  BRANCH 4
        return "cancelled"                                        # deployment.py:487
    if gdp2_outcome == "failed":                                  # deployment.py:488  BRANCH 5
        return await self._fail("max-rework-exceeded-gdp2", app_id)   # deployment.py:489

    # ---- Step 17: Persist Deployment Side Effects ----
    await self._set_step("persist-deployment-side-effects", 96.0) # deployment.py:492
    await self._persist_side_effects(app_id)                      # deployment.py:493  (§ Step 17)

    # ---- Step 18: Merge Final Gate PR -> Sustainment handoff ----
    await self._set_step("merge-final-gate-pr", 98.0)             # deployment.py:496

    if self._disposition_label in ("Refactor", "Rearchitect"):    # deployment.py:502  BRANCH 6
        await self._emit_output_bundle(                           # deployment.py:503-509  (§ disposition bundle)
            input=input, app_id=app_id, repo=repo, branch=branch,
            disposition_label=self._disposition_label)

    await self._update_app_status(app_id, "sustainment_active", "registered", "Sustainment")   # deployment.py:511-513
    self._status = WorkflowStatus.COMPLETED                       # deployment.py:514
    self._progress_pct = 100.0                                    # deployment.py:515
    self._current_step = "completed"                              # deployment.py:516
    self._updated_at = _now_iso()                                 # deployment.py:517
    return "completed"                                            # deployment.py:518
```

**Branch inventory (6):** `if "orchestration" in active_steps` (455); `if gdp1_outcome ==
"cancelled"` (466); `if gdp1_outcome == "failed"` (468); `if gdp2_outcome == "cancelled"` (486);
`if gdp2_outcome == "failed"` (488); `if self._disposition_label in ("Refactor","Rearchitect")`
(502).

> ⚠️ **GOTCHA-EX1 (cumulative-progress bookkeeping is split across helpers + the body):** the
> `cumulative` float is seeded at `STEP_WEIGHTS["intake"]=2.0` (449), advanced by
> `_run_deploy_and_shift`'s return value (456), then EXPLICITLY incremented in the body by the
> SUM of the six G-DP-1-cluster weights (470-479) AFTER `_run_gdp1_with_rework` returns
> (because the G-DP-1 helper does its own `_set_step` calls internally but does NOT return an
> updated cumulative — it returns a decision string). `_run_gdp2_with_rework` recomputes its own
> local `step_cumulative` from the passed `cumulative` (§ G-DP-2). A rebuild MUST mirror this:
> the helpers that return a string do NOT mutate the caller's `cumulative`; the caller adds their
> cluster weights manually. Steps 17/18 use HARDCODED progress (96.0, 98.0) — NOT
> `cumulative`-derived — and the terminal sets exactly `100.0`. The intermediate `cumulative` is
> never read after the G-DP-2 call; it exists only to thread into the helpers' `_set_step` calls.
> ⚠️ **GOTCHA-EX2 (Retire bypasses the whole G-DP-1 block):** for Retire, `"orchestration" not in
> active_steps` (the Retire subset has no orchestration), so the entire `if` block (456-479) is
> skipped: no deploy-and-shift, no G-DP-1 loop, no cumulative increment. Control jumps straight to
> the G-DP-2 loop with `cumulative` still at 2.0. A rebuild must gate the ENTIRE deploy+G-DP-1
> section on `"orchestration" in active_steps`, not just the deploy dispatches.
> ⚠️ **GOTCHA-EX3 (terminal bundle emission ONLY for Refactor/Rearchitect):** `_emit_output_bundle`
> runs at Step 18 ONLY when `_disposition_label in ("Refactor","Rearchitect")` (502). The comment
> (`deployment.py:498-501`) explains: other dispositions reached Deployment via Disposition's
> `DispositionExecutedSignal`, and Disposition owns their bundle. Replace/Replatform/Consolidate
> (which also run all 18 steps) do NOT emit a bundle here. A rebuild MUST gate bundle emission on
> exactly the two-element tuple `("Refactor","Rearchitect")`.
> ⚠️ **GOTCHA-EX4 (final status = `sustainment_active`/`registered`, line `Sustainment`):** the
> COMPLETED path pushes `_update_app_status(app_id, "sustainment_active", "registered",
> "Sustainment")` (511-513) — the lifecycle advances to Sustainment. This is the ONLY place that
> advances to `sustainment_active`; the `_fail` path explicitly does NOT (it leaves
> `deployment_in_progress`, §10). A rebuild must reproduce both.

---

## 6. CONTROL FLOW — `_resolve_entry_path(...)` (path resolution) (`deployment.py:524-583`)

Resolves `self._disposition_label` (and maybe `self._risk_tier`) from the input dataclass or by
waiting on an entry signal.

```text
async def _resolve_entry_path(self, input) -> None:
    if input.disposition is not None:                      # deployment.py:540  BRANCH 1
        self._disposition_label = input.disposition.value  # deployment.py:541
        return                                             # deployment.py:542  ← no wait (direct-start)

    # Wait for either entry signal, capped at ENTRY_SIGNAL_WAIT_SECONDS.
    try:
        await workflow.wait_condition(                     # deployment.py:547
            lambda: (self._validation_signal is not None   # deployment.py:549
                     or self._disposition_signal is not None   # deployment.py:550
                     or self.cancelled),                    # deployment.py:551  ★PREDICATE
            timeout=timedelta(seconds=ENTRY_SIGNAL_WAIT_SECONDS))   # deployment.py:553
    except Exception:                                      # deployment.py:555  BRANCH 2 (timeout)
        self._disposition_label = "Refactor"               # deployment.py:559  ← default on timeout
        return                                             # deployment.py:560

    if self._disposition_signal is not None:               # deployment.py:562  BRANCH 3
        self._disposition_label = self._disposition_signal.disposition   # deployment.py:563
        if self._risk_tier is None:                        # deployment.py:568  BRANCH 4
            self._risk_tier = 2                            # deployment.py:569  ← default Tier-2
    elif self._validation_signal is not None:              # deployment.py:570  BRANCH 5
        if self._risk_tier is None and self._validation_signal.risk_tier:   # deployment.py:575  BRANCH 6
            try:
                self._risk_tier = int(self._validation_signal.risk_tier)    # deployment.py:577
            except (TypeError, ValueError):                # deployment.py:578  BRANCH 7
                self._risk_tier = 2                        # deployment.py:579
        self._disposition_label = "Refactor"               # deployment.py:580  ← modernization default
    else:                                                  # deployment.py:581  BRANCH 8 (cancelled)
        self._disposition_label = "Refactor"               # deployment.py:583
```

**Branch inventory (8):**
1. `if input.disposition is not None:` (540) — direct-start path; no wait.
2. `except Exception:` (555) — wait timed out (or failed) → default `"Refactor"`, return.
3. `if self._disposition_signal is not None:` (562) — non-modernization path.
4. `if self._risk_tier is None:` (568) — default disposition-path tier to **2**.
5. `elif self._validation_signal is not None:` (570) — modernization path.
6. `if self._risk_tier is None and self._validation_signal.risk_tier:` (575) — parse tier from signal.
7. `except (TypeError, ValueError):` (578) — unparseable tier → **2**.
8. `else:` (581) — cancelled while waiting → default `"Refactor"`.

> ⚠️ **GOTCHA-EP1 (THREE entry paths, all converge on a disposition label):** (a) input carries
> `disposition` → use `.value` directly, no wait (most tests, legacy callers); (b)
> `DispositionExecutedSignal` → use `signal.disposition` (a STRING, not enum), default tier 2;
> (c) `ValidationApprovedSignal` → ALWAYS `"Refactor"` (signal carries no disposition), tier from
> `signal.risk_tier` string. A rebuild MUST set `_disposition_label` on every path.
> ⚠️ **GOTCHA-EP2 (timeout → "Refactor", NOT a failure):** if neither signal arrives within
> ENTRY_SIGNAL_WAIT_SECONDS (1800s), `wait_condition` raises (timeout) and the `except`
> (`deployment.py:555-560`) defaults to `"Refactor"` and RETURNS — the workflow continues running
> the full modernization path with an empty bundle. It does NOT fail. A rebuild MUST catch the
> timeout and default to Refactor, not propagate. The comment (`deployment.py:556-560`) is
> explicit: "default to modernization path (Refactor) for back-compat with legacy starters."
> ⚠️ **GOTCHA-EP3 (`disposition_signal` checked BEFORE `validation_signal`):** if BOTH signals
> somehow arrived, the disposition signal wins (562 `if` precedes 570 `elif`). A rebuild MUST
> preserve this precedence.
> ⚠️ **GOTCHA-EP4 (cancel during entry wait does NOT early-return cancelled here):** the predicate
> includes `self.cancelled` so the wait unblocks on cancel, but the post-wait branching falls into
> the `else` (581) and sets `_disposition_label="Refactor"` — it does NOT return a cancel signal.
> The cancel is honored LATER, at the gate waits (the gate `wait_condition`s include `cancelled`).
> So a cancel during intake lets the workflow proceed to the first gate, where it then drains to
> `"cancelled"`. A rebuild must NOT add a cancel-return in `_resolve_entry_path`; cancellation is
> handled downstream. (`self._risk_tier` may already be set from `run()`'s `input.risk_tier`; the
> disposition/validation tier defaults only fire when it's still `None`.)
> ⚠️ **GOTCHA-EP5 (modernization-path tier parse needs BOTH `is None` AND truthy `risk_tier`):**
> branch 6 requires `self._risk_tier is None AND self._validation_signal.risk_tier` (575) — i.e.
> only parse from the signal when the input didn't already set a tier AND the signal's risk_tier
> string is non-empty. If the signal's `risk_tier` is `""` (the default), `_risk_tier` stays
> `None` (drives Tier-2 default behavior downstream via `_parallel_run_days`). A rebuild keeps
> both conditions.

---

## 7. `_resolve_prior_artifacts(...)` (`deployment.py:585-598`)

```text
def _resolve_prior_artifacts(self, input) -> list[str]:
    prior = list(input.prior_artifacts)                    # deployment.py:589
    if self._validation_signal is not None:                # deployment.py:590  BRANCH 1
        for ref in self._validation_signal.validation_output_refs:   # deployment.py:591  LOOP
            if ref and ref not in prior:                   # deployment.py:592  BRANCH 2
                prior.append(ref)                          # deployment.py:593
    if self._disposition_signal is not None:               # deployment.py:594  BRANCH 3
        ref = self._disposition_signal.disposition_output_ref   # deployment.py:595
        if ref and ref not in prior:                       # deployment.py:596  BRANCH 4
            prior.append(ref)                              # deployment.py:597
    return prior                                           # deployment.py:598
```
- **4 branches + 1 loop.** Seeds from `input.prior_artifacts`, then appends each non-empty,
  not-already-present `validation_output_refs` entry, then the single non-empty
  `disposition_output_ref`. Order: input refs, then validation refs, then disposition ref.
- ⚠️ **GOTCHA-PA1 (dedup is `ref not in prior`, order-preserving):** uses a linear `not in`
  membership test, not a set, so insertion order is preserved and duplicates skipped. A rebuild
  must dedup with order preservation, not via `set()`.

---

## 8. `_run_deploy_and_shift(...)` — Steps 2-4 (`deployment.py:604-658`)

Runs orchestration → traffic-shifting → parallel-run (3 agent dispatches), capturing the
manifest JSON and performing the tier-driven parallel-run sleep. Returns the updated `cumulative`.

```text
async def _run_deploy_and_shift(self, app_id, repo, branch, workspace_key, prior_artifacts,
                                cumulative, input) -> float:
    for step_name in ("orchestration", "traffic-shifting", "parallel-run"):   # deployment.py:621  LOOP
        await self._set_step(step_name, cumulative)                          # deployment.py:622
        step_inputs = self._inputs_for_step(step_name, prior_artifacts)      # deployment.py:623  (§ inputs)
        result = await self._dispatch_agent(                                 # deployment.py:624-631  (base helper)
            app_id=app_id, step_name=step_name, input_artifacts=step_inputs,
            workspace_key=workspace_key, artifact_repo=repo, artifact_ref=branch)
        self._step_results[step_name] = result.output_artifacts             # deployment.py:632
        artifact_path = f"deployment/{app_id}/{DEPLOYMENT_STEPS[step_name]['artifact']}"   # deployment.py:633-636
        await self._commit_step_artifacts(repo, branch, app_id, step_name, result, artifact_path)   # deployment.py:637-639  (base helper)
        cumulative += STEP_WEIGHTS[step_name]                                # deployment.py:640

        if step_name == "orchestration":                                     # deployment.py:644  BRANCH 1
            self._manifest_json = result.output_artifacts[0] if result.output_artifacts else ""   # deployment.py:645-649  BRANCH 2

        if step_name == "parallel-run":                                      # deployment.py:651  BRANCH 3
            duration_days = _parallel_run_days(input.risk_tier, self._risk_tier)   # deployment.py:652-654
            self._parallel_run_duration_days = duration_days                 # deployment.py:655
            await workflow.sleep(timedelta(days=duration_days))              # deployment.py:656  ★TIMER

    return cumulative                                                        # deployment.py:658
```

**Branch inventory (3 + 1 loop):** the `for` loop over 3 steps (621); `if step_name ==
"orchestration"` (644); `result.output_artifacts[0] if ... else ""` (645); `if step_name ==
"parallel-run"` (651).

**Per-step activity calls (inherited helpers, in order, per loop iteration):**
1. `_dispatch_agent(...)` — dispatches the step's skill. Internally: `dispatch_agent_task`
   (1h start_to_close, `agent_failure` policy = 3 attempts, `activity_id="agent-{step}"`), plus
   the patch-gated `load_context_priors` (10s, `transient`). See `_LineWorkflowBase.md` §8.
2. `_commit_step_artifacts(...)` — batched `write_artifacts_batch` (120s, `transient`,
   `activity_id="commit-{step}"`) + patch-gated `update_agent_task_output_ref`. See
   `_LineWorkflowBase.md` §9. `artifact_path = "deployment/{app_id}/{artifact}"`.

> ⚠️ **GOTCHA-DS1 (the parallel-run `workflow.sleep` is the line's defining timer):**
> `await workflow.sleep(timedelta(days=duration_days))` (`deployment.py:656`) where duration =
> 90/30/14 days by tier (or 30 default). This is a DURABLE Temporal timer — the workflow sleeps
> across the parallel-run window. ⚠️ Under the time-skipping test environment this collapses to
> near-zero real time (docstring `deployment.py:60-62`, `deployment.py:617-620`). A rebuild MUST
> use `workflow.sleep` (deterministic durable timer), NOT `asyncio.sleep` or wall-clock. The
> resolved `duration_days` is stamped into `_parallel_run_duration_days` BEFORE the sleep so the
> terminal projection can read it even if the workflow is queried mid-sleep.
> ⚠️ **GOTCHA-DS2 (manifest captured from `output_artifacts[0]`):** `_manifest_json` is the FIRST
> output artifact of `orchestration` (`deployment.py:645-649`), guarded `if result.output_artifacts
> else ""`. A rebuild must capture index 0 with the empty-guard.
> ⚠️ **GOTCHA-DS3 (`_set_step` uses the running `cumulative`, incremented AFTER dispatch):** each
> step calls `_set_step(step, cumulative)` at the CURRENT cumulative, THEN adds the step weight
> (`deployment.py:640`). So the progress bar shows the value at step START, not step end. A
> rebuild must increment AFTER `_set_step`, matching the order: set → dispatch → commit →
> increment.
> ⚠️ **GOTCHA-DS4 (`_step_results` written by the SUBCLASS — base never writes it):** per
> `_LineWorkflowBase.md` GOTCHA-S2, the subclass MUST set
> `self._step_results[step_name] = result.output_artifacts` (`deployment.py:632`) or evidence
> bundles come back empty. A rebuild must replicate this on every dispatch.

---

## 9. `_inputs_for_step(...)` — compose dispatch inputs (`deployment.py:973-987`)

```text
def _inputs_for_step(self, step_name, prior_artifacts) -> list[str]:
    inputs = list(prior_artifacts)                         # deployment.py:982
    for prev in PRIMARY_STEP_ORDER:                        # deployment.py:983  LOOP
        if prev == step_name:                              # deployment.py:984  BRANCH
            break                                          # deployment.py:985  ← stop at current step
        inputs.extend(self._step_committed_paths.get(prev, []))   # deployment.py:986
    return dedup_paths(inputs)                             # deployment.py:987
```
- **1 branch + 1 loop.** Each step sees `prior_artifacts` PLUS every previously-committed PRIMARY
  step's artifacts (in `PRIMARY_STEP_ORDER`), stopping at the current step, deduplicated via
  `dedup_paths`.
- ⚠️ **GOTCHA-IFS1 (iterates `PRIMARY_STEP_ORDER`, not active_steps):** the accumulation walks all
  6 primary agent steps. For Retire (which skips orchestration..adoption-verification), those
  steps were never committed, so `_step_committed_paths.get(prev, [])` returns `[]` for them —
  the loop is harmless but contributes nothing. So `legacy-decommission` for Retire sees only
  `prior_artifacts`. A rebuild iterates `PRIMARY_STEP_ORDER` and relies on the `.get(prev, [])`
  default for un-run steps.
- ⚠️ **GOTCHA-IFS2 (`break` at current step EXCLUDES the current step's own paths):** the loop
  breaks BEFORE extending with the current step's paths (`deployment.py:984-985`). So a step never
  sees its own (not-yet-committed) output. A rebuild must `break` on equality, not after.

---

## 10. `_run_gate(...)` — single-gate plumbing (shared G-DP-1/G-DP-2) (`deployment.py:994-1088`)

Builds evidence, opens the gate PR, creates the gate record, submits evidence, runs AI
pre-review, then waits (with Tier-1 augmentation) and on approval merges. Returns `"approved"`,
`"rejected"`, or `"cancelled"`.

```text
async def _run_gate(self, input, repo, branch, app_id, gate_type, gate_step,
                    evidence_steps, title, body_builder) -> str:
    evidence_paths = []                                            # deployment.py:1013
    for step_name in evidence_steps:                              # deployment.py:1014  LOOP
        evidence_paths.extend(self._step_committed_paths.get(step_name, []))   # deployment.py:1015-1017
    evidence_paths = dedup_paths(evidence_paths)                 # deployment.py:1018

    pr_result = await self._create_gate_pr(                      # deployment.py:1020-1025  (base helper)
        repo, branch, app_id, gate_type=gate_type.value, title=title, body=body_builder(app_id))

    gate_record = await workflow.execute_activity(               # deployment.py:1027-1038
        create_gate_record,
        CreateGateRecordInput(gate_type=gate_type.value, app_id=app_id,
            portfolio_id=input.portfolio_id, workflow_id=workflow.info().workflow_id,
            evidence_package_url=pr_result.pr_url),
        start_to_close_timeout=timedelta(seconds=30), retry_policy=RETRY_POLICIES["transient"])

    await self._submit_gate_evidence(                            # deployment.py:1040-1048  (base helper)
        gate_id=gate_record.gate_id, gate_type=gate_type, app_id=app_id,
        artifact_paths=evidence_paths, pr_url=pr_result.pr_url,
        assembly_line="Deployment", step=gate_step)

    await self._run_gate_pre_review(                             # deployment.py:1050-1056  (base helper)
        gate_record.gate_id, gate_type.value, evidence_paths,
        artifact_repo=repo, artifact_ref=branch)

    gate_progress = self._progress_for_gate(gate_step)           # deployment.py:1058  (§ progress)
    await self._set_step(gate_step, gate_progress)               # deployment.py:1059

    decision = await self._wait_for_gate_decision_with_tier_1(gate_type)   # deployment.py:1061  (§6 — Tier-1 aware)
    if decision == "cancelled":                                  # deployment.py:1062  BRANCH 1
        return "cancelled"                                       # deployment.py:1063

    if decision == "approved":                                   # deployment.py:1065  BRANCH 2
        await self._reconcile_and_merge_with_retry_loop(         # deployment.py:1068-1073  (base helper — merge_blocked loop)
            repo=repo, pr_number=pr_result.pr_number, gate_id=gate_record.gate_id, merge_method="merge")
        approver = self._gate_decisions[-1][1] if self._gate_decisions else "unknown"   # deployment.py:1074-1078  BRANCH 3
        self._bundle_approvals.append({                          # deployment.py:1079-1086
            "gate": gate_type.value, "approved_at": _now_iso(),
            "approved_by": approver, "record_ref": f"gates/{gate_record.gate_id}/decision.json"})
        return "approved"                                        # deployment.py:1087
    return "rejected"                                            # deployment.py:1088
```

**Branch inventory (3 + 1 loop):** the `for step_name in evidence_steps` loop (1014); `if decision
== "cancelled"` (1062); `if decision == "approved"` (1065); `approver = ... if self._gate_decisions
else "unknown"` (1074-1078).

**Activity calls (in order):**
1. `_create_gate_pr(...)` → `create_pr` (60s, `transient`); targets `main`; labels
   `["gate-review","deployment", gate_type.value]`. Returns `CreatePRResult` (`pr_number`,
   `pr_url`). (base helper, `_LineWorkflowBase.md` §10.) ⚠️ `gate_type.value` passed (the STRING).
2. `create_gate_record` — `CreateGateRecordInput(gate_type=gate_type.value, app_id, portfolio_id,
   workflow_id, evidence_package_url=pr_result.pr_url)`; **30s**; `transient`. Returns `gate_id`.
3. `_submit_gate_evidence(...)` → `check_gate_criteria` (60s, `transient`) + `submit_gate_evidence`
   (60s, `transient`). `gate_type` passed as the ENUM (not value); `forward_risk_tier` defaults
   True so `_risk_tier` is forwarded. (base helper, §11.)
4. `_run_gate_pre_review(...)` → `dispatch_agent_task` (gate-pre-review, 10m, `transient`) +
   `store_gate_pre_review` (30s) + patch-gated `mark_gate_ready_for_review` in `finally`. (base
   helper, §12.) ⚠️ `artifact_repo`/`artifact_ref` ARE passed (not blind).
5. `_wait_for_gate_decision_with_tier_1(gate_type)` — §6 below.
6. (on approve) `_reconcile_and_merge_with_retry_loop(...)` → `reconcile_and_merge_pr`
   (60s, **`git_merge`** policy = 3 attempts, non_retryable merge types) in a `while True`
   merge_blocked loop; on structured merge error → `set_gate_merge_blocked` + wait for
   `merge_retry` signal. (base helper, §14.) `merge_method="merge"`.

> ⚠️ **GOTCHA-RG1 (approver = `_gate_decisions[-1][1]`, the actor field of the LAST decision):**
> after the merge, the approver name is the index-1 element of the last `_gate_decisions` tuple
> (`deployment.py:1074-1078`), defaulting to `"unknown"` when the list is empty. For a 5-tuple
> `(GateStatus, actor, reason, reason_category, card_decisions)`, index 1 is `actor`
> (=`approved_by`). A rebuild MUST read `[-1][1]`, not search by gate_id — it relies on the
> most-recently-consumed decision being THIS gate's approval. (This is sound because
> `_wait_for_gate_decision` consumes decisions in order and the approval that just returned
> `"approved"` is the last appended/consumed one.)
> ⚠️ **GOTCHA-RG2 (bundle_approvals accumulates for the terminal output bundle):** every gate
> approval appends a dict to `_bundle_approvals` (`deployment.py:1079-1086`) with `record_ref =
> f"gates/{gate_id}/decision.json"`. `_emit_output_bundle` later copies `list(_bundle_approvals)`
> into the bundle's `approvals` field (`deployment.py:948`). For a modernization run both G-DP-1
> and G-DP-2 approvals land here in order; for Retire only G-DP-2. A rebuild must accumulate in
> approval order.
> ⚠️ **GOTCHA-RG3 (`_set_step(gate_step, progress)` happens AFTER pre-review, BEFORE the wait):**
> the gate step's progress is set right before `_wait_for_gate_decision_with_tier_1`
> (`deployment.py:1058-1059`). So `get_status` during the gate wait shows `current_step=gate_step`
> with `_progress_for_gate(gate_step)` and (via the base wait) `status=WAITING_FOR_SIGNAL`,
> `pending_gate=gate_type`. A rebuild must order: build evidence → PR → record → submit →
> pre-review → set_step → wait.
> ⚠️ **GOTCHA-RG4 (rejection returns WITHOUT consuming rework — that's the loop's job):** `_run_gate`
> returns `"rejected"` (1088) and does NOT bump the rework counter; the calling loop
> (`_run_gdp1_with_rework`/`_run_gdp2_with_rework`) bumps and re-dispatches. (Matches
> `_LineWorkflowBase.md` GOTCHA-RW1.)

---

## 11. `_run_gdp1_with_rework(...)` — Step 5 + Steps 6-10 with rework (`deployment.py:660-720`)

Adoption-verification dispatch → G-DP-1 gate, looping on rejection (max 3). Returns `"approved"`,
`"cancelled"`, or `"failed"`.

```text
async def _run_gdp1_with_rework(self, input, app_id, repo, branch, workspace_key,
                                prior_artifacts, cumulative) -> str:
    while True:                                                  # deployment.py:675  ★LOOP
        # Step 5: Adoption Verification
        await self._set_step("adoption-verification", cumulative)   # deployment.py:677
        step_inputs = self._inputs_for_step("adoption-verification", prior_artifacts)   # deployment.py:678-680
        result = await self._dispatch_agent(app_id=app_id, step_name="adoption-verification",   # deployment.py:681-688
            input_artifacts=step_inputs, workspace_key=workspace_key,
            artifact_repo=repo, artifact_ref=branch)
        self._step_results["adoption-verification"] = result.output_artifacts   # deployment.py:689
        artifact_path = f"deployment/{app_id}/{DEPLOYMENT_STEPS['adoption-verification']['artifact']}"   # deployment.py:690-693
        await self._commit_step_artifacts(repo, branch, app_id, "adoption-verification", result, artifact_path)   # deployment.py:694-697

        # Steps 6-10: G-DP-1 gate review
        gdp1_decision = await self._run_gate(                   # deployment.py:700-712  (§10)
            input, repo, branch, app_id,
            gate_type=GateType.G_DP_1, gate_step="gate-review-dp1",
            evidence_steps=["orchestration","traffic-shifting","parallel-run","adoption-verification"],
            title=f"Gate G-DP-1: Cutover Go — {app_id}",
            body_builder=self._build_gdp1_pr_body)
        if gdp1_decision == "cancelled":                       # deployment.py:713  BRANCH 1
            return "cancelled"                                 # deployment.py:714
        if gdp1_decision == "rejected":                        # deployment.py:715  BRANCH 2
            self._bump_rework("G-DP-1")                        # deployment.py:716  ← counter HERE
            if self._rework_count("G-DP-1") > MAX_REWORK_ITERATIONS:   # deployment.py:717  BRANCH 3
                return "failed"                                # deployment.py:718
            continue                                           # deployment.py:719  ← re-dispatch adoption-verification
        return "approved"                                      # deployment.py:720
```

**Branch inventory (3 + 1 loop):** `while True` (675); `if gdp1_decision == "cancelled"` (713);
`if gdp1_decision == "rejected"` (715); `if self._rework_count("G-DP-1") > MAX_REWORK_ITERATIONS`
(717).

> ⚠️ **GOTCHA-G1RW1 (G-DP-1 rework re-runs adoption-verification ONLY — NOT the deploy steps):**
> the loop body re-dispatches `adoption-verification` then re-runs the gate. It does NOT re-run
> orchestration/traffic-shifting/parallel-run (those happened once in `_run_deploy_and_shift`
> before this helper). This matches the docstring: "G-DP-1 rejection → rerun adoption-verification
> only" (`deployment.py:66`). The re-dispatch picks up `_rework_feedback["G-DP-1"]` (set by the
> base `_wait_for_gate_decision` on reject, forwarded by `_dispatch_agent` because
> `_rework_gate_key_for_step("adoption-verification")` returns `"G-DP-1"`). A rebuild MUST loop
> ONLY adoption-verification + gate, not the upstream deploy steps.
> ⚠️ **GOTCHA-G1RW2 (`_set_step` re-set to the SAME `cumulative` on each iteration):** the loop
> re-calls `_set_step("adoption-verification", cumulative)` with the unchanged `cumulative` passed
> in (it is a parameter, not mutated in the loop). So progress does NOT advance during rework
> iterations of adoption-verification. A rebuild must NOT advance cumulative inside this loop.
> ⚠️ **GOTCHA-G1RW3 (counter bump BEFORE the `>` check — threshold is `> 3` i.e. the 4th rejection
> fails):** `_bump_rework("G-DP-1")` (716) increments first, then `> MAX_REWORK_ITERATIONS` (3)
> (717). So rejections 1,2,3 → count becomes 1,2,3 → `3 > 3` is False → continue (re-dispatch);
> rejection 4 → count 4 → `4 > 3` True → return `"failed"`. **The loop tolerates up to 3 reworks
> and fails on the 4th rejection.** A rebuild MUST bump-then-compare with strict `>`, giving 3
> rework iterations before failure.
> ⚠️ **GOTCHA-G1RW4 (evidence_steps for G-DP-1 are the 4 deploy steps):** the gate's
> `evidence_steps` list is `["orchestration","traffic-shifting","parallel-run",
> "adoption-verification"]` (`deployment.py:704-709`) — the four steps committed before G-DP-1.
> A rebuild must pass exactly these four as G-DP-1 evidence.

---

## 12. `_run_gdp2_with_rework(...)` — Steps 11-12 + Steps 13-16 with rework (`deployment.py:722-801`)

legacy-decommission + cost-certification dispatches → G-DP-2 gate, looping on rejection (max 3).
Returns `"approved"`, `"cancelled"`, or `"failed"`.

```text
async def _run_gdp2_with_rework(self, input, app_id, repo, branch, workspace_key,
                                prior_artifacts, cumulative) -> str:
    while True:                                                 # deployment.py:736  ★LOOP
        step_cumulative = cumulative                            # deployment.py:737  ← LOCAL copy, reset each iter
        for step_name in ("legacy-decommission", "cost-certification"):   # deployment.py:738  LOOP
            await self._set_step(step_name, step_cumulative)    # deployment.py:739
            step_inputs = self._inputs_for_step(step_name, prior_artifacts)   # deployment.py:740-742
            result = await self._dispatch_agent(app_id=app_id, step_name=step_name,   # deployment.py:743-750
                input_artifacts=step_inputs, workspace_key=workspace_key,
                artifact_repo=repo, artifact_ref=branch)
            self._step_results[step_name] = result.output_artifacts   # deployment.py:751
            artifact_path = f"deployment/{app_id}/{DEPLOYMENT_STEPS[step_name]['artifact']}"   # deployment.py:752-755
            await self._commit_step_artifacts(repo, branch, app_id, step_name, result, artifact_path)   # deployment.py:756-759
            step_cumulative += STEP_WEIGHTS[step_name]          # deployment.py:760

            if step_name == "legacy-decommission":              # deployment.py:763  BRANCH 1
                self._decommission_certificate_json = result.output_artifacts[0] if result.output_artifacts else ""   # deployment.py:764-768  BRANCH 2
                self._license_reclamation_json = result.output_artifacts[1] if len(result.output_artifacts) > 1 else ""   # deployment.py:771-775  BRANCH 3
            elif step_name == "cost-certification":             # deployment.py:776  BRANCH 4
                self._cost_certification_json = result.output_artifacts[0] if result.output_artifacts else ""   # deployment.py:777-781  BRANCH 5

        # Steps 13-16: G-DP-2 gate review
        gdp2_decision = await self._run_gate(                   # deployment.py:784-792  (§10)
            input, repo, branch, app_id,
            gate_type=GateType.G_DP_2, gate_step="gate-review-dp2",
            evidence_steps=PRIMARY_STEP_ORDER,
            title=f"Gate G-DP-2: Deployment Complete — {app_id}",
            body_builder=self._build_gdp2_pr_body)
        if gdp2_decision == "cancelled":                        # deployment.py:794  BRANCH 6
            return "cancelled"                                  # deployment.py:795
        if gdp2_decision == "rejected":                         # deployment.py:796  BRANCH 7
            self._bump_rework("G-DP-2")                         # deployment.py:797  ← counter HERE
            if self._rework_count("G-DP-2") > MAX_REWORK_ITERATIONS:   # deployment.py:798  BRANCH 8
                return "failed"                                 # deployment.py:799
            continue                                            # deployment.py:800  ← re-run decommission + cost-cert
        return "approved"                                       # deployment.py:801
```

**Branch inventory (8 + 2 loops):** `while True` (736); inner `for step_name` loop (738); `if
step_name == "legacy-decommission"` (763); the decommission `[0] if ... else ""` (764); the
license `[1] if len > 1 else ""` (771); `elif step_name == "cost-certification"` (776); the
cost-cert `[0] if ... else ""` (777); `if gdp2_decision == "cancelled"` (794); `if gdp2_decision
== "rejected"` (796); `if _rework_count("G-DP-2") > MAX_REWORK_ITERATIONS` (798).

> ⚠️ **GOTCHA-G2RW1 (`step_cumulative` is a per-iteration LOCAL reset from `cumulative`):**
> `step_cumulative = cumulative` is the FIRST statement of every `while` iteration
> (`deployment.py:737`), so rework iterations restart the local progress at the same base. The
> outer `cumulative` parameter is never mutated. A rebuild MUST reset `step_cumulative` inside the
> loop, not before it.
> ⚠️ **GOTCHA-G2RW2 (G-DP-2 rework re-runs BOTH decommission AND cost-cert):** unlike G-DP-1
> (adoption-verification only), the G-DP-2 loop re-runs the FULL inner `for` over
> `("legacy-decommission","cost-certification")` (`deployment.py:738`). Both re-dispatch on each
> rework iteration, picking up `_rework_feedback["G-DP-2"]` (because
> `_rework_gate_key_for_step` maps both to `"G-DP-2"`). Matches docstring: "G-DP-2 rejection →
> rerun legacy-decommission + cost-certification" (`deployment.py:67`). A rebuild MUST re-run both
> steps per G-DP-2 rework iteration.
> ⚠️ **GOTCHA-G2RW3 (G-DP-2 evidence_steps = ALL 6 PRIMARY steps):** the gate's `evidence_steps`
> is `PRIMARY_STEP_ORDER` (`deployment.py:788`) — all six agent steps including the four deploy
> steps from G-DP-1. So G-DP-2 evidence is cumulative across the whole line. For Retire, the four
> deploy steps were never committed, so `_run_gate`'s evidence accumulation
> (`_step_committed_paths.get(step, [])`) yields only the two that ran. A rebuild passes
> `PRIMARY_STEP_ORDER`, relying on the `.get(..., [])` default for un-run steps.
> ⚠️ **GOTCHA-G2RW4 (same bump-then-`>3` semantics as G-DP-1):** 3 reworks tolerated, 4th rejection
> → `"failed"`. Independent counter keyed `"G-DP-2"`.
> ⚠️ **GOTCHA-G2RW5 (artifact-capture vars are OVERWRITTEN on every rework iteration):** on a
> G-DP-2 rework re-run, `_decommission_certificate_json` / `_license_reclamation_json` /
> `_cost_certification_json` are reassigned from the fresh dispatch results. So the terminal
> projection reads the LAST iteration's artifacts. A rebuild must reassign (not append) these on
> each iteration.

---

## 13. `_wait_for_gate_decision_with_tier_1(...)` — Tier-1 triple-signal wait (`deployment.py:1090-1120`)

Wraps the base `_wait_for_gate_decision` to add Tier-1 stakeholder-signal gating.

```text
async def _wait_for_gate_decision_with_tier_1(self, gate_type) -> str:
    if self._risk_tier != 1:                                   # deployment.py:1101  BRANCH 1
        return await self._wait_for_gate_decision(gate_type)   # deployment.py:1102  ← base wait (PM only)

    # Tier-1: PM signal first (base wait pops the decision + tracks rework feedback)
    decision = await self._wait_for_gate_decision(gate_type)   # deployment.py:1106
    if decision != "approved":                                 # deployment.py:1107  BRANCH 2
        return decision                                        # deployment.py:1108  ← reject/cancel short-circuit

    # PM approved — now wait for stakeholder triple-signal flags.
    await workflow.wait_condition(                             # deployment.py:1112
        lambda: self._tier_1_stakeholders_ready(gate_type) or self.cancelled)   # deployment.py:1113-1114  ★PREDICATE
    if self.cancelled:                                         # deployment.py:1116  BRANCH 3
        self._status = WorkflowStatus.CANCELLED                # deployment.py:1117
        self._updated_at = _now_iso()                          # deployment.py:1118
        return "cancelled"                                     # deployment.py:1119
    return "approved"                                          # deployment.py:1120
```

**Branch inventory (3):** `if self._risk_tier != 1` (1101); `if decision != "approved"` (1107);
`if self.cancelled` (1116).

> ⚠️ **GOTCHA-T1W1 (Tier-2/Tier-3 = base wait only, PM `gate_approved` sufficient):** when
> `_risk_tier != 1` (including `None`), this delegates straight to the base
> `_wait_for_gate_decision` — only the PM's `gate_approved` signal is needed. The stakeholder
> flags are NOT consulted. A rebuild MUST short-circuit non-Tier-1 to the base wait.
> ⚠️ **GOTCHA-T1W2 (Tier-1 is a TWO-PHASE wait — PM FIRST, THEN stakeholders):** Tier-1 first
> awaits the base PM decision (1106). If PM rejects or cancels, it returns immediately
> (`decision != "approved"`, 1107-1108) — the stakeholder flags are NOT waited on. ONLY after PM
> approval does it block on `_tier_1_stakeholders_ready(gate_type) or self.cancelled`. A rebuild
> MUST order PM-then-stakeholders, and MUST short-circuit reject/cancel before the stakeholder
> wait. ⚠️ The base `_wait_for_gate_decision` already advanced the decision cursor and recorded
> rework feedback for a rejection, so a Tier-1 reject is identical to a Tier-2 reject from the
> loop's perspective.
> ⚠️ **GOTCHA-T1W3 (stakeholder wait has NO timeout):** the second `wait_condition`
> (`deployment.py:1112-1114`) has no timeout — it blocks until the required stakeholder signals
> arrive OR cancel. A misconfigured Tier-1 run with a missing stakeholder hangs here (only cancel
> frees it). A rebuild reproduces the un-timed wait (cancel is the only escape).
> ⚠️ **GOTCHA-T1W4 (cancel during stakeholder wait sets CANCELLED + returns "cancelled"):** unlike
> the base wait (which sets CANCELLED itself), this method ALSO sets `_status=CANCELLED` and
> `_updated_at` on the stakeholder-wait cancel branch (1116-1119) before returning `"cancelled"`.
> A rebuild must set status on this branch too.

### 13.1 `_tier_1_stakeholders_ready(self, gate_type) -> bool` (`deployment.py:1122-1134`)
```text
def _tier_1_stakeholders_ready(self, gate_type):
    if gate_type == GateType.G_DP_1:                           # deployment.py:1124  BRANCH 1
        return self._stakeholder_ops_approved and self._stakeholder_safety_approved   # deployment.py:1125-1128
    if gate_type == GateType.G_DP_2:                           # deployment.py:1129  BRANCH 2
        return self._stakeholder_ops_approved and self._stakeholder_cert_approved     # deployment.py:1130-1133
    return True                                                # deployment.py:1134  ← any other gate: no extra signals
```
- **3 branches (2 `if` + fall-through).** G-DP-1 needs **ops AND safety**; G-DP-2 needs **ops AND
  cert**; anything else returns `True` (vacuously ready).
- ⚠️ **GOTCHA-T1R1 (G-DP-1 = ops+safety; G-DP-2 = ops+cert; ops is SHARED):** see GOTCHA-STK1 — a
  single `_stakeholder_ops_approved` flag serves both gates. So if G-DP-1's `g-dp1-ops` arrived,
  ops is already satisfied for G-DP-2; G-DP-2 then only needs `g-dp2-cert`. A rebuild MUST AND the
  exact pair per gate using the shared ops flag.

---

## 14. `_progress_for_gate(self, gate_step) -> float` (`deployment.py:1136-1143`)

```text
def _progress_for_gate(self, gate_step):
    total = 0.0                                                # deployment.py:1138
    for step in CANONICAL_STEP_ORDER:                          # deployment.py:1139  LOOP
        total += STEP_WEIGHTS.get(step, 0.0)                   # deployment.py:1140
        if step == gate_step:                                  # deployment.py:1141  BRANCH
            break                                              # deployment.py:1142
    return total                                               # deployment.py:1143
```
- **1 branch + 1 loop.** Cumulative sum of `STEP_WEIGHTS` over `CANONICAL_STEP_ORDER` UP TO AND
  INCLUDING `gate_step`. For `gate-review-dp1`: 2+10+10+14+12+2+2+2+6 = **60.0**. For
  `gate-review-dp2`: through step 16 = 2+10+10+14+12+2+2+2+6+2+12+10+2+2+2+6 = **96.0**.
- ⚠️ **GOTCHA-PG1 (includes the gate step's own weight):** the `total +=` happens BEFORE the
  `break` (`deployment.py:1140-1142`), so the gate step's own weight is included. A rebuild must
  add-then-break, not break-then-add.

---

## 15. `_persist_side_effects(self, app_id)` — Step 17 projection (`deployment.py:803-863`)

Best-effort DB projection of the captured artifact JSON. Lifts the observed parallel-run duration
into the manifest before projecting.

```text
async def _persist_side_effects(self, app_id) -> None:
    manifest_with_duration = self._manifest_json              # deployment.py:814
    if (self._parallel_run_duration_days                      # deployment.py:815-818  BRANCH 1 (compound)
            and manifest_with_duration
            and '"parallel_run"' not in manifest_with_duration):
        import json as _json                                  # deployment.py:824
        try:
            parsed = _json.loads(manifest_with_duration)      # deployment.py:827
            if isinstance(parsed, dict):                      # deployment.py:828  BRANCH 2
                parsed.setdefault("parallel_run", {})         # deployment.py:829
                if isinstance(parsed["parallel_run"], dict):  # deployment.py:830  BRANCH 3
                    parsed["parallel_run"]["observed_duration_days"] = self._parallel_run_duration_days   # deployment.py:831-833
                    manifest_with_duration = _json.dumps(parsed)   # deployment.py:834
        except (TypeError, ValueError):                       # deployment.py:835  BRANCH 4
            pass                                              # deployment.py:838  ← malformed JSON tolerated

    try:
        await workflow.execute_activity(                      # deployment.py:841-857
            persist_deployment_side_effects,
            PersistDeploymentSideEffectsInput(
                target_app_id=app_id,
                deployment_manifest_json=manifest_with_duration,
                decommission_certificate_json=self._decommission_certificate_json,
                license_reclamation_json=self._license_reclamation_json,
                cost_savings_certification_json=self._cost_certification_json,
                deployment_current_status="completed"),       # deployment.py:853
            start_to_close_timeout=timedelta(seconds=60), retry_policy=RETRY_POLICIES["transient"])
    except Exception:                                         # deployment.py:858  BRANCH 5 (best-effort)
        workflow.logger.warning("persist_deployment_side_effects failed; continuing to "
                                "Sustainment handoff", extra={"app_id": app_id})   # deployment.py:859-863
```

**Branch inventory (5):** compound `if duration and manifest and '"parallel_run"' not in manifest`
(815-818); `if isinstance(parsed, dict)` (828); `if isinstance(parsed["parallel_run"], dict)`
(830); `except (TypeError, ValueError): pass` (835); outer `except Exception:` (858).

**Activity:** `persist_deployment_side_effects` — `PersistDeploymentSideEffectsInput` with
`deployment_current_status="completed"`; **60s**; `transient`. Wrapped in try/except — **best-effort**.

> ⚠️ **GOTCHA-PS1 (duration injection guarded by `'"parallel_run"' not in manifest`):** the manifest
> is only mutated when (a) a duration was observed, (b) the manifest is non-empty, AND (c) the
> manifest doesn't ALREADY contain the literal substring `"parallel_run"` (`deployment.py:815-818`).
> This prevents double-injecting if the agent already wrote a parallel_run block. A rebuild MUST
> keep all three conditions.
> ⚠️ **GOTCHA-PS2 (inline `import json as _json` inside the method):** json is imported LOCALLY
> (`deployment.py:824`), not at module top. This is fine under the Temporal sandbox (json is a
> standard lib). A rebuild may import at top, but the parse+inject logic must be identical.
> ⚠️ **GOTCHA-PS3 (malformed manifest → projection still runs with the ORIGINAL manifest):** if
> `_json.loads` raises (manifest isn't pure JSON), the `except` does `pass` (`deployment.py:835-838`)
> — `manifest_with_duration` stays the unmodified original string. The comment notes the extractor
> tolerates malformed JSON and falls back to a top-level key. So the activity always runs; the
> injection is best-effort. A rebuild must NOT skip the activity on a parse failure.
> ⚠️ **GOTCHA-PS4 (the WHOLE projection is best-effort — never blocks Sustainment handoff):** the
> outer try/except (858) swallows ANY activity failure and logs a warning (`deployment.py:858-863`).
> The workflow then proceeds to Step 18 and COMPLETED. A rebuild MUST swallow projection failures
> here. (Contrast `_fail`, §16, which is also best-effort but sets status `"failed"`.)
> ⚠️ **GOTCHA-PS5 (`setdefault` + nested `isinstance` guard):** `parsed.setdefault("parallel_run",
> {})` creates the key if absent; the inner `if isinstance(parsed["parallel_run"], dict)` guards
> against an existing non-dict `parallel_run` value (e.g. a list) — only then is
> `observed_duration_days` written and the manifest re-serialized. If `parallel_run` exists but
> isn't a dict, the manifest is NOT re-serialized (stays original). A rebuild keeps both guards.

---

## 16. `_fail(self, reason_step, app_id) -> str` — graceful failure projection (`deployment.py:1145-1181`)

Called by `_execute_deployment` on rework exhaustion (`"max-rework-exceeded-gdp1"` /
`"max-rework-exceeded-gdp2"`). Marks FAILED, best-effort projects `deployment_current_status="failed"`,
pushes a lifecycle status row (NOT advancing to Sustainment), returns `"failed"`.

```text
async def _fail(self, reason_step, app_id) -> str:
    self._status = WorkflowStatus.FAILED                      # deployment.py:1155
    self._current_step = reason_step                          # deployment.py:1156
    self._updated_at = _now_iso()                             # deployment.py:1157
    try:
        await workflow.execute_activity(                      # deployment.py:1159-1175
            persist_deployment_side_effects,
            PersistDeploymentSideEffectsInput(
                target_app_id=app_id,
                deployment_manifest_json=self._manifest_json,
                decommission_certificate_json=self._decommission_certificate_json,
                license_reclamation_json=self._license_reclamation_json,
                cost_savings_certification_json=self._cost_certification_json,
                deployment_current_status="failed"),          # deployment.py:1171
            start_to_close_timeout=timedelta(seconds=60), retry_policy=RETRY_POLICIES["transient"])
    except Exception:                                         # deployment.py:1176  BRANCH (best-effort)
        pass                                                  # deployment.py:1177
    await self._update_app_status(app_id, "deployment_in_progress", reason_step, "Deployment")   # deployment.py:1178-1180
    return "failed"                                           # deployment.py:1181
```

**Branch inventory (1):** the `except Exception: pass` (1176).

> ⚠️ **GOTCHA-FAIL1 (`_fail` uses RAW `_manifest_json`, NOT the duration-injected one):** unlike
> `_persist_side_effects` (which injects the parallel-run duration), `_fail` passes
> `self._manifest_json` directly (`deployment.py:1163`) — no duration injection. The projection
> status is `"failed"` (1171). A rebuild must pass the raw manifest here.
> ⚠️ **GOTCHA-FAIL2 (lifecycle status stays `deployment_in_progress` on failure):** the final
> `_update_app_status(app_id, "deployment_in_progress", reason_step, "Deployment")`
> (`deployment.py:1178-1180`) does NOT advance to `sustainment_active`. The docstring
> (`deployment.py:1150-1153`) is explicit: the lifecycle marker stays `deployment_in_progress`
> until Governance retriage. The `deployment_current_status` column reflects `"failed"` (via the
> projection activity) but the `application.current_status` lifecycle marker does not. A rebuild
> MUST reproduce this split: projection status `"failed"`, lifecycle status
> `"deployment_in_progress"`.
> ⚠️ **GOTCHA-FAIL3 (`_update_app_status` here is NOT wrapped in try/except → CAN raise):** unlike
> the projection activity (wrapped, swallowed), the final `_update_app_status` call
> (`deployment.py:1178-1180`) is NOT in a try/except inside `_fail`. If it raises, the exception
> propagates out of `_fail`, out of `_execute_deployment`, and is caught by `run()`'s outer
> `except` (which then re-raises after another best-effort status push). A rebuild must NOT wrap
> this `_update_app_status` in `_fail`. (Note: `_update_app_status` itself uses the `transient`
> 3-attempt policy, so a transient blip retries before raising.)

---

## 17. `_emit_output_bundle(...)` — terminal disposition bundle (Refactor/Rearchitect) (`deployment.py:869-971`)

Emits the P5-S13 / W12 disposition-output bundle. Called at Step 18 ONLY for Refactor/Rearchitect
(§ GOTCHA-EX3).

```text
async def _emit_output_bundle(self, input, app_id, repo, branch, disposition_label) -> None:
    def step_path(step_name):                                 # deployment.py:880  nested helper
        paths = self._step_committed_paths.get(step_name, [])
        return paths[0] if paths else ""                      # deployment.py:882  BRANCH

    wave_id = getattr(input, "wave_id", "") or ""             # deployment.py:884
    disposition_decision_ref = (f"rationalization/wave-{wave_id}/{app_id}/disposition-recommendation.json"
                                if wave_id else "")           # deployment.py:885-890  BRANCH
    baseline_ref = (f"rationalization/wave-{wave_id}/{app_id}/tco-analysis.json"
                    if wave_id else None)                     # deployment.py:891-895  BRANCH
    user_impact_ref = (f"rationalization/wave-{wave_id}/{app_id}/user-impact-analysis.json"
                       if wave_id else None)                  # deployment.py:896-900  BRANCH

    payload = { ... "deployment": { ...
        "deployment_ref": step_path("adoption-verification") or f"deployment/{app_id}/deployment-evidence.json",  # deployment.py:927-930  BRANCH
        ...}}                                                 # deployment.py:902-932
    if disposition_label == "Rearchitect":                    # deployment.py:933  BRANCH
        payload["bounded_context_map_ref"] = f"architecture/{app_id}/bounded-context-map.json"   # deployment.py:934-936

    bundle = { "application_id": app_id,
               "application_name": input.app_name or app_id,  # deployment.py:940  BRANCH
               "portfolio_id": input.portfolio_id, "wave_id": wave_id,
               "disposition": disposition_label, "status": "completed",
               "started_at": self._started_at, "completed_at": _now_iso(),
               "disposition_decision_ref": disposition_decision_ref,
               "approvals": list(self._bundle_approvals),      # deployment.py:948  ← snapshot
               "realized_net_impact": { "tco_delta": {... "baseline_ref": baseline_ref}, ...
                                        "users_affected_estimate_ref": user_impact_ref},
               "payload": payload }                            # deployment.py:938-959
    await workflow.execute_activity(                          # deployment.py:960-971
        emit_disposition_output_bundle,
        EmitDispositionOutputBundleInput(repo=repo, branch=branch, portfolio_id=input.portfolio_id,
                                         app_id=app_id, bundle=bundle),
        start_to_close_timeout=timedelta(seconds=60), retry_policy=RETRY_POLICIES["transient"])
```

**Branch inventory (7):** `paths[0] if paths else ""` (882); `...disposition-recommendation.json
if wave_id else ""` (885-890); `...tco-analysis.json if wave_id else None` (891-895);
`...user-impact-analysis.json if wave_id else None` (896-900); `step_path(...) or f"..."`
deployment_ref fallback (927-930); `if disposition_label == "Rearchitect"` (933);
`input.app_name or app_id` (940).

**Activity:** `emit_disposition_output_bundle` — `EmitDispositionOutputBundleInput(repo, branch,
portfolio_id, app_id, bundle)`; **60s**; `transient`. (NOT best-effort — failure propagates and
fails the workflow via run()'s outer except, because this is awaited unguarded.)

> ⚠️ **GOTCHA-OB1 (`wave_id`-conditional refs: empty-string vs None differ):** when `wave_id` is
> empty, `disposition_decision_ref` defaults to `""` (885-890) but `baseline_ref` /
> `user_impact_ref` default to `None` (891-900). A rebuild MUST reproduce the empty-string-vs-None
> asymmetry — the bundle schema distinguishes them.
> ⚠️ **GOTCHA-OB2 (Rearchitect adds `bounded_context_map_ref`):** only Rearchitect's payload gets
> the extra `bounded_context_map_ref` key (933-936). Refactor's does not. A rebuild branches on
> `disposition_label == "Rearchitect"`.
> ⚠️ **GOTCHA-OB3 (`approvals` snapshots `_bundle_approvals` at emit time):** `list(self._bundle_approvals)`
> (948) copies the accumulated gate-approval dicts (from `_run_gate`, GOTCHA-RG2). For a
> Refactor/Rearchitect run this holds G-DP-1 + G-DP-2 approvals in order. A rebuild must snapshot
> a copy (not the live list).
> ⚠️ **GOTCHA-OB4 (`modernized_repo_url` / `deployment_ref` fallbacks):** `payload.modernized_repo_url
> = getattr(input,"source_repo","") or f"https://github.com/org/{app_id}-modernized"` (904-907) and
> `deployment_ref = step_path("adoption-verification") or f"deployment/{app_id}/deployment-evidence.json"`
> (927-930). Both use `or`-fallbacks. A rebuild reproduces both fallback chains.
> ⚠️ **GOTCHA-OB5 (this activity is UNGUARDED — failure fails the workflow):** unlike
> `_persist_side_effects`, the `emit_disposition_output_bundle` call has NO surrounding try/except
> (`deployment.py:960-971`). A schema-validation failure (the activity validates against
> `disposition-output.schema.json`) raises and propagates to run()'s outer except → workflow FAILS.
> A rebuild must NOT wrap this call. (Step 18 emission is treated as load-bearing, not best-effort.)

---

## 18. ACTIVITY & CHILD-WORKFLOW INVENTORY (Deployment-direct calls)

Child workflows: **NONE.** Deployment spawns no children.

Activities invoked DIRECTLY by Deployment code (excludes activities invoked inside inherited base
helpers — see `_LineWorkflowBase.md` §19 for those):

| Activity | Where | Args | Timeout | Retry | non_retryable | Guarded? |
|----------|-------|------|---------|-------|---------------|----------|
| `create_gate_record` | `_run_gate` (`deployment.py:1027`) | `CreateGateRecordInput(gate_type.value, app_id, portfolio_id, workflow_id, evidence_package_url)` | 30s | `transient` | — | no |
| `persist_deployment_side_effects` | `_persist_side_effects` (`deployment.py:841`) | `PersistDeploymentSideEffectsInput(...status="completed")` | 60s | `transient` | — | **yes (best-effort)** |
| `persist_deployment_side_effects` | `_fail` (`deployment.py:1159`) | `PersistDeploymentSideEffectsInput(...status="failed")` | 60s | `transient` | — | **yes (best-effort)** |
| `emit_disposition_output_bundle` | `_emit_output_bundle` (`deployment.py:960`) | `EmitDispositionOutputBundleInput(repo, branch, portfolio_id, app_id, bundle)` | 60s | `transient` | — | **no (load-bearing)** |

Activities invoked via inherited helpers (in call order across a full modernization run): per
agent step — `load_context_priors` (patch-gated), `dispatch_agent_task` (1h, `agent_failure`),
`write_artifacts_batch` (commit), `update_agent_task_output_ref` (patch-gated); per gate —
`create_pr` (60s), `check_gate_criteria` (60s), `submit_gate_evidence` (60s), `dispatch_agent_task`
(gate-pre-review, 10m), `store_gate_pre_review` (30s), `mark_gate_ready_for_review` (patch-gated,
finally), `reconcile_and_merge_pr` (60s, **`git_merge`**), and on merge_blocked
`set_gate_merge_blocked` (30s); plus `update_application_status` (30s, `transient`) on every
`_set_step` and the terminal/failure status pushes. See `_LineWorkflowBase.md`.

All imports are inside `with workflow.unsafe.imports_passed_through():` (`deployment.py:83-107`).

---

## 19. GATE HANDLING SUMMARY (evidence → wait → routing)

For BOTH gates the flow is (in `_run_gate`, §10): assemble `evidence_paths` from
`_step_committed_paths` over `evidence_steps` (dedup) → `_create_gate_pr` (PR to `main`) →
`create_gate_record` → `_submit_gate_evidence` (slim bundle + threshold-scoped criteria check,
risk_tier forwarded) → `_run_gate_pre_review` (advisory AI, best-effort, `finally` ready-flip) →
`_set_step(gate_step, _progress_for_gate(gate_step))` → `_wait_for_gate_decision_with_tier_1`.

**Routing of the four reviewer outcomes:**
- **approve** → base wait returns `"approved"` (pops `_rework_feedback[gate]`); for Tier-1, ALSO
  wait for stakeholder triple-signal (§13). Then `_reconcile_and_merge_with_retry_loop` merges the
  PR; append to `_bundle_approvals`; `_run_gate` returns `"approved"`; the loop returns `"approved"`.
- **reject** → base wait returns `"rejected"` (stores `_rework_feedback[gate]`); `_run_gate`
  returns `"rejected"`; the loop bumps `_bump_rework(gate)`, checks `> MAX_REWORK_ITERATIONS(3)`,
  and either returns `"failed"` (4th rejection) or `continue`s (re-dispatch the gate's steps with
  the rework feedback now attached).
- **merge_blocked** (post-approval, structured merge error MergeConflict /
  MergeDivergenceUnresolved / MergeBranchProtectionRejected) → handled INSIDE
  `_reconcile_and_merge_with_retry_loop`: `set_gate_merge_blocked` + wait for `merge_retry` signal,
  loop until merge succeeds or cancel. (base helper, §14.)
- **cancel** → any gate wait sees `self.cancelled`, returns `"cancelled"`; `_run_gate` returns
  `"cancelled"`; the loop returns `"cancelled"`; `_execute_deployment` returns `"cancelled"`.

**Rework loops & counters:**
- G-DP-1: counter key `"G-DP-1"`, re-dispatches **adoption-verification only** (§11).
- G-DP-2: counter key `"G-DP-2"`, re-dispatches **legacy-decommission + cost-certification** (§12).
- Each: `_bump_rework` then strict `> 3` → 3 rework iterations tolerated, fail on 4th rejection.
- Counters are independent; G-DP-1 exhaustion → `_fail("max-rework-exceeded-gdp1")`; G-DP-2 →
  `_fail("max-rework-exceeded-gdp2")`.

**Tier routing:**
- Tier-2/Tier-3 (or `_risk_tier=None`): PM `gate_approved` alone suffices.
- Tier-1 G-DP-1: PM + `g-dp1-ops` (→ops flag) + `g-dp1-safety` (→safety flag).
- Tier-1 G-DP-2: PM + `g-dp2-ops`/`g-dp1-ops` (→shared ops flag) + `g-dp2-cert` (→cert flag).

---

## 20. PR BODY BUILDERS (`_build_gdp1_pr_body` / `_build_gdp2_pr_body`)

### 20.1 `_build_gdp1_pr_body(self, app_id) -> str` (`deployment.py:1187-1222`)
```text
def _build_gdp1_pr_body(self, app_id):
    rework_iter = self._rework_count("G-DP-1")                # deployment.py:1189
    tier_note = ""                                            # deployment.py:1190
    if self._risk_tier == 1:                                  # deployment.py:1191  BRANCH 1
        tier_note = "\n### Tier-1 Triple-Signal Approvals Required\n- [ ] PM (`gate_approved`)\n"
                    "- [ ] Operations Lead (`stakeholder_approved` scope=g-dp1-ops)\n"
                    "- [ ] Safety Board Chair (`stakeholder_approved` scope=g-dp1-safety)\n"   # deployment.py:1192-1198
    body = f"## Gate G-DP-1 Review: Cutover Go\n\n**Application:** {app_id}\n\n..."  # deployment.py:1199-1219 (full markdown, incl tier_note)
    if rework_iter > 0:                                       # deployment.py:1220  BRANCH 2
        body += f"\n**Rework iteration:** {rework_iter}\n"    # deployment.py:1221
    return body                                               # deployment.py:1222
```
- **2 branches.** `if self._risk_tier == 1` appends the Tier-1 triple-signal checklist; `if
  rework_iter > 0` appends the rework-iteration footer.

### 20.2 `_build_gdp2_pr_body(self, app_id) -> str` (`deployment.py:1224-1261`)
```text
def _build_gdp2_pr_body(self, app_id):
    rework_iter = self._rework_count("G-DP-2")                # deployment.py:1226
    tier_note = ""                                            # deployment.py:1227
    if self._risk_tier == 1:                                  # deployment.py:1228  BRANCH 1
        tier_note = "...PM... Operations Lead (scope=g-dp2-ops)... Certifying Authority (scope=g-dp2-cert)..."   # deployment.py:1229-1235
    body = f"## Gate G-DP-2 Review: Deployment Complete\n\n**Application:** {app_id}\n\n..."  # deployment.py:1236-1258
    if rework_iter > 0:                                       # deployment.py:1259  BRANCH 2
        body += f"\n**Rework iteration:** {rework_iter}\n"    # deployment.py:1260
    return body                                               # deployment.py:1261
```
- **2 branches.** Same shape as G-DP-1 but cert (not safety) in the Tier-1 checklist, and a
  6-step "All Deployment Steps Completed" list.
- ⚠️ **GOTCHA-PR-BODY (rework footer only when count>0; tier note only for Tier-1):** both
  builders read the CURRENT rework count via `_rework_count(gate)` — so on a rework re-PR the body
  shows the (already-bumped) iteration number. A rebuild reproduces both conditionals.

---

## 21. RESILIENCE

- **Timeouts:** `create_gate_record` 30s; `persist_deployment_side_effects` 60s;
  `emit_disposition_output_bundle` 60s; the parallel-run `workflow.sleep` is 90/30/14 days (durable
  timer, collapses under time-skipping); inherited-helper timeouts per `_LineWorkflowBase.md` §19.
  The entry-signal wait is capped at `ENTRY_SIGNAL_WAIT_SECONDS=1800s`.
- **Heartbeats:** none.
- **continue-as-new:** none.
- **Idempotency:** inherited deterministic `activity_id`s on dispatch/commit/patch (base);
  `create_gate_record`/`persist_*`/`emit_*` have NO explicit `activity_id` (rely on Temporal's
  per-call dedup on replay). `_now_iso()` = `workflow.now()` is deterministic. `run_suffix`/branch
  derive deterministically from `workflow.info().workflow_id`.
- **Compensation / rollback:** none. Failure semantics:
  - Rework exhaustion → graceful `"failed"` return via `_fail` (best-effort `failed` projection;
    lifecycle stays `deployment_in_progress`).
  - Unexpected exception → run()'s outer `except` flips FAILED, best-effort
    `deployment_in_progress`/`failed` status push, then **re-raises** (workflow fails in Temporal).
  - Best-effort activities that swallow failures: `_persist_side_effects` projection, `_fail`
    projection, run()'s terminal status push, all inherited best-effort activities (context-priors,
    mirror, output-ref patch, pre-review, ready-flip).
  - Load-bearing (un-swallowed) activities: `create_gate_record`, `emit_disposition_output_bundle`,
    `_fail`'s final `_update_app_status`, and all the inherited gate/commit activities not marked
    best-effort.
  - Cancel (`self.cancelled`): drains the entry wait, both gate waits (base + Tier-1 stakeholder
    wait), and the merge_blocked wait to a `"cancelled"` return; `_execute_deployment` returns
    `"cancelled"` (NO projection, NO status push on the cancel path).

---

## 22. Behavioral parity checklist

A rebuilt `DeploymentWorkflow` MUST satisfy ALL of the following:

1. `class DeploymentWorkflow(LineWorkflowBase)`; classvars `ASSEMBLY_LINE=DEPLOYMENT`,
   `ARTIFACT_ROOT="deployment"`, `LINE_LABEL="Deployment"`, `STATUS_PREFIX="deployment"`,
   `STEPS=DEPLOYMENT_STEPS` (the 6 agent steps only), `STEP_WEIGHTS` (18 keys, sum 100.0).
   `SINGLE_GATE_KEY` is NOT set. (§1)
2. `__init__` calls `super().__init__()` FIRST, then initializes the 12 vars in §2 to their exact
   initial values, including the four `_*_json` capture vars (`""`),
   `_parallel_run_duration_days=0`, `_disposition_label=""`, the three stakeholder flags (`False`),
   `_bundle_approvals=[]`, both entry-signal vars (`None`).
3. Exactly THREE new `@workflow.signal` handlers: `validation_approved` (buffers
   `_validation_signal`), `disposition_executed` (buffers `_disposition_signal`),
   `stakeholder_approved` (3-scope branch: g-dp1-ops/g-dp2-ops→ops flag, g-dp1-safety→safety flag,
   g-dp2-cert→cert flag; unknown scopes no-op). All `async def`, all bump `_updated_at`. NONE of
   the four base gate signals nor `get_status` are redefined. (§3)
4. `_rework_gate_key_for_step` is OVERRIDDEN: `legacy-decommission`/`cost-certification`→`"G-DP-2"`,
   ELSE→`"G-DP-1"`. (§4.1)
5. `run()` sets RUNNING + timestamps, populates `_risk_tier=int(input.risk_tier) if not None else
   None`, derives `branch=f"olympus/deployment/{app_id}/{run_suffix}"` (run_suffix = last `-`-seg
   of wf id else first 8 chars) + `workspace_key=f"deployment-{app_id}-{run_suffix}"`, then
   try/except around `_execute_deployment`; on exception sets FAILED + step `"failed"` + best-effort
   `deployment_in_progress`/`failed` push, then **re-raises**. (§5)
6. `_execute_deployment` runs: intake (`_set_step("intake",0.0)` → `_resolve_entry_path` →
   `_resolve_prior_artifacts` → `active_steps=PATH_ACTIVE_STEPS.get(label, full)`); `cumulative=2.0`;
   IF `"orchestration" in active_steps` → `_run_deploy_and_shift` then `_run_gdp1_with_rework`
   (return `"cancelled"`/`_fail("max-rework-exceeded-gdp1")` on those outcomes) then add the SIX
   G-DP-1-cluster weights to cumulative; then `_run_gdp2_with_rework` (return
   `"cancelled"`/`_fail("max-rework-exceeded-gdp2")`); then `_set_step("persist-...",96.0)` +
   `_persist_side_effects`; then `_set_step("merge-final-gate-pr",98.0)`; IF label in
   ("Refactor","Rearchitect") → `_emit_output_bundle`; then `_update_app_status(app_id,
   "sustainment_active","registered","Sustainment")`, set COMPLETED + 100.0 + step "completed",
   return `"completed"`. (§5.1 — all 6 branches)
7. Retire path: `PATH_ACTIVE_STEPS["Retire"]` has no `"orchestration"`, so the entire
   deploy+G-DP-1 block is skipped and control jumps to G-DP-2 with cumulative still 2.0. No
   `_emit_output_bundle` (Retire not in the tuple). (GOTCHA-EX2/EX3, GOTCHA-RETIRE)
8. `_resolve_entry_path`: IF `input.disposition is not None` → label=`.value`, return (no wait);
   ELSE wait_condition on `(_validation_signal or _disposition_signal or cancelled)` capped at
   1800s; on timeout (`except`) → label=`"Refactor"`, return; else IF `_disposition_signal` →
   label=`signal.disposition`, default tier 2 if None; ELIF `_validation_signal` → parse tier from
   `signal.risk_tier` (None+truthy guard, try/except→2), label=`"Refactor"`; ELSE (cancelled) →
   label=`"Refactor"`. (§6 — all 8 branches; disposition signal checked before validation)
9. `_resolve_prior_artifacts`: input refs, then non-empty/non-dup `validation_output_refs`, then
   non-empty/non-dup `disposition_output_ref`; order-preserving `not in` dedup. (§7)
10. `_run_deploy_and_shift`: for ("orchestration","traffic-shifting","parallel-run") →
    `_set_step(step, cumulative)` → `_dispatch_agent` → set `_step_results[step]` →
    `_commit_step_artifacts` (path `deployment/{app_id}/{artifact}`) → `cumulative += weight`;
    capture `_manifest_json=output_artifacts[0] if any else ""` after orchestration; after
    parallel-run resolve `_parallel_run_days(input.risk_tier, self._risk_tier)`, set
    `_parallel_run_duration_days`, then `await workflow.sleep(timedelta(days=duration))`. Returns
    cumulative. (§8 — incl. the durable sleep timer, GOTCHA-DS1)
11. `_parallel_run_days`: checks `[resolved_tier, input_tier]` (resolved FIRST), skips None /
    unparseable (try/except), returns `PARALLEL_RUN_DAYS.get(tier, 30)`; both missing → 30.
    PARALLEL_RUN_DAYS = {1:90,2:30,3:14}. (§0.5 — 4 branches, resolved-wins precedence)
12. `_inputs_for_step`: input prior_artifacts + every prior PRIMARY step's committed paths up to
    (NOT including) the current step, dedup_paths. Iterates `PRIMARY_STEP_ORDER`, breaks at current.
    (§9)
13. `_run_gate`: assemble evidence_paths from `_step_committed_paths` over evidence_steps (dedup);
    `_create_gate_pr` (gate_type.value); `create_gate_record` (30s/transient); `_submit_gate_evidence`
    (gate_type enum, line="Deployment", step=gate_step); `_run_gate_pre_review` (artifact_repo/ref
    passed); `_set_step(gate_step, _progress_for_gate(gate_step))`;
    `_wait_for_gate_decision_with_tier_1`; on "cancelled" return "cancelled"; on "approved" →
    `_reconcile_and_merge_with_retry_loop(merge_method="merge")`, approver=`_gate_decisions[-1][1]`
    else "unknown", append to `_bundle_approvals` (record_ref `gates/{gate_id}/decision.json`),
    return "approved"; else return "rejected". (§10 — 3 branches + loop)
14. `_run_gdp1_with_rework`: `while True` → dispatch+commit `adoption-verification` → `_run_gate`
    (G_DP_1, gate-review-dp1, evidence=[orchestration,traffic-shifting,parallel-run,
    adoption-verification], title "Gate G-DP-1: Cutover Go — {app_id}", body `_build_gdp1_pr_body`);
    on "cancelled" return; on "rejected" `_bump_rework("G-DP-1")` then if `>3` return "failed" else
    continue; else return "approved". Re-runs ONLY adoption-verification on rework. (§11 — 3 branches)
15. `_run_gdp2_with_rework`: `while True` → `step_cumulative=cumulative` (reset per iter) → for
    ("legacy-decommission","cost-certification") dispatch+commit, capture
    `_decommission_certificate_json=[0]`/`_license_reclamation_json=[1] if len>1`/
    `_cost_certification_json=[0]`; `_run_gate` (G_DP_2, gate-review-dp2, evidence=PRIMARY_STEP_ORDER,
    title "Gate G-DP-2: Deployment Complete — {app_id}", body `_build_gdp2_pr_body`); on "cancelled"
    return; on "rejected" `_bump_rework("G-DP-2")` then if `>3` return "failed" else continue; else
    return "approved". Re-runs BOTH steps on rework. (§12 — 8 branches + 2 loops)
16. Rework ceiling: `_bump_rework` THEN strict `> MAX_REWORK_ITERATIONS(3)` → exactly 3 rework
    iterations tolerated, fail on the 4th rejection, per independent counter "G-DP-1"/"G-DP-2".
    (GOTCHA-G1RW3/G2RW4)
17. `_wait_for_gate_decision_with_tier_1`: IF `_risk_tier != 1` → delegate to base
    `_wait_for_gate_decision`; ELSE base wait for PM, return immediately if `!= "approved"`, else
    `wait_condition(_tier_1_stakeholders_ready(gate) or cancelled)` (no timeout); on cancel set
    CANCELLED + return "cancelled"; else "approved". (§13 — 3 branches)
18. `_tier_1_stakeholders_ready`: G_DP_1 → `ops AND safety`; G_DP_2 → `ops AND cert`; else True.
    `_stakeholder_ops_approved` is SHARED across both gates (g-dp1-ops and g-dp2-ops both set it),
    never reset. (§13.1, GOTCHA-STK1/T1R1)
19. `_progress_for_gate`: cumulative `STEP_WEIGHTS` over `CANONICAL_STEP_ORDER` up to AND INCLUDING
    gate_step (add-then-break). gate-review-dp1→60.0, gate-review-dp2→96.0. (§14)
20. `_persist_side_effects`: IF `_parallel_run_duration_days AND _manifest_json AND '"parallel_run"'
    not in manifest` → try `json.loads`; if dict, `setdefault("parallel_run",{})`, if that's a
    dict set `observed_duration_days`, re-dumps; except(TypeError,ValueError) pass (keep original);
    then try `persist_deployment_side_effects` (status="completed", 60s/transient) except → log
    warning + continue. Best-effort. (§15 — 5 branches)
21. `_fail(reason_step, app_id)`: set FAILED + step=reason_step; try `persist_deployment_side_effects`
    (RAW manifest, status="failed", 60s/transient) except pass; then UNGUARDED
    `_update_app_status(app_id, "deployment_in_progress", reason_step, "Deployment")` (lifecycle
    does NOT advance to sustainment); return "failed". (§16 — GOTCHA-FAIL1/2/3)
22. `_emit_output_bundle` (Refactor/Rearchitect only): build payload + bundle with wave_id-conditional
    refs (decision_ref `""` when no wave, baseline/user_impact `None` when no wave); Rearchitect adds
    `bounded_context_map_ref`; `approvals=list(_bundle_approvals)`; UNGUARDED
    `emit_disposition_output_bundle` (60s/transient) — failure fails the workflow. (§17 — 7 branches)
23. `_build_gdp1_pr_body`/`_build_gdp2_pr_body`: Tier-1 note only when `_risk_tier==1` (g-dp1-ops/
    g-dp1-safety vs g-dp2-ops/g-dp2-cert); rework footer only when `_rework_count(gate) > 0`. (§20)
24. Direct activities: `create_gate_record` (30s), `persist_deployment_side_effects` (60s, ×2
    best-effort), `emit_disposition_output_bundle` (60s, load-bearing). NO child workflows. All
    imports under `workflow.unsafe.imports_passed_through()`. (§18)
25. Return values: `"completed"` (happy path, status COMPLETED + 100.0 + sustainment_active),
    `"cancelled"` (any cancel — no projection/status push), `"failed"` (rework exhaustion via
    `_fail`); unexpected exceptions re-raise (workflow fails). (§5, §21)
