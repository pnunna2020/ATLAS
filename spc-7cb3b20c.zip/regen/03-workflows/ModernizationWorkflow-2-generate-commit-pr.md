# `ModernizationWorkflow` — Part 2: Generate factory, commit/PR helpers, seeding & parsing (ATOMIC regen spec)

> **Source of truth:** `temporal/olympus_workflows/workflows/modernization.py` (**2819 lines**, HEAD
> `7cb3b20c`). Every `mod.py:line` citation is against that file at HEAD. **This file OWNS ONLY lines
> 1346–2819.** Lines 1–1344 (`__init__`, signal/query handlers, `_dispatch_agent` override,
> `_build_evidence_data` override, `run`/`_execute_modernization`, `_execute_extract` + its G-04a
> loop, `_persist_side_effects`, `_find_output_file_content`, `_select_extraction_skill`,
> `_dispatch_design_internal`, `_fold_bundle_design_outputs`, and the `_execute_design` G-04b loop)
> are specced in the **sibling file** `ModernizationWorkflow-1-state-extract-design.md`.
> Cross-references to that file are marked **[Part 1]**.
>
> ⚠️ **CHANGED vs the prior baseline (HEAD-refresh, this revision):** `_execute_generate` grew
> dramatically (now `mod.py:1710-2100`, was ~1587-1862, **+~115 lines net**) with FOUR new pieces and
> `_commit_generate_artifacts` was rewritten:
> 1. **Pre-loop DevSecOps resolution** — `if not self._devsecops_params:` →
>    `resolve_devsecops_profile` building the 8-key `_devsecops_params` dict ONCE before the rework
>    loop (`mod.py:1736-1755`). NEW.
> 2. **`security-scan-review` dispatch in try/except** — best-effort advisory triage of SAST/SCA
>    scanner output (`mod.py:1877-1890`). NEW.
> 3. **`iac-scaffolding-generator` dispatch** — rich cloud-resource IaC (`mod.py:1903-1910`). NEW.
> 4. **`validate_devsecops_baseline` activity + `if not baseline_validation.passed:` branch** — a
>    **machine-driven** Generate rework distinct from human G-04c rejection: it resets the Tier-1
>    flags, `_bump_rework("G-04c")`, fails-if `> MAX`, **else `continue`s the while-loop** to
>    RE-FAN-OUT (`mod.py:1942-1979`). The `continue` at `mod.py:1979` loops back BETWEEN the commit
>    and the PR — there is NO PR/gate-record on a baseline-failed iteration. NEW & subtle (§C0.7).
> 5. **`_commit_generate_artifacts` rewritten** — now uses the `route_generate_file` /
>    `is_root_bound` contract (W11) to split agent files between the **target repo root** (built-app +
>    DevSecOps baseline) and the namespaced `modernization/{app_id}/generate/` metadata; applies
>    **first-writer-wins** precedence across BC code → synthesis → IaC sources; captures the IaC
>    manifest separately; and stashes the root-bound set on `self._committed_baseline_files` for the
>    validator (§C3). The old per-BC `files/{bc}/{path}` layout is now produced *by the router*.
> 6. **NEW static helper `_output_file_fields`** (`mod.py:2175-2181`) normalises an OutputFile-or-dict
>    into `(path, content)`; used by `_commit_generate_artifacts` (§C2a).
>
> **Base engine:** `class ModernizationWorkflow(BundleAwareMixin, LineWorkflowBase)`. Inherited
> dispatch / commit / gate-wait / signal / query / merge-retry / evidence scaffolding is specced in
> **`_LineWorkflowBase.md`** (referenced **[Base §N]**), **`_HILSignalsMixin.md`**, and the
> `BundleAwareMixin` (`bundle_helpers.py`). This file does **not** re-reproduce inherited methods.
>
> **Scope of this file (the methods at mod.py:1346–2819):**
> `_is_batch_archetype` (1346) · `_collect_extract_artifacts` (1353) · `_workflow_input_prior_artifacts`
> (1376) · `_collect_design_artifacts` (1385) · `_commit_design_artifacts` (1392) ·
> `_build_design_review_content` (1601) · `_create_design_pr` (1671) · `_execute_generate` (1710, the
> Generate factory) · `_parse_bounded_contexts` (2102) · `_output_file_fields` (2175, NEW) ·
> `_commit_generate_artifacts` (2183) · `_create_generate_pr` (2342) · `_commit_extract_artifacts`
> (2399) · `_create_extract_pr` (2594) · `_sum_weights` (2654) · `_seed_patterns_from_registry`
> (2657) · `_mark_ready_for_review` (2752) · the module-level pure helper `parse_bc_names_from_yaml`
> (2777).
>
> ⚠️ The Ralph Loop itself lives in the **child** `GenerateBCWorkflow` (`generate_bc.py`) — out of
> scope here. This file specs only how the parent fans out children, gathers their `GenerateBCResult`s,
> folds them into synthesis/commit/gate, and the deterministic baseline gate.

---

## 0. WHERE THIS FITS — call graph into this file's scope

`run()` **[Part 1, mod.py:632]** → `_execute_modernization()` **[Part 1, mod.py:672]** does, in order:
1. `await self._seed_patterns_from_registry(input.portfolio_id)` — **§E1 (in scope)**, mod.py:692.
2. `await self._load_delegation_config(input.portfolio_id)` — inherited (base.py:487), mod.py:698.
3. `_execute_extract(...)` — **[Part 1]**; calls `_commit_extract_artifacts` (**§D1**),
   `_create_extract_pr` (**§D2**), `_mark_ready_for_review` (**§E2**).
4. `_execute_design(...)` — **[Part 1]**; calls `_is_batch_archetype` (**§A1**),
   `_collect_extract_artifacts` (**§A2**), `_collect_design_artifacts` (**§A4**),
   `_commit_design_artifacts` (**§B1**), `_create_design_pr` (**§B3**), `_mark_ready_for_review`
   (**§E2**), `_sum_weights` (**§E0**). (The internal-chain `_dispatch_design_internal` is **[Part 1]**.)
5. `_execute_generate(...)` — **§C (in scope, the bulk of this file)**.

Each `_execute_*` returns one of `"approved"` / `"failed"` / `"cancelled"`. `_execute_modernization`
short-circuits the whole run on any non-`"approved"` result **[Part 1, mod.py:709-724]**.

---

## 1. STATE this file's methods READ or MUTATE

All instance vars are initialized in `__init__` **[Part 1, mod.py:242-291]**. The in-scope methods
touch the following (base vars are documented in **[Base §2]**):

| Var | Type | Init | Read by (this file) | Mutated by (this file) |
|-----|------|------|---------------------|------------------------|
| `_extract_results` | `dict[str, list[str]]` | `{}` | `_commit_extract_artifacts`, `_collect_extract_artifacts` | — (written in `_execute_extract`, Part 1) |
| `_design_results` | `dict[str, list[str]]` | `{}` | `_commit_design_artifacts`, `_collect_design_artifacts`, `_create_design_pr`, `_parse_bounded_contexts`, `_build_design_review_content` | `_commit_design_artifacts` sets `["design-review"]` (mod.py:1583) |
| `_generate_results` | `list[GenerateBCResult]` | `[]` | (read in `_execute_generate` after gather) | `_execute_generate` → `list(bc_results)` (mod.py:1822) |
| `_received_patterns` | `list[dict]` | `[]` | (forwarded by `_dispatch_agent`, Part 1) | `_seed_patterns_from_registry` appends 1 cold-start entry (mod.py:2743) |
| `_agent_metadata` | `dict[str, dict]` | `{}` | `_commit_design_artifacts`, `_commit_extract_artifacts`, `_commit_generate_artifacts`, `_find_output_file_content` | `_commit_design_artifacts` sets `["design-review"]` (mod.py:1584); `_dispatch_agent` sets per-step (Part 1) |
| `_rework_iterations` | `dict[str,int]` | `{"G-04a":0,"G-04b":0,"G-04c":0}` | `_create_design_pr`/`_create_generate_pr`/`_create_extract_pr` via `_rework_count` | `_execute_generate` via `_bump_rework("G-04c")` at BOTH the baseline-validation-rework (mod.py:1967) AND the human-reject (mod.py:2089) sites |
| `_g04c_stakeholder_ea_approved` | `bool` | `False` | `_execute_generate` Tier-1 wait predicate (mod.py:2052) | `_execute_generate` reset on baseline-fail (1965) + on human-reject (2086) |
| `_g04c_stakeholder_security_approved` | `bool` | `False` | `_execute_generate` Tier-1 wait predicate (mod.py:2053) | `_execute_generate` reset on baseline-fail (1966) + on human-reject (2087) |
| `_devsecops_params` | `dict[str,Any]` | `{}` | `_dispatch_agent` injects `context["devsecops_baseline"]` **[Part 1 §6]**; `_execute_generate` reads `.get("sast_tool",...)` for the validator (mod.py:1947-1949) | `_execute_generate` sets the 8-key dict ONCE pre-loop (mod.py:1746-1755) |
| `_committed_baseline_files` | `list[tuple[str,str]]` | `[]` | `_execute_generate` passes to `validate_devsecops_baseline` (mod.py:1946) | `_commit_generate_artifacts` sets the root-bound+manifest set (mod.py:2339) |
| `_risk_tier` | `int \| None` | `None` | `_execute_generate` Tier-1 branch (mod.py:2048) | — (set in `run`, Part 1) |
| `_status` | `WorkflowStatus` | `PENDING` | — | `_execute_generate` → `CANCELLED` (2059) / `FAILED` (1969, 2091) |
| `_current_step` | `str` | `""` | — | `_execute_generate` → `"generate-baseline-incomplete"` (1970) / `"generate-max-rework-exceeded"` (2092) |
| `_updated_at` | `str` | `""` | — | `_execute_generate` (1971, 2093); `_seed_patterns_*` via `_now_iso()` in appended entry |
| `self.cancelled` | `bool` | (HIL mixin) | `_execute_generate` Tier-1 wait predicate (2055), post-wait check (2058) | — (set by `cancel_workflow` HIL signal) |
| `self._input` | `LineWorkflowInput` | (set in `run`, **NEW**) | `_workflow_input_prior_artifacts` (mod.py:1380) | — |

> ⚠️ **GOTCHA-STATE-1 (`_design_results["design-review"]` is a SYNTHETIC step):** `_commit_design_artifacts`
> writes `self._design_results["design-review"] = [review_path]` (mod.py:1583) and a matching
> `self._agent_metadata["design-review"]` entry (mod.py:1584-1597) **even though no agent dispatch
> named `design-review` ever ran.** This makes the design-review JSON appear as a `file_artifacts`
> entry in `_build_evidence_data`'s `"design"` bundle **[Part 1]** so the G-04b threshold check can
> read its content. A rebuild MUST inject this synthetic step after writing the review artifact, with
> the exact 6-key metadata (model_used="", duration_ms=0, token_usage_input=0, token_usage_output=0,
> cost_estimate_usd=0.0, output_files=[one OutputFile]).
> ⚠️ **GOTCHA-STATE-2 (NEW — `_committed_baseline_files` is the bridge from commit → validator):**
> `_commit_generate_artifacts` stashes the root-bound `(repo_path, content)` set (plus the IaC
> manifest) on `self._committed_baseline_files` (mod.py:2339); `_execute_generate` then passes a COPY
> of it (`list(self._committed_baseline_files)`, mod.py:1946) to `validate_devsecops_baseline`. The
> validator does NOT round-trip Git — it checks the in-memory set. A rebuild MUST stash and re-read
> this state across the two methods.

---

## 2. OVERRIDE MATRIX — what this subclass overrides vs. the base

| Base method | This subclass | Where |
|-------------|---------------|-------|
| `_dispatch_agent` | **OVERRIDDEN** (explicit `skill_id`+`source_repo`; injects governance + devsecops context) | **[Part 1, mod.py:409]** |
| `_build_evidence_data` | **OVERRIDDEN** (per-phase) | **[Part 1, mod.py:488]** |
| `_rework_gate_key_for_step` | **OVERRIDDEN** (G-04a/b/c map) | **[Part 1, mod.py:297]** |
| `_run_gate_pre_review` / `_submit_gate_evidence` / `_wait_for_gate_decision` / `_reconcile_and_merge_with_retry_loop` / `_bump_rework` / `_rework_count` | **INHERITED** **[Base]** | used here |
| `_commit_step_artifacts` (base flat commit) | **NOT USED** — Modernization uses its OWN per-phase commit helpers under `{extract\|design\|generate}/` sub-roots | this file |
| `_create_gate_pr` (base) | **NOT USED** — Modernization uses its OWN `_create_extract_pr`/`_create_design_pr`/`_create_generate_pr` (custom checklists) | this file |
| `_mark_ready_for_review` | **NEW METHOD** (subclass-only, mod.py:2752) — bare status flip | **§E2** |
| `_output_file_fields` | **NEW STATIC METHOD** (mod.py:2175) — `(path,content)` normaliser | **§C2a** |

> ⚠️ **GOTCHA-OVERRIDE-1 (must NOT redefine base/mixin gate signals / queries):** Per **[Base §3,
> §16]**, this subclass NEVER redefines `gate_approved`, `gate_rejected`, `escalation_resolved`,
> `merge_retry`, `get_status`, NOR the BundleAwareMixin `bundle_completed`/`bundle_expired` signals
> and `get_bundle_outcome`/`get_bundle_outputs` queries. It adds only `stakeholder_approved` +
> `wave_patterns_ready` and `get_received_patterns` **[all Part 1]**. Keep them inherited.

---

## A. Archetype + artifact-collection helpers

### A1. `_is_batch_archetype(self, input: LineWorkflowInput) -> bool` — mod.py:1346-1351

Pure predicate. Called from `_dispatch_design_internal` **[Part 1, mod.py:1129]**.

```text
def _is_batch_archetype(self, input):
    for artifact in input.prior_artifacts:          # mod.py:1348  LOOP
        if "batch" in artifact.lower():             # mod.py:1349  BRANCH 1
            return True                             # mod.py:1350  ← early return
    return False                                    # mod.py:1351
```

- ⚠️ **GOTCHA-A1 (substring, not exact):** matches ANY prior-artifact path containing the literal
  substring `"batch"` (case-insensitive). Lowercase the whole path and test `"batch" in …`, not a
  structured archetype field.

### A2. `_collect_extract_artifacts(self) -> list[str]` — mod.py:1353-1374

Builds the Design step's input-artifact list: architecture/blueprint priors **prepended**, then every
extraction output. Called from `_dispatch_design_internal`'s `module-design` dispatch **[Part 1,
mod.py:1100]**.

```text
def _collect_extract_artifacts(self):
    artifacts = []                                                 # mod.py:1364
    for prior in self._workflow_input_prior_artifacts():           # mod.py:1365  LOOP (see A3)
        if "architecture" in prior.lower() or "blueprint" in prior.lower():   # mod.py:1370  BRANCH 1
            artifacts.append(prior)                                # mod.py:1371
    for step_artifacts in self._extract_results.values():          # mod.py:1372  LOOP
        artifacts.extend(step_artifacts)                           # mod.py:1373
    return dedup_paths(artifacts)                                  # mod.py:1374
```

- ⚠️ **GOTCHA-A2 (ordering matters — arch priors FIRST):** architecture/blueprint priors are
  appended BEFORE extraction outputs (1365-1371 before 1372-1373), so the Design agent sees the
  target-architecture blueprint at the head of its input list. `dedup_paths` (= `list(dict.fromkeys(...))`,
  **first-wins, order-preserving**) is applied last (1374). Preserve this exact order, first-wins dedup.
- ⚠️ **GOTCHA-A2b (`.values()` iteration order):** iterates `_extract_results.values()` — dict
  insertion order. Extract inserts `extraction` → `cross-validation` → [`requirement-aggregation` →
  `business-rule-reconciliation` if patched] **[Part 1]**. Iterate insertion order, not sorted keys.

### A3. `_workflow_input_prior_artifacts(self) -> list[str]` — mod.py:1376-1383

Defensive accessor for `self._input.prior_artifacts`.

```text
def _workflow_input_prior_artifacts(self):
    input_obj = getattr(self, "_input", None)                      # mod.py:1380
    if input_obj is None:                                          # mod.py:1381  BRANCH 1
        return []                                                  # mod.py:1382  ← stub-run guard
    return list(getattr(input_obj, "prior_artifacts", []) or [])   # mod.py:1383
```

- ⚠️ **GOTCHA-A3 (CHANGED — `self._input` IS now set in the live run path):** this reads `self._input`
  via `getattr(..., None)`. **The prior baseline spec claimed `_input` is "never assigned in
  production" so this method "collects nothing in production" — that is now STALE/WRONG.** As of HEAD,
  `run` assigns `self._input = input` **[Part 1, mod.py:650]**, so in normal production runs this
  returns the real `prior_artifacts` and `_collect_extract_artifacts` (§A2) DOES prepend architecture/
  blueprint priors. The `getattr(..., None)` guard remains because unit tests may stub `run` without
  setting `_input` (then it returns `[]`). The `... or []` also coerces a `None`-valued
  `prior_artifacts` to `[]`. A rebuild MUST keep the defensive read AND ensure `run` populates
  `self._input` (do NOT read the `input` parameter directly here — read the instance attribute).

### A4. `_collect_design_artifacts(self) -> list[str]` — mod.py:1385-1390

```text
def _collect_design_artifacts(self):
    artifacts = []                                          # mod.py:1387
    for step_artifacts in self._design_results.values():    # mod.py:1388  LOOP
        artifacts.extend(step_artifacts)                    # mod.py:1389
    return dedup_paths(artifacts)                           # mod.py:1390
```

- Flat collection of every design step's output artifacts, order-preserving dedup. Called from
  `_dispatch_design_internal`'s `traceability-audit` dispatch **[Part 1, mod.py:1147]** AND from
  `_execute_generate`'s per-BC child input (`design_artifacts=self._collect_design_artifacts()`,
  mod.py:1802).
- ⚠️ **GOTCHA-A4 (includes the synthetic `design-review` entry IF already set):** if called AFTER
  `_commit_design_artifacts` ran, `_design_results` contains `"design-review": [review_path]`
  (GOTCHA-STATE-1). In `_dispatch_design_internal` `traceability-audit` runs BEFORE commit, so
  `design-review` is absent at that call site; in `_execute_generate` it runs after G-04b approval so
  the review path IS present. Don't special-case — it falls out of iterating `.values()` per timing.

---

## B. Design commit + PR helpers (called by `_execute_design` [Part 1])

### B1. `_commit_design_artifacts(self, repo, branch, app_id, audit_result=None) -> list[str]` — mod.py:1392-1599

Commits each design skill's summary JSON + its output files, then emits the `design-review.json`
threshold-evidence artifact, then injects the synthetic `design-review` step into state. **Branch-heavy.**

**Signature & call site:** `await self._commit_design_artifacts(repo, branch, app_id,
audit_result=audit_result)` **[Part 1, mod.py:1243-1245]** where `audit_result` is the
traceability-audit result on the internal path, or **`None`** on the delegated-bundle path **[Part 1
GOTCHA-DS1-NEW]**.

```text
async def _commit_design_artifacts(self, repo, branch, app_id, audit_result=None):
    use_batch = workflow.patched("modernization-batch-writes-v1")     # mod.py:1418  PATCH GATE
    committed_paths = []                                              # mod.py:1419

    for step_name, skill_def in DESIGN_SKILLS.items():                # mod.py:1420  LOOP (4 skills)
        artifacts = self._design_results.get(step_name, [])           # mod.py:1421
        if not artifacts:                                             # mod.py:1422  BRANCH — skip unrun skill
            continue                                                  # mod.py:1423

        artifact_path = f"modernization/{app_id}/design/{skill_def['artifact']}"   # mod.py:1425-1427
        metadata = self._agent_metadata.get(step_name, {})            # mod.py:1428
        output_files = metadata.get("output_files", [])               # mod.py:1429

        content = json.dumps({                                        # mod.py:1431-1440
            "step": step_name, "artifacts": artifacts,
            "model_used": metadata.get("model_used", ""),
            "duration_ms": metadata.get("duration_ms", 0),
            "timestamp": workflow.now().isoformat(),                  # mod.py:1437  deterministic
        }, indent=2)

        design_commit_ctx = self._execution_ctx(f"commit-design-{step_name}", app_id=app_id)   # mod.py:1442-1445

        if use_batch:                                                 # mod.py:1446  BRANCH (batch path)
            batch = [(artifact_path, content)]                        # mod.py:1447
            committed_paths.append(artifact_path)                     # mod.py:1448
            for file_artifact in output_files:                        # mod.py:1449  LOOP
                if isinstance(file_artifact, dict):                   # mod.py:1450  BRANCH (dict-vs-OutputFile)
                    fa_path = file_artifact["path"]; fa_content = file_artifact["content"]   # mod.py:1451-1452
                else:
                    fa_path = file_artifact.path; fa_content = file_artifact.content          # mod.py:1454-1455
                file_path = f"modernization/{app_id}/design/files/{step_name}/{fa_path}"      # mod.py:1456-1459
                batch.append((file_path, fa_content)); committed_paths.append(file_path)      # mod.py:1460-1461
            await workflow.execute_activity(write_artifacts_batch, ...,                        # mod.py:1462
                commit_message=f"modernization({app_id}): design {step_name}",
                start_to_close_timeout=timedelta(seconds=120),
                activity_id=f"commit-design-{step_name}")             # mod.py:1475
        else:                                                         # mod.py:1477  (per-file legacy path)
            await workflow.execute_activity(write_artifact, ...,                               # mod.py:1478
                commit_message=f"modernization({app_id}): design {step_name}",
                start_to_close_timeout=timedelta(seconds=60),
                activity_id=f"commit-design-{step_name}")             # mod.py:1492
            committed_paths.append(artifact_path)                     # mod.py:1494
            for file_artifact in output_files:                        # mod.py:1496  LOOP (one activity per file!)
                file_path = f"modernization/{app_id}/design/files/{step_name}/{file_artifact.path}"  # mod.py:1497-1500
                await workflow.execute_activity(write_artifact, ...,                           # mod.py:1501
                    commit_message=f"modernization({app_id}): design {step_name} file {file_artifact.path}",
                    activity_id=f"commit-design-file-{step_name}-{file_artifact.path.replace('/', '-')}")  # mod.py:1516-1519
                committed_paths.append(file_path)                     # mod.py:1521

    # -- design-review.json emission (F3 G-04b threshold evidence) --
    review_path = f"modernization/{app_id}/design/design-review.json"                # mod.py:1533
    review_content_str = self._build_design_review_content(                          # mod.py:1534 (see B2)
        app_id=app_id, audit_result=audit_result, review_path=review_path)
    if use_batch:                                                     # mod.py:1539  BRANCH
        await workflow.execute_activity(write_artifacts_batch, ...,
            files=[(review_path, review_content_str)],
            commit_message=f"modernization({app_id}): design-review summary",
            start_to_close_timeout=timedelta(seconds=120), activity_id="commit-design-review")  # mod.py:1556
    else:
        await workflow.execute_activity(write_artifact, ..., path=review_path, content=review_content_str,
            commit_message=f"modernization({app_id}): design-review summary",
            start_to_close_timeout=timedelta(seconds=60), activity_id="commit-design-review")    # mod.py:1576
    committed_paths.append(review_path)                               # mod.py:1578

    # -- inject synthetic design-review step into state (GOTCHA-STATE-1) --
    self._design_results["design-review"] = [review_path]             # mod.py:1583
    self._agent_metadata["design-review"] = {                         # mod.py:1584-1597
        "model_used": "", "duration_ms": 0, "token_usage_input": 0,
        "token_usage_output": 0, "cost_estimate_usd": 0.0,
        "output_files": [OutputFile(path=review_path, content=review_content_str, encoding="utf-8")],
    }
    return dedup_paths(committed_paths)                               # mod.py:1599
```

**Branch inventory (7 + 3 loops):** `use_batch` patch (1418, consulted at 1446 & 1539); `for
step_name, skill_def in DESIGN_SKILLS.items()` (1420); `if not artifacts: continue` (1422); `if
use_batch:` (1446) vs else (1477); `for file_artifact in output_files:` (1449 batch / 1496 legacy);
`if isinstance(file_artifact, dict):` (1450, batch path only); `if use_batch:` (1539) vs else.

**`DESIGN_SKILLS` [Part 1 §1.3]:** `module-design`→`module-map.yaml`, `api-specification`→
`openapi.yaml`, `data-modeling`→`data-model.yaml`, `batch-design`→`batch-design.yaml`. Note
`traceability-audit` is NOT in `DESIGN_SKILLS`, so its summary JSON is NOT committed here — only its
output drives `design-review.json` via `audit_result`.

> ⚠️ **GOTCHA-B1-1 (patch ID verbatim — `modernization-batch-writes-v1`):** drives batch-vs-per-file
> (1418). Use this EXACT string — changing it triggers nondeterminism for in-flight pre-patch runs.
> ⚠️ **GOTCHA-B1-2 (legacy per-file activity_id has slashes replaced):**
> `f"commit-design-file-{step_name}-{file_artifact.path.replace('/', '-')}"` (1516-1519). Reproduce
> the `/`→`-` substitution so ids stay valid & deterministic.
> ⚠️ **GOTCHA-B1-3 (batch path does dict-vs-OutputFile coercion; legacy does NOT):** the batch loop
> (1450-1455) tolerates dict OR `OutputFile`; the legacy loop (1496-1500) directly accesses
> `.path`/`.content`. This asymmetry is in the source — do NOT "harmonize" it.
> ⚠️ **GOTCHA-B1-4 (file commit path template):**
> `modernization/{app_id}/design/files/{step_name}/{fa_path}` (1456-1459 / 1497-1500). Per-phase
> nested layout (NOT base's `{ARTIFACT_ROOT}/{app_id}/files/{step}/{path}`). The top-level summary
> path is `modernization/{app_id}/design/{skill_def['artifact']}`. **`_parse_bounded_contexts` (§C2)
> depends on this exact files/ path** to read `module-map.yaml`. Reproduce both templates exactly.
> ⚠️ **GOTCHA-B1-5 (summary `content` schema is the 5-key shape, differs from extract):** the
> per-skill summary JSON here has 5 keys (`step`/`artifacts`/`model_used`/`duration_ms`/`timestamp`) —
> NO `file_artifacts`/`token_usage`/`cost_estimate_usd`. `_commit_extract_artifacts` (§D1) uses a
> RICHER 7-key schema. Keep the design summary at exactly these 5 fields.
> ⚠️ **GOTCHA-B1-6 (final `dedup_paths` on committed_paths):** returns `dedup_paths(committed_paths)`
> (1599), order-preserving first-wins; this is what `_execute_design` passes as `artifact_paths`.

### B2. `_build_design_review_content(self, app_id, audit_result, review_path) -> str` — mod.py:1601-1669

Returns the `design-review.json` body string. Two paths: audit-skill-provided vs provisional legacy.

```text
def _build_design_review_content(self, app_id, audit_result, review_path):
    if audit_result is not None:                                      # mod.py:1623  BRANCH 1
        for f in audit_result.output_files:                          # mod.py:1627  LOOP
            if f.path.endswith("design-review.json"):                # mod.py:1628  BRANCH 2
                return f.content                                     # mod.py:1629  ← prefer matching file
        if audit_result.output_files:                                # mod.py:1630  BRANCH 3
            return audit_result.output_files[0].content              # mod.py:1631  ← fallback to first file
        workflow.logger.warning("traceability-audit produced no output_files; "
            "emitting provisional review content instead", extra={...})   # mod.py:1635-1639
        # falls through to legacy default below

    review_doc = {                                                   # mod.py:1644-1668
        "app_id": app_id, "timestamp": workflow.now().isoformat(),   # mod.py:1646  deterministic
        "forward_coverage": 0.99,                                    # mod.py:1649  T1 needs 0.99, T2/3 0.98 → 0.99 passes both
        "backward_coverage": 0.99, "critical_508_violations": 0,
        "journey_preservation_pct": 1.0, "bounded_contexts_defined": True,
        "openapi_valid": True,                                       # mod.py:1654  key matches GATE_THRESHOLDS verbatim
        "ddd_elements_present": True,
        "design_steps_evaluated": sorted(self._design_results.keys()),   # mod.py:1659
        "provisional": True, "provisional_note": "...",              # mod.py:1660-1667
    }
    return json.dumps(review_doc, indent=2)                          # mod.py:1669
```

**Branch inventory (3 + loop):** `if audit_result is not None:` (1623); `for f in
audit_result.output_files:` (1627); `if f.path.endswith("design-review.json"):` (1628); `if
audit_result.output_files:` (1630).

> ⚠️ **GOTCHA-B2-1 (THREE sub-paths — audit content / first-file / provisional):** when
> `audit_result is not None` it returns the audit skill's matching (suffix `design-review.json`)
> output_file content VERBATIM, else the FIRST output_file, else (no files) warns + falls through. The
> provisional dict (1644-1668) is reached when `audit_result is None` (delegated-bundle path **[Part 1
> GOTCHA-DS1-NEW]**, or pre-patch legacy replay) OR when the audit skill produced ZERO files.
> Reproduce all three.
> ⚠️ **GOTCHA-B2-2 (`endswith` selection, then `[0]` fallback):** prefers the file whose path ENDS
> WITH `design-review.json` (1628), else the FIRST (1631). Try the suffix-match first.
> ⚠️ **GOTCHA-B2-3 (provisional thresholds are pass-by-construction):** `forward_coverage=0.99`,
> `critical_508_violations=0`, all booleans True — chosen so the G-04b threshold predicates in
> `gate_operations.GATE_THRESHOLDS["G-04b"]` pass for BOTH tiers. Keys
> (`forward_coverage`/`bounded_contexts_defined`/`openapi_valid`/`ddd_elements_present`/
> `critical_508_violations`/`journey_preservation_pct`) match the threshold spec verbatim. Keep these
> exact keys & pass-values, and `provisional: True`. ⚠️ Note the delegated-bundle path now routinely
> hits this provisional doc (since `audit_result=None` on a bundle), so it is no longer "legacy only".

### B3. `_create_design_pr(self, repo, branch, app_id)` — mod.py:1671-1704

```text
async def _create_design_pr(self, repo, branch, app_id):
    rework = self._rework_count("G-04b")                             # mod.py:1673
    pr_body = ("## Gate G-04b Review: Modernization Design Review\n\n"
               f"**Application:** {app_id}\n\n### Artifacts\n"
               "- [x] Module Map (`module-map.yaml`)\n- [x] API Specification (`openapi.yaml`)\n"
               "- [x] Data Model (`data-model.yaml`)\n")              # mod.py:1674-1681
    if "batch-design" in self._design_results:                       # mod.py:1682  BRANCH 1
        pr_body += "- [x] Batch Design (`batch-design.yaml`)\n"       # mod.py:1683
    pr_body += "- [x] Design Review Summary (`design-review.json`)\n" # mod.py:1684
    if rework > 0:                                                   # mod.py:1685  BRANCH 2
        pr_body += f"\n**Rework iteration:** {rework}\n"             # mod.py:1686

    return await workflow.execute_activity(create_pr,                # mod.py:1688
        CreatePRInput(repo=repo, source_branch=branch, target_branch="main",
            title=f"Gate G-04b: Modernization Design Review — {app_id}", body=pr_body,
            labels=["gate-review", "modernization", "design", "G-04b"],     # mod.py:1696
            execution_context=self._execution_ctx("create-g-04b-pr", app_id=app_id)),
        start_to_close_timeout=timedelta(seconds=60), retry_policy=RETRY_POLICIES["transient"])
```

- **Branch inventory (2):** `if "batch-design" in self._design_results:` (1682); `if rework > 0:`
  (1685). Returns the `CreatePRResult` (`.pr_number`, `.pr_url`). **Activity:** `create_pr`, 60s,
  `transient`, target `main`.
- ⚠️ **GOTCHA-B3-1 (custom labels — 4 not 3):** `["gate-review", "modernization", "design", "G-04b"]`
  (1696) — FOUR labels, vs base `_create_gate_pr`'s three. This is why Modernization has its OWN PR
  helper.
- ⚠️ **GOTCHA-B3-2 (batch-design line keyed on state membership):** the optional Batch Design line
  appears iff `"batch-design"` is a key in `_design_results` (1682).

---

## C. Generate factory — `_execute_generate` and its helpers ★ CORE

### C0. The G-04c rework loop — `_execute_generate(self, input, app_id, repo, source_repo, run_suffix, workspace_key) -> str` — mod.py:1710-2100

The third and final factory step. Returns `"approved"` / `"failed"` / `"cancelled"`. A `while True`
rework loop, structurally parallel to G-04a/G-04b **[Part 1]** but with: a **pre-loop DevSecOps
resolution**, BC fan-out via child workflows, **SIX generate dispatches** (synthesis +
adversarial-review + security-posture-review + security-scan-review[try/except] + iac-scaffolding +
gate-review-package), a **deterministic baseline validator** that can trigger a machine-driven rework
mid-loop, and a Tier-1 **triple-signal** approval gate.

```text
async def _execute_generate(self, input, app_id, repo, source_repo, run_suffix, workspace_key):
    branch = f"olympus/modernization/generate/{app_id}/{run_suffix}"          # mod.py:1720
    generate_base = self._sum_weights(                                        # mod.py:1721-1729
        "extract","cross-validation","extract-commit","extract-gate",
        "design","design-commit","design-gate")          # = 15+5+2.5+7.5+15+2.5+7.5 = 55.0

    # -- PRE-LOOP: resolve DevSecOps baseline params ONCE (NEW, P6-S11.6) --
    if not self._devsecops_params:                                            # mod.py:1736  BRANCH 0 (NEW)
        ds_params = await workflow.execute_activity(resolve_devsecops_profile,  # mod.py:1737
            ResolveDevSecOpsProfileInput(profile_id=input.portfolio_id or ""),  # mod.py:1739-1741
            start_to_close_timeout=timedelta(seconds=30),
            retry_policy=RETRY_POLICIES["transient"],
            activity_id=f"resolve-devsecops-{app_id}")                        # mod.py:1744
        self._devsecops_params = {                                            # mod.py:1746-1755  ★8 keys
            "sast_tool": ds_params.sast_tool,         "sbom_required": ds_params.sbom_required,
            "container_base": ds_params.container_base,"license": ds_params.license,
            "target_cloud": ds_params.target_cloud,   "primary_ecosystem": ds_params.primary_ecosystem,
            "iac": ds_params.iac,                     "cicd": ds_params.cicd,
        }

    while True:                                                               # mod.py:1757  ★REWORK LOOP
        await self._set_step("generate", generate_base)                       # mod.py:1758

        # -- Parse bounded contexts from committed module-map.yaml (§C2) --
        bc_names = await self._parse_bounded_contexts(repo=repo, app_id=app_id)   # mod.py:1765-1767

        # -- Per-BC framework routing + fan-out --
        _FRONTEND_BC_NAMES = {"frontend", "ui", "web-app", "spa"}              # mod.py:1781
        _DEFAULT_BACKEND_FRAMEWORK = "express"                                 # mod.py:1782
        _DEFAULT_FRONTEND = "react"                                            # mod.py:1783

        bc_tasks = []                                                          # mod.py:1785
        for bc_name in bc_names[:MAX_BC_CHILDREN_PER_APP]:                     # mod.py:1786  LOOP (cap 12)
            bc_name_lower = bc_name.lower()                                    # mod.py:1787
            if bc_name_lower in _FRONTEND_BC_NAMES:                            # mod.py:1788  BRANCH (frontend vs backend)
                bc_framework = None                                           # mod.py:1789
                bc_frontend = input.target_frontend or _DEFAULT_FRONTEND      # mod.py:1790
            else:
                bc_framework = input.target_framework or _DEFAULT_BACKEND_FRAMEWORK   # mod.py:1792
                bc_frontend = None                                            # mod.py:1793
            bc_input = GenerateBCInput(                                        # mod.py:1795-1806
                app_id=app_id, bc_name=bc_name, wave_id=input.wave_id,
                portfolio_id=input.portfolio_id, artifact_repo=repo, source_repo=source_repo,
                design_artifacts=self._collect_design_artifacts(),            # §A4
                target_framework=bc_framework, target_frontend=bc_frontend,
                primary_language=input.primary_language)
            task = workflow.execute_child_workflow("GenerateBCWorkflow", bc_input,  # mod.py:1807
                id=f"generate-bc-{app_id}-{bc_name}-{run_suffix}",            # mod.py:1810  ★child id
                task_queue=workflow.info().task_queue)                        # mod.py:1811
            bc_tasks.append(task)                                             # mod.py:1813

        raw_results = await asyncio.gather(*bc_tasks)                          # mod.py:1816  ★PARALLEL wait
        bc_results = [GenerateBCResult(**r) if isinstance(r, dict) else r      # mod.py:1818-1821  BRANCH (dict coercion)
                      for r in raw_results]
        self._generate_results = list(bc_results)                             # mod.py:1822

        # -- Synthesis --
        await self._set_step("generate-synthesis", generate_base + STEP_WEIGHTS["generate"])   # mod.py:1825-1828
        synthesis_result = await self._dispatch_agent(                        # mod.py:1829
            app_id=app_id, step_name="synthesis", skill_id="code-synthesis",
            input_artifacts=[a for r in bc_results for a in r.output_artifacts],   # mod.py:1833-1835  flatten
            source_repo=source_repo, workspace_key=workspace_key)

        # -- Adversarial review --
        await self._set_step("generate-review",
            generate_base + STEP_WEIGHTS["generate"] + STEP_WEIGHTS["generate-synthesis"])   # mod.py:1841-1846
        await self._dispatch_agent(app_id=app_id, step_name="adversarial-review",            # mod.py:1847
            skill_id="adversarial-review", input_artifacts=synthesis_result.output_artifacts,
            source_repo=source_repo, workspace_key=workspace_key)

        # -- Security-posture review (W19 PR C) --
        await self._dispatch_agent(app_id=app_id, step_name="security-posture-review",       # mod.py:1861
            skill_id="security-posture-review", input_artifacts=synthesis_result.output_artifacts,
            source_repo=source_repo, workspace_key=workspace_key)

        # -- Security-scan review — BEST-EFFORT (NEW, P6-S8.3) --
        try:                                                                  # mod.py:1877
            await self._dispatch_agent(app_id=app_id, step_name="security-scan-review",       # mod.py:1878
                skill_id="security-scan-review", input_artifacts=synthesis_result.output_artifacts,
                source_repo=source_repo, workspace_key=workspace_key)
        except Exception as exc:                                              # mod.py:1886  BRANCH (advisory)
            workflow.logger.warning("security-scan-review dispatch failed (non-fatal): %s", exc)  # mod.py:1887-1890

        # -- IaC scaffolding generator (NEW, P6-S11.3) --
        await self._dispatch_agent(app_id=app_id, step_name="iac-scaffolding",                # mod.py:1903
            skill_id="iac-scaffolding-generator", input_artifacts=synthesis_result.output_artifacts,
            source_repo=source_repo, workspace_key=workspace_key)

        # -- Gate-review package --
        await self._dispatch_agent(app_id=app_id, step_name="gate-review-package",            # mod.py:1913
            skill_id="gate-review-package", input_artifacts=synthesis_result.output_artifacts,
            source_repo=source_repo, workspace_key=workspace_key)

        # -- Commit (sets _committed_baseline_files) --
        await self._set_step("generate-commit",
            generate_base + STEP_WEIGHTS["generate"] + STEP_WEIGHTS["generate-synthesis"]
            + STEP_WEIGHTS["generate-review"])                                # mod.py:1923-1929
        artifact_paths = await self._commit_generate_artifacts(repo, branch, app_id, bc_results)   # mod.py:1930 (§C2)

        # -- DETERMINISTIC BASELINE VALIDATOR — gates G-04c (NEW, P6-S11.5) --
        baseline_validation = await workflow.execute_activity(validate_devsecops_baseline,    # mod.py:1942
            ValidateDevSecOpsBaselineInput(app_id=app_id,
                committed_files=list(self._committed_baseline_files),         # mod.py:1946  (§C2 stash)
                sast_tool=str(self._devsecops_params.get("sast_tool", "codeql"))),  # mod.py:1947-1949
            start_to_close_timeout=timedelta(seconds=60), retry_policy=RETRY_POLICIES["transient"],
            activity_id=f"validate-devsecops-{app_id}")                       # mod.py:1953
        if not baseline_validation.passed:                                    # mod.py:1955  BRANCH ★MACHINE-REWORK
            workflow.logger.warning("G-04c DevSecOps baseline validation failed; reworking Generate",
                extra={"app_id": app_id, "missing": baseline_validation.missing,
                       "errors": baseline_validation.errors})                 # mod.py:1956-1964
            self._g04c_stakeholder_ea_approved = False                        # mod.py:1965  ★reset
            self._g04c_stakeholder_security_approved = False                  # mod.py:1966
            self._bump_rework("G-04c")                                        # mod.py:1967  ★counter bumped
            if self._rework_count("G-04c") > MAX_REWORK_ITERATIONS:           # mod.py:1968  BRANCH (ceiling)
                self._status = WorkflowStatus.FAILED                          # mod.py:1969
                self._current_step = "generate-baseline-incomplete"           # mod.py:1970  ★distinct step id
                self._updated_at = _now_iso()                                 # mod.py:1971
                await self._update_app_status(app_id, "modernization_failed",
                    "generate-baseline-incomplete", "Modernization")          # mod.py:1972-1977
                return "failed"                                               # mod.py:1978
            continue                                                          # mod.py:1979  ★LOOP BACK (no PR/gate this iter)

        # -- Create PR + gate record G-04c --
        pr_result = await self._create_generate_pr(repo, branch, app_id, bc_results)          # mod.py:1982 (§C4)
        gate_record = await workflow.execute_activity(create_gate_record,     # mod.py:1986
            CreateGateRecordInput(gate_type="G-04c", app_id=app_id,
                portfolio_id=input.portfolio_id, workflow_id=workflow.info().workflow_id,
                evidence_package_url=pr_result.pr_url),
            start_to_close_timeout=timedelta(seconds=30), retry_policy=RETRY_POLICIES["transient"])  # mod.py:1995-1996

        await self._submit_gate_evidence(gate_id=gate_record.gate_id, gate_type=GateType.G_04C,   # mod.py:1999  [Base]
            app_id=app_id, artifact_paths=artifact_paths, pr_url=pr_result.pr_url,
            assembly_line="Modernization", step="generate")

        if workflow.patched("modernization-gate-pre-review-v1"):              # mod.py:2009  PATCH GATE
            await self._run_gate_pre_review(gate_record.gate_id, "G-04c", artifact_paths,        # [Base]
                artifact_repo=repo, artifact_ref=branch)                      # mod.py:2010-2016
        else:
            await self._mark_ready_for_review(gate_record.gate_id)            # mod.py:2018  (§E2)

        await self._update_app_status(app_id, "gate_review", "generate-gate-review", "Modernization")   # mod.py:2020

        await self._set_step("generate-gate",
            generate_base + STEP_WEIGHTS["generate"] + STEP_WEIGHTS["generate-synthesis"]
            + STEP_WEIGHTS["generate-review"] + STEP_WEIGHTS["generate-commit"])   # mod.py:2027-2034
        decision = await self._wait_for_gate_decision(GateType.G_04C)         # mod.py:2035  [Base]

        if decision == "cancelled":                                          # mod.py:2037  BRANCH A
            return "cancelled"                                               # mod.py:2038

        if decision == "approved":                                           # mod.py:2040  BRANCH B
            if self._risk_tier == 1:                                         # mod.py:2048  BRANCH B1 (Tier-1)
                await workflow.wait_condition(lambda: (                       # mod.py:2049
                    (self._g04c_stakeholder_ea_approved
                     and self._g04c_stakeholder_security_approved)            # mod.py:2052-2053  ★AND predicate
                    or self.cancelled))                                       # mod.py:2055
                if self.cancelled:                                           # mod.py:2058  BRANCH B1a
                    self._status = WorkflowStatus.CANCELLED                  # mod.py:2059
                    return "cancelled"                                       # mod.py:2060

            package_content = self._find_output_file_content("gate-review-package")   # mod.py:2066  [Part 1]
            await self._persist_side_effects(app_id, "generate",             # mod.py:2069  [Part 1]
                gate_review_package_json=package_content)
            await self._reconcile_and_merge_with_retry_loop(repo=repo,        # mod.py:2076  [Base]
                pr_number=pr_result.pr_number, gate_id=gate_record.gate_id)
            return "approved"                                               # mod.py:2081

        # decision == "rejected" — HUMAN rework
        self._g04c_stakeholder_ea_approved = False                           # mod.py:2086  ★reset BEFORE next iter
        self._g04c_stakeholder_security_approved = False                     # mod.py:2087
        self._bump_rework("G-04c")                                           # mod.py:2089  ★counter bumped HERE
        if self._rework_count("G-04c") > MAX_REWORK_ITERATIONS:              # mod.py:2090  BRANCH C (ceiling=3)
            self._status = WorkflowStatus.FAILED                            # mod.py:2091
            self._current_step = "generate-max-rework-exceeded"             # mod.py:2092
            self._updated_at = _now_iso()                                   # mod.py:2093
            await self._update_app_status(app_id, "modernization_failed",   # mod.py:2094
                "generate-max-rework-exceeded", "Modernization")
            return "failed"                                                 # mod.py:2100
        # else: loop back to top → re-run BC fan-out + reviews + commit + (validator) + gate
```

**Branch inventory for `_execute_generate` (~14 + loops):**
- **NEW** `if not self._devsecops_params:` (1736) — pre-loop resolution.
- `while True:` (1757) — rework loop.
- `for bc_name in bc_names[:MAX_BC_CHILDREN_PER_APP]:` (1786) — fan-out loop, capped at 12.
- `if bc_name_lower in _FRONTEND_BC_NAMES:` (1788) vs else — frontend-vs-backend framework routing.
- `[GenerateBCResult(**r) if isinstance(r, dict) else r for r in raw_results]` (1818-1821) — coercion.
- **NEW** `try / except Exception` around `security-scan-review` (1877/1886).
- **NEW** `if not baseline_validation.passed:` (1955) — machine-driven rework.
- **NEW (nested)** `if self._rework_count("G-04c") > MAX_REWORK_ITERATIONS:` (1968) inside the
  baseline-fail branch.
- `if decision == "cancelled":` (2037) → return.
- `if decision == "approved":` (2040) → Tier-1 gate + projection + merge.
- `if self._risk_tier == 1:` (2048) — Tier-1 triple-signal wait.
- `if self.cancelled:` (2058) — cancel during Tier-1 wait.
- `if self._rework_count("G-04c") > MAX_REWORK_ITERATIONS:` (2090) — human-reject ceiling.

**Child workflow call (mod.py:1807-1813):** Type `"GenerateBCWorkflow"`. Input `GenerateBCInput`.
**Deterministic child id** `f"generate-bc-{app_id}-{bc_name}-{run_suffix}"` (1810). Task queue
inherited (1811). NO explicit retry/timeout/parent_close_policy/id_reuse_policy — Temporal defaults.
Started in the loop (futures in `bc_tasks`), awaited together.

**`asyncio.gather` (mod.py:1816):** awaits ALL bc child futures **in parallel**. Returns `raw_results`
in submission order. ⚠️ Propagates the FIRST child exception — a terminally-failed `GenerateBCWorkflow`
makes `gather` raise, unwinding through `_execute_generate` → `run`'s outer `except` **[Part 1,
mod.py:657-670]** → `_status=FAILED` + `_update_app_status("modernization_failed", ...)`.

**Activity calls in `_execute_generate` (per loop iteration, in order):**
1. **(pre-loop, once)** `resolve_devsecops_profile` — `ResolveDevSecOpsProfileInput(profile_id=
   input.portfolio_id or "")`, **30s**, `transient`, `activity_id=f"resolve-devsecops-{app_id}"`.
2. `read_artifact` (inside `_parse_bounded_contexts`, §C2) — read module-map.
3. `dispatch_agent_task` ×6 via `_dispatch_agent` **[Part 1]**: `synthesis` (`code-synthesis`) →
   `adversarial-review` → `security-posture-review` → `security-scan-review` (in try/except) →
   `iac-scaffolding` (`iac-scaffolding-generator`) → `gate-review-package`. Each 1h start_to_close,
   `agent_failure`, `activity_id="agent-{step_name}"`.
4. `write_artifacts_batch`/`write_artifact` (inside `_commit_generate_artifacts`, §C2).
5. **NEW** `validate_devsecops_baseline` — `ValidateDevSecOpsBaselineInput`, **60s**, `transient`,
   `activity_id=f"validate-devsecops-{app_id}"`.
6. `create_pr` (inside `_create_generate_pr`, §C4) — 60s, `transient`. **(SKIPPED on a baseline-fail
   iteration — see GOTCHA-C0-7.)**
7. `create_gate_record` — `gate_type="G-04c"`, 30s, `transient` (1986).
8. `check_gate_criteria` + `submit_gate_evidence` (inside `_submit_gate_evidence` **[Base]**).
9. pre-review (`gate-pre-review` 10m + `store_gate_pre_review` 30s + ready-flip) IF patched, ELSE
   `mark_gate_ready_for_review` (30s) iff patched (§E2).
10. `update_application_status` (2020) — 30s, `transient`.
11. On approve: `persist_modernization_side_effects` (gate_phase="generate", 60s, `transient`,
    `activity_id="persist-modernization-generate"`) **[Part 1]**, then `reconcile_and_merge_pr` (60s,
    `git_merge`) inside the merge-retry loop **[Base]**.

> ⚠️ **GOTCHA-C0-0-NEW (pre-loop DevSecOps resolution — ONCE, idempotent across reworks):** the
> `if not self._devsecops_params:` guard (1736) runs `resolve_devsecops_profile` and builds the
> **8-key** `_devsecops_params` dict (sast_tool / sbom_required / container_base / license /
> target_cloud / primary_ecosystem / iac / cicd) BEFORE the `while True` loop. Because it's gated on
> emptiness, a rework iteration does NOT re-resolve (the dict is already truthy). These params are (a)
> injected into every generating agent's `context["devsecops_baseline"]` **[Part 1 GOTCHA-DA-O6-NEW]**
> and (b) passed (`sast_tool`) to the validator (1947-1949). A rebuild MUST resolve once, before the
> loop, gated on `not self._devsecops_params`, with `profile_id=input.portfolio_id or ""`, and build
> all 8 keys.
> ⚠️ **GOTCHA-C0-1 (SIX generate dispatches, mapping to `_rework_gate_key_for_step`):** synthesis,
> adversarial-review, security-posture-review, security-scan-review, iac-scaffolding,
> gate-review-package dispatch in Generate. Per `_rework_gate_key_for_step` **[Part 1 §3]**:
> `synthesis` → G-04a (extract-set); `adversarial-review` + `gate-review-package` → G-04b
> (design-set); `security-posture-review`, `security-scan-review`, `iac-scaffolding` → `None` (no
> feedback). So on a G-04c rework the re-dispatched agents do NOT pick up `_rework_feedback["G-04c"]`
> (there is no G-04c entry in the map). This is BY DESIGN: Generate re-runs the CHILD
> `GenerateBCWorkflow`; G-04c feedback is conceptually forwarded through the child's input. **⚠️ BUT
> the current `_execute_generate` body does NOT thread any `_rework_feedback["G-04c"]` into
> `GenerateBCInput`** — on a G-04c rework the children re-run with the SAME inputs. A rebuild must
> replicate exactly: bump the counter, reset Tier-1 flags, loop, re-run the identical fan-out — do
> NOT invent a rework-feedback channel the source lacks.
> ⚠️ **GOTCHA-C0-2-NEW (`security-scan-review` is BEST-EFFORT — try/except, advisory):** the
> `security-scan-review` dispatch (1877-1890) is wrapped in `try/except Exception` and a triage miss
> only logs a WARNING — it does NOT block the Generate gate. Its `security-scan-report.json` is the
> G-04c security evidence (RA-5 / SI-2 control). A rebuild MUST wrap ONLY this dispatch in try/except;
> the other five generate dispatches are NOT wrapped (a failure there propagates via `agent_failure`
> retry-then-raise). ⚠️ Distinct from `security-posture-review` (design-intent reasoning, NOT
> wrapped) — these are two different skills.
> ⚠️ **GOTCHA-C0-3-NEW (`iac-scaffolding-generator` — rich IaC, ownership split):** the
> `iac-scaffolding` dispatch (1903-1910) produces the rich cloud-resource IaC (Lambda / API-GW /
> Aurora / EventBridge / KMS + remote-state backend) + its iac-manifest evidence + additional IaC
> source files. The baseline Terraform *module skeleton* (`infra/terraform/main.tf`) is the
> `code-synthesis` baseline's job; this skill does NOT emit `infra/terraform/main.tf`, so the two
> never collide on that path (design §4.2 / OQ-1). The router (`route_generate_file`, §C2) lands its
> root-bound files at the repo root and the `iac-manifest.json` as metadata. A rebuild MUST add this
> dispatch with `step_name="iac-scaffolding"`, `skill_id="iac-scaffolding-generator"`, input =
> `synthesis_result.output_artifacts`.
> ⚠️ **GOTCHA-C0-4-NEW (DETERMINISTIC baseline validator gates G-04c — machine-driven rework):** after
> the commit, `validate_devsecops_baseline` (1942-1954) CONFIRMS (does not author) the agent-generated
> baseline: every required repo-root file present + cheap schema/lint (ci.yml parses with its jobs,
> dependabot/branch-protection parse, iac-manifest validates). It is passed `committed_files=
> list(self._committed_baseline_files)` (the root-bound set §C2 stashed) and `sast_tool` from
> `_devsecops_params`. **If `not baseline_validation.passed`** (1955): reset BOTH Tier-1 flags
> (1965-1966), `_bump_rework("G-04c")` (1967); if count `> 3` → `_status=FAILED`,
> `_current_step="generate-baseline-incomplete"` (a DISTINCT step id from the human-reject's
> `"generate-max-rework-exceeded"`), `_update_app_status(...,"generate-baseline-incomplete",...)`,
> return `"failed"` (1969-1978); **ELSE `continue`** (1979). A rebuild MUST add this whole block — it
> is the standing guard that replaces the old xfail regression test.
> ⚠️ **GOTCHA-C0-5-NEW (the `continue` loops back BETWEEN commit and PR — NO PR/gate on a baseline-fail
> iteration):** the `continue` at mod.py:1979 jumps to the top of the `while True`, so on a
> baseline-failed iteration **`_create_generate_pr`, `create_gate_record`, evidence submission, the
> ready-flip, the gate wait, and the human decision are ALL SKIPPED** — the workflow RE-FANS-OUT the
> BC children and re-runs the whole synthesis/review/commit/validate sequence with the SAME
> `_devsecops_params`. This is a MACHINE-driven rework distinct from human G-04c rejection (which
> happens AFTER the PR + gate wait, mod.py:2086-2100). BOTH share the `_rework_iterations["G-04c"]`
> counter and the same ceiling, but they fail with DIFFERENT `_current_step` values
> (`"generate-baseline-incomplete"` vs `"generate-max-rework-exceeded"`). A rebuild MUST place the
> validator + its rework branch BEFORE the PR creation and use `continue` (not fall-through) on the
> non-ceiling baseline-fail path.
> ⚠️ **GOTCHA-C0-6 (Tier-1 triple-signal is AND of TWO flags + PM merge):** the `decision ==
> "approved"` is the PM's `gate_approved` (consumed by `_wait_for_gate_decision`). For Tier-1
> (`_risk_tier == 1`), the workflow ALSO waits for BOTH `_g04c_stakeholder_ea_approved` AND
> `_g04c_stakeholder_security_approved` (2052-2053) — set by `stakeholder_approved` **[Part 1 §4.1]**
> on scopes `"g-04c-ea"` and `"g-04c-security"`. Tier-2/3 SKIP this wait. A rebuild MUST: (a) consult
> the flags only when `_risk_tier == 1`; (b) AND the two flags; (c) OR `self.cancelled`; (d) proceed
> straight to projection+merge for Tier-2/3.
> ⚠️ **GOTCHA-C0-7 (cancel during Tier-1 wait sets `_status=CANCELLED` explicitly):** the post-wait
> `if self.cancelled:` (2058) sets `_status=CANCELLED` (2059) BEFORE returning `"cancelled"` — unlike
> BRANCH A (`decision == "cancelled"`, 2037) which returns WITHOUT setting `_status` (because
> `_wait_for_gate_decision` already set it). Set `_status=CANCELLED` only on the Tier-1-wait cancel
> path.
> ⚠️ **GOTCHA-C0-8 (reset Tier-1 flags on BOTH reject paths, BEFORE looping):** the flags are reset
> to `False` at the baseline-fail site (1965-1966) AND the human-reject site (2086-2087) so an
> early-arriving signal from a PRIOR cycle doesn't leak into the next attempt's wait. Mirrors the
> G-04a SME-flag reset **[Part 1, mod.py:975]**. Reset before `continue`/loop, NOT after.
> ⚠️ **GOTCHA-C0-9 (pre-review patch — modernization is opt-in):** the pre-review at 2009 is gated by
> `workflow.patched("modernization-gate-pre-review-v1")`. Unpatched → `_mark_ready_for_review` (§E2),
> ITSELF gated by `workflow.patched("mark-gate-ready-for-review-v1")`. So a pre-patch run does the
> bare ready-flip; a patched run does the full AI pre-review (whose `finally` ALSO does the ready-flip
> **[Base]**). Reproduce BOTH patch IDs verbatim at all three gate sites (G-04a/b/c).
> ⚠️ **GOTCHA-C0-10 (`generate_base` = 55.0 is a literal sum):** `_sum_weights("extract",
> "cross-validation","extract-commit","extract-gate","design","design-commit","design-gate")` = 15 +
> 5 + 2.5 + 7.5 + 15 + 2.5 + 7.5 = **55.0**. Compute identically so `get_status.progress_pct` matches.
> ⚠️ **GOTCHA-C0-11 (synthesis input is the FLATTENED concat of all BC output_artifacts):**
> `input_artifacts=[a for r in bc_results for a in r.output_artifacts]` (1833-1835) — flattening every
> child's `output_artifacts` in child-submission order. Adversarial, security-posture, security-scan,
> iac-scaffolding, and gate-review-package dispatches all take `synthesis_result.output_artifacts`
> (NOT the flattened BC list). Wire these inputs exactly.
> ⚠️ **GOTCHA-C0-12 (per-BC framework routing overrides uniform `target_framework`):** frontend-named
> BCs (`{"frontend","ui","web-app","spa"}`, case-insensitive on `bc_name.lower()`) get
> `target_framework=None` + `target_frontend=(input.target_frontend or "react")`; all other BCs get
> `target_framework=(input.target_framework or "express")` + `target_frontend=None` (1788-1793). This
> lets a wave-launched run (where `input.target_framework` is unset) still route a `frontend` BC to
> React and backend BCs to Express. Reproduce the exact frontend-name set and the two defaults.
> ⚠️ **GOTCHA-C0-13 (`asyncio.gather` parallel + first-exception-propagates):** all children run
> concurrently; a single child failure aborts `gather` and unwinds the workflow. NO per-child
> try/except, NO `return_exceptions=True`. Use bare `gather` (fail-fast).

### C2. `_parse_bounded_contexts(self, repo, app_id) -> list[str]` — mod.py:2102-2173

Reads the committed `module-map.yaml` and returns BC names, with `["default"]` fallbacks.

```text
async def _parse_bounded_contexts(self, repo, app_id):
    module_map_artifacts = self._design_results.get("module-design", [])   # mod.py:2120
    if not module_map_artifacts:                                           # mod.py:2121  BRANCH 1
        return ["default"]                                                 # mod.py:2122

    module_map_path = f"modernization/{app_id}/design/files/module-design/module-map.yaml"   # mod.py:2127-2129

    try:
        read_result = await workflow.execute_activity(read_artifact,       # mod.py:2132
            ReadArtifactInput(repo=repo, branch="main", path=module_map_path,
                execution_context=self._execution_ctx("read-module-map", app_id=app_id,
                    input_artifact_paths=[module_map_path])),
            start_to_close_timeout=timedelta(seconds=60),                  # mod.py:2144
            retry_policy=RETRY_POLICIES["transient"],                      # mod.py:2145
            activity_id=f"read-module-map-{app_id}")                       # mod.py:2146
        content = read_result.content                                      # mod.py:2148
    except Exception:                                                      # mod.py:2149  BRANCH 2 (read failure)
        workflow.logger.warning("Failed to read module-map.yaml; falling back to default BC", extra={...})   # mod.py:2150-2153
        return ["default"]                                                 # mod.py:2154

    bc_names = parse_bc_names_from_yaml(content)                           # mod.py:2156 (§F1)
    if not bc_names:                                                       # mod.py:2157  BRANCH 3 (empty parse)
        return ["default"]                                                 # mod.py:2158

    if len(bc_names) > MAX_BC_CHILDREN_PER_APP:                            # mod.py:2160  BRANCH 4 (over-cap warn)
        workflow.logger.warning("module-map declares %d bounded contexts; truncating "
            "fan-out to cap of %d" % (len(bc_names), MAX_BC_CHILDREN_PER_APP), extra={...})   # mod.py:2161-2172
    return bc_names                                                        # mod.py:2173
```

**Branch inventory (4 + try/except):** `if not module_map_artifacts:` (2121); `try/except Exception`
(2132/2149); `if not bc_names:` (2157); `if len(bc_names) > MAX_BC_CHILDREN_PER_APP:` (2160).

**Activity:** `read_artifact`, branch `"main"` (G-04b merged the design PR to main), 60s, `transient`,
`activity_id=f"read-module-map-{app_id}"`.

> ⚠️ **GOTCHA-C2-1 (reads the `files/` YAML, not the top-level metadata envelope):** path is
> `modernization/{app_id}/design/files/module-design/module-map.yaml` (2127-2129) — the REAL agent YAML
> committed under `files/`, NOT `modernization/{app_id}/design/module-map.yaml` (the 5-key JSON
> metadata envelope from §B1). Read the `files/` path.
> ⚠️ **GOTCHA-C2-2 (reads from `main`, not the generate branch):** branch `"main"` (2136) — the module
> map was merged to main by the G-04b `_reconcile_and_merge_with_retry_loop` **[Part 1]**. Read main.
> ⚠️ **GOTCHA-C2-3 (THREE fallback-to-`["default"]` triggers):** (1) no `module-design` entry in
> `_design_results` (2121), (2) read activity raised (2149), (3) `parse_bc_names_from_yaml` returned
> `[]` (2157) — which subsumes malformed YAML / missing contexts. Return `["default"]` on ALL so
> Generate still runs ONE child for a degenerate app.
> ⚠️ **GOTCHA-C2-4 (cap is WARN-only here; truncation is at the call site):** this method only LOGS
> when `len(bc_names) > 12` (2160) — it returns the FULL list. The actual truncation is the
> `bc_names[:MAX_BC_CHILDREN_PER_APP]` slice in `_execute_generate` (mod.py:1786).
> `MAX_BC_CHILDREN_PER_APP = 12` (types.py:133). Do NOT truncate inside the parser, only warn.

### C2a. `_output_file_fields(file_artifact) -> tuple[str, str]` — NEW static helper, mod.py:2175-2181

`@staticmethod`. Normalises an `OutputFile` (dataclass OR Temporal-deserialised dict) into
`(path, content)`. **NEW since the prior baseline** — extracted so `_commit_generate_artifacts` (§C2b)
can route each file uniformly.

```text
@staticmethod
def _output_file_fields(file_artifact) -> tuple[str, str]:
    if isinstance(file_artifact, dict):                # mod.py:2179  BRANCH
        return file_artifact["path"], file_artifact["content"]   # mod.py:2180
    return file_artifact.path, file_artifact.content   # mod.py:2181
```

> ⚠️ **GOTCHA-OFF1 (dict-OR-OutputFile, same tolerance as `_find_output_file_content`):** dict →
> `(["path"], ["content"])`; object → `(.path, .content)`. A rebuild MUST tolerate both shapes (child
> `GenerateBCResult.output_files` may deserialise as dicts).

### C2b. `_commit_generate_artifacts(self, repo, branch, app_id, bc_results) -> list[str]` — REWRITTEN, mod.py:2183-2340

Commits the workflow metadata summary (`gate-review-package.json`) + every agent-produced file, routed
by the W11 commit contract (`route_generate_file` / `is_root_bound`) into either the **target repo
root** (built-app + DevSecOps baseline) or the namespaced `modernization/{app_id}/generate/` metadata,
with **first-writer-wins** precedence. Stashes the root-bound set on `_committed_baseline_files`.
**Substantially CHANGED vs the prior baseline** (which used a fixed `modernization/{app_id}/generate/
files/{bc}/{path}` layout and no router/precedence/stash).

```text
async def _commit_generate_artifacts(self, repo, branch, app_id, bc_results):
    committed_paths = []                                                   # mod.py:2211
    root_files: dict[str, str] = {}        # repo-path -> content; preserves FIRST-WRITER-WINS   # mod.py:2213
    iac_manifest: tuple[str, str] | None = None   # captured separately    # mod.py:2216

    # -- Summary artifact (workflow metadata — ALWAYS namespaced) --
    summary_path = f"modernization/{app_id}/generate/gate-review-package.json"   # mod.py:2219-2221
    summary = {                                                            # mod.py:2222-2236
        "step": "generate",
        "bounded_contexts": [{                                             # ★6-field per-BC dicts
            "bc_name": r.bc_name, "status": r.status, "iteration_count": r.iteration_count,
            "escalation_id": r.escalation_id, "test_results_count": len(r.test_results),
            "output_artifacts_count": len(r.output_artifacts),
        } for r in bc_results],                                            # mod.py:2224-2233  LOOP (comprehension)
        "timestamp": workflow.now().isoformat(),                           # mod.py:2235
    }
    summary_content = json.dumps(summary, indent=2)                        # mod.py:2238
    if workflow.patched("modernization-batch-writes-v1"):                  # mod.py:2239  PATCH GATE
        await workflow.execute_activity(write_artifacts_batch, ...,
            files=[(summary_path, summary_content)],
            commit_message=f"modernization({app_id}): generate summary",
            start_to_close_timeout=timedelta(seconds=120), activity_id="commit-generate-summary")   # mod.py:2256
    else:
        await workflow.execute_activity(write_artifact, ..., path=summary_path, content=summary_content,
            commit_message=f"modernization({app_id}): generate summary",
            start_to_close_timeout=timedelta(seconds=60), activity_id="commit-generate-summary")     # mod.py:2276
    committed_paths.append(summary_path)                                   # mod.py:2278

    # -- Build ordered (label, bc_name, output_files) source list --
    sources: list[tuple[str, str | None, list]] = []                       # mod.py:2283
    for bc_result in bc_results:                                           # mod.py:2284  LOOP — BC code FIRST
        if bc_result.output_files:                                         # mod.py:2285  BRANCH
            sources.append((bc_result.bc_name, bc_result.bc_name, bc_result.output_files))   # mod.py:2286-2288
    for step_name in ("synthesis", "iac-scaffolding"):                     # mod.py:2292  LOOP — synthesis THEN iac
        metadata = self._agent_metadata.get(step_name, {})                 # mod.py:2293
        files = metadata.get("output_files") or []                         # mod.py:2294
        if files:                                                          # mod.py:2295  BRANCH
            sources.append((step_name, None, files))                       # mod.py:2296  ← bc_name None for parent dispatches

    # -- Route + commit each source's files --
    for label, bc_name, output_files in sources:                          # mod.py:2298  LOOP
        batch = []                                                         # mod.py:2299
        for file_artifact in output_files:                                # mod.py:2300  LOOP
            fa_path, fa_content = self._output_file_fields(file_artifact)  # mod.py:2301  (§C2a)
            dest = route_generate_file(app_id=app_id, bc_name=bc_name, path=fa_path)   # mod.py:2302-2304
            if is_root_bound(fa_path):                                     # mod.py:2305  BRANCH (root-bound)
                if dest in root_files:                                     # mod.py:2307  BRANCH ★FIRST-WRITER-WINS
                    continue                                               # mod.py:2308  ← skip later writer
                root_files[dest] = fa_content                              # mod.py:2309
            elif fa_path.rsplit("/", 1)[-1] == "iac-manifest.json":        # mod.py:2310  BRANCH (capture manifest)
                iac_manifest = (dest, fa_content)                          # mod.py:2311
            batch.append((dest, fa_content)); committed_paths.append(dest) # mod.py:2312-2313
        if batch:                                                          # mod.py:2314  BRANCH
            await workflow.execute_activity(write_artifacts_batch, ...,    # mod.py:2315
                files=batch, commit_message=f"modernization({app_id}): generate {label}",
                start_to_close_timeout=timedelta(seconds=120), retry_policy=RETRY_POLICIES["transient"],
                activity_id=f"commit-generate-{label}")                    # mod.py:2331

    # -- Stash root-bound + manifest for the G-04c validator --
    validator_files = list(root_files.items())                            # mod.py:2336
    if iac_manifest is not None:                                          # mod.py:2337  BRANCH
        validator_files.append(iac_manifest)                             # mod.py:2338
    self._committed_baseline_files = validator_files                      # mod.py:2339  ★STASH (GOTCHA-STATE-2)
    return dedup_paths(committed_paths)                                   # mod.py:2340
```

**Branch inventory (~9 + 4 loops):** summary comprehension (2224-2233); `if workflow.patched(...)`
(2239); `for bc_result in bc_results` (2284); `if bc_result.output_files` (2285); `for step_name in
("synthesis","iac-scaffolding")` (2292); `if files` (2295); `for label,bc_name,output_files in
sources` (2298); `for file_artifact in output_files` (2300); `if is_root_bound(fa_path)` (2305); `if
dest in root_files` (2307); `elif …=="iac-manifest.json"` (2310); `if batch` (2314); `if iac_manifest
is not None` (2337).

**Activity calls (in order):** ONE summary commit (`commit-generate-summary`, batch 120s / legacy
60s); then PER non-empty source (BC code first, then `synthesis`, then `iac-scaffolding`), ONE batched
`write_artifacts_batch` (`activity_id=f"commit-generate-{label}"`, 120s, `transient`) — **always
batched regardless of the patch gate** (only the SUMMARY commit branches on the patch).

> ⚠️ **GOTCHA-C2b-1-NEW (W11 routing — `route_generate_file` + `is_root_bound` decide repo-root vs
> metadata):** each agent file is routed by `route_generate_file(app_id, bc_name, path)` (2302):
> root-bound built-app + DevSecOps-baseline files (`.github/workflows/ci.yml`, `Dockerfile`,
> `deploy/helm/**`, `infra/terraform/**`, `SECURITY.md`, …) land at the **target repo root** (path
> verbatim); everything else is namespaced under `modernization/{app_id}/generate/files/{bc_name}/{path}`
> (or `.../files/{path}` when `bc_name` is None). The split is DECLARED by the contract
> (`devsecops_contract`), not inferred. Deterministic code only PLACES the agent's output — it authors
> nothing. A rebuild MUST route via the contract functions, NOT a hardcoded path template.
> ⚠️ **GOTCHA-C2b-2-NEW (FIRST-WRITER-WINS precedence; ordered source list):** `sources` is built BC
> code FIRST (2284-2288), THEN `synthesis`, THEN `iac-scaffolding` (2292-2296). A root-bound `dest`
> already in `root_files` is SKIPPED for any later source (`if dest in root_files: continue`,
> 2307-2308) — so an app file the BCs/synthesis already wrote at a repo-root path is never clobbered
> by a later source (design §7 OQ-3). A rebuild MUST preserve the exact source ORDER (BC → synthesis →
> iac) and the first-writer-wins skip.
> ⚠️ **GOTCHA-C2b-3-NEW (IaC manifest captured SEPARATELY, not as a root file):** a file whose
> basename is `iac-manifest.json` (the `elif`, 2310-2311) is captured into `iac_manifest = (dest,
> content)` (note: it is metadata, NOT root-bound — `is_root_bound` is False for it, so it lands under
> the namespaced metadata prefix). It is STILL committed (the `batch.append` at 2312 runs for both
> branches). It is appended to `validator_files` (2337-2338) so the validator schema-checks it. A
> rebuild MUST capture the manifest separately AND still commit it AND add it to the validator set.
> ⚠️ **GOTCHA-C2b-4-NEW (`_committed_baseline_files` stash = root_files.items() + manifest):** the
> validator set is `list(root_files.items())` PLUS the manifest tuple if present (2336-2339). This is
> the root-bound subset (NOT all committed paths) — the validator only needs to confirm the
> repo-root baseline + manifest. A rebuild MUST stash exactly this (GOTCHA-STATE-2).
> ⚠️ **GOTCHA-C2b-5 (per-source code commit always batched; only summary respects the patch):** the
> patch `modernization-batch-writes-v1` (2239) ONLY switches the SUMMARY commit. The per-source code
> commits (2315) use `write_artifacts_batch` unconditionally. Do NOT gate the per-source commits on
> the patch.
> ⚠️ **GOTCHA-C2b-6 (summary path == `gate-review-package.json`):** the WORKFLOW-built summary (BC
> status roll-up, 6-field dicts) is committed at `modernization/{app_id}/generate/gate-review-package.json`
> (2219-2221) — distinct from the AGENT-emitted `gate-review-package` skill output (routed by
> `route_generate_file`). Keep the exact summary path + 6-field per-BC schema.
> ⚠️ **GOTCHA-C2b-7 (`commit-generate-{label}` activity id, label = bc_name | "synthesis" |
> "iac-scaffolding"):** the per-source commit `activity_id` is `f"commit-generate-{label}"` where
> `label` is the BC name for BC sources, or `"synthesis"`/`"iac-scaffolding"` for the parent
> dispatches. Reproduce exactly for deterministic replay.

### C4. `_create_generate_pr(self, repo, branch, app_id, bc_results)` — mod.py:2342-2393

Builds the G-04c PR body (per-BC status checklist + escalation lines + rework line) and creates the PR.

```text
async def _create_generate_pr(self, repo, branch, app_id, bc_results):
    rework = self._rework_count("G-04c")                                   # mod.py:2350
    pr_body = ("## Gate G-04c Review: Generated Code Review\n\n"
               f"**Application:** {app_id}\n\n### Bounded Context Results\n")   # mod.py:2351-2355
    for r in bc_results:                                                   # mod.py:2356  LOOP
        status_icon = "x" if r.status == "completed" else " "             # mod.py:2357  BRANCH 1 (status → checkbox)
        pr_body += f"- [{status_icon}] **{r.bc_name}**: {r.status} ({r.iteration_count} iterations)\n"   # mod.py:2358-2361
        if r.escalation_id:                                               # mod.py:2362  BRANCH 2
            pr_body += f"  - Escalation: `{r.escalation_id}`\n"           # mod.py:2363
    pr_body += "\n### Artifacts\n- [x] Gate Review Package (`gate-review-package.json`)\n"   # mod.py:2365-2368
    if rework > 0:                                                        # mod.py:2369  BRANCH 3
        pr_body += f"\n**Rework iteration:** {rework}\n"                  # mod.py:2370

    return await workflow.execute_activity(create_pr,                     # mod.py:2372
        CreatePRInput(repo=repo, source_branch=branch, target_branch="main",
            title=f"Gate G-04c: Generated Code Review — {app_id}", body=pr_body,
            labels=["gate-review", "modernization", "generate", "G-04c"],  # mod.py:2380-2385
            execution_context=self._execution_ctx("create-g-04c-pr", app_id=app_id)),
        start_to_close_timeout=timedelta(seconds=60), retry_policy=RETRY_POLICIES["transient"])
```

**Branch inventory (3 + loop):** `for r in bc_results:` (2356); `status_icon = "x" if r.status ==
"completed" else " "` (2357); `if r.escalation_id:` (2362); `if rework > 0:` (2369).

- **Activity:** `create_pr`, 60s, `transient`, target `main`, labels `["gate-review", "modernization",
  "generate", "G-04c"]`.
- ⚠️ **GOTCHA-C4-1 (checkbox only checked when `status == "completed"`):** any BC with status `failed`
  or `escalated` renders an UNchecked box `[ ]` (2357). Compare exactly to `"completed"`.

---

## D. Extract commit + PR helpers (called by `_execute_extract` [Part 1])

### D1. `_commit_extract_artifacts(self, repo, branch, app_id) -> list[str]` — mod.py:2399-2592

Commits extraction + cross-validation (+ optional reconciliation) artifacts, plus the second
`test-scenarios.yaml` artifact. **Branch-heavy. Uses a RICHER summary schema than design.**

```text
async def _commit_extract_artifacts(self, repo, branch, app_id):
    use_batch = workflow.patched("modernization-batch-writes-v1")          # mod.py:2410  PATCH GATE
    committed_paths = []                                                   # mod.py:2411

    step_to_artifact_filename = {                                          # mod.py:2417-2424
        "extraction": "business-rules.yaml",
        "cross-validation": "cross-validation-report.json",
        "requirement-aggregation": "modern-requirements.yaml",
        "business-rule-reconciliation": "rule-reconciliation-matrix.yaml",
    }
    for step_name in ["extraction","cross-validation",                     # mod.py:2425-2430  LOOP (fixed order)
                      "requirement-aggregation","business-rule-reconciliation"]:
        artifacts = self._extract_results.get(step_name, [])               # mod.py:2431
        if not artifacts:                                                  # mod.py:2432  BRANCH — skip unrun step
            continue                                                       # mod.py:2433

        filename = step_to_artifact_filename[step_name]                    # mod.py:2435
        artifact_path = f"modernization/{app_id}/extract/{filename}"       # mod.py:2436
        metadata = self._agent_metadata.get(step_name, {})                 # mod.py:2438
        output_files = metadata.get("output_files", [])                    # mod.py:2439
        file_paths = [f.path for f in output_files] if output_files else []   # mod.py:2440  BRANCH

        content = json.dumps({                                            # mod.py:2442-2459  RICHER 7-key summary
            "step": step_name, "artifacts": artifacts, "file_artifacts": file_paths,
            "model_used": metadata.get("model_used", ""),
            "duration_ms": metadata.get("duration_ms", 0),
            "token_usage": {"input": metadata.get("token_usage_input", 0),
                            "output": metadata.get("token_usage_output", 0)},
            "cost_estimate_usd": metadata.get("cost_estimate_usd", 0.0),
            "timestamp": workflow.now().isoformat(),
        }, indent=2)

        extract_commit_ctx = self._execution_ctx(f"commit-extract-{step_name}", app_id=app_id)   # mod.py:2461-2464
        if use_batch:                                                      # mod.py:2465  BRANCH
            batch = [(artifact_path, content)]; committed_paths.append(artifact_path)   # mod.py:2466-2467
            for file_artifact in output_files:                             # mod.py:2468  LOOP
                file_path = f"modernization/{app_id}/extract/files/{step_name}/{file_artifact.path}"   # mod.py:2469-2472
                batch.append((file_path, file_artifact.content)); committed_paths.append(file_path)    # mod.py:2473-2474
            await workflow.execute_activity(write_artifacts_batch, ...,    # mod.py:2475
                commit_message=f"modernization({app_id}): extract {step_name}",
                start_to_close_timeout=timedelta(seconds=120),
                activity_id=f"commit-{step_name}")                         # mod.py:2488  ★id is commit-{step_name}, NOT commit-extract-{step_name}
        else:                                                              # mod.py:2490  (per-file legacy)
            await workflow.execute_activity(write_artifact, ..., path=artifact_path, content=content,
                commit_message=f"modernization({app_id}): extract {step_name}",
                start_to_close_timeout=timedelta(seconds=60), activity_id=f"commit-{step_name}")   # mod.py:2505
            committed_paths.append(artifact_path)                          # mod.py:2507
            for file_artifact in output_files:                             # mod.py:2509  LOOP (one activity per file)
                file_path = f"modernization/{app_id}/extract/files/{step_name}/{file_artifact.path}"   # mod.py:2510-2513
                await workflow.execute_activity(write_artifact, ..., path=file_path, content=file_artifact.content,
                    commit_message=f"modernization({app_id}): extract {step_name} file {file_artifact.path}",
                    activity_id=f"commit-file-{step_name}-{file_artifact.path.replace('/', '-')}")   # mod.py:2529-2532
                committed_paths.append(file_path)                          # mod.py:2534

    # -- second extraction artifact: test-scenarios.yaml --
    extraction_artifacts = self._extract_results.get("extraction", [])     # mod.py:2537
    if extraction_artifacts:                                               # mod.py:2538  BRANCH
        test_scenarios_path = f"modernization/{app_id}/extract/test-scenarios.yaml"   # mod.py:2539-2541
        metadata = self._agent_metadata.get("extraction", {})              # mod.py:2542
        content = json.dumps({"step": "extraction-test-scenarios",         # mod.py:2543-2550  3-key summary
            "artifacts": extraction_artifacts, "timestamp": workflow.now().isoformat()}, indent=2)
        if use_batch:                                                      # mod.py:2551  BRANCH
            await workflow.execute_activity(write_artifacts_batch, ...,
                files=[(test_scenarios_path, content)],
                commit_message=f"modernization({app_id}): extract test scenarios",
                start_to_close_timeout=timedelta(seconds=120), activity_id="commit-test-scenarios")   # mod.py:2568
        else:
            await workflow.execute_activity(write_artifact, ..., path=test_scenarios_path, content=content,
                commit_message=f"modernization({app_id}): extract test scenarios",
                start_to_close_timeout=timedelta(seconds=60), activity_id="commit-test-scenarios")     # mod.py:2588
        committed_paths.append(test_scenarios_path)                        # mod.py:2590

    return dedup_paths(committed_paths)                                    # mod.py:2592
```

**Branch inventory (7 + 3 loops):** `use_batch` patch (2410, consulted at 2465 & 2551); the fixed
4-step `for` loop (2425); `if not artifacts: continue` (2432); `file_paths = [...] if output_files
else []` (2440); `if use_batch:` (2465) vs else (2490); per-output-file loops (2468 batch / 2509
legacy); `if extraction_artifacts:` (2538); `if use_batch:` (2551) vs else (test-scenarios).

**Activity calls (in order):** per non-empty extract step — batch: ONE `write_artifacts_batch`
(`activity_id=f"commit-{step_name}"`, 120s); legacy: ONE summary `write_artifact`
(`activity_id=f"commit-{step_name}"`, 60s) + ONE per output file
(`activity_id=f"commit-file-{step_name}-{path/→-}"`, 60s). Then test-scenarios:
`activity_id="commit-test-scenarios"` (120s batch / 60s legacy).

> ⚠️ **GOTCHA-D1-1 (extract activity_id is `commit-{step_name}`, NOT `commit-extract-{step_name}`):**
> the `activity_id` at 2488/2505 is `f"commit-{step_name}"` — even though the `execution_ctx` step_id
> is `f"commit-extract-{step_name}"` (2461-2464). The DESIGN equivalent (§B1) uses
> `f"commit-design-{step_name}"` for BOTH. This asymmetry is in the source. Reproduce the extract
> `commit-{step_name}` activity id exactly.
> ⚠️ **GOTCHA-D1-2 (extract summary schema is the RICH 7-key shape):** unlike the design summary (5
> keys, §B1/GOTCHA-B1-5), the extract per-step summary has 7 keys incl. `file_artifacts`,
> `token_usage` (nested dict), `cost_estimate_usd` (2442-2459). The test-scenarios summary is a
> different 3-key shape (`step`/`artifacts`/`timestamp`, 2543-2550). Use the correct schema per
> artifact.
> ⚠️ **GOTCHA-D1-3 (fixed-order step loop drives commit order):** iterates the LITERAL list
> `["extraction","cross-validation","requirement-aggregation","business-rule-reconciliation"]` (2425)
> — NOT `_extract_results.keys()`. Reconciliation steps are skipped when absent via the `if not
> artifacts: continue` guard. Iterate this exact 4-element order.
> ⚠️ **GOTCHA-D1-4 (test-scenarios committed even though it's the SAME extraction artifact set):** the
> `test-scenarios.yaml` commit (2536-2590) re-uses `_extract_results["extraction"]` as its
> `artifacts` — a SECOND committed path for the same extraction outputs (extraction emits both
> business-rules and test-scenarios; the workflow commits them as two artifacts). Commit both.
> Returned list is `dedup_paths(committed_paths)` (2592).

### D2. `_create_extract_pr(self, repo, branch, app_id, skill_id, reconciliation_ran=False)` — mod.py:2594-2648

```text
async def _create_extract_pr(self, repo, branch, app_id, skill_id, reconciliation_ran=False):
    rework = self._rework_count("G-04a")                                   # mod.py:2610
    pr_body = ("## Gate G-04a Review: Extracted Specifications Review\n\n"
               f"**Application:** {app_id}\n**Extraction Skill:** {skill_id}\n\n### Artifacts\n"
               "- [x] Business Rules (`business-rules.yaml`)\n"
               "- [x] Test Scenarios (`test-scenarios.yaml`)\n"
               "- [x] Cross-Validation Report (`cross-validation-report.json`)\n")   # mod.py:2611-2619
    if reconciliation_ran:                                                 # mod.py:2620  BRANCH 1
        pr_body += ("- [x] Modern Requirements Catalog (`modern-requirements.yaml`)\n"
            "- [x] Rule Reconciliation Matrix (`rule-reconciliation-matrix.yaml`)\n"
            "- [x] Obsolete Rules Inventory (`obsolete-rules-inventory.md`)\n"
            "- [x] Modernization Gap Analysis (`modernization-gap-analysis.md`)\n"
            "- [x] Vision Alignment Report (`vision-alignment-report.md`)\n"
            "- [x] Conflict Resolution Log (`conflict-resolution-log.md`)\n")          # mod.py:2621-2628
    if rework > 0:                                                         # mod.py:2629  BRANCH 2
        pr_body += f"\n**Rework iteration:** {rework}\n"                   # mod.py:2630

    return await workflow.execute_activity(create_pr,                     # mod.py:2632
        CreatePRInput(repo=repo, source_branch=branch, target_branch="main",
            title=f"Gate G-04a: Extracted Specifications Review — {app_id}", body=pr_body,
            labels=["gate-review", "modernization", "extract", "G-04a"],   # mod.py:2640
            execution_context=self._execution_ctx("create-g-04a-pr", app_id=app_id)),
        start_to_close_timeout=timedelta(seconds=60), retry_policy=RETRY_POLICIES["transient"])
```

**Branch inventory (2):** `if reconciliation_ran:` (2620); `if rework > 0:` (2629).

- **Activity:** `create_pr`, 60s, `transient`, target `main`, labels `["gate-review", "modernization",
  "extract", "G-04a"]`.
- ⚠️ **GOTCHA-D2-1 (`reconciliation_ran` is passed by `_execute_extract`):** the caller passes
  `reconciliation_ran=True` only when the `br-reconciliation-v1` patch ran for this cycle **[Part 1]**.
  The 6 extra checklist lines (modern-requirements + matrix + 4 markdown reports) appear only then.

---

## E. Seeding, summing, ready-flip

### E0. `_sum_weights(self, *steps: str) -> float` — mod.py:2654-2655

```text
def _sum_weights(self, *steps):
    return sum(STEP_WEIGHTS.get(s, 0.0) for s in steps)   # mod.py:2655
```

- Pure. Sums `STEP_WEIGHTS` **[Part 1 §1.4]** for the named steps, defaulting unknown keys to `0.0`.
  Used to compute `design_base` (=30.0) **[Part 1]** and `generate_base` (=55.0, §C0). Use `.get(s,
  0.0)` (tolerant of unknown step names), not `[s]`.
- ⚠️ **GOTCHA-E0 (reconciliation steps are zero-weight):** `requirement-aggregation` +
  `business-rule-reconciliation` are 0.0 so the sum stays 100 and legacy replay paths see unchanged
  progress percentages. Keep at 0.0.

### E1. `_seed_patterns_from_registry(self, portfolio_id: str) -> None` — mod.py:2657-2750

Cold-start seed of `_received_patterns` from the governance registry artifact. Best-effort. Called
ONCE at the top of `_execute_modernization` **[Part 1, mod.py:692]**.

```text
async def _seed_patterns_from_registry(self, portfolio_id):
    if not portfolio_id:                                                   # mod.py:2677  BRANCH 1
        return                                                             # mod.py:2678

    repo = f"olympus/{portfolio_id}-governance"                            # mod.py:2680
    path = f"governance/{portfolio_id}/latest-patterns.json"               # mod.py:2681

    try:
        read_result = await workflow.execute_activity(read_artifact,       # mod.py:2684
            ReadArtifactInput(repo=repo, branch="main", path=path),
            start_to_close_timeout=timedelta(seconds=30),                  # mod.py:2687
            retry_policy=RETRY_POLICIES["transient"],                      # mod.py:2691
            activity_id=f"read-governance-patterns-{portfolio_id}")        # mod.py:2692
    except Exception as exc:                                               # mod.py:2694  BRANCH 2 (missing file = common)
        workflow.logger.info("cold-start: latest-patterns.json not found ... empty bundle", ...)   # mod.py:2695-2702
        return                                                             # mod.py:2703

    try:
        payload = json.loads(read_result.content)                         # mod.py:2706
    except (json.JSONDecodeError, TypeError, ValueError) as exc:          # mod.py:2707  BRANCH 3 (malformed JSON)
        workflow.logger.warning("cold-start: latest-patterns.json is malformed ...", ...)   # mod.py:2708-2716
        return                                                             # mod.py:2716

    if not isinstance(payload, dict):                                      # mod.py:2718  BRANCH 4 (root not object)
        workflow.logger.warning("cold-start: latest-patterns.json root is not an object ...", ...)   # mod.py:2719-2726
        return                                                             # mod.py:2726

    patterns = payload.get("patterns")                                     # mod.py:2728
    if not isinstance(patterns, list):                                     # mod.py:2729  BRANCH 5
        return                                                             # mod.py:2730  ← silent (no log)

    string_patterns = [p for p in patterns if isinstance(p, str)]          # mod.py:2732  filter to strings
    if not string_patterns:                                                # mod.py:2733  BRANCH 6
        return                                                             # mod.py:2734  ← silent

    source = payload.get("source") or {}                                   # mod.py:2736
    seed_wave_id = source.get("sweep_wave_id") if isinstance(source, dict) else None   # mod.py:2737-2739  BRANCH 7
    if not isinstance(seed_wave_id, str) or not seed_wave_id:              # mod.py:2740  BRANCH 8
        seed_wave_id = "governance-registry-cold-start"                    # mod.py:2741  ← default id

    self._received_patterns.append({                                       # mod.py:2743-2749  ★MUTATION
        "wave_id": seed_wave_id, "patterns": string_patterns,
        "received_at": _now_iso(), "source": "cold-start-registry"})
```

**Branch inventory (8 + try/except×2):** `if not portfolio_id:` (2677); `try/except Exception`
(2684/2694); `try/except (JSONDecodeError, TypeError, ValueError)` (2706/2707); `if not
isinstance(payload, dict):` (2718); `if not isinstance(patterns, list):` (2729); `if not
string_patterns:` (2733); `seed_wave_id = … if isinstance(source, dict) else None` (2737-2739); `if
not isinstance(seed_wave_id, str) or not seed_wave_id:` (2740).

**Activity:** `read_artifact`, repo `olympus/{portfolio_id}-governance`, path
`governance/{portfolio_id}/latest-patterns.json`, branch `"main"`, 30s, `transient` (3 attempts),
`activity_id=f"read-governance-patterns-{portfolio_id}"`.

> ⚠️ **GOTCHA-E1-1 (entirely best-effort — SIX early returns, ZERO raises):** every failure mode (no
> portfolio, read failure, malformed JSON, non-dict root, non-list patterns, no string patterns)
> returns cleanly. The method NEVER raises. The appended entry has a 4-key shape (adds `"source":
> "cold-start-registry"`, 2748) distinct from the signal-pushed shape (3 keys). `get_received_patterns`
> **[Part 1]** returns a shallow copy of all entries.
> ⚠️ **GOTCHA-E1-2 (the docstring's retry claim is WRONG; code uses `transient`=3 attempts):** the
> comment at 2688-2690 says "skip retries" but the actual `retry_policy=RETRY_POLICIES["transient"]`
> (2691) is the 3-attempt policy. The code is authoritative — use `transient`, NOT a no-retry policy.
> ⚠️ **GOTCHA-E1-3 (`patterns` filtered to STRINGS only):** `[p for p in patterns if isinstance(p,
> str)]` (2732) — non-string entries dropped; if empty, return silently (2733).
> ⚠️ **GOTCHA-E1-4 (`seed_wave_id` fallback chain):** prefer `payload["source"]["sweep_wave_id"]` if
> `source` is a dict and the value is a non-empty string; else default `"governance-registry-cold-start"`
> (2736-2741). Reproduce the exact default string.
> ⚠️ **GOTCHA-E1-5 (additive — does NOT suppress live signal propagation):** the cold-start seed
> shares the same `_received_patterns` list as the `wave_patterns_ready` signal **[Part 1]**;
> subsequent signals append on top. Do NOT clear or guard `_received_patterns` after seeding.

### E2. `_mark_ready_for_review(self, gate_id: str) -> None` — mod.py:2752-2774

The subclass-only bare ready-flip (alternative to the inherited `_run_gate_pre_review` **[Base]**),
called at each of the three gates when the pre-review patch is NOT active **[Part 1 G-04a/G-04b
sites; §C0 G-04c site]**.

```text
async def _mark_ready_for_review(self, gate_id):
    if workflow.patched("mark-gate-ready-for-review-v1"):                  # mod.py:2768  PATCH GATE
        await workflow.execute_activity(mark_gate_ready_for_review, gate_id,
            start_to_close_timeout=timedelta(seconds=30),                  # mod.py:2772
            retry_policy=RETRY_POLICIES["transient"])                      # mod.py:2773
```

**Branch inventory (1):** `if workflow.patched("mark-gate-ready-for-review-v1"):` (2768).

- **Activity:** `mark_gate_ready_for_review`, positional `gate_id` (NOT a dataclass), 30s, `transient`,
  no explicit activity_id.
- ⚠️ **GOTCHA-E2-1 (patch ID verbatim, no-op when unpatched):** when the patch is inactive, this
  method does NOTHING — no activity, no state change. Gate on
  `workflow.patched("mark-gate-ready-for-review-v1")` (verbatim) and no-op otherwise.
- ⚠️ **GOTCHA-E2-2 (positional gate_id):** `mark_gate_ready_for_review` is called with positional
  `gate_id` (2771), matching base's `_run_gate_pre_review` `finally` call **[Base]**. Pass `gate_id`
  positionally, not wrapped.

---

## F. Module-level pure helper

### F1. `parse_bc_names_from_yaml(content: str) -> list[str]` — mod.py:2777-2819

Pure, I/O-free YAML parser for bounded-context names. Called by `_parse_bounded_contexts` (§C2,
mod.py:2156). Safe to unit-test directly.

```text
def parse_bc_names_from_yaml(content):
    if not content or not content.strip():                                 # mod.py:2793  BRANCH 1
        return []                                                          # mod.py:2794

    try:
        data = yaml.safe_load(content)                                     # mod.py:2797  ★safe_load, NOT load
    except yaml.YAMLError:                                                 # mod.py:2798  BRANCH 2 (malformed)
        return []                                                          # mod.py:2799

    if not isinstance(data, dict):                                         # mod.py:2801  BRANCH 3
        return []                                                          # mod.py:2802

    contexts = (data.get("bounded_contexts")                               # mod.py:2804-2808  ★3-key fallback chain
                or data.get("contexts")
                or data.get("modules"))
    if not isinstance(contexts, list) or not contexts:                     # mod.py:2809  BRANCH 4
        return []                                                          # mod.py:2810

    names = []                                                             # mod.py:2812
    for ctx in contexts:                                                   # mod.py:2813  LOOP
        if not isinstance(ctx, dict):                                      # mod.py:2814  BRANCH 5
            continue                                                       # mod.py:2815  ← skip non-dict entries
        name = ctx.get("name") or ctx.get("id")                           # mod.py:2816  ★name-then-id fallback
        if isinstance(name, str) and name.strip():                        # mod.py:2817  BRANCH 6
            names.append(name.strip())                                    # mod.py:2818  ← stripped
    return names                                                          # mod.py:2819
```

**Branch inventory (6 + loop):** `if not content or not content.strip():` (2793); `try/except
yaml.YAMLError` (2797/2798); `if not isinstance(data, dict):` (2801); `if not isinstance(contexts,
list) or not contexts:` (2809); `for ctx in contexts:` (2813); `if not isinstance(ctx, dict):
continue` (2814); `if isinstance(name, str) and name.strip():` (2817).

> ⚠️ **GOTCHA-F1-1 (`yaml.safe_load` ONLY — security):** uses `yaml.safe_load`, never `yaml.load`
> (2797) to avoid arbitrary Python object construction from untrusted YAML. Use safe_load.
> ⚠️ **GOTCHA-F1-2 (3-key context-list fallback, in order):** `bounded_contexts` → `contexts` →
> `modules` (2804-2808), first truthy wins. Reproduce the exact OR-fallback order.
> ⚠️ **GOTCHA-F1-3 (per-context `name`-then-`id`, stripped, non-string skipped):** for each list entry
> that is a dict (2814 skips non-dicts), the name is `ctx.get("name") or ctx.get("id")` (2816); kept
> only if a non-empty (post-strip) string (2817); appended `.strip()`ped (2818).
> ⚠️ **GOTCHA-F1-4 (empty list is the universal "give up" signal):** EVERY failure returns `[]` so the
> caller (§C2) applies its `["default"]` fallback. Truncation to `MAX_BC_CHILDREN_PER_APP` is NOT done
> here — it happens at the workflow slice. Keep the parser order-preserving, cap-free, `[]`-on-any-failure.

---

## G. RESILIENCE summary (this file's scope)

- **Timeouts (start_to_close):** design/extract/generate summary batch commit 120s (legacy single
  `write_artifact` 60s, per-file 60s); design-review commit 120s/60s; generate per-source code batch
  120s; **NEW** `resolve_devsecops_profile` 30s; **NEW** `validate_devsecops_baseline` 60s; `create_pr`
  (×3 gate PRs) 60s; `create_gate_record` (G-04c) 30s; `read_artifact` (module-map) 60s; `read_artifact`
  (governance cold-start) 30s; `mark_gate_ready_for_review` 30s. All commit/PR/gate-record/read/
  resolve/validate activities use `transient` (3 attempts). Inherited dispatch (1h, `agent_failure`)
  and merge (60s, `git_merge`) per **[Base]**.
- **Heartbeats:** none configured here.
- **continue-as-new:** none — the rework loops are bounded by `MAX_REWORK_ITERATIONS = 3` (mod.py:203).
  ⚠️ The Generate loop now has TWO `_bump_rework("G-04c")` sites (baseline-fail + human-reject)
  sharing one counter — see GOTCHA-C0-4/C0-5.
- **Child workflows:** `GenerateBCWorkflow` started in the §C0 fan-out with deterministic id
  `generate-bc-{app_id}-{bc_name}-{run_suffix}`, awaited via `asyncio.gather` (fail-fast). NO explicit
  retry/timeout/parent_close_policy — Temporal defaults.
- **Idempotency:** all commit/read/PR/resolve/validate activities use deterministic `activity_id`s
  (`commit-{step}`, `commit-design-{step}`, `commit-design-review`, `commit-generate-summary`,
  `commit-generate-{label}`, `commit-test-scenarios`, `read-module-map-{app_id}`,
  `read-governance-patterns-{portfolio_id}`, **NEW** `resolve-devsecops-{app_id}`, **NEW**
  `validate-devsecops-{app_id}`) → replay-stable. `workflow.now().isoformat()` is deterministic. Patch
  IDs gate optional behavior changes.
- **Compensation / rollback:** none in this scope. Failure semantics: `_seed_patterns_from_registry`
  is fully best-effort (6 early returns). `security-scan-review` is best-effort (try/except,
  GOTCHA-C0-2-NEW). A child-workflow failure in `_execute_generate` propagates through `gather` →
  `run`'s outer `except` → `_status=FAILED` + `_update_app_status("modernization_failed", ...)`
  **[Part 1]**. **NEW:** baseline-validation failure → `_bump_rework("G-04c")`; on ceiling →
  `_status=FAILED`, `_current_step="generate-baseline-incomplete"`, `return "failed"`
  (1969-1978); else `continue`. Human G-04c rejection → ceiling → `_current_step="generate-max-rework-
  exceeded"`, `return "failed"` (2091-2100). Merge_blocked routing + cancel handled by the inherited
  merge-retry loop **[Base]**.
- **Patch IDs reproduced VERBATIM in this scope:** `"modernization-batch-writes-v1"` (§B1, §C2b, §D1),
  `"modernization-gate-pre-review-v1"` (§C0 G-04c site; also G-04a/G-04b [Part 1]),
  `"mark-gate-ready-for-review-v1"` (§E2). [`"br-reconciliation-v1"` is consulted in [Part 1]; the
  traceability-audit gate was REMOVED — `audit_result is not None` is now the in-band signal here.]

---

## H. Behavioral parity checklist (this file's scope)

A rebuild of these methods MUST satisfy ALL of the following:

1. **`_is_batch_archetype`** returns `True` iff ANY `input.prior_artifacts` path contains the
   case-insensitive substring `"batch"`; else `False`. (GOTCHA-A1)
2. **`_collect_extract_artifacts`** prepends arch/blueprint priors (from
   `_workflow_input_prior_artifacts`, filtered by `"architecture" in lower OR "blueprint" in lower`)
   BEFORE all `_extract_results.values()` artifacts, then `dedup_paths` (first-wins, order-preserving).
   (GOTCHA-A2/A2b)
3. **`_workflow_input_prior_artifacts`** reads `self._input` via `getattr(..., None)`, returns `[]`
   when absent (stub-test case), else `list(getattr(input_obj, "prior_artifacts", []) or [])`. ⚠️
   **CHANGED:** `run` NOW sets `self._input` **[Part 1]**, so the live path returns real priors —
   MUST NOT read the `input` parameter directly. (GOTCHA-A3)
4. **`_collect_design_artifacts`** = `dedup_paths` of all `_design_results.values()` (includes the
   synthetic `design-review` entry when present). (GOTCHA-A4)
5. **`_commit_design_artifacts`** iterates the 4 `DESIGN_SKILLS` (skipping empties), commits each
   summary (5-key JSON) + output files under `modernization/{app_id}/design/files/{step}/{path}`,
   branching on `modernization-batch-writes-v1`; then emits `design-review.json` (path
   `modernization/{app_id}/design/design-review.json`, `commit-design-review`); then injects the
   synthetic `_design_results["design-review"]=[path]` + matching 6-key `_agent_metadata["design-
   review"]`; returns `dedup_paths(committed_paths)`. (GOTCHA-B1-1..6, STATE-1)
6. **`_build_design_review_content`**: if `audit_result is not None`, return the output_file whose path
   ends with `design-review.json` (else first; else warn + fall through); the fall-through /
   `audit_result is None` path returns the provisional dict (forward_coverage 0.99, backward_coverage
   0.99, critical_508_violations 0, journey_preservation_pct 1.0, bounded_contexts_defined/openapi_valid/
   ddd_elements_present True, design_steps_evaluated=`sorted(self._design_results.keys())`, provisional
   True, provisional_note) as indent-2 JSON. ⚠️ The `None` path is now routinely hit on the delegated-
   bundle Design route **[Part 1]**. (GOTCHA-B2-1..3)
7. **`_create_design_pr`** body: 3 always-on artifact lines + conditional batch-design line iff
   `"batch-design" in _design_results` + always-on design-review line + conditional rework line iff
   `_rework_count("G-04b") > 0`; labels `["gate-review","modernization","design","G-04b"]`; `create_pr`
   60s `transient` target main. (GOTCHA-B3-1/B3-2)
8. **`_execute_generate`** — **PRE-LOOP:** `if not self._devsecops_params:` →
   `resolve_devsecops_profile(profile_id=input.portfolio_id or "")` (30s, transient,
   `resolve-devsecops-{app_id}`) building the 8-key `_devsecops_params` dict ONCE (GOTCHA-C0-0-NEW).
   Then a `while True` loop that: sets step `generate`@55.0; calls `_parse_bounded_contexts`; fans out
   one `GenerateBCWorkflow` child per `bc_names[:12]` with id `generate-bc-{app_id}-{bc}-{run_suffix}`
   (frontend-named BCs → framework None + frontend `input.target_frontend or "react"`; others →
   framework `input.target_framework or "express"` + frontend None, GOTCHA-C0-12); awaits all via
   `asyncio.gather` (fail-fast, coercing dict→`GenerateBCResult`, GOTCHA-C0-13); stores
   `_generate_results`; dispatches synthesis (`code-synthesis`, input = flattened all-BC
   output_artifacts, GOTCHA-C0-11), adversarial-review, security-posture-review, **security-scan-review
   in try/except (best-effort, GOTCHA-C0-2-NEW)**, **iac-scaffolding (`iac-scaffolding-generator`,
   GOTCHA-C0-3-NEW)**, gate-review-package (the last five input = synthesis output_artifacts). (GOTCHA-C0-1)
9. **`_execute_generate` commit + baseline gate:** commit via `_commit_generate_artifacts` (sets
   `_committed_baseline_files`); then **NEW** `validate_devsecops_baseline(committed_files=
   list(_committed_baseline_files), sast_tool=_devsecops_params.get("sast_tool","codeql"))` (60s,
   transient, `validate-devsecops-{app_id}`); `if not passed`: reset both Tier-1 flags, `_bump_rework(
   "G-04c")`, if `>3` → `_status=FAILED`, `_current_step="generate-baseline-incomplete"`,
   `_update_app_status(...,"generate-baseline-incomplete",...)`, `return "failed"`; **else `continue`**
   (loops back BETWEEN commit and PR — NO PR/gate this iter). (GOTCHA-C0-4-NEW, C0-5-NEW)
10. **`_execute_generate` PR + gate:** `_create_generate_pr`; `create_gate_record(G-04c, 30s)`;
    `_submit_gate_evidence(step="generate")`; pre-review under `modernization-gate-pre-review-v1` else
    `_mark_ready_for_review`; `_update_app_status("gate_review","generate-gate-review")`;
    `_wait_for_gate_decision(G_04C)`.
11. On `"cancelled"` decision → `return "cancelled"` (no `_status` mutation). On `"approved"`: if
    `_risk_tier == 1`, wait `(ea AND security) or cancelled`; on cancel set `_status=CANCELLED` +
    return `"cancelled"` (GOTCHA-C0-7); else continue. Then `_persist_side_effects(app_id,"generate",
    gate_review_package_json=_find_output_file_content("gate-review-package"))`, then
    `_reconcile_and_merge_with_retry_loop(repo,pr_number,gate_id)`, then `return "approved"`.
    (GOTCHA-C0-6)
12. On `"rejected"`: reset `_g04c_stakeholder_ea_approved=False` + `_g04c_stakeholder_security_approved
    =False`, `_bump_rework("G-04c")`; if `_rework_count("G-04c") > 3` → `_status=FAILED`,
    `_current_step="generate-max-rework-exceeded"`, `_update_app_status("modernization_failed",...)`,
    `return "failed"`; else loop. (GOTCHA-C0-8 — flag reset on BOTH the baseline-fail and human-reject
    paths)
13. **`_parse_bounded_contexts`**: return `["default"]` if no `module-design` in `_design_results`;
    else read `modernization/{app_id}/design/files/module-design/module-map.yaml` from branch `main`
    (60s transient `read-module-map-{app_id}`); on read exception → warn + `["default"]`; parse via
    `parse_bc_names_from_yaml`; if empty → `["default"]`; if `len > 12` → warn (return full list, NOT
    truncated). (GOTCHA-C2-1..4)
14. **`_output_file_fields` (NEW)**: static; dict→`(["path"],["content"])`, object→`(.path,.content)`.
    (GOTCHA-OFF1)
15. **`_commit_generate_artifacts` (REWRITTEN)**: build summary (step + bounded_contexts list of
    6-field dicts + timestamp) at `modernization/{app_id}/generate/gate-review-package.json`; commit it
    branching on `modernization-batch-writes-v1` (`commit-generate-summary`, 120s/60s); build the
    ordered `sources` list (BC code FIRST, then `synthesis`, then `iac-scaffolding`); for each source,
    route each file via `route_generate_file(app_id, bc_name, path)` (§C2b), apply FIRST-WRITER-WINS on
    root-bound dests (`is_root_bound` + `if dest in root_files: continue`), capture `iac-manifest.json`
    separately, batch-commit non-empty batches via `write_artifacts_batch` UNCONDITIONALLY
    (`commit-generate-{label}`, 120s); stash `_committed_baseline_files = list(root_files.items()) +
    [manifest]`; return `dedup_paths(committed_paths)`. (GOTCHA-C2b-1..7, STATE-2)
16. **`_create_generate_pr`** body: per-BC line `- [x|space] **{bc}**: {status} ({n} iterations)`
    checked iff `status == "completed"`, plus `  - Escalation: {id}` iff `escalation_id`; gate-review-
    package artifact line; conditional rework line iff `_rework_count("G-04c") > 0`; labels
    `["gate-review","modernization","generate","G-04c"]`; `create_pr` 60s transient. (GOTCHA-C4-1)
17. **`_commit_extract_artifacts`**: iterate the FIXED 4-step order
    `[extraction,cross-validation,requirement-aggregation,business-rule-reconciliation]`, skip empties;
    per step build the RICH 7-key summary at `modernization/{app_id}/extract/{filename}`, commit
    branching on `modernization-batch-writes-v1` with activity_id `commit-{step_name}` (NOT
    `commit-extract-{step}`), files under `modernization/{app_id}/extract/files/{step}/{path}` (legacy
    per-file id `commit-file-{step}-{path/→-}`); then commit `test-scenarios.yaml` (3-key summary) iff
    `_extract_results["extraction"]` non-empty (`commit-test-scenarios`); return
    `dedup_paths(committed_paths)`. (GOTCHA-D1-1..4)
18. **`_create_extract_pr`** body: 3 base artifact lines + extraction-skill name; conditional 6-line
    reconciliation block iff `reconciliation_ran`; conditional rework line iff `_rework_count("G-04a")
    > 0`; labels `["gate-review","modernization","extract","G-04a"]`; `create_pr` 60s transient.
    (GOTCHA-D2-1)
19. **`_sum_weights`** = `sum(STEP_WEIGHTS.get(s, 0.0) for s in steps)`; `STEP_WEIGHTS` sums to 100
    with reconciliation steps at 0.0; `generate_base` = 55.0, `design_base` = 30.0. (GOTCHA-E0, C0-10)
20. **`_seed_patterns_from_registry`** is fully best-effort with SIX clean early returns and ZERO
    raises; reads `governance/{portfolio_id}/latest-patterns.json` from `olympus/{portfolio_id}-
    governance`@main (30s, **`transient`** — NOT no-retry, despite the comment); filters `patterns` to
    strings; resolves `seed_wave_id` from `payload["source"]["sweep_wave_id"]` (str, non-empty) else
    `"governance-registry-cold-start"`; appends a 4-key entry `{wave_id, patterns, received_at=
    _now_iso(), source:"cold-start-registry"}` (additive). (GOTCHA-E1-1..5)
21. **`_mark_ready_for_review`** calls `mark_gate_ready_for_review` with POSITIONAL `gate_id` (30s,
    transient) ONLY under `workflow.patched("mark-gate-ready-for-review-v1")`; no-op otherwise.
    (GOTCHA-E2-1/E2-2)
22. **`parse_bc_names_from_yaml`** is pure: `[]` on empty/whitespace; `yaml.safe_load` (NEVER `load`)
    with `[]` on `YAMLError`; `[]` on non-dict root; context list = first truthy of
    `bounded_contexts`/`contexts`/`modules`, `[]` if not a non-empty list; per dict entry append
    `(ctx.get("name") or ctx.get("id"))` stripped iff a non-empty string (skip non-dicts); no cap
    applied. (GOTCHA-F1-1..4)
23. **No subclass redefinition** of base/mixin gate signals or `get_status`/bundle queries; per-phase
    commit/PR helpers are subclass-only and base `_commit_step_artifacts`/`_create_gate_pr` are NOT
    used. (GOTCHA-OVERRIDE-1)
24. **All deterministic activity_ids and the deterministic child id** are reproduced exactly; all
    `workflow.now()`/`_now_iso()` time sources are deterministic; all patch IDs in scope are verbatim.

---

### Appendix — branch-point census for this file's scope (lines 1346–2819)

| Method | Branch-points reproduced |
|--------|--------------------------|
| `_is_batch_archetype` | 2 (for, if) |
| `_collect_extract_artifacts` | 3 (for, OR-if, for) |
| `_workflow_input_prior_artifacts` | 1 |
| `_collect_design_artifacts` | 1 (for) |
| `_commit_design_artifacts` | 10 (patch, for-skills, skip-if, batch-if, for-files×2, dict-if, review batch-if) |
| `_build_design_review_content` | 4 (audit-if, for, endswith-if, files-if) |
| `_create_design_pr` | 2 |
| `_execute_generate` | ~16 (devsecops-resolve-if, while, for-BC, frontend-if/else, dict-coerce, scan-try/except, baseline-if, baseline-ceiling-if, cancelled-if, approved-if, tier1-if, tier1-cancel-if, max-rework-if) |
| `_parse_bounded_contexts` | 5 (no-artifacts-if, try/except, empty-if, over-cap-if) |
| `_output_file_fields` | 1 (dict-if) |
| `_commit_generate_artifacts` | ~13 (summary-comp, patch-if, for-BC, bc-files-if, for-step-sources, files-if, for-sources, for-files, root-bound-if, first-writer-if, manifest-elif, batch-if, manifest-stash-if) |
| `_create_generate_pr` | 4 (for, status-icon, escalation-if, rework-if) |
| `_commit_extract_artifacts` | 9 (patch, for-steps, skip-if, file_paths-if, batch-if, for-files×2, ts-if, ts-batch-if) |
| `_create_extract_pr` | 2 |
| `_sum_weights` | 1 (generator) |
| `_seed_patterns_from_registry` | 10 (portfolio-if, try/except×2, dict-if, list-if, strings-if, source-if, seed-id-if) |
| `_mark_ready_for_review` | 1 |
| `parse_bc_names_from_yaml` | 7 (content-if, try/except, dict-if, contexts-if, for, non-dict-if, name-if) |
| **TOTAL (approx)** | **~94 branch-points** in the 1346–2819 scope |
