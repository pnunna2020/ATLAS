# `DispositionWorkflow` — Disposition Execution Line (ATOMIC regeneration spec)

> **Source of truth:** `temporal/olympus_workflows/workflows/disposition.py` (1605 lines).
> Every `disposition.py:line` citation below is against that file.
>
> **Inherits:** `class DispositionWorkflow(LineWorkflowBase)` (`disposition.py:207-208`,
> decorated `@workflow.defn`). `LineWorkflowBase(HILSignalsMixin)`. See `_LineWorkflowBase.md`
> for the inherited engine (gate-wait, signals, query, status, dispatch, commit, gate-PR,
> evidence, merge loop, rework counters) and `_HILSignalsMixin.md` for the HIL signal surface
> (`approve`, `cancel_workflow`, `cancelled` kill-switch, etc.). **This spec reproduces ONLY the
> subclass's own code** and explicitly lists what it overrides; do not re-reproduce inherited
> methods.
>
> **What this workflow is:** a per-app workflow for the **Disposition Execution** assembly line.
> It runs in parallel with the Modernization→Validation→Deployment pipeline and executes the
> **five non-modernization dispositions** — Retire, Retain, Replace, Replatform, Consolidate
> (`disposition.py:1-66`). Refactor and Rearchitect flow through `ModernizationWorkflow`; this
> workflow **rejects them**. It gates progress through **G-DE-1** (Disposition Execution Plan
> Approval; stakeholder + PM) and, for dispositions with a decommission phase, **G-DE-2**
> (Decommission Readiness Sign-off; ops lead + security). **Retain uses only G-DE-1** (nothing is
> decommissioned).
>
> **Per-disposition step sequences** are NOT hard-coded in the workflow — they are resolved at
> `run()` from the **Disposition Strategy Registry** (`registries/disposition.py`, F6 pilot). The
> registry is populated at import time and is read-only from workflow code, so lookup is
> deterministic and replay-safe (`disposition.py:264-267`). The 12-step canonical *shape* (agent
> steps + bundle/PR/review/merge/persist code-steps) is fixed; the *agent* step IDs vary by
> disposition.

---

## 0. Module-level constants, imports, re-exports (`disposition.py:68-204`)

- ⚠️ **GOTCHA-IMPORTS:** all activity / registry / type imports are inside
  `with workflow.unsafe.imports_passed_through():` (`disposition.py:81-128`). MUST stay there
  for sandbox determinism (same rule as base). `import json` and `from datetime import timedelta`
  are top-level (`disposition.py:74-75`).
- **Back-compat re-exports** (`disposition.py:131-145`): `DispositionSpec = DispositionStrategy`;
  `RETIRE_SPEC`/`RETAIN_SPEC`/`REPLACE_SPEC`/`REPLATFORM_SPEC`/`CONSOLIDATE_SPEC` =
  `DISPOSITION_REGISTRY.get(<label>)`; `DISPOSITION_SPECS = {s.label: s for s in
  DISPOSITION_REGISTRY.list_all()}`. These are thin aliases; the registry is the source of truth.
  A rebuild must keep them importable (tests import them) but they are not consulted at runtime —
  `run()` calls `DISPOSITION_REGISTRY.get(...)` directly.
- `MODERNIZATION_DISPOSITIONS = {"Refactor", "Rearchitect"}` (`disposition.py:149`) — the reject
  set.
- `MAX_REWORK_ITERATIONS = 3` (`disposition.py:156`) — module-level back-compat constant. ⚠️ **The
  workflow does NOT read this constant** — it reads `spec.max_rework_iterations` off the registry
  strategy (`disposition.py:367,438`), which defaults to 3 (`registries/disposition.py:97`) but can
  diverge per-strategy. A rebuild must compare rework count against `spec.max_rework_iterations`,
  not the module constant.
- **Canonical 12-step code-/git-/agent-step IDs** (`disposition.py:181-191`), each a `str`
  constant used purely to drive `_set_step` so the dashboard stepper + backend step-mapping see the
  contract's 12-step shape:
  - `_BUNDLE_PRE_GATE_STEP   = "bundle-pre-gate-evidence"`
  - `_CREATE_GDE1_PR_STEP    = "create-g-de1-pr"`
  - `_AI_PRE_REVIEW_DE1_STEP = "ai-pre-review-de1"`
  - `_GATE_REVIEW_DE1_STEP   = "gate-review-de1"`
  - `_MERGE_GDE1_PR_STEP     = "merge-g-de1-pr"`
  - `_BUNDLE_POST_GATE_STEP  = "bundle-post-gate-evidence"`
  - `_CREATE_GDE2_PR_STEP    = "create-g-de2-pr"`
  - `_AI_PRE_REVIEW_DE2_STEP = "ai-pre-review-de2"`
  - `_GATE_REVIEW_DE2_STEP   = "gate-review-de2"`
  - `_MERGE_GDE2_PR_STEP     = "merge-g-de2-pr"`
  - `_PERSIST_SIDE_EFFECTS_STEP = "persist-disposition-side-effects"`
- `_DISPOSITION_OUTPUT_ARTIFACT = "disposition-output.json"` (`disposition.py:196`) — the single
  canonical artifact filename committed pre- and post-gate.
- Legacy aliases `_DISPOSITION_PLAN_STEP = _BUNDLE_PRE_GATE_STEP` and
  `_DISPOSITION_PLAN_ARTIFACT = _DISPOSITION_OUTPUT_ARTIFACT` (`disposition.py:203-204`) — retained
  for import-time back-compat; runtime use is gone.

---

## 1. CLASSVARS — `LineWorkflowBase` configuration (`disposition.py:221-225`)

| Classvar | Value | Effect |
|----------|-------|--------|
| `ASSEMBLY_LINE` | `AssemblyLine.DISPOSITION_EXECUTION` | `get_status.current_line` |
| `ARTIFACT_ROOT` | `"disposition"` | base path-prefix / PR-label root (but see GOTCHA-PATH) |
| `LINE_LABEL` | `"Disposition Execution"` | `_set_step`, `_execution_ctx` (`line_id="disposition-execution"`) |
| `STATUS_PREFIX` | `"disposition"` | `_set_step` → `"disposition_in_progress"` |

- `STEPS`, `STEP_WEIGHTS`, `SINGLE_GATE_KEY` are **NOT set** (left at base defaults `{}`,`{}`,`None`).
  ⚠️ **GOTCHA-NOSTEPS:** Disposition does not use the base `STEPS` dict at all — it carries
  per-step data on the registry `StepSpec` records and overrides every base method that would read
  `STEPS` (`_dispatch_agent_step`, `_commit_step_artifacts_spec`, `_build_evidence_data`). Because
  `SINGLE_GATE_KEY is None`, the base `_rework_gate_key_for_step` default returns `None` — **but it
  is never called**, because this workflow does not use the base `_dispatch_agent` (which is the
  only caller of `_rework_gate_key_for_step`). Disposition's own `_dispatch_agent_step` computes
  the gate key inline (§ Override 1). A rebuild need not set `SINGLE_GATE_KEY` but MUST route rework
  feedback by phase membership (pre vs post G-DE-1), not by a single gate key.

---

## 2. STATE — instance vars added by this subclass (`disposition.py:227-241`)

`__init__` calls `super().__init__()` FIRST (`disposition.py:228`) — initializing all 8 HIL vars
and the 19 `LineWorkflowBase` vars (see `_LineWorkflowBase.md` §2) — then sets:

| Var | Type | Initial | Mutated by → value | When |
|-----|------|---------|---------------------|------|
| `_spec` | `DispositionSpec \| None` | `None` | `run()` → resolved `DispositionStrategy` (`disposition.py:272`) | run start, after registry lookup |
| `_disposition_label` | `str` | `""` | `run()` → `disposition_str` (`disposition.py:273`) | run start |
| `_bundle_approvals` | `list[dict[str,str]]` | `[]` | `_run_gate` appends one dict per merged gate (`disposition.py:1179-1186`) | each gate that approves+merges |
| `_disposition_output_ref` | `str` | `""` | set by `_bundle_pre_gate_evidence` (`disposition.py:833`) AND `_bundle_post_gate_evidence` (`disposition.py:923`) to the committed artifact path | each bundle commit |
| `_disposition_output_json` | `str` | `""` | set ONLY by `_bundle_post_gate_evidence` (`disposition.py:928`) to the serialized envelope JSON | post-gate bundle commit |

> ⚠️ **GOTCHA-STATE-REF:** `_disposition_output_ref` is overwritten by BOTH bundle helpers, so at
> persist time it holds the **post-gate** path for non-Retain (last writer = post-gate bundle) and
> the **pre-gate** path for Retain (post-gate bundle never runs). Both helpers write the SAME path
> string (`disposition/{label}/{app_id}/disposition-output.json`), so this is idempotent in
> practice. `_disposition_output_json` is ONLY set post-gate, so for Retain it stays `""` at persist
> time (Retain never runs `_bundle_post_gate_evidence`). A rebuild MUST leave `_disposition_output_json`
> empty for Retain and populate it for non-Retain.
>
> ⚠️ **GOTCHA-STATE-DET:** `_disposition_output_json` is stored on `self` so
> `persist_disposition_side_effects` reads it without a Git read. This is replay-safe because the
> envelope is built from `_step_committed_paths` (already deterministic on replay) and
> `workflow.now()` (deterministic) (`disposition.py:924-928`). A rebuild MUST snapshot from
> deterministic sources only — never read the committed file back.

---

## 3. SIGNALS / QUERIES — what this subclass adds vs inherits

### 3.1 Inherited (DO NOT redefine — GOTCHA-SIG0 from base)
- **Signals (base):** `gate_approved`, `gate_rejected`, `escalation_resolved`, `merge_retry`
  (all `async def` on `LineWorkflowBase`). Disposition relies on `gate_approved`/`gate_rejected`
  buffering 5-tuples into `_gate_decisions`, consumed by `_wait_for_gate_decision`.
- **Signals (HIL mixin):** `approve`, `cancel_workflow`, `approve_plan`, `provide_plan_feedback`,
  `approve_research`, `provide_feedback`. `cancel_workflow` → `cancelled=True` is the kill switch
  that drains every gate wait / merge wait (§ Control flow returns `"cancelled"`).
- **Query (base):** `get_status` — the ONLY query; not redefined here.

### 3.2 Added by this subclass — `stakeholder_approved` (`disposition.py:1205-1225`) ★ NEW SIGNAL

```text
@workflow.signal
async def stakeholder_approved(self, signal: StakeholderApprovedSignal) -> None:
    self._gate_decisions.append((                  # disposition.py:1216-1224
        GateStatus.APPROVED,
        signal.approved_by,        # ⚠ see GOTCHA-SH1
        signal.justification,      # ⚠ see GOTCHA-SH1
        None,    # reason_category — approvals don't carry one
        [],      # card_decisions — reject-specific
    ))
    self._updated_at = _now_iso()                  # disposition.py:1225
```

- **Purpose:** lets the dashboard route a **stakeholder** sign-off through a distinct signal name
  for G-DE-1 (which requires stakeholder + PM) while still progressing the gate exactly like a
  normal `gate_approved` (`disposition.py:1209-1215`).
- **What it buffers/mutates:** appends a **5-tuple** `(APPROVED, approved_by, justification, None,
  [])` onto `self._gate_decisions` — the SAME shape `gate_approved` appends — then bumps
  `_updated_at`. It is consumed by the inherited `_wait_for_gate_decision`'s predicate
  `len(self._gate_decisions) > consumed or self.cancelled` (no special-casing; it is
  indistinguishable from `gate_approved` once buffered).
- ⚠️ **GOTCHA-SH1 (signal payload field mismatch — load-bearing):** the source dataclass
  `StakeholderApprovedSignal` (`types.py:165-170`) declares fields **`approval_id`, `stakeholder`,
  `scope`** — but this handler reads `signal.approved_by` and `signal.justification`
  (`disposition.py:1218-1219`), which **do not exist on that dataclass**. A literal rebuild that
  sends the documented `StakeholderApprovedSignal` would raise `AttributeError` inside the handler.
  For **behavioral parity** the rebuild MUST reproduce the handler reading `signal.approved_by` /
  `signal.justification` (i.e. the on-wire payload Temporal actually delivers must carry those two
  attributes). Do not "fix" the handler to read `stakeholder`/`scope`; reproduce the exact attribute
  reads. (In practice the dashboard sends a payload with `approved_by` + `justification`; the typed
  dataclass annotation is stale.)
- ⚠️ **GOTCHA-SH2 (this is an ADDITIVE signal, NOT a redefinition):** `stakeholder_approved` is a
  brand-new signal name — it does NOT re-decorate any base signal. A rebuild registers it under the
  wire name `stakeholder_approved`. It MUST NOT touch `gate_approved`/`gate_rejected` (GOTCHA-SIG0).
- ⚠️ **GOTCHA-SH3 (no gate-type discrimination):** the handler does NOT check which gate is
  pending — it always appends an APPROVED decision. If a stakeholder fires it while G-DE-2 is the
  pending gate, it approves G-DE-2. In practice the dashboard only surfaces this control on G-DE-1,
  but the workflow logic itself is gate-agnostic. A rebuild must NOT add a `_pending_gate` guard.

---

## 4. OVERRIDE MATRIX — what this subclass overrides vs the base

| Base method | Status here | Why / how it differs |
|-------------|-------------|----------------------|
| `run()` / `_execute()` | **DEFINED** (base has none) | full orchestration, §5 / §6 |
| `_dispatch_agent` | **NOT overridden; NOT used.** Disposition defines its own `_dispatch_agent_step` (different name) | runtime disposition label in `task_type` + path; rework key by phase. Override 1 (§7) |
| `_commit_step_artifacts` | **NOT overridden; NOT used.** Disposition defines `_commit_step_artifacts_spec` | runtime disposition label in commit msg + path. Override 2 (§8) |
| `_create_gate_pr` | **OVERRIDDEN** (`disposition.py:1410-1438`) | adds disposition label + gate_type to PR labels. Override 3 (§9) |
| `_build_evidence_data` | **OVERRIDDEN** (`disposition.py:1440-1525`) | adds `disposition` key + iterates registry StepSpecs (not `STEPS`) + injects the two bundle code-steps. Override 4 (§10b) |
| `_rework_gate_key_for_step` | **NOT overridden** (base default returns `SINGLE_GATE_KEY=None`); never called | Disposition's `_dispatch_agent_step` computes the gate key inline by phase membership. (GOTCHA-NOSTEPS) |
| `_primary_skill_for_step` / `_evidence_step_metadata` / `_evidence_steps_iter` | **NOT overridden; NOT used** | Disposition reads `StepSpec.skill_id`/`.artifact` directly; its own `_build_evidence_data` does not call `_evidence_steps_iter`. |
| `gate_approved`/`gate_rejected`/`escalation_resolved`/`merge_retry`/`get_status` | **INHERITED, never redefined** | GOTCHA-SIG0 / GOTCHA-Q1 |

**Helpers DEFINED on this subclass (not on base):** `run`, `_execute`, `_complete`,
`_emit_output_bundle`, `_build_output_bundle`, `_build_payload`, `_bundle_pre_gate_evidence`,
`_bundle_post_gate_evidence`, `_persist_disposition_side_effects`,
`_fire_disposition_executed_signal`, `_run_step`, `_inputs_for_step`, `_run_gate`, `_fail`,
`stakeholder_approved`, `_dispatch_agent_step`, `_commit_step_artifacts_spec`, `_create_gate_pr`
(override), `_build_evidence_data` (override), `_build_gde1_pr_body`, `_build_gde2_pr_body`. Plus
module function `_disposition_str`.

**Inherited helpers this workflow CALLS:** `_set_step`, `_update_app_status`,
`_submit_gate_evidence`, `_run_gate_pre_review`, `_wait_for_gate_decision`,
`_reconcile_and_merge_with_retry_loop`, `_bump_rework`, `_rework_count`, `_now_iso` (module fn from
base module).

---

## 5. `run()` — entry point (`disposition.py:243-301`) ★ CONTROL FLOW

```text
@workflow.run
async def run(self, input: LineWorkflowInput) -> str:        # returns "completed"|"cancelled"|"failed"
    self._status     = WorkflowStatus.RUNNING                # disposition.py:250
    self._started_at = _now_iso()                            # disposition.py:251
    self._updated_at = self._started_at                      # disposition.py:252

    app_id = input.app_id                                    # disposition.py:254
    self._app_id = app_id                                    # disposition.py:255

    disposition_str = _disposition_str(input.disposition)    # disposition.py:257  (see §12)

    # ---- BRANCH 1: reject modernization dispositions ----
    if disposition_str in MODERNIZATION_DISPOSITIONS:        # disposition.py:258
        return await self._fail(                             # disposition.py:260-263
            f"unsupported-disposition-{disposition_str.lower()}",
            app_id,
        )

    # ---- BRANCH 2: resolve strategy via registry (try/except) ----
    try:
        spec = DISPOSITION_REGISTRY.get(disposition_str)     # disposition.py:269
    except UnknownDispositionError:                          # disposition.py:270
        return await self._fail("missing-disposition", app_id)  # disposition.py:271
    self._spec            = spec                             # disposition.py:272
    self._disposition_label = disposition_str               # disposition.py:273

    repo       = input.artifact_repo                         # disposition.py:275
    wf_id      = workflow.info().workflow_id                 # disposition.py:276
    # ---- BRANCH 3: derive run_suffix from workflow id ----
    run_suffix = wf_id.rsplit("-", 1)[-1] if "-" in wf_id else wf_id[:8]   # disposition.py:277
    branch       = f"olympus/disposition/{disposition_str.lower()}/{app_id}/{run_suffix}"  # disposition.py:278-281
    workspace_key = f"disposition-{disposition_str.lower()}-{app_id}-{run_suffix}"         # disposition.py:282-284

    # ---- BRANCH 4: execute, with terminal failure projection ----
    try:
        return await self._execute(                          # disposition.py:287-289
            input, spec, app_id, repo, branch, workspace_key,
        )
    except Exception:                                        # disposition.py:290
        self._status       = WorkflowStatus.FAILED           # disposition.py:291
        self._current_step = "failed"                        # disposition.py:292
        self._updated_at   = _now_iso()                      # disposition.py:293
        try:
            await self._update_app_status(                   # disposition.py:295-298
                app_id, "disposition_failed", "failed", "Disposition Execution",
            )
        except Exception:                                    # disposition.py:299
            pass  # Best-effort                              # disposition.py:300
        raise                                                # disposition.py:301
```

**Branch inventory in `run` (6):** B1 modernization-reject (258); B2 try/except UnknownDisposition
(269/270); B3 `run_suffix` ternary `"-" in wf_id` (277); B4 outer try/except (290); B4-inner
try/except…pass around the failure-status push (299-300); plus the `raise` re-propagation (301).

> ⚠️ **GOTCHA-RUN1 (reject is a FAIL, not a no-op):** Refactor/Rearchitect reaching this workflow
> returns `"failed"` with reason step `unsupported-disposition-{lower}` (`disposition.py:258-263`),
> NOT silently completing. A rebuild must `_fail`, not skip.
> ⚠️ **GOTCHA-RUN2 (unknown disposition fails loudly):** `DISPOSITION_REGISTRY.get` raises
> `UnknownDispositionError` (subclass of `EntityNotFound`/`KeyError`) on unknown labels; the
> workflow catches it and `_fail("missing-disposition", ...)` (`disposition.py:269-271`). Retire is
> NOT a safe default. A rebuild must catch the registry's not-found error and fail with reason
> `missing-disposition`.
> ⚠️ **GOTCHA-RUN3 (branch / workspace naming is deterministic & label-lowercased):** branch =
> `olympus/disposition/{label.lower()}/{app_id}/{run_suffix}`; `run_suffix` is the substring after
> the last `-` in the workflow id (or the first 8 chars if no `-`). A rebuild MUST reproduce both
> templates exactly — they determine the Git branch every artifact lands on and the agent workspace
> key. The `.lower()` on the label appears in branch, workspace, every artifact path, every commit
> message, every `task_type`, and the PR labels.
> ⚠️ **GOTCHA-RUN4 (the outer except re-raises after best-effort DB push):** the `except Exception`
> at (290) sets FAILED state, attempts a best-effort `_update_app_status` (swallowing its own
> failure at 299-300), then **`raise`** (301). So a workflow-internal exception both projects
> `disposition_failed` to the DB AND propagates as a Temporal workflow failure (NOT a clean
> `"failed"` return — that string is only returned by `_fail` for the two early-validation cases and
> by the `max-rework-exceeded` paths). A rebuild MUST re-raise after the projection, not swallow.

---

## 6. `_execute(...)` — core 12-step orchestration (`disposition.py:303-476`) ★★ CORE CONTROL FLOW

Signature: `_execute(self, input, spec, app_id, repo, branch, workspace_key) -> str`.

```text
prior_artifacts = list(input.prior_artifacts)                          # disposition.py:319
total_steps     = len(spec.pre_gate1_steps) + len(spec.post_gate1_steps)  # disposition.py:320
# ---- BRANCH 1: gate weight depends on whether G-DE-2 exists ----
gate_count      = 2 if spec.has_gate2 else 1                            # disposition.py:322
per_step_weight = (100.0 - 10.0 * gate_count) / max(total_steps, 1)     # disposition.py:323
```

⚠️ **GOTCHA-EXEC-WEIGHT:** progress math: each gate is worth **10%** of total; the remaining
`100 - 10*gate_count` is split evenly across all agent steps. `max(total_steps, 1)` guards a
divide-by-zero (a hypothetical zero-step strategy). For Retain (`has_gate2=False`, 5 steps):
`per_step_weight = (100-10)/5 = 18.0`. For Retire (`has_gate2=True`, 2 pre + 5 post = 7 steps):
`per_step_weight = (100-20)/7 ≈ 11.4286`. A rebuild MUST reproduce this formula exactly — the
`_set_step(progress=...)` values are observable via `get_status`.

### 6.1 Phase 1 — pre-G-DE-1 steps + G-DE-1 gate (rework loop) `disposition.py:325-372`

```text
# ---- LOOP 1: while True (G-DE-1 rework loop) ----
while True:                                                            # disposition.py:326
    cumulative = 0.0                                                  # disposition.py:327
    # ---- LOOP 1a: run each pre-gate1 agent step ----
    for step_spec in spec.pre_gate1_steps:                           # disposition.py:328
        await self._set_step(step_spec.step, cumulative)             # disposition.py:329
        await self._run_step(                                        # disposition.py:330-333
            step_spec, app_id, repo, branch, workspace_key, prior_artifacts,
        )
        cumulative += per_step_weight                                # disposition.py:334

    # code-step: synthesize + commit partial disposition-output.json
    await self._set_step(_BUNDLE_PRE_GATE_STEP, cumulative)          # disposition.py:340
    await self._bundle_pre_gate_evidence(repo, branch, app_id, input, spec)  # disposition.py:341-343

    gate1_evidence_steps = (                                         # disposition.py:344-347
        [s.step for s in spec.pre_gate1_steps] + [_BUNDLE_PRE_GATE_STEP]
    )

    gate1_decision = await self._run_gate(                           # disposition.py:349-362
        input, repo, branch, app_id,
        gate_type=GateType.G_DE_1,
        gate_step=_GATE_REVIEW_DE1_STEP,
        evidence_steps=gate1_evidence_steps,
        title=f"Gate G-DE-1: {spec.title_label} Execution Plan Approval — {app_id}",
        body_builder=self._build_gde1_pr_body,
        create_pr_step=_CREATE_GDE1_PR_STEP,
        pre_review_step=_AI_PRE_REVIEW_DE1_STEP,
        merge_pr_step=_MERGE_GDE1_PR_STEP,
    )
    # ---- BRANCH 2: cancelled ----
    if gate1_decision == "cancelled":                               # disposition.py:363
        return "cancelled"                                          # disposition.py:364
    # ---- BRANCH 3: rejected → bump rework, maybe fail, else re-loop ----
    if gate1_decision == "rejected":                                # disposition.py:365
        self._bump_rework("G-DE-1")                                 # disposition.py:366
        if self._rework_count("G-DE-1") > spec.max_rework_iterations:  # disposition.py:367
            return await self._fail("max-rework-exceeded-gde1", app_id)  # disposition.py:368-370
        continue  # Re-run pre-gate1 steps                          # disposition.py:371
    break  # approved → exit Phase 1 loop                           # disposition.py:372
```

### 6.2 Phase-2 fork — Retain terminal vs full decommission `disposition.py:374-395`

```text
# ---- BRANCH 4: Retain has NO G-DE-2 → terminal at G-DE-1 ----
if not spec.has_gate2:                                               # disposition.py:375
    await self._emit_output_bundle(                                 # disposition.py:382-388
        input=input, spec=spec, app_id=app_id, repo=repo, branch=branch,
    )
    await self._set_step(_PERSIST_SIDE_EFFECTS_STEP, 99.0)          # disposition.py:389
    await self._persist_disposition_side_effects(                   # disposition.py:390-394
        app_id=app_id, spec=spec, terminal_status="disposition_complete",
    )
    return await self._complete(app_id)                             # disposition.py:395
    # NOTE: Retain does NOT fire DispositionExecutedSignal.
```

⚠️ **GOTCHA-RETAIN-TERMINAL:** Retain (the only `has_gate2=False` strategy) terminates right after
G-DE-1 approval+merge: it emits the canonical bundle, sets the persist step at progress **99.0**,
persists with `terminal_status="disposition_complete"`, and `_complete`s. It does NOT run Phase 2,
does NOT bundle post-gate, and does NOT fire `DispositionExecutedSignal` (`disposition.py:380-381`,
`994-995`). Retain's handoff to Sustainment is **state-based** via the `sustainment-handoff` skill's
artifact. A rebuild MUST branch on `spec.has_gate2` here and skip all G-DE-2 / signal logic for the
no-gate2 case.

### 6.3 Phase 2 — post-G-DE-1 steps + G-DE-2 gate (rework loop) `disposition.py:397-443`

```text
# ---- LOOP 2: while True (G-DE-2 rework loop) ----
while True:                                                          # disposition.py:397
    cumulative = len(spec.pre_gate1_steps) * per_step_weight + 10.0  # disposition.py:398-400
    # ---- LOOP 2a: run each post-gate1 agent step ----
    for step_spec in spec.post_gate1_steps:                         # disposition.py:401
        await self._set_step(step_spec.step, cumulative)            # disposition.py:402
        await self._run_step(                                       # disposition.py:403-406
            step_spec, app_id, repo, branch, workspace_key, prior_artifacts,
        )
        cumulative += per_step_weight                               # disposition.py:407

    # code-step: synthesize + commit COMPLETE disposition-output.json
    await self._set_step(_BUNDLE_POST_GATE_STEP, cumulative)        # disposition.py:411
    await self._bundle_post_gate_evidence(repo, branch, app_id, input, spec)  # disposition.py:412-414

    gate2_decision = await self._run_gate(                          # disposition.py:416-433
        input, repo, branch, app_id,
        gate_type=GateType.G_DE_2,
        gate_step=_GATE_REVIEW_DE2_STEP,
        evidence_steps=(
            [s.step for s in spec.pre_gate1_steps]
            + [s.step for s in spec.post_gate1_steps]
            + [_BUNDLE_POST_GATE_STEP]
        ),
        title=f"Gate G-DE-2: {spec.title_label} Decommission Readiness Sign-off — {app_id}",
        body_builder=self._build_gde2_pr_body,
        create_pr_step=_CREATE_GDE2_PR_STEP,
        pre_review_step=_AI_PRE_REVIEW_DE2_STEP,
        merge_pr_step=_MERGE_GDE2_PR_STEP,
    )
    # ---- BRANCH 5: cancelled ----
    if gate2_decision == "cancelled":                               # disposition.py:434
        return "cancelled"                                          # disposition.py:435
    # ---- BRANCH 6: rejected → bump, maybe fail, else re-loop ----
    if gate2_decision == "rejected":                                # disposition.py:436
        self._bump_rework("G-DE-2")                                 # disposition.py:437
        if self._rework_count("G-DE-2") > spec.max_rework_iterations:  # disposition.py:438
            return await self._fail("max-rework-exceeded-gde2", app_id)  # disposition.py:439-441
        continue                                                    # disposition.py:442
    break  # approved → exit Phase 2 loop                           # disposition.py:443
```

### 6.4 Terminal sequence (non-Retain) `disposition.py:445-476`

```text
# Legacy canonical bundle emission (P5-S13 / W12 schema-validation pass)
await self._emit_output_bundle(input=input, spec=spec, app_id=app_id,
                               repo=repo, branch=branch)            # disposition.py:449-455

await self._set_step(_PERSIST_SIDE_EFFECTS_STEP, 99.0)             # disposition.py:460
await self._persist_disposition_side_effects(                      # disposition.py:461-465
    app_id=app_id, spec=spec, terminal_status="disposition_complete",
)

# Fire DispositionExecutedSignal to Deployment (non-Retain only)
await self._fire_disposition_executed_signal(input=input, app_id=app_id, spec=spec)  # disposition.py:470-474

return await self._complete(app_id)                                # disposition.py:476
```

**Branch inventory in `_execute` (12 + 4 loops):** B1 `2 if has_gate2 else 1` (322); LOOP1 `while
True` (326); LOOP1a `for step_spec in pre_gate1_steps` (328); B2 `=="cancelled"` (363); B3
`=="rejected"` (365) + nested `if rework_count > max` (367); B4 `if not has_gate2` (375); LOOP2
`while True` (397); LOOP2a `for step_spec in post_gate1_steps` (401); B5 `=="cancelled"` (434); B6
`=="rejected"` (436) + nested `if rework_count > max` (438); the two `break`s (372, 443) and several
`return`s. (Plus the implicit `max(total_steps,1)` at 323.)

> ⚠️ **GOTCHA-REWORK-LOOP (the canonical subclass rework loop — counter bumped HERE):** per base
> GOTCHA-RW1/WG5, `_wait_for_gate_decision` does NOT touch `_rework_iterations`. THIS workflow bumps
> via `self._bump_rework("G-DE-1")` / `_bump_rework("G-DE-2")` on the `"rejected"` branch
> (`disposition.py:366,437`), then compares `_rework_count(...) > spec.max_rework_iterations`. The
> ceiling is **`spec.max_rework_iterations`** (registry field, default 3), NOT the module constant.
> The `continue` re-runs the entire phase loop (re-dispatching every agent step in that phase) with
> `_rework_feedback["G-DE-1"]` / `["G-DE-2"]` now populated (set by `_wait_for_gate_decision` on the
> reject) and forwarded by `_dispatch_agent_step` (§7). The first rejection bumps to 1; the 4th
> rejection bumps to 4, `4 > 3` → fail. So a strategy with `max_rework_iterations=3` tolerates **3
> rejections then re-attempts**, and fails on the **4th** rejection. A rebuild MUST use strict `>`
> (not `>=`) and bump BEFORE the comparison.
> ⚠️ **GOTCHA-REWORK-FEEDBACK-ROUTING:** because Phase-1 rework re-runs ONLY `pre_gate1_steps` and
> Phase-2 rework re-runs ONLY `post_gate1_steps`, and `_dispatch_agent_step` selects feedback by
> phase membership (§7), G-DE-1 feedback flows only to pre-gate steps and G-DE-2 feedback only to
> post-gate steps. A rebuild MUST keep the two rework loops disjoint by phase.
> ⚠️ **GOTCHA-EXEC-CUMULATIVE:** Phase-2 cumulative restarts at `len(pre_gate1_steps)*per_step_weight
> + 10.0` (`disposition.py:398-400`) — i.e. it accounts for all pre-gate weight PLUS the 10% G-DE-1
> gate. On a G-DE-2 rework `continue`, cumulative is recomputed from scratch at the top of LOOP2
> (not carried), so progress resets to the post-gate baseline each rework iteration. A rebuild MUST
> recompute cumulative at the top of each `while True` iteration, not accumulate across reworks.
> ⚠️ **GOTCHA-EXEC-DOUBLE-BUNDLE:** for non-Retain, the canonical `disposition-output.json` envelope
> is written THREE times to the same path: once by `_bundle_pre_gate_evidence` (status
> `"in_progress"`), once by `_bundle_post_gate_evidence` (status `"completed"`), and once by
> `_emit_output_bundle` (status `"completed"`, schema-validated). The comment
> (`disposition.py:445-448`) notes `_emit_output_bundle` is "a schema-validation pass more than a
> second write" — it produces the same envelope shape to the same canonical
> `dispositions/{portfolio}/{app}/...` path (a DIFFERENT path from the bundle helpers' per-label
> path — see GOTCHA-EMIT-PATH). A rebuild MUST run all three in this order for non-Retain (Retain
> runs only pre-gate bundle + `_emit_output_bundle`).

---

## 7. OVERRIDE 1 — `_dispatch_agent_step(...)` (`disposition.py:1233-1286`)

Replaces base `_dispatch_agent` (different name; base method is never used). Dispatches one agent
for a `StepSpec`, routing rework feedback by **phase membership**.

```text
async def _dispatch_agent_step(self, app_id, step_spec, input_artifacts,
                               workspace_key="", artifact_repo="", artifact_ref="") -> AgentTaskResult:
    context = {}                                                   # disposition.py:1248
    assert self._spec is not None                                  # disposition.py:1249
    # ---- BRANCH 1: pick rework-feedback key by phase ----
    if step_spec in self._spec.pre_gate1_steps:                    # disposition.py:1250
        fb = self._rework_feedback.get("G-DE-1")                   # disposition.py:1251
    else:                                                          # disposition.py:1252
        fb = self._rework_feedback.get("G-DE-2")                   # disposition.py:1253
    # ---- BRANCH 2: attach feedback only if present ----
    if fb is not None:                                             # disposition.py:1254
        context["rework_feedback"] = fb                            # disposition.py:1255

    task_input = AgentTaskInput(
        task_type=f"disposition-{self._disposition_label.lower()}-{step_spec.step}",  # disposition.py:1257-1260
        app_id=app_id,
        skill_id=step_spec.skill_id,                               # disposition.py:1262
        input_artifacts=input_artifacts,
        artifact_repo=artifact_repo,
        artifact_ref=artifact_ref,
        workspace_key=workspace_key,
        context=context,
    )
    result = await workflow.execute_activity(
        dispatch_agent_task, task_input,                           # disposition.py:1269-1270
        start_to_close_timeout=timedelta(hours=1),                 # disposition.py:1272
        retry_policy=RETRY_POLICIES["agent_failure"],              # disposition.py:1273
        activity_id=f"agent-{step_spec.step}",                     # disposition.py:1274
    )
    self._agent_metadata[step_spec.step] = {                       # disposition.py:1277-1284
        "model_used":        result.model_used,
        "duration_ms":       result.duration_ms,
        "token_usage_input": result.token_usage_input,
        "token_usage_output":result.token_usage_output,
        "cost_estimate_usd": result.cost_estimate_usd,
        "output_files":      result.output_files,
    }
    return result
```

**Branch inventory (2):** B1 `if step_spec in self._spec.pre_gate1_steps` else (1250/1252); B2
`if fb is not None` (1254).

**Activity call:** `dispatch_agent_task` — `task_input`; **1 hour** start_to_close;
`agent_failure` (3 attempts, 5-60s backoff); `activity_id=f"agent-{step_spec.step}"`.

> ⚠️ **GOTCHA-DISP1 (phase membership selects the rework key — NOT `_rework_gate_key_for_step`):**
> Disposition decides G-DE-1 vs G-DE-2 feedback by `step_spec in self._spec.pre_gate1_steps`
> (`disposition.py:1250`). Because `StepSpec` is a frozen dataclass, `in` uses value equality. A
> rebuild MUST route by phase membership, not by a step→gate map. (This is why
> `_rework_gate_key_for_step` is never overridden and never called — see GOTCHA-NOSTEPS.)
> ⚠️ **GOTCHA-DISP2 (NO context-priors, NO execution_context):** unlike base `_dispatch_agent`,
> this override does NOT load context-priors (no `context-priors-v1` patch gate) and does NOT set
> `execution_context` on the `AgentTaskInput`. The only `context` keys are `rework_feedback` (when
> present). A rebuild MUST NOT add the priors load or the execution-context to this method —
> matching base would change history/behavior.
> ⚠️ **GOTCHA-DISP3 (task_type embeds runtime label):** `task_type =
> f"disposition-{label.lower()}-{step}"` (`disposition.py:1257-1260`) — the runtime disposition
> label is baked in. This is WHY the base method can't be reused (the base builds
> `f"{ARTIFACT_ROOT}-{step}"` = `f"disposition-{step}"`, missing the label). A rebuild MUST embed
> the label.
> ⚠️ **GOTCHA-DISP4 (`agent_failure` 1h timeout, deterministic activity_id):** same resilience
> contract as base dispatch — agent failures retry 3×; validation failures surface as a result. The
> `activity_id=f"agent-{step}"` makes the dispatch idempotent on replay. A rebuild keeps both.

---

## 8. `_run_step(...)` + `_inputs_for_step(...)` (`disposition.py:1029-1071`)

### 8.1 `_run_step` (`disposition.py:1029-1055`)
```text
async def _run_step(self, step_spec, app_id, repo, branch, workspace_key, prior_artifacts) -> None:
    step_inputs = self._inputs_for_step(step_spec.step, prior_artifacts)   # disposition.py:1039
    result = await self._dispatch_agent_step(                              # disposition.py:1040-1047
        app_id=app_id, step_spec=step_spec, input_artifacts=step_inputs,
        workspace_key=workspace_key, artifact_repo=repo, artifact_ref=branch,
    )
    self._step_results[step_spec.step] = result.output_artifacts           # disposition.py:1048
    artifact_path = (                                                      # disposition.py:1049-1052
        f"disposition/{self._disposition_label.lower()}/{app_id}/{step_spec.artifact}"
    )
    await self._commit_step_artifacts_spec(                                # disposition.py:1053-1054
        repo, branch, app_id, step_spec, result, artifact_path,
    )
```
No branches. ⚠️ **GOTCHA-RUNSTEP (`_step_results` is populated HERE):** per base GOTCHA-S2 the base
never writes `_step_results`; this subclass writes `self._step_results[step] =
result.output_artifacts` (`disposition.py:1048`) so the evidence bundle's `"output"` fields are
populated. A rebuild MUST set this after every dispatch or evidence comes back empty.

### 8.2 `_inputs_for_step` (`disposition.py:1057-1071`)
```text
def _inputs_for_step(self, step_name, prior_artifacts) -> list[str]:
    assert self._spec is not None                                          # disposition.py:1062
    ordered = [s.step for s in self._spec.pre_gate1_steps] + \             # disposition.py:1063-1065
              [s.step for s in self._spec.post_gate1_steps]
    inputs = list(prior_artifacts)                                         # disposition.py:1066
    for prev in ordered:                                                   # disposition.py:1067  LOOP
        if prev == step_name:                                             # disposition.py:1068  BRANCH
            break                                                          # disposition.py:1069
        inputs.extend(self._step_committed_paths.get(prev, []))            # disposition.py:1070
    return dedup_paths(inputs)                                             # disposition.py:1071
```
**Branch inventory (1 + 1 loop):** `for prev in ordered` (1067); `if prev == step_name: break`
(1068).

⚠️ **GOTCHA-INPUTS (cumulative prior-step inputs):** each step receives `prior_artifacts` PLUS every
**previously committed** step's paths (in full pre+post order, stopping at the current step), then
deduped via `dedup_paths`. So step N sees the committed artifacts of steps 1..N-1. The order list is
ALWAYS the full pre+post sequence regardless of phase — a post-gate step thus sees all pre-gate
committed paths too. A rebuild MUST build inputs by walking the full ordered list, breaking at the
current step, extending with `_step_committed_paths`, and dedup.

---

## 9. OVERRIDE 2 — `_commit_step_artifacts_spec(...)` (`disposition.py:1288-1408`)

Replaces base `_commit_step_artifacts` (different name; base never used). Writes the per-step
summary JSON + agent output files; commit message + paths embed the runtime disposition label.

```text
async def _commit_step_artifacts_spec(self, repo, branch, app_id, step_spec, result, artifact_path) -> None:
    metadata     = self._agent_metadata.get(step_spec.step, {})            # disposition.py:1302
    output_files = metadata.get("output_files", [])                        # disposition.py:1303
    # ---- BRANCH 1: file_paths from output_files ----
    file_paths   = [f.path for f in output_files] if output_files else []  # disposition.py:1304

    committed = [artifact_path]                                            # disposition.py:1306

    content = json.dumps({                                                 # disposition.py:1308-1322
        "disposition": self._disposition_label,
        "step": step_spec.step,
        "skill_id": step_spec.skill_id,
        "artifacts": result.output_artifacts,
        "file_artifacts": file_paths,
        "model_used": metadata.get("model_used", ""),
        "duration_ms": metadata.get("duration_ms", 0),
        "token_usage": {"input": metadata.get("token_usage_input", 0),
                        "output": metadata.get("token_usage_output", 0)},
        "cost_estimate_usd": metadata.get("cost_estimate_usd", 0.0),
        "timestamp": workflow.now().isoformat(),                           # disposition.py:1321  deterministic
    }, indent=2)

    # ---- BRANCH 2: patched batch-write vs per-file write ----
    if workflow.patched("disposition-batch-writes-v1"):                    # disposition.py:1324
        batch = [(artifact_path, content)]                                 # disposition.py:1325
        for file_artifact in output_files:                                 # disposition.py:1326  LOOP
            file_path = (                                                  # disposition.py:1327-1330
                f"disposition/{self._disposition_label.lower()}/{app_id}/files/{step_spec.step}/{file_artifact.path}"
            )
            batch.append((file_path, file_artifact.content))               # disposition.py:1331
            committed.append(file_path)                                    # disposition.py:1332
        await workflow.execute_activity(
            write_artifacts_batch,                                         # disposition.py:1333-1334
            WriteArtifactsBatchInput(repo=repo, branch=branch, files=batch,
                commit_message=f"disposition/{label.lower()}({app_id}): {step_spec.step} artifacts"),  # disposition.py:1339-1342
            start_to_close_timeout=timedelta(seconds=120),                 # disposition.py:1344
            retry_policy=RETRY_POLICIES["transient"],                      # disposition.py:1345
            activity_id=f"commit-{step_spec.step}",                        # disposition.py:1346
        )
    else:
        await workflow.execute_activity(
            write_artifact,                                                # disposition.py:1349-1350
            WriteArtifactInput(repo=repo, branch=branch, path=artifact_path, content=content,
                commit_message=f"disposition/{label.lower()}({app_id}): {step_spec.step} artifacts"),  # disposition.py:1356-1359
            start_to_close_timeout=timedelta(seconds=60),                  # disposition.py:1361
            retry_policy=RETRY_POLICIES["transient"],                      # disposition.py:1362
            activity_id=f"commit-{step_spec.step}",                        # disposition.py:1363
        )
        for file_artifact in output_files:                                 # disposition.py:1366  LOOP
            file_path = (                                                  # disposition.py:1367-1370
                f"disposition/{label.lower()}/{app_id}/files/{step_spec.step}/{file_artifact.path}"
            )
            await workflow.execute_activity(
                write_artifact,                                            # disposition.py:1371-1372
                WriteArtifactInput(repo=repo, branch=branch, path=file_path, content=file_artifact.content,
                    commit_message=f"disposition/{label.lower()}({app_id}): {step_spec.step} file {file_artifact.path}"),  # disposition.py:1377-1382
                start_to_close_timeout=timedelta(seconds=60),              # disposition.py:1384
                retry_policy=RETRY_POLICIES["transient"],                  # disposition.py:1385
            )
            committed.append(file_path)                                    # disposition.py:1387

    self._step_committed_paths[step_spec.step] = committed                 # disposition.py:1389

    # ---- BRANCH 3: patched output-ref patch (best-effort) ----
    if workflow.patched("patch-output-artifact-ref-v1"):                   # disposition.py:1391
        try:
            await workflow.execute_activity(
                update_agent_task_output_ref,                              # disposition.py:1393-1394
                args=[app_id,
                      f"disposition-{self._disposition_label.lower()}-{step_spec.step}",  # disposition.py:1397-1400
                      artifact_path],
                start_to_close_timeout=timedelta(seconds=30),              # disposition.py:1403
                retry_policy=RETRY_POLICIES["transient"],                  # disposition.py:1404
                activity_id=f"patch-output-ref-{step_spec.step}",          # disposition.py:1405
            )
        except Exception:                                                  # disposition.py:1407  best-effort
            pass                                                           # disposition.py:1408
```

**Branch inventory (3 + 2 loops):** B1 `[...] if output_files else []` (1304); B2
`if workflow.patched("disposition-batch-writes-v1")` else (1324/1348) + the batch `for` (1326) +
the per-file `for` (1366); B3 `if workflow.patched("patch-output-artifact-ref-v1")` (1391) + inner
`try/except…pass` (1407-1408).

**Activity calls (depend on patch):**
- patched branch: ONE `write_artifacts_batch` (summary + all files) — `repo`/`branch`/`batch`;
  **120s**; `transient`; `activity_id="commit-{step}"`.
- unpatched branch: ONE `write_artifact` (summary) — **60s**; `transient`; `activity_id="commit-{step}"`
  — then ONE `write_artifact` per output file — **60s**; `transient`; **no activity_id**.
- then (both branches) optional `update_agent_task_output_ref` — positional `args=[app_id,
  "disposition-{label}-{step}", artifact_path]`; **30s**; `transient`;
  `activity_id="patch-output-ref-{step}"`; ONLY under patch, try/except…pass.

> ⚠️ **GOTCHA-COMMIT-PATCH (`disposition-batch-writes-v1` — verbatim, replay-critical):** the
> batch-vs-per-file fork is patch-gated (`disposition.py:1324`). Pre-patch in-flight runs replay
> through the per-file branch (N commits); post-patch runs use ONE batched commit. The patch ID
> `"disposition-batch-writes-v1"` MUST be reproduced exactly — it changes git history (one commit
> vs N) and replay determinism. The SAME patch gates the two bundle helpers (§11). A rebuild MUST
> use this exact string in all three places.
> ⚠️ **GOTCHA-COMMIT-PATHS (label-embedded artifact + file paths):** summary commits to
> `disposition/{label.lower()}/{app_id}/{step_spec.artifact}` (computed by `_run_step`, passed in);
> output files commit to `disposition/{label.lower()}/{app_id}/files/{step}/{file.path}`. Commit
> messages embed `disposition/{label.lower()}({app_id}): {step} artifacts` / `... file {path}`.
> This differs from base (`{ARTIFACT_ROOT}/{app_id}/files/...`, msg `{ARTIFACT_ROOT}({app_id})`)
> because the label is interpolated — WHY the override exists. A rebuild MUST reproduce the
> label-embedded templates exactly.
> ⚠️ **GOTCHA-COMMIT-NOCTX:** unlike base `_commit_step_artifacts`, this override does NOT thread an
> `execution_context` into the write inputs and does NOT do the mirror-repo write. A rebuild MUST
> NOT add those.
> ⚠️ **GOTCHA-COMMIT-OUTPUTREF (positional args + observability-only):** the output-ref patch uses
> positional `args=[app_id, task_type, artifact_path]` (`disposition.py:1395-1402`), NOT a dataclass,
> and its failure is swallowed (`except Exception: pass`). The `task_type` here is
> `disposition-{label}-{step}` — matching the dispatch task_type so the DB row links. A rebuild MUST
> match the positional shape and swallow failures.

---

## 10. OVERRIDE 3 — `_create_gate_pr(...)` (`disposition.py:1410-1438`)

Replaces base `_create_gate_pr` — adds the disposition label to PR labels.
```text
async def _create_gate_pr(self, repo, branch, app_id, gate_type, title, body):
    pr_input = CreatePRInput(
        repo=repo, source_branch=branch, target_branch="main",         # disposition.py:1421-1423
        title=title, body=body,
        labels=["gate-review", "disposition",
                self._disposition_label.lower(), gate_type],            # disposition.py:1426-1431
    )
    return await workflow.execute_activity(
        create_pr, pr_input,                                           # disposition.py:1433-1434
        start_to_close_timeout=timedelta(seconds=60),                  # disposition.py:1436
        retry_policy=RETRY_POLICIES["transient"],                      # disposition.py:1437
    )
```
No branches. **Activity:** `create_pr` — **60s**; `transient`. Always targets `main`.

⚠️ **GOTCHA-PR-LABELS:** labels are `["gate-review", "disposition", {label.lower()}, gate_type]` —
**four** labels (base has three: `["gate-review", ARTIFACT_ROOT, gate_type]`). The override adds the
lowercased disposition label as a fourth label and hard-codes `"disposition"` as the second (which
equals `ARTIFACT_ROOT` here anyway). `gate_type` is a **string** (e.g. `"G-DE-1"`) here. ⚠️ Unlike
base, this override does NOT set `execution_context` on the `CreatePRInput`. A rebuild MUST emit
exactly these four labels in this order and omit the execution context.

---

## 10b. OVERRIDE 4 — `_build_evidence_data(...)` (`disposition.py:1440-1525`)

Replaces base `_build_evidence_data`. Adds a top-level `disposition` key, iterates the **registry
StepSpecs** (`spec.pre_gate1_steps + spec.post_gate1_steps`) instead of the base `STEPS` dict / the
`_evidence_steps_iter` hook, and explicitly injects the two synthetic bundle code-steps
(`_BUNDLE_PRE_GATE_STEP`, `_BUNDLE_POST_GATE_STEP`) so G-DE-1 threshold predicates find the
`g_de1_readiness` flags. Same slim-by-default content contract as base.

```text
def _build_evidence_data(self, app_id, assembly_line, step, *, include_content=False,
                         content_paths=None) -> dict:
    assert self._spec is not None                                      # disposition.py:1454

    def _build_file_entries(output_files) -> list[dict]:               # disposition.py:1456-1472
        entries = []
        for f in output_files:                                         # disposition.py:1458  LOOP
            if not isinstance(f, OutputFile):                          # disposition.py:1459  BRANCH
                continue                                               # disposition.py:1460  ← skip non-OutputFile
            content_str = f.content if isinstance(f.content, str) else ""  # disposition.py:1461  BRANCH
            entry = {"path": f.path, "encoding": f.encoding,
                     "size": len(content_str.encode("utf-8")) if content_str else 0}  # disposition.py:1462-1466  BRANCH
            if include_content or (content_paths is not None and f.path in content_paths):  # disposition.py:1467-1469  BRANCH
                entry["content"] = f.content                           # disposition.py:1470
            entries.append(entry)
        return entries

    steps = {}                                                         # disposition.py:1474
    all_steps = list(self._spec.pre_gate1_steps) + list(self._spec.post_gate1_steps)  # disposition.py:1475-1477
    # ---- LOOP: per agent StepSpec ----
    for step_spec in all_steps:                                        # disposition.py:1478
        artifacts    = self._step_results.get(step_spec.step, [])      # disposition.py:1479
        metadata     = self._agent_metadata.get(step_spec.step, {})    # disposition.py:1480
        output_files = metadata.get("output_files", [])                # disposition.py:1481
        raw_file_artifacts     = _build_file_entries(output_files)     # disposition.py:1482
        deduped_file_artifacts = list({f["path"]: f for f in raw_file_artifacts}.values())  # disposition.py:1483-1485
        steps[step_spec.step] = {                                      # disposition.py:1486-1494
            "skill_id": step_spec.skill_id,
            "artifact": step_spec.artifact,
            "output": artifacts[0] if artifacts else "",               # disposition.py:1489  BRANCH
            "metadata": {k: v for k, v in metadata.items() if k != "output_files"},  # disposition.py:1490-1492
            "file_artifacts": deduped_file_artifacts,
        }

    # ---- LOOP: inject the two synthetic bundle code-steps ----
    for code_step_id in (_BUNDLE_PRE_GATE_STEP, _BUNDLE_POST_GATE_STEP):  # disposition.py:1501
        code_meta = self._agent_metadata.get(code_step_id)             # disposition.py:1502
        if code_meta is None:                                          # disposition.py:1503  BRANCH
            continue                                                   # disposition.py:1504  ← skip if not yet bundled
        code_output_files   = code_meta.get("output_files", [])        # disposition.py:1505
        code_file_artifacts = _build_file_entries(code_output_files)   # disposition.py:1506
        steps[code_step_id] = {                                        # disposition.py:1507-1517
            "skill_id": "",
            "artifact": _DISPOSITION_OUTPUT_ARTIFACT,
            "output": "",
            "metadata": {k: v for k, v in code_meta.items() if k != "output_files"},  # disposition.py:1511-1515
            "file_artifacts": code_file_artifacts,
        }

    return {                                                           # disposition.py:1519-1525
        "assembly_line": assembly_line,
        "app_id": app_id,
        "current_step": step,
        "disposition": self._disposition_label,                        # ← ADDED vs base
        "steps": steps,
    }
```

**Branch inventory (6 + 3 loops):** inner `for f in output_files` (1458); `if not isinstance(f,
OutputFile): continue` (1459); `content_str = ... if isinstance(...) else ""` (1461); `entry["size"]
= ... if content_str else 0` (1466); `if include_content or (content_paths is not None and f.path in
content_paths)` (1467); outer `for step_spec in all_steps` (1478); `"output": artifacts[0] if
artifacts else ""` (1489); the bundle-step `for code_step_id in (...)` (1501); `if code_meta is None:
continue` (1503).

> ⚠️ **GOTCHA-EVID-DISPOSITION-KEY:** the returned dict carries a top-level **`"disposition"`** key
> (`disposition.py:1523`) that the base `_build_evidence_data` does NOT emit — WHY this override
> exists. A rebuild MUST include it.
> ⚠️ **GOTCHA-EVID-STEPSPEC-ITER:** this iterates `self._spec.pre_gate1_steps +
> self._spec.post_gate1_steps` directly (`disposition.py:1475-1478`) — NOT `STEPS.items()` / NOT
> `_evidence_steps_iter()`. Per-step entry uses `step_spec.skill_id` + `step_spec.artifact` directly
> (no `_evidence_step_metadata` hook). A rebuild MUST iterate the registry StepSpecs.
> ⚠️ **GOTCHA-EVID-BUNDLE-INJECT (the load-bearing part):** the two bundle code-steps are injected
> separately (`disposition.py:1496-1517`) so the G-DE-1 threshold predicates — which scan
> `steps[*].file_artifacts` — find the `g_de1_readiness` flags embedded in the
> `disposition-output.json` envelope (registered as the bundle step's synthetic `OutputFile`). Each
> injected step has `skill_id=""`, `artifact=_DISPOSITION_OUTPUT_ARTIFACT`, `output=""`. If
> `_agent_metadata[code_step_id]` is absent (bundle not yet run, e.g. at G-DE-1 the post-gate bundle
> step is missing), it is skipped via `if code_meta is None: continue`. A rebuild MUST inject both
> code-steps conditionally on their metadata presence. (This is how the slim/enriched evidence path
> in inherited `_submit_gate_evidence` — which calls THIS override — resolves the readiness flags
> for threshold checks.)
> ⚠️ **GOTCHA-EVID-SLIM-PARITY:** the inner `_build_file_entries` reproduces the base's slim-by-
> default + `include_content`/`content_paths` + utf-8-`size` + non-`OutputFile`-skip + dedup-by-path
> (last-wins) semantics (base GOTCHA-BE1..5) — but as a nested function rather than inline. A rebuild
> MUST keep the slim default and the content-scoping branch identical to base, since inherited
> `_submit_gate_evidence` calls this twice (slim for submit, content-scoped for `check_gate_criteria`).
> ⚠️ **GOTCHA-EVID-METADATA-STRIP:** per-step `metadata` strips the `output_files` key (both for
> agent steps at 1490-1492 and bundle steps at 1511-1515); those surface as `file_artifacts` instead.
> A rebuild MUST strip `output_files`.

---

## 11. Bundle / persist / signal helpers (code-steps)

### 11.1 `_bundle_pre_gate_evidence(...)` (`disposition.py:712-853`)

Synthesizes + commits the **partial** `disposition-output.json` envelope before G-DE-1, attaches a
`g_de1_readiness` block the gate threshold predicates consume, and registers the artifact under
`_BUNDLE_PRE_GATE_STEP` so evidence collection picks it up.

```text
async def _bundle_pre_gate_evidence(self, repo, branch, app_id, input, spec) -> None:
    pre_gate_step_names = {s.step for s in spec.pre_gate1_steps}        # disposition.py:745

    def _any_hint(hints) -> bool:                                      # disposition.py:747-751
        return any(any(hint in name for hint in hints) for name in pre_gate_step_names)

    _USER_TRANSITION_HINTS = ("user-transition","user-training","user-migration",
                              "change-mgmt","workflow-mapping")          # disposition.py:753-759
    _DATA_ARCHIVAL_HINTS   = ("data-archival","data-migration","data-reconciliation")  # disposition.py:760-764
    is_retain = self._disposition_label == "Retain"                     # disposition.py:765  BRANCH

    envelope = bundle_pre_gate_evidence(                                # disposition.py:767-777  (pure activity-module fn, called INLINE)
        app_id=app_id, app_name=input.app_name or app_id, portfolio_id=input.portfolio_id,
        wave_id=getattr(input, "wave_id", "") or "", disposition=self._disposition_label,
        step_committed_paths=self._step_committed_paths, started_at=self._started_at,
        approvals=list(self._bundle_approvals), now_iso=workflow.now().isoformat(),
    )
    envelope["g_de1_readiness"] = {                                     # disposition.py:781-793
        "stakeholder_sign_off": True,
        "user_transition_addressed": is_retain or _any_hint(_USER_TRANSITION_HINTS),  # BRANCH
        "data_archival_defined":    is_retain or _any_hint(_DATA_ARCHIVAL_HINTS),     # BRANCH
        "rollback_documented":      is_retain or spec.has_gate2,                       # BRANCH
        "pre_gate1_steps": sorted(pre_gate_step_names),
        "has_gate2": spec.has_gate2,
        "timestamp": workflow.now().isoformat(),
    }

    content = json.dumps(envelope, indent=2, sort_keys=True)            # disposition.py:795
    artifact_path = f"disposition/{self._disposition_label.lower()}/{app_id}/{_DISPOSITION_OUTPUT_ARTIFACT}"  # disposition.py:796-799

    # ---- BRANCH: patched batch vs single write ----
    if workflow.patched("disposition-batch-writes-v1"):                # disposition.py:800
        await workflow.execute_activity(write_artifacts_batch,
            WriteArtifactsBatchInput(repo, branch, files=[(artifact_path, content)],
                commit_message=f"disposition/{label.lower()}({app_id}): pre-gate evidence bundle"),  # disposition.py:801-811
            start_to_close_timeout=timedelta(seconds=120),
            retry_policy=RETRY_POLICIES["transient"],
            activity_id="commit-bundle-pre-gate-evidence")             # disposition.py:814
    else:
        await workflow.execute_activity(write_artifact,
            WriteArtifactInput(repo, branch, path=artifact_path, content=content,
                commit_message=f"disposition/{label.lower()}({app_id}): pre-gate evidence bundle"),  # disposition.py:817-828
            start_to_close_timeout=timedelta(seconds=60),
            retry_policy=RETRY_POLICIES["transient"],
            activity_id="commit-bundle-pre-gate-evidence")             # disposition.py:831
    self._disposition_output_ref = artifact_path                       # disposition.py:833

    self._step_committed_paths[_BUNDLE_PRE_GATE_STEP] = [artifact_path]  # disposition.py:839
    self._agent_metadata[_BUNDLE_PRE_GATE_STEP] = {                    # disposition.py:840-853
        "model_used": "deterministic", "duration_ms": 0,
        "token_usage_input": 0, "token_usage_output": 0, "cost_estimate_usd": 0.0,
        "output_files": [OutputFile(path=_DISPOSITION_OUTPUT_ARTIFACT, content=content, encoding="utf-8")],
    }
```

**Branch inventory (4 + the `_any_hint` comprehensions):** `is_retain = label=="Retain"` (765);
three `is_retain or ...` ORs feeding the readiness flags (783,786,789); `if
workflow.patched("disposition-batch-writes-v1")` else (800/816). Plus `getattr(input, "wave_id", "")
or ""` (771).

**Activity call:** ONE write (`write_artifacts_batch` patched / `write_artifact` unpatched) —
120s/60s; `transient`; `activity_id="commit-bundle-pre-gate-evidence"`.

> ⚠️ **GOTCHA-PREGATE-READINESS:** the four `g_de1_readiness` booleans are what the G-DE-1 threshold
> predicates (registered in `activities/gate_operations.py`) consume — they are embedded in the
> committed envelope so `_find_file_artifact` resolves them at gate-check time. `stakeholder_sign_off`
> is ALWAYS `True`. `user_transition_addressed` is `True` iff Retain OR any pre-gate step name
> contains a user-transition hint substring. `data_archival_defined` is `True` iff Retain OR any
> pre-gate step name contains a data-archival hint substring. `rollback_documented` is `True` iff
> Retain OR `spec.has_gate2`. ⚠️ The hint match is a SUBSTRING `in` check over step NAMES
> (`disposition.py:747-751`), not exact equality. A rebuild MUST reproduce the exact hint tuples and
> substring semantics — changing them changes whether G-DE-1 thresholds pass.
> ⚠️ **GOTCHA-PREGATE-INLINE (pure helper called in workflow code, NOT as activity):**
> `bundle_pre_gate_evidence` (the function imported from `activities/disposition_outputs.py`) is a
> **pure, side-effect-free** synthesis function invoked DIRECTLY in workflow code
> (`disposition.py:767`) — it is NOT `workflow.execute_activity`'d. This is deterministic-safe
> because it only reads `_step_committed_paths` + passed scalars. The ACTIVITY here is the
> `write_artifact(s_batch)` commit. A rebuild MUST call the synthesis inline (deterministic) and only
> the write as an activity.
> ⚠️ **GOTCHA-PREGATE-REGISTER (rework re-invokes; metadata is "deterministic"):** on a G-DE-1
> rework the whole Phase-1 loop re-runs, re-invoking this method so `_step_committed_paths` +
> `_agent_metadata[_BUNDLE_PRE_GATE_STEP]` reflect the LATEST bundle. The synthetic metadata uses
> `model_used="deterministic"`, all-zero usage, and an `OutputFile` carrying the FULL envelope
> content so `_build_evidence_data` and threshold predicates see it. A rebuild MUST register both maps
> with this exact synthetic shape.

### 11.2 `_bundle_post_gate_evidence(...)` (`disposition.py:855-944`)

Synthesizes + commits the **complete** envelope after all post-G-DE-1 steps (before G-DE-2). Same
structure as pre-gate but uses `bundle_post_gate_evidence`, sets `_disposition_output_json`, and
registers under `_BUNDLE_POST_GATE_STEP`. Does NOT add a `g_de1_readiness` block.

```text
async def _bundle_post_gate_evidence(self, repo, branch, app_id, input, spec) -> None:
    completed_at = workflow.now().isoformat()                          # disposition.py:871
    envelope = bundle_post_gate_evidence(                              # disposition.py:872-883  (pure fn INLINE)
        app_id=app_id, app_name=input.app_name or app_id, portfolio_id=input.portfolio_id,
        wave_id=getattr(input, "wave_id", "") or "", disposition=self._disposition_label,
        step_committed_paths=self._step_committed_paths, started_at=self._started_at,
        completed_at=completed_at, approvals=list(self._bundle_approvals), now_iso=completed_at,
    )
    content = json.dumps(envelope, indent=2, sort_keys=True)           # disposition.py:885
    artifact_path = f"disposition/{label.lower()}/{app_id}/{_DISPOSITION_OUTPUT_ARTIFACT}"  # disposition.py:886-889
    # ---- BRANCH: patched batch vs single write ---- (disposition.py:890 / 906)
    if workflow.patched("disposition-batch-writes-v1"):
        await workflow.execute_activity(write_artifacts_batch, ...,
            start_to_close_timeout=timedelta(seconds=120), retry_policy=RETRY_POLICIES["transient"],
            activity_id="commit-bundle-post-gate-evidence")           # disposition.py:891-905
    else:
        await workflow.execute_activity(write_artifact, ...,
            start_to_close_timeout=timedelta(seconds=60), retry_policy=RETRY_POLICIES["transient"],
            activity_id="commit-bundle-post-gate-evidence")           # disposition.py:907-922
    self._disposition_output_ref  = artifact_path                      # disposition.py:923
    self._disposition_output_json = content                            # disposition.py:928  ★ only set here

    self._step_committed_paths[_BUNDLE_POST_GATE_STEP] = [artifact_path]  # disposition.py:930
    self._agent_metadata[_BUNDLE_POST_GATE_STEP] = { ... "model_used":"deterministic" ... }  # disposition.py:931-944
```

**Branch inventory (1 + getattr):** `if workflow.patched("disposition-batch-writes-v1")` else
(890/906); `getattr(input, "wave_id", "") or ""` (876).

**Activity call:** ONE write — 120s/60s; `transient`; `activity_id="commit-bundle-post-gate-evidence"`.

> ⚠️ **GOTCHA-POSTGATE-JSON (snapshot for persist):** `_disposition_output_json = content`
> (`disposition.py:928`) is the ONLY place this var is set. `persist_disposition_side_effects` reads
> it so the DB projection doesn't need a Git read. Deterministic-safe (built from
> `_step_committed_paths` + `workflow.now()`). Retain never reaches here, so its
> `_disposition_output_json` stays `""`. A rebuild MUST set it here and only here.
> ⚠️ **GOTCHA-POSTGATE-RETAIN-GUARD:** the pure helper `bundle_post_gate_evidence` RAISES
> `ValueError` if `disposition == "Retain"` (`activities/disposition_outputs.py:451-456`). This
> method is never invoked for Retain (Phase-2 fork excludes it), so the guard never fires in
> practice — but a rebuild that mistakenly calls it for Retain would raise. Keep the guard.

### 11.3 `_emit_output_bundle` / `_build_output_bundle` / `_build_payload` (`disposition.py:490-710`)

`_emit_output_bundle` builds the P5-S13/W12 bundle dict and emits it via the
`emit_disposition_output_bundle` activity (which schema-validates + commits to the canonical
`dispositions/{portfolio}/{app}/disposition-output.json` path).

```text
async def _emit_output_bundle(self, input, spec, app_id, repo, branch) -> None:
    bundle = self._build_output_bundle(input, spec, app_id)            # disposition.py:506
    await workflow.execute_activity(
        emit_disposition_output_bundle,                                # disposition.py:507-508
        EmitDispositionOutputBundleInput(repo=repo, branch=branch, portfolio_id=input.portfolio_id,
                                         app_id=app_id, bundle=bundle),  # disposition.py:509-515
        start_to_close_timeout=timedelta(seconds=60),                  # disposition.py:516
        retry_policy=RETRY_POLICIES["transient"],                      # disposition.py:517
    )
```
No branches. **Activity:** `emit_disposition_output_bundle` — **60s**; `transient`.

⚠️ **GOTCHA-EMIT-SCHEMA (schema failure aborts the step deliberately):** schema validation happens
INSIDE the activity; a schema failure raises `NonRetryableError` (one attempt), which aborts the
workflow step (`disposition.py:498-505`, `activities/disposition_outputs.py:499-531`). That is the
correct behavior — silently emitting an invalid bundle would break downstream consumers. A rebuild
MUST let the schema failure propagate (do not swallow).

⚠️ **GOTCHA-EMIT-PATH (DIFFERENT path from the bundle helpers):** `emit_disposition_output_bundle`
commits to `dispositions/{portfolio_id}/{app_id}/disposition-output.json`
(`activities/disposition_outputs.py:534-535`) — a PLURAL `dispositions/` portfolio-scoped path.
The two bundle helpers (§11.1/11.2) commit to `disposition/{label}/{app_id}/disposition-output.json`
— a SINGULAR `disposition/` label-scoped path. These are TWO DIFFERENT FILES. A rebuild MUST keep
both paths distinct.

`_build_output_bundle` (`disposition.py:520-579`) assembles the envelope dict:
```text
def _build_output_bundle(self, input, spec, app_id) -> dict:
    def step_path(step_name):                                          # disposition.py:536-538
        paths = self._step_committed_paths.get(step_name, [])
        return paths[0] if paths else ""                              # BRANCH

    wave_id = getattr(input, "wave_id", "") or ""                      # disposition.py:540  BRANCH(getattr+or)
    baseline_ref               = f"rationalization/wave-{wave_id}/{app_id}/tco-analysis.json" if wave_id else ""  # disposition.py:541-545  BRANCH
    disposition_decision_ref   = f"rationalization/wave-{wave_id}/{app_id}/disposition-recommendation.json" if wave_id else ""  # disposition.py:546-550  BRANCH
    user_impact_ref            = f"rationalization/wave-{wave_id}/{app_id}/user-impact-analysis.json" if wave_id else ""  # disposition.py:551-555  BRANCH

    envelope = {                                                       # disposition.py:557-578
        "application_id": app_id,
        "application_name": input.app_name or app_id,                  # BRANCH(or)
        "portfolio_id": input.portfolio_id,
        "wave_id": wave_id,
        "disposition": spec.label,
        "status": "completed",
        "started_at": self._started_at,
        "completed_at": _now_iso(),
        "disposition_decision_ref": disposition_decision_ref,
        "approvals": list(self._bundle_approvals),
        "realized_net_impact": {
            "tco_delta": {"annual_savings_usd": None, "one_time_cost_usd": None,
                          "baseline_ref": baseline_ref or None},       # BRANCH(or None)
            "users_affected_actual": None,
            "users_affected_estimate_ref": user_impact_ref or None,    # BRANCH(or None)
        },
        "payload": self._build_payload(spec, app_id, step_path),       # disposition.py:577
    }
    return envelope
```
**Branch inventory (≈7):** `paths[0] if paths else ""` (538); `getattr(...) or ""` (540); three
`... if wave_id else ""` ternaries (541-555); `input.app_name or app_id` (559); `baseline_ref or
None` (572); `user_impact_ref or None` (576).

`_build_payload` (`disposition.py:581-710`) — **dispatch on `spec.label`** to build the typed
payload. Each branch returns a fully-shaped dict (reproduced verbatim in source; structure summarized
here — a rebuild MUST emit the exact key set per label):
```text
def _build_payload(self, spec, app_id, step_path) -> dict:
    label = spec.label                                                 # disposition.py:588
    if label == "Retire":      return { ...decommission_certificate_ref (step_path("infrastructure-decommission") or f"disposition/{app_id}/decommission-certificate.json"),
                                          archival{reconstruction_plan_ref, data_archival_plan_ref = step_path("data-archival-plan")},
                                          consumer_migration{...migration_report_ref=step_path("consumer-migration")},
                                          license_reclamation_ref=step_path("license-reclamation"), infrastructure_torn_down=[] }  # disposition.py:589-607  BRANCH
    if label == "Retain":      return { retain_reason, remediation_outcome{security_remediation_ref, documentation_updates_ref, monitoring_setup_ref},
                                          sustainment_handoff{owner_team:"sustainment", handoff_confirmed_at=_now_iso(), handoff_ref=step_path("sustainment-handoff")},
                                          re_evaluation_triggers:["annual review"] }  # disposition.py:608-632  BRANCH
    if label == "Replace":     return { selected_vendor{name:"TBD", product_version:"TBD", vendor_evaluation_ref},
                                          integration{integration_spec_ref, cutover_plan_ref = step_path("integration-specification")},
                                          data_migration{records_migrated:0, reconciliation_pass:False, migration_ref},
                                          legacy_decommission_ref=step_path("legacy-decommission") }  # disposition.py:633-653  BRANCH
    if label == "Replatform":  return { target_platform{name:"TBD", platform_selection_ref}, workflow_mapping_ref, component_configuration_ref,
                                          data_migration{...}, validation_cutover_ref, legacy_decommission_ref,
                                          perf_delta{latency_p95_before_ms:None, latency_p95_after_ms:None, source:"parallel-run-monitor"},
                                          cost_delta{monthly_before_usd:None, monthly_after_usd:None} }  # disposition.py:654-681  BRANCH
    if label == "Consolidate": return { target_application{id:"00000000-0000-0000-0000-000000000000", name:"TBD", target_selection_ref},
                                          feature_gap_analysis_ref, features_ported:0, features_dropped:[], enhancement_plan_ref,
                                          data_reconciliation{records_merged:0, conflicts_resolved:0, reconciliation_ref},
                                          user_migration_ref, absorbed_decommission_ref }  # disposition.py:682-705  BRANCH
    raise ValueError(f"Unsupported disposition label for DispositionWorkflow bundle: {label!r}")  # disposition.py:707-710  BRANCH (Refactor/Rearchitect)
```
**Branch inventory (6):** 5 `if label == "..."` returns (589,608,633,654,682) + the terminal `raise
ValueError` (707).

> ⚠️ **GOTCHA-PAYLOAD-PARALLEL:** `_build_payload` (workflow method, used by `_emit_output_bundle`)
> and `_build_payload` (module function in `activities/disposition_outputs.py`, used by the
> pre/post-gate helpers) are TWO separate but largely parallel implementations of the same
> per-disposition payload shapes. The activity-module version threads an `include_post_gate` flag to
> blank post-gate refs pre-G-DE-1; the workflow-method version always fills all refs (it only runs
> AFTER the last gate). A rebuild MUST reproduce BOTH and keep the per-label key sets identical to
> source — divergence breaks the `disposition-output.schema.json` validation in
> `emit_disposition_output_bundle`.
> ⚠️ **GOTCHA-PAYLOAD-RETIRE-FALLBACK:** Retire's `decommission_certificate_ref` falls back to
> `f"disposition/{app_id}/decommission-certificate.json"` when `step_path("infrastructure-decommission")`
> is empty (`disposition.py:592-594`). The other label refs do NOT have fallbacks (empty string when
> the step has no committed path). A rebuild MUST reproduce this single Retire-specific fallback.

### 11.4 `_persist_disposition_side_effects(...)` (`disposition.py:946-974`)

```text
async def _persist_disposition_side_effects(self, *, app_id, spec, terminal_status) -> None:
    output_ref  = getattr(self, "_disposition_output_ref", "")         # disposition.py:959
    output_json = getattr(self, "_disposition_output_json", "")        # disposition.py:960
    await workflow.execute_activity(
        persist_disposition_side_effects,                              # disposition.py:961-962
        PersistDispositionSideEffectsInput(
            app_id=app_id, disposition=self._disposition_label,
            disposition_output_ref=output_ref, disposition_output_json=output_json,
            disposition_current_status=terminal_status,
            completed_at=workflow.now().isoformat()),                  # disposition.py:963-970
        start_to_close_timeout=timedelta(seconds=60),                  # disposition.py:971
        retry_policy=RETRY_POLICIES["transient"],                      # disposition.py:972
        activity_id="persist-disposition-side-effects",                # disposition.py:973
    )
```
No control branches (the `getattr(..., "")` defaults are defensive reads). **Activity:**
`persist_disposition_side_effects` — **60s**; `transient`; `activity_id="persist-disposition-side-effects"`.

⚠️ **GOTCHA-PERSIST-BESTEFFORT:** the docstring (`disposition.py:953-957`) notes the bundle is the
source of truth and the DB row is a derived cache; the underlying activity swallows DB blips, so this
wrapper adds NO extra retries and does NOT try/except (it relies on the activity's own resilience +
the `transient` policy). `terminal_status` is always `"disposition_complete"` from both call sites
(Retain at 392, non-Retain at 463). A rebuild MUST pass the snapshot `_disposition_output_ref` +
`_disposition_output_json` (empty for Retain) and NOT wrap in try/except.

### 11.5 `_fire_disposition_executed_signal(...)` (`disposition.py:976-1027`)

Fires `DispositionExecutedSignal` to the peer Deployment workflow — **non-Retain only**, best-effort.

```text
async def _fire_disposition_executed_signal(self, *, input, app_id, spec) -> None:
    # ---- BRANCH 1: Retain never fires ----
    if self._disposition_label == "Retain":                            # disposition.py:994
        return                                                         # disposition.py:995

    deployment_wf_id = ""                                              # disposition.py:997
    # ---- BRANCH 2: read peer id defensively ----
    try:
        deployment_wf_id = input.peer_workflow_ids.get("Deployment", "")  # disposition.py:999
    except AttributeError:                                             # disposition.py:1000
        deployment_wf_id = ""                                          # disposition.py:1001

    # ---- BRANCH 3: no peer → skip silently ----
    if not deployment_wf_id:                                           # disposition.py:1003
        workflow.logger.info("disposition-executed signal skipped — no peer Deployment workflow id on input")  # disposition.py:1004-1007
        return                                                         # disposition.py:1008

    payload = DispositionExecutedSignal(                               # disposition.py:1010-1018
        app_id=app_id, disposition=self._disposition_label,
        disposition_output_ref=getattr(self, "_disposition_output_ref", ""),
        portfolio_id=input.portfolio_id, executed_at=workflow.now().isoformat(),
    )
    # ---- BRANCH 4: signal external workflow, best-effort ----
    try:
        handle = workflow.get_external_workflow_handle(deployment_wf_id)  # disposition.py:1020
        await handle.signal("disposition_executed", payload)           # disposition.py:1021
    except Exception as exc:                                           # disposition.py:1022  best-effort
        workflow.logger.warning("disposition-executed signal failed — Deployment workflow may not yet be started: %s", exc)  # disposition.py:1023-1027
```

**Branch inventory (4):** B1 `if label=="Retain"` (994); B2 try/except AttributeError (999/1000);
B3 `if not deployment_wf_id` (1003); B4 try/except on the external signal (1022).

> ⚠️ **GOTCHA-SIGNAL-RETAIN:** Retain returns immediately without firing (`disposition.py:994-995`)
> — its Sustainment handoff is state-based. Only Retire/Replace/Replatform/Consolidate emit. A
> rebuild MUST gate on `label == "Retain"`.
> ⚠️ **GOTCHA-SIGNAL-BESTEFFORT:** BOTH the peer-id read (`AttributeError` → `""`, for unit-test /
> standalone inputs missing `peer_workflow_ids`) AND the cross-workflow signal send (`Exception` →
> log+continue, for Deployment not-yet-started) are best-effort. A missing peer id is logged at INFO
> and skipped; a send failure is logged at WARNING and swallowed. Neither fails the workflow. A
> rebuild MUST swallow both. The wire signal name is the literal `"disposition_executed"`
> (`disposition.py:1021`) — matches Deployment's `@workflow.signal disposition_executed`.

---

## 12. `_run_gate(...)` — single-gate orchestration (`disposition.py:1073-1188`) ★★ GATE ROUTING

The reusable per-gate routine: announce sub-steps, open PR, create gate record, submit evidence, run
AI pre-review, wait for decision, and on approval merge + record the approval. Returns
`"approved"` / `"rejected"` / `"cancelled"`.

```text
async def _run_gate(self, input, repo, branch, app_id, gate_type, gate_step, evidence_steps,
                    title, body_builder, *, create_pr_step="", pre_review_step="", merge_pr_step="") -> str:
    # ---- assemble evidence paths from the named steps ----
    evidence_paths = []                                                # disposition.py:1100
    for step_name in evidence_steps:                                   # disposition.py:1101  LOOP
        evidence_paths.extend(self._step_committed_paths.get(step_name, []))  # disposition.py:1102-1104
    evidence_paths = dedup_paths(evidence_paths)                       # disposition.py:1105

    # ---- BRANCH 1: announce create-PR sub-step if named ----
    if create_pr_step:                                                 # disposition.py:1107
        await self._set_step(create_pr_step, self._progress_pct)       # disposition.py:1108
    pr_result = await self._create_gate_pr(                            # disposition.py:1109-1114
        repo, branch, app_id, gate_type=gate_type.value, title=title, body=body_builder(app_id),
    )

    gate_record = await workflow.execute_activity(                     # disposition.py:1116-1127
        create_gate_record,
        CreateGateRecordInput(gate_type=gate_type.value, app_id=app_id, portfolio_id=input.portfolio_id,
                              workflow_id=workflow.info().workflow_id, evidence_package_url=pr_result.pr_url),
        start_to_close_timeout=timedelta(seconds=30),
        retry_policy=RETRY_POLICIES["transient"],
    )

    await self._submit_gate_evidence(                                  # disposition.py:1129-1138  (INHERITED)
        gate_id=gate_record.gate_id, gate_type=gate_type, app_id=app_id,
        artifact_paths=evidence_paths, pr_url=pr_result.pr_url,
        assembly_line="Disposition Execution", step=gate_step, forward_risk_tier=False,
    )

    # ---- BRANCH 2: announce pre-review sub-step if named ----
    if pre_review_step:                                                # disposition.py:1143
        await self._set_step(pre_review_step, self._progress_pct)      # disposition.py:1144
    await self._run_gate_pre_review(                                   # disposition.py:1145-1151  (INHERITED, advisory)
        gate_record.gate_id, gate_type.value, evidence_paths, artifact_repo=repo, artifact_ref=branch,
    )

    await self._set_step(gate_step, self._progress_pct)                # disposition.py:1153

    decision = await self._wait_for_gate_decision(gate_type)           # disposition.py:1155  (INHERITED ★)
    # ---- BRANCH 3: cancelled ----
    if decision == "cancelled":                                        # disposition.py:1156
        return "cancelled"                                             # disposition.py:1157

    # ---- BRANCH 4: approved → merge + record approval ----
    if decision == "approved":                                         # disposition.py:1159
        # ---- BRANCH 5: announce merge sub-step if named ----
        if merge_pr_step:                                              # disposition.py:1160
            await self._set_step(merge_pr_step, self._progress_pct)    # disposition.py:1161
        await self._reconcile_and_merge_with_retry_loop(               # disposition.py:1163-1168  (INHERITED ★ merge_blocked loop)
            repo=repo, pr_number=pr_result.pr_number, gate_id=gate_record.gate_id, merge_method="merge",
        )
        # ---- BRANCH 6: approver from last gate decision ----
        approver = (self._gate_decisions[-1][1] if self._gate_decisions else "unknown")  # disposition.py:1174-1178
        self._bundle_approvals.append({                                # disposition.py:1179-1186
            "gate": gate_type.value,
            "approved_at": _now_iso(),
            "approved_by": approver,
            "record_ref": f"gates/{gate_record.gate_id}/decision.json",
        })
        return "approved"                                              # disposition.py:1187
    return "rejected"                                                  # disposition.py:1188
```

**Branch inventory (6 + 1 loop):** LOOP `for step_name in evidence_steps` (1101); B1 `if
create_pr_step` (1107); B2 `if pre_review_step` (1143); B3 `if decision == "cancelled"` (1156); B4
`if decision == "approved"` (1159); B5 `if merge_pr_step` (1160); B6 `approver = ... if
self._gate_decisions else "unknown"` (1174-1178).

**Activity / inherited calls (in strict order):**
1. (opt) `_set_step(create_pr_step)` — local.
2. `_create_gate_pr` → `create_pr` activity (override §10) — **60s**; `transient`; 4 labels.
3. `create_gate_record` — `CreateGateRecordInput` (gate_type.value, app_id, portfolio_id,
   workflow_id, evidence_package_url=pr_url); **30s**; `transient`.
4. `_submit_gate_evidence` (INHERITED) — with **`forward_risk_tier=False`** → builds slim evidence,
   omits `evidence_data`+`risk_tier` on the `check_gate_criteria` input (base GOTCHA-SE2);
   `assembly_line="Disposition Execution"`, `step=gate_step`. Internally runs `check_gate_criteria`
   (60s/transient) + `submit_gate_evidence` (60s/transient).
5. (opt) `_set_step(pre_review_step)` — local.
6. `_run_gate_pre_review` (INHERITED, advisory/best-effort) — dispatches `gate-pre-review` (10m),
   stores result (30s), `finally` patch-gated `mark_gate_ready_for_review` (30s). NEVER fatal.
7. `_set_step(gate_step)` — local; sets the gate-review step.
8. `_wait_for_gate_decision(gate_type)` (INHERITED ★) — sets `WAITING_FOR_SIGNAL`+`_pending_gate`,
   blocks on `len(_gate_decisions) > consumed or cancelled`, returns `"approved"`/`"rejected"`/`"cancelled"`,
   manages `_rework_feedback` (pop on approve / set on reject).
9. (approved only) `_reconcile_and_merge_with_retry_loop` (INHERITED ★) — merges PR with
   **`git_merge`** policy; on structured merge error → `set_gate_merge_blocked` + wait for
   `merge_retry` signal; loops; returns on cancel.

> ⚠️ **GOTCHA-GATE-FRT (forward_risk_tier=False — distinct call shape):** Disposition calls
> `_submit_gate_evidence(..., forward_risk_tier=False)` (`disposition.py:1137`). Per base GOTCHA-SE2
> this builds the `check_gate_criteria` input WITHOUT `evidence_data` and WITHOUT `risk_tier` —
> Disposition does not forward a risk tier to its gate checks (it never sets `_risk_tier` from input).
> A rebuild MUST pass `forward_risk_tier=False` for both G-DE-1 and G-DE-2.
> ⚠️ **GOTCHA-GATE-MERGEMETHOD:** merge uses `merge_method="merge"` (`disposition.py:1167`) — a
> merge commit, not squash/rebase. A rebuild MUST pass `"merge"`.
> ⚠️ **GOTCHA-GATE-APPROVER (records the LAST decision's actor):** after the merge succeeds, the
> approver is taken from `self._gate_decisions[-1][1]` (index 1 = actor) — the MOST RECENT decision
> tuple, falling back to `"unknown"` if the list is somehow empty (`disposition.py:1174-1178`). This
> is appended to `_bundle_approvals` with `gate=gate_type.value`, `approved_at=_now_iso()`,
> `record_ref="gates/{gate_id}/decision.json"`. ⚠️ It reads `[-1]` (last), which is the decision
> JUST consumed by `_wait_for_gate_decision` (the cursor advanced past it but it remains in the list).
> A rebuild MUST read the LAST tuple's index-1 actor, not search by gate. This `_bundle_approvals`
> list is what the terminal bundle's `approvals` array cites (so the bundle records who approved each
> gate without re-reading Git).
> ⚠️ **GOTCHA-GATE-NOMERGE-ON-REJECT:** the final `return "rejected"` (`disposition.py:1188`) is the
> fall-through when `decision` is neither `"cancelled"` nor `"approved"` (i.e. `"rejected"`). On
> reject NO merge happens, NO approval is recorded — control returns to the caller's rework loop. A
> rebuild MUST NOT merge or record approval on the reject path.
> ⚠️ **GOTCHA-GATE-SUBSTEP-PROGRESS:** all the optional sub-step announcements (`create_pr_step`,
> `pre_review_step`, `merge_pr_step`) AND the `gate_step` announcement pass `self._progress_pct`
> UNCHANGED as the progress arg (`disposition.py:1108,1144,1153,1161`) — they only change
> `_current_step`, not the percentage, so the stepper reflects the 12-step shape without moving the
> progress bar during the gate. A rebuild MUST pass the current `_progress_pct` for these.

---

## 13. `_complete` / `_fail` (`disposition.py:478-488`, `1190-1199`)

### 13.1 `_complete(app_id)` (`disposition.py:478-488`)
```text
async def _complete(self, app_id) -> str:
    await self._update_app_status(app_id, "disposition_complete", "completed", "Disposition Execution")  # disposition.py:480-483
    self._status       = WorkflowStatus.COMPLETED                      # disposition.py:484
    self._progress_pct = 100.0                                         # disposition.py:485
    self._current_step = "completed"                                   # disposition.py:486
    self._updated_at   = _now_iso()                                    # disposition.py:487
    return "completed"                                                 # disposition.py:488
```
No branches. Pushes DB status `disposition_complete`, sets COMPLETED + 100% + step `"completed"`,
returns `"completed"`.

### 13.2 `_fail(reason_step, app_id)` (`disposition.py:1190-1199`)
```text
async def _fail(self, reason_step, app_id) -> str:
    self._status       = WorkflowStatus.FAILED                         # disposition.py:1192
    self._current_step = reason_step                                   # disposition.py:1193
    self._updated_at   = _now_iso()                                    # disposition.py:1194
    await self._update_app_status(app_id, "disposition_failed", reason_step, "Disposition Execution")  # disposition.py:1195-1198
    return "failed"                                                    # disposition.py:1199
```
No branches. Sets FAILED + `_current_step=reason_step`, pushes DB `disposition_failed` (with
`current_step=reason_step`), returns `"failed"`.

⚠️ **GOTCHA-FAIL-VS-RAISE:** `_fail` returns the STRING `"failed"` and does NOT raise — used by the
two early-validation cases (modernization-reject, missing-disposition) and the two
max-rework-exceeded cases. This is DISTINCT from `run`'s outer `except` (§5) which sets FAILED, does
a best-effort DB push, and RE-RAISES (Temporal workflow failure). A rebuild MUST keep both terminal
shapes: graceful `"failed"` return for the four known-failure cases; re-raise for unexpected
exceptions.

---

## 14. PR body builders (`disposition.py:1531-1591`)

### 14.1 `_build_gde1_pr_body(app_id)` (`disposition.py:1531-1560`)
```text
def _build_gde1_pr_body(self, app_id) -> str:
    assert self._spec is not None                                      # disposition.py:1533
    step_list     = "\n".join(f"- [x] {s.step} ({s.skill_id})" for s in self._spec.pre_gate1_steps)  # disposition.py:1534-1537
    artifact_list = "\n".join(f"- `disposition/{label.lower()}/{app_id}/{s.artifact}`" for s in self._spec.pre_gate1_steps)  # disposition.py:1538-1542
    rework_iter   = self._rework_count("G-DE-1")                       # disposition.py:1543
    body = (... "## Gate G-DE-1 Review: {title_label} Execution Plan Approval ..."
            "### Review Checklist (Stakeholder + Portfolio Manager) ...")  # disposition.py:1544-1557
    # ---- BRANCH: append rework iteration line if > 0 ----
    if rework_iter > 0:                                                # disposition.py:1558
        body += f"\n**Rework iteration:** {rework_iter}\n"             # disposition.py:1559
    return body                                                        # disposition.py:1560
```
**Branch inventory (1):** `if rework_iter > 0` (1558). Checklist items: evidence trail from
Rationalization / user impact reviewed / stakeholder sign-off / timeline aligned / dependencies
coordinated.

### 14.2 `_build_gde2_pr_body(app_id)` (`disposition.py:1562-1591`)
Mirror of 14.1 but over `post_gate1_steps` and the G-DE-2 title/checklist (data archived / consumers
migrated / user transition complete / rollback window / security decommission docs). Same `if
rework_iter > 0` branch using `_rework_count("G-DE-2")` (`disposition.py:1574,1589-1590`).

**Branch inventory (1):** `if rework_iter > 0` (1589).

⚠️ **GOTCHA-PRBODY:** these are pure string builders (no `workflow.now()`, no I/O) — deterministic.
The artifact list embeds `disposition/{label.lower()}/{app_id}/{artifact}` (the per-label path).
`rework_iter` comes from `_rework_count`, so on a rework the PR body shows the current iteration. A
rebuild MUST reproduce the exact markdown structure (the gate service / dashboard render it) and the
conditional rework line.

---

## 15. `_disposition_str(disposition)` module function (`disposition.py:1594-1604`)
```text
def _disposition_str(disposition) -> str:
    if disposition is None:                                            # disposition.py:1601  BRANCH 1
        return ""                                                      # disposition.py:1602
    if isinstance(disposition, Disposition):                          # disposition.py:1602  BRANCH 2
        return disposition.value                                       # disposition.py:1603
    return str(disposition)                                           # disposition.py:1604
```
**Branch inventory (2):** `if disposition is None` (1601); `if isinstance(disposition, Disposition)`
(1602).

⚠️ **GOTCHA-DISPSTR (enum round-trip tolerance):** Temporal may round-trip the `Disposition` enum as
its raw string `value` after serialization, so this accepts BOTH the enum and a raw string
(`disposition.py:1595-1599`). `None` → `""` (which then fails the registry lookup →
`missing-disposition`). A rebuild MUST accept both forms; reading `.value` only when it is the enum.

---

## 16. ACTIVITY & CHILD-WORKFLOW CALL INVENTORY (complete, in execution order)

No child workflows are spawned. One external-workflow signal is sent. All activities:

| # | Activity | Where | args | timeout | retry policy | activity_id | notes |
|---|----------|-------|------|---------|--------------|-------------|-------|
| via base | `update_application_status` | `_set_step`, `_complete`, `_fail`, `run` except | `UpdateAppStatusInput` | 30s | `transient` | — | inherited |
| per step | `dispatch_agent_task` | `_dispatch_agent_step` | `AgentTaskInput` | **1h** | `agent_failure` | `agent-{step}` | label in task_type |
| per step | `write_artifacts_batch` OR `write_artifact`(+per-file) | `_commit_step_artifacts_spec` | batch/single | 120s/60s | `transient` | `commit-{step}` | patch-gated |
| per step (opt) | `update_agent_task_output_ref` | `_commit_step_artifacts_spec` | positional `args=[app_id, "disposition-{label}-{step}", path]` | 30s | `transient` | `patch-output-ref-{step}` | patch-gated, try/except…pass |
| pre G-DE-1 | `write_artifacts_batch` OR `write_artifact` | `_bundle_pre_gate_evidence` | single file | 120s/60s | `transient` | `commit-bundle-pre-gate-evidence` | patch-gated |
| pre G-DE-2 | `write_artifacts_batch` OR `write_artifact` | `_bundle_post_gate_evidence` | single file | 120s/60s | `transient` | `commit-bundle-post-gate-evidence` | patch-gated |
| each gate | `create_pr` | `_create_gate_pr` (override) | `CreatePRInput` (4 labels) | 60s | `transient` | — | targets main |
| each gate | `create_gate_record` | `_run_gate` | `CreateGateRecordInput` | 30s | `transient` | — | — |
| each gate (base) | `check_gate_criteria` | `_submit_gate_evidence` | `CheckGateCriteriaInput` (no risk_tier/evidence_data; forward_risk_tier=False) | 60s | `transient` | — | inherited |
| each gate (base) | `submit_gate_evidence` | `_submit_gate_evidence` | `SubmitGateEvidenceInput` (slim) | 60s | `transient` | — | inherited |
| each gate (base) | `dispatch_agent_task` (gate-pre-review) | `_run_gate_pre_review` | `AgentTaskInput` | 10m | `transient` | — | advisory, try/except |
| each gate (base) | `store_gate_pre_review` | `_run_gate_pre_review` | `StoreGatePreReviewInput` | 30s | `transient` | — | only if markdown non-empty |
| each gate (base) | `mark_gate_ready_for_review` | `_run_gate_pre_review` finally | positional `gate_id` | 30s | `transient` | — | patch-gated, in finally |
| each gate→approve (base) | `reconcile_and_merge_pr` | `_reconcile_and_merge_with_retry_loop` | `MergePRInput` (merge_method="merge") | 60s | **`git_merge`** | — | non_retryable merge errors |
| each gate→approve (base) | `set_gate_merge_blocked` | merge loop on structured error | positional `args=[gate_id, detail]` | 30s | `transient` | — | then wait for merge_retry |
| terminal | `emit_disposition_output_bundle` | `_emit_output_bundle` | `EmitDispositionOutputBundleInput` | 60s | `transient` | — | schema-validates, NonRetryable on fail |
| terminal | `persist_disposition_side_effects` | `_persist_disposition_side_effects` | `PersistDispositionSideEffectsInput` | 60s | `transient` | `persist-disposition-side-effects` | best-effort in activity |
| terminal signal | (external) `handle.signal("disposition_executed", payload)` | `_fire_disposition_executed_signal` | `DispositionExecutedSignal` | — | — | — | non-Retain only, try/except |

All agent step dispatches and commits are **sequential** within a phase (the `for step_spec in
spec.pre/post_gate1_steps` loops `await` each step before the next). There is **no `asyncio.gather`
/ no parallel fan-out** in this workflow. A rebuild MUST run steps strictly sequentially.

---

## 17. RESILIENCE summary

- **Timeouts (start_to_close):** dispatch_agent_task 1h; commit batch 120s / single 60s; bundle
  commits 120s/60s; output-ref patch 30s; status update 30s; create_pr 60s; create_gate_record 30s;
  check/submit evidence 60s each; pre-review dispatch 10m; store pre-review 30s; ready-flip 30s;
  reconcile_and_merge 60s; set_gate_merge_blocked 30s; emit_output_bundle 60s; persist 60s.
- **Heartbeats:** none configured here (relies on start_to_close).
- **continue-as-new:** none. The workflow can block indefinitely in `_wait_for_gate_decision` and in
  the `merge_blocked` wait — both drain on `cancelled`.
- **Idempotency:** deterministic `activity_id`s (`agent-{step}`, `commit-{step}`,
  `patch-output-ref-{step}`, `commit-bundle-pre-gate-evidence`, `commit-bundle-post-gate-evidence`,
  `persist-disposition-side-effects`) make those activities replay-stable. `_now_iso()` /
  `workflow.now()` are deterministic. Registry lookup is read-only/import-time → replay-safe.
  ⚠️ The gate-cycle activities `create_pr` / `create_gate_record` / `check_gate_criteria` /
  `submit_gate_evidence` / `reconcile_and_merge_pr` have **no** explicit `activity_id` — they rely on
  Temporal's default command-ordering for replay stability.
- **Compensation / rollback:** NONE — there is no rollback path. Failure semantics:
  - Early-validation failures (modernization-reject, unknown disposition) → graceful `_fail` →
    `"failed"` string + DB `disposition_failed`.
  - Rework exhaustion (count > `spec.max_rework_iterations`) → graceful `_fail` →
    `"max-rework-exceeded-gde1"`/`"-gde2"` + DB `disposition_failed`.
  - Cancel (`cancelled=True`) → `_wait_for_gate_decision` / merge wait return `"cancelled"` →
    `_execute` returns `"cancelled"` (NO DB status push to a cancelled state; the workflow just
    returns the string).
  - Unexpected exception inside `_execute` → `run` outer `except` sets FAILED + best-effort DB
    `disposition_failed` + RE-RAISES (Temporal workflow failure).
  - Best-effort activities that swallow failures: output-ref patch (try/except…pass), the
    cross-workflow signal (try/except log), the peer-id read (AttributeError → ""), `_run_gate_pre_review`
    (entire body best-effort), `persist_disposition_side_effects` (activity-internal).
  - Structured merge errors route to `merge_blocked` + reviewer `merge_retry` (inherited loop).

---

## 18. Behavioral parity checklist

A rebuilt `DispositionWorkflow` MUST satisfy ALL of the following:

1. **Inheritance/decoration:** `@workflow.defn class DispositionWorkflow(LineWorkflowBase)`; `__init__`
   calls `super().__init__()` first, then sets `_spec=None`, `_disposition_label=""`,
   `_bundle_approvals=[]`, `_disposition_output_ref=""`, `_disposition_output_json=""`. Classvars:
   `ASSEMBLY_LINE=DISPOSITION_EXECUTION`, `ARTIFACT_ROOT="disposition"`, `LINE_LABEL="Disposition
   Execution"`, `STATUS_PREFIX="disposition"`; `STEPS`/`STEP_WEIGHTS`/`SINGLE_GATE_KEY` unset.
2. **Disposition resolution:** `run` rejects `{"Refactor","Rearchitect"}` via
   `_fail("unsupported-disposition-{lower}")` BEFORE registry lookup; resolves via
   `DISPOSITION_REGISTRY.get(label)` catching `UnknownDispositionError` →
   `_fail("missing-disposition")`. (GOTCHA-RUN1/RUN2)
3. **Branch/workspace naming:** `branch="olympus/disposition/{label.lower()}/{app_id}/{run_suffix}"`;
   `workspace_key="disposition-{label.lower()}-{app_id}-{run_suffix}"`; `run_suffix = wf_id after
   last "-" else wf_id[:8]`. (GOTCHA-RUN3)
4. **Outer failure handling:** `run`'s `try/except Exception` around `_execute` sets FAILED +
   `_current_step="failed"`, best-effort `_update_app_status(..., "disposition_failed", "failed", ...)`
   in nested try/except…pass, then **re-raises**. (GOTCHA-RUN4)
5. **Progress math:** `gate_count = 2 if has_gate2 else 1`; `per_step_weight = (100 -
   10*gate_count)/max(total_steps,1)`; gates worth 10% each; Phase-2 cumulative starts at
   `len(pre_gate1_steps)*per_step_weight + 10.0`. (GOTCHA-EXEC-WEIGHT/CUMULATIVE)
6. **Phase 1 loop:** `while True`: run each `pre_gate1_steps` step (set_step + run_step,
   cumulative += weight); `_bundle_pre_gate_evidence`; `_run_gate(G_DE_1, ...)`; on `"cancelled"`
   return `"cancelled"`; on `"rejected"` `_bump_rework("G-DE-1")`, if count >
   `spec.max_rework_iterations` `_fail("max-rework-exceeded-gde1")` else `continue`; else `break`.
7. **Retain fork:** `if not spec.has_gate2:` → `_emit_output_bundle` → `_set_step(persist, 99.0)` →
   `_persist_disposition_side_effects(terminal_status="disposition_complete")` → `_complete`. Retain
   does NOT run Phase 2 and does NOT fire `DispositionExecutedSignal`. (GOTCHA-RETAIN-TERMINAL)
8. **Phase 2 loop:** `while True`: run each `post_gate1_steps` step; `_bundle_post_gate_evidence`;
   `_run_gate(G_DE_2, ...)`; cancel/reject handling mirrors Phase 1 with `"G-DE-2"` /
   `"max-rework-exceeded-gde2"`; else `break`.
9. **Terminal (non-Retain):** after Phase 2 break → `_emit_output_bundle` → `_set_step(persist,
   99.0)` → `_persist_disposition_side_effects("disposition_complete")` →
   `_fire_disposition_executed_signal` → `_complete`. (GOTCHA-EXEC-DOUBLE-BUNDLE)
10. **Rework counter:** bumped by the SUBCLASS on `"rejected"` (NOT by `_wait_for_gate_decision`);
    ceiling is `spec.max_rework_iterations` (NOT the module `MAX_REWORK_ITERATIONS`); strict `>`;
    bump BEFORE compare; 4th rejection at default 3 → fail. (GOTCHA-REWORK-LOOP)
11. **`stakeholder_approved` signal:** additive `@workflow.signal` (NOT a base redefinition);
    appends 5-tuple `(APPROVED, signal.approved_by, signal.justification, None, [])` and bumps
    `_updated_at`. MUST read `approved_by`/`justification` off the payload (GOTCHA-SH1), no gate
    guard (GOTCHA-SH3).
12. **`_dispatch_agent_step`:** routes rework feedback by phase (`step_spec in
    self._spec.pre_gate1_steps` → "G-DE-1" else "G-DE-2"); attaches `context["rework_feedback"]`
    only if present; `task_type="disposition-{label.lower()}-{step}"`; NO context-priors, NO
    execution_context; `dispatch_agent_task` 1h/`agent_failure`/`activity_id="agent-{step}"`; records
    6-field `_agent_metadata[step]`. (GOTCHA-DISP1..4)
13. **`_run_step`:** computes `_inputs_for_step`, dispatches, sets `self._step_results[step] =
    result.output_artifacts`, computes artifact_path `disposition/{label.lower()}/{app_id}/{artifact}`,
    commits via `_commit_step_artifacts_spec`. (GOTCHA-RUNSTEP)
14. **`_inputs_for_step`:** `prior_artifacts` + every previously committed step's paths (full
    pre+post order, break at current step), dedup via `dedup_paths`. (GOTCHA-INPUTS)
15. **`_commit_step_artifacts_spec`:** summary JSON (with `disposition`/`step`/`skill_id`/`artifacts`/
    `file_artifacts`/metadata/`timestamp=workflow.now().isoformat()`); under
    `workflow.patched("disposition-batch-writes-v1")` ONE `write_artifacts_batch` (summary+files,
    120s, `commit-{step}`) else `write_artifact` summary (60s, `commit-{step}`) + per-file
    `write_artifact` (60s, no id); file paths `disposition/{label.lower()}/{app_id}/files/{step}/{path}`;
    commit msg `disposition/{label.lower()}({app_id}): {step} artifacts`; sets
    `_step_committed_paths[step]`; under `workflow.patched("patch-output-artifact-ref-v1")` positional
    `update_agent_task_output_ref` (30s, `patch-output-ref-{step}`, try/except…pass); NO mirror, NO
    execution_context. (GOTCHA-COMMIT-PATCH/PATHS/NOCTX/OUTPUTREF)
16. **`_create_gate_pr` override:** labels `["gate-review", "disposition", {label.lower()},
    gate_type]` (4 labels), targets `main`, `create_pr` 60s/`transient`, NO execution_context.
    (GOTCHA-PR-LABELS)
17. **`_bundle_pre_gate_evidence`:** calls pure `bundle_pre_gate_evidence` INLINE (deterministic);
    attaches `g_de1_readiness` with `stakeholder_sign_off=True`, `user_transition_addressed =
    is_retain or _any_hint(USER_TRANSITION_HINTS)`, `data_archival_defined = is_retain or
    _any_hint(DATA_ARCHIVAL_HINTS)`, `rollback_documented = is_retain or spec.has_gate2`,
    `pre_gate1_steps=sorted(...)`, `has_gate2`, `timestamp`; commits to
    `disposition/{label.lower()}/{app_id}/disposition-output.json` (patch-gated, activity_id
    `commit-bundle-pre-gate-evidence`); sets `_disposition_output_ref`; registers
    `_step_committed_paths[_BUNDLE_PRE_GATE_STEP]` + synthetic `_agent_metadata` (`model_used`
    "deterministic", zero usage, full-content `OutputFile`). Hint match is SUBSTRING `in` over step
    names with the exact tuples. (GOTCHA-PREGATE-READINESS/INLINE/REGISTER)
18. **`_bundle_post_gate_evidence`:** calls pure `bundle_post_gate_evidence` INLINE; commits same
    per-label path (patch-gated, activity_id `commit-bundle-post-gate-evidence`); sets
    `_disposition_output_ref` AND `_disposition_output_json=content` (ONLY here); registers
    `_step_committed_paths[_BUNDLE_POST_GATE_STEP]` + synthetic metadata; NO `g_de1_readiness`. Never
    called for Retain. (GOTCHA-POSTGATE-JSON/RETAIN-GUARD)
19. **`_emit_output_bundle`:** builds via `_build_output_bundle`/`_build_payload`; `emit_disposition_output_bundle`
    60s/`transient`; schema failure (NonRetryable in activity) propagates; commits to the DISTINCT
    plural path `dispositions/{portfolio}/{app}/disposition-output.json`. (GOTCHA-EMIT-SCHEMA/PATH)
20. **`_build_payload`:** dispatch on `spec.label` with the exact per-disposition key sets for
    Retire/Retain/Replace/Replatform/Consolidate; Retire's `decommission_certificate_ref` has the
    `f"disposition/{app_id}/decommission-certificate.json"` fallback; unknown label raises
    `ValueError`. (GOTCHA-PAYLOAD-PARALLEL/RETIRE-FALLBACK)
21. **`_persist_disposition_side_effects`:** reads `_disposition_output_ref`/`_disposition_output_json`
    via `getattr(..., "")`; `persist_disposition_side_effects` 60s/`transient`/`activity_id="persist-disposition-side-effects"`;
    no try/except wrapper; `terminal_status` always `"disposition_complete"` from both call sites.
    (GOTCHA-PERSIST-BESTEFFORT)
22. **`_fire_disposition_executed_signal`:** returns early for Retain; reads peer id defensively
    (AttributeError → ""); skips silently (INFO log) if no peer id; builds `DispositionExecutedSignal`;
    sends `handle.signal("disposition_executed", payload)` in try/except (WARNING log on failure).
    Non-Retain only. (GOTCHA-SIGNAL-RETAIN/BESTEFFORT)
23. **`_run_gate`:** assembles+dedups evidence paths from `evidence_steps`; optional sub-step
    announcements pass UNCHANGED `_progress_pct`; opens PR (override); `create_gate_record`
    (30s/`transient`); `_submit_gate_evidence(forward_risk_tier=False)`; advisory `_run_gate_pre_review`;
    `_set_step(gate_step)`; `_wait_for_gate_decision`; on `"cancelled"` return `"cancelled"`; on
    `"approved"` optional merge sub-step, `_reconcile_and_merge_with_retry_loop(merge_method="merge")`,
    record approval from `_gate_decisions[-1][1]` (else `"unknown"`) into `_bundle_approvals`
    (`gate`/`approved_at`/`approved_by`/`record_ref="gates/{gate_id}/decision.json"`), return
    `"approved"`; else return `"rejected"` (no merge, no approval). (GOTCHA-GATE-FRT/MERGEMETHOD/
    APPROVER/NOMERGE-ON-REJECT/SUBSTEP-PROGRESS)
24. **`_complete`:** DB `disposition_complete` + status COMPLETED + 100% + step `"completed"`, return
    `"completed"`. **`_fail`:** status FAILED + `_current_step=reason_step` + DB `disposition_failed`,
    return `"failed"` (does NOT raise). (GOTCHA-FAIL-VS-RAISE)
25. **PR body builders:** deterministic markdown over `pre_gate1_steps` (G-DE-1) / `post_gate1_steps`
    (G-DE-2); artifact list uses per-label path; append `**Rework iteration:** N` line iff
    `_rework_count(gate) > 0`. (GOTCHA-PRBODY)
26. **`_disposition_str`:** `None → ""`; `isinstance(Disposition) → .value`; else `str(...)`.
    (GOTCHA-DISPSTR)
27. **Sequencing:** all agent steps + bundles + gates run STRICTLY sequentially (no gather/no child
    workflows). One external signal only. Patch IDs reproduced VERBATIM:
    `"disposition-batch-writes-v1"` (3 sites), plus the inherited `"patch-output-artifact-ref-v1"`
    (used by `_commit_step_artifacts_spec`), and the base's `"mark-gate-ready-for-review-v1"` (via
    `_run_gate_pre_review`). Activity imports inside `with workflow.unsafe.imports_passed_through()`.
28. **`_build_evidence_data` override:** returns dict WITH top-level `"disposition"` key; iterates
    `self._spec.pre_gate1_steps + self._spec.post_gate1_steps` (NOT `STEPS`/`_evidence_steps_iter`)
    using `step_spec.skill_id`/`.artifact`; injects the two synthetic bundle code-steps
    (`_BUNDLE_PRE_GATE_STEP`, `_BUNDLE_POST_GATE_STEP`) with `skill_id=""`,
    `artifact=_DISPOSITION_OUTPUT_ARTIFACT`, conditionally on `_agent_metadata[code_step]` presence
    (`if code_meta is None: continue`); reproduces base slim/`include_content`/`content_paths`/utf-8
    `size`/non-`OutputFile`-skip/dedup-by-path/`output_files`-strip semantics via nested
    `_build_file_entries`. (GOTCHA-EVID-DISPOSITION-KEY/STEPSPEC-ITER/BUNDLE-INJECT/SLIM-PARITY/
    METADATA-STRIP)
29. **Inherited contracts honored:** does NOT redefine `gate_approved`/`gate_rejected`/
    `escalation_resolved`/`merge_retry`/`get_status`; does NOT override
    `_rework_gate_key_for_step`/`_primary_skill_for_step`/`_evidence_step_metadata`/`_evidence_steps_iter`;
    overrides `_create_gate_pr` + `_build_evidence_data` and defines (not overrides)
    `_dispatch_agent_step`/`_commit_step_artifacts_spec` as separate-named helpers.
