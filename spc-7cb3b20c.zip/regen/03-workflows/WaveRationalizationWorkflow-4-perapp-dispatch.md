# `WaveRationalizationWorkflow` — Part 4: Per-app pipelines + Architecture/Data dispatch helpers (ATOMIC regeneration spec)

> **Source of truth:** `temporal/olympus_workflows/workflows/wave_rationalization.py` (≈5946 lines). Every `wr.py:line` citation below is against that file.
>
> **Scope of THIS file:** **lines 3256–4465 only.** This covers eight methods of
> `WaveRationalizationWorkflow`:
> 1. `_per_app_pipeline` (`wr.py:3256-3608`) — per-app disposition → governance → user-impact fan-out unit.
> 2. `_classify_app` (`wr.py:3610-3713`) — per-app classification + Tier-1 stakeholder pause.
> 3. `_score_app` (`wr.py:3719-3827`) — per-app portfolio-scorer dispatch.
> 4. `_project_per_app_side_effects` (`wr.py:3833-3890`) — post-G-DA parallel side-effect projection.
> 5. `_compute_pending_target_dispatch_entries` (`wr.py:3896-3972`) — v2 target-keyed preview builder.
> 6. `_compute_pending_dispatch_entries` (`wr.py:3974-4054`) — v1 per-app dispatch preview builder.
> 7. `_dispatch_key` + `_init_dispatch_status` + `_normalize_dispatch_payload` (`wr.py:4056-4202`) — dispatch-entry computation / payload coercion.
> 8. `_provision_one_target` (`wr.py:4204-4245`), `_spawn_children_for_target` (`wr.py:4247-4434`), `_update_wave_status_safe` (`wr.py:4436-4463`) — per-target provisioning, child-workflow spawn, best-effort wave-status flip.
>
> **NOT in scope (handled by sibling files — referenced, not reproduced):** `run`/`_execute`
> (`wr.py:1238-1345`/`1346+`), the sequence-1 redundancy passes, the G-RR / G-DA gate loops,
> `_wait_for_gate`/`_register_gate_key`/`_gate_key_from_signal`, `gate_approved`/`gate_rejected`/
> `merge_retry`/`stakeholder_approved`/`dispatch_architecture`/`dispatch_architecture_v2`/
> `retry_target_dispatch`/`cancel_all_children` signal handlers, the queries, and the body of
> `_execute_architecture_data_fanout` (`wr.py:4465+`, which is the orchestrator that CALLS the
> dispatch helpers in this file). Those line ranges belong to the other WaveRationalization
> spec files. This file reproduces ONLY the eight methods above.
>
> **Inheritance:** `class WaveRationalizationWorkflow(HILSignalsMixin)` (`wr.py:1078`). It does
> **NOT** extend `LineWorkflowBase` — see `_LineWorkflowBase.md` for the base it deliberately
> sidesteps and `_HILSignalsMixin.md` for the inherited HIL signals (`approve`,
> `cancel_workflow`, `approve_plan`, etc. — only `self.cancelled` is consumed in this file's
> waits). ⚠️ **GOTCHA-NOBASE (inlines, does not inherit):** every base-like helper this
> workflow uses — `_execution_ctx` (`wr.py:4737`), `_set_step` (`wr.py:5253`), `_now_iso`
> (module-level `wr.py:134`), the gate-wait/merge loop — is **re-implemented in this module**,
> NOT inherited. A rebuild must NOT route these to `LineWorkflowBase`; the wave's fan-out shape
> differs (wave-scoped, per-app gather) and the inlined versions diverge in details (e.g.
> `_set_step` here does NOT push DB status, `_execution_ctx` hard-codes `line_id="rationalization"`).
>
> **Determinism:** every method here is deterministic under Temporal replay. The only time
> source is `_now_iso()` = `workflow.now().isoformat()` (`wr.py:134-135`) and
> `int(workflow.now().timestamp())` (computed by the caller `_execute_architecture_data_fanout`,
> not in this file). No `datetime.now()`, no `random`, no module-level mutable state. All
> per-target IDs are derived deterministically from `target_app_id` + `run_ts`.

---

## 0. STATE this file reads or mutates

These instance vars are all initialized in `__init__` (`wr.py:1087-1236`). The table lists ONLY
the vars the in-scope methods touch (full state lives in the run/signals sibling specs). Types
are the literal annotations.

| Var | Type | Init (`__init__` line) | Read by (this file) | Mutated by (this file) |
|-----|------|------------------------|---------------------|------------------------|
| `_portfolio_id` | `str` | `""` (`wr.py:1092`) | `_execution_ctx` gate (`wr.py:4752`); `_per_app_pipeline`/`_score_app`/`_project_…` pass `input.portfolio_id` to activities | — |
| `_wave_id` | `str` | `""` (`wr.py:1089`) | `_update_wave_status_safe` guard+arg (`wr.py:4442,4448`); `_execution_ctx` (`wr.py:4759`) | — |
| `_current_step` | `str` | `""` (`wr.py:1094`) | — | `_classify_app` sets `f"awaiting-tier1-approval-{app_id}"` (`wr.py:3699`) |
| `_rework_feedback` | `dict[str,dict]` | `{}` (`wr.py:1155`) | `_per_app_pipeline` reads `.get("G-DA")` when `rework` (`wr.py:3282`) | — (set by gate loop in sibling) |
| `_approval_feedback` | `dict[str,dict]` | `{}` (`wr.py:1170`) | `_per_app_pipeline` reads `.get("G-RR")` (`wr.py:3295`) | — (set by gate loop in sibling) |
| `_validation_warnings` | `dict[str,list[str]]` | `{}` (`wr.py:1178`) | — | via `_validate_artifact_or_warn` (called by `_per_app_pipeline`/`_classify_app`/`_score_app`) |
| `_tier1_approved_apps` | `set[str]` | `set()` (`wr.py:1151`) | `_classify_app` wait predicate (`wr.py:3701`); `_project_per_app_side_effects` membership (`wr.py:3873`) | — (set by `stakeholder_approved` signal, sibling) |
| `cancelled` | `bool` | `False` (HIL mixin) | `_classify_app` wait predicate + branch (`wr.py:3701,3703`) | — (set by `cancel_workflow`, HIL) |
| `_dispatch_status` | `dict[str,DispatchTargetStatus]` | `{}` (`wr.py:1212`) | `_provision_one_target`/`_spawn_children_for_target` lookups (`wr.py:4220,4227,4278,4429`) | `_init_dispatch_status` seeds entries (`wr.py:4087`); `_provision_one_target` sets `.status="provisioning"` (`wr.py:4220`); `_spawn_children_for_target` sets `.target_app_id`/`.architecture_workflow_id`/`.data_workflow_id`/`.status` (`wr.py:4430-4433`) |
| `_v2_dispatch_meta` | `dict[str,dict[str,str]]` | `{}` (`wr.py:1231`) | `_init_dispatch_status` (`wr.py:4086`); `_spawn_children_for_target` (`wr.py:4273`) | — (set by dispatch signals, sibling) |
| `_pending_dispatch_entries` | `list[PendingDispatchEntry]` | `[]` (`wr.py:1217`) | (built by `_compute_pending_dispatch_entries`; assigned by the caller fan-out, sibling) | — |
| `_pending_target_dispatch_entries` | `list[PendingTargetDispatchEntry]` | `[]` (`wr.py:1224`) | (built by `_compute_pending_target_dispatch_entries`; assigned by caller, sibling) | — |

> ⚠️ **GOTCHA-STATE-KEY (`_dispatch_status` keyed by `_dispatch_key`, NOT `source_app_id`):** the
> `__init__` comment at `wr.py:1210-1211` says "keyed by source_app_id" but the live code keys it
> by `_dispatch_key(cfg)` = `cfg.target_app_id or cfg.source_app_id` (`wr.py:4087,4220,4227,…`).
> PR #495 (`wr.py:4078-4082`) changed this so N targets sharing an anchor source app don't
> overwrite each other. A rebuild MUST key `_dispatch_status` by `_dispatch_key`, not raw
> `source_app_id`, or capability-grain waves (many targets per anchor) silently collapse to one
> row. The docstring is stale; the code is authoritative.

---

## 1. SIGNALS / QUERIES / UPDATES contributed by THIS file

**None.** No `@workflow.signal`, `@workflow.query`, or `@workflow.update` is declared in lines
3256–4465. Every method here is a plain `async def` (or `@staticmethod`) helper. The signal
handlers that mutate the state these helpers read (`stakeholder_approved` →
`_tier1_approved_apps`; `dispatch_architecture`/`_v2` → `_v2_dispatch_meta` /
`_dispatch_payload` / `_dispatch_received`; `retry_target_dispatch` → `_pending_retries`; the
gate signals → `_rework_feedback` / `_approval_feedback`) are all defined elsewhere (sibling
spec). The **only** signal-driven predicate consumed in this file is in `_classify_app`:
`await workflow.wait_condition(lambda: app_id in self._tier1_approved_apps or self.cancelled)`
(`wr.py:3700-3702`).

> ⚠️ **GOTCHA-NOOVERRIDE:** because this workflow inherits `HILSignalsMixin` (not
> `LineWorkflowBase`), it does **not** carry the four base gate signals (`gate_approved`,
> `gate_rejected`, `escalation_resolved`, `merge_retry`) by inheritance — it defines its OWN
> `gate_approved`/`gate_rejected`/`merge_retry` (sibling spec) with **per-gate queue** semantics
> (keyed by `gate_key` string, not a flat list). A rebuild must NOT mix the base's flat-list
> gate model into this workflow.

---

## 2. Module-level helpers consumed by this file (reproduce exactly)

These are **module functions** (not methods). The in-scope code depends on their exact
behavior. Reproduce them verbatim.

### 2.1 `_now_iso() -> str` — `wr.py:134-135`
```text
def _now_iso():
    return workflow.now().isoformat()
```

### 2.2 `_normalize_relationship(relationship: str | None) -> str` — `wr.py:138-155`
```text
def _normalize_relationship(relationship):
    if not relationship:            # wr.py:153  → None, "", whitespace handled by strip below? NO: empty str is falsy
        return ""                   # wr.py:154
    return relationship.strip().lower()   # wr.py:155
```
⚠️ **GOTCHA-NR1:** `not relationship` catches `None` and `""` but a whitespace-only `"  "` is
**truthy**, so it reaches `.strip().lower()` → `""`. Either way the result for blank input is
`""`. A rebuild must keep the `.strip().lower()` so `"Consolidate"`/`" CONSOLIDATE "` →
`"consolidate"`. EVERY read of a relationship/disposition value for case comparison goes through
this (`wr.py:3935,4275,4276,5875,5894`).

### 2.3 `_legacy_disposition_from_relationship(relationship: str | None) -> str` — `wr.py:158-172`
```text
def _legacy_disposition_from_relationship(relationship):
    rel = _normalize_relationship(relationship)   # wr.py:169
    if not rel:                                    # wr.py:170
        return ""                                  # wr.py:171
    return rel[:1].upper() + rel[1:]               # wr.py:172  "consolidate" → "Consolidate"
```
⚠️ **GOTCHA-LD1 (Title-case, not `.title()`):** uses `rel[:1].upper() + rel[1:]`, NOT
`str.title()`. So `"re-architect"` → `"Re-architect"` (only the first char upcased), NOT
`"Re-Architect"`. A rebuild must use the slice form. Used by `_normalize_dispatch_payload` to
project v2 lowercase `relationship` onto v1 Title-cased `disposition` (`wr.py:4136,4172`).

### 2.4 `_is_retire_or_replace_disposition(disp: str | None) -> bool` — `wr.py:762-765`
```text
def _is_retire_or_replace_disposition(disp):
    if not disp:                          # wr.py:763
        return False                      # wr.py:764
    return disp in ("Retire", "Replace")  # wr.py:765
```
⚠️ **GOTCHA-RR1 (exact Title-case membership):** matches the literal strings `"Retire"` /
`"Replace"` only. A lowercase `"retire"` returns `False`. Since `_per_app_pipeline` parses
`disposition` from `recommended_disposition` (raw agent JSON, conventionally Title-cased) this
gate is what decides whether user-impact runs. A rebuild must compare against exactly
`("Retire", "Replace")`.

### 2.5 `_classification_is_tier_1(cls_json: str) -> bool` — `wr.py:185-211`
```text
def _classification_is_tier_1(cls_json):
    import json                               # wr.py:195 (local import)
    if not cls_json:                          # wr.py:197
        return False                          # wr.py:198
    try:
        parsed = json.loads(cls_json)         # wr.py:200
    except (json.JSONDecodeError, TypeError, ValueError):   # wr.py:201
        return False                          # wr.py:202
    if not isinstance(parsed, dict):          # wr.py:203
        return False                          # wr.py:204
    if parsed.get("tier_1_flag") is True:     # wr.py:205  (identity check vs True)
        return True                           # wr.py:206
    risk = parsed.get("risk_tier")            # wr.py:207
    try:
        return int(risk) == 1 if risk is not None else False   # wr.py:209
    except (TypeError, ValueError):           # wr.py:210
        return False                          # wr.py:211
```
⚠️ **GOTCHA-T1 (uses `json.loads`, NOT `parse_agent_json`):** unlike disposition parsing,
tier-1 detection uses **strict** `json.loads` on `cls_json`. But `cls_json` is already resolved
from `output_files` via `_primary_output_content` (the workspace JSON, not the narrative), so it
is real JSON. The `tier_1_flag is True` is an **identity** check (not truthy) — `"true"` string
or `1` won't trip it; only Python `True`. Then `risk_tier` is coerced via `int(risk)==1`
(accepts int or numeric string). A rebuild must keep BOTH paths (flag-identity then risk-int) and
the strict-parse + safe-False-default behavior.

### 2.6 `_compute_overall_readiness(score_json: str) -> tuple[float|None, list[str]]` — `wr.py:214-258`
Pure deterministic function consumed by `_score_app`. Reproduce branch-for-branch:
```text
_PORTFOLIO_SCORER_DIMENSIONS = (   # wr.py:175-182 — ORDER matters for iteration
    "technical_readiness", "architectural_readiness", "operational_readiness",
    "security_readiness", "user_experience_readiness", "business_readiness",
)

def _compute_overall_readiness(score_json):
    import json                               # wr.py:224
    if not score_json:                        # wr.py:226
        return None, []                       # wr.py:227
    try:
        parsed = json.loads(score_json)       # wr.py:229
    except (json.JSONDecodeError, TypeError, ValueError):   # wr.py:230
        return None, []                       # wr.py:231
    if not isinstance(parsed, dict):          # wr.py:232
        return None, []                       # wr.py:233
    scores = parsed.get("scores")             # wr.py:234
    if not isinstance(scores, dict):          # wr.py:235
        return None, []                       # wr.py:236
    total = 0.0; count = 0; present = []      # wr.py:237-239
    for dim in _PORTFOLIO_SCORER_DIMENSIONS:  # wr.py:240  LOOP (fixed 6 dims, fixed order)
        entry = scores.get(dim)               # wr.py:241
        if not isinstance(entry, dict):       # wr.py:242
            continue                          # wr.py:243  ← dim entirely absent → NOT in `present`
        value = entry.get("score")            # wr.py:244
        if value is None:                     # wr.py:245
            present.append(dim)               # wr.py:246  ← null-score dim IS in `present`, excluded from denom
            continue                          # wr.py:247
        try:
            value_f = float(value)            # wr.py:249
        except (TypeError, ValueError):       # wr.py:250
            continue                          # wr.py:251  ← unparseable score → NOT in `present`
        value_f = max(0.0, min(100.0, value_f))   # wr.py:252  clamp to [0,100]
        total += value_f; count += 1; present.append(dim)   # wr.py:253-255
    if count == 0:                            # wr.py:256
        return None, sorted(present)          # wr.py:257  ← overall=None when no numeric scores
    return round(total / count, 2), sorted(present)   # wr.py:258
```
⚠️ **GOTCHA-OR1 (three distinct `continue` paths, different `present` semantics):** (a)
non-dict dim entry → skip, NOT added to `present`; (b) `score is None` → added to `present`
(reported as "dimension exists but unscored") but excluded from the mean denominator; (c)
unparseable score → skip, NOT in `present`. A rebuild MUST preserve which path adds to
`present`. ⚠️ **GOTCHA-OR2:** scores clamp to `[0.0, 100.0]` (`wr.py:252`); mean is
`round(total/count, 2)`; `present` is **sorted** on return. Empty/non-numeric → `(None, [])` or
`(None, sorted(present))`. A rebuild must clamp, round-2, and sort.

### 2.7 Artifact-path helpers (pure, deterministic) — consumed by per-app dispatches
- `_discovery_passes_for_app(app_id)` → `[f"discovery/{app_id}/{name}.json" for name in _DISCOVERY_PASSES]` where `_DISCOVERY_PASSES = ("catalog","structural-analysis","business-logic","quality-risk","ux-accessibility","tco-baseline","synthesis")` (`wr.py:813-832`). **7 paths.**
- `_wave_context_artifacts(wave_id, app_id)` → 5 paths (`wr.py:858-865`): `rationalization/wave-{wave_id}/redundancy-matrix.json`, `…/ux-overlap-matrix.json`, `…/integration-graph.json`, `…/portfolio-redundancy-matrix.json`, `…/{app_id}/intra-app-redundancy.json`.
- `_wave_context_optional_artifacts(wave_id)` → `[f"rationalization/wave-{wave_id}/shared-identity-report.json"]` (`wr.py:886-889`) — single optional path; agent treats 404 as "not present" (⚠️ **GOTCHA-OPT1:** must be passed as `optional_input_artifacts`, NOT `input_artifacts`, or a missing companion file fails every per-app dispatch).
- `_disposition_input_artifacts(wave_id, app_id)` → `_discovery_passes_for_app(app_id) + _wave_context_artifacts(wave_id, app_id)` = **12 paths** (`wr.py:948-950`).

### 2.8 `_with_context_priors(context, skill_id) -> dict` (async) — `wr.py:953-995`
```text
async def _with_context_priors(context, skill_id):
    try:
        result = await workflow.execute_activity(
            load_context_priors, LoadContextPriorsInput(skill_id=skill_id),
            start_to_close_timeout=timedelta(seconds=10),    # wr.py:975
            retry_policy=RETRY_POLICIES["transient"])        # wr.py:976
    except Exception as exc:                                 # wr.py:978  BRANCH (best-effort)
        workflow.logger.warning("context_priors load failed (continuing without priors): %s", exc, extra={"skill_id": skill_id})
        return context                                       # wr.py:984  ← unchanged on failure
    priors = getattr(result, "priors", None) or []           # wr.py:985
    if not priors:                                           # wr.py:986  BRANCH
        return context                                       # wr.py:987  ← unchanged when empty
    merged = dict(context)                                   # wr.py:988  (shallow copy)
    merged["context_priors"] = priors                        # wr.py:994
    return merged                                            # wr.py:995
```
Activity: `load_context_priors`; **10s**; `transient`. **Best-effort** (try/except returns
context unchanged). ⚠️ **GOTCHA-CP1:** failure and empty-priors both return the ORIGINAL dict
(not a copy); only the non-empty path copies and adds `context_priors`. A rebuild must not mutate
the caller's dict on the empty/failure path.

### 2.9 `_with_fixture_scenario(context, skill_id, fixture_scenarios) -> dict` — `wr.py:998-1018`
```text
def _with_fixture_scenario(context, skill_id, fixture_scenarios):
    scenario = fixture_scenarios.get(skill_id) if fixture_scenarios else None   # wr.py:1012
    if not scenario:                                                            # wr.py:1013  BRANCH
        return context                                                          # wr.py:1014  ← unchanged
    merged = dict(context)                                                       # wr.py:1016
    merged["fixture_scenario"] = scenario                                        # wr.py:1017
    return merged                                                                # wr.py:1018
```
No-op in prod (empty `fixture_scenarios`). DECISION-018 mock-runtime hook. ⚠️ **GOTCHA-FX1:**
returns the original dict (no copy) when no scenario; copies only when adding the key.

### 2.10 `parse_agent_json(raw)` — imported from `olympus_workflows.utils` (`wr.py:131`)
Defensive JSON parser that strips markdown fences / preamble before parsing; returns a dict (or
non-dict / None on failure). Used in `_per_app_pipeline` (`wr.py:3501`),
`_compute_pending_dispatch_entries` (`wr.py:4002,4022`). ⚠️ **GOTCHA-PA1:** disposition parsing
uses `parse_agent_json` (lenient, fence-stripping) whereas tier-1/score use strict `json.loads`.
This asymmetry is deliberate (the disposition output historically arrived ```json-fenced); a
rebuild must keep the two parsers distinct at their call sites.

---

## 3. `_per_app_pipeline(...)` — per-app disposition → governance → user-impact (`wr.py:3256-3608`)

**Signature** (`wr.py:3256-3265`):
```text
async def _per_app_pipeline(self, app_id, input, repo, branch, workspace_key, *, rework=False) -> dict
```
**Called from:** `_execute` (sibling), fanned out across `input.app_ids` under
`asyncio.gather(*[self._per_app_pipeline(app_id, …) for app_id in input.app_ids])`
(`wr.py:2498-2502`). On rework it is re-called with `rework=True` (`wr.py:2963`). So **N copies
run concurrently**; this method must remain replay-deterministic per coroutine.

**Returns:** a dict (the per-app G-DA evidence row). Exact shape at end.

### 3.1 Control-flow pseudocode (preserve EVERY branch)

```text
async def _per_app_pipeline(self, app_id, input, repo, branch, workspace_key, *, rework=False):

    # ---- (A) Disposition recommendation dispatch -------------------------
    disp_skill = SKILLS["disposition-recommendation"]   # wr.py:3271
        # = {"skill_id": "disposition-recommender", "artifact": "disposition-recommendation.json"}

    # Build the dispatch context: fixture-scenario-wrap, then context-priors-wrap.
    disp_context = await _with_context_priors(            # wr.py:3277  (outer await)
        _with_fixture_scenario(                          # wr.py:3278  (inner, sync)
            {
                "wave_id": input.wave_id,                                    # wr.py:3280
                "rework_feedback": (                                         # wr.py:3281
                    self._rework_feedback.get("G-DA") if rework else None    # wr.py:3282  ★BRANCH 1
                ),
                "approval_guidance": self._approval_feedback.get("G-RR"),    # wr.py:3295
            },
            disp_skill["skill_id"],                       # wr.py:3299
            input.fixture_scenarios,                      # wr.py:3300
        ),
        disp_skill["skill_id"],                           # wr.py:3302
    )

    disp_result = await workflow.execute_activity(        # wr.py:3304
        dispatch_agent_task,
        AgentTaskInput(
            task_type="wave-per-app-disposition",         # wr.py:3307
            skill_id=disp_skill["skill_id"],
            app_id=app_id,
            workspace_key=f"{workspace_key}-{app_id}",     # wr.py:3310  ★per-app suffix
            artifact_repo=repo, artifact_ref=branch,
            context=disp_context,
            input_artifacts=_disposition_input_artifacts(input.wave_id, app_id),       # wr.py:3322  (12 paths)
            optional_input_artifacts=_wave_context_optional_artifacts(input.wave_id),  # wr.py:3325
            timeout_seconds=3600,
            execution_context=self._execution_ctx(
                "disposition-recommendation", app_id=app_id,
                input_artifact_paths=_disposition_input_artifacts(input.wave_id, app_id)),  # wr.py:3329-3334
        ),
        start_to_close_timeout=timedelta(hours=1),         # wr.py:3337
        retry_policy=RETRY_POLICIES["agent_failure"],      # wr.py:3338  (3 attempts, 5-60s)
    )

    # ---- (B) Resolve + validate + commit disposition artifact ------------
    disp_raw = self._primary_output_content(disp_result, disp_skill["artifact"])   # wr.py:3355
    await self._validate_artifact_or_warn(                                          # wr.py:3358
        artifact_filename=disp_skill["artifact"], raw_content=disp_raw,
        wave_id=input.wave_id, app_id=app_id)

    disp_path = f"rationalization/wave-{input.wave_id}/{app_id}/{disp_skill['artifact']}"   # wr.py:3365
    await self._commit_artifact(repo, branch, disp_path, disp_raw,
        f"Wave {input.wave_id} / {app_id}: disposition recommendation")             # wr.py:3366-3372
    await self._commit_output_files(repo, branch, disp_result,                       # wr.py:3373
        primary_path=disp_path, wave_id=input.wave_id, app_id=app_id,
        commit_message_prefix=f"Wave {input.wave_id} / {app_id}: disposition recommendation companion")

    # ---- (C) Rat-cap disposition persist (patch-gated, best-effort) ------
    if (workflow.patched("wave-rationalization-rat-cap-clustering-v1") and disp_raw):   # wr.py:3398-3403  ★BRANCH 2 (compound)
        try:
            await workflow.execute_activity(                                         # wr.py:3405
                persist_rationalization_capability_dispositions,
                PersistRationalizationCapabilityDispositionsInput(
                    portfolio_id=input.portfolio_id, wave_id=input.wave_id,
                    disposition_recommendation_json=disp_raw,
                    disposition_recommendation_artifact_ref=disp_path,
                    execution_context=self._execution_ctx("disposition-recommendation", app_id=app_id)),
                start_to_close_timeout=timedelta(seconds=60),                        # wr.py:3417
                retry_policy=RETRY_POLICIES["transient"],                            # wr.py:3418
                activity_id=f"persist-rat-cap-disp-{input.wave_id}-{app_id}",        # wr.py:3419  ★stable id
            )
        except Exception:                                                            # wr.py:3423  ★BRANCH 3 (best-effort)
            workflow.logger.exception("persist_rationalization_capability_dispositions failed; …")

    # ---- (D) Governance dispatch -----------------------------------------
    gov_skill = SKILLS["disposition-governance"]   # wr.py:3431  ({"skill_id":"disposition-governance","artifact":"disposition-governance.json"})
    gov_input_artifacts = [disp_path, *_wave_context_artifacts(input.wave_id, app_id)]   # wr.py:3438  (1 + 5 = 6 paths)
    gov_result = await workflow.execute_activity(   # wr.py:3441
        dispatch_agent_task,
        AgentTaskInput(
            task_type="wave-per-app-governance",
            skill_id=gov_skill["skill_id"], app_id=app_id,
            workspace_key=f"{workspace_key}-{app_id}",
            artifact_repo=repo, artifact_ref=branch,
            context=_with_fixture_scenario({"wave_id": input.wave_id}, gov_skill["skill_id"], input.fixture_scenarios),  # wr.py:3450
            input_artifacts=gov_input_artifacts,
            optional_input_artifacts=_wave_context_optional_artifacts(input.wave_id),
            timeout_seconds=3600,
            execution_context=self._execution_ctx("disposition-governance", app_id=app_id, input_artifact_paths=gov_input_artifacts)),
        start_to_close_timeout=timedelta(hours=1),     # wr.py:3466
        retry_policy=RETRY_POLICIES["agent_failure"],  # wr.py:3467
    )
    gov_path = f"rationalization/wave-{input.wave_id}/{app_id}/{gov_skill['artifact']}"   # wr.py:3469
    gov_raw  = self._primary_output_content(gov_result, gov_skill["artifact"])            # wr.py:3472
    await self._commit_artifact(repo, branch, gov_path, gov_raw,
        f"Wave {input.wave_id} / {app_id}: disposition governance")                       # wr.py:3475
    await self._commit_output_files(repo, branch, gov_result, primary_path=gov_path,
        wave_id=input.wave_id, app_id=app_id,
        commit_message_prefix=f"Wave {input.wave_id} / {app_id}: disposition governance companion")  # wr.py:3482

    # ⚠️ NOTE: governance output is NOT schema-validated (no _validate_artifact_or_warn call) —
    #          unlike disposition (B), classification, and score. This is intentional asymmetry.

    # ---- (E) Parse disposition for user-impact gating --------------------
    disposition = ""                                # wr.py:3499
    if disp_raw:                                    # wr.py:3500  ★BRANCH 4
        parsed = parse_agent_json(disp_raw)         # wr.py:3501  (LENIENT parser)
        if isinstance(parsed, dict):                # wr.py:3502  ★BRANCH 5
            disposition = str(parsed.get("recommended_disposition", ""))   # wr.py:3503

    # ---- (F) User-impact dispatch (Retire/Replace ONLY) ------------------
    ui_result = None   # wr.py:3509
    ui_path = ""       # wr.py:3510
    if _is_retire_or_replace_disposition(disposition):   # wr.py:3511  ★BRANCH 6
        ui_skill = SKILLS["user-impact"]   # wr.py:3512  ({"skill_id":"assess-user-impact","artifact":"user-impact-analysis.json"})
        ui_input_artifacts = [
            disp_path,
            f"discovery/{app_id}/ux-accessibility.json",
            *_wave_context_artifacts(input.wave_id, app_id),    # wr.py:3518-3522  (2 + 5 = 7 paths)
        ]
        ui_result = await workflow.execute_activity(            # wr.py:3523
            dispatch_agent_task,
            AgentTaskInput(
                task_type="wave-per-app-user-impact",
                skill_id=ui_skill["skill_id"], app_id=app_id,
                workspace_key=f"{workspace_key}-{app_id}",
                artifact_repo=repo, artifact_ref=branch,
                context=_with_fixture_scenario(
                    {"wave_id": input.wave_id, "disposition": disposition},   # wr.py:3533  ★carries disposition
                    ui_skill["skill_id"], input.fixture_scenarios),
                input_artifacts=ui_input_artifacts,
                optional_input_artifacts=_wave_context_optional_artifacts(input.wave_id),
                timeout_seconds=3600,
                execution_context=self._execution_ctx("user-impact-analysis", app_id=app_id, input_artifact_paths=ui_input_artifacts)),
            start_to_close_timeout=timedelta(hours=1),     # wr.py:3548
            retry_policy=RETRY_POLICIES["agent_failure"],  # wr.py:3549
        )
        ui_path = f"rationalization/wave-{input.wave_id}/{app_id}/{ui_skill['artifact']}"   # wr.py:3551
        ui_raw  = self._primary_output_content(ui_result, ui_skill["artifact"])             # wr.py:3554
        await self._commit_artifact(repo, branch, ui_path, ui_raw,
            f"Wave {input.wave_id} / {app_id}: user impact analysis")                        # wr.py:3557
        await self._commit_output_files(repo, branch, ui_result, primary_path=ui_path,
            wave_id=input.wave_id, app_id=app_id,
            commit_message_prefix=f"Wave {input.wave_id} / {app_id}: user impact companion")  # wr.py:3564

    # ---- (G) Return per-app evidence row ---------------------------------
    return {                                            # wr.py:3586-3608
        "app_id": app_id,
        "disposition": disposition,
        "disposition_path": disp_path,
        "disposition_json": disp_raw,
        "disposition_narrative": self._agent_narrative(disp_result),
        "governance_path": gov_path,
        "governance_json": gov_raw,
        "governance_narrative": self._agent_narrative(gov_result),
        "user_impact_path": ui_path,
        "user_impact_json": (
            self._primary_output_content(ui_result, SKILLS["user-impact"]["artifact"])
            if ui_result is not None else ""            # wr.py:3604  ★BRANCH 7
        ),
        "user_impact_narrative": self._agent_narrative(ui_result),   # ui_result may be None → _agent_narrative returns ""
    }
```

### 3.2 Branch inventory (`_per_app_pipeline`): **7 branches**
1. `self._rework_feedback.get("G-DA") if rework else None` (`wr.py:3282`) — rework feedback only on rework re-call.
2. `if (workflow.patched("wave-rationalization-rat-cap-clustering-v1") and disp_raw):` (`wr.py:3398-3403`) — patch-gated AND non-empty disp.
3. `except Exception:` around the rat-cap persist (`wr.py:3423`) — best-effort.
4. `if disp_raw:` (`wr.py:3500`) — parse only if non-empty.
5. `if isinstance(parsed, dict):` (`wr.py:3502`) — extract `recommended_disposition`.
6. `if _is_retire_or_replace_disposition(disposition):` (`wr.py:3511`) — gate the user-impact dispatch.
7. `… if ui_result is not None else ""` (`wr.py:3604`) — guard `user_impact_json`.

### 3.3 Activity / dispatch calls (`_per_app_pipeline`), in order
| # | Activity | Args | Timeout | Retry | activity_id | Notes |
|---|----------|------|---------|-------|-------------|-------|
| 1 | `load_context_priors` | via `_with_context_priors` | 10s | transient | — | best-effort try/except |
| 2 | `dispatch_agent_task` (disposition) | `AgentTaskInput(task_type="wave-per-app-disposition", …)` | **1h** | **agent_failure** | — (none) | per-app, `workspace_key-{app_id}` |
| 3 | `validate_artifact_against_schema` | via `_validate_artifact_or_warn` | 30s | transient | — | advisory; skip if `disp_raw` empty |
| 4 | `write_artifact` **or** `write_artifacts_batch` | via `_commit_artifact` | 60s / 120s | transient | — | patch-gated; primary disposition JSON |
| 5 | `write_artifact`×k | via `_commit_output_files` | 60s/120s | transient | — | companions; best-effort each |
| 6 | `persist_rationalization_capability_dispositions` | `PersistRationalizationCapabilityDispositionsInput(…)` | **60s** | transient | `persist-rat-cap-disp-{wave}-{app}` | patch-gated + best-effort |
| 7 | `dispatch_agent_task` (governance) | `task_type="wave-per-app-governance"` | **1h** | **agent_failure** | — | NO schema validation after |
| 8 | `write_artifact`/`batch` + companions | governance commit | 60s/120s | transient | — | |
| 9 | `dispatch_agent_task` (user-impact) | `task_type="wave-per-app-user-impact"` | **1h** | **agent_failure** | — | **only if Retire/Replace** |
| 10 | user-impact commit + companions | | 60s/120s | transient | — | only if user-impact ran |

⚠️ **GOTCHA-PAP1 (governance NOT validated):** disposition (step 3), classification, and score
each call `_validate_artifact_or_warn`; governance does **not** (`wr.py:3469-3492` has no
validate call). A rebuild must NOT add a validation call for governance — that would change
`_validation_warnings` contents surfaced at G-DA.
⚠️ **GOTCHA-PAP2 (`disp_raw` resolved from `output_files`, not narrative):** `disp_raw` is
`_primary_output_content(disp_result, "disposition-recommendation.json")` (§5.2) — the workspace
JSON file, NOT `output_artifacts[0]`. The same `disp_raw` flows to: the validator, the rat-cap
persist activity, the `recommended_disposition` parse, and the G-DA `disposition_json`. A rebuild
that reads `output_artifacts[0]` here re-introduces the 2026-05-19 bug (committing prose into the
JSON path, `_is_retire_or_replace` never matching, user-impact silently skipped).
⚠️ **GOTCHA-PAP3 (rat-cap persist `activity_id` is stable, persist is idempotent):**
`activity_id=f"persist-rat-cap-disp-{wave}-{app}"` makes the persist replay-stable; the activity
UPDATEs rat-cap rows by id (last-write-wins) so N concurrent per-app pipelines touching
overlapping rat-caps are safe (`wr.py:3385-3397`). A rebuild keeps the stable id + idempotent
contract.
⚠️ **GOTCHA-PAP4 (return dict shape is the G-DA evidence contract):** the 12-key return dict
(`wr.py:3586-3608`) is consumed by the G-DA evidence builder and by
`_compute_pending_dispatch_entries` (which reads `disposition_json`). A rebuild MUST emit ALL 12
keys with these exact names; `disposition_narrative`/`governance_narrative`/
`user_impact_narrative` use `_agent_narrative` (which returns `""` for `None`).

---

## 4. `_classify_app(...)` — per-app classification + Tier-1 pause (`wr.py:3610-3713`)

**Signature:** `async def _classify_app(self, app_id, input, repo, branch, workspace_key) -> dict` (`wr.py:3610-3617`).
**Called from:** `_execute` via `asyncio.gather(*[self._classify_app(app_id, …) for app_id in input.app_ids])` (`wr.py:2521-2525`). **N copies run concurrently** — so multiple Tier-1 pauses may be outstanding at once (each keyed by its own `app_id`).

### 4.1 Control-flow pseudocode
```text
async def _classify_app(self, app_id, input, repo, branch, workspace_key):
    cls_skill = SKILLS["classification"]   # wr.py:3626  ({"skill_id":"classify-application","artifact":"classification.json"})
    cls_result = await workflow.execute_activity(   # wr.py:3627
        dispatch_agent_task,
        AgentTaskInput(
            task_type="wave-per-app-classification",
            skill_id=cls_skill["skill_id"], app_id=app_id,
            workspace_key=f"{workspace_key}-{app_id}",
            artifact_repo=repo, artifact_ref=branch,
            context=_with_fixture_scenario({"wave_id": input.wave_id}, cls_skill["skill_id"], input.fixture_scenarios),  # wr.py:3636
            input_artifacts=_discovery_passes_for_app(app_id),       # wr.py:3644  (7 paths — NO wave context)
            timeout_seconds=3600,
            execution_context=self._execution_ctx("classification", app_id=app_id,
                input_artifact_paths=_discovery_passes_for_app(app_id))),
        start_to_close_timeout=timedelta(hours=1),      # wr.py:3652
        retry_policy=RETRY_POLICIES["agent_failure"],   # wr.py:3653
    )
    cls_path = f"rationalization/wave-{input.wave_id}/{app_id}/{cls_skill['artifact']}"   # wr.py:3655
    cls_json = self._primary_output_content(cls_result, cls_skill["artifact"])            # wr.py:3661
    await self._validate_artifact_or_warn(artifact_filename=cls_skill["artifact"],        # wr.py:3668
        raw_content=cls_json, wave_id=input.wave_id, app_id=app_id)
    await self._commit_artifact(repo, branch, cls_path, cls_json,
        f"Wave {input.wave_id} / {app_id}: classification")                                # wr.py:3674
    await self._commit_output_files(repo, branch, cls_result, primary_path=cls_path,
        wave_id=input.wave_id, app_id=app_id,
        commit_message_prefix=f"Wave {input.wave_id} / {app_id}: classification companion")  # wr.py:3681

    # ---- Tier-1 stakeholder pause ----------------------------------------
    if _classification_is_tier_1(cls_json):                                  # wr.py:3698  ★BRANCH 1
        self._current_step = f"awaiting-tier1-approval-{app_id}"             # wr.py:3699  (per-app step label)
        await workflow.wait_condition(                                       # wr.py:3700
            lambda: app_id in self._tier1_approved_apps or self.cancelled)   # wr.py:3701  ★PREDICATE
        if self.cancelled:                                                   # wr.py:3703  ★BRANCH 2
            raise RuntimeError("cancelled waiting for tier-1 approval")      # wr.py:3704  ← RAISES (not return)

    return {                                            # wr.py:3706-3713
        "app_id": app_id,
        "cls_json": cls_json,
        "cls_path": cls_path,
        "cls_narrative": self._agent_narrative(cls_result),
    }
```

### 4.2 Branch inventory (`_classify_app`): **2 branches**
1. `if _classification_is_tier_1(cls_json):` (`wr.py:3698`) — only Tier-1 apps pause.
2. `if self.cancelled:` after the wait (`wr.py:3703`) — cancel → **raise** `RuntimeError`.

### 4.3 Activity calls (`_classify_app`), in order
| # | Activity | Args | Timeout | Retry | Notes |
|---|----------|------|---------|-------|-------|
| 1 | `dispatch_agent_task` | `task_type="wave-per-app-classification"`, `input_artifacts=_discovery_passes_for_app(app_id)` (7 paths) | **1h** | **agent_failure** | NO wave-context inputs (unlike disposition/score) |
| 2 | `validate_artifact_against_schema` | via `_validate_artifact_or_warn` | 30s | transient | advisory |
| 3 | commit + companions | via `_commit_artifact`/`_commit_output_files` | 60s/120s | transient | |

> ⚠️ **GOTCHA-CA1 (Tier-1 pause is per-app, keyed by `app_id`):** the wait predicate is
> `app_id in self._tier1_approved_apps` (`wr.py:3701`), and `_tier1_approved_apps` is a SET keyed
> by app_id (populated by `stakeholder_approved` parsing `approval_id` prefix `tier1-{app_id}-…`,
> sibling). Because N `_classify_app` coroutines run concurrently under one `gather`, each Tier-1
> app blocks independently; the wave proceeds only when ALL Tier-1 apps' approvals land (or
> cancel). A rebuild MUST key the wait by `app_id` membership, not a single shared flag.
> ⚠️ **GOTCHA-CA2 (cancel → RAISE, not graceful return):** on `self.cancelled` the method
> **raises** `RuntimeError("cancelled waiting for tier-1 approval")` (`wr.py:3704`), which
> propagates out of the `gather` → out of `_execute` → into `run()`'s outer `except` →
> `classify_failure` (defaults `"terminal"`, since no recoverable activity name is on the chain) →
> wave flips to `failed`. A rebuild must raise here, not return a sentinel, so cancellation during
> a Tier-1 pause is recorded as a terminal failure. ⚠️ Note `_classify_app`'s wait predicate does
> NOT short-circuit on the dispatch-cancel; the ONLY escape besides approval is `self.cancelled`.
> ⚠️ **GOTCHA-CA3 (classification inputs have NO wave context):** `input_artifacts` is just the 7
> Discovery passes (`wr.py:3644`); classification is per-app-local and does not read the
> wave-scoped redundancy matrices (contrast `_per_app_pipeline`/`_score_app` which add the 5
> wave-context paths). A rebuild must NOT add wave-context to classification.
> ⚠️ **GOTCHA-CA4 (`_current_step` write inside a per-app coroutine):** `self._current_step =
> f"awaiting-tier1-approval-{app_id}"` (`wr.py:3699`) is written by EACH paused coroutine. Since N
> run concurrently, the `get_status` query reflects whichever coroutine wrote last (last-writer-
> wins, non-deterministic-looking but replay-stable). This is intentional observability, not a
> bug. A rebuild keeps the assignment; do not guard it.

---

## 5. `_score_app(...)` — per-app portfolio-scorer (`wr.py:3719-3827`)

**Signature:** `async def _score_app(self, app_id, input, repo, branch, workspace_key) -> dict` (`wr.py:3719-3726`).
**Called from:** `_execute` via `asyncio.gather(*[self._score_app(app_id, …) for app_id in input.app_ids])` (`wr.py:2546-2550`). **N concurrent.**

### 5.1 Control-flow pseudocode
```text
async def _score_app(self, app_id, input, repo, branch, workspace_key):
    score_skill = SKILLS["portfolio-score"]   # wr.py:3741  ({"skill_id":"portfolio-scorer","artifact":"portfolio-score.json"})
    score_result = await workflow.execute_activity(   # wr.py:3742
        dispatch_agent_task,
        AgentTaskInput(
            task_type="wave-per-app-portfolio-score",
            skill_id=score_skill["skill_id"], app_id=app_id,
            workspace_key=f"{workspace_key}-{app_id}",
            artifact_repo=repo, artifact_ref=branch,
            context=_with_fixture_scenario({"wave_id": input.wave_id}, score_skill["skill_id"], input.fixture_scenarios),  # wr.py:3751
            input_artifacts=_disposition_input_artifacts(input.wave_id, app_id),       # wr.py:3762  (12 paths: 7 discovery + 5 wave-ctx)
            optional_input_artifacts=_wave_context_optional_artifacts(input.wave_id),  # wr.py:3765
            timeout_seconds=3600,
            execution_context=self._execution_ctx("portfolio-scoring", app_id=app_id,
                input_artifact_paths=_disposition_input_artifacts(input.wave_id, app_id))),
        start_to_close_timeout=timedelta(hours=1),      # wr.py:3777
        retry_policy=RETRY_POLICIES["agent_failure"],   # wr.py:3778
    )
    score_path = f"rationalization/wave-{input.wave_id}/{app_id}/{score_skill['artifact']}"   # wr.py:3780
    score_json = self._primary_output_content(score_result, score_skill["artifact"])          # wr.py:3786
    await self._validate_artifact_or_warn(artifact_filename=score_skill["artifact"],          # wr.py:3792
        raw_content=score_json, wave_id=input.wave_id, app_id=app_id)
    await self._commit_artifact(repo, branch, score_path, score_json,
        f"Wave {input.wave_id} / {app_id}: portfolio readiness score")                         # wr.py:3798
    await self._commit_output_files(repo, branch, score_result, primary_path=score_path,
        wave_id=input.wave_id, app_id=app_id,
        commit_message_prefix=f"Wave {input.wave_id} / {app_id}: portfolio score companion")    # wr.py:3805

    overall, dimensions = _compute_overall_readiness(score_json)   # wr.py:3817  (PURE — §2.6)
    return {                                          # wr.py:3818-3827
        "app_id": app_id,
        "score_json": score_json,
        "artifact_path": score_path,
        "overall_weighted": overall,          # float|None
        "dimensions": dimensions,             # sorted list[str]
        "score_narrative": self._agent_narrative(score_result),
    }
```

### 5.2 Branches: **0** explicit branches in `_score_app` itself (linear). All branching is
delegated to `_compute_overall_readiness` (§2.6, 8 branches) and the helpers
`_validate_artifact_or_warn`/`_commit_artifact`/`_commit_output_files`/`_primary_output_content`.

### 5.3 Activity calls (`_score_app`), in order
| # | Activity | Args | Timeout | Retry | Notes |
|---|----------|------|---------|-------|-------|
| 1 | `dispatch_agent_task` | `task_type="wave-per-app-portfolio-score"`, 12 input paths + optional | **1h** | **agent_failure** | reads wave-context (cited by modernization-complexity dim) |
| 2 | `validate_artifact_against_schema` | via `_validate_artifact_or_warn` | 30s | transient | advisory |
| 3 | commit + companions | | 60s/120s | transient | |

> ⚠️ **GOTCHA-SC1 (`overall_weighted` computed in-workflow, deterministic):** `_score_app` does
> NOT round-trip a DB activity to compute the weighted overall — it calls the **pure**
> `_compute_overall_readiness(score_json)` (`wr.py:3817`). DB persistence is deferred to the
> post-G-DA `_project_per_app_side_effects` (§6). A rebuild must compute `overall_weighted` purely
> here (no activity) so the sequencer can read it without a DB hit, and must not write
> `application.portfolio_score` here.
> ⚠️ **GOTCHA-SC2 (`score_json` from `output_files`):** like disposition, `score_json` is the
> workspace JSON via `_primary_output_content` (§5.2/§"primary output"). Reading
> `output_artifacts[0]` would feed prose to `_compute_overall_readiness`, which then returns
> `(None, [])` for every app and blanks the heat map (the documented 2026-05-19 regression,
> `wr.py:3781-3785`).

---

## 6. `_project_per_app_side_effects(...)` — post-G-DA parallel projection (`wr.py:3833-3890`)

**Signature** (`wr.py:3833-3839`):
```text
async def _project_per_app_side_effects(self, input, classification_results, per_app_results, portfolio_scores) -> None
```
**Called from:** `_execute` AFTER G-DA approves (`wr.py:2927`). Runs once per wave. **This is the
transactional boundary for Rationalization's DB ownership** — all per-app `application` writes
happen here, after the gate, so rework can't leave the DB half-projected (`wr.py:3840-3853`).

### 6.1 Control-flow pseudocode
```text
async def _project_per_app_side_effects(self, input, classification_results, per_app_results, portfolio_scores):
    projection_tasks = []                                  # wr.py:3855
    for app_id in input.app_ids:                           # wr.py:3856  LOOP (build futures)
        cls   = classification_results.get(app_id, {})     # wr.py:3857
        disp  = per_app_results.get(app_id, {})            # wr.py:3858
        score = portfolio_scores.get(app_id, {})           # wr.py:3859
        projection_tasks.append(                           # wr.py:3860
            workflow.execute_activity(                      # ★ NOT awaited here — future collected
                persist_rationalization_side_effects,
                PersistRationalizationSideEffectsInput(
                    app_id=app_id,
                    classification_json=cls.get("cls_json", "") or "",                       # wr.py:3865
                    portfolio_score_json=score.get("score_json", "") or "",                  # wr.py:3866
                    disposition_recommendation_json=(disp.get("disposition_json", "") or ""),# wr.py:3867
                    disposition_rationale_ref=(disp.get("disposition_path", "") or ""),      # wr.py:3870
                    tier_1_approved=app_id in self._tier1_approved_apps,                      # wr.py:3873  ★set membership
                ),
                start_to_close_timeout=timedelta(seconds=60),     # wr.py:3875
                retry_policy=RETRY_POLICIES["transient"],         # wr.py:3876
            )
        )

    results = await asyncio.gather(*projection_tasks, return_exceptions=True)   # wr.py:3880  ★parallel, exceptions captured
    for app_id, result in zip(input.app_ids, results):    # wr.py:3881  LOOP (drain results)
        if isinstance(result, BaseException):             # wr.py:3882  ★BRANCH (best-effort)
            workflow.logger.warning(
                "persist_rationalization_side_effects failed for app",
                extra={"app_id": app_id, "wave_id": input.wave_id, "error": repr(result)})   # wr.py:3883-3889
    # returns None implicitly
```

### 6.2 Branch inventory (`_project_per_app_side_effects`): **2 loops + 1 branch**
- `for app_id in input.app_ids` (build futures, `wr.py:3856`).
- `await asyncio.gather(*projection_tasks, return_exceptions=True)` (`wr.py:3880`).
- `for app_id, result in zip(…)` (drain, `wr.py:3881`) + `if isinstance(result, BaseException):` (`wr.py:3882`) — log only.

### 6.3 Activity call
- `persist_rationalization_side_effects` — `PersistRationalizationSideEffectsInput(…)`; **60s**;
  `transient`; **no `activity_id`**; one per app, all started before the single `gather`.

> ⚠️ **GOTCHA-PR-SE1 (`return_exceptions=True` → wave never fails on a bad projection):** the
> `gather` captures exceptions instead of propagating (`wr.py:3880`); the drain loop logs each
> `BaseException` and continues (`wr.py:3881-3889`). So a single malformed artifact can't block
> the wave from advancing to `wave-outcome-synthesis`. A rebuild MUST use `return_exceptions=True`
> and log-not-raise. (Note: `persist_rationalization_side_effects` IS in
> `TERMINAL_FAILURE_ACTIVITIES` (`wr.py:316`) — but that classifier only fires when the activity
> failure PROPAGATES to `run()`'s outer except; here it never propagates because of
> `return_exceptions=True`. The two facts coexist: a side-effect failure during the per-app fan-out
> (in `_per_app_pipeline`, where it would propagate) is terminal, but in THIS post-G-DA projection
> it is swallowed.)
> ⚠️ **GOTCHA-PR-SE2 (`… or ""` double-defaults):** each JSON field uses
> `dict.get(key, "") or ""` (`wr.py:3865-3872`) so a missing key OR a `None`/falsy value both
> normalize to `""`. A rebuild must keep the double-default; passing `None` would break the
> activity's str-typed input.
> ⚠️ **GOTCHA-PR-SE3 (`tier_1_approved` from the live set):** `app_id in self._tier1_approved_apps`
> (`wr.py:3873`) is read at projection time — by post-G-DA all Tier-1 approvals have landed (the
> per-app pauses in `_classify_app` already blocked on them). A rebuild reads the set membership
> at projection time, not a cached bool.

---

## 7. `_compute_pending_target_dispatch_entries(...)` — v2 target preview (`wr.py:3896-3972`)

**Signature** (`wr.py:3896-3900`):
```text
def _compute_pending_target_dispatch_entries(self, per_app_results, legacy_entries) -> list[PendingTargetDispatchEntry]
```
**Called from:** `_execute_architecture_data_fanout` (sibling) right before the pre-dispatch hold,
fed the v1 `legacy_entries` produced by `_compute_pending_dispatch_entries` (`wr.py:4486-4490`).
Synchronous (no `await`).

### 7.1 Control-flow pseudocode
```text
def _compute_pending_target_dispatch_entries(self, per_app_results, legacy_entries):
    if not workflow.patched("architecture-target-plan-v1"):   # wr.py:3921  ★BRANCH 1 (patch gate)
        return []                                             # wr.py:3922  ← pre-patch replay safety

    def _resolve_name(app_id):                                # wr.py:3924  nested helper
        result = per_app_results.get(app_id)                  # wr.py:3925
        if isinstance(result, dict):                          # wr.py:3926  ★BRANCH 2
            name = result.get("app_name") or result.get("name") or ""   # wr.py:3927
            if isinstance(name, str):                         # wr.py:3928  ★BRANCH 3
                return name                                   # wr.py:3929
        return ""                                             # wr.py:3930

    out = []                                                  # wr.py:3932
    for entry in legacy_entries:                              # wr.py:3933  LOOP
        disposition = entry.disposition or ""                 # wr.py:3934
        relationship_lower = _normalize_relationship(disposition)   # wr.py:3935
        if disposition == "Retire":                           # wr.py:3936  ★BRANCH 4
            continue                                          # wr.py:3939  ← Retire never dispatched
        source_ids = [entry.source_app_id]                    # wr.py:3940
        if (disposition == "Consolidate" and entry.peer_source_app_ids):   # wr.py:3941-3944  ★BRANCH 5
            for peer in entry.peer_source_app_ids:            # wr.py:3946  LOOP
                if peer and peer not in source_ids:           # wr.py:3947  ★BRANCH 6
                    source_ids.append(peer)                   # wr.py:3948
        source_names = [_resolve_name(sid) for sid in source_ids]   # wr.py:3949
        slug_seed = entry.source_app_id                       # wr.py:3953
        target_name_seed = ""                                 # wr.py:3954
        target_repo_slug = (                                  # wr.py:3955  ★BRANCH 7 (ternary)
            f"target/{slug_seed}-{relationship_lower}" if relationship_lower
            else f"target/{slug_seed}")
        out.append(PendingTargetDispatchEntry(                # wr.py:3960
            target_app_id=f"target-{slug_seed}",
            target_service_id="",                             # wr.py:3963  not yet resolved
            target_name_seed=target_name_seed,                # = ""
            target_repo_slug=target_repo_slug,
            relationship=relationship_lower,
            source_app_ids=source_ids,
            source_app_names=source_names,
            rationale=""))
    return out                                                # wr.py:3972
```

### 7.2 Branch inventory: **7 branches + 2 loops** (`wr.py:3921,3926,3928,3936,3941-3944,3946,3947,3955`).

> ⚠️ **GOTCHA-CPTD1 (patch gate `architecture-target-plan-v1` — verbatim):** the whole method
> returns `[]` unless `workflow.patched("architecture-target-plan-v1")` (`wr.py:3921`). Exact
> string; load-bearing for replay of pre-patch wave histories. A rebuild must use this exact id.
> ⚠️ **GOTCHA-CPTD2 (Retire rows dropped):** `if disposition == "Retire": continue` (`wr.py:3936`)
> — Retire targets are never dispatched, so the v2 preview shows only actionable rows. The v1
> builder (§8) does NOT drop Retire (it emits them with whatever disposition string). A rebuild
> must drop Retire HERE but not in §8.
> ⚠️ **GOTCHA-CPTD3 (`target_app_id=f"target-{source_app_id}"` is a synthetic preview id):** at the
> pre-dispatch hold the wave-scoped `architecture-target-plan.json` doesn't exist yet
> (`wr.py:3905-3909`), so the target id is synthesized from the anchor source id. The real
> `target_app_id` (SF3 slug) only arrives in the dispatch signal. A rebuild reproduces the
> `f"target-{slug_seed}"` synthetic form.
> ⚠️ **GOTCHA-CPTD4 (peer dedup preserves order, anchor-first):** peers are appended only if
> `peer and peer not in source_ids` (`wr.py:3947`) so `source_ids` is `[anchor, *unique-peers]` in
> insertion order. A rebuild must dedup with anchor first.

---

## 8. `_compute_pending_dispatch_entries(...)` — v1 per-app preview (`wr.py:3974-4054`)

**Signature:** `def _compute_pending_dispatch_entries(self, per_app_results) -> list[PendingDispatchEntry]` (`wr.py:3974-3977`).
**Called from:** `_execute_architecture_data_fanout` (sibling) at `wr.py:4479-4481`. Synchronous. Two passes over `per_app_results`.

### 8.1 Control-flow pseudocode
```text
def _compute_pending_dispatch_entries(self, per_app_results):
    entries = []                                  # wr.py:3989
    consumed_as_peer = set()                       # wr.py:3992

    # ---- Pass 1: find Consolidate anchors + their peer sets -------------
    anchor_for_peer = {}                           # wr.py:3999  (built but ⚠️ never read after — see GOTCHA-CPD3)
    for app_id, result in per_app_results.items(): # wr.py:4000  LOOP (pass 1)
        disp_json = result.get("disposition_json", "") if isinstance(result, dict) else ""   # wr.py:4001  ★BRANCH
        parsed = parse_agent_json(disp_json) if disp_json else None   # wr.py:4002  ★BRANCH
        if not isinstance(parsed, dict):           # wr.py:4003  ★BRANCH
            continue                               # wr.py:4004
        target_hint = parsed.get("target_hint") or {}   # wr.py:4005
        if not isinstance(target_hint, dict):      # wr.py:4006  ★BRANCH
            continue                               # wr.py:4007
        kind = str(target_hint.get("kind") or "")  # wr.py:4008
        if kind == "consolidate-target":           # wr.py:4009  ★BRANCH
            peers_raw = target_hint.get("peer_app_ids") or []                      # wr.py:4010
            peers = [str(p) for p in peers_raw if isinstance(p, str) and p]        # wr.py:4011  (filter blanks/non-str)
            anchor_for_peer[app_id] = (app_id, peers)   # wr.py:4012
            for p in peers:                         # wr.py:4013  LOOP
                consumed_as_peer.add(p)             # wr.py:4014

    # ---- Pass 2: emit one PendingDispatchEntry per non-peer app ---------
    for app_id, result in per_app_results.items(): # wr.py:4016  LOOP (pass 2)
        disp_json = result.get("disposition_json", "") if isinstance(result, dict) else ""   # wr.py:4017  ★BRANCH
        disposition = ""; target_hint_kind = ""; peers = []   # wr.py:4018-4020
        if disp_json:                              # wr.py:4021  ★BRANCH
            parsed = parse_agent_json(disp_json)   # wr.py:4022
            if isinstance(parsed, dict):           # wr.py:4023  ★BRANCH
                disposition = str(                  # wr.py:4025
                    parsed.get("recommended_disposition")
                    or parsed.get("disposition")
                    or "")
                th = parsed.get("target_hint") or {}   # wr.py:4030
                if isinstance(th, dict):           # wr.py:4031  ★BRANCH
                    target_hint_kind = str(th.get("kind") or "")   # wr.py:4032
                    peers_raw = th.get("peer_app_ids") or []        # wr.py:4033
                    peers = [str(p) for p in peers_raw if isinstance(p, str) and p]   # wr.py:4034
        if disposition == "Consolidate":           # wr.py:4039  ★BRANCH
            if target_hint_kind == "consolidate-source" or app_id in consumed_as_peer:   # wr.py:4040  ★BRANCH (compound)
                continue                           # wr.py:4041  ← skip consolidate-source / absorbed peers
            if target_hint_kind != "consolidate-target":   # wr.py:4042  ★BRANCH
                pass                               # wr.py:4045  ← legacy/unclear hint: emit anyway (no-op branch)
        entries.append(                            # wr.py:4046
            PendingDispatchEntry(
                source_app_id=app_id,
                disposition=disposition,
                target_hint_kind=target_hint_kind,
                peer_source_app_ids=peers))
    return entries                                 # wr.py:4054
```

### 8.2 Branch inventory: **~14 branches + 4 loops** across the two passes (`wr.py:4000,4001,4002,4003,4006,4009,4013,4016,4017,4021,4023,4031,4039,4040,4042`).

> ⚠️ **GOTCHA-CPD1 (`recommended_disposition` OR `disposition` fallback):** pass 2 reads
> `parsed.get("recommended_disposition") or parsed.get("disposition") or ""` (`wr.py:4025-4029`) —
> spec-compliant field first, legacy field fallback. Pass 1 / `_per_app_pipeline` only read
> `recommended_disposition`. A rebuild keeps the OR fallback HERE.
> ⚠️ **GOTCHA-CPD2 (Consolidate skip rule):** a Consolidate row is emitted ONLY for the anchor.
> Skip when `target_hint_kind == "consolidate-source"` OR `app_id in consumed_as_peer`
> (`wr.py:4040`). A `consolidate-target` (or unclear/legacy) anchor is emitted with its peer list.
> A rebuild MUST keep both skip conditions; dropping `app_id in consumed_as_peer` would emit
> duplicate rows for apps already folded into an anchor.
> ⚠️ **GOTCHA-CPD3 (`anchor_for_peer` is built but its VALUE is never consumed):** pass 1 populates
> `anchor_for_peer[app_id] = (app_id, peers)` (`wr.py:4012`) but the dict is never read afterward —
> only `consumed_as_peer` (the side-effect set) drives pass 2. This is dead-ish bookkeeping a
> rebuild may keep for parity but need not consult. Do NOT rely on `anchor_for_peer` for any
> decision; only `consumed_as_peer` matters.
> ⚠️ **GOTCHA-CPD4 (`if … != "consolidate-target": pass`):** `wr.py:4042-4045` is a literal no-op
> `pass` documenting "legacy/unclear target_hint — emit anyway with empty-ish peer list". A rebuild
> must NOT add a `continue` here — the row IS emitted. This branch exists purely as a documented
> fall-through.
> ⚠️ **GOTCHA-CPD5 (Retire NOT dropped here):** unlike §7, this v1 builder emits a row for every
> non-peer app regardless of disposition (including `"Retire"`). Retire filtering happens later
> (in the v2 builder §7 and at provisioning). A rebuild must NOT drop Retire in this method.

---

## 9. `_dispatch_key` + `_init_dispatch_status` + `_normalize_dispatch_payload` (`wr.py:4056-4202`)

### 9.1 `_dispatch_key(cfg) -> str` — `@staticmethod`, `wr.py:4056-4066`
```text
@staticmethod
def _dispatch_key(cfg):
    return cfg.target_app_id or cfg.source_app_id   # wr.py:4066
```
Unique key for `_dispatch_status` + `_v2_dispatch_meta` lookups. v2 carries per-target
`target_app_id` (so N targets can share an anchor `source_app_id`); v1 has one target per source
so `source_app_id` is unique enough. ⚠️ **GOTCHA-DK1:** prefer `target_app_id`, fall back to
`source_app_id`. A rebuild must use `or` (truthy fallback) — an empty `target_app_id` falls back.

### 9.2 `_init_dispatch_status(payload) -> None` — `wr.py:4068-4097`
```text
def _init_dispatch_status(self, payload):
    for cfg in payload.targets:                          # wr.py:4084  LOOP
        key = cfg.target_app_id or cfg.source_app_id     # wr.py:4085  (== _dispatch_key(cfg))
        v2_meta = self._v2_dispatch_meta.get(cfg.target_app_id, {})   # wr.py:4086  ★keyed by target_app_id
        self._dispatch_status[key] = DispatchTargetStatus(            # wr.py:4087
            source_app_id=cfg.source_app_id,
            target_app_name=cfg.target_app_name,
            target_repo=cfg.target_repo,
            disposition=cfg.disposition,
            status="pending",                            # wr.py:4092
            source_app_ids=([cfg.source_app_id] + list(cfg.peer_source_app_ids or [])),   # wr.py:4093-4095
            target_service_id=v2_meta.get("target_service_id", ""),   # wr.py:4096
        )
```
**Called from:** `_execute_architecture_data_fanout` once when the dispatch signal lands
(`wr.py:4509`), so queries return a stable shape during the gather. ⚠️ **GOTCHA-IDS1
(`_v2_dispatch_meta` lookup keyed by `cfg.target_app_id`, NOT `key`):** `v2_meta` is fetched with
`cfg.target_app_id` (`wr.py:4086`) — and `_v2_dispatch_meta` itself is keyed by `target_app_id`
(see `_extract_v2_metadata`, sibling). For v1 payloads `cfg.target_app_id == ""`, so `v2_meta` is
`{}` and `target_service_id=""`. A rebuild must look up `_v2_dispatch_meta` by `target_app_id`,
not by `key`. ⚠️ **GOTCHA-IDS2 (status seeded `"pending"`):** the `DispatchTargetStatus.status`
DEFAULT is `"pending"` but this explicitly sets it; the per-row `status` then transitions
`pending → provisioning (_provision_one_target) → provisioned (caller) → architecture_in_flight
(_spawn_children) → completed/failed (caller)`. A rebuild seeds `"pending"`. **0 branches** (one
loop). The `peer_source_app_ids or []` is the only defensive normalization.

### 9.3 `_normalize_dispatch_payload(payload) -> DispatchArchitecturePayload` — `@staticmethod`, `wr.py:4099-4202`
Coerces v1 dataclass / v2 dataclass / wire-dict into the canonical **v1** shape the rest of the
workflow consumes. ⚠️ This is the single most branch-dense method in this file.

```text
@staticmethod
def _normalize_dispatch_payload(payload):
    # ---- Case 1: already v1 dataclass (or empty) ------------------------
    if isinstance(payload, DispatchArchitecturePayload):   # wr.py:4122  ★BRANCH 1
        return payload                                     # wr.py:4123  ← pass through unchanged

    # ---- Case 2: v2 dataclass → map each target to v1 -------------------
    if isinstance(payload, DispatchArchitecturePayloadV2): # wr.py:4124  ★BRANCH 2
        return DispatchArchitecturePayload(
            targets=[
                DispatchArchitectureTargetConfig(
                    source_app_id=((t.source_app_ids[0] if t.source_app_ids else "")),   # wr.py:4128-4130  ★BRANCH (anchor)
                    target_app_name=t.target_app_name,
                    target_repo=t.target_repo,
                    disposition=_legacy_disposition_from_relationship(t.relationship),   # wr.py:4136  (normalize→Title)
                    default_branch=t.default_branch or "main",                            # wr.py:4139  ★BRANCH
                    peer_source_app_ids=list(t.source_app_ids[1:]),                       # wr.py:4140  (rest of cluster)
                    target_app_id=t.target_app_id,                                        # wr.py:4145  ★preserve identity
                )
                for t in payload.targets                   # wr.py:4147  LOOP
            ])

    # ---- Case 3: wire-dict (dict-of-dicts) ------------------------------
    if isinstance(payload, dict):                          # wr.py:4151  ★BRANCH 3
        raw_targets = payload.get("targets", [])           # wr.py:4152
        if not isinstance(raw_targets, list):              # wr.py:4153  ★BRANCH
            return DispatchArchitecturePayload(targets=[]) # wr.py:4154  ← malformed → empty
        v2_shape = any(                                    # wr.py:4155  (sniff: any entry has target_app_id)
            isinstance(t, dict) and ("target_app_id" in t) for t in raw_targets)   # wr.py:4156-4158
        if v2_shape:                                       # wr.py:4159  ★BRANCH
            v2_targets = []                                # wr.py:4160
            for t in raw_targets:                          # wr.py:4161  LOOP
                if not isinstance(t, dict):                # wr.py:4162  ★BRANCH
                    continue                               # wr.py:4163
                src_ids_raw = t.get("source_app_ids") or []   # wr.py:4164
                src_ids = [str(s) for s in src_ids_raw if isinstance(s, str) and s]   # wr.py:4165-4168
                disposition = _legacy_disposition_from_relationship(t.get("relationship"))   # wr.py:4172
                v2_targets.append(
                    DispatchArchitectureTargetConfig(
                        source_app_id=src_ids[0] if src_ids else "",                    # wr.py:4177  ★BRANCH
                        target_app_name=str(t.get("target_app_name") or ""),
                        target_repo=str(t.get("target_repo") or ""),
                        disposition=disposition,
                        default_branch=str(t.get("default_branch") or "main"),          # wr.py:4181-4183
                        peer_source_app_ids=list(src_ids[1:]),
                        target_app_id=str(t.get("target_app_id") or ""),
                    ))
            return DispatchArchitecturePayload(targets=v2_targets)   # wr.py:4188
        # ---- wire-dict but v1 shape ------------------------------------
        return DispatchArchitecturePayload(                # wr.py:4190
            targets=[
                (DispatchArchitectureTargetConfig(**t) if isinstance(t, dict) else t)   # wr.py:4193  ★BRANCH (kwargs-splat)
                for t in raw_targets                        # wr.py:4191  LOOP
            ])

    # ---- Case 4: unknown type → empty ----------------------------------
    return DispatchArchitecturePayload(targets=[])         # wr.py:4202  ← short-circuit to "completed"
```

**Branch inventory (`_normalize_dispatch_payload`): ~14 branches + 3 loops**
(`wr.py:4122,4124,4128,4139,4151,4153,4159,4162,4177,4181,4193` + comprehension loops). Key
decision points: (1) v1 dataclass → pass-through; (2) v2 dataclass → per-target map; (3) dict →
sniff `v2_shape` via `any(... "target_app_id" in t ...)` then v2-map or v1-kwargs-splat; (4)
unknown → empty.

> ⚠️ **GOTCHA-NDP1 (anchor = `source_app_ids[0]`, peers = `source_app_ids[1:]`):** the v2→v1
> projection takes the FIRST source as the anchor `source_app_id` and the REST as
> `peer_source_app_ids` (`wr.py:4128-4140`, `wr.py:4177-4184`). The schema guarantees minItems:1 so
> `[0]` is "always safe" — but the code STILL guards with `if t.source_app_ids else ""` /
> `if src_ids else ""`. A rebuild must keep the guard AND the anchor/peers split.
> ⚠️ **GOTCHA-NDP2 (disposition is Title-cased via `_legacy_disposition_from_relationship`):** the
> v1 `disposition` field must be 7R Title-case ("Consolidate") because `create_target_app_and_repo`
> expects it (`wr.py:4133-4138`, `wr.py:4169-4172`). The v2 `relationship` is lowercase; the
> projection upcases the first char. A rebuild must route through
> `_legacy_disposition_from_relationship`, not pass `relationship` through raw.
> ⚠️ **GOTCHA-NDP3 (`v2_shape` sniff is "ANY entry has `target_app_id`"):** `wr.py:4155-4158` uses
> `any(...)` — if even ONE wire target carries `target_app_id`, the WHOLE payload is treated as v2.
> A rebuild must use `any`, not `all`. Entries that aren't dicts are skipped inside the v2 loop
> (`wr.py:4162-4163`).
> ⚠️ **GOTCHA-NDP4 (`default_branch or "main"` everywhere):** every path defaults an empty/missing
> `default_branch` to `"main"` (`wr.py:4139`, `wr.py:4181-4183`). A rebuild must default.
> ⚠️ **GOTCHA-NDP5 (unknown payload → empty, NOT raise):** Case 4 (`wr.py:4200-4202`) returns an
> empty `DispatchArchitecturePayload` for any unrecognized type so a malformed signal makes the
> workflow short-circuit to `"completed"` (the caller treats empty `payload.targets` as "no fan-out
> needed", `wr.py:4503-4507`). A rebuild must NOT raise on unknown input.
> ⚠️ **GOTCHA-NDP6 (v1 wire-dict uses `**t` kwargs splat):** the v1 wire path does
> `DispatchArchitectureTargetConfig(**t)` (`wr.py:4193`) — so an extra/unknown key in a wire dict
> would raise `TypeError`. This is the legacy v1 path; a rebuild must splat (not field-by-field) to
> match.

---

## 10. `_provision_one_target(...)` — provision one target app+repo (`wr.py:4204-4245`)

**Signature:** `async def _provision_one_target(self, cfg, input) -> CreateTargetAppAndRepoResult` (`wr.py:4204-4208`).
**Called from:** `_execute_architecture_data_fanout` under
`asyncio.gather(*[self._provision_one_target(cfg, input) for cfg in payload.targets],
return_exceptions=True)` (`wr.py:4518-4523`), AND in the retry-drain loop (`wr.py:4718`). So **N
run in parallel**, and a raise here surfaces as a per-entry exception in the gather (the caller
records `status="failed"`, `wr.py:4528-4538`).

### 10.1 Control-flow pseudocode
```text
async def _provision_one_target(self, cfg, input):
    self._dispatch_status[self._dispatch_key(cfg)].status = "provisioning"   # wr.py:4220  ★mutate status (KeyError if not seeded)
    full_source_ids = ([cfg.source_app_id] + list(cfg.peer_source_app_ids or []))   # wr.py:4221-4223
    status = self._dispatch_status.get(self._dispatch_key(cfg))    # wr.py:4227  (.get — tolerant read)
    target_service_id = status.target_service_id if status else ""  # wr.py:4228  ★BRANCH
    return await workflow.execute_activity(                         # wr.py:4229
        create_target_app_and_repo,
        CreateTargetAppAndRepoInput(
            source_app_id=cfg.source_app_id,
            target_app_name=cfg.target_app_name,
            target_repo=cfg.target_repo,
            default_branch=cfg.default_branch,
            wave_id=input.wave_id,
            portfolio_id=input.portfolio_id,
            disposition=cfg.disposition,                  # Title-cased
            peer_source_app_ids=list(cfg.peer_source_app_ids),   # wr.py:4239
            source_app_ids=full_source_ids,               # wr.py:4240  full set (anchor+peers)
            target_service_id=target_service_id,          # wr.py:4241
        ),
        start_to_close_timeout=timedelta(minutes=5),       # wr.py:4243  ★5 MINUTES
        retry_policy=RETRY_POLICIES["transient"],          # wr.py:4244
    )
```

### 10.2 Branches: **1** (`target_service_id = status.target_service_id if status else ""`, `wr.py:4228`).

### 10.3 Activity call
- `create_target_app_and_repo` — `CreateTargetAppAndRepoInput(…)`; **5 min** start_to_close;
  `transient` (3 attempts); **no `activity_id`** (idempotency is on the activity side via
  `target_repo_url` short-circuit + HTTP-422→`NonRetryableError`, see types.py
  `CreateTargetAppAndRepoInput` docstring).

> ⚠️ **GOTCHA-POT1 (`[self._dispatch_key(cfg)]` indexing raises `KeyError` if not seeded):** line
> 4220 uses **subscript** `self._dispatch_status[self._dispatch_key(cfg)].status = "provisioning"`,
> which raises if `_init_dispatch_status` hasn't seeded the key. The caller ALWAYS calls
> `_init_dispatch_status(payload)` before the provision gather (`wr.py:4509`), so the key exists. A
> rebuild must seed first; do not convert this to a `.get()` (the subscript-write is intentional —
> it mutates the seeded entry). The LATER read at `wr.py:4227` uses `.get()` (tolerant) only to
> resolve `target_service_id`. Keep the asymmetry.
> ⚠️ **GOTCHA-POT2 (`source_app_ids` = full set, but `peer_source_app_ids` also passed):** the
> activity input carries BOTH `peer_source_app_ids=list(cfg.peer_source_app_ids)` AND
> `source_app_ids=[anchor]+peers` (`wr.py:4239-4240`). The activity prefers `source_app_ids` when
> populated, falling back to `[source_app_id]+peer_source_app_ids` for v1 (types.py
> `CreateTargetAppAndRepoInput`). A rebuild must pass both for forward/back compat.
> ⚠️ **GOTCHA-POT3 (5-minute timeout, transient retry):** provisioning includes repo creation (a
> Git provider round-trip) so it gets **5 min** (not the 30-60s of other activities) and `transient`
> retry. A rebuild must use 5 min + transient here.
> ⚠️ **GOTCHA-POT4 (`create_target_app_and_repo` is RECOVERABLE):** this activity is in
> `RECOVERABLE_FAILURE_ACTIVITIES` (`wr.py:285`). If it raises and the exception propagates to
> `run()`'s outer except, the wave flips to `stuck-awaiting-recovery` (resumable). But in the
> fan-out gather the exception is caught via `return_exceptions=True` (caller, `wr.py:4521`) and
> recorded as a per-target `status="failed"` — it does NOT propagate. So a single provisioning
> failure leaves the wave running and surfaces in `dispatch_results` for UI retry, while a
> propagating provisioning failure (rare) is recoverable.

---

## 11. `_spawn_children_for_target(...)` — start Architecture + Data children (`wr.py:4247-4434`)

**Signature** (`wr.py:4247-4253`):
```text
async def _spawn_children_for_target(self, cfg, provisioned, input, run_ts) -> tuple[ChildWorkflowHandle, ChildWorkflowHandle]
```
**Called from:** `_execute_architecture_data_fanout` for each successfully-provisioned target
(`wr.py:4542`) and in the retry drain (`wr.py:4725`). Returns `(arch_handle, data_handle)`.

### 11.1 Control-flow pseudocode
```text
async def _spawn_children_for_target(self, cfg, provisioned, input, run_ts):
    target_app_id = provisioned.target_app_id              # wr.py:4259  ★real target id from activity result
    arch_workflow_id = f"architecture-{target_app_id}-{run_ts}"   # wr.py:4260  ★deterministic id
    data_workflow_id = f"data-{target_app_id}-{run_ts}"           # wr.py:4261

    # ---- Resolve relationship + service id + full source set ------------
    v2_meta = self._v2_dispatch_meta.get(cfg.target_app_id, {})   # wr.py:4273  (keyed by target_app_id)
    relationship = (                                              # wr.py:4274  ★BRANCH (or-chain)
        _normalize_relationship(v2_meta.get("relationship"))
        or _normalize_relationship(cfg.disposition))
    status = self._dispatch_status.get(self._dispatch_key(cfg))   # wr.py:4278
    target_service_id = (                                         # wr.py:4279  ★BRANCH (or-chain)
        (status.target_service_id if status else "")
        or v2_meta.get("target_service_id", ""))
    full_source_ids = (                                           # wr.py:4283  ★BRANCH (ternary)
        list(status.source_app_ids) if status and status.source_app_ids
        else [cfg.source_app_id] + list(cfg.peer_source_app_ids or []))

    # ---- Resolve source-app repo URLs (activity) ------------------------
    source_repos_result = await workflow.execute_activity(        # wr.py:4300
        fetch_application_source_repos,
        FetchSourceReposInput(source_app_ids=list(full_source_ids)),
        start_to_close_timeout=timedelta(seconds=30),             # wr.py:4303
        retry_policy=RETRY_POLICIES["transient"],                 # wr.py:4304
        activity_id=f"fetch-source-repos-{target_app_id}",        # wr.py:4305  ★stable id
    )
    anchor_source_repo = source_repos_result.anchor_source_repo   # wr.py:4307
    source_repos_map = dict(source_repos_result.source_repos)     # wr.py:4308
    if not anchor_source_repo:                                    # wr.py:4309  ★BRANCH (warn only)
        workflow.logger.warning("no source_repo resolved for anchor source app", extra={…})   # wr.py:4310-4319

    # ---- Build Architecture child input ---------------------------------
    peer_ids = {"Data": data_workflow_id}                         # wr.py:4321
    arch_input = LineWorkflowInput(                               # wr.py:4322
        app_id=target_app_id,
        app_name=cfg.target_app_name or target_app_id,           # wr.py:4324  ★BRANCH (or-default)
        wave_id=input.wave_id, portfolio_id=input.portfolio_id,
        artifact_repo=input.artifact_repo,
        source_repo=anchor_source_repo,
        source_repos=source_repos_map,
        target_repo_url=provisioned.target_repo_url,
        disposition=None,                                         # wr.py:4331  ★Architecture resolves from DB
        peer_workflow_ids=peer_ids,
        target_service_id=target_service_id,
        relationship=relationship,
        source_app_ids=list(full_source_ids),
    )

    # ---- Build Data child input (+ Discovery data priors, patch-gated) --
    data_prior = []                                               # wr.py:4345
    if workflow.patched("discovery-data-steps-v1"):               # wr.py:4346  ★BRANCH (patch gate)
        source_ids = [cfg.source_app_id] + list(cfg.peer_source_app_ids or [])   # wr.py:4347
        for src in source_ids:                                    # wr.py:4348  LOOP
            if not src:                                           # wr.py:4349  ★BRANCH
                continue                                          # wr.py:4350
            data_prior.append(f"discovery/{src}/data-domains.json")        # wr.py:4351
            data_prior.append(f"discovery/{src}/shared-db-analysis.json")  # wr.py:4352
    data_input = LineWorkflowInput(                               # wr.py:4353
        app_id=target_app_id,
        app_name=cfg.target_app_name or target_app_id,
        wave_id=input.wave_id, portfolio_id=input.portfolio_id,
        artifact_repo=input.artifact_repo,
        source_repo=anchor_source_repo, source_repos=source_repos_map,
        target_repo_url=provisioned.target_repo_url,
        disposition=None,
        peer_workflow_ids={"Architecture": arch_workflow_id},     # wr.py:4363
        prior_artifacts=data_prior,
        target_service_id=target_service_id, relationship=relationship,
        source_app_ids=list(full_source_ids),
    )

    # ---- Start the two children (sibling-lifecycle patch-gated) ---------
    if workflow.patched("arch-data-sibling-lifecycle-v1"):        # wr.py:4380  ★BRANCH (patch gate)
        arch_handle = await workflow.start_child_workflow(
            "ArchitectureWorkflow", arch_input, id=arch_workflow_id,
            parent_close_policy=workflow.ParentClosePolicy.ABANDON)   # wr.py:4381-4386
        data_handle = await workflow.start_child_workflow(
            "DataWorkflow", data_input, id=data_workflow_id,
            parent_close_policy=workflow.ParentClosePolicy.ABANDON)   # wr.py:4387-4392
    else:
        arch_handle = await workflow.start_child_workflow(
            "ArchitectureWorkflow", arch_input, id=arch_workflow_id)  # wr.py:4394-4398
        data_handle = await workflow.start_child_workflow(
            "DataWorkflow", data_input, id=data_workflow_id)          # wr.py:4399-4403

    # ---- Best-effort projection flip (Architecture in flight) -----------
    try:
        await workflow.execute_activity(                          # wr.py:4409
            update_application_line_projection,
            UpdateApplicationLineProjectionInput(
                app_id=target_app_id, line="Architecture",
                workflow_id=arch_workflow_id, status="in_progress"),
            start_to_close_timeout=timedelta(seconds=30),         # wr.py:4417
            retry_policy=RETRY_POLICIES["transient"])             # wr.py:4418
    except Exception as exc:                                      # wr.py:4420  ★BRANCH (best-effort)
        workflow.logger.warning("update_application_line_projection failed (Architecture)", extra={…})

    # ---- Update dispatch status + return handles ------------------------
    status = self._dispatch_status[self._dispatch_key(cfg)]       # wr.py:4429  ★subscript (must exist)
    status.target_app_id = target_app_id                          # wr.py:4430
    status.architecture_workflow_id = arch_workflow_id            # wr.py:4431
    status.data_workflow_id = data_workflow_id                    # wr.py:4432
    status.status = "architecture_in_flight"                      # wr.py:4433
    return arch_handle, data_handle                               # wr.py:4434
```

### 11.2 Branch inventory (`_spawn_children_for_target`): **~9 branches + 1 loop**
`relationship` or-chain (`wr.py:4274`); `target_service_id` or-chain (`wr.py:4279`);
`full_source_ids` ternary (`wr.py:4283`); `if not anchor_source_repo:` (`wr.py:4309`);
`app_name … or target_app_id` (`wr.py:4324,4355`); `if workflow.patched("discovery-data-steps-v1"):`
(`wr.py:4346`) + inner `for src` loop + `if not src` (`wr.py:4348-4350`); `if
workflow.patched("arch-data-sibling-lifecycle-v1"):` (`wr.py:4380`); `except Exception` (`wr.py:4420`).

### 11.3 Activity & child-workflow calls (in order)
| # | Call | Args | Timeout / policy | id | Notes |
|---|------|------|------------------|-----|-------|
| 1 | activity `fetch_application_source_repos` | `FetchSourceReposInput(source_app_ids=full_source_ids)` | 30s / transient | `fetch-source-repos-{target_app_id}` | resolves anchor + per-source repo URLs |
| 2 | child `ArchitectureWorkflow` | `arch_input` (`LineWorkflowInput`) | — | `architecture-{target_app_id}-{run_ts}` | ABANDON parent-close iff `arch-data-sibling-lifecycle-v1` |
| 3 | child `DataWorkflow` | `data_input` | — | `data-{target_app_id}-{run_ts}` | ABANDON iff sibling patch |
| 4 | activity `update_application_line_projection` | `UpdateApplicationLineProjectionInput(app_id=target, line="Architecture", status="in_progress")` | 30s / transient | — | best-effort try/except |

> ⚠️ **GOTCHA-SCT1 (child IDs are deterministic — `{line}-{target_app_id}-{run_ts}`):** `run_ts =
> int(workflow.now().timestamp())` is computed ONCE by the caller (`wr.py:4513`) and threaded in, so
> all targets in one dispatch share the same `run_ts` and each child id is
> `architecture-{target_app_id}-{run_ts}` / `data-{target_app_id}-{run_ts}` (`wr.py:4260-4261`). A
> rebuild MUST derive ids this way (deterministic on replay; unique per target because
> `target_app_id` is unique). Do NOT use `uuid` or per-call `workflow.now()`.
> ⚠️ **GOTCHA-SCT2 (`provisioned.target_app_id` is the REAL id, not `cfg.target_app_id`):** the
> child ids and the `LineWorkflowInput.app_id` use `provisioned.target_app_id` (the activity's
> result, `wr.py:4259`), which for Replace/Consolidate is a freshly-minted UUID and for
> Refactor/Rearchitect/Replatform/Retain equals the source app id. `cfg.target_app_id` (the SF3
> plan slug) is used ONLY to key `_v2_dispatch_meta` (`wr.py:4273`). A rebuild must NOT conflate the
> two — child ids use the provisioned (DB) id, metadata lookups use the plan slug.
> ⚠️ **GOTCHA-SCT3 (both children get `disposition=None`):** `arch_input`/`data_input` set
> `disposition=None` (`wr.py:4331,4362`) — "Architecture resolves from DB on start." A rebuild must
> pass `None`, not `cfg.disposition`. The downstream lines re-read disposition from the
> `application` row.
> ⚠️ **GOTCHA-SCT4 (peer_workflow_ids cross-wire Arch↔Data):** Architecture's input carries
> `peer_workflow_ids={"Data": data_workflow_id}` (`wr.py:4321,4332`) and Data's carries
> `{"Architecture": arch_workflow_id}` (`wr.py:4363`) so each can `signal_external_workflow` the
> other (TargetProvisionedSignal / DataReadyForTargetSignal handshake). ⚠️ But under
> `arch-data-sibling-lifecycle-v1` the children run with `ParentClosePolicy.ABANDON` and signal
> routing is DB-backed (`arch_data_signal_registry`), so sibling lifecycle "does not break peer
> signalling" (`wr.py:4370-4379`). A rebuild must wire both peer maps regardless of the patch.
> ⚠️ **GOTCHA-SCT5 (`discovery-data-steps-v1` patch gates Data's `prior_artifacts`):** the Data
> child's `prior_artifacts` (Discovery `data-domains.json` + `shared-db-analysis.json` per source)
> are added ONLY under `workflow.patched("discovery-data-steps-v1")` (`wr.py:4346`). Pre-patch
> replays leave `data_prior=[]`. ⚠️ Note the inner loop uses `[cfg.source_app_id] +
> cfg.peer_source_app_ids` (`wr.py:4347`) — NOT `full_source_ids` (the status-resolved set). This is
> a subtle divergence: the priors use the cfg-level source set, while `source_app_ids` on the input
> uses `full_source_ids`. A rebuild must reproduce both source-set computations exactly as-is.
> ⚠️ **GOTCHA-SCT6 (sibling-lifecycle patch flips child→sibling):** under
> `arch-data-sibling-lifecycle-v1` (`wr.py:4380`) the children start with
> `parent_close_policy=ABANDON` so they OUTLIVE the parent Rationalization workflow (true top-level
> siblings); without the patch they are ordinary children. The patch id is verbatim & load-bearing
> for replay. A rebuild must gate the ABANDON policy on this exact patch.
> ⚠️ **GOTCHA-SCT7 (`fetch_application_source_repos` stable id; empty-anchor only warns):** the
> fetch has `activity_id=f"fetch-source-repos-{target_app_id}"` (replay-stable). If
> `anchor_source_repo` comes back empty, the code only logs a WARNING (`wr.py:4309-4319`) and
> proceeds — legacy waves without recorded repo_urls still spawn children (skills fall back to
> path-hints). A rebuild must NOT raise on an empty anchor repo.
> ⚠️ **GOTCHA-SCT8 (status mutation AFTER spawning, subscript-write):** the final
> `self._dispatch_status[self._dispatch_key(cfg)]` (`wr.py:4429`) is a subscript (KeyError if
> unseeded — but the caller path guarantees seeding) and sets `target_app_id` /
> `architecture_workflow_id` / `data_workflow_id` / `status="architecture_in_flight"`. Note the
> status lands `"architecture_in_flight"` even though Data is also started (there is no
> `"data_in_flight"` transition emitted here — the caller may advance it). A rebuild sets exactly
> these four fields and leaves status at `"architecture_in_flight"`.
> ⚠️ **GOTCHA-SCT9 (the projection flip happens AFTER both children start, best-effort):** the
> `update_application_line_projection` activity (`wr.py:4408-4427`) runs after both
> `start_child_workflow` calls and is wrapped in try/except (logs, never raises). It is in
> `RECOVERABLE_FAILURE_ACTIVITIES` (`wr.py:292`) but here cannot propagate (caught locally). A
> rebuild must place it after the spawns and swallow its exceptions.

---

## 12. `_update_wave_status_safe(...)` — best-effort wave-status flip (`wr.py:4436-4463`)

**Signature:** `async def _update_wave_status_safe(self, new_status, reason="") -> None` (`wr.py:4436-4440`).
**Called from:** `_execute_architecture_data_fanout` to transition the wave through
`awaiting-architecture-dispatch → … → completed` (`wr.py:4491,4506`, and more in sibling). Used
wherever a wave-status flip should NOT be able to fail the workflow.

```text
async def _update_wave_status_safe(self, new_status, reason=""):
    if not self._wave_id:                          # wr.py:4442  ★BRANCH (guard)
        return                                     # wr.py:4443  ← no wave id → silent no-op
    try:
        await workflow.execute_activity(           # wr.py:4445
            update_wave_status,
            UpdateWaveStatusInput(wave_id=self._wave_id, new_status=new_status, reason=reason),
            start_to_close_timeout=timedelta(seconds=30),   # wr.py:4452
            retry_policy=RETRY_POLICIES["transient"])       # wr.py:4453
    except Exception as exc:                        # wr.py:4455  ★BRANCH (best-effort)
        workflow.logger.warning("update_wave_status failed", extra={
            "wave_id": self._wave_id, "new_status": new_status, "error": repr(exc)})   # wr.py:4456-4462
    # returns None
```

### 12.1 Branches: **2** (`if not self._wave_id: return` `wr.py:4442`; `except Exception` `wr.py:4455`).
### 12.2 Activity: `update_wave_status` — `UpdateWaveStatusInput(…)`; **30s**; `transient`; no `activity_id`.

> ⚠️ **GOTCHA-UWS1 (`update_wave_status` is RECOVERABLE but swallowed here):** `update_wave_status`
> is in `RECOVERABLE_FAILURE_ACTIVITIES` (`wr.py:289`). But this helper wraps it in try/except so a
> failure NEVER propagates — the wave keeps running and the status flip is just lost (the reviewer
> still sees the live status via the `get_status` query, sibling). A rebuild MUST make this
> best-effort (swallow), distinct from the failure-projection calls in `run()`'s outer except (which
> are also best-effort but for a different reason). ⚠️ Contrast: the `update_wave_status` calls in
> `run()`'s recoverable-failure path (`wr.py:1312-1321`, sibling) are the ones that actually flip the
> terminal recovery state; THIS helper is for happy-path transitions only.

---

## 13. RESILIENCE summary (this file)

- **Timeouts (start_to_close):** agent dispatches 1h (`agent_failure`); `load_context_priors` 10s;
  `validate_artifact_against_schema` 30s (via `_validate_artifact_or_warn`); commits 60s
  (`write_artifact`) / 120s (`write_artifacts_batch`); `persist_rationalization_capability_dispositions`
  60s; `persist_rationalization_side_effects` 60s; `create_target_app_and_repo` **5 min**;
  `fetch_application_source_repos` 30s; `update_application_line_projection` 30s;
  `update_wave_status` 30s.
- **Retry policies:** `agent_failure` (3 attempts, 5-60s) for the FOUR per-app skill dispatches
  (disposition, governance, user-impact, classification, portfolio-score); `transient` for
  everything else.
- **Heartbeats:** none configured in this file.
- **continue-as-new:** none in this file (the caller `_execute` does not CAN either).
- **Idempotency / determinism:** stable `activity_id`s on `persist-rat-cap-disp-{wave}-{app}`
  (`wr.py:3419`) and `fetch-source-repos-{target_app_id}` (`wr.py:4305`); deterministic child ids
  `{line}-{target_app_id}-{run_ts}` (`wr.py:4260-4261`); `_compute_overall_readiness` is a pure
  function. ⚠️ The per-app dispatch activities do NOT set `activity_id` — they rely on Temporal's
  command sequencing + the `agent_failure` retry; this is fine because each runs once per coroutine
  and `gather` preserves command order on replay.
- **Patch gates (verbatim, load-bearing for replay):**
  `"wave-rationalization-rat-cap-clustering-v1"` (`wr.py:3399`),
  `"wave-rationalization-batch-writes-v1"` (`wr.py:4931`, via `_commit_artifact`),
  `"architecture-target-plan-v1"` (`wr.py:3921`),
  `"discovery-data-steps-v1"` (`wr.py:4346`),
  `"arch-data-sibling-lifecycle-v1"` (`wr.py:4380`),
  `"wave-rationalization-architecture-dispatch-v1"` (consumed by `cancel_all_children`, sibling).
- **Best-effort (swallow + continue) activities:** `load_context_priors`,
  `persist_rationalization_capability_dispositions`, every `_commit_output_files` companion write,
  the post-G-DA `persist_rationalization_side_effects` (via `return_exceptions=True`),
  `update_application_line_projection`, `update_wave_status` (via `_update_wave_status_safe`).
- **Compensation / rollback:** none in this file. Failure semantics are split by the module-level
  `classify_failure` (`wr.py:327-377`, used in `run()`'s except, sibling): activities here that are
  RECOVERABLE → `create_target_app_and_repo`, `update_wave_status`,
  `update_application_line_projection`; TERMINAL → `dispatch_agent_task`,
  `validate_artifact_against_schema`, `write_artifact`, `create_pr`, `reconcile_and_merge_pr`,
  `persist_rationalization_side_effects`, gate plumbing. ⚠️ But best-effort wrapping (return_exceptions,
  try/except) in THIS file's helpers means most of those classifications only matter when the
  activity failure actually propagates out of the helper (e.g. an un-wrapped agent dispatch in
  `_per_app_pipeline` is terminal; the wrapped rat-cap persist never propagates).
- **Cancellation:** the ONLY blocking wait in this file is `_classify_app`'s Tier-1 pause
  (`wr.py:3700-3702`), whose predicate ORs `self.cancelled`; on cancel it RAISES
  `RuntimeError` (`wr.py:3703-3704`) → propagates → terminal failure projection.

---

## 14. Behavioral parity checklist

A rebuild of lines 3256–4465 MUST satisfy ALL of the following:

1. **`_per_app_pipeline`** dispatches `disposition-recommender` (task_type
   `"wave-per-app-disposition"`, 1h, `agent_failure`, 12 input paths + 1 optional, context wrapped
   by `_with_fixture_scenario` then `_with_context_priors`, carrying `wave_id`, `rework_feedback`
   only when `rework=True`, and `approval_guidance=_approval_feedback.get("G-RR")`); resolves
   `disp_raw` via `_primary_output_content(...,"disposition-recommendation.json")` (NOT
   `output_artifacts[0]`); validates (advisory); commits primary + companions; THEN under
   `patched("wave-rationalization-rat-cap-clustering-v1") and disp_raw` runs
   `persist_rationalization_capability_dispositions` (60s, transient, id
   `persist-rat-cap-disp-{wave}-{app}`, best-effort try/except); dispatches
   `disposition-governance` (1h, `agent_failure`, NO subsequent validation); parses `disposition`
   from `recommended_disposition` via `parse_agent_json` ONLY if `disp_raw` non-empty & dict;
   dispatches `assess-user-impact` (1h, `agent_failure`) ONLY when
   `_is_retire_or_replace_disposition(disposition)` (exact `"Retire"`/`"Replace"`); returns the
   exact 12-key dict (`wr.py:3586-3608`) with `_agent_narrative` for the three `*_narrative` keys
   and the `ui_result is not None` guard on `user_impact_json`. **7 branches.**
2. **`_classify_app`** dispatches `classify-application` (task_type
   `"wave-per-app-classification"`, 1h, `agent_failure`, `input_artifacts=_discovery_passes_for_app`
   = 7 paths ONLY, no wave context); resolves `cls_json` via `_primary_output_content`; validates;
   commits; if `_classification_is_tier_1(cls_json)` sets `_current_step =
   f"awaiting-tier1-approval-{app_id}"` and `await wait_condition(lambda: app_id in
   self._tier1_approved_apps or self.cancelled)`; if `self.cancelled` **raises**
   `RuntimeError("cancelled waiting for tier-1 approval")`; returns
   `{"app_id","cls_json","cls_path","cls_narrative"}`. **2 branches.** Tier-1 detection uses strict
   `json.loads` + identity-`is True` flag + `int(risk)==1`.
3. **`_score_app`** dispatches `portfolio-scorer` (task_type `"wave-per-app-portfolio-score"`, 1h,
   `agent_failure`, 12 input paths + 1 optional); resolves `score_json` via
   `_primary_output_content`; validates; commits; computes `(overall, dimensions) =
   _compute_overall_readiness(score_json)` PURELY (no DB activity); returns
   `{"app_id","score_json","artifact_path","overall_weighted","dimensions","score_narrative"}`.
   `_compute_overall_readiness` clamps each score to `[0,100]`, equal-weight-means present numeric
   dims, rounds 2, returns `(None, sorted(present))` when no numeric scores, and adds null-score
   dims to `present` but a non-dict entry to neither. **0 branches in `_score_app`; 8 in the pure
   helper.**
4. **`_project_per_app_side_effects`** builds one `persist_rationalization_side_effects` future per
   `input.app_ids` (60s, transient, `… or ""` double-defaults on every JSON field,
   `tier_1_approved=app_id in self._tier1_approved_apps`); `await asyncio.gather(*tasks,
   return_exceptions=True)`; logs each `BaseException` and continues (never raises). Runs ONCE
   post-G-DA. **2 loops + 1 branch.**
5. **`_compute_pending_target_dispatch_entries`** returns `[]` unless
   `patched("architecture-target-plan-v1")`; drops `disposition=="Retire"`; folds Consolidate peers
   (anchor-first, deduped); builds `target_app_id=f"target-{anchor}"`,
   `target_repo_slug=f"target/{anchor}-{rel}"` (or `f"target/{anchor}"` when rel empty),
   `relationship=_normalize_relationship(disposition)`, `target_name_seed=""`,
   `target_service_id=""`, names via `_resolve_name`. **7 branches + 2 loops.**
6. **`_compute_pending_dispatch_entries`** runs two passes: pass 1 finds `consolidate-target`
   anchors and accumulates `consumed_as_peer`; pass 2 emits one `PendingDispatchEntry` per non-peer
   app, reading `recommended_disposition` OR `disposition` OR `""`, skipping Consolidate rows that
   are `consolidate-source` or in `consumed_as_peer`, emitting `consolidate-target`/unclear anchors.
   Uses `parse_agent_json`. Retire is NOT dropped. `anchor_for_peer` is built but its value unused.
   **~14 branches + 4 loops.**
7. **`_dispatch_key`** = `cfg.target_app_id or cfg.source_app_id`. **`_init_dispatch_status`** seeds
   `_dispatch_status[_dispatch_key(cfg)] = DispatchTargetStatus(status="pending", …,
   source_app_ids=[anchor]+peers, target_service_id=_v2_dispatch_meta.get(cfg.target_app_id,{}).get(
   "target_service_id",""))` per target. **`_normalize_dispatch_payload`** returns v1 unchanged;
   maps v2 dataclass (anchor=`source_app_ids[0]`, peers=`[1:]`,
   disposition=`_legacy_disposition_from_relationship(relationship)`,
   default_branch=`… or "main"`, preserves `target_app_id`); for wire-dict sniffs `v2_shape` via
   `any("target_app_id" in t)`, maps v2 entries (skip non-dicts) or splats v1 dicts with `**t`;
   returns empty for malformed/unknown. **~14 branches + 3 loops.**
8. **`_provision_one_target`** sets `_dispatch_status[_dispatch_key(cfg)].status="provisioning"`
   (subscript), resolves `target_service_id` via tolerant `.get`, invokes
   `create_target_app_and_repo` (5 min, transient, no activity_id) with BOTH
   `peer_source_app_ids` AND `source_app_ids=[anchor]+peers`, returns the result; raising surfaces
   as a per-entry exception in the caller's `gather(return_exceptions=True)`. **1 branch.**
9. **`_spawn_children_for_target`** computes `target_app_id=provisioned.target_app_id`, child ids
   `architecture-{target_app_id}-{run_ts}` / `data-{target_app_id}-{run_ts}`; resolves
   `relationship` (`v2_meta.relationship` → `cfg.disposition`, both via `_normalize_relationship`),
   `target_service_id` (status → v2_meta), `full_source_ids` (status.source_app_ids → cfg anchor+
   peers); calls `fetch_application_source_repos` (30s, transient, id
   `fetch-source-repos-{target_app_id}`); warns (only) on empty anchor repo; builds `arch_input` /
   `data_input` (`disposition=None`, cross-wired `peer_workflow_ids`, Data's `prior_artifacts`
   added ONLY under `patched("discovery-data-steps-v1")` from `[cfg.source]+cfg.peers`); starts
   `ArchitectureWorkflow` then `DataWorkflow` with `ParentClosePolicy.ABANDON` ONLY under
   `patched("arch-data-sibling-lifecycle-v1")`; runs best-effort
   `update_application_line_projection` (30s, transient, try/except); sets the seeded status'
   `target_app_id`/`architecture_workflow_id`/`data_workflow_id`/`status="architecture_in_flight"`;
   returns `(arch_handle, data_handle)`. **~9 branches + 1 loop.**
10. **`_update_wave_status_safe`** no-ops when `_wave_id` empty; else best-effort
    `update_wave_status` (30s, transient) inside try/except (logs, never raises). **2 branches.**
11. **All patch ids reproduced verbatim:** `"wave-rationalization-rat-cap-clustering-v1"`,
    `"wave-rationalization-batch-writes-v1"`, `"architecture-target-plan-v1"`,
    `"discovery-data-steps-v1"`, `"arch-data-sibling-lifecycle-v1"`.
12. **All per-app skill dispatches use `RETRY_POLICIES["agent_failure"]` (1h timeout); all
    plumbing/persist/commit/projection use `RETRY_POLICIES["transient"]`.** `create_target_app_and_repo`
    uses **5 min** + transient. No method here uses `validation_failure` or `git_merge` directly.
13. **`_primary_output_content` is used for EVERY committed primary artifact** (disposition,
    governance, classification, score, user-impact) so the WORKSPACE JSON (not the prose narrative)
    is committed, validated, parsed, and surfaced. Reading `output_artifacts[0]` instead is a
    parity failure.
14. **`_execution_ctx` returns `None` when `_portfolio_id` empty, else a `StepExecutionContext`
    with `line_id="rationalization"` (hard-coded), `wave_id=self._wave_id`** — it is the inlined
    version, NOT `LineWorkflowBase._execution_ctx`. **`_set_step`** sets `_current_step` /
    `_progress_pct` (clamped `[0,100]`) / `_updated_at` and does NOT push DB status (unlike the base).
15. **No `@workflow.signal` / `@workflow.query` / `@workflow.update` is defined in this line range.**
    The only signal-driven predicate consumed is `app_id in self._tier1_approved_apps` in
    `_classify_app`.

---

### Branch-count attestation (this file's scope)
Reproduced branch points by method (if/elif/else/except/ternary/compound-condition + loops):
`_per_app_pipeline` 7; `_classify_app` 2; module helpers feeding them (`_classification_is_tier_1`
~6, `_compute_overall_readiness` 8, `_with_context_priors` 2, `_with_fixture_scenario` 1,
`_normalize_relationship`/`_legacy_disposition` 4, `_is_retire_or_replace` 1) ~22; `_score_app` 0;
`_project_per_app_side_effects` 3 (incl. loops); `_compute_pending_target_dispatch_entries` 7+2;
`_compute_pending_dispatch_entries` ~14+4; `_dispatch_key` 1; `_init_dispatch_status` 1 loop;
`_normalize_dispatch_payload` ~14+3; `_provision_one_target` 1; `_spawn_children_for_target` 9+1;
`_update_wave_status_safe` 2. **Total ≈ 95+ branch/loop points across lines 3256–4465** —
exhaustively reproduced above with `wr.py:line` citations.
