# `GovernanceWorkflow` — Continuous Portfolio Learning-Loop Sweep (ATOMIC regeneration spec)

> **Source of truth:** `temporal/olympus_workflows/workflows/governance.py` (799 lines). Every
> `governance.py:line` citation below is against that file.
>
> **What this is:** the `@workflow.defn` class that executes **one** Governance sweep across an
> entire portfolio. The Governance assembly line is **continuous** — it runs on Temporal
> Schedules on two cadences (weekly + quarterly). One workflow class serves both; the cadence is
> selected at `run()` by inspecting `input.schedule_id` (`governance.py:1-37`, `163-171`).
>
> **★ STANDALONE — DOES NOT INHERIT FROM `LineWorkflowBase` OR `HILSignalsMixin`.**
> `class GovernanceWorkflow:` (`governance.py:163-164`) — bare class, no base. The docstring is
> explicit: *"Does NOT inherit from HILSignalsMixin — Governance has no human gates; instead it
> emits `wave_patterns_ready` signals out to other workflows after pattern extraction
> completes."* (`governance.py:169-171`). Consequences a rebuild MUST honor:
> - **No HIL state** (`approved`, `plan_approved`, `cancelled`, …) — none of the eight
>   `_HILSignalsMixin.md` vars exist here. There is **no `cancel_workflow` signal, no `cancelled`
>   flag, no kill switch.** The workflow runs to completion or fails; it cannot be cancelled via
>   signal (only via Temporal's native `terminate`/`cancel` API, which is out of band).
> - **No gates / no gate signals** — none of `gate_approved` / `gate_rejected` /
>   `escalation_resolved` / `merge_retry` from `_LineWorkflowBase.md` §3 exist. There is **no
>   `_wait_for_gate_decision`, no `_reconcile_and_merge_with_retry_loop`, no rework loop, no
>   `_rework_iterations` counter, no `_gate_decisions` buffer.** `get_status` returns
>   `pending_gate=None` always (`governance.py:334`).
> - **No `_set_step` / `_dispatch_agent` / `_commit_step_artifacts` / `_build_evidence_data`
>   from the base.** This class reimplements its own narrower helpers inline (`_dispatch_activity`,
>   `_commit_activity_artifact`, `_collect_pattern_bundle`, …). They are **NOT** the base
>   methods of the same family and have different shapes — see each section.
> - It DOES define its own `get_status` query and its own `wave_patterns_ready` signal — these
>   are the only handlers on the class.
>
> **Determinism note:** the only time source is `_now_iso()` → `workflow.now().isoformat()`
> (`governance.py:796-798`) — deterministic under replay. There is **no `datetime.now()`, no
> `random`, no wall-clock** in the module. `workflow.patched("governance-batch-writes-v1")` is a
> patch-gate whose ID is **load-bearing & verbatim** (appears 3×). Activity imports are inside
> `with workflow.unsafe.imports_passed_through():` (`governance.py:51`).

---

## 0. Imports, module constants, and helpers

### 0.1 Imports (`governance.py:43-76`)
- `import asyncio` (45), `import json` (46), `from datetime import timedelta` (47),
  `from temporalio import workflow` (49).
- Gated behind `with workflow.unsafe.imports_passed_through():` (`governance.py:51`):
  - Activities: `dispatch_agent_task` (agent_dispatch); `write_artifact`,
    `write_artifacts_batch` (git_operations); `list_active_modernization_workflows`
    (governance_operations); `persist_governance_sweep_side_effects` (line_transitions).
  - `RETRY_POLICIES` (retry_policies).
  - Types: `AgentTaskInput`, `AgentTaskResult`, `AssemblyLine`, `CronWorkflowInput`,
    `ListActiveModernizationWorkflowsInput`, `PersistGovernanceSweepSideEffectsInput`,
    `WavePatternsReadySignal`, `WorkflowStatus`, `WorkflowStatusResponse`, `WriteArtifactInput`,
    `WriteArtifactsBatchInput`.
- ⚠️ **GOTCHA-IMPORTS:** these MUST stay inside `imports_passed_through()` so the Temporal
  sandbox does not re-import them on replay. Same rule as the base (`_LineWorkflowBase.md` §0).

### 0.2 Retry policies used (`retry_policies.py`)
This workflow uses only two policy keys (string-keyed from `RETRY_POLICIES`):
- `"transient"` = `HTTP_RETRY_POLICY` — initial 1s, backoff 2.0, max 15s, **3 attempts**, no
  non-retryable list. Used for ALL git/list/persist activities here.
- `"agent_failure"` — initial 5s, backoff 2.0, max 60s, **3 attempts** (retry_policies.py:37-42).
  Used ONLY for the agent dispatch.
- ⚠️ **GOTCHA-RP1:** `git_merge`, `validation_failure`, `timeout`, `infrastructure` are **never
  used** by GovernanceWorkflow. There is no merge here (Governance writes commits but opens no
  gate PRs and merges nothing), so no `git_merge` / non-retryable merge errors.

### 0.3 Module-level registry constants (`governance.py:82-160`)

These are module globals (NOT classvars). A rebuild must reproduce them **exactly** — they drive
skill selection, artifact names, input-artifact refs, activity-set membership, and the
schedule-prefix decision.

**`GOVERNANCE_ACTIVITIES: dict[str, dict[str,str]]`** (`governance.py:82-107`) — per-activity
`{skill_id, artifact}`:

| activity | `skill_id` | `artifact` |
|----------|-----------|------------|
| `drift-detection` | `drift-detection` | `drift-detection.json` |
| `pattern-extraction` | `skill-builder` | `pattern-extraction.json` |
| `health-report` | `portfolio-health-check` | `health-report.json` |
| `skill-evolution` | `skill-builder` | `skill-evolution.json` |
| `factory-capacity` | `factory-capacity-manager` | `factory-capacity.json` |
| `model-evaluation` | `model-benchmark` | `model-evaluation.json` |

> ⚠️ **GOTCHA-REG1:** `pattern-extraction` and `skill-evolution` share the SAME skill_id
> (`skill-builder`) but write DIFFERENT artifacts. A rebuild must NOT collapse them.

**`ACTIVITY_INPUT_ARTIFACTS: dict[str, list[str]]`** (`governance.py:114-136`) — declared input
artifact globs forwarded onto `AgentTaskInput.input_artifacts` so the Layer-B envelope surfaces
refs. `*` is the all-apps glob; `wave-*` the all-waves glob:

| activity | input_artifacts |
|----------|-----------------|
| `drift-detection` | `["architecture/*/architecture-blueprint.json", "data/*/data-architecture.json", "deployment/*/cost-savings-certification.json"]` |
| `pattern-extraction` | `["modernization/*/generate/*/", "modernization/*/ralph-loop-metrics.json", "modernization/*/escalation-record.json"]` |
| `health-report` | `[]` (DB-first skill; no artifact reads) |
| `skill-evolution` | `["governance/*/pattern-extraction.json", "modernization/*/ralph-loop-metrics.json"]` |
| `factory-capacity` | `["rationalization/wave-*/wave-plan.json"]` |
| `model-evaluation` | `["governance/*/pattern-extraction.json"]` |

> ⚠️ **GOTCHA-REG2:** lookup is via `ACTIVITY_INPUT_ARTIFACTS.get(activity, [])`
> (`governance.py:355-357`) — a missing key defaults to `[]`, never raises. `health-report`
> intentionally maps to `[]` (the empty literal), not "missing".

**Activity sets:**
- `WEEKLY_ACTIVITIES = ["drift-detection", "pattern-extraction", "health-report",
  "skill-evolution", "factory-capacity"]` — 5 activities (`governance.py:139-145`).
- `QUARTERLY_ACTIVITIES = WEEKLY_ACTIVITIES + ["model-evaluation"]` — 6 activities
  (`governance.py:148`). ⚠️ **GOTCHA-REG3:** the **order** is weekly-5 then `model-evaluation`
  last. `_activities_for_schedule` returns `list(...)` copies (§9.1) so the module globals are
  never mutated by the workflow — a rebuild must copy, not alias.

**Step-name constants** (`governance.py:153-156`): `INTAKE_STEP = "intake"`;
`PROPAGATE_PATTERNS_STEP = "propagate-patterns"`;
`PERSIST_SWEEP_SIDE_EFFECTS_STEP = "persist-governance-sweep-side-effects"`;
`COMMIT_SWEEP_SUMMARY_STEP = "commit-sweep-summary"`.

**Schedule prefix** (`governance.py:160`): `QUARTERLY_SCHEDULE_PREFIX = "gov-quarterly"`. Any
`schedule_id` starting with this → quarterly; everything else (including unrecognized / `"adhoc"`)
→ weekly. ⚠️ **GOTCHA-REG4 (default is weekly):** an unknown or empty schedule prefix is NOT an
error — it silently runs the weekly set.

### 0.4 `_now_iso()` (`governance.py:796-798`)
```text
def _now_iso() -> str:
    return workflow.now().isoformat()
```
Deterministic. Used for every timestamp. ⚠️ NEVER `datetime.now()`.

---

## 1. STATE — every instance var in `__init__` (`governance.py:173-193`)

`__init__` takes no input and does **NOT** call `super().__init__()` (there is no base). It sets
exactly these 12 attributes:

| Var | Type | Initial | Line | Mutated by → value | When |
|-----|------|---------|------|---------------------|------|
| `_portfolio_id` | `str` | `""` | 174 | `run()` → `input.portfolio_id` (`governance.py:205`) | run start |
| `_schedule_id` | `str` | `""` | 175 | `run()` → `input.schedule_id or "adhoc"` (`governance.py:206`) | run start |
| `_status` | `WorkflowStatus` | `PENDING` | 176 | `run()` → `RUNNING` (202); `_execute_sweep` → `COMPLETED` (263); `run()` except → `FAILED` (211) | run / terminal |
| `_current_step` | `str` | `""` | 177 | `_intake`→`"intake"` (278); `_run_activity`→activity name (231); `_propagate_patterns`→`"propagate-patterns"` (495); `_persist…`→`"persist-governance-sweep-side-effects"` (646); `_commit_sweep_summary`→`"commit-sweep-summary"` (703); `_execute_sweep`→`"completed"` (264); `run()` except→`"failed"` (212) | each step |
| `_progress_pct` | `float` | `0.0` | 178 | `_intake`→`5.0` (279); `_execute_sweep`→`75.0` (250); `_persist…`→`90.0` (647); `_execute_sweep`→`100.0` (262) | each step |
| `_started_at` | `str` | `""` | 179 | `run()` → `_now_iso()` (203) | run start |
| `_updated_at` | `str` | `""` | 180 | bumped to `_now_iso()` by `run()`(204,213), `_run_activity`(232), `wave_patterns_ready` signal(319), `_intake`(280), `_propagate_patterns`(496), `_persist…`(648), `_commit_sweep_summary`(704), `_execute_sweep` final(265) | many |
| `_findings` | `dict[str, list[str]]` | `{}` | 183 | `_run_activity` → `_findings[activity] = result.output_artifacts` (234) | per activity (in fan-out) |
| `_activity_metadata` | `dict[str, dict]` | `{}` | 184 | `_dispatch_activity` → per-activity 5-field metadata (377-383) | each dispatch |
| `_activity_output_json` | `dict[str, str]` | `{}` | 186 | `_dispatch_activity` → raw agent text if non-empty (391-392) | each dispatch |
| `_wave_patterns_ready` | `list[dict]` | `[]` | 189 | `_run_activity` appends `{extracted_at, patterns}` on pattern-extraction (244-247); `wave_patterns_ready` signal appends `{wave_id, patterns, acknowledged_at}` (308-312) | pattern-extraction step + each inbound signal |
| `_pattern_reuse_acks` | `list[dict]` | `[]` | 193 | `wave_patterns_ready` signal appends `{pattern_name, delta:1}` per named pattern (316-318) | each inbound signal |

> ⚠️ **GOTCHA-ST1 (`_wave_patterns_ready` has TWO different dict shapes):** entries appended by
> `_run_activity` (the pattern-extraction step) have keys `{"extracted_at", "patterns"}`
> (`governance.py:244-247`); entries appended by the inbound `wave_patterns_ready` SIGNAL handler
> have keys `{"wave_id", "patterns", "acknowledged_at"}` (`governance.py:308-312`). Both shapes
> coexist in the same list. `_collect_pattern_bundle` (§5) reads only the common `"patterns"` key,
> so heterogeneity is tolerated by design. The sweep-summary artifact (`governance.py:726`) dumps
> the WHOLE heterogeneous list verbatim. A rebuild must keep both shapes and NOT normalize them.

> ⚠️ **GOTCHA-ST2 (`_pattern_reuse_acks` dict shape mismatch vs. activity-input doc):** the
> handler appends `{"pattern_name": <name>, "delta": 1}` (`governance.py:317`). The activity-input
> dataclass docstring describes the list as `{pattern_name, ack_count}` dicts
> (`types.py:2374-2375`), and the result echo counts them — but the workflow emits `delta`, not
> `ack_count`. A rebuild MUST emit the key name `"delta"` (the activity tolerates/normalizes the
> shape downstream; the workflow side is authoritative for what it writes). Do not "fix" to
> `ack_count`.

> ⚠️ **GOTCHA-ST3 (no `_app_id`, `_wave_id`, `_risk_tier`, `_pending_gate`):** Governance is
> portfolio-scoped only. There is no per-app or per-wave state, no risk tier, no pending-gate
> var. `get_status` hard-codes `pending_gate=None`.

---

## 2. SIGNALS / QUERIES — every handler atomically

This class registers **exactly one signal** and **exactly one query**. No updates.

### 2.1 `wave_patterns_ready(self, signal: WavePatternsReadySignal) -> None` — `@workflow.signal` (`governance.py:297-319`)

Payload `WavePatternsReadySignal` (`types.py:182-187`): `wave_id: str`,
`patterns: list[str] = []`.

Semantics: an INBOUND ack from a downstream consumer ("a Modernization workflow accepted this
pattern bundle"). Governance records the ack so the next sweep tracks adoption.

> ⚠️ **GOTCHA-SIG-DUAL (same name, two directions):** the wire signal name `wave_patterns_ready`
> is used in BOTH directions. INBOUND: this handler receives acks from consumers. OUTBOUND:
> `_propagate_patterns` (§6) FIRES `wave_patterns_ready` AT each active Modernization workflow.
> Same name, opposite flow. A rebuild must register this handler under exactly the name
> `wave_patterns_ready` (Temporal default = method name) AND send under the same literal string in
> `_propagate_patterns`. They share the payload type but are not "the same message".

This handler is **`async def`** (`governance.py:297-300`), but performs no `await` — pure state
mutation, completes in one workflow task with no yield point.

```text
async def wave_patterns_ready(self, signal):
    self._wave_patterns_ready.append({                       # governance.py:308-312
        "wave_id": signal.wave_id,
        "patterns": list(signal.patterns),                   # ← copy, not alias
        "acknowledged_at": _now_iso(),
    })
    # One reuse ack per named pattern in the signal payload.
    for pattern_name in (signal.patterns or []):             # governance.py:314  LOOP
        if isinstance(pattern_name, str) and pattern_name:   # governance.py:315  BRANCH
            self._pattern_reuse_acks.append(                 # governance.py:316-318
                {"pattern_name": pattern_name, "delta": 1}
            )
    self._updated_at = _now_iso()                            # governance.py:319
```

**Branch inventory (1 loop + 1 branch):**
- `for pattern_name in (signal.patterns or []):` (`governance.py:314`) — `or []` normalizes a
  `None` `patterns` to empty (defensive against malformed senders).
- `if isinstance(pattern_name, str) and pattern_name:` (`governance.py:315`) — only non-empty
  string entries become reuse acks. Non-str / empty-str entries are SKIPPED (no ack appended) but
  STILL land verbatim in the `_wave_patterns_ready` dict's `patterns` list (via `list(...)` copy
  on 310). A rebuild must keep both the skip on the ack side and the verbatim copy on the list side.

> ⚠️ **GOTCHA-SIG1 (timing — acks can arrive any time the workflow is alive):** this signal can
> fire BEFORE pattern-extraction runs, DURING the fan-out, or AFTER. There is no `wait_condition`
> consuming it (Governance never blocks on a decision). Every ack is purely additive to two lists
> that the tail steps (`_persist_governance_sweep_side_effects` §8, `_commit_sweep_summary` §9)
> read at the end. So an ack delivered after the fan-out but before step 9 is still captured; one
> delivered after step 10 is lost (workflow has completed). A rebuild must NOT add any
> `wait_condition` for this signal.

> ⚠️ **GOTCHA-SIG2 (no super-handler / no base):** because there is no base, this is the ONLY
> `@workflow.signal` on the class — there are no inherited gate/HIL signals to avoid redefining.
> A rebuild adds only this one signal.

### 2.2 `get_status(self) -> WorkflowStatusResponse` — `@workflow.query` (`governance.py:325-337`)

```text
@workflow.query
def get_status(self):
    return WorkflowStatusResponse(
        workflow_id  = workflow.info().workflow_id,   # governance.py:329
        status       = self._status,
        current_line = AssemblyLine.GOVERNANCE,       # governance.py:331  ← hard-coded enum
        current_step = self._current_step,
        progress_pct = self._progress_pct,
        pending_gate = None,                          # governance.py:334  ← always None
        started_at   = self._started_at,
        updated_at   = self._updated_at,
    )
```
- Synchronous, read-only. Returns live mutable state.
- ⚠️ **GOTCHA-Q1:** `current_line` is hard-coded `AssemblyLine.GOVERNANCE` (not a classvar — there
  is no `ASSEMBLY_LINE` classvar here). `pending_gate` is hard-coded `None` (Governance has no
  gates). A rebuild must hard-code both, not derive them.
- ⚠️ **GOTCHA-Q2 (reflects fan-out racing):** during the parallel fan-out (§3 step 2-7),
  `_current_step` is set by each `_run_activity` to its own activity name (231) under
  `asyncio.gather`. Because the coroutines interleave on `await` boundaries, a `get_status` poll
  mid-fan-out returns *whichever* activity most recently set `_current_step` — it is
  nondeterministic-from-the-observer's view *which* of the 5/6 names appears, but this is
  observability only and does not affect workflow determinism (no decision branches on
  `_current_step`). A rebuild need not stabilize which name wins.

> No updates (`@workflow.update`) are defined.

---

## 3. CONTROL FLOW — `run()` and `_execute_sweep()`

### 3.1 `run(self, input: CronWorkflowInput) -> str` — `@workflow.run` (`governance.py:195-214`)

Input `CronWorkflowInput` (`types.py:2491-2504`): `portfolio_id: str`, `schedule_id: str = ""`,
`triggered_at: str = ""`, `activities: list[str] = []` (the `activities` field is
**Sustainment-only** and **IGNORED** by Governance — Governance derives its set from
`schedule_id`).

Returns the string `"completed"` or `"failed"` (`"failed"` only as the docstring contract; in
practice the failure path re-raises, see GOTCHA-RUN1).

```text
@workflow.run
async def run(self, input):
    self._status = WorkflowStatus.RUNNING            # governance.py:202
    self._started_at = _now_iso()                    # governance.py:203
    self._updated_at = self._started_at              # governance.py:204
    self._portfolio_id = input.portfolio_id          # governance.py:205
    self._schedule_id = input.schedule_id or "adhoc" # governance.py:206  ← "" → "adhoc"

    try:                                             # governance.py:208
        return await self._execute_sweep(input)      # governance.py:209
    except Exception:                                # governance.py:210  BRANCH (catch-all)
        self._status = WorkflowStatus.FAILED         # governance.py:211
        self._current_step = "failed"                # governance.py:212
        self._updated_at = _now_iso()                # governance.py:213
        raise                                        # governance.py:214  ← RE-RAISES
```

**Branch inventory (1 try/except):** the `try` (208) / `except Exception:` (210) wrapping the
entire sweep.

> ⚠️ **GOTCHA-RUN1 (the except RE-RAISES — it does NOT return `"failed"`):** despite the docstring
> ("Returns: 'completed' or 'failed'", `governance.py:199-201`), the `except` block sets
> `_status=FAILED`, `_current_step="failed"`, bumps `_updated_at`, then **`raise`** (`governance.py:214`).
> The workflow execution therefore FAILS (Temporal records a failed run); the string `"failed"`
> is never actually returned. A rebuild MUST re-raise after stamping FAILED state — returning
> `"failed"` instead would make Temporal mark the run COMPLETED, which is wrong. The state
> mutation before re-raise exists so a `get_status` query against the failed-but-still-queryable
> history shows `status=FAILED`/`current_step="failed"`.

> ⚠️ **GOTCHA-RUN2 (`schedule_id or "adhoc"` default):** an empty/None `schedule_id` becomes the
> literal `"adhoc"` (`governance.py:206`), which does NOT start with `"gov-quarterly"`, so an
> adhoc run is a **weekly** sweep. The `"adhoc"` string then flows into every artifact path,
> branch name, workspace_key, and activity_id. A rebuild must default to exactly `"adhoc"`.

### 3.2 `_execute_sweep(self, input: CronWorkflowInput) -> str` (`governance.py:216-266`)

The orchestration body. 10 canonical steps; steps 2-7 fan out via `asyncio.gather`.

```text
async def _execute_sweep(self, input):
    # -- Step 1 — intake --
    activities = await self._intake(input)                       # governance.py:227

    # -- Steps 2-7 — parallel activity dispatch --
    async def _run_activity(activity):                           # governance.py:230  (nested)
        self._current_step = activity                            # governance.py:231
        self._updated_at = _now_iso()                            # governance.py:232
        result = await self._dispatch_activity(activity, input)  # governance.py:233
        self._findings[activity] = result.output_artifacts       # governance.py:234
        await self._commit_activity_artifact(activity, result, input)  # governance.py:235
        if activity == "pattern-extraction":                     # governance.py:243  BRANCH
            self._wave_patterns_ready.append({                   # governance.py:244-247
                "extracted_at": _now_iso(),
                "patterns": result.output_artifacts,
            })

    await asyncio.gather(*[_run_activity(a) for a in activities])  # governance.py:249  ★FAN-OUT
    self._progress_pct = 75.0                                    # governance.py:250

    # -- Step 8 — propagate patterns --
    await self._propagate_patterns(input)                        # governance.py:253
    await self._commit_latest_patterns_registry(input)           # governance.py:254

    # -- Step 9 — persist governance sweep side effects --
    await self._persist_governance_sweep_side_effects(input, activities)  # governance.py:257

    # -- Step 10 — commit sweep summary --
    await self._commit_sweep_summary(input, activities)          # governance.py:260

    self._progress_pct = 100.0                                   # governance.py:262
    self._status = WorkflowStatus.COMPLETED                      # governance.py:263
    self._current_step = "completed"                             # governance.py:264
    self._updated_at = _now_iso()                                # governance.py:265
    return "completed"                                           # governance.py:266
```

**Branch inventory (1 fan-out gather + 1 branch inside the nested coroutine):**
- `await asyncio.gather(*[_run_activity(a) for a in activities])` (`governance.py:249`) — the
  list-comprehension builds one coroutine per activity (5 weekly / 6 quarterly); `gather` runs
  them **concurrently**.
- `if activity == "pattern-extraction":` (`governance.py:243`) inside `_run_activity` — only the
  pattern-extraction coroutine appends a `{extracted_at, patterns}` entry to `_wave_patterns_ready`.

> ⚠️ **GOTCHA-FAN1 (`asyncio.gather` = concurrent activities, deterministic under Temporal):**
> the fan-out runs all activities concurrently via `gather` (`governance.py:249`). Under Temporal,
> `asyncio.gather` is deterministic: the activities are scheduled together and their completions
> are processed in history order, so replay is stable. A rebuild MUST use `asyncio.gather` over a
> list comprehension of `_run_activity(a)` — NOT a sequential `for a in activities: await ...`
> loop (that would change the activity-scheduling order in history and the concurrency profile).

> ⚠️ **GOTCHA-FAN2 (each `_run_activity` mutates shared state — order is racy but
> commutative):** every coroutine writes `self._current_step`, `self._updated_at`,
> `self._findings[activity]`, `self._activity_metadata[activity]`, `self._activity_output_json[activity]`,
> and (pattern-extraction only) appends to `self._wave_patterns_ready`. The per-activity dict
> writes are keyed by `activity`, so they don't collide. `_current_step`/`_updated_at` are
> last-writer-wins (observability only). The single `_wave_patterns_ready.append` happens only in
> the pattern-extraction coroutine. Because Temporal serializes workflow-coroutine steps at await
> boundaries (single-threaded event loop), there is no true data race — but the interleaving order
> of the per-key writes is determined by activity completion order in history. A rebuild must keep
> all these mutations INSIDE the per-activity coroutine (not hoisted), so each completes its own
> bookkeeping.

> ⚠️ **GOTCHA-FAN3 (progress jumps 5 → 75 across the whole fan-out):** `_intake` set 5.0; the
> next progress write is `75.0` AFTER `gather` returns (`governance.py:250`). During the entire
> fan-out, `_progress_pct` stays at 5.0 (no per-activity progress increments). A rebuild must NOT
> add intermediate progress — the canonical values are 5 → (fan-out) → 75 → 90 → 100.

> ⚠️ **GOTCHA-FAN4 (`gather` propagates the FIRST exception):** if any `_run_activity` raises
> (e.g. its `_dispatch_activity` exhausts the 3 agent_failure retries, or `_commit_activity_artifact`
> exhausts transient retries), `asyncio.gather` re-raises that exception, which propagates up
> through `_execute_sweep` → `run()`'s `except` (§3.1) → FAILED + re-raise. The OTHER in-flight
> activities are NOT awaited to completion by `gather` on the failure path. So a single hard
> activity failure fails the whole sweep. (Note: `_dispatch_activity` and `_commit_activity_artifact`
> have NO try/except — they are NOT best-effort. Only the post-fan-out steps 8/9 are best-effort.)
> A rebuild must NOT wrap the fan-out activities in try/except; let `gather` propagate.

> ⚠️ **GOTCHA-FAN5 (steps 8/9/10 are sequential AFTER the fan-out):** `_propagate_patterns`,
> `_commit_latest_patterns_registry`, `_persist_governance_sweep_side_effects`,
> `_commit_sweep_summary` all `await` in strict sequence (`governance.py:253-260`). Only steps
> 2-7 are parallel. A rebuild must keep 8/9/10 sequential.

---

## 4. Step 1 — `_intake()` (`governance.py:272-291`)

Pure determinism — **no activity call**. Resolves the cadence and selects the activity set.

```text
async def _intake(self, input):
    self._current_step = INTAKE_STEP        # governance.py:278  → "intake"
    self._progress_pct = 5.0                # governance.py:279
    self._updated_at = _now_iso()           # governance.py:280
    activities = _activities_for_schedule(self._schedule_id)   # governance.py:281
    workflow.logger.info(                   # governance.py:282-290
        "governance intake: cadence=%s activities=%s",
        _cadence_for_schedule(self._schedule_id),
        activities,
        extra={"portfolio_id": input.portfolio_id, "schedule_id": self._schedule_id},
    )
    return activities                       # governance.py:291
```
- No branches in the body (the branch is inside `_activities_for_schedule`, §9.1). Returns the
  list[str] of activities for the rest of `_execute_sweep`.
- ⚠️ **GOTCHA-INTAKE1 (logging is allowed; it's not I/O for determinism):** `workflow.logger.info`
  is the Temporal-safe logger (deduplicated on replay). A rebuild may log but must not introduce
  non-deterministic data into control flow.

---

## 5. `_collect_pattern_bundle()` — flatten patterns for propagation (`governance.py:460-478`)

Synchronous helper. Flattens every `_wave_patterns_ready` entry's `"patterns"` into a single
ordered, de-duplicated `list[str]`. Consumed by both `_propagate_patterns` (§6) and
`_commit_latest_patterns_registry` (§7).

```text
def _collect_pattern_bundle(self) -> list[str]:
    seen: set[str] = set()                         # governance.py:468
    bundle: list[str] = []                         # governance.py:469
    for entry in self._wave_patterns_ready:        # governance.py:470  LOOP
        patterns = entry.get("patterns") or []     # governance.py:471
        if not isinstance(patterns, list):         # governance.py:472  BRANCH
            continue                               # governance.py:473  ← skip non-list
        for p in patterns:                         # governance.py:474  LOOP
            if isinstance(p, str) and p and p not in seen:   # governance.py:475  BRANCH
                seen.add(p)                         # governance.py:476
                bundle.append(p)                    # governance.py:477
    return bundle                                  # governance.py:478
```

**Branch inventory (2 loops + 2 branches):**
- `for entry in self._wave_patterns_ready:` (470) — iterates BOTH dict shapes (GOTCHA-ST1).
- `if not isinstance(patterns, list): continue` (472) — defensively skips an entry whose
  `"patterns"` is not a list (`.get("patterns") or []` already maps missing/falsy → `[]`, which IS
  a list, so this guard catches a present-but-non-list value).
- `for p in patterns:` (474).
- `if isinstance(p, str) and p and p not in seen:` (475) — three conjuncts: must be str, must be
  non-empty, must be unseen. Order-preserving de-dup via the `seen` set.

> ⚠️ **GOTCHA-CB1 (order-preserving de-dup, first-occurrence wins):** the `seen` set + `append`
> pattern preserves first-occurrence order and drops later duplicates (`governance.py:468-477`).
> This differs from the base's `_build_evidence_data` dedup (last-wins). A rebuild must use
> first-occurrence-wins here. The docstring confirms: *"preserving order and de-duplicating"*
> (`governance.py:466-467`).
> ⚠️ **GOTCHA-CB2 (the bundle is `list[str]` to keep the signal payload stable):** the docstring
> (`governance.py:461-466`) records that `WavePatternsReadySignal.patterns` is intentionally
> still `list[str]` (unchanged by "F5") so in-flight Modernization signal handlers keep working. A
> rebuild must NOT widen the bundle element type.

---

## 6. Step 8a — `_propagate_patterns()` (`governance.py:480-551`)

Signals every active Modernization workflow with this sweep's bundle (the F5 compound-growth
flywheel). **All failures are best-effort / swallowed.** Keeps I/O in an activity (enumeration)
and signal dispatch in the workflow (via `get_external_workflow_handle`) to preserve determinism.

```text
async def _propagate_patterns(self, input):
    self._current_step = PROPAGATE_PATTERNS_STEP   # governance.py:495  → "propagate-patterns"
    self._updated_at = _now_iso()                  # governance.py:496
    bundle = self._collect_pattern_bundle()        # governance.py:497
    if not bundle:                                 # governance.py:498  BRANCH 1
        return                                     # governance.py:499  ← nothing to propagate

    try:                                           # governance.py:501
        result = await workflow.execute_activity(  # governance.py:502-513
            list_active_modernization_workflows,
            ListActiveModernizationWorkflowsInput(portfolio_id=input.portfolio_id),
            start_to_close_timeout=timedelta(seconds=60),
            retry_policy=RETRY_POLICIES["transient"],
            activity_id=f"governance-list-modernization-{input.portfolio_id}-{self._schedule_id}",
        )
    except Exception as exc:                        # governance.py:514  BRANCH 2 (best-effort)
        workflow.logger.warning(                    # governance.py:515-519
            "governance pattern propagation: enumeration failed: %s", exc,
            extra={"portfolio_id": input.portfolio_id})
        return                                      # governance.py:520  ← swallow + return

    workflow_ids = list(result.workflow_ids or [])  # governance.py:522
    if not workflow_ids:                            # governance.py:523  BRANCH 3
        return                                      # governance.py:524  ← no active consumers

    wave_id = f"governance-sweep-{self._schedule_id}"   # governance.py:529  synthetic wave_id
    signal_payload = WavePatternsReadySignal(           # governance.py:530-533
        wave_id=wave_id, patterns=bundle)

    for wf_id in workflow_ids:                          # governance.py:535  LOOP
        try:                                            # governance.py:536
            handle = workflow.get_external_workflow_handle(wf_id)   # governance.py:537
            await handle.signal("wave_patterns_ready", signal_payload)  # governance.py:538-541
        except Exception as exc:                        # governance.py:542  BRANCH 4 (best-effort)
            workflow.logger.warning(                    # governance.py:543-550
                "governance pattern propagation: signal to %s failed: %s",
                wf_id, exc, extra={"portfolio_id": input.portfolio_id})
            # NOTE: no return — continue to next wf_id
```

**Branch inventory (3 `if`-returns + 1 loop + 2 try/except):**
1. `if not bundle: return` (498) — empty bundle short-circuits (no activity call at all).
2. `try/except Exception` (501/514) around enumeration — on failure, **log + return** (swallow).
3. `if not workflow_ids: return` (523) — empty enumeration short-circuits.
4. `for wf_id in workflow_ids:` (535) with inner `try/except Exception` (536/542) — per-handle
   signal; on failure **log + continue** (does NOT return — one dead workflow can't block the rest).

**Activity calls (in order):**
- `list_active_modernization_workflows` — `ListActiveModernizationWorkflowsInput(portfolio_id)`;
  **60s** start_to_close; `transient` (3 attempts);
  `activity_id="governance-list-modernization-{portfolio_id}-{schedule_id}"`. (Inside try.)

**Signal dispatches (in loop):**
- For each `wf_id`: `workflow.get_external_workflow_handle(wf_id)` then
  `await handle.signal("wave_patterns_ready", signal_payload)`. ⚠️ This is a SIGNAL, not an
  activity — no retry policy / timeout. Each wrapped in try/except.

> ⚠️ **GOTCHA-PP1 (signal name is a literal string here):** the outbound dispatch uses the literal
> `"wave_patterns_ready"` (`governance.py:539`), matching the INBOUND handler name (GOTCHA-SIG-DUAL).
> A rebuild must use this exact string — a typo would silently no-op (the target workflow ignores
> unknown signals).
> ⚠️ **GOTCHA-PP2 (synthetic wave_id encodes provenance):** `wave_id="governance-sweep-{schedule_id}"`
> (`governance.py:529`) lets downstream consumers attribute the bundle to the producing sweep. The
> payload schema is unchanged (`wave_id: str`, `patterns: list[str]`). A rebuild must use this
> exact format string.
> ⚠️ **GOTCHA-PP3 (everything best-effort — propagation NEVER fails the sweep):** the docstring
> (`governance.py:491-494`) is explicit: an empty list, Temporal unreachable, or per-handle signal
> failure are all non-errors. The enumeration try/except returns cleanly; the per-handle try/except
> continues the loop. A rebuild must NOT let any propagation failure escape this method. (Contrast
> with the fan-out activities, which are NOT best-effort, GOTCHA-FAN4.)
> ⚠️ **GOTCHA-PP4 (I/O in activity, signal dispatch in workflow — determinism boundary):** the
> docstring (`governance.py:486-489`) records the design: enumeration (which talks to the Temporal
> visibility API / DB) is an ACTIVITY; firing the signals uses `get_external_workflow_handle`
> (a deterministic workflow primitive). A rebuild MUST NOT enumerate workflows inside the workflow
> code, nor dispatch signals inside the activity.

---

## 7. Step 8b — `_commit_latest_patterns_registry()` (`governance.py:553-635`)

Writes the cold-start pattern registry at `governance/{portfolio_id}/latest-patterns.json` on
`main` so Modernization workflows that START AFTER this sweep (and thus missed the live signal)
can read the same bundle. Best-effort.

```text
async def _commit_latest_patterns_registry(self, input):
    bundle = self._collect_pattern_bundle()        # governance.py:566
    if not bundle:                                  # governance.py:567  BRANCH 1
        return                                      # governance.py:568

    repo = _governance_repo(input.portfolio_id)     # governance.py:570  → "olympus/{pid}-governance"
    branch = "main"                                 # governance.py:571  ★ MAIN, not the sweep branch
    path = f"governance/{input.portfolio_id}/latest-patterns.json"   # governance.py:572
    content = json.dumps({                          # governance.py:573-585
        "portfolio_id": input.portfolio_id,
        "schedule_id": self._schedule_id,
        "updated_at": _now_iso(),
        "patterns": bundle,
        "source": {
            "sweep_wave_id": f"governance-sweep-{self._schedule_id}",
            "triggered_at": input.triggered_at,
        },
    }, indent=2)

    try:                                            # governance.py:587
        if workflow.patched("governance-batch-writes-v1"):   # governance.py:588  BRANCH 2 (patch gate)
            await workflow.execute_activity(        # governance.py:589-606
                write_artifacts_batch,
                WriteArtifactsBatchInput(repo=repo, branch=branch, files=[(path, content)],
                    commit_message=f"governance({input.portfolio_id}): update latest-patterns registry"),
                start_to_close_timeout=timedelta(seconds=120),
                retry_policy=RETRY_POLICIES["transient"],
                activity_id=f"commit-governance-latest-patterns-{input.portfolio_id}-{self._schedule_id}",
            )
        else:                                       # governance.py:607
            await workflow.execute_activity(        # governance.py:608-626
                write_artifact,
                WriteArtifactInput(repo=repo, branch=branch, path=path, content=content,
                    commit_message=f"governance({input.portfolio_id}): update latest-patterns registry"),
                start_to_close_timeout=timedelta(seconds=60),
                retry_policy=RETRY_POLICIES["transient"],
                activity_id=f"commit-governance-latest-patterns-{input.portfolio_id}-{self._schedule_id}",
            )
    except Exception as exc:                        # governance.py:627  BRANCH 3 (best-effort)
        workflow.logger.warning(                    # governance.py:628-635
            "governance latest-patterns commit failed (portfolio=%s): %s",
            input.portfolio_id, exc)
```

**Branch inventory (1 `if`-return + 1 patch gate if/else + 1 try/except):**
1. `if not bundle: return` (567).
2. `if workflow.patched("governance-batch-writes-v1"):` (588) → `write_artifacts_batch`; `else:`
   (607) → `write_artifact`.
3. `try/except Exception` (587/627) wrapping BOTH branches — best-effort, log + swallow.

**Activity calls (mutually exclusive on the patch gate; in order = single call):**
- Patched path: `write_artifacts_batch` — `WriteArtifactsBatchInput(repo, branch="main",
  files=[(path, content)], commit_message)`; **120s**; `transient`;
  `activity_id="commit-governance-latest-patterns-{pid}-{sched}"`.
- Unpatched path: `write_artifact` — `WriteArtifactInput(repo, branch="main", path, content,
  commit_message)`; **60s**; `transient`; same `activity_id`.

> ⚠️ **GOTCHA-LP1 (this commit targets `main`, NOT the per-sweep branch):** unlike
> `_commit_activity_artifact` (§9.2) and `_commit_sweep_summary` (§9.3) which write to
> `governance/{pid}/{schedule_id}`, this registry is committed to `branch="main"`
> (`governance.py:571`). The docstring explains why: late-starting consumers read it from `main`
> at startup (`governance.py:556-564`). A rebuild MUST target `main` here.
> ⚠️ **GOTCHA-LP2 (patch gate selects batch-vs-single — verbatim ID, replay-critical):**
> `workflow.patched("governance-batch-writes-v1")` (`governance.py:588`) gates batch vs single
> commit. The patched (newer) path uses `write_artifacts_batch` with a 120s timeout; the unpatched
> (legacy/in-flight) path uses `write_artifact` with 60s. The two activities differ in name AND
> timeout. A rebuild MUST reproduce the EXACT patch ID and BOTH call shapes — a pre-patch in-flight
> run replays down the `write_artifact` path; flipping it would break replay determinism.
> ⚠️ **GOTCHA-LP3 (best-effort — registry failure never fails the sweep):** the whole commit is in
> a try/except that logs + swallows (`governance.py:627-635`). A rebuild must swallow here.

---

## 8. Step 9 — `_persist_governance_sweep_side_effects()` (`governance.py:637-692`)

Projects each activity's raw JSON onto Governance DB tables in ONE best-effort activity. Swallows
DB failures so the sweep-summary commit (step 10) isn't blocked.

```text
async def _persist_governance_sweep_side_effects(self, input, activities):
    self._current_step = PERSIST_SWEEP_SIDE_EFFECTS_STEP   # governance.py:646
    self._progress_pct = 90.0                              # governance.py:647
    self._updated_at = _now_iso()                          # governance.py:648
    cadence = _cadence_for_schedule(self._schedule_id)     # governance.py:649
    payload = PersistGovernanceSweepSideEffectsInput(      # governance.py:650-672
        portfolio_id=input.portfolio_id,
        schedule_id=self._schedule_id,
        cadence=cadence,
        drift_detection_json   = self._activity_output_json.get("drift-detection", ""),
        pattern_extraction_json= self._activity_output_json.get("pattern-extraction", ""),
        health_report_json     = self._activity_output_json.get("health-report", ""),
        factory_capacity_json  = self._activity_output_json.get("factory-capacity", ""),
        model_evaluation_json  = (                          # governance.py:666-670  BRANCH (cond expr)
            self._activity_output_json.get("model-evaluation", "")
            if cadence == "quarterly"
            else ""
        ),
        pattern_reuse_acks = list(self._pattern_reuse_acks),  # governance.py:671  ← copy
    )
    try:                                                    # governance.py:673
        await workflow.execute_activity(                    # governance.py:674-683
            persist_governance_sweep_side_effects,
            payload,
            start_to_close_timeout=timedelta(seconds=120),
            retry_policy=RETRY_POLICIES["transient"],
            activity_id=f"persist-governance-sweep-{input.portfolio_id}-{self._schedule_id}",
        )
    except Exception as exc:                                # governance.py:684  BRANCH (best-effort)
        workflow.logger.warning(                            # governance.py:685-692
            "persist_governance_sweep_side_effects failed: %s", exc,
            extra={"portfolio_id": input.portfolio_id, "schedule_id": self._schedule_id})
```

**Branch inventory (1 conditional expression + 1 try/except):**
- `model_evaluation_json = (... if cadence == "quarterly" else "")` (`governance.py:666-670`) —
  the model-evaluation JSON is forwarded ONLY on quarterly sweeps; on weekly it is the empty
  string even if (impossibly) populated.
- `try/except Exception` (673/684) — best-effort, log + swallow.

**Activity calls (1):**
- `persist_governance_sweep_side_effects` — `PersistGovernanceSweepSideEffectsInput` (see
  `types.py:2348-2377`); **120s**; `transient`;
  `activity_id="persist-governance-sweep-{pid}-{sched}"`.

> ⚠️ **GOTCHA-PS1 (model-evaluation gated by cadence, NOT by whether the activity ran):** the
> conditional uses `cadence == "quarterly"` (`governance.py:668`), not "did model-evaluation run".
> On a weekly sweep the activity never runs, so `_activity_output_json` has no `"model-evaluation"`
> key anyway — the `.get(..., "")` would return `""`. The explicit `else ""` is belt-and-braces.
> A rebuild must gate on cadence string equality.
> ⚠️ **GOTCHA-PS2 (`.get(key, "")` everywhere — missing activity output → empty string):** all
> five JSON fields use `_activity_output_json.get(<activity>, "")` (`governance.py:654-665`). If an
> activity produced no textual output (GOTCHA-DA1 below), its field is `""`. The activity tolerates
> empty JSON strings (parses best-effort). A rebuild must default to `""`, never `None`.
> ⚠️ **GOTCHA-PS3 (`pattern_reuse_acks` is a COPY of the live list):** `list(self._pattern_reuse_acks)`
> (`governance.py:671`) snapshots the accumulated acks at step-9 time. Acks delivered between step
> 9 and step 10 land in the live list but NOT in this payload (they DO appear in the sweep summary,
> §9, which reads the live list). A rebuild must copy here.
> ⚠️ **GOTCHA-PS4 (best-effort — DB failure never blocks step 10):** try/except logs + swallows
> (`governance.py:684-692`). The docstring notes the activity itself is transactional per sweep
> (`governance.py:642-645`). A rebuild must swallow.
> ⚠️ **GOTCHA-PS5 (`activities` param is UNUSED here):** `_persist_governance_sweep_side_effects`
> takes `activities` but never reads it (the payload is built from `_activity_output_json` keys).
> A rebuild may keep the param for signature parity but it has no behavioral effect.

---

## 9. Step 10 — `_commit_sweep_summary()` (`governance.py:694-760`)

The terminal code step. Synthesizes per-activity findings + the (heterogeneous)
`_wave_patterns_ready` list + `_pattern_reuse_acks` into the portfolio-wide
`sweep-summary.json` the dashboard renders.

```text
async def _commit_sweep_summary(self, input, activities):
    self._current_step = COMMIT_SWEEP_SUMMARY_STEP   # governance.py:703  → "commit-sweep-summary"
    self._updated_at = _now_iso()                    # governance.py:704
    repo = _governance_repo(input.portfolio_id)      # governance.py:705
    branch = f"governance/{input.portfolio_id}/{self._schedule_id}"   # governance.py:706  ★ sweep branch
    path = f"governance/{input.portfolio_id}/{self._schedule_id}/sweep-summary.json"  # governance.py:707-710
    cadence = _cadence_for_schedule(self._schedule_id)   # governance.py:711
    summary = {                                      # governance.py:712-728
        "portfolio_id": input.portfolio_id,
        "schedule_id": self._schedule_id,
        "cadence": cadence,
        "triggered_at": input.triggered_at,
        "completed_at": _now_iso(),
        "activities": {                              # governance.py:718-725  DICT-COMPREHENSION
            activity: {
                "artifact":       GOVERNANCE_ACTIVITIES[activity]["artifact"],
                "skill_id":       GOVERNANCE_ACTIVITIES[activity]["skill_id"],
                "findings_count": len(self._findings.get(activity, [])),
            }
            for activity in activities               # governance.py:724  LOOP
        },
        "wave_patterns_ready": self._wave_patterns_ready,    # governance.py:726  whole heterogeneous list
        "pattern_reuse_acks": self._pattern_reuse_acks,      # governance.py:727  live list (not a copy)
    }
    summary_content = json.dumps(summary, indent=2)  # governance.py:729
    if workflow.patched("governance-batch-writes-v1"):   # governance.py:730  BRANCH (patch gate)
        await workflow.execute_activity(             # governance.py:731-744
            write_artifacts_batch,
            WriteArtifactsBatchInput(repo=repo, branch=branch, files=[(path, summary_content)],
                commit_message=f"governance({input.portfolio_id}): {self._schedule_id} sweep summary"),
            start_to_close_timeout=timedelta(seconds=120),
            retry_policy=RETRY_POLICIES["transient"],
        )                                            # ← NOTE: no activity_id
    else:                                            # governance.py:745
        await workflow.execute_activity(             # governance.py:746-760
            write_artifact,
            WriteArtifactInput(repo=repo, branch=branch, path=path, content=summary_content,
                commit_message=f"governance({input.portfolio_id}): {self._schedule_id} sweep summary"),
            start_to_close_timeout=timedelta(seconds=60),
            retry_policy=RETRY_POLICIES["transient"],
        )                                            # ← NOTE: no activity_id
```

**Branch inventory (1 dict-comprehension loop + 1 patch gate if/else):**
- `for activity in activities` (`governance.py:724`) — dict comprehension building the
  `"activities"` map (one entry per activity in the active set).
- `if workflow.patched("governance-batch-writes-v1"):` (730) → `write_artifacts_batch`; `else:`
  (745) → `write_artifact`.

**Activity calls (mutually exclusive on patch gate; in order = single call):**
- Patched: `write_artifacts_batch` — `WriteArtifactsBatchInput(repo, branch (sweep branch),
  files=[(path, summary_content)], commit_message)`; **120s**; `transient`; **NO activity_id**.
- Unpatched: `write_artifact` — `WriteArtifactInput(repo, branch (sweep branch), path,
  content, commit_message)`; **60s**; `transient`; **NO activity_id**.

> ⚠️ **GOTCHA-SS1 (NOT best-effort — step 10 failure FAILS the sweep):** unlike step 8b and step 9,
> `_commit_sweep_summary` has **no try/except**. If the commit activity exhausts its 3 transient
> retries, the exception propagates → `run()`'s `except` → FAILED + re-raise. The sweep summary is
> the authoritative terminal artifact, so its failure is fatal. A rebuild must NOT wrap this in
> try/except.
> ⚠️ **GOTCHA-SS2 (no `activity_id` on the summary commit, unlike every other commit):** the two
> commit calls here pass NO `activity_id` (`governance.py:744`, `governance.py:760`) — contrast
> `_commit_activity_artifact` (`activity_id="commit-governance-{activity}"`) and the registry
> commit (`activity_id="commit-governance-latest-patterns-..."`). Temporal will auto-assign a
> sequence-based activity id. A rebuild must reproduce this asymmetry (omit `activity_id` here)
> to keep replay history identical.
> ⚠️ **GOTCHA-SS3 (summary targets the per-sweep branch):** `branch="governance/{pid}/{sched}"`
> (`governance.py:706`) — same branch the per-activity artifacts went to (§9.2), NOT `main` (that
> was only the registry, §7). A rebuild must use the sweep branch.
> ⚠️ **GOTCHA-SS4 (`pattern_reuse_acks` is the LIVE list, not a copy):** `governance.py:727`
> assigns `self._pattern_reuse_acks` directly into the summary dict (no `list(...)`). Since this is
> the final read before `json.dumps`, any ack delivered up to this exact point is included — but
> because it's serialized immediately, the alias-vs-copy distinction is moot for the artifact. A
> rebuild may pass the live reference (it is read-then-dumped synchronously). Contrast the persist
> step (§8) which DID copy because the payload crosses an activity boundary later.
> ⚠️ **GOTCHA-SS5 (`findings_count` from `_findings`, not from the summary artifacts):**
> `len(self._findings.get(activity, []))` (`governance.py:723`) — `_findings[activity]` was set to
> `result.output_artifacts` in `_run_activity` (`governance.py:234`). A missing activity defaults
> to `[]` → count 0. A rebuild must compute the count from `_findings`, not re-read artifacts.

---

## 9.2 `_commit_activity_artifact()` — per-activity finding commit (`governance.py:395-458`)

Called by `_run_activity` (inside the fan-out, §3.2:235) after each `_dispatch_activity`. Writes
one JSON artifact per activity to the per-sweep branch.

```text
async def _commit_activity_artifact(self, activity, result, input):
    act_def = GOVERNANCE_ACTIVITIES[activity]        # governance.py:402
    repo = _governance_repo(input.portfolio_id)      # governance.py:403
    branch = f"governance/{input.portfolio_id}/{self._schedule_id}"   # governance.py:404
    path = f"governance/{input.portfolio_id}/{self._schedule_id}/{act_def['artifact']}"  # 405-408
    metadata = self._activity_metadata.get(activity, {})   # governance.py:409
    content = json.dumps({                           # governance.py:411-426
        "activity": activity,
        "skill_id": act_def["skill_id"],
        "portfolio_id": input.portfolio_id,
        "schedule_id": self._schedule_id,
        "triggered_at": input.triggered_at,
        "findings": result.output_artifacts,
        "model_used": metadata.get("model_used", ""),
        "duration_ms": metadata.get("duration_ms", 0),
        "token_usage": {"input": metadata.get("token_usage_input", 0),
                        "output": metadata.get("token_usage_output", 0)},
        "cost_estimate_usd": metadata.get("cost_estimate_usd", 0.0),
        "timestamp": workflow.now().isoformat(),     # governance.py:425  deterministic
    }, indent=2)

    if workflow.patched("governance-batch-writes-v1"):   # governance.py:428  BRANCH (patch gate)
        await workflow.execute_activity(             # governance.py:429-442
            write_artifacts_batch,
            WriteArtifactsBatchInput(repo=repo, branch=branch, files=[(path, content)],
                commit_message=f"governance({input.portfolio_id}): {activity} sweep"),
            start_to_close_timeout=timedelta(seconds=120),
            retry_policy=RETRY_POLICIES["transient"],
            activity_id=f"commit-governance-{activity}",
        )
    else:                                            # governance.py:443
        await workflow.execute_activity(             # governance.py:444-458
            write_artifact,
            WriteArtifactInput(repo=repo, branch=branch, path=path, content=content,
                commit_message=f"governance({input.portfolio_id}): {activity} sweep"),
            start_to_close_timeout=timedelta(seconds=60),
            retry_policy=RETRY_POLICIES["transient"],
            activity_id=f"commit-governance-{activity}",
        )
```

**Branch inventory (1 patch gate if/else):**
- `if workflow.patched("governance-batch-writes-v1"):` (428) → `write_artifacts_batch` (120s);
  `else:` (443) → `write_artifact` (60s). Both `activity_id=f"commit-governance-{activity}"`.

> ⚠️ **GOTCHA-CA1 (NOT best-effort — runs inside the fan-out; failure fails the sweep):** no
> try/except. A commit failure propagates out of `_run_activity` → `asyncio.gather` re-raises →
> sweep FAILED (GOTCHA-FAN4). A rebuild must NOT wrap this.
> ⚠️ **GOTCHA-CA2 (deterministic `activity_id` per activity makes the commit replay-stable):**
> `activity_id=f"commit-governance-{activity}"` (`governance.py:441`, `457`). Unique per activity,
> stable across replay. A rebuild must keep it.
> ⚠️ **GOTCHA-CA3 (`workflow.now()` not `_now_iso()` for `timestamp`):** the JSON `"timestamp"`
> uses `workflow.now().isoformat()` inline (`governance.py:425`), equivalent to `_now_iso()` but
> spelled out. Deterministic either way. A rebuild may use either; both reduce to the same call.
> ⚠️ **GOTCHA-CA4 (same patch ID, third occurrence):** `governance-batch-writes-v1` appears in
> `_commit_activity_artifact` (428), `_commit_latest_patterns_registry` (588), and
> `_commit_sweep_summary` (730). All three MUST use the identical string and the same batch-vs-single
> dichotomy, because a single in-flight run's replay must take the SAME branch at all three sites.

---

## 10. `_dispatch_activity()` — agent dispatch for one activity (`governance.py:343-393`)

The "run a skill for this activity" helper. Returns `AgentTaskResult`. ⚠️ This is **NOT** the
base's `_dispatch_agent` — narrower, no rework feedback, no context-priors, no execution_context.

```text
async def _dispatch_activity(self, activity, input) -> AgentTaskResult:
    act_def = GOVERNANCE_ACTIVITIES[activity]        # governance.py:347
    task_input = AgentTaskInput(                     # governance.py:348-369
        task_type=f"governance-{activity}",
        app_id="",                                   # ← portfolio-scoped (empty app_id)
        skill_id=act_def["skill_id"],
        input_artifacts=list(ACTIVITY_INPUT_ARTIFACTS.get(activity, [])),   # governance.py:355-357
        artifact_repo="",
        artifact_ref="",
        workspace_key=f"governance-{input.portfolio_id}-{self._schedule_id}",
        context={                                    # governance.py:363-368
            "portfolio_id": input.portfolio_id,
            "schedule_id": self._schedule_id,
            "triggered_at": input.triggered_at,
            "cadence": _cadence_for_schedule(self._schedule_id),
        },
    )
    result = await workflow.execute_activity(        # governance.py:370-376
        dispatch_agent_task,
        task_input,
        start_to_close_timeout=timedelta(hours=1),
        retry_policy=RETRY_POLICIES["agent_failure"],
        activity_id=f"governance-{activity}",
    )
    self._activity_metadata[activity] = {            # governance.py:377-383
        "model_used": result.model_used,
        "duration_ms": result.duration_ms,
        "token_usage_input": result.token_usage_input,
        "token_usage_output": result.token_usage_output,
        "cost_estimate_usd": result.cost_estimate_usd,
    }
    text = getattr(result, "output_text", "") or getattr(result, "output", "")  # governance.py:388-390
    if isinstance(text, str) and text:               # governance.py:391  BRANCH
        self._activity_output_json[activity] = text  # governance.py:392
    return result                                    # governance.py:393
```

**Branch inventory (1 branch):**
- `if isinstance(text, str) and text:` (`governance.py:391`) — only record the raw textual output
  when it is a non-empty string.

**Activity calls (1):**
- `dispatch_agent_task` — `AgentTaskInput` (above); **1 hour** start_to_close;
  **`agent_failure`** (3 attempts, 5-60s backoff); `activity_id=f"governance-{activity}"`.

> ⚠️ **GOTCHA-DA1 (`output_text` may not exist — graceful getattr fallback):** the raw text is read
> `getattr(result, "output_text", "") or getattr(result, "output", "")` (`governance.py:388-390`).
> The comment (`governance.py:386-390`) notes `AgentTaskResult.output_text` "may or may not exist
> across adapters". The canonical `AgentTaskResult` dataclass (`types.py:513-525`) has NEITHER
> `output_text` NOR `output` — so on the canonical type, BOTH getattrs return `""`, the `if`
> (391) is False, and `_activity_output_json[activity]` is NEVER set. That cascades to step 9's
> `.get(activity, "")` returning `""` (GOTCHA-PS2). A rebuild MUST reproduce the double-getattr
> fallback EXACTLY (it is forward-compat plumbing for adapters that DO carry the field). Do not
> assume the field exists; do not raise on its absence.
> ⚠️ **GOTCHA-DA2 (`app_id=""` — portfolio-scoped dispatch):** `AgentTaskInput.app_id=""`
> (`governance.py:350`). The dataclass contract (`types.py:472-509`) says "exactly one of app_id /
> wave_id must be populated" — but Governance is PORTFOLIO-scoped, so it sets NEITHER (both default
> empty). ⚠️ This appears to violate the documented exactly-one CHECK constraint — but Governance
> dispatches are not inserted as per-app/per-wave agent_task rows the same way; the portfolio
> context lives in `context["portfolio_id"]`. A rebuild must set `app_id=""` and NOT set `wave_id`,
> exactly as written, and NOT try to satisfy the exactly-one rule by inventing an id.
> ⚠️ **GOTCHA-DA3 (no `execution_context`, no context-priors, no rework_feedback):** unlike the
> base `_dispatch_agent`, this dispatch does NOT build a `StepExecutionContext`, does NOT load
> context-priors, and does NOT attach `rework_feedback` (Governance has no gates/rework). The
> `AgentTaskInput.execution_context` defaults to `None`. A rebuild must NOT add any of these.
> ⚠️ **GOTCHA-DA4 (`input_artifacts` is a COPY of the registry list):**
> `list(ACTIVITY_INPUT_ARTIFACTS.get(activity, []))` (`governance.py:355-357`) copies the module
> global so the workflow can't mutate it. A rebuild must copy.
> ⚠️ **GOTCHA-DA5 (`activity_id=f"governance-{activity}"` — deterministic, idempotent):** stable
> per activity across replay. NOTE this is the SAME prefix the commit uses but the commit's id is
> `commit-governance-{activity}` — distinct ids, no collision. A rebuild must keep both.
> ⚠️ **GOTCHA-DA6 (`_activity_metadata` is a 5-field dict — NO `output_files`):** unlike the base's
> `_agent_metadata` (6 fields incl. `output_files`), this records only 5 fields (`governance.py:377-383`).
> A rebuild must NOT add `output_files` here.
> ⚠️ **GOTCHA-DA7 (`workspace_key` shape):** `f"governance-{portfolio_id}-{schedule_id}"`
> (`governance.py:360-362`). Shared by all activities in the sweep (same workspace). A rebuild must
> use this exact format.

---

## 11. Module-level pure functions (`governance.py:763-798`)

### 11.1 `_activities_for_schedule(schedule_id) -> list[str]` (`governance.py:763-775`)
```text
def _activities_for_schedule(schedule_id):
    if schedule_id.startswith(QUARTERLY_SCHEDULE_PREFIX):   # governance.py:773  BRANCH
        return list(QUARTERLY_ACTIVITIES)                   # governance.py:774  ← 6, copy
    return list(WEEKLY_ACTIVITIES)                          # governance.py:775  ← 5, copy
```
**Branch (1):** `if schedule_id.startswith("gov-quarterly")` → 6 activities; else 5. Returns a
fresh `list(...)` so the module globals are never aliased/mutated (GOTCHA-REG3).

### 11.2 `_cadence_for_schedule(schedule_id) -> str` (`governance.py:778-782`)
```text
def _cadence_for_schedule(schedule_id):
    if schedule_id.startswith(QUARTERLY_SCHEDULE_PREFIX):   # governance.py:780  BRANCH
        return "quarterly"                                  # governance.py:781
    return "weekly"                                         # governance.py:782
```
**Branch (1):** identical prefix test as 11.1. ⚠️ **GOTCHA-CAD1:** the two functions use the SAME
prefix test independently — they MUST stay consistent (both keyed on `QUARTERLY_SCHEDULE_PREFIX`).
A rebuild that changes one prefix and not the other would dispatch the quarterly activity set but
label the cadence "weekly" (or vice-versa), corrupting `model_evaluation_json` gating (§8) and the
summary `cadence` field (§9).

### 11.3 `_governance_repo(portfolio_id) -> str` (`governance.py:785-793`)
```text
def _governance_repo(portfolio_id):
    return f"olympus/{portfolio_id}-governance"             # governance.py:793
```
No branches. ⚠️ **GOTCHA-REPO1:** Governance artifacts are portfolio-scoped, stored in a dedicated
`olympus/{pid}-governance` repo (not per-app). The docstring notes tests rely on this default;
production overrides via deployment config (`governance.py:788-792`). A rebuild must use this exact
format string as the default.

### 11.4 `_now_iso()` — see §0.4.

---

## 12. RESILIENCE summary

- **Timeouts (start_to_close):** agent dispatch **1 hour** (`agent_failure`); per-activity commit
  120s (batch) / 60s (single); list-active-modernization 60s; latest-patterns commit 120s / 60s;
  persist-side-effects 120s; sweep-summary commit 120s / 60s. All git/list/persist use
  `transient` (3 attempts); only the agent dispatch uses `agent_failure` (3 attempts).
- **Heartbeats:** none configured (relies on start_to_close timeouts).
- **continue-as-new:** **none.** Each sweep is a single bounded run started by a Temporal Schedule;
  the workflow does not continue-as-new. A new sweep = a new workflow execution fired by the
  Schedule. A rebuild must NOT add continue-as-new.
- **Cancellation:** **none via signal** — there is no `cancel_workflow` signal and no `cancelled`
  flag (★ standalone, no HIL mixin). The only way to stop a sweep is Temporal's native
  terminate/cancel API (out of band). No `wait_condition` exists to drain on cancel.
- **Idempotency:** deterministic `activity_id`s where set —
  `governance-{activity}` (dispatch), `commit-governance-{activity}` (per-activity commit),
  `governance-list-modernization-{pid}-{sched}`, `commit-governance-latest-patterns-{pid}-{sched}`,
  `persist-governance-sweep-{pid}-{sched}`. ⚠️ The TWO sweep-summary commits (§9) deliberately omit
  `activity_id` (GOTCHA-SS2). `_now_iso()`/`workflow.now()` deterministic. The patch ID
  `governance-batch-writes-v1` gates batch-vs-single at three commit sites consistently.
- **Best-effort vs. fatal activity policy (★ asymmetric):**
  - **FATAL** (no try/except — failure fails the whole sweep via `gather`/propagation → run's
    except → FAILED + re-raise): the per-activity agent dispatch (`_dispatch_activity`), the
    per-activity commit (`_commit_activity_artifact`), and the **sweep-summary commit**
    (`_commit_sweep_summary`).
  - **BEST-EFFORT** (try/except logs + swallows, never fails the sweep): pattern propagation
    enumeration AND per-handle signal (`_propagate_patterns`), the latest-patterns registry commit
    (`_commit_latest_patterns_registry`), and the DB side-effect projection
    (`_persist_governance_sweep_side_effects`).
  A rebuild MUST reproduce this exact split — wrapping a fatal step in try/except (or vice-versa)
  changes failure semantics.
- **Compensation / rollback:** none. There is no rollback path. A failed sweep leaves whatever
  partial commits succeeded (per-activity artifacts that committed before the failure) on the
  per-sweep branch; the next scheduled sweep is an independent run on a new branch
  (`governance/{pid}/{next-schedule_id}`).
- **Terminal `FAILED` projection:** `run()`'s except stamps `_status=FAILED`,
  `_current_step="failed"`, `_updated_at` before re-raising (§3.1) so `get_status` reflects the
  failure. There is no DB failure-projection activity (unlike line workflows' `persist_wave_failure`).

---

## 13. Behavioral parity checklist

A rebuilt `GovernanceWorkflow` MUST satisfy ALL of the following:

1. **Standalone class** `class GovernanceWorkflow:` decorated `@workflow.defn` — does **NOT**
   inherit from `LineWorkflowBase` or `HILSignalsMixin`. No HIL state, no `cancelled`, no
   `cancel_workflow` signal, no gate signals, no `_wait_for_gate_decision`, no rework loop, no
   `_rework_iterations`, no `_gate_decisions`. (§intro)
2. `__init__` takes no args, does NOT call `super().__init__()`, and sets exactly 12 attrs to the
   initial values in §1 (`_portfolio_id=""`, `_schedule_id=""`, `_status=PENDING`,
   `_current_step=""`, `_progress_pct=0.0`, `_started_at=""`, `_updated_at=""`, `_findings={}`,
   `_activity_metadata={}`, `_activity_output_json={}`, `_wave_patterns_ready=[]`,
   `_pattern_reuse_acks=[]`).
3. **Exactly one** `@workflow.signal` — `wave_patterns_ready(signal: WavePatternsReadySignal)`,
   `async def`, no `await`/no `wait_condition`. Appends `{wave_id, patterns=list(...),
   acknowledged_at}` to `_wave_patterns_ready`; for each `pattern_name in (signal.patterns or [])`
   that `isinstance(str) and truthy`, appends `{"pattern_name": pattern_name, "delta": 1}` (key
   name **`delta`**, not `ack_count`) to `_pattern_reuse_acks`; bumps `_updated_at`. (§2.1,
   GOTCHA-ST2, SIG-DUAL)
4. **Exactly one** `@workflow.query` — `get_status() -> WorkflowStatusResponse` with hard-coded
   `current_line=AssemblyLine.GOVERNANCE` and `pending_gate=None`, reading live state +
   `workflow.info().workflow_id`. No updates defined. (§2.2)
5. `run()`: sets `RUNNING`/`_started_at`/`_updated_at`/`_portfolio_id`; `_schedule_id =
   input.schedule_id or "adhoc"`; `try: return await self._execute_sweep(input)`; `except
   Exception:` sets FAILED/`"failed"`/`_updated_at` then **`raise`** (NOT `return "failed"`).
   (§3.1, GOTCHA-RUN1/RUN2)
6. `_execute_sweep()` runs exactly 10 steps: intake → `asyncio.gather(*[_run_activity(a) for a in
   activities])` → progress 75 → `_propagate_patterns` → `_commit_latest_patterns_registry` →
   `_persist_governance_sweep_side_effects` → `_commit_sweep_summary` → progress 100 / COMPLETED /
   `"completed"` / return `"completed"`. Steps 2-7 are concurrent (`gather`); 8/9/10 sequential.
   (§3.2, GOTCHA-FAN1/FAN5)
7. `_run_activity(activity)` (nested coroutine): sets `_current_step=activity` + `_updated_at`;
   `result = await _dispatch_activity`; `_findings[activity]=result.output_artifacts`; `await
   _commit_activity_artifact`; `if activity == "pattern-extraction":` appends `{extracted_at,
   patterns=result.output_artifacts}` to `_wave_patterns_ready`. (§3.2, GOTCHA-FAN2)
8. Progress sequence is exactly **5 → 75 → 90 → 100** (intake / post-fan-out / persist / final).
   No per-activity progress increments. (GOTCHA-FAN3)
9. `_intake()` is pure (no activity), sets `"intake"` + 5.0, returns
   `_activities_for_schedule(schedule_id)`. (§4)
10. `_activities_for_schedule` returns `list(QUARTERLY_ACTIVITIES)` (6: weekly-5 +
    `model-evaluation`) iff `schedule_id.startswith("gov-quarterly")`, else `list(WEEKLY_ACTIVITIES)`
    (5). `_cadence_for_schedule` returns `"quarterly"`/`"weekly"` on the SAME prefix test. Both
    return COPIES. (§11.1/11.2, GOTCHA-REG3/REG4/CAD1)
11. `GOVERNANCE_ACTIVITIES`, `ACTIVITY_INPUT_ARTIFACTS`, the activity-set lists, the step-name
    constants, and `QUARTERLY_SCHEDULE_PREFIX="gov-quarterly"` are reproduced EXACTLY (§0.3),
    including `pattern-extraction` & `skill-evolution` both using `skill-builder` (GOTCHA-REG1) and
    `health-report` mapping to `[]` input artifacts.
12. `_dispatch_activity` builds `AgentTaskInput(task_type="governance-{activity}", app_id="",
    skill_id=act_def[...], input_artifacts=list(ACTIVITY_INPUT_ARTIFACTS.get(activity,[])),
    artifact_repo="", artifact_ref="", workspace_key="governance-{pid}-{sched}", context={4
    keys})`; dispatches `dispatch_agent_task` (**1h**, **`agent_failure`**,
    `activity_id="governance-{activity}"`); records 5-field `_activity_metadata[activity]` (NO
    `output_files`); reads raw text via `getattr(result,"output_text","") or
    getattr(result,"output","")` and stores into `_activity_output_json[activity]` ONLY if non-empty
    str. No execution_context, no context-priors, no rework_feedback. (§10, GOTCHA-DA1..7)
13. `_commit_activity_artifact` writes one JSON (16-ish keys incl. `findings`,
    `model_used`/`duration_ms`/`token_usage`/`cost_estimate_usd` from metadata, `timestamp =
    workflow.now().isoformat()`) to `governance/{pid}/{sched}/{artifact}` on branch
    `governance/{pid}/{sched}`; **patch-gated** `governance-batch-writes-v1` → `write_artifacts_batch`
    (120s) else `write_artifact` (60s); both `transient`,
    `activity_id="commit-governance-{activity}"`. **No try/except (fatal).** (§9.2, GOTCHA-CA1..4)
14. `_collect_pattern_bundle` flattens `_wave_patterns_ready[*]["patterns"]` into an
    order-preserving, **first-occurrence-wins** de-duped `list[str]`; skips entries whose
    `"patterns"` is not a list; keeps only non-empty str elements. (§5, GOTCHA-CB1)
15. `_propagate_patterns`: sets `"propagate-patterns"`+`_updated_at`; `if not bundle: return`;
    `try` enumerate via `list_active_modernization_workflows` (60s/`transient`,
    `activity_id="governance-list-modernization-{pid}-{sched}"`) `except` log+return; `if not
    workflow_ids: return`; build `WavePatternsReadySignal(wave_id="governance-sweep-{sched}",
    patterns=bundle)`; `for wf_id` → `get_external_workflow_handle(wf_id).signal("wave_patterns_ready",
    payload)` each in `try/except` log+**continue**. All best-effort. Signal dispatch in workflow,
    enumeration in activity. (§6, GOTCHA-PP1..4)
16. `_commit_latest_patterns_registry`: `if not bundle: return`; writes
    `governance/{pid}/latest-patterns.json` on **`main`** (NOT the sweep branch) with
    `{portfolio_id, schedule_id, updated_at, patterns:bundle, source:{sweep_wave_id, triggered_at}}`;
    **patch-gated** `governance-batch-writes-v1` → batch (120s) / single (60s), both `transient`,
    `activity_id="commit-governance-latest-patterns-{pid}-{sched}"`; whole thing in `try/except`
    log+swallow (best-effort). (§7, GOTCHA-LP1..3)
17. `_persist_governance_sweep_side_effects`: sets `"persist-governance-sweep-side-effects"`+90.0;
    builds `PersistGovernanceSweepSideEffectsInput` with `cadence`, the four always-on JSON fields
    via `_activity_output_json.get(...,"")`, `model_evaluation_json = (...get("model-evaluation","")
    if cadence=="quarterly" else "")`, and `pattern_reuse_acks=list(self._pattern_reuse_acks)` (a
    COPY); dispatches `persist_governance_sweep_side_effects` (120s/`transient`,
    `activity_id="persist-governance-sweep-{pid}-{sched}"`) in `try/except` log+swallow
    (best-effort). (§8, GOTCHA-PS1..5)
18. `_commit_sweep_summary`: sets `"commit-sweep-summary"`+`_updated_at`; builds summary
    `{portfolio_id, schedule_id, cadence, triggered_at, completed_at, activities:{<activity>:
    {artifact, skill_id, findings_count=len(_findings.get(activity,[]))} for activity in
    activities}, wave_patterns_ready: <whole live list>, pattern_reuse_acks: <live list>}`; writes
    to `governance/{pid}/{sched}/sweep-summary.json` on branch `governance/{pid}/{sched}`;
    **patch-gated** `governance-batch-writes-v1` → batch (120s) / single (60s), both `transient`,
    **NO `activity_id`**. **No try/except (FATAL).** (§9, GOTCHA-SS1..5)
19. **Asymmetric failure semantics** honored exactly: agent dispatch, per-activity commit, and
    sweep-summary commit are FATAL (no try/except → propagate → run's except → FAILED+re-raise);
    propagation, latest-patterns registry, and DB side-effect projection are BEST-EFFORT (try/except
    log+swallow). (§12)
20. All `workflow.patched(...)` IDs reproduced VERBATIM: `"governance-batch-writes-v1"` at all
    THREE commit sites (`_commit_activity_artifact`, `_commit_latest_patterns_registry`,
    `_commit_sweep_summary`), each with the same batch-vs-single dichotomy.
21. `_governance_repo(pid) == f"olympus/{pid}-governance"`; `_now_iso() ==
    workflow.now().isoformat()`; no `datetime.now()`/random/continue-as-new/heartbeats anywhere;
    all activity imports inside `with workflow.unsafe.imports_passed_through():`. (§0, §11.3, §12)
22. Uses only `RETRY_POLICIES["transient"]` (git/list/persist) and `RETRY_POLICIES["agent_failure"]`
    (dispatch). Never uses `git_merge`/`validation_failure`/`timeout`/`infrastructure`. (§0.2,
    GOTCHA-RP1)
