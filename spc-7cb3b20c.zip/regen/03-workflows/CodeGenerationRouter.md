# `code_generation_router` — Code-Generation Skill-Variant Router (ATOMIC regeneration spec)

> **Source of truth:** `temporal/olympus_workflows/workflows/code_generation_router.py` (93 lines).
> Every `code_generation_router.py:line` citation below is against that file.
>
> **What this is:** a **pure-Python helper module** — NOT a Temporal `@workflow.defn` class. It
> exposes two module-level lookup tables and a single pure function,
> `select_code_generation_skill(...)`, that maps `(target_framework, target_frontend,
> primary_language)` to the id of the correct `code-generation-*` skill variant the Ralph Loop
> should dispatch. It is the code-generation analogue of `modernization.py`'s
> `LANGUAGE_SKILL_MAP` + `_select_extraction_skill` extraction router
> (`code_generation_router.py:4-6`).
>
> **This module has NO `run()` / `_execute()`, NO `@workflow.signal`, NO `@workflow.query`, NO
> instance state, NO activity calls, NO child-workflow calls, NO gates, NO rework loop.** It is a
> stateless lookup function below the Temporal workflow boundary. The mandatory-rule sections that
> normally cover STATE / SIGNALS / ACTIVITY-CALLS / GATE-HANDLING / RESILIENCE are therefore marked
> **N/A — and exactly why** (see §6). The whole substance is the routing control flow in §3.
>
> ⚠️ **GOTCHA-CGR-TEMPORAL-BOUNDARY (no Temporal imports — by design):** the module docstring
> (`code_generation_router.py:28-30`) mandates: *"Keep this module pure Python with no Temporal
> imports so it can be exercised by unit tests directly (the Temporal sandbox does not hold on
> import — we're below the workflow boundary)."* The function is **called from inside a workflow
> `run()`** (`generate_bc.py:126`, see §5) but is itself deterministic pure Python — no I/O, no
> wall-clock, no random — so it is replay-safe and needs no `workflow.patched(...)` gate, no
> `imports_passed_through()` wrapper, and no activity round-trip. A rebuild MUST keep it import-pure
> (only `from __future__ import annotations`, `code_generation_router.py:33`) and MUST NOT add any
> `temporalio`/`workflow` import — doing so would (a) break the direct unit tests and (b) risk
> pulling the sandbox import machinery in below the workflow boundary.

---

## 0. Module provenance (docstring) — why this is Python, not a skill

`code_generation_router.py:1-31` records the ATLAS-skills-integration Stage 3 decision
(`specifications/atlas-skills-integration.md`):

- The ATLAS catalog shipped a `code-generation-router` `SKILL.md` **plus** a
  `code-generation-abstract` dispatcher. **Both were REJECTED** per `CONVENTIONS.md §2` — *"If its
  job is 'pick who does the thinking next,' it's orchestration"* — and lifted into this Python
  module instead (`code_generation_router.py:8-14`).
- The generic `code-generation` skill **remains as the default fallback**
  (`code_generation_router.py:13-14`, `47`).
- The module is **importable from BOTH** (`code_generation_router.py:23-27`):
  - `modernization.py` (legacy bridge — `_select_extraction_skill` sits alongside for symmetry;
    `modernization.py:104-108` imports it and `modernization.py:124-129` re-exports the two maps +
    function for back-compat with callers that historically imported them from `modernization.py`).
  - `generate_bc.py` (the Ralph-Loop dispatch call — `generate_bc.py:45-47`, `:126`).

⚠️ **GOTCHA-CGR-REEXPORT (two import paths, one authority):** `CODE_GENERATION_PAIR_MAP`,
`CODE_GENERATION_SKILL_MAP`, and `select_code_generation_skill` are RE-EXPORTED from
`modernization.py` via its `__all__` (`modernization.py:124-129`) purely so legacy code that did
`from ...modernization import select_code_generation_skill` keeps working. The **authoritative
definitions live in `code_generation_router`** (`modernization.py:119-123`). A rebuild that splits
these maps must keep `modernization.py` re-exporting them (or it breaks those legacy imports), but
must NOT duplicate/diverge the table contents — there is exactly one source of truth.

---

## 1. MODULE-LEVEL CONSTANTS — the two lookup tables (verbatim)

These are module-level `dict` literals, evaluated once at import. They are the ONLY mutable-looking
state in the module, but they are **read-only in practice** (never mutated anywhere). A rebuild MUST
reproduce both tables EXACTLY — keys, values, ordering of the resolution semantics, and the
lowercase convention.

### 1.1 `CODE_GENERATION_SKILL_MAP: dict[str, str]` — `code_generation_router.py:39-48`

Target-framework / target-frontend → skill variant. Keyed by the **framework or frontend** primarily,
with a source-language fallback handled separately by the pair map (§1.2). Comment
(`code_generation_router.py:35-38`): *"Additive to `LANGUAGE_SKILL_MAP` — code-generation picks by
target framework/frontend primarily, with source-language fallback for legacy-migration specialists."*

| Key (lowercase) | Value (skill id) | Source line |
|-----------------|------------------|-------------|
| `"springboot"`   | `"code-generation-springboot"` | `:40` |
| `"aspnet-core"`  | `"code-generation-dotnet"`     | `:41` |
| `"dotnet"`       | `"code-generation-dotnet"`     | `:42` |
| `"fastapi"`      | `"code-generation-fastapi"`    | `:43` |
| `"express"`      | `"code-generation-node"`       | `:44` |
| `"fastify"`      | `"code-generation-node"`       | `:45` |
| `"react"`        | `"code-generation-react"`      | `:46` |
| `"default"`      | `"code-generation"`            | `:47` |

⚠️ **GOTCHA-CGR-MAP1 (two keys collapse to `code-generation-dotnet`):** both `"aspnet-core"` and
`"dotnet"` map to `"code-generation-dotnet"` (`:41-42`); both `"express"` and `"fastify"` map to
`"code-generation-node"` (`:44-45`). A rebuild must keep ALL FOUR keys — not just one per target
skill — because the *input* `target_framework`/`target_frontend` strings come in either spelling and
must all resolve.

⚠️ **GOTCHA-CGR-MAP2 (`"react"` lives in the SAME map as backend frameworks):** `"react"` is a
`target_frontend` value but sits in `CODE_GENERATION_SKILL_MAP` alongside backend frameworks (`:46`).
This is deliberate so the single `dict` serves BOTH the frontend lookup (§3 branch 2) and the
framework lookup (§3 branch 3). A rebuild must NOT split it into two dicts — the resolution order
relies on `target_frontend` being checked against this same map FIRST (so a React frontend wins over
a backend framework when both are set).

⚠️ **GOTCHA-CGR-MAP3 (`"default"` is a real dict key, not a `.get(...)` fallback):** the generic
fallback is stored under the literal key `"default"` (`:47`) and is returned by **explicit subscript**
`CODE_GENERATION_SKILL_MAP["default"]` at `:92` — NOT via `dict.get(key, "code-generation")`. A
rebuild MUST keep `"default"` as a present key; if it were removed, the final `return` (§3 branch 4)
would raise `KeyError` instead of returning the generic skill.

### 1.2 `CODE_GENERATION_PAIR_MAP: dict[tuple[str, str], str]` — `code_generation_router.py:54-57`

Specialist **legacy-migration** pairs `(source_language, target_framework)` → specialist skill. These
**outrank** the target-only map (checked first in §3) *"because they encode source idioms too (COBOL
division/PERFORM semantics, NATURAL GDA / MU / PE flattening)"* (`code_generation_router.py:50-53`).

| Key tuple (both lowercase) | Value (skill id) | Source line |
|----------------------------|------------------|-------------|
| `("cobol", "springboot")`   | `"code-generation-cobol-to-java"`          | `:55` |
| `("natural", "springboot")` | `"code-generation-natural-to-springboot"`  | `:56` |

⚠️ **GOTCHA-CGR-MAP4 (the tuple key order is `(language, framework)`, NOT `(framework, language)`):**
the dict is keyed `(source_language, target_framework)` and the lookup at `:85` builds
`key = (primary_language.lower(), target_framework.lower())` in that exact order. A rebuild MUST build
the probe tuple in `(primary_language, target_framework)` order — reversing it would never hit either
entry (lookup miss → falls through to the target-only map).

⚠️ **GOTCHA-CGR-MAP5 (both specialist pairs share `"springboot"` as the framework half):** both
COBOL→Java and NATURAL→SpringBoot target `springboot`. So when `target_framework="springboot"` and
`primary_language` is `"cobol"` or `"natural"`, the **pair map wins** over the plain
`CODE_GENERATION_SKILL_MAP["springboot"] = "code-generation-springboot"` (which is what a non-legacy
SpringBoot target would get). This is the entire reason the pair check is FIRST. A rebuild must
preserve the precedence: a COBOL→SpringBoot job gets `code-generation-cobol-to-java`, NOT
`code-generation-springboot`.

---

## 2. PUBLIC SIGNATURE — `select_code_generation_skill(...)` (`code_generation_router.py:60-64`)

```text
def select_code_generation_skill(
    target_framework:  str | None,
    target_frontend:   str | None,
    primary_language:  str | None,
) -> str:
```

- **All three params are `str | None`** (`:61-63`). Any may be `None` (legacy callers / unknown
  stacks) or `""` (empty). Both are treated as "absent" by the truthiness guards in §3.
- **Return type is always `str`** (`:64`, `:80-82`): the function NEVER returns `None`, NEVER raises
  on absent/unmatched inputs — it always falls back to the generic `'code-generation'` via the
  `"default"` key. (`code_generation_router.py:80-82`: *"Always a string; falls back to the generic
  `'code-generation'` when inputs are absent / unmatched."*)
- **Callers invoke it BY KEYWORD** (`generate_bc.py:126-130`):
  `select_code_generation_skill(target_framework=..., target_frontend=..., primary_language=...)`.
  Positional order is nonetheless `(target_framework, target_frontend, primary_language)`. A rebuild
  must preserve BOTH the parameter names (callers pass by keyword) AND the positional order.

---

## 3. CONTROL FLOW — the routing logic, branch-by-branch (`code_generation_router.py:84-92`)

This is the entire behavioral surface. The function is **9 lines of body** containing **4
branch-points** (the four `if`s at `:84`, `:86`, `:88`, `:90`) plus the unconditional final `return`.
Reproduced as structured pseudocode with EVERY branch preserved and each case's exact resolution:

```text
def select_code_generation_skill(target_framework, target_frontend, primary_language) -> str:

    # ── Resolution step 1: specialist legacy-migration PAIR match (highest precedence) ──
    if primary_language and target_framework:                      # :84  BRANCH 1 (both truthy)
        key = (primary_language.lower(), target_framework.lower())  # :85  build (lang, fw) tuple
        if key in CODE_GENERATION_PAIR_MAP:                         # :86  BRANCH 2 (pair hit?)
            return CODE_GENERATION_PAIR_MAP[key]                    # :87  ← EARLY RETURN, specialist

    # ── Resolution step 2: target_frontend match (e.g. React SPA) ──
    if target_frontend and target_frontend.lower() in CODE_GENERATION_SKILL_MAP:   # :88  BRANCH 3
        return CODE_GENERATION_SKILL_MAP[target_frontend.lower()]   # :89  ← EARLY RETURN, frontend

    # ── Resolution step 3: target_framework match ──
    if target_framework and target_framework.lower() in CODE_GENERATION_SKILL_MAP: # :90  BRANCH 4
        return CODE_GENERATION_SKILL_MAP[target_framework.lower()]  # :91  ← EARLY RETURN, framework

    # ── Resolution step 4: default generic ──
    return CODE_GENERATION_SKILL_MAP["default"]                    # :92  ← unconditional fallback
```

### 3.1 Branch inventory (4 branch-points — ALL in scope, ALL reproduced)

| # | Source | Predicate | True path | False path |
|---|--------|-----------|-----------|------------|
| **1** | `:84` | `if primary_language and target_framework:` — **both** non-empty/non-None | enter the pair-lookup block (build tuple, test BRANCH 2) | skip pair lookup, fall to BRANCH 3 |
| **2** | `:86` | `if key in CODE_GENERATION_PAIR_MAP:` — the `(lang, fw)` tuple is a known specialist pair | **early-return** `CODE_GENERATION_PAIR_MAP[key]` (`:87`) | fall through (out of the BRANCH-1 block) to BRANCH 3 |
| **3** | `:88` | `if target_frontend and target_frontend.lower() in CODE_GENERATION_SKILL_MAP:` | **early-return** `CODE_GENERATION_SKILL_MAP[target_frontend.lower()]` (`:89`) | fall to BRANCH 4 |
| **4** | `:90` | `if target_framework and target_framework.lower() in CODE_GENERATION_SKILL_MAP:` | **early-return** `CODE_GENERATION_SKILL_MAP[target_framework.lower()]` (`:91`) | fall to the unconditional `return …["default"]` (`:92`) |

> **Branch-count reconciliation:** the task estimate is ~4 branch-points. The four `if` statements
> above (`:84`, `:86`, `:88`, `:90`) are exactly those four; the final `return` at `:92` is
> unconditional (not a branch). There are NO loops, NO `try/except`, NO `match/case`, NO `elif/else`
> in this module. All 4 in-scope branches are reproduced.

### 3.2 The four exhaustive resolution outcomes (worked, in precedence order)

This is the canonical **resolution order, most → least specific** (`code_generation_router.py:16-21`,
restated in the function docstring `:67-72`):

1. **Specialist pair** (BRANCH 1 true **and** BRANCH 2 true): `(primary_language.lower(),
   target_framework.lower())` is in `CODE_GENERATION_PAIR_MAP` → return the specialist skill (`:87`).
   - `("cobol","springboot")` → `"code-generation-cobol-to-java"`.
   - `("natural","springboot")` → `"code-generation-natural-to-springboot"`.
2. **Frontend** (BRANCH 1/2 didn't return, BRANCH 3 true): `target_frontend.lower()` is in
   `CODE_GENERATION_SKILL_MAP` → return that (`:89`). e.g. `target_frontend="React"` →
   `"code-generation-react"`.
3. **Framework** (BRANCHes 1-3 didn't return, BRANCH 4 true): `target_framework.lower()` is in
   `CODE_GENERATION_SKILL_MAP` → return that (`:91`). e.g. `target_framework="FastAPI"` →
   `"code-generation-fastapi"`; `"aspnet-core"` → `"code-generation-dotnet"`; `"express"` →
   `"code-generation-node"`.
4. **Default** (no branch returned): `return CODE_GENERATION_SKILL_MAP["default"]` →
   `"code-generation"` (`:92`). Reached when all inputs are `None`/`""`, or none of the supplied
   strings match any key (e.g. an unknown framework like `"flask"`).

### 3.3 Ordering-dependent & non-obvious behavior (⚠️ GOTCHAs)

⚠️ **GOTCHA-CGR-PRECEDENCE (frontend OUTRANKS framework — `:88` is tested BEFORE `:90`):** when a
caller supplies BOTH a `target_frontend` that's in the map AND a `target_framework` that's in the map
(e.g. `target_frontend="react"`, `target_framework="fastapi"`), the function returns the **frontend**
skill `"code-generation-react"` (BRANCH 3 returns first at `:89`) and NEVER reaches the framework
check at `:90`. A rebuild MUST test frontend before framework — swapping `:88` and `:90` would flip a
React-SPA-with-FastAPI-backend job from `code-generation-react` to `code-generation-fastapi`. (The
docstring resolution order `:16-21` codifies this: frontend is item 2, framework is item 3.)

⚠️ **GOTCHA-CGR-PAIR-FIRST (specialist pair OUTRANKS everything — `:84` block is first):** a
COBOL→SpringBoot job (`primary_language="cobol"`, `target_framework="springboot"`) returns
`"code-generation-cobol-to-java"` (BRANCH 2 at `:87`), NOT `"code-generation-springboot"` (which the
plain framework lookup at `:90`/`:91` would yield). A rebuild must keep the pair block first so source
idioms win. See GOTCHA-CGR-MAP5.

⚠️ **GOTCHA-CGR-PAIR-FALLTHROUGH (pair MISS does NOT return — it falls through to frontend/framework):**
if BRANCH 1 is true (both `primary_language` and `target_framework` set) but BRANCH 2 is false (the
`(lang, fw)` tuple is NOT a known specialist pair — e.g. `("java","springboot")`), the function does
**not** return inside the block — it falls out and continues to BRANCH 3 then BRANCH 4. So
`primary_language="java"`, `target_framework="springboot"` resolves via the **framework** path to
`"code-generation-springboot"` (`:91`). A rebuild MUST NOT add an `else: return default` inside the
pair block — the pair check is a *try-and-continue*, not a terminal switch. (The `return` at `:87` is
nested two levels deep, *inside both* `if`s, precisely so a pair miss falls through.)

⚠️ **GOTCHA-CGR-CASEFOLD (every lookup is `.lower()`-normalized; inputs are NOT pre-normalized):**
all comparisons lowercase the input at the comparison site — `primary_language.lower()` (`:85`),
`target_framework.lower()` (`:85`, `:90`, `:91`), `target_frontend.lower()` (`:88`, `:89`). The map
**keys are already lowercase** (§1). So `"SpringBoot"`, `"SPRINGBOOT"`, `"springboot"` all resolve;
`"React"` → `"code-generation-react"`. A rebuild MUST lowercase the input at lookup time AND store
lowercase keys — relying on caller-supplied casing would miss `"FastAPI"`/`"React"` etc. (which is
exactly how `LineWorkflowInput.target_frontend` may arrive, e.g. `"React"` from a blueprint).

⚠️ **GOTCHA-CGR-EMPTY-VS-NONE (truthiness guard treats `""` and `None` identically):** every branch
guards with plain truthiness (`if primary_language and target_framework`, `if target_frontend and …`,
`if target_framework and …`) — NOT `is not None`. So an empty string `""` is "absent" exactly like
`None`. A `LineWorkflowInput`/`GenerateBCInput` whose `target_framework=""` (default empty, see
types.py) routes to default just as `None` would. A rebuild MUST use truthiness, NOT `is not None`,
or empty-string inputs would attempt a `"".lower()` → `""` lookup, miss, and (harmlessly here) fall
through — but the BRANCH-1 pair tuple `(lang, "")` would also be built and probed, which is a wasted
lookup the truthiness guard avoids. Behavior is identical for the empty-string case **only because**
`""` is never a map key; keep the truthiness guard to match exactly.

⚠️ **GOTCHA-CGR-MEMBERSHIP-THEN-SUBSCRIPT (each map branch tests membership, then re-subscripts):**
BRANCHes 3 and 4 do `if X.lower() in MAP: return MAP[X.lower()]` — a membership test followed by a
subscript with the same lowered key. A rebuild may use a single `.get(...)` internally, but MUST
preserve the observable result (return the mapped value, or fall through on miss). The pair branch
(BRANCH 2) likewise tests `key in CODE_GENERATION_PAIR_MAP` then subscripts `[key]`. There is no
`KeyError` risk on any of these because membership is checked first; the ONLY direct (un-guarded)
subscript is the final `["default"]` at `:92` (safe because `"default"` is always present — see
GOTCHA-CGR-MAP3).

---

## 4. STATE / SIGNALS / QUERIES / UPDATES — N/A (and exactly why)

- **STATE:** there are **no instance variables** — this is a module-level function, not a class. The
  only module-level objects are the two read-only `dict` constants (§1), evaluated once at import and
  never mutated. There is nothing analogous to `LineWorkflowBase.__init__`'s 19 line-state vars.
- **SIGNALS / QUERIES / UPDATES:** **none.** No `@workflow.signal`, `@workflow.query`,
  `@workflow.update`. This module does not inherit `HILSignalsMixin` or `LineWorkflowBase` (see
  `_HILSignalsMixin.md` / `_LineWorkflowBase.md` for the surface this module deliberately does NOT
  have). It has no `wait_condition`, no buffered decisions, no cancel handling — there is no signal
  surface to override or protect (no GOTCHA-SIG0 equivalent).
- **Relationship to the base specs:** the **callers** (`GenerateBCWorkflow`, `ModernizationWorkflow`)
  carry the signal/gate/state machinery; this module is a leaf they call synchronously. It OVERRIDES
  nothing from `LineWorkflowBase`/`HILSignalsMixin` because it does not inherit them.

---

## 5. WHO CALLS IT — invocation sites (in order, with exact arg shape)

### 5.1 `GenerateBCWorkflow.run()` — the Ralph Loop (PRIMARY caller)

`generate_bc.py:126-130`, inside the `while self._iteration < MAX_RALPH_ITERATIONS:` loop
(`generate_bc.py:96`), **Step 2 (Generate code)**:

```text
code_generation_skill_id = select_code_generation_skill(
    target_framework = input.target_framework,   # GenerateBCInput field
    target_frontend  = input.target_frontend,     # GenerateBCInput field
    primary_language = input.primary_language,    # GenerateBCInput field
)
code_result = await workflow.execute_activity(
    dispatch_agent_task,
    AgentTaskInput(
        task_type       = f"generate-code-{input.bc_name}",
        app_id          = input.app_id,
        skill_id        = code_generation_skill_id,   # ← the router's return value
        input_artifacts = tdd_result.output_artifacts,
        source_repo     = input.source_repo,
    ),
    start_to_close_timeout = timedelta(hours=1),
    retry_policy           = RETRY_POLICIES["agent_failure"],
    activity_id            = f"codegen-{input.bc_name}-iter{self._iteration}",
)
```

- The returned `skill_id` becomes `AgentTaskInput.skill_id` for the **code-generation dispatch** in
  the Ralph Loop's Step 2. Steps 1 (TDD, `skill_id="tdd-generation"`) and 3 (validation,
  `skill_id="test-validation"`) use FIXED skill ids — only Step 2 is router-driven
  (`generate_bc.py:102-158`).
- ⚠️ **GOTCHA-CGR-CALL1 (re-resolved EVERY Ralph iteration — deterministically):** the call sits
  INSIDE the `while` loop, so it runs once per iteration. Because the function is pure and its inputs
  (`input.target_framework/target_frontend/primary_language`) are immutable workflow input, it returns
  the **same skill id every iteration** and on every replay — deterministic. A rebuild may hoist it
  out of the loop for efficiency ONLY if it preserves determinism; the in-loop placement is harmless
  and matches the source. (The `dispatch_agent_task` activity itself is keyed
  `activity_id=f"codegen-{bc_name}-iter{iteration}"` for replay stability — that idempotency is the
  activity's, not the router's.)
- The three inputs originate from `GenerateBCInput` (`types.py:2563-2589`); the wave coordinator
  threads them from the target-architecture blueprint (or the `classify-application` output). When all
  three are `None`, the router returns generic `code-generation` (types.py:2584-2589 comment;
  `generate_bc.py:118-125` comment).

### 5.2 `modernization.py` — import + re-export (NOT a direct functional call)

`modernization.py:104-108` imports `CODE_GENERATION_PAIR_MAP`, `CODE_GENERATION_SKILL_MAP`, and
`select_code_generation_skill`; `modernization.py:124-129` lists all three (plus its own
`LANGUAGE_SKILL_MAP`) in `__all__` to **re-export** them for back-compat (see GOTCHA-CGR-REEXPORT).
`modernization.py` keeps the symmetric *extraction* router (`LANGUAGE_SKILL_MAP` +
`_select_extraction_skill`) alongside; it does NOT itself call `select_code_generation_skill` at
runtime (the Ralph-Loop dispatch is delegated to `GenerateBCWorkflow`). A rebuild must preserve the
import + re-export so legacy `from ...modernization import select_code_generation_skill` resolves.

### 5.3 Sibling routers (same pattern, NOT callers of this module)

`data_router.py`, `architecture_patterns_router.py`, and `discovery_patterns_router.py` reference this
module only in docstrings as the *pattern they mirror* (`data_router.py:7`,
`architecture_patterns_router.py:7`, `discovery_patterns_router.py:6`). They are independent routers
(`select_data_product_skill`, etc.) and do NOT import or call `select_code_generation_skill`. Do not
wire any dependency between them.

---

## 6. CONTROL-FLOW-ADJACENT MANDATORY SECTIONS — N/A justifications

| Mandatory rule | Status here | Why |
|----------------|-------------|-----|
| **ACTIVITY & CHILD-WORKFLOW calls (args / retry / timeout / non_retryable / sequential vs parallel)** | **NONE** | The function makes no `workflow.execute_activity` / `execute_child_workflow` calls. It is pure CPU lookup. The *caller* (`generate_bc.py:131-143`) wraps the result in a `dispatch_agent_task` activity (1h timeout, `agent_failure` policy, `activity_id="codegen-{bc}-iter{n}"`) — that is GenerateBC's resilience, not the router's. |
| **GATE handling (evidence / wait / approve-reject-merge_blocked-rework / counters)** | **NONE** | No gates, no `_wait_for_gate_decision`, no `_rework_feedback`, no counters. Gate orchestration lives in `LineWorkflowBase` (`_LineWorkflowBase.md` §13–§17) and the per-line `run()`s — never here. |
| **RESILIENCE (timeouts / heartbeats / continue-as-new / idempotency / compensation / rollback)** | **NONE intrinsic** | No timeouts, heartbeats, continue-as-new, compensation, or rollback. **Idempotency/determinism is structural:** pure function of its args, no I/O, no `datetime.now()`, no `random`, no module-state mutation → identical output for identical input on every call and every Temporal replay. No `workflow.patched(...)` gate is needed precisely because it adds no activity and changes no history. |
| **SIGNALS / QUERIES / UPDATES** | **NONE** | See §4. |
| **STATE (instance vars, mutation)** | **NONE (instance)** | See §4. Two read-only module-level dicts only. |

---

## 7. Behavioral parity checklist

A rebuilt `code_generation_router` MUST satisfy ALL of the following:

1. **Module is import-pure** — only `from __future__ import annotations`
   (`code_generation_router.py:33`); **NO `temporalio`/`workflow` import**; directly unit-testable
   without a Temporal worker. (GOTCHA-CGR-TEMPORAL-BOUNDARY)
2. **`CODE_GENERATION_SKILL_MAP`** contains EXACTLY the 8 entries in §1.1 — including BOTH
   `"aspnet-core"`→`code-generation-dotnet` AND `"dotnet"`→`code-generation-dotnet`, BOTH
   `"express"`→`code-generation-node` AND `"fastify"`→`code-generation-node`, and `"react"`→
   `code-generation-react` living in this same dict. The literal key `"default"` is present and maps
   to `"code-generation"`. (GOTCHA-CGR-MAP1/2/3)
3. **`CODE_GENERATION_PAIR_MAP`** contains EXACTLY `("cobol","springboot")`→`code-generation-cobol-to-java`
   and `("natural","springboot")`→`code-generation-natural-to-springboot`, keyed `(language,
   framework)` (not reversed). (GOTCHA-CGR-MAP4/5)
4. **Signature** is `select_code_generation_skill(target_framework: str | None, target_frontend:
   str | None, primary_language: str | None) -> str`; parameter NAMES preserved (callers pass by
   keyword); always returns a `str`; never returns `None`; never raises on absent/unknown inputs.
5. **Resolution order is exactly pair → frontend → framework → default**, implemented as the four
   branches at `:84`, `:86`, `:88`, `:90` and the unconditional `return …["default"]` at `:92`:
   - `if primary_language and target_framework:` then `if (lang.lower(), fw.lower()) in PAIR_MAP:
     return PAIR_MAP[...]` (early). (BRANCH 1, 2)
   - `if target_frontend and target_frontend.lower() in SKILL_MAP: return SKILL_MAP[...]` (early).
     (BRANCH 3)
   - `if target_framework and target_framework.lower() in SKILL_MAP: return SKILL_MAP[...]` (early).
     (BRANCH 4)
   - `return SKILL_MAP["default"]`.
6. **Frontend OUTRANKS framework** — `target_frontend="react"` + `target_framework="fastapi"` →
   `"code-generation-react"` (NOT fastapi). (GOTCHA-CGR-PRECEDENCE)
7. **Specialist pair OUTRANKS plain framework** — `primary_language="cobol"` +
   `target_framework="springboot"` → `"code-generation-cobol-to-java"` (NOT
   `code-generation-springboot`). (GOTCHA-CGR-PAIR-FIRST)
8. **Pair MISS falls through** (does NOT return default early) — `primary_language="java"` +
   `target_framework="springboot"` → `"code-generation-springboot"` (resolved by the framework branch,
   not short-circuited by the pair block). The pair `return` is nested inside BOTH `if`s.
   (GOTCHA-CGR-PAIR-FALLTHROUGH)
9. **All lookups are `.lower()`-normalized at the comparison site**, map keys are lowercase:
   `"SpringBoot"`/`"SPRINGBOOT"`/`"React"`/`"FastAPI"` all resolve correctly. (GOTCHA-CGR-CASEFOLD)
10. **Truthiness guards** (`if x and y`, not `is not None`): `target_framework=""` /
    `target_frontend=""` / `primary_language=""` behave identically to `None` → fall through to
    default when nothing matches. (GOTCHA-CGR-EMPTY-VS-NONE)
11. **Exhaustive routing table holds** (case-insensitive inputs):
    - `("cobol","springboot",*)` → `code-generation-cobol-to-java`
    - `("natural","springboot",*)` → `code-generation-natural-to-springboot`
    - `(_, frontend="react", _)` → `code-generation-react`
    - `(fw="springboot", no frontend, lang∉{cobol,natural})` → `code-generation-springboot`
    - `(fw∈{"aspnet-core","dotnet"})` → `code-generation-dotnet`
    - `(fw="fastapi")` → `code-generation-fastapi`
    - `(fw∈{"express","fastify"})` → `code-generation-node`
    - all `None`/`""` OR unknown framework (e.g. `"flask"`) with no frontend → `code-generation`
12. **Pure & deterministic** — no I/O, no wall-clock/`datetime.now()`, no `random`, no module-state
    mutation; identical output for identical input across calls and Temporal replays; safe to call
    once-per-Ralph-iteration from `GenerateBCWorkflow.run()`. (GOTCHA-CGR-CALL1, §6)
13. **`modernization.py` re-exports** `CODE_GENERATION_PAIR_MAP`, `CODE_GENERATION_SKILL_MAP`,
    `select_code_generation_skill` via `__all__` so legacy imports from that module still resolve, but
    the authoritative definitions live ONLY in `code_generation_router`. (GOTCHA-CGR-REEXPORT)
