# `LineWorkflowBase` — Shared Line-Workflow Engine (ATOMIC regeneration spec)

> **Source of truth:** `temporal/olympus_workflows/workflows/base.py` (1353 lines, HEAD `7cb3b20c`).
> Every `base.py:line` citation below is against that file.
>
> **What this is:** the shared engine that the per-app/per-portfolio line workflows inherit. At HEAD
> `7cb3b20c` there are exactly **8** subclasses (verified — `grep 'class \w\+(.*LineWorkflowBase'`):
> `ArchitectureWorkflow` (`architecture.py:379`), `DataWorkflow` (`data.py:270`),
> `DeploymentWorkflow` (`deployment.py:265`), `DiscoveryWorkflow` (`discovery.py:160`),
> `DispositionWorkflow` (`disposition.py:208`), `ModernizationWorkflow` (`modernization.py:207` —
> the only bundle-aware line, MRO `class ModernizationWorkflow(BundleAwareMixin, LineWorkflowBase)`),
> `RationalizationWorkflow` (`rationalization.py:103`), `ValidationWorkflow` (`validation.py:195`).
> ⚠️ **There is NO `BuildWorkflow` / `build*.py` workflow at HEAD** — the "build" assembly line lives
> in the `assembly-lines/` specs + registry, not as a `LineWorkflowBase` subclass. The module
> docstring (`base.py:1-6`) says it eliminates "~1,500+ LOC of
> duplicated helpers (dispatch, commit, gate PR, evidence submission, gate decision wait,
> progress tracking, signal handlers, query)". Each subclass spec states explicitly which base
> methods it overrides.
>
> **Inherits:** `class LineWorkflowBase(HILSignalsMixin)` (`base.py:106`). See `_HILSignalsMixin.md`
> for the inherited HIL signal surface (`approve_plan`, `provide_plan_feedback`,
> `approve_research`, `provide_feedback`, `approve`, `cancel_workflow`, the `reset_*` /
> `is_*_decision_received` helpers, and the `create_*_signal` factories).
> `LineWorkflowBase.__init__` calls `super().__init__()` first (`base.py:132`) so all HIL state vars
> are initialized before the line-specific state.
>
> **`LineWorkflowBase` has NO `run()` / `_execute()`.** It is a toolkit of helpers + signal/query
> handlers. The actual orchestration `run()` lives in each subclass. This file specs the shared
> toolkit; the per-line `run()` flows are in the per-line specs and reference this file.
>
> ⚠️ **CHANGED-AT-HEAD (Phase 6 W1 — paired-work / delegated-bundle dispatch):** the biggest delta
> from the prior baseline (1087 → 1353 LOC) is a whole new helper block (`base.py:477-723`):
> `_load_delegation_config`, `_maybe_dispatch_bundle`, `_dispatch_bundle_and_wait`,
> `_apply_bundle_fallback`, `_workflow_created_by`, plus three new `__init__` state vars
> (`_profile_id`, `_portfolio_fallback_policy`, `_redispatch_guard`). This is the "delegate a
> step/gate to a human pair vs. run it internally" generalization point. It is fully additive: a
> line that never calls `_maybe_dispatch_bundle` behaves exactly as before. See §8a. **Branch
> count rose from ~33 to ~45 — all the new branches live in §8a.**
>
> **Determinism invariants (`base.py:29-32`):** no wall-clock/random/external-I/O in this module;
> `workflow.patched(...)` patch IDs are passed verbatim; all state is attribute-based (no
> module-level mutation). The only time source is `_now_iso()` → `workflow.now().isoformat()`
> (`base.py:101-103`), which is deterministic under Temporal replay.

---

## 0. Imports, retry policies, and the time helper

- Imports gated behind `with workflow.unsafe.imports_passed_through():` (`base.py:45`) —
  `ActivityError`, `ApplicationError`, all activity functions, `RETRY_POLICIES`, and all the
  shared types. ⚠️ **GOTCHA-IMPORTS:** these MUST be inside `imports_passed_through()` so the
  Temporal sandbox doesn't re-import (and re-execute) them on replay. A rebuild that moves them to
  the top level risks sandbox nondeterminism / import-time side effects.
- ⚠️ **CHANGED-AT-HEAD (new imports):** the import block (`base.py:46-98`) now ALSO pulls in the
  paired-work surface: `from olympus_workflows.activities.bundle_activities import (
  DISPATCH_MODE_DELEGATED_BUNDLE, dispatch_delegated_bundle, load_portfolio_delegation_activity,
  resolve_dispatch_mode )` (`base.py:52-57`), and the types `EscalationResolvedSignal`,
  `GateApprovedSignal`, `GateMergeRetrySignal`, `GateRejectedSignal` etc. `ApplicationError` is now
  raised directly by `_apply_bundle_fallback` (`base.py:698`), not only caught.
- Top-of-module also imports `from collections.abc import Awaitable, Callable` (`base.py:38`) —
  used by the new `fallback_fn: Callable[[], Awaitable[Any]]` parameter shape.
- `_now_iso() -> str` (`base.py:101-103`): `return workflow.now().isoformat()`. Used everywhere a
  timestamp is stamped. Deterministic. NEVER use `datetime.now()`.
- Retry policies referenced by string key from `RETRY_POLICIES` (see `retry_policies.py`):
  - `"transient"` = `TRANSIENT_RETRY_POLICY` = foundry-temporal `HTTP_RETRY_POLICY` — initial 1s,
    backoff 2.0, max 15s, **3 attempts** (`retry_policies.py:33,110`).
  - `"agent_failure"` — initial 5s, backoff 2.0, max 60s, **3 attempts** (`retry_policies.py:38-41,111`).
  - `"git_merge"` = `GIT_MERGE_RETRY_POLICY` — initial 5s, backoff 2.0, max 30s, **3 attempts**,
    `non_retryable_error_types=["MergeConflict","MergeDivergenceUnresolved","MergeBranchProtectionRejected"]`
    (`retry_policies.py:94-103,115`).
  - (`"validation_failure"` max 1 attempt; `"timeout"` 2 attempts; `"infrastructure"` 10 attempts —
    not used directly by base.py but available to subclasses.)

---

## 1. CLASSVARS — subclass configuration surface (`base.py:120-129`)

These are the knobs subclasses set; the engine reads them. All are `ClassVar`.

| Classvar | Type | Default | Read by | Meaning |
|----------|------|---------|---------|---------|
| `ASSEMBLY_LINE` | `AssemblyLine` | *(no default — subclass MUST set)* (`base.py:121`) | `get_status` (`base.py:1331`) | enum for status queries |
| `ARTIFACT_ROOT` | `str` | `""` (`base.py:122`) | `_task_type_prefix`, `_commit_step_artifacts` paths, `_create_gate_pr` labels | path prefix e.g. `"data"`, `"deployment"` |
| `LINE_LABEL` | `str` | `""` (`base.py:123`) | `_set_step`, `_execution_ctx` (`base.py:346`) | human line name e.g. `"Data"` |
| `STATUS_PREFIX` | `str` | `""` (`base.py:124`) | `_set_step` (`base.py:371`) | status prefix → `{prefix}_in_progress` / `{prefix}_failed` |
| `STEPS` | `dict[str, dict[str, Any]]` | `{}` (`base.py:125`) | `_primary_skill_for_step`, `_commit_step_artifacts`, `_evidence_steps_iter`, `_build_evidence_data` | per-step `{skill_id\|skills, artifact, title?}` |
| `STEP_WEIGHTS` | `dict[str, float]` | `{}` (`base.py:126`) | *(subclass `run()` only — base.py never reads it)* | progress weights, sum 100 |
| `SINGLE_GATE_KEY` | `str \| None` | `None` (`base.py:129`) | `_rework_gate_key_for_step` default (`base.py:274`) | single-gate workflows set this so rework routes to it |

> ⚠️ **GOTCHA-CV1:** `STEP_WEIGHTS` is documented (`base.py:24`) and declared (`base.py:126`) but
> **never read inside base.py** — only subclass `run()` bodies consume it to compute the
> `progress` arg they pass to `_set_step`. A rebuild's base need not reference it.

---

## 2. STATE — every instance var in `__init__` (`base.py:131-186`)

`__init__` calls `super().__init__()` first (`base.py:132`; initializes the HIL vars from
`_HILSignalsMixin.md`), then sets the following. (Subclass `__init__` typically calls
`super().__init__()` then hydrates `_app_id`, `_portfolio_id`, `_wave_id`, `_risk_tier`, etc. from
its `LineWorkflowInput` — but those reads happen in subclass `run()`/`__init__`, not here.)

| Var | Type | Initial | Line | Mutated by → value | When |
|-----|------|---------|------|---------------------|------|
| `_app_id` | `str` | `""` | 134 | subclass sets from input | run start |
| `_portfolio_id` | `str` | `""` | 138 | subclass sets from input | run start; **gates `_execution_ctx`** (returns `None` if empty) |
| `_wave_id` | `str` | `""` | 139 | subclass sets from input | run start |
| `_status` | `WorkflowStatus` | `PENDING` | 140 | `_set_step` does NOT touch it; `_wait_for_gate_decision` sets `WAITING_FOR_SIGNAL`→`RUNNING`/`CANCELLED` (`base.py:1085,1095,1113`); subclass sets `RUNNING`/`COMPLETED`/`FAILED` | progress + gate waits |
| `_current_step` | `str` | `""` | 141 | `_set_step` → `step` (`base.py:363`) | each step |
| `_progress_pct` | `float` | `0.0` | 142 | `_set_step` → `progress` (`base.py:364`) | each step |
| `_pending_gate` | `GateType \| None` | `None` | 143 | `_wait_for_gate_decision` → `gate_type` then `None` (`base.py:1086,1112`) | gate wait window |
| `_started_at` | `str` | `""` | 144 | subclass sets at run start | run start |
| `_updated_at` | `str` | `""` | 145 | bumped to `_now_iso()` by gate signals, `_set_step`, `_wait_for_gate_decision` | many |
| `_gate_decisions` | `list[tuple[GateStatus,str,str]]` *(annotated 3-tuple — see GOTCHA-S1)* | `[]` | 149 | `gate_approved`/`gate_rejected` append **5-tuples** (`base.py:195,218`); subclasses may append **3-tuples** | gate signals |
| `_gate_decisions_consumed` | `int` | `0` | 150 | `_wait_for_gate_decision` → `consumed+1` (`base.py:1110`) | each consumed decision |
| `_rework_feedback` | `dict[str, dict]` | `{}` | 155 | `_dispatch_agent` reads it (`base.py:417`); `_wait_for_gate_decision`: `pop(gate_key)` on approve (`base.py:1118`), `[gate_key]=…` on reject (`base.py:1121`) | gate decision |
| `_rework_iterations` | `dict[str,int]` | `{}` | 159 | `_bump_rework` increments (`base.py:1350`) | subclass rework loop |
| `_step_results` | `dict[str, list[str]]` | `{}` | 162 | **never written in base.py** — subclasses write it; read by `_build_evidence_data` (`base.py:1282`) | subclass per-step |
| `_step_committed_paths` | `dict[str, list[str]]` | `{}` | 163 | `_commit_step_artifacts` → committed list (`base.py:845`) | each commit |
| `_agent_metadata` | `dict[str, dict]` | `{}` | 164 | `_dispatch_agent` writes per-step (`base.py:467-474`) | each dispatch |
| `_risk_tier` | `int \| None` | `None` | 168 | subclass sets from input | run start; forwarded by `_submit_gate_evidence` |
| `_merge_retry_signalled` | `bool` | `False` | 175 | `merge_retry` → `True` (`base.py:251`); `_reconcile_and_merge_with_retry_loop` → `False` before block (`base.py:1233`) | merge retry loop |
| `_profile_id` | `str` | `""` | 184 | `_load_delegation_config` → `str(profile_id or "")` (`base.py:498`); subclass may set from `LineWorkflowInput.portfolio_id` | run start; read by `_maybe_dispatch_bundle`/`_dispatch_bundle_and_wait` |
| `_portfolio_fallback_policy` | `str` | `"internal_fallback"` | 185 | `_load_delegation_config` → `config["fallback_policy"]` if a non-empty str (`base.py:516-518`) | run start; read by `_maybe_dispatch_bundle`/`_apply_bundle_fallback` |
| `_redispatch_guard` | `set[str]` | `set()` | 186 | `_apply_bundle_fallback` `.add(step_or_gate_id)` (`base.py:683`) | redispatch fallback |

> ⚠️ **GOTCHA-S1 (the 3-tuple annotation is a LIE — handlers append 5-tuples):** `_gate_decisions`
> is annotated `list[tuple[GateStatus, str, str]]` (3-tuple, `base.py:149`) but `gate_approved`
> appends `(APPROVED, approved_by, justification, None, [])` — a **5-tuple** (`base.py:195-202`) —
> and `gate_rejected` appends `(REJECTED, rejected_by, reason, reason_category, card_decisions)` —
> also **5-tuple** (`base.py:218-225`). The consumer `_wait_for_gate_decision` branches on
> `len(entry) == 5` vs else (`base.py:1104-1109`) precisely because **some other callers (older
> disposition/deployment terminal-resolution paths) append 3-tuples directly** to the list. A
> rebuild MUST: (a) make `gate_approved`/`gate_rejected` append 5-tuples, (b) make the consumer
> tolerate BOTH lengths, (c) NOT enforce the 3-tuple type annotation at runtime. The annotation is
> documentary only.

> ⚠️ **GOTCHA-S2 (`_step_results` is never written by base):** base reads `_step_results` in
> `_build_evidence_data` (`base.py:1282`) but never assigns it. Each subclass `run()` is
> responsible for `self._step_results[step_name] = result.output_artifacts` after a dispatch. A
> rebuild's base must declare it but leave population to subclasses, or evidence bundles come back
> with empty `"output"` fields.

> ⚠️ **CHANGED-AT-HEAD GOTCHA-S3 (`_profile_id` is set TWICE — beware the precedence):**
> `_load_delegation_config(profile_id)` UNCONDITIONALLY overwrites `self._profile_id` with
> `str(profile_id or "")` at its top (`base.py:498`) — even on the empty/early-return path. A
> subclass that set `_profile_id` itself in `run()` and then calls `_load_delegation_config(None)`
> will see `_profile_id` reset to `""`. A rebuild must reproduce the unconditional assignment
> (it's there so `resolve_dispatch_mode`/`dispatch_delegated_bundle` always see the canonical
> id). `_portfolio_fallback_policy` is only overwritten on the success path with a non-empty
> string (`base.py:516-518`), so a failed load keeps the safe `internal_fallback` default.

---

## 3. SIGNAL HANDLERS defined ON THE BASE — DO NOT redefine in subclasses

> ⚠️ **GOTCHA-SIG0 (re-decoration = duplicate registration crash):** `gate_approved`,
> `gate_rejected`, `escalation_resolved`, and `merge_retry` are decorated `@workflow.signal`
> **here on the base** (`base.py:192-252`, explicitly called out at `base.py:8-13` and
> `base.py:112-113`). **Subclasses MUST NOT redefine them** — Temporal raises on duplicate signal
> registration for the same name. The inherited HIL signals (`approve`, `cancel_workflow`, etc.)
> are likewise inherited, not redefined. A rebuild's subclasses add *new* signals only (e.g.
> `dispatch_architecture`, `pre_dispatch_confirmed`, `data_ready_for_target`); they never
> re-decorate these four. ⚠️ **CHANGED-AT-HEAD:** lines that adopt paired-work ALSO inherit
> `BundleAwareMixin` (`bundle_helpers.py:68`), which adds `bundle_completed` / `bundle_expired`
> `@workflow.signal` handlers and `get_bundle_outcome` / `get_bundle_outputs` queries — those live
> in the mixin, NOT here, but the base's `_maybe_dispatch_bundle` depends on them existing
> (see §8a / GOTCHA-PW1).

All four are **`async def`** signal handlers (unlike the HIL mixin's synchronous ones).

### 3.1 `gate_approved(self, signal: GateApprovedSignal) -> None` — `base.py:192-204`
Payload `GateApprovedSignal` (fields: `gate_id`, `approved_by`, `justification=""`,
`card_decisions=[]`, `reviewer_notes=None`).
```text
async def gate_approved(self, signal):
    self._gate_decisions.append((                       # base.py:195
        GateStatus.APPROVED,
        signal.approved_by,
        signal.justification,
        None,        # reason_category — approvals carry none   base.py:199
        [],          # card_decisions — reject-specific shape    base.py:200
    ))
    self._updated_at = _now_iso()                       # base.py:204
```
Buffers a 5-tuple onto `_gate_decisions`. Consumed by `_wait_for_gate_decision`'s `wait_condition`
predicate `len(self._gate_decisions) > consumed` (`base.py:1091`).
⚠️ **GOTCHA-SIG1:** approvals hard-code `reason_category=None` and `card_decisions=[]` even though
the *signal* may carry non-empty `card_decisions` / `reviewer_notes`. The base deliberately drops
approval-side card decisions — only rejection card decisions flow to rework. A rebuild must NOT
forward `signal.card_decisions` on the approve path.

### 3.2 `gate_rejected(self, signal: GateRejectedSignal) -> None` — `base.py:206-227`
Payload `GateRejectedSignal` (fields: `gate_id`, `rejected_by`, `reason`, `reason_category=None`,
`card_decisions=[]`, `reviewer_notes=None`).
```text
async def gate_rejected(self, signal):
    card_decisions = list(getattr(signal, "card_decisions", []) or [])   # base.py:216
    reason_category = getattr(signal, "reason_category", None)           # base.py:217
    self._gate_decisions.append((                                        # base.py:218
        GateStatus.REJECTED,
        signal.rejected_by,
        signal.reason,
        reason_category,
        card_decisions,
    ))
    self._updated_at = _now_iso()                                        # base.py:227
```
⚠️ **GOTCHA-SIG2 (defensive `getattr` for old senders):** `card_decisions` and `reason_category`
are read via `getattr(signal, ..., default)` because older signal senders may not populate them
(`base.py:216-217`). The `... or []` also normalizes a `None` `card_decisions` to `[]`. A rebuild
MUST keep this defensive read so a pre-W8 `GateRejectedSignal` doesn't raise `AttributeError` in
the handler. The full 5-tuple (with `reason_category` + `card_decisions`) is what
`_wait_for_gate_decision` later folds into `_rework_feedback[gate_key]` so the re-running agent
sees structured feedback, not just free text.

### 3.3 `escalation_resolved(self, signal: EscalationResolvedSignal) -> None` — `base.py:229-234`
Payload `EscalationResolvedSignal` (`escalation_id`, `resolved_by`, `resolution_type:
ResolutionType`, `resolution`).
```text
async def escalation_resolved(self, signal):
    self._updated_at = _now_iso()    # base.py:234
```
⚠️ **GOTCHA-SIG3 (no-op except timestamp):** the BASE handler ONLY bumps `_updated_at`. It does
**not** record the resolution anywhere. Workflows that actually act on escalation resolution
(notably Modernization's Ralph-Loop escape: `RE_EXTRACT` / `MANUAL_AUGMENT` / `RE_DISPOSITION` /
`ABANDON`) maintain their own escalation-state vars and their own `wait_condition` predicates in
the subclass — but they still rely on this base handler being the *only* `@workflow.signal` named
`escalation_resolved` (GOTCHA-SIG0). A subclass that needs the payload reads it by buffering in a
subclass-defined var; it must NOT redefine this method.

### 3.4 `merge_retry(self, signal: GateMergeRetrySignal) -> None` — `base.py:236-252`
Payload `GateMergeRetrySignal` (`gate_id`, `retried_by`, `note=None`). W17 / P5-S17.4.
```text
async def merge_retry(self, signal):
    self._merge_retry_signalled = True    # base.py:251
    self._updated_at = _now_iso()         # base.py:252
```
Fired by `POST /api/v1/gates/{id}/retry-merge`. Consumed by
`_reconcile_and_merge_with_retry_loop`'s `wait_condition(lambda: self._merge_retry_signalled or
self.cancelled)` (`base.py:1243-1245`). ⚠️ **GOTCHA-SIG4 (idempotent set):** if the flag is already
`True` when a second retry signal lands, this is a state no-op (still `True`) but still refreshes
`_updated_at` so the dashboard sees activity (`base.py:247-249` docstring). A rebuild keeps the
unconditional `= True` (no `if not` guard).

---

## 4. HOOKS — methods subclasses OVERRIDE (default behavior here)

These have working defaults; subclasses override when behavior diverges. They are plain methods
(no decorator).

### 4.1 `_task_type_prefix(self) -> str` — `base.py:258-264`
`return self.ARTIFACT_ROOT`. Override when `task_type` stub differs from artifact root. Used to
build `AgentTaskInput.task_type = f"{prefix}-{step_name}"` (`base.py:445`) and the output-ref
patch path (`base.py:856`).

### 4.2 `_rework_gate_key_for_step(self, step_name: str) -> str | None` — `base.py:266-274`
```text
return self.SINGLE_GATE_KEY    # base.py:274
```
Default returns the workflow's single gate key (or `None`). **Multi-gate** workflows
(Modernization with G-04a/b/c, Disposition with G-DE-1/2, Validation with G-V1/2/3, etc.)
**override** this with a `step → gate` map. Consumed by `_dispatch_agent` to decide which
`_rework_feedback` entry to forward (`base.py:415-419`).
⚠️ **GOTCHA-H1:** if a subclass forgets to override this on a multi-gate line, ALL steps get the
`SINGLE_GATE_KEY` (or `None`) rework feedback — meaning rework from gate B could be fed to a step
that belongs to gate A, or no feedback at all. Parity requires each multi-gate subclass to provide
the correct map.

### 4.3 `_primary_skill_for_step(self, step_name: str) -> str` — `base.py:276-282`
`return self.STEPS[step_name]["skill_id"]`. ⚠️ **GOTCHA-H2:** raises `KeyError` if the step has a
`"skills"` list instead of a `"skill_id"` scalar. **Validation overrides this** (its steps use a
`skills` list). A rebuild's Validation subclass MUST override or dispatch will `KeyError`.

### 4.4 `_evidence_step_metadata(self, step_name, step_def) -> dict` — `base.py:284-304`
```text
return {
    "title":    step_def.get("title", step_name),   # base.py:301  reviewer card label
    "skill_id": step_def.get("skill_id", ""),       # base.py:302
    "artifact": step_def.get("artifact", ""),       # base.py:303
}
```
Default `skill_id`-shaped per-step metadata for the evidence bundle. **Validation overrides** (uses
a `skills` list). `title` wins when present, else the gate service falls back to the step id
(`olympus-api/src/services/gate.py::_build_unit_artifacts`). Consumed by `_build_evidence_data` via
`**self._evidence_step_metadata(...)` (`base.py:1306`).

### 4.5 `_evidence_steps_iter(self)` — `base.py:306-313`
`return self.STEPS.items()`. Subclasses override to expose a filtered/extended view
(Rationalization excludes governance; Modernization fans out differently). Consumed by
`_build_evidence_data` (`base.py:1281`).

---

## 5. `_execution_ctx(...)` — Layer-B step-execution context (`base.py:323-355`)

Builds the `StepExecutionContext` threaded into every dispatch / git activity input so activities
emit `step_execution` rows for the timeline. **P5-S19.26 (Layer B).**

```text
def _execution_ctx(self, step_id, *, app_id=None, gate_id="", wave_id=None,
                   input_artifact_paths=None) -> StepExecutionContext | None:
    if not self._portfolio_id:                      # base.py:340
        return None                                 # base.py:341  ← best-effort no-op
    line_id = self.LINE_LABEL.lower().replace(" ", "-")   # base.py:346  canonical kebab id
    return StepExecutionContext(
        portfolio_id = self._portfolio_id,
        line_id      = line_id,
        step_id      = step_id,
        app_id       = self._app_id if app_id  is None else app_id,    # base.py:351
        wave_id      = self._wave_id if wave_id is None else wave_id,   # base.py:352
        gate_id      = gate_id,
        input_artifact_paths = list(input_artifact_paths or []),       # base.py:354
    )
```
- **One branch:** `if not self._portfolio_id: return None` (`base.py:340-341`).
- ⚠️ **GOTCHA-EC1 (None-vs-default arg semantics):** `app_id`/`wave_id` use `None` sentinel so a
  caller can pass an explicit different value for fan-out sub-steps (e.g. a step targeting a
  different app). `if x is None` (not falsy) — passing `app_id=""` would override to empty, not
  fall back. A rebuild MUST use `is None`, not truthiness.
- ⚠️ **GOTCHA-EC2 (`line_id` is lowercase-kebab of `LINE_LABEL`):** `"Disposition Execution"` →
  `"disposition-execution"`. The envelope writer accepts both forms but the canonical emitted form
  is kebab. A rebuild must lowercase + replace spaces with hyphens, not use `ARTIFACT_ROOT`.
- Returning `None` makes all downstream activities skip `step_execution` emission (best-effort).

---

## 6. `_set_step(self, step, progress)` — progress tracking (`base.py:362-373`)

```text
async def _set_step(self, step, progress):
    self._current_step = step           # base.py:363
    self._progress_pct  = progress      # base.py:364
    self._updated_at    = _now_iso()    # base.py:365
    if self._app_id:                                       # base.py:367  ← ONLY branch
        await self._update_app_status(
            self._app_id,
            f"{self.STATUS_PREFIX}_in_progress",           # base.py:370
            step,
            self.LINE_LABEL,
        )
```
- **One branch:** `if self._app_id:` (`base.py:367`). When `_app_id` is empty (wave-scoped
  callers), it updates local state but skips the DB write.
- Note it does NOT change `_status`; subclass `run()` owns `_status` transitions to `RUNNING`/
  `COMPLETED`/`FAILED`.

---

## 7. `_update_app_status(...)` — DB status push (`base.py:375-396`)

```text
async def _update_app_status(self, app_id, status, step, line):
    await workflow.execute_activity(
        update_application_status,
        UpdateAppStatusInput(app_id=app_id, status=status,
                             current_step=step, current_line=line),
        start_to_close_timeout=timedelta(seconds=30),       # base.py:394
        retry_policy=RETRY_POLICIES["transient"],           # base.py:395
    )
```
- Activity: `update_application_status`; timeout **30s**; retry **transient** (3 attempts).
- ⚠️ **GOTCHA-US1 (why transient, not validation_failure):** the comment (`base.py:380-385`) records
  a real phase-2 incident: a single CPDSS status-update 30s timeout under the old
  `validation_failure` policy (`max_attempts=1`) **failed the whole workflow** because it refused to
  retry. The fix was to use `transient` so a stray DB-write timeout retries instead of killing the
  run. A rebuild MUST use `transient` here, never a no-retry policy.

---

## 8. `_dispatch_agent(...)` — agent task dispatch (`base.py:398-475`)

The core "run a skill for this step" helper. Returns `AgentTaskResult` and records per-step
metadata. **Branch-heavy.**

```text
async def _dispatch_agent(self, app_id, step_name, input_artifacts,
                          workspace_key="", artifact_repo="", artifact_ref="") -> AgentTaskResult:
    skill_id = self._primary_skill_for_step(step_name)        # base.py:413
    context = {}
    gate_for_step = self._rework_gate_key_for_step(step_name) # base.py:415
    if gate_for_step is not None:                             # base.py:416  BRANCH 1
        fb = self._rework_feedback.get(gate_for_step)         # base.py:417
        if fb is not None:                                    # base.py:418  BRANCH 2
            context["rework_feedback"] = fb                   # base.py:419

    if workflow.patched("context-priors-v1"):                # base.py:427  BRANCH 3 (patch gate)
        try:
            priors_result = await workflow.execute_activity(
                load_context_priors,
                LoadContextPriorsInput(skill_id=skill_id),
                start_to_close_timeout=timedelta(seconds=10), # base.py:432
                retry_policy=RETRY_POLICIES["transient"],     # base.py:433
            )
            priors = getattr(priors_result, "priors", None) or []   # base.py:435
            if priors:                                              # base.py:436  BRANCH 4
                context["context_priors"] = priors                  # base.py:437
        except Exception as exc:                                    # base.py:438  BRANCH 5 (best-effort)
            workflow.logger.warning("context_priors load failed (continuing): %s",
                                    exc, extra={"skill_id": skill_id, "step": step_name})

    task_input = AgentTaskInput(
        task_type = f"{self._task_type_prefix()}-{step_name}",      # base.py:445
        app_id    = app_id,
        skill_id  = skill_id,
        input_artifacts = input_artifacts,
        artifact_repo   = artifact_repo,
        artifact_ref    = artifact_ref,
        workspace_key   = workspace_key,
        context = context,
        execution_context = self._execution_ctx(step_name, app_id=app_id,
                                                input_artifact_paths=input_artifacts),  # base.py:453
    )
    result = await workflow.execute_activity(
        dispatch_agent_task, task_input,
        start_to_close_timeout=timedelta(hours=1),             # base.py:462
        retry_policy=RETRY_POLICIES["agent_failure"],          # base.py:463  3 attempts
        activity_id=f"agent-{step_name}",                      # base.py:464
    )
    self._agent_metadata[step_name] = {                        # base.py:467-474
        "model_used":        result.model_used,
        "duration_ms":       result.duration_ms,
        "token_usage_input": result.token_usage_input,
        "token_usage_output":result.token_usage_output,
        "cost_estimate_usd": result.cost_estimate_usd,
        "output_files":      result.output_files,
    }
    return result
```

**Branch inventory (5):**
1. `if gate_for_step is not None:` (`base.py:416`) — only look up rework feedback if a gate maps to
   this step.
2. `if fb is not None:` (`base.py:418`) — only attach `context["rework_feedback"]` if feedback
   exists for that gate (i.e. there was a prior rejection not yet cleared by approval).
3. `if workflow.patched("context-priors-v1"):` (`base.py:427`) — **patch-gated** so pre-patch
   in-flight runs replay WITHOUT the `load_context_priors` activity (history determinism).
4. `if priors:` (`base.py:436`) — only attach non-empty priors.
5. `except Exception` (`base.py:438`) — context-priors load is **best-effort**; failure logs and
   continues. Never blocks dispatch.

**Activity calls (in order):**
- `load_context_priors` — `LoadContextPriorsInput(skill_id)`; **10s**; `transient`; ONLY under
  patch `context-priors-v1`, wrapped in try/except (best-effort).
- `dispatch_agent_task` — `task_input`; **1 hour** start_to_close; `agent_failure` (3 attempts);
  `activity_id="agent-{step_name}"`.

> ⚠️ **GOTCHA-DA1 (patch ID is load-bearing & verbatim):** `workflow.patched("context-priors-v1")`
> (`base.py:427`). A rebuild MUST use this EXACT string. Changing it (or removing the patch gate)
> changes replay history for any in-flight pre-patch run and triggers nondeterminism errors.
> ⚠️ **GOTCHA-DA2 (`activity_id` stability):** `activity_id=f"agent-{step_name}"` makes the dispatch
> idempotent per step on replay. A rebuild must keep deterministic activity ids.
> ⚠️ **GOTCHA-DA3 (1-hour dispatch timeout, no retry-on-validation):** agent dispatch uses
> `agent_failure` (malformed-output / model-error → 3 retries with 5-60s backoff). Validation
> failures are NOT retried here — they surface as a result the subclass inspects. A rebuild must
> use `agent_failure`, not `transient`, for the agent dispatch.
> ⚠️ **CHANGED-AT-HEAD note (multi-provider dispatch):** the dispatch activity now resolves a
> provider internally (multi-provider agent dispatch landed at HEAD), but from the workflow's
> perspective the call shape, timeout, retry policy, and `_agent_metadata` projection are
> UNCHANGED — `_dispatch_agent` still records the 6 fields `model_used` / `duration_ms` /
> `token_usage_input` / `token_usage_output` / `cost_estimate_usd` / `output_files`. A rebuild
> reproduces this helper verbatim; provider selection is an activity-internal concern, not a
> workflow branch.

---

## 8a. PAIRED-WORK / DELEGATED-BUNDLE DISPATCH — ⚠️ NEW AT HEAD (`base.py:477-723`)

> **CHANGED-AT-HEAD — Phase 6 W1, design §3 / §7.2.D / §8.2.** This entire block is new since the
> prior baseline. It is the single generalization point that lets a line wrap any delegatable
> step/gate with ONE call (`_maybe_dispatch_bundle`) and get the full delegate-vs-internal
> decision, the bundle dispatch + signal-await, and the fallback-policy application "for free".
> **Lines that don't delegate never call `_maybe_dispatch_bundle` and are unaffected.** This block
> adds the bulk of the new branch points (≈12).

### 8a.1 `_load_delegation_config(self, profile_id: str | None) -> None` — `base.py:487-518`
Loads + caches the portfolio's delegation config at run start. File I/O lives in the activity, not
the workflow.

```text
async def _load_delegation_config(self, profile_id):
    self._profile_id = str(profile_id or "")          # base.py:498  ← UNCONDITIONAL overwrite
    if not self._profile_id:                          # base.py:499  BRANCH 1
        return                                        # base.py:500  ← no profile → keep defaults
    try:
        config = await workflow.execute_activity(
            load_portfolio_delegation_activity,
            args=[self._profile_id],
            start_to_close_timeout=timedelta(seconds=15),   # base.py:505
            retry_policy=RETRY_POLICIES["transient"],       # base.py:506
        )
    except Exception as exc:                          # base.py:508  BRANCH 2 (best-effort)
        workflow.logger.warning("delegation config load failed (defaulting to "
                                "internal_fallback): %s", exc, extra={...})
        return                                        # base.py:515  ← keep internal_fallback
    policy = (config or {}).get("fallback_policy")    # base.py:516
    if isinstance(policy, str) and policy:            # base.py:517  BRANCH 3
        self._portfolio_fallback_policy = policy      # base.py:518
```
- **Branches (3):** empty-profile early return (499); load `except` → keep default (508);
  `isinstance(policy, str) and policy` guard before adopting (517).
- Activity: `load_portfolio_delegation_activity` — positional `args=[profile_id]`; **15s**;
  `transient`. Reads `profiles/<profile_id>/delegation.yaml`.
- ⚠️ **GOTCHA-PW0 (best-effort + safe default):** ANY failure (or no profile) leaves
  `_portfolio_fallback_policy == "internal_fallback"`, so the line runs every step internally. See
  GOTCHA-S3 for the unconditional `_profile_id` write.

### 8a.2 `_maybe_dispatch_bundle(...)` — the generalization point — `base.py:520-602` ★ CORE-NEW
Signature (all keyword-only after `self`):
`step_or_gate_id`, `scope_kind`, `app_id`, `wave_id`, `fallback_fn: Callable[[], Awaitable[Any]]`,
`is_delegatable=True`, `expires_hours=168`.

```text
async def _maybe_dispatch_bundle(self, *, step_or_gate_id, scope_kind, app_id, wave_id,
                                 fallback_fn, is_delegatable=True, expires_hours=168):
    if not hasattr(self, "await_bundle_completion"):     # base.py:564  BRANCH 1 ★
        return await fallback_fn()                       # base.py:565  ← line lacks the mixin → internal
    mode = await workflow.execute_activity(
        resolve_dispatch_mode,
        args=[scope_kind, step_or_gate_id, app_id, wave_id,
              self._profile_id or None, is_delegatable],     # base.py:568-575
        start_to_close_timeout=timedelta(seconds=30),    # base.py:577
        retry_policy=RETRY_POLICIES["transient"],        # base.py:578
    )
    if mode != DISPATCH_MODE_DELEGATED_BUNDLE:           # base.py:580  BRANCH 2
        return await fallback_fn()                       # base.py:581  ← not delegated → internal
    outcome = await self._dispatch_bundle_and_wait(      # base.py:583
        step_or_gate_id=…, scope_kind=…, app_id=…, wave_id=…, expires_hours=…)
    if outcome["outcome"] == "accepted":                 # base.py:590  BRANCH 3
        return outcome["outputs"]                        # base.py:591  ← accepted → bundle outputs
    return await self._apply_bundle_fallback(            # base.py:593  ← non-accepted → policy
        step_or_gate_id=…, scope_kind=…, app_id=…, wave_id=…, fallback_fn=fallback_fn,
        expires_hours=…, outcome=outcome["outcome"], bundle_id=outcome["bundle_id"])
```
- **Branches (3):** `not hasattr(self, "await_bundle_completion")` (564); `mode !=
  DISPATCH_MODE_DELEGATED_BUNDLE` (580); `outcome["outcome"] == "accepted"` (590).
- Activity: `resolve_dispatch_mode` — positional `args=[scope_kind, step_or_gate_id, app_id,
  wave_id, profile_id_or_None, is_delegatable]`; **30s**; `transient`. Returns the string
  `"delegated_bundle"` or `"internal_agent"` (`bundle_activities.py:464,468-525`). Layer (b)
  eligibility gate → never delegate a non-delegatable step; Layer (a) → an open bundle for the
  exact scope wins; Layer (c) → portfolio `delegation.yaml` `default_delegation: enabled` or
  `delegated_steps` membership.
- ⚠️ **GOTCHA-PW1 (mixin gate is the safe default):** a line that has NOT inherited
  `BundleAwareMixin` (so `await_bundle_completion` is absent) can't honour bundle signals, so the
  helper NEVER delegates for it — it just runs `fallback_fn()` (`base.py:564-565`). A rebuild MUST
  keep the `hasattr` guard FIRST, before any activity call, or a non-bundle-aware line would
  dispatch a bundle it can never await.
- ⚠️ **GOTCHA-PW2 (`scope_kind` ∈ {`'line_step'`, `'gate_packet'`}; exactly one of app/wave set):**
  `step_or_gate_id` is the step_id or gate_id; exactly one of `app_id` / `wave_id` is non-None.
  `expires_hours` (default 168 = 7 days) is the bundle TTL. A rebuild threads these verbatim.
- ⚠️ **GOTCHA-PW3 (the gate gets the SAME artifact schema either way):** on the accepted path the
  caller receives the bundle's `artifact_kind → ref` outputs map; on every internal path it
  receives `fallback_fn()`'s result. Callers treat both identically — the downstream gate consumes
  the same shape regardless of producer. A rebuild must return the bundle outputs on accept and the
  fallback result otherwise, not two different shapes.

### 8a.3 `_dispatch_bundle_and_wait(...)` — `base.py:604-648`
Dispatches one bundle and blocks until terminal. Returns `{"bundle_id", "outcome", "outputs"}`.

```text
async def _dispatch_bundle_and_wait(self, *, step_or_gate_id, scope_kind, app_id, wave_id,
                                    expires_hours):
    bundle_id = await workflow.execute_activity(
        dispatch_delegated_bundle,
        args=[scope_kind, step_or_gate_id, app_id, wave_id, expires_hours,
              self._portfolio_fallback_policy, self._workflow_created_by()],  # base.py:623-631
        start_to_close_timeout=timedelta(seconds=30),    # base.py:632
        retry_policy=RETRY_POLICIES["transient"],        # base.py:633
    )
    outcome = await self.await_bundle_completion(        # base.py:635  (BundleAwareMixin)
        bundle_id, timeout_seconds=expires_hours * 3600 + 3600)   # base.py:637 ★ TTL + 1h margin
    outputs = {}
    if outcome == "accepted":                            # base.py:640  BRANCH
        outputs = dict(getattr(self, "_bundle_outputs", {}).get(bundle_id, {}))   # base.py:641-643
    return {"bundle_id": bundle_id, "outcome": outcome, "outputs": outputs}       # base.py:644-648
```
- **Branch (1):** `if outcome == "accepted":` (640) — only then read `_bundle_outputs[bundle_id]`.
- Activity: `dispatch_delegated_bundle` — positional `args=[scope_kind, step_or_gate_id, app_id,
  wave_id, expires_hours, fallback_policy, created_by]`; **30s**; `transient`. Returns the bundle
  id string.
- `await_bundle_completion(bundle_id, timeout_seconds=expires_hours*3600 + 3600)` is provided by
  `BundleAwareMixin` (`bundle_helpers.py:140-176`): blocks on
  `wait_condition(lambda: bundle_id in self._bundle_outcomes, timeout=…)`; returns one of
  `"accepted"`/`"rejected"`/`"expired"`/`"released"` from the signal handlers or `"timeout"` if the
  timer fires.
- ⚠️ **GOTCHA-PW4 (the +3600s safety margin is deliberate):** the workflow-internal await timeout
  is `expires_hours*3600 + 3600` (`base.py:637`) — bundle TTL PLUS one hour — so the bundle-reaper's
  `BundleExpiredSignal` always lands BEFORE this local timer fires. A rebuild MUST keep the
  margin; shortening it to exactly the TTL would race the reaper and surface a `"timeout"` instead
  of the reaper's `"expired"`, mis-routing the fallback policy.
- ⚠️ **GOTCHA-PW5 (`_bundle_outputs` read via `getattr` default):** the outputs map is read with
  `getattr(self, "_bundle_outputs", {})` (`base.py:641-642`) so a partially-initialized mixin
  doesn't `AttributeError`. Keep the defensive read.

### 8a.4 `_apply_bundle_fallback(...)` — per-portfolio fallback policy — `base.py:650-707`
Applies the §7.2.D fallback after a non-accepted bundle. All keyword-only:
`step_or_gate_id`, `scope_kind`, `app_id`, `wave_id`, `fallback_fn`, `expires_hours`, `outcome`,
`bundle_id`.

```text
async def _apply_bundle_fallback(self, *, step_or_gate_id, scope_kind, app_id, wave_id,
                                 fallback_fn, expires_hours, outcome, bundle_id):
    policy = self._portfolio_fallback_policy           # base.py:671
    workflow.logger.warning("delegated-bundle.fallback.triggered", extra={...})  # base.py:672-680

    if policy == "redispatch" and step_or_gate_id not in self._redispatch_guard:   # base.py:682  BRANCH 1 ★
        self._redispatch_guard.add(step_or_gate_id)    # base.py:683  ← guard against loop
        retry = await self._dispatch_bundle_and_wait(  # base.py:684
            step_or_gate_id=…, scope_kind=…, app_id=…, wave_id=…, expires_hours=…)
        if retry["outcome"] == "accepted":             # base.py:691  BRANCH 2
            return retry["outputs"]                     # base.py:692
        return await fallback_fn()                      # base.py:695  ← redispatch failed → internal

    if policy in ("escalate", "fail"):                 # base.py:697  BRANCH 3
        raise ApplicationError(                         # base.py:698
            f"Delegated bundle for {scope_kind}:{step_or_gate_id} reached terminal outcome "
            f"{outcome!r}; fallback_policy={policy!r} stops the line.",
            type="DELEGATED_BUNDLE_FALLBACK",
            non_retryable=True,                         # base.py:703
        )

    return await fallback_fn()                          # base.py:707  ← internal_fallback (default)
```
- **Branches (3):** `policy == "redispatch" and step_or_gate_id not in self._redispatch_guard`
  (682); inner `retry["outcome"] == "accepted"` (691); `policy in ("escalate", "fail")` (697).
  Default fall-through is `internal_fallback` → `fallback_fn()` (707).
- ⚠️ **GOTCHA-PW6 (redispatch is bounded to ONE extra cycle per scope):** `_redispatch_guard` is a
  per-scope `set`; once `step_or_gate_id` is added (683) a second non-accepted bundle for the SAME
  scope skips the `redispatch` branch (the `and step_or_gate_id not in self._redispatch_guard`
  short-circuits) and falls through to the `escalate/fail`-or-`internal_fallback` tail. So
  `redispatch` issues at most ONE fresh bundle, then degrades to internal. A rebuild MUST keep the
  guard or `redispatch` loops forever.
- ⚠️ **GOTCHA-PW7 (`escalate`/`fail` raise a NON-RETRYABLE `ApplicationError`):** `type=
  "DELEGATED_BUNDLE_FALLBACK"`, `non_retryable=True` (`base.py:698-704`) — the line stalls VISIBLY at
  the operator's attention instead of silently downgrading. Lines wanting a softer behaviour
  override `_apply_bundle_fallback`. A rebuild must raise (not swallow) on these two policies and
  mark it non-retryable so Temporal doesn't retry the workflow task.
- ⚠️ **GOTCHA-PW8 (redispatch reuses `_dispatch_bundle_and_wait`, NOT `_maybe_dispatch_bundle`):**
  the retry path calls `_dispatch_bundle_and_wait` directly (`base.py:684`), skipping the
  `resolve_dispatch_mode` re-check — once we've decided to redispatch, we just issue another
  bundle. A rebuild must call the lower helper, not re-run the trigger evaluation.

### 8a.5 `_workflow_created_by(self) -> str` — `base.py:709-723`
```text
def _workflow_created_by(self):
    input_obj = getattr(self, "_input", None)      # base.py:718
    if input_obj is not None:                       # base.py:719  BRANCH 1
        created_by = getattr(input_obj, "created_by", "")   # base.py:720
        if created_by:                              # base.py:721  BRANCH 2
            return str(created_by)                  # base.py:722
    return "olympus-line-workflow"                  # base.py:723  ← stable service-account marker
```
- **Branches (2):** `input_obj is not None` (719); `if created_by:` (721).
- Best-effort identity for the `created_by` column of line-dispatched bundles. Prefers
  `self._input.created_by` when the subclass stored `_input`; else a stable
  `"olympus-line-workflow"` marker so the row is never NULL. The concrete identity isn't
  load-bearing (the pair claims the bundle later). A rebuild keeps the double `getattr` + the
  non-NULL fallback.

---

## 9. `_commit_step_artifacts(...)` — write step artifacts to Git (`base.py:725-864`)

Writes the per-step summary JSON + all agent output files to the branch in **one batched commit**,
optionally **mirrors** files to a target repo, then patch-gated patches the output-ref.

```text
async def _commit_step_artifacts(self, repo, branch, app_id, step_name, result,
                                 artifact_path, mirror_repo="", mirror_path_prefix=""):
    metadata = self._agent_metadata.get(step_name, {})              # base.py:750
    output_files = metadata.get("output_files", [])                 # base.py:751
    file_paths = [f.path for f in output_files] if output_files else []   # base.py:752  BRANCH

    step_def = self.STEPS[step_name]                                # base.py:756
    summary = {                                                     # base.py:757-769
        "step": step_name,
        "artifacts": result.output_artifacts,
        "file_artifacts": file_paths,
        "model_used": metadata.get("model_used",""),
        "duration_ms": metadata.get("duration_ms",0),
        "token_usage": {"input": metadata.get("token_usage_input",0),
                        "output": metadata.get("token_usage_output",0)},
        "cost_estimate_usd": metadata.get("cost_estimate_usd",0.0),
        "timestamp": workflow.now().isoformat(),                    # base.py:768  deterministic
    }
    if "skill_id" in step_def: summary["skill_id"] = step_def["skill_id"]   # base.py:770-771 BRANCH
    if "skills"   in step_def: summary["skills"]   = step_def["skills"]     # base.py:772-773 BRANCH
    summary_content = json.dumps(summary, indent=2)                 # base.py:774

    primary_batch = [(artifact_path, summary_content)]              # base.py:781
    committed = [artifact_path]                                     # base.py:782
    for file_artifact in output_files:                             # base.py:783  LOOP
        file_path = f"{self.ARTIFACT_ROOT}/{app_id}/files/{step_name}/{file_artifact.path}"  # base.py:784-787
        primary_batch.append((file_path, file_artifact.content))
        committed.append(file_path)

    commit_ctx = self._execution_ctx(f"commit-{step_name}", app_id=app_id)   # base.py:791
    await workflow.execute_activity(
        write_artifacts_batch,
        WriteArtifactsBatchInput(repo=repo, branch=branch, files=primary_batch,
            commit_message=f"{self.ARTIFACT_ROOT}({app_id}): {step_name} artifacts",   # base.py:801
            execution_context=commit_ctx),
        start_to_close_timeout=timedelta(seconds=120),              # base.py:806
        retry_policy=RETRY_POLICIES["transient"],                   # base.py:807
        activity_id=f"commit-{step_name}",                          # base.py:808
    )

    if mirror_repo and output_files:                                # base.py:816  BRANCH (mirror)
        prefix = mirror_path_prefix.rstrip("/") or f"docs/{self.ARTIFACT_ROOT}/{step_name}"  # base.py:817-819
        mirror_files = [(f"{prefix}/{f.path}", f.content) for f in output_files]   # base.py:820-822
        try:
            await workflow.execute_activity(
                write_artifacts_batch,
                WriteArtifactsBatchInput(repo=mirror_repo, branch="main", files=mirror_files,
                    commit_message=f"{self.ARTIFACT_ROOT}({app_id}): {step_name} design artifacts",
                    execution_context=commit_ctx),
                start_to_close_timeout=timedelta(seconds=120),
                retry_policy=RETRY_POLICIES["transient"],
            )
        except Exception as exc:                                    # base.py:839  BRANCH (best-effort)
            workflow.logger.warning("mirror batch write to target repo failed (non-fatal): %s", exc)

    self._step_committed_paths[step_name] = committed               # base.py:845

    if workflow.patched("patch-output-artifact-ref-v1"):            # base.py:850  BRANCH (patch gate)
        try:
            await workflow.execute_activity(
                update_agent_task_output_ref,
                args=[app_id, f"{self._task_type_prefix()}-{step_name}", artifact_path],  # base.py:854-858
                start_to_close_timeout=timedelta(seconds=30),
                retry_policy=RETRY_POLICIES["transient"],
                activity_id=f"patch-output-ref-{step_name}",        # base.py:861
            )
        except Exception:                                           # base.py:863  BRANCH (best-effort)
            pass                                                    # base.py:864  observability-only
```

**Branch inventory (7):** `file_paths = [...] if output_files else []` (752); `if "skill_id" in
step_def` (770); `if "skills" in step_def` (772); the `for file_artifact in output_files` loop
(783); `if mirror_repo and output_files` (816); the mirror `try/except` (839); `if
workflow.patched("patch-output-artifact-ref-v1")` (850) and its inner `try/except…pass` (863).

**Activity calls (in order):**
1. `write_artifacts_batch` (primary) — `repo`/`branch`/`primary_batch`; **120s**; `transient`;
   `activity_id="commit-{step_name}"`.
2. `write_artifacts_batch` (mirror) — `mirror_repo`/`branch="main"`/`mirror_files`; **120s**;
   `transient`; **no activity_id**; wrapped in try/except — **best-effort, never fatal**. Only when
   `mirror_repo and output_files`.
3. `update_agent_task_output_ref` — positional `args=[app_id, "{prefix}-{step_name}",
   artifact_path]`; **30s**; `transient`; `activity_id="patch-output-ref-{step_name}"`; only under
   patch `patch-output-artifact-ref-v1`; try/except…pass (observability-only).

> ⚠️ **GOTCHA-CSA1 (batched single commit, not per-file):** the whole step (summary JSON + every
> output file) lands in ONE `write_artifacts_batch` commit (`base.py:776-809`). The comment notes
> the old per-file loop cost ~1-2s/file and made noisy history. A rebuild MUST batch — do not emit
> N commits per step (would change git history, commit shas, and timing).
> ⚠️ **GOTCHA-CSA2 (summary `skill_id` XOR `skills`):** both `if` checks (770, 772) run; a step def
> has exactly one of the keys in practice. Validation steps carry `skills`; all others carry
> `skill_id`. A rebuild keeps both conditional inserts.
> ⚠️ **GOTCHA-CSA3 (file paths are `ARTIFACT_ROOT/{app_id}/files/{step}/{path}`):** primary file
> commit paths (`base.py:784-787`) differ from mirror paths (`{prefix}/{f.path}`, default
> `docs/{ARTIFACT_ROOT}/{step}`). A rebuild must reproduce both path templates exactly.
> ⚠️ **GOTCHA-CSA4 (mirror is best-effort; patch is patch-gated + best-effort):** the authoritative
> artifact is the primary commit. Mirror failure and output-ref patch failure are both swallowed
> (`base.py:839`, `base.py:863-864`). The output-ref patch is ALSO behind
> `workflow.patched("patch-output-artifact-ref-v1")` — verbatim string, load-bearing for replay.
> ⚠️ **GOTCHA-CSA5 (positional `args=` on output-ref activity):** unlike every other call which
> passes a single dataclass, `update_agent_task_output_ref` is invoked with positional
> `args=[app_id, task_type, artifact_path]` (`base.py:854-858`). A rebuild must match this exact
> positional shape, not wrap it in a dataclass.

---

## 10. `_create_gate_pr(...)` — open gate-review PR (`base.py:866-893`)

```text
async def _create_gate_pr(self, repo, branch, app_id, gate_type, title, body):
    pr_input = CreatePRInput(
        repo=repo, source_branch=branch, target_branch="main",        # base.py:877-879
        title=title, body=body,
        labels=["gate-review", self.ARTIFACT_ROOT, gate_type],        # base.py:882
        execution_context=self._execution_ctx(
            f"create-{gate_type.lower()}-pr", app_id=app_id),          # base.py:883-886
    )
    return await workflow.execute_activity(
        create_pr, pr_input,
        start_to_close_timeout=timedelta(seconds=60),                 # base.py:891
        retry_policy=RETRY_POLICIES["transient"],                     # base.py:892
    )
```
- Always targets `main`. Labels = `["gate-review", ARTIFACT_ROOT, gate_type]`.
- Activity `create_pr`; **60s**; `transient`. Returns `CreatePRResult` (`pr_number`, `pr_url`, …).
- ⚠️ **GOTCHA-GP1:** `gate_type` here is a **string** (used in labels and
  `f"create-{gate_type.lower()}-pr"`), while `_submit_gate_evidence` takes a `GateType` enum.
  Callers pass the string form here. A rebuild must accept the string and `.lower()` it for the
  execution-context step id.

---

## 11. `_submit_gate_evidence(...)` — check criteria + submit evidence (`base.py:895-994`)

Builds a **slim** evidence bundle (no inline file content) for persistence, **enriches** only the
threshold-target artifacts with content for `check_gate_criteria`, then submits. **Branch-heavy.**

```text
async def _submit_gate_evidence(self, gate_id, gate_type, app_id, artifact_paths, pr_url,
                                assembly_line, step, *, forward_risk_tier=True):
    slim_evidence = self._build_evidence_data(app_id, assembly_line, step)   # base.py:927 (slim)

    gate_type_str = gate_type.value if isinstance(gate_type, GateType) else str(gate_type)  # base.py:936 BRANCH
    threshold_suffixes = { th["artifact"] for th in GATE_THRESHOLDS.get(gate_type_str, []) }  # base.py:938-941

    if threshold_suffixes:                                            # base.py:942  BRANCH
        needed_paths = set()
        for step_def in slim_evidence.get("steps", {}).values():     # base.py:946  LOOP
            for art in step_def.get("file_artifacts") or []:         # base.py:947  LOOP
                path = art.get("path") or ""
                if any(path.endswith(s) for s in threshold_suffixes):  # base.py:949  BRANCH
                    needed_paths.add(path)
        criteria_evidence = self._build_evidence_data(app_id, assembly_line, step,
                                                      content_paths=needed_paths)   # base.py:951-954
    else:
        criteria_evidence = slim_evidence                            # base.py:956

    if forward_risk_tier:                                            # base.py:958  BRANCH
        check_input = CheckGateCriteriaInput(gate_id=gate_id, gate_type=gate_type, app_id=app_id,
            evidence_paths=artifact_paths, evidence_data=criteria_evidence,
            risk_tier=self._risk_tier)                               # base.py:959-966
    else:
        check_input = CheckGateCriteriaInput(gate_id=gate_id, gate_type=gate_type, app_id=app_id,
            evidence_paths=artifact_paths)                           # base.py:968-973

    await workflow.execute_activity(check_gate_criteria, check_input,
        start_to_close_timeout=timedelta(seconds=60), retry_policy=RETRY_POLICIES["transient"])   # base.py:974-979

    evidence_input = SubmitGateEvidenceInput(gate_id=gate_id, gate_type=gate_type, app_id=app_id,
        artifact_paths=artifact_paths, pr_url=pr_url, evidence_data=slim_evidence)   # base.py:981-988
    await workflow.execute_activity(submit_gate_evidence, evidence_input,
        start_to_close_timeout=timedelta(seconds=60), retry_policy=RETRY_POLICIES["transient"])   # base.py:989-994
```

**Branch inventory (6):** `gate_type.value if isinstance(...) else str(...)` (936); `if
threshold_suffixes:` (942); the `for step_def …` + `for art …` loops (946-947); `if
any(path.endswith(s) …)` (949); `if forward_risk_tier:` (958).

**Activity calls (in order):**
1. `check_gate_criteria` — `check_input` (shape depends on `forward_risk_tier`); **60s**;
   `transient`.
2. `submit_gate_evidence` — `evidence_input` (always the **slim** bundle); **60s**; `transient`.

> ⚠️ **GOTCHA-SE1 (slim vs enriched bundle — two separate `_build_evidence_data` calls):** the
> bundle SUBMITTED (`submit_gate_evidence`) is always slim (no inline content) (`base.py:987`). The
> bundle used for `check_gate_criteria` is slim too UNLESS the gate has `GATE_THRESHOLDS`, in which
> case it's rebuilt with `content_paths=needed_paths` to inline ONLY the threshold-target file
> contents (`base.py:951-954`). This keeps activity-input size O(threshold-artifact-count), not
> O(total), avoiding Temporal's `limit.blobSize`. A rebuild MUST make these two distinct calls with
> the documented content scoping.
> ⚠️ **GOTCHA-SE2 (`forward_risk_tier=False` omits `evidence_data` AND `risk_tier`):** when
> `forward_risk_tier=False` (legacy Data / pre-F3 workflows), the `check_gate_criteria` input is
> built WITHOUT `evidence_data` and WITHOUT `risk_tier` (`base.py:968-973`) — bare 4-field shape —
> to preserve exact call-shape parity for those callers. A rebuild must keep both input shapes.
> ⚠️ **GOTCHA-SE3 (suffix→full-path widening):** thresholds declare artifact **suffixes**; the
> bundle stores **full paths**. The widening loop (`base.py:945-950`) resolves which full paths end
> with any threshold suffix. A rebuild must do suffix matching (`path.endswith(s)`), not exact-path
> matching.
> ⚠️ **GOTCHA-SE4 (`GATE_THRESHOLDS` lookup key is the gate STRING value):** the lookup uses
> `gate_type_str` (`.value` if enum else `str()`), e.g. `"G-V1"` (`base.py:936-941`). A rebuild must
> key by the gate's stable string code.

---

## 12. `_run_gate_pre_review(...)` — advisory AI pre-review (`base.py:996-1073`)

Best-effort AI pre-review for a gate; failures logged but **never fatal**; then a patch-gated
"ready for review" flip in `finally`.

```text
async def _run_gate_pre_review(self, gate_id, gate_type_value, evidence_paths, *,
                               artifact_repo="", artifact_ref=""):
    try:
        pre_review_result = await workflow.execute_activity(
            dispatch_agent_task,
            AgentTaskInput(skill_id="gate-pre-review", app_id=self._app_id,
                task_type="gate-pre-review", input_artifacts=evidence_paths,
                artifact_repo=artifact_repo, artifact_ref=artifact_ref,
                context={"gate_id": gate_id, "gate_type": gate_type_value},
                execution_context=self._execution_ctx(
                    f"ai-pre-review-{gate_type_value.lower()}", gate_id=gate_id,
                    input_artifact_paths=evidence_paths)),
            start_to_close_timeout=timedelta(minutes=10),            # base.py:1041
            retry_policy=RETRY_POLICIES["transient"])                # base.py:1042
        agent_markdown = (pre_review_result.output_artifacts[0]
                          if pre_review_result.output_artifacts else "")   # base.py:1044-1048  BRANCH
        if not agent_markdown:                                       # base.py:1049  BRANCH
            raise ValueError("Gate pre-review produced no output")   # base.py:1050
        await workflow.execute_activity(store_gate_pre_review,
            StoreGatePreReviewInput(gate_id=gate_id, agent_output=agent_markdown),
            start_to_close_timeout=timedelta(seconds=30), retry_policy=RETRY_POLICIES["transient"])  # base.py:1051-1059
    except Exception:                                                # base.py:1060  BRANCH (best-effort)
        workflow.logger.warning(
            f"Gate pre-review failed for {gate_type_value}; continuing without AI recommendation",
            extra={"gate_id": gate_id})
    finally:                                                         # base.py:1066
        if workflow.patched("mark-gate-ready-for-review-v1"):        # base.py:1067  BRANCH (patch gate)
            await workflow.execute_activity(mark_gate_ready_for_review, gate_id,
                start_to_close_timeout=timedelta(seconds=30), retry_policy=RETRY_POLICIES["transient"])  # base.py:1068-1073
```

**Branch inventory (4 + finally):** `output_artifacts[0] if … else ""` (1044); `if not
agent_markdown: raise` (1049); `except Exception` (1060); `finally` → `if
workflow.patched("mark-gate-ready-for-review-v1")` (1067).

**Activity calls (in order):**
1. `dispatch_agent_task` — `gate-pre-review` skill, `task_type="gate-pre-review"`; **10 minutes**;
   `transient`. (Inside the try.)
2. `store_gate_pre_review` — `StoreGatePreReviewInput`; **30s**; `transient`. (Only if markdown
   non-empty.)
3. `mark_gate_ready_for_review` — positional `gate_id`; **30s**; `transient`. **In `finally`,
   patch-gated.** Runs whether or not the pre-review succeeded.

> ⚠️ **GOTCHA-PR1 (`artifact_repo`/`artifact_ref` MUST be passed or pre-review runs blind):** the
> docstring (`base.py:1012-1019`) warns: without `artifact_repo`+`artifact_ref`, the agent-side
> fetch gate (`_fetch_input_artifacts`, which requires non-empty `artifact_repo`) silently no-ops,
> the skill runs with `input_artifacts_dir=""`, and the report complains about missing context.
> Callers default to `""` for back-compat but every real dispatcher passes the active wave/app
> branch. A rebuild must thread these through.
> ⚠️ **GOTCHA-PR2 (`finally` runs the ready-flip even on pre-review failure):** the
> `mark_gate_ready_for_review` flip is in `finally` (`base.py:1066`), so the gate becomes reviewable
> even when the AI pre-review failed. A rebuild MUST place this in `finally`, not in the `try`
> success path — otherwise a flaky pre-review would block the gate from ever opening.
> ⚠️ **GOTCHA-PR3 (patch ID verbatim):** `workflow.patched("mark-gate-ready-for-review-v1")`
> (`base.py:1067`). Exact string; load-bearing for replay of pre-patch histories.

---

## 13. `_wait_for_gate_decision(...)` — the gate wait (`base.py:1075-1129`) ★ CORE

The heart of gate routing. Blocks on a buffered decision (or cancel), consumes it in order, and
returns `"approved"` / `"rejected"` / `"cancelled"`. On reject it records structured rework
feedback; on approve it clears prior feedback for that gate.

```text
async def _wait_for_gate_decision(self, gate_type: GateType) -> str:
    self._status = WorkflowStatus.WAITING_FOR_SIGNAL    # base.py:1085
    self._pending_gate = gate_type                      # base.py:1086
    self._updated_at = _now_iso()                       # base.py:1087

    consumed = self._gate_decisions_consumed            # base.py:1089  ← snapshot the cursor
    await workflow.wait_condition(                      # base.py:1090
        lambda: len(self._gate_decisions) > consumed or self.cancelled)   # base.py:1091 ★PREDICATE

    if self.cancelled:                                  # base.py:1094  BRANCH A
        self._status = WorkflowStatus.CANCELLED         # base.py:1095
        self._updated_at = _now_iso()
        return "cancelled"                              # base.py:1097

    entry = self._gate_decisions[consumed]              # base.py:1099
    if len(entry) == 5:                                 # base.py:1104  BRANCH B (5-tuple)
        decision, actor, reason, reason_category, card_decisions = entry   # base.py:1105
    else:                                               # base.py:1106  (3-tuple legacy)
        decision, actor, reason = entry[0], entry[1], entry[2]   # base.py:1107
        reason_category = None                          # base.py:1108
        card_decisions = []                             # base.py:1109
    self._gate_decisions_consumed = consumed + 1        # base.py:1110  ← advance cursor

    self._pending_gate = None                           # base.py:1112
    self._status = WorkflowStatus.RUNNING               # base.py:1113
    self._updated_at = _now_iso()

    gate_key = gate_type.value                          # base.py:1116
    if decision == GateStatus.APPROVED:                 # base.py:1117  BRANCH C
        self._rework_feedback.pop(gate_key, None)       # base.py:1118  ← clear prior feedback
        return "approved"                               # base.py:1119

    # else: rejected
    self._rework_feedback[gate_key] = {                 # base.py:1121-1128
        "gate": gate_key,
        "rejected_by": actor,
        "reason": reason,
        "reason_category": reason_category,
        "card_decisions": card_decisions,
        "rejected_at": _now_iso(),
    }
    return "rejected"                                   # base.py:1129
```

**Branch inventory (3 decision branches + tuple-length branch):**
- **A.** `if self.cancelled:` (1094) → status `CANCELLED`, return `"cancelled"`.
- **B.** `if len(entry) == 5:` (1104) vs else 3-tuple (1106) — see GOTCHA-S1.
- **C.** `if decision == GateStatus.APPROVED:` (1117) → pop feedback, return `"approved"`; else
  (rejected) → store structured feedback dict, return `"rejected"`.

> ⚠️ **GOTCHA-WG1 (the cursor pattern — buffered, in-order, race-safe):** `consumed =
> self._gate_decisions_consumed` is snapshotted BEFORE the wait (`base.py:1089`); the predicate is
> `len(self._gate_decisions) > consumed` (`base.py:1091`). This makes the wait race-safe against
> signals that arrive BEFORE `_wait_for_gate_decision` is even called (the comment at
> `base.py:147-148` explains decisions may arrive early and are buffered/consumed in order). The
> consumer reads `_gate_decisions[consumed]` (`base.py:1099`) and advances `consumed+1`
> (`base.py:1110`). A rebuild MUST use this exact snapshot-then-index-then-advance pattern; a naive
> `wait_condition(lambda: len(self._gate_decisions) > 0)` then `.pop(0)` would mis-handle a second
> gate whose decision arrived during the first gate's wait.
> ⚠️ **GOTCHA-WG2 (`cancelled` short-circuits before consuming):** branch A checks `cancelled`
> FIRST and returns without consuming a decision (`base.py:1094-1097`). So a cancel during a gate
> wait does NOT advance the cursor. A rebuild must check cancel before reading
> `_gate_decisions[consumed]`.
> ⚠️ **GOTCHA-WG3 (`_status` round-trip):** sets `WAITING_FOR_SIGNAL` on entry (1085) and `RUNNING`
> on consumption (1113) — so the `get_status` query shows the gate-wait window. A rebuild must
> reproduce both transitions and set `_pending_gate=gate_type` then back to `None`.
> ⚠️ **GOTCHA-WG4 (approve POPS, reject SETS — feedback lifecycle):** approve does
> `_rework_feedback.pop(gate_key, None)` (1118) so a re-approved gate carries no stale feedback;
> reject stores the full structured dict keyed by `gate_type.value` (1121-1128). `_dispatch_agent`
> later forwards that dict via `context["rework_feedback"]` for the matching gate's steps. A
> rebuild must key feedback by `gate_type.value` and clear on approve.
> ⚠️ **GOTCHA-WG5 (this method does NOT increment `_rework_iterations`):** despite the docstring at
> `base.py:1079-1081` ("increments the per-gate rework counter in `self._rework_iterations`"), the
> BODY does **not** call `_bump_rework` or touch `_rework_iterations` at all. The counter is bumped
> by the **subclass `run()`** rework loop via `_bump_rework(gate_key)` (§17). A rebuild must NOT
> increment the counter inside `_wait_for_gate_decision` — doing so would double-count against the
> subclass's own bump. (The docstring is stale; the code is authoritative.)
> ⚠️ **GOTCHA-WG6 (routing: this returns a STRING, not the gate disposition):** the four routes
> reviewers can pick map to exactly three return strings here — approve→`"approved"`,
> reject→`"rejected"`, cancel→`"cancelled"`. **`merge_blocked` and the rework loop are NOT handled
> in this method.** `merge_blocked` is a post-approval state handled by
> `_reconcile_and_merge_with_retry_loop` (§14); the rework loop (re-dispatch on `"rejected"`) is
> orchestrated by the subclass `run()` (§17). A rebuild must keep this method's contract to the
> three strings and push merge/rework routing to the layers below/above.

---

## 14. `_reconcile_and_merge_with_retry_loop(...)` — merge with merge_blocked loop (`base.py:1131-1251`) ★ CORE

After a gate is approved, every merging line calls this. It merges the gate PR; on a structured
merge error it transitions the gate to `merge_blocked` and **waits for the reviewer to retry**,
looping until success or cancel. W17 / P5-S17.4.

```text
async def _reconcile_and_merge_with_retry_loop(self, *, repo, pr_number, gate_id,
                                               merge_method="merge"):
    merge_failure_types = {"MergeConflict", "MergeDivergenceUnresolved",
                           "MergeBranchProtectionRejected"}          # base.py:1168-1172
    merge_ctx = self._execution_ctx(f"merge-pr-{pr_number}", gate_id=gate_id)   # base.py:1174

    while True:                                                      # base.py:1178  ★LOOP
        try:
            await workflow.execute_activity(
                reconcile_and_merge_pr,
                MergePRInput(repo=repo, pr_number=pr_number, merge_method=merge_method,
                             execution_context=merge_ctx),
                start_to_close_timeout=timedelta(seconds=60),        # base.py:1188
                retry_policy=RETRY_POLICIES["git_merge"])            # base.py:1189  3 attempts + non_retryable
            return                                                   # base.py:1192  ← SUCCESS exits loop
        except (ActivityError, ApplicationError) as outer_exc:       # base.py:1193  BRANCH
            inner = outer_exc                                        # base.py:1200
            while (not isinstance(inner, ApplicationError)
                   and getattr(inner, "__cause__", None) is not None):   # base.py:1201-1204  LOOP (unwrap)
                inner = inner.__cause__                              # base.py:1205
            if not isinstance(inner, ApplicationError):              # base.py:1206  BRANCH
                raise                                                # base.py:1207  ← can't unwrap → propagate
            failure_type = inner.type or ""                         # base.py:1208
            if failure_type not in merge_failure_types:              # base.py:1209  BRANCH
                raise                                                # base.py:1212  ← not our error → propagate
            exc = inner

            detail = {"failure_type": failure_type, "reason": str(exc),
                      "pr_number": pr_number, "detected_at": _now_iso()}   # base.py:1215-1220
            workflow.logger.warning("merge_blocked", extra={...})    # base.py:1221-1228

            self._merge_retry_signalled = False                     # base.py:1233  ★ reset BEFORE block
            await workflow.execute_activity(set_gate_merge_blocked,
                args=[gate_id, detail],
                start_to_close_timeout=timedelta(seconds=30),
                retry_policy=RETRY_POLICIES["transient"])            # base.py:1235-1240
            await workflow.wait_condition(                          # base.py:1243
                lambda: self._merge_retry_signalled or self.cancelled)   # base.py:1244 ★PREDICATE
            if self.cancelled:                                       # base.py:1246  BRANCH
                return                                               # base.py:1247  ← cancel exits loop
            # loop back to top → retry merge
```

**Branch inventory (5 + 2 loops):** `while True` (1178); `except (ActivityError,
ApplicationError)` (1193); the unwrap `while` (1201); `if not isinstance(inner, ApplicationError):
raise` (1206); `if failure_type not in merge_failure_types: raise` (1209); `if self.cancelled:
return` (1246).

**Activity calls (per loop iteration, in order):**
1. `reconcile_and_merge_pr` — `MergePRInput`; **60s**; **`git_merge`** policy (3 attempts;
   non_retryable: MergeConflict / MergeDivergenceUnresolved / MergeBranchProtectionRejected).
   Success → `return` (loop exits).
2. (on structured merge error) `set_gate_merge_blocked` — positional `args=[gate_id, detail]`;
   **30s**; `transient`.
3. (then) `await wait_condition(merge_retry_signalled or cancelled)` — blocks for reviewer retry.

> ⚠️ **GOTCHA-MR1 (the `__cause__` unwrap — Temporal wraps ApplicationError):** Temporal wraps
> activity failures in `ActivityError`; the structured `ApplicationError` (carrying `.type` = class
> name) lives in `__cause__` (`base.py:1200-1205`). The `while` walks `__cause__` until it finds an
> `ApplicationError` OR runs out of causes. foundry_temporal's decorator may ALSO re-raise
> `ApplicationError` directly, so both shapes are accepted (the `except` catches both). A rebuild
> MUST walk `__cause__` to extract `inner.type`; reading `outer_exc.type` directly would miss the
> wrapped structured type.
> ⚠️ **GOTCHA-MR2 (two re-raise escapes):** (a) if unwrapping never yields an `ApplicationError`,
> `raise` (1206-1207) — non-structured failure propagates and the workflow fails normally; (b) if
> `failure_type` is not one of the three merge types, `raise` (1209-1212). Only the three
> structured merge errors enter the `merge_blocked` wait. A rebuild must keep BOTH escapes —
> otherwise an unrelated activity failure would get silently trapped in the merge loop.
> ⚠️ **GOTCHA-MR3 (reset `_merge_retry_signalled=False` BEFORE setting merge_blocked):**
> `base.py:1230-1233` — the flag is reset before the `set_gate_merge_blocked` activity AND before
> the wait, so a stale retry signal from a PRIOR loop iteration can't immediately short-circuit a
> fresh wait. A rebuild MUST reset before the block, not after. The trailing comment
> (`base.py:1248-1251`) notes the flag stays `True` through the next attempt and is cleared at the
> top of the NEXT iteration if the merge fails again.
> ⚠️ **GOTCHA-MR4 (`git_merge` policy is what surfaces the structured type):** the 3 merge errors
> are in `non_retryable_error_types` (`retry_policies.py:99-103`) so the policy short-circuits
> (MergeConflict/BranchProtection) or exhausts (MergeDivergence after 3) and surfaces the
> `ApplicationError.type`. A rebuild MUST use `git_merge` here, not `transient`, or the loop will
> retry forever at the Temporal level and never reach `merge_blocked`.
> ⚠️ **GOTCHA-MR5 (cancel during merge_blocked returns cleanly):** `if self.cancelled: return`
> (1246-1247) exits the loop without merging. A rebuild must include `cancelled` in the
> `wait_condition` predicate and return on it.
> ⚠️ **GOTCHA-MR6 (positional `args=` on set_gate_merge_blocked):** like the output-ref patch, this
> activity takes positional `args=[gate_id, detail]` (`base.py:1237`), not a dataclass.

---

## 15. `_build_evidence_data(...)` — evidence bundle for the gate UI (`base.py:1253-1319`)

Builds the structured evidence bundle. **Slim by default** (no inline content); `include_content`
or `content_paths` selectively inline file contents.

```text
def _build_evidence_data(self, app_id, assembly_line, step, *,
                         include_content=False, content_paths=None) -> dict:
    steps = {}
    for step_name, step_def in self._evidence_steps_iter():          # base.py:1281  LOOP (hook)
        artifacts = self._step_results.get(step_name, [])            # base.py:1282
        metadata  = self._agent_metadata.get(step_name, {})          # base.py:1283
        output_files = metadata.get("output_files", [])              # base.py:1284

        raw_file_artifacts = []
        for f in output_files:                                       # base.py:1287  LOOP
            if not isinstance(f, OutputFile):                        # base.py:1288  BRANCH
                continue                                             # base.py:1289  ← skip non-OutputFile
            entry = {"path": f.path, "encoding": f.encoding}         # base.py:1290
            content_str = f.content if isinstance(f.content, str) else ""   # base.py:1294  BRANCH
            entry["size"] = len(content_str.encode("utf-8")) if content_str else 0   # base.py:1295 BRANCH
            if include_content or (content_paths is not None and f.path in content_paths):  # base.py:1296-1298 BRANCH
                entry["content"] = f.content                         # base.py:1299
            raw_file_artifacts.append(entry)

        deduped_file_artifacts = list({f["path"]: f for f in raw_file_artifacts}.values())   # base.py:1302-1304
        steps[step_name] = {
            **self._evidence_step_metadata(step_name, step_def),     # base.py:1306  (hook)
            "output": artifacts[0] if artifacts else "",             # base.py:1307  BRANCH
            "metadata": {k: v for k, v in metadata.items() if k != "output_files"},   # base.py:1308-1310
            "file_artifacts": deduped_file_artifacts,                # base.py:1311
        }

    return {                                                         # base.py:1314-1319
        "assembly_line": assembly_line,
        "app_id": app_id,
        "current_step": step,
        "steps": steps,
    }
```

**Branch inventory (5 + 2 loops):** `for step_name, step_def …` (1281); `for f in output_files`
(1287); `if not isinstance(f, OutputFile): continue` (1288); `content_str = … if isinstance(...)
else ""` (1294); `entry["size"] = … if content_str else 0` (1295); `if include_content or
(content_paths is not None and f.path in content_paths)` (1296); `"output": artifacts[0] if
artifacts else ""` (1307).

> ⚠️ **GOTCHA-BE1 (slim by default — content omitted):** by default `entry` carries only `path`,
> `encoding`, `size` — NOT `content` (`base.py:1290-1300`). Content is inlined ONLY when
> `include_content=True` OR `f.path in content_paths`. Artifact contents live in git; the API
> hydrates on demand. This keeps blobs under Temporal's `limit.blobSize`. A rebuild MUST default to
> slim.
> ⚠️ **GOTCHA-BE2 (`size` always computed, even in slim mode):** `size` (utf-8 byte length) is
> always set (`base.py:1295`) so the UI can decide "big file, fetch on click" vs "tiny, render
> inline". A rebuild must always compute size.
> ⚠️ **GOTCHA-BE3 (dedup by path, last-wins):** `{f["path"]: f for f in raw_file_artifacts}`
> collapses duplicate paths keeping the LAST occurrence (`base.py:1302-1304`). A rebuild must dedup
> by path with last-wins semantics.
> ⚠️ **GOTCHA-BE4 (`metadata` strips `output_files`):** the per-step `metadata` in the bundle
> excludes the `output_files` key (`base.py:1308-1310`) — those are surfaced as `file_artifacts`
> instead. A rebuild must strip `output_files` from the metadata projection.
> ⚠️ **GOTCHA-BE5 (`isinstance(f, OutputFile)` guard):** non-`OutputFile` entries in `output_files`
> are skipped (`base.py:1288-1289`). Defensive against malformed metadata. Keep it.

---

## 16. `get_status()` query — dashboard status (`base.py:1325-1337`)

```text
@workflow.query
def get_status(self) -> WorkflowStatusResponse:
    return WorkflowStatusResponse(
        workflow_id  = workflow.info().workflow_id,    # base.py:1329
        status       = self._status,
        current_line = self.ASSEMBLY_LINE,             # base.py:1331
        current_step = self._current_step,
        progress_pct = self._progress_pct,
        pending_gate = self._pending_gate,
        started_at   = self._started_at,
        updated_at   = self._updated_at,
    )
```
- The **only** query on the base. Synchronous, read-only (queries must not mutate state). ⚠️
  **CHANGED-AT-HEAD:** bundle-aware subclasses ALSO carry `get_bundle_outcome` /
  `get_bundle_outputs` queries inherited from `BundleAwareMixin` (`bundle_helpers.py:182-190`) —
  distinct names, no clash with `get_status`.
- ⚠️ **GOTCHA-Q1 (subclasses MAY add queries but MUST NOT redefine `get_status`):** like the gate
  signals, `get_status` is registered once on the base. A subclass adding its own queries (e.g.
  `dispatch_results`, `pending_dispatch_payload`) must use distinct names. A rebuild keeps
  `get_status` here and never re-decorates it in subclasses.
- ⚠️ **GOTCHA-Q2 (reads live mutable state):** the query returns the current values of
  `_status`/`_current_step`/`_progress_pct`/`_pending_gate`/`_updated_at`, all of which are mutated
  by `_set_step` and `_wait_for_gate_decision`. So a dashboard polling `get_status` during a gate
  wait sees `status=WAITING_FOR_SIGNAL`, `pending_gate=<gate>`. A rebuild must wire these vars so
  the query reflects them.

---

## 17. Rework counter mechanics — `_rework_count` / `_bump_rework` (`base.py:1344-1353`)

```text
def _rework_count(self, gate_key: str) -> int:                   # base.py:1344-1346
    return self._rework_iterations.get(gate_key, 0)

def _bump_rework(self, gate_key: str) -> int:                    # base.py:1348-1353
    self._rework_iterations[gate_key] = self._rework_iterations.get(gate_key, 0) + 1
    return self._rework_iterations[gate_key]
```
- `_rework_count(gate_key)` → current count (0 if none).
- `_bump_rework(gate_key)` → increment and return new count.

> ⚠️ **GOTCHA-RW1 (the COUNTER is bumped by the SUBCLASS, not by `_wait_for_gate_decision`):** Per
> GOTCHA-WG5, `_wait_for_gate_decision` does NOT touch `_rework_iterations`. The canonical subclass
> rework loop (reconstruct in each per-line spec) is:
> ```text
> while True:
>     <dispatch step(s)>; <commit>; <create gate PR>; <submit evidence>; <pre-review>
>     decision = await self._wait_for_gate_decision(gate_type)
>     if decision == "cancelled":  -> set _status=CANCELLED, return/raise
>     if decision == "approved":   -> await self._reconcile_and_merge_with_retry_loop(...); break
>     # decision == "rejected":
>     n = self._bump_rework(gate_key)          # ← counter bumped HERE
>     if n > MAX_REWORK:  -> escalate / fail   # subclass policy
>     # loop: re-dispatch with _rework_feedback[gate_key] now populated
> ```
> A rebuild MUST bump in the subclass on the `"rejected"` branch, and the re-dispatch picks up
> `_rework_feedback[gate_key]` (set by `_wait_for_gate_decision`, forwarded by `_dispatch_agent`).
> The exact `MAX_REWORK` ceiling and escalate-vs-fail policy are per-subclass — see each line spec.
> ⚠️ **GOTCHA-RW2 (back-compat accessor names):** these per-attr-style accessors exist to keep
> back-compat with legacy code / PR-body builders that referenced per-gate counts
> (`base.py:1339-1342`). A rebuild keeps both methods even though only `_bump_rework` mutates.

---

## 18. Override matrix — which subclass overrides what

| Method | Default (base) | Subclasses that OVERRIDE | MUST NOT override |
|--------|----------------|--------------------------|-------------------|
| `gate_approved` / `gate_rejected` / `escalation_resolved` / `merge_retry` | base signals | — | **ALL** (GOTCHA-SIG0) |
| `get_status` | base query | — (add new queries instead) | **ALL** (GOTCHA-Q1) |
| `_task_type_prefix` | `ARTIFACT_ROOT` | lines where task_type ≠ artifact root | — |
| `_rework_gate_key_for_step` | `SINGLE_GATE_KEY` | multi-gate lines (Modernization, Disposition, Validation, …) | — |
| `_primary_skill_for_step` | `STEPS[step]["skill_id"]` | **Validation** (uses `skills` list; GOTCHA-H2) | — |
| `_evidence_step_metadata` | `skill_id`-shaped | **Validation** | — |
| `_evidence_steps_iter` | `STEPS.items()` | Rationalization (excl. governance), Modernization (fan-out) | — |
| `_apply_bundle_fallback` *(NEW)* | redispatch/escalate/internal (§8a.4) | lines wanting softer non-accepted handling | — |
| `run()` / `_execute()` | **absent** | **ALL** (each line defines its own) | — |

> ⚠️ **GOTCHA-OV1 (HIL signals are inherited, not redefined either):** the `_HILSignalsMixin`
> signals (`approve`, `cancel_workflow`, `approve_plan`, `provide_plan_feedback`,
> `approve_research`, `provide_feedback`) are inherited transitively. A subclass relying on
> `self.cancelled` etc. does NOT redefine them. Adding *new* HIL-style signals uses the
> `create_*_signal` factories or fresh `@workflow.signal` methods with unique names.
> ⚠️ **CHANGED-AT-HEAD GOTCHA-OV2 (`BundleAwareMixin` is opt-in via MRO, not on the base):** to use
> `_maybe_dispatch_bundle`, a line must inherit `BundleAwareMixin` IN ADDITION to
> `LineWorkflowBase` (the only line that does at HEAD is Modernization, whose actual MRO is
> `class ModernizationWorkflow(BundleAwareMixin, LineWorkflowBase)` — mixin FIRST; ordering is not
> load-bearing since the two contribute disjoint method sets), supplying
> `await_bundle_completion`, `_bundle_outcomes`, `_bundle_outputs`, and the `bundle_completed` /
> `bundle_expired` signal handlers. The base detects the mixin at runtime via
> `hasattr(self, "await_bundle_completion")` (GOTCHA-PW1) so a line WITHOUT it runs everything
> internally. A rebuild keeps the base mixin-agnostic and the `hasattr` guard as the safe default.

---

## 19. RESILIENCE summary

- **Timeouts (start_to_close):** status update 30s; dispatch_agent 1h; context-priors 10s;
  delegation-config load 15s; resolve-dispatch-mode 30s; dispatch-delegated-bundle 30s; commit
  batch 120s; mirror batch 120s; output-ref patch 30s; create_pr 60s; check_gate_criteria 60s;
  submit_gate_evidence 60s; pre-review dispatch 10m; store_gate_pre_review 30s;
  mark_gate_ready_for_review 30s; reconcile_and_merge_pr 60s; set_gate_merge_blocked 30s.
  **Bundle await timeout** = `expires_hours*3600 + 3600` (workflow-internal, GOTCHA-PW4).
- **Heartbeats:** none configured in base.py (relies on start_to_close timeouts).
- **continue-as-new:** none in base.py (subclass `run()` may; the base is stateless across waits).
- **Idempotency:** deterministic `activity_id`s (`agent-{step}`, `commit-{step}`,
  `patch-output-ref-{step}`) make those activities replay-stable. `_now_iso()` = `workflow.now()` is
  deterministic. Patch IDs gate optional activity additions. (The paired-work activities use
  positional `args=` and no explicit `activity_id` — the bundle id they return is persisted by the
  workflow, and re-dispatch is bounded by `_redispatch_guard`.)
- **Compensation / rollback:** none — there is no rollback path in the base. Failure semantics:
  best-effort activities (context-priors load, delegation-config load, mirror write, output-ref
  patch, pre-review, ready-flip) swallow exceptions and continue; structured merge errors route to
  `merge_blocked` and wait for reviewer retry; a non-accepted delegated bundle routes to
  `_apply_bundle_fallback` (internal / redispatch / escalate-or-fail per portfolio policy); cancel
  (`self.cancelled`) drains every wait to a `CANCELLED`/clean return. The subclass `run()` owns
  terminal `FAILED` status + any DB failure projection (e.g. `persist_*_side_effects` /
  `persist_wave_failure`).
- **Best-effort activity policy:** `_execution_ctx` returns `None` when `_portfolio_id` is empty, so
  all Layer-B `step_execution` emission is best-effort and never blocks dispatch.

---

## 20. Behavioral parity checklist

A rebuilt `LineWorkflowBase` MUST satisfy ALL of the following:

1. `class LineWorkflowBase(HILSignalsMixin)`; `__init__` calls `super().__init__()` **first**
   (`base.py:132`), then initializes the 22 line-state vars (including the 3 NEW paired-work vars
   `_profile_id`/`_portfolio_fallback_policy`/`_redispatch_guard`) to the exact initial values in §2.
2. `_gate_decisions` is populated with **5-tuples** by `gate_approved`/`gate_rejected`, and
   `_wait_for_gate_decision` tolerates BOTH 5-tuple and 3-tuple entries (`len(entry)==5` branch).
   The 3-tuple type annotation is NOT enforced at runtime. (GOTCHA-S1)
3. Exactly four `@workflow.signal` handlers are defined on the base — `gate_approved`,
   `gate_rejected`, `escalation_resolved`, `merge_retry` — all `async def`. They are NEVER
   redefined by subclasses (GOTCHA-SIG0). `gate_approved` appends `(APPROVED, approved_by,
   justification, None, [])` and bumps `_updated_at`; `gate_rejected` reads `card_decisions` /
   `reason_category` defensively via `getattr` and appends the full 5-tuple; `escalation_resolved`
   only bumps `_updated_at`; `merge_retry` sets `_merge_retry_signalled=True` unconditionally and
   bumps `_updated_at`.
4. `_now_iso()` uses `workflow.now().isoformat()` — never `datetime.now()`.
5. `_execution_ctx` returns `None` iff `_portfolio_id` is empty; otherwise builds a
   `StepExecutionContext` with `line_id = LINE_LABEL.lower().replace(" ","-")` and `is None`
   fallback semantics for `app_id`/`wave_id`. (GOTCHA-EC1/EC2)
6. `_set_step` sets `_current_step`/`_progress_pct`/`_updated_at` then, ONLY if `_app_id`, awaits
   `_update_app_status(app_id, "{STATUS_PREFIX}_in_progress", step, LINE_LABEL)`. It does NOT mutate
   `_status`.
7. `_update_app_status` calls `update_application_status` with **30s** timeout and **`transient`**
   policy (NOT `validation_failure`). (GOTCHA-US1)
8. `_dispatch_agent`: resolves `skill_id` via `_primary_skill_for_step`; attaches
   `context["rework_feedback"]` iff `_rework_gate_key_for_step(step)` is not None AND has feedback;
   loads context-priors ONLY under `workflow.patched("context-priors-v1")` (best-effort try/except,
   10s/`transient`) attaching `context["context_priors"]` iff non-empty; dispatches
   `dispatch_agent_task` (1h, `agent_failure`, `activity_id="agent-{step}"`); records 6-field
   `_agent_metadata[step]`. (GOTCHA-DA1/DA2/DA3)
8a. **(NEW)** Paired-work block (§8a) is present and ADDITIVE:
    - `_load_delegation_config(profile_id)` UNCONDITIONALLY sets `_profile_id=str(profile_id or "")`,
      early-returns on empty, loads `load_portfolio_delegation_activity` (15s/`transient`) best-effort,
      and adopts `_portfolio_fallback_policy` only if a non-empty str. (GOTCHA-S3/PW0)
    - `_maybe_dispatch_bundle`: `hasattr(self,"await_bundle_completion")` guard FIRST → else
      `fallback_fn()`; calls `resolve_dispatch_mode` (30s/`transient`); on `!= "delegated_bundle"` →
      `fallback_fn()`; on accept returns bundle outputs; else `_apply_bundle_fallback`. (GOTCHA-PW1/PW2/PW3)
    - `_dispatch_bundle_and_wait`: `dispatch_delegated_bundle` (positional 7-arg, 30s/`transient`)
      then `await_bundle_completion(bundle_id, timeout=expires_hours*3600+3600)`; returns
      `{bundle_id, outcome, outputs}`; reads `_bundle_outputs` only on accept. (GOTCHA-PW4/PW5)
    - `_apply_bundle_fallback`: `redispatch` (guarded by `_redispatch_guard`, one extra cycle) →
      accept-or-`fallback_fn`; `escalate`/`fail` → raise non-retryable `ApplicationError`
      type `"DELEGATED_BUNDLE_FALLBACK"`; default `internal_fallback` → `fallback_fn`. (GOTCHA-PW6/PW7/PW8)
    - `_workflow_created_by`: prefers `self._input.created_by`, else `"olympus-line-workflow"`.
9. `_commit_step_artifacts`: builds summary JSON (with conditional `skill_id` XOR `skills`), batches
   summary + all output files into ONE `write_artifacts_batch` commit
   (120s/`transient`/`activity_id="commit-{step}"`) to paths
   `{ARTIFACT_ROOT}/{app_id}/files/{step}/{path}`; ONLY if `mirror_repo and output_files` does a
   best-effort mirror batch to `mirror_repo`@`main` (try/except, never fatal); sets
   `_step_committed_paths[step]`; ONLY under `workflow.patched("patch-output-artifact-ref-v1")`
   calls `update_agent_task_output_ref` with positional `args=[app_id, "{prefix}-{step}",
   artifact_path]` (30s/`transient`/`activity_id="patch-output-ref-{step}"`, try/except…pass).
   (GOTCHA-CSA1..5)
10. `_create_gate_pr` always targets `main`, labels `["gate-review", ARTIFACT_ROOT, gate_type]`,
    `create_pr` 60s/`transient`. (GOTCHA-GP1)
11. `_submit_gate_evidence`: builds SLIM bundle for `submit_gate_evidence`; for
    `check_gate_criteria`, if the gate has `GATE_THRESHOLDS` rebuilds with `content_paths` of full
    paths whose suffix matches any threshold artifact (else slim); branches on `forward_risk_tier`
    to include/omit `evidence_data`+`risk_tier`; both activities 60s/`transient`. (GOTCHA-SE1..4)
12. `_run_gate_pre_review`: dispatches `gate-pre-review` (10m/`transient`) inside try; raises
    `ValueError` on empty output; stores via `store_gate_pre_review` (30s/`transient`); `except
    Exception` logs and continues; `finally` runs `mark_gate_ready_for_review` (positional `gate_id`,
    30s/`transient`) ONLY under `workflow.patched("mark-gate-ready-for-review-v1")`.
    (GOTCHA-PR1/PR2/PR3)
13. `_wait_for_gate_decision`: sets `WAITING_FOR_SIGNAL`+`pending_gate`; snapshots
    `consumed=_gate_decisions_consumed`; waits `len(_gate_decisions)>consumed or self.cancelled`; on
    cancel → `CANCELLED`, return `"cancelled"` WITHOUT consuming; else reads
    `_gate_decisions[consumed]`, handles 5-tuple/3-tuple, advances `consumed+1`, sets
    `pending_gate=None`+`RUNNING`; on APPROVED pops `_rework_feedback[gate_type.value]` and returns
    `"approved"`; else stores the 6-key structured feedback dict and returns `"rejected"`. Does NOT
    touch `_rework_iterations`. (GOTCHA-WG1..6)
14. `_reconcile_and_merge_with_retry_loop`: `while True`; merges via `reconcile_and_merge_pr`
    (60s, **`git_merge`** policy) → return on success; on `(ActivityError, ApplicationError)`
    unwraps `__cause__` to find the `ApplicationError`, re-raises if none or if `type` not in
    {MergeConflict, MergeDivergenceUnresolved, MergeBranchProtectionRejected}; else resets
    `_merge_retry_signalled=False`, calls `set_gate_merge_blocked` (positional `args=[gate_id,
    detail]`, 30s/`transient`), waits `_merge_retry_signalled or self.cancelled`, returns on cancel,
    else loops. (GOTCHA-MR1..6)
15. `_build_evidence_data`: slim by default; always computes utf-8 byte `size`; inlines `content`
    only when `include_content` or `f.path in content_paths`; skips non-`OutputFile`; dedups
    file_artifacts by path (last-wins); strips `output_files` from per-step `metadata`; iterates
    `_evidence_steps_iter()` and merges `_evidence_step_metadata(...)`. (GOTCHA-BE1..5)
16. `get_status` is the ONLY base query (`@workflow.query`), read-only, returns
    `WorkflowStatusResponse` built from live state + `workflow.info().workflow_id` + `ASSEMBLY_LINE`.
    Never redefined by subclasses. (GOTCHA-Q1/Q2)
17. `_rework_count(gate_key)` returns `_rework_iterations.get(gate_key,0)`; `_bump_rework(gate_key)`
    increments and returns. The counter is bumped by the SUBCLASS rework loop on `"rejected"`, NOT
    by `_wait_for_gate_decision`. (GOTCHA-RW1/RW2)
18. All `workflow.patched(...)` IDs are reproduced VERBATIM: `"context-priors-v1"`,
    `"patch-output-artifact-ref-v1"`, `"mark-gate-ready-for-review-v1"`. (The paired-work block adds
    NO new patch ids — it is gated by the `hasattr` mixin check, not a patch.)
19. All activity imports are inside `with workflow.unsafe.imports_passed_through():` — including the
    NEW `bundle_activities` imports (`DISPATCH_MODE_DELEGATED_BUNDLE`, `dispatch_delegated_bundle`,
    `load_portfolio_delegation_activity`, `resolve_dispatch_mode`).
20. No subclass redefines the four base gate signals or `get_status`; every subclass supplies its
    own `run()`/`_execute()` and (where multi-gate / validation) overrides `_rework_gate_key_for_step`
    / `_primary_skill_for_step` / `_evidence_step_metadata` / `_evidence_steps_iter` as listed in §18.
    Lines that delegate ALSO inherit `BundleAwareMixin` (GOTCHA-OV2) and MAY override
    `_apply_bundle_fallback` for softer non-accepted handling.
