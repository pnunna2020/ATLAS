# `HILSignalsMixin` — Shared Human-in-the-Loop Signal Surface (ATOMIC regeneration spec)

> **Source of truth:** `foundry_temporal/signals.py` (the external `foundry-temporal`
> package). Read for this spec at
> `/private/var/folders/qs/dwcdl18n351cyz88x2tc9w3w0000gp/T/tmp.2xQMcqnDWM/foundry_temporal/signals.py`.
> Citations below are `signals.py:line` against that file (141 lines total).
>
> **What this is:** the base mixin that **every** Olympus workflow inherits *transitively*
> via `LineWorkflowBase(HILSignalsMixin)` (see `_LineWorkflowBase.md`). It contributes a
> fixed set of `@workflow.signal` handlers, plain (non-signal) helper methods, and two
> **module-level factory functions** that synthesize custom signals. It defines **no**
> queries, **no** updates, **no** `run()`. It is pure signal-state plumbing.
>
> **Determinism note:** every method here is a synchronous attribute mutation. No
> `workflow.now()`, no I/O, no `await`. Signal handlers are non-async (`def`, not `async
> def`) — they complete in a single workflow task with no yield point. This matters for
> ordering (see GOTCHA-1).

---

## 0. Class shape & inheritance contract

```text
class HILSignalsMixin:          # signals.py:10
    def __init__(self): ...     # signals.py:21  — calls super().__init__()
    @workflow.signal approve_plan(self)                       # signals.py:40-45
    @workflow.signal provide_plan_feedback(self, comments)    # signals.py:47-52
    @workflow.signal approve_research(self)                   # signals.py:55-60
    @workflow.signal provide_feedback(self, comments)         # signals.py:62-67
    @workflow.signal approve(self)                            # signals.py:70-73
    @workflow.signal cancel_workflow(self)                    # signals.py:75-78
    def reset_plan_feedback(self)                             # signals.py:81-84
    def reset_document_feedback(self)                         # signals.py:86-89
    def is_plan_decision_received(self) -> bool               # signals.py:91-93
    def is_document_decision_received(self) -> bool           # signals.py:95-97

# module level (NOT methods):
def create_approval_signal(signal_name="approve")            # signals.py:101-121
def create_feedback_signal(signal_name="provide_feedback")   # signals.py:124-140
```

- **Usage contract** (`signals.py:14-19`): a subclass `__init__` must call
  `super().__init__()` so the HIL state vars below are initialized. `LineWorkflowBase.__init__`
  does exactly this (`base.py:125`).
- ⚠️ **GOTCHA-0 (cooperative `super().__init__()` chain):** `HILSignalsMixin.__init__`
  *itself* calls `super().__init__()` first (`signals.py:22`) **before** setting its own
  attrs. This is deliberate cooperative-multiple-inheritance plumbing — it lets a workflow
  declare `class W(LineWorkflowBase)` where the MRO terminates at `object`. A rebuild MUST
  keep the `super().__init__()` call as the **first** statement of `__init__`, or any class
  mixed in *after* `HILSignalsMixin` in the MRO will not be initialized.

---

## 1. STATE — every instance var (all set in `__init__`, `signals.py:21-37`)

All initialized in `HILSignalsMixin.__init__`. Types are the literal annotations in source.

| Var | Type | Initial | Set by `__init__` line | Mutated by | When |
|-----|------|---------|------------------------|------------|------|
| `approved` | `bool` | `False` | `signals.py:24` | `approve()` → `True` (`signals.py:73`); `create_approval_signal("approve")`-built signal → `True` | on general approval signal |
| `plan_approved` | `bool` | `False` | `signals.py:27` | `approve_plan()` → `True` (`signals.py:43`); `provide_plan_feedback()` → `False` (`signals.py:52`) | plan review decisions |
| `plan_feedback_received` | `bool` | `False` | `signals.py:28` | `approve_plan()` → `False` (`signals.py:44`); `provide_plan_feedback()` → `True` (`signals.py:50`); `reset_plan_feedback()` → `False` (`signals.py:83`) | plan review / reset |
| `plan_feedback_comments` | `str` | `""` | `signals.py:29` | `approve_plan()` → `""` (`signals.py:45`); `provide_plan_feedback(comments)` → `comments` (`signals.py:51`); `reset_plan_feedback()` → `""` (`signals.py:84`) | plan review / reset |
| `document_approved` | `bool` | `False` | `signals.py:32` | `approve_research()` → `True` (`signals.py:58`); `provide_feedback()` → `False` (`signals.py:67`) | document review decisions |
| `document_feedback_received` | `bool` | `False` | `signals.py:33` | `approve_research()` → `False` (`signals.py:59`); `provide_feedback()` → `True` (`signals.py:65`); `reset_document_feedback()` → `False` (`signals.py:88`) | document review / reset |
| `document_feedback_comments` | `str` | `""` | `signals.py:34` | `approve_research()` → `""` (`signals.py:60`); `provide_feedback(comments)` → `comments` (`signals.py:66`); `reset_document_feedback()` → `""` (`signals.py:89`) | document review / reset |
| `cancelled` | `bool` | `False` | `signals.py:37` | `cancel_workflow()` → `True` (`signals.py:78`) | workflow cancel request |

> ⚠️ **GOTCHA-1 (the `cancelled` flag is the universal kill switch):** `cancelled` is the
> single most load-bearing var in the whole hierarchy. `LineWorkflowBase` consumes it in
> **every** `wait_condition` predicate — `_wait_for_gate_decision`
> (`base.py:825`: `... or self.cancelled`) and `_reconcile_and_merge_with_retry_loop`
> (`base.py:978`: `... or self.cancelled`). Setting `cancelled=True` is the ONLY way those
> waits return without a positive decision. A rebuild MUST expose `cancel_workflow` as a
> live `@workflow.signal` on every workflow and MUST thread `self.cancelled` into every
> blocking `wait_condition`, or the workflow becomes unkillable via signal.

---

## 2. SIGNALS — each handler atomically (`@workflow.signal`)

All six are **synchronous** (`def`, not `async def`). Each is a pure state mutation with no
`await`, no `workflow.now()`, no I/O. There are **no queries or updates** in this mixin.

### 2.1 `approve_plan(self) -> None` — `signals.py:40-45`
Semantics: "Approve research plan, proceed to execution."
```text
def approve_plan(self):
    self.plan_approved = True               # signals.py:43
    self.plan_feedback_received = False     # signals.py:44  ← clears any pending feedback
    self.plan_feedback_comments = ""        # signals.py:45  ← clears feedback text
```
Buffers nothing. Sets a terminal "plan approved" state and atomically wipes the competing
feedback fields so a later `is_plan_decision_received()` reads cleanly as "approved".

### 2.2 `provide_plan_feedback(self, comments: str) -> None` — `signals.py:47-52`
Payload: `comments: str`. Semantics: "Request plan revision with feedback."
```text
def provide_plan_feedback(self, comments):
    self.plan_feedback_received = True      # signals.py:50
    self.plan_feedback_comments = comments  # signals.py:51  ← stores reviewer text
    self.plan_approved = False              # signals.py:52  ← un-approves
```
⚠️ **GOTCHA-2 (mutually-exclusive write order):** `approve_plan` and `provide_plan_feedback`
each set their own primary flag **and** clear the other's. Last-writer-wins. If both signals
arrive in the same workflow task batch, the **later-delivered** one wins because each fully
resets the other's state. A rebuild MUST preserve all three assignments in each handler (not
just the primary flag) or a stale `plan_feedback_comments` could leak into an approved path.

### 2.3 `approve_research(self) -> None` — `signals.py:55-60`
Semantics: "Approve final document." Mirror of `approve_plan` for the document axis.
```text
def approve_research(self):
    self.document_approved = True            # signals.py:58
    self.document_feedback_received = False  # signals.py:59
    self.document_feedback_comments = ""     # signals.py:60
```
> ⚠️ **GOTCHA-3 (signal NAME ≠ attribute NAME):** the signal is named **`approve_research`**
> but it drives the **`document_*`** state family, not a `research_*` family. The wire signal
> name a client must send is the literal method name `"approve_research"`. A rebuild MUST
> register the signal under the name `approve_research` (Temporal uses the method name as the
> default signal name) while mutating `document_approved` — do not rename to `approve_document`.

### 2.4 `provide_feedback(self, comments: str) -> None` — `signals.py:62-67`
Payload: `comments: str`. Semantics: "Request document revision with feedback." Mirror of
`provide_plan_feedback` for the document axis.
```text
def provide_feedback(self, comments):
    self.document_feedback_received = True       # signals.py:65
    self.document_feedback_comments = comments   # signals.py:66
    self.document_approved = False               # signals.py:67
```
> ⚠️ **GOTCHA-4 (asymmetric naming):** the plan-feedback signal is `provide_plan_feedback`
> but the document-feedback signal is just `provide_feedback` (NOT `provide_document_feedback`).
> The `create_feedback_signal` factory's default name is `"provide_feedback"` (`signals.py:124`)
> — i.e. this document handler is what the default factory reproduces. A rebuild MUST register
> these under exactly `provide_plan_feedback` and `provide_feedback`.

### 2.5 `approve(self) -> None` — `signals.py:70-73`
Semantics: "General approval signal." The only state it touches:
```text
def approve(self):
    self.approved = True   # signals.py:73
```
Generic catch-all "yes" used by workflows that don't need the plan/document split.

### 2.6 `cancel_workflow(self) -> None` — `signals.py:75-78`
Semantics: "Cancel the entire workflow." See GOTCHA-1.
```text
def cancel_workflow(self):
    self.cancelled = True  # signals.py:78
```
> ⚠️ **GOTCHA-5 (one-way latch, never reset):** nothing in this mixin or in `LineWorkflowBase`
> ever sets `cancelled` back to `False`. It is a one-way latch. Once flipped, every subsequent
> `wait_condition` that includes `or self.cancelled` returns immediately and the workflow
> drains toward `CANCELLED`. A rebuild MUST NOT add any reset of `cancelled`.

---

## 3. HELPER METHODS (plain methods, **not** signals — `signals.py:80-97`)

These are called by workflow control flow to interpret the signal state. They mutate or read
state but are **not** registered as Temporal signals/queries (no decorator).

### 3.1 `reset_plan_feedback(self) -> None` — `signals.py:81-84`
```text
def reset_plan_feedback(self):
    self.plan_feedback_received = False   # signals.py:83
    self.plan_feedback_comments = ""      # signals.py:84
```
Use: called by a workflow at the **top of each rework iteration** so the next
`wait_condition(lambda: self.is_plan_decision_received())` blocks on a fresh decision instead
of immediately re-firing on the just-consumed feedback. Does **not** touch `plan_approved`.

### 3.2 `reset_document_feedback(self) -> None` — `signals.py:86-89`
```text
def reset_document_feedback(self):
    self.document_feedback_received = False   # signals.py:88
    self.document_feedback_comments = ""      # signals.py:89
```
Symmetric to 3.1 for the document axis. Does **not** touch `document_approved`.

> ⚠️ **GOTCHA-6 (reset clears feedback but NOT approval):** both reset helpers deliberately
> leave `*_approved` untouched. A rework loop that resets feedback then re-waits must therefore
> guard against a stale `*_approved=True` from a prior loop, or it will fall straight through.
> The canonical loop pattern (from the architecture spec these signals derive from) is:
> `reset_*_feedback()` → dispatch revision → `await wait_condition(is_*_decision_received)` →
> branch on `*_approved`. A rebuild that wants idempotent rework loops should reset feedback at
> the top of the iteration, never the approval flag mid-loop.

### 3.3 `is_plan_decision_received(self) -> bool` — `signals.py:91-93`
```text
def is_plan_decision_received(self):
    return self.plan_approved or self.plan_feedback_received   # signals.py:93
```
The canonical `wait_condition` predicate for plan review: returns `True` the moment **either**
an approve OR a feedback signal has landed. Note it does **not** include `cancelled` — callers
that need cancellability must OR it in themselves at the call site.

### 3.4 `is_document_decision_received(self) -> bool` — `signals.py:95-97`
```text
def is_document_decision_received(self):
    return self.document_approved or self.document_feedback_received   # signals.py:97
```
Symmetric to 3.3 for the document axis.

> ⚠️ **GOTCHA-7 (predicate omits `cancelled`):** neither `is_*_decision_received` predicate
> includes `self.cancelled`. A workflow that does `await workflow.wait_condition(self.is_plan_decision_received)`
> verbatim is **NOT cancellable during that wait**. Workflows that want cancel support write
> `await workflow.wait_condition(lambda: self.is_plan_decision_received() or self.cancelled)`.
> A rebuild must decide per call site and match the original; do not silently fold `cancelled`
> into the predicate methods themselves.

---

## 4. SIGNAL FACTORY FUNCTIONS (module-level, `signals.py:101-140`)

These are **module functions**, not methods. They return a decorated signal function suitable
for assigning as a class attribute, e.g. `my_signal = create_approval_signal("ratify")`. They
let workflows mint extra HIL signals beyond the six built-ins without writing the boilerplate.

### 4.1 `create_approval_signal(signal_name: str = "approve")` — `signals.py:101-121`
```text
def create_approval_signal(signal_name="approve"):
    def signal_func(self):
        # derive past-tense attribute name from the signal name
        if signal_name.endswith("e"):              # signals.py:114
            attribute_name = f"{signal_name}d"     # signals.py:115   "approve" -> "approved"
        else:                                       # signals.py:116
            attribute_name = f"{signal_name}ed"    # signals.py:117   "ratify"  -> "ratifyed"
        setattr(self, attribute_name, True)        # signals.py:118
    signal_func.__name__ = signal_name             # signals.py:120  ← Temporal signal name
    return workflow.signal(signal_func)            # signals.py:121
```
Behavior: builds a zero-arg signal whose effect is `setattr(self, <pasttense>, True)`.
- `signal_name="approve"` (default) → sets attribute **`approved`** → identical to the built-in
  `approve()` (both write `self.approved = True`).
- ⚠️ **GOTCHA-8 (naïve past-tense rule):** the past-tense derivation is purely lexical:
  `endswith("e")` → append `"d"`, else append `"ed"` (`signals.py:114-117`). It is **not**
  English-correct. `"ratify"` → `"ratifyed"` (not `"ratified"`); `"submit"` → `"submited"`
  (not `"submitted"`). A rebuild MUST reproduce this exact (wrong) rule, because any workflow
  that reads `self.ratifyed` depends on the misspelling. Do not "fix" it.
- ⚠️ **GOTCHA-9 (`__name__` is the wire signal name):** `signal_func.__name__ = signal_name`
  (`signals.py:120`) is set **before** `workflow.signal(...)` wraps it, so Temporal registers
  the signal under `signal_name` (e.g. `"ratify"`), while the **attribute** it sets is the
  past-tense form (e.g. `ratifyed`). Signal-name and attribute-name diverge by design.

### 4.2 `create_feedback_signal(signal_name: str = "provide_feedback")` — `signals.py:124-140`
```text
def create_feedback_signal(signal_name="provide_feedback"):
    def signal_func(self, comments):
        base = signal_name.replace("provide_", "")               # signals.py:136
        setattr(self, f"{base}_received", True)                  # signals.py:136
        setattr(self, f"{base}_comments", comments)              # signals.py:137
    signal_func.__name__ = signal_name                           # signals.py:139
    return workflow.signal(signal_func)                          # signals.py:140
```
Behavior: builds a one-arg (`comments: str`) signal that sets `<base>_received = True` and
`<base>_comments = comments`, where `<base>` is `signal_name` with a leading `"provide_"`
stripped.
- `signal_name="provide_feedback"` (default) → base `"feedback"` → sets `feedback_received`
  and `feedback_comments`.
- ⚠️ **GOTCHA-10 (default factory does NOT reproduce the built-in `provide_feedback`):** the
  built-in `provide_feedback` (§2.4) writes **`document_feedback_received`** /
  **`document_feedback_comments`** and ALSO clears `document_approved`. The factory's default
  (`"provide_feedback"` → base `"feedback"`) instead writes **`feedback_received`** /
  **`feedback_comments`** and does **NOT** clear any approval flag. They are NOT the same
  signal despite the matching name string. A rebuild must keep the hand-written
  `provide_feedback` (§2.4) as the canonical one; the factory is for *additional* feedback axes.
- ⚠️ **GOTCHA-11 (`replace("provide_", ...)` is a substring replace):** `signal_name.replace`
  removes the **first** occurrence of the literal `"provide_"` anywhere in the string, not only
  a prefix. For names like `"provide_plan_feedback"` it yields base `"plan_feedback"` →
  attrs `plan_feedback_received` / `plan_feedback_comments` (which DO match the built-in plan
  vars). A rebuild MUST use a substring `.replace("provide_", "")`, not a prefix strip, to keep
  this coincidental match working.

---

## 5. What this mixin does NOT provide (so subclasses must)

- **No `run()` / `_execute()`** — orchestration lives in `LineWorkflowBase` and the line
  subclasses.
- **No queries** — `get_status` is defined in `LineWorkflowBase` (`base.py:1059-1071`), not here.
- **No gate signals** — `gate_approved` / `gate_rejected` / `escalation_resolved` / `merge_retry`
  are defined in `LineWorkflowBase` (`base.py:174-234`), NOT here. (See `_LineWorkflowBase.md`.)
- **No reset of `cancelled`** — one-way latch (GOTCHA-5).

---

## 6. Behavioral parity checklist

A rebuilt `HILSignalsMixin` MUST satisfy ALL of the following:

1. `__init__` calls `super().__init__()` as its **first** statement (GOTCHA-0), then sets
   exactly these eight attrs to these initial values: `approved=False`, `plan_approved=False`,
   `plan_feedback_received=False`, `plan_feedback_comments=""`, `document_approved=False`,
   `document_feedback_received=False`, `document_feedback_comments=""`, `cancelled=False`.
2. Exactly **six** `@workflow.signal` handlers exist, registered under the wire names
   `approve_plan`, `provide_plan_feedback`, `approve_research`, `provide_feedback`, `approve`,
   `cancel_workflow`. All are **synchronous** (`def`), perform only attribute writes, and never
   `await` / call `workflow.now()` / do I/O.
3. `approve_plan` sets `plan_approved=True`, `plan_feedback_received=False`,
   `plan_feedback_comments=""` (all three). `provide_plan_feedback(comments)` sets
   `plan_feedback_received=True`, `plan_feedback_comments=comments`, `plan_approved=False`
   (all three). (GOTCHA-2)
4. `approve_research` drives the **`document_*`** family (not `research_*`), setting
   `document_approved=True` and clearing both feedback fields. (GOTCHA-3)
5. `provide_feedback(comments)` drives the **`document_*`** family, setting
   `document_feedback_received=True`, `document_feedback_comments=comments`,
   `document_approved=False`. (GOTCHA-4)
6. `approve()` sets `approved=True` and nothing else. `cancel_workflow()` sets `cancelled=True`
   and nothing else; `cancelled` is never reset anywhere. (GOTCHA-5)
7. `reset_plan_feedback()` clears `plan_feedback_received` + `plan_feedback_comments` only (not
   `plan_approved`). `reset_document_feedback()` clears `document_feedback_received` +
   `document_feedback_comments` only (not `document_approved`). (GOTCHA-6) Neither is a signal.
8. `is_plan_decision_received()` returns `plan_approved or plan_feedback_received`.
   `is_document_decision_received()` returns `document_approved or document_feedback_received`.
   Neither ORs in `cancelled`. (GOTCHA-7) Neither is a signal.
9. `create_approval_signal(name)` returns a zero-arg signal that sets `setattr(self, P, True)`
   where `P = name + "d"` if `name` ends in `"e"` else `name + "ed"` (the literal, English-
   incorrect rule of GOTCHA-8). The returned signal's wire name is exactly `name`
   (`__name__` set before `workflow.signal`). (GOTCHA-9)
10. `create_feedback_signal(name)` returns a one-arg (`comments`) signal that sets
    `<base>_received=True` and `<base>_comments=comments` where
    `base = name.replace("provide_", "")` (substring replace, GOTCHA-11). The default
    `name="provide_feedback"` yields base `"feedback"` and does NOT match the built-in
    `provide_feedback` semantics (GOTCHA-10). Wire name is exactly `name`.
11. The class defines **no** query handlers, **no** update handlers, **no** gate signals, and
    **no** `run`/`_execute` — those belong to `LineWorkflowBase` and subclasses.
