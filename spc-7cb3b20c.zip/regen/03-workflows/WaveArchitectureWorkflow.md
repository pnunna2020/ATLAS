# `WaveArchitectureWorkflow` — Wave-grain Architecture coordinator (ATOMIC regeneration spec)

> **Source of truth:** `temporal/olympus_workflows/workflows/wave_architecture.py` (889 lines).
> Every `wave_architecture.py:line` citation below is against that file.
>
> **What this is:** a wave-grain coordinator that runs **once per wave** AFTER
> `WaveRationalizationWorkflow` clears G-DA (`wave_architecture.py:1-9`). It (1) dispatches the
> `target-state-mapper` skill at wave grain to emit the canonical
> `architecture/wave-{wave_id}/architecture-target-plan.json`, (2) commits it to artifact-repo
> `main`, (3) parks on a **pre-dispatch operator hold**, (4) re-reads the (possibly operator-edited)
> plan from git, (5) provisions one target app+repo per plan target **in parallel**, (6) spawns
> `ArchitectureWorkflow` + `DataWorkflow` children per provisioned target with
> `ParentClosePolicy.ABANDON`, then (7) hands off. (`wave_architecture.py:10-31`).
>
> ⚠️ **GOTCHA-STANDALONE (this workflow does NOT inherit `LineWorkflowBase` / `HILSignalsMixin`):**
> The class is declared `@workflow.defn class WaveArchitectureWorkflow:` with **no base class**
> (`wave_architecture.py:203-204`). Unlike the seven per-app line workflows specced in
> `_LineWorkflowBase.md`, this is a **standalone** workflow. Consequences a rebuild MUST honor:
> - There is **NO `self.cancelled`** flag, **NO `approve`/`cancel_workflow`/`approve_plan`/…** HIL
>   signals, **NO `gate_approved`/`gate_rejected`/`escalation_resolved`/`merge_retry`** signals.
>   Cancellation is handled exclusively by this workflow's own `cancel_all_children` signal +
>   `_cancel_all_children_requested` flag (`wave_architecture.py:239`, `828-861`).
> - There are **NO gates** in this workflow ("Does NOT own: gate signal bookkeeping (no gates run
>   here)" — `wave_architecture.py:210-211`). No `_wait_for_gate_decision`, no
>   `_reconcile_and_merge_with_retry_loop`, no rework loop, no `_rework_iterations`. Any reference
>   in this spec to gate/rework machinery is to state that it is **ABSENT**.
> - It re-implements its own `__init__` state, its own `_now_iso()`, its own `get_status` query,
>   and its own `_update_wave_status_safe`. None of these are inherited.
> - `_LineWorkflowBase.md` / `_HILSignalsMixin.md` are referenced here ONLY to contrast: this
>   workflow overrides nothing because it inherits nothing. The children it spawns
>   (`ArchitectureWorkflow`, `DataWorkflow`) DO inherit the base — but they run as separate
>   workflows and are out of scope here (started by `id` only, `wave_architecture.py:733-744`).
>
> **Determinism invariants:** activity imports gated behind
> `with workflow.unsafe.imports_passed_through():` (`wave_architecture.py:57`). The only time source
> is `_now_iso()` → `workflow.now().isoformat()` (`wave_architecture.py:155-156`) and
> `int(workflow.now().timestamp())` (`wave_architecture.py:476`) — both deterministic under replay.
> NO `datetime.now()`, NO `random`, NO wall-clock. There are **NO `workflow.patched(...)` patch
> gates** in this workflow (module docstring: "No patch gates. This is a brand-new workflow with no
> in-flight history to preserve." — `wave_architecture.py:42-43`).

---

## 0. Imports, constants, module helpers

### 0.1 Imports (`wave_architecture.py:48-93`)
- `asyncio`, `json`, `timedelta`, `typing.Any`, `temporalio.workflow` at top level.
- Inside `with workflow.unsafe.imports_passed_through():` (`wave_architecture.py:57`):
  - From `temporalio.exceptions`: `ActivityError`, `ApplicationError`.
  - Activities: `dispatch_agent_task`; `validate_artifact_against_schema`; `read_artifact`,
    `write_artifact`; `create_target_app_and_repo`, `fetch_application_source_repos`,
    `update_application_line_projection`; `update_wave_status`.
  - `RETRY_POLICIES`.
  - Types: `AgentTaskInput`, `AssemblyLine`, `CreateTargetAppAndRepoInput`,
    `CreateTargetAppAndRepoResult`, `DispatchTargetStatus`, `FetchSourceReposInput`,
    `LineWorkflowInput`, `PreDispatchConfirmedSignal`, `ReadArtifactInput`, `StepExecutionContext`,
    `UpdateApplicationLineProjectionInput`, `UpdateWaveStatusInput`, `ValidateArtifactInput`,
    `WaveArchitectureWorkflowInput`, `WorkflowStatus`, `WorkflowStatusResponse`,
    `WriteArtifactInput`.
- ⚠️ **GOTCHA-IMPORTS:** every activity + dataclass + `RETRY_POLICIES` MUST be inside
  `imports_passed_through()` so the Temporal sandbox doesn't re-import (and re-execute) them on
  replay. Same rule as the base (`_LineWorkflowBase.md` §0).
- ⚠️ **GOTCHA-ACTIVITYERR-LIVE:** the very last line `_ = ActivityError` (`wave_architecture.py:888`)
  exists ONLY to keep the `ActivityError` import alive (it is imported but not yet referenced in a
  `catch`) so follow-on commits can add catch sites "without re-touching the import block"
  (`wave_architecture.py:886-887`). A rebuild may import `ActivityError` and may include this keep-alive
  line; it has no runtime effect.

### 0.2 Constants (`wave_architecture.py:110-152`)
These define the mapper's input bundle and the relationship→disposition title-casing.

- `_SOURCE_DISCOVERY_ARTIFACT_NAMES: tuple[str, ...]` (`wave_architecture.py:110-120`) — 9 names, in
  this EXACT order: `"catalog.json"`, `"structural-analysis.json"`, `"business-logic.json"`,
  `"quality-risk.json"`, `"ux-accessibility.json"`, `"data-domains.json"`,
  `"shared-db-analysis.json"`, `"synthesis.json"`, `"tco-baseline.json"`.
- `_SOURCE_RATIONALIZATION_ARTIFACT_NAMES: tuple[str, ...]` (`wave_architecture.py:121-128`) — 6 names,
  in this EXACT order: `"disposition-recommendation.json"`, `"disposition-recommendation.md"`,
  `"classification.json"`, `"portfolio-score.json"`, `"intra-app-redundancy.json"`,
  `"disposition-governance.json"`.
- `_WAVE_SHARED_RATIONALIZATION_ARTIFACT_NAMES: tuple[str, ...]` (`wave_architecture.py:133-136`) —
  2 names: `"redundancy-matrix.json"`, `"ux-overlap-matrix.json"`. One copy per wave, not per app.
- `_TARGET_PLAN_FILENAME = "architecture-target-plan.json"` (`wave_architecture.py:138`).
- `_RELATIONSHIP_TO_DISPOSITION: dict[str, str]` (`wave_architecture.py:145-152`) — lowercase →
  Title-case:
  `{"replace":"Replace", "consolidate":"Consolidate", "refactor":"Refactor",
  "rearchitect":"Rearchitect", "replatform":"Replatform", "retain":"Retain"}`. **Note:** six keys
  — `"retire"` is intentionally ABSENT (Retire targets don't get provisioned by this path).

> ⚠️ **GOTCHA-CONST-DUP:** `_SOURCE_DISCOVERY_ARTIFACT_NAMES` / `_SOURCE_RATIONALIZATION_ARTIFACT_NAMES`
> are **deliberately replicated** here rather than imported from
> `activities/line_transitions._SOURCE_DISCOVERY_ARTIFACTS` / `_SOURCE_RATIONALIZATION_ARTIFACTS`
> (`wave_architecture.py:100-109`). The comment: importing the activity module into the workflow's
> safe-import set would drag DB + HTTP deps into the sandbox, and the tuples are derived at
> module-import time from the contract yaml. The two sides are the same source of truth and "must be
> updated together." A rebuild MUST reproduce these literal tuples (in order) inside the workflow
> module, NOT import them from the activity module.

### 0.3 Module helper functions (`wave_architecture.py:155-195`)

**`_now_iso() -> str`** (`wave_architecture.py:155-156`): `return workflow.now().isoformat()`.
Deterministic. Used everywhere a timestamp is stamped onto `_updated_at` / `_started_at`.

**`_plan_path(wave_id: str) -> str`** (`wave_architecture.py:159-160`):
`return f"architecture/wave-{wave_id}/{_TARGET_PLAN_FILENAME}"`. The canonical plan path on `main`.
⚠️ This SAME path is read by the pre-dispatch UI and overwritten by the API on operator confirm;
the workflow re-reads it after the hold (`wave_architecture.py:17-21`, `36-38`).

**`_build_input_artifacts(app_ids: list[str], wave_id: str) -> list[str]`**
(`wave_architecture.py:163-179`) — builds the mapper's input bundle. Structured pseudocode:
```text
out = []
for app_id in app_ids:                                 # wave_architecture.py:172  LOOP A
    for name in _SOURCE_DISCOVERY_ARTIFACT_NAMES:      # wave_architecture.py:173  LOOP B
        out.append(f"discovery/{app_id}/{name}")       # wave_architecture.py:174
    for name in _SOURCE_RATIONALIZATION_ARTIFACT_NAMES:# wave_architecture.py:175  LOOP C
        out.append(f"rationalization/wave-{wave_id}/{app_id}/{name}")   # wave_architecture.py:176
for name in _WAVE_SHARED_RATIONALIZATION_ARTIFACT_NAMES:# wave_architecture.py:177  LOOP D
    out.append(f"rationalization/wave-{wave_id}/{name}")# wave_architecture.py:178
return out
```
> ⚠️ **GOTCHA-BUNDLE-ORDER:** order is **per-app-grouped** (all of app A's Discovery, then app A's
> Rationalization, then app B's…) followed by the two wave-shared artifacts LAST. The comment
> (`wave_architecture.py:167-169`) says this keeps related-source files adjacent which "empirically
> improves synthesis." A rebuild MUST preserve this exact ordering — the agent prompt order is
> behaviorally load-bearing for synthesis quality (and for any test asserting the artifact list).
> Per-app path templates: Discovery = `discovery/{app_id}/{name}`; per-app Rationalization =
> `rationalization/wave-{wave_id}/{app_id}/{name}`; wave-shared = `rationalization/wave-{wave_id}/{name}`.

**`_disposition_from_relationship(relationship: str) -> str`** (`wave_architecture.py:182-195`):
```text
rel = (relationship or "").strip().lower()             # wave_architecture.py:189
if rel not in _RELATIONSHIP_TO_DISPOSITION:            # wave_architecture.py:190  BRANCH
    raise ApplicationError(                            # wave_architecture.py:191-194
        f"unknown relationship {relationship!r} in plan target",
        non_retryable=True,
    )
return _RELATIONSHIP_TO_DISPOSITION[rel]               # wave_architecture.py:195
```
> ⚠️ **GOTCHA-REL-NORMALIZE:** the input is normalized with `(relationship or "").strip().lower()`
> — handles `None`, whitespace, and mixed case. An unknown relationship raises a **non-retryable**
> `ApplicationError` (`wave_architecture.py:191-194`). The docstring notes the plan schema already
> enforces the six-value enum at validation time, so a miss here means "we drifted from the schema."
> This helper is called from `_init_dispatch_status` (`wave_architecture.py:595-597`) — so a bad
> relationship raises while seeding per-target status, which propagates up through
> `_provision_and_spawn` → `run`'s `except ApplicationError` (see §4). A rebuild must raise
> non-retryable here, not silently default.

---

## 1. STATE — every instance var (`__init__`, `wave_architecture.py:215-240`)

`__init__` takes no input; all vars are set to defaults and hydrated in `run()`. **No
`super().__init__()` call** (standalone class — GOTCHA-STANDALONE).

| Var | Type | Initial | Line | Mutated by → value | When |
|-----|------|---------|------|---------------------|------|
| `_wave_id` | `str` | `""` | 216 | `run` ← `input.wave_id` (`wave_architecture.py:261`) | run start |
| `_portfolio_id` | `str` | `""` | 217 | `run` ← `input.portfolio_id` (`wave_architecture.py:262`) | run start |
| `_artifact_repo` | `str` | `""` | 218 | `run` ← `input.artifact_repo` (`wave_architecture.py:263`) | run start |
| `_status` | `WorkflowStatus` | `PENDING` | 219 | `run` → `RUNNING` (264); `→ CANCELLED` (286); `→ COMPLETED`/`FAILED` (294-298); `except` → `FAILED` (303,312); `cancel_all_children` → `CANCELLED` (859) | run lifecycle |
| `_current_step` | `str` | `""` | 220 | many — see §2.x: `"wave-target-state-mapping"`, `"awaiting-architecture-dispatch"`, `"architecture-in-flight"`, `outcome`, `"cancelled"`, `"failed"` | each phase |
| `_progress_pct` | `float` | `0.0` | 221 | `5.0` (342); `30.0` (430); `50.0` (460/544); `100.0` (550) | each phase |
| `_started_at` | `str` | `""` | 222 | `run` → `_now_iso()` (265) | run start |
| `_updated_at` | `str` | `""` | 223 | bumped to `_now_iso()` at almost every state change | many |
| `_pre_dispatch_confirmed` | `bool` | `False` | 226 | `pre_dispatch_confirmed` signal → `True` (824) | operator confirm |
| `_pre_dispatch_confirmed_by` | `str` | `""` | 227 | `pre_dispatch_confirmed` signal → `signal.confirmed_by` (825) | operator confirm |
| `_dispatch_status` | `dict[str, DispatchTargetStatus]` | `{}` | 233 | `_init_dispatch_status` seeds (590); per-target mutated in place (493,503,515,617,769-772) | post plan-read → spawn |
| `_cancel_all_children_requested` | `bool` | `False` | 239 | `cancel_all_children` signal → `True` (837) | operator abort |
| `_child_handles` | `list[tuple[str, Any]]` | `[]` | 240 | `_provision_and_spawn` appends `(handle.id, handle)` pairs (508-513); `cancel_all_children` clears to `[]` (858) | spawn / cancel |

> ⚠️ **GOTCHA-STATE-DISPATCH-KEY:** `_dispatch_status` is keyed by `target_app_id` (from the plan),
> NOT by `source_app_id` (`wave_architecture.py:229-233`, `576-580`). The comment explains the
> capability-grain rationalization case where N targets share a source anchor — keying by target
> avoids collisions. A rebuild MUST key by `target_app_id`.
> ⚠️ **GOTCHA-STATE-CHILD-HANDLES-TUPLE:** `_child_handles` is a list of `(child_id_str, handle)`
> tuples (`wave_architecture.py:240`). The string id is stored alongside the handle so
> `cancel_all_children` can log the id even after `handle.cancel()` (`wave_architecture.py:839-857`).
> ⚠️ **GOTCHA-STATE-NO-CANCELLED-FLAG:** there is NO `cancelled` bool. The kill switch is
> `_cancel_all_children_requested`. It is checked in the pre-dispatch `wait_condition`
> (`wave_architecture.py:442-447`) and immediately after the hold returns (`wave_architecture.py:285`).
> It is NOT a one-way latch consumed by every wait — there is only one wait that consumes it
> (the pre-dispatch hold). See GOTCHA-CANCEL-WINDOW.

---

## 2. SIGNALS & QUERIES

### 2.1 `pre_dispatch_confirmed(self, signal: PreDispatchConfirmedSignal) -> None` — SIGNAL `wave_architecture.py:812-826`
`@workflow.signal`, **`async def`**. Payload `PreDispatchConfirmedSignal` (field: `confirmed_by:
str = ""`). Sent by the API after it has already overwritten the plan on artifact-repo `main`
(`wave_architecture.py:816-821`).
```text
async def pre_dispatch_confirmed(self, signal):
    if isinstance(signal, dict):                       # wave_architecture.py:822  BRANCH
        signal = PreDispatchConfirmedSignal(**signal)  # wave_architecture.py:823
    self._pre_dispatch_confirmed = True                # wave_architecture.py:824
    self._pre_dispatch_confirmed_by = signal.confirmed_by  # wave_architecture.py:825
    self._updated_at = _now_iso()                      # wave_architecture.py:826
```
- **One branch:** `if isinstance(signal, dict): signal = PreDispatchConfirmedSignal(**signal)`
  (`wave_architecture.py:822-823`) — coerces a dict-shaped payload (Temporal may deliver the signal
  as a dict depending on the data converter) into the dataclass.
- **Consumed by** `_await_pre_dispatch_confirmation`'s wait_condition predicate
  `self._pre_dispatch_confirmed or self._cancel_all_children_requested`
  (`wave_architecture.py:442-447`).
- ⚠️ **GOTCHA-SIG-PDC-DICT-COERCE:** the `isinstance(signal, dict)` coercion MUST be reproduced — a
  rebuild that types the param as the dataclass but receives a dict (raw JSON converter) would crash
  reading `signal.confirmed_by`. The SAME coercion appears in `run()` for the workflow input
  (`wave_architecture.py:258-259`).
- ⚠️ **GOTCHA-SIG-PDC-GIT-NOT-PAYLOAD:** the signal payload carries ONLY `confirmed_by` — it does
  NOT carry the plan. The plan source-of-truth is git: the API overwrote
  `architecture/wave-{wave_id}/architecture-target-plan.json` on `main` BEFORE sending the signal,
  and the workflow re-reads from git on the next step (`_read_plan_from_git`,
  `wave_architecture.py:554-573`). This is the central design invariant ("Plan source-of-truth is
  git, not the in-memory dispatch payload" — `wave_architecture.py:36-38`). A rebuild MUST re-read
  the plan from git after this signal, never trust an in-memory payload.

### 2.2 `cancel_all_children(self) -> None` — SIGNAL `wave_architecture.py:828-861`
`@workflow.signal`, **`async def`**, no payload. Aborts the coordinator and best-effort cancels any
spawned children.
```text
async def cancel_all_children(self):
    self._cancel_all_children_requested = True         # wave_architecture.py:837
    self._updated_at = _now_iso()                      # wave_architecture.py:838
    for child_id, handle in self._child_handles:       # wave_architecture.py:839  LOOP
        try:
            await handle.cancel()                      # wave_architecture.py:841
            workflow.logger.info(                      # wave_architecture.py:842-848
                "wave_architecture.cancel_all_children.cancelled_child",
                extra={"wave_id": self._wave_id, "child_workflow_id": child_id})
        except Exception as exc:                       # wave_architecture.py:849  BRANCH (best-effort)
            workflow.logger.warning(                   # wave_architecture.py:850-857
                "wave_architecture.cancel_all_children.child_cancel_failed",
                extra={"wave_id": self._wave_id, "child_workflow_id": child_id,
                       "error": str(exc)})
    self._child_handles = []                           # wave_architecture.py:858
    self._status = WorkflowStatus.CANCELLED            # wave_architecture.py:859
    self._current_step = "cancelled"                   # wave_architecture.py:860
```
- **Branches:** the `for child_id, handle in self._child_handles` loop (`wave_architecture.py:839`)
  and its inner `try / except Exception` (`wave_architecture.py:840-857`).
- ⚠️ **GOTCHA-SIG-CANCEL-BEST-EFFORT:** each `handle.cancel()` is wrapped in try/except because a
  child that has ALREADY COMPLETED raises on cancel; the handler swallows and continues
  (`wave_architecture.py:830-836`, `849-857`). Children are `ABANDON` (see §5.3) so cancellation
  here is genuinely best-effort. A rebuild MUST swallow per-child cancel failures, not abort the loop.
- ⚠️ **GOTCHA-SIG-CANCEL-CLEARS-HANDLES:** after the loop, `_child_handles` is reset to `[]`
  (`wave_architecture.py:858`). A second `cancel_all_children` would then iterate an empty list (no
  double-cancel). A rebuild must clear the list after cancelling.
- ⚠️ **GOTCHA-SIG-CANCEL-SETS-STATUS-IN-HANDLER:** this handler itself sets `_status = CANCELLED`
  and `_current_step = "cancelled"` (`wave_architecture.py:859-860`). This is in addition to `run()`
  setting the same on the post-hold cancel path (`wave_architecture.py:285-289`). So if the signal
  fires during the gather window, the handler stamps CANCELLED even though `run()` may still return a
  non-`"cancelled"` outcome string (see GOTCHA-CANCEL-WINDOW). A rebuild must reproduce both writes.
- ⚠️ **GOTCHA-SIG-CANCEL-NOT-A-WAIT-DRAIN:** unlike the base's `self.cancelled` (which is OR'd into
  EVERY base `wait_condition`), `_cancel_all_children_requested` is consumed by ONLY ONE wait — the
  pre-dispatch hold (`wave_architecture.py:442-447`). There is no other blocking `wait_condition` in
  this workflow (the gather in §3 step 3 is an `asyncio.gather`, NOT a `wait_condition`). So cancel
  has guaranteed effect ONLY during the pre-dispatch hold. During provisioning/gather it sets state
  + cancels handles but does not interrupt the running `asyncio.gather`. (See GOTCHA-CANCEL-WINDOW.)

### 2.3 `dispatch_results(self) -> list[DispatchTargetStatus]` — QUERY `wave_architecture.py:866-870`
`@workflow.query`, synchronous, read-only.
```text
def dispatch_results(self):
    return list(self._dispatch_status.values())        # wave_architecture.py:870
```
Powers the wave-page progress table and the partial-failure retry affordance
(`wave_architecture.py:867-869`). Returns a **list copy** of the dict values (stable snapshot order
= insertion order = plan target order). During the hold the dict is empty (seeded only after plan
read in `_provision_and_spawn`) — so this query returns `[]` until provisioning begins.

### 2.4 `get_status(self) -> WorkflowStatusResponse` — QUERY `wave_architecture.py:872-883`
`@workflow.query`, synchronous, read-only. **This is a fresh implementation, NOT the inherited base
`get_status`** (standalone class).
```text
def get_status(self):
    return WorkflowStatusResponse(
        workflow_id=workflow.info().workflow_id,       # wave_architecture.py:875
        status=self._status,
        current_line=AssemblyLine.ARCHITECTURE,        # wave_architecture.py:877  hardcoded
        current_step=self._current_step,
        progress_pct=self._progress_pct,
        pending_gate=None,                             # wave_architecture.py:880  always None (no gates)
        started_at=self._started_at,
        updated_at=self._updated_at,
    )
```
- ⚠️ **GOTCHA-Q-LINE-HARDCODED:** `current_line` is hardcoded to `AssemblyLine.ARCHITECTURE`
  (`wave_architecture.py:877`), and `pending_gate` is ALWAYS `None` (`wave_architecture.py:880`)
  because this workflow runs no gates. A rebuild must hardcode both.
- ⚠️ **GOTCHA-Q-NO-DECORATOR-CLASH:** because the class is standalone, there is no inherited
  `get_status` to clash with. A rebuild defines `get_status` and `dispatch_results` directly on the
  class. (Contrast GOTCHA-Q1 in `_LineWorkflowBase.md` which forbids subclasses from redefining
  `get_status` — that rule does NOT apply here because this is not a subclass.)

> **There are NO update handlers** (`@workflow.update`) and NO other signals/queries. The full
> signal/query surface is exactly: signals `pre_dispatch_confirmed`, `cancel_all_children`; queries
> `dispatch_results`, `get_status`.

---

## 3. CONTROL FLOW — `run()` (`wave_architecture.py:246-323`)

`@workflow.run async def run(self, input: WaveArchitectureWorkflowInput) -> str`. Returns one of
four strings: `"completed"`, `"failed"` (via raised exception — see below), `"stuck-awaiting-recovery"`,
`"cancelled"` (`wave_architecture.py:250-257`).

```text
async def run(self, input):
    if isinstance(input, dict):                                  # wave_architecture.py:258  BRANCH 1
        input = WaveArchitectureWorkflowInput(**input)           # wave_architecture.py:259

    self._wave_id       = input.wave_id                          # wave_architecture.py:261
    self._portfolio_id  = input.portfolio_id                     # wave_architecture.py:262
    self._artifact_repo = input.artifact_repo                    # wave_architecture.py:263
    self._status        = WorkflowStatus.RUNNING                 # wave_architecture.py:264
    self._started_at    = _now_iso()                             # wave_architecture.py:265
    self._updated_at    = self._started_at                       # wave_architecture.py:266

    if not input.app_ids:                                        # wave_architecture.py:268  BRANCH 2
        raise ApplicationError(                                  # wave_architecture.py:269-272
            "WaveArchitectureWorkflow requires at least one app_id",
            non_retryable=True)
    if not input.artifact_repo:                                  # wave_architecture.py:273  BRANCH 3
        raise ApplicationError(                                  # wave_architecture.py:274-277
            "WaveArchitectureWorkflow requires artifact_repo",
            non_retryable=True)

    try:                                                         # wave_architecture.py:279
        # Step 1 — wave-grain target-state-mapping.
        await self._dispatch_wave_target_state_mapper(input)     # wave_architecture.py:281

        # Step 2 — pre-dispatch hold.
        await self._await_pre_dispatch_confirmation()            # wave_architecture.py:284
        if self._cancel_all_children_requested:                  # wave_architecture.py:285  BRANCH 4
            self._status       = WorkflowStatus.CANCELLED        # wave_architecture.py:286
            self._current_step = "cancelled"                     # wave_architecture.py:287
            self._updated_at   = _now_iso()                      # wave_architecture.py:288
            return "cancelled"                                   # wave_architecture.py:289

        # Step 3 + 4 — provision and spawn.
        outcome = await self._provision_and_spawn(input)         # wave_architecture.py:292

        self._status = (                                         # wave_architecture.py:294-298  BRANCH 5
            WorkflowStatus.COMPLETED
            if outcome == "completed"
            else WorkflowStatus.FAILED)
        self._current_step = outcome                             # wave_architecture.py:299
        self._updated_at   = _now_iso()                          # wave_architecture.py:300
        return outcome                                           # wave_architecture.py:301

    except ApplicationError:                                     # wave_architecture.py:302  BRANCH 6
        self._status       = WorkflowStatus.FAILED               # wave_architecture.py:303
        self._current_step = "failed"                            # wave_architecture.py:304
        self._updated_at   = _now_iso()                          # wave_architecture.py:305
        await self._update_wave_status_safe(                     # wave_architecture.py:306-309
            "stuck-awaiting-recovery",
            reason="wave_architecture coordinator failed")
        raise                                                    # wave_architecture.py:310  ← re-raise

    except Exception as exc:                                     # wave_architecture.py:311  BRANCH 7
        self._status       = WorkflowStatus.FAILED               # wave_architecture.py:312
        self._current_step = "failed"                            # wave_architecture.py:313
        self._updated_at   = _now_iso()                          # wave_architecture.py:314
        workflow.logger.error(                                   # wave_architecture.py:315-318
            "wave_architecture.run failed",
            extra={"wave_id": self._wave_id, "error": repr(exc)})
        await self._update_wave_status_safe(                     # wave_architecture.py:319-322
            "stuck-awaiting-recovery",
            reason=f"wave_architecture: {exc!r}"[:500])
        raise                                                    # wave_architecture.py:323  ← re-raise
```

**`run()` branch inventory (7):**
1. `if isinstance(input, dict)` (258) — dict→dataclass coercion.
2. `if not input.app_ids: raise` (268) — non-retryable guard.
3. `if not input.artifact_repo: raise` (273) — non-retryable guard.
4. `if self._cancel_all_children_requested:` after the hold (285) — early cancel return `"cancelled"`.
5. The `outcome == "completed" ? COMPLETED : FAILED` ternary (294-298) selecting terminal status.
6. `except ApplicationError:` (302) — set FAILED, push `stuck-awaiting-recovery` wave status, **re-raise**.
7. `except Exception:` (311) — set FAILED, log, push `stuck-awaiting-recovery` wave status, **re-raise**.

> ⚠️ **GOTCHA-RUN-RETURN-vs-RAISE:** the four documented return strings (`wave_architecture.py:250-257`)
> are NOT all reachable as return values. `"completed"` and `"stuck-awaiting-recovery"` are returned
> by `_provision_and_spawn` and become `run`'s return value (301). `"cancelled"` is returned at 289.
> But `"failed"` is NEVER returned — both `except` blocks set `_current_step="failed"` then
> **re-raise** (310, 323), so the workflow FAILS (Temporal records a failed execution) rather than
> returning `"failed"`. A rebuild MUST re-raise in both `except` blocks; do not convert them to a
> `return "failed"`. (The status string `"failed"` is observable only via the `get_status` query /
> `_current_step`, not via the workflow result.)
> ⚠️ **GOTCHA-RUN-OUTCOME-FAILED:** when `_provision_and_spawn` returns `"stuck-awaiting-recovery"`
> (every target failed to provision/spawn), the ternary at 294-298 maps it to
> `WorkflowStatus.FAILED` (because it isn't `"completed"`), and `run` RETURNS the string
> `"stuck-awaiting-recovery"` (301). So the workflow COMPLETES (does not fail) with result
> `"stuck-awaiting-recovery"` but reports `_status=FAILED`. This is intentional: the plan is
> committed, no work is in flight, and the operator can `/resume`. A rebuild must distinguish this
> (clean completion with a stuck-marker result + FAILED status) from the `except` paths (Temporal
> failure). The `_update_wave_status_safe("stuck-awaiting-recovery", …)` call for THIS path happens
> INSIDE `_provision_and_spawn` (`wave_architecture.py:540-543`), NOT in `run`'s except block.
> ⚠️ **GOTCHA-RUN-EXCEPT-ORDER:** `except ApplicationError` (302) is listed BEFORE the broad
> `except Exception` (311). Order matters: `ApplicationError` is a subclass of `Exception`, so the
> narrower handler must come first or the broad one would shadow it. The two handlers differ ONLY in
> the `reason` string passed to `_update_wave_status_safe` (the ApplicationError path uses a fixed
> `"wave_architecture coordinator failed"` and does NOT log; the broad path logs an error and uses
> `f"wave_architecture: {exc!r}"[:500]`). A rebuild MUST keep both handlers in this order with these
> distinct reasons; both re-raise.
> ⚠️ **GOTCHA-RUN-REASON-TRUNCATE:** the broad-except reason is truncated to 500 chars via
> `[:500]` (`wave_architecture.py:322`) so the wave row doesn't grow an unbounded error string. A
> rebuild must truncate.
> ⚠️ **GOTCHA-RUN-INPUT-HYDRATION-ORDER:** the input fields are hydrated onto state (261-263) and
> `_status=RUNNING`/`_started_at` set (264-266) BEFORE the two `not input.*` guards (268, 273). So
> if `app_ids` is empty, the workflow has already stamped `_status=RUNNING`/`_started_at` before
> raising — but because `__init__` already ran and these are pre-`try` raises, the guards raise an
> `ApplicationError` that is NOT caught by the `try/except` (the `try` starts at 279, after the
> guards). The guard `ApplicationError`s therefore propagate directly and fail the workflow WITHOUT
> the `stuck-awaiting-recovery` wave-status push. A rebuild must place the guards before the `try`
> so they bypass the recovery-status side effect.

---

### 3.1 Step 1 — `_dispatch_wave_target_state_mapper(self, input)` (`wave_architecture.py:329-431`)

Runs `target-state-mapper` at wave grain, validates the emitted plan strictly, commits it to `main`.

```text
async def _dispatch_wave_target_state_mapper(self, input):
    self._current_step = "wave-target-state-mapping"             # wave_architecture.py:341
    self._progress_pct = 5.0                                     # wave_architecture.py:342
    self._updated_at   = _now_iso()                              # wave_architecture.py:343

    input_artifacts = _build_input_artifacts(input.app_ids, input.wave_id)   # wave_architecture.py:345
    execution_ctx = StepExecutionContext(                        # wave_architecture.py:346-352
        portfolio_id=input.portfolio_id,
        line_id="Architecture",                                  # ⚠ literal "Architecture", see GOTCHA
        step_id="wave-target-state-mapping",
        wave_id=input.wave_id,
        input_artifact_paths=list(input_artifacts))

    task_input = AgentTaskInput(                                 # wave_architecture.py:355-366
        task_type="wave-target-state-mapping",
        app_id="",                                               # ⚠ empty — wave-scoped dispatch
        wave_id=input.wave_id,
        skill_id="target-state-mapper",
        input_artifacts=input_artifacts,
        artifact_repo=input.artifact_repo,
        model_preference="tier-2",                               # ⚠ Sonnet 1M (synthesis-class)
        workspace_key=f"wave-architecture-{input.wave_id}",
        context={"wave_name": input.wave_name},
        execution_context=execution_ctx)

    result = await workflow.execute_activity(                    # wave_architecture.py:367-374
        dispatch_agent_task, task_input,
        start_to_close_timeout=timedelta(minutes=30),            # wave_architecture.py:370
        heartbeat_timeout=timedelta(minutes=2),                  # wave_architecture.py:371
        retry_policy=RETRY_POLICIES["agent_failure"],            # wave_architecture.py:372  3 attempts
        activity_id=f"agent-wave-target-state-mapping-{input.wave_id}")   # wave_architecture.py:373

    # Locate the plan in output_files.
    plan_file = next(                                            # wave_architecture.py:379-385
        (f for f in (result.output_files or [])
         if f.path.endswith(_TARGET_PLAN_FILENAME)),
        None)
    if plan_file is None:                                        # wave_architecture.py:386  BRANCH 1
        raise ApplicationError(                                  # wave_architecture.py:387-390
            f"target-state-mapper did not emit {_TARGET_PLAN_FILENAME}",
            non_retryable=True)

    # Strict schema validation.
    validation = await workflow.execute_activity(                # wave_architecture.py:393-401
        validate_artifact_against_schema,
        ValidateArtifactInput(
            artifact_filename=_TARGET_PLAN_FILENAME,
            raw_content=plan_file.content),
        start_to_close_timeout=timedelta(seconds=30),            # wave_architecture.py:399
        retry_policy=RETRY_POLICIES["validation_failure"])       # wave_architecture.py:400  1 attempt
    if not validation.validated or validation.errors:           # wave_architecture.py:402  BRANCH 2
        errors_preview = "; ".join(validation.errors[:4])        # wave_architecture.py:403
        raise ApplicationError(                                  # wave_architecture.py:404-407
            f"wave plan failed schema validation: {errors_preview}",
            non_retryable=True)

    # Commit the plan to artifact-repo main.
    await workflow.execute_activity(                             # wave_architecture.py:412-429
        write_artifact,
        WriteArtifactInput(
            repo=input.artifact_repo,
            branch="main",
            path=_plan_path(input.wave_id),
            content=plan_file.content,
            commit_message=(                                     # wave_architecture.py:419-423
                f"Wave {input.wave_id}: architecture target plan "
                f"({len(validation.parsed_payload.get('targets', []) if validation.parsed_payload else [])}"
                f" targets)"),
            execution_context=execution_ctx),
        start_to_close_timeout=timedelta(seconds=60),            # wave_architecture.py:426
        retry_policy=RETRY_POLICIES["transient"],                # wave_architecture.py:427  3 attempts
        activity_id=f"commit-target-plan-{input.wave_id}")       # wave_architecture.py:428
    self._progress_pct = 30.0                                    # wave_architecture.py:430
    self._updated_at   = _now_iso()                              # wave_architecture.py:431
```

**Step-1 branch inventory (2):** `if plan_file is None: raise` (386); `if not validation.validated
or validation.errors: raise` (402).

**Step-1 activity calls (in order, all SEQUENTIAL):**
1. `dispatch_agent_task` — `task_input`; **30 min** start_to_close; **2 min** heartbeat;
   `agent_failure` (3 attempts, 5-60s backoff); `activity_id="agent-wave-target-state-mapping-{wave_id}"`.
2. `validate_artifact_against_schema` — `ValidateArtifactInput(artifact_filename="architecture-target-plan.json",
   raw_content=plan_file.content)`; **30s**; **`validation_failure`** (max 1 attempt — NO retry).
3. `write_artifact` — `WriteArtifactInput(repo, branch="main", path=_plan_path(wave_id),
   content=plan_file.content, commit_message=…, execution_context)`; **60s**; `transient` (3 attempts);
   `activity_id="commit-target-plan-{wave_id}"`.

> ⚠️ **GOTCHA-S1-WAVE-SCOPE:** the dispatch sets `app_id=""` AND `wave_id=<uuid>`
> (`wave_architecture.py:357-358`). The comment (`wave_architecture.py:353-354`) notes this is the
> "exactly-one scope rule enforced by `agent_task_application_or_wave_ck`" — the DB CHECK constraint
> requires exactly one of app_id/wave_id populated. A rebuild MUST set `app_id=""` and the wave_id;
> setting both (or neither) violates the constraint and the dispatch's row insert fails.
> ⚠️ **GOTCHA-S1-TIER2:** `model_preference="tier-2"` (`wave_architecture.py:362`) drops to Sonnet
> 1M because "Opus 4.7 1M soft-fails on the largest synthesis prompts at >50% rate"
> (`wave_architecture.py:337-339`). This is a synthesis-class step. A rebuild must request tier-2.
> ⚠️ **GOTCHA-S1-HEARTBEAT:** this is the ONLY activity in the workflow with a `heartbeat_timeout`
> (2 min, `wave_architecture.py:371`). The 30-min start_to_close is long enough that a hung agent
> would otherwise sit idle; the heartbeat catches a stalled-but-not-crashed runtime sooner. The
> `dispatch_agent_task` activity is expected to heartbeat. A rebuild must set both
> `start_to_close_timeout=30min` AND `heartbeat_timeout=2min` on this call.
> ⚠️ **GOTCHA-S1-EXECCTX-LINE-ID-LITERAL:** `execution_ctx.line_id` is the LITERAL string
> `"Architecture"` (`wave_architecture.py:348`), NOT the kebab `"architecture"` the base produces
> via `LINE_LABEL.lower().replace(" ","-")`. Because this workflow doesn't inherit `_execution_ctx`,
> it builds `StepExecutionContext` by hand and passes `line_id="Architecture"` verbatim. The
> docstring on `StepExecutionContext` notes "the activity binds it … the envelope writer accepts
> both forms" — but the canonical emitted form here is the title-cased `"Architecture"`. A rebuild
> must use the literal `"Architecture"` to match. The SAME `execution_ctx` object is reused for both
> the dispatch and the `write_artifact` commit (`wave_architecture.py:352`, `366`, `424`).
> ⚠️ **GOTCHA-S1-PLAN-LOCATE-SUFFIX:** the plan file is located by `f.path.endswith(_TARGET_PLAN_FILENAME)`
> over `result.output_files or []` (`wave_architecture.py:379-385`), taking the FIRST match (or
> `None`). The skill is documented to emit exactly one `architecture-target-plan.json`
> (`wave_architecture.py:376-378`). If none is found → non-retryable raise (386). A rebuild must
> match by suffix (`endswith`), tolerate a `None`/empty `output_files`, and fail loud on no match.
> ⚠️ **GOTCHA-S1-VALIDATION-STRICT-FAIL:** validation uses `validation_failure` policy (max 1
> attempt — `retry_policies.py:50-52`) and the workflow **strict-fails** (non-retryable
> `ApplicationError`) if `not validation.validated OR validation.errors` (`wave_architecture.py:402`).
> Note the `OR`: even if `validated` is somehow True, a non-empty `errors` list still fails. The
> docstring (`wave_architecture.py:39-41`): "If the agent's plan doesn't conform, the workflow raises
> NonRetryableError rather than silently committing a bad plan." `errors[:4]` previews the first 4
> errors. A rebuild MUST NOT commit a plan that fails validation, and MUST use the no-retry policy
> on the validation activity (retrying a deterministic schema failure is pointless).
> ⚠️ **GOTCHA-S1-COMMIT-MESSAGE-COUNT:** the commit message embeds the target count via
> `len(validation.parsed_payload.get('targets', []) if validation.parsed_payload else [])`
> (`wave_architecture.py:421`). Parse carefully: the conditional `parsed_payload.get('targets', [])
> if parsed_payload else []` evaluates to the targets list (or `[]` when `parsed_payload` is None),
> and `len(...)` counts it. So a None payload yields `len([]) == 0`. A rebuild must reproduce this
> exact count expression in the commit message (it is observable in git history).
> ⚠️ **GOTCHA-S1-COMMIT-CONTENT-IS-AGENT-RAW:** the committed content is `plan_file.content` — the
> RAW agent output (`wave_architecture.py:417`), the same bytes that were validated. It is NOT
> re-serialized from `parsed_payload`. So the committed file is byte-identical to what the agent
> produced (markdown fences would already have been stripped by the validator's `parse_agent_json`
> per the `ValidateArtifactInput` docstring — but the COMMIT writes `plan_file.content`, the
> pre-strip raw). A rebuild MUST commit `plan_file.content` verbatim, not a re-serialization.
> ⚠️ **GOTCHA-S1-PROGRESS:** progress goes 5.0 at step entry (342) → 30.0 after commit (430). A
> rebuild must set these exact values for the `get_status` query.

---

### 3.2 Step 2 — `_await_pre_dispatch_confirmation(self)` (`wave_architecture.py:437-447`)

The pre-dispatch operator hold.
```text
async def _await_pre_dispatch_confirmation(self):
    self._current_step = "awaiting-architecture-dispatch"        # wave_architecture.py:439
    self._updated_at   = _now_iso()                              # wave_architecture.py:440
    await self._update_wave_status_safe("awaiting-architecture-dispatch")   # wave_architecture.py:441
    await workflow.wait_condition(                               # wave_architecture.py:442-447
        lambda: (self._pre_dispatch_confirmed
                 or self._cancel_all_children_requested))
```
- Sets `_current_step="awaiting-architecture-dispatch"`, best-effort flips `wave.status` to the same
  value, then BLOCKS on the wait_condition.
- ★ **The wait_condition predicate** (`wave_architecture.py:443-446`):
  `self._pre_dispatch_confirmed or self._cancel_all_children_requested`. Returns when EITHER the
  operator confirmed (via `pre_dispatch_confirmed` signal) OR requested cancel (via
  `cancel_all_children` signal).
- Does NOT set `_progress_pct` (stays at 30.0 from step 1).
> ⚠️ **GOTCHA-S2-WAIT-PREDICATE-EXACT:** the predicate is EXACTLY
> `_pre_dispatch_confirmed or _cancel_all_children_requested` — no timeout, no SLA timer. The hold
> is indefinite until one of the two signals lands. A rebuild MUST OR both flags into the predicate;
> omitting `_cancel_all_children_requested` would make the workflow uncancellable during the hold.
> ⚠️ **GOTCHA-S2-NO-RESET:** `_pre_dispatch_confirmed` is set once (by the signal) and never reset.
> There is no rework loop here, so it does not need resetting. A rebuild must not reset it.
> ⚠️ **GOTCHA-S2-STATUS-BEST-EFFORT:** the wave-status flip is via `_update_wave_status_safe` (never
> raises — see §3.5). If the DB write fails, the hold still proceeds. A rebuild must use the safe
> wrapper, not a raising activity call.

After the hold returns, control goes back to `run()` which checks
`if self._cancel_all_children_requested:` (`wave_architecture.py:285`) and returns `"cancelled"` if
set (BRANCH 4 in §3).

---

### 3.3 Steps 3 + 4 — `_provision_and_spawn(self, input) -> str` (`wave_architecture.py:453-552`)

Re-reads the (possibly edited) plan, provisions targets in parallel, spawns children, returns an
outcome string (`"completed"` or `"stuck-awaiting-recovery"`).

```text
async def _provision_and_spawn(self, input):
    self._current_step = "architecture-in-flight"               # wave_architecture.py:459
    self._progress_pct = 50.0                                   # wave_architecture.py:460
    self._updated_at   = _now_iso()                             # wave_architecture.py:461
    await self._update_wave_status_safe("architecture-in-flight")   # wave_architecture.py:462

    plan = await self._read_plan_from_git()                     # wave_architecture.py:464
    targets = plan.get("targets") or []                         # wave_architecture.py:465
    if not isinstance(targets, list) or not targets:            # wave_architecture.py:466  BRANCH 1
        raise ApplicationError(                                 # wave_architecture.py:469-472
            "architecture-target-plan.json on main has no targets",
            non_retryable=True)

    self._init_dispatch_status(targets)                         # wave_architecture.py:474

    run_ts = int(workflow.now().timestamp())                    # wave_architecture.py:476  deterministic

    # Provision in parallel.
    provision_futures = [                                       # wave_architecture.py:480-482
        self._provision_one_target(t, input) for t in targets]
    provisioned = await asyncio.gather(                         # wave_architecture.py:483-485
        *provision_futures, return_exceptions=True)             # ⚠ return_exceptions=True

    for plan_target, result in zip(targets, provisioned):       # wave_architecture.py:487  LOOP
        target_app_id = plan_target.get("target_app_id") or ""  # wave_architecture.py:488
        status = self._dispatch_status.get(target_app_id)       # wave_architecture.py:489
        if status is None:                                      # wave_architecture.py:490  BRANCH 2
            continue                                            # wave_architecture.py:491  ← skip
        if isinstance(result, BaseException):                   # wave_architecture.py:492  BRANCH 3
            status.status = "failed"                            # wave_architecture.py:493
            status.error  = repr(result)                        # wave_architecture.py:494
            workflow.logger.warning(                            # wave_architecture.py:495-501
                "create_target_app_and_repo failed",
                extra={"target_app_id": target_app_id, "error": repr(result)})
            continue                                            # wave_architecture.py:502  ← skip spawn
        status.status = "provisioned"                           # wave_architecture.py:503
        try:
            arch_handle, data_handle = await self._spawn_children_for_target(   # wave_architecture.py:505-507
                plan_target, result, input, run_ts)
            self._child_handles.append((arch_handle.id, arch_handle))   # wave_architecture.py:508-510
            self._child_handles.append((data_handle.id, data_handle))   # wave_architecture.py:511-513
        except Exception as exc:                                # wave_architecture.py:514  BRANCH 4
            status.status = "failed"                            # wave_architecture.py:515
            status.error  = f"spawn_children: {exc!r}"          # wave_architecture.py:516
            workflow.logger.warning(                            # wave_architecture.py:517-523
                "start_child_workflow failed",
                extra={"target_app_id": target_app_id, "error": repr(exc)})

    any_in_flight = any(                                        # wave_architecture.py:525-528
        s.status == "architecture_in_flight"
        for s in self._dispatch_status.values())
    if not any_in_flight:                                       # wave_architecture.py:529  BRANCH 5
        error_reasons = [                                       # wave_architecture.py:532-534
            s.error for s in self._dispatch_status.values() if s.error]
        reason_summary = (                                      # wave_architecture.py:535-539
            "; ".join(error_reasons)[:500]
            if error_reasons
            else "every target failed to provision")            # BRANCH 6 (ternary)
        await self._update_wave_status_safe(                    # wave_architecture.py:540-543
            "stuck-awaiting-recovery",
            reason=f"wave_architecture: {reason_summary}")
        self._progress_pct = 50.0                               # wave_architecture.py:544
        self._updated_at   = _now_iso()                         # wave_architecture.py:545
        return "stuck-awaiting-recovery"                        # wave_architecture.py:546

    # At least one target in flight.
    await self._update_wave_status_safe("architecture-dispatched")   # wave_architecture.py:549
    self._progress_pct = 100.0                                  # wave_architecture.py:550
    self._updated_at   = _now_iso()                             # wave_architecture.py:551
    return "completed"                                          # wave_architecture.py:552
```

**`_provision_and_spawn` branch inventory (6):**
1. `if not isinstance(targets, list) or not targets: raise` (466) — empty/garbage plan → non-retryable.
2. `if status is None: continue` (490) — skip target with no seeded status row.
3. `if isinstance(result, BaseException):` (492) — provision raised → mark failed, skip spawn.
4. `except Exception as exc:` around spawn (514) — spawn raised → mark failed.
5. `if not any_in_flight:` (529) — nothing in flight → `stuck-awaiting-recovery`.
6. `"; ".join(...) if error_reasons else "every target failed to provision"` ternary (535-539).

**Activity / call ordering:**
- `_read_plan_from_git()` (§3.4) — SEQUENTIAL, first.
- `_init_dispatch_status(targets)` (§3.6) — local, seeds `_dispatch_status`.
- `provision_futures = [_provision_one_target(t, input) for t in targets]` then
  `await asyncio.gather(*provision_futures, return_exceptions=True)` — **PARALLEL** provisioning
  (one `create_target_app_and_repo` activity per target, §3.7).
- Per-target spawn (`_spawn_children_for_target`, §3.8) runs SEQUENTIALLY in the `zip` loop AFTER
  the gather — each spawn is awaited one at a time.

> ⚠️ **GOTCHA-PS-GATHER-RETURN-EXCEPTIONS:** `asyncio.gather(..., return_exceptions=True)`
> (`wave_architecture.py:484`) means a per-target provisioning failure is RETURNED as a
> `BaseException` object in the `provisioned` list rather than raising out of the gather. This is the
> mechanism that lets one target fail without aborting the whole wave (`wave_architecture.py:478-479`).
> A rebuild MUST use `return_exceptions=True`; a plain `gather` would propagate the first failure and
> abort all other targets. The exception is then detected per-element via `isinstance(result,
> BaseException)` (492).
> ⚠️ **GOTCHA-PS-ZIP-ORDER:** the loop `zip(targets, provisioned)` (`wave_architecture.py:487`)
> pairs each plan target with its gather result POSITIONALLY. `asyncio.gather` preserves input order
> regardless of completion order, so `targets[i]` always pairs with `provisioned[i]`. A rebuild's
> gather/result correlation MUST be positional, not by completion order.
> ⚠️ **GOTCHA-PS-DUAL-FAILURE-MODES:** there are TWO failure capture points per target: (a) provision
> failure → `isinstance(result, BaseException)` → `status="failed"`, `error=repr(result)`, `continue`
> (skip spawn) (492-502); (b) spawn failure → caught by `try/except Exception` around
> `_spawn_children_for_target` → `status="failed"`, `error=f"spawn_children: {exc!r}"` (514-523).
> The error prefixes differ (`repr(result)` vs `"spawn_children: …"`) so an operator can tell which
> phase failed. A rebuild must reproduce both capture points with these exact error string shapes.
> ⚠️ **GOTCHA-PS-PROVISIONED-BEFORE-SPAWN:** on the happy path, `status.status` is set to
> `"provisioned"` (503) BEFORE the spawn attempt, then `_spawn_children_for_target` flips it to
> `"architecture_in_flight"` on success (`wave_architecture.py:772`). If spawn fails, the except
> overwrites it back to `"failed"` (515). So a target that provisioned but failed to spawn ends as
> `"failed"`, not `"provisioned"`. The `any_in_flight` check keys on `"architecture_in_flight"`
> specifically (526), so a stuck-at-`"provisioned"` (impossible on this path) or `"failed"` target
> does NOT count as in-flight. A rebuild must use `"architecture_in_flight"` as the in-flight marker.
> ⚠️ **GOTCHA-PS-CHILD-HANDLES-APPENDED-IN-LOOP:** both child handles are appended to `_child_handles`
> as `(handle.id, handle)` tuples ONLY on spawn success (508-513), inside the loop, so a later
> `cancel_all_children` can reach them. If spawn fails mid-way (e.g. arch started but data failed),
> the except catches it and neither handle is appended (because the append happens after BOTH handles
> are returned from `_spawn_children_for_target` — which itself starts both children before returning;
> see §3.8 GOTCHA-SPAWN-PARTIAL). A rebuild must append both handles only after a successful spawn.
> ⚠️ **GOTCHA-PS-RUN-TS-DETERMINISTIC:** `run_ts = int(workflow.now().timestamp())`
> (`wave_architecture.py:476`) is computed ONCE before the gather and threaded into every
> `_spawn_children_for_target` call so all children of this run share the same timestamp suffix in
> their workflow ids (`architecture-{target_app_id}-{run_ts}`, `data-{target_app_id}-{run_ts}`).
> `workflow.now()` is deterministic under replay, so `run_ts` is stable across replays — making the
> child workflow ids deterministic/idempotent. A rebuild MUST compute `run_ts` once, from
> `workflow.now()`, before the loop — NOT per-target and NOT from `datetime.now()`.
> ⚠️ **GOTCHA-PS-EMPTY-PLAN-RAISE:** `if not isinstance(targets, list) or not targets: raise`
> (466-472) — the plan schema enforces `minItems:1` on targets, so an empty list "here means the
> operator overwrote with garbage" (`wave_architecture.py:467-468`). This non-retryable raise
> propagates to `run`'s `except ApplicationError` (302) → FAILED + `stuck-awaiting-recovery` wave
> status + re-raise. A rebuild must raise non-retryable on empty/non-list targets.
> ⚠️ **GOTCHA-PS-STUCK-PROGRESS-STAYS-50:** on the `stuck-awaiting-recovery` path, `_progress_pct`
> is set back to / stays at 50.0 (544), NOT advanced. On the `completed` path it goes to 100.0 (550).
> A rebuild must reproduce both.

---

### 3.4 `_read_plan_from_git(self) -> dict` (`wave_architecture.py:554-573`)

```text
async def _read_plan_from_git(self):
    read_result = await workflow.execute_activity(              # wave_architecture.py:556-566
        read_artifact,
        ReadArtifactInput(
            repo=self._artifact_repo,
            branch="main",
            path=_plan_path(self._wave_id)),
        start_to_close_timeout=timedelta(seconds=30),           # wave_architecture.py:563
        retry_policy=RETRY_POLICIES["transient"],               # wave_architecture.py:564  3 attempts
        activity_id=f"read-target-plan-{self._wave_id}")        # wave_architecture.py:565
    try:
        return json.loads(read_result.content)                 # wave_architecture.py:568
    except (json.JSONDecodeError, TypeError, ValueError) as exc:# wave_architecture.py:569  BRANCH
        raise ApplicationError(                                 # wave_architecture.py:570-573
            f"architecture-target-plan.json on main is malformed: {exc}",
            non_retryable=True) from exc
```
- **One branch:** `except (json.JSONDecodeError, TypeError, ValueError)` (569) → non-retryable raise
  with `from exc` chaining.
- **Activity:** `read_artifact` — `ReadArtifactInput(repo=_artifact_repo, branch="main",
  path=_plan_path(wave_id))`; **30s**; `transient` (3 attempts);
  `activity_id="read-target-plan-{wave_id}"`.
> ⚠️ **GOTCHA-READ-FROM-MAIN:** reads from `main` at `_plan_path(wave_id)` — the SAME path the API
> overwrote on operator confirm. This is the "re-read from git after confirmation" invariant
> (`wave_architecture.py:36-38`). A rebuild must read `main`, not a feature branch, and at this exact
> path.
> ⚠️ **GOTCHA-READ-MALFORMED-NONRETRY:** a `json.loads` failure (or `TypeError`/`ValueError` from a
> non-string `content`) raises a non-retryable `ApplicationError` with `from exc`
> (`wave_architecture.py:570-573`). This propagates to `run`'s `except ApplicationError` → FAILED.
> A rebuild must catch exactly those three exception types and re-raise non-retryable with chaining.

---

### 3.5 `_update_wave_status_safe(self, new_status, reason="")` (`wave_architecture.py:779-806`)

Best-effort `wave.status` flip — NEVER raises.
```text
async def _update_wave_status_safe(self, new_status, reason=""):
    if not self._wave_id:                                      # wave_architecture.py:785  BRANCH 1
        return                                                 # wave_architecture.py:786  ← no-op
    try:
        await workflow.execute_activity(                       # wave_architecture.py:788-797
            update_wave_status,
            UpdateWaveStatusInput(
                wave_id=self._wave_id,
                new_status=new_status,
                reason=reason),
            start_to_close_timeout=timedelta(seconds=30),      # wave_architecture.py:795
            retry_policy=RETRY_POLICIES["transient"])          # wave_architecture.py:796  3 attempts
    except Exception as exc:                                   # wave_architecture.py:798  BRANCH 2 (best-effort)
        workflow.logger.warning(                               # wave_architecture.py:799-806
            "update_wave_status failed",
            extra={"wave_id": self._wave_id, "new_status": new_status, "error": repr(exc)})
```
- **Two branches:** `if not self._wave_id: return` (785) — guard against empty wave id; `except
  Exception` (798) — swallow + log.
- **Activity:** `update_wave_status` — `UpdateWaveStatusInput(wave_id, new_status, reason)`; **30s**;
  `transient` (3 attempts). Wrapped in try/except — best-effort.
- **Callers / status sequence:** `awaiting-architecture-dispatch` (§3.2, line 441),
  `architecture-in-flight` (§3.3, line 462), `stuck-awaiting-recovery` (§3.1 run except 306/319,
  §3.3 line 540), `architecture-dispatched` (§3.3, line 549).
> ⚠️ **GOTCHA-WSS-NEVER-RAISES:** this method NEVER propagates an exception — both the empty-wave-id
> guard and the except make it safe to call from anywhere, including the `run()` except blocks
> (where raising would mask the original failure). A rebuild MUST keep this no-raise contract.
> ⚠️ **GOTCHA-WSS-VALID-STATUSES:** the wave CHECK constraint (migration 045 per the
> `UpdateWaveStatusInput` docstring) only allows the fan-out statuses
> `awaiting-architecture-dispatch` / `architecture-in-flight` / `data-in-flight` (this workflow uses
> the first two) plus the new `architecture-dispatched` / `stuck-awaiting-recovery` and pre-existing
> `completed`/`failed`. A rebuild must pass only these literal status strings.

---

### 3.6 `_init_dispatch_status(self, targets: list[dict]) -> None` (`wave_architecture.py:575-601`)

Seeds `_dispatch_status` with one `pending` entry per plan target, keyed by `target_app_id`.
```text
def _init_dispatch_status(self, targets):
    for t in targets:                                          # wave_architecture.py:581  LOOP
        target_app_id = str(t.get("target_app_id") or "")      # wave_architecture.py:582
        if not target_app_id:                                  # wave_architecture.py:583  BRANCH 1
            continue                                           # wave_architecture.py:584  ← skip
        source_app_ids = [                                     # wave_architecture.py:585-588
            str(s) for s in (t.get("source_app_ids") or [])
            if isinstance(s, str) and s]
        anchor = source_app_ids[0] if source_app_ids else ""   # wave_architecture.py:589  BRANCH 2 (ternary)
        self._dispatch_status[target_app_id] = DispatchTargetStatus(   # wave_architecture.py:590-601
            source_app_id=anchor,
            target_app_id=target_app_id,
            target_app_name=str(t.get("target_name") or ""),
            target_repo=str(t.get("target_repo_slug") or ""),
            disposition=_disposition_from_relationship(        # wave_architecture.py:595-597
                str(t.get("relationship") or "")),
            status="pending",
            source_app_ids=list(source_app_ids),
            target_service_id=str(t.get("target_service_id") or ""))
```
- **Branches:** `if not target_app_id: continue` (583); the `anchor = source_app_ids[0] if
  source_app_ids else ""` ternary (589). Plus the list-comprehension filter `if isinstance(s, str)
  and s` (587).
- ⚠️ **GOTCHA-INIT-PLAN-FIELD-NAMES:** the plan target dict uses these EXACT keys: `target_app_id`,
  `source_app_ids`, `target_name`, `target_repo_slug`, `relationship`, `target_service_id`
  (`wave_architecture.py:582-600`). Note `target_name` (not `target_app_name`) and
  `target_repo_slug` (not `target_repo`) in the PLAN — they map onto the
  `DispatchTargetStatus.target_app_name` / `.target_repo` fields. A rebuild must read these exact
  plan keys and map them to these exact status fields.
> ⚠️ **GOTCHA-INIT-SOURCE-FILTER:** `source_app_ids` is filtered to non-empty strings:
> `[str(s) for s in (t.get("source_app_ids") or []) if isinstance(s, str) and s]`
> (`wave_architecture.py:585-588`). Non-string or empty-string entries are dropped. `anchor` is the
> first surviving entry, or `""` if none. A rebuild must filter identically.
> ⚠️ **GOTCHA-INIT-DISPOSITION-RAISE-HERE:** `_disposition_from_relationship` is called HERE
> (`wave_architecture.py:595-597`) while seeding — so a plan target with an unknown `relationship`
> raises a non-retryable `ApplicationError` (§0.3) DURING `_init_dispatch_status`, which propagates
> up through `_provision_and_spawn` (no try around `_init_dispatch_status`) → `run`'s
> `except ApplicationError`. A rebuild must call the title-caser here, accepting that a bad
> relationship fails the whole coordinator.
> ⚠️ **GOTCHA-INIT-SKIP-EMPTY-TARGET-ID:** targets with no `target_app_id` are silently skipped
> (583-584) — they get NO `_dispatch_status` row. In the later `zip` loop, such a target's
> `status = self._dispatch_status.get(target_app_id)` returns `None` and is skipped via `if status
> is None: continue` (`wave_architecture.py:490-491`). So a target with an empty id is provisioned by
> the gather (it still appears in `provision_futures`) but its result is then discarded. ⚠️ Subtle:
> `_provision_one_target` does `self._dispatch_status[target_app_id]` (`wave_architecture.py:616`)
> — a DIRECT subscript, NOT `.get()` — so a target with empty id would raise `KeyError` inside
> `_provision_one_target`, which the gather captures as a `BaseException` (return_exceptions=True),
> and the zip loop then can't find a status row to record it on (status is None → continue). Net:
> empty-id targets are effectively dropped. A rebuild must reproduce the skip-on-empty-id seeding
> and the direct-subscript-in-provision behavior.

---

### 3.7 `_provision_one_target(self, plan_target, input) -> CreateTargetAppAndRepoResult` (`wave_architecture.py:603-638`)

One `create_target_app_and_repo` activity invocation per plan target.
```text
async def _provision_one_target(self, plan_target, input):
    target_app_id = str(plan_target.get("target_app_id") or "")# wave_architecture.py:615
    status = self._dispatch_status[target_app_id]              # wave_architecture.py:616  ⚠ direct subscript
    status.status = "provisioning"                             # wave_architecture.py:617
    source_app_ids = list(status.source_app_ids)               # wave_architecture.py:618
    anchor = source_app_ids[0] if source_app_ids else ""       # wave_architecture.py:619  BRANCH (ternary)
    peers  = source_app_ids[1:]                                # wave_architecture.py:620
    return await workflow.execute_activity(                    # wave_architecture.py:621-638
        create_target_app_and_repo,
        CreateTargetAppAndRepoInput(
            source_app_id=anchor,
            target_app_name=status.target_app_name or target_app_id,   # wave_architecture.py:625  BRANCH (or-default)
            target_repo=status.target_repo,
            default_branch="main",
            wave_id=input.wave_id,
            portfolio_id=input.portfolio_id,
            disposition=status.disposition,
            peer_source_app_ids=list(peers),
            source_app_ids=list(source_app_ids),
            target_service_id=status.target_service_id),
        start_to_close_timeout=timedelta(minutes=5),           # wave_architecture.py:635
        retry_policy=RETRY_POLICIES["transient"],              # wave_architecture.py:636  3 attempts
        activity_id=f"provision-target-{target_app_id}")       # wave_architecture.py:637
```
- **Branches:** `anchor = source_app_ids[0] if source_app_ids else ""` (619); the
  `status.target_app_name or target_app_id` or-default (625).
- **Activity:** `create_target_app_and_repo` — `CreateTargetAppAndRepoInput(source_app_id=anchor,
  target_app_name=…, target_repo=…, default_branch="main", wave_id, portfolio_id, disposition=…,
  peer_source_app_ids=peers, source_app_ids=all, target_service_id=…)`; **5 min**; `transient`
  (3 attempts); `activity_id="provision-target-{target_app_id}"`.
> ⚠️ **GOTCHA-PROV-ANCHOR-PEERS-SPLIT:** the activity input carries BOTH the v1 anchor+peer split
> (`source_app_id=anchor`, `peer_source_app_ids=peers=source_app_ids[1:]`) AND the v2 full set
> (`source_app_ids=source_app_ids`) (`wave_architecture.py:618-620`, `624`, `631-632`). The activity
> falls back to the legacy fields for v1 callers but uses `source_app_ids` as the full set when set
> (per `CreateTargetAppAndRepoInput` docstring). A rebuild must populate ALL THREE so both code paths
> in the activity work. `anchor` = first source; `peers` = rest; `source_app_ids` = full list.
> ⚠️ **GOTCHA-PROV-NAME-FALLBACK:** `target_app_name=status.target_app_name or target_app_id`
> (`wave_architecture.py:625`) — falls back to the target_app_id when the plan's `target_name` was
> empty. A rebuild must reproduce this fallback.
> ⚠️ **GOTCHA-PROV-SETS-PROVISIONING:** `status.status = "provisioning"` (617) is set at the START
> of provisioning (before the activity). So `dispatch_results` during the gather window shows
> `"provisioning"` per target. A rebuild must set this before awaiting the activity.
> ⚠️ **GOTCHA-PROV-RETRY-TRANSIENT-NOT-INFRA:** provisioning uses `transient` (3 attempts), NOT
> `infrastructure` (10). The `create_target_app_and_repo` docstring notes HTTP 422 (repo already
> exists) raises `NonRetryableError` so the user can correct it — that non-retryable surfaces through
> the gather as a `BaseException`. A rebuild must use `transient` here.

---

### 3.8 `_spawn_children_for_target(self, plan_target, provisioned, input, run_ts) -> tuple[handle, handle]` (`wave_architecture.py:640-773`)

Resolves source repos, builds Architecture + Data `LineWorkflowInput`s, starts both children with
`ABANDON`, best-effort projects the Architecture line status, mutates the status row, returns the two
handles.

```text
async def _spawn_children_for_target(self, plan_target, provisioned, input, run_ts):
    target_app_id    = provisioned.target_app_id               # wave_architecture.py:654
    arch_workflow_id = f"architecture-{target_app_id}-{run_ts}"# wave_architecture.py:655
    data_workflow_id = f"data-{target_app_id}-{run_ts}"        # wave_architecture.py:656

    plan_target_app_id = str(plan_target.get("target_app_id") or "")   # wave_architecture.py:658
    status = self._dispatch_status[plan_target_app_id]         # wave_architecture.py:659  ⚠ keyed by PLAN id
    relationship = str(plan_target.get("relationship") or "").strip().lower()   # wave_architecture.py:660
    source_app_ids = list(status.source_app_ids)               # wave_architecture.py:661
    target_service_id = status.target_service_id               # wave_architecture.py:662

    # Resolve each source app's repo URL.
    source_repos_result = await workflow.execute_activity(     # wave_architecture.py:668-674
        fetch_application_source_repos,
        FetchSourceReposInput(source_app_ids=list(source_app_ids)),
        start_to_close_timeout=timedelta(seconds=30),          # wave_architecture.py:671
        retry_policy=RETRY_POLICIES["transient"],              # wave_architecture.py:672  3 attempts
        activity_id=f"fetch-source-repos-{target_app_id}")     # wave_architecture.py:673
    anchor_source_repo = source_repos_result.anchor_source_repo# wave_architecture.py:675
    source_repos_map   = dict(source_repos_result.source_repos)# wave_architecture.py:676
    if not anchor_source_repo:                                 # wave_architecture.py:677  BRANCH 1 (warn-only)
        workflow.logger.warning(                               # wave_architecture.py:678-687
            "no source_repo resolved for anchor source app",
            extra={"target_app_id": target_app_id,
                   "anchor_source_app_id": (source_app_ids[0] if source_app_ids else ""),   # BRANCH 2 (ternary)
                   "source_app_ids_count": len(source_app_ids)})

    target_app_name = status.target_app_name or target_app_id  # wave_architecture.py:689  BRANCH 3 (or-default)

    arch_input = LineWorkflowInput(                            # wave_architecture.py:691-705
        app_id=target_app_id,
        app_name=target_app_name,
        wave_id=input.wave_id,
        portfolio_id=input.portfolio_id,
        artifact_repo=input.artifact_repo,
        source_repo=anchor_source_repo,
        source_repos=source_repos_map,
        target_repo_url=provisioned.target_repo_url,
        disposition=None,                                      # wave_architecture.py:701  ⚠ Architecture resolves from DB
        peer_workflow_ids={"Data": data_workflow_id},          # wave_architecture.py:702
        target_service_id=target_service_id,
        relationship=relationship,
        source_app_ids=list(source_app_ids))

    # Discovery-produced data artifacts the Data line inherits.
    data_prior: list[str] = []                                 # wave_architecture.py:707
    for src in source_app_ids:                                 # wave_architecture.py:708  LOOP
        if not src:                                            # wave_architecture.py:709  BRANCH 4
            continue                                           # wave_architecture.py:710  ← skip
        data_prior.append(f"discovery/{src}/data-domains.json")        # wave_architecture.py:711
        data_prior.append(f"discovery/{src}/shared-db-analysis.json")  # wave_architecture.py:712
    data_input = LineWorkflowInput(                            # wave_architecture.py:713-728
        app_id=target_app_id,
        app_name=target_app_name,
        wave_id=input.wave_id,
        portfolio_id=input.portfolio_id,
        artifact_repo=input.artifact_repo,
        source_repo=anchor_source_repo,
        source_repos=source_repos_map,
        target_repo_url=provisioned.target_repo_url,
        disposition=None,
        peer_workflow_ids={"Architecture": arch_workflow_id},  # wave_architecture.py:723
        prior_artifacts=data_prior,                            # wave_architecture.py:724
        target_service_id=target_service_id,
        relationship=relationship,
        source_app_ids=list(source_app_ids))

    # Start children — ABANDON.
    arch_handle = await workflow.start_child_workflow(         # wave_architecture.py:733-738
        "ArchitectureWorkflow", arch_input,
        id=arch_workflow_id,
        parent_close_policy=workflow.ParentClosePolicy.ABANDON)
    data_handle = await workflow.start_child_workflow(         # wave_architecture.py:739-744
        "DataWorkflow", data_input,
        id=data_workflow_id,
        parent_close_policy=workflow.ParentClosePolicy.ABANDON)

    # Best-effort projection of the Arch line status.
    try:
        await workflow.execute_activity(                       # wave_architecture.py:749-759
            update_application_line_projection,
            UpdateApplicationLineProjectionInput(
                app_id=target_app_id,
                line="Architecture",
                workflow_id=arch_workflow_id,
                status="in_progress"),
            start_to_close_timeout=timedelta(seconds=30),      # wave_architecture.py:757
            retry_policy=RETRY_POLICIES["transient"])          # wave_architecture.py:758  3 attempts
    except Exception as exc:                                   # wave_architecture.py:760  BRANCH 5 (best-effort)
        workflow.logger.warning(                               # wave_architecture.py:761-767
            "update_application_line_projection failed (Architecture)",
            extra={"target_app_id": target_app_id, "error": repr(exc)})

    status.target_app_id            = target_app_id            # wave_architecture.py:769
    status.architecture_workflow_id = arch_workflow_id         # wave_architecture.py:770
    status.data_workflow_id         = data_workflow_id         # wave_architecture.py:771
    status.status                   = "architecture_in_flight" # wave_architecture.py:772
    return arch_handle, data_handle                            # wave_architecture.py:773
```

**`_spawn_children_for_target` branch inventory (5):**
1. `if not anchor_source_repo:` (677) — warn-only (does NOT abort).
2. `source_app_ids[0] if source_app_ids else ""` ternary in the warn extra (684).
3. `target_app_name = status.target_app_name or target_app_id` or-default (689).
4. `for src in source_app_ids: if not src: continue` (708-710) — skip empty source ids building data_prior.
5. `except Exception` around `update_application_line_projection` (760) — best-effort projection.

**Activity / child calls (in order):**
1. `fetch_application_source_repos` — `FetchSourceReposInput(source_app_ids)`; **30s**; `transient`
   (3 attempts); `activity_id="fetch-source-repos-{target_app_id}"`. SEQUENTIAL, first.
2. `start_child_workflow("ArchitectureWorkflow", arch_input, id=arch_workflow_id,
   parent_close_policy=ABANDON)` — child start, returns handle.
3. `start_child_workflow("DataWorkflow", data_input, id=data_workflow_id,
   parent_close_policy=ABANDON)` — child start, returns handle.
4. `update_application_line_projection` — `UpdateApplicationLineProjectionInput(app_id=target_app_id,
   line="Architecture", workflow_id=arch_workflow_id, status="in_progress")`; **30s**; `transient`;
   try/except — best-effort. (No `activity_id`.)

> ⚠️ **GOTCHA-SPAWN-CHILD-IDS:** child workflow ids are
> `arch_workflow_id = f"architecture-{target_app_id}-{run_ts}"` and
> `data_workflow_id = f"data-{target_app_id}-{run_ts}"` (`wave_architecture.py:655-656`), using the
> `provisioned.target_app_id` (the activity-returned target id, which for Replace/Consolidate is a
> fresh UUID, for Refactor/etc equals the source id — per `CreateTargetAppAndRepoResult` docstring).
> `run_ts` is the shared run timestamp (GOTCHA-PS-RUN-TS-DETERMINISTIC). A rebuild MUST use these
> exact id templates so the children are deterministically identified and the peer handshake works.
> ⚠️ **GOTCHA-SPAWN-ABANDON:** BOTH children are started with
> `parent_close_policy=workflow.ParentClosePolicy.ABANDON` (`wave_architecture.py:737`, `743`). The
> comment (`wave_architecture.py:730-732`): ABANDON so children outlive this coordinator; cross-line
> Arch↔Data signalling goes through the DB-backed `arch_data_signal_registry`, so sibling lifecycle
> is fine. This is why `run`'s `"completed"` "just means spawn succeeded" (`wave_architecture.py:251-252`)
> — the coordinator can complete/cancel without tearing children down. A rebuild MUST use ABANDON;
> the default (TERMINATE) would kill children when the coordinator closes.
> ⚠️ **GOTCHA-SPAWN-START-NOT-EXECUTE:** uses `workflow.start_child_workflow(...)` (returns a handle
> immediately after the child is started) NOT `workflow.execute_child_workflow(...)` (which would
> await child completion). The coordinator does NOT await child results. A rebuild MUST use
> `start_child_workflow` and NOT await the handles' results.
> ⚠️ **GOTCHA-SPAWN-DISPOSITION-NONE:** both `arch_input` and `data_input` set `disposition=None`
> (`wave_architecture.py:701`, `722`). The comment: "Architecture resolves from DB on start." The
> children do NOT receive the disposition through the input — they read it from the DB (the
> `relationship` field IS threaded through, but `disposition` is None). A rebuild must pass
> `disposition=None` and rely on `relationship` for routing.
> ⚠️ **GOTCHA-SPAWN-PEER-IDS-CROSSED:** `arch_input.peer_workflow_ids={"Data": data_workflow_id}` and
> `data_input.peer_workflow_ids={"Architecture": arch_workflow_id}` (`wave_architecture.py:702`,
> `723`) — each child gets the OTHER's workflow id so the cross-line handshake
> (`TargetProvisionedSignal` / `DataReadyForTargetSignal`) can route. The keys are the
> assembly-line names. A rebuild must cross-wire these exactly.
> ⚠️ **GOTCHA-SPAWN-DATA-PRIOR-ARTIFACTS:** `data_input.prior_artifacts` is built by iterating
> source_app_ids and appending TWO Discovery artifacts per non-empty source:
> `discovery/{src}/data-domains.json` and `discovery/{src}/shared-db-analysis.json`
> (`wave_architecture.py:707-712`). Empty source ids are skipped (709-710). `arch_input` gets NO
> prior_artifacts. A rebuild must build this exact list (two paths per source, in this order) for the
> Data child only.
> ⚠️ **GOTCHA-SPAWN-SOURCE-REPO-WARN-ONLY:** an empty `anchor_source_repo` only LOGS a warning
> (`wave_architecture.py:677-687`) — it does NOT abort the spawn. The children get an empty
> `source_repo` and degrade (skills can't read legacy code via the envelope). The comment
> (`wave_architecture.py:665-667`): per-source repo resolution mirrors the legacy
> wave_rationalization path so skills get a populated `source_repo` envelope. A rebuild must warn-only,
> not raise, on an unresolved anchor repo.
> ⚠️ **GOTCHA-SPAWN-PROJECTION-BEST-EFFORT:** `update_application_line_projection` is wrapped in
> try/except (`wave_architecture.py:748-767`) — a failure logs and continues. The comment: "Best-
> effort projection so the dashboard reflects the Arch line transitioning to in-progress."
> CRITICALLY: this is INSIDE `_spawn_children_for_target`, which is itself called inside the caller's
> `try/except` (§3.3, line 514). But because this inner except SWALLOWS the projection failure, a
> projection error does NOT propagate to the caller's spawn-failed branch — the spawn still "succeeds"
> (children were already started). A rebuild must make ONLY the projection best-effort, leaving the
> child-start failures to propagate to the caller. (Projection is for `line="Architecture"` only;
> the Data child's projection is NOT done here — Data projects its own line.)
> ⚠️ **GOTCHA-SPAWN-PARTIAL (child-start ordering & failure):** the arch child is started FIRST
> (733-738), THEN the data child (739-744). If the data-child start RAISES, the exception propagates
> out of `_spawn_children_for_target` (it is NOT caught inside this method — only the projection is)
> to the caller's `except Exception` (§3.3, line 514), which marks the target `"failed"`. BUT the
> arch child was ALREADY started and is ABANDON, so it KEEPS RUNNING — and neither handle was
> appended to `_child_handles` (the append in §3.3 happens only after BOTH handles return). So on a
> partial spawn failure, an orphaned Architecture child runs un-tracked. This is a known fragility:
> a rebuild must reproduce the ordering (arch first, data second) and accept that a data-start failure
> leaves an orphaned, untracked arch child. (There is no compensation/rollback.)
> ⚠️ **GOTCHA-SPAWN-STATUS-MUTATION-LAST:** the status mutations (`target_app_id`,
> `architecture_workflow_id`, `data_workflow_id`, `status="architecture_in_flight"`) happen LAST,
> AFTER both children started and the projection attempt (`wave_architecture.py:769-772`). So the
> status only flips to `architecture_in_flight` on a fully-successful spawn (both children + reaching
> line 772). If the data-start raised before 772, status stays whatever it was (`"provisioned"` from
> the caller) until the caller's except overwrites it to `"failed"`. A rebuild must order the status
> mutation after both `start_child_workflow` calls.
> ⚠️ **GOTCHA-SPAWN-STATUS-KEYED-BY-PLAN-ID:** inside this method, `status` is looked up by
> `plan_target.get("target_app_id")` (`wave_architecture.py:658-659`), the PLAN's id — which equals
> the `_dispatch_status` key. But `target_app_id` used for child ids / projection / input is
> `provisioned.target_app_id` (the ACTIVITY-returned id) (`wave_architecture.py:654`). For
> Replace/Consolidate the provisioned id is a fresh UUID that DIFFERS from the plan slug; for
> Refactor/etc they coincide. So the status row (keyed by plan slug) records
> `status.target_app_id = provisioned.target_app_id` (769) — overwriting the plan slug with the
> resolved id. A rebuild must distinguish plan-id (status key + status lookup) from provisioned-id
> (child ids, inputs, projection, and the final `status.target_app_id` write).

---

## 4. GATE HANDLING

**There are NO gates in this workflow.** (`wave_architecture.py:210-211`: "Does NOT own: gate signal
bookkeeping (no gates run here)…".) Therefore:
- No `gate_approved` / `gate_rejected` / `escalation_resolved` / `merge_retry` signals.
- No `_wait_for_gate_decision`, no `_reconcile_and_merge_with_retry_loop`.
- No `_rework_feedback`, no `_rework_iterations`, no `_bump_rework`, no MAX_REWORK ceiling.
- No gate PR creation, no evidence assembly, no `check_gate_criteria` / `submit_gate_evidence`.
- `get_status().pending_gate` is hardcoded `None` (`wave_architecture.py:880`).

The only human-in-the-loop point is the **pre-dispatch hold** (§3.2), which is NOT a gate — it is a
plain `wait_condition` on `_pre_dispatch_confirmed or _cancel_all_children_requested` with no gate
record, no evidence, no PR, no SLA timer. A rebuild MUST NOT add any gate machinery here. The gates
for the design work live in the SPAWNED `ArchitectureWorkflow` (G-02) and `DataWorkflow` (G-DT)
children — out of scope for this coordinator.

---

## 5. RESILIENCE

### 5.1 Timeouts (start_to_close) and retry policies — complete inventory
| Activity | Timeout | Heartbeat | Retry policy | activity_id |
|----------|---------|-----------|--------------|-------------|
| `dispatch_agent_task` (step 1 mapper) | **30 min** | **2 min** | `agent_failure` (3) | `agent-wave-target-state-mapping-{wave_id}` |
| `validate_artifact_against_schema` | 30s | — | **`validation_failure` (1, no retry)** | *(none)* |
| `write_artifact` (commit plan) | 60s | — | `transient` (3) | `commit-target-plan-{wave_id}` |
| `read_artifact` (re-read plan) | 30s | — | `transient` (3) | `read-target-plan-{wave_id}` |
| `create_target_app_and_repo` (per target) | **5 min** | — | `transient` (3) | `provision-target-{target_app_id}` |
| `fetch_application_source_repos` (per target) | 30s | — | `transient` (3) | `fetch-source-repos-{target_app_id}` |
| `update_application_line_projection` (per target, best-effort) | 30s | — | `transient` (3) | *(none)* |
| `update_wave_status` (via `_update_wave_status_safe`, best-effort) | 30s | — | `transient` (3) | *(none)* |

`transient` = `HTTP_RETRY_POLICY` (initial 1s, backoff 2.0, max 15s, 3 attempts).
`agent_failure` = initial 5s, backoff 2.0, max 60s, 3 attempts.
`validation_failure` = max 1 attempt (NO retry).

### 5.2 Heartbeats
- ONLY the step-1 `dispatch_agent_task` sets a `heartbeat_timeout` (2 min). All other activities rely
  solely on start_to_close. (GOTCHA-S1-HEARTBEAT.)

### 5.3 continue-as-new
- NONE. The workflow runs once per wave, finishes after spawning (or recovers/cancels), and never
  loops or continues-as-new. The pre-dispatch hold is a single indefinite `wait_condition`, not a
  loop, so history does not grow unbounded during the hold.

### 5.4 Idempotency / determinism
- Deterministic `activity_id`s on the four keyed activities make them replay-stable:
  `agent-wave-target-state-mapping-{wave_id}`, `commit-target-plan-{wave_id}`,
  `read-target-plan-{wave_id}`, `provision-target-{target_app_id}`,
  `fetch-source-repos-{target_app_id}`.
- `run_ts = int(workflow.now().timestamp())` computed once (GOTCHA-PS-RUN-TS-DETERMINISTIC) → stable
  child workflow ids across replays.
- `create_target_app_and_repo` is idempotent on `target_repo_url` (short-circuits to existing row);
  HTTP 422 (repo exists) → `NonRetryableError` (per its docstring).
- Children are started with deterministic ids (`architecture-{id}-{run_ts}` / `data-{id}-{run_ts}`)
  so a replay would attempt the same child ids (Temporal dedupes on workflow id).
- `_now_iso()` = `workflow.now().isoformat()` everywhere — deterministic.
- NO `workflow.patched(...)` gates (brand-new workflow, no in-flight histories to preserve —
  `wave_architecture.py:42-43`).

### 5.5 Compensation / rollback
- NONE. There is no rollback path. Failure semantics:
  - **Best-effort activities** (`update_wave_status` via `_update_wave_status_safe`,
    `update_application_line_projection`, per-child `handle.cancel()` in `cancel_all_children`)
    swallow exceptions and continue.
  - **Per-target provisioning failures** are isolated by `asyncio.gather(return_exceptions=True)` —
    one target failing does not abort the wave; it is recorded on its `_dispatch_status` row.
  - **Per-target spawn failures** are caught by the caller's `try/except` and recorded on the status
    row (GOTCHA-PS-DUAL-FAILURE-MODES). An orphaned ABANDON arch child may result from a partial
    spawn (GOTCHA-SPAWN-PARTIAL) — NOT compensated.
  - **Total provision/spawn failure** (no target reaches `architecture_in_flight`) →
    `"stuck-awaiting-recovery"` outcome + wave status flip; the plan stays committed; operator
    `/resume`s on the same workflow_id (`wave_architecture.py:529-546`, `211-212`,
    `wave_architecture.py:255-256`).
  - **Fatal coordinator errors** (validation fail, malformed plan, empty plan, unknown relationship,
    missing app_ids/artifact_repo, any uncaught exception) → `run`'s `except` blocks set
    `_status=FAILED`, push `stuck-awaiting-recovery` wave status (best-effort), and **re-raise** →
    Temporal records a failed execution (GOTCHA-RUN-RETURN-vs-RAISE).
  - **Cancel** (`cancel_all_children`) → best-effort cancels tracked child handles, clears handles,
    sets `_status=CANCELLED`; if it fired during the hold, `run` returns `"cancelled"`.

> ⚠️ **GOTCHA-CANCEL-WINDOW (cancellation only fully works during the hold):** `cancel_all_children`
> has guaranteed effect ONLY while the workflow is parked in `_await_pre_dispatch_confirmation`'s
> `wait_condition` (the only wait that consumes `_cancel_all_children_requested`,
> `wave_architecture.py:442-447`). If the signal fires DURING `_provision_and_spawn` (e.g. mid-gather
> or mid-spawn-loop), it sets `_cancel_all_children_requested=True`, cancels any already-tracked child
> handles, and sets `_status=CANCELLED`/`_current_step="cancelled"` (`wave_architecture.py:837-860`)
> — but the running `asyncio.gather` and the spawn loop are NOT interrupted by it (they are not
> `wait_condition`s). The loop continues, may spawn more children, and `_provision_and_spawn` returns
> its normal `"completed"`/`"stuck-awaiting-recovery"` outcome — which `run` then maps to
> COMPLETED/FAILED (overwriting the CANCELLED the signal handler set). Net: a cancel during
> provisioning races; the final `_status` depends on ordering. A rebuild MUST reproduce this exact
> shape (single consuming wait; signal handler mutates state + cancels tracked handles; no
> interruption of in-flight gather/loop). Do NOT add `_cancel_all_children_requested` to a
> non-existent gather-level wait — there is none.

---

## 6. Behavioral parity checklist

A rebuilt `WaveArchitectureWorkflow` MUST satisfy ALL of the following:

1. **Standalone class:** `@workflow.defn class WaveArchitectureWorkflow:` with NO base class. NO HIL
   signals, NO gate signals, NO `self.cancelled`, NO gates, NO rework loop, NO `_rework_iterations`.
   `__init__` does NOT call `super().__init__()`. (GOTCHA-STANDALONE)
2. **State:** exactly the 13 instance vars of §1 with the listed initial values; `_dispatch_status`
   keyed by `target_app_id`; `_child_handles` a list of `(child_id_str, handle)` tuples; no
   `cancelled` flag. (GOTCHA-STATE-*)
3. **Signal surface:** exactly two `@workflow.signal` (`pre_dispatch_confirmed`,
   `cancel_all_children`, both `async def`) and exactly two `@workflow.query` (`dispatch_results`,
   `get_status`). No updates. `pre_dispatch_confirmed` coerces a dict payload to
   `PreDispatchConfirmedSignal`, sets `_pre_dispatch_confirmed=True`,
   `_pre_dispatch_confirmed_by=signal.confirmed_by`, bumps `_updated_at`. `cancel_all_children` sets
   `_cancel_all_children_requested=True`, best-effort cancels each tracked handle (swallowing
   per-handle errors), clears `_child_handles`, sets `_status=CANCELLED`+`_current_step="cancelled"`.
   (GOTCHA-SIG-*)
4. **`get_status`** returns `WorkflowStatusResponse` with `current_line=AssemblyLine.ARCHITECTURE`
   (hardcoded) and `pending_gate=None` (always). `dispatch_results` returns
   `list(self._dispatch_status.values())`. (GOTCHA-Q-*)
5. **`run()` preserves all 7 branches** of §3 in order: dict→dataclass coerce; `not app_ids` raise;
   `not artifact_repo` raise (BOTH non-retryable, BEFORE the `try`); post-hold
   `_cancel_all_children_requested` → return `"cancelled"`; `outcome=="completed"?COMPLETED:FAILED`
   ternary; `except ApplicationError` (fixed reason, no log, re-raise); `except Exception` (log,
   `{exc!r}[:500]` reason, re-raise). `except ApplicationError` is listed BEFORE `except Exception`.
   Both except blocks call `_update_wave_status_safe("stuck-awaiting-recovery", …)` then re-raise.
   `"failed"` is NEVER returned (only raised). (GOTCHA-RUN-*)
6. **Step 1** sets step `"wave-target-state-mapping"`/progress 5.0; builds the input bundle via
   `_build_input_artifacts` (per-app-grouped Discovery+Rationalization then 2 wave-shared, exact
   order); dispatches `dispatch_agent_task` with `app_id=""`, `wave_id=<uuid>`,
   `skill_id="target-state-mapper"`, `model_preference="tier-2"`,
   `workspace_key="wave-architecture-{wave_id}"`, `context={"wave_name": …}`, `execution_context`
   with `line_id="Architecture"` literal, `start_to_close=30min`, `heartbeat=2min`,
   `agent_failure`, `activity_id="agent-wave-target-state-mapping-{wave_id}"`; locates the plan via
   `f.path.endswith("architecture-target-plan.json")` (first match, None→non-retryable raise);
   validates via `validate_artifact_against_schema` (`validation_failure`, 30s) and STRICT-FAILS on
   `not validated or errors` (non-retryable, first-4-errors preview); commits `plan_file.content`
   (raw) to `main` at `_plan_path(wave_id)` via `write_artifact` (60s, `transient`,
   `activity_id="commit-target-plan-{wave_id}"`) with the exact target-count commit message; sets
   progress 30.0. Both step-1 branches preserved. (GOTCHA-S1-*, GOTCHA-BUNDLE-ORDER, GOTCHA-CONST-DUP)
7. **Step 2 (`_await_pre_dispatch_confirmation`)** sets step `"awaiting-architecture-dispatch"`,
   best-effort flips wave status to the same, then `await workflow.wait_condition(lambda:
   self._pre_dispatch_confirmed or self._cancel_all_children_requested)`. The predicate ORs BOTH
   flags. No timeout, no SLA, no reset. (GOTCHA-S2-*)
8. **Steps 3+4 (`_provision_and_spawn`)** preserve all 6 branches: set step
   `"architecture-in-flight"`/progress 50.0 + wave status; `_read_plan_from_git`; `not isinstance
   list or not targets` → non-retryable raise; `_init_dispatch_status`; compute `run_ts` once from
   `workflow.now()`; provision via `asyncio.gather(..., return_exceptions=True)` (PARALLEL); zip loop
   pairing targets↔results positionally with `status is None → continue`, `isinstance BaseException
   → status="failed"/repr/continue`, success → status="provisioned" then try-spawn (append both
   `(handle.id, handle)` on success; `except Exception → status="failed"/spawn_children:{exc!r}`);
   `any_in_flight` check on `"architecture_in_flight"`; if none → join error reasons (`[:500]` or
   default) → `_update_wave_status_safe("stuck-awaiting-recovery", …)` → progress 50.0 → return
   `"stuck-awaiting-recovery"`; else → `_update_wave_status_safe("architecture-dispatched")` →
   progress 100.0 → return `"completed"`. (GOTCHA-PS-*)
9. **`_read_plan_from_git`** reads `read_artifact` from `main` at `_plan_path(wave_id)` (30s,
   `transient`, `activity_id="read-target-plan-{wave_id}"`); `json.loads` the content; on
   `(JSONDecodeError, TypeError, ValueError)` → non-retryable raise `from exc`. (GOTCHA-READ-*)
10. **`_update_wave_status_safe`** no-ops on empty `_wave_id`; else `update_wave_status` (30s,
    `transient`) wrapped in try/except that logs and NEVER raises. (GOTCHA-WSS-*)
11. **`_init_dispatch_status`** seeds one `DispatchTargetStatus` per target keyed by `target_app_id`;
    skips empty `target_app_id`; reads plan keys `target_app_id`/`source_app_ids`/`target_name`/
    `target_repo_slug`/`relationship`/`target_service_id`; filters source ids to non-empty strings;
    anchor = first or ""; disposition via `_disposition_from_relationship` (raises non-retryable on
    unknown). (GOTCHA-INIT-*, GOTCHA-REL-NORMALIZE)
12. **`_provision_one_target`** looks up status by direct subscript `[target_app_id]`; sets
    `status="provisioning"`; computes anchor=first/peers=rest from `status.source_app_ids`; calls
    `create_target_app_and_repo` (5min, `transient`,
    `activity_id="provision-target-{target_app_id}"`) with `source_app_id=anchor`,
    `target_app_name=status.target_app_name or target_app_id`, `target_repo=status.target_repo`,
    `default_branch="main"`, wave/portfolio ids, `disposition=status.disposition`,
    `peer_source_app_ids=peers`, `source_app_ids=full`, `target_service_id=…`. (GOTCHA-PROV-*)
13. **`_spawn_children_for_target`** preserves all 5 branches: derives `arch_workflow_id` /
    `data_workflow_id` from `provisioned.target_app_id`+`run_ts`; looks up `status` by PLAN
    `target_app_id`; `fetch_application_source_repos` (30s, `transient`,
    `activity_id="fetch-source-repos-{target_app_id}"`); warn-only on empty `anchor_source_repo`;
    builds `arch_input` (no prior_artifacts, `peer_workflow_ids={"Data": data_workflow_id}`,
    `disposition=None`, relationship, source repos/ids, target_repo_url) and `data_input`
    (`prior_artifacts` = two Discovery paths per non-empty source,
    `peer_workflow_ids={"Architecture": arch_workflow_id}`); starts `ArchitectureWorkflow` then
    `DataWorkflow` via `start_child_workflow(..., parent_close_policy=ABANDON)` (arch FIRST);
    best-effort `update_application_line_projection` (Architecture, in_progress, 30s, `transient`,
    try/except swallow); LAST sets `status.target_app_id`/`architecture_workflow_id`/
    `data_workflow_id`/`status="architecture_in_flight"`; returns `(arch_handle, data_handle)`.
    (GOTCHA-SPAWN-*)
14. **NO gates, NO rework, NO merge loop, NO evidence, NO PR.** (§4)
15. **Resilience parity:** only the step-1 dispatch has a heartbeat (2min); no continue-as-new; no
    compensation; deterministic activity_ids + `run_ts`; children ABANDON; cancel only fully effective
    during the hold; total-failure → `"stuck-awaiting-recovery"` (clean completion, FAILED status,
    plan committed for `/resume`); fatal errors re-raise. (§5, GOTCHA-CANCEL-WINDOW,
    GOTCHA-RUN-OUTCOME-FAILED)
16. **All activity imports inside `with workflow.unsafe.imports_passed_through():`**; `_ = ActivityError`
    keep-alive line may be reproduced (no runtime effect). NO `workflow.patched(...)` anywhere.
    (GOTCHA-IMPORTS, GOTCHA-ACTIVITYERR-LIVE)
17. **Determinism:** `_now_iso()` = `workflow.now().isoformat()`; `run_ts` from
    `int(workflow.now().timestamp())` computed once; no `datetime.now()`, no `random`.
