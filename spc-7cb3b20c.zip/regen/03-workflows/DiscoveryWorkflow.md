# `DiscoveryWorkflow` — Discovery Assembly Line (ATOMIC regeneration spec)

> **Source of truth:** `temporal/olympus_workflows/workflows/discovery.py` (**1468** lines, HEAD
> `7cb3b20c`). Every `discovery.py:line` citation below is against that file at HEAD.
>
> **Class:** `@workflow.defn class DiscoveryWorkflow(LineWorkflowBase)` (`discovery.py:159-160`).
> Per-app workflow for the **Discovery** assembly line. Gate: **G-DC** (Discovery Complete).
>
> **Inherits:** `LineWorkflowBase` → `HILSignalsMixin`. **READ `_LineWorkflowBase.md` and
> `_HILSignalsMixin.md` first** — this spec REFERENCES inherited behavior and reproduces ONLY the
> overrides + the Discovery-specific `run()`/`_execute_discovery()` and helpers. Inherited methods
> (`gate_approved`, `gate_rejected`, `escalation_resolved`, `merge_retry`, `get_status`,
> `_set_step`, `_update_app_status`, `_submit_gate_evidence`, `_run_gate_pre_review`,
> `_wait_for_gate_decision`, `_reconcile_and_merge_with_retry_loop`, `_execution_ctx`,
> `_rework_count`, `_bump_rework`, the 8 HIL state vars + 6 HIL signals, the 19 base line-state
> vars) are **NOT re-reproduced** here — cross-reference the base spec.
>
> **Branch budget:** under the workflow-control-flow counting convention (block `if`/`elif`/`else`/
> `except`/`for`/`while`/`try` keywords, EXCLUDING the import-time builders at `discovery.py:121-126`
> and EXCLUDING inline ternaries) the file has **56** branch points. Including the 10 inline ternaries
> the raw total is 91. **Every** branch in `run`, `_execute_discovery`, and all instance-method helpers
> is reproduced below; the section sub-counts call out ternaries explicitly.
>
> ### ⚠️ WHAT CHANGED SINCE THE PRIOR BASELINE (HEAD refresh — read this delta first)
> The codebase advanced; the following are NEW or CHANGED at HEAD vs. the prior spec baseline. All
> citations elsewhere in this doc are already fixed to HEAD lines.
> 1. **NEW 5th replay-load-bearing patch `"discovery-commit-before-synthesis-v1"`**
>    (`discovery.py:342-344`). Gates an **incremental per-pass commit loop INSIDE the `while True`**
>    (`discovery.py:348-359`) that commits every completed *input* pass to the branch BEFORE synthesis
>    runs, so the synthesizer (and TCO) can hydrate prior passes via `artifact_ref` from git — making
>    synthesis input-resolution **branch-backed and agent-replica-independent**. (§4.2 BRANCH-NEW,
>    §5.5, §5.8.1, GOTCHA-CBS-1.)
> 2. **NEW instance var `_committed_pass_paths: dict[str, list[str]]`** (`discovery.py:197`) —
>    committed repo-relative paths per pass, populated by the new `_commit_one_pass`. (§2, GOTCHA-STATE-4.)
> 3. **NEW method `_commit_one_pass(pass_name, repo, branch, app_id)`** (`discovery.py:1150-1228`) —
>    commits ONE pass's artifacts (summary JSON + files) in a single `write_artifacts_batch`, records
>    `_committed_pass_paths[pass_name]`, optionally patches the output-ref. Used BOTH incrementally
>    (commit-before-synthesis) AND from the batched fallback. (§5.8.1.)
> 4. **`_dispatch_pass` gained `artifact_repo` + `artifact_ref` params** (`discovery.py:657-658`,
>    threaded into `AgentTaskInput` at 685-686) so a pass can hydrate inputs from the committed branch;
>    **and gained `heartbeat_timeout=timedelta(minutes=2)`** (`discovery.py:700`). (§5.1, GOTCHA-DP-4/5.)
> 5. **`_dispatch_discovery_patterns_variant` gained `heartbeat_timeout=timedelta(minutes=2)`**
>    (`discovery.py:831`). (§5.3.)
> 6. **`_run_synthesis_and_tco` gained `artifact_repo` + `artifact_ref` params** (`discovery.py:972-973`)
>    and now sources TCO inputs from `_committed_pass_paths` (preferred) falling back to `_pass_results`
>    (`discovery.py:1012-1018`). The synthesis loop passes repo/ref **only when commit-before-synthesis
>    is active** (`discovery.py:368-369`). (§5.5, GOTCHA-ST-3.)
> 7. **`_collect_all_pass_artifacts` now PREFERS `_committed_pass_paths[pass_name]`** over
>    `_pass_results[pass_name]` in BOTH loops (`discovery.py:1083-1086`, `1095`) so synthesis fetches
>    each pass via `artifact_ref`. (§5.7, GOTCHA-COL-3.)
> 8. **`_commit_artifacts_batched` REWRITTEN** (`discovery.py:1123-1148`): now iterates
>    `DISCOVERY_PASSES` **keys** (not `.items()`), **reuses** already-`_committed_pass_paths` entries
>    instead of re-committing, and delegates each remaining pass to `_commit_one_pass`. (§5.8.1,
>    GOTCHA-COMMITB-1.)
> 9. **§8 RESILIENCE corrected:** heartbeats are NO LONGER "none" — the agent `dispatch_agent_task`
>    activities now carry a **2-minute `heartbeat_timeout`** (`discovery.py:700`, `831`).
> 10. **Patch count is now FIVE** (was four): the four prior IDs PLUS
>     `"discovery-commit-before-synthesis-v1"`.

---

## 0. WHAT IT OVERRIDES vs INHERITS (do this first)

| Member | Status | Where |
|--------|--------|-------|
| `run()` | **defines** (`@workflow.run`) — base has none | §4.1 |
| `_execute_discovery()` | **new private** (the real orchestration body) | §4.2 |
| `reclassify_complexity` | **new `@workflow.signal`** (Discovery-only) | §3.1 |
| `_dispatch_pass` | **new** (Discovery batches passes; does NOT use base `_dispatch_agent`) | §5.1 |
| `_select_discovery_patterns_variant` | **new** (pure, sync) | §5.2 |
| `_dispatch_discovery_patterns_variant` | **new** | §5.3 |
| `_run_parallel_passes` | **new** | §5.4 |
| `_run_synthesis_and_tco` | **new** | §5.5 |
| `_extract_pass_content` | **new** (sync) | §5.6 |
| `_collect_all_pass_artifacts` | **new** (sync) | §5.7 |
| `_commit_artifacts` / `_commit_artifacts_batched` / **`_commit_one_pass`** / `_commit_artifacts_legacy` | **new** (Discovery commits per-PASS, not per-step; does NOT use base `_commit_step_artifacts`) | §5.8 |
| `_create_gate_pr_discovery` | **new** (Discovery-specific PR body; does NOT use base `_create_gate_pr`) | §5.9 |
| `_build_evidence_data` | **OVERRIDES** base — uses `passes` key not `steps`; keyed by pass_name | §5.10 |
| `_calculate_and_record_score` | **new** | §5.11 |
| `gate_approved` / `gate_rejected` / `escalation_resolved` / `merge_retry` | **inherited, MUST NOT redefine** (GOTCHA-SIG0) | base spec §3 |
| `get_status` | **inherited, MUST NOT redefine** (GOTCHA-Q1) | base spec §16 |
| `_submit_gate_evidence` / `_run_gate_pre_review` / `_wait_for_gate_decision` / `_reconcile_and_merge_with_retry_loop` / `_update_app_status` / `_set_step` / `_execution_ctx` / `_rework_count` / `_bump_rework` | **inherited, called as-is** | base spec |
| `_task_type_prefix` / `_rework_gate_key_for_step` / `_primary_skill_for_step` / `_evidence_step_metadata` / `_evidence_steps_iter` | **NOT overridden** — base defaults apply | base spec §4 |

> ⚠️ **GOTCHA-OVERRIDE-1 (Discovery DOES NOT use the base dispatch/commit machinery):** Discovery
> ships its own `_dispatch_pass` (§5.1) and `_commit_artifacts*` / `_commit_one_pass` (§5.8) instead of
> inheriting `_dispatch_agent` / `_commit_step_artifacts`. Why: Discovery commits all passes **as a
> batch per-pass** (not per-step), and its evidence shape uses `passes` keyed by `pass_name` rather
> than `steps` keyed by `step_name` (`discovery.py:161-171`). A rebuild MUST NOT route Discovery
> through the base helpers; the metadata bucket (`_agent_metadata`) IS shared, but the artifact bucket
> is `_pass_results` (Discovery's own), NOT the base `_step_results`. (See GOTCHA-STATE-1.)
> ⚠️ **GOTCHA-OVERRIDE-2 (`_build_evidence_data` override is structurally different):** base emits
> `{"assembly_line", "app_id", "current_step", "steps": {...}}`; Discovery emits
> `{"assembly_line", "app_id", "pass_count", "passes": {...}}` (`discovery.py:1438-1443`). Note
> **NO `current_step` key** and a computed `pass_count`. The base `_submit_gate_evidence`
> threshold-widening loop iterates `slim_evidence.get("steps", {})` — which on a Discovery bundle is
> **empty** because Discovery uses `passes`, not `steps`. (See GOTCHA-SE-DISC.)

---

## 1. MODULE-LEVEL CONSTANTS & IMPORT-TIME BUILDERS (`discovery.py:91-156`)

These run at **module import**, not in the workflow. They populate two dicts the workflow reads.

### 1.1 `_build_discovery_passes() -> dict[str, dict]` (`discovery.py:107-134`)
Loads Discovery analysis passes from the authoritative contract. Pseudocode:
```text
from olympus_contracts import get_line
passes = {}
for step in get_line("Discovery").evidence_steps():        # discovery.py:121  LOOP
    if not step.skills:                                    # discovery.py:122  BRANCH → skip steps with no skills
        continue
    artifact = step.artifact_filename or (                 # discovery.py:124
        f"{step.outputs.artifacts[0]}.json"                # discovery.py:125
        if step.outputs.artifacts else f"{step.id}.json"   # discovery.py:126-128  BRANCH (ternary)
    )
    passes[step.id] = {"skill_id": step.skills[0],         # discovery.py:129-133
                       "artifact": artifact, "kind": "agent"}
return passes
DISCOVERY_PASSES = _build_discovery_passes()               # discovery.py:137
```
- Each entry: `{"skill_id": <first skill>, "artifact": <first output artifact + ".json" | step.id+".json">, "kind": "agent"}`.
- ⚠️ **GOTCHA-IMPORT-1 (KeyError-at-startup drift guard):** the comment block (`discovery.py:27-34`)
  states `DISCOVERY_PASSES` and `STEP_WEIGHTS` are built from the authoritative yaml at import, so a
  contract step rename **without** a matching edit to the literal step-id strings in this file
  (`self._set_step("catalog", ...)`, `STEP_WEIGHTS["catalog"]`, etc.) raises **`KeyError` at module
  import / first `STEP_WEIGHTS[...]` lookup**, not silently. A rebuild MUST preserve this coupling:
  the workflow indexes `STEP_WEIGHTS` by literal contract step ids and will `KeyError` if a key is
  absent.

### 1.2 `_build_step_weights() -> dict[str, float]` (`discovery.py:143-150`)
```text
from olympus_contracts import step_weights as _contract_weights
return _contract_weights("Discovery")
STEP_WEIGHTS = _build_step_weights()                       # discovery.py:153
```
Per-step progress weights; the workflow emits **cumulative sums** of these as steps complete.

### 1.3 Other constants
- `MAX_REWORK_ITERATIONS = 3` (`discovery.py:156`) — the rework ceiling. (NOT inclusive — see §4.2.)
- `DISCOVERY_PATTERNS_DEFAULT_SKILL` and `select_discovery_patterns_skill` imported from
  `discovery_patterns_router` (`discovery.py:93-96`) — **pure Python, no Temporal imports**, safe to
  call inside `@workflow.defn`.

### 1.4 CLASSVARS (`discovery.py:173-180`) — subclass configuration surface the base reads
```text
ASSEMBLY_LINE  = AssemblyLine.DISCOVERY     # discovery.py:174
ARTIFACT_ROOT  = "discovery"                # discovery.py:175
LINE_LABEL     = "Discovery"                # discovery.py:176
STATUS_PREFIX  = "discovery"                # discovery.py:177
STEPS          = DISCOVERY_PASSES           # discovery.py:178  (base helpers referencing STEPS resolve)
STEP_WEIGHTS   = STEP_WEIGHTS               # discovery.py:179
SINGLE_GATE_KEY = "G-DC"                     # discovery.py:180
```
- ⚠️ **GOTCHA-CV-1 (`STEPS = DISCOVERY_PASSES`):** Discovery aliases `STEPS` to its `DISCOVERY_PASSES`
  so that any inherited base helper that reads `self.STEPS` (e.g. `_primary_skill_for_step`,
  `_evidence_step_metadata`) still works. But Discovery overrides `_build_evidence_data` so the base
  `_evidence_steps_iter()`→`STEPS.items()` path is NOT how Discovery builds evidence — it builds from
  `DISCOVERY_PASSES` directly in its own override. `SINGLE_GATE_KEY="G-DC"` means the inherited
  `_rework_gate_key_for_step` returns `"G-DC"` for every step (base spec §4.2).
- ⚠️ **GOTCHA-CV-2 (`STEP_WEIGHTS = STEP_WEIGHTS`):** the class attr is assigned the module global of
  the same name (`discovery.py:179`). A rebuild must ensure the class-level name resolves to the
  contract-loaded dict, not shadow it with `{}`.

---

## 2. STATE — instance vars (`__init__`, `discovery.py:182-197`)

`__init__` calls `super().__init__()` **first** (`discovery.py:183`) → initializes all 8 HIL vars
(`_HILSignalsMixin.md` §1) + all 19 base line-state vars (`_LineWorkflowBase.md` §2). Then Discovery
adds **three** of its own (was two — `_committed_pass_paths` is NEW at HEAD):

| Var | Type | Initial | Line | Mutated by → value | When |
|-----|------|---------|------|---------------------|------|
| `_complexity_tier` | `ComplexityTier \| None` | `None` | 185 | `run()` sets `= input.complexity_tier` (`discovery.py:213`); `reclassify_complexity` signal sets `= ComplexityTier(new_tier)` on valid value (`discovery.py:640`) | run start; any time a `reclassify_complexity` signal lands |
| `_pass_results` | `dict[str, list[str]]` | `{}` | 190 | written per-pass: `_pass_results[pass_name] = result.output_artifacts` throughout `_execute_discovery`/`_run_parallel_passes`/`_run_synthesis_and_tco` | each pass completion |
| **`_committed_pass_paths`** | `dict[str, list[str]]` | `{}` | **197** | written by `_commit_one_pass` → `_committed_pass_paths[pass_name] = committed_paths` (`discovery.py:1227`) | each incremental / batched pass commit |

> ⚠️ **GOTCHA-STATE-1 (`_pass_results` is Discovery's artifact bucket — NOT base `_step_results`):**
> the docstring (`discovery.py:187-189`) is explicit: `_pass_results` is keyed by **pass name**, is
> **distinct** from the base `_step_results`, and exists so the `_commit_artifacts` batching pattern
> keeps working. The base `_step_results` is **never populated by Discovery** (it stays `{}`). A
> rebuild MUST track pass artifacts in `_pass_results`, not the inherited bucket.
> ⚠️ **GOTCHA-STATE-2 (`_complexity_tier` is set BUT never read in the orchestration body):** `run()`
> stores `input.complexity_tier` into `_complexity_tier` (line 213) and `reclassify_complexity`
> mutates it (line 640), and there is a comment at lines 316-317 noting "the signal handler updates
> `self._complexity_tier` directly" — but **no branch in `_execute_discovery` reads
> `self._complexity_tier`**. It is observable state for the dashboard / downstream lines only. A
> rebuild MUST still maintain it, but its value does NOT alter control flow within Discovery.
> ⚠️ **GOTCHA-STATE-3 (`_agent_metadata` IS the shared base bucket):** Discovery writes
> `_agent_metadata[pass_name]` / `_agent_metadata[skill_id]` (the inherited base dict) in
> `_dispatch_pass`/`_dispatch_discovery_patterns_variant`. So the metadata bucket is keyed by **pass
> name** (and additionally by the variant skill_id for the Pass-1 specialist). A rebuild keeps
> `_agent_metadata` as the shared dict.
> ⚠️ **GOTCHA-STATE-4 (NEW: `_committed_pass_paths` is the branch-backed-input enabler):** populated
> ONLY by `_commit_one_pass` (`discovery.py:1227`), it records the repo-relative paths a pass landed
> at on the per-app branch. It is consumed by `_collect_all_pass_artifacts` (§5.7) and
> `_run_synthesis_and_tco`'s TCO-input assembly (§5.5) so synthesis/TCO read prior passes via
> `artifact_ref` (git) rather than container-local agent workspace the NLB fan-out doesn't share. A
> rebuild MUST add this dict, write it from `_commit_one_pass`, and prefer it over `_pass_results`
> wherever §5.7/§5.5 do.

---

## 3. SIGNALS / QUERIES / UPDATES

### 3.0 Inherited surface (DO NOT redefine)
- **Signals (base, `async def`):** `gate_approved`, `gate_rejected`, `escalation_resolved`,
  `merge_retry` — `_LineWorkflowBase.md` §3. ⚠️ **MUST NOT be overridden** (GOTCHA-SIG0): Temporal
  raises on duplicate signal registration. Discovery does NOT redefine any of them.
- **Signals (HIL mixin, sync `def`):** `approve_plan`, `provide_plan_feedback`, `approve_research`,
  `provide_feedback`, `approve`, `cancel_workflow` — `_HILSignalsMixin.md` §2. Inherited. Discovery
  uses **`self.cancelled`** (set by `cancel_workflow`) — it is the kill switch threaded into the
  inherited gate-wait and merge-loop predicates.
- **Query (base):** `get_status` — `_LineWorkflowBase.md` §16. The ONLY query. ⚠️ MUST NOT be
  redefined. Discovery adds NO new queries.
- **Updates:** none anywhere in this hierarchy.

### 3.1 `reclassify_complexity(self, new_tier: str) -> None` — `@workflow.signal` (`discovery.py:632-643`)
The single Discovery-specific signal. Payload: `new_tier: str`. Semantics: "Pass 1 revealed the app
is more/less complex than initially classified." Pseudocode:
```text
@workflow.signal
async def reclassify_complexity(self, new_tier):
    try:                                            # discovery.py:639
        self._complexity_tier = ComplexityTier(new_tier)   # discovery.py:640
    except ValueError:                              # discovery.py:641
        pass                                        # discovery.py:642  ← ignore invalid tier values
    self._updated_at = _now_iso()                   # discovery.py:643
```
- **Branches (2):** `try` (639) / `except ValueError` (641).
- Buffers nothing onto a queue. Directly mutates `_complexity_tier`. `ComplexityTier(new_tier)`
  raises `ValueError` for any string not in the `ComplexityTier` enum → swallowed, state unchanged.
- ⚠️ **GOTCHA-SIG-RC1 (no `wait_condition` consumes this signal):** unlike the gate signals (consumed
  by `_wait_for_gate_decision`'s predicate), `reclassify_complexity` has **no waiting predicate** in
  the workflow. It is a fire-and-forget state mutation observed only via downstream reads /
  dashboard. There is NO point in `_execute_discovery` that blocks on `_complexity_tier` changing.
  The comment at `discovery.py:316-317` ("Check if complexity tier was reclassified ... The signal
  handler updates self._complexity_tier directly") is informational — there is **no actual check
  branch** there. A rebuild MUST register this signal (`async def`, name `reclassify_complexity`) but
  must NOT add a wait on it.
- ⚠️ **GOTCHA-SIG-RC2 (`async def` but no await):** declared `async` (like the base gate signals) but
  the body has no `await`. Harmless; keep `async def` to match registration semantics.

---

## 4. CONTROL FLOW — `run()` and `_execute_discovery()`

### 4.1 `run(self, input: LineWorkflowInput) -> str` — `@workflow.run` (`discovery.py:199-244`)
Thin wrapper: initialize state, derive branch/workspace keys, call `_execute_discovery` inside a
`try`, and on ANY exception mark the workflow FAILED + best-effort push DB status, then re-raise.
```text
@workflow.run
async def run(self, input):
    # --- Initialize observable state ---
    self._status      = WorkflowStatus.RUNNING            # discovery.py:210
    self._started_at  = _now_iso()                        # discovery.py:211
    self._updated_at  = self._started_at                  # discovery.py:212
    self._complexity_tier = input.complexity_tier         # discovery.py:213

    app_id = input.app_id                                 # discovery.py:215
    self._app_id = app_id                                 # discovery.py:216
    repo        = input.artifact_repo                     # discovery.py:217
    source_repo = input.source_repo                       # discovery.py:218

    # --- Derive a per-run branch suffix from the workflow id ---
    wf_id = workflow.info().workflow_id                   # discovery.py:220
    run_suffix = wf_id.rsplit("-", 1)[-1] if "-" in wf_id else wf_id[:8]   # discovery.py:221  BRANCH (ternary)
    branch = f"olympus/discovery/{app_id}/{run_suffix}"   # discovery.py:222
    workspace_key = f"discovery-{app_id}-{run_suffix}"    # discovery.py:227

    try:                                                  # discovery.py:229
        return await self._execute_discovery(
            input, app_id, repo, source_repo, branch, workspace_key)   # discovery.py:230-232
    except Exception:                                     # discovery.py:233  BRANCH (catch-all)
        self._status       = WorkflowStatus.FAILED        # discovery.py:235
        self._current_step = "failed"                     # discovery.py:236
        self._updated_at   = _now_iso()                   # discovery.py:237
        try:                                              # discovery.py:238
            await self._update_app_status(
                app_id, "discovery_failed", "failed", "Discovery")   # discovery.py:239-241
        except Exception:                                 # discovery.py:242
            pass    # Best-effort — don't mask the original error   # discovery.py:243
        raise                                             # discovery.py:244  ← re-raise original
```
- **Branches (4):** the ternary `run_suffix` (221); the outer `try/except Exception` (229/233);
  the inner best-effort `try/except Exception:pass` (238/242).
- **Returns:** the string returned by `_execute_discovery` (`"completed"` / `"cancelled"` /
  `"failed"`), OR re-raises on exception.
- ⚠️ **GOTCHA-RUN-1 (`run_suffix` determinism):** `workflow.info().workflow_id` is deterministic
  under replay. The branch name `olympus/discovery/{app_id}/{run_suffix}` and `workspace_key`
  `discovery-{app_id}-{run_suffix}` are derived once and reused for ALL passes (so the source repo
  is cloned once and prior artifacts are visible to later passes — `discovery.py:224-227`). A rebuild
  MUST derive these from `workflow_id`, not from a uuid/random, or branch names diverge on replay.
- ⚠️ **GOTCHA-RUN-2 (`rsplit("-",1)[-1]` vs `[:8]`):** if the workflow id contains a `-`, the suffix
  is the substring after the LAST `-`; otherwise the first 8 chars. A rebuild must match BOTH cases.
- ⚠️ **GOTCHA-RUN-3 (failure projection is best-effort, original error always re-raised):** the inner
  `try/except…pass` (238-243) ensures a DB-status-write failure during failure handling does NOT mask
  the original exception. The outer handler ALWAYS `raise`s (244) → the workflow fails. A rebuild
  MUST set `FAILED`+`failed`+timestamp, attempt the status push, swallow its error, and re-raise.

### 4.2 `_execute_discovery(self, input, app_id, repo, source_repo, branch, workspace_key) -> str` (`discovery.py:246-626`)
The real orchestration body. **Linear prelude (Steps 1-3) then an unbounded `while True` synthesis+
gate+rework loop.** Reproduced in full, every branch preserved.

```text
async def _execute_discovery(self, input, app_id, repo, source_repo, branch, workspace_key):

    # ============ STEP 1: Catalog ============
    await self._set_step("catalog", 0.0)                                  # discovery.py:257
    catalog_result = await self._dispatch_pass(                           # discovery.py:258-264
        app_id=app_id, pass_name="catalog",
        input_artifacts=list(input.prior_artifacts),
        source_repo=source_repo, workspace_key=workspace_key)
    self._pass_results["catalog"] = catalog_result.output_artifacts        # discovery.py:265

    # ============ STEP 2: Structural Analysis (Pass 1) + optional variant specialist ============
    await self._set_step("structural-analysis", STEP_WEIGHTS["catalog"])   # discovery.py:280
    variant_skill = self._select_discovery_patterns_variant(               # discovery.py:281-283
        catalog_result.output_artifacts)
    dispatches = [                                                         # discovery.py:284-292
        self._dispatch_pass(app_id=app_id, pass_name="structural-analysis",
            input_artifacts=catalog_result.output_artifacts,
            source_repo=source_repo, workspace_key=workspace_key)
    ]
    if variant_skill and variant_skill != DISCOVERY_PATTERNS_DEFAULT_SKILL:   # discovery.py:293  BRANCH
        dispatches.append(                                                 # discovery.py:294-302
            self._dispatch_discovery_patterns_variant(
                app_id=app_id, skill_id=variant_skill,
                input_artifacts=catalog_result.output_artifacts,
                source_repo=source_repo, workspace_key=workspace_key))
    fan_out = await asyncio.gather(*dispatches)                            # discovery.py:303  ★PARALLEL
    structural_result = fan_out[0]                                         # discovery.py:304
    self._pass_results["structural-analysis"] = list(structural_result.output_artifacts)  # discovery.py:305
    if len(fan_out) > 1:                                                   # discovery.py:306  BRANCH
        variant_result = fan_out[1]                                        # discovery.py:307
        self._pass_results["structural-analysis"].extend(                  # discovery.py:312-314
            variant_result.output_artifacts)     # merge specialist outputs into the structural bucket

    # (comment-only: complexity tier may have been reclassified via signal during pass 1; no branch here)  # discovery.py:316-317

    # ============ STEPS 3a-3c: Fan-out Passes 2,3,4 in parallel ============
    await self._run_parallel_passes(                                       # discovery.py:324-329
        app_id, list(self._pass_results["structural-analysis"]),
        source_repo, workspace_key)

    # ============ NEW: commit-before-synthesis patch gate ============
    commit_before_synthesis = workflow.patched(                           # discovery.py:342-344
        "discovery-commit-before-synthesis-v1")

    # ============ Synthesis + Gate loop (supports rework) ============
    while True:                                                            # discovery.py:347  ★UNBOUNDED LOOP

        # ---- NEW: commit every completed INPUT pass to the branch BEFORE synthesis ----
        if commit_before_synthesis:                                       # discovery.py:348  BRANCH-NEW (patch gate)
            for pass_name in DISCOVERY_PASSES:                            # discovery.py:352  LOOP
                if pass_name in ("synthesis", "tco-baseline",
                                 "gate-readiness-check"):                  # discovery.py:353-354  BRANCH → skip non-input passes
                    continue                                              # discovery.py:355
                if self._pass_results.get(pass_name):                     # discovery.py:356  BRANCH → only commit passes with results
                    await self._commit_one_pass(pass_name, repo, branch, app_id)  # discovery.py:357-359

        # ---- STEP 4: Synthesis + TCO baseline in parallel ----
        synthesis_input_artifacts = self._collect_all_pass_artifacts()     # discovery.py:362
        synthesis_result, tco_result = await self._run_synthesis_and_tco(  # discovery.py:363-370
            app_id=app_id, synthesis_input_artifacts=synthesis_input_artifacts,
            source_repo=source_repo, workspace_key=workspace_key,
            artifact_repo=(repo if commit_before_synthesis else ""),       # discovery.py:368  BRANCH (ternary)
            artifact_ref=(branch if commit_before_synthesis else ""))      # discovery.py:369  BRANCH (ternary)
        self._pass_results["synthesis"]    = synthesis_result.output_artifacts  # discovery.py:371
        self._pass_results["tco-baseline"] = tco_result.output_artifacts        # discovery.py:372

        # ---- STEP 5: Commit artifacts to Git ----
        await self._set_step("commit-artifacts",                           # discovery.py:375-384
            STEP_WEIGHTS["catalog"] + STEP_WEIGHTS["structural-analysis"]
            + STEP_WEIGHTS["business-logic-extraction"]
            + STEP_WEIGHTS["quality-risk-assessment"]
            + STEP_WEIGHTS["ux-accessibility-assessment"]
            + STEP_WEIGHTS["synthesis"] + STEP_WEIGHTS["tco-baseline"])
        artifact_paths = await self._commit_artifacts(repo, branch, app_id)  # discovery.py:385

        # ---- STEP 5b: Persist decomposition map (best-effort) ----
        try:                                                               # discovery.py:392
            catalog_json   = self._extract_pass_content("catalog")         # discovery.py:393
            synthesis_json = self._extract_pass_content("synthesis")       # discovery.py:394
            if catalog_json or synthesis_json:                             # discovery.py:395  BRANCH
                await workflow.execute_activity(
                    persist_decomposition_map,
                    PersistDecompositionMapInput(app_id=app_id,
                        catalog_json=catalog_json, synthesis_json=synthesis_json),  # discovery.py:396-402
                    start_to_close_timeout=timedelta(seconds=30),
                    retry_policy=RETRY_POLICIES["transient"],
                    activity_id="persist-decomposition-map")               # discovery.py:403-406
        except Exception:                                                  # discovery.py:407  BRANCH (best-effort)
            workflow.logger.exception(                                     # discovery.py:408-410
                "persist_decomposition_map failed; insights will be empty")

        # ---- STEP 5c: Project Discovery side effects onto application (best-effort) ----
        try:                                                               # discovery.py:421
            side_effects_input = PersistDiscoverySideEffectsInput(          # discovery.py:422-439
                app_id=app_id,
                catalog_json        = self._extract_pass_content("catalog"),
                structural_json     = self._extract_pass_content("structural-analysis"),
                business_logic_json = self._extract_pass_content("business-logic-extraction"),
                quality_risk_json   = self._extract_pass_content("quality-risk-assessment"),
                ux_accessibility_json = self._extract_pass_content("ux-accessibility-assessment"),
                synthesis_json      = self._extract_pass_content("synthesis"),
                tco_json            = self._extract_pass_content("tco-baseline"))
            await workflow.execute_activity(
                persist_discovery_side_effects, side_effects_input,        # discovery.py:440-446
                start_to_close_timeout=timedelta(seconds=30),
                retry_policy=RETRY_POLICIES["transient"],
                activity_id="persist-discovery-side-effects")
        except Exception:                                                  # discovery.py:447  BRANCH (best-effort)
            workflow.logger.exception(
                "persist_discovery_side_effects failed; application row will keep stale fields")  # discovery.py:448-451

        # ---- STEP 5d: Persist capability-catalog onto grain tables (best-effort) ----
        try:                                                               # discovery.py:460
            cap_json = self._extract_pass_content("capability-extraction")  # discovery.py:461
            if cap_json:                                                   # discovery.py:462  BRANCH
                await workflow.execute_activity(
                    persist_capability_catalog,
                    PersistCapabilityCatalogInput(app_id=app_id,           # discovery.py:463-472
                        portfolio_id=input.portfolio_id,
                        capability_catalog_json=cap_json,
                        capability_catalog_artifact_ref=f"discovery/{app_id}/capability-catalog.json"),
                    start_to_close_timeout=timedelta(seconds=30),
                    retry_policy=RETRY_POLICIES["transient"],
                    activity_id="persist-capability-catalog")              # discovery.py:473-476
        except Exception:                                                  # discovery.py:477  BRANCH (best-effort)
            workflow.logger.exception(
                "persist_capability_catalog failed; capability + system grain rows will not be minted ...")  # discovery.py:478-481

        # ---- STEP 6: Create PR ----
        await self._set_step("create-pr",                                  # discovery.py:484-494
            <cumsum: catalog + structural-analysis + business-logic-extraction
             + quality-risk-assessment + ux-accessibility-assessment + synthesis
             + tco-baseline + commit-artifacts>)
        pr_result = await self._create_gate_pr_discovery(repo, branch, app_id)  # discovery.py:495

        # ---- STEP 6b: Create gate record in DB ----
        wf_id = workflow.info().workflow_id                                # discovery.py:498
        gate_record = await workflow.execute_activity(                     # discovery.py:499-510
            create_gate_record,
            CreateGateRecordInput(gate_type="G-DC", app_id=app_id,
                portfolio_id=input.portfolio_id, workflow_id=wf_id,
                evidence_package_url=pr_result.pr_url),
            start_to_close_timeout=timedelta(seconds=30),
            retry_policy=RETRY_POLICIES["transient"])

        # ---- STEP 7: Check gate criteria + submit evidence ----
        gate_id = gate_record.gate_id                                      # discovery.py:515
        await self._submit_gate_evidence(                                  # discovery.py:516-525
            gate_id=gate_id, gate_type=GateType.G_DC, app_id=app_id,
            artifact_paths=artifact_paths, pr_url=pr_result.pr_url,
            assembly_line="Discovery", step="gate-review",
            forward_risk_tier=False)            # ★ Discovery predates F3 risk-tier plumbing

        # ---- STEP 7b: Gate Readiness Check (advisory, fault-tolerant) ----
        await self._set_step("gate-readiness-check",                       # discovery.py:533-544
            <cumsum: ... + commit-artifacts + create-pr>)
        await self._run_gate_pre_review(                                   # discovery.py:545-551
            gate_id, "G-DC", artifact_paths,
            artifact_repo=repo, artifact_ref=branch)

        # ---- Update status: entering gate review ----
        await self._update_app_status(app_id, "gate_review", "gate-review", "Discovery")  # discovery.py:554-556

        # ---- STEP 8: Wait for gate decision ----
        await self._set_step("gate-review",                                # discovery.py:559-571
            <cumsum: ... + create-pr + gate-readiness-check>)
        decision = await self._wait_for_gate_decision(GateType.G_DC)       # discovery.py:572

        if decision == "cancelled":                                        # discovery.py:574  BRANCH A
            return "cancelled"                                             # discovery.py:575

        if decision == "approved":                                         # discovery.py:577  BRANCH B
            await self._reconcile_and_merge_with_retry_loop(               # discovery.py:583-588
                repo=repo, pr_number=pr_result.pr_number,
                gate_id=gate_id, merge_method="merge")
            await self._calculate_and_record_score(app_id)                 # discovery.py:590
            await self._update_app_status(
                app_id, "discovery_complete", "completed", "Discovery")    # discovery.py:591-593
            # (comment: do NOT auto-start Rationalization — wave-scoped; see GOTCHA-FLOW-3)  # discovery.py:595-602
            self._status       = WorkflowStatus.COMPLETED                  # discovery.py:604
            self._progress_pct = 100.0                                     # discovery.py:605
            self._current_step = "completed"                               # discovery.py:606
            self._updated_at   = _now_iso()                                # discovery.py:607
            return "completed"                                             # discovery.py:608

        # ---- Gate rejected → rework ----                                 # discovery.py:610
        self._bump_rework("G-DC")                                          # discovery.py:611  ★ COUNTER BUMP
        if self._rework_count("G-DC") > MAX_REWORK_ITERATIONS:             # discovery.py:612  BRANCH C
            self._status       = WorkflowStatus.FAILED                     # discovery.py:613
            self._current_step = "max-rework-exceeded"                     # discovery.py:614
            self._updated_at   = _now_iso()                                # discovery.py:615
            await self._update_app_status(
                app_id, "discovery_failed", "max-rework-exceeded", "Discovery")  # discovery.py:616-618
            return "failed"                                                # discovery.py:619

        # ---- Re-run parallel passes with feedback, then loop to synthesis ----
        await self._run_parallel_passes(                                   # discovery.py:622-626
            app_id, list(self._pass_results["structural-analysis"]),
            source_repo, workspace_key)
        # (loop back to `while True` top → re-commit-input-passes → re-synthesis → re-commit → re-PR → re-gate)
```

**Branch inventory for `_execute_discovery` (13 control-flow branches incl. ternaries + 1 unbounded loop, +2 inner loops):**
1. `if variant_skill and variant_skill != DISCOVERY_PATTERNS_DEFAULT_SKILL:` (293) — append specialist dispatch only when router picked a non-base variant.
2. `if len(fan_out) > 1:` (306) — merge specialist outputs into the structural bucket only when the specialist was dispatched.
3. `while True:` (347) — the synthesis+gate+rework loop.
4. **NEW** `if commit_before_synthesis:` (348) — patch-gated incremental input-pass commit block.
5. **NEW** `for pass_name in DISCOVERY_PASSES:` (352) — inner commit loop.
6. **NEW** `if pass_name in ("synthesis","tco-baseline","gate-readiness-check"): continue` (353) — skip non-input passes.
7. **NEW** `if self._pass_results.get(pass_name):` (356) — only commit a pass that produced results.
8. **NEW** ternaries `artifact_repo=(repo if commit_before_synthesis else "")` (368) / `artifact_ref=(branch if … else "")` (369) — pass repo/ref into synthesis+TCO only in commit-before-synthesis mode.
9. `try` / `except Exception` (392/407) — best-effort decomposition-map persist.
10. `if catalog_json or synthesis_json:` (395) — only call persist if at least one JSON is non-empty.
11. `try` / `except Exception` (421/447) — best-effort side-effects persist.
12. `try` / `except Exception` (460/477) — best-effort capability-catalog persist.
13. `if cap_json:` (462) — only persist capability catalog if the artifact JSON is non-empty.
14. `if decision == "cancelled":` (574) — **BRANCH A** → return `"cancelled"`.
15. `if decision == "approved":` (577) — **BRANCH B** → merge, score, complete, return `"completed"`.
16. `if self._rework_count("G-DC") > MAX_REWORK_ITERATIONS:` (612) — **BRANCH C** → fail on rework exhaustion. (Implicit else = reject path: bump done, re-run passes, loop.)

> ⚠️ **GOTCHA-FLOW-1 (the gate decision tri-state → 4 routes):** `_wait_for_gate_decision` returns
> exactly one of `"cancelled"` / `"approved"` / `"rejected"` (base spec §13). Discovery routes:
> `"cancelled"`→return `"cancelled"` (575); `"approved"`→merge+score+complete (577-608);
> **else (rejected)** falls through to the rework block (611+). There is NO `elif`/`else` keyword —
> `"rejected"` is the **fall-through** after the two `if`s. A rebuild MUST treat any non-approved,
> non-cancelled return as the rework path.
> ⚠️ **GOTCHA-FLOW-2 (counter is bumped in the SUBCLASS, off-by-one ceiling):** `_bump_rework("G-DC")`
> is called FIRST (611), THEN the check `_rework_count("G-DC") > MAX_REWORK_ITERATIONS` (612). With
> `MAX_REWORK_ITERATIONS=3`: 1st reject → count=1 (≤3, rework); 2nd → 2 (rework); 3rd → 3 (rework);
> **4th reject → count=4 (>3) → FAIL**. So Discovery tolerates **3 reworks** and fails on the 4th
> rejection. The base `_wait_for_gate_decision` does NOT touch `_rework_iterations` (base GOTCHA-WG5);
> bump happens ONLY here. A rebuild MUST bump-then-compare-strictly-greater, giving exactly 3 reworks.
> ⚠️ **GOTCHA-FLOW-3 (Discovery does NOT chain to Rationalization):** the comment block at
> `discovery.py:595-602` is load-bearing intent: on approval Discovery does **NOT** fire
> `start_next_line_workflow`. Rationalization is wave-scoped (the wave owner starts
> `WaveRationalizationWorkflow` from the UI once all wave apps finish Discovery). A previous version
> auto-started a per-app RationalizationWorkflow and broke wave scoping (observed on CFWheels
> 2026-05-05). A rebuild MUST NOT auto-start any successor line on Discovery completion.
> ⚠️ **GOTCHA-FLOW-4 (rework re-runs ONLY parallel passes 2-4, NOT catalog/structural):** on reject,
> the rework path re-dispatches `_run_parallel_passes` (622-626) using the **already-stored**
> `_pass_results["structural-analysis"]` as input, then loops to re-run synthesis+TCO. **Catalog
> (Step 1) and Structural-Analysis (Pass 1) are NOT re-run** — they ran once in the linear prelude
> (257-329) which is OUTSIDE the `while True`. So the rework loop iterates: [commit-input-passes if
> patched] → synthesis+tco → commit → persists → PR → gate-record → submit-evidence → readiness-check
> → wait. The very FIRST loop iteration also runs synthesis+tco (it follows the prelude's first
> `_run_parallel_passes`). A rebuild MUST keep catalog+structural OUTSIDE the loop and re-run only
> passes 2-4 + synthesis on rework. (On reject, `_run_parallel_passes` re-dispatch picks up
> `_rework_feedback["G-DC"]` via `_dispatch_pass`; see §5.1 / GOTCHA-DP-1.)
> ⚠️ **GOTCHA-FLOW-5 (`forward_risk_tier=False`):** Discovery calls `_submit_gate_evidence` with
> `forward_risk_tier=False` (525) because it predates F3 risk-tier plumbing. Per base GOTCHA-SE2 this
> builds the `check_gate_criteria` input WITHOUT `evidence_data` and WITHOUT `risk_tier` (bare 4-field
> shape). A rebuild MUST pass `False` here, not the default `True`.
> ⚠️ **GOTCHA-FLOW-6 (cumulative-progress sums are hand-written and must match exactly):** each
> `_set_step` second arg is a literal sum of `STEP_WEIGHTS[...]` terms (280, 375-384, 484-494,
> 533-544, 559-571). The terms accumulate as steps complete (catalog → +structural → +the 3 parallel
> passes → +synthesis → +tco → +commit-artifacts → +create-pr → +gate-readiness-check). ⚠️ Note the
> sums use the THREE legacy parallel passes' weights (business-logic-extraction,
> quality-risk-assessment, ux-accessibility-assessment) but **NOT** the patch-gated extra passes
> (`data-domain-discovery`, `shared-database-analysis`, `capability-extraction`). The comment block
> at `discovery.py:27-34` flags this hand-sum as a drift vector. A rebuild MUST reproduce these EXACT
> term lists; a missing/extra term changes the `progress_pct` the dashboard renders and (if a key is
> absent from `STEP_WEIGHTS`) raises `KeyError`.
> ⚠️ **GOTCHA-FLOW-7 (success terminal state is set BEFORE return):** on approval the workflow sets
> `_status=COMPLETED`, `_progress_pct=100.0`, `_current_step="completed"`, `_updated_at` (604-607)
> THEN returns `"completed"`. On rework-exhaustion it sets `_status=FAILED`,
> `_current_step="max-rework-exceeded"` (613-614) THEN pushes status `discovery_failed`/
> `max-rework-exceeded` and returns `"failed"`. On cancel it returns `"cancelled"` WITHOUT setting
> any terminal `_status` here (the inherited `_wait_for_gate_decision` already set
> `_status=CANCELLED` — base spec §13 BRANCH A). A rebuild must replicate exactly which terminal
> fields each exit sets.
> ⚠️ **GOTCHA-CBS-1 (NEW: commit-before-synthesis runs EVERY loop iteration, idempotently):** the
> `if commit_before_synthesis:` block (348) is INSIDE `while True`, so on each rework iteration the
> re-run input passes are RE-committed via `_commit_one_pass` (idempotent — `commit_files` advances
> the ref with an unchanged tree as a harmless no-op when content is unchanged; `discovery.py:351`).
> It commits ONLY input passes (skips `synthesis`/`tco-baseline`/`gate-readiness-check` at 353-354)
> and only passes that produced results (356). This populates `_committed_pass_paths`, which then
> redirects synthesis/TCO input-resolution to git (`artifact_repo`/`artifact_ref` set at 368-369;
> see §5.5/§5.7). A rebuild MUST gate this on the patch, place it at the TOP of the loop body, skip
> the three non-input passes, and only commit passes with non-empty `_pass_results`.

---

## 5. HELPER METHODS (every branch reproduced)

### 5.1 `_dispatch_pass(...) -> AgentTaskResult` (`discovery.py:650-715`)
Dispatch one discovery pass via `dispatch_agent_task`. Discovery's analogue of base `_dispatch_agent`
— but simpler (no `_execution_ctx`, no context-priors, no patch gate) and feedback is always keyed to
the single gate `"G-DC"`. **At HEAD it gained `artifact_repo`/`artifact_ref` params + a 2m heartbeat.**
```text
async def _dispatch_pass(self, app_id, pass_name, input_artifacts, source_repo="", workspace_key="",
                         artifact_repo="", artifact_ref=""):     # discovery.py:650-659  (★NEW repo/ref params)
    pass_def = DISCOVERY_PASSES[pass_name]                 # discovery.py:673  (KeyError if unknown pass)
    context = {}                                           # discovery.py:674
    fb = self._rework_feedback.get("G-DC")                 # discovery.py:675
    if fb is not None:                                     # discovery.py:676  BRANCH
        context["rework_feedback"] = fb                    # discovery.py:677
    task_input = AgentTaskInput(                           # discovery.py:678-688
        task_type=f"discovery-{pass_name}", app_id=app_id,
        skill_id=pass_def["skill_id"], input_artifacts=input_artifacts,
        source_repo=source_repo, workspace_key=workspace_key,
        artifact_repo=artifact_repo, artifact_ref=artifact_ref,    # ★NEW threaded into AgentTaskInput
        context=context)
    result = await workflow.execute_activity(              # discovery.py:689-703
        dispatch_agent_task, task_input,
        start_to_close_timeout=timedelta(hours=1),
        heartbeat_timeout=timedelta(minutes=2),            # discovery.py:700  ★NEW
        retry_policy=RETRY_POLICIES["agent_failure"],
        activity_id=f"agent-{pass_name}")
    self._agent_metadata[pass_name] = {                    # discovery.py:706-713
        "model_used": result.model_used, "duration_ms": result.duration_ms,
        "token_usage_input": result.token_usage_input,
        "token_usage_output": result.token_usage_output,
        "cost_estimate_usd": result.cost_estimate_usd,
        "output_files": result.output_files}
    return result                                          # discovery.py:715
```
- **Branch (1):** `if fb is not None:` (676).
- **Activity:** `dispatch_agent_task`; args `task_input` (single dataclass); **start_to_close = 1
  hour**; **`heartbeat_timeout = 2 minutes` (NEW)**; retry **`agent_failure`** (initial 5s, ×2.0, max
  60s, **3 attempts**, no non_retryable); `activity_id=f"agent-{pass_name}"` (deterministic, idempotent
  on replay).
- ⚠️ **GOTCHA-DP-1 (single-gate rework feedback is uniform across ALL passes):** the docstring
  (`discovery.py:662-666`) notes Discovery has one gate (G-DC) covering every pass, so a prior
  rejection's feedback `_rework_feedback["G-DC"]` is attached to **every** re-dispatched pass via
  `context["rework_feedback"]`. A rebuild MUST key feedback to `"G-DC"` (not per-pass) and attach it
  to every pass dispatch when present. (`_rework_feedback["G-DC"]` is SET by the inherited
  `_wait_for_gate_decision` on a `"rejected"` decision — base spec §13 — and CLEARED on approve.)
- ⚠️ **GOTCHA-DP-2 (no `execution_context`, no context-priors, no patch gate):** unlike base
  `_dispatch_agent`, `_dispatch_pass` does NOT set `AgentTaskInput.execution_context` and does NOT
  load context-priors. So Layer-B `step_execution` rows are NOT emitted for Discovery agent dispatches
  via this path. A rebuild must NOT add those — it would change activity-input shape and emit extra
  rows Discovery doesn't.
- ⚠️ **GOTCHA-DP-3 (`task_type = f"discovery-{pass_name}"`):** the task_type prefix is the literal
  `"discovery"` joined to the pass name (e.g. `"discovery-catalog"`). This is what the output-ref
  patch later targets (§5.8). A rebuild must match this format.
- ⚠️ **GOTCHA-DP-4 (NEW: `artifact_repo`/`artifact_ref` hydrate inputs from the committed branch):**
  the two new kwargs (default `""`) flow straight into `AgentTaskInput.artifact_repo`/`artifact_ref`
  (`types.py:498-499`). When set (by `_run_synthesis_and_tco` in commit-before-synthesis mode), the
  agent runtime fetches each `input_artifacts` entry from the per-app branch (the
  cross-container-consistent source) instead of relying on container-local workspace the NLB fan-out
  may not have populated on the replica that runs synthesis. When `""` (every Pass-1/Pass-2-4
  dispatch), behavior is unchanged (workspace-local resolution). A rebuild MUST add these params,
  default them to `""`, and thread them into `AgentTaskInput`.
- ⚠️ **GOTCHA-DP-5 (NEW: 2-minute heartbeat_timeout):** `dispatch_agent_task` heartbeats every ~30s;
  the paired `heartbeat_timeout=timedelta(minutes=2)` (700) lets Temporal detect a truly-dead dispatch
  (agent container OOM/crash mid-stream) in ~2 min instead of waiting the full 1h `start_to_close`.
  Matches architecture.py/data.py. A rebuild MUST set this 2m heartbeat on the agent dispatch (and on
  the variant dispatch, §5.3) — it is NOT optional and changes failure-detection timing.

### 5.2 `_select_discovery_patterns_variant(self, catalog_artifacts) -> str | None` (`discovery.py:717-792`)
**Pure synchronous** helper. Parses the first catalog artifact as JSON and feeds a tech fingerprint
into `select_discovery_patterns_skill` (router; §1.3). Returns `None` on any parse failure so a
malformed catalog can't stall Discovery (the generic structural pass still dispatches).
```text
def _select_discovery_patterns_variant(self, catalog_artifacts):
    if not catalog_artifacts:                              # discovery.py:729  BRANCH
        return None
    raw = catalog_artifacts[0]                             # discovery.py:731
    if not isinstance(raw, str) or not raw.strip():        # discovery.py:732  BRANCH
        return None
    try:                                                   # discovery.py:734
        parsed = json.loads(raw)
    except (json.JSONDecodeError, TypeError, ValueError):  # discovery.py:736  BRANCH
        return None
    if not isinstance(parsed, dict):                       # discovery.py:738  BRANCH
        return None

    fingerprint = parsed.get("tech_fingerprint")           # discovery.py:746
    if not isinstance(fingerprint, dict):                  # discovery.py:747  BRANCH (no explicit fingerprint)
        ts = parsed.get("tech_stack") or {}                # discovery.py:748
        if isinstance(ts, dict):                           # discovery.py:749  BRANCH
            langs_raw = ts.get("languages") or []          # discovery.py:753
            lang_names = []
            if isinstance(langs_raw, list):                # discovery.py:754  BRANCH
                for entry in langs_raw:                    # discovery.py:755  LOOP
                    if isinstance(entry, dict) and entry.get("name"):   # discovery.py:756  BRANCH
                        lang_names.append(str(entry["name"]))           # discovery.py:757
                    elif isinstance(entry, str):           # discovery.py:758  BRANCH
                        lang_names.append(entry)           # discovery.py:759
            dbs_raw = ts.get("databases") or []            # discovery.py:768
            primary_db = dbs_raw[0] if dbs_raw and isinstance(dbs_raw, list) else ""  # discovery.py:769  BRANCH (ternary)
            runtimes = ts.get("runtimes") or []            # discovery.py:775
            fingerprint = {                                # discovery.py:776-784
                "languages": lang_names,
                "frameworks": ts.get("frameworks") or [],
                "platforms": runtimes, "runtimes": runtimes,
                "databases": dbs_raw, "database": primary_db,
                "primary_language": lang_names[0] if lang_names else ""}  # discovery.py:783  BRANCH (ternary)
        else:                                              # discovery.py:785  BRANCH
            fingerprint = None                             # discovery.py:786
    has_source = parsed.get("has_source_available")        # discovery.py:787
    if not isinstance(has_source, bool):                   # discovery.py:788  BRANCH
        has_source = True                                  # discovery.py:789
    return select_discovery_patterns_skill(fingerprint, has_source_available=has_source)  # discovery.py:790-792
```
- **Branches (13):** 729, 732, 734/736, 738, 747, 749, 754, 755 (loop), 756, 758, 769 (ternary),
  783 (ternary), 785, 788.
- ⚠️ **GOTCHA-VAR-1 (fingerprint preference & tech_stack normalization):** prefers an explicit
  `tech_fingerprint` dict; falls back to normalizing the catalog's `tech_stack` block
  (`discovery.py:740-786`). Language list-of-dicts (`[{"name":"C#","percent":86}]`) is flattened to
  `["C#"]` (755-759); `databases` is passed VERBATIM as a list of vendor-blob strings (768) AND a
  scalar `database` = first element (769); `runtimes` is forwarded under BOTH `platforms` and
  `runtimes` keys (775-781). A rebuild MUST reproduce this exact normalization — the router's
  substring probe depends on the raw `databases[*]` blobs and the `runtimes` duplication (the ATLAS
  Challenge 3 Oracle-blob case at `discovery.py:763-767` of the comment).
- ⚠️ **GOTCHA-VAR-2 (`has_source` default True):** if `has_source_available` is absent or not a
  `bool`, it defaults to `True` (788-789) — so the doc-only variant is NOT selected unless the
  catalog explicitly says `has_source_available: false`. A rebuild must default to `True`.
- ⚠️ **GOTCHA-VAR-3 (this is pure & deterministic — safe inside @workflow.defn):** no Temporal /
  I/O / random; only `json.loads` and dict munging. Called directly in `_execute_discovery` (line
  281) **not** via an activity. A rebuild keeps it pure; the router module
  (`discovery_patterns_router`) is likewise pure (its docstring forbids Temporal imports).
- **Router output mapping** (`discovery_patterns_router.select_discovery_patterns_skill`, resolution
  order): (1) `has_source_available==False` → `"discovery-patterns-doc-only"`; (2) any mainframe
  token (exact-membership OR substring on raw strings) → `"discovery-patterns-mainframe"`; (3)
  oracle/plsql substring → `"discovery-patterns-oracle"`; (4) sqlserver/mssql/tsql/t-sql substring →
  `"discovery-patterns-sqlserver"`; (5) c#/csharp/.net/dotnet/vbnet/asp.net/vb6/classic-asp substring
  → `"discovery-patterns-dotnet"`; (6) else `"discovery-patterns"` (base). **Always returns a
  string** (never None) when reached — but `_select_discovery_patterns_variant` itself can return
  `None` on the early parse-fail branches above.

### 5.3 `_dispatch_discovery_patterns_variant(self, *, app_id, skill_id, input_artifacts, source_repo, workspace_key) -> AgentTaskResult` (`discovery.py:794-843`)
Dispatch the tech-stack specialist alongside the generic mapper at Pass 1. Same shape as
`_dispatch_pass` but `task_type=f"discovery-{skill_id}"`, `skill_id=skill_id`, and metadata stored
under the **variant skill_id key** (not a pass name). **Also carries the new 2m heartbeat.**
```text
async def _dispatch_discovery_patterns_variant(self, *, app_id, skill_id, input_artifacts, source_repo, workspace_key):
    context = {}                                           # discovery.py:811
    fb = self._rework_feedback.get("G-DC")                 # discovery.py:812
    if fb is not None:                                     # discovery.py:813  BRANCH
        context["rework_feedback"] = fb                    # discovery.py:814
    task_input = AgentTaskInput(task_type=f"discovery-{skill_id}", app_id=app_id,  # discovery.py:815-823
        skill_id=skill_id, input_artifacts=input_artifacts,
        source_repo=source_repo, workspace_key=workspace_key, context=context)
    result = await workflow.execute_activity(dispatch_agent_task, task_input,       # discovery.py:824-834
        start_to_close_timeout=timedelta(hours=1),
        heartbeat_timeout=timedelta(minutes=2),            # discovery.py:831  ★NEW
        retry_policy=RETRY_POLICIES["agent_failure"],
        activity_id=f"agent-{skill_id}")
    self._agent_metadata[skill_id] = { ...6 fields... }    # discovery.py:835-842
    return result                                          # discovery.py:843
```
- **Branch (1):** `if fb is not None:` (813).
- **Activity:** `dispatch_agent_task`; 1 hour; **2m heartbeat (NEW)**; `agent_failure` (3 attempts);
  `activity_id=f"agent-{skill_id}"`.
- ⚠️ **GOTCHA-VARDISP-1 (metadata key = skill_id, not a pass name):** the variant's metadata is stored
  under `_agent_metadata[skill_id]` (835) so it doesn't overwrite the base pass's telemetry (the
  generic mapper writes `_agent_metadata["structural-analysis"]`). But `_pass_results` only ever has a
  `"structural-analysis"` key — the variant's `output_artifacts` are MERGED into that bucket by the
  caller (`_execute_discovery` line 312-314), NOT stored under a separate pass key. So the variant's
  artifacts contribute to evidence/commit via the structural-analysis bucket, while its metadata is
  separate. A rebuild must keep this split: shared metadata under `skill_id`, artifacts folded into
  `structural-analysis`.
- ⚠️ **GOTCHA-VARDISP-2 (same workspace + source repo as the generic mapper):** runs concurrently with
  `legacy-architecture-mapper` using the identical `workspace_key`/`source_repo` so the specialist
  sees the same cloned tree (`discovery.py:805-810`). A rebuild must pass the same keys. NOTE: this
  variant does NOT take `artifact_repo`/`artifact_ref` (no keyword-only params for them) — it runs at
  Pass 1, before any commit, so there's nothing to hydrate from git yet.

### 5.4 `_run_parallel_passes(self, app_id, structural_artifacts, source_repo="", workspace_key="") -> None` (`discovery.py:845-964`)
Fan-out the sequence-3 passes. ALWAYS dispatches business-logic-extraction + quality-risk-assessment +
ux-accessibility-assessment. Under patch `discovery-data-steps-v1` ALSO dispatches
data-domain-discovery + shared-database-analysis. Under patch `discovery-capability-extraction-v1`
ALSO dispatches capability-extraction. All in ONE `asyncio.gather`.
```text
async def _run_parallel_passes(self, app_id, structural_artifacts, source_repo="", workspace_key=""):
    cumulative_base = STEP_WEIGHTS["catalog"] + STEP_WEIGHTS["structural-analysis"]   # discovery.py:875-877
    await self._set_step("business-logic-extraction", cumulative_base)   # discovery.py:878
    await self._set_step("quality-risk-assessment",   cumulative_base)   # discovery.py:879
    await self._set_step("ux-accessibility-assessment", cumulative_base) # discovery.py:880

    include_data_passes = workflow.patched("discovery-data-steps-v1")    # discovery.py:882
    if include_data_passes:                                              # discovery.py:883  BRANCH (patch gate)
        await self._set_step("data-domain-discovery",  cumulative_base)  # discovery.py:884
        await self._set_step("shared-database-analysis", cumulative_base)# discovery.py:885

    include_capability_pass = workflow.patched("discovery-capability-extraction-v1")  # discovery.py:887-889
    if include_capability_pass:                                          # discovery.py:890  BRANCH (patch gate)
        await self._set_step("capability-extraction", cumulative_base)   # discovery.py:891

    bl_task = self._dispatch_pass(app_id, "business-logic-extraction", structural_artifacts, source_repo, workspace_key)  # discovery.py:893-899
    qr_task = self._dispatch_pass(app_id, "quality-risk-assessment",   structural_artifacts, source_repo, workspace_key)  # discovery.py:900-906
    ux_task = self._dispatch_pass(app_id, "ux-accessibility-assessment", structural_artifacts, source_repo, workspace_key)# discovery.py:907-913

    tasks = [bl_task, qr_task, ux_task]                                  # discovery.py:915
    if include_data_passes:                                             # discovery.py:916  BRANCH
        dd_task = self._dispatch_pass(app_id, "data-domain-discovery", structural_artifacts, source_repo, workspace_key)   # discovery.py:917-923
        sd_task = self._dispatch_pass(app_id, "shared-database-analysis", structural_artifacts, source_repo, workspace_key)# discovery.py:924-930
        tasks.extend([dd_task, sd_task])                                # discovery.py:931

    if include_capability_pass:                                        # discovery.py:940  BRANCH
        cap_inputs = list(structural_artifacts)                        # discovery.py:941
        cap_inputs.extend(self._pass_results.get("catalog", []))       # discovery.py:942
        ce_task = self._dispatch_pass(app_id, "capability-extraction", cap_inputs, source_repo, workspace_key)  # discovery.py:943-949
        tasks.append(ce_task)                                          # discovery.py:950

    results = await asyncio.gather(*tasks)                             # discovery.py:952  ★PARALLEL

    self._pass_results["business-logic-extraction"] = results[0].output_artifacts   # discovery.py:954
    self._pass_results["quality-risk-assessment"]   = results[1].output_artifacts   # discovery.py:955
    self._pass_results["ux-accessibility-assessment"] = results[2].output_artifacts # discovery.py:956
    idx = 3                                                            # discovery.py:957
    if include_data_passes:                                           # discovery.py:958  BRANCH
        self._pass_results["data-domain-discovery"]  = results[idx].output_artifacts      # discovery.py:959
        self._pass_results["shared-database-analysis"] = results[idx + 1].output_artifacts# discovery.py:960
        idx += 2                                                      # discovery.py:961
    if include_capability_pass:                                      # discovery.py:962  BRANCH
        self._pass_results["capability-extraction"] = results[idx].output_artifacts       # discovery.py:963
        idx += 1                                                      # discovery.py:964
```
- **Branches (6 patch-gated + gather):** `include_data_passes` checked at 883 (set_step), 916
  (dispatch), 958 (result-unpack); `include_capability_pass` checked at 890 (set_step), 940
  (dispatch), 962 (result-unpack). Plus the parallel `gather` at 952.
- **Activities:** 3 (or 5, or 4, or 6 with both patches) `dispatch_agent_task` calls via
  `_dispatch_pass`, fanned out with `asyncio.gather` → run **in parallel**. Each: 1 hour / **2m
  heartbeat** / `agent_failure` / `activity_id=f"agent-{pass_name}"`.
- ⚠️ **GOTCHA-PP-1 (patch gates are LOAD-BEARING & VERBATIM — replay determinism):** the two patch
  IDs `"discovery-data-steps-v1"` (882) and `"discovery-capability-extraction-v1"` (887-889) gate
  which passes fan out. The docstring (`discovery.py:872-874`) states pre-patch in-flight histories
  must replay with ONLY the legacy three passes. A rebuild MUST use these EXACT strings and gate the
  extra dispatches (AND their `_set_step` calls AND their result-unpacking) behind them, or replay of
  any pre-patch run breaks (different activity count = nondeterminism). All `_set_step` extra-pass
  calls (884-885, 891) are ALSO inside the patch gates.
- ⚠️ **GOTCHA-PP-2 (result-index bookkeeping `idx` MUST match dispatch order):** results are unpacked
  positionally: `[0,1,2]` always = bl/qr/ux; then `idx=3`; if data passes, `[3,4]` = dd/sd and
  `idx→5`; if capability, `[idx]` = ce. Because dispatch order (893-950) and unpack order (954-964)
  share the same conditional structure, the indices align. A rebuild MUST dispatch and unpack in this
  EXACT order, advancing `idx` identically, or pass results get mis-assigned (e.g.
  shared-database-analysis artifacts attributed to capability-extraction).
- ⚠️ **GOTCHA-PP-3 (capability-extraction has EXTRA inputs):** `capability-extraction` consumes
  `structural_artifacts` PLUS `_pass_results.get("catalog", [])` (941-942) — the only pass with a
  widened input set. The other parallel passes get only `structural_artifacts`. A rebuild must add the
  catalog artifacts for capability-extraction.
- ⚠️ **GOTCHA-PP-4 (called from TWO sites with identical args):** invoked once in the linear prelude
  (line 324) and again on each rework iteration (line 622), both with
  `list(self._pass_results["structural-analysis"])`. On rework, `_dispatch_pass` attaches
  `_rework_feedback["G-DC"]` to every dispatched pass (§5.1). A rebuild must call this from both sites.

### 5.5 `_run_synthesis_and_tco(self, app_id, synthesis_input_artifacts, source_repo="", workspace_key="", artifact_repo="", artifact_ref="") -> tuple[AgentTaskResult, AgentTaskResult]` (`discovery.py:966-1032`)
Fan-out Synthesis + TCO Baseline (contract sequence 4) in parallel. **At HEAD gained
`artifact_repo`/`artifact_ref` params and TCO now prefers committed branch paths.** No branches except
the two ternary input selectors for TCO.
```text
async def _run_synthesis_and_tco(self, app_id, synthesis_input_artifacts, source_repo="", workspace_key="",
                                 artifact_repo="", artifact_ref=""):     # discovery.py:966-974  (★NEW repo/ref params)
    cumulative_base = ( STEP_WEIGHTS["catalog"] + STEP_WEIGHTS["structural-analysis"]
        + STEP_WEIGHTS["business-logic-extraction"] + STEP_WEIGHTS["quality-risk-assessment"]
        + STEP_WEIGHTS["ux-accessibility-assessment"] )                # discovery.py:988-994
    await self._set_step("synthesis",    cumulative_base)              # discovery.py:995
    await self._set_step("tco-baseline", cumulative_base)              # discovery.py:996
    synthesis_task = self._dispatch_pass(app_id, "synthesis", synthesis_input_artifacts,  # discovery.py:998-1006
        source_repo, workspace_key, artifact_repo=artifact_repo, artifact_ref=artifact_ref)  # ★NEW repo/ref threaded
    # TCO inputs: prefer COMMITTED branch paths, fall back to raw pass-result paths
    tco_inputs = ( self._committed_pass_paths.get("catalog")
                   or self._pass_results.get("catalog", []) )          # discovery.py:1012-1015  BRANCH (or-fallback)
                 + ( self._committed_pass_paths.get("structural-analysis")
                     or self._pass_results.get("structural-analysis", []) )  # discovery.py:1016-1018  BRANCH (or-fallback)
    tco_task = self._dispatch_pass(app_id, "tco-baseline", tco_inputs,  # discovery.py:1019-1027
        source_repo, workspace_key, artifact_repo=artifact_repo, artifact_ref=artifact_ref)  # ★NEW repo/ref threaded
    synthesis_result, tco_result = await asyncio.gather(synthesis_task, tco_task)  # discovery.py:1029-1031  ★PARALLEL
    return synthesis_result, tco_result                                # discovery.py:1032
```
- **Branches (2 `or`-fallback expressions + gather):** the `committed_pass_paths.get(...) or
  pass_results.get(...)` short-circuits at 1012-1015 and 1016-1018; `asyncio.gather` at 1029.
- **Activities:** 2 `dispatch_agent_task` via `_dispatch_pass` → parallel. 1 hour / **2m heartbeat** /
  `agent_failure` each. Both carry `artifact_repo`/`artifact_ref` (set by the caller only in
  commit-before-synthesis mode).
- ⚠️ **GOTCHA-ST-1 (distinct inputs — synthesis gets ALL, TCO gets catalog+structural only):**
  synthesis consumes `synthesis_input_artifacts` (= `_collect_all_pass_artifacts()`, §5.7); TCO
  consumes ONLY `catalog + structural-analysis` artifacts (best-effort cost baseline, emits
  `tco.confidence=low` when no cost-context-bundle is supplied — `discovery.py:1007-1011`). A rebuild
  must NOT feed TCO the full bundle.
- ⚠️ **GOTCHA-ST-2 (called every loop iteration):** invoked at the top of each `while True` iteration
  (line 363). On rework, both dispatches carry `_rework_feedback["G-DC"]` via `_dispatch_pass`.
- ⚠️ **GOTCHA-ST-3 (NEW: TCO inputs prefer `_committed_pass_paths`, synthesis hydrates via ref):**
  TCO's catalog/structural inputs are `_committed_pass_paths.get(k) or _pass_results.get(k, [])`
  (1012-1018) — i.e. the COMMITTED repo-relative branch paths win when present (commit-before-synthesis
  mode), falling back to the raw workspace paths pre-patch. Combined with `artifact_repo`/`artifact_ref`
  being passed down (998-1006, 1019-1027), both synthesis AND TCO then fetch their inputs from the
  branch via `artifact_ref` rather than a possibly-cold container-local workspace. A rebuild MUST add
  the repo/ref params, thread them to both `_dispatch_pass` calls, and use the `committed-or-raw`
  fallback for TCO inputs.

### 5.6 `_extract_pass_content(self, pass_name) -> str` (`discovery.py:1034-1054`)
**Pure sync.** Returns the raw JSON content the agent wrote for a pass (from
`_agent_metadata[pass_name]["output_files"]`), matching the pass's target artifact filename; falls
back to any `.json` file; `""` if none.
```text
def _extract_pass_content(self, pass_name):
    metadata = self._agent_metadata.get(pass_name) or {}    # discovery.py:1042
    output_files = metadata.get("output_files") or []       # discovery.py:1043
    target = DISCOVERY_PASSES.get(pass_name, {}).get("artifact", "")  # discovery.py:1044
    if not target:                                          # discovery.py:1045  BRANCH
        return ""
    for f in output_files:                                  # discovery.py:1048  LOOP
        if f.path.endswith(target):                         # discovery.py:1049  BRANCH → exact-ish match wins
            return f.content or ""                          # discovery.py:1050
    for f in output_files:                                  # discovery.py:1051  LOOP
        if f.path.endswith(".json"):                        # discovery.py:1052  BRANCH → fallback any .json
            return f.content or ""                          # discovery.py:1053
    return ""                                               # discovery.py:1054
```
- **Branches (5):** 1045, 1048 (loop), 1049, 1051 (loop), 1052.
- ⚠️ **GOTCHA-EXT-1 (two-pass match — target suffix first, then any .json):** prefers a file whose
  path ENDS WITH the pass's declared artifact (e.g. `catalog.json`); only if none matches does it fall
  back to the FIRST `.json` file. `""` ⇒ caller treats as "no data". A rebuild MUST do exact-suffix-
  first then any-`.json` fallback, returning `f.content or ""` (so a `None` content becomes `""`).
- Used by Steps 5b/5c/5d to feed the best-effort persist activities; a `""` return + the surrounding
  `if catalog_json or synthesis_json:` / `if cap_json:` branches mean those persists are skipped when
  no content was produced (§4.2 branches 10, 13).

### 5.7 `_collect_all_pass_artifacts(self) -> list[str]` (`discovery.py:1056-1097`)
**Pure sync.** Collect artifact paths from all completed passes for synthesis input, in deterministic
contract order, EXCLUDING synthesis/tco-baseline/gate-readiness-check; dedup. **At HEAD it PREFERS
the committed branch paths over raw pass-result paths.**
```text
def _collect_all_pass_artifacts(self):
    artifacts = []                                          # discovery.py:1067
    seen = set()                                            # discovery.py:1068
    contract_pass_order = [                                 # discovery.py:1072-1075
        p for p in DISCOVERY_PASSES
        if p not in ("synthesis", "tco-baseline", "gate-readiness-check")]  # discovery.py:1074  BRANCH (comprehension filter)
    for pass_name in contract_pass_order:                   # discovery.py:1076  LOOP
        if pass_name in seen:                               # discovery.py:1077  BRANCH
            continue
        seen.add(pass_name)                                 # discovery.py:1079
        artifacts.extend(                                   # discovery.py:1083-1086
            self._committed_pass_paths.get(pass_name)       # ★NEW prefer committed branch paths
            or self._pass_results.get(pass_name, []))       # fall back to raw pass-result paths
    for pass_name, vals in self._pass_results.items():      # discovery.py:1088  LOOP (defensive fold)
        if pass_name in seen:                               # discovery.py:1089  BRANCH
            continue
        if pass_name in ("synthesis", "tco-baseline"):      # discovery.py:1091  BRANCH
            continue
        seen.add(pass_name)                                 # discovery.py:1093
        artifacts.extend(                                   # discovery.py:1094-1096
            self._committed_pass_paths.get(pass_name) or vals)  # ★NEW prefer committed branch paths
    return dedup_paths(artifacts)                           # discovery.py:1097
```
- **Branches (6):** comprehension filter (1074); loop 1076 + `if pass_name in seen` (1077); loop 1088
  + `if pass_name in seen` (1089) + `if pass_name in ("synthesis","tco-baseline")` (1091). Plus the
  two `committed-or-raw` `or`-fallbacks (1083-1086, 1094-1096).
- ⚠️ **GOTCHA-COL-1 (deterministic order: contract-declared first, runtime-only folded after):** the
  first loop iterates `DISCOVERY_PASSES` keys in declaration order (deterministic); the second
  defensively folds any `_pass_results` keys that weren't in `DISCOVERY_PASSES` (should be empty in
  practice — `discovery.py:1064-1065`). Both EXCLUDE synthesis/tco-baseline (they run AFTER synthesis
  and aren't inputs to it; gate-readiness-check is pre-review, not evidence). The fold-loop does NOT
  re-exclude `gate-readiness-check` (only synthesis/tco-baseline at 1091) — but it can't appear in
  `_pass_results` anyway since no pass writes that key. A rebuild MUST iterate `DISCOVERY_PASSES`
  first for determinism, fold runtime-only keys after, and exclude synthesis+tco-baseline from BOTH
  loops (and gate-readiness-check from the first via the comprehension).
- ⚠️ **GOTCHA-COL-2 (`dedup_paths` = order-preserving uniq):** final return is
  `dedup_paths(artifacts)` = `list(dict.fromkeys(paths))` — removes duplicates while preserving
  first-seen order. A rebuild MUST dedup order-preservingly, not via `set()`.
- ⚠️ **GOTCHA-COL-3 (NEW: committed branch paths win over raw workspace paths):** BOTH loops now use
  `self._committed_pass_paths.get(pass_name) or <raw>` (1083-1086, 1094-1096). In commit-before-
  synthesis mode every input pass was committed by `_commit_one_pass` (§5.8.1), so `_committed_pass_paths`
  holds the branch repo-relative paths, and synthesis receives THOSE — letting it fetch each pass from
  git via `artifact_ref` (replica-independent). Pre-patch (`_committed_pass_paths` empty) it falls back
  to the raw `_pass_results` paths exactly as before. A rebuild MUST prefer `_committed_pass_paths`
  with an `or`-fallback to `_pass_results` in both loops.

### 5.8 `_commit_artifacts` / `_commit_artifacts_batched` / `_commit_one_pass` / `_commit_artifacts_legacy` (`discovery.py:1099-1320`)

#### 5.8.0 `_commit_artifacts(self, repo, branch, app_id) -> list[str]` (`discovery.py:1099-1121`) — patch-gated dispatcher
```text
async def _commit_artifacts(self, repo, branch, app_id):
    if workflow.patched("discovery-batch-writes-v1"):       # discovery.py:1119  BRANCH (patch gate)
        return await self._commit_artifacts_batched(repo, branch, app_id)   # discovery.py:1120
    return await self._commit_artifacts_legacy(repo, branch, app_id)        # discovery.py:1121
```
- **Branch (1):** `if workflow.patched("discovery-batch-writes-v1"):` (1119).
- ⚠️ **GOTCHA-COMMIT-1 (patch verbatim; new runs batch, old runs per-file):** the patch
  `"discovery-batch-writes-v1"` (1119) gates batched-vs-legacy. The docstring (`discovery.py:1107-1115`)
  records the incident: the old per-file path killed Run 2's `discovery-CHAPS` at event 464 because
  each scheduled activity input accumulated every prior artifact path in history and exceeded the 2 MB
  Temporal activity-input cap past ~40 files. Batched = one commit per pass, history linear in pass
  count (9) not file count. A rebuild MUST keep this patch gate EXACT and route new runs to batched.

#### 5.8.1 `_commit_artifacts_batched(self, repo, branch, app_id) -> list[str]` (`discovery.py:1123-1148`) — REWRITTEN at HEAD
**REWRITTEN.** Now iterates `DISCOVERY_PASSES` **keys** (not `.items()`), REUSES already-committed
passes from `_committed_pass_paths` (incremental commit-before-synthesis), and delegates each remaining
pass to the new `_commit_one_pass`.
```text
async def _commit_artifacts_batched(self, repo, branch, app_id):
    committed_paths = []                                    # discovery.py:1137
    for pass_name in DISCOVERY_PASSES:                      # discovery.py:1138  LOOP (over ALL declared passes, keys only)
        if pass_name in self._committed_pass_paths:         # discovery.py:1143  BRANCH → reuse incremental commit, skip re-commit
            committed_paths.extend(self._committed_pass_paths[pass_name])   # discovery.py:1144
            continue                                        # discovery.py:1145
        paths = await self._commit_one_pass(pass_name, repo, branch, app_id)  # discovery.py:1146
        committed_paths.extend(paths)                       # discovery.py:1147
    return dedup_paths(committed_paths)                     # discovery.py:1148
```
- **Branches (2):** loop 1138; `if pass_name in self._committed_pass_paths: ... continue` (1143).
- ⚠️ **GOTCHA-COMMITB-1 (REWRITTEN: reuse-or-commit-one-pass; the heavy lifting moved to
  `_commit_one_pass`):** in commit-before-synthesis mode the INPUT passes were already committed
  incrementally (their paths are in `_committed_pass_paths`), so this loop just REUSES those paths and
  skips re-committing (1143-1145); the passes that run AFTER the incremental commits (`synthesis`,
  `tco-baseline`) — and EVERY pass in a pre-patch run (where `_committed_pass_paths` is empty) — are
  committed here via `_commit_one_pass` (1146). `_commit_one_pass` itself skips passes with no
  artifacts (§5.8.1a), so passes like `gate-readiness-check` produce nothing. A rebuild MUST: iterate
  `DISCOVERY_PASSES` keys; for a pass already in `_committed_pass_paths`, extend with the stored paths
  and continue; else call `_commit_one_pass`; finally `dedup_paths`.

#### 5.8.1a `_commit_one_pass(self, pass_name, repo, branch, app_id) -> list[str]` (`discovery.py:1150-1228`) — NEW METHOD
Commit a SINGLE pass's artifacts (summary JSON + every output file) in ONE `write_artifacts_batch`,
record the committed paths in `_committed_pass_paths`, optionally patch the output-ref. Idempotent.
Used BOTH incrementally (`discovery-commit-before-synthesis-v1`, right after each input pass completes)
AND from `_commit_artifacts_batched`.
```text
async def _commit_one_pass(self, pass_name, repo, branch, app_id):
    pass_def = DISCOVERY_PASSES.get(pass_name)              # discovery.py:1162
    if pass_def is None:                                    # discovery.py:1163  BRANCH → unknown pass → []
        return []                                           # discovery.py:1164
    artifacts = self._pass_results.get(pass_name, [])       # discovery.py:1165
    if not artifacts:                                       # discovery.py:1166  BRANCH → no result → []
        return []                                           # discovery.py:1167
    artifact_path = f"discovery/{app_id}/{pass_def['artifact']}"   # discovery.py:1169
    metadata = self._agent_metadata.get(pass_name, {})      # discovery.py:1170
    output_files = metadata.get("output_files", [])         # discovery.py:1171
    file_paths = [f.path for f in output_files] if output_files else []  # discovery.py:1172  BRANCH (ternary)
    content = json.dumps({                                  # discovery.py:1174-1187
        "pass": pass_name, "skill_id": pass_def["skill_id"],
        "artifacts": artifacts, "file_artifacts": file_paths,
        "model_used": metadata.get("model_used",""), "duration_ms": metadata.get("duration_ms",0),
        "token_usage": {"input": metadata.get("token_usage_input",0),
                        "output": metadata.get("token_usage_output",0)},
        "cost_estimate_usd": metadata.get("cost_estimate_usd",0.0),
        "timestamp": workflow.now().isoformat()},            # discovery.py:1186  deterministic
        indent=2)
    committed_paths = [artifact_path]                        # discovery.py:1189
    batch = [(artifact_path, content)]                       # discovery.py:1190
    for file_artifact in output_files:                       # discovery.py:1191  LOOP
        file_path = f"discovery/{app_id}/files/{pass_name}/{file_artifact.path}"   # discovery.py:1192-1194
        batch.append((file_path, file_artifact.content))     # discovery.py:1195
        committed_paths.append(file_path)                    # discovery.py:1196
    commit_ctx = self._execution_ctx(f"commit-{pass_name}", app_id=app_id)   # discovery.py:1198
    await workflow.execute_activity(                         # discovery.py:1199-1211
        write_artifacts_batch,
        WriteArtifactsBatchInput(repo=repo, branch=branch, files=batch,
            commit_message=f"discovery({app_id}): {pass_name} artifacts",
            execution_context=commit_ctx),
        start_to_close_timeout=timedelta(seconds=120),
        retry_policy=RETRY_POLICIES["transient"],
        activity_id=f"commit-{pass_name}")
    if workflow.patched("patch-output-artifact-ref-v1"):     # discovery.py:1213  BRANCH (patch gate)
        try:                                                 # discovery.py:1214
            await workflow.execute_activity(
                update_agent_task_output_ref,
                args=[app_id, f"discovery-{pass_name}", artifact_path],   # discovery.py:1217  ★positional
                start_to_close_timeout=timedelta(seconds=30),
                retry_policy=RETRY_POLICIES["transient"],
                activity_id=f"patch-output-ref-{pass_name}")  # discovery.py:1215-1221
        except Exception:                                    # discovery.py:1222  BRANCH (best-effort)
            pass                                             # discovery.py:1223
    self._committed_pass_paths[pass_name] = committed_paths  # discovery.py:1227  ★records committed paths
    return committed_paths                                   # discovery.py:1228
```
- **Branches (6):** `if pass_def is None` (1163); `if not artifacts` (1166); ternary `file_paths`
  (1172); loop 1191; `if workflow.patched("patch-output-artifact-ref-v1")` (1213); inner
  `try/except…pass` (1214/1222).
- **Activities per call (in order):**
  1. `write_artifacts_batch` — `WriteArtifactsBatchInput(repo, branch, files=batch, commit_message,
     execution_context=commit_ctx)`; **120s**; `transient`; `activity_id=f"commit-{pass_name}"`.
  2. `update_agent_task_output_ref` — **positional** `args=[app_id, f"discovery-{pass_name}",
     artifact_path]`; **30s**; `transient`; `activity_id=f"patch-output-ref-{pass_name}"`; ONLY under
     `patch-output-artifact-ref-v1`; wrapped in `try/except…pass` (observability-only).
- ⚠️ **GOTCHA-COMMITONE-1 (NEW METHOD — idempotent, records `_committed_pass_paths`):** returns
  `[]` for an unknown pass (1163) or a pass with no artifacts (1166). On success it writes the summary
  JSON + each output file as ONE tree+commit (`write_artifacts_batch`), then records the committed
  repo-relative paths under `_committed_pass_paths[pass_name]` (1227) so synthesis/TCO can hydrate
  from the branch (§5.5/§5.7). It is IDEMPOTENT: calling again for an already-committed pass advances
  the ref with an unchanged tree (harmless no-op commit). Both the incremental commit-before-synthesis
  loop (§4.2 BRANCH-NEW) and `_commit_artifacts_batched`'s fallback (§5.8.1) call it. A rebuild MUST
  reproduce the early-returns, the EXACT summary JSON shape (GOTCHA-COMMITONE-2), the file-path
  template, the output-ref patch, and the `_committed_pass_paths` write.
- ⚠️ **GOTCHA-COMMITONE-2 (summary JSON shape is EXACT & uses `workflow.now()`):** the per-pass summary
  has keys `pass, skill_id, artifacts, file_artifacts, model_used, duration_ms, token_usage{input,
  output}, cost_estimate_usd, timestamp`, `json.dumps(..., indent=2)` (1174-1187). `timestamp` =
  `workflow.now().isoformat()` (deterministic under replay). A rebuild MUST reproduce this exact JSON
  (key set, `indent=2`, `workflow.now()` not `datetime.now()`) — the committed file content is part of
  git history. (This is the SAME 10-key shape the legacy path writes; §5.8.2.)
- ⚠️ **GOTCHA-COMMITONE-3 (file paths `discovery/{app_id}/files/{pass_name}/{path}`):** the summary
  lands at `discovery/{app_id}/{pass_def['artifact']}`; each output file lands at
  `discovery/{app_id}/files/{pass_name}/{file_artifact.path}` (1192-1194). A rebuild must reproduce
  both path templates exactly.
- ⚠️ **GOTCHA-COMMITONE-4 (output-ref task_type = `discovery-{pass_name}`, positional args):** the
  patch activity targets the agent_task row by `task_type=f"discovery-{pass_name}"` (matching
  `_dispatch_pass`'s task_type, GOTCHA-DP-3) and is called with **positional** `args=[...]`, NOT a
  dataclass (1217). The activity signature is `update_agent_task_output_ref(app_id, task_type,
  artifact_ref)` (`agent_dispatch.py:288`). A rebuild must match positional shape + task_type format.
- ⚠️ **GOTCHA-COMMITONE-5 (`commit_ctx` may be None):** `_execution_ctx(...)` returns `None` when
  `_portfolio_id` is empty (base GOTCHA-EC1). The `WriteArtifactsBatchInput.execution_context` then is
  `None` → activity skips `step_execution` emission (best-effort). A rebuild must thread the
  possibly-None ctx, not require it.

#### 5.8.2 `_commit_artifacts_legacy(self, repo, branch, app_id) -> list[str]` (`discovery.py:1230-1320`)
Per-file path, kept VERBATIM for replay determinism of pre-`discovery-batch-writes-v1` runs. Identical
content/JSON to the batched summary, but writes the summary via `write_artifact` (single file), then
each output file via its own `write_artifact`. **Does NOT use `_commit_one_pass` and does NOT populate
`_committed_pass_paths`.**
```text
async def _commit_artifacts_legacy(self, repo, branch, app_id):
    committed_paths = []                                    # discovery.py:1236
    for pass_name, pass_def in DISCOVERY_PASSES.items():    # discovery.py:1237  LOOP
        artifacts = self._pass_results.get(pass_name, [])   # discovery.py:1238
        if not artifacts:                                   # discovery.py:1239  BRANCH → skip
            continue
        artifact_path = f"discovery/{app_id}/{pass_def['artifact']}"   # discovery.py:1242
        metadata = self._agent_metadata.get(pass_name, {})  # discovery.py:1243
        output_files = metadata.get("output_files", [])     # discovery.py:1245-1247
        file_paths = [f.path for f in output_files] if output_files else []  # discovery.py:1248  BRANCH (ternary)
        content = json.dumps({ ...same 10-key shape as _commit_one_pass, workflow.now()... }, indent=2)  # discovery.py:1250-1263
        write_input = WriteArtifactInput(repo=repo, branch=branch, path=artifact_path,
            content=content, commit_message=f"discovery({app_id}): {pass_name} artifacts")  # discovery.py:1265-1271
        await workflow.execute_activity(write_artifact, write_input,    # discovery.py:1272-1278
            start_to_close_timeout=timedelta(seconds=60),
            retry_policy=RETRY_POLICIES["transient"],
            activity_id=f"commit-{pass_name}")
        committed_paths.append(artifact_path)               # discovery.py:1279
        if workflow.patched("patch-output-artifact-ref-v1"):# discovery.py:1281  BRANCH (patch gate)
            try:                                            # discovery.py:1282
                await workflow.execute_activity(update_agent_task_output_ref,
                    args=[app_id, f"discovery-{pass_name}", artifact_path],   # discovery.py:1285  ★positional
                    start_to_close_timeout=timedelta(seconds=30),
                    retry_policy=RETRY_POLICIES["transient"],
                    activity_id=f"patch-output-ref-{pass_name}")  # discovery.py:1283-1289
            except Exception:                               # discovery.py:1290  BRANCH (best-effort)
                pass                                        # discovery.py:1291
        for file_artifact in output_files:                 # discovery.py:1293  LOOP
            file_path = f"discovery/{app_id}/files/{pass_name}/{file_artifact.path}"   # discovery.py:1294-1297
            file_write = WriteArtifactInput(repo=repo, branch=branch, path=file_path,
                content=file_artifact.content,
                commit_message=f"discovery({app_id}): {pass_name} file {file_artifact.path}")  # discovery.py:1298-1307
            await workflow.execute_activity(write_artifact, file_write,    # discovery.py:1308-1318
                start_to_close_timeout=timedelta(seconds=60),
                retry_policy=RETRY_POLICIES["transient"],
                activity_id=f"commit-file-{pass_name}-{file_artifact.path.replace('/', '-')}")
            committed_paths.append(file_path)               # discovery.py:1318
    return dedup_paths(committed_paths)                     # discovery.py:1320
```
- **Branches (6):** loop 1237; `if not artifacts: continue` (1239); ternary `file_paths` (1248);
  `if workflow.patched(...)` (1281); inner `try/except…pass` (1282/1290); loop 1293.
- **Activities per non-empty pass (in order):**
  1. `write_artifact` (summary) — `WriteArtifactInput`; **60s**; `transient`;
     `activity_id=f"commit-{pass_name}"`.
  2. `update_agent_task_output_ref` — positional `args=[app_id, f"discovery-{pass_name}",
     artifact_path]`; **30s**; `transient`; `activity_id=f"patch-output-ref-{pass_name}"`; ONLY under
     `patch-output-artifact-ref-v1`; try/except…pass. **(NB: runs BEFORE the per-file writes here, but
     AFTER the commit in `_commit_one_pass` — order differs but both are after the summary write.)**
  3. (per file) `write_artifact` — `WriteArtifactInput`; **60s**; `transient`;
     `activity_id=f"commit-file-{pass_name}-{path.replace('/','-')}"`.
- ⚠️ **GOTCHA-COMMITL-1 (legacy is NOT dead code — replay-only):** kept verbatim so workflows STARTED
  before `discovery-batch-writes-v1` shipped replay with the exact same per-file activity history. A
  rebuild MUST keep both paths and the patch dispatcher (§5.8.0). The legacy path's `write_artifact`
  timeout is **60s** (vs batched 120s for `write_artifacts_batch`) and uses NO `execution_context` and
  does NOT touch `_committed_pass_paths`. A rebuild must reproduce the timeout/shape difference and the
  `.items()` iteration (vs `_commit_artifacts_batched`'s keys-only iteration).
- ⚠️ **GOTCHA-COMMITL-2 (legacy file activity_id slash→dash):** the per-file activity id replaces `/`
  with `-` in the file path (`discovery.py:1316`) for a stable, slash-free Temporal activity id. A
  rebuild must reproduce this transform.

### 5.9 `_create_gate_pr_discovery(self, repo, branch, app_id)` (`discovery.py:1322-1365`)
Discovery-specific gate-review PR (does NOT use base `_create_gate_pr`). Builds a markdown body from
`DISCOVERY_PASSES` + a label map, then creates the PR.
```text
async def _create_gate_pr_discovery(self, repo, branch, app_id):
    rework_iter = self._rework_count("G-DC")                # discovery.py:1324
    pass_labels = { ...10 entries: catalog→"Catalog", structural-analysis→"Application & Data Mapping",
        business-logic-extraction→"Business Logic Extraction", quality-risk-assessment→"Quality & Risk Assessment",
        ux-accessibility-assessment→"UX & Accessibility Assessment", data-domain-discovery→"Data Domain Discovery",
        shared-database-analysis→"Shared Database Analysis", capability-extraction→"Capability + System Grain",
        synthesis→"Discovery Synthesis", tco-baseline→"TCO Baseline"... }   # discovery.py:1325-1336
    pr_body = f"## Gate G-DC Review: Discovery Complete\n\n**Application:** {app_id}\n\n### Discovery Passes Completed\n"  # discovery.py:1337-1341
    for pass_name, pass_def in DISCOVERY_PASSES.items():    # discovery.py:1342  LOOP
        label = pass_labels.get(pass_name, pass_name)       # discovery.py:1343
        pr_body += f"- [x] {label} ({pass_def['skill_id']})\n"  # discovery.py:1344
    pr_body += "\n### Artifacts\n"                          # discovery.py:1345
    for pass_name, pass_def in DISCOVERY_PASSES.items():    # discovery.py:1346  LOOP
        pr_body += f"- `discovery/{app_id}/{pass_def['artifact']}`\n"   # discovery.py:1347
    if rework_iter > 0:                                     # discovery.py:1349  BRANCH
        pr_body += f"\n**Rework iteration:** {rework_iter}\n"    # discovery.py:1350
    pr_input = CreatePRInput(repo=repo, source_branch=branch, target_branch="main",   # discovery.py:1352-1359
        title=f"Gate G-DC: Discovery Complete — {app_id}", body=pr_body,
        labels=["gate-review", "discovery", "G-DC"])
    return await workflow.execute_activity(create_pr, pr_input,        # discovery.py:1360-1365
        start_to_close_timeout=timedelta(seconds=60),
        retry_policy=RETRY_POLICIES["transient"])
```
- **Branches (3):** loop 1342; loop 1346; `if rework_iter > 0:` (1349).
- **Activity:** `create_pr` — `CreatePRInput(repo, source_branch=branch, target_branch="main",
  title, body, labels=["gate-review","discovery","G-DC"])`; **60s**; `transient`. Returns
  `CreatePRResult` (`pr_number`, `pr_url`, ...).
- ⚠️ **GOTCHA-PR-DISC-1 (PR body iterates ALL passes, including unproduced ones):** both loops walk
  `DISCOVERY_PASSES` (declaration order) — so the PR body lists EVERY declared pass as `- [x]` even
  if a patch-gated pass didn't run this build. The body is documentation; the authoritative evidence
  is the gate bundle. A rebuild must iterate the full pass dict, label via the map (default = pass_name
  for unmapped keys), and append the rework-iteration footer ONLY when `rework_iter > 0`.
- ⚠️ **GOTCHA-PR-DISC-2 (labels + target hardcoded):** `target_branch="main"`, labels exactly
  `["gate-review","discovery","G-DC"]`, NO `execution_context` (unlike base `_create_gate_pr` which
  threads one). A rebuild must match. The `—` in the title is an em-dash (U+2014).
- ⚠️ **GOTCHA-PR-DISC-3 (no reviewers):** `CreatePRInput.reviewers` defaults to `[]` — Discovery
  never sets reviewers.

### 5.10 `_build_evidence_data(...)` — OVERRIDE of base (`discovery.py:1367-1443`)
**OVERRIDES** `LineWorkflowBase._build_evidence_data`. Same signature, but emits a `passes` dict keyed
by pass_name (not `steps`), with per-pass `title`, and a top-level `pass_count`. Slim by default;
`include_content`/`content_paths` selectively inline file contents.
```text
def _build_evidence_data(self, app_id, assembly_line="Discovery", step="", *, include_content=False, content_paths=None):
    pass_titles = { ...same 10 label map as _create_gate_pr_discovery's pass_labels... }   # discovery.py:1388-1399
    passes = {}                                             # discovery.py:1401
    for pass_name, pass_def in DISCOVERY_PASSES.items():    # discovery.py:1402  LOOP
        artifacts = self._pass_results.get(pass_name, [])   # discovery.py:1403
        metadata  = self._agent_metadata.get(pass_name, {}) # discovery.py:1404
        output_files = metadata.get("output_files", [])     # discovery.py:1405
        raw_file_artifacts = []                             # discovery.py:1409
        for f in output_files:                              # discovery.py:1410  LOOP
            if not isinstance(f, OutputFile):               # discovery.py:1411  BRANCH → skip non-OutputFile
                continue
            content_str = f.content if isinstance(f.content, str) else ""   # discovery.py:1413  BRANCH (ternary)
            entry = {"path": f.path, "encoding": f.encoding,                  # discovery.py:1414-1418
                     "size": len(content_str.encode("utf-8")) if content_str else 0}  # discovery.py:1417  BRANCH (ternary)
            if include_content or (content_paths is not None and f.path in content_paths):  # discovery.py:1419-1421  BRANCH
                entry["content"] = f.content                # discovery.py:1422
            raw_file_artifacts.append(entry)                # discovery.py:1423
        deduped_file_artifacts = list({f["path"]: f for f in raw_file_artifacts}.values())  # discovery.py:1424-1426
        passes[pass_name] = {                               # discovery.py:1427-1436
            "title": pass_titles.get(pass_name, pass_name),
            "skill_id": pass_def["skill_id"], "artifact": pass_def["artifact"],
            "output": artifacts[0] if artifacts else "",    # discovery.py:1431  BRANCH (ternary)
            "metadata": {k: v for k, v in metadata.items() if k != "output_files"},  # discovery.py:1432-1434
            "file_artifacts": deduped_file_artifacts}
    return {                                                # discovery.py:1438-1443
        "assembly_line": "Discovery", "app_id": app_id,
        "pass_count": len([p for p in passes.values() if p["output"]]),   # discovery.py:1441  (comprehension)
        "passes": passes}
```
- **Branches (8):** loop 1402; loop 1410; `if not isinstance(f, OutputFile): continue` (1411);
  ternary `content_str` (1413); ternary `size` (1417); `if include_content or (...)` (1419); ternary
  `output` (1431); `pass_count` comprehension (1441).
- ⚠️ **GOTCHA-BE-DISC-1 (the override's RETURN SHAPE differs from base):** returns
  `{"assembly_line":"Discovery", "app_id", "pass_count", "passes": {pass_name: {...}}}` — **no
  `current_step` key**, a top-level `pass_count` = count of passes with a non-empty `output`, and the
  per-pass dict carries an extra `title` and an `artifact` field. The base returns `{...,
  "current_step", "steps": {...}}`. A rebuild MUST emit the Discovery shape verbatim — the gate-review
  cards and the dashboard stepper consume `passes`/`title`/`pass_count` (comment `discovery.py:1385-
  1387` ties titles to `dashboard/src/data/line-contracts/discovery.json`).
- ⚠️ **GOTCHA-SE-DISC (the base `_submit_gate_evidence` threshold-widening NO-OPS on Discovery):**
  the inherited `_submit_gate_evidence` builds a slim bundle via THIS override, then (if G-DC has
  `GATE_THRESHOLDS`) loops `slim_evidence.get("steps", {}).values()` to find threshold-target paths.
  But this Discovery bundle has NO `"steps"` key (it has `"passes"`), so `.get("steps", {})` returns
  `{}` and the widening loop finds NOTHING → `criteria_evidence` stays the slim bundle and NO file
  content is inlined for `check_gate_criteria`. Combined with `forward_risk_tier=False` (§4.2
  GOTCHA-FLOW-5), the `check_gate_criteria` input is the bare 4-field shape with NO evidence_data at
  all. A rebuild MUST preserve this: Discovery's evidence uses `passes`, the base widening keys on
  `steps`, so for Discovery the widening is a deliberate no-op and gate criteria are checked against
  artifact paths only.
- ⚠️ **GOTCHA-BE-DISC-2 (slim default, size always computed, dedup last-wins, strip output_files):**
  matches the base semantics: `content` omitted unless `include_content` or `f.path in content_paths`;
  `size` (utf-8 byte length) always set; `file_artifacts` deduped by path (last-wins via
  `{f["path"]: f}`); per-pass `metadata` strips the `output_files` key (surfaced as `file_artifacts`);
  non-`OutputFile` entries skipped. A rebuild keeps all five.

### 5.11 `_calculate_and_record_score(self, app_id) -> None` (`discovery.py:1445-1468`)
Two sequential activities: compute readiness score, record a snapshot. No branches.
```text
async def _calculate_and_record_score(self, app_id):
    score_input = CalculateReadinessScoreInput(app_id=app_id,
        dimensions=["code_quality", "architecture_clarity"])   # discovery.py:1447-1450
    score_result = await workflow.execute_activity(calculate_readiness_score, score_input,  # discovery.py:1451-1456
        start_to_close_timeout=timedelta(seconds=60),
        retry_policy=RETRY_POLICIES["transient"])
    snapshot_input = RecordScoreSnapshotInput(app_id=app_id, scores=score_result,
        snapshot_reason="discovery-complete")              # discovery.py:1458-1462
    await workflow.execute_activity(record_score_snapshot, snapshot_input,   # discovery.py:1463-1468
        start_to_close_timeout=timedelta(seconds=60),
        retry_policy=RETRY_POLICIES["transient"])
```
- **Branches (0).**
- **Activities (in order, sequential):** 1. `calculate_readiness_score` — `CalculateReadinessScoreInput(app_id, dimensions=["code_quality","architecture_clarity"])`; **60s**; `transient`. → returns `ReadinessScoreResult`. 2. `record_score_snapshot` — `RecordScoreSnapshotInput(app_id, scores=score_result, snapshot_reason="discovery-complete")`; **60s**; `transient`.
- ⚠️ **GOTCHA-SCORE-1 (only on approval, after merge):** called once at `_execute_discovery` line 590,
  AFTER `_reconcile_and_merge_with_retry_loop` succeeds and BEFORE the `discovery_complete` status
  push. Exactly two dimensions are scored (Discovery only assesses `code_quality` +
  `architecture_clarity`). A rebuild must pass these two dimensions and the `"discovery-complete"`
  reason, and call this ONLY on the approved path.
- ⚠️ **GOTCHA-SCORE-2 (`score_result` is the full dataclass, passed by value into snapshot):** the
  `ReadinessScoreResult` returned by the first activity is embedded directly into
  `RecordScoreSnapshotInput.scores` (1460) and serialized into the second activity's input. A rebuild
  must thread the result object, not re-fetch.

---

## 6. ACTIVITY & CHILD-WORKFLOW INVENTORY (full, in execution order)

**Child workflows:** NONE. Discovery is a leaf per-app workflow — no `execute_child_workflow`, no
`continue_as_new`. (`grep` confirms: zero child-workflow / continue-as-new calls in discovery.py.)

**Activities (sequence within one successful run, no rework):**

| # | Activity | Args | Timeout (start_to_close) | Heartbeat | Retry policy | non_retryable | activity_id | Seq/Par |
|---|----------|------|--------------------------|-----------|--------------|---------------|-------------|---------|
| 1 | `update_application_status` (via inherited `_set_step`→`_update_app_status`, many times) | `UpdateAppStatusInput` | 30s | — | `transient` | — | (none) | seq |
| 2 | `dispatch_agent_task` (catalog) | `AgentTaskInput` | 1h | **2m** | `agent_failure` | — | `agent-catalog` | seq |
| 3 | `dispatch_agent_task` (structural-analysis) + optional variant | `AgentTaskInput` | 1h | **2m** | `agent_failure` | — | `agent-structural-analysis` / `agent-{variant_skill}` | **parallel** (gather) |
| 4 | `dispatch_agent_task` ×3 (+2 +1 patch-gated) parallel passes | `AgentTaskInput` | 1h | **2m** | `agent_failure` | — | `agent-{pass}` | **parallel** (gather) |
| 5a | (commit-before-synthesis patch) `write_artifacts_batch` per INPUT pass via `_commit_one_pass` | `WriteArtifactsBatchInput` | 120s | — | `transient` | — | `commit-{pass}` | seq (per input pass, BEFORE synthesis) |
| 5b | (commit-before-synthesis patch) `update_agent_task_output_ref` per pass (patch-gated, best-effort) | positional `[app_id, "discovery-{pass}", path]` | 30s | — | `transient` | — | `patch-output-ref-{pass}` | seq |
| 6 | `dispatch_agent_task` (synthesis) + (tco-baseline) — repo/ref-hydrated in commit-before-synthesis mode | `AgentTaskInput` | 1h | **2m** | `agent_failure` | — | `agent-synthesis` / `agent-tco-baseline` | **parallel** (gather) |
| 7 | `write_artifacts_batch` (batched, via `_commit_one_pass`) OR `write_artifact` (legacy) — per remaining non-empty pass | `WriteArtifactsBatchInput` / `WriteArtifactInput` | 120s / 60s | — | `transient` | — | `commit-{pass}` (+`commit-file-{pass}-{path}` legacy) | seq (per pass) |
| 8 | `update_agent_task_output_ref` (per pass, patch-gated, best-effort) | positional `[app_id, "discovery-{pass}", path]` | 30s | — | `transient` | — | `patch-output-ref-{pass}` | seq |
| 9 | `persist_decomposition_map` (best-effort, if catalog/synthesis JSON) | `PersistDecompositionMapInput` | 30s | — | `transient` | — | `persist-decomposition-map` | seq |
| 10 | `persist_discovery_side_effects` (best-effort) | `PersistDiscoverySideEffectsInput` | 30s | — | `transient` | — | `persist-discovery-side-effects` | seq |
| 11 | `persist_capability_catalog` (best-effort, if cap JSON) | `PersistCapabilityCatalogInput` | 30s | — | `transient` | — | `persist-capability-catalog` | seq |
| 12 | `create_pr` (via `_create_gate_pr_discovery`) | `CreatePRInput` | 60s | — | `transient` | — | (none) | seq |
| 13 | `create_gate_record` | `CreateGateRecordInput(gate_type="G-DC")` | 30s | — | `transient` | — | (none) | seq |
| 14 | `check_gate_criteria` (via inherited `_submit_gate_evidence`, `forward_risk_tier=False`) | `CheckGateCriteriaInput` (bare 4-field) | 60s | — | `transient` | — | (none) | seq |
| 15 | `submit_gate_evidence` (via inherited `_submit_gate_evidence`) | `SubmitGateEvidenceInput` (slim bundle) | 60s | — | `transient` | — | (none) | seq |
| 16 | `dispatch_agent_task` (gate-pre-review, via inherited `_run_gate_pre_review`) | `AgentTaskInput(skill_id="gate-pre-review")` | 10m | (base) | `transient` | — | (none) | seq (try) |
| 17 | `store_gate_pre_review` (via `_run_gate_pre_review`, if markdown) | `StoreGatePreReviewInput` | 30s | — | `transient` | — | (none) | seq |
| 18 | `mark_gate_ready_for_review` (via `_run_gate_pre_review`, `finally`, patch-gated) | positional `gate_id` | 30s | — | `transient` | — | (none) | seq (finally) |
| 19 | `update_application_status` ("gate_review") | `UpdateAppStatusInput` | 30s | — | `transient` | — | (none) | seq |
| — | **WAIT** `_wait_for_gate_decision(G_DC)` — blocks on `len(_gate_decisions)>consumed or self.cancelled` | — | — | — | — | — | — | wait |
| 20 | (approve) `reconcile_and_merge_pr` (via inherited merge loop) | `MergePRInput(merge_method="merge")` | 60s | — | **`git_merge`** | **MergeConflict / MergeDivergenceUnresolved / MergeBranchProtectionRejected** | (none) | loop |
| 21 | (merge_blocked) `set_gate_merge_blocked` (via merge loop) | positional `[gate_id, detail]` | 30s | — | `transient` | — | (none) | loop |
| 22 | (approve) `calculate_readiness_score` (via `_calculate_and_record_score`) | `CalculateReadinessScoreInput` | 60s | — | `transient` | — | (none) | seq |
| 23 | (approve) `record_score_snapshot` | `RecordScoreSnapshotInput` | 60s | — | `transient` | — | (none) | seq |
| 24 | (approve) `update_application_status` ("discovery_complete"/"completed") | `UpdateAppStatusInput` | 30s | — | `transient` | — | (none) | seq |
| — | (reject) `_bump_rework("G-DC")` then loop → re-run #4, #5a/b, #6, #7… | — | — | — | — | — | — | rework |
| 25 | (max-rework) `update_application_status` ("discovery_failed"/"max-rework-exceeded") | `UpdateAppStatusInput` | 30s | — | `transient` | — | (none) | seq |
| 26 | (any exception) `update_application_status` ("discovery_failed"/"failed", best-effort) | `UpdateAppStatusInput` | 30s | — | `transient` | — | (none) | seq |

> ⚠️ **GOTCHA-ACT-1 (agent dispatch uses `agent_failure` + 2m heartbeat, everything else `transient`,
> merge uses `git_merge`):** the ONLY `agent_failure`-policy activities are the `dispatch_agent_task`
> calls in `_dispatch_pass`/`_dispatch_discovery_patterns_variant` (the gate-pre-review dispatch in the
> base uses `transient`). Those Discovery agent dispatches are ALSO the ONLY activities carrying a
> **2-minute `heartbeat_timeout`**. The ONLY `git_merge`-policy activity is `reconcile_and_merge_pr`
> (inherited merge loop). All others are `transient` with no heartbeat. A rebuild must match
> per-activity policy + heartbeat exactly.
> ⚠️ **GOTCHA-ACT-2 (NEW: commit happens TWICE-ish per loop in commit-before-synthesis mode):** in that
> mode each INPUT pass is committed BEFORE synthesis (rows 5a/5b), then `_commit_artifacts` (row 7)
> RE-uses those `_committed_pass_paths` entries (no re-commit) and commits only synthesis/tco-baseline.
> Pre-patch (no commit-before-synthesis), rows 5a/5b don't exist and row 7 commits ALL non-empty passes
> for the first time. A rebuild must reproduce both histories under the respective patch states.

---

## 7. GATE HANDLING (G-DC) — evidence, wait, routing, rework

**Gate:** single gate **G-DC** (`SINGLE_GATE_KEY="G-DC"`, `GateType.G_DC = "G-DC"`).

**Evidence assembly (per build / rework iteration):**
1. (commit-before-synthesis patch) Commit each completed INPUT pass to the branch via `_commit_one_pass`
   BEFORE synthesis (§4.2 BRANCH-NEW) → populates `_committed_pass_paths`.
2. Commit all pass artifacts (§5.8) → `artifact_paths` (deduped committed paths) — reusing the
   already-committed input passes and committing synthesis/tco-baseline.
3. `create_gate_record(gate_type="G-DC", app_id, portfolio_id, workflow_id, evidence_package_url=pr_url)`
   → `gate_record.gate_id`.
4. Inherited `_submit_gate_evidence(gate_id, GateType.G_DC, app_id, artifact_paths, pr_url,
   "Discovery", "gate-review", forward_risk_tier=False)` — builds the SLIM `passes` bundle via the
   §5.10 override, checks criteria (bare 4-field input — GOTCHA-SE-DISC + GOTCHA-FLOW-5), submits slim
   bundle.
5. Inherited `_run_gate_pre_review(gate_id, "G-DC", artifact_paths, artifact_repo=repo,
   artifact_ref=branch)` — advisory AI pre-review (best-effort), then `finally` flips gate
   ready-for-review under `mark-gate-ready-for-review-v1` (base spec §12).
6. `_update_app_status("gate_review", "gate-review", "Discovery")`.

**The wait:** inherited `_wait_for_gate_decision(GateType.G_DC)` (base spec §13). Blocks on
`wait_condition(lambda: len(self._gate_decisions) > consumed or self.cancelled)`. The decision is
buffered by the inherited `gate_approved`/`gate_rejected` signals (5-tuples). Returns
`"approved"`/`"rejected"`/`"cancelled"`. On reject it SETS `_rework_feedback["G-DC"]`; on approve it
POPS it.

**Routing (the four reviewer outcomes → Discovery behavior):**
- **approve** → `decision=="approved"` (577): inherited `_reconcile_and_merge_with_retry_loop(repo,
  pr_number, gate_id, merge_method="merge")` → `_calculate_and_record_score` → status
  `discovery_complete`/`completed` → set COMPLETED/100.0/"completed" → return `"completed"`.
- **merge_blocked** → NOT a `_wait_for_gate_decision` outcome. It is a POST-approval state inside the
  inherited merge loop: a structured merge error (MergeConflict / MergeDivergenceUnresolved /
  MergeBranchProtectionRejected) → `set_gate_merge_blocked` → wait for `merge_retry` signal (reviewer
  clicks "Resolve & Retry Merge") or cancel → loop (base spec §14). Discovery just calls the loop;
  routing lives there.
- **reject** → fall-through (611): `_bump_rework("G-DC")`; if count > 3 → FAIL (status
  `discovery_failed`/`max-rework-exceeded`, return `"failed"`); else `_run_parallel_passes(...)` (with
  feedback) → loop to re-commit-input-passes + re-synthesis.
- **cancel** → `decision=="cancelled"` (574) → return `"cancelled"` (the wait already set
  `_status=CANCELLED`).

**The rework loop & counters (EXACT):**
- Counter: `_rework_iterations["G-DC"]`, bumped by `_bump_rework("G-DC")` (611) — SUBCLASS bumps, NOT
  the wait (base GOTCHA-WG5).
- Ceiling: `MAX_REWORK_ITERATIONS = 3`. Test is `_rework_count("G-DC") > 3` AFTER the bump (612).
  → tolerates rework iterations producing counts 1,2,3; FAILS on the bump that yields 4 (the 4th
  rejection).
- Feedback: `_rework_feedback["G-DC"]` (6-key dict: `gate, rejected_by, reason, reason_category,
  card_decisions, rejected_at`) set by `_wait_for_gate_decision` on reject; forwarded to EVERY
  re-dispatched pass via `_dispatch_pass`/`_dispatch_discovery_patterns_variant`
  `context["rework_feedback"]`; cleared (popped) by `_wait_for_gate_decision` on a later approve.
- Rework re-runs ONLY passes 2-4 + [commit-input-passes] + synthesis/tco/commit/PR/gate (catalog +
  structural are NOT re-run; GOTCHA-FLOW-4).

---

## 8. RESILIENCE

- **Timeouts (start_to_close):** agent dispatch (every pass) **1h**; `update_application_status` 30s;
  `write_artifacts_batch` 120s; `write_artifact` (legacy) 60s; `update_agent_task_output_ref` 30s;
  the three persist activities 30s each; `create_pr` 60s; `create_gate_record` 30s;
  `check_gate_criteria` 60s; `submit_gate_evidence` 60s; gate-pre-review dispatch 10m;
  `store_gate_pre_review` 30s; `mark_gate_ready_for_review` 30s; `reconcile_and_merge_pr` 60s;
  `set_gate_merge_blocked` 30s; `calculate_readiness_score`/`record_score_snapshot` 60s.
- **Heartbeats (CHANGED at HEAD):** every Discovery `dispatch_agent_task` (catalog, structural,
  variant, the 3-6 parallel passes, synthesis, tco-baseline) carries a **2-minute `heartbeat_timeout`**
  (`discovery.py:700`, `831`) — the activity heartbeats ~every 30s; a stalled/dead dispatch is
  detected in ~2 min instead of waiting the full 1h. (The inherited gate-pre-review dispatch keeps the
  base's heartbeat behavior.) No OTHER Discovery activity sets a heartbeat. A rebuild MUST set the 2m
  heartbeat on every Discovery agent dispatch.
- **continue-as-new:** NONE. The rework loop is an in-place `while True` — history grows with each
  rework iteration (bounded at 4 rejections → fail). A rebuild does NOT continue-as-new.
- **Idempotency / determinism:** deterministic `activity_id`s (`agent-{pass}`, `commit-{pass}`,
  `patch-output-ref-{pass}`, `commit-file-{pass}-{path}`) make those activities replay-stable. Branch
  name + workspace_key derived from `workflow_id` (deterministic). `workflow.now().isoformat()` used
  for all artifact timestamps (deterministic). `_commit_one_pass` is idempotent (re-commit = no-op
  tree advance). ALL FIVE `workflow.patched(...)` IDs are replay-load-bearing and MUST be verbatim:
  `"discovery-data-steps-v1"`, `"discovery-capability-extraction-v1"`,
  **`"discovery-commit-before-synthesis-v1"`**, `"discovery-batch-writes-v1"`,
  `"patch-output-artifact-ref-v1"` (×2 sites: `_commit_one_pass` + legacy). (`"context-priors-v1"` /
  `"mark-gate-ready-for-review-v1"` live in the inherited base helpers, not in discovery.py directly.)
- **Best-effort activities (failures swallowed, never fatal):** `persist_decomposition_map`,
  `persist_discovery_side_effects`, `persist_capability_catalog` (each in its own `try/except
  Exception: workflow.logger.exception(...)`); `update_agent_task_output_ref` (try/except…pass); the
  inherited gate-pre-review + ready-flip + Layer-B `step_execution` emission. A failure in any of these
  does NOT interrupt the gate flow.
- **Compensation / rollback:** NONE. There is no rollback path. Failure semantics:
  - ANY unhandled exception in `_execute_discovery` → caught by `run()` → `_status=FAILED`,
    `_current_step="failed"`, best-effort `discovery_failed`/`failed` status push, re-raise (workflow
    fails). (GOTCHA-RUN-3.)
  - Rework exhaustion (4th reject) → `_status=FAILED`, `discovery_failed`/`max-rework-exceeded`, return
    `"failed"` (clean return, NOT an exception).
  - Cancel (`self.cancelled` set by `cancel_workflow`) → every inherited `wait_condition` (gate wait,
    merge-blocked wait) drains; gate wait returns `"cancelled"` → `_execute_discovery` returns
    `"cancelled"` (no terminal `_status` set here; the wait set `_status=CANCELLED`).
  - Structured merge error → `merge_blocked` + wait for reviewer retry (inherited loop; never fails the
    workflow on its own).

---

## 9. BEHAVIORAL PARITY CHECKLIST

A rebuilt `DiscoveryWorkflow` MUST satisfy ALL of the following:

1. `@workflow.defn class DiscoveryWorkflow(LineWorkflowBase)` with classvars `ASSEMBLY_LINE=DISCOVERY`,
   `ARTIFACT_ROOT="discovery"`, `LINE_LABEL="Discovery"`, `STATUS_PREFIX="discovery"`,
   `STEPS=DISCOVERY_PASSES`, `STEP_WEIGHTS=<contract weights>`, `SINGLE_GATE_KEY="G-DC"`.
2. `__init__` calls `super().__init__()` first, then sets `_complexity_tier=None`, `_pass_results={}`,
   **and `_committed_pass_paths={}`**. It uses `_pass_results` (NOT the base `_step_results`) as the
   artifact bucket, `_committed_pass_paths` for committed branch paths, and the shared `_agent_metadata`
   for telemetry (keyed by pass_name, plus the variant skill_id).
3. Defines exactly ONE new signal: `reclassify_complexity(new_tier)` (`async def`, `@workflow.signal`),
   which sets `_complexity_tier=ComplexityTier(new_tier)` inside try/except ValueError (invalid →
   no-op) and bumps `_updated_at`. NO wait_condition consumes it. Does NOT redefine the four base gate
   signals or `get_status`.
4. `run()` sets `_status=RUNNING`/`_started_at`/`_updated_at`/`_complexity_tier`, derives
   `run_suffix = wf_id.rsplit("-",1)[-1] if "-" in wf_id else wf_id[:8]`,
   `branch="olympus/discovery/{app_id}/{run_suffix}"`, `workspace_key="discovery-{app_id}-{run_suffix}"`,
   calls `_execute_discovery` in try/except; on exception sets FAILED/"failed"/timestamp, best-effort
   pushes `discovery_failed`/"failed", re-raises.
5. `_execute_discovery` runs the LINEAR prelude ONCE: Step1 catalog (`_set_step("catalog",0.0)` →
   `_dispatch_pass("catalog", prior_artifacts)`); Step2 structural (`_set_step("structural-analysis",
   STEP_WEIGHTS["catalog"])` → select variant → gather [`structural-analysis` dispatch, optional
   variant dispatch] → merge variant outputs into the structural bucket iff dispatched); Step3
   `_run_parallel_passes`. Catalog + structural are OUTSIDE the rework loop. Then read
   `commit_before_synthesis = workflow.patched("discovery-commit-before-synthesis-v1")`.
6. The synthesis+gate+rework loop is `while True`: **if `commit_before_synthesis`, commit every input
   pass (skip synthesis/tco-baseline/gate-readiness-check; only passes with results) via
   `_commit_one_pass`** → `_collect_all_pass_artifacts` → `_run_synthesis_and_tco` (passing
   `artifact_repo=repo`/`artifact_ref=branch` iff `commit_before_synthesis`, else `""`/`""`; store
   synthesis + tco-baseline) → `_set_step("commit-artifacts", <7-term cumsum>)` → `_commit_artifacts` →
   3 best-effort persists (decomposition-map iff catalog|synthesis JSON; side-effects always;
   capability-catalog iff cap JSON) → `_set_step("create-pr", <8-term>)` → `_create_gate_pr_discovery`
   → `create_gate_record("G-DC")` → `_submit_gate_evidence(..., forward_risk_tier=False)` →
   `_set_step("gate-readiness-check", <9-term>)` → `_run_gate_pre_review` → status "gate_review" →
   `_set_step("gate-review", <10-term>)` → `_wait_for_gate_decision(G_DC)`.
7. Gate routing: `"cancelled"`→return `"cancelled"`; `"approved"`→merge loop (`merge_method="merge"`)→
   `_calculate_and_record_score`→status `discovery_complete`/"completed"→set
   COMPLETED/100.0/"completed"→return `"completed"`; ELSE (rejected)→`_bump_rework("G-DC")`, if
   `_rework_count("G-DC")>3` set FAILED/"max-rework-exceeded"+status+return `"failed"`, else
   `_run_parallel_passes` (with feedback) and loop. Discovery does NOT auto-start Rationalization.
8. `_dispatch_pass`: signature includes `artifact_repo=""`/`artifact_ref=""`; attaches
   `context["rework_feedback"]=_rework_feedback["G-DC"]` iff present;
   `AgentTaskInput(task_type="discovery-{pass}", skill_id=pass_def["skill_id"],
   artifact_repo=..., artifact_ref=..., ...)`; `dispatch_agent_task` 1h/**2m heartbeat**/
   `agent_failure`/`activity_id="agent-{pass}"`; records 6-field `_agent_metadata[pass]`. No
   execution_context, no context-priors, no patch gate.
9. `_select_discovery_patterns_variant` (pure): returns `None` on empty/non-str/blank/JSON-fail/
   non-dict catalog; else builds a fingerprint preferring `tech_fingerprint` dict, else normalizing
   `tech_stack` (flatten language dicts→names, forward `databases` verbatim + scalar `database`=first,
   `runtimes` under both `platforms` and `runtimes`), defaults `has_source_available` to True when
   absent/non-bool, returns `select_discovery_patterns_skill(fingerprint, has_source_available)`.
10. `_dispatch_discovery_patterns_variant`: like `_dispatch_pass` but `task_type="discovery-{skill_id}"`,
    `skill_id=skill_id`, `activity_id="agent-{skill_id}"`, **2m heartbeat**, metadata under
    `_agent_metadata[skill_id]`; NO `artifact_repo`/`artifact_ref` params; its outputs are merged into
    `_pass_results["structural-analysis"]` by the caller.
11. `_run_parallel_passes`: `_set_step` the 3 legacy passes at `cumulative_base=catalog+structural`;
    under `workflow.patched("discovery-data-steps-v1")` ALSO `_set_step`+dispatch
    data-domain-discovery + shared-database-analysis; under
    `workflow.patched("discovery-capability-extraction-v1")` ALSO capability-extraction (inputs =
    structural + catalog); ONE `asyncio.gather`; result-unpack positionally with `idx` bookkeeping
    matching dispatch order. Both patch IDs verbatim and gating set_step + dispatch + unpack.
12. `_run_synthesis_and_tco`: signature includes `artifact_repo=""`/`artifact_ref=""`;
    `_set_step("synthesis"/"tco-baseline", <5-term cumsum>)`; synthesis gets `synthesis_input_artifacts`
    + the repo/ref; TCO gets ONLY catalog+structural artifacts (preferring `_committed_pass_paths` via
    `committed-or-raw` fallback) + the repo/ref; `asyncio.gather`; returns `(synthesis_result,
    tco_result)`.
13. `_extract_pass_content`: returns `""` if no target artifact; else first file whose path ends with
    the target, else first `.json` file, else `""`; returns `f.content or ""`.
14. `_collect_all_pass_artifacts`: iterate `DISCOVERY_PASSES` keys (excluding synthesis/tco-baseline/
    gate-readiness-check) collecting **`_committed_pass_paths[pass] or _pass_results[pass]`**, then
    defensively fold any other `_pass_results` keys (excluding synthesis/tco-baseline, same
    committed-or-raw preference), `dedup_paths` the result.
15. `_commit_artifacts` dispatches to `_commit_artifacts_batched` under
    `workflow.patched("discovery-batch-writes-v1")` else `_commit_artifacts_legacy`. **Batched: iterate
    `DISCOVERY_PASSES` KEYS; for a pass already in `_committed_pass_paths` extend+continue (reuse the
    incremental commit); else delegate to `_commit_one_pass`; `dedup_paths`.** `_commit_one_pass`:
    early-return `[]` for unknown pass / no artifacts; ONE `write_artifacts_batch` (summary JSON at
    `discovery/{app}/{artifact}` + each output file at `discovery/{app}/files/{pass}/{path}`)
    120s/`transient`/`activity_id="commit-{pass}"`; then output-ref patch (positional `[app,
    "discovery-{pass}", path]`, 30s/`transient`/`activity_id="patch-output-ref-{pass}"`, patch-gated,
    try/except…pass); record `_committed_pass_paths[pass]`. Legacy: iterate `.items()`; `write_artifact`
    for summary (60s) then output-ref patch then per-file `write_artifact` (60s,
    `activity_id="commit-file-{pass}-{path-with-/→-}"`); NO `_committed_pass_paths` write. Both skip
    passes with no artifacts; both dedup committed paths; both use the EXACT 10-key summary JSON with
    `workflow.now()` timestamp.
16. `_create_gate_pr_discovery`: builds markdown body (header + `- [x] {label} ({skill_id})` per pass +
    `### Artifacts` list of `discovery/{app}/{artifact}` per pass + rework footer iff `rework_iter>0`),
    `CreatePRInput(target_branch="main", labels=["gate-review","discovery","G-DC"], title="Gate G-DC:
    Discovery Complete — {app}")`, `create_pr` 60s/`transient`.
17. `_build_evidence_data` OVERRIDE returns `{"assembly_line":"Discovery","app_id","pass_count","passes"}`
    (NO `current_step`, NO `steps`), `passes` keyed by pass_name with `title`/`skill_id`/`artifact`/
    `output`/`metadata`(sans output_files)/`file_artifacts`(slim, size-always, dedup last-wins,
    skip non-OutputFile), `pass_count`=count of passes with non-empty `output`. The base
    `_submit_gate_evidence` threshold-widening (`.get("steps",{})`) is a deliberate no-op on this shape.
18. `_calculate_and_record_score`: `calculate_readiness_score(dimensions=["code_quality",
    "architecture_clarity"])` 60s/`transient`, then `record_score_snapshot(scores=result,
    snapshot_reason="discovery-complete")` 60s/`transient`. Called only on the approved path, after
    merge.
19. NO child workflows, NO continue-as-new. The ONLY heartbeats are the 2m `heartbeat_timeout` on the
    Discovery agent dispatches. Best-effort activities swallow exceptions. `self.cancelled` threaded
    (inherited) into every wait. The four base gate signals + `get_status` are inherited, never
    redefined.
20. All **FIVE** replay-load-bearing patch IDs reproduced verbatim: `"discovery-data-steps-v1"`,
    `"discovery-capability-extraction-v1"`, **`"discovery-commit-before-synthesis-v1"`**,
    `"discovery-batch-writes-v1"`, `"patch-output-artifact-ref-v1"` (`_commit_one_pass` + legacy sites).
    Inherited helpers additionally gate on `"context-priors-v1"` / `"mark-gate-ready-for-review-v1"`
    (base spec).
