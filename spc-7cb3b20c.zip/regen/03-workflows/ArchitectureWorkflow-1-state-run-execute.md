# `ArchitectureWorkflow` — Part 1: module helpers, state, signals, `run()`, `_execute_architecture` (ATOMIC regeneration spec)

> **Source of truth:** `temporal/olympus_workflows/workflows/architecture.py`. Every
> `architecture.py:line` citation is against that file. **This file owns lines 1–1264 ONLY**
> (module helpers, step registries, `__init__`, the two subclass signal handlers, `run()`,
> `_is_system_umbrella`, `_should_run_step`, `_read_target_source_artifacts_index`,
> `_realize_consolidation_grain_if_present`, `_execute_architecture`).
>
> Lines **1264–2192** (the step helpers `_derive_target_state_mapping_from_plan`,
> `_run_agent_step`, `_run_agent_step_task`, `_wait_for_data_ready`,
> `_provision_target_repo_for_this_run`, `_render_target_repo_readme`,
> `_fire_target_provisioned_signal`, and the overrides `_dispatch_agent`,
> `_build_evidence_data`, `_collect_committed_paths`, `_create_gate_pr_architecture`) are
> **sibling-owned** — referenced here by name + contract, not reproduced. Where `run()` /
> `_execute_architecture` *calls* one of those helpers, this spec states the call site, its
> args, and the externally-observable contract (activities fired, retry/timeout, mutations)
> so a rebuild can wire the call correctly even before the sibling file is read.
>
> **Inheritance:** `class ArchitectureWorkflow(LineWorkflowBase)` (`architecture.py:378-379`).
> See `_LineWorkflowBase.md` for the inherited engine (gate signals, `_wait_for_gate_decision`,
> `_reconcile_and_merge_with_retry_loop`, `_set_step`, `_update_app_status`,
> `_submit_gate_evidence`, `_run_gate_pre_review`, `_commit_step_artifacts`,
> `_bump_rework`/`_rework_count`, `get_status` query, the four base gate signals, rework
> mechanics) and `_HILSignalsMixin.md` for the HIL signals (`cancel_workflow`→`self.cancelled`
> etc.). **This subclass adds two new signals, overrides four methods, and supplies `run()`.**

---

## 0. OVERRIDE / NEW-METHOD MATRIX (what this subclass changes vs. the base)

| Method | Base behavior (`_LineWorkflowBase.md`) | This subclass | In my scope (≤1264)? |
|--------|----------------------------------------|---------------|----------------------|
| `gate_approved` / `gate_rejected` / `escalation_resolved` / `merge_retry` | base `@workflow.signal` (GOTCHA-SIG0) | **NOT redefined** — inherited verbatim | n/a |
| `get_status` query | base `@workflow.query` | **NOT redefined** — inherited | n/a |
| `stakeholder_approved` | *(does not exist on base)* | **NEW `@workflow.signal`** (§3.1) | ✅ yes (437-456) |
| `data_ready_for_target` | *(does not exist on base)* | **NEW `@workflow.signal`** (§3.2) | ✅ yes (458-498) |
| `run()` / `_execute()` | absent on base | **`@workflow.run def run`** (§5) + `_execute_architecture` (§9) | ✅ yes (504-1258) |
| `_dispatch_agent` | base 5-branch dispatcher | **OVERRIDDEN** (threads `source_repo`, step-10 router, tier-2 model preference, 3h/1h timeout, 2m heartbeat) | ❌ sibling (1919-2032) |
| `_build_evidence_data` | base slim/enriched builder | **OVERRIDDEN** (arch-specific bundle, `data_architecture` block) | ❌ sibling (2034-2103) |
| `_collect_committed_paths` | *(not on base — convenience)* | **NEW helper** (dedup over `ARCHITECTURE_STEPS`) | ❌ sibling (2105-2110) |
| `_task_type_prefix`, `_rework_gate_key_for_step`, `_primary_skill_for_step`, `_evidence_step_metadata`, `_evidence_steps_iter` | base defaults | **NOT overridden** — uses base defaults (single gate `G-02`, `skill_id` shape) | n/a |
| `_set_step`, `_update_app_status`, `_submit_gate_evidence`, `_wait_for_gate_decision`, `_run_gate_pre_review`, `_reconcile_and_merge_with_retry_loop`, `_commit_step_artifacts`, `_execution_ctx`, `_bump_rework`, `_rework_count` | base | **NOT overridden** — inherited; called by `run()`/`_execute_architecture` | n/a (called) |

> ⚠️ **GOTCHA-ARCH-OVR (`_rework_gate_key_for_step` is NOT overridden → single gate):** because
> `SINGLE_GATE_KEY = "G-02"` (`architecture.py:395`) and the base default returns
> `self.SINGLE_GATE_KEY`, every step's rework feedback routes to the `"G-02"` key. The override
> `_dispatch_agent` (sibling, 1936-1939) **does not** call `_rework_gate_key_for_step` — it reads
> `self._rework_feedback.get("G-02")` directly (`architecture.py:1937`). A rebuild's `_dispatch_agent`
> override must hard-code `"G-02"`, matching the sibling file; the base default still applies to any
> path that does use the hook.

---

## 1. MODULE-LEVEL CONSTANTS (`architecture.py:128-145, 375`)

| Constant | Value | Line | Purpose / consumed by |
|----------|-------|------|------------------------|
| `_DATA_READY_WAIT_TIMEOUT_SECONDS` | `24 * 60 * 60` (86400) | 131 | overall cap for the data-ready handshake wait (sibling `_wait_for_data_ready`) |
| `_REGISTRY_POLL_INTERVAL_SECONDS` | `15` | 137 | legacy `arch-data-registry-v1` poll cadence (sibling) |
| `_DB_BACKSTOP_INTERVAL_SECONDS` | `5 * 60` (300) | 145 | DB-backstop interval under `arch-data-signal-first-v1` (sibling) |
| `MAX_REWORK_ITERATIONS` | `3` | 375 | **rework ceiling consumed in `_execute_architecture`** (§9 gate loop) |

> ⚠️ **GOTCHA-WEIGHTS-ASSERT (module-import-time assertion):** `architecture.py:371-373`:
> `assert abs(sum(STEP_WEIGHTS.values()) - 100.0) < 0.01, "STEP_WEIGHTS must sum to 100"`. This
> runs at **import time**. A rebuild's `STEP_WEIGHTS` (§2) MUST sum to exactly 100.0 or the
> module fails to import (and the worker won't register the workflow).

---

## 2. STEP REGISTRIES (module-level — drive `_execute_architecture`)

### 2.1 `ARCHITECTURE_STEPS: dict[str, dict]` (`architecture.py:200-319`)

`step_id -> {title, skill_id, artifact, kind, write_to_target?, dispatch_via?}`. **Ordering of
keys matters** — `_collect_committed_paths` (sibling) and `_build_evidence_data` (sibling)
iterate `ARCHITECTURE_STEPS` in insertion order. Exact contents:

| step_id | title | skill_id | artifact | kind | write_to_target | dispatch_via |
|---------|-------|----------|----------|------|-----------------|--------------|
| `target-state-mapping` | Target-State Mapping | `target-state-mapper` | `target-application-map.json` | `agent` | — | — |
| `cloud-pattern-selection` | Target Architecture Strategy | `migration-strategy-advisor` | `cloud-pattern.json` | `agent` | **True** | — |
| `ea-compliance` | EA Compliance Verification | `ea-compliance` | `ea-compliance.json` | `agent` | — | — |
| `integration-arch` | Integration Architecture | `api-contract-validator` | `integration-arch.json` | `agent` | **True** | — |
| `data-architecture` | Data Architecture Handshake | `None` | `None` | **`code`** | — | — |
| `security-arch` | Security Architecture | `cato-compliance` | `security-arch.json` | `agent` | — | — |
| `design-system` | Design System Mapping | `design-system` | `design-system.json` | `agent` | **True** | — |
| `accessibility-review` | Accessibility Review | `accessibility-reviewer` | `accessibility-review.json` | `agent` | — | — |
| `ai-ml-integration` | AI/ML Integration | `ai-ml-integration` | `ai-ml-integration.json` | `agent` | — | — |
| `blueprint-assembly` | Blueprint Assembly | `blueprint-assembly` | `architecture-blueprint.json` | `agent` | **True** | — |
| `cloud-cost-estimate` | Cloud Cost Estimate | `cloud-cost-estimator` | `cost-estimate.yaml` | `agent` | — | — |
| `well-architected-review` | Well-Architected Review | `well-architected-reviewer` | `well-architected-review.json` | `agent` | — | — |
| `traceability-validation` | Architecture Traceability Validation | `architecture-traceability-validator` | `traceability-validation.md` | `agent` | — | — |
| `ai-pre-review` | AI Pre-Review | `gate-pre-review` | `pre-review.json` | `agent` | — | **`base_gate_pre_review`** |

> ⚠️ **GOTCHA-STEP-DA (`data-architecture` is `kind="code"`, skill_id/artifact `None`):**
> `architecture.py:238-245`. It is a **signal wait** (sibling `_wait_for_data_ready`), not an
> agent dispatch. `_build_evidence_data` (sibling, 2057-2059) skips any `kind == "code"` step.
> Its artifact refs are tracked via `self._step_committed_paths["data-architecture"]` (set in
> `_execute_architecture`, 906-910), NOT via the agent path. A rebuild must NOT dispatch an agent
> for it and must NOT give it an `artifact`.
> ⚠️ **GOTCHA-STEP-PREREVIEW (`ai-pre-review` has `dispatch_via="base_gate_pre_review"`):**
> `architecture.py:312-318`. It is dispatched through the **inherited** `_run_gate_pre_review`
> helper (task_type `gate-pre-review`, skill_id `gate-pre-review`), **not** through
> `_run_agent_step`. It therefore **never lands in `self._step_results`** and never goes through
> `_commit_step_artifacts`. It exists in the dict purely so the gate-card registry matches the
> line contract's `evidence_steps()` (CI guard). A rebuild must keep it in the dict but dispatch
> it via the base pre-review path only.
> ⚠️ **GOTCHA-STEP-WTT (`write_to_target` set on exactly four steps):** `cloud-pattern-selection`,
> `integration-arch`, `design-system`, `blueprint-assembly` carry `write_to_target: True`. The
> sibling `_run_agent_step` mirrors those steps' agent file artifacts into the target repo under
> `docs/architecture/{step}/` ONLY when `self._target_repo_url` is set. Step summary JSON always
> lands in `artifact_repo`. A rebuild must set this flag on exactly those four steps.

### 2.2 `STEP_WEIGHTS: dict[str, float]` (`architecture.py:328-351`)

Sum **must** be 100.0 (GOTCHA-WEIGHTS-ASSERT). Exact values, **consumed only inside
`_execute_architecture`** (the base never reads it — base GOTCHA-CV1):

```
target-state-mapping=6.0   cloud-pattern-selection=10.0   ea-compliance=8.0
integration-arch=10.0      data-architecture=6.0          security-arch=10.0
design-system=8.0          accessibility-review=6.0       ai-ml-integration=4.0
blueprint-assembly=8.0     cloud-cost-estimate=2.0        well-architected-review=2.0
traceability-validation=2.0  commit-blueprint-artifacts=2.0  create-g-02-pr=2.0
ai-pre-review=4.0          gate-review-02=6.0             persist-architecture-side-effects=2.0
merge-blueprint-pr=2.0
```
(Sum = 6+10+8+10+6+10+8+6+4+8+2+2+2+2+2+4+6+2+2 = 100.0.)

> ⚠️ **GOTCHA-WEIGHTS-EXTRA (weights cover steps NOT in ARCHITECTURE_STEPS):**
> `commit-blueprint-artifacts`, `create-g-02-pr`, `gate-review-02`,
> `persist-architecture-side-effects`, `merge-blueprint-pr` have weights but are **not keys in
> `ARCHITECTURE_STEPS`** — they are logical stepper markers used only to advance
> `running_progress`/`blueprint_progress` in `_execute_architecture`. A rebuild must include them
> in `STEP_WEIGHTS` (for the 100.0 sum and for progress math) but must NOT add them to
> `ARCHITECTURE_STEPS`.

### 2.3 `SYSTEM_UMBRELLA_ARCHITECTURE_STEPS: frozenset[str]` (`architecture.py:361-368`)

```
frozenset({"target-state-mapping", "design-system", "ea-compliance",
           "well-architected-review", "traceability-validation", "blueprint-assembly"})
```
The abridged step set the cross-cutting `system` umbrella target runs. Consumed by
`_should_run_step` (§7). Gate/commit/PR/persist/merge steps are **NOT** in this set — they
always run (they run unconditionally outside `_should_run_step` in `_execute_architecture`).

---

## 3. MODULE HELPER FUNCTIONS (payload encode/decode — `architecture.py:148-190`)

These are **pure module functions**, NOT methods. They keep `json.dumps`/`json.loads` out of
`@workflow.run`-scoped code. (`json` itself is imported under
`with workflow.unsafe.imports_passed_through():`, `architecture.py:71-72`.)

### 3.1 `_encode_target_provisioned_payload(payload: TargetProvisionedSignal) -> str` (`148-172`)

Serializes a `TargetProvisionedSignal` to JSON for the registry publish activity. **Used only by
the sibling `_fire_target_provisioned_signal`** (>1264), reproduced here because it is in my
scope.
```text
return json.dumps({
    "target_app_id":            payload.target_app_id,
    "portfolio_id":             payload.portfolio_id,
    "architecture_workflow_id": payload.architecture_workflow_id,
    "wave_id":                  payload.wave_id,
    "disposition":              payload.disposition,
    "target_repo_url":          payload.target_repo_url,
    # W19 wave-scoped fields (2026-05-20) — defensive getattr + "" / [] fallback:
    "target_service_id": getattr(payload, "target_service_id", "") or "",   # arch.py:168
    "relationship":      getattr(payload, "relationship", "") or "",        # arch.py:169
    "source_app_ids":    list(getattr(payload, "source_app_ids", []) or []),# arch.py:170
})
```
> ⚠️ **GOTCHA-ENC1 (defensive `getattr(...) or default` on the three W19 fields):** the last three
> keys use `getattr(payload, name, default) or default` so a `TargetProvisionedSignal` produced by
> a pre-2026-05-20 publisher (no such attrs, or `None`) serializes as `""`/`[]` not `AttributeError`/
> `null`. `source_app_ids` is wrapped in `list(...)` to force a JSON array. A rebuild must keep all
> three defensive reads and the `list()` wrap.

### 3.2 `_decode_data_ready_payload(payload_json: str) -> dict` (`175-190`)

Parses a `DataReadyForTargetSignal` payload string from the registry. **Used by the sibling
`_wait_for_data_ready`** (>1264). Branch-exhaustive:
```text
def _decode_data_ready_payload(payload_json):
    if not payload_json:                 # arch.py:182  BRANCH 1 — empty/None → {}
        return {}
    try:
        parsed = json.loads(payload_json)    # arch.py:185
    except (ValueError, TypeError):          # arch.py:186  BRANCH 2 — malformed → {}
        return {}
    if not isinstance(parsed, dict):     # arch.py:188  BRANCH 3 — non-dict JSON (list/scalar) → {}
        return {}
    return parsed                        # arch.py:190
```
> ⚠️ **GOTCHA-DEC1 (three independent fallbacks all return `{}`):** empty string, JSON parse
> error, and non-dict-but-valid JSON (`"[]"`, `"5"`) each return `{}`. The caller treats `{}` as
> "no refs hydrated". A rebuild must reproduce all three branches; catching only `ValueError`
> would let a `TypeError` (e.g. `json.loads(123)`) escape — the `except (ValueError, TypeError)`
> tuple is load-bearing.

---

## 4. STATE — every instance var (`__init__`, `architecture.py:397-431`)

`__init__` calls `super().__init__()` **first** (`architecture.py:398`) → this runs
`LineWorkflowBase.__init__` (which runs `HILSignalsMixin.__init__` first), initializing **all 8
HIL vars** (`approved`, `plan_approved`, … `cancelled`; see `_HILSignalsMixin.md`) and **all 19
base line vars** (`_app_id`, `_portfolio_id`, `_wave_id`, `_status=PENDING`, `_current_step`,
`_progress_pct=0.0`, `_pending_gate`, `_started_at`, `_updated_at`, `_gate_decisions`,
`_gate_decisions_consumed`, `_rework_feedback`, `_rework_iterations`, `_step_results`,
`_step_committed_paths`, `_agent_metadata`, `_risk_tier`, `_merge_retry_signalled`; see
`_LineWorkflowBase.md` §2). THEN the 7 architecture-specific vars below:

| Var | Type | Initial | Line | Mutated by → value | When |
|-----|------|---------|------|---------------------|------|
| `_stakeholder_ea_approved` | `bool` | `False` | 402 | `stakeholder_approved(scope="g-02-ea")` → `True` (449); reset → `False` in gate-reject branch of `_execute_architecture` (1219) | Tier-1 EA sign-off; reset each rework |
| `_stakeholder_security_approved` | `bool` | `False` | 403 | `stakeholder_approved(scope="g-02-security")` → `True` (450); reset → `False` (1220) | Tier-1 security sign-off; reset each rework |
| `_disposition` | `str` | `""` | 411 | `run()` sets from `input.disposition` (526-528) | run entry; read by `_dispatch_agent` step-10 router (sibling 1950) |
| `_data_ready` | `bool` | `False` | 414 | `data_ready_for_target` → `True` (495); sibling `_wait_for_data_ready` → `True` on registry hit | Data handshake |
| `_data_architecture_ref` | `str` | `""` | 415 | `data_ready_for_target` → `signal.data_architecture_ref` (496); sibling hydrates from registry payload | Data handshake; read by `_build_evidence_data` + `_create_gate_pr_architecture` |
| `_data_migration_plan_ref` | `str` | `""` | 416 | `data_ready_for_target` → `signal.data_migration_plan_ref` (497); sibling hydrates | Data handshake |
| `_target_repo_url` | `str` | `""` | 421 | sibling `_provision_target_repo_for_this_run` → provisioned URL (or `input.target_repo_url`); read in `_execute_architecture` persist call (1176) and `_run_agent_step` mirror | run entry (before step 1) |
| `_artifact_repo` | `str` | `""` | 426 | `run()` sets `= input.artifact_repo` (547) | run entry; retained for cross-line reads |
| `_target_service_id` | `str` | `""` | 431 | `run()` sets from `input.target_service_id` (533-535) | run entry; gates `_is_system_umbrella` (578) |

> ⚠️ **GOTCHA-DISP-STR (`_disposition` is a STRING, not the enum):** stored as the enum's `.value`
> (or `str()`), deliberately — the comment (`architecture.py:407-411`) notes Temporal serializes
> `self` state across waits and a plain string is safer than holding the `Disposition` enum. A
> rebuild MUST store the normalized string, not the enum member.

---

## 5. SIGNAL HANDLERS — the two NEW signals this subclass adds

> ⚠️ **GOTCHA-SIG-INHERIT (the four base gate signals are NOT redefined here):** `gate_approved`,
> `gate_rejected`, `escalation_resolved`, `merge_retry` are inherited from `LineWorkflowBase`
> (base GOTCHA-SIG0). This subclass adds ONLY `stakeholder_approved` and `data_ready_for_target`.
> A rebuild must NOT re-decorate the base four (duplicate-registration crash).

### 5.1 `stakeholder_approved(self, signal: StakeholderApprovedSignal) -> None` — `@workflow.signal` (`437-456`)

Payload `StakeholderApprovedSignal` (`types.py:165-170`): fields `approval_id: str`,
`stakeholder: str`, `scope: str`. **`async def`.** Routes Tier-1 stakeholder approvals by scope.
```text
async def stakeholder_approved(self, signal):
    if signal.scope == "g-02-ea":                       # arch.py:447  BRANCH A
        self._stakeholder_ea_approved = True            # arch.py:448
    elif signal.scope == "g-02-security":               # arch.py:449  BRANCH B
        self._stakeholder_security_approved = True      # arch.py:450
    else:                                               # arch.py:451  BRANCH C — unknown scope
        workflow.logger.warning(                        # arch.py:452-455
            "stakeholder_approved with unrecognized scope",
            extra={"scope": signal.scope})
    self._updated_at = _now_iso()                       # arch.py:456  (always, all branches)
```
- **Buffers:** flips `_stakeholder_ea_approved` / `_stakeholder_security_approved` flags consumed
  by the Tier-1 `wait_condition` in `_execute_architecture` (1120-1128). It does NOT enqueue onto
  any list — it sets boolean flags.
- ⚠️ **GOTCHA-STK1 (unknown scope is logged + dropped, NOT raised):** branch C only logs a
  warning; it does not error and does not flip any flag (`architecture.py:451-455`). A rebuild must
  swallow unknown scopes — a stakeholder firing `scope="g-02-foo"` must not crash the workflow nor
  satisfy either flag.
- ⚠️ **GOTCHA-STK2 (`_updated_at` bumped on EVERY branch):** line 456 is outside the if/elif/else,
  so even an unknown scope refreshes `_updated_at` (dashboard sees activity). A rebuild keeps the
  timestamp update unconditional.
- ⚠️ **GOTCHA-STK3 (early-arriving signals are preserved across the gate):** these flags can be
  set BEFORE the gate PR exists (a stakeholder can sign off early). The reset to `False` lives in
  the **gate-reject** branch (1219-1220), NOT at the top of the gate loop — so an early sign-off
  before G-02 PR creation is preserved into the first decision wait (see GOTCHA-RESET in §9). A
  rebuild must NOT reset these flags before the first gate wait.

### 5.2 `data_ready_for_target(self, signal: DataReadyForTargetSignal) -> None` — `@workflow.signal` (`458-498`)

Payload `DataReadyForTargetSignal` (`types.py:191-204`): fields `target_app_id: str`,
`data_architecture_ref: str`, `data_migration_plan_ref: str`, `approved_at: str`. **`async def`.**
Receives the Data-line handshake.
```text
async def data_ready_for_target(self, signal):
    # arch.py:483 — wait until run() has assigned self._app_id before comparing.
    await workflow.wait_condition(lambda: bool(self._app_id))         # arch.py:483  ★WAIT
    if signal.target_app_id != self._app_id:                         # arch.py:484  BRANCH A
        workflow.logger.info(                                        # arch.py:487-493
            "data_ready_for_target ignored — wrong target",
            extra={"signal_target_app_id": signal.target_app_id,
                   "self_app_id": self._app_id})
        return                                                       # arch.py:494  ← drop, no mutation
    self._data_ready = True                                          # arch.py:495
    self._data_architecture_ref = signal.data_architecture_ref       # arch.py:496
    self._data_migration_plan_ref = signal.data_migration_plan_ref   # arch.py:497
    self._updated_at = _now_iso()                                    # arch.py:498
```
- **Mutates:** sets `_data_ready=True` and caches the two refs. Consumed by the sibling
  `_wait_for_data_ready`'s `wait_condition(lambda: self._data_ready or self.cancelled)`.
- ⚠️ **GOTCHA-DRT1 (the `await wait_condition(bool(self._app_id))` is THE FIX for a Wave-1 silent
  drop):** `architecture.py:480-483` — if a `data_ready_for_target` signal arrives **before** `run()`
  has assigned `self._app_id` (still `""` from `__init__`), the naive `signal.target_app_id !=
  self._app_id` comparison would be `target != ""` → always True → the signal would be silently
  dropped. The handler first **awaits** until `self._app_id` is non-empty, so the comparison runs
  against the real app id. ⚠️ A signal handler that `await`s a `wait_condition` is legal in
  Temporal — the handler suspends until the predicate holds. A rebuild MUST keep this await as the
  first statement; removing it reintroduces the Wave-1 race.
- ⚠️ **GOTCHA-DRT2 (wrong-target signals are dropped, not buffered):** branch A returns without
  mutating anything (`architecture.py:494`). In a multi-target wave, sibling Architecture workflows
  share the same signal name; each filters on `target_app_id == self._app_id`. A rebuild must drop
  (return early) on mismatch — do NOT record refs for another target.
- ⚠️ **GOTCHA-DRT3 (this handler is the LEGACY path; the registry is the source of truth):** the
  docstring (`architecture.py:462-479`) documents that under `arch-data-registry-v1` the sibling
  `_wait_for_data_ready` polls the registry and this in-memory handler is retained ONLY so pre-patch
  in-flight histories replay deterministically (they flipped `_data_ready` here). A stray signal
  under the new patch is an advisory write — the wait loop trusts the registry. A rebuild MUST keep
  this handler live (for replay equality) even though new runs primarily use the registry path.

---

## 6. `run(self, input: LineWorkflowInput) -> str` — `@workflow.run` (`504-572`) ★ ENTRY POINT

The Temporal entry point. Sets up state, provisions the target repo, then delegates the 16-step
shape to `_execute_architecture`, wrapping it in a try/except that fails cleanly. Returns the
terminal string (`"completed"` / `"cancelled"` / `"failed"`).

```text
@workflow.run
async def run(self, input):
    self._status = WorkflowStatus.RUNNING            # arch.py:507
    self._started_at = _now_iso()                    # arch.py:508
    self._updated_at = self._started_at              # arch.py:509

    target_app_id = input.app_id                     # arch.py:516  ← app_id IS the target app
    self._app_id = target_app_id                     # arch.py:517
    self._portfolio_id = input.portfolio_id          # arch.py:518
    self._wave_id = input.wave_id                    # arch.py:519
    self._risk_tier = getattr(input, "risk_tier", None)   # arch.py:520

    disp = getattr(input, "disposition", None)       # arch.py:526
    if disp is not None:                             # arch.py:527  BRANCH 1
        self._disposition = getattr(disp, "value", str(disp))   # arch.py:528  enum→str (or str())
    # (else: _disposition stays "" — router returns base skill)

    self._target_service_id = (                      # arch.py:533-535
        getattr(input, "target_service_id", "") or ""
    )

    self._artifact_repo = input.artifact_repo        # arch.py:547
    await self._provision_target_repo_for_this_run(input, target_app_id)   # arch.py:548-550  ← SETS _target_repo_url
    repo = input.artifact_repo                       # arch.py:551  ★ commit target is artifact_repo
    wf_id = workflow.info().workflow_id              # arch.py:552
    run_suffix = wf_id.rsplit("-", 1)[-1] if "-" in wf_id else wf_id[:8]   # arch.py:553  BRANCH 2
    branch = f"olympus/architecture/{target_app_id}/{run_suffix}"          # arch.py:554
    workspace_key = f"architecture-{target_app_id}-{run_suffix}"           # arch.py:555

    try:
        return await self._execute_architecture(     # arch.py:558-560
            input, target_app_id, repo, branch, workspace_key)
    except Exception:                                # arch.py:561  BRANCH 3 — terminal failure path
        self._status = WorkflowStatus.FAILED         # arch.py:562
        self._current_step = "failed"                # arch.py:563
        self._updated_at = _now_iso()                # arch.py:564
        try:
            await self._update_app_status(           # arch.py:566-569
                target_app_id, "architecture_failed", "failed", "Architecture")
        except Exception:                            # arch.py:570  BRANCH 4 — best-effort
            pass                                     # arch.py:571
        raise                                        # arch.py:572  ← re-raise original
```

**Branch inventory (4):**
1. `if disp is not None:` (527) — normalize disposition to string only when present; legacy
   `disposition=None` leaves `_disposition=""`.
2. `run_suffix = … if "-" in wf_id else wf_id[:8]` (553) — derive a stable suffix from the
   workflow id: last hyphen-segment if hyphenated, else first 8 chars.
3. `except Exception:` (561) — any failure escaping `_execute_architecture` → set FAILED + failed
   step, attempt a best-effort DB status push, **re-raise** (the workflow surfaces as failed to
   Temporal).
4. inner `except Exception: pass` (570) — the DB status push itself is best-effort; a failure
   there is swallowed so the original exception still propagates.

> ⚠️ **GOTCHA-RUN1 (`repo` = artifact_repo, NOT target_repo):** `repo = input.artifact_repo`
> (`architecture.py:551`) is the **commit target for every step's summary JSON**. The per-target
> modernization repo (`self._target_repo_url`) is only a *mirror* destination for `write_to_target`
> steps. The comment block (537-546) is explicit: step JSONs always land in `artifact_repo` so the
> portfolio stays internally consistent. A rebuild must pass `artifact_repo` as `repo` to
> `_execute_architecture`, not the target repo url.
> ⚠️ **GOTCHA-RUN2 (target-repo provisioning happens in `run`, BEFORE step 1):** the
> `await self._provision_target_repo_for_this_run(...)` (548) runs before `_execute_architecture`,
> so `self._target_repo_url` is populated (or empty on best-effort failure) before any
> `write_to_target` mirror. A rebuild MUST provision before the step loop, not inside it.
> ⚠️ **GOTCHA-RUN3 (branch/workspace_key derive from `run_suffix`, deterministic):** `branch`
> (`olympus/architecture/{target}/{suffix}`) and `workspace_key` (`architecture-{target}-{suffix}`)
> are derived from the deterministic `workflow.info().workflow_id` — same id → same branch on
> replay. A rebuild must reproduce both templates exactly (they appear in git history and
> agent-workspace keys).
> ⚠️ **GOTCHA-RUN4 (`run()` sets `_status=RUNNING` up front but the catch sets `FAILED`; terminal
> `COMPLETED`/`CANCELLED`/`FAILED` are set inside `_execute_architecture`):** the success return
> path sets `COMPLETED` deep in `_execute_architecture` (1206); `run()` only force-sets `FAILED` on
> an escaping exception. A `"cancelled"`/`"failed"` returned *normally* by `_execute_architecture`
> does NOT hit the `except` — it returns through the `try` cleanly. A rebuild must not assume the
> `except` is the only terminal-status setter.

---

## 7. `_is_system_umbrella(self) -> bool` (`574-578`)

```text
def _is_system_umbrella(self):
    return self._target_service_id == "system"       # arch.py:578
```
Pure predicate. True iff this workflow solves the cross-cutting `system` umbrella target. No
branches beyond the equality. Consumed by `_should_run_step`.

---

## 8. `_should_run_step(self, step_name: str) -> bool` (`580-593`)

Per-step gate for the system-umbrella abridged shape.
```text
def _should_run_step(self, step_name):
    if self._is_system_umbrella():                              # arch.py:591  BRANCH A
        return step_name in SYSTEM_UMBRELLA_ARCHITECTURE_STEPS  # arch.py:592
    return True                                                 # arch.py:593  (per-service / legacy)
```
- **Branch A** (umbrella): returns True ONLY for the 6 steps in
  `SYSTEM_UMBRELLA_ARCHITECTURE_STEPS` (§2.3); all other agent steps return False (skipped).
- **else**: per-service targets (S1..S11) and legacy waves (empty `target_service_id`) always
  return True.

> ⚠️ **GOTCHA-SRS1 (gate/commit/PR/persist/merge steps bypass this predicate):** `_should_run_step`
> is only consulted for the *agent* steps in `_execute_architecture`. The commit-blueprint /
> create-g-02-pr / gate-review-02 / persist / merge steps are run **unconditionally** (they are not
> guarded by `_should_run_step`). The umbrella set deliberately excludes them (`architecture.py:359-360`)
> because they always run. A rebuild must NOT guard the gate/commit/persist/merge sequence with this
> predicate — only the agent dispatch steps.
> ⚠️ **GOTCHA-SRS2 (`data-architecture` IS guarded — umbrella skips the Data wait):**
> `architecture.py:901` guards the data-architecture signal wait with `_should_run_step`. Since
> `data-architecture` is NOT in the umbrella set, the umbrella **skips the Data-ready wait
> entirely** (the comment at 896-900 explains Data fires `DataReadyForTarget` with empty refs
> synchronously for the umbrella, so skipping avoids a 30-min timeout). A rebuild must gate the Data
> wait with `_should_run_step("data-architecture")`.

---

## 9. `_execute_architecture(self, input, target_app_id, repo, branch, workspace_key) -> str` (`748-1258`) ★★ CORE ORCHESTRATION

The 16-step canonical shape with a `while True` gate-rework loop. **This is the highest-value
section.** Returns `"completed"` / `"cancelled"` / `"failed"`.

### 9.0 Local state at entry (`757-758`)
```text
running_progress = 0.0                          # arch.py:757  running progress accumulator
prior_inputs = list(input.prior_artifacts)      # arch.py:758  COPY of prior_artifacts (mutated below)
```
`prior_inputs` is the input-artifact list threaded into each step; it is **re-snapshotted** after
most steps via `self._collect_committed_paths()` (sibling).

### 9.1 Source-artifacts-index merge — patch-gated (`767-776`)
```text
if workflow.patched("architecture-source-index-v1"):            # arch.py:767  BRANCH 1 (patch)
    indexed_paths = await self._read_target_source_artifacts_index(input, target_app_id)  # arch.py:768  (→ §11)
    if indexed_paths:                                           # arch.py:771  BRANCH 2
        seen = set(prior_inputs)                                # arch.py:772
        for p in indexed_paths:                                # arch.py:773  LOOP
            if p not in seen:                                  # arch.py:774  BRANCH 3 (dedup)
                prior_inputs.append(p)                         # arch.py:775
                seen.add(p)                                    # arch.py:776
```
Appends each not-already-present indexed path to `prior_inputs`, preserving order and dedupe.

> ⚠️ **GOTCHA-EXEC-PATCH1 (`architecture-source-index-v1` verbatim):** `architecture.py:767`. Exact
> patch string. Pre-patch in-flight runs take the `else`-equivalent (skip) and keep using
> `input.prior_artifacts` only. A rebuild MUST use this exact string and only run the index merge
> under the patch.

### 9.2 Track-A capability-extraction grain — patch-gated (`788-789`)
```text
if workflow.patched("architecture-realize-grain-v1"):          # arch.py:788  BRANCH 4 (patch)
    await self._realize_consolidation_grain_if_present(input)  # arch.py:789  (→ §12)
```
> ⚠️ **GOTCHA-EXEC-PATCH2 (`architecture-realize-grain-v1` verbatim):** `architecture.py:788`.
> Pre-2026-05-17 histories skip this. A rebuild reproduces the exact string + patch gate.

### 9.3 Step 1 — Target-State Mapping (always first, no `_should_run_step` guard) (`814-829`)
```text
await self._set_step("target-state-mapping", running_progress)                 # arch.py:814
await self._derive_target_state_mapping_from_plan(input, target_app_id, repo, branch)  # arch.py:815-817 (→ sibling)
running_progress += STEP_WEIGHTS["target-state-mapping"]                        # arch.py:818  (+6.0)
prior_inputs = self._collect_committed_paths()                                 # arch.py:819  ← re-snapshot
await self._fire_target_provisioned_signal(input, target_app_id)               # arch.py:827-829 (→ sibling)
```
- `_derive_target_state_mapping_from_plan` (sibling, 1264-1411) is **strict-fail**: it reads
  `architecture/wave-{wave_id}/architecture-target-plan.json` from `artifact_repo`@`main` and
  raises **non-retryable `ApplicationError`** if (a) `wave_id`/`artifact_repo` missing, (b) plan
  not found, (c) plan malformed JSON, or (d) `target_app_id` not in the plan's `targets[]`. On
  success it synthesizes an `AgentTaskResult` and commits `target-application-map.json` via
  `_commit_step_artifacts`, recording `_agent_metadata["target-state-mapping"]` (model
  `"derived-from-plan"`) and `_step_results["target-state-mapping"]`. **No agent dispatch.**
- `_fire_target_provisioned_signal` (sibling, 1764-1913) publishes `TargetProvisionedSignal` to the
  arch-data registry (patch `arch-data-registry-v1`) + best-effort fast-path Temporal signal to the
  peer Data workflow (patch `arch-data-signal-first-v1`); best-effort, never fatal.

> ⚠️ **GOTCHA-EXEC-STEP1 (step 1 is NEVER guarded by `_should_run_step`):** `target-state-mapping`
> IS in the umbrella set, but the call site (814-817) does not wrap it in `_should_run_step` — it
> always runs (the umbrella also needs target identity). A rebuild must always run step 1.

### 9.4 Steps 2 + 3 — Cloud Pattern Selection ‖ EA Compliance — patch-gated parallel/sequential (`839-877`)
```text
if workflow.patched("arch-parallel-fanout-v1"):                # arch.py:839  BRANCH 5 (patch — NEW parallel shape)
    parallel_inputs = prior_inputs                             # arch.py:840  ★ snapshot BEFORE gather
    tasks = []
    if self._should_run_step("cloud-pattern-selection"):       # arch.py:842  BRANCH 6
        await self._set_step("cloud-pattern-selection", running_progress)   # arch.py:843-845
        tasks.append(self._run_agent_step_task(                # arch.py:846-850
            "cloud-pattern-selection", target_app_id, parallel_inputs,
            input.source_repo, workspace_key, repo, branch))
        running_progress += STEP_WEIGHTS["cloud-pattern-selection"]   # arch.py:851  (+10.0)
    if self._should_run_step("ea-compliance"):                 # arch.py:852  BRANCH 7
        tasks.append(self._run_agent_step_task(                # arch.py:853-856
            "ea-compliance", target_app_id, parallel_inputs,
            input.source_repo, workspace_key, repo, branch))
        running_progress += STEP_WEIGHTS["ea-compliance"]      # arch.py:857  (+8.0)
    if tasks:                                                  # arch.py:858  BRANCH 8
        await asyncio.gather(*tasks)                           # arch.py:859  ★ PARALLEL
        prior_inputs = self._collect_committed_paths()         # arch.py:860  re-snapshot AFTER gather
else:                                                          # arch.py:861  LEGACY sequential shape
    if self._should_run_step("cloud-pattern-selection"):       # arch.py:863  BRANCH 9
        await self._run_agent_step("cloud-pattern-selection", target_app_id, prior_inputs,
            input.source_repo, workspace_key, repo, branch)    # arch.py:864-867
        running_progress += STEP_WEIGHTS["cloud-pattern-selection"]   # arch.py:868
        prior_inputs = self._collect_committed_paths()         # arch.py:869
    if self._should_run_step("ea-compliance"):                 # arch.py:871  BRANCH 10
        await self._run_agent_step("ea-compliance", target_app_id, prior_inputs,
            input.source_repo, workspace_key, repo, branch)    # arch.py:872-875
        running_progress += STEP_WEIGHTS["ea-compliance"]      # arch.py:876
        prior_inputs = self._collect_committed_paths()         # arch.py:877
```
> ⚠️ **GOTCHA-EXEC-FANOUT (input-artifact snapshot BEFORE gather — siblings can't see each other's
> commits):** in the parallel branch, `parallel_inputs = prior_inputs` is captured **before** the
> two tasks are created (`architecture.py:840`), and `prior_inputs` is only re-collected **after**
> `asyncio.gather` (860). So `cloud-pattern-selection` and `ea-compliance` both dispatch with the
> identical input set (the step-1 commits), and neither observes the other's output. The module
> docstring (40-42) calls this out: "Input-artifact chaining is preserved — each fan-out's inputs
> are snapshotted *before* the gather call." A rebuild MUST snapshot before, gather, then re-collect.
> ⚠️ **GOTCHA-EXEC-PATCH3 (`arch-parallel-fanout-v1` gates BOTH the 2+3 fan-out AND the 6-9
> fan-out):** the same patch string (839 and 923) controls both parallel groups. Pre-patch
> histories take the sequential `else` branches in *both* places. A rebuild must use the SAME exact
> string at both sites or replay diverges.
> ⚠️ **GOTCHA-EXEC-PROGRESS-PARALLEL (`_set_step` called only for the FIRST task in a fan-out
> group):** in the parallel branch, `_set_step("cloud-pattern-selection", …)` is called (843) but
> NOT `_set_step("ea-compliance", …)` — only the first step's `_set_step` runs; the second step's
> progress is folded by `running_progress +=` without a `_set_step` call. The `_set_step` inside
> `_run_agent_step` (sibling) covers each step's own status push when run. A rebuild must reproduce
> exactly which `_set_step` calls happen at the orchestration level vs. inside the helper.

### 9.5 Step 4 — Integration Arch (agent, sequential await) (`883-894`)
```text
if self._should_run_step("integration-arch"):                  # arch.py:883  BRANCH 11
    await self._set_step("integration-arch", running_progress) # arch.py:884
    integration_task = self._run_agent_step_task(              # arch.py:885-888
        "integration-arch", target_app_id, prior_inputs,
        input.source_repo, workspace_key, repo, branch)
    await integration_task                                     # arch.py:892  ← awaited immediately
    running_progress += STEP_WEIGHTS["integration-arch"]       # arch.py:893  (+10.0)
    prior_inputs = self._collect_committed_paths()             # arch.py:894
```
> ⚠️ **GOTCHA-EXEC-INTEG (integration-arch creates a task then immediately awaits it):** despite the
> comment about "running in parallel", the code creates `integration_task` then `await
> integration_task` on the very next executable line (885 → 892) — there is **no concurrent Data
> wait gathered with it**. The data-architecture wait is a *separate* `if` block (901) that runs
> after. So integration-arch effectively runs sequentially before the Data wait. A rebuild should
> reproduce this exact shape (create task, await it) — the "parallel" comment is aspirational; the
> code is sequential here.

### 9.6 Step 5 — Data Architecture Handshake (kind=code, signal wait) (`901-912`)
```text
if self._should_run_step("data-architecture"):                 # arch.py:901  BRANCH 12
    await self._set_step("data-architecture", running_progress)# arch.py:902
    await self._wait_for_data_ready()                          # arch.py:903  ← BLOCKS on signal/registry (→ sibling)
    if self._data_architecture_ref:                            # arch.py:906  BRANCH 13
        self._step_committed_paths["data-architecture"] = [    # arch.py:907-910
            self._data_architecture_ref,
            self._data_migration_plan_ref]
    running_progress += STEP_WEIGHTS["data-architecture"]      # arch.py:911  (+6.0)
    prior_inputs = self._collect_committed_paths()             # arch.py:912
```
- `_wait_for_data_ready` (sibling, 1478-1623) blocks (signal-first w/ DB backstop under
  `arch-data-signal-first-v1`; 15s registry poll under `arch-data-registry-v1`; in-memory
  `wait_condition` legacy). On `self.cancelled` it raises `RuntimeError`; on the 24h cap it raises
  `RuntimeError`. Both propagate up → caught by `run()`'s `except` → workflow FAILED.

> ⚠️ **GOTCHA-EXEC-DATAREFS (Data refs recorded as committed paths only if `_data_architecture_ref`
> truthy):** `architecture.py:906` — for the umbrella (which skips this block) or a Retain target
> with empty refs, `_step_committed_paths["data-architecture"]` is left unset. When set, BOTH refs
> are recorded (arch ref + migration plan ref), so downstream `_collect_committed_paths` includes
> them in `prior_inputs`. A rebuild must conditionally record both refs only when the arch ref is
> non-empty.

### 9.7 Steps 6-9 — Security / Design / Accessibility / AI-ML — patch-gated parallel/sequential (`923-991`)
```text
if workflow.patched("arch-parallel-fanout-v1"):                # arch.py:923  BRANCH 14 (same patch as §9.4)
    parallel_inputs = prior_inputs                             # arch.py:924  ★ snapshot BEFORE gather
    tasks = []
    if self._should_run_step("security-arch"):                 # arch.py:926  BRANCH 15
        await self._set_step("security-arch", running_progress)# arch.py:927
        tasks.append(self._run_agent_step_task("security-arch", …, parallel_inputs, …))  # arch.py:928-931
        running_progress += STEP_WEIGHTS["security-arch"]      # arch.py:932  (+10.0)
    if self._should_run_step("design-system"):                 # arch.py:933  BRANCH 16
        tasks.append(self._run_agent_step_task("design-system", …, parallel_inputs, …))  # arch.py:934-937
        running_progress += STEP_WEIGHTS["design-system"]      # arch.py:938  (+8.0)
    if self._should_run_step("accessibility-review"):          # arch.py:939  BRANCH 17
        tasks.append(self._run_agent_step_task("accessibility-review", …, parallel_inputs, …))  # arch.py:940-943
        running_progress += STEP_WEIGHTS["accessibility-review"]   # arch.py:944  (+6.0)
    if self._should_run_step("ai-ml-integration"):             # arch.py:945  BRANCH 18
        tasks.append(self._run_agent_step_task("ai-ml-integration", …, parallel_inputs, …))  # arch.py:946-949
        running_progress += STEP_WEIGHTS["ai-ml-integration"]  # arch.py:950  (+4.0)
    if tasks:                                                  # arch.py:951  BRANCH 19
        await asyncio.gather(*tasks)                           # arch.py:952  ★ PARALLEL (up to 4)
        prior_inputs = self._collect_committed_paths()         # arch.py:953
else:                                                          # arch.py:954  LEGACY shape
    if self._should_run_step("security-arch"):                 # arch.py:957  BRANCH 20
        await self._run_agent_step("security-arch", …, prior_inputs, …)   # arch.py:958-961  SEQUENTIAL
        running_progress += STEP_WEIGHTS["security-arch"]      # arch.py:962
        prior_inputs = self._collect_committed_paths()         # arch.py:963
    ds_ar_tasks = []
    if self._should_run_step("design-system"):                 # arch.py:967  BRANCH 21
        await self._set_step("design-system", running_progress)# arch.py:968
        ds_ar_tasks.append(self._run_agent_step_task("design-system", …, prior_inputs, …))  # arch.py:969-972
        running_progress += STEP_WEIGHTS["design-system"]      # arch.py:973
    if self._should_run_step("accessibility-review"):          # arch.py:974  BRANCH 22
        ds_ar_tasks.append(self._run_agent_step_task("accessibility-review", …, prior_inputs, …))  # arch.py:975-978
        running_progress += STEP_WEIGHTS["accessibility-review"]   # arch.py:979
    if ds_ar_tasks:                                            # arch.py:980  BRANCH 23
        await asyncio.gather(*ds_ar_tasks)                     # arch.py:981  ★ design ‖ accessibility
        prior_inputs = self._collect_committed_paths()         # arch.py:982
    if self._should_run_step("ai-ml-integration"):             # arch.py:985  BRANCH 24
        await self._run_agent_step("ai-ml-integration", …, prior_inputs, …)   # arch.py:986-989  SEQUENTIAL
        running_progress += STEP_WEIGHTS["ai-ml-integration"]  # arch.py:990
        prior_inputs = self._collect_committed_paths()         # arch.py:991
```
> ⚠️ **GOTCHA-EXEC-LEGACY69 (the legacy 6-9 shape is security→[design‖accessibility]→ai-ml, NOT all
> four parallel):** the legacy branch (954-991) runs security-arch **sequentially first**, then
> design+accessibility **in parallel** (980-981), then ai-ml-integration **sequentially last**. The
> new branch runs all four (that pass `_should_run_step`) in ONE gather. A rebuild must reproduce
> BOTH shapes under the patch gate — pre-patch histories replay the staged legacy shape.
> ⚠️ **GOTCHA-EXEC-VARREUSE (`tasks` / `parallel_inputs` reused across §9.4 and §9.7):** in the new
> branch, `tasks = []` and `parallel_inputs = prior_inputs` are reassigned at 924-925 (same local
> names as 840-841). This is benign because §9.4's gather already drained `tasks`. A rebuild may
> reuse or re-declare these names; behavior is identical because both groups gather-and-drain.

### 9.8 ★ THE GATE-REWORK LOOP — `while True:` (`994-1258`)

Everything from blueprint-assembly through merge runs inside one `while True` loop; rejection
re-runs the agent steps and loops back to the top. **This is the rework engine.**

#### 9.8.a Step 10 — Blueprint Assembly (synthesis, sequential, always runs — NO `_should_run_step`) (`996-1003`)
```text
while True:                                                    # arch.py:994  ★LOOP TOP
    await self._run_agent_step("blueprint-assembly", target_app_id, prior_inputs,
        input.source_repo, workspace_key, repo, branch)        # arch.py:996-998
    blueprint_progress = running_progress + STEP_WEIGHTS["blueprint-assembly"]   # arch.py:1000-1002  (+8.0)
    prior_inputs = self._collect_committed_paths()             # arch.py:1003
```
> ⚠️ **GOTCHA-EXEC-BLUEPRINT-NOGUARD (blueprint-assembly is NOT `_should_run_step`-guarded but the
> umbrella DOES include it):** `blueprint-assembly` is in `SYSTEM_UMBRELLA_ARCHITECTURE_STEPS`, and
> its call site (996) has no guard — it always runs (for both umbrella and per-service). The
> step-10 disposition router lives in the sibling `_dispatch_agent` override (1949-1951): for
> Retire/Retain the router returns `None` but `_dispatch_agent` falls back to the declared
> `blueprint-assembly` skill_id (safety net). A rebuild must always run blueprint-assembly here; the
> Retire/Retain "skip the step" rule is a *caller-level* concern not enforced in this loop.
> ⚠️ **GOTCHA-EXEC-BPPROGRESS (`blueprint_progress` is a NEW local each loop iteration):** it is
> recomputed from `running_progress` at the top of every loop (1000). On rework, `running_progress`
> was reset to `target-state-mapping + data-architecture` weight (12.0; see §9.8.f) so the progress
> bar restarts from that floor each rework. A rebuild must recompute `blueprint_progress` inside the
> loop, not hoist it.

#### 9.8.b Steps 11/12/13 — Stage 5/9 post-synthesis evidence — patch-gated parallel (`1017-1045`)
```text
if workflow.patched("architecture-stage5-evidence-v1"):        # arch.py:1017  BRANCH 25 (patch)
    evidence_tasks = []
    if self._should_run_step("cloud-cost-estimate"):           # arch.py:1019  BRANCH 26
        evidence_tasks.append(self._run_agent_step_task("cloud-cost-estimate", …, prior_inputs, …))  # arch.py:1020-1023
        blueprint_progress += STEP_WEIGHTS["cloud-cost-estimate"]   # arch.py:1024  (+2.0)
    if self._should_run_step("well-architected-review"):       # arch.py:1025  BRANCH 27
        evidence_tasks.append(self._run_agent_step_task("well-architected-review", …, prior_inputs, …))  # arch.py:1026-1030
        blueprint_progress += STEP_WEIGHTS["well-architected-review"]   # arch.py:1031-1033  (+2.0)
    if self._should_run_step("traceability-validation"):       # arch.py:1034  BRANCH 28
        evidence_tasks.append(self._run_agent_step_task("traceability-validation", …, prior_inputs, …))  # arch.py:1035-1039
        blueprint_progress += STEP_WEIGHTS["traceability-validation"]   # arch.py:1040-1042  (+2.0)
    if evidence_tasks:                                         # arch.py:1043  BRANCH 29
        await asyncio.gather(*evidence_tasks)                  # arch.py:1044  ★ PARALLEL (up to 3)
        prior_inputs = self._collect_committed_paths()         # arch.py:1045
```
> ⚠️ **GOTCHA-EXEC-PATCH4 (`architecture-stage5-evidence-v1` verbatim):** `architecture.py:1017`.
> Pre-change histories never scheduled these three activities → skip branch on replay. Note these
> three steps run **inside** the `while True` loop, so a rework re-runs them too (no `_set_step`
> call at the orchestration level — each is set inside `_run_agent_step`). A rebuild reproduces the
> exact string and keeps these inside the loop.

#### 9.8.c Step 14 marker — Commit Blueprint Artifacts (logical, no commit here) (`1050-1056`)
```text
await self._set_step("commit-blueprint-artifacts", blueprint_progress)   # arch.py:1050-1052
commit_progress = blueprint_progress + STEP_WEIGHTS["commit-blueprint-artifacts"]   # arch.py:1053-1056  (+2.0)
```
> ⚠️ **GOTCHA-EXEC-COMMIT-MARKER (commit-blueprint-artifacts does NO git work):** artifacts were
> already committed per-step by `_commit_step_artifacts` (inside each `_run_agent_step`). This step
> is a **logical stepper marker only** (`architecture.py:1047-1049`). A rebuild must NOT add a
> commit activity here — it only calls `_set_step` and advances progress.

#### 9.8.d Step 12 — Create G-02 PR + gate record + submit evidence (`1058-1089`)
```text
artifact_paths = dedup_paths(self._collect_committed_paths())  # arch.py:1059  ← deduped path list for the gate
await self._set_step("create-g-02-pr", commit_progress)        # arch.py:1060
pr_result = await self._create_gate_pr_architecture(repo, branch, target_app_id, input)  # arch.py:1061-1063 (→ sibling)
pr_progress = commit_progress + STEP_WEIGHTS["create-g-02-pr"] # arch.py:1064  (+2.0)

gate_record = await workflow.execute_activity(                 # arch.py:1066-1077  ACTIVITY: create_gate_record
    create_gate_record,
    CreateGateRecordInput(
        gate_type="G-02",
        app_id=target_app_id,
        portfolio_id=input.portfolio_id,
        workflow_id=workflow.info().workflow_id,
        evidence_package_url=pr_result.pr_url),
    start_to_close_timeout=timedelta(seconds=30),              # arch.py:1075
    retry_policy=RETRY_POLICIES["transient"])                  # arch.py:1076  (3 attempts)
gate_id = gate_record.gate_id                                  # arch.py:1078

await self._submit_gate_evidence(                              # arch.py:1080-1089 (→ base §11)
    gate_id=gate_id, gate_type=GateType.G_02, app_id=target_app_id,
    artifact_paths=artifact_paths, pr_url=pr_result.pr_url,
    assembly_line="Architecture", step="gate-review-02",
    forward_risk_tier=True)
```
- `create_gate_record` — `CreateGateRecordInput(gate_type="G-02", …, evidence_package_url=pr_url)`;
  **30s**; `transient`; **no explicit activity_id** (auto). Returns `gate_record.gate_id`.
- `_submit_gate_evidence` (inherited base, base §11): builds slim bundle (via the OVERRIDDEN
  `_build_evidence_data`, sibling 2034), checks gate criteria (with `forward_risk_tier=True` →
  includes `evidence_data` + `risk_tier`), submits slim evidence. Both inner activities 60s/transient.

> ⚠️ **GOTCHA-EXEC-PRURL (gate record's `evidence_package_url` = the PR url):** `architecture.py:1073`
> threads `pr_result.pr_url` into the gate record. A rebuild must pass the PR url here.
> ⚠️ **GOTCHA-EXEC-FWDRISK (`forward_risk_tier=True` for Architecture):** Architecture always
> forwards risk tier (unlike legacy Data which passes False). This makes G-02 criteria checking
> tier-aware. A rebuild must pass `forward_risk_tier=True`.

#### 9.8.e Step 13 — AI Pre-Review (inherited base helper) (`1092-1102`)
```text
await self._set_step("ai-pre-review", pr_progress)             # arch.py:1092
await self._run_gate_pre_review(gate_id, "G-02", artifact_paths,
    artifact_repo=repo, artifact_ref=branch)                   # arch.py:1093-1099 (→ base §12)
pre_review_progress = pr_progress + STEP_WEIGHTS["ai-pre-review"]   # arch.py:1100-1102  (+4.0)
```
- `_run_gate_pre_review` (inherited): best-effort `gate-pre-review` dispatch (10m/transient),
  `store_gate_pre_review` (30s), and a `finally` `mark_gate_ready_for_review` under patch
  `mark-gate-ready-for-review-v1`. **`artifact_repo=repo, artifact_ref=branch` are threaded** so
  the pre-review agent can fetch the evidence (base GOTCHA-PR1). A rebuild MUST pass both.

#### 9.8.f Step 14 — Gate G-02 decision wait + routing (`1105-1258`)
```text
await self._set_step("gate-review-02", pre_review_progress)    # arch.py:1105
await self._update_app_status(target_app_id, "gate_review", "gate-review-02", "Architecture")  # arch.py:1106-1109

decision = await self._wait_for_gate_decision(GateType.G_02)   # arch.py:1111  ★ BLOCKS (→ base §13)
if decision == "cancelled":                                    # arch.py:1112  BRANCH 30
    return "cancelled"                                         # arch.py:1113  ← exit (NO _status set here!)
if decision == "approved":                                     # arch.py:1114  BRANCH 31
    # ---- Tier-1 triple-signal sub-wait ----
    if self._risk_tier == 1:                                   # arch.py:1119  BRANCH 32
        await workflow.wait_condition(                         # arch.py:1120-1128  ★ DUAL-STAKEHOLDER WAIT
            lambda: (
                (self._stakeholder_ea_approved
                 and self._stakeholder_security_approved)
                or self.cancelled))
        if self.cancelled:                                     # arch.py:1129  BRANCH 33
            self._status = WorkflowStatus.CANCELLED            # arch.py:1130
            return "cancelled"                                 # arch.py:1131
    # ---- Step 15 — Persist side-effects (best-effort) ----
    gate_progress = pre_review_progress + STEP_WEIGHTS["gate-review-02"]   # arch.py:1140-1142  (+6.0)
    await self._set_step("persist-architecture-side-effects", gate_progress)  # arch.py:1143-1145
    blueprint_json = ""                                        # arch.py:1146
    target_map_json = ""                                       # arch.py:1147
    if self._step_results.get("blueprint-assembly"):           # arch.py:1148  BRANCH 34
        blueprint_json = self._step_results["blueprint-assembly"][0]   # arch.py:1149-1151
    if self._step_results.get("target-state-mapping"):         # arch.py:1152  BRANCH 35
        target_map_json = self._step_results["target-state-mapping"][0]   # arch.py:1153-1155
    blueprint_ref = (                                          # arch.py:1156-1159
        f"architecture/{target_app_id}/"
        f"{ARCHITECTURE_STEPS['blueprint-assembly']['artifact']}")   # → architecture-blueprint.json
    try:
        await workflow.execute_activity(                       # arch.py:1161-1181  ACTIVITY: persist_architecture_side_effects
            persist_architecture_side_effects,
            PersistArchitectureSideEffectsInput(
                target_app_id=target_app_id,
                target_name=input.app_name,
                target_portfolio_id=input.portfolio_id,
                target_application_map_json=target_map_json,
                blueprint_json=blueprint_json,
                blueprint_ref=blueprint_ref,
                decided_at=_now_iso(),
                target_repo_url=self._target_repo_url),
            start_to_close_timeout=timedelta(seconds=60),      # arch.py:1178
            retry_policy=RETRY_POLICIES["transient"],          # arch.py:1179
            activity_id="persist-architecture-side-effects")   # arch.py:1180
    except Exception:                                          # arch.py:1182  BRANCH 36 — best-effort
        workflow.logger.exception(                             # arch.py:1183-1186
            "persist_architecture_side_effects failed; application row will keep stale architecture fields")
    persist_progress = gate_progress + STEP_WEIGHTS["persist-architecture-side-effects"]   # arch.py:1187-1190  (+2.0)
    # ---- Step 16 — Merge Blueprint PR (with merge_blocked loop) ----
    await self._set_step("merge-blueprint-pr", persist_progress)   # arch.py:1193
    await self._reconcile_and_merge_with_retry_loop(           # arch.py:1196-1201 (→ base §14)
        repo=repo, pr_number=pr_result.pr_number, gate_id=gate_id, merge_method="merge")
    await self._update_app_status(target_app_id, "architecture_complete", "completed", "Architecture")  # arch.py:1202-1205
    self._status = WorkflowStatus.COMPLETED                    # arch.py:1206
    self._progress_pct = 100.0                                 # arch.py:1207
    self._current_step = "completed"                           # arch.py:1208
    self._updated_at = _now_iso()                              # arch.py:1209
    return "completed"                                         # arch.py:1210  ← SUCCESS EXIT

# ---- decision == "rejected" → rework ----
self._stakeholder_ea_approved = False                          # arch.py:1219  ← reset HERE (not loop top)
self._stakeholder_security_approved = False                    # arch.py:1220
self._bump_rework("G-02")                                      # arch.py:1222  ← counter bumped by SUBCLASS
if self._rework_count("G-02") > MAX_REWORK_ITERATIONS:         # arch.py:1223  BRANCH 37  (> 3)
    self._status = WorkflowStatus.FAILED                       # arch.py:1224
    self._current_step = "max-rework-exceeded"                 # arch.py:1225
    self._updated_at = _now_iso()                              # arch.py:1226
    await self._update_app_status(target_app_id, "architecture_failed",
        "max-rework-exceeded", "Architecture")                 # arch.py:1227-1230
    return "failed"                                            # arch.py:1231  ← FAILURE EXIT

# ---- re-run agent steps for next rework iteration ----
running_progress = (STEP_WEIGHTS["target-state-mapping"]
                    + STEP_WEIGHTS["data-architecture"])       # arch.py:1238-1241  (reset to 12.0)
for step_name in ("cloud-pattern-selection", "ea-compliance", "integration-arch",
                  "security-arch", "design-system", "accessibility-review",
                  "ai-ml-integration"):                        # arch.py:1242-1250  LOOP (7 steps, FIXED ORDER)
    if not self._should_run_step(step_name):                  # arch.py:1251  BRANCH 38
        continue                                              # arch.py:1252
    await self._run_agent_step(step_name, target_app_id, prior_inputs,
        input.source_repo, workspace_key, repo, branch)       # arch.py:1253-1256  SEQUENTIAL
    running_progress += STEP_WEIGHTS[step_name]                # arch.py:1257
    prior_inputs = self._collect_committed_paths()            # arch.py:1258
# ← falls off the for-loop, loops back to `while True` top (blueprint-assembly re-runs)
```

**Gate-routing branch inventory (decision + sub-branches):**
- **30. `decision == "cancelled"`** (1112) → `return "cancelled"` immediately. ⚠️ **GOTCHA-EXEC-CANCEL1:**
  this return does NOT set `self._status = CANCELLED` (only the Tier-1 sub-wait cancel at 1129-1131
  does). `_wait_for_gate_decision` itself already set `_status=CANCELLED` (base 829) before returning
  `"cancelled"`, so the status is correct — but a rebuild must rely on the base having set it, not
  re-set it here.
- **31. `decision == "approved"`** (1114) → Tier-1 sub-wait, persist, merge loop, COMPLETED.
- **32. `if self._risk_tier == 1:`** (1119) → Tier-1 dual-stakeholder `wait_condition`. Tier-2/3
  skip this entirely (EA/security participate in PR review but don't block).
- **33. `if self.cancelled:` (post Tier-1 wait)** (1129) → set `_status=CANCELLED`, `return
  "cancelled"`. This is the ONLY place in this method that sets CANCELLED explicitly.
- **34/35. `if self._step_results.get(...)`** (1148, 1152) → harvest blueprint/target-map JSON `[0]`
  for the persist activity; empty string if the step produced nothing.
- **36. `except Exception:` (persist)** (1182) → best-effort; logs and continues so the gate
  approval still completes. **Persist failure does NOT fail the workflow.**
- **37. `if self._rework_count("G-02") > MAX_REWORK_ITERATIONS:`** (1223) → after the 3rd rejection
  the 4th would exceed (count becomes 4 > 3), so FAILED + `return "failed"`.
- **38. `if not self._should_run_step(step_name): continue`** (1251) → in the rework re-run loop,
  skip umbrella-excluded steps.

> ⚠️ **GOTCHA-EXEC-TIER1 (the Tier-1 triple-signal: PM merge ⟂ G-02 PR approval + EA flag +
> security flag):** `_wait_for_gate_decision` returning `"approved"` corresponds to the **PM's
> gate-PR approval** (the `gate_approved` signal). For Tier-1 (`_risk_tier == 1`), the workflow then
> additionally waits for BOTH `_stakeholder_ea_approved` AND `_stakeholder_security_approved`
> (`architecture.py:1120-1128`) via the `stakeholder_approved` signal (scopes `g-02-ea` /
> `g-02-security`). The predicate is `(ea AND security) OR cancelled`. **Tier-2/3 NEVER enter this
> sub-wait** — `if self._risk_tier == 1` is the only gate (1119). A rebuild MUST: (a) only require
> the dual flags for Tier-1, (b) include `or self.cancelled` in the predicate so cancel drains the
> wait, (c) on cancel set `_status=CANCELLED` and return `"cancelled"`.
> ⚠️ **GOTCHA-RESET (stakeholder flags reset in the REJECT branch, deliberately NOT at loop top):**
> `architecture.py:1219-1220` resets both stakeholder flags, and the comment (1213-1218) is explicit:
> "reset lives here rather than at the top of the loop so early-arriving stakeholder signals before
> G-02 PR creation are preserved." On the FIRST iteration the flags are already `False` (from
> `__init__`), so resetting in the reject branch is equivalent to never resetting on iteration 1 —
> but it clears a *prior* rework cycle's approvals before the next attempt. A rebuild MUST reset in
> the reject branch, NOT at the top of `while True`, or a Tier-1 early sign-off would be wiped before
> the first gate wait.
> ⚠️ **GOTCHA-EXEC-REWORK-COUNTER (the SUBCLASS bumps the counter, not the base):** `_bump_rework("G-02")`
> at 1222 is the ONLY counter increment (base `_wait_for_gate_decision` does NOT touch
> `_rework_iterations` — base GOTCHA-WG5/RW1). The ceiling check uses `_rework_count("G-02") >
> MAX_REWORK_ITERATIONS` (i.e. `> 3`). So: reject#1→count1, reject#2→count2, reject#3→count3 (all
> loop and retry), reject#4→count4 → `4 > 3` → FAILED. **The line tolerates exactly 3 reworks (4
> total gate attempts).** A rebuild must bump in the subclass on `"rejected"` and use strict `>`.
> ⚠️ **GOTCHA-EXEC-REWORK-SCOPE (rework re-runs 7 agent steps in a FIXED order, EXCLUDING
> target-state-mapping & data-architecture):** the rework loop (1242-1250) re-dispatches exactly
> `cloud-pattern-selection, ea-compliance, integration-arch, security-arch, design-system,
> accessibility-review, ai-ml-integration` **sequentially** (no fan-out), then falls back to the
> `while True` top so blueprint-assembly + evidence + gate re-run. `target-state-mapping` and
> `data-architecture` are **NOT** re-run — target identity is fixed and `_data_ready` stays True
> (the comment at 1233-1237 explains re-waiting Data is a no-op). `running_progress` is reset to
> `6.0 + 6.0 = 12.0` (their two weights) so the progress floor reflects the two retained steps. A
> rebuild MUST: (a) re-run exactly those 7 steps in that exact order sequentially on rework, (b) NOT
> re-run target-state-mapping or data-architecture, (c) reset `running_progress` to the sum of those
> two weights, (d) honor `_should_run_step` (umbrella skips the per-service ones).
> ⚠️ **GOTCHA-EXEC-REWORK-FEEDBACK (rework feedback flows via `_rework_feedback["G-02"]`):** on
> reject, base `_wait_for_gate_decision` (base 855-862) stored the structured feedback dict under
> key `"G-02"`. On the re-dispatch, the OVERRIDDEN `_dispatch_agent` (sibling 1936-1939) reads
> `self._rework_feedback.get("G-02")` and attaches it to `context["rework_feedback"]`. blueprint-
> assembly re-running at loop top also picks it up. A rebuild's rework re-dispatch must surface the
> `"G-02"` feedback to the agents.
> ⚠️ **GOTCHA-EXEC-NO-RETURN-FALLTHROUGH (the `while True` has no `break`; only the three returns
> exit):** the loop exits ONLY via `return "cancelled"` (1113 or 1131), `return "completed"` (1210),
> or `return "failed"` (1231). After the rework re-run for-loop completes it falls off the bottom of
> the `while` body and loops back to the top (blueprint-assembly). There is no `break`. A rebuild
> must NOT add a `break` — the loop is exited only by the three return statements.

---

## 10. ACTIVITY & CHILD-WORKFLOW CALL INVENTORY (in execution order, scope ≤1264)

| # | Activity | Where | Args (dataclass) | start_to_close | retry_policy | activity_id | Seq/Par | non_retryable |
|---|----------|-------|------------------|----------------|--------------|-------------|---------|---------------|
| A1 | `read_artifact` (source index) | `_read_target_source_artifacts_index` (617) | `ReadArtifactInput(repo=artifact_repo, branch="main", path=index_path)` | 30s | `transient` | `read-target-source-index-{target}` | seq | — (in try, → `[]`) |
| A2 | `read_artifact` (consolidation plan) | `_realize_consolidation_grain_if_present` (685) | `ReadArtifactInput(…, path=plan_path)` | 30s | `transient` | `read-consolidation-plan-{wave}` | seq | — (in try, → skip) |
| A3 | `realize_target_state_grain` | `_realize_consolidation_grain_if_present` (708) | `RealizeTargetStateGrainInput(wave_id, portfolio_id, consolidation_plan_artifact_ref=plan_path, consolidation_plan_json=read_result.content)` | **5 min** | **`infrastructure`** (10 attempts) | `realize-target-state-grain-{wave}-{app}` | seq | NonRetryable on schema-invalid → propagates |
| — | `_derive_target_state_mapping_from_plan` | step 1 (815) | *(sibling — reads plan via `read_artifact` 30s/transient; commits via `_commit_step_artifacts`; strict-fail non-retryable ApplicationError)* | — | — | `read-arch-target-plan-{target}` | seq | strict-fail |
| — | `_fire_target_provisioned_signal` | step 1 (827) | *(sibling — `publish_arch_data_signal` 30s/transient + best-effort peer signal)* | — | — | `publish-target-provisioned` | seq | best-effort |
| — | `_run_agent_step` × N | steps 2-9, 11-13, rework | *(sibling → OVERRIDDEN `_dispatch_agent` → `dispatch_agent_task`; then `_commit_step_artifacts`)* | 3h synthesis / 1h else | `agent_failure` | `agent-{step}` | par/seq | — |
| — | `_wait_for_data_ready` | step 5 (903) | *(sibling — `consume_arch_data_signal` 30s/transient on DB backstop; or `wait_condition`)* | 30s (per read) | `transient` | `consume-data-ready-for-target` | seq (blocks) | raises RuntimeError on cancel/timeout |
| A4 | `create_gate_record` | gate loop (1066) | `CreateGateRecordInput(gate_type="G-02", app_id, portfolio_id, workflow_id, evidence_package_url=pr_url)` | 30s | `transient` | *(auto)* | seq | — |
| — | `_create_gate_pr_architecture` | gate loop (1061) | *(sibling → `create_pr` 60s/transient, line-specific body)* | 60s | `transient` | *(auto)* | seq | — |
| — | `_submit_gate_evidence` | gate loop (1080) | *(base §11 → `check_gate_criteria` + `submit_gate_evidence`, both 60s/transient)* | 60s | `transient` | *(auto)* | seq | — |
| — | `_run_gate_pre_review` | gate loop (1093) | *(base §12 → `dispatch_agent_task` 10m + `store_gate_pre_review` 30s + `mark_gate_ready_for_review` 30s in finally)* | varies | `transient` | *(auto)* | seq | best-effort |
| — | `_update_app_status` (gate_review) | gate loop (1106) | *(base §7 → `update_application_status` 30s/transient)* | 30s | `transient` | *(auto)* | seq | — |
| A5 | `persist_architecture_side_effects` | approve branch (1161) | `PersistArchitectureSideEffectsInput(target_app_id, target_name=input.app_name, target_portfolio_id, target_application_map_json, blueprint_json, blueprint_ref, decided_at=_now_iso(), target_repo_url)` | 60s | `transient` | `persist-architecture-side-effects` | seq | — (in try, best-effort) |
| — | `_reconcile_and_merge_with_retry_loop` | approve branch (1196) | *(base §14 → `reconcile_and_merge_pr` 60s/**git_merge**; `set_gate_merge_blocked` on structured error; `wait_condition` merge_retry)* | 60s | `git_merge` | *(auto)* | seq (loops) | MergeConflict/Divergence/BranchProtection |
| — | `_update_app_status` (complete/failed) | various | *(base §7 → 30s/transient)* | 30s | `transient` | *(auto)* | seq | — |

> ⚠️ **GOTCHA-ACT-INFRA (A3 uses `infrastructure` policy, NOT `transient`):** `realize_target_state_grain`
> (`architecture.py:717`) is the ONLY activity in scope using `RETRY_POLICIES["infrastructure"]` (10
> attempts, 5s→300s backoff) and a **5-minute** timeout. Schema-invalid plans raise NonRetryable and
> propagate out of the helper (caught by `run()`'s except → FAILED). A rebuild must use
> `infrastructure` + 5min here, not transient.
> ⚠️ **GOTCHA-ACT-PERSIST-ID (A5 fixed `activity_id="persist-architecture-side-effects"`):** stable
> id → idempotent on replay. A rebuild keeps the explicit id.

---

## 11. `_read_target_source_artifacts_index(self, input, target_app_id) -> list[str]` (`595-648`)

Returns Discovery + Rationalization artifact paths from the target's source-artifacts-index, or
`[]` if absent/malformed. Best-effort (the index is optional).
```text
async def _read_target_source_artifacts_index(self, input, target_app_id):
    if not input.wave_id or not input.artifact_repo:           # arch.py:610  BRANCH 1
        return []                                              # arch.py:611  ← no wave/repo → []
    index_path = (f"rationalization/wave-{input.wave_id}/targets/{target_app_id}/"
                  f"source-artifacts-index.json")              # arch.py:612-615
    try:
        result = await workflow.execute_activity(              # arch.py:617-627  ACTIVITY A1
            read_artifact,
            ReadArtifactInput(repo=input.artifact_repo, branch="main", path=index_path),
            start_to_close_timeout=timedelta(seconds=30),
            retry_policy=RETRY_POLICIES["transient"],
            activity_id=f"read-target-source-index-{target_app_id}")
    except Exception:                                          # arch.py:628  BRANCH 2 — index optional
        return []                                              # arch.py:629
    try:
        import json as _json                                  # arch.py:632  (local import inside try)
        payload = _json.loads(result.content)                 # arch.py:634
    except Exception:                                         # arch.py:635  BRANCH 3 — malformed → []
        return []                                             # arch.py:636
    paths: list[str] = []
    for source in payload.get("source_apps", []) or []:        # arch.py:639  LOOP 1
        artifacts = source.get("artifacts", {}) or {}          # arch.py:640
        for key in ("discovery", "rationalization"):           # arch.py:641  LOOP 2 (fixed keys)
            for p in artifacts.get(key, []) or []:             # arch.py:642  LOOP 3
                if isinstance(p, str) and p:                   # arch.py:643  BRANCH 4
                    paths.append(p)                            # arch.py:644
    for p in payload.get("shared_artifacts", []) or []:        # arch.py:645  LOOP 4
        if isinstance(p, str) and p:                           # arch.py:646  BRANCH 5
            paths.append(p)                                    # arch.py:647
    return paths                                               # arch.py:648
```
**Branch inventory (5 + 4 loops):** missing wave/repo (610); activity exception (628); JSON parse
exception (635); per-source-app loop over `("discovery","rationalization")` with `isinstance(p,str)
and p` guard (639-644); `shared_artifacts` loop with same guard (645-647).

> ⚠️ **GOTCHA-IDX1 (THREE swallow points all return `[]`):** missing wave/repo, activity failure
> (index not found), and malformed JSON all return `[]` so an in-flight run that predates the index
> keeps using `input.prior_artifacts`. A rebuild must reproduce all three early returns.
> ⚠️ **GOTCHA-IDX2 (`isinstance(p, str) and p` guards filter non-string / empty entries):** every
> path append is guarded (643, 646) so a malformed index with `null`/numeric/empty entries doesn't
> inject garbage paths. A rebuild must keep both type+truthy guards.
> ⚠️ **GOTCHA-IDX3 (only `discovery` + `rationalization` keys are harvested):** the inner loop is
> over the literal tuple `("discovery","rationalization")` (641) — other artifact categories in the
> index are ignored. `shared_artifacts` is harvested separately (645). A rebuild must use exactly
> these keys.
> ⚠️ **GOTCHA-IDX4 (`import json as _json` is INSIDE the try, not module-level):** `architecture.py:632`
> re-imports json locally under a different alias. `json` is already imported at module top under
> `imports_passed_through`, so this is redundant but harmless. A rebuild may use the module `json`;
> the local alias is cosmetic.

---

## 12. `_realize_consolidation_grain_if_present(self, input) -> None` (`650-746`)

Reads the wave's G-RR-approved capability-consolidation-plan (if present) and UPSERTs cross-app
target-side rows via `realize_target_state_grain`. Best-effort on a *missing* plan; **loud** on a
*schema-invalid* plan.
```text
async def _realize_consolidation_grain_if_present(self, input):
    if not input.wave_id or not input.artifact_repo:           # arch.py:674  BRANCH 1
        workflow.logger.info("realize_target_state_grain skipped — no wave/artifact_repo", …)  # arch.py:675-678
        return                                                 # arch.py:679  ← no wave/repo → skip
    plan_path = (f"rationalization/wave-{input.wave_id}/"
                 f"capability-consolidation-plan.json")        # arch.py:680-683
    try:
        read_result = await workflow.execute_activity(         # arch.py:685-697  ACTIVITY A2
            read_artifact,
            ReadArtifactInput(repo=input.artifact_repo, branch="main", path=plan_path),
            start_to_close_timeout=timedelta(seconds=30),
            retry_policy=RETRY_POLICIES["transient"],
            activity_id=f"read-consolidation-plan-{input.wave_id}")
    except Exception as exc:                                   # arch.py:698  BRANCH 2 — plan optional
        workflow.logger.info("realize_target_state_grain: no consolidation plan at %s (%s); skipping …",
            plan_path, str(exc)[:200])                         # arch.py:699-704
        return                                                 # arch.py:705  ← missing plan → skip
    try:
        result = await workflow.execute_activity(              # arch.py:708-722  ACTIVITY A3
            realize_target_state_grain,
            RealizeTargetStateGrainInput(wave_id=input.wave_id, portfolio_id=input.portfolio_id,
                consolidation_plan_artifact_ref=plan_path,
                consolidation_plan_json=read_result.content),
            start_to_close_timeout=timedelta(minutes=5),       # arch.py:716
            retry_policy=RETRY_POLICIES["infrastructure"],     # arch.py:717  ★ infrastructure (10 attempts)
            activity_id=f"realize-target-state-grain-{input.wave_id}-{input.app_id}")
        workflow.logger.info("realize_target_state_grain wrote target-side rows", extra={…})  # arch.py:723-742
    except Exception:                                          # arch.py:743  BRANCH 3
        raise                                                  # arch.py:746  ★ RE-RAISE (schema-invalid surfaces)
```
**Branch inventory (3):** missing wave/repo skip (674-679); missing-plan skip on read failure
(698-705); the realize call's `except Exception: raise` (743-746).

> ⚠️ **GOTCHA-GRAIN1 (asymmetric error handling — missing plan SKIPS, invalid plan RAISES):** a
> *missing* plan (read_artifact fails, branch 2) is best-effort → log + return (older waves /
> Track-A-foundation-only portfolios have no plan). But the `realize_target_state_grain` activity's
> failure (branch 3) is **re-raised** — a NonRetryable schema-validation error propagates out of
> this helper (and via `_execute_architecture` → `run()`'s except → FAILED). The docstring (670-672)
> is explicit: "an invalid plan fails loud at the activity (NonRetryableError) and propagates out."
> A rebuild MUST keep this asymmetry — swallowing branch 3 would silently skip a broken plan.
> ⚠️ **GOTCHA-GRAIN2 (the `except Exception: raise` is intentional, not a no-op):** branch 3 looks
> like dead code but is semantically meaningful: it documents that **transient** failures were
> already retried by the `infrastructure` policy (10 attempts), so anything reaching here is
> terminal and must surface. A rebuild may omit the bare try/raise (equivalent to not catching) but
> the *behavior* (propagate) must hold.
> ⚠️ **GOTCHA-GRAIN3 (idempotent on natural keys — concurrent waves safe):** the docstring (663-667)
> notes the activity is idempotent on natural keys so concurrent Architecture workflows for the same
> wave can both invoke it without doubling rows. This is an activity-side guarantee; the workflow
> just calls it. A rebuild relies on the activity being idempotent (out of scope here).

---

## 13. RESILIENCE SUMMARY (scope ≤1264)

- **Timeouts (start_to_close):** `read_artifact` (index/plan) 30s; `realize_target_state_grain`
  **5 min**; `create_gate_record` 30s; `persist_architecture_side_effects` 60s; `consume_arch_data_signal`
  (per backstop read, sibling) 30s. Inherited helpers: dispatch 3h synthesis / 1h else (override),
  pre-review 10m, merge 60s, status 30s, PR 60s, gate-criteria/evidence 60s.
- **Data-ready wait cap:** `_DATA_READY_WAIT_TIMEOUT_SECONDS` = **24h** overall (sibling); DB
  backstop `_DB_BACKSTOP_INTERVAL_SECONDS` = 5 min; legacy poll 15s. On cap or cancel → `RuntimeError`
  → workflow FAILED.
- **Heartbeats:** the agent dispatch override sets `heartbeat_timeout=2m` (sibling 2020); nothing in
  scope ≤1264 sets a heartbeat directly.
- **continue-as-new:** **none.** The `while True` gate-rework loop bounds itself by
  `MAX_REWORK_ITERATIONS=3` (`> 3` → FAILED), not by history-size continue-as-new. The Data-ready
  wait uses the 5-min DB-backstop precisely to keep history-event count low (the comment at 138-145
  notes ~5700 polls collapse to ~288 over 24h). A rebuild must NOT add continue-as-new; bound rework
  by the counter and keep the backstop cadence to manage history size.
- **Idempotency:** deterministic `activity_id`s (`read-target-source-index-{target}`,
  `read-consolidation-plan-{wave}`, `realize-target-state-grain-{wave}-{app}`,
  `persist-architecture-side-effects`, and inherited `agent-{step}`/`commit-{step}`). `_now_iso()` =
  `workflow.now()` is deterministic. All five `workflow.patched(...)` IDs gate optional behavior.
- **Compensation / rollback:** **none.** Failure semantics: (a) target-state-mapping strict-fail and
  consolidation-grain schema-invalid → non-retryable → workflow FAILED (with best-effort
  `architecture_failed` DB status push in `run()`); (b) persist-side-effects failure is best-effort
  (logged, gate still completes); (c) `_fire_target_provisioned_signal`, source-index read,
  missing-consolidation-plan, target-repo provisioning (sibling) are all best-effort; (d) structured
  merge errors route to `merge_blocked` and wait for reviewer retry (base §14); (e) `self.cancelled`
  drains the Data wait, the gate wait, the Tier-1 wait, and the merge wait to a clean
  `"cancelled"`/CANCELLED return.

> ⚠️ **GOTCHA-RES-PATCH-LIST (the FIVE patch IDs that gate scope-≤1264 behavior — all verbatim):**
> `architecture-source-index-v1` (767), `architecture-realize-grain-v1` (788),
> `arch-parallel-fanout-v1` (839 **and** 923 — same string, two sites),
> `architecture-stage5-evidence-v1` (1017). (Sibling code adds `arch-data-registry-v1`,
> `arch-data-signal-first-v1`.) A rebuild MUST reproduce every one EXACTLY — any change breaks
> replay of in-flight pre-patch histories with a nondeterminism error.

---

## 14. BEHAVIORAL PARITY CHECKLIST (scope ≤1264)

A rebuilt `ArchitectureWorkflow` (lines 1–1264) MUST satisfy ALL of the following:

1. **Class & classvars:** `class ArchitectureWorkflow(LineWorkflowBase)`; classvars
   `ASSEMBLY_LINE=AssemblyLine.ARCHITECTURE`, `ARTIFACT_ROOT="architecture"`,
   `LINE_LABEL="Architecture"`, `STATUS_PREFIX="architecture"`, `STEPS=ARCHITECTURE_STEPS`,
   `STEP_WEIGHTS=STEP_WEIGHTS`, `SINGLE_GATE_KEY="G-02"`. `STEP_WEIGHTS` sums to exactly 100.0
   (import-time `assert`). (§1, §2)
2. **`__init__`** calls `super().__init__()` first, then sets exactly 9 arch vars to:
   `_stakeholder_ea_approved=False`, `_stakeholder_security_approved=False`, `_disposition=""`,
   `_data_ready=False`, `_data_architecture_ref=""`, `_data_migration_plan_ref=""`,
   `_target_repo_url=""`, `_artifact_repo=""`, `_target_service_id=""`. (§4)
3. **Two NEW signals only** (`stakeholder_approved`, `data_ready_for_target`), both `async def
   @workflow.signal`. The base four gate signals + `get_status` are NEVER redefined. (§0, §5)
4. **`stakeholder_approved`:** `scope=="g-02-ea"`→`_stakeholder_ea_approved=True`;
   `scope=="g-02-security"`→`_stakeholder_security_approved=True`; else log warning + drop; ALWAYS
   bump `_updated_at`. (§5.1, GOTCHA-STK1/2/3)
5. **`data_ready_for_target`:** FIRST `await workflow.wait_condition(lambda: bool(self._app_id))`;
   then drop (return, no mutation) if `signal.target_app_id != self._app_id`; else set
   `_data_ready=True`, cache `data_architecture_ref` + `data_migration_plan_ref`, bump `_updated_at`.
   (§5.2, GOTCHA-DRT1/2/3 — the await is the Wave-1 fix; keep it first.)
6. **`run()`:** sets `_status=RUNNING`/`_started_at`/`_updated_at`; `_app_id=input.app_id`,
   `_portfolio_id`, `_wave_id`, `_risk_tier`; normalizes `_disposition` from `input.disposition`
   only if not None; `_target_service_id = getattr(input,"target_service_id","") or ""`;
   `_artifact_repo=input.artifact_repo`; awaits `_provision_target_repo_for_this_run` BEFORE the
   step loop; `repo=input.artifact_repo` (NOT target repo); `run_suffix` = last hyphen-segment of
   the workflow id else first 8 chars; `branch=f"olympus/architecture/{target}/{suffix}"`;
   `workspace_key=f"architecture-{target}-{suffix}"`; delegates to `_execute_architecture` in a
   try/except that on ANY exception sets `_status=FAILED`/`_current_step="failed"`, best-effort
   `_update_app_status(…,"architecture_failed","failed",…)` (swallow its failure), and RE-RAISES.
   (§6, GOTCHA-RUN1/2/3/4)
7. **`_is_system_umbrella`** = `self._target_service_id == "system"`. **`_should_run_step`**: if
   umbrella, `step_name in SYSTEM_UMBRELLA_ARCHITECTURE_STEPS` (the exact 6-element frozenset); else
   True. (§7, §8)
8. **`_execute_architecture` step order** (per-service, new-patch shape): step1 target-state-mapping
   (always, no guard) → fire-target-provisioned → [cloud-pattern-selection ‖ ea-compliance gather]
   → integration-arch (create-task-then-await) → data-architecture wait (guarded) → [security-arch
   ‖ design-system ‖ accessibility-review ‖ ai-ml-integration gather] → `while True`{ blueprint-
   assembly → [cloud-cost-estimate ‖ well-architected-review ‖ traceability-validation gather] →
   commit-marker → create-G-02-PR + create_gate_record + submit-evidence → ai-pre-review →
   gate-review-02 wait → route }. (§9)
9. **Input-artifact snapshot discipline:** in each fan-out group, capture `parallel_inputs =
   prior_inputs` BEFORE creating tasks, gather, THEN `prior_inputs = self._collect_committed_paths()`.
   Sequential steps re-collect after each. (GOTCHA-EXEC-FANOUT)
10. **Patch gates (verbatim, exact sites):** `architecture-source-index-v1` (index merge);
    `architecture-realize-grain-v1` (consolidation grain); `arch-parallel-fanout-v1` (BOTH the 2+3
    AND 6-9 fan-outs — same string twice); `architecture-stage5-evidence-v1` (11/12/13 evidence).
    Pre-patch histories take the documented legacy/skip branches. (§9, GOTCHA-RES-PATCH-LIST)
11. **Legacy 6-9 shape** (no `arch-parallel-fanout-v1`): security-arch sequential → [design-system ‖
    accessibility-review gather] → ai-ml-integration sequential. (GOTCHA-EXEC-LEGACY69)
12. **data-architecture handling:** guarded by `_should_run_step("data-architecture")` (umbrella
    SKIPS it); on completion, IF `_data_architecture_ref` truthy set
    `_step_committed_paths["data-architecture"]=[arch_ref, migration_plan_ref]`. (§9.6,
    GOTCHA-SRS2/GOTCHA-EXEC-DATAREFS)
13. **Gate G-02 creation:** `create_gate_record(gate_type="G-02", …, evidence_package_url=pr_url)`
    30s/transient; `_submit_gate_evidence(gate_type=GateType.G_02, …, forward_risk_tier=True)`;
    `_run_gate_pre_review(gate_id, "G-02", artifact_paths, artifact_repo=repo, artifact_ref=branch)`.
    (§9.8.d/e)
14. **Decision routing:** `"cancelled"`→`return "cancelled"` (base already set CANCELLED);
    `"approved"`→ Tier-1 sub-wait → persist → merge loop → COMPLETED/100%/`return "completed"`;
    `"rejected"`→ reset both stakeholder flags, `_bump_rework("G-02")`, if `_rework_count("G-02") >
    MAX_REWORK_ITERATIONS` (=3) → FAILED/`return "failed"`, else re-run the 7 agent steps and loop.
    (§9.8.f)
15. **Tier-1 triple-signal:** ONLY when `_risk_tier == 1`, `await wait_condition((ea AND security)
    OR cancelled)`; on cancel set `_status=CANCELLED`, `return "cancelled"`. Tier-2/3 skip the
    sub-wait entirely. (GOTCHA-EXEC-TIER1)
16. **Stakeholder-flag reset is in the REJECT branch (1219-1220), NOT at loop top** — preserves
    early-arriving Tier-1 sign-offs before the first gate wait. (GOTCHA-RESET)
17. **Rework counter is bumped by THIS subclass** via `_bump_rework("G-02")` on `"rejected"`, with a
    strict `> MAX_REWORK_ITERATIONS` ceiling (3 reworks tolerated, 4th rejection fails). The base
    `_wait_for_gate_decision` does NOT bump it. (GOTCHA-EXEC-REWORK-COUNTER)
18. **Rework re-runs EXACTLY 7 agent steps in fixed order** (`cloud-pattern-selection`,
    `ea-compliance`, `integration-arch`, `security-arch`, `design-system`, `accessibility-review`,
    `ai-ml-integration`) SEQUENTIALLY (honoring `_should_run_step`), resets `running_progress` to
    `STEP_WEIGHTS["target-state-mapping"] + STEP_WEIGHTS["data-architecture"]` (12.0), and loops to
    re-run blueprint-assembly. Does NOT re-run target-state-mapping or data-architecture.
    (GOTCHA-EXEC-REWORK-SCOPE)
19. **Persist side-effects is best-effort:** `persist_architecture_side_effects` 60s/transient/
    `activity_id="persist-architecture-side-effects"`, wrapped in try/except that logs and continues
    (gate approval completes regardless). `blueprint_json`/`target_map_json` are `[0]` of the
    respective `_step_results` entry if present, else `""`. `blueprint_ref =
    f"architecture/{target}/architecture-blueprint.json"`. `target_repo_url=self._target_repo_url`.
    (§9.8.f, GOTCHA-EXEC branches 34/35/36)
20. **`_read_target_source_artifacts_index`:** returns `[]` on missing wave/repo, on read-activity
    exception, and on malformed JSON; harvests only `("discovery","rationalization")` per source app
    plus `shared_artifacts`, each path guarded by `isinstance(p,str) and p`. `read_artifact`
    30s/transient/`activity_id="read-target-source-index-{target}"`. (§11, GOTCHA-IDX1/2/3)
21. **`_realize_consolidation_grain_if_present`:** skip (log+return) on missing wave/repo; skip
    (log+return) when `read_artifact` for the plan fails (missing plan); on the
    `realize_target_state_grain` call use 5min/**`infrastructure`** (10 attempts)/
    `activity_id="realize-target-state-grain-{wave}-{app}"` and **RE-RAISE** any exception
    (schema-invalid surfaces → workflow FAILED). (§12, GOTCHA-GRAIN1/2)
22. **Module helpers:** `_encode_target_provisioned_payload` serializes the 9 fields with defensive
    `getattr(...) or default` + `list()` on the three W19 fields; `_decode_data_ready_payload`
    returns `{}` on empty / parse-error (`except (ValueError, TypeError)`) / non-dict. (§3,
    GOTCHA-ENC1/DEC1)
23. **`while True` loop has NO `break`** — exits ONLY via `return "cancelled"`, `return "completed"`,
    or `return "failed"`. (GOTCHA-EXEC-NO-RETURN-FALLTHROUGH)
24. **No continue-as-new, no rollback/compensation in scope ≤1264.** Rework bounded by the counter;
    Data wait bounded by 24h cap (RuntimeError on cap/cancel). (§13)
25. **Inherited methods are NOT overridden in this scope:** `_set_step`, `_update_app_status`,
    `_submit_gate_evidence`, `_wait_for_gate_decision`, `_run_gate_pre_review`,
    `_reconcile_and_merge_with_retry_loop`, `_bump_rework`, `_rework_count`, `_execution_ctx`,
    `_commit_step_artifacts`, the four base gate signals, and `get_status` are used as-is from
    `LineWorkflowBase`. (The overrides `_dispatch_agent` / `_build_evidence_data` /
    `_collect_committed_paths` / `_create_gate_pr_architecture` are in the sibling file >1264.) (§0)
