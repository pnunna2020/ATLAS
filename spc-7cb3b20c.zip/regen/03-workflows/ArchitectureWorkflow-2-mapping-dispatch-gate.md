# `ArchitectureWorkflow` — Part 2: Mapping derivation, dispatch override, evidence & gate-PR (ATOMIC regeneration spec)

> **Refreshed to HEAD `7cb3b20c`** (file now 2198 lines). The only behavioral change in this scope
> since the prior baseline is PR #577 (W8 Security/cATO evidence pipeline): `_dispatch_agent` now pins
> `context["fixture_scenario"] = "security-arch"` for the `security-arch` step (`architecture.py:1945-1946`,
> NEW BRANCH — see §A.2 / GOTCHA-DA-OVR6). That 7-line insert shifts every citation from `_dispatch_agent`
> line ~1948 onward by **+7** (e.g. `_build_evidence_data` 2034→2041, `_create_gate_pr_architecture`
> 2112→2119); all such citations below are corrected to current lines.
>
> **Source of truth:** `temporal/olympus_workflows/workflows/architecture.py`. Every `architecture.py:line`
> citation below is against that file. **This file OWNS only lines 1264–2198** — the step-helper /
> override block. Lines 1–1263 (module docstring, constants, `ARCHITECTURE_STEPS`, `STEP_WEIGHTS`,
> `SYSTEM_UMBRELLA_ARCHITECTURE_STEPS`, the two signal handlers, `run`, `_execute_architecture`,
> `_is_system_umbrella`, `_should_run_step`, `_read_target_source_artifacts_index`,
> `_realize_consolidation_grain_if_present`) are specced in the sibling file
> `ArchitectureWorkflow-1-*.md` — referenced here but **not** re-reproduced.
>
> **Inherits:** `class ArchitectureWorkflow(LineWorkflowBase)` (`architecture.py:378-379`). See
> `_LineWorkflowBase.md` for all inherited helpers/signals/queries and `_HILSignalsMixin.md` for the
> HIL signal surface (`cancelled`, `approve`, `cancel_workflow`, etc.). **This subclass OVERRIDES one
> base method (`_dispatch_agent`) and one base method by name-shadowing (`_build_evidence_data`)**; it
> also DEFINES several brand-new helpers (`_derive_target_state_mapping_from_plan`, `_run_agent_step`,
> `_run_agent_step_task`, `_wait_for_data_ready`, `_provision_target_repo_for_this_run`,
> `_render_target_repo_readme`, `_fire_target_provisioned_signal`, `_collect_committed_paths`,
> `_create_gate_pr_architecture`). The exact override deltas are in §A and §F below.
>
> **Branch-count for this scope:** ~96 branch-points (if/elif/else/except/for/while/ternary/`and`-`or`
> guards) across the 11 methods in lines 1264–2198 — one more than the prior baseline because of the
> NEW `security-arch` fixture-scenario branch in `_dispatch_agent` (`:1945`). All are reproduced below.

---

## 0. Override / new-method inventory (what THIS scope changes vs base)

| Method (this scope) | Relationship to base | Lines |
|---|---|---|
| `_dispatch_agent` | **OVERRIDE** of `LineWorkflowBase._dispatch_agent` (`base.py:380-457`) — different signature (adds `source_repo`), no context-priors patch, `security-arch` fixture-scenario pin (NEW, #577), blueprint router, synthesis-tier model preference, per-step timeout + heartbeat | `1919-2039` |
| `_build_evidence_data` | **OVERRIDE** (name-shadow) of `LineWorkflowBase._build_evidence_data` (`base.py:987-1053`) — Architecture-specific bundle: skips `kind=="code"` steps, hard-codes `assembly_line="Architecture"`, appends a `data_architecture` ref block | `2041-2110` |
| `_collect_committed_paths` | **NEW** helper (no base equivalent) | `2112-2117` |
| `_create_gate_pr_architecture` | **NEW** helper — does NOT call `base._create_gate_pr`; builds its own `CreatePRInput` and calls `create_pr` directly | `2119-2198` |
| `_derive_target_state_mapping_from_plan` | **NEW** — replaces step-1 agent dispatch with plan-derived synthesized result | `1264-1411` |
| `_run_agent_step` | **NEW** — per-step dispatch+commit wrapper (calls the overridden `_dispatch_agent`) | `1413-1460` |
| `_run_agent_step_task` | **NEW** — returns a coroutine for parallel `asyncio.gather` | `1462-1476` |
| `_wait_for_data_ready` | **NEW** — Data-line handshake wait (three patch-gated branches) | `1478-1623` |
| `_provision_target_repo_for_this_run` | **NEW** — provision/derive the target modernization repo | `1625-1734` |
| `_render_target_repo_readme` | **NEW** `@staticmethod` — README body | `1736-1762` |
| `_fire_target_provisioned_signal` | **NEW** — publish `TargetProvisionedSignal` to the arch-data registry (+ fast-path signal) | `1764-1913` |

> ⚠️ **GOTCHA-OVR0 (`_build_evidence_data` shadows base AND is the one called by `_submit_gate_evidence`):**
> `LineWorkflowBase._submit_gate_evidence` (`base.py:629-728`) calls `self._build_evidence_data(...)`.
> Because this subclass defines its own `_build_evidence_data`, **Architecture's gate evidence uses the
> override here, not the base** — both the slim `submit_gate_evidence` bundle and the
> `content_paths`-enriched `check_gate_criteria` bundle are built by `architecture.py:2041`. The override
> keeps the SAME keyword signature (`include_content`, `content_paths`) so the base's slim/enriched
> two-call contract (GOTCHA-SE1) still works — a rebuild MUST preserve the signature exactly or the base
> caller breaks.

---

## 1. State touched by this scope (declared in `__init__`, `architecture.py:397-431`)

These instance vars are READ/WRITTEN by the methods in this file. (Full state table is in sibling
file part 1; here we list only what this scope mutates or depends on.)

| Var | Type | Initial | Touched in THIS scope → how |
|-----|------|---------|------------------------------|
| `_disposition` | `str` | `""` (`:411`) | READ by `_dispatch_agent` (blueprint router, `:1957`) and by `_render_target_repo_readme` indirectly (it reads `input.disposition`, not this var) |
| `_data_ready` | `bool` | `False` (`:414`) | WRITTEN `True` by `_wait_for_data_ready` on registry hit (`:1562`,`:1602`); READ in wait predicates (`:1504`,`:1524`,`:1534`,`:1577`,`:1620`) |
| `_data_architecture_ref` | `str` | `""` (`:415`) | WRITTEN by `_wait_for_data_ready` (`:1556`,`:1596`); READ by `_build_evidence_data` (`:2107`) + `_create_gate_pr_architecture` (`:2152`,`:2162`,`:2163`) |
| `_data_migration_plan_ref` | `str` | `""` (`:416`) | WRITTEN by `_wait_for_data_ready` (`:1559`,`:1599`); READ by `_build_evidence_data` (`:2108`) + `_create_gate_pr_architecture` (`:2164`) |
| `_target_repo_url` | `str` | `""` (`:421`) | WRITTEN by `_provision_target_repo_for_this_run` (`:1652`,`:1719`); READ by `_run_agent_step` (mirror, `:1451`), `_fire_target_provisioned_signal` (`:1801`) |
| `_target_service_id` | `str` | `""` (`:431`) | READ by `_fire_target_provisioned_signal` log (`:1845`); drives `_should_run_step` (part 1) |
| `_agent_metadata` | `dict[str,dict]` | `{}` (base) | WRITTEN by `_derive_target_state_mapping_from_plan` (`:1389`) + `_dispatch_agent` (`:2031`); READ by `_build_evidence_data` (`:2071`) |
| `_step_results` | `dict[str,list[str]]` | `{}` (base) | WRITTEN by `_derive_…` (`:1397`) + `_run_agent_step` (`:1443`); READ by `_build_evidence_data` (`:2068`), `_create_gate_pr_architecture` (`:2130`) |
| `_step_committed_paths` | `dict[str,list[str]]` | `{}` (base) | WRITTEN by base `_commit_step_artifacts`; READ by `_collect_committed_paths` (`:2116`) |
| `_rework_feedback` | `dict[str,dict]` | `{}` (base) | READ by `_dispatch_agent` (`:1937`) — keyed `"G-02"` literal, NOT via `_rework_gate_key_for_step` |
| `_updated_at` | `str` | `""` (base) | bumped by `_wait_for_data_ready` (`:1563`,`:1603`) |
| `_risk_tier` | `int\|None` | `None` (base) | READ by `_create_gate_pr_architecture` (`:2136`,`:2138`) |
| `_app_id` | `str` | `""` (base) | READ by `_wait_for_data_ready` (`:1545`,`:1569`,…); set in `run` (part 1) |
| `_wave_id` | `str` | `""` (base) | READ by `_wait_for_data_ready` (`:1544`,`:1569`,…) |
| `cancelled` | `bool` | `False` (HIL mixin) | READ in every `_wait_for_data_ready` predicate; the universal kill switch (GOTCHA-1 in `_HILSignalsMixin.md`) |

> ⚠️ **GOTCHA-RWFB1 (`_dispatch_agent` reads `_rework_feedback["G-02"]` by LITERAL key, not via
> `_rework_gate_key_for_step`):** the BASE `_dispatch_agent` resolves the rework key via
> `self._rework_gate_key_for_step(step_name)` (`base.py:397`). THIS override instead does
> `self._rework_feedback.get("G-02")` directly (`architecture.py:1937`). Architecture is a single-gate
> line (`SINGLE_GATE_KEY="G-02"`, `:395`), so the literal `"G-02"` is equivalent to the base default —
> but a rebuild MUST hard-code `"G-02"` here to match history, NOT call the hook. `_wait_for_gate_decision`
> writes/clears `_rework_feedback["G-02"]` because it keys by `gate_type.value` where `GateType.G_02.value
> == "G-02"` (base GOTCHA-WG4).

---

## 2. `_derive_target_state_mapping_from_plan(self, input, target_app_id, repo, branch) -> None` — `architecture.py:1264-1411`

**Purpose (NEW method; replaces a per-row `target-state-mapper` agent dispatch):** derive the legacy
`target-application-map.json` from the wave-scoped `architecture-target-plan.json` that
`WaveArchitectureWorkflow` committed once per wave, synthesize an `AgentTaskResult`, record fake agent
metadata, and commit via the base `_commit_step_artifacts`. **Strict-fail** — four `non_retryable=True`
`ApplicationError` raise sites; no best-effort fallback.

```text
async def _derive_target_state_mapping_from_plan(self, input, target_app_id, repo, branch):
    # ── BRANCH 1 — missing wave/artifact_repo ──                           architecture.py:1300
    if not input.wave_id or not input.artifact_repo:
        raise ApplicationError(
            "Architecture child workflow missing wave_id or artifact_repo "
            "— cannot read wave-scoped target plan",
            non_retryable=True)                                            # :1301-1305

    plan_path = f"architecture/wave-{input.wave_id}/architecture-target-plan.json"   # :1306-1309

    # ── read the plan artifact (transient retry) ──
    try:
        read_result = await workflow.execute_activity(
            read_artifact,
            ReadArtifactInput(repo=input.artifact_repo, branch="main", path=plan_path),
            start_to_close_timeout=timedelta(seconds=30),                  # :1318
            retry_policy=RETRY_POLICIES["transient"],                      # :1319
            activity_id=f"read-arch-target-plan-{target_app_id}")          # :1320
    except Exception as exc:                          # BRANCH 2 — plan not found   :1322
        raise ApplicationError(
            f"architecture-target-plan.json not found at {plan_path!r} on "
            f"{input.artifact_repo}@main — WaveArchitectureWorkflow must commit "
            f"the plan before per-target Architecture children spawn ({exc!r})",
            non_retryable=True) from exc                                   # :1323-1329

    # ── parse plan JSON ──
    try:
        plan = json.loads(read_result.content)                            # :1332
    except Exception as exc:                          # BRANCH 3 — malformed JSON   :1333
        raise ApplicationError(
            f"architecture-target-plan.json at {plan_path!r} is malformed JSON "
            f"— coordinator should have rejected via schema validation before "
            f"commit ({exc!r})",
            non_retryable=True) from exc                                   # :1334-1339

    # ── BRANCH 4 — target_app_id not covered by the plan ──
    target_ids_in_plan = [
        (t.get("target_app_id") or "")
        for t in (plan.get("targets") or [])
        if isinstance(t, dict)                                            # :1341-1345  (list-comp + isinstance guard)
    ]
    if target_app_id not in target_ids_in_plan:                           # :1346
        raise ApplicationError(
            f"target_app_id={target_app_id!r} not present in "
            f"architecture-target-plan (plan covers {target_ids_in_plan!r}) "
            f"— provisioning seeded a target that the coordinator's plan does "
            f"not cover",
            non_retryable=True)                                           # :1347-1353

    # ── derive the legacy map (ValueError → NonRetryable) ──
    try:
        derived = derive_target_application_map_from_plan(
            plan, target_app_id,
            target_portfolio_id=input.portfolio_id or "")                 # :1356-1360
    except ValueError as exc:                         # BRANCH 5 — derivation failed   :1361
        raise ApplicationError(
            f"derive_target_application_map_from_plan failed for "
            f"target_app_id={target_app_id!r}: {exc}",
            non_retryable=True) from exc                                   # :1362-1366

    # ── synthesize an AgentTaskResult so _commit_step_artifacts works identically ──
    artifact_filename = ARCHITECTURE_STEPS["target-state-mapping"]["artifact"]   # :1370-1372  → "target-application-map.json"
    derived_content = json.dumps(derived, indent=2)                        # :1373
    synthesized_result = AgentTaskResult(
        task_id=f"derived-{target_app_id}",                                # :1375
        output_artifacts=["target-state-mapping derived from architecture-target-plan.json"],  # :1376-1379
        output_files=[OutputFile(path=artifact_filename, content=derived_content, encoding="utf-8")],  # :1380-1386
        model_used="derived-from-plan")                                    # :1387

    # ── record fake agent metadata so the gate card has a cost/model/token block ──
    self._agent_metadata["target-state-mapping"] = {
        "model_used": "derived-from-plan",
        "duration_ms": 0,
        "token_usage_input": 0,
        "token_usage_output": 0,
        "cost_estimate_usd": 0.0,
        "output_files": list(synthesized_result.output_files),            # :1389-1396
    }
    self._step_results["target-state-mapping"] = list(
        synthesized_result.output_artifacts)                              # :1397-1399

    artifact_path = f"architecture/{target_app_id}/{artifact_filename}"    # :1401-1403
    await self._commit_step_artifacts(
        repo, branch, target_app_id, "target-state-mapping",
        synthesized_result, artifact_path)                                # :1404-1411
```

**Branch inventory (6):** missing wave/repo (`:1300`); plan-not-found except (`:1322`); malformed-JSON
except (`:1333`); the `isinstance(t, dict)` comprehension guard + `target_app_id not in` membership
(`:1341-1346`); `derive_…` `ValueError` except (`:1361`).

**Activity calls (in order):**
1. `read_artifact` — `ReadArtifactInput(repo=input.artifact_repo, branch="main", path=plan_path)`; **30s**;
   `transient`; `activity_id="read-arch-target-plan-{target_app_id}"`. Failure → `ApplicationError(non_retryable=True)`.
2. *(no second activity)* — derivation is pure Python (`derive_target_application_map_from_plan`,
   `utils/target_plan.py`), then the base `_commit_step_artifacts` runs (which itself fires
   `write_artifacts_batch` + optional output-ref patch — see `_LineWorkflowBase.md` §9).

> ⚠️ **GOTCHA-DTS1 (no agent dispatch on step 1 — replaces a prior per-row mapper):** the docstring
> (`:1282-1289`) records that the prior best-effort per-row `target-state-mapper` dispatch was a BUG
> (it emitted wave-shaped output inside per-row dirs). The replacement is strict-fail: any of the four
> failure modes raises `non_retryable=True`. A rebuild MUST NOT add a fallback agent dispatch — a
> missing/malformed/uncovered plan is a deployment bug that must surface immediately.
> ⚠️ **GOTCHA-DTS2 (`model_used="derived-from-plan"`, zero cost):** the synthesized metadata records the
> model as the literal string `"derived-from-plan"` with `duration_ms=0` / all token + cost fields `0`
> (`:1387`,`:1389-1396`). This is what makes the G-02 gate card show a non-empty (but zero-cost) block
> for step 1. A rebuild must record exactly these sentinel values.
> ⚠️ **GOTCHA-DTS3 (two parallel writes of step-1 state):** both `_agent_metadata["target-state-mapping"]`
> (`:1389`) AND `_step_results["target-state-mapping"]` (`:1397`) are set BEFORE `_commit_step_artifacts`.
> `_commit_step_artifacts` reads `_agent_metadata[step]["output_files"]` (base `:484-485`) to build the
> commit batch, so the metadata write MUST precede the commit. `output_files` is stored as
> `list(synthesized_result.output_files)` (a copy) — a rebuild must copy, not alias.
> ⚠️ **GOTCHA-DTS4 (`read_artifact` reads `artifact_repo`, NOT `repo`/`branch` args):** the plan lives on
> `input.artifact_repo`@`main` (`:1313-1315`), independent of the `repo`/`branch` parameters (which are
> the per-run portfolio repo + work branch). A rebuild must read the plan from artifact-repo `main`.
> ⚠️ **GOTCHA-DTS5 (`derive_target_application_map_from_plan` itself raises `ValueError` for an absent
> target — DOUBLE-guarded):** the workflow checks membership at `:1346` AND `derive_…` re-checks at
> `target_plan.py:144`. Both raise. The workflow's `:1346` check fires first; the `:1361` except is a
> belt-and-suspenders for an entry whose `target_app_id` matches but whose body fails derivation. Keep
> both.

---

## A. OVERRIDE — `_dispatch_agent(...)` — `architecture.py:1919-2039`

**OVERRIDES `LineWorkflowBase._dispatch_agent` (`base.py:380-457`).** Signature ADDS a positional/keyword
`source_repo: str = ""` (base has none). Returns `AgentTaskResult`. Records `_agent_metadata[step_name]`.

### A.1 Signature delta

```text
# BASE  (base.py:380-394):
async def _dispatch_agent(self, app_id, step_name, input_artifacts,
                          workspace_key="", artifact_repo="", artifact_ref="") -> AgentTaskResult

# OVERRIDE (architecture.py:1919-1928):
async def _dispatch_agent(self, app_id, step_name, input_artifacts,
                          source_repo="", workspace_key="",
                          artifact_repo="", artifact_ref="") -> AgentTaskResult
```

### A.2 Override body (control flow)

```text
step_def = ARCHITECTURE_STEPS[step_name]                                   # :1935
context = {}                                                               # :1936

# ── rework feedback — LITERAL "G-02" key (NOT _rework_gate_key_for_step) ──
fb = self._rework_feedback.get("G-02")                                     # :1937
if fb is not None:                                       # BRANCH 1          :1938
    context["rework_feedback"] = fb                                        # :1939

# ── security-arch fixture-scenario pin (NEW, PR #577) ──
# cato-compliance ships multiple scenario fixtures (security-arch seed +
# G-V1/G-V2/G-V3 SSP/SAR/POA&M bundles); the mock runtime can no longer
# resolve the skill by the single-fixture rule, so the step pins it.
if step_name == "security-arch":                         # BRANCH 2 (NEW #577)  :1945
    context["fixture_scenario"] = "security-arch"                          # :1946

# ── blueprint-assembly router (step 10) ──
skill_id = step_def["skill_id"]                                            # :1955
if step_name == "blueprint-assembly":                    # BRANCH 3          :1956
    routed = select_architecture_blueprint_skill(self._disposition)        # :1957
    if routed is not None:                               # BRANCH 4          :1958
        skill_id = routed                                                  # :1959

# ── synthesis-tier model preference (tier-2 / Sonnet 1M) ──
synthesis_steps = {                                                        # :1981-1986
    "target-state-mapping", "blueprint-assembly",
    "cloud-pattern-selection", "ea-compliance"}
model_preference = "tier-2" if step_name in synthesis_steps else ""        # :1987-1989  (ternary BRANCH 5)

task_input = AgentTaskInput(
    task_type=f"architecture-{step_name}",                                 # :1991
    app_id=app_id,
    skill_id=skill_id,
    input_artifacts=input_artifacts,
    source_repo=source_repo,                                               # :1995  ← ADDED vs base
    artifact_repo=artifact_repo,
    artifact_ref=artifact_ref,
    workspace_key=workspace_key,
    context=context,
    model_preference=model_preference,                                     # :2000  ← ADDED vs base
    execution_context=self._execution_ctx(
        step_name, app_id=app_id, input_artifact_paths=input_artifacts))   # :2001-2005

# ── per-step timeout: 3h for synthesis, 1h otherwise ──
activity_timeout = (
    timedelta(hours=3) if step_name in synthesis_steps                     # BRANCH 6 (ternary)  :2019-2022
    else timedelta(hours=1))

result = await workflow.execute_activity(
    dispatch_agent_task, task_input,
    start_to_close_timeout=activity_timeout,                               # :2026
    heartbeat_timeout=timedelta(minutes=2),                                # :2027  ← ADDED vs base
    retry_policy=RETRY_POLICIES["agent_failure"],                          # :2028  (3 attempts, 5-60s)
    activity_id=f"agent-{step_name}")                                      # :2029

self._agent_metadata[step_name] = {                                        # :2031-2038
    "model_used": result.model_used,
    "duration_ms": result.duration_ms,
    "token_usage_input": result.token_usage_input,
    "token_usage_output": result.token_usage_output,
    "cost_estimate_usd": result.cost_estimate_usd,
    "output_files": result.output_files,
}
return result                                                              # :2039
```

**Branch inventory (6):** `if fb is not None` (`:1938`); **`if step_name == "security-arch"` (`:1945`, NEW
#577 — see GOTCHA-DA-OVR6)**; `if step_name == "blueprint-assembly"` (`:1956`); `if routed is not None`
(`:1958`); `model_preference = ... if ... else ""` ternary (`:1987`); `activity_timeout = ... if ... else
...` ternary (`:2019`).

**Activity calls (in order):**
1. `dispatch_agent_task` — `task_input`; **`start_to_close=3h`** for the four synthesis steps else **1h**;
   **`heartbeat_timeout=2m`**; `agent_failure` (3 attempts, 5-60s backoff); `activity_id="agent-{step_name}"`.

### A.3 How this override DIFFERS from base `_dispatch_agent`

| Aspect | Base (`base.py`) | This override (`architecture.py`) |
|---|---|---|
| `source_repo` arg | absent | added & threaded into `AgentTaskInput.source_repo` (`:1995`) — several arch skills read source for fallback context |
| rework-feedback key | `self._rework_gate_key_for_step(step_name)` then `.get(key)` (`:397-401`) | **literal** `self._rework_feedback.get("G-02")` (`:1937`) — GOTCHA-RWFB1 |
| `fixture_scenario` pin | none | **NEW (#577)**: `context["fixture_scenario"] = "security-arch"` for the `security-arch` step (`:1945-1946`) — GOTCHA-DA-OVR6 |
| context-priors | patch-gated `load_context_priors` activity (`base.py:409-421`) | **OMITTED** entirely — no `context-priors-v1` patch, no priors load |
| `skill_id` source | `_primary_skill_for_step` → `STEPS[step]["skill_id"]` | `step_def["skill_id"]`, **overridden by router** for `blueprint-assembly` (`:1956-1959`) |
| `model_preference` | not set (default `""`) | `"tier-2"` for the four synthesis steps (`:1987-1989`) |
| `task_type` | `f"{self._task_type_prefix()}-{step}"` (= `f"architecture-{step}"`) | hard-coded `f"architecture-{step_name}"` (`:1991`) — same value, different mechanism |
| `start_to_close` | fixed **1h** (`base.py:444`) | **3h** for synthesis steps else 1h (`:2019-2022`) |
| `heartbeat_timeout` | none | **2 minutes** (`:2027`) — `dispatch_agent_task` heartbeats every 30s |
| retry / activity_id / metadata | `agent_failure`, `agent-{step}`, 6-field metadata | **identical** |

> ⚠️ **GOTCHA-DA-OVR1 (blueprint router can return `None` → falls back to declared `skill_id`):**
> `select_architecture_blueprint_skill(self._disposition)` returns `None` for **Retire / Retain**
> dispositions (`architecture_patterns_router.py` — `DISPOSITION_BLUEPRINT_MAP["retire"/"retain"]=None`).
> The override checks `if routed is not None` (`:1958`) and only then overrides; on `None` it keeps the
> declared `skill_id="blueprint-assembly"` as a **safety net**. The comment (`:1947-1954`) says Retire/Retain
> *should* skip the step at the caller level, so this branch is defensive — but a rebuild MUST keep the
> `is not None` guard, NOT assign `skill_id = routed` unconditionally (that would set `skill_id=None` and
> crash dispatch).
> ⚠️ **GOTCHA-DA-OVR2 (router routes by `self._disposition` STRING):** `_disposition` is the enum *value*
> string captured at `run` entry (`:526-528`). The router `_normalize`s case (`"Refactor"`→`"refactor"`),
> maps Replace+Consolidate→`target-architecture-blueprint-rearchitect`, and returns the generic base
> `"target-architecture-blueprint"` for unknown/empty. A rebuild must pass the string, not the enum.
> ⚠️ **GOTCHA-DA-OVR3 (the four synthesis steps are EXACT — both timeout and tier depend on this set):**
> `synthesis_steps = {target-state-mapping, blueprint-assembly, cloud-pattern-selection, ea-compliance}`
> (`:1981-1986`). Membership controls BOTH `model_preference="tier-2"` (`:1987`) AND the 3h timeout
> (`:2019`). The comment block (`:1960-1980`) records WHY: Opus 4.7 1M returned `is_error=True,
> subtype=success` at >50% on the largest synthesis prompts (and on HIPAA-flagged `ea-compliance` /
> `cloud-pattern-selection`); Sonnet 1M (tier-2) is the proven workaround. A rebuild MUST use this exact
> 4-element set — adding/removing a member changes both routing and timeout for that step. (Note
> `target-state-mapping` is in the set even though step 1 is plan-derived and never calls `_dispatch_agent`
> on the happy path — it would only matter if a future caller dispatched it.)
> ⚠️ **GOTCHA-DA-OVR4 (heartbeat 2m + start_to_close as absolute cap):** PR #495 added `heartbeat_timeout=2m`
> with `dispatch_agent_task` heartbeating every 30s, so Temporal kills only on a true hang; `start_to_close`
> (1h/3h) becomes the absolute upper bound, not the liveness signal (`:2007-2018`). A rebuild MUST set both
> — omitting the heartbeat reverts to the old behavior where a slow-but-progressing call dies at the deadline.
> ⚠️ **GOTCHA-DA-OVR5 (NO context-priors here):** unlike base, this override never calls `load_context_priors`
> and has NO `workflow.patched("context-priors-v1")` gate. A rebuild of Architecture's `_dispatch_agent` MUST
> NOT add the priors path — doing so would inject a `load_context_priors` activity into Architecture
> histories that never had it and break replay.
> ⚠️ **GOTCHA-DA-OVR6 (NEW #577 — `security-arch` pins `context["fixture_scenario"]="security-arch"`):**
> `architecture.py:1945-1946` adds `if step_name == "security-arch": context["fixture_scenario"] =
> "security-arch"` — the FIRST step-name branch in the override body (before the blueprint router). Rationale
> (comment `:1940-1944`, W8 Security/cATO evidence pipeline): `cato-compliance` now ships MULTIPLE scenario
> fixtures (the `security-arch` seed PLUS the G-V1/G-V2/G-V3 SSP/SAR/POA&M bundles), so the mock runtime can
> no longer resolve the skill by the single-fixture rule and the step must name its scenario explicitly. This
> is the ONLY behavioral change in this scope since the prior baseline; it shifts every `_dispatch_agent`
> citation at/after `:1947` by **+7**. A rebuild MUST set `context["fixture_scenario"]="security-arch"` for
> the `security-arch` step (and only that step) before building `AgentTaskInput`, so `context` already
> carries both any rework feedback AND the fixture scenario. NOTE: it sets a `context` key, NOT
> `model_preference` — `security-arch` is NOT in the `synthesis_steps` set, so it still runs on the default
> model with the 1h timeout.

---

## 3. `_run_agent_step(...)` — `architecture.py:1413-1460`  (NEW)

Per-step wrapper: set progress, dispatch (via the §A override), record results, commit (with optional
target-repo mirror for `write_to_target` steps).

```text
async def _run_agent_step(self, step_name, app_id, prior_inputs, source_repo,
                          workspace_key, repo, branch):
    running = self._progress_pct                                           # :1432
    await self._set_step(step_name, running)                               # :1433  (base helper)
    result = await self._dispatch_agent(                                   # :1434  ← the §A override
        app_id=app_id, step_name=step_name, input_artifacts=prior_inputs,
        source_repo=source_repo, workspace_key=workspace_key,
        artifact_repo=repo, artifact_ref=branch)                          # :1435-1442
    self._step_results[step_name] = result.output_artifacts                # :1443
    step_def = ARCHITECTURE_STEPS[step_name]                               # :1444
    if step_def.get("artifact"):                          # BRANCH 1        :1445
        artifact_path = f"architecture/{app_id}/{step_def['artifact']}"    # :1446-1448
        mirror_repo = (                                                    # :1449-1453
            self._target_repo_url
            if step_def.get("write_to_target") and self._target_repo_url   # BRANCH 2 (ternary + AND)
            else "")
        await self._commit_step_artifacts(
            repo, branch, app_id, step_name, result, artifact_path,
            mirror_repo=mirror_repo,
            mirror_path_prefix=(
                f"docs/architecture/{step_name}" if mirror_repo else ""))  # :1454-1460  BRANCH 3 (ternary)
```

**Branch inventory (3):** `if step_def.get("artifact")` (`:1445`); `mirror_repo = ... if (write_to_target
and _target_repo_url) else ""` ternary (`:1449-1453`); `mirror_path_prefix = ... if mirror_repo else ""`
ternary (`:1458`).

**Activity calls (in order):** `_dispatch_agent` (→ `dispatch_agent_task`), then `_commit_step_artifacts`
(→ `write_artifacts_batch` [+ mirror batch if `write_to_target`] [+ output-ref patch if patched]).

> ⚠️ **GOTCHA-RAS1 (`progress` passed to `_set_step` is the CURRENT `_progress_pct`, not a freshly-computed
> value):** `_run_agent_step` reads `running = self._progress_pct` (`:1432`) and re-sets the step to it.
> The actual progress *increment* (`running_progress += STEP_WEIGHTS[step]`) happens in the caller
> (`_execute_architecture`, part 1), NOT here. So `_set_step` here only updates `_current_step` + DB status
> to "in_progress"; progress_pct stays at whatever the caller last set. A rebuild must NOT re-derive
> progress inside `_run_agent_step`.
> ⚠️ **GOTCHA-RAS2 (mirror only for `write_to_target` steps AND when `_target_repo_url` is non-empty):** the
> `write_to_target` flag is set on `cloud-pattern-selection`, `integration-arch`, `design-system`,
> `blueprint-assembly` in `ARCHITECTURE_STEPS` (part 1, `:223`,`:236`,`:257`,`:276`). The mirror fires ONLY
> when BOTH `step_def.get("write_to_target")` is truthy AND `self._target_repo_url` is non-empty (`:1451`).
> If provisioning failed (`_target_repo_url==""`), mirror is skipped silently and only the artifact_repo
> commit happens. Mirror path prefix is `docs/architecture/{step_name}`. A rebuild must reproduce both the
> AND-guard and the exact prefix.
> ⚠️ **GOTCHA-RAS3 (steps with no `artifact` skip commit entirely):** `if step_def.get("artifact")`
> (`:1445`) — `data-architecture` has `artifact=None` (part 1, `:243`) so if it were ever routed through
> `_run_agent_step` it would set results but commit nothing. In practice `data-architecture` is `kind=code`
> and never goes through `_run_agent_step`. Keep the guard.

---

## 4. `_run_agent_step_task(...)` — `architecture.py:1462-1476`  (NEW)

```text
def _run_agent_step_task(self, step_name, app_id, prior_inputs, source_repo,
                         workspace_key, repo, branch):
    return self._run_agent_step(                                           # :1473-1476
        step_name, app_id, prior_inputs, source_repo,
        workspace_key, repo, branch)
```

- **Synchronous** method that returns the **un-awaited coroutine** from `_run_agent_step`. Used by
  `_execute_architecture` (part 1) to build a `tasks` list for `asyncio.gather(*tasks)` (parallel fan-out
  of steps 2+3, 4, 6-9, 11-13, etc.).
- **No branches.**

> ⚠️ **GOTCHA-RAST1 (input-artifact snapshot is the CALLER's job, not this method's):** the parallel-fanout
> sites in part 1 snapshot `parallel_inputs = prior_inputs` BEFORE building the task list and pass that same
> frozen list to every `_run_agent_step_task` so siblings can't observe each other's commits (`:840`,`:924`).
> This method just forwards `prior_inputs` verbatim — it does NOT re-collect committed paths. A rebuild MUST
> NOT call `_collect_committed_paths()` inside the task; determinism of the gather depends on the snapshot.
> ⚠️ **GOTCHA-RAST2 (returns coroutine, does NOT await):** a rebuild must return `self._run_agent_step(...)`
> WITHOUT `await` so the caller controls scheduling via `asyncio.gather`. Awaiting here would serialize the
> "parallel" steps.

---

## 5. `_wait_for_data_ready(self) -> None` — `architecture.py:1478-1623`  (NEW) ★ CORE

Block until the Data line's handshake payload is available. **Three patch-gated branches** with very
different polling cadences. Hydrates `_data_architecture_ref` / `_data_migration_plan_ref` on success.

### 5.1 Branch I — `workflow.patched("arch-data-signal-first-v1")` (signal-first + 5-min DB backstop) — `:1499-1570`

```text
if workflow.patched("arch-data-signal-first-v1"):                          # :1499
    elapsed = 0                                                            # :1500
    while elapsed < _DATA_READY_WAIT_TIMEOUT_SECONDS:        # LOOP (24h cap)   :1501
        if self._data_ready:                  # BRANCH — common fast path   :1504
            return                                                         # :1505
        if self.cancelled:                    # BRANCH                      :1506
            raise RuntimeError("cancelled waiting for data-ready signal")  # :1507-1509

        remaining = _DATA_READY_WAIT_TIMEOUT_SECONDS - elapsed             # :1513
        this_wait = min(_DB_BACKSTOP_INTERVAL_SECONDS, remaining)          # :1514-1516  (shrink last slice)

        # signal-first: wait for the in-memory flag OR cancel, with a 5-min timeout
        try:
            await workflow.wait_condition(
                lambda: self._data_ready or self.cancelled,                # :1524  ★PREDICATE
                timeout=timedelta(seconds=this_wait))                      # :1525
        except asyncio.TimeoutError:           # BRANCH — backstop tick     :1527
            pass                                                           # :1528

        if self.cancelled:                     # BRANCH                     :1530
            raise RuntimeError("cancelled waiting for data-ready signal")  # :1531-1533
        if self._data_ready:                   # BRANCH                     :1534
            return                                                         # :1535

        # DB backstop: ONE registry read per iteration
        result = await workflow.execute_activity(
            consume_arch_data_signal,
            ConsumeArchDataSignalInput(
                signal_type=SIGNAL_DATA_READY_FOR_TARGET,                  # :1542  ("data_ready_for_target")
                wave_id=self._wave_id, target_app_id=self._app_id,
                workflow_id=workflow.info().workflow_id),                  # :1543-1546
            start_to_close_timeout=timedelta(seconds=30),                  # :1547
            retry_policy=RETRY_POLICIES["transient"],                      # :1548
            activity_id="consume-data-ready-for-target")                   # :1549
        if result.found:                       # BRANCH — registry hit      :1551
            payload = _decode_data_ready_payload(result.payload_json)      # :1555  (module helper)
            self._data_architecture_ref = payload.get("data_architecture_ref", "")   # :1556-1558
            self._data_migration_plan_ref = payload.get("data_migration_plan_ref", "")  # :1559-1561
            self._data_ready = True                                        # :1562
            self._updated_at = _now_iso()                                  # :1563
            return                                                         # :1564

        elapsed += this_wait                                               # :1566
    raise RuntimeError(                        # loop fell through → timeout   :1567-1570
        f"timed out waiting for data-ready signal (wave={self._wave_id} target={self._app_id})")
```

### 5.2 Branch II — `elif workflow.patched("arch-data-registry-v1")` (15-s registry poll) — `:1571-1615`

```text
elif workflow.patched("arch-data-registry-v1"):                            # :1571
    elapsed = 0                                                            # :1572
    while True:                                              # LOOP          :1573
        if self._data_ready:                  # BRANCH — stray-signal fast path   :1577
            return                                                         # :1578
        result = await workflow.execute_activity(
            consume_arch_data_signal,
            ConsumeArchDataSignalInput(
                signal_type=SIGNAL_DATA_READY_FOR_TARGET,
                wave_id=self._wave_id, target_app_id=self._app_id,
                workflow_id=workflow.info().workflow_id),                  # :1581-1586
            start_to_close_timeout=timedelta(seconds=30),
            retry_policy=RETRY_POLICIES["transient"],
            activity_id="consume-data-ready-for-target")                   # :1587-1589
        if result.found:                       # BRANCH — registry hit      :1591
            payload = _decode_data_ready_payload(result.payload_json)      # :1595
            self._data_architecture_ref = payload.get("data_architecture_ref", "")   # :1596-1598
            self._data_migration_plan_ref = payload.get("data_migration_plan_ref", "")  # :1599-1601
            self._data_ready = True                                        # :1602
            self._updated_at = _now_iso()                                  # :1603
            return                                                         # :1604
        if self.cancelled:                     # BRANCH                     :1605
            raise RuntimeError("cancelled waiting for data-ready registry entry")  # :1606-1608
        if elapsed >= _DATA_READY_WAIT_TIMEOUT_SECONDS:   # BRANCH — timeout   :1609
            raise RuntimeError(                                            # :1610-1613
                f"timed out waiting for data-ready registry entry (wave={self._wave_id} target={self._app_id})")
        await workflow.sleep(_REGISTRY_POLL_INTERVAL_SECONDS)              # :1614  (15s)
        elapsed += _REGISTRY_POLL_INTERVAL_SECONDS                         # :1615
```

### 5.3 Branch III — `else` (legacy pre-registry in-memory wait) — `:1616-1623`

```text
else:                                                                      # :1616
    await workflow.wait_condition(
        lambda: self._data_ready or self.cancelled)                        # :1619-1621  ★PREDICATE (no timeout)
    if self.cancelled:                         # BRANCH                     :1622
        raise RuntimeError("cancelled waiting for data-ready signal")      # :1623
```

**Branch inventory (~16):** Branch I `if patched(signal-first)` (`:1499`) + `while elapsed<cap` (`:1501`)
+ `if _data_ready` (`:1504`) + `if cancelled` (`:1506`) + `except TimeoutError` (`:1527`) + `if cancelled`
(`:1530`) + `if _data_ready` (`:1534`) + `if result.found` (`:1551`); Branch II `elif patched(registry)`
(`:1571`) + `while True` (`:1573`) + `if _data_ready` (`:1577`) + `if result.found` (`:1591`) + `if
cancelled` (`:1605`) + `if elapsed>=cap` (`:1609`); Branch III `else` (`:1616`) + `if cancelled` (`:1622`).

**Constants (module-level, `architecture.py:128-145`):**
- `_DATA_READY_WAIT_TIMEOUT_SECONDS = 24*60*60` (86400) — overall cap, all branches.
- `_REGISTRY_POLL_INTERVAL_SECONDS = 15` — Branch II poll cadence.
- `_DB_BACKSTOP_INTERVAL_SECONDS = 5*60` (300) — Branch I per-iteration `wait_condition` timeout.

**Module helper consumed:** `_decode_data_ready_payload(payload_json)` (`architecture.py:175-190`):
returns `{}` for empty/`None` (`:182-183`); `try: json.loads` → on `(ValueError, TypeError)` return `{}`
(`:184-187`); if not a `dict` return `{}` (`:188-189`); else return parsed dict. So `payload.get("...")`
never raises.

**Activity calls:** `consume_arch_data_signal` — `ConsumeArchDataSignalInput(signal_type=
SIGNAL_DATA_READY_FOR_TARGET, wave_id, target_app_id=self._app_id, workflow_id=workflow.info().workflow_id)`;
**30s**; `transient`; `activity_id="consume-data-ready-for-target"`. Fired once per loop iteration in
Branches I & II; never in Branch III.

> ⚠️ **GOTCHA-WDR1 (THREE patch branches, evaluated in order, MUST be reproduced verbatim):** the gate
> chain is `if patched("arch-data-signal-first-v1")` → `elif patched("arch-data-registry-v1")` → `else`
> (`:1499`,`:1571`,`:1616`). The exact patch strings are load-bearing for replay: a workflow started under
> a given patch set replays the SAME branch forever. A rebuild MUST use both literal patch IDs and keep the
> `if/elif/else` ordering. New runs (both patches present) take Branch I; mid-era runs (only registry) take
> Branch II; pre-registry histories take Branch III.
> ⚠️ **GOTCHA-WDR2 (Branch I collapses ~5700 polls → ~288):** Branch I waits on the in-memory signal flag
> with a 5-min `wait_condition` timeout, doing ONE registry read per backstop tick. For a 24h cap that's
> ≤288 iterations vs ~5700 at 15s; for a typical sub-30-min Data completion, ~5 reads (`:138-145`,
> `:1489-1494`). ATLAS Challenge 3 saw 1200+ history events from a 25-min wait under the old cadence. The
> `min(_DB_BACKSTOP_INTERVAL_SECONDS, remaining)` (`:1514`) shrinks the LAST slice so the loop never sleeps
> past the cap. A rebuild must keep the per-iteration `timeout=this_wait` and the `min(...)` clamp.
> ⚠️ **GOTCHA-WDR3 (`asyncio.TimeoutError` is the backstop trigger, swallowed with `pass`):** in Branch I
> the `wait_condition(..., timeout=...)` raises `asyncio.TimeoutError` on timeout, caught and `pass`ed
> (`:1527-1528`) so control falls to the DB read. This is the ONLY place a timeout is non-fatal. A rebuild
> must catch `asyncio.TimeoutError` specifically (not bare `Exception`) and continue, not propagate.
> ⚠️ **GOTCHA-WDR4 (cancel raises `RuntimeError`, it does NOT return):** every cancel check in this method
> RAISES `RuntimeError("cancelled waiting for data-ready ...")` (`:1507`,`:1531`,`:1606`,`:1623`) — unlike
> the base gate-wait which RETURNS `"cancelled"`. So a cancel during the data-ready wait propagates up
> through `_execute_architecture`'s outer `try/except` in `run` (part 1, `:561`) → `_status=FAILED`, NOT
> `CANCELLED`. A rebuild MUST raise here (the data wait predates the gate-string convention) — changing it
> to a clean return would alter terminal status on cancel.
> ⚠️ **GOTCHA-WDR5 (in-memory `_data_ready` fast-path short-circuits the activity):** all three branches
> check `self._data_ready` FIRST (`:1504`,`:1577`,`:1620`) so if the `data_ready_for_target` signal handler
> (`architecture.py:458-498`, part 1) already flipped the flag, the wait returns WITHOUT any registry read.
> Under the signal-first patch the peer Data workflow fires both a registry publish AND a Temporal signal,
> so the common path never reaches `consume_arch_data_signal`. A rebuild must keep the flag-first check in
> every branch.
> ⚠️ **GOTCHA-WDR6 (refs hydrated from registry payload via `.get(...,"")`):** on a registry hit the refs
> come from `_decode_data_ready_payload(result.payload_json).get("data_architecture_ref","")` /
> `.get("data_migration_plan_ref","")` (`:1556-1561`,`:1596-1601`). The in-memory signal handler hydrates
> the SAME two vars from the signal payload (part 1, `:496-497`). Either path leaves the vars in the same
> shape so `_build_evidence_data` / `_create_gate_pr_architecture` see consistent refs. A rebuild must use
> these exact dict keys.
> ⚠️ **GOTCHA-WDR7 (rework re-wait is a no-op):** `_data_ready` is set `True` once and never reset, so on a
> G-02 rework loop the step-5 wait returns immediately (the rework loop in part 1 deliberately excludes
> `data-architecture` from re-running, `:1233-1241`). A rebuild must NOT reset `_data_ready` on rework.

---

## 6. `_provision_target_repo_for_this_run(self, input, target_app_id) -> None` — `architecture.py:1625-1734`  (NEW)

Provision the per-target modernization repo (W19 repo-split). Best-effort: failures log a warning and the
line continues with `_target_repo_url=""`.

```text
async def _provision_target_repo_for_this_run(self, input, target_app_id):
    # ── reuse a caller-supplied URL ──
    passed_url = getattr(input, "target_repo_url", "") or ""               # :1650
    if passed_url:                              # BRANCH 1                  :1651
        self._target_repo_url = passed_url                                 # :1652
        workflow.logger.info("target repo pre-provisioned by caller", ...) # :1653-1656
        return                                                             # :1657

    # ── derive owner from artifact_repo (owner/name or full URL) ──
    artifact_repo = getattr(input, "artifact_repo", "") or ""              # :1673
    owner = ""                                                             # :1674
    if "/" in artifact_repo:                    # BRANCH 2                  :1675
        owner = artifact_repo.split("/", 1)[0]                             # :1676
        for scheme in ("https:", "http:"):      # LOOP                     :1678
            if owner.startswith(scheme):        # BRANCH 3                  :1679
                parts = artifact_repo.split("/")                           # :1680
                if len(parts) >= 4:             # BRANCH 4                  :1681
                    owner = parts[3]                                       # :1682
                break                                                      # :1683

    if not owner:                               # BRANCH 5                 :1685
        workflow.logger.warning("target-repo provisioning skipped — cannot derive owner ...", ...)  # :1686-1693
        return                                                             # :1694

    # ── friendly slug from app_name, else opaque fallback ──
    friendly_slug = slugify_target_name(getattr(input, "app_name", "") or "")   # :1696-1698
    if friendly_slug:                           # BRANCH 6                  :1699
        name = friendly_slug                                               # :1700
    else:                                                                  # :1701
        name = f"olympus-target-{target_app_id[:8]}"                       # :1702
    slug = f"{owner}/{name}"                                               # :1703
    readme = self._render_target_repo_readme(input, target_app_id)         # :1704

    # ── provision (best-effort) ──
    try:
        result = await workflow.execute_activity(
            provision_target_repo,
            ProvisionTargetRepoInput(
                target_app_id=target_app_id, repo_slug=slug,
                initial_readme=readme, private=True),                      # :1709-1714
            start_to_close_timeout=timedelta(seconds=120),                 # :1715
            retry_policy=RETRY_POLICIES["transient"],                      # :1716
            activity_id="provision-target-repo")                           # :1717
        self._target_repo_url = result.target_repo_url                     # :1719
        workflow.logger.info("target repo provisioned", ...)               # :1720-1728
    except Exception as exc:                    # BRANCH 7 — best-effort    :1729
        workflow.logger.warning(
            "target-repo provisioning failed; continuing without "
            "target_repo_url on application row: %s", exc)                 # :1730-1734
```

**Branch inventory (7):** `if passed_url` (`:1651`); `if "/" in artifact_repo` (`:1675`); `for scheme in
(...)` (`:1678`); `if owner.startswith(scheme)` (`:1679`); `if len(parts) >= 4` (`:1681`); `if not owner`
(`:1685`); `if friendly_slug ... else` (`:1699-1702`); `except Exception` (`:1729`).

**Activity calls:** `provision_target_repo` — `ProvisionTargetRepoInput(target_app_id, repo_slug=slug,
initial_readme=readme, private=True)`; **120s**; `transient`; `activity_id="provision-target-repo"`.
**Best-effort** (try/except, never fatal).

> ⚠️ **GOTCHA-PTR1 (caller-supplied URL wins; activity is idempotent on slug for rework):** if the wave
> coordinator (or upstream `AppWorkflow`) already populated `input.target_repo_url`, it's reused verbatim
> and NO activity fires (`:1650-1657`). Otherwise `provision_target_repo` is idempotent on slug, so a G-02
> rework re-running `run` reuses the existing repo (`:1633-1636`). A rebuild must short-circuit on
> `passed_url` BEFORE deriving a slug.
> ⚠️ **GOTCHA-PTR2 (owner extraction handles both `owner/name` and full URLs):** `owner =
> artifact_repo.split("/",1)[0]` (`:1676`), but if that starts with `https:`/`http:` it re-splits and takes
> `parts[3]` (the host-relative owner segment) only if `len(parts)>=4` (`:1678-1683`). A rebuild must
> reproduce both forms — passing a full `https://github.com/owner/repo` URL must still yield `owner`.
> ⚠️ **GOTCHA-PTR3 (friendly slug vs opaque fallback):** `slugify_target_name(input.app_name)` produces
> e.g. `"S1 Unified Pilot Identity"` → `"s1-unified-pilot-identity"`; if it returns `""` (whitespace/
> punctuation-only name) the fallback is `f"olympus-target-{target_app_id[:8]}"` (`:1699-1702`). The slug
> is `f"{owner}/{name}"`. A rebuild must use `slugify_target_name` and fall back to the opaque 8-char-prefix
> form on empty.
> ⚠️ **GOTCHA-PTR4 (provisioning failure is non-fatal — empty `_target_repo_url`):** on any provision
> exception the warning is logged and the method returns WITHOUT raising (`:1729-1734`); `_target_repo_url`
> stays `""`. Downstream effects: `_run_agent_step` skips mirroring (GOTCHA-RAS2), `_fire_target_provisioned_signal`
> publishes `target_repo_url=""`, and the G-02 projection writes an empty URL (`:1644-1647`). A rebuild MUST
> swallow provisioning errors — a Git-provider blip must not fail the whole Architecture line.
> ⚠️ **GOTCHA-PTR5 (called from `run` BEFORE the step loop):** `run` (part 1, `:548`) calls this BEFORE
> `_execute_architecture`, so the target repo exists before step 1's commit. A rebuild must provision up
> front, not lazily at the first `write_to_target` step.

---

## 7. `_render_target_repo_readme(input, target_app_id) -> str` — `architecture.py:1736-1762`  (NEW, `@staticmethod`)

```text
@staticmethod
def _render_target_repo_readme(input, target_app_id):
    disposition = ""                                                       # :1746
    disp_attr = getattr(input, "disposition", None)                        # :1747
    if disp_attr is not None:                   # BRANCH 1                  :1748
        disposition = getattr(disp_attr, "value", str(disp_attr))          # :1749  (enum.value or str)
    return (
        f"# Olympus Target — {input.app_name}\n\n"
        f"**Target application id:** `{target_app_id}`\n"
        f"**Portfolio:** `{input.portfolio_id}`\n"
        f"**Wave:** `{input.wave_id}`\n"
        f"**Disposition:** {disposition or 'unknown'}\n\n"                 # BRANCH 2 (`or 'unknown'`)  :1755
        "This repository holds all self-contained artifacts about the target "
        "application — Architecture design docs, Data architecture, Modernization "
        "specs/designs/generated code, and renditions. Provisioned by Olympus "
        "Architecture's `target-state-mapping` step under the W19 repo-split rule "
        "(2026-05-02).\n")                                                 # :1750-1762
```

**Branch inventory (2):** `if disp_attr is not None` (`:1748`); `disposition or 'unknown'` (`:1755`).

- **`@staticmethod`** — no `self`. Pure string build, deterministic, no `workflow.now()`.

> ⚠️ **GOTCHA-RDR1 (disposition normalized to enum `.value` or `str`):** handles both a `Disposition` enum
> member (`.value`) and a raw string (`str(disp_attr)`) via `getattr(disp_attr, "value", str(disp_attr))`
> (`:1749`); empty/None renders as `"unknown"` (`:1755`). A rebuild must reproduce this dual-mode read.

---

## B. (cont.) `_fire_target_provisioned_signal(self, input, target_app_id) -> None` — `architecture.py:1764-1913`  (NEW) ★ CORE

Publish `TargetProvisionedSignal` to the arch-data registry so the peer Data workflow can poll it; under
the signal-first patch ALSO fire a best-effort Temporal signal at the peer for fast wake-up. **Two
patch-gated top-level branches** (registry path vs legacy direct-signal path).

```text
async def _fire_target_provisioned_signal(self, input, target_app_id):
    # ── normalize disposition to string ──
    disposition_str = ""                                                   # :1786
    if getattr(input, "disposition", None) is not None:    # BRANCH 1       :1787
        disposition_str = getattr(input.disposition, "value", str(input.disposition))  # :1790

    payload = TargetProvisionedSignal(                                     # :1792-1810
        target_app_id=target_app_id,
        portfolio_id=input.portfolio_id,
        architecture_workflow_id=workflow.info().workflow_id,
        wave_id=input.wave_id,
        disposition=disposition_str,
        target_repo_url=self._target_repo_url,                             # :1801
        target_service_id=getattr(input, "target_service_id", "") or "",   # :1807
        relationship=getattr(input, "relationship", "") or "",             # :1808
        source_app_ids=list(getattr(input, "source_app_ids", []) or []))   # :1809

    # ╔═══ BRANCH 2 — registry path (arch-data-registry-v1) ═══╗
    if workflow.patched("arch-data-registry-v1"):                          # :1812
        if not input.wave_id:                   # BRANCH 3 — no wave_id     :1816
            workflow.logger.info("target-provisioned publish skipped — no wave_id on input")  # :1817-1819
            return                                                         # :1820
        try:
            await workflow.execute_activity(
                publish_arch_data_signal,
                PublishArchDataSignalInput(
                    signal_type=SIGNAL_TARGET_PROVISIONED,                 # :1825  ("target_provisioned")
                    wave_id=input.wave_id, target_app_id=target_app_id,
                    payload_json=_encode_target_provisioned_payload(payload)),  # :1828
                start_to_close_timeout=timedelta(seconds=30),              # :1830
                retry_policy=RETRY_POLICIES["transient"],                  # :1831
                activity_id="publish-target-provisioned")                  # :1832
            # Structured signal-observability trace (PR #494). The
            # `peer_workflow_id` field is computed by an inline ternary —
            # ⚠️ GOTCHA-FTP8 (observability-only — NOT load-bearing for parity).
            workflow.logger.info(                                          # :1838-1855  (structured trace)
                "arch_data_signal_fired",
                extra={
                    "signal_kind": "target_provisioned",
                    "wave_id": input.wave_id,
                    "target_app_id": target_app_id,
                    "target_service_id": (self._target_service_id or ""),  # :1844-1846
                    "relationship": (getattr(input, "relationship", "") or ""),  # :1847-1849
                    "peer_workflow_id": (                                  # :1850-1853  ⚠️ GOTCHA-FTP8 (observability-only)
                        (input.peer_workflow_ids or {}).get("Data", "")
                        if hasattr(input, "peer_workflow_ids") else ""),   # :1852  ← inline ternary (12th branch)
                })
        except Exception as exc:                 # BRANCH 4 — best-effort    :1856
            workflow.logger.warning("target-provisioned registry publish failed: %s", exc)  # :1857-1859

        # ── nested: signal-first fast-path Temporal signal ──
        if workflow.patched("arch-data-signal-first-v1"):  # BRANCH 5       :1870
            data_wf_id = ""                                                # :1871
            try:
                data_wf_id = input.peer_workflow_ids.get("Data", "")       # :1873
            except AttributeError:               # BRANCH 6                 :1874
                data_wf_id = ""                                            # :1875
            if data_wf_id:                       # BRANCH 7                 :1876
                try:
                    handle = workflow.get_external_workflow_handle(data_wf_id)   # :1878-1880
                    await handle.signal("target_provisioned", payload)     # :1881
                except Exception as exc:          # BRANCH 8 — best-effort   :1882
                    workflow.logger.info(
                        "target-provisioned fast-path signal failed "
                        "(DB backstop will catch it): %s", exc)            # :1883-1887
        return                                                             # :1888

    # ╔═══ legacy direct-signal path (pre-arch-data-registry-v1) ═══╗
    data_wf_id = ""                                                        # :1892
    try:
        data_wf_id = input.peer_workflow_ids.get("Data", "")              # :1894
    except AttributeError:                       # BRANCH 9                 :1893→1895
        data_wf_id = ""                                                    # :1896
    if not data_wf_id:                           # BRANCH 10                :1898
        workflow.logger.info("target-provisioned signal skipped — no peer Data workflow id on input")  # :1899-1903
        return                                                             # :1903
    try:
        handle = workflow.get_external_workflow_handle(data_wf_id)         # :1906
        await handle.signal("target_provisioned", payload)                # :1907
    except Exception as exc:                     # BRANCH 11 — best-effort   :1908
        workflow.logger.warning(
            "target-provisioned signal failed — Data workflow may not yet "
            "be started: %s", exc)                                         # :1909-1913
```

**Branch inventory (12):** `if disposition not None` (`:1787`); `if patched(registry)` (`:1812`); `if not
input.wave_id` (`:1816`); registry-publish `except` (`:1856`); `if patched(signal-first)` (`:1870`);
peer-id `except AttributeError` (`:1874`); `if data_wf_id` (`:1876`); fast-path signal `except` (`:1882`);
legacy peer-id `except AttributeError` (`:1893`); legacy `if not data_wf_id` (`:1898`); legacy signal
`except` (`:1908`); **`peer_workflow_id` log-field ternary (`:1852`)** — `(input.peer_workflow_ids or
{}).get("Data","") if hasattr(input,"peer_workflow_ids") else ""`; **observability-only**, decides the
logged peer-id vs the empty string when `input` lacks `peer_workflow_ids`; **no control-flow effect** (does
not gate any signal, activity dispatch, gate routing, or determinism) — GOTCHA-FTP8.

**Module helper consumed:** `_encode_target_provisioned_payload(payload)` (`architecture.py:148-172`):
`json.dumps` over a dict literal with keys `target_app_id`, `portfolio_id`, `architecture_workflow_id`,
`wave_id`, `disposition`, `target_repo_url`, plus W19 fields `target_service_id` /`relationship`
(`getattr(...,"") or ""`) and `source_app_ids` (`list(getattr(...,[]) or [])`). Activity schema is
primitive strings only.

**Activity calls (in order, registry path):**
1. `publish_arch_data_signal` — `PublishArchDataSignalInput(signal_type=SIGNAL_TARGET_PROVISIONED, wave_id,
   target_app_id, payload_json=_encode_target_provisioned_payload(payload))`; **30s**; `transient`;
   `activity_id="publish-target-provisioned"`. **Best-effort** (try/except).
2. *(signal-first nested)* `workflow.get_external_workflow_handle(data_wf_id).signal("target_provisioned",
   payload)` — a Temporal cross-workflow signal (NOT an activity), best-effort.

**Cross-workflow signal (legacy path):** `get_external_workflow_handle(data_wf_id).signal(
"target_provisioned", payload)`, best-effort.

> ⚠️ **GOTCHA-FTP1 (TWO top-level patch branches; the legacy path uses NO registry):** `if patched(
> "arch-data-registry-v1")` (`:1812`) routes the modern registry publish; the trailing `else`-by-fallthrough
> (`:1890-1913`) is the legacy direct-`signal_external_workflow` path retained for replay determinism of
> pre-patch histories. A rebuild MUST keep BOTH and gate on the EXACT patch string.
> ⚠️ **GOTCHA-FTP2 (signal-first is a NESTED patch INSIDE the registry branch):** `if patched(
> "arch-data-signal-first-v1")` (`:1870`) is nested under the registry branch — it fires the fast-path
> Temporal signal AT the peer Data workflow IN ADDITION to the registry publish. The registry publish is the
> source of truth; the signal is just an accelerator so Data's `_wait_for_target_provisioned` exits its
> 5-min DB-backstop immediately (`:1860-1869`). If the peer hasn't started yet (early producer) the signal
> is silently dropped and Data's first backstop read finds the row. A rebuild must keep the registry publish
> unconditional within the branch and the signal nested + best-effort.
> ⚠️ **GOTCHA-FTP3 (registry publish skipped when `wave_id` empty):** `if not input.wave_id: return`
> (`:1816-1820`) — the registry key requires a UUID wave_id; standalone/unit-test runs without one skip the
> publish entirely. A rebuild must guard before `publish_arch_data_signal`.
> ⚠️ **GOTCHA-FTP4 (peer-id read is defensively `getattr`/try-except'd TWICE):** both the signal-first
> nested block (`:1872-1875`) and the legacy path (`:1893-1896`) read `input.peer_workflow_ids.get("Data","")`
> inside `try/except AttributeError` so a `LineWorkflowInput` lacking `peer_workflow_ids` doesn't raise. A
> rebuild must keep the AttributeError guard on both reads.
> ⚠️ **GOTCHA-FTP5 (everything here is best-effort — no failure aborts the line):** all three activity/signal
> sites are in try/except that log-and-continue (`:1856`,`:1882`,`:1908`). The whole method is called from
> `run` (part 1) right after step 1 and any failure must not fail the Architecture line — Data's poll/backstop
> is the durable channel. A rebuild MUST NOT propagate any exception from this method.
> ⚠️ **GOTCHA-FTP6 (payload carries `_target_repo_url` snapshotted post-provision):** `payload.target_repo_url
> = self._target_repo_url` (`:1801`) is read AFTER `_provision_target_repo_for_this_run` ran in `run`, so Data
> learns the target repo URL. If provisioning failed it's `""` and Data falls back to `artifact_repo`. A
> rebuild must populate the payload AFTER provisioning.
> ⚠️ **GOTCHA-FTP7 (wire signal name is literal `"target_provisioned"`):** both the fast-path (`:1881`) and
> legacy (`:1907`) signal sends use the literal method name `"target_provisioned"` — this MUST match the
> Data workflow's `@workflow.signal target_provisioned` handler name and the registry `SIGNAL_TARGET_PROVISIONED`
> constant (`= "target_provisioned"`). A rebuild must not rename.
> ⚠️ **GOTCHA-FTP8 (observability-only — `peer_workflow_id` log-field ternary, NOT load-bearing for parity):**
> the `arch_data_signal_fired` structured-log `extra={...}` dict computes its `peer_workflow_id` field via an
> inline ternary `(input.peer_workflow_ids or {}).get("Data","") if hasattr(input,"peer_workflow_ids") else ""`
> (`:1850-1853`, decision at `:1852`). When `input` carries `peer_workflow_ids` the field logs the peer Data
> workflow id (or `""` if the `"Data"` key is absent); when the attribute is missing it logs `""`. This is a
> 12th decision point in the method, but it ONLY affects what the trace line shows — it has ZERO effect on
> control flow, signal sends, activity dispatch, gate routing, or determinism. The actual fast-path signal
> target is resolved independently at `:1873` (the `try/except AttributeError` peer-id read), NOT from this log
> ternary. A rebuild may render the field however it likes (or omit the log entirely) without diverging on
> behavioral parity — it is documented here only for completeness of the branch inventory.

---

## C. OVERRIDE — `_build_evidence_data(...)` — `architecture.py:2041-2110`

**OVERRIDES `LineWorkflowBase._build_evidence_data` (`base.py:987-1053`).** Keeps the keyword signature
(`include_content=False`, `content_paths=None`) so `_submit_gate_evidence` (base) still drives the
slim/enriched two-call contract. Differences: skips `kind=="code"` steps, hard-codes
`assembly_line="Architecture"`, appends a `data_architecture` ref block, iterates
`ARCHITECTURE_STEPS.items()` directly (NOT `_evidence_steps_iter()`).

```text
def _build_evidence_data(self, app_id, assembly_line="Architecture", step="",
                         *, include_content=False, content_paths=None) -> dict[str, Any]:
    steps = {}                                                             # :2063
    for step_name, step_def in ARCHITECTURE_STEPS.items():    # LOOP        :2064
        if step_def.get("kind") == "code":      # BRANCH 1 — skip code-kind  :2065
            continue                                                       # :2067  (data-architecture)
        artifacts = self._step_results.get(step_name, [])                  # :2068
        if not artifacts:                        # BRANCH 2 — skip unrun     :2069
            continue                                                       # :2070
        metadata = self._agent_metadata.get(step_name, {})                 # :2071
        output_files = metadata.get("output_files", [])                    # :2072
        raw_file_artifacts = []                                            # :2073
        for f in output_files:                   # LOOP                     :2074
            if not isinstance(f, OutputFile):    # BRANCH 3 — skip non-OutputFile  :2075
                continue                                                   # :2076
            content_str = f.content if isinstance(f.content, str) else ""  # BRANCH 4 (ternary)  :2077
            entry = {
                "path": f.path,
                "encoding": f.encoding,
                "size": len(content_str.encode("utf-8")) if content_str else 0,  # BRANCH 5 (ternary)  :2081
            }
            if include_content or (content_paths is not None and f.path in content_paths):  # BRANCH 6  :2083-2085
                entry["content"] = f.content                               # :2086
            raw_file_artifacts.append(entry)                               # :2087
        deduped_file_artifacts = list(
            {f["path"]: f for f in raw_file_artifacts}.values())           # :2088-2090  (dedup by path, last-wins)
        steps[step_name] = {
            "title": step_def.get("title", step_name),                     # :2092  BRANCH 7 (.get default)
            "skill_id": step_def["skill_id"],                              # :2093
            "artifact": step_def["artifact"],                              # :2094
            "output": artifacts[0] if artifacts else "",                   # :2095  BRANCH 8 (ternary)
            "metadata": {k: v for k, v in metadata.items() if k != "output_files"},  # :2096-2098
            "file_artifacts": deduped_file_artifacts,                      # :2099
        }
    return {                                                               # :2101-2110
        "assembly_line": "Architecture",                                   # :2102  ← HARD-CODED (ignores arg)
        "app_id": app_id,
        "step_count": len(steps),                                          # :2104  ← NEW key vs base
        "steps": steps,
        "data_architecture": {                                             # :2106-2109  ← NEW block vs base
            "architecture_ref": self._data_architecture_ref,
            "migration_plan_ref": self._data_migration_plan_ref,
        },
    }
```

**Branch inventory (8):** `for step_name … in ARCHITECTURE_STEPS.items()` (`:2064`); `if step_def.get("kind")
== "code": continue` (`:2065`); `if not artifacts: continue` (`:2069`); `for f in output_files` (`:2074`);
`if not isinstance(f, OutputFile): continue` (`:2075`); `content_str = ... if isinstance(...) else ""`
ternary (`:2077`); `"size": ... if content_str else 0` ternary (`:2081`); `if include_content or
(content_paths is not None and f.path in content_paths)` (`:2083`); `"title": step_def.get("title",
step_name)` (`:2092`); `"output": artifacts[0] if artifacts else ""` (`:2095`).

### C.1 How this override DIFFERS from base `_build_evidence_data`

| Aspect | Base (`base.py:987-1053`) | This override (`architecture.py:2041-2110`) |
|---|---|---|
| step iteration | `self._evidence_steps_iter()` (hook, `:1015`) | direct `ARCHITECTURE_STEPS.items()` (`:2064`) — does NOT use the hook |
| `kind=="code"` skip | none | **skips** `data-architecture` (`:2065-2067`) |
| skip-when-no-artifacts | none (always emits step) | **skips** steps with empty `_step_results` (`:2069-2070`) |
| per-step metadata | `**self._evidence_step_metadata(...)` (hook, `:1040`) | inline `title`/`skill_id`/`artifact` (`:2092-2094`) — does NOT use the hook |
| `assembly_line` | the `assembly_line` ARG (`:1049`) | **hard-coded** `"Architecture"` (`:2102`) — ignores the arg |
| `current_step` key | `step` arg (`:1051`) | **absent** — replaced by `step_count` (`:2104`) |
| `data_architecture` block | absent | **added** with `_data_architecture_ref` + `_data_migration_plan_ref` (`:2106-2109`) |
| slim default / size / dedup / content-paths | same semantics | **same** (GOTCHA-BE1..5 still hold) |

> ⚠️ **GOTCHA-BE-OVR1 (`assembly_line` arg is ACCEPTED but IGNORED — always `"Architecture"`):** the method
> takes `assembly_line="Architecture"` and `_submit_gate_evidence` passes `"Architecture"` anyway, but even
> if a caller passed something else, line `:2102` hard-codes `"Architecture"` in the returned dict. A rebuild
> must hard-code the value, matching this.
> ⚠️ **GOTCHA-BE-OVR2 (`step` arg is ACCEPTED but UNUSED):** base puts `"current_step": step` in the bundle;
> this override drops it and emits `"step_count": len(steps)` instead (`:2104`). The `step` parameter is dead
> on this path. A rebuild keeps the parameter (signature parity for the base caller) but does not use it.
> ⚠️ **GOTCHA-BE-OVR3 (data-architecture is tracked SEPARATELY, never as a step entry):** `data-architecture`
> (`kind=code`) is filtered out of `steps` (`:2065`) and instead surfaced as the top-level `data_architecture`
> ref block (`:2106-2109`). Its artifact refs live in `_step_committed_paths["data-architecture"]` (set by
> part 1, `:907-910`) and flow into `artifact_paths` via `_collect_committed_paths`, but NOT into the per-step
> evidence map. A rebuild must keep these two surfaces distinct.
> ⚠️ **GOTCHA-BE-OVR4 (slim/enriched two-call contract preserved):** because the signature keeps
> `include_content` / `content_paths`, the base `_submit_gate_evidence` (`base.py:661`,`:685`) still calls this
> twice — once slim for `submit_gate_evidence`, once with `content_paths=needed_paths` for
> `check_gate_criteria` when G-02 has thresholds. A rebuild MUST preserve the keyword-only `*` separator and
> both params, or the base caller's enriched call breaks.

---

## 8. `_collect_committed_paths(self) -> list[str]` — `architecture.py:2112-2117`  (NEW)

```text
def _collect_committed_paths(self):
    paths = []                                                             # :2114
    for step_name in ARCHITECTURE_STEPS:        # LOOP                      :2115
        paths.extend(self._step_committed_paths.get(step_name, []))        # :2116
    return dedup_paths(paths)                                              # :2117
```

**Branch inventory (1):** the `for step_name in ARCHITECTURE_STEPS` loop (`:2115`).

- Iterates `ARCHITECTURE_STEPS` **insertion order** (dict order), extends `paths` with each step's committed
  list, dedups via `utils.dedup_paths` (order-preserving first-seen dedup).

> ⚠️ **GOTCHA-CCP1 (iteration order = `ARCHITECTURE_STEPS` declaration order, dedup is order-preserving):**
> the returned list reflects the step-declaration order in `ARCHITECTURE_STEPS` (part 1, `:200-319`), then
> `dedup_paths` keeps first occurrences. This ordering feeds `prior_inputs` (the next step's
> `input_artifacts`) and `artifact_paths` (the gate evidence). A rebuild MUST iterate the SAME dict in the
> SAME order and dedup first-seen — a different order changes the input_artifacts list a downstream agent
> sees and could change agent output (and thus history).
> ⚠️ **GOTCHA-CCP2 (includes `data-architecture` refs):** unlike `_build_evidence_data` (which skips
> code-kind steps), `_collect_committed_paths` includes `_step_committed_paths["data-architecture"]` if set
> — those are the Data-line refs the part-1 step-5 block stored (`:907-910`). So data refs DO appear in
> `prior_inputs` / `artifact_paths` even though they're not a step evidence entry. A rebuild must NOT filter
> code-kind here.

---

## D. `_create_gate_pr_architecture(self, repo, branch, app_id, input)` — `architecture.py:2119-2198`  (NEW)

Build the G-02 review PR with a line-specific body, then call `create_pr` directly. **Does NOT call the
base `_create_gate_pr`** — it constructs its own `CreatePRInput` and fires the activity itself.

```text
async def _create_gate_pr_architecture(self, repo, branch, app_id, input):
    # ── steps_run: agent-kind steps that have results ──
    steps_run = [
        name for name, step_def in ARCHITECTURE_STEPS.items()
        if step_def.get("kind") == "agent" and name in self._step_results  # :2127-2131  (comp w/ AND guard)
    ]
    pr_body = (
        f"## Gate G-02 Review: Architecture Alignment — {app_id}\n\n"
        f"**Target application:** `{app_id}`\n")                           # :2132-2135

    # ── risk-tier annotation ──
    if self._risk_tier is not None:              # BRANCH 1                 :2136
        pr_body += f"**Risk tier:** {self._risk_tier}\n"                   # :2137
        if self._risk_tier == 1:                 # BRANCH 2                 :2138
            pr_body += ('\n> **Tier-1:** Approval requires PM merge **AND** '
                        '`scope="g-02-ea"` stakeholder signal **AND** '
                        '`scope="g-02-security"` stakeholder signal.\n')   # :2139-2144

    pr_body += "\n### Architecture Steps Completed\n"                      # :2145
    for step_name in steps_run:                  # LOOP                     :2146
        step_def = ARCHITECTURE_STEPS[step_name]                           # :2147
        pr_body += f"- [x] {step_name} (`{step_def['skill_id']}`)\n"       # :2148-2151

    if self._data_architecture_ref:              # BRANCH 3                 :2152
        pr_body += "- [x] data-architecture (handshake from Data line)\n"  # :2153-2155

    pr_body += "\n### Artifacts\n"                                         # :2156
    for step_name in steps_run:                  # LOOP                     :2157
        step_def = ARCHITECTURE_STEPS[step_name]                           # :2158
        pr_body += f"- `architecture/{app_id}/{step_def['artifact']}`\n"   # :2159-2161

    if self._data_architecture_ref:              # BRANCH 4                 :2162
        pr_body += f"- `{self._data_architecture_ref}`\n"                  # :2163
        pr_body += f"- `{self._data_migration_plan_ref}`\n"               # :2164

    pr_body += ("\n### EA Review Board Checklist\n"
                "- [ ] Target identity correct (Replace / Consolidate reviewed)\n"
                "- [ ] Cloud pattern aligns with enterprise standards\n"
                ... 9 checklist lines ...
                "- [ ] Blueprint actionable for Modernization\n")          # :2165-2176

    rework_iter = self._rework_count("G-02")                               # :2177  (base helper)
    if rework_iter > 0:                          # BRANCH 5                 :2178
        pr_body += f"\n**Rework iteration:** {rework_iter}\n"              # :2179

    pr_input = CreatePRInput(
        repo=repo, source_branch=branch, target_branch="main",            # :2182-2184
        title=f"Gate G-02: Architecture Alignment Review — {app_id}",     # :2185
        body=pr_body,
        labels=["gate-review", "architecture", "G-02"],                    # :2187
        execution_context=self._execution_ctx("create-g-02-pr", app_id=app_id))  # :2188-2191
    return await workflow.execute_activity(
        create_pr, pr_input,
        start_to_close_timeout=timedelta(seconds=60),                      # :2196
        retry_policy=RETRY_POLICIES["transient"])                         # :2197
```

**Branch inventory (7):** the `steps_run` comprehension `if kind=="agent" and name in _step_results`
(`:2127-2131`); `if self._risk_tier is not None` (`:2136`); `if self._risk_tier == 1` (`:2138`); the first
`for step_name in steps_run` (`:2146`); `if self._data_architecture_ref` (`:2152`); the second `for
step_name in steps_run` (`:2157`); `if self._data_architecture_ref` (`:2162`); `if rework_iter > 0` (`:2178`).

**Activity calls:** `create_pr` — `CreatePRInput(repo, source_branch=branch, target_branch="main",
title=..., body=pr_body, labels=["gate-review","architecture","G-02"], execution_context=...)`; **60s**;
`transient`. Returns `CreatePRResult` (`pr_number`, `pr_url`, …). Called by `_execute_architecture` (part 1,
`:1061`) — the result's `pr_url` feeds the gate record + evidence, and `pr_number` feeds the merge loop.

> ⚠️ **GOTCHA-CGP1 (bypasses base `_create_gate_pr` — but produces an identical label set):** this builds
> `CreatePRInput` itself rather than calling `base._create_gate_pr` (`base.py:600-627`). The labels
> `["gate-review", "architecture", "G-02"]` (`:2187`) MATCH what the base would emit
> (`["gate-review", ARTIFACT_ROOT, gate_type]` with `ARTIFACT_ROOT="architecture"`), and the
> `execution_context` step-id is `"create-g-02-pr"` (`:2188`) — note this is the LITERAL step id, whereas
> base derives `f"create-{gate_type.lower()}-pr"` (= `"create-g-02-pr"`, same value). A rebuild may inline
> `create_pr` here; it must reproduce the exact labels, title, and the literal `"create-g-02-pr"` exec-ctx id.
> ⚠️ **GOTCHA-CGP2 (`steps_run` filters to agent-kind WITH results — order = declaration order):** the body's
> "Steps Completed" + "Artifacts" sections iterate `steps_run`, which is `[name for name,def in
> ARCHITECTURE_STEPS.items() if def.kind=="agent" and name in _step_results]` (`:2127-2131`). This EXCLUDES
> `data-architecture` (kind=code) and any agent step that didn't run (e.g. system-umbrella skips). The
> data-architecture handshake is appended separately ONLY if `_data_architecture_ref` is truthy (`:2152`,
> `:2162`). A rebuild must filter on BOTH `kind=="agent"` AND `name in self._step_results`.
> ⚠️ **GOTCHA-CGP3 (Tier-1 PR-body annotation describes the triple-signal rule):** when `_risk_tier==1` the
> body inserts the Tier-1 note requiring PM merge AND `scope="g-02-ea"` AND `scope="g-02-security"`
> stakeholder signals (`:2138-2144`). This is purely advisory text for reviewers — the ACTUAL enforcement is
> the `wait_condition` in `_execute_architecture` (part 1, `:1119-1131`). A rebuild must emit this text only
> for tier 1.
> ⚠️ **GOTCHA-CGP4 (rework-iteration footer driven by `_rework_count("G-02")`):** `rework_iter =
> self._rework_count("G-02")` (`:2177`) reads the base counter; the footer is appended only when `>0`
> (`:2178-2179`). On the first G-02 attempt it's 0 (no footer); after the part-1 rework loop calls
> `_bump_rework("G-02")` it shows the count. A rebuild must read the SAME gate key `"G-02"`.
> ⚠️ **GOTCHA-CGP5 (two `_data_architecture_ref` checks, both gate the SAME ref):** the data handshake line
> in "Steps Completed" (`:2152`) and the data refs in "Artifacts" (`:2162-2164`) are BOTH gated on
> `if self._data_architecture_ref` (truthiness). For the system-umbrella (where Data fires with empty refs)
> both are skipped. A rebuild must gate both sections on the same non-empty-ref check.

---

## E. RESILIENCE summary (this scope)

- **Timeouts (start_to_close):**
  - `read_artifact` (plan): **30s** (`:1318`).
  - `dispatch_agent_task`: **3h** for {target-state-mapping, blueprint-assembly, cloud-pattern-selection,
    ea-compliance}, else **1h** (`:2019-2022`); **`heartbeat_timeout=2m`** (`:2027`).
  - `consume_arch_data_signal`: **30s** (`:1547`,`:1587`).
  - `provision_target_repo`: **120s** (`:1715`).
  - `publish_arch_data_signal`: **30s** (`:1830`).
  - `create_pr`: **60s** (`:2196`).
- **Heartbeats:** only `dispatch_agent_task` (2-min heartbeat timeout, runtime heartbeats every 30s). No
  other activity in this scope heartbeats.
- **Retry policies:** `read_artifact`/`consume_arch_data_signal`/`provision_target_repo`/
  `publish_arch_data_signal`/`create_pr` → `transient` (3 attempts, 1-15s). `dispatch_agent_task` →
  `agent_failure` (3 attempts, 5-60s). No `non_retryable_error_types` set on any activity in THIS scope (the
  merge `git_merge` policy lives in base `_reconcile_and_merge_with_retry_loop`).
- **Non-retryable raises (workflow-level, not policy):** `_derive_target_state_mapping_from_plan` raises
  `ApplicationError(non_retryable=True)` on all four failure modes (`:1301`,`:1323`,`:1334`,`:1347`,`:1362`)
  — these PROPAGATE through `run`'s outer try (part 1) → `_status=FAILED`.
- **Cancellation:** `_wait_for_data_ready` RAISES `RuntimeError` on cancel (all branches) — does NOT return
  cleanly (GOTCHA-WDR4); cancel therefore surfaces as FAILED, not CANCELLED, from this wait.
- **Best-effort (swallowed, never fatal):** `_provision_target_repo_for_this_run` (`:1729`),
  `_fire_target_provisioned_signal` (all sites: `:1856`,`:1882`,`:1908`). The base `_commit_step_artifacts`
  mirror + output-ref patch (invoked via `_run_agent_step`) are also best-effort (base GOTCHA-CSA4).
- **Idempotency / determinism:** deterministic `activity_id`s — `read-arch-target-plan-{target_app_id}`,
  `agent-{step_name}`, `consume-data-ready-for-target`, `provision-target-repo`,
  `publish-target-provisioned`. `provision_target_repo` is idempotent on slug (rework re-uses the repo).
  `consume_arch_data_signal` is idempotent per `workflow_id`. All patch IDs (`arch-data-signal-first-v1`,
  `arch-data-registry-v1`) are load-bearing for replay.
- **No continue-as-new** in this scope. **No compensation/rollback** — failures either propagate (step-1
  derive) or are swallowed (provision / signal).

---

## F. Behavioral parity checklist (this scope — lines 1264-2191)

A rebuilt Architecture step-helper/override block MUST satisfy ALL of the following:

1. **`_dispatch_agent` is an OVERRIDE** with the extra `source_repo` arg threaded into
   `AgentTaskInput.source_repo`; reads rework feedback via the **literal** `self._rework_feedback.get("G-02")`
   (NOT `_rework_gate_key_for_step`); has **NO context-priors** path; routes `blueprint-assembly`'s skill via
   `select_architecture_blueprint_skill(self._disposition)` keeping the declared skill on a `None` return;
   sets `model_preference="tier-2"` for {target-state-mapping, blueprint-assembly, cloud-pattern-selection,
   ea-compliance}; `task_type=f"architecture-{step}"`; `start_to_close=3h` for those four synthesis steps else
   1h; `heartbeat_timeout=2m`; `agent_failure` policy; `activity_id="agent-{step}"`; records the 6-field
   `_agent_metadata[step]`. (GOTCHA-DA-OVR1..5, GOTCHA-RWFB1)
2. **`_build_evidence_data` is an OVERRIDE** keeping the keyword signature (`include_content`,
   `content_paths`) so the base `_submit_gate_evidence` slim/enriched two-call contract works; iterates
   `ARCHITECTURE_STEPS.items()` directly; `continue`s on `kind=="code"` and on empty `_step_results`; skips
   non-`OutputFile`; computes utf-8 `size` always; inlines `content` only when `include_content` or
   `f.path in content_paths`; dedups file_artifacts by path (last-wins); strips `output_files` from per-step
   metadata; returns `assembly_line` **hard-coded** `"Architecture"`, `step_count=len(steps)` (no
   `current_step`), and a `data_architecture` block carrying `_data_architecture_ref` /
   `_data_migration_plan_ref`. (GOTCHA-BE-OVR1..4)
3. `_derive_target_state_mapping_from_plan` raises `ApplicationError(non_retryable=True)` on (a) missing
   `wave_id`/`artifact_repo`, (b) plan read failure, (c) malformed-JSON plan, (d) `target_app_id` not in the
   plan's `targets[]`, (e) `derive_target_application_map_from_plan` `ValueError`. Reads the plan from
   `architecture/wave-{wave_id}/architecture-target-plan.json` on `input.artifact_repo`@`main`
   (`activity_id="read-arch-target-plan-{target_app_id}"`, 30s/`transient`). On success synthesizes an
   `AgentTaskResult` (single `OutputFile` = the derived `target-application-map.json`,
   `model_used="derived-from-plan"`), writes BOTH `_agent_metadata["target-state-mapping"]` (zero cost/tokens)
   and `_step_results["target-state-mapping"]`, then calls base `_commit_step_artifacts`. NO agent dispatch.
   (GOTCHA-DTS1..5)
4. `_run_agent_step` sets the step, calls the overridden `_dispatch_agent` (with `source_repo`), stores
   `_step_results[step]=result.output_artifacts`, and commits only when `step_def.get("artifact")`; mirrors to
   `_target_repo_url` under `docs/architecture/{step}` ONLY when `write_to_target` AND `_target_repo_url`
   non-empty. `_set_step` is called with the CURRENT `_progress_pct` (increment is the caller's job).
   (GOTCHA-RAS1..3)
5. `_run_agent_step_task` returns the **un-awaited** coroutine from `_run_agent_step`, forwarding
   `prior_inputs` verbatim (no internal `_collect_committed_paths`). (GOTCHA-RAST1/2)
6. `_wait_for_data_ready` has THREE patch-gated branches in order: `if patched("arch-data-signal-first-v1")`
   (signal-first, 5-min `_DB_BACKSTOP_INTERVAL_SECONDS` `wait_condition` timeout per iter, ONE
   `consume_arch_data_signal` read per backstop tick, `min()`-clamped last slice, ≤288 iters under the 24h
   `_DATA_READY_WAIT_TIMEOUT_SECONDS` cap) → `elif patched("arch-data-registry-v1")` (15-s
   `_REGISTRY_POLL_INTERVAL_SECONDS` `workflow.sleep` poll) → `else` (legacy in-memory `wait_condition`, no
   timeout). Every branch checks `self._data_ready` first (fast path) and `self.cancelled` (RAISES
   `RuntimeError`, never returns). On a registry hit hydrates `_data_architecture_ref` /
   `_data_migration_plan_ref` from `_decode_data_ready_payload(result.payload_json).get(...,"")`, sets
   `_data_ready=True`, bumps `_updated_at`. Catches `asyncio.TimeoutError` and `pass`es in Branch I only.
   `consume_arch_data_signal` uses `SIGNAL_DATA_READY_FOR_TARGET`, `activity_id="consume-data-ready-for-target"`,
   30s/`transient`. (GOTCHA-WDR1..7)
7. `_provision_target_repo_for_this_run` short-circuits on a caller-supplied `input.target_repo_url`
   (no activity); else derives `owner` from `artifact_repo` (handling both `owner/name` and full URLs via the
   `https:`/`http:` re-split + `len(parts)>=4`), returns early if no owner; builds `name` from
   `slugify_target_name(input.app_name)` else `f"olympus-target-{target_app_id[:8]}"`; calls
   `provision_target_repo` (`ProvisionTargetRepoInput(target_app_id, repo_slug=slug, initial_readme=readme,
   private=True)`, 120s/`transient`, `activity_id="provision-target-repo"`) and sets `_target_repo_url`;
   swallows any provision exception (warns, `_target_repo_url` stays ""). (GOTCHA-PTR1..5)
8. `_render_target_repo_readme` is a `@staticmethod` returning the exact README markdown, normalizing
   disposition to `.value`/`str` and rendering `"unknown"` when empty. (GOTCHA-RDR1)
9. `_fire_target_provisioned_signal` builds a `TargetProvisionedSignal` (with `target_repo_url=
   self._target_repo_url` snapshotted post-provision, plus W19 `target_service_id`/`relationship`/
   `source_app_ids`); under `patched("arch-data-registry-v1")` returns early if `wave_id` empty, else
   best-effort `publish_arch_data_signal` (`SIGNAL_TARGET_PROVISIONED`,
   `payload_json=_encode_target_provisioned_payload(payload)`, 30s/`transient`,
   `activity_id="publish-target-provisioned"`) + structured `arch_data_signal_fired` log; NESTED under
   `patched("arch-data-signal-first-v1")` also best-effort fires `get_external_workflow_handle(
   peer_workflow_ids["Data"]).signal("target_provisioned", payload)`; the legacy fallthrough path (no
   registry) best-effort fires the same cross-workflow signal. Peer-id reads are `try/except AttributeError`
   guarded on BOTH paths. NO failure propagates. (GOTCHA-FTP1..7)
10. `_collect_committed_paths` iterates `ARCHITECTURE_STEPS` in declaration order, extends with each
    `_step_committed_paths.get(step,[])` (INCLUDING `data-architecture`), and returns `dedup_paths(...)`
    (order-preserving first-seen). (GOTCHA-CCP1/2)
11. `_create_gate_pr_architecture` does NOT call base `_create_gate_pr`; builds `CreatePRInput` directly with
    `target_branch="main"`, `title=f"Gate G-02: Architecture Alignment Review — {app_id}"`,
    `labels=["gate-review","architecture","G-02"]`, `execution_context=_execution_ctx("create-g-02-pr",
    app_id=...)`; PR body contains the risk-tier line + Tier-1 triple-signal note (only when `_risk_tier==1`),
    a "Steps Completed" + "Artifacts" section over `steps_run` (agent-kind steps present in `_step_results`),
    a data-architecture line + data refs ONLY when `_data_architecture_ref` is truthy, the 9-line EA checklist,
    and a "Rework iteration: {n}" footer ONLY when `_rework_count("G-02")>0`; fires `create_pr`
    (60s/`transient`). (GOTCHA-CGP1..5)
12. All `workflow.patched(...)` IDs reproduced VERBATIM: `"arch-data-signal-first-v1"`,
    `"arch-data-registry-v1"`. All registry signal-type constants used verbatim:
    `SIGNAL_TARGET_PROVISIONED="target_provisioned"`, `SIGNAL_DATA_READY_FOR_TARGET="data_ready_for_target"`.
    All deterministic `activity_id`s reproduced. Module helpers `_encode_target_provisioned_payload` /
    `_decode_data_ready_payload` behave as specced (primitive-only encode; `{}`-on-failure decode).
13. This scope NEVER redefines the four base gate signals (`gate_approved`/`gate_rejected`/
    `escalation_resolved`/`merge_retry`) or `get_status` (base GOTCHA-SIG0/Q1). It only OVERRIDES
    `_dispatch_agent` + `_build_evidence_data` and adds the nine new helpers above.
