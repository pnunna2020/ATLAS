# DataRouter — `select_data_product_skill` routing module

**Source:** `temporal/olympus_workflows/workflows/data_router.py` (184 lines, whole file)
**Kind:** Pure-Python routing/helper MODULE. **NOT** a `@workflow.defn` class. It has NO Temporal imports, NO signals, NO queries, NO activities, NO state, NO `run()`. It is a deterministic synchronous pure function plus two private helpers and three module-level data tables.
**Mirrors:** `discovery_patterns_router` (tech-fingerprint keyed) and `code_generation_router` (framework keyed). Source docstring `data_router.py:1-33`.

> ⚠️ GOTCHA (architectural constraint): The module is deliberately kept Temporal-free so it can be unit-tested below the workflow boundary (`data_router.py:31-32`). It is imported **inside** a workflow method — see "Where it is called" — NOT at module top of the workflow. A rebuild MUST keep this pure (no `workflow.*`, no `datetime.now()`, no I/O, no randomness): it is invoked from inside a deterministic Temporal workflow context and must itself be deterministic. Given identical input it must always return the identical string.

---

## 0. Why this is in scope for Phase 3 (workflow spec)

`DataWorkflow` (`temporal/olympus_workflows/workflows/data.py`) calls `select_data_product_skill` at `data.py:1459` to pick which `data-product-design-*` skill variant the **Step 5 (`data-product-design`)** agent dispatch uses. The chosen `skill_id` flows directly into `AgentTaskInput.skill_id` (`data.py:1480`), which is the activity argument for `dispatch_agent_task`. So although this file performs no orchestration itself, its return value **selects the activity payload** for one workflow step. A wrong return value silently dispatches the wrong agent skill — a behavioral parity defect invisible to schema checks.

### Where it is called (exact caller contract)

`data.py:127-128` — imported lazily inside the workflow module:
```
from olympus_workflows.workflows.data_router import (
    select_data_product_skill,
)
```

`data.py:1457-1459` — inside the per-step dispatch builder, AFTER `skill_id` is seeded from the step definition:
```
skill_id = step_def["skill_id"]                       # data.py:1457  (default from step def)
if step_name == "data-product-design":                # data.py:1458  ← ONLY this step routes
    skill_id = select_data_product_skill(self._tech_fingerprint)   # data.py:1459 (override)
```
- ⚠️ GOTCHA: the router is consulted for **exactly one** Data-line step name, the literal string `"data-product-design"`. Every other Data step keeps `step_def["skill_id"]` unchanged. A rebuild that calls the router for all steps, or for the wrong step name, breaks parity.
- Argument is `self._tech_fingerprint` — the `DataWorkflow` instance variable populated from `LineWorkflowInput.tech_fingerprint` (`types.py:1174-1183`). It is `dict | None`. When the caller threaded no fingerprint it is `None`, and the router returns the base skill (`data-product-specification`), preserving legacy behavior (`data.py:1454-1456`, `data_router.py:11-13`, `98-102`).
- The returned `skill_id` then goes into `AgentTaskInput(... skill_id=skill_id ...)` at `data.py:1477-1480`.
- Independent of the router result, `data.py:1469-1476` ALSO sets `model_preference="tier-2"` when `step_name in {"migration-planning", "data-product-design", "data-synthesis"}`. This is NOT part of the router — do not fold it in — but a parity rebuild of the *caller* must preserve it. The router's output does not affect `model_preference`.

---

## 1. STATE

This module has **no instance state**. It has three module-level immutable/constant data structures evaluated once at import. Reproduce these EXACTLY — the router's entire behavior is table-driven and a single missing token changes routing.

### 1.1 `MAINFRAME_TOKENS: frozenset[str]` — `data_router.py:42-63`

A `frozenset` of lower-case tokens that mark the source data store as mainframe-family. ⚠️ GOTCHA: the docstring says this "mirrors `discovery_patterns_router.MAINFRAME_TOKENS`" and must stay in lockstep (`data_router.py:38-41`). Exact members (18):

```
{ "natural", "adabas", "cobol", "ims", "vsam", "db2-zos", "db2zos",
  "jcl", "cics", "bms", "copybook", "tn3270", "unisys", "mainframe",
  "broker", "entirex", "infoimage", "ewf" }
```
> Count check: the literal set has 18 string entries (the docstring rounds to "tokens"); reproduce all 18: `natural, adabas, cobol, ims, vsam, db2-zos, db2zos, jcl, cics, bms, copybook, tn3270, unisys, mainframe, broker, entirex, infoimage, ewf`. A regression test (`test_data_router.py:204-218`) pins `natural, adabas, cobol, ims, vsam, db2-zos, cics, copybook` as must-stay members — dropping any fails that test.

### 1.2 `DATA_PRODUCT_DATABASE_MAP: dict[str, str]` — `data_router.py:68-96`

Maps a normalized database token → specialist skill id. Order in dict is irrelevant to correctness (lookup is by key membership) but reproduce all keys. ⚠️ GOTCHA: this map ALSO contains five mainframe data-store keys (`adabas`, `ims`, `vsam`, `db2-zos`, `db2zos`) that point to `data-product-design-mainframe` — these are redundant with the MAINFRAME_TOKENS check (which runs first and wins) but exist for fingerprints that record the data store only in the `database` field (`data_router.py:88-95`). Note `adabas`, `ims`, `vsam`, `db2-zos`, `db2zos` are in BOTH structures.

Exact key → value pairs (19 entries):
```
"oracle"             -> "data-product-design-oracle"
"oracle-plsql"       -> "data-product-design-oracle"
"sqlserver"          -> "data-product-design-sqlserver"
"sql-server"         -> "data-product-design-sqlserver"
"sql server"         -> "data-product-design-sqlserver"   # note: literal space, not hyphen
"mssql"              -> "data-product-design-sqlserver"
"tsql"               -> "data-product-design-sqlserver"
"t-sql"              -> "data-product-design-sqlserver"
"postgres"           -> "data-product-design-postgres"
"postgresql"         -> "data-product-design-postgres"
"aurora-postgres"    -> "data-product-design-postgres"
"aurora-postgresql"  -> "data-product-design-postgres"
"rds-postgres"       -> "data-product-design-postgres"
"rds-postgresql"     -> "data-product-design-postgres"
"adabas"             -> "data-product-design-mainframe"
"ims"                -> "data-product-design-mainframe"
"vsam"               -> "data-product-design-mainframe"
"db2-zos"            -> "data-product-design-mainframe"
"db2zos"             -> "data-product-design-mainframe"
```
> ⚠️ GOTCHA: `db2-for-luw` is intentionally NOT a key — DB2-for-LUW stays on the base until a LUW specialist exists (`data_router.py:79-81`). Do not add it.
> ⚠️ GOTCHA: `"sql server"` has a literal embedded space (not a hyphen). It only matches because `_normalize` lower-cases/strips but does NOT replace internal spaces — so an input `database="SQL Server"` normalizes to `"sql server"` and hits this exact key. Pinned by `test_data_router.py:113-119`.

### 1.3 `DATA_PRODUCT_DEFAULT_SKILL: str` — `data_router.py:102`

```
DATA_PRODUCT_DEFAULT_SKILL = "data-product-specification"
```
The fallback / base skill returned when no specialist fires. This MUST equal the generic skill the Data Step-5 step would otherwise dispatch, so callers without a fingerprint see no behavior change (`data_router.py:98-102`). It is also exported and asserted by tests (`test_data_router.py:21-25,154-166`).

---

## 2. SIGNALS / QUERIES / UPDATES

**NONE.** This module defines no Temporal signal, query, or update handlers. There is nothing here that buffers, mutates, or is consumed by a `wait_condition`. (The "must not be overridden by subclass" rule does not apply — there is no class.) Inherited HIL behavior from `_HILSignalsMixin.md` / `_LineWorkflowBase.md` is irrelevant to this module; it is below the workflow boundary.

---

## 3. CONTROL FLOW — structured pseudocode (every branch reproduced)

There are three functions. Below, each `if`/`elif`/`else`, `for`, ternary, and early `return` is reproduced. Branch-point citations are inline.

### 3.1 `_normalize(value: str | None) -> str` — `data_router.py:105-109`

```
function _normalize(value):
    # BRANCH 1 — data_router.py:107
    if not value:                      # falsy: None OR empty string "" OR (any falsy str)
        return ""                      # early return — data_router.py:108
    return value.strip().lower()       # data_router.py:109 — strip whitespace ends, lower-case
```
- ⚠️ GOTCHA: `not value` is truthy for `None`, `""`, and also `0`/`False`-like — but callers always pass a string or None. An empty-string input yields `""` (not an exception). `.strip()` removes leading/trailing whitespace only; internal spaces are preserved (this is why `"sql server"` survives as a map key — see §1.2).
- Pure transform: lower + strip. No locale, no unicode folding beyond Python's `str.lower()`.

### 3.2 `_fingerprint_tokens(tech_fingerprint: dict | None) -> set[str]` — `data_router.py:112-138`

Flattens a fingerprint into a `set` of normalized tokens, pulling from `languages`, `frameworks`, `platforms`, `tech_stack`, and `tech_family`.

```
function _fingerprint_tokens(tech_fingerprint):
    # BRANCH 2 — data_router.py:121
    if (not tech_fingerprint) or (not isinstance(tech_fingerprint, dict)):
        return set()                                  # early return — data_router.py:122
        # Fires for: None, {} (empty dict is falsy), [], "", or any non-dict type.

    tokens = empty set()                              # data_router.py:123

    # BRANCH 3 — loop over exactly these 4 keys, in THIS order — data_router.py:124
    for key in ("languages", "frameworks", "platforms", "tech_stack"):
        value = tech_fingerprint.get(key)             # data_router.py:125 (None if absent)

        # BRANCH 4 — data_router.py:126
        if isinstance(value, (list, tuple, set)):
            # BRANCH 5 — iterate each element — data_router.py:127
            for item in value:
                # BRANCH 6 — ternary — data_router.py:128
                norm = _normalize(str(item)) if item is not None else ""
                # BRANCH 7 — data_router.py:129
                if norm:
                    tokens.add(norm)                  # data_router.py:130

        # BRANCH 8 — elif (mutually exclusive with the list/tuple/set arm) — data_router.py:131
        elif isinstance(value, str):
            norm = _normalize(value)                  # data_router.py:132
            # BRANCH 9 — data_router.py:133
            if norm:
                tokens.add(norm)                      # data_router.py:134
        # (no else: any other type — int, dict, None — for this key is silently skipped)

    # tech_family handled SEPARATELY, outside the loop — data_router.py:135
    family = _normalize(tech_fingerprint.get("tech_family"))
    # BRANCH 10 — data_router.py:136
    if family:
        tokens.add(family)                            # data_router.py:137

    return tokens                                     # data_router.py:138
```

Behavioral details a rebuild MUST preserve:
- ⚠️ GOTCHA (ordering of source keys): only `languages`, `frameworks`, `platforms`, `tech_stack` are scanned as collections-or-strings; plus a separate `tech_family` scalar. Fields like `database`, `primary_language` are **NOT** flattened into the token bag here — `database` is handled separately in §3.3 Step 2, and `primary_language` is never consulted by the router at all (it is only carried for other routers). Do not add it to the bag.
- ⚠️ GOTCHA (`tech_stack` flat-bag path): some upstream emitters dump everything into a single `tech_stack` list. Because `tech_stack` is in the scanned tuple, a database token appearing ONLY there (e.g. `tech_stack=["java","spring","ORACLE"]`) still routes correctly. Pinned by `test_data_router.py:188-201`. If a rebuild forgets `tech_stack`, that test breaks and Oracle apps that only declare DB in `tech_stack` mis-route to base.
- The `str` arm (BRANCH 8) handles a fingerprint where a key holds a bare string instead of a list, e.g. `{"languages": "cobol"}` → adds `"cobol"`.
- Items are stringified with `str(item)` before normalizing (BRANCH 6) so non-string list members (e.g. ints) don't crash — but a `None` element short-circuits to `""` and is dropped by BRANCH 7.
- Empty normalized tokens are never added (BRANCH 7 / BRANCH 9 / BRANCH 10 guards).
- Return type is `set` — membership/intersection only; order is NOT defined (see determinism note in §3.3).

### 3.3 `select_data_product_skill(tech_fingerprint: dict | None) -> str` — `data_router.py:141-183`

The single public entry point. Resolution order (most → least specific): mainframe token → explicit `database` field → database token in flat bag → base fallback.

```
function select_data_product_skill(tech_fingerprint):
    tokens = _fingerprint_tokens(tech_fingerprint)        # data_router.py:163

    # ── STEP 1: mainframe family wins over everything ──────────────────
    # BRANCH 11 — data_router.py:169
    if tokens & MAINFRAME_TOKENS:                          # set intersection non-empty
        return "data-product-design-mainframe"             # early return — data_router.py:170

    # ── STEP 2: explicit `database` field lookup ───────────────────────
    database = _normalize((tech_fingerprint or {}).get("database"))   # data_router.py:173-175
        # NOTE: `(tech_fingerprint or {})` guards None — .get on {} returns None,
        # _normalize(None) -> "". So `database` is always a str (possibly "").

    # BRANCH 12 — data_router.py:176
    if database and (database in DATA_PRODUCT_DATABASE_MAP):
        return DATA_PRODUCT_DATABASE_MAP[database]         # early return — data_router.py:177

    # ── STEP 3: scan the flat token bag for any database token ─────────
    # BRANCH 13 — loop — data_router.py:178
    for tok in tokens:
        # BRANCH 14 — data_router.py:179
        if tok in DATA_PRODUCT_DATABASE_MAP:
            return DATA_PRODUCT_DATABASE_MAP[tok]          # early return on FIRST match — data_router.py:180

    # ── STEP 4: fallback to generic base ───────────────────────────────
    return DATA_PRODUCT_DEFAULT_SKILL                      # data_router.py:183 ("data-product-specification")
```

Behavioral details a rebuild MUST preserve:
- ⚠️ GOTCHA (priority is strict and short-circuiting): Step 1 (mainframe) wins over Step 2/3 (database) ALWAYS. The canonical case: a NATURAL/COBOL shop with a SQL Server reporting replica (`database="sqlserver"`, `languages=["natural","cobol"]`) routes to `data-product-design-mainframe`, NOT SQL Server, because the *source* semantics dominate the data contract (`data_router.py:165-168`, pinned by `test_data_router.py:50-65`). If a rebuild checks `database` before the mainframe intersection, this test breaks.
- ⚠️ GOTCHA (`database` field vs. flat bag precedence): Step 2 checks the **explicit `database` key** first; Step 3 only runs if Step 2 didn't return. The explicit field is normalized via `_normalize` (lower+strip), so `"ORACLE"`, `"oracle"`, `" Oracle "` all map to `"oracle"` → Oracle specialist (`test_data_router.py:169-185`).
- ⚠️ GOTCHA (`(tech_fingerprint or {})` re-guard at line 173): `select_data_product_skill` does NOT trust that `_fingerprint_tokens` already validated the dict. It independently guards `None` when reading `database`. If `tech_fingerprint` is a non-dict-but-truthy value (e.g. a list — pathological), `_fingerprint_tokens` returned `set()` (BRANCH 2), and `(["x"] or {}).get` would raise AttributeError because lists have no `.get`. ⚠️ This means a truthy-non-dict input is NOT fully defended at line 173 — it only defends `None`/falsy. In practice the caller always passes `dict | None`, so this never fires; but a rebuild should replicate the *exact* guard `(tech_fingerprint or {})` (only None/falsy protection), not a broader `isinstance` guard, to match behavior on edge inputs. (For `None` and `{}` the result is the base fallback via Step 4.)
- ⚠️ GOTCHA (determinism of Step 3 first-match): `tokens` is a Python `set`, whose iteration order is not guaranteed stable across processes/insertions. Step 3 returns on the FIRST token found in the map. **In practice this is deterministic-by-construction**: every database token in `DATA_PRODUCT_DATABASE_MAP` maps to a value within a single family, AND the only families reachable via Step 3 are the same specialists; BUT if a single fingerprint's flat bag contained two database tokens from *different* families (e.g. both `"oracle"` and `"postgres"` in `tech_stack`), the chosen specialist would depend on set iteration order — a latent non-determinism. The current ATLAS-8 fingerprints never do this, and the explicit `database` field (Step 2) is the intended single-source path. A rebuild should be aware: do NOT rely on Step 3 to disambiguate multi-DB bags; treat the `database` field as authoritative. (No test exercises a conflicting multi-DB bag.)
- Return value is ALWAYS a non-empty `str` (one of the 4 specialist ids or the base). Never `None`, never raises for `dict | None` inputs (`data_router.py:159-161`).

### 3.4 Resolution truth table (consolidated)

| Input condition (first matching row wins) | Returns | Source |
|---|---|---|
| `tech_fingerprint` is `None` or `{}` | `data-product-specification` | BRANCH 2 → Step 4 |
| Any token in `languages`/`frameworks`/`platforms`/`tech_stack`/`tech_family` ∈ MAINFRAME_TOKENS | `data-product-design-mainframe` | BRANCH 11 (`:169-170`) |
| `database` (normalized) ∈ DATA_PRODUCT_DATABASE_MAP | mapped specialist | BRANCH 12 (`:176-177`) |
| Some flat-bag token ∈ DATA_PRODUCT_DATABASE_MAP (first found) | mapped specialist | BRANCH 14 (`:179-180`) |
| Otherwise | `data-product-specification` | Step 4 (`:183`) |

Worked cases (from tests, all pinned):
- `{"languages":["NATURAL"], "database":"ADABAS"}` → `mainframe` (BRANCH 11; `natural` ∈ MAINFRAME_TOKENS). `test:28-34`
- `{"languages":["cobol"], "database":"db2-zos", "tech_family":"mainframe"}` → `mainframe`. `test:37-47`
- `{"languages":["natural","cobol"], "database":"sqlserver", "tech_family":"mainframe"}` → `mainframe` (NOT sqlserver). `test:50-65`
- `{"languages":["java"], "frameworks":["spring"], "database":"oracle", "primary_language":"java"}` → `oracle` (Step 2). `test:68-79`
- `{"database":"oracle-plsql"}` → `oracle` (Step 2). `test:82-88`
- `{"database":"mssql"}` / `{"database":"tsql"}` / `{"database":"sql server"}` → `sqlserver` (Step 2). `test:91-119`
- `{"database":"postgres"}` / `{"database":"aurora-postgres"}` / `{"database":"rds-postgresql"}` → `postgres` (Step 2). `test:122-151`
- `{}` and `None` → `data-product-specification`. `test:154-157`
- `{"database":"some-niche-engine"}` → `data-product-specification` (Step 2 miss, no flat-bag DB token, Step 4). `test:160-166`
- `{"database":"ORACLE"}` / `{"database":"SqlServer"}` / `{"database":"PostgreSQL"}` → resp. oracle/sqlserver/postgres (normalize). `test:169-185`
- `{"languages":["java"], "tech_stack":["java","spring","ORACLE"]}` → `oracle` (Step 2 has no `database`, Step 3 finds `oracle` in flat bag). `test:188-201`

---

## 4. ACTIVITY & CHILD-WORKFLOW CALLS

**NONE.** This module issues no `workflow.execute_activity`, no `workflow.start_child_workflow`, no `asyncio.gather`, no `signal_external_workflow`. It is synchronous, has no retry policies, no timeouts, no `non_retryable_errors`. (The caller `data.py` wraps the *returned skill id* into `AgentTaskInput` and dispatches `dispatch_agent_task` — that activity, its retry policy, and timeout are specified in the `DataWorkflow` / activities specs, not here.)

---

## 5. GATE HANDLING

**NONE.** This module performs no gate evidence assembly, no `wait_for_gate_decision`, no approve/reject/merge-blocked/rework routing, no counters. It is below the workflow boundary. (Data-line G-DT gate routing and its rework loop are specified in the `DataWorkflow` spec.)

---

## 6. RESILIENCE

No timeouts, no heartbeats, no `continue_as_new`, no idempotency keys, no compensation/rollback. Resilience properties relevant to a rebuild:
- **Determinism / replay-safe:** Pure function of its single argument. No clock, no UUID, no network, no global mutable state. Safe to call from inside a deterministic Temporal workflow (which is exactly how `DataWorkflow` uses it). A rebuild MUST NOT introduce any non-deterministic operation.
- **Total / non-raising for the declared input domain (`dict | None`):** Always returns a `str`; never raises for `None`, `{}`, or any `dict`. (Edge: a truthy non-dict, e.g. a list, can raise `AttributeError` at `data_router.py:173` because of the `.get` after the `(x or {})` guard — see §3.3 GOTCHA. This is outside the declared input domain and the caller never produces it.)
- **Import-time evaluation:** The three module-level tables (§1) are built once at import. No runtime mutation. Treat them as constants.

---

## 7. Behavioral parity checklist

A rebuild of this module passes parity iff ALL hold:

1. **Pure & deterministic.** `select_data_product_skill(x)` returns the same string for the same `x` on every call, with no Temporal/clock/network/random usage. Importable and callable with zero Temporal harness.
2. **Three module-level structures reproduced verbatim:**
   - `MAINFRAME_TOKENS` is a `frozenset` containing exactly the 18 tokens in §1.1 (incl. both `db2-zos` and `db2zos`).
   - `DATA_PRODUCT_DATABASE_MAP` contains exactly the 19 key→value pairs in §1.2, including the literal-space key `"sql server"` and the 5 redundant mainframe-data-store keys; `db2-for-luw` is ABSENT.
   - `DATA_PRODUCT_DEFAULT_SKILL == "data-product-specification"`. All three are importable by name (tests import `DATA_PRODUCT_DEFAULT_SKILL`, `MAINFRAME_TOKENS`, `select_data_product_skill`).
3. **`_normalize`** lower-cases and `.strip()`s; returns `""` for `None`/empty; preserves internal whitespace (so `"SQL Server"` → `"sql server"`).
4. **`_fingerprint_tokens`** returns `set()` for `None`/`{}`/non-dict; flattens ONLY keys `languages, frameworks, platforms, tech_stack` (collections OR bare string) plus scalar `tech_family`; stringifies list items via `str()`; drops `None` items and empty norms; does NOT include `database` or `primary_language` in the bag.
5. **Resolution order is exactly Step1→Step2→Step3→Step4** with short-circuit early returns:
   - Step 1: `tokens & MAINFRAME_TOKENS` non-empty → `data-product-design-mainframe` (wins over a conflicting `database`).
   - Step 2: normalized `database` field ∈ map → mapped specialist.
   - Step 3: first flat-bag token ∈ map → mapped specialist.
   - Step 4: else → `data-product-specification`.
6. **Mainframe priority:** `{"languages":["natural","cobol"], "database":"sqlserver", "tech_family":"mainframe"}` returns `data-product-design-mainframe` (NOT sqlserver).
7. **Case-insensitivity:** `{"database":"ORACLE"}` → oracle; `{"database":"SqlServer"}` → sqlserver; `{"database":"PostgreSQL"}` → postgres.
8. **Flat-bag DB routing:** `{"languages":["java"], "tech_stack":["java","spring","ORACLE"]}` → `data-product-design-oracle`.
9. **Fallback:** `{}`, `None`, and `{"database":"some-niche-engine"}` all return `data-product-specification`.
10. **All 4 specialist ids reachable:** `data-product-design-mainframe`, `-oracle`, `-sqlserver`, `-postgres`, plus base `data-product-specification`. Return is never `None` and never raises for `dict | None`.
11. **Caller wiring (DataWorkflow parity):** The router is consulted ONLY when `step_name == "data-product-design"` (`data.py:1458`); every other step uses `step_def["skill_id"]`. The returned id flows into `AgentTaskInput.skill_id`. The router does NOT influence `model_preference` (which is set independently to `"tier-2"` for `migration-planning`/`data-product-design`/`data-synthesis`).
12. **Regression-pinned tokens present:** `natural, adabas, cobol, ims, vsam, db2-zos, cics, copybook` all remain in `MAINFRAME_TOKENS`.

---

## 8. Notes for the integrator
- This module's sibling `discovery_patterns_router.MAINFRAME_TOKENS` MUST be kept identical (the docstring promises lockstep, `data_router.py:38-41`). If regenerating both, share one source of truth or keep two identical literals; a drift is a latent routing bug.
- The full input-shape contract for `tech_fingerprint` is documented on `LineWorkflowInput.tech_fingerprint` (`types.py:1174-1183`): conventionally `languages`, `frameworks`, `platforms`, `database`, `primary_language`, `tech_family`. Only `languages/frameworks/platforms/tech_stack/tech_family/database` are read by this router.
