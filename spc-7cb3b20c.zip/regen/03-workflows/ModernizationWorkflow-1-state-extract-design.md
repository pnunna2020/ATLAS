# `ModernizationWorkflow` — Part 1: State, Signals, Dispatch/Evidence Overrides, run(), Extract (G-04a), Design (G-04b) (ATOMIC regeneration spec)

> **Source of truth:** `temporal/olympus_workflows/workflows/modernization.py` (**2819 lines**, HEAD `7cb3b20c`).
> Every `mod.py:line` citation is against that file at HEAD.
>
> **Scope of THIS file:** lines **1–1709** only. Covers: module constants & maps,
> `__init__`, `_rework_gate_key_for_step`, the two line-specific signals
> (`stakeholder_approved`, `wave_patterns_ready`), the `get_received_patterns` query, the
> `_dispatch_agent` override, the `_build_evidence_data` override, `run()`,
> `_execute_modernization`, `_execute_extract` (G-04a loop), `_find_output_file_content`,
> `_persist_side_effects`, `_select_extraction_skill`, `_dispatch_design_internal` (NEW),
> `_fold_bundle_design_outputs` (NEW), and `_execute_design` (G-04b loop, `mod.py:1185-1344`).
>
> **NOT in scope (sibling Part 2 file owns these — reference only, do NOT reproduce here):**
> `_is_batch_archetype` (1346), `_collect_extract_artifacts` (1353), `_workflow_input_prior_artifacts`
> (1376), `_collect_design_artifacts` (1385), `_commit_design_artifacts` (1392),
> `_build_design_review_content` (1601), `_create_design_pr` (1671), `_execute_generate` (1710),
> `_parse_bounded_contexts` (2102), `_output_file_fields` (2175), `_commit_generate_artifacts` (2183),
> `_create_generate_pr` (2342), `_commit_extract_artifacts` (2399), `_create_extract_pr` (2594),
> `_sum_weights` (2654), `_seed_patterns_from_registry` (2657), `_mark_ready_for_review` (2752), and
> the module-level `parse_bc_names_from_yaml` (2777). When `_execute_extract`/`_execute_design`
> *call* these I describe the call (args/return contract) but do not reproduce the body.
>
> ⚠️ **CHANGED vs the prior baseline (HEAD-refresh, this revision):** The whole file shifted ~50–150
> lines because new state, a `devsecops_baseline` context injection, two NEW Design helpers, and a
> delegated-bundle Design path were added. Most notably:
> 1. **Class base changed** — now `class ModernizationWorkflow(BundleAwareMixin, LineWorkflowBase)`
>    (`mod.py:207`), was `(LineWorkflowBase)`. New MRO + new bundle signals/queries inherited (§0).
> 2. **`run` NOW SETS `self._input = input`** (`mod.py:650`). The prior spec's claim that `_input` is
>    "never populated in production" is **STALE/WRONG** — corrected in GOTCHA-RUN1 below.
> 3. **`_dispatch_agent` NOW injects `context["devsecops_baseline"]`** (`mod.py:451-452`) — a 4th
>    context branch (§6).
> 4. **`__init__` adds `_devsecops_params` + `_committed_baseline_files`** (`mod.py:285, 291`).
> 5. **Design step routes through `_maybe_dispatch_bundle`** (delegated portfolio bundle) with an
>    `internal_fallback` to the NEW `_dispatch_design_internal` chain (§10). The old "inline design
>    dispatch in `_execute_design`" layout is gone.
> 6. **`_execute_modernization` now calls `_load_delegation_config`** after the pattern seed
>    (`mod.py:698`).
>
> **Inherits:** `class ModernizationWorkflow(BundleAwareMixin, LineWorkflowBase)` (`mod.py:207`). See
> `_LineWorkflowBase.md` for inherited engine behavior and `_HILSignalsMixin.md` for the inherited
> HIL signal surface, and the `BundleAwareMixin` (`bundle_helpers.py:68`) for delegated-bundle wiring.
> **Do NOT re-reproduce inherited methods.** Sections below state exactly which base methods this
> subclass OVERRIDES and how the override differs.
>
> **`@workflow.defn` on the class** (`mod.py:206`); `@workflow.run` on `run` (`mod.py:632`).

---

## 0. OVERRIDE / INHERITANCE MATRIX (what THIS subclass changes vs base)

| Base method | This subclass | How it differs |
|-------------|---------------|----------------|
| `_rework_gate_key_for_step` | **OVERRIDES** (`mod.py:297-335`) | Base returns `SINGLE_GATE_KEY`; here returns `"G-04a"` for extract-phase steps, `"G-04b"` for design-phase steps, `None` for generate-phase (Generate reworks via child re-run, not direct dispatch). |
| `_dispatch_agent` | **OVERRIDES** (`mod.py:409-482`) | Base resolves `skill_id` from `STEPS[step]["skill_id"]` and passes `artifact_repo`/`artifact_ref`; here `skill_id` is an **explicit param** + accepts `source_repo`. Injects `context["governance_patterns"]` AND `context["devsecops_baseline"]`. |
| `_build_evidence_data` | **OVERRIDES** (`mod.py:488-626`) | Base iterates `_evidence_steps_iter()` over `STEPS`; here it is **phase-keyed** off the `step` arg (`"extract"`→G-04a, `"design"`→G-04b, `"generate"`→G-04c) with hand-coded step lists and titles, reading `_extract_results`/`_design_results`. |
| `__init__` | **EXTENDS** (`mod.py:242-291`) | Calls `super().__init__()` first (chains BundleAwareMixin → LineWorkflowBase → HILSignalsMixin), then adds **8** instance vars and seeds `_rework_iterations`. |
| `run` / `_execute_modernization` & all `_execute_*` | **DEFINES** (base has none) | Subclass owns orchestration. |
| `_dispatch_design_internal` | **NEW METHOD** (`mod.py:1077-1152`) | Internal Design agent chain; doubles as the `internal_fallback` callable for `_maybe_dispatch_bundle`. |
| `_fold_bundle_design_outputs` | **NEW METHOD** (`mod.py:1154-1183`) | Maps a delegated bundle's accepted `kind→ref` map onto `_design_results` sub-step keys. |
| `stakeholder_approved`, `wave_patterns_ready` | **NEW signals** (`mod.py:341-387`) | Added; do NOT collide with base's 4 gate signals or BundleAwareMixin's bundle signals. |
| `get_received_patterns` | **NEW query** (`mod.py:393-403`) | Added; distinct from base `get_status` and from BundleAwareMixin's `get_bundle_outcome`/`get_bundle_outputs`. |
| `_load_delegation_config`, `_maybe_dispatch_bundle`, `await_bundle_completion`, `get_bundle_outcome`, `get_bundle_outputs` | **INHERITED** (base.py:487/520; `bundle_helpers.py:140/182/187`) | Used by the Design step + the bundle signal surface; NOT redefined here. |

> ⚠️ **GOTCHA-OV (MUST NOT redefine base signals/query):** Per `_LineWorkflowBase.md`
> GOTCHA-SIG0 / GOTCHA-Q1, this subclass MUST NOT redefine `gate_approved`, `gate_rejected`,
> `escalation_resolved`, `merge_retry`, or `get_status`, NOR the BundleAwareMixin signals
> (`bundle_completed`/`bundle_expired`) / queries (`get_bundle_outcome`/`get_bundle_outputs`) —
> Temporal raises on duplicate registration. It adds only the two NEW signals and one NEW query
> above. A rebuild must keep `stakeholder_approved` / `wave_patterns_ready` / `get_received_patterns`
> and inherit the rest.
> ⚠️ **GOTCHA-MRO (CHANGED — MRO is now 4-deep):** docstring `mod.py:217-220` —
> `ModernizationWorkflow → BundleAwareMixin → LineWorkflowBase → HILSignalsMixin → object`.
> `BundleAwareMixin.__init__` calls `super().__init__()` so the whole chain initializes once; no
> base signal handler is redefined. A rebuild MUST list `BundleAwareMixin` **first** in the bases so
> its `__init__` and bundle signal handlers are picked up before base, and so `super().__init__()`
> in the subclass reaches the mixin first.

---

## 1. MODULE-LEVEL CONSTANTS & MAPS (`mod.py:123-203`) — load-bearing

These drive skill selection, progress weights, commit filenames, and the rework ceiling. A
rebuild MUST reproduce them verbatim (values are referenced by exact key).

### 1.1 `LANGUAGE_SKILL_MAP` (`mod.py:124-130`)
```text
LANGUAGE_SKILL_MAP = {
    "cobol":      "extraction-cobol",
    "java":       "extraction-java",
    "coldfusion": "extraction-coldfusion",
    "python":     "extraction-python",
    "default":    "extraction",
}
```
Consumed by `_select_extraction_skill` (§9). ⚠️ **GOTCHA-LSM (iteration order & substring match):**
`_select_extraction_skill` iterates this dict's `.items()` in **insertion order** and does a
**substring** test (`lang in artifact_lower`). So for a prior artifact path containing both
`"java"` and `"python"`, `"cobol"`→`"java"`→`"coldfusion"`→`"python"` ordering means the FIRST
matching language wins (cobol checked before java before coldfusion before python). `"default"`
is explicitly skipped in the loop. A rebuild MUST preserve this dict ordering (Python 3.7+ dict
insertion order is part of behavior here).

### 1.2 `__all__` re-exports (`mod.py:137-142`)
`["CODE_GENERATION_PAIR_MAP", "CODE_GENERATION_SKILL_MAP", "LANGUAGE_SKILL_MAP",
"select_code_generation_skill"]` — the three code-generation symbols are re-exported from
`code_generation_router` for back-compat (`mod.py:117-121`). Not behavior-relevant to this
file's flows except that the import must succeed. ⚠️ **GOTCHA-IMPORT (changed import surface):**
the `with workflow.unsafe.imports_passed_through():` block (`mod.py:66-121`) now ALSO imports
`validate_devsecops_baseline`, `resolve_devsecops_profile`, `is_root_bound`, `route_generate_file`,
`MAX_BC_CHILDREN_PER_APP`, `ResolveDevSecOpsProfileInput`, `ValidateDevSecOpsBaselineInput`, and the
`code_generation_router` symbols — all new since the prior baseline. A rebuild's import block must
include them (the DevSecOps + per-BC-framework features below depend on them).

### 1.3 `EXTRACT_SKILLS` (`mod.py:145-154`) and `DESIGN_SKILLS` (`mod.py:157-174`)
`EXTRACT_SKILLS` maps `"extraction"`→`{artifact, secondary_artifact}` and `"cross-validation"`
→`{skill_id, artifact}`. `DESIGN_SKILLS` maps the four design steps to `{skill_id, artifact}`:
```text
DESIGN_SKILLS = {
    "module-design":     {"skill_id":"module-design",     "artifact":"module-map.yaml"},
    "api-specification": {"skill_id":"api-specification", "artifact":"openapi.yaml"},
    "data-modeling":     {"skill_id":"data-modeling",     "artifact":"data-model.yaml"},
    "batch-design":      {"skill_id":"batch-design",      "artifact":"batch-design.yaml"},
}
```
`DESIGN_SKILLS` is iterated by `_commit_design_artifacts` (sibling file). `EXTRACT_SKILLS` is
declared but the extract-commit helper (sibling) uses its own filename map, not this constant.

### 1.4 `STEP_WEIGHTS` (`mod.py:186-201`) — progress weights, sum 100
```text
STEP_WEIGHTS = {
    "extract": 15.0, "cross-validation": 5.0,
    "requirement-aggregation": 0.0, "business-rule-reconciliation": 0.0,
    "extract-commit": 2.5, "extract-gate": 7.5,
    "design": 15.0, "design-commit": 2.5, "design-gate": 7.5,
    "generate": 25.0, "generate-synthesis": 5.0, "generate-review": 5.0,
    "generate-commit": 2.5, "generate-gate": 7.5,
}
```
⚠️ **GOTCHA-SW (reconciliation steps are 0.0 by design):** `requirement-aggregation` and
`business-rule-reconciliation` carry **0.0 weight** (`mod.py:189-190`) so the sum stays 100 and
legacy replay paths (pre-`br-reconciliation-v1`) see unchanged progress percentages. A rebuild
MUST keep them at 0.0 — giving them weight would change progress for new runs and break replay
parity. ⚠️ Note this `STEP_WEIGHTS` is a **module constant**, separate from the (unused) base
`STEP_WEIGHTS` classvar. The subclass reads it directly (e.g. `STEP_WEIGHTS["extract"]`) and via
`_sum_weights(*steps)` (sibling).

### 1.5 `MAX_REWORK_ITERATIONS = 3` (`mod.py:203`)
The per-gate rework ceiling. Each gate (G-04a/b/c) independently fails the workflow when its
counter exceeds 3. (Comparison is `> MAX_REWORK_ITERATIONS`, i.e. the 4th rejection fails — see
§8.13, §10 rework branches, and the NEW machine-driven baseline-validation rework in §C0 of Part 2.)

### 1.6 Classvar config (`mod.py:231-240`)
```text
ASSEMBLY_LINE = AssemblyLine.MODERNIZATION
ARTIFACT_ROOT = "modernization"
LINE_LABEL    = "Modernization"
STATUS_PREFIX = "modernization"
# SINGLE_GATE_KEY intentionally UNSET (None) — 3 gates; routing via _rework_gate_key_for_step.
# STEPS / STEP_WEIGHTS (base classvars) intentionally unused — evidence is phase-keyed.
```
⚠️ **GOTCHA-CV (no `SINGLE_GATE_KEY`, no base `STEPS`):** because `SINGLE_GATE_KEY` is left at its
base default (`None`) and `_rework_gate_key_for_step` is overridden, rework feedback routes to the
correct one of three gates. Because base `STEPS` is empty, the inherited
`_build_evidence_data`/`_evidence_steps_iter` would yield empty evidence — that is precisely why
`_build_evidence_data` is overridden (§7). A rebuild that sets `SINGLE_GATE_KEY` or relies on base
`STEPS` here will mis-route rework and emit empty evidence.

---

## 2. STATE — instance vars added by THIS subclass (`__init__`, `mod.py:242-291`)

`__init__` calls `super().__init__()` **first** (`mod.py:243`) — this chains
`BundleAwareMixin.__init__` → `LineWorkflowBase.__init__` → `HILSignalsMixin.__init__`, initializing
all HIL vars (`_HILSignalsMixin.md` §1), the base line-state vars (`_LineWorkflowBase.md` §2)
including the empty `_rework_iterations`/`_agent_metadata`/`_step_results`/`_rework_feedback`, and the
bundle-state vars (`_bundle_outcomes`/`_bundle_outputs`). **Then** the subclass sets the following.

| Var | Type | Initial | Line | Mutated by → value | When |
|-----|------|---------|------|---------------------|------|
| `_extract_results` | `dict[str, list[str]]` | `{}` | 248 | `_execute_extract` sets keys `extraction`, `cross-validation`, `requirement-aggregation`, `business-rule-reconciliation` → `result.output_artifacts`; read by `_build_evidence_data`/`_find_output_file_content`/extract-commit | Extract step |
| `_design_results` | `dict[str, list[str]]` | `{}` | 249 | `_dispatch_design_internal` sets `module-design`, `api-specification`, `data-modeling`, `batch-design`(cond), `traceability-audit`; `_fold_bundle_design_outputs` sets sub-step keys from bundle; `_commit_design_artifacts` adds `design-review`; read by evidence/PR-body/`_collect_design_artifacts`/`_parse_bounded_contexts` | Design step |
| `_generate_results` | `list[GenerateBCResult]` | `[]` | 250 | `_execute_generate` sets `= list(bc_results)` (sibling file) | Generate step |
| `_rework_iterations` (inherited, **seeded here**) | `dict[str,int]` | seeded `{"G-04a":0,"G-04b":0,"G-04c":0}` | 256 | `_bump_rework(gate)` increments (base); read by `_rework_count`, PR-body builders | rework loops |
| `_received_patterns` | `list[dict]` | `[]` | 264 | `wave_patterns_ready` appends; `_seed_patterns_from_registry` appends (sibling); read by `_dispatch_agent` (injects into context) + `get_received_patterns` query | governance flywheel |
| `_g04c_stakeholder_ea_approved` | `bool` | `False` | 272 | `stakeholder_approved(scope="g-04c-ea")`→`True`; **reset `False`** in G-04c reject branch (sibling, `mod.py:1965` validation-rework + `mod.py:2086` human-reject) | G-04c Tier-1 |
| `_g04c_stakeholder_security_approved` | `bool` | `False` | 273 | `stakeholder_approved(scope="g-04c-security")`→`True`; reset `False` in G-04c reject branches (`mod.py:1966` + `2087`) | G-04c Tier-1 |
| `_g04a_stakeholder_sme_approved` | `bool` | `False` | 276 | `stakeholder_approved(scope="g-04a-sme")`→`True`; **reset `False`** in G-04a reject branch (`mod.py:975`, §8.13) | G-04a Tier-1 |
| `_devsecops_params` | `dict[str, Any]` | `{}` | 285 | **NEW.** `_execute_generate` resolves once via `resolve_devsecops_profile` → 8-key dict (sibling Part 2 §C0); read by `_dispatch_agent` (injects `context["devsecops_baseline"]`, §6) + the validator's `sast_tool` | Generate step |
| `_committed_baseline_files` | `list[tuple[str,str]]` | `[]` | 291 | **NEW.** `_commit_generate_artifacts` sets the root-bound `(repo_path, content)` set (sibling); read by `validate_devsecops_baseline` (sibling §C0) | Generate step |

> ⚠️ **GOTCHA-INIT1 (seed `_rework_iterations` keys to 0):** `self._rework_iterations.update({"G-04a":0,"G-04b":0,"G-04c":0})`
> (`mod.py:256`). The base initializes the dict EMPTY. The subclass pre-seeds all three keys to 0
> so PR-body builders / callers that read counts by key see `0`, not `KeyError`, on the first
> iteration. A rebuild MUST seed all three.
> ⚠️ **GOTCHA-INIT2 (three Tier-1 flags, reset semantics differ by gate):** the three stakeholder
> flags default `False`. They are consulted **only when `_risk_tier == 1`**. On a gate rejection,
> the matching gate's flags are reset to `False` (`g04a_sme` in this file's §8.13; `g04c_ea`+`g04c_security`
> in the sibling Generate file at BOTH the baseline-validation-rework site and the human-reject site)
> so an early-arriving stakeholder signal from a prior cycle does not leak into the next rework
> attempt. A rebuild MUST reset the relevant flag(s) in each gate's reject branch (NOT a global reset).
> ⚠️ **GOTCHA-INIT3 (`_risk_tier` set in `run`, not `__init__`):** `_risk_tier` is hydrated in
> `run()` from `input.risk_tier` (§8.1). Until `run` executes it is the base default `None`. The
> Tier-1 branches compare `self._risk_tier == 1` (int), and `run` coerces via `int(input.risk_tier)`.
> ⚠️ **GOTCHA-INIT4 (NEW — DevSecOps state is empty until Generate):** `_devsecops_params` is `{}`
> and `_committed_baseline_files` is `[]` until the Generate step (sibling Part 2 §C0) resolves /
> populates them. `_dispatch_agent`'s `devsecops_baseline` injection (§6) is therefore a NO-OP during
> Extract and Design (the dict is falsy) and only fires for the Generate dispatches. A rebuild MUST
> init both empty and gate the injection on truthiness.

---

## 3. `_rework_gate_key_for_step` OVERRIDE (`mod.py:297-335`)

**Base default** returns `self.SINGLE_GATE_KEY`. This subclass overrides to a phase→gate routing
table. Consumed by `_dispatch_agent` (§6) to pick which `_rework_feedback` entry to forward.

```text
def _rework_gate_key_for_step(self, step_name) -> str | None:
    extract_steps = {                                  # mod.py:313-320
        "extraction", "cross-validation",
        "requirement-aggregation", "business-rule-reconciliation",
        "extract", "synthesis",
    }
    design_steps = {                                   # mod.py:321-330
        "module-design", "api-specification", "data-modeling",
        "batch-design", "traceability-audit",
        "design", "adversarial-review", "gate-review-package",
    }
    if step_name in extract_steps:    return "G-04a"    # mod.py:331-332  BRANCH 1
    if step_name in design_steps:     return "G-04b"    # mod.py:333-334  BRANCH 2
    return None                                         # mod.py:335     BRANCH 3 (generate / unknown)
```

**Branch inventory (3):** in-extract-set → `"G-04a"`; in-design-set → `"G-04b"`; else `None`.

> ⚠️ **GOTCHA-RG1 (`synthesis` routes to G-04a, NOT generate):** `"synthesis"` is in
> `extract_steps` (`mod.py:319`), so rework feedback for a step named `synthesis` is forwarded as
> G-04a feedback. But note the Generate step's synthesis dispatch uses `step_name="synthesis"`
> (sibling, `mod.py:1829-1838`) — so on a Generate dispatch with `step_name="synthesis"`,
> `_dispatch_agent` would look up `_rework_feedback["G-04a"]`. This is an intentional-but-subtle
> mapping; a rebuild MUST place `synthesis` in the extract set to match.
> ⚠️ **GOTCHA-RG2 (Generate returns `None` ⇒ no rework_feedback injected for unmapped steps):**
> generate-phase step names not in either set (`security-posture-review`, `security-scan-review`,
> `iac-scaffolding`, and the BC child re-runs) return `None`, so `_dispatch_agent` injects no
> `rework_feedback`. G-04c rework re-runs the child `GenerateBCWorkflow` and re-dispatches the
> SAME-named generate agents (which, via `adversarial-review`/`gate-review-package` ∈ design-set,
> would pick up `_rework_feedback["G-04b"]` if any — see Part 2 GOTCHA-C0-1 for the full nuance). A
> rebuild MUST return `None` for generate-only step names and keep the exact set membership.
> ⚠️ **GOTCHA-RG3 (`extract` and `design` literal step ids are present):** the bare step ids
> `"extract"` and `"design"` are in their respective sets, even though `_set_step("extract", …)`/
> `_set_step("design", …)` are progress markers (not dispatch step names). Harmless but reproduce
> exactly.

---

## 4. NEW SIGNALS (extend base; do not collide)

### 4.1 `stakeholder_approved(self, signal: StakeholderApprovedSignal) -> None` — `mod.py:341-367`
`@workflow.signal`, **async**. Payload `StakeholderApprovedSignal` fields include `scope: str`.
**Only `scope` is read.**

```text
async def stakeholder_approved(self, signal):
    if   signal.scope == "g-04c-ea":        self._g04c_stakeholder_ea_approved = True       # mod.py:356-357  CASE 1
    elif signal.scope == "g-04c-security":  self._g04c_stakeholder_security_approved = True # mod.py:358-359  CASE 2
    elif signal.scope == "g-04a-sme":       self._g04a_stakeholder_sme_approved = True      # mod.py:360-361  CASE 3
    else:                                                                                   # mod.py:362       CASE 4 (unknown)
        workflow.logger.warning(
            "modernization stakeholder_approved with unrecognized scope",
            extra={"scope": signal.scope})                                                  # mod.py:363-366
    self._updated_at = _now_iso()                                                           # mod.py:367
```

**Branch inventory (4 — match/elif chain):** `g-04c-ea` / `g-04c-security` / `g-04a-sme` / else.

> ⚠️ **GOTCHA-SA1 (unknown scope is a WARN no-op, not a failure):** an unrecognized scope logs a
> warning and is **ignored** — it does NOT raise (`mod.py:362-366`). Older callers may send scopes
> that don't apply to Modernization. A rebuild MUST NOT hard-fail on unknown scope.
> ⚠️ **GOTCHA-SA2 (additive set, never cleared here):** each branch sets its flag to `True`; the
> handler NEVER clears a flag. Flags are cleared only in the gate reject branches (§8.13 for SME;
> sibling for ea/security). A second signal with the same scope is an idempotent re-set to `True`.
> ⚠️ **GOTCHA-SA3 (always bump `_updated_at`):** even on the unknown-scope branch, `_updated_at`
> is refreshed (`mod.py:367`). A rebuild bumps `_updated_at` unconditionally at the end.
> ⚠️ **GOTCHA-SA4 (consumed by Tier-1 `wait_condition`, not by `_wait_for_gate_decision`):** these
> flags are NOT part of the buffered `_gate_decisions` cursor. They are consumed by a SECOND
> `wait_condition` that runs AFTER `_wait_for_gate_decision` returns `"approved"` on Tier-1 (§8.11
> for G-04a; sibling for G-04c). A rebuild must keep them as separate flags, not fold into the gate
> decision tuple.

### 4.2 `wave_patterns_ready(self, signal: WavePatternsReadySignal) -> None` — `mod.py:369-387`
`@workflow.signal`, **async**. Payload `WavePatternsReadySignal` fields: `wave_id: str`,
`patterns: list[str]`.

```text
async def wave_patterns_ready(self, signal):
    self._received_patterns.append({                       # mod.py:380-386
        "wave_id":     signal.wave_id,
        "patterns":    list(signal.patterns),              # ← shallow copy of the list
        "received_at": _now_iso(),
    })
    self._updated_at = _now_iso()                          # mod.py:387
```

> ⚠️ **GOTCHA-WP1 (additive — multiple waves accumulate):** each signal APPENDS one bundle dict;
> bundles are never deduped or replaced. If N waves complete, all N bundles are retained for the
> run (`mod.py:380-386`). A rebuild must append, not overwrite.
> ⚠️ **GOTCHA-WP2 (copy the patterns list):** `list(signal.patterns)` snapshots the list so later
> mutation of the signal payload can't alias internal state. A rebuild must copy.
> ⚠️ **GOTCHA-WP3 (no `source` key — distinguishes from cold-start seed):** signal-pushed bundles
> have keys `{wave_id, patterns, received_at}` (no `source`). The cold-start seed
> (`_seed_patterns_from_registry`, sibling) adds an extra `"source":"cold-start-registry"` key. Both
> live in the same list; the distinction is observational only. A rebuild's signal handler must NOT
> add a `source` key.

---

## 5. NEW QUERY: `get_received_patterns(self) -> list[dict]` — `mod.py:393-403`

`@workflow.query`, synchronous, read-only.
```text
@workflow.query
def get_received_patterns(self) -> list[dict]:
    return [dict(entry) for entry in self._received_patterns]   # mod.py:403
```
Returns a **shallow copy** (one new dict per entry) of `_received_patterns` so the query never
aliases internal state. Dashboards use it to surface "absorbed N patterns from governance."

> ⚠️ **GOTCHA-QRP (shallow copy per entry; distinct name from `get_status` & bundle queries):** must
> `dict(entry)` each element, and must be registered under the distinct name `get_received_patterns`
> — NEVER re-decorate `get_status` (base) or the inherited `get_bundle_outcome`/`get_bundle_outputs`
> (BundleAwareMixin). Query handlers must not mutate state (this one doesn't). A rebuild keeps all
> queries.

---

## 6. `_dispatch_agent` OVERRIDE (`mod.py:409-482`)

**Base** takes `(app_id, step_name, input_artifacts, workspace_key="", artifact_repo="",
artifact_ref="")`, resolves `skill_id` from `STEPS`, and optionally loads context-priors under patch
`context-priors-v1`. **This override**:
- takes **explicit `skill_id`** + **`source_repo`** instead of `artifact_repo`/`artifact_ref`;
- does **NOT** resolve `skill_id` from `STEPS` (extraction's skill is runtime-chosen);
- does **NOT** load context-priors (no `context-priors-v1` block here);
- **DOES** inject `context["governance_patterns"]` when patterns have been received; and
- **(NEW) DOES** inject `context["devsecops_baseline"]` when `_devsecops_params` is non-empty.

Signature: `async def _dispatch_agent(self, app_id, step_name, skill_id, input_artifacts,
source_repo="", workspace_key="") -> AgentTaskResult`.

```text
async def _dispatch_agent(self, app_id, step_name, skill_id, input_artifacts,
                          source_repo="", workspace_key=""):
    context: dict = {}
    gate_key = self._rework_gate_key_for_step(step_name)        # mod.py:436
    if gate_key is not None:                                    # mod.py:437  BRANCH 1
        fb = self._rework_feedback.get(gate_key)                # mod.py:438
        if fb is not None:                                      # mod.py:439  BRANCH 2
            context["rework_feedback"] = fb                     # mod.py:440

    if self._received_patterns:                                 # mod.py:445  BRANCH 3
        context["governance_patterns"] = list(self._received_patterns)   # mod.py:446

    if self._devsecops_params:                                  # mod.py:451  BRANCH 4 (NEW)
        context["devsecops_baseline"] = dict(self._devsecops_params)     # mod.py:452

    task_input = AgentTaskInput(                                # mod.py:453-466
        task_type        = f"modernization-{step_name}",        # ← hard-coded "modernization-" prefix
        app_id           = app_id,
        skill_id         = skill_id,                            # ← explicit, not resolved
        input_artifacts  = input_artifacts,
        source_repo      = source_repo,                         # ← source tree, not artifact_repo
        workspace_key    = workspace_key,
        context          = context,
        execution_context= self._execution_ctx(
            step_name, app_id=app_id, input_artifact_paths=input_artifacts),  # mod.py:461-465
    )
    result = await workflow.execute_activity(
        dispatch_agent_task, task_input,
        start_to_close_timeout=timedelta(hours=1),              # mod.py:470
        retry_policy=RETRY_POLICIES["agent_failure"],           # mod.py:471  3 attempts, 5-60s
        activity_id=f"agent-{step_name}",                       # mod.py:472
    )
    self._agent_metadata[step_name] = {                         # mod.py:474-481
        "model_used":         result.model_used,
        "duration_ms":        result.duration_ms,
        "token_usage_input":  result.token_usage_input,
        "token_usage_output": result.token_usage_output,
        "cost_estimate_usd":  result.cost_estimate_usd,
        "output_files":       result.output_files,
    }
    return result
```

**Branch inventory (4):** `if gate_key is not None` (437); `if fb is not None` (439); `if
self._received_patterns` (445); **NEW** `if self._devsecops_params` (451).

**Activity call (1):** `dispatch_agent_task` — `task_input`; **1 hour** start_to_close;
`agent_failure` (3 attempts, 5s→60s backoff); `activity_id=f"agent-{step_name}"`.

> ⚠️ **GOTCHA-DA-O1 (explicit `skill_id`, NO `STEPS` resolution):** unlike base, this never resolves
> from `STEPS`. Every caller passes `skill_id` directly (extraction passes the runtime-selected
> variant from `_select_extraction_skill`; all other steps pass a literal). A rebuild MUST keep
> `skill_id` as an explicit parameter.
> ⚠️ **GOTCHA-DA-O2 (`task_type` prefix is the literal `"modernization-"`):** hard-codes
> `f"modernization-{step_name}"` (`mod.py:454`). A rebuild may hard-code `"modernization-"`.
> ⚠️ **GOTCHA-DA-O3 (`source_repo` not `artifact_repo`):** modernization agents read the LEGACY
> SOURCE tree, so this passes `source_repo=source_repo` and leaves `artifact_repo`/`artifact_ref`
> at their `AgentTaskInput` defaults (`""`). A rebuild must wire `source_repo`, not artifact_repo.
> ⚠️ **GOTCHA-DA-O4 (NO context-priors load):** the base's `workflow.patched("context-priors-v1")`
> block is ABSENT from this override. A rebuild MUST NOT add it here.
> ⚠️ **GOTCHA-DA-O5 (`governance_patterns` injected as a list snapshot, only when non-empty):**
> `context["governance_patterns"] = list(self._received_patterns)` only when truthy
> (`mod.py:445-446`). A rebuild must gate on truthiness and pass a copy.
> ⚠️ **GOTCHA-DA-O6-NEW (`devsecops_baseline` injected as a dict copy, only when non-empty):**
> `context["devsecops_baseline"] = dict(self._devsecops_params)` only when `_devsecops_params` is
> truthy (`mod.py:451-452`). Because `_devsecops_params` is only populated at the start of the
> Generate step (sibling Part 2 §C0), this branch is a **no-op for Extract and Design dispatches**
> and only fires for the four Generate dispatches (synthesis / adversarial-review /
> security-posture-review / security-scan-review / gate-review-package / iac-scaffolding). The
> generating agents render the DevSecOps baseline templates with these profile-correct
> sast_tool/target_cloud/container_base/etc. values. A rebuild MUST add this 4th context branch,
> gate it on truthiness, and pass a **copy** (`dict(...)`), not the live ref.
> ⚠️ **GOTCHA-DA-O7 (rework_feedback routing identical to base, via overridden gate map):** the
> attach logic mirrors base, but `_rework_gate_key_for_step` is the OVERRIDDEN one (§3). Keep them
> together.
> ⚠️ **GOTCHA-DA-O8 (same `_agent_metadata` 6-field shape + `activity_id`):** identical metadata
> recording (6 keys) and deterministic `activity_id=f"agent-{step_name}"`. Keep both for replay
> stability and so `_find_output_file_content` / `_build_evidence_data` / the commit helpers can read
> `output_files`.

---

## 7. `_build_evidence_data` OVERRIDE (`mod.py:488-626`) — phase-keyed evidence

**Base** iterates `_evidence_steps_iter()` (= `STEPS.items()`). Modernization has empty base `STEPS`,
so it overrides to a **phase-keyed** bundle selected by the `step` argument: `"extract"`→G-04a,
`"design"`→G-04b, anything else→G-04c (generate). Slim by default (same content-inclusion contract
as base).

Signature: `def _build_evidence_data(self, app_id, assembly_line, step, *, include_content=False,
content_paths=None) -> dict`.

### 7.1 Phase selection (the outer 3-way branch, `mod.py:511-586`)
```text
if step == "extract":                                          # mod.py:511  PHASE A
    step_titles = {                                            # mod.py:518-525
        "extraction": "Extraction",
        "cross-validation": "Cross-Validation",
        "requirement-aggregation": "Modern Requirements Catalog",
        "business-rule-reconciliation": "Business Rule Reconciliation Matrix",
    }
    candidate_extract_steps = ["extraction","cross-validation",
                               "requirement-aggregation","business-rule-reconciliation"]  # mod.py:530-535
    steps_iter = tuple(                                        # mod.py:536-541
        s for s in candidate_extract_steps
        if s in {"extraction","cross-validation"}             #   core always included
           or s in self._extract_results)                     #   reconciliation only if it ran
    factory_step = "Extract"                                   # mod.py:542
    results_src  = self._extract_results                       # mod.py:543

elif step == "design":                                         # mod.py:544  PHASE B
    step_titles = {                                            # mod.py:548-555
        "module-design": "Domain Modeling",
        "api-specification": "API Design",
        "data-modeling": "Data Model Design",
        "batch-design": "Batch Design",
        "traceability-audit": "Traceability Audit",
        "design-review": "Design Review Summary",
    }
    candidate_steps = ["module-design","api-specification","data-modeling",
                       "batch-design","traceability-audit","design-review"]  # mod.py:559-566
    steps_iter = tuple(                                        # mod.py:567-571
        s for s in candidate_steps
        if s in self._design_results or s == "design-review")  #   each only if it ran; design-review always
    factory_step = "Design"                                    # mod.py:572
    results_src  = self._design_results                        # mod.py:573

else:  # generate                                              # mod.py:574  PHASE C
    step_titles = {                                            # mod.py:575-579
        "synthesis": "Code Synthesis",
        "adversarial-review": "Adversarial Review",
        "gate-review-package": "Gate Review Package",
    }
    steps_iter   = ("synthesis","adversarial-review","gate-review-package")  # mod.py:580-584
    factory_step = "Generate"                                  # mod.py:585
    results_src  = {}     # generate results aren't phase-step-keyed          # mod.py:586
```

### 7.2 Per-step file-artifact assembly (the inner loops, `mod.py:588-618`)
```text
steps: dict = {}
for step_name in steps_iter:                                   # mod.py:589  LOOP
    artifacts    = results_src.get(step_name, [])              # mod.py:590
    metadata     = self._agent_metadata.get(step_name, {})     # mod.py:591
    output_files = metadata.get("output_files", [])            # mod.py:592
    raw_file_artifacts: list[dict] = []
    for f in output_files:                                     # mod.py:594  LOOP
        if not isinstance(f, OutputFile):                      # mod.py:595  BRANCH (skip non-OutputFile)
            continue                                           # mod.py:596
        content_str = f.content if isinstance(f.content, str) else ""   # mod.py:597  BRANCH
        entry = {                                              # mod.py:598-602
            "path": f.path,
            "encoding": f.encoding,
            "size": len(content_str.encode("utf-8")) if content_str else 0,  # BRANCH (size)
        }
        if include_content or (content_paths is not None and f.path in content_paths):  # mod.py:603-605 BRANCH
            entry["content"] = f.content                       # mod.py:606
        raw_file_artifacts.append(entry)
    deduped_file_artifacts = list({f["path"]: f for f in raw_file_artifacts}.values())  # mod.py:608-610 (dedup last-wins)
    steps[step_name] = {                                       # mod.py:611-618
        "title":  step_titles.get(step_name, step_name),       #   title fallback = step id
        "output": artifacts[0] if artifacts else "",           # mod.py:613  BRANCH
        "metadata": {k:v for k,v in metadata.items() if k != "output_files"},  # mod.py:614-616 (strip output_files)
        "file_artifacts": deduped_file_artifacts,              # mod.py:617
    }

return {                                                       # mod.py:620-626
    "assembly_line": assembly_line,
    "factory_step":  factory_step,                             # ← extra key vs base bundle
    "app_id":        app_id,
    "current_step":  step,
    "steps":         steps,
}
```

**Branch inventory (≈10):** phase A/B/C 3-way (511/544/574); the extract `steps_iter`
comprehension condition (538-540: core-always-OR-in-results); the design `steps_iter` condition
(569-570: in-results-OR-design-review); `for step_name in steps_iter` (589); `for f in output_files`
(594); `if not isinstance(f, OutputFile): continue` (595); `content_str = … if isinstance else ""`
(597); `size = … if content_str else 0` (601); `if include_content or (content_paths … in)` (603);
`"output": artifacts[0] if artifacts else ""` (613).

> ⚠️ **GOTCHA-BE-O1 (`step` arg is the PHASE selector, three-way):** the third positional `step`
> is interpreted as the gate phase: `"extract"`/`"design"`/anything-else→generate. Callers pass it
> from the gate sites (`step="extract"` at §8.6, `step="design"` at §10.6, `step="generate"` at the
> sibling). A rebuild MUST branch the bundle shape on this exact arg, NOT iterate base `STEPS`.
> ⚠️ **GOTCHA-BE-O2 (conditional step inclusion mirrors what actually ran):** extract includes
> `extraction`/`cross-validation` ALWAYS, reconciliation steps ONLY if present in `_extract_results`.
> Design includes each of `module-design`/`api-specification`/`data-modeling`/`batch-design`/
> `traceability-audit` ONLY if present in `_design_results`, plus `design-review` ALWAYS. A rebuild
> MUST reproduce the exact membership tests (538-540, 569-570).
> ⚠️ **GOTCHA-BE-O3 (generate `results_src = {}`):** in the generate phase the per-step `output`
> field is always `""` because `results_src.get(step_name, [])` reads an EMPTY dict (`mod.py:586`).
> Generate evidence carries `file_artifacts` from `_agent_metadata` only. A rebuild MUST set
> `results_src={}` for generate.
> ⚠️ **GOTCHA-BE-O4 (extra `"factory_step"` key vs base bundle):** the returned dict has a
> `"factory_step"` key (`"Extract"`/`"Design"`/`"Generate"`) NOT present in base's bundle. Include it.
> ⚠️ **GOTCHA-BE-O5 (slim default + threshold-content scoping identical to base):** the
> `include_content` / `content_paths` / `size`-always / dedup-last-wins / strip-`output_files`
> semantics match base. This override is called TWICE by the inherited `_submit_gate_evidence` (slim,
> then content-scoped for threshold artifacts). For G-04b, `design-review.json` is the threshold
> artifact, so the second call inlines its content. Keep identical to base.

---

## 8. `run()` + `_execute_modernization` + `_execute_extract` (G-04a)

### 8.1 `run(self, input: LineWorkflowInput) -> str` (`mod.py:632-670`) ★ ENTRY
`@workflow.run`. Hydrates lifecycle state, **stores `self._input`**, delegates to
`_execute_modernization`, and on ANY exception marks FAILED + best-effort DB status, then re-raises.

```text
async def run(self, input):
    self._status      = WorkflowStatus.RUNNING        # mod.py:642
    self._started_at  = _now_iso()                    # mod.py:643
    self._updated_at  = self._started_at              # mod.py:644
    self._app_id      = input.app_id                  # mod.py:645
    self._portfolio_id= input.portfolio_id            # mod.py:646
    self._wave_id     = input.wave_id                 # mod.py:647
    self._input       = input                         # mod.py:650  ★ NEW — stores input on self
    self._risk_tier   = int(input.risk_tier) if input.risk_tier is not None else None  # mod.py:651-653  BRANCH
    try:
        return await self._execute_modernization(input)   # mod.py:656
    except Exception:                                  # mod.py:657  BRANCH (catch-all)
        self._status       = WorkflowStatus.FAILED     # mod.py:658
        self._current_step = "failed"                  # mod.py:659
        self._updated_at   = _now_iso()                # mod.py:660
        try:
            await self._update_app_status(             # mod.py:662-667
                input.app_id, "modernization_failed", "failed", "Modernization")
        except Exception:                              # mod.py:668  BRANCH (best-effort)
            pass                                       # mod.py:669
        raise                                          # mod.py:670  ← re-raise original
```

> ⚠️ **GOTCHA-RUN1 (CHANGED — `_input` IS now set):** `run` NOW assigns `self._input = input`
> (`mod.py:650`). **This CORRECTS the prior baseline spec**, which claimed `_input` was "never
> populated in production" and that `_collect_extract_artifacts`'s architecture-blueprint forwarding
> "silently yields nothing." That is now FALSE: with `_input` populated,
> `_workflow_input_prior_artifacts` (sibling) returns the real `prior_artifacts`, so
> `_collect_extract_artifacts` DOES prepend architecture/blueprint priors in production. A rebuild
> MUST set `self._input = input` in `run` (the docstring at `mod.py:648-649` confirms base helpers +
> the delegated-bundle wiring read it). ⚠️ The sibling Part 2 §A3 GOTCHA-A3 is correspondingly
> updated — `_workflow_input_prior_artifacts` still reads `self._input` *defensively* (returns `[]`
> if absent, e.g. unit tests that stub `run`), but in the live `run` path it IS present.
> ⚠️ **GOTCHA-RUN2 (`_risk_tier` coercion to int):** `int(input.risk_tier)` when not None
> (`mod.py:651-653`). `RiskTier` is a str-enum; `int(...)` of a numeric-valued enum member yields
> the int. Tier-1 branches test `== 1`. A rebuild must coerce, or `== 1` against a str/enum fails.
> ⚠️ **GOTCHA-RUN3 (outer except: FAILED + best-effort DB + re-raise):** any exception escaping
> `_execute_modernization` sets `_status=FAILED`, `_current_step="failed"`, attempts a best-effort
> `_update_app_status("modernization_failed","failed")` (swallowing its own errors), then
> **re-raises** the ORIGINAL exception (`mod.py:670`). The workflow does NOT swallow the failure. A
> rebuild MUST re-raise after the projection, wrapping the `_update_app_status` in its own
> try/except…pass so a DB error doesn't mask the original.

### 8.2 `_execute_modernization(self, input) -> str` (`mod.py:672-733`) — top-level orchestration
```text
async def _execute_modernization(self, input):
    app_id = input.app_id                                      # mod.py:674
    self._artifact_repo = input.artifact_repo                  # mod.py:680
    repo = getattr(input, "target_repo_url", "") or input.artifact_repo   # mod.py:681  BRANCH (target-repo fallback)
    source_repo = input.source_repo                            # mod.py:682

    wf_id = workflow.info().workflow_id                        # mod.py:684
    run_suffix = wf_id.rsplit("-", 1)[-1] if "-" in wf_id else wf_id[:8]   # mod.py:685  BRANCH (suffix)
    workspace_key = f"modernization-{app_id}-{run_suffix}"     # mod.py:686

    await self._seed_patterns_from_registry(input.portfolio_id)  # mod.py:692  (sibling; best-effort)
    await self._load_delegation_config(input.portfolio_id)       # mod.py:698  ★ NEW (base.py:487)

    await self._update_app_status(                             # mod.py:701-703
        app_id, "modernization_in_progress", "extract", "Modernization")

    # ── Step 1: Extract ──
    extract_result = await self._execute_extract(input, app_id, repo, source_repo, run_suffix, workspace_key)  # mod.py:706-708
    if extract_result != "approved":                           # mod.py:709  BRANCH (early return)
        return extract_result                                  # mod.py:710

    # ── Step 2: Design ──
    design_result = await self._execute_design(input, app_id, repo, source_repo, run_suffix, workspace_key)    # mod.py:713-715
    if design_result != "approved":                            # mod.py:716  BRANCH (early return)
        return design_result                                   # mod.py:717

    # ── Step 3: Generate ──
    generate_result = await self._execute_generate(input, app_id, repo, source_repo, run_suffix, workspace_key)  # mod.py:720-722
    if generate_result != "approved":                          # mod.py:723  BRANCH (early return)
        return generate_result                                 # mod.py:724

    await self._update_app_status(                             # mod.py:726-728
        app_id, "modernization_complete", "completed", "Modernization")
    self._status       = WorkflowStatus.COMPLETED              # mod.py:729
    self._progress_pct = 100.0                                 # mod.py:730
    self._current_step = "completed"                           # mod.py:731
    self._updated_at   = _now_iso()                            # mod.py:732
    return "completed"                                         # mod.py:733
```

**Branch inventory (5):** target-repo fallback (681); run-suffix `if "-" in wf_id` (685);
`if extract_result != "approved"` (709); `if design_result != "approved"` (716); `if
generate_result != "approved"` (723).

> ⚠️ **GOTCHA-EM1 (target_repo_url FALLBACK to artifact_repo):** `repo = getattr(input,
> "target_repo_url","") or input.artifact_repo` (`mod.py:681`). W19 PR C: commits land in the
> TARGET application's modernization repo when populated, else the portfolio artifact_repo (pre-A3
> back-compat). ALL commit/PR/gate activities use `repo`, NOT `_artifact_repo`. `_artifact_repo` is
> still SET (`mod.py:680`) but only the local `repo` var flows downstream. A rebuild MUST compute
> `repo` with this exact fallback and thread it through every phase.
> ⚠️ **GOTCHA-EM2 (run_suffix derivation):** `wf_id.rsplit("-",1)[-1] if "-" in wf_id else
> wf_id[:8]` (`mod.py:685`) — the trailing token after the last hyphen, or the first 8 chars if no
> hyphen. Used in branch names, the workspace key, and child workflow ids. DETERMINISTIC (derived
> from `workflow.info()`), safe under replay. Reproduce the exact slicing or branch/child ids drift.
> ⚠️ **GOTCHA-EM3 (sequential phase gating — any non-approved short-circuits):** each phase returns
> a string; ONLY `"approved"` proceeds. `"failed"` / `"cancelled"` short-circuit immediately
> (`mod.py:709/716/723`). The terminal COMPLETED block runs ONLY after all three phases returned
> `"approved"`. A rebuild MUST gate each phase on `== "approved"` and propagate any other string.
> ⚠️ **GOTCHA-EM4-CHANGED (`_seed_patterns_from_registry` THEN `_load_delegation_config` THEN status
> flip):** the cold-start pattern seed runs first (`mod.py:692`), then the **NEW**
> `_load_delegation_config(input.portfolio_id)` (`mod.py:698`, inherited from base) loads the
> portfolio's delegation config so the Design step can route through a delegated bundle, THEN the
> `modernization_in_progress` status push (`mod.py:701`). Both pre-status calls are best-effort
> wrt the run continuing. A rebuild MUST add the `_load_delegation_config` call in this exact order
> (seed → delegation-config → status → extract) — omitting it means `_maybe_dispatch_bundle` in the
> Design step sees no delegation config and always takes the internal-chain path.

### 8.3 `_execute_extract(...)` — the G-04a loop (`mod.py:739-990`) ★ CORE

Signature: `async def _execute_extract(self, input, app_id, repo, source_repo, run_suffix,
workspace_key) -> str`. Returns `"approved"` / `"failed"` / `"cancelled"`.

```text
branch = f"olympus/modernization/extract/{app_id}/{run_suffix}"   # mod.py:753

while True:                                                       # mod.py:755  ★ REWORK LOOP
    # ---- 8.4 Variant selection ----
    skill_id = self._select_extraction_skill(input)              # mod.py:757  (§9)

    # ---- 8.5 Extraction dispatch ----
    business_logic_path = f"discovery/{app_id}/business-logic.json"   # mod.py:767
    extract_inputs = list(input.prior_artifacts)                 # mod.py:768
    if business_logic_path not in extract_inputs:                # mod.py:769  BRANCH (G6.3 prepend)
        extract_inputs.insert(0, business_logic_path)            # mod.py:770
    await self._set_step("extract", 0.0)                         # mod.py:771
    extraction_result = await self._dispatch_agent(              # mod.py:772-779
        app_id=app_id, step_name="extraction", skill_id=skill_id,
        input_artifacts=extract_inputs, source_repo=source_repo, workspace_key=workspace_key)
    self._extract_results["extraction"] = extraction_result.output_artifacts   # mod.py:780-782

    # ---- Cross-validation dispatch ----
    await self._set_step("cross-validation", STEP_WEIGHTS["extract"])   # mod.py:785-787  (progress = 15.0)
    cross_val_result = await self._dispatch_agent(               # mod.py:788-795
        app_id=app_id, step_name="cross-validation", skill_id="cross-validation",
        input_artifacts=extraction_result.output_artifacts,      # ← extraction outputs feed cross-val
        source_repo=source_repo, workspace_key=workspace_key)
    self._extract_results["cross-validation"] = cross_val_result.output_artifacts   # mod.py:796-798

    # ---- Business Rule Reconciliation (PATCH-GATED) ----
    reconciliation_ran = False                                   # mod.py:814
    if workflow.patched("br-reconciliation-v1"):                 # mod.py:815  BRANCH (patch gate)
        req_agg_result = await self._dispatch_agent(             # mod.py:820-827
            app_id=app_id, step_name="requirement-aggregation",
            skill_id="requirement-aggregation",
            input_artifacts=extraction_result.output_artifacts,  # ← extraction outputs as context
            source_repo=source_repo, workspace_key=workspace_key)
        self._extract_results["requirement-aggregation"] = req_agg_result.output_artifacts  # mod.py:828-830

        reconcile_inputs = list(extraction_result.output_artifacts) + list(req_agg_result.output_artifacts)  # mod.py:837-839
        reconcile_result = await self._dispatch_agent(           # mod.py:840-847
            app_id=app_id, step_name="business-rule-reconciliation",
            skill_id="business-rule-reconciliation",
            input_artifacts=reconcile_inputs,
            source_repo=source_repo, workspace_key=workspace_key)
        self._extract_results["business-rule-reconciliation"] = reconcile_result.output_artifacts  # mod.py:848-850
        reconciliation_ran = True                                # mod.py:851

    # ---- 8.6 Commit, PR, gate record, evidence ----
    await self._set_step("extract-commit",                       # mod.py:854-857
        STEP_WEIGHTS["extract"] + STEP_WEIGHTS["cross-validation"])   # progress = 20.0
    artifact_paths = await self._commit_extract_artifacts(repo, branch, app_id)   # mod.py:858-860 (sibling)

    pr_result = await self._create_extract_pr(                   # mod.py:863-865 (sibling)
        repo, branch, app_id, skill_id, reconciliation_ran)

    gate_record = await workflow.execute_activity(               # mod.py:868-879
        create_gate_record,
        CreateGateRecordInput(gate_type="G-04a", app_id=app_id,
            portfolio_id=input.portfolio_id,
            workflow_id=workflow.info().workflow_id,
            evidence_package_url=pr_result.pr_url),
        start_to_close_timeout=timedelta(seconds=30),
        retry_policy=RETRY_POLICIES["transient"])

    await self._submit_gate_evidence(                            # mod.py:882-890  (base helper)
        gate_id=gate_record.gate_id, gate_type=GateType.G_04A, app_id=app_id,
        artifact_paths=artifact_paths, pr_url=pr_result.pr_url,
        assembly_line="Modernization", step="extract")

    # ---- 8.7 Pre-review vs bare ready-flip (PATCH-GATED) ----
    if workflow.patched("modernization-gate-pre-review-v1"):     # mod.py:899  BRANCH (patch gate)
        await self._run_gate_pre_review(gate_record.gate_id, "G-04a",
            artifact_paths, artifact_repo=repo, artifact_ref=branch)   # mod.py:900-906  (base helper)
    else:                                                        # mod.py:907
        await self._mark_ready_for_review(gate_record.gate_id)   # mod.py:908  (sibling helper)

    await self._update_app_status(app_id, "gate_review",         # mod.py:910-915
        "extract-gate-review", "Modernization")

    # ---- 8.8 Wait for gate decision ----
    await self._set_step("extract-gate",                         # mod.py:918-923
        STEP_WEIGHTS["extract"] + STEP_WEIGHTS["cross-validation"] + STEP_WEIGHTS["extract-commit"])  # 22.5
    decision = await self._wait_for_gate_decision(GateType.G_04A)   # mod.py:924  (base)

    # ---- 8.9 Decision routing ----
    if decision == "cancelled":                                  # mod.py:926  BRANCH
        return "cancelled"                                       # mod.py:927

    if decision == "approved":                                   # mod.py:929  BRANCH
        # ---- 8.10/8.11 Tier-1 SME gate ----
        if self._risk_tier == 1:                                 # mod.py:935  BRANCH (Tier-1 only)
            await workflow.wait_condition(                       # mod.py:936-941
                lambda: (self._g04a_stakeholder_sme_approved or self.cancelled))   # ★ PREDICATE
            if self.cancelled:                                   # mod.py:942  BRANCH
                self._status = WorkflowStatus.CANCELLED          # mod.py:943
                return "cancelled"                               # mod.py:944

        # ---- 8.12 Post-G-04a projection ----
        cross_val_refs = self._extract_results.get("cross-validation", [])   # mod.py:950-952
        extraction_ref = cross_val_refs[0] if cross_val_refs else ""         # mod.py:953  BRANCH
        report_file = self._find_output_file_content("cross-validation")     # mod.py:954-956 (§8a)
        await self._persist_side_effects(                        # mod.py:957-962 (§8b)
            app_id, "extract",
            extraction_report_json=report_file, extraction_ref=extraction_ref)

        # ---- merge with merge_blocked retry loop ----
        await self._reconcile_and_merge_with_retry_loop(         # mod.py:965-970  (base)
            repo=repo, pr_number=pr_result.pr_number,
            gate_id=gate_record.gate_id, merge_method="merge")
        return "approved"                                        # mod.py:971

    # ---- 8.13 Rejected → rework ----
    self._g04a_stakeholder_sme_approved = False                  # mod.py:975  ★ reset SME flag
    self._bump_rework("G-04a")                                   # mod.py:977  (base) increments counter
    if self._rework_count("G-04a") > MAX_REWORK_ITERATIONS:      # mod.py:978  BRANCH (ceiling)
        self._status       = WorkflowStatus.FAILED               # mod.py:979
        self._current_step = "extract-max-rework-exceeded"       # mod.py:980
        self._updated_at   = _now_iso()                          # mod.py:981
        await self._update_app_status(app_id, "modernization_failed",
            "extract-max-rework-exceeded", "Modernization")      # mod.py:982-987
        return "failed"                                          # mod.py:988
    # else: fall through → loop back to top of `while True` and re-extract  (mod.py:989-990)
```

**Branch inventory for `_execute_extract` (≈14):** `while True` (755); `if business_logic_path
not in extract_inputs` (769); `if workflow.patched("br-reconciliation-v1")` (815); `if
workflow.patched("modernization-gate-pre-review-v1")` else (899/907); `if decision == "cancelled"`
(926); `if decision == "approved"` (929); `if self._risk_tier == 1` (935); the SME `wait_condition`
lambda (936); `if self.cancelled` (942); `extraction_ref = cross_val_refs[0] if … else ""` (953);
`self._g04a_stakeholder_sme_approved = False` (reject reset, 975); `if self._rework_count("G-04a")
> MAX_REWORK_ITERATIONS` (978); and the implicit fall-through loop-back.

**Activities & helpers in order (one rework iteration):**
1. `_select_extraction_skill` (pure, §9).
2. `_dispatch_agent("extraction", skill_id, extract_inputs, source_repo)` → `dispatch_agent_task`
   (1h, `agent_failure`, `activity_id="agent-extraction"`).
3. `_dispatch_agent("cross-validation", "cross-validation", extraction outputs)` →
   `agent-cross-validation`.
4. **IF `br-reconciliation-v1`:** `_dispatch_agent("requirement-aggregation", …)` →
   `agent-requirement-aggregation`; then `_dispatch_agent("business-rule-reconciliation", …)` →
   `agent-business-rule-reconciliation`.
5. `_commit_extract_artifacts(repo, branch, app_id)` (sibling — batches/writes per
   `modernization-batch-writes-v1`; returns committed paths).
6. `_create_extract_pr(repo, branch, app_id, skill_id, reconciliation_ran)` (sibling — `create_pr`,
   60s, `transient`).
7. `create_gate_record` — `CreateGateRecordInput(gate_type="G-04a", …)`; **30s**; `transient`.
8. `_submit_gate_evidence(gate_type=GateType.G_04A, step="extract")` (base — runs
   `check_gate_criteria` + `submit_gate_evidence`).
9. **IF `modernization-gate-pre-review-v1`:** `_run_gate_pre_review(gate_id,"G-04a", …,
   artifact_repo=repo, artifact_ref=branch)` (base). **ELSE:** `_mark_ready_for_review(gate_id)`
   (sibling — patch-gated `mark_gate_ready_for_review`, 30s).
10. `_update_app_status("gate_review","extract-gate-review")` (base, 30s/`transient`).
11. `_wait_for_gate_decision(GateType.G_04A)` (base — buffered cursor wait).
12. **on approve + Tier-1:** `wait_condition(SME or cancelled)`.
13. **on approve:** `_find_output_file_content("cross-validation")`; `_persist_side_effects("extract",
    …)` → `persist_modernization_side_effects` (60s/`transient`, `activity_id="persist-modernization-extract"`);
    `_reconcile_and_merge_with_retry_loop(merge_method="merge")` (base).
14. **on reject:** reset SME flag; `_bump_rework("G-04a")`; ceiling check → FAILED or loop.

> ⚠️ **GOTCHA-EX1 (`_set_step("extract", 0.0)` resets progress to 0 every loop iteration):** at the
> top of each rework iteration progress is set to 0.0 (`mod.py:771`), then climbs through 15→20→22.5
> as the gate is reached. ⚠️ A rework iteration's progress NON-MONOTONICALLY drops back to 0. Set
> progress to exactly `0.0` at the extract dispatch each loop.
> ⚠️ **GOTCHA-EX2 (G6.3 business-logic.json prepend, dedup-aware):** `extract_inputs =
> list(input.prior_artifacts)`; prepend `f"discovery/{app_id}/business-logic.json"` ONLY if not
> already present (`mod.py:767-770`). A rebuild MUST prepend (insert at index 0) only when missing.
> ⚠️ **GOTCHA-EX3 (input chaining: extraction → cross-val → reconciliation):** cross-validation's
> `input_artifacts` = `extraction_result.output_artifacts` (NOT `extract_inputs`); requirement-
> aggregation's input = `extraction_result.output_artifacts`; reconciliation's input =
> `extraction.output_artifacts + req_agg.output_artifacts` (concatenated, `mod.py:837-839`). Chain
> exactly these.
> ⚠️ **GOTCHA-EX4 (`br-reconciliation-v1` patch — verbatim, replay-critical):** the two
> reconciliation dispatches AND `reconciliation_ran=True` are gated by
> `workflow.patched("br-reconciliation-v1")` (`mod.py:815`). Pre-patch in-flight runs replay WITHOUT
> these two dispatches. Gate ALL of: the two dispatches, the two `_extract_results` writes, and the
> `reconciliation_ran` flag. `reconciliation_ran` flows into `_create_extract_pr` to extend the PR
> body. The 0.0 STEP_WEIGHTS keep progress identical on both paths.
> ⚠️ **GOTCHA-EX5 (pre-review patch — `modernization-gate-pre-review-v1`):** the choice between
> `_run_gate_pre_review` and the bare `_mark_ready_for_review` flip is patch-gated (`mod.py:899`).
> BOTH branches end with the gate becoming reviewable. A rebuild MUST use this EXACT patch id.
> ⚠️ **GOTCHA-EX6 (Tier-1 SME is a SECOND wait AFTER gate approve):** on `decision == "approved"`
> AND `_risk_tier == 1`, a SEPARATE `wait_condition(lambda: self._g04a_stakeholder_sme_approved or
> self.cancelled)` blocks until the SME signal lands (`mod.py:935-941`). Tier-2/3 SKIP this wait.
> If cancel arrives during this wait, `_status=CANCELLED` and return `"cancelled"` (`mod.py:942-944`).
> ⚠️ **GOTCHA-EX7 (post-approve projection uses cross-validation refs):** `extraction_ref =
> cross_val_refs[0] if cross_val_refs else ""` where `cross_val_refs =
> _extract_results.get("cross-validation", [])` (`mod.py:950-953`); and `extraction_report_json` is
> the cross-validation step's first output FILE content
> (`_find_output_file_content("cross-validation")`). Source BOTH from cross-validation.
> ⚠️ **GOTCHA-EX8 (merge_method="merge" for G-04a only):** `_reconcile_and_merge_with_retry_loop`
> is called with explicit `merge_method="merge"` for G-04a (`mod.py:969`). Design (G-04b) and Generate
> (G-04c) call it WITHOUT `merge_method` → default `"merge"` (same value).
> ⚠️ **GOTCHA-EX9 (reject branch: reset SME → bump → ceiling, in that order):** on `"rejected"`,
> the SME flag is reset to `False` FIRST (`mod.py:975`), THEN `_bump_rework("G-04a")` (`mod.py:977`),
> THEN the `> MAX_REWORK_ITERATIONS` ceiling check (`mod.py:978`). The counter increments BEFORE the
> comparison, so the 4th rejection (count → 4 > 3) fails with `_current_step="extract-max-rework-exceeded"`
> and returns `"failed"`. Three rejections loop back. Keep this exact order.
> ⚠️ **GOTCHA-EX10 (rework re-dispatch picks up `_rework_feedback["G-04a"]`):** `_wait_for_gate_decision`
> set `_rework_feedback["G-04a"]` on reject (base). On loop-back, `_dispatch_agent` for extract-phase
> steps forwards that feedback via `context["rework_feedback"]`.

---

## 8a. `_find_output_file_content(self, step_name) -> str` (`mod.py:992-1009`)

Returns the first output-file content for a step, tolerating dict OR `OutputFile`.
```text
def _find_output_file_content(self, step_name):
    metadata = self._agent_metadata.get(step_name, {})         # mod.py:1001
    output_files = metadata.get("output_files", [])            # mod.py:1002
    if not output_files:                                       # mod.py:1003  BRANCH
        return ""                                              # mod.py:1004
    first = output_files[0]                                    # mod.py:1005
    if isinstance(first, dict):                                # mod.py:1007  BRANCH
        return str(first.get("content", ""))                   # mod.py:1008
    return first.content if hasattr(first, "content") else ""  # mod.py:1009  BRANCH
```
**Branch inventory (3):** `if not output_files` → `""`; `if isinstance(first, dict)` →
`str(first.get("content",""))`; else `first.content if hasattr else ""`.

> ⚠️ **GOTCHA-FF1 (dict-OR-OutputFile tolerance):** Temporal may deserialize `OutputFile`
> dataclasses as plain dicts across activity boundaries. dict → `str(.get("content",""))`; object →
> `.content` if it has the attr, else `""`. A rebuild MUST tolerate both shapes.
> ⚠️ **GOTCHA-FF2 (empty = "skip that field"):** returns `""` when the step didn't run or produced
> no files. The `persist_modernization_side_effects` activity treats empty `*_json` as "skip that
> field" rather than failing. Used by all three `_persist_side_effects` calls (extract/design/
> generate). A rebuild MUST return `""` (not raise) on missing data.

---

## 8b. `_persist_side_effects(...)` (`mod.py:1011-1054`) — best-effort projection

Signature: `async def _persist_side_effects(self, app_id, gate_phase, *,
extraction_report_json="", extraction_ref="", module_map_json="", design_review_json="",
design_ref="", gate_review_package_json="") -> None`.

```text
async def _persist_side_effects(self, app_id, gate_phase, *, <kwargs all default ""> ):
    try:
        await workflow.execute_activity(                       # mod.py:1032-1048
            persist_modernization_side_effects,
            PersistModernizationSideEffectsInput(
                target_app_id=app_id,
                gate_phase=gate_phase,                         # "extract" | "design" | "generate"
                extraction_report_json=extraction_report_json,
                extraction_ref=extraction_ref,
                module_map_json=module_map_json,
                design_review_json=design_review_json,
                design_ref=design_ref,
                gate_review_package_json=gate_review_package_json,
                decided_at=_now_iso()),
            start_to_close_timeout=timedelta(seconds=60),       # mod.py:1045
            retry_policy=RETRY_POLICIES["transient"],           # mod.py:1046
            activity_id=f"persist-modernization-{gate_phase}")  # mod.py:1047
    except Exception:                                          # mod.py:1049  BRANCH (best-effort)
        workflow.logger.exception(                             # mod.py:1050-1054
            "persist_modernization_side_effects failed; app row keeps stale modernization fields",
            extra={"gate_phase": gate_phase, "app_id": app_id})
```

**Branch inventory (1):** the `try/except Exception` (1049).

**Activity (1):** `persist_modernization_side_effects` — `PersistModernizationSideEffectsInput`;
**60s**; `transient`; `activity_id=f"persist-modernization-{gate_phase}"`.

> ⚠️ **GOTCHA-PS1 (BEST-EFFORT — swallows ALL exceptions, continues):** a projection failure logs
> via `workflow.logger.exception` and returns normally (`mod.py:1049-1054`). The gate approval still
> completes; only the app row keeps stale Modernization fields. A rebuild MUST wrap the activity in
> try/except and NOT propagate. (Contrast `run`'s outer except which re-raises; this inner one does
> not.)
> ⚠️ **GOTCHA-PS2 (`gate_phase` selects which fields the activity projects):** called three times
> with `gate_phase` = `"extract"` (§8.12), `"design"` (§10.6), `"generate"` (sibling). The workflow
> populates only the relevant `*_json`/`*_ref` kwargs and leaves the rest `""`.
> ⚠️ **GOTCHA-PS3 (`activity_id` keyed by gate_phase):** `persist-modernization-{gate_phase}` makes
> each of the three projections independently idempotent on replay. Keep distinct ids.
> ⚠️ **GOTCHA-PS4 (`decided_at=_now_iso()`):** deterministic timestamp. Never `datetime.now()`.

---

## 9. `_select_extraction_skill(self, input) -> str` (`mod.py:1056-1071`)

```text
def _select_extraction_skill(self, input):
    for artifact in input.prior_artifacts:                     # mod.py:1063  LOOP
        artifact_lower = artifact.lower()                      # mod.py:1064
        for lang, skill_id in LANGUAGE_SKILL_MAP.items():      # mod.py:1065  LOOP
            if lang == "default":                              # mod.py:1066  BRANCH (skip default)
                continue                                       # mod.py:1067
            if lang in artifact_lower:                         # mod.py:1068  BRANCH (substring match)
                return skill_id                                # mod.py:1069  ← first match wins
    return LANGUAGE_SKILL_MAP["default"]                       # mod.py:1071  ← "extraction"
```

**Branch inventory (4):** outer `for artifact` (1063); inner `for lang, skill_id` (1065); `if lang
== "default": continue` (1066); `if lang in artifact_lower: return` (1068); plus the final
`return ...["default"]` (1071).

> ⚠️ **GOTCHA-SES1 (artifact-outer, language-inner iteration order):** the OUTER loop is over
> `input.prior_artifacts` (list order), the INNER over `LANGUAGE_SKILL_MAP.items()` (insertion
> order). The FIRST `(artifact, lang)` pair where `lang` is a substring of `artifact.lower()` wins.
> Keep artifact-outer/language-inner ordering AND the dict insertion order.
> ⚠️ **GOTCHA-SES2 (substring, case-insensitive, `default` excluded):** match is `lang in
> artifact_lower`, `"default"` is explicitly skipped, ultimate fallback is `LANGUAGE_SKILL_MAP["default"]`
> = `"extraction"`.

---

## 9a. `_dispatch_design_internal(...)` — NEW (`mod.py:1077-1152`) ★ the internal Design agent chain

Signature: `async def _dispatch_design_internal(self, input, app_id, source_repo, workspace_key)
-> AgentTaskResult`. **NEW since the prior baseline.** Runs the internal-agent dispatch chain the
Design step used before Phase 6 delegation: module-design → api-specification → data-modeling →
(batch-design) → traceability-audit. It is BOTH the `internal_fallback` callable for
`_maybe_dispatch_bundle` AND the direct path when the step isn't delegated. Returns the
**traceability-audit** `AgentTaskResult` that `_commit_design_artifacts` consumes to emit
`design-review.json`.

```text
async def _dispatch_design_internal(self, input, app_id, source_repo, workspace_key):
    # ---- Module design ----
    module_result = await self._dispatch_agent(                 # mod.py:1096-1103
        app_id=app_id, step_name="module-design", skill_id="module-design",
        input_artifacts=self._collect_extract_artifacts(),      # ← extract outputs (+ arch blueprint), sibling
        source_repo=source_repo, workspace_key=workspace_key)
    self._design_results["module-design"] = module_result.output_artifacts   # mod.py:1104

    # ---- API specification ----
    api_result = await self._dispatch_agent(                    # mod.py:1107-1114
        app_id=app_id, step_name="api-specification", skill_id="api-specification",
        input_artifacts=module_result.output_artifacts,         # ← module-design outputs
        source_repo=source_repo, workspace_key=workspace_key)
    self._design_results["api-specification"] = api_result.output_artifacts   # mod.py:1115

    # ---- Data modeling ----
    data_result = await self._dispatch_agent(                   # mod.py:1118-1125
        app_id=app_id, step_name="data-modeling", skill_id="data-modeling",
        input_artifacts=module_result.output_artifacts,         # ← module-design outputs (NOT api outputs)
        source_repo=source_repo, workspace_key=workspace_key)
    self._design_results["data-modeling"] = data_result.output_artifacts   # mod.py:1126

    # ---- Batch design (CONDITIONAL on archetype) ----
    if self._is_batch_archetype(input):                         # mod.py:1129  BRANCH (sibling helper)
        batch_result = await self._dispatch_agent(              # mod.py:1130-1137
            app_id=app_id, step_name="batch-design", skill_id="batch-design",
            input_artifacts=module_result.output_artifacts,     # ← module-design outputs
            source_repo=source_repo, workspace_key=workspace_key)
        self._design_results["batch-design"] = batch_result.output_artifacts   # mod.py:1138

    # ---- Traceability audit (ALWAYS-ON, W19 PR C) ----
    audit_result = await self._dispatch_agent(                  # mod.py:1143-1150
        app_id=app_id, step_name="traceability-audit", skill_id="traceability-audit",
        input_artifacts=self._collect_design_artifacts(),       # ← all design outputs so far (sibling)
        source_repo=source_repo, workspace_key=workspace_key)
    self._design_results["traceability-audit"] = audit_result.output_artifacts   # mod.py:1151
    return audit_result                                         # mod.py:1152
```

**Branch inventory (1):** `if self._is_batch_archetype(input)` (1129).

**Activities in order:** `_dispatch_agent` × (4 or 5): `module-design` → `api-specification` →
`data-modeling` → [`batch-design` if batch] → `traceability-audit`. Each → `agent-{step}`.

> ⚠️ **GOTCHA-DDI1 (NEW — extracted into its own method as the bundle fallback):** the old baseline
> inlined this chain inside `_execute_design`. It is now a SEPARATE method so it can serve as the
> `fallback_fn` lambda for `_maybe_dispatch_bundle` (§10). A rebuild MUST extract this chain so it
> can be (a) the internal direct path and (b) the bundle-expiry fallback, both returning the
> traceability-audit result.
> ⚠️ **GOTCHA-DDI2 (input chaining: module → api/data/batch; audit ← all design):** module-design
> feeds api-specification AND data-modeling AND batch-design (all three take
> `module_result.output_artifacts`). data-modeling takes MODULE outputs, NOT api outputs.
> traceability-audit takes `_collect_design_artifacts()` (all design outputs accumulated so far —
> at this point `design-review` is NOT yet present). Chain exactly.
> ⚠️ **GOTCHA-DDI3 (batch-design CONDITIONAL; traceability-audit ALWAYS-ON):** batch-design
> dispatches ONLY when `_is_batch_archetype(input)`. traceability-audit ALWAYS dispatches (the old
> `traceability-audit-v1` patch gate was removed). Do NOT re-add a patch gate around the audit.
> ⚠️ **GOTCHA-DDI4 (returns the audit result):** the return value is the traceability-audit
> `AgentTaskResult`, which `_commit_design_artifacts(audit_result=...)` reads to source
> `design-review.json` from the audit skill's `output_files` (sibling §B1/B2). A rebuild MUST return
> the audit result.

---

## 9b. `_fold_bundle_design_outputs(self, outputs: dict[str, str]) -> None` — NEW (`mod.py:1154-1183`)

Folds a delegated bundle's accepted output map (`artifact_kind → ref`) into `_design_results` keyed
by the canonical design sub-step, so the gate's evidence + commit helpers see the pair's artifacts
exactly as they would the internal agents'. **NEW since the prior baseline.**

```text
def _fold_bundle_design_outputs(self, outputs):
    kind_to_step = {                                            # mod.py:1167-1176
        "module-map": "module-design",     "module_map": "module-design",
        "openapi": "api-specification",    "api-specification": "api-specification",
        "data-model": "data-modeling",     "data_model": "data-modeling",
        "batch-design": "batch-design",    "traceability-audit": "traceability-audit",
    }
    for kind, ref in (outputs or {}).items():                   # mod.py:1177  LOOP
        if not ref:                                             # mod.py:1178  BRANCH (skip empty ref)
            continue                                            # mod.py:1179
        step_key = kind_to_step.get(kind, kind)                 # mod.py:1180  ← unknown kinds kept under own key
        self._design_results.setdefault(step_key, [])           # mod.py:1181
        if ref not in self._design_results[step_key]:           # mod.py:1182  BRANCH (de-dup append)
            self._design_results[step_key].append(ref)          # mod.py:1183
```

**Branch inventory (3 + loop):** `for kind, ref in (outputs or {}).items()` (1177); `if not ref:
continue` (1178); `if ref not in self._design_results[step_key]` (1182).

> ⚠️ **GOTCHA-FB1 (unknown kinds kept under their own key — defensive):** `kind_to_step.get(kind,
> kind)` (1180) — a kind not in the map is stored under its own key so nothing is silently dropped
> (defensive-agent-output rule). A rebuild MUST default to `kind` itself, not skip.
> ⚠️ **GOTCHA-FB2 (de-dup append; never overwrite the list):** each ref is appended to the
> sub-step's list only if not already present (1182), via `setdefault(step_key, [])` (1181). A
> rebuild MUST append (de-duped), not replace the list.
> ⚠️ **GOTCHA-FB3 (both kebab and snake aliases map to the same step):** `module-map`/`module_map`,
> `openapi`/`api-specification`, `data-model`/`data_model` all collapse to the canonical step. A
> rebuild MUST include both spellings.

---

## 10. `_execute_design(...)` — the G-04b loop (`mod.py:1185-1344`) ★ CORE

Signature: `async def _execute_design(self, input, app_id, repo, source_repo, run_suffix,
workspace_key) -> str`. Returns `"approved"` / `"failed"` / `"cancelled"`. ⚠️ **CHANGED:** the
internal agent chain that used to be inlined here now lives in `_dispatch_design_internal` (§9a),
and the dispatch is routed through the inherited `_maybe_dispatch_bundle` (delegated-portfolio
bundle) with `_dispatch_design_internal` as the `internal_fallback`.

```text
branch = f"olympus/modernization/design/{app_id}/{run_suffix}"   # mod.py:1195
design_base = self._sum_weights("extract","cross-validation","extract-commit","extract-gate")  # mod.py:1196-1201  = 30.0

while True:                                                      # mod.py:1203  ★ REWORK LOOP
    await self._set_step("design", design_base)                 # mod.py:1204  (progress = 30.0)

    # ---- 10.1 Bundle-or-internal Design dispatch (NEW routing) ----
    audit_result = await self._maybe_dispatch_bundle(           # mod.py:1215-1225  (base.py:520)
        step_or_gate_id="modernization-design",
        scope_kind="line_step",
        app_id=app_id,
        wave_id=None,
        is_delegatable=True,
        expires_hours=7 * 24,                                   #   168h delegation TTL
        fallback_fn=lambda: self._dispatch_design_internal(     #   ← §9a is the internal_fallback
            input, app_id, source_repo, workspace_key))
    # When delegated + accepted, _maybe_dispatch_bundle returns the accepted
    # outputs MAP (dict). The internal path returns the traceability-audit
    # AgentTaskResult. Normalise.
    if isinstance(audit_result, dict):                          # mod.py:1234  BRANCH (bundle path)
        self._fold_bundle_design_outputs(audit_result)          # mod.py:1235  (§9b)
        audit_result = None                                     # mod.py:1236  ← no internal audit; design-review falls back to provisional

    # ---- Commit, PR, gate record, evidence ----
    await self._set_step("design-commit", design_base + STEP_WEIGHTS["design"])   # mod.py:1240-1242  = 45.0
    artifact_paths = await self._commit_design_artifacts(       # mod.py:1243-1245 (sibling)
        repo, branch, app_id, audit_result=audit_result)        #   emits design-review.json from audit output (or provisional if None)

    pr_result = await self._create_design_pr(repo, branch, app_id)   # mod.py:1248 (sibling)

    gate_record = await workflow.execute_activity(              # mod.py:1250-1261
        create_gate_record,
        CreateGateRecordInput(gate_type="G-04b", app_id=app_id,
            portfolio_id=input.portfolio_id,
            workflow_id=workflow.info().workflow_id,
            evidence_package_url=pr_result.pr_url),
        start_to_close_timeout=timedelta(seconds=30),
        retry_policy=RETRY_POLICIES["transient"])

    await self._submit_gate_evidence(                           # mod.py:1263-1271  (base helper)
        gate_id=gate_record.gate_id, gate_type=GateType.G_04B, app_id=app_id,
        artifact_paths=artifact_paths, pr_url=pr_result.pr_url,
        assembly_line="Modernization", step="design")

    if workflow.patched("modernization-gate-pre-review-v1"):    # mod.py:1273  BRANCH (patch gate)
        await self._run_gate_pre_review(gate_record.gate_id, "G-04b",
            artifact_paths, artifact_repo=repo, artifact_ref=branch)   # mod.py:1274-1280
    else:                                                       # mod.py:1281
        await self._mark_ready_for_review(gate_record.gate_id)  # mod.py:1282

    await self._update_app_status(app_id, "gate_review",        # mod.py:1284-1289
        "design-gate-review", "Modernization")

    await self._set_step("design-gate",                         # mod.py:1291-1296
        design_base + STEP_WEIGHTS["design"] + STEP_WEIGHTS["design-commit"])   # = 47.5
    decision = await self._wait_for_gate_decision(GateType.G_04B)   # mod.py:1297  (base)

    # ---- 10.6 Decision routing ----
    if decision == "cancelled":                                 # mod.py:1299  BRANCH
        return "cancelled"                                      # mod.py:1300

    if decision == "approved":                                  # mod.py:1302  BRANCH
        module_map_content    = self._find_output_file_content("module-design")   # mod.py:1308-1310 (§8a)
        design_review_content = self._find_output_file_content("design-review")   # mod.py:1311-1313 (§8a)
        design_refs = self._design_results.get("design-review", [])               # mod.py:1314
        design_ref  = design_refs[0] if design_refs else ""                        # mod.py:1315  BRANCH
        await self._persist_side_effects(                       # mod.py:1316-1322 (§8b)
            app_id, "design",
            module_map_json=module_map_content,
            design_review_json=design_review_content,
            design_ref=design_ref)
        await self._reconcile_and_merge_with_retry_loop(        # mod.py:1325-1329  (base; default merge_method)
            repo=repo, pr_number=pr_result.pr_number, gate_id=gate_record.gate_id)
        return "approved"                                       # mod.py:1330

    # ---- 10.7 Rejected → rework (NOTE: NO Tier-1 flag reset for G-04b) ----
    self._bump_rework("G-04b")                                  # mod.py:1333  (base) increment
    if self._rework_count("G-04b") > MAX_REWORK_ITERATIONS:     # mod.py:1334  BRANCH (ceiling)
        self._status       = WorkflowStatus.FAILED              # mod.py:1335
        self._current_step = "design-max-rework-exceeded"       # mod.py:1336
        self._updated_at   = _now_iso()                         # mod.py:1337
        await self._update_app_status(app_id, "modernization_failed",
            "design-max-rework-exceeded", "Modernization")      # mod.py:1338-1343
        return "failed"                                         # mod.py:1344
    # else: fall through → loop back to top of `while True` and re-run design (implicit)
```

**Branch inventory for `_execute_design` (≈8):** `while True` (1203); `if isinstance(audit_result,
dict)` (1234, NEW bundle-vs-internal normalisation); `if workflow.patched("modernization-gate-pre-review-v1")`
else (1273/1281); `if decision == "cancelled"` (1299); `if decision == "approved"` (1302);
`design_ref = design_refs[0] if … else ""` (1315); `if self._rework_count("G-04b") >
MAX_REWORK_ITERATIONS` (1334); and the implicit fall-through loop-back. (The internal-chain
branches — batch-design conditional, etc. — now live in `_dispatch_design_internal`, §9a.)

**Activities & helpers in order (one rework iteration):**
1. `_maybe_dispatch_bundle("modernization-design", scope_kind="line_step", is_delegatable=True,
   expires_hours=168, fallback_fn=→_dispatch_design_internal)` (base). On delegation it dispatches a
   bundle + blocks on the completion signal via `await_bundle_completion`; on a non-accepted terminal
   outcome (expired/released/rejected/timeout) it invokes `fallback_fn` (the internal chain). On no
   delegation it runs the internal chain directly. The internal chain itself runs the 4-or-5
   `_dispatch_agent` calls of §9a.
2. **IF bundle path:** `_fold_bundle_design_outputs(accepted_outputs)` (pure, §9b); `audit_result=None`.
3. `_commit_design_artifacts(repo, branch, app_id, audit_result=audit_result)` (sibling — iterates
   `DESIGN_SKILLS`, emits `design-review.json` from `audit_result.output_files` OR the provisional
   default when `audit_result is None`, sets `_design_results["design-review"]` +
   `_agent_metadata["design-review"]`).
4. `_create_design_pr(repo, branch, app_id)` (sibling — `create_pr`, 60s, `transient`).
5. `create_gate_record(gate_type="G-04b")` — 30s/`transient`.
6. `_submit_gate_evidence(gate_type=GateType.G_04B, step="design")` (base; G-04b has `GATE_THRESHOLDS`
   so the criteria call inlines `design-review.json` content).
7. **IF pre-review patch:** `_run_gate_pre_review(gate_id,"G-04b", …)`. **ELSE:**
   `_mark_ready_for_review(gate_id)`.
8. `_update_app_status("gate_review","design-gate-review")`.
9. `_wait_for_gate_decision(GateType.G_04B)`.
10. **on approve:** `_find_output_file_content("module-design")` + `_find_output_file_content(
    "design-review")`; `_persist_side_effects("design", module_map_json, design_review_json,
    design_ref)` → `persist-modernization-design`; `_reconcile_and_merge_with_retry_loop(...)`.
11. **on reject:** `_bump_rework("G-04b")`; ceiling → FAILED or loop.

> ⚠️ **GOTCHA-DS0-NEW (delegated-bundle Design routing):** the Design dispatch is the platform's
> reference delegatable scope (Phase 6 W1, design §5.2). `_maybe_dispatch_bundle("modernization-design",
> scope_kind="line_step", is_delegatable=True, expires_hours=7*24)` either (a) dispatches a claimable
> bundle for the whole design package and blocks on the completion signal — then on a NON-accepted
> terminal outcome falls back to the internal chain — or (b), when the portfolio isn't delegated, runs
> the internal chain directly via `fallback_fn`. Either way the gate downstream sees the same
> `_design_results` shape. A rebuild MUST: pass `step_or_gate_id="modernization-design"`,
> `scope_kind="line_step"`, `is_delegatable=True`, `expires_hours=7*24`, and a `fallback_fn` lambda
> that calls `_dispatch_design_internal(input, app_id, source_repo, workspace_key)`.
> ⚠️ **GOTCHA-DS1-NEW (dict-return normalisation determines `audit_result`):** `_maybe_dispatch_bundle`
> returns the bundle's accepted outputs **map (dict)** when the pair produced the design package, or
> the traceability-audit **`AgentTaskResult`** when the internal chain ran. The normalisation at
> `mod.py:1234-1236`: `if isinstance(audit_result, dict)` → fold the refs into `_design_results`
> (§9b) AND set `audit_result = None`. Setting it to `None` means `_commit_design_artifacts`'s
> `design-review.json` falls back to the **provisional default** (still gate-evaluable; sibling §B2),
> because a delegated pair produces no internal audit result. A rebuild MUST reproduce this exact
> branch — fold-then-None on dict, leave the dataclass untouched otherwise.
> ⚠️ **GOTCHA-DS-design_base (`design_base = 30.0`, progress climbs 30→45→47.5 each loop):**
> `design_base = _sum_weights("extract","cross-validation","extract-commit","extract-gate")` =
> 15+5+2.5+7.5 = 30.0 (`mod.py:1196-1201`). Each rework re-sets progress to 30.0, then 45.0 at commit,
> 47.5 at gate. Recompute via `_sum_weights` (do not hard-code; though it equals 30.0).
> ⚠️ **GOTCHA-DS4 (`audit_result` threads into `_commit_design_artifacts` → design-review.json):**
> the audit result (or `None` on the bundle path) is passed to
> `_commit_design_artifacts(audit_result=...)` so the committed `design-review.json` is sourced from
> the audit skill's `output_files` (real metrics) OR the provisional default (when `None`). The
> committed `design-review.json` is the G-04b THRESHOLD artifact. Pass `audit_result` through.
> ⚠️ **GOTCHA-DS5 (post-approve projection reads module-design + design-review):** `module_map_json`
> = first output FILE content of `module-design`; `design_review_json` = first output FILE content of
> `design-review` (the synthetic step `_commit_design_artifacts` registered); `design_ref` = first
> element of `_design_results["design-review"]`, or `""` (`mod.py:1308-1315`). Source each from these
> exact steps.
> ⚠️ **GOTCHA-DS6 (G-04b reject branch has NO Tier-1 flag reset):** unlike G-04a (resets `_g04a_
> stakeholder_sme_approved`, §8.13) and G-04c (resets `_g04c_*`, sibling), the G-04b reject branch
> does NOT reset any stakeholder flag — because **G-04b has no Tier-1 stakeholder wait at all**.
> Design proceeds on the gate `gate_approved` (PM merge) regardless of risk tier; there is no
> `if self._risk_tier == 1` block in the approve path of `_execute_design`. A rebuild MUST NOT add a
> Tier-1 wait or a flag reset to G-04b. (The key behavioral asymmetry: G-04a = SME wait, G-04b =
> none, G-04c = EA+security wait.)
> ⚠️ **GOTCHA-DS7 (G-04b merge uses default merge_method):** `_reconcile_and_merge_with_retry_loop`
> is called WITHOUT `merge_method` (`mod.py:1325-1329`), defaulting to `"merge"`.
> ⚠️ **GOTCHA-DS8 (ceiling semantics identical to extract):** `_bump_rework("G-04b")` then `> 3`
> check; the 4th rejection fails with `_current_step="design-max-rework-exceeded"` → `"failed"`;
> 1st-3rd loop back. Counter is per-gate (`_rework_iterations["G-04b"]`), independent of G-04a's.

---

## 11. RESILIENCE summary (this file's scope)

- **Timeouts (start_to_close):** `dispatch_agent_task` **1h** (`agent_failure`, 3 attempts, 5-60s);
  `create_gate_record` **30s** (`transient`); `_submit_gate_evidence` → `check_gate_criteria` /
  `submit_gate_evidence` **60s** each (`transient`, base); `_update_app_status` **30s** (`transient`,
  base); `persist_modernization_side_effects` **60s** (`transient`); plus base helpers
  `_run_gate_pre_review` (10m + 30s + 30s), `_mark_ready_for_review` (30s), `_reconcile_and_merge_
  with_retry_loop` (60s `git_merge` + 30s `set_gate_merge_blocked`), and the inherited
  `_maybe_dispatch_bundle` / `await_bundle_completion` (workflow-internal `wait_condition` timeout +
  the bundle-dispatch activity). Sibling commit helpers use 120s (batch) / 60s (single).
- **Heartbeats:** none configured by this workflow.
- **continue-as-new:** none. The workflow runs all three phases in one execution; rework loops are
  `while True` with bounded counters (max 3 rejections each), so iteration count is bounded.
- **Idempotency / determinism:** deterministic `activity_id`s (`agent-{step}`, `persist-
  modernization-{gate_phase}`); `_now_iso()` / `workflow.now()` only; `run_suffix` derived from
  `workflow.info().workflow_id`. All optional behavior is patch-gated with VERBATIM ids:
  `"br-reconciliation-v1"`, `"modernization-gate-pre-review-v1"`, `"mark-gate-ready-for-review-v1"`
  (sibling helper), `"modernization-batch-writes-v1"` (sibling commit helpers),
  `"context-priors-v1"` / `"mark-gate-ready-for-review-v1"` (base). Imports are inside
  `with workflow.unsafe.imports_passed_through():` (`mod.py:66`).
- **Compensation / rollback:** none. Failure semantics: rework exhaustion → `_status=FAILED` +
  `_current_step="{phase}-max-rework-exceeded"` + best-effort `_update_app_status("modernization_
  failed", ...)` + return `"failed"` (caught by `_execute_modernization`'s `!= "approved"` short-
  circuit, which returns the string up to `run`). `"failed"`/`"cancelled"` are RETURNED, not raised.
  The only RAISE path is `run`'s outer except for unexpected exceptions (sets FAILED, best-effort DB,
  re-raises). `_persist_side_effects` is best-effort (swallows). `_seed_patterns_from_registry` /
  `_load_delegation_config` are best-effort (sibling / base). `cancel_workflow` (inherited HIL) sets
  `self.cancelled`, drained by `_wait_for_gate_decision`, the Tier-1 SME `wait_condition`, and
  `_reconcile_and_merge_with_retry_loop` — all return `"cancelled"`.

---

## 12. Behavioral parity checklist (this file's scope)

A rebuilt `ModernizationWorkflow` (state + signals + dispatch/evidence overrides + run + Extract +
Design portions) MUST satisfy ALL of the following:

1. **Inheritance / non-override:** `class ModernizationWorkflow(BundleAwareMixin, LineWorkflowBase)`,
   `@workflow.defn`, MRO 4-deep (GOTCHA-MRO). Does NOT redefine `gate_approved`/`gate_rejected`/
   `escalation_resolved`/`merge_retry`/`get_status` NOR the BundleAwareMixin signals/queries
   (GOTCHA-OV). Adds exactly two new signals + one new query.
2. **Classvars:** `ASSEMBLY_LINE=AssemblyLine.MODERNIZATION`, `ARTIFACT_ROOT="modernization"`,
   `LINE_LABEL="Modernization"`, `STATUS_PREFIX="modernization"`, `SINGLE_GATE_KEY` left None, base
   `STEPS`/`STEP_WEIGHTS` unused (GOTCHA-CV).
3. **Module constants:** `LANGUAGE_SKILL_MAP` (5 keys, exact insertion order, GOTCHA-LSM),
   `STEP_WEIGHTS` (14 keys sum 100, reconciliation steps 0.0, GOTCHA-SW), `MAX_REWORK_ITERATIONS=3`,
   `EXTRACT_SKILLS`, `DESIGN_SKILLS` (4 design steps), reproduced verbatim. Import block includes the
   DevSecOps + per-BC-framework symbols (GOTCHA-IMPORT).
4. **`__init__`:** calls `super().__init__()` first; sets `_extract_results={}`, `_design_results={}`,
   `_generate_results=[]`; seeds `_rework_iterations` `{"G-04a":0,"G-04b":0,"G-04c":0}` (GOTCHA-INIT1);
   `_received_patterns=[]`; three stakeholder flags `False` (GOTCHA-INIT2); **NEW**
   `_devsecops_params={}` + `_committed_baseline_files=[]` (GOTCHA-INIT4).
5. **`_rework_gate_key_for_step` override:** extract-set (incl. `synthesis`, GOTCHA-RG1) → `"G-04a"`;
   design-set (incl. `traceability-audit`, `adversarial-review`, `gate-review-package`) → `"G-04b"`;
   else `None` (generate, GOTCHA-RG2). Exact set membership.
6. **`stakeholder_approved` signal:** async; 4-way scope branch `g-04c-ea`/`g-04c-security`/
   `g-04a-sme`/else-warn-noop (GOTCHA-SA1); sets only the matching flag `True` (never clears); bumps
   `_updated_at` unconditionally (GOTCHA-SA3).
7. **`wave_patterns_ready` signal:** async; APPENDS `{wave_id, patterns:list(copy), received_at}` (no
   `source` key, GOTCHA-WP3); additive across waves (GOTCHA-WP1); bumps `_updated_at`.
8. **`get_received_patterns` query:** returns `[dict(e) for e in _received_patterns]`; distinct name
   from `get_status` and bundle queries (GOTCHA-QRP).
9. **`_dispatch_agent` override:** explicit `skill_id` (no `STEPS` resolution, GOTCHA-DA-O1);
   `task_type=f"modernization-{step_name}"` literal (GOTCHA-DA-O2); passes `source_repo` not
   artifact_repo (GOTCHA-DA-O3); NO context-priors block (GOTCHA-DA-O4); injects
   `context["governance_patterns"]=list(...)` only when `_received_patterns` truthy (GOTCHA-DA-O5);
   **NEW** injects `context["devsecops_baseline"]=dict(...)` only when `_devsecops_params` truthy
   (GOTCHA-DA-O6-NEW); attaches `context["rework_feedback"]` via overridden gate map when present;
   `dispatch_agent_task` 1h/`agent_failure`/`activity_id="agent-{step}"`; records 6-field
   `_agent_metadata[step]` (GOTCHA-DA-O8).
10. **`_build_evidence_data` override:** 3-way phase branch on `step` arg (GOTCHA-BE-O1); conditional
    step inclusion (GOTCHA-BE-O2); generate `results_src={}` (GOTCHA-BE-O3); extra `"factory_step"`
    key (GOTCHA-BE-O4); slim default + threshold-content scoping identical to base (GOTCHA-BE-O5).
11. **`run`:** sets RUNNING + timestamps + `_app_id`/`_portfolio_id`/`_wave_id`; **NEW** `self._input=
    input` (GOTCHA-RUN1, CHANGED); `_risk_tier=int(input.risk_tier) if not None else None`
    (GOTCHA-RUN2); try → `_execute_modernization`; except-all → FAILED + `_current_step="failed"` +
    best-effort `_update_app_status("modernization_failed","failed")` (own try/except) + **re-raise**
    (GOTCHA-RUN3).
12. **`_execute_modernization`:** `repo = target_repo_url or artifact_repo` (GOTCHA-EM1, also sets
    `_artifact_repo`); `run_suffix` derivation (GOTCHA-EM2); `workspace_key=f"modernization-{app_id}-
    {run_suffix}"`; `_seed_patterns_from_registry` THEN **NEW** `_load_delegation_config` THEN status
    flip (GOTCHA-EM4-CHANGED); runs Extract→Design→Generate, each short-circuiting on `!= "approved"`
    (GOTCHA-EM3); terminal block sets COMPLETED + 100.0 + `"completed"`.
13. **`_execute_extract` G-04a loop:** `while True`; branch `olympus/modernization/extract/{app_id}/
    {run_suffix}`; `_set_step("extract", 0.0)` each iteration (GOTCHA-EX1); business-logic.json
    prepend-if-missing (GOTCHA-EX2); input chaining extraction→cross-val→reconciliation (GOTCHA-EX3);
    `br-reconciliation-v1` patch gates the two reconciliation dispatches + `reconciliation_ran`
    (GOTCHA-EX4); commit → PR (passes `reconciliation_ran`) → `create_gate_record(G-04a, 30s)` →
    `_submit_gate_evidence(G_04A, step="extract")`; pre-review-vs-flip patch branch (GOTCHA-EX5);
    `_update_app_status("gate_review","extract-gate-review")`; `_set_step("extract-gate", 22.5)`;
    `_wait_for_gate_decision(G_04A)`; `cancelled`→return; `approved`→[Tier-1 SME wait if `_risk_tier==
    1` with cancel handling (GOTCHA-EX6)] → projection from cross-validation refs (GOTCHA-EX7) +
    `_persist_side_effects("extract", …)` → `_reconcile_and_merge_with_retry_loop(merge_method="merge")`
    → `"approved"`; `rejected`→reset SME flag, `_bump_rework("G-04a")`, if `>3` FAILED+`"extract-max-
    rework-exceeded"`+`"failed"` else loop (GOTCHA-EX9), re-dispatch picking up `_rework_feedback[
    "G-04a"]` (GOTCHA-EX10).
14. **`_find_output_file_content`:** `""` if no files; dict→`str(.get("content",""))`; object→
    `.content if hasattr else ""` (GOTCHA-FF1/FF2).
15. **`_persist_side_effects`:** best-effort try/except (swallows, logs — GOTCHA-PS1);
    `persist_modernization_side_effects` 60s/`transient`/`activity_id=f"persist-modernization-
    {gate_phase}"`; `decided_at=_now_iso()`; phase-selective kwargs (GOTCHA-PS2/PS3/PS4).
16. **`_select_extraction_skill`:** artifact-outer/language-inner loops (GOTCHA-SES1); skip
    `"default"`; substring case-insensitive; first match wins; fallback `"extraction"` (GOTCHA-SES2).
17. **`_dispatch_design_internal` (NEW):** the internal chain module-design → api-specification →
    data-modeling → (batch-design if `_is_batch_archetype`) → traceability-audit; module outputs feed
    api/data/batch; audit reads `_collect_design_artifacts()`; returns the audit `AgentTaskResult`
    (GOTCHA-DDI1..4). Serves as the bundle `internal_fallback`.
18. **`_fold_bundle_design_outputs` (NEW):** maps `kind→ref` (both kebab+snake aliases) onto
    `_design_results` sub-step keys; unknown kinds kept under own key; de-dup append; skip empty refs
    (GOTCHA-FB1..3).
19. **`_execute_design` G-04b loop:** `while True`; branch `olympus/modernization/design/{app_id}/
    {run_suffix}`; `design_base = 30.0`; `_set_step("design", design_base)` each iteration; **NEW**
    `audit_result = await _maybe_dispatch_bundle("modernization-design", scope_kind="line_step",
    is_delegatable=True, expires_hours=7*24, fallback_fn=→_dispatch_design_internal)` (GOTCHA-DS0-NEW);
    `if isinstance(audit_result, dict)` → `_fold_bundle_design_outputs` + `audit_result=None`
    (GOTCHA-DS1-NEW); commit (`_commit_design_artifacts(audit_result=audit_result)`, GOTCHA-DS4) → PR
    → `create_gate_record(G-04b, 30s)` → `_submit_gate_evidence(G_04B, step="design")`;
    pre-review-vs-flip patch branch; `_update_app_status("gate_review","design-gate-review")`;
    `_set_step("design-gate", 47.5)`; `_wait_for_gate_decision(G_04B)`; `cancelled`→return; `approved`→
    projection from module-design + design-review (GOTCHA-DS5) + `_persist_side_effects("design", …)` →
    `_reconcile_and_merge_with_retry_loop(...)` (default merge_method, GOTCHA-DS7) → `"approved"`;
    **NO Tier-1 wait and NO flag reset for G-04b** (GOTCHA-DS6); `rejected`→`_bump_rework("G-04b")`, if
    `>3` FAILED+`"design-max-rework-exceeded"`+`"failed"` (line 1344) else loop (GOTCHA-DS8). Counter
    independent of G-04a.
20. **Patch ids verbatim:** `"br-reconciliation-v1"`, `"modernization-gate-pre-review-v1"`.
21. **Determinism:** `_now_iso()`/`workflow.now()` only; deterministic activity ids; `run_suffix`
    from `workflow.info()`; imports inside `imports_passed_through()`.
22. **Per-gate independence:** G-04a / G-04b counters and Tier-1 behavior are independent — G-04a has
    an SME wait (Tier-1), G-04b has none; their `_rework_iterations` keys never cross-contaminate.
