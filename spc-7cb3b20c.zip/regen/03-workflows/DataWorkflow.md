# `DataWorkflow` — Per-Target-App Data Assembly Line (ATOMIC regeneration spec)

> **Source of truth:** `temporal/olympus_workflows/workflows/data.py` (1674 lines). Every
> `data.py:line` citation is against that file.
>
> **Extends:** `class DataWorkflow(LineWorkflowBase)` (`data.py:269-270`). Inherited behavior is
> specified in `_LineWorkflowBase.md` (the shared engine) and transitively `_HILSignalsMixin.md`
> (the HIL signal surface). **This spec reproduces ONLY the subclass: its new state, its two new
> signals, `run()`/`_execute_data()`, the override `_dispatch_agent`, and every Data-specific
> helper. It does NOT re-reproduce inherited methods** — it lists which are inherited-as-is,
> which are overridden, and how each override differs.
>
> **Gate:** single gate `G-DT` (Data Architecture Review). `SINGLE_GATE_KEY = "G-DT"`.
>
> **One run = one TARGET application.** For Refactor / Rearchitect / Replatform / Retain the
> target *is* the source; for Replace the target is net-new; for Consolidate the target is
> anchored on one source plus its peers (`data.py:1-8`).
>
> **Two-way Arch↔Data handshake** (registry-backed under `arch-data-registry-v1`): Data's
> step 0 *receives* Architecture's `TargetProvisionedSignal`; Data's step 11 *publishes*
> `DataReadyForTargetSignal` back so Architecture's step 5 unblocks (`data.py:10-50`).
>
> ⚠️ **GOTCHA-SCOPE (78 branch-point premise):** The task brief estimates ~78 branch-points.
> The literal `if/elif/else/except/for/while/try/finally` keyword count in `data.py` is ~154
> (many are inline-conditional expressions and prose in comments). Every **executable** branch in
> the subclass scope is reproduced below; nothing is collapsed. Inherited-method branches
> (`_dispatch_agent` base path, `_wait_for_gate_decision`, `_reconcile_and_merge_with_retry_loop`,
> `_commit_step_artifacts`, `_submit_gate_evidence`, `_run_gate_pre_review`, etc.) are in
> `_LineWorkflowBase.md` and referenced, not duplicated.

---

## 0. Module-level constants, helpers, and the step table

### 0.1 Imports (`data.py:73-129`)
- `import asyncio` (`data.py:75`) — used for `asyncio.gather(...)` parallel fan-out and to catch
  `asyncio.TimeoutError` in the backstop wait.
- `from olympus_workflows.workflows.base import LineWorkflowBase, _now_iso` (`data.py:81`).
- Everything else is inside `with workflow.unsafe.imports_passed_through():` (`data.py:83-129`):
  `json`; `ApplicationError`; the activity functions `dispatch_agent_task`,
  `consume_arch_data_signal`, `publish_arch_data_signal`, `create_gate_record`, `create_pr`,
  `read_artifact`, `persist_data_side_effects`; the registry signal-name constants
  `SIGNAL_DATA_READY_FOR_TARGET` (`="data_ready_for_target"`) and `SIGNAL_TARGET_PROVISIONED`
  (`="target_provisioned"`); `RETRY_POLICIES`; a large list of shared types; `dedup_paths`; and
  `select_data_product_skill` from `data_router`.
  ⚠️ **GOTCHA-IMPORTS** (same as base): these MUST stay inside `imports_passed_through()` so the
  Temporal sandbox doesn't re-execute them on replay. Moving them top-level breaks determinism.

### 0.2 Polling-bound constants (`data.py:132-143`)
| Constant | Value | Used by |
|----------|-------|---------|
| `_TARGET_PROVISIONED_WAIT_TIMEOUT_SECONDS` | `24 * 60 * 60` (86400s = 24h) | overall cap in both `_wait_for_target_provisioned` branches |
| `_REGISTRY_POLL_INTERVAL_SECONDS` | `15` | `arch-data-registry-v1` poll cadence (`workflow.sleep`) |
| `_DB_BACKSTOP_INTERVAL_SECONDS` | `5 * 60` (300s) | `arch-data-signal-first-v1` per-iteration `wait_condition` timeout |

> ⚠️ **GOTCHA-CONST1 (symmetry, NOT cross-import):** these duplicate the values in
> `architecture.py` deliberately so the data module has **no** cross-workflow import
> (`data.py:132-143`). A rebuild MUST keep them as local literals matching Architecture's, not
> import them.

### 0.3 Module helper functions (`data.py:146-172`)

**`_encode_data_ready_payload(payload: DataReadyForTargetSignal) -> str`** (`data.py:146-155`):
```text
return json.dumps({
    "target_app_id":          payload.target_app_id,
    "data_architecture_ref":  payload.data_architecture_ref,
    "data_migration_plan_ref":payload.data_migration_plan_ref,
    "approved_at":            payload.approved_at,
})
```
Serializes the reply signal for the registry-publish activity (activity schema is primitive-only).

**`_decode_target_provisioned_payload(payload_json: str) -> dict`** (`data.py:158-172`):
```text
if not payload_json:                       # data.py:164  BRANCH
    return {}
try:                                       # data.py:166
    parsed = json.loads(payload_json)
except (ValueError, TypeError):            # data.py:168  BRANCH
    return {}
if not isinstance(parsed, dict):           # data.py:170  BRANCH
    return {}
return parsed                              # data.py:172
```
⚠️ **GOTCHA-DEC1:** three defensive guards (empty/non-JSON/non-dict) all collapse to `{}`; on
`{}` the caller's `payload.get(...)` reads fall back to in-memory state populated by the legacy
signal handler (`data.py:159-163`). A rebuild MUST return `{}` on all three, NOT raise.

### 0.4 `DATA_STEPS` table (`data.py:182-244`) — `step_id -> {title, skill_id, artifact, kind, ...}`
Set as classvar `STEPS = DATA_STEPS` (`data.py:285`). **Iteration order is insertion order** and
is load-bearing (`_collect_committed_paths`, `_build_evidence_data`, `_create_gate_pr_data` all
iterate it). The 7 entries in order:

| step_id | title | skill_id | artifact | kind | extra |
|---------|-------|----------|----------|------|-------|
| `domain-discovery` | "Data Domain Discovery" | `data-domain-patterns` | `data-domains.json` | agent | — |
| `shared-db-analysis` | "Shared Database Analysis" | `decomposition-patterns` | `shared-db-analysis.json` | agent | — |
| `decomposition-strategy` | "Decomposition Strategy" | `decomposition-patterns` | `decomposition-strategy.json` | agent | — |
| `migration-planning` | "Migration Planning" | `data-migration-planner` | `data-migration-plan.json` | agent | `write_to_target=True` |
| `data-product-design` | "Data Product Design" | `data-product-specification` | `data-product-design.json` | agent | `write_to_target=True` |
| `data-synthesis` | "Data Architecture Synthesis" | `data-modeling` | `data-architecture.json` | agent | `write_to_target=True` |
| `ai-pre-review` | "AI Pre-Review" | `gate-pre-review` | `pre-review.json` | agent | `dispatch_via="base_gate_pre_review"` |

> ⚠️ **GOTCHA-STEPS1 (`ai-pre-review` is a phantom step):** it is present in `DATA_STEPS` ONLY so
> the gate-card registry matches `LineContract.evidence_steps()` and the contract-compliance CI
> guard passes (`data.py:230-243`). It is **dispatched via the base `_run_gate_pre_review` helper**
> (task_type `gate-pre-review`, skill `gate-pre-review`), **NOT** via `_run_agent_step`, so it
> **never lands in `self._step_results`**. Consequences: it is skipped by `_build_evidence_data`
> (which `continue`s on empty `_step_results`), skipped by `_collect_committed_paths` (no committed
> paths), and skipped by `_create_gate_pr_data`'s `steps_run` filter (`name in self._step_results`).
> A rebuild MUST include it in the table for CI parity but MUST NOT dispatch it through the
> per-step agent path.

> ⚠️ **GOTCHA-STEPS2 (`write_to_target` flag drives the mirror commit):** the 3 design-deliverable
> steps (`migration-planning`, `data-product-design`, `data-synthesis`) carry
> `write_to_target=True` (`data.py:214,221,228`). In `_run_agent_step`, when this flag is set AND a
> target repo URL is known, the step's agent **file** artifacts are mirrored to the per-target
> modernization repo under `docs/data/{step}/`; the summary JSON always stays in the portfolio
> `artifact_repo`. The other steps never mirror. A rebuild MUST gate mirroring on this exact flag.

### 0.5 `STEP_WEIGHTS` (`data.py:247-264`) — set as classvar `STEP_WEIGHTS` (`data.py:286`)
Progress weights summing to **exactly 100.0** (asserted at module load, `data.py:262-264` — `assert
abs(sum - 100.0) < 0.01`). ⚠️ **GOTCHA-WT0:** this is 13 entries (the 12 contract steps + the
`wait-for-target-provisioned` step-0 marker), NOT the 7 `DATA_STEPS` keys. The weights are:

| step | weight | | step | weight |
|------|-------:|-|------|-------:|
| `wait-for-target-provisioned` | 2.0 | | `data-synthesis` | 14.0 |
| `domain-discovery` | 10.0 | | `commit-data-artifacts` | 2.0 |
| `shared-db-analysis` | 12.0 | | `create-g-dt-pr` | 2.0 |
| `decomposition-strategy` | 12.0 | | `ai-pre-review` | 4.0 |
| `migration-planning` | 14.0 | | `gate-review-dt` | 14.0 |
| `data-product-design` | 10.0 | | `persist-data-side-effects` | 2.0 |
| | | | `merge-data-pr` | 2.0 |

⚠️ **GOTCHA-WT1 (`STEP_WEIGHTS` keys ≠ `DATA_STEPS` keys):** the weights table has step ids that do
**not** appear in `DATA_STEPS` (`wait-for-target-provisioned`, `commit-data-artifacts`,
`create-g-dt-pr`, `gate-review-dt`, `persist-data-side-effects`, `merge-data-pr`) — these are
stepper/progress markers `_set_step`-only. Conversely `ai-pre-review` is in both. Base never reads
`STEP_WEIGHTS` (GOTCHA-CV1 in base); only `run()`/`_execute_data` consume it to compute the
`progress` arg passed to `_set_step`. A rebuild MUST reproduce both tables with these exact keys.

### 0.6 `MAX_REWORK_ITERATIONS = 3` (`data.py:266`) — module-level. Rework ceiling for G-DT.

---

## 1. CLASSVAR configuration (`data.py:280-287`)
Overrides base classvars (see `_LineWorkflowBase.md` §1):
```text
ASSEMBLY_LINE   = AssemblyLine.DATA
ARTIFACT_ROOT   = "data"
LINE_LABEL      = "Data"
STATUS_PREFIX   = "data"
STEPS           = DATA_STEPS
STEP_WEIGHTS    = STEP_WEIGHTS
SINGLE_GATE_KEY = "G-DT"
```
Effects of these on inherited helpers: `_task_type_prefix()` returns `"data"` (so
`AgentTaskInput.task_type` defaults to `data-{step}` — but see GOTCHA-DA-OVR, the override builds
this string itself); `_set_step` writes status `data_in_progress`; `_create_gate_pr` (base) labels
`["gate-review","data",gate_type]` — **but Data does NOT use the base `_create_gate_pr`; it has its
own `_create_gate_pr_data`** (§7.6). `_execution_ctx` line_id = `"data"` (lowercase of LINE_LABEL).
`_rework_gate_key_for_step(step)` returns `"G-DT"` for every step (single-gate; NOT overridden).
`get_status` reports `current_line = AssemblyLine.DATA`.

---

## 2. STATE — subclass instance vars (`__init__`, `data.py:289-338`)

`__init__` calls `super().__init__()` **first** (`data.py:290`) — this initializes the 8 HIL vars
(`_HILSignalsMixin.md` §1, incl. `cancelled=False`) AND the 19 base line-state vars
(`_LineWorkflowBase.md` §2, incl. `_app_id`, `_portfolio_id`, `_wave_id`, `_risk_tier`,
`_status=PENDING`, `_gate_decisions`, `_rework_iterations`, `_step_results`,
`_step_committed_paths`, `_agent_metadata`, `_merge_retry_signalled`, etc.). Then the following
**Data-specific** vars:

| Var | Type | Initial | Line | Mutated by → value | When |
|-----|------|---------|------|---------------------|------|
| `_stakeholder_data_governance_approved` | `bool` | `False` | 294 | `stakeholder_approved` (scope `g-dt-data-governance`) → `True` (`data.py:355`); reset to `False` on gate-reject rework (`data.py:990`) | Tier-1 gate wait |
| `_stakeholder_security_approved` | `bool` | `False` | 295 | `stakeholder_approved` (scope `g-dt-security`) → `True` (`data.py:357`); reset to `False` on gate-reject rework (`data.py:991`) | Tier-1 gate wait |
| `_target_provisioned` | `bool` | `False` | 298 | `target_provisioned` signal → `True` (`data.py:401`); `_wait_for_target_provisioned` DB-backstop hit → `True` (`data.py:1170,1234`) | step 0 |
| `_architecture_workflow_id` | `str` | `""` | 299 | `target_provisioned` signal → `signal.architecture_workflow_id` (`data.py:402`); backstop payload `architecture_workflow_id` (`data.py:1171,1235`) | step 0; used for reply-signal fast path + evidence |
| `_provisioned_portfolio_id` | `str` | `""` | 300 | signal `portfolio_id` (`data.py:403`); backstop payload (`data.py:1174,1238`) | step 0 (observability) |
| `_provisioned_wave_id` | `str` | `""` | 301 | signal `wave_id` (`data.py:404`); backstop payload (`data.py:1177,1241`) | step 0 (observability) |
| `_provisioned_disposition` | `str` | `""` | 302 | signal `disposition` (`data.py:405`); backstop payload (`data.py:1178,1242`) | step 0; **drives Retire-skip** (`data.py:723`) |
| `_provisioned_target_repo_url` | `str` | `""` | 308 | signal `target_repo_url` or `""` (`data.py:408-410`); backstop payload or `""` (`data.py:1181,1245`) | step 0; **drives mirror-commit repo** (`data.py:1061-1066`) |
| `_target_service_id` | `str` | `""` | 319 | `run()` from input (`data.py:454`); signal if non-empty (`data.py:415-417`); backstop if non-empty (`data.py:1190,1254`); `_load_target_plan_entry` if still empty (`data.py:614-617`) | run+step0; **drives system-umbrella skip** + projected onto `application.target_service_id` |
| `_relationship` | `str` | `""` | 323 | `run()` from input (`data.py:455`); signal if non-empty (`data.py:418-420`); backstop if non-empty (`data.py:1195,1259`); plan if still empty, lowercased (`data.py:618-621`) | run+step0; threaded into every dispatch context |
| `_source_app_ids` | `list[str]` | `[]` | 328 | `run()` from input (`data.py:456-458`); signal if non-empty (`data.py:421-423`); backstop if non-empty (`data.py:1200,1264`); plan if still empty (`data.py:622-625`) | run+step0; threaded into dispatch context (many-to-one consolidate driver) |
| `_target_plan_entry` | `dict` | `{}` | 333 | `_load_target_plan_entry` → `dict(t)` for matched target (`data.py:610`) | step 0 (strict-fail read) |
| `_tech_fingerprint` | `dict \| None` | `None` | 338 | `run()` from `input.tech_fingerprint` (`data.py:448`) | run start; drives step-5 router |

> ⚠️ **GOTCHA-ST1 (`_provisioned_*` vs `_target_service_id`/`_relationship`/`_source_app_ids`
> precedence):** `_target_service_id`/`_relationship`/`_source_app_ids` are hydrated **3 times** in a
> specific precedence: (1) `run()` from `LineWorkflowInput` (always, even if empty → `""`/`[]`);
> (2) the `target_provisioned` signal / DB-backstop, **only if the signal/payload field is
> non-empty** (`if sig_service_id:` etc., `data.py:416-423`, `1190-1201`, `1254-1265`); (3)
> `_load_target_plan_entry`, **only if still empty** (`if not self._target_service_id:`,
> `data.py:614-625`). The "only if non-empty" / "only if still empty" guards mean Architecture's
> signal is authoritative when it speaks, the wave plan is the canonical backfill, and legacy
> callers keep `LineWorkflowInput` values. A rebuild MUST preserve all three layers AND their
> exact guards or the wrong source set / relationship leaks into skill dispatch.
>
> ⚠️ **GOTCHA-ST2 (`_relationship` is lowercased ONLY from the plan):** the signal/backstop store
> `relationship` verbatim; the plan path lowercases it (`(t.get("relationship") or "").lower()`,
> `data.py:620`). A rebuild matches: do not lowercase on the signal path.

---

## 3. SIGNAL / QUERY surface

### 3.0 Inherited signals/queries — NEVER redefine (GOTCHA-SIG0 / GOTCHA-Q1)
DataWorkflow **inherits and does NOT redefine**: `gate_approved`, `gate_rejected`,
`escalation_resolved`, `merge_retry` (base `@workflow.signal`, `_LineWorkflowBase.md` §3); the 6 HIL
signals `approve_plan`, `provide_plan_feedback`, `approve_research`, `provide_feedback`, `approve`,
`cancel_workflow` (`_HILSignalsMixin.md` §2); and the `get_status` query (base, §16). A rebuild MUST
NOT re-decorate any of these — Temporal raises on duplicate signal/query registration.

> ⚠️ **GOTCHA-SIG-DATA0 (`gate_approved`/`merge_retry`/`cancel_workflow` are the gate-routing
> backbone):** Data's gate loop consumes `_gate_decisions` (fed by inherited `gate_approved`/
> `gate_rejected`), `cancelled` (inherited `cancel_workflow`), and `_merge_retry_signalled`
> (inherited `merge_retry`). These power `_wait_for_gate_decision` and
> `_reconcile_and_merge_with_retry_loop` (both inherited). Data ADDS only the two new signals below.

### 3.1 NEW signal — `stakeholder_approved(self, signal: StakeholderApprovedSignal) -> None` — `data.py:344-363`
`async def`, `@workflow.signal`. Payload `StakeholderApprovedSignal` (`approval_id: str`,
`stakeholder: str`, `scope: str`).
```text
async def stakeholder_approved(self, signal):
    if signal.scope == "g-dt-data-governance":            # data.py:354  BRANCH
        self._stakeholder_data_governance_approved = True # data.py:355
    elif signal.scope == "g-dt-security":                 # data.py:356  BRANCH
        self._stakeholder_security_approved = True        # data.py:357
    else:                                                 # data.py:358  BRANCH
        workflow.logger.warning(                          # data.py:359-362
            "stakeholder_approved with unrecognized scope",
            extra={"scope": signal.scope})
    self._updated_at = _now_iso()                         # data.py:363
```
**Branches (3):** scope `g-dt-data-governance` (354) / `g-dt-security` (356) / unknown→warn+ignore
(358). Buffers nothing structured — flips the matching bool flag. Consumed by the **Tier-1
triple-signal `wait_condition`** in the gate-approve branch (`data.py:888-896`, §6 step 10).
⚠️ **GOTCHA-SIG-DATA1:** unknown scopes are logged and **ignored** — they do NOT raise and do NOT
flip a flag. A rebuild MUST keep the `else: warn` arm, not raise. ⚠️ Always bumps `_updated_at` even
on the ignored path (so dashboards see activity).

### 3.2 NEW signal — `target_provisioned(self, signal: TargetProvisionedSignal) -> None` — `data.py:365-424`
`async def`, `@workflow.signal`. Payload `TargetProvisionedSignal` (`target_app_id`, `portfolio_id`,
`architecture_workflow_id`, `wave_id`, `disposition`, and defaulted `target_repo_url=""`,
`target_service_id=""`, `relationship=""`, `source_app_ids=[]`).
```text
async def target_provisioned(self, signal):
    await workflow.wait_condition(lambda: bool(self._app_id))   # data.py:388  ★ AWAIT inside handler
    if signal.target_app_id != self._app_id:                    # data.py:389  BRANCH
        workflow.logger.info("target_provisioned ignored — wrong target",
                             extra={...})                        # data.py:393-399
        return                                                  # data.py:400  ← drop signal, not ours
    self._target_provisioned = True                             # data.py:401
    self._architecture_workflow_id = signal.architecture_workflow_id   # data.py:402
    self._provisioned_portfolio_id = signal.portfolio_id        # data.py:403
    self._provisioned_wave_id      = signal.wave_id             # data.py:404
    self._provisioned_disposition  = signal.disposition         # data.py:405
    self._provisioned_target_repo_url = getattr(signal, "target_repo_url", "") or ""   # data.py:408-410
    sig_service_id = getattr(signal, "target_service_id", "") or ""    # data.py:415
    if sig_service_id:                                          # data.py:416  BRANCH
        self._target_service_id = sig_service_id               # data.py:417
    sig_relationship = getattr(signal, "relationship", "") or ""       # data.py:418
    if sig_relationship:                                       # data.py:419  BRANCH
        self._relationship = sig_relationship                  # data.py:420
    sig_source_ids = list(getattr(signal, "source_app_ids", []) or [])  # data.py:421
    if sig_source_ids:                                         # data.py:422  BRANCH
        self._source_app_ids = sig_source_ids                  # data.py:423
    self._updated_at = _now_iso()                              # data.py:424
```
**Branches (4):** target-mismatch drop (389); the three "only if non-empty" guards (416/419/422).

> ⚠️ **GOTCHA-SIG-DATA2 (the `wait_condition(lambda: bool(self._app_id))` INSIDE the handler is
> the Wave-1 race fix):** the handler **awaits** until `run()` has assigned `self._app_id` before
> the mismatch compare (`data.py:388`). Without it, a signal arriving between `start_workflow` and
> `run()`'s `self._app_id = target_app_id` would compare against `""` (from `__init__`), mismatch,
> and **silently drop** (the punch-list "target_provisioned signal races workflow init",
> `data.py:384-388`). A rebuild MUST keep this `await wait_condition` as the first statement of the
> handler. (This is a signal handler that legitimately `await`s — unusual but required.)
>
> ⚠️ **GOTCHA-SIG-DATA3 (handler is a belt-and-braces fast path, not the primary delivery on the
> new shape):** Under `arch-data-registry-v1`+ Data POLLS the registry in
> `_wait_for_target_provisioned`; this signal handler is retained (a) so pre-patch in-flight
> histories replay deterministically and (b) as a fast path — if a stray signal arrives (test
> harness still firing it) the handler hydrates state and the registry poll short-circuits on the
> in-memory `_target_provisioned` flag (`data.py:369-381`). A rebuild MUST keep the handler even
> though the registry poll is primary.
>
> ⚠️ **GOTCHA-SIG-DATA4 (`getattr(..., default) or ""` for pre-PR-A3 senders):**
> `target_repo_url`, `target_service_id`, `relationship`, `source_app_ids` are read via
> `getattr(signal, ..., default)` because older senders predate those fields (`data.py:408-421`).
> The `... or ""` / `... or []` normalizes `None`. A rebuild MUST keep defensive `getattr` so an
> older `TargetProvisionedSignal` doesn't raise `AttributeError`.

### 3.3 Query surface
Only the inherited `get_status` (base §16). Data adds **no** new queries. A rebuild MUST NOT
redefine `get_status`.

---

## 4. `run(self, input: LineWorkflowInput) -> str` — `@workflow.run` (`data.py:430-489`)

The entry point. Hydrates state, computes branch/workspace names, delegates to `_execute_data` in a
try/except that maps any exception to terminal FAILED + best-effort status push.

```text
@workflow.run
async def run(self, input):
    self._status     = WorkflowStatus.RUNNING       # data.py:433
    self._started_at = _now_iso()                   # data.py:434
    self._updated_at = self._started_at             # data.py:435

    target_app_id = input.app_id                    # data.py:440  ← app_id IS the TARGET
    self._app_id        = target_app_id             # data.py:441   (unblocks the signal-handler wait_condition)
    self._portfolio_id  = input.portfolio_id        # data.py:442
    self._wave_id       = input.wave_id             # data.py:443
    self._risk_tier     = getattr(input, "risk_tier", None)        # data.py:444
    self._tech_fingerprint = getattr(input, "tech_fingerprint", None)   # data.py:448
    self._target_service_id = getattr(input, "target_service_id", "") or ""   # data.py:454
    self._relationship      = getattr(input, "relationship", "") or ""        # data.py:455
    self._source_app_ids    = list(getattr(input, "source_app_ids", []) or [])# data.py:456-458

    self._artifact_repo = input.artifact_repo       # data.py:467
    wf_id      = workflow.info().workflow_id        # data.py:468
    run_suffix = wf_id.rsplit("-", 1)[-1] if "-" in wf_id else wf_id[:8]   # data.py:469  BRANCH (inline)
    branch        = f"olympus/data/{target_app_id}/{run_suffix}"   # data.py:470
    workspace_key = f"data-{target_app_id}-{run_suffix}"           # data.py:471

    try:                                            # data.py:473
        return await self._execute_data(input, target_app_id, "", branch, workspace_key)   # data.py:476-478
    except Exception:                               # data.py:479  BRANCH (catch-all)
        self._status       = WorkflowStatus.FAILED  # data.py:480
        self._current_step = "failed"               # data.py:481
        self._updated_at   = _now_iso()             # data.py:482
        try:                                        # data.py:483
            await self._update_app_status(target_app_id, "data_failed", "failed", "Data")  # data.py:484-486
        except Exception:                           # data.py:487  BRANCH (best-effort)
            pass                                    # data.py:488
        raise                                       # data.py:489  ← re-raise to fail the workflow
```

**Branches (4):** the inline `run_suffix` conditional (469); outer `except Exception` (479); inner
status-push `try`/`except…pass` (483-488); the final `raise`.

> ⚠️ **GOTCHA-RUN1 (`self._app_id = target_app_id` is the race-unblock):** setting `_app_id` here
> (`data.py:441`) is what releases the `wait_condition(lambda: bool(self._app_id))` inside
> `target_provisioned` (GOTCHA-SIG-DATA2). A rebuild MUST set `_app_id` early in `run()`.
>
> ⚠️ **GOTCHA-RUN2 (`repo=""` passed to `_execute_data`; resolved later):** `run()` passes `""`
> for the `repo` arg (`data.py:476`) because the commit repo is resolved INSIDE `_execute_data`
> after step 0 (`repo = self._artifact_repo`, `data.py:683`). A rebuild MUST NOT resolve the repo
> in `run()`. ⚠️ The comment at `data.py:467-466` is the wrong way round in source but the behavior
> is: `_artifact_repo` is set from `input.artifact_repo` and used for ALL commits (the per-target
> modernization repo is only a *mirror* target, see GOTCHA-STEPS2 / GOTCHA-REPO).
>
> ⚠️ **GOTCHA-RUN3 (the except RE-RAISES):** unlike many best-effort paths, the outer
> `except Exception` sets FAILED, does a best-effort DB push, then **`raise`s** (`data.py:489`) so
> Temporal records the workflow as failed. The inner DB-push `except…pass` is the only swallow. A
> rebuild MUST re-raise the outer exception. ⚠️ `run_suffix` matches base
> Architecture's branch-naming convention; `branch`/`workspace_key` are deterministic from
> `workflow_id` (replay-safe).

---

## 5. Helper: `_read_target_source_artifacts_index(...)` — `data.py:491-541`

Best-effort read of the target's `source-artifacts-index.json` (the artifact-level link back to
each absorbed source app's Discovery + Rationalization outputs for Consolidate/Replace targets).
**Returns `[]` on any miss** (legacy/in-flight runs fall back to `input.prior_artifacts`).

```text
async def _read_target_source_artifacts_index(self, input, target_app_id) -> list[str]:
    if not input.wave_id or not input.artifact_repo:    # data.py:505  BRANCH
        return []                                       # data.py:506
    index_path = f"rationalization/wave-{input.wave_id}/targets/{target_app_id}/source-artifacts-index.json"  # data.py:507-510
    try:                                                # data.py:511
        result = await workflow.execute_activity(
            read_artifact,
            ReadArtifactInput(repo=input.artifact_repo, branch="main", path=index_path),
            start_to_close_timeout=timedelta(seconds=30),               # data.py:519
            retry_policy=RETRY_POLICIES["transient"],                   # data.py:520
            activity_id=f"read-target-source-index-{target_app_id}")    # data.py:521
    except Exception:                                   # data.py:523  BRANCH (index optional)
        return []                                       # data.py:524
    try:                                                # data.py:526
        payload = json.loads(result.content)
    except Exception:                                   # data.py:528  BRANCH (malformed → skip)
        return []                                       # data.py:529
    paths: list[str] = []
    for source in payload.get("source_apps", []) or []:         # data.py:532  LOOP
        artifacts = source.get("artifacts", {}) or {}           # data.py:533
        for key in ("discovery", "rationalization"):            # data.py:534  LOOP
            for p in artifacts.get(key, []) or []:              # data.py:535  LOOP
                if isinstance(p, str) and p:                    # data.py:536  BRANCH
                    paths.append(p)                             # data.py:537
    for p in payload.get("shared_artifacts", []) or []:         # data.py:538  LOOP
        if isinstance(p, str) and p:                            # data.py:539  BRANCH
            paths.append(p)                                     # data.py:540
    return paths                                                # data.py:541
```
**Branches (8):** missing wave/repo guard (505); read `try/except→[]` (523); json `try/except→[]`
(528); 4 nested loops (532/534/535/538); 2 `isinstance(p,str) and p` guards (536/539).

> ⚠️ **GOTCHA-IDX1 (activity_id keyed on target):** `activity_id=f"read-target-source-index-{target_app_id}"`
> (`data.py:521`) — deterministic on replay. Activity timeout **30s**, `transient` (3 attempts).
> ⚠️ **GOTCHA-IDX2 (totally best-effort):** missing index, read failure, malformed JSON all →
> `[]`. The caller (`_execute_data`) appends these paths to `prior_inputs` only when non-empty AND
> only under the `data-source-index-v1` patch. A rebuild MUST return `[]` (never raise) on every
> failure. ⚠️ Only `str`-and-truthy paths are collected (defensive against null/empty entries).

---

## 6. Helper: `_load_target_plan_entry(...)` — `data.py:543-639` ★ STRICT-FAIL

Reads this target's entry from `architecture/wave-{wave_id}/architecture-target-plan.json`, stashes
it on `_target_plan_entry`, and **back-fills** `_target_service_id`/`_relationship`/`_source_app_ids`
when the signal was silent. **Unlike the index read, this RAISES `ApplicationError(non_retryable)`
on miss / malformed / target-not-in-plan** — a missing plan is a deployment bug, not a legacy
fallback (`data.py:558-566`).

```text
async def _load_target_plan_entry(self, input, target_app_id) -> None:
    if not input.wave_id or not input.artifact_repo:           # data.py:567  BRANCH
        raise ApplicationError("... missing wave_id or artifact_repo ...", non_retryable=True)  # data.py:568-572
    plan_path = f"architecture/wave-{input.wave_id}/architecture-target-plan.json"  # data.py:573-576
    try:                                                       # data.py:577
        read_result = await workflow.execute_activity(
            read_artifact,
            ReadArtifactInput(repo=input.artifact_repo, branch="main", path=plan_path),
            start_to_close_timeout=timedelta(seconds=30),          # data.py:585
            retry_policy=RETRY_POLICIES["transient"],              # data.py:586
            activity_id=f"read-data-target-plan-{target_app_id}")  # data.py:587
    except Exception as exc:                                   # data.py:589  BRANCH
        raise ApplicationError(f"architecture-target-plan.json not found at {plan_path!r} ...",
                               non_retryable=True) from exc    # data.py:590-596
    try:                                                       # data.py:598
        plan = json.loads(read_result.content)
    except Exception as exc:                                   # data.py:600  BRANCH
        raise ApplicationError(f"... malformed JSON ...", non_retryable=True) from exc  # data.py:601-606

    for t in plan.get("targets") or []:                        # data.py:608  LOOP
        if isinstance(t, dict) and t.get("target_app_id") == target_app_id:   # data.py:609  BRANCH
            self._target_plan_entry = dict(t)                  # data.py:610
            if not self._target_service_id:                    # data.py:614  BRANCH (back-fill)
                self._target_service_id = (t.get("target_service_id") or "")   # data.py:615-617
            if not self._relationship:                         # data.py:618  BRANCH (back-fill)
                self._relationship = ((t.get("relationship") or "").lower())   # data.py:619-621
            if not self._source_app_ids:                       # data.py:622  BRANCH (back-fill)
                self._source_app_ids = list(t.get("source_app_ids") or [])     # data.py:623-625
            return                                             # data.py:626  ← matched → done
    target_ids_in_plan = [(t.get("target_app_id") or "") for t in (plan.get("targets") or [])
                          if isinstance(t, dict)]              # data.py:628-632
    raise ApplicationError(f"target_app_id={target_app_id!r} not present in plan ...",
                           non_retryable=True)                 # data.py:633-639  ← unmatched → FAIL
```
**Branches (8):** missing wave/repo raise (567); read `try/except→raise` (589); json
`try/except→raise` (600); `for t` loop (608); `isinstance(t,dict) and ...==target_app_id` match
(609); 3 back-fill guards (614/618/622); final unmatched-raise (633).

> ⚠️ **GOTCHA-PLAN1 (STRICT-FAIL — the opposite of the index read):** every failure raises
> `ApplicationError(non_retryable=True)` (`data.py:568,590,601,633`). The previous best-effort
> fallback masked a wave-grain bug; the coordinator MUST commit the plan before per-target Data
> children spawn (`data.py:558-565`). A rebuild MUST raise (not return) here, and the errors MUST
> be `non_retryable` so Temporal doesn't burn retries on a structurally-missing plan. These
> exceptions propagate up through `_execute_data` to `run()`'s `except` → workflow FAILED.
>
> ⚠️ **GOTCHA-PLAN2 (back-fill ONLY when still empty):** the three `if not self._...:` guards
> (614/618/622) implement layer-3 of GOTCHA-ST1 — the plan only fills a field the signal left empty.
> `relationship` is `.lower()`-normalized here (GOTCHA-ST2). A rebuild MUST keep the guards.
>
> ⚠️ **GOTCHA-PLAN3 (`dict(t)` copy):** `_target_plan_entry = dict(t)` (`data.py:610`) takes a
> shallow copy of the matched entry, not a reference. A rebuild copies.

---

## 7. `_execute_data(...)` — CORE ORCHESTRATION (`data.py:641-1020`) ★★★

The 12-step canonical shape. Signature `(self, input, target_app_id, repo, branch, workspace_key)`.
`repo` arrives as `""` and is reassigned at `data.py:683`.

### 7.0 Prologue + optional source-index merge (`data.py:650-668`)
```text
running_progress = 0.0                                  # data.py:650
prior_inputs = list(input.prior_artifacts)              # data.py:651  ← mutable copy

if workflow.patched("data-source-index-v1"):            # data.py:658  BRANCH (patch gate)
    indexed_paths = await self._read_target_source_artifacts_index(input, target_app_id)  # data.py:659
    if indexed_paths:                                   # data.py:662  BRANCH
        seen = set(prior_inputs)                        # data.py:663
        for p in indexed_paths:                         # data.py:664  LOOP
            if p not in seen:                           # data.py:665  BRANCH
                prior_inputs.append(p)
                seen.add(p)
```
⚠️ **GOTCHA-EXD0 (`data-source-index-v1` patch — verbatim, load-bearing):** the index merge runs
ONLY under this patch so pre-patch in-flight runs replay without the extra `read_artifact` activity
(history determinism). The merge **appends** indexed paths not already in `prior_inputs`
(de-dup via `seen` set, preserving order). A rebuild MUST use the exact patch id and the
append-if-unseen merge.

### 7.1 Step 0 — Wait for Target Provisioned (`data.py:669-683`)
```text
await self._set_step("wait-for-target-provisioned", running_progress)   # data.py:673  (progress 0.0)
await self._wait_for_target_provisioned()                               # data.py:676  (§8 — BLOCKS)
running_progress += STEP_WEIGHTS["wait-for-target-provisioned"]         # data.py:677  (→ 2.0)
repo = self._artifact_repo                                              # data.py:683  ← repo resolved HERE
```
⚠️ **GOTCHA-REPO (step-contract artifacts go to `artifact_repo`; only design deliverables mirror):**
the repo-routing rule (2026-05-08) is that ALL step-contract artifacts land in the portfolio
`artifact_repo` (same as every other line); the per-target modernization repo
(`_provisioned_target_repo_url`) is ONLY a mirror target for `write_to_target` steps' file artifacts
(`data.py:679-683`). So `repo = self._artifact_repo` for every commit. A rebuild MUST NOT route
primary commits to the modernization repo.

### 7.2 Step 0.5 — load wave-scoped plan (`data.py:685-692`)
```text
await self._load_target_plan_entry(input, target_app_id)               # data.py:692  (§6 — STRICT-FAIL)
```
Runs AFTER `_wait_for_target_provisioned` (so signal-sourced fields take precedence in the back-fill
guards). Raises on miss (GOTCHA-PLAN1).

### 7.3 System-umbrella skip (`data.py:701-719`) ★ EARLY RETURN
```text
if (self._target_service_id == "system"
        or self._target_plan_entry.get("target_service_id") == "system"):   # data.py:701-704  BRANCH
    await self._fire_data_ready_signal(data_architecture_ref="", data_migration_plan_ref="")  # data.py:705-708
    await self._update_app_status(target_app_id, "data_skipped_system_umbrella", "completed", "Data")  # data.py:709-714
    self._status       = WorkflowStatus.COMPLETED   # data.py:715
    self._progress_pct = 100.0                       # data.py:716
    self._current_step = "completed"                 # data.py:717
    self._updated_at   = _now_iso()                  # data.py:718
    return "completed"                               # data.py:719
```
⚠️ **GOTCHA-SKIP-SYS:** the umbrella check ORs two sources — the hydrated `_target_service_id`
field AND the raw plan-entry field — so a stale/empty `_target_service_id` still skips if the plan
says `system` (`data.py:701-704`). When the target is the cross-cutting "system" umbrella (shared
libs, design system, encryption — not a per-service S1..S11 row) there is no schema to merge: it
**fires `DataReadyForTargetSignal` with EMPTY refs** so Architecture's step 5 still unblocks, marks
`data_skipped_system_umbrella`, completes. A rebuild MUST fire the ready signal even on skip — else
Architecture deadlocks waiting for Data.

### 7.4 Retire skip (`data.py:721-735`) ★ EARLY RETURN
```text
if self._provisioned_disposition == "Retire":          # data.py:723  BRANCH
    await self._fire_data_ready_signal(data_architecture_ref="", data_migration_plan_ref="")  # data.py:724-727
    await self._update_app_status(target_app_id, "data_skipped_retire", "completed", "Data")  # data.py:728-730
    self._status = WorkflowStatus.COMPLETED; self._progress_pct = 100.0
    self._current_step = "completed"; self._updated_at = _now_iso()
    return "completed"                                  # data.py:735
```
⚠️ **GOTCHA-SKIP-RETIRE:** keyed on `_provisioned_disposition == "Retire"` (the signal's
`disposition`, NOT `_relationship`). Same empty-refs-ready-signal contract. Note: there is NO
explicit "Retain" skip branch despite the docstring of `TargetProvisionedSignal` mentioning it —
Retain targets run the full line. A rebuild MUST skip ONLY on `"Retire"` here.

### 7.5 Steps 1+2 — Domain Discovery ∥ Shared-DB Analysis (`data.py:737-776`)
```text
if workflow.patched("data-parallel-fanout-v1"):        # data.py:745  BRANCH (patch gate)
    await self._set_step("domain-discovery", running_progress)   # data.py:746
    parallel_inputs = prior_inputs                       # data.py:747  ← BOTH read the SAME inputs
    dd_task  = self._run_agent_step_task("domain-discovery",  target_app_id, parallel_inputs,
                                         input.source_repo, workspace_key, repo, branch)   # data.py:748-751
    sdb_task = self._run_agent_step_task("shared-db-analysis", target_app_id, parallel_inputs,
                                         input.source_repo, workspace_key, repo, branch)   # data.py:752-755
    await asyncio.gather(dd_task, sdb_task)              # data.py:756  ★ PARALLEL
    running_progress += STEP_WEIGHTS["domain-discovery"] + STEP_WEIGHTS["shared-db-analysis"]  # data.py:757-760 (→ 24.0)
    prior_inputs = self._collect_committed_paths()      # data.py:761
else:                                                   # data.py:762  BRANCH (legacy sequential)
    await self._run_agent_step("domain-discovery", target_app_id, prior_inputs,
                               input.source_repo, workspace_key, repo, branch)   # data.py:764-767
    running_progress += STEP_WEIGHTS["domain-discovery"]    # data.py:768  (→ 12.0)
    prior_inputs = self._collect_committed_paths()          # data.py:769
    await self._run_agent_step("shared-db-analysis", target_app_id, prior_inputs,
                               input.source_repo, workspace_key, repo, branch)   # data.py:771-774
    running_progress += STEP_WEIGHTS["shared-db-analysis"]  # data.py:775  (→ 24.0)
    prior_inputs = self._collect_committed_paths()          # data.py:776
```
**Branches (2):** `data-parallel-fanout-v1` patch (745) vs legacy else (762).

> ⚠️ **GOTCHA-FANOUT1 (`data-parallel-fanout-v1` patch — verbatim, replay determinism):**
> pre-2026-05-08 in-flight runs replay the **sequential** shape (1→2); post-patch they fan out via
> `asyncio.gather`. The two steps both consume the SAME source application (`parallel_inputs =
> prior_inputs`) and neither reads the other's output (`data.py:737-744`), so the fan-out is safe.
> A rebuild MUST gate the fan-out on this exact patch id; changing it breaks replay of pre-patch
> histories.
> ⚠️ **GOTCHA-FANOUT2 (`_run_agent_step_task` returns a COROUTINE, not a Task):** `_run_agent_step_task`
> (`data.py:1075-1089`) just *returns* `self._run_agent_step(...)` (an un-awaited coroutine);
> `asyncio.gather` schedules both. Each coroutine internally awaits `dispatch_agent_task` (1-3h) and
> the commit batch. ⚠️ **Determinism caveat:** under Temporal, `asyncio.gather` over two
> `execute_activity` calls issues both commands in one workflow task; the ORDER of command emission
> is the order of the gather args (dd before sdb). A rebuild MUST keep arg order stable.
> ⚠️ **GOTCHA-FANOUT3 (`_set_step("domain-discovery")` fired once before the gather):** in the
> parallel branch, `_set_step` is called for `domain-discovery` only (`data.py:746`) — the stepper
> shows the pair under the first step's label. The legacy branch calls `_set_step` inside each
> `_run_agent_step`. A rebuild matches: parallel path sets step once, sequential path twice.
> ⚠️ **GOTCHA-FANOUT4 (`prior_inputs` reassigned to `_collect_committed_paths()` after each
> barrier):** after the gather (or each sequential step) `prior_inputs` becomes the full deduped set
> of all committed paths so far (`data.py:761,769,776`). So step 3 sees steps 1+2's outputs.

### 7.6 Step 3 — Decomposition Strategy (`data.py:778-784`)
```text
await self._run_agent_step("decomposition-strategy", target_app_id, prior_inputs,
                           input.source_repo, workspace_key, repo, branch)   # data.py:779-782
running_progress += STEP_WEIGHTS["decomposition-strategy"]   # data.py:783  (→ 36.0)
prior_inputs = self._collect_committed_paths()               # data.py:784
```
Sequential (consumes both step-1 and step-2 outputs).

### 7.7 Steps 4+5 — Migration Planning ∥ Data Product Design (`data.py:786-804`)
```text
await self._set_step("migration-planning", running_progress)   # data.py:790
mp_task  = self._run_agent_step_task("migration-planning",  target_app_id, prior_inputs,
                                     input.source_repo, workspace_key, repo, branch)   # data.py:791-794
dpd_task = self._run_agent_step_task("data-product-design", target_app_id, prior_inputs,
                                     input.source_repo, workspace_key, repo, branch)   # data.py:795-798
await asyncio.gather(mp_task, dpd_task)                        # data.py:799  ★ PARALLEL (always — NOT patch-gated)
running_progress += STEP_WEIGHTS["migration-planning"] + STEP_WEIGHTS["data-product-design"]  # data.py:800-803 (→ 60.0)
prior_inputs = self._collect_committed_paths()                 # data.py:804
```
⚠️ **GOTCHA-FANOUT5 (steps 4+5 fan-out is NOT patch-gated — always parallel):** unlike steps 1+2,
the 4+5 gather has no `workflow.patched` guard (`data.py:786-799`). This fan-out has been present
since the W19 reshape, so there are no pre-fanout histories to protect. Both consume Architecture's
best-effort artifacts (`cloud-pattern.json`, `integration-arch.json`) handled inside the skills. A
rebuild MUST run 4+5 unconditionally in parallel (gather), step set once on `migration-planning`.

### 7.8 Steps 6 + 7-12 — the GATE LOOP (`data.py:806-1020`) ★★★ THE HEART

A `while True:` loop. Each iteration: synthesis (6) → commit marker (7) → create PR (8) → gate
record + evidence → pre-review (9) → gate wait (10) → on approve: Tier-1 wait + persist + ready
signal (11) + merge (12) + COMPLETE; on reject: reset stakeholder flags, bump rework, fail-if-over-
ceiling, else re-dispatch steps 1-5 and loop. On cancel: return `"cancelled"`.

```text
while True:                                              # data.py:807  ★ GATE LOOP
    # --- Step 6 — Data Synthesis (sequential) ---
    await self._run_agent_step("data-synthesis", target_app_id, prior_inputs,
                               input.source_repo, workspace_key, repo, branch)   # data.py:809-812
    synthesis_progress = running_progress + STEP_WEIGHTS["data-synthesis"]       # data.py:813-815 (→ 74.0)

    # --- Step 7 — Commit marker (logical only; per-step commits already done) ---
    await self._set_step("commit-data-artifacts", synthesis_progress)            # data.py:820-822
    commit_progress = synthesis_progress + STEP_WEIGHTS["commit-data-artifacts"] # data.py:823-825 (→ 76.0)

    # --- Step 8 — Create G-DT PR ---
    artifact_paths = dedup_paths(self._collect_committed_paths())                # data.py:828
    await self._set_step("create-g-dt-pr", commit_progress)                      # data.py:829
    pr_result = await self._create_gate_pr_data(repo, branch, target_app_id, input)   # data.py:830-832 (§7.6 helper)
    pr_progress = commit_progress + STEP_WEIGHTS["create-g-dt-pr"]               # data.py:833 (→ 78.0)

    gate_record = await workflow.execute_activity(
        create_gate_record,
        CreateGateRecordInput(gate_type="G-DT", app_id=target_app_id,
                              portfolio_id=input.portfolio_id,
                              workflow_id=workflow.info().workflow_id,
                              evidence_package_url=pr_result.pr_url),
        start_to_close_timeout=timedelta(seconds=30),                            # data.py:844
        retry_policy=RETRY_POLICIES["transient"])                                # data.py:845
    gate_id = gate_record.gate_id                                                # data.py:847

    await self._submit_gate_evidence(                                            # data.py:849-858  (INHERITED §11)
        gate_id=gate_id, gate_type=GateType.G_DT, app_id=target_app_id,
        artifact_paths=artifact_paths, pr_url=pr_result.pr_url,
        assembly_line="Data", step="gate-review-dt",
        forward_risk_tier=True)                                                  # ← Data forwards risk tier

    # --- Step 9 — AI Pre-Review (INHERITED §12) ---
    await self._set_step("ai-pre-review", pr_progress)                           # data.py:861
    await self._run_gate_pre_review(gate_id, "G-DT", artifact_paths,
                                    artifact_repo=repo, artifact_ref=branch)     # data.py:862-868
    pre_review_progress = pr_progress + STEP_WEIGHTS["ai-pre-review"]            # data.py:869-871 (→ 82.0)

    # --- Step 10 — Gate G-DT (INHERITED §13 _wait_for_gate_decision) ---
    await self._set_step("gate-review-dt", pre_review_progress)                  # data.py:874
    await self._update_app_status(target_app_id, "gate_review", "gate-review-dt", "Data")  # data.py:875-878

    decision = await self._wait_for_gate_decision(GateType.G_DT)                 # data.py:880  ★ BLOCKS
    if decision == "cancelled":                          # data.py:881  BRANCH
        return "cancelled"                               # data.py:882  ← early return (NO status set here)
    if decision == "approved":                           # data.py:883  BRANCH
        # ----- Tier-1 triple-signal wait -----
        if self._risk_tier == 1:                         # data.py:887  BRANCH
            await workflow.wait_condition(lambda: (
                (self._stakeholder_data_governance_approved
                 and self._stakeholder_security_approved)
                or self.cancelled))                      # data.py:888-896  ★ BLOCKS (Tier-1 only)
            if self.cancelled:                           # data.py:897  BRANCH
                self._status = WorkflowStatus.CANCELLED  # data.py:898
                return "cancelled"                       # data.py:899

        # ----- Step 11 — Persist side effects + fire ready signal -----
        gate_progress = pre_review_progress + STEP_WEIGHTS["gate-review-dt"]     # data.py:908-910 (→ 96.0)
        await self._set_step("persist-data-side-effects", gate_progress)        # data.py:911-913

        data_architecture_ref   = f"data/{target_app_id}/{DATA_STEPS['data-synthesis']['artifact']}"     # data.py:915-918
        data_migration_plan_ref = f"data/{target_app_id}/{DATA_STEPS['migration-planning']['artifact']}" # data.py:919-922
        architecture_json  = ""                          # data.py:923
        decomposition_json = ""                          # data.py:924
        if self._step_results.get("data-synthesis"):     # data.py:925  BRANCH
            architecture_json  = self._step_results["data-synthesis"][0]         # data.py:926-928
        if self._step_results.get("decomposition-strategy"):  # data.py:929  BRANCH
            decomposition_json = self._step_results["decomposition-strategy"][0] # data.py:930-932
        try:                                             # data.py:933
            await workflow.execute_activity(
                persist_data_side_effects,
                PersistDataSideEffectsInput(
                    target_app_id=target_app_id, target_name=input.app_name,
                    target_portfolio_id=input.portfolio_id,
                    data_architecture_json=architecture_json,
                    decomposition_strategy_json=decomposition_json,
                    data_architecture_ref=data_architecture_ref,
                    data_migration_plan_ref=data_migration_plan_ref,
                    decided_at=_now_iso(),
                    target_service_id=self._target_service_id),
                start_to_close_timeout=timedelta(seconds=60),                    # data.py:947
                retry_policy=RETRY_POLICIES["transient"],                        # data.py:948
                activity_id="persist-data-side-effects")                         # data.py:949
        except Exception:                                # data.py:951  BRANCH (best-effort)
            workflow.logger.exception("persist_data_side_effects failed; "
                "application row will keep stale data fields")                   # data.py:952-955

        await self._fire_data_ready_signal(data_architecture_ref=data_architecture_ref,
                                           data_migration_plan_ref=data_migration_plan_ref)  # data.py:957-960 (§9)
        persist_progress = gate_progress + STEP_WEIGHTS["persist-data-side-effects"]  # data.py:961-964 (→ 98.0)

        # ----- Step 12 — Merge PR (INHERITED §14 retry/merge_blocked loop) -----
        await self._set_step("merge-data-pr", persist_progress)                  # data.py:967
        await self._reconcile_and_merge_with_retry_loop(
            repo=repo, pr_number=pr_result.pr_number, gate_id=gate_id, merge_method="merge")  # data.py:970-975
        await self._update_app_status(target_app_id, "data_complete", "completed", "Data")    # data.py:976-979
        self._status = WorkflowStatus.COMPLETED          # data.py:980
        self._progress_pct = 100.0                       # data.py:981
        self._current_step = "completed"                 # data.py:982
        self._updated_at = _now_iso()                    # data.py:983
        return "completed"                               # data.py:984  ← SUCCESS exit

    # --- Gate REJECTED → rework ---
    self._stakeholder_data_governance_approved = False   # data.py:990  ★ reset per-rework flags
    self._stakeholder_security_approved = False          # data.py:991

    self._bump_rework("G-DT")                            # data.py:993  ★ counter bumped HERE (subclass)
    if self._rework_count("G-DT") > MAX_REWORK_ITERATIONS:   # data.py:994  BRANCH (ceiling)
        self._status = WorkflowStatus.FAILED             # data.py:995
        self._current_step = "max-rework-exceeded"       # data.py:996
        self._updated_at = _now_iso()                    # data.py:997
        await self._update_app_status(target_app_id, "data_failed", "max-rework-exceeded", "Data")  # data.py:998-1001
        return "failed"                                  # data.py:1002  ← FAIL exit

    # --- Re-dispatch steps 1-5 (NOT step 0) then loop back to synthesis ---
    running_progress = STEP_WEIGHTS["wait-for-target-provisioned"]   # data.py:1007  ← reset to 2.0
    for step_name in ("domain-discovery", "shared-db-analysis", "decomposition-strategy",
                      "migration-planning", "data-product-design"):  # data.py:1008-1014  LOOP
        await self._run_agent_step(step_name, target_app_id, prior_inputs,
                                   input.source_repo, workspace_key, repo, branch)   # data.py:1015-1018
        running_progress += STEP_WEIGHTS[step_name]      # data.py:1019
        prior_inputs = self._collect_committed_paths()   # data.py:1020
    # loop back to while-True top → re-run synthesis (step 6) → new PR → new gate
```

**Branch inventory for §7.8 (10):** `decision == "cancelled"` (881); `decision == "approved"`
(883); `_risk_tier == 1` (887); inner `if self.cancelled` after Tier-1 wait (897);
`_step_results.get("data-synthesis")` (925); `_step_results.get("decomposition-strategy")` (929);
persist `try/except` (933-955); rework ceiling `> MAX_REWORK_ITERATIONS` (994); the rework
re-dispatch `for` loop (1008); (implicit `else`: `decision == "rejected"` falls through to rework).

> ⚠️ **GOTCHA-GATE1 (cancel from `_wait_for_gate_decision` returns `"cancelled"` WITHOUT setting
> `_status`):** at `data.py:881-882` the cancel return does NOT set `_status=CANCELLED` — because
> `_wait_for_gate_decision` already set it (base `base.py:829`). But the Tier-1 inner cancel
> (`data.py:897-899`) DOES set `_status=CANCELLED` explicitly because that `wait_condition` is in
> the SUBCLASS, not the base. A rebuild MUST: not set status on the step-10 cancel (base already
> did), but DO set `CANCELLED` on the Tier-1 inner cancel.
>
> ⚠️ **GOTCHA-GATE2 (Tier-1 triple-signal — PM merge AND BOTH stakeholder signals):** for
> `_risk_tier == 1`, after `_wait_for_gate_decision` returns `"approved"` (PM merged the gate PR /
> fired `gate_approved`), Data ADDITIONALLY blocks on
> `wait_condition(lambda: (gov AND sec) or cancelled)` (`data.py:888-896`). Tier-2/3 short-circuit
> (no extra wait). The two stakeholder flags are set by the `stakeholder_approved` signal
> (scope `g-dt-data-governance` / `g-dt-security`). A rebuild MUST AND both flags AND only for
> Tier-1, and MUST OR in `cancelled` so the wait is cancellable.
>
> ⚠️ **GOTCHA-GATE3 (`_bump_rework` is in the SUBCLASS, on the rejected branch):** per base
> GOTCHA-WG5/RW1, `_wait_for_gate_decision` does NOT touch `_rework_iterations`. Data bumps it at
> `data.py:993` ONLY on rejection, then checks `> MAX_REWORK_ITERATIONS` (3). So the loop runs at
> most 4 gate attempts (initial + 3 reworks): on the 4th rejection `_rework_count` returns 4 > 3 →
> FAIL. A rebuild MUST bump exactly once per rejection in the subclass, check strict `>`.
>
> ⚠️ **GOTCHA-GATE4 (reset stakeholder flags BEFORE bump — prevents cross-cycle leak):** the two
> `self._stakeholder_*_approved = False` resets (`data.py:990-991`) happen at the TOP of the reject
> branch, before `_bump_rework`, so a prior cycle's stakeholder approvals don't satisfy the next
> cycle's Tier-1 wait (`data.py:986-991`, "Matches the Architecture PR 2 bug-fix pattern"). A
> rebuild MUST reset both flags on every rework iteration. (Note: `_rework_feedback["G-DT"]` is set
> by the base `_wait_for_gate_decision` on the rejected path and is forwarded by the override
> `_dispatch_agent` on the re-dispatch — see §10.)
>
> ⚠️ **GOTCHA-GATE5 (rework re-dispatches steps 1-5, NOT step 0; resets progress to 2.0):** the
> rework `for` loop (`data.py:1008-1014`) iterates exactly `("domain-discovery",
> "shared-db-analysis", "decomposition-strategy", "migration-planning", "data-product-design")` —
> note these run **sequentially** here even though the first pass fanned 1+2 and 4+5 out. Step 0
> (`wait-for-target-provisioned`) is skipped because target identity doesn't change on rework
> (`data.py:1004-1007`). `running_progress` is reset to `STEP_WEIGHTS["wait-for-target-provisioned"]`
> = 2.0. Then the loop falls back to `while True` top → re-runs step 6 (synthesis) → new PR → new
> gate. A rebuild MUST re-dispatch exactly these 5 steps sequentially, skip step 0, reset progress
> to 2.0, and loop.
>
> ⚠️ **GOTCHA-GATE6 (`persist_data_side_effects` is best-effort; ready signal fires regardless):**
> the persist activity is wrapped in `try/except` that logs and continues (`data.py:933-955`) so a
> failed projection doesn't block gate approval. `_fire_data_ready_signal` is OUTSIDE the try, so
> it fires whether or not persist succeeded. A rebuild MUST keep persist best-effort and fire the
> ready signal unconditionally. ⚠️ `architecture_json`/`decomposition_json` default `""` and are
> only populated from `_step_results[...][0]` when present (defensive, `data.py:925-932`).
>
> ⚠️ **GOTCHA-GATE7 (refs are computed strings, not read from results):**
> `data_architecture_ref` = `f"data/{target_app_id}/data-architecture.json"` and
> `data_migration_plan_ref` = `f"data/{target_app_id}/data-migration-plan.json"` (`data.py:915-922`)
> — built from the `DATA_STEPS` artifact names, NOT from agent output. These same refs are passed
> to BOTH `persist_data_side_effects` AND `_fire_data_ready_signal`. A rebuild MUST compute them
> identically.
>
> ⚠️ **GOTCHA-GATE8 (`forward_risk_tier=True` — Data forwards the tier):** the
> `_submit_gate_evidence` call passes `forward_risk_tier=True` (`data.py:857`) so the
> `check_gate_criteria` input carries `evidence_data` + `risk_tier` (base GOTCHA-SE2). This differs
> from the legacy bare-shape callers. A rebuild MUST forward the tier.
>
> ⚠️ **GOTCHA-GATE9 (`merge_method="merge"`):** the merge uses `merge_method="merge"`
> (`data.py:974`), not squash/rebase, and the inherited
> `_reconcile_and_merge_with_retry_loop` handles `merge_blocked` + reviewer `merge_retry` (base
> §14). A rebuild passes `"merge"`.
>
> ⚠️ **GOTCHA-GATE10 (progress arithmetic is cumulative & re-derived each loop):** the
> `synthesis_progress`/`commit_progress`/`pr_progress`/`pre_review_progress`/`gate_progress`/
> `persist_progress` locals are recomputed each loop from `running_progress` (`data.py:813-964`).
> On a successful first pass: 60 (after step 5) → +14 synth =74 → +2 commit =76 → +2 pr =78 →
> +4 prereview =82 → +14 gate =96 → +2 persist =98 → merge step set to 98 → final forced to 100.0.
> A rebuild must reproduce these exact running totals so `get_status` progress matches.

---

## 8. `_wait_for_target_provisioned(self) -> None` — step-0 blocking wait (`data.py:1091-1288`) ★★

Three patch-gated implementations of the same contract: block until `_target_provisioned` is set
(by signal OR DB-backstop registry read) or cancellation, with a 24h overall cap. **`elif/else`
chain on patch ids** (`data.py:1112,1210,1281`).

### 8.1 `arch-data-signal-first-v1` branch (current, `data.py:1112-1209`) ★ signal-first + DB backstop
```text
if workflow.patched("arch-data-signal-first-v1"):       # data.py:1112  BRANCH
    elapsed = 0                                          # data.py:1113
    while elapsed < _TARGET_PROVISIONED_WAIT_TIMEOUT_SECONDS:   # data.py:1114  LOOP (cap 86400)
        if self._target_provisioned:                     # data.py:1117  BRANCH
            return                                       # data.py:1118  ← common fast path
        if self.cancelled:                               # data.py:1119  BRANCH
            raise RuntimeError("cancelled waiting for target-provisioned signal")  # data.py:1120-1122
        remaining = _TARGET_PROVISIONED_WAIT_TIMEOUT_SECONDS - elapsed   # data.py:1124-1126
        this_wait = min(_DB_BACKSTOP_INTERVAL_SECONDS, remaining)        # data.py:1127-1129 (≤300s)
        try:                                             # data.py:1133
            await workflow.wait_condition(
                lambda: (self._target_provisioned or self.cancelled),
                timeout=timedelta(seconds=this_wait))    # data.py:1134-1139  ★ signal-first wait
        except asyncio.TimeoutError:                     # data.py:1140  BRANCH (→ backstop)
            pass                                         # data.py:1141
        if self.cancelled:                               # data.py:1143  BRANCH
            raise RuntimeError("cancelled waiting for target-provisioned signal")  # data.py:1144-1146
        if self._target_provisioned:                     # data.py:1147  BRANCH
            return                                       # data.py:1148
        # DB backstop — ONE registry read per iteration
        result = await workflow.execute_activity(
            consume_arch_data_signal,
            ConsumeArchDataSignalInput(signal_type=SIGNAL_TARGET_PROVISIONED,
                wave_id=self._wave_id, target_app_id=self._app_id,
                workflow_id=workflow.info().workflow_id),
            start_to_close_timeout=timedelta(seconds=30),                # data.py:1159
            retry_policy=RETRY_POLICIES["transient"],                    # data.py:1160
            activity_id="consume-target-provisioned")                    # data.py:1161
        if result.found:                                 # data.py:1163  BRANCH
            payload = _decode_target_provisioned_payload(result.payload_json)   # data.py:1164-1166
            self._target_provisioned = True              # data.py:1170
            self._architecture_workflow_id   = payload.get("architecture_workflow_id", "")   # data.py:1171-1173
            self._provisioned_portfolio_id   = payload.get("portfolio_id", "")               # data.py:1174-1176
            self._provisioned_wave_id        = payload.get("wave_id", "")                     # data.py:1177
            self._provisioned_disposition    = payload.get("disposition", "")                # data.py:1178-1180
            self._provisioned_target_repo_url= payload.get("target_repo_url", "") or ""       # data.py:1181-1183
            payload_service_id = payload.get("target_service_id", "") or ""   # data.py:1187-1189
            if payload_service_id:                       # data.py:1190  BRANCH
                self._target_service_id = payload_service_id   # data.py:1191
            payload_relationship = payload.get("relationship", "") or ""      # data.py:1192-1194
            if payload_relationship:                     # data.py:1195  BRANCH
                self._relationship = payload_relationship      # data.py:1196
            payload_source_ids = list(payload.get("source_app_ids", []) or [])  # data.py:1197-1199
            if payload_source_ids:                       # data.py:1200  BRANCH
                self._source_app_ids = payload_source_ids      # data.py:1201
            self._updated_at = _now_iso()                # data.py:1202
            return                                       # data.py:1203  ← backstop hit
        elapsed += this_wait                             # data.py:1205
    raise RuntimeError("timed out waiting for target-provisioned signal (wave=... target=...)")  # data.py:1206-1209
```

### 8.2 `arch-data-registry-v1` branch (prior, `data.py:1210-1280`) ★ 15s registry poll
```text
elif workflow.patched("arch-data-registry-v1"):         # data.py:1210  BRANCH
    elapsed = 0                                          # data.py:1211
    while True:                                          # data.py:1212  LOOP
        if self._target_provisioned:                     # data.py:1213  BRANCH
            return                                       # data.py:1214
        result = await workflow.execute_activity(
            consume_arch_data_signal, ConsumeArchDataSignalInput(...same as above...),
            start_to_close_timeout=timedelta(seconds=30), retry_policy=RETRY_POLICIES["transient"],
            activity_id="consume-target-provisioned")    # data.py:1215-1226
        if result.found:                                 # data.py:1227  BRANCH
            payload = _decode_target_provisioned_payload(result.payload_json)   # data.py:1228-1230
            # ----- hydration block (data.py:1234-1267) — byte-for-byte IDENTICAL to §8.1's
            #       data.py:1170-1203 block (verified by diff); reproduced verbatim here. -----
            self._target_provisioned = True              # data.py:1234
            self._architecture_workflow_id   = payload.get("architecture_workflow_id", "")   # data.py:1235-1237
            self._provisioned_portfolio_id   = payload.get("portfolio_id", "")               # data.py:1238-1240
            self._provisioned_wave_id        = payload.get("wave_id", "")                     # data.py:1241
            self._provisioned_disposition    = payload.get("disposition", "")                # data.py:1242-1244
            self._provisioned_target_repo_url= payload.get("target_repo_url", "") or ""       # data.py:1245-1247
            payload_service_id = payload.get("target_service_id", "") or ""   # data.py:1251-1253
            if payload_service_id:                       # data.py:1254  BRANCH
                self._target_service_id = payload_service_id   # data.py:1255
            payload_relationship = payload.get("relationship", "") or ""      # data.py:1256-1258
            if payload_relationship:                     # data.py:1259  BRANCH
                self._relationship = payload_relationship      # data.py:1260
            payload_source_ids = list(payload.get("source_app_ids", []) or [])  # data.py:1261-1263
            if payload_source_ids:                       # data.py:1264  BRANCH
                self._source_app_ids = payload_source_ids      # data.py:1265
            self._updated_at = _now_iso()                # data.py:1266
            return                                       # data.py:1267  ← backstop hit
        if self.cancelled:                               # data.py:1268  BRANCH
            raise RuntimeError("cancelled waiting for target-provisioned registry entry")  # data.py:1269-1272
        if elapsed >= _TARGET_PROVISIONED_WAIT_TIMEOUT_SECONDS:   # data.py:1273  BRANCH
            raise RuntimeError("timed out waiting for target-provisioned registry entry (...)")  # data.py:1274-1278
        await workflow.sleep(_REGISTRY_POLL_INTERVAL_SECONDS)     # data.py:1279  ★ 15s sleep
        elapsed += _REGISTRY_POLL_INTERVAL_SECONDS                # data.py:1280
```

### 8.3 Legacy `else` branch (pre-registry, `data.py:1281-1288`) ★ pure in-memory wait
```text
else:                                                    # data.py:1281
    await workflow.wait_condition(lambda: self._target_provisioned or self.cancelled)  # data.py:1282-1284
    if self.cancelled:                                   # data.py:1285  BRANCH
        raise RuntimeError("cancelled waiting for target-provisioned signal")  # data.py:1286-1288
```

**Branch inventory for §8 (~24):** patch `if/elif/else` (1112/1210/1281); §8.1: `while` (1114),
`_target_provisioned` fast (1117), `cancelled` (1119), `except TimeoutError` (1140),
`cancelled` post-wait (1143), `_target_provisioned` post-wait (1147), `result.found` (1163), 3
hydration guards (1190/1195/1200); §8.2: `while` (1212), `_target_provisioned` (1213),
`result.found` (1227), 3 hydration guards (1254/1259/1264), `cancelled` (1268), timeout (1273);
§8.3: `cancelled` (1285).

> ⚠️ **GOTCHA-WAIT1 (three patch branches, EXACT verbatim ids — all retained for replay):** the
> `if arch-data-signal-first-v1 / elif arch-data-registry-v1 / else` chain (`data.py:1112-1288`)
> exists so that (a) current runs use signal-first + 5-min DB backstop, (b) mid-migration runs use
> 15s polling, (c) legacy pre-registry runs use a pure in-memory `wait_condition`. ATLAS Challenge
> 3 observed 1200+ history events from a 25-minute polled wait; the signal-first branch collapses
> ~120 polls into ~5 DB reads (`data.py:1093-1107`). A rebuild MUST reproduce ALL THREE with the
> exact patch ids; removing any breaks replay of in-flight histories.
>
> ⚠️ **GOTCHA-WAIT2 (signal-first: `except asyncio.TimeoutError: pass` then ONE DB read):** the
> per-iteration `wait_condition(..., timeout=this_wait)` raises `asyncio.TimeoutError` on timeout
> which is caught and swallowed (`data.py:1140-1141`); only THEN does it do the registry read.
> `this_wait = min(_DB_BACKSTOP_INTERVAL_SECONDS, remaining)` caps each wait at 300s but never
> exceeds the remaining budget. ⚠️ Determinism: the `timeout=` arg makes `wait_condition` itself a
> timer command — replay-safe. A rebuild MUST catch `asyncio.TimeoutError` (not generic
> `TimeoutError`) and continue to the DB read.
>
> ⚠️ **GOTCHA-WAIT3 (cancellation raises `RuntimeError`, does NOT return cleanly):** all three
> branches raise `RuntimeError("cancelled ...")` on `self.cancelled` (`data.py:1120,1144,1269,1286`)
> — they do NOT return a sentinel. This propagates up through `_execute_data` → `run()`'s `except`
> → workflow FAILED (NOT cancelled-clean). Contrast with the gate-wait cancel (§7.8 GOTCHA-GATE1)
> which returns `"cancelled"`. A rebuild MUST raise here, not return. ⚠️ This means a cancel during
> step 0 ends as `FAILED` with `current_step="failed"`, not `CANCELLED`.
>
> ⚠️ **GOTCHA-WAIT4 (`activity_id="consume-target-provisioned"` is STABLE across iterations):** the
> registry-read activity uses a fixed `activity_id` (`data.py:1161,1225`) — NOT keyed on `elapsed`
> or iteration. ⚠️ This means on replay Temporal sees the SAME activity id across poll iterations.
> The activity is idempotent per `workflow_id` (a row consumed by the same workflow still returns
> its payload — `ConsumeArchDataSignalInput` docstring). A rebuild MUST use a stable activity id
> here; varying it per-iteration would either re-run consumed rows or break replay.
>
> ⚠️ **GOTCHA-WAIT5 (DB-backstop hydration mirrors the signal handler, with the SAME guards):**
> the `result.found` block hydrates the exact same fields as the `target_provisioned` signal
> handler, including the 3× "only if non-empty" guards (`data.py:1190/1195/1200` and
> `1254/1259/1264`) — so DB-delivered state reads identically to signal-delivered state. A rebuild
> MUST keep the guards in BOTH the signal handler and BOTH backstop blocks.
>
> ⚠️ **GOTCHA-WAIT6 (registry-poll branch uses `while True` + explicit timeout check, not `while
> elapsed < cap`):** the `arch-data-registry-v1` branch loops `while True` and checks
> `elapsed >= cap` AFTER the read and cancel checks (`data.py:1212,1273`), sleeping 15s at the end
> (`data.py:1279`). The signal-first branch uses `while elapsed < cap` with the timeout baked into
> `wait_condition`. A rebuild MUST keep the two loop shapes distinct (they produce different
> history-event cadences).

---

## 9. `_fire_data_ready_signal(...)` — publish reply to Architecture (`data.py:1290-1409`)

Publishes `DataReadyForTargetSignal` to the arch-data registry (and, under signal-first, ALSO fires
a Temporal signal at the peer Architecture workflow as a fast path). Patch-gated three ways.

```text
async def _fire_data_ready_signal(self, data_architecture_ref, data_migration_plan_ref):
    signal_payload = DataReadyForTargetSignal(
        target_app_id=self._app_id, data_architecture_ref=data_architecture_ref,
        data_migration_plan_ref=data_migration_plan_ref, approved_at=_now_iso())   # data.py:1309-1314

    if workflow.patched("arch-data-registry-v1"):        # data.py:1316  BRANCH
        if not self._wave_id or not self._app_id:        # data.py:1317  BRANCH
            workflow.logger.info("data-ready publish skipped — missing wave_id / app_id")  # data.py:1322-1324
            return                                       # data.py:1325  ← unit-test/empty-id skip
        try:                                             # data.py:1326
            await workflow.execute_activity(
                publish_arch_data_signal,
                PublishArchDataSignalInput(signal_type=SIGNAL_DATA_READY_FOR_TARGET,
                    wave_id=self._wave_id, target_app_id=self._app_id,
                    payload_json=_encode_data_ready_payload(signal_payload)),
                start_to_close_timeout=timedelta(seconds=30),    # data.py:1335
                retry_policy=RETRY_POLICIES["transient"],        # data.py:1336
                activity_id="publish-data-ready-for-target")     # data.py:1337
            workflow.logger.info("arch_data_signal_fired", extra={...})   # data.py:1343-1359 (observability)
        except Exception as exc:                         # data.py:1360  BRANCH (best-effort)
            workflow.logger.warning("data-ready registry publish failed: %s", exc)  # data.py:1361-1363
        if (workflow.patched("arch-data-signal-first-v1")
                and self._architecture_workflow_id):     # data.py:1373-1376  BRANCH (fast-path)
            try:                                         # data.py:1377
                handle = workflow.get_external_workflow_handle(self._architecture_workflow_id)  # data.py:1378-1380
                await handle.signal("data_ready_for_target", signal_payload)        # data.py:1381-1383
            except Exception as exc:                     # data.py:1384  BRANCH (best-effort)
                workflow.logger.info("data-ready fast-path signal failed (DB backstop will catch it): %s", exc)  # data.py:1385-1389
        return                                           # data.py:1390

    # ----- Legacy signal path (pre-arch-data-registry-v1) -----
    if not self._architecture_workflow_id:               # data.py:1394  BRANCH
        workflow.logger.info("data-ready signal skipped — no architecture_workflow_id")  # data.py:1395-1397
        return                                           # data.py:1398
    try:                                                 # data.py:1399
        handle = workflow.get_external_workflow_handle(self._architecture_workflow_id)  # data.py:1400-1402
        await handle.signal("data_ready_for_target", signal_payload)   # data.py:1403
    except Exception as exc:                             # data.py:1404  BRANCH (best-effort)
        workflow.logger.warning("data-ready signal failed — architecture workflow may have completed: %s", exc)  # data.py:1405-1409
```

**Branch inventory for §9 (7):** `arch-data-registry-v1` (1316); empty-id skip (1317); registry
publish `try/except` (1326-1363); fast-path `arch-data-signal-first-v1 AND _architecture_workflow_id`
(1373); fast-path `try/except` (1377-1389); legacy `not _architecture_workflow_id` skip (1394);
legacy signal `try/except` (1399-1409).

> ⚠️ **GOTCHA-READY1 (registry publish is source-of-truth; signal is fast-path only):** under
> `arch-data-registry-v1` the `publish_arch_data_signal` activity (upsert keyed on
> `(wave_id, target_app_id, signal_type=data_ready_for_target)`) is authoritative — Architecture's
> step 5 polls the same key (`data.py:1296-1308`). The DIRECT Temporal signal to the peer
> (`handle.signal("data_ready_for_target", ...)`) runs ONLY when ALSO under
> `arch-data-signal-first-v1` AND `_architecture_workflow_id` is non-empty (`data.py:1373-1376`),
> as a latency optimization so Architecture's `wait_condition` exits on the in-memory flag without
> waiting for its 5-min DB backstop. A rebuild MUST keep the registry publish as primary and the
> direct signal as a best-effort fast path gated on BOTH the patch AND a non-empty peer id.
>
> ⚠️ **GOTCHA-READY2 (empty wave_id/app_id → SKIP silently):** unit-test runs without a wave_id
> can't be represented in the registry (UUID columns), so the publish is skipped (`data.py:1317-
> 1325`). A rebuild MUST skip (log+return), not raise, when either id is empty. ⚠️ This means the
> system-umbrella/Retire skips and the gate-approve path all tolerate empty wave/app ids.
>
> ⚠️ **GOTCHA-READY3 (ENTIRE method is best-effort — publish AND signal failures swallowed):**
> the registry publish `except` (1360) and both signal `except` blocks (1384, 1404) log and
> continue; the method never raises. A failed ready-signal does NOT fail the Data workflow (the
> gate is already approved). The DB row is the durable channel. A rebuild MUST make every failure
> path here non-fatal.
>
> ⚠️ **GOTCHA-READY4 (signal NAME is the literal string `"data_ready_for_target"`):** the
> cross-workflow signal is sent by name string (`data.py:1381,1403`), matching Architecture's
> `@workflow.signal data_ready_for_target` handler. The registry `signal_type` is the constant
> `SIGNAL_DATA_READY_FOR_TARGET` (= same string). A rebuild MUST use this exact name on both
> channels.
>
> ⚠️ **GOTCHA-READY5 (`_architecture_workflow_id` is observability on the new path, routing on the
> old):** under registry-v1 the reply routes via the registry key, NOT via
> `_architecture_workflow_id` (that field is "preserved for observability but not used for signal
> delivery", `data.py:1299-1302`) — EXCEPT for the fast-path direct signal which DOES use it. On
> the legacy path it is the sole routing target. A rebuild MUST preserve this dual role.

---

## 10. OVERRIDE: `_dispatch_agent(...)` — Data threads source_repo + plan context + model tiers (`data.py:1415-1525`)

> **Overrides** base `_dispatch_agent` (`_LineWorkflowBase.md` §8). **How it differs from base:**
> (1) adds a `source_repo` parameter threaded into `AgentTaskInput.source_repo`; (2) builds
> `context["rework_feedback"]` directly from `self._rework_feedback.get("G-DT")` instead of via
> `_rework_gate_key_for_step` (single-gate shortcut); (3) ALWAYS attaches a
> `context["target_plan_entry"]` block; (4) for `data-product-design` resolves the skill via
> `select_data_product_skill(self._tech_fingerprint)` instead of `STEPS[step]["skill_id"]`;
> (5) sets `model_preference="tier-2"` for the 3 synthesis-class steps; (6) uses a step-specific
> activity timeout (3h for `data-synthesis`, else 1h) + `heartbeat_timeout=2m`; (7) **does NOT load
> context-priors** (base loads them under `context-priors-v1` — this override OMITS that entirely).

```text
async def _dispatch_agent(self, app_id, step_name, input_artifacts,
                          source_repo="", workspace_key="", artifact_repo="", artifact_ref="") -> AgentTaskResult:
    step_def = DATA_STEPS[step_name]                     # data.py:1431
    context: dict = {}                                   # data.py:1432
    fb = self._rework_feedback.get("G-DT")               # data.py:1433
    if fb is not None:                                   # data.py:1434  BRANCH
        context["rework_feedback"] = fb                  # data.py:1435
    context["target_plan_entry"] = {                     # data.py:1443-1450  ALWAYS attached
        "target_app_id":     app_id,
        "target_service_id": self._target_service_id,
        "relationship":      self._relationship,
        "source_app_ids":    list(self._source_app_ids),
        "target_name":       self._target_plan_entry.get("target_name", ""),
        "rationale":         self._target_plan_entry.get("rationale", ""),
    }
    skill_id = step_def["skill_id"]                      # data.py:1457
    if step_name == "data-product-design":               # data.py:1458  BRANCH
        skill_id = select_data_product_skill(self._tech_fingerprint)   # data.py:1459  (router §0/data_router.py)
    sonnet_data_steps = {"migration-planning", "data-product-design", "data-synthesis"}   # data.py:1469-1473
    model_preference = "tier-2" if step_name in sonnet_data_steps else ""   # data.py:1474-1476  BRANCH (inline)
    task_input = AgentTaskInput(
        task_type=f"data-{step_name}", app_id=app_id, skill_id=skill_id,
        input_artifacts=input_artifacts, source_repo=source_repo,
        artifact_repo=artifact_repo, artifact_ref=artifact_ref,
        workspace_key=workspace_key, context=context,
        model_preference=model_preference,
        execution_context=self._execution_ctx(step_name, app_id=app_id,
                                              input_artifact_paths=input_artifacts))   # data.py:1477-1493
    synthesis_steps = {"data-synthesis"}                 # data.py:1504
    activity_timeout = timedelta(hours=3) if step_name in synthesis_steps else timedelta(hours=1)  # data.py:1505-1508  BRANCH (inline)
    result = await workflow.execute_activity(
        dispatch_agent_task, task_input,
        start_to_close_timeout=activity_timeout,         # data.py:1512
        heartbeat_timeout=timedelta(minutes=2),          # data.py:1513  ★ heartbeat
        retry_policy=RETRY_POLICIES["agent_failure"],    # data.py:1514  (3 attempts, 5-60s)
        activity_id=f"agent-{step_name}")                # data.py:1516
    self._agent_metadata[step_name] = {                  # data.py:1517-1524
        "model_used": result.model_used, "duration_ms": result.duration_ms,
        "token_usage_input": result.token_usage_input, "token_usage_output": result.token_usage_output,
        "cost_estimate_usd": result.cost_estimate_usd, "output_files": result.output_files,
    }
    return result                                        # data.py:1525
```

**Branch inventory for §10 (4):** `fb is not None` (1434); `step_name == "data-product-design"`
(1458); inline `model_preference = "tier-2" if ... else ""` (1474); inline `activity_timeout =
3h if ... else 1h` (1505).

> ⚠️ **GOTCHA-DA-OVR1 (override OMITS context-priors entirely):** the base `_dispatch_agent` loads
> `load_context_priors` under `workflow.patched("context-priors-v1")` (base GOTCHA-DA1). This
> override does NOT — there is no `load_context_priors` call at all. So Data dispatches never carry
> `context["context_priors"]`. A rebuild MUST NOT add context-priors to this override. (The
> `context-priors-v1` patch id is therefore NOT used in the Data module — only the base's path
> uses it, and Data doesn't call the base path.)
>
> ⚠️ **GOTCHA-DA-OVR2 (`task_type=f"data-{step_name}"` built literally, not via
> `_task_type_prefix()`):** the override hard-codes the `"data-"` prefix (`data.py:1478`) rather
> than calling `self._task_type_prefix()`. Since `ARTIFACT_ROOT="data"` the result is identical to
> base, but a rebuild matching THIS file builds it literally. (Same final string either way.)
>
> ⚠️ **GOTCHA-DA-OVR3 (rework feedback keyed directly on `"G-DT"`):** the override reads
> `self._rework_feedback.get("G-DT")` directly (`data.py:1433`), bypassing
> `_rework_gate_key_for_step`. Single-gate shortcut; behaviorally equal to the base (which would
> resolve `SINGLE_GATE_KEY="G-DT"`). A rebuild may use either but MUST forward the G-DT feedback on
> re-dispatch. (This is the channel by which gate-rejection structured feedback reaches the
> re-running agent — set by base `_wait_for_gate_decision`, §13.)
>
> ⚠️ **GOTCHA-DA-OVR4 (`target_plan_entry` context ALWAYS attached — single shape for every
> step):** every Data dispatch carries `context["target_plan_entry"]` with `target_app_id`,
> `target_service_id`, `relationship`, `source_app_ids` (copied via `list(...)`), and best-effort
> `target_name`/`rationale` from `_target_plan_entry` (`data.py:1443-1450`). Skills read this to
> decide many-to-one consolidate (`relationship=="consolidate"` AND `len(source_app_ids)>1`) vs 1:1
> (`data.py:1436-1442`). Empty on legacy waves / standalone runs. A rebuild MUST attach this block
> on EVERY step (not just consolidate).
>
> ⚠️ **GOTCHA-DA-OVR5 (step-5 skill is router-resolved, NOT the table's `skill_id`):** for
> `data-product-design` the skill is `select_data_product_skill(self._tech_fingerprint)`
> (`data.py:1458-1459`). The router (`data_router.py`) resolves: mainframe-family token →
> `data-product-design-mainframe`; else explicit `database` field via `DATA_PRODUCT_DATABASE_MAP`;
> else any DB token in the flattened fingerprint bag; else the base
> `data-product-specification`. When `_tech_fingerprint is None` it returns the base skill (legacy
> behavior preserved). A rebuild MUST route step 5 through this exact resolution order; the
> table's `skill_id="data-product-specification"` is only the fallback.
>
> ⚠️ **GOTCHA-DA-OVR6 (`model_preference="tier-2"` for the 3 synthesis-class steps — Bedrock flake
> mitigation):** `migration-planning`, `data-product-design`, `data-synthesis` get
> `model_preference="tier-2"` (Sonnet 4.6 1M); all others get `""` (`data.py:1469-1476`). The
> comment records a 43/52 failure rate on migration-planning from the Opus 4.7 1M
> `is_error=True, subtype=success` flake (`data.py:1460-1468`). A rebuild MUST set tier-2 for
> exactly these 3 steps.
>
> ⚠️ **GOTCHA-DA-OVR7 (3h timeout for synthesis, 1h else, + 2m heartbeat):** `data-synthesis` gets
> `start_to_close_timeout=timedelta(hours=3)`; everything else 1h (`data.py:1504-1508`). PLUS
> `heartbeat_timeout=timedelta(minutes=2)` on ALL dispatches (`data.py:1513`) — so `start_to_close`
> is the absolute upper bound, not the practical deadline; Temporal kills only on a true 2-min hang
> (`data.py:1494-1503`; Wave 1 hit the 1h ceiling on UAEP = AMCS+MedXPress consolidation). The base
> `_dispatch_agent` uses 1h start_to_close and NO heartbeat. A rebuild MUST set 3h-vs-1h by step and
> add the 2-min heartbeat. ⚠️ Retry policy is `agent_failure` (3 attempts) — NOT `transient`.
>
> ⚠️ **GOTCHA-DA-OVR8 (`activity_id=f"agent-{step_name}"` — deterministic, idempotent per step):**
> same as base (`data.py:1516`). Replay-stable. `_agent_metadata[step_name]` records the 6-field
> dict identically to base (`data.py:1517-1524`). A rebuild keeps the deterministic activity id.

---

## 11. Helper: `_run_agent_step(...)` — dispatch + commit + state (`data.py:1026-1073`)

Data's per-step wrapper (NOT in base — Data defines its own because it threads `source_repo` and
the `write_to_target` mirror).
```text
async def _run_agent_step(self, step_name, app_id, prior_inputs, source_repo, workspace_key, repo, branch) -> None:
    running = self._progress_pct                         # data.py:1044
    await self._set_step(step_name, running)             # data.py:1045
    result = await self._dispatch_agent(                 # data.py:1046-1054 (§10 override)
        app_id=app_id, step_name=step_name, input_artifacts=prior_inputs,
        source_repo=source_repo, workspace_key=workspace_key,
        artifact_repo=repo, artifact_ref=branch)
    self._step_results[step_name] = result.output_artifacts   # data.py:1055  ★ populate _step_results
    step_def = DATA_STEPS[step_name]                     # data.py:1056
    if step_def.get("artifact"):                         # data.py:1057  BRANCH
        artifact_path = f"data/{app_id}/{step_def['artifact']}"   # data.py:1058-1060
        mirror_repo = (self._provisioned_target_repo_url
                       if step_def.get("write_to_target") and self._provisioned_target_repo_url
                       else "")                          # data.py:1061-1066  BRANCH (inline)
        await self._commit_step_artifacts(               # data.py:1067-1073 (INHERITED §9)
            repo, branch, app_id, step_name, result, artifact_path,
            mirror_repo=mirror_repo,
            mirror_path_prefix=(f"docs/data/{step_name}" if mirror_repo else ""))   # data.py:1070-1072  BRANCH (inline)
```
**Branches (3):** `step_def.get("artifact")` (1057); inline `mirror_repo = ... if (write_to_target
AND url) else ""` (1061); inline `mirror_path_prefix = ... if mirror_repo else ""` (1070).

> ⚠️ **GOTCHA-RAS1 (`_step_results[step_name] = result.output_artifacts` — base relies on this):**
> per base GOTCHA-S2, `_step_results` is never written by base; Data writes it here
> (`data.py:1055`). This feeds `_build_evidence_data`, `_create_gate_pr_data`'s `steps_run`, and the
> step-11 `architecture_json`/`decomposition_json` reads. A rebuild MUST populate `_step_results`
> after every dispatch or evidence/persist come back empty.
>
> ⚠️ **GOTCHA-RAS2 (mirror ONLY when `write_to_target` AND a target repo URL exists):**
> `mirror_repo` is `_provisioned_target_repo_url` only when the step is flagged
> `write_to_target` AND the URL is non-empty (`data.py:1061-1066`); otherwise `""`. When
> `mirror_repo` is set, `mirror_path_prefix=f"docs/data/{step_name}"`; else `""`. The base
> `_commit_step_artifacts` mirrors the agent FILE artifacts to `mirror_repo`@`main` only when
> `mirror_repo and output_files` (best-effort, base GOTCHA-CSA4). So design deliverables travel with
> the target code, summary JSON stays in the artifact_repo. A rebuild MUST gate the mirror on
> exactly these two conditions. ⚠️ Pre-PR-A3 senders leave `_provisioned_target_repo_url=""` → NO
> mirror (falls back to artifact_repo only) — backward compatible.
>
> ⚠️ **GOTCHA-RAS3 (`_set_step(step_name, self._progress_pct)` — uses CURRENT progress):**
> `_run_agent_step` reads `running = self._progress_pct` (`data.py:1044`) and passes it to
> `_set_step` — i.e. it does NOT advance progress itself; the caller (`_execute_data`) advances
> `running_progress` after the step and the NEXT `_set_step` reflects it. ⚠️ In the PARALLEL paths
> (steps 1+2, 4+5), `_set_step` was already called once on the first step's id by `_execute_data`
> (GOTCHA-FANOUT3), then BOTH `_run_agent_step` coroutines call `_set_step` again with the same
> `_progress_pct` — a benign double-set. A rebuild keeps `_run_agent_step` reading current progress.

## 11.1 Helper: `_run_agent_step_task(...)` (`data.py:1075-1089`)
```text
def _run_agent_step_task(self, step_name, app_id, prior_inputs, source_repo, workspace_key, repo, branch):
    return self._run_agent_step(step_name, app_id, prior_inputs, source_repo, workspace_key, repo, branch)
```
⚠️ **GOTCHA-RAST1:** plain (non-async) method that **returns the coroutine** from `_run_agent_step`
WITHOUT awaiting it — used as a gather argument (`data.py:1085`). A rebuild MUST return the
un-awaited coroutine; awaiting it here would serialize the "parallel" steps.

---

## 12. OVERRIDE: `_build_evidence_data(...)` — Data-specific evidence bundle (`data.py:1527-1589`)

> **Overrides** base `_build_evidence_data` (`_LineWorkflowBase.md` §15). **How it differs from
> base:** (1) iterates `DATA_STEPS.items()` directly (not `_evidence_steps_iter()`); (2) hard-codes
> `"assembly_line": "Data"` in both the loop tag and the return; (3) adds
> `"architecture_workflow_id": self._architecture_workflow_id` to the top-level bundle; (4) returns
> `step_count` + `steps` (the base returns `current_step` instead of `step_count`). The slim/
> content/dedup/size mechanics are otherwise the same as base.

```text
def _build_evidence_data(self, app_id, assembly_line="Data", step="", *,
                         include_content=False, content_paths=None) -> dict[str, Any]:
    steps: dict[str, dict] = {}
    for step_name, step_def in DATA_STEPS.items():       # data.py:1549  LOOP
        artifacts = self._step_results.get(step_name, [])    # data.py:1550
        if not artifacts:                                # data.py:1551  BRANCH
            continue                                     # data.py:1552  ← skip steps that didn't run (incl ai-pre-review)
        metadata = self._agent_metadata.get(step_name, {})   # data.py:1553
        output_files = metadata.get("output_files", [])      # data.py:1554
        raw_file_artifacts: list[dict] = []
        for f in output_files:                           # data.py:1556  LOOP
            if not isinstance(f, OutputFile):            # data.py:1557  BRANCH
                continue                                 # data.py:1558  ← skip non-OutputFile
            content_str = f.content if isinstance(f.content, str) else ""   # data.py:1559  BRANCH (inline)
            entry: dict = {"path": f.path, "encoding": f.encoding,
                           "size": len(content_str.encode("utf-8")) if content_str else 0}  # data.py:1560-1564  BRANCH (inline)
            if include_content or (content_paths is not None and f.path in content_paths):  # data.py:1565-1567  BRANCH
                entry["content"] = f.content             # data.py:1568
            raw_file_artifacts.append(entry)             # data.py:1569
        deduped_file_artifacts = list({f["path"]: f for f in raw_file_artifacts}.values())  # data.py:1570-1572
        steps[step_name] = {                             # data.py:1573-1582
            "title": step_def.get("title", step_name),
            "skill_id": step_def["skill_id"],
            "artifact": step_def["artifact"],
            "output": artifacts[0] if artifacts else "",  # data.py:1577  BRANCH (inline)
            "metadata": {k: v for k, v in metadata.items() if k != "output_files"},  # data.py:1578-1580
            "file_artifacts": deduped_file_artifacts,
        }
    return {                                             # data.py:1583-1589
        "assembly_line": "Data",
        "app_id": app_id,
        "step_count": len(steps),
        "steps": steps,
        "architecture_workflow_id": self._architecture_workflow_id,
    }
```
**Branches (6 + 2 loops):** `for step_name` (1549); `if not artifacts: continue` (1551);
`for f in output_files` (1556); `if not isinstance(f, OutputFile): continue` (1557); inline
`content_str = ... if isinstance else ""` (1559); inline `size = ... if content_str else 0` (1563);
`if include_content or (content_paths ... in content_paths)` (1565); inline `output = artifacts[0]
if artifacts else ""` (1577).

> ⚠️ **GOTCHA-BE-OVR1 (iterates `DATA_STEPS.items()`, NOT `_evidence_steps_iter()`):** base iterates
> the `_evidence_steps_iter()` hook (`base.py:1015`); this override iterates `DATA_STEPS` directly
> (`data.py:1549`). Behaviorally equal here (Data doesn't override `_evidence_steps_iter`), but a
> rebuild matching THIS file iterates the table. ⚠️ `skill_id`/`artifact` are read via direct
> `step_def["skill_id"]`/`step_def["artifact"]` (NOT `.get`) — every `DATA_STEPS` entry has both, so
> no KeyError; but a rebuild must keep both keys present in the table.
>
> ⚠️ **GOTCHA-BE-OVR2 (`ai-pre-review` is skipped here too):** the `if not artifacts: continue`
> guard (`data.py:1551`) skips `ai-pre-review` because it's dispatched via the base gate-pre-review
> helper and never lands in `_step_results` (GOTCHA-STEPS1). So the evidence bundle has at most 6
> steps. A rebuild MUST skip empty-result steps.
>
> ⚠️ **GOTCHA-BE-OVR3 (slim by default; `size` always; dedup last-wins — same as base):** content
> is inlined ONLY when `include_content=True` or `f.path in content_paths`; `size` (utf-8 byte
> length) is always computed; file_artifacts dedup by path keeping last; `metadata` strips
> `output_files`; non-`OutputFile` entries skipped. Identical to base GOTCHA-BE1..5. A rebuild keeps
> all of these.
>
> ⚠️ **GOTCHA-BE-OVR4 (`step_count` not `current_step`; `architecture_workflow_id` added):** the
> return shape is `{assembly_line, app_id, step_count, steps, architecture_workflow_id}`
> (`data.py:1583-1589`) — base returns `{assembly_line, app_id, current_step, steps}`. The
> `_submit_gate_evidence` caller (base §11) passes `step="gate-review-dt"` which Data's override
> IGNORES (it hard-codes assembly_line and emits step_count). A rebuild matching this file MUST emit
> `step_count` + `architecture_workflow_id`, not `current_step`.

---

## 13. Helper: `_collect_committed_paths(self) -> list[str]` (`data.py:1591-1596`)
```text
def _collect_committed_paths(self):
    paths: list[str] = []
    for step_name in DATA_STEPS:                         # data.py:1594  LOOP
        paths.extend(self._step_committed_paths.get(step_name, []))   # data.py:1595
    return dedup_paths(paths)                            # data.py:1596
```
⚠️ **GOTCHA-CCP1:** iterates `DATA_STEPS` insertion order, accumulating each step's committed paths
(written by base `_commit_step_artifacts` to `_step_committed_paths[step]`), then `dedup_paths`
(order-preserving dedup). Returns the running set of all committed artifacts. Called after every
step/barrier to refresh `prior_inputs`, and at step 8 to build `artifact_paths`. A rebuild MUST
iterate the table in order and dedup.

---

## 14. Helper: `_create_gate_pr_data(...)` — G-DT review PR (`data.py:1598-1673`)

Data's OWN gate-PR builder (does NOT use base `_create_gate_pr` — it builds a Data-specific body
with the governance checklist and Tier-1 callout).
```text
async def _create_gate_pr_data(self, repo, branch, app_id, input):
    steps_run = [name for name, step_def in DATA_STEPS.items()
                 if step_def.get("kind") == "agent" and name in self._step_results]   # data.py:1606-1610  LOOP+BRANCH
    pr_body = f"## Gate G-DT Review: Data Architecture — {app_id}\n\n**Target application:** `{app_id}`\n"  # data.py:1611-1614
    if self._risk_tier is not None:                      # data.py:1615  BRANCH
        pr_body += f"**Risk tier:** {self._risk_tier}\n"     # data.py:1616
        if self._risk_tier == 1:                         # data.py:1617  BRANCH
            pr_body += "\n> **Tier-1:** Approval requires PM merge **AND** ... data-governance ... **AND** ... security ...\n"  # data.py:1618-1624
    pr_body += "\n### Data Steps Completed\n"
    for step_name in steps_run:                          # data.py:1626  LOOP
        step_def = DATA_STEPS[step_name]
        pr_body += f"- [x] {step_name} (`{step_def['skill_id']}`)\n"   # data.py:1628-1631
    pr_body += "\n### Artifacts\n"
    for step_name in steps_run:                          # data.py:1633  LOOP
        step_def = DATA_STEPS[step_name]
        pr_body += f"- `data/{app_id}/{step_def['artifact']}`\n"   # data.py:1635-1637
    pr_body += "\n### Data Governance Board Checklist\n- [ ] ... (9 fixed checklist items) ...\n"  # data.py:1638-1651
    rework_iter = self._rework_count("G-DT")             # data.py:1652
    if rework_iter > 0:                                  # data.py:1653  BRANCH
        pr_body += f"\n**Rework iteration:** {rework_iter}\n"   # data.py:1654
    pr_input = CreatePRInput(
        repo=repo, source_branch=branch, target_branch="main",
        title=f"Gate G-DT: Data Architecture Review — {app_id}",
        body=pr_body, labels=["gate-review", "data", "G-DT"],
        execution_context=self._execution_ctx("create-g-dt-pr", app_id=app_id))   # data.py:1656-1667
    return await workflow.execute_activity(
        create_pr, pr_input,
        start_to_close_timeout=timedelta(seconds=60),    # data.py:1671
        retry_policy=RETRY_POLICIES["transient"])        # data.py:1672
```
**Branches (4 + 3 loops):** `steps_run` comprehension `kind=="agent" AND name in _step_results`
(1606); `_risk_tier is not None` (1615); `_risk_tier == 1` (1617); `steps_run` loops (1626, 1633);
`rework_iter > 0` (1653).

> ⚠️ **GOTCHA-PR-DATA1 (`steps_run` filters to agent steps with results — excludes `ai-pre-review`
> AND not-yet-run steps):** `steps_run = [name for ... if kind=="agent" AND name in
> self._step_results]` (`data.py:1606-1610`). `ai-pre-review` is `kind=="agent"` but never in
> `_step_results` (GOTCHA-STEPS1) → excluded. A rebuild MUST apply both conditions.
>
> ⚠️ **GOTCHA-PR-DATA2 (Tier-1 PR body callout):** when `_risk_tier == 1` the body adds the explicit
> triple-signal requirement text (`data.py:1617-1624`). When `_risk_tier is None` no tier line at
> all. A rebuild reproduces the conditional body. ⚠️ The 9-item governance checklist
> (`data.py:1638-1651`) is FIXED text appended unconditionally.
>
> ⚠️ **GOTCHA-PR-DATA3 (rework footer):** `rework_iter = self._rework_count("G-DT")`; if `> 0`
> appends `**Rework iteration:** {n}` (`data.py:1652-1654`). So the 2nd+ gate PR (after rework)
> shows the iteration. A rebuild appends it only when `> 0`. ⚠️ labels are
> `["gate-review", "data", "G-DT"]` and target_branch is always `"main"`; `create_pr` 60s/`transient`.

---

## 15. RESILIENCE summary (Data-specific; base resilience in `_LineWorkflowBase.md` §19)

- **Activity timeouts (start_to_close):** `read_artifact` (index/plan) 30s/`transient`;
  `consume_arch_data_signal` 30s/`transient`; `publish_arch_data_signal` 30s/`transient`;
  `create_gate_record` 30s/`transient`; `persist_data_side_effects` 60s/`transient`;
  `dispatch_agent_task` **3h for `data-synthesis`, 1h else** + **2-min heartbeat** /`agent_failure`
  (3 attempts); `_create_gate_pr_data`'s `create_pr` 60s/`transient`. Inherited: commit batch
  120s, check/submit gate evidence 60s, pre-review dispatch 10m, merge 60s/`git_merge`,
  status update 30s.
- **Heartbeats:** ONLY on `dispatch_agent_task` (2-min, `data.py:1513`). No other Data activity
  heartbeats. (Base has none.)
- **continue-as-new:** NONE. Long waits use `wait_condition`/`workflow.sleep`, not C-A-N. ⚠️ The
  24h step-0 wait + up-to-4 gate cycles can accumulate large histories; the signal-first +
  DB-backstop design (GOTCHA-WAIT1/2) is the explicit mitigation, not C-A-N.
- **Idempotency:** deterministic activity ids — `agent-{step}`, `commit-{step}` (base),
  `read-target-source-index-{app}`, `read-data-target-plan-{app}`, `consume-target-provisioned`
  (stable across poll iterations, GOTCHA-WAIT4), `publish-data-ready-for-target`,
  `persist-data-side-effects`. `consume_arch_data_signal` is idempotent per `workflow_id`;
  `persist_data_side_effects` is idempotent on rework (cluster rows `ON CONFLICT DO NOTHING`).
  `_now_iso()` deterministic.
- **Patch ids (ALL verbatim, load-bearing for replay):** `"data-source-index-v1"` (§7.0),
  `"data-parallel-fanout-v1"` (§7.5), `"arch-data-signal-first-v1"` (§8.1 + §9 fast-path),
  `"arch-data-registry-v1"` (§8.2 + §9 publish). ⚠️ `"context-priors-v1"`/`"patch-output-artifact-
  ref-v1"`/`"mark-gate-ready-for-review-v1"` appear in BASE methods Data calls
  (`_commit_step_artifacts`, `_run_gate_pre_review`) — Data's own `_dispatch_agent` override does
  NOT use `context-priors-v1` (GOTCHA-DA-OVR1).
- **Compensation / rollback:** none. Failure semantics:
  - Step-0 `_load_target_plan_entry` miss/malformed/unmatched → `ApplicationError(non_retryable)` →
    `run()` except → FAILED (GOTCHA-PLAN1).
  - Step-0 wait cancel → `RuntimeError` → FAILED (NOT clean-cancelled, GOTCHA-WAIT3).
  - `persist_data_side_effects` / source-index read / ready-signal publish+signal / mirror commit →
    best-effort (logged, swallowed).
  - Gate cancel (step 10) → return `"cancelled"` (base set `_status=CANCELLED`); Tier-1 inner cancel
    → set `_status=CANCELLED`, return `"cancelled"` (GOTCHA-GATE1).
  - Gate reject → rework up to `MAX_REWORK_ITERATIONS=3`; on the 4th reject → FAILED with
    `current_step="max-rework-exceeded"` (GOTCHA-GATE3).
  - Structured merge errors → `merge_blocked` + reviewer `merge_retry` loop (inherited base §14).
  - Any other exception anywhere → `run()` except → FAILED + best-effort `data_failed` status push,
    then re-raise.
- **System-umbrella / Retire skips fire the ready signal with empty refs** so Architecture never
  deadlocks (GOTCHA-SKIP-SYS / GOTCHA-SKIP-RETIRE).

---

## 16. Override matrix — DataWorkflow vs base

| Method | Inherited as-is | Overridden by Data | How it differs |
|--------|:--------------:|:------------------:|----------------|
| `gate_approved` / `gate_rejected` / `escalation_resolved` / `merge_retry` | ✅ | — | NEVER redefine (GOTCHA-SIG0) |
| 6 HIL signals (`approve`, `cancel_workflow`, …) | ✅ | — | inherited transitively |
| `get_status` query | ✅ | — | NEVER redefine (GOTCHA-Q1) |
| `_task_type_prefix` | ✅ (`"data"`) | — | — (override `_dispatch_agent` builds `"data-{step}"` literally) |
| `_rework_gate_key_for_step` | ✅ (returns `"G-DT"`) | — | single-gate; override `_dispatch_agent` reads `"G-DT"` directly |
| `_primary_skill_for_step` | ✅ | — | (Data step-5 routing done in `_dispatch_agent`, not this hook) |
| `_evidence_step_metadata` / `_evidence_steps_iter` | ✅ | — | (Data `_build_evidence_data` iterates `DATA_STEPS` directly) |
| `_dispatch_agent` | — | ✅ | +source_repo, +target_plan_entry ctx, step-5 router, tier-2 model, 3h/1h timeout + 2m heartbeat, NO context-priors (§10) |
| `_build_evidence_data` | — | ✅ | hard-codes `"Data"`, emits `step_count` + `architecture_workflow_id` (§12) |
| `_commit_step_artifacts` | ✅ | — | called via `_run_agent_step` with mirror args |
| `_submit_gate_evidence` | ✅ | — | called with `forward_risk_tier=True` |
| `_run_gate_pre_review` | ✅ | — | called with `artifact_repo`/`artifact_ref` |
| `_wait_for_gate_decision` | ✅ | — | called per gate cycle |
| `_reconcile_and_merge_with_retry_loop` | ✅ | — | called with `merge_method="merge"` |
| `_create_gate_pr` | ✅ (unused) | — | Data uses its own `_create_gate_pr_data` instead |
| `run()` / `_execute()` | — | ✅ | Data defines `run()` → `_execute_data` (12-step) |
| NEW: `stakeholder_approved`, `target_provisioned` signals | — | (new) | §3.1 / §3.2 |
| NEW helpers: `_execute_data`, `_read_target_source_artifacts_index`, `_load_target_plan_entry`, `_wait_for_target_provisioned`, `_fire_data_ready_signal`, `_run_agent_step`, `_run_agent_step_task`, `_collect_committed_paths`, `_create_gate_pr_data` | — | (new) | §5-§14 |

---

## 17. Behavioral parity checklist

A rebuilt `DataWorkflow` MUST satisfy ALL of the following:

1. `class DataWorkflow(LineWorkflowBase)`; classvars `ASSEMBLY_LINE=AssemblyLine.DATA`,
   `ARTIFACT_ROOT="data"`, `LINE_LABEL="Data"`, `STATUS_PREFIX="data"`, `STEPS=DATA_STEPS`,
   `STEP_WEIGHTS` (13 keys, sum 100.0, asserted at load), `SINGLE_GATE_KEY="G-DT"`,
   `MAX_REWORK_ITERATIONS=3`.
2. `__init__` calls `super().__init__()` first, then initializes the 13 Data state vars to: two
   stakeholder flags `False`, `_target_provisioned=False`, `_architecture_workflow_id=""`, four
   `_provisioned_*` strings `""`, `_target_service_id=""`, `_relationship=""`, `_source_app_ids=[]`,
   `_target_plan_entry={}`, `_tech_fingerprint=None`.
3. Exactly TWO new `@workflow.signal` handlers: `stakeholder_approved` (routes scope
   `g-dt-data-governance`/`g-dt-security`, else warn+ignore; bumps `_updated_at`) and
   `target_provisioned` (FIRST statement `await wait_condition(lambda: bool(self._app_id))`; drops
   on `target_app_id != _app_id`; hydrates `_provisioned_*` + `_architecture_workflow_id` always,
   and `_target_service_id`/`_relationship`/`_source_app_ids` only-if-signal-field-non-empty;
   defensive `getattr` for PR-A3 fields). NO other new signals; `get_status` NOT redefined; the
   four base gate signals NOT redefined. (GOTCHA-SIG-DATA0..4)
4. `run()`: sets RUNNING/`_started_at`; sets `_app_id=input.app_id` early (unblocks the signal
   wait_condition); hydrates `_portfolio_id`/`_wave_id`/`_risk_tier`/`_tech_fingerprint`/
   `_target_service_id`/`_relationship`/`_source_app_ids`/`_artifact_repo`; computes
   `run_suffix=wf_id.rsplit("-",1)[-1] if "-" in wf_id else wf_id[:8]`,
   `branch=f"olympus/data/{app}/{suffix}"`, `workspace_key=f"data-{app}-{suffix}"`; calls
   `_execute_data(input, app, "", branch, workspace_key)` in try; on exception sets FAILED +
   `current_step="failed"` + best-effort `data_failed` status push (inner try/except/pass) then
   **re-raises**. (GOTCHA-RUN1..3)
5. Step-0 wait `_wait_for_target_provisioned` reproduces ALL THREE patch branches with EXACT ids:
   `arch-data-signal-first-v1` (signal-first `wait_condition` with `timeout=min(300s, remaining)`,
   `except asyncio.TimeoutError: pass`, then ONE `consume_arch_data_signal` DB read per iteration,
   24h cap, `while elapsed < cap`), `arch-data-registry-v1` (`while True` 15s `workflow.sleep` poll
   + explicit cap/cancel checks), legacy `else` (pure `wait_condition`). All raise
   `RuntimeError` on cancel (NOT clean return) and on timeout. `activity_id="consume-target-
   provisioned"` STABLE across iterations. DB-backstop hydration mirrors the signal handler incl
   the 3 "only-if-non-empty" guards. (GOTCHA-WAIT1..6)
6. `_load_target_plan_entry` STRICT-FAILS: raises `ApplicationError(non_retryable=True)` on missing
   wave/repo, read failure, malformed JSON, or target-not-in-plan; on match stores `dict(t)` and
   back-fills `_target_service_id`/`_relationship`(lowercased)/`_source_app_ids` only-if-still-empty.
   `read_artifact` 30s/`transient`, `activity_id=f"read-data-target-plan-{app}"`. (GOTCHA-PLAN1..3)
7. `_read_target_source_artifacts_index` is BEST-EFFORT: returns `[]` on missing wave/repo, read
   failure, or malformed JSON; collects only `str`-and-truthy paths from
   `source_apps[].artifacts.{discovery,rationalization}` + `shared_artifacts`. Merged into
   `prior_inputs` (append-if-unseen) ONLY under `workflow.patched("data-source-index-v1")`.
   (GOTCHA-IDX1/2, GOTCHA-EXD0)
8. `_execute_data` runs the 12-step shape with EXACT progress arithmetic and EXACT ordering:
   step0 wait → `repo=self._artifact_repo` → `_load_target_plan_entry` → system-umbrella skip (OR
   of `_target_service_id=="system"` and plan-entry `=="system"`) → Retire skip
   (`_provisioned_disposition=="Retire"`) → steps 1+2 (`data-parallel-fanout-v1` gather else
   sequential) → step 3 → steps 4+5 (ALWAYS gather, NOT patch-gated) → `while True` gate loop. Both
   skips fire `_fire_data_ready_signal` with empty refs, set COMPLETED/100.0, return `"completed"`.
   `prior_inputs` refreshed to `_collect_committed_paths()` after every step/barrier.
   (GOTCHA-EXD0, REPO, SKIP-SYS, SKIP-RETIRE, FANOUT1..5)
9. Gate loop body order: step6 synthesis (sequential) → step7 commit marker → step8 `artifact_paths
   = dedup_paths(_collect_committed_paths())` + `_create_gate_pr_data` + `create_gate_record`
   (30s/`transient`) + `_submit_gate_evidence(forward_risk_tier=True)` → step9 `_run_gate_pre_review`
   (artifact_repo/ref passed) → step10 `_set_step("gate-review-dt")` + status `gate_review` +
   `_wait_for_gate_decision(G_DT)`. (GOTCHA-GATE8..10)
10. Step10 routing: `"cancelled"` → return `"cancelled"` (no status set, base already did);
    `"approved"` → IF `_risk_tier==1` block on `wait_condition((gov AND sec) or cancelled)` and on
    cancel set CANCELLED + return `"cancelled"`; then step11 persist + ready-signal + step12 merge +
    COMPLETED/100.0/return `"completed"`. (GOTCHA-GATE1/2)
11. Step11: refs computed as `f"data/{app}/data-architecture.json"` and
    `f"data/{app}/data-migration-plan.json"`; `architecture_json`/`decomposition_json` from
    `_step_results[...][0]` only-if-present else `""`; `persist_data_side_effects`
    (60s/`transient`/`activity_id="persist-data-side-effects"`) wrapped in best-effort try/except;
    `_fire_data_ready_signal` fired OUTSIDE the try (unconditional). (GOTCHA-GATE6/7)
12. Step12: `_reconcile_and_merge_with_retry_loop(repo, pr_number, gate_id, merge_method="merge")`
    (inherited; handles merge_blocked + merge_retry). (GOTCHA-GATE9)
13. Gate reject → rework: reset BOTH `_stakeholder_*_approved=False` BEFORE `_bump_rework("G-DT")`;
    if `_rework_count("G-DT") > 3` set FAILED + `current_step="max-rework-exceeded"` + status push +
    return `"failed"`; else reset `running_progress=2.0` and re-dispatch the 5 steps
    (`domain-discovery`, `shared-db-analysis`, `decomposition-strategy`, `migration-planning`,
    `data-product-design`) SEQUENTIALLY (skipping step 0), refreshing `prior_inputs` each, then loop
    to synthesis. (GOTCHA-GATE3/4/5)
14. `_fire_data_ready_signal`: under `arch-data-registry-v1` skip-if-empty-wave/app; else
    `publish_arch_data_signal` (30s/`transient`/`activity_id="publish-data-ready-for-target"`,
    payload via `_encode_data_ready_payload`) best-effort; ALSO under `arch-data-signal-first-v1`
    AND non-empty `_architecture_workflow_id` fire direct `handle.signal("data_ready_for_target",
    payload)` best-effort. Legacy path: skip-if-no-arch-id else `handle.signal` best-effort. Method
    NEVER raises. (GOTCHA-READY1..5)
15. `_dispatch_agent` OVERRIDE: threads `source_repo`; `context["rework_feedback"]` from
    `_rework_feedback.get("G-DT")` if not None; ALWAYS `context["target_plan_entry"]` (6 fields,
    `source_app_ids` copied); step-5 skill via `select_data_product_skill(_tech_fingerprint)`;
    `model_preference="tier-2"` for {`migration-planning`,`data-product-design`,`data-synthesis`}
    else `""`; `task_type=f"data-{step}"`; `dispatch_agent_task` with
    `start_to_close=3h if data-synthesis else 1h`, `heartbeat_timeout=2m`,
    `retry_policy=agent_failure`, `activity_id=f"agent-{step}"`; records 6-field
    `_agent_metadata[step]`; NO context-priors load. (GOTCHA-DA-OVR1..8)
16. `_run_agent_step` populates `_step_results[step]=result.output_artifacts`, then commits via
    inherited `_commit_step_artifacts(... mirror_repo=_provisioned_target_repo_url if write_to_target
    AND url else "", mirror_path_prefix=f"docs/data/{step}" if mirror else "")`.
    `_run_agent_step_task` returns the un-awaited coroutine. (GOTCHA-RAS1..3, RAST1)
17. `_build_evidence_data` OVERRIDE iterates `DATA_STEPS.items()`, skips empty-result steps
    (incl `ai-pre-review`), slim-by-default with always-computed utf-8 `size`, content only if
    `include_content`/`content_paths`, dedup file_artifacts last-wins, strips `output_files` from
    metadata, returns `{assembly_line:"Data", app_id, step_count, steps, architecture_workflow_id}`.
    (GOTCHA-BE-OVR1..4)
18. `_collect_committed_paths` iterates `DATA_STEPS` order accumulating `_step_committed_paths`,
    `dedup_paths`. `_create_gate_pr_data` builds Data-specific body (`steps_run` = agent-kind steps
    in `_step_results`; Tier-1 callout; 9-item governance checklist; rework footer if count>0),
    labels `["gate-review","data","G-DT"]`, target `main`, `create_pr` 60s/`transient`.
    (GOTCHA-CCP1, PR-DATA1..3)
19. ALL patch ids reproduced VERBATIM: `"data-source-index-v1"`, `"data-parallel-fanout-v1"`,
    `"arch-data-signal-first-v1"`, `"arch-data-registry-v1"`. The 24h/15s/5-min constants match
    `architecture.py` as local literals.
20. `_encode_data_ready_payload` JSON-encodes exactly `{target_app_id, data_architecture_ref,
    data_migration_plan_ref, approved_at}`; `_decode_target_provisioned_payload` returns `{}` on
    empty/non-JSON/non-dict. Cross-workflow signal name is the literal `"data_ready_for_target"`.
