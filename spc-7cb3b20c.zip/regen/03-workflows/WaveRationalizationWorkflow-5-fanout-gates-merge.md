# `WaveRationalizationWorkflow` — Part 5: Arch/Data fan-out, gate plumbing, gate-wait & merge (ATOMIC regeneration spec)

> **Source of truth:** `temporal/olympus_workflows/workflows/wave_rationalization.py` (6129 lines,
> HEAD 7cb3b20c). Every `wave_rationalization.py:line` (abbreviated `WR:line`) citation is against
> that file.
>
> **Scope of THIS file:** lines **4566–5762** only. That covers, in source order:
> `_execute_architecture_data_fanout` (WR:4566), `_drain_retry_queue` (WR:4763),
> `_execution_ctx` (WR:4838), `_validate_artifact_or_warn` (WR:4865), `_agent_narrative`
> (WR:4942), `_primary_output_content` (WR:4966), **NEW `_primary_output_is_empty` (WR:5022)**,
> `_commit_artifact` (WR:5057), `_commit_output_files` (WR:5102), `_open_gate_pr` (WR:5178),
> `_build_grr_body` (WR:5203), `_build_gda_body` (WR:5240), `_build_scoring_methodology` (WR:5280),
> `_build_factory_routing` (WR:5332), `_set_step` (WR:5400), `_wait_for_gate` (WR:5405),
> `_merge_capability_lineage_row_rework` (WR:5482), `_run_gate_pre_review` (WR:5571), and
> `_reconcile_and_merge_with_retry_loop` (WR:5687).
>
> ⚠️ **REFRESH NOTE (HEAD 7cb3b20c vs old 5969-line baseline):** the file grew to 6129 lines.
> Every helper in this spec's scope **shifted down**, and the shift is NON-uniform because a NEW
> static helper `_primary_output_is_empty` (WR:5022-5055, ~35 lines) was inserted between
> `_primary_output_content` and `_commit_artifact`. Old→new offsets: `_execute_architecture_data_
> fanout`/`_drain_retry_queue`/`_execution_ctx`/`_validate_artifact_or_warn` ≈ +101; `_agent_
> narrative`/`_primary_output_content` ≈ +102; `_commit_artifact`…`_build_gda_body` ≈ +137;
> `_build_scoring_methodology`/`_build_factory_routing` ≈ +139; `_set_step`/`_wait_for_gate`/
> `_merge_capability_lineage_row_rework`/`_run_gate_pre_review` ≈ +147; `_reconcile_and_merge_
> with_retry_loop` ≈ +160. **Behavioral deltas in MY scope:** (1) **NEW** `_primary_output_is_empty`
> static helper; (2) `_build_factory_routing` gained a **`Build`** disposition → new `build` route
> bucket (5→8 dispositions, 4→5 buckets); (3) `_run_gate_pre_review` gained an
> `optional_evidence_paths` kwarg threaded into `optional_input_artifacts`. Helper BODIES otherwise
> unchanged. All `WR:line` citations below are refreshed to HEAD.
>
> **Out of scope (handled by sibling specs — referenced, never reproduced here):** `__init__`
> (WR:1087), `run`/`_execute` (WR:1239 / WR:1346), the per-app fan-out
> (`_per_app_pipeline` WR:3357), the dispatch bookkeeping helpers (`_compute_pending_*` WR:3997/4075,
> `_dispatch_key` WR:4158, `_init_dispatch_status` WR:4169, `_normalize_dispatch_payload` WR:4201,
> `_provision_one_target` WR:4305, `_spawn_children_for_target` WR:4348, `_update_wave_status_safe`
> WR:4537, `_project_per_app_side_effects` WR:3934), and ALL signal/query handlers
> (WR:5768–6122). Where my methods call those, I cite them by line and describe their *contract*
> only.
>
> **Inheritance:** `class WaveRationalizationWorkflow(HILSignalsMixin)` — see `_HILSignalsMixin.md`.
> ⚠️ **GOTCHA-WR0 (does NOT inherit `LineWorkflowBase`):** unlike the seven per-app line
> workflows, this workflow inherits ONLY `HILSignalsMixin`, **not** `LineWorkflowBase`. The
> module docstring (WR:1) and several method docstrings (WR:4848, WR:5583, WR:5695) state this
> explicitly: "WaveRationalizationWorkflow deliberately doesn't inherit from the per-app base —
> the fan-out shape is wave-scoped, not per-app." Consequently **four** methods that `_LineWorkflowBase.md`
> describes — `_execution_ctx`, `_wait_for_gate_decision` (here renamed `_wait_for_gate`),
> `_run_gate_pre_review`, `_reconcile_and_merge_with_retry_loop` — are **re-implemented inline in
> this file**. They are NOT inherited. This spec reproduces them in full and calls out exactly how
> each diverges from the base version. The HIL signals (`approve`, `cancel_workflow`,
> `approve_plan`, …, and crucially `self.cancelled`) ARE inherited from the mixin.

---

## 0. Determinism / time / retry preliminaries (used throughout this file)

- `_now_iso() -> str` (WR:134-135) = `workflow.now().isoformat()`. Deterministic under replay.
  **Every** timestamp written by methods in this file goes through `_now_iso()` — never
  `datetime.now()`.
- Retry policies referenced by string key from `RETRY_POLICIES` (`retry_policies.py:109-116`):
  - `"transient"` = `TRANSIENT_RETRY_POLICY` = `HTTP_RETRY_POLICY` — exp backoff 1→15s, **3
    attempts** (`retry_policies.py:32-33,110`).
  - `"git_merge"` = `GIT_MERGE_RETRY_POLICY` — initial 5s, backoff 2.0, max 30s, **3 attempts**,
    `non_retryable_error_types=["MergeConflict","MergeDivergenceUnresolved",
    "MergeBranchProtectionRejected"]` (`retry_policies.py:94-104,115`). ⚠️ This list is what
    surfaces the structured `ApplicationError.type` to `_reconcile_and_merge_with_retry_loop` —
    see §17 GOTCHA-MR4.
  - `"agent_failure"` — used by callers of these helpers, not directly inside my scope.
- All activity imports live inside `with workflow.unsafe.imports_passed_through():` (WR:44-131).
  A rebuild MUST keep that guard.

---

## 1. STATE — every instance var READ or MUTATED by methods in this file

All vars are declared in `__init__` (WR:1087-1236, out of scope) and inherited from
`HILSignalsMixin` (the `cancelled` flag). The table lists ONLY vars that the **lines 4465-5608**
methods touch, with the exact read/write sites in my scope.

| Var | Type | Initial (WR) | Touched by (in THIS file) | How |
|-----|------|--------------|---------------------------|-----|
| `_current_step` | `str` | `""` (WR:1094) | `_execute_architecture_data_fanout` (WR:4579), `_set_step` (WR:5401), `_wait_for_gate` (indirectly via `_set_step` only at caller; `_wait_for_gate` itself doesn't set it) | set to `"awaiting-architecture-dispatch"` (WR:4579); set to `step` arg (WR:5401) |
| `_progress_pct` | `float` | `0.0` (WR:1095) | `_set_step` (WR:5402) | clamped `max(0.0, min(100.0, progress))` |
| `_updated_at` | `str` | `""` (WR:1098) | `_set_step` (WR:5403), `_wait_for_gate` (WR:5413,5424,5439) | `= _now_iso()` |
| `_pending_gate` | `GateType \| None` | `None` (WR:1096) | `_wait_for_gate` (WR:5411 set, WR:5437 clear) | `GateType(gate_key)` or `None` |
| `_status` | `WorkflowStatus` | `PENDING` (WR:1093) | `_wait_for_gate` (WR:5412,5423,5438) | `WAITING_FOR_SIGNAL` → (`CANCELLED` on cancel) / `RUNNING` |
| `_portfolio_id` | `str` | `""` (WR:1092) | `_execution_ctx` (WR:4853,4856) | read-only — gate for returning `None` |
| `_wave_id` | `str` | `""` (WR:1089) | `_execution_ctx` (WR:4860), `_validate_artifact_or_warn` (log only), `_run_gate_pre_review` (WR:5648 in AgentTaskInput), `_reconcile…` (log only) | read-only |
| `_validation_warnings` | `dict[str, list[str]]` | `{}` (WR:1178) | `_validate_artifact_or_warn` (WR:4937-4939) | `setdefault(warning_key, []).extend(result.errors)` |
| `_gate_decisions` | `dict[str, list[tuple]]` | `{}` (WR:1106) | `_wait_for_gate` (WR:5415 setdefault, WR:5420 predicate, WR:5426 read) | per-gate queue keyed by gate_key string |
| `_gate_decisions_consumed` | `dict[str, int]` | `{}` (WR:1107) | `_wait_for_gate` (WR:5416 setdefault, WR:5417 snapshot, WR:5436 advance) | per-gate consume cursor |
| `_rework_feedback` | `dict[str, dict]` | `{}` (WR:1155) | `_wait_for_gate` (WR:5441 pop on approve, WR:5471 set on reject), `_merge_capability_lineage_row_rework` (WR:5542 read, WR:5560 set) | structured rework dict keyed by gate_key |
| `_approval_feedback` | `dict[str, dict]` | `{}` (WR:1170) | `_wait_for_gate` (WR:5449 set, WR:5456 / WR:5462 pop) | approve-with-guidance dict keyed by gate_key |
| `_rework_iterations_grr` | `int` | `0` (WR:1153) | `_build_grr_body` (WR:5236-5237 read) | read-only here (bumped in caller WR:2292) |
| `_rework_iterations_gda` | `int` | `0` (WR:1154) | `_build_gda_body` (WR:5276-5277 read), `_merge_capability_lineage_row_rework` (WR:5521 activity_id) | read-only here (bumped in caller WR:3037) |
| `_tier1_approval_records` | `dict[str, dict[str,str]]` | `{}` (WR:1150) | `_run_gate_pre_review` (WR:5629-5632 read) | read-only here |
| `_dispatch_status` | `dict[str, DispatchTargetStatus]` | `{}` (WR:1212) | `_execute_architecture_data_fanout` (WR:4628,4665,4680,4716,4738,4747), `_drain_retry_queue` (WR:4786,4814-4831) | mutates per-target `.status` / `.error` / names |
| `_dispatch_received` | `bool` | `False` (WR:1208) | `_execute_architecture_data_fanout` (WR:4599 predicate) | read-only here (set by signals WR:5974/6000) |
| `_dispatch_payload` | `DispatchArchitecturePayload\|None` | `None` (WR:1209) | `_execute_architecture_data_fanout` (WR:4603), `_drain_retry_queue` (WR:4797-4798) | read-only here |
| `_pending_dispatch_entries` | `list[PendingDispatchEntry]` | `[]` (WR:1217) | `_execute_architecture_data_fanout` (WR:4580) | set via `_compute_pending_dispatch_entries` |
| `_pending_target_dispatch_entries` | `list[PendingTargetDispatchEntry]` | `[]` (WR:1224) | `_execute_architecture_data_fanout` (WR:4587) | set via `_compute_pending_target_dispatch_entries` |
| `_pending_retries` | `list[RetryTargetDispatchPayload]` | `[]` (WR:1236) | `_drain_retry_queue` (WR:4778 while, WR:4779 pop) | drained FIFO |
| `_merge_retry_signalled` | `bool` | `False` (WR:1183) | `_reconcile_and_merge_with_retry_loop` (WR:5751 reset, WR:5759 predicate) | reset before block, consumed by predicate |
| `cancelled` | `bool` | `False` (mixin) | `_execute_architecture_data_fanout` (WR:4599,4601 predicate+branch), `_wait_for_gate` (WR:5420,5422), `_reconcile…` (WR:5759,5761) | inherited kill switch (one-way latch; see `_HILSignalsMixin.md` GOTCHA-5) |

> ⚠️ **GOTCHA-WR-STATE1 (per-gate dict keying — NOT the base's scalar cursor):** unlike
> `LineWorkflowBase` where `_gate_decisions` is a flat `list` and `_gate_decisions_consumed` is a
> single `int` (`_LineWorkflowBase.md` §2), THIS workflow keys BOTH by **gate_key string**
> (`"G-RR"` / `"G-DA"`) — `_gate_decisions: dict[str, list[tuple]]` (WR:1106) and
> `_gate_decisions_consumed: dict[str, int]` (WR:1107). The docstring (WR:1100-1102) explains why:
> so G-RR and G-DA decisions land in independent queues and "don't collide if both gates have
> activity in flight." A rebuild MUST use per-gate dicts here, not the base's scalar pattern. The
> signal handlers (WR:5792-5844, out of scope) append into `_gate_decisions[gate_key]` via a
> `gate_id→gate_key` UUID lookup; my `_wait_for_gate` consumes one queue at a time.

---

## 2. `_execute_architecture_data_fanout(self, input, per_app_results) -> str` (WR:4566-4761) ★ MAJOR

**Signature** (WR:4566-4570): `async def _execute_architecture_data_fanout(self, input:
WaveRationalizationInput, per_app_results: dict[str, dict]) -> str`.

**Returns** one of the literal strings: `"cancelled"`, `"completed"`, `"dispatched"`,
`"stuck-awaiting-recovery"`, `"failed"`. The caller (`_execute`, WR:3249) propagates this as the
workflow's terminal value. Docstring (WR:4571-4578): partial failures do NOT cascade — successful
children run to completion; failed targets surface in the `dispatch_results` query for UI retry.

### 2.1 Activity / child-workflow calls in order
| # | Callee | Args | sequential/parallel | Notes |
|---|--------|------|---------------------|-------|
| 1 | `_update_wave_status_safe("awaiting-architecture-dispatch")` (WR:4592) | status str | seq | best-effort wave-status push (out-of-scope helper WR:4537) |
| 2 | `_provision_one_target(cfg, input)` (WR:4620) ×N | per target cfg | **parallel** via `asyncio.gather(return_exceptions=True)` (WR:4622-4624) | out-of-scope helper WR:4305 |
| 3 | `_spawn_children_for_target(cfg, result, input, run_ts)` (WR:4643) | per successful target | **sequential** in the zip loop | returns `(arch_handle, data_handle)`; out-of-scope WR:4348 |
| 4 | `_drain_retry_queue(input, run_ts, child_handles)` (WR:4662) | — | seq | §3 below |
| 5 | `_update_wave_status_safe(...)` various (WR:4667/4688/4701/4754/4760) | status str (+reason) | seq | branch-dependent |
| 6 | child `h.result()` ×len(child_handles) (WR:4707-4709) | — | **parallel** via `asyncio.gather(return_exceptions=True)` | Phase-2 path only (NOT taken under sibling-lifecycle patch) |

No retry policies / timeouts apply directly here — those live inside the called helpers.
`run_ts = int(workflow.now().timestamp())` (WR:4614) — deterministic; used to derive child IDs.
⚠️ **GOTCHA-WR-FO1 (`run_ts` MUST be `workflow.now()`):** comment WR:4612-4613 — child workflow
IDs are derived from this timestamp; using wall-clock time would break replay determinism.

### 2.2 CONTROL FLOW — structured pseudocode (preserve EVERY branch)
(Body unchanged from baseline; only line numbers shifted +101.)

```text
async def _execute_architecture_data_fanout(self, input, per_app_results) -> str:
    self._current_step = "awaiting-architecture-dispatch"                       # WR:4579
    self._pending_dispatch_entries = self._compute_pending_dispatch_entries(    # WR:4580-4582
        per_app_results)
    self._pending_target_dispatch_entries = (                                   # WR:4587-4591
        self._compute_pending_target_dispatch_entries(
            per_app_results, self._pending_dispatch_entries))
    await self._update_wave_status_safe("awaiting-architecture-dispatch")       # WR:4592-4594

    # ── pre-dispatch hold ──────────────────────────────────────────
    await workflow.wait_condition(                                              # WR:4598-4600 ★PREDICATE
        lambda: self._dispatch_received or self.cancelled)
    if self.cancelled:                          # ── BRANCH 1 (WR:4601)
        return "cancelled"                       # WR:4602

    payload = self._dispatch_payload             # WR:4603
    if payload is None or not payload.targets:  # ── BRANCH 2 (WR:4604)
        # empty payload → no fan-out (e.g. wave was 100% Retire)
        await self._update_wave_status_safe("completed")    # WR:4607
        return "completed"                                  # WR:4608

    self._init_dispatch_status(payload)          # WR:4610  (out-of-scope WR:4169)
    run_ts = int(workflow.now().timestamp())     # WR:4614  ★deterministic

    # ── Phase 1: provision targets in PARALLEL ─────────────────────
    provision_futures = [self._provision_one_target(cfg, input)               # WR:4619-4621
                         for cfg in payload.targets]
    provisioned_results = await asyncio.gather(*provision_futures,            # WR:4622-4624
                                               return_exceptions=True)

    child_handles: list[workflow.ChildWorkflowHandle] = []                    # WR:4626
    for cfg, result in zip(payload.targets, provisioned_results):             # WR:4627  LOOP
        status = self._dispatch_status[self._dispatch_key(cfg)]               # WR:4628
        if isinstance(result, BaseException):    # ── BRANCH 3 (WR:4629)  provision failed
            status.status = "failed"             # WR:4630
            status.error = repr(result)          # WR:4631
            workflow.logger.warning("create_target_app_and_repo failed", extra={...})  # WR:4632-4638
            continue                              # WR:4639
        # provision succeeded → spawn children
        status.status = "provisioned"            # WR:4641
        try:
            arch_handle, data_handle = await self._spawn_children_for_target(  # WR:4643-4645
                cfg, result, input, run_ts)
            child_handles.extend([arch_handle, data_handle])                  # WR:4646
        except Exception as exc:                 # ── BRANCH 4 (WR:4647)  spawn failed
            status.status = "failed"             # WR:4648
            status.error = f"spawn_children: {exc!r}"   # WR:4649
            workflow.logger.warning("start_child_workflow failed", extra={...})  # WR:4650-4656

    # drain any retries queued while provisioning was in flight
    await self._drain_retry_queue(input, run_ts, child_handles)               # WR:4662

    # ── post-provision routing ─────────────────────────────────────
    if any(s.status == "architecture_in_flight"                               # ── BRANCH 5 (WR:4664-4666)
           for s in self._dispatch_status.values()):
        await self._update_wave_status_safe("architecture-in-flight")         # WR:4667
    elif not child_handles:                       # ── BRANCH 6 (WR:4668)  every target failed
        # Task #88: RECOVERABLE — all upstream artifacts already committed;
        # operator can fix per-target config and /resume.
        error_reasons = [s.error for s in self._dispatch_status.values()      # WR:4679-4681
                         if s.error]
        reason_summary = ("; ".join(error_reasons)[:500]   # ── BRANCH 7 (WR:4682-4687)
                          if error_reasons
                          else "every target failed to provision in "
                               "create_target_app_and_repo")
        await self._update_wave_status_safe(                                  # WR:4688-4691
            "stuck-awaiting-recovery",
            reason=f"dispatch_architecture: {reason_summary}")
        return "stuck-awaiting-recovery"           # WR:4692

    # ── sibling-lifecycle patch: complete on dispatch ──────────────
    if workflow.patched("arch-data-sibling-lifecycle-v1"):  # ── BRANCH 8 (WR:4700)  PATCH GATE
        await self._update_wave_status_safe("architecture-dispatched")        # WR:4701
        return "dispatched"                                                   # WR:4702

    # ── Phase 2: wait for every child to complete (PARALLEL) ───────
    child_results = await asyncio.gather(                                     # WR:4707-4709
        *[h.result() for h in child_handles], return_exceptions=True)

    idx = 0                                       # WR:4714
    for cfg in payload.targets:                   # WR:4715  LOOP  (attribute results back)
        status = self._dispatch_status[self._dispatch_key(cfg)]               # WR:4716
        if status.status == "failed":             # ── BRANCH 9 (WR:4717)  skip already-failed
            continue                              # WR:4718
        if idx + 1 >= len(child_results):         # ── BRANCH 10 (WR:4719)  ran out of results
            break                                 # WR:4720
        arch_result = child_results[idx]          # WR:4721
        data_result = child_results[idx + 1]      # WR:4722
        idx += 2                                  # WR:4723
        arch_ok = not isinstance(arch_result, BaseException)   # WR:4724
        data_ok = not isinstance(data_result, BaseException)   # WR:4725
        if arch_ok and data_ok:                   # ── BRANCH 11 (WR:4726)
            status.status = "completed"           # WR:4727
        else:                                     # WR:4728
            status.status = "failed"              # WR:4729
            err_parts: list[str] = []             # WR:4730
            if not arch_ok:                       # ── BRANCH 12 (WR:4731)
                err_parts.append(f"arch: {arch_result!r}")   # WR:4732
            if not data_ok:                       # ── BRANCH 13 (WR:4733)
                err_parts.append(f"data: {data_result!r}")   # WR:4734
            status.error = "; ".join(err_parts)   # WR:4735

    any_failed = any(s.status == "failed"         # WR:4737-4739
                     for s in self._dispatch_status.values())
    if any_failed:                                # ── BRANCH 14 (WR:4740)
        # Task #88: per-target child failures are RECOVERABLE.
        failed_targets = [                        # WR:4745-4749
            s.target_app_id or s.target_app_name or "<unknown>"
            for s in self._dispatch_status.values() if s.status == "failed"]
        reason = (f"one or more target workflows failed: "                    # WR:4750-4753
                  f"{', '.join(str(t) for t in failed_targets)}")[:500]
        await self._update_wave_status_safe("stuck-awaiting-recovery", reason=reason)  # WR:4754-4757
        return "stuck-awaiting-recovery"          # WR:4758

    await self._update_wave_status_safe("completed")   # WR:4760
    return "completed"                                 # WR:4761
```

### 2.3 GOTCHAs

- ⚠️ **GOTCHA-WR-FO2 (`return_exceptions=True` on BOTH gathers):** provisioning (WR:4622-4624)
  and child-completion (WR:4707-4709) gathers both pass `return_exceptions=True`. This is what
  prevents one failed target from cascading — a `BaseException` lands as an element in the result
  list, and the `isinstance(result, BaseException)` checks (WR:4629, WR:4724-4725) attribute it
  per-target. A rebuild that uses a default `gather` (which raises on first exception) would
  destroy the partial-failure semantics the docstring promises.
- ⚠️ **GOTCHA-WR-FO3 (child_handles ordering is `[arch,data,arch,data,…]`):** comment WR:4712-4713.
  `_spawn_children_for_target` returns `(arch_handle, data_handle)` and we `extend([arch,data])`
  (WR:4646). The Phase-2 attribution loop relies on this exact ordering: `child_results[idx]` is
  arch, `child_results[idx+1]` is data, `idx += 2` (WR:4721-4723). ⚠️ But the loop iterates
  `payload.targets` and skips entries whose `status == "failed"` (WR:4717-4718) WITHOUT advancing
  `idx`. This is correct ONLY because a failed target contributed zero handles (it `continue`d at
  WR:4639 or set failed at WR:4648 without extending). A rebuild MUST skip-without-advancing for
  failed targets and advance-by-2 for the rest, or the arch/data results get mis-attributed.
  Note: retried targets (drained at WR:4662) append handles AFTER the initial set but are NOT
  re-walked here in the same `payload.targets` order — see GOTCHA-WR-FO4.
- ⚠️ **GOTCHA-WR-FO4 (retried-target handles & the `idx+1 >= len` guard):** `_drain_retry_queue`
  appends extra handles to `child_handles` (WR:4829) for v1 retries. The Phase-2 attribution loop
  walks `payload.targets` (the ORIGINAL list), so retried targets that were absent / failed in the
  original payload may not line up 1:1 with the extra handles. The `if idx + 1 >= len(child_results):
  break` (WR:4719-4720) is the safety valve: once we run out of paired results we stop. This means a
  retried target's child results may NOT be attributed back to its `DispatchTargetStatus` in this
  loop (the retry path is "v1-only, known v2 gap" per WR:4783-4785). A rebuild must keep the
  `break` guard exactly; do not assume `len(child_results) == 2 * len(targets)`.
- ⚠️ **GOTCHA-WR-FO5 (three terminal strings map to recovery semantics):** the return value drives
  `classify_failure` semantics in the caller. `"stuck-awaiting-recovery"` is returned on BOTH the
  all-provision-failed path (WR:4692) AND the any-child-failed path (WR:4758) — these are the
  Task-#88 RECOVERABLE cases (artifacts already committed; `/resume` works). `"completed"` /
  `"dispatched"` / `"cancelled"` are clean. A rebuild must return the EXACT strings — the API's
  wave-resume logic branches on them (`RECOVERABLE_FAILURE_ACTIVITIES`, WR:280-300).
- ⚠️ **GOTCHA-WR-FO6 (sibling-lifecycle patch SHORT-CIRCUITS Phase 2):** under
  `workflow.patched("arch-data-sibling-lifecycle-v1")` (WR:4700), the workflow returns
  `"dispatched"` **before** the Phase-2 `child_results = gather(...)` (WR:4707). Comment
  WR:4694-4699: children keep running under an ABANDON parent-close policy and the sibling
  Architecture/Data workflows drive the wave's status thereafter. The patch ID string is
  load-bearing for replay — a pre-patch in-flight run replays through Phase 2; a post-patch run
  short-circuits. Reproduce VERBATIM.
- ⚠️ **GOTCHA-WR-FO7 (`reason` truncated to 500 chars):** both recovery reasons are sliced `[:500]`
  (WR:4683, WR:4753). A rebuild must truncate to keep the DB `wave.failure_reason` column / status
  reason within bounds.

---

## 3. `_drain_retry_queue(self, input, run_ts, child_handles) -> None` (WR:4763-4832)

**Signature** (WR:4763-4768): `async def _drain_retry_queue(self, input:
WaveRationalizationInput, run_ts: int, child_handles: list) -> None`. Mutates `child_handles`
in place (appends arch/data handles for each successfully-retried target). Returns `None`.
(Body unchanged from baseline; only line numbers shifted +101.)

Docstring (WR:4769-4777): processes `retry_target_dispatch` signals (buffered in
`_pending_retries`) that arrived between the initial signal and the end of provisioning. Retries
run **sequentially** — the UI resubmits per-row after fixing the error (usually a repo-name
collision); concurrent retries are not a hot path. Each retry reuses `disposition` +
`peer_source_app_ids` from the originating dispatch row.

### 3.1 Activity calls in order (per retry iteration)
| # | Callee | When | Notes |
|---|--------|------|-------|
| 1 | `_provision_one_target(retried_cfg, input)` (WR:4819) | after building `retried_cfg` | out-of-scope WR:4305; wrapped in try/except |
| 2 | `_spawn_children_for_target(retried_cfg, provisioned, input, run_ts)` (WR:4826) | after successful provision | out-of-scope WR:4348; wrapped in try/except; extends `child_handles` |

### 3.2 CONTROL FLOW — structured pseudocode

```text
async def _drain_retry_queue(self, input, run_ts, child_handles) -> None:
    while self._pending_retries:                         # WR:4778  LOOP (FIFO drain)
        retry = self._pending_retries.pop(0)             # WR:4779
        # PR #495: retry payload carries the v1 source key; v2 retry is unsupported here.
        status = self._dispatch_status.get(retry.source_app_id)   # WR:4786
        if status is None:                                # ── BRANCH 1 (WR:4787)
            workflow.logger.warning(                      # WR:4788-4791
                "retry_target_dispatch for unknown source_app_id",
                extra={"source_app_id": retry.source_app_id})
            continue                                      # WR:4792

        # Reuse disposition + peer set from the ORIGINAL dispatch row.
        orig_cfg = None                                   # WR:4796
        if self._dispatch_payload is not None:            # ── BRANCH 2 (WR:4797)
            for cfg in self._dispatch_payload.targets:    # WR:4798  LOOP
                if cfg.source_app_id == retry.source_app_id:   # ── BRANCH 3 (WR:4799)
                    orig_cfg = cfg                        # WR:4800
                    break                                 # WR:4801
        if orig_cfg is None:                              # ── BRANCH 4 (WR:4802)
            status.status = "failed"                      # WR:4803
            status.error = "retry: original dispatch entry missing"   # WR:4804
            continue                                      # WR:4805

        retried_cfg = DispatchArchitectureTargetConfig(   # WR:4806-4813
            source_app_id=retry.source_app_id,
            target_app_name=retry.target_app_name,
            target_repo=retry.target_repo,
            disposition=orig_cfg.disposition,             # ← reused from original
            default_branch=retry.default_branch or orig_cfg.default_branch,   # WR:4811 fallback
            peer_source_app_ids=list(orig_cfg.peer_source_app_ids))           # ← reused, copied
        status.target_app_name = retry.target_app_name    # WR:4814
        status.target_repo = retry.target_repo            # WR:4815
        status.status = "provisioning"                    # WR:4816
        status.error = ""                                 # WR:4817

        try:
            provisioned = await self._provision_one_target(retried_cfg, input)   # WR:4819
        except Exception as exc:                          # ── BRANCH 5 (WR:4820)
            status.status = "failed"                      # WR:4821
            status.error = repr(exc)                      # WR:4822
            continue                                      # WR:4823
        status.status = "provisioned"                     # WR:4824
        try:
            arch_handle, data_handle = await self._spawn_children_for_target(    # WR:4826-4828
                retried_cfg, provisioned, input, run_ts)
            child_handles.extend([arch_handle, data_handle])                     # WR:4829
        except Exception as exc:                          # ── BRANCH 6 (WR:4830)
            status.status = "failed"                      # WR:4831
            status.error = f"spawn_children: {exc!r}"     # WR:4832
        # loop back: continue draining until _pending_retries empty
```

### 3.3 GOTCHAs

- ⚠️ **GOTCHA-WR-DR1 (keyed by `source_app_id`, NOT `_dispatch_key`):** the retry lookup uses
  `self._dispatch_status.get(retry.source_app_id)` (WR:4786), NOT `self._dispatch_key(cfg)`.
  Comment WR:4780-4785: `_dispatch_status` may now be keyed by `target_app_id` (v2) or
  `source_app_id` (v1); the retry payload only carries the v1 source key, so the retry path is
  **v1-only** (a "known v2 gap"). For a v2 dispatch, `_dispatch_status` is keyed by `target_app_id`
  (see `_dispatch_key` WR:4158), so `get(retry.source_app_id)` returns `None` → BRANCH 1 logs and
  skips. A rebuild MUST keep this v1-only behavior (do not silently "fix" it to use target keys —
  the retry UI doesn't supply them).
- ⚠️ **GOTCHA-WR-DR2 (`disposition` + `peer_source_app_ids` are NOT user-editable on retry):** only
  `target_app_name` / `target_repo` / `default_branch` come from the retry payload (WR:4806-4813);
  `disposition` and `peer_source_app_ids` are copied from `orig_cfg` (WR:4810, WR:4812). The
  `peer_source_app_ids` is wrapped in `list(...)` to avoid aliasing the original config's list. A
  rebuild must preserve which fields are editable-vs-reused.
- ⚠️ **GOTCHA-WR-DR3 (`default_branch` falsy-fallback):** `retry.default_branch or
  orig_cfg.default_branch` (WR:4811) — an empty/`None` retry branch falls back to the original. Use
  truthiness here, not `is None`.
- ⚠️ **GOTCHA-WR-DR4 (`pop(0)` while iterating — drains signals that arrive DURING the drain):**
  the `while self._pending_retries: ... pop(0)` (WR:4778-4779) re-checks the list each iteration,
  so a `retry_target_dispatch` signal (WR:6060-6073) that lands mid-drain (e.g. while
  `_provision_one_target` is awaiting) is also processed. A rebuild must re-evaluate the `while`
  condition each loop (don't snapshot the list length up front).

---

## 4. `_execution_ctx(self, step_id, *, app_id="", gate_id="", input_artifact_paths=None) -> StepExecutionContext | None` (WR:4838-4863)

**Signature** (WR:4838-4845): keyword-only `app_id`/`gate_id`/`input_artifact_paths` after
`step_id`. Returns `StepExecutionContext | None`.

⚠️ **GOTCHA-WR-EC0 (this OVERRIDES the base — but is a DIFFERENT implementation, not an override
in the OOP sense):** the docstring (WR:4846-4852) says "Mirrors `LineWorkflowBase._execution_ctx`
but inlined here since WaveRationalizationWorkflow doesn't inherit from the base (its fan-out shape
is wave-scoped, not per-app)." Differences from the base version (`_LineWorkflowBase.md` §5):
1. **`line_id` is the literal `"rationalization"`** (WR:4857), NOT `LINE_LABEL.lower().replace(" ","-")`.
   The wave workflow has no `LINE_LABEL` classvar.
2. **`app_id` / `wave_id` use a plain default `""` + truthy-list semantics**, NOT the base's `None`
   sentinel. Here `app_id: str = ""` (WR:4842) is passed straight through (WR:4859); `wave_id` is
   ALWAYS `self._wave_id` (WR:4860) — the base lets callers override `wave_id` per-substep, this
   one does not.
3. **`gate_id`** is a first-class kwarg here (WR:4843, WR:4861); the base also has it.

```text
def _execution_ctx(self, step_id, *, app_id="", gate_id="", input_artifact_paths=None):
    if not self._portfolio_id:                  # ── BRANCH 1 (WR:4853)  ★ONLY branch
        return None                             # WR:4854  best-effort no-op
    return StepExecutionContext(                # WR:4855-4862
        portfolio_id=self._portfolio_id,
        line_id="rationalization",              # WR:4857  ★literal, not derived
        step_id=step_id,
        app_id=app_id,                          # WR:4859  passed through verbatim
        wave_id=self._wave_id,                  # WR:4860  always the wave
        gate_id=gate_id,
        input_artifact_paths=list(input_artifact_paths or []))   # WR:4862
```

- ⚠️ **GOTCHA-WR-EC1 (`None` when no portfolio → all Layer-B step_execution emission is best-effort):**
  same contract as base — when `_portfolio_id` is empty (`""`), returns `None` (WR:4853-4854), and
  every downstream activity that receives `execution_context=None` skips its `step_execution`
  emission. A rebuild MUST gate on `not self._portfolio_id` and return `None`.
- ⚠️ **GOTCHA-WR-EC2 (`input_artifact_paths` defensively copied):** `list(input_artifact_paths or
  [])` (WR:4862) — `None` → `[]`, and any passed list is copied (no aliasing). Keep the copy.

---

## 5. `_validate_artifact_or_warn(self, *, artifact_filename, raw_content, wave_id, app_id="") -> None` (WR:4865-4939)

**Signature** (WR:4865-4872): all keyword-only. Returns `None`. **Advisory-mode — NEVER blocks
the workflow** (docstring WR:4873-4889). Stashes errors into `self._validation_warnings` for the
G-DA evidence bundle.

### 5.1 Activity call
- `validate_artifact_against_schema` with `ValidateArtifactInput(artifact_filename, raw_content)`
  (WR:4893-4898); **30s** start_to_close; `RETRY_POLICIES["transient"]` (WR:4899-4900). Result type
  `ValidateArtifactResult(validated: bool, errors: list[str])` (`types.py:647-669`).

### 5.2 CONTROL FLOW — structured pseudocode (preserve EVERY branch)

```text
async def _validate_artifact_or_warn(self, *, artifact_filename, raw_content, wave_id, app_id=""):
    if not raw_content:                          # ── BRANCH 1 (WR:4890)  nothing to validate
        return                                   # WR:4891
    try:
        result = await workflow.execute_activity(                       # WR:4893-4901
            validate_artifact_against_schema,
            ValidateArtifactInput(artifact_filename=artifact_filename,
                                  raw_content=raw_content),
            start_to_close_timeout=timedelta(seconds=30),
            retry_policy=RETRY_POLICIES["transient"])
    except ActivityError as exc:                 # ── BRANCH 2 (WR:4902)  schema-missing/packaging defect
        # NonRetryableError from the activity arrives here as ActivityError.
        # Advisory mode MUST never take down the workflow.
        workflow.logger.warning(                 # WR:4907-4915
            f"{artifact_filename} schema validation skipped: {exc}",
            extra={"wave_id": wave_id, "app_id": app_id,
                   "artifact": artifact_filename, "reason": "validator-unavailable"})
        return                                   # WR:4916  ← swallow, treat as un-validated

    if not result.errors:                        # ── BRANCH 3 (WR:4917)  clean
        return                                   # WR:4918

    warning_key = app_id or f"wave-{wave_id}"    # WR:4919  ★key selection
    log_extra = {"wave_id": wave_id, "app_id": app_id, "artifact": artifact_filename,
                 "error_count": len(result.errors), "errors": result.errors}   # WR:4920-4926
    if result.validated:                         # ── BRANCH 4 (WR:4927)  parsed but schema-invalid
        workflow.logger.warning(f"{artifact_filename} schema validation failed", extra=log_extra)  # WR:4928-4931
    else:                                        # WR:4932  could not even parse
        workflow.logger.warning(f"{artifact_filename} could not be parsed", extra=log_extra)       # WR:4933-4936
    self._validation_warnings.setdefault(warning_key, []).extend(result.errors)   # WR:4937-4939
```

### 5.3 GOTCHAs

- ⚠️ **GOTCHA-WR-VAL1 (ONLY catches `ActivityError`, not bare `Exception`):** the try/except
  catches `except ActivityError` specifically (WR:4902), not `Exception`. The comment (WR:4903-4906)
  explains: the activity raises a `NonRetryableError` for a missing schema / packaging defect, which
  Temporal surfaces to the workflow as `ActivityError`. A rebuild must catch `ActivityError` here.
  (A non-`ActivityError` would propagate — but in practice the activity only raises that wrapped
  form.)
- ⚠️ **GOTCHA-WR-VAL2 (warning_key fallback `app_id or f"wave-{wave_id}"`):** wave-scoped artifacts
  pass `app_id=""` and bucket under `"wave-{wave_id}"` (WR:4919); per-app artifacts bucket under the
  `app_id`. A rebuild must use this exact key-selection so the G-DA evidence bundle
  (`dict(self._validation_warnings)`, WR:2968) groups warnings correctly. ⚠️ The **NEW** rat-cap
  zero-row read-back (sibling `-execute-a`, WR:2028) appends into this SAME dict under
  `"wave-{wave_id}"` — so `_validation_warnings` now also carries persist-failure notices.
- ⚠️ **GOTCHA-WR-VAL3 (`validated` distinguishes "parsed-but-invalid" from "unparseable"):** both
  log a warning AND append errors, but the log MESSAGE differs (`validated=True` → "schema
  validation failed"; `validated=False` → "could not be parsed", WR:4927-4936). Either way the
  errors are appended (WR:4937-4939). A rebuild must keep both log branches but append in both.
- ⚠️ **GOTCHA-WR-VAL4 (unregistered artifacts return cleanly):** docstring WR:4878-4879 — artifacts
  not in `_SCHEMA_REGISTRY` make the activity return `validated=False, errors=[]`, which hits
  BRANCH 3 (`not result.errors`) and returns without warning. So unknown artifacts are a no-op, not
  a warning. A rebuild's activity must return empty errors for unregistered artifacts.

---

## 6. `_agent_narrative(result) -> str` (staticmethod, WR:4942-4963)

`@staticmethod`. Returns the agent's prose narrative = `output_artifacts[0]`, or `""`.

```text
@staticmethod
def _agent_narrative(result) -> str:
    if result is None:                           # ── BRANCH 1 (WR:4957)
        return ""                                # WR:4958
    artifacts = getattr(result, "output_artifacts", None) or []   # WR:4959
    if not artifacts:                            # ── BRANCH 2 (WR:4960)
        return ""                                # WR:4961
    first = artifacts[0]                         # WR:4962
    return first or ""                           # WR:4963  ← None-safe
```

- ⚠️ **GOTCHA-WR-AN1 (`first or ""` guards a `None` first element):** even when `output_artifacts`
  is non-empty, `artifacts[0]` could be `None`; `first or ""` (WR:4963) normalizes it. A rebuild
  must not return a raw possibly-`None` element.
- Context (docstring WR:4943-4956, issue #184): per-app rollup cards lead with this prose
  narrative; the JSON files are linked separately as `file_artifacts`. Empty narrative = "JSON-only
  output" → callers fall back to JSON sections.

---

## 7. `_primary_output_content(result, primary_filename) -> str` (staticmethod, WR:4966-5019) ★ FIDELITY-CRITICAL

`@staticmethod`. Resolves the agent's primary artifact content for commit. ⚠️ This is the
**2026-05-19 bug-fix** method (docstring WR:4985-4993): committing `output_artifacts[0]` (the prose
narrative) straight into a `.json` artifact path corrupted per-app JSON artifacts; the correct
content lives in `output_files` (the real workspace file the skill wrote).

```text
@staticmethod
def _primary_output_content(result, primary_filename) -> str:
    if result is None:                           # ── BRANCH 1 (WR:4995)
        return ""                                # WR:4996
    files = getattr(result, "output_files", None) or []   # WR:4997
    for out_file in files:                       # WR:4998  LOOP
        if isinstance(out_file, dict):           # ── BRANCH 2 (WR:4999)  dict-shaped file
            raw_path = out_file.get("path", "") or ""        # WR:5000
            content = out_file.get("content", "") or ""      # WR:5001
        else:                                    # WR:5002  object-shaped file
            raw_path = getattr(out_file, "path", "") or ""   # WR:5003
            content = getattr(out_file, "content", "") or "" # WR:5004
        if not raw_path:                         # ── BRANCH 3 (WR:5005)
            continue                             # WR:5006
        # Match on basename — agent may emit bare filename OR nested path.
        if raw_path.rsplit("/", 1)[-1] == primary_filename:  # ── BRANCH 4 (WR:5010)
            return content                       # WR:5011  ★workspace file wins
    # Workspace file absent → fall back to narrative
    artifacts = getattr(result, "output_artifacts", None) or []   # WR:5016
    if artifacts:                                # ── BRANCH 5 (WR:5017)
        return artifacts[0] or ""                # WR:5018  ← None-safe
    return ""                                    # WR:5019
```

- ⚠️ **GOTCHA-WR-POC1 (workspace `output_files` content WINS over narrative — the whole point):**
  the loop searches `output_files` for a file whose **basename** matches `primary_filename` and
  returns its `content` (WR:5010-5011). ONLY if no workspace file matches does it fall back to
  `output_artifacts[0]` (WR:5016-5018). A rebuild MUST prefer the workspace file; reversing the
  precedence re-introduces the corruption bug (prose narrative committed into `.json`).
- ⚠️ **GOTCHA-WR-POC2 (basename match via `rsplit("/", 1)[-1]`):** agents emit either a bare
  filename (`disposition-recommendation.json`) or a nested path
  (`rationalization/.../disposition-recommendation.json`). The match is on the last path segment
  (WR:5007-5010). A rebuild must basename-match, not exact-match.
- ⚠️ **GOTCHA-WR-POC3 (dual file shape — dict OR object):** `output_files` entries may be `dict`s
  (`out_file.get("path")`) or objects (`getattr(out_file, "path")`) — handled by the
  `isinstance(out_file, dict)` branch (WR:4999-5004). The mock runtime / fixtures emit dicts; the
  live runtime emits `OutputFile` objects. Keep BOTH shapes.
- ⚠️ **GOTCHA-WR-POC4 (fallback returns `artifacts[0] or ""` so callers' `content or "{}"` works):**
  comment WR:5012-5015 — the empty-string fallback keeps `_commit_artifact`'s `content or "{}"`
  defaulting (WR:5074/5091) intact. A rebuild must return `""` (not `None`) when neither source
  exists.

---

## 7b. ⚠️ NEW — `_primary_output_is_empty(raw) -> bool` (staticmethod, WR:5022-5055)

`@staticmethod`. **NEW since baseline.** True when an agent's primary output carries no usable
content. Gates the empty-PRA-plan hard-fail (sibling `-execute-a`, WR:1906-1919). "Empty" =
blank/whitespace OR JSON that parses to `{}` / `[]` / `null` OR a non-JSON narrative string (the
primary artifact is contractually JSON).

```text
@staticmethod
def _primary_output_is_empty(raw) -> bool:
    import json                                  # WR:5041  (local import, sandbox rule)
    if not raw or not raw.strip():               # ── BRANCH 1 (WR:5043)  blank/whitespace
        return True                              # WR:5044
    try:
        parsed = json.loads(raw)                 # WR:5046
    except (ValueError, TypeError):              # ── BRANCH 2 (WR:5047)  non-JSON prose
        return True                              # WR:5050
    if parsed is None:                           # ── BRANCH 3 (WR:5051)
        return True                              # WR:5052
    if isinstance(parsed, (dict, list)) and len(parsed) == 0:   # ── BRANCH 4 (WR:5053)
        return True                              # WR:5054
    return False                                 # WR:5055
```

- ⚠️ **GOTCHA-WR-EMPTY1 (4 ways to be "empty"; non-JSON is empty, never an exception):** the
  `json.loads` is inside a `try` (WR:5045-5050) — a non-JSON string returns `True`, never raises out
  of this helper. A rebuild MUST treat blank, `{}`/`[]`/`null`, AND non-JSON-prose all as empty.
  Docstring WR:5023-5038 records the 2026-06-14 Wave-1 rat-cap break this guards.
- ⚠️ **GOTCHA-WR-EMPTY2 (local `import json`):** WR:5039-5041 — `json` imported locally (sandbox
  rule), consistent with `_build_factory_routing`. Pure/deterministic.

---

## 8. `_commit_artifact(self, repo, branch, path, content, message, *, step_id="commit-redundancy-artifacts", app_id="") -> None` (WR:5057-5100)

**Signature** (WR:5057-5067): positional `repo, branch, path, content, message`; keyword-only
`step_id` (default `"commit-redundancy-artifacts"`) + `app_id` (default `""`). Returns `None`.

⚠️ **GOTCHA-WR-CA0 (patch-gated batch-vs-single write):** the body branches on
`workflow.patched("wave-rationalization-batch-writes-v1")` (WR:5068). Pre-patch in-flight runs
replay through the single-file `write_artifact` path; post-patch runs use the batched
`write_artifacts_batch`. The patch ID string is load-bearing for replay. Reproduce VERBATIM.

```text
async def _commit_artifact(self, repo, branch, path, content, message, *,
                           step_id="commit-redundancy-artifacts", app_id=""):
    if workflow.patched("wave-rationalization-batch-writes-v1"):   # ── BRANCH 1 (WR:5068) PATCH GATE
        await workflow.execute_activity(                           # WR:5069-5083
            write_artifacts_batch,
            WriteArtifactsBatchInput(
                repo=repo, branch=branch,
                files=[(path, content or "{}")],                   # WR:5074  ★single-element batch; "{}" default
                commit_message=message,
                execution_context=self._execution_ctx(step_id, app_id=app_id)),  # WR:5076-5079
            start_to_close_timeout=timedelta(seconds=120),         # WR:5081  ★120s for batch
            retry_policy=RETRY_POLICIES["transient"])
    else:                                                          # WR:5084
        await workflow.execute_activity(                           # WR:5085-5099
            write_artifact,
            WriteArtifactInput(
                repo=repo, branch=branch, path=path,
                content=content or "{}",                           # WR:5091  ★"{}" default
                commit_message=message,
                execution_context=self._execution_ctx(step_id, app_id=app_id)),  # WR:5093-5096
            start_to_close_timeout=timedelta(seconds=60),          # WR:5098  ★60s for single
            retry_policy=RETRY_POLICIES["transient"])
```

- ⚠️ **GOTCHA-WR-CA1 (`content or "{}"` empty-content default):** BOTH branches default empty
  content to the literal `"{}"` (WR:5074, WR:5091) so an empty commit still writes valid JSON. A
  rebuild must default to `"{}"`.
- ⚠️ **GOTCHA-WR-CA2 (different timeouts per branch — 120s batch / 60s single):** the batch path
  uses **120s** (WR:5081), the single path **60s** (WR:5098). A rebuild must keep the timeout
  asymmetry.
- ⚠️ **GOTCHA-WR-CA3 (default `step_id="commit-redundancy-artifacts"`):** when the caller omits
  `step_id`, the execution-context step is `"commit-redundancy-artifacts"` (WR:5065). Several
  per-app commit callers override it (e.g. `commit-disposition-artifacts`). A rebuild must keep this
  default so step_execution rows attribute correctly.

---

## 9. `_commit_output_files(self, repo, branch, result, *, primary_path, wave_id, app_id="", step_id="commit-redundancy-artifacts", commit_message_prefix) -> None` (WR:5102-5176)

**Signature** (WR:4965-4976): positional `repo, branch, result`; keyword-only `primary_path`,
`wave_id`, `app_id=""`, `step_id="commit-redundancy-artifacts"`, `commit_message_prefix`
(REQUIRED — no default). Returns `None`. Commits **additional** files the agent emitted via
`output_files` (e.g. `wave-plan.md`, `scoring-explanation.md`) — the caller already committed the
primary JSON via `_commit_artifact`.

### 9.1 CONTROL FLOW — structured pseudocode

```text
async def _commit_output_files(self, repo, branch, result, *, primary_path, wave_id,
                               app_id="", step_id="commit-redundancy-artifacts",
                               commit_message_prefix):
    if not result or not getattr(result, "output_files", None):   # ── BRANCH 1 (WR:5132)
        return                                                    # WR:5133
    wave_prefix = f"rationalization/wave-{wave_id}"               # WR:5134
    for out_file in result.output_files:                         # WR:5135  LOOP
        if isinstance(out_file, dict):           # ── BRANCH 2 (WR:5136)  dict-shaped
            raw_path = out_file.get("path", "") or ""            # WR:5137
            content = out_file.get("content", "") or ""          # WR:5138
        else:                                    # WR:5139  object-shaped
            raw_path = getattr(out_file, "path", "") or ""       # WR:5140
            content = getattr(out_file, "content", "") or ""     # WR:5141
        if not raw_path or not content:          # ── BRANCH 3 (WR:5142)  skip empties
            continue                             # WR:5143
        # Normalise the path → land next to the JSON primary artifact.
        if raw_path.startswith(wave_prefix):     # ── BRANCH 4 (WR:5148)  already wave-scoped
            final_path = raw_path                # WR:5149
        elif "/" not in raw_path:                # ── BRANCH 5 (WR:5150)  bare filename
            if app_id:                           # ── BRANCH 6 (WR:5152)
                final_path = f"{wave_prefix}/{app_id}/{raw_path}"   # WR:5153
            else:                                # WR:5154
                final_path = f"{wave_prefix}/{raw_path}"           # WR:5155
        else:                                    # WR:5156  nested relative path
            final_path = raw_path                # WR:5157
        if final_path == primary_path:           # ── BRANCH 7 (WR:5158)  caller handled primary
            continue                             # WR:5160
        try:
            await self._commit_artifact(                          # WR:5162-5170
                repo, branch, final_path, content,
                f"{commit_message_prefix}: {final_path.rsplit('/', 1)[-1]}",   # WR:5167
                step_id=step_id, app_id=app_id)
        except Exception:                        # ── BRANCH 8 (WR:5171)  best-effort
            workflow.logger.warning(                              # WR:5172-5176
                "Failed to commit output_file to artifact repo (non-fatal)",
                extra={"path": final_path, "app_id": app_id})
        # loop continues to next file
```

### 9.2 GOTCHAs

- ⚠️ **GOTCHA-WR-COF1 (three-way path normalization):** (a) path already under `wave_prefix` → use
  as-is (WR:5148-5149); (b) bare filename (no `/`) → prefix with `wave_prefix/{app_id}/` if
  `app_id` else `wave_prefix/` (WR:5150-5155); (c) nested relative path → use as-is (WR:5156-5157).
  A rebuild must reproduce all three cases so companion files land next to the JSON primary, not at
  the repo root. (The "MD shows in UI, only JSON on disk" bug, docstring WR:5121-5124, was caused
  by NOT committing these companions to git.) ⚠️ Since wave-plan + factory-routing now commit
  under `rationalization/wave-{id}/…` (sibling `-execute-b`), their companions land alongside via
  branch (a).
- ⚠️ **GOTCHA-WR-COF2 (skip primary; skip empties):** files equal to `primary_path` are skipped
  (the caller committed it) (WR:5158-5160); files with empty path OR empty content are skipped
  (WR:5142-5143). A rebuild must keep both skips.
- ⚠️ **GOTCHA-WR-COF3 (per-file failure is swallowed — never fails the wave):** each companion
  commit is wrapped in try/except that logs and continues (WR:5161-5176). Docstring WR:5129-5130:
  "do not fail the wave for a missing summary." A rebuild MUST swallow per-companion failures.
- ⚠️ **GOTCHA-WR-COF4 (commit message = `{prefix}: {basename}`):** WR:5167 —
  `f"{commit_message_prefix}: {final_path.rsplit('/', 1)[-1]}"`. A rebuild must format the message
  this way for git-history parity.
- ⚠️ **GOTCHA-WR-COF5 (dual file shape — dict OR object):** same as `_primary_output_content`
  (WR:5136-5141). Keep both shapes.

---

## 10. `_open_gate_pr(self, repo, branch, input, gate, title, body)` (WR:5178-5201)

⚠️ **GOTCHA-WR-OGP0 (this is the wave workflow's OWN PR opener — NOT `_create_gate_pr` from the
base):** the base's `_create_gate_pr` (`_LineWorkflowBase.md` §10) attaches `labels=["gate-review",
ARTIFACT_ROOT, gate_type]`. THIS method passes **NO labels** to `CreatePRInput` (WR:5189-5198) —
the wave PR has no labels. A rebuild must NOT add labels here.

```text
async def _open_gate_pr(self, repo, branch, input, gate, title, body):
    return await workflow.execute_activity(                      # WR:5187-5201
        create_pr,
        CreatePRInput(
            repo=repo, source_branch=branch, target_branch="main",   # WR:5190-5192  ★always main
            title=title, body=body,
            execution_context=self._execution_ctx(
                f"create-{gate.lower()}-pr")),                       # WR:5195-5197  ★step id from gate
        start_to_close_timeout=timedelta(seconds=60),               # WR:5199  60s
        retry_policy=RETRY_POLICIES["transient"])
```

- Activity `create_pr`; **60s**; `transient`. Returns `CreatePRResult` (has `.pr_number`,
  `.pr_url`). Caller stores `gr_pr` / `gda_pr` and later passes `.pr_number` to
  `_reconcile_and_merge_with_retry_loop` (WR:2287, WR:3019).
- ⚠️ **GOTCHA-WR-OGP1 (always targets `main`):** `target_branch="main"` (WR:5192). A rebuild keeps
  the merge target as `main`.
- ⚠️ **GOTCHA-WR-OGP2 (execution-context step id is `create-{gate.lower()}-pr`):** WR:5196 — e.g.
  `"create-g-rr-pr"`. `gate` is a string here (`"G-RR"` / `"G-DA"`), `.lower()`-ed for the step id.

---

## 11. `_build_grr_body(self, input) -> str` (WR:5203-5238)

Pure string builder for the G-RR PR body. No activities. Returns markdown.

```text
def _build_grr_body(self, input) -> str:
    body = ("## Gate G-RR Review: Wave {wave_id} Redundancy Review\n\n"          # WR:5204-5223
            "**Wave:** {wave_name or wave_id}\n"
            "**Applications:** {len(app_ids)}\n\n"
            "### Wave-Scoped Artifacts\n"
            + 6 fixed bullet lines for:
              redundancy-matrix.json, ux-overlap-matrix.json, integration-graph.json,
              portfolio-redundancy-matrix.json, shared-identity-report.json,
              business-rule-redundancy.json (T2.6)
            + "\n### Per-App Intra-Application Redundancy\n")
    for app_id in input.app_ids:                                                 # WR:5224  LOOP
        body += f"- `rationalization/wave-{input.wave_id}/{app_id}/intra-app-redundancy.json`\n"   # WR:5225
    body += "\n### Review Checklist\n"                                           # WR:5226
    body += 6 fixed checklist "- [ ] …" lines                                    # WR:5227-5235
    if self._rework_iterations_grr:                # ── BRANCH 1 (WR:5236)
        body += f"\n**Rework iteration:** {self._rework_iterations_grr}\n"        # WR:5237
    return body                                                                  # WR:5238
```

- ⚠️ **GOTCHA-WR-GRR1 (rework-iteration footer only when non-zero):** the `**Rework iteration:**`
  footer is appended ONLY when `self._rework_iterations_grr` is truthy (WR:5236-5237). On the first
  pass (counter `0`) it's omitted. A rebuild must gate the footer on a non-zero counter so the
  first PR body has no rework line.
- `wave_name or wave_id` fallback appears twice (WR:5206). Exact bullet text and checklist items
  are reproduced verbatim in the source (WR:5209-5235) — a rebuild should match them for reviewer
  parity, but they are not behaviorally load-bearing beyond the PR body content.

---

## 12. `_build_gda_body(self, input, per_app) -> str` (WR:5240-5278)

Pure string builder for the G-DA PR body. No activities.

```text
def _build_gda_body(self, input, per_app) -> str:
    body = ("## Gate G-DA Review: Wave {wave_id} Disposition Approval\n\n"        # WR:5245-5250
            "**Wave:** {wave_name or wave_id}\n"
            "**Applications:** {len(app_ids)}\n\n"
            "### Per-Application Dispositions\n")
    for app_id in input.app_ids:                                                  # WR:5251  LOOP
        result = per_app.get(app_id, {})                                          # WR:5252
        disp = result.get("disposition") or "(pending)"   # ── BRANCH (WR:5253) per-app fallback
        body += f"- `{app_id}` → **{disp}**\n"                                     # WR:5254
    body += ("\n### Wave-Scoped Artifacts\n"                                       # WR:5255-5275
             + 3 bullet lines (scoring-methodology.md, wave-plan.json, factory-routing.json)
             + "\n### Stakeholder Sign-Off Checklist\n"
             + 5 checklist lines
             + '\n**Approval requires BOTH:** PM merges this PR (`gate_approved` signal) AND '
               'stakeholder fires a `StakeholderApprovedSignal` with `scope="g-da"`.\n')
    if self._rework_iterations_gda:                # ── BRANCH 2 (WR:5276)
        body += f"\n**Rework iteration:** {self._rework_iterations_gda}\n"          # WR:5277
    return body                                                                   # WR:5278
```

- ⚠️ **GOTCHA-WR-GDA1 (per-app disposition fallback `"(pending)"`):** WR:5253 —
  `result.get("disposition") or "(pending)"`. A rebuild must render `(pending)` for apps without a
  resolved disposition. Note the wave-scoped artifact bullets still list `wave-plan.json` /
  `factory-routing.json` (now under `rationalization/wave-{id}/`).
- ⚠️ **GOTCHA-WR-GDA2 (the body DOCUMENTS the dual-signal gate):** WR:5272-5274 explicitly states
  approval requires BOTH `gate_approved` (PR merge) AND a `StakeholderApprovedSignal` with
  `scope="g-da"`. This mirrors the actual control flow in the caller (WR:3009-3016): on
  `"approved"`, the workflow ALSO waits `lambda: self._stakeholder_approved or self.cancelled`. The
  body is descriptive; the enforcement is in the caller's `run`/`_execute`.
- ⚠️ **GOTCHA-WR-GDA3 (rework-iteration footer only when non-zero):** same as GRR (WR:5276-5277).

---

## 13. `_build_scoring_methodology(self, input, portfolio_scores) -> str` (WR:5280-5330)

Pure markdown digest of the portfolio-scoring run. No activities. (Bespoke artifact
`scoring-methodology.md`.)

```text
def _build_scoring_methodology(self, input, portfolio_scores) -> str:
    lines = [ "# Wave {wave_id} Portfolio Scoring Methodology", "",            # WR:5293-5306
              "- **Wave:** {wave_name or wave_id}",
              "- **Applications scored:** {len(app_ids)}",
              "- **Methodology:** `portfolio-scorer` skill, 6 dimensions (0-100)",
              "- **Weights:** equal per-dimension (default). …",
              "", "## Per-App Overall Readiness", "",
              "| App | Overall | Dimensions Persisted |",
              "|-----|---------|----------------------|" ]
    for app_id in input.app_ids:                                               # WR:5307  LOOP
        result = portfolio_scores.get(app_id, {})                              # WR:5308
        overall = result.get("overall_weighted")                              # WR:5309
        overall_str = (f"{overall:.1f}" if isinstance(overall, (int, float))   # ── BRANCH (WR:5310)
                       else "—")
        dims = result.get("dimensions") or []                                 # WR:5311
        dims_str = str(len(dims)) if dims else "—"     # ── BRANCH (WR:5312)
        lines.append(f"| `{app_id}` | {overall_str} | {dims_str}/6 |")         # WR:5313
    lines.extend([ "", "## Interpretation Anchors", "",                        # WR:5314-5328
                   5 fixed anchor lines (90-100 … 0-29),
                   "", "See each app's `portfolio-score.json` …", "" ])
    return "\n".join(lines)                                                    # WR:5330
```

- ⚠️ **GOTCHA-WR-SM1 (numeric-vs-em-dash rendering):** `overall_str` is `f"{overall:.1f}"` ONLY if
  `overall` is `int`/`float`, else the em-dash `"—"` (WR:5310). `dims_str` is `len(dims)` if `dims`
  truthy, else `"—"` (WR:5312). A rebuild must render `"—"` for missing scores/dimensions, and
  format present scores to 1 decimal place.

---

## 14. `_build_factory_routing(self, input, per_app) -> str` (WR:5332-5394) ★ DISPOSITION ROUTING ⚠️ CHANGED

Produces `factory-routing.json` content — the deterministic route list downstream factories read.
Pure function (no activities). ⚠️ **Disposition-keyed routing — reproduce EACH disposition branch.**
⚠️ **CHANGED since baseline: a NEW `Build` disposition → NEW `build` route bucket (8 dispositions,
5 buckets — was 7/4).**

```text
def _build_factory_routing(self, input, per_app) -> str:
    import json                                  # WR:5346  (local import — workflow-safe)
    mod_factory = []                             # WR:5348
    build_factory = []                           # WR:5349  ★NEW bucket
    disp_factory = []                            # WR:5350
    retain_factory = []                          # WR:5351
    unknown_factory = []                         # WR:5352
    for app_id in input.app_ids:                 # WR:5353  LOOP
        result = per_app.get(app_id, {})         # WR:5354
        disposition = result.get("disposition") or ""   # WR:5355
        entry = { "app_id": app_id,                      # WR:5356-5360
                  "disposition": disposition,
                  "disposition_artifact": result.get("disposition_path") or "" }
        # ── DISPOSITION ROUTING (the 5 mutually-exclusive cases) ──
        if disposition in ("Refactor", "Rearchitect", "Replace", "Replatform"):  # ── CASE A (WR:5361)
            mod_factory.append(entry)            # WR:5362  → Modernization factory
        elif disposition == "Build":                                            # ── CASE A2 (WR:5366) ★NEW
            build_factory.append(entry)          # WR:5367  → Build factory (Spec→Design→Generate)
        elif disposition in ("Retire", "Consolidate"):                          # ── CASE B (WR:5368)
            disp_factory.append(entry)           # WR:5369  → Disposition Execution factory
        elif disposition == "Retain":                                           # ── CASE C (WR:5370)
            retain_factory.append(entry)         # WR:5371  → Retain factory
        else:                                    # ── CASE D (WR:5372)  unknown / empty
            unknown_factory.append(entry)        # WR:5373  → unknown bucket

    payload = { "wave_id": input.wave_id,                                       # WR:5375-5393
                "wave_name": input.wave_name or input.wave_id,
                "generated_at": _now_iso(),                                      # ★deterministic
                "routes": { "modernization": mod_factory,
                            "build": build_factory,                              # ★NEW route
                            "disposition_execution": disp_factory,
                            "retain": retain_factory,
                            "unknown": unknown_factory },
                "summary": { "modernization_count": len(mod_factory),
                             "build_count": len(build_factory),                  # ★NEW count
                             "disposition_execution_count": len(disp_factory),
                             "retain_count": len(retain_factory),
                             "unknown_count": len(unknown_factory) } }
    return json.dumps(payload, indent=2)         # WR:5394
```

- ⚠️ **GOTCHA-WR-FR1 (⚠️ CHANGED — EXACT disposition→factory mapping, now 8 dispositions / 5
  buckets):** load-bearing for downstream pipelines:
  - `Refactor`, `Rearchitect`, `Replace`, `Replatform` → **`modernization`** (CASE A, WR:5361).
  - **NEW** `Build` → **`build`** (CASE A2, WR:5366) — the Phase-6 W5 Build line
    (Spec-from-Requirements → Design → Generate); routes to `build`, **NOT** `modernization`,
    because there is no legacy source to extract.
  - `Retire`, `Consolidate` → **`disposition_execution`** (CASE B, WR:5368).
  - `Retain` → **`retain`** (CASE C, WR:5370).
  - anything else (including empty `""`) → **`unknown`** (CASE D, WR:5372).
  A rebuild MUST reproduce these exact set memberships, INCLUDING the new `Build`→`build` arm and
  the `build`/`build_count` keys in `routes`/`summary`. Note `Replace` routes to **modernization**
  (it rebuilds onto a target but EXTRACTS legacy first), while `Build` routes to its own `build`
  bucket (greenfield, no extract). `Consolidate` routes to **disposition_execution** alongside
  `Retire`. The downstream Modernization / Build / Disposition Execution factories read
  `routes.modernization` / `routes.build` / `routes.disposition_execution`.
- ⚠️ **GOTCHA-WR-FR2 (`generated_at` via `_now_iso()`):** WR:5378 — uses the deterministic
  `_now_iso()`, not `datetime.now()`. The JSON is committed to git so it must be replay-stable.
- ⚠️ **GOTCHA-WR-FR3 (local `import json` inside the method):** WR:5343-5346 — `json` is imported
  locally (workflow-safe: pure Python, deterministic). A rebuild may import at module top, but the
  source keeps it local "consistent with the rest of the workflow's helpers."
- ⚠️ **GOTCHA-WR-FR4 (`disposition_artifact` fallback `""`):** `result.get("disposition_path") or
  ""` (WR:5359) — missing path → empty string. Keep the fallback.

---

## 15. `_set_step(self, step, progress) -> None` (WR:5400-5403)

⚠️ **GOTCHA-WR-SS0 (this OVERRIDES the base `_set_step` — and is DELIBERATELY simpler):** the
base's `_set_step` (`_LineWorkflowBase.md` §6) ALSO does a DB `_update_app_status` write when
`_app_id` is set. THIS wave version does **NOT** — it only mutates three local vars. There is no
DB push, because the wave workflow is wave-scoped (no single `_app_id`). A rebuild must NOT add a
status-DB write here.

```text
async def _set_step(self, step, progress) -> None:
    self._current_step = step                        # WR:5401
    self._progress_pct = max(0.0, min(100.0, progress))   # WR:5402  ★clamped to [0,100]
    self._updated_at = _now_iso()                    # WR:5403
```

- ⚠️ **GOTCHA-WR-SS1 (progress CLAMPED to [0.0, 100.0]):** `max(0.0, min(100.0, progress))`
  (WR:5402) — unlike the base which assigns `progress` raw. Callers pass cumulative progress sums
  that could (defensively) exceed bounds; this clamps them. A rebuild must clamp.
- ⚠️ **GOTCHA-WR-SS2 (does NOT touch `_status`):** like the base, `_status` transitions are owned by
  `run`/`_execute`, not `_set_step`. The `get_status` query (WR:6111) reads `_current_step` /
  `_progress_pct` / `_updated_at` live.

---

## 16. `_wait_for_gate(self, gate_key) -> str` (WR:5405-5480) ★★ CORE GATE WAIT

⚠️ **GOTCHA-WR-WFG0 (this OVERRIDES/REPLACES the base `_wait_for_gate_decision` — KEY DIVERGENCES):**
the base (`_LineWorkflowBase.md` §13) keys decisions by a flat list + scalar cursor. THIS version
keys BOTH by **gate_key string**. It ALSO adds the **approve-with-guidance** mechanism
(`_approval_feedback`) and **card-decision rework-target resolution** that the base does NOT have
inline. (Body unchanged from baseline; only line numbers shifted +147.) Divergences vs base:
1. Per-gate `dict` queue + per-gate `dict` consume cursor (WR:5415-5417) — base uses flat
   list/int.
2. Sets `_pending_gate = GateType(gate_key) if gate_key in GateType._value2member_map_ else None`
   (WR:5411) — defensively guards an unknown gate_key string to `None`.
3. On approve, stashes reviewer justification into `_approval_feedback[gate_key]` (approve-with-
   guidance, WR:5447-5456) — base has no such mechanism.
4. On reject, computes `rework_targets = rework_targets_from_card_decisions(card_decisions)`
   (WR:5470) and stores it INTO the feedback dict (WR:5471-5479) — base stores a 6-key dict without
   `rework_targets`.
5. Does NOT touch `_rework_iterations_*` — same as base (the caller bumps; see GOTCHA-WR-WFG6).

**Returns** `"cancelled"` / `"approved"` / `"rejected"`.

### 16.1 CONTROL FLOW — structured pseudocode (preserve EVERY branch)

```text
async def _wait_for_gate(self, gate_key) -> str:
    # ── set pending-gate + status ──
    self._pending_gate = (GateType(gate_key)                  # ── BRANCH 1 (WR:5411)  defensive enum
                          if gate_key in GateType._value2member_map_ else None)
    self._status = WorkflowStatus.WAITING_FOR_SIGNAL          # WR:5412
    self._updated_at = _now_iso()                             # WR:5413

    self._gate_decisions.setdefault(gate_key, [])             # WR:5415
    self._gate_decisions_consumed.setdefault(gate_key, 0)     # WR:5416
    consumed = self._gate_decisions_consumed[gate_key]        # WR:5417  ★snapshot cursor BEFORE wait

    await workflow.wait_condition(                            # WR:5419-5421 ★PREDICATE
        lambda: len(self._gate_decisions[gate_key]) > consumed or self.cancelled)

    if self.cancelled:                          # ── BRANCH 2 (WR:5422)  cancel short-circuit
        self._status = WorkflowStatus.CANCELLED  # WR:5423
        self._updated_at = _now_iso()            # WR:5424
        return "cancelled"                       # WR:5425  ← WITHOUT consuming

    entry = self._gate_decisions[gate_key][consumed]   # WR:5426  read at snapshot index
    # 5-tuple vs legacy 3-tuple
    if len(entry) == 5:                         # ── BRANCH 3 (WR:5430)
        decision, actor, reason, reason_category, card_decisions = entry   # WR:5431
    else:                                       # WR:5432  legacy 3-tuple
        decision, actor, reason = entry[0], entry[1], entry[2]   # WR:5433
        reason_category = None                  # WR:5434
        card_decisions = []                     # WR:5435
    self._gate_decisions_consumed[gate_key] = consumed + 1   # WR:5436  ★advance cursor
    self._pending_gate = None                   # WR:5437
    self._status = WorkflowStatus.RUNNING       # WR:5438
    self._updated_at = _now_iso()               # WR:5439

    if decision == GateStatus.APPROVED:         # ── BRANCH 4 (WR:5440)  APPROVE
        self._rework_feedback.pop(gate_key, None)   # WR:5441  clear prior rework feedback
        stripped_reason = (reason or "").strip()    # WR:5447
        if stripped_reason:                     # ── BRANCH 5 (WR:5448)  approve-with-guidance
            self._approval_feedback[gate_key] = {   # WR:5449-5454
                "gate": gate_key, "approved_by": actor,
                "guidance": stripped_reason, "approved_at": _now_iso()}
        else:                                   # WR:5455
            self._approval_feedback.pop(gate_key, None)   # WR:5456  vanilla approval → clear
        return "approved"                       # WR:5457

    # ── REJECT path ──
    self._approval_feedback.pop(gate_key, None) # WR:5462  clear stale approval-guidance
    rework_targets = rework_targets_from_card_decisions(card_decisions)   # WR:5470
    self._rework_feedback[gate_key] = {         # WR:5471-5479
        "gate": gate_key, "rejected_by": actor, "reason": reason,
        "reason_category": reason_category, "card_decisions": card_decisions,
        "rework_targets": rework_targets, "rejected_at": _now_iso()}
    return "rejected"                           # WR:5480
```

### 16.2 GOTCHAs

- ⚠️ **GOTCHA-WR-WFG1 (the cursor pattern — snapshot, index, advance — PER GATE KEY):** `consumed =
  self._gate_decisions_consumed[gate_key]` is snapshotted BEFORE the wait (WR:5417); the predicate is
  `len(self._gate_decisions[gate_key]) > consumed` (WR:5420); the consumer reads
  `self._gate_decisions[gate_key][consumed]` (WR:5426) and advances `consumed + 1` (WR:5436). This is
  race-safe against signals that arrive BEFORE `_wait_for_gate` is called (the signal handlers buffer
  into `_gate_decisions[gate_key]`, WR:5819/5843). A rebuild MUST use this snapshot-index-advance
  pattern PER gate_key — not the base's single scalar cursor, or a G-DA decision arriving during a
  G-RR wait would be mis-counted.
- ⚠️ **GOTCHA-WR-WFG2 (`cancelled` short-circuits BEFORE consuming):** BRANCH 2 (WR:5422-5425)
  returns `"cancelled"` WITHOUT reading/advancing the cursor. A cancel during a gate wait leaves the
  decision queue untouched. Keep cancel-check first.
- ⚠️ **GOTCHA-WR-WFG3 (5-tuple vs 3-tuple tolerance):** like the base (GOTCHA-S1), the consumer
  tolerates BOTH a 5-tuple `(status, actor, reason, reason_category, card_decisions)` and a legacy
  3-tuple `(status, actor, reason)` (WR:5430-5435). The signal handlers append 5-tuples (WR:5806-5812,
  WR:5830-5836), but the consumer must accept 3-tuples for any legacy buffered entry. A rebuild must
  branch on `len(entry) == 5`.
- ⚠️ **GOTCHA-WR-WFG4 (`_pending_gate` defensive enum guard):** WR:5411 —
  `GateType(gate_key) if gate_key in GateType._value2member_map_ else None`. An unknown gate_key
  string yields `_pending_gate = None` instead of raising `ValueError` from `GateType(...)`. A rebuild
  must guard the enum construction against unknown keys (the `get_status` query reads `_pending_gate`).
- ⚠️ **GOTCHA-WR-WFG5 (approve-with-guidance lifecycle — the FULL three-way):**
  - APPROVE with non-empty stripped reason → SET `_approval_feedback[gate_key]` (WR:5448-5454) AND
    POP `_rework_feedback[gate_key]` (WR:5441). The next downstream dispatch reads
    `context["approval_guidance"]` from `_approval_feedback` (caller WR:3396).
  - APPROVE with empty/whitespace reason → POP `_approval_feedback[gate_key]` (WR:5456) (clean
    approval carries no guidance) AND POP `_rework_feedback[gate_key]` (WR:5441).
  - REJECT → POP `_approval_feedback[gate_key]` (WR:5462) (clear any prior approve-guidance so the
    rerun doesn't see contradictory steers — comment WR:5458-5461) AND SET `_rework_feedback[gate_key]`
    (WR:5471-5479).
  A rebuild MUST implement all three transitions exactly: approve clears rework + conditionally
  sets/clears approval-guidance; reject clears approval-guidance + sets rework.
- ⚠️ **GOTCHA-WR-WFG6 (does NOT bump `_rework_iterations_*`):** despite consuming a reject, this
  method does NOT touch `_rework_iterations_grr` / `_rework_iterations_gda`. The CALLER bumps the
  per-gate counter on the `"rejected"` branch (WR:2292 for G-RR, WR:3037 for G-DA) and enforces
  `MAX_REWORK_ITERATIONS = 3` (WR:759). A rebuild must bump in the caller, not here, to avoid
  double-counting.
- ⚠️ **GOTCHA-WR-WFG7 (rework-target resolution lives HERE):** `rework_targets =
  rework_targets_from_card_decisions(card_decisions)` (WR:5470; helper at WR:683) is stored into the
  feedback dict (WR:5477). The caller reads `(self._rework_feedback.get("G-RR") or
  {}).get("rework_targets", [])` (WR:2308-2312) to decide which steps to re-run on rework. Empty
  list = legacy whole-gate reject → caller falls back to full-fan-out rerun. A rebuild must store
  `rework_targets` in the feedback dict so the caller's card-scoped rework boundary works.
- ⚠️ **GOTCHA-WR-WFG8 (`_status` round-trip WAITING_FOR_SIGNAL → RUNNING/CANCELLED):** sets
  `WAITING_FOR_SIGNAL` on entry (WR:5412), then `RUNNING` on consumption (WR:5438) or `CANCELLED` on
  cancel (WR:5423). The `get_status` query (WR:6111) reflects this so the dashboard shows the gate
  wait window with `pending_gate` set.

---

## 17. `_merge_capability_lineage_row_rework(self, gate_id) -> None` (WR:5482-5569)

Reads row-level rework feedback persisted on a gate and merges it into
`self._rework_feedback["G-DA"]` as structured `row_rework` entries. Called by the caller on the
G-DA `"rejected"` branch BEFORE re-running the per-app pipelines (WR:3054-3056).
(Body unchanged from baseline; only line numbers shifted +147.)

### 17.1 Activity call
- `fetch_gate_capability_lineage_rework` with `FetchGateCapabilityLineageReworkInput(gate_id)`
  (WR:5514-5523); **30s**; `transient`; **`activity_id=f"fetch-capability-lineage-rework-{gate_id}-
  iter-{self._rework_iterations_gda}"`** (WR:5519-5522). Result type
  `FetchGateCapabilityLineageReworkResult` (`types.py:982-997`): `gate_id`, `ratified_count`,
  `rejected_count`, `rejected_rows: list[CapabilityLineageRowRework]` (each row has `lineage_id`,
  `feedback`, `source_capability`, `target_capability`, `source_system`, `target_system`,
  `relationship` — `types.py:962-978`).

### 17.2 CONTROL FLOW — structured pseudocode

```text
async def _merge_capability_lineage_row_rework(self, gate_id) -> None:
    if not gate_id:                              # ── BRANCH 1 (WR:5511)
        return                                   # WR:5512
    try:
        result = await workflow.execute_activity(                       # WR:5514-5523
            fetch_gate_capability_lineage_rework,
            FetchGateCapabilityLineageReworkInput(gate_id=gate_id),
            start_to_close_timeout=timedelta(seconds=30),
            retry_policy=RETRY_POLICIES["transient"],
            activity_id=(f"fetch-capability-lineage-rework-{gate_id}-"
                         f"iter-{self._rework_iterations_gda}"))          # ★iter-stamped id
    except Exception as exc:                     # ── BRANCH 2 (WR:5524)  best-effort
        workflow.logger.warning(                 # WR:5525-5529
            "fetch_gate_capability_lineage_rework failed: %s", exc,
            extra={"gate_id": gate_id})
        return                                   # WR:5530  ← swallow; leave free-text feedback intact

    if not result.rejected_rows:                 # ── BRANCH 3 (WR:5531)  no row-level decisions
        return                                   # WR:5535  ← gate-level free-text path already wired

    existing = self._rework_feedback.get("G-DA") or {}   # WR:5542
    merged = dict(existing)                      # WR:5543  ★copy so we don't overwrite keys
    merged["row_rework"] = [                      # WR:5544-5555
        {"lineage_id": r.lineage_id, "feedback": r.feedback,
         "source_capability": r.source_capability, "target_capability": r.target_capability,
         "source_system": r.source_system, "target_system": r.target_system,
         "relationship": r.relationship}
        for r in result.rejected_rows]
    merged["row_rework_summary"] = {              # WR:5556-5559
        "ratified_count": result.ratified_count, "rejected_count": result.rejected_count}
    self._rework_feedback["G-DA"] = merged        # WR:5560  ★replace whole slot
    workflow.logger.info("capability_lineage_row_rework_merged", extra={...})   # WR:5561-5569
```

### 17.3 GOTCHAs

- ⚠️ **GOTCHA-WR-CLR1 (best-effort — three early returns, all non-fatal):** (a) no `gate_id` →
  return (WR:5511-5512); (b) activity exception → log + return, leaving the existing free-text
  `_rework_feedback["G-DA"]` (set by `_wait_for_gate`) untouched (WR:5524-5530); (c) no rejected rows
  → return, free-text path already populated (WR:5531-5535). Docstring WR:5499-5505: "a thrown
  exception or empty result leaves the existing free-text `_rework_feedback['G-DA']` unchanged so the
  gate rework path keeps working even if the new read-back path fails." A rebuild MUST make all three
  cases non-fatal.
- ⚠️ **GOTCHA-WR-CLR2 (MERGE — does NOT clobber existing feedback keys):** `merged =
  dict(existing)` then `merged["row_rework"] = [...]` (WR:5543-5544) — it COPIES the existing
  free-text feedback dict (already set by `_wait_for_gate` on the reject) and ADDS `row_rework` +
  `row_rework_summary` ALONGSIDE the existing keys (`reason`, `card_decisions`, `rework_targets`,
  etc.). It does NOT overwrite. Comment WR:5537-5541. A rebuild must merge-not-replace so SKILL.md
  authors see BOTH the gate-level free text AND the structured rows.
- ⚠️ **GOTCHA-WR-CLR3 (idempotent — `activity_id` stamped with rework iteration):** the
  `activity_id=f"…-iter-{self._rework_iterations_gda}"` (WR:5519-5522) makes the fetch idempotent
  per rework iteration on replay AND distinct across iterations (so iteration N's fetch isn't
  cached-collided with iteration N+1). Docstring WR:5499-5501: "multiple invocations with the same
  gate_id are safe — the read activity is read-only and the merge replaces the existing `row_rework`
  slot." A rebuild must include the iteration in the activity id.
- ⚠️ **GOTCHA-WR-CLR4 (catches bare `Exception`, not just `ActivityError`):** WR:5524 catches
  `except Exception` (wider than `_validate_artifact_or_warn`'s `ActivityError`). Keep the wide
  catch — this is a best-effort enhancement that must never fail the rework.

---

## 18. `_run_gate_pre_review(self, gate_id, gate_type_value, evidence_paths, *, artifact_repo="", artifact_ref="", optional_evidence_paths=None) -> None` (WR:5571-5685) ⚠️ SIGNATURE CHANGED

⚠️ **GOTCHA-WR-PRV0 (this OVERRIDES/REPLACES the base `_run_gate_pre_review` — KEY DIVERGENCES):**
inlined port of `LineWorkflowBase._run_gate_pre_review` (`_LineWorkflowBase.md` §12). Divergences:
1. **NO `finally: mark_gate_ready_for_review`** — the base flips the gate to ready in a `finally`
   block (base §12 GOTCHA-PR2). THIS version does NOT; the docstring (WR:5599-5601) explicitly says
   "The caller is still responsible for flipping the gate to `ready_for_review` via
   `mark_gate_ready_for_review` after this helper returns." Indeed both callers call
   `mark_gate_ready_for_review` themselves AFTER (WR:2273-2278 for G-RR, WR:2998-3003 for G-DA).
2. **G-DA-specific prompt context enrichment** (WR:5628-5641) — adds `tier1_approvals` +
   `downstream_artifact_kinds` ONLY when `gate_type_value == "G-DA"`. The base passes only
   `{gate_id, gate_type}`.
3. `app_id=""` and `wave_id=self._wave_id` in the `AgentTaskInput` (WR:5647-5648) — the base passes
   `app_id=self._app_id`. The wave workflow has no single app.
4. ⚠️ **NEW kwarg `optional_evidence_paths: list[str] | None = None`** (WR:5579) threaded into the
   dispatch as `optional_input_artifacts=list(optional_evidence_paths or [])` (WR:5651) — the base
   has no such param. The G-RR caller passes `optional_evidence_paths=grr_pre_review_optional` (the
   `shared-identity-report.json` companion, sibling `-execute-a` WR:2247/2255/2271); the G-DA caller
   omits it (no optional companion, sibling `-execute-b` WR:2991-2997).

### 18.1 Activity calls in order
| # | Callee | Args (key fields) | timeout | retry | Notes |
|---|--------|-------------------|---------|-------|-------|
| 1 | `dispatch_agent_task` (WR:5643) | `AgentTaskInput(skill_id="gate-pre-review", app_id="", wave_id=self._wave_id, task_type="gate-pre-review", input_artifacts=evidence_paths, optional_input_artifacts=list(optional_evidence_paths or []), artifact_repo, artifact_ref, context=pre_review_context, execution_context=…)` (WR:5645-5660) | **10 minutes** (WR:5661) | `transient` (WR:5662) | inside try; ★`optional_input_artifacts` is NEW (WR:5651) |
| 2 | `store_gate_pre_review` (WR:5671) | `StoreGatePreReviewInput(gate_id, agent_output=agent_markdown)` (WR:5673-5676) | **30s** (WR:5677) | `transient` (WR:5678) | only if markdown non-empty |

### 18.2 CONTROL FLOW — structured pseudocode (preserve EVERY branch)

```text
async def _run_gate_pre_review(self, gate_id, gate_type_value, evidence_paths, *,
                               artifact_repo="", artifact_ref="", optional_evidence_paths=None):  # WR:5571-5580
    pre_review_context: dict = {"gate_id": gate_id, "gate_type": gate_type_value}   # WR:5624-5627
    if gate_type_value == "G-DA":               # ── BRANCH 1 (WR:5628)  G-DA enrichment
        pre_review_context["tier1_approvals"] = [                                   # WR:5629-5632
            self._tier1_approval_records[app_id]
            for app_id in sorted(self._tier1_approval_records)]                      # ★sorted → deterministic
        pre_review_context["downstream_artifact_kinds"] = [                          # WR:5635-5641
            "disposition-recommendation", "disposition-governance",
            "user-impact-analysis", "classification", "portfolio-score"]
    try:
        pre_review_result = await workflow.execute_activity(                         # WR:5643-5663
            dispatch_agent_task,
            AgentTaskInput(skill_id="gate-pre-review", app_id="",
                           wave_id=self._wave_id, task_type="gate-pre-review",
                           input_artifacts=evidence_paths,
                           optional_input_artifacts=list(optional_evidence_paths or []),  # WR:5651 ★NEW
                           artifact_repo=artifact_repo, artifact_ref=artifact_ref,
                           context=pre_review_context,
                           execution_context=self._execution_ctx(
                               f"ai-pre-review-{gate_type_value.lower()}",
                               gate_id=gate_id, input_artifact_paths=evidence_paths)),
            start_to_close_timeout=timedelta(minutes=10),
            retry_policy=RETRY_POLICIES["transient"])
        agent_markdown = (pre_review_result.output_artifacts[0]      # ── BRANCH 2 (WR:5664-5668)
                          if pre_review_result.output_artifacts else "")
        if not agent_markdown:                  # ── BRANCH 3 (WR:5669)
            raise ValueError("Gate pre-review produced no output")   # WR:5670
        await workflow.execute_activity(                             # WR:5671-5679
            store_gate_pre_review,
            StoreGatePreReviewInput(gate_id=gate_id, agent_output=agent_markdown),
            start_to_close_timeout=timedelta(seconds=30),
            retry_policy=RETRY_POLICIES["transient"])
    except Exception:                           # ── BRANCH 4 (WR:5680)  best-effort
        workflow.logger.warning(                # WR:5681-5685
            f"Gate pre-review failed for {gate_type_value}; continuing "
            "without AI recommendation", extra={"gate_id": gate_id})
    # NOTE: NO finally block. Caller flips gate ready_for_review itself.
```

### 18.3 GOTCHAs

- ⚠️ **GOTCHA-WR-PRV1 (NO `finally` ready-flip — caller's responsibility):** see GOTCHA-WR-PRV0(1).
  Both gate-orchestration sites guard the pre-review behind
  `workflow.patched("wave-rationalization-gate-pre-review-v1")` (WR:2235, WR:2990) and then ALWAYS
  call `mark_gate_ready_for_review` (WR:2273/2998) OUTSIDE/AFTER the patch-guarded pre-review. So
  the gate becomes reviewable even when pre-review is skipped (pre-patch replay) or fails. A rebuild
  must NOT put the ready-flip inside this method.
- ⚠️ **GOTCHA-WR-PRV2 (best-effort — whole body in try/except Exception):** a failing pre-review
  dispatch, empty output, or store failure all land in `except Exception` (WR:5680), log a warning,
  and return cleanly (WR:5681-5685). Docstring WR:5596-5598: "any exception is logged and swallowed
  so a flaky pre-review agent never blocks a reviewer from seeing the gate." Keep the wide catch.
- ⚠️ **GOTCHA-WR-PRV3 (empty output → `raise ValueError` → caught locally):** WR:5669-5670 raises
  inside the try; the local `except Exception` catches it. This is a deliberate "treat empty output
  as failure" path. A rebuild must raise-then-catch (the store activity is skipped on empty output).
- ⚠️ **GOTCHA-WR-PRV4 (`tier1_approvals` sorted for determinism):** `for app_id in
  sorted(self._tier1_approval_records)` (WR:5631) — sorted iteration makes the context payload (and
  thus the dispatch input) replay-stable. A rebuild MUST sort the app_ids.
- ⚠️ **GOTCHA-WR-PRV5 (`artifact_repo`/`artifact_ref` MUST be passed or pre-review runs blind):**
  docstring WR:5588-5594 (same as base GOTCHA-PR1): without a non-empty `artifact_repo`, the
  agent-side `_fetch_input_artifacts` no-ops and the skill runs with `input_artifacts_dir=""`. Both
  callers pass `artifact_repo=repo, artifact_ref=branch` (WR:2269-2270, WR:2995-2996). Thread them
  through.
- ⚠️ **GOTCHA-WR-PRV6 (execution-context step id `ai-pre-review-{gate_type_value.lower()}`):**
  WR:5656 — e.g. `"ai-pre-review-g-da"`. The `gate_id` is also threaded into the execution context
  (WR:5657) so the step_execution row links to the gate.
- ⚠️ **GOTCHA-WR-PRV7 (NEW — `optional_evidence_paths` → `optional_input_artifacts`):** the new
  kwarg (WR:5579) routes through to `optional_input_artifacts=list(optional_evidence_paths or [])`
  (WR:5651), so a file in the optional set that is *missing on the branch* is skipped (the agent
  runtime treats a 404 as "not present yet") rather than raising `FileNotFoundError` in
  `_fetch_input_artifacts` — which previously took down the whole pre-review and left reviewers on an
  empty AI-recommendation panel. Docstring WR:5603-5612 records this: the rat-cap-rewritten
  `analyze-portfolio-redundancy` skill no longer always emits the `shared-identity-report.json`
  companion, so the G-RR caller now passes it via `optional_evidence_paths` (sibling `-execute-a`
  WR:2247/2255/2271), NOT as a required `evidence_paths` entry. The G-DA caller passes none. A
  rebuild MUST add this kwarg, default `None`, wrap as `list(... or [])`, and route to
  `optional_input_artifacts`.

---

## 19. `_reconcile_and_merge_with_retry_loop(self, *, repo, pr_number, gate_id, merge_method="merge") -> None` (WR:5687-5762) ★★ CORE MERGE LOOP

⚠️ **GOTCHA-WR-MRG0 (this OVERRIDES/REPLACES the base `_reconcile_and_merge_with_retry_loop`):**
inlined duplicate of `LineWorkflowBase._reconcile_and_merge_with_retry_loop`
(`_LineWorkflowBase.md` §14). Docstring WR:5695-5699: "WaveRationalizationWorkflow doesn't inherit
from LineWorkflowBase so the helper is duplicated here. … behavior is identical." This spec
reproduces it in full. Called by both gate sites on the `"approved"` branch (WR:2286-2290 for G-RR,
WR:3018-3022 for G-DA — for G-DA only AFTER the dual-signal stakeholder wait).

### 19.1 Activity calls (per loop iteration, in order)
| # | Callee | Args | timeout | retry | Notes |
|---|--------|------|---------|-------|-------|
| 1 | `reconcile_and_merge_pr` (WR:5713) | `MergePRInput(repo, pr_number, merge_method, execution_context=merge_ctx)` (WR:5715-5720) | **60s** (WR:5721) | **`git_merge`** (WR:5722) — 3 attempts + non_retryable | success → `return` |
| 2 | `set_gate_merge_blocked` (WR:5752) | positional `args=[gate_id, detail]` (WR:5754) | **30s** (WR:5755) | `transient` (WR:5756) | only on structured merge error |
| 3 | (then) `workflow.wait_condition(merge_retry_signalled or cancelled)` (WR:5758-5760) | — | — | — | blocks for reviewer retry |

### 19.2 CONTROL FLOW — structured pseudocode (preserve EVERY branch + both loops)

```text
async def _reconcile_and_merge_with_retry_loop(self, *, repo, pr_number, gate_id,
                                               merge_method="merge"):
    merge_failure_types = {"MergeConflict", "MergeDivergenceUnresolved",          # WR:5701-5705
                           "MergeBranchProtectionRejected"}
    merge_ctx = self._execution_ctx(f"merge-pr-{pr_number}", gate_id=gate_id)     # WR:5707-5710

    while True:                                  # WR:5711  ★OUTER LOOP
        try:
            await workflow.execute_activity(                                      # WR:5713-5723
                reconcile_and_merge_pr,
                MergePRInput(repo=repo, pr_number=pr_number,
                             merge_method=merge_method, execution_context=merge_ctx),
                start_to_close_timeout=timedelta(seconds=60),
                retry_policy=RETRY_POLICIES["git_merge"])
            return                               # WR:5724  ← SUCCESS exits the loop

        except (ActivityError, ApplicationError) as outer_exc:   # ── BRANCH 1 (WR:5725)
            inner: BaseException = outer_exc     # WR:5726
            while (not isinstance(inner, ApplicationError)       # WR:5727-5731  ★INNER UNWRAP LOOP
                   and getattr(inner, "__cause__", None) is not None):
                inner = inner.__cause__          # WR:5731
            if not isinstance(inner, ApplicationError):   # ── BRANCH 2 (WR:5732)  can't unwrap
                raise                            # WR:5733  ← non-structured failure propagates
            failure_type = inner.type or ""      # WR:5734
            if failure_type not in merge_failure_types:   # ── BRANCH 3 (WR:5735)  not a merge error
                raise                            # WR:5736  ← unrelated failure propagates
            detail = {"failure_type": failure_type, "reason": str(inner),         # WR:5737-5742
                      "pr_number": pr_number, "detected_at": _now_iso()}
            workflow.logger.warning("merge_blocked", extra={                       # WR:5743-5750
                "gate_id": gate_id, "pr_number": pr_number, "failure_type": failure_type})

            self._merge_retry_signalled = False  # WR:5751  ★RESET BEFORE the block
            await workflow.execute_activity(                                       # WR:5752-5757
                set_gate_merge_blocked,
                args=[gate_id, detail],          # WR:5754  ★positional args, NOT a dataclass
                start_to_close_timeout=timedelta(seconds=30),
                retry_policy=RETRY_POLICIES["transient"])
            await workflow.wait_condition(                                         # WR:5758-5760 ★PREDICATE
                lambda: self._merge_retry_signalled or self.cancelled)
            if self.cancelled:                   # ── BRANCH 4 (WR:5761)
                return                           # WR:5762  ← cancel exits the loop (no merge)
            # else: loop back to top → retry the merge
```

### 19.3 GOTCHAs

- ⚠️ **GOTCHA-WR-MRG1 (`__cause__` unwrap — Temporal wraps ApplicationError):** Temporal wraps
  activity failures in `ActivityError`; the structured `ApplicationError` (carrying `.type` = the
  failure class name like `"MergeConflict"`) lives in `__cause__`. The inner `while`
  (WR:5727-5731) walks `__cause__` until it finds an `ApplicationError` OR runs out of causes. The
  `except` catches BOTH `ActivityError` and a directly-raised `ApplicationError` (WR:5725). A rebuild
  MUST walk `__cause__` to extract `inner.type` — reading `outer_exc.type` directly would miss the
  wrapped type.
- ⚠️ **GOTCHA-WR-MRG2 (TWO re-raise escapes — only the 3 merge types enter the wait):** (a) if
  unwrapping never yields an `ApplicationError`, `raise` (WR:5732-5733) — non-structured failure
  propagates and the workflow fails. (b) if `failure_type` is not in `merge_failure_types`, `raise`
  (WR:5735-5736) — unrelated activity failure propagates. ONLY `MergeConflict` /
  `MergeDivergenceUnresolved` / `MergeBranchProtectionRejected` enter the `merge_blocked` wait. A
  rebuild MUST keep BOTH escapes or an unrelated failure gets silently trapped in the loop forever.
- ⚠️ **GOTCHA-WR-MRG3 (reset `_merge_retry_signalled=False` BEFORE the block):** WR:5751 — the flag
  is reset BEFORE the `set_gate_merge_blocked` activity AND before the `wait_condition`, so a stale
  retry signal from a PRIOR loop iteration can't immediately short-circuit a fresh wait. The
  `merge_retry` signal handler (WR:5768-5772) sets it unconditionally to `True`. A rebuild MUST reset
  before the block, not after.
- ⚠️ **GOTCHA-WR-MRG4 (`git_merge` policy is what surfaces the structured type):** the merge uses
  `RETRY_POLICIES["git_merge"]` (WR:5722), whose `non_retryable_error_types` are exactly the three
  merge failure types (`retry_policies.py:99-103`). This makes Temporal short-circuit
  (MergeConflict / MergeBranchProtection) or exhaust (MergeDivergence after 3 attempts) and surface
  the `ApplicationError.type` to the `except`. A rebuild MUST use `git_merge` here — `transient`
  would retry the merge forever at the Temporal level and never reach `merge_blocked`.
- ⚠️ **GOTCHA-WR-MRG5 (cancel during merge_blocked returns cleanly, no merge):** `if self.cancelled:
  return` (WR:5761-5762) exits the loop WITHOUT merging. The predicate includes `or self.cancelled`
  (WR:5759). A rebuild must thread `cancelled` into the wait and return on it (the inherited mixin
  `cancel_workflow` sets `self.cancelled`).
- ⚠️ **GOTCHA-WR-MRG6 (positional `args=` on `set_gate_merge_blocked`):** WR:5754 — invoked with
  positional `args=[gate_id, detail]`, NOT a dataclass (unlike `reconcile_and_merge_pr` which passes
  `MergePRInput`). A rebuild must match the positional shape.
- ⚠️ **GOTCHA-WR-MRG7 (`detail.detected_at` via `_now_iso()`):** WR:5741 — deterministic timestamp.
  `detail` is persisted to the gate row; keep `_now_iso()`.
- ⚠️ **GOTCHA-WR-MRG8 (`merge_ctx` built ONCE before the loop):** WR:5707-5710 — the
  `_execution_ctx` is computed once and reused across every merge attempt (step id
  `merge-pr-{pr_number}`). A rebuild may rebuild it per-iteration (deterministic) but the source
  builds it once.

---

## 20. RESILIENCE summary (this file's scope)

- **Timeouts (start_to_close):** validate_artifact 30s; write_artifacts_batch (commit) 120s;
  write_artifact (single commit) 60s; create_pr 60s; fetch_gate_capability_lineage_rework 30s;
  dispatch_agent_task (pre-review) 10m; store_gate_pre_review 30s; reconcile_and_merge_pr 60s;
  set_gate_merge_blocked 30s. Child workflow waits (`h.result()`) have no explicit timeout (governed
  by the child's own run timeout).
- **Heartbeats:** none configured by methods in this file.
- **continue-as-new:** none in this file's methods.
- **Idempotency:** deterministic `activity_id`s where set —
  `fetch-capability-lineage-rework-{gate_id}-iter-{rework_gda}` (WR:5519-5522). The commit / PR /
  merge activities here do NOT set explicit `activity_id`s (they rely on Temporal's command sequence
  for replay stability). `_now_iso()` / `workflow.now()` used for all timestamps and `run_ts`.
- **Patch gates (reproduce VERBATIM):** `"arch-data-sibling-lifecycle-v1"` (WR:4700),
  `"wave-rationalization-batch-writes-v1"` (WR:5068). (The pre-review patch
  `"wave-rationalization-gate-pre-review-v1"` and the dispatch patch
  `"wave-rationalization-architecture-dispatch-v1"` gate the CALLERS of my methods, WR:2235/2990 and
  WR:3248, but are not inside my line range.)
- **Best-effort / swallow-and-continue activities:** `_validate_artifact_or_warn` (swallows
  `ActivityError`), `_commit_output_files` (per-companion try/except), `_merge_capability_lineage_row_rework`
  (swallows `Exception` + empty results), `_run_gate_pre_review` (swallows all `Exception`),
  `_update_wave_status_safe` (out-of-scope, best-effort by name). All of these NEVER fail the wave.
- **Compensation / rollback:** none in this file. Structured merge errors route to `merge_blocked`
  and wait for reviewer retry (§19). Cancel (`self.cancelled`) drains the fan-out wait (§2 BRANCH 1),
  the gate wait (§16 BRANCH 2), and the merge-blocked wait (§19 BRANCH 4) to clean returns.
- **Recoverable-vs-terminal failure:** `_execute_architecture_data_fanout` returns
  `"stuck-awaiting-recovery"` for post-artifact provisioning/child failures (Task #88), which the
  caller / API treats as RECOVERABLE (`RECOVERABLE_FAILURE_ACTIVITIES`, WR:280-294).

---

## 21. BEHAVIORAL PARITY CHECKLIST (concrete assertions a rebuild MUST pass)

**Class shape & inheritance**
1. `WaveRationalizationWorkflow` inherits ONLY `HILSignalsMixin` (NOT `LineWorkflowBase`).
   `_execution_ctx`, `_set_step`, `_wait_for_gate`, `_run_gate_pre_review`,
   `_reconcile_and_merge_with_retry_loop` are all defined INLINE on this class. (GOTCHA-WR0)
2. `_gate_decisions` is `dict[str, list[tuple]]` and `_gate_decisions_consumed` is `dict[str, int]`,
   keyed by gate_key string (`"G-RR"`/`"G-DA"`) — NOT the base's flat list + scalar. (GOTCHA-WR-STATE1)

**`_execute_architecture_data_fanout`**
3. Sets `_current_step="awaiting-architecture-dispatch"`, computes `_pending_dispatch_entries` and
   `_pending_target_dispatch_entries`, pushes wave status, then `wait_condition(_dispatch_received or
   cancelled)`. On cancel → `"cancelled"`. On `payload is None or not payload.targets` → push
   `"completed"`, return `"completed"`.
4. `run_ts = int(workflow.now().timestamp())` (deterministic). Provision targets via
   `asyncio.gather(..., return_exceptions=True)`. For each: `BaseException` → status `failed` +
   `continue`; else status `provisioned`, spawn children in try/except (failure → status `failed`,
   error `spawn_children: {exc!r}`), extend `child_handles` with `[arch, data]`. (GOTCHA-WR-FO2/FO3)
5. Drain retries via `_drain_retry_queue`. Then: if any status `architecture_in_flight` → push
   `"architecture-in-flight"`; elif `not child_handles` → reason-summarize (sliced `[:500]`), push
   `"stuck-awaiting-recovery"`, return `"stuck-awaiting-recovery"`. (GOTCHA-WR-FO5/FO7)
6. Under `workflow.patched("arch-data-sibling-lifecycle-v1")` → push `"architecture-dispatched"`,
   return `"dispatched"` BEFORE Phase 2. (GOTCHA-WR-FO6)
7. Phase 2: `gather([h.result()…], return_exceptions=True)`; attribute results back to targets in
   `[arch,data]` pairs (`idx += 2`), skipping `failed` targets WITHOUT advancing idx, breaking when
   `idx+1 >= len(child_results)`; set `completed`/`failed` with `arch:`/`data:` error parts. If
   any `failed` → push `"stuck-awaiting-recovery"` (reason sliced `[:500]`), return it. Else push
   `"completed"`, return `"completed"`. (GOTCHA-WR-FO3/FO4)

**`_drain_retry_queue`**
8. `while self._pending_retries: pop(0)` (re-evaluated each loop, GOTCHA-WR-DR4). Lookup
   `_dispatch_status.get(retry.source_app_id)` (v1-only key, GOTCHA-WR-DR1); `None` → log + continue.
   Find `orig_cfg` by `source_app_id` in `_dispatch_payload.targets`; `None` → status `failed`
   ("retry: original dispatch entry missing") + continue.
9. Build `retried_cfg` reusing `orig_cfg.disposition` + `list(orig_cfg.peer_source_app_ids)`; only
   `target_app_name`/`target_repo`/`default_branch` from payload (`default_branch` falsy-fallback).
   Set status `provisioning`, clear error. Provision in try/except (fail → `failed` + repr +
   continue); set `provisioned`; spawn in try/except (fail → `failed` + `spawn_children: {exc!r}`),
   extend `child_handles`. (GOTCHA-WR-DR2/DR3)

**`_execution_ctx`**
10. Returns `None` iff `not self._portfolio_id`; else `StepExecutionContext` with
    `line_id="rationalization"` (literal), `wave_id=self._wave_id` (always), `app_id` passed through,
    `input_artifact_paths=list(... or [])`. (GOTCHA-WR-EC0/EC1/EC2)

**`_validate_artifact_or_warn`**
11. Empty `raw_content` → return. `validate_artifact_against_schema` (30s/`transient`) wrapped in
    `except ActivityError` (NOT bare Exception) → log + return. `not result.errors` → return.
    `warning_key = app_id or f"wave-{wave_id}"`. Log "schema validation failed" if `validated` else
    "could not be parsed"; in BOTH cases `setdefault(warning_key, []).extend(result.errors)`.
    (GOTCHA-WR-VAL1/VAL2/VAL3/VAL4)

**`_agent_narrative` / `_primary_output_content`**
12. `_agent_narrative`: `None`/empty artifacts → `""`; else `output_artifacts[0] or ""`. (None-safe)
13. `_primary_output_content`: search `output_files` (dict OR object shape) for basename ==
    `primary_filename`, return its content; else fall back to `output_artifacts[0] or ""`. Workspace
    file WINS. (GOTCHA-WR-POC1/POC2/POC3/POC4)

**`_commit_artifact` / `_commit_output_files`**
14. `_commit_artifact`: under `workflow.patched("wave-rationalization-batch-writes-v1")` →
    `write_artifacts_batch` (single-element `files=[(path, content or "{}")]`, 120s/`transient`);
    else `write_artifact` (`content or "{}"`, 60s/`transient`). Default
    `step_id="commit-redundancy-artifacts"`. (GOTCHA-WR-CA0/CA1/CA2/CA3)
15. `_commit_output_files`: empty result/output_files → return. Per file (dict OR object): skip empty
    path/content; normalize path (wave_prefix-as-is | bare→`wave_prefix[/app_id]/file` | nested
    as-is); skip if == `primary_path`; commit via `_commit_artifact` (message `{prefix}: {basename}`)
    in try/except (swallow per-file). (GOTCHA-WR-COF1..5)

**Gate-PR + body builders**
16. `_open_gate_pr`: `create_pr` to `target_branch="main"`, NO labels, step id
    `create-{gate.lower()}-pr`, 60s/`transient`. (GOTCHA-WR-OGP0/OGP1/OGP2)
17. `_build_grr_body` / `_build_gda_body`: append `**Rework iteration:**` footer ONLY when the
    matching `_rework_iterations_*` is truthy. G-DA per-app disposition fallback `"(pending)"`; body
    documents the dual-signal requirement. (GOTCHA-WR-GRR1/GDA1/GDA2/GDA3)
18. `_build_scoring_methodology`: `overall` → `f"{x:.1f}"` if numeric else `"—"`; dims → `len` if
    truthy else `"—"`. (GOTCHA-WR-SM1)
19. `_build_factory_routing`: route `Refactor/Rearchitect/Replace/Replatform → modernization`;
    `Retire/Consolidate → disposition_execution`; `Retain → retain`; else → `unknown`. `generated_at
    = _now_iso()`. `disposition_artifact = result.get("disposition_path") or ""`. (GOTCHA-WR-FR1..4)

**`_set_step`**
20. Sets `_current_step=step`, `_progress_pct=max(0.0, min(100.0, progress))` (CLAMPED),
    `_updated_at=_now_iso()`. Does NOT do a DB status push (unlike base) and does NOT touch `_status`.
    (GOTCHA-WR-SS0/SS1/SS2)

**`_wait_for_gate`**
21. `_pending_gate = GateType(gate_key) if gate_key in GateType._value2member_map_ else None`; set
    `WAITING_FOR_SIGNAL`; setdefault per-gate queue + cursor; snapshot `consumed`; wait
    `len(_gate_decisions[gate_key]) > consumed or self.cancelled`. (GOTCHA-WR-WFG1/WFG4)
22. On cancel → `CANCELLED`, return `"cancelled"` WITHOUT consuming. Else read
    `_gate_decisions[gate_key][consumed]`, handle 5-tuple/3-tuple, advance `consumed+1`, set
    `_pending_gate=None`+`RUNNING`. (GOTCHA-WR-WFG2/WFG3/WFG8)
23. APPROVE: pop `_rework_feedback[gate_key]`; if stripped reason non-empty → set
    `_approval_feedback[gate_key]={gate,approved_by,guidance,approved_at}` else pop it; return
    `"approved"`. REJECT: pop `_approval_feedback[gate_key]`; compute
    `rework_targets_from_card_decisions(card_decisions)`; set `_rework_feedback[gate_key]` with 7
    keys (incl `rework_targets`); return `"rejected"`. Does NOT bump `_rework_iterations_*`.
    (GOTCHA-WR-WFG5/WFG6/WFG7)

**`_merge_capability_lineage_row_rework`**
24. Empty `gate_id` → return. `fetch_gate_capability_lineage_rework` (30s/`transient`,
    `activity_id=fetch-capability-lineage-rework-{gate_id}-iter-{rework_gda}`) wrapped in `except
    Exception` → log + return (free-text feedback untouched). `not result.rejected_rows` → return.
    Else `merged = dict(existing)` + add `row_rework[]` + `row_rework_summary`; set
    `_rework_feedback["G-DA"] = merged` (MERGE not clobber). (GOTCHA-WR-CLR1/CLR2/CLR3/CLR4)

**`_run_gate_pre_review`**
25. Context `{gate_id, gate_type}`; if `gate_type_value == "G-DA"` add `tier1_approvals` (from
    `sorted(_tier1_approval_records)`) + fixed `downstream_artifact_kinds`. Dispatch `gate-pre-review`
    (`app_id=""`, `wave_id=self._wave_id`, 10m/`transient`) in try; empty output → `raise ValueError`
    (caught locally); else `store_gate_pre_review` (30s/`transient`). `except Exception` → log +
    continue. NO `finally`; NO `mark_gate_ready_for_review` (caller's job). (GOTCHA-WR-PRV0..6)

**`_reconcile_and_merge_with_retry_loop`**
26. `while True`: `reconcile_and_merge_pr` (`MergePRInput`, 60s, **`git_merge`**) → return on success.
    On `(ActivityError, ApplicationError)`: unwrap `__cause__` to an `ApplicationError`; `raise` if
    none or if `type` not in `{MergeConflict, MergeDivergenceUnresolved,
    MergeBranchProtectionRejected}`. Else build `detail` (incl `detected_at=_now_iso()`), reset
    `_merge_retry_signalled=False` BEFORE block, `set_gate_merge_blocked` (positional
    `args=[gate_id, detail]`, 30s/`transient`), wait `_merge_retry_signalled or self.cancelled`,
    return on cancel, else loop. (GOTCHA-WR-MRG0..8)

**Cross-cutting**
27. Every timestamp written by these methods uses `_now_iso()` (`workflow.now().isoformat()`), never
    `datetime.now()`. `run_ts` uses `int(workflow.now().timestamp())`.
28. Patch IDs reproduced VERBATIM: `"arch-data-sibling-lifecycle-v1"`,
    `"wave-rationalization-batch-writes-v1"`.
29. All best-effort helpers (`_validate_artifact_or_warn`, `_commit_output_files`,
    `_merge_capability_lineage_row_rework`, `_run_gate_pre_review`) swallow their failures and NEVER
    fail the wave.
30. The inherited `self.cancelled` (one-way latch from `HILSignalsMixin`) is threaded into the three
    blocking `wait_condition`s in this file (`_dispatch_received or cancelled`,
    `len(_gate_decisions[gate_key]) > consumed or cancelled`, `_merge_retry_signalled or cancelled`).
