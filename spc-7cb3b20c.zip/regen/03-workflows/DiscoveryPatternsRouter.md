# `discovery_patterns_router` — Discovery-Patterns Skill-Variant Router (ATOMIC regeneration spec)

> **Source of truth:** `temporal/olympus_workflows/workflows/discovery_patterns_router.py` (336 lines).
> Every `discovery_patterns_router.py:line` (abbreviated `dpr.py:line`) citation below is against that file.
>
> **What this is:** a **pure-Python module** (NOT a `@workflow.defn` class, NO Temporal imports,
> NO state, NO signals/queries, NO activities, NO gates, NO resilience constructs). It is a
> *routing helper* — a deterministic pure function plus its lookup tables and four private
> helpers. It chooses **which `discovery-patterns-*` skill variant** runs in the Discovery
> Pass 1 (structural-analysis) step, based on the tech fingerprint emitted by the
> `catalog-application` skill. It mirrors the pattern `code_generation_router` uses for the
> Modernization Ralph Loop (`dpr.py:5-6`).
>
> **Module-purity contract (`dpr.py:26-29`):** "Keep this module pure Python with no Temporal
> imports so it can be exercised by unit tests directly — we're below the workflow boundary."
> ⚠️ **GOTCHA-PURITY:** A rebuild MUST NOT add `from temporalio import workflow` (or any Temporal
> import) to this module. It is called from *inside* a `@workflow.defn` method
> (`DiscoveryWorkflow._select_discovery_patterns_variant`, `discovery.py:735`), and because it
> performs **only** dict/string/set operations with no wall-clock, no random, no I/O, and no
> `await`, it is **replay-deterministic** when invoked from workflow code. Adding a Temporal
> import would either break the import-passthrough sandbox contract or invite nondeterminism.
> The whole point of locating routing logic here (rather than in a `SKILL.md`) is that
> "picking which specialist runs — is orchestration" (`dpr.py:14-16`).
>
> **Inheritance / base relationship:** NONE. This module does **not** inherit from
> `LineWorkflowBase` or `HILSignalsMixin` and overrides nothing. It is consumed *by* a subclass
> of `LineWorkflowBase` (`DiscoveryWorkflow`), but it is not part of that class hierarchy. See
> `_LineWorkflowBase.md` / `_HILSignalsMixin.md` only for the surrounding workflow that calls
> this — not for any behavior reproduced here.

---

## 0. Who calls this module (consumer map)

| Caller | File:line | What it imports/calls | Effect |
|--------|-----------|-----------------------|--------|
| `DiscoveryWorkflow` (`@workflow.defn`, subclass of `LineWorkflowBase`) | `discovery.py:93-96` | imports `DISCOVERY_PATTERNS_DEFAULT_SKILL` and `select_discovery_patterns_skill` | the **only runtime caller** |
| `DiscoveryWorkflow._select_discovery_patterns_variant(catalog_artifacts)` | `discovery.py:662-737` | projects catalog JSON → fingerprint dict, then `select_discovery_patterns_skill(fingerprint, has_source_available=has_source)` (`discovery.py:735`) | returns the variant skill id (or `None`) |
| `DiscoveryWorkflow.run()` Step 2 (structural-analysis) | `discovery.py:273-307` | `variant_skill = self._select_discovery_patterns_variant(catalog_result.output_artifacts)` then **conditionally fans out a second dispatch** | see §6 |
| `test_discovery_patterns_router.py` | whole file | imports `select_discovery_patterns_skill`, `MAINFRAME_TOKENS`, `DATABASE_TOKEN_MATCHERS`, `LANGUAGE_TOKEN_MATCHERS` and asserts resolution order + edge cases | the behavioral contract is pinned by these tests |
| `data_router.py` / `architecture_patterns_router.py` | docstrings only (`data_router.py:6,39-42`; `architecture_patterns_router.py:6`) | **reference** this module's `MAINFRAME_TOKENS` and pattern; they re-declare their own copies — they do **not** import from here | sibling routers, out of scope |

> ⚠️ **GOTCHA-CALLER (the exported default name is load-bearing for the caller's skip logic):**
> `DiscoveryWorkflow.run()` does `if variant_skill and variant_skill != DISCOVERY_PATTERNS_DEFAULT_SKILL:`
> (`discovery.py:286`) before appending the specialist dispatch. So when this router returns the
> base string `"discovery-patterns"` (its fallback) OR `None`, **the workflow skips the second
> agent dispatch entirely** — the generic `legacy-architecture-mapper` structural pass already
> covers the tech-agnostic skeleton (`discovery.py:260-272`). A rebuild MUST export the constant
> `DISCOVERY_PATTERNS_DEFAULT_SKILL = "discovery-patterns"` with that exact value AND make the
> fallback return path return that same value, or the caller's `!=`-comparison skip will break and
> a redundant base dispatch will fire (extra agent cost, duplicate structural artifacts).

---

## 1. MODULE-LEVEL CONSTANTS / LOOKUP TABLES — exact values

These are module-level immutables. ⚠️ Several are exported and asserted-against by tests; their
**membership and ordering are load-bearing**.

### 1.1 `MAINFRAME_TOKENS: frozenset[str]` — `dpr.py:37-54`
Case-insensitive family markers. Used by **both** an exact set-intersection AND a substring scan
(§4 step 2). Members (13):
```text
{"natural", "adabas", "cobol", "jcl", "cics", "bms", "copybook",
 "tn3270", "unisys", "mainframe", "broker", "entirex", "infoimage", "ewf"}
```
> Test `test_mainframe_tokens_set_contains_expected_members` (`test_…:166-179`) requires at least
> `natural, adabas, cobol, jcl, cics, bms, copybook` to stay in the set. A rebuild MUST keep all 13;
> dropping any changes routing for that family.
> ⚠️ **GOTCHA-MT1 (short substring tokens are dangerous in the substring path):** `"bms"`, `"ewf"`,
> `"broker"`, `"cics"` are short. Because §4-step-2's second pass does `if fragment in cand`
> (substring containment) over raw catalog strings, a token like `"bms"` would match any longer
> word containing `"bms"`. In practice the catalog vocabulary makes this safe, but a rebuild MUST
> reproduce the substring scan (not "fix" it to word-boundary matching) to preserve identical
> routing on the real catalog blobs.

### 1.2 `DISCOVERY_PATTERNS_DATABASE_MAP: dict[str, str]` — `dpr.py:61-68`
**Exact-equality** db-token → variant. Retained "for backwards-compat with callers that pass a
normalized token directly" (`dpr.py:58-60`). ⚠️ **GOTCHA-DEADMAP1:** the live function
`select_discovery_patterns_skill` **does NOT consult this dict** — substring probing via
`DATABASE_TOKEN_MATCHERS` subsumes it (`dpr.py:276-280`: "the legacy exact-match dicts are no
longer consulted directly — but they remain exported so downstream callers / tests can still
introspect the canonical token set"). A rebuild MUST still **export** it (introspection / parity),
but it is **dead code on the hot path**. Contents:
```text
{"oracle": "discovery-patterns-oracle",
 "oracle-plsql": "discovery-patterns-oracle",
 "sqlserver": "discovery-patterns-sqlserver",
 "mssql": "discovery-patterns-sqlserver",
 "tsql": "discovery-patterns-sqlserver",
 "sql server": "discovery-patterns-sqlserver"}
```

### 1.3 `DISCOVERY_PATTERNS_SKILL_MAP: dict[str, str]` — `dpr.py:77-83`
**Exact-equality** primary-language-token → variant. Same dead-on-hot-path status as 1.2 (kept for
exact-token callers; substring probing via `LANGUAGE_TOKEN_MATCHERS` does the real work). Export it;
do not call it. Contents:
```text
{"csharp": "discovery-patterns-dotnet",
 "dotnet": "discovery-patterns-dotnet",
 "vbnet": "discovery-patterns-dotnet",
 "classic-asp": "discovery-patterns-dotnet",
 "vb6": "discovery-patterns-dotnet"}
```

### 1.4 `DATABASE_TOKEN_MATCHERS: tuple[tuple[str,str],...]` — `dpr.py:97-108`
**Ordered** list of `(lower_case_fragment, variant)`. Substring-aware; **first match wins** (§3.3).
Fragments **MUST be lower-case** (comparison is case-insensitive substring on the candidate).
Order (7 entries) — specifics with vendor/dialect markers first:
```text
(("oracle",    "discovery-patterns-oracle"),
 ("plsql",     "discovery-patterns-oracle"),
 ("sqlserver", "discovery-patterns-sqlserver"),
 ("sql server","discovery-patterns-sqlserver"),
 ("mssql",     "discovery-patterns-sqlserver"),
 ("t-sql",     "discovery-patterns-sqlserver"),
 ("tsql",      "discovery-patterns-sqlserver"))
```
> Test `test_token_matchers_contain_expected_anchors` (`test_…:387-396`) requires fragments
> `oracle, sqlserver, tsql, mssql` to stay present. Order matters when a candidate carries multiple
> tokens (e.g. `"oracle plsql"` → oracle because `oracle` is first) (`dpr.py:98-100`).

### 1.5 `LANGUAGE_TOKEN_MATCHERS: tuple[tuple[str,str],...]` — `dpr.py:110-124`
**Ordered** `(fragment, variant)`. All variants are `discovery-patterns-dotnet` today, so order is
**informational** for now (`dpr.py:111-113`) but MUST be preserved (a future variant split would
make it load-bearing). Order (10 entries), most-specific first:
```text
(("c#",          "discovery-patterns-dotnet"),
 ("csharp",      "discovery-patterns-dotnet"),
 ("vb.net",      "discovery-patterns-dotnet"),
 ("vbnet",       "discovery-patterns-dotnet"),
 ("classic asp", "discovery-patterns-dotnet"),
 ("classic-asp", "discovery-patterns-dotnet"),
 ("asp.net",     "discovery-patterns-dotnet"),
 (".net",        "discovery-patterns-dotnet"),
 ("dotnet",      "discovery-patterns-dotnet"),
 ("vb6",         "discovery-patterns-dotnet"))
```
> Test `test_token_matchers_contain_expected_anchors` (`test_…:398-401`) requires `c#, csharp, .net,
> asp.net` to stay present. ⚠️ **GOTCHA-LM1 (`"c#"` and `".net"` fragments are why the .NET path
> fires on real shapes):** the dead exact-dict (1.3) had `"csharp"` but no `"c#"`, so catalogs that
> emit the human token `"C#"` silently fell through pre-fix (`dpr.py:285-289`). The substring matcher
> explicitly includes `"c#"`. A rebuild MUST keep `"c#"` and `".net"` as fragments.

### 1.6 `DISCOVERY_PATTERNS_DEFAULT_SKILL: str = "discovery-patterns"` — `dpr.py:127`
The fallback when no specialist fires. **Exported** and imported by the caller for its skip-compare
(GOTCHA-CALLER). MUST equal `"discovery-patterns"`.

> ⚠️ **GOTCHA-VARIANTS (the six possible return values are exactly these strings):** the function
> returns one of: `"discovery-patterns-doc-only"`, `"discovery-patterns-mainframe"`,
> `"discovery-patterns-oracle"`, `"discovery-patterns-sqlserver"`, `"discovery-patterns-dotnet"`,
> `"discovery-patterns"` (base). It is annotated `-> str | None` but **the body never returns
> `None`** — every path returns a concrete string (see §4). The `None` in the annotation is purely
> documentary / for symmetry with the caller's projection helper (which can pass `None`). A rebuild's
> function always returns a string.

---

## 2. STATE

**NONE.** This module has zero mutable state — no instance vars, no module-level mutation, no
caches. Every function is pure: output depends only on arguments. ⚠️ **GOTCHA-STATELESS:** do NOT
add memoization/caching keyed on `id(dict)` or similar — it would not change results but could
introduce subtle non-determinism if a dict were mutated between calls. Keep it stateless.

## 2b. SIGNALS / QUERIES / UPDATES

**NONE.** No `@workflow.signal`, `@workflow.query`, or `@workflow.update` handlers. No
`wait_condition`. This module is below the workflow boundary and has no Temporal surface. (Signal/
gate/rework behavior of the *surrounding* `DiscoveryWorkflow` lives in that workflow's own spec and
in `_LineWorkflowBase.md` — not here.)

---

## 3. PRIVATE HELPER FUNCTIONS — atomic pseudocode (preserve every branch)

### 3.1 `_normalize(value: str | None) -> str` — `dpr.py:130-134`
Lower-cases and strips one token for comparison.
```text
def _normalize(value):
    if not value:            # dpr.py:132  BRANCH 1  (None OR empty string "")
        return ""            # dpr.py:133
    return value.strip().lower()   # dpr.py:134
```
- **Branch inventory (1):** `if not value` (`dpr.py:132`) — catches both `None` and `""` (and any
  falsy). ⚠️ **GOTCHA-N1:** the falsy check means `_normalize(None) == _normalize("") == ""`. A
  rebuild MUST use `if not value`, not `if value is None`, or empty strings would hit `.strip()`
  on an already-empty value (harmless) but more importantly the contract is "falsy → ''".
- Order of ops on the non-empty path: `.strip()` **then** `.lower()` (`dpr.py:134`). Both are
  whitespace/case idempotent so order is immaterial here, but reproduce `strip().lower()`.

### 3.2 `_fingerprint_tokens(tech_fingerprint: dict | None) -> set[str]` — `dpr.py:137-177`
Flattens a fingerprint into a **set** of normalized tokens. Pulls from `languages`, `frameworks`,
`platforms`, `runtimes`, `tech_stack` (whichever present) plus the scalar `tech_family`.
```text
def _fingerprint_tokens(tech_fingerprint):
    if not tech_fingerprint or not isinstance(tech_fingerprint, dict):   # dpr.py:153  BRANCH 1
        return set()                                                     # dpr.py:154
    tokens = set()                                                       # dpr.py:155
    for key in ("languages","frameworks","platforms","runtimes","tech_stack"):  # dpr.py:156  LOOP A
        value = tech_fingerprint.get(key)                               # dpr.py:163
        if isinstance(value, (list, tuple, set)):                      # dpr.py:164  BRANCH 2 (collection)
            for item in value:                                          # dpr.py:165  LOOP B
                norm = _normalize(str(item)) if item is not None else ""   # dpr.py:166  BRANCH 3
                if norm:                                                # dpr.py:167  BRANCH 4
                    tokens.add(norm)                                    # dpr.py:168
        elif isinstance(value, str):                                    # dpr.py:169  BRANCH 5 (scalar str)
            norm = _normalize(value)                                    # dpr.py:170
            if norm:                                                    # dpr.py:171  BRANCH 6
                tokens.add(norm)                                        # dpr.py:172
        # else: value is None / int / dict → silently ignored (no branch)
    family = _normalize(tech_fingerprint.get("tech_family"))            # dpr.py:174
    if family:                                                          # dpr.py:175  BRANCH 7
        tokens.add(family)                                              # dpr.py:176
    return tokens                                                       # dpr.py:177
```
- **Branch inventory (7 + 2 loops):** guard (153); collection-vs (164); per-item None-guard (166);
  per-item truthy (167); `elif isinstance str` (169); scalar truthy (171); family truthy (175).
- ⚠️ **GOTCHA-FT1 (key order is fixed but irrelevant to a SET):** iteration order over the 5 keys
  is fixed (`dpr.py:156-162`) but since the result is a `set`, ordering does not affect the value.
  However the **key list itself is load-bearing** — `runtimes` and `frameworks` were added (history:
  `runtimes` 2026-05-13, `dpr.py:145-151`) so .NET-Framework/ASP.NET-WebForms tokens in `runtimes`
  and NATURAL/ADABAS/CICS markers in `frameworks` get folded into the bag. A rebuild MUST scan all
  five keys.
- ⚠️ **GOTCHA-FT2 (dict-shaped list entries become their `str()`, NOT their `name`):** for a list
  entry that is a dict (e.g. `{"name":"C#","percent":86}`), this helper does `_normalize(str(item))`
  → `"{'name': 'c#', 'percent': 86}"`. That stringified-dict token is essentially never an exact
  match but DOES still contain the substring `"c#"`, so the §4 substring probes can still fire on it
  via the flat-token candidate list. The **clean** extraction of dict `name` values happens in the
  separate `_raw_text_candidates` helper (§3.4), not here. A rebuild MUST keep `str(item)` here
  (do not special-case dicts in this function) — the test `test_csharp_with_pound_sign_routes_to_dotnet`
  passes precisely because the raw-candidates path (§3.4) surfaces `"c#"` cleanly even though this
  bag holds the messy stringified dict.
- ⚠️ **GOTCHA-FT3 (`tech_family` is a scalar, normalized separately):** `tech_family` is read with
  `_normalize(...)` directly (`dpr.py:174`), so a value like `"mainframe"` becomes the token
  `"mainframe"` in the bag — which is itself a `MAINFRAME_TOKENS` member. This is why
  `test_mainframe_wins_on_cobol_with_sqlserver_db` (which sets `tech_family: "mainframe"`) routes to
  mainframe.

### 3.3 `_probe(candidates: list[str], matchers: tuple[tuple[str,str],...]) -> str | None` — `dpr.py:180-201`
Returns the **first matcher's** variant whose fragment is a case-insensitive substring of **any**
candidate. Matcher order dominates (outer loop = matchers).
```text
def _probe(candidates, matchers):
    norm_candidates = [c.lower() for c in candidates if c]   # dpr.py:195  (drop falsy, lower-case)
    for fragment, variant in matchers:                       # dpr.py:196  LOOP A (matchers — OUTER)
        frag = fragment.lower()                              # dpr.py:197  (defensive re-lower)
        for cand in norm_candidates:                         # dpr.py:198  LOOP B (candidates — INNER)
            if frag in cand:                                 # dpr.py:199  BRANCH 1 (substring hit)
                return variant                               # dpr.py:200  ← first hit wins
    return None                                              # dpr.py:201
```
- **Branch inventory (1 + 2 loops):** comprehension filter `if c` (195); `if frag in cand` (199);
  matchers loop (196); candidates loop (198).
- ⚠️ **GOTCHA-PROBE1 (matcher-major iteration = matcher order wins, NOT candidate order):** the
  OUTER loop is over `matchers` (`dpr.py:196`) and the INNER over candidates (`dpr.py:198`). So the
  **earliest matcher fragment** that appears in **any** candidate wins, regardless of which candidate
  it is or where it sits in the candidate list. This is why `("oracle", …)` before `("plsql", …)` in
  `DATABASE_TOKEN_MATCHERS` makes `"oracle plsql"` route to oracle. A rebuild MUST keep matchers as
  the outer loop. Swapping the loop nesting (candidate-major) would let an early candidate's later
  fragment beat a late candidate's earlier fragment — different routing.
- ⚠️ **GOTCHA-PROBE2 (defensive double-lower):** candidates are lower-cased at 195 and fragments at
  197 even though callers pass already-lower-cased data and the table fragments are declared
  lower-case. Keep both — the helper is documented as "defensive" (`dpr.py:189-191`).
- ⚠️ **GOTCHA-PROBE3 (falsy candidates dropped):** `if c` in the comprehension (195) drops empty
  strings (`""`) and `None`. So an empty `database`/`primary_language` hint contributes nothing.
  Keep it.

### 3.4 `_raw_text_candidates(tech_fingerprint: dict | None) -> list[str]` — `dpr.py:298-335`
Renders the catalog's list entries as **raw lower-case strings** (preserving vendor/version/schema
blobs and cleanly extracting dict `name`s) for the substring probe. Note: **defined AFTER**
`select_discovery_patterns_skill` in the file, but Python resolves it at call time so position is
immaterial.
```text
def _raw_text_candidates(tech_fingerprint):
    if not tech_fingerprint or not isinstance(tech_fingerprint, dict):   # dpr.py:311  BRANCH 1
        return []                                                        # dpr.py:312
    out = []                                                             # dpr.py:313
    for key in ("languages","frameworks","platforms","runtimes"):        # dpr.py:314  LOOP A (4 keys — NOTE: no tech_stack)
        value = tech_fingerprint.get(key)                                # dpr.py:315
        if not isinstance(value, (list, tuple)):                         # dpr.py:316  BRANCH 2 (skip non-list)
            continue                                                     # dpr.py:317
        for entry in value:                                              # dpr.py:318  LOOP B
            if isinstance(entry, str):                                   # dpr.py:319  BRANCH 3 (str entry)
                out.append(entry.lower())                                # dpr.py:320
            elif isinstance(entry, dict):                                # dpr.py:321  BRANCH 4 (dict entry)
                name = entry.get("name")                                 # dpr.py:325
                if isinstance(name, str):                                # dpr.py:326  BRANCH 5
                    out.append(name.lower())                             # dpr.py:327
            # else: int/None entry → ignored (no branch)
    dbs = tech_fingerprint.get("databases")                              # dpr.py:330  ← key is "databases" (plural!)
    if isinstance(dbs, (list, tuple)):                                   # dpr.py:331  BRANCH 6
        for entry in dbs:                                                # dpr.py:332  LOOP C
            if isinstance(entry, str):                                   # dpr.py:333  BRANCH 7
                out.append(entry.lower())                                # dpr.py:334
    return out                                                          # dpr.py:335
```
- **Branch inventory (7 + 3 loops):** guard (311); non-list skip (316); str entry (319); dict entry
  (321); dict-name str-check (326); `databases` is-list (331); db str entry (333).
- ⚠️ **GOTCHA-RTC1 (`databases` PLURAL vs `database` SINGULAR):** this helper scans the
  **`databases`** list (plural, `dpr.py:330`) and renders each vendor-blob string verbatim. The
  single scalar **`database`** key (singular) is handled separately by the main function
  (`dpr.py:259-261`). Both feed the candidate list. A rebuild MUST read `databases` here (plural)
  and `database` in the main fn (singular) — they are different fields from the catalog output. This
  is what makes `"Oracle (ODP.NET unmanaged 2.112.1.0 / Oracle 11g; schemas: DMX, DIWS)"` (a
  `databases[0]` blob) survive into the probe and match `"oracle"`.
- ⚠️ **GOTCHA-RTC2 (this helper extracts dict `name` cleanly — unlike `_fingerprint_tokens`):** for
  `{"name":"C#","percent":86}` this appends `"c#"` (clean), whereas `_fingerprint_tokens` (§3.2)
  would have produced the stringified-dict token. This clean `"c#"` is what reliably matches
  `LANGUAGE_TOKEN_MATCHERS`' `"c#"` fragment. A rebuild MUST extract `entry.get("name")` here.
- ⚠️ **GOTCHA-RTC3 (4 keys here, 5 in `_fingerprint_tokens` — `tech_stack` is intentionally absent):**
  this helper scans only `languages, frameworks, platforms, runtimes` (`dpr.py:314`) — NOT
  `tech_stack`. `tech_stack` entries reach the candidate list only via the flat `*tokens` splat
  (from `_fingerprint_tokens`). Reproduce the 4-key list here exactly.

---

## 4. `select_discovery_patterns_skill(...)` — the public router ★ CORE — `dpr.py:204-295`

Signature: `select_discovery_patterns_skill(tech_fingerprint: dict | None, has_source_available: bool = True) -> str | None`.
Resolution order (most → least specific): doc-only → mainframe → database(oracle/sqlserver) →
language(.NET) → base. Returns a concrete string on every path (§GOTCHA-VARIANTS).

```text
def select_discovery_patterns_skill(tech_fingerprint, has_source_available=True):

    # ── Step 1: doc-only short-circuit (wins over EVERYTHING) ──
    if not has_source_available:                       # dpr.py:236  BRANCH 1
        return "discovery-patterns-doc-only"           # dpr.py:237  ← earliest return; ignores fingerprint

    tokens = _fingerprint_tokens(tech_fingerprint)     # dpr.py:239  (set of normalized tokens)

    # ── Step 2: mainframe family (TWO sub-paths, both → mainframe) ──
    # 2a: exact set-intersection on the flat bag
    if tokens & MAINFRAME_TOKENS:                      # dpr.py:249  BRANCH 2 (set intersection truthy)
        return "discovery-patterns-mainframe"          # dpr.py:250
    # 2b: substring scan — token fragment found inside any raw candidate string
    raw_strings = list(tokens) + _raw_text_candidates(tech_fingerprint)   # dpr.py:251
    for fragment in MAINFRAME_TOKENS:                  # dpr.py:252  LOOP A (OUTER = mainframe tokens)
        for cand in raw_strings:                       # dpr.py:253  LOOP B (INNER = candidates)
            if fragment in cand:                       # dpr.py:254  BRANCH 3 (substring hit)
                return "discovery-patterns-mainframe"  # dpr.py:255  ← first hit wins

    # ── Pull the specific scalar hints (singular keys) ──
    database = _normalize((tech_fingerprint or {}).get("database"))          # dpr.py:259-261
    primary_language = _normalize((tech_fingerprint or {}).get("primary_language"))   # dpr.py:262-264

    # ── Build the shared candidate list for the DB + language probes ──
    extra_candidates = _raw_text_candidates(tech_fingerprint)                # dpr.py:271
    candidates = [database, primary_language, *tokens, *extra_candidates]    # dpr.py:272

    # ── Step 3+4: database probe (oracle / sqlserver) — substring-aware ──
    db_match = _probe(candidates, DATABASE_TOKEN_MATCHERS)                   # dpr.py:281
    if db_match:                                                            # dpr.py:282  BRANCH 4
        return db_match                                                     # dpr.py:283

    # ── Step 5: primary-language probe (.NET family) ──
    lang_match = _probe(candidates, LANGUAGE_TOKEN_MATCHERS)                 # dpr.py:290
    if lang_match:                                                          # dpr.py:291  BRANCH 5
        return lang_match                                                   # dpr.py:292

    # ── Step 6: fallback to the generic base ──
    return DISCOVERY_PATTERNS_DEFAULT_SKILL                                  # dpr.py:295  ("discovery-patterns")
```

**Branch inventory in the public function (5 + 2 loops):**
1. `if not has_source_available:` (`dpr.py:236`) → doc-only.
2. `if tokens & MAINFRAME_TOKENS:` (`dpr.py:249`) → mainframe (exact).
3. `if fragment in cand:` (`dpr.py:254`) inside the double mainframe loop → mainframe (substring).
4. `if db_match:` (`dpr.py:282`) → oracle/sqlserver.
5. `if lang_match:` (`dpr.py:291`) → dotnet.
Loops: `for fragment in MAINFRAME_TOKENS` (252), `for cand in raw_strings` (253).
Fall-through return at `dpr.py:295`.

> ⚠️ **GOTCHA-RES1 (strict precedence — the order of these checks IS the contract):** the six steps
> form a strict early-return cascade. Doc-only beats everything (even a mainframe+oracle fingerprint —
> `test_doc_only_overrides_every_fingerprint_signal`, `test_…:105-116`). Mainframe beats database
> (`test_mainframe_wins_on_cobol_with_sqlserver_db`: COBOL + `database:"sqlserver"` → mainframe,
> `test_…:45-60`). Database beats language (`test_sqlserver_selected_from_tsql_token`: `csharp` +
> `database:"tsql"` → **sqlserver**, NOT dotnet, `test_…:77-89`; and the DMS fixture
> `test_fixture_dms_routes_to_sqlserver` where C#/ASP.NET-Core + SQL-Server → sqlserver). A rebuild
> MUST evaluate the checks in exactly this order with early returns. Reordering any pair changes
> documented routing.
> ⚠️ **GOTCHA-RES2 (mainframe has TWO independent sub-checks — keep BOTH):** step 2a (exact set
> intersection, `dpr.py:249`) and step 2b (substring scan, `dpr.py:251-255`) are **separate** and a
> rebuild MUST keep both. 2a catches the clean case (emitter wrote `"natural"` standalone →
> `test_mainframe_wins_on_natural_token`). 2b catches the messy case (emitter wrote
> `"Software AG NATURAL/ADABAS"` as a composed framework string, or NATURAL only lives in
> `frameworks`/`databases` blobs → `test_mainframe_via_framework_block_only`, `test_…:279-294`, and
> the RMS fixture). Removing 2b would regress the framework-only mainframe case.
> ⚠️ **GOTCHA-RES3 (the mainframe substring loop is matcher/token-major, like `_probe`):** the OUTER
> loop is `for fragment in MAINFRAME_TOKENS` (252), INNER is candidates (253). So the **first
> mainframe token** (in `frozenset` iteration order) found in any candidate wins. Since all paths
> return the same `"discovery-patterns-mainframe"`, the *which-token-won* is irrelevant to the
> result — but a rebuild should still iterate tokens-outer to match structure. (Note: `frozenset`
> iteration order is unspecified across Python builds, but because every match yields the identical
> return value, the function's output is deterministic regardless of set ordering. A rebuild needs no
> ordered set here.)
> ⚠️ **GOTCHA-RES4 (`raw_strings` and `candidates` are built TWICE via two `_raw_text_candidates`
> calls):** `_raw_text_candidates(tech_fingerprint)` is called once at `dpr.py:251` (for the mainframe
> substring scan, combined with `list(tokens)`) and AGAIN at `dpr.py:271` (for the DB/language probe,
> combined with `database, primary_language, *tokens`). They are two separate computations of the
> same underlying list. A rebuild may compute it once and reuse, OR call twice — the result is
> identical because the helper is pure. But note the **candidate compositions differ**: the mainframe
> scan uses `list(tokens) + raw` (no scalar `database`/`primary_language`), whereas the DB/language
> probe uses `[database, primary_language, *tokens, *raw]` (scalars prepended). Reproduce both
> compositions exactly.
> ⚠️ **GOTCHA-RES5 (`(tech_fingerprint or {}).get(...)` guards None safely):** the scalar reads at
> `dpr.py:259-264` use `(tech_fingerprint or {})` so a `None` fingerprint yields `{}` → `.get(...)`
> → `None` → `_normalize(None)` → `""`. This is why `select_discovery_patterns_skill(None)` returns
> the base (`test_empty_fingerprint_falls_back_to_base`, `test_…:119-122`): with `None`,
> `_fingerprint_tokens` returns `set()` (no mainframe), scalars normalize to `""`, `_raw_text_candidates`
> returns `[]`, both probes find nothing, fall through to base. A rebuild MUST guard the scalar reads
> with `(tech_fingerprint or {})`.
> ⚠️ **GOTCHA-RES6 (substring subsumes exact — the dead dicts are NOT consulted):** `dpr.py:274-280`
> documents that "a `in` test on identical strings is True, so the legacy exact-match dicts are no
> longer consulted directly." The DB and language routing flows **only** through the two
> `*_TOKEN_MATCHERS` substring tables via `_probe`. A rebuild MUST route through the substring
> matchers; it must NOT add a `DISCOVERY_PATTERNS_DATABASE_MAP[token]` / `DISCOVERY_PATTERNS_SKILL_MAP[token]`
> dict lookup on the hot path (it would be redundant and could double-route).
> ⚠️ **GOTCHA-RES7 (case-insensitivity end-to-end):** every comparison path lower-cases — `_normalize`
> (tokens, scalars), `_raw_text_candidates` (`.lower()`), `_probe` (double-lower). So
> `{"languages":["CSharp","VBNet"], "primary_language":"CSHARP"}` routes to dotnet
> (`test_case_insensitive_tokens`, `test_…:138-147`). A rebuild MUST lower-case on every comparison
> path; do not compare raw-cased.

---

## 5. ACTIVITY & CHILD-WORKFLOW CALLS

**NONE.** This module issues **zero** `workflow.execute_activity` / `execute_child_workflow` calls.
It is a synchronous pure function. (The activity dispatch that *consumes* its return value —
`_dispatch_discovery_patterns_variant` → `_dispatch_pass` → agent task — lives in `DiscoveryWorkflow`
and is specced there, not here.) Retry policies, timeouts, `non_retryable_error_types`, gather/child
ordering: **N/A — none in this module.**

---

## 6. HOW THE RETURN VALUE ROUTES IN THE CALLING WORKFLOW (context, not re-specced)

This module produces a string; `DiscoveryWorkflow` decides what to do with it. Captured here so a
rebuild understands the end-to-end effect (full Discovery flow → its own spec). All citations
`discovery.py`.

```text
# DiscoveryWorkflow.run(), Step 2 — structural-analysis (discovery.py:260-307):
await self._set_step("structural-analysis", STEP_WEIGHTS["catalog"])           # 273
variant_skill = self._select_discovery_patterns_variant(catalog_result.output_artifacts)   # 274-276
dispatches = [ self._dispatch_pass(..., pass_name="structural-analysis", ...) ]            # 277-285  (ALWAYS the generic pass)
if variant_skill and variant_skill != DISCOVERY_PATTERNS_DEFAULT_SKILL:        # 286  ★ skip-compare
    dispatches.append(self._dispatch_discovery_patterns_variant(skill_id=variant_skill, ...))   # 287-295
fan_out = await asyncio.gather(*dispatches)                                     # 296  (parallel)
structural_result = fan_out[0]                                                  # 297
self._pass_results["structural-analysis"] = list(structural_result.output_artifacts)   # 298
if len(fan_out) > 1:                                                            # 299
    self._pass_results["structural-analysis"].extend(fan_out[1].output_artifacts)   # 305-307  (merge specialist outputs)
```

And the **projection helper** `_select_discovery_patterns_variant` (`discovery.py:662-737`) — this is
what shapes the dict before calling our function. Its branches matter for what fingerprint our router
sees:
```text
def _select_discovery_patterns_variant(self, catalog_artifacts):
    if not catalog_artifacts: return None                          # 674-675
    raw = catalog_artifacts[0]
    if not isinstance(raw, str) or not raw.strip(): return None    # 677-678
    try: parsed = json.loads(raw)
    except (JSONDecodeError, TypeError, ValueError): return None   # 681-682  ← malformed catalog → None (Discovery NOT stalled)
    if not isinstance(parsed, dict): return None                   # 683-684
    fingerprint = parsed.get("tech_fingerprint")                   # 691
    if not isinstance(fingerprint, dict):                          # 692  ← fall back to tech_stack projection
        ts = parsed.get("tech_stack") or {}
        if isinstance(ts, dict):
            # project languages (list-of-dict→names), databases (verbatim), runtimes→platforms+runtimes
            fingerprint = {languages, frameworks, platforms=runtimes, runtimes, databases, database=dbs[0], primary_language=lang0}   # 721-729
        else:
            fingerprint = None                                     # 730-731
    has_source = parsed.get("has_source_available")
    if not isinstance(has_source, bool): has_source = True         # 733-734  ← non-bool defaults True
    return select_discovery_patterns_skill(fingerprint, has_source_available=has_source)   # 735-737
```
> ⚠️ **GOTCHA-PROJ1 (the projection maps `runtimes` to BOTH `platforms` and `runtimes`):**
> `discovery.py:724-725` sets `"platforms": runtimes, "runtimes": runtimes` so our router sees the
> .NET runtime tokens under either key (both are in `_fingerprint_tokens`' key list). And it forwards
> `databases` verbatim (`discovery.py:726`) so the vendor blob survives for `_raw_text_candidates`.
> The router's behavior is correct only *given* this projection; a rebuild of the workflow caller MUST
> reproduce this projection, but the **router itself** is agnostic to it (it just reads whatever keys
> are present).
> ⚠️ **GOTCHA-PROJ2 (malformed/empty catalog → `None` → generic pass still runs):** every defensive
> early-`None` in the projection (`discovery.py:675,678,682,684`) means the specialist is skipped but
> the generic structural pass at `discovery.py:277-285` always runs — "a malformed catalog can't stall
> Discovery" (`discovery.py:670-672`). Our router never sees `None` *via this path* unless projection
> bailed; but our router itself also tolerates `None` (GOTCHA-RES5).

---

## 7. RESILIENCE

- **Timeouts / heartbeats / continue-as-new / idempotency keys:** **N/A** — no Temporal constructs
  in this module.
- **Determinism:** the function is **purely deterministic** given its arguments — no `workflow.now()`,
  no `random`, no I/O, no module state (§2). Safe to call from inside `@workflow.defn` code without a
  patch gate. ⚠️ **GOTCHA-DET1:** the only theoretical non-determinism source would be `frozenset`/
  `set` iteration order (in `_fingerprint_tokens`' set, the `tokens & MAINFRAME_TOKENS` truthiness,
  and the `for fragment in MAINFRAME_TOKENS` loop). Because (a) set *membership/intersection
  truthiness* is order-independent, and (b) every mainframe match returns the **same** string, and
  (c) `_probe` iterates the **ordered tuples** `*_TOKEN_MATCHERS` (not the sets) for the
  variant-distinguishing decisions — the **return value is order-independent**. A rebuild does NOT
  need an ordered/sorted set and MUST NOT rely on set iteration order to pick a *different* variant
  (none of the order-sensitive decisions cross variant boundaries).
- **Failure semantics:** the function does not raise on bad input — `None`/`{}`/non-dict/empty all
  funnel to defensive empties and fall through to the base. The **only** way it could raise is a
  `TypeError` if a caller passed a non-dict non-None `tech_fingerprint` whose `.get` doesn't exist —
  but the guards (`isinstance(..., dict)` in `_fingerprint_tokens`/`_raw_text_candidates`, and
  `(tech_fingerprint or {})` for scalars) prevent that on every internal path. The **caller**
  (`_select_discovery_patterns_variant`) additionally wraps JSON parse in try/except and returns
  `None` on failure (`discovery.py:681-682`), so a malformed catalog never reaches an exception here.
- **Compensation / rollback:** **N/A** — stateless pure function, nothing to compensate.

---

## 8. Behavioral parity checklist

A rebuilt `discovery_patterns_router` module MUST satisfy ALL of the following (each is a concrete,
testable assertion):

1. **Module purity:** no Temporal imports; no module-level mutable state; no `await`; no `workflow.now()`/
   `random`/I/O. Importable and callable from plain pytest with no Temporal harness. (GOTCHA-PURITY,
   GOTCHA-STATELESS)
2. **Exports:** the module exports `MAINFRAME_TOKENS` (frozenset of the exact 13 members §1.1),
   `DISCOVERY_PATTERNS_DATABASE_MAP` (§1.2), `DISCOVERY_PATTERNS_SKILL_MAP` (§1.3),
   `DATABASE_TOKEN_MATCHERS` (ordered 7-tuple §1.4), `LANGUAGE_TOKEN_MATCHERS` (ordered 10-tuple §1.5),
   `DISCOVERY_PATTERNS_DEFAULT_SKILL == "discovery-patterns"` (§1.6), and `select_discovery_patterns_skill`.
3. **Six possible return strings, never `None`:** every code path of `select_discovery_patterns_skill`
   returns one of `discovery-patterns-doc-only` / `-mainframe` / `-oracle` / `-sqlserver` / `-dotnet` /
   `discovery-patterns`. (GOTCHA-VARIANTS)
4. **Resolution precedence (strict early-return cascade):** doc-only > mainframe > database
   (oracle/sqlserver) > language(.NET) > base — in exactly that order. Specifically:
   - `has_source_available=False` returns `"discovery-patterns-doc-only"` regardless of fingerprint
     (even mainframe+oracle+csharp). (`dpr.py:236-237`; test 105-116)
   - A `MAINFRAME_TOKENS` member anywhere in the fingerprint beats any database/language signal
     (COBOL + `database:"sqlserver"` → mainframe). (test 45-60)
   - A database match beats a language match (`csharp` + `database:"tsql"` → **sqlserver**). (test 77-89)
   (GOTCHA-RES1)
5. **Mainframe has two sub-checks, both reproduced:** (a) `tokens & MAINFRAME_TOKENS` set-intersection
   (`dpr.py:249`); (b) substring scan `for fragment in MAINFRAME_TOKENS: for cand in (list(tokens) +
   _raw_text_candidates(fp)): if fragment in cand` (`dpr.py:251-255`). NATURAL standalone hits (a);
   `"Software AG NATURAL/ADABAS"` in `frameworks` / `"ADABAS (…on-prem mainframe)"` in `databases`
   hits (b). (GOTCHA-RES2; tests 36-42, 279-294, fixture rms)
6. **DB/language routing flows ONLY through the ordered substring matchers via `_probe`**, never
   through the exact dicts (which are dead-on-hot-path but still exported). (GOTCHA-RES6, DEADMAP1)
7. **`_probe` is matcher-major:** outer loop over `matchers`, inner over candidates; first matcher
   fragment found in any candidate wins → returns that matcher's variant. Both candidates and fragments
   are lower-cased defensively; falsy candidates are dropped. (`dpr.py:195-201`; GOTCHA-PROBE1/2/3)
8. **Candidate-list composition (two distinct shapes):** mainframe substring scan uses
   `list(tokens) + _raw_text_candidates(fp)` (no scalars); DB/language probe uses
   `[database, primary_language, *tokens, *_raw_text_candidates(fp)]` (scalars prepended).
   (`dpr.py:251`, `dpr.py:272`; GOTCHA-RES4)
9. **`_fingerprint_tokens` scans 5 keys** (`languages, frameworks, platforms, runtimes, tech_stack`)
   for list/tuple/set (per-item `_normalize(str(item))`, skip falsy) OR scalar str, PLUS scalar
   `tech_family`; returns a `set`; `None`/non-dict → `set()`. Dict-shaped list entries become their
   `str(item)` here (messy) — clean `name` extraction is `_raw_text_candidates`' job. (`dpr.py:137-177`;
   GOTCHA-FT1/FT2/FT3)
10. **`_raw_text_candidates` scans 4 keys** (`languages, frameworks, platforms, runtimes` — NO
    `tech_stack`) for list/tuple, appending `entry.lower()` for str entries and `entry["name"].lower()`
    for dict entries; THEN scans the **plural `databases`** list appending each str `.lower()` verbatim;
    `None`/non-dict → `[]`. (`dpr.py:298-335`; GOTCHA-RTC1/RTC2/RTC3)
11. **Scalar singular keys:** the main function reads scalar `database` and `primary_language` via
    `_normalize((tech_fingerprint or {}).get(key))` — singular, None-safe. (`dpr.py:259-264`; GOTCHA-RES5)
12. **`_normalize` returns `""` for any falsy input** (None or empty), else `value.strip().lower()`.
    (`dpr.py:130-134`; GOTCHA-N1)
13. **Case-insensitive end-to-end:** upper-case tokens still route (`{"languages":["CSharp","VBNet"],
    "primary_language":"CSHARP"}` → dotnet). (test 138-147; GOTCHA-RES7)
14. **Real-world substring shapes route correctly (the noop-fix regressions):**
    - `databases:["Oracle (ODP.NET unmanaged 2.112.1.0 / Oracle 11g; schemas: DMX, DIWS)"]` with C#
      languages → **oracle** (DB beats .NET). (test 193-215, fixture cpdss)
    - `languages:[{"name":"C#","percent":100}]` + `databases:["PostgreSQL 14"]` → **dotnet**. (test 218-232)
    - `runtimes:[".NET Framework 4.8"]` with JavaScript languages → **dotnet**. (test 235-253)
    - `databases:["SQL Server 2019 (T-SQL …)"]` with C#/ASP.NET → **sqlserver** (DB beats .NET).
      (test 256-276, fixture dms)
15. **Empty/None/modern-stack fall through to base:** `select_discovery_patterns_skill({})` and
    `select_discovery_patterns_skill(None)` both return `"discovery-patterns"`; Python+Postgres+FastAPI
    returns `"discovery-patterns"`. (tests 119-135)
16. **Caller skip contract:** `DISCOVERY_PATTERNS_DEFAULT_SKILL` equals the fallback return value, so
    `DiscoveryWorkflow`'s `variant_skill != DISCOVERY_PATTERNS_DEFAULT_SKILL` (`discovery.py:286`)
    correctly skips the second dispatch when the router returns base or `None`. (GOTCHA-CALLER)
17. **Determinism / order-independence:** the return value does not depend on `set`/`frozenset`
    iteration order (all order-sensitive loops either test order-independent membership or return an
    identical string; variant-distinguishing decisions use the ordered tuple matchers). No patch gate
    is needed to call this from workflow code. (GOTCHA-DET1, GOTCHA-RES3)
18. **No activities, no child workflows, no signals, no queries, no gates, no rework loop, no
    compensation** are defined in this module. (§2b, §5, §7)
