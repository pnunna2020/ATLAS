# `ValidationWorkflow` — Per-App Validation Assembly Line (ATOMIC regeneration spec)

> **Source of truth:** `temporal/olympus_workflows/workflows/validation.py` (1292 lines, HEAD
> `7cb3b20c`). Every `validation.py:line` citation below is against that file.
>
> **Base class:** `class ValidationWorkflow(LineWorkflowBase)` (`validation.py:194-195`). See
> **`_LineWorkflowBase.md`** for ALL inherited helpers/signals/queries (`_dispatch_agent`,
> `_commit_step_artifacts`, `_create_gate_pr`, `_submit_gate_evidence`, `_run_gate_pre_review`,
> `_wait_for_gate_decision`, `_reconcile_and_merge_with_retry_loop`, `_set_step`, `_execution_ctx`,
> `_update_app_status`, `_build_evidence_data`, `_bump_rework`/`_rework_count`, `get_status`, the
> four base gate signals `gate_approved`/`gate_rejected`/`escalation_resolved`/`merge_retry`).
> See **`_HILSignalsMixin.md`** for the transitively-inherited HIL surface (`approve`,
> `cancel_workflow`, `self.cancelled`, etc.). This spec reproduces ONLY what Validation defines or
> overrides, and references the base for the rest.
>
> **What this workflow is:** the per-app Validation line. Runs ONCE per target application after
> Modernization's G-04c approves and the generated code is committed to `target_repo`
> (`validation.py:1-7`). Executes an 18-step canonical shape (`validation.py:8-30`): intake → 3
> parallel quality streams → G-V1 (automated parity) → G-V2 (compliance+security+accessibility) →
> [Tier-1 only: safety-assurance → G-V3] → persist side-effects → merge final PR + emit
> `ValidationApprovedSignal` to Deployment. **Tier-2/Tier-3 skip steps 12-16** (safety + G-V3
> entirely) — the branch is at `if is_tier_1:` (`validation.py:601`).
>
> **Operating principle (`validation.py:32-39`):** streams run in PARALLEL (`asyncio.gather`);
> gates run SERIALLY. G-V1 is automated pass/fail — PM merge is *acknowledgement*, not evaluation;
> auto-rejection when parity < threshold routes contested findings back to Modernization via the
> rework loop. Tier-1 G-V2 and G-V3 are **triple-signal** gates (PM merge AND two stakeholder
> scope signals each).
>
> ⚠️ **CHANGED-SINCE-OLD-BASELINE (P6-S8.2 / P6-S8.4 cATO evidence pipeline is NEW):** the prior
> spec described an 1078-line baseline with **42** branches and NO cATO evidence dispatch. HEAD adds
> the entire `_dispatch_cato_evidence` method (§5.7, ~8 branches), four new `_cato_*` state vars
> (§2), three per-gate cATO dispatch calls woven into the bundle steps (steps 5/8/13), and six new
> cATO fields on the `persist_validation_side_effects` call (§5.1 step 17). New module imports:
> `dispatch_agent_task`, `AgentTaskInput`, `WriteArtifactsBatchInput` (`validation.py:72-98`). Total
> branch count is now **~53** (was 42). Every line citation below has been re-anchored to HEAD.

---

## 0. Module-level constants and tables (`validation.py:112-191`)

These are read by the workflow body and MUST be reproduced verbatim.

### 0.1 `VALIDATION_STEPS: dict[str, dict]` (`validation.py:112-142`)
Only the **agent (stream)** steps are in this table — code/git/gate steps carry no entry. Each
value has `title`, `skills` (a **list**, not `skill_id`), `artifact`, `kind="agent"`:

| step_id | title | skills (list) | artifact |
|---------|-------|---------------|----------|
| `functional-parity` | "Functional Parity Verification" | `["parity-verifier", "acceptable-divergences"]` | `parity-report.json` |
| `security-compliance` | "Security & Compliance Assessment" | `["security-scan-review", "cato-evidence-validator"]` | `security-assessment-report.json` |
| `accessibility-ux` | "Accessibility & UX Audit" | `["accessibility-checker", "design-system"]` | `accessibility-audit.json` |
| `safety-assurance` | "Safety Assurance" | `["safety-critical-verifier", "traceability-checker"]` | `safety-case.json` |

> ⚠️ **GOTCHA-VS1 (steps carry `skills` LIST, not `skill_id`):** every step def has a `skills`
> list and NO `skill_id` key (`validation.py:117-141`). This is *why* Validation MUST override
> `_primary_skill_for_step` and `_evidence_step_metadata` (base defaults read `["skill_id"]` and
> would `KeyError` — GOTCHA-H2 in `_LineWorkflowBase.md`). The base `_commit_step_artifacts`
> handles this correctly via its `if "skills" in step_def` branch (GOTCHA-CSA2).

### 0.2 `PARALLEL_STREAMS: list[str]` (`validation.py:145-149`)
`["functional-parity", "security-compliance", "accessibility-ux"]` — the three always-on streams
that fan out after intake. **Order is load-bearing** (drives stream-status dict init,
`asyncio.gather` order, evidence assembly). ⚠️ **GOTCHA-VS2:** `safety-assurance` is NOT in this
list — it is the Tier-1-only 4th stream (`TIER1_STEP`).

### 0.3 `TIER1_STEP = "safety-assurance"` (`validation.py:152`)
The Tier-1-only stream that runs after G-V1 + G-V2 approve.

### 0.4 `STEP_WEIGHTS: dict[str, float]` (`validation.py:158-177`)
Sum to 100.0 (asserted at import, `validation.py:178-180`). Full Tier-1 path order:

```
intake 2.0 | functional-parity 18.0 | security-compliance 18.0 | accessibility-ux 18.0 |
bundle-g-v1-evidence 2.0 | create-g-v1-pr 2.0 | gate-review-v1 4.0 | bundle-g-v2-evidence 2.0 |
create-g-v2-pr 2.0 | ai-pre-review-v2 2.0 | gate-review-v2 6.0 | safety-assurance 12.0 |
bundle-g-v3-evidence 1.0 | create-g-v3-pr 1.0 | ai-pre-review-v3 2.0 | gate-review-v3 4.0 |
persist-validation-side-effects 2.0 | merge-final-gate-pr 2.0
```
> ⚠️ **GOTCHA-VS3 (insertion order is the cumulative-progress order):** `_progress_at(step)`
> (§5.9) sums weights in **dict insertion order** through the named step inclusive. A rebuild MUST
> preserve this exact key ordering or the progress bar values diverge. Tier-2/Tier-3 runs skip
> weights for `safety-assurance`/`bundle-g-v3-evidence`/`create-g-v3-pr`/`ai-pre-review-v3`/
> `gate-review-v3` (they never call `_progress_at` for those) but progress still advances
> monotonically because the workflow jumps ahead to `persist-validation-side-effects`.

### 0.5 `MAX_REWORK_ITERATIONS = 3` (`validation.py:182`)
The per-gate rework ceiling. The check is **strictly greater than** (`> MAX_REWORK_ITERATIONS`),
so the gate may be reworked up to 3 times before the 4th rejection fails the run (see GOTCHA-RW
below).

### 0.6 `PARITY_THRESHOLDS: dict[int | None, float]` (`validation.py:186-191`)
```
{1: 99.0, 2: 98.0, 3: 95.0, None: 98.0}
```
Tier-1 ≥ 99%, Tier-2 ≥ 98%, Tier-3 ≥ 95%, unclassified (None) ≥ 98%. Looked up by
`_parity_meets_threshold` and the G-V1 PR-body builder.

### 0.7 `_CATO_STAGE_FIXTURE: dict[str, str]` (class-level, `validation.py:925-929`) — **NEW (P6-S8.2)**
```
{"G-V1": "ssp-g-v1", "G-V2": "sar-g-v2", "G-V3": "poam-g-v3"}
```
Stage → fixture-scenario map. The `cato-compliance` skill emits a different OSCAL artifact set per
stage (SSP at G-V1, SAR + `evidence/` at G-V2, POA&M + reauth log at G-V3). The fixture scenario
keeps the **mock-runtime** resolution deterministic; **live runtimes ignore it** and stage-detect
from `context["stage"]` (`validation.py:920-924`). Looked up by `_dispatch_cato_evidence` via
`.get(stage, "")` (`validation.py:962`).

---

## 1. CLASSVARS — base configuration surface (`validation.py:210-216`)

| Classvar | Value | Effect |
|----------|-------|--------|
| `ASSEMBLY_LINE` | `AssemblyLine.VALIDATION` | `get_status` `current_line`; status-query enum |
| `ARTIFACT_ROOT` | `"validation"` | path prefix `validation/...`; `_task_type_prefix`; PR labels |
| `LINE_LABEL` | `"Validation"` | `_set_step`, `_execution_ctx` `line_id="validation"` |
| `STATUS_PREFIX` | `"validation"` | `_set_step` → `"validation_in_progress"` |
| `STEPS` | `VALIDATION_STEPS` | per-step skills/artifact lookup |
| `STEP_WEIGHTS` | module `STEP_WEIGHTS` | progress weights (read only by this subclass's `run()`) |

> Note: `SINGLE_GATE_KEY` is NOT set → defaults to `None`. Validation is multi-gate and
> **overrides** `_rework_gate_key_for_step` (§3.3) instead.

---

## 2. STATE — instance vars beyond the base (`validation.py:218-245`)

`__init__` calls `super().__init__()` first (`validation.py:219`) → all base + HIL vars
initialized (see `_LineWorkflowBase.md` §2 and `_HILSignalsMixin.md` §1). Then Validation adds:

| Var | Type | Initial | Line | Mutated by → value | When |
|-----|------|---------|------|--------------------|------|
| `_stakeholder_compliance_approved` | `bool` | `False` | 222 | `stakeholder_approved(scope="g-v2-compliance")` → `True` (`validation.py:300`) | Tier-1 G-V2 signal |
| `_stakeholder_security_approved` | `bool` | `False` | 223 | `stakeholder_approved(scope="g-v2-security")` → `True` (`validation.py:302`) | Tier-1 G-V2 signal |
| `_stakeholder_safety_approved` | `bool` | `False` | 224 | `stakeholder_approved(scope="g-v3-safety")` → `True` (`validation.py:304`); RESET to `False` on G-V3 reject (`validation.py:711`) | Tier-1 G-V3 signal / G-V3 rework |
| `_stakeholder_cert_approved` | `bool` | `False` | 225 | `stakeholder_approved(scope="g-v3-cert")` → `True` (`validation.py:306`); RESET to `False` on G-V3 reject (`validation.py:712`) | Tier-1 G-V3 signal / G-V3 rework |
| `_stream_status` | `dict[str,str]` | `{s:"queued" for s in PARALLEL_STREAMS}` | 228-230 | `_run_parallel_streams`: per-stream → `"running"` (`validation.py:846`), `"completed"` (`validation.py:867`), or `"failed"` (`validation.py:870`) | each parallel-stream run |
| `_stream_started_at` | `dict[str,str]` | `{}` | 231 | `_run_parallel_streams` → `_now_iso()` per stream before gather (`validation.py:847`) | stream start |
| `_stream_completed_at` | `dict[str,str]` | `{}` | 232 | `_run_stream` → `_now_iso()` on completion (`validation.py:868`) or failure (`validation.py:871`) | stream end |
| `_safety_case_ref` | `str` | `""` | 235 | set at step 12 to `f"validation/{app_id}/safety-case.json"` (`validation.py:623-626`) | Tier-1 only, after safety stream |
| **`_cato_paths`** ⓝ | `dict[str,list[str]]` | `{}` | 239 | `_dispatch_cato_evidence` → `_cato_paths[stage] = committed` (`validation.py:1041`); keyed `"G-V1"`/`"G-V2"`/`"G-V3"` | each per-gate cATO commit success |
| **`_cato_target_uuid`** ⓝ | `str` | `""` | 240 | `_dispatch_cato_evidence` → `app_id` (`validation.py:957-958`) | every cATO dispatch (set before commit) |
| **`_cato_evidence_records`** ⓝ | `list[str]` | `""`→`[]` (244, `[]` literal) | 244 | `_dispatch_cato_evidence` → list of `evidence/`-dir file contents (`validation.py:1046-1052`) | cATO commit success with `evidence/` files |
| **`_cato_highest_stage`** ⓝ | `str` | `""` | 245 | `_dispatch_cato_evidence` → `stage` on commit success (`validation.py:1042`) | each cATO commit success (last wins → highest reached) |

ⓝ = **NEW since old baseline** (P6-S8.2 / P6-S8.4 cATO evidence side-effects).

The base vars Validation reads/writes via `run()`: `_status`, `_started_at`, `_updated_at`,
`_app_id`, `_risk_tier`, `_current_step`, `_progress_pct`, `_step_results`,
`_step_committed_paths`, `_rework_iterations` (via `_bump_rework`/`_rework_count`),
`_gate_decisions`/`_gate_decisions_consumed`/`_rework_feedback` (via `_wait_for_gate_decision`),
`_merge_retry_signalled` (via `_reconcile_and_merge_with_retry_loop`).

> ⚠️ **GOTCHA-VS4 (`_risk_tier` is set from INPUT, not classified here):** unlike older code that
> did manual `RiskTier` conversion, `run()` reads `input.risk_tier` and stores
> `int(input.risk_tier) if not None else None` (`validation.py:330-332`). `is_tier_1` is the
> derived boolean `self._risk_tier == 1` (`validation.py:333`). Both the `int(...)` cast AND the
> `None` passthrough are load-bearing — `_parity_meets_threshold` / `PARITY_THRESHOLDS` key on the
> int|None and a `None` tier maps to the 98% default.

> ⚠️ **GOTCHA-VS5 (stream-status dicts are observability-only):** `_stream_status` /
> `_stream_started_at` / `_stream_completed_at` are mutated to drive the `per_stream_agent` fanout
> payload narrative but are NOT read by any control-flow branch and NOT surfaced by `get_status`.
> They ARE part of behavioral parity for the fanout-record story but a rebuild that drops them
> changes no routing decision. Reproduce them for fidelity.

> ⚠️ **GOTCHA-VS6 (NEW — `_cato_*` vars ARE read by control-flow):** unlike the stream-status dicts,
> three of the new `_cato_*` vars DO feed control flow / output:
> - `_cato_paths` is read at every bundle step to UNION cATO paths into the gate evidence
>   (`validation.py:399-406 / 498-507 / 637-645`) AND at step 17 to gate the `cato_ssp_path` /
>   `cato_sar_path` / `cato_poam_path` ternaries (`validation.py:761/766/771`).
> - `_cato_target_uuid` defaults the persist `cato_uuid` (`validation.py:744`, `... or app_id`).
> - `_cato_evidence_records` gates the persist `control_evidence_json` ternary (`validation.py:776`).
> - `_cato_highest_stage` is passed as persist `cato_stage` (`validation.py:758`).
> A rebuild MUST thread all four into step 17 and the bundle unions.

---

## 3. OVERRIDDEN base methods (only these four + `run`/`_execute`)

ValidationWorkflow OVERRIDES exactly these base hooks (all others inherited unchanged):

| Method | Base default | Validation override | Why |
|--------|--------------|---------------------|-----|
| `_primary_skill_for_step` | `STEPS[step]["skill_id"]` | `STEPS[step]["skills"][0]` | steps carry a list |
| `_evidence_step_metadata` | `{title, skill_id, artifact}` | `{title, skills, artifact}` | evidence UI shows the list |
| `_rework_gate_key_for_step` | `SINGLE_GATE_KEY` (=None) | step→gate map | multi-gate line |
| `run()` / `_execute_validation()` | absent | defines full 18-step `run` + `_execute_validation` | per-line orchestration |

> ⚠️ **GOTCHA-OV (DO NOT redefine base signals/query):** Validation adds ONE NEW signal
> (`stakeholder_approved`, §4.1). It does NOT redefine `gate_approved`, `gate_rejected`,
> `escalation_resolved`, `merge_retry`, or `get_status` — those are inherited from
> `LineWorkflowBase` and re-decorating any of them crashes on duplicate registration
> (GOTCHA-SIG0 / GOTCHA-Q1 in `_LineWorkflowBase.md`). A rebuild MUST inherit, not redeclare.

### 3.1 `_primary_skill_for_step(self, step_name) -> str` (`validation.py:251-253`)
```text
return VALIDATION_STEPS[step_name]["skills"][0]
```
First entry of the `skills` list drives `task_type` dispatch (`base._dispatch_agent`). E.g.
`functional-parity` → `"parity-verifier"`.

### 3.2 `_evidence_step_metadata(self, step_name, step_def) -> dict` (`validation.py:255-263`)
```text
return {
    "title":    step_def.get("title", step_name),
    "skills":   step_def["skills"],         # ← LIST, not skill_id
    "artifact": step_def["artifact"],
}
```
The evidence bundle per-step block carries the full `skills` list. (No branches.)

### 3.3 `_rework_gate_key_for_step(self, step_name) -> str | None` (`validation.py:265-280`) — 4 BRANCHES
Maps each agent step to the gate whose rework feedback should forward into its dispatch context
(consumed by `base._dispatch_agent` → `context["rework_feedback"]`):
```text
def _rework_gate_key_for_step(self, step_name):
    if step_name == "functional-parity":                              # BRANCH 1  validation.py:274
        return "G-V1"
    if step_name in {"security-compliance", "accessibility-ux"}:      # BRANCH 2  validation.py:276
        return "G-V2"
    if step_name == "safety-assurance":                              # BRANCH 3  validation.py:278
        return "G-V3"
    return None                                                      # BRANCH 4 (default) validation.py:280
```
> ⚠️ **GOTCHA-RG1 (feedback string keys MUST equal `GateType.value`):** the returned keys
> (`"G-V1"`/`"G-V2"`/`"G-V3"`) match `GateType.G_V*.value`, which is the SAME key
> `_wait_for_gate_decision` stores feedback under (`_rework_feedback[gate_type.value]`). If a
> rebuild returned e.g. `"GV1"` the rework feedback would never match and re-running streams would
> lose prior rejection reasons. Per the docstring (`validation.py:267-273`), the contract is that
> G-V1/G-V2 rejection actually routes contested findings back to *Modernization*, but the feedback
> still flows into the per-stream agent context so the stream is aware of prior rejection reasons
> when Modernization re-submits.

---

## 4. SIGNALS / QUERIES / UPDATES

### 4.1 NEW signal: `stakeholder_approved(self, signal: StakeholderApprovedSignal) -> None` (`validation.py:286-312`) — 5 BRANCHES

`@workflow.signal`, **async**. Payload `StakeholderApprovedSignal` (`approval_id: str`,
`stakeholder: str`, `scope: str` — see types.py:165-170). Routes Tier-1 stakeholder approvals by
scope into the four flags. Unknown scopes are logged and ignored.

```text
async def stakeholder_approved(self, signal):
    scope = signal.scope                                       # validation.py:298
    if scope == "g-v2-compliance":                             # BRANCH 1  validation.py:299
        self._stakeholder_compliance_approved = True           # validation.py:300
    elif scope == "g-v2-security":                             # BRANCH 2  validation.py:301
        self._stakeholder_security_approved = True             # validation.py:302
    elif scope == "g-v3-safety":                               # BRANCH 3  validation.py:303
        self._stakeholder_safety_approved = True               # validation.py:304
    elif scope == "g-v3-cert":                                 # BRANCH 4  validation.py:305
        self._stakeholder_cert_approved = True                 # validation.py:306
    else:                                                      # BRANCH 5  validation.py:307
        workflow.logger.warning(
            "validation stakeholder_approved with unrecognized scope",
            extra={"scope": scope})                            # validation.py:308-311
    self._updated_at = _now_iso()                              # validation.py:312  (ALWAYS, even unknown scope)
```

**Buffering / consumption:** these four bool flags are consumed by two `wait_condition`
predicates in `_execute_validation`:
- G-V2 (`validation.py:570-579`): `wait_condition(lambda: (self._stakeholder_compliance_approved and self._stakeholder_security_approved) or self.cancelled)`.
- G-V3 (`validation.py:717-725`): `wait_condition(lambda: (self._stakeholder_safety_approved and self._stakeholder_cert_approved) or self.cancelled)`.

> ⚠️ **GOTCHA-SH1 (scope strings are EXACT wire contract):** the four literal scope strings
> `"g-v2-compliance"`, `"g-v2-security"`, `"g-v3-safety"`, `"g-v3-cert"` are the exact strings a
> client must send. A rebuild MUST match them byte-for-byte; a typo silently routes to the
> `else`/warn branch and the gate never unblocks.
> ⚠️ **GOTCHA-SH2 (`_updated_at` bumped even for unknown scope):** the timestamp bump
> (`validation.py:312`) is AFTER the if/elif chain, so even an unrecognized scope refreshes
> `_updated_at` (dashboard sees activity). Keep it outside the branch.
> ⚠️ **GOTCHA-SH3 (flags are NOT consulted for Tier-2/Tier-3):** the gate `wait_condition`s that
> read these flags are guarded by `if self._risk_tier == 1:` (G-V2, `validation.py:570`) and live
> only inside the `if is_tier_1:` block (G-V3). Tier-2/Tier-3 runs set/ignore the flags harmlessly
> — the signal handler still records them, but no predicate reads them.
> ⚠️ **GOTCHA-SH4 (G-V3 reset, NOT G-V2 reset):** only the G-V3 flags are reset on rejection
> (`validation.py:711-712`). The G-V2 flags are NOT reset on G-V2 rejection — see GOTCHA-V2RESET
> in §5.1. A rebuild must reproduce the asymmetry exactly.

### 4.2 Inherited signals (NOT redefined)
`gate_approved`, `gate_rejected`, `escalation_resolved`, `merge_retry` (base);
`approve`, `cancel_workflow`, `approve_plan`, `provide_plan_feedback`, `approve_research`,
`provide_feedback` (HIL mixin). `self.cancelled` (set by `cancel_workflow`) is the universal kill
switch threaded into every gate/merge/stakeholder `wait_condition`.

### 4.3 Inherited query (NOT redefined)
`get_status()` (base) — the only query. Reflects live
`_status`/`_current_step`/`_progress_pct`/`_pending_gate`/`_updated_at`. Validation adds NO new
queries and NO updates.

---

## 5. CONTROL FLOW — `run()` and `_execute_validation()`

### 5.0 `run(self, input: LineWorkflowInput) -> str` (`validation.py:318-361`) — entry + 1 try/except (2 except branches)

`@workflow.run`. Sets up state, derives identifiers, delegates to `_execute_validation`, and wraps
everything in a failure handler.

```text
async def run(self, input):
    self._status = WorkflowStatus.RUNNING                       # validation.py:321
    self._started_at = _now_iso()                               # validation.py:322
    self._updated_at = self._started_at                         # validation.py:323

    app_id = input.app_id                                       # validation.py:325
    self._app_id = app_id                                       # validation.py:326
    self._risk_tier = (                                         # validation.py:330-332
        int(input.risk_tier) if input.risk_tier is not None else None)
    is_tier_1 = self._risk_tier == 1                            # validation.py:333

    wf_id = workflow.info().workflow_id                         # validation.py:335
    run_suffix = wf_id.rsplit("-", 1)[-1] if "-" in wf_id else wf_id[:8]   # validation.py:336  BRANCH (inline)
    branch = f"olympus/validation/{app_id}/{run_suffix}"        # validation.py:337
    workspace_key = f"validation-{app_id}-{run_suffix}"         # validation.py:338
    repo = getattr(input, "target_repo_url", "") or input.artifact_repo    # validation.py:342-345  BRANCH (or)

    try:
        return await self._execute_validation(                  # validation.py:348-350
            input, app_id, repo, branch, workspace_key, is_tier_1)
    except Exception:                                           # validation.py:351  BRANCH (outer except)
        self._status = WorkflowStatus.FAILED                    # validation.py:352
        self._current_step = "failed"                           # validation.py:353
        self._updated_at = _now_iso()                           # validation.py:354
        try:
            await self._update_app_status(                      # validation.py:356-358
                app_id, "validation_failed", "failed", "Validation")
        except Exception:                                       # validation.py:359  BRANCH (inner except)
            pass                                                # validation.py:360  best-effort
        raise                                                   # validation.py:361  re-raise original
```

**Branch inventory (run): 4**
- `run_suffix = ... if "-" in wf_id else wf_id[:8]` (`validation.py:336`) — derive a short suffix
  from the workflow id (last hyphen-delimited segment, or first 8 chars if no hyphen).
- `repo = getattr(...,"") or input.artifact_repo` (`validation.py:342-345`) — prefer
  `target_repo_url`, fall back to `artifact_repo` for older callers (W19 repo-split,
  `validation.py:339-345`).
- outer `except Exception:` (`validation.py:351`) — on ANY failure, set `FAILED`/`"failed"`, push
  app status best-effort, re-raise.
- inner `except Exception: pass` (`validation.py:359-360`) — the failure-status DB push is itself
  best-effort; swallow its error.

> ⚠️ **GOTCHA-RUN1 (`run_suffix` derivation is deterministic but workflow-id-shaped):** branch +
> workspace_key both embed `run_suffix`. A rebuild MUST use `wf_id.rsplit("-", 1)[-1]` (NOT
> `split`), giving the trailing segment, and fall back to `wf_id[:8]` only when there's no hyphen.
> Different derivation → different branch name → wrong PRs / commits.
> ⚠️ **GOTCHA-RUN2 (the outer except re-raises after marking FAILED):** the workflow does NOT
> swallow the underlying exception — it sets terminal `FAILED` state, best-effort projects
> `validation_failed`, then `raise`s so Temporal records the failure. The `_fail(...)` helper (§5.10)
> is a DIFFERENT path that *returns* `"failed"` cleanly (rework exhaustion) without raising. Don't
> conflate them.

---

### 5.1 `_execute_validation(self, input, app_id, repo, branch, workspace_key, is_tier_1) -> str` (`validation.py:363-819`) — the 18-step core

This is the heart. It contains the G-V1/G-V2 rework loop, the Tier-1 G-V3 rework loop, the
per-gate cATO evidence dispatches, the persist step, and the terminal merge + signal. Structured
pseudocode preserving EVERY branch:

```text
async def _execute_validation(self, input, app_id, repo, branch, workspace_key, is_tier_1):
    prior_artifacts = list(input.prior_artifacts)               # validation.py:373

    # ===== Step 1 — Intake =====
    await self._set_step("intake", STEP_WEIGHTS["intake"])      # validation.py:376

    # ===== G-V1 / G-V2 rework loop (steps 2-11) =====
    while True:                                                  # validation.py:383  ★LOOP-A
        # --- Steps 2-4: three parallel streams ---
        await self._run_parallel_streams(                       # validation.py:385-387
            app_id, repo, branch, workspace_key, prior_artifacts)

        # --- Step 5: Bundle G-V1 evidence (+ cATO SSP dispatch) ---
        await self._set_step("bundle-g-v1-evidence",
                             self._progress_at("bundle-g-v1-evidence"))   # validation.py:390-393
        # ⓝ P6-S8.2 — dispatch cato-compliance to emit SSP + per-control
        # evidence bundle to .cato/{uuid}/ BEFORE the gate (best-effort).
        await self._dispatch_cato_evidence(                     # validation.py:396-402
            app_id, repo, branch, workspace_key, stage="G-V1",
            input_artifacts=self._step_committed_paths.get("security-compliance", []))
        gv1_evidence_paths = dedup_paths(                       # validation.py:403-406
            self._step_committed_paths.get("functional-parity", [])
            + self._cato_paths.get("G-V1", []))                 # ← ⓝ cATO paths unioned in

        # --- Step 6: Create G-V1 PR + gate record + submit evidence ---
        await self._set_step("create-g-v1-pr", self._progress_at("create-g-v1-pr"))    # validation.py:409-411
        gv1_pr = await self._create_gate_pr(                    # validation.py:412-417
            repo, branch, app_id,
            gate_type=GateType.G_V1.value,                      # ← STRING "G-V1"
            title=f"Gate G-V1: Functional Parity — {app_id}",
            body=self._build_gv1_pr_body(app_id))
        gv1_record = await workflow.execute_activity(           # validation.py:418-429
            create_gate_record,
            CreateGateRecordInput(gate_type=GateType.G_V1.value, app_id=app_id,
                portfolio_id=input.portfolio_id,
                workflow_id=workflow.info().workflow_id,
                evidence_package_url=gv1_pr.pr_url),
            start_to_close_timeout=timedelta(seconds=30),
            retry_policy=RETRY_POLICIES["transient"])
        await self._submit_gate_evidence(                       # validation.py:430-438
            gate_id=gv1_record.gate_id, gate_type=GateType.G_V1, app_id=app_id,
            artifact_paths=dedup_paths(gv1_evidence_paths), pr_url=gv1_pr.pr_url,
            assembly_line="Validation", step="gate-review-v1")

        # --- Step 7: Gate G-V1 (AUTOMATED pass/fail) ---
        await self._set_step("gate-review-v1", self._progress_at("gate-review-v1"))    # validation.py:447-449
        if not self._parity_meets_threshold():                  # validation.py:450  BRANCH 1 (auto-reject)
            workflow.logger.info("G-V1 auto-rejected — parity below threshold",
                extra={"app_id": app_id, "risk_tier": self._risk_tier})   # validation.py:451-457
            self._bump_rework("G-V1")                           # validation.py:458
            if self._rework_count("G-V1") > MAX_REWORK_ITERATIONS:   # validation.py:459  BRANCH 2
                return await self._fail("max-rework-exceeded-gv1", app_id)   # validation.py:460-462
            continue                                            # validation.py:463  ← re-enter LOOP-A (re-run streams)

        gv1_decision = await self._wait_for_gate_decision(GateType.G_V1)   # validation.py:465
        if gv1_decision == "cancelled":                         # validation.py:466  BRANCH 3
            return "cancelled"                                  # validation.py:467
        if gv1_decision == "rejected":                          # validation.py:468  BRANCH 4
            self._bump_rework("G-V1")                           # validation.py:469
            if self._rework_count("G-V1") > MAX_REWORK_ITERATIONS:   # validation.py:470  BRANCH 5
                return await self._fail("max-rework-exceeded-gv1", app_id)   # validation.py:471-473
            continue                                            # validation.py:474  ← re-enter LOOP-A

        # Approved — merge the G-V1 ACK PR (merge_blocked retry loop inside helper)
        await self._reconcile_and_merge_with_retry_loop(        # validation.py:478-483
            repo=repo, pr_number=gv1_pr.pr_number,
            gate_id=gv1_record.gate_id, merge_method="merge")
        await self._update_app_status(app_id, "validation_parity_approved",
                                      "gate-review-v1", "Validation")       # validation.py:484-487

        # --- Step 8: Bundle G-V2 evidence (+ cATO SAR dispatch) ---
        await self._set_step("bundle-g-v2-evidence",
                             self._progress_at("bundle-g-v2-evidence"))     # validation.py:490-493
        # ⓝ P6-S8.2 — emit SAR + refreshed per-control evidence bundle.
        await self._dispatch_cato_evidence(                     # validation.py:495-502
            app_id, repo, branch, workspace_key, stage="G-V2",
            input_artifacts=dedup_paths(
                self._step_committed_paths.get("security-compliance", [])
                + self._cato_paths.get("G-V1", [])))            # ← prior SSP fed forward
        gv2_evidence_paths = dedup_paths(                       # validation.py:503-507
            self._step_committed_paths.get("security-compliance", [])
            + self._step_committed_paths.get("accessibility-ux", [])
            + self._cato_paths.get("G-V2", []))                 # ← ⓝ cATO SAR unioned in

        # --- Step 9: Create G-V2 PR + gate record + submit evidence ---
        await self._set_step("create-g-v2-pr", self._progress_at("create-g-v2-pr"))    # validation.py:510-512
        gv2_pr = await self._create_gate_pr(                    # validation.py:513-518
            repo, branch, app_id, gate_type=GateType.G_V2.value,
            title=f"Gate G-V2: Compliance & Security — {app_id}",
            body=self._build_gv2_pr_body(app_id))
        gv2_record = await workflow.execute_activity(           # validation.py:519-530
            create_gate_record,
            CreateGateRecordInput(gate_type=GateType.G_V2.value, app_id=app_id,
                portfolio_id=input.portfolio_id,
                workflow_id=workflow.info().workflow_id,
                evidence_package_url=gv2_pr.pr_url),
            start_to_close_timeout=timedelta(seconds=30),
            retry_policy=RETRY_POLICIES["transient"])
        await self._submit_gate_evidence(                       # validation.py:531-539
            gate_id=gv2_record.gate_id, gate_type=GateType.G_V2, app_id=app_id,
            artifact_paths=gv2_evidence_paths, pr_url=gv2_pr.pr_url,
            assembly_line="Validation", step="gate-review-v2")

        # --- Step 10: AI Pre-Review (G-V2) ---
        await self._set_step("ai-pre-review-v2", self._progress_at("ai-pre-review-v2"))   # validation.py:542-544
        await self._run_gate_pre_review(                        # validation.py:545-551
            gv2_record.gate_id, GateType.G_V2.value, gv2_evidence_paths,
            artifact_repo=repo, artifact_ref=branch)

        # --- Step 11: Gate G-V2 ---
        await self._set_step("gate-review-v2", self._progress_at("gate-review-v2"))     # validation.py:554-556
        gv2_decision = await self._wait_for_gate_decision(GateType.G_V2)   # validation.py:557
        if gv2_decision == "cancelled":                         # validation.py:558  BRANCH 6
            return "cancelled"                                  # validation.py:559
        if gv2_decision == "rejected":                          # validation.py:560  BRANCH 7
            self._bump_rework("G-V2")                           # validation.py:561
            if self._rework_count("G-V2") > MAX_REWORK_ITERATIONS:   # validation.py:562  BRANCH 8
                return await self._fail("max-rework-exceeded-gv2", app_id)   # validation.py:563-565
            continue                                            # validation.py:566  ← re-enter LOOP-A

        # Approved — Tier-1 triple-signal wait for compliance + security
        if self._risk_tier == 1:                                # validation.py:570  BRANCH 9 (Tier-1 only)
            await workflow.wait_condition(                      # validation.py:571-579
                lambda: ((self._stakeholder_compliance_approved
                          and self._stakeholder_security_approved)
                         or self.cancelled))
            if self.cancelled:                                  # validation.py:580  BRANCH 10
                self._status = WorkflowStatus.CANCELLED         # validation.py:581
                return "cancelled"                              # validation.py:582

        await self._reconcile_and_merge_with_retry_loop(        # validation.py:584-589
            repo=repo, pr_number=gv2_pr.pr_number,
            gate_id=gv2_record.gate_id, merge_method="merge")
        await self._update_app_status(app_id, "validation_compliance_approved",
                                      "gate-review-v2", "Validation")       # validation.py:590-593
        break                                                   # validation.py:594  ← EXIT LOOP-A

    # final_pr default = G-V2 PR (Tier-2/3 terminal); Tier-1 overrides below
    final_pr = gv2_pr                                           # validation.py:598

    # ===== Steps 12-16 — Safety Assurance + G-V3 (Tier-1 ONLY) =====
    if is_tier_1:                                               # validation.py:601  BRANCH 11 (TIER GATE)
        while True:                                             # validation.py:602  ★LOOP-B
            # --- Step 12: Safety Assurance stream ---
            await self._run_safety_stream(                      # validation.py:604-621
                app_id, repo, branch, workspace_key,
                dedup_paths(list(input.prior_artifacts)
                    + self._step_committed_paths.get("functional-parity", [])
                    + self._step_committed_paths.get("security-compliance", [])
                    + self._step_committed_paths.get("accessibility-ux", [])))
            self._safety_case_ref = f"validation/{app_id}/{VALIDATION_STEPS[TIER1_STEP]['artifact']}"   # validation.py:623-626

            # --- Step 13: Bundle G-V3 evidence (+ cATO POA&M dispatch) ---
            await self._set_step("bundle-g-v3-evidence",
                                 self._progress_at("bundle-g-v3-evidence"))   # validation.py:629-632
            # ⓝ P6-S8.2 — emit POA&M + reauthorization-trigger log.
            await self._dispatch_cato_evidence(                 # validation.py:634-641
                app_id, repo, branch, workspace_key, stage="G-V3",
                input_artifacts=dedup_paths(
                    self._step_committed_paths.get(TIER1_STEP, [])
                    + self._cato_paths.get("G-V2", [])))        # ← prior SAR fed forward
            gv3_evidence_paths = dedup_paths(                   # validation.py:642-645
                self._step_committed_paths.get(TIER1_STEP, [])
                + self._cato_paths.get("G-V3", []))             # ← ⓝ cATO POA&M unioned in

            # --- Step 14: Create G-V3 PR + gate record + submit evidence ---
            await self._set_step("create-g-v3-pr", self._progress_at("create-g-v3-pr"))   # validation.py:648-650
            gv3_pr = await self._create_gate_pr(                # validation.py:651-658
                repo, branch, app_id, gate_type=GateType.G_V3.value,
                title=f"Gate G-V3: Safety Assurance (Tier 1) — {app_id}",
                body=self._build_gv3_pr_body(app_id))
            gv3_record = await workflow.execute_activity(       # validation.py:659-670
                create_gate_record,
                CreateGateRecordInput(gate_type=GateType.G_V3.value, app_id=app_id,
                    portfolio_id=input.portfolio_id,
                    workflow_id=workflow.info().workflow_id,
                    evidence_package_url=gv3_pr.pr_url),
                start_to_close_timeout=timedelta(seconds=30),
                retry_policy=RETRY_POLICIES["transient"])
            await self._submit_gate_evidence(                   # validation.py:671-679
                gate_id=gv3_record.gate_id, gate_type=GateType.G_V3, app_id=app_id,
                artifact_paths=dedup_paths(gv3_evidence_paths), pr_url=gv3_pr.pr_url,
                assembly_line="Validation", step="gate-review-v3")

            # --- Step 15: AI Pre-Review (G-V3) ---
            await self._set_step("ai-pre-review-v3", self._progress_at("ai-pre-review-v3"))   # validation.py:682-685
            await self._run_gate_pre_review(                    # validation.py:686-692
                gv3_record.gate_id, GateType.G_V3.value, dedup_paths(gv3_evidence_paths),
                artifact_repo=repo, artifact_ref=branch)

            # --- Step 16: Gate G-V3 ---
            await self._set_step("gate-review-v3", self._progress_at("gate-review-v3"))   # validation.py:695-697
            gv3_decision = await self._wait_for_gate_decision(GateType.G_V3)   # validation.py:698-700
            if gv3_decision == "cancelled":                     # validation.py:701  BRANCH 12
                return "cancelled"                              # validation.py:702
            if gv3_decision == "rejected":                      # validation.py:703  BRANCH 13
                self._bump_rework("G-V3")                       # validation.py:704
                if self._rework_count("G-V3") > MAX_REWORK_ITERATIONS:   # validation.py:705  BRANCH 14
                    return await self._fail("max-rework-exceeded-gv3", app_id)   # validation.py:706-708
                self._stakeholder_safety_approved = False       # validation.py:711  ← RESET
                self._stakeholder_cert_approved = False         # validation.py:712  ← RESET
                continue                                        # validation.py:713  ← re-enter LOOP-B

            # Approved — Tier-1 triple-signal wait for safety + cert
            await workflow.wait_condition(                      # validation.py:717-725
                lambda: ((self._stakeholder_safety_approved
                          and self._stakeholder_cert_approved)
                         or self.cancelled))
            if self.cancelled:                                  # validation.py:726  BRANCH 15
                self._status = WorkflowStatus.CANCELLED         # validation.py:727
                return "cancelled"                              # validation.py:728

            final_pr = gv3_pr                                   # validation.py:730  ← Tier-1 terminal PR
            break                                               # validation.py:731  ← EXIT LOOP-B

    # ===== Step 17 — Persist Validation side-effects (+ cATO projection) =====
    await self._set_step("persist-validation-side-effects",
                         self._progress_at("persist-validation-side-effects"))   # validation.py:734-737
    gv1_json = self._first_output("functional-parity")          # validation.py:738
    gv2_compliance_json = self._first_output("security-compliance")   # validation.py:739
    gv2_accessibility_json = self._first_output("accessibility-ux")   # validation.py:740
    gv3_safety_json = self._first_output(TIER1_STEP) if is_tier_1 else ""   # validation.py:741-743  BRANCH 16
    cato_uuid = self._cato_target_uuid or app_id                # validation.py:744  BRANCH 17 (or)
    try:
        await workflow.execute_activity(                        # validation.py:746-783
            persist_validation_side_effects,
            PersistValidationSideEffectsInput(
                target_app_id=app_id,
                risk_tier=str(self._risk_tier) if self._risk_tier else "",   # validation.py:750  BRANCH 18
                parity_report_json=gv1_json,
                security_report_json=gv2_compliance_json,
                accessibility_audit_json=gv2_accessibility_json,
                safety_case_json=gv3_safety_json,
                safety_case_ref=self._safety_case_ref,
                decided_at=_now_iso(),
                cato_target_uuid=cato_uuid,                              # ⓝ
                cato_stage=self._cato_highest_stage,                    # ⓝ
                cato_ssp_path=(f".cato/{cato_uuid}/ssp.json"
                               if self._cato_paths.get("G-V1") else ""),   # validation.py:759-763  BRANCH 19 ⓝ
                cato_sar_path=(f".cato/{cato_uuid}/sar.json"
                               if self._cato_paths.get("G-V2") else ""),   # validation.py:764-768  BRANCH 20 ⓝ
                cato_poam_path=(f".cato/{cato_uuid}/poam.json"
                                if self._cato_paths.get("G-V3") else ""),   # validation.py:769-773  BRANCH 21 ⓝ
                control_evidence_json=(json.dumps(self._cato_evidence_records)
                    if self._cato_evidence_records else "")),               # validation.py:774-778  BRANCH 22 ⓝ
            start_to_close_timeout=timedelta(seconds=60),
            retry_policy=RETRY_POLICIES["transient"],
            activity_id="persist-validation-side-effects")
    except Exception:                                           # validation.py:784  BRANCH 23 (best-effort)
        workflow.logger.exception(
            "persist_validation_side_effects failed; application row will keep "
            "stale validation fields")                          # validation.py:785-788

    # ===== Step 18 — Merge final gate PR + emit ValidationApprovedSignal =====
    await self._set_step("merge-final-gate-pr",
                         self._progress_at("merge-final-gate-pr"))   # validation.py:791-794
    if is_tier_1:                                               # validation.py:798  BRANCH 24
        await self._reconcile_and_merge_with_retry_loop(        # validation.py:799-804
            repo=repo, pr_number=final_pr.pr_number,
            gate_id=gv3_record.gate_id, merge_method="merge")
    await self._fire_validation_approved_signal(input, app_id)  # validation.py:810
    await self._update_app_status(app_id, "validation_complete",
                                  "completed", "Validation")    # validation.py:812-814
    self._status = WorkflowStatus.COMPLETED                     # validation.py:815
    self._progress_pct = 100.0                                  # validation.py:816
    self._current_step = "completed"                            # validation.py:817
    self._updated_at = _now_iso()                               # validation.py:818
    return "completed"                                          # validation.py:819
```

**Branch inventory (`_execute_validation`): 24** (LOOP-A `while True` 383; G-V1 auto-reject 450;
auto-reject cap 459; gv1 cancelled 466; gv1 rejected 468; gv1 reject cap 470; gv2 cancelled 558;
gv2 rejected 560; gv2 reject cap 562; Tier-1 G-V2 wait gate 570; G-V2 cancel after wait 580;
`if is_tier_1` step-12 gate 601; LOOP-B `while True` 602; gv3 cancelled 701; gv3 rejected 703; gv3
reject cap 705; G-V3 cancel after wait 726; persist `gv3_safety_json` ternary 741; `cato_uuid` or
744; persist `risk_tier` ternary 750; cato_ssp ternary 759; cato_sar ternary 764; cato_poam
ternary 769; control_evidence ternary 774; persist `except` 784; final-merge `if is_tier_1` 798).
The inline `run_suffix` ternary lives in `run()` (§5.0). ⓝ = the four cATO-path ternaries + the
`cato_uuid or` fallback are NEW since the old baseline.

> ⚠️ **GOTCHA-V1AUTO (G-V1 auto-rejection bypasses the gate wait entirely):** at step 7
> (`validation.py:450-463`), if `_parity_meets_threshold()` is False the workflow does NOT call
> `_wait_for_gate_decision`. It bumps rework, checks the cap, and `continue`s to re-run streams —
> NO PM signal is awaited. The PM-merge path (`_wait_for_gate_decision` → `gate_approved`) is ONLY
> reached when parity ≥ threshold, where the PM merge is *acknowledgement, not evaluation*
> (`validation.py:440-446`). A rebuild MUST keep the auto-reject branch BEFORE the gate wait, or
> it would block forever waiting for a PM decision on a failing-parity gate.
> ⚠️ **GOTCHA-V1CONT (`continue` re-runs the FULL stream fan-out — AND the cATO dispatch):** every
> `continue` in LOOP-A (validation.py:463/474/566) jumps back to `_run_parallel_streams`
> (validation.py:385). On a rework iteration ALL THREE streams re-dispatch (with `_rework_feedback`
> for the relevant gate now populated by `_wait_for_gate_decision`) AND the G-V1 / G-V2 cATO
> dispatches re-run (re-emitting `.cato/{uuid}/` evidence, merging into prior SSP via
> `context["prior_ssp_path"]`). A rebuild must NOT skip un-rejected streams nor short-circuit the
> cATO re-emit — the loop always re-runs all three streams and both pre-gate cATO dispatches.
> ⚠️ **GOTCHA-V2RESET (G-V2 flags are NOT reset on rework, but G-V3 flags ARE):** on G-V2
> rejection (`validation.py:560-566`) the code bumps rework + `continue`s but does NOT reset
> `_stakeholder_compliance_approved` / `_stakeholder_security_approved`. On G-V3 rejection
> (`validation.py:703-713`) it DOES reset `_stakeholder_safety_approved` /
> `_stakeholder_cert_approved` (validation.py:711-712) "so a prior cycle's approvals don't leak".
> This asymmetry is INTENTIONAL and load-bearing: a rebuild MUST reset only the G-V3 pair. (Note:
> the G-V2 stakeholder wait happens AFTER approval, so a leaked G-V2 flag could let a re-approved
> G-V2 skip the stakeholder wait on the next cycle — this is the documented behavior; reproduce it,
> do not "fix" it.)
> ⚠️ **GOTCHA-REWORKCAP (cap is `> MAX_REWORK_ITERATIONS`, i.e. allows 3 reworks):** `_bump_rework`
> increments FIRST, then `_rework_count(...) > 3` is checked. So counts 1,2,3 pass (continue);
> count 4 fails. Effectively the gate may be reworked 3 times; the 4th rejection (the 4th bump)
> trips `_fail`. A rebuild MUST bump-then-compare-strictly-greater, not `>=`.
> ⚠️ **GOTCHA-FINALPR (`final_pr` defaulting + Tier branch):** `final_pr = gv2_pr` is set
> unconditionally after LOOP-A (`validation.py:598`); Tier-1 overwrites it with `gv3_pr`
> (`validation.py:730`). At step 18 the final merge runs ONLY for Tier-1 (`validation.py:798`)
> because Tier-2/3 already merged G-V2 in the approval branch (`validation.py:584-589`) — merging
> again would be a no-op, so it's skipped. Both Tier paths still emit the signal
> (`_fire_validation_approved_signal`, validation.py:810). The Tier-1 final merge uses
> `gate_id=gv3_record.gate_id` (`validation.py:802`) — `gv3_record` is in scope only because the
> `if is_tier_1:` step-18 guard mirrors the `if is_tier_1:` step-12 guard that created it.
> ⚠️ **GOTCHA-CANCELRETURN (two cancel return shapes):** gate-decision cancels return the bare
> string `"cancelled"` WITHOUT setting `_status` (validation.py:467/559/702 — `_wait_for_gate_decision`
> already set `_status=CANCELLED` internally per GOTCHA-WG3). The stakeholder-wait cancels DO set
> `self._status = WorkflowStatus.CANCELLED` explicitly before returning `"cancelled"`
> (validation.py:580-582, 726-728) because no helper set it. A rebuild must reproduce both shapes.
> ⚠️ **GOTCHA-PERSIST-TERNARIES (multiple falsy-guard ternaries differ subtly):**
> `gv3_safety_json = _first_output(TIER1_STEP) if is_tier_1 else ""` (validation.py:741) keys on the
> boolean `is_tier_1`; `risk_tier=str(self._risk_tier) if self._risk_tier else ""`
> (validation.py:750) keys on TRUTHINESS of `_risk_tier`. The three cATO-path ternaries
> (validation.py:759/764/769) each key on `self._cato_paths.get("G-Vx")` being TRUTHY (a non-empty
> list) — so a stage that was dispatched but committed NO files (or whose cATO dispatch failed)
> yields `""` for that path. `control_evidence_json` (validation.py:774) keys on
> `_cato_evidence_records` being non-empty. `_risk_tier == 0` is impossible (tiers are 1/2/3/None)
> but `None` is falsy → `""`. A rebuild must reproduce each guard's exact predicate.
> ⚠️ **GOTCHA-PERSIST-CATOUUID (`_cato_target_uuid or app_id`):** the persist `cato_uuid`
> (`validation.py:744`) is `self._cato_target_uuid or app_id`. `_cato_target_uuid` is set to `app_id`
> by every cATO dispatch (§5.7), so in practice it equals `app_id` once any dispatch ran; the `or
> app_id` covers the case where NO cATO dispatch ever set it (e.g. all dispatches failed before
> line 957-958, which is impossible since it's set first — belt-and-suspenders). The cATO-path
> ternaries then build `.cato/{cato_uuid}/{ssp,sar,poam}.json` from this same uuid. Reproduce the
> `or app_id` fallback.
> ⚠️ **GOTCHA-PERSIST-BESTEFFORT (step 17 NEVER fails the run):** the `persist_validation_side_effects`
> call is wrapped in `try/except Exception` that only logs (`validation.py:784-788`). Even with a
> `transient` (3-attempt) retry policy, total failure is swallowed — the app row keeps stale
> validation fields but the workflow proceeds to step 18 and completes. A rebuild must NOT let this
> activity's failure propagate.

---

### 5.2 cATO dispatch interleaving — where the three `_dispatch_cato_evidence` calls sit

⚠️ **CHANGED — this entire interleaving is NEW.** The old baseline had no cATO calls in
`_execute_validation`. HEAD inserts a `_dispatch_cato_evidence` call inside each of the three
bundle steps, BEFORE the gate-PR/evidence-submit for that gate:

| Stage | Call site | `input_artifacts` fed | Purpose | Result consumed by |
|-------|-----------|-----------------------|---------|--------------------|
| `G-V1` | step 5, `validation.py:396-402` | `_step_committed_paths["security-compliance"]` | emit SSP + per-control evidence bundle | `gv1_evidence_paths` union (403-406) + persist `cato_ssp_path` |
| `G-V2` | step 8, `validation.py:495-502` | dedup(`security-compliance` committed + `_cato_paths["G-V1"]`) | emit SAR + refreshed evidence bundle (prior SSP fed forward) | `gv2_evidence_paths` union (503-507) + persist `cato_sar_path` |
| `G-V3` | step 13 (Tier-1 only), `validation.py:634-641` | dedup(`safety-assurance` committed + `_cato_paths["G-V2"]`) | emit POA&M + reauth-trigger log (prior SAR fed forward) | `gv3_evidence_paths` union (642-645) + persist `cato_poam_path` |

> ⚠️ **GOTCHA-CATO-ORDER (cATO dispatch happens INSIDE the bundle step, BEFORE the gate PR):** each
> `_dispatch_cato_evidence` runs after `_set_step("bundle-g-vN-evidence", ...)` but BEFORE the
> `gvN_evidence_paths` union is computed, so the union can pick up the freshly committed
> `_cato_paths[stage]`. A rebuild MUST order: set bundle step → dispatch cATO → compute evidence
> union (with `_cato_paths.get(stage, [])` folded in) → create PR / submit evidence. Reordering
> would drop cATO artifacts from the gate evidence bundle.
> ⚠️ **GOTCHA-CATO-FEEDFORWARD (prior-stage cATO paths feed the next dispatch's inputs):** G-V2's
> dispatch inputs include `_cato_paths["G-V1"]` (the SSP), and G-V3's include `_cato_paths["G-V2"]`
> (the SAR). This is how the skill merges into prior OSCAL state rather than regenerating (the
> `prior_ssp_path` context arg, §5.7). On a rework `continue`, the G-V1/G-V2 dispatches re-run and
> the unions re-form — `_cato_paths` is overwritten per stage each time. Reproduce the feed-forward.

---

### 5.3 `_run_parallel_streams(self, app_id, repo, branch, workspace_key, prior_artifacts) -> None` (`validation.py:825-884`) — fan-out, 1 nested try/except

Runs the three always-on streams concurrently via `asyncio.gather`. Emits per-stream
status/timestamps for the `per_stream_agent` fanout payload.

```text
async def _run_parallel_streams(self, app_id, repo, branch, workspace_key, prior_artifacts):
    await self._set_step("functional-parity", self._progress_at("functional-parity"))   # validation.py:842-844
    for stream in PARALLEL_STREAMS:                             # validation.py:845  LOOP (init)
        self._stream_status[stream] = "running"                # validation.py:846
        self._stream_started_at[stream] = _now_iso()           # validation.py:847

    async def _run_stream(step_name):                          # validation.py:849  (inner coroutine)
        try:
            result = await self._dispatch_agent(               # validation.py:851-858
                app_id=app_id, step_name=step_name,
                input_artifacts=prior_artifacts, workspace_key=workspace_key,
                artifact_repo=repo, artifact_ref=branch)
            self._step_results[step_name] = result.output_artifacts   # validation.py:859
            artifact_path = f"validation/{app_id}/{VALIDATION_STEPS[step_name]['artifact']}"   # validation.py:860-863
            await self._commit_step_artifacts(                 # validation.py:864-866
                repo, branch, app_id, step_name, result, artifact_path)
            self._stream_status[step_name] = "completed"       # validation.py:867
            self._stream_completed_at[step_name] = _now_iso()  # validation.py:868
        except Exception:                                      # validation.py:869  BRANCH (mark failed + re-raise)
            self._stream_status[step_name] = "failed"          # validation.py:870
            self._stream_completed_at[step_name] = _now_iso()  # validation.py:871
            raise                                              # validation.py:872

    await asyncio.gather(*[_run_stream(s) for s in PARALLEL_STREAMS])   # validation.py:877  ★FAN-OUT

    # advance pointer through remaining stream-roots so stepper shows all completed
    await self._set_step("accessibility-ux", self._progress_at("accessibility-ux"))   # validation.py:882-884
```

**Branch inventory: 2** (the init `for stream in PARALLEL_STREAMS` loop 845; the per-stream
`try/except…raise` 869). Plus the `asyncio.gather` fan-out comprehension (877).

**Per-stream activity calls (inside `_run_stream`, via base helpers):**
1. `_dispatch_agent(...)` → `dispatch_agent_task` (1h start_to_close, `agent_failure` policy,
   `activity_id="agent-{step}"`). Sets `_step_results[step] = result.output_artifacts`.
2. `_commit_step_artifacts(...)` → batched `write_artifacts_batch` (120s, `transient`,
   `activity_id="commit-{step}"`) to `validation/{app_id}/{artifact}`. Sets
   `_step_committed_paths[step]`.

> ⚠️ **GOTCHA-FANOUT1 (`asyncio.gather` surfaces FIRST exception, cancels the rest):** per the
> docstring (`validation.py:874-877`), if any one stream raises, `gather` propagates the first
> exception and the remaining streams are cancelled; the exception bubbles to `run()`'s outer
> `except` → workflow FAILED. A rebuild MUST use `asyncio.gather` (default `return_exceptions=False`)
> so a stream failure fails the run — NOT `return_exceptions=True` (which would swallow).
> ⚠️ **GOTCHA-FANOUT2 (two `_set_step` pointer moves frame the gather):** the step pointer is set
> to `functional-parity` BEFORE gather (`validation.py:842`) and to `accessibility-ux` AFTER
> (`validation.py:882`). `security-compliance` is never explicitly `_set_step`'d as a pointer — the
> comment notes the post-gather move exists "so the stepper shows both as completed (not just the
> first)" (`validation.py:879-881`). A rebuild must reproduce both pointer moves around the gather;
> dropping them changes the timeline rendering and the `_progress_pct` values observed mid-run.
> ⚠️ **GOTCHA-FANOUT3 (determinism of `asyncio.gather` under Temporal):** Temporal's asyncio event
> loop schedules the gathered coroutines deterministically by creation order. The streams' activity
> dispatches interleave but each has a stable `activity_id` (`agent-{step}` / `commit-{step}`) so
> replay is deterministic. A rebuild MUST NOT introduce wall-clock ordering or `asyncio.wait` with
> timeouts here.
> ⚠️ **GOTCHA-FANOUT4 (`input_artifacts=prior_artifacts` for ALL three streams):** all three
> streams receive the SAME `prior_artifacts` list (the line's prior-line inputs), NOT each other's
> outputs (`validation.py:854`). The streams are independent. A rebuild must pass `prior_artifacts`
> to each, not chain them.

---

### 5.4 `_run_safety_stream(self, app_id, repo, branch, workspace_key, safety_inputs) -> None` (`validation.py:886-914`) — Tier-1 stream 4, NO branches

Runs `safety-assurance` (stream 4) serially. NOT wrapped in its own try/except — a failure
propagates to `run()`'s outer handler.

```text
async def _run_safety_stream(self, app_id, repo, branch, workspace_key, safety_inputs):
    await self._set_step(TIER1_STEP, self._progress_at(TIER1_STEP))   # validation.py:895-897
    result = await self._dispatch_agent(                       # validation.py:899-906
        app_id=app_id, step_name=TIER1_STEP, input_artifacts=safety_inputs,
        workspace_key=workspace_key, artifact_repo=repo, artifact_ref=branch)
    self._step_results[TIER1_STEP] = result.output_artifacts   # validation.py:907
    artifact_path = f"validation/{app_id}/{VALIDATION_STEPS[TIER1_STEP]['artifact']}"   # validation.py:908-911
    await self._commit_step_artifacts(                         # validation.py:912-914
        repo, branch, app_id, TIER1_STEP, result, artifact_path)
```

**Activity calls:** `_dispatch_agent` (→ `dispatch_agent_task`, 1h, `agent_failure`,
`activity_id="agent-safety-assurance"`) then `_commit_step_artifacts` (→ `write_artifacts_batch`,
120s, `transient`, `activity_id="commit-safety-assurance"`).

> ⚠️ **GOTCHA-SAFETY-INPUTS (safety input bundle = priors + all three prior evidence bundles):**
> the caller (`validation.py:604-621`) passes `safety_inputs = dedup_paths(prior_artifacts +
> functional-parity committed + security-compliance committed + accessibility-ux committed)`. The
> safety case references the G-V1/G-V2 approvals, so its inputs MUST be the union of prior-line
> context plus all three stream commit paths, deduped. ⚠️ Note this does NOT include the cATO
> paths — only the three stream `_step_committed_paths`. A rebuild must assemble this exact union.
> ⚠️ **GOTCHA-SAFETY-NOSTREAMSTATUS (no `_stream_status` update for safety):** `_run_safety_stream`
> does NOT touch `_stream_status`/`_stream_started_at`/`_stream_completed_at` — those dicts only
> track the THREE `PARALLEL_STREAMS`. Safety is sequential and outside that fanout payload. Don't
> add a status entry for it.

---

### 5.5 `_dispatch_cato_evidence(self, app_id, repo, branch, workspace_key, stage, input_artifacts) -> None` (`validation.py:931-1057`) — ⓝ NEW (P6-S8.2), best-effort cATO emit + commit, ~8 BRANCHES

Dispatches the `cato-compliance` skill for one Validation gate, emits the stage's OSCAL artifact
set (SSP / SAR+`evidence/` / POA&M), normalizes each output path to this run's `.cato/{uuid}/`, and
commits them. **Entirely best-effort** — any dispatch or commit failure is logged and returns
WITHOUT failing the gate (the gate's own evidence bundle already carries the stream outputs).

```text
async def _dispatch_cato_evidence(self, app_id, repo, branch, workspace_key, stage, input_artifacts):
    target_uuid = app_id                                       # validation.py:957  (OQ-3: target_uuid = app UUID)
    self._cato_target_uuid = target_uuid                       # validation.py:958
    context = {                                                # validation.py:959-963
        "stage": stage,
        "prior_ssp_path": f".cato/{target_uuid}/ssp.json",     # ← skill merges into prior state
        "fixture_scenario": self._CATO_STAGE_FIXTURE.get(stage, "")}   # ← BRANCH (inline .get default)
    try:
        result = await workflow.execute_activity(              # validation.py:965-985
            dispatch_agent_task,
            AgentTaskInput(
                task_type=f"validation-cato-{stage.lower()}",
                app_id=app_id, skill_id="cato-compliance",
                input_artifacts=input_artifacts,
                artifact_repo=repo, artifact_ref=branch, workspace_key=workspace_key,
                context=context,
                execution_context=self._execution_ctx(
                    f"cato-evidence-{stage.lower()}", app_id=app_id,
                    input_artifact_paths=input_artifacts)),
            start_to_close_timeout=timedelta(hours=1),          # ← 1h, agent_failure
            retry_policy=RETRY_POLICIES["agent_failure"],
            activity_id=f"cato-evidence-{stage.lower()}")
    except Exception as exc:                                   # validation.py:986  BRANCH 1 (dispatch fail → return)
        workflow.logger.warning(
            "cato-compliance dispatch failed at %s (non-fatal): %s", stage, exc)   # validation.py:987-991
        return                                                 # validation.py:992

    output_files = result.output_files or []                   # validation.py:994
    if not output_files:                                       # validation.py:995  BRANCH 2 (no files → return)
        return                                                 # validation.py:996

    def _normalize(path):                                      # validation.py:1003  (inner)
        if path.startswith(".cato/"):                          # validation.py:1004  BRANCH 3
            parts = path.split("/", 2)
            if len(parts) == 3:                                # validation.py:1006  BRANCH 4
                return f".cato/{target_uuid}/{parts[2]}"        # ← rewrite uuid segment
        return path                                            # validation.py:1008

    batch = [(_normalize(f.path), f.content)
             for f in output_files if f.path]                  # validation.py:1010-1012  BRANCH 5 (if f.path)
    committed = [p for p, _ in batch]                          # validation.py:1013
    try:
        await workflow.execute_activity(                       # validation.py:1015-1033
            write_artifacts_batch,
            WriteArtifactsBatchInput(
                repo=repo, branch=branch, files=batch,
                commit_message=f"cato({app_id}): {stage} evidence [{workflow.info().workflow_id}]",
                execution_context=self._execution_ctx(f"commit-cato-{stage.lower()}", app_id=app_id)),
            start_to_close_timeout=timedelta(seconds=120),      # ← 120s, transient
            retry_policy=RETRY_POLICIES["transient"],
            activity_id=f"commit-cato-{stage.lower()}")
    except Exception as exc:                                   # validation.py:1034  BRANCH 6 (commit fail → return)
        workflow.logger.warning(
            "cato evidence commit failed at %s (non-fatal): %s", stage, exc)   # validation.py:1035-1039
        return                                                 # validation.py:1040
    self._cato_paths[stage] = committed                        # validation.py:1041  ← RECORD committed paths
    self._cato_highest_stage = stage                           # validation.py:1042  ← last stage wins
    evidence_records = [f.content for f in output_files
                        if "/evidence/" in (f.path or "")]      # validation.py:1046-1050  BRANCH 7 (if "/evidence/")
    if evidence_records:                                       # validation.py:1051  BRANCH 8
        self._cato_evidence_records = evidence_records         # validation.py:1052
    workflow.logger.info("cato evidence committed at %s", stage,
        extra={"app_id": app_id, "paths": len(committed)})     # validation.py:1053-1057
```

**Branch inventory: 8** (inline `.get(stage,"")` fixture lookup 962; dispatch `except` 986; `if not
output_files` 995; `_normalize` `if path.startswith(".cato/")` 1004; `_normalize` `if len(parts)==3`
1006; batch comprehension `if f.path` 1011; evidence comprehension `if "/evidence/"` 1049; `if
evidence_records` 1051). Plus the two list comprehensions (batch 1010, evidence 1046).

> ⚠️ **GOTCHA-CATO-BESTEFFORT (NEW — cATO is fully non-fatal at THREE return points):** (a) dispatch
> failure (`validation.py:986-992`) → warn + return (does NOT set `_cato_paths`); (b) empty
> `output_files` (`validation.py:995-996`) → return; (c) commit failure (`validation.py:1034-1040`)
> → warn + return (does NOT set `_cato_paths`/`_cato_highest_stage`/`_cato_evidence_records`). In all
> three early-return cases the stage gets NO `_cato_paths[stage]` entry, so the downstream evidence
> union (`_cato_paths.get(stage, [])`) and the persist ternary (`if self._cato_paths.get("G-Vx")`)
> see nothing for that stage. A rebuild MUST make every cATO failure non-fatal — the gate proceeds
> on stream outputs alone. ⚠️ This is the single biggest behavioral addition vs. the old baseline.
> ⚠️ **GOTCHA-CATO-PATHNORMALIZE (`.cato/{uuid}/` rewrite, NOT `validation/{app}/files/...`):** the
> committed cATO files are written at their LITERAL `.cato/{uuid}/...` paths (artifact-repo-root
> relative), NOT under the `validation/{app_id}/files/...` prefix the stream commit helper uses
> (`validation.py:940-948`). `_normalize` rewrites the uuid segment of any `.cato/<some-uuid>/rest`
> path to `.cato/{target_uuid}/rest` (so the layout is stable per application); a live runtime that
> already emits the right uuid gets a no-op, and a path NOT starting with `.cato/` or without exactly
> 3 `/`-split parts passes through unchanged. A rebuild MUST commit via `write_artifacts_batch` with
> the raw `.cato/` paths and the `_normalize` uuid-rewrite, NOT route through `_commit_step_artifacts`.
> ⚠️ **GOTCHA-CATO-PRIORSSP (`context["prior_ssp_path"]` always points at the SSP):** every stage's
> dispatch context carries `prior_ssp_path = f".cato/{target_uuid}/ssp.json"` (`validation.py:961`),
> even G-V1 (where the SSP doesn't exist yet — the skill creates it). This is how the skill merges
> into prior OSCAL state instead of regenerating (SKILL.md §Anti-Patterns; design Risk R-2). A
> rebuild must always thread this exact context key.
> ⚠️ **GOTCHA-CATO-EVIDENCERECORDS (`/evidence/` substring filter):** `_cato_evidence_records` is
> set to the `.content` of every output file whose path contains the substring `"/evidence/"`
> (`validation.py:1046-1050`). These raw JSON strings are threaded to `persist_validation_side_effects`
> as `control_evidence_json` (json-dumped) so it can build `metadata.compliance.controls` WITHOUT
> re-reading Git. Note it only OVERWRITES when `evidence_records` is non-empty (`validation.py:1051`)
> — a stage with no `evidence/` files leaves the prior stage's records intact (G-V2 emits the
> `evidence/` bundle; G-V1/G-V3 may not). A rebuild must use the `/evidence/` substring match and
> the non-empty-guard overwrite.
> ⚠️ **GOTCHA-CATO-ACTIVITYIDS (stable per-stage activity ids):** dispatch uses
> `activity_id=f"cato-evidence-{stage.lower()}"` and commit uses
> `activity_id=f"commit-cato-{stage.lower()}"` (`validation.py:984/1032`) — e.g. `cato-evidence-g-v1`,
> `commit-cato-g-v2`. The `task_type` is `f"validation-cato-{stage.lower()}"`. These are
> replay-stable. A rebuild MUST use these exact id/task_type shapes.

---

### 5.6 `_parity_meets_threshold(self) -> bool` (`validation.py:1063-1094`) — G-V1 verdict, 6 BRANCHES (5 default-True escapes + final compare)

Parses the first `functional-parity` output artifact, extracts a parity score, compares to the
tier threshold. **Defaults to True at every uncertainty** so the mock-agent happy path passes
without a full parity-report.

```text
def _parity_meets_threshold(self):
    raw = self._first_output("functional-parity")             # validation.py:1073
    if not raw:                                               # validation.py:1074  BRANCH 1 → True
        return True
    try:
        import json                                           # validation.py:1078  (local import)
        start = raw.find("{")                                 # validation.py:1079
        end = raw.rfind("}")                                  # validation.py:1080
        if start == -1 or end <= start:                       # validation.py:1081  BRANCH 2 → True
            return True
        report = json.loads(raw[start : end + 1])             # validation.py:1083
    except Exception:                                         # validation.py:1084  BRANCH 3 → True
        return True
    if not isinstance(report, dict):                          # validation.py:1086  BRANCH 4 → True
        return True
    score = report.get("parity_score") or report.get("score") # validation.py:1088
    if not isinstance(score, (int, float)):                   # validation.py:1089  BRANCH 5 → True
        return True
    threshold = PARITY_THRESHOLDS.get(self._risk_tier, PARITY_THRESHOLDS[None])   # validation.py:1091-1093
    return float(score) >= threshold                          # validation.py:1094  ★FINAL COMPARE
```

**Branch inventory: 6** (no-raw 1074; brace-find fail 1081; json parse except 1084; non-dict 1086;
non-numeric score 1089; final `>= threshold` 1094).

> ⚠️ **GOTCHA-PARITY-DEFAULTTRUE (5 escape hatches all return True):** EVERY failure to extract a
> numeric score returns `True` (pass). This is deliberate (`validation.py:1066-1072`): the standard
> mock-agent path emits no parity score, so tests exercise the happy path without a full report. A
> rebuild MUST default to True on: empty output, no valid JSON braces, JSON parse error, non-dict
> payload, non-numeric score. ONLY a present-and-numeric score below threshold returns False.
> ⚠️ **GOTCHA-PARITY-SCOREKEY (`parity_score` OR `score`):** the score is
> `report.get("parity_score") or report.get("score")` (`validation.py:1088`) — tries `parity_score`
> first, falls back to `score`. The `or` means a `parity_score` of `0` (falsy) would fall through
> to `score` — but a 0 parity score is then re-checked by `isinstance(..., (int,float))` and would
> compare `0.0 >= threshold` → False (auto-reject). A rebuild must use this exact `or` fallback.
> ⚠️ **GOTCHA-PARITY-BRACE (substring JSON extraction):** the parser extracts `raw[first"{" :
> last"}"+1]` (`validation.py:1079-1083`) to tolerate prose around the JSON (parity-report "may carry
> prose"). `end <= start` (not `<`) guards the empty/degenerate case. A rebuild must do find/rfind
> brace extraction, not `json.loads(raw)` directly.
> ⚠️ **GOTCHA-PARITY-THRESHOLD (`.get(tier, [None])` fallback):** threshold lookup is
> `PARITY_THRESHOLDS.get(self._risk_tier, PARITY_THRESHOLDS[None])` (`validation.py:1091-1093`) — if
> the tier int isn't a key (only 1/2/3/None are), fall back to the `None` entry (98.0). Since tiers
> are constrained to {1,2,3,None} this is belt-and-suspenders, but reproduce it.
> ⚠️ **GOTCHA-PARITY-DETERMINISM (`import json` inside the method is fine):** the local `import json`
> (`validation.py:1078`) is a deterministic stdlib import; it does not violate Temporal sandbox
> rules (json is pure). It shadows the module-level `import json` (validation.py:64) harmlessly. A
> rebuild may use the module import instead with no behavioral change.

---

### 5.7 `_first_output(self, step_name) -> str` (`validation.py:1096-1099`) and `_progress_at(self, step_name) -> float` (`validation.py:1101-1112`)

`_first_output` (1 inline branch):
```text
outputs = self._step_results.get(step_name, [])              # validation.py:1098
return outputs[0] if outputs else ""                         # validation.py:1099  BRANCH (inline)
```

`_progress_at` (1 loop + break):
```text
total = 0.0                                                  # validation.py:1107
for name, weight in STEP_WEIGHTS.items():                    # validation.py:1108  LOOP
    total += weight                                          # validation.py:1109
    if name == step_name:                                    # validation.py:1110  BRANCH
        break                                                # validation.py:1111
return min(total, 100.0)                                     # validation.py:1112
```

> ⚠️ **GOTCHA-PROGRESS (cumulative sum in dict-insertion order, capped at 100):** `_progress_at`
> sums `STEP_WEIGHTS` values in insertion order through the named step INCLUSIVE, then caps at
> 100.0. It relies on the dict ordering of §0.4. If `step_name` isn't found the loop sums ALL
> weights (=100.0). A rebuild MUST preserve the exact `STEP_WEIGHTS` key order and the
> sum-through-inclusive + `min(.,100.0)` semantics, or every `_set_step` progress value diverges.

---

### 5.8 `_fire_validation_approved_signal(self, input, app_id) -> None` (`validation.py:1114-1173`) — cross-workflow signal, 3 BRANCHES + 1 loop

Emits `ValidationApprovedSignal` to the peer Deployment workflow. Best-effort: skips if no peer id;
swallows signal-send failures.

```text
async def _fire_validation_approved_signal(self, input, app_id):
    deployment_wf_id = ""
    try:
        deployment_wf_id = input.peer_workflow_ids.get("Deployment", "")   # validation.py:1131
    except AttributeError:                                    # validation.py:1132  BRANCH 1
        deployment_wf_id = ""                                 # validation.py:1133

    output_refs = []
    for step_name in ("functional-parity", "security-compliance",
                      "accessibility-ux", TIER1_STEP):        # validation.py:1136-1141  LOOP
        output_refs.extend(self._step_committed_paths.get(step_name, []))   # validation.py:1142-1144
    output_refs = dedup_paths(output_refs)                    # validation.py:1145

    payload = ValidationApprovedSignal(                       # validation.py:1147-1155
        target_app_id=app_id, portfolio_id=input.portfolio_id,
        validation_output_refs=output_refs, approved_at=_now_iso(),
        risk_tier=(str(self._risk_tier) if self._risk_tier is not None else ""))   # validation.py:1152-1154  BRANCH 2 (inline)

    if not deployment_wf_id:                                  # validation.py:1157  BRANCH 3 (skip)
        workflow.logger.info(
            "validation-approved signal skipped — no peer Deployment workflow id on input",
            extra={"target_app_id": app_id})                  # validation.py:1158-1162
        return                                                # validation.py:1163

    try:
        handle = workflow.get_external_workflow_handle(deployment_wf_id)   # validation.py:1166
        await handle.signal("validation_approved", payload)   # validation.py:1167
    except Exception as exc:                                  # validation.py:1168  BRANCH 4 (best-effort)
        workflow.logger.warning(
            "validation-approved signal failed — Deployment workflow may not yet be "
            "started: %s", exc)                               # validation.py:1169-1173
```

**Branch inventory: 4** (`except AttributeError` 1132; the `risk_tier` inline ternary 1153; `if not
deployment_wf_id` 1157; outer `except Exception` 1168). Plus the output-ref accumulation loop (1136).

> ⚠️ **GOTCHA-SIGNAL-OUTPUTREFS (output refs = union of all 4 streams' COMMITTED paths):** the
> signal's `validation_output_refs` is the deduped union of `_step_committed_paths` for
> functional-parity + security-compliance + accessibility-ux + safety-assurance (`validation.py:1136-1145`).
> For Tier-2/3, `safety-assurance` has no committed paths so it contributes nothing (the `.get(...,[])`
> default). ⚠️ Note this does NOT include cATO paths — only the four stream `_step_committed_paths`.
> A rebuild must iterate all four step names in this exact order and dedup.
> ⚠️ **GOTCHA-SIGNAL-RISKTIER-NONE (`is not None`, not truthiness):** the payload `risk_tier` uses
> `str(self._risk_tier) if self._risk_tier is not None else ""` (`validation.py:1152-1154`) — `is
> not None`, distinct from the step-17 persist call's truthiness check (GOTCHA-PERSIST-TERNARIES).
> Practically identical for {1,2,3,None} but the rebuild must match `is not None` here.
> ⚠️ **GOTCHA-SIGNAL-WIRENAME (`"validation_approved"`):** the cross-workflow signal is sent under
> the literal name `"validation_approved"` (`validation.py:1167`) — this is the handler name
> Deployment must register. A rebuild must use this exact string.
> ⚠️ **GOTCHA-SIGNAL-BESTEFFORT (two swallow points):** (a) `input.peer_workflow_ids` may be absent
> (`AttributeError` → empty id → skip with info log, validation.py:1132/1157); (b) the signal send
> itself may fail if Deployment isn't started yet (`except Exception` → warn, validation.py:1168).
> Neither fails the workflow — Validation completes regardless. Unit tests + standalone runs commonly
> lack a peer (`validation.py:1126-1128`). A rebuild MUST make signal emission non-fatal.

---

### 5.9 `_fail(self, reason_step, app_id) -> str` (`validation.py:1175-1183`) — clean terminal failure, NO branches

```text
async def _fail(self, reason_step, app_id):
    self._status = WorkflowStatus.FAILED                      # validation.py:1177
    self._current_step = reason_step                          # validation.py:1178
    self._updated_at = _now_iso()                             # validation.py:1179
    await self._update_app_status(app_id, "validation_failed", reason_step, "Validation")   # validation.py:1180-1182
    return "failed"                                           # validation.py:1183
```

> ⚠️ **GOTCHA-FAIL (returns, does NOT raise):** `_fail` is the rework-exhaustion path. It sets
> `FAILED` status, projects `validation_failed`, and RETURNS `"failed"` (not raises). The callers
> (`return await self._fail(...)` at validation.py:460/471/563/706) propagate that return up through
> `_execute_validation` → `run()`, which returns it as the workflow result string WITHOUT entering
> `run()`'s outer except (no exception is raised). Contrast GOTCHA-RUN2: a real exception path
> marks FAILED AND raises. A rebuild must keep `_fail` as a return-path. The `reason_step` values
> are the four literals `"max-rework-exceeded-gv1"` / `"...gv2"` / `"...gv3"`.

---

## 6. PR BODY BUILDERS (`validation.py:1189-1292`) — 3 builders, 1 conditional each (+ G-V2 nested)

These build markdown PR bodies; passed to `_create_gate_pr(body=...)`. Pure string assembly. Each
appends a rework-iteration footer when `_rework_count(gate) > 0`.

### 6.1 `_build_gv1_pr_body(self, app_id) -> str` (`validation.py:1189-1220`) — 1 branch
```text
rework_iter = self._rework_count("G-V1")                     # validation.py:1191
threshold = PARITY_THRESHOLDS.get(self._risk_tier, PARITY_THRESHOLDS[None])   # validation.py:1192-1194
body = (... "## Gate G-V1 Review: Functional Parity ..."
        f"**Risk tier:** {self._risk_tier or 'unclassified'} ..."   # validation.py:1198  (inline `or`)
        f"**Parity threshold:** ≥ {threshold}% ...")          # ... validation.py:1195-1217
if rework_iter > 0:                                          # validation.py:1218  BRANCH
    body += f"\n**Rework iteration:** {rework_iter}\n"        # validation.py:1219
return body                                                  # validation.py:1220
```
Note `{self._risk_tier or 'unclassified'}` (`validation.py:1198`) — None/0 → `"unclassified"`.

### 6.2 `_build_gv2_pr_body(self, app_id) -> str` (`validation.py:1222-1263`) — 3 branches
```text
rework_iter = self._rework_count("G-V2")                     # validation.py:1224
body = "## Gate G-V2 Review: Compliance & Security ...\n**Application:** {app_id}\n"   # validation.py:1225-1228
if self._risk_tier is not None:                              # validation.py:1229  BRANCH 1
    body += f"**Risk tier:** {self._risk_tier}\n"            # validation.py:1230
    if self._risk_tier == 1:                                 # validation.py:1231  BRANCH 2 (nested)
        body += "\n> **Tier-1:** Approval requires PM merge AND "
                "`scope=\"g-v2-compliance\"` ... AND `scope=\"g-v2-security\"` ...\n"   # validation.py:1232-1236
body += (... streams + artifacts + compliance/security checklist ...)   # validation.py:1237-1260
if rework_iter > 0:                                          # validation.py:1261  BRANCH 3
    body += f"\n**Rework iteration:** {rework_iter}\n"        # validation.py:1262
return body                                                  # validation.py:1263
```

### 6.3 `_build_gv3_pr_body(self, app_id) -> str` (`validation.py:1265-1292`) — 1 branch
```text
rework_iter = self._rework_count("G-V3")                     # validation.py:1267
body = ("## Gate G-V3 Review: Safety Assurance (Tier-1) ... **Risk tier:** 1 (safety-critical) ..."
        "> **Tier-1 triple-signal.** Approval requires PM merge AND "
        "`scope=\"g-v3-safety\"` ... AND `scope=\"g-v3-cert\"` ...")   # validation.py:1268-1289
if rework_iter > 0:                                          # validation.py:1290  BRANCH
    body += f"\n**Rework iteration:** {rework_iter}\n"        # validation.py:1291
return body                                                  # validation.py:1292
```

> ⚠️ **GOTCHA-PRBODY (bodies document the gate contract — keep the scope strings):** the G-V2/G-V3
> bodies embed the literal stakeholder scope strings (`"g-v2-compliance"` etc.) as human-readable
> approval requirements. These mirror the `stakeholder_approved` wire scopes (§4.1). A rebuild
> should reproduce them for reviewer fidelity, but they are documentary text, not load-bearing for
> routing. The rework-iteration footer IS surfaced to reviewers — preserve the `if rework_iter > 0`
> guard so a fresh (count 0) PR has no footer.

---

## 7. ACTIVITY & CHILD-WORKFLOW CALLS (full inventory, in execution order)

Validation spawns NO child workflows. All work is activities (via base helpers or direct). In
canonical Tier-1 order (cATO calls ⓝ NEW):

| # | Activity | Caller / line | Args (shape) | Timeout | Retry policy | activity_id | non_retryable |
|---|----------|---------------|--------------|---------|-------------|-------------|---------------|
| 1 | `update_application_status` | `_set_step` (intake) | `UpdateAppStatusInput("validation_in_progress",...)` | 30s | `transient` | — | — |
| 2-7 | `dispatch_agent_task` ×3 | `_run_parallel_streams._dispatch_agent` | `AgentTaskInput(task_type="validation-{step}",...)` | 1h | `agent_failure` | `agent-{step}` | — |
| | `write_artifacts_batch` ×3 | `_commit_step_artifacts` | `WriteArtifactsBatchInput(...)` | 120s | `transient` | `commit-{step}` | — |
| ⓝ7a | `dispatch_agent_task` (cATO G-V1) | `_dispatch_cato_evidence:965` | `AgentTaskInput(task_type="validation-cato-g-v1", skill_id="cato-compliance", context={stage,prior_ssp_path,fixture_scenario})` | 1h | `agent_failure` | `cato-evidence-g-v1` | — (best-effort) |
| ⓝ7b | `write_artifacts_batch` (cATO G-V1) | `_dispatch_cato_evidence:1015` | `WriteArtifactsBatchInput(.cato/{uuid}/... paths)` | 120s | `transient` | `commit-cato-g-v1` | — (best-effort) |
| 8 | `create_pr` (G-V1) | `_create_gate_pr` | `CreatePRInput(target="main", labels=["gate-review","validation","G-V1"])` | 60s | `transient` | — | — |
| 9 | `create_gate_record` (G-V1) | `_execute_validation:418` | `CreateGateRecordInput(gate_type="G-V1",...)` | **30s** | `transient` | — | — |
| 10 | `check_gate_criteria` (G-V1) | `_submit_gate_evidence` | `CheckGateCriteriaInput(...,risk_tier=...)` | 60s | `transient` | — | — |
| 11 | `submit_gate_evidence` (G-V1) | `_submit_gate_evidence` | `SubmitGateEvidenceInput(slim bundle)` | 60s | `transient` | — | — |
| 12 | `reconcile_and_merge_pr` (G-V1) | `_reconcile_and_merge_with_retry_loop` | `MergePRInput(merge_method="merge")` | 60s | **`git_merge`** | — | MergeConflict / MergeDivergenceUnresolved / MergeBranchProtectionRejected |
| | `set_gate_merge_blocked` (on merge error) | same | positional `args=[gate_id, detail]` | 30s | `transient` | — | — |
| 13 | `update_application_status` | `_execute_validation:484` | `"validation_parity_approved"` | 30s | `transient` | — | — |
| ⓝ13a | `dispatch_agent_task` (cATO G-V2) + `write_artifacts_batch` (cATO G-V2) | `_dispatch_cato_evidence:495` | `task_type="validation-cato-g-v2"` | 1h / 120s | `agent_failure` / `transient` | `cato-evidence-g-v2` / `commit-cato-g-v2` | — (best-effort) |
| 14 | `create_pr` (G-V2) | `_create_gate_pr` | labels `[...,"G-V2"]` | 60s | `transient` | — | — |
| 15 | `create_gate_record` (G-V2) | `_execute_validation:519` | `gate_type="G-V2"` | 30s | `transient` | — | — |
| 16 | `check_gate_criteria` + `submit_gate_evidence` (G-V2) | `_submit_gate_evidence` | — | 60s ea | `transient` | — | — |
| 17 | `dispatch_agent_task` (pre-review G-V2) | `_run_gate_pre_review` | `AgentTaskInput(skill_id="gate-pre-review")` | **10m** | `transient` | — | — |
| | `store_gate_pre_review` (if output) | same | `StoreGatePreReviewInput` | 30s | `transient` | — | — |
| | `mark_gate_ready_for_review` (finally, patch-gated) | same | positional `gate_id` | 30s | `transient` | — | — |
| 18 | `reconcile_and_merge_pr` (G-V2) | merge helper | `MergePRInput` | 60s | `git_merge` | — | (3 merge types) |
| 19 | `update_application_status` | `_execute_validation:590` | `"validation_compliance_approved"` | 30s | `transient` | — | — |
| **Tier-1 only:** | | | | | | | |
| 20 | `dispatch_agent_task` (safety) | `_run_safety_stream._dispatch_agent` | `task_type="validation-safety-assurance"` | 1h | `agent_failure` | `agent-safety-assurance` | — |
| | `write_artifacts_batch` (safety) | `_commit_step_artifacts` | — | 120s | `transient` | `commit-safety-assurance` | — |
| ⓝ20a | `dispatch_agent_task` (cATO G-V3) + `write_artifacts_batch` (cATO G-V3) | `_dispatch_cato_evidence:634` | `task_type="validation-cato-g-v3"` | 1h / 120s | `agent_failure` / `transient` | `cato-evidence-g-v3` / `commit-cato-g-v3` | — (best-effort) |
| 21 | `create_pr` (G-V3) | `_create_gate_pr` | labels `[...,"G-V3"]` | 60s | `transient` | — | — |
| 22 | `create_gate_record` (G-V3) | `_execute_validation:659` | `gate_type="G-V3"` | 30s | `transient` | — | — |
| 23 | `check_gate_criteria` + `submit_gate_evidence` (G-V3) | `_submit_gate_evidence` | — | 60s ea | `transient` | — | — |
| 24 | `dispatch_agent_task` (pre-review G-V3) + `store_gate_pre_review` + `mark_gate_ready_for_review` | `_run_gate_pre_review` | — | 10m/30s/30s | `transient` | — | — |
| **Both tiers:** | | | | | | | |
| 25 | `persist_validation_side_effects` | `_execute_validation:746` | `PersistValidationSideEffectsInput(... +6 cATO fields ⓝ)` | **60s** | `transient` | `persist-validation-side-effects` | — (wrapped in best-effort try/except) |
| 26 | `reconcile_and_merge_pr` (final, **Tier-1 only**) | merge helper | `MergePRInput`, gate_id=gv3_record | 60s | `git_merge` | — | (3 merge types) |
| 27 | external `handle.signal("validation_approved", payload)` | `_fire_validation_approved_signal` | `ValidationApprovedSignal` | — | (best-effort try/except) | — | — |
| 28 | `update_application_status` | `_execute_validation:812` | `"validation_complete"` | 30s | `transient` | — | — |

Plus the patch-gated activities inside `_commit_step_artifacts` (`update_agent_task_output_ref`,
30s/`transient`/`patch-output-ref-{step}`, under `patched("patch-output-artifact-ref-v1")`) and the
context-priors load inside `_dispatch_agent` (`load_context_priors`, under
`patched("context-priors-v1")`) — see `_LineWorkflowBase.md` §8-9.

> ⚠️ **GOTCHA-DIRECT-CALLS (the direct activity calls in the subclass are `create_gate_record` ×3,
> `persist_validation_side_effects` ×1, and ⓝ the cATO `dispatch_agent_task` + `write_artifacts_batch`
> ×3 each inside `_dispatch_cato_evidence`):** all OTHER activities go through base helpers. The
> three `create_gate_record` calls use **30s** timeout + `transient` (`validation.py:418-428 /
> 519-529 / 659-669`); `persist_validation_side_effects` uses **60s** + `transient` +
> `activity_id="persist-validation-side-effects"` (`validation.py:780-782`); the cATO dispatches use
> **1h** + `agent_failure` (`validation.py:982-983`) and the cATO commits use **120s** + `transient`
> (`validation.py:1030-1031`). A rebuild must reproduce these exact timeouts/policies/ids.

---

## 8. GATE HANDLING SUMMARY (the three gates, their routing, and the rework loop)

| Gate | Type | Steps | Approval condition | Rework key | On reject |
|------|------|-------|--------------------|-----------|-----------|
| **G-V1** | automated parity | 5-7 | `_parity_meets_threshold()` True THEN `_wait_for_gate_decision`→`"approved"` (PM ack) | `"G-V1"` | `_bump_rework("G-V1")`; if count>3 `_fail`; else `continue` LOOP-A |
| **G-V2** | triple-signal (Tier-1) / PM-only (T2/T3) | 8-11 | `_wait_for_gate_decision`→`"approved"` THEN (Tier-1: wait compliance+security signals) | `"G-V2"` | `_bump_rework("G-V2")`; if count>3 `_fail`; else `continue` LOOP-A |
| **G-V3** | triple-signal (Tier-1 only) | 12-16 | `_wait_for_gate_decision`→`"approved"` THEN wait safety+cert signals | `"G-V3"` | `_bump_rework("G-V3")`; if count>3 `_fail`; else RESET safety/cert flags + `continue` LOOP-B |

**Evidence assembly per gate (⚠️ NOW UNIONS cATO PATHS — changed from old baseline):**
- G-V1: dedup(`_step_committed_paths["functional-parity"]` + `_cato_paths.get("G-V1", [])`)
  (`validation.py:403-406`, `434`).
- G-V2: dedup(`security-compliance` + `accessibility-ux` committed paths + `_cato_paths.get("G-V2", [])`)
  (`validation.py:503-507`).
- G-V3: dedup(`safety-assurance` committed paths + `_cato_paths.get("G-V3", [])`)
  (`validation.py:642-645`, `675`).

**The wait (per gate):** `await self._wait_for_gate_decision(GateType.G_Vx)` (base) — sets
`WAITING_FOR_SIGNAL` + `_pending_gate`, blocks on `len(_gate_decisions) > consumed or
self.cancelled`, returns `"approved"`/`"rejected"`/`"cancelled"`, and on reject stores
`_rework_feedback["G-Vx"]` (forwarded into next stream dispatch via `_dispatch_agent`).

**merge_blocked routing:** all merges go through `_reconcile_and_merge_with_retry_loop` (base)
— on a structured merge error (`MergeConflict`/`MergeDivergenceUnresolved`/
`MergeBranchProtectionRejected`) the gate transitions to `merge_blocked` and waits for a
`merge_retry` signal; cancel exits the loop cleanly.

**Triple-signal routing (Tier-1 only):**
- G-V2 (`validation.py:570-582`): after PM approval, `wait_condition(compliance AND security OR
  cancelled)`; on cancel → `CANCELLED`, return `"cancelled"`; else merge.
- G-V3 (`validation.py:717-728`): after PM approval, `wait_condition(safety AND cert OR
  cancelled)`; on cancel → `CANCELLED`, return `"cancelled"`; else set `final_pr=gv3_pr`, break.

> ⚠️ **GOTCHA-GATE-ORDER (G-V1 auto-reject is checked BEFORE the PM wait; triple-signal waits are
> AFTER the PM approval):** the ordering matters for replay determinism and for which signals must
> arrive when. G-V1: parity check → (if pass) PM wait. G-V2/G-V3 (Tier-1): PM wait → (if approved)
> stakeholder-signal wait. A reviewer must merge the PR (→ `gate_approved` signal) BEFORE the
> stakeholder scope signals are consumed. A rebuild must preserve this two-phase order for Tier-1
> gates.

---

## 9. RESILIENCE

- **Timeouts:** `create_gate_record` 30s; `persist_validation_side_effects` 60s; cATO dispatch 1h /
  cATO commit 120s (ⓝ); all base-helper activities per `_LineWorkflowBase.md` (dispatch 1h, commit
  120s, create_pr 60s, gate criteria/evidence 60s, pre-review dispatch 10m, merge 60s, status 30s).
- **Heartbeats:** none configured (relies on start_to_close timeouts).
- **continue-as-new:** none. The two `while True` loops (LOOP-A / LOOP-B) bound iterations via
  `MAX_REWORK_ITERATIONS` (3) — they cannot loop unbounded because the 4th bump trips `_fail`. No
  continue-as-new is needed because rework is capped.
- **Idempotency:** deterministic `activity_id`s (`agent-{step}`, `commit-{step}`,
  `cato-evidence-{stage}`, `commit-cato-{stage}`, `persist-validation-side-effects`); `_now_iso()`
  deterministic; gate decisions consumed via the cursor pattern (base). The three `create_gate_record`
  calls and `create_pr` calls have NO explicit `activity_id` — they are NOT replay-idempotent by id
  (Temporal dedups by event sequence on replay; a rebuild must not add an `activity_id` that would
  change history).
- **Compensation / rollback:** NONE. There is no rollback of committed artifacts or created PRs.
  Failure semantics:
  - **Stream failure** (`asyncio.gather`) → bubbles to `run()` outer except → `FAILED` +
    best-effort `validation_failed` projection + re-raise (GOTCHA-FANOUT1, GOTCHA-RUN2).
  - **cATO dispatch/commit failure** (ⓝ) → swallowed at three return points inside
    `_dispatch_cato_evidence`; the gate proceeds on stream outputs alone (GOTCHA-CATO-BESTEFFORT).
  - **Rework exhaustion** → `_fail(...)` returns `"failed"` cleanly (no raise; GOTCHA-FAIL).
  - **Cancel** (`self.cancelled`) → drains every gate/merge/stakeholder `wait_condition` to a
    `"cancelled"` return; gate-wait cancels set `_status=CANCELLED` inside the base helper, the two
    stakeholder waits set it explicitly (GOTCHA-CANCELRETURN).
  - **persist step failure** → swallowed, run completes (GOTCHA-PERSIST-BESTEFFORT).
  - **signal-emit failure** → swallowed, run completes (GOTCHA-SIGNAL-BESTEFFORT).
- **Best-effort Layer-B emission:** `_execution_ctx` returns `None` when `_portfolio_id` empty, so
  step_execution emission never blocks dispatch (base).

---

## 10. Behavioral parity checklist

A rebuilt `ValidationWorkflow` MUST satisfy ALL of the following:

1. `class ValidationWorkflow(LineWorkflowBase)`; classvars `ASSEMBLY_LINE=AssemblyLine.VALIDATION`,
   `ARTIFACT_ROOT="validation"`, `LINE_LABEL="Validation"`, `STATUS_PREFIX="validation"`,
   `STEPS=VALIDATION_STEPS`, `STEP_WEIGHTS` sums to 100.0. `SINGLE_GATE_KEY` unset (None).
2. `__init__` calls `super().__init__()` first, then sets the 4 stakeholder bool flags to `False`,
   `_stream_status` to `{s:"queued" for s in PARALLEL_STREAMS}`, `_stream_started_at`/
   `_stream_completed_at` to `{}`, `_safety_case_ref` to `""`, AND ⓝ `_cato_paths={}`,
   `_cato_target_uuid=""`, `_cato_evidence_records=[]`, `_cato_highest_stage=""`.
3. Module tables EXACT: `VALIDATION_STEPS` (4 agent steps, each with a `skills` LIST + `artifact` +
   `title`, no `skill_id`); `PARALLEL_STREAMS=["functional-parity","security-compliance",
   "accessibility-ux"]` (order matters); `TIER1_STEP="safety-assurance"`;
   `MAX_REWORK_ITERATIONS=3`; `PARITY_THRESHOLDS={1:99.0,2:98.0,3:95.0,None:98.0}`; `STEP_WEIGHTS`
   in the exact insertion order of §0.4; ⓝ `_CATO_STAGE_FIXTURE={"G-V1":"ssp-g-v1","G-V2":"sar-g-v2",
   "G-V3":"poam-g-v3"}` (class-level).
4. OVERRIDES exactly: `_primary_skill_for_step` (→ `skills[0]`), `_evidence_step_metadata`
   (→ `{title,skills,artifact}`), `_rework_gate_key_for_step` (the 4-branch step→gate map), and
   defines `run`/`_execute_validation`. Does NOT redefine `gate_approved`/`gate_rejected`/
   `escalation_resolved`/`merge_retry`/`get_status`.
5. `_rework_gate_key_for_step`: `functional-parity→"G-V1"`; `{security-compliance,accessibility-ux}
   →"G-V2"`; `safety-assurance→"G-V3"`; else `None`. (GOTCHA-RG1)
6. NEW signal `stakeholder_approved` (async, `@workflow.signal`): routes scope
   `"g-v2-compliance"`/`"g-v2-security"`/`"g-v3-safety"`/`"g-v3-cert"` to the four flags; unknown
   → warn; ALWAYS bumps `_updated_at`. (GOTCHA-SH1..4)
7. `run()`: sets `RUNNING`/`_started_at`/`_updated_at`; `_risk_tier=int(input.risk_tier) if not
   None else None`; `is_tier_1 = _risk_tier==1`; `run_suffix=wf_id.rsplit("-",1)[-1] if "-" in
   wf_id else wf_id[:8]`; `branch=f"olympus/validation/{app_id}/{run_suffix}"`;
   `workspace_key=f"validation-{app_id}-{run_suffix}"`; `repo=target_repo_url or artifact_repo`;
   delegates to `_execute_validation` in a try; on ANY exception sets `FAILED`/`"failed"`,
   best-effort projects `validation_failed`, re-raises. (GOTCHA-RUN1/RUN2)
8. Step 1: `_set_step("intake", STEP_WEIGHTS["intake"])`.
9. LOOP-A (`while True`) runs steps 2-11: `_run_parallel_streams`; ⓝ `_dispatch_cato_evidence(G-V1,
   inputs=security-compliance committed)`; G-V1 evidence = dedup(functional-parity committed +
   `_cato_paths["G-V1"]`); create/submit G-V1; step 7 — **if `not _parity_meets_threshold()`** bump
   G-V1 rework, fail if count>3, else `continue` (NO PM wait); else `_wait_for_gate_decision(G_V1)` →
   cancel→return `"cancelled"`, rejected→bump/fail-or-`continue`, approved→
   `_reconcile_and_merge_with_retry_loop` + `update_app_status("validation_parity_approved")`; ⓝ
   `_dispatch_cato_evidence(G-V2, inputs=dedup(security-compliance committed + `_cato_paths["G-V1"]`))`;
   G-V2 evidence = dedup(security-compliance + accessibility-ux committed + `_cato_paths["G-V2"]`);
   create/submit/pre-review G-V2; step 11 `_wait_for_gate_decision(G_V2)` → cancel→`"cancelled"`,
   rejected→bump/fail-or-`continue`, approved→**if Tier-1** wait(compliance AND security OR
   cancelled)+cancel-check→merge+`update_app_status("validation_compliance_approved")`+`break`.
   (GOTCHA-V1AUTO, V1CONT, V2RESET, REWORKCAP, CANCELRETURN, CATO-ORDER, CATO-FEEDFORWARD)
10. `final_pr=gv2_pr` after LOOP-A. **If `is_tier_1`:** LOOP-B (`while True`) runs steps 12-16:
    `_run_safety_stream`(dedup(priors+3 stream commits, NO cATO)); set `_safety_case_ref`; ⓝ
    `_dispatch_cato_evidence(G-V3, inputs=dedup(safety committed + `_cato_paths["G-V2"]`))`; G-V3
    evidence = dedup(safety committed + `_cato_paths["G-V3"]`); create/submit/pre-review G-V3; step
    16 `_wait_for_gate_decision(G_V3)` → cancel→`"cancelled"`, rejected→bump/fail-or-(RESET safety+
    cert flags THEN `continue`), approved→wait(safety AND cert OR cancelled)+cancel-check→
    `final_pr=gv3_pr`+`break`.
11. Step 17: `_set_step`; gather `_first_output` for the 3 (Tier-1: 4) streams; `gv3_safety_json =
    _first_output(TIER1_STEP) if is_tier_1 else ""`; ⓝ `cato_uuid = _cato_target_uuid or app_id`;
    call `persist_validation_side_effects` (60s/`transient`/`activity_id="persist-validation-side-
    effects"`, `risk_tier=str(...) if _risk_tier else ""`, ⓝ `cato_target_uuid=cato_uuid`,
    `cato_stage=_cato_highest_stage`, `cato_ssp_path=f".cato/{cato_uuid}/ssp.json" if
    _cato_paths.get("G-V1") else ""`, `cato_sar_path=...G-V2...`, `cato_poam_path=...G-V3...`,
    `control_evidence_json=json.dumps(_cato_evidence_records) if _cato_evidence_records else ""`)
    wrapped in `try/except` that ONLY logs. (GOTCHA-PERSIST-*)
12. Step 18: `_set_step("merge-final-gate-pr")`; **if `is_tier_1`** merge `final_pr` with
    `gate_id=gv3_record.gate_id`; ALWAYS `_fire_validation_approved_signal`;
    `update_app_status("validation_complete","completed")`; set `COMPLETED`/`progress_pct=100.0`/
    `_current_step="completed"`; return `"completed"`. (GOTCHA-FINALPR)
13. `_run_parallel_streams`: `_set_step("functional-parity")`; mark all 3 streams "running" +
    started_at; inner `_run_stream` dispatches+commits each (sets `_step_results` and
    `_step_committed_paths`), marks "completed"/completed_at, or on exception marks "failed" + re-
    raise; `asyncio.gather` all three (first-exception-propagates); `_set_step("accessibility-ux")`
    after. (GOTCHA-FANOUT1..4)
14. `_run_safety_stream`: `_set_step(TIER1_STEP)`; dispatch+commit `safety-assurance`; sets
    `_step_results`/`_step_committed_paths`; no stream-status update; not self-wrapped (failure
    propagates). (GOTCHA-SAFETY-*)
15. ⓝ `_dispatch_cato_evidence(stage, inputs)`: sets `_cato_target_uuid=app_id`; builds context
    `{stage, prior_ssp_path=f".cato/{app_id}/ssp.json", fixture_scenario=_CATO_STAGE_FIXTURE.get(
    stage,"")}`; dispatch `cato-compliance` (task_type=`validation-cato-{stage.lower()}`, 1h/
    `agent_failure`/`activity_id=cato-evidence-{stage.lower()}`) in try/except→warn+return; if no
    `output_files`→return; `_normalize` each `.cato/<uuid>/rest` path to `.cato/{app_id}/rest`;
    `write_artifacts_batch` the batch (120s/`transient`/`activity_id=commit-cato-{stage.lower()}`,
    msg `cato({app}): {stage} evidence [{wf_id}]`) in try/except→warn+return; on success set
    `_cato_paths[stage]=committed`, `_cato_highest_stage=stage`, and (if any `/evidence/` files)
    `_cato_evidence_records=[those contents]`. (GOTCHA-CATO-BESTEFFORT, CATO-PATHNORMALIZE,
    CATO-PRIORSSP, CATO-EVIDENCERECORDS, CATO-ACTIVITYIDS)
16. `_parity_meets_threshold`: returns True on empty raw / no JSON braces / parse error / non-dict
    / non-numeric score; else `float(score) >= PARITY_THRESHOLDS.get(_risk_tier,
    PARITY_THRESHOLDS[None])`; score = `report.get("parity_score") or report.get("score")`; JSON
    extracted by first-`{`/last-`}` substring. (GOTCHA-PARITY-*)
17. `_first_output(step)` → `_step_results.get(step,[])[0]` or `""`. `_progress_at(step)` → sum of
    `STEP_WEIGHTS` in insertion order through `step` inclusive, capped at 100.0. (GOTCHA-PROGRESS)
18. `_fire_validation_approved_signal`: reads `input.peer_workflow_ids.get("Deployment","")` in
    try/`except AttributeError`; builds output_refs = dedup(union of 4 stream committed paths in
    order functional-parity, security-compliance, accessibility-ux, safety-assurance — NO cATO);
    payload `ValidationApprovedSignal(... risk_tier=str(_risk_tier) if not None else "")`; if no
    deployment id → info-log + return; else `get_external_workflow_handle(id).signal(
    "validation_approved", payload)` in try/`except Exception`→warn. (GOTCHA-SIGNAL-*)
19. `_fail(reason_step, app_id)`: sets `FAILED`/`_current_step=reason_step`/`_updated_at`;
    `update_app_status("validation_failed", reason_step)`; RETURNS `"failed"` (no raise). Reason
    strings: `"max-rework-exceeded-gv1"/"...gv2"/"...gv3"`. (GOTCHA-FAIL)
20. PR builders: G-V1 body uses `{_risk_tier or 'unclassified'}` + threshold; G-V2 body conditional
    `if _risk_tier is not None` then nested `if _risk_tier==1` Tier-1 note; G-V3 fixed Tier-1
    triple-signal note; each appends `**Rework iteration:** {n}` ONLY when `_rework_count(gate)>0`.
21. Gate types passed to `_create_gate_pr`/`create_gate_record` as `GateType.G_Vx.value` (STRING),
    to `_submit_gate_evidence`/`_wait_for_gate_decision` as the `GateType.G_Vx` ENUM. (matches base
    GOTCHA-GP1/SE4)
22. Three `create_gate_record` calls: 30s/`transient`, `CreateGateRecordInput(gate_type=G_Vx.value,
    app_id, portfolio_id, workflow_id=workflow.info().workflow_id, evidence_package_url=pr.pr_url)`.
23. NO child workflows; NO continue-as-new; rework bounded at 3 (4th bump → `_fail`); all merges via
    base `_reconcile_and_merge_with_retry_loop` (merge_blocked + `merge_retry` loop, `git_merge`
    policy); cancel drains all waits to `"cancelled"`.
24. Tier-2/Tier-3 path: skips the entire `if is_tier_1:` block (steps 12-16, INCLUDING the G-V3 cATO
    dispatch) AND the step-18 final merge; G-V2 was already merged in the approval branch; signal
    still emitted; safety + `cato_poam_path` fields empty.
25. ⓝ cATO is fully best-effort: every dispatch/commit failure inside `_dispatch_cato_evidence` is
    swallowed (warn + return) and never fails the gate; the gate evidence bundle still carries the
    stream outputs even if cATO emitted nothing. cATO paths are written at literal `.cato/{uuid}/`
    repo-root paths (NOT under `validation/{app}/files/`), unioned into each gate's evidence bundle,
    and projected into `metadata.compliance` via the persist activity's 6 cATO fields.
