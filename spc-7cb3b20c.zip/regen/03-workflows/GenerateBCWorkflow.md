# `GenerateBCWorkflow` — Per-Bounded-Context TDD Code Generation (Ralph Loop) — ATOMIC regeneration spec

> **Source of truth:** `temporal/olympus_workflows/workflows/generate_bc.py` (314 lines). Every
> `generate_bc.py:line` citation below is against that file.
>
> **What this is:** the **child workflow** spawned by `ModernizationWorkflow`'s Generate step,
> one per bounded context (BC), running up to `MAX_BC_CHILDREN_PER_APP` (=12) in parallel under a
> single app. It runs the **Ralph Loop** — write tests → generate code → run tests → iterate —
> for a single BC, escalating to a human when the loop exhausts `MAX_RALPH_ITERATIONS` (=10)
> without all tests passing. (Class docstring `generate_bc.py:1-19`; concurrency / iteration
> constants in `types.py:133-134`.)
>
> **Ralph-loop ENGINE internals** (how the agent skills write tests / generate code / run tests
> internally) are elaborated in Phase 7 (`13-generation-engine.md`). **This spec captures the
> WORKFLOW mechanics only**: state, signals/queries, the `run()` / `_handle_escalation()` control
> flow, and the activity calls in order. The four dispatches here are `dispatch_agent_task`
> activity calls — opaque from the workflow's point of view.

---

## 0. Class shape, inheritance, and what it OVERRIDES vs INHERITS

```text
@workflow.defn
class GenerateBCWorkflow(HILSignalsMixin):     # generate_bc.py:50-51
    def __init__(self) -> None: ...            # generate_bc.py:59-73
    @workflow.run
    async def run(self, input: GenerateBCInput) -> GenerateBCResult: ...   # generate_bc.py:75-190
    async def _handle_escalation(self, input, test_results, output_artifacts) -> GenerateBCResult  # 192-264
    @workflow.signal async def escalation_resolved(self, signal)  # 270-275
    @workflow.signal async def gate_approved(self, signal)        # 277-279
    @workflow.signal async def gate_rejected(self, signal)        # 281-283
    @workflow.signal async def wave_patterns_ready(self, signal)  # 285-287
    @workflow.query     def get_status(self) -> WorkflowStatusResponse  # 293-309

def _now_iso() -> str: return workflow.now().isoformat()   # generate_bc.py:312-313  (module-level)
```

> ⚠️ **GOTCHA-INHERIT (this extends `HILSignalsMixin` DIRECTLY, NOT `LineWorkflowBase`):**
> Unlike the seven per-app *line* workflows, `GenerateBCWorkflow` inherits from
> **`HILSignalsMixin`** (`generate_bc.py:51`), **not** `LineWorkflowBase`. Consequences a rebuild
> MUST honor:
> 1. It gets the **six** HIL signals from the mixin (`approve_plan`, `provide_plan_feedback`,
>    `approve_research`, `provide_feedback`, `approve`, `cancel_workflow`) and the eight HIL state
>    vars (`approved`, `plan_approved`, `cancelled`, …) — see `_HILSignalsMixin.md`. **`self.cancelled`
>    is the only inherited var this workflow actually reads** (in the escalation wait predicate,
>    `generate_bc.py:222,225`).
> 2. It does **NOT** inherit `LineWorkflowBase`'s `gate_approved` / `gate_rejected` /
>    `escalation_resolved` / `merge_retry` signals, nor `_wait_for_gate_decision`,
>    `_dispatch_agent`, `_commit_step_artifacts`, `_submit_gate_evidence`, `_set_step`, etc.
>    **It re-implements its own `gate_approved` / `gate_rejected` / `escalation_resolved` as
>    plain mixin-level signals** (`generate_bc.py:270-287`) — this is allowed precisely because it
>    does NOT inherit the base versions, so there is no duplicate registration. (Contrast
>    `_LineWorkflowBase.md` GOTCHA-SIG0, which forbids line subclasses from redefining them.)
> 3. There is **no `merge_retry` signal**, **no gate PR / merge logic**, **no
>    `_reconcile_and_merge_with_retry_loop`** here — this child performs no git merges.
> 4. `get_status` is **NOT** inherited from the base (the base's lives on `LineWorkflowBase`,
>    which this class doesn't extend). It defines its **own** `get_status` returning a
>    `WorkflowStatusResponse` with a **different shape** than the base's (no `current_line`, no
>    `pending_gate`; a composite `current_step` string and an iteration-based `progress_pct`).
>
> ⚠️ **GOTCHA-SUPER (`__init__` must call `super().__init__()` FIRST):** `generate_bc.py:60` calls
> `super().__init__()` as the first statement, which runs `HILSignalsMixin.__init__` and
> initializes the eight HIL vars (including `self.cancelled = False`). A rebuild that omits this,
> or sets the BC-local vars before calling super, breaks the cooperative-init chain and
> `self.cancelled` would be undefined when the escalation wait reads it. (See `_HILSignalsMixin.md`
> GOTCHA-0.)

**Imports (all inside `with workflow.unsafe.imports_passed_through():`, `generate_bc.py:28-47`):**
`dispatch_agent_task` (the only activity), `RETRY_POLICIES`, and from `types.py`:
`MAX_RALPH_ITERATIONS`, `AgentTaskInput`, `EscalationResolvedSignal`, `GateApprovedSignal`,
`GateRejectedSignal`, `GenerateBCInput`, `GenerateBCResult`, `ResolutionType`, `TaskStatus`,
`WavePatternsReadySignal`, `WorkflowStatus`, `WorkflowStatusResponse`; plus
`select_code_generation_skill` from `code_generation_router`. The `HILSignalsMixin` import and
`from temporalio import workflow` sit at the top level (`generate_bc.py:25-26`) — only the
sandbox-sensitive olympus/foundry imports are gated.

> ⚠️ **GOTCHA-IMPORTS:** `select_code_generation_skill` is imported under
> `imports_passed_through()` (`generate_bc.py:45-47`) and is **pure Python with no Temporal
> imports** (router module docstring `code_generation_router.py:28-31`). It is called *inside*
> `run()` (a workflow method) at `generate_bc.py:126` — i.e. it executes **in the workflow
> sandbox, not as an activity**. It is deterministic (pure dict lookups, `.lower()`), so this is
> safe. A rebuild MUST keep skill selection as an in-workflow pure function call, NOT an activity
> dispatch — making it an activity would change the event history.

---

## 1. STATE — every instance var

`__init__` (`generate_bc.py:59-73`) calls `super().__init__()` (line 60), then sets the
following. All HIL vars from `HILSignalsMixin` are also present (see `_HILSignalsMixin.md` §1);
only `self.cancelled` is consumed by this workflow.

| Var | Type | Initial | Set in `__init__` line | Mutated by → value | When |
|-----|------|---------|------------------------|---------------------|------|
| `_bc_name` | `str` | `""` | 61 | `run()` → `input.bc_name` (`88`) | run start |
| `_app_id` | `str` | `""` | 62 | `run()` → `input.app_id` (`89`) | run start |
| `_status` | `WorkflowStatus` | `WorkflowStatus.PENDING` | 63 | `run()` → `RUNNING` (`85`), `COMPLETED` (`175`); `_handle_escalation` → `WAITING_FOR_SIGNAL` (`202`), `CANCELLED` (`226`), `COMPLETED` (`237`) | run lifecycle |
| `_current_step` | `str` | `""` | 64 | `run()` → `f"ralph-loop-{iter}"` (`98`), `"completed"` (`176`); `_handle_escalation` → `"escalation-pending"` (`201`), `"escalation-resolved"` (`238`) | per iteration / escalation |
| `_iteration` | `int` | `0` | 65 | `run()` → `0` (`90`) then `+= 1` each loop top (`97`) | each Ralph iteration |
| `_started_at` | `str` | `""` | 66 | `run()` → `_now_iso()` (`86`) | run start |
| `_updated_at` | `str` | `""` | 67 | `run()` → `_started_at` (`87`), `_now_iso()` (`99,177`); `_handle_escalation` → `_now_iso()` (`203,227,239`); `escalation_resolved` signal → `_now_iso()` (`275`); the three other signals → `_now_iso()` (`279,283,287`) | many |
| `_escalation_id` | `str` | `""` | 70 | `_handle_escalation` → `f"esc-{wf_id[-8:]}"` (`200`) | on escalation entry |
| `_escalation_resolved` | `bool` | `False` | 71 | `escalation_resolved` signal → `True` (`272`) | escalation resolution |
| `_escalation_resolution` | `str` | `""` | 72 | `escalation_resolved` signal → `signal.resolution` (`273`) | escalation resolution |
| `_escalation_resolution_type` | `ResolutionType \| None` | `None` | 73 | `escalation_resolved` signal → `signal.resolution_type` (`274`) | escalation resolution |

**Local (non-instance) accumulators in `run()`** (NOT instance vars — re-created per `run()`,
`generate_bc.py:92-94`):

| Local | Type | Initial | Accumulated by | Read by |
|-------|------|---------|----------------|---------|
| `all_output_artifacts` | `list[str]` | `[]` (line 92) | `.extend(code_result.output_artifacts)` each iteration (`161`) | success return `output_artifacts` (`183`); passed to `_handle_escalation` (`190`) |
| `all_output_files` | `list` | `[]` (line 93) | `.extend(code_result.output_files)` each iteration (`162`) | success return `output_files` (`184`) |
| `test_results` | `list[str]` | `[]` (line 94) | `.extend(test_result.output_artifacts)` each iteration (`160`) | success return (`181`); passed to `_handle_escalation` (`190`) |

> ⚠️ **GOTCHA-ACCUM-ORDER (extend order is fixed: tests → code-artifacts → code-files):** the
> three `.extend(...)` calls run in this exact order every iteration (`generate_bc.py:160-162`):
> `test_results.extend(test_result.output_artifacts)` → `all_output_artifacts.extend(code_result.output_artifacts)`
> → `all_output_files.extend(code_result.output_files)`. They accumulate across ALL iterations,
> so on iteration N the result lists hold the concatenation of every iteration's outputs (not
> just the last). A rebuild MUST accumulate (extend), not overwrite, and MUST keep this order so
> list contents (and their order) match.
>
> ⚠️ **GOTCHA-ACCUM-SOURCE (artifacts come from `code_result`, NOT `test_result`):**
> `all_output_artifacts`/`all_output_files` are extended from **`code_result`** (the Step-2
> codegen dispatch), while `test_results` is extended from **`test_result`** (the Step-3 test
> dispatch). The Step-1 `tdd_result` outputs are **never** accumulated into any returned list —
> `tdd_result.output_artifacts` is only forwarded as the *input* to Step 2 (`generate_bc.py:137`).
> A rebuild must wire the three sources exactly: tests→`test_results`, code→both `output_*` lists,
> tdd→consumed-as-codegen-input-only.

---

## 2. SIGNALS & QUERY

### 2.1 Signal handlers (all `async def`, `@workflow.signal`)

This workflow defines **four** signals of its own (`generate_bc.py:270-287`) and inherits the
**six** HIL signals from `HILSignalsMixin`. None of the four below is inherited from a base
(this class doesn't extend `LineWorkflowBase`), so re-declaring `gate_approved` / `gate_rejected`
/ `escalation_resolved` is legal (no duplicate registration).

#### 2.1.1 `escalation_resolved(self, signal: EscalationResolvedSignal) -> None` — `generate_bc.py:270-275`
The **load-bearing** signal. `EscalationResolvedSignal` fields (`types.py:154-161`):
`escalation_id: str`, `resolved_by: str`, `resolution_type: ResolutionType`, `resolution: str`.
```text
async def escalation_resolved(self, signal):
    self._escalation_resolved = True                          # generate_bc.py:272
    self._escalation_resolution = signal.resolution           # generate_bc.py:273
    self._escalation_resolution_type = signal.resolution_type # generate_bc.py:274
    self._updated_at = _now_iso()                             # generate_bc.py:275
```
Buffers the resolution and **flips `_escalation_resolved=True`**, which is the predicate that
releases the escalation `wait_condition` (`generate_bc.py:221-223`). `_escalation_resolution_type`
is what `_handle_escalation` later inspects to decide `"escalated"` vs `"abandoned"`.
> ⚠️ **GOTCHA-SIG-VS-BASE (this OVERRIDES the base's no-op `escalation_resolved`):** in
> `LineWorkflowBase`, `escalation_resolved` only bumps `_updated_at` and records nothing
> (`_LineWorkflowBase.md` GOTCHA-SIG3). Here, because the class does NOT inherit the base, this
> handler is the **only** `escalation_resolved` registered, and it **does** record the resolution
> into instance vars. A rebuild must make THIS handler write `_escalation_resolved` /
> `_escalation_resolution` / `_escalation_resolution_type` — it is not a no-op.

#### 2.1.2 `gate_approved(self, signal: GateApprovedSignal) -> None` — `generate_bc.py:277-279`
```text
async def gate_approved(self, signal):
    self._updated_at = _now_iso()    # generate_bc.py:279
```
**No-op except timestamp.** The BC child has no gate of its own; this exists so a stray gate
signal addressed to the child doesn't fail. Payload `GateApprovedSignal` (re-exported from
contracts) is ignored.

#### 2.1.3 `gate_rejected(self, signal: GateRejectedSignal) -> None` — `generate_bc.py:281-283`
```text
async def gate_rejected(self, signal):
    self._updated_at = _now_iso()    # generate_bc.py:283
```
**No-op except timestamp.** Same rationale as `gate_approved`.

#### 2.1.4 `wave_patterns_ready(self, signal: WavePatternsReadySignal) -> None` — `generate_bc.py:285-287`
`WavePatternsReadySignal` fields (`types.py:182-188`): `wave_id: str`, `patterns: list[str]=[]`.
```text
async def wave_patterns_ready(self, signal):
    self._updated_at = _now_iso()    # generate_bc.py:287
```
**No-op except timestamp.** The pattern bundle is not consumed by the BC child.

> ⚠️ **GOTCHA-NOOP-SIGNALS (three of four signals are deliberate no-ops — keep them registered):**
> `gate_approved`, `gate_rejected`, `wave_patterns_ready` do nothing but bump `_updated_at`. They
> exist so signals propagated to this workflow (e.g. a wave-wide `wave_patterns_ready` broadcast,
> or a mis-routed gate decision) are **accepted and dropped** rather than causing
> "unhandled signal" warnings or being silently lost. A rebuild MUST register all three even
> though they have no effect on control flow — removing them changes signal-handling behavior
> (Temporal buffers signals for undefined handlers differently). The `_updated_at` bump keeps the
> dashboard's "last activity" timestamp fresh on any inbound signal.

> ⚠️ **GOTCHA-NO-CANCEL-REDEF (cancellation comes from the inherited `cancel_workflow`):** this
> workflow does **not** define its own cancel signal. Cancellation is driven by the inherited
> `HILSignalsMixin.cancel_workflow` signal (sets `self.cancelled=True`, `_HILSignalsMixin.md` §2.6),
> which the escalation wait predicate reads (`generate_bc.py:222`). A rebuild must inherit (not
> redefine) `cancel_workflow`, and must thread `self.cancelled` into the escalation wait.

### 2.2 Query: `get_status(self) -> WorkflowStatusResponse` — `generate_bc.py:293-309`

```text
@workflow.query
def get_status(self):
    return WorkflowStatusResponse(
        workflow_id = workflow.info().workflow_id,                       # 296
        status      = self._status,                                      # 297
        current_step = (                                                 # 298-301
            f"{self._bc_name}: {self._current_step} (iteration {self._iteration})"
        ),
        progress_pct = (                                                 # 302-306  ★TERNARY
            (self._iteration / MAX_RALPH_ITERATIONS) * 100
            if self._iteration > 0
            else 0.0
        ),
        started_at  = self._started_at,                                  # 307
        updated_at  = self._updated_at,                                  # 308
    )
```
- **One branch (ternary, `generate_bc.py:302-306`):** `progress_pct = (iteration / MAX_RALPH_ITERATIONS) * 100
  if iteration > 0 else 0.0`. With `MAX_RALPH_ITERATIONS=10`, iteration 1 → 10.0%, iteration 5 →
  50.0%, iteration 10 → 100.0%; iteration 0 (before the loop body runs) → 0.0%.
- Read-only, synchronous (queries must not mutate). Returns the **only** query on this workflow.
> ⚠️ **GOTCHA-Q-SHAPE (this `get_status` differs from the base's):** unlike `LineWorkflowBase.get_status`
> (which sets `current_line=self.ASSEMBLY_LINE` and `pending_gate=self._pending_gate`), this one
> leaves `current_line`/`pending_gate` at their dataclass defaults (`None`) and instead packs a
> **composite** `current_step` string `"{bc}: {step} (iteration {n})"` and an **iteration-derived**
> `progress_pct`. A rebuild MUST reproduce the exact f-string format and the `iteration>0` ternary
> — a dashboard parses this string and the percent.
> ⚠️ **GOTCHA-Q-PROGRESS-MISMATCH:** `progress_pct` divides by `MAX_RALPH_ITERATIONS` even though
> the workflow may complete on iteration 1 (showing 10%) or run to escalation (showing up to
> 100%). It is a *loop-position* indicator, NOT a completion percent. A rebuild must not "fix" it
> to reflect completion; reproduce the division verbatim.

---

## 3. CONTROL FLOW — `run(self, input: GenerateBCInput) -> GenerateBCResult` — `generate_bc.py:75-190`

`GenerateBCInput` fields (`types.py:2563-2589`): `app_id`, `bc_name`, `wave_id`, `portfolio_id`,
`artifact_repo=""`, `source_repo=""`, `module_map=""`, `design_artifacts=[]`,
`target_framework: str|None=None`, `target_frontend: str|None=None`, `primary_language: str|None=None`.

```text
async def run(self, input):
    # ── Initialization (generate_bc.py:85-90) ──
    self._status      = WorkflowStatus.RUNNING        # 85
    self._started_at  = _now_iso()                    # 86
    self._updated_at  = self._started_at              # 87
    self._bc_name     = input.bc_name                 # 88
    self._app_id      = input.app_id                  # 89
    self._iteration   = 0                             # 90

    all_output_artifacts: list[str] = []              # 92
    all_output_files:     list      = []              # 93
    test_results:         list[str] = []              # 94

    # ── Ralph Loop (generate_bc.py:96-187) ──  ★BRANCH 1 (while)
    while self._iteration < MAX_RALPH_ITERATIONS:     # 96   (MAX_RALPH_ITERATIONS = 10)
        self._iteration  += 1                         # 97
        self._current_step = f"ralph-loop-{self._iteration}"   # 98
        self._updated_at = _now_iso()                 # 99

        # Step 1 — Write tests from specs (tdd-generation skill)
        tdd_result = await workflow.execute_activity(
            dispatch_agent_task,                       # 102
            AgentTaskInput(                            # 104-110
                task_type=f"generate-tdd-{input.bc_name}",
                app_id=input.app_id,
                skill_id="tdd-generation",
                input_artifacts=input.design_artifacts,
                source_repo=input.source_repo,
            ),
            start_to_close_timeout=timedelta(hours=1), # 111
            retry_policy=RETRY_POLICIES["agent_failure"],   # 112
            activity_id=f"tdd-{input.bc_name}-iter{self._iteration}",   # 113
        )

        # Step 2 — Generate code to pass tests (router-selected skill)
        code_generation_skill_id = select_code_generation_skill(   # 126-130  ★IN-WORKFLOW PURE CALL
            target_framework=input.target_framework,
            target_frontend=input.target_frontend,
            primary_language=input.primary_language,
        )
        code_result = await workflow.execute_activity(
            dispatch_agent_task,                       # 131
            AgentTaskInput(                            # 133-139
                task_type=f"generate-code-{input.bc_name}",
                app_id=input.app_id,
                skill_id=code_generation_skill_id,
                input_artifacts=tdd_result.output_artifacts,   # ← Step-1 output as input
                source_repo=input.source_repo,
            ),
            start_to_close_timeout=timedelta(hours=1), # 140
            retry_policy=RETRY_POLICIES["agent_failure"],   # 141
            activity_id=f"codegen-{input.bc_name}-iter{self._iteration}",   # 142
        )

        # Step 3 — Run tests (test-validation skill)
        test_result = await workflow.execute_activity(
            dispatch_agent_task,                       # 146
            AgentTaskInput(                            # 148-154
                task_type=f"test-validation-{input.bc_name}",
                app_id=input.app_id,
                skill_id="test-validation",
                input_artifacts=code_result.output_artifacts,   # ← Step-2 output as input
                source_repo=input.source_repo,
            ),
            start_to_close_timeout=timedelta(minutes=15),   # 155  ← 15 MIN, not 1 hr
            retry_policy=RETRY_POLICIES["agent_failure"],   # 156
            activity_id=f"test-{input.bc_name}-iter{self._iteration}",   # 157
        )

        # Accumulate (generate_bc.py:160-162) — ORDER FIXED
        test_results.extend(test_result.output_artifacts)        # 160
        all_output_artifacts.extend(code_result.output_artifacts)# 161
        all_output_files.extend(code_result.output_files)        # 162

        # Step 4 — Did all tests pass? (generate_bc.py:167-185)
        raw_status = test_result.status                          # 167
        if isinstance(raw_status, list):                         # 168  ★BRANCH 2
            raw_status = "".join(raw_status)                     # 169
        tests_passed = (                                         # 170-173
            str(raw_status) == TaskStatus.COMPLETED.value        # "completed"
            and not test_result.error
        )
        if tests_passed:                                         # 174  ★BRANCH 3 (early return)
            self._status = WorkflowStatus.COMPLETED              # 175
            self._current_step = "completed"                     # 176
            self._updated_at = _now_iso()                        # 177
            return GenerateBCResult(                             # 178-185
                bc_name=input.bc_name,
                status="completed",
                test_results=test_results,
                iteration_count=self._iteration,
                output_artifacts=all_output_artifacts,
                output_files=all_output_files,
            )
        # tests failed → continue loop (no else; falls through to next while check)

    # ── Loop exhausted (iteration reached MAX_RALPH_ITERATIONS without success) ──
    return await self._handle_escalation(input, test_results, all_output_artifacts)   # 190
```

**Branch inventory in `run()` (3):**
1. **`while self._iteration < MAX_RALPH_ITERATIONS:`** (`generate_bc.py:96`) — the Ralph Loop.
   Pre-increment at top (`97`), so the body runs for iteration values 1..10 inclusive (10
   iterations). Exits when `_iteration` reaches 10 *and* no early return fired.
2. **`if isinstance(raw_status, list):`** (`generate_bc.py:168`) → `raw_status = "".join(raw_status)`.
   See GOTCHA-STR-ENUM.
3. **`if tests_passed:`** (`generate_bc.py:174`) → **early return** with `status="completed"`.
   The only happy-path exit. The implicit `else` is "fall through, loop again".

> ⚠️ **GOTCHA-LOOP-COUNT (10 iterations, pre-increment):** `_iteration` starts at 0 (`90`), the
> `while` checks `< 10` (`96`), then `+= 1` (`97`). So bodies execute for `_iteration ∈ {1,…,10}`
> — **exactly 10** Ralph iterations before exhaustion. On exhaustion `_iteration == 10`. A rebuild
> MUST pre-increment INSIDE the loop (not in the condition) so `iteration_count` on the result is
> the count of iterations actually run, and `get_status` reports the live iteration.
>
> ⚠️ **GOTCHA-STR-ENUM (Temporal deserializes a `str`-Enum as a LIST OF CHARS — both here and in
> escalation):** `test_result.status` is a `TaskStatus` (`str, enum.Enum`, `types.py:47-55`). When
> the `AgentTaskResult` round-trips through Temporal's converter, the str-enum field can come back
> as a **list of single-character strings** (e.g. `["c","o","m","p","l","e","t","e","d"]`) instead
> of the string `"completed"`. The guard at `generate_bc.py:168-169` normalizes it with
> `"".join(raw_status)` BEFORE comparing to `TaskStatus.COMPLETED.value` (= `"completed"`,
> `types.py:53`). A rebuild MUST reproduce this `isinstance(x, list)` → `"".join(x)` normalization
> verbatim, or a successful test run would mis-compare and the loop would never detect success.
> (The same quirk is handled again for `ResolutionType` in `_handle_escalation`, §4 GOTCHA-RES-ENUM.)
>
> ⚠️ **GOTCHA-TESTS-PASSED-AND (success requires BOTH status==completed AND empty error):**
> `tests_passed = str(raw_status) == "completed" and not test_result.error`
> (`generate_bc.py:170-173`). `AgentTaskResult.error` defaults to `""` (`types.py:525`); `not ""`
> is `True`. So success needs the normalized status to equal `"completed"` AND the `error` field
> to be falsy. A result with `status="completed"` but a non-empty `error` string is **NOT** a pass
> — it loops again. A rebuild must AND both conditions.
>
> ⚠️ **GOTCHA-STEP3-TIMEOUT (test-validation is 15 min, the other two are 1 hour):** Steps 1 & 2
> use `start_to_close_timeout=timedelta(hours=1)` (`generate_bc.py:111,140`); Step 3 (test run)
> uses `timedelta(minutes=15)` (`generate_bc.py:155`). A rebuild MUST use the shorter 15-minute
> timeout for the test-validation dispatch — test execution is expected to be fast; a 1-hour test
> hang should time out and (via `agent_failure` retries) surface sooner.
>
> ⚠️ **GOTCHA-ACTIVITY-IDS (deterministic, iteration-scoped):** each dispatch sets
> `activity_id=f"{prefix}-{bc_name}-iter{iteration}"` (`tdd-…`, `codegen-…`, `test-…`,
> `generate_bc.py:113,142,157`). These embed the iteration number so each iteration's three
> dispatches have unique, replay-stable ids. A rebuild MUST keep the iteration in the activity id;
> reusing the same id across iterations would make Temporal treat re-dispatches as the same
> activity on replay.
>
> ⚠️ **GOTCHA-INPUT-CHAIN (the three steps form a strict data pipeline):** Step-2 input =
> `tdd_result.output_artifacts` (`137`); Step-3 input = `code_result.output_artifacts` (`152`).
> Step-1 input = `input.design_artifacts` (`108`). All three pass `source_repo=input.source_repo`.
> A rebuild MUST wire the outputs forward exactly: design→tdd→codegen→test.
>
> ⚠️ **GOTCHA-AGENTTASKINPUT-MINIMAL (these dispatches pass NO execution_context, NO artifact_repo):**
> Unlike `LineWorkflowBase._dispatch_agent` (which threads `execution_context`, `artifact_repo`,
> `artifact_ref`, `context`, `workspace_key`), the four dispatches here construct a **minimal**
> `AgentTaskInput` with only `task_type`, `app_id`, `skill_id`, `input_artifacts`, `source_repo`
> (`generate_bc.py:104-110,133-139,148-154,209-214`). All other `AgentTaskInput` fields fall to
> their dataclass defaults (`types.py:469-509`): `artifact_repo=""`, `artifact_ref=""`,
> `execution_context=None`, `context={}`, `workspace_key=""`, `wave_id=""`. A rebuild MUST NOT add
> `execution_context` or other fields — doing so changes the activity input payload (and thus
> event history / replay).

---

## 4. CONTROL FLOW — `_handle_escalation(self, input, test_results, output_artifacts) -> GenerateBCResult` — `generate_bc.py:192-264`

Reached **only** when the Ralph Loop exhausts all 10 iterations without `tests_passed`. Creates an
escalation record (via an agent dispatch), waits for a human `escalation_resolved` signal (or
cancel), then maps the resolution to a terminal status.

```text
async def _handle_escalation(self, input, test_results, output_artifacts):
    wf_id = workflow.info().workflow_id                  # 199
    self._escalation_id = f"esc-{wf_id[-8:]}"            # 200  ← last 8 chars of workflow id
    self._current_step  = "escalation-pending"          # 201
    self._status        = WorkflowStatus.WAITING_FOR_SIGNAL   # 202
    self._updated_at    = _now_iso()                    # 203

    # Dispatch escalation handler to recommend a path (escalation-handler skill)
    await workflow.execute_activity(
        dispatch_agent_task,                             # 206
        AgentTaskInput(                                  # 208-214
            task_type=f"escalation-{input.bc_name}",
            app_id=input.app_id,
            skill_id="escalation-handler",
            input_artifacts=test_results,
            source_repo=input.source_repo,
        ),
        start_to_close_timeout=timedelta(minutes=10),    # 215  ← 10 MIN
        retry_policy=RETRY_POLICIES["agent_failure"],    # 216
        activity_id=f"escalation-{input.bc_name}",       # 217  ← NO iteration suffix
    )

    # Wait for human to resolve (or cancel)
    await workflow.wait_condition(                       # 221
        lambda: self._escalation_resolved or self.cancelled   # 222  ★PREDICATE
    )

    if self.cancelled:                                   # 225  ★BRANCH A (early return)
        self._status     = WorkflowStatus.CANCELLED      # 226
        self._updated_at  = _now_iso()                   # 227
        return GenerateBCResult(                         # 228-235
            bc_name=input.bc_name,
            status="cancelled",
            test_results=test_results,
            iteration_count=self._iteration,
            escalation_id=self._escalation_id,
            output_artifacts=output_artifacts,
        )

    # Resolved (not cancelled)
    self._status       = WorkflowStatus.COMPLETED        # 237
    self._current_step = "escalation-resolved"           # 238
    self._updated_at   = _now_iso()                      # 239

    # Map resolution_type → terminal status (generate_bc.py:246-255)
    result_status = "escalated"                          # 246  ← default
    resolution_type = self._escalation_resolution_type   # 247
    if isinstance(resolution_type, list):                # 248  ★BRANCH B (str-enum-as-list)
        resolution_type = "".join(resolution_type)       # 250
    if isinstance(resolution_type, str):                 # 251  ★BRANCH C
        if resolution_type == ResolutionType.ABANDON.value:   # 252  ★BRANCH C-inner ("Abandon")
            result_status = "abandoned"                  # 253
    elif resolution_type == ResolutionType.ABANDON:      # 254  ★BRANCH D (enum-identity)
        result_status = "abandoned"                      # 255

    return GenerateBCResult(                             # 257-264
        bc_name=input.bc_name,
        status=result_status,                            # "escalated" | "abandoned"
        test_results=test_results,
        iteration_count=self._iteration,
        escalation_id=self._escalation_id,
        output_artifacts=output_artifacts,
    )
```

**Branch inventory in `_handle_escalation` (5):**
- **A.** `if self.cancelled:` (`generate_bc.py:225`) → status `CANCELLED`, **early return** with
  `status="cancelled"`. Checked FIRST after the wait.
- **B.** `if isinstance(resolution_type, list):` (`generate_bc.py:248`) → `"".join(...)`.
- **C.** `if isinstance(resolution_type, str):` (`generate_bc.py:251`) — string path; with inner
  **C-inner** `if resolution_type == ResolutionType.ABANDON.value:` (`= "Abandon"`,
  `types.py:105`) → `result_status = "abandoned"` (`253`).
- **D.** `elif resolution_type == ResolutionType.ABANDON:` (`generate_bc.py:254`) — the
  `elif` of branch C (taken only when `resolution_type` is NOT a `str`, e.g. the live enum
  member) → compares by enum identity → `result_status = "abandoned"` (`255`).

> ⚠️ **GOTCHA-ESC-ID (`esc-` + LAST 8 chars of workflow id):** `self._escalation_id =
> f"esc-{wf_id[-8:]}"` (`generate_bc.py:200`). It is derived from `workflow.info().workflow_id`,
> NOT random — deterministic under replay. A rebuild MUST use the **last** 8 chars (`[-8:]`) of
> the workflow id, prefixed with `"esc-"`. This id is surfaced in the result (`233,262`) and is
> what the human's `EscalationResolvedSignal.escalation_id` is expected to reference.
>
> ⚠️ **GOTCHA-ESC-WAIT-PREDICATE (`_escalation_resolved OR cancelled`):** the wait
> (`generate_bc.py:221-223`) releases on EITHER the human signal (`_escalation_resolved`, set by
> the `escalation_resolved` handler) OR `self.cancelled` (set by the inherited `cancel_workflow`).
> This is the workflow's ONLY blocking wait. A rebuild MUST OR in `self.cancelled` — otherwise the
> escalated BC is uncancellable and blocks forever if no human resolves it. (Mirrors
> `_HILSignalsMixin.md` GOTCHA-7's "OR cancelled at the call site" pattern.)
>
> ⚠️ **GOTCHA-CANCEL-FIRST (cancel wins even if both flags set):** branch A checks `cancelled`
> BEFORE inspecting `_escalation_resolution_type` (`generate_bc.py:225` precedes `247`). If a
> resolution signal AND a cancel both arrive before the wait releases, `cancelled` short-circuits
> to `status="cancelled"` and the resolution_type mapping is never reached. A rebuild MUST check
> `self.cancelled` first.
>
> ⚠️ **GOTCHA-RES-ENUM (the str-enum-as-list quirk AGAIN, plus a dual str/enum compare):**
> `_escalation_resolution_type` is a `ResolutionType` (`str, enum.Enum`, `types.py:84-105`).
> Temporal may deserialize it as a **list of chars** (branch B, `generate_bc.py:248-250`) — same
> quirk as the test status (GOTCHA-STR-ENUM). After the join, the value is a **plain `str`**, so
> branch C (`isinstance str`) is taken and the inner compare uses `ABANDON.value` (`"Abandon"`).
> But if the value was delivered as a genuine **enum member** (not a list, not a bare str — though
> note `ResolutionType` *is* a str subclass, so `isinstance(member, str)` is actually `True`),
> branch D's `elif … == ResolutionType.ABANDON` is the fallback enum-identity compare. A rebuild
> MUST reproduce all three forms: (B) list→join, (C) str→compare to `.value`, (D) elif→compare to
> the enum member. Only `ResolutionType.ABANDON` maps to `"abandoned"`; **all other resolution
> types** (`RE_EXTRACT`, `MANUAL_AUGMENT`, `RE_DISPOSITION`, or `None`, or unmatched) leave
> `result_status` at its default **`"escalated"`** (`generate_bc.py:246`).
>
> ⚠️ **GOTCHA-RES-DEFAULT-ESCALATED (only ABANDON → "abandoned"; everything else → "escalated"):**
> Per the W19 Modernization line contract (`types.py:84-105`, `generate_bc.py:241-245`), the four
> Ralph-loop escape outcomes are `RE_EXTRACT` / `MANUAL_AUGMENT` / `RE_DISPOSITION` / `ABANDON`.
> **This workflow only distinguishes ABANDON** (terminal failure → `"abandoned"`); the other three
> resolution types all yield `"escalated"`. The *actual* re-extract / manual-augment / re-disposition
> behavior is enacted by the **parent** `ModernizationWorkflow` reading the child's result + the
> escalation record — NOT by this child. The contract (`generate_bc.py:14-18`): Re-Extract → parent
> restarts Modernization from Extract; Manual Augment → human commits patches, child *re-enters*
> the Ralph Loop (but note: THIS `run()` does not loop back after escalation — re-entry is a fresh
> child spawn by the parent); Re-Disposition → parent cancels remaining BCs; Abandon → parent marks
> line failed. A rebuild MUST map exactly ABANDON→"abandoned", all-else→"escalated", and MUST NOT
> attempt to re-enter the Ralph Loop inside `_handle_escalation`.
>
> ⚠️ **GOTCHA-ESC-NO-LOOPBACK (resolution does NOT restart the Ralph Loop in THIS workflow):**
> Despite the docstring's "Manual Augment: child re-enters Ralph Loop" (`generate_bc.py:17`), the
> `_handle_escalation` body has **no loop** — after the wait releases (non-cancel), it computes a
> terminal status and returns (`generate_bc.py:257`). There is no path from escalation back to the
> `while` loop in `run()`. "Re-enters the Ralph Loop" is realized by the parent spawning a **new**
> `GenerateBCWorkflow` child. A rebuild MUST NOT add a loop-back from escalation to the Ralph Loop.
>
> ⚠️ **GOTCHA-ABANDON-PARENT-PROJECTION:** the `"abandoned"` status is consumed by the parent so it
> sets `application.modernization_current_status = "modernization_failed"` via the post-G-04c
> projection (`generate_bc.py:241-245`) — i.e. an abandoned BC fails the whole Modernization run
> (no partial ship), whereas `"escalated"` is a resolvable outcome. A rebuild must keep the two
> statuses distinct on the result so the parent's projection branches correctly.

---

## 5. ACTIVITY CALLS — complete ordered inventory

The workflow calls exactly **one activity function** — `dispatch_agent_task` — **four times** (three
in the Ralph Loop per iteration, one in escalation). There are **no child-workflow calls** from
here (this IS the child); there are **no parallel/`gather` dispatches** — every call is sequential
and `await`ed.

`dispatch_agent_task` is the agent-dispatch activity (imported from `activities.agent_dispatch`,
`generate_bc.py:29`); it takes a single `AgentTaskInput` dataclass and returns `AgentTaskResult`
(`types.py:512-525`).

| # | Where | Activity | Input (`AgentTaskInput` fields set) | `skill_id` | `start_to_close_timeout` | `retry_policy` | `activity_id` |
|---|-------|----------|--------------------------------------|------------|--------------------------|----------------|---------------|
| 1 | Ralph Step 1 (`102-114`) | `dispatch_agent_task` | `task_type="generate-tdd-{bc}"`, `app_id`, `skill_id="tdd-generation"`, `input_artifacts=input.design_artifacts`, `source_repo` | `tdd-generation` | **1 hour** | `agent_failure` | `tdd-{bc}-iter{n}` |
| 2 | Ralph Step 2 (`131-143`) | `dispatch_agent_task` | `task_type="generate-code-{bc}"`, `app_id`, `skill_id=<router>`, `input_artifacts=tdd_result.output_artifacts`, `source_repo` | `select_code_generation_skill(...)` | **1 hour** | `agent_failure` | `codegen-{bc}-iter{n}` |
| 3 | Ralph Step 3 (`146-158`) | `dispatch_agent_task` | `task_type="test-validation-{bc}"`, `app_id`, `skill_id="test-validation"`, `input_artifacts=code_result.output_artifacts`, `source_repo` | `test-validation` | **15 minutes** | `agent_failure` | `test-{bc}-iter{n}` |
| 4 | Escalation (`206-218`) | `dispatch_agent_task` | `task_type="escalation-{bc}"`, `app_id`, `skill_id="escalation-handler"`, `input_artifacts=test_results`, `source_repo` | `escalation-handler` | **10 minutes** | `agent_failure` | `escalation-{bc}` |

**`agent_failure` retry policy** (`retry_policies.py:37-42`, key `"agent_failure"` at line 111):
`initial_interval=5s`, `backoff_coefficient=2.0`, `maximum_interval=60s`, **`maximum_attempts=3`**,
**no `non_retryable_error_types`**. So each dispatch retries up to 3 times on any failure (5s →
10s → … capped at 60s backoff). There are **no `non_retryable` errors** on these dispatches —
validation/agent failures retry, they do not hard-fail the workflow on first error.

> ⚠️ **GOTCHA-ESC-ID-STABLE (escalation activity_id has NO iteration suffix):** the escalation
> dispatch uses `activity_id=f"escalation-{input.bc_name}"` (`generate_bc.py:217`) — no `-iter{n}`.
> `_handle_escalation` runs exactly once (after the loop), so a single stable id is correct. A
> rebuild MUST NOT add an iteration suffix here.
>
> ⚠️ **GOTCHA-RouterIsNotAnActivity:** call #2's `skill_id` is computed by the **in-workflow pure
> function** `select_code_generation_skill` (`generate_bc.py:126-130`), evaluated synchronously
> before the dispatch — it is NOT a fifth activity. See §6 for its full branch table.
>
> ⚠️ **GOTCHA-DISPATCH-PARITY-DIFF (this does NOT use `_dispatch_agent`):** because the class does
> not extend `LineWorkflowBase`, these four calls invoke `workflow.execute_activity(dispatch_agent_task, …)`
> **directly**, with hand-built minimal `AgentTaskInput`s — they do NOT go through
> `LineWorkflowBase._dispatch_agent` and therefore do **not**: load context-priors, attach
> rework-feedback, record `_agent_metadata`, or attach `execution_context`. A rebuild MUST call the
> dispatch activity directly with the minimal input shape, NOT route through any base dispatch helper.

---

## 6. `select_code_generation_skill(...)` — the Stage-3 router (called in-workflow) — `code_generation_router.py:60-92`

Pure, deterministic skill-variant selector. Called once per Ralph iteration at
`generate_bc.py:126-130` to pick call #2's `skill_id`.

```text
def select_code_generation_skill(target_framework, target_frontend, primary_language):
    if primary_language and target_framework:                              # router:84  ★B1
        key = (primary_language.lower(), target_framework.lower())         # router:85
        if key in CODE_GENERATION_PAIR_MAP:                                # router:86  ★B2
            return CODE_GENERATION_PAIR_MAP[key]                           # router:87
    if target_frontend and target_frontend.lower() in CODE_GENERATION_SKILL_MAP:   # router:88  ★B3
        return CODE_GENERATION_SKILL_MAP[target_frontend.lower()]          # router:89
    if target_framework and target_framework.lower() in CODE_GENERATION_SKILL_MAP: # router:90  ★B4
        return CODE_GENERATION_SKILL_MAP[target_framework.lower()]         # router:91
    return CODE_GENERATION_SKILL_MAP["default"]                            # router:92  → "code-generation"
```

**Resolution order (most → least specific), 4 branches:**
1. **B1+B2** (`router:84-87`): if BOTH `primary_language` and `target_framework` are truthy AND
   `(primary_language.lower(), target_framework.lower())` is a key in `CODE_GENERATION_PAIR_MAP`,
   return the specialist pair skill. `CODE_GENERATION_PAIR_MAP` (`router:54-57`):
   `("cobol","springboot") → "code-generation-cobol-to-java"`,
   `("natural","springboot") → "code-generation-natural-to-springboot"`.
2. **B3** (`router:88-89`): else if `target_frontend` is truthy and its lowercase is in
   `CODE_GENERATION_SKILL_MAP`, return that. (Only `"react" → "code-generation-react"` is a
   frontend key.)
3. **B4** (`router:90-91`): else if `target_framework` is truthy and its lowercase is in
   `CODE_GENERATION_SKILL_MAP`, return that.
4. **default** (`router:92`): return `CODE_GENERATION_SKILL_MAP["default"]` = `"code-generation"`.

`CODE_GENERATION_SKILL_MAP` (`router:39-48`): `springboot→code-generation-springboot`,
`aspnet-core→code-generation-dotnet`, `dotnet→code-generation-dotnet`,
`fastapi→code-generation-fastapi`, `express→code-generation-node`, `fastify→code-generation-node`,
`react→code-generation-react`, `default→code-generation`.

> ⚠️ **GOTCHA-ROUTER-FALLBACK (None inputs → generic `code-generation`):** when all three inputs
> are `None` (legacy fixtures / unknown stacks — the common case for `GenerateBCInput` without
> Stage-3 fields, `types.py:2587-2589`), every `if` short-circuits on the `and`/truthiness checks
> and the function returns `"code-generation"`. The `generate_bc.py:118-125` comment confirms this
> preserves pre-Stage-3 behavior. A rebuild MUST default to `"code-generation"` so legacy BCs
> dispatch the generic skill unchanged.
> ⚠️ **GOTCHA-ROUTER-PAIR-OUTRANKS (pair map beats frontend beats framework):** the specialist
> `(language, framework)` pair (B1+B2) is checked FIRST and outranks both frontend (B3) and
> framework (B4) because it encodes source idioms (COBOL `PERFORM`, NATURAL GDA/MU/PE) on top of
> the target. A rebuild MUST preserve this precedence order; e.g. `(cobol, springboot)` →
> `code-generation-cobol-to-java`, NOT `code-generation-springboot`.
> ⚠️ **GOTCHA-ROUTER-LOWER (all comparisons are `.lower()`):** every lookup lowercases the input
> (`router:85,88-91`). `"SpringBoot"` and `"springboot"` both resolve. A rebuild MUST lowercase
> before the dict lookups.

---

## 7. RESILIENCE

- **Timeouts (start_to_close):** Step-1 tdd dispatch **1 hr**; Step-2 codegen dispatch **1 hr**;
  Step-3 test dispatch **15 min**; escalation dispatch **10 min** (`generate_bc.py:111,140,155,215`).
- **Retry:** every dispatch uses `agent_failure` (3 attempts, 5–60s exp backoff, no non_retryable
  types, `retry_policies.py:37-42`). A persistently failing dispatch raises after 3 attempts and
  fails the workflow (no try/except wraps the dispatches — see GOTCHA-NO-TRYEXCEPT).
- **Heartbeats:** none configured. Relies on start_to_close timeouts.
- **continue-as-new:** none. The Ralph Loop is bounded at 10 iterations × 3 dispatches = ≤30
  dispatch events + 1 escalation, well within history limits; no CAN needed.
- **Idempotency:** deterministic, iteration-scoped `activity_id`s make each dispatch replay-stable
  (`tdd-{bc}-iter{n}`, `codegen-…`, `test-…`, `escalation-{bc}`). `_now_iso()` =
  `workflow.now().isoformat()` (`generate_bc.py:312-313`) is deterministic under replay — there is
  **no** `datetime.now()` anywhere. The escalation id is workflow-id-derived (deterministic).
- **Cancellation:** `self.cancelled` (inherited, set by `cancel_workflow`) is ORed into the
  escalation wait (`generate_bc.py:222`); during the wait, cancel drains to `status="cancelled"`.
  Cancellation during a Ralph dispatch propagates as a Temporal `CancelledError` through the
  `await` (not explicitly handled here — Temporal cancels the in-flight activity).
- **Compensation / rollback:** **none.** There is no rollback path. Code/test artifacts already
  committed by the agent (inside the dispatched skills) are not un-committed on failure. Terminal
  semantics are conveyed by the result `status` (`"completed"` / `"escalated"` / `"abandoned"` /
  `"cancelled"`); the **parent** `ModernizationWorkflow` owns any line-level failure projection.

> ⚠️ **GOTCHA-NO-TRYEXCEPT (no try/except/finally anywhere in this workflow):** neither `run()`
> nor `_handle_escalation()` wraps any dispatch in `try/except`. An unrecoverable dispatch failure
> (after `agent_failure`'s 3 attempts) propagates as an `ActivityError` and **fails the workflow**.
> There is no best-effort swallowing here (contrast `LineWorkflowBase`'s many best-effort blocks).
> A rebuild MUST NOT add try/except around the dispatches — a hard agent failure is meant to fail
> the child so the parent sees it.
>
> ⚠️ **GOTCHA-STATUS-NEVER-FAILED (`run()` never sets `_status=FAILED`):** the only statuses this
> workflow assigns are `RUNNING` (`85`), `COMPLETED` (`175,237`), `WAITING_FOR_SIGNAL` (`202`),
> `CANCELLED` (`226`). It NEVER sets `WorkflowStatus.FAILED`. A genuinely failed (raising)
> dispatch crashes the workflow with `_status` stuck at its last value (`RUNNING` or
> `WAITING_FOR_SIGNAL`); the *result* status `"escalated"`/`"abandoned"` is how failure-to-pass is
> reported, not the `_status` enum. A rebuild must not introduce a `FAILED` status assignment.

---

## 8. END-TO-END OUTCOME MAP (what a rebuild's `GenerateBCResult.status` must be)

| Scenario | Path | `GenerateBCResult.status` | `iteration_count` | `escalation_id` | `output_files` |
|----------|------|---------------------------|-------------------|-----------------|----------------|
| All tests pass on iteration k (1≤k≤10) | early return `174-185` | `"completed"` | k | `""` (default) | `all_output_files` (populated) |
| 10 iterations, never pass, human resolves with ABANDON | `_handle_escalation` branch C-inner/D | `"abandoned"` | 10 | `esc-{wf_id[-8:]}` | `[]` (default — escalation result omits `output_files`) |
| 10 iterations, never pass, human resolves with RE_EXTRACT / MANUAL_AUGMENT / RE_DISPOSITION / (any non-ABANDON / None) | `_handle_escalation` default | `"escalated"` | 10 | `esc-{wf_id[-8:]}` | `[]` |
| Cancelled during escalation wait | `_handle_escalation` branch A | `"cancelled"` | 10 | `esc-{wf_id[-8:]}` | `[]` |
| Dispatch fails 3× (Ralph or escalation) | exception propagates | *(workflow fails; no result)* | — | — | — |

> ⚠️ **GOTCHA-RESULT-FIELDS (success vs escalation result shapes differ):** the **success** return
> (`generate_bc.py:178-185`) sets `output_artifacts=all_output_artifacts` AND
> `output_files=all_output_files`, but does NOT set `escalation_id` (defaults to `""`). The
> **escalation/cancel** returns (`228-235`, `257-264`) set `escalation_id=self._escalation_id` and
> `output_artifacts=output_artifacts`, but do NOT set `output_files` (defaults to `[]`,
> `types.py:2602`). A rebuild MUST match these field presences exactly — the parent reads
> `output_files` only on the success path and `escalation_id` only on the escalate/cancel paths.
> Both `_handle_escalation` returns pass `iteration_count=self._iteration` (= 10 at exhaustion).

---

## 9. Behavioral parity checklist

A rebuilt `GenerateBCWorkflow` MUST satisfy ALL of the following:

1. **Inheritance:** `class GenerateBCWorkflow(HILSignalsMixin)` — inherits from the **mixin
   directly**, NOT `LineWorkflowBase`. `__init__` calls `super().__init__()` as its **first**
   statement (initializing the 8 HIL vars incl. `cancelled=False`), then sets the 11 BC-local vars
   (§1) to their listed initial values. (GOTCHA-INHERIT, GOTCHA-SUPER)
2. **Activity imports** are inside `with workflow.unsafe.imports_passed_through():`; the only
   activity imported is `dispatch_agent_task`. `select_code_generation_skill` is imported there too
   and is called **in-workflow** (pure function, not an activity). (GOTCHA-IMPORTS, GOTCHA-RouterIsNotAnActivity)
3. **Ralph Loop:** `while self._iteration < MAX_RALPH_ITERATIONS` (=10); `_iteration += 1` at the
   **top** of the body (pre-increment); set `_current_step=f"ralph-loop-{n}"` and bump `_updated_at`
   each iteration. Body runs for `_iteration ∈ {1..10}` → exactly 10 iterations on exhaustion.
   (GOTCHA-LOOP-COUNT)
4. **Three sequential dispatches per iteration**, awaited in order: (1) `tdd-generation`
   [`generate-tdd-{bc}`, input=`design_artifacts`, **1h**, `agent_failure`,
   `activity_id=tdd-{bc}-iter{n}`]; (2) router-selected skill [`generate-code-{bc}`,
   input=`tdd_result.output_artifacts`, **1h**, `agent_failure`, `activity_id=codegen-{bc}-iter{n}`];
   (3) `test-validation` [`test-validation-{bc}`, input=`code_result.output_artifacts`, **15min**,
   `agent_failure`, `activity_id=test-{bc}-iter{n}`]. All pass `source_repo=input.source_repo` and
   set ONLY the 5 minimal `AgentTaskInput` fields (no execution_context / artifact_repo / context).
   (GOTCHA-INPUT-CHAIN, GOTCHA-STEP3-TIMEOUT, GOTCHA-ACTIVITY-IDS, GOTCHA-AGENTTASKINPUT-MINIMAL,
   GOTCHA-DISPATCH-PARITY-DIFF)
5. **Accumulation order (every iteration):** `test_results.extend(test_result.output_artifacts)`
   → `all_output_artifacts.extend(code_result.output_artifacts)` →
   `all_output_files.extend(code_result.output_files)`. `tdd_result` outputs are NOT accumulated.
   Lists are local to `run()` and accumulate across all iterations. (GOTCHA-ACCUM-ORDER,
   GOTCHA-ACCUM-SOURCE)
6. **Test-pass detection:** normalize `test_result.status` — `if isinstance(raw_status, list):
   raw_status = "".join(raw_status)` — then `tests_passed = str(raw_status) ==
   TaskStatus.COMPLETED.value AND not test_result.error`. (GOTCHA-STR-ENUM, GOTCHA-TESTS-PASSED-AND)
7. **Success early-return:** on `tests_passed`, set `_status=COMPLETED`, `_current_step="completed"`,
   bump `_updated_at`, and **return** `GenerateBCResult(status="completed",
   iteration_count=_iteration, test_results=test_results, output_artifacts=all_output_artifacts,
   output_files=all_output_files)` (no `escalation_id`). (GOTCHA-RESULT-FIELDS)
8. **Router** `select_code_generation_skill`: 4-branch resolution — pair-map (lang+framework,
   lowercased) → frontend (lowercased) → framework (lowercased) → `"code-generation"` default;
   pair-map outranks frontend outranks framework; all-None → `"code-generation"`. (GOTCHA-ROUTER-*)
9. **Escalation entry (only after 10-iteration exhaustion):** set `_escalation_id=f"esc-{wf_id[-8:]}"`
   (last 8 chars of workflow id), `_current_step="escalation-pending"`,
   `_status=WAITING_FOR_SIGNAL`, bump `_updated_at`; then dispatch `escalation-handler`
   [`escalation-{bc}`, input=`test_results`, **10min**, `agent_failure`,
   `activity_id=escalation-{bc}` (NO iteration suffix)]. (GOTCHA-ESC-ID, GOTCHA-ESC-ID-STABLE)
10. **Escalation wait:** `await workflow.wait_condition(lambda: self._escalation_resolved or
    self.cancelled)`. (GOTCHA-ESC-WAIT-PREDICATE)
11. **Cancel branch FIRST:** `if self.cancelled:` → `_status=CANCELLED`, bump `_updated_at`, return
    `GenerateBCResult(status="cancelled", iteration_count=_iteration, test_results=test_results,
    escalation_id=_escalation_id, output_artifacts=output_artifacts)`. Checked before any
    resolution-type inspection. (GOTCHA-CANCEL-FIRST)
12. **Resolution mapping (non-cancel):** set `_status=COMPLETED`, `_current_step="escalation-resolved"`,
    bump `_updated_at`. `result_status="escalated"` default; `if isinstance(resolution_type, list):
    "".join(...)`; `if isinstance(resolution_type, str): if == ResolutionType.ABANDON.value
    ("Abandon"): result_status="abandoned"`; `elif resolution_type == ResolutionType.ABANDON:
    result_status="abandoned"`. ONLY ABANDON → `"abandoned"`; all else → `"escalated"`. Return with
    `escalation_id` set, `output_files` unset. **No loop-back to the Ralph Loop.** (GOTCHA-RES-ENUM,
    GOTCHA-RES-DEFAULT-ESCALATED, GOTCHA-ESC-NO-LOOPBACK, GOTCHA-ABANDON-PARENT-PROJECTION)
13. **Signals (exactly four own + six inherited):** own `escalation_resolved` (records
    `_escalation_resolved=True`, `_escalation_resolution`, `_escalation_resolution_type`, bump
    `_updated_at`); `gate_approved` / `gate_rejected` / `wave_patterns_ready` are **no-ops except
    `_updated_at`**. All four `async def`. The six HIL signals are inherited (not redefined),
    notably `cancel_workflow`→`cancelled=True`. NONE of the four own signals is a redefinition of a
    base signal (this class has no `LineWorkflowBase` base). (GOTCHA-SIG-VS-BASE, GOTCHA-NOOP-SIGNALS,
    GOTCHA-NO-CANCEL-REDEF)
14. **Query (exactly one):** `get_status` returns `WorkflowStatusResponse(workflow_id=info().workflow_id,
    status=_status, current_step=f"{_bc_name}: {_current_step} (iteration {_iteration})",
    progress_pct=(_iteration/MAX_RALPH_ITERATIONS)*100 if _iteration>0 else 0.0,
    started_at=_started_at, updated_at=_updated_at)`. No `current_line`/`pending_gate`. Read-only.
    (GOTCHA-Q-SHAPE, GOTCHA-Q-PROGRESS-MISMATCH)
15. **No try/except/finally** anywhere; **no `_status=FAILED`** ever assigned; **no continue-as-new**;
    **no child-workflow calls**; **no gate/merge logic**; **no compensation/rollback**. A hard
    dispatch failure (after 3 `agent_failure` attempts) propagates and fails the workflow.
    (GOTCHA-NO-TRYEXCEPT, GOTCHA-STATUS-NEVER-FAILED)
16. **Determinism:** all timestamps via module-level `_now_iso()` = `workflow.now().isoformat()`;
    escalation id derived from `workflow.info().workflow_id`; activity ids deterministic and
    iteration-scoped (Ralph) / stable (escalation). No `datetime.now()`, no randomness.
