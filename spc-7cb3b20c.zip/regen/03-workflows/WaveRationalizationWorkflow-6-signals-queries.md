# `WaveRationalizationWorkflow` — Part 6: Signal & Query Handlers (ATOMIC regeneration spec)

> **Source of truth:** `temporal/olympus_workflows/workflows/wave_rationalization.py`.
> **THIS FILE OWNS LINES 5608–5969 ONLY.** Every `@workflow.signal` / `@workflow.query`
> handler plus the two non-decorated helpers they depend on (`_register_gate_key`,
> `_extract_v2_metadata`) live here. The `run()`/`_execute()` body, the gate rework loop,
> `_wait_for_gate`, `_normalize_dispatch_payload`, the dispatch/fan-out methods, and `__init__`
> live in **sibling files** and are referenced (not re-reproduced) where they consume the
> state these handlers mutate.
>
> **Inheritance:** `class WaveRationalizationWorkflow(HILSignalsMixin)` — it inherits the six
> HIL signals + helpers documented in `_HILSignalsMixin.md`. ⚠️ **It does NOT extend
> `LineWorkflowBase`** (confirmed by the docstring at `wave_rationalization.py:1180-1183`:
> *"this workflow inlines the same logic because it doesn't inherit from LineWorkflowBase"*).
> Therefore the gate-decision / merge-retry / status plumbing that `LineWorkflowBase` would
> normally provide is **re-declared inline on this class** — those inline copies are the
> handlers documented below. This is the critical structural difference from every per-line
> workflow.
>
> **Determinism note:** every handler in scope is an `async def` but performs **only**
> synchronous attribute mutations and (in `cancel_all_children`) `await handle.cancel()`. The
> only non-determinism-sensitive call any handler makes is `_now_iso()` → `workflow.now()`
> (`wave_rationalization.py:134-135`), which is deterministic under Temporal replay. No handler
> calls `workflow.wait_condition` or `asyncio.sleep`; they set flags/append to queues that the
> **run body's** `wait_condition` predicates consume.

---

## 0. What is in scope (the exact handler inventory, in source order)

| Line(s) | Symbol | Kind | Wire name | Payload type |
|---------|--------|------|-----------|--------------|
| 5608-5612 | `merge_retry` | `@workflow.signal` | `merge_retry` | `GateMergeRetrySignal` |
| 5614-5630 | `_register_gate_key` | plain method (NOT a signal) | — | `(gate_id: str, gate_key: str)` |
| 5632-5660 | `gate_approved` | `@workflow.signal` | `gate_approved` | `GateApprovedSignal` |
| 5662-5684 | `gate_rejected` | `@workflow.signal` | `gate_rejected` | `GateRejectedSignal` |
| 5686-5753 | `cancel_all_children` | `@workflow.signal` | `cancel_all_children` | *(none — zero-arg)* |
| 5755-5787 | `stakeholder_approved` | `@workflow.signal` | `stakeholder_approved` | `StakeholderApprovedSignal` |
| 5793-5815 | `dispatch_architecture` | `@workflow.signal` | `dispatch_architecture` | `DispatchArchitecturePayload` |
| 5817-5841 | `dispatch_architecture_v2` | `@workflow.signal` | `dispatch_architecture_v2` | `DispatchArchitecturePayloadV2` |
| 5843-5898 | `_extract_v2_metadata` | `@staticmethod` (NOT a signal) | — | `(payload: object)` |
| 5900-5913 | `retry_target_dispatch` | `@workflow.signal` | `retry_target_dispatch` | `RetryTargetDispatchPayload` |
| 5915-5922 | `pending_dispatch_payload` | `@workflow.query` | `pending_dispatch_payload` | → `list[PendingDispatchEntry]` |
| 5924-5939 | `pending_target_dispatch_payload` | `@workflow.query` | `pending_target_dispatch_payload` | → `list[PendingTargetDispatchEntry]` |
| 5941-5945 | `dispatch_results` | `@workflow.query` | `dispatch_results` | → `list[DispatchTargetStatus]` |
| 5951-5962 | `get_status` | `@workflow.query` | `get_status` | → `WorkflowStatusResponse` |
| 5965-5968 | module-tail keep-alive | module statements | — | — |

So: **8 signals, 4 queries, 2 plain helpers, 1 module tail.** Plus the six inherited HIL
signals from `HILSignalsMixin` (`approve_plan`, `provide_plan_feedback`, `approve_research`,
`provide_feedback`, `approve`, `cancel_workflow`) which are live on this class **but defined in
`_HILSignalsMixin.md`** — only `cancel_workflow` (→ `self.cancelled`) matters to this file's
predicates.

---

## 1. STATE consumed/mutated by handlers in scope

All vars below are set in `__init__` (`wave_rationalization.py:1087-1236`, owned by the
state-spec sibling file). Re-tabulated here ONLY for the vars these handlers read or write,
with the exact line each handler touches them.

| Var | Type | Initial | Mutated by (this file) | Consumed by (run body, sibling files) |
|-----|------|---------|------------------------|----------------------------------------|
| `_merge_retry_signalled` | `bool` | `False` (`:1183`) | `merge_retry` → `True` (`:5611`) | merge-blocked loop predicate `lambda: self._merge_retry_signalled or self.cancelled` (`:5599`); reset to `False` at `:5591` before each `set_gate_merge_blocked` wait |
| `_gate_id_to_key` | `dict[str,str]` | `{}` (`:1116`) | `_register_gate_key` writes `[gate_id]=gate_key` (`:5625`) | `gate_approved` / `gate_rejected` look up `signal.gate_id` (`:5653`,`:5677`) |
| `_pending_signals_by_gate_id` | `dict[str, list[tuple]]` | `{}` (`:1128`) | `_register_gate_key` `.pop(gate_id,[])` (`:5626`); `gate_approved`/`gate_rejected` `.setdefault(...).append(entry)` on miss (`:5655`,`:5679`) | drained into `_gate_decisions` by `_register_gate_key` (`:5628-5629`) |
| `_gate_decisions` | `dict[str, list[tuple]]` | `{}` (`:1106`) | `_register_gate_key` `.setdefault(gate_key,[]).extend(pending)` (`:5628-5629`); `gate_approved`/`gate_rejected` `.setdefault(gate_key,[]).append(entry)` on hit (`:5659`,`:5683`) | `_wait_for_gate` predicate `lambda: len(self._gate_decisions[gate_key]) > consumed or self.cancelled` (`:5273`) |
| `_cancel_all_children_requested` | `bool` | `False` (`:1202`) | `cancel_all_children` → `True` (`:5721`) | dispatch loop break condition (sibling file) |
| `_architecture_child_handles` | `list[tuple[str, Any]]` | `[]` (`:1197`) | `cancel_all_children` iterates then sets `= []` (`:5724`,`:5746`) | populated by dispatch path as children spawn (sibling file) |
| `_status` | `WorkflowStatus` | `PENDING` (`:1093`) | `cancel_all_children` → `CANCELLED` (`:5752`) | `get_status` query (`:5955`) |
| `_current_step` | `str` | `""` (`:1094`) | `cancel_all_children` → `"cancelled"` (`:5753`) | `get_status` query (`:5957`) |
| `_tier1_approved_apps` | `set[str]` | `set()` (`:1151`) | `stakeholder_approved` `.add(app_id)` (`:5772`) | per-app classify coroutine predicate `lambda: app_id in self._tier1_approved_apps or self.cancelled` (`:3701`); `tier_1_approved=` arg (`:3873`) |
| `_tier1_approval_records` | `dict[str, dict[str,str]]` | `{}` (`:1150`) | `stakeholder_approved` writes full record (`:5777-5783`) | G-DA evidence builder iterates `sorted(self._tier1_approval_records)` (`:2876`,`:5471`) |
| `_stakeholder_approved` | `bool` | `False` (`:1133`) | `stakeholder_approved` → `True` (`:5785`) | G-DA dual-signal wait `lambda: self._stakeholder_approved or self.cancelled` (`:2910`); reset `False` at `:2915`,`:2935` |
| `_stakeholder_info` | `str` | `""` (`:1134`) | `stakeholder_approved` → `f"{stakeholder} approved scope: {scope}"` (`:5786`) | observability only |
| `_v2_dispatch_meta` | `dict[str, dict[str,str]]` | `{}` (`:1231`) | `dispatch_architecture` & `dispatch_architecture_v2` → `_extract_v2_metadata(payload)` (`:5811`,`:5837`) | `_init_dispatch_status` (`:4086`), `_provision_one_target` (`:4273`) |
| `_dispatch_payload` | `DispatchArchitecturePayload \| None` | `None` (`:1209`) | both dispatch signals → `_normalize_dispatch_payload(payload)` (`:5813`,`:5839`) | `_run_architecture_dispatch` reads at `:4502`; retry drain reads `.targets` (`:4696-4697`) |
| `_dispatch_received` | `bool` | `False` (`:1208`) | both dispatch signals → `True` (`:5814`,`:5840`) | pre-dispatch hold predicate `lambda: self._dispatch_received or self.cancelled` (`:4498`) |
| `_pending_retries` | `list[RetryTargetDispatchPayload]` | `[]` (`:1236`) | `retry_target_dispatch` `.append(payload)` (`:5912`) | retry drain loop `while self._pending_retries: ... .pop(0)` (`:4677-4678`) |
| `_pending_dispatch_entries` | `list[PendingDispatchEntry]` | `[]` (`:1217`) | NOT written here (written by run body `:4479`) | returned by `pending_dispatch_payload` query (`:5922`) |
| `_pending_target_dispatch_entries` | `list[PendingTargetDispatchEntry]` | `[]` (`:1224`) | NOT written here (written by run body `:4486`) | returned by `pending_target_dispatch_payload` query (`:5939`) |
| `_dispatch_status` | `dict[str, DispatchTargetStatus]` | `{}` (`:1212`) | NOT written here | returned by `dispatch_results` query (`:5945`) |
| `_progress_pct` | `float` | `0.0` (`:1095`) | NOT written here | `get_status` (`:5958`) |
| `_pending_gate` | `GateType \| None` | `None` (`:1096`) | NOT written here | `get_status` (`:5959`) |
| `_started_at` | `str` | `""` (`:1097`) | NOT written here | `get_status` (`:5960`) |
| `_updated_at` | `str` | `""` (`:1098`) | written by EVERY handler in scope via `_now_iso()` | `get_status` (`:5961`) |
| `_wave_id` | `str` | `""` (`:1089`) | NOT written here | logged by `cancel_all_children` (`:5729`,`:5739`) |
| `cancelled` | `bool` | `False` (inherited, `HILSignalsMixin.__init__`) | NOT written here (set by inherited `cancel_workflow`) | every blocking predicate ORs it in |

> ⚠️ **GOTCHA-A (`_updated_at` is touched by literally every handler):** all eight signals and
> `_register_gate_key` (conditionally) write `self._updated_at = _now_iso()` as their final
> statement. `_now_iso()` calls `workflow.now()` (`:135`), which IS replay-deterministic, so
> this is safe. The **queries do NOT** write `_updated_at` (queries must be side-effect-free —
> Temporal forbids state mutation in query handlers). A rebuild MUST keep `_updated_at` writes
> in signals and MUST NOT add them to queries.

---

## 2. SIGNAL HANDLERS — each reproduced verbatim with branches

### 2.1 `merge_retry(self, signal: GateMergeRetrySignal) -> None` — `:5608-5612`

Payload `GateMergeRetrySignal` (`olympus-contracts/.../signals.py:71-89`): `gate_id: str`,
`retried_by: str`, `note: Optional[str] = None`. **Only the flag is set — no payload field is
read.**

```text
@workflow.signal
async def merge_retry(self, signal):                      # :5608-5609
    # W17 / P5-S17.4 — reviewer retry on merge_blocked gate.
    self._merge_retry_signalled = True                    # :5611
    self._updated_at = _now_iso()                         # :5612
```

**No branches.** Buffers nothing structured; flips one flag.

**Consumer (sibling file, `_reconcile_and_merge_with_retry_loop`-equivalent, `:5551-5602`):**
the merge loop catches a `MergeConflict` / `MergeDivergenceUnresolved` /
`MergeBranchProtectionRejected` `ApplicationError`, sets `self._merge_retry_signalled = False`
(`:5591`), calls `set_gate_merge_blocked` activity (`:5592-5597`), then blocks on
`await workflow.wait_condition(lambda: self._merge_retry_signalled or self.cancelled)`
(`:5598-5600`). If `self.cancelled` it `return`s (`:5601-5602`); otherwise loops back to retry
`reconcile_and_merge_pr`.

> ⚠️ **GOTCHA-B (reset-before-wait, set-after-block — the canonical re-arm pattern):** the
> consumer sets `_merge_retry_signalled = False` **immediately before** entering the
> `wait_condition`, NOT inside `merge_retry`. So the handler is pure latch-on; the loop
> re-arms. If a rebuild moved the reset into the handler, or forgot the `:5591` reset, a stale
> `True` from a previous merge-block would make the second `wait_condition` fall straight
> through (immediate re-merge without reviewer action). Keep reset at the loop, set in the
> handler. The handler does NOT read `signal.gate_id` — a `merge_retry` for ANY gate unblocks
> the single in-flight merge wait. (There is at most one merge in flight per gate sequence in
> this workflow, so this is correct but globally-scoped.)

---

### 2.2 `_register_gate_key(self, gate_id, gate_key) -> None` — `:5614-5630` (plain method)

NOT a signal/query — a normal method called by the run body at each gate-record-create site:
`_register_gate_key(gate_record.gate_id, "G-RR")` (`:2030`) and
`_register_gate_key(gate_record.gate_id, "G-DA")` (`:2681`). It bridges the UUID→key gap so
signals that arrived **before** the gate record existed get flushed into the right queue.

```text
def _register_gate_key(self, gate_id, gate_key):                 # :5614
    self._gate_id_to_key[gate_id] = gate_key                     # :5625
    pending = self._pending_signals_by_gate_id.pop(gate_id, [])  # :5626  ← removes buffer
    if pending:                                                  # :5627  ← BRANCH 1
        queue = self._gate_decisions.setdefault(gate_key, [])    # :5628
        queue.extend(pending)                                    # :5629  ← preserves arrival order
        self._updated_at = _now_iso()                            # :5630
    # else: nothing buffered → no _updated_at write
```

**Branch count: 1** (`if pending:`). On the false branch (`pending == []`) NOTHING happens
except the mapping write at `:5625` — note `_updated_at` is NOT bumped on the empty path.

> ⚠️ **GOTCHA-C (ordering: mapping write THEN buffer pop THEN extend):** the sequence at
> `:5625-5629` is load-bearing. `_gate_id_to_key[gate_id] = gate_key` MUST happen first so that
> any signal handler running in the **same workflow task batch after** this call sees the
> mapping and routes directly to `_gate_decisions` instead of re-buffering. Then `.pop` removes
> the buffer entry (so it's not double-counted), then `.extend` appends the buffered decisions
> **in arrival order** (list order preserved). A rebuild that pops before writing the mapping,
> or that uses a dict/set for the buffer, breaks FIFO decision ordering — and
> `_wait_for_gate` consumes decisions by **index** (`_gate_decisions[gate_key][consumed]`,
> `:5279`), so order is behaviorally observable (first decision wins the first wait).

> ⚠️ **GOTCHA-D (must be called at EVERY gate-create site, exactly once per gate):** if a
> rebuild creates a gate record but forgets `_register_gate_key`, any `gate_approved` /
> `gate_rejected` for that gate is buffered forever and `_wait_for_gate` hangs until SLA / cancel
> (the exact bug the docstring at `:5618-5623` says this fixes). Called at `:2030` (G-RR) and
> `:2681` (G-DA) only.

---

### 2.3 `gate_approved(self, signal: GateApprovedSignal) -> None` — `:5632-5660`

Payload `GateApprovedSignal` (`signals.py:24-43`): `gate_id: str`, `approved_by: str`,
`justification: str=""`, `card_decisions: List[dict]=[]`, `reviewer_notes: Optional[str]=None`.

```text
@workflow.signal
async def gate_approved(self, signal):                       # :5632-5633
    entry = (                                                 # :5646-5652  ← 5-TUPLE
        GateStatus.APPROVED,                                 #   [0] status
        signal.approved_by,                                  #   [1] actor
        signal.justification,                                #   [2] reason/justification
        None,                                                #   [3] reason_category (always None on approve)
        [],                                                  #   [4] card_decisions (always [] on approve)
    )
    gate_key = self._gate_id_to_key.get(signal.gate_id)      # :5653
    if gate_key is None:                                     # :5654  ← BRANCH 1 (race: gate not yet created)
        self._pending_signals_by_gate_id.setdefault(         # :5655-5657
            signal.gate_id, []
        ).append(entry)
    else:                                                    # :5658  ← BRANCH 2 (mapping known)
        self._gate_decisions.setdefault(gate_key, []).append(entry)  # :5659
    self._updated_at = _now_iso()                            # :5660
```

**Branch count: 2** (`if gate_key is None / else`).

> ⚠️ **GOTCHA-E (the approval entry is a FIXED 5-tuple; `card_decisions`/`reviewer_notes` from
> the payload are DISCARDED):** even though `GateApprovedSignal` carries `card_decisions` and
> `reviewer_notes`, the entry tuple hard-codes index [3]=`None` and index [4]=`[]`
> (`:5650-5651`). Only `approved_by` and `justification` are propagated. The 5-tuple shape
> matches what `_wait_for_gate` unpacks at `:5283-5284`
> (`decision, actor, reason, reason_category, card_decisions = entry`). A rebuild MUST emit a
> 5-tuple in this exact order; emitting a 3-tuple would force `_wait_for_gate` down its legacy
> `len(entry)==... else` branch (`:5285-5288`) which still works but loses the explicit
> `reason_category=None`. ⚠️ This handler **MUST NOT** be overridden to forward
> `card_decisions` on approve — the consumer only acts on reject-side card decisions, and an
> approve carrying cards would confuse rework routing.

---

### 2.4 `gate_rejected(self, signal: GateRejectedSignal) -> None` — `:5662-5684`

Payload `GateRejectedSignal` (`signals.py:46-68`): `gate_id: str`, `rejected_by: str`,
`reason: str`, `reason_category: Optional[str]=None`, `card_decisions: List[dict]=[]`,
`reviewer_notes: Optional[str]=None`.

```text
@workflow.signal
async def gate_rejected(self, signal):                              # :5662-5663
    card_decisions = list(getattr(signal, "card_decisions", []) or [])  # :5668  ← defensive coalesce
    reason_category = getattr(signal, "reason_category", None)          # :5669  ← defensive getattr
    entry = (                                                       # :5670-5676  ← 5-TUPLE
        GateStatus.REJECTED,                                        #   [0] status
        signal.rejected_by,                                         #   [1] actor
        signal.reason,                                              #   [2] reason text
        reason_category,                                            #   [3] reason_category (forwarded!)
        card_decisions,                                             #   [4] card_decisions (forwarded!)
    )
    gate_key = self._gate_id_to_key.get(signal.gate_id)             # :5677
    if gate_key is None:                                            # :5678  ← BRANCH 1 (race)
        self._pending_signals_by_gate_id.setdefault(               # :5679-5681
            signal.gate_id, []
        ).append(entry)
    else:                                                           # :5682  ← BRANCH 2 (mapping known)
        self._gate_decisions.setdefault(gate_key, []).append(entry)  # :5683
    self._updated_at = _now_iso()                                  # :5684
```

**Branch count: 2** (`if gate_key is None / else`). Plus two `getattr(...) ... or []` / `getattr(..., None)`
defensive coalesces at `:5668-5669` (each a short-circuit boolean, not an `if`, but
behaviorally equivalent to a branch — `card_decisions` is `[]` if attr missing OR falsy).

> ⚠️ **GOTCHA-F (reject DOES forward `reason_category` + `card_decisions`; approve does NOT —
> asymmetric on purpose):** contrast `:5650-5651` (approve hard-codes `None`/`[]`) with
> `:5674-5675` (reject forwards the real values). The rejection's `reason_category` and
> `card_decisions` flow through `_wait_for_gate` (`:5284`) into the **rework dispatch** so the
> next disposition-recommender / redundancy run sees structured per-card feedback (the
> downstream sibling-file rework path reads `self._rework_feedback`). A rebuild MUST preserve
> this asymmetry; folding the two handlers into one shared shape that always forwards cards
> would leak card decisions into approvals.

> ⚠️ **GOTCHA-G (`getattr` defensive reads — the payload may be a dict or an older dataclass):**
> `:5668-5669` use `getattr(signal, "card_decisions", [])` rather than `signal.card_decisions`.
> This tolerates a signal delivered as a pre-W8 `GateRejectedSignal` (no `card_decisions`
> field) without `AttributeError`. The `... or []` further coalesces an explicit `None`. A
> rebuild MUST use `getattr` with defaults here, NOT direct attribute access, or replaying an
> old history with a thinner payload will crash the handler. (Note `gate_approved` at
> `:5648-5651` does NOT use `getattr` because it never reads those fields at all.)

---

### 2.5 `cancel_all_children(self) -> None` — `:5686-5753` (zero-arg signal)

The single most branch-heavy handler in scope. Backs the wave fan-out banner "Cancel All".

```text
@workflow.signal
async def cancel_all_children(self):                              # :5686-5687
    # --- PATCH GUARD (early return) ---
    if not workflow.patched(                                      # :5716-5718  ← BRANCH 1
        "wave-rationalization-architecture-dispatch-v1"
    ):
        return                                                    # :5719  ← inert no-op for legacy workflows

    self._cancel_all_children_requested = True                   # :5721
    self._updated_at = _now_iso()                                # :5722

    # --- CANCEL EVERY LIVE CHILD HANDLE ---
    for child_id, handle in self._architecture_child_handles:    # :5724  ← LOOP
        try:                                                     # :5725
            await handle.cancel()                                # :5726  ← the only await in scope
            workflow.logger.info(                                # :5727-5731
                "wave_rationalization.cancel_all_children.cancelled_child",
                wave_id=self._wave_id,
                child_workflow_id=child_id,
            )
        except Exception as exc:  # noqa: BLE001                 # :5732  ← BRANCH 2 (swallow finished-child error)
            workflow.logger.warning(                             # :5737-5742
                "wave_rationalization.cancel_all_children.child_cancel_failed",
                wave_id=self._wave_id,
                child_workflow_id=child_id,
                error=str(exc),
            )
            # NO re-raise — best-effort sweep, continue loop

    # --- CLEAR HANDLE STORE + PROJECT CANCELLED STATUS ---
    self._architecture_child_handles = []                        # :5746
    self._status = WorkflowStatus.CANCELLED                      # :5752
    self._current_step = "cancelled"                             # :5753
```

**Branch count: 2** (`if not workflow.patched(...)` early-return; `try/except Exception`
inside the loop) + the `for` loop. If `_architecture_child_handles == []` (the legacy /
pre-dispatch case), the loop body never executes and the cancels are a no-op even past the
patch guard.

> ⚠️ **GOTCHA-H (`workflow.patched("wave-rationalization-architecture-dispatch-v1")` gate is a
> DETERMINISM REQUIREMENT, not just a feature flag):** the early `return` at `:5716-5719` is
> guarded by `workflow.patched(...)`. Workflows that **started before** the dispatch path
> landed have no child handles and MUST treat the signal as a pure no-op; replaying their
> history must NOT execute the cancel loop or the status flip. A rebuild MUST use the SAME
> patch id string `"wave-rationalization-architecture-dispatch-v1"` and MUST gate the entire
> body behind it. Changing the patch id or removing the guard re-writes the replay decision and
> breaks in-flight pre-patch workflows.

> ⚠️ **GOTCHA-I (`except Exception` is intentional and MUST swallow):** `await handle.cancel()`
> on an already-completed child raises (the comment at `:5732-5736` says "tolerate finished
> children"). The handler catches **bare `Exception`** (`noqa: BLE001`), logs a warning, and
> **continues the loop** — it does NOT re-raise. This guarantees one finished child doesn't
> abort the remaining cancellations. A rebuild MUST NOT narrow this to a specific exception
> type (Temporal's cancel-of-finished error type is not part of the contract) and MUST NOT
> re-raise. Idempotency: Temporal cancels are idempotent, so re-delivering `cancel_all_children`
> is safe — but `:5746` clears the handle list so a second delivery finds nothing to cancel.

> ⚠️ **GOTCHA-J (this handler does the only `await` of any in-scope handler, and it sets
> terminal status `CANCELLED` WITHOUT tearing down `run()`):** the docstring (`:5703-5707`) is
> explicit — `run()`'s own loop is NOT torn down here; the full orchestrator teardown is the
> `/waves/{id}/cancel-rationalization` path. `cancel_all_children` flips `_status=CANCELLED` and
> `_current_step="cancelled"` as a **best-effort DB/UI projection** (visible via `get_status`),
> aborts the children, clears handles, and returns. Setting `_status=CANCELLED` here does NOT
> set `self.cancelled` — so the run body's `wait_condition`s that OR in `self.cancelled` are
> **NOT** released by this handler. (To actually unblock those, the caller sends the inherited
> `cancel_workflow` signal.) A rebuild MUST keep these two effects separate: `cancel_all_children`
> aborts children + projects status; `cancel_workflow` releases the run loop.

> ⚠️ **GOTCHA-K (status flip is unconditional — no DB activity, deliberately):** the comment at
> `:5747-5751` notes the status transition is a best-effort projection done purely in-memory
> (no `update_wave_status` activity call). This is intentional so the handler stays a pure
> in-process mutation + child-cancel and can't itself fail on a DB hiccup. A rebuild MUST NOT
> add an activity call to persist the status here — the load-bearing behavior is the child
> cancellation; the status is read from the workflow's `get_status` query.

---

### 2.6 `stakeholder_approved(self, signal: StakeholderApprovedSignal) -> None` — `:5755-5787`

Payload `StakeholderApprovedSignal` (`types.py:164-170`): `approval_id: str`,
`stakeholder: str`, `scope: str`. Dispatches on `signal.scope`.

```text
@workflow.signal
async def stakeholder_approved(self, signal):                     # :5755-5756
    if signal.scope == "tier-1-classification":                   # :5766  ← BRANCH 1 (tier-1 path)
        prefix = "tier1-"                                         # :5768
        if signal.approval_id.startswith(prefix):                # :5769  ← BRANCH 1a (id parse guard)
            remainder = signal.approval_id[len(prefix):]         # :5770
            app_id = (                                            # :5771  ← BRANCH 1a-i (inline ternary)
                remainder.rsplit("-", 1)[0]
                if "-" in remainder
                else remainder
            )
            self._tier1_approved_apps.add(app_id)                # :5772
            self._tier1_approval_records[app_id] = {             # :5777-5783  ← last-write-per-app wins
                "app_id": app_id,
                "approval_id": signal.approval_id,
                "stakeholder": signal.stakeholder,
                "scope": signal.scope,
                "approved_at": _now_iso(),
            }
        # else (approval_id has no "tier1-" prefix): SILENTLY IGNORED — no app recorded
    else:                                                         # :5784  ← BRANCH 2 (g-da / anything else)
        self._stakeholder_approved = True                        # :5785
        self._stakeholder_info = (                               # :5786
            f"{signal.stakeholder} approved scope: {signal.scope}"
        )
    self._updated_at = _now_iso()                                # :5787
```

**Branch count: 3** (`if scope == "tier-1-classification"` / `else`; nested
`if approval_id.startswith("tier1-")`; inline ternary `... if "-" in remainder else ...`).

**Scope routing (each case explicitly):**
- `scope == "tier-1-classification"`: parse `app_id` out of the `approval_id` (convention
  `tier1-{app_id}-{n}`). Add to `_tier1_approved_apps` set; record full approval dict. This
  unblocks the per-app classify coroutine waiting at
  `lambda: app_id in self._tier1_approved_apps or self.cancelled` (`:3701`).
- `scope == "tier-1-classification"` BUT `approval_id` does NOT start with `"tier1-"`: the
  inner `if` is false → **nothing happens** (no app added, no record). Only `_updated_at` is
  bumped. ⚠️ a tier-1 approval with a malformed `approval_id` is silently dropped.
- **any other scope** (`"g-da"`, `""`, arbitrary): set `_stakeholder_approved=True` +
  `_stakeholder_info`. Unblocks the G-DA dual-signal wait
  `lambda: self._stakeholder_approved or self.cancelled` (`:2910`).

> ⚠️ **GOTCHA-L (`app_id` parse: `rsplit("-", 1)[0]` strips the trailing `-{n}` suffix, but
> ONLY if a `-` remains after stripping the `tier1-` prefix):** for `approval_id="tier1-foo-3"`,
> `remainder="foo-3"`, `"-" in remainder` true → `app_id="foo"`. For
> `approval_id="tier1-foo"` (no numeric suffix), `remainder="foo"`, `"-" in remainder` false →
> `app_id="foo"`. ⚠️ For `approval_id="tier1-my-app-3"`, `remainder="my-app-3"` →
> `rsplit("-",1)[0]="my-app"` — i.e. an app_id containing a hyphen is reconstructed correctly
> as long as the trailing token is the `{n}` counter. A rebuild MUST use `rsplit("-", 1)`
> (split from the right, maxsplit 1), NOT `split("-")`, or hyphenated app_ids break. The
> matching `add()`'d `app_id` must EXACTLY equal the `app_id` the classify coroutine waits on
> (`:3701`), so any divergence in this parse hangs that coroutine.

> ⚠️ **GOTCHA-M (last-write-per-app wins for `_tier1_approval_records`; the set is the derived
> gate):** the dict assignment at `:5777` overwrites any prior record for the same `app_id`
> (comment `:5775-5776`: "Last write per app wins"). The **set** `_tier1_approved_apps` is the
> idempotent membership gate the wait predicate uses; the **dict** is richer evidence surfaced
> to the G-DA gate-pre-review skill (`:2876`,`:5471`). A rebuild MUST keep both structures in
> sync: every `.add()` to the set MUST be paired with a record write to the dict (and vice
> versa) — they are written together at `:5772` + `:5777`.

> ⚠️ **GOTCHA-N (`_stakeholder_approved` is re-armed by the run body, not here):** the G-DA path
> reads `_stakeholder_approved`, then resets it to `False` (`:2915`, `:2935`) so a subsequent
> rework cycle waits for a fresh signal. This handler only ever SETS `True`. Same re-arm
> discipline as `merge_retry` (GOTCHA-B). A rebuild MUST NOT reset `_stakeholder_approved`
> inside the handler.

---

### 2.7 `dispatch_architecture(self, payload: DispatchArchitecturePayload) -> None` — `:5793-5815`

Legacy v1 entry point. Payload `DispatchArchitecturePayload` (`types.py:1982-2002`):
`targets: list[DispatchArchitectureTargetConfig]`.

```text
@workflow.signal
async def dispatch_architecture(self, payload):                   # :5793-5795
    self._v2_dispatch_meta = self._extract_v2_metadata(payload)   # :5811
    normalized = self._normalize_dispatch_payload(payload)        # :5812
    self._dispatch_payload = normalized                           # :5813
    self._dispatch_received = True                                # :5814
    self._updated_at = _now_iso()                                 # :5815
```

**No branches in the handler itself** (the branching lives in `_extract_v2_metadata` §2.9 and
`_normalize_dispatch_payload`, sibling file `:4100-4202`). Setting `_dispatch_received=True`
trips the pre-dispatch hold predicate `lambda: self._dispatch_received or self.cancelled`
(`:4498`).

> ⚠️ **GOTCHA-O (v1 handler still calls `_extract_v2_metadata`, which returns `{}` for v1
> payloads):** even the legacy v1 signal runs `_extract_v2_metadata(payload)` (`:5811`). For a
> genuine v1 `DispatchArchitecturePayload`, `_extract_v2_metadata` returns `{}` (no
> `target_app_id` to key on — see §2.9 branch logic), so `_v2_dispatch_meta` is correctly
> empty. A rebuild MUST call `_extract_v2_metadata` on BOTH handlers identically; the v2-vs-v1
> discrimination is inside the helper, not at the call site.

---

### 2.8 `dispatch_architecture_v2(self, payload: DispatchArchitecturePayloadV2) -> None` — `:5817-5841`

Wave-scoped target-keyed entry point. Payload `DispatchArchitecturePayloadV2`
(`types.py:2042-2054`): `targets: list[DispatchArchitectureTarget]`.

```text
@workflow.signal
async def dispatch_architecture_v2(self, payload):                # :5817-5819
    self._v2_dispatch_meta = self._extract_v2_metadata(payload)   # :5837
    normalized = self._normalize_dispatch_payload(payload)        # :5838
    self._dispatch_payload = normalized                           # :5839
    self._dispatch_received = True                                # :5840
    self._updated_at = _now_iso()                                 # :5841
```

**No branches in the handler itself.** Body is **byte-identical to `dispatch_architecture`**
(`:5811-5815` ≡ `:5837-5841`) — the ONLY difference is the declared payload type annotation.

> ⚠️ **GOTCHA-P (two separate signal handlers exist SOLELY so the Temporal payload converter
> preserves v2 fields):** the docstring (`:5821-5836`) is the whole reason for the duplication.
> If a v2 wire payload were delivered to the v1 `dispatch_architecture` handler (annotated
> `DispatchArchitecturePayload`), the converter would coerce it through the v1 source-keyed
> dataclass and **silently drop** `target_app_id` / `target_service_id` / `source_app_ids`.
> Declaring a second handler with the `DispatchArchitecturePayloadV2` annotation makes the
> converter materialize the v2 dataclass intact. Both then normalize to a single v1 canonical
> shape via `_normalize_dispatch_payload`. A rebuild MUST register BOTH signals under their
> distinct wire names (`dispatch_architecture`, `dispatch_architecture_v2`) with their distinct
> type annotations — collapsing them to one handler re-introduces the field-drop bug. Both set
> `_dispatch_received=True`, so whichever the client sends trips the same hold.

---

### 2.9 `_extract_v2_metadata(payload: object) -> dict[str, dict[str, str]]` — `:5843-5898` (`@staticmethod`)

NOT a signal. Pulls v2-only `target_service_id` + `relationship`, keyed by `target_app_id`.
Called by both dispatch signals (`:5811`,`:5837`).

```text
@staticmethod
def _extract_v2_metadata(payload):                                # :5843-5844
    out: dict[str, dict[str, str]] = {}                           # :5860
    # --- DATACLASS v2 PATH ---
    if isinstance(payload, DispatchArchitecturePayloadV2):        # :5862  ← BRANCH 1
        for t in payload.targets:                                 # :5863  ← LOOP
            if not t.target_app_id:                               # :5864  ← BRANCH 1a (skip keyless)
                continue
            out[t.target_app_id] = {                              # :5866-5876
                "target_app_id": t.target_app_id,
                "target_service_id": t.target_service_id,
                "relationship": _normalize_relationship(t.relationship),  # :5875
            }
        return out                                                # :5877  ← EARLY RETURN
    # --- WIRE-FORM DICT PATH ---
    if isinstance(payload, dict):                                 # :5879  ← BRANCH 2
        raw_targets = payload.get("targets", [])                  # :5880
        if isinstance(raw_targets, list):                         # :5881  ← BRANCH 2a
            for t in raw_targets:                                 # :5882  ← LOOP
                if not isinstance(t, dict):                       # :5883  ← BRANCH 2a-i (skip non-dict)
                    continue
                target_app_id = str(t.get("target_app_id") or "") # :5885
                if not target_app_id:                             # :5886  ← BRANCH 2a-ii (v1 entry, skip)
                    continue
                out[target_app_id] = {                            # :5889-5897
                    "target_app_id": target_app_id,
                    "target_service_id": str(t.get("target_service_id") or ""),
                    "relationship": _normalize_relationship(t.get("relationship")),  # :5894
                }
    return out                                                    # :5898  ← falls through for v1 dataclass / unknown → {}
```

**Branch count: 6** — `isinstance(payload, DispatchArchitecturePayloadV2)` (1);
`if not t.target_app_id` (1a); `isinstance(payload, dict)` (2);
`isinstance(raw_targets, list)` (2a); `if not isinstance(t, dict)` (2a-i);
`if not target_app_id` (2a-ii). Plus two `... or ""` coalesces at `:5885`,`:5892`.

> ⚠️ **GOTCHA-Q (keyed by `target_app_id`, NOT `source_app_ids[0]` — fixes PR #495
> last-write-wins collision):** the docstring (`:5849-5858`) documents the historical bug:
> pre-fix this dict was keyed by the anchor source app, so when N targets share an anchor
> source (capability-grain rationalization), 11 of 12 targets got the wrong
> `target_service_id`. Keying by the unique `target_app_id` (SF3 slug, e.g.
> `"s1-unified-pilot-identity"`) restores per-target uniqueness. A rebuild MUST key by
> `target_app_id`. Entries with a falsy `target_app_id` are SKIPPED (`continue` at `:5864`,
> `:5886`) — that's the v1-entry signal (v1 has no `target_app_id`).

> ⚠️ **GOTCHA-R (`relationship` ALWAYS routed through `_normalize_relationship`):** both the
> dataclass path (`:5875`) and the dict path (`:5894`) wrap `relationship` in
> `_normalize_relationship(...)` (defined `:138-155`: `"" ` for None/empty/whitespace; else
> `.strip().lower()`). The comment (`:5870-5875`) is explicit: this is so "a stray uppercase
> value can't slip past the case check" downstream. A rebuild MUST normalize `relationship`
> here; `target_service_id` is NOT normalized (kept verbatim as the SF3 catalog id).

> ⚠️ **GOTCHA-S (v1 dataclass falls through to `return {}` at :5898):** a genuine
> `DispatchArchitecturePayload` (v1) is neither a `DispatchArchitecturePayloadV2` (branch 1
> false) nor a `dict` (branch 2 false), so it skips both blocks and returns the empty `out`
> initialized at `:5860`. This is why `dispatch_architecture` (v1) gets an empty
> `_v2_dispatch_meta` (GOTCHA-O). An "unknown" payload object also returns `{}`. A rebuild MUST
> NOT raise on unrecognized payload types — return the empty dict.

---

### 2.10 `retry_target_dispatch(self, payload: RetryTargetDispatchPayload) -> None` — `:5900-5913`

Payload `RetryTargetDispatchPayload` (`types.py:2057-2069`): `source_app_id: str`,
`target_app_name: str`, `target_repo: str`, `default_branch: str="main"`.

```text
@workflow.signal
async def retry_target_dispatch(self, payload):                   # :5900-5902
    if isinstance(payload, dict):                                 # :5910  ← BRANCH 1 (wire-form coercion)
        payload = RetryTargetDispatchPayload(**payload)           # :5911
    self._pending_retries.append(payload)                         # :5912
    self._updated_at = _now_iso()                                 # :5913
```

**Branch count: 1** (`if isinstance(payload, dict)`). If the converter delivered a raw dict
(wire form), re-hydrate into the dataclass via `**payload` kwargs splat; otherwise use as-is.

**Consumer:** the run body's retry-drain loop (sibling file, `:4677-4712`):
`while self._pending_retries: retry = self._pending_retries.pop(0)` — sequential FIFO drain
**after** the initial `asyncio.gather` of provisioning completes. Each retry looks up
`self._dispatch_status.get(retry.source_app_id)` (`:4685`) and the original cfg in
`self._dispatch_payload.targets` (`:4696-4700`) to reuse the disposition + peer set.

> ⚠️ **GOTCHA-T (FIFO via `.append` + `.pop(0)`, NOT a stack):** the handler appends to the
> tail (`:5912`) and the drain pops from the head (`:4678`). Retries are processed in arrival
> order. A rebuild MUST use `.append` here and `.pop(0)` (or equivalent FIFO) in the drain —
> a `.pop()` (LIFO) would reorder retries. The drain is sequential, not gathered (comment
> `:4671-4675`: "Retries run sequentially").

> ⚠️ **GOTCHA-U (`**payload` splat requires field-name match — v2 retries are unsupported):**
> the dict-coercion at `:5911` does `RetryTargetDispatchPayload(**payload)`, so a wire dict with
> keys outside `{source_app_id, target_app_name, target_repo, default_branch}` raises
> `TypeError`. The drain path is **v1-only** (comment `:4679-4684`: "the retry path is v1-only,
> a known v2 gap") — `_dispatch_status` may be keyed by `target_app_id` (v2) but the retry
> payload carries only the v1 `source_app_id`, so a v2 retry would miss the status lookup
> (`status is None` → logged + `continue` at `:4686-4691`). A rebuild MUST reproduce the v1-only
> retry behavior; do not "fix" it to accept target_app_id.

---

## 3. QUERY HANDLERS — each reproduced verbatim

All four are synchronous `def` (queries cannot be `async`-blocking and MUST NOT mutate state).
None bump `_updated_at` (GOTCHA-A).

### 3.1 `pending_dispatch_payload(self) -> list[PendingDispatchEntry]` — `:5915-5922`

```text
@workflow.query
def pending_dispatch_payload(self):                               # :5915-5916
    return list(self._pending_dispatch_entries)                   # :5922  ← defensive copy
```
Returns a **copy** of `_pending_dispatch_entries`. Empty until the run body reaches the
pre-dispatch hold and sets it at `:4479`. Callers treat empty as "not yet computed / not
awaiting dispatch" (docstring `:5917-5921`). **No branches.**

### 3.2 `pending_target_dispatch_payload(self) -> list[PendingTargetDispatchEntry]` — `:5924-5939`

```text
@workflow.query
def pending_target_dispatch_payload(self):                        # :5924-5927
    return list(self._pending_target_dispatch_entries)            # :5939  ← defensive copy
```
Wave-scoped target-keyed mirror. Empty when the workflow hasn't reached the hold OR the
`architecture-target-plan-v1` patch is inactive (the run body only populates it under that
patch — see `:4482-4490`; the query itself does not check the patch). **No branches.**

### 3.3 `dispatch_results(self) -> list[DispatchTargetStatus]` — `:5941-5945`

```text
@workflow.query
def dispatch_results(self):                                       # :5941-5942
    return list(self._dispatch_status.values())                   # :5945  ← copy of dict VALUES
```
Returns a list of the `_dispatch_status` dict's **values** (one `DispatchTargetStatus` per
target). Powers the fan-out table + retry affordance. The dict may be keyed by `source_app_id`
(v1) or `target_app_id` (v2) but the query exposes only values, so the key scheme is invisible
to callers. **No branches.**

### 3.4 `get_status(self) -> WorkflowStatusResponse` — `:5951-5962`

```text
@workflow.query
def get_status(self):                                             # :5951-5952
    return WorkflowStatusResponse(                                # :5953-5962
        workflow_id=workflow.info().workflow_id,                  # :5954
        status=self._status,                                      # :5955
        current_line=AssemblyLine.RATIONALIZATION,                # :5956  ← HARD-CODED
        current_step=self._current_step,                          # :5957
        progress_pct=self._progress_pct,                          # :5958
        pending_gate=self._pending_gate,                          # :5959
        started_at=self._started_at,                              # :5960
        updated_at=self._updated_at,                              # :5961
    )
```
**No branches.** `current_line` is **always** `AssemblyLine.RATIONALIZATION` (literal, `:5956`).
`workflow_id` is read live from `workflow.info()` (deterministic). All other fields echo
instance state. This is the inline equivalent of `LineWorkflowBase.get_status` — re-declared
here because this workflow does not inherit it (see file header).

> ⚠️ **GOTCHA-V (queries return DEFENSIVE COPIES of mutable collections):** the three list
> queries (`:5922`, `:5939`, `:5945`) all wrap their backing collection in `list(...)`. This
> prevents a caller from mutating workflow state through the returned reference and avoids
> handing out a live view that could change mid-iteration. A rebuild MUST copy; returning the
> raw `self._...` list/`.values()` view risks state corruption or non-deterministic query
> results. ⚠️ Queries MUST remain side-effect-free — no `_now_iso()`, no flag writes (Temporal
> raises if a query mutates state under validation).

---

## 4. The module tail — `:5965-5968`

```text
# Keep the no-op ``update_application_status`` imports alive so worker
# registration picks them up even though this workflow doesn't call
# them directly.
_ = update_application_status                                     # :5967
_ = UpdateAppStatusInput                                          # :5968
```
Two no-op `_ = name` bindings at module scope. Their sole purpose (comment `:5965-5966`) is to
prevent a linter from removing the `update_application_status` activity import and the
`UpdateAppStatusInput` type import (both imported at `:62`, `:120`) — the worker's
registration scan needs the activity symbol importable from this module even though
`WaveRationalizationWorkflow` never calls it directly.

> ⚠️ **GOTCHA-W (these two lines are load-bearing for WORKER REGISTRATION, not for runtime):**
> deleting `_ = update_application_status` / `_ = UpdateAppStatusInput` would let an autofixer
> strip the imports, after which `worker.py`'s activity-discovery sweep over this module would
> miss `update_application_status` and the activity would fail to register on the task queue. A
> rebuild MUST retain both module-level keep-alive bindings (or otherwise guarantee the symbols
> stay importable from this module).

---

## 5. SIGNAL↔PREDICATE consumption map (the contract a rebuild must reproduce exactly)

Each signal's effect is only observable through the run-body `wait_condition` (or loop) that
consumes the flag/queue it mutates. The predicates live in sibling files; reproduced here so a
rebuild keeps the handler↔predicate pairing intact.

| Signal (this file) | Mutates | Consuming predicate / loop (sibling) | Cancel escape? |
|--------------------|---------|--------------------------------------|----------------|
| `merge_retry` | `_merge_retry_signalled=True` (`:5611`) | `wait_condition(lambda: self._merge_retry_signalled or self.cancelled)` (`:5599`) | yes (`or self.cancelled`) |
| `gate_approved`/`gate_rejected` (via `_register_gate_key` flush) | append 5-tuple to `_gate_decisions[gate_key]` | `wait_condition(lambda: len(self._gate_decisions[gate_key]) > consumed or self.cancelled)` (`:5273`) | yes |
| `stakeholder_approved` (tier-1) | `_tier1_approved_apps.add(app_id)` (`:5772`) | `wait_condition(lambda: app_id in self._tier1_approved_apps or self.cancelled)` (`:3701`) | yes |
| `stakeholder_approved` (g-da) | `_stakeholder_approved=True` (`:5785`) | `wait_condition(lambda: self._stakeholder_approved or self.cancelled)` (`:2910`) | yes |
| `dispatch_architecture`/`_v2` | `_dispatch_received=True` (`:5814`/`:5840`) | `wait_condition(lambda: self._dispatch_received or self.cancelled)` (`:4498`) | yes |
| `retry_target_dispatch` | `_pending_retries.append(...)` (`:5912`) | `while self._pending_retries: ...pop(0)` (`:4677`) — drained, NOT awaited | n/a (drain) |
| `cancel_all_children` | aborts children + `_status=CANCELLED` | none — does NOT set `self.cancelled` (GOTCHA-J) | does NOT release run-loop waits |
| inherited `cancel_workflow` | `self.cancelled=True` (HILSignalsMixin) | every predicate above via `or self.cancelled` | the universal kill switch |

> ⚠️ **GOTCHA-X (only `cancel_workflow`, NOT `cancel_all_children`, releases the run loop):**
> reiterating GOTCHA-J in the consumption frame — every blocking predicate ORs in
> `self.cancelled`, which is set ONLY by the inherited `cancel_workflow` signal
> (`HILSignalsMixin`, `signals.py:75-78`). `cancel_all_children` deliberately does **not** touch
> `self.cancelled`; it aborts children and projects `CANCELLED` status but lets the run loop
> sit on its current wait. A rebuild MUST keep these two cancel paths semantically distinct.

---

## 6. RESILIENCE / determinism summary for this file's surface

- **No activities** are invoked by any handler in scope **except** `cancel_all_children`'s
  `await handle.cancel()` (`:5726`), which is a child-workflow cancel RPC (idempotent), NOT an
  `execute_activity`. There are no retry policies, timeouts, or `non_retryable_errors` to spec
  in this file — those belong to the run body / activity sites in sibling files.
- **Determinism:** every handler is replay-safe — only attribute mutations + deterministic
  `workflow.now()` (via `_now_iso()`) + `workflow.patched(...)` (the one patch gate). No
  `random`, no wall-clock, no I/O.
- **Idempotency:** re-delivering any signal is safe. `gate_approved`/`gate_rejected` append a
  new decision tuple each time (the run body consumes by monotonic `consumed` index, so a
  duplicate sits unconsumed harmlessly). `cancel_all_children` clears its handle list so a
  second delivery is a no-op. `dispatch_architecture*` overwrite `_dispatch_payload` /
  `_v2_dispatch_meta` wholesale (last-write-wins). `stakeholder_approved` tier-1 is set-idempotent
  + dict last-write-wins.
- **Buffering / race tolerance:** `_pending_signals_by_gate_id` + `_register_gate_key` are the
  ONLY race-mitigation machinery — they exist solely to tolerate `gate_approved`/`gate_rejected`
  racing ahead of `create_gate_record` (GOTCHA-D).
- **continue-as-new / heartbeats / compensation:** none in scope (run-body concerns).

---

## 7. Behavioral parity checklist

A rebuilt signal/query surface MUST satisfy ALL of the following:

1. The class extends `HILSignalsMixin` (inheriting `approve`, `cancel_workflow`, plan/document
   signals) and **does NOT extend `LineWorkflowBase`**. `get_status`, the gate-decision queue,
   `_register_gate_key`, and the merge-retry latch are declared **inline on this class**.
2. **Exactly 8 `@workflow.signal` handlers** are declared here under the wire names
   `merge_retry`, `gate_approved`, `gate_rejected`, `cancel_all_children`,
   `stakeholder_approved`, `dispatch_architecture`, `dispatch_architecture_v2`,
   `retry_target_dispatch` — plus the 6 inherited HIL signals. All 8 are `async def` and mutate
   only attributes (+ `cancel_all_children`'s `await handle.cancel()`).
3. **Exactly 4 `@workflow.query` handlers**: `pending_dispatch_payload`,
   `pending_target_dispatch_payload`, `dispatch_results`, `get_status`. All `def` (sync), all
   side-effect-free, the three list ones return `list(...)` copies, none write `_updated_at`.
4. `merge_retry` sets `_merge_retry_signalled=True` (only) + `_updated_at`; reads no payload
   field; the **consumer** resets the flag to `False` before each merge-blocked wait (GOTCHA-B).
5. `gate_approved` builds the FIXED 5-tuple `(GateStatus.APPROVED, approved_by, justification,
   None, [])` — index [3]/[4] hard-coded, NOT forwarded from payload (GOTCHA-E); routes via
   `_gate_id_to_key.get`: append to `_gate_decisions[key]` on hit, else buffer in
   `_pending_signals_by_gate_id[gate_id]`.
6. `gate_rejected` builds the 5-tuple `(GateStatus.REJECTED, rejected_by, reason,
   reason_category, card_decisions)` — `reason_category`/`card_decisions` FORWARDED via
   `getattr(..., default)` (GOTCHA-F, GOTCHA-G); same hit/miss routing as `gate_approved`.
7. `_register_gate_key(gate_id, key)` writes the mapping FIRST (`:5625`), then `.pop`s the
   buffer, then `.extend`s `_gate_decisions[key]` with the buffered entries **in order**, and
   bumps `_updated_at` ONLY when the buffer was non-empty (GOTCHA-C). It is called at each
   gate-create site exactly once (G-RR `:2030`, G-DA `:2681`) (GOTCHA-D).
8. `cancel_all_children` early-`return`s if `not workflow.patched(
   "wave-rationalization-architecture-dispatch-v1")` (exact patch id, GOTCHA-H); else sets
   `_cancel_all_children_requested=True`, iterates `_architecture_child_handles` awaiting
   `handle.cancel()` inside a `try/except Exception` that LOGS-AND-CONTINUES (no re-raise,
   GOTCHA-I), then sets `_architecture_child_handles=[]`, `_status=CANCELLED`,
   `_current_step="cancelled"`. It does NOT call any activity and does NOT set `self.cancelled`
   (GOTCHA-J, GOTCHA-K, GOTCHA-X).
9. `stakeholder_approved` branches on `scope == "tier-1-classification"`: parse `app_id` from
   `approval_id` via prefix-strip `"tier1-"` + `rsplit("-", 1)[0] if "-" in remainder else
   remainder` (GOTCHA-L), then `.add` to `_tier1_approved_apps` AND write `_tier1_approval_records[app_id]`
   (paired, last-write-wins, GOTCHA-M); a malformed (non-`tier1-` prefixed) id is silently
   dropped. Any other scope sets `_stakeholder_approved=True` + `_stakeholder_info`. Neither the
   set nor `_stakeholder_approved` is reset in the handler (GOTCHA-N).
10. `dispatch_architecture` and `dispatch_architecture_v2` have **byte-identical bodies**
    (`_v2_dispatch_meta = _extract_v2_metadata(payload)` → `_dispatch_payload =
    _normalize_dispatch_payload(payload)` → `_dispatch_received=True` → `_updated_at`),
    differing ONLY in payload type annotation; both registered as distinct signals so the
    converter preserves v2 fields (GOTCHA-O, GOTCHA-P).
11. `_extract_v2_metadata` returns a dict keyed by `target_app_id` (NOT anchor source,
    GOTCHA-Q), skips entries with falsy `target_app_id` (`continue`), normalizes `relationship`
    via `_normalize_relationship` on both dataclass (`:5875`) and dict (`:5894`) paths
    (GOTCHA-R), keeps `target_service_id` verbatim, and returns `{}` for v1-dataclass / unknown
    payloads (GOTCHA-S). Handles `DispatchArchitecturePayloadV2`, dict, and fall-through.
12. `retry_target_dispatch` coerces a dict payload via `RetryTargetDispatchPayload(**payload)`
    then `.append`s to `_pending_retries` (FIFO with the drain's `.pop(0)`, GOTCHA-T); the
    drain path is v1-only (GOTCHA-U).
13. `get_status` returns a `WorkflowStatusResponse` with `current_line` HARD-CODED to
    `AssemblyLine.RATIONALIZATION` (`:5956`), `workflow_id` from `workflow.info()`, and all
    other fields echoing instance state; no mutation.
14. The module-tail `_ = update_application_status` / `_ = UpdateAppStatusInput` bindings are
    retained so worker registration discovers the activity (GOTCHA-W).
15. Only `cancel_workflow` (inherited) sets `self.cancelled`, which releases every run-loop
    `wait_condition` via its `or self.cancelled` clause; `cancel_all_children` does not
    (GOTCHA-X). The signal↔predicate pairings in §5 must hold exactly.
