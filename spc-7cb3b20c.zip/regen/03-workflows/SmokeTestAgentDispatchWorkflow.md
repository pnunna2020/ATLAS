# `SmokeTestAgentDispatchWorkflow` — Live agent-dispatch smoke test (ATOMIC regeneration spec)

> **Source of truth:** `temporal/olympus_workflows/workflows/smoke_test.py` (93 lines). Every
> `smoke_test.py:line` citation below is against that file.
>
> **What this is:** a **standalone**, single-activity `@workflow.defn` workflow that wraps exactly
> one `dispatch_agent_task` activity call (`smoke_test.py:69-74`). An operator fires it from the
> starter script `temporal/scripts/smoke_test_agent.py` to confirm, end-to-end against a **live**
> Bedrock-backed agent, that the strict-schema validator + retry-with-feedback loop is actually
> firing (`smoke_test.py:1-21`, `35-44`). It is **NOT part of any line orchestration**
> (`smoke_test.py:8`).
>
> ⚠️ **GOTCHA-INHERIT (does NOT inherit `LineWorkflowBase` / `HILSignalsMixin`):** unlike the seven
> per-app line workflows, this class is declared `class SmokeTestAgentDispatchWorkflow:` with **no
> base class** (`smoke_test.py:36`). It therefore has:
> - **NO** `__init__` and **NO instance state** (no `_status`, no `_gate_decisions`, no `cancelled`,
>   none of the 19 base state vars, none of the 8 HIL state vars). See §1.
> - **NO signal handlers** — not the four base gate signals (`gate_approved`, `gate_rejected`,
>   `escalation_resolved`, `merge_retry`), not the six HIL signals (`approve`, `cancel_workflow`,
>   `approve_plan`, `provide_plan_feedback`, `approve_research`, `provide_feedback`). See §2.
> - **NO queries** — not even `get_status`. See §2.
> - **NO gates, NO rework loop, NO merge loop, NO continue-as-new, NO compensation.** See §5/§6.
>
> So none of the inherited contracts from `_LineWorkflowBase.md` / `_HILSignalsMixin.md` apply
> here. The two base specs are referenced ONLY to state explicitly that this workflow shares none
> of that surface. A rebuild that adds any of the above would diverge from parity. **It overrides
> nothing** because it inherits nothing — it is a flat workflow with one `@workflow.run` method.

---

## 0. Imports & determinism (`smoke_test.py:23-32`)

```text
from __future__ import annotations                       # smoke_test.py:23
from datetime import timedelta                            # smoke_test.py:25
from typing import Any                                    # smoke_test.py:26
from temporalio import workflow                           # smoke_test.py:28

with workflow.unsafe.imports_passed_through():            # smoke_test.py:30
    from olympus_workflows.activities.agent_dispatch import dispatch_agent_task   # smoke_test.py:31
    from olympus_workflows.types import AgentTaskInput, AgentTaskResult           # smoke_test.py:32
```

- ⚠️ **GOTCHA-IMPORTS (gated imports, identical rule to base):** `dispatch_agent_task`,
  `AgentTaskInput`, and `AgentTaskResult` are imported INSIDE
  `with workflow.unsafe.imports_passed_through():` (`smoke_test.py:30-32`). A rebuild MUST keep
  these inside the gate so the Temporal sandbox does not re-import / re-execute them on replay.
  Moving them to module top level risks sandbox nondeterminism.
- ⚠️ **GOTCHA-NO-TIME:** there is **no** `workflow.now()`, no `datetime.now()`, no `random`, no
  wall-clock anywhere in this workflow. `timedelta` is imported only to express the two activity
  timeouts (`smoke_test.py:72-73`), which are deterministic constants. The workflow is trivially
  deterministic: it has exactly one yield point (the single `await workflow.execute_activity`).

---

## 1. STATE — instance vars

**NONE.** `SmokeTestAgentDispatchWorkflow` defines **no `__init__`** and holds **no instance
attributes** (`smoke_test.py:35-93`). The only data are method-local:

| Local var | Type | Where bound | Source |
|-----------|------|-------------|--------|
| `payload` | `dict[str, Any]` | `run` param | the dict the starter script sends (`smoke_test.py:47`) |
| `task_input` | `AgentTaskInput` | `smoke_test.py:51-67` | built from `payload` (§3) |
| `result` | `AgentTaskResult` | `smoke_test.py:69` | the single activity's return value |

⚠️ **GOTCHA-STATELESS:** because there is no instance state, there is nothing for a query to read
and nothing for a signal to mutate — consistent with the absence of both. A rebuild MUST NOT add
`__init__` or any `self.*` attribute; doing so would imply state the original never had (and would
be dead, since nothing reads it).

---

## 2. SIGNALS / QUERIES / UPDATES

**NONE.** There are zero `@workflow.signal`, zero `@workflow.query`, zero `@workflow.update`
handlers on this class (`smoke_test.py:35-93`). The only decorated method is the single
`@workflow.run` (`smoke_test.py:46`).

Consequences for parity:
- The workflow is **not cancellable via an in-workflow signal** (no `cancel_workflow`, no
  `self.cancelled`). ⚠️ **GOTCHA-CANCEL:** the docstring (`smoke_test.py:42-44`) explicitly says
  cancellation is done by the **operator from the Temporal UI** if a run "goes off the rails" —
  i.e. via Temporal's native workflow-cancellation request, which surfaces as a
  `CancelledError`/`asyncio.CancelledError` against the in-flight `await execute_activity`, NOT via
  any custom signal handler. A rebuild MUST NOT add a `cancel_workflow` signal or a `cancelled`
  flag to "improve" cancellability; native Temporal cancel is the only intended path and adding a
  signal would change the registered signal surface.
- No status query exists; the starter script learns the outcome from the workflow's **return
  value** (§4), not from polling `get_status`. A rebuild MUST NOT add `get_status` or any query.

There is **no `wait_condition`** anywhere — the single `await` is the activity call, which blocks
until the activity completes (or its timeout / a native cancel fires). So there is no predicate to
specify.

---

## 3. `run(self, payload)` — control flow (`smoke_test.py:46-92`)

Decorated `@workflow.run` (`smoke_test.py:46`). Signature
`async def run(self, payload: dict[str, Any]) -> dict[str, Any]` (`smoke_test.py:47`).

The body is **strictly linear**: there are **no `if/elif/else`, no `try/except/finally`, no
`for`/`while` statements, no `match/case`, and no early `return`** other than the single terminal
`return` of the result dict. The control flow is: build input → await one activity → build & return
a dict. The only branching constructs are **expression-level `... or <default>` short-circuit
fallbacks** and **one list comprehension** — all reproduced explicitly below.

### 3.1 Build `AgentTaskInput` from the raw dict (`smoke_test.py:51-67`)

```text
task_input = AgentTaskInput(
    task_type   = payload.get("task_type", "smoke-test"),                # smoke_test.py:52  default "smoke-test"
    app_id      = payload.get("app_id", ""),                             # smoke_test.py:53  default ""
    skill_id    = payload["skill_id"],                                   # smoke_test.py:54  ★ REQUIRED — no default
    input_artifacts = list(payload.get("input_artifacts") or []),        # smoke_test.py:55  FALLBACK #1
    optional_input_artifacts = list(
        payload.get("optional_input_artifacts") or []                    # smoke_test.py:56-58 FALLBACK #2
    ),
    source_repo      = payload.get("source_repo", ""),                   # smoke_test.py:59  default ""
    artifact_repo    = payload.get("artifact_repo", ""),                 # smoke_test.py:60  default ""
    artifact_ref     = payload.get("artifact_ref", ""),                  # smoke_test.py:61  default ""
    model_preference = payload.get("model_preference", ""),              # smoke_test.py:62  default ""
    workspace_key    = payload.get("workspace_key", ""),                 # smoke_test.py:63  default ""
    timeout_seconds  = int(payload.get("timeout_seconds") or 7200),      # smoke_test.py:64  FALLBACK #3 + int()
    context          = dict(payload.get("context") or {}),               # smoke_test.py:65  FALLBACK #4 + dict()
    wave_id          = payload.get("wave_id", ""),                       # smoke_test.py:66  default ""
)
```

**Field-by-field semantics (every fallback is load-bearing):**

| Field | Expression | Default / fallback | ⚠️ Notes |
|-------|-----------|--------------------|----------|
| `task_type` | `payload.get("task_type", "smoke-test")` | `"smoke-test"` if key absent | `dict.get` default fires only on **missing key**, not on falsy values. A present `None`/`""` passes through. |
| `app_id` | `payload.get("app_id", "")` | `""` | Defaults match a **per-app** dispatch shape; wave-scoped runs supply `wave_id` and leave `app_id=""` (`smoke_test.py:48-50`). |
| `skill_id` | `payload["skill_id"]` | **none — direct index** | ⚠️ **GOTCHA-SKILL-REQUIRED:** this is the ONLY required field. `payload["skill_id"]` raises `KeyError` (which surfaces as a workflow task failure) if `"skill_id"` is absent. A rebuild MUST use `[]` indexing here, NOT `.get(...)` — the contract is "skill_id is mandatory; everything else has a default." |
| `input_artifacts` | `list(payload.get("input_artifacts") or [])` | `[]` | **FALLBACK #1.** `or []` converts a missing key (→`None`) OR a falsy value (`None`/`[]`/`""`/`0`) to `[]`, then wraps in `list(...)` to copy/coerce. ⚠️ A truthy non-list (e.g. a tuple) would be `list(...)`-coerced; a falsy value becomes `[]`. |
| `optional_input_artifacts` | `list(payload.get("optional_input_artifacts") or [])` | `[]` | **FALLBACK #2.** Same `... or [] → list(...)` idiom across two source lines (`smoke_test.py:56-58`). |
| `source_repo` | `payload.get("source_repo", "")` | `""` | plain `.get` default. |
| `artifact_repo` | `payload.get("artifact_repo", "")` | `""` | plain `.get` default. |
| `artifact_ref` | `payload.get("artifact_ref", "")` | `""` | plain `.get` default. |
| `model_preference` | `payload.get("model_preference", "")` | `""` | plain `.get` default; empty → agent runtime picks the model. |
| `workspace_key` | `payload.get("workspace_key", "")` | `""` | plain `.get` default. |
| `timeout_seconds` | `int(payload.get("timeout_seconds") or 7200)` | `7200` | **FALLBACK #3.** ⚠️ **GOTCHA-TIMEOUT-7200:** `... or 7200` means a missing key, `None`, `0`, OR `""` all collapse to **7200 (2h)** — the `AgentTaskInput` dataclass's own default is `3600`, but this workflow OVERRIDES it to **7200**. Then `int(...)` coerces a string like `"600"`. Note: `timeout_seconds=0` does NOT mean "no timeout" — it falls through to 7200. A rebuild MUST use `or 7200` (so `0`/`""`→7200) AND wrap in `int(...)`. This 7200 is the *agent-runtime-side* budget; it is distinct from the Temporal `start_to_close_timeout` (also 2h, §3.2). |
| `context` | `dict(payload.get("context") or {})` | `{}` | **FALLBACK #4.** `... or {}` collapses missing/falsy to `{}`, then `dict(...)` copies/coerces. ⚠️ A present non-empty dict is shallow-copied via `dict(...)`. |
| `wave_id` | `payload.get("wave_id", "")` | `""` | plain `.get` default. |

⚠️ **GOTCHA-PASSTHROUGH (no validation, no exactly-one check here):** the workflow does **not**
enforce the `app_id` XOR `wave_id` "exactly one" constraint (that lives in the
`_insert_agent_task_row` activity / DB CHECK per `types.py:472-509`). The workflow passes the dict
straight through so the starter script can target any skill (`smoke_test.py:37-44`). A rebuild MUST
NOT add input validation here — both `app_id` and `wave_id` default to `""` and the activity/DB is
the authority on the constraint.

⚠️ **GOTCHA-FIELD-OMISSIONS:** the constructor does **NOT** set `execution_context` — it is left at
its `AgentTaskInput` default `None` (`types.py:504`). So **no Layer-B `step_execution` row** is
emitted for a smoke-test dispatch (the activity tolerates `None`). A rebuild MUST leave
`execution_context` unset (defaulted `None`); do NOT synthesize a `StepExecutionContext`.

### 3.2 Dispatch the single activity (`smoke_test.py:69-74`)

```text
result: AgentTaskResult = await workflow.execute_activity(   # smoke_test.py:69
    dispatch_agent_task,                                     # smoke_test.py:70  the activity fn
    task_input,                                              # smoke_test.py:71  single positional arg
    start_to_close_timeout = timedelta(hours=2),             # smoke_test.py:72  2h
    heartbeat_timeout      = timedelta(minutes=5),           # smoke_test.py:73  5m
)
```

This is the **only** `await` and the **only** activity call in the workflow. There is exactly **one
yield point** in `run`.

### 3.3 Build and return the JSON-serializable summary (`smoke_test.py:78-92`)

```text
return {                                                          # smoke_test.py:78
    "task_id":              result.task_id,                       # smoke_test.py:79
    "status":               str(result.status),                  # smoke_test.py:80  ★ str(enum)
    "model_used":           result.model_used,                   # smoke_test.py:81
    "duration_ms":          result.duration_ms,                  # smoke_test.py:82
    "cost_estimate_usd":    result.cost_estimate_usd,            # smoke_test.py:83
    "token_usage_input":    result.token_usage_input,            # smoke_test.py:84
    "token_usage_output":   result.token_usage_output,           # smoke_test.py:85
    "output_artifact_count": len(result.output_artifacts or []),  # smoke_test.py:86  FALLBACK #5
    "output_file_count":     len(result.output_files or []),      # smoke_test.py:87  FALLBACK #6
    "output_file_paths": [                                        # smoke_test.py:88  ★ COMPREHENSION
        getattr(f, "path", "") for f in (result.output_files or [])   # smoke_test.py:89-90 FALLBACK #7
    ],
    "error": getattr(result, "error", "") or "",                  # smoke_test.py:91  FALLBACK #8 + getattr
}
```

**Field-by-field semantics of the return dict (every fallback/coercion is load-bearing):**

| Key | Expression | ⚠️ Notes |
|-----|-----------|----------|
| `task_id` | `result.task_id` | direct attribute (always present on `AgentTaskResult`, `types.py:516`). |
| `status` | `str(result.status)` | ⚠️ **GOTCHA-STATUS-STR:** `result.status` is a `TaskStatus(str, enum.Enum)` (`types.py:47-53`; members `QUEUED/DISPATCHED/RUNNING/COMPLETED/FAILED/TIMED_OUT`). `str(member)` on a `str`-mixin Enum yields the **repr-style** `"TaskStatus.COMPLETED"`, **NOT** the value `"completed"`. (Compare `_LineWorkflowBase` which compares against `GateStatus.APPROVED` directly; here the value is stringified for printing.) A rebuild MUST use `str(result.status)` exactly — not `result.status.value`, not `result.status.name` — to reproduce the literal `"TaskStatus.<NAME>"` string the starter script prints. On a schema-validation failure the activity returns `status=FAILED`, so this field reads `"TaskStatus.FAILED"` and `error` (below) carries the validation message (`smoke_test.py:16-20`). |
| `model_used` | `result.model_used` | direct (defaults `""`, `types.py:520`). |
| `duration_ms` | `result.duration_ms` | direct (defaults `0`, `types.py:521`). |
| `cost_estimate_usd` | `result.cost_estimate_usd` | direct (defaults `0.0`, `types.py:524`). |
| `token_usage_input` | `result.token_usage_input` | direct (defaults `0`, `types.py:522`). |
| `token_usage_output` | `result.token_usage_output` | direct (defaults `0`, `types.py:523`). |
| `output_artifact_count` | `len(result.output_artifacts or [])` | **FALLBACK #5.** `or []` guards a `None`/falsy `output_artifacts` so `len(...)` never raises. The dataclass default is `[]` (`types.py:518`), so in practice `or []` only matters if an activity returned `None`. Reproduce it. |
| `output_file_count` | `len(result.output_files or [])` | **FALLBACK #6.** Same guard for `output_files` (`types.py:519`). |
| `output_file_paths` | `[getattr(f, "path", "") for f in (result.output_files or [])]` | ⚠️ **GOTCHA-PATHS-COMPREHENSION:** the ONLY loop in the workflow. It is a **list comprehension** over `(result.output_files or [])` — **FALLBACK #7** (`None`/falsy → `[]`, no iteration). For each element `f` it reads `getattr(f, "path", "")` — i.e. it tolerates an element that lacks a `.path` attribute by substituting `""` rather than raising `AttributeError`. (`OutputFile.path` is normally present, `types.py:463`, so the `getattr` default is defensive against malformed entries.) A rebuild MUST: (a) guard the iterable with `or []`, (b) use `getattr(f, "path", "")` per element — NOT `f.path` — to keep the defensive default. |
| `error` | `getattr(result, "error", "") or ""` | **FALLBACK #8.** ⚠️ **GOTCHA-ERROR-DOUBLE-GUARD:** two defenses stacked: `getattr(result, "error", "")` tolerates a result object that has no `error` attribute at all (substitutes `""`), and the trailing `or ""` then normalizes a present-but-falsy value (`None`/`""`) to `""`. Net effect: the key is ALWAYS a string, never `None`, never missing. (`AgentTaskResult.error` defaults `""`, `types.py:525`, so the `getattr` default is belt-and-suspenders.) A rebuild MUST keep BOTH the `getattr(..., "")` and the `or ""`. |

⚠️ **GOTCHA-RETURN-IS-PLAIN-DICT (no dataclass on the wire):** the workflow deliberately returns a
plain JSON-serializable `dict`, NOT the `AgentTaskResult` dataclass, "so the starter script can
print without dragging in the dataclass machinery" (`smoke_test.py:76-77`). The returned dict is
the workflow's **only output channel** (there is no query). A rebuild MUST return this exact dict
shape with these exact 11 keys and these exact value expressions — the starter script parses these
keys.

⚠️ **GOTCHA-NO-PERSIST:** the workflow does NOT write anything to git, does NOT update any DB row,
does NOT create a PR, does NOT submit gate evidence. It is purely: dispatch → summarize → return.
The `dispatch_agent_task` activity itself may persist agent-task rows / artifacts as a side effect,
but the **workflow** adds no persistence of its own. A rebuild MUST NOT add commit/PR/DB-write
activities.

---

## 4. ACTIVITY & CHILD-WORKFLOW CALLS (in order)

**Exactly one activity. Zero child workflows. Zero `gather`/parallel calls.**

| # | Activity | Args | start_to_close | heartbeat | retry_policy | non_retryable | activity_id |
|---|----------|------|----------------|-----------|--------------|---------------|-------------|
| 1 | `dispatch_agent_task` (`smoke_test.py:70`) | single positional `task_input: AgentTaskInput` (`smoke_test.py:71`) | **`timedelta(hours=2)`** (`smoke_test.py:72`) | **`timedelta(minutes=5)`** (`smoke_test.py:73`) | **NOT SPECIFIED — uses Temporal SDK default** | n/a | **NOT SPECIFIED** (none) |

⚠️ **GOTCHA-NO-RETRY-POLICY (★ key divergence from base):** unlike `LineWorkflowBase._dispatch_agent`
— which dispatches `dispatch_agent_task` with `start_to_close=1h`, `retry_policy=RETRY_POLICIES["agent_failure"]`
(3 attempts, 5-60s backoff), and `activity_id="agent-{step}"` (`base.py:444-446`) — this smoke-test
workflow passes **NEITHER a `retry_policy` NOR an `activity_id`** (`smoke_test.py:69-74`). Therefore
the activity runs under **Temporal's default retry policy** (effectively unbounded retries with
exponential backoff: initial 1s, backoff 2.0, max interval 100s, **maximum_attempts = 0 = unlimited**
unless capped at the worker/namespace level), and gets a Temporal-assigned activity id. A rebuild
MUST reproduce the OMISSION exactly: do not add `retry_policy=` and do not add `activity_id=`. Adding
`agent_failure` (3 attempts) would change failure behavior; adding a deterministic `activity_id`
would change history identity. The smoke test intentionally leans on the activity's own internal
retry-with-feedback loop (pass-1 then pass-2-with-feedback, `smoke_test.py:14-20`) and on the long
2h `start_to_close` rather than on workflow-level retry tuning.

⚠️ **GOTCHA-HEARTBEAT-5M (the real hang detector):** `heartbeat_timeout=timedelta(minutes=5)`
(`smoke_test.py:73`) is the load-bearing liveness check, NOT `start_to_close`. The activity's
`_heartbeat_loop` fires every 30s for the lifetime of the dispatch (`agent_dispatch.py:391-394`),
so a genuinely hung agent trips the **5-minute** heartbeat timeout long before the 2h
`start_to_close`. The 2h `start_to_close` is a generous ceiling so even slow Opus runs have
headroom (`smoke_test.py:41-44`). A rebuild MUST set BOTH timeouts to these exact values — dropping
`heartbeat_timeout` would mean a hang is only caught after 2h.

⚠️ **GOTCHA-SINGLE-POSITIONAL-ARG:** the activity is invoked with a single positional dataclass
`task_input` (`smoke_test.py:71`), NOT `args=[...]` and NOT keyword. This matches the
`dispatch_agent_task(input: AgentTaskInput)` signature (`agent_dispatch.py:382`). A rebuild passes
one positional dataclass.

**Activity behavior the workflow relies on (for parity context — do not re-spec; see Phase 4):**
on success the activity returns the `AgentTaskResult` as-is (the workflow returns it summarized);
on **schema-validation failure** the activity returns `status=FAILED` with the validation message
in `error` — the workflow does NOT raise on that; it summarizes and returns it
(`smoke_test.py:14-20`). The pass-1 → pass-2-with-feedback loop is internal to the activity / its
Temporal retry of the *activity*, exercised within a single workflow run; the **workflow itself**
contains no such loop.

---

## 5. GATE HANDLING

**NONE.** This workflow performs **no gate handling whatsoever**:
- No `_build_evidence_data`, no `_create_gate_pr`, no `_submit_gate_evidence`, no
  `_run_gate_pre_review`.
- No `_wait_for_gate_decision` — there is no gate wait, no approve/reject/cancel routing, no
  `merge_blocked` state, no `_reconcile_and_merge_with_retry_loop`.
- **No rework loop and no rework counters** — there is no `_rework_iterations`, no `_bump_rework`,
  no `MAX_REWORK` ceiling, no escalate-vs-fail policy. The "retry-with-feedback" the docstring
  mentions (`smoke_test.py:14-20`) is the **activity's** internal pass-1/pass-2 loop, NOT a
  workflow-level rework loop.

A rebuild MUST NOT introduce any gate, evidence, PR, merge, or rework machinery. The smoke test's
entire job is to fire one activity and report what came back.

---

## 6. RESILIENCE

- **Timeouts:** the single activity has `start_to_close_timeout = 2 hours` (`smoke_test.py:72`) and
  `heartbeat_timeout = 5 minutes` (`smoke_test.py:73`). No `schedule_to_close`, no
  `schedule_to_start` set. The agent-runtime-side budget is `timeout_seconds` on the input
  (default coerced to **7200s**, §3.1) — distinct from the Temporal timeouts.
- **Heartbeats:** relied upon — 5-minute `heartbeat_timeout`; the activity heartbeats every 30s
  (§4, GOTCHA-HEARTBEAT-5M).
- **Retry:** **no workflow-supplied retry policy** on the activity → Temporal SDK default applies
  (§4, GOTCHA-NO-RETRY-POLICY).
- **continue-as-new:** NONE. The workflow does a single activity and returns; history stays tiny
  (one activity scheduled/started/completed event pair). No history-growth concern.
- **Idempotency / determinism:** the workflow is deterministic — one yield point, no time/random/IO,
  imports gated (`smoke_test.py:30`). It does NOT set a deterministic `activity_id`, so on a
  workflow *replay* the SDK reuses the recorded activity result from history (replay is driven by
  event history, not by activity_id) — i.e. determinism is preserved by Temporal's history, not by
  a stable activity id. A rebuild's omission of `activity_id` is safe precisely because there is
  only one activity and no branching.
- **Cancellation:** native Temporal workflow-cancel only (no `cancel_workflow` signal). A cancel
  request propagates to the in-flight `await execute_activity` (`smoke_test.py:69`) as a
  cancellation; the operator triggers it from the Temporal UI (`smoke_test.py:42-44`). See
  GOTCHA-CANCEL (§2).
- **Compensation / rollback:** NONE. There is nothing to roll back (no git writes, no DB writes, no
  PRs). A `status=FAILED` result is returned, not raised — the workflow **completes successfully**
  with a dict whose `"status"` is `"TaskStatus.FAILED"` and whose `"error"` carries the message.
- **Failure surfaces that DO fail the workflow:** (a) `KeyError` if `payload["skill_id"]` is missing
  (`smoke_test.py:54`) — fails the workflow task; (b) the activity exhausting its retries / tripping
  a timeout / heartbeat-timeout raises `ActivityError` out of `execute_activity`, which (uncaught,
  since there is no `try/except`) propagates and **fails the workflow**. Everything else
  (schema-validation `FAILED`) is a normal successful return.

---

## 7. Behavioral parity checklist

A rebuilt `SmokeTestAgentDispatchWorkflow` MUST satisfy ALL of the following:

1. **Standalone class** decorated `@workflow.defn`, named `SmokeTestAgentDispatchWorkflow`, with
   **no base class** (`smoke_test.py:35-36`). It inherits NOTHING from `LineWorkflowBase` /
   `HILSignalsMixin` and overrides nothing (GOTCHA-INHERIT). It has **no `__init__`** and **no
   instance state** (§1, GOTCHA-STATELESS).
2. **No signal handlers, no query handlers, no update handlers** — the ONLY decorated method is a
   single `@workflow.run` (`smoke_test.py:46`). In particular there is NO `get_status`, NO
   `cancel_workflow`, NO `gate_approved`/`gate_rejected`/`escalation_resolved`/`merge_retry`, and
   none of the six HIL signals (§2).
3. Activity + types imported inside `with workflow.unsafe.imports_passed_through():`
   (`smoke_test.py:30-32`); no other imports gated; `from __future__ import annotations` present
   (GOTCHA-IMPORTS).
4. `run(self, payload: dict[str, Any]) -> dict[str, Any]` is **fully linear** — zero
   `if/elif/else`, zero `try/except/finally`, zero `for`/`while` statements, zero `match/case`,
   exactly ONE `return` (the terminal dict). The only branching is expression-level `... or`
   fallbacks (8 of them) and one list comprehension (§3).
5. `AgentTaskInput` is built with EXACTLY the field expressions in §3.1:
   - `task_type` ← `payload.get("task_type", "smoke-test")`,
   - `app_id` ← `payload.get("app_id", "")`,
   - `skill_id` ← `payload["skill_id"]` (**direct index — KeyError if absent**, GOTCHA-SKILL-REQUIRED),
   - `input_artifacts` ← `list(payload.get("input_artifacts") or [])` (FALLBACK #1),
   - `optional_input_artifacts` ← `list(payload.get("optional_input_artifacts") or [])` (FALLBACK #2),
   - `source_repo`/`artifact_repo`/`artifact_ref`/`model_preference`/`workspace_key`/`wave_id` ←
     `payload.get(<key>, "")`,
   - `timeout_seconds` ← `int(payload.get("timeout_seconds") or 7200)` (**FALLBACK #3; `0`/`""`/None → 7200**, then `int()`, GOTCHA-TIMEOUT-7200),
   - `context` ← `dict(payload.get("context") or {})` (FALLBACK #4).
   - `execution_context` is **NOT set** (defaults `None`) → no Layer-B emission (GOTCHA-FIELD-OMISSIONS).
   - No input validation / no app-vs-wave exactly-one check in the workflow (GOTCHA-PASSTHROUGH).
6. **Exactly one** `await workflow.execute_activity(dispatch_agent_task, task_input, ...)`
   (`smoke_test.py:69-74`) with `start_to_close_timeout=timedelta(hours=2)` and
   `heartbeat_timeout=timedelta(minutes=5)`, **single positional arg**, and **NO `retry_policy`**
   and **NO `activity_id`** (GOTCHA-NO-RETRY-POLICY, GOTCHA-HEARTBEAT-5M, GOTCHA-SINGLE-POSITIONAL-ARG).
   Zero child workflows, zero parallel/gather calls.
7. Returns a **plain dict** (not the dataclass) with EXACTLY these 11 keys and value expressions
   (§3.3): `task_id`=`result.task_id`; `status`=`str(result.status)` (→ `"TaskStatus.<NAME>"`, NOT
   `.value`, GOTCHA-STATUS-STR); `model_used`; `duration_ms`; `cost_estimate_usd`;
   `token_usage_input`; `token_usage_output`;
   `output_artifact_count`=`len(result.output_artifacts or [])` (FALLBACK #5);
   `output_file_count`=`len(result.output_files or [])` (FALLBACK #6);
   `output_file_paths`=`[getattr(f, "path", "") for f in (result.output_files or [])]` (FALLBACK #7
   + per-element `getattr` default, GOTCHA-PATHS-COMPREHENSION);
   `error`=`getattr(result, "error", "") or ""` (FALLBACK #8 + double-guard, GOTCHA-ERROR-DOUBLE-GUARD).
8. A `status=FAILED` activity result is **returned, not raised** — the workflow completes
   successfully with `"status": "TaskStatus.FAILED"` and the message in `"error"` (§4/§6). Only an
   uncaught `ActivityError` (retries exhausted / timeout / heartbeat timeout) or the missing-
   `skill_id` `KeyError` fails the workflow.
9. **No gates, no evidence, no PR, no merge loop, no rework loop/counters** (§5). **No git writes,
   no DB writes, no continue-as-new, no compensation** (§6, GOTCHA-NO-PERSIST). **No
   `wait_condition`** anywhere (§2).
10. **No time/random/external-I/O** in the workflow body; `timedelta` used only for the two activity
    timeouts (GOTCHA-NO-TIME). Determinism is preserved by Temporal history (single activity, no
    branching), not by a stable `activity_id`.
