# `WaveRationalizationWorkflow` — Part 1: Module Helpers + `__init__` STATE (ATOMIC regeneration spec)

> **Source of truth:** `temporal/olympus_workflows/workflows/wave_rationalization.py` (5969 lines
> total). Every `wave_rationalization.py:line` citation below is against that file.
>
> **Scope of THIS file:** lines **1–1238** ONLY — module-level constants, module-level helper
> functions (`classify_failure`, `rework_targets_for`, `_compute_overall_readiness`, the
> artifact-list builders, `_build_rationalization_step_entry`, etc.), the module-level signal
> docstring, and the class `__init__` STATE (every instance var, type, initial value, what
> mutates it & when). The `run()` / `_execute()` orchestration (lines 1239+), the gate-PR body
> builders (`_build_grr_body`/`_build_gda_body`), `_set_step`, `_wait_for_gate`,
> `_run_gate_pre_review`, `_reconcile_and_merge_with_retry_loop`, `_normalize_dispatch_payload`,
> `_provision_one_target`, `_spawn_children_for_target`, `_execution_ctx`, the schema-validation
> helper, and ALL `@workflow.signal` / `@workflow.query` handlers live in **sibling spec files**
> for this workflow. Where this file references their behavior (e.g. to say "what mutates
> `_gate_decisions`"), it cites the sibling line but does NOT reproduce the body.
>
> ⚠️ **TOP-LEVEL GOTCHA — does NOT extend `LineWorkflowBase`.** Despite being a line workflow,
> `WaveRationalizationWorkflow` inherits **directly** from `HILSignalsMixin` (`wave_rationalization.py:1078`),
> NOT from `LineWorkflowBase`. The class docstring + multiple inline comments
> (`wave_rationalization.py:1181-1183`, `5435-5438`, `5535-5539`) say the fan-out shape is
> different so the base helpers are **inlined / re-implemented** here. Consequences a rebuild MUST
> honor:
> 1. `__init__` re-declares the line-state vars (`_status`, `_current_step`, `_pending_gate`,
>    `_gate_decisions`, …) itself — it does NOT get them from `LineWorkflowBase.__init__`. (It DOES
>    get the 8 HIL vars via `super().__init__()` → `HILSignalsMixin.__init__`.)
> 2. The gate-decision queues here are **`dict[gate_key → list]`** (per-gate), NOT the base's flat
>    `list` + single `int` cursor. Two gates (G-RR, G-DA) get independent queues + cursors.
> 3. `_set_step`, `_wait_for_gate`, `gate_approved`, `gate_rejected`, `merge_retry`,
>    `_run_gate_pre_review`, `_reconcile_and_merge_with_retry_loop`, `get_status`,
>    `_execution_ctx` are **re-implemented in this class** (sibling files) — they are NOT inherited.
>    A rebuild must NOT assume base behavior; it must reproduce the in-class versions.
> 4. The HIL mixin's `approve` / `cancel_workflow` / `approve_plan` / `provide_plan_feedback` /
>    `approve_research` / `provide_feedback` signals ARE inherited (see `_HILSignalsMixin.md`).
>    `self.cancelled` (set by inherited `cancel_workflow`) is threaded into every `wait_condition`.
>
> **Reference for inherited behavior:** `regen/03-workflows/_HILSignalsMixin.md` — the 8 HIL state
> vars (`approved`, `plan_approved`, `plan_feedback_received`, `plan_feedback_comments`,
> `document_approved`, `document_feedback_received`, `document_feedback_comments`, `cancelled`),
> the 6 inherited signals, and the `reset_*` / `is_*_decision_received` helpers + `create_*_signal`
> factories. `_LineWorkflowBase.md` is referenced only to contrast what this workflow does NOT
> inherit.

---

## 0. Module shape & imports (`wave_rationalization.py:1-131`)

- `from __future__ import annotations` (`:35`) — all annotations are strings; runtime never
  evaluates them. Matters for the `DispatchArchitecturePayload | None`-style annotations on state.
- `import asyncio` (`:37`), `from datetime import timedelta` (`:38`), `from typing import Any` (`:39`).
- `from foundry_temporal.signals import HILSignalsMixin` (`:41`) — imported at TOP LEVEL (NOT inside
  `imports_passed_through`). ⚠️ **GOTCHA-IMP1:** `HILSignalsMixin` is a pure-Python mixin with no
  side effects, so it is safe to import at module top; the activity functions + types below are
  NOT and MUST be inside the sandbox-passthrough block.
- `from temporalio import workflow` (`:42`) — top level.
- ⚠️ **GOTCHA-IMP2 (sandbox passthrough block — `wave_rationalization.py:44-131`):** EVERYTHING
  else (the two Temporal exception types `ActivityError`/`ApplicationError`, every activity
  function, `RETRY_POLICIES`, every dataclass type from `olympus_workflows.types`, and
  `parse_agent_json`) is imported inside `with workflow.unsafe.imports_passed_through():`. A rebuild
  MUST keep this block so the Temporal sandbox does not re-import/re-execute these on replay.
  Activities imported (used across the whole class, not just in scope): `dispatch_agent_task`,
  `validate_artifact_against_schema`, `load_context_priors`, `create_gate_record`,
  `fetch_gate_capability_lineage_rework`, `mark_gate_ready_for_review`, `set_gate_merge_blocked`,
  `submit_gate_evidence`, `update_application_status`, `store_gate_pre_review`, `create_pr`,
  `reconcile_and_merge_pr`, `write_artifact`, `write_artifacts_batch`, `create_target_app_and_repo`,
  `fetch_application_source_repos`, `load_wave_rationalization_capabilities`,
  `persist_rationalization_capabilities`, `persist_rationalization_capability_dispositions`,
  `persist_rationalization_side_effects`, `update_application_line_projection`,
  `persist_wave_failure`, `update_wave_architecture_workflow_id`, `update_wave_status`.
- ⚠️ **GOTCHA-IMP3 (keep-alive at module end — `wave_rationalization.py:5965-5968`):**
  `_ = update_application_status` is assigned at the very bottom to keep the import alive for worker
  registration even though the workflow never calls it directly. A rebuild that drops the import
  because "it's unused" breaks worker activity registration. (Out of this file's 1-1238 line scope,
  but called out because it explains why `update_application_status` is imported.)

### `_now_iso()` — deterministic timestamp (`wave_rationalization.py:134-135`)

```text
def _now_iso() -> str:
    return workflow.now().isoformat()
```
⚠️ **GOTCHA-NOW (determinism):** module-level function (NOT a method). EVERY timestamp in the whole
workflow goes through this — `workflow.now()` is deterministic under Temporal replay. A rebuild MUST
NEVER use `datetime.now()` / `time.time()`. Used in `run()`'s failure path, `_set_step`,
`_wait_for_gate`, every signal handler, and the rework-feedback dicts.

---

## 1. `_normalize_relationship(relationship)` (`wave_rationalization.py:138-155`)

Canonicalizes a relationship/disposition string to lowercase. **2 branches.**

```text
def _normalize_relationship(relationship: str | None) -> str:
    if not relationship:                       # :153  BRANCH 1 — None / "" / falsy
        return ""                              # :154
    return relationship.strip().lower()        # :155
```

- **BRANCH 1** (`:153`): `not relationship` is truthy for `None`, `""`, and any falsy → returns `""`.
- **Fall-through** (`:155`): `.strip().lower()` — `"Consolidate"` → `"consolidate"`, `"  REPLACE "` → `"replace"`.
- ⚠️ **GOTCHA-NR1 (load-bearing case normalizer):** the wave-scoped `architecture-target-plan.json`
  schema spells `relationship` lowercase (`"replace"`, `"consolidate"`, …) but the legacy v1
  dispatch path threads it through `cfg.disposition` which is Title-cased (`"Consolidate"`). The
  docstring (`:138-152`) states: **EVERY** read of `relationship` from the plan, the v2 dispatch
  payload, the v1 disposition fallback, or any signal payload MUST go through this helper, or the
  v1 fan-out silently routes around the consolidate code paths. A rebuild must funnel all reads here.
- ⚠️ **GOTCHA-NR2 (whitespace-only → `""`):** `"   "` → `.strip()` → `""`. The docstring guarantees
  `""` for `None`, empty, AND whitespace-only so downstream truthy checks (`if rel:`) work unchanged.

---

## 2. `_legacy_disposition_from_relationship(relationship)` (`wave_rationalization.py:158-172`)

Projects a lowercase `relationship` → Title-cased legacy v1 `disposition`. **1 branch.**

```text
def _legacy_disposition_from_relationship(relationship: str | None) -> str:
    rel = _normalize_relationship(relationship)     # :169  ← funnel through §1 first
    if not rel:                                      # :170  BRANCH
        return ""                                    # :171
    return rel[:1].upper() + rel[1:]                 # :172  Title-case ONLY the first char
```

- **BRANCH** (`:170`): empty normalized → `""`.
- **Fall-through** (`:172`): `rel[:1].upper() + rel[1:]` — `"consolidate"` → `"Consolidate"`,
  `"rearchitect"` → `"Rearchitect"`. ⚠️ **GOTCHA-LD1:** this is **first-char-only** capitalization,
  NOT `.title()` / `.capitalize()`. `.capitalize()` would lowercase the tail; this preserves the
  tail verbatim. For the 7R vocabulary (all single-word, lowercase) the difference is moot, but a
  rebuild MUST use `rel[:1].upper() + rel[1:]` to match exactly (and to be safe if a multi-word
  value ever appears). Used by `_normalize_dispatch_payload` (sibling) to project v2 → v1
  `DispatchArchitectureTargetConfig.disposition` (which the activity expects in 7R Title-case).

---

## 3. `_PORTFOLIO_SCORER_DIMENSIONS` constant (`wave_rationalization.py:175-182`)

```text
_PORTFOLIO_SCORER_DIMENSIONS = (
    "technical_readiness",
    "architectural_readiness",
    "operational_readiness",
    "security_readiness",
    "user_experience_readiness",
    "business_readiness",
)
```
A 6-tuple (ordered, immutable). Consumed ONLY by `_compute_overall_readiness` (§5). ⚠️ **GOTCHA-PD1
(order is part of the contract):** it is a `tuple`, not a `set` — iteration order is fixed. The
six exact dimension keys must match the `portfolio-scorer` skill's output schema. A rebuild must
reproduce all six names exactly and in this order (order affects the `present` list ordering before
the final `sorted()` — see §5).

---

## 4. `_classification_is_tier_1(cls_json)` (`wave_rationalization.py:185-211`)

True iff the classification artifact flags Tier-1 risk. Defensive JSON parse. **6 branches.**

```text
def _classification_is_tier_1(cls_json: str) -> bool:
    import json                                                   # :195  local import

    if not cls_json:                                             # :197  BRANCH 1
        return False                                            # :198
    try:
        parsed = json.loads(cls_json)                           # :200
    except (json.JSONDecodeError, TypeError, ValueError):       # :201  BRANCH 2 (parse fail)
        return False                                            # :202
    if not isinstance(parsed, dict):                            # :203  BRANCH 3
        return False                                            # :204
    if parsed.get("tier_1_flag") is True:                       # :205  BRANCH 4 — explicit shorthand
        return True                                             # :206
    risk = parsed.get("risk_tier")                              # :207
    try:
        return int(risk) == 1 if risk is not None else False    # :209  BRANCH 5 (inline cond) + BRANCH 6 (int cast)
    except (TypeError, ValueError):                             # :210  BRANCH 6 (cast fail)
        return False                                            # :211
```

- **BRANCH 1** (`:197`): empty/falsy string → `False`.
- **BRANCH 2** (`:201`): JSON decode error / `TypeError` / `ValueError` → `False`.
- **BRANCH 3** (`:203`): parsed non-dict (e.g. a JSON list or scalar) → `False`.
- **BRANCH 4** (`:205`): `parsed.get("tier_1_flag") is True` — note **identity** check `is True`, not
  truthy. `1`, `"true"`, `"yes"` do NOT trip this — only the literal boolean `True`. → `True`.
- **BRANCH 5** (`:209` inline ternary): `if risk is not None` else `False` — a `None` `risk_tier`
  falls to `False` WITHOUT attempting `int(None)`.
- **BRANCH 6** (`:209`/`:210`): `int(risk) == 1` inside try; `int("1")==1` → `True`, `int("foo")`
  raises `ValueError` → caught → `False`. `int(1.9)` == `1` → `True` (float truncation).
- ⚠️ **GOTCHA-CT1 (safe default is "don't pause"):** docstring (`:185-194`) — returns `False` on
  ANY parse failure because the safe default is "don't pause for stakeholder sign-off." A missing
  flag does NOT skip the gate (G-DA still runs); it only skips the mid-stream Tier-1 pause. A rebuild
  must default `False`, never raise.
- ⚠️ **GOTCHA-CT2 (`is True` vs truthy):** preserving the identity check matters — an agent that
  emits `"tier_1_flag": 1` falls through to the `risk_tier` path, NOT BRANCH 4. Do not relax to a
  truthy check.
- **Caller:** the per-app classification fan-out (sibling, `_execute`) — `app_id` is added to a
  Tier-1 stakeholder-pause wait when this returns `True`.

---

## 5. `_compute_overall_readiness(score_json)` (`wave_rationalization.py:214-258`)

Pure deterministic equal-weight mean over the 6 portfolio-score dimensions. Returns
`(overall_weighted | None, dimensions_present: list[str])`. **9 branches + 1 loop.**

```text
def _compute_overall_readiness(score_json: str) -> tuple[float | None, list[str]]:
    import json                                                   # :224

    if not score_json:                                           # :226  BRANCH 1
        return None, []                                          # :227
    try:
        parsed = json.loads(score_json)                          # :229
    except (json.JSONDecodeError, TypeError, ValueError):        # :230  BRANCH 2
        return None, []                                          # :231
    if not isinstance(parsed, dict):                             # :232  BRANCH 3
        return None, []                                          # :233
    scores = parsed.get("scores")                                # :234
    if not isinstance(scores, dict):                             # :235  BRANCH 4
        return None, []                                          # :236
    total = 0.0                                                  # :237
    count = 0                                                    # :238
    present: list[str] = []                                      # :239
    for dim in _PORTFOLIO_SCORER_DIMENSIONS:                     # :240  LOOP over the fixed 6-tuple
        entry = scores.get(dim)                                  # :241
        if not isinstance(entry, dict):                          # :242  BRANCH 5 — skip non-dict entry
            continue                                             # :243
        value = entry.get("score")                               # :244
        if value is None:                                        # :245  BRANCH 6 — null score: present but not scored
            present.append(dim)                                  # :246
            continue                                             # :247
        try:
            value_f = float(value)                               # :249
        except (TypeError, ValueError):                          # :250  BRANCH 7 — unparseable: NOT present, skip
            continue                                             # :251
        value_f = max(0.0, min(100.0, value_f))                 # :252  CLAMP to [0,100]
        total += value_f                                         # :253
        count += 1                                               # :254
        present.append(dim)                                      # :255
    if count == 0:                                               # :256  BRANCH 8
        return None, sorted(present)                             # :257  ← still returns sorted present (nulls)
    return round(total / count, 2), sorted(present)              # :258  BRANCH 9 (implicit) — mean of scored dims
```

- **BRANCH 1-4** (`:226,:230,:232,:235`): empty / unparseable / non-dict / `scores` not a dict →
  `(None, [])`.
- **LOOP** (`:240`): iterates `_PORTFOLIO_SCORER_DIMENSIONS` in tuple order.
  - **BRANCH 5** (`:242`): `scores[dim]` is not a dict → `continue` (NOT added to `present`).
  - **BRANCH 6** (`:245`): `entry["score"] is None` → added to `present` but excluded from
    `total`/`count` (the dim "exists" but has no numeric value).
  - **BRANCH 7** (`:250`): `float(value)` raises → `continue` (NOT added to `present`; unparseable
    is treated as absent).
  - **CLAMP** (`:252`): every scored value is clamped into `[0.0, 100.0]` before summing.
- **BRANCH 8** (`:256`): `count == 0` (no dim had a numeric score) → `(None, sorted(present))` —
  note `present` may be non-empty here (it can hold null-score dims from BRANCH 6).
- **Fall-through** (`:258`): `round(total / count, 2)` — 2-decimal rounded equal-weight mean;
  `sorted(present)`.
- ⚠️ **GOTCHA-OR1 (null score ≠ absent score for `present`, but BOTH excluded from denominator):**
  a `null` score (BRANCH 6) IS recorded in `present`; an unparseable score (BRANCH 7) is NOT. Both
  are excluded from `count`/`total`. The docstring (`:214-223`) ties this to historical
  `persist_portfolio_score` behavior: "dimensions with `null` score are excluded from the
  denominator." A rebuild must replicate the exact bucketing: scored→{present, total, count};
  null→{present only}; unparseable/non-dict→{neither}.
- ⚠️ **GOTCHA-OR2 (`present` always `sorted()` on return):** both return paths that include
  `present` sort it (`:257`, `:258`). The in-loop append order is tuple order, but the FINAL order
  is alphabetical. A rebuild must sort on return, not rely on append order.
- ⚠️ **GOTCHA-OR3 (pure function, no activity):** docstring (`:216-218`) — kept pure so it runs
  deterministically inside workflow code with no activity round-trip. A rebuild must NOT move this
  into an activity. (Consumed by the sibling per-app portfolio-score handling.)

---

## 6. Failure-classification constants + `classify_failure` (`wave_rationalization.py:261-377`)

### 6.1 `RECOVERABLE_FAILURE_ACTIVITIES` (`wave_rationalization.py:280-294`)
`frozenset` of activity names that run AFTER all wave-scoped artifacts are committed. A failure in
one of these → wave flips to `stuck-awaiting-recovery` (operator can `/resume` or
`/retry-rationalization`).
```text
RECOVERABLE_FAILURE_ACTIVITIES = frozenset({
    "create_target_app_and_repo",          # :285  post-G-DA per-target provisioning
    "update_wave_status",                  # :289  arch/data fan-out plumbing
    "update_application_line_projection",  # :293  wave-outcome projection post-G-DA
})
```

### 6.2 `TERMINAL_FAILURE_ACTIVITIES` (`wave_rationalization.py:302-324`)
`frozenset` of activities that run DURING artifact generation. A failure here → upstream artifacts
may be missing/partial/stale → wave flips to `failed` (recovery is `/reset` + `/retry-rationalization`).
```text
TERMINAL_FAILURE_ACTIVITIES = frozenset({
    "dispatch_agent_task",                       # :306
    "validate_artifact_against_schema",          # :309
    "write_artifact",                            # :310
    "create_pr",                                 # :311
    "reconcile_and_merge_pr",                    # :312
    "persist_rationalization_side_effects",      # :316
    "create_gate_record",                        # :319
    "submit_gate_evidence",                      # :320
    "mark_gate_ready_for_review",                # :321
    "set_gate_merge_blocked",                    # :322
})
```
⚠️ **GOTCHA-CF1 (the two sets are a tuned contract — keep verbatim):** the comments
(`:265-279`, `:296-324`) warn that mis-bucketing an activity has UX consequences: a recoverable
activity wrongly marked terminal forces an unnecessary full `/reset`; a terminal activity wrongly
marked recoverable shows a Resume affordance that silently no-ops. They must be kept in sync with
`specifications/phase-5/architecture-data-triggering.md` §D7 and
`olympus-api/src/services/wave.py::resume_wave_fanout`. A rebuild MUST reproduce both sets exactly
— membership is load-bearing for the recovery UX, not cosmetic.

### 6.3 `classify_failure(exc)` (`wave_rationalization.py:327-377`)
Walks the exception cause chain extracting activity names, returns `"recoverable"` or `"terminal"`.
**4 branches (incl. inner) + 2 loops.**

```text
def classify_failure(exc: BaseException) -> str:
    activity_names: list[str] = []                                # :353
    current: BaseException | None = exc                           # :354
    seen: set[int] = set()                                        # :355
    while current is not None and id(current) not in seen:        # :356  OUTER LOOP (cycle-guarded)
        seen.add(id(current))                                     # :357
        for attr in ("activity_type", "activity_name", "_activity_type"):  # :361  INNER LOOP (attr probe)
            value = getattr(current, attr, None)                  # :362
            if isinstance(value, str) and value:                  # :363  BRANCH A
                activity_names.append(value)                      # :364
                break                                             # :365  ← stop at first hit per exc node
        current = getattr(current, "__cause__", None) or getattr( # :367  walk cause, then context
            current, "__context__", None                         # :368
        )
    for name in activity_names:                                   # :371  LOOP (priority scan)
        if name in RECOVERABLE_FAILURE_ACTIVITIES:                # :372  BRANCH B
            return "recoverable"                                  # :373
        if name in TERMINAL_FAILURE_ACTIVITIES:                   # :374  BRANCH C
            return "terminal"                                     # :375
    return "terminal"                                             # :377  DEFAULT
```

- **OUTER LOOP** (`:356`): `while current is not None and id(current) not in seen` — walks
  `__cause__` then `__context__`. The `seen` set of `id()`s prevents infinite loops on a cyclic
  cause chain. ⚠️ **GOTCHA-CF2 (cycle guard via `id()`):** a rebuild MUST track visited nodes by
  `id()` and stop re-visiting, or a self-referential `__context__` loops forever.
- **INNER LOOP** (`:361`): probes three attribute name candidates in order
  (`activity_type`, `activity_name`, `_activity_type`) because different Temporal SDK versions expose
  the failing activity name under different names. ⚠️ **GOTCHA-CF3 (multi-SDK attr probe):** keep all
  three candidates and the order; the first that is a non-empty `str` wins for that node, then `break`.
- **BRANCH A** (`:363`): `isinstance(value, str) and value` — only non-empty strings are recorded.
- **cause-then-context walk** (`:367-368`): `getattr(current, "__cause__", None) or
  getattr(current, "__context__", None)` — prefers `__cause__` (explicit `raise … from`); falls to
  `__context__` (implicit chaining). ⚠️ **GOTCHA-CF4:** the `or` means a falsy/`None` `__cause__`
  falls through to `__context__`. Keep this exact precedence.
- **PRIORITY SCAN** (`:371-375`): iterates the COLLECTED names in chain order. **Recoverable wins on
  the first match** (BRANCH B before BRANCH C within the same iteration), but the scan is per-name
  top-to-bottom — the FIRST name (outermost exception) that lands in EITHER set decides.
  ⚠️ **GOTCHA-CF5 (recoverable-checked-first per name, outermost-first across names):** for a single
  activity name, recoverable is checked before terminal. Across the chain, the outermost-first
  ordering means the activity closest to the surface decides. A rebuild must preserve both: the
  per-name check order AND the chain iteration order.
- **DEFAULT** (`:377`): no recognized name → `"terminal"`. Docstring (`:341-351`): terminal is the
  safe default (matches pre-task-#88 behaviour); an operator can manually downgrade.
- **Caller:** `run()`'s outer `except` (sibling, `:1277`) calls `classify_failure(exc)` then routes
  to `persist_wave_failure` + `update_wave_status("stuck-awaiting-recovery")` (recoverable) or
  `persist_wave_failure` alone (terminal). See sibling spec for that routing.

---

## 7. `SKILLS` dict (`wave_rationalization.py:380-464`)

Legacy skill→artifact map keyed by workflow-local step-role names. **No branches** — a literal dict.
A rebuild MUST reproduce ALL entries verbatim (keys, `skill_id`, `artifact`, and the one
`companion_artifact`):

| `SKILLS` key | `skill_id` | `artifact` | extra |
|---|---|---|---|
| `cross-app-redundancy` (`:385`) | `redundancy-analyzer` | `redundancy-matrix.json` | — |
| `compare-ux-overlap` (`:392`) | `compare-ux-overlap` | `ux-overlap-matrix.json` | — |
| `wave-outcome-synthesis` (`:399`) | `wave-outcome-synthesizer` | `wave-outcome-synthesis.json` | — |
| `intra-app-redundancy` (`:403`) | `redundancy-analyzer` | `intra-app-redundancy.json` | (same skill, different scope) |
| `portfolio-integration-mapping` (`:415`) | `portfolio-integration-mapper` | `integration-graph.json` | — |
| `analyze-portfolio-redundancy` (`:419`) | `analyze-portfolio-redundancy` | `portfolio-redundancy-matrix.json` | `companion_artifact: "shared-identity-report.json"` (`:424`) |
| `cross-app-business-rule-analysis` (`:432`) | `cross-app-business-rule-analyzer` | `business-rule-redundancy.json` | — |
| `disposition-recommendation` (`:436`) | `disposition-recommender` | `disposition-recommendation.json` | — |
| `disposition-governance` (`:440`) | `disposition-governance` | `disposition-governance.json` | — |
| `user-impact` (`:444`) | `assess-user-impact` | `user-impact-analysis.json` | — |
| `classification` (`:448`) | `classify-application` | `classification.json` | — |
| `portfolio-score` (`:455`) | `portfolio-scorer` | `portfolio-score.json` | — |
| `wave-plan` (`:460`) | `sequencer` | `wave-plan.json` | — |

⚠️ **GOTCHA-SK1 (`redundancy-analyzer` reused for two scopes):** `cross-app-redundancy` and
`intra-app-redundancy` both map to `skill_id: "redundancy-analyzer"` (`:387`, `:405`); the agent
branches on input context to switch scope. A rebuild must keep both mapping to the same skill id.
⚠️ **GOTCHA-SK2 (`SKILLS` keys ≠ `RATIONALIZATION_STEPS` keys):** the legacy `SKILLS` keys conflate
skill role with step identity (e.g. `user-impact` vs contract `user-impact-analysis`, `wave-plan`
vs `wave-planning`, `portfolio-score` vs `portfolio-scoring`). See §8 for why both dicts exist. A
rebuild must keep both, with the divergent keys.

---

## 8. `RATIONALIZATION_STEPS` dict (`wave_rationalization.py:511-634`)

Contract-facing step registry keyed by the Rationalization **contract step IDs** (from
`olympus-contracts/.../rationalization.yaml`). Exists so the gate-review card aggregator and the
contract-compliance CI guard (`test_gate_card_contract_compliance` /
`test_rationalization_step_registry_matches_contract`) can assert parity with the contract. Each
entry: `title`, `skill_id`, `artifact`, `kind: "agent"`, `depends_on: list[str]`, and optionally
`dispatch_pending: True`. **No branches** — literal dict. Reproduce ALL entries verbatim:

| step_id | title | skill_id | artifact | depends_on | dispatch_pending |
|---|---|---|---|---|---|
| `cross-app-redundancy` (`:512`) | Cross-App Redundancy | `redundancy-analyzer` | `redundancy-matrix.json` | `[]` | — |
| `intra-app-redundancy` (`:519`) | Intra-App Redundancy | `redundancy-analyzer` | `intra-app-redundancy.json` | `[]` | — |
| `compare-ux-overlap` (`:526`) | UX Overlap Analysis | `compare-ux-overlap` | `ux-overlap-matrix.json` | `[]` | — |
| `portfolio-integration-mapping` (`:533`) | Portfolio Integration Mapping | `portfolio-integration-mapper` | `integration-graph.json` | `[]` | — |
| `analyze-portfolio-redundancy` (`:549`) | Portfolio Redundancy Analysis | `analyze-portfolio-redundancy` | `portfolio-redundancy-matrix.json` | `["cross-app-redundancy","intra-app-redundancy","compare-ux-overlap","portfolio-integration-mapping"]` | — |
| `disposition-recommendation` (`:561`) | Disposition Recommendation | `disposition-recommender` | `disposition-recommendation.json` | `["analyze-portfolio-redundancy"]` | — |
| `disposition-governance` (`:568`) | Disposition Governance | `disposition-governance` | `disposition-governance.json` | `["disposition-recommendation"]` | — |
| `user-impact-analysis` (`:575`) | User Impact Analysis | `assess-user-impact` | `user-impact-analysis.json` | `["disposition-recommendation"]` | — |
| `classification` (`:582`) | Classification & Risk Tiering | `classify-application` | `classification.json` | `["disposition-governance"]` | — |
| `portfolio-scoring` (`:589`) | Portfolio Scoring | `portfolio-scorer` | `portfolio-score.json` | `["classification"]` | — |
| `capability-consolidation-advisory` (`:600`) | Capability Consolidation Advisory | `capability-consolidation-advisor` | `capability-consolidation-plan.json` | `["analyze-portfolio-redundancy"]` | **`True`** |
| `wave-planning` (`:608`) | Wave Planning | `sequencer` | `wave-plan.json` | `["portfolio-scoring","user-impact-analysis"]` | — |
| `wave-outcome-synthesis` (`:615`) | Wave Outcome Synthesis | `wave-outcome-synthesizer` | `wave-outcome-synthesis.json` | `["wave-planning"]` | — |
| `portfolio-manifest-generation` (`:626`) | Portfolio Manifest Generation | `portfolio-manifest-generator` | `portfolio-manifest.json` | `["wave-outcome-synthesis"]` | **`True`** |

⚠️ **GOTCHA-RS1 (`dispatch_pending: True` ≠ dispatched):** `capability-consolidation-advisory`
(`:605`) and `portfolio-manifest-generation` (`:631`) are declared so the contract-compliance CI
guard passes, but they are NOT dispatched by this workflow yet (Task #59). A rebuild must keep them
in the registry (CI parity) but understand the workflow body never calls them.
⚠️ **GOTCHA-RS2 (`cross-app-business-rule-analysis` is in `SKILLS`, NOT here):** the comment
(`:540-548`) explains `cross-app-business-rule-analysis` IS dispatched + IS schema-validated but is
deliberately absent from `RATIONALIZATION_STEPS` because the authoritative contract YAML doesn't
list it as a contract step; adding it here would drift the CI parity check. A rebuild MUST NOT add
it to `RATIONALIZATION_STEPS`.
⚠️ **GOTCHA-RS3 (`depends_on` drives rework scoping):** the comment (`:487-510`) states `depends_on`
is the rework-resolver's input — on a card-scoped gate rejection, the resolver walks `depends_on` to
re-run ONLY the affected dependency-closure slice instead of the whole wave. The exact dependency
DAG above is therefore behavioral, not documentary. Reproduce it exactly. (Consumed by
`rework_targets_for` §9.)
⚠️ **GOTCHA-RS4 (insertion order == dispatch order):** the dict's insertion order is relied on as
the canonical dispatch / "upstream-most-first" order by `rework_targets_for` and
`rework_targets_from_card_decisions` (both filter `[s for s in RATIONALIZATION_STEPS if s in affected]`).
A rebuild MUST preserve insertion order (Python 3.7+ dicts are ordered; do not use an unordered map).

---

## 9. `rework_targets_for(rejected_step)` (`wave_rationalization.py:637-667`)

Transitive-closure of downstream consumers of `rejected_step`. **2 branches + 2 loops (fixpoint).**

```text
def rework_targets_for(rejected_step: str) -> list[str]:
    if rejected_step not in RATIONALIZATION_STEPS:               # :653  BRANCH 1 — unknown step
        return []                                                # :654
    affected = {rejected_step}                                   # :655  seed set
    progressed = True                                            # :656
    while progressed:                                            # :657  FIXPOINT LOOP
        progressed = False                                       # :658
        for step_id, spec in RATIONALIZATION_STEPS.items():      # :659  INNER LOOP over all steps
            if step_id in affected:                              # :660  BRANCH 2 — already in set
                continue                                         # :661
            deps = spec.get("depends_on") or []                 # :662
            if any(d in affected for d in deps):                 # :663  BRANCH 3 — depends on an affected step
                affected.add(step_id)                            # :664
                progressed = True                                # :665  ← keep iterating to fixpoint
    return [s for s in RATIONALIZATION_STEPS if s in affected]   # :667  insertion-order filter
```

- **BRANCH 1** (`:653`): step not in registry → `[]` (NOT `[rejected_step]`).
- **FIXPOINT LOOP** (`:657`): repeats the full pass until no new step is added in a pass
  (`progressed` stays `False`). This is a naïve transitive-closure — O(steps²) per pass, multiple
  passes. ⚠️ **GOTCHA-RT1 (fixpoint, not single-pass):** a single forward pass would miss
  grandchildren whose parents were added later in the SAME pass only after them. The `while
  progressed` re-runs until stable. A rebuild MUST loop to a fixpoint, not do one pass.
- **BRANCH 2** (`:660`): skip already-affected steps.
- **BRANCH 3** (`:663`): `any(d in affected for d in deps)` — a step joins `affected` if ANY of its
  `depends_on` is already affected.
- **RETURN** (`:667`): `[s for s in RATIONALIZATION_STEPS if s in affected]` — re-orders the set to
  RATIONALIZATION_STEPS insertion order (upstream-most-first). Returns `[rejected_step]` for a
  terminal step (no consumers), per docstring (`:644-646`).
- ⚠️ **GOTCHA-RT2 (`or []` guards missing `depends_on`):** `spec.get("depends_on") or []` (`:662`)
  tolerates a step def with no `depends_on` key OR a `None` value. Keep the `or []`.

---

## 10. `_step_id_for_artifact(artifact_filename)` (`wave_rationalization.py:675-680`)

Inverts `RATIONALIZATION_STEPS` artifact→step_id. **2 branches (loop + match).**

```text
def _step_id_for_artifact(artifact_filename: str) -> str | None:
    for step_id, spec in RATIONALIZATION_STEPS.items():          # :677  LOOP
        if spec.get("artifact") == artifact_filename:            # :678  BRANCH — exact match
            return step_id                                       # :679
    return None                                                  # :680  no match
```
- First exact `artifact` match wins (insertion order). No match → `None`.
- ⚠️ **GOTCHA-SA1 (exact filename match):** `spec.get("artifact") == artifact_filename` is an exact
  string equality (e.g. `"redundancy-matrix.json"`), not a suffix/contains match. A rebuild must use
  exact equality.

---

## 11. `rework_targets_from_card_decisions(card_decisions)` (`wave_rationalization.py:683-721`)

Union of rework targets across every **rejected** card. **6 branches + 2 loops.**

```text
def rework_targets_from_card_decisions(card_decisions: list[dict]) -> list[str]:
    affected: set[str] = set()                                   # :700
    for entry in card_decisions or []:                           # :701  LOOP (── `or []` guards None)
        if not isinstance(entry, dict):                          # :702  BRANCH 1 — skip non-dict
            continue                                             # :703
        if entry.get("decision") != "reject":                    # :704  BRANCH 2 — only rejects count
            continue                                             # :705
        artifact_type = entry.get("artifact_type") or ""         # :706
        step_id = _step_id_for_artifact(artifact_type)           # :711
        if step_id is None:                                      # :712  BRANCH 3 — artifact didn't map
            card_id = entry.get("card_id") or ""                 # :714  FALLBACK: try card_id
            if card_id in RATIONALIZATION_STEPS:                 # :715  BRANCH 4 — card_id is a step id
                step_id = card_id                                # :716
        if step_id is None:                                      # :717  BRANCH 5 — still unresolved
            continue                                             # :718  skip gate-level cards
        for s in rework_targets_for(step_id):                    # :719  INNER LOOP — expand closure
            affected.add(s)                                      # :720
    return [s for s in RATIONALIZATION_STEPS if s in affected]   # :721  insertion-order filter
```

- **OUTER LOOP** (`:701`): `card_decisions or []` — `None`-safe.
- **BRANCH 1** (`:702`): non-dict entry skipped.
- **BRANCH 2** (`:704`): `entry.get("decision") != "reject"` — only cards explicitly rejected
  contribute. Approved/abstained cards skipped.
- **BRANCH 3** (`:712`): artifact didn't resolve to a step → try the `card_id` fallback.
- **BRANCH 4** (`:715`): if `card_id` is itself a step id key, use it. ⚠️ **GOTCHA-CD1 (two-stage
  resolution):** the card's `artifact_type` is normally the bare committed filename
  (`redundancy-matrix.json`); some legacy gates store the kind (`"file_artifact"`) which won't map,
  so the fallback tries `card_id` directly against `RATIONALIZATION_STEPS`. A rebuild MUST try
  artifact-first, then card_id.
- **BRANCH 5** (`:717`): still `None` → skip silently. Docstring (`:692-695`): these are gate-level
  cards (gate_summary, ai-pre-review, …) with no corresponding DAG step.
- **INNER LOOP** (`:719`): expand each mapped step through `rework_targets_for` and union into
  `affected`.
- **RETURN** (`:721`): insertion-order filter (upstream-most-first).
- **Caller:** `_wait_for_gate` (sibling, `:5323`) calls this on a rejection and stores the result in
  `_rework_feedback[gate_key]["rework_targets"]`. An empty result means a legacy whole-gate reject →
  rerun falls back to the full fan-out.

---

## 12. `STEP_WEIGHTS` dict + invariant assert (`wave_rationalization.py:728-757`)

Progress weights summing to 100, keyed by a 21-name **progress shape** that is a SUPERSET of
`RATIONALIZATION_STEPS` (it adds the non-agent orchestration steps `commit-redundancy-artifacts`,
`create-grr-pr`, `gate-review-rr`, `factory-routing`, `commit-disposition-artifacts`,
`create-gda-pr`, `gate-review-da`). Reproduce ALL entries + the assert:

```text
STEP_WEIGHTS = {
    "cross-app-redundancy": 8.0,                  # :729
    "intra-app-redundancy": 5.0,                  # :730
    "compare-ux-overlap": 5.0,                    # :731
    "portfolio-integration-mapping": 4.0,         # :735
    "analyze-portfolio-redundancy": 5.0,          # :736
    "cross-app-business-rule-analysis": 3.0,      # :741
    "commit-redundancy-artifacts": 2.0,           # :742
    "create-grr-pr": 1.0,                         # :743
    "gate-review-rr": 7.0,                        # :744
    "disposition-recommendation": 8.0,            # :745
    "disposition-governance": 7.0,                # :746
    "user-impact-analysis": 4.0,                  # :747
    "classification": 8.0,                        # :748
    "portfolio-scoring": 7.0,                      # :749
    "wave-planning": 8.0,                          # :750
    "factory-routing": 1.0,                        # :751
    "commit-disposition-artifacts": 2.0,           # :752
    "create-gda-pr": 1.0,                          # :753
    "gate-review-da": 9.0,                         # :754
    "wave-outcome-synthesis": 5.0,                 # :755
}
assert abs(sum(STEP_WEIGHTS.values()) - 100.0) < 0.01, "STEP_WEIGHTS must sum to 100"   # :757
```
- ⚠️ **GOTCHA-SW1 (module-import-time assert):** the `assert` (`:757`) runs at MODULE IMPORT — if
  the weights don't sum to 100 (±0.01) the worker FAILS to import the module. A rebuild MUST keep
  the assert AND keep the weights summing to 100. (Listed sum: 8+5+5+4+5+3+2+1+7+8+7+4+8+7+8+1+2+1+9+5 = 100.0.)
- ⚠️ **GOTCHA-SW2 (consumed only by subclass `run()`, passed as `progress` to `_set_step`):** like
  the base's `STEP_WEIGHTS`, nothing in the helpers reads it; the sibling `_execute` body uses it to
  compute the `progress` float passed to `_set_step`. (`_set_step` clamps to `[0,100]`, sibling
  `:5255`.) A rebuild's helper layer need not reference it, but the module-level assert is part of
  this file's scope.

### `MAX_REWORK_ITERATIONS = 3` (`wave_rationalization.py:759`)
Module-level constant. ⚠️ **GOTCHA-MR-CEIL:** the rework ceiling for BOTH G-RR and G-DA. The sibling
`_execute` body compares `self._rework_iterations_grr > MAX_REWORK_ITERATIONS` (`:2203`) and
`self._rework_iterations_gda > MAX_REWORK_ITERATIONS` (`:2937`); exceeding it fails the wave. A
rebuild MUST set this to `3` and gate BOTH gate rework loops on it. (Note: strictly `>`, so up to 3
rework iterations are allowed; the 4th increment trips it.)

---

## 13. `_is_retire_or_replace_disposition(disp)` (`wave_rationalization.py:762-765`)

```text
def _is_retire_or_replace_disposition(disp: str | None) -> bool:
    if not disp:                                # :763  BRANCH — None / ""
        return False                            # :764
    return disp in ("Retire", "Replace")        # :765  exact Title-case membership
```
- **BRANCH** (`:763`): falsy → `False`.
- **Membership** (`:765`): exact `in ("Retire", "Replace")` — Title-case literals.
- ⚠️ **GOTCHA-RR1 (Title-case + only Retire/Replace gate user-impact):** the membership is
  case-sensitive Title-case. Per the wave flow (docstring `:21`), user-impact analysis runs per-app
  for **Retire/Replace only**. A `"retire"` lowercase would NOT match — callers must pass the
  Title-cased disposition. A rebuild must keep exact-Title-case membership.

---

## 14. Artifact-path builder helpers (`wave_rationalization.py:768-951`)

These are pure path-string builders consumed by the sibling `_execute` dispatch sites to stage agent
input artifacts. **No branches except simple loops.** Reproduce path templates EXACTLY (the gate /
agent reads fail silently if a path is wrong — see GOTCHA-AP1).

### 14.1 `_business_logic_artifact(app_id)` (`:768-776`)
`return f"discovery/{app_id}/business-logic.json"`. Matches Discovery Pass-2 commit path.

### 14.2 `_business_logic_artifacts_for_wave(app_ids)` (`:779-781`)
`return [_business_logic_artifact(a) for a in app_ids]` — one path per app.

### 14.3 `_ux_overlap_input_artifacts(app_ids)` (`:784-803`)
```text
paths = []
for app_id in app_ids:                                            # :800  LOOP
    paths.append(f"discovery/{app_id}/ux-accessibility.json")     # :801
    paths.append(f"discovery/{app_id}/catalog.json")              # :802
return paths
```
⚠️ **GOTCHA-AP1 (filename is `catalog.json`, NOT `catalog-application.json`):** the docstring
(`:794-795`) says "catalog-application.json" but the CODE emits `catalog.json` (`:802`). The CODE is
authoritative — Discovery commits `catalog.json` (see §14.6). Staging the wrong path makes the agent
fall back to slow billable GitHub-API fetches from inside the sandbox (the $2+/pass failure mode the
docstring warns about). A rebuild MUST emit `catalog.json`.

### 14.4 `_discovery_passes_for_app(app_id)` (`:824-832`) + `_DISCOVERY_PASSES` (`:813-821`)
```text
_DISCOVERY_PASSES = ("catalog", "structural-analysis", "business-logic",
                     "quality-risk", "ux-accessibility", "tco-baseline", "synthesis")   # :813-821
def _discovery_passes_for_app(app_id) -> list[str]:
    return [f"discovery/{app_id}/{name}.json" for name in _DISCOVERY_PASSES]             # :832
```
⚠️ **GOTCHA-AP2 (canonical Discovery filenames):** the comment (`:806-812`) is explicit —
`catalog.json` not `catalog-application.json`, `synthesis.json` not `discovery-synthesis.json`. The
7-tuple order is fixed. A rebuild must reproduce all 7 names exactly.

### 14.5 `_wave_context_artifacts(wave_id, app_id)` (`:835-865`)
```text
prefix = f"rationalization/wave-{wave_id}"                                  # :858
return [
    f"{prefix}/redundancy-matrix.json",                                     # :860
    f"{prefix}/ux-overlap-matrix.json",                                     # :861
    f"{prefix}/integration-graph.json",                                     # :862
    f"{prefix}/portfolio-redundancy-matrix.json",                           # :863
    f"{prefix}/{app_id}/intra-app-redundancy.json",                         # :864
]
```
⚠️ **GOTCHA-AP3 (REQUIRED wave context, not optional):** docstring (`:835-857`) — per-app
dispositions CANNOT recommend Consolidate or surface capability-level Retire/Replace without these
5 wave-scoped artifacts. The last entry is per-app-nested (`{prefix}/{app_id}/...`); the first four
are wave-root. Pair with §14.6 for optional inputs. A rebuild must thread all 5 into each per-app
disposition dispatch's `input_artifacts`.

### 14.6 `_wave_context_optional_artifacts(wave_id)` (`:868-889`)
```text
prefix = f"rationalization/wave-{wave_id}"                                  # :886
return [f"{prefix}/shared-identity-report.json"]                            # :888
```
⚠️ **GOTCHA-AP4 (optional → must NOT hard-fail):** docstring (`:868-885`) — `shared-identity-report.json`
is the legacy companion output of `analyze-portfolio-redundancy` that the rewritten skill no longer
always emits. It is staged via `optional_input_artifacts` (NOT `input_artifacts`) so the agent
runtime treats a 404 as "not present yet" and skips it, instead of aborting. Threading it into the
required set previously took down every per-app disposition on waves whose PRA run didn't emit the
companion. A rebuild MUST place this in `optional_input_artifacts`.

### 14.7 `_portfolio_integration_input_artifacts(app_ids)` (`:892-904`)
```text
paths = []
for app_id in app_ids:                                            # :901  LOOP
    paths.append(f"discovery/{app_id}/catalog.json")              # :902
    paths.append(f"discovery/{app_id}/structural-analysis.json")  # :903
return paths
```
Inputs for `portfolio-integration-mapper`: per-app catalog + structural analysis.

### 14.8 `_portfolio_redundancy_input_artifacts(wave_id, app_ids)` (`:907-924`)
```text
prefix = f"rationalization/wave-{wave_id}"                              # :916
paths = [f"{prefix}/redundancy-matrix.json",                           # :918
         f"{prefix}/integration-graph.json"]                           # :919
for app_id in app_ids:                                                 # :921  LOOP
    paths.append(f"{prefix}/{app_id}/intra-app-redundancy.json")       # :922
    paths.append(f"discovery/{app_id}/business-logic.json")            # :923
return paths
```
Inputs for the `analyze-portfolio-redundancy` synthesis pass: wave cross-app matrix +
integration-graph + per-app intra-app-redundancy + per-app business-logic.

### 14.9 `_cross_app_business_rule_input_artifacts(app_ids)` (`:927-936`)
`return [_business_logic_artifact(app_id) for app_id in app_ids]` — one business-logic path per app
for `cross-app-business-rule-analyzer`.

### 14.10 `_disposition_input_artifacts(wave_id, app_id)` (`:939-950`)
```text
return _discovery_passes_for_app(app_id) + _wave_context_artifacts(wave_id, app_id)   # :948-950
```
⚠️ **GOTCHA-AP5 (concatenation order):** Discovery 7-pass set FIRST, then the 5 wave-context paths.
The full 12-path input bundle for `disposition-recommender`, mirroring its SKILL.md Inputs list. A
rebuild must concatenate in this order (it determines what the agent sees first; the order is the
contract surface for the skill).

---

## 15. `_with_context_priors(context, skill_id)` — async (`wave_rationalization.py:953-995`)

Folds best-effort context priors into a dispatch context. **3 branches.** Async helper that runs an
activity.

```text
async def _with_context_priors(context: dict, skill_id: str) -> dict:
    try:
        result = await workflow.execute_activity(
            load_context_priors,
            LoadContextPriorsInput(skill_id=skill_id),
            start_to_close_timeout=timedelta(seconds=10),         # :975
            retry_policy=RETRY_POLICIES["transient"],             # :976
        )
    except Exception as exc:                                      # :978  BRANCH 1 — best-effort swallow
        workflow.logger.warning("context_priors load failed (continuing without priors): %s",
                                exc, extra={"skill_id": skill_id})
        return context                                            # :984  ← unchanged context
    priors = getattr(result, "priors", None) or []               # :985
    if not priors:                                               # :986  BRANCH 2 — no priors
        return context                                           # :987  ← unchanged context
    merged = dict(context)                                       # :988  shallow copy (don't mutate caller's dict)
    merged["context_priors"] = priors                            # :994
    return merged                                                # :995
```

- **Activity:** `load_context_priors(LoadContextPriorsInput(skill_id))` — **10s** start_to_close;
  retry **`transient`** (= `HTTP_RETRY_POLICY`, 3 attempts, 1-15s backoff).
- **BRANCH 1** (`:978`): any exception → log + return the ORIGINAL `context` unchanged. Priors are
  best-effort (`noqa: BLE001`).
- **BRANCH 2** (`:986`): `getattr(result, "priors", None) or []` empty → return original context.
- **Fall-through** (`:988-995`): `merged = dict(context)` (shallow copy), set
  `merged["context_priors"] = priors`, return `merged`.
- ⚠️ **GOTCHA-CP1 (shallow-copy, not mutate):** `dict(context)` (`:988`) ensures a caller-owned dict
  is never mutated. A rebuild MUST copy before assigning, or repeated dispatches accumulate keys.
- ⚠️ **GOTCHA-CP2 (this is the standalone async variant — distinct from base's inline version):**
  the base's `_dispatch_agent` does the priors load inline under a patch gate (`context-priors-v1`).
  This module-level helper is NOT patch-gated — it is called directly by sibling dispatch sites. A
  rebuild must keep it as a free async function with the 10s/`transient` shape, swallowing failures.

---

## 16. `_with_fixture_scenario(context, skill_id, fixture_scenarios)` (`wave_rationalization.py:998-1018`)

Threads a test-only `fixture_scenario` key. **2 branches.** Synchronous (no activity).

```text
def _with_fixture_scenario(context: dict, skill_id: str, fixture_scenarios: dict[str, str]) -> dict:
    scenario = fixture_scenarios.get(skill_id) if fixture_scenarios else None   # :1012  BRANCH 1 (inline)
    if not scenario:                                                            # :1013  BRANCH 2
        return context                                                          # :1014  ← unchanged
    merged = dict(context)                                                      # :1016  shallow copy
    merged["fixture_scenario"] = scenario                                       # :1017
    return merged                                                              # :1018
```

- **BRANCH 1** (`:1012` inline ternary): `fixture_scenarios.get(skill_id) if fixture_scenarios else
  None` — guards a `None`/empty map (production passes `{}`).
- **BRANCH 2** (`:1013`): `not scenario` (None or "") → return original context.
- **Fall-through**: shallow-copy + set `fixture_scenario`.
- ⚠️ **GOTCHA-FS1 (no-op in production, DECISION-018 mock hook):** production callers pass an empty
  `fixture_scenarios` dict → BRANCH 1 yields `None` → returns context unchanged. Only
  `MockAgentRuntime` under test consumes `context["fixture_scenario"]` to pick a deterministic
  fixture branch. A rebuild MUST keep this no-op path and the shallow-copy.

---

## 17. `_build_rationalization_step_entry(title, skill_id, artifact_filename, result)` (`wave_rationalization.py:1021-1074`)

Builds one entry for the `evidence_data.steps` map consumed by the gate service's
`_build_unit_artifacts` renderer. **4 branches + 1 loop.** Pure (no activity). `result` is an
`AgentTaskResult` (may arrive as dataclass OR dict at the workflow boundary).

```text
def _build_rationalization_step_entry(title, skill_id, artifact_filename, result) -> dict:
    primary_output = ""                                          # :1038
    if result.output_artifacts:                                  # :1039  BRANCH 1
        primary_output = result.output_artifacts[0]              # :1040  first artifact string

    file_artifacts: list[dict] = []                              # :1042
    for out_file in result.output_files:                         # :1043  LOOP
        if isinstance(out_file, dict):                           # :1047  BRANCH 2 — dict shape
            path = out_file.get("path", "")                      # :1048
            content = out_file.get("content", "")                # :1049
            encoding = out_file.get("encoding", "utf-8")         # :1050
        else:                                                    # :1051  dataclass shape
            path = getattr(out_file, "path", "")                 # :1052
            content = getattr(out_file, "content", "")           # :1053
            encoding = getattr(out_file, "encoding", "utf-8")    # :1054
        if not path:                                             # :1055  BRANCH 3 — skip pathless file
            continue                                             # :1056
        file_artifacts.append(                                   # :1057
            {"path": path, "content": content, "encoding": encoding}
        )

    return {                                                     # :1061-1074
        "title": title,
        "skill_id": skill_id,
        "artifact": artifact_filename,
        "output": primary_output,
        "file_artifacts": file_artifacts,
        "metadata": {
            "model_used": result.model_used,
            "duration_ms": result.duration_ms,
            "token_usage_input": result.token_usage_input,
            "token_usage_output": result.token_usage_output,
            "cost_estimate_usd": result.cost_estimate_usd,
        },
    }
```

- **BRANCH 1** (`:1039`): `if result.output_artifacts:` → `primary_output = output_artifacts[0]`
  (the string the card body renders); else stays `""`.
- **LOOP** (`:1043`): iterate `result.output_files`.
  - **BRANCH 2** (`:1047`): `isinstance(out_file, dict)` → read via `.get(...)`; else (dataclass) →
    read via `getattr(...)`. ⚠️ **GOTCHA-BS1 (dual dataclass/dict shape):** Temporal's payload
    converter may deliver `OutputFile` as either the dataclass OR a plain dict at the workflow
    boundary. The handler MUST handle both — `.get("path","")` for dicts, `getattr(.,"path","")`
    for dataclasses — both with the SAME defaults (`""`, `""`, `"utf-8"`). A rebuild that assumes
    one shape drops file_artifacts on the other.
  - **BRANCH 3** (`:1055`): `if not path: continue` — skip files with empty path.
- **RETURN** (`:1061`): a dict with keys `title`, `skill_id`, `artifact`, `output` (primary string),
  `file_artifacts` (list of `{path, content, encoding}`), and `metadata` (5 specific fields —
  notably **`output_files` is NOT in metadata**, unlike the base; the files are surfaced as
  `file_artifacts`).
- ⚠️ **GOTCHA-BS2 (inlines full content — NOT slim):** unlike `LineWorkflowBase._build_evidence_data`
  (slim by default), THIS builder inlines the full `content` of every output file into
  `file_artifacts` (`:1058`). The docstring (`:1027-1036`) explains: without this bundling the gate
  review UI renders the empty fallback card (just PR URL + one-line guidance) — useless for reviewer
  work on a wave-scoped G-RR/G-DA gate. A rebuild MUST inline content here. (The sibling caller
  decides how large bundles are kept under Temporal blob limits.)
- ⚠️ **GOTCHA-BS3 (5 metadata fields, no `output_files`):** the `metadata` sub-dict carries exactly
  `model_used`, `duration_ms`, `token_usage_input`, `token_usage_output`, `cost_estimate_usd` —
  read directly off `result.*`. A rebuild must include exactly these 5 and must NOT add `output_files`.

---

## 18. CLASS `WaveRationalizationWorkflow(HILSignalsMixin)` — declaration (`wave_rationalization.py:1077-1085`)

- `@workflow.defn` (`:1077`) — registers the workflow type. Default workflow name =
  `"WaveRationalizationWorkflow"`. A rebuild must register under this exact name (the API/worker
  start it by this name).
- `class WaveRationalizationWorkflow(HILSignalsMixin):` (`:1078`) — inherits **only**
  `HILSignalsMixin`. (See TOP-LEVEL GOTCHA — NOT `LineWorkflowBase`.)
- **No `ClassVar`s** (no `ASSEMBLY_LINE`, `ARTIFACT_ROOT`, `STEPS`, etc.). The line identity is
  hard-coded in `get_status` (`AssemblyLine.RATIONALIZATION`, sibling `:5956`) and paths are
  hard-coded as `rationalization/...` / `discovery/...` literals in the helpers above. A rebuild
  must NOT introduce the base's classvar surface; the constants are module-level + literals.

---

## 19. `__init__(self) -> None` — STATE (`wave_rationalization.py:1087-1237`)

> ⚠️ **GOTCHA-INIT0 (`super().__init__()` FIRST):** `super().__init__()` (`:1088`) is the FIRST
> statement — it runs `HILSignalsMixin.__init__` which initializes the **8 inherited HIL vars**
> (`approved=False`, `plan_approved=False`, `plan_feedback_received=False`,
> `plan_feedback_comments=""`, `document_approved=False`, `document_feedback_received=False`,
> `document_feedback_comments=""`, `cancelled=False` — see `_HILSignalsMixin.md` §1). A rebuild MUST
> call `super().__init__()` first, then set the line-state vars below. Skipping it leaves
> `self.cancelled` undefined and every `wait_condition(... or self.cancelled)` raises `AttributeError`.

> ⚠️ **GOTCHA-INIT1 (re-declares line state — does NOT inherit it):** because this class does NOT
> extend `LineWorkflowBase`, the vars `_wave_id`/`_portfolio_id`/`_status`/`_current_step`/
> `_progress_pct`/`_pending_gate`/`_started_at`/`_updated_at`/`_rework_feedback`/`_merge_retry_signalled`
> that LOOK like base state are actually re-declared HERE. A rebuild must initialize them in this
> `__init__`, not assume a base sets them.

The complete state table. **All set in `__init__`** (`wave_rationalization.py:1087-1237`). "Mutated
by" cites the sibling line that writes it (those bodies are spec'd in sibling files; here we record
the lifecycle so the STATE contract is complete).

| # | Var | Type (annotation) | Initial | `__init__` line | Mutated by → value | When |
|---|-----|-------------------|---------|------------------|---------------------|------|
| 1 | `_wave_id` | `str` | `""` | 1089 | `run()` → `input.wave_id` (`:1245`) | run start |
| 2 | `_portfolio_id` | `str` | `""` | 1092 | `run()` → `input.portfolio_id` (`:1246`) | run start; **gates `_execution_ctx`** (returns `None` if empty, sibling `:4737`) |
| 3 | `_status` | `WorkflowStatus` | `WorkflowStatus.PENDING` | 1093 | `run()`→`RUNNING` (`:1244`)/`FAILED` (`:1261`); `_wait_for_gate`→`WAITING_FOR_SIGNAL`/`RUNNING`/`CANCELLED` (sibling `:5265,5276,5291`); `cancel_all_children`→`CANCELLED` (sibling `:5752`); `_execute` final→`COMPLETED` | lifecycle + gate waits + cancel |
| 4 | `_current_step` | `str` | `""` | 1094 | `_set_step`→`step` (sibling `:5254`); `run()` fail→`"failed"` (`:1262`); `cancel_all_children`→`"cancelled"` (sibling `:5753`) | each step / fail / cancel |
| 5 | `_progress_pct` | `float` | `0.0` | 1095 | `_set_step`→`max(0,min(100,progress))` (sibling `:5255`) | each step |
| 6 | `_pending_gate` | `GateType \| None` | `None` | 1096 | `_wait_for_gate`→`GateType(gate_key)` or `None` then back to `None` (sibling `:5264,5290`) | gate wait window |
| 7 | `_started_at` | `str` | `""` | 1097 | `run()`→`_now_iso()` (`:1247`) | run start |
| 8 | `_updated_at` | `str` | `""` | 1098 | `run()`/`_set_step`/`_wait_for_gate`/every signal handler→`_now_iso()` | many |
| 9 | `_gate_decisions` | `dict[str, list[tuple]]` | `{}` | 1106 | `gate_approved`/`gate_rejected` append a **5-tuple** to `_gate_decisions[gate_key]` (sibling `:5659,5683`); `_register_gate_key` extends with buffered entries (sibling `:5629`); `_wait_for_gate` does `setdefault(gate_key,[])` (sibling `:5268`) | gate signals / register / wait |
| 10 | `_gate_decisions_consumed` | `dict[str, int]` | `{}` | 1107 | `_wait_for_gate` `setdefault(gate_key,0)` then `[gate_key]=consumed+1` (sibling `:5269,5289`) | each consumed decision |
| 11 | `_gate_id_to_key` | `dict[str, str]` | `{}` | 1116 | `_register_gate_key`→`[gate_id]=gate_key` (sibling `:5625`) | each gate-record create |
| 12 | `_pending_signals_by_gate_id` | `dict[str, list[tuple[GateStatus,str,str]]]` | `{}` | 1128 | `gate_approved`/`gate_rejected` buffer when key unknown (sibling `:5655,5679`); `_register_gate_key` `pop(gate_id,[])` to flush (sibling `:5626`) | early signals / flush |
| 13 | `_stakeholder_approved` | `bool` | `False` | 1133 | `stakeholder_approved` (non-tier-1 scope)→`True` (sibling `:5785`); `_execute` G-DA dual-signal consume→`False` (sibling `:2915,2935`) | G-DA dual-signal |
| 14 | `_stakeholder_info` | `str` | `""` | 1134 | `stakeholder_approved` (non-tier-1)→`f"{stakeholder} approved scope: {scope}"` (sibling `:5786`) | G-DA dual-signal |
| 15 | `_tier1_approval_records` | `dict[str, dict[str, str]]` | `{}` | 1150 | `stakeholder_approved` (tier-1 scope)→`[app_id]={app_id,approval_id,stakeholder,scope,approved_at}` (sibling `:5777`) | tier-1 sign-off |
| 16 | `_tier1_approved_apps` | `set[str]` | `set()` | 1151 | `stakeholder_approved` (tier-1)→`.add(app_id)` (sibling `:5772`) | tier-1 sign-off |
| 17 | `_rework_iterations_grr` | `int` | `0` | 1153 | `_execute` G-RR reject branch→`+= 1` (sibling `:2202`) | each G-RR rework |
| 18 | `_rework_iterations_gda` | `int` | `0` | 1154 | `_execute` G-DA reject branch→`+= 1` (sibling `:2936`) | each G-DA rework |
| 19 | `_rework_feedback` | `dict[str, dict]` | `{}` | 1155 | `_wait_for_gate`: approve→`pop(gate_key,None)`; reject→`[gate_key]={…rework_targets…}` (sibling `:5294,5324`); `_merge_capability_lineage_row_rework`→`["G-DA"]=merged{row_rework…}` (sibling `:5413`) | gate decision / lineage rework |
| 20 | `_approval_feedback` | `dict[str, dict]` | `{}` | 1170 | `_wait_for_gate`: approve w/ justification→`[gate_key]={gate,approved_by,guidance,approved_at}`; approve w/o→`pop`; reject→`pop` (sibling `:5302,5309,5315`) | gate decision |
| 21 | `_validation_warnings` | `dict[str, list[str]]` | `{}` | 1178 | schema-validation helper→`setdefault(warning_key,[]).extend(errors)` (sibling `:4836`) | per-app schema validation |
| 22 | `_merge_retry_signalled` | `bool` | `False` | 1183 | `merge_retry` signal→`True` (sibling `:5611`); `_reconcile_and_merge_with_retry_loop`→`False` before block (sibling `:5591`) | merge_blocked loop |
| 23 | `_architecture_child_handles` | `list[tuple[str, Any]]` | `[]` | 1197 | dispatch path appends `(child_workflow_id, handle)` (sibling, patched path); `cancel_all_children`→`[]` after cancel sweep (sibling `:5746`) | child spawn / cancel-all |
| 24 | `_cancel_all_children_requested` | `bool` | `False` | 1202 | `cancel_all_children`→`True` (sibling `:5721`) | cancel-all signal |
| 25 | `_dispatch_received` | `bool` | `False` | 1208 | `dispatch_architecture`/`dispatch_architecture_v2`→`True` (sibling `:5814,5840`) | pre-dispatch hold release |
| 26 | `_dispatch_payload` | `DispatchArchitecturePayload \| None` | `None` | 1209 | `dispatch_architecture[_v2]`→normalized v1 payload (sibling `:5813,5839`) | dispatch signal |
| 27 | `_dispatch_status` | `dict[str, DispatchTargetStatus]` | `{}` | 1212 | `_provision_one_target` / `_spawn_children_for_target` (sibling) write per-source-app status; `dispatch_results` query reads `.values()` (sibling `:5945`) | fan-out progress |
| 28 | `_pending_dispatch_entries` | `list[PendingDispatchEntry]` | `[]` | 1217 | `_execute` populates just before the pre-dispatch hold (sibling); `pending_dispatch_payload` query returns a copy (sibling `:5922`) | pre-dispatch hold |
| 29 | `_pending_target_dispatch_entries` | `list[PendingTargetDispatchEntry]` | `[]` | 1224 | `_execute` populates (sibling); `pending_target_dispatch_payload` query returns a copy (sibling `:5939`) | pre-dispatch hold (v2) |
| 30 | `_v2_dispatch_meta` | `dict[str, dict[str, str]]` | `{}` | 1231 | `dispatch_architecture[_v2]`→`_extract_v2_metadata(payload)` (sibling `:5811,5837`) | dispatch signal (v2) |
| 31 | `_pending_retries` | `list[RetryTargetDispatchPayload]` | `[]` | 1236 | `retry_target_dispatch` signal→`.append(payload)` (sibling `:5912`); `_execute` drains after main gather (sibling) | single-target retry |

### 19.1 ⚠️ GOTCHAs on the STATE shape

- ⚠️ **GOTCHA-S-GATEQ (per-gate dict queues, NOT base's flat list):** `_gate_decisions` is
  `dict[gate_key → list[tuple]]` (`:1106`) and `_gate_decisions_consumed` is `dict[gate_key → int]`
  (`:1107`). This is the deliberate divergence from `LineWorkflowBase` (which uses one flat list + one
  int). The comment (`:1100-1105`) explains: keyed by gate_type string so G-RR and G-DA decisions
  don't collide if both have activity in flight ("they can't in practice, but defensive"). Each gate
  has its OWN consume cursor so the two gates' decisions land independently. A rebuild MUST use
  per-gate dict queues + per-gate cursors, NOT the base's single-cursor pattern, or a G-DA decision
  arriving during a G-RR wait would be mis-consumed.
- ⚠️ **GOTCHA-S-5TUPLE (5-tuple gate entries):** `_gate_decisions[gate_key]` entries are
  **5-tuples** `(GateStatus, actor, reason, reason_category, card_decisions)` (comment `:1103-1105`,
  appended by `gate_approved`/`gate_rejected` sibling `:5646-5652,5670-5676`). `card_decisions` is a
  list of W8 per-card reject payloads (empty on approval); `reason_category` is a
  `RejectReasonCategory` value or `None`. `_wait_for_gate` (sibling `:5283`) tolerates BOTH 5-tuple
  and legacy 3-tuple (`(status, actor, reason)`) entries — the buffered-signal path
  (`_pending_signals_by_gate_id` annotated as 3-tuples at `:1129`) and the live signal path may
  produce different lengths. ⚠️ The annotation on `_pending_signals_by_gate_id` says
  `list[tuple[GateStatus, str, str]]` (3-tuple, `:1129`) but `gate_approved`/`gate_rejected` actually
  buffer **5-tuples** into it (sibling `:5655,5679`). The annotation is documentary/stale — the
  runtime shape is 5-tuple. A rebuild MUST: buffer 5-tuples, make the consumer tolerate both lengths,
  and NOT enforce the 3-tuple annotation.
- ⚠️ **GOTCHA-S-EARLY (early-signal buffering is load-bearing):** the comment (`:1118-1130`) records
  a real bug — reviewer automations / tests fire `gate_approved`/`gate_rejected` BEFORE
  `create_gate_record` returns; without buffering the signal was silently dropped and the workflow
  hung in `_wait_for_gate` forever (reproduced under CI load + xdist-parallel runs). The fix:
  `gate_approved`/`gate_rejected` look up `_gate_id_to_key`; on a MISS they buffer into
  `_pending_signals_by_gate_id[gate_id]`; `_register_gate_key` (called at each gate-record create
  site) flushes the buffer into `_gate_decisions[gate_key]` preserving arrival order. A rebuild MUST
  implement this three-var dance (`_gate_id_to_key` + `_pending_signals_by_gate_id` +
  `_register_gate_key`) or it inherits the hang-forever bug. (Bodies are in the sibling spec; the
  STATE here must declare all three vars.)
- ⚠️ **GOTCHA-S-GATEID-UUID (gate_id is a UUID, not a prefixed string):** the comment (`:1109-1116`)
  records that pre-0.2 code tried to parse the `gate_key` prefix out of `gate_id`, but gate_ids are
  actually UUIDs, so every signal got dropped as "unrecognized gate_id." The fix is the
  `_gate_id_to_key` map populated at gate-record-create time. A rebuild MUST route signals by UUID
  lookup, NOT by parsing the gate_id string.
- ⚠️ **GOTCHA-S-TIER1-DUAL (set + records dual-tracking):** `_tier1_approved_apps` (`set[str]`,
  `:1151`) is a DERIVED view kept alongside the richer `_tier1_approval_records`
  (`dict[app_id → {app_id, approval_id, stakeholder, scope, approved_at}]`, `:1150`). The comment
  (`:1143-1151`, issue #186) explains: the full record is for the G-DA evidence builder /
  gate-pre-review skill (human-safety-review evidence → raises pre-review confidence); the set is
  preserved so existing branch checks (`app_id in self._tier1_approved_apps`, sibling `:3701,3873`)
  keep working without churn. A rebuild MUST maintain BOTH — `stakeholder_approved` (tier-1 scope)
  writes both (sibling `:5772,5777`). Dropping the set breaks the classify-app unblock wait
  (sibling `:3701`).
- ⚠️ **GOTCHA-S-TIER1-PARSE (approval_id encodes app_id):** the tier-1 convention is
  `approval_id == "tier1-{app_id}-{n}"`. `stakeholder_approved` strips the `"tier1-"` prefix then
  `remainder.rsplit("-", 1)[0]` to recover `app_id` (sibling `:5768-5771`). Multiple Tier-1
  assignments may wait concurrently (per-app fan-out), so the per-app keying matters. (Parsing body
  is sibling; STATE here declares the two tier-1 vars.)
- ⚠️ **GOTCHA-S-REWORK-FB (rework feedback carries `rework_targets` + optional `row_rework`):**
  `_rework_feedback[gate_key]` (set by `_wait_for_gate` reject, sibling `:5324`) is a 7-key dict:
  `{gate, rejected_by, reason, reason_category, card_decisions, rework_targets, rejected_at}` — note
  it ADDS `rework_targets` (from `rework_targets_from_card_decisions`, §11) vs the base's 6-key dict.
  For G-DA, `_merge_capability_lineage_row_rework` (sibling `:5413`) further folds in `row_rework`
  + `row_rework_summary` keys WITHOUT overwriting the existing keys. A rebuild MUST: store the 7-key
  dict on reject, clear on approve (`pop`), and (G-DA only) merge row-level lineage rework non-
  destructively.
- ⚠️ **GOTCHA-S-APPROVAL-GUIDANCE (approve-with-guidance, separate from rework):** `_approval_feedback`
  (`:1170`) is distinct from `_rework_feedback`. On a NON-empty-justification APPROVAL,
  `_wait_for_gate` stashes `{gate, approved_by, guidance, approved_at}` keyed by gate_key (sibling
  `:5302`) so the next downstream skill dispatch folds it into `context["approval_guidance"]`
  (sibling `:3295`). The comment (`:1157-1169`) explains this exists so reviewers don't have to
  REJECT a gate just to carry a note onto the next line (which would burn a rework iteration). It is
  cleared on the next REJECTION of the same gate (sibling `:5315`) AND on a blank-justification
  approval (sibling `:5309`). A rebuild MUST keep `_approval_feedback` separate from `_rework_feedback`
  and clear it on reject + blank approve.
- ⚠️ **GOTCHA-S-MERGE-RETRY-INLINE (own merge-retry flag):** `_merge_retry_signalled` (`:1183`) is
  re-declared here (comment `:1180-1182`: "this workflow inlines the same logic because it doesn't
  inherit from LineWorkflowBase"). Both the `merge_retry` signal (sibling `:5611`) and the inlined
  `_reconcile_and_merge_with_retry_loop` (sibling `:5527-5602`) live in this class. A rebuild must
  NOT rely on the base's flag/loop.
- ⚠️ **GOTCHA-S-CHILD-HANDLES (`Any`-typed handle tuples + cancel-all):** `_architecture_child_handles`
  is `list[tuple[str, Any]]` (`:1197`) — `(child_workflow_id, ChildWorkflowHandle)`. Populated only
  on the patched dispatch path (`wave-rationalization-architecture-dispatch-v1`); empty for pre-patch
  replays (comment `:1185-1197`), which makes `cancel_all_children` a no-op. The `Any` type is
  deliberate (Temporal handle type isn't easily annotated in the sandbox). A rebuild keeps the tuple
  shape + the empty-list-is-no-op contract.
- ⚠️ **GOTCHA-S-PATCH-GUARDED-STATE (dispatch bookkeeping is patch-scoped):** vars 25-31
  (`_dispatch_received`, `_dispatch_payload`, `_dispatch_status`, `_pending_dispatch_entries`,
  `_pending_target_dispatch_entries`, `_v2_dispatch_meta`, `_pending_retries`) are all populated ONLY
  on the patched path (comment `:1204-1207`: "Pre-patch replays never touch these fields"). They are
  STILL initialized in `__init__` (so the constructor shape is stable across patch versions) but the
  bodies that write them are guarded by `workflow.patched("wave-rationalization-architecture-dispatch-v1")`
  in the sibling `_execute`. ⚠️ A rebuild MUST initialize all 7 to their empty defaults in `__init__`
  unconditionally (so queries like `dispatch_results` / `pending_dispatch_payload` never `AttributeError`),
  but only WRITE them under the patch gate. The patch ID string is load-bearing for replay — see the
  sibling spec.
- ⚠️ **GOTCHA-S-V2META-KEY (v2 metadata keyed by target_app_id):** `_v2_dispatch_meta` (`:1231`) is
  keyed by the **anchor source_app_id** per the `__init__` comment (`:1225-1231`) BUT
  `_extract_v2_metadata` (sibling `:5843-5898`) actually keys it by **`target_app_id`** (PR #495 fix
  — comment `:5849-5855`: keying by source_app_id broke capability-grain rationalization where N
  targets share an anchor, last-write-wins corrupted 11/12 targets' `target_service_id`). ⚠️ The
  `__init__` comment is STALE; the authoritative behavior (sibling) keys by `target_app_id`. A
  rebuild MUST key `_v2_dispatch_meta` by `target_app_id`, not the anchor source app.

### 19.2 ⚠️ GOTCHA — vars this workflow does NOT have (vs `LineWorkflowBase`)

A rebuild must NOT add these base-only vars (this workflow's STATE is intentionally a different
shape): `_app_id` (this workflow is wave-scoped, never per-app — all dispatches set `app_id=""` +
`wave_id`), `_risk_tier`, `_gate_decisions` as a flat `list`, `_gate_decisions_consumed` as a single
`int`, `_rework_iterations` as a dict (here it's two scalar ints `_rework_iterations_grr` /
`_rework_iterations_gda`), `_step_results`, `_step_committed_paths`, `_agent_metadata`. The evidence
bundle is built by the module-level `_build_rationalization_step_entry` (§17) from per-step
`AgentTaskResult`s the sibling `_execute` threads, NOT from base's `_agent_metadata`/`_step_results`.

---

## 20. RESILIENCE notes for this file's scope

- **No `workflow.now()`-free timestamps:** every timestamp uses `_now_iso()` → `workflow.now()`
  (`:135`). Deterministic under replay.
- **Best-effort activity in scope:** `_with_context_priors` (§15) — `load_context_priors`, 10s,
  `transient`, swallows all exceptions, returns unchanged context. Never fails a dispatch.
- **Module-import-time invariant:** the `STEP_WEIGHTS` sum-to-100 `assert` (`:757`) fails worker
  module import if violated (GOTCHA-SW1).
- **Pure deterministic helpers:** `classify_failure`, `rework_targets_for`,
  `rework_targets_from_card_decisions`, `_step_id_for_artifact`, `_compute_overall_readiness`,
  `_classification_is_tier_1`, `_normalize_relationship`, `_legacy_disposition_from_relationship`,
  `_is_retire_or_replace_disposition`, all artifact-path builders, `_with_fixture_scenario`,
  `_build_rationalization_step_entry` — no `await`, no `workflow.now()`, no random, no I/O. Safe to
  call anywhere in workflow code. (`_with_context_priors` is the ONLY async one — it awaits an
  activity.)
- **Constructor stability across patch versions:** all 31 line-state vars are initialized in
  `__init__` unconditionally so queries never `AttributeError`, even on pre-patch replays
  (GOTCHA-S-PATCH-GUARDED-STATE).
- **No continue-as-new, no heartbeats, no compensation in scope** — those (if any) live in `run()`/
  `_execute` (sibling files). The failure-classification + `persist_wave_failure` routing is in the
  sibling `run()` body; this file only provides the `classify_failure` decision function it calls.

---

## 21. Behavioral parity checklist (THIS FILE'S SCOPE — lines 1-1238)

A rebuilt module + `__init__` MUST satisfy ALL of the following:

1. **Inheritance:** `@workflow.defn class WaveRationalizationWorkflow(HILSignalsMixin)` — inherits
   ONLY `HILSignalsMixin`, NOT `LineWorkflowBase`. `__init__` calls `super().__init__()` as its
   FIRST statement (GOTCHA-INIT0), then sets the 31 line-state vars below.
2. **Imports:** `HILSignalsMixin` + `workflow` imported at top level; ALL activities, exception
   types, `RETRY_POLICIES`, types, and `parse_agent_json` imported inside
   `with workflow.unsafe.imports_passed_through():` (GOTCHA-IMP2). `_ = update_application_status`
   keep-alive at module end (GOTCHA-IMP3).
3. **`_now_iso()`** = `workflow.now().isoformat()`, module-level (GOTCHA-NOW). Never `datetime.now()`.
4. **`_normalize_relationship`**: `not relationship → ""`; else `.strip().lower()` (GOTCHA-NR1/NR2).
5. **`_legacy_disposition_from_relationship`**: funnels through `_normalize_relationship`; empty→`""`;
   else `rel[:1].upper() + rel[1:]` (first-char-only cap, GOTCHA-LD1).
6. **`_PORTFOLIO_SCORER_DIMENSIONS`** = the exact 6-tuple in order (GOTCHA-PD1).
7. **`_classification_is_tier_1`**: empty→F; parse-fail→F; non-dict→F; `tier_1_flag is True`→T
   (identity, not truthy, GOTCHA-CT2); `risk_tier` None→F else `int(risk)==1` in try (cast-fail→F).
   Defaults False on every failure (GOTCHA-CT1). All 6 branches present.
8. **`_compute_overall_readiness`**: empty/parse-fail/non-dict/`scores`-not-dict → `(None, [])`;
   loop the 6-tuple; non-dict entry skipped (not present); `score is None` → present-only;
   unparseable → skipped (not present); clamp scored value to `[0,100]`; `count==0` →
   `(None, sorted(present))`; else `(round(total/count, 2), sorted(present))`. All 9 branches +
   loop + clamp present (GOTCHA-OR1/OR2/OR3). Pure function.
9. **`RECOVERABLE_FAILURE_ACTIVITIES`** = exactly `{create_target_app_and_repo, update_wave_status,
   update_application_line_projection}`; **`TERMINAL_FAILURE_ACTIVITIES`** = exactly the 10-name set
   in §6.2. Both `frozenset`. (GOTCHA-CF1)
10. **`classify_failure`**: cycle-guarded `while` over `__cause__`-then-`__context__` (GOTCHA-CF4);
    inner probe of `("activity_type","activity_name","_activity_type")` taking first non-empty str
    (GOTCHA-CF3); `id()`-based `seen` cycle guard (GOTCHA-CF2); priority scan checks recoverable
    before terminal per name (GOTCHA-CF5); default `"terminal"`.
11. **`SKILLS`** dict: all 13 entries verbatim incl. `analyze-portfolio-redundancy.companion_artifact
    = "shared-identity-report.json"` and the two `redundancy-analyzer` reuses (GOTCHA-SK1).
12. **`RATIONALIZATION_STEPS`** dict: all 14 entries verbatim with exact `depends_on` DAG, `kind:
    "agent"`, and `dispatch_pending: True` on `capability-consolidation-advisory` +
    `portfolio-manifest-generation`; insertion order preserved (== dispatch order, GOTCHA-RS4);
    `cross-app-business-rule-analysis` is NOT in this dict (GOTCHA-RS2).
13. **`rework_targets_for`**: unknown step → `[]`; fixpoint `while progressed` closure over
    `depends_on` (`spec.get("depends_on") or []`); BRANCH `any(d in affected for d in deps)`; return
    insertion-order-filtered list. Must loop to fixpoint, not single-pass (GOTCHA-RT1).
14. **`_step_id_for_artifact`**: first exact `artifact` equality match → step_id; else `None`
    (GOTCHA-SA1).
15. **`rework_targets_from_card_decisions`**: `card_decisions or []` loop; skip non-dict; only
    `decision == "reject"`; resolve artifact→step_id then fallback to `card_id in
    RATIONALIZATION_STEPS`; skip unresolved; union via `rework_targets_for`; insertion-order return
    (GOTCHA-CD1). All 5 branches present.
16. **`STEP_WEIGHTS`**: all 21 entries verbatim summing to 100.0; module-level `assert abs(sum-100)<
    0.01` present (GOTCHA-SW1).
17. **`MAX_REWORK_ITERATIONS = 3`** module-level (GOTCHA-MR-CEIL); both gate loops compare `>` it.
18. **`_is_retire_or_replace_disposition`**: falsy→F; else `in ("Retire","Replace")` exact Title-case
    (GOTCHA-RR1).
19. **Artifact-path builders** emit EXACTLY: `discovery/{app_id}/business-logic.json`;
    `discovery/{app_id}/{name}.json` over `_DISCOVERY_PASSES=(catalog, structural-analysis,
    business-logic, quality-risk, ux-accessibility, tco-baseline, synthesis)`; UX overlap →
    `discovery/{app_id}/ux-accessibility.json` + `discovery/{app_id}/catalog.json` (NOT
    catalog-application.json — GOTCHA-AP1); `_wave_context_artifacts` → the 5 paths under
    `rationalization/wave-{wave_id}` with the last per-app-nested; `_wave_context_optional_artifacts`
    → `[…/shared-identity-report.json]` (must be wired as `optional_input_artifacts`, GOTCHA-AP4);
    `_portfolio_integration_input_artifacts` → per-app catalog + structural-analysis;
    `_portfolio_redundancy_input_artifacts` → wave matrix + integration-graph + per-app
    intra-app-redundancy + per-app business-logic; `_disposition_input_artifacts` = discovery passes
    THEN wave context (order, GOTCHA-AP5).
20. **`_with_context_priors`** (async): `load_context_priors` 10s/`transient`; exception→log+return
    original context; empty priors→return original; else shallow-copy + `["context_priors"]=priors`
    (GOTCHA-CP1/CP2).
21. **`_with_fixture_scenario`** (sync): `fixture_scenarios.get(skill_id) if fixture_scenarios else
    None`; falsy→return original; else shallow-copy + `["fixture_scenario"]=scenario` (GOTCHA-FS1).
22. **`_build_rationalization_step_entry`**: `output = output_artifacts[0]` if any else `""`; loop
    output_files handling BOTH dict (`.get`) and dataclass (`getattr`) shapes with defaults
    `("","","utf-8")` (GOTCHA-BS1); skip empty-path files; inline FULL `content` into file_artifacts
    (NOT slim, GOTCHA-BS2); return dict with `title/skill_id/artifact/output/file_artifacts/metadata`
    where metadata has exactly the 5 result fields and NO `output_files` (GOTCHA-BS3).
23. **`__init__` STATE**: all 31 vars initialized to the exact initial values + types in §19, in
    addition to the 8 inherited HIL vars. The gate queues are **per-gate dicts**
    (`_gate_decisions: dict[str, list]`, `_gate_decisions_consumed: dict[str, int]`), NOT base's flat
    list+int (GOTCHA-S-GATEQ). Gate entries are 5-tuples (GOTCHA-S-5TUPLE). The three early-signal
    vars (`_gate_id_to_key`, `_pending_signals_by_gate_id`) are present (GOTCHA-S-EARLY/S-GATEID-UUID).
    Tier-1 dual tracking (`_tier1_approval_records` dict + `_tier1_approved_apps` set) both present
    (GOTCHA-S-TIER1-DUAL). Two scalar rework counters `_rework_iterations_grr`/`_rework_iterations_gda`
    (NOT a dict). `_approval_feedback` separate from `_rework_feedback` (GOTCHA-S-APPROVAL-GUIDANCE).
    Own `_merge_retry_signalled` (GOTCHA-S-MERGE-RETRY-INLINE). All 7 dispatch-bookkeeping vars
    initialized unconditionally to empty defaults (GOTCHA-S-PATCH-GUARDED-STATE). NONE of the
    base-only vars from §19.2 are added.
24. **Module-level docstring contract:** the class-level signal note (`:25-28`) — `gate_approved` /
    `gate_rejected` carry `gate_id` (a UUID) routed via `_gate_id_to_key`; `stakeholder_approved`
    takes `scope` (`"tier-1-classification"` for tier-1 pauses, `"g-da"` for the G-DA dual-signal).
    (Handlers are sibling-spec'd; this file's STATE supports them.)
