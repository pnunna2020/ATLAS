# `PortfolioWorkflow` — Top-of-hierarchy portfolio orchestrator (ATOMIC regeneration spec)

> **Source of truth:** `temporal/olympus_workflows/workflows/portfolio.py` (80 lines total).
> Every `portfolio.py:line` citation below is against that file.
>
> **Inherits:** `class PortfolioWorkflow(HILSignalsMixin)` (`portfolio.py:24`). See
> `_HILSignalsMixin.md` for the inherited HIL signal surface. **NOTE:** unlike the seven
> per-app *line* workflows, `PortfolioWorkflow` does **NOT** inherit `LineWorkflowBase` —
> it extends `HILSignalsMixin` **directly**. Do not pull in `LineWorkflowBase` helpers
> (`_dispatch_agent`, `_wait_for_gate_decision`, `gate_approved`/`gate_rejected` base
> handlers, `get_status` base query, etc.). Those are **not** present on this class; this
> class re-declares its own `gate_approved`/`gate_rejected`/`get_status` (see §0 GOTCHA-P0).

---

## ⚠️ TOP-LEVEL GOTCHA-P0 — THIS IS A STUB INTERFACE, NOT AN IMPLEMENTATION

**This is the single most important fact in this spec.** `PortfolioWorkflow` as it exists in
the codebase is a **pure interface stub**. There is **no orchestration state machine**, **no
instance state beyond what the mixin sets**, **no wave fan-out**, **no child-workflow spawn**,
**no activity calls**, **no gate routing**, **no rework loop**. Every executable member raises
`NotImplementedError`:

| Member | Decorator | Body | Line |
|--------|-----------|------|------|
| `run(self, input)` | `@workflow.run` | `raise NotImplementedError("PortfolioWorkflow.run is a stub interface")` | `portfolio.py:42-43` |
| `gate_approved(self, signal)` | `@workflow.signal` | `raise NotImplementedError` | `portfolio.py:47-49` |
| `gate_rejected(self, signal)` | `@workflow.signal` | `raise NotImplementedError` | `portfolio.py:51-53` |
| `override_approved(self, signal)` | `@workflow.signal` | `raise NotImplementedError` | `portfolio.py:55-57` |
| `escalation_resolved(self, signal)` | `@workflow.signal` | `raise NotImplementedError` | `portfolio.py:59-61` |
| `stakeholder_approved(self, signal)` | `@workflow.signal` | `raise NotImplementedError` | `portfolio.py:63-65` |
| `wave_patterns_ready(self, signal)` | `@workflow.signal` | `raise NotImplementedError` | `portfolio.py:67-69` |
| `get_status(self)` | `@workflow.query` | `raise NotImplementedError` | `portfolio.py:73-75` |
| `get_app_status(self, app_id)` | `@workflow.query` | `raise NotImplementedError` | `portfolio.py:77-79` |

- The **only** member with a real body is `__init__`, which calls `super().__init__()`
  (`portfolio.py:38-39`) — initializing the 8 HIL state vars from `HILSignalsMixin`.
- The class docstring (`portfolio.py:25-36`) describes an **aspirational** design ("Spawns
  WaveWorkflow children (max 4 concurrent waves)", "Wave planning and sequencing", "Aggregating
  cross-wave status"). **NONE of that is implemented.** The docstring is a forward-looking
  contract, not a description of code that runs. A regeneration MUST reproduce the *stub*, not
  invent the orchestration the docstring promises. (If you build the orchestration, you have
  produced a *different* artifact than the one that exists — see "What parity means here" below.)

> **Why a stub is registered as a live workflow:** `PortfolioWorkflow` IS in `ALL_WORKFLOWS`
> (`worker.py:136`) and is imported by the worker (`worker.py:123`) and the package
> `__init__` (`workflows/__init__.py:11,26`). So Temporal **will** register it. Its
> **type contract** (class name `"PortfolioWorkflow"`, the wire signal names, the query
> names, payload dataclass types, `run` arg/return types) is therefore load-bearing for the
> worker to start and for clients to address it — even though invoking `run()` would
> immediately fail with `NotImplementedError`. In this codebase, portfolio-level
> orchestration is actually carried by `WaveRationalizationWorkflow` /
> `WaveArchitectureWorkflow` / `WaveWorkflow` (spec'd separately); `PortfolioWorkflow` is a
> reserved/placeholder top-of-tree interface.

> **What "behavioral parity" means for a stub:** parity here = **reproduce the exact interface
> surface and the exact failure semantics**, NOT an orchestration. Concretely: same class name,
> same base class, same decorators, same wire signal/query names, same payload types, same
> `run` signature returning `str`, same `__init__` cooperative `super().__init__()`, and every
> executable member raising `NotImplementedError` (with `run`'s exact message string). A rebuild
> that "completes" the orchestration is NOT parity with this artifact — it is a fork. If the
> regeneration intends a working portfolio orchestrator, that is a NEW design and must be spec'd
> as such; this file specs the stub that exists.

---

## 0. Class shape & inheritance contract

```text
@workflow.defn                                   # portfolio.py:23
class PortfolioWorkflow(HILSignalsMixin):         # portfolio.py:24
    def __init__(self) -> None:                   # portfolio.py:38-39
        super().__init__()                        # portfolio.py:39  ← initializes 8 HIL vars

    @workflow.run
    async def run(self, input: PortfolioWorkflowInput) -> str: ...   # portfolio.py:41-43  (stub)

    # 6 signals (portfolio.py:47-69) — ALL stubs
    @workflow.signal async def gate_approved(self, signal: GateApprovedSignal) -> None: ...
    @workflow.signal async def gate_rejected(self, signal: GateRejectedSignal) -> None: ...
    @workflow.signal async def override_approved(self, signal: OverrideApprovedSignal) -> None: ...
    @workflow.signal async def escalation_resolved(self, signal: EscalationResolvedSignal) -> None: ...
    @workflow.signal async def stakeholder_approved(self, signal: StakeholderApprovedSignal) -> None: ...
    @workflow.signal async def wave_patterns_ready(self, signal: WavePatternsReadySignal) -> None: ...

    # 2 queries (portfolio.py:73-79) — ALL stubs
    @workflow.query def get_status(self) -> PortfolioStatusResponse: ...
    @workflow.query def get_app_status(self, app_id: str) -> AppStatusResponse: ...
```

- `@workflow.defn` at `portfolio.py:23` — registers the class as a Temporal workflow definition
  under the **default name `"PortfolioWorkflow"`** (the class name; no `name=` override). A
  rebuild MUST keep the class named exactly `PortfolioWorkflow` or the worker registration and
  every `start_workflow("PortfolioWorkflow", ...)` client call breaks.
- **Inheritance:** `HILSignalsMixin` **only** (`portfolio.py:24`). Transitively this gives the
  workflow the six inherited HIL signals + helpers from `_HILSignalsMixin.md`:
  `approve_plan`, `provide_plan_feedback`, `approve_research`, `provide_feedback`, `approve`,
  `cancel_workflow` (all `@workflow.signal`), plus the non-signal helpers `reset_plan_feedback`,
  `reset_document_feedback`, `is_plan_decision_received`, `is_document_decision_received`. These
  are **inherited, not redefined** — they exist on the class even though `run()` never consumes
  them (because `run()` is a stub).
- **Import surface** (`portfolio.py:7-20`):
  - `from foundry_temporal.signals import HILSignalsMixin` (`portfolio.py:7`)
  - `from temporalio import workflow` (`portfolio.py:8`)
  - From `olympus_workflows.types` (`portfolio.py:10-20`): `AppStatusResponse`,
    `EscalationResolvedSignal`, `GateApprovedSignal`, `GateRejectedSignal`,
    `OverrideApprovedSignal`, `PortfolioStatusResponse`, `PortfolioWorkflowInput`,
    `StakeholderApprovedSignal`, `WavePatternsReadySignal`.
  - ⚠️ **GOTCHA-P1 (no `workflow.unsafe.imports_passed_through()` block):** unlike
    `LineWorkflowBase` (which gates activity imports through `imports_passed_through()`), this
    stub imports everything at module top level (`portfolio.py:7-20`). That is **safe here**
    because it imports **no activity functions and no `RETRY_POLICIES`** — only the mixin, the
    `workflow` module, and pure dataclass types. A rebuild of the *stub* keeps top-level imports.
    (If the rebuild ever adds real activity dispatch it MUST move activity imports into
    `with workflow.unsafe.imports_passed_through():` per the base's GOTCHA-IMPORTS.)
- ⚠️ **GOTCHA-P2 (cooperative `super().__init__()`):** `__init__` (`portfolio.py:38-39`) does
  nothing but `super().__init__()`. Per `_HILSignalsMixin.md` GOTCHA-0, that call MUST be the
  first (here: only) statement so the MRO chain (`HILSignalsMixin` → `object`) runs and the 8
  HIL attrs initialize. A rebuild MUST keep this `__init__` (even though it adds no own state) —
  removing it would still inherit `HILSignalsMixin.__init__`, but the explicit override is what
  the source declares; keep it for parity and to leave a clear extension point.

---

## 1. STATE — every instance var

**This class declares NO instance state of its own.** The only state present is what
`HILSignalsMixin.__init__` sets via the `super().__init__()` call at `portfolio.py:39`. Those
eight vars (see `_HILSignalsMixin.md` §1) are:

| Var | Type | Initial | Set by | Notes |
|-----|------|---------|--------|-------|
| `approved` | `bool` | `False` | `HILSignalsMixin.__init__` (via `super().__init__()`, `portfolio.py:39`) | mutated only by inherited `approve()` signal |
| `plan_approved` | `bool` | `False` | same | inherited `approve_plan` / `provide_plan_feedback` |
| `plan_feedback_received` | `bool` | `False` | same | inherited |
| `plan_feedback_comments` | `str` | `""` | same | inherited |
| `document_approved` | `bool` | `False` | same | inherited |
| `document_feedback_received` | `bool` | `False` | same | inherited |
| `document_feedback_comments` | `str` | `""` | same | inherited |
| `cancelled` | `bool` | `False` | same | inherited `cancel_workflow()` one-way latch |

> ⚠️ **GOTCHA-P3 (no `_portfolio_id`, no `_status`, no `_gate_decisions`, no wave bookkeeping):**
> Because this class does NOT inherit `LineWorkflowBase`, it has **none** of the line-state vars
> (`_portfolio_id`, `_status`, `_current_step`, `_gate_decisions`, `_gate_decisions_consumed`,
> `_rework_feedback`, `_rework_iterations`, `_pending_gate`, etc.). The
> `PortfolioStatusResponse` fields (`total_apps`, `apps_completed`, `active_wave_id`,
> `waves_completed`, `waves_total`, …) that `get_status` *would* return have **no backing
> instance vars** — consistent with `get_status` being a stub that raises. A rebuild of the stub
> MUST NOT add these vars; they belong to a future implementation. The inherited HIL vars are the
> complete state inventory.

> ⚠️ **GOTCHA-P4 (inherited HIL signals mutate state that nothing reads):** the six inherited
> HIL signals (`approve`, `cancel_workflow`, `approve_plan`, …) will, if fired, mutate the 8 HIL
> vars exactly as `_HILSignalsMixin.md` describes — but **`run()` is a stub and never reads
> them**, so those mutations have no observable effect on workflow progression. A rebuild
> reproduces the inherited signals (they exist via inheritance) but must not wire them into any
> control flow in the stub.

---

## 2. SIGNALS / QUERIES — each handler atomically

There are **8 declared handlers on this class** (6 signals + 2 queries), PLUS the 6 inherited
HIL signals. The 8 declared-here handlers are the focus of this spec. **Every one is a stub
that `raise NotImplementedError`.** The load-bearing facts are: the **decorator**, the **wire
name** (Temporal uses the method name as the signal/query name — no `name=` override anywhere),
the **payload/arg type**, the **async-ness**, and the **return type annotation**.

### 2.1 `gate_approved(self, signal: GateApprovedSignal) -> None` — `portfolio.py:47-49`
```text
@workflow.signal                       # portfolio.py:47
async def gate_approved(self, signal): # portfolio.py:48
    raise NotImplementedError          # portfolio.py:49
```
- Wire signal name: **`gate_approved`**. Payload type: `GateApprovedSignal` (fields
  `gate_id`, `approved_by`, `justification=""`, `card_decisions=[]`, `reviewer_notes=None` —
  from `olympus-contracts`, re-exported via types.py). `async def`. Buffers/mutates **nothing**
  (raises before any statement).
- ⚠️ **GOTCHA-P5 (NOT the `LineWorkflowBase.gate_approved`):** `LineWorkflowBase` defines an
  `async gate_approved` that appends a 5-tuple to `_gate_decisions` (`_LineWorkflowBase.md` §3.1).
  This class is **not** a `LineWorkflowBase` subclass, so it **re-declares** its own
  `gate_approved` stub here. There is no `_gate_decisions` to append to (GOTCHA-P3). A rebuild of
  the stub re-declares it as a `NotImplementedError` stub — it must NOT delegate to a base 5-tuple
  buffer (there is no base to delegate to), and it does NOT clash with `LineWorkflowBase` because
  there is no inheritance relationship.

### 2.2 `gate_rejected(self, signal: GateRejectedSignal) -> None` — `portfolio.py:51-53`
```text
@workflow.signal                        # portfolio.py:51
async def gate_rejected(self, signal):  # portfolio.py:52
    raise NotImplementedError           # portfolio.py:53
```
- Wire name **`gate_rejected`**. Payload `GateRejectedSignal` (`gate_id`, `rejected_by`,
  `reason`, `reason_category=None`, `card_decisions=[]`, `reviewer_notes=None`). `async def`,
  stub.

### 2.3 `override_approved(self, signal: OverrideApprovedSignal) -> None` — `portfolio.py:55-57`
```text
@workflow.signal                            # portfolio.py:55
async def override_approved(self, signal):  # portfolio.py:56
    raise NotImplementedError               # portfolio.py:57
```
- Wire name **`override_approved`**. Payload `OverrideApprovedSignal` (`gate_id: str`,
  `override_by: str`, `justification: str`, `override_type: OverrideType`) — defined in
  `types.py:144-151`. `OverrideType` ∈ {`CRITICAL_PATCH="critical_patch"`,
  `EXECUTIVE_OVERRIDE="executive_override"`, `TIME_SENSITIVE="time_sensitive"`} (`types.py:108-113`).
  `async def`, stub.
- ⚠️ **GOTCHA-P6 (override_approved is NOT in the base/HIL set):** `override_approved` is a
  portfolio-specific signal — it is NOT one of the four `LineWorkflowBase` gate signals and NOT
  one of the six `HILSignalsMixin` signals. It exists ONLY here. A rebuild must register it under
  exactly `override_approved`.

### 2.4 `escalation_resolved(self, signal: EscalationResolvedSignal) -> None` — `portfolio.py:59-61`
```text
@workflow.signal                              # portfolio.py:59
async def escalation_resolved(self, signal):  # portfolio.py:60
    raise NotImplementedError                 # portfolio.py:61
```
- Wire name **`escalation_resolved`**. Payload `EscalationResolvedSignal` (`escalation_id: str`,
  `resolved_by: str`, `resolution_type: ResolutionType`, `resolution: str`) — `types.py:154-161`.
  `ResolutionType` ∈ {`RE_EXTRACT="Re-Extract"`, `MANUAL_AUGMENT="Manual Augment"`,
  `RE_DISPOSITION="Re-Disposition"`, `ABANDON="Abandon"`} (`types.py:102-105`). `async def`, stub.
- ⚠️ **GOTCHA-P7 (same wire name as the base, but different class):** `LineWorkflowBase` also
  defines `escalation_resolved` (a no-op-except-timestamp handler, `_LineWorkflowBase.md` §3.3).
  These are independent declarations on independent (non-related) classes — there is no override
  relationship and no duplicate-registration conflict (different workflow types). The stub here
  takes the SAME payload type (`EscalationResolvedSignal`) but raises. A rebuild keeps it as a
  stub under `escalation_resolved`.

### 2.5 `stakeholder_approved(self, signal: StakeholderApprovedSignal) -> None` — `portfolio.py:63-65`
```text
@workflow.signal                               # portfolio.py:63
async def stakeholder_approved(self, signal):  # portfolio.py:64
    raise NotImplementedError                  # portfolio.py:65
```
- Wire name **`stakeholder_approved`**. Payload `StakeholderApprovedSignal` (`approval_id: str`,
  `stakeholder: str`, `scope: str`) — `types.py:164-169`. `async def`, stub.

### 2.6 `wave_patterns_ready(self, signal: WavePatternsReadySignal) -> None` — `portfolio.py:67-69`
```text
@workflow.signal                              # portfolio.py:67
async def wave_patterns_ready(self, signal):  # portfolio.py:68
    raise NotImplementedError                 # portfolio.py:69
```
- Wire name **`wave_patterns_ready`**. Payload `WavePatternsReadySignal` (`wave_id: str`,
  `patterns: list[str] = field(default_factory=list)`) — `types.py:182-187`. `async def`, stub.
- ⚠️ **GOTCHA-P8 (`patterns` default is a mutable field-factory):** the payload's `patterns`
  uses `field(default_factory=list)` (`types.py:187`), so a sender may omit it and get `[]`. The
  stub never reads it. A rebuild of the *payload type* must use `default_factory=list`, not a
  bare `= []` default (the latter is a shared-mutable-default bug). (This pertains to the
  dataclass in types.py, not to portfolio.py logic, which raises.)

### 2.7 `get_status(self) -> PortfolioStatusResponse` — `portfolio.py:73-75`
```text
@workflow.query                                 # portfolio.py:73
def get_status(self) -> PortfolioStatusResponse:  # portfolio.py:74
    raise NotImplementedError                   # portfolio.py:75
```
- Wire query name **`get_status`**. **Synchronous** (`def`, not `async def` — queries are
  synchronous). Return type `PortfolioStatusResponse` (`types.py:423-435`): fields
  `portfolio_id: str`, `status: WorkflowStatus`, `total_apps=0`, `apps_completed=0`,
  `active_wave_id=""`, `waves_completed=0`, `waves_total=0`, `started_at=""`, `updated_at=""`.
  Stub — raises.
- ⚠️ **GOTCHA-P9 (`get_status` re-declared, NOT inherited from base):** `LineWorkflowBase`
  defines a working `get_status` returning `WorkflowStatusResponse` (`_LineWorkflowBase.md` §16).
  This class returns a **different** type — `PortfolioStatusResponse` (portfolio-aggregate shape,
  not single-workflow shape). Because this class doesn't inherit the base, it declares its own
  `get_status`. A rebuild MUST return the **`PortfolioStatusResponse`** type from this query, not
  `WorkflowStatusResponse`. (Stub still raises; the annotation is the contract.)
- ⚠️ **GOTCHA-P10 (queries are `def`, never `async def`):** both query handlers here are
  synchronous `def`. Temporal queries MUST be synchronous and side-effect-free (must not mutate
  state, must not `await`). A rebuild MUST declare them `def` (the stub already is). When the stub
  is ever implemented, the body MUST remain read-only.

### 2.8 `get_app_status(self, app_id: str) -> AppStatusResponse` — `portfolio.py:77-79`
```text
@workflow.query                                       # portfolio.py:77
def get_app_status(self, app_id: str) -> AppStatusResponse:  # portfolio.py:78
    raise NotImplementedError                         # portfolio.py:79
```
- Wire query name **`get_app_status`**. Synchronous. **Takes a positional arg `app_id: str`** —
  i.e. a *parameterized* query (the client passes the app id). Return type `AppStatusResponse`
  (`types.py:407-420`): `app_id`, `app_name`, `disposition: Disposition|None`,
  `risk_tier: RiskTier|None`, `complexity_tier: ComplexityTier|None`,
  `current_line: AssemblyLine|None`, `current_step=""`, `status: WorkflowStatus=PENDING`,
  `pending_gate: GateType|None`, `workflow_id=""`. Stub — raises.
- ⚠️ **GOTCHA-P11 (parameterized query):** `get_app_status` is the only handler on this class
  taking a caller-supplied argument (`app_id`). Temporal supports query args; the client sends
  `query("get_app_status", app_id)`. A rebuild MUST preserve the `app_id: str` parameter and the
  `AppStatusResponse` return type.

### Inherited HIL signals (present via inheritance, not declared here)
Per `_HILSignalsMixin.md`, the following six `@workflow.signal` handlers exist on every instance
of `PortfolioWorkflow` by inheritance and are registered under their wire names:
`approve_plan`, `provide_plan_feedback`, `approve_research`, `provide_feedback`, `approve`,
`cancel_workflow`. They are **synchronous** (`def`), perform attribute writes, and are NOT
stubs — they mutate the 8 HIL vars. A rebuild gets these for free by extending a parity-correct
`HILSignalsMixin`. **Do NOT re-declare them on `PortfolioWorkflow`** (would be a different
registration than the source, which inherits them).

> ⚠️ **GOTCHA-P12 (total registered signal/query surface):** a worker registering this class
> exposes **12 signals** (6 declared-here stubs + 6 inherited HIL) and **2 queries** (both
> declared-here stubs). A parity rebuild MUST expose exactly this surface — no more, no fewer.
> The 8 "own" handlers the prompt counts are the 6 signals + 2 queries declared in portfolio.py
> (`portfolio.py:47-79`); the additional 6 come from the mixin.

---

## 3. CONTROL FLOW — `run()` pseudocode

```text
@workflow.run
async def run(self, input: PortfolioWorkflowInput) -> str:   # portfolio.py:41-42
    raise NotImplementedError("PortfolioWorkflow.run is a stub interface")   # portfolio.py:43
```

- **Branch-points in `run()`: ZERO.** No `if`/`elif`/`else`, no `for`/`while`, no `try/except`,
  no `match/case`, no early `return`. The body is a single unconditional `raise`.
- **Arg type:** `PortfolioWorkflowInput` (`types.py:1070-1079`): `portfolio_id: str`,
  `portfolio_name: str`, `artifact_repo: str = ""`, `profile_id: str = ""`,
  `max_concurrent_waves: int = MAX_CONCURRENT_WAVES` (=4, `types.py:131`),
  `max_apps_per_wave: int = MAX_APPS_PER_WAVE` (=10, `types.py:132`).
- **Return type:** `str`. (Never actually returns — raises first.)
- ⚠️ **GOTCHA-P13 (the exact message string is part of parity):** the `NotImplementedError`
  message is the literal `"PortfolioWorkflow.run is a stub interface"` (`portfolio.py:43`). A
  rebuild MUST reproduce this exact string. (Tests / operators distinguish a deliberate stub from
  an accidental missing impl by this message.)
- ⚠️ **GOTCHA-P14 (`run` is `async def` and decorated `@workflow.run`):** even though it only
  raises, it MUST be `async def` and carry `@workflow.run` (`portfolio.py:41-42`) so Temporal
  treats it as the entry point. There must be **exactly one** `@workflow.run` method. A rebuild
  keeps `async def run(self, input: PortfolioWorkflowInput) -> str`.

**No `_execute()` / helper methods exist.** The class has no private orchestration helpers,
no `_set_step`, no wave-spawn loop, no continue-as-new, nothing. The aspirational
"Responsibilities" bullets (`portfolio.py:31-35`) correspond to **no code**.

---

## 4. ACTIVITY & CHILD-WORKFLOW CALLS

**NONE.** The stub makes:
- **zero `workflow.execute_activity(...)` calls** (no activity functions are even imported —
  GOTCHA-P1).
- **zero `workflow.execute_child_workflow(...)` / `workflow.start_child_workflow(...)` calls**
  (no `WaveWorkflow` spawn despite the docstring's "Spawns WaveWorkflow children" claim at
  `portfolio.py:28`).
- **zero `workflow.signal_external_workflow(...)` calls.**
- **zero `asyncio.gather` / fan-out.**

A parity rebuild of the stub introduces **no** retry policies, timeouts, `non_retryable_errors`,
or concurrency primitives — there are no activity/child calls to attach them to. (Contrast:
`MAX_CONCURRENT_WAVES=4` and `MAX_APPS_PER_WAVE=10` exist as module constants in `types.py:131-132`
and are referenced as `PortfolioWorkflowInput` defaults, but the stub never enforces or uses
them.)

---

## 5. GATE HANDLING

**NONE implemented.** Although the class declares `gate_approved` / `gate_rejected` /
`override_approved` / `escalation_resolved` / `stakeholder_approved` signal *names*, there is:
- **no evidence assembly** (`_submit_gate_evidence` / `_build_evidence_data` do not exist here),
- **no gate wait** (`_wait_for_gate_decision` does not exist here; no `wait_condition` anywhere),
- **no approve/reject/merge-blocked/rework routing**,
- **no rework loop, no rework counters** (`_rework_iterations` / `_bump_rework` do not exist here).

The gate-signal handlers raise `NotImplementedError` (§2.1-2.5), so no buffering and no
consumption occur. A parity rebuild reproduces the gate-signal *handlers as stubs* and adds
**no** gate routing machinery.

---

## 6. RESILIENCE

- **Timeouts / heartbeats:** none (no activities, no timers).
- **continue-as-new:** none (`run()` raises immediately; no long-running loop to checkpoint).
- **Idempotency:** N/A — no activity ids, no side effects. `run()` is deterministically a single
  `raise` on every replay (a `raise NotImplementedError` is deterministic; it produces a
  WorkflowTaskFailed / application failure consistently).
- **Compensation / rollback:** none.
- **Cancellation:** the inherited `cancel_workflow` signal still sets `self.cancelled=True`
  (GOTCHA-P4), but since `run()` raises before reading it, cancellation has no orchestration
  effect on this stub. (No `wait_condition` exists to consult `self.cancelled`.)
- **Determinism note:** no `workflow.now()`, no `random`, no I/O, no `workflow.patched(...)` —
  trivially deterministic. The only "side effect" of executing the entry point is the
  `NotImplementedError`.

---

## 7. Override matrix — what this class declares vs inherits

| Member | Source on this class | Relationship to `LineWorkflowBase` / `HILSignalsMixin` |
|--------|----------------------|--------------------------------------------------------|
| `__init__` | declared (`portfolio.py:38-39`), calls `super().__init__()` | overrides `HILSignalsMixin.__init__` cooperatively (adds nothing) |
| `run` | declared stub (`portfolio.py:41-43`) | neither base has a `run` (GOTCHA: base has none) |
| `gate_approved` / `gate_rejected` | declared stubs (`portfolio.py:47-53`) | **independent** of `LineWorkflowBase`'s same-named handlers (not a subclass; no override, no clash) — GOTCHA-P5 |
| `override_approved` | declared stub (`portfolio.py:55-57`) | portfolio-only; not on either base — GOTCHA-P6 |
| `escalation_resolved` | declared stub (`portfolio.py:59-61`) | same wire name as base's, but independent class — GOTCHA-P7 |
| `stakeholder_approved` | declared stub (`portfolio.py:63-65`) | portfolio-only |
| `wave_patterns_ready` | declared stub (`portfolio.py:67-69`) | portfolio-only |
| `get_status` | declared stub returning `PortfolioStatusResponse` (`portfolio.py:73-75`) | base returns `WorkflowStatusResponse`; different type — GOTCHA-P9 |
| `get_app_status` | declared stub, parameterized (`portfolio.py:77-79`) | portfolio-only parameterized query — GOTCHA-P11 |
| `approve_plan`, `provide_plan_feedback`, `approve_research`, `provide_feedback`, `approve`, `cancel_workflow` | **inherited** from `HILSignalsMixin` (not declared) | inherited, NOT redefined — GOTCHA-P12 |

---

## 8. Behavioral parity checklist

A rebuilt `PortfolioWorkflow` (matching the artifact that exists — the stub) MUST satisfy ALL:

1. **It is a stub.** Every executable member raises `NotImplementedError`. There is NO
   orchestration, NO wave fan-out, NO child-workflow spawn, NO activity call, NO gate routing,
   NO rework loop, NO instance state beyond the inherited HIL vars. (GOTCHA-P0)
2. `@workflow.defn` on `class PortfolioWorkflow(HILSignalsMixin)` — registered under the default
   name `"PortfolioWorkflow"`; extends `HILSignalsMixin` **directly** (NOT `LineWorkflowBase`).
   (`portfolio.py:23-24`)
3. `__init__(self) -> None` does exactly `super().__init__()` and nothing else — initializing the
   8 inherited HIL vars (`approved`, `plan_approved`, `plan_feedback_received`,
   `plan_feedback_comments`, `document_approved`, `document_feedback_received`,
   `document_feedback_comments`, `cancelled`) to their `_HILSignalsMixin.md` initials.
   (`portfolio.py:38-39`, GOTCHA-P2/P3)
4. `run` is `async def run(self, input: PortfolioWorkflowInput) -> str`, decorated
   `@workflow.run`, with body `raise NotImplementedError("PortfolioWorkflow.run is a stub
   interface")` — the exact message string. Exactly one `@workflow.run`. ZERO branch-points.
   (`portfolio.py:41-43`, GOTCHA-P13/P14)
5. Exactly **six** `@workflow.signal` handlers declared on the class, all `async def`, all
   `raise NotImplementedError`, under the wire names: `gate_approved` (payload
   `GateApprovedSignal`), `gate_rejected` (`GateRejectedSignal`), `override_approved`
   (`OverrideApprovedSignal`), `escalation_resolved` (`EscalationResolvedSignal`),
   `stakeholder_approved` (`StakeholderApprovedSignal`), `wave_patterns_ready`
   (`WavePatternsReadySignal`). (`portfolio.py:47-69`)
6. Exactly **two** `@workflow.query` handlers declared on the class, both **synchronous** (`def`),
   both `raise NotImplementedError`: `get_status(self) -> PortfolioStatusResponse` and
   `get_app_status(self, app_id: str) -> AppStatusResponse`. `get_status` returns
   `PortfolioStatusResponse` (NOT `WorkflowStatusResponse`); `get_app_status` is parameterized by
   `app_id`. (`portfolio.py:73-79`, GOTCHA-P9/P10/P11)
7. The six inherited HIL signals (`approve_plan`, `provide_plan_feedback`, `approve_research`,
   `provide_feedback`, `approve`, `cancel_workflow`) are present **by inheritance** and are NOT
   re-declared on the class. Total registered surface = 12 signals + 2 queries. (GOTCHA-P12)
8. No `workflow.unsafe.imports_passed_through()` block, no activity imports, no `RETRY_POLICIES`
   import — top-level imports are limited to `HILSignalsMixin`, `temporalio.workflow`, and the
   nine pure types listed at `portfolio.py:10-20`. (GOTCHA-P1)
9. No `workflow.now()`, no `random`, no `workflow.patched(...)`, no `wait_condition`, no I/O —
   fully deterministic; the only behavior on running `run()` is the `NotImplementedError`.
10. The class is importable from `olympus_workflows.workflows` and present in the worker's
    `ALL_WORKFLOWS` registration list (`workflows/__init__.py:11,26`, `worker.py:123,136`).
11. The pinned test invariant holds: `PortfolioWorkflow` `hasattr` each of `gate_approved`,
    `gate_rejected`, `override_approved`, `escalation_resolved`, `stakeholder_approved`,
    `wave_patterns_ready`, `get_status`, `get_app_status` (`test_interfaces.py:293-304`), and the
    workflow set has 13 members (`test_interfaces.py:291`).
12. **Anti-parity guard:** a rebuild that implements wave planning / `WaveWorkflow` fan-out /
    cross-wave aggregation is NOT a faithful reproduction of this artifact — it is a new design.
    The docstring "Responsibilities" (`portfolio.py:31-35`) are aspirational and back NO code.
    (GOTCHA-P0)
```
