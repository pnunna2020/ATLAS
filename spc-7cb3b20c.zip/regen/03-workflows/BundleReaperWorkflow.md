# `BundleReaperWorkflow` — Delegated-Bundle Expiry Cron Sweep (ATOMIC regeneration spec)

> **Source of truth:** `temporal/olympus_workflows/workflows/bundle_reaper.py` (119 lines).
> Every `bundle_reaper.py:line` citation below is against that file.
>
> **What this is:** a **one-shot** Temporal cron workflow (Phase 5 W20, chunk D). Each execution
> runs **one** activity (`expire_due_bundles_activity`) that transitions all `delegated_bundle`
> rows in state `claimed AND expires_at < now()` to `expired`, then **fires a
> `BundleExpiredSignal`** (signal name `"bundle_expired"`) to each expired bundle's dispatching
> workflow so that workflow can apply its `fallback_policy`. It returns a tiny summary dict
> `{"expired": int, "signalled": int}` (`bundle_reaper.py:65,115-118`).
>
> **This workflow is STANDALONE.** `@workflow.defn class BundleReaperWorkflow:`
> (`bundle_reaper.py:46-47`) — it does **NOT** inherit `LineWorkflowBase` and does **NOT** inherit
> `HILSignalsMixin`. It therefore has **no** `get_status` query, **no** gate signals, **no** HIL
> signals, **no** instance state at all (no `__init__`), and **no** gate / rework / merge logic.
> The shared-base specs (`_LineWorkflowBase.md`, `_HILSignalsMixin.md`) **do not apply** to it.
> Treat any base-class behavior described there as **absent here**.
>
> **Scheduling is OUT-OF-BAND.** The class is registered with the worker
> (`worker.py:115,160`) but the 15-minute cadence is provisioned via the Temporal **Schedules
> API**, NOT a `@workflow.defn(... )` cron annotation in code and NOT `continue_as_new` self-cron.
> Each run is an independent, fresh execution — no inter-run state, no `continue_as_new`
> (`bundle_reaper.py:48-62`).

---

## 0. Module-level facts: imports, schedule, determinism

### 0.1 Imports (`bundle_reaper.py:29-43`)
```text
from __future__ import annotations
import logging
from datetime import timedelta
from temporalio import workflow

with workflow.unsafe.imports_passed_through():               # bundle_reaper.py:36
    from olympus_workflows.activities.bundle_activities import (
        expire_due_bundles_activity,                         # bundle_reaper.py:37-39
    )
    from olympus_workflows.retry_policies import RETRY_POLICIES   # bundle_reaper.py:40
    from olympus_workflows.types import BundleExpiredSignal       # bundle_reaper.py:41

logger = logging.getLogger(__name__)                         # bundle_reaper.py:43
```
- ⚠️ **GOTCHA-IMP1 (imports MUST be inside `workflow.unsafe.imports_passed_through()`):**
  `bundle_reaper.py:36`. The activity ref, `RETRY_POLICIES`, and `BundleExpiredSignal` are all
  imported inside the sandbox-bypass block so the Temporal workflow sandbox does not re-import /
  re-execute them on replay. A rebuild that hoists these to module top risks sandbox
  nondeterminism. (Same rule as the base module; see `_LineWorkflowBase.md` §0 GOTCHA-IMPORTS.)
- ⚠️ **GOTCHA-IMP2 (`logger = logging.getLogger(__name__)` is module-level and NOT used in the
  body):** `bundle_reaper.py:43`. The module defines a stdlib `logger`, but the workflow **body
  logs via `workflow.logger`**, not this module logger (`bundle_reaper.py:82,109`). The
  module-level `logger` is effectively dead for the workflow path. A rebuild should log through
  `workflow.logger` inside `run()` (replay-safe, deterministic) and must NOT substitute
  `logging.getLogger(...)` calls inside the workflow body.

### 0.2 Schedule cadence (docstring, `bundle_reaper.py:10-21`)
The canonical provisioning command (NOT part of the workflow code — run out-of-band, matching
`SustainmentWorkflow` / `GovernanceWorkflow`):
```bash
temporal schedule create \
    --schedule-id bundle-reaper \
    --workflow-id bundle-reaper \
    --workflow-type BundleReaperWorkflow \
    --task-queue olympus-main \
    --interval 15m
```
- **Cadence:** every **15 minutes** (`--interval 15m`, `bundle_reaper.py:6,21,48`).
- **schedule-id / workflow-id:** `bundle-reaper`. **workflow-type:** `BundleReaperWorkflow`.
  **task-queue:** `olympus-main`.
- ⚠️ **GOTCHA-SCHED1 (no in-code cron):** there is NO `cron_schedule=` and NO
  `@workflow.defn(sandboxed=...)`-style cron in the decorator (`bundle_reaper.py:46` is a bare
  `@workflow.defn`). A rebuild MUST NOT add `continue_as_new`, an in-code cron annotation, or a
  sleep-loop; the workflow body runs exactly once and exits. Cadence is the deployer's
  responsibility via Schedules. (The integration tests `test_bundle_activities.py:569-574` start
  the workflow as a plain one-shot `start_workflow(BundleReaperWorkflow.run, ...)` with no cron —
  confirming the body is single-shot.)

### 0.3 Determinism
- No `__init__`, no instance state, no wall-clock, no random, no module mutation in the body.
- The only nondeterminism-adjacent calls are `workflow.execute_activity`,
  `workflow.get_external_workflow_handle`, `handle.signal`, and `workflow.logger.*` — all
  Temporal-deterministic primitives.
- ⚠️ **GOTCHA-DET1 (no `workflow.now()`):** unlike the base, this workflow never timestamps
  anything in-workflow. The `now()` comparison (`expires_at < now()`) happens **inside the
  activity** (`expire_due_bundles_activity` → `bundle_svc.expire_due_bundles`, DB-side
  `now()`), NOT in the workflow body. A rebuild must keep all time logic in the activity.

---

## 1. STATE

**NONE.** `BundleReaperWorkflow` has **no `__init__` and no instance variables**
(`bundle_reaper.py:46-64`). The class body is a single `@workflow.run async def run(self)` method.
All state is local to `run()`:

| Local var | Type | Initial | Line | Mutated by → value |
|-----------|------|---------|------|---------------------|
| `expired` | `list[dict[str,str]]` | result of activity | `bundle_reaper.py:76` | assigned once from `execute_activity`; reassigned via the `except` path's `return` (never rebound, the except returns early) |
| `signalled` | `int` | `0` | `bundle_reaper.py:87` | `+= 1` per successfully-signalled non-empty `workflow_id` (`bundle_reaper.py:104`) |
| `entry` | `dict[str,str]` | loop var | `bundle_reaper.py:88` | per-iteration; each is `{"bundle_id": str, "workflow_id": str}` |
| `bundle_id` | `str` | `entry.get("bundle_id","")` | `bundle_reaper.py:89` | per-iteration |
| `wfid` | `str` | `entry.get("workflow_id","")` | `bundle_reaper.py:90` | per-iteration |
| `handle` | external WF handle | `get_external_workflow_handle(wfid)` | `bundle_reaper.py:97` | per-iteration (only when `wfid` truthy) |

- ⚠️ **GOTCHA-ST1 (no signal/query/update handlers → no buffers):** because the class has no
  `@workflow.signal` / `@workflow.query` / `@workflow.update` handlers (docstring is explicit:
  "no signal handlers (the reaper consumes nothing beyond the cron tick)" `bundle_reaper.py:52-53`),
  there are **zero** buffered-signal vars, **zero** `wait_condition` predicates, and the workflow
  never blocks on a signal. A rebuild MUST NOT add any handler. The reaper is a pure
  fan-activity-then-emit-signals body.

---

## 2. SIGNALS / QUERIES / UPDATES

**This workflow DEFINES none.** It is a signal **emitter**, never a signal **receiver**.

- **Queries:** none. (No `get_status`. The summary dict is returned as the workflow result, read
  from `WorkflowExecutionInfo` / `handle.result()`, not via a query — `bundle_reaper.py:66-74`.)
- **Updates:** none.
- **Signals received:** none.
- **Signal EMITTED:** `"bundle_expired"` with payload `BundleExpiredSignal` — fired at
  `bundle_reaper.py:98-103` to **another** workflow (the bundle's dispatching workflow) via an
  external handle. See §4.3.

> ⚠️ **GOTCHA-SIGEMIT1 (signal name is the STRING `"bundle_expired"`, not a method ref):** the
> emit uses `handle.signal("bundle_expired", BundleExpiredSignal(...))` (`bundle_reaper.py:99`).
> The receiving workflow registers a `@workflow.signal(name="bundle_expired")` (or a method named
> `bundle_expired`) consuming `BundleExpiredSignal`. A rebuild MUST fire by the **exact string
> name** `"bundle_expired"` so it matches the consumer's registered handler — see `types.py:373-385`
> and `bundle_helpers.py` (`await_bundle_completion` waits on this signal). Mismatching the name
> silently no-ops on the receiver side.

### 2.1 `BundleExpiredSignal` payload shape (`types.py:373-385`)
```text
@dataclass
class BundleExpiredSignal:
    bundle_id: str
    reason: str = "expired"
```
- The reaper constructs it as `BundleExpiredSignal(bundle_id=bundle_id, reason="expired")`
  (`bundle_reaper.py:100-102`).
- ⚠️ **GOTCHA-SIGEMIT2 (`reason` is hard-coded `"expired"`):** the reaper always passes
  `reason="expired"` (`bundle_reaper.py:101`), even though the field defaults to `"expired"`
  anyway. A rebuild must set it explicitly to `"expired"` for call-shape parity. (Other
  `reason` values like voluntary release come from the API path, not the reaper.)

---

## 3. CONTROL FLOW — `run()` pseudocode (`bundle_reaper.py:64-118`)

Signature: `@workflow.run async def run(self) -> dict[str, int]:` (`bundle_reaper.py:64-65`).
Returns `{"expired": int, "signalled": int}` where `signalled <= expired` always
(`bundle_reaper.py:68-74`).

```text
@workflow.run
async def run(self) -> dict[str, int]:                                  # bundle_reaper.py:64-65

    # ---- (A) THE SWEEP (single activity; failure → empty summary) ----
    try:                                                                 # bundle_reaper.py:75
        expired = await workflow.execute_activity(                       # bundle_reaper.py:76-80
            expire_due_bundles_activity,
            start_to_close_timeout = timedelta(minutes=2),               # bundle_reaper.py:78
            retry_policy = RETRY_POLICIES["transient"],                  # bundle_reaper.py:79
        )
    except Exception as exc:                              # noqa: BLE001 # bundle_reaper.py:81  ★BRANCH 1
        workflow.logger.warning(                                         # bundle_reaper.py:82-84
            "bundle-reaper.sweep-failed: %s", exc
        )
        return {"expired": 0, "signalled": 0}                           # bundle_reaper.py:85  ← EARLY RETURN

    # ---- (B) FAN-OUT: signal each expired bundle's parent workflow ----
    signalled = 0                                                        # bundle_reaper.py:87
    for entry in expired or []:                                          # bundle_reaper.py:88  ★LOOP (note `or []`)
        bundle_id = entry.get("bundle_id", "")                           # bundle_reaper.py:89
        wfid      = entry.get("workflow_id", "")                         # bundle_reaper.py:90

        if not wfid:                                                     # bundle_reaper.py:91  ★BRANCH 2
            # Activity already emitted the structured-stub log for
            # bundles with no associated workflow (manual admin dispatch,
            # or pre-persistence-of-workflow-id rows).             bundle_reaper.py:92-94
            continue                                                     # bundle_reaper.py:95  ← skip, NOT counted in `signalled`

        try:                                                             # bundle_reaper.py:96
            handle = workflow.get_external_workflow_handle(wfid)         # bundle_reaper.py:97
            await handle.signal(                                         # bundle_reaper.py:98-103
                "bundle_expired",
                BundleExpiredSignal(bundle_id=bundle_id, reason="expired"),
            )
            signalled += 1                                               # bundle_reaper.py:104  ← only on SUCCESS
        except Exception as exc:                          # noqa: BLE001 # bundle_reaper.py:105  ★BRANCH 3 (best-effort)
            # External workflow likely complete / cancelled. Log and
            # move on — the structured-stub log already captured
            # operator-actionable detail.                          bundle_reaper.py:106-108
            workflow.logger.info(                                        # bundle_reaper.py:109-114
                "bundle-reaper.signal-failed: bundle=%s wf=%s err=%s",
                bundle_id, wfid, exc,
            )
            # NO continue / NO re-raise — falls through to next loop iteration

    # ---- (C) SUMMARY ----
    return {                                                             # bundle_reaper.py:115-118
        "expired":   len(expired or []),                                # bundle_reaper.py:116  ← recomputes `or []`
        "signalled": signalled,                                         # bundle_reaper.py:117
    }
```

### Branch inventory (3 branch-points + 1 loop) — ALL reproduced above
1. **`except Exception` around the sweep activity** (`bundle_reaper.py:81`) — catches ANY
   exception from `execute_activity` (i.e. the activity exhausted its `transient` retries, or a
   non-retryable failure), logs `bundle-reaper.sweep-failed`, and **returns `{"expired": 0,
   "signalled": 0}` immediately** (`bundle_reaper.py:85`). The fan-out loop is never reached.
   Pinned by `test_activity_failure_returns_empty_summary` (`test_bundle_activities.py:608-646`).
2. **`if not wfid: continue`** (`bundle_reaper.py:91-95`) — for an expired bundle with **empty**
   `workflow_id` (manual admin dispatch, or rows persisted before workflow_id capture), skip the
   signal entirely. The bundle is STILL counted in the final `expired` total (`len(expired or [])`)
   but NOT in `signalled`. Pinned by `test_expired_bundle_without_workflow_id_logs_only`
   (`test_bundle_activities.py:577-606`) → asserts `{"expired": 1, "signalled": 0}`.
3. **`except Exception` around the per-bundle signal** (`bundle_reaper.py:105-114`) — if
   `get_external_workflow_handle` or `handle.signal` raises (external workflow already
   complete / cancelled / not found), log `bundle-reaper.signal-failed` at **info** level and
   **fall through to the next loop iteration** (no `continue`, no re-raise). `signalled` is NOT
   incremented for that bundle. The sweep does not fail.

(`for entry in expired or []` at `bundle_reaper.py:88` is the single loop; see GOTCHA-CF2.)

> ⚠️ **GOTCHA-CF1 (the sweep `except` is the ONLY thing that returns zeros):** there are exactly
> **two** `return` statements — the early `{"expired": 0, "signalled": 0}` on sweep failure
> (`bundle_reaper.py:85`) and the terminal summary (`bundle_reaper.py:115-118`). A rebuild MUST
> route sweep-activity failure to the zeros early-return, NOT let it propagate as a workflow
> failure. The whole point (docstring `bundle_reaper.py:23-26`) is that a transient reaper failure
> is swallowed so the next cron tick can retry — a reaper that fails the *workflow* on a DB blip
> would surface a failed-execution in Temporal every 15 minutes.
> ⚠️ **GOTCHA-CF2 (`expired or []` defends against `None`, computed TWICE):** both the loop
> (`bundle_reaper.py:88`) and the final `len(...)` (`bundle_reaper.py:116`) use `expired or []`.
> The activity is typed to return `list[dict[str,str]]` and returns `[]` on no-work, but the
> `or []` guards a `None`/falsy result defensively. A rebuild MUST use `expired or []` in BOTH
> places — the count at the end re-derives from `expired`, it does NOT track a separate counter.
> So `expired_total = len(expired or [])` counts EVERY expired row (signalled + skipped + signal-
> failed), while `signalled` counts only successful signals. They diverge whenever any bundle has
> an empty `workflow_id` or a signal raises.
> ⚠️ **GOTCHA-CF3 (`signalled += 1` is INSIDE the try, AFTER the await):** `bundle_reaper.py:104`
> sits after `await handle.signal(...)` and before the `except`. So the increment happens ONLY
> when the signal future resolves without raising. If the signal raises, control jumps to the
> `except` (105) and the increment is skipped. A rebuild must place the increment after a
> successful `await`, never before the signal call.
> ⚠️ **GOTCHA-CF4 (no per-bundle `continue` in the signal-failure branch):** unlike Branch 2
> (`if not wfid: continue`), the signal-failure `except` (Branch 3) has NO `continue` — it logs
> and naturally proceeds to the next iteration because it's the last statement in the loop body.
> Behaviorally identical to `continue` *here* (nothing follows it in the loop), but a rebuild
> should not add code after the `except` inside the loop without re-checking this.

---

## 4. ACTIVITY & EXTERNAL-SIGNAL CALLS (in order)

### 4.1 `expire_due_bundles_activity` — the sweep (`bundle_reaper.py:76-80`)
| Property | Value |
|----------|-------|
| Activity | `expire_due_bundles_activity` (passed by **function reference**, not string) |
| Args | **none** (zero-arg activity) |
| `start_to_close_timeout` | `timedelta(minutes=2)` (`bundle_reaper.py:78`) |
| `retry_policy` | `RETRY_POLICIES["transient"]` (`bundle_reaper.py:79`) — = `HTTP_RETRY_POLICY`: initial 1s, backoff 2.0, max 15s, **3 attempts** (`retry_policies.py:33`) |
| `activity_id` | **not set** (Temporal auto-assigns; the workflow runs exactly one activity so determinism is unaffected) |
| `non_retryable_error_types` | none (the `transient`/HTTP policy has no non-retryable list) |
| Sequencing | sequential — single `await`, no `gather`, no parallelism |
| Return type | `list[dict[str,str]]` — each `{"bundle_id": str, "workflow_id": str}` (`bundle_activities.py:345,397-402`) |

**What the activity does (reference only — specced in Phase 4):** wraps
`bundle_svc.expire_due_bundles(db)` to transition `claimed AND expires_at < now()` rows to
`expired`, then for each expired id post-fetches `(scope_kind, target_id, portfolio_id,
application_id, wave_id, fallback_policy)` and calls `log_internal_fallback_stub(...)` with
`reason="expired"`. **In chunk D the `workflow_id` is ALWAYS `""`** — the dispatching workflow_id
is not yet persisted on the bundle row (`bundle_activities.py:380-384,397-402`). So *today* every
returned entry has `workflow_id=""` and Branch 2 (`if not wfid: continue`) fires for **every**
bundle, meaning `signalled` is **always 0** in production until the follow-on chunk persists
workflow_ids. The workflow code already handles the future non-empty case (Branch 3 path).

> ⚠️ **GOTCHA-ACT1 (2-minute timeout, transient retry — NOT validation_failure):** the sweep gets
> a generous 2-min `start_to_close` and the 3-attempt `transient` policy (`bundle_reaper.py:78-79`).
> A DB blip retries up to 3× at 1s/2s backoff before the activity fails and the workflow swallows
> it (Branch 1). A rebuild MUST use `transient` here; a no-retry policy would surface spurious
> reaper failures on every transient DB hiccup.
> ⚠️ **GOTCHA-ACT2 (zero-arg activity, function-ref form):** the activity takes no positional
> args and is passed as a bare function reference (`expire_due_bundles_activity`,
> `bundle_reaper.py:77`), NOT a string name and NOT with `args=[...]`. A rebuild must register the
> activity under the name `expire_due_bundles_activity` (the tests stub it via
> `@activity.defn(name="expire_due_bundles_activity")`, `test_bundle_activities.py:558,589,620`)
> and invoke it with no args.

### 4.2 No child workflows
This workflow starts **no child workflows** (`execute_child_workflow`/`start_child_workflow`
never appear). The only "outbound workflow interaction" is the external **signal** in §4.3.

### 4.3 `handle.signal("bundle_expired", ...)` — external-workflow signal (`bundle_reaper.py:97-103`)
Per expired bundle **with a non-empty `workflow_id`**:
```text
handle = workflow.get_external_workflow_handle(wfid)                 # bundle_reaper.py:97
await handle.signal(                                                 # bundle_reaper.py:98-103
    "bundle_expired",
    BundleExpiredSignal(bundle_id=bundle_id, reason="expired"),
)
```
| Property | Value |
|----------|-------|
| Target | external workflow with id `wfid` (`get_external_workflow_handle(wfid)`) |
| Signal name | `"bundle_expired"` (string) |
| Payload | `BundleExpiredSignal(bundle_id=<this bundle>, reason="expired")` |
| Failure handling | wrapped in try/except (Branch 3); failure logged at **info**, loop continues |
| Success effect | `signalled += 1` |

> ⚠️ **GOTCHA-SIG-EXT1 (`get_external_workflow_handle` is deterministic; signal delivery is
> best-effort fire-and-forget):** `workflow.get_external_workflow_handle(wfid)` does not validate
> that the target exists — it returns a handle unconditionally (`bundle_reaper.py:97`). The
> `await handle.signal(...)` is where a "workflow not found / already closed" surfaces as an
> exception, caught by Branch 3. A rebuild MUST treat the signal as best-effort: a closed/cancelled
> target is an expected, non-fatal outcome (docstring `bundle_reaper.py:105-108`), NOT a reason to
> fail the sweep. The activity-side structured-stub log (`log_internal_fallback_stub`) is the
> durable operator record; the signal is an optimization for live parents.
> ⚠️ **GOTCHA-SIG-EXT2 (one signal per expired bundle, sequential `await`):** each signal is
> `await`ed sequentially inside the loop (`bundle_reaper.py:98`) — there is NO `asyncio.gather`
> fan-out of signals. A rebuild must emit signals one at a time, in `expired` list order. (For the
> tiny expected batch sizes this is fine; the docstring at `bundle_reaper.py:23-25` notes the body
> is "intentionally tiny … no per-app fan-out, no signal accumulation.")

---

## 5. GATE HANDLING

**NONE.** This workflow has **no gates, no gate evidence, no gate PRs, no gate waits, no rework
loop, no rework counters.** It does not call `_wait_for_gate_decision`,
`_reconcile_and_merge_with_retry_loop`, `_submit_gate_evidence`, `_create_gate_pr`, or any
gate/merge activity (none of those symbols appear in `bundle_reaper.py`). There are no `approve`/
`reject`/`merge_blocked`/`rework` routes because there is no human-in-the-loop surface at all.

> ⚠️ **GOTCHA-GATE1 (do NOT import or wire any gate machinery):** a rebuild that inherits
> `LineWorkflowBase` "for convenience" would WRONGLY register the four base gate signals
> (`gate_approved`, `gate_rejected`, `escalation_resolved`, `merge_retry`) and `get_status` on
> this cron workflow — none of which belong here and which would change the workflow's signal/query
> surface. Keep `BundleReaperWorkflow` a bare `@workflow.defn` class with a single `@workflow.run`
> method and NOTHING else, exactly as `bundle_reaper.py:46-118`.

---

## 6. RESILIENCE

- **Timeouts:** the sweep activity has `start_to_close_timeout = 2 minutes`
  (`bundle_reaper.py:78`). No other timeouts (signals have no per-call timeout configured here).
- **Retries:** sweep activity uses `transient` (3 attempts, 1s→15s backoff). The external signal
  has no explicit retry policy (Temporal's default signal-delivery semantics apply; on raise it's
  caught and dropped per Branch 3).
- **Heartbeats:** none — the sweep is a short DB sweep gated by the 2-min `start_to_close`.
- **continue-as-new:** **none.** Each run is independent and exits after one sweep
  (`bundle_reaper.py:48-53`). Cadence is external (Schedules API).
- **Idempotency:**
  - The **sweep** is idempotent at the data layer — `bundle_svc.expire_due_bundles` only
    transitions `claimed AND expires_at < now()`; a re-run after the rows are already `expired`
    finds nothing and returns `[]` (→ summary `{"expired": 0, "signalled": 0}`). So a duplicate
    cron tick or a Temporal activity retry does not double-expire.
  - The **signal** is fire-and-forget; a duplicate `BundleExpiredSignal` on the parent is the
    parent's problem to make idempotent (the parent's `await_bundle_completion` helper consumes
    the first one; see `bundle_helpers.py`). The reaper does not dedupe.
  - ⚠️ **GOTCHA-RES1 (no `activity_id` on the sweep):** because there's exactly one activity and no
    branching that depends on its id, the auto-assigned `activity_id` is replay-stable. A rebuild
    need not set one, but MUST NOT introduce a second activity that would shift command indices.
- **Compensation / rollback:** **none.** There is no rollback path. Failure semantics:
  - Sweep activity exhausts retries / fails → caught (Branch 1) → return zeros, NO workflow
    failure. The next 15-min tick retries the whole sweep from scratch.
  - Per-bundle signal raises → caught (Branch 3) → logged, skip, continue. The durable record is
    the activity-side `log_internal_fallback_stub`.
  - There is no `FAILED` terminal status projection (no DB write of failure) — the reaper is
    side-effect-light and self-healing across ticks.

---

## 7. Behavioral parity checklist

A rebuilt `BundleReaperWorkflow` MUST satisfy ALL of the following:

1. **Standalone class.** `@workflow.defn class BundleReaperWorkflow:` with a single
   `@workflow.run async def run(self) -> dict[str, int]` method. It does **NOT** inherit
   `LineWorkflowBase` or `HILSignalsMixin`. It has **no `__init__`, no instance state, no
   `@workflow.signal`/`@workflow.query`/`@workflow.update` handlers**. (`bundle_reaper.py:46-118`;
   GOTCHA-ST1, GOTCHA-GATE1)
2. **Imports inside the sandbox bypass.** `expire_due_bundles_activity`, `RETRY_POLICIES`, and
   `BundleExpiredSignal` are imported inside `with workflow.unsafe.imports_passed_through():`.
   (`bundle_reaper.py:36-41`; GOTCHA-IMP1)
3. **Single sweep activity, exact config.** `run()` first `await`s
   `workflow.execute_activity(expire_due_bundles_activity, start_to_close_timeout=timedelta(
   minutes=2), retry_policy=RETRY_POLICIES["transient"])` — zero args, function-ref form, **2-min**
   timeout, **transient** (3-attempt) policy, no `activity_id`. (`bundle_reaper.py:76-80`;
   GOTCHA-ACT1, GOTCHA-ACT2)
4. **Sweep-failure early return (Branch 1).** The sweep is wrapped in `try/except Exception`; on
   ANY exception it calls `workflow.logger.warning("bundle-reaper.sweep-failed: %s", exc)` and
   **returns `{"expired": 0, "signalled": 0}`** without reaching the fan-out. The workflow does
   NOT fail. (`bundle_reaper.py:81-85`; GOTCHA-CF1) — asserted by
   `test_activity_failure_returns_empty_summary`.
5. **`signalled` starts at 0; loop over `expired or []`.** (`bundle_reaper.py:87-88`; GOTCHA-CF2)
6. **Per-entry extraction.** `bundle_id = entry.get("bundle_id","")`,
   `wfid = entry.get("workflow_id","")`. (`bundle_reaper.py:89-90`)
7. **Empty-workflow_id skip (Branch 2).** `if not wfid: continue` — the bundle is NOT signalled
   and NOT counted in `signalled`, but IS counted in the final `expired` total. (`bundle_reaper.py:91-95`;
   GOTCHA-CF2) — asserted by `test_expired_bundle_without_workflow_id_logs_only`
   (`{"expired": 1, "signalled": 0}`).
8. **External signal emission.** For non-empty `wfid`:
   `handle = workflow.get_external_workflow_handle(wfid)` then
   `await handle.signal("bundle_expired", BundleExpiredSignal(bundle_id=bundle_id,
   reason="expired"))`. Signal fired by the **string** `"bundle_expired"`; payload has
   `reason="expired"` explicitly. (`bundle_reaper.py:97-103`; GOTCHA-SIGEMIT1, GOTCHA-SIGEMIT2,
   GOTCHA-SIG-EXT1)
9. **`signalled += 1` only on signal success.** The increment is the last statement in the `try`,
   after the `await`. (`bundle_reaper.py:104`; GOTCHA-CF3)
10. **Per-bundle signal-failure swallow (Branch 3).** A raise from the handle/signal is caught by
    `except Exception`, logged at **info** via
    `workflow.logger.info("bundle-reaper.signal-failed: bundle=%s wf=%s err=%s", bundle_id, wfid,
    exc)`, and the loop continues (no re-raise, no `continue` needed). `signalled` is not bumped
    for that bundle. (`bundle_reaper.py:105-114`; GOTCHA-CF4, GOTCHA-SIG-EXT1)
11. **Terminal summary.** Returns `{"expired": len(expired or []), "signalled": signalled}` —
    `expired` recomputed via `len(expired or [])`, NOT a separate counter. So the two values
    diverge exactly when any bundle is skipped (empty wfid) or its signal raises.
    (`bundle_reaper.py:115-118`; GOTCHA-CF2) — empty sweep asserts `{"expired": 0, "signalled": 0}`.
12. **No child workflows, no gates, no rework, no merge, no continue-as-new, no `workflow.now()`,
    no heartbeats.** (§§4.2, 5, 6; GOTCHA-DET1, GOTCHA-SCHED1, GOTCHA-RES1)
13. **All in-body logging via `workflow.logger`**, never the module-level `logging.getLogger`.
    (`bundle_reaper.py:82,109`; GOTCHA-IMP2)
14. **Scheduling is out-of-band.** The decorator is a bare `@workflow.defn` (no `cron_schedule`);
    cadence (15m, schedule-id `bundle-reaper`, task-queue `olympus-main`) is provisioned via the
    Temporal Schedules API. The class is registered in the worker's workflow list.
    (`bundle_reaper.py:46`, docstring `bundle_reaper.py:10-21`; `worker.py:115,160`; GOTCHA-SCHED1)
15. **Production reality (chunk D):** because the activity always returns `workflow_id=""` today
    (`bundle_activities.py:380-402`), Branch 2 fires for every bundle and `signalled` is always 0
    in production; the signal path (Branch 3 / step 8-10) is exercised only once workflow_id
    persistence lands. A rebuild must still implement the signal path — it is not dead code, it is
    forward-wired. (informational; covered by steps 7-10)
```
