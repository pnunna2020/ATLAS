# Regen 04 — Data Layer: Capability, Rationalization & Traceability Tables

ATOMIC regeneration spec. Scope: six tables —
`capability`, `capability_business_domain`, `capability_lineage`,
`rationalization_capability`, `shared_db_cluster`, `traceability_link`.

Bar: **behavioral parity** — these tables must be rebuildable EXACTLY,
column-by-column, with every CHECK value set in full, every index, every
unique constraint, every FK + ON DELETE rule, and the JSONB shapes the
`persist_*` activities write. Migrations live in
`db/alembic/versions/` (66 files; revisions 001–066 with a gap where 055
is absent — `054`→`056` per chain). Tables are created via
`op.create_table(` with the **name on the following line**; columns may be
ADDED by later migrations — each table below is traced across ALL
migrations.

> **Verified scope claim:** A `grep` across all 66 version files for
> `add_column|alter_column|drop_column|drop_constraint|create_check_constraint|create_index|create_unique_constraint`
> referencing any of these six table-name string literals returns matches
> **only** in their creation migrations (plus 050's in-create index on
> `capability` and 052's three `drop_column`s which are in 052's
> `downgrade()`). **No later migration ALTERs any of these six tables.**
> No enum→varchar "flexibility" migration touches them — every
> disposition/role/relationship column was born as `VARCHAR + CHECK`, not
> as a PG `ENUM` (see §"GOTCHAS").

---

## 0. Migration DAG (relevant slice)

These six tables are introduced across four migrations on the **linear**
Alembic chain (no branches in this slice; the only merge points in the
repo — 039, plus the heads merge — are upstream and unrelated):

```
… 003 ──▶ 004 ──▶ 005 ──▶ … ──▶ 030 ──▶ 031 ──▶ … ──▶ 049 ──▶ 050 ──▶ 051 ──▶ 052 ──▶ … ──▶ 057 ──▶ 058 ──▶ …
            │        │                      │                       │                              │
   traceability_link │            shared_db_cluster        rationalization_capability    (view redefine only;
   (CREATE)    (3 idx on it)        (CREATE)                (CREATE) + capability         no table change)
                                                            +3 cols + view CREATE
                                          capability / capability_business_domain /
                                          capability_lineage all CREATE in 050
```

Per-migration ledger (this slice only):

| rev | down_rev | file | what it does to our 6 tables |
|---|---|---|---|
| `004` | `003` | `004_create_analytics_tables.py` | CREATE `traceability_link` (+ `model_config`, `model_override`, `score_history`, `audit_log`) |
| `005` | `004` | `005_create_indexes.py` | 3 indexes on `traceability_link` |
| `031` | `030` | `031_add_data_projection_columns.py` | CREATE `shared_db_cluster`; (also adds 6 cols to `application` — out of scope here) |
| `050` | `049` | `050_capability_system_grain.py` | CREATE `capability`, `capability_business_domain`, `capability_lineage` (+ `system`, `system_application`, `business_domain`, `business_domain_lineage`, `system_lineage`, `agent_task_session_artifact`; +3 cols on `agent_task`) |
| `052` | `051` | `052_rationalization_capability.py` | CREATE `rationalization_capability`; ADD 3 cols to `capability` (`rationalization_capability_id`, `parent_capability_id`, `split_at`) + 2 indexes; CREATE VIEW `application_disposition` |
| `058` | `057` | `058_application_disposition_capability_grain.py` | CREATE OR REPLACE VIEW `application_disposition` (no table change; documented here because it consumes `capability` + `rationalization_capability`) |

**Final column counts** (post-066): `capability`=14, `capability_business_domain`=2, `capability_lineage`=11, `rationalization_capability`=14, `shared_db_cluster`=6, `traceability_link`=11.

All six revisions are `branch_labels=None`, `depends_on=None`. All UUID
PK columns use `server_default=sa.text("gen_random_uuid()")` (requires
`pgcrypto`/`gen_random_uuid()` available — provisioned upstream by 001).
`UUID(as_uuid=True)` and `JSONB` are imported from
`sqlalchemy.dialects.postgresql` in each migration.

---

## 1. `capability`

> Discovery-grain entity: **one slice of business functionality** on a
> `system` (M1..M19 in the FAA/ATLAS SF1 matrix). Created in migration
> 050; extended with three rat-cap/split columns in migration 052.
> Written by Discovery's `capability-extraction` skill via
> `persist_capability_catalog` and by Rationalization's clustering step
> via `persist_rationalization_capabilities`.

Source: CREATE at `db/alembic/versions/050_capability_system_grain.py:218-306`;
ALTER (3 cols) at `db/alembic/versions/052_rationalization_capability.py:228-270`.

### 1.1 Columns (14 total — 11 from 050, 3 from 052)

| # | column | type | nullable | default | FK (→table.col, ON DELETE) | added-by (path:line) |
|---|---|---|---|---|---|---|
| 1 | `id` | `UUID` | NO | `gen_random_uuid()` | — (PK) | 050:220-225 |
| 2 | `system_id` | `UUID` | NO | — | →`system.id` **ON DELETE CASCADE** | 050:226-231 |
| 3 | `name` | `VARCHAR(255)` | NO | — | — | 050:232 |
| 4 | `description` | `TEXT` | YES | — | — | 050:233 |
| 5 | `external_id` | `VARCHAR(64)` | YES | — | — | 050:234-243 |
| 6 | `kind` | `VARCHAR(32)` | NO | `'legacy'` (server_default) | — | 050:244-256 |
| 7 | `primary_disposition` | `VARCHAR(32)` | YES | — | — | 050:257-266 |
| 8 | `secondary_disposition` | `VARCHAR(32)` | YES | — | — | 050:267-276 |
| 9 | `created_at` | `TIMESTAMPTZ` | NO | `now()` | — | 050:277-282 |
| 10 | `updated_at` | `TIMESTAMPTZ` | NO | `now()` | — | 050:283-288 |
| 11 | `retired_at` | `TIMESTAMPTZ` | YES | — | — | 050:289 |
| 12 | `rationalization_capability_id` | `UUID` | YES | — | →`rationalization_capability.id` **ON DELETE SET NULL** | 052:228-243 |
| 13 | `parent_capability_id` | `UUID` | YES | — | →`capability.id` (self-ref) **ON DELETE CASCADE** | 052:244-258 |
| 14 | `split_at` | `TIMESTAMPTZ` | YES | — | — | 052:259-270 |

Column semantics (from inline `comment=` in 050/052):
- `kind`: `'legacy'` (current-state inventory on legacy system) / `'derived'` (on a target system, from one+ sources) / `'net_new'` (on a target system, no source provenance, e.g. S6 PHI-isolation policy-as-code).
- `external_id`: SF1 capability-matrix identifier `'M1'..'M19'`; NULL allowed.
- `primary_disposition`: one of the 7 Olympus dispositions; NULL until disposition-recommender runs; required on legacy capabilities at G-RR approval (enforced in app logic, not DB).
- `secondary_disposition`: the "+ Consolidate"/"+ Retire" the SF1 matrix encodes (e.g. M3 IACRA FTN resolver = "Re-architect + Consolidate").
- `rationalization_capability_id`: rolls up to a rat-cap; NULL until Rationalization clustering sets the FK at G-RR submit.
- `parent_capability_id`: set on **child** rows the clustering agent split off from a Discovery-emitted parent; NULL on parents and never-split rows.
- `split_at`: timestamp the row was split off; NULL on parents and never-split rows.

### 1.2 CHECK constraints (FULL value sets)

1. **`capability_kind_chk`** (050:290-293):
   ```
   kind IN ('legacy', 'derived', 'net_new')
   ```
2. **`capability_primary_disposition_chk`** (050:294-299):
   ```
   primary_disposition IS NULL OR primary_disposition IN
     ('Retire', 'Retain', 'Refactor', 'Rearchitect', 'Replace', 'Replatform', 'Consolidate')
   ```
3. **`capability_secondary_disposition_chk`** (050:300-305):
   ```
   secondary_disposition IS NULL OR secondary_disposition IN
     ('Retire', 'Retain', 'Refactor', 'Rearchitect', 'Replace', 'Replatform', 'Consolidate')
   ```
   (Both disposition CHECKs use the **identical** 7-value set — the canonical Olympus disposition vocabulary.)

### 1.3 Indexes

| index | columns | unique | partial WHERE | added-by |
|---|---|---|---|---|
| `ix_capability_system` | `(system_id)` | no | — | 050:307 |
| `ix_capability_system_external_id` | `(system_id, external_id)` | **YES** | `external_id IS NOT NULL` | 050:308-314 |
| `ix_capability_rat_cap` | `(rationalization_capability_id)` | no | `rationalization_capability_id IS NOT NULL` | 052:271-278 |
| `ix_capability_parent` | `(parent_capability_id)` | no | `parent_capability_id IS NOT NULL` | 052:279-284 |

The partial-unique `ix_capability_system_external_id` is the **natural
key** for SF1-bound rows: `(system_id, external_id)` is unique when
`external_id` is set; multiple NULL `external_id` rows per system are
allowed (NULLs distinct under Postgres partial-index semantics). This is
the index `persist_capability_catalog` targets via `ON CONFLICT
(system_id, external_id) WHERE external_id IS NOT NULL`.

### 1.4 JSONB shapes
None. `capability` has no JSONB column.

### 1.5 How rows are written (Git → DB projection)

`capability` is **not** a Git-mirror table per se — it is a projection of
two artifacts written by two activities:

**A. Discovery projection — `persist_capability_catalog`**
(`temporal/olympus_workflows/activities/line_transitions.py:1415`,
INSERTs at `:1648` and `:1683`). Reads Discovery's committed
`capability-catalog.json` (schema `schemas/discovery/capability-catalog.schema.json`).
Per `capabilities[]` entry it UPSERTs a `capability` row on the
**`(system_id, external_id)`** natural key when `external_id` is set:
```sql
INSERT INTO capability (system_id, name, description, external_id, kind)
VALUES ($1, $2, $3, $4, 'legacy')
ON CONFLICT (system_id, external_id) WHERE external_id IS NOT NULL
DO UPDATE SET name = EXCLUDED.name,
              description = COALESCE(NULLIF(EXCLUDED.description, ''), capability.description),
              updated_at = now()
RETURNING id, (xmax = 0) AS inserted
```
When `external_id` is NULL it SELECT-by-`(system_id, name, external_id IS NULL)`
then INSERTs (`kind='legacy'`) or UPDATEs description (`:1669-1707`).
`kind` is **hard-coded `'legacy'`** on this Discovery path. `business_domain_names[]`
are resolved to `capability_business_domain` edges (§2.5).
Cross-ref: `regen/03b-activities/line_transitions-1-discovery-decomp-capability.md`.

**B. Rationalization split-children — `persist_rationalization_capabilities`**
(`temporal/olympus_workflows/activities/line_transitions.py:2049`, child
INSERT at `:2453`). When the clustering plan
(`schemas/rationalization/rationalization-clustering-plan.schema.json`,
`capability_splits[]`) splits one Discovery capability across multiple
rat-caps, it mints **child** rows that inherit the parent's
`system_id`/`kind`/`external_id` and carry `parent_capability_id` +
`split_at = now()` + `rationalization_capability_id`:
```sql
INSERT INTO capability (
    system_id, name, description, kind, external_id,
    parent_capability_id, split_at, rationalization_capability_id)
VALUES ($1, $2, $3, $4, $5, $6, now(), $7)
```
The same activity also sets `capability.rationalization_capability_id`
(and clears it for parents) on the non-split assignments
(UPDATE at `:2363-2370`, around the `capability_assignments[]` loop).

---

## 2. `capability_business_domain`

> N:M edge between `capability` and `business_domain` (most realizations
> are 1:1). Pure junction table — two FK columns forming the composite PK.

Source: CREATE at `db/alembic/versions/050_capability_system_grain.py:364-383`.

### 2.1 Columns (2 total)

| # | column | type | nullable | default | FK (→table.col, ON DELETE) | added-by (path:line) |
|---|---|---|---|---|---|---|
| 1 | `capability_id` | `UUID` | NO | — | →`capability.id` **ON DELETE CASCADE** | 050:366-371 |
| 2 | `business_domain_id` | `UUID` | NO | — | →`business_domain.id` **ON DELETE CASCADE** | 050:372-377 |

### 2.2 Primary key
**`capability_business_domain_pkey`** = composite `(capability_id, business_domain_id)` (050:378-382). No surrogate `id`.

### 2.3 CHECK constraints
None.

### 2.4 Indexes

| index | columns | unique | added-by |
|---|---|---|---|
| (PK) `capability_business_domain_pkey` | `(capability_id, business_domain_id)` | YES (PK) | 050:378-382 |
| `ix_capability_business_domain_domain` | `(business_domain_id)` | no | 050:384-388 |

The composite PK already indexes `capability_id` first; the explicit
`ix_..._domain` index covers reverse lookups by `business_domain_id`.

### 2.5 JSONB shapes
None.

### 2.6 How rows are written
By `persist_capability_catalog`
(`temporal/olympus_workflows/activities/line_transitions.py:1723`):
for each `business_domain_names[]` reference on a capability that resolves
to a domain in the same catalog, it inserts the edge idempotently:
```sql
INSERT INTO capability_business_domain (capability_id, business_domain_id)
VALUES ($1, $2)
ON CONFLICT (capability_id, business_domain_id) DO NOTHING
```
Names not present in the catalog's domain set are silently ignored
(defensive — the SKILL.md contract requires references to exist in
`business_domains[]`). Cross-ref:
`regen/03b-activities/line_transitions-1-discovery-decomp-capability.md`.

⚠️ **Mass-delete vector:** both FKs are `ON DELETE CASCADE`. Deleting a
`capability` (which itself cascades from `system` → from `portfolio`)
removes its edges; deleting a `business_domain` removes them too. There is
no `retired_at` soft-delete on this edge — it is hard-deleted with either
parent.

---

## 3. `capability_lineage`

> **N source capabilities collapse onto 1 target capability.** This is the
> capability-grain provenance edge. `relationship='dropped'` is the
> explicit "source has no successor" row (and is the **only** case where
> `target_capability_id` is NULL).

Source: CREATE at `db/alembic/versions/050_capability_system_grain.py:393-472`.

### 3.1 Columns (11 total)

| # | column | type | nullable | default | FK (→table.col, ON DELETE) | added-by (path:line) |
|---|---|---|---|---|---|---|
| 1 | `id` | `UUID` | NO | `gen_random_uuid()` | — (PK) | 050:395-400 |
| 2 | `target_capability_id` | `UUID` | **YES** | — | →`capability.id` **ON DELETE CASCADE** | 050:401-411 |
| 3 | `source_capability_id` | `UUID` | NO | — | →`capability.id` **ON DELETE CASCADE** | 050:412-417 |
| 4 | `relationship` | `VARCHAR(32)` | NO | — | — | 050:418-430 |
| 5 | `notes` | `TEXT` | YES | — | — | 050:431 |
| 6 | `confidence` | `NUMERIC(3,2)` | YES | — | — | 050:432 |
| 7 | `agent_emitted` | `BOOLEAN` | NO | `false` (server_default) | — | 050:433-443 |
| 8 | `ratified_by` | `VARCHAR(255)` | YES | — | — | 050:444 |
| 9 | `ratified_at` | `TIMESTAMPTZ` | YES | — | — | 050:445 |
| 10 | `created_at` | `TIMESTAMPTZ` | NO | `now()` | — | 050:446-451 |
| 11 | `retired_at` | `TIMESTAMPTZ` | YES | — | — | 050:452 |

Column semantics (from inline `comment=`):
- `target_capability_id`: NULL **only** when `relationship='dropped'`.
- `relationship`: `'absorbed'` (full absorption / 1:1 Rearchitect) / `'partial'` (part of source contributes; remainder under another target — the M:N case) / `'transformed'` (semantics significantly change) / `'dropped'` (source retired, no target).
- `agent_emitted`: TRUE if emitted by an agent; FALSE if reviewer-authored (Option-B dispatch UI) or manually backfilled.

⚠️ **Nullable-with-no-default surprise:** `target_capability_id` is
NULLABLE with **no default** but is constrained by CHECK
`capability_lineage_target_chk` (§3.2) to be NULL **iff**
`relationship='dropped'`. Both `source_capability_id` and
`target_capability_id` point at the **same** `capability` table.

### 3.2 CHECK constraints (FULL value sets)

1. **`capability_lineage_relationship_chk`** (050:458-462):
   ```
   relationship IN ('absorbed', 'partial', 'transformed', 'dropped')
   ```
2. **`capability_lineage_target_chk`** (050:463-467) — the dropped/target coupling:
   ```
   (relationship = 'dropped' AND target_capability_id IS NULL)
   OR (relationship <> 'dropped' AND target_capability_id IS NOT NULL)
   ```
3. **`capability_lineage_confidence_chk`** (050:468-471):
   ```
   confidence IS NULL OR (confidence >= 0 AND confidence <= 1)
   ```

### 3.3 Unique constraint
**`capability_lineage_target_source_uniq`** = `(target_capability_id, source_capability_id)` (050:453-457). Note: a `NULL target` (dropped) does not collide under standard unique-constraint NULL semantics, so multiple `dropped` rows for distinct sources coexist.

### 3.4 Indexes

| index | columns | unique | added-by |
|---|---|---|---|
| `ix_capability_lineage_target` | `(target_capability_id)` | no | 050:473-477 |
| `ix_capability_lineage_source` | `(source_capability_id)` | no | 050:478-482 |
| (unique constraint) `capability_lineage_target_source_uniq` | `(target_capability_id, source_capability_id)` | YES | 050:453-457 |

### 3.5 JSONB shapes
None.

### 3.6 How rows are written
No `persist_*` activity in this repo INSERTs into `capability_lineage`
directly (a `grep` for `INSERT INTO capability_lineage` over the worker
returns no matches; the table is referenced read-only by the rat-cap
context-priors query at `line_transitions.py:1986` for
`capability_business_domain`, not lineage). `capability_lineage` is
populated by the lineage/mapping reviewer flow (agent-emitted or
reviewer-authored mappings ratified via `ratified_by`/`ratified_at`); for
behavioral parity, reproduce the **table + constraints exactly** — the
columns `agent_emitted`/`ratified_by`/`ratified_at` capture provenance,
and the absence of a worker writer is itself the current behavior.

⚠️ **Mass-delete vector:** both FKs `ON DELETE CASCADE` to `capability`.
Deleting either the source or target capability hard-deletes the lineage
edge (no soft-delete via `retired_at` on cascade).

---

## 4. `rationalization_capability`

> **Disposition-decision-unit grain** ("rat-cap") above Discovery's
> implementation-feature-grain `capability` table. Portfolio-scoped; one
> rat-cap can span many apps, one app contributes to many rat-caps.
> Holds the disposition + target-service binding read by G-RR/G-DA.
> Resolves the SF1 grain mismatch (Discovery's ~10 fine caps/app vs SF1's
> ~19 M-rows for the whole portfolio).

Source: CREATE at `db/alembic/versions/052_rationalization_capability.py:68-189`.

### 4.1 Columns (14 total)

| # | column | type | nullable | default | FK (→table.col, ON DELETE) | added-by (path:line) |
|---|---|---|---|---|---|---|
| 1 | `id` | `UUID` | NO | `gen_random_uuid()` | — (PK) | 052:70-75 |
| 2 | `portfolio_id` | `UUID` | NO | — | →`portfolio.id` **ON DELETE CASCADE** | 052:76-81 |
| 3 | `wave_id` | `UUID` | YES | — | →`wave.id` **ON DELETE SET NULL** | 052:82-94 |
| 4 | `external_id` | `VARCHAR(64)` | YES | — | — | 052:95-105 |
| 5 | `name` | `VARCHAR(255)` | NO | — | — | 052:106 |
| 6 | `description` | `TEXT` | **NO** | — | — | 052:107 |
| 7 | `rationale` | `TEXT` | **NO** | — | — | 052:108-116 |
| 8 | `evidence_refs` | `JSONB` | **NO** | — | — | 052:117-128 |
| 9 | `confidence` | `NUMERIC(3,2)` | YES | — | — | 052:129-134 |
| 10 | `disposition` | `VARCHAR(64)` | YES | — | — | 052:135-146 |
| 11 | `target_service_external_id` | `VARCHAR(64)` | YES | — | — | 052:147-157 |
| 12 | `created_at` | `TIMESTAMPTZ` | NO | `now()` | — | 052:158-163 |
| 13 | `updated_at` | `TIMESTAMPTZ` | NO | `now()` | — | 052:164-169 |
| 14 | `retired_at` | `TIMESTAMPTZ` | YES | — | — | 052:170-178 |

⚠️ **Nullable-with-no-default surprises:** `description`, `rationale`, and
`evidence_refs` are all **NOT NULL with no server default** — a row cannot
be inserted without them. The persist activity always supplies them
(`description`/`rationale` coerced to `''` and `evidence_refs` to `'[]'`
when absent — see §4.6). `disposition` is **`VARCHAR(64)`** here (wider
than `capability`'s `VARCHAR(32)`) but its CHECK set is the same 7-value
disposition vocabulary.

Column semantics (from inline `comment=`):
- `wave_id`: wave that produced the rat-cap; **SET NULL** on wave delete so soft history survives a wave purge. SF1-bound rows converge across waves via the portfolio-scoped natural key.
- `external_id`: SF1 M-row id (`'M1'..'M19'`); NULL for clusters that don't cleanly map (rationale must explain).
- `evidence_refs`: per-fine-capability citations (shape §4.5).
- `disposition`: 5R/7-disposition outcome at rat-cap grain; set by disposition-recommender post-G-RR; NULL until G-DA stage.
- `target_service_external_id`: SF3 target service id (`'S1'..'S11'`); set by capability-consolidation-advisor at G-DA; may be NULL for Retire/Retain.
- `retired_at`: set when a rat-cap is superseded by a re-cluster (soft-delete preserves gate-decision history).

### 4.2 CHECK constraints (FULL value sets)

1. **`rationalization_capability_disposition_chk`** (052:179-184):
   ```
   disposition IS NULL OR disposition IN
     ('Retire', 'Retain', 'Refactor', 'Rearchitect', 'Replace', 'Replatform', 'Consolidate')
   ```
2. **`rationalization_capability_confidence_chk`** (052:185-188):
   ```
   confidence IS NULL OR (confidence >= 0 AND confidence <= 1)
   ```

### 4.3 Indexes (incl. the two partial-unique natural keys)

| index | columns | unique | partial WHERE | added-by |
|---|---|---|---|---|
| `ix_rat_cap_portfolio` | `(portfolio_id)` | no | — | 052:190-194 |
| `ix_rat_cap_wave` | `(wave_id)` | no | `wave_id IS NOT NULL` | 052:195-200 |
| `ix_rat_cap_portfolio_external_id` | `(portfolio_id, external_id)` | **YES** | `external_id IS NOT NULL AND retired_at IS NULL` | 052:205-213 |
| `ix_rat_cap_portfolio_name` | `(portfolio_id, name)` | **YES** | `retired_at IS NULL` | 052:217-223 |

**Two-tier natural key** (critical for the UPSERT logic):
- **Primary key when SF1-bound:** `(portfolio_id, external_id)` unique among **live** rows with a non-NULL `external_id`. Multiple NULL `external_id` per portfolio allowed; retired rows excluded so a re-cluster can re-mint the same `external_id`.
- **Fallback when `external_id` IS NULL:** `(portfolio_id, name)` unique among **live** rows. Retired rows may share a name with their successors (soft-delete history stays intact).

### 4.4 No FK from any later table
`capability.rationalization_capability_id` (052:228-243) is the only FK
**into** this table, and it is **ON DELETE SET NULL** — deleting a rat-cap
nulls the children's FK rather than cascading. (Hard delete of a rat-cap
is not the normal path; supersession uses `retired_at`.)

### 4.5 JSONB shape — `evidence_refs` (NOT NULL)

Stored verbatim from the clustering plan's
`rationalization_capabilities[].evidence_refs`. Schema
`schemas/rationalization/rationalization-clustering-plan.schema.json`
(`evidence_refs` block) — array, **minItems 1**, each item
`additionalProperties:false` with all five fields required:

```json
[
  {
    "capability_id":   "<uuid>",            // Discovery fine-capability row id
    "application_id":  "<uuid>",            // app the fine capability belongs to
    "application_name":"<string, len>=1>",  // denormalized for the G-RR card
    "capability_name": "<string, len>=1>",  // denormalized fine-cap name
    "citation":        "<string, len>=1>"   // e.g. "capability-catalog.json:capabilities[N]"
                                            //  or  "data-domains.json:domain[N]"
  }
]
```

Renders on the G-RR card as "this rat-cap is justified by N fine
capabilities across M apps" (click-to-expand). Persist serializes it with
`json.dumps(evidence_refs)` and binds as `$N::jsonb`
(`line_transitions.py:2164`, `:2202`, `:2234`).

### 4.6 How rows are written (Git → DB projection)

Written by **`persist_rationalization_capabilities`**
(`temporal/olympus_workflows/activities/line_transitions.py:2049`),
consuming Rationalization's committed
`rationalization-clustering-plan.json`. Per
`rationalization_capabilities[]` entry, three UPSERT paths:

- **`existing_id` supplied** → validate it belongs to `portfolio_id` (defends against cross-portfolio plan poisoning), then direct `UPDATE … SET name/description/rationale/evidence_refs=$5::jsonb/confidence/wave_id/external_id, updated_at=now()` (`:2196-2217`).
- **`external_id` set** → INSERT … `ON CONFLICT (portfolio_id, external_id) WHERE external_id IS NOT NULL AND retired_at IS NULL DO UPDATE …` (`:2226-2257`).
- **else (name fallback)** → `SELECT … WHERE portfolio_id=$1 AND name=$2 AND retired_at IS NULL` then INSERT-or-UPDATE inside the txn (the partial `WHERE` prevents `ON CONFLICT` inference, so it's done manually) (`:2264-2324`).

`description`/`rationale` are coerced to `str(... or "")` and
`evidence_refs` to `... or []` before `json.dumps`
(`:2148-2164`) — that is how the NOT NULL columns are always satisfied.
`disposition` and `target_service_external_id` are **not** set here; they
are written later by **`persist_rationalization_capability_dispositions`**
(`line_transitions.py:2604`, UPDATE at `:2795` / `:2809`) which matches a
rat-cap by `rationalization_capability_id` or by
`(portfolio_id, external_id)` and sets `disposition` (+ optionally
`target_service_external_id`, left untouched when the entry omits it so
G-DA's advisor isn't clobbered).

Cross-ref: `regen/03b-activities/line_transitions-2-rationalization.md`.

---

## 5. `shared_db_cluster`

> Records a **target application's participation in a shared-DB cluster**
> (post-G-DT Data-line projection). Composite PK `(target_app_id,
> cluster_id)`. One target may have different patterns across clusters.

Source: CREATE at `db/alembic/versions/031_add_data_projection_columns.py:126-151`.

### 5.1 Columns (6 total)

| # | column | type | nullable | default | FK (→table.col, ON DELETE) | added-by (path:line) |
|---|---|---|---|---|---|---|
| 1 | `target_app_id` | `UUID` | NO | — | →`application.id` **ON DELETE CASCADE** | 031:128-133 |
| 2 | `cluster_id` | `VARCHAR(128)` | NO | — | — | 031:134 |
| 3 | `role` | `VARCHAR(16)` | NO | — | — | 031:135 |
| 4 | `pattern` | `VARCHAR(32)` | NO | — | — | 031:136 |
| 5 | `created_at` | `TIMESTAMPTZ` | NO | `NOW()` (server_default `sa.text("NOW()")`) | — | 031:137-142 |
| 6 | `retired_at` | `TIMESTAMPTZ` | YES | — | — | 031:143-147 |

Column semantics (from migration docstring 031:45-57):
- `cluster_id`: opaque cluster identifier (string from the decomposition artifact).
- `role`: the target's role in the cluster — `read`/`write`/`owner`/`both`.
- `pattern`: mirrors `application.data_pattern` whitelist; per-cluster since one target may differ across clusters.
- `created_at`: projection time, immediately post-G-DT.
- `retired_at`: reserved for retaining historical participation rows when a target is later retired; NULL = still active.

### 5.2 Primary key
**`shared_db_cluster_pkey`** = composite `(target_app_id, cluster_id)` (031:148-150). No surrogate `id`.

### 5.3 CHECK constraints
**None at the DB level.** ⚠️ `role` and `pattern` are **NOT** constrained
by a DB CHECK — the whitelists are enforced **only in application code**
(`_extract_shared_db_cluster_rows`, §5.5). Malformed entries are dropped
with a `logger.warning` before insert, never rejected by the database.
This is a deliberate "validate in the projector, keep the column flexible"
choice and must be reproduced as such (do **not** add a CHECK — that would
change behavior for any direct/legacy insert).

### 5.4 Indexes

| index | columns | unique | added-by |
|---|---|---|---|
| (PK) `shared_db_cluster_pkey` | `(target_app_id, cluster_id)` | YES (PK) | 031:148-150 |
| `ix_shared_db_cluster_cluster_id` | `(cluster_id)` | no | 031:154-158 |

`ix_shared_db_cluster_cluster_id` supports "which targets share cluster
X?" queries from the portfolio / cluster-detail pages.

### 5.5 JSONB shapes
None. (The cluster participation arrives as JSON in the artifact but is
normalized into scalar columns here.)

### 5.6 How rows are written (Git → DB projection)

Written by **`persist_data_side_effects`**
(`temporal/olympus_workflows/activities/line_transitions.py:3618`),
consuming the target's committed `decomposition-strategy.json`. Helper
`_extract_shared_db_cluster_rows` (`:3561`) reads the `clusters[]` array:

```json
{ "clusters": [ { "cluster_id": "...", "role": "owner", "pattern": "strangler-fig" }, ... ] }
```

and **whitelists** each entry against two frozensets defined in the same
module:

- `_CLUSTER_ROLES` (`:3488-3495`) = `{ "read", "write", "owner", "both" }`
- `_DATA_PATTERNS` (`:3478-3486`) = `{ "database-per-service", "strangler-fig", "db-facade", "dedicated", "shared-read-only" }`

Entries with a missing/blank `cluster_id`, a `role` not in `_CLUSTER_ROLES`,
or a `pattern` not in `_DATA_PATTERNS` are **skipped with a warning**
(`:3593-3606`). Surviving rows are inserted idempotently (insert at `:3698`):
```sql
INSERT INTO shared_db_cluster (target_app_id, cluster_id, role, pattern, created_at)
VALUES ($1, $2, $3, $4, $5)
ON CONFLICT (target_app_id, cluster_id) DO NOTHING
```
`created_at` is passed explicitly as `datetime.now(timezone.utc)` (the
`NOW()` server default is the fallback for any direct insert). The same
activity also writes the six `application.data_*` projection columns from
031 (out of scope for this doc). Cross-ref:
`regen/03b-activities/line_transitions-3-architecture-data.md`.

⚠️ **Mass-delete vector:** `target_app_id` is `ON DELETE CASCADE` to
`application`. Deleting an application removes **all** its cluster
participation rows. There is no cascade from the cluster side (clusters
are not a table — `cluster_id` is a free string).

---

## 6. `traceability_link`

> Structured **citation/provenance edges** between artifacts for one
> application (`{artifact}:{section}:{finding-id}` or
> `{repo}:{file}:{line}` style traces). One of the original analytics
> tables (migration 004); indexed in 005. Unchanged since.

Source: CREATE at `db/alembic/versions/004_create_analytics_tables.py:71-86`;
indexes at `db/alembic/versions/005_create_indexes.py:69-76`.

### 6.1 Columns (11 total)

| # | column | type | nullable | default | FK (→table.col, ON DELETE) | added-by (path:line) |
|---|---|---|---|---|---|---|
| 1 | `id` | `UUID` | NO | `gen_random_uuid()` | — (PK) | 004:73-74 |
| 2 | `app_id` | `UUID` | NO | — | →`application.id` **ON DELETE CASCADE** | 004:75-76 |
| 3 | `source_artifact` | `TEXT` | NO | — | — | 004:77 |
| 4 | `source_element` | `TEXT` | YES | — | — | 004:78 |
| 5 | `source_version` | `VARCHAR(100)` | YES | — | — | 004:79 |
| 6 | `target_artifact` | `TEXT` | NO | — | — | 004:80 |
| 7 | `target_element` | `TEXT` | YES | — | — | 004:81 |
| 8 | `target_version` | `VARCHAR(100)` | YES | — | — | 004:82 |
| 9 | `relationship` | `VARCHAR(100)` | NO | — | — | 004:83 |
| 10 | `produced_by` | `JSONB` | YES | — | — | 004:84 |
| 11 | `validated_at` | `JSONB` | YES | — | — | 004:85 |

⚠️ **Column-name trap:** `validated_at` is **JSONB**, *not* a timestamp,
despite its `_at` suffix. Reproduce the type as `JSONB NULL` exactly.

⚠️ **No CHECK on `relationship`:** `relationship` is a free
`VARCHAR(100)` with **no** value constraint. The application emits
`'references'` (see `parse_citations`,
`olympus-api/src/services/traceability.py:85/106/125`), and the model
docstring lists "references, derived_from, validates, etc."
(`olympus-api/src/models/traceability.py:17-20`) — but the DB accepts any
≤100-char string.

### 6.2 CHECK constraints
None.

### 6.3 Unique constraints
None declared. (The writer relies on `ON CONFLICT DO NOTHING` against the
**PK** `id` only — see §6.6 — so duplicate logical links can exist; the
writer dedups in-memory via a `seen` set in `parse_citations`.)

### 6.4 Indexes

| index | columns | unique | added-by |
|---|---|---|---|
| `ix_traceability_link_app_id` | `(app_id)` | no | 005:69-70 |
| `ix_traceability_link_source_artifact` | `(source_artifact)` | no | 005:71-73 |
| `ix_traceability_link_target_artifact` | `(target_artifact)` | no | 005:74-76 |

### 6.5 JSONB shapes — `produced_by` and `validated_at`

- **`produced_by`** (JSONB, nullable): an arbitrary provenance dict
  threaded through unchanged from the caller. The API writer
  `index_citations(db, app_id, source_artifact, citations, *, source_version=None, produced_by=None)`
  (`olympus-api/src/services/traceability.py:132-180`) binds the caller's
  `produced_by` dict verbatim into the column (`:168`). No schema pins its
  shape; in practice it carries agent/run provenance (e.g.
  `{ "agent_task_id": "<uuid>", "skill": "<name>", "model": "<id>" }`) —
  but **any JSON object is valid**. For parity, type = `JSONB NULL`,
  shape = open/caller-defined.
- **`validated_at`** (JSONB, nullable): present in the schema and the
  read-model (`olympus-api/src/models/traceability.py:36`) but **never
  written** by any code path in this repo (no INSERT/UPDATE sets it; the
  `index_citations` INSERT column list omits it entirely —
  `traceability.py:152-156`). It is read back as `dict | None`. For
  parity: column exists as `JSONB NULL`, always NULL in practice.

### 6.6 How rows are written (Git → DB projection)

Two relevant facts for parity:

**A. The Temporal activity is a STUB that writes nothing.** The activity
`index_artifact_citations` (`temporal/olympus_workflows/activities/traceability.py`)
**does not** parse text, **does not** touch the DB, and **always returns
`citations_found=0, citations_indexed=0`** regardless of input
(`input.artifact_text`/`source_version`/`produced_by` are accepted but
ignored). The docstring describes intended behavior that is NOT
implemented. ⚠️ For behavioral parity, reproduce the **stub** — do not
implement parsing. Cross-ref (authoritative):
`regen/03b-activities/governance_traceability.md` §2.4.

**B. The real writer is the API service.** `traceability_link` rows are
written by `index_citations` in
`olympus-api/src/services/traceability.py:132-180`, fed by
`parse_citations` (`:56-129`) which extracts two citation grammars:
- artifact: `{artifact}:{section}[:{finding}]` → `relationship='references'`, `target_element = "{section}:{finding}"` or `"{section}"`;
- repo: `{owner}/{repo}:{file}:{line}` → `target_artifact = "{repo}:{file}"`, `target_element = "L{line}"`, `relationship='references'`;
- explicit markers `[[ref:...]]` / `[cite:...]` → `relationship='references'`.

INSERT (`:152-157`):
```sql
INSERT INTO traceability_link
  (id, app_id, source_artifact, source_element, source_version,
   target_artifact, target_element, relationship, produced_by)
VALUES (:id, :app_id, :source_artifact, :source_element, :source_version,
        :target_artifact, :target_element, :relationship, :produced_by)
ON CONFLICT DO NOTHING
```
- `id` minted client-side via `uuid.uuid4()` (`:160`), so `ON CONFLICT DO NOTHING` only fires on the (astronomically unlikely) PK collision — effectively an unconditional insert; logical dedup is done in `parse_citations`'s `seen` set.
- `target_version` and `validated_at` are **not** in the column list → both default to NULL on every insert.
- This service is also read heavily by `scoring.py` (`olympus-api/src/services/scoring.py:401-745`) for redundancy/coverage computation (read-only joins on `traceability_link`).

⚠️ **Mass-delete vector:** `app_id` is `ON DELETE CASCADE` to
`application`. Deleting an application removes all its traceability links.

---

## 7. Cross-cutting GOTCHAS (consolidated)

1. **No enum→varchar flexibility migration touches these six tables.**
   Every disposition / role / relationship / pattern / kind column was
   **born** as `VARCHAR(n)` — with a CHECK where one exists
   (`capability.kind`, both `capability` disposition columns,
   `capability_lineage.relationship`, `rationalization_capability.disposition`)
   and **without** a CHECK where the whitelist lives in app code
   (`shared_db_cluster.role` / `.pattern`, `traceability_link.relationship`).
   Do **not** model any of these as PG `ENUM`.

2. **Disposition vocabulary is identical everywhere it's CHECK-constrained:**
   `('Retire', 'Retain', 'Refactor', 'Rearchitect', 'Replace', 'Replatform', 'Consolidate')` —
   appears in `capability_primary_disposition_chk`,
   `capability_secondary_disposition_chk`, and
   `rationalization_capability_disposition_chk`. The two `capability`
   columns are `VARCHAR(32)`; the rat-cap column is `VARCHAR(64)`.

3. **Cascade map (what a delete propagates):**
   - `portfolio` → `rationalization_capability` (CASCADE).
   - `wave` → `rationalization_capability.wave_id` (**SET NULL**, not cascade — soft history survives).
   - `system` → `capability` (CASCADE) → `capability_business_domain` (CASCADE) and `capability_lineage` source/target (CASCADE) and `capability.parent_capability_id` self-ref (CASCADE).
   - `rationalization_capability` → `capability.rationalization_capability_id` (**SET NULL**, not cascade).
   - `application` → `shared_db_cluster.target_app_id` (CASCADE), `traceability_link.app_id` (CASCADE).
   The dangerous chain: deleting a `portfolio`/`system` mass-deletes the
   entire `capability` subtree and its lineage/domain edges.

4. **Two partial-unique natural keys on `rationalization_capability`**
   (`(portfolio_id, external_id)` live+non-null; `(portfolio_id, name)`
   live) cannot be reproduced as plain UNIQUE constraints — they are
   **partial** (`postgresql_where`) and the UPSERT logic depends on the
   exact predicate (`external_id IS NOT NULL AND retired_at IS NULL`,
   `retired_at IS NULL`). Same applies to `capability`'s
   `ix_capability_system_external_id` (`WHERE external_id IS NOT NULL`).

5. **NOT NULL with no default:**
   `rationalization_capability.description`, `.rationale`, `.evidence_refs`
   (the projector always supplies `''`/`'[]'`).
   `capability_lineage.target_capability_id` is **nullable** but
   CHECK-coupled to `relationship='dropped'`.

6. **`validated_at` is JSONB, never written** — column-name trap; and
   `traceability_link.target_version` is never written by the API path.

7. **The `index_artifact_citations` Temporal activity is a no-op stub**
   (always `0/0`, no DB write). The only writer of `traceability_link` is
   the **API** `index_citations`. The only writer of `capability` /
   `capability_business_domain` is `persist_capability_catalog` (+ split
   children from `persist_rationalization_capabilities`). The only writer
   of `rationalization_capability` is `persist_rationalization_capabilities`
   (rows) + `persist_rationalization_capability_dispositions`
   (disposition/target). The only writer of `shared_db_cluster` is
   `persist_data_side_effects`. `capability_lineage` has **no** worker
   writer in this repo.

8. **`application_disposition` is a VIEW, not a table** (created in 052,
   redefined in 058) — included for context because it reads `capability`
   + `rationalization_capability` + `system_application`. 058's redefine
   UNIONs the rat-cap grain (`rc.disposition` + target binding) with the
   capability grain (`c.primary_disposition`/`c.secondary_disposition`,
   no target binding) so apps dispositioned via either path render. The
   `target_services` / `rationalization_capability_ids` arrays come from
   the rat-cap grain only. Reproduce the view DDL **verbatim** from
   `058_application_disposition_capability_grain.py:96-137`.
