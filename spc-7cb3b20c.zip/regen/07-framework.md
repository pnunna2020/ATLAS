# 07 — Framework, Extension Points & Profiles

> ATOMIC regeneration specification. Behavioral-parity bar: an engineer with **no** access to the original code must be able to rebuild every component so it behaves identically. Logic is reproduced as structured pseudocode preserving every branch / loop / early-return / exception path. Config/override data is reproduced at field level. ⚠️ GOTCHA marks non-obvious, fragile, ordering-dependent, or determinism-sensitive code.

## Table of Contents

- **PART A — The 6 Extension Points** (this section): the shared `Registry` substrate (`engine.py`) and the six extension-point registries (`assembly_line`, `disposition`, `analysis_pass`, `scoring_dimension`, `gate_provider`, `skill_composition`), plus `profile_overrides.py`, `worker_bootstrap.py`, and the package `__init__.py`.
- **PART B — Line-to-Line Contract** (written by Phase-2 PART B): how assembly lines hand off versioned artifacts, dependency model, wave management.
- **PART C — FAA Profile** (written by Phase-2 PART C): field-level reproduction of the ENTIRE FAA profile bundle (`profile.yaml`, `compliance.yaml`, `risk-classification.yaml`, `gates.yaml`, `scoring.yaml`, `technology.yaml`, `wave-planning.yaml`, `delegation.yaml`, `objectives.yaml`, `config/*.yaml`, branding, mission context, context-priors, regulatory-knowledge), the four loaders, and the CAN-vs-CANNOT-override boundary. ⚠️ **SECTION C is SPLIT into its own file `regen/07-framework-faa-profile.md`** because of its length — see the pointer in PART C below.
- **PART D — Risk / Disposition / Gate Models** (written by Phase-2 PART D): the 3 risk tiers, 7 dispositions, 15 standard gates and their semantics.

---

# PART A — THE 6 EXTENSION POINTS

**Location:** `/Users/pnunna/Documents/GitHub/foundry/temporal/olympus_workflows/registries/`

**Files covered in this part:**

| File | Lines | Role |
| --- | --- | --- |
| `engine.py` | 453 | Shared generic registry substrate (`Registry[T]` + errors + semver helpers) |
| `assembly_line.py` | 188 | Extension Point 1 — Assembly Line Registry |
| `disposition.py` | 492 | Extension Point 2 — Disposition Strategy Registry |
| `analysis_pass.py` | 172 | Extension Point 3 — Analysis Pass Registry |
| `scoring_dimension.py` | 206 | Extension Point 4 — Scoring Dimension Registry |
| `gate_provider.py` | 408 | Extension Point 5 — Gate Provider Registry |
| `skill_composition.py` | 195 | Extension Point 6 — Skill Composition Registry |
| `profile_overrides.py` | 310 | Single profile-application seam across all six |
| `worker_bootstrap.py` | 199 | Worker-side profile activation from env + minimal YAML parser |
| `__init__.py` | 145 | Package re-export surface |

**Architectural premise (`engine.py:21-40`):** The substrate is deliberately **not** a database. Each of the six registries populates its defaults **at module import** for Temporal determinism; profile overrides apply **once at worker startup** through `apply_profile`. Entity types are **frozen dataclasses** so workflow code can pass them around without fearing mutation. Version tracking lives **alongside** entities (in a parallel dict), never **on** them, so the frozen dataclass stays source-of-truth and version bumps don't require entity field mutation.

---

## A.0 — Temporal-Determinism Model (read first)

⚠️ **GOTCHA — THE central determinism contract.** Every concrete registry is a **module-level singleton** constructed at import and immediately populated with defaults:

```python
ASSEMBLY_LINE_REGISTRY = AssemblyLineRegistry();   register_default_lines(ASSEMBLY_LINE_REGISTRY)        # assembly_line.py:186-187
DISPOSITION_REGISTRY   = DispositionStrategyRegistry(); register_default_strategies(DISPOSITION_REGISTRY) # disposition.py:490-491
ANALYSIS_PASS_REGISTRY = AnalysisPassRegistry();   register_default_passes(ANALYSIS_PASS_REGISTRY)        # analysis_pass.py:170-171
SCORING_DIMENSION_REGISTRY = ScoringDimensionRegistry(); register_default_dimensions(...)               # scoring_dimension.py:204-205
GATE_PROVIDER_REGISTRY = GateProviderRegistry();   register_default_providers(GATE_PROVIDER_REGISTRY)    # gate_provider.py:406-407
SKILL_COMPOSITION_REGISTRY = SkillCompositionRegistry()   # NO defaults — empty at import                # skill_composition.py:194
```

The determinism guarantee is **procedural, not enforced by a lock or freeze flag**: the registries are *documented and intended* to be read-only inside Temporal workflow code (`__init__.py:14-19`, `assembly_line.py:10-12`, `disposition.py:18-21`). The mechanics that make this safe:

1. **Defaults at import** — every worker process, on both first execution and replay, imports the same modules and builds identical registry contents in identical insertion order. ⚠️ The default loaders for `assembly_line` and `analysis_pass` read YAML from `olympus-contracts` at import time (`assembly_line.py:156-178`, `analysis_pass.py:116-162`); that YAML is packaged and immutable at runtime and is loaded via an `@lru_cache(maxsize=1)` in the contract loader (`olympus-contracts/.../assembly_lines.py:297`), so repeated reads are stable within a process.
2. **Profile overrides applied once at startup** — `bootstrap_profile_from_env()` runs in `run_worker` *before* the worker accepts tasks (`worker_bootstrap.py:14-16, 158-198`). No workflow code mutates a registry.
3. **No enforcement flag** — there is **no** `frozen`/`locked` boolean on `Registry`. `register`, `delete`, `clear`, `bump_version`, `set_default`, `set_gate_overrides` are all public and mutate in place. Nothing *prevents* a workflow from calling them; the contract is "don't, and the system is structured so you never need to." ⚠️ GOTCHA: A regeneration that adds a runtime guard would be *more* defensive but would break the documented `reset_registries_to_defaults` test path (which calls `__init__()` then re-registers — see A.8) and the API CRUD router. Reproduce the no-flag design.

⚠️ **GOTCHA — `VersionRecord` is a *non-frozen* `@dataclass` with a mutable `list`** (`engine.py:144-165`). It is the one mutable structure in the substrate. It is stored in `Registry._versions`, never inside the frozen entity. `bump()` mutates `self.version` and appends to `self.history`. If a workflow called `bump_version` it would be a determinism violation — but version bumps are a CRUD/API-layer concern, never a workflow-execution concern.

---

## A.1 — Shared Substrate: `engine.py`

### A.1.1 Module docstring & public surface

`__all__` (`engine.py:49-59`): `EntityExists`, `EntityHasDependents`, `EntityNotFound`, `RegistryError`, `RegistryValidationError`, `Registry`, `VersionRecord`, `bump_semver`, `parse_semver`.

⚠️ GOTCHA: `CircularDependencyError` is defined and used internally but is **deliberately omitted from `engine.__all__`** (`engine.py:91-92` vs `49-59`). It *is* re-exported from the package `__init__.py:41` / `__init__.py:129`. So `from ...engine import CircularDependencyError` would need an explicit name (it works, just not via `*`), while `from ...registries import CircularDependencyError` works.

### A.1.2 Exception hierarchy (`engine.py:67-92`)

```
RegistryError(RuntimeError)                                  # base for all engine errors (engine.py:67-68)
├── EntityExists(RegistryError)                              # register(overwrite=False) hit existing id (71-72)
├── EntityNotFound(KeyError, RegistryError)                  # get/delete/bump miss (75-80)  ⚠️ multiple-inheritance
├── EntityHasDependents(RegistryError)                       # delete would orphan a dependent (83-84)
├── RegistryValidationError(RegistryError)                   # a configured validator rejected an entity (87-88)
└── CircularDependencyError(RegistryError)                   # registration would complete a dep cycle (91-92)
```

⚠️ **GOTCHA — `EntityNotFound` inherits from BOTH `KeyError` and `RegistryError`** (`engine.py:75`). Intentional: legacy callers that used the raw dict-lookup idiom (`registry[x]` → `KeyError`) keep working. **Every concrete registry subclasses `EntityNotFound` for its own "unknown X" error** (`UnknownAssemblyLineError`, `UnknownDispositionError`, `UnknownAnalysisPassError`, `UnknownGateProviderError`, `UnknownSkillCompositionError`), so each of those is *also* a `KeyError`. Catch order matters: catching `KeyError` will catch these.

⚠️ **GOTCHA — `KeyError.__str__` adds quotes.** Because `EntityNotFound` subclasses `KeyError`, when raised with a string message and stringified by `str(exc)`, Python's `KeyError.__str__` wraps the message in `repr()` (adds surrounding quotes). The concrete registries that do `raise UnknownXError(str(exc))` (e.g. `assembly_line.py:139`, `analysis_pass.py:107`) therefore re-wrap an already-quoted message. Reproduce the message text exactly as the code produces it, including this double-quoting where it occurs.

### A.1.3 Semver helpers

**`parse_semver(value: str) -> tuple[int, int, int]`** (`engine.py:100-123`):

```
raw = value.strip().lstrip("vV")            # strip whitespace then leading v/V chars
for sep in ("-", "+"):                       # strip prerelease/build metadata, "-" first then "+"
    if sep in raw:
        raw = raw.split(sep, 1)[0]
parts = raw.split(".")
if len(parts) != 3:
    raise ValueError("Invalid semver {value!r} — expected 'X.Y.Z'")
try:
    major, minor, patch = (int(p) for p in parts)
except ValueError as exc:
    raise ValueError("Invalid semver {value!r} — non-integer component") from exc
if any(c < 0 for c in (major, minor, patch)):
    raise ValueError("Invalid semver {value!r} — negative component")
return (major, minor, patch)
```
⚠️ GOTCHA: `lstrip("vV")` strips **all** leading `v`/`V` characters (so `"vv1.0.0"` → `"1.0.0"`), not just one — it's a character set, not a prefix. ⚠️ GOTCHA: a `-` is stripped *before* `+`, and only the segment *before* the first separator survives, so `"1.2.3-rc.1+build"` → `"1.2.3"`. ⚠️ Negative components are caught only *after* int-parsing succeeds (so `"-1.0.0"` becomes `parts=["", "1", "0", "0"]`? No — `"-1.0.0".lstrip("vV")` = `"-1.0.0"`, then `-` is in raw → `raw.split("-",1)[0]` = `""`, so `parts=[""]`, `len != 3` → "expected 'X.Y.Z'". So a leading minus never reaches the negative check via this path; the negative check guards components produced by int() that are themselves negative, which after the `-`-split can't happen — it is effectively dead for normal inputs but reproduce it verbatim.)

**`bump_semver(current: str, kind: str) -> str`** (`engine.py:126-141`):

```
major, minor, patch = parse_semver(current)
k = kind.lower()
if k == "major": return f"{major+1}.0.0"     # zeroes minor & patch
if k == "minor": return f"{major}.{minor+1}.0" # zeroes patch
if k == "patch": return f"{major}.{minor}.{patch+1}"
raise ValueError("Unknown semver kind {kind!r} — want major|minor|patch")
```
⚠️ `kind` is lowercased, so `"MAJOR"` works.

**`VersionRecord`** dataclass (`engine.py:144-165`) — **not** frozen:

```
@dataclass
class VersionRecord:
    version: str = "1.0.0"
    history: list[str] = field(default_factory=list)
    def __post_init__():
        parse_semver(self.version)          # eager validation — bad seed raises ValueError at construction
        if not self.history:
            self.history = [self.version]   # ⚠️ history seeded with initial version iff empty
    def bump(kind) -> str:
        new = bump_semver(self.version, kind)
        self.version = new
        self.history.append(new)            # append-only audit trail
        return new
```

### A.1.4 The `Registry[T]` generic class (`engine.py:181-453`)

Type aliases (`engine.py:173-178`): `T = TypeVar("T")`; `IdExtractor = Callable[[T], str]`; `DepExtractor = Callable[[T], Iterable[str]]`; `Validator = Callable[[T], None]`.

**Constructor** (`engine.py:200-213`):

```
def __init__(self, *, id_getter, dep_getter=None, validators=None, case_sensitive=False):
    self._id_getter   = id_getter
    self._dep_getter  = dep_getter or (lambda _e: ())     # default: no dependencies
    self._validators  = list(validators or ())            # copied into a list
    self._case_sensitive = case_sensitive                 # default False ⇒ ids lower-cased
    self._entities: dict[str, T] = {}                     # canonical-key → entity (INSERTION-ORDERED)
    self._versions: dict[str, VersionRecord] = {}         # canonical-key → version record
```

⚠️ **GOTCHA — all constructor args are keyword-only** (note the `*` at `engine.py:202`). Every concrete registry constructs `Registry(id_getter=..., dep_getter=..., validators=[...])` accordingly.

**Data structures:** two parallel dicts keyed by the *canonical* (normalised) id. `dict` preserves insertion order (Python 3.7+), and the registry relies on that for `list_all`/`ids`/`labels`/iteration determinism.

**Normalisation** (`engine.py:219-223`):
```
_key(entity_id)  = entity_id if self._case_sensitive else entity_id.lower()
_id_of(entity)   = self._key(self._id_getter(entity))
```

**Validation hooks** (`engine.py:229-250`):
```
add_validator(validator):  self._validators.append(validator)   # appended; runs on every subsequent register
validate(entity):
    entity_id = self._id_getter(entity)        # ⚠️ RAW id (not normalised) — used only for the error message
    for validator in self._validators:         # in registration order
        try:
            validator(entity)
        except RegistryValidationError:
            raise                               # ⚠️ re-raised AS-IS (no re-wrap)
        except Exception as exc:
            raise RegistryValidationError(
                f"Validator {validator.__name__!r} rejected {entity_id!r}: {exc}"
            ) from exc                          # ANY other exception → wrapped w/ validator name + entity id
```
⚠️ GOTCHA: validators may raise *any* exception type; the engine normalises everything **except** `RegistryValidationError` into a `RegistryValidationError` carrying `validator.__name__`. A validator that itself raises `RegistryValidationError` passes through unchanged (so its message is preserved verbatim — `skill_composition`'s presence validator relies on this, A.7).

**`register`** (`engine.py:256-303`) — the heart of the substrate:
```
def register(entity, *, overwrite=True, version=None):
    self.validate(entity)                         # 1. validate FIRST (raises before any state change)
    key = self._id_of(entity)                     # 2. compute canonical key

    if not overwrite and key in self._entities:   # 3. overwrite guard
        raise EntityExists(
            f"Registry already contains {self._id_getter(entity)!r}. Pass overwrite=True to replace.")

    previous          = self._entities.get(key)   # 4. snapshot for rollback
    previous_version  = self._versions.get(key)
    self._entities[key] = entity                  # 5. STAGE the entity
    try:
        self._assert_no_cycle(key)                # 6. cycle check AFTER staging
    except CircularDependencyError:
        if previous is None:                      #    rollback: brand-new key → delete it
            del self._entities[key]
        else:                                     #    rollback: existing key → restore prior entity
            self._entities[key] = previous
        raise                                     #    re-raise the cycle error

    if version is not None:                        # 7. version handling
        self._versions[key] = VersionRecord(version=version)   # explicit seed (replaces any prior)
    elif previous_version is None:
        self._versions[key] = VersionRecord()      # fresh 1.0.0 for a new entity
    # else: keep existing version record across an overwrite  ⚠️ (no reset on overwrite)
```
⚠️ **GOTCHA — default `overwrite=True`**: "later registrations win." Profile overrides and re-imports depend on this (`engine.py:264-268`). The strict CRUD path passes `overwrite=False`.
⚠️ **GOTCHA — staging-then-rollback ordering**: the entity is inserted into `_entities` *before* cycle detection, then removed/restored on failure. This is required because `_assert_no_cycle` walks `self._entities` and must see the new edge to detect a cycle it would create. A rejected registration leaves `_entities` byte-for-byte as it was, but note the version dict is only touched in step 7 which is *after* the rollback, so a cycle failure never creates a stray VersionRecord.
⚠️ **GOTCHA — version preserved across overwrite**: re-registering an existing id with `version=None` does **not** reset its `VersionRecord`; the prior record (and its history) survives.

**`upsert`** (`engine.py:305-307`): `register(entity, overwrite=True, version=version)`. Every concrete registry's `register()` delegates to `upsert()` (so concrete `register` is always overwrite-true).

**`get`** (`engine.py:309-316`):
```
try: return self._entities[self._key(entity_id)]
except KeyError:
    known = ", ".join(sorted(self._entities)) or "<none>"
    raise EntityNotFound(f"No entity registered for {entity_id!r}. Known: {known}") from exc
```
⚠️ The "Known:" list is the **sorted canonical (lower-cased) keys**, not the labels.

**`has`** (`engine.py:318-319`): `self._key(entity_id) in self._entities`.

**`list_all`** (`engine.py:321-323`): `list(self._entities.values())` — **insertion order**.

**`ids`** (`engine.py:325-327`): `list(self._entities.keys())` — canonical (lower-cased unless case-sensitive).

**`labels`** (`engine.py:329-331`): `[self._id_getter(e) for e in self._entities.values()]` — **original casing** as each entity reports it.

**`delete`** (`engine.py:333-354`):
```
key = self._key(entity_id)
if key not in self._entities:
    raise EntityNotFound(f"No entity registered for {entity_id!r}")
dependents = self.dependents(entity_id)
if dependents:
    raise EntityHasDependents(
        f"Cannot delete {entity_id!r}: depended on by {', '.join(sorted(dependents))}")
removed = self._entities.pop(key)
self._versions.pop(key, None)               # version record dropped too (None-safe)
return removed                              # returned for audit
```
⚠️ GOTCHA: dependent check uses *original-casing* dependent labels (via `dependents()`, which returns `self._id_getter(other)` values — see below), sorted, in the error message.

**`clear`** (`engine.py:356-359`): empties both `_entities` and `_versions`.

**Versioning** (`engine.py:365-387`):
```
version(entity_id):
    key = _key(entity_id)
    if key not in _versions:
        if key not in _entities: raise EntityNotFound(...)
        _versions[key] = VersionRecord()         # lazily create on first query for a record-less entity
    return _versions[key].version
version_history(entity_id):
    self.version(entity_id)                       # ensures record exists / raises
    return list(self._versions[self._key(entity_id)].history)   # COPY
bump_version(entity_id, kind):
    key = _key(entity_id)
    if key not in _entities: raise EntityNotFound(...)
    record = _versions.setdefault(key, VersionRecord())
    return record.bump(kind)
```

**Dependencies** (`engine.py:393-438`):
```
dependencies(entity_id):
    entity = self.get(entity_id)                  # raises EntityNotFound if missing
    return [self._id_getter_of_dep(d) for d in self._dep_getter(entity)]   # dep ids AS DECLARED (no normalise)
_id_getter_of_dep(raw_id): return raw_id          # identity — downstream may normalise

dependents(entity_id) -> set[str]:               # reverse edges
    needle = self._key(entity_id)
    hits = set()
    for other_key, other in self._entities.items():
        if other_key == needle: continue          # skip self
        for dep in self._dep_getter(other):
            if self._key(dep) == needle:           # case-insensitive compare on dep
                hits.add(self._id_getter(other))   # ⚠️ add ORIGINAL-CASING label, not canonical key
                break
    return hits

_assert_no_cycle(start_key):                      # DFS for a cycle reachable from start_key
    visiting = set(); visited = set()
    def visit(key):
        if key in visited: return
        if key in visiting: raise CircularDependencyError(f"Circular dependency detected involving {key!r}")
        visiting.add(key)
        entity = self._entities.get(key)
        if entity is not None:
            for dep in self._dep_getter(entity):
                dep_key = self._key(dep)
                if dep_key in self._entities:      # ⚠️ only follow deps that ARE registered (dangling deps ignored)
                    visit(dep_key)
        visiting.remove(key)
        visited.add(key)
    visit(start_key)
```
⚠️ **GOTCHA — dangling dependencies are tolerated.** `_assert_no_cycle` and the cycle traversal only recurse into dependency ids that exist in `_entities` (`engine.py:433`). A line that `depends_on` an unregistered line registers fine; the missing edge is simply not walked. This is why assembly-line and analysis-pass registration order doesn't matter for cycle purposes — but it also means a typo'd dependency is silently accepted at the engine level (concrete validators may still object).
⚠️ **GOTCHA — `dependents()` returns labels, `_assert_no_cycle` works in keys.** Keep this straight: deletion's "depended on by …" message lists *labels*; the cycle message names a *key*.

**Dunder helpers** (`engine.py:444-453`):
```
__iter__   → iter(self._entities.values())        # iterate entities in insertion order
__len__    → len(self._entities)
__contains__(x) → False if not isinstance(x, str) else self.has(x)   # ⚠️ non-str → False, never raises
```

---

## A.2 — Extension Point 1: Assembly Line Registry (`assembly_line.py`)

**What an extension registers:** an `AssemblyLine` frozen dataclass. **Registration mechanism:** profile-driven / programmatic `register()` (no decorator). Defaults are loaded from contract YAML at import.

### A.2.1 Contract dataclass `AssemblyLine` (`assembly_line.py:41-60`)
```
@dataclass(frozen=True)
class AssemblyLine:
    name: str
    description: str = ""
    steps: tuple[str, ...] = ()           # ordered step ids
    gates: tuple[str, ...] = ()           # gate ids the line owns (e.g. "G-DC")
    depends_on: tuple[str, ...] = ()      # upstream line names
    inputs: tuple[str, ...] = ()          # consumed artifact ids
    outputs: tuple[str, ...] = ()         # produced artifact ids
    mode: str = "per-app"
    metadata: dict[str, object] = field(default_factory=dict)
```

### A.2.2 Validator `_validate_assembly_line` (`assembly_line.py:72-86`)
```
_VALID_MODES = frozenset({"per-app", "per-wave", "per-target-app", "continuous"})   # line 72

def _validate_assembly_line(line):
    if not line.name.strip(): raise ValueError("AssemblyLine.name must not be empty")
    if line.mode not in _VALID_MODES:
        raise ValueError(f"AssemblyLine.mode={line.mode!r} not in {sorted(_VALID_MODES)}")
    if len(set(line.depends_on)) != len(line.depends_on):     # ⚠️ duplicate deps rejected (no silent dedupe)
        raise ValueError(f"AssemblyLine {line.name!r} has duplicate depends_on entries")
```
⚠️ Duplicate `depends_on` entries are a hard error, *not* deduped — "silent dedupe would hide profile bugs" (`assembly_line.py:82`).

### A.2.3 The interface — `AssemblyLineRegistry` (`assembly_line.py:94-149`)
A **thin wrapper** around `Registry[AssemblyLine]` exposing legacy method names. ⚠️ GOTCHA: this is the recurring pattern for 5 of the 6 registries — they **compose** (not inherit) `Registry`, holding it as `self._engine`, and translate `EntityNotFound` into a domain-specific subclass.

```
__init__():
    self._engine = Registry[AssemblyLine](
        id_getter   = lambda line: line.name,
        dep_getter  = lambda line: line.depends_on,
        validators  = [_validate_assembly_line])

register(line)      → self._engine.upsert(line)                    # idempotent, later wins
get(name)           → try self._engine.get(name)
                      except EntityNotFound: raise UnknownAssemblyLineError(
                          f"No assembly line registered for {name!r}. Known lines: {<sorted ids or '<none>'>}")
has(name)           → self._engine.has(name)
list_all()          → self._engine.list_all()
labels()            → self._engine.labels()
delete(name)        → try self._engine.delete(name)
                      except EntityHasDependents: raise            # ⚠️ re-raised UNWRAPPED (engine type leaks)
                      except EntityNotFound: raise UnknownAssemblyLineError(str(exc))
version(name)       → self._engine.version(name)
bump_version(name,kind) → self._engine.bump_version(name, kind)
dependents(name)    → self._engine.dependents(name)
```
⚠️ **GOTCHA — `delete` re-raises `EntityHasDependents` as-is** (`assembly_line.py:136-137`) but converts `EntityNotFound` to `UnknownAssemblyLineError`. So callers see two different exception types from one method.

`UnknownAssemblyLineError(EntityNotFound)` (`assembly_line.py:63-64`).

### A.2.4 Default population from contract (`assembly_line.py:156-187`)
```
def _load_default_lines_from_contract() -> tuple[AssemblyLine, ...]:
    from olympus_contracts import list_lines as _contract_lines
    return tuple(
        AssemblyLine(
            name        = line.name,
            description = line.description,
            steps       = line.step_ids(),                 # ordered step ids
            gates       = tuple(g.id for g in line.gates), # GateRef.id list
            depends_on  = line.depends_on,
            inputs      = line.inputs,
            outputs     = line.outputs,
            mode        = line.mode,
        ) for line in _contract_lines()                    # contract loader returns lines sorted by name
    )

_DEFAULT_LINES = _load_default_lines_from_contract()        # module-level, evaluated at import
def register_default_lines(registry): for line in _DEFAULT_LINES: registry.register(line)
ASSEMBLY_LINE_REGISTRY = AssemblyLineRegistry(); register_default_lines(ASSEMBLY_LINE_REGISTRY)
```
⚠️ **GOTCHA — single source of truth is the YAML, not this file.** Editing the assembly-line YAML changes the registry defaults at next import. The 10 contract files are: `architecture.yaml`, `data.yaml`, `deployment.yaml`, `discovery.yaml`, `disposition-execution.yaml`, `governance.yaml`, `modernization.yaml`, `rationalization.yaml`, `sustainment.yaml`, `validation.yaml` (`olympus-contracts/olympus_contracts/data/assembly-lines/`). The contract loader (`list_lines`, `assembly_lines.py:335-337`) returns them **sorted by `dict` insertion**, which is alphabetical-by-filename because `_load_all` iterates `sorted(data_root.iterdir(), key=lambda p: p.name)` (`assembly_lines.py:306`) and skips files that don't end `.yaml` or that start with `_`. Insertion order of the registry is therefore alphabetical by filename. (Full line-by-line YAML content is owned by Phase 1 / PART B.)

### A.2.5 WORKED EXAMPLE — Discovery line as registered
From `discovery.yaml` (`name: Discovery`, `G-DC` gate), after `_load_default_lines_from_contract` the registry holds an `AssemblyLine(name="Discovery", gates=("G-DC",), mode=..., steps=("catalog", "structural-analysis", "business-logic-extraction", "quality-risk-assessment", "ux-accessibility-assessment", "data-domain-discovery", "shared-database-analysis", "capability-extraction", "synthesis", "tco-baseline", "commit-artifacts", "create-pr", "gate-readiness-check", "gate-review", ...))` (step ids verified from `discovery.yaml` lines 42-649). Lookup: `ASSEMBLY_LINE_REGISTRY.get("discovery")` (case-insensitive) returns it; `.labels()` returns `["Discovery", ...]` preserving the capital D.

---

## A.3 — Extension Point 2: Disposition Strategy Registry (`disposition.py`)

**What an extension registers:** a `DispositionStrategy` frozen dataclass (which contains a tuple of `StepSpec`). **Registration mechanism:** programmatic `register()`; five built-ins registered at import. ⚠️ This is the **pilot** extension point (`disposition.py:31-33`) and the only one whose registry is read by a workflow at run time today (`temporal/.../workflows/disposition.py`).

### A.3.1 `StepSpec` (`disposition.py:52-63`)
```
@dataclass(frozen=True)
class StepSpec:
    step: str        # the agent-dispatched activity name
    skill_id: str    # skill the agent loads
    artifact: str    # artifact file committed to the Git branch
```

### A.3.2 `DispositionStrategy` (`disposition.py:66-149`)
```
@dataclass(frozen=True)
class DispositionStrategy:
    label: str                                    # canonical — "Retire","Retain",etc.
    pre_gate1_steps:  tuple[StepSpec, ...]         # run BEFORE plan approval (G-DE-1)
    post_gate1_steps: tuple[StepSpec, ...]         # run between G-DE-1 and G-DE-2
    has_gate2: bool                                # False for Retain (no decommission phase)
    max_rework_iterations: int = 3
    workflow: str = "DispositionWorkflow"          # P4-S5.3 — Temporal workflow id that owns it
    required_gates: tuple[str, ...] = ()           # P4-S5.3 — explicit gate enumeration
    metadata: dict[str, object] = field(default_factory=dict)
```
Properties / methods:
- `has_gate1` (property, `disposition.py:102-111`) → **always returns `True`** (every current strategy uses G-DE-1; a future no-plan-gate strategy would override).
- `title_label` (property, `113-121`) → alias for `label` (matches pre-registry `DispositionSpec` field name for drop-in refactor).
- `steps` (property, `123-126`) → `pre_gate1_steps + post_gate1_steps` (full ordered list).
- `skills` (property, `128-131`) → `{s.step: s.skill_id for s in self.steps}`. ⚠️ Dict comprehension over ordered steps; duplicate `step` names would collapse (none do).
- `effective_required_gates() -> tuple[str, ...]` (`133-149`):
  ```
  if self.required_gates: return self.required_gates       # explicit wins
  gates = []
  if self.has_gate1: gates.append("G-DE-1")                # always true ⇒ always present
  if self.has_gate2: gates.append("G-DE-2")
  return tuple(gates)
  ```
  ⚠️ For the five built-ins (none set `required_gates`), this derives `("G-DE-1","G-DE-2")` for all except Retain → `("G-DE-1",)`.

### A.3.3 Validator `_validate_disposition` (`disposition.py:166-176`)
```
if not strategy.label.strip(): raise ValueError("DispositionStrategy.label must not be empty")
if strategy.max_rework_iterations < 0: raise ValueError(f"max_rework_iterations for {label!r} must be >= 0")
if not strategy.workflow.strip(): raise ValueError(f"DispositionStrategy {label!r} must name a workflow")
```

### A.3.4 `DispositionStrategyRegistry` (`disposition.py:179-243`)
Wrapper over `Registry[DispositionStrategy]` with `id_getter=lambda s: s.label`, `dep_getter=lambda _s: ()` (**dispositions have no inter-deps** — `disposition.py:190`), `validators=[_validate_disposition]`. Methods: `register`→upsert; `get` (raises `UnknownDispositionError` with "Known strategies: …"); `list_all`; `labels`; `has`; `delete` (`EntityNotFound`→`UnknownDispositionError(str(exc))`, but does **not** specially re-raise `EntityHasDependents` since deps are empty); `version`; `bump_version`.

`UnknownDispositionError(EntityNotFound)` (`disposition.py:157-163`) — also a `KeyError`; doc note (`disposition.py:159-162`) flags this is intentional for legacy `.get(label)`→`None` callers migrating.

⚠️ **GOTCHA — Retire is NOT a safe default.** `get()` on an unknown label *raises* rather than returning a default (`disposition.py:203-218`, doc `28-29`). Decommissioning is destructive; unknown dispositions must fail loudly.

⚠️ **GOTCHA — Refactor & Rearchitect are intentionally absent.** Only the **five non-modernization** dispositions are registered (`disposition.py:9-14, 474-484`). Refactor/Rearchitect flow through `ModernizationWorkflow`, and `DispositionWorkflow` short-circuits them *before* registry lookup. A regeneration that registers all seven here would change behavior — do not.

### A.3.5 The five default strategies (FIELD-LEVEL — `disposition.py:261-471`)

⚠️ These mirror the pre-registry `DispositionSpec` constants exactly; "any behavior difference is a bug" (`disposition.py:250-252`). Reproduce verbatim. All have `has_gate2` as noted; none set `workflow`/`required_gates`/`max_rework_iterations` (so defaults `"DispositionWorkflow"`, `()`, `3` apply).

**`_RETIRE`** (`label="Retire"`, `has_gate2=True`):
| phase | step | skill_id | artifact |
|---|---|---|---|
| pre_gate1 | `user-transition-plan` | `user-transition-planning` | `user-transition-plan.json` |
| pre_gate1 | `data-archival-plan` | `data-archival-planning` | `data-archival-plan.json` |
| post_gate1 | `consumer-migration` | `consumer-migration-planning` | `consumer-migration.json` |
| post_gate1 | `infrastructure-decommission` | `legacy-decommission` | `infrastructure-decommission.json` |
| post_gate1 | `security-decommission` | `security-decommission` | `security-decommission.json` |
| post_gate1 | `license-reclamation` | `license-reclamation` | `license-reclamation.json` |
| post_gate1 | `cost-savings-certification` | `tco-analyzer` | `cost-savings-certification.json` |

**`_RETAIN`** (`label="Retain"`, `has_gate2=False`, `post_gate1_steps=()`):
| phase | step | skill_id | artifact |
|---|---|---|---|
| pre_gate1 | `security-remediation` | `security-remediation-planning` | `security-remediation.json` |
| pre_gate1 | `documentation-update` | `documentation-remediation` | `documentation-update.json` |
| pre_gate1 | `test-coverage` | `test-coverage-uplift` | `test-coverage.json` |
| pre_gate1 | `monitoring-setup` | `monitoring-bootstrap` | `monitoring-setup.json` |
| pre_gate1 | `sustainment-handoff` | `sustainment-handoff` | `sustainment-handoff.json` |

**`_REPLACE`** (`label="Replace"`, `has_gate2=True`):
| phase | step | skill_id | artifact |
|---|---|---|---|
| pre_gate1 | `requirements-derivation` | `requirements-derivation` | `requirements.json` |
| pre_gate1 | `vendor-evaluation` | `vendor-evaluation` | `vendor-selection.json` |
| pre_gate1 | `integration-specification` | `integration-specification` | `integration-specification.json` |
| post_gate1 | `data-migration` | `data-migration-planning` | `data-migration.json` |
| post_gate1 | `user-transition` | `user-adoption-coordinator` | `user-transition.json` |
| post_gate1 | `legacy-decommission` | `legacy-decommission` | `decommission-certificate.json` |

**`_REPLATFORM`** (`label="Replatform"`, `has_gate2=True`):
| phase | step | skill_id | artifact |
|---|---|---|---|
| pre_gate1 | `platform-selection` | `platform-selection` | `platform-selection.json` |
| pre_gate1 | `workflow-mapping` | `workflow-mapping` | `workflow-mapping.json` |
| post_gate1 | `component-configuration` | `component-configuration` | `component-configuration.json` |
| post_gate1 | `data-migration` | `data-migration-planning` | `data-migration.json` |
| post_gate1 | `user-training` | `user-adoption-coordinator` | `user-training.json` |
| post_gate1 | `validation-cutover` | `validation-cutover` | `validation-cutover.json` |
| post_gate1 | `legacy-decommission` | `legacy-decommission` | `decommission-certificate.json` |

**`_CONSOLIDATE`** (`label="Consolidate"`, `has_gate2=True`):
| phase | step | skill_id | artifact |
|---|---|---|---|
| pre_gate1 | `target-selection` | `target-selection` | `target-selection.json` |
| pre_gate1 | `feature-gap-analysis` | `feature-gap-analysis` | `feature-gap.json` |
| pre_gate1 | `enhancement-planning` | `enhancement-planning` | `enhancement-plan.json` |
| post_gate1 | `data-reconciliation` | `data-reconciliation-planning` | `data-reconciliation.json` |
| post_gate1 | `user-migration` | `user-adoption-coordinator` | `user-migration.json` |
| post_gate1 | `absorbed-decommission` | `legacy-decommission` | `decommission-certificate.json` |

`_DEFAULT_STRATEGIES = (_RETIRE, _RETAIN, _REPLACE, _REPLATFORM, _CONSOLIDATE)` (`disposition.py:465-471`) — **this is the insertion order** → `labels()` and `list_all()` return them in this order. `register_default_strategies` loops and registers each (`474-484`). Singleton `DISPOSITION_REGISTRY` built + populated at import (`490-491`).

### A.3.6 WORKED EXAMPLE — real consumer
`temporal/olympus_workflows/workflows/disposition.py` imports `DISPOSITION_REGISTRY` and calls `.get(label)` to obtain `self._spec`, then reads `_spec.pre_gate1_steps`, `_spec.post_gate1_steps`, `_spec.has_gate2`, `_spec.max_rework_iterations`, `_spec.title_label`. (Workflow behavior is detailed in Phase 3.) The field names on `DispositionStrategy` were chosen to be drop-in identical to the pre-registry `DispositionSpec` so the workflow refactor was "pure indirection with zero behavior change" (`disposition.py:79-82`).

---

## A.4 — Extension Point 3: Analysis Pass Registry (`analysis_pass.py`)

**What an extension registers:** an `AnalysisPass` frozen dataclass. **Registration mechanism:** programmatic; defaults derived from `discovery.yaml` at import. Discovery fan-out dispatches one work unit per registered pass.

### A.4.1 `AnalysisPass` (`analysis_pass.py:34-50`)
```
@dataclass(frozen=True)
class AnalysisPass:
    name: str
    skill_id: str
    artifact: str
    depends_on: tuple[str, ...] = ()
    pass_number: int = 0               # P4-S5.4 — deterministic ordering tiebreaker
    synthesis_rule: str = "synthesis"  # "none" only for the synthesis pass itself (it IS the synthesis)
    parallel_with: tuple[str, ...] = ()# informational fan-out hint
    metadata: dict[str, object] = field(default_factory=dict)
```

### A.4.2 Validator `_validate_analysis_pass` (`analysis_pass.py:57-67`)
```
if not pass_.name.strip():     raise ValueError("AnalysisPass.name must not be empty")
if not pass_.skill_id.strip(): raise ValueError(f"AnalysisPass {name!r} must declare a skill_id")
if not pass_.artifact.strip(): raise ValueError(f"AnalysisPass {name!r} must declare an artifact")
if pass_.pass_number < 0:      raise ValueError(f"AnalysisPass {name!r} pass_number must be >= 0")
```

### A.4.3 `AnalysisPassRegistry` (`analysis_pass.py:70-113`)
Wrapper over `Registry[AnalysisPass]` (`id_getter=lambda p: p.name`, `dep_getter=lambda p: p.depends_on`, `validators=[_validate_analysis_pass]`). Methods: `register`→upsert; `get`→`UnknownAnalysisPassError` ("Known: …"); `has`; `list_all`; `names()`→`labels()`; `delete` (re-raises `EntityHasDependents`, converts `EntityNotFound`→`UnknownAnalysisPassError(str(exc))` — same dual-exception shape as assembly_line); `version`; `bump_version`. `UnknownAnalysisPassError(EntityNotFound)` (`analysis_pass.py:53-54`).

### A.4.4 Default derivation from `discovery.yaml` (`analysis_pass.py:116-171`) — ⚠️ NON-OBVIOUS LOGIC
```
def _load_default_passes_from_contract() -> tuple[AnalysisPass, ...]:
    from olympus_contracts import get_line
    line = get_line("Discovery")
    passes = []
    for step in line.evidence_steps():               # only kind=="agent" AND role in ("analysis","rollup")
        if not step.skills: continue                 # skip steps with no skills
        artifact = step.artifact_filename or (
            f"{step.outputs.artifacts[0]}.json" if step.outputs.artifacts else f"{step.id}.json")
        summary_step = line.summary_step()            # the single step with summary:true (or None)
        is_terminal = step.summary or (
            summary_step is not None and summary_step.id in step.parallel_with)
        # translate input artifact names → producer step ids, deduped
        producers = []; seen = set()
        for artifact_name in step.inputs.artifacts:
            for producer in line.evidence_steps():
                if artifact_name in producer.outputs.artifacts and producer.id not in seen:
                    producers.append(producer.id); seen.add(producer.id)
        passes.append(AnalysisPass(
            name           = step.id,
            skill_id       = step.skills[0],          # ⚠️ FIRST skill only
            artifact       = artifact,
            depends_on     = tuple(producers),
            pass_number    = step.sequence,
            synthesis_rule = "none" if is_terminal else "synthesis",
            parallel_with  = step.parallel_with))
    return tuple(passes)
```
⚠️ **GOTCHA — artifact fallback chain:** `step.artifact_filename` → else first declared output artifact + `".json"` → else `"{step.id}.json"`.
⚠️ **GOTCHA — terminal detection:** a pass is terminal (`synthesis_rule="none"`) if it *is* the summary step OR it runs `parallel_with` the summary step. In Discovery, `synthesis` has `summary: true` and `tco-baseline` declares `parallel_with: [synthesis]`, while `synthesis` declares `parallel_with: [tco-baseline]` — so **both** synthesis and tco-baseline become terminal (`synthesis_rule="none"`). Reproduce this symmetry.
⚠️ **GOTCHA — `skill_id = step.skills[0]`:** only the first skill of a multi-skill step is recorded as the pass's skill (e.g. Discovery `synthesis` has `skills: [discovery-synthesizer, srs-from-discovery]` → pass records `discovery-synthesizer`).
⚠️ **GOTCHA — dependencies reconstructed from artifact wiring:** `depends_on` is built by reverse-mapping each input artifact name to the producer step that lists it in its outputs, deduping by producer id, preserving first-seen order. This is O(passes²) and runs at import.
⚠️ **GOTCHA — only `evidence_steps` become passes:** `git`-kind steps (`commit-artifacts`, `create-pr`), the `gate-review` step, and the `pre-review` `gate-readiness-check` are excluded (their `kind`/`role` fail the `evidence_steps` filter, `assembly_lines.py:182-185`). `commit-artifacts`/`create-pr` also have `skills: []` so they'd be skipped anyway.

`_DEFAULT_PASSES = _load_default_passes_from_contract()`; `register_default_passes` loops; `ANALYSIS_PASS_REGISTRY` built + populated at import (`analysis_pass.py:162-171`).

### A.4.5 WORKED EXAMPLE — `catalog` pass
Discovery step `catalog` (`kind: agent`, `sequence: 1`, `skills: [catalog-application]`, `artifact_filename: catalog.json`, `parallel_with: []`) becomes `AnalysisPass(name="catalog", skill_id="catalog-application", artifact="catalog.json", depends_on=(...derived...), pass_number=1, synthesis_rule="synthesis", parallel_with=())`. `ANALYSIS_PASS_REGISTRY.get("catalog")` returns it; `.names()` lists `"catalog"` among the evidence-step ids.

---

## A.5 — Extension Point 4: Scoring Dimension Registry (`scoring_dimension.py`)

**What an extension registers:** a `ScoringDimensionEntry`. **Registration mechanism:** programmatic; FAA profile overrides the weight set wholesale. ⚠️ This registry is **`case_sensitive=True`** (the only one) — dimension names are canonical ids (`scoring_dimension.py:79-80`).

### A.5.1 `ScoringDimensionEntry` (`scoring_dimension.py:31-48`)
```
@dataclass(frozen=True)
class ScoringDimensionEntry:
    name: str
    weight: float
    default_weight: float | None = None
    rationale: str = ""
    data_source: str = ""
    scoring_function: str = ""
    bounds: tuple[float, float] = (0.0, 1.0)
    metadata: dict[str, object] = field(default_factory=dict)
```

### A.5.2 Validator `_validate_scoring_dimension` (`scoring_dimension.py:51-64`)
```
if not dim.name.strip():        raise ValueError("ScoringDimensionEntry.name must not be empty")
if dim.weight < 0:              raise ValueError(f"Dimension {name!r} weight must be >= 0")
if dim.weight > 1.0 + 1e-6:     raise ValueError(f"Dimension {name!r} weight {weight} exceeds 1.0")
low, high = dim.bounds
if low > high:                  raise ValueError(f"Dimension {name!r} bounds {bounds} invalid (low > high)")
```
⚠️ Per-dimension weight ceiling check uses a `1e-6` tolerance (`weight > 1.0 + 1e-6`).

### A.5.3 `ScoringDimensionRegistry` (`scoring_dimension.py:67-151`) — has extra surface
Wrapper over `Registry[ScoringDimensionEntry]` with `case_sensitive=True`, `validators=[_validate_scoring_dimension]` (**no `dep_getter`** — dimensions have no deps).

⚠️ **GOTCHA — weight-sum is NOT enforced on individual `register`** (`scoring_dimension.py:70-74`). Intermediate states during a bulk override may be off-total. Sum is enforced only by `replace_all` / `validate_weights` / `validate_ready`.

Extra methods beyond the standard wrapper:
- `clear()` → `self._engine.clear()` (used by profile overrides that swap the full set).
- `replace_all(dimensions: list)` (`scoring_dimension.py:90-106`) — **atomic swap with sum validation**:
  ```
  total = sum(d.weight for d in dimensions)
  if not math.isclose(total, 1.0, abs_tol=1e-3):
      raise ValueError(f"ScoringDimension weights must sum to 1.0 (got {total:.4f})")
  for d in dimensions: _validate_scoring_dimension(d)      # validate ALL up front (reject whole batch)
  self._engine.clear()
  for d in dimensions: self._engine.upsert(d)
  ```
  ⚠️ Validates the **whole batch before mutating** so a single bad entry can't leave a half-populated registry. The sum check (`abs_tol=1e-3`) runs *before* per-entry validation.
- `get(name) -> ScoringDimensionEntry | None` (`108-112`) — ⚠️ **returns `None` on miss** (catches `EntityNotFound`), unlike every other registry's `get` which raises. Reproduce this divergence.
- `list_all`; `names()`→`labels()`; `delete` (`EntityNotFound`→**plain `KeyError(str(exc))`**, not a domain error — `120-124`); `version`; `bump_version`.
- `total_weight()` → `sum(d.weight for d in self._engine.list_all())` (`132-133`).
- `validate_weights()` (`135-141`) → raise `ValueError(f"... (got {total:.4f})")` unless `math.isclose(total, 1.0, abs_tol=1e-3)`.
- `validate_ready()` (`143-151`) → currently just calls `validate_weights()` (separate surface for future required-dimension checks).

### A.5.4 The 6 default dimensions (FIELD-LEVEL — `scoring_dimension.py:154-197`)
⚠️ All six default `bounds=(0.0,1.0)`, `rationale=""`. Weights sum to exactly `0.20+0.15+0.20+0.10+0.15+0.20 = 1.00`.

| # | name | weight | default_weight | data_source | scoring_function |
|---|---|---|---|---|---|
| 1 | `code-quality` | 0.20 | 0.20 | `discovery-pass-3` | `weighted_linter_score` |
| 2 | `test-coverage` | 0.15 | 0.15 | `discovery-pass-3` | `coverage_percentage` |
| 3 | `security-posture` | 0.20 | 0.20 | `discovery-pass-3` | `vulnerability_weighted_score` |
| 4 | `documentation` | 0.10 | 0.10 | `discovery-pass-1` | `doc_completeness_score` |
| 5 | `dependency-currency` | 0.15 | 0.15 | `discovery-pass-3` | `dependency_age_score` |
| 6 | `architecture-clarity` | 0.20 | 0.20 | `discovery-pass-1` | `modularity_score` |

⚠️ **GOTCHA — defaults are seeded via `replace_all`, not per-`register`** (`scoring_dimension.py:200-205`): `register_default_dimensions(registry)` calls `registry.replace_all(list(_DEFAULT_DIMENSIONS))`, which re-validates the sum at import. If a future edit broke the sum the module would fail to import. Insertion order = the tuple order above.

⚠️ **GOTCHA — FAA override** (cross-ref PART C / `scoring_dimension.py:5-6`): FAA elevates `security-posture` to 0.25 and `architecture-clarity` to 0.25 via `_apply_scoring` (A.8) which calls `replace_all` with the profile's dimension set. The profile's dimensions must still sum to 1.0.

---

## A.6 — Extension Point 5: Gate Provider Registry (`gate_provider.py`)

**What an extension registers:** a `GateProvider` record AND (separately) implements the `GateProviderAdapter` Protocol. **Registration mechanism:** programmatic; four built-ins + a default-provider selection at import; adapters resolved out of a module-level `_BUILTIN_ADAPTERS` dict. Per-gate overrides are stored on the registry, profile-driven.

### A.6.1 The adapter Protocol (`gate_provider.py:71-90`)
```
@runtime_checkable
class GateProviderAdapter(Protocol):
    provider_id: str
    def initiate(self, request: GateApprovalRequest) -> GateApprovalStatus: ...
    def poll(self, request: GateApprovalRequest) -> GateApprovalStatus: ...
    def close(self, request: GateApprovalRequest, status: GateApprovalStatus) -> None: ...
```
⚠️ `@runtime_checkable` → `isinstance(x, GateProviderAdapter)` checks method *presence* only (not signatures). Contract: gate subsystem calls `initiate` once, polls via `poll` until state leaves `"pending"`, then `close` on success/abort.

### A.6.2 Adapter request/response dataclasses
**`GateApprovalRequest`** (`gate_provider.py:44-52`, frozen): `gate_id: str`, `artifact_url: str=""`, `title: str=""`, `reviewers: tuple[str,...]=()`, `context: dict[str,Any]=field(default_factory=dict)`.
**`GateApprovalStatus`** (`gate_provider.py:55-68`, frozen): `state: str` (one of `"pending"|"approved"|"rejected"|"cancelled"`), `decided_by: str=""`, `reason: str=""`, `metadata: dict[str,Any]=field(default_factory=dict)`.

### A.6.3 Concrete adapters — full logic

**`GitHubPRGateProvider`** (`provider_id="github-pr"`, `gate_provider.py:93-138`) — the default, fully implemented:
```
initiate(request) → GateApprovalStatus(state="pending", metadata={"artifact_url": request.artifact_url})
poll(request):
    decision = str(request.context.get("decision") or "pending").lower()
    if decision in {"approved","merged"}:
        return GateApprovalStatus("approved",
            decided_by=str(request.context.get("reviewer") or ""),
            reason=str(request.context.get("reason") or ""))
    if decision in {"rejected","changes_requested","closed"}:
        return GateApprovalStatus("rejected",
            decided_by=str(request.context.get("reviewer") or ""),
            reason=str(request.context.get("reason") or ""))
    return GateApprovalStatus("pending")
close(request, status) → None
```
⚠️ GOTCHA: the adapter does **not** drive the PR; Olympus's gate workflow opens the PR and pushes the decision into `request.context["decision"]` so `poll` can echo it. Any decision string outside the two sets → `"pending"`.

**`AutomatedOnlyGateProvider`** (`provider_id="automated-only"`, `gate_provider.py:141-177`):
```
initiate(request) → GateApprovalStatus(state="pending")
poll(request):
    predicates = request.context.get("predicates") or {}
    if not isinstance(predicates, dict) or not predicates:
        return GateApprovalStatus("pending", reason="no predicates provided")
    failing = [name for name, ok in predicates.items() if not ok]
    if failing:
        return GateApprovalStatus("rejected", reason=f"failing predicates: {', '.join(sorted(failing))}")
    return GateApprovalStatus("approved", decided_by="automated", reason="all predicates true")
close(request, status) → None
```
⚠️ GOTCHA: empty/missing/non-dict predicates → `"pending"` (zero-predicate automated gate is a misconfiguration). Failing predicate names are **sorted** in the reason string.

**`ServiceNowGateProvider`** (`provider_id="servicenow"`, `gate_provider.py:180-206`) — **stub**: `initiate`/`poll`/`close` each `raise NotImplementedError("ServiceNow integration not wired — see specifications/implementation-plan.md §4E.")`.

**`JIRAGateProvider`** (`provider_id="jira"`, `gate_provider.py:209-233`) — **stub**: `initiate`/`poll`/`close` each `raise NotImplementedError("JIRA integration not wired — see specifications/implementation-plan.md §4E.")`.

**Adapter resolution** (`gate_provider.py:236-246`):
```
_BUILTIN_ADAPTERS = {                         # ⚠️ keyed by provider_id, values are SHARED singleton instances
    "github-pr":      GitHubPRGateProvider(),
    "automated-only": AutomatedOnlyGateProvider(),
    "servicenow":     ServiceNowGateProvider(),
    "jira":           JIRAGateProvider()}
def builtin_adapter(provider_id) → _BUILTIN_ADAPTERS.get(provider_id.lower())   # case-insensitive, None on miss
```

### A.6.4 `GateProvider` record dataclass (`gate_provider.py:254-268`)
```
@dataclass(frozen=True)
class GateProvider:
    id: str
    description: str = ""
    supports_automated: bool = False          # provider supports no-human decisions
    requires_human: bool = True               # humans required
    metadata: dict[str, object] = field(default_factory=dict)
    implemented: bool = True                  # ⚠️ declared AFTER metadata; True=wired, False=stub
```
⚠️ GOTCHA: `implemented` is declared **after** `metadata` in the dataclass (`gate_provider.py:264-268`), so positional construction order is `(id, description, supports_automated, requires_human, metadata, implemented)`. The gate subsystem refuses to route traffic to a provider with `implemented=False`.

### A.6.5 Validator `_validate_gate_provider` (`gate_provider.py:275-285`)
```
if not provider.id.strip(): raise ValueError("GateProvider.id must not be empty")
if provider.supports_automated and provider.requires_human:
    raise ValueError(f"GateProvider {id!r}: supports_automated and requires_human cannot both be True")
```
⚠️ GOTCHA: a provider that is both automated-capable AND human-required is rejected, even though the comment (`gate_provider.py:278-281`) notes it's "not an absolute error" conceptually — today no such provider exists so the contradiction is surfaced loudly.

### A.6.6 `GateProviderRegistry` (`gate_provider.py:288-365`) — has extra state
Wraps `Registry[GateProvider]` (`id_getter=lambda p: p.id`, `validators=[_validate_gate_provider]`, no dep_getter). **Extra instance state** (`gate_provider.py:296-298`):
```
self._gate_overrides: dict[str, dict] = {}    # keyed by gate id (G-*) — profile-driven per-gate overrides
self._default_provider_id: str = ""           # canonical (lower-cased) id of the default provider
```
Standard methods: `register`→upsert; `get`→`UnknownGateProviderError` ("Known: …"); `has`; `list_all`; `delete` (`EntityNotFound`→`UnknownGateProviderError(str(exc))`); `version`; `bump_version`. `UnknownGateProviderError(EntityNotFound)` (`271-272`).

Extra methods:
- `set_default(provider_id)` (`330-335`): if not registered → `UnknownGateProviderError(f"Cannot set default to unknown provider {id!r}")`; else `self._default_provider_id = provider_id.lower()`.
- `default_provider` (property, `337-341`): `None` if `_default_provider_id` empty, else `self._engine.get(self._default_provider_id)`.
- `set_gate_overrides(gate_id, overrides)` (`343-345`): `self._gate_overrides[gate_id] = dict(overrides)` (**replace**, defensive copy).
- `gate_overrides(gate_id)` (`347-348`): `dict(self._gate_overrides.get(gate_id, {}))` (copy; `{}` if absent).
- `clear_gate_overrides()` (`350-351`): empties the dict.
- `all_gate_overrides()` (`353-354`): `{k: dict(v) for k, v in self._gate_overrides.items()}` (deep-ish copy).
- `adapter_for(provider_id)` (`356-365`): `None` if provider not registered, else `builtin_adapter(provider_id)`. ⚠️ A registered provider with no built-in adapter (e.g. a profile-added id) → `None`.

### A.6.7 The 4 default providers (FIELD-LEVEL — `gate_provider.py:368-403`)
| id | description | supports_automated | requires_human | implemented |
|---|---|---|---|---|
| `github-pr` | `GitHub Pull Request approval (default Olympus gate).` | False | True | True |
| `automated-only` | `Automated checker — gate passes when evidence predicates evaluate true.` | True | False | True |
| `servicenow` | `ServiceNow change request ticket (stub; integration not wired).` | False | True | **False** |
| `jira` | `JIRA ticket-based approval (stub; integration not wired).` | False | True | **False** |

`register_default_providers(registry)` (`400-403`): registers all four **then** `registry.set_default("github-pr")`. Singleton `GATE_PROVIDER_REGISTRY` built + populated at import (`406-407`). Insertion order = table order.

### A.6.8 WORKED EXAMPLE — automated gate evaluation
`GATE_PROVIDER_REGISTRY.adapter_for("automated-only")` → the shared `AutomatedOnlyGateProvider()` instance. Calling `.poll(GateApprovalRequest(gate_id="G-V2", context={"predicates": {"coverage_ok": True, "lint_ok": False}}))` → `GateApprovalStatus(state="rejected", reason="failing predicates: lint_ok")`. With all-true predicates → `GateApprovalStatus("approved", decided_by="automated", reason="all predicates true")`.

---

## A.7 — Extension Point 6: Skill Composition Registry (`skill_composition.py`)

**What an extension registers:** a `SkillComposition`. **Registration mechanism:** programmatic; ⚠️ **NO defaults at import** — the singleton starts **empty** (`skill_composition.py:194`). Profile overrides and API-startup wiring populate it. A skill-presence validator can be attached at runtime.

### A.7.1 `SkillComposition` (`skill_composition.py:42-71`)
```
VALID_MODES = frozenset({"sequential", "parallel", "conditional"})   # line 39

@dataclass(frozen=True)
class SkillComposition:
    name: str
    skills: tuple[str, ...]
    mode: str = "sequential"
    description: str = ""
    conditions: dict[str, str] = field(default_factory=dict)         # skill_id → free-form expr (conditional mode)
    variant_selectors: dict[str, str] = field(default_factory=dict)  # match criteria for an external variant picker
    metadata: dict[str, object] = field(default_factory=dict)
```
⚠️ GOTCHA: `conditions` values are **strings**, not callables — "to keep Temporal determinism, there's no live function reference threaded through the registry" (`skill_composition.py:55-58`). Downstream executors parse/evaluate the expression.

### A.7.2 Two validators
**`_validate_skill_composition`** (always attached, `skill_composition.py:83-101`):
```
if not comp.name.strip(): raise ValueError("SkillComposition.name must not be empty")
if comp.mode not in VALID_MODES: raise ValueError(f"... mode={mode!r} not in {sorted(VALID_MODES)}")
if not comp.skills: raise ValueError(f"... must name at least one skill")
if comp.mode == "conditional":
    for skill in comp.skills:
        if skill not in comp.conditions:
            raise ValueError(f"... conditional mode requires a condition for skill {skill!r}")
```
⚠️ GOTCHA: in `"conditional"` mode **every** skill in `skills` must have a key in `conditions`, else hard error.

**`make_skill_presence_validator(known_skill_ids: Callable[[], set[str]])`** (factory, `skill_composition.py:104-132`) — optional, attached at API startup:
```
def _validator(comp):
    ids = known_skill_ids()
    if not ids: return                            # ⚠️ empty catalog ⇒ SKIP (keeps Temporal decoupled from skill YAML)
    missing = [s for s in comp.skills if s not in ids]
    if missing:
        raise RegistryValidationError(f"SkillComposition {name!r} references unknown skill(s): {', '.join(missing)}")
return _validator
```
⚠️ GOTCHA: raises `RegistryValidationError` directly (not a plain ValueError), so the engine's `validate()` re-raises it **unwrapped** (A.1.3) — the unknown-skill message is preserved verbatim. ⚠️ An empty `known_skill_ids()` result disables the check entirely (so a worker with no skill catalog accepts any composition).

### A.7.3 `SkillCompositionRegistry` (`skill_composition.py:140-191`)
Wraps `Registry[SkillComposition]` (`id_getter=lambda c: c.name`, `validators=[_validate_skill_composition]`, no dep_getter). Methods: `register`→upsert; **`add_validator(validator)`** (`152-161`) → `self._engine.add_validator(validator)` (used to attach the presence validator at API startup); `get`→`UnknownSkillCompositionError` ("Known: …"); `has`; `list_all`; `names()`→`labels()`; `delete` (`EntityNotFound`→`UnknownSkillCompositionError(str(exc))`); `version`; `bump_version`. `UnknownSkillCompositionError(EntityNotFound)` (`74-75`).

`SKILL_COMPOSITION_REGISTRY = SkillCompositionRegistry()` (`194`) — **no `register_default_*` call**; empty until a profile or the API populates it.

### A.7.4 WORKED EXAMPLE — profile-injected composition
There is no built-in composition. The concrete worked example comes from `profile_overrides._apply_skill_composition` (A.8.4): given the FAA profile (which declares 3 skills), it registers `SkillComposition(name="faa-profile-skills", skills=("faa-code-standards","faa-style-greenfield","faa-style-brownfield"), mode="sequential", description="Custom skills declared by the faa profile.")`. After `apply_profile(faa)`, `SKILL_COMPOSITION_REGISTRY.get("faa-profile-skills")` returns it. (The actual FAA skill list / SKILL.md content is PART C.)

---

## A.8 — Profile-Override Orchestration: `profile_overrides.py`

**Role:** ONE seam — every registry learns about a profile through `apply_profile`. Precedence (DECISION-010, `profile_overrides.py:9-15`): (1) registry defaults at import → (2) profile overrides applied here once at startup → (3) tests may `reset_registries_to_defaults`.

### A.8.1 Duck-typed Protocols (`profile_overrides.py:66-99`)
The module depends on the *shape* of a profile, not the API loader, to keep Temporal's dependency footprint thin. Protocols:
```
_ScoringDimensionShape: name:str; weight:float; default_weight:float|None; rationale:str; data_source:str; scoring_function:str
_ScoringShape:          dimensions: tuple[_ScoringDimensionShape, ...]
_GateOverrideShape:     gate_id:str; faa_additions:tuple[Any,...]; reviewer_override:dict[str,Any]
_GatesShape:            default_provider:str; overrides: tuple[_GateOverrideShape, ...]
_ProfileMetadataShape:  id:str; skills:tuple[str,...]
_ProfileShape:          metadata:_ProfileMetadataShape; scoring:_ScoringShape; gates:_GatesShape
```
⚠️ GOTCHA: `faa_additions` and `reviewer_override` field names are FAA-specific but baked into the generic Protocol (`_GateOverrideShape`). Reproduce these exact attribute names — `worker_bootstrap`'s stub and the API loader must match them.

### A.8.2 `RegistryBundle` & `default_registries` (`profile_overrides.py:106-141`)
`RegistryBundle.__init__(*, assembly_lines, dispositions, analysis_passes, scoring_dimensions, gate_providers, skill_compositions)` — keyword-only, stores all six as attributes. `default_registries()` returns a bundle wrapping the **module-level singletons** (`ASSEMBLY_LINE_REGISTRY`, `DISPOSITION_REGISTRY`, `ANALYSIS_PASS_REGISTRY`, `SCORING_DIMENSION_REGISTRY`, `GATE_PROVIDER_REGISTRY`, `SKILL_COMPOSITION_REGISTRY`) so workers keep using the same instances workflow code reads.

### A.8.3 `apply_profile(profile, bundle=None) -> RegistryBundle` (`profile_overrides.py:149-176`)
```
bundle = bundle or default_registries()
_apply_scoring(bundle.scoring_dimensions, profile.scoring)
_apply_gates(bundle.gate_providers, profile.gates)
_apply_skill_composition(bundle.skill_compositions, profile.metadata)
# ⚠️ assembly-line / disposition / analysis-pass have NO override application today —
#    the hook exists but FAA ships no overrides for these three (no-op). (profile_overrides.py:171-175)
return bundle
```
⚠️ **GOTCHA — idempotent by construction, not by guard.** The docstring claims "passing the same profile twice is a no-op" (`profile_overrides.py:156`). There is no explicit guard; idempotency emerges because `_apply_scoring` does `replace_all` (full swap), `_apply_gates` does `clear_gate_overrides` then re-adds + `set_default`, and `_apply_skill_composition` does an overwrite-true `register`. Re-applying lands the registries in the same state. ⚠️ Three of the six registries are *not touched* at all by `apply_profile`.

### A.8.4 The three apply helpers — full logic
**`_apply_scoring`** (`profile_overrides.py:179-199`):
```
entries = [ScoringDimensionEntry(name=d.name, weight=d.weight, default_weight=d.default_weight,
            rationale=d.rationale, data_source=d.data_source, scoring_function=d.scoring_function)
           for d in scoring.dimensions]
registry.replace_all(entries)        # ⚠️ re-validates sum==1.0 defensively (loader already validated)
```
⚠️ GOTCHA: `bounds` and `metadata` are **not** carried from the profile shape (the Protocol has no such fields) — every profile-applied dimension gets default `bounds=(0.0,1.0)`, `metadata={}`.

**`_apply_gates`** (`profile_overrides.py:202-226`):
```
if gates.default_provider:
    if not registry.has(gates.default_provider):
        raise ValueError(f"Profile gates.default_provider {default_provider!r} is not registered. "
                         f"Known providers: {', '.join(p.id for p in registry.list_all())}")
    registry.set_default(gates.default_provider)
registry.clear_gate_overrides()                      # ⚠️ wipe prior per-gate overrides FIRST
for override in gates.overrides:
    registry.set_gate_overrides(override.gate_id, {
        "faa_additions":    list(override.faa_additions),
        "reviewer_override": dict(override.reviewer_override)})
```
⚠️ GOTCHA: unknown `default_provider` raises a **plain `ValueError`** here (not `UnknownGateProviderError`), with a "Known providers" list built from `p.id` (original casing). Falsy `default_provider` (empty string) skips the default-set entirely but still clears+reapplies overrides.

**`_apply_skill_composition`** (`profile_overrides.py:229-260`):
```
if not metadata.skills: return                       # no profile skills ⇒ nothing to register
names = []
for entry in metadata.skills:
    parts = entry.split("/")
    if len(parts) >= 2: names.append(parts[-2])       # "skills/<id>/SKILL.md" → "<id>"
    else:               names.append(parts[-1])       # bare id → itself
if not names: return
registry.register(SkillComposition(
    name=f"{metadata.id}-profile-skills",
    skills=tuple(names), mode="sequential",
    description=f"Custom skills declared by the {metadata.id} profile."))
```
⚠️ **GOTCHA — the skill-name extraction takes the second-to-last path segment.** A profile skill entry like `"skills/faa-code-standards/SKILL.md"` yields `"faa-code-standards"` (index `[-2]`). A bare `"faa-code-standards"` (no slash) yields itself (`[-1]`). A trailing-slash entry like `"skills/x/"` → `parts=["skills","x",""]`, `len>=2` → `parts[-2]="x"`. Reproduce this exactly.

### A.8.5 `reset_registries_to_defaults(bundle=None)` (`profile_overrides.py:263-295`)
```
bundle = bundle or default_registries()
bundle.assembly_lines.__init__();      register_default_lines(bundle.assembly_lines)
bundle.dispositions.__init__();        register_default_strategies(bundle.dispositions)
bundle.analysis_passes.__init__();     register_default_passes(bundle.analysis_passes)
register_default_dimensions(bundle.scoring_dimensions)        # ⚠️ NO __init__() — replace_all is already atomic
bundle.gate_providers.__init__();      register_default_providers(bundle.gate_providers)
bundle.skill_compositions.__init__()   # ⚠️ clear only — skill comps have NO defaults
return bundle
```
⚠️ **GOTCHA — re-calling `__init__()` on a live instance** is the reset mechanism for five registries: it rebuilds `self._engine` (and `_gate_overrides`/`_default_provider_id` for gates) from scratch on the *same object*, so all existing references stay valid. Scoring is the exception — it skips `__init__()` because `register_default_dimensions`→`replace_all` already clears+repopulates atomically. Skill composition gets `__init__()` only (no defaults to re-register). ⚠️ If you reproduce `reset` differently (e.g. constructing a new object), the module-level singletons would diverge from the bundle and break callers — keep the in-place `__init__()` trick.

### A.8.6 `__all__` (`profile_overrides.py:299-309`)
Re-exports: `AnalysisPass`, `AssemblyLine`, `DispositionStrategy`, `RegistryBundle`, `ScoringDimensionEntry`, `SkillComposition`, `apply_profile`, `default_registries`, `reset_registries_to_defaults`.

---

## A.9 — Worker-Side Profile Activation: `worker_bootstrap.py`

**Role:** Worker mirror of the API's `profile_activation`. Implements a **minimal YAML→stub parser** producing duck-typed objects matching the `profile_overrides` Protocols, then calls `apply_profile`. Invoked by `olympus_workflows.worker.run_worker` *before* the worker accepts tasks (`worker_bootstrap.py:14-16`).

### A.9.1 Error type & stub dataclasses (`worker_bootstrap.py:31-79`)
`ProfileBootstrapError(RuntimeError)`. Stub dataclasses (non-frozen, match Protocol shapes):
```
_Metadata:    id:str; skills:tuple[str,...]=()
_ScoringDim:  name:str; weight:float; default_weight:float|None=None; rationale:str=""; data_source:str=""; scoring_function:str=""
_Scoring:     dimensions:tuple[_ScoringDim,...]=()
_GateOverride: gate_id:str; faa_additions:tuple=(); reviewer_override:dict=field(default_factory=dict)
_Gates:       default_provider:str="github-pr"; overrides:tuple[_GateOverride,...]=()
_ProfileStub: metadata:_Metadata; scoring:_Scoring; gates:_Gates
```
⚠️ `_Gates.default_provider` defaults to `"github-pr"` (matches the registry default).

### A.9.2 `_load_yaml(path)` (`worker_bootstrap.py:86-97`)
```
import yaml                                  # lazy import
if not path.is_file(): raise ProfileBootstrapError(f"Missing profile file: {path}")
try:    data = yaml.safe_load(path.read_text(encoding="utf-8")) or {}     # ⚠️ empty file → {}
except yaml.YAMLError as exc: raise ProfileBootstrapError(f"Invalid YAML in {path}: {exc}") from exc
if not isinstance(data, dict): raise ProfileBootstrapError(f"Expected mapping in {path}")
return data
```

### A.9.3 `load_profile_stub(profile_root)` (`worker_bootstrap.py:100-150`) — parser logic
```
root = Path(profile_root).resolve()
if not root.is_dir(): raise ProfileBootstrapError(f"Profile root not found: {root}")
prof    = _load_yaml(root/"profile.yaml").get("profile") or {}     # ⚠️ unwraps top-level "profile:" key
scoring = _load_yaml(root/"scoring.yaml").get("scoring") or {}     # unwraps "scoring:"
gates   = _load_yaml(root/"gates.yaml").get("gates") or {}         # unwraps "gates:"

dims = []
for d in scoring.get("dimensions") or []:
    if not isinstance(d, dict) or "name" not in d or "weight" not in d: continue   # ⚠️ silently skip malformed
    dims.append(_ScoringDim(
        name=str(d["name"]), weight=float(d["weight"]),
        default_weight=(float(d["default_weight"]) if d.get("default_weight") is not None else None),
        rationale=str(d.get("rationale") or ""), data_source=str(d.get("data_source") or ""),
        scoring_function=str(d.get("scoring_function") or "")))

gate_overrides = []
overrides_block = gates.get("overrides") or {}
if isinstance(overrides_block, dict):                              # ⚠️ overrides expected as a MAPPING gate_id→body
    for gate_id, body in overrides_block.items():
        body = body or {}
        gate_overrides.append(_GateOverride(
            gate_id=str(gate_id),
            faa_additions=tuple(body.get("faa_additions") or ()),
            reviewer_override=dict(body.get("reviewer_override") or {})))

return _ProfileStub(
    metadata=_Metadata(id=str(prof.get("id","unknown")), skills=tuple(prof.get("skills") or ())),
    scoring=_Scoring(dimensions=tuple(dims)),
    gates=_Gates(default_provider=str(gates.get("default_provider") or "github-pr"),
                 overrides=tuple(gate_overrides)))
```
⚠️ **GOTCHA — each profile file is unwrapped by its top-level key**: `profile.yaml` → `profile:`, `scoring.yaml` → `scoring:`, `gates.yaml` → `gates:`. Reproduce these wrapper keys (cross-ref PART C for actual FAA content).
⚠️ **GOTCHA — gate `overrides` parsed as a mapping `{gate_id: body}`**, but the API loader / `_GatesShape` treats `overrides` as a tuple of records with a `gate_id` field. The worker builds the tuple here from the mapping. If overrides is a *list* in YAML, `isinstance(overrides_block, dict)` is False and **all overrides are silently dropped**. The FAA `gates.yaml` must therefore express overrides as a mapping for the worker to pick them up.
⚠️ **GOTCHA — malformed scoring dimensions silently skipped** (missing `name` or `weight`), but the eventual `replace_all` will still enforce sum==1.0, so a dropped dimension surfaces as a sum failure, not a parse error.
⚠️ Missing `prof.id` defaults to `"unknown"` (so `_apply_skill_composition` would name the composition `"unknown-profile-skills"` if id is absent but skills are present).

### A.9.4 `bootstrap_profile_from_env() -> _ProfileStub | None` (`worker_bootstrap.py:158-198`)
```
profile_id = os.environ.get("OLYMPUS_PROFILE")
if not profile_id:
    log.info("No OLYMPUS_PROFILE set — worker will use default registries.")
    return None                                   # ⚠️ no profile ⇒ defaults, NOT an error

profiles_dir = os.environ.get("OLYMPUS_PROFILES_DIR")
candidates = []
if profiles_dir: candidates.append(Path(profiles_dir)/profile_id)
here = Path(__file__).resolve()
for parent in (here, *here.parents):              # ⚠️ walk up from THIS FILE to filesystem root
    candidates.append(parent/"profiles"/profile_id)

for candidate in candidates:                      # first existing dir wins
    if candidate.is_dir():
        stub = load_profile_stub(candidate)
        try: apply_profile(stub)
        except Exception as exc:                  # ⚠️ ANY apply error → ProfileBootstrapError (fail fast at startup)
            raise ProfileBootstrapError(f"Failed to apply profile {profile_id!r}: {exc}") from exc
        log.info("Activated worker profile %s from %s", profile_id, candidate)
        return stub

raise ProfileBootstrapError(f"Could not locate profile {profile_id!r}. Set OLYMPUS_PROFILES_DIR.")
```
⚠️ **GOTCHA — candidate search order**: explicit `OLYMPUS_PROFILES_DIR/<id>` first (if set), then `<each ancestor of this file>/profiles/<id>` walking *up* from `worker_bootstrap.py`'s location to `/`. The **first directory that exists** is used. ⚠️ `here` itself (the file path) is included as a "parent" so `here/"profiles"/id` is checked even though `here` is a file — harmless (won't be a dir).
⚠️ **GOTCHA — apply failures are fatal at startup by design** (`worker_bootstrap.py:14-16, 184-188`): "Failing loudly at startup beats half-configuring the worker." A profile that names an unregistered gate provider, or whose scoring weights don't sum to 1.0, crashes the worker before it serves any task.

---

## A.10 — Package Surface: `__init__.py`

`olympus_workflows/registries/__init__.py` (145 lines) re-exports the public API of all six registries + engine + profile orchestration. Notable: it exposes `SKILL_COMPOSITION_MODES` as an alias for `skill_composition.VALID_MODES` (`__init__.py:84-86, 123`), and re-exports `CircularDependencyError` (which `engine.__all__` omits — A.1.1). The full `__all__` lists every singleton, dataclass, error, and helper across the package (`__init__.py:88-144`). Module docstring (`__init__.py:14-19`) restates the determinism contract: "Registries are read-only from inside Temporal workflow code — determinism is preserved by populating defaults at import and applying profile overrides at worker startup *before* the first workflow executes."

---

## A.11 — Cross-Registry Behavioral Summary (parity checklist)

| Aspect | Engine default | Per-registry divergence |
|---|---|---|
| Case sensitivity | `case_sensitive=False` (lower-cased keys) | `scoring_dimension` is `case_sensitive=True` |
| `get` on miss | raises `EntityNotFound` | `scoring_dimension.get` returns **`None`**; others raise a domain subclass |
| `delete` `EntityNotFound` | raises `EntityNotFound` | mapped to domain error; `scoring_dimension`→plain `KeyError` |
| `delete` `EntityHasDependents` | raises `EntityHasDependents` | `assembly_line`/`analysis_pass` re-raise it unwrapped; others can't hit it (no deps) |
| Defaults at import | n/a | all populate EXCEPT `skill_composition` (empty) |
| `dep_getter` | `() ` | set only for `assembly_line` & `analysis_pass` |
| Validators | `[]` | each registry supplies ≥1; `skill_composition` can gain a presence validator at runtime |
| Extra state | none | `gate_provider` adds `_gate_overrides` + `_default_provider_id` |
| Default seeding call | n/a | `scoring_dimension` uses `replace_all` (sum-checked); others loop `register` |
| Touched by `apply_profile` | n/a | only scoring, gates, skill_composition; assembly/disposition/analysis are no-ops today |
| Touched by `reset_registries_to_defaults` | n/a | all six; scoring skips `__init__()`, skill_composition has no re-register |

⚠️ **Determinism summary:** defaults at import + single startup override + frozen entities + parallel version dict = replay-safe. No runtime guard prevents mutation; the safety is structural. `VersionRecord` is the only mutable structure and is never on the entity. The contract loader's `@lru_cache(maxsize=1)` (`olympus-contracts/.../assembly_lines.py:297`) makes import-time YAML reads stable within a process.

---

# PART B — THE LINE-TO-LINE CONTRACT

> How assembly lines couple producer→consumer through **versioned, schema-validated, Git-stored artifacts**. The contract has four moving parts (`assembly-lines/overview.md:149-158`): (1) the producer writes artifacts to a defined repo path in a defined schema; (2) the consumer reads them and validates schema compliance before processing; (3) the transition **gate** between lines verifies completeness/quality; (4) traceability — every artifact references its source inputs. This part reproduces the *mechanics* of all four at behavioral-parity fidelity.

**Files covered in this part:**

| File | Role |
| --- | --- |
| `temporal/olympus_workflows/activities/git_operations.py` (601 lines) | `read_artifact` / `write_artifact` / `write_artifacts_batch` / `create_pr` / `merge_pr` / `reconcile_and_merge_pr` / `provision_target_repo` — the Git handoff substrate |
| `temporal/olympus_workflows/activities/artifact_validation.py` (433 lines) | `validate_artifact_against_schema` + `_SCHEMA_REGISTRY` (the artifact→schema map) |
| `temporal/olympus_workflows/activities/line_transitions.py` (≈8000 lines) | `start_next_line_workflow` (linear handoff) + `_LINE_TO_WORKFLOW` map + fan-out persistence activities |
| `temporal/olympus_workflows/workflows/wave_rationalization.py` | `_validate_artifact_or_warn` (read-side advisory validation), `_wait_for_gate` (gate gating), `_handoff_to_architecture_coordinator` (gate→next-line) |
| `temporal/olympus_workflows/workflows/wave_architecture.py` | strict-fail validation on read (`validated`/`errors` → `ApplicationError(non_retryable=True)`) |
| `temporal/olympus_workflows/workflows/architecture.py` / `modernization.py` / `data.py` / `discovery.py` | consumer-side `read_artifact` call sites + `prior_artifacts` threading |
| `olympus-contracts/.../assembly_lines.py` (`_load_all`, `list_lines`, `_parse_line`) | the contract loader that materialises `depends_on`/`inputs`/`outputs` |
| `assembly-lines/overview.md` | the dependency-model + line-to-line-contract narrative (source of truth for the model) |
| 10 line YAMLs under `olympus-contracts/olympus_contracts/data/assembly-lines/` | per-line `depends_on`/`inputs`/`outputs`/`mode` declarations |

⚠️ **GOTCHA — there are TWO orchestration topologies, and only ONE is the linear-handoff path.** Olympus does **not** drive the whole pipeline through `start_next_line_workflow`. That activity exists and handles a **linear** Discovery→Rationalization→Modernization handoff for the legacy/non-wave path, but the **live wave path** (FAA, Phase 3) couples lines through **child-workflow spawning gated by gate-approval signals** inside `WaveRationalizationWorkflow` / `WaveArchitectureWorkflow`. Both must be reproduced. See B.4.

---

## B.0 — The Artifact Handoff Object Model (read first)

Every line-to-line coupling is a **(repo, branch, path, schema)** tuple. The producer commits a file; the consumer reads the *same path* on the *same branch* of the *same repo*.

**Handoff coordinates:**
- **repo** — a GitHub `owner/name` slug. There are TWO repo roles after W19's repo-split (`git_operations.py:548-561`): the **artifact_repo** (governance-only: Discovery/Rationalization/Architecture-plan/Validation evidence, committed by `WriteArtifactInput.repo = input.artifact_repo`) and the **target_repo** (self-contained per-target-app: Architecture+Data+Modernization specs/designs/code). The application row carries both (`application.repo_url` = legacy source; `application.target_repo_url`; `portfolio.artifact_repo_url`) — see `start_next_line_workflow`'s SQL at `line_transitions.py:128-142`.
- **branch** — almost always `"main"` for cross-line handoffs (consumers read `branch="main"`: `architecture.py:1315`, `wave_architecture.py` plan read, `modernization.py:1898`). Producers commit work to a feature branch, open a PR, and the gate's merge moves the artifact onto `main` (B.4). Once on `main`, downstream lines read it.
- **path** — a deterministic, wave/app-scoped path. Canonical patterns (verified from read call sites):
  - `architecture/wave-{wave_id}/architecture-target-plan.json` (`architecture.py:1306-1309`, `wave_architecture.py` `_plan_path`)
  - `rationalization/wave-{wave_id}/capability-consolidation-plan.json` (`architecture.py:680-683`)
  - `rationalization/wave-{wave_id}/targets/{target_app_id}/source-artifacts-index.json` (`architecture.py:612-615`)
  - `modernization/{app_id}/design/files/module-design/module-map.yaml` (`modernization.py:1889-1891`)
- **schema** — a JSON-Schema 2020-12 document under `schemas/<line>/<name>.schema.json`, resolved through `_SCHEMA_REGISTRY` keyed by **artifact filename** (B.2).

**The two write activities (`git_operations.py:217-320`):**

`write_artifact(WriteArtifactInput)` — one file, one commit via the GitHub Contents API (`svc.commit_file`). `WriteArtifactInput` fields (`types.py:609-618`): `repo`, `branch`, `path`, `content`, `commit_message`, `execution_context: StepExecutionContext | None = None`. Returns `WriteArtifactResult(commit_sha, path, branch)` (`types.py:621-627`).

`write_artifacts_batch(WriteArtifactsBatchInput)` — N files in ONE commit via blob+tree+commit+ref-update (`svc.commit_files`). ⚠️ GOTCHA: the per-file loop (`write_artifact` × N) costs N+1 commits and N+1 activity round-trips; batch collapses to ONE commit regardless of N (`git_operations.py:276-283`). `paths = [p for p, _ in input.files]` — `files` is a list of `(path, content)` pairs.

**The read activity:** `read_artifact(ReadArtifactInput)` (`git_operations.py:168-214`). `ReadArtifactInput` fields (`types.py:558-565`): `repo`, `branch`, `path`, `commit_sha: str = ""`, `execution_context: StepExecutionContext | None = None`. Returns `ReadArtifactResult(content, commit_sha, path)` (`types.py:568-574`).

⚠️ **GOTCHA — `read_artifact` does NOT validate.** It is a pure Git fetch. Schema validation is a **separate** activity (`validate_artifact_against_schema`) the *consumer workflow* chooses to invoke on the returned `content`. The read activity raises only on Git I/O failure (re-raises after emitting a FAILED execution record — `git_operations.py:194-202`). See B.2/B.3 for where validation actually happens.

---

## B.1 — Producer Write Path (full logic, `git_operations.py:168-320`)

### B.1.1 `read_artifact` — the consumer's fetch primitive
```
async read_artifact(input: ReadArtifactInput) -> ReadArtifactResult:
    execution_id = await _emit_git_start(           # observability: RUNNING step_execution row
        input.execution_context, repo=input.repo,
        operation="read_artifact", branch=input.branch, paths=[input.path])
    try:
        svc = _build_git_service(repo_override=input.repo)      # PyGithub-backed GitService
        result = svc.read_file(path=input.path, branch=input.branch, commit_sha=input.commit_sha)
    except Exception as exc:
        await _emit_git_complete(execution_id, repo=input.repo, branch=input.branch,
                                 status=ExecutionStatus.FAILED, error=str(exc))
        raise                                         # ⚠️ re-raise — caller decides retry/fallback
    await _emit_git_complete(execution_id, repo=input.repo, branch=input.branch,
                             commit_sha=result.commit_sha, output_paths=[result.path])
    return ReadArtifactResult(content=result.content, commit_sha=result.commit_sha, path=result.path)
```
⚠️ GOTCHA: `_emit_git_start` returns `None` (no-op) when `ctx is None` (`git_operations.py:67-68`), e.g. unit-test contexts; then `_emit_git_complete(None,...)` early-returns (`git_operations.py:117-118`). So observability is conditional on a non-null `execution_context`.
⚠️ GOTCHA: `_build_git_service` imports `from src.git_service import GitService` **at call time** (`git_operations.py:156`) — PyGithub is only available in the worker container at runtime, so the import is deferred.

### B.1.2 `write_artifact` / `write_artifacts_batch`
```
async write_artifact(input: WriteArtifactInput) -> WriteArtifactResult:
    execution_id = await _emit_git_start(input.execution_context, repo=input.repo,
        operation="write_artifact", branch=input.branch, paths=[input.path])
    try:
        svc = _build_git_service(repo_override=input.repo)
        result = svc.commit_file(branch=input.branch, path=input.path,
                                 content=input.content, commit_message=input.commit_message)
    except Exception as exc:
        await _emit_git_complete(execution_id, repo=input.repo, branch=input.branch,
                                 status=ExecutionStatus.FAILED, error=str(exc)); raise
    await _emit_git_complete(execution_id, repo=input.repo, branch=result.branch,
                             commit_sha=result.commit_sha, output_paths=[result.path])
    return WriteArtifactResult(commit_sha=result.commit_sha, path=result.path, branch=result.branch)
```
⚠️ All writes are **idempotent** — "safe to retry"; a retry re-does the commit and advances the ref again (`git_operations.py:227-228`, `282-283`). Use `RETRY_POLICIES["transient"]` (HTTP retry).

`write_artifacts_batch` is structurally identical but calls `svc.commit_files(branch, files, commit_message)` and reports `paths` (all files) on the execution record. Returns `WriteArtifactsBatchResult(commit_sha, paths, branch)`.

### B.1.3 The PR + merge path that moves an artifact onto `main`
A producer line commits artifacts to a **feature branch**, then `create_pr` opens a PR for gate review, then (post gate-approval) `merge_pr` / `reconcile_and_merge_pr` moves the artifact to `main` where consumers read it.

`create_pr(CreatePRInput)` (`git_operations.py:323-374`): `svc.create_pull_request(source_branch, target_branch, title, body, reviewers or None, labels or None)` → `CreatePRResult(pr_number, pr_url, source_branch, target_branch)`. Docstring contract: "PR approval triggers a `gate_approved` signal on the waiting workflow" (`git_operations.py:327`).

`merge_pr(MergePRInput)` (`git_operations.py:377-421`): `svc.merge_pull_request(pr_number, merge_method)` → `MergePRResult(pr_number, merged=result["merged"], merge_sha=result.get("merge_sha",""))`.

`reconcile_and_merge_pr(MergePRInput)` (`git_operations.py:424-540`) — ⚠️ the **concurrency-safe** replacement for `merge_pr` on artifact-repo merges that may race with sibling app workflows (W17/P5-S17.3c). Behavior delegated to `GitService.reconcile_and_merge` (`git_operations.py:433-462`):
```
1. Re-read PR state from GitHub.
2. If already merged → idempotent success.
3. If mergeable_state == "clean"  → merge.
4. If mergeable_state == "behind" → invoke update-branch API, re-check, then merge.
                                     If STILL behind → raise MergeDivergenceUnresolved.
5. If mergeable_state == "dirty"   → raise MergeConflict (non-retryable).
6. If mergeable_state == "blocked" → raise MergeBranchProtectionRejected (non-retryable).
```
⚠️ GOTCHA — telemetry side-channel: on BOTH success and failure it emits one structured log line with `extra=` fields `pr_number`, `initial_mergeable_state`, `rebase_ran`, `final_mergeable_state`, `merge_sha`, `failure_type`, `attempt`, `duration_ms` (`git_operations.py:443-462`, `496-535`); the same fields land in the step_execution payload. `attempt = activity.info().attempt` with fallback `1` in unit tests (`git_operations.py:476-479`). The three structured merge errors are in `RETRY_POLICIES["git_merge"]`'s non-retryable list so the workflow catches them and transitions the gate to `merge_blocked`.

### B.1.4 Target-repo provisioning (`provision_target_repo`, `git_operations.py:543-600`)
Backs the Architecture line's `target-state-mapping` step under W19's repo-split. **Idempotent on `repo_slug`** — re-running against an existing repo returns the existing URL with `created=False` rather than raising (`git_operations.py:555-557`). Calls `GitService.provision_repository(GitServiceConfig(...), repo_slug, initial_readme, private)` → `(url, created)`. Returns `ProvisionTargetRepoResult(target_app_id, target_repo_url=url, repo_slug, created)`. ⚠️ Writes NO DB state — callers project `target_repo_url` via `persist_architecture_side_effects` post-G-02.

---

## B.2 — Schema Validation on Read: `validate_artifact_against_schema`

**This is WHERE schema validation happens.** The activity lives at `artifact_validation.py:379-432`. It is the single chokepoint; consumer workflows call it on `read_artifact`/agent-emitted content. ⚠️ It **NEVER raises for a validation outcome** — it always returns a `ValidateArtifactResult` (`artifact_validation.py:28-29, 389-393`). The caller owns escalation (warn vs. retry vs. hard-fail). It raises `NonRetryableError` ONLY on an environmental failure (schema file missing).

### B.2.1 The activity, branch-by-branch (`artifact_validation.py:379-432`)
```
async validate_artifact_against_schema(input: ValidateArtifactInput) -> ValidateArtifactResult:
    filename = input.artifact_filename
    if not _known_artifact(filename):                       # filename not in _SCHEMA_REGISTRY
        return ValidateArtifactResult(validated=False, parsed_payload=None, errors=[])
        #  ⚠️ validated=False here means "nothing to check", NOT "bad payload"

    parsed = parse_agent_json(input.raw_content)            # markdown-fence-tolerant parse (utils)
    if not isinstance(parsed, dict):                        # couldn't extract a JSON object
        return ValidateArtifactResult(
            validated=False, parsed_payload=None,
            errors=[f"{filename}: agent output could not be parsed as a JSON object "
                    "(even with markdown-fence-stripping and brace-scanning fallbacks)."])

    schema = _load_schema(_SCHEMA_REGISTRY[filename])       # ⚠️ may raise NonRetryableError (missing file)
    errors = _validate_payload(parsed, schema)
    return ValidateArtifactResult(validated=True, parsed_payload=parsed, errors=errors)
```
- `ValidateArtifactInput` (`types.py:630-643`): `artifact_filename: str`, `raw_content: str`.
- `ValidateArtifactResult` (`types.py:646-669`): `validated: bool`, `parsed_payload: dict | None`, `errors: list[str] = field(default_factory=list)`.

⚠️ **GOTCHA — three distinct meanings of the result triple.** (a) `validated=False, errors=[]` → filename unknown to registry, **no-op** (forward progress preserved). (b) `validated=False, errors=[<parse msg>]` → known filename but the agent output wasn't a JSON object. (c) `validated=True, errors=[…]` → schema validation actually ran and found problems. (d) `validated=True, errors=[]` → clean. Callers MUST distinguish (a) from (b)/(c) — a readable summary that conflates "nothing to check" with "valid" is a parity failure.

### B.2.2 `_validate_payload` (`artifact_validation.py:363-376`)
```
validator = Draft202012Validator(schema)
errors = list(validator.iter_errors(payload))
if not errors: return []
return [f"  {err.json_path or '<root>'}: {err.message}" for err in errors[:8]]
```
⚠️ GOTCHA — error messages are **capped at the first 8** (`errors[:8]`), each prefixed with two spaces and the `json_path` (or literal `'<root>'` when empty). The error *list ordering* is whatever `Draft202012Validator.iter_errors` yields — not sorted. Reproduce the 8-cap and the `  {path}: {message}` format exactly.

### B.2.3 `_load_schema` — the only raise path (`artifact_validation.py:354-360`)
```
if not schema_path.exists():
    raise NonRetryableError(f"schema not found at {schema_path}. Check your repo layout.")
with schema_path.open() as handle: return json.load(handle)
```
⚠️ A missing schema is a **build/deployment bug, not an agent-output problem** — hence `NonRetryableError` (non-retryable). This is the ONLY way the activity raises.

### B.2.4 `_resolve_schemas_dir` — layout resolution (`artifact_validation.py:85-115`)
⚠️ GOTCHA — the schemas dir is resolved at **import time** into module-global `_SCHEMAS_DIR` (`artifact_validation.py:118`), checked in this exact order, first existing dir wins:
```
candidates = []
if os.environ.get("OLYMPUS_SCHEMAS_DIR"): candidates.append(Path(env))
candidates.append(Path(__file__).resolve().parents[3] / "schemas")   # dev-mode repo layout
candidates.append(Path("/app/schemas"))                              # canonical container mount
candidates.append(Path("/app/repo/schemas"))                         # alternate mount
for p in candidates:
    if p.is_dir(): return p.resolve()
return candidates[1]   # ⚠️ informative fallback — parents[3]/schemas even if missing, so _load_schema's error names what was checked
```
⚠️ The wheel-installed activity lives under `site-packages/olympus_workflows/activities/`, where `parents[3]` does NOT contain the repo's `schemas/` tree — hence the container relies on `OLYMPUS_SCHEMAS_DIR` or `/app/schemas`.

### B.2.5 `_SCHEMA_REGISTRY` — the artifact→schema map (FIELD-LEVEL, `artifact_validation.py:124-346`)
⚠️ **GOTCHA — this dict IS the validation surface.** Adding a `(filename, schema_path)` entry auto-enables validation for that artifact (`artifact_validation.py:55-57`). All values are `_SCHEMAS_DIR / "<subdir>" / "<file>.schema.json"`. Reproduce EVERY mapping — these are the ONLY artifacts that get validated; everything else returns the no-op (a) result.

**Rationalization subdir (`schemas/rationalization/`):**
| artifact_filename (key) | schema file |
|---|---|
| `disposition-recommendation.json` | `disposition-recommendation.schema.json` |
| `classification.json` | `classification.schema.json` |
| `portfolio-score.json` | `portfolio-score.schema.json` |
| `redundancy-matrix.json` | `redundancy-matrix.schema.json` |
| `portfolio-redundancy-matrix.json` | `rationalization-clustering-plan.schema.json` ⚠️ alias-to-clustering-plan (Migration 052; filename preserved, validator alias changed) |
| `shared-identity-report.json` | `shared-identity-report.schema.json` |
| `wave-outcome-synthesis.json` | `wave-outcome-synthesis.schema.json` |
| `intra-app-redundancy.json` | `redundancy-matrix.schema.json` ⚠️ same schema as cross-app redundancy-matrix |
| `ux-overlap-matrix.json` | `ux-overlap-matrix.schema.json` |
| `business-rule-redundancy.json` | `business-rule-redundancy.schema.json` |
| `integration-graph.json` | `integration-graph.schema.json` |
| `disposition-governance.json` | `disposition-governance.schema.json` |
| `user-impact-analysis.json` | `user-impact-analysis.schema.json` |
| `wave-plan.json` | `wave-plan.schema.json` |
| `wave-plan-validation.json` | `wave-plan-validation.schema.json` |

**Discovery subdir (`schemas/discovery/`):**
| artifact_filename | schema file |
|---|---|
| `application-catalog-entry.json` | `catalog.schema.json` ⚠️ key≠schema-stem |
| `business-logic.json` | `business-logic.schema.json` |
| `quality-risk.json` | `quality-risk.schema.json` |
| `ux-accessibility.json` | `ux-accessibility.schema.json` |
| `discovery-synthesis.json` | `discovery-synthesis.schema.json` |
| `capability-catalog.json` | `capability-catalog.schema.json` |

**Architecture subdir (`schemas/architecture/`):**
| artifact_filename | schema file |
|---|---|
| `architecture-blueprint.json` | `architecture-blueprint.schema.json` |
| `cloud-pattern.json` | `cloud-pattern.schema.json` |
| `target-application-map.json` | `target-application-map.schema.json` |
| `architecture-target-plan.json` | `architecture-target-plan.schema.json` ⚠️ wave-grain; strict-fail validated pre-commit (B.3) |
| `cost-estimate.json` | `cost-estimate.schema.json` |
| `ea-compliance-report.json` | `ea-compliance.schema.json` ⚠️ two filenames → one schema |
| `ea-compliance.json` | `ea-compliance.schema.json` |
| `api-contract-compliance-report.json` | `integration-arch.schema.json` ⚠️ aliases integration-arch |
| `integration-arch.json` | `integration-arch.schema.json` |
| `security-arch.json` | `security-arch.schema.json` |
| `design-system.json` | `design-system.schema.json` |
| `accessibility-review.json` | `accessibility-review.schema.json` |
| `ai-ml-integration.json` | `ai-ml-integration.schema.json` |
| `well-architected-review.json` | `well-architected-review.schema.json` |

**Data subdir (`schemas/data/`):**
| artifact_filename | schema file |
|---|---|
| `data-domains.json` | `data-domains.schema.json` |
| `shared-db-analysis.json` | `shared-db-analysis.schema.json` ⚠️ source-grain: requires `source_app_id` + `wave_id` |
| `decomposition-strategy.json` | `decomposition-strategy.schema.json` |
| `data-migration-plan.json` | `data-migration-plan.schema.json` |
| `data-product-design.json` | `data-product-design.schema.json` ⚠️ wave-scoped target-binding fields required at top level |
| `data-architecture.json` | `data-architecture.schema.json` |

⚠️ GOTCHA — the Data-line + Rationalization artifacts (`data-domains`, `shared-db-analysis`, `decomposition-strategy`, `data-migration-plan`, `data-product-design`, `data-architecture`) require **wave-scoped target binding** at the top level (`target_app_id`/`target_service_id`/`relationship`/`source_app_ids`), EXCEPT `shared-db-analysis` which is source-grain (`source_app_id` + `wave_id`) — documented `artifact_validation.py:47-53`. The schema itself enforces these; the registry just routes the filename.

---

## B.3 — Two Read-Side Validation Modes: ADVISORY vs. STRICT-FAIL

The activity is policy-free; the **consumer workflow** picks the escalation. There are exactly two production patterns.

### B.3.1 ADVISORY mode — `_validate_artifact_or_warn` (`wave_rationalization.py:4764-4838`)
Used right after an agent dispatch for every registered JSON artifact, so bad shape lands in a warnings dict surfaced on the G-DA card instead of silently flowing downstream. **Never blocks the workflow.**
```
async _validate_artifact_or_warn(*, artifact_filename, raw_content, wave_id, app_id=""):
    if not raw_content: return                       # ⚠️ empty content → no-op
    try:
        result = await workflow.execute_activity(
            validate_artifact_against_schema,
            ValidateArtifactInput(artifact_filename=artifact_filename, raw_content=raw_content),
            start_to_close_timeout=30s, retry_policy=RETRY_POLICIES["transient"])
    except ActivityError as exc:                     # ⚠️ schema-missing NonRetryableError arrives as ActivityError
        workflow.logger.warning(f"{artifact_filename} schema validation skipped: {exc}",
            extra={...,"reason":"validator-unavailable"})
        return                                        # ⚠️ advisory MUST never take down the workflow → swallow + return
    if not result.errors: return                     # clean OR no-op (validated=False,errors=[])
    warning_key = app_id or f"wave-{wave_id}"
    log_extra = {"wave_id":wave_id,"app_id":app_id,"artifact":artifact_filename,
                 "error_count":len(result.errors),"errors":result.errors}
    if result.validated:
        workflow.logger.warning(f"{artifact_filename} schema validation failed", extra=log_extra)
    else:
        workflow.logger.warning(f"{artifact_filename} could not be parsed", extra=log_extra)
    self._validation_warnings.setdefault(warning_key, []).extend(result.errors)
```
⚠️ **GOTCHA — advisory mode swallows EVEN the environmental `NonRetryableError`.** Because a missing schema arrives wrapped as `ActivityError`, advisory mode catches it, logs `reason: validator-unavailable`, and returns as if nothing happened. So a packaging defect that hides a schema does NOT fail a wave-rationalization run — it silently disables that artifact's validation. Reproduce this swallow; do not "improve" it to raise.
⚠️ GOTCHA — `warning_key` is `app_id` if non-empty, else `f"wave-{wave_id}"`. Warnings accumulate via `setdefault(...).extend(...)` so repeated calls for the same key append.
⚠️ This was retrofitted: before it existed, only `disposition-recommendation` called the validator; 5 other registered artifacts (classification, portfolio-score, redundancy-matrix, portfolio-redundancy-matrix, wave-outcome-synthesis) had schemas but **no runtime call site** (`wave_rationalization.py:4783-4787`).

### B.3.2 STRICT-FAIL mode — `WaveArchitectureWorkflow` plan validation (`wave_architecture.py:392-407`)
Used for the load-bearing `architecture-target-plan.json` before committing it to `main`, because downstream per-target Architecture children read+derive from it.
```
validation = await workflow.execute_activity(
    validate_artifact_against_schema,
    ValidateArtifactInput(artifact_filename=_TARGET_PLAN_FILENAME, raw_content=plan_file.content),
    start_to_close_timeout=30s, retry_policy=RETRY_POLICIES["validation_failure"])
if not validation.validated or validation.errors:            # ⚠️ BOTH conditions fail-loud
    errors_preview = "; ".join(validation.errors[:4])
    raise ApplicationError(f"wave plan failed schema validation: {errors_preview}", non_retryable=True)
```
⚠️ **GOTCHA — strict mode treats `validated=False` AS a failure.** Note the gate is `not validation.validated OR validation.errors`. In advisory mode `validated=False, errors=[]` is a benign no-op; in strict mode it raises (because a plan whose filename isn't registered, or that won't parse, is a hard error here). The two modes interpret the SAME result triple oppositely — this is the crux of behavioral parity. The strict raise uses `ApplicationError(non_retryable=True)` and previews only the first 4 errors (`errors[:4]`).

⚠️ The consumer side ALSO re-checks on read: when a per-target Architecture child reads the plan (`architecture.py:1310-1353`) it raises `ApplicationError(non_retryable=True)` if (a) the read fails ("WaveArchitectureWorkflow must commit the plan before per-target Architecture children spawn"), (b) `json.loads` fails ("coordinator should have rejected via schema validation before commit"), or (c) `target_app_id not in target_ids_in_plan` ("provisioning seeded a target that the coordinator's plan does not cover"). So the plan is validated at WRITE (coordinator, strict) and re-asserted at READ (child, structural).

### B.3.3 FALLBACK-ON-READ mode (optional artifacts)
Many reads are best-effort with a typed fallback rather than validate-or-raise:
- `architecture.py:595-648` `_read_target_source_artifacts_index`: read fails OR malformed JSON → `return []` (index is optional; in-flight runs fall back to `input.prior_artifacts`).
- `architecture.py:650-705` `_realize_consolidation_grain_if_present`: missing consolidation plan → log + `return` (older waves won't have one).
- `modernization.py:1893-1920` `_read_module_map`: read fails / malformed YAML / empty contexts → `return ["default"]` (single default bounded-context fan-out).
⚠️ GOTCHA — these `except Exception: # noqa: BLE001` blocks are deliberately broad; the artifact being optional is the design. Distinguish them from the strict-fail path: optional reads NEVER call the validator and NEVER raise.

---

## B.4 — Transition Gates: How the Next Line Is Gated (the live wave path)

⚠️ **GOTCHA — the live FAA/wave path does NOT use `start_next_line_workflow` to advance Discovery→Rationalization, or Rationalization→Architecture.** Instead, the *next line is started as a child workflow only after the current line's gate is approved*, inside the wave orchestrators. Reproduce this exactly — wiring the linear handoff for these transitions would change behavior.

### B.4.1 The gate-gating primitive — `_wait_for_gate` (`wave_rationalization.py:5258-5333`)
A line cannot advance until a human (or dual-signal) approves its gate. The workflow parks on a Temporal `wait_condition` keyed by gate, consuming per-gate decision queues:
```
async _wait_for_gate(gate_key) -> str:     # gate_key e.g. "G-RR" / "G-DA"
    self._pending_gate = GateType(gate_key) if gate_key in GateType._value2member_map_ else None
    self._status = WAITING_FOR_SIGNAL
    self._gate_decisions.setdefault(gate_key, [])
    self._gate_decisions_consumed.setdefault(gate_key, 0)
    consumed = self._gate_decisions_consumed[gate_key]
    await workflow.wait_condition(
        lambda: len(self._gate_decisions[gate_key]) > consumed or self.cancelled)
    if self.cancelled:
        self._status = CANCELLED; return "cancelled"
    entry = self._gate_decisions[gate_key][consumed]
    if len(entry) == 5:                      # newer 5-tuple signal payload
        decision, actor, reason, reason_category, card_decisions = entry
    else:                                    # legacy 3-tuple fallback
        decision, actor, reason = entry[0], entry[1], entry[2]
        reason_category = None; card_decisions = []
    self._gate_decisions_consumed[gate_key] = consumed + 1
    self._pending_gate = None; self._status = RUNNING
    if decision == GateStatus.APPROVED:
        self._rework_feedback.pop(gate_key, None)
        stripped = (reason or "").strip()
        if stripped:                         # approve-with-guidance
            self._approval_feedback[gate_key] = {"gate":gate_key,"approved_by":actor,
                "guidance":stripped,"approved_at":_now_iso()}
        else:
            self._approval_feedback.pop(gate_key, None)
        return "approved"
    # rejection:
    self._approval_feedback.pop(gate_key, None)
    rework_targets = rework_targets_from_card_decisions(card_decisions)   # dependency-closure step ids to rerun
    self._rework_feedback[gate_key] = {"gate":gate_key,"rejected_by":actor,"reason":reason,
        "reason_category":reason_category,"card_decisions":card_decisions,
        "rework_targets":rework_targets,"rejected_at":_now_iso()}
    return "rejected"
```
⚠️ **GOTCHA — per-gate consume counters.** `_gate_decisions` and `_gate_decisions_consumed` are dicts keyed by gate_key so G-RR and G-DA decisions land independently and don't block each other. The wait condition fires when `len(queue) > consumed` (a NEW decision arrived) OR `cancelled`. ⚠️ The 5-tuple-vs-3-tuple branch is a replay-determinism concern: old signal payloads must still parse, so reproduce the `len(entry) == 5` dispatch.
⚠️ Decisions arrive via `@workflow.signal gate_approved` / `gate_rejected` carrying a `gate_id` whose prefix disambiguates G-RR from G-DA (`wave_rationalization.py:25-28`); a `_register_gate_key(gate_id, "G-RR"|"G-DA")` map (`wave_rationalization.py:1109`, `2030`, `2681`) translates the UUID gate_id → gate_key. G-DA is a **dual-signal** gate: it also waits on `stakeholder_approved` (`wave_rationalization.py:2910` `await workflow.wait_condition(lambda: self._stakeholder_approved or self.cancelled)`).

### B.4.2 The gate→next-line transition (Rationalization → Architecture)
After G-DA approves and per-app side-effects are projected, the terminal step of `WaveRationalizationWorkflow` hands off (`wave_rationalization.py:3122-3170`):
```
if workflow.patched("wave-arch-coordinator-v1"):                         # ⚠️ current path
    terminal = await self._handoff_to_architecture_coordinator(input)
    self._status = COMPLETED; self._progress_pct = 100.0
    self._current_step = terminal; return terminal
if workflow.patched("wave-rationalization-architecture-dispatch-v1"):    # ⚠️ legacy inline fan-out (replay only)
    terminal = await self._execute_architecture_data_fanout(input, per_app_results)
    self._status = COMPLETED if terminal in ("completed","dispatched") else FAILED
    self._current_step = "architecture-dispatched" if terminal=="dispatched" else terminal
    return terminal
self._status = COMPLETED; self._current_step = "completed"; return "completed"
```
⚠️ **GOTCHA — `workflow.patched(...)` selects the topology and is REPLAY-CRITICAL.** New runs take `wave-arch-coordinator-v1` (the patch returns True at the head of run history); in-flight pre-patch workflows replay the legacy inline fan-out. Reproduce BOTH branches with `workflow.patched` guards or you break determinism for in-flight executions.

`_handoff_to_architecture_coordinator` (`wave_rationalization.py:3172-3250`):
```
coordinator_workflow_id = f"wave-architecture-{input.wave_id}"
coordinator_input = WaveArchitectureWorkflowInput(wave_id, wave_name, portfolio_id,
    app_ids=list(input.app_ids), artifact_repo, stakeholder, fixture_scenarios=dict(...))
try:
    await workflow.start_child_workflow("WaveArchitectureWorkflow", coordinator_input,
        id=coordinator_workflow_id,
        parent_close_policy=workflow.ParentClosePolicy.ABANDON)   # ⚠️ ABANDON → coordinator outlives Rationalization
except Exception as exc:
    workflow.logger.error("wave-arch-coordinator start failed", extra={...})
    return "architecture-coordinator-start-failed"               # ⚠️ does NOT roll back Rationalization success
try:
    await workflow.execute_activity(update_wave_architecture_workflow_id,
        UpdateWaveArchitectureWorkflowIdInput(wave_id, architecture_workflow_id=coordinator_workflow_id),
        start_to_close_timeout=30s, retry_policy=RETRY_POLICIES["transient"], activity_id=...)
except Exception as exc:
    workflow.logger.warning("update_wave_architecture_workflow_id failed", extra={...})  # best-effort projection
return "architecture-coordinator-started"
```
⚠️ **GOTCHA — `ParentClosePolicy.ABANDON`.** The coordinator child is abandoned so Rationalization can complete cleanly at G-DA approval; the coordinator owns wave-grain target-state mapping + pre-dispatch hold + per-target fan-out. The coordinator's handle is persisted on `wave.architecture_workflow_id` for signal/query routing.
⚠️ **GOTCHA — start failure is NON-fatal.** A handle collision logs an error and returns `"architecture-coordinator-start-failed"` but does NOT fail Rationalization — the operator retries via a future `/start-architecture` endpoint.

### B.4.3 WaveArchitectureWorkflow's own gate sequence (commit-after-validate, then pre-dispatch hold)
The coordinator (`wave_architecture.py`) itself enforces completeness before fanning out:
1. `target-state-mapper` emits `architecture-target-plan.json`; if no plan file → `ApplicationError("target-state-mapper did not emit {filename}", non_retryable=True)` (`wave_architecture.py:386-390`).
2. **Strict schema validation** (B.3.2) — fail loud on drift.
3. Commit the plan to `artifact_repo@main` (`wave_architecture.py:412-429`).
4. `_await_pre_dispatch_confirmation` — park on `wait_condition(lambda: self._pre_dispatch_confirmed or self._cancel_all_children_requested)` (`wave_architecture.py:437-447`). ⚠️ A human operator may edit the committed plan on `main` before confirming.
5. `_provision_and_spawn` — re-read the (possibly edited) plan from Git; if `targets` empty/not-list → `ApplicationError("...has no targets", non_retryable=True)` (`wave_architecture.py:464-472`); provision targets in parallel via `asyncio.gather(..., return_exceptions=True)` (per-target failure surfaces in `_dispatch_status`, doesn't abort the wave); then spawn per-target Architecture+Data children.

### B.4.4 Discovery → Rationalization is DELIBERATELY NOT auto-started (`discovery.py:558-571`)
```
# on G-DC approval, after merge + score + status flip to discovery_complete:
# Do NOT auto-start Rationalization. Rationalization is a wave-scoped line —
# apps in a wave are analysed together so cross-app redundancy + scoring is comparable.
# The wave owner starts WaveRationalizationWorkflow from the UI when every app in
# the wave has completed Discovery.
# Previously Discovery fired start_next_line_workflow here, which kicked off a per-app
# RationalizationWorkflow and broke wave scoping (observed on CFWheels 2026-05-05).
self._status = WorkflowStatus.COMPLETED; self._progress_pct = 100.0
self._current_step = "completed"; return "completed"
```
⚠️ **GOTCHA — Discovery completes and STOPS.** The Discovery→Rationalization edge is **operator-triggered from the UI**, not an automatic line transition. A regeneration that auto-fires `start_next_line_workflow` from Discovery's G-DC approval REINTRODUCES a known bug (wave-scoping breakage on CFWheels). The gate (G-DC) gates only the merge+completion of Discovery, not the start of Rationalization.

⚠️ On G-DC rejection (`discovery.py:573-589`): `_bump_rework("G-DC")`; if `_rework_count("G-DC") > MAX_REWORK_ITERATIONS` → `WorkflowStatus.FAILED`, status `discovery_failed`/`max-rework-exceeded`, `return "failed"`; else re-run the parallel passes with feedback and loop back to synthesis.

---

## B.5 — The Linear Handoff Activity: `start_next_line_workflow` (`line_transitions.py:106-216`)

This is the **other** topology — a thin, side-effect-only activity that starts the next per-line workflow for the **legacy/linear (non-wave) path** and flips the application row so the dashboard reflects the handoff. "The activity is deliberately thin — it is a side effect, not a policy. Callers decide *which* line comes next" (`line_transitions.py:11-12`).

### B.5.1 The line→workflow map (`line_transitions.py:81-85`)
```
_LINE_TO_WORKFLOW = {
    "Discovery":       "DiscoveryWorkflow",
    "Rationalization": "RationalizationWorkflow",
    "Modernization":   "ModernizationWorkflow"}
```
⚠️ **GOTCHA — only THREE lines are mappable here.** Architecture, Data, Validation, Deployment, Disposition Execution, Sustainment, Governance are NOT in `_LINE_TO_WORKFLOW`. Calling `start_next_line_workflow(next_line="Architecture")` raises `NonRetryableError("No Temporal workflow registered for line 'Architecture'")`. Those lines are reached via the wave-orchestrator child-spawn path (B.4) and `update_application_line_projection` (the non-spawning projection used by the post-G-DA Architecture/Data fan-out — `types.py:1765-1786`), NOT through this activity.

### B.5.2 Full logic (`line_transitions.py:106-216`)
```
async start_next_line_workflow(input: StartNextLineInput) -> StartNextLineResult:
    workflow_name = _LINE_TO_WORKFLOW.get(input.next_line)
    if workflow_name is None:
        raise NonRetryableError(f"No Temporal workflow registered for line {input.next_line!r}")
    try:
        app_uuid = uuid.UUID(input.app_id)
    except (ValueError, TypeError) as exc:
        raise NonRetryableError(f"Invalid app_id: {input.app_id!r}") from exc

    conn = await asyncpg.connect(_db_url())
    try:
        row = await conn.fetchrow(
            "SELECT a.name, a.portfolio_id, a.repo_url, a.target_repo_url, "
            "a.architecture_blueprint_ref, p.artifact_repo_url "
            "FROM application a JOIN portfolio p ON p.id = a.portfolio_id WHERE a.id = $1",
            app_uuid)
    finally:
        await conn.close()
    if row is None:
        raise NonRetryableError(f"Application {input.app_id} not found")

    run_ts = int(datetime.now(timezone.utc).timestamp())
    line_slug = input.next_line.lower().replace(" ", "-")
    workflow_id = f"{line_slug}-{input.app_id}-{run_ts}"

    prior_artifacts: list[str] = []
    if row.get("architecture_blueprint_ref"):                 # ⚠️ carry the Architecture spec downstream
        prior_artifacts.append(row["architecture_blueprint_ref"])

    client = await Client.connect(_temporal_host(), namespace=_temporal_namespace())
    await client.start_workflow(workflow_name,
        {"app_id": str(app_uuid), "app_name": row["name"], "wave_id": "",
         "portfolio_id": str(row["portfolio_id"]),
         "artifact_repo": row["artifact_repo_url"] or "",
         "source_repo": row["repo_url"] or "",
         "target_repo_url": row.get("target_repo_url") or "",
         "prior_artifacts": prior_artifacts},
        id=workflow_id, task_queue=input.task_queue)

    conn = await asyncpg.connect(_db_url())                   # ⚠️ SECOND connection (first already closed)
    try:
        status = f"{line_slug.replace('-', '_')}_in_progress"
        await conn.execute(
            "UPDATE application SET current_status=$1, current_line=$2, current_step=NULL, "
            "workflow_id=$3, updated_at=$4 WHERE id=$5",
            status, input.next_line, workflow_id, datetime.now(timezone.utc), app_uuid)
    finally:
        await conn.close()

    logger.info("Started next line workflow", extra={...})
    return StartNextLineResult(workflow_id=workflow_id, line=input.next_line)
```
- `StartNextLineInput` (`types.py:1742-1754`): `app_id: str`, `next_line: str` (an AssemblyLineName value, e.g. `"Rationalization"`), `task_queue: str`.
- `StartNextLineResult` (`types.py:1757-1762`): `workflow_id: str`, `line: str`.

⚠️ **GOTCHA — `workflow_id` is time-stamped and NOT idempotent.** `workflow_id = f"{line_slug}-{app_id}-{run_ts}"` embeds a UNIX timestamp. Re-invoking this activity (e.g. on Temporal activity retry) at a different second produces a DIFFERENT workflow_id and would start a SECOND child workflow. The activity is therefore declared with non-retryable errors on the unknown-line/missing-app paths so retries don't re-fire — but a transient mid-activity failure between `start_workflow` and the UPDATE could still leave a started workflow with a stale DB row. Reproduce the timestamp-in-id construction exactly (it is what the dashboard keys on).
⚠️ **GOTCHA — `line_slug` transforms differ for the id vs. the status.** The workflow_id slug uses `lower().replace(" ", "-")` (hyphens), but the status string uses `line_slug.replace("-", "_")` + `"_in_progress"` (underscores). So `"Disposition Execution"` → workflow_id slug `disposition-execution`, status `disposition_execution_in_progress`. (For the 3 mappable lines there are no spaces, but reproduce both transforms.)
⚠️ **GOTCHA — `prior_artifacts` carries the Architecture blueprint ref.** The downstream workflow (Modernization) receives `application.architecture_blueprint_ref` in `prior_artifacts`; Modernization's Extract/Design/Generate factory uses it as the target-state contract. Empty for apps that haven't traversed G-02, in which case Modernization falls back to source-only Ralph Loop (`line_transitions.py:153-162`). The downstream consumer threads `prior_artifacts` into `input_artifacts` for the agent (`architecture.py:758` `prior_inputs = list(input.prior_artifacts)`, `architecture.py:1437`).
⚠️ **GOTCHA — TWO separate asyncpg connections.** The read (app resolution) and the write (row flip) each open+close their own connection, with the `client.start_workflow` happening BETWEEN them while NO connection is held. Reproduce the open→close→start→open→close sequence; do not collapse into one connection (the original deliberately doesn't hold the DB connection across the Temporal client call).
⚠️ Env-derived config: `_db_url()` builds `postgresql://{user}:{password}@{host}:{port}/{db}` from `DATABASE_HOST`/`PORT`/`USER`/`PASSWORD`/`NAME` (defaults `localhost`/`5432`/`olympus`/`olympus`/`olympus`); `_temporal_host()` = `TEMPORAL_HOST` (default `temporal:7233`); `_temporal_namespace()` = `TEMPORAL_NAMESPACE` (default `default`) (`line_transitions.py:88-103`).

---

## B.6 — The Dependency Model: `depends_on` and How a Line May Start

### B.6.1 Where the model is declared (the 10 line YAMLs)
Each line YAML declares `depends_on`/`inputs`/`outputs`/`mode`. ⚠️ This is the source of truth; the registry (`AssemblyLine.depends_on`, PART A §A.2.4) is derived from it at import. FIELD-LEVEL reproduction of the dependency graph (verified from `olympus-contracts/olympus_contracts/data/assembly-lines/*.yaml`):

| Line | `mode` | `depends_on` |
|---|---|---|
| **Discovery** | `per-app` | `[]` (entry point) |
| **Rationalization** | `per-wave` | `[Discovery]` |
| **Architecture** | `per-target-app` | `[Rationalization]` |
| **Data** | `per-target-app` | `[Rationalization]` |
| **Modernization** | `per-target-app` | `[Architecture, Data]` |
| **Validation** | `per-app` | `[Modernization]` |
| **Deployment** | `per-app` | `[Validation, Disposition Execution]` |
| **Disposition Execution** | `per-app` | `[Rationalization]` |
| **Sustainment** | `continuous` | `[Deployment, Disposition Execution]` |
| **Governance** | `continuous` | `[]` |

⚠️ **GOTCHA — `Data.depends_on` in the YAML is `[Rationalization]` only**, NOT `[Discovery, Architecture]` as `overview.md:14` narrates. The YAML is authoritative for the registry. (Data *consumes* `target-application-map` from Architecture via its `inputs`, but its declared `depends_on` is Rationalization — Architecture and Data both spawn from the post-G-DA coordinator and run in parallel, so Data does not formally depend on Architecture in the registry.) Reproduce the YAML value.
⚠️ **GOTCHA — Modernization is the only line with TWO upstream deps** (`[Architecture, Data]`) — it cannot start until BOTH complete. Deployment also has two (`[Validation, Disposition Execution]`), and Sustainment has two (`[Deployment, Disposition Execution]`).
⚠️ Mode values seen: `per-app`, `per-wave`, `per-target-app`, `continuous` — these are exactly the four members of `_VALID_MODES` (PART A §A.2.2). The registry validator rejects any other mode.

### B.6.2 The full inputs/outputs wiring (artifact-level coupling)
The `inputs`/`outputs` lists are the artifact-name contract; a consumer's `inputs` must be produced by some upstream line's `outputs`. FIELD-LEVEL (verified from the YAMLs):

**Discovery** — `inputs: [legacy-source, documentation, stakeholder-context]`; `outputs: [application-catalog-entry, tech-fingerprint, structural-analysis, business-logic, quality-risk, ux-accessibility, data-domains, shared-db-analysis, capability-catalog, discovery-synthesis, tco-baseline]`.

**Rationalization** — `inputs: [discovery-synthesis, catalog-application, business-logic, structural-analysis, ux-accessibility, quality-risk, tco-baseline]`; `outputs: [redundancy-matrix, consolidation-report, ux-overlap-matrix, intra-app-redundancy, integration-graph, portfolio-redundancy-matrix, disposition-recommendation, disposition-governance, user-impact-analysis, classification, complexity-classification, portfolio-score, capability-consolidation-plan, wave-plan, wave-plan-validation, factory-routing, wave-outcome-synthesis, portfolio-manifest]`.

**Architecture** — `inputs: [disposition-recommendation, disposition-governance, redundancy-matrix, catalog-application, tco-baseline, structural-analysis, business-logic, ux-accessibility]`; `outputs: [target-application-map, cloud-pattern, deployment-topology, target-architecture-blueprint, ea-compliance, integration-arch, resilience-matrix, security-arch, cato-evidence-seed, design-system, accessibility-review, ai-ml-integration, architecture-blueprint, blueprint-summary, cost-estimate, well-architected-review, traceability-validation]`.

**Data** — `inputs: [target-application-map, catalog-application, structural-analysis, business-logic, wave-plan, cloud-pattern, integration-arch]`; `outputs: [data-domains, shared-db-analysis, decomposition-strategy, co-wave-constraints, data-migration-plan, data-product-design, data-architecture, data-architecture-summary]`.

**Modernization** — `inputs: [architecture-blueprint, target-application-map, integration-arch, data-architecture, data-migration-plan, business-logic, structural-analysis, catalog-application]`; `outputs: [pre-processing, business-rules, test-scenarios, user-guide, extraction-report, traceability-matrix, module-map, context-map, openapi, event-contracts, api-coverage, data-model, ddl, batch-design, design-review, generated-application, security-posture, adversarial-review, gate-review-package]`.

**Validation** — `inputs: [gate-review-package, architecture-blueprint, data-architecture, accessibility-review, security-arch, cato-evidence-seed, data-migration-plan, ux-accessibility, quality-risk, structural-analysis, business-logic, integration-arch, design-system]`; `outputs: [parity-report, api-contract-report, external-consumer-compat, acceptable-divergences, security-assessment-report, ssp, poam, authorization-recommendation, accessibility-audit, design-system-compliance, uat-results, training-package, g-v1-evidence, g-v2-evidence, safety-case, ivnv-results, traceability-report, safety-impact-assessment, g-v3-evidence, test-plan, remediation-plan]`.

**Deployment** — `inputs: [parity-report, authorization-recommendation, disposition-output, deployment-topology, rollback-plan, tco-baseline, adoption-baseline, data-migration-plan]`; `outputs: [deployment-manifest, smoke-test-results, traffic-shift-log, parallel-run-report, adoption-verification, gate-review-package-g-dp1, decommission-certificate, license-reclamation-record, cost-savings-certification, gate-review-package-g-dp2]`.

**Disposition Execution** — `inputs: [disposition-recommendation, disposition-governance, catalog-application, structural-analysis, business-logic, ux-accessibility, tco-baseline]`; `outputs: [disposition-output]`.

**Sustainment** — `inputs: [wave-plan, sustainment-handoff, deployment-env-status, catalog-application, tco-baseline]`; `outputs: [cve-triage, incident-response, sla-monitoring, change-conflict, cost-anomaly, sweep-summary]`.

**Governance** — `inputs: [wave-plan, sweep-summary, architecture-blueprint, data-architecture, cost-savings-certification, pattern-extraction, ralph-loop-metrics, escalation-record]`; `outputs: [drift-detection, pattern-extraction, latest-patterns, health-report, skill-evolution, factory-capacity, model-evaluation, sweep-summary]`.

⚠️ **GOTCHA — Governance both consumes AND produces `pattern-extraction` and `sweep-summary`.** These appear in BOTH its `inputs` and `outputs` — it is a continuous, self-feeding line (the compound-growth flywheel). This is intentional, not a typo; reproduce both lists with the overlap.
⚠️ GOTCHA — artifact-name vs. filename mismatch: `inputs`/`outputs` use logical artifact NAMES (e.g. `catalog-application`, `application-catalog-entry`), which are NOT always the validation FILENAMES in `_SCHEMA_REGISTRY` (e.g. `application-catalog-entry.json` → `catalog.schema.json`). The dependency model is name-based; validation routing is filename-based. Keep these two namespaces distinct.

### B.6.3 How the orchestrator decides a line may start
Olympus has NO standalone "dependency scheduler" that polls `depends_on` and auto-launches lines. The decision is **encoded structurally** in two layers (`overview.md:24-32`, `assembly-lines/overview.md:149-158`):

1. **The dependency graph is declarative metadata** (`depends_on` in the YAML → `AssemblyLine.depends_on` in the registry). It documents the partial order and is what `Registry._assert_no_cycle` (PART A §A.1.4) guards against cycles in. It is consumed for **display/validation**, not for runtime scheduling dispatch.
2. **Runtime advancement is gate-driven and orchestrator-coded:**
   - **Within a wave** (live path): `WaveRationalizationWorkflow` runs the per-app pipelines and, at G-DA approval, spawns `WaveArchitectureWorkflow` (B.4.2), which spawns per-target Architecture+Data children, which (on G-02 approval) lead into Modernization. Each edge is a `workflow.start_child_workflow` call guarded by a `_wait_for_gate` approval. The "decision" that a line may start = "the upstream line's gate was approved AND (for the coordinator) the operator confirmed dispatch."
   - **Linear path** (legacy): a workflow explicitly calls `start_next_line_workflow(next_line=...)`; the activity's only "may start" check is `next_line in _LINE_TO_WORKFLOW` and `application` row exists. There is no `depends_on` consultation at this seam — the *caller* is responsible for only calling it when upstream is done.
   - **Operator-gated edges** (Discovery→Rationalization): the wave owner manually starts `WaveRationalizationWorkflow` from the UI once every app in the wave has completed Discovery (B.4.4). No automatic transition.

⚠️ **GOTCHA — there is no central "ready check" function.** A regeneration that builds a `can_line_start(line, completed_lines)` predicate from `depends_on` and auto-dispatches would be a *different system*. The actual coupling is: (a) declarative `depends_on` for the graph + cycle-safety, (b) gate-approval signals (`_wait_for_gate`) as the real "go" condition, (c) explicit child-spawn / `start_next_line_workflow` calls hard-coded in the orchestrator workflows. The "orchestrator decides" via the COMBINATION of patched topology selection + gate signals + hard-coded successor calls — not by interpreting the dependency YAML at runtime.
⚠️ **GOTCHA — parallelism is structural, not scheduled.** "Architecture and Data can run concurrently once Rationalization completes" (`overview.md:28`) happens because the post-G-DA coordinator spawns BOTH as children (parallel `asyncio.gather`), NOT because a scheduler noticed both had satisfied `depends_on`. "Continuous lines" (Sustainment, Governance) run as separate long-lived/cron workflows that never block the per-app pipeline (`overview.md:31`).

### B.6.4 Traceability (the 4th contract leg)
Every artifact references its source inputs, enabling end-to-end evidence chains (`overview.md:156`). Mechanically: agent dispatches carry `input_artifacts` (the upstream artifact paths the agent read) onto the `StepExecutionContext.input_artifact_paths`, which `_emit_git_start` resolves via `resolve_input_artifacts(ctx.input_artifact_paths, repo=..., ref=branch or "main")` into `StepArtifactRef(repo, ref, path)` rows on the step_execution record (`git_operations.py:76-101`). So each produced artifact's execution row records the exact `(repo, ref, path)` of every input it consumed — the citation chain `{repo}:{file}` is materialised in the execution-record projection, not in the artifact file itself. (Detailed execution-record schema is Phase 4/9.)

---

## B.7 — Line-to-Line Contract: Parity Checklist

| Concern | Mechanism | Source |
|---|---|---|
| Producer write | `write_artifact` / `write_artifacts_batch` → feature branch, idempotent commit | `git_operations.py:217-320` |
| Move to consumable state | `create_pr` → gate approval → `merge_pr` / `reconcile_and_merge_pr` to `main` | `git_operations.py:323-540` |
| Consumer read | `read_artifact(repo, branch="main", path)` — pure fetch, no validation, re-raises on I/O error | `git_operations.py:168-214` |
| Validation chokepoint | `validate_artifact_against_schema` — never raises on validation outcome; `NonRetryableError` only on missing schema | `artifact_validation.py:379-432` |
| Artifact→schema routing | `_SCHEMA_REGISTRY` keyed by filename; adding an entry auto-enables validation | `artifact_validation.py:124-346` |
| Advisory escalation | `_validate_artifact_or_warn` — logs + stashes warnings; swallows even `ActivityError` | `wave_rationalization.py:4764-4838` |
| Strict escalation | `not validated OR errors` → `ApplicationError(non_retryable=True)` (interprets `validated=False` as failure) | `wave_architecture.py:402-407` |
| Optional read | broad `except` → typed fallback (`[]` / `["default"]` / `return`) | `architecture.py:628`, `modernization.py:1911` |
| Gate gating | `_wait_for_gate(gate_key)` — per-gate consume counters, 5/3-tuple signal, approve-with-guidance / rework | `wave_rationalization.py:5258-5333` |
| Gate→next-line (wave) | `workflow.patched(...)` topology select → `start_child_workflow(..., ABANDON)` | `wave_rationalization.py:3139-3250` |
| Next-line (linear) | `start_next_line_workflow` via `_LINE_TO_WORKFLOW` (3 lines only); timestamped non-idempotent workflow_id | `line_transitions.py:81-216` |
| Dependency graph | declarative `depends_on` in YAML → registry; cycle-guarded; NOT a runtime scheduler | `*.yaml`, `overview.md:24-32` |
| Traceability | `input_artifacts` → `StepArtifactRef(repo, ref, path)` on execution record | `git_operations.py:76-101` |

⚠️ **The ONE-LINE contract:** producer commits to a feature branch → PR → gate approval merges to `main` → consumer reads `(repo, "main", path)` → consumer chooses advisory (warn) or strict (`ApplicationError`) validation against `_SCHEMA_REGISTRY[filename]` → next line is started either by a gate-gated `start_child_workflow` (wave path) or an explicit `start_next_line_workflow` (linear path), NEVER by an automatic `depends_on`-driven scheduler.

---

# PART C — THE FULL FAA PROFILE  →  SPLIT INTO `regen/07-framework-faa-profile.md`

> ⚠️ **POINTER.** SECTION C (the gate-target, exhaustive field-level reproduction of the entire FAA client-profile bundle plus the four loaders and the override-boundary) is **maintained in a separate file** because of its length:
>
> **`/Users/pnunna/Documents/GitHub/foundry/regen/07-framework-faa-profile.md`**
>
> It covers, at FIELD LEVEL with `path:line` citations and ⚠️ GOTCHAs:
>
> | § | Contents |
> |---|---|
> | C.0 | The FOUR independent loaders for the same bundle and their DISTINCT env vars (`OLYMPUS_PROFILE`+`OLYMPUS_PROFILES_DIR` for registry overlays; `OLYMPUS_PROFILE_ROOT` for mission context; `SKILLS_ROOT` for skill bootstrap) — read first |
> | C.1 | `profile.yaml` — id/name/version, organization, portfolio, extensions, 9 skills, templates, branding, deployment, devsecops, inherits/overlays, mission_context (every key + EFFECT; flags fields the typed loader DROPS into `raw_profile_yaml`) |
> | C.2 | `compliance.yaml` — 5 domains (accessibility/security/enterprise_architecture/coding/safety) every framework/control, 5 `regulatory_sources` CFR parts, branding |
> | C.3 | `risk-classification.yaml` — 3 tiers (all parameters), 8 signals, 4 override_rules (with `enforced` flags); ⚠️ HARD 3-tier constraint |
> | C.4 | `gates.yaml` — 8 gate overrides (every `faa_additions` check + `reviewer_override`), 3 additional_roles, per-tier SLA |
> | C.5 | `scoring.yaml` — 6 dimensions; ⚠️ WEIGHT-SUM PROOF `0.15+0.15+0.25+0.10+0.10+0.25 = 1.00` (confirmed == `total_weight`) |
> | C.6 | `technology.yaml` — infrastructure/data/messaging/document_management/low_code/modernization_targets/phase3_prototype(dropped)/tyrion_requirements |
> | C.7 | `wave-planning.yaml` — cadence, concurrent_wave_limit, sizing bands, 5 constraints, compound_growth, composition_factors (weights sum 1.0) |
> | C.8 | `delegation.yaml` — flat `fallback_policy: internal_fallback` (+ the 4 allowed values) |
> | C.9 | `objectives.yaml` — 8 SOO objectives (ids/KPIs/targets/baselines/contributes_from) + `baselines/2024.yaml` |
> | C.10 | `config/*.yaml` — `common.yaml` shared vars + 16 skill-named overlay files (⚠️ actual count is 17, not "11"; brief discrepancy noted) + `identity.yaml` OIDC config |
> | C.11 | branding asset spec, mission-context loader pseudocode (`profile_context.py`), `context-priors/manifest.yaml`, regulatory-knowledge structure (parts 47/61/63/67/183) |
> | C.12 | HOW a profile loads & overlays apply — `load_profile`/`activate_profile`/`discover_profile_root` pseudocode + the complete cross-process load+overlay ORDERING + skill-bootstrap overlay merge |
> | C.13 | ⚠️ CAN-vs-CANNOT override — the hard core constants: 3 tiers, 7 dispositions, 15 gates, 10 lines, 4 gate providers, mode/state enums, weight-sum==1.0, 6 required files, `Profile` immutability |
> | C.14 | FAA profile parity checklist |
>
> ⚠️ **KEY CROSS-PART FACT:** `apply_profile` (PART A §A.8.3) mutates ONLY the scoring, gate-provider, and skill-composition registries. Everything else in the FAA bundle (compliance, risk tiers, technology, wave-planning, SLA, additional_roles, objectives, regulatory_sources, branding, delegation) is DATA consumed by the API/dashboard/agent-runtime/exec-microsite/human-reviewers — NOT by the workflow registries. The 3 untouched extension points (assembly-line, disposition, analysis-pass) receive no FAA override today.

---

# PART D — RISK-TIER, DISPOSITION, AND GATE MODELS

> The three core vocabularies. For each: WHERE the canonical values live, the decisive HARD-ENUM-vs-DATA classification, the relevant DB representation, the "flexibility migration" question (enum→varchar/CHECK), and the extension-point / profile relationship. ⚠️ This part is the runbook's authority on what an extension can change WITHOUT touching code vs. what requires a code change + migration.

**Files covered in this part:**

| File | Lines | Role |
| --- | --- | --- |
| `olympus-contracts/olympus_contracts/enums.py` | 240 | Canonical Python enums: `Disposition`, `RiskTier`, `GateType` (+`GATE_FRIENDLY_NAMES`, `GATE_ASSEMBLY_LINES`, `gate_friendly_name`, `gate_assembly_line`, `GateStatus`, `AssemblyLine`, `ComplexityTier`, `Archetype`, `TierSource`) |
| `db/alembic/versions/001_create_enum_types.py` | 115 | Native PostgreSQL ENUM TYPE creation: `risk_tier_enum`, `disposition_enum`, `gate_type_enum`, `gate_status_enum`, +9 more |
| `db/alembic/versions/002_create_core_tables.py` | 123 | `application` table — `risk_tier` (ENUM), `disposition` (ENUM) columns |
| `db/alembic/versions/003_create_workflow_tables.py` | 142 | `gate` table — `gate_type` (ENUM), `status` (ENUM) columns |
| `db/alembic/versions/013,019,040` | — | `ALTER TYPE gate_status_enum ADD VALUE` — the ONLY enum-extension migrations (gate STATUS, not gate TYPE) |
| `db/alembic/versions/020,029` | — | varchar/TEXT columns deliberately NOT enums (`reject_reason_category` TEXT, `disposition_source` varchar(16)) |
| `db/alembic/versions/050,052` | — | varchar + CHECK-constraint columns enumerating the 7 dispositions (capability / rat-cap grain) |
| `temporal/olympus_workflows/registries/disposition.py` | 492 | Disposition Strategy Registry (Extension Point 2) — DATA layer over the 7-value vocabulary; registers 5 of 7 |
| `temporal/olympus_workflows/registries/gate_provider.py` | 408 | Gate Provider Registry (Extension Point 5) — see PART A §A.6 |
| `temporal/olympus_workflows/activities/classification.py` | 211 | `persist_classification` — HOW a risk tier is assigned + validated + written |
| `profiles/faa/risk-classification.yaml` | 130 | FAA's per-tier parameters, auto-classification signals, override rules (3 tiers, profile-supplied) |
| `profiles/faa/gates.yaml` | (full in PART C §C.4) | FAA gate overrides — `faa_additions` + `reviewer_override`, parsed by `_apply_gates` (PART A §A.8.4) |
| `olympus-contracts/olympus_contracts/assembly_lines.py` | 13202 B | `GateRef` + `_parse_gates` — gate SET is declared per-line in the 10 line YAMLs |

⚠️ **GOTCHA — there are TWO layers per model, and they DIVERGE in extensibility:** the **Python contract enum** (`enums.py`, a hard compile-time `StrEnum`/`IntEnum`) AND the **DB representation** (mostly native PostgreSQL ENUM TYPE; in a few newer columns varchar+CHECK or bare varchar/TEXT). A claim like "dispositions are an enum" is incomplete: the *vocabulary* (7 names) is a hard enum at BOTH layers for the core columns, but the *disposition-strategy registry* (Extension Point 2) is DATA, and a few peripheral columns store dispositions as varchar+CHECK. Keep all three facts distinct.

---

## D.0 — Decisive Enum-vs-Data Verdict (read first)

| Model | Python contract layer (`enums.py`) | Core DB column(s) | "Flexibility migration" (enum→varchar/CHECK)? | Extension-point / profile layer | **VERDICT** |
|---|---|---|---|---|---|
| **Risk tier** | `RiskTier(enum.IntEnum)` {1,2,3} — `enums.py:33-43`. HARD. | `application.risk_tier` = native `risk_tier_enum` `('1','2','3')` — `001:23`, `002:25,89` | **NO.** Never converted. Still native ENUM. Extending to a 4th tier = `ALTER TYPE` + `enums.py` edit + Pydantic recompile. | TIER DEFINITIONS (labels, parameters, classification signals, override rules) come from the **profile** (`profiles/faa/risk-classification.yaml`), NOT core. The 3-tier *count* is core. | ⚠️ **HARD ENUM (count + values); DATA (tier semantics via profile).** The number of tiers is compile+migration-locked at 3; what each tier *means* is profile-driven. |
| **Disposition** | `Disposition(enum.StrEnum)` 7 values — `enums.py:15-30`. HARD. | `application.disposition` = native `disposition_enum` (7 values) — `001:39-43`, `002:32-36,96`; `gate`/lineage read it too. | **NO** for the core `application.disposition` column (stays native ENUM — explicitly confirmed `029:74-78`). **PARTIAL** elsewhere: newer capability/rat-cap columns use **varchar + CHECK listing all 7** (`050:294-305`, `052:179-184`); `disposition_source` is bare varchar(16) (`029:68`). | Disposition **Strategy** Registry (Extension Point 2, `disposition.py`) is DATA: 5 of 7 registered at import, profile-overridable via `register()`. But it does NOT define the 7-value vocabulary. | ⚠️ **HARD ENUM (the 7 names, at contract + core DB); DATA (the per-disposition *workflow/steps* via the registry).** Adding an 8th disposition = `enums.py` + `ALTER TYPE disposition_enum ADD VALUE` + every CHECK constraint (050/052) + a registry strategy. |
| **Gate** | `GateType(enum.StrEnum)` 15 values — `enums.py:80-106`. HARD. | `gate.gate_type` = native `gate_type_enum` (15 values) — `001:46-53`, `003:17-24,66` | **NO.** `gate_type_enum` was NEVER altered or converted (grep confirms zero `ALTER TYPE gate_type_enum` / zero varchar gate_type). Only `gate_status_enum` (a DIFFERENT enum) got `ADD VALUE` migrations (013/019/040). | The gate SET (which gates a line owns) is declared per-line in the 10 line YAMLs as `GateRef` (`assembly_lines.py:106-110`, `_parse_gates:247-255`). The **Gate Provider** (HOW a gate is decided) is Extension Point 5 (DATA, profile `default_provider` + per-gate `faa_additions`/`reviewer_override`). | ⚠️ **HARD ENUM (the 15 gate IDs, at contract + DB); DATA (which provider decides each gate + FAA additions/reviewers via profile; which line owns each gate via YAML).** Adding a 16th gate = `enums.py` + `ALTER TYPE gate_type_enum ADD VALUE` + `GATE_FRIENDLY_NAMES` + `GATE_ASSEMBLY_LINES` + a line YAML `gates:` entry. |

⚠️ **THE FLEXIBILITY-MIGRATION HEADLINE (what the runbook asked for):** For the THREE core vocabularies (risk-tier, disposition, gate-type) the codebase **NEVER performed an enum→varchar conversion**. All three remain native PostgreSQL ENUM TYPEs created once in migration `001` and never altered (disposition/gate-type) or only value-added on a *sibling* enum (`gate_status_enum`, not `gate_type_enum`). The places where the code DID choose varchar-over-enum for flexibility are **peripheral, newer columns** — and even there, dispositions are still guarded by a CHECK constraint enumerating the same 7 values (so it is varchar-storage but NOT a loosened vocabulary). See D.4 for the precise list. **Do not regenerate any of the three core columns as varchar; reproduce them as native ENUM.**

---

## D.1 — RISK TIER

### D.1.1 Canonical definition (`enums.py:33-43`)
```python
class RiskTier(enum.IntEnum):
    """Risk classification tiers. 1 = Critical, 2 = Standard, 3 = Low-Risk."""
    TIER_1 = 1
    TIER_2 = 2
    TIER_3 = 3
```
⚠️ **GOTCHA — `IntEnum`, not `(int, Enum)`.** Chosen so Temporal's default payload converter round-trips the value across workflow input boundaries (the converter special-cases `IntEnum`/`StrEnum` subclasses) — `enums.py:35-39`. A regeneration using `class RiskTier(int, Enum)` would break Temporal serialization. Reproduce `enum.IntEnum` exactly.
⚠️ **GOTCHA — values are the INTEGERS 1/2/3, but the DB enum stores the STRINGS `'1'/'2'/'3'`.** `risk_tier_enum` is `CREATE TYPE risk_tier_enum AS ENUM ('1', '2', '3')` (`001:22-24`) — string labels, not smallint. The classification activity bridges this: it computes `risk_int = int(risk)`, validates `risk_int in (1,2,3)`, then writes `validated_risk = str(risk_int)` (a STRING) into the column (`classification.py:108-110, 121`), and reads it back as `int(validated_risk)` for the typed result (`classification.py:167`). Reproduce the int↔str bridge precisely; writing an integer to the column would fail the enum cast.

### D.1.2 DB representation
- `application.risk_tier` → `risk_tier_enum` (nullable) — `002:89`.
- `application.risk_tier_source` → `tier_source_enum` `('auto','confirmed','overridden')` (nullable) — `001:32-36`, `002:90`.
- `application.complexity_tier` → `complexity_tier_enum` `('simple','moderate','complex')` — `002:91` (the parallel `ComplexityTier` StrEnum, `enums.py:46-55`).
- Index `ix_application_risk_tier` on `application(risk_tier)` — `005:30`.
- ⚠️ No CHECK constraint on `risk_tier` anywhere; the native enum IS the constraint.

### D.1.3 Where tier DEFINITIONS come from — PROFILE, not core (`profiles/faa/risk-classification.yaml`)
The core framework fixes the 3-tier *count* but supplies ZERO semantics. The FAA profile's `risk-classification.yaml` provides everything domain-specific, under `risk_classification:` (FIELD-LEVEL reproduced in PART C §C.3; summarised here for the model):
- `profile: "faa"`, `domain_label: "NAS Safety Tiering"` (`risk-classification.yaml:5-6`).
- `tiers.tier_1` / `tier_2` / `tier_3` — each with `label`, `definition`, `examples[]`, and a `parameters` block (`traceability_forward/backward`, `test_coverage_overall/domain`, `parallel_run_days`, `parallel_run_monitoring`, `deployment_strategy`, `traffic_shift`, `rollback_window_days`, `ivv_required`, `safety_case_required`, `safety_board_review`, `model_tier`, `security_safety_crosswalk`, `nas_impact_assessment`, `stakeholder_confirmation`) — `risk-classification.yaml:9-90`.
- `signals[]` — 8 auto-classification heuristics each `{signal, tier_suggestion, confidence}` (e.g. name contains ATC/radar → tier_1/high) — `risk-classification.yaml:92-117`.
- `override_rules[]` — 4 rules each `{rule, enforced}` (+ optional `note`); 3 are `enforced: true` (NAS-DB-write ⇒ T1-min; T1 ⇒ Safety-Board confirmation; T1-downgrade ⇒ Safety-Board approval), 1 advisory `enforced: false` — `risk-classification.yaml:119-129`.

⚠️ **GOTCHA — the YAML tier keys are `tier_1/tier_2/tier_3` (string), the enum values are `1/2/3` (int), the DB labels are `'1'/'2'/'3'` (string).** Three different spellings for the same three tiers. The profile YAML is consumed by the API/agent-runtime/human-reviewers (NOT by the workflow registries — risk tiers are NOT one of the 6 extension points). The classification SKILL reads the profile's signals/parameters when proposing a tier; the activity below only validates/persists the proposed integer.

### D.1.4 HOW classification assigns a tier — `persist_classification` (`classification.py:69-171`)
The Rationalization line (Step 5, Classification & Risk Tiering) dispatches a classification skill whose JSON output is persisted by this activity. The tier is NOT computed in Python — the *agent skill* proposes it; Python validates+writes it.
```
async persist_classification(input: PersistClassificationInput) -> PersistClassificationResult:
    try: app_uuid = uuid.UUID(input.app_id)
    except (ValueError, TypeError) as exc:
        raise NonRetryableError(f"Invalid app_id: {input.app_id!r}") from exc      # bad id → non-retryable

    parsed = _parse_classification(input.classification_json)     # markdown-prose-tolerant JSON parse
    if not parsed:                                                # unparseable → write NOTHING, tier_1_flag=False
        logger.warning("persist_classification: unparseable skill output", extra={app_id})
        return PersistClassificationResult(app_id=input.app_id)   # (all other fields default: None/""/False)

    complexity = parsed.get("complexity_tier")
    risk       = parsed.get("risk_tier")
    archetype  = parsed.get("archetype")
    tier_1_flag = bool(parsed.get("tier_1_flag"))

    # VALIDATE — only write what looks valid:
    validated_complexity = complexity if complexity in _COMPLEXITY else None   # {"simple","moderate","complex"}
    try:
        risk_int = int(risk) if risk is not None else None
        validated_risk = str(risk_int) if risk_int in (1, 2, 3) else None       # ⚠️ clamp to 1/2/3 → STRING
    except (TypeError, ValueError):
        validated_risk = None                                                   # non-int risk → dropped
    validated_archetype = archetype if archetype in _ARCHETYPES else None        # {web-app,batch-etl,api-service,scheduled-job,hybrid}

    # Build a DYNAMIC SET clause — partial classifications land the fields they got right:
    set_parts = []; params = []
    if validated_risk is not None:
        set_parts += [f"risk_tier = ${n}", f"risk_tier_source = ${n+1}"]; params += [validated_risk, "auto"]
    if validated_complexity is not None:
        set_parts += [f"complexity_tier = ${...}", f"complexity_tier_source = ${...}"]; params += [validated_complexity, "auto"]
    if validated_archetype is not None:
        set_parts += [f"archetype = ${...}", f"archetype_source = ${...}"]; params += [validated_archetype, "auto"]

    if not set_parts:                                            # nothing valid → write NOTHING
        logger.warning("persist_classification: no valid fields to write", extra={app_id, parsed})
        return PersistClassificationResult(app_id=input.app_id)

    set_parts.append(f"updated_at = ${...}"); params += [now_utc, app_uuid]
    sql = f"UPDATE application SET {', '.join(set_parts)} WHERE id = ${len(params)}"
    conn = await asyncpg.connect(_db_url())
    try:    await conn.execute(sql, *params)
    finally: await conn.close()
    return PersistClassificationResult(app_id, risk_tier=int(validated_risk) if validated_risk else None,
        complexity_tier=validated_complexity or "", archetype=validated_archetype or "", tier_1_flag=tier_1_flag)
```
- `_COMPLEXITY = {"simple","moderate","complex"}` (`classification.py:46`); `_ARCHETYPES = {"web-app","batch-etl","api-service","scheduled-job","hybrid"}` (`classification.py:39-45`).
- `_parse_classification(raw)` (`classification.py:49-66`): `json.loads` if str; on `JSONDecodeError`, brace-scan `raw[raw.find("{") : raw.rfind("}")+1]` and retry; returns `{}` on any failure (treated as no-op).

⚠️ **GOTCHA — invalid tier values are SILENTLY DROPPED, not rejected.** A `risk_tier` of `4`, `0`, `"high"`, or `None` makes `validated_risk = None`, so the SET clause simply omits `risk_tier` (the column keeps its prior value, likely NULL). The activity never raises for a bad tier — it logs and writes a partial/empty update. Reproduce this best-effort-write semantics; the source-of-truth constraint is the agent skill + the DB enum cast, not this validator.
⚠️ **GOTCHA — `*_source` is hard-coded `"auto"` on every write here.** The activity always stamps `risk_tier_source="auto"`. The `confirmed`/`overridden` transitions happen elsewhere: `confirm_classification_tier_1` (`classification.py:174-211`) flips `risk_tier_source='confirmed'` ONLY for rows where `risk_tier='1' AND risk_tier_source='auto'` (idempotent — a row already `overridden` is untouched), after a stakeholder signs off on a Tier-1 assignment via `StakeholderApprovedSignal`.
⚠️ **GOTCHA — Tier-1 gates the pipeline.** `tier_1_flag=True` (from the skill output, NOT derived from `risk_tier==1`) tells the calling workflow to pause for `StakeholderApprovedSignal` (scope `"tier-1-classification"`) before proceeding past Discovery/classification — `classification.py:78-80`, and the wave/rationalization workflows' `scope == "tier-1-classification"` handling (`wave_rationalization.py:5766`, `rationalization.py:687`). This implements the FAA `override_rules` "T1 requires Safety Board confirmation" rule, but the *enforcement* is in the workflow, keyed off the skill's `tier_1_flag`.

### D.1.5 Risk-tier extensibility verdict
- **Count (3):** HARD. Compile-time `IntEnum` + native DB enum + `'1'/'2'/'3'` labels baked into migration 001 and the classification clamp `risk_int in (1,2,3)`. A 4th tier requires: `enums.py` edit, `ALTER TYPE risk_tier_enum ADD VALUE '4'`, the classification clamp tuple, and any Pydantic models — a code change.
- **Semantics (labels, parameters, signals, override rules):** DATA — fully profile-driven (`risk-classification.yaml`), swappable without touching core.

---

## D.2 — DISPOSITION

### D.2.1 Canonical definition — confirm the 7 (`enums.py:15-30`)
```python
class Disposition(enum.StrEnum):
    """The 7 application dispositions."""
    RETIRE = "Retire"
    RETAIN = "Retain"
    REFACTOR = "Refactor"
    REARCHITECT = "Rearchitect"
    REPLACE = "Replace"
    REPLATFORM = "Replatform"
    CONSOLIDATE = "Consolidate"
```
✅ **Confirmed 7, exactly: Retire, Retain, Refactor, Rearchitect, Replace, Replatform, Consolidate** — matching CLAUDE.md's writing guideline. Canonical home is `enums.py:24-30`; re-exported through `olympus-api/src/models/common.py:17` and consumed by olympus-api, olympus-worker, olympus-workflows, and the MCP server.
⚠️ **GOTCHA — `StrEnum` (Temporal round-trip), values are TITLE-CASE.** `"Retire"` not `"retire"`. The DB enum, the registry strategy `label`s, and all 7 CHECK-constraint string literals all use the SAME title-case spelling. ⚠️ One known wart: lineage rows store "legacy lowercase values alongside title-case ones" so `LineageEdge.disposition` is typed as a raw `str | None` not the enum (`application.py:629-634`) — a deliberate exception to avoid an enum-parse failure on legacy data.

### D.2.2 DB representation
- `application.disposition` → native `disposition_enum` (7 values, `001:38-43`), nullable — `002:32-36,96`.
- `disposition_enum` definition: `CREATE TYPE disposition_enum AS ENUM ('Retire','Retain','Refactor','Rearchitect','Replace','Replatform','Consolidate')` — `001:39-43`. Same 7, same order, same casing as the Python enum.
- `application.disposition_source` → **bare `varchar(16)`, NO enum, NO CHECK** — `029:68`. Values `auto`/`overridden`/`confirmed`/NULL validated only at the API layer. ⚠️ This is a deliberate varchar-not-enum choice (mirrors `tier_source` semantically but was added as varchar for flexibility — `029:18-25` docstring).
- `application.disposition_rationale_ref` → `TEXT` (artifact path) — `029:72`.
- `application.disposition_current_status` → `varchar(64)` (disposition-execution projection) — `034:77`.

### D.2.3 The disposition REGISTRY (Extension Point 2) — DATA layer, registers 5 of 7
⚠️ **GOTCHA — THE registry confirms 5, not 7, are registered.** `disposition.py:9-14` and `register_default_strategies` (`disposition.py:474-484`) register ONLY the **five non-modernization** dispositions: **Retire, Retain, Replace, Replatform, Consolidate** (insertion order `_DEFAULT_STRATEGIES = (_RETIRE, _RETAIN, _REPLACE, _REPLATFORM, _CONSOLIDATE)`, `disposition.py:465-471`). **Refactor and Rearchitect are intentionally absent** — they flow through `ModernizationWorkflow`, and `DispositionWorkflow` short-circuits them BEFORE registry lookup (`disposition.py:147-149` `MODERNIZATION_DISPOSITIONS = {"Refactor", "Rearchitect"}`; rejected at `disposition.py:259`). See PART A §A.3.4–A.3.5 for the full FIELD-LEVEL StepSpec tables of all 5 strategies.
- **Relationship to the vocabulary:** the registry's `DispositionStrategy.label` values are a SUBSET of the 7-value enum, but the registry does NOT *define* the vocabulary — the enum + DB type do. The registry defines, per disposition, the *workflow steps, skills, artifacts, and gates* (HOW that disposition is executed). It is DATA: profile-overridable via `register()` (idempotent, later-wins), though the FAA profile ships no disposition override today (PART A §A.8.3 — `apply_profile` does not touch the disposition registry).
- ⚠️ **GOTCHA — Retire is NOT a safe default.** `DISPOSITION_REGISTRY.get(unknown_label)` RAISES `UnknownDispositionError` rather than defaulting (`disposition.py:203-218`, doc `26-29`) — decommissioning is destructive, so unknown dispositions must fail loudly.

### D.2.4 ⚠️ The "flexibility migration" for disposition — varchar+CHECK, but NOT on the core column
This is the most nuanced part of the runbook's question. The answer is **bidirectional**:

**(a) Core column STAYS native enum — explicitly chosen NOT to migrate.** Migration 029's docstring describes `disposition` as "VARCHAR(16)" (`029:18`) — but that is ASPIRATIONAL/wrong: the `upgrade()` body adds only `disposition_source` + `disposition_rationale_ref`, and a comment explicitly states `application.disposition` "already exists from migration 002 as the disposition_enum column. This migration only adds the source + rationale_ref columns... Revisit during the cross-line side-effect sweep (P5-S19.13) if the existing column type needs tightening" (`029:74-78`). So the core `application.disposition` was NEVER converted to varchar. ⚠️ GOTCHA: do not trust the 029 docstring's "VARCHAR(16)" for `disposition`; trust the code — it is `disposition_enum`.

**(b) NEWER capability/rat-cap columns DID use varchar + CHECK enumerating all 7 — the actual "flexibility move."** When the rationalization-capability / system-grain layer was added (Phase 5, migrations 050 & 052), those NEW disposition-bearing columns were declared as `String` with a CHECK constraint rather than reusing `disposition_enum`:
- Migration **050** (`capability` table) — `capability.primary_disposition` and `capability.secondary_disposition`, each guarded by:
  ```
  sa.CheckConstraint(
      "primary_disposition IS NULL OR primary_disposition IN "
      "('Retire', 'Retain', 'Refactor', 'Rearchitect', "
      "'Replace', 'Replatform', 'Consolidate')",
      name="capability_primary_disposition_chk")          # 050:294-299
  # and capability_secondary_disposition_chk              # 050:300-305
  ```
- Migration **052** (`rationalization_capability` table) — `rationalization_capability.disposition`:
  ```
  sa.CheckConstraint(
      "disposition IS NULL OR disposition IN ("
      "'Retire', 'Retain', 'Refactor', 'Rearchitect', "
      "'Replace', 'Replatform', 'Consolidate')",
      name="rationalization_capability_disposition_chk")   # 052:179-184
  ```
- The SQL VIEWs over these (`050:290-301`, `052:180`) also embed the same `IN (...)` 7-value list.

⚠️ **GOTCHA — varchar+CHECK is varchar STORAGE but NOT a loosened vocabulary.** Even on these "flexible" columns, the CHECK constraint still enumerates the SAME 7 disposition strings. So adding an 8th disposition would still require editing every one of these CHECK constraints (a migration) PLUS `enums.py` PLUS `ALTER TYPE disposition_enum ADD VALUE`. The varchar choice bought *projection convenience* (avoiding the native-enum cast friction in views and supporting legacy lowercase) — NOT vocabulary extensibility. The disposition vocabulary remains a HARD 7 everywhere it is constrained.

### D.2.5 Disposition extensibility verdict
- **The 7-value vocabulary:** HARD ENUM at the contract layer (`enums.py`), the core DB column (`disposition_enum`), AND the varchar+CHECK peripheral columns (all list the same 7). Adding an 8th = code change + `ALTER TYPE` + edit 3+ CHECK constraints (050 ×2, 052) + any views.
- **Per-disposition execution plan (steps/skills/artifacts/gates):** DATA — the Disposition Strategy Registry (Extension Point 2), 5 of 7 registered, profile-overridable without code (no override shipped).

---

## D.3 — GATES

### D.3.1 Canonical definition — confirm the 15 (`enums.py:80-106`)
```python
class GateType(enum.StrEnum):
    """The 15 standard gate identifiers. The enum value is the stable code."""
    G_DC = "G-DC";   G_RR = "G-RR";   G_DA = "G-DA";   G_02 = "G-02";   G_DT = "G-DT"
    G_04A = "G-04a"; G_04B = "G-04b"; G_04C = "G-04c"
    G_DE_1 = "G-DE-1"; G_DE_2 = "G-DE-2"
    G_V1 = "G-V1";   G_V2 = "G-V2";   G_V3 = "G-V3"
    G_DP_1 = "G-DP-1"; G_DP_2 = "G-DP-2"
```
✅ **Confirmed 15, exactly: G-DC, G-RR, G-DA, G-02, G-DT, G-04a, G-04b, G-04c, G-DE-1, G-DE-2, G-V1, G-V2, G-V3, G-DP-1, G-DP-2** — matching the prompt and CLAUDE.md. Canonical home `enums.py:92-106`.
⚠️ **GOTCHA — the enum VALUE is the stable code (e.g. `"G-DC"`), used in URLs, Git commits, contract schemas, registry IDs, and DB columns; "it MUST NOT be renamed without a migration"** (`enums.py:83-86`). The Python member NAME mangles the code (`G_04A` ↔ `"G-04a"`, `G_DE_1` ↔ `"G-DE-1"`) — hyphens and lowercase letters can't be Python identifiers. Reproduce the name↔value mapping table EXACTLY (note `G-04a/b/c` are lowercase-suffixed; `G-02` has a leading zero; the rest are uppercase).

### D.3.2 Two companion tables + two resolvers (`enums.py:122-197`)
⚠️ These are part of the gate model and MUST be reproduced (they are the default human-facing label + owning-line resolution):

**`GATE_FRIENDLY_NAMES: dict[GateType, str]`** (`enums.py:122-138`) — plain-English label per gate. FIELD-LEVEL (all 15):
| GateType | friendly name |
|---|---|
| `G_DC` | `Discovery Complete` |
| `G_RR` | `Portfolio Rationalization Approval` |
| `G_DA` | `Disposition Plan Approval` |
| `G_02` | `Architecture Alignment Review` |
| `G_DT` | `Data Architecture Review` |
| `G_04A` | `Extracted Specifications Review` |
| `G_04B` | `Modernization Design Review` |
| `G_04C` | `Generated Code Review` |
| `G_DE_1` | `Disposition Execution Plan Approval` |
| `G_DE_2` | `Decommission Readiness Sign-off` |
| `G_V1` | `Functional Parity Confirmation` |
| `G_V2` | `Compliance & Security Certification` |
| `G_V3` | `Safety Assurance Sign-off` |
| `G_DP_1` | `Production Deployment Approval` |
| `G_DP_2` | `Legacy Decommission Authorization` |
⚠️ Must be kept in sync with `dashboard/src/data/gateMetadata.ts` (`GATE_METADATA`), `dashboard/src/config/glossary.ts` (`GLOSSARY`), and `cross-cutting/gates/README.md` (Unified Gate Registry table) — `enums.py:114-119`.

**`GATE_ASSEMBLY_LINES: dict[GateType, str]`** (`enums.py:167-183`) — owning assembly line per gate (the single source of truth replacing a former hardcoded `"Discovery"` default that was wrong for 10 of 15 gates — `enums.py:157-165`). FIELD-LEVEL:
| GateType | owning line | | GateType | owning line |
|---|---|---|---|---|
| `G_DC` | `Discovery` | | `G_DE_1` | `Disposition Execution` |
| `G_RR` | `Rationalization` | | `G_DE_2` | `Disposition Execution` |
| `G_DA` | `Rationalization` | | `G_V1` | `Validation` |
| `G_02` | `Architecture` | | `G_V2` | `Validation` |
| `G_DT` | `Data` | | `G_V3` | `Validation` |
| `G_04A` | `Modernization` | | `G_DP_1` | `Deployment` |
| `G_04B` | `Modernization` | | `G_DP_2` | `Deployment` |
| `G_04C` | `Modernization` | | | |

**Resolvers (both accept enum OR raw string; both have defensive fallbacks):**
```
gate_friendly_name(gate_type) -> str:                       # enums.py:141-154
    try: key = GateType(gate_type)
    except ValueError: return str(gate_type)                # unknown code → echo raw (keeps logs readable)
    return GATE_FRIENDLY_NAMES.get(key, str(gate_type))

gate_assembly_line(gate_type) -> str:                       # enums.py:186-197
    try: key = GateType(gate_type)
    except ValueError: return "Discovery"                    # ⚠️ unknown code → "Discovery" (legacy-row safety)
    return GATE_ASSEMBLY_LINES.get(key, "Discovery")
```
⚠️ **GOTCHA — the two fallbacks DIFFER.** `gate_friendly_name` falls back to the RAW code string; `gate_assembly_line` falls back to the literal `"Discovery"`. Both swallow `ValueError` so an extension-registry gate the core enum doesn't yet know still renders. Reproduce the asymmetry.

### D.3.3 DB representation
- `gate.gate_type` → native `gate_type_enum` (15 values, `001:46-53`), `nullable=False` — `003:66`.
- `gate.status` → native `gate_status_enum`, `nullable=False`, default `'pending'` — `003:71-72`.
- `gate_type_enum` definition: `CREATE TYPE gate_type_enum AS ENUM ('G-DC','G-RR','G-DA','G-02','G-DT','G-04a','G-04b','G-04c','G-DE-1','G-DE-2','G-V1','G-V2','G-V3','G-DP-1','G-DP-2')` — `001:46-53`. Exact 15, exact order/casing as the Python enum.
- Index `ix_gate_gate_type` on `gate(gate_type)` — `005:38`.
- ⚠️ NO varchar gate_type, NO CHECK on gate_type anywhere (grep-confirmed zero hits for `gate_type.*String|gate_type.*Text|gate_type.*sa\.Enum|gate_type.*IN`).

### D.3.4 ⚠️ Flexibility-migration finding for gates: gate_type NEVER moved; only gate_STATUS got `ADD VALUE`
- **`gate_type_enum`: NEVER altered.** No migration ever runs `ALTER TYPE gate_type_enum`, converts it to varchar, or adds a CHECK. The 15 codes are frozen at migration 001. Adding a 16th gate = `enums.py` + `ALTER TYPE gate_type_enum ADD VALUE '<code>'` + `GATE_FRIENDLY_NAMES` + `GATE_ASSEMBLY_LINES` + a line-YAML `gates:` entry. HARD ENUM.
- **`gate_status_enum`: THIS is the enum that got the `ADD VALUE` migrations** (a DIFFERENT enum — gate *decision state*, not gate *identity*). Three migrations append values, all idempotent via `ADD VALUE IF NOT EXISTS` and all noting "PostgreSQL does not support removing values from enums" in `downgrade()`:
  - `013_add_gate_escalated_status.py:21` → `ALTER TYPE gate_status_enum ADD VALUE IF NOT EXISTS 'escalated'`
  - `019_add_gate_preparing_status.py:24` → `... ADD VALUE ... 'preparing'`
  - `040_add_gate_merge_blocked.py:48-50` → `... ADD VALUE ... 'merge_blocked'` (+ adds `gate.merge_failure_detail` JSONB column)
  - Net `GateStatus` (`enums.py:200-219`): `preparing, pending, approved, rejected, overridden, escalated, merge_blocked` (7 values). The migration-001 base was only `('pending','approved','rejected','overridden')` (`001:55-59`); 013/019/040 grew it.
- ⚠️ **GOTCHA — `gate.reject_reason_category` was deliberately TEXT, not an enum** (`020_add_gate_reject_reason_category.py:13-15`): "stored as plain TEXT (not an enum) so Phase 3 gate implementers can refine per-gate without forcing an ALTER TYPE. Validation lives in the API layer (Pydantic Literal)." The API `RejectReasonCategory` Literal is `{"evidence-incomplete","policy-violation","needs-rework","escalate"}` (`olympus-api/src/models/gate.py:18-23`), but each gate MAY refine it. This is a genuine *enum→varchar-for-flexibility* design decision — but on a category field, NOT on `gate_type`. The runbook's "where did code move from enum→varchar" answer for gates is: **`reject_reason_category` (chose TEXT from the start, 020) — never `gate_type`.**

### D.3.5 Where the gate SET is defined (which gates exist + which line owns them)
Two complementary sources:
1. **The 15-value enum** (`enums.py`) is the closed vocabulary of gate IDs (+ `GATE_ASSEMBLY_LINES` for ownership).
2. **The per-line YAML `gates:` block** declares which gates a line emits, parsed into `GateRef` records by the contract loader. `GateRef` (`assembly_lines.py:105-110`): `@dataclass(frozen=True, slots=True)` with `id: str`, `label: str = ""`. `_parse_gates(raw)` (`assembly_lines.py:247-255`):
   ```
   raw = raw or []
   out = []
   for g in raw:
       if isinstance(g, str):  out.append(GateRef(id=g))                          # bare "G-DC"
       elif isinstance(g, dict): out.append(GateRef(id=g["id"], label=g.get("label", "")))  # {id, label}
   return tuple(out)
   ```
   ⚠️ GOTCHA — `_parse_gates` accepts a gate id that is NOT in the `GateType` enum (it does no enum validation — just stores the string). So a line YAML COULD declare a custom gate id and the contract loader would carry it; the enum is enforced only at the DB column and wherever code constructs `GateType(...)`. The `AssemblyLine.gates` registry field (PART A §A.2.4) is `tuple(g.id for g in line.gates)` — the GateRef ids.

### D.3.6 The Gate PROVIDER (Extension Point 5) and profile gate overrides — how they interact
This is the DATA layer of the gate model (full mechanics in PART A §A.6 and §A.8.4):
- **Gate Provider Registry** (`gate_provider.py`) holds 4 built-in providers (`github-pr` default, `automated-only`, `servicenow` stub, `jira` stub) + a `_default_provider_id` + a `_gate_overrides: dict[gate_id → {...}]`. A provider decides HOW a gate is approved (PR merge / predicate evaluation / external ticket).
- **Profile interaction — `_apply_gates`** (`profile_overrides.py:202-226`, PART A §A.8.4): at worker startup `apply_profile` reads `profile.gates` and:
  1. If `gates.default_provider` is set: validate it `registry.has(...)` (else raise plain `ValueError` "...not registered. Known providers: ..."); then `registry.set_default(default_provider)`. FAA sets `default_provider: "github-pr"` (`profiles/faa/gates.yaml:8`) — same as the built-in default, so a no-op set.
  2. `registry.clear_gate_overrides()` — wipe prior per-gate overrides FIRST.
  3. For each `override` in `gates.overrides`: `registry.set_gate_overrides(override.gate_id, {"faa_additions": list(override.faa_additions), "reviewer_override": dict(override.reviewer_override)})`.
- **FAA's gate overrides** (`profiles/faa/gates.yaml:13+`, full in PART C §C.4): a MAPPING `gate_id → {faa_additions[], reviewer_override{}}` for **G-DC, G-DA, G-02, G-04b, G-04c, G-V2** (and more — 8 total per PART C). Each `faa_additions` entry is `{check, description, applies_to, automated}`; each `reviewer_override` maps a tier/disposition key → reviewer-role list (e.g. `G-DC.reviewer_override.tier_1: ["portfolio_manager","safety_board_liaison"]`).
- ⚠️ **GOTCHA — profile gate overrides ADD criteria + reviewers to EXISTING gates; they do NOT create new gate IDs.** `faa_additions` are extra checks layered onto a standard gate; `reviewer_override` swaps the reviewer roster for a tier/disposition. The 15-gate set is unchanged by the profile. So: gate IDENTITY = hard enum (core); gate CRITERIA/REVIEWERS/PROVIDER = DATA (profile-driven, no code change).
- ⚠️ **GOTCHA — the worker parses `gates.overrides` as a MAPPING, the API loader as a tuple of records** (PART A §A.9.3, `worker_bootstrap.py:166-174`). The FAA `gates.yaml` MUST express `overrides:` as a `{gate_id: body}` mapping (it does — `gates.yaml:13` onward) or the worker's `isinstance(overrides_block, dict)` check fails and ALL overrides are silently dropped. Reproduce overrides as a mapping.

### D.3.7 Gate extensibility verdict
- **The 15 gate IDs + their friendly names + owning lines:** HARD ENUM (`enums.py` + native `gate_type_enum` + the two companion dicts). A 16th gate = code change + migration + companion-dict edits + line-YAML edit.
- **Gate decision STATE (`gate_status_enum`):** semi-hard — extended 3× by `ALTER TYPE ... ADD VALUE` migrations (013/019/040), so adding a state is a migration + `GateStatus` enum edit (no varchar conversion).
- **Gate reject-reason category:** DATA-ish — TEXT column (020), validated by an API Pydantic Literal that each gate may refine. The genuine enum→varchar flexibility move in the gate model.
- **Which provider decides each gate + FAA criteria/reviewer additions:** DATA — Gate Provider Registry (Extension Point 5) + profile `gates.yaml`, no code change.

---

## D.4 — Cross-Model Flexibility-Migration Ledger (the runbook's core question, consolidated)

| Column / type | Migration | Storage | Constraint | Flexibility classification |
|---|---|---|---|---|
| `risk_tier_enum` type | 001:22-24 | native ENUM `'1','2','3'` | enum IS the constraint | HARD — never altered |
| `application.risk_tier` | 002:89 | `risk_tier_enum` | — | HARD |
| `disposition_enum` type | 001:38-43 | native ENUM (7 title-case) | enum IS the constraint | HARD — never altered |
| `application.disposition` | 002:96 | `disposition_enum` | — | HARD — 029 docstring says "VARCHAR(16)" but code keeps it ENUM (`029:74-78`) |
| `application.disposition_source` | 029:68 | `varchar(16)` | none (API Pydantic only) | **varchar-for-flexibility** (source field, not the disposition itself) |
| `capability.primary_disposition` | 050 | `String` | CHECK IN (7 dispositions) — `050:294-299` | **varchar+CHECK** — storage flexible, vocabulary still hard 7 |
| `capability.secondary_disposition` | 050 | `String` | CHECK IN (7 dispositions) — `050:300-305` | **varchar+CHECK** — vocabulary still hard 7 |
| `rationalization_capability.disposition` | 052 | `String` | CHECK IN (7 dispositions) — `052:179-184` | **varchar+CHECK** — vocabulary still hard 7 |
| `gate_type_enum` type | 001:46-53 | native ENUM (15 codes) | enum IS the constraint | HARD — never altered |
| `gate.gate_type` | 003:66 | `gate_type_enum` | — | HARD |
| `gate_status_enum` type | 001:55-59 | native ENUM | enum IS the constraint | semi-hard — `ADD VALUE` ×3 (013,019,040): +escalated, +preparing, +merge_blocked |
| `gate.reject_reason_category` | 020:30-32 | `TEXT` | none (API Pydantic Literal) | **enum→varchar-for-flexibility** (the genuine move; never an enum) |
| `archetype_enum` type | 021:36-41 | native ENUM (5) | enum IS the constraint | HARD (parallel `Archetype` StrEnum, `enums.py:58-69`) |

⚠️ **Bottom line for the runbook:** the three core vocabularies (risk-tier / disposition / gate-type) are **hard enums at the contract AND core-DB layers and were NEVER subjected to an enum→varchar flexibility migration.** The only places the code chose varchar over a native enum are: (1) `reject_reason_category` TEXT (gate model — chose TEXT from the start for per-gate refinement, migration 020); (2) `disposition_source` varchar(16) (no constraint, migration 029); (3) the capability/rat-cap disposition columns varchar+CHECK (migrations 050/052 — storage-flexible but the CHECK still enumerates the same 7, so NOT a loosened vocabulary). The flexible/extensible behavior for all three models lives in the **profile + registries**, not in column types: risk-tier *semantics* via `risk-classification.yaml`; disposition *execution plans* via the Disposition Strategy Registry; gate *providers/criteria/reviewers* via the Gate Provider Registry + `gates.yaml`.
