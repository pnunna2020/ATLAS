# Regeneration Spec — Phase 8 API (Portfolio, Lines & Misc Routers)

ATOMIC regeneration specification. Premise: source is deleted; this is the only surviving artifact. Behavioral parity bar.

Covers 16 routers under `olympus-api/src/routers/` (was 15; `admin_audit.py` added at HEAD `7cb3b20c`):
`portfolio.py`, `portfolio_members.py`, `lines.py`, `profiles.py`, `system.py`, `health.py`, `artifacts.py`, `renditions.py`, `agents.py`, `agent_runs.py`, `admin.py`, `admin_audit.py`, `activity.py`, `events.py`, `git.py`, `human_paired_agent.py`.

---

## 0. Shared infrastructure (MUST reproduce — every endpoint depends on it)

### 0.1 Auth — `src/middleware/auth.py`

`class CurrentUser` (`auth.py:32`):
- `__init__(self, sub: str, roles: list[RBACRole], claims: dict)` → attributes `sub`, `roles`, `claims`.
- `has_role(self, *roles: RBACRole) -> bool` → `any(r in self.roles for r in roles)` (`auth.py:40`).

Module env (read at import, `auth.py:26-29`):
- `_JWT_SECRET = os.environ.get("JWT_SECRET", "olympus-dev-secret")`
- `_JWT_ALGORITHM = os.environ.get("JWT_ALGORITHM", "HS256")`
- `_AUTH_SKIP_VERIFICATION = os.environ.get("AUTH_SKIP_VERIFICATION", "true").lower() == "true"`
- `_DEV_AUTH_BYPASS = os.environ.get("DEV_AUTH_BYPASS", "").lower() == "true"`

`async get_current_user(request: Request) -> CurrentUser` (`auth.py:52`):
```
if _DEV_AUTH_BYPASS:
    return CurrentUser(sub="local-dev", roles=list(RBACRole),
                       claims={"sub": "local-dev", "dev_bypass": True})
token = bearer-token from "Authorization" header ("Bearer " prefix; else None)
if token is None: raise HTTPException(401, "Missing authorization token")
options = {} ; if _AUTH_SKIP_VERIFICATION: options = {verify_signature:False, verify_exp:False, verify_aud:False}
try: payload = jwt.decode(token, _JWT_SECRET, algorithms=[_JWT_ALGORITHM], options=options)
except JWTError: raise HTTPException(401, "Invalid or expired token")
sub = payload.get("sub", "anonymous")
roles = [RBACRole(r) for r in payload.get("roles", []) if valid]  # unknown roles logged + skipped
if not roles: roles = [RBACRole.VIEWER]
return CurrentUser(sub, roles, payload)
```

`require_role(*required_roles) -> dependency` (`auth.py:106`): returns inner `_check(user=Depends(get_current_user))` that raises `HTTPException(403, f"Requires one of: {[r.value for r in required_roles]}")` if `not user.has_role(*required_roles)`; else returns `user`.

### 0.2 `RBACRole` enum (`src/models/common.py:47`, str enum)
`PORTFOLIO_ADMIN="portfolio_admin"`, `PORTFOLIO_MANAGER="portfolio_manager"`, `TECH_LEAD="tech_lead"`, `ARCH_LEAD="arch_lead"`, `COMPLIANCE_LEAD="compliance_lead"`, `OPERATIONS_LEAD="operations_lead"`, `SAFETY_BOARD="safety_board"`, `VIEWER="viewer"`, `SERVICE="service"`.

### 0.3 Dependencies — `src/dependencies.py`
- `get_config() -> AppConfig` — `@lru_cache` singleton (`dependencies.py:28`).
- `async get_temporal_client() -> Client` — module-global lazy `Client.connect(config.temporal_host, namespace=config.temporal_namespace)` cached in `_temporal_client` (`dependencies.py:34`).
- `async verify_portfolio_access(db, user, portfolio_id)` (`dependencies.py:105`): if `user.has_role(PORTFOLIO_ADMIN)` return; elif `await membership_svc.is_member(db, portfolio_id, user.sub)` return; else raise `HTTPException(403, detail={"code":"PORTFOLIO_NOT_MEMBER","message":"Caller is not a member of this portfolio. Ask a portfolio_admin to grant access."})`.
- `async require_application_member(app_id: Path uuid, user=Depends(get_current_user), db=Depends(get_db)) -> CurrentUser` (`dependencies.py:136`): if admin return user; else `await verify_application_portfolio_access(...)`; return user. `verify_application_portfolio_access` (`:184`): admin→None; else `SELECT portfolio_id FROM application WHERE id=:aid`; None→`HTTPException(404,"Application not found")`; then `verify_portfolio_access`.
- `async filter_portfolio_ids_by_membership(db, user, candidate=None) -> list[uuid]|None` (`dependencies.py:389`): admin→`None` (means "no filter"); else `member_ids = membership_svc.list_user_portfolio_ids(db, user.sub)`; if candidate None → member_ids; else intersection.

### 0.4 Error envelope — `src/middleware/error_handler.py`
`class OlympusHTTPException(StarletteHTTPException)` (`error_handler.py:20`): `__init__(status_code, code, message, details=None)` → super with `detail=message`; sets `.code`, `.error_details`.
Global handlers serialize ALL errors to:
```json
{"error": {"code": "...", "message": "...", "details": {...}, "request_id": "..."}}
```
- `OlympusHTTPException` → uses its `.code` + `.error_details`.
- `StarletteHTTPException` → code from map {400:BAD_REQUEST,401:UNAUTHORIZED,403:FORBIDDEN,404:NOT_FOUND,409:CONFLICT,422:VALIDATION_ERROR,429:RATE_LIMITED} else "ERROR"; `details={}`.
- `RequestValidationError` → 422 `VALIDATION_ERROR` "Request validation failed", `details={"errors":[...]}` (ctx/input coerced to str/repr if non-JSON).
- bare `Exception` → 500 `INTERNAL_ERROR` "An internal error occurred".

### 0.5 Router mount order (`src/main.py:176-219`) — ⚠️ GOTCHA: order matters for path-prefix overlap
Relevant subset, in registration order:
`health_router`(177) → `system_router`(178) → `portfolio_router`(182) → `profiles_router`(183) → `portfolio_profile_router`(184) → `events_router`(189) → `activity_router`(190) → `git_router`(193) → `lines_router`(194) → `line_start_router`(195) → `artifacts_router`(201) → `renditions_router`(205) → `agent_runs_router`(209) → `agents_router`(210) → `admin_router`(212) → `admin_audit_router`(213) → `portfolio_members_router`(214) → `human_paired_agent_router`(221). ⚠️ Mount-line numbers SHIFTED at HEAD (admin_audit_router added at `main.py:213`; all subsequent calls +1). `admin_audit_router` shares the `/api/v1/admin` prefix with `admin_router` (212) and `portfolio_members_router` (214).
⚠️ GOTCHA: `profiles_router` (`/api/v1/profiles`) registers `GET /compare` and `GET /active` BEFORE `GET /{profile_id}` so static segments win over the catch-all path param — preserve intra-router decorator order.

### 0.6 `GitService` surface used here (`src/services/git_service.py`)
- `GitServiceConfig(token, repo, base_url)`; `GitServiceError(Exception)`.
- `read_file(path, branch="main", commit_sha="") -> FileReadResult` (`:317`). `FileReadResult` has `.content` (utf-8 str), `.commit_sha`, `.path`. Raises `GitServiceError(f"File '{path}' not found on ref '{ref}': ...")` on 404.
- `validate_repo_access(*, require_push=True)` (`:699`).
- ctor raises `GitServiceError(f"Repository '{slug}' not found or token lacks access")` on a 404 from `get_repo`. Construction succeeding ⇒ repo exists.
- `._repo` is the raw PyGithub repo (used directly in artifacts router via `get_contents` / `get_commits`).

### 0.7 `AppConfig` fields referenced
`service_name`, `version`, `github_token`, `github_base_url`, `temporal_host`, `temporal_namespace`, `temporal_task_queue`, `temporal_ui_base_url`.

---

## 1. `portfolio.py` — prefix `/api/v1/portfolio`, tags `["portfolio"]`  (4 endpoints)

Module state: `_portfolios: dict[str, dict] = {}` (`portfolio.py:41`) — in-memory store keyed by portfolio-id string; used by webhook lookup + profile switch. Each record dict keys: `id, name, owner, status, artifact_repo_url, artifact_repo_default_branch, webhook_secret, profile_id`.

Helper `async hydrate_portfolios_from_db(db) -> int` (`:43`): `SELECT id,name,owner,status,artifact_repo_url FROM portfolio`; for each row not already in `_portfolios`, insert record with defaults `artifact_repo_default_branch="main"`, `webhook_secret=""`, `profile_id=""`. Returns row count. (Called from lifespan startup, not an endpoint.)

Helper `find_portfolio_by_repo(repo_full_name) -> dict|None` (`:280`): linear scan of `_portfolios.values()` matching `artifact_repo_url`. (Webhook use, not an endpoint.)

**Models** (`src/models/portfolio.py`):
- `PortfolioCreate` (`:82`): `name: str`; `owner: str`; `artifact_repo_url: str = Field(..., description="GitHub repo in 'owner/name' format for portfolio artifacts")`; `artifact_repo_default_branch: str = "main"`; `webhook_secret: str = Field(default="", description="HMAC-SHA256 secret...")`; `profile_id: str = ""`.
- `PortfolioDetail` (`:99`): `id: str`; `name: str`; `owner: str`; `status: str="active"`; `artifact_repo_url: str|None=""`; `artifact_repo_default_branch: str="main"`; `webhook_secret_configured: bool=False`; `profile_id: str=""`.
- `PortfolioListItem` (`:112`): `id: str`; `name: str`; `owner: str`; `status: str="active"`; `artifact_repo_url: str|None=""`.

### 1.1 POST `/api/v1/portfolio` → `create_portfolio` (`portfolio.py:86`)
- status_code **201**, response_model `PortfolioDetail`.
- Auth: **NONE** (no `Depends` for user — ⚠️ GOTCHA: unauthenticated create). Deps: `body: PortfolioCreate`, `db=Depends(get_db)`.
- Logic:
```
config = AppConfig()    # ⚠️ fresh instance, not get_config()
if config.github_token:
    try:
        git_svc = GitService(GitServiceConfig(token, repo=body.artifact_repo_url, base_url))
        git_svc.validate_repo_access()
    except GitServiceError as exc: raise HTTPException(422, detail=str(exc))
    except Exception as exc: log; raise HTTPException(422, f"Could not validate repository '{repo}': {exc}")
else: log warning "github_validation_skipped"
portfolio_id = uuid4(); now = utcnow()
INSERT INTO portfolio (id,name,owner,status,artifact_repo_url,created_at,updated_at)
       VALUES (:id,:name,:owner,'active',:artifact_repo_url,:now,:now)
db.commit()
# ⚠️ NEW at HEAD (P6-S8.6 / design §7.3 + OQ-4) — auto-create the recurring WEEKLY
# governance-sweep Temporal Schedule (zero-config continuous monitoring). BEST-EFFORT:
# a Temporal outage must NOT block portfolio creation.
try:
    from src.dependencies import get_temporal_client          # lazy import (portfolio.py:149)
    temporal = await get_temporal_client()
    await create_governance_schedule(temporal, str(portfolio_id), cadence="weekly", task_queue=config.temporal_task_queue)
except Exception:                                              # noqa: BLE001 — swallow + log
    logger.warning("governance_schedule_autocreate_failed", portfolio_id=str(portfolio_id), exc_info=True)
_portfolios[str(pid)] = {id,name,owner,status:"active",artifact_repo_url,
                         artifact_repo_default_branch:body.*, webhook_secret:body.*, profile_id:body.*}
return PortfolioDetail(id, name, owner, status="active", artifact_repo_url,
       artifact_repo_default_branch=body.*, webhook_secret_configured=bool(body.webhook_secret), profile_id=body.*)
```
- Status: 201, 422 (git validation), 500 (unhandled).
- ⚠️ GOTCHA — `create_governance_schedule` (imported at `portfolio.py:33` from `src/services/governance_schedule.py`) runs AFTER the DB commit and is wrapped in a bare `except Exception` so a Temporal failure logs `governance_schedule_autocreate_failed` and the 201 still returns. The schedule is later managed via `POST /governance/schedule` / `DELETE /governance/schedule/{id}` (see `01-api-governance-systems.md` §A10/§A11). Service contract: `create_governance_schedule(temporal, portfolio_id, *, cadence="weekly", task_queue, paused=False)` (`governance_schedule.py:38`) builds a `Schedule(action=ScheduleActionStartWorkflow("GovernanceWorkflow", {...}, id=f"governance-{pid}-{cadence}", task_queue), spec=ScheduleSpec(cron_expressions=[CADENCE_CRON[cadence]]), state=ScheduleState(paused=paused))`; `temporal.create_schedule(sid, schedule)` with `sid = schedule_id_for(pid, cadence) = f"gov-{cadence}-{pid}"`; idempotent — `ScheduleAlreadyRunningError` swallowed. `CADENCE_CRON = {weekly:"0 7 * * MON", quarterly:"0 7 1 */3 *"}` (`governance_schedule.py:28`).

### 1.2 GET `/api/v1/portfolio` → `list_portfolios` (`portfolio.py:190`, def `:191`)
- response_model `list[PortfolioListItem]`.
- Deps: `user=Depends(get_current_user)`, `db=Depends(get_db)`. Any authenticated user.
- Logic: `visible = await filter_portfolio_ids_by_membership(db, user)`. If `visible is None` (admin) → `SELECT id,name,owner,status,artifact_repo_url FROM portfolio ORDER BY name`. Elif `not visible` (empty) → `rows=[]`. Else → same SELECT `WHERE id = ANY(:ids) ORDER BY name`. Map each to `PortfolioListItem`.
- Status: 200, 401.

### 1.3 GET `/api/v1/portfolio/{portfolio_id}` → `get_portfolio` (`portfolio.py:235`, def `:236`)
- response_model `PortfolioDetail`. Deps: `portfolio_id: str`, `user=Depends(get_current_user)`, `db=Depends(get_db)`.
- Logic: parse `pid=uuid.UUID(portfolio_id)` (ValueError→`HTTPException(404,"Portfolio not found")`). `await verify_portfolio_access(db,user,pid)`. `SELECT * FROM portfolio WHERE id=:id`; None→404. `in_mem=_portfolios.get(str(id),{})`. Return `PortfolioDetail(id,name,owner,status,artifact_repo_url, artifact_repo_default_branch=in_mem.get(...,"main"), webhook_secret_configured=bool(in_mem.get("webhook_secret")), profile_id=in_mem.get("profile_id",""))`.
- Status: 200, 401, 403 (not member), 404.

### 1.4 GET `/api/v1/portfolio/{portfolio_id}/target-state-rollup` → `get_portfolio_target_state_rollup` (`portfolio.py:271`, def `:280`)
- `responses={200:{"model": PortfolioTargetStateRollup}}`; handler return type `dict` (service returns plain dict — NOT coerced). Deps: `portfolio_id: str`, `user=Depends(get_current_user)`, `db=Depends(get_db)`.
- Logic: parse uuid (ValueError→404 "Portfolio not found"); `verify_portfolio_access`; `return await rollup_svc.get_target_state_rollup(db, pid, get_config())`.
- **Response model `PortfolioTargetStateRollup`** (`src/models/rollup.py:74`, `ConfigDict(extra="forbid")`):
  - `portfolio_id: UUID`; `computed_at: datetime`;
  - `waves_included: list[RollupWaveIncluded]` — each: `wave_id:UUID`, `wave_number:int(ge=1)`, `wave_name:str|None`, `synthesized_at:datetime|None`, `synthesis_ref:str(min_length=1)`.
  - `waves_omitted: list[RollupWaveOmitted]` — each: `wave_id:UUID`, `wave_number:int(ge=1)`, `reason:str`.
  - `counts: RollupCounts` — `apps_total,target_state_system_count,retired,consolidated_absorbed,surviving` (all `int ge=0`).
  - `disposition_mix: RollupDispositionMix` — `Retire,Retain,Refactor,Rearchitect,Replace,Replatform,Consolidate` (all `float 0..100`, exact capitalized keys).
  - `aggregate_net_impact: AggregateNetImpact` — `annual_savings_usd:float`, `one_time_cost_usd:float`, `tier1_reduction:int`, `users_affected:int(ge=0)`.
- Status: 200, 401, 403, 404 (bad uuid; or service `PORTFOLIO_NOT_FOUND`/`PORTFOLIO_NOT_CONFIGURED`), 500 (`GIT_NOT_CONFIGURED`), 502 (`GIT_READ_FAILED`).

#### Service `target_state_rollup.get_target_state_rollup(db, portfolio_id, config) -> dict` (`src/services/target_state_rollup.py:193`) — reproduce all branches
```
_DISPOSITIONS = ("Retire","Retain","Refactor","Rearchitect","Replace","Replatform","Consolidate")
_synthesis_path(wave_id) = f"rationalization/wave-{wave_id}/wave-outcome-synthesis.json"

row = SELECT id, artifact_repo_url FROM portfolio WHERE id=:id
if row is None: raise OlympusHTTPException(404,"PORTFOLIO_NOT_FOUND", f"Portfolio {pid} not found")
artifact_repo = (row.artifact_repo_url or "").strip()
if not artifact_repo: raise OlympusHTTPException(404,"PORTFOLIO_NOT_CONFIGURED","Portfolio has no artifact repo; rollup cannot be computed.")
if not config.github_token: raise OlympusHTTPException(500,"GIT_NOT_CONFIGURED","GITHUB_TOKEN is not set on the API service.")
waves = SELECT id,wave_number,name,status,updated_at FROM wave WHERE portfolio_id=:pid ORDER BY wave_number ASC
try: svc = GitService(GitServiceConfig(token, repo=artifact_repo, base_url))
except GitServiceError as exc: raise OlympusHTTPException(502,"GIT_READ_FAILED", f"Could not access artifact repo: {exc}")
included=[]; synth_list=[]; omitted=[]
for wave in waves:
    try: synth = _read_synthesis(svc, wave.id)
    except GitServiceError as exc:    # transient backend failure
        log; omitted.append({wave_id:str, wave_number:int, reason:"read-failed"}); continue
    if synth is None:
        omitted.append({wave_id, wave_number, reason:"synthesis-not-emitted"}); continue
    synth_list.append(synth)
    included.append({wave_id:str, wave_number:int, wave_name:wave.name,
                     synthesized_at: synth.get("synthesized_at"), synthesis_ref:_synthesis_path(wave.id)})
agg = _aggregate(synth_list)
return {portfolio_id:str, computed_at:utcnow().isoformat(), waves_included:included,
        waves_omitted:omitted, counts:agg.counts, disposition_mix:agg.disposition_mix,
        aggregate_net_impact:agg.aggregate_net_impact}

_read_synthesis(svc, wave_id):
    try: result = svc.read_file(path=_synthesis_path(wave_id), branch="main")
    except GitServiceError as exc:
        if "not found on ref" in str(exc) or " 404" in str(exc): return None
        raise           # genuine failure → 502 upstream
    try: return json.loads(result.content)
    except JSONDecodeError: log "wave_outcome_synthesis_malformed"; return None

_aggregate(synth_list) -> {counts, disposition_mix, aggregate_net_impact}:   # PURE
    totals = {apps_total:0, target_state_system_count:0, retired:0, consolidated_absorbed:0, surviving:0}
    disposition_counts = {d:0 for d in _DISPOSITIONS}
    impact = {annual_savings_usd:0.0, one_time_cost_usd:0.0, tier1_reduction:0, users_affected:0}
    for s in synth_list:
        totals.apps_total                 += int(s.get("app_count") or 0)
        totals.target_state_system_count  += int(s.get("target_state_system_count") or 0)
        totals.retired                    += int(s.get("retired_count") or 0)
        totals.consolidated_absorbed      += int(s.get("consolidated_into_count") or 0)
        totals.surviving                  += int(s.get("surviving_count") or 0)
        mix = s.get("disposition_mix") or {}; app_count = int(s.get("app_count") or 0)
        if app_count > 0:
            for d in _DISPOSITIONS:
                pct = float(mix.get(d) or 0.0)
                disposition_counts[d] += round((pct/100.0)*app_count)   # banker's rounding (Python round)
        net = s.get("estimated_net_impact") or {}; tco = net.get("tco_delta") or {}
        if isinstance(tco.get("annual_savings"),(int,float)): impact.annual_savings_usd += float(tco["annual_savings"])
        if isinstance(tco.get("one_time_cost"),(int,float)):  impact.one_time_cost_usd  += float(tco["one_time_cost"])
        risk = net.get("risk_delta") or {}; b=risk.get("tier1_count_before"); a=risk.get("tier1_count_after")
        if isinstance(b,int) and isinstance(a,int): impact.tier1_reduction += b - a
        users = net.get("user_impact_summary") or {}
        if isinstance(users.get("users_affected"),int): impact.users_affected += users["users_affected"]
    total_accounted = sum(disposition_counts.values())
    if total_accounted > 0:
        disposition_mix = {d: round((disposition_counts[d]/total_accounted)*100.0, 1) for d in _DISPOSITIONS}
    else:
        disposition_mix = {d:0.0 for d in _DISPOSITIONS}
    return {counts:totals, disposition_mix, aggregate_net_impact:impact}
```
⚠️ GOTCHA: disposition mix is re-derived from raw counts (percent × app_count, summed, then re-percented over the grand total) — NEVER average percentages. ⚠️ GOTCHA: `_read_synthesis` distinguishes "missing file" (→omit, reason `synthesis-not-emitted`) from genuine Git failure (→re-raise; caught per-wave → omit reason `read-failed`); a ctor-time `GitServiceError` for the whole repo is a hard 502.

---

## 2. `portfolio_members.py` — prefix `/api/v1/admin`, tags `["Admin"]`  (3 endpoints)

Every endpoint: `Depends(require_role(RBACRole.PORTFOLIO_ADMIN))` — **portfolio_admin only**.

**Models** (`src/models/portfolio_membership.py`):
- `PortfolioMembershipResponse` (`:16`): `id:uuid.UUID`, `portfolio_id:uuid.UUID`, `user_id:str`, `role:RBACRole`, `granted_by:str`, `granted_at:datetime`.
- `PortfolioMembershipCreate` (`:27`): `user_id: str = Field(..., min_length=1, max_length=255)`, `role: RBACRole = Field(...)`.

### 2.1 GET `/api/v1/admin/portfolios/{portfolio_id}/members` → `list_members` (`portfolio_members.py:43`)
- response_model `list[PortfolioMembershipResponse]`. `portfolio_id: uuid.UUID`, `user=require_role(PORTFOLIO_ADMIN)`, `db`.
- Logic: `rows = membership_svc.list_portfolio_members(db, portfolio_id)`; map to response. Service runs `SELECT id,portfolio_id,user_id,role,granted_by,granted_at FROM portfolio_membership WHERE portfolio_id=:pid ORDER BY granted_at` (`portfolio_membership.py:78`).
- Status: 200, 401, 403.

### 2.2 POST `/api/v1/admin/portfolios/{portfolio_id}/members` → `add_or_update_member` (`portfolio_members.py:68`)
- status_code **201**, response_model `PortfolioMembershipResponse`. `portfolio_id: uuid.UUID`, `body: PortfolioMembershipCreate`, `user=require_role(PORTFOLIO_ADMIN)`, `db`.
- Logic:
```
exists = SELECT 1 FROM portfolio WHERE id=:pid
if exists is None: raise HTTPException(404,"Portfolio not found")
row = membership_svc.add_member(db, portfolio_id, user_id=body.user_id, role=body.role, granted_by=user.sub)
log "portfolio_membership.added"
return PortfolioMembershipResponse(id,portfolio_id,user_id,role,granted_by,granted_at)
```
- `add_member` (`portfolio_membership.py:109`): `INSERT INTO portfolio_membership (portfolio_id,user_id,role,granted_by) VALUES (...) ON CONFLICT (portfolio_id,user_id) DO UPDATE SET role=EXCLUDED.role, granted_by=EXCLUDED.granted_by, granted_at=now() RETURNING ...`; `db.commit()`. Idempotent on `(portfolio_id,user_id)`.
- Status: 201, 401, 403, 404.

### 2.3 DELETE `/api/v1/admin/portfolios/{portfolio_id}/members/{user_id}` → `remove_member` (`portfolio_members.py:119`)
- status_code **204**, no response body. `portfolio_id: uuid.UUID`, `user_id: str`, `user=require_role(PORTFOLIO_ADMIN)`, `db`.
- Logic: `deleted = membership_svc.remove_member(db, portfolio_id, user_id)` (`DELETE ... WHERE portfolio_id=:pid AND user_id=:uid`; commit; returns `rowcount>0`). If `not deleted`: `raise HTTPException(404,"Membership not found")`; else log + return None.
- Status: 204, 401, 403, 404.

---

## 3. `lines.py` — TWO routers  (4 endpoints + 3 signal-firing endpoints)

`router` = prefix `/api/v1/lines`, tags `["Assembly Lines"]` (`lines.py:62`).
`line_start_router` = prefix `/api/v1`, tags `["Assembly Lines"]` (`lines.py:66`).

Role groups (`lines.py:46-60`):
- `VIEWER_PLUS = [VIEWER, TECH_LEAD, ARCH_LEAD, COMPLIANCE_LEAD, OPERATIONS_LEAD, SAFETY_BOARD, PORTFOLIO_MANAGER, PORTFOLIO_ADMIN]`.
- `MANAGER_ROLES = [PORTFOLIO_MANAGER, PORTFOLIO_ADMIN]`.

Helper `_info_as_dict(info) -> dict` (`:71`): `{name, description, steps, skills, gates, dependencies}` from `LineInfo`.

### 3.1 GET `/api/v1/lines` → `list_lines` (`lines.py:82`)
- Returns `dict`. Dep: `_user=Depends(require_role(*VIEWER_PLUS))`.
- Logic: `return {"data": [_info_as_dict(info) for info in lines_svc.list_lines()]}`.
- Status: 200, 401, 403.

### 3.2 GET `/api/v1/lines/{line_name}` → `get_line` (`lines.py:90`)
- Returns `dict`. `line_name: str`, `_user=require_role(*VIEWER_PLUS)`.
- Logic: `info = lines_svc.get_line(line_name)`; if None → `raise OlympusHTTPException(404,"LINE_NOT_FOUND", f"Assembly line {line_name!r} not found")`; else `_info_as_dict(info)`.
- Status: 200, 401, 403, 404 (`LINE_NOT_FOUND`).

### 3.3 GET `/api/v1/lines/{line_name}/status` → `get_line_status` (`lines.py:104`)
- Returns `dict`. `line_name: str`; `portfolio_id: uuid.UUID|None = Query(None)`; `_user=require_role(*VIEWER_PLUS)`; `user=Depends(get_current_user)`; `db`.
- Logic: if `portfolio_id is not None`: `verify_portfolio_access(db,user,portfolio_id)`. `member_ids = filter_portfolio_ids_by_membership(db,user)`. `try: return await lines_svc.get_line_status(db, line_name, portfolio_id=portfolio_id, portfolio_ids=member_ids)` `except KeyError: raise OlympusHTTPException(404,"LINE_NOT_FOUND",...)`.
- Response dict: `{line, apps_in_progress:int, apps_completed:int, apps_blocked:int}`.
- Status: 200, 401, 403, 404.

### 3.4 GET `/api/v1/lines/{line_name}/throughput` → `get_line_throughput` (`lines.py:137`)
- Returns `dict`. `line_name: str`; `days: int = Query(7, ge=1, le=90)`; `portfolio_id: uuid.UUID|None = Query(None)`; `_user=require_role(*VIEWER_PLUS)`; `user=Depends(get_current_user)`; `db`.
- Logic: same scoping; `try: return await lines_svc.get_line_throughput(db, line_name, days=days, portfolio_id=..., portfolio_ids=...)` `except KeyError → 404 LINE_NOT_FOUND`.
- Response dict: `{line, apps_per_week:float, avg_duration_hours:float, period_start:iso, period_end:iso}`.
- Status: 200, 401, 403, 404.

#### Service `lines.py` — registry + status + throughput (reproduce)
Static maps (`services/lines.py:27-73`):
- `_LINE_DESCRIPTIONS` keys (canonical order): `Discovery, Rationalization, Architecture, Data, Modernization, Disposition Execution, Validation, Deployment, Sustainment, Governance` — with the exact description strings in source `:27-47`.
- `_LINE_DEPENDENCIES`: Discovery=[], Rationalization=[Discovery], Architecture=[Rationalization], Data=[Discovery,Architecture], Modernization=[Architecture,Data], "Disposition Execution"=[Rationalization], Validation=[Modernization], Deployment=[Validation,"Disposition Execution"], Sustainment=[], Governance=[].
- `_LINE_GATES`: Discovery=[G-DC], Rationalization=[G-RR,G-DA,G-02], Architecture=[G-DT], Data=[G-DT], Modernization=[G-04a,G-04b,G-04c], "Disposition Execution"=[G-DE-1,G-DE-2], Validation=[G-V1,G-V2,G-V3], Deployment=[G-DP-1,G-DP-2], Sustainment=[], Governance=[].
- `LineInfo` (frozen dataclass): `name, description, steps:list[str], skills:list[str], gates:list[str], dependencies:list[str]`.
- `_line_info(name)`: None if name unknown; else `steps = sorted({s.step for s in registry.skills if s.line==name and s.step})`; `skills = sorted({s.id for s in registry.skills if s.line==name and not s.is_orchestration})`; gates/deps from maps. `registry = get_registry()` (skill_registry).
- `list_lines()` = `[_line_info(n) for n in _LINE_DESCRIPTIONS if _line_info(n)]`. `get_line(name)=_line_info(name)`.

`get_line_status(db, line, portfolio_id=None, portfolio_ids=None) -> dict` (`services/lines.py:115`):
```
if line not in _LINE_DESCRIPTIONS: raise KeyError(line)
params={"line":line}; portfolio_clause=""
if portfolio_ids is not None:
    if not portfolio_ids: return {line, apps_in_progress:0, apps_completed:0, apps_blocked:0}
    portfolio_clause += " AND portfolio_id = ANY(:pf_ids)"; params["pf_ids"]=portfolio_ids
if portfolio_id is not None:
    portfolio_clause += " AND portfolio_id = :pid"; params["pid"]=portfolio_id
running   = SELECT count(*) FROM application WHERE current_line=:line AND current_status='running' {clause}
completed = SELECT count(*) FROM application WHERE current_line=:line AND current_status='completed' {clause}
# blocked uses a-prefixed clause:
blocked_clause = (" AND a.portfolio_id = ANY(:pf_ids)" if portfolio_ids else "") + (" AND a.portfolio_id = :pid" if portfolio_id else "")
blocked = SELECT count(DISTINCT a.id) FROM application a
          LEFT JOIN escalation e ON e.application_id=a.id AND e.status!='resolved'
          LEFT JOIN gate g ON g.application_id=a.id AND g.status='pending'
          WHERE a.current_line=:line AND (e.id IS NOT NULL OR g.id IS NOT NULL){blocked_clause}
return {line, apps_in_progress:int(running), apps_completed:int(completed), apps_blocked:int(blocked)}
```

`get_line_throughput(db, line, days=7, portfolio_id=None, portfolio_ids=None) -> dict` (`services/lines.py:208`):
```
if line not in _LINE_DESCRIPTIONS: raise KeyError(line)
period_end = utcnow(); period_start = period_end - timedelta(days=days)
params={"line":line,"period_start":period_start}; portfolio_clause=""
if portfolio_ids is not None:
    if not portfolio_ids: return {line, apps_per_week:0.0, avg_duration_hours:0.0, period_start:iso, period_end:iso}
    portfolio_clause += " AND a.portfolio_id = ANY(:pf_ids)"; params["pf_ids"]=...
if portfolio_id is not None: portfolio_clause += " AND a.portfolio_id = :pid"; params["pid"]=...
row = SELECT count(*)::float AS cnt,
             AVG(EXTRACT(EPOCH FROM (t.completed_at - t.dispatched_at))/3600.0) AS avg_hours
      FROM agent_task t JOIN application a ON a.id=t.application_id
      WHERE a.current_line=:line AND t.status='completed' AND t.completed_at >= :period_start {clause}
count=float(row.cnt or 0.0); avg_hours=float(row.avg_hours or 0.0)
apps_per_week = count/(days/7.0) if days>0 else 0.0
return {line, apps_per_week:round(.,2), avg_duration_hours:round(avg_hours,2), period_start:iso, period_end:iso}
```

### Line-start endpoints (`line_start_router`, mount `/api/v1`) — fire Temporal `start_workflow`

`_LINE_SPECS` (`lines.py:181`): `architecture→{workflow:"ArchitectureWorkflow", id_prefix:"architecture-"}`, `data→{"DataWorkflow","data-"}`, `modernization→{"ModernizationWorkflow","modernization-"}`.

**`LineStartRequest`** (`lines.py:199`): `target_app_id: uuid.UUID`; `wave_id: uuid.UUID`; `artifact_repo: str=Field(...,min_length=1)`; `target_repo_url: str=Field(...,min_length=1)`; `disposition: str=Field(...,min_length=1)`; `prior_artifact_paths: list[str]=Field(default_factory=list)`; `target_framework: str|None=None`; `target_frontend: str|None=None`; `primary_language: str|None=None`; **⚠️ NEW at HEAD** `delegation: DelegationRequest|None=None` (Phase 6 W1, design §9.0 — optional workflow-kickoff routing choice; absent ⇒ internal/back-compatible; a `delegate` choice produces an `offered` bundle for the chosen scope as the line starts). `DelegationRequest` imported from `src.models.delegation` (`lines.py:43`).
**`LineStartResponse`** (`lines.py:230`): `workflow_id: str`; `temporal_ui_url: str`.

Helpers:
- `_temporal_ui_url(base_url, namespace, workflow_id) = f"{base_url.rstrip('/')}/namespaces/{namespace}/workflows/{workflow_id}"`.
- `_validate_target_app(db, target_app_id) -> dict` (`:243`): `SELECT id,name,portfolio_id FROM application WHERE id=:id`; None → `OlympusHTTPException(404,"TARGET_APP_NOT_FOUND", f"Target application {id} not found")`.
- `_read_required_artifacts(git_svc, paths) -> list[str]` (`:264`): if no paths → []; for each path run `git_svc.read_file(path=path)` in a thread (`asyncio.to_thread`) catching `GitServiceError`→missing; `asyncio.gather` all; return list of paths that failed (missing).

**Shared `_start_line_workflow(line, body, db, temporal) -> LineStartResponse`** (`lines.py:291`):
```
spec = _LINE_SPECS[line]
target = await _validate_target_app(db, body.target_app_id)     # 404 TARGET_APP_NOT_FOUND
config = get_config(); missing=[]
if body.prior_artifact_paths:
    if not config.github_token:
        raise OlympusHTTPException(503,"GIT_TOKEN_MISSING","Artifact validation requires GITHUB_TOKEN to be configured")
    git_svc = GitService(GitServiceConfig(token, repo=body.artifact_repo, base_url))
    missing = await _read_required_artifacts(git_svc, body.prior_artifact_paths)
if missing:
    raise OlympusHTTPException(400,"PRIOR_ARTIFACTS_MISSING",
        f"{len(missing)} prior artifact(s) not found in {body.artifact_repo!r}",
        details={"missing_paths":missing, "artifact_repo":body.artifact_repo})
# ⚠️ NEW at HEAD (Phase 6 W1, design §9.0) — kickoff-time delegation. Produce the OFFERED
# bundle for the chosen scope BEFORE the workflow starts so the line's resolve_dispatch_mode
# picks it up (Layer a):
if body.delegation is not None and body.delegation.is_delegated():
    await bundle_svc.dispatch_from_kickoff(db, scope_kind=body.delegation.scope_kind,
        target_id=str(body.delegation.target_id), application_id=body.target_app_id, wave_id=None,
        expires_in_hours=body.delegation.expires_in_hours, fallback_policy=body.delegation.fallback_policy,
        created_by_user_id="olympus-kickoff")
workflow_id = f"{spec['id_prefix']}{body.target_app_id}-{int(time.time())}"
line_input = {
  app_id:str(body.target_app_id), app_name: target.get("name") or str(target_app_id),
  wave_id:str(body.wave_id), portfolio_id:str(target.get("portfolio_id") or ""),
  artifact_repo:body.artifact_repo, target_repo_url:body.target_repo_url,
  disposition: body.disposition.title(),          # ⚠️ .title() applied
  prior_artifacts: list(body.prior_artifact_paths),
  peer_workflow_ids: {},                           # no peers — operator restart runs independently
  target_framework:body.target_framework, target_frontend:body.target_frontend, primary_language:body.primary_language }
try: await temporal.start_workflow(spec["workflow"], line_input, id=workflow_id, task_queue=config.temporal_task_queue)
except Exception as exc: raise OlympusHTTPException(502,"WORKFLOW_START_FAILED", f"Failed to start {spec['workflow']}: {exc!r}")
return LineStartResponse(workflow_id, temporal_ui_url=_temporal_ui_url(config.temporal_ui_base_url, config.temporal_namespace, workflow_id))
```
⚠️ GOTCHA: spawned as a **top-level (parentless)** workflow — survives a dead wave coordinator. ⚠️ GOTCHA: `disposition` is title-cased before passing to the workflow.

### 3.5 POST `/api/v1/architecture/start` → `start_architecture` (`lines.py:395`)
- status_code **202**, response_model `LineStartResponse`. Body `LineStartRequest`; `_user=Depends(require_role(*MANAGER_ROLES))`; `db`; `temporal=Depends(get_temporal_client)`.
- Logic: `return await _start_line_workflow("architecture", body, db, temporal)`.
- Status: 202, 401, 403, 400 (`PRIOR_ARTIFACTS_MISSING`), 404 (`TARGET_APP_NOT_FOUND`), 502 (`WORKFLOW_START_FAILED`), 503 (`GIT_TOKEN_MISSING`).

### 3.6 POST `/api/v1/data/start` → `start_data` (`lines.py:410`)
- Same shape; `_start_line_workflow("data", ...)`. 202 + same error set.

### 3.7 POST `/api/v1/modernization/start` → `start_modernization` (`lines.py:425`)
- Same shape; `_start_line_workflow("modernization", ...)`. 202 + same error set.

---

## 4. `profiles.py` — TWO routers  (4 endpoints + bundle + switch)

`router` = prefix `/api/v1/profiles`, tags `["profiles"]` (`profiles.py:50`).
`portfolio_profile_router` = prefix `/api/v1/portfolio`, tags `["portfolio"]` (`profiles.py:530`).

**Models** (defined in this module):
- `ProfileSummary` (`:168`): `id,name,version:str`, `description:str=""`.
- `ProfileDetail` (`:190`): `id,name,version:str`, `description:str=""`, `organization:dict[str,Any]={}`, `portfolio:dict[str,Any]={}`, `extensions:dict[str,str]={}`, `skills:list[str]=[]`, `risk_tier_labels:list[str]=[]`, `compliance_domains:list[str]=[]`, `scoring_weights:dict[str,float]={}`, `default_gate_provider:str=""`, `technology_highlights:dict[str,str]={}`. **⚠️ NEW fields at HEAD (P6-S10.3** — render the ACTIVE profile, not a hardcoded FAA bundle): `portfolio:dict[str,Any]={}`, `risk_tiers:list[ProfileRiskTier]=[]` (`ProfileRiskTier{key,label,definition:str=""}`, `:175`), `compliance_standards:list[ProfileComplianceStandard]=[]` (`ProfileComplianceStandard{domain,standard:str=""}`, `:183`). `_profile_detail` (`:274`) now also emits `portfolio=profile.metadata.portfolio`, `risk_tiers=[ProfileRiskTier(t.key,t.label,t.definition) for t in profile.risk_classification.tiers]`, `compliance_standards=[ProfileComplianceStandard(domain, _compliance_standard_label(profile.compliance.domains.get(domain))) for domain in profile.compliance.domain_names]`. Helper `_compliance_standard_label(domain_config)` (`:258`): first non-empty of `domain_config["standard"]` / `domain_config["framework"]`, else `""` (non-dict → `""`).
- `ActiveProfileResponse` (`:190`): `active: ProfileDetail|None=None`.
- `ProfileFieldDiff` (`:194`): `path:str`, `status:str` ("added"|"removed"|"changed"|"unchanged"), `left:Any=None`, `right:Any=None`.
- `ProfileComparisonResponse` (`:203`): `left:ProfileSummary`, `right:ProfileSummary`, `diffs:list[ProfileFieldDiff]=[]`.
- `ProfileSwitchRequest` (`:209`): `profile:str`.
- `ProfileSwitchResponse` (`:213`): `portfolio_id:str`, `profile_id:str`, `activated:bool`.
- `ProfileBundleResponse` (`:219`): `profile_name:str`, `files:dict[str,str]`.

Helpers: `_profiles_dir()` (`:58`, search order: `OLYMPUS_PROFILES_DIR` env → walk up from `__file__` for `profiles/` → walk up from CWD → `/app/repo/profiles`,`/app/profiles`; returns `Path|None`). `_list_profile_ids()` (`:118`, subdirs with a `profile.yaml`; degrades to `[]`). `_load_by_id(profile_id) -> Profile` (`:155`, `discover_profile_root` + `load_profile`; `ProfileLoadError → HTTPException(404, str(exc))`). `_profile_detail(profile) -> ProfileDetail` (`:238`) — maps profile dataclass; `technology_highlights` picked from infrastructure keys `api_gateway,identity,container_platform` where entry is a dict with `name`.

### 4.1 GET `/api/v1/profiles` → `list_profiles` (`profiles.py:317`, def `:318`)
- response_model `list[ProfileSummary]`. **No auth dependency.**
- Logic: for each pid in `_list_profile_ids()`: try `_load_by_id(pid)`; `except HTTPException`→log+skip; `except Exception`→log+skip; else append `ProfileSummary(id,name,version,description)`. Never 500s (degrades gracefully).
- Status: 200.

### 4.2 GET `/api/v1/profiles/active` → `get_active_profile` (`profiles.py:356`, def `:357`)
- response_model `ActiveProfileResponse`. **No auth.**
- Logic: `current = active_profile()`; if None → `ActiveProfileResponse(active=None)`; else `ActiveProfileResponse(active=_profile_detail(current))`.
- Status: 200.

### 4.3 GET `/api/v1/profiles/compare` → `compare_profiles` (`profiles.py:365`, def `:366`)
- response_model `ProfileComparisonResponse`. **No auth.** Query: `left: str=Query(...)`, `right: str=Query(...)`.
- Logic: `left_profile=_load_by_id(left)`; `right_profile=_load_by_id(right)` (each 404 on unknown); `diffs=_diff_profiles(left,right)`; return `ProfileComparisonResponse(left=ProfileSummary(...), right=ProfileSummary(...), diffs=diffs)`.
- Status: 200, 404 (unknown profile).

#### `_diff_profiles(left, right) -> list[ProfileFieldDiff]` (`profiles.py:440`) — reproduce diff emission order
Helpers: `_diff_scalars(path,l,r)` → status "unchanged" if `l==r` else "changed". `_diff_dicts(prefix,l,r)`: for each key in `sorted(set(l)|set(r))`, path=`f"{prefix}.{k}"` (or `k` if no prefix); missing-in-left→"added"(right value); missing-in-right→"removed"(left value); else `_diff_scalars`.
Emission order (extend rows in this sequence):
1. `_diff_dicts("metadata", {id,name,version,description}_left, ..._right)`.
2. `_diff_dicts("scoring.weights", {d.name:d.weight for dims}_l, _r)`.
3. `_diff_dicts("risk_classification.tier_labels", {t.key:t.label for tiers}_l, _r)`.
4. `_diff_dicts("compliance.domains", {d:True for domain_names}_l, _r)`.
5. `_diff_scalars("gates.default_provider", l.gates.default_provider, r...)`.
6. `_diff_dicts("gates.overrides", {o.gate_id:True for overrides}_l, _r)`.
7. `_diff_dicts("technology.infrastructure", {k:(v["name"] if dict else v) for infrastructure}_l, _r)`.
8. `_diff_dicts("skills", {s:True for metadata.skills}_l, _r)`.

### 4.4 GET `/api/v1/profiles/{profile_id}` → `get_profile` (`profiles.py:393`, def `:394`)
- response_model `ProfileDetail`. **No auth.** `profile_id: str`.
- Logic: `profile=_load_by_id(profile_id)` (404 on unknown); `return _profile_detail(profile)`.
- Status: 200, 404.

### 4.5 GET `/api/v1/portfolio/{portfolio_id}/profile-bundle` → `get_portfolio_profile_bundle` (`profiles.py:615`, def `:622`, on `portfolio_profile_router`)
- response_model `ProfileBundleResponse`; `responses={404:{"description":"Portfolio or profile not found on disk"}}`. `portfolio_id: str`; `db`; `profile: str|None = Query(None)`; `user=Depends(get_current_user)`.
- Logic:
```
from src.routers.portfolio import _portfolios
try: _pid_uuid = uuid.UUID(portfolio_id) except: _pid_uuid=None
if _pid_uuid is not None: await verify_portfolio_access(db, user, _pid_uuid)
portfolio_record = _portfolios.get(portfolio_id)
if portfolio_record is None:
    try uuid.UUID(portfolio_id) except: raise HTTPException(404, f"Portfolio {portfolio_id!r} not found")
    row = SELECT id,name,owner,status,artifact_repo_url FROM portfolio WHERE id=:id::uuid
    if row is None: raise HTTPException(404, "Portfolio ... not found")
    portfolio_record = {id,name,owner,status,artifact_repo_url, artifact_repo_default_branch:"main", webhook_secret:"", profile_id:""}
    _portfolios[portfolio_id] = portfolio_record       # lazy-hydrate
target = (profile or "").strip()
if not target: target = _portfolio_profile_id(portfolio_id) or "faa"   # in-mem profile_id else "faa"
if "/" in target or ".." in target or target.startswith("."): raise HTTPException(404, f"Profile {target!r} not found")
try: files = _read_profile_bundle(target)
except ProfileLoadError as exc: raise HTTPException(404, str(exc))
if not files: raise HTTPException(404, f"Profile {target!r} has no YAML files to export")
return ProfileBundleResponse(profile_name=target, files=files)
```
- `_portfolio_profile_id(portfolio_id)` (`profiles.py:543`): `_portfolios.get(id)`; None→`""`; else `record.get("profile_id") or ""`.
- `_read_profile_bundle(profile_id) -> dict[str,str]` (`profiles.py:563`): `root=discover_profile_root(profile_id).resolve()`; for each `sorted(root.rglob("*"))` that is a file with suffix `.yaml`/`.yml`: resolve; ⚠️ GOTCHA path-traversal guard `resolved.relative_to(root)` (ValueError→skip); `read_text("utf-8")` (OSError→skip); key by `relative_to(root).as_posix()`.
- Status: 200, 401, 403, 404.

### 4.6 PUT `/api/v1/portfolio/{portfolio_id}/profile` → `switch_portfolio_profile` (`profiles.py:753`, def `:758`, on `portfolio_profile_router`)
- response_model `ProfileSwitchResponse`; `responses={409:{"description":"In-flight workflows block profile switch"}}`. `portfolio_id: str`; `body: ProfileSwitchRequest`; `user=Depends(get_current_user)`; `db`.
- `_workflows_in_flight(portfolio_id) -> list[str]` (`profiles.py:738`): default returns `[]` (hook patched by tests; real Temporal Visibility query pending).
- Logic:
```
from src.routers.portfolio import _portfolios
try _pid_uuid = uuid.UUID(portfolio_id) except: _pid_uuid=None
if _pid_uuid is not None: await verify_portfolio_access(db, user, _pid_uuid)
portfolio_record = _portfolios.get(portfolio_id)
if portfolio_record is None:
    try uuid.UUID(portfolio_id) except: raise HTTPException(404,"Portfolio ... not found")
    row = SELECT id,name,owner,status,artifact_repo_url FROM portfolio WHERE id=:id::uuid
    if row is None: raise HTTPException(404, "Portfolio ... not found")
    portfolio_record = {...defaults profile_id:""}; _portfolios[portfolio_id]=portfolio_record
in_flight = _workflows_in_flight(portfolio_id)
if in_flight: raise HTTPException(409, f"Portfolio {id!r} has {len(in_flight)} in-flight workflow(s). Drain or cancel them before switching profiles.")
target = body.profile.strip()
if not target: raise HTTPException(422, "profile id cannot be empty")
if target.lower() == "default":
    deactivate_profile(); portfolio_record["profile_id"]=""
    return ProfileSwitchResponse(portfolio_id, profile_id="", activated=True)
try: profile = activate_profile(profile_id=target)
except ProfileActivationError as exc: raise HTTPException(404, str(exc))
if profile is None: raise HTTPException(500, "profile activation returned no profile")
portfolio_record["profile_id"] = profile.metadata.id
return ProfileSwitchResponse(portfolio_id, profile_id=profile.metadata.id, activated=True)
```
⚠️ GOTCHA: `profile == "default"` (case-insensitive) deactivates the active profile and resets registries. Switching mid-flight is blocked (409) to preserve Temporal determinism.
- Status: 200, 401, 403, 404, 409, 422, 500.

---

## 5. `system.py` — no prefix, tags `["System"]`  (4 endpoints)

Module: `_PROCESS_START = time.monotonic()` (`system.py:44`). `_timestamp() = datetime.now(utc).isoformat()`.

### 5.1 GET `/health/live` → `get_liveness` (`system.py:57`)
- Returns `dict`. Dep: `config=Depends(get_config)`. **No auth.**
- Returns `{"status":"ok","service":config.service_name,"version":config.version,"timestamp":_timestamp()}`. Always 200; no dependency checks.

### 5.2 GET `/system/info` → `get_system_info` (`system.py:77`)
- Returns `dict`. `config=Depends(get_config)`. **No auth.**
- Logic: `profile_id=""`; `current=active_profile()` (local import); if not None → `profile_id=current.metadata.id`. `deployment = os.environ.get("OLYMPUS_ENVIRONMENT","development")`. Return `{version, profile:profile_id, deployment, temporal_namespace:config.temporal_namespace, service:config.service_name, timestamp}`.
- Status: 200.

### 5.3 GET `/system/metrics` → `get_metrics` (`system.py:165`)
- Returns `Response` (`media_type="text/plain; version=0.0.4"`). `config=Depends(get_config)`. **No auth** (scrape agents unauthenticated).
- Logic: `body = _render_prometheus(collect_metrics(), config)`; `return Response(content=body, media_type="text/plain; version=0.0.4")`.
- `_render_prometheus(metrics, config) -> str` (`system.py:107`) emits (in order): `olympus_api_info{service,version} 1`; `olympus_api_uptime_seconds {monotonic()-_PROCESS_START:.3f}`; `olympus_api_skills_loaded {get_skill_count()}`; per-key `olympus_api_requests_total{method,path,status} count` from `metrics["requests_total"]` (key tuple `(method,path_template,status)`); per-key `olympus_api_request_duration_seconds_sum`/`_count{method,path}` from `metrics["request_duration"]` (key `(method,path_template)`, stats `{sum,count}`); `olympus_api_rate_limited_total {metrics.get("rate_limited_total",0)}`. Joined with `"\n"` + trailing `"\n"`. Each metric preceded by `# HELP`/`# TYPE` lines.
- Status: 200.

### 5.4 GET `/system/dependencies` → `get_dependencies` (`system.py:182`)
- Returns `dict`. `config=Depends(get_config)`, `db=Depends(get_db)`. **No auth** (feeds public status pages).
- Logic:
```
deps={}
try: t0=monotonic(); db.execute(SELECT 1); latency=round((monotonic()-t0)*1000,2); deps["database"]={status:"ok", latency_ms:latency}
except: log; deps["database"]={status:"error", error:"database unavailable"}
try: client=await get_temporal_client(); await client.service_client.check_health()
     deps["temporal"]={status:"ok", host:config.temporal_host, namespace:config.temporal_namespace, ui_url:config.temporal_ui_base_url}
except: log; deps["temporal"]={status:"error", error:"temporal unavailable"}
skill_count=get_skill_count(); deps["skills"]={status:"ok" if count>0 else "error", count}
overall = "ok" if all(d.status=="ok" for d in deps.values()) else "degraded"
return {status:overall, dependencies:deps, timestamp}
```
- Status: 200 (always; degradation expressed in body).

---

## 6. `health.py` — no prefix, tags `["health"]`  (4 endpoints) — **no auth on any**

`_timestamp() = datetime.now(utc).isoformat()`.

### 6.1 GET `/health` → `health` (`health.py:33`)
- `config=Depends(get_config)`. Returns `{status:"ok", service, version, timestamp}`. Always 200.

### 6.2 GET `/health/detailed` → `health_detailed` (`health.py:44`)
- `config=Depends(get_config)`, `db=Depends(get_db)`. Returns `{status:overall, service, version, timestamp, dependencies:{database:{status,latency_ms|error}, temporal:{status,host|error}, skills:{status,count}}}`. `overall="ok"` iff all deps ok else `"degraded"`. DB latency `round(...,1)`. (Same probe pattern as `/system/dependencies` but slightly different shape: includes service/version, temporal only carries `host`.)
- Status: 200.

### 6.3 GET `/health/temporal` → `health_temporal` (`health.py:90`)
- `config=Depends(get_config)`. On success returns `{status:"ok", service:"temporal", host, namespace, timestamp}`; on exception returns `{status:"error", service:"temporal", host, error:"temporal unavailable", timestamp}` (200 either way; error in body).

### 6.4 GET `/health/ready` → `health_ready` (`health.py:114`)
- `config=Depends(get_config)`. Logic: `checks={}`, `all_ok=True`; temporal check (`check_health()`) ok→`checks["temporal"]="ok"` else `"error"`+`all_ok=False`; `skill_count=get_skill_count()`>0→`checks["skills"]="ok"` else error+`all_ok=False`. `status="ready" if all_ok else "not_ready"`. Returns `{status, service, version, timestamp, checks}`.
- ⚠️ GOTCHA: returns HTTP 200 even when `not_ready` (status carried in body, not status code). Two routers (`health` + `system`) both register `GET /health/ready`-adjacent paths — `system` adds `/health/live`; `health` owns `/health/ready`. Both registered (health 176, system 177).

---

## 7. `artifacts.py` — prefix `/api/v1/artifacts`, tags `["Artifacts"]`  (4 endpoints)

Role groups (`artifacts.py:38-53`): `VIEWER_PLUS` (same 8 as lines), `TECH_PLUS = [TECH_LEAD, PORTFOLIO_MANAGER, PORTFOLIO_ADMIN]`.

**Models** (in module):
- `ArtifactSummary` (`:63`): `path:str`, `type:str`, `line:str|None=None`, `step:str|None=None`, `commit_sha:str=""`, `created_at:datetime|None=None`, `updated_at:datetime|None=None`.
- `ArtifactContent` (`:73`): `path:str`, `content:str`, `schema_valid:bool=False`, `commit_sha:str=""`.
- `ArtifactVersion` (`:80`): `commit_sha:str`, `author:str=""`, `message:str=""`, `timestamp:datetime|None=None`.
- `ArtifactValidateError` (`:87`): `path:str`, `message:str`.
- `ArtifactValidateRequest` (`:92`): `artifact_type:str`, `content:dict[str,Any]`.
- `ArtifactValidateResponse` (`:97`): `valid:bool`, `errors:list[ArtifactValidateError]=[]`.

Helpers: `_ARTIFACT_TYPE_HINTS` map (`.json→json`,`.yaml/.yml→yaml`,`.md→markdown`,`.txt→text`,`.py/.java/.cs→source`); `_guess_type(path)` matches suffix or `"unknown"`. `_load_app(db, app_id) -> dict|None` (`:132`): `SELECT a.id,a.name,a.portfolio_id,p.artifact_repo_url FROM application a LEFT JOIN portfolio p ON p.id=a.portfolio_id WHERE a.id=:id`. `_git_service(config, repo) -> GitService|None` (`:147`): None if `not repo or not config.github_token`; else construct (catching `GitServiceError`→None).

⚠️ GOTCHA: decorator order. `POST /validate` is registered FIRST (`:173`), then `GET /{app_id}` (`:209`), then `GET /{app_id}/{artifact_path:path}/history` (`:268`), then `GET /{app_id}/{artifact_path:path}` (`:318`). The `/validate` literal must precede the `{app_id}` param. The `/history` path (ending segment fixed) must precede the bare `{path:path}` catch-all. Preserve this order. Note: `GET /api/v1/artifacts/stale` is NOT here — served by `traceability` router (avoid double registration).

### 7.1 POST `/api/v1/artifacts/validate` → `validate_artifact` (`artifacts.py:173`)
- response_model `ArtifactValidateResponse`. Body `ArtifactValidateRequest`; `_user=Depends(require_role(*TECH_PLUS))`.
- Logic: `errors=[]`; `try json.dumps(body.content) except (TypeError,ValueError) as exc: errors.append(ArtifactValidateError(path="$", message=f"Not JSON-serialisable: {exc}"))`. `required_by_type = {"catalog":["version"], "disposition":["version"], "pattern":["id","name"]}`; for each required key absent from `body.content`: append `ArtifactValidateError(path=f"$.{key}", message=f"Missing required field {key!r}")`. Return `ArtifactValidateResponse(valid=len(errors)==0, errors=errors)`.
- Status: 200, 401, 403.

### 7.2 GET `/api/v1/artifacts/{app_id}` → `list_artifacts` (`artifacts.py:209`)
- Returns `dict`. `dependencies=[Depends(require_application_member)]`. `app_id: uuid.UUID`; `line/step/type: str|None = Query(None)`; `_user=Depends(require_role(*VIEWER_PLUS))`; `db`; `config=Depends(get_config)`.
- Logic:
```
app_row = _load_app(db, app_id); if None: raise OlympusHTTPException(404,"APP_NOT_FOUND", f"Application {app_id} not found")
repo = app_row.get("artifact_repo_url") or ""
svc = _git_service(config, repo)
if svc is None: return {"data":[], "empty_state":True, "reason":"artifact_repo_not_configured"}
try: contents = svc._repo.get_contents(f"discovery/{app_id}", ref="main")
except Exception: return {"data":[], "empty_state":True, "reason":"no_artifacts_yet"}
if not list: contents=[contents]
items=[]
for f in contents:
    path = getattr(f,"path",""); if not path: continue
    if type and _guess_type(path) != type: continue      # only 'type' filter applied here
    items.append(ArtifactSummary(path, type=_guess_type(path), line=line or "Discovery", step=step, commit_sha=getattr(f,"sha","") or ""))
return {"data":[i.model_dump(mode="json") for i in items]}
```
⚠️ GOTCHA: `line`/`step` query params are NOT used to filter — only `type` filters; `line` defaults the summary's `line` to `"Discovery"`. Empty-state responses (200) instead of 500 when repo missing/unreadable.
- Status: 200, 401, 403, 404.

### 7.3 GET `/api/v1/artifacts/{app_id}/{artifact_path:path}/history` → `get_artifact_history` (`artifacts.py:272`)
- Returns `dict`. `dependencies=[Depends(require_application_member)]`. `app_id: uuid.UUID`; `artifact_path: str`; `_user=require_role(*VIEWER_PLUS)`; `db`; `config`.
- Logic: `_load_app` (404 `APP_NOT_FOUND`); `svc=_git_service(...)`; if None → `{"data":[]}`. `try: commits = svc._repo.get_commits(path=f"discovery/{app_id}/{artifact_path}")`; for first 25 commits build `ArtifactVersion(commit_sha=commit.sha, author=committer.name|"" , message=commit.commit.message, timestamp=committer.date(tz-coerced to utc if naive))`; return `{"data":[...model_dump...]}`. `except Exception: log; return {"data":[]}`.
- Status: 200, 401, 403, 404.

### 7.4 GET `/api/v1/artifacts/{app_id}/{artifact_path:path}` → `get_artifact` (`artifacts.py:319`)
- response_model `ArtifactContent`. `dependencies=[Depends(require_application_member)]`. `app_id`, `artifact_path`, `_user=require_role(*VIEWER_PLUS)`, `db`, `config`.
- Logic:
```
_load_app (404 APP_NOT_FOUND)
svc=_git_service(...); if None: raise OlympusHTTPException(503,"ARTIFACT_REPO_UNAVAILABLE","Artifact repository is not configured for this portfolio")
full_path = f"discovery/{app_id}/{artifact_path}"
try: result = svc.read_file(full_path, branch="main")
except GitServiceError as exc:
    if "not found" in str(exc).lower(): raise OlympusHTTPException(404,"ARTIFACT_NOT_FOUND", f"Artifact {artifact_path!r} not found")
    raise OlympusHTTPException(502,"GIT_READ_FAILED","Failed to read artifact from repository")
schema_valid = True
if artifact_path.endswith(".json"): try json.loads(result.content) except JSONDecodeError: schema_valid=False
return ArtifactContent(path=artifact_path, content=result.content, schema_valid=schema_valid, commit_sha=result.commit_sha)
```
- Status: 200, 401, 403, 404 (`APP_NOT_FOUND`/`ARTIFACT_NOT_FOUND`), 502 (`GIT_READ_FAILED`), 503 (`ARTIFACT_REPO_UNAVAILABLE`).

---

## 8. `renditions.py` — prefix `/api/v1/applications`, tags `["Renditions"]`  (2 endpoints) — **no auth on either**

`RenditionType(StrEnum)` (`:19`): `REQUIREMENTS_DOC="requirements_doc"`, `ARCHITECTURE_DECK="architecture_deck"`, `TEST_REPORT="test_report"`.
**Models**:
- `GenerateRenditionRequest` (`:27`): `rendition_type: RenditionType=Field(...)`.
- `RenditionRecord` (`:35`): `id:uuid.UUID=Field(default_factory=uuid4)`, `app_id:uuid.UUID`, `rendition_type:RenditionType`, `status:str="completed"`, `created_at:datetime=Field(default_factory=now-utc)`, `template_name:str`, `output_path:str|None=None`.
- `GenerateRenditionResponse` (`:47`): `rendition:RenditionRecord`, `message:str`.
- `ListRenditionsResponse` (`:54`): `app_id:uuid.UUID`, `renditions:list[RenditionRecord]`, `total:int`.

Module state: `_rendition_store: dict[uuid.UUID, list[RenditionRecord]] = {}` (`:63`). `TEMPLATE_MAP` (`:65`): `REQUIREMENTS_DOC→"requirements_doc.md.j2"`, `ARCHITECTURE_DECK→"architecture_deck.md.j2"`, `TEST_REPORT→"test_report.md.j2"`.

### 8.1 POST `/api/v1/applications/{app_id}/renditions/generate` → `generate_rendition` (`renditions.py:77`)
- status_code **201**, response_model `GenerateRenditionResponse`. Body `GenerateRenditionRequest`; `app_id: uuid.UUID = Path(...)`.
- Logic: `template_name = TEMPLATE_MAP[body.rendition_type]`; `record = RenditionRecord(app_id, rendition_type=body.rendition_type, template_name, output_path=f"renditions/{app_id}/{body.rendition_type.value}.md")`; append to `_rendition_store[app_id]` (create list if absent); return `GenerateRenditionResponse(rendition=record, message=f"Rendition '{body.rendition_type.value}' generation initiated.")`.
- Status: 201, 422 (bad rendition_type).

### 8.2 GET `/api/v1/applications/{app_id}/renditions` → `list_renditions` (`renditions.py:109`)
- response_model `ListRenditionsResponse`. `app_id: uuid.UUID = Path(...)`.
- Logic: `records = _rendition_store.get(app_id, [])`; return `ListRenditionsResponse(app_id, renditions=records, total=len(records))`.
- Status: 200.

---

## 9. `agents.py` — prefix `/api/v1/agents`, tags `["Agents"]`  (2 endpoints, fire DB writes; **service-only**)

`SERVICE_ONLY = [RBACRole.SERVICE]` (`agents.py:34`).

**Models** (`src/models/agent.py`):
- `AgentTaskStartRequest` (`:167`): `task_id:UUID`, `agent_id:str`, `skill_id:str|None=None`, `task_type:str`, `workflow_id:str|None=None`, `application_id:UUID|None=None`, `model_requested:str|None=None`, `model_used:str|None=None`, `started_at:datetime`, `agent_backend:str|None=None`.
- `AgentTaskTimingBlock` (`:187`): `llm_ms:int|None(ge=0)`, `tool_ms:int|None(ge=0)`, `tool_call_count:int|None(ge=0)`.
- `AgentTaskCompleteRequest` (`:204`): `status: Literal["completed","failed","timed_out"]`, `completed_at:datetime`, `duration_ms:int|None`, `input_tokens/output_tokens/cache_read_tokens/cache_write_tokens:int|None`, `quality_score:float|None(ge=0,le=1)`, `error_code:str|None`, `artifact_id:UUID|None`, `cost_estimate:float|None`, `model_used:str|None`, `timing:AgentTaskTimingBlock|None=None`.
- `AgentTaskRecordResponse` (`:231`): `task_id:UUID`, `status:str`, `recorded:bool=True`.

### 9.1 POST `/api/v1/agents/tasks` → `record_task_start` (`agents.py:44`)
- status_code **202**, response_model `AgentTaskRecordResponse`. Body `AgentTaskStartRequest`; `_user=Depends(require_role(*SERVICE_ONLY))`; `db`.
- Logic: `await agents_svc.record_task_start(db, body)`; return `AgentTaskRecordResponse(task_id=body.task_id, status="running")`.
- `agents_svc.record_task_start` (`services/agents.py:24`): `INSERT INTO agent_task (id,task_type,application_id,agent_id,skill_id,workflow_id,status,agent_backend,model_requested,model_used,dispatched_at,started_at) VALUES (...,'running',...,:started_at,:started_at) ON CONFLICT (id) DO NOTHING`; commit. ⚠️ Idempotent by `task_id`.
- Status: 202, 401, 403.

### 9.2 POST `/api/v1/agents/tasks/{task_id}/complete` → `record_task_complete` (`agents.py:66`)
- response_model `AgentTaskRecordResponse` (default 200). `task_id: str`; Body `AgentTaskCompleteRequest`; `_user=require_role(*SERVICE_ONLY)`; `db`.
- Logic: `updated = await agents_svc.record_task_complete(db, task_id, body)`; if not updated → `raise OlympusHTTPException(404,"TASK_NOT_FOUND", f"Agent task '{task_id}' was not recorded at start")`; return `AgentTaskRecordResponse(task_id=task_id, status=body.status)`.
- `record_task_complete` (`services/agents.py:65`): builds `timing_json = json.dumps(req.timing.model_dump(exclude_none=True))` only when `req.timing is not None`. `UPDATE agent_task SET status,completed_at,duration_ms,input_tokens,output_tokens,cache_read_tokens,cache_write_tokens,quality_score,error_code,artifact_id, cost_estimate=COALESCE(:cost_estimate,cost_estimate), model_used=COALESCE(:model_used,model_used), token_usage = CASE WHEN CAST(:timing_json AS jsonb) IS NOT NULL THEN jsonb_set(COALESCE(token_usage,'{}'::jsonb),'{timing}',CAST(:timing_json AS jsonb),true) ELSE token_usage END WHERE id=:id`; commit; return `False` if `rowcount==0` else `True`.
- ⚠️ GOTCHA: `timing` block is merged via `jsonb_set(...,'{timing}',...,true)` to preserve sibling keys; `cost_estimate`/`model_used` use COALESCE (keep existing when null).
- Status: 200, 401, 403, 404 (`TASK_NOT_FOUND`).

---

## 10. `agent_runs.py` — prefix `/api/v1/agent-runs`, tags `["Agent Runs"]`  (1 endpoint)

**Models** (`src/models/agent_run.py`):
- `AgentRunError` (`:20`): `task_id:UUID`, `task_type:str`, `status:Literal["failed","timed_out"]`, `app_id:UUID|None`, `app_name:str|None`, `module_name:str|None`, `agent_backend:str|None`, `model_used:str|None`, `last_error:str|None`, `failed_at:datetime|None`, `duration_ms:int|None`, `retry_count:int=0`.
- `AgentRunErrorListResponse` (`:37`): `errors:list[AgentRunError]=[]`, `limit:int`.

### 10.1 GET `/api/v1/agent-runs/recent-errors` → `recent_errors_route` (`agent_runs.py:27`)
- response_model `AgentRunErrorListResponse`. `limit: int = Query(20, ge=1, le=100)`; `portfolio_id: uuid.UUID|None = Query(None)`; `user=Depends(get_current_user)`; `db`.
- Logic: if `portfolio_id is not None`: `verify_portfolio_access`. `member_ids = filter_portfolio_ids_by_membership(db,user)`. `return await agent_runs.list_recent_errors(db, limit=limit, portfolio_id=..., portfolio_ids=member_ids)`.
- `list_recent_errors` (`services/agent_runs.py:18`):
```
clauses = ["at.status IN ('failed','timed_out')"]; params={"limit":limit}; join_app="LEFT"
if portfolio_ids is not None:
    if not portfolio_ids: return AgentRunErrorListResponse(errors=[])    # ⚠️ note: limit defaulted (no explicit limit kwarg)
    clauses.append("a.portfolio_id = ANY(:pf_ids)"); join_app="INNER"
if portfolio_id is not None: clauses.append("a.portfolio_id = :portfolio_id"); join_app="INNER"
rows = SELECT at.id,at.task_type,at.status,at.application_id,a.name AS app_name,at.module_name,at.agent_backend,
              at.model_used,at.last_error,at.completed_at,at.duration_ms,COALESCE(at.retry_count,0) AS retry_count
       FROM agent_task at {join_app} JOIN application a ON a.id=at.application_id
       WHERE <clauses ANDed>
       ORDER BY at.completed_at DESC NULLS LAST, at.dispatched_at DESC NULLS LAST LIMIT :limit
map → AgentRunError(... failed_at=completed_at ...); return AgentRunErrorListResponse(errors, limit=limit)
```
⚠️ GOTCHA: when scoped (portfolio_id or portfolio_ids present) the app join switches LEFT→INNER. Empty-membership short-circuit returns `AgentRunErrorListResponse(errors=[])` whose `limit` field takes the model default `0` (no `limit=` passed there).
- Status: 200, 401, 403.

---

## 11. `admin.py` — prefix `/api/v1/admin`, tags `["Admin"]`  (1 endpoint)

**Models**:
- `SeedSamplePortfolioRequest` (`:41`): `name: str|None = Field(default=None, max_length=120)`.
- `SeedSamplePortfolioResponse` (`:51`): `portfolio:PortfolioDetail`, `application_count:int`, `application_ids:list[str]`.

`_SAMPLE_APPS` (`admin.py:64`): a fixed list of **12** app dicts (keys: `name, description, archetype, risk_tier, complexity_tier, current_line, current_status, disposition`). Archetypes span web-app/api-service/batch-etl/scheduled-job/hybrid; risk_tier 1/2/3. Reproduce verbatim from source (`:64-185`) — names: Flight Plan Filing Portal, Weather Integration Service, Runway Inspection Tracker, Billing Reconciliation Batch, Radar Feed Aggregator, NOTAM Authoring Tool, Crew Scheduling Legacy, Maintenance Work Orders, Pilot Credentialing Portal, Fuel Burn Analytics, Taxiway Surface Monitoring, Passenger Facility Charge Ledger.

Helpers: `_is_enabled()` (`:188`): `env = OLYMPUS_ENVIRONMENT or "development"`; if env != "production" → True; else `ALLOW_SAMPLE_PORTFOLIO.lower()=="true"`. `_unique_portfolio_name(db, base_name)` (`:201`): query `SELECT name FROM portfolio WHERE name LIKE :pat` (pat=`{base}%`); if base free → base; else first of `f"{base} ({i})"` for i in 2..99; fallback `f"{base} ({uuid4().hex[:6]})"`.

### 11.1 POST `/api/v1/admin/seed-sample-portfolio` → `seed_sample_portfolio` (`admin.py:228`)
- status_code **201**, response_model `SeedSamplePortfolioResponse`. Body `SeedSamplePortfolioRequest`; `_user=Depends(require_role(RBACRole.PORTFOLIO_ADMIN))`; `db`.
- Logic:
```
if not _is_enabled(): raise OlympusHTTPException(403,"SAMPLE_PORTFOLIO_DISABLED","Sample portfolio seeding is disabled in this environment. Set ALLOW_SAMPLE_PORTFOLIO=true to enable.")
base_name = body.name or "Sample Portfolio (Demo)"
portfolio_name = await _unique_portfolio_name(db, base_name)
portfolio_id = uuid4(); now = utcnow(); artifact_repo_url = "olympus/sample-portfolio-demo"
INSERT INTO portfolio (id,name,owner,status,artifact_repo_url,created_at,updated_at) VALUES (:id,:name,'demo','active',:url,:now,:now)
app_ids=[]
for spec in _SAMPLE_APPS:
    app_id=uuid4(); app_ids.append(str(app_id))
    INSERT INTO application (id,portfolio_id,name,description,repo_url, source_git_token,source_git_base_url,
        risk_tier,risk_tier_source, complexity_tier,complexity_tier_source, current_line,current_status,disposition,
        created_at,updated_at)
      VALUES (:id,:portfolio_id,:name,:description, :repo_url=f"https://example.com/sample/{name.lower().replace(' ','-')}",
        NULL,NULL, :risk_tier,'auto', :complexity_tier,'auto', :current_line,:current_status,:disposition, :now,:now)
    overall_score = {"1":0.38,"2":0.62,"3":0.78}[spec.risk_tier]
    INSERT INTO score_history (application_id,dimension,score,recorded_at) VALUES (:app_id,'overall',:score,:now)
db.commit()
_portfolios[str(pid)] = {id,name,owner:"demo",status:"active",artifact_repo_url, artifact_repo_default_branch:"main", webhook_secret:None, profile_id:"", sample:True}
log "admin.sample_portfolio_seeded"
return SeedSamplePortfolioResponse(portfolio=PortfolioDetail(id,name,owner:"demo",status:"active",artifact_repo_url, artifact_repo_default_branch:"main", webhook_secret_configured:False, profile_id:""), application_count=len(app_ids), application_ids=app_ids)
```
⚠️ GOTCHA: there is a dead line at `admin.py:281` — a bare dict literal `{"archetype": spec["archetype"], "sample": "true"}` with no assignment (no effect; preserve only if mirroring exactly, otherwise omit). Safe to call repeatedly (unique name). `risk_tier_source`/`complexity_tier_source` hardcoded `'auto'`.
- Status: 201, 401, 403 (`SAMPLE_PORTFOLIO_DISABLED` or non-admin).

---

## 11b. `admin_audit.py` — prefix `/api/v1/admin`, tags `["Admin"]`  (1 endpoint) — ⚠️ NEW router at HEAD `7cb3b20c`

`router = APIRouter(prefix="/api/v1/admin", tags=["Admin"])` (`admin_audit.py:31`). Centralized RBAC audit-log feed (P6-S6.6, `rbac-model.md` §8.2). Mounted at `main.py:213` (`admin_audit_router`), sharing the `/api/v1/admin` namespace with `admin.py` (212) and `portfolio_members.py` (214).

### 11b.1 GET `/api/v1/admin/audit-log` → `get_audit_log` (`admin_audit.py:34`)
- **Auth:** `Depends(require_role(RBACRole.PORTFOLIO_ADMIN, RBACRole.PORTFOLIO_MANAGER))` — admin OR manager only.
- **Query params:** `pagination = Depends(get_pagination)`; `portfolio_id: uuid.UUID|None=Query(None)`; `event_type: str|None=Query(None)`; `actor: str|None=Query(None)` (filter by actor user sub); `from_ts: datetime|None=Query(None, alias="from")`; `to_ts: datetime|None=Query(None, alias="to")`. ⚠️ `from`/`to` are the wire names (aliased).
- **Returns:** `dict` (no response_model) → `paginated_response(events, total, pagination)`. Status 200; 400 `AUDIT_EVENT_TYPE_INVALID`; 401; 403.
- **Handler:**
  ```
  if event_type is not None and event_type not in audit_svc.EVENT_TYPES:
      raise OlympusHTTPException(400, "AUDIT_EVENT_TYPE_INVALID",
          f"Invalid event_type '{event_type}'. Allowed: {sorted(audit_svc.EVENT_TYPES)}.")
  events, total = await audit_svc.query_audit_events(db, portfolio_id=, event_type=, actor=,
      from_ts=, to_ts=, limit=pagination.per_page, offset=pagination.offset)
  return paginated_response(events, total, pagination)
  ```
- **`EVENT_TYPES`** (`src/services/audit_log.py:27-33`): `("approval","rejection","escalation","force_advance","membership_grant")`.
- **Service `query_audit_events(db, *, portfolio_id, event_type, actor, from_ts, to_ts, limit, offset)`** (`audit_log.py:44-222`) — read-only projection that UNIONs four source tables in Python (Olympus principle 4: no new authoritative store). Reproduce EVERY source branch:
  ```
  events=[]; want = {event_type} if event_type else set(EVENT_TYPES)
  # (1) "approval" → gate_approval JOIN gate (+LEFT JOIN application/wave for portfolio_id):
  if "approval" in want:
      rows = SELECT ga.gate_id, ga.approved_by, ga.approver_role, ga.is_oversight,
                    ga.is_management_override, ga.comment, ga.approved_at, g.gate_type,
                    COALESCE(a.portfolio_id, w.portfolio_id) AS portfolio_id
             FROM gate_approval ga JOIN gate g ON g.id=ga.gate_id
             LEFT JOIN application a ON a.id=g.application_id LEFT JOIN wave w ON w.id=g.wave_id
      → event {event_type:"approval", actor:approved_by, actor_role:approver_role, target:str(gate_id),
               portfolio_id, details:{gate_type, is_oversight, is_management_override, comment}, occurred_at:approved_at}
  # (2) "rejection" → gate rows status='rejected' AND decided_by IS NOT NULL:
  if "rejection" in want:
      rows = SELECT g.id, g.gate_type, g.decided_by, g.decided_at, g.justification,
                    g.reject_reason_category, COALESCE(a.portfolio_id, w.portfolio_id) AS portfolio_id
             FROM gate g LEFT JOIN application a ... LEFT JOIN wave w ...
             WHERE g.status='rejected' AND g.decided_by IS NOT NULL
      → {event_type:"rejection", actor:decided_by, actor_role:None, target:str(id), portfolio_id,
         details:{gate_type, reason_category:reject_reason_category, feedback:justification}, occurred_at:decided_at}
  # (3) "escalation"/"force_advance" → audit_log WHERE action = ANY(:actions):
  al_actions=[]; if "escalation" in want: al_actions += "gate.escalate"; if "force_advance" in want: al_actions += "gate.force_advance"
  if al_actions:
      rows = SELECT actor, action, resource_id, details, timestamp FROM audit_log WHERE action = ANY(:actions)
      → {event_type: "force_advance" if action=="gate.force_advance" else "escalation",
         actor, actor_role:None, target:resource_id, portfolio_id:None, details:(details or {}), occurred_at:timestamp}
  # (4) "membership_grant" → portfolio_membership:
  if "membership_grant" in want:
      rows = SELECT portfolio_id, user_id, role, granted_by, granted_at FROM portfolio_membership
      → {event_type:"membership_grant", actor:granted_by, actor_role:None, target:user_id, portfolio_id,
         details:{role, portfolio_id:str(portfolio_id)}, occurred_at:granted_at}
  # (5) IN-MEMORY filter + sort (admin-scoped, small feed; materialized view flagged as follow-up >10K/day):
  def _match(ev): portfolio_id mismatch→False; actor mismatch→False;
                  from_ts and (occurred is None or occurred<from_ts)→False; to_ts and (occurred>to_ts)→False; else True
  filtered = [e for e in events if _match(e)]
  filtered.sort(key=lambda e: e.get("occurred_at") or datetime.min, reverse=True)   # ⚠️ newest-first; None→datetime.min
  total = len(filtered); page = filtered[offset : offset+limit]
  for e in page: e["occurred_at"]=_iso(e["occurred_at"]); if e["portfolio_id"] is not None: e["portfolio_id"]=str(...)
  return page, total
  ```
  ⚠️ GOTCHAs: (a) `portfolio_id` filter is applied IN PYTHON after the union — escalation/force_advance events have `portfolio_id=None` so they are EXCLUDED whenever `portfolio_id` is supplied; (b) total is the post-filter count, pagination slices the in-memory list; (c) `_iso` (audit_log.py:36) → `value.isoformat()` for datetime else `str(value)`, None→None.

---

## 12. `activity.py` — prefix `/api/v1/activity`, tags `["Activity"]`  (1 endpoint)

### 12.1 GET `/api/v1/activity/recent` → `get_recent_activity` (`activity.py:21`)
- Returns `list[dict]`. `limit: int = 20` (plain default, no Query constraints); `portfolio_id: uuid.UUID|None = Query(None)`; `user=Depends(get_current_user)`; `db`.
- Logic:
```
if portfolio_id is not None: verify_portfolio_access(db,user,portfolio_id)
member_ids = filter_portfolio_ids_by_membership(db,user)
app_clauses=[]; gate_clauses=[]; params={"limit":limit}
if member_ids is not None:
    if not member_ids: return []
    app_clauses.append("a.portfolio_id = ANY(:pf_ids)"); gate_clauses.append("g.portfolio_id = ANY(:pf_ids)"); params["pf_ids"]=member_ids
if portfolio_id is not None:
    app_clauses.append("a.portfolio_id = :portfolio_id"); gate_clauses.append("g.portfolio_id = :portfolio_id"); params["portfolio_id"]=portfolio_id
app_where  = "WHERE "+" AND ".join(app_clauses)  if app_clauses  else ""
gate_where = "WHERE "+" AND ".join(gate_clauses) if gate_clauses else ""
app_rows = SELECT a.id,a.name,a.current_status,a.current_step,a.current_line,a.updated_at FROM application a {app_where} ORDER BY a.updated_at DESC LIMIT :limit
gate_rows = SELECT g.id,g.gate_type,g.status,g.decided_by,g.requested_at,g.decided_at,a.name AS app_name,g.application_id AS app_id
            FROM gate g LEFT JOIN application a ON a.id=g.application_id {gate_where}
            ORDER BY COALESCE(g.decided_at,g.requested_at) DESC LIMIT :limit
events=[]
for r in app_rows: events.append({type:"app_status_change", timestamp:r.updated_at.isoformat() or "", app_id:str(r.id), app_name:r.name,
                                  description:f"{r.name} — {_format_status(r.current_status)}", detail:r.current_step or r.current_line or ""})
for r in gate_rows:
    ts = r.decided_at or r.requested_at
    desc = ("Gate {gt} requested for {app}" if status=="pending" else
            "Gate {gt} approved for {app}"  if status=="approved" else
            "Gate {gt} rejected for {app}"  if status=="rejected" else
            "Gate {gt} — {status} for {app}")
    events.append({type:"gate_activity", timestamp:ts.isoformat() or "", app_id:str(r.app_id), app_name:r.app_name or "",
                   description:desc, detail:f"Decided by {r.decided_by}" if r.decided_by else ""})
events.sort(key=lambda e: e["timestamp"], reverse=True)
return events[:limit]
```
- `_format_status(status)` (`:122`): `"unknown"` if falsy else `status.replace("_"," ").title()`.
- ⚠️ GOTCHA: combined app+gate events are re-sorted by ISO-string `timestamp` descending then sliced to `limit`. Empty-membership short-circuit returns `[]`.
- Status: 200, 401, 403.

---

## 13. `events.py` — prefix `/api/v1/events`, tags `["Events"]`  (1 HTTP GET + 1 WebSocket) — **no auth**

Module: `class ConnectionManager` (`events.py:28`) holds `_ws_connections: list[WebSocket]` + `_event_queues: list[asyncio.Queue]`; methods `connect_ws`, `disconnect_ws`, `create_sse_queue`, `remove_sse_queue`, `broadcast(event_type, payload)`. `broadcast` JSON-encodes `{type, payload, timestamp:utcnow-iso}` and sends to all WS clients (dropping dead) + puts on every SSE queue. Singleton `manager = ConnectionManager()` (`:78`).

### 13.1 WEBSOCKET `/api/v1/events/ws` → `websocket_events` (`events.py:87`)
- `@router.websocket("/ws")`. Params: `ws: WebSocket`, `event_types: str|None = Query(None)`.
- Logic: `await manager.connect_ws(ws)`; loop `data = await ws.receive_text()`; if `data=="ping"` → `await ws.send_text("pong")`; on `WebSocketDisconnect` → `manager.disconnect_ws(ws)`. (Echo heartbeat keepalive.)

### 13.2 GET `/api/v1/events` → `sse_events` (`events.py:123`)
- Returns `StreamingResponse` (`media_type="text/event-stream"`). Params: `request: Request`, `event_types: str|None = Query(None, description="Comma-separated event types")`.
- Logic: `queue = manager.create_sse_queue()`; `event_stream()` async-gen loops while not `request.is_disconnected()`; `try: message = await asyncio.wait_for(queue.get(), timeout=15.0); yield f"data: {message}\n\n"` `except asyncio.TimeoutError: yield ": keepalive\n\n"`; `finally: manager.remove_sse_queue(queue)`. Response headers: `Cache-Control:no-cache`, `Connection:keep-alive`, `X-Accel-Buffering:no`.
- Status: 200 (streaming).
- (Note: `_sse_generator` helper at `:109` uses a 30s timeout — but `sse_events` defines its own inline `event_stream` with 15s; the inline one is what runs.)

---

## 14. `git.py` — prefix `/api/v1/git`, tags `["Git"]`  (1 endpoint)

`MANAGER_ROLES = [PORTFOLIO_MANAGER, PORTFOLIO_ADMIN]` (`git.py:35`).
**Model** `RepoAvailableResponse` (`:41`): `repo:str`, `available:bool`, `reason:str=""`.

### 14.1 GET `/api/v1/git/repo-available` → `repo_available` (`git.py:50`)
- response_model `RepoAvailableResponse`. `repo: str = Query(...)`; `_user=Depends(require_role(*MANAGER_ROLES))`.
- Logic:
```
if "/" not in repo or repo.count("/") != 1: raise OlympusHTTPException(400,"INVALID_REPO_SLUG", f"repo must be 'owner/name', got {repo!r}")
config = get_config()
if not config.github_token: raise OlympusHTTPException(503,"GIT_TOKEN_MISSING","GITHUB_TOKEN must be configured to check repo availability.")
git_svc_config = GitServiceConfig(token, repo=repo, base_url)
try: GitService(git_svc_config)        # ctor succeeds ⇒ repo EXISTS
except GitServiceError as exc:
    msg=str(exc).lower()
    if "not found" in msg or "404" in msg or "does not exist" in msg: return RepoAvailableResponse(repo, available=True)
    log; raise OlympusHTTPException(500,"GIT_CHECK_FAILED", f"Could not verify repo: {exc}")
except Exception as exc:                # PyGithub native GithubException
    msg=repr(exc).lower()
    if "404" in msg or "not found" in msg: return RepoAvailableResponse(repo, available=True)
    log; raise OlympusHTTPException(500,"GIT_CHECK_FAILED", f"Could not verify repo: {exc}")
return RepoAvailableResponse(repo, available=False, reason="repo exists")
```
⚠️ GOTCHA: inverted semantics — `available=True` means the repo does NOT exist (safe to create). Construction succeeding ⇒ exists ⇒ `available=False`. Auth/network errors surface as 500 (not conflated with "free to create").
- Status: 200, 400 (`INVALID_REPO_SLUG`), 401, 403, 500 (`GIT_CHECK_FAILED`), 503 (`GIT_TOKEN_MISSING`).

---

## 15. `human_paired_agent.py` — prefix `/api/v1`, tags `["Human-Paired Agent"]`  (3 endpoints)

Every endpoint requires a valid bearer token (`get_current_user`); the carried identity is `user.sub`.

**Models** (`src/models/human_paired_agent.py`):
- `ActorKind = Literal["olympus_agent","human","human_with_agent"]`.
- `LocalAgentDescriptor` (`:57`): `tool:str=Field(...)`, `version:str|None=None`, `model:str|None=None`.
- `MyTaskSummary` (`:76`): `task_id:UUID`, `task_type:str`, `skill_id:str|None=None`, `application_id:UUID|None=None`, `wave_id:UUID|None=None`, `status:str`, `actor_kind:ActorKind`, `dispatched_at:datetime|None=None`, `input_artifact_refs:list[str]=[]`, `output_artifact_ref:str|None=None`, `local_agent_descriptor:LocalAgentDescriptor|None=None`, `human_user_id:str|None=None`.
- `MyTasksResponse` (`:122`): `items:list[MyTaskSummary]=[]`, `total:int=0`.
- `LocalAgentSession` (`:134`): `transcript_artifact_ref/prompt_artifact_ref/diff_artifact_ref/summary_artifact_ref:str|None=None`, `transcript_hash:str|None=None`, `tool/version/model:str|None=None`.
- `TaskReturnRequest` (`:170`): `status: Literal["completed","needs_help"]=Field(...)`, `result_artifact_refs:list[str]=[]`, `implementation_notes_ref:str|None=None`, `gate_evidence_refs:list[str]=[]`, `local_agent_session:LocalAgentSession|None=None`, `feedback_text:str|None=None`, `output_payload:dict[str,Any]|None=None`, `output_payload_path:str|None=None`.
- `TaskReturnResponse` (`:245`): `task_id:UUID`, `status:str`, `actor_kind:ActorKind`, `session_artifact_ids:list[UUID]=[]`, `validation_errors:list[str]=[]`.
- `TaskAuditNarrative` (`:278`): `task_id:UUID`, `actor_kind:ActorKind`, `actor_sentence:str=Field(...)`, `skill_id:str|None=None`, `task_type:str`, `dispatched_at:datetime|None=None`, `completed_at:datetime|None=None`, `output_artifact_ref:str|None=None`, `session_artifact_refs:list[str]=[]`, `local_agent_descriptor:LocalAgentDescriptor|None=None`, `human_user_id:str|None=None`.

`render_actor_sentence(*, actor_kind, skill_id, task_type, human_user_id, local_agent_descriptor, dispatched_at, completed_at, agent_id=None) -> str` (`models/human_paired_agent.py:313`) — PURE:
```
skill_or_type = skill_id or task_type
when = " between {d.iso} and {c.iso}" if both else " dispatched at {d.iso}" if d only else ""
olympus_agent → f"{agent_id or 'Olympus agent'} ran skill {skill_or_type}{when}."
human         → f"{human_user_id or 'Unknown human user'} accepted task {skill_or_type}{when}; no local agent contributed."
human_with_agent → who=human_user_id or 'Unknown human user';
   tool/model from descriptor (LocalAgentDescriptor or dict; else 'unknown local agent'/None);
   paired = f"paired with {tool}" (+ f" ({model})" if model);
   f"{who} ({paired}) accepted task {skill_or_type}{when}; session transcript captured."
```

### 15.1 GET `/api/v1/me/tasks` → `list_my_tasks` (`human_paired_agent.py:41`)
- response_model `MyTasksResponse`. `user=Depends(get_current_user)`; `db`; `include_claimable: bool = Query(True)`; `portfolio_id: str|None = Query(None)`; `limit: int = Query(50, ge=1, le=200)`.
- Logic: `return await hpa_service.list_my_tasks(db, human_user_id=user.sub, include_claimable=include_claimable, portfolio_id=portfolio_id, limit=limit)`.
- Service `list_my_tasks` (`services/human_paired_agent.py:49`):
```
identity_clause = "(at.human_user_id = :human_user_id OR at.human_user_id IS NULL)" if include_claimable
                  else "at.human_user_id = :human_user_id"
portfolio_clause = "AND (a.portfolio_id = :portfolio_id OR w.portfolio_id = :portfolio_id)" if portfolio_id else ""
SELECT at.id,at.task_type,at.skill_id,at.application_id,at.wave_id,at.status,at.actor_kind,at.human_user_id,
       at.dispatched_at,at.input_artifact_refs,at.output_artifact_ref,at.local_agent_descriptor
FROM agent_task at LEFT JOIN application a ON a.id=at.application_id LEFT JOIN wave w ON w.id=at.wave_id
WHERE at.actor_kind IN ('human','human_with_agent') AND {identity_clause}
      AND at.status NOT IN ('completed','failed','timed_out') {portfolio_clause}
ORDER BY at.dispatched_at DESC NULLS LAST LIMIT :limit
→ items = [_row_to_my_task_summary(r)]; MyTasksResponse(items, total=len(items))
```
`_row_to_my_task_summary` (`:130`): descriptor built only if `local_agent_descriptor` is a dict with a `tool` key; `input_artifact_refs` coerced (dict→`refs` key or []; list→stringify each; else []); status defaults `"queued"`, actor_kind defaults `"human"`.
- Status: 200, 401.

### 15.2 POST `/api/v1/agent-tasks/{task_id}/return` → `return_agent_task` (`human_paired_agent.py:84`)
- response_model `TaskReturnResponse`. `task_id: uuid.UUID`; Body `payload: TaskReturnRequest`; `user=Depends(get_current_user)`; `db`.
- Router logic: `response = await hpa_service.return_task(db, task_id, payload, human_user_id=user.sub)`; ⚠️ then `if response.validation_errors: await db.rollback() else: await db.commit()`; return response.
- Service `return_task` (`services/human_paired_agent.py:172`):
```
task_row = SELECT at.id,at.task_type,at.skill_id,at.actor_kind,at.human_user_id,at.local_agent_descriptor,at.status,at.output_artifact_ref FROM agent_task at WHERE at.id=:id
if task_row is None: raise OlympusHTTPException(404,"TASK_NOT_FOUND", f"Agent task {task_id} not found")
actor_kind = task_row.actor_kind or "olympus_agent"
if actor_kind == "olympus_agent": raise OlympusHTTPException(400,"TASK_NOT_HUMAN_PAIRED", "... reserved for human-paired tasks")
existing_user = task_row.human_user_id
if existing_user and existing_user != human_user_id: raise OlympusHTTPException(403,"TASK_OWNED_BY_OTHER", "... claimed by another user")
validation_errors = _validate_return_payload(payload, actor_kind=actor_kind)
if validation_errors:                # SOFT failure path — returns 200 body, router rolls back
    return TaskReturnResponse(task_id, status=task_row.status or "queued", actor_kind, session_artifact_ids=[], validation_errors=validation_errors)
violations, debug_info = validate_return_output_payload(skill_id=task_row.skill_id, output_payload=payload.output_payload, payload_path=payload.output_payload_path)
if violations:
    details={"violations":violations}; details.update(debug_info if debug_info)
    raise OlympusHTTPException(400,"OUTPUT_SPEC_VIOLATION", f"... {len(violations)} rule(s) failed.", details=details)
new_status = "completed" if payload.status=="completed" else "needs_help"
completed_at = utcnow() if payload.status=="completed" else None
output_ref = payload.implementation_notes_ref or (payload.result_artifact_refs[0] if payload.result_artifact_refs else None)
UPDATE agent_task SET status=:new_status, completed_at=COALESCE(:completed_at,completed_at), human_user_id=:human_user_id,
       output_artifact_ref=COALESCE(:output_ref,output_artifact_ref),
       last_error = CASE WHEN :feedback IS NULL THEN last_error ELSE :feedback END
   WHERE id=:id
session_ids = await _persist_session_artifacts(db, task_id, payload.local_agent_session) if local_agent_session else []
return TaskReturnResponse(task_id, status=new_status, actor_kind, session_artifact_ids=session_ids, validation_errors=[])
```
`_validate_return_payload(payload, actor_kind) -> list[str]` (structural, `:337`):
- `status=="completed"` and no `implementation_notes_ref` and no `result_artifact_refs` → error "completed return must include implementation_notes_ref or at least one result_artifact_refs entry".
- `actor_kind=="human_with_agent"` and `local_agent_session is None` → error "actor_kind='human_with_agent' requires local_agent_session ...".
- `actor_kind=="human"` and `local_agent_session` present and ANY of its 4 refs set → error "actor_kind='human' must not include a local_agent_session block — bump actor_kind to 'human_with_agent' first".
`_persist_session_artifacts(db, task_id, session) -> list[uuid]` (`:395`): builds inserts list — `("transcript", ref, transcript_hash)` if transcript_artifact_ref; `("prompt", ref, None)`; `("diff", ref, None)`; `("summary", ref, None)` for each set ref; per insert `INSERT INTO agent_task_session_artifact (agent_task_id,kind,artifact_ref,hash) VALUES (...) RETURNING id`; collect ids. If `session.tool`: `UPDATE agent_task SET local_agent_descriptor = CAST(:descriptor AS JSONB) WHERE id=:id` with `json.dumps({tool,version,model})`.
- ⚠️ GOTCHA: two-layer validation. Layer 1 (structural) failures return HTTP 200 with `validation_errors` populated and the router ROLLS BACK (no DB writes persist). Layer 2 (strict output-spec via `return_payload_validator.validate_return_output_payload`) failures raise `OUTPUT_SPEC_VIOLATION` 400. Commit happens only when `validation_errors` is empty.
- Status: 200 (success OR soft-validation-fail), 400 (`TASK_NOT_HUMAN_PAIRED`, `OUTPUT_SPEC_VIOLATION`), 401, 403 (`TASK_OWNED_BY_OTHER`), 404 (`TASK_NOT_FOUND`).

### 15.3 GET `/api/v1/agent-tasks/{task_id}/audit-narrative` → `get_audit_narrative` (`human_paired_agent.py:133`)
- response_model `TaskAuditNarrative`. `task_id: uuid.UUID`; `_user=Depends(get_current_user)`; `db`.
- Logic: `return await hpa_service.render_task_audit_narrative(db, task_id=task_id)`.
- Service `render_task_audit_narrative` (`services/human_paired_agent.py:476`): `SELECT at.id,at.task_type,at.skill_id,at.agent_id,at.actor_kind,at.human_user_id,at.local_agent_descriptor,at.dispatched_at,at.completed_at,at.output_artifact_ref FROM agent_task at WHERE at.id=:id`; None→`OlympusHTTPException(404,"TASK_NOT_FOUND",...)`; build descriptor (dict-with-tool guard); `actor_kind = row.actor_kind or "olympus_agent"`; `actor_sentence = render_actor_sentence(...)`; `session_refs = SELECT artifact_ref FROM agent_task_session_artifact WHERE agent_task_id=:id ORDER BY captured_at ASC`; return `TaskAuditNarrative(... session_artifact_refs=[r.artifact_ref], ...)`.
- Status: 200, 401, 404 (`TASK_NOT_FOUND`).

---

## Endpoint count summary (gate)

| Router | endpoints | paths |
|---|---|---|
| portfolio | 4 | POST `/api/v1/portfolio`; GET `/api/v1/portfolio`; GET `/api/v1/portfolio/{portfolio_id}`; GET `/api/v1/portfolio/{portfolio_id}/target-state-rollup` |
| portfolio_members | 3 | GET/POST `/api/v1/admin/portfolios/{portfolio_id}/members`; DELETE `/api/v1/admin/portfolios/{portfolio_id}/members/{user_id}` |
| lines | 4 + 3 | GET `/api/v1/lines`; GET `/api/v1/lines/{line_name}`; GET `…/status`; GET `…/throughput`; POST `/api/v1/architecture/start`; POST `/api/v1/data/start`; POST `/api/v1/modernization/start` |
| profiles | 4 + 2 | GET `/api/v1/profiles`; GET `/active`; GET `/compare`; GET `/{profile_id}`; GET `/api/v1/portfolio/{portfolio_id}/profile-bundle`; PUT `/api/v1/portfolio/{portfolio_id}/profile` |
| system | 4 | GET `/health/live`; GET `/system/info`; GET `/system/metrics`; GET `/system/dependencies` |
| health | 4 | GET `/health`; `/health/detailed`; `/health/temporal`; `/health/ready` |
| artifacts | 4 | POST `/api/v1/artifacts/validate`; GET `/{app_id}`; GET `/{app_id}/{path:path}/history`; GET `/{app_id}/{path:path}` |
| renditions | 2 | POST `/api/v1/applications/{app_id}/renditions/generate`; GET `/api/v1/applications/{app_id}/renditions` |
| agents | 2 | POST `/api/v1/agents/tasks`; POST `/api/v1/agents/tasks/{task_id}/complete` |
| agent_runs | 1 | GET `/api/v1/agent-runs/recent-errors` |
| admin | 1 | POST `/api/v1/admin/seed-sample-portfolio` |
| **admin_audit** ⚠️NEW | 1 | GET `/api/v1/admin/audit-log` |
| activity | 1 | GET `/api/v1/activity/recent` |
| events | 1 GET + 1 WS | GET `/api/v1/events` (SSE); WS `/api/v1/events/ws` |
| git | 1 | GET `/api/v1/git/repo-available` |
| human_paired_agent | 3 | GET `/api/v1/me/tasks`; POST `/api/v1/agent-tasks/{task_id}/return`; GET `/api/v1/agent-tasks/{task_id}/audit-narrative` |
