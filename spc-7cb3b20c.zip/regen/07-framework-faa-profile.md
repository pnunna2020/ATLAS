# 07 (PART C) — The Full FAA Client Profile

> ATOMIC regeneration specification, behavioral-parity bar. This document is the field-level reproduction of the FAA profile bundle and the code that loads/applies it. It is split out of `regen/07-framework.md` (which holds PART A — the 6 extension points, and PART B — the line-to-line contract). Every override is reproduced at FIELD LEVEL with its EFFECT. ⚠️ GOTCHA marks non-obvious / fragile / ordering-dependent behavior. Citations are `path:line`.
>
> **Profile root:** `/Users/pnunna/Documents/GitHub/foundry/profiles/faa/`
>
> **Bundle inventory (verified `profiles/faa/`):** `profile.yaml` (94 lines), `compliance.yaml` (303), `risk-classification.yaml` (130), `gates.yaml` (138), `scoring.yaml` (61), `technology.yaml` (148), `wave-planning.yaml` (105), `delegation.yaml` (24), `objectives.yaml` (332), `README.md` (22156 bytes); plus dirs `config/` (17 YAMLs), `skills/` (55 entries), `branding/`, `context-priors/`, `regulatory-knowledge/` (5 CFR parts), `baselines/` (`2024.yaml`), `templates/`.

## Table of Contents — PART C

- **C.0** — How the profile is consumed (the 4 loaders + their env vars) — read first
- **C.1** — `profile.yaml` (metadata + activation)
- **C.2** — `compliance.yaml` (5 domains + regulatory_sources + branding)
- **C.3** — `risk-classification.yaml` (3 tiers + signals + override rules)
- **C.4** — `gates.yaml` (gate overrides + additional roles + SLA)
- **C.5** — `scoring.yaml` (6 dimensions; weight-sum proof)
- **C.6** — `technology.yaml` (approved stack)
- **C.7** — `wave-planning.yaml`
- **C.8** — `delegation.yaml`
- **C.9** — `objectives.yaml` (8 SOO objectives) + `baselines/2024.yaml`
- **C.10** — `config/*.yaml` skill overlays (16 skill-var files + `common.yaml`)
- **C.11** — Branding, mission context, context-priors/manifest, regulatory-knowledge
- **C.12** — HOW a profile loads & overlays apply (loader pseudocode)
- **C.13** — What a profile CAN vs CANNOT override (⚠️ hard core constants)

---

## C.0 — How the FAA profile is consumed (read first)

⚠️ **GOTCHA — there are FOUR independent loaders for the SAME profile bundle, and they DO NOT share a code path, a cache, OR an environment variable.** Reproducing parity means reproducing all four separately. They are:

| # | Loader | File | Env var(s) | What it produces / applies | When it runs |
|---|---|---|---|---|---|
| 1 | **API typed loader + activation** | `olympus-api/src/services/profile_loader.py` + `profile_activation.py` | `OLYMPUS_PROFILE` (id), `OLYMPUS_PROFILES_DIR` (parent dir) | parses the 6 required YAMLs into a frozen `Profile`, then calls `apply_profile(profile)` → overrides scoring + gate + skill-composition registries | API startup / profile-switch |
| 2 | **Worker minimal parser + activation** | `temporal/olympus_workflows/registries/worker_bootstrap.py` | `OLYMPUS_PROFILE` (id), `OLYMPUS_PROFILES_DIR` (parent dir) | a minimal duck-typed YAML→stub parser producing the same Protocol shapes, then calls `apply_profile(stub)` | worker `run_worker` startup, before accepting tasks |
| 3 | **Mission-context loader** | `olympus-agent-runtime/src/services/profile_context.py` | **`OLYMPUS_PROFILE_ROOT`** (the profile DIR itself, NOT the parent) | reads `profile.yaml` `mission_context`, loads the referenced markdown body, prepends it to every dispatched agent's system prompt | per agent dispatch (cached per-process) |
| 4 | **Skill bootstrap (filesystem→DB)** | `olympus-api/src/services/skill_bootstrap.py` | `SKILLS_ROOT` (repo root) | scans `cross-cutting/skills/` then `profiles/faa/skills/`, parses each `SKILL.md`, layers FAA overlays, upserts into the `skill` table | API startup |

⚠️ **The env-var split is the #1 parity hazard.** Loaders 1 & 2 take a profile **id** plus a **parent** dir (`OLYMPUS_PROFILE` + `OLYMPUS_PROFILES_DIR`); loader 3 takes the profile **directory itself** in `OLYMPUS_PROFILE_ROOT`; loader 4 takes the **repo root** in `SKILLS_ROOT`. Confusing these silently disables an entire facet of the profile (e.g. an unset `OLYMPUS_PROFILE_ROOT` → no mission context → agents lose the SOO framing, but registries still override fine).

⚠️ **GOTCHA — only registry-applied facets actually mutate runtime behavior through `apply_profile`.** `apply_profile` (PART A §A.8.3, `profile_overrides.py:149-176`) touches **only three** registries: scoring dimensions, gate providers (default + per-gate overrides), and skill composition. Everything else in the bundle (compliance domains, risk tiers, technology, wave-planning, SLA, additional_roles, objectives, regulatory_sources, branding) is **data consumed elsewhere** — by the API endpoints, the dashboard, agent prompts, the exec microsite, and human reviewers — NOT by the workflow registries. See C.12 for the precise application map.

The full loader pseudocode lives in C.12; the env-var resolution walks in C.12.4. PART A §A.8–A.9 already reproduces `apply_profile`, the three apply-helpers, and `worker_bootstrap` byte-for-byte — C.12 cross-references rather than duplicates.

---

## C.1 — `profile.yaml` (metadata + activation config)

**File:** `profiles/faa/profile.yaml` (94 lines). Top-level wrapper key: `profile:` (everything nests under it). The API loader unwraps `raw.get("profile")` (`profile_loader.py:285`); the worker unwraps `.get("profile")` (`worker_bootstrap.py:103`); the mission loader tolerates either flat or nested (`profile_context.py:179-188`).

### C.1.1 Identity block (`profile.yaml:4-8`)
| key | value | effect |
|---|---|---|
| `profile.id` | `"faa"` | canonical profile id. Used to name the skill-composition (`{id}-profile-skills` = `faa-profile-skills`, PART A §A.8.4), to resolve the profile dir (`<profiles_dir>/faa`), and as the DB `active profile` key. ⚠️ `_load_metadata` REQUIRES `id`/`name`/`version` (raises `ProfileLoadError` if any missing — `profile_loader.py:290-294`). |
| `profile.name` | `"Federal Aviation Administration"` | display name (dashboard, logs). |
| `profile.version` | `"1.0.0"` | profile version (logged at activation — `profile_activation.py:105-110`). Free-form string; NOT semver-validated by the loader (unlike registry `VersionRecord`). |
| `profile.description` | `"Domain-specific customizations for FAA legacy modernization program"` | free text. |

### C.1.2 `organization` (`profile.yaml:10-13`)
Loaded into `ProfileMetadata.organization: dict` verbatim (`profile_loader.py:306`). Keys/values:
- `name: "Federal Aviation Administration"`
- `parent: "U.S. Department of Transportation"`
- `sector: "Federal Government — Transportation"`

Effect: metadata only — surfaced on the profile-info API/dashboard. No runtime branch keys off it.

### C.1.3 `portfolio` (`profile.yaml:15-19`)
Loaded into `ProfileMetadata.portfolio: dict` verbatim. Keys/values:
- `estimated_size: 200` (applications)
- `estimated_databases: 3000`
- `program_duration: "10 years"`
- `primary_concern: "NAS safety"`

Effect: informational; drives no scheduling. (The 200-app / 10-yr figures recur in `objectives.yaml` targets and `wave-planning.yaml` narrative.)

### C.1.4 `extensions` (`profile.yaml:22-33`) — activation pointers
⚠️ The loader coerces every value to `str` via `{str(k): str(v) for k,v in extensions.items()}` (`profile_loader.py:310`) and REQUIRES the block to be a mapping (`profile_loader.py:296-298`). Keys → values (filenames relative to the profile root):
| key | value | effect |
|---|---|---|
| `compliance` | `"compliance.yaml"` | names the compliance bundle file (C.2). |
| `risk_classification` | `"risk-classification.yaml"` | names the risk file (C.3). |
| `gates` | `"gates.yaml"` | names the gate-overrides file (C.4). |
| `scoring` | `"scoring.yaml"` | names the scoring file (C.5). |
| `technology` | `"technology.yaml"` | names the tech file (C.6). |
| `wave_planning` | `"wave-planning.yaml"` | names the wave file (C.7). |
| `objectives` | `"objectives.yaml"` | names the Agency-Objectives file (C.9). |

⚠️ **GOTCHA — `extensions` is descriptive, not load-driving for the 6 core files.** The API loader does NOT consult `extensions` to find the 6 required files; it hard-codes `_EXPECTED_FILES = ("profile.yaml","compliance.yaml","risk-classification.yaml","gates.yaml","scoring.yaml","technology.yaml")` and reads them by literal name (`profile_loader.py:244-251, 501-506`). So `extensions.compliance: "compliance.yaml"` is documentation/consistency; renaming the file via `extensions` would NOT change which file the loader reads (it would still read `compliance.yaml` and fail if absent). `wave_planning` and `objectives` are NOT in `_EXPECTED_FILES` — they are loaded by other subsystems (wave planner, objectives/exec microsite), not the core `load_profile`. ⚠️ Comment (`profile.yaml:29-32`) notes `objectives.yaml` may be absent during phases AO-0→AO-1 without breaking CI, but runtime activation requires it to exist when the objectives endpoint is hit.

### C.1.5 `skills` (`profile.yaml:36-50`) — profile-specific skills
Loaded into `ProfileMetadata.skills: tuple[str,...]` (`profile_loader.py:308`). Ordered list (order preserved):
1. `"skills/faa-code-standards/SKILL.md"`
2. `"skills/faa-style-greenfield/SKILL.md"`
3. `"skills/faa-style-brownfield/SKILL.md"`
4. `"skills/pilot-certification-domain-modeler/SKILL.md"`
5. `"skills/faa-form-schema-generator/SKILL.md"`
6. `"skills/aerospace-medical-certification-mapper/SKILL.md"`
7. `"skills/form-8710-validator/SKILL.md"`
8. `"skills/medxpress-confirmation-binder/SKILL.md"`
9. `"skills/ame-decision-workflow-scaffolder/SKILL.md"`

⚠️ **EFFECT — this list drives the skill-composition registry.** `apply_profile` → `_apply_skill_composition(metadata)` (PART A §A.8.4, `profile_overrides.py:229-260`) extracts the **second-to-last path segment** of each entry (so `"skills/faa-code-standards/SKILL.md"` → `"faa-code-standards"`), and registers ONE `SkillComposition(name="faa-profile-skills", skills=(<all 9 ids>), mode="sequential", description="Custom skills declared by the faa profile.")`. So after activation, `SKILL_COMPOSITION_REGISTRY.get("faa-profile-skills").skills == ("faa-code-standards","faa-style-greenfield","faa-style-brownfield","pilot-certification-domain-modeler","faa-form-schema-generator","aerospace-medical-certification-mapper","form-8710-validator","medxpress-confirmation-binder","ame-decision-workflow-scaffolder")`.
⚠️ **GOTCHA — the worker stub picks up the SAME list** (`worker_bootstrap.load_profile_stub` reads `prof.get("skills")` — `worker_bootstrap.py:147`), so both API and worker register identical compositions. ⚠️ Comments (`profile.yaml:40-50`) note items 4–9 are Phase-3 ATLAS pilot-certification skills (CFR Part 61/67, Form 8710, MedXPress, AME decision-tree domain knowledge) deliberately FAA-specific (no analogue in other portfolios); their generic siblings stay in `cross-cutting/skills/`.

### C.1.6 `templates` (`profile.yaml:53-57`)
Loaded into `ProfileMetadata.templates: tuple[str,...]`. Ordered list:
1. `"templates/safety-case.md"`
2. `"templates/nas-impact-assessment.md"`
3. `"templates/ato-decommission.md"`
4. `"templates/security-safety-crosswalk.md"`

Effect: declares profile artifact templates; consumed when scaffolding the corresponding FAA-only artifacts (safety case, NAS impact assessment, ATO decommission certificate, security-safety crosswalk). No registry mutation.

### C.1.7 `branding` (`profile.yaml:60`)
`branding: "branding/"` — loaded into `ProfileMetadata.branding: str`. Effect: points the dashboard/asset pipeline at `profiles/faa/branding/` (C.11.1). String value only.

### C.1.8 `deployment` (`profile.yaml:63-65`)
Loaded into `ProfileMetadata.deployment: dict`. Keys/values:
- `target: "Tyrion Container Platform"`
- `cloud: "AWS GovCloud (EKS)"`

Effect: informational deployment-target hint surfaced to scaffolding skills (cross-referenced by `technology.yaml` infra block, C.6).

### C.1.9 `devsecops` (`profile.yaml:71-79`)
⚠️ **GOTCHA — NOT captured by the typed `ProfileMetadata`.** `ProfileMetadata` has no `devsecops` field (`profile_loader.py:79-95`), so this block survives ONLY in `Profile.raw_profile_yaml` (the full `profile:` dict preserved at `profile_loader.py:316, 523`). Consumers that want it must introspect `raw_profile_yaml["devsecops"]`. Per the comment (`profile.yaml:67-70`) the values are consumed by `cross-cutting/templates/devsecops-baseline/` when scaffolding generated apps (schema per `specifications/phase-5/devsecops-baseline.md §6`). FIELD-LEVEL:
- `sast_tool: codeql` (choices: `codeql | semgrep`)
- `sbom_required: true`
- `container_base: distroless` (choices: `distroless | alpine-nonroot`)
- `license: "Apache-2.0"`
- `branch_protection:`
  - `require_status_checks: [lint, test, build, sast, sca, image-scan]` (6 required checks)
  - `require_review_from_codeowners: true`
  - `require_signed_commits: true`

### C.1.10 Layering fields (`profile.yaml:82-83`)
- `inherits: null` → `ProfileMetadata.inherits = None`. ⚠️ EFFECT: FAA is a **base profile, not an overlay** — no parent profile is merged in. (The loader stores `inherits` raw; there is NO inheritance-resolution code in `load_profile` — `inherits`/`overlays` are declarative only today.)
- `overlays: []` → `ProfileMetadata.overlays = ()`. EFFECT: no additional overlays merged.

### C.1.11 `mission_context` (`profile.yaml:91-93`)
⚠️ **GOTCHA — NOT captured by `ProfileMetadata` either.** Like `devsecops`, `mission_context` survives only in `raw_profile_yaml`; the typed loader ignores it. It is consumed exclusively by **loader #3** (`profile_context.py`). FIELD-LEVEL:
- `path: "../../docs/Attachment 1 - Statement of Objectives_2026-02-17.md"` — relative to the profile dir; resolves to `<repo>/docs/Attachment 1 - Statement of Objectives_2026-02-17.md` (9480-byte markdown, confirmed present).
- `heading: "FAA ATLAS Statement of Objectives"` — the heading the body is injected under.

⚠️ **EFFECT (full HOW in C.11.2):** when `OLYMPUS_PROFILE_ROOT` points at `profiles/faa`, `load_mission_context()` reads this block, resolves `path`, reads the whole markdown file, and prepends it under the heading to EVERY dispatched skill's system prompt — before any skill-specific instructions. Resolution failures (missing file, bad YAML, no `path`) log a warning and inject nothing; dispatch NEVER fails on mission-context errors.

---

## C.2 — `compliance.yaml` (5 domains + regulatory_sources + branding)

**File:** `profiles/faa/compliance.yaml` (303 lines). Top-level wrapper key `compliance:`. ⚠️ The API loader stores the ENTIRE block loosely as `Compliance(domains=block)` (`profile_loader.py:320-326`) — it does NOT enforce a fixed domain set ("core framework does not cap the list" — `profile_loader.py:101-105`). `Compliance.domain_names` returns `tuple(sorted(self.domains.keys()))`. So all 7 top-level keys below (`accessibility`, `security`, `enterprise_architecture`, `coding`, `safety`, `regulatory_sources`, `branding`) become "domains" in the typed model. EFFECT: compliance data is consumed by gate-criteria rendering, agent prompts, and the dashboard — NOT by `apply_profile` (no registry mutation).

### C.2.1 Domain 1 — `accessibility` (`compliance.yaml:7-41`)
- `standard: "WCAG 2.1 AA"` ⚠️ FAA target.
- `federal_minimum: "WCAG 2.0 AA"` — comment: FAA exceeds federal minimum.
- `design_system: "USWDS"`
- `branding_overlay: "FAA Design System"`
- `tools:`
  - `automated_scanner: "axe-core"`
  - `manual_testing:` (list of 2)
    - `{tool: "JAWS", required_for: "Tier 1"}`
    - `{tool: "NVDA", required_for: "Tier 1"}`
- `enforcement:` (list of 6 `{point, action}` pairs — these map compliance checks to pipeline steps):
  - `discovery_pass4` → "Accessibility baseline assessment"
  - `architecture_design_system` → "Design system alignment verification"
  - `modernization_g04b` → "Design includes ARIA roles, keyboard nav, contrast, semantic HTML"
  - `modernization_g04c` → "No critical 508 violations in generated code"
  - `validation_stream3` → "Comprehensive WCAG audit — automated + manual (T1)"
  - `governance_drift` → "Periodic re-scan for compliance regression"
- `requirements:` (the concrete a11y thresholds, consumed by accessibility skills/gates):
  - `semantic_html: true`
  - `keyboard_navigation: true`
  - `color_contrast_normal: 4.5` (ratio for normal text)
  - `color_contrast_large: 3.0` (ratio for large text)
  - `alt_text: true`
  - `touch_targets_min: 44` (px)
  - `screen_reader_compatible: true`
  - `responsive_design: true`
  - `viewport_meta: true`

### C.2.2 Domain 2 — `security` (`compliance.yaml:44-78`)
- `framework: "NIST 800-53 Rev 5"`
- `artifact_format: "OSCAL 1.1.2"` ⚠️ the cATO evidence package format (cross-ref G-V2 override, C.4).
- `additional_standards: ["FAA Order 1370.121"]`
- `zero_trust: true`
- `encryption:` `{at_rest: "AES-256", in_transit: "TLS 1.2+"}`
- `secrets_management: "AWS Secrets Manager"`
- `patching_sla:` (days — drives patch-assessment skill; cross-ref `config/patch-assessment.yaml`, C.10):
  - `critical: 15`, `high: 30`, `medium: 90`, `low: 180`
- `owasp_enforcement:`
  - `sql_injection: "Parameterized queries only"`
  - `xss: "Output encoding + CSP headers"`
  - `mitm: "HTTPS/TLS enforced + secure cookies"`
  - `dom_manipulation: "Validate/sanitize + safe APIs"`
- `enforcement:` (list of 7 `{point, action}`):
  - `discovery_pass3` → "Security posture baseline"
  - `architecture_security` → "Security architecture design, cATO seed artifacts"
  - `modernization_g04b` → "Security controls mapped in design"
  - `modernization_g04c` → "No critical security findings in generated code"
  - `validation_stream2` → "Security certification, cATO artifact package"
  - `deployment_ato_transition` → "ATO boundary transition from legacy to modernized"
  - `governance_cve_monitoring` → "Continuous vulnerability monitoring"

### C.2.3 Domain 3 — `enterprise_architecture` (`compliance.yaml:81-92`)
- `standards: ["FAA Acquisition Management System (AMS)", "FAA Enterprise Architecture Policy"]`
- `gate: "G-02"` ⚠️ ties EA review to the Architecture gate.
- `tier_1_override:` `{review_board: "FAA EA Review Board"}` — for T1, EA review escalates to the board (cross-ref G-02 override, C.4).
- `enforcement:` (list of 2):
  - `architecture_g02` → "EA alignment verification"
  - `modernization_g04b` → "Architecture conforms to FAA EA standards"

### C.2.4 Domain 4 — `coding` (`compliance.yaml:95-112`)
- `standards: ["FAA Code Standards"]`
- `linters:` (per-language linter pinned):
  - `python: "ruff"`, `javascript: "eslint"`, `typescript: "eslint"`, `java: "checkstyle"`, `csharp: "dotnet-format"`
- `additional_rules:` (list of 5):
  - "FAA-approved library versions"
  - "No deprecated FAA APIs"
  - "FAA security header requirements"
  - "FAA logging format compliance"
  - "Twelve-factor methodology adherence"
- `enforcement:` (list of 1):
  - `modernization_g04c` → "FAA code standards compliance check"

### C.2.5 Domain 5 — `safety` (Tier 1 only) (`compliance.yaml:115-131`)
- `applies_to: "Tier 1"` ⚠️ safety domain gates ONLY apply to T1 apps.
- `standard: "FAA System Safety Assessment"`
- `requirements:`
  - `traceability: 0.99` (99% forward and backward)
  - `ivv: true`, `safety_case: true`, `safety_board: true`, `security_safety_crosswalk: true`, `nas_impact_assessment: true`
- `enforcement:` (list of 3):
  - `modernization_all_gates` → "Enhanced traceability verification at G-04a, G-04b, G-04c"
  - `validation_stream4` → "IV&V with independent subagent"
  - `validation_g_v3` → "Safety board review with NAS impact assessment"

### C.2.6 `regulatory_sources` (`compliance.yaml:156-288`) — domain-knowledge regulations
⚠️ **DISTINCT from compliance domains:** these describe real-world rules FAA apps *implement* (e.g. IACRA implements 14 CFR Part 61), not how Olympus builds software (`compliance.yaml:134-139`). Consumed by Discovery/Rationalization/Validation agents when analyzing regulatory-logic systems. Per-source schema (`compliance.yaml:141-155`): `id`, `title`, `authority`, `current_version`, `analysis_document`, `raw_text`, `cross_cut_analysis` (optional), `relevance`, `applicable_systems`, `key_concepts`, `update_frequency`. FIVE sources (each id matches a `regulatory-knowledge/<id>/` dir, C.11.4):

| id | title | authority | current_version (ingested) | analysis_document | raw_text | relevance | applicable_systems (count) | update_frequency |
|---|---|---|---|---|---|---|---|---|
| `14-cfr-47` | 14 CFR Part 47 — Aircraft Registration | FAA | Amdt. 47-36 (Jan 17 2025); ingested May 5 2026 | `regulatory-knowledge/part-47/analysis.md` | `regulatory-knowledge/part-47/raw/14_CFR_Part_47.txt` | Primary — Civil Aviation Registry / Aircraft Registration Branch | 3 (Civil Aviation Registry/Aircraft Registration Branch; N-number assignment/reservation/special-registration; Dealer's Aircraft Registration Certificate workflows) | Monitor eCFR quarterly; watch Federal Register for Aircraft Registration Branch dockets |
| `14-cfr-61` | 14 CFR Part 61 — Certification: Pilots, Flight Instructors, and Ground Instructors | FAA | Amdt. 61-159 (July 24 2025); ingested Apr 17 2026 | `regulatory-knowledge/part-61/analysis.md` | `regulatory-knowledge/part-61/raw/14_CFR_Part_61.txt` | Primary — governs all airman certification systems | 5 (IACRA; Airmen Certification DB; DMS; Medical cert; Flight Standards) | Monitor eCFR quarterly |
| `14-cfr-63` | 14 CFR Part 63 — Certification: Flight Crewmembers Other Than Pilots | FAA | Amdt. 63-47 (Oct 1 2024); ingested May 4 2026 | `regulatory-knowledge/part-63/analysis.md` | `regulatory-knowledge/part-63/raw/14_CFR_Part_63.txt` | Primary — FAA flight engineer and flight navigator certification | 5 (IACRA; Airmen Certification DB; DMS; Medical cert; Flight Standards) | Monitor eCFR quarterly |
| `14-cfr-67` | 14 CFR Part 67 — Medical Standards and Certification | FAA | Amdt. 67-23 (Sept 3 2025); ingested May 6 2026 | `regulatory-knowledge/part-67/analysis.md` | `regulatory-knowledge/part-67/raw/14_CFR_Part_67.txt` | Primary — medical certification for all airman certificates | 6 (AMCS; MedXPress; IACRA; Airmen Certification DB; AME systems; Federal Air Surgeon systems) | Monitor eCFR quarterly |
| `14-cfr-183` | 14 CFR Part 183 — Representatives of the Administrator | FAA | Amdt. 183-18 (Dec 9 2022); ingested from eCFR snapshot May 4 2026 | `regulatory-knowledge/part-183/analysis.md` | `regulatory-knowledge/part-183/raw/14_CFR_Part_183.txt` | Primary — delegation of certification authority to designated representatives and ODAs | 6 (DMS; IACRA; Medical cert; Aircraft Certification; ODA management; Flight Standards) | Monitor eCFR quarterly |

⚠️ **GOTCHA — only `14-cfr-61` declares a `cross_cut_analysis`** (`regulatory-knowledge/part-61/cross-cut-analysis.md`); the other four omit that optional key. `14-cfr-47` carries a `# TODO(human)` comment in its `applicable_systems` (`compliance.yaml:165`). Each source lists 8–11 `key_concepts` (regulation-specific section citations, e.g. Part 47 §§47.2/47.7/47.8 citizenship tiers, Part 61 progressive certification ladder, Part 67 three-tier medical structure, Part 183 designee tiers). These `key_concepts` strings are the per-regulation summary agents reason over; reproduce them verbatim from `compliance.yaml:169-180` (47), `:196-204` (61), `:220-231` (63), `:248-260` (67), `:276-288` (183).

### C.2.7 `branding` (`compliance.yaml:291-302`)
⚠️ **GOTCHA — there are TWO branding declarations in the bundle: this one (`compliance.yaml:branding`) and the `profiles/faa/branding/README.md` asset spec (C.11.1).** This compliance-side block is the machine-readable subset. FIELD-LEVEL:
- `font: "'Source Sans Pro', sans-serif"`
- `primary_color: "#15396c"` (DOT/FAA blue)
- `header:` `{usa_banner: true, dot_ribbon: true, faa_logo: true, system_title: true}`
- `footer:` `{template: "faa-footer-bottom.png", top_section: "faa-footer-top.png"}` (top optional)
- `design_system: "USWDS"`

---

## C.3 — `risk-classification.yaml` (3 tiers + signals + override rules)

**File:** `profiles/faa/risk-classification.yaml` (130 lines). Wrapper key `risk_classification:`. Loaded by `_load_risk_classification` (`profile_loader.py:329-369`).

⚠️ **GOTCHA — HARD CONSTRAINT: tiers MUST be exactly `{tier_1, tier_2, tier_3}`.** The loader computes `set(tiers_block.keys())` and raises `ProfileLoadError` if it `!= {"tier_1","tier_2","tier_3"}` (`profile_loader.py:338-343`). A profile CANNOT add a tier_4 or drop a tier — the 3-tier model is a core constant (see C.13). Tiers are then materialized in CANONICAL order `tier_1 → tier_2 → tier_3` REGARDLESS of YAML ordering (`profile_loader.py:346-361`). Each tier → `RiskTier(key, label, definition, examples: tuple, parameters: dict)`.

- `profile: "faa"`
- `domain_label: "NAS Safety Tiering"` → `RiskClassification.domain_label`. EFFECT: dashboard label mapping the generic 3-tier model to FAA's NAS terminology.

### C.3.1 `tier_1` (`risk-classification.yaml:10-36`)
- `label: "NAS Safety-Critical"`
- `definition: "Directly impacts NAS operations — failure could affect flight safety, air traffic control, or aviation safety data integrity"`
- `examples:` (6) — "Air traffic control systems", "Flight data processing", "NOTAM systems", "Radar/surveillance data processing", "Safety reporting and analysis", "SWIM data publishers"
- `parameters:` (the T1 gating + deployment knobs; consumed by gates, deployment, validation, model-selection):
  - `traceability_forward: 0.99`
  - `traceability_backward: 0.99`
  - `test_coverage_overall: 0.90`
  - `test_coverage_domain: 0.95`
  - `parallel_run_days: 90`
  - `parallel_run_monitoring: "continuous"`
  - `deployment_strategy: "canary"`
  - `traffic_shift: "5→25→50→100% over 14 days"`
  - `rollback_window_days: 30`
  - `ivv_required: true`
  - `safety_case_required: true`
  - `safety_board_review: true`
  - `model_tier: "tier_1"` ⚠️ comment: "Force reasoning models for all roles" — T1 apps escalate every agent role to the tier_1 model.
  - `security_safety_crosswalk: true`
  - `nas_impact_assessment: true`
  - `stakeholder_confirmation: true`

### C.3.2 `tier_2` (`risk-classification.yaml:38-63`)
- `label: "Mission Support"`
- `definition: "Supports FAA mission but no direct NAS impact — failure disrupts operations but doesn't affect flight safety"`
- `examples:` (5) — "Certification tracking", "Workforce management", "Logistics systems", "Financial management", "Training management"
- `parameters:`
  - `traceability_forward: 0.98`, `traceability_backward: 0.98`
  - `test_coverage_overall: 0.80`, `test_coverage_domain: 0.95`
  - `parallel_run_days: 30`, `parallel_run_monitoring: "continuous"`
  - `deployment_strategy: "blue_green"`, `traffic_shift: "instant switch"`, `rollback_window_days: 14`
  - `ivv_required: false`, `safety_case_required: false`, `safety_board_review: false`
  - `model_tier: "default"`
  - `security_safety_crosswalk: false`, `nas_impact_assessment: false`, `stakeholder_confirmation: false`

### C.3.3 `tier_3` (`risk-classification.yaml:65-90`)
- `label: "Administrative"`
- `definition: "Internal business applications — failure causes inconvenience with workarounds available"`
- `examples:` (5) — "Timekeeping", "Travel management", "Document management", "Internal communications", "Intranet portals"
- `parameters:`
  - `traceability_forward: 0.98`, `traceability_backward: 0.98`
  - `test_coverage_overall: 0.80`, `test_coverage_domain: 0.95`
  - `parallel_run_days: 14`, `parallel_run_monitoring: "sampling"` ⚠️ T3 is the only tier with `sampling` (vs `continuous`) monitoring.
  - `deployment_strategy: "blue_green"`, `traffic_shift: "instant switch"`, `rollback_window_days: 7`
  - `ivv_required: false`, `safety_case_required: false`, `safety_board_review: false`
  - `model_tier: "default"`
  - `security_safety_crosswalk: false`, `nas_impact_assessment: false`, `stakeholder_confirmation: false`

⚠️ **GOTCHA — T2 and T3 differ ONLY in `parallel_run_days` (30 vs 14), `parallel_run_monitoring` (continuous vs sampling), and `rollback_window_days` (14 vs 7).** Every other parameter is identical. T1 is the materially different tier (0.99 traceability, 0.90 coverage, canary, 90-day parallel run, forced reasoning model, all safety flags true).

### C.3.4 `signals` (`risk-classification.yaml:93-117`) — auto-classification heuristics
Loaded into `RiskClassification.signals: tuple[dict,...]` verbatim. 8 signals (`{signal, tier_suggestion, confidence}`):
1. name contains ATC/radar/surveillance/NOTAM/flight data → `tier_1`, high
2. business domain = Air Traffic/Flight Safety/Aviation Safety → `tier_1`, high
3. interfaces with NAS operational systems → `tier_1`, high
4. interfaces with FAA safety databases → `tier_1`, medium
5. publishes to or consumes from SWIM → `tier_1`, high
6. business domain = Certification/Workforce/Finance/Logistics → `tier_2`, medium
7. business domain = Admin/Travel/Timesheet/Internal → `tier_3`, high
8. no external interfaces, <50 users → `tier_3`, medium

EFFECT: consumed by the `classify-application` skill to SUGGEST a tier; not auto-applied (`confidence` informs human review). Signal text is free-form; reproduce verbatim.

### C.3.5 `override_rules` (`risk-classification.yaml:120-129`) — hard tier guardrails
Loaded into `RiskClassification.override_rules: tuple[dict,...]` verbatim. 4 rules (`{rule, enforced, [note]}`):
1. `rule: "Any application that reads from or writes to NAS operational databases must be T1 minimum"` — `enforced: true`
2. `rule: "T1 classification requires Safety Board confirmation before proceeding past Discovery"` — `enforced: true` (cross-ref `safety_board_liaison` role at G-DC, C.4)
3. `rule: "Downgrading from T1 requires documented justification and Safety Board approval"` — `enforced: true`
4. `rule: "Read-only access to T1 data does not automatically require T1 classification (evaluate case-by-case)"` — `enforced: false`, `note: "Advisory — may be T2 if no write access and failure has no NAS impact"`

⚠️ **GOTCHA — `enforced` is a per-rule boolean; rule 4 is the only advisory (`enforced:false`) rule.** The 3 enforced rules are hard floors (NAS DB access → T1, T1 needs Safety Board sign-off post-Discovery, T1 downgrade needs justification+approval). Reproduce the `enforced` flag on each.

---

## C.4 — `gates.yaml` (gate overrides + additional roles + SLA)

**File:** `profiles/faa/gates.yaml` (138 lines). Wrapper key `gates:`. Loaded by `_load_gates` (`profile_loader.py:372-398`); APPLIED to the gate registry by `_apply_gates` (PART A §A.8.4, `profile_overrides.py:202-226`).

- `profile: "faa"`
- `default_provider: "github-pr"` → ⚠️ **EFFECT — `_apply_gates` calls `registry.set_default("github-pr")`** after asserting it's registered; if it weren't registered → plain `ValueError` (`profile_overrides.py:204-211`). `github-pr` IS a built-in (PART A §A.6.7), so this succeeds and makes GitHub-PR the default gate provider.

### C.4.1 `overrides` (`gates.yaml:13-112`) — per-gate FAA additions + reviewer overrides
⚠️ **GOTCHA — the API loader parses `overrides` as a MAPPING `{gate_id: body}`** (`profile_loader.py:378-390`); the worker parser ALSO expects a mapping (`worker_bootstrap.py:117-126`). Each `body` → `GateOverride(gate_id, faa_additions: tuple[dict], reviewer_override: dict)`. ⚠️ **EFFECT — `_apply_gates` does `clear_gate_overrides()` FIRST, then for each override `set_gate_overrides(gate_id, {"faa_additions": list(...), "reviewer_override": dict(...)})`** (`profile_overrides.py:218-225`). So the gate registry's `_gate_overrides` dict ends up keyed by these 8 gate ids. Each `faa_additions` entry is `{check, description, applies_to, automated}`.

⚠️ **GOTCHA — `applies_to` is a free-form scope string, NOT a hard enum.** Observed values: `"tier_1"`, `"retire,replace"` (comma-joined disposition labels, lowercase), `"nas_facing"`, `"external_api"`, `"all"`, `"retire"`. The gate subsystem interprets these; the registry stores them verbatim.

**8 gate overrides (FIELD-LEVEL):**

**`G-DC`** (Discovery gate) — `gates.yaml:15-26`:
- faa_additions (2):
  - `{check: "nas_interface_inventory", description: "NAS interface inventory complete for T1 applications", applies_to: "tier_1", automated: true}`
  - `{check: "stakeholder_business_criticality", description: "Business criticality confirmed by stakeholder", applies_to: "tier_1", automated: false}`
- reviewer_override: `{tier_1: ["portfolio_manager", "safety_board_liaison"]}`

**`G-DA`** (Disposition Approval gate) — `gates.yaml:28-36`:
- faa_additions (1):
  - `{check: "faa_issm_security_review", description: "FAA ISSM reviews security implications for Retire/Replace dispositions", applies_to: "retire,replace", automated: false}`
- reviewer_override: `{retire: ["portfolio_manager","stakeholder","faa_issm"], replace: ["portfolio_manager","stakeholder","faa_issm"]}`

**`G-02`** (Architecture gate) — `gates.yaml:38-45`:
- faa_additions (1):
  - `{check: "faa_ea_review_board", description: "FAA EA Review Board approval (not just arch lead)", applies_to: "tier_1", automated: false}`
- reviewer_override: `{tier_1: ["arch_lead", "faa_ea_review_board"]}`

**`G-04b`** (Modernization design gate) — `gates.yaml:47-56`:
- faa_additions (2); ⚠️ NO reviewer_override (so `GateOverride.reviewer_override = {}`):
  - `{check: "swim_solace_integration", description: "SWIM/Solace integration design validated", applies_to: "nas_facing", automated: true}`
  - `{check: "gravitee_api_gateway", description: "Gravitee API Gateway specification included for external APIs", applies_to: "external_api", automated: true}`

**`G-04c`** (Modernization code gate) — `gates.yaml:58-71`:
- faa_additions (3); NO reviewer_override:
  - `{check: "faa_code_standards", description: "FAA code standards compliance (ruff/eslint with FAA rules)", applies_to: "all", automated: true}`
  - `{check: "faa_security_headers", description: "FAA security header requirements met", applies_to: "all", automated: true}`
  - `{check: "twelve_factor_compliance", description: "Twelve-factor methodology adherence for Tyrion compatibility", applies_to: "all", automated: true}`

**`G-V2`** (Validation security gate) — `gates.yaml:73-82`:
- faa_additions (2); NO reviewer_override:
  - `{check: "cato_oscal_package", description: "cATO artifact package complete in OSCAL 1.1.2 format", applies_to: "all", automated: true}`
  - `{check: "faa_order_1370_121", description: "FAA Order 1370.121 compliance verified", applies_to: "all", automated: true}`

**`G-V3`** (Validation safety gate) — `gates.yaml:84-99`:
- faa_additions (3):
  - `{check: "nas_impact_assessment", description: "NAS impact assessment document complete", applies_to: "tier_1", automated: false}`
  - `{check: "safety_case_review", description: "Formal safety case reviewed by Safety Board", applies_to: "tier_1", automated: false}`
  - `{check: "security_safety_crosswalk", description: "Security-safety crosswalk verified", applies_to: "tier_1", automated: true}`
- reviewer_override: `{tier_1: ["safety_board", "compliance_lead"]}`

**`G-DP-2`** (Deployment decommission gate) — `gates.yaml:101-112`:
- faa_additions (2):
  - `{check: "ato_decommission_certificate", description: "ATO decommission certificate issued to FAA ISSM", applies_to: "retire", automated: false}`
  - `{check: "data_archival_verification", description: "Data archived per FAA records retention policy", applies_to: "retire", automated: true}`
- reviewer_override: `{retire: ["operations_lead","portfolio_manager","faa_issm"]}`

⚠️ **GOTCHA — only 8 of the 15 standard gates are overridden.** The other 7 (G-RR, G-DT, G-04a, G-DE-1, G-DE-2, G-V1, G-DP-1) get NO FAA additions — they run with their core definitions. A profile can ADD criteria/reviewers to a gate but the 15-gate SET itself is a core constant (C.13).

### C.4.2 `additional_roles` (`gates.yaml:116-125`)
Loaded into `Gates.additional_roles: tuple[dict,...]` verbatim. 3 roles (`{role, description, permissions}`) — FAA-specific RBAC beyond the standard Olympus model:
1. `{role: "faa_issm", description: "FAA Information System Security Manager", permissions: "Security review at G-DA (Retire/Replace), ATO decommission authorization at G-DP-2"}`
2. `{role: "faa_ea_review_board", description: "FAA Enterprise Architecture Review Board", permissions: "Architecture gate (G-02) approval for T1 applications"}`
3. `{role: "safety_board_liaison", description: "Safety Board liaison for Discovery intake", permissions: "T1 classification confirmation at G-DC"}`

⚠️ EFFECT: these role names are referenced by the `reviewer_override` lists in C.4.1 (e.g. `faa_issm`, `faa_ea_review_board`, `safety_board_liaison`). They extend the OIDC role map (`config/identity.yaml`, C.10) which separately maps OKTA groups → roles `safety_board` etc.

### C.4.3 `sla` (`gates.yaml:128-137`)
Loaded into `Gates.sla: dict` verbatim. Per-tier gate-review SLA in HOURS:
- `tier_1:` `{critical_path: 24, standard: 48}`
- `tier_2:` `{critical_path: 48, standard: 72}`
- `tier_3:` `{critical_path: 72, standard: 96}` (comment: more relaxed for low-risk)

EFFECT: gate-review SLA timers; consumed by the gate-review dashboard/escalation logic. ⚠️ NOT applied to any registry — `_apply_gates` ignores `sla`/`additional_roles`; they live only on the typed `Gates` object the API exposes.

---

## C.5 — `scoring.yaml` (6 dimensions; weight-sum proof)

**File:** `profiles/faa/scoring.yaml` (61 lines). Wrapper key `scoring:`. Loaded by `_load_scoring` (`profile_loader.py:401-455`); APPLIED to the scoring-dimension registry by `_apply_scoring` (PART A §A.8.4, `profile_overrides.py:179-199`) via `replace_all` (full atomic swap, sum-checked).

- `profile: "faa"`
- `total_weight: 1.0` (`scoring.yaml:53`) — declared sum.

### C.5.1 The 6 dimensions (`scoring.yaml:9-50`) — FIELD-LEVEL
Each → `ScoringDimension(name, weight, default_weight, rationale, data_source, scoring_function)`. ⚠️ EFFECT — `_apply_scoring` maps each to `ScoringDimensionEntry(name, weight, default_weight, rationale, data_source, scoring_function)` and calls `replace_all`, which CLEARS the 6 registry defaults and installs these 6. ⚠️ `bounds` and `metadata` are NOT carried (Protocol has no such fields) → every FAA dimension gets default `bounds=(0.0,1.0)`, `metadata={}` (PART A §A.8.4 gotcha).

| # | name | weight | default_weight | rationale | data_source | scoring_function |
|---|---|---|---|---|---|---|
| 1 | `code-quality` | **0.15** | 0.20 | "Slightly reduced — many legacy apps are old but functional" | `discovery-pass-3` | `weighted_linter_score` |
| 2 | `test-coverage` | 0.15 | 0.15 | "Unchanged" | `discovery-pass-3` | `coverage_percentage` |
| 3 | `security-posture` | **0.25** | 0.20 | "Elevated — FAA Order 1370.121 compliance critical" | `discovery-pass-3` | `vulnerability_weighted_score` |
| 4 | `documentation` | 0.10 | 0.10 | "Unchanged" | `discovery-pass-1` | `doc_completeness_score` |
| 5 | `dependency-currency` | **0.10** | 0.15 | "Slightly reduced — some FAA-approved versions intentionally lag behind latest" | `discovery-pass-3` | `dependency_age_score` |
| 6 | `architecture-clarity` | **0.25** | 0.20 | "Elevated — shared database complexity is FAA's biggest challenge" | `discovery-pass-1` | `modularity_score` |

⚠️ **WEIGHT-SUM PROOF (gate-target requirement):** `0.15 + 0.15 + 0.25 + 0.10 + 0.10 + 0.25 = 1.00`. ✅ Sums EXACTLY to `total_weight: 1.0`. The loader enforces this with `math.isclose(total, 1.0, abs_tol=1e-3)` and raises `ProfileLoadError(f"...weights must sum to 1.0 (got {total:.4f})")` otherwise (`profile_loader.py:444-448`). `_apply_scoring`→`replace_all` re-validates the same sum at `abs_tol=1e-3` (`scoring_dimension.py:90-106`); the worker stub's `replace_all` re-checks it a third time. So a regeneration that mis-sums these weights fails at THREE independent points.
⚠️ **GOTCHA — the FAA deltas vs core defaults:** `code-quality` −0.05, `security-posture` +0.05, `dependency-currency` −0.05, `architecture-clarity` +0.05 (net zero, sum preserved). `test-coverage` and `documentation` unchanged. The `default_weight` column records the CORE default for delta display; it does not affect scoring math (the live `weight` is what's used).
⚠️ Per-dimension `weight` must be in `[0,1]` — loader raises if `weight < 0 or weight > 1` (`profile_loader.py:427-430`); registry validator additionally allows `weight <= 1.0 + 1e-6` (PART A §A.5.2).

### C.5.2 `notes` (`scoring.yaml:56-60`)
Loaded into `Scoring.notes: tuple[str,...]`. 4 free-text notes:
- "Security posture scoring includes FAA Order 1370.121 patching compliance as a factor"
- "Architecture clarity scoring accounts for shared Oracle database coupling"
- "Dependency currency scoring uses FAA-approved version list, not latest public release"
- "Code quality scoring applies FAA code standards rules (not just language defaults)"

EFFECT: documentation surfaced on the scoring view; no runtime branch.

---

## C.6 — `technology.yaml` (approved stack)

**File:** `profiles/faa/technology.yaml` (148 lines). Wrapper key `technology:`. Loaded by `_load_technology` (`profile_loader.py:458-473`) into `Technology(profile, infrastructure: dict, data: dict, messaging: dict, document_management: tuple, low_code: tuple, modernization_targets: dict, tyrion_requirements: dict)`. ⚠️ EFFECT: this is the approved-technology contract; consumed by Architecture/Modernization scaffolding skills and the cross-cutting code-generation skills (cross-ref `config/*.yaml`, C.10). NOT applied to any registry. ⚠️ Loose schema by design ("varies wildly by client" — `profile_loader.py:206`).

- `profile: "faa"`

### C.6.1 `infrastructure` (`technology.yaml:8-29`)
- `api_gateway:` `{name: "Gravitee", mandatory: true, note: "All external APIs must route through Gravitee"}`
- `identity:` `{name: "OKTA", protocol: "SAML/OIDC"}`
- `compute:` (list of 2):
  - `{name: "AWS Lambda", environment: "Tyrion", primary: true, note: "Phase 3 prototype target — Node.js/TypeScript handlers"}`
  - `{name: "AWS EKS", environment: "Tyrion", note: "For long-running services if needed"}`
- `container_platform:` `{target: "Tyrion Container Platform (AWS EKS)"}`
- `iac: "Terraform"`
- `cicd: "GitHub Actions"`
- `monitoring: "Datadog"`
- `gitops: "ArgoCD on Tyrion"`

### C.6.2 `data` (`technology.yaml:32-44`)
- `legacy:` (list of 1): `{name: "Oracle", note: "Widespread shared clusters — ~3,000 databases"}`
- `modern:` (list of 2):
  - `{name: "Aurora PostgreSQL", primary: true, note: "Default target for relational data"}`
  - `{name: "DynamoDB", note: "For key-value and document workloads"}`
- `migration:` `{strategy: "Per-application or per-bounded-context migration", shared_db_handling: "Data assembly line — domain ownership mapping, strangler fig, database-per-service"}`

### C.6.3 `messaging` (`technology.yaml:47-56`)
- `nas:` `{name: "Solace PubSub+", protocol: "SWIM (System Wide Information Management)", note: "Required for NAS-facing data exchange"}`
- `modern:` (list of 2):
  - `{name: "Amazon EventBridge", use: "Event-driven architecture"}`
  - `{name: "Amazon SNS/SQS", use: "Pub/sub and queue-based messaging"}`

### C.6.4 `document_management` (`technology.yaml:59-63`) — loaded as tuple of dicts
- `{name: "Alfresco", note: "Enterprise content management"}`
- `{name: "SharePoint/OneDrive", note: "Collaboration and document sharing"}`

### C.6.5 `low_code` (`technology.yaml:66-72`) — tuple of dicts
- `{name: "PowerApps", use: "Simple administrative tools (Replatform target)"}`
- `{name: "PowerBI", use: "Reporting and analytics (Replatform target)"}`
- `{name: "UiPath", use: "Robotic process automation"}`

### C.6.6 `modernization_targets` (`technology.yaml:76-115`) — legacy→target mapping (dict)
Five archetypes, each `{legacy: [...], target, [target_framework], [target_frontend], [target_runtime], notes: [...]}`:
- `java_ee:` legacy `["EJB","JSP/Servlet","Spring (old)","WebSphere"]`; target `"Spring Boot / cloud-native Java"`; notes: EJB→Spring components / JSP→React+USWDS / WebSphere→embedded Tomcat/Jetty.
- `coldfusion:` legacy `["CFML","CFScript","Fusebox"]`; target `"Python/FastAPI or Node.js"`; notes: CFML tag analysis for extraction / requires specialized extraction skill variant.
- `dotnet:` legacy `["ASP.NET","C#","WCF"]`; target `"Node.js/TypeScript (Lambda handlers)"`; `target_framework: "express"`, `target_frontend: "react"`, `target_runtime: "AWS Lambda"`; notes: WCF→REST API (Express on Lambda) / ASP.NET Web Forms→React+USWDS / "Phase 3 prototype uses Node.js/TypeScript Lambda, not .NET 8".
- `batch_etl:` legacy `["Scheduled jobs","Data pipelines","Mainframe batch"]`; target `"AWS Step Functions / Lambda / ECS Fargate"`; notes: some may be Retain candidates / evaluate complexity vs value.
- `cobol:` legacy `["COBOL"]`; target `"Python/FastAPI or Java"`; notes: "Rare in FAA portfolio (~5%)" / requires specialized extraction skill variant (copybook-first).

### C.6.7 `phase3_prototype` (`technology.yaml:120-137`)
⚠️ **GOTCHA — NOT in the typed `Technology` model.** `Technology` has no `phase3_prototype` field (`profile_loader.py:204-215`), so this block is DROPPED by the typed loader and survives only if a consumer reads the raw `technology.yaml`. Comment (`technology.yaml:117-119`) declares it the canonical Phase-3 CBA stack that `module-design`/`tdd-generation` skills MUST use. FIELD-LEVEL (for regeneration completeness):
- `backend:` `{language: "TypeScript", runtime: "Node.js 20.x", compute: "AWS Lambda", framework: "Express (lambda-wrapped)", iac: "AWS CDK"}`
- `frontend:` `{framework: "React", design_system: "USWDS"}`
- `database:` `{primary: "Aurora PostgreSQL"}`
- `auth:` `{provider: "Cognito", note: "Placeholder for login.gov integration"}`
- `orchestration: "Temporal"`, `event_bus: "EventBridge"`, `cicd: "GitHub Actions"`

### C.6.8 `tyrion_requirements` (`technology.yaml:140-147`) — Tyrion compatibility flags (dict)
- `gitops: true`, `containers: "OCI-compliant"`, `cloud_native: true`, `twelve_factor: true`, `trunk_based_development: true`, `devsecops: true`, `automation: true`

EFFECT: platform-compatibility gate inputs (cross-ref G-04c `twelve_factor_compliance` check).

---

## C.7 — `wave-planning.yaml`

**File:** `profiles/faa/wave-planning.yaml` (105 lines). Wrapper key `wave_planning:`. ⚠️ **GOTCHA — NOT loaded by the core `load_profile` (`wave-planning.yaml` is NOT in `_EXPECTED_FILES`).** It is consumed by the wave-planning subsystem (`disposition-recommender`/wave composition) and the dashboard, read directly as YAML. So none of these values pass through `apply_profile`. Reproduce as data.

- `profile: "faa"`

### C.7.1 Cadence (`wave-planning.yaml:8-9`)
- `cadence: "quarterly"` (4 waves/year)
- `concurrent_wave_limit: 4` (max concurrent waves in different stages)

### C.7.2 `sizing` (`wave-planning.yaml:12-32`) — per-wave-band targets
Each band `{target_apps, focus, purpose}`:
- `wave_1:` target `"5-8"`; focus "T3 administrative apps (simplest, lowest risk)"; purpose "Establish baseline, extract initial patterns, calibrate factory"
- `wave_2:` target `"8-12"`; focus "T3 apps + simple T2 apps"; purpose "Leverage Wave 1 patterns, expand skill coverage"
- `wave_3_4:` target `"10-15"`; focus "T2 mission support apps"; purpose "Apply compound growth, tackle shared database clusters"
- `wave_5_6:` target `"12-18"`; focus "Complex T2 + first T1 apps"; purpose "Full factory maturity, safety board engagement"
- `wave_7_plus:` target `"15-20+"`; focus "Remaining T1 NAS-critical apps"; purpose "Maximum pattern reuse, proven safety assurance process"

### C.7.3 `constraints` (`wave-planning.yaml:35-59`) — 5 wave-assignment rules
Each `{name, rule, reason, enforcement}` — ⚠️ `enforcement` ∈ {`automated`, `manual`, `advisory`}:
1. `shared_database_co_dependency` — "Applications sharing Oracle clusters must be in same or adjacent waves" — reason "Database decomposition requires coordinated migration" — `automated`
2. `tier_1_safety_coordination` — "T1 applications require Safety Board coordination before wave assignment" — reason "Safety board review capacity is limited; must be planned" — `manual`
3. `application_dependencies` — "If App A depends on App B, App B must be in same or earlier wave" — reason "Downstream consumers need stable upstream services" — `automated`
4. `skill_readiness` — "Wave should not introduce more than 2 new technology types" — reason "Skill enrichment bottleneck — new tech requires skill development before factory execution" — `advisory`
5. `team_capacity` — "Total concurrent agent tasks across all waves must not exceed configured limit" — reason "API rate limits and human reviewer bandwidth" — `automated`

### C.7.4 `compound_growth` (`wave-planning.yaml:62-82`) — efficiency-curve targets
Each band `{pattern_reuse, skill_first_pass, escalation_rate, human_hours_per_app}`:
- `wave_1:` `{pattern_reuse: "10-20%", skill_first_pass: "~70%", escalation_rate: "~15%", human_hours_per_app: "baseline"}`
- `wave_2_3:` `{pattern_reuse: "30-40%", skill_first_pass: "~80%", escalation_rate: "~10%", human_hours_per_app: "-20%"}`
- `wave_4_5:` `{pattern_reuse: "50-60%", skill_first_pass: "~85%", escalation_rate: "~7%", human_hours_per_app: "-40%"}`
- `wave_6_plus:` `{pattern_reuse: "70-80%", skill_first_pass: "~90%", escalation_rate: "~5%", human_hours_per_app: "-50%"}`

### C.7.5 `composition_factors` (`wave-planning.yaml:86-104`) — weighted wave-selection priorities
List of `{factor, weight, preference}`:
| factor | weight | preference |
|---|---|---|
| `risk_tier` | 0.25 | "Start with T3, progress to T1 over waves" |
| `complexity` | 0.20 | "Start with Simple, progress to Complex over waves" |
| `database_cluster` | 0.20 | "Co-locate shared database apps in same wave" |
| `technology_type` | 0.15 | "Limit new technology types per wave" |
| `business_value` | 0.10 | "Higher business value earlier (within risk constraints)" |
| `pattern_leverage` | 0.10 | "Apps that can leverage existing patterns earlier" |

⚠️ **WEIGHT-SUM:** `0.25+0.20+0.20+0.15+0.10+0.10 = 1.00`. ✅ Sums to 1.0 (no loader enforces this — `wave-planning.yaml` isn't validated by `load_profile`; reproduce as-is). These weights drive the wave-composition scoring that selects which apps go in which wave.

---

## C.8 — `delegation.yaml`

**File:** `profiles/faa/delegation.yaml` (24 lines). ⚠️ **GOTCHA — NO wrapper key; this file is a FLAT single-key YAML.** Phase-5 W20 delegated-bundle fallback policy.

- `fallback_policy: internal_fallback`

⚠️ EFFECT (`delegation.yaml:1-22`): controls behavior when a delegated bundle expires (claimed + past `expires_at`) or is voluntarily released. Loaded by `olympus_workflows.activities.bundle_activities.load_fallback_policy_for_portfolio`, read LAZILY (no worker restart needed on change — `delegation.yaml:16-18`). Default when file absent/unreadable = `internal_fallback`. Allowed values (the enum the loader accepts):
- `internal_fallback` — re-run the skill chain internally (DEFAULT; FAA's choice)
- `escalate` — pause workflow + create admin escalation
- `fail` — fail the workflow (rare; safety-critical)
- `redispatch` — issue a fresh bundle, same scope, same TTL

⚠️ Comment (`delegation.yaml:19-22`) notes chunk D ships only the loader + structured-warning stub; real orchestration of the non-default policies is a follow-on PR. So FAA today behaves as plain `internal_fallback`.

---

## C.9 — `objectives.yaml` (8 SOO objectives) + `baselines/2024.yaml`

### C.9.1 `objectives.yaml` structure (`profiles/faa/objectives.yaml`, 332 lines)
⚠️ **GOTCHA — top-level is FLAT `version` + `objectives` (no wrapper key).** Validated against `schemas/profiles/objectives.schema.json` (Phase 1). ⚠️ NOT in `_EXPECTED_FILES` — loaded by the objectives endpoint / exec-microsite renderer (`scripts/render_exec_microsite.py`), not `load_profile`. Source of truth for `presentation/exec/` and the future `GET /api/v1/portfolio/objectives` Mission View. Objective ordering mirrors the SOO (Statement of Objectives, `docs/Attachment 1...`) so evaluators walk it in lock-step.

- `version: "1.0.0"`
- `objectives:` — list of 8 objectives, each with a fixed shape:
  - `id` (e.g. `faa.accelerate`), `label`, `order` (1–8), `owner`, `icon`
  - `description` (folded block), `narrative_template` (folded block with `{token}` placeholders resolved from analytics + baselines)
  - `kpi:` `{primary: {metric, unit, direction, [label]}, secondary: [ {metric, unit, direction, [label]} ... ]}`
  - `target:` `{value, by, baseline: {value, as_of, source}}` — `source` is a `profiles/faa/baselines/2024.yaml#<key>` ref
  - `contributes_from:` a subset of `{lines: [...], gates: [...], dispositions: [...], skills: [...], compliance_domains: [...], risk_tiers: [...]}`

**The 8 objectives (id, label, order, primary KPI metric, target value@by, baseline value):**
| order | id | label | primary KPI metric | unit / dir | target | baseline | contributes_from highlights |
|---|---|---|---|---|---|---|---|
| 1 | `faa.accelerate` | Accelerate NAS modernization | `analytics.factory_velocity.apps_per_wave` | count / higher | 20 @ wave-6 | 6 (2024-12-31) | lines [discovery, rationalization, modernization, disposition]; gates [G-04a/b/c]; dispositions [refactor, rearchitect, replace, replatform, retire, consolidate] |
| 2 | `faa.uiux` | Human-centered UX | `compliance.section508_pass_rate` | pct / higher | 95 @ wave-6 | 48 | lines [validation]; gates [G-V3]; skills [accessibility-reviewer, accessibility-checker, ux-accessibility-assessor]; compliance_domains [508] |
| 3 | `faa.availability_cost` | Mission availability & cost | `ops.availability.tier1_rolling_30d` | pct / higher | 99.9 @ 2027-09-30 | 99.2 | lines [sustainment, governance]; risk_tiers [1]; secondary `finance.tco.annualized_savings_usd` |
| 4 | `faa.devsecops` | DevSecOps velocity | `security.sast_pass_rate` | pct / higher | 98 @ wave-6 | 72 | lines [modernization, validation]; gates [G-04a/b/c]; skills [security-posture-review, security-scan-review, tdd-generation]; secondary `security.branch_protection_conformance_pct` |
| 5 | `faa.data_excellence` | Data consolidation | `data.consolidation.duplicate_fields_eliminated` | count / higher | 250 @ wave-6 | 0 | lines [data, discovery]; skills [redundancy-analyzer, business-rule-reconciliation, requirement-aggregation, legacy-business-rule-extractor] |
| 6 | `faa.cyber_cato` | Cyber posture (cATO) | `security.tier1_gate_first_pass_rate` | pct / higher | 90 @ wave-6 | 64 | gates [G-V1, G-V2, G-V3]; compliance_domains [ato, nist-800-53]; skills [cato-evidence-validator, safety-critical-verifier, security-posture-analyzer]; secondary `security.sbom_coverage_pct` |
| 7 | `faa.governance` | Governance & AI oversight | `governance.traceability_coverage_pct` | pct / higher | 100 @ wave-6 | 61 | lines [governance]; gates [G-DA, G-DE-1, G-DE-2]; skills [traceability-checker, traceability-audit, gate-review-package]; secondary `governance.human_override_rate_pct` |
| 8 | `faa.service_transition` | Zero-degradation transition | `deployment.parallel_run_success_rate_pct` | pct / higher | 99 @ wave-6 | 84 | lines [deployment, sustainment]; gates [G-DP-1, G-DP-2]; skills [parallel-run-monitor, traffic-shift, parity-verifier]; secondary `sustainment.rollback_incidents_total` (count / **lower_is_better**) |

⚠️ **GOTCHA — Objective 8's secondary KPI is the only `lower_is_better` metric** (`sustainment.rollback_incidents_total`, `objectives.yaml:317-321`). All primaries and other secondaries are `higher_is_better`. ⚠️ Objective 3's target `by` is a calendar date (`2027-09-30`), all others are `wave-6`. EFFECT: these objectives are presentation/analytics contracts; the `contributes_from` maps tell the analytics layer which lines/gates/skills/dispositions feed each metric. They do not gate workflow execution.

### C.9.2 `baselines/2024.yaml` (`profiles/faa/baselines/2024.yaml`, 44 lines)
The pre-Olympus reference deltas the narrative templates render against. FLAT structure (no wrapper key):
- `version: "1.0.0"`, `as_of: "2024-12-31"`, `profile: "faa"`
- `baselines:` (keyed by objective metric short-name; ⚠️ each `target.baseline.source` in `objectives.yaml` references one via `#<key>`):
  - `apps_per_wave: 6`, `timeline_compression_years: 0.0` (Obj 1)
  - `section508_pass_rate: 48` (pct, across 200-app portfolio scan) (Obj 2)
  - `availability_tier1: 99.2` (pct), `annualized_savings_usd: 0` (Obj 3)
  - `sast_pass_rate: 72` (pct), `branch_protection_conformance_pct: 34` (pct across legacy repos) (Obj 4) ⚠️ NOTE: `objectives.yaml` Obj 4 narrative references branch-protection but its baseline `source` points at `#sast_pass_rate`; the 34% baseline lives here for the secondary.
  - `duplicate_fields_eliminated: 0` (Obj 5)
  - `tier1_pass_rate: 64` (pct), `sbom_coverage_pct: 12` (pct of portfolio with CycloneDX SBOM) (Obj 6)
  - `traceability_coverage: 61` (pct), `human_override_rate_pct: 100` (pct — no agent recs pre-Olympus) (Obj 7)
  - `parallel_run_success_rate: 84` (pct on 2024 test-cutover pilot), `rollback_incidents_total: 3` (count, 2024 historical) (Obj 8)

⚠️ Comment (`baselines/2024.yaml:6-9`): values are pre-Olympus/pre-ChBA starting positions, intended to be updated by FAA program staff post-award; shape authored so narrative templates have a defined delta.

---

## C.10 — `config/*.yaml` skill overlays (16 skill-var files + `common.yaml`)

**Dir:** `profiles/faa/config/` (17 YAML files). ⚠️ **DISCREPANCY NOTE vs the task brief (which said "11"):** the actual count is **17 files** — `common.yaml` (shared variable file) + **16 skill-named overlay files**. All 17 are documented below at field level.

⚠️ **GOTCHA — these are profile-VARIABLE files, NOT registry overrides.** They are resolved into a dispatched skill's body at dispatch time via the `skill_loader` profile-variable resolution path (the `{{<var>}}` token substitution noted in `common.yaml:3-5`). Per-skill files override `common.yaml` ("Per-skill overrides live in the sibling `<skill-id>.yaml` files and take precedence over this file" — `common.yaml:4-5`). The filename (sans `.yaml`) names the skill the overlay applies to. These do NOT pass through `apply_profile`; they are consumed by the agent-runtime/skill-loader.

### C.10.1 `common.yaml` (`config/common.yaml`, 49 lines) — shared variables for ALL skills
Resolved into ANY dispatched skill referencing `{{<var>}}` tokens. FIELD-LEVEL:
- `api_gateway: Gravitee`
- `identity_provider: OKTA`
- `compliance_framework: cATO (OSCAL)`
- `control_framework: NIST 800-53 Rev 5` ⚠️ distinct from `compliance_framework` — names the per-control-id framework for `security-anomaly-resolution` (`common.yaml:10-14`).
- `compliance_authority: FAA ISSM`
- `tco_definition:` (folded) "Cloud/Infra hosting + O&M + hosting (per FAA Announcement Element 7 footnote). Operational costs only — exclude one-time development..."
- `patch_slas:` (folded) "Critical: 15 days; High: 30 days; Medium: 90 days; Low: 180 days (per FAA Order 1370.121)..."
- Modernization reconciliation vars: `agency_domain: faa.gov`, `line_of_business: Aviation Services`, `regulatory_order_ref: FAA Order 1370.121 Rev 2026`, `regulatory_order_filename: faa-order-1370.121-rev2026`
- AWS GovCloud cloud identifiers: `cloud_provider: AWS GovCloud`, `cloud_region: us-gov-west-1`, `cloud_identity_service: AWS IAM + OKTA federation`, `cloud_container_service: Amazon ECS on Fargate`, `cloud_serverless_service: AWS Lambda`, `well_architected_framework: AWS Well-Architected Framework (with GovCloud Lens)`
- EA identifier: `approved_service_catalog: FAA EA Approved Services Catalog`

### C.10.2 The 16 skill-named overlay files
Each row: filename → skill it overlays → overlay shape (keys). ⚠️ Many code-generation overlays share the identity stanza `{identity_provider: OKTA, oauth2_resource_server: {issuer_uri: https://faa.okta.com, jwks_url: https://faa.okta.com/oauth2/v1/keys}, cloud_provider: AWS GovCloud, secrets_manager: "CyberArk (prod), AWS Secrets Manager (fallback)"}` — call this **[ID-STANZA]**.

| file | overlays skill | overlay keys (FIELD-LEVEL) |
|---|---|---|
| `cloud-cost-estimator.yaml` | `cloud-cost-estimator` | `cloud_pricing_reference: "profiles/faa/skills/cloud-cost-estimator/references/aws-pricing-reference.md"`; `cost_optimization_reference: "...aws-govcloud-optimizations.md"` |
| `code-generation-cobol-to-java.yaml` | `code-generation-cobol-to-java` | [ID-STANZA] + `source_encoding: EBCDIC` (comment: FAA-typical legacy on CICS/VSAM, mainframe batch on DB2 use EBCDIC; generator emits conversion step by default) |
| `code-generation-dotnet.yaml` | `code-generation-dotnet` | [ID-STANZA] (only) |
| `code-generation-fastapi.yaml` | `code-generation-fastapi` | [ID-STANZA] (only) |
| `code-generation-natural-to-springboot.yaml` | `code-generation-natural-to-springboot` | [ID-STANZA] + `ui_framework: "Angular 17"`, `ui_style_base: "Angular Material with USWDS-aligned theme"`, `accessibility_floor: "Section 508 / WCAG 2.1 AA"` (comment: NATURAL MAP replacements emit Angular for parity; greenfield prefers React+USWDS) |
| `code-generation-node.yaml` | `code-generation-node` | `target_runtime: AWS Lambda`, `target_framework: express`, `lambda_adapter: "@vendia/serverless-express"`, `node_version: "20.x"`, `typescript: true`; `database: {engine: Aurora PostgreSQL, client: pg, connection: RDS Proxy, migrations: "aws-cdk (schema managed via CDK custom resources)"}`; `iac: {tool: AWS CDK, language: TypeScript, constructs: [Lambda (Node.js 20.x), API Gateway (HTTP API), RDS Proxy, EventBridge]}`; `event_bus: EventBridge`; [ID-STANZA]; `auth_middleware: "Cognito JWT (login.gov placeholder)"`; `excluded_technologies: [Spring Boot, Java, .NET, Angular, ECS, Fargate, "Docker (deployment target is Lambda, not containers)"]` ⚠️ the excluded list prevents the generator hallucinating wrong tech |
| `code-generation-react.yaml` | `code-generation-react` | `design_system: "USWDS (U.S. Web Design System)"`, `component_library: "@trussworks/react-uswds"`, `component_library_version: "^9.0.0"`, `accessibility_floor: "WCAG 2.1 AA"`, `accessibility_ceiling: "WCAG 2.1 AAA (when client profile specifies)"`, `identity_provider: OKTA` ⚠️ comment: keep `@trussworks/react-uswds`/USWDS HERE not in the cross-cutting SKILL.md body (a profile leak per CONVENTIONS.md §5) |
| `code-generation-springboot.yaml` | `code-generation-springboot` | [ID-STANZA] (only) |
| `deployment-topology.yaml` | `deployment-topology` | `sizing_reference: "...deployment-topology/references/fargate-sizing-guide.md"`; `network_topology_reference: "...govcloud-vpc-patterns.md"`; `iac_module_catalog: "...iac-module-catalog.md"` (cloud-identifier vars come from `common.yaml`) |
| `identity.yaml` | (auth subsystem, not a single skill — see C.10.3) | full OIDC config |
| `patch-assessment.yaml` | `patch-assessment` | `patch_slas:` (folded) "Critical: 15 days; High: 30 days; Medium: 90 days; Low: 180 days (FAA Order 1370.121). Critical findings MUST NOT be deferred to modernization." |
| `resilience-designer.yaml` | `resilience-designer` | `resilience_patterns_reference: "...resilience-designer/references/govcloud-resilience-patterns.md"` |
| `target-architecture-blueprint.yaml` | `target-architecture-blueprint` | `approved_service_catalog: "profiles/faa/skills/ea-compliance/references/approved-services.md"`; `cloud_region_constraints_reference: "...target-architecture-blueprint/references/aws-govcloud-constraints.md"`; `archetype_references_path: "profiles/faa/skills/target-architecture-blueprint/references/"` |
| `tco-analyzer.yaml` | `tco-analyzer` | `tco_definition:` (folded) "Cloud/Infra hosting + O&M + hosting (per FAA Announcement Element 7 footnote). Operational costs only — exclude one-time development. See references/faa-tco-definition.md..." |
| `well-architected-reviewer.yaml` | `well-architected-reviewer` | `well_architected_lens_reference: "...well-architected-reviewer/references/aws-govcloud-lens.md"` |

⚠️ **GOTCHA — `identity.yaml` is NOT a skill overlay; it is the auth-subsystem OIDC config.** It overlays the platform's auth path (provider-neutral OIDC), documented at `docs/auth-config.md`. See C.10.3.

### C.10.3 `config/identity.yaml` (`config/identity.yaml`, 59 lines) — OIDC auth config
⚠️ EFFECT: provider-neutral OIDC; "swap to a different client (NFIP, JobCorps, FDA, EAS), copy this file, change `provider_id`/`issuer`/endpoints, platform picks it up with no code changes" (`identity.yaml:4-7`). FIELD-LEVEL:
- `identity_mode: oidc`
- `oidc:`
  - `provider_id: okta` ⚠️ stored on every user row as `identity_provider = "oidc:okta"` (`identity.yaml:18-20`)
  - `label: "Sign in with FAA SSO"`
  - `issuer: https://faa.okta.com` (placeholder tenant)
  - `client_id: ${FAA_OKTA_CLIENT_ID}` (populated via Parameter Store)
  - `client_secret_env: FAA_OKTA_CLIENT_SECRET` ⚠️ NAME of env var holding the secret, read at request time from AWS Secrets Manager (prod) or `.env` (local); NEVER the secret value itself (`identity.yaml:9-12, 26-27`)
  - `authorization_url: https://faa.okta.com/oauth2/v1/authorize`
  - `token_url: https://faa.okta.com/oauth2/v1/token`
  - `userinfo_url: https://faa.okta.com/oauth2/v1/userinfo`
  - `jwks_url: https://faa.okta.com/oauth2/v1/keys`
  - `redirect_uri: https://olympus.faa.gov/api/v1/auth/oidc/callback`
  - `scopes: [openid, profile, email, groups]`
  - `groups_claim: groups`
  - `default_role: viewer` ⚠️ users with no mapped group get `viewer`
  - `role_mapping:` (OKTA group → Olympus RBAC role):
    - `olympus-portfolio-admin → portfolio_admin`
    - `olympus-portfolio-manager → portfolio_manager`
    - `olympus-tech-lead → tech_lead`
    - `olympus-arch-lead → arch_lead`
    - `olympus-compliance-lead → compliance_lead`
    - `olympus-operations-lead → operations_lead`
    - `faa-safety-board → safety_board`
    - `olympus-viewer → viewer`

⚠️ EFFECT: the `role_mapping` targets (`portfolio_manager`, `arch_lead`, `compliance_lead`, `operations_lead`, `safety_board`, etc.) are the RBAC roles the gate `reviewer_override` lists (C.4.1) reference. Note `safety_board` (from OKTA group `faa-safety-board`) is distinct from the gate-doc role `safety_board_liaison` (defined in `gates.yaml` `additional_roles`, C.4.2).

---

## C.11 — Branding, mission context, context-priors, regulatory-knowledge

### C.11.1 `branding/` (`profiles/faa/branding/README.md`, 88 lines)
Pointed at by `profile.yaml` `branding: "branding/"`. Asset/spec doc (machine subset is in `compliance.yaml branding`, C.2.7). Provides:
- **Branding elements table** (required/optional): Font `'Source Sans Pro', sans-serif` (req), Primary color `#15396c` DOT/FAA blue (req), USA banner (req), DOT ribbon (req), FAA logo (req), system title (req), Footer bottom = `faa-footer-bottom.png` (req), Footer top = `faa-footer-top.png` (optional).
- **Color palette tokens:** `--faa-primary: #15396c`, `--faa-primary-dark: #0d2449`, `--faa-primary-light: #2a5a9e`, `--faa-white: #ffffff`, `--faa-gray-cool: #71767a`, `--faa-error: #d63e04`, `--faa-success: #00a91c`, `--faa-warning: #e5a000`. All combos must meet WCAG 2.1 AA (4.5:1 normal / 3:1 large).
- **Typography table:** H1 2.44rem/700, H2 1.95rem/700, H3 1.56rem/700, Body 1rem/400, Small 0.87rem/400, Navigation 1rem/600 (all Source Sans Pro).
- **CSS integration** snippet: imports Source Sans Pro (weights 400;600;700), sets `:root` FAA vars, overrides USWDS `--theme-color-primary` on `.usa-banner/.usa-nav/.usa-footer`.
- **Asset sources:** USA banner (USWDS component), DOT ribbon (FAA asset library), FAA logo (FAA asset library), footer bottom/top (`assets/faa-graphics/faa-footer-*.png`).
- **Responsive behavior:** Desktop ≥1200px full horizontal; Tablet 768–1199px condensed/stacked; Mobile <768px minimal + hamburger nav. Header/footer must stay visible at all breakpoints.

EFFECT: consumed by dashboard theming + generated-app scaffolding (USWDS overlay). No registry/runtime branch.

### C.11.2 Mission context — HOW it injects (`olympus-agent-runtime/src/services/profile_context.py`, 189 lines)
⚠️ This is loader #3. The `mission_context` block (C.1.11) is consumed ONLY here. Reproduced as pseudocode:

```
# module-level cache
_CACHE: MissionContext | None = None
_CACHE_POPULATED: bool = False
_DEFAULT_HEADING = "Program Context"

@frozen dataclass MissionContext: heading: str; body: str

def load_mission_context(profile_root=None) -> MissionContext | None:
    explicit = (profile_root is not None)
    if not explicit and _CACHE_POPULATED:          # env-var path caches; explicit path bypasses cache
        return _CACHE
    root_value = profile_root if explicit else os.environ.get("OLYMPUS_PROFILE_ROOT")
    result = _resolve(root_value)
    if not explicit:                                # only the env-var path populates the cache
        _CACHE = result; _CACHE_POPULATED = True
    return result

def _resolve(profile_root) -> MissionContext | None:
    if not profile_root: return None                            # ⚠️ unset env → None, no FS touch
    profile_dir = Path(profile_root).expanduser()
    if not profile_dir.is_dir():  log.warning(...); return None
    profile_yaml = profile_dir / "profile.yaml"
    if not profile_yaml.is_file(): log.warning(...); return None
    try: data = yaml.safe_load(profile_yaml.read_text("utf-8"))
    except (OSError, yaml.YAMLError) as exc: log.warning(...); return None   # ⚠️ NEVER raises
    block = _extract_mission_block(data)            # tolerates flat OR profile-nested mission_context
    if not block: return None
    raw_path = block.get("path")
    if not raw_path or not isinstance(raw_path, str): log.warning("...without a 'path'..."); return None
    candidate = Path(raw_path).expanduser()
    if not candidate.is_absolute():
        candidate = (profile_dir / candidate).resolve()         # ⚠️ relative → resolved against profile DIR
    if not candidate.is_file(): log.warning("...does not exist..."); return None
    try: body = candidate.read_text("utf-8")
    except OSError as exc: log.warning(...); return None
    heading_raw = block.get("heading", _DEFAULT_HEADING)
    heading = heading_raw.strip() if (isinstance(heading_raw,str) and heading_raw.strip()) else _DEFAULT_HEADING
    log.info("Loaded mission context ... (%d bytes) under heading '%s'", len(body), heading)
    return MissionContext(heading=heading, body=body)

def _extract_mission_block(data) -> dict | None:
    if not isinstance(data, dict): return None
    if isinstance(data.get("mission_context"), dict): return data["mission_context"]   # flat layout
    nested = data.get("profile")
    if isinstance(nested, dict) and isinstance(nested.get("mission_context"), dict):
        return nested["mission_context"]                                                # nested layout (FAA uses this)
    return None
```
⚠️ **GOTCHA — env var is `OLYMPUS_PROFILE_ROOT` (the profile DIR itself), totally separate from the registry-overlay `OLYMPUS_PROFILE`+`OLYMPUS_PROFILES_DIR` pair.** A worker can have registries overridden (via loaders 1/2) yet inject NO mission context (because `OLYMPUS_PROFILE_ROOT` is unset). Reproduce both env vars independently.
⚠️ **GOTCHA — total fail-soft.** EVERY error path (not-a-dir, no profile.yaml, YAML parse error, no `path`, missing file, read error) logs a warning and returns `None`; dispatch NEVER fails on mission-context problems (`profile_context.py:14-25`). The heading defaults to `"Program Context"` if the block omits/blank-ifies `heading` — but FAA sets it to `"FAA ATLAS Statement of Objectives"`.
⚠️ **GOTCHA — explicit-arg vs env-var cache divergence.** Passing `profile_root=` explicitly BYPASSES the module cache (so tests can exercise multiple profiles in one process); only the env-var path caches. `reset_cache()` clears `_CACHE`/`_CACHE_POPULATED` for tests. EFFECT: the resolved `MissionContext.body` (the full 9480-byte SOO markdown) is prepended under its heading to every dispatched skill's system prompt, before skill-specific instructions (`profile_context.py:5-9`).

### C.11.3 `context-priors/manifest.yaml` (`profiles/faa/context-priors/manifest.yaml`, 45 lines)
⚠️ Declares which human-reviewed priors get staged for which skills, scoped to FAA-profile + named skill. Read via the `load_context_priors` activity, which folds matching prior content into `AgentTaskInput.context['context_priors']` (`manifest.yaml:9-12`). FIELD-LEVEL:
- `version: 1`
- `priors:` (list of 2 `{id, path, skills: [...], purpose}`):
  1. `id: subfactor-1-rationalization-business-value`; `path: subfactor-1-portfolio-rationalization-business-value.md`; `skills: [disposition-recommender, analyze-portfolio-redundancy, capability-consolidation-advisor]`; `purpose:` (block) "Human-reviewed prior disposition opinions for the Private Pilot Certification portfolio. Agents should CITE this prior when their own analysis converges with it, and DISSENT (with evidence) when it doesn't. The prior is an opinion, not ground truth — current-wave evidence always wins."
  2. `id: subfactor-3-target-state-architecture`; `path: subfactor-3-target-state-architecture.md`; `skills: [target-state-mapper, blueprint-assembly, migration-strategy-advisor]`; `purpose:` (block) "Human-reviewed prior target-state architecture for the Private Pilot Certification portfolio — eleven services in four groups, federated identity, dual-gateway service mesh, enterprise event bus, bounded-context data surfaces. Target-state-mapper should align app-level decisions with the prior's service decomposition unless per-app evidence says otherwise."

⚠️ **GOTCHA — `skills` is the FILTER:** a prior is only folded into a dispatch whose skill id is in the prior's `skills` list. The two prior body files (`subfactor-1-portfolio-rationalization-business-value.md`, `subfactor-3-target-state-architecture.md`) live alongside the manifest. EFFECT: gives rationalization/architecture agents human opinion as advisory context (CITE-or-DISSENT), never ground truth.

### C.11.4 `regulatory-knowledge/` (5 CFR parts + INDEX + README)
⚠️ Mirrors the `compliance.yaml regulatory_sources` entries (C.2.6); the `INDEX.md` is the authoritative table kept in sync with `compliance.yaml` (`INDEX.md:3`). Dir layout per part (`part-47`, `part-61`, `part-63`, `part-67`, `part-183`):
- `README.md` — per-part overview
- `analysis.md` — the ingested summary agents reason over (sizes: part-47 351 lines, part-61 506, part-63 408, part-67 383, part-183 469)
- `raw/` — directory for raw CFR text (currently `raw/README.md` placeholders; the `raw_text` paths in `compliance.yaml` point at `raw/14_CFR_Part_<n>.txt`)
- `part-61/cross-cut-analysis.md` — ONLY part-61 has this (matches the `cross_cut_analysis` key in C.2.6)

`INDEX.md` columns (per part): ID (kebab, matches dir + `compliance.yaml id`), Title, Authority, Current Version (ingested), Primary Systems (short list; full list in `compliance.yaml`), Last Re-ingested. `INDEX.md` maintenance rules: amend → bump `current_version` in `compliance.yaml`, refresh `analysis.md`+`raw/`, update row+"Last Re-ingested"; retiring → remove `compliance.yaml` entry, archive under `_retired/<id>/`, strike row (`INDEX.md:26-30`). EFFECT: the `analysis.md` bodies are the per-regulation domain knowledge Discovery/Rationalization/Validation agents consult; routing is by `applicable_systems`/`key_concepts` in `compliance.yaml`.

---

## C.12 — HOW a profile loads & overlays apply (loader pseudocode)

This section reproduces the load+overlay sequence. PART A §A.8–A.9 already reproduces `apply_profile` + the 3 helpers + `worker_bootstrap` byte-for-byte; here is the API-side typed loader and the end-to-end ordering.

### C.12.1 `load_profile(profile_root)` — the API typed loader (`profile_loader.py:476-524`)
```
root = Path(profile_root).resolve()
if not root.is_dir(): raise ProfileLoadError(f"Profile root not found: {root}")
missing = [name for name in _EXPECTED_FILES if not (root/name).is_file()]   # 6 required files
if missing: raise ProfileLoadError(f"... missing required files: {missing}")
# Parse each YAML to a dict FIRST so errors attribute to the specific file:
profile_yaml    = _read_yaml(root/"profile.yaml")
compliance_yaml = _read_yaml(root/"compliance.yaml")
risk_yaml       = _read_yaml(root/"risk-classification.yaml")
gates_yaml      = _read_yaml(root/"gates.yaml")
scoring_yaml    = _read_yaml(root/"scoring.yaml")
tech_yaml       = _read_yaml(root/"technology.yaml")
metadata, raw_profile_block = _load_metadata(root/"profile.yaml", profile_yaml)
compliance = _load_compliance(...); risk = _load_risk_classification(...)
gates = _load_gates(...); scoring = _load_scoring(...); technology = _load_technology(...)
return Profile(root, metadata, compliance, risk_classification=risk, gates, scoring, technology,
               raw_profile_yaml=raw_profile_block)
```
- `_EXPECTED_FILES` = `("profile.yaml","compliance.yaml","risk-classification.yaml","gates.yaml","scoring.yaml","technology.yaml")` (`profile_loader.py:244-251`). ⚠️ `wave-planning.yaml`, `delegation.yaml`, `objectives.yaml`, the `config/` overlays, branding, regulatory-knowledge are NOT required by `load_profile`.
- `_read_yaml` (`profile_loader.py:254-268`): missing file → `ProfileLoadError`; `yaml.YAMLError` → `ProfileLoadError`; `None` (empty) → `{}`; non-dict top level → `ProfileLoadError`.
- `_coerce_tuple` (`profile_loader.py:271-281`): None→`()`; tuple→as-is; list→tuple; else `ProfileLoadError`.
- ⚠️ **GOTCHA — silent partial loads forbidden (DECISION-010):** any missing/malformed file raises with an actionable path; there is no "load what you can" fallback.

### C.12.2 The per-block loaders (validation specifics)
- `_load_metadata` (`:284-317`): requires `profile:` mapping; requires `id`/`name`/`version`; requires `extensions` be a mapping; coerces `extensions` values to str; preserves the whole `profile:` dict as `raw_profile_block`.
- `_load_compliance` (`:320-326`): requires `compliance:` mapping; stores it whole as `Compliance.domains`.
- `_load_risk_classification` (`:329-369`): requires `risk_classification:` mapping + `tiers` mapping; ⚠️ HARD: `set(tiers)=={tier_1,tier_2,tier_3}` else raise; materializes in canonical order.
- `_load_gates` (`:372-398`): requires `gates:` mapping; `overrides` MUST be a mapping → list of `GateOverride`; `default_provider` defaults to `"github-pr"` if absent/falsy.
- `_load_scoring` (`:401-455`): requires `scoring:` mapping + `dimensions` LIST; each entry needs `name`+`weight`; `weight` numeric and in `[0,1]`; ⚠️ sum must be `isclose(1.0, abs_tol=1e-3)` else raise; `total_weight` defaults to the computed sum if absent.
- `_load_technology` (`:458-473`): requires `technology:` mapping; loose dicts/tuples; drops unknown keys (`phase3_prototype` lost).

### C.12.3 `activate_profile` — wiring loader→registries (`profile_activation.py:50-111`)
```
global _ACTIVE_PROFILE
try: from olympus_workflows.registries import apply_profile          # lazy import
except ImportError as exc: raise ProfileActivationError(...)
effective_id = profile_id or os.environ.get("OLYMPUS_PROFILE")
if not effective_id and profile_root is None:
    log.info("No profile configured — registries will use defaults."); return None   # ⚠️ no profile ⇒ defaults, NOT error
try:
    if profile_root is None: profile_root = discover_profile_root(effective_id or "")
    profile = load_profile(profile_root)
except ProfileLoadError as exc: raise ProfileActivationError(f"Failed to load profile {id!r} from {root}: {exc}")
try:
    with _LOCK:                              # threading.Lock — thread-safe activation
        apply_profile(profile)               # PART A §A.8.3 — overrides scoring+gates+skill-composition only
        _ACTIVE_PROFILE = profile
except Exception as exc: raise ProfileActivationError(f"Failed to apply profile {id!r} to registries: {exc}")
log.info("Activated profile %s (version %s) from %s", id, version, root); return profile
```
- `active_profile()` returns the module-singleton `_ACTIVE_PROFILE` (`:45-47`).
- `deactivate_profile()` (`:114-126`): under `_LOCK`, calls `reset_registries_to_defaults()` (PART A §A.8.5) and clears `_ACTIVE_PROFILE`. Used by tests + switching to `default`.
- ⚠️ Precedence (`:57-62`): (1) explicit `profile_root` arg (tests) → (2) `profile_id` arg + `OLYMPUS_PROFILES_DIR`/walk → (3) `OLYMPUS_PROFILE` env + `OLYMPUS_PROFILES_DIR`.
- ⚠️ **GOTCHA — repeated activation is safe** because `apply_profile` is idempotent (full-swap helpers) AND the `_LOCK` serializes concurrent calls (`profile_activation.py:13-14, 96-99`).

### C.12.4 `discover_profile_root(profile_id, repo_root=None)` (`profile_loader.py:532-568`)
```
env_dir = os.environ.get("OLYMPUS_PROFILES_DIR")
if env_dir:                                            # 1. explicit parent dir
    candidate = Path(env_dir)/profile_id
    if candidate.is_dir(): return candidate
if repo_root is not None:                              # 2. caller-provided repo root
    candidate = Path(repo_root)/"profiles"/profile_id
    if candidate.is_dir(): return candidate
here = Path(__file__).resolve()                        # 3. walk UP from this file
for parent in (here, *here.parents):
    candidate = parent/"profiles"/profile_id
    if candidate.is_dir(): return candidate
raise ProfileLoadError(f"Could not locate profile {profile_id!r}. Set OLYMPUS_PROFILES_DIR or place it under <repo_root>/profiles/{profile_id}.")
```
⚠️ Mirrors the worker's `bootstrap_profile_from_env` search (PART A §A.9.4) but the API version takes `profile_id` as the directory leaf under `OLYMPUS_PROFILES_DIR` (whereas the worker reads `OLYMPUS_PROFILE` directly). Both walk up from `__file__` as the last resort.

### C.12.5 The complete load+overlay ORDERING (parity-critical sequence)
1. **Import time (worker + API processes):** all six registries built + populated with DEFAULTS (PART A §A.0). Scoring has its 6 core dimensions; gates has 4 providers + default `github-pr`; skill-composition is EMPTY.
2. **Startup (API):** `activate_profile()` → `discover_profile_root("faa")` → `load_profile(root)` (validates 6 files, builds frozen `Profile`) → under `_LOCK`: `apply_profile(profile)`:
   - `_apply_scoring`: `replace_all` swaps the 6 core dims for the 6 FAA dims (re-validates sum 1.0). ⚠️ Registry now holds FAA weights (security 0.25, arch 0.25, code-quality 0.15, dep-currency 0.10, test 0.15, doc 0.10).
   - `_apply_gates`: `set_default("github-pr")`, `clear_gate_overrides()`, then `set_gate_overrides(...)` for the 8 FAA gates.
   - `_apply_skill_composition`: registers `SkillComposition("faa-profile-skills", <9 skills>, sequential, ...)`.
   - assembly-line / disposition / analysis-pass registries: UNTOUCHED (FAA ships no overrides — PART A §A.8.3).
3. **Startup (worker):** independently, `bootstrap_profile_from_env()` (PART A §A.9.4) reads `OLYMPUS_PROFILE`/`OLYMPUS_PROFILES_DIR`, parses the minimal stub (`profile.yaml`+`scoring.yaml`+`gates.yaml` only), `apply_profile(stub)` — landing the SAME scoring/gate/skill-comp state via the same helpers. ⚠️ The worker stub IGNORES compliance/risk/technology/wave/objectives entirely (it only reads what `apply_profile` consumes).
4. **Agent dispatch (runtime):** independently, `load_mission_context()` reads `OLYMPUS_PROFILE_ROOT`, injects the SOO body; `load_context_priors` folds matching priors; `skill_loader` resolves `config/*.yaml` `{{vars}}` into skill bodies.
5. **API startup (skills→DB):** independently, `bootstrap_skills` scans filesystem → upserts skill rows (C.12.6).
6. **Tests / switch-to-default:** `deactivate_profile()` → `reset_registries_to_defaults()` rebuilds all six registries to defaults in place.

⚠️ **GOTCHA — three of those flows run in DIFFERENT processes/services (API, worker, agent-runtime) and key off DIFFERENT env vars.** A correct deployment sets `OLYMPUS_PROFILE=faa` + `OLYMPUS_PROFILES_DIR=<.../profiles>` on API & worker, `OLYMPUS_PROFILE_ROOT=<.../profiles/faa>` on the agent-runtime, and `SKILLS_ROOT=<repo root>` on the API. Reproduce all four.

### C.12.6 Skill bootstrap overlay merge (`skill_bootstrap.py:351-422`, `_apply_profile_overlay` `:293-339`)
⚠️ This is HOW `profiles/faa/skills/` augments core skills (distinct from the `config/` variable overlays). Two phases (`collect_skills`):
```
# Phase 1 — core skills from cross-cutting/skills/ (sorted iterdir)
for skill_dir in sorted(core_dir.iterdir()):
    if not (skill_dir/"SKILL.md").is_file(): continue
    skills_by_id[name] = _build_skill_record(skill_dir, repo_root, source="core")
# Phase 2 — profiles/faa/skills/ (sorted iterdir)
for skill_dir in sorted(faa_dir.iterdir()):
    if not skill_dir.is_dir(): continue
    if (skill_dir/"SKILL.md").is_file():
        skills_by_id[id] = _build_skill_record(skill_dir, repo_root, "faa-profile")  # ⚠️ FAA SKILL.md WINS over core
        continue
    if not _overlay_has_content(skill_dir):                  # no references/assets/scripts/config.json
        log.debug("empty_overlay"); continue
    core = skills_by_id.get(id)
    if core is None: log.warning("overlay_without_core"); continue   # ⚠️ overlay with no core is SKIPPED
    skills_by_id[id] = _apply_profile_overlay(core, skill_dir, "faa-profile")
```
`_apply_profile_overlay(core, overlay_dir, source)`:
```
merged_refs    = {**core.references_data, **_load_text_dir(overlay/"references", ".md")}  # overlay wins on filename collision
merged_assets  = {**core.assets_data,     **_load_text_dir(overlay/"assets")}
merged_scripts = {**core.scripts_data,    **_load_text_dir(overlay/"scripts")}
merged_config  = {**core.config_data,     **_load_config(overlay)}                         # overlay top-level keys win
# recompute enrichment_level over the UNION:
enrichment = "full"    if has_refs and (has_assets or has_config or has_scripts)
        else "partial" if (has_refs or has_assets or has_config or has_scripts)
        else "minimal"
return {**core, "source": source, references/assets/scripts/config = merged..., "enrichment_level": enrichment}
```
⚠️ **GOTCHA — a FAA skill dir WITH its own `SKILL.md` fully REPLACES the core skill** (e.g. `code-generation-react` exists in BOTH `cross-cutting/skills/` AND `profiles/faa/skills/` — the FAA one wins as a standalone `faa-profile` record). A FAA skill dir WITHOUT a `SKILL.md` but with `references/`/`assets/`/`scripts/`/`config.json` MERGES onto the matching core skill (overlay wins on filename collisions / top-level config keys), re-sources it as `faa-profile`, and recomputes the enrichment badge. A dir with neither is skipped (debug log); an overlay with no matching core is skipped (warning). EFFECT: the `skill` table ends with core + FAA-standalone + FAA-overlaid records, `source` flipped so the UI filter shows FAA provenance. (Phase-6 owns the full skill registry; this is the load mechanism.)

---

## C.13 — What a profile CAN vs CANNOT override (⚠️ hard core constants)

⚠️ **GATE-TARGET deliverable.** The boundary between profile-configurable and core-constant is enforced in code at multiple points. Reproducing parity REQUIRES preserving these guardrails.

### C.13.1 What the FAA profile CAN override (configurable surface)
| Surface | Mechanism | Citation |
|---|---|---|
| Scoring dimension WEIGHTS (and which dims exist, names, rationale, data_source, scoring_function) | `scoring.yaml` → `_apply_scoring`→`replace_all` (full swap) | `profile_overrides.py:179-199` |
| Default gate provider | `gates.yaml default_provider` → `set_default` | `profile_overrides.py:204-211` |
| Per-gate ADDITIONAL criteria (`faa_additions`) + reviewer overrides | `gates.yaml overrides` → `set_gate_overrides` | `profile_overrides.py:218-225` |
| The profile's skill composition (`<id>-profile-skills`) | `profile.yaml skills` → `_apply_skill_composition` | `profile_overrides.py:229-260` |
| Risk-tier LABELS, definitions, examples, and all `parameters` (traceability %, coverage, parallel-run days, deployment strategy, model_tier, safety flags) | `risk-classification.yaml tiers.*.parameters` (data) | `profile_loader.py:346-361` |
| Auto-classification signals + override rules (incl. `enforced` flags) | `risk-classification.yaml signals/override_rules` (data) | `profile_loader.py:363-369` |
| Compliance domains (any number, any names), frameworks, controls, enforcement points | `compliance.yaml` (loose `domains` map) | `profile_loader.py:101-105, 320-326` |
| Regulatory sources (domain knowledge) | `compliance.yaml regulatory_sources` (data) | `compliance.yaml:156-288` |
| Approved technology stack, modernization targets | `technology.yaml` (loose schema) | `profile_loader.py:204-215` |
| Gate-review SLA hours per tier; additional RBAC roles | `gates.yaml sla / additional_roles` (data, not applied to registry) | `profile_loader.py:392-398` |
| Wave cadence, sizing, constraints, composition weights | `wave-planning.yaml` (data) | `wave-planning.yaml` |
| Delegated-bundle fallback policy | `delegation.yaml fallback_policy` (one of 4 values) | `delegation.yaml:24` |
| Agency objectives + baselines | `objectives.yaml` / `baselines/2024.yaml` (data) | `objectives.yaml`, `baselines/2024.yaml` |
| Per-skill prompt variables; OIDC auth config; mission context; branding; context priors | `config/*.yaml`, `config/identity.yaml`, `mission_context`, `branding/`, `context-priors/` | C.10/C.11 |
| Skill BODIES (FAA standalone `SKILL.md`) + skill enrichment (FAA `references/assets/scripts/config.json` overlays) | `profiles/faa/skills/` → `skill_bootstrap` | `skill_bootstrap.py:351-422` |

### C.13.2 What a profile CANNOT override (⚠️ HARD CORE CONSTANTS)
⚠️ Each of these is fixed in code; a profile YAML CANNOT change it. A regeneration that lets a profile alter any of these is WRONG.

| Hard constant | Fixed value | Where enforced / defined |
|---|---|---|
| **The 3-tier risk model COUNT** | exactly `{tier_1, tier_2, tier_3}` | ⚠️ `_load_risk_classification` raises `ProfileLoadError` if `set(tiers) != {"tier_1","tier_2","tier_3"}` (`profile_loader.py:338-343`). Cannot add tier_4 or drop a tier — only relabel/reparameterize the three. |
| **Scoring weights MUST sum to 1.0** | `isclose(sum, 1.0, abs_tol=1e-3)` | enforced at THREE points: loader (`profile_loader.py:444-448`), `replace_all` (`scoring_dimension.py:90-106`), worker stub `replace_all`. A profile cannot ship weights that don't sum to 1.0. |
| **Per-dimension weight range** | `0 ≤ weight ≤ 1` (loader); `≤ 1.0+1e-6` (registry) | `profile_loader.py:427-430`, `scoring_dimension.py:51-64` |
| **The 7 dispositions** | Retire, Retain, Refactor, Rearchitect, Replace, Replatform, Consolidate | the disposition REGISTRY is NOT touched by `apply_profile` (`profile_overrides.py:171-175`); FAA ships no disposition override. ⚠️ Only 5 are registered as strategies (Retire/Retain/Replace/Replatform/Consolidate); Refactor/Rearchitect route through `ModernizationWorkflow` (PART A §A.3.4). A profile cannot add/remove dispositions via YAML. |
| **The 15 standard gates** | G-DC, G-RR, G-DA, G-02, G-DT, G-04a, G-04b, G-04c, G-DE-1, G-DE-2, G-V1, G-V2, G-V3, G-DP-1, G-DP-2 | a profile may ADD criteria/reviewers to a gate (`faa_additions`/`reviewer_override`) but cannot add/remove gates from the set. FAA overrides only 8 of the 15; the gate set itself is core. (PART D owns the gate model.) |
| **The 4 gate-provider adapters & the registered provider records** | github-pr, automated-only, servicenow (stub), jira (stub) | `apply_profile` can only `set_default` to an ALREADY-REGISTERED provider — an unknown `default_provider` raises `ValueError` (`profile_overrides.py:204-211`). A profile cannot register a NEW provider record or adapter via YAML; `adapter_for` returns `None` for any provider without a built-in adapter (PART A §A.6.3/A.6.6). |
| **The 10 assembly lines & their `depends_on`/`mode`** | the line REGISTRY is loaded from `olympus-contracts` YAML at import; NOT touched by `apply_profile` (`profile_overrides.py:171-175`) | a profile cannot add/remove/re-wire assembly lines. `mode` is constrained to `{per-app, per-wave, per-target-app, continuous}` (PART A §A.2.2). |
| **The 3 analysis-pass / synthesis semantics** | analysis-pass REGISTRY derived from `discovery.yaml`; NOT touched by `apply_profile` | a profile cannot add discovery passes via YAML. |
| **`mode` enum, `SkillComposition` mode enum, gate-status / approval-state enums** | `_VALID_MODES` (line), `VALID_MODES` (skill-comp: sequential/parallel/conditional), gate states (pending/approved/rejected/cancelled) | frozen `frozenset`s in code (PART A §A.2.2, §A.7.1, §A.6.2); profiles supply DATA, not new enum members. |
| **The 6 required profile files** | `profile.yaml, compliance.yaml, risk-classification.yaml, gates.yaml, scoring.yaml, technology.yaml` | `_EXPECTED_FILES` (`profile_loader.py:244-251`); a profile cannot omit any (raises). |
| **`Profile` immutability** | all `Profile`/`ProfileMetadata`/`RiskTier`/etc. are `@dataclass(frozen=True)` | `profile_loader.py:79, 98, 114, 125, 146, 155, 173, 185, 204, 218`; downstream cannot mutate a loaded profile. |
| **Which 3 registries `apply_profile` mutates** | scoring + gates + skill-composition ONLY | `profile_overrides.py:149-176`; assembly-line/disposition/analysis-pass are no-ops today. A profile's YAML for those areas (none exist) would have no registry effect. |

⚠️ **THE BOUNDARY IN ONE SENTENCE:** A profile may freely supply DATA (weights, tier parameters, compliance/regulatory content, technology choices, gate criteria/reviewers/SLA, wave rules, objectives, skill bodies/variables, branding, mission context) and may `set_default`/augment within the FIXED sets — but it CANNOT change the cardinalities or membership of the core enums and registries (3 tiers, 7 dispositions, 15 gates, 10 lines, 4 gate providers, the mode/state enums), and CANNOT make scoring weights not sum to 1.0 or omit a required file.

---

## C.14 — FAA Profile Parity Checklist

| Facet | What FAA sets | Applied by | Affects runtime? |
|---|---|---|---|
| Scoring weights | security 0.25 / arch 0.25 / code-quality 0.15 / test 0.15 / doc 0.10 / dep-currency 0.10 (sum 1.0) | `apply_profile`→`_apply_scoring`→`replace_all` | YES (scoring registry) |
| Default gate provider | `github-pr` | `apply_profile`→`_apply_gates`→`set_default` | YES (gate registry) |
| Per-gate FAA additions | 8 gates (G-DC, G-DA, G-02, G-04b, G-04c, G-V2, G-V3, G-DP-2) | `apply_profile`→`_apply_gates`→`set_gate_overrides` | YES (gate registry `_gate_overrides`) |
| Skill composition | `faa-profile-skills` (9 skills, sequential) | `apply_profile`→`_apply_skill_composition` | YES (skill-comp registry) |
| Risk tiers/signals/overrides | 3 tiers w/ NAS labels + parameters; 8 signals; 4 override rules | typed `Profile` only | indirect (read by gates/deployment/model-select) |
| Compliance (5 domains + reg sources + branding) | WCAG 2.1 AA, NIST 800-53 R5/OSCAL 1.1.2, FAA AMS/EA, FAA code standards, T1 safety; 5 CFR parts | typed `Profile` only | indirect (gate criteria, agent prompts) |
| Technology stack | Gravitee/OKTA/Lambda/EKS/Aurora/Solace/etc. | typed `Profile` only | indirect (scaffolding skills) |
| Wave planning | quarterly, limit 4, sizing bands, 5 constraints, composition weights (sum 1.0) | NOT in core loader (wave subsystem) | indirect |
| Delegation | `internal_fallback` | `bundle_activities.load_fallback_policy_for_portfolio` (lazy) | indirect |
| Objectives + baselines | 8 SOO objectives + 2024 baselines | objectives endpoint / exec microsite | NO (presentation) |
| Mission context | SOO markdown under "FAA ATLAS Statement of Objectives" | `profile_context.load_mission_context` (`OLYMPUS_PROFILE_ROOT`) | YES (agent system prompt) |
| Config var overlays | 16 skill-var files + `common.yaml` (Gravitee/OKTA/GovCloud/CyberArk/SLAs/etc.) | `skill_loader` `{{var}}` resolution | YES (skill bodies) |
| OIDC auth | OKTA, 8 group→role mappings, default `viewer` | auth subsystem | YES (auth path) |
| Context priors | 2 human-reviewed priors filtered by skill | `load_context_priors` activity | YES (agent context) |
| Skill bodies/overlays | 9 standalone FAA skills + N enrichment overlays | `skill_bootstrap.collect_skills` | YES (skill DB rows) |
