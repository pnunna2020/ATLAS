# Olympus — Regeneration Spec · Phase 0A · Repository Overview & Topology

> **Premise.** This is part of an ATOMIC regeneration specification. The codebase will be deleted; this spec is the only surviving artifact. This file (`00-overview.md`) is the **repo map**: it enumerates every top-level package/service, their build/test tooling and coverage floors, the explicit inter-package dependency graph, the full Docker Compose runtime topology with every port, and a navigational map of the non-code spec trees (assembly-lines, cross-cutting, profiles, specifications). Deep behavioral detail of each component is captured in later phases (01–11) — this file is the index those phases hang off of.
>
> **Repo root:** `/Users/pnunna/Documents/GitHub/foundry` (the on-disk project is named `foundry`; the product is named **Olympus**). All paths below are relative to that root unless absolute.
>
> ⚠️ **IGNORE** anything under `/.claude/worktrees/` — stale duplicate copies. Never cited here.

---

## 0. What Olympus Is (one paragraph for context)

Olympus is a domain-customizable framework + API-first platform for modernizing enterprise application portfolios using AI-native processes (`README.md:7-16`, `CLAUDE.md`). It defines 10 named **assembly lines** (process pipelines), 11 **cross-cutting concerns**, domain **profiles** (FAA is the only fully-built one), and a runnable **platform** (FastAPI API + Temporal workflows + React/USWDS dashboard + agent runtime + MCP server, all backed by Postgres and Git). It operates at "AI Maturity Level 3-4": agents execute autonomously inside lines, humans review at quality gates (`README.md:16`). Currently in Phase 3 with a production trajectory (`CLAUDE.md` Repository Nature).

The four architectural pillars (`CLAUDE.md` Architecture Overview):
1. **Assembly Lines** (`assembly-lines/`) — 10 pipelines.
2. **Cross-Cutting Concerns** (`cross-cutting/`) — 11 capabilities.
3. **Client Profiles** (`profiles/`) — domain bundles (FAA + `test-generic`).
4. **Platform Specifications** (`specifications/`) — API-first platform design.

Engine substrate: **Temporal OSS** (durable workflows, signal-based gates), **A2A** protocol for agent dispatch, **MCP** protocol for resource/tool integration, **Git as source of truth** (branch-per-task, PRs as gates), **PostgreSQL + JSONB** as a *derived, disposable* query layer rebuilt from Git.

---

## 1. Top-Level Directory Inventory

Directories at repo root (excluding `.git`, `.github`, `.claude`, `node_modules`, `vendor` build artifacts):

| Directory | Kind | Role (one-line) |
|-----------|------|-----------------|
| `olympus-api/` | **Python service** | FastAPI backend — the platform API. |
| `olympus-worker/` | **Python service** | Temporal worker process — registers + runs all workflows & activities; hosts the agent client / fallback adapter / model resolver. |
| `olympus-agent-runtime/` | **Python service** | A2A HTTP server executing skills via Claude Agent SDK on Bedrock (live) or `MockAgentRuntime` (tests). |
| `mcp-server/` | **Python service** | MCP protocol server exposing Olympus resources + tools (`olympus-mcp` package). |
| `temporal/` | **Python library** | `olympus-workflows` package — workflow/activity definitions, the 6 extension-point registries, retry policies, types, utils. Consumed by `olympus-worker` and (partially) `olympus-api`. |
| `dashboard/` | **TS/React service** | Vite + React 19 + USWDS frontend. |
| `olympus-cli/` | **Python CLI** | `olympus` CLI client — fetch/accept/return human-paired-agent tasks. |
| `olympus-contracts/` | **Python library** | Shared domain types (enums, errors, signals, git_types) + authoritative assembly-line YAML contracts. The base dependency of nearly everything. |
| `schemas/` | **JSON Schemas** | Artifact contract schemas (per assembly line + common/cross-cutting), validated by `make validate-schemas` / `schemas/validate.sh`. |
| `db/` | **Migrations** | Alembic migration project (`alembic/`, 56 version files), DB init scripts, seed SQL, `db/Dockerfile`. |
| `assembly-lines/` | **Spec/skill content** | 10 line definitions (`README.md` + `artifacts.md` each) + `overview.md`. |
| `cross-cutting/` | **Spec/skill content** | 11 concern dirs + `templates/`; `cross-cutting/skills/` holds the 137 SKILL.md files + `registry.yaml` + per-skill `fixtures/`. |
| `profiles/` | **Config bundles** | `faa/` (full), `test-generic/` (portability test), `README.md`. |
| `specifications/` | **Platform specs** | Functional/nonfunctional/architecture specs, `api/` (OpenAPI), `ui/`, `decisions.md`, `implementation-plan.md`, `user-stories/`, phase plans, `gates/`. |
| `reference/` | **Docs** | `terminology.md`, `tech-stack.md`, `origins.md`. |
| `scripts/` | **Ops scripts** | 41 entries — seed scripts, smoke, render-exec, validators, `csn-fargate/`, `ops/`, `traceability/`, demo recorders. Invoked by Makefile targets. |
| `infra/` | **Infra-as-code** | `haproxy/` (agent LB cfg), `temporal/` (dynamicconfig), `helm/`, `terraform/`, `argocd/`, `prometheus/`, `grafana/`, `dms/`, `gfi/`. |
| `templates/` | **Shared templates** | Artifact/workflow templates. |
| `traceability/` | **Traceability data** | Evidence-chain content (published via `pages-publish-traceability.yml`). |
| `presentation/` | **Microsite output** | Render target for the Executive View microsite (`make render-exec` → `presentation/exec/`). |
| `docs/` | **Docs** | Includes `phase1-continuity-matrix.md` (imported `?raw` by the dashboard AboutContinuity page — see compose mount note). |
| `tests/` | **Root tests** | Repo-level cross-cutting tests (not a package). |
| `test-data/` | **Fixtures** | Shared test fixture data. |
| `demo-output/` | **Artifacts** | Output of the root-level demo-recording Playwright harness. |
| `vendor/` | **Vendored** | Vendored third-party content. |
| `regen/` | **This spec** | The regeneration specification output (this file lives here). |

Root manifests: `package.json` (root) is the **demo-recording Playwright harness ONLY — not the dashboard** (`package.json:1-5` name `foundry-demo-record`; `CLAUDE.md` Repository Layout). `docker-compose.yml`, `Makefile`, `.env.example`, `CLAUDE.md`, `CONTRIBUTING.md`, `.cursorrules` at root.

---

## 2. Per-Package Build / Test / Coverage Detail

Each Python service/library is independently testable with its own `pyproject.toml`. Coverage is enforced via `--cov-fail-under` in `[tool.pytest.ini_options].addopts`. **⚠️ GOTCHA — coverage floors only move UP, never down** (`CLAUDE.md`; DECISION-017; CI fails the build if coverage drops below the floor). The numbers below are the floors *as committed* — several are documented as transitional (lowered to absorb new-code dips, with a tracked plan to restore). Capture the **exact committed number** when regenerating, not the aspirational target.

### 2.1 `olympus-api/` — FastAPI backend
- **Package name / version:** `olympus-api` 0.1.0 (`olympus-api/pyproject.toml:6-7`).
- **Language / Python:** Python `>=3.13` (`:9`); ruff `target-version = "py313"`, line-length 100, lint select `["E","F","I","W"]` (`:90-95`).
- **Build tool:** setuptools (`>=68.0`) + wheel, `build_meta` backend (`:1-3`); `packages.find include = ["src*"]` (`:97-98`).
- **Runtime deps (`:10-43`):** `fastapi>=0.115,<1`, `uvicorn[standard]>=0.32,<1`, `temporalio>=1.7,<2`, `pydantic>=2,<3`, `pydantic-settings>=2,<3`, `PyGithub>=2,<3`, `structlog>=24`, `sqlalchemy[asyncio]>=2,<3`, `asyncpg>=0.29`, `python-jose[cryptography]>=3.3`, **`foundry-temporal>=1.3.0`** (private Artifactory — see §6), `httpx>=0.27`, **`olympus-contracts>=0.1.0`** (local pkg), `PyYAML>=6,<7`, **`bcrypt>=4.1,<6`** (⚠️ used directly because passlib 1.7.x is broken with bcrypt≥4.3 on Py3.13 — `:26-29`), `python-multipart>=0.0.9,<1` (FastAPI `UploadFile` for zip onboarding), `boto3>=1.34,<2` (S3 source intake), `jsonschema>=4.20` (⚠️ promoted dev→runtime in task #145 for the strict output-spec validator on `POST /agent-tasks/{id}/return` — `:36-42`).
- **Optional deps:** `dev` = pytest/pytest-asyncio/pytest-cov/ruff/httpx (`:45-54`). `integration` = `alembic`, `testcontainers[postgres]`, `psycopg2-binary` — ⚠️ **deliberately separate from `dev`** so the default unit job never pulls the testcontainers/alembic stack (`:56-67`).
- **Test runner:** pytest, `asyncio_mode="auto"`, `testpaths=["tests"]`.
- **Coverage floor:** **`--cov-fail-under=87`** (target 90; F8a) (`:80`). ⚠️ `addopts` also has **`--ignore=tests/integration`** — the real-Postgres suite is excluded from the default `pytest` run and invoked explicitly by the `Python: olympus-api (integration)` CI job / `pytest tests/integration/` (`:74-80`).
- **Source layout (`src/`):** `main.py`, `config.py`, `database.py`, `dependencies.py`, `startup_state.py`, plus dirs `auth/`, `middleware/`, `models/`, `routers/` (**36 router files** incl. `__init__`; see list below), `services/` (**43 service modules**). Router files: activity, admin, admin_bundles, agent_roles, agent_runs, agents, analytics, applications, artifacts, auth, bundles, chat, escalations, events, gates, git, governance, health, human_paired_agent, lines, me, portfolio, portfolio_members, profiles, registries, renditions, skills, system, systems, traceability, users, waves, webhooks, workflow_signals, workflows.

### 2.2 `olympus-worker/` — Temporal worker
- **Package name / version:** `olympus-worker` 0.1.0 (`olympus-worker/pyproject.toml:6-7`).
- **Python:** `>=3.13`; ruff py313, line 100, `["E","F","I","W"]`.
- **Build:** setuptools+wheel; `include=["src*"]`.
- **Runtime deps (`:10-23`):** `temporalio>=1.7,<2`, `pydantic>=2,<3`, `pydantic-settings>=2,<3`, `PyGithub>=2,<3`, `pyyaml>=6`, `Jinja2>=3.1,<4`, `structlog>=24`, **`olympus-workflows>=0.1.0`** (= the `temporal/` package), `httpx>=0.27`, **`foundry-temporal>=1.3.0`** (Artifactory), **`olympus-contracts>=0.1.0`**.
- **Coverage floor:** **`--cov-fail-under=90`** (`:39`).
- **Source layout (`src/`):** `worker.py` (entrypoint), `agent_client.py`, `agent_registry.py`, `config.py`, `fallback_adapter.py`, `model_resolver.py`, dirs `agents/`, `renditions/`, `testing/`. ⚠️ `worker.py:27` does `from olympus_workflows.worker import ALL_ACTIVITIES, ALL_WORKFLOWS` — the worker is a thin host that imports the workflow/activity registry from the `temporal/` package.
- **Config dir:** `olympus-worker/config/` holds `agents.yaml` (the 5 agent-role identities) — bind-mounted read-only into both the API container (`OLYMPUS_WORKER_CONFIG_DIR`, for `/api/v1/agent-roles`) and consumed by the worker.

### 2.3 `olympus-agent-runtime/` — A2A agent server
- **Package name / version:** `olympus-agent-runtime` 0.1.0 (`olympus-agent-runtime/pyproject.toml:6-7`).
- **Python:** `>=3.13`; ruff py313, line 100.
- **Runtime deps (`:10-20`):** `fastapi>=0.115,<1`, `uvicorn[standard]>=0.32,<1`, `pydantic>=2,<3`, `pydantic-settings>=2,<3`, `structlog>=24`, `httpx>=0.27`, `pyyaml>=6`, `boto3>=1.28.59`, `jsonschema>=4`.
- **Optional deps:** ⚠️ `agent` extra = **`claude-agent-sdk` + `anthropic[bedrock]`** (`:22-26`) — the live-inference deps are *optional*, so the test/mock image installs without them. `dev` = pytest stack.
- **Coverage floor:** **`--cov-fail-under=90`** (`:45`).
- **Source layout (`src/`):** `main.py`, `config.py`, dirs `middleware/`, `models/`, `routers/` (`a2a.py`, `health.py`, `__init__.py`), `services/`. The A2A dispatch surface is `routers/a2a.py`.

### 2.4 `mcp-server/` — MCP protocol server
- **Package name / version:** `olympus-mcp` 0.1.0 (`mcp-server/pyproject.toml:6-7`). ⚠️ Distribution name `olympus-mcp` but the import package is `olympus_mcp`.
- **Python:** `>=3.11` (note: lower floor than API/worker which need 3.13).
- **Runtime deps (`:10-20`):** `pydantic>=2,<3`, `jsonschema>=4,<5`, `asyncpg>=0.29,<1`, `httpx>=0.27,<1` (⚠️ the `olympus.api.*` tool family proxies read calls to `olympus-api` over HTTP — `:13-18`), **`olympus-contracts>=0.1.0`**.
- **Console script:** `olympus-mcp = "olympus_mcp.server:main"` (`:29-30`).
- **Coverage floor:** **`--cov-fail-under=90`** (`:41`).
- **Source layout (`olympus_mcp/`):** `server.py`, `db.py`, dirs `resources/` (`registry.py`, `schemas.py`, `handlers/`) and `tools/` (`registry.py`, `schemas.py`, `handlers/`, `auth.py`, `hashing.py`, `http.py`).

### 2.5 `temporal/` — `olympus-workflows` library
- **Package name / version:** `olympus-workflows` 0.1.0 (`temporal/pyproject.toml:6-7`).
- **Python:** `>=3.11`; ruff `target-version = "py311"`.
- **Runtime deps (`:10-29`):** `temporalio>=1.7,<2`, `pydantic>=2,<3`, `asyncpg>=0.29`, **`foundry-temporal>=1.3.0`** (Artifactory), **`olympus-contracts>=0.1.0`**, `pyyaml>=6` (ModernizationWorkflow reads committed `module-map.yaml`), `jsonschema>=4.20` (⚠️ disposition-output activity validates bundles at emission; promoted dev→runtime in W12 — `:20-23`), `sqlalchemy[asyncio]>=2,<3` (⚠️ bundle activities thin-wrap olympus-api's bundle service with their own per-call async session — `:24-28`).
- **Optional deps:** `dev` adds **`pytest-xdist>=3.5`** — ⚠️ workflow suite runs `-n auto`; each `WorkflowEnvironment.start_time_skipping()` spawns its own Rust sidecar; serial on a shared CI core took 30+ min vs 6 min local (`:36-47`). The comment also records a **fixed signal-race** in `WaveRationalizationWorkflow` (`gate_approved` firing before `create_gate_record` returned → signal silently dropped → workflow hung), now buffered via `_pending_signals_by_gate_id` in `wave_rationalization.py`.
- **Coverage floor:** **`--cov-fail-under=78`** (`:115`). ⚠️ **Heavily-documented transitional floor** — the comment block `:54-114` is a chronological log of every deliberate drop (87→85→…→79→78) and *why* (WaveArch/bundle/line-transition code whose async paths can't be driven without a real Temporal binary in CI). Each entry names the restore condition. **When regenerating, reproduce the floor as 78 but understand it is artificially low; the intended target is ≥87.**
- **Source layout (`olympus_workflows/`):** `worker.py` (exports `ALL_ACTIVITIES`, `ALL_WORKFLOWS`), `types.py`, `retry_policies.py`, dirs:
  - `workflows/` — **25 files** incl. `base.py`, `application.py`, `portfolio.py`, `discovery.py`, `rationalization.py`, `wave.py`, `wave_rationalization.py`, `wave_architecture.py`, `architecture.py`, `data.py`, `modernization.py`, `generate_bc.py`, `disposition.py`, `validation.py`, `deployment.py`, `sustainment.py`, `governance.py`, `bundle_helpers.py`, `bundle_reaper.py`, `smoke_test.py`, plus `*_router.py` files (architecture_patterns_router, code_generation_router, data_router, discovery_patterns_router).
  - `activities/` — 16 files.
  - `registries/` — the **6 extension points** on a shared substrate: `assembly_line.py`, `disposition.py`, `analysis_pass.py`, `scoring_dimension.py`, `gate_provider.py`, `skill_composition.py`, plus `engine.py` (shared substrate), `profile_overrides.py`, `worker_bootstrap.py`, `defaults/`.
  - `utils/` — incl. `parse_agent_json` (imported by `olympus-api/src/routers/waves.py:36`).
- Other: `temporal/config/`, `temporal/scripts/`, `temporal/tests/`, `temporal/requirements.txt` (mirrors deps + `foundry-strands-agents>=0.4.0` for editable installs), `temporal/uv.lock`, `temporal/README.md` (Artifactory install instructions).

### 2.6 `olympus-cli/` — `olympus` CLI
- **Package name / version:** `olympus-cli` 0.1.0 (`olympus-cli/pyproject.toml:6-7`).
- **Python:** `>=3.11`; ruff py311.
- **Runtime deps:** `httpx>=0.27`, `click>=8.1`, `pydantic>=2,<3` (`:10-14`). ⚠️ Notably does **not** depend on `olympus-contracts` — it is a standalone HTTP client.
- **Console script:** `olympus = "olympus_cli.main:cli"` (`:23-24`).
- **Test runner:** pytest, `addopts="-q"` — **⚠️ NO coverage floor** (the only Python package without one).
- **Source layout (`olympus_cli/`):** `__main__.py`, `main.py`, `api.py`, `bundle.py`, `config.py`, `hashing.py`, `output.py`, `skill_install.py`.

### 2.7 `olympus-contracts/` — shared types library
- **Package name / version:** `olympus-contracts` **0.3.0** (`olympus-contracts/pyproject.toml:6-7`) — ⚠️ the only package not at 0.1.0; it is the most-depended-on package.
- **Python:** `>=3.11`; ruff py311.
- **Runtime deps:** **only `pyyaml>=6.0`** (`:10`) — deliberately near-zero-dependency so everything can depend on it without pulling a heavy graph.
- **No test/coverage config** in the manifest (validated indirectly via consumers + CI's step-registry / contract checks).
- **Package data:** ships `data/assembly-lines/*.yaml` (`:22-23`) — the **authoritative assembly-line contracts** packaged into the wheel.
- **Source layout (`olympus_contracts/`):** `assembly_lines.py`, `enums.py`, `errors.py`, `git_types.py`, `signals.py`, and `data/` containing the 10 line YAMLs (`architecture.yaml`, `data.yaml`, `deployment.yaml`, `discovery.yaml`, `disposition-execution.yaml`, `governance.yaml`, `modernization.yaml`, `rationalization.yaml`, `sustainment.yaml`, `validation.yaml`) plus `data/assembly-lines/`.

### 2.8 `dashboard/` — React + USWDS frontend
- **Package name / version:** `olympus-dashboard` 0.1.0, `private: true`, `type: module` (`dashboard/package.json:1-5`).
- **Language / framework:** TypeScript + React **19.2** (`react`/`react-dom` `^19.2.5`); build via **Vite ^8.0.8** (`tsc -b && vite build`).
- **Key runtime deps (`:21-39`):** `@tanstack/react-query ^5.99`, `@tanstack/react-table ^8.21`, `@trussworks/react-uswds ^11.0.1`, `@uswds/uswds ^3.13`, `@xyflow/react ^12.10` (flow diagrams), `axios ^1.15`, `focus-trap-react ^12`, `mermaid ^11.14`, `react-markdown ^10.1`, `react-router-dom ^7.14`, `react-syntax-highlighter ^16.1`, `recharts ^3.8`, `remark-gfm ^4`, `sonner ^2.0.7` (toasts). ⚠️ `overrides` block pins `eslint-plugin-react-hooks`→`$eslint` and `@trussworks/react-uswds`→`$focus-trap-react` to dedupe (`:40-47`).
- **Dev deps:** TypeScript `~6.0.2`, vitest `^4.1.4` + `@vitest/coverage-v8 ^4.1.4`, `@playwright/test ^1.59.1`, `@axe-core/playwright`, jest-axe, `@testing-library/*`, jsdom `^29`, eslint `^10`, `typescript-eslint ^8.58`, `yaml ^2.8.4`.
- **Test runner:** **Vitest** (`test` = `vitest run`). E2E via **Playwright** (`test:e2e` = `playwright test`; tagged variants `@visual`/`@layout`/`@a11y`).
- **Coverage floors (`dashboard/vitest.config.ts:73-77`):** **lines 81 / branches 70 / functions 76 / statements 78** (F8b tracks raising). ⚠️ Same "floors only move up" rule applies.
- **Scripts of note:** `build:line-contracts` runs `node scripts/parse-line-contracts.mjs` (generates frontend line-contract sequences validated against backend by CI's `line-contracts-consistency` job).
- **Source layout (`src/`):** `App.tsx`, `main.tsx`, dirs `api/`, `components/`, `config/`, `data/`, `fixtures/`, `hooks/`, `pages/` (**26 page dirs**), `shared/`, `styles/`, `test/`, `types/`, `utils/`, plus `demo-mode.ts`. Imports `../../../../docs/phase1-continuity-matrix.md?raw` (the `docs/` compose mount exists to satisfy this — see §3).

### 2.9 Root `package.json` — demo-recording harness (NOT the dashboard)
- `foundry-demo-record` 0.0.0, private (`package.json:1-5`). Deps: `@playwright/test ^1.60`, `@types/node ^20`, `typescript ^5.4.5`. Scripts: `demo:shoot` (`playwright test --config=playwright.config.ts`), `demo:shoot:dry`/`:headed`, `demo:report` (`playwright show-report demo-output/_report`). ⚠️ **Do not confuse with the dashboard** — different React version, different toolchain.

### 2.10 `db/` — migrations (not a Python *package*, an Alembic project)
- **Migration tool:** **Alembic** (`db/alembic/` with `env.py`, `script.py.mako`, `versions/` = **56 version files**), `db/alembic.ini`. ⚠️ There is **no flat `db/migrations/` directory** — migrations live under `db/alembic/versions/`.
- **Deps (`db/requirements.txt`):** `alembic>=1.13,<2`, `psycopg2-binary>=2.9,<3`, `sqlalchemy>=2,<3`. ⚠️ Migrations use the **synchronous** `psycopg2` driver; `asyncpg` stays the *production app* driver.
- **Other:** `db/Dockerfile` (used by compose `db-migrate` one-shot), `db/init/01-create-databases.sh` (mounted at `/docker-entrypoint-initdb.d` in postgres), `db/seeds/initial-data.sql` + `db/seeds/README.md`, `db/README.md`.

---

## 3. Runtime Topology — Docker Compose (verified against `docker-compose.yml`)

**13 services** defined (`docker-compose.yml:9-494`), 4 named volumes (`:496-500`). Endpoints summary from `README.md:189-194`: dashboard `:3000`, API `:8000`, Temporal UI `:8080`, Agent Runtime `:8100`.

⚠️ **NOTE on the service list in the task prompt.** The prompt listed `temporal-server`, `olympus-agent-runtime 8100`, and `olympus-agent` (no port) as separate items. The **actual file** is: the runtime pool service is named **`olympus-temporal-worker`** for the worker, **`olympus-agent-runtime`** for the agent pool (NO host port), and **`olympus-agent`** is a **HAProxy load balancer** that publishes host `:8100` in front of the agent-runtime pool. The agent runtime itself binds 8100 only *inside the network*. This is verified below.

### 3.1 Service table (every service, image/build, port)

| # | Service | Image / Build | Host:Container Port | depends_on (condition) | Healthcheck |
|---|---------|---------------|---------------------|------------------------|-------------|
| 1 | **postgres** | `postgres:16` | **5432:5432** (`:15-16`) | — | `pg_isready -U $POSTGRES_USER`, 5s/5s/10 (`:24-28`) |
| 2 | **redis** | `redis:7` | **6379:6379** (`:32-33`) | — | `redis-cli ping`, 5s/3s/5 (`:36-40`) |
| 3 | **localstack** | `localstack/localstack:latest` | **4566:4566** (`:44-45`) | — | none. `SERVICES: s3,secretsmanager`, region us-east-1 (`:46-48`) |
| 4 | **db-migrate** | build `db/Dockerfile` (context `.`) | none (one-shot) | postgres: healthy (`:62-64`) | none; `restart: "no"` (`:65`) — runs migrations then exits |
| 5 | **temporal-server** | `temporalio/auto-setup:latest` | **7233:7233** (`:72-73`) | postgres: healthy (`:87-89`) | `tctl … cluster health` OR `nc -z localhost 7233`, 10s/5s/20, start 30s (`:90-95`) |
| 6 | **temporal-namespace-init** | `temporalio/auto-setup:latest` | none (one-shot) | temporal-server: healthy (`:107-109`) | none; `restart: "no"`. Runs `temporal operator namespace update -n default --retention 720h` (30 days) then describes it (`:113-117`) |
| 7 | **temporal-ui** | `temporalio/ui:latest` | **8080:8080** (`:121-122`) | temporal-server: healthy (`:126-128`) | none. `TEMPORAL_CORS_ORIGINS: http://localhost:3000` (`:123-125`) |
| 8 | **olympus-api** | build `olympus-api/Dockerfile` (context `.`) | **8000:8000** (`:139-140`) | db-migrate: completed_successfully; postgres/temporal-server/redis: healthy (`:203-211`) | `curl -sf localhost:8000/health`, 10s/5s/5, start 15s (`:212-217`) |
| 9 | **olympus-temporal-worker** | build `olympus-worker/Dockerfile` (context `.`) | **none** (background poller; scale-compatible) (`:219-224`) | db-migrate: completed_successfully; temporal-server/postgres: healthy (`:276-282`) | ⚠️ scans `/proc` for `src.worker` cmdline excluding own pid (no HTTP port; `procps` not in `python:3.14-slim`), 15s/5s/5, start 30s (`:295-302`) |
| 10 | **olympus-dashboard** | build `./dashboard/Dockerfile` (context `./dashboard`) | **3000:3000** (`:308-309`) | olympus-api: healthy (`:325-327`) | `node fetch('http://localhost:3000')` (`:328-329`) |
| 11 | **olympus-agent-runtime** | build `olympus-agent-runtime/Dockerfile` (context `.`) | **none** (host); binds 8100 inside network; pool (`:346-422`) | none declared (LB depends on it) | `curl -sf localhost:8100/health`, 10s/5s/5, start 15s (`:417-422`) |
| 12 | **olympus-agent** | `haproxy:2.9-alpine` | **8100:8100** (`:452-456`) | olympus-agent-runtime: healthy (`:459-461`) | ⚠️ `wget -qO- http://127.0.0.1:8100/lb-health` (127.0.0.1 not localhost — alpine resolves localhost→::1 first, HAProxy binds IPv4 only), 10s/5s/5, start 5s (`:462-470`) |
| 13 | **olympus-mcp-server** | build `mcp-server/Dockerfile` (context `.`) | **3001:3001** (`:476-477`) | db-migrate: completed_successfully; postgres: healthy (`:484-488`) | `python urllib urlopen('http://localhost:3001/')`, 10s/5s/5, start 10s (`:489-494`) |

**Named volumes (`:496-500`):** `postgres-data`, `redis-data`, `localstack-data`, `agent-workspace`. The `agent-workspace` volume is shared between `olympus-api` (mounted at `/workspace`) and `olympus-agent-runtime` (`/workspace`) so non-Git source intake (zip/S3) unpacked by the API is visible to Discovery in the agent — ⚠️ this shared mount is load-bearing for the source-intake feature.

### 3.2 Scaling & the agent LB (⚠️ ordering/topology gotchas)

- **`olympus-agent` is HAProxy, not an agent.** It load-balances the `olympus-agent-runtime` replica pool with `leastconn` (NOT round-robin) — better for 30s–5min Bedrock calls than DNS RR, and retries on a *different* replica when one returns 503 (saturated) (`:424-470`, config `infra/haproxy/agent-lb.cfg`). Callers keep using `OLYMPUS_AGENT_URL=http://olympus-agent:8100` unchanged.
- ⚠️ **Why HAProxy not nginx-OSS:** `--scale`-managed compose pools don't expose individual replicas under predictable hostnames; only the bare service name resolves (to all replica IPs). nginx-OSS resolves upstream names once at config-load, so `least_conn` over a single resolved IP collapses to no-op. HAProxy's `server-template` + `resolvers` block tracks the DNS answer dynamically, picking up `--scale` adds/removes within seconds (`:436-444`).
- **`olympus-agent-runtime` replicas:** `deploy.replicas: ${AGENT_REPLICAS:-3}` (`:410-411`). Each runs `MAX_CONCURRENT_TASKS=12`, `MAX_QUEUED_WAITERS=2`. `shm_size: ${AGENT_SHM_SIZE:-512m}` (up from Docker's 64 MiB default — guards subprocess tool-call shm). Memory limit `${AGENT_MEMORY_LIMIT:-6G}`, reservation `2G` (Claude Agent SDK sessions ~200 MiB each × 12 ≈ 2.4 GiB peak) (`:387-416`).
- **`make up` default:** scales `olympus-agent` to **8** (`Makefile:28` `AGENT_SCALE ?= 8`; `Makefile:48,107`). README §"Scaling Agents Locally" notes 8 × 12 = 96 concurrent agents; cap is 10 (historically limited by an `8100-8109` host-port range, now superseded by the single LB port). ⚠️ **README still describes the pre-LB round-robin DNS model in places** (`README.md:207-238`) — the *current* truth is the HAProxy LB (`docker-compose.yml:424-470` is authoritative; the `8100-8109` range no longer applies because only the LB binds a host port).
- **`olympus-temporal-worker`:** no host port; `--scale olympus-temporal-worker=N` runs N pollers on the shared `olympus-main` task queue. `WORKER_IDENTITY` is intentionally **unset** in compose; `src.worker._resolve_worker_identity` derives `olympus-worker-<task-queue>-<hostname>-<pid>` at startup so each replica is distinct in the Temporal UI (`:219-243`).

### 3.3 Key environment wiring (per service, the load-bearing vars)

- **olympus-api (`:141-202`):** `API_PORT=8000`; DB → `postgres:5432` db `olympus`; `TEMPORAL_HOST=temporal-server:7233`, `TEMPORAL_NAMESPACE=default`; `REDIS_URL=redis://redis:6379/0`; **`DEV_AUTH_BYPASS="true"`** (⚠️ local-only — disables auth); `AWS_PROFILE=${AWS_PROFILE:-ATLAS}`; `MCP_SERVER_URL=http://olympus-mcp-server:3001`; `SKILLS_ROOT=/app/repo`; `OLYMPUS_PROFILES_DIR=/app/repo/profiles` (⚠️ P5-AUDIT-005: without it `GET /api/v1/profiles` 500s); `OLYMPUS_WORKER_CONFIG_DIR=/app/repo/olympus-worker/config` (for `/api/v1/agent-roles`); **`RATE_LIMIT_ENABLED=${…:-false}`** (⚠️ disabled locally because the dashboard fires 15–20 reqs per page nav, tripping the 60/min/IP default; prod keeps it on via Helm); `JWT_SECRET=${…:-olympus-dev-secret}`; `SERVICE_TOKEN_PROVISIONING_SECRET`; `SOURCE_INTAKE_ROOT=/workspace/sources`, `SOURCE_INTAKE_MAX_UPLOAD_BYTES=${…:-524288000}` (500 MB). Mounts: `~/.aws:ro`, `cross-cutting/skills:ro`, `profiles:ro`, `olympus-worker/config:ro`, `agent-workspace:/workspace`.
- **olympus-temporal-worker (`:230-275`):** `TASK_QUEUE=olympus-main`; DB env; `OLYMPUS_AGENT_URL=http://olympus-agent:8100` (the LB); `OLYMPUS_PROFILE_ROOT=/app/repo/profiles/faa` (⚠️ `load_context_priors` resolves priors from here; without it priors silently return empty); `OLYMPUS_SCHEMAS_DIR=/app/repo/schemas` (⚠️ `validate_artifact_against_schema` can't reach repo `schemas/` via `parents[3]` from a wheel install — without the env var advisory validation logs a warning and continues, see `_validate_artifact_or_warn`). Mounts: `~/.aws:ro`, `profiles:ro`, `schemas:ro`.
- **olympus-dashboard (`:310-324`):** `API_URL=http://olympus-api:8000`, `VITE_API_BASE_URL=http://localhost:8000`, `VITE_WS_BASE_URL=ws://localhost:8000`. Mounts `dashboard/src`, `dashboard/index.html`, and ⚠️ `./docs:/docs:ro` (AboutContinuity page imports `…/docs/phase1-continuity-matrix.md?raw`; `vite.config.ts` widens `fs.allow` to repo root, the mount makes the file exist).
- **olympus-agent-runtime (`:352-386`):** `AGENT_NAME=${…:-discovery-analyst}` (⚠️ selects which registered identity this instance serves — DECISION-019: one general-purpose image, identity chosen by env var), `AGENT_PORT=8100`, `SKILLS_DIR=/app/skills`, `INFERENCE_PROVIDER=${…:-bedrock}`, `DEFAULT_MODEL_TIER=tier-2`, `CLAUDE_CODE_USE_BEDROCK="1"`, `MAX_CONCURRENT_TASKS=12`, `MAX_QUEUED_WAITERS=2`, `WORKSPACE_DIR=/workspace`, `SKILL_API_URL=http://olympus-api:8000`, `OLYMPUS_API_TOKEN=${OLYMPUS_AGENT_RUNTIME_TOKEN:-}`, `OLYMPUS_SCHEMA_ROOT=/app/repo` (⚠️ `build_system_prompt` folds each declared `output_schemas` into the prompt + `output_validator` strict post-run check use this root; without it `load_schema` returns None and the agent dispatches with an empty contract section). Mounts: `~/.aws:ro`, `cross-cutting/skills:/app/skills:ro`, `schemas:/app/repo/schemas:ro`, `agent-workspace:/workspace`.
- **temporal-server (`:74-86`):** `DB=postgres12` on `postgres:5432`; `DYNAMIC_CONFIG_FILE_PATH=config/dynamicconfig/docker.yaml` overridden by mount `./infra/temporal/dynamicconfig.yaml:…:ro`. ⚠️ The override raises `blobSize.error` 2 MiB→4 MiB so oversized gate-evidence payloads don't terminate Discovery workflows (band-aid; durable fix is slimming `_build_evidence_data` in `base.py`).

---

## 4. Inter-Package Dependency Graph

### 4.1 ASCII dependency graph (build/import-time)

Arrows mean **"depends on / imports"**. Leaf at the bottom is the most-depended-on.

```
                         ┌──────────────────────────────────────────────┐
                         │                  dashboard                    │
                         │  (TS/React — talks to API over HTTP/WS only,  │
                         │   no Python import edge)                      │
                         └───────────────────┬──────────────────────────┘
                                             │ HTTP/WS  → olympus-api:8000
                                             ▼
   olympus-cli ──HTTP──► olympus-api ◄──HTTP── olympus-agent-runtime ──HTTP──► olympus-api
   (httpx,click;          │   │   │            (fastapi; SKILL_API_URL)         (skill lookups)
    NO contracts dep)     │   │   │
                          │   │   └────import────► olympus_workflows (registries, utils,
                          │   │                     workflows refs in comments)
                          │   └────────import────► olympus_contracts (models, services)
                          │   └────────import────► foundry_temporal (Artifactory)
                          │
   olympus-worker ────────┴── imports ALL_WORKFLOWS / ALL_ACTIVITIES ──► olympus_workflows (temporal/)
        │                                                                     │
        ├── import ──► olympus_contracts                                      ├── import ──► olympus_contracts
        ├── import ──► foundry_temporal (Artifactory)                         ├── import ──► foundry_temporal
        └── HTTP ────► olympus-agent (HAProxy) ──leastconn──► agent-runtime   └── import ──► foundry_strands_agents (editable)

   olympus-mcp-server ── import ──► olympus_contracts
        │                └── import ──► asyncpg (direct DB reads)
        └── HTTP (olympus.api.* tools) ──► olympus-api:8000

                         ┌───────────────────────────────────────┐
                         │   olympus_contracts  (pyyaml only)     │  ◄── the universal base
                         └───────────────────────────────────────┘

   db (Alembic project)  ── one-shot ──► creates/owns the Postgres schema consumed by
                                          olympus-api, olympus-worker (sessions), olympus-mcp-server
```

⚠️ **`olympus-api` and `olympus-worker` BOTH talk to the Postgres schema that `db/alembic` owns**, but neither package *imports* `db/`. The migration project is a build-time/runtime peer, sequenced by the `db-migrate` compose one-shot (`depends_on: condition: service_completed_successfully`).

### 4.2 Per-package "imports / depends-on" list (verified)

Verified by grepping actual imports across the source trees (not just manifests):

- **olympus-contracts** → depends on: nothing internal (only `pyyaml`). **The base.**
- **olympus-workflows (temporal/)** → imports `olympus_contracts`, `foundry_temporal`, (editable) `foundry_strands_agents`; uses `temporalio`, `pydantic`, `asyncpg`, `pyyaml`, `jsonschema`, `sqlalchemy[asyncio]`. Confirmed `olympus_contracts` imported under `workflows/`, `activities/`, `registries/`, and package root.
- **olympus-worker** → imports `olympus_workflows` (`src/worker.py:27` `from olympus_workflows.worker import ALL_ACTIVITIES, ALL_WORKFLOWS`; also under `src/testing/`), `olympus_contracts`, `foundry_temporal`; HTTP-calls the agent LB (`OLYMPUS_AGENT_URL`).
- **olympus-api** → imports `olympus_contracts` (under `src/models/`, `src/services/`), `olympus_workflows` (under `src/routers/` — e.g. `waves.py`, `registries.py` imports from `olympus_workflows.registries`; `governance.py`; and `src/services/`), `foundry_temporal`; HTTP-calls MCP (`MCP_SERVER_URL`).
- **olympus-agent-runtime** → imports `olympus_contracts`? **No direct edge found**; it is a FastAPI service that HTTP-calls `olympus-api` (`SKILL_API_URL`) and reads skills from `SKILLS_DIR` + schemas from `OLYMPUS_SCHEMA_ROOT`. (Live extra: `claude-agent-sdk`, `anthropic[bedrock]`.)
- **olympus-mcp-server** → imports `olympus_contracts` (under `resources/`), uses `asyncpg` for direct DB reads; HTTP-calls `olympus-api` for the `olympus.api.*` tool family.
- **olympus-cli** → **no internal package dependency**; pure HTTP client (`httpx` + `click`) against the API.
- **dashboard** → no Python edge; consumes the API over HTTP/WS. Build-time it generates line-contract sequences from the spec via `scripts/parse-line-contracts.mjs` and reads `docs/phase1-continuity-matrix.md`.

### 4.3 Topological build/regeneration order (derived; full order in Phase 11)

1. `olympus-contracts` (no internal deps) → 2. `olympus-workflows` (`temporal/`) → 3. `olympus-worker`, `olympus-api`, `olympus-mcp-server` (depend on contracts/workflows) → 4. `olympus-agent-runtime`, `olympus-cli`, `dashboard` (HTTP-only edges; can build independently once API contract is fixed). `db/alembic` (schema) must be applied before any service touches Postgres at runtime. ⚠️ The private **`foundry-temporal` / `foundry-strands-agents`** Artifactory packages are an *external* prerequisite for steps 2–3 (see §6).

---

## 5. Navigational Map — Spec / Content Trees (detail deferred to later phases)

These trees hold framework definitions and skill content, not runnable Python (except where noted). Mapped here for navigation; behavioral detail is Phases 2 & 6.

### 5.1 `assembly-lines/` — 10 lines + overview
`overview.md` (line registry, dependency model, wave management — `CLAUDE.md`). Each line dir = `README.md` (single source of truth: purpose, inputs, outputs, deps, steps, gates, skills, agents, dashboard) + `artifacts.md` (artifact specs/schemas).

| Dir | Line | (from README.md:53-64) |
|-----|------|------------------------|
| `discovery/` | Discovery | Portfolio intake, 4-pass analysis, dependency mapping |
| `rationalization/` | Rationalization | Redundancy, disposition recs, wave planning |
| `architecture/` | Architecture | EA blueprints, cloud-native designs |
| `data/` | Data | Data mesh, DB decomposition, migration |
| `modernization/` | Modernization | Extract → Design → Generate factory (Ralph Loop in Generate) |
| `disposition/` | Disposition Execution | 5 of 7 dispositions (Refactor/Rearchitect → Modernization) |
| `validation/` | Validation | Parity, cATO, 508 certification |
| `deployment/` | Deployment | Traffic shifting, parallel run, decommission |
| `sustainment/` | Sustainment | O&M, incident response (continuous) |
| `governance/` | Governance | Health checks, drift, pattern extraction, skill evolution (continuous) |

**Flow** (`README.md:41-49`, `CLAUDE.md`): `Discovery → Rationalization → Architecture ─┬→ Modernization → Validation → Deployment` with `Data` joining into Modernization and `Disposition Execution` branching from Rationalization to Deployment; `Sustainment` and `Governance` run continuously in parallel. The Rationalization box is two Temporal workflows: `WaveRationalizationWorkflow` (cross-portfolio redundancy, fan-out disposition recs, per-app synthesis, gate staging) then `WaveWorkflow` (per-application pipelines for the wave).

### 5.2 `cross-cutting/` — 11 concerns + templates
Dirs: `orchestration/`, `skills/`, `agents/`, `gates/`, `hcd/`, `compliance/`, `security/`, `risk-classification/`, `extensibility/`, `traceability/`, `human-agent-collaboration/`, plus `templates/`.
- ⚠️ **`cross-cutting/skills/`** is the highest-value tree: **137 SKILL.md files** across 12 categories + `registry.yaml` + per-skill `references/`, `scripts/`, `assets/`, `config.json`, and **`fixtures/`** (the mock-mode canned agent responses, validated against each skill's pydantic contract at test collection — DECISION-018). Indexed in Phase 6.
- `cross-cutting/extensibility/README.md` is the implementation map for the **6 extension points**, all realized as Python registries in `temporal/olympus_workflows/registries/` (Phase 2).

### 5.3 `profiles/` — domain bundles
`README.md`, `faa/` (full FAA/NAS profile — T1/T2/T3 tiers, cATO/OSCAL, FAA Design System, Gravitee/OKTA/Solace, Order 1370.121), `test-generic/` (used by the CI **profile-portability** integration test). Profile bundle = `profile.yaml`, `compliance.yaml`, `risk-classification.yaml`, `gates.yaml`, `scoring.yaml`, `technology.yaml`, plus `objectives.yaml`, `context-priors/manifest.yaml`, and `skills/` (`CLAUDE.md` File Conventions; compose env `OLYMPUS_PROFILE_ROOT=/app/repo/profiles/faa`). Detail in Phase 2.

### 5.4 `specifications/` — platform specs
Top-level docs (`README.md:152-159`, dir listing): `functional-requirements.md`, `nonfunctional-requirements.md`, `architecture.md`, `constraints-risks.md`, `decisions.md` (the **ADRs** — DECISION-017 coverage, DECISION-018 mock runtime, DECISION-019 single agent image, etc.), `implementation-plan.md` (phase deliverables), `demo-golden-path.md`. Subdirs: `api/` (OpenAPI specs — multi-file source bundled + validated in CI), `ui/` (dashboard/UI specs), `gates/`, `user-stories/` (task completion tracked here per `CLAUDE.md`), `phase-5/` + many `phase-3-*` GFI plans, `agency-objectives-*`, `regeneration/` + `regeneration.zip`. Mapped here; spec content is referenced throughout later phases.

### 5.5 `schemas/` — JSON Schemas
Subdirs: `architecture/`, `common/`, `cross-cutting/`, `data/`, `design/`, `discovery/`, `dispositions/`, `gates/`, `modernization/`, `profiles/`, `rationalization/`, `samples/`, + `validate.sh`. Validated by `make validate-schemas` (metaschema + shape) and CI `contracts` job (also validates sample artifacts against schemas). Detail in Phase 1.

### 5.6 `infra/` — infra-as-code
`haproxy/agent-lb.cfg` (the agent LB config — §3.2), `temporal/dynamicconfig.yaml` (blobSize override — §3.3), `helm/`, `terraform/` (incl. `environments/dev-csn-fargate` — the CSN-Fargate Makefile targets), `argocd/`, `prometheus/`, `grafana/`, `dms/`, `gfi/`, `README.md`.

---

## 6. External / Private Dependencies (regeneration prerequisites)

⚠️ **CRITICAL for regeneration.** Three internal packages are **not on public PyPI** — they come from a private Artifactory registry (`agent-foundry` repo):
- **`foundry-temporal>=1.3.0`** — imported by `olympus-api`, `olympus-worker`, `olympus-workflows` (`temporal/`). Provides Temporal scaffolding shared with the broader foundry ecosystem.
- **`foundry-strands-agents>=0.4.0`** — listed in `temporal/requirements.txt` for editable installs.
- Install index (`.env.example:7`): `PIP_EXTRA_INDEX_URL=https://jfrog-platform.bah-ss-nonprod.te-test-domain.com/artifactory/api/pypi/agentic-ai-pypi/simple` (anonymous read; `temporal/README.md` has the editable-install path: `pip install -e /path/to/agent-foundry/temporal-packages/packages/foundry-temporal`). Compose passes `PIP_EXTRA_INDEX_URL` as a build arg to the API/worker/agent-runtime/workflows images. **These packages' source is NOT in this repo — their behavior is out of scope for this spec and must be sourced from the foundry monorepo.**

**Live-inference deps** (`olympus-agent-runtime` `agent` extra): `claude-agent-sdk`, `anthropic[bedrock]` — only installed for the live runtime; tests/mock omit them. Bedrock requires real AWS creds (`~/.aws` mounted ro; `AWS_PROFILE`, `CLAUDE_CODE_USE_BEDROCK=1`); LocalStack does **not** emulate Bedrock (`.env.example` Agent Runtime section).

---

## 7. CI / Build Surface (high-level; full detail in Phase 11)

`.github/workflows/`: **`ci.yml`** (main), `deploy.yml`, `pages-publish-traceability.yml`, `traceability-check.yml`.

`ci.yml` jobs (names from `ci.yml`): `preflight` (classify changed paths → drives conditional matrix legs), `branch-naming` (enforces `phase-*/`,`feat/`,`fix/` etc.), `contracts` (validate OpenAPI multi-file + bundle, JSON schemas, sample artifacts), `skill-catalog` (skill registry consistency), `agency-objectives`, `step-registry-consistency` (frontend ↔ backend step registry), `sql-schema-drift` (SQL ↔ alembic), `line-contracts-consistency` (dashboard line contracts vs backend), `profile-portability` (runs the `test-generic` profile integration test), `python` (matrix `Python: ${{ matrix.package }}` — per-package pytest with the coverage floors above; integration leg gated separately). Triggered on `pull_request`, `push`, and a `schedule` (`ci.yml:1-8`).

Lint: `ruff check` per Python package (`select=["E","F","I","W"]`, line 100); dashboard `npm run lint` (ESLint 10 + typescript-eslint). Schema/contract: `make validate-schemas`, `make validate-objectives`.

---

## 8. Coverage-Floor Quick Reference (the numbers that gate CI)

| Package | Test runner | Floor (committed) | Source |
|---------|-------------|-------------------|--------|
| olympus-api | pytest (asyncio auto) | **87%** (target 90; integration excluded by default) | `olympus-api/pyproject.toml:80` |
| olympus-worker | pytest | **90%** | `olympus-worker/pyproject.toml:39` |
| olympus-agent-runtime | pytest | **90%** | `olympus-agent-runtime/pyproject.toml:45` |
| mcp-server (olympus-mcp) | pytest | **90%** | `mcp-server/pyproject.toml:41` |
| temporal (olympus-workflows) | pytest `-n auto` | **78%** (artificially low/transitional — target ≥87) | `temporal/pyproject.toml:115` |
| olympus-cli | pytest `-q` | **none** | `olympus-cli/pyproject.toml:29` |
| olympus-contracts | (via consumers/CI) | **none in manifest** | `olympus-contracts/pyproject.toml` |
| dashboard | vitest + playwright | **lines 81 / branches 70 / functions 76 / statements 78** | `dashboard/vitest.config.ts:73-77` |

---

## 9. Phase 0A Coverage Report

**Covered by this file:**
- All **9 buildable packages/libraries** mapped (olympus-api, olympus-worker, olympus-agent-runtime, mcp-server, temporal/olympus-workflows, dashboard, olympus-cli, olympus-contracts) + the `db/` Alembic project + root demo-record harness — each with purpose, language/framework, build tool, test runner, and coverage floor (§2, §8).
- Full **inter-package dependency graph** (ASCII + per-package verified import lists + topological order) (§4).
- Full **Docker Compose runtime topology** — all **13 services** with image/build, host:container ports, depends_on, healthchecks, the scaling model, the HAProxy LB clarification, and load-bearing env wiring, all confirmed line-by-line against `docker-compose.yml` (§3).
- **Navigational map** of `assembly-lines/` (10), `cross-cutting/` (11 + skills/templates), `profiles/` (faa + test-generic), `specifications/`, `schemas/`, `infra/` (§5).
- External/private dependency prerequisites (`foundry-temporal`, `foundry-strands-agents`, Artifactory, Bedrock) (§6) and CI surface (§7).

**Deferred to later phases (by design):**
- Phase 1: contract types + JSON schemas (`schemas/`, `olympus-contracts/`, OpenAPI in `specifications/api/`).
- Phase 2: framework definitions, the 6 extension-point registries, profile bundle semantics.
- Phases 3–4: every Temporal workflow + activity (atomic pseudocode).
- Phase 5: agent runtime internals + skill interface.
- Phase 6: the 137-skill registry index.
- Phase 7: generation engine / Ralph Loop.
- Phase 8: API routers + services (36 routers, 43 services) behavior.
- Phase 9: data layer (56 alembic versions, models, the derived-from-Git rebuild).
- Phase 10: dashboard (26 pages, hooks, api client).
- Phase 11: build, CI job detail, regeneration order.

**Could not determine / open items:**
- `temporal/`, `olympus-cli/`, `olympus-contracts/` count files but their exact internal module APIs are intentionally left to Phases 2–4 (this is the map, not the contents).
- The **behavior of `foundry-temporal` / `foundry-strands-agents`** is unknowable from this repo (private, external) — flagged as a regeneration prerequisite, not reproducible from here.
- The README's agent-scaling narrative (`README.md:207-238`) describes the **pre-LB** round-robin DNS / `8100-8109` port-range model; the **authoritative current** topology is the HAProxy LB in `docker-compose.yml:424-470`. Noted as a doc/impl drift; the compose file is treated as source of truth.
