# Regen 04 — Data Layer: Platform Tables (skill / user / membership / chat / audit / model / delegated_bundle family)

ATOMIC regeneration spec. Premise: codebase deleted; this is the only surviving artifact. Bar = **behavioral parity** — the schema must be rebuildable EXACTLY.

**Scope of this file (14 tables):** `skill`, `skill_metrics`, `user_account`, `portfolio_membership`, `chat_message`, `audit_log`, `model_config`, `model_override`, `viewer_event`, `delegated_bundle`, `delegated_bundle_input_ref`, `delegated_bundle_output_ref`, `delegated_bundle_session_artifact`, `delegated_bundle_validation_history`. (`skill_metrics` and `viewer_event` are routed here by the spine §6e — `04-data-layer.md`.)

**Migration root:** `/Users/pnunna/Documents/GitHub/foundry/db/alembic/versions/` (56 files, `001` … `066` with `055` skipped — there is no `055_*.py`; the linear chain jumps `054 → 056` via `056.down_revision = "054"`).

**Method:** every table was traced across ALL 56 migrations. `op.create_table(` puts the table NAME on the following line; columns may be ADDED by later migrations via `op.add_column(...)` or `op.execute("ALTER TABLE … ADD COLUMN …")`. Each column row cites the `path:line` of its origin.

**Convention for the column tables below:**
- `type` = the SQLAlchemy/PG type as written in the migration.
- `null` = `YES`/`NO` (nullable).
- `default` = server-side default (PG `DEFAULT`), or `—` if none. ⚠️ Client-side ORM/insert defaults are NOT DB defaults; where a column has *no* DB default but is always supplied by the writer, that is flagged.
- `FK` = `→table.col (ON DELETE …)`; ON UPDATE is never specified in any of these migrations (PG default `NO ACTION`).
- `added-by` = `file:line`.

---

## 0. ENUM-TYPE CONTEXT (relevant to this file)

Only ONE PG enum type touches these 14 tables: **`actor_type_enum`** (used by `audit_log.actor_type`). (`skill_metrics` and `viewer_event` use no enum at all — `interview_session`'s VARCHAR+CHECK `status`/`phase` columns live in the workflow-tables file §14.)

`CREATE TYPE actor_type_enum AS ENUM ('human', 'agent', 'system')` — `001_create_enum_types.py:94-98`. Final value set: **`human`, `agent`, `system`** (3 values, all created in `001`). It is **never** extended by a later `ALTER TYPE … ADD VALUE`, so there is **no non-transactional ADD VALUE ordering hazard** for any table in this file. `004` references it as a non-creating handle: `actor_type_enum = ENUM("human","agent","system", name="actor_type_enum", create_type=False)` (`004_create_analytics_tables.py:17-19`) — it relies on `001` having already created the type.

⚠️ **Flexibility-migration note (enum→varchar+CHECK):** There is NO migration in this repo that converts any of these 14 tables' columns from a PG enum to `varchar + CHECK`. Every status/role/kind column on the `skill`, `skill_metrics`, `user_account`, `portfolio_membership`, `chat_message`, `model_*`, `viewer_event`, and `delegated_bundle*` tables was **born** as `String(n)`/`Numeric` (with optional `CHECK`) — they never used a PG enum. The only enum-typed column in this file is `audit_log.actor_type` (still a live `actor_type_enum`). So the classic "the flexibility migration loosened it" gotcha does **not** apply here; these tables were designed loose from day one. (Contrast: the enum→varchar churn lives on `gate`/`wave`/`application`/`agent_task`, documented in the other data-layer regen files.)

---

## 1. `skill` — 21 columns

Skill lifecycle / runtime-enrichment registry. Created by `015`, extended by `017` (7 cols + GIN index) and `018` (1 col).

**Created:** `015_create_skill_table.py:23-42` (`op.create_table("skill", …)`).

| # | column | type | null | default | FK | added-by |
|---|---|---|---|---|---|---|
| 1 | `id` | `UUID(as_uuid=True)` | NO | `gen_random_uuid()` | PK | `015:25-26` |
| 2 | `skill_id` | `String(100)` | NO | — | — (UNIQUE, see §1.3) | `015:27` |
| 3 | `name` | `String(255)` | NO | — | — | `015:28` |
| 4 | `description` | `Text` | YES | — | — | `015:29` |
| 5 | `category` | `String(100)` | YES | — | — | `015:30` |
| 6 | `assembly_line` | `String(100)` | YES | — | — | `015:31` |
| 7 | `enrichment_level` | `String(20)` | NO | `'minimal'` | — | `015:32-33` |
| 8 | `model_tier` | `String(20)` | YES | — | — | `015:34` |
| 9 | `source` | `String(50)` | NO | `'core'` | — | `015:35` |
| 10 | `content` | `Text` | YES | — | — | `015:36` |
| 11 | `status` | `String(20)` | NO | `'active'` | — | `015:37` |
| 12 | `created_at` | `DateTime(timezone=True)` | NO | `now()` | — | `015:38-39` |
| 13 | `updated_at` | `DateTime(timezone=True)` | NO | `now()` | — | `015:40-41` |
| 14 | `system_prompt` | `TEXT` | YES | — | — | `017:24-26` |
| 15 | `references_data` | `JSONB` | YES | `'{}'` | — | `017:27-29` |
| 16 | `assets_data` | `JSONB` | YES | `'{}'` | — | `017:30-32` |
| 17 | `config_data` | `JSONB` | YES | `'{}'` | — | `017:33-35` |
| 18 | `allowed_tools` | `JSONB` | YES | `'[]'` | — | `017:36-38` |
| 19 | `dispatch_ids` | `JSONB` | YES | `'[]'` | — | `017:39-41` |
| 20 | `skill_path` | `TEXT` | YES | — | — | `017:42-44` |
| 21 | `scripts_data` | `JSONB` | YES | `'{}'` | — | `018:22-25` |

⚠️ **Columns 14-21 are added via raw `op.execute("ALTER TABLE skill ADD COLUMN …")`, NOT `op.add_column`.** The DB defaults on 15-19,21 are written as bare `DEFAULT '{}'` / `DEFAULT '[]'` (untyped string literals). PG infers JSONB because the column type is JSONB — reproduce them as `DEFAULT '{}'::jsonb` / `DEFAULT '[]'::jsonb` to be safe. `system_prompt` (14) and `skill_path` (20) get NO default (nullable TEXT).

**CHECK constraints:** NONE. `enrichment_level`, `model_tier`, `source`, `status` are unconstrained `String` — values enforced only at the application layer (see §1.5). ⚠️ This means the DB will accept any string; parity requires NOT adding a CHECK that the original lacks.

### 1.3 Unique constraints
- `skill_id` carries `unique=True` inline (`015:27`). PG auto-names this `skill_skill_id_key` (the `op.create_table` column-level `unique=True` emits an unnamed unique constraint → PG default name). The upsert relies on it: `ON CONFLICT (skill_id)` (`skill_bootstrap.py:496`).

### 1.4 Indexes (4)
| index | columns | kind | added-by |
|---|---|---|---|
| `ix_skill_skill_id` | `(skill_id)` | btree | `015:43` |
| `ix_skill_assembly_line` | `(assembly_line)` | btree | `015:44` |
| `ix_skill_status` | `(status)` | btree | `015:45` |
| `ix_skill_dispatch_ids` | `(dispatch_ids)` | **GIN** | `017:46` (`CREATE INDEX … USING GIN (dispatch_ids)`) |

### 1.5 Application-enforced value sets (NOT DB-enforced — for fidelity of the projection, §1.6)
From `olympus-api/src/models/skill.py`:
- `enrichment_level` ∈ {`minimal`, `partial`, `full`} (`skill.py:21`; computed by `_determine_enrichment_level`, `skill_bootstrap.py:176-185`).
- `model_tier` ∈ {`opus`, `sonnet`} or NULL (`skill.py:22`; derived from `AGENT_TO_TIER`).
- `source` ∈ {`core`, `<profile-id>-profile`, `custom`} (`skill.py:23-25`).
- `status` defaults `'active'`; the upsert hardcodes `'active'` (`skill_bootstrap.py:485`).

### 1.6 ⭐ Git-as-source-of-truth → projection model for `skill`
`skill` rows are a **derived projection of Git-tracked skill directories**, not authoritative data. Source of truth = `cross-cutting/skills/<skill-id>/SKILL.md` (+ optional `references/`, `assets/`, `scripts/`, `config.json`) and profile overlays under `profiles/<profile-id>/skills/<skill-id>/`.

**Projection function:** `bootstrap_skills` → `collect_skills` → `upsert_skills` in `olympus-api/src/services/skill_bootstrap.py`. (This is the skill analogue of the workflow `persist_*` activities; cross-ref `regen/03b-activities/` — skill projection is API-side, invoked at app startup, not a Temporal activity.)

**Scan (`collect_skills`, `skill_bootstrap.py:388-469`):**
1. Phase 1 — scan `cross-cutting/skills/`; each dir with `SKILL.md` → `_build_skill_record(dir, root, "core")`.
2. Phase 2 — scan active profile's `profiles/<profile_id>/skills/`: dir WITH `SKILL.md` → standalone profile skill (`source="{profile_id}-profile"`, **wins over core** of same id); dir WITHOUT `SKILL.md` but with overlay content → merge onto matching core via `_apply_profile_overlay` (re-sourced `{profile_id}-profile`); empty dir → skipped. Active profile id resolves via in-process `active_profile()` → `OLYMPUS_PROFILE` env → default `"faa"` (`skill_bootstrap.py:358-385`).

**Record build (`_build_skill_record`, `skill_bootstrap.py:246-...`):**
- `parse_skill_md` reads YAML frontmatter (`---` delimited) → `name`, `description`, `agent`, `allowed_tools` (list), and `system_prompt` = the markdown BODY after frontmatter (`skill_bootstrap.py:123-145`, `_parse_frontmatter:64-120`).
- `content` = full SKILL.md text; `name` falls back to `_title_case(skill_id)` rules (`skill_bootstrap.py:219-238`, acronym/mixed-case maps at `:193-216`).
- `model_tier` = `AGENT_TO_TIER[agent]` (or NULL).
- `assembly_line` = `LINE_MAP[skill_id]`; `dispatch_ids` = `DIR_TO_DISPATCH[skill_id]` (default `[]`).
- `enrichment_level` from presence of subdirs (`_determine_enrichment_level:176-185`): `full` if `references/` AND (`assets/` OR `config.json` OR `scripts/`); `partial` if exactly one present; else `minimal`.

**Upsert (`upsert_skills` + `_UPSERT_SQL`, `skill_bootstrap.py:476-539`):** `INSERT INTO skill (skill_id, name, description, category, assembly_line, enrichment_level, model_tier, source, content, status, system_prompt, references_data, assets_data, scripts_data, config_data, allowed_tools, dispatch_ids, skill_path, created_at, updated_at) VALUES (…, 'active', …, now(), now()) ON CONFLICT (skill_id) DO UPDATE SET <every column except id/skill_id/created_at> = EXCLUDED.…, updated_at = now()`. `status` is HARDCODED `'active'` on insert (`:485`) and **not** touched on conflict-update (preserved). `id` and `created_at` are preserved across re-bootstraps (only set on first insert).

### 1.7 ⭐ JSONB shapes for `skill`
The four JSONB "data" columns are populated by `_load_text_dir` / `_load_config` and serialized via `json.dumps(...)` before the `CAST(… AS jsonb)` (`skill_bootstrap.py:533-538`):

- **`references_data`** — `{ "<filename>.md": "<file UTF-8 text>" }`. Map of every `.md` file in `references/` (suffix-filtered to `.md`), filename→content. Empty dir → `{}`. (`_load_text_dir(dir, ".md")`, `skill_bootstrap.py:152-163`.)
- **`assets_data`** — `{ "<filename>": "<file UTF-8 text>" }`. Every file in `assets/` (no suffix filter; UnicodeDecodeError files silently skipped). Empty → `{}`.
- **`scripts_data`** — `{ "<filename>": "<file UTF-8 text>" }`. Every file in `scripts/`. Empty → `{}`.
- **`config_data`** — the **parsed JSON object** of `config.json` (arbitrary shape, whatever the skill's config.json contains), or `{}` if absent/unparseable. (`_load_config`, `skill_bootstrap.py:166-173`.)
- **`allowed_tools`** — `["ToolName", …]` JSON array of tool-name strings from the SKILL.md `allowed-tools:` frontmatter list. Default `[]`.
- **`dispatch_ids`** — `["dispatch-id", …]` JSON array from `DIR_TO_DISPATCH`. Default `[]`. (GIN-indexed for containment queries.)

⚠️ **Seed:** `scripts/seed_skills.py` invokes the bootstrap pipeline (it is NOT a static DML seed). There is no `INSERT INTO skill` in `seed_data.py`. Per the migration-seeding-separation rule, `015` is DDL-only (header `015:7`). The 137-skill catalog (per CLAUDE.md / `cross-cutting/skills/registry.yaml`) materializes ONLY by running the projection against the Git tree.

---

## 1A. `skill_metrics` — 5 columns

Derived per-skill dispatch-metrics rollup (P5-S30.9). Created by `060`; never altered later.

**Created:** `060_create_skill_metrics.py:53-96` (`op.create_table("skill_metrics", …)`).

Skill dispatch metrics were previously a LIVE SQL aggregation over `agent_task` keyed on the
free-form `module_name` string (a fragile historical-dispatch-name match — the old `WHERE
module_name = :skill_id` query in `olympus-api/src/routers/skills.py`). `060` introduces a
dedicated **derived** metrics table keyed by the canonical `skill_id` column (the one added to
`agent_task` in `027`). Per Olympus principle 4 (Git is source of truth; Postgres is a derived,
disposable query layer — `060:14-19`), `skill_metrics` is a **recompute / upsert projection**,
not an authoritative store: rows are recomputed from `agent_task` on task completion (see
`olympus-api/src/services/skill_metrics.py`) and can be rebuilt wholesale at any time. DDL-only,
no backfill, no DML (`060:35-37`).

| # | column | type | null | default | FK | added-by |
|---|---|---|---|---|---|---|
| 1 | `skill_id` | `String(150)` | NO | — | **PK** | `060:55-63` |
| 2 | `invocations_total` | `Integer` | NO | `0` | — | `060:64-70` |
| 3 | `gate_pass_rate` | `Numeric(5, 4)` | YES | — | — | `060:71-79` |
| 4 | `avg_quality_score` | `Numeric(3, 2)` | YES | — | — | `060:80-88` |
| 5 | `updated_at` | `DateTime(timezone=True)` | NO | `now()` | — | `060:89-95` |

> Column count = **5**. ⚠️ **`skill_id` is the PRIMARY KEY** — `String(150)` (the canonical
> kebab-case skill identifier), one row per skill, upserted on recompute (`060:30-33,55-63`). It
> matches `agent_task.skill_id` (also `VARCHAR(150)`, §3.1 of the workflow-tables file).
> ⚠️ **NO FK to `skill`** (`060:30-33`) — the registry (`cross-cutting/skills/registry.yaml`), NOT
> the `skill` table, is the catalog source of truth, and dispatches may reference skills not yet
> materialized as `skill` DB rows. Do **not** add an FK on regeneration.
> ⚠️ **`gate_pass_rate` is `NUMERIC(5,4)`** (0.0000–1.0000) = completed / terminal
> (completed+failed+timed_out) dispatch ratio; **NULL when no terminal dispatches exist yet**
> (`060:71-79`). ⚠️ **`avg_quality_score` is `NUMERIC(3,2)`** (0.00–1.00) = mean
> `agent_task.quality_score` across scored dispatches; **NULL when none scored** (`060:80-88`).
> `invocations_total` defaults `0`; `updated_at` is the last-recompute stamp (DB default `now()`).

**CHECK constraints:** NONE. The numeric ranges (0–1) are an application invariant, not a DB
CHECK — do not add one.

**Indexes / unique constraints:** none beyond the `skill_id` PRIMARY KEY (which is itself a unique
index). `060` creates no secondary index.

**No JSONB columns** — all scalar.

### 1A.1 Projection / population model
Derived recompute/upsert projection (NOT a Git projection, NOT in `seed_data.py`). Rows are
recomputed from `agent_task` on task completion and upserted keyed on `skill_id` PK
(`olympus-api/src/services/skill_metrics.py`). The table is populated **lazily** on the next task
completion per skill; a full backfill ships as a separate recompute pass, never as a migration
(`060:35-37`). An empty `skill_metrics` is a valid steady state (the skills router falls back to
the live aggregation or reports zero metrics). Disposable: drop + recompute from `agent_task`.

---

## 2. `user_account` — 12 columns

Identity records for local-password AND external OIDC/SSO users. Backs `/api/v1/auth` + `/api/v1/users` (P4-S1.11). Created by `026`; never altered by a later migration.

**Created:** `026_create_user_table.py:38-87`.

⚠️ **Table name is `user_account`, NOT `user`** — `user` is a reserved word in PG; the migration deliberately uses `user_account`.

| # | column | type | null | default | FK | added-by |
|---|---|---|---|---|---|---|
| 1 | `id` | `UUID(as_uuid=True)` | NO | `gen_random_uuid()` | PK | `026:40-45` |
| 2 | `username` | `String(150)` | NO | — | — | `026:46` |
| 3 | `email` | `String(255)` | NO | — | — | `026:47` |
| 4 | `full_name` | `String(255)` | YES | — | — | `026:48` |
| 5 | `password_hash` | `String(255)` | YES | — | — | `026:50` |
| 6 | `identity_provider` | `String(100)` | NO | `'local'` | — | `026:54-59` |
| 7 | `external_id` | `String(255)` | YES | — | — | `026:61` |
| 8 | `roles` | `JSONB` | NO | `'["viewer"]'::jsonb` | — | `026:62-67` |
| 9 | `is_active` | `Boolean` | NO | `true` | — | `026:68-73` |
| 10 | `last_login_at` | `DateTime(timezone=True)` | YES | — | — | `026:74` |
| 11 | `created_at` | `DateTime(timezone=True)` | NO | `now()` | — | `026:75-80` |
| 12 | `updated_at` | `DateTime(timezone=True)` | NO | `now()` | — | `026:81-86` |

⚠️ **`password_hash` is nullable with NO default** — intentional: NULL for OIDC/SSO users, bcrypt hash for local-password users (`026:49-50`). ⚠️ **`external_id` is nullable with NO default** — NULL for local users, IdP `sub` claim for OIDC users.

**CHECK constraints:** NONE. `identity_provider` shape (`local` | `oidc:<slug>`) and `roles` membership are enforced only in the application layer (`olympus-api/src/models/user.py:41-59`, `identity_provider_id`).

### 2.3 Indexes / unique constraints (4 — all PARTIAL except the last)
| index | columns | unique | partial `WHERE` | added-by |
|---|---|---|---|---|
| `uq_user_email_active` | `(email)` | YES | `is_active = true` | `026:93-99` |
| `uq_user_username_active` | `(username)` | YES | `is_active = true` | `026:100-106` |
| `uq_user_external_identity` | `(identity_provider, external_id)` | YES | `external_id IS NOT NULL` | `026:107-113` |
| `ix_user_identity_provider` | `(identity_provider)` | NO | — | `026:114-119` |

⚠️ **The uniqueness of email/username is PARTIAL on `is_active = true`** — a soft-deleted (deactivated) user frees its email/username for reuse. The `(identity_provider, external_id)` pair is unique only when `external_id` is set (so unlimited local users with NULL external_id coexist).

### 2.4 ⭐ Projection / seed model for `user_account`
NOT a Git projection — `user_account` is **authoritative** (it stores credentials/identity that cannot live in Git). Per `026` header (`026:19-22`): DDL-only, no bundled seed users.

**Seed (admin bootstrap):** `scripts/seed_admin_user.py` (idempotent). On first run: `INSERT INTO user_account (id, username, email, full_name, password_hash, identity_provider, external_id, roles, is_active, …)` with `roles = '["portfolio_admin"]'::jsonb`, `identity_provider = 'local'`, `password_hash = bcrypt(generated_password)` — the generated password is logged ONCE and never committed (`seed_admin_user.py:60-136`). If the user exists and is local → rotates `password_hash` + sets `roles = $3::jsonb` (`:96-104`); if OIDC → refuses (`:87-91`).

**JSONB shape — `roles`:** a JSON array of RBACRole string values. **RBACRole value set** (`olympus-api/src/models/common.py:56-65`): `portfolio_admin`, `portfolio_manager`, `tech_lead`, `arch_lead`, `compliance_lead`, `operations_lead`, `safety_board`, `viewer`, `service`. DB default `["viewer"]`. ⚠️ `require_role()` decodes the JWT `roles` claim; this column is the authoritative role-assignment seed source (`026:14-17`).

---

## 3. `portfolio_membership` — 6 columns

`(portfolio_id, user_id, role)` triples for portfolio-scoped authorization (Phase 5 W20). Created by `056`; never altered later.

**Created:** `056_create_portfolio_membership.py:34-60`.

| # | column | type | null | default | FK | added-by |
|---|---|---|---|---|---|---|
| 1 | `id` | `UUID(as_uuid=True)` | NO | `gen_random_uuid()` | PK | `056:36-41` |
| 2 | `portfolio_id` | `UUID(as_uuid=True)` | NO | — | **→`portfolio.id` (ON DELETE CASCADE)** | `056:42-47` |
| 3 | `user_id` | `String(255)` | NO | — | — | `056:48` |
| 4 | `role` | `String(32)` | NO | — | — | `056:49` |
| 5 | `granted_by` | `String(255)` | NO | — | — | `056:50` |
| 6 | `granted_at` | `TIMESTAMP()` | NO | `now()` | — | `056:51-56` |

⚠️ **`granted_at` is `sa.TIMESTAMP()` (no `timezone=True`)** → PG `TIMESTAMP WITHOUT TIME ZONE`. (Contrast `user_account`/`skill` which use `DateTime(timezone=True)`.) Reproduce as `TIMESTAMP WITHOUT TIME ZONE DEFAULT now()`.

⚠️ **CASCADE mass-delete risk:** `portfolio_id` FK is `ON DELETE CASCADE` — deleting a `portfolio` row wipes ALL its membership rows. `user_id` is a bare `String(255)` (NOT a FK to `user_account` — it stores the user `sub`/identifier string), so deleting a user does NOT cascade here.

**CHECK constraints:** NONE. `role` is `String(32)` enforced only at the app layer (RBACRole values, e.g. `portfolio_admin`/`portfolio_manager`/`viewer`).

### 3.3 Unique + indexes
| object | columns | kind | added-by |
|---|---|---|---|
| `uq_portfolio_membership` | `(portfolio_id, user_id)` | UNIQUE constraint | `056:57-59` |
| `ix_portfolio_membership_user` | `(user_id)` | btree index | `056:61-65` |
| `ix_portfolio_membership_portfolio` | `(portfolio_id)` | btree index | `056:66-70` |

### 3.4 Projection / seed model
Authoritative (not Git-derived). Seed: `scripts/seed_portfolio_memberships.py` — idempotent bootstrap that grants every active `portfolio_admin`-roled user a membership on every existing portfolio: `INSERT INTO portfolio_membership (portfolio_id, user_id, role, granted_by) VALUES ($1, $2, 'portfolio_admin', 'bootstrap') ON CONFLICT (portfolio_id, user_id) DO NOTHING` (`seed_portfolio_memberships.py:126-129`). `id`/`granted_at` are DB-defaulted. The `ON CONFLICT DO NOTHING` preserves an intentionally-demoted admin's existing role.

---

## 4. `chat_message` — 11 columns

Conversation persistence between reviewers and AI agents (gate/application/portfolio contexts). Created by `014`; never altered later.

**Created:** `014_create_chat_message_table.py:24-54`.

| # | column | type | null | default | FK | added-by |
|---|---|---|---|---|---|---|
| 1 | `id` | `UUID(as_uuid=True)` | NO | `gen_random_uuid()` | PK | `014:26-31` |
| 2 | `gate_id` | `String(255)` | YES | — | — (indexed inline) | `014:32` |
| 3 | `app_id` | `String(255)` | YES | — | — (indexed inline) | `014:33` |
| 4 | `context_type` | `String(50)` | NO | — | — | `014:34-36` |
| 5 | `context_id` | `String(255)` | NO | — | — (indexed inline) | `014:37` |
| 6 | `role` | `String(20)` | NO | — | — | `014:38-40` |
| 7 | `content` | `Text` | NO | — | — | `014:41` |
| 8 | `sources` | `JSONB` | YES | — | — | `014:42-44` |
| 9 | `model_used` | `String(100)` | YES | — | — | `014:45` |
| 10 | `token_usage` | `JSONB` | YES | — | — | `014:46-48` |
| 11 | `created_at` | `DateTime(timezone=True)` | YES | `now()` | — | `014:49-53` |

⚠️ **`created_at` is NULLABLE here** (no `nullable=False`), unlike the other tables in this file where it's NOT NULL. It has the `now()` default but the column permits NULL (`014:49-53`).

⚠️ **`gate_id` / `app_id` are `String(255)`, NOT UUIDs and NOT FKs** — they store id strings without referential integrity. `context_id` is also a plain string (for portfolio contexts it is the `_scoped_context_id` = portfolio_id folded with the page section, `chat.py:282` / `:308`).

**Value notes (app-enforced, no CHECK):** `context_type` ∈ {`gate`, `application`, `portfolio`} (`014:35-36`); `role` ∈ {`reviewer`, `agent`} (`014:39-40`).

**CHECK constraints:** NONE.

### 4.3 Indexes
| index | columns | kind | added-by |
|---|---|---|---|
| (auto, `gate_id`) | `(gate_id)` | btree, from `index=True` inline | `014:32` |
| (auto, `app_id`) | `(app_id)` | btree, from `index=True` inline | `014:33` |
| (auto, `context_id`) | `(context_id)` | btree, from `index=True` inline | `014:37` |
| `ix_chat_message_context` | `(context_type, context_id)` | composite btree | `014:55-59` |

⚠️ The three inline `index=True` flags emit PG-default-named indexes (`ix_chat_message_gate_id`, `ix_chat_message_app_id`, `ix_chat_message_context_id`). Reproduce all four.

### 4.4 ⭐ JSONB shapes for `chat_message`
Written by `_persist_chat_message` (`olympus-api/src/routers/chat.py:262-305`): `INSERT INTO chat_message (id, context_type, context_id, role, content, gate_id, app_id, sources, model_used, token_usage) VALUES (:id, …, CAST(:sources AS jsonb), :model_used, CAST(:token_usage AS jsonb))`. `id` is a client-side `uuid.uuid4()` (`:281`); `created_at` left to the DB default.

- **`sources`** — JSON ARRAY of source-citation objects, or NULL when empty. Each object is `ChatSource.model_dump(exclude_none=True)` (`chat.py:1093-1095`). Shape of one element (`ChatSource`, `chat.py:127-134`):
  ```json
  { "artifact": "catalog.json", "section": "technology", "finding_id": "F-001" }
  ```
  or, for repo-style citations:
  ```json
  { "artifact": "org/app", "file": "src/main.py", "line": 42 }
  ```
  Fields: `artifact` (str, always present), `section` (str|absent), `finding_id` (str|absent), `file` (str|absent), `line` (int|absent). Parsed from agent text by `parse_source_citations` against two regexes: `{artifact}:{section}:{finding-id}` and `{repo}:{file}:{line}` (`chat.py:169-227`). Serialized with `json.dumps(sources)` (`chat.py:299`).
- **`token_usage`** — JSON OBJECT `{"input": <int>, "output": <int>}`, or NULL. (Shape per `014:46-48` comment `{input, output}`; serialized `json.dumps(token_usage)`, `chat.py:301`.) NULL when no usage was captured.

⚠️ **Projection note:** `chat_message` is authoritative conversational state (NOT a Git projection) — agent answers and reviewer questions are persisted directly here; only the *citations within* `sources` point back at Git artifacts (`{artifact}:{section}:{finding-id}`) or repo files (`{repo}:{file}:{line}`).

---

## 5. `audit_log` — 9 columns

Forensic action record. Created by `004` (analytics-tables migration); indexes in `005`; never altered later.

**Created:** `004_create_analytics_tables.py:89-102`.

| # | column | type | null | default | FK | added-by |
|---|---|---|---|---|---|---|
| 1 | `id` | `UUID(as_uuid=True)` | NO | `gen_random_uuid()` | PK | `004:91-92` |
| 2 | `timestamp` | `DateTime(timezone=True)` | NO | `now()` | — | `004:93-94` |
| 3 | `actor` | `String(255)` | NO | — | — | `004:95` |
| 4 | `actor_type` | **`actor_type_enum`** | NO | — | — | `004:96` |
| 5 | `action` | `String(100)` | NO | — | — | `004:97` |
| 6 | `resource_type` | `String(100)` | NO | — | — | `004:98` |
| 7 | `resource_id` | `String(255)` | NO | — | — | `004:99` |
| 8 | `details` | `JSONB` | YES | — | — | `004:100` |
| 9 | `ip_address` | `String(45)` | YES | — | — | `004:101` |

⚠️ **`actor_type` is the only PG-enum-typed column in this whole file** (`actor_type_enum`, values `human`/`agent`/`system`, §0). NOT a varchar+CHECK. ⚠️ **`actor_type` has NO default and is NOT NULL** — every insert MUST supply one of the 3 enum values (the gate writer hardcodes `'human'`, `gate.py:2196`).

⚠️ **`ip_address` is `String(45)`** — sized for an IPv6 string (max 45 chars). Nullable, no default.

**CHECK constraints:** NONE (the enum type itself constrains `actor_type`).

### 5.3 Indexes (2)
| index | columns | added-by |
|---|---|---|
| `ix_audit_log_resource` | `(resource_type, resource_id)` | `005:62-64` |
| `ix_audit_log_timestamp` | `(timestamp)` | `005:65-66` |

### 5.4 ⭐ Projection / write model for `audit_log` — DUAL ROLE
This table has a **hybrid** identity:

1. **As a derived read-projection** — `olympus-api/src/services/audit_log.py` builds a *unified RBAC audit feed* by READING `audit_log` rows (e.g. `gate.escalate` / `gate.force_advance`) and UNION-ing them with derived events from `gate_approval`, `gate` (rejections), and `portfolio_membership` grants (`audit_log.py:1-20` docstring; `query_audit_events:43-...`). The header explicitly invokes Olympus principle 4 (Git = source of truth, Postgres = derived query layer): no new authoritative store is introduced for the *feed*.
2. **As a direct write target** — specific privileged actions INSERT authoritative rows. Confirmed writer: gate force-advance (`gate.py:2192-2205`): `INSERT INTO audit_log (actor, actor_type, action, resource_type, resource_id, details) VALUES (:actor, 'human', :action, 'gate', :resource_id, CAST(:details AS JSONB))` with `action='gate.force_advance'`. `id`/`timestamp` are DB-defaulted; `actor_type` hardcoded `'human'`; `ip_address` omitted (NULL).

### 5.5 ⭐ JSONB shape for `audit_log.details`
Free-form per-action JSON object (no fixed schema; key set varies by `action`). Confirmed shape for `gate.force_advance` (`gate.py:2185-2191`):
```json
{
  "comment": "<reviewer comment>",
  "bypass_evidence_check": false,
  "from_status": "preparing",
  "to_status": "approved",
  "advanced_app_status": "<new app status or null>"
}
```
Serialized `json.dumps(audit_details)` then `CAST(:details AS JSONB)`. Other `action` values store other shapes; `details` is the catch-all per-event payload (nullable).

⚠️ **Seed:** none. `seed_data.py` seeds `portfolio`/`application`/`wave`/`gate`/`score_history` only — NO `audit_log` rows (`seed_data.py:330-466`). Rows accrue purely from runtime privileged actions.

---

## 6. `model_config` — 5 columns

Task-type → default-model mapping (read by the worker's `ModelResolver`). Created by `004`; never altered later.

**Created:** `004_create_analytics_tables.py:30-38`.

| # | column | type | null | default | FK | added-by |
|---|---|---|---|---|---|---|
| 1 | `id` | `UUID(as_uuid=True)` | NO | `gen_random_uuid()` | PK | `004:32-33` |
| 2 | `task_type` | `String(100)` | NO | — | — (UNIQUE) | `004:34` |
| 3 | `default_model` | `String(100)` | NO | — | — | `004:35` |
| 4 | `default_model_tier` | `String(50)` | YES | — | — | `004:36` |
| 5 | `recommended_alternatives` | `JSONB` | YES | — | — | `004:37` |

**Unique:** `task_type` inline `unique=True` (`004:34`) → PG-default name `model_config_task_type_key`. **CHECK constraints:** NONE. **Indexes:** none beyond the unique + PK.

### 6.3 ⭐ JSONB shape — `recommended_alternatives`
JSON ARRAY of alternative model-name strings, or NULL. Confirmed by the worker dataclass that loads it (`olympus-worker/src/model_resolver.py:51-58`): `ModelConfig.recommended_alternatives: list[str]`. Example: `["claude-sonnet-4-6", "claude-haiku-4-5"]`.

### 6.4 Projection / population model
Authoritative config table (not Git-derived, not seeded by `seed_data.py`). Populated by config/admin paths and READ by the worker's `ModelResolver.load_task_configs([ModelConfig(task_type, default_model, default_model_tier, recommended_alternatives)])` (`model_resolver.py:119-123`). Resolution precedence in `resolve()` (`model_resolver.py:133-197`): (1) explicit `model_preference`, (2) `model_override` row (§7), (3) `model_config` row's `default_model`, (4) static tier map default. ⚠️ If the table is empty, resolution falls straight to the tier-map default (`DEFAULT_TIER`, `model_resolver.py:48`) — an empty `model_config` is a valid steady state.

---

## 7. `model_override` — 7 columns

Per-application model override for a task type. Created by `004`; never altered later.

**Created:** `004_create_analytics_tables.py:41-53`.

| # | column | type | null | default | FK | added-by |
|---|---|---|---|---|---|---|
| 1 | `id` | `UUID(as_uuid=True)` | NO | `gen_random_uuid()` | PK | `004:43-44` |
| 2 | `application_id` | `UUID(as_uuid=True)` | NO | — | **→`application.id` (ON DELETE CASCADE)** | `004:45-46` |
| 3 | `task_type` | `String(100)` | NO | — | — | `004:47` |
| 4 | `model` | `String(100)` | NO | — | — | `004:48` |
| 5 | `rationale` | `Text` | YES | — | — | `004:49` |
| 6 | `created_at` | `DateTime(timezone=True)` | NO | `now()` | — | `004:50-51` |
| 7 | `created_by` | `String(255)` | YES | — | — | `004:52` |

⚠️ **CASCADE mass-delete risk:** `application_id` FK is `ON DELETE CASCADE` — deleting an `application` wipes all its model-override rows.

**CHECK constraints:** NONE. **Unique constraints:** NONE — ⚠️ there is **no** `UNIQUE(application_id, task_type)`; multiple override rows for the same (app, task_type) are physically permitted. The resolver's `load_app_overrides` (`model_resolver.py:125-131`) builds `{app_id: {task_type: override}}` — last-loaded wins in memory; the load ORDER over duplicates is undefined. **Indexes:** none beyond PK.

### 7.3 Projection / population model
Authoritative (not Git-derived, not in `seed_data.py`). READ by `ModelResolver.load_app_overrides([ModelOverride(application_id, task_type, model, rationale)])` (`model_resolver.py:61-68`, `:125-131`). `rationale` / `created_by` are the human-audit fields.

---

## 7A. `viewer_event` — 7 columns

Append-only viewer-analytics telemetry (P5-S30.11). Created by `061`; never altered later.

**Created:** `061_create_viewer_event.py:58-123` (`op.create_table("viewer_event", …)`).

The artifact viewers rendered for gate reviewers (data-domain models, architecture blueprints,
etc.) emit **dwell telemetry**: how long a reviewer keeps a given section/sub-area of a viewer
visible and focused — a proxy for "where the artifact is hard to read" (`061:6-12`).
`viewer_event` is the **raw append-only event store**, one row per section-dwell observation. It
is a **derived telemetry projection, not an authoritative store** (Olympus principle 4 — Git is
source of truth, Postgres is a disposable query layer, `061:14-19`): events can be discarded and
re-collected without loss of any committed artifact. The aggregation endpoint rolls these rows up
by `(artifact_type, section)`. DDL-only, no backfill, no DML (`061:40-41`).

| # | column | type | null | default | FK | added-by |
|---|---|---|---|---|---|---|
| 1 | `id` | `UUID(as_uuid=True)` | NO | `gen_random_uuid()` | PK | `061:60-66` |
| 2 | `artifact_type` | `String(150)` | NO | — | — | `061:67-75` |
| 3 | `section` | `String(200)` | NO | — | — | `061:76-84` |
| 4 | `gate_id` | `UUID(as_uuid=True)` | YES | — | — (NO FK, `061:85-93`) | `061:85-93` |
| 5 | `app_id` | `UUID(as_uuid=True)` | YES | — | — (NO FK, `061:94-99`) | `061:94-99` |
| 6 | `dwell_ms` | `Integer` | NO | — | — | `061:100-105` |
| 7 | `occurred_at` | `DateTime(timezone=True)` | NO | `now()` | — | `061:106-112` |

> Column count = **7**. Semantics (`061:21-34`): `artifact_type` = the viewer's registry type
> (e.g. `data_domain_model`, `architecture_blueprint`); `section` = the section/sub-area dwelled
> on (e.g. `cross_domain_dependencies`, `c4_diagrams`); `dwell_ms` = milliseconds the section was
> visible/focused; `occurred_at` = event time (DB default `now()`).
> ⚠️ **`gate_id` and `app_id` are nullable UUIDs with NO FK** (`061:85-99`) — by design: gates may
> be transient/expired and applications may be gone; telemetry inserts must **not** fail on a
> missing/expired gate or app. Do **not** add FKs on regeneration — that would diverge (a deleted
> gate/app would break telemetry ingest). They are bare UUID columns.
> ⚠️ **`dwell_ms` is NOT NULL with NO default** — every event must supply the dwell duration.

**CHECK constraints:** NONE. `artifact_type`/`section` are free-form `String(n)` (registry types
validated upstream, not at the DB).

### 7A.1 Indexes & unique constraints
| index | columns | kind | added-by |
|---|---|---|---|
| (PK) | `id` | primary key | `061:60-66` |
| `ix_viewer_event_artifact_type` | `(artifact_type)` | btree | `061:114-118` |
| `ix_viewer_event_artifact_type_section` | `(artifact_type, section)` | composite btree | `061:119-123` |

⚠️ The composite `(artifact_type, section)` index backs the rollup query's `GROUP BY
artifact_type, section` / `WHERE artifact_type = :…` (`061:36-38`); the single-column
`artifact_type` index backs the type-filtered scan. Reproduce both. No unique constraints
(append-only — many dwell rows per `(artifact_type, section)` are expected).

**No JSONB columns** — all scalar (the dwell signal is flat: type, section, ids, ms, timestamp).

### 7A.2 Projection / population model
Derived telemetry projection (NOT a Git projection, NOT in `seed_data.py`). Populated **lazily**
by the ingest endpoint (one INSERT per section-dwell observation); rolled up by the aggregation
endpoint over `(artifact_type, section)`. Append-only and best-effort — discardable and
re-collectable. `id`/`occurred_at` are DB-defaulted; `artifact_type`/`section`/`dwell_ms` supplied
per event; `gate_id`/`app_id` nullable context.

---

## 8. `delegated_bundle` — 18 columns (17 from `057` + 1 from `063`)

Primary row of the Phase-5 W20 "delegated bundle" (paired human+local-agent work delegation): scope, lifecycle state, claim identity, expiration, fallback policy. Created by `057`; ONE column added by `063`.

**Created:** `057_create_delegated_bundle.py:44-130`. **Backing design:** `specifications/phase-5/delegated-bundles-design.md` §4.1. **Activity cross-ref:** `regen/03b-activities/bundle_activities.md` (the two Temporal activities `dispatch_delegated_bundle` / `expire_due_bundles_activity` write/expire these rows).

| # | column | type | null | default | FK | added-by |
|---|---|---|---|---|---|---|
| 1 | `id` | `UUID(as_uuid=True)` | NO | `gen_random_uuid()` | PK | `057:46-51` |
| 2 | `portfolio_id` | `UUID(as_uuid=True)` | NO | — | **→`portfolio.id`** (no ON DELETE → `NO ACTION`) | `057:52-57` |
| 3 | `application_id` | `UUID(as_uuid=True)` | YES | — | **→`application.id`** (no ON DELETE → `NO ACTION`) | `057:58-63` |
| 4 | `wave_id` | `UUID(as_uuid=True)` | YES | — | **→`wave.id`** (no ON DELETE → `NO ACTION`) | `057:64-69` |
| 5 | `scope_kind` | `String(32)` | NO | — | — | `057:70` |
| 6 | `target_id` | `String(128)` | NO | — | — | `057:71` |
| 7 | `status` | `String(32)` | NO | `'offered'` | — | `057:72-77` |
| 8 | `claimed_by_user_id` | `String(255)` | YES | — | — | `057:78` |
| 9 | `claimed_at` | `TIMESTAMP()` | YES | — | — | `057:79` |
| 10 | `expires_at` | `TIMESTAMP()` | YES | — | — | `057:80` |
| 11 | `submitted_at` | `TIMESTAMP()` | YES | — | — | `057:81` |
| 12 | `accepted_at` | `TIMESTAMP()` | YES | — | — | `057:82` |
| 13 | `local_agent_descriptor` | `JSONB` | YES | — | — | `057:83` |
| 14 | `fallback_policy` | `String(32)` | NO | `'internal_fallback'` | — | `057:84-89` |
| 15 | `created_by_user_id` | `String(255)` | NO | — | — | `057:90` |
| 16 | `created_at` | `TIMESTAMP()` | NO | `now()` | — | `057:91-96` |
| 17 | `updated_at` | `TIMESTAMP()` | NO | `now()` | — | `057:97-102` |
| 18 | `dispatching_workflow_id` | `String(255)` | YES | — | — | `063:45-57` |

⚠️ **All five `TIMESTAMP()` columns (9-12,16,17) are `TIMESTAMP WITHOUT TIME ZONE`** (no `timezone=True`). The expiry reaper computes a single timezone-aware UTC `now` in Python and uses it on both sides of the comparison (`bundle_activities.md:361`).

⚠️ **`dispatching_workflow_id` (col 18) added by `063`** — `op.add_column("delegated_bundle", sa.Column("dispatching_workflow_id", sa.String(255), nullable=True, comment=…))` (`063:45-57`). NULL for admin-created bundles (those have no parent workflow); set to the Temporal `workflow_id` that called `dispatch_delegated_bundle`. The reaper branches on null vs non-null to apply `fallback_policy`. (Migration `057` had no such column; the reaper formerly hardcoded `workflow_id=""`.)

### 8.2 ⭐ CHECK constraints (5) — FULL value sets
All defined inline in `057`:
1. **`chk_bundle_scope_kind`** (`057:103-106`): `scope_kind IN ('gate_packet', 'line_step')`.
2. **`chk_bundle_status`** (`057:107-111`): `status IN ('offered', 'claimed', 'submitted', 'accepted', 'rejected', 'expired', 'released')` — **7 values**.
3. **`chk_bundle_app_or_wave`** (`057:112-115`): `(application_id IS NOT NULL) OR (wave_id IS NOT NULL)` — at least one of app/wave must be set.
4. **`chk_bundle_claim_consistency`** (`057:116-124`): 
   ```
   (status = 'offered' AND claimed_by_user_id IS NULL AND claimed_at IS NULL)
   OR (status IN ('claimed','submitted','accepted','rejected','released')
       AND claimed_by_user_id IS NOT NULL AND claimed_at IS NOT NULL)
   OR (status = 'expired')
   ```
   ⚠️ `dispatch` inserts `'offered'` with claim columns NULL precisely to satisfy branch 1; the reaper flips to `'expired'` (branch 3 permits any claim-column state). Branch 2 requires both claim columns set for the claimed→released lifecycle.
5. **`chk_bundle_fallback`** (`057:125-129`): `fallback_policy IN ('internal_fallback', 'escalate', 'fail', 'redispatch')` — **4 values**.

### 8.3 Indexes (6: 5 from `057` + 1 from `063`)
| index | columns | partial `WHERE` | added-by |
|---|---|---|---|
| `ix_bundle_portfolio_status` | `(portfolio_id, status)` | — | `057:131-135` |
| `ix_bundle_application_id` | `(application_id)` | — | `057:136-140` |
| `ix_bundle_wave_id` | `(wave_id)` | — | `057:141-145` |
| `ix_bundle_claimed_by` | `(claimed_by_user_id)` | `claimed_by_user_id IS NOT NULL` | `057:146-151` |
| `ix_bundle_expires_at` | `(expires_at)` | `status = 'claimed'` | `057:152-157` |
| `ix_bundle_dispatching_workflow` | `(dispatching_workflow_id)` | `dispatching_workflow_id IS NOT NULL` | `063:58-63` |

⚠️ `ix_bundle_expires_at` (partial on `status='claimed'`) is what powers the reaper sweep — keep the partial predicate exact.

### 8.4 ⭐ Concurrency-guard UNIQUE index (raw SQL — NOT `op.create_index`)
`ux_bundle_one_open_per_scope` (`057:165-179`, `op.execute(...)`):
```sql
CREATE UNIQUE INDEX ux_bundle_one_open_per_scope
  ON delegated_bundle (
    scope_kind,
    target_id,
    COALESCE(application_id, '00000000-0000-0000-0000-000000000000'::uuid),
    COALESCE(wave_id,        '00000000-0000-0000-0000-000000000000'::uuid)
  )
  WHERE status NOT IN ('expired', 'released', 'rejected', 'accepted');
```
⚠️ At most ONE open (non-terminal) bundle per `(scope_kind, target_id, app, wave)` tuple. NULL app/wave is normalized to the zero-UUID via COALESCE so two NULL-app bundles still collide. This is the structural invariant behind `dispatch`'s non-idempotency (a collision raises a unique-violation → NonRetryableError). It is a **functional partial unique index** and MUST be created with raw SQL (alembic's `op.create_index` doesn't cleanly express the COALESCE expressions). Reproduce verbatim. `downgrade()` drops it via `DROP INDEX IF EXISTS ux_bundle_one_open_per_scope` (`057:317`).

### 8.5 ⭐ JSONB shape — `local_agent_descriptor`
JSONB, nullable, **no default** (NULL at dispatch). Dual-purpose:
- **Between dispatch and claim** it carries the TTL under an internal key: `{"_expires_in_hours": <int>}`, written by `dispatch` step E (`bundle_activities.md:334-341`): `UPDATE delegated_bundle SET local_agent_descriptor = jsonb_build_object('_expires_in_hours', :hours) WHERE id = :id`. ⚠️ **GOTCHA — the TTL travels inside the JSONB under `_expires_in_hours`, NOT a dedicated column.** The CLAIM handler reads it back to compute `expires_at = claim_time + hours`, then strips all `_`-prefixed keys when merging the caller's real descriptor. If `expires_in_hours is None`, the column stays NULL and claim defaults to `24*7` hours (7 days).
- **After claim** it holds the local-agent descriptor object the claimer supplied (free-form; `_`-prefixed internal keys removed). Shape is caller-defined.

### 8.6 ⭐ Git-as-source-of-truth → projection model for the bundle family
The two Temporal activities are the authoritative writers (cross-ref `regen/03b-activities/bundle_activities.md` §6):
- **`dispatch_delegated_bundle`** → delegates to `bundle.dispatch(db, *, contract, fallback_policy, expires_in_hours, created_by_user_id)` (`bundle.py:309-396`). This is the projection of a deterministic `BundleContract` (resolved read-only from `application`/`wave`/`portfolio` rows + hand-curated `_GATE_OUTPUTS`/`_LINE_STEP_OUTPUTS` registries) → 3 tables:
  - INSERT 1 `delegated_bundle` row (`status='offered'`, claim/expiry/submission cols NULL, `created_at`/`updated_at` DB-defaulted; `id` is a client-side `uuid.uuid4()` — NOT relying on `gen_random_uuid()`) — `bundle_activities.md:286-306`.
  - INSERT one `delegated_bundle_input_ref` per `contract.inputs` (`bundle_activities.md:308-318`).
  - INSERT one `delegated_bundle_output_ref` per `contract.outputs` (`bundle_activities.md:320-332`).
  - Conditional UPDATE of `local_agent_descriptor` with the TTL (§8.5).
  - `await db.commit()`. ⚠️ NO `ON CONFLICT` — concurrency guarded only by `ux_bundle_one_open_per_scope`.
- **`expire_due_bundles_activity`** → `bundle.expire_due_bundles(db)` (`bundle.py:857-877`): single statement flipping `status='claimed'` rows past `expires_at` to `'expired'` and setting `updated_at=now`, using ONE Python-computed UTC `now` on both SET and WHERE (`bundle_activities.md:352-361`).
- ⚠️ The other bundle-service writes (`claim`, `release`, `submit` + the helpers `_persist_session_artifacts` / `_persist_validation_history` that populate tables §11/§12) are reachable via the **API surface**, not these two activities — specified in the Phase-8 API/services regen (`bundle_activities.md:363`). Do not attribute their writes to the activity group.

The bundle rows are authoritative orchestration state; the artifact REFs they hold (`artifact_ref`, `schema_ref`, `submitted_artifact_ref`) point at Git/repo artifacts and JSON Schemas — those remain the source of truth for the actual artifact content.

---

## 9. `delegated_bundle_input_ref` — 5 columns

Read-only artifact refs supplied to the pair as starting context. Created by `057`; never altered later.

**Created:** `057_create_delegated_bundle.py:181-201`.

| # | column | type | null | default | FK | added-by |
|---|---|---|---|---|---|---|
| 1 | `id` | `UUID(as_uuid=True)` | NO | `gen_random_uuid()` | PK | `057:183-188` |
| 2 | `bundle_id` | `UUID(as_uuid=True)` | NO | — | **→`delegated_bundle.id` (ON DELETE CASCADE)** | `057:189-194` |
| 3 | `artifact_kind` | `String(64)` | NO | — | — | `057:195` |
| 4 | `artifact_ref` | `Text` | NO | — | — | `057:196` |
| 5 | `description` | `Text` | YES | — | — | `057:197` |

**Unique:** `uq_bundle_input_ref` = `UNIQUE(bundle_id, artifact_ref)` (`057:198-200`). **CHECK constraints:** NONE. **Index:** `ix_bundle_input_ref_bundle` on `(bundle_id)` (`057:202-206`).

⚠️ **CASCADE:** `bundle_id` is `ON DELETE CASCADE` — deleting the parent `delegated_bundle` wipes all its input refs (true for all four child tables §9-§12).

**Write path:** `dispatch` step C inserts `(bundle_id, artifact_kind, artifact_ref, description)`; `id` DB-defaulted (`bundle_activities.md:347`). One row per `contract.inputs` entry; for an app/wave with a `portfolio.artifact_repo_url`, the single default input is `artifact_kind="artifact-repo"`, `artifact_ref=<repo url>` (`bundle_activities.md:257-258`).

---

## 10. `delegated_bundle_output_ref` — 8 columns

Required artifact slots (kind + schema_ref) the pair must fill; the submitted artifact ref is attached on submission. Created by `057`; never altered later.

**Created:** `057_create_delegated_bundle.py:208-236`.

| # | column | type | null | default | FK | added-by |
|---|---|---|---|---|---|---|
| 1 | `id` | `UUID(as_uuid=True)` | NO | `gen_random_uuid()` | PK | `057:210-215` |
| 2 | `bundle_id` | `UUID(as_uuid=True)` | NO | — | **→`delegated_bundle.id` (ON DELETE CASCADE)** | `057:216-221` |
| 3 | `artifact_kind` | `String(64)` | NO | — | — | `057:222` |
| 4 | `schema_ref` | `Text` | NO | — | — | `057:223` |
| 5 | `required` | `Boolean` | NO | `TRUE` | — | `057:224-229` |
| 6 | `description` | `Text` | YES | — | — | `057:230` |
| 7 | `submitted_artifact_ref` | `Text` | YES | — | — | `057:231` |
| 8 | `submitted_at` | `TIMESTAMP()` | YES | — | — | `057:232` |

**Unique:** `uq_bundle_output_ref` = `UNIQUE(bundle_id, artifact_kind)` (`057:233-235`). **CHECK constraints:** NONE. **Index:** `ix_bundle_output_ref_bundle` on `(bundle_id)` (`057:237-241`).

⚠️ **`submitted_at` is `TIMESTAMP WITHOUT TIME ZONE`**; both `submitted_artifact_ref` and `submitted_at` are NULL at dispatch and filled later at submit time (NOT by `dispatch`) — `bundle_activities.md:332`, `:348`.

**Write path:** `dispatch` step D inserts `(bundle_id, artifact_kind, schema_ref, required, description)`; `id` DB-defaulted, `submitted_*` NULL (`bundle_activities.md:320-332`). One row per `contract.outputs` entry (the hand-curated `_GATE_OUTPUTS` / `_LINE_STEP_OUTPUTS` registries — e.g. gate `G-DC` → 4 outputs `application-catalog-entry`, `tech-fingerprint`, `analysis-report`, `discovery-synthesis`, each with its `schemas/discovery/*.schema.json` ref; full registry at `bundle_activities.md:264-279`).

---

## 11. `delegated_bundle_session_artifact` — 6 columns

Local-agent session evidence (transcript / prompt / diff / summary) with SHA-256 hash. Created by `057`; never altered later.

**Created:** `057_create_delegated_bundle.py:243-270`.

| # | column | type | null | default | FK | added-by |
|---|---|---|---|---|---|---|
| 1 | `id` | `UUID(as_uuid=True)` | NO | `gen_random_uuid()` | PK | `057:245-250` |
| 2 | `bundle_id` | `UUID(as_uuid=True)` | NO | — | **→`delegated_bundle.id` (ON DELETE CASCADE)** | `057:251-256` |
| 3 | `kind` | `String(32)` | NO | — | — | `057:257` |
| 4 | `artifact_ref` | `Text` | NO | — | — | `057:258` |
| 5 | `hash` | `String(64)` | YES | — | — | `057:259` |
| 6 | `captured_at` | `TIMESTAMP()` | NO | `now()` | — | `057:260-265` |

⚠️ **CHECK constraint — `chk_bundle_session_kind`** (`057:266-269`): `kind IN ('transcript', 'prompt', 'diff', 'summary')` — **4 values**.

**Index:** `ix_bundle_session_artifact_bundle` on `(bundle_id)` (`057:271-275`). **Unique constraints:** NONE.

⚠️ **`hash` is `String(64)`** — sized for a hex SHA-256 (64 chars). Nullable. **`captured_at` is `TIMESTAMP WITHOUT TIME ZONE` with `now()` default.**

**Write path:** populated by `_persist_session_artifacts` on submit (API surface, NOT the dispatch activity — `bundle_activities.md:363`).

---

## 12. `delegated_bundle_validation_history` — 6 columns

Append-only ledger of every submission attempt (accept/reject + structured violations). Created by `057`; never altered later.

**Created:** `057_create_delegated_bundle.py:277-304`.

| # | column | type | null | default | FK | added-by |
|---|---|---|---|---|---|---|
| 1 | `id` | `UUID(as_uuid=True)` | NO | `gen_random_uuid()` | PK | `057:279-284` |
| 2 | `bundle_id` | `UUID(as_uuid=True)` | NO | — | **→`delegated_bundle.id` (ON DELETE CASCADE)** | `057:285-290` |
| 3 | `submitted_at` | `TIMESTAMP()` | NO | `now()` | — | `057:291-296` |
| 4 | `submitted_by` | `String(255)` | NO | — | — | `057:297` |
| 5 | `outcome` | `String(32)` | NO | — | — | `057:298` |
| 6 | `violations` | `JSONB` | YES | — | — | `057:299` |

⚠️ **CHECK constraint — `chk_bundle_validation_outcome`** (`057:300-303`): `outcome IN ('accepted', 'rejected')` — **2 values**.

**Index:** `ix_bundle_validation_history_bundle` on `(bundle_id, submitted_at)` (`057:305-309`). **Unique constraints:** NONE (append-only — repeat submissions create new rows). **`submitted_at` is `TIMESTAMP WITHOUT TIME ZONE` with `now()` default.**

### 12.3 ⭐ JSONB shape — `violations`
JSON ARRAY of structured validation-violation objects (nullable; NULL/empty on an accept). Each element mirrors the return-payload validator shape (`olympus-api/src/services/return_payload_validator.py:34-36`, `human_paired_agent.py:272-283`): an object like `{"path": "/foo/0/bar", "message": "...", "schema_path": "..."}`. Written by `_persist_validation_history` on submit (API surface, NOT the dispatch activity — `bundle_activities.md:363`).

---

## 13. MIGRATION DAG (linear, for the tables in this file)

The full chain is linear `001 → 002 → … → 066` with these provenance points for this file's tables (`down_revision` shown):

```
001 (enum types: actor_type_enum) ─┐
002 (core)                          │
003 (workflow)                      │
004 (analytics) ── model_config, model_override, audit_log   [down_revision="003"]
005 (indexes)  ── audit_log indexes                          [down_revision="004"]
…
014 ── chat_message                                          [down_revision="013"]
015 ── skill (create)                                        [down_revision="014"]
…
017 ── skill (+7 cols, GIN idx)                              [down_revision="016"]
018 ── skill (+scripts_data)                                 [down_revision="017"]
…
026 ── user_account                                          [down_revision="025"]
…
054                                                          [down_revision="053"]
056 ── portfolio_membership   ⚠️ down_revision="054" (055 skipped — no 055 file)
057 ── delegated_bundle + 4 children + ux guard             [down_revision="056"]
…
060 ── skill_metrics (create)                               [down_revision="059"]
061 ── viewer_event (create)                                [down_revision="060"]
062 ── (gate_approval; NOT in this file — see workflow-tables §12) [down_revision="061"]
063 ── delegated_bundle.dispatching_workflow_id (+partial idx) [down_revision="062"]
…
066 (HEAD: interview_session; NOT in this file — see workflow-tables §14)
```

⚠️ **`055` does not exist** — there is no `055_*.py`. The chain hops `054 → 056` because `056.down_revision = "054"`. Do not synthesize a phantom `055`. (Also note `039_merge_w19_reconciliation_heads.py` is a merge node elsewhere in the DAG, but it does not touch any table in this file.)

---

## 14. PER-MIGRATION LEDGER (only entries touching this file's tables)

| rev | file | down_rev | effect on this file's tables |
|---|---|---|---|
| `001` | `001_create_enum_types.py` | None | CREATE TYPE `actor_type_enum` ('human','agent','system') — used by `audit_log.actor_type`. |
| `004` | `004_create_analytics_tables.py` | `003` | CREATE `model_config`, `model_override`, `audit_log` (also `score_history`, `traceability_link` — out of scope here). |
| `005` | `005_create_indexes.py` | `004` | CREATE `ix_audit_log_resource`, `ix_audit_log_timestamp`. |
| `014` | `014_create_chat_message_table.py` | `013` | CREATE `chat_message` (+3 inline idx + `ix_chat_message_context`). |
| `015` | `015_create_skill_table.py` | `014` | CREATE `skill` (13 cols) + `ix_skill_skill_id`/`ix_skill_assembly_line`/`ix_skill_status`. |
| `017` | `017_add_skill_structured_columns.py` | `016` | ALTER `skill` ADD `system_prompt`,`references_data`,`assets_data`,`config_data`,`allowed_tools`,`dispatch_ids`,`skill_path` + GIN `ix_skill_dispatch_ids`. |
| `018` | `018_add_skill_scripts_data.py` | `017` | ALTER `skill` ADD `scripts_data` JSONB DEFAULT '{}'. |
| `026` | `026_create_user_table.py` | `025` | CREATE `user_account` (12 cols) + 3 partial unique idx + `ix_user_identity_provider`. |
| `056` | `056_create_portfolio_membership.py` | `054` | CREATE `portfolio_membership` (6 cols) + `uq_portfolio_membership` + 2 idx. |
| `057` | `057_create_delegated_bundle.py` | `056` | CREATE `delegated_bundle` (17 cols, 5 CHECKs, 5 idx) + `ux_bundle_one_open_per_scope` (raw) + 4 child tables (input_ref/output_ref/session_artifact/validation_history) with their CHECKs/idx/uniques. |
| `060` | `060_create_skill_metrics.py` | `059` | CREATE `skill_metrics` (5 cols; `skill_id` PK String(150); NO CHECK, NO FK, no secondary idx). |
| `061` | `061_create_viewer_event.py` | `060` | CREATE `viewer_event` (7 cols; `gate_id`/`app_id` nullable, NO FK) + `ix_viewer_event_artifact_type` + `ix_viewer_event_artifact_type_section`. |
| `063` | `063_bundle_dispatching_workflow.py` | `062` | ALTER `delegated_bundle` ADD `dispatching_workflow_id` String(255) NULL + partial idx `ix_bundle_dispatching_workflow`. |

(No other migration among the 65 files touches any of these 14 tables — verified by grep across all `*.py` for `ADD COLUMN` / `add_column` / `alter_column` / `ALTER TABLE` / `CheckConstraint` / `UniqueConstraint` keyed to each table name. `027`'s `drop_column("agent_task","skill_id")` touches `agent_task`, NOT `skill`.)

---

## 15. SEEDS SUMMARY (for these tables)

| table | seeded by | mechanism |
|---|---|---|
| `skill` | `scripts/seed_skills.py` | Runs the `bootstrap_skills` projection over Git skill dirs → `upsert_skills` (ON CONFLICT skill_id). NOT static DML. |
| `skill_metrics` | — | None. Derived recompute/upsert from `agent_task` on task completion; lazily populated; empty is valid. |
| `user_account` | `scripts/seed_admin_user.py` | Idempotent: creates ONE `portfolio_admin` local user with a generated bcrypt password (logged once). |
| `portfolio_membership` | `scripts/seed_portfolio_memberships.py` | Idempotent: grants every active global-`portfolio_admin` user `('portfolio_admin','bootstrap')` on every portfolio; ON CONFLICT DO NOTHING. |
| `chat_message` | — | None. Runtime-only (reviewer/agent messages). |
| `audit_log` | — | None (`seed_data.py` does NOT touch it). Runtime privileged actions only. |
| `model_config` | — | None in `seed_data.py`. Populated via config/admin paths; empty is valid (resolver falls to tier-map default). |
| `model_override` | — | None. Created via per-app override admin paths. |
| `viewer_event` | — | None. Append-only dwell telemetry; lazily populated by the ingest endpoint; discardable. |
| `delegated_bundle` + 4 children | — | None. Created at runtime by the dispatch activity / API. |

⚠️ All migrations are strictly DDL-only (every header cites the `database-migration-seeding-separation.md` rule); ALL seed data lives in `scripts/seed_*.py`, never in a migration.
