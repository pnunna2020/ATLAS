# Activity Group: Line Transitions — Architecture & Data projections

**Source file:** `temporal/olympus_workflows/activities/line_transitions.py`
**HEAD:** `7cb3b20c`. **Line numbers REFRESHED to HEAD** (see ⚠️ shift note below).
**Owned range:** lines **3253–3979** (`persist_architecture_side_effects` @ 3253; the Data-line helpers @ 3478–3616; `persist_data_side_effects` @ 3618; the Modernization helpers @ 3765–3978 are read for context but **owned by a sibling file** — the Modernization activity itself begins @ 3980 and is NOT reproduced here).

> ⚠️ **HEAD `7cb3b20c` line-shift note (citations CORRECTED).** `line_transitions.py` grew by +162 lines via two upstream insertions. The Architecture region shifted by **+115** (`persist_architecture_side_effects` 3138→**3253**; its helpers `_extract_blueprint_side_effects` 3018→**3133**, `_extract_lineage_side_effects` 3057→**3172**, `_extract_new_application_row` 3109→**3224**; `_ARCHITECTURE_PATTERNS` 2995→**3110**, `_LINEAGE_RELATIONSHIPS` 3006→**3121**). The Data region shifted by **+125** (`persist_data_side_effects` 3493→**3618**; helpers `_extract_data_architecture_side_effects` 3373→**3498**, `_extract_data_domains_side_effects` 3414→**3539**, `_extract_shared_db_cluster_rows` 3436→**3561**; `_DATA_PATTERNS` 3353→**3478**, `_CLUSTER_ROLES` 3363→**3488**). `_extract_architecture_compliance_metadata` is UNCHANGED at **1019** (above the insertion points). Inline pseudocode `# NNNN` anchors below have been re-based to HEAD. **`types.py` also grew** (+68): the dataclass citations are CORRECTED. Bodies are behaviorally UNCHANGED — only citations moved.

**Activities reproduced (2):**
1. `persist_architecture_side_effects` (line 3253) — post-G-02 projection.
2. `persist_data_side_effects` (line 3618) — post-G-DT projection.

Both are **projection / persist_\*** activities: they parse artifact JSON, transform it into a projection dict, and write it onto `application` + a satellite table (`application_lineage` / `shared_db_cluster`), all inside ONE asyncpg transaction. The complete artifact-field → table.column mapping is reproduced below as explicit tables PLUS the control flow.

---

## 0. PREAMBLE — `@foundry_activity` decorator semantics (MUST reproduce)

Both activities are decorated:

```python
@foundry_activity(config=ActivityConfig(enable_observability=True))
```

`foundry_activity` lives in `foundry_temporal/activities.py` (imported at line_transitions.py:26 as `from foundry_temporal.activities import ActivityConfig, foundry_activity`). It is **NOT** plain `@activity.defn`. A rebuild using plain `@activity.defn` loses error-wrapping + retryability classification and breaks Temporal's retry behavior. Reproduce exactly:

`foundry_activity(config=None, name=None, **activity_kwargs)` returns a decorator that wraps `func` as follows (`foundry_temporal/activities.py:107-165`):

1. `activity_config = config or ActivityConfig()`. Here `config=ActivityConfig(enable_observability=True)`. **All other `ActivityConfig` fields default** (`activities.py:27-39`): `retry_policy=None`, all timeouts `None`, `enable_observability=True` (default), `enable_error_wrapping=True` (default), `log_inputs=False`, `log_outputs=False`. ⚠️ Because no timeouts/retry_policy are set on the decorator, **timeouts + RetryPolicy come from the workflow's `execute_activity(...)` call site, not from here.**
2. The inner `wrapper` is decorated `@activity.defn(name=name, **activity_kwargs)` then `@wraps(func)`. `name` is `None`, so Temporal registers the activity under the **function name** (`persist_architecture_side_effects` / `persist_data_side_effects`).
3. `activity_name = name or func.__name__`.
4. **Observability (enabled):** before calling `func`, logs `f"Activity {activity_name} starting"` with `extra={"inputs": args if log_inputs else None}` → here `inputs=None` (log_inputs False). After success, logs `f"Activity {activity_name} completed"` with `extra={"outputs": None}` (log_outputs False).
5. **Body:** `result = await func(*args, **kwargs)`; returns `result`.
6. **Error path (`except Exception as error`)** — with `enable_error_wrapping=True`:
   - Logs `f"Activity {activity_name} failed: {error}"` with `extra={"error": str(error)}`.
   - If `isinstance(error, (WorkflowError, ApplicationError))` → **`raise`** (re-raise unchanged; preserves the original `non_retryable` flag). `NonRetryableError` / `RetryableError` subclass `WorkflowError` which subclasses `temporalio.exceptions.ApplicationError`, so any error these activities raise explicitly (always `NonRetryableError`) **passes through verbatim**.
   - elif `_is_retryable_error(error)` → `raise RetryableError(f"Retryable error in {activity_name}: {error}") from error`.
   - else → `raise NonRetryableError(f"Non-retryable error in {activity_name}: {error}") from error`.

`_is_retryable_error(error)` (`activities.py:168-183`): lowercases `str(type(error))` and returns True if it contains any of: `timeout, connection, network, temporary, unavailable, overload, busy, throttle, rate_limit`. ⚠️ It matches on the **type's repr string**, not the message. So an `asyncpg` `ConnectionDoesNotExistError` / `CannotConnectNowError` (type repr contains "connection"/"connect") classifies **retryable** and Temporal retries the whole activity; a `ValueError`/`KeyError`/generic `Exception` classifies **non-retryable**.

**Error classes** (`foundry_temporal/errors.py`):
- `WorkflowError(ApplicationError)` — `__init__(message, non_retryable=True)`.
- `RetryableError(WorkflowError)` — `non_retryable=False`.
- `NonRetryableError(WorkflowError)` — `non_retryable=True`.

**Net effect for these two activities:** the explicit `raise NonRetryableError(...)` on bad `target_app_id` propagates verbatim (non-retryable). Any DB exception raised *inside the transaction block* is NOT caught locally (no try/except around the `asyncpg.connect`/transaction other than the `finally: conn.close()`), so it bubbles to the decorator wrapper and is classified retryable/non-retryable by type-repr as above. ⚠️ This means a transient asyncpg connection failure → `RetryableError` → Temporal re-runs the activity → re-projection. Re-projection is **idempotent** (UPDATE is last-writer-wins on the same scalar values; satellite-row INSERTs are `ON CONFLICT DO NOTHING`), so retries are safe.

---

## 1. Shared module-level dependencies (read for context, defined OUTSIDE owned range but USED by owned activities)

### 1.1 Imports (line_transitions.py:15-28, plus utils)
```python
import json, os, uuid
from datetime import datetime, timezone
from typing import Any
import asyncpg
from foundry_temporal.activities import ActivityConfig, foundry_activity
from foundry_temporal.errors import NonRetryableError
from olympus_workflows.types import (... PersistArchitectureSideEffectsInput, PersistArchitectureSideEffectsResult, PersistDataSideEffectsInput, PersistDataSideEffectsResult, StepExecutionContext ...)
from olympus_workflows.utils.execution import (emit_code_step_start, emit_code_step_complete, ExecutionStatus ...)
logger = logging.getLogger(__name__)
```

### 1.2 `_db_url()` (line 88-94)
```python
def _db_url() -> str:
    host = os.environ.get("DATABASE_HOST", "localhost")
    port = os.environ.get("DATABASE_PORT", "5432")
    user = os.environ.get("DATABASE_USER", "olympus")
    password = os.environ.get("DATABASE_PASSWORD", "olympus")
    db = os.environ.get("DATABASE_NAME", "olympus")
    return f"postgresql://{user}:{password}@{host}:{port}/{db}"
```
Builds a libpq DSN from env vars (defaults: `olympus:olympus@localhost:5432/olympus`). Connection is per-activity via `asyncpg.connect(_db_url())`; **no pool** — open + `finally: await conn.close()`.

### 1.3 `_try_parse_json(text: str) -> dict[str, Any] | None` (line 281-297)
Best-effort parse of agent JSON that may be prose-wrapped:
1. If `not text` → return `None`.
2. `json.loads(text)`; on `JSONDecodeError`, find first `{` (`text.find("{")`) and last `}` (`text.rfind("}")`); if `start == -1 or end <= start` → `None`; else retry `json.loads(text[start:end+1])`, return `None` on second failure.
3. Return `value` **only if `isinstance(value, dict)`**, else `None`. (A top-level JSON array or scalar parses but returns `None`.)

### 1.4 `_build_update_sql(projections) -> tuple[str, list[Any]]` (line 1226-1259) — THE projection-to-UPDATE builder
This is the shared UPDATE assembler both activities use for the `application`-row scalar projections.
```python
def _build_update_sql(projections: dict[str, Any]) -> tuple[str, list[Any]]:
    assignments: list[str] = []
    params: list[Any] = []
    idx = 1
    for column in _SIDE_EFFECT_COLUMNS:        # iterate in FIXED tuple order, NOT dict order
        if column not in projections:
            continue
        value = projections[column]
        if column in _JSONB_COLUMNS:
            value = json.dumps(value)          # JSONB cols are dumped to a string
        assignments.append(f"{column} = ${idx}")
        params.append(value)
        idx += 1
    # Always touch updated_at so the dashboard refreshes.
    assignments.append(f"updated_at = ${idx}")
    params.append(datetime.now(timezone.utc))
    idx += 1
    where_idx = idx
    sql = "UPDATE application SET " + ", ".join(assignments) + f" WHERE id = ${where_idx}"
    return sql, params
```
⚠️ **Column ordering:** assignments are emitted in the order of the `_SIDE_EFFECT_COLUMNS` tuple, NOT the insertion order of the `projections` dict. The reproduction MUST iterate the whitelist tuple to get identical placeholder numbering.
⚠️ **`updated_at` is ALWAYS appended** as the second-to-last assignment with `datetime.now(timezone.utc)`. The caller then **appends `target_uuid` to `params`** (the WHERE bind) — `_build_update_sql` reserves `$where_idx` but does NOT add the id param itself. Both call sites do `params.append(target_uuid)` after calling the builder.
⚠️ **JSONB serialization:** only columns in `_JSONB_COLUMNS` get `json.dumps`'d. Everything else is passed as a raw Python object (datetime → timestamptz, `list[uuid.UUID]` → `uuid[]`, str → text/varchar) and asyncpg binds natively. The generated SQL has **no `::jsonb` cast token** — asyncpg infers the column type, so the JSONB columns receive a Python `str` that Postgres coerces to jsonb on assignment.

`_SIDE_EFFECT_COLUMNS` (line 791-874) is a fixed tuple (full list in the Discovery/Rationalization sibling specs). The subset relevant to THIS file, **in tuple order**:
- Architecture: `architecture_blueprint_ref`, `architecture_pattern`, `architecture_decided_at`, `source_app_ids`, `target_repo_url`
- Data: `target_service_id`, `data_architecture_ref`, `data_migration_plan_ref`, `data_decided_at`, `data_pattern`, `data_domains`, `data_current_status`

`_JSONB_COLUMNS` (line 877-892) is `frozenset({tech_stack, size_metrics, architecture, business_logic, quality, ux_assessment, tco, portfolio_score, data_domains, bounded_contexts, generated_module_refs})`. ⚠️ Of the columns THIS file writes, **only `data_domains` is JSONB** (gets `json.dumps`'d). `source_app_ids` (a `list[uuid.UUID]`), `architecture_decided_at`/`data_decided_at` (datetime), and `target_repo_url`/`target_service_id`/`*_ref`/`*_pattern`/`data_current_status` (str) are all passed as native Python objects.

### 1.5 `_merge_application_metadata(conn, app_uuid, namespace, payload)` (line 1173-1225) — JSONB metadata merge (Architecture only)
Async, runs **on the caller's open connection inside the same transaction**.
```python
async def _merge_application_metadata(conn, app_uuid, namespace, payload) -> None:
    if not payload:
        return
    payload_with_meta = dict(payload)
    payload_with_meta.setdefault("last_assessed", datetime.now(timezone.utc).isoformat())
    namespace_block = json.dumps({namespace: payload_with_meta})
    await conn.execute(
        """
        UPDATE application
           SET metadata = COALESCE(metadata, '{}'::jsonb) || $1::jsonb,
               updated_at = $2
         WHERE id = $3::uuid
        """,
        namespace_block,
        datetime.now(timezone.utc),
        app_uuid,
    )
```
- Copies `payload`, **`setdefault("last_assessed", <now iso>)`** (only adds if caller didn't supply it).
- Wraps as `{namespace: payload_with_meta}` and JSON-dumps the whole thing.
- SQL: `metadata = COALESCE(metadata, '{}'::jsonb) || $1::jsonb` — **shallow JSONB merge via `||`**; replaces the *entire* `metadata.<namespace>` block (does NOT deep-merge sub-keys). `COALESCE` guards NULL metadata (pre-051 rows in non-prod). Also re-stamps top-level `updated_at`.
- ⚠️ This is a **second UPDATE on the same `application` row** in the same transaction (the first being the `_build_update_sql` projection). Both touch `updated_at`. Last write wins; both use `datetime.now(timezone.utc)` captured at their own call moment.
- No-op short-circuit when `payload` is falsy.

### 1.6 `emit_code_step_start` / `emit_code_step_complete` (utils/execution.py:283-345) — Layer B step-execution record (best-effort, observability only)

`emit_code_step_start(ctx, *, function_name, columns_writable=None) -> uuid.UUID | None` (line 283):
- If `ctx is None` → return `None` (legacy call sites with no execution_context skip emission).
- Reads `workflow_id` + `attempt` from `temporalio.activity.info()` inside try/except (defaults `""`/`1` on failure — e.g. when called outside an activity context in tests).
- `payload = {"function": function_name}`; adds `payload["columns_written"] = columns_writable` if provided (these activities pass NO `columns_writable`, so payload starts as just `{"function": <name>}`).
- Calls `emit_execution_record(EmitExecutionRecordInput(portfolio_id=ctx.portfolio_id, line_id=ctx.line_id, step_id=ctx.step_id, step_kind=StepKind.CODE, workflow_id=..., app_id=ctx.app_id or None, wave_id=ctx.wave_id or None, attempt=..., payload=payload, status=ExecutionStatus.RUNNING))`.

`emit_execution_record` (line 150-219): INSERTs into `step_execution` (execution_id=uuid4, step_kind='code', status='running', …). **Best-effort: returns `None` and logs a warning on ANY exception or when `portfolio_id` is not a valid UUID.** Never raises. Full column mapping is owned by the execution-utils spec; here it matters only that it returns an `execution_id | None` that gets threaded to `emit_code_step_complete`.

`emit_code_step_complete(execution_id, *, status=ExecutionStatus.COMPLETED, columns_written=None, error=None) -> None` (line 324):
- `payload_merge = {"columns_written": columns_written}` iff `columns_written is not None` (the `[]` empty list still produces `{"columns_written": []}` because `[] is not None`).
- Calls `update_execution_record(execution_id, status=status, payload_merge=payload_merge, last_error=error)`.
- `update_execution_record` (line 222): no-op if `execution_id is None`; else UPDATEs `step_execution` SET status, completed_at=now, duration_ms=EXTRACT(EPOCH FROM (completed - started_at))*1000, `payload = payload || COALESCE($5::jsonb,'{}'::jsonb)` (shallow merge), `last_error = COALESCE($6, last_error)`. **Best-effort, swallows exceptions.**

`ExecutionStatus` enum (utils/execution.py:66-74): `QUEUED, RUNNING, COMPLETED, FAILED, TIMED_OUT, SKIPPED, ESCALATED, ABANDONED` (str values lowercase). Used: `ExecutionStatus.FAILED` (bad uuid path), default `COMPLETED` otherwise.

⚠️ **Critical sequencing:** `emit_code_step_start` is awaited as the **very first statement** in each activity (before the uuid parse). On the bad-uuid path the activity calls `emit_code_step_complete(exec_id, status=ExecutionStatus.FAILED, error=str(exc))` **before** raising `NonRetryableError`. On the "nothing extractable" path it calls `emit_code_step_complete(exec_id, columns_written=[])` (empty list, default COMPLETED status) and returns an empty result. On the success path it calls `emit_code_step_complete(exec_id, columns_written=<sorted list>)`. Because all emit calls are best-effort, none of them can fail the activity.

---

## 2. ACTIVITY: `persist_architecture_side_effects` (line 3253-3354)

### 2.1 Signature
```python
@foundry_activity(config=ActivityConfig(enable_observability=True))
async def persist_architecture_side_effects(
    input: PersistArchitectureSideEffectsInput,
) -> PersistArchitectureSideEffectsResult:
```

### 2.2 Input dataclass `PersistArchitectureSideEffectsInput` (types.py:1698-1731) — EVERY field
```python
@dataclass
class PersistArchitectureSideEffectsInput:
    target_app_id: str                              # REQUIRED (no default) — UUID string of the target app
    target_name: str = ""                           # name for a newly-provisioned target row
    target_portfolio_id: str = ""                   # portfolio UUID string for a new target row
    target_application_map_json: str = ""           # raw JSON of the target-application-map artifact (lineage + provisioning)
    blueprint_json: str = ""                         # raw JSON of architecture-blueprint.json (pattern, ratified_at, ea_compliance, security_architecture)
    blueprint_ref: str = ""                          # artifact-repo path to the merged blueprint
    decided_at: str = ""                             # ISO-8601 timestamp the G-02 merge landed
    target_repo_url: str = ""                        # target app's dedicated modernization repo URL (provisioned at target-state-mapping)
    execution_context: "StepExecutionContext | None" = None   # Layer B record context
```
Runs **once per target after G-02 approves**.

### 2.3 Output dataclass `PersistArchitectureSideEffectsResult` (types.py:1733-1746)
```python
@dataclass
class PersistArchitectureSideEffectsResult:
    target_app_id: str                              # echo of input.target_app_id
    architecture_pattern: str = ""                  # str(projections.get("architecture_pattern","")) — "" if not whitelisted/absent
    blueprint_persisted: bool = False               # "architecture_blueprint_ref" in projections
    new_application_row_created: bool = False        # True iff a new target row INSERT was attempted
    lineage_rows_inserted: int = 0                   # count of application_lineage rows actually inserted (not skipped by ON CONFLICT)
    target_repo_url_persisted: bool = False          # "target_repo_url" in projections
```

### 2.4 Control flow (exact)

```python
exec_id = await emit_code_step_start(input.execution_context, function_name="persist_architecture_side_effects")   # 3268
try:
    target_uuid = uuid.UUID(input.target_app_id)                          # 3273
except (ValueError, TypeError) as exc:                                     # 3274
    await emit_code_step_complete(exec_id, status=ExecutionStatus.FAILED, error=str(exc))   # 3275
    raise NonRetryableError(f"Invalid target_app_id: {input.target_app_id!r}") from exc   # 3278 — propagates verbatim (non-retryable)

target_map = _try_parse_json(input.target_application_map_json)            # 3282 -> dict | None
blueprint  = _try_parse_json(input.blueprint_json)                        # 3283 -> dict | None

projections: dict[str, Any] = {}
projections.update(_extract_blueprint_side_effects(blueprint, blueprint_ref=input.blueprint_ref, decided_at=input.decided_at))  # ~3286
if input.target_repo_url:                                                  # 3298 — empty string => skip (Retire/Retain/test harness)
    projections["target_repo_url"] = input.target_repo_url                 # 3299

lineage_rows, source_ids = _extract_lineage_side_effects(target_map)       # 3310
if source_ids:                                                             # 3311
    try:
        projections["source_app_ids"] = [uuid.UUID(s) for s in source_ids] # 3314 — list[UUID]; asyncpg binds to uuid[]
    except (ValueError, TypeError):
        logger.warning("lineage source_app_ids include invalid UUIDs; skipping cache")   # 3318 — drop the cache, KEEP lineage_rows

new_row = _extract_new_application_row(target_map, target_portfolio_id=input.target_portfolio_id, target_name=input.target_name)  # 3322

compliance_metadata = _extract_architecture_compliance_metadata(           # 3333
    blueprint=blueprint,
    ea_compliance = blueprint.get("ea_compliance") if isinstance(blueprint, dict) else None,
    security_arch = blueprint.get("security_architecture") if isinstance(blueprint, dict) else None,
)

if not projections and not lineage_rows and new_row is None and not compliance_metadata:   # 3348 — NOTHING-EXTRACTABLE short circuit
    logger.info("persist_architecture_side_effects: nothing extractable", extra={"target_app_id": input.target_app_id})   # 3350
    await emit_code_step_complete(exec_id, columns_written=[])             # 3353
    return PersistArchitectureSideEffectsResult(target_app_id=input.target_app_id)   # all defaults

conn = await asyncpg.connect(_db_url())                                    # 3358
try:
    async with conn.transaction():                                          # 3360 — single transaction wraps ALL writes
        new_row_created = False
        if new_row is not None:                                             # 3363 — provision new target row (Replace/Consolidate)
            try:
                portfolio_uuid = uuid.UUID(new_row["portfolio_id"]) if new_row["portfolio_id"] else None   # 3372
            except (ValueError, TypeError):
                portfolio_uuid = None                                       # bad portfolio => NULL, INSERT still proceeds
            await conn.execute(<INSERT application ... ON CONFLICT (id) DO NOTHING>, target_uuid, new_row["name"], portfolio_uuid)  # 3373
            new_row_created = True                                          # 3385 — set True regardless of whether ON CONFLICT skipped

        if projections:                                                     # 3388 — UPDATE blueprint projections
            sql, params = _build_update_sql(projections)
            params.append(target_uuid)                                      # 3390 — WHERE id bind appended by caller
            await conn.execute(sql, *params)                                # 3391

        lineage_inserted = 0
        for row in lineage_rows:                                            # 3395 — insert lineage edges
            try:
                source_uuid = uuid.UUID(row["source_app_id"])
            except (ValueError, TypeError):
                continue                                                    # 3399 — skip malformed source id, no fail
            result = await conn.execute(<INSERT application_lineage ... ON CONFLICT (target_app_id, source_app_id) DO NOTHING>,   # 3400
                                        target_uuid, source_uuid, row["relationship"], datetime.now(timezone.utc))
            if result.endswith(" 1"):                                       # 3416 — asyncpg returns "INSERT 0 N"; count only real inserts
                lineage_inserted += 1

        if compliance_metadata:                                             # 3422 — merge compliance metadata INSIDE the txn
            await _merge_application_metadata(conn, target_uuid, "compliance", compliance_metadata)   # 3423
finally:
    await conn.close()                                                      # 3430

columns_written = sorted(projections.keys())                               # 3432
if compliance_metadata:
    columns_written.append("metadata.compliance")                          # 3434 — appended AFTER sort (stays last regardless of alpha order)

logger.info("architecture side-effects persisted", extra={...})           # 3437
await emit_code_step_complete(exec_id, columns_written=columns_written)    # 3445
return PersistArchitectureSideEffectsResult(
    target_app_id=input.target_app_id,
    architecture_pattern=str(projections.get("architecture_pattern", "")),
    blueprint_persisted="architecture_blueprint_ref" in projections,
    new_application_row_created=new_row_created,
    lineage_rows_inserted=lineage_inserted,
    target_repo_url_persisted="target_repo_url" in projections,
)
```

⚠️ **GOTCHA (ordering within the transaction):** the writes execute in a fixed order — (1) INSERT new application row, (2) UPDATE projections, (3) INSERT lineage edges, (4) merge compliance metadata. This matters because the lineage rows have a FK `source_app_id`/`target_app_id` → `application.id ON DELETE CASCADE`; the target row must exist before its lineage edges are inserted (for Replace/Consolidate the new target row is created in step 1; for self-dispositions there are no lineage rows). Source-app rows are assumed pre-existing (created by Discovery). If a source app id has no `application` row, the FK insert raises inside the transaction → whole txn rolls back → activity raises (classified by decorator).
⚠️ **GOTCHA (`new_row_created` semantics):** set `True` whenever `new_row is not None`, NOT whether the INSERT actually created a row. An `ON CONFLICT (id) DO NOTHING` skip (rework re-run) still reports `new_application_row_created=True` in the result.

### 2.5 Helper: `_extract_blueprint_side_effects(blueprint, *, blueprint_ref, decided_at) -> dict` (line 3133-3171)
Produces the scalar blueprint projection subset:
- `if blueprint_ref:` → `out["architecture_blueprint_ref"] = blueprint_ref`.
- `if isinstance(blueprint, dict):` read `pattern = blueprint.get("pattern")`; if `isinstance(pattern, str) and pattern in _ARCHITECTURE_PATTERNS` → `out["architecture_pattern"] = pattern`; elif truthy `pattern` → log warning "blueprint pattern not in whitelist", **drop it** (ref+timestamp still persist).
- `if decided_at:` → `out["architecture_decided_at"] = datetime.fromisoformat(decided_at.replace("Z","+00:00"))` inside try/except `(TypeError, ValueError)`; on failure log "decided_at not ISO-8601" and **omit** the column.

`_ARCHITECTURE_PATTERNS` (line 3110-3120) = `frozenset({"modular-monolith", "microservices", "serverless", "event-driven", "hybrid", "batch"})`.

### 2.6 Helper: `_extract_lineage_side_effects(target_map) -> (list[dict], list[str])` (line 3172-3223)
- `if not isinstance(target_map, dict)` → `([], [])`.
- `relationship = target_map.get("relationship")`; if not a str OR not in `_LINEAGE_RELATIONSHIPS` → `([], [])`.
- ⚠️ **Self-dispositions short-circuit:** if `relationship in {"refactor-of","rearchitect-of","replatform-of","retain"}` → `([], [])` (no lineage edges; relationship lives on `application.disposition` only).
- `sources = target_map.get("sources")`; if not a list → `([], [])`.
- For each `entry` in `sources`: skip non-dict; read `source_app_id = entry.get("source_app_id")`; skip if not a non-empty str; append `{"source_app_id": <id>, "relationship": <relationship>}` to rows and `<id>` to ids.
- Returns `(rows, ids)`.

`_LINEAGE_RELATIONSHIPS` (line 3121-3132) = `frozenset({"replace", "consolidate", "refactor-of", "rearchitect-of", "replatform-of", "retain"})`. ⚠️ Only `replace` and `consolidate` actually produce edges (the other four are filtered by the self-disposition short-circuit). The full set is the gate that prevents arbitrary relationship strings from reaching the column.

### 2.7 Helper: `_extract_new_application_row(target_map, *, target_portfolio_id, target_name) -> dict | None` (line 3224-3252)
- `if not isinstance(target_map, dict)` → `None`.
- `if not target_map.get("provisioned_new_row")` → `None` (only Replace/Consolidate anchor sets this).
- `target_app_id = target_map.get("target_app_id")`; if not a non-empty str → `None`.
- Returns `{"id": target_app_id, "name": target_name or target_map.get("target_name") or target_app_id, "portfolio_id": target_portfolio_id or target_map.get("target_portfolio_id") or ""}`.
  - ⚠️ Name fallback chain: input.target_name → target_map.target_name → the id itself. Portfolio fallback: input.target_portfolio_id → target_map.target_portfolio_id → `""` (empty → INSERT writes NULL portfolio_id).
  - ⚠️ Note `id` is taken from `target_map["target_app_id"]`, but the INSERT actually binds `target_uuid` (parsed from `input.target_app_id`). The activity does not reconcile these; the caller is responsible for passing matching values.

### 2.8 Helper: `_extract_architecture_compliance_metadata(blueprint, ea_compliance, security_arch) -> dict` (line 1019-1055)
Builds the `metadata.compliance` block:
- `block = {"source_line": "Architecture"}`.
- `if isinstance(blueprint, dict) and blueprint.get("ratified_at"):` → `block["cato_state"] = "in-progress"`.
- `if isinstance(ea_compliance, dict):` read `findings = ea_compliance.get("findings")`; if a list → `block["ea_findings_count"] = len(findings)` and `block["ea_alignment_status"] = "compliant" if not findings else "needs-review"`.
- `if isinstance(security_arch, dict):` read `controls = security_arch.get("controls")`; if a list → `block["security_controls_count"] = len(controls)`.
- ⚠️ **Empty-block guard:** `if list(block.keys()) == ["source_line"]: return {}` — if NOTHING beyond `source_line` was extracted, returns `{}` (falsy), so the caller skips the metadata merge entirely. Note `_merge_application_metadata` later re-adds `last_assessed` via `setdefault`.

### 2.9 SQL written by `persist_architecture_side_effects`

**(A) INSERT new target application row** (line 3375-3379, only when `new_row is not None`):
```sql
INSERT INTO application (id, name, portfolio_id, current_line, current_status)
VALUES ($1, $2, $3, 'Architecture', 'architecture_complete')
ON CONFLICT (id) DO NOTHING
```
Binds: `$1=target_uuid`, `$2=new_row["name"]`, `$3=portfolio_uuid` (or NULL). ⚠️ `current_line` literal `'Architecture'` is bound to the `assembly_line` enum column; `current_status` literal `'architecture_complete'` to `VARCHAR(50)`. Idempotent on PK `id`.

**(B) UPDATE projections** (line 3389-3391, only when `projections` non-empty): SQL from `_build_update_sql` (§1.4). Touches the projected columns + `updated_at`, `WHERE id = $N`.

**(C) INSERT lineage edge** (line 3402-3408, per `lineage_rows` entry):
```sql
INSERT INTO application_lineage (target_app_id, source_app_id, relationship, created_at)
VALUES ($1, $2, $3, $4)
ON CONFLICT (target_app_id, source_app_id) DO NOTHING
```
Binds: `$1=target_uuid`, `$2=source_uuid`, `$3=row["relationship"]`, `$4=datetime.now(timezone.utc)`. ⚠️ ON CONFLICT targets the composite PK `(target_app_id, source_app_id)` (backed by `application_lineage_pkey`, migration 030). `result.endswith(" 1")` detects a real insert ("INSERT 0 1") vs a conflict skip ("INSERT 0 0").

**(D) Metadata merge** (line 3423, only when `compliance_metadata` truthy): SQL from `_merge_application_metadata` (§1.5).

### 2.10 Column-by-column mapping — `persist_architecture_side_effects`

#### Table `application` — INSERT (new target row, Replace/Consolidate only)
| Artifact source | application.column | Type | Value / default | Condition |
|---|---|---|---|---|
| `input.target_app_id` (parsed `target_uuid`) | `id` | UUID PK | bind `$1` | always (this INSERT) |
| `new_row["name"]` ← target_name‖target_map.target_name‖id | `name` | VARCHAR(255) | bind `$2` | always (this INSERT) |
| `new_row["portfolio_id"]` → `portfolio_uuid` | `portfolio_id` | UUID FK→portfolio | bind `$3` or **NULL** if blank/unparseable | always (this INSERT) |
| — (literal) | `current_line` | assembly_line enum | `'Architecture'` | always (this INSERT) |
| — (literal) | `current_status` | VARCHAR(50) | `'architecture_complete'` | always (this INSERT) |
| (DB default) | `created_at`,`updated_at`,`metadata` | — | server defaults (`NOW()` / `'{}'::jsonb`) | not in INSERT column list |

ON CONFLICT (id) DO NOTHING → if the row already exists, NONE of the above are overwritten.

#### Table `application` — UPDATE (projection columns; `_build_update_sql`)
| Artifact field (path) | application.column | Type | JSONB? | Default if absent | Write condition |
|---|---|---|---|---|---|
| `input.blueprint_ref` | `architecture_blueprint_ref` | TEXT | no | column unchanged | `blueprint_ref` truthy |
| `blueprint["pattern"]` | `architecture_pattern` | VARCHAR(32) | no | column unchanged | pattern ∈ `_ARCHITECTURE_PATTERNS` |
| `input.decided_at` (ISO→datetime) | `architecture_decided_at` | TIMESTAMPTZ | no | column unchanged | parseable ISO-8601 |
| `target_map["sources"][*].source_app_id` (→ list[UUID]) | `source_app_ids` | UUID[] | no (native list) | column unchanged | `source_ids` non-empty AND all parse as UUID |
| `input.target_repo_url` | `target_repo_url` | TEXT | no | column unchanged | `target_repo_url` truthy |
| — (always) | `updated_at` | TIMESTAMPTZ | no | `datetime.now(utc)` | always when UPDATE runs |

⚠️ The UPDATE runs **only if `projections` is non-empty**. Each column is in the SET clause **only if its key is present** in `projections`. Columns NOT listed here (owned by Discovery/Rationalization/etc.) are never touched.

#### Table `application_lineage` — INSERT (one per lineage edge)
| Artifact field | application_lineage.column | Type | Value | Condition |
|---|---|---|---|---|
| `input.target_app_id` (`target_uuid`) | `target_app_id` | UUID (PK part, FK→application) | bind `$1` | per edge |
| `entry["source_app_id"]` (`source_uuid`) | `source_app_id` | UUID (PK part, FK→application) | bind `$2` | per edge (skipped if unparseable) |
| `target_map["relationship"]` | `relationship` | VARCHAR(32) | bind `$3` | per edge (whitelisted ∈ `_LINEAGE_RELATIONSHIPS`, excl. self-dispositions) |
| — (always) | `created_at` | TIMESTAMPTZ NOT NULL | `datetime.now(utc)` (overrides server default) | per edge |
| (not written) | `retired_at` | TIMESTAMPTZ NULL | left NULL | — |
ON CONFLICT (target_app_id, source_app_id) DO NOTHING.

#### Table `application` — metadata merge (`metadata.compliance` namespace)
| Block key (under metadata.compliance) | Source | Condition |
|---|---|---|
| `source_line` | literal `"Architecture"` | always (when block emitted) |
| `cato_state` = `"in-progress"` | `blueprint["ratified_at"]` truthy | conditional |
| `ea_findings_count` = `len(findings)` | `blueprint["ea_compliance"]["findings"]` is list | conditional |
| `ea_alignment_status` = `"compliant"`/`"needs-review"` | derived from findings emptiness | conditional |
| `security_controls_count` = `len(controls)` | `blueprint["security_architecture"]["controls"]` is list | conditional |
| `last_assessed` = `<now iso>` | added by `_merge_application_metadata.setdefault` | always (when merged) |
| `application.metadata` (column) | JSONB; merged via `COALESCE(metadata,'{}') || $1::jsonb` | only if block ≠ `{source_line}`-only |
| `application.updated_at` | re-stamped to now by the merge UPDATE | when merge runs |

**Tables touched by `persist_architecture_side_effects`:** `application` (INSERT conditional + UPDATE projections + UPDATE metadata), `application_lineage` (INSERT), and `step_execution` (best-effort, via emit helpers — owned by execution-utils spec).

---

## 3. ACTIVITY: `persist_data_side_effects` (line 3618-3682)

### 3.1 Signature
```python
@foundry_activity(config=ActivityConfig(enable_observability=True))
async def persist_data_side_effects(
    input: PersistDataSideEffectsInput,
) -> PersistDataSideEffectsResult:
```

### 3.2 Input dataclass `PersistDataSideEffectsInput` (types.py:1652-1681) — EVERY field
```python
@dataclass
class PersistDataSideEffectsInput:
    target_app_id: str                              # REQUIRED — UUID string
    target_name: str = ""                           # (unused by this activity body — no new-row provisioning in Data line)
    target_portfolio_id: str = ""                   # (unused by this activity body)
    data_architecture_json: str = ""                # raw JSON of merged data-architecture.json (data_pattern, data_domains)
    decomposition_strategy_json: str = ""           # raw JSON of decomposition-strategy.json (clusters[])
    data_architecture_ref: str = ""                 # artifact-repo path to data-architecture.json
    data_migration_plan_ref: str = ""               # artifact-repo path to data-migration-plan.json
    decided_at: str = ""                            # ISO-8601 timestamp the G-DT merge landed
    target_service_id: str = ""                     # SF3 catalog id (S1..S11/"system"/""); empty = leave column unchanged
    execution_context: "StepExecutionContext | None" = None
```
Runs **once per target after G-DT approves**.
⚠️ `target_name`/`target_portfolio_id` are declared (parity with the Architecture input) but the Data activity body does NOT use them — Data never provisions a new application row.

### 3.3 Output dataclass `PersistDataSideEffectsResult` (types.py:1683-1696)
```python
@dataclass
class PersistDataSideEffectsResult:
    target_app_id: str                              # echo
    data_pattern: str = ""                          # str(projections.get("data_pattern",""))
    data_architecture_persisted: bool = False       # "data_architecture_ref" in projections
    cluster_rows_inserted: int = 0                  # count of shared_db_cluster rows actually inserted
    domains_persisted: int = 0                      # len(domains) extracted (NOT necessarily persisted count)
```
⚠️ `domains_persisted = len(domains)` reflects the EXTRACTED count even though domains are written as a single `data_domains` JSONB array; it is the length of the list, not a row count.

### 3.4 Control flow (exact)
```python
exec_id = await emit_code_step_start(input.execution_context, function_name="persist_data_side_effects")   # 3632
try:
    target_uuid = uuid.UUID(input.target_app_id)                          # 3637
except (ValueError, TypeError) as exc:                                     # 3638
    await emit_code_step_complete(exec_id, status=ExecutionStatus.FAILED, error=str(exc))
    raise NonRetryableError(f"Invalid target_app_id: {input.target_app_id!r}") from exc   # 3642

architecture   = _try_parse_json(input.data_architecture_json)            # 3646 -> dict | None
decomposition  = _try_parse_json(input.decomposition_strategy_json)       # 3647 -> dict | None

projections: dict[str, Any] = {}
projections.update(_extract_data_architecture_side_effects(               # ~3650
    architecture,
    architecture_ref=input.data_architecture_ref,
    migration_plan_ref=input.data_migration_plan_ref,
    decided_at=input.decided_at,
))
domains = _extract_data_domains_side_effects(architecture)                # 3658
if domains:                                                                # 3659
    projections["data_domains"] = domains                                  # JSONB list[str]

cluster_rows = _extract_shared_db_cluster_rows(decomposition)             # 3662

if projections or cluster_rows:                                            # 3666 — status marker
    projections["data_current_status"] = "data_complete"                   # 3667

if getattr(input, "target_service_id", "") or "":                          # 3673 — SF3 id stamp (only when truthy)
    projections["target_service_id"] = input.target_service_id             # 3674

if not projections and not cluster_rows:                                   # 3677 — NOTHING-EXTRACTABLE short circuit
    logger.info("persist_data_side_effects: nothing extractable", extra={"target_app_id": input.target_app_id})   # 3678
    await emit_code_step_complete(exec_id, columns_written=[])
    return PersistDataSideEffectsResult(target_app_id=input.target_app_id)

conn = await asyncpg.connect(_db_url())                                    # 3686
try:
    async with conn.transaction():                                          # 3688
        if projections:                                                     # 3690 — UPDATE projections
            sql, params = _build_update_sql(projections)
            params.append(target_uuid)                                      # 3692
            await conn.execute(sql, *params)

        cluster_inserted = 0
        for row in cluster_rows:                                            # 3697 — insert cluster participation rows
            result = await conn.execute(<INSERT shared_db_cluster ... ON CONFLICT (target_app_id, cluster_id) DO NOTHING>,   # 3700
                                        target_uuid, row["cluster_id"], row["role"], row["pattern"], datetime.now(timezone.utc))
            if result.endswith(" 1"):                                       # 3713
                cluster_inserted += 1
finally:
    await conn.close()                                                      # 3716

logger.info("data side-effects persisted", extra={"target_app_id":..., "columns_written": sorted(projections.keys()), "cluster_rows_inserted": cluster_inserted, "domain_count": len(domains)})   # 3719
await emit_code_step_complete(exec_id, columns_written=sorted(projections.keys()))   # ~3729
return PersistDataSideEffectsResult(
    target_app_id=input.target_app_id,
    data_pattern=str(projections.get("data_pattern", "")),
    data_architecture_persisted="data_architecture_ref" in projections,
    cluster_rows_inserted=cluster_inserted,
    domains_persisted=len(domains),
)
```

⚠️ **GOTCHA (`getattr(input, "target_service_id", "") or ""`, line 3673):** the `or ""` is a no-op tautology — the expression is just truthiness of `target_service_id`. `getattr(..., "")` defaults to `""` defensively in case an older `PersistDataSideEffectsInput` (without the field) is unpickled across a deploy. When truthy, `projections["target_service_id"] = input.target_service_id`. Empty string → column left unchanged (legacy waves / system umbrella runs).
⚠️ **GOTCHA (status-marker ordering, line 3666):** `data_current_status="data_complete"` is added to `projections` **before** the nothing-extractable check. So if `cluster_rows` is non-empty even with empty scalar projections, the activity still proceeds and the UPDATE will fire (carrying `data_current_status` + possibly `target_service_id`). Conversely if BOTH `projections` and `cluster_rows` are empty at line 3666, the status marker is never added and the short-circuit returns an empty result.
⚠️ **GOTCHA (transaction):** single `async with conn.transaction()` wraps the UPDATE + all cluster INSERTs. Unlike Architecture, **no metadata merge** and **no new-row provisioning** in the Data line. No try/except around the body (other than `finally: conn.close()`), so any asyncpg error bubbles to the decorator wrapper.

### 3.5 Helper: `_extract_data_architecture_side_effects(architecture, *, architecture_ref, migration_plan_ref, decided_at) -> dict` (line 3498-3538)
- `if architecture_ref:` → `out["data_architecture_ref"] = architecture_ref`.
- `if migration_plan_ref:` → `out["data_migration_plan_ref"] = migration_plan_ref`.
- `if isinstance(architecture, dict):` read `pattern = architecture.get("data_pattern")`; if `isinstance(pattern, str) and pattern in _DATA_PATTERNS` → `out["data_pattern"] = pattern`; elif truthy `pattern` → log "data_pattern not in whitelist", **drop**.
- `if decided_at:` → `out["data_decided_at"] = datetime.fromisoformat(decided_at.replace("Z","+00:00"))` in try/except `(TypeError, ValueError)`; on failure log "data decided_at not ISO-8601" and **omit**.

`_DATA_PATTERNS` (line 3478-3487) = `frozenset({"database-per-service", "strangler-fig", "db-facade", "dedicated", "shared-read-only"})`.

### 3.6 Helper: `_extract_data_domains_side_effects(architecture) -> list[str]` (line 3539-3560)
- `if not isinstance(architecture, dict)` → `[]`.
- `domains = architecture.get("data_domains")`; if not a list → `[]`.
- Keep only non-empty str entries; preserve order; return list (possibly empty). Caller only adds `projections["data_domains"]` if the list is **truthy** (non-empty); a target owning no domains never writes the `data_domains` column.

### 3.7 Helper: `_extract_shared_db_cluster_rows(decomposition) -> list[dict]` (line 3561-3617)
Expected input shape: `{"clusters": [{"cluster_id": str, "role": str, "pattern": str}, ...]}`.
- `if not isinstance(decomposition, dict)` → `[]`.
- `clusters = decomposition.get("clusters")`; if not a list → `[]`.
- Per `entry`: skip non-dict; read `cluster_id`/`role`/`pattern`.
  - skip if `cluster_id` not a non-empty str (no log).
  - if `role` not a str OR `role not in _CLUSTER_ROLES` → log "shared_db_cluster row skipped — invalid role" and **skip the whole row**.
  - if `pattern` not a str OR `pattern not in _DATA_PATTERNS` → log "shared_db_cluster row skipped — invalid pattern" and **skip the whole row**.
  - else append `{"cluster_id": ..., "role": ..., "pattern": ...}`.

`_CLUSTER_ROLES` (line 3488-3497) = `frozenset({"read", "write", "owner", "both"})`.
`_DATA_PATTERNS` (same frozenset as §3.5) gates the per-cluster `pattern`.
⚠️ Both `role` and `pattern` are independently whitelisted; either failing drops the row. `cluster_id` malformed drops silently (no warning).

### 3.8 SQL written by `persist_data_side_effects`

**(A) UPDATE projections** (line 3690-3692, only when `projections` non-empty): SQL from `_build_update_sql` (§1.4).

**(B) INSERT shared_db_cluster row** (line 3700-3704, per cluster row):
```sql
INSERT INTO shared_db_cluster (target_app_id, cluster_id, role, pattern, created_at)
VALUES ($1, $2, $3, $4, $5)
ON CONFLICT (target_app_id, cluster_id) DO NOTHING
```
Binds: `$1=target_uuid`, `$2=row["cluster_id"]`, `$3=row["role"]`, `$4=row["pattern"]`, `$5=datetime.now(timezone.utc)`. ⚠️ ON CONFLICT targets composite PK `(target_app_id, cluster_id)` (backed by `shared_db_cluster_pkey`, migration 031). `result.endswith(" 1")` → real insert; counts into `cluster_inserted`.

### 3.9 Column-by-column mapping — `persist_data_side_effects`

#### Table `application` — UPDATE (projection columns; `_build_update_sql`)
| Artifact field (path) | application.column | Type | JSONB? | Default if absent | Write condition |
|---|---|---|---|---|---|
| `input.data_architecture_ref` | `data_architecture_ref` | TEXT | no | column unchanged | ref truthy |
| `input.data_migration_plan_ref` | `data_migration_plan_ref` | TEXT | no | column unchanged | ref truthy |
| `architecture["data_pattern"]` | `data_pattern` | VARCHAR(32) | no | column unchanged | pattern ∈ `_DATA_PATTERNS` |
| `input.decided_at` (ISO→datetime) | `data_decided_at` | TIMESTAMPTZ | no | column unchanged | parseable ISO-8601 |
| `architecture["data_domains"]` (list[str]) | `data_domains` | JSONB | **yes** (json.dumps) | column unchanged | domains list non-empty |
| literal `"data_complete"` | `data_current_status` | VARCHAR(64) | no | column unchanged | `projections OR cluster_rows` truthy |
| `input.target_service_id` | `target_service_id` | VARCHAR(64) | no | column unchanged | `target_service_id` truthy |
| — (always) | `updated_at` | TIMESTAMPTZ | no | `datetime.now(utc)` | always when UPDATE runs |

⚠️ UPDATE runs only if `projections` non-empty. Each column set only when its key present. Columns owned by Architecture / Rationalization / Discovery / Modernization are NEVER touched here.

#### Table `shared_db_cluster` — INSERT (one per valid cluster row)
| Artifact field | shared_db_cluster.column | Type | Value | Condition |
|---|---|---|---|---|
| `input.target_app_id` (`target_uuid`) | `target_app_id` | UUID (PK part, FK→application ON DELETE CASCADE) | bind `$1` | per row |
| `clusters[*].cluster_id` | `cluster_id` | VARCHAR(128) (PK part) | bind `$2` | per row (non-empty str) |
| `clusters[*].role` | `role` | VARCHAR(16) | bind `$3` | per row (∈ `_CLUSTER_ROLES`) |
| `clusters[*].pattern` | `pattern` | VARCHAR(32) | bind `$4` | per row (∈ `_DATA_PATTERNS`) |
| — (always) | `created_at` | TIMESTAMPTZ NOT NULL | `datetime.now(utc)` (overrides server default) | per row |
| (not written) | `retired_at` | TIMESTAMPTZ NULL | left NULL | — |
ON CONFLICT (target_app_id, cluster_id) DO NOTHING.

**Tables touched by `persist_data_side_effects`:** `application` (UPDATE projections only — no INSERT, no metadata merge), `shared_db_cluster` (INSERT), and `step_execution` (best-effort via emit helpers).

---

## 4. Cross-cutting GOTCHAS / idempotency / error semantics (both activities)

1. **Single per-activity connection, no pool:** `asyncpg.connect(_db_url())` opened, all writes in one `async with conn.transaction()`, `finally: await conn.close()`. A failure mid-transaction rolls back ALL writes (atomic). Connection close is in `finally` so it always runs.
2. **Best-effort vs hard-fail boundary:** parsing (`_try_parse_json`) and extraction are best-effort — malformed artifacts produce empty projections and the activity returns an empty result (the "nothing extractable" branch) **without raising**. This mirrors Discovery/Rationalization (per the docstrings inside `persist_architecture_side_effects` 3253+ / `persist_data_side_effects` 3618+). The ONLY hard-fail is a non-UUID `target_app_id` → `NonRetryableError`.
3. **Idempotency:** UPDATEs are last-writer-wins on identical scalar inputs; satellite-row INSERTs (`application_lineage` / `shared_db_cluster`) are `ON CONFLICT (<composite PK>) DO NOTHING`; the new-application INSERT is `ON CONFLICT (id) DO NOTHING`; the metadata merge is `||` (re-merging the same payload only refreshes `last_assessed`). ⇒ Temporal retries (from the decorator's retryable classification) are safe to re-run.
4. **`result.endswith(" 1")` row-count trick:** asyncpg `Connection.execute` returns the command tag string (e.g. `"INSERT 0 1"` / `"INSERT 0 0"` / `"UPDATE 1"`). Both activities count only `endswith(" 1")` for the satellite INSERT loops — distinguishing a fresh insert from an ON CONFLICT skip. ⚠️ This is fragile: it relies on asyncpg returning exactly `"INSERT 0 1"` for a single-row insert. A multi-row insert (not used here) would break the heuristic.
5. **`datetime.now(timezone.utc)` is evaluated multiple times per activity** (per lineage/cluster row `created_at`, once for the UPDATE `updated_at`, again inside `_merge_application_metadata`). Each call gets a fresh tz-aware UTC timestamp — they will differ by microseconds. Reproductions must use tz-aware UTC (asyncpg binds these to `timestamptz`).
6. **`columns_written` for the Layer B record:** Architecture = `sorted(projections.keys())` then `.append("metadata.compliance")` when compliance was merged (so `"metadata.compliance"` is the LAST element, not alpha-sorted). Data = `sorted(projections.keys())` (no metadata token). These strings are stored in `step_execution.payload.columns_written` and are observability-only.
7. **`emit_code_step_*` never blocks the activity:** if `execution_context is None`, `exec_id` is `None` and both emit calls are effectively no-ops; if the DB write for the record fails, it's swallowed (logged warning). The activity's success/failure is decided solely by the projection transaction + the uuid parse.
