# Phase 4 — Activity Group: Git Operations

**Source files (rebuild these EXACTLY):**

- `temporal/olympus_workflows/activities/git_operations.py` (600 lines) — `read_artifact`, `write_artifact`, `write_artifacts_batch`, `create_pr`, `merge_pr`, `reconcile_and_merge_pr`, `provision_target_repo`, plus `_emit_git_start` / `_emit_git_complete` / `_git_service_config` / `_build_git_service` helpers.
- `temporal/olympus_workflows/activities/line_transitions.py` — `fetch_application_source_repos` (L220), `create_target_app_and_repo` (L7536), `terminate_source_app_workflows` (L8168), plus the helpers `_db_url`, `_lineage_relationship_for`, `_build_source_artifacts_index`, `_target_source_artifacts_index_path`, `_fetch_source_app_names_and_repo`, `_write_target_source_artifacts_index`, `_is_already_exists_error`, `_cancel_running_source_line_workflows`, `_set_application_consolidated_status`, the disposition frozensets, and the source-artifacts-index constants.
- `olympus-api/src/services/git_service.py` (866 lines) — the **`GitService`** class that ALL of the above delegate to. **This is where the entire branch/commit/PR/merge sequence and mergeable_state polling lives.** Rebuild it verbatim.
- `olympus-contracts/olympus_contracts/git_types.py` — `GitServiceConfig`, `PRResult`, `FileReadResult`, `CommitResult`, `GitServiceError`, `BRANCH_PATTERN`.
- `olympus-contracts/olympus_contracts/errors.py` — `MergeConflict`, `MergeDivergenceUnresolved`, `MergeBranchProtectionRejected`.
- `temporal/olympus_workflows/retry_policies.py` — `GIT_MERGE_RETRY_POLICY` (non-retryable list).
- `temporal/olympus_workflows/utils/execution.py` — `emit_execution_record` / `update_execution_record` / `emit_code_step_start` / `emit_code_step_complete` / `resolve_input_artifacts` / `StepArtifactRef` / `StepKind` / `ExecutionStatus` / `EmitExecutionRecordInput`. **This is the `step_execution` projection every git activity writes telemetry into.**

---

## PREAMBLE 1 — THE `@foundry_activity` DECORATOR (applies to EVERY activity below)

Source: `foundry_temporal/activities.py` (the temp-extracted package). EVERY activity in this group is decorated `@foundry_activity(config=ActivityConfig(enable_observability=True))` — NOT plain `@activity.defn`. Reproducing with plain `@activity.defn` LOSES error-wrapping + retryability classification and breaks Temporal retry behavior.

`foundry_activity(config=None, name=None, **activity_kwargs)` returns a decorator that:

1. Resolves `activity_config = config or ActivityConfig()`.
2. Applies `@activity.defn(name=name, **activity_kwargs)` over an `@wraps(func)` async `wrapper`.
3. On call: `activity_name = name or func.__name__`; obtains a logger via `get_logger()`.
4. If `activity_config.enable_observability` (TRUE for all git activities): logs `f"Activity {activity_name} starting"` with `extra={"inputs": args if log_inputs else None}`. (`log_inputs` defaults FALSE → inputs logged as None.)
5. `result = await func(*args, **kwargs)`.
6. On success: if observability, logs `f"Activity {activity_name} completed"` with `extra={"outputs": result if log_outputs else None}` (`log_outputs` default FALSE).
7. **On `except Exception as error`:** if observability, logs `f"Activity {activity_name} failed: {error}"`. Then, if `activity_config.enable_error_wrapping` (default TRUE):
   - `if isinstance(error, (WorkflowError, ApplicationError)): raise` — re-raises UNWRAPPED. **`WorkflowError` is the base of `NonRetryableError` and `RetryableError`** (the foundry-temporal error hierarchy), so anything already typed (e.g. `NonRetryableError` raised inside `create_target_app_and_repo`, OR `MergeConflict`/`MergeDivergenceUnresolved`/`MergeBranchProtectionRejected` if they subclass `ApplicationError` — they do NOT, see GOTCHA below) passes through untouched.
   - `elif _is_retryable_error(error): raise RetryableError(f"Retryable error in {activity_name}: {error}") from error`
   - `else: raise NonRetryableError(f"Non-retryable error in {activity_name}: {error}") from error`
   - If `enable_error_wrapping` is False: bare `raise`.

`_is_retryable_error(error)`: lowercases `str(type(error))` and returns True if it contains ANY of: `timeout`, `connection`, `network`, `temporary`, `unavailable`, `overload`, `busy`, `throttle`, `rate_limit`. **Pattern-matches the TYPE name string, not the message.** A `GitServiceError("...timeout...")` would NOT match (its type name is `GitServiceError`); a `ConnectionError` WOULD (type name contains `connection`).

`ActivityConfig` dataclass fields (all defaults): `retry_policy=None`, `start_to_close_timeout=None`, `schedule_to_close_timeout=None`, `schedule_to_start_timeout=None`, `heartbeat_timeout=None`, `enable_observability=True`, `enable_error_wrapping=True`, `log_inputs=False`, `log_outputs=False`. **The decorator does NOT set the retry policy on the Temporal activity** — `retry_policy` in `ActivityConfig` is unused by `foundry_activity` (it never reads it). Retry policy is supplied by the CALLING WORKFLOW at `execute_activity(..., retry_policy=...)`. Git I/O activities are called with `TRANSIENT_RETRY_POLICY` (= `HTTP_RETRY_POLICY`); `reconcile_and_merge_pr` is called with `RETRY_POLICIES["git_merge"]` = `GIT_MERGE_RETRY_POLICY`.

⚠️ **GOTCHA (error-class wrapping interaction — CRITICAL for merge typing):** `MergeConflict` / `MergeDivergenceUnresolved` / `MergeBranchProtectionRejected` all subclass `GitServiceError(Exception)` — they are **NOT** `WorkflowError` and **NOT** `ApplicationError`. They are also **NOT** name-matched by `_is_retryable_error` (type names contain none of the retryable patterns). Therefore the decorator wraps them as `NonRetryableError(f"Non-retryable error in {activity_name}: <merge error>")`. **The original class name is LOST inside the message** by the time Temporal sees it for `merge_pr`. BUT `reconcile_and_merge_pr` is special — it catches the exception itself, records `failure_type = type(exc).__name__` for telemetry, then re-raises the ORIGINAL exception. The original `MergeConflict`/etc. then reaches the decorator and IS wrapped into `NonRetryableError`. The non-retryable classification therefore comes from TWO independent mechanisms that must AGREE: (a) the decorator wraps them as `NonRetryableError` regardless, and (b) `GIT_MERGE_RETRY_POLICY.non_retryable_error_types = ["MergeConflict", "MergeDivergenceUnresolved", "MergeBranchProtectionRejected"]` lists them by name. **Mechanism (b) matters because Temporal matches `non_retryable_error_types` against the error type name; once wrapped into `NonRetryableError`, `NonRetryableError` itself must be treated as non-retryable by Temporal.** A faithful rebuild MUST keep `NonRetryableError` non-retryable in Temporal AND keep the three names in the policy list. If you rebuild with plain `@activity.defn`, the raw `MergeConflict` reaches Temporal and ONLY mechanism (b) applies — so you MUST then keep the three class names in `non_retryable_error_types` or merges will retry forever.

⚠️ **GOTCHA (`activity.info()` in unit tests):** Several activities call `activity.info().workflow_id` / `.attempt`. Outside the Temporal runtime this raises; every call site wraps it in `try/except Exception` and falls back to `workflow_id=""`, `attempt=1`. Reproduce this fallback or unit-construction breaks.

---

## PREAMBLE 2 — THE `step_execution` PROJECTION (telemetry written by every git activity)

Every git activity that receives a non-None `execution_context: StepExecutionContext` emits ONE `step_execution` row at start (status `running`) and updates it to terminal state at the end. **This is best-effort: `emit_execution_record` returns `None` on ANY DB failure (caught + warning-logged), and `update_execution_record` swallows exceptions. A telemetry failure NEVER fails the activity.** If `execution_context is None` (legacy/unit callers), emission is skipped entirely (`_emit_git_start` returns `None`, `_emit_git_complete` no-ops on `None`).

### `StepExecutionContext` (dataclass, `types.py:531`)
| field | type | default |
|---|---|---|
| `portfolio_id` | `str` | (required) — only strictly-required field |
| `line_id` | `str` | (required) |
| `step_id` | `str` | (required) |
| `app_id` | `str` | `""` (nullable for wave-scoped records) |
| `wave_id` | `str` | `""` (nullable for per-app records) |
| `input_artifact_paths` | `list[str]` | `field(default_factory=list)` |
| `gate_id` | `str` | `""` |

### `StepArtifactRef` (frozen dataclass, `execution.py:82`)
Fields: `repo: str`, `ref: str`, `path: str`, `content_hash: str | None = None`. `.to_dict()` → `{"repo","ref","path"}` plus `"content_hash"` ONLY when not None.

### `_emit_git_start(ctx, *, repo, operation, branch="", paths=None)` → `execution_id | None`
- If `ctx is None`: return `None`.
- Resolve `workflow_id`/`attempt` from `activity.info()` (fallback `""`/`1`).
- `input_artifacts = resolve_input_artifacts(ctx.input_artifact_paths, repo=repo, ref=branch or "main")` — builds `StepArtifactRef(repo=repo, ref=(branch or "main"), path=<decl with {placeholder} substituted>)` per declaration; no substitutions dict here so placeholders pass through literally.
- `payload = {"operation": operation, "repo": repo, "branch": branch, "paths": paths or []}`.
- Calls `emit_execution_record(EmitExecutionRecordInput(portfolio_id=ctx.portfolio_id, line_id=ctx.line_id, step_id=ctx.step_id, step_kind=StepKind.GIT, workflow_id=workflow_id, app_id=ctx.app_id or None, wave_id=ctx.wave_id or None, attempt=attempt, input_artifacts=input_artifacts, payload=payload, status=ExecutionStatus.RUNNING))`.

### `emit_execution_record(input)` → `uuid.UUID | None` — **`step_execution` INSERT projection**
Generates `execution_id = uuid.uuid4()`; `started_at = input.started_at or now(utc)`. Parses `app_id`, `wave_id`, `portfolio_id`, `agent_task_id`, `gate_id` via `_parse_uuid` (returns `None` for `None`/`""`/unparseable). **If `portfolio_uuid is None`: warning-log + return `None` (no row).** Else INSERT (best-effort try/except → `None` on failure):

```sql
INSERT INTO step_execution (
    execution_id, app_id, wave_id, portfolio_id,
    line_id, step_id, step_kind, status,
    started_at, attempt, input_artifacts, payload,
    workflow_id, agent_task_id, gate_id
) VALUES ($1,$2,$3,$4, $5,$6,$7,$8, $9,$10,$11::jsonb,$12::jsonb, $13,$14,$15)
```

| param | source | notes |
|---|---|---|
| `$1 execution_id` | `uuid.uuid4()` | PK |
| `$2 app_id` | `_parse_uuid(input.app_id)` | nullable |
| `$3 wave_id` | `_parse_uuid(input.wave_id)` | nullable |
| `$4 portfolio_id` | `_parse_uuid(input.portfolio_id)` | NOT NULL gate above |
| `$5 line_id` | `input.line_id` | |
| `$6 step_id` | `input.step_id` | |
| `$7 step_kind` | `input.step_kind.value` | `"git"` for these activities |
| `$8 status` | `input.status.value` | `"running"` at start |
| `$9 started_at` | `started_at` | |
| `$10 attempt` | `input.attempt` | Temporal attempt or 1 |
| `$11 input_artifacts` | `json.dumps([a.to_dict() for a in input.input_artifacts])` | jsonb array |
| `$12 payload` | `json.dumps(input.payload or {})` | jsonb |
| `$13 workflow_id` | `input.workflow_id` | |
| `$14 agent_task_id` | `_parse_uuid(input.agent_task_id)` | NULL for git |
| `$15 gate_id` | `_parse_uuid(input.gate_id)` | NULL for git |

### `_emit_git_complete(execution_id, *, output_paths=None, repo="", commit_sha="", pr_number=None, pr_url="", branch="", status=COMPLETED, error=None)`
- If `execution_id is None`: return.
- `payload_merge = {}`; add `"commit_sha"` if `commit_sha` truthy; add `"pr_number"` if `pr_number is not None`; add `"pr_url"` if `pr_url` truthy.
- `output_artifacts = [StepArtifactRef(repo=repo, ref=(branch or commit_sha or "main"), path=p) for p in output_paths]` **only if `output_paths and repo`** else `None`.
- Calls `update_execution_record(execution_id, status=status, output_artifacts=output_artifacts, payload_merge=(payload_merge or None), last_error=error)`.

### `update_execution_record(execution_id, *, status, completed_at=None, output_artifacts=None, payload_merge=None, last_error=None)` — **`step_execution` UPDATE projection**
- If `execution_id is None`: return. `completed = completed_at or now(utc)`. `out_artifacts = [a.to_dict() for a in output_artifacts] if output_artifacts else None`. Best-effort try/except.

```sql
UPDATE step_execution
   SET status = $2,
       completed_at = $3,
       duration_ms = EXTRACT(EPOCH FROM ($3 - started_at)) * 1000,
       output_artifacts = COALESCE($4::jsonb, output_artifacts),
       payload = payload || COALESCE($5::jsonb, '{}'::jsonb),
       last_error = COALESCE($6, last_error)
 WHERE execution_id = $1
```

| param | source | notes |
|---|---|---|
| `$1 execution_id` | arg | |
| `$2 status` | `status.value` | e.g. `"completed"` / `"failed"` |
| `$3 completed_at` | `completed` | also drives `duration_ms` |
| `duration_ms` | `EXTRACT(EPOCH FROM ($3 - started_at)) * 1000` | server-computed |
| `$4 output_artifacts` | `json.dumps(out_artifacts)` or `None` | **COALESCE: only overwritten if non-NULL** |
| `$5 payload` | `json.dumps(payload_merge)` or `None` | **`payload || COALESCE($5,'{}')` — SHALLOW JSONB MERGE, never replaces** |
| `$6 last_error` | `last_error` | **COALESCE: only set if non-NULL** |

⚠️ **GOTCHA (payload merge is shallow `||`):** `payload_merge` keys (`commit_sha`/`pr_number`/`pr_url`, and for `reconcile_and_merge_pr` the merge_sha lands via `commit_sha`) are merged into the EXISTING payload with PostgreSQL `||`. A top-level key in the merge replaces the same top-level key but does NOT deep-merge nested objects. The `operation`/`repo`/`branch`/`paths` keys written at start survive.

⚠️ **GOTCHA (separate connections, no transaction across start/complete):** emit and update each open + close their OWN `asyncpg.connect(_db_url())`. There is NO transaction spanning them. If the activity crashes between them, the row stays `running` forever (the stepper UI treats it as stuck). `_db_url()` (in `execution.py`) reads `DATABASE_HOST`(localhost)/`DATABASE_PORT`(5432)/`DATABASE_USER`(olympus)/`DATABASE_PASSWORD`(olympus)/`DATABASE_NAME`(olympus) → `postgresql://user:password@host:port/db`.

### Code-step variant (used by `create_target_app_and_repo`'s downstream-only; NOT by the git_operations.py activities, but listed for completeness since the file imports them)
`emit_code_step_start(ctx, *, function_name, columns_writable=None)` → emits with `step_kind=StepKind.CODE`, `payload={"function": function_name}` (+`"columns_written"` if `columns_writable`). `emit_code_step_complete(execution_id, *, status=COMPLETED, columns_written=None, error=None)` → `payload_merge={"columns_written": columns_written}` if provided. (Note: `create_target_app_and_repo` itself does NOT call these — it has no execution_context param. They are used by sibling persist activities in `line_transitions.py` not in this group's scope.)

---

## PREAMBLE 3 — `GitService` (the GitHub-API engine all activities delegate to)

`olympus-api/src/services/git_service.py`. Imports PyGithub (`from github import Auth, Github, GithubException`). **Imported lazily inside activities** (`from src.git_service import GitService` with fallback `from olympus_api.services.git_service import ...`) because PyGithub is only present in the worker container at runtime. Stateless — one instance per activity call.

### Construction: `GitService(config: GitServiceConfig)`
`GitServiceConfig` (`git_types.py`): `token: str`, `repo: str`, `base_url: str = "https://api.github.com"`.
1. `auth = Auth.Token(config.token)`; `kwargs = {"auth": auth}`; if `base_url and base_url != "https://api.github.com"`: `kwargs["base_url"] = base_url`. `self._github = Github(**kwargs)`.
2. **Repo-slug normalization** (must reproduce EXACTLY): start with `config.repo`. For each prefix in `("https://","http://")`: if it startswith, `repo_slug = "/".join(repo_slug.split("/")[3:])` (strips scheme+host, e.g. `https://github.com/org/repo` → `org/repo`) then break. `repo_slug = repo_slug.strip("/")`. If endswith `.git`: drop the last 4 chars.
3. `self._repo = self._github.get_repo(repo_slug)`. On `GithubException`: status 404 → `GitServiceError("Repository '<slug>' not found or token lacks access")`; else → `GitServiceError("Cannot connect to repository '<slug>': <exc.data>")`.

### `_UNMERGEABLE_STATE_TO_ERROR` (module-level dict) — THE mergeable_state → error-class map
```python
{"dirty": MergeConflict, "behind": MergeDivergenceUnresolved, "blocked": MergeBranchProtectionRejected}
```
Anything NOT in this map (notably `"clean"`, `"unknown"`, `"draft"`) is handled separately (see polling + merge below).

### Mergeability polling constants + `_await_mergeability(pr_number)`
GitHub computes `mergeable`/`mergeable_state` ASYNCHRONOUSLY; a fresh PR returns `mergeable=None`, `mergeable_state="unknown"`. Treating that as terminal caused the 2026-05-05 Mezzanine bug (discovery PRs classified non-mergeable). Constants:
- `_MERGEABILITY_POLL_ATTEMPTS = 8`
- `_MERGEABILITY_POLL_DELAY_SECONDS = 1.5`

`_await_mergeability(pr_number)`:
1. `pr = self._repo.get_pull(pr_number)`; `GithubException` → `GitServiceError("PR #<n> not found: <data>")`.
2. **If `pr.merged`: return `pr` immediately** (short-circuit — no wait).
3. Loop `for attempt in range(8)`: `state = pr.mergeable_state or "unknown"`; if `pr.mergeable is not None and state != "unknown"`: return `pr`. Else log + `time.sleep(1.5)`, re-fetch `pr = self._repo.get_pull(pr_number)` (re-fetch failure → `GitServiceError("PR #<n> not found during mergeability poll: <data>")`); if `pr.merged`: return `pr`.
4. After 8 attempts: return last `pr` (caller raises on the real state). ⚠️ **`time.sleep` is BLOCKING** — runs on a worker thread inside the activity; acceptable because activities run in their own threads, but a rebuild must keep up to `8 × 1.5s = 12s` of blocking tolerance in the activity's `start_to_close_timeout`.

### `create_pull_request(source_branch, target_branch, title, body, reviewers=None, labels=None)` → `PRResult`
1. Try `pr = self._repo.create_pull(title=title, body=body, head=source_branch, base=target_branch)`; `created=True`.
2. `except GithubException as exc`: if `_is_pr_already_exists(exc)` → `existing = self._find_open_pr(source_branch, target_branch)`; if `existing is None` → `GitServiceError("Failed to create PR: <data>")`; else try `existing.edit(title=title, body=body)` (swallow `GithubException` with warning), `pr = existing`, `created=False`. Else (not already-exists) → `GitServiceError("Failed to create PR: <data>")`.
3. If `reviewers`: try `pr.create_review_request(reviewers=reviewers)`; swallow `GithubException` (warning).
4. If `labels`: try `pr.set_labels(*labels)`; swallow `GithubException` (warning).
5. Return `PRResult(pr_number=pr.number, pr_url=pr.html_url, source_branch=source_branch, target_branch=target_branch)`.

`_is_pr_already_exists(exc)`: `exc.status == 422` AND `exc.data["errors"]` is a list AND some `err["message"]` (str) contains `"already exists"` (case-insensitive). ⚠️ Idempotency hinges on this: the UI Retry path re-runs workflows that left a PR open → 422 → reuse existing PR + refresh title/body/labels.

`_find_open_pr(source_branch, target_branch)`: `head_spec = f"{self._repo.owner.login}:{source_branch}"`; `prs = self._repo.get_pulls(state="open", head=head_spec, base=target_branch)` (swallow `GithubException` → `None`); return first PR or `None`. ⚠️ GitHub's `head` filter REQUIRES `owner:branch` form.

### `merge_pull_request(pr_number, merge_method="merge")` → `dict`
1. `pr = self._await_mergeability(pr_number)`.
2. **If `pr.merged`: return `{"merged": True, "merge_sha": pr.merge_commit_sha or ""}`** (idempotent).
3. **If `not pr.mergeable`:** `state = pr.mergeable_state or "unknown"`; `error_cls = _UNMERGEABLE_STATE_TO_ERROR.get(state, GitServiceError)`; `raise error_cls(f"PR #{pr_number} is not mergeable (state: {state})")`. → `dirty`→`MergeConflict`, `behind`→`MergeDivergenceUnresolved`, `blocked`→`MergeBranchProtectionRejected`, anything else→`GitServiceError`.
4. Else try `result = pr.merge(merge_method=merge_method)`; `GithubException` → `GitServiceError("Failed to merge PR #<n>: <data>")`.
5. Return `{"merged": result.merged, "merge_sha": result.sha or ""}`.

### `rebase_pr_onto_base(pr_number)` → `RebaseResult(rebase_ran: bool, final_mergeable_state: str)`
1. `pr = self._repo.get_pull(pr_number)`; `GithubException` → `GitServiceError("PR #<n> not found: <data>")`.
2. `rebase_ran=False`; try `rebase_ran = bool(pr.update_branch())` (PUT /pulls/{n}/update-branch, HTTP 202). `except GithubException`: `message = exc.data.get("message","")`; if `exc.status == 422 and "up to date" in message.lower()`: `rebase_ran=False` (benign no-op). Else → `GitServiceError("Failed to rebase PR #<n>: <data>")`.
3. Re-fetch `refreshed = self._repo.get_pull(pr_number)` (failure → `GitServiceError("Failed to re-read PR #<n> after rebase: <data>")`); `final_state = refreshed.mergeable_state or "unknown"`.
4. Return `RebaseResult(rebase_ran, final_state)`.

### `reconcile_and_merge(pr_number, merge_method="merge")` → `ReconcileMergeResult` — **THE rebase-then-merge orchestration**
`ReconcileMergeResult(merged: bool, merge_sha: str, initial_mergeable_state: str, rebase_performed: bool, final_mergeable_state: str)`.
1. `pr = self._await_mergeability(pr_number)`.
2. **If `pr.merged`:** return `ReconcileMergeResult(merged=True, merge_sha=pr.merge_commit_sha or "", initial_mergeable_state=pr.mergeable_state or "unknown", rebase_performed=False, final_mergeable_state=pr.mergeable_state or "unknown")` (idempotent no-op).
3. `initial_state = pr.mergeable_state or "unknown"`; `rebase_performed=False`; `final_state=initial_state`.
4. **If `initial_state == "dirty"`: `raise MergeConflict("PR #<n> is not mergeable (state: dirty)")`** (BEFORE any rebase).
5. **If `initial_state == "blocked"`: `raise MergeBranchProtectionRejected("PR #<n> is not mergeable (state: blocked)")`.**
6. **If `initial_state == "behind"`:** `rebase = self.rebase_pr_onto_base(pr_number)`; `rebase_performed = rebase.rebase_ran`; `final_state = rebase.final_mergeable_state`. Then:
   - `if final_state == "behind": raise MergeDivergenceUnresolved("PR #<n> still behind base after rebase (state: behind)")` (racing merge re-diverged — RETRYABLE at workflow level via reviewer signal, but on `non_retryable_error_types` so Temporal does NOT auto-retry).
   - `if final_state == "dirty": raise MergeConflict("PR #<n> conflicts after rebase (state: dirty)")`.
   - `if final_state == "blocked": raise MergeBranchProtectionRejected("PR #<n> blocked after rebase (state: blocked)")`.
7. Fall through (state should be `clean`, or optimistic `unknown`): `merge_result = self.merge_pull_request(pr_number, merge_method=merge_method)` — this re-polls and does the final unmergeable classification + POST.
8. Return `ReconcileMergeResult(merged=merge_result["merged"], merge_sha=merge_result.get("merge_sha",""), initial_mergeable_state=initial_state, rebase_performed=rebase_performed, final_mergeable_state=final_state)`.

⚠️ **GOTCHA (`final_mergeable_state` on the happy path is the PRE-merge state, NOT `clean` guaranteed):** for `initial_state == "clean"`, no rebase runs so `final_state` stays `"clean"`. For `initial_state == "behind"` resolved to clean, `final_state` is what `rebase_pr_onto_base` saw (`refreshed.mergeable_state`, typically `"clean"`). For `initial_state == "unknown"`, `final_state == "unknown"` even on a successful merge. The telemetry field can legitimately be `"unknown"`.

### `provision_repository(config, repo_slug, initial_readme="", private=True)` → `(html_url: str, created: bool)` — **STATICMETHOD**
1. If `"/" not in repo_slug`: `GitServiceError("repo_slug must be 'owner/name', got <slug>")`. `owner, name = repo_slug.split("/", 1)`.
2. Build a fresh `Github(**kwargs)` (same auth + base_url rule as ctor — does NOT reuse `self._github`; it's static).
3. **Short-circuit:** try `existing = gh.get_repo(repo_slug)` → return `(existing.html_url, False)`. `except GithubException`: if `status != 404` → `GitServiceError("Cannot check repository '<slug>': <data>")`; (404 falls through to create).
4. Resolve target: try `org = gh.get_organization(owner)`, `target = org`. `except GithubException`: if `status != 404` → `GitServiceError("Cannot resolve owner '<owner>': <data>")`; else `target = gh.get_user()` (owner is a user, not an org).
5. try `new_repo = target.create_repo(name=name, private=private, auto_init=True, description="Olympus modernization target repo — provisioned by Architecture's target-state-mapping step.")`; `GithubException` → `GitServiceError("Failed to create repository '<slug>': <data>")`.
6. If `initial_readme`: try get `README.md` on `main`, take `.sha` if a single file (not list/None), then `new_repo.update_file(path="README.md", message="Olympus: initial target-repo README", content=initial_readme, sha=sha, branch="main")`. Swallow `GithubException` (warning, continue).
7. Return `(new_repo.html_url, True)`.

### File ops (used by `read_artifact` / `write_artifact` / `write_artifacts_batch`, and by `_write_target_source_artifacts_index`)
- `create_branch(branch_name, base_branch="main")` → `base_sha`: get base ref (404-class → `GitServiceError("Base branch '<b>' not found: <data>")`); `create_git_ref(ref=f"refs/heads/{branch_name}", sha=base_sha)`; 422 → `GitServiceError("Branch '<b>' already exists")`, else → `GitServiceError("Failed to create branch: <data>")`.
- `_ensure_branch(branch, base_branch="main")`: get `heads/{branch}` → return if exists; on non-404 `GithubException` re-raise; on 404 create from base ref; **422 on create → return (race: branch created concurrently)**; other → `GitServiceError`.
- `commit_file(branch, path, content, commit_message)` → `CommitResult`: if `branch != "main"`: `_ensure_branch(branch)`. Try `get_contents(path, ref=branch)` (if list → `GitServiceError("Path '<p>' is a directory, not a file")`), then `update_file(path,message,content,sha=existing.sha,branch)`. `except GithubException`: 404 → `create_file(path,message,content,branch)`; else → `GitServiceError("Failed to commit file: <data>")`. `commit_sha = result["commit"].sha`. Return `CommitResult(commit_sha, path, branch)`.
- `commit_files(branch, files: list[(path,content)], commit_message)` → `CommitResult` (**one commit, N files**): empty `files` → `GitServiceError("commit_files requires at least one file")`. If `branch != "main"`: `_ensure_branch(branch)`. Then walk blob+tree+commit+ref: get `heads/{branch}` ref → `base_commit = get_git_commit(ref.sha)` → `base_tree = base_commit.tree`; for each `(path,content)`: `blob = create_git_blob(content,"utf-8")`, append `InputGitTreeElement(path=path, mode="100644", type="blob", sha=blob.sha)`; `new_tree = create_git_tree(elements, base_tree=base_tree)`; `new_commit = create_git_commit(message=commit_message, tree=new_tree, parents=[base_commit])`; `base_ref.edit(new_commit.sha)`. Any `GithubException` → `GitServiceError("Batch commit on '<b>' failed: <data>")`. Return `CommitResult(new_commit.sha, files[0][0], branch)`.
- `read_file(path, branch="main", commit_sha="")` → `FileReadResult`: `ref = commit_sha or branch`; `get_contents(path, ref=ref)` (`GithubException` → `GitServiceError("File '<p>' not found on ref '<ref>': <data>")`; list → directory error). `decoded = contents.decoded_content.decode("utf-8")`. `ref_sha = commit_sha` if given else `get_branch(branch).commit.sha`. Return `FileReadResult(decoded, ref_sha, path)`.

### Other helpers (not core to this group but in the class)
- `validate_repo_access(*, require_push=True)`: reads `self._repo.permissions`; `None` → pass; `not pull` → write-access error; `require_push and not push` → push error; 404/other → `GitServiceError`.
- `build_branch_name(line, app_id, step)` (static) → `f"olympus/{line}/{app_id}/{step}"`.
- `parse_branch_name(branch)` (static) → `BRANCH_PATTERN.match(branch).groupdict()` or `None`. `BRANCH_PATTERN = ^olympus/(?P<line>[a-z][a-z0-9-]*)/(?P<app_id>[a-z0-9][a-z0-9-]*)/(?P<step>[a-z0-9][a-z0-9-]*)$`.

---

## ENV CONFIG HELPERS (`git_operations.py`)
- `_git_service_config()` → `{"token": $GITHUB_TOKEN or "", "repo": $GITHUB_REPO or "", "base_url": $GITHUB_BASE_URL or "https://api.github.com"}`.
- `_build_git_service(repo_override="")`: lazily `from src.git_service import GitService`; `cfg = _git_service_config()`; return `GitService(GitServiceConfig(token=cfg["token"], repo=(repo_override or cfg["repo"]), base_url=cfg["base_url"]))`. ⚠️ `repo_override` (the per-activity `input.repo`) WINS over the env default — each activity targets its OWN repo.

---

# ACTIVITY-BY-ACTIVITY SPEC

> All seven below are async, decorated `@foundry_activity(config=ActivityConfig(enable_observability=True))`. All follow the same emit-start → try-delegate → on-exception-emit-failed-and-reraise → emit-complete pattern. Idempotency lives in `GitService` (PR reuse, repo short-circuit, file create-or-update) — the activities are thin.

---

## 1. `read_artifact(input: ReadArtifactInput) -> ReadArtifactResult`
**Source:** `git_operations.py:168`.

`ReadArtifactInput`: `repo: str`, `branch: str`, `path: str`, `commit_sha: str = ""`, `execution_context: StepExecutionContext | None = None`.
`ReadArtifactResult`: `content: str`, `commit_sha: str`, `path: str`.

Flow:
1. `execution_id = await _emit_git_start(ctx, repo=input.repo, operation="read_artifact", branch=input.branch, paths=[input.path])`.
2. `try`: `svc = _build_git_service(repo_override=input.repo)`; `result = svc.read_file(path=input.path, branch=input.branch, commit_sha=input.commit_sha)`.
3. `except Exception as exc`: `await _emit_git_complete(execution_id, repo=input.repo, branch=input.branch, status=FAILED, error=str(exc))`; `raise`.
4. Success: `await _emit_git_complete(execution_id, repo=input.repo, branch=input.branch, commit_sha=result.commit_sha, output_paths=[result.path])`.
5. Return `ReadArtifactResult(content=result.content, commit_sha=result.commit_sha, path=result.path)`.

**Reads:** GitHub Contents API (file at branch/commit). **Writes:** `step_execution` only (telemetry). **Retry:** `TRANSIENT_RETRY_POLICY` (= `HTTP_RETRY_POLICY`) at the caller. Read-only + idempotent.

---

## 2. `write_artifact(input: WriteArtifactInput) -> WriteArtifactResult`
**Source:** `git_operations.py:217`.

`WriteArtifactInput`: `repo`, `branch`, `path`, `content`, `commit_message`, `execution_context=None`.
`WriteArtifactResult`: `commit_sha`, `path`, `branch`.

Flow: emit-start (`operation="write_artifact"`, `paths=[input.path]`) → `svc.commit_file(branch, path, content, commit_message)` → on error emit FAILED + raise → emit-complete with `branch=result.branch, commit_sha=result.commit_sha, output_paths=[result.path]` → return `WriteArtifactResult(result.commit_sha, result.path, result.branch)`.

**Idempotent on content** — a retry re-commits (create-or-update via `commit_file`). Branch auto-created from `main` if absent (`_ensure_branch`). Retry: `TRANSIENT_RETRY_POLICY`.

---

## 3. `write_artifacts_batch(input: WriteArtifactsBatchInput) -> WriteArtifactsBatchResult`
**Source:** `git_operations.py:268`.

`WriteArtifactsBatchInput`: `repo`, `branch`, `files: list[tuple[str,str]]` (path,content pairs), `commit_message`, `execution_context=None`.
`WriteArtifactsBatchResult`: `commit_sha`, `paths: list[str]`, `branch`.

Flow: `paths = [p for p,_ in input.files]`; emit-start (`operation="write_artifacts_batch"`, `paths=paths`) → `svc.commit_files(branch, files, commit_message)` (ONE commit, blob+tree+commit+ref) → on error emit FAILED + raise → emit-complete (`branch=result.branch, commit_sha=result.commit_sha, output_paths=paths`) → return `WriteArtifactsBatchResult(result.commit_sha, paths, result.branch)`.

⚠️ **GOTCHA:** collapses N files into 1 commit (vs N commits for N `write_artifact` calls). Idempotent on content; a retry re-does the blob/tree/commit dance and advances the ref again (no harm — same tree → effectively same content, but a NEW commit SHA each retry). Retry: `TRANSIENT_RETRY_POLICY`.

---

## 4. `create_pr(input: CreatePRInput) -> CreatePRResult`
**Source:** `git_operations.py:323`.

`CreatePRInput`: `repo`, `source_branch`, `target_branch`, `title`, `body`, `reviewers: list[str]=[]`, `labels: list[str]=[]`, `execution_context=None`.
`CreatePRResult`: `pr_number: int`, `pr_url: str`, `source_branch: str`, `target_branch: str`.

Flow:
1. emit-start (`operation="create_pr"`, `branch=input.source_branch`).
2. `svc.create_pull_request(source_branch, target_branch, title, body, reviewers=(input.reviewers or None), labels=(input.labels or None))`. ⚠️ `[]` is coerced to `None` so `GitService` skips review-request/label calls cleanly.
3. on error emit FAILED + raise.
4. emit-complete (`branch=result.source_branch, pr_number=result.pr_number, pr_url=result.pr_url`).
5. Return `CreatePRResult(result.pr_number, result.pr_url, result.source_branch, result.target_branch)`.

**Idempotency:** delegated to `GitService.create_pull_request` — a duplicate-open-PR 422 reuses the existing PR (title/body/labels refreshed). PR approval drives a `gate_approved` signal on the waiting workflow (out of scope here). Retry: `TRANSIENT_RETRY_POLICY`.

---

## 5. `merge_pr(input: MergePRInput) -> MergePRResult`
**Source:** `git_operations.py:377`.

`MergePRInput`: `repo`, `pr_number: int`, `merge_method: str = "merge"` (merge|squash|rebase), `execution_context=None`.
`MergePRResult`: `pr_number: int`, `merged: bool`, `merge_sha: str = ""`.

Flow:
1. emit-start (`operation="merge_pr"`, no branch).
2. `result = svc.merge_pull_request(pr_number=input.pr_number, merge_method=input.merge_method)` — returns a `dict` `{"merged":bool,"merge_sha":str}`.
3. on error emit FAILED + raise.
4. emit-complete (`pr_number=input.pr_number, commit_sha=result.get("merge_sha","")`).
5. Return `MergePRResult(pr_number=input.pr_number, merged=result["merged"], merge_sha=result.get("merge_sha",""))`.

**Failure → error class (via `GitService.merge_pull_request`):** `dirty`→`MergeConflict`, `behind`→`MergeDivergenceUnresolved`, `blocked`→`MergeBranchProtectionRejected`, other-unmergeable→`GitServiceError`, merge POST failure→`GitServiceError`. ⚠️ ALL of these are then re-wrapped by the decorator into `NonRetryableError(...)` (none are `WorkflowError`/`ApplicationError`, none name-match `_is_retryable_error`). **This is the bare-merge path that does NOT auto-rebase; superseded by `reconcile_and_merge_pr` for artifact-repo merges that may race (W17/P5-S17.3c, 2026-05-04).** Idempotent: already-merged PR returns `{"merged":True,...}`. Retry: `TRANSIENT_RETRY_POLICY` (note: this means a `behind` from bare `merge_pr` WOULD be retried at Temporal level since the wrapped `NonRetryableError` under `TRANSIENT_RETRY_POLICY`... — see GOTCHA).

⚠️ **GOTCHA (merge_pr vs reconcile_and_merge_pr retry semantics differ):** `merge_pr` is called with `TRANSIENT_RETRY_POLICY` which has NO `non_retryable_error_types`. `NonRetryableError`, however, is intrinsically non-retryable to Temporal regardless of policy (it derives from the foundry-temporal `NonRetryableError` whose contract is "Temporal must not retry"). So a bare `merge_pr` hitting `dirty`/`behind`/`blocked` does NOT retry. The difference vs `reconcile_and_merge_pr` is: the latter RESOLVES `behind` via rebase before failing, and uses `GIT_MERGE_RETRY_POLICY` (short backoff, 3 attempts) so a transient GitHub hiccup before classification gets a couple retries.

---

## 6. `reconcile_and_merge_pr(input: MergePRInput) -> MergePRResult`
**Source:** `git_operations.py:424`. Input/Result identical to `merge_pr`.

Behavior (delegated to `GitService.reconcile_and_merge`): (1) re-read PR; (2) already-merged→idempotent success; (3) `clean`→merge; (4) `behind`→update-branch, re-check, then merge; if still `behind`→`MergeDivergenceUnresolved`; (5) `dirty`→`MergeConflict`; (6) `blocked`→`MergeBranchProtectionRejected`.

Flow (with telemetry — reproduce the structured-log fields EXACTLY):
1. `import time` (local). `execution_id = await _emit_git_start(ctx, repo=input.repo, operation="reconcile_and_merge_pr")`.
2. `try: attempt = activity.info().attempt; except Exception: attempt = 1`.
3. `start_wall = time.monotonic()`.
4. `try: svc = _build_git_service(repo_override=input.repo); result = svc.reconcile_and_merge(pr_number=input.pr_number, merge_method=input.merge_method)`.
5. `except Exception as exc:` `duration_ms = int((time.monotonic()-start_wall)*1000)`; `failure_type = type(exc).__name__`; **`logger.warning("reconcile_and_merge_pr failed", extra={"pr_number": input.pr_number, "failure_type": failure_type, "attempt": attempt, "duration_ms": duration_ms})`**; `await _emit_git_complete(execution_id, repo=input.repo, status=FAILED, error=f"{failure_type}: {exc}")`; **`raise`** (re-raises ORIGINAL exc — the original merge-error class, NOT a new wrap; the decorator then wraps it into `NonRetryableError`).
6. Success: `duration_ms = int((time.monotonic()-start_wall)*1000)`; `await _emit_git_complete(execution_id, repo=input.repo, pr_number=input.pr_number, commit_sha=result.merge_sha)`; **`logger.info("reconcile_and_merge_pr succeeded", extra={"pr_number": input.pr_number, "initial_mergeable_state": result.initial_mergeable_state, "rebase_ran": result.rebase_performed, "final_mergeable_state": result.final_mergeable_state, "merge_sha": result.merge_sha, "attempt": attempt, "duration_ms": duration_ms})`**.
7. Return `MergePRResult(pr_number=input.pr_number, merged=result.merged, merge_sha=result.merge_sha)`.

**Telemetry field set (strategy doc §3.8) — exact `extra=` keys:**
- Success path: `pr_number`, `initial_mergeable_state`, `rebase_ran` (= `result.rebase_performed`), `final_mergeable_state`, `merge_sha`, `attempt`, `duration_ms`.
- Failure path: `pr_number`, `failure_type` (structured class name), `attempt`, `duration_ms`.
⚠️ Note the field is named `rebase_ran` in the LOG but maps from `result.rebase_performed`. The same fields also land in the `step_execution` payload via `_emit_git_complete` (`commit_sha` only, via `payload_merge`), so the on-success commit_sha is queryable.

**Failure → error class (via `GitService.reconcile_and_merge`):**
| GitHub `mergeable_state` (initial, or post-rebase) | raised class | retryable? |
|---|---|---|
| `dirty` (initial OR post-rebase) | `MergeConflict` | NO (operator must resolve) |
| `blocked` (initial OR post-rebase) | `MergeBranchProtectionRejected` | NO (operator/policy) |
| `behind` still after rebase | `MergeDivergenceUnresolved` | NO at Temporal (in non_retryable list); workflow re-enters via reviewer `merge_retry` signal |
| `behind` → resolved to `clean` by rebase | (none — proceeds to merge) | — |
| `clean`/`unknown` | (none — proceeds to merge; merge_pull_request re-classifies) | — |
| GitHub API error during chain | `GitServiceError` | YES (not in non_retryable list, wrapped to `NonRetryableError`... see below) |

⚠️ **GOTCHA (retry intent vs decorator wrap):** `reconcile_and_merge_pr` is meant to be called with `RETRY_POLICIES["git_merge"]` (`GIT_MERGE_RETRY_POLICY`: `initial=5s, coeff=2.0, max_interval=30s, max_attempts=3, non_retryable_error_types=["MergeConflict","MergeDivergenceUnresolved","MergeBranchProtectionRejected"]`). The decorator wraps the three merge errors into `NonRetryableError`. For Temporal's `non_retryable_error_types` name-match to work, EITHER the original class names must reach Temporal OR `NonRetryableError` must be intrinsically non-retryable. Because this activity re-raises the ORIGINAL exception (step 5 `raise`), Temporal sees `NonRetryableError` (post-decorator). The policy's name list is belt-and-suspenders. **A faithful rebuild must keep BOTH** (the explicit re-raise of the original class for telemetry `failure_type`, AND the policy name list) so a transient `GitServiceError` (not in the list) gets the 3 short-backoff retries while the three structured errors short-circuit.

---

## 7. `provision_target_repo(input: ProvisionTargetRepoInput) -> ProvisionTargetRepoResult`
**Source:** `git_operations.py:543`.

`ProvisionTargetRepoInput`: `target_app_id: str`, `repo_slug: str` ("owner/name"), `initial_readme: str=""`, `private: bool=True`, `execution_context=None`, `source_app_ids: list[str]=[]`, `target_service_id: str=""`, `portfolio_id: str=""`, `relationship: str=""`.
`ProvisionTargetRepoResult`: `target_app_id`, `target_repo_url`, `repo_slug`, `created: bool=False`, `lineage_rows_inserted: int=0`.

Flow:
1. emit-start (`repo=input.repo_slug`, `operation="provision_target_repo"`).
2. `try`: lazily `from src.git_service import GitService`; `cfg = _git_service_config()`; `url, created = GitService.provision_repository(GitServiceConfig(token=cfg["token"], repo=cfg["repo"], base_url=cfg["base_url"]), repo_slug=input.repo_slug, initial_readme=input.initial_readme, private=input.private)`. ⚠️ The `repo=cfg["repo"]` in the config is **unused for provisioning** (the static method takes `repo_slug` separately) but is required by the `GitServiceConfig` ctor.
3. on error emit FAILED + raise.
4. emit-complete (`repo=input.repo_slug` only — no commit_sha/pr).
5. Return `ProvisionTargetRepoResult(target_app_id=input.target_app_id, target_repo_url=url, repo_slug=input.repo_slug, created=created)`.

⚠️ **GOTCHA:** despite the input carrying `source_app_ids`/`target_service_id`/`portfolio_id`/`relationship` and the result declaring `lineage_rows_inserted`, **THIS activity writes NO DB state and NO lineage** — `lineage_rows_inserted` always defaults to `0`. Idempotent on `repo_slug` (existing repo → `created=False`, no failure). DB projection (`target_repo_url`) is done separately by `persist_architecture_side_effects` at G-02. The lineage-write-from-`source_app_ids` documented in the input docstring is NOT implemented in this activity (it is in `create_target_app_and_repo`). Retry: `TRANSIENT_RETRY_POLICY`; existing-repo short-circuited.

---

## 8. `fetch_application_source_repos(input: FetchSourceReposInput) -> FetchSourceReposResult`
**Source:** `line_transitions.py:220`. Read-only DB lookup (NOT a git/GitHub call despite the name).

`FetchSourceReposInput`: `source_app_ids: list[str] = []`.
`FetchSourceReposResult`: `anchor_source_repo: str = ""`, `source_repos: dict[str,str] = {}`.

Flow:
1. If `not input.source_app_ids`: return `FetchSourceReposResult()` (both defaults).
2. Build `ids: list[uuid.UUID]` and `raw_to_canonical: dict[str,str]`: for each `raw` in `source_app_ids`, `try parsed = uuid.UUID(raw)` (skip on `ValueError`/`TypeError` — `continue`), append `parsed`, `raw_to_canonical[raw] = str(parsed)`.
3. If `not ids`: return `FetchSourceReposResult()`.
4. `conn = await asyncpg.connect(_db_url())` (the `line_transitions._db_url()`); query and close in `finally`:
   ```sql
   SELECT id, repo_url FROM application WHERE id = ANY($1::uuid[])
   ```
   with `ids`. For each row: `source_repos[str(row["id"])] = row["repo_url"] or ""`.
5. `anchor_canonical = raw_to_canonical.get(input.source_app_ids[0], "")`; `anchor_source_repo = source_repos.get(anchor_canonical, "")`.
6. Return `FetchSourceReposResult(anchor_source_repo=anchor_source_repo, source_repos=source_repos)`.

**Reads:** `application(id, repo_url)`. **Writes:** NONE. ⚠️ Apps with no DB row are OMITTED from `source_repos` (callers diff keys vs requested to detect misses). Missing rows return empty values rather than raising — the workflow proceeds (logs the gap). Idempotent + read-only. `_db_url()` here is `line_transitions._db_url()` (same env vars / default values as `execution._db_url()`). Retry: transient.

---

## 9. `create_target_app_and_repo(input: CreateTargetAppAndRepoInput) -> CreateTargetAppAndRepoResult` — **THE COMPLEX FAN-OUT PROJECTION**
**Source:** `line_transitions.py:7536`. One invocation per non-Retire fan-out target (from `WaveRationalizationWorkflow.dispatch_architecture`). **This is the heaviest write path in the group: provisions a repo, INSERTs/UPDATEs `application`, INSERTs `wave_application` + `application_lineage`, commits a `source-artifacts-index.json` to the artifact repo, and (Replace/Consolidate only) cancels source workflows + flips source status.**

`CreateTargetAppAndRepoInput`: `source_app_id: str`, `target_app_name: str`, `target_repo: str`, `wave_id: str`, `portfolio_id: str`, `disposition: str`, `default_branch: str="main"`, `peer_source_app_ids: list[str]=[]`, `source_app_ids: list[str]=[]` (v2 full source set), `target_service_id: str=""` (v2 SF3 catalog id).
`CreateTargetAppAndRepoResult`: `target_app_id: str`, `target_repo_url: str`, `created_new_app_row: bool=False`, `lineage_rows_inserted: int=0`.

**Disposition classification:**
- `_TARGET_EQUALS_SOURCE_DISPOSITIONS = frozenset({"Retain","Refactor","Rearchitect","Replatform"})` → `new_target = False`.
- `_NEW_TARGET_DISPOSITIONS = frozenset({"Replace","Consolidate"})` → `new_target = True`.
- Anything else → `NonRetryableError("create_target_app_and_repo invoked with unsupported disposition <d>")`.

### Step A — input validation (all `NonRetryableError` on bad UUID):
1. `source_uuid = uuid.UUID(input.source_app_id)` → bad → `NonRetryableError("Invalid source_app_id: <...>")`.
2. `portfolio_uuid = uuid.UUID(input.portfolio_id) if input.portfolio_id else None` → bad → `NonRetryableError("Invalid portfolio_id: <...>")`.
3. `wave_uuid = uuid.UUID(input.wave_id) if input.wave_id else None`; **bad → `wave_uuid = None`** (NOT an error — `wave_application` insert is best-effort).
4. Compute `new_target` (above).
5. **`if not input.target_repo`: `NonRetryableError("create_target_app_and_repo: target_repo is required for disposition <d> — source <id>")`.** EVERY disposition now requires an operator-named target repo (source repos stay frozen as Discovery evidence).

### Step B — idempotency probe (separate `conn`, closed in `finally` before Step C):
Only if `portfolio_uuid is not None and input.target_repo`:
- **`new_target` (Replace/Consolidate):**
  ```sql
  SELECT id, target_repo_url FROM application
  WHERE portfolio_id = $1 AND target_repo_url = $2 LIMIT 1
  ```
  (`portfolio_uuid`, `input.target_repo`). If found → log + **return `CreateTargetAppAndRepoResult(target_app_id=str(existing["id"]), target_repo_url=(existing["target_repo_url"] or input.target_repo), created_new_app_row=False, lineage_rows_inserted=0)`** (short-circuit, NO repo provisioning, NO further writes).
- **target==source (Retain/Refactor/Rearchitect/Replatform):**
  ```sql
  SELECT target_repo_url FROM application WHERE id = $1
  ```
  (`source_uuid`). If `existing is not None and existing["target_repo_url"] == input.target_repo` → log + **return `CreateTargetAppAndRepoResult(target_app_id=input.source_app_id, target_repo_url=existing["target_repo_url"], created_new_app_row=False, lineage_rows_inserted=0)`**.

### Step C — provision the repo (EVERY disposition):
Lazily import `GitService`/`GitServiceConfig` (`src.git_service` then `olympus_api.services.git_service` fallback; both fail → both set to `None`). `token = $GITHUB_TOKEN`; `base_url = $GITHUB_BASE_URL or "https://api.github.com"`.
- **If `GitService is not None and GitServiceConfig is not None and token`:** build `readme = f"# {input.target_app_name}\n\nOlympus modernization target — disposition: {disposition}.\nSources: {input.source_app_id}"`; if `input.peer_source_app_ids`: `readme += f", {', '.join(input.peer_source_app_ids)}"`; `readme += f"\nWave: {input.wave_id}\n"`. Then `try: provisioned_url, _ = GitService.provision_repository(cfg, repo_slug=input.target_repo, initial_readme=readme, private=True)`. **`except Exception as exc`:** if `_is_already_exists_error(exc)` → `NonRetryableError("Target repository <repo> already exists and is owned by a different wave or user. Pick a different repo name and retry.")`; else bare `raise` (bubbles to retry policy).
- **Else (no token / GitService unavailable — unit-test branch):** `provisioned_url = input.target_repo` (slug passthrough), log.

`_is_already_exists_error(exc)`: `str(exc).lower()` contains `"422"` OR `"already exists"` OR `"name already exists"`; OR `exc.__cause__` has `.status == 422`. ⚠️ Detects PyGithub `GithubException`'s 422 via both message and cause chain.

### Step D — DB writes (new `conn`, ALL inside `async with conn.transaction()`, conn closed in `finally`):

#### D-new_target (Replace/Consolidate):
1. `target_uuid = uuid.uuid4()`.
2. **Resolve source-id set** (drives both `application.source_app_ids` AND lineage edges — kept identical):
   - If `input.source_app_ids` (v2): parse each to UUID, skip+warn on bad; if NONE parsed → fallback `source_ids = [source_uuid]`.
   - Else (v1): `source_ids = [source_uuid]` then append each parsed `peer_source_app_ids` (skip+warn on bad).
3. `target_service_id = input.target_service_id or None`.
4. **INSERT `application`:**
   ```sql
   INSERT INTO application (
       id, name, portfolio_id, current_line, current_status,
       target_repo_url, source_app_ids, target_service_id
   ) VALUES ($1, $2, $3, NULL, 'onboarded', $4, $5, $6)
   ON CONFLICT (id) DO NOTHING
   ```

   | artifact/input field | column | value / default | condition |
   |---|---|---|---|
   | `uuid.uuid4()` | `application.id` | `$1 = target_uuid` | always (new row) |
   | `input.target_app_name` | `application.name` | `$2` | always |
   | `portfolio_uuid` | `application.portfolio_id` | `$3` | always (may be NULL if input.portfolio_id empty) |
   | — | `application.current_line` | `NULL` (literal) | always |
   | — | `application.current_status` | `'onboarded'` (literal) | always |
   | `provisioned_url or input.target_repo` | `application.target_repo_url` | `$4` | always |
   | resolved `source_ids` | `application.source_app_ids` | `$5` (uuid[]) | always (≥1 entry guaranteed) |
   | `input.target_service_id or None` | `application.target_service_id` | `$6` | NULL for v1 callers |
   - `ON CONFLICT (id) DO NOTHING` — uuid4 collision is astronomically unlikely; defensive.
   - `created_new = True`.
5. **INSERT `wave_application`** ONLY `if wave_uuid is not None`:
   ```sql
   INSERT INTO wave_application (wave_id, application_id)
   VALUES ($1, $2) ON CONFLICT DO NOTHING
   ```
   (`wave_uuid`, `target_uuid`). | `wave.id`→`wave_application.wave_id ($1)`, `target_uuid`→`wave_application.application_id ($2)`. Binds the new target to the wave for the Applications list.
6. **INSERT `application_lineage` — one edge per source:** `relationship = _lineage_relationship_for(disposition)` (Replace→`"replace"`, Consolidate→`"consolidate"`). `lineage_inserted = 0`. For each `src` in `source_ids`:
   ```sql
   INSERT INTO application_lineage (target_app_id, source_app_id, relationship, created_at)
   VALUES ($1, $2, $3, $4)
   ON CONFLICT (target_app_id, source_app_id) DO NOTHING
   ```
   (`target_uuid`, `src`, `relationship`, `datetime.now(timezone.utc)`); if `result.endswith(" 1")`: `lineage_inserted += 1`.

   | field | column | value |
   |---|---|---|
   | `target_uuid` | `application_lineage.target_app_id` | `$1` |
   | each `src` (from `source_ids`) | `application_lineage.source_app_id` | `$2` |
   | `_lineage_relationship_for(disposition)` | `application_lineage.relationship` | `$3` (`replace`/`consolidate`) |
   | `now(utc)` | `application_lineage.created_at` | `$4` |
   - ⚠️ Lineage edge count = `len(source_ids)`: Consolidate emits N, Replace emits 1. Matches `application.source_app_ids` verbatim.
7. Build `new_target_result = CreateTargetAppAndRepoResult(target_app_id=str(target_uuid), target_repo_url=(provisioned_url or input.target_repo), created_new_app_row=True, lineage_rows_inserted=lineage_inserted)`. **Falls through** (transaction commits at `async with` exit; `finally` closes conn) to Step E + Step F.

#### D-target_equals_source (Retain/Refactor/Rearchitect/Replatform):
1. `effective_url = provisioned_url or input.target_repo`.
2. **UPDATE `application`:**
   ```sql
   UPDATE application SET target_repo_url = $2, updated_at = $3 WHERE id = $1
   ```

   | field | column | value |
   |---|---|---|
   | `source_uuid` | (WHERE `application.id`) | `$1` |
   | `effective_url` | `application.target_repo_url` | `$2` (overwrites any stale stub URL) |
   | `now(utc)` | `application.updated_at` | `$3` |
3. **INSERT `application_lineage` — self-referential single edge:** `relationship = _lineage_relationship_for(disposition)` (= `f"{disposition.lower()}-of"`, e.g. `refactor-of`, `rearchitect-of`, `replatform-of`, `retain-of`).
   ```sql
   INSERT INTO application_lineage (target_app_id, source_app_id, relationship, created_at)
   VALUES ($1, $2, $3, $4)
   ON CONFLICT (target_app_id, source_app_id) DO NOTHING
   ```
   (`source_uuid`, `source_uuid`, `relationship`, `now(utc)`). `lineage_inserted = 1 if result.endswith(" 1") else 0`.

   | field | column | value |
   |---|---|---|
   | `source_uuid` | `application_lineage.target_app_id` | `$1` (== source) |
   | `source_uuid` | `application_lineage.source_app_id` | `$2` (== target — self-ref) |
   | `_lineage_relationship_for(disposition)` | `application_lineage.relationship` | `$3` (`<disp>-of`) |
   | `now(utc)` | `application_lineage.created_at` | `$4` |
4. Build `new_target_result = CreateTargetAppAndRepoResult(target_app_id=input.source_app_id, target_repo_url=effective_url, created_new_app_row=False, lineage_rows_inserted=lineage_inserted)`. **Falls through** to Step E (NOT Step F — see below).

⚠️ **GOTCHA (provisioning OUTSIDE the transaction, DB writes INSIDE):** repo provisioning (Step C, a non-transactional GitHub call) precedes the DB transaction (Step D). If the DB transaction rolls back, the provisioned repo is orphaned (idempotency probe will reuse it next run). Conversely if Step C raised, no DB write happened. The `source-artifacts-index` commit (Step E) happens AFTER the transaction commits + conn closes.

### Step E — commit the source-artifacts-index (BOTH branches, HARD-FAIL on error):
After Step D's `finally`:
1. `target_app_id_str = new_target_result.target_app_id`.
2. `anchor_name, peer_pairs, artifact_repo = await _fetch_source_app_names_and_repo(source_app_id=input.source_app_id, peer_source_app_ids=input.peer_source_app_ids, portfolio_uuid=portfolio_uuid)` — reads `application(id,name)` for the source set and `portfolio.artifact_repo_url`. Returns `(anchor_name, [(peer_id, peer_name),...], artifact_repo)`.
3. `index_payload = _build_source_artifacts_index(target_app_id=target_app_id_str, target_app_name=input.target_app_name, wave_id=input.wave_id, disposition=disposition, anchor_source_app_id=input.source_app_id, anchor_source_app_name=anchor_name, peer_sources=peer_pairs)`.
4. `await _write_target_source_artifacts_index(artifact_repo=artifact_repo, wave_id=input.wave_id, target_app_id=target_app_id_str, index_payload=index_payload)`.

`_write_target_source_artifacts_index`: **raises on EVERY failure mode** (no longer best-effort since 2026-05-21 Private Pilot Cert incident):
- `if not artifact_repo`: `ValueError("source-artifacts-index: artifact_repo unavailable for target_app_id=<...> — portfolio row missing artifact_repo_url")`.
- `if not $GITHUB_TOKEN`: `RuntimeError("source-artifacts-index: GITHUB_TOKEN unset — ...")`.
- GitService import fails (both paths): `RuntimeError("source-artifacts-index: GitService unavailable — ... (<exc>)")`.
- `path = _target_source_artifacts_index_path(wave_id, target_app_id)` = `f"rationalization/wave-{wave_id}/targets/{target_app_id}/source-artifacts-index.json"`. `content = json.dumps(index_payload, indent=2, sort_keys=True)`. `svc.commit_files(branch="main", files=[(path, content)], commit_message=f"rationalization(wave-{wave_id}): source-artifacts-index for target {target_app_id}")`. (Commit to the **artifact repo's `main`** — single-file batch commit.)

`_build_source_artifacts_index(...)` → dict:
- `peer_role`: `"consolidate-source"` if Consolidate, `"replace-source"` if Replace, else `f"{disposition.lower()}-source"`.
- `_artifacts_for_source(source_id)` → `{"discovery": [f"discovery/{source_id}/{name}" for name in _SOURCE_DISCOVERY_ARTIFACTS], "rationalization": [f"rationalization/wave-{wave_id}/{source_id}/{name}" for name in _SOURCE_RATIONALIZATION_ARTIFACTS]}`.
- `sources = [{"app_id": anchor_source_app_id, "app_name": anchor_source_app_name, "role": "anchor", "artifacts": _artifacts_for_source(anchor_source_app_id)}]` + one `{"app_id": peer_id, "app_name": peer_name, "role": peer_role, "artifacts": ...}` per `(peer_id, peer_name)` in `peer_sources`.
- Returns:
  ```json
  {
    "schema_version": "1.0",
    "target_app_id": "<...>",
    "target_app_name": "<...>",
    "wave_id": "<...>",
    "disposition": "<...>",
    "source_apps": [ ... ],
    "shared_artifacts": ["rationalization/wave-{wave_id}/{name}" for name in _WAVE_SHARED_RATIONALIZATION_ARTIFACTS]
  }
  ```
  (`TARGET_SOURCE_ARTIFACTS_INDEX_SCHEMA_VERSION = "1.0"`.)
- `_SOURCE_DISCOVERY_ARTIFACTS`, `_SOURCE_RATIONALIZATION_ARTIFACTS`, `_WAVE_SHARED_RATIONALIZATION_ARTIFACTS` are NOT hard-coded — they are computed at IMPORT time from the line contracts via `_artifact_filenames_for_steps(line_name, step_ids)` (reads `olympus_contracts.get_line(line).step(step_id).artifact_filename` or basename of `outputs.artifacts[0]`; raises at import on drift). Curated step-id subsets:
  - Discovery: `catalog, structural-analysis, business-logic-extraction, quality-risk-assessment, ux-accessibility-assessment, data-domain-discovery, shared-database-analysis, synthesis, tco-baseline`.
  - Rationalization: `disposition-recommendation` (+ literal `disposition-recommendation.md` sidecar) + `classification, portfolio-scoring, intra-app-redundancy, disposition-governance`.
  - Wave-shared Rationalization: `cross-app-redundancy, compare-ux-overlap`.

`_fetch_source_app_names_and_repo(*, source_app_id, peer_source_app_ids, portfolio_uuid)` (around L7391): opens a conn; builds `ids = [source_app_id + peers]` (parsed); `SELECT id, name FROM application WHERE id = ANY($1::uuid[])` → `id_to_name[str(id)] = name or str(id)`; if `portfolio_uuid is not None`: `SELECT artifact_repo_url FROM portfolio WHERE id = $1` → `artifact_repo = row["artifact_repo_url"] or ""`. Returns `(anchor_name=id_to_name.get(source_app_id, source_app_id), peer_pairs=[(pid, id_to_name.get(pid,pid)) for pid in peers if pid and pid != source_app_id], artifact_repo)`. **Reads:** `application(id,name)`, `portfolio(artifact_repo_url)`. **Writes:** none.

### Step F — post-commit housekeeping (new_target / Replace+Consolidate ONLY):
- **`if not new_target`: `return new_target_result`** (target==source skips housekeeping — cancelling its own workflows would cancel its modernization).
- Else: `reason = f"source app consolidated into {target_app_id_str}; work transitioned to target"`; build `source_ids_for_cleanup = [input.source_app_id]` + each unique non-empty `peer_source_app_ids`. For each `src_id`:
  - `try: cancelled = await _cancel_running_source_line_workflows(src_id, reason); status_updated = await _set_application_consolidated_status(src_id); log info`.
  - `except Exception as exc: logger.warning("create_target_app_and_repo: source termination failed: %s", exc, ...)` — **best-effort, NEVER rolls back the new target row.**
- `return new_target_result`.

`_cancel_running_source_line_workflows(source_app_id, reason)` → `list[str]` (best-effort, never raises): if `not source_app_id`: `[]`. Connect Temporal (`_temporal_host()` = `$TEMPORAL_HOST or "temporal:7233"`, `_temporal_namespace()` = `$TEMPORAL_NAMESPACE or "default"`); on connect failure → warn + `[]`. Visibility query `WorkflowType IN ('ArchitectureWorkflow','DataWorkflow','ModernizationWorkflow','ValidationWorkflow','DeploymentWorkflow') AND ExecutionStatus = 'Running'`. `acceptable_prefixes = tuple(f"{slug}-{source_app_id}" for slug in _SOURCE_LINE_SLUGS)` where `_SOURCE_LINE_SLUGS = ("architecture","data","modernization","validation","deployment")`. `async for desc in client.list_workflows(query=...)`: `wf_id = getattr(desc,"id","")`; skip empty; skip if not `wf_id.startswith(acceptable_prefixes)`; `handle.cancel()` (swallow per-wf errors → still appended as attempted); append `wf_id`. `list_workflows` failure → warn + return what was attempted. ⚠️ id-prefix scan (NOT a search-attribute filter — avoids a Temporal schema migration).

`_set_application_consolidated_status(source_app_id)` → `bool` (best-effort, swallows errors): parse uuid (bad → warn + `False`); connect; `UPDATE application SET current_status = $1, updated_at = $2 WHERE id = $3` with `_CONSOLIDATED_STATUS = "consolidated_into_target"`, `now(utc)`, `app_uuid`. Parse `"UPDATE <n>"` → `count >= 1`. Conn closed in `finally`.

| field | column | value |
|---|---|---|
| `"consolidated_into_target"` | `application.current_status` | `$1` |
| `now(utc)` | `application.updated_at` | `$2` |
| `source_app_id` | (WHERE `application.id`) | `$3` |

**Tables written by `create_target_app_and_repo`:** `application` (INSERT new-target OR UPDATE target==source; UPDATE source on consolidate), `wave_application` (INSERT, new-target only, if wave_uuid), `application_lineage` (INSERT, both branches). Plus a Git commit of `source-artifacts-index.json` to the artifact repo. **Idempotency:** Step-B probe short-circuits on existing target_repo_url. **Retry:** transient; 422-already-exists raised as `NonRetryableError`; bad UUIDs / unsupported disposition / missing target_repo → `NonRetryableError`; index-write failure → `ValueError`/`RuntimeError` (decorator wraps to `NonRetryableError` since type names don't match retryable patterns — ⚠️ this means an index-write failure is NON-retryable, so a transient artifact-repo blip needs an operator re-run; this is the deliberate "hard fail loudly" design).

⚠️ **GOTCHA (two non-transactional `conn` lifecycles + a Git commit + Temporal cancels in one activity):** the activity opens/closes the DB connection THREE+ times (Step-B probe, Step-D transaction, then `_fetch_source_app_names_and_repo`, then `_set_application_consolidated_status` per source). None of these share a transaction with the Git commit or the Temporal cancels. A crash mid-activity can leave: repo provisioned but no `application` row (probe reuses next run); `application` row written but no index commit (downstream lines starve — but the index write raises so the activity fails and Temporal retries the whole thing, re-hitting the probe short-circuit); index committed but source workflows not cancelled (housekeeping is best-effort and re-runnable via the standalone `terminate_source_app_workflows` activity).

---

## 10. `terminate_source_app_workflows(input: TerminateSourceAppWorkflowsInput) -> TerminateSourceAppWorkflowsResult`
**Source:** `line_transitions.py:8168`. (Standalone re-runnable form of Step F; same helpers.)

`TerminateSourceAppWorkflowsInput`: `source_app_id: str`, `target_app_id: str=""`, `target_app_name: str=""`, `reason: str=""`.
`TerminateSourceAppWorkflowsResult`: `source_app_id: str`, `cancelled_workflow_ids: list[str]=[]`, `status_updated: bool=False`.

Flow: `reason = input.reason or (f"source app consolidated into {input.target_app_id}; work transitioned" if input.target_app_id else "source app consolidated; work transitioned")`; `cancelled = await _cancel_running_source_line_workflows(input.source_app_id, reason)`; `status_updated = await _set_application_consolidated_status(input.source_app_id)`; return `TerminateSourceAppWorkflowsResult(input.source_app_id, cancelled, status_updated)`.

**Writes:** `application.current_status`/`updated_at` (best-effort). **Side effect:** Temporal workflow cancels (best-effort). Idempotent (cancelling terminal workflows is a no-op; UPDATE re-writes same values). Both sub-ops swallow errors → never raises.

---

## CROSS-CUTTING NOTES

- **Two `_db_url()` implementations** — one in `execution.py` (telemetry), one in `line_transitions.py` (business DB). Identical env vars + defaults (`DATABASE_HOST=localhost, PORT=5432, USER=olympus, PASSWORD=olympus, NAME=olympus`). Both build `postgresql://user:password@host:port/db`.
- **`GitService` import resolution order everywhere:** `from src.git_service import GitService` FIRST (worker container layout where it's copied to `src/`), `from olympus_api.services.git_service import GitService` SECOND (monorepo/test layout). `create_target_app_and_repo` tolerates BOTH failing (sets `None`, slug-passthrough); `_write_target_source_artifacts_index` raises `RuntimeError` if both fail.
- **Retry-policy summary:** `read/write/write_batch/create_pr/merge_pr/provision_target_repo/fetch_application_source_repos/create_target_app_and_repo/terminate_source_app_workflows` → `TRANSIENT_RETRY_POLICY` (`HTTP_RETRY_POLICY`, 3 retries, exp 1–15s). `reconcile_and_merge_pr` → `GIT_MERGE_RETRY_POLICY` (5s init, ×2, max 30s, 3 attempts, non_retryable=[MergeConflict, MergeDivergenceUnresolved, MergeBranchProtectionRejected]).
- **Error-class → state map (single source of truth):** `_UNMERGEABLE_STATE_TO_ERROR = {"dirty": MergeConflict, "behind": MergeDivergenceUnresolved, "blocked": MergeBranchProtectionRejected}` in `git_service.py`. `reconcile_and_merge` raises these directly (not via the map) but the messages/classes match. All three subclass `GitServiceError(Exception)`; defined in `olympus_contracts/errors.py`; re-exported via `olympus_contracts`.
