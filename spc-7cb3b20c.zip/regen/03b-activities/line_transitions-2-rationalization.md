# Phase 4 — Activity Group: `line_transitions.py` (Rationalization persisters)

**Source file:** `/Users/pnunna/Documents/GitHub/foundry/temporal/olympus_workflows/activities/line_transitions.py`
**HEAD:** `7cb3b20c`. **Line numbers REFRESHED to HEAD** (see ⚠️ shift note below).
**Owned line range:** **2048–3252** (inclusive of the three target functions and the helpers/constants that *live inside* this range; shared helpers defined earlier in the file are reproduced here because the activities depend on them for behavioral parity, but their canonical home is the sibling spec for lines 1–2047).

> ⚠️ **HEAD `7cb3b20c` line-shift note (citations CORRECTED).** `line_transitions.py` grew by +162 lines via two upstream insertions. Symbols owned by this group shifted by +115; e.g. `persist_rationalization_capabilities` 1934→**2049**, `persist_rationalization_capability_dispositions` 2489→**2604**, `persist_rationalization_side_effects` 2862→**2977**. Shared helpers also moved: `_merge_application_metadata` 1058→**1173**, `_build_update_sql` 1111→**1226** — but `_extract_rationalization_compliance_metadata` is UNCHANGED at **970** (it sits above the first insertion point). **`types.py` also grew** (new DevSecOps dataclasses; +68): the dataclass citations below are CORRECTED. Bodies are behaviorally UNCHANGED — only citations moved.

**Activities reproduced in this file (3):**

| Symbol | Def line | Kind |
|---|---|---|
| `persist_rationalization_capabilities` | 2049 | persist / projection (rat-cap layer) |
| `persist_rationalization_capability_dispositions` | 2604 | persist / projection (rat-cap disposition) |
| `persist_rationalization_side_effects` | 2977 | persist / projection (application columns + metadata JSONB) |

**Tables written by this range:**
- `rationalization_capability` (UPSERT/UPDATE) — by `persist_rationalization_capabilities` (mints/updates rows) and `persist_rationalization_capability_dispositions` (updates `disposition` / `target_service_external_id`).
- `capability` (UPDATE FK + INSERT child rows) — by `persist_rationalization_capabilities`.
- `application` (UPDATE projected columns) and `application.metadata` JSONB merge — by `persist_rationalization_side_effects`.

> ⚠️ **Scope note vs. task prompt.** The prompt's hint mentioned `capability_lineage` / `*_lineage` tables. **No function in lines 2048–3252 writes any `*_lineage` table.** Those tables (`capability_lineage`, `business_domain_lineage`, `system_lineage`, `application_lineage`) are DDL-defined in migration 050/earlier and are written by `persist_architecture_side_effects` (def at **3253**, the first activity *after* this range — owned by a sibling spec) via `application_lineage`, and the `capability_lineage`/`business_domain_lineage`/`system_lineage` tables are written by `realize_target_state_grain` (file 6) — not by any activity in this group's projection path. `persist_rationalization_capabilities` instead expresses capability splits through the `capability` table's own `parent_capability_id` / `split_at` self-referential columns (migration 052), **not** through a lineage table. See "Undetermined / cross-file" at the end.

---

## 0. The `@foundry_activity` wrapper (applies to ALL THREE activities here)

Every activity in this group is decorated:

```python
@foundry_activity(config=ActivityConfig(enable_observability=True))
```

`foundry_activity` is imported from `foundry_temporal.activities` (NOT `temporalio.activity`). Reproduced from `/private/var/folders/qs/.../foundry_temporal/activities.py`:

- `foundry_activity(config=None, name=None, **activity_kwargs)` returns a decorator that wraps `func` in an `async def wrapper(*args, **kwargs)` and applies **`@activity.defn(name=name, **activity_kwargs)`** to that wrapper (so Temporal registers it; `name` defaults to the function's `__name__`).
- `ActivityConfig` is a dataclass; here only `enable_observability=True` is set. Other fields default: `retry_policy=None`, all timeouts `None`, **`enable_error_wrapping=True`**, `log_inputs=False`, `log_outputs=False`. (Retry policy / timeouts therefore come entirely from the **workflow's** `execute_activity` call, not from the decorator.)
- **Observability:** when `enable_observability` (true here): on entry logs `f"Activity {activity_name} starting"` with `extra={"inputs": args if log_inputs else None}` (so `None` here); on success logs `"... completed"` with `extra={"outputs": result if log_outputs else None}` (`None` here); on exception logs `f"Activity {activity_name} failed: {error}"` with `extra={"error": str(error)}`. Logger is `get_logger()` from `foundry_temporal.logging`.
- **Error wrapping (`enable_error_wrapping=True`):** on any exception out of `func`:
  - if the error is already a `WorkflowError` **or** `temporalio.exceptions.ApplicationError` → **re-raised unchanged** (`raise`).
  - else if `_is_retryable_error(error)` is True → re-raised as **`RetryableError(f"Retryable error in {activity_name}: {error}")`** (`from error`).
  - else → re-raised as **`NonRetryableError(f"Non-retryable error in {activity_name}: {error}")`** (`from error`).
  - `_is_retryable_error(error)` matches on `str(type(error)).lower()` containing any of: `timeout`, `connection`, `network`, `temporary`, `unavailable`, `overload`, `busy`, `throttle`, `rate_limit`. **It inspects the *type repr*, not the message** — e.g. `asyncpg`/socket errors whose class name contains "connection"/"timeout" classify retryable; a generic `RuntimeError("connection lost")` does **not** (the substring is in the message, not the type).

  > ⚠️ **`NonRetryableError` is itself a subclass that the wrapper recognizes** — it is raised by these activities directly (see below). Because `NonRetryableError`/`RetryableError` derive from `WorkflowError` (see `foundry_temporal/errors.py`), a `NonRetryableError` raised *inside* `func` short-circuits the `isinstance(error, (WorkflowError, ApplicationError))` branch and is **re-raised verbatim** — it is NOT re-wrapped as retryable even though its type repr contains no retry token. This is the mechanism by which "invalid UUID" failures stay non-retryable.

  > ⚠️ **Rebuild trap:** Using plain `@activity.defn` loses (a) the start/complete/fail observability logs and (b) the retryable-vs-non-retryable classification. You MUST reproduce this wrapper or the retry semantics of the worker diverge.

**Important interaction with each activity's own try/except:** All three activities also do `await emit_code_step_complete(exec_id, status=ExecutionStatus.FAILED, error=str(exc)); raise` in their own `except Exception`. So the FAILED execution record is written *before* the wrapper sees the re-raised exception and classifies it. The `raise` then propagates into the wrapper which applies the wrapping rules above.

---

## 1. Shared helpers & module constants (depended on by this range)

These are referenced by the three activities. Reproduce them exactly.

### 1.1 `_db_url()` (line 88)
```python
host = os.environ.get("DATABASE_HOST", "localhost")
port = os.environ.get("DATABASE_PORT", "5432")
user = os.environ.get("DATABASE_USER", "olympus")
password = os.environ.get("DATABASE_PASSWORD", "olympus")
db = os.environ.get("DATABASE_NAME", "olympus")
return f"postgresql://{user}:{password}@{host}:{port}/{db}"
```
All three open a **fresh `asyncpg.connect(_db_url())` per invocation** and `await conn.close()` in a `finally`. No pooling. (⚠️ one TCP connect per app/per wave call — fine at wave cardinalities, not optimized.)

### 1.2 `_try_parse_json(text: str) -> dict | None` (line 281)
Best-effort JSON parse tolerant of agent prose wrappers:
1. If `not text` (empty string / falsy) → return `None`.
2. `json.loads(text)`; on `json.JSONDecodeError`, find first `{` (`text.find("{")`) and last `}` (`text.rfind("}")`); if `start == -1 or end <= start` → `None`; else `json.loads(text[start:end+1])`; on second `JSONDecodeError` → `None`.
3. Return `value` **only if `isinstance(value, dict)`**, else `None`. (A top-level JSON array or scalar parses but is rejected → `None`.)

### 1.3 Disposition / tier value sets (lines 2880–2885)
```python
_RISK_TIERS = frozenset({"1", "2", "3"})
_DISPOSITION_VALUES = frozenset({"Retire", "Retain", "Refactor", "Rearchitect",
                                 "Replace", "Replatform", "Consolidate"})
_DISPOSITION_SOURCES = frozenset({"auto", "overridden", "confirmed"})
```
> ⚠️ **Definition-order gotcha.** `_DISPOSITION_VALUES` is *defined at line 2881* but is *referenced at line 2703* inside `persist_rationalization_capability_dispositions`. This works only because Python resolves the module-global name at **call time**, not def time; by the time any activity runs, the whole module is imported. A rebuild must keep `_DISPOSITION_VALUES` as a module global (not a closure / local).

### 1.4 Clustering-plan schema loading (lines 1804–1881) — used by activity #1
- `_rat_cap_clustering_plan_schema_path()`: candidate list, first match wins:
  1. `$OLYMPUS_SCHEMAS_DIR` (if env set).
  2. `Path(__file__).resolve().parents[3] / "schemas"`.
  3. `/app/schemas`.
  4. `/app/repo/schemas`.
  For each, check `c / "rationalization" / "rationalization-clustering-plan.schema.json"`; return `str(candidate.resolve())` of the first that `.is_file()`, else `None`.
- `_CACHED_RAT_CAP_PLAN_SCHEMA: dict | None = None` module global; `_load_rat_cap_clustering_plan_schema()` returns cache if set; else path → `open(path,"r",encoding="utf-8")` → `json.load`; on `(json.JSONDecodeError, OSError)` returns `None`; on success caches and returns. (⚠️ once cached, never reloaded for the worker process lifetime.)
- `_validate_rat_cap_clustering_plan(payload) -> list[str]`:
  - `payload` not a dict → `["clustering plan is not a JSON object"]`.
  - schema `None` → `["rationalization-clustering-plan.schema.json not found on worker — set OLYMPUS_SCHEMAS_DIR or mount the repo schemas directory"]`.
  - else `from jsonschema import Draft202012Validator`; `errors = list(validator.iter_errors(payload))`; empty → `[]`; else **first 8** errors formatted as `f"{err.json_path or '<root>'}: {err.message}"`.
  - **Schema contract** (`schemas/rationalization/rationalization-clustering-plan.schema.json`): `type:object`, `additionalProperties:false`, **required**: `metadata`, `rationalization_capabilities`, `capability_assignments`, `capability_splits`. `metadata` requires `portfolio_id`(uuid), `wave_id`(uuid), `input_capability_count`(int≥1), `input_application_count`(int≥1). `rationalization_capabilities` array `minItems:1, maxItems:50`; each item requires `name`(3–255), `description`(≥20), `rationale`(≥30), `evidence_refs`(array,minItems:1), `confidence`(0–1); optional `existing_id`(uuid|null), `external_id` (`^[A-Z][A-Z0-9_-]{0,63}$`|null). `capability_assignments[]` requires `capability_id`(uuid)+`rationalization_capability_index`(int≥0). `capability_splits[]` requires `parent_capability_id`(uuid)+`child_assignments`(array,minItems:2; each requires `name`(3–255)+`description`(≥10)+`rationalization_capability_index`(int≥0)). **A plan with empty `rationalization_capabilities` fails (`minItems:1`).**

### 1.5 Disposition-recommendation schema loading (lines 2525–2602) — used by activity #2
- `_disposition_recommendation_schema_path()`: identical candidate logic, file `rationalization/disposition-recommendation.schema.json`.
- `_CACHED_DISPOSITION_RECOMMENDATION_SCHEMA: dict | None = None`; `_load_disposition_recommendation_schema()` same pattern + cache.
- `_validate_disposition_recommendation(payload) -> list[str]`: not-dict → `["disposition recommendation is not a JSON object"]`; schema-missing → `["disposition-recommendation.schema.json not found on worker — set OLYMPUS_SCHEMAS_DIR or mount the repo schemas directory"]`; else first-8 jsonschema errors same format.
  - **Schema contract** (`schemas/rationalization/disposition-recommendation.schema.json`): `type:object`, `additionalProperties:false`, **required**: `metadata`, `rationalization_capability_dispositions`. `metadata` requires `portfolio_id`(uuid)+`wave_id`(uuid)+`input_rat_cap_count`(int≥0). `rationalization_capability_dispositions` array `minItems:0`; each item requires `rationalization_capability_name`(≥1)+`primary_disposition`(enum of the seven)+`rationale`(≥1)+`confidence`(0–1)+`evidence_refs`(array,minItems:1). Optional `rationalization_capability_id`(uuid|null), `rationalization_capability_external_id`(string|null), `secondary_disposition`(enum|null), `target_service_external_id`(string|null), `alternatives_considered`. **`allOf` rule:** if `primary_disposition ∈ {Retire,Retain}` then `target_service_external_id` must be `const: null`. So the *schema* already rejects Retire/Retain rows carrying a target service — the persist activity never sees those past validation.

### 1.6 `_extract_rationalization_compliance_metadata(classification, recommendation) -> dict` (line 970) — used by activity #3
Builds `application.metadata.compliance` block. Start `block = {"source_line": "Rationalization"}`.
- If `classification` is a dict: `tier = classification.get("risk_tier") or classification.get("tier")`; if `isinstance(tier, str) and tier in {"1","2","3"}` → `block["risk_tier"] = tier`; **if `tier == "1"`** → `block["status"] = "needs-review"`.
- If `recommendation` is a dict: `disposition = recommendation.get("recommended_disposition") or ""`; if `disposition in {"Replace","Consolidate","Rearchitect"}` → `block["cato_state"] = "transition"`; **elif `disposition == "Retain"`** → `block["cato_state"] = "inheriting"`. (Note: only reads `recommended_disposition`, NOT the `disposition` shorthand here — distinct from `_extract_disposition_side_effects`.)
- **Drop-to-empty rule:** if `list(block.keys()) == ["source_line"]` (no real signal) → return `{}`. (⚠️ key-list equality, order-sensitive: `source_line` is always inserted first, so this is the only single-key state possible.)

### 1.7 `_merge_application_metadata(conn, app_uuid, namespace, payload)` (line 1173) — used by activity #3
JSONB namespace merge into `application.metadata`:
1. `if not payload: return` (no-op on empty dict).
2. `payload_with_meta = dict(payload)`; `payload_with_meta.setdefault("last_assessed", datetime.now(timezone.utc).isoformat())` (only set if caller didn't supply it; here callers never supply it → always stamped with UTC ISO-8601 string).
3. `namespace_block = json.dumps({namespace: payload_with_meta})`.
4. Execute:
```sql
UPDATE application
   SET metadata = COALESCE(metadata, '{}'::jsonb) || $1::jsonb,
       updated_at = $2
 WHERE id = $3::uuid
```
params `($1=namespace_block, $2=datetime.now(timezone.utc), $3=app_uuid)`.
> ⚠️ Uses JSONB `||` (shallow merge at top level). **The whole `namespace` sub-object is replaced**, not deep-merged — so callers must pass the full namespace shape (this is why `_extract_*_compliance_metadata` returns the entire block, not a delta). `COALESCE(metadata,'{}')` guards pre-051 NULL rows. Two `datetime.now(timezone.utc)` calls (step 2 inside payload, step 3 as `updated_at`) are independent reads of the clock — microsecond-different is possible and harmless.

### 1.8 `_build_update_sql(projections) -> (sql, params)` (line 1226) — used by activity #3
Builds a single `UPDATE application SET ... WHERE id = $N`:
- Iterate `_SIDE_EFFECT_COLUMNS` (a module-level **ordered tuple** — column order in the generated SQL follows tuple order, NOT dict-insertion order of `projections`). For each `column` present in `projections`:
  - `value = projections[column]`; **if `column in _JSONB_COLUMNS`: `value = json.dumps(value)`**.
  - append `f"{column} = ${idx}"`, `params.append(value)`, `idx += 1`.
- Always append `f"updated_at = ${idx}"`, `params.append(datetime.now(timezone.utc))`, `idx += 1`.
- `where_idx = idx`; `sql = "UPDATE application SET " + ", ".join(assignments) + f" WHERE id = ${where_idx}"`. Return `(sql, params)`. **Caller appends `app_uuid` to params** *after* the call (activity #3: `params.append(app_uuid)`), matching `$where_idx`.
- Relevant subset of `_JSONB_COLUMNS` for activity #3: **`portfolio_score`** is JSONB-serialized; `risk_tier`, `risk_tier_source`, `disposition`, `disposition_source`, `disposition_rationale_ref`, `target_repo_url` are bound as plain strings. (`_NATIVE_COLUMNS` documents datetime/Decimal/list columns but is not consulted by the function — it's documentation; asyncpg binds those natively. None of activity #3's columns are native.)

### 1.9 Observability emit helpers (from `olympus_workflows.utils.execution`)
- `emit_code_step_start(ctx, *, function_name, columns_writable=None) -> uuid.UUID | None`: if `ctx is None` → return `None` (no record). Else read `activity.info().workflow_id` + `.attempt` (on any exception default `""` / `1`); build `payload={"function": function_name}` (+ `columns_written` if `columns_writable` given); call `emit_execution_record(EmitExecutionRecordInput(portfolio_id=ctx.portfolio_id, line_id=ctx.line_id, step_id=ctx.step_id, step_kind=StepKind.CODE, workflow_id, app_id=ctx.app_id or None, wave_id=ctx.wave_id or None, attempt, payload, status=ExecutionStatus.RUNNING))`. Returns the new execution id (or `None`).
- `emit_code_step_complete(execution_id, *, status=COMPLETED, columns_written=None, error=None)`: `payload_merge = {"columns_written": columns_written}` iff `columns_written is not None`; `await update_execution_record(execution_id, status, payload_merge, last_error=error)`. **If `execution_id is None` (ctx was None), `update_execution_record(None, ...)` is still called** — it must no-op on a `None` id (per the helper's own guard, not reproduced here).
- `StepExecutionContext` (types.py:532): dataclass — `portfolio_id: str` (required), `line_id: str` (required), `step_id: str` (required), `app_id: str=""`, `wave_id: str=""`, `input_artifact_paths: list[str]=[]`, `gate_id: str=""`.

---

## 2. `persist_rationalization_capabilities` (def 2049)

### 2.1 Signature & types
```python
@foundry_activity(config=ActivityConfig(enable_observability=True))
async def persist_rationalization_capabilities(
    input: PersistRationalizationCapabilitiesInput,
) -> PersistRationalizationCapabilitiesOutput
```

**`PersistRationalizationCapabilitiesInput`** (types.py:1463) — dataclass:
| field | type | default |
|---|---|---|
| `portfolio_id` | `str` | (required) |
| `wave_id` | `str` | (required) |
| `clustering_plan_json` | `str` | `""` |
| `clustering_plan_artifact_ref` | `str` | `""` |
| `execution_context` | `StepExecutionContext \| None` | `None` |

**`PersistRationalizationCapabilitiesOutput`** (types.py:1489) — dataclass, returned:
| field | type | default |
|---|---|---|
| `portfolio_id` | `str` | (set from input) |
| `wave_id` | `str` | (set from input) |
| `rat_caps_inserted` | `int` | `0` |
| `rat_caps_updated` | `int` | `0` |
| `capability_fk_assignments` | `int` | `0` |
| `capability_splits_created` | `int` | `0` |
| `validation_errors` | `list[str]` | `[]` (default_factory) |

### 2.2 Control flow
1. `exec_id = await emit_code_step_start(input.execution_context, function_name="persist_rationalization_capabilities")`.
2. `out = PersistRationalizationCapabilitiesOutput(portfolio_id=input.portfolio_id, wave_id=input.wave_id)`.
3. **Outer `try:`** (whose `except Exception as exc:` does FAILED-emit + `raise`).
4. **UUID parse (loud — these are workflow inputs):** `portfolio_uuid = uuid.UUID(input.portfolio_id)`; on `(ValueError, TypeError)` → `raise NonRetryableError(f"Invalid portfolio_id: {input.portfolio_id!r}")`. Same for `wave_uuid = uuid.UUID(input.wave_id)` → `NonRetryableError(f"Invalid wave_id: ...")`. ⚠️ These propagate through the wrapper as non-retryable.
5. **Parse plan (quiet — artifact-derived):** `plan = _try_parse_json(input.clustering_plan_json)`. If `plan is None`: append `"clustering plan JSON is empty or unparseable"` to `out.validation_errors`; log info (`extra` has portfolio_id, wave_id, `artifact_ref=input.clustering_plan_artifact_ref`); `await emit_code_step_complete(exec_id, columns_written=[])`; **`return out`** (zero rows, never raises).
6. **Schema validation:** `validation_errors = _validate_rat_cap_clustering_plan(plan)`. If non-empty: `out.validation_errors = validation_errors` (replaces list), log info, `emit_code_step_complete(exec_id, columns_written=[])`, **`return out`**.
7. Extract: `rat_caps = plan.get("rationalization_capabilities") or []`; `assignments = plan.get("capability_assignments") or []`; `splits = plan.get("capability_splits") or []`.
8. `conn = await asyncpg.connect(_db_url())`; **`async with conn.transaction():`** (single txn for all of steps 1–3 below). `finally: await conn.close()`.
9. After the txn block: `await emit_code_step_complete(exec_id, columns_written=[ "rat_caps_inserted={...}", "rat_caps_updated={...}", "capability_fk_assignments={...}", "capability_splits_created={...}" ])` (f-strings with the counts), then `logger.info("rat-cap clustering plan persisted", extra={...})`, **`return out`**.

> ⚠️ **Whole-transaction atomicity:** all UPSERTs, FK sets, and split inserts run in ONE `conn.transaction()`. If anything inside raises (e.g. a CHECK/FK violation asyncpg surfaces), the txn rolls back, the outer `except` emits FAILED, and the error propagates through the wrapper — so the activity is **NOT** purely best-effort once it reaches the DB; only the *pre-DB* parse/validate stage is no-raise. The `validation_errors` accumulated for per-row problems (bad child UUID, etc.) do NOT roll back valid sibling rows — they're skipped via `continue`, the txn still commits.

### 2.3 Step 1 — UPSERT each `rationalization_capability` row
`rat_cap_id_by_index: dict[int, uuid.UUID] = {}`. `for idx, rat_cap in enumerate(rat_caps):`
- `if not isinstance(rat_cap, dict): continue`.
- Field extraction (with normalization):
  - `name = str(rat_cap.get("name") or "").strip()`
  - `description = str(rat_cap.get("description") or "")`
  - `rationale = str(rat_cap.get("rationale") or "")`
  - `evidence_refs = rat_cap.get("evidence_refs") or []`
  - `confidence = rat_cap.get("confidence")` (passed through as-is — number or None; bound to `Numeric(3,2)`)
  - `external_id`: if `isinstance(str)` → `.strip() or None`; else `None`.
  - `existing_id`: if `isinstance(str)` → `.strip() or None`; else `None`.
  - `evidence_refs_json = json.dumps(evidence_refs)`.

**Branch A — `existing_id` present (direct UPDATE on supplied uuid):**
- `existing_uuid = uuid.UUID(existing_id)`; on bad uuid → append `f"rat-cap[{idx}].existing_id is not a valid UUID"`, `continue`.
- Ownership probe: `owner = await conn.fetchval("SELECT portfolio_id FROM rationalization_capability WHERE id = $1", existing_uuid)`.
  - `owner is None` → append `f"rat-cap[{idx}].existing_id {existing_id} not found"`, `continue`.
  - `owner != portfolio_uuid` → append `f"rat-cap[{idx}].existing_id {existing_id} belongs to another portfolio"`, `continue`. (⚠️ cross-portfolio poison defense.)
- `UPDATE` (all 7 columns + updated_at):
```sql
UPDATE rationalization_capability
SET name=$2, description=$3, rationale=$4, evidence_refs=$5::jsonb,
    confidence=$6, wave_id=$7, external_id=$8, updated_at=now()
WHERE id=$1
```
params `($1=existing_uuid, $2=name, $3=description, $4=rationale, $5=evidence_refs_json, $6=confidence, $7=wave_uuid, $8=external_id)`.
- `rat_cap_id_by_index[idx] = existing_uuid`; `out.rat_caps_updated += 1`; `continue`.

**Branch B — `external_id` present (UPSERT on partial unique index):**
```sql
INSERT INTO rationalization_capability (
    portfolio_id, wave_id, external_id, name, description, rationale,
    evidence_refs, confidence)
VALUES ($1,$2,$3,$4,$5,$6,$7::jsonb,$8)
ON CONFLICT (portfolio_id, external_id)
    WHERE external_id IS NOT NULL AND retired_at IS NULL
DO UPDATE SET
    name=EXCLUDED.name, description=EXCLUDED.description,
    rationale=EXCLUDED.rationale, evidence_refs=EXCLUDED.evidence_refs,
    confidence=EXCLUDED.confidence, wave_id=EXCLUDED.wave_id,
    updated_at=now()
RETURNING id, (xmax = 0) AS inserted
```
params `($1=portfolio_uuid, $2=wave_uuid, $3=external_id, $4=name, $5=description, $6=rationale, $7=evidence_refs_json, $8=confidence)`. Captured as `row` via `fetchrow`.
> ⚠️ **`(xmax = 0) AS inserted`** is the canonical Postgres trick: on a fresh INSERT `xmax=0` → `inserted=True`; on the conflict-UPDATE path `xmax≠0` → `False`. This drives the inserted-vs-updated counter below. The `ON CONFLICT ... WHERE` matches the **partial unique index** `ix_rat_cap_portfolio_external_id` (migration 052: `unique, postgresql_where = external_id IS NOT NULL AND retired_at IS NULL`). **On conflict the UPDATE does NOT touch `external_id`** (it's the conflict key) and does NOT touch `retired_at`/`portfolio_id`.

**Branch C — fallback natural key `(portfolio_id, name)` (SELECT-then-INSERT-or-UPDATE):**
- `existing_row = await conn.fetchrow("SELECT id FROM rationalization_capability WHERE portfolio_id=$1 AND name=$2 AND retired_at IS NULL LIMIT 1", portfolio_uuid, name)`.
- If `existing_row is None` → INSERT:
```sql
INSERT INTO rationalization_capability (
    portfolio_id, wave_id, external_id, name, description, rationale,
    evidence_refs, confidence)
VALUES ($1,$2,NULL,$3,$4,$5,$6::jsonb,$7)
RETURNING id, true AS inserted
```
params `($1=portfolio_uuid,$2=wave_uuid,$3=name,$4=description,$5=rationale,$6=evidence_refs_json,$7=confidence)`. (`external_id` hard-coded `NULL`.) `row = fetchrow(...)`.
- Else (found) → UPDATE (note: does **NOT** write `name` or `external_id`):
```sql
UPDATE rationalization_capability
SET description=$2, rationale=$3, evidence_refs=$4::jsonb,
    confidence=$5, wave_id=$6, updated_at=now()
WHERE id=$1
```
params `($1=existing_row["id"],$2=description,$3=rationale,$4=evidence_refs_json,$5=confidence,$6=wave_uuid)`; then `row = {"id": existing_row["id"], "inserted": False}` (synthesized dict, since `conn.execute` returns a status string not a row).
> ⚠️ **Why SELECT-then-write, not ON CONFLICT:** the partial unique index `ix_rat_cap_portfolio_name` has a `WHERE retired_at IS NULL` predicate, which prevents ON CONFLICT *inference* (Postgres can't infer a partial index as the arbiter without naming it, and naming a constraint isn't possible for a partial unique index here). So the natural-key path is read-modify-write *inside the same txn* (relies on the txn + the fact waves don't run concurrently on the same portfolio name — see concurrency note).

**End of all three branches:** `rat_cap_id_by_index[idx] = row["id"]`; `if row.get("inserted"): out.rat_caps_inserted += 1 else: out.rat_caps_updated += 1`. (Branch A `continue`s earlier and never reaches this.)

### 2.4 Step 2 — `capability_assignments` → set `capability.rationalization_capability_id`
`seen_capability_ids: set[uuid.UUID] = set()`. `for asn in assignments:`
- `if not isinstance(asn, dict): continue`.
- `raw_cap_id = asn.get("capability_id")`; `rat_cap_idx = asn.get("rationalization_capability_index")`. `if not isinstance(raw_cap_id, str) or not isinstance(rat_cap_idx, int): continue`. (⚠️ `bool` is an `int` subclass — `True`/`False` would pass `isinstance(int)`; schema prevents it.)
- `cap_uuid = uuid.UUID(raw_cap_id)`; on bad uuid → append `f"assignment.capability_id {raw_cap_id!r} is not a valid UUID"`, `continue`.
- Duplicate guard: `if cap_uuid in seen_capability_ids:` → append `f"capability_id {raw_cap_id} appears more than once in capability_assignments"`, `continue`. Else `seen_capability_ids.add(cap_uuid)`.
- `rat_cap_uuid = rat_cap_id_by_index.get(rat_cap_idx)`; if `None` → append `f"assignment references rationalization_capability_index {rat_cap_idx} which has no resolved row"`, `continue`. (Index resolves only if Step 1 produced a row for that index — a rat-cap that was skipped/non-dict has no entry.)
- UPDATE:
```sql
UPDATE capability
SET rationalization_capability_id=$1, updated_at=now()
WHERE id=$2
```
params `($1=rat_cap_uuid, $2=cap_uuid)`. `result` is asyncpg command tag string.
- `if result and result.endswith(" 1"): out.capability_fk_assignments += 1` else append `f"assignment.capability_id {raw_cap_id} not found in capability table"`.
> ⚠️ **`result.endswith(" 1")`** parses the asyncpg status tag (`"UPDATE 1"` vs `"UPDATE 0"`) to detect whether the row existed. A capability id that's a valid UUID but not in the table yields `"UPDATE 0"` → counted as a validation error, NOT an exception.

### 2.5 Step 3 — `capability_splits` → mint child capability rows
`for split in splits:` (continues using the SAME `seen_capability_ids` set):
- `if not isinstance(split, dict): continue`.
- `raw_parent_id = split.get("parent_capability_id")`; `child_assignments = split.get("child_assignments") or []`. `if not isinstance(raw_parent_id, str): continue`.
- `parent_uuid = uuid.UUID(raw_parent_id)`; bad → append `f"split.parent_capability_id {raw_parent_id!r} is not a valid UUID"`, `continue`.
- Cross-section dup guard: `if parent_uuid in seen_capability_ids:` → append `f"capability_id {raw_parent_id} appears in both capability_assignments and capability_splits"`, `continue`. Else `seen_capability_ids.add(parent_uuid)`. (⚠️ a parent must not also be an assignment target.)
- Parent fetch (to inherit scope): `parent_row = await conn.fetchrow("SELECT id, system_id, kind, external_id FROM capability WHERE id=$1", parent_uuid)`. If `None` → append `f"split.parent_capability_id {raw_parent_id} not found in capability table"`, `continue`.
- `parent_system_id = parent_row["system_id"]`; `parent_kind = parent_row["kind"]`; `parent_external_id = parent_row["external_id"]`.
- `for child in child_assignments:`
  - `if not isinstance(child, dict): continue`.
  - `child_name = str(child.get("name") or "").strip()`; `child_desc = str(child.get("description") or "")`; `child_rat_cap_idx = child.get("rationalization_capability_index")`.
  - `if not child_name or not isinstance(child_rat_cap_idx, int): continue`.
  - `rat_cap_uuid = rat_cap_id_by_index.get(child_rat_cap_idx)`; if `None` → append `f"split.child references rationalization_capability_index {child_rat_cap_idx} which has no resolved row"`, `continue`.
  - INSERT child:
```sql
INSERT INTO capability (
    system_id, name, description, kind, external_id,
    parent_capability_id, split_at, rationalization_capability_id)
VALUES ($1,$2,$3,$4,$5,$6, now(), $7)
```
params `($1=parent_system_id, $2=child_name, $3=child_desc, $4=parent_kind, $5=parent_external_id, $6=parent_uuid, $7=rat_cap_uuid)`. `out.capability_splits_created += 1`.
> ⚠️ **Children inherit `system_id`, `kind`, `external_id` from the parent**; carry their OWN `name`/`description`; `split_at = now()`; `parent_capability_id` pins lineage. **The parent row is never modified** (its record is preserved verbatim; it gets NO rat-cap FK). The child INSERT does NOT set `id` (DB default `gen_random_uuid()`), `created_at`/`updated_at` (DB default `now()`), `primary_disposition`/`secondary_disposition` (NULL), `retired_at` (NULL).
> ⚠️ **External_id collision risk:** children inherit the parent's `external_id`; if non-NULL, the partial unique index `ix_capability_system_external_id (system_id, external_id) WHERE external_id IS NOT NULL` will reject ≥2 children sharing the parent's external_id within the same system → the txn raises and rolls back. In practice split parents are expected to have NULL external_id (multiple NULLs are allowed); a non-NULL parent external_id with ≥2 children is a data-integrity trap. **Reproduce the INSERT verbatim — do not "fix" by NULLing child external_id**, or you change behavior.

### 2.6 Column-mapping tables — activity #1

**Table `rationalization_capability`** (target of UPSERT/UPDATE; types from migration 052):

| Artifact field (`rat_caps[idx].*`) | column (type) | written when | normalization / default |
|---|---|---|---|
| — | `id` UUID PK | INSERT only (Branch B fresh / Branch C insert) | DB `gen_random_uuid()` |
| `input.portfolio_id` (parsed) | `portfolio_id` UUID NOT NULL | INSERT (B/C); **read-only on UPDATE** | `uuid.UUID(...)` |
| `input.wave_id` (parsed) | `wave_id` UUID NULL | INSERT + every UPDATE branch (A/B-conflict/C-update) | `uuid.UUID(...)`; bound `wave_uuid` |
| `external_id` | `external_id` String(64) NULL | Branch A UPDATE writes it; Branch B INSERT writes it (conflict UPDATE does NOT); Branch C insert hard-codes `NULL`, C-update doesn't touch | `str.strip() or None` else `None` |
| `name` | `name` String(255) NOT NULL | Branch A UPDATE + Branch B INSERT + Branch C INSERT. **NOT written by Branch B conflict-UPDATE (it's the EXCLUDED.name, so yes it is) nor by Branch C UPDATE (no)** | `str(... or "").strip()` |
| `description` | `description` Text NOT NULL | all write paths (A,B-insert,B-conflict,C-insert,C-update) | `str(... or "")` |
| `rationale` | `rationale` Text NOT NULL | all write paths | `str(... or "")` |
| `evidence_refs` | `evidence_refs` JSONB NOT NULL | all write paths | `json.dumps(... or [])`, bound `::jsonb` |
| `confidence` | `confidence` Numeric(3,2) NULL | all write paths | passed through (number or None) |
| — | `created_at` timestamptz NOT NULL | INSERT only | DB `now()` |
| — | `updated_at` timestamptz NOT NULL | every write sets `updated_at=now()` | SQL `now()` |
| — | `retired_at` timestamptz NULL | never written here | DB NULL |
| — | `disposition`, `target_service_external_id` | **never written here** (owned by activity #2) | — |

> Clarification on `name` per branch: Branch A UPDATE sets `name=$2`. Branch B INSERT sets it; Branch B's `DO UPDATE SET name=EXCLUDED.name` re-sets it on conflict. Branch C INSERT sets it; **Branch C's UPDATE deliberately omits `name`** (matched the row by name already). CHECK constraints in play: `rationalization_capability_disposition_chk` (not exercised here — disposition untouched), `rationalization_capability_confidence_chk` (`confidence IS NULL OR 0..1`) — a confidence outside [0,1] would violate and roll back the txn (schema validation should have caught it first).

**Table `capability`** — Step 2 UPDATE:

| Source | column | written when |
|---|---|---|
| `rat_cap_id_by_index[asn.rationalization_capability_index]` | `rationalization_capability_id` UUID NULL (FK) | per valid assignment whose target row exists (`UPDATE 1`) |
| — | `updated_at` | same UPDATE sets `updated_at=now()` |

**Table `capability`** — Step 3 INSERT (child rows):

| Source | column | default if absent |
|---|---|---|
| parent's `system_id` | `system_id` UUID NOT NULL | (inherited) |
| `child.name` | `name` String(255) NOT NULL | — |
| `child.description` | `description` Text NULL | `str(... or "")` |
| parent's `kind` | `kind` String(32) NOT NULL | (inherited) |
| parent's `external_id` | `external_id` String(64) NULL | (inherited) |
| `parent_uuid` | `parent_capability_id` UUID NULL (FK→capability.id) | — |
| SQL `now()` | `split_at` timestamptz NULL | — |
| `rat_cap_id_by_index[child.rationalization_capability_index]` | `rationalization_capability_id` UUID NULL (FK) | — |
| — | `id`/`created_at`/`updated_at` | DB defaults |
| — | `primary_disposition`/`secondary_disposition`/`retired_at` | NULL (not in INSERT) |

### 2.7 Idempotency / retries / errors — activity #1
- **Idempotency:** re-running the same plan UPSERTs the same rat-cap rows (Branch A/B/C all converge on the natural key) and re-sets the same FKs (Step 2 `UPDATE` is idempotent). **Step 3 child INSERTs are NOT idempotent** — re-running mints duplicate child rows (no ON CONFLICT, child names aren't unique). ⚠️ A retry of a partially-applied txn is impossible (whole txn is atomic), but a *fresh* re-invocation (new activity attempt after the txn already committed, e.g. workflow replay-then-redrive) would double-insert split children. The clustering plan is meant to be applied once per wave at G-RR submit.
- **Non-retryable:** invalid `portfolio_id`/`wave_id` UUID → `NonRetryableError` (propagates).
- **No-raise (returns `out` with `validation_errors`):** unparseable plan; schema-invalid plan; per-row issues (bad child/assignment/existing UUID, not-found, cross-portfolio, dup) → recorded and skipped, valid rows still commit.
- **Raises through wrapper:** any DB exception inside the txn (FK/CHECK/unique violation, connection drop) → outer `except` emits FAILED → wrapper classifies (asyncpg connection errors → retryable by type-name; constraint violations → non-retryable).

---

## 3. `persist_rationalization_capability_dispositions` (def 2604)

### 3.1 Signature & types
```python
@foundry_activity(config=ActivityConfig(enable_observability=True))
async def persist_rationalization_capability_dispositions(
    input: PersistRationalizationCapabilityDispositionsInput,
) -> PersistRationalizationCapabilityDispositionsOutput
```

**`PersistRationalizationCapabilityDispositionsInput`** (types.py:1508):
| field | type | default |
|---|---|---|
| `portfolio_id` | `str` | (required) |
| `wave_id` | `str` | (required) |
| `disposition_recommendation_json` | `str` | `""` |
| `disposition_recommendation_artifact_ref` | `str` | `""` |
| `execution_context` | `StepExecutionContext \| None` | `None` |

**`PersistRationalizationCapabilityDispositionsOutput`** (types.py:1532):
| field | type | default |
|---|---|---|
| `portfolio_id` | `str` | (set from input) |
| `wave_id` | `str` | (set from input) |
| `rat_caps_disposition_set` | `int` | `0` |
| `rat_caps_target_service_set` | `int` | `0` |
| `rat_caps_not_found` | `int` | `0` |
| `validation_errors` | `list[str]` | `[]` |

### 3.2 Control flow
1. `exec_id = emit_code_step_start(input.execution_context, function_name="persist_rationalization_capability_dispositions")`.
2. `out = ...Output(portfolio_id=input.portfolio_id, wave_id=input.wave_id)`.
3. Outer `try:` (FAILED-emit + `raise` on `except`).
4. UUID parse: `portfolio_uuid = uuid.UUID(input.portfolio_id)` (→ `NonRetryableError` on fail). `uuid.UUID(input.wave_id)` is parsed **for validation only — the result is discarded** (wave_id is not used in any query in this activity). ⚠️ This is intentional: wave scope is implicit (rat-caps already belong to the wave's portfolio); the parse is a guard against a malformed workflow input.
5. `payload = _try_parse_json(input.disposition_recommendation_json)`. If `None`: append `"disposition recommendation JSON is empty or unparseable"`, log, `emit_code_step_complete(exec_id, columns_written=[])`, `return out`.
6. `validation_errors = _validate_disposition_recommendation(payload)`. If non-empty: `out.validation_errors = ...`, log, complete `[]`, `return out`.
7. `entries = payload.get("rationalization_capability_dispositions") or []`.
8. `conn = await asyncpg.connect(_db_url())`; `async with conn.transaction():` (single txn); `finally: await conn.close()`.
9. After txn: `emit_code_step_complete(exec_id, columns_written=["rat_caps_disposition_set={...}", "rat_caps_target_service_set={...}", "rat_caps_not_found={...}"])`; `logger.info("rat-cap dispositions persisted", extra={...})`; `return out`.

### 3.3 Per-entry loop
`seen_ids: set[uuid.UUID] = set()`. `for idx, entry in enumerate(entries):`
- `if not isinstance(entry, dict): continue`.
- **primary disposition gate:** `primary = entry.get("primary_disposition")`; `if not isinstance(primary, str) or primary not in _DISPOSITION_VALUES:` → append `f"entry[{idx}].primary_disposition {primary!r} is not a valid 5R outcome"`, `continue`. (Belt-and-suspenders over the schema enum.)
- `raw_id = entry.get("rationalization_capability_id")`; `raw_external_id = entry.get("rationalization_capability_external_id")`. `target_uuid: uuid.UUID | None = None`.

**Resolution path 1 — by id:** if `isinstance(raw_id, str) and raw_id.strip()`:
- `target_uuid = uuid.UUID(raw_id.strip())`; on bad uuid → append `f"entry[{idx}].rationalization_capability_id {raw_id!r} is not a valid UUID"`, `continue`.
- Ownership probe (also gates on not-retired):
```sql
SELECT portfolio_id FROM rationalization_capability
WHERE id = $1 AND retired_at IS NULL
```
`owner = fetchval(..., target_uuid)`.
  - `owner is None` → `out.rat_caps_not_found += 1`; **`target_uuid = None`** (falls through to external-id fallback). ⚠️ Note: counts not-found here, but if the fallback later resolves, the row is still updated — the counter is NOT decremented (so `rat_caps_not_found` can over-count when id misses but external_id hits).
  - `owner != portfolio_uuid` → append `f"entry[{idx}].rationalization_capability_id {raw_id} belongs to another portfolio"`, `continue` (hard skip; no fallback).

**Resolution path 2 — fallback by `(portfolio_id, external_id)`:** if `target_uuid is None and isinstance(raw_external_id, str) and raw_external_id.strip()`:
```sql
SELECT id FROM rationalization_capability
WHERE portfolio_id = $1 AND external_id = $2 AND retired_at IS NULL
LIMIT 1
```
`target_uuid = fetchval(..., portfolio_uuid, raw_external_id.strip())`. If still `None` → `out.rat_caps_not_found += 1`.

- **Unresolved:** `if target_uuid is None: continue` (already counted).
- **Dedup:** `if target_uuid in seen_ids:` → append `f"rationalization_capability_id {target_uuid} appears more than once in rationalization_capability_dispositions"`, `continue`. Else `seen_ids.add(target_uuid)`.
- **target_service normalization:** `target_service = entry.get("target_service_external_id")`; if `isinstance(str)` → `.strip() or None`; else `None`.

**Conditional UPDATE:**
- If `target_service is not None`:
```sql
UPDATE rationalization_capability
SET disposition = $2, target_service_external_id = $3, updated_at = now()
WHERE id = $1
```
params `($1=target_uuid, $2=primary, $3=target_service)`. `out.rat_caps_target_service_set += 1`.
- Else:
```sql
UPDATE rationalization_capability
SET disposition = $2, updated_at = now()
WHERE id = $1
```
params `($1=target_uuid, $2=primary)`. (⚠️ **`target_service_external_id` column is left UNTOUCHED** — a NULL target_service does NOT clobber a value a later `capability-consolidation-advisor` may set at G-DA.)
- **Both branches then:** `out.rat_caps_disposition_set += 1`.
> ⚠️ `rat_caps_disposition_set` counts BOTH branches; `rat_caps_target_service_set` counts only the target-service branch. They are not mutually exclusive (a target-service write increments both).
> ⚠️ Neither branch checks the asyncpg command tag — since `target_uuid` was just confirmed to exist (id-path) or selected (external-path), `WHERE id=$1` always matches exactly one live row.

### 3.4 Column-mapping table — activity #2

**Table `rationalization_capability`** (UPDATE only — never inserts):

| Artifact field (`entries[idx].*`) | column (type) | written when | normalization |
|---|---|---|---|
| `primary_disposition` | `disposition` String(64) NULL | **every** successful entry (both branches) | must be in `_DISPOSITION_VALUES`; bound verbatim (PascalCase); satisfies `rationalization_capability_disposition_chk` |
| `target_service_external_id` | `target_service_external_id` String(64) NULL | **only when entry carries a non-empty string** (the `target_service is not None` branch) | `str.strip() or None`; left untouched otherwise |
| — | `updated_at` timestamptz | every successful entry (`updated_at=now()`) | SQL `now()` |
| `rationalization_capability_id` / `rationalization_capability_external_id` | (used to **resolve** `WHERE id=$1`, not written) | — | id parsed + ownership/retired-checked; external_id used in fallback SELECT |

Columns explicitly **NOT** touched: `portfolio_id`, `wave_id`, `external_id`, `name`, `description`, `rationale`, `evidence_refs`, `confidence`, `created_at`, `retired_at`.

### 3.5 Idempotency / retries / errors — activity #2
- **Idempotent:** every write is an UPDATE keyed by id; re-running sets the same `disposition`/`target_service` values. Safe to redrive (subject to whole-txn atomicity).
- **Non-retryable:** invalid `portfolio_id`/`wave_id` UUID.
- **No-raise:** unparseable/schema-invalid payload; per-entry: invalid primary disposition, invalid id UUID, cross-portfolio id, dup id, unresolvable (id+external both miss) → recorded/counted, skipped.
- **Raises through wrapper:** DB exception in txn → FAILED-emit → wrapper classifies.

---

## 4. `persist_rationalization_side_effects` (def 2977)

### 4.1 Signature & types
```python
@foundry_activity(config=ActivityConfig(enable_observability=True))
async def persist_rationalization_side_effects(
    input: PersistRationalizationSideEffectsInput,
) -> PersistRationalizationSideEffectsResult
```

**`PersistRationalizationSideEffectsInput`** (types.py:1594):
| field | type | default |
|---|---|---|
| `app_id` | `str` | (required) |
| `classification_json` | `str` | `""` |
| `portfolio_score_json` | `str` | `""` |
| `disposition_recommendation_json` | `str` | `""` |
| `disposition_rationale_ref` | `str` | `""` |
| `tier_1_approved` | `bool` | `False` |
| `execution_context` | `StepExecutionContext \| None` | `None` |

**`PersistRationalizationSideEffectsResult`** (types.py:1615):
| field | type | default |
|---|---|---|
| `app_id` | `str` | (set from input) |
| `risk_tier` | `str` | `""` |
| `risk_tier_source` | `str` | `""` |
| `disposition` | `str` | `""` |
| `disposition_source` | `str` | `""` |
| `portfolio_score_persisted` | `bool` | `False` |

### 4.2 Extractor helpers (defined in this range)

**`_extract_classification_side_effects(classification, *, tier_1_approved) -> dict`** (line 2888):
- not-dict → `{}`.
- `risk = classification.get("risk_tier")`; `risk_int = int(risk) if risk is not None else None` (on `(TypeError, ValueError)` → `None`). Accepts int OR numeric-string shape.
- `if risk_int in (1,2,3):` → `out["risk_tier"] = str(risk_int)`; **`out["risk_tier_source"] = "confirmed" if (risk_int == 1 and tier_1_approved) else "auto"`**.
- Returns `{}` or `{"risk_tier": "1|2|3", "risk_tier_source": "confirmed|auto"}`. (⚠️ Discovery owns `archetype`/`complexity_tier` — explicitly NOT extracted here even if present.)

**`_extract_portfolio_score_side_effects(score) -> dict`** (line 2926):
- not-dict → `{}`. `scores = score.get("scores")`; if `not isinstance(scores, dict) or not scores` → `{}` (requires ≥1 dimension under `scores`).
- Else returns **`{"portfolio_score": score}`** — the *entire* input payload is persisted as the JSONB value (not just `scores`).

**`_extract_disposition_side_effects(recommendation, *, rationale_ref) -> dict`** (line 2945):
- not-dict → `{}`. `disposition = recommendation.get("recommended_disposition") or recommendation.get("disposition")` (accepts either key; `recommended_disposition` preferred).
- `if not isinstance(disposition, str) or disposition not in _DISPOSITION_VALUES: return {}`.
- `out = {"disposition": disposition, "disposition_source": "auto"}`; **if `rationale_ref` (truthy): `out["disposition_rationale_ref"] = rationale_ref`**.
- Returns that dict. (⚠️ `disposition_source` is ALWAYS `"auto"` here — overridden/confirmed sources would be set by the gate-review flow which is "not yet wired" per the source comment.)

### 4.3 Control flow
1. `exec_id = emit_code_step_start(input.execution_context, function_name="persist_rationalization_side_effects")`.
2. Outer `try:` (FAILED-emit + `raise`).
3. `app_uuid = uuid.UUID(input.app_id)`; on `(ValueError, TypeError)` → `raise NonRetryableError(f"Invalid app_id: {input.app_id!r}")`.
4. Parse three payloads: `classification = _try_parse_json(input.classification_json)`; `portfolio_score = _try_parse_json(input.portfolio_score_json)`; `recommendation = _try_parse_json(input.disposition_recommendation_json)`. (No schema validation here — best-effort extraction only.)
5. Build `projections: dict = {}` via three `.update()` calls in order: classification extractor (passing `tier_1_approved=input.tier_1_approved`), portfolio-score extractor, disposition extractor (passing `rationale_ref=input.disposition_rationale_ref`).
6. `compliance_metadata = _extract_rationalization_compliance_metadata(classification, recommendation)`.
7. **Empty short-circuit:** `if not projections and not compliance_metadata:` → log `"persist_rationalization_side_effects: nothing extractable"` (extra `app_id`); `emit_code_step_complete(exec_id, columns_written=[])`; **`return PersistRationalizationSideEffectsResult(app_id=input.app_id)`** (all-default result).
8. `conn = await asyncpg.connect(_db_url())`; in `try` (with `finally: await conn.close()`):
   - **`if projections:`** `sql, params = _build_update_sql(projections)`; `params.append(app_uuid)`; `await conn.execute(sql, *params)`.
   - **`if compliance_metadata:`** `await _merge_application_metadata(conn, app_uuid, "compliance", compliance_metadata)`.
   > ⚠️ **NO `conn.transaction()` here.** Unlike activities #1 and #2, the two writes (column UPDATE + metadata JSONB merge) run as **two independent autocommit statements** on the connection. If the metadata merge fails after the column UPDATE committed, the column UPDATE is NOT rolled back. They are also two separate `UPDATE application ... WHERE id` statements (the projection UPDATE sets `updated_at` to one clock read; the metadata merge sets `updated_at` to another). Reproduce as two statements, not one txn.
9. `columns_written = sorted(projections.keys())`; `if compliance_metadata: columns_written.append("metadata.compliance")`. (⚠️ sorted keys of projections, THEN append the literal `"metadata.compliance"` — so it's last regardless of sort.)
10. `logger.info("rationalization side-effects persisted", extra={"app_id", "columns_written"})`; `emit_code_step_complete(exec_id, columns_written=columns_written)`.
11. **Return** populated result:
```python
PersistRationalizationSideEffectsResult(
    app_id=input.app_id,
    risk_tier=str(projections.get("risk_tier", "")),
    risk_tier_source=str(projections.get("risk_tier_source", "")),
    disposition=str(projections.get("disposition", "")),
    disposition_source=str(projections.get("disposition_source", "")),
    portfolio_score_persisted="portfolio_score" in projections,
)
```

### 4.4 Column-mapping table — activity #3

**Table `application`** (single conditional UPDATE via `_build_update_sql`; only keys present in `projections` are emitted; `updated_at` always; `WHERE id=$N` = `app_uuid`). Column types from migrations 002 / 024 / 029:

| `projections` key | column (type) | source / when written | value form |
|---|---|---|---|
| `risk_tier` | `risk_tier` `risk_tier_enum('1','2','3')` NULL | `_extract_classification_side_effects` when `risk_tier ∈ {1,2,3}` | str `"1"/"2"/"3"` |
| `risk_tier_source` | `risk_tier_source` `tier_source_enum('auto','confirmed','overridden')` NULL | same; `"confirmed"` iff tier==1 & `tier_1_approved`, else `"auto"` | str |
| `portfolio_score` | `portfolio_score` JSONB NULL | `_extract_portfolio_score_side_effects` when `score.scores` is a non-empty dict | **`json.dumps(score)`** (whole payload; in `_JSONB_COLUMNS`) |
| `disposition` | `disposition` `disposition_enum` (7 values) NULL | `_extract_disposition_side_effects` when `recommended_disposition`/`disposition` ∈ `_DISPOSITION_VALUES` | str (PascalCase) |
| `disposition_source` | `disposition_source` String(16) NULL | same extractor (paired) | always `"auto"` |
| `disposition_rationale_ref` | `disposition_rationale_ref` Text NULL | same extractor, **only if `input.disposition_rationale_ref` truthy** | str |
| (always) | `updated_at` timestamptz | `_build_update_sql` always appends | `datetime.now(timezone.utc)` |

> Columns Rationalization does NOT own / not written by this activity (documented in source for reviewer clarity): `archetype`, `archetype_source`, `complexity_tier`, `complexity_tier_source` (Discovery owns). Also `target_repo_url`, `data_*`, `extraction_*`, etc. are in `_SIDE_EFFECT_COLUMNS` but never appear in this activity's `projections`, so never written.

**Table `application` — `metadata` JSONB merge** (via `_merge_application_metadata(..., "compliance", compliance_metadata)`):

| `compliance_metadata` key | JSON path written | source | when |
|---|---|---|---|
| `source_line` | `metadata.compliance.source_line` | literal `"Rationalization"` | always (when block non-empty) |
| `risk_tier` | `metadata.compliance.risk_tier` | `classification.risk_tier`/`.tier` if str ∈ {"1","2","3"} | when classification carries a valid tier |
| `status` | `metadata.compliance.status` | `"needs-review"` | only when tier == `"1"` |
| `cato_state` | `metadata.compliance.cato_state` | `"transition"` for Replace/Consolidate/Rearchitect; `"inheriting"` for Retain | when `recommendation.recommended_disposition` matches |
| `last_assessed` | `metadata.compliance.last_assessed` | `datetime.now(timezone.utc).isoformat()` | always stamped by `_merge_application_metadata` (caller never supplies it) |
| (always) | `application.updated_at` | `datetime.now(timezone.utc)` | the merge UPDATE sets it |

SQL of the merge (repeat): `UPDATE application SET metadata = COALESCE(metadata,'{}'::jsonb) || $1::jsonb, updated_at = $2 WHERE id = $3::uuid` with `$1 = json.dumps({"compliance": <block+last_assessed>})`.
> ⚠️ The block is dropped entirely (`{}`) if `_extract_rationalization_compliance_metadata` produced only `source_line` (no tier-1, no transition/inheriting disposition). In that case `compliance_metadata` is falsy → the merge is skipped → `metadata.compliance` untouched → `"metadata.compliance"` NOT appended to `columns_written`.

### 4.5 Idempotency / retries / errors — activity #3
- **Idempotent:** the column UPDATE is keyed by id with deterministic values; the metadata merge replaces `metadata.compliance` wholesale (refreshing `last_assessed` each run). Re-runnable. **But not transactional** (see ⚠️ above) — a crash between the two statements leaves columns updated, metadata stale (or vice-versa not possible since columns write first).
- **Non-retryable:** invalid `app_id` UUID.
- **No-raise:** all three input JSONs unparseable/empty → extractors return `{}`/`{}`, `compliance_metadata` empty → empty short-circuit returns default result (no DB writes).
- **Raises through wrapper:** DB exception on either statement → FAILED-emit → wrapper classifies (e.g. `disposition_enum` violation if a value somehow bypassed `_DISPOSITION_VALUES` — can't happen given the gate; an enum cast error would be non-retryable).

---

## 5. Concurrency / ordering notes spanning all three

- ⚠️ **No advisory locks; relies on wave-serial execution.** Activity #1's Branch C (SELECT-then-write on `(portfolio_id, name)`) is a read-modify-write that is only race-safe because waves are not expected to cluster the same portfolio concurrently. Two concurrent invocations could both SELECT-miss and both INSERT → the partial unique index `ix_rat_cap_portfolio_name` then raises on the second commit (txn rollback → wrapper). This is acceptable (loud failure) but a rebuild MUST keep the partial unique index so the race fails closed rather than silently duplicating.
- ⚠️ **`emit_code_step_*` are fire-through-DB side effects** outside the main asyncpg connection (they open their own connection inside `execution.py`). A failure to emit observability does NOT fail the activity body (the body's own conn is separate), but an exception raised by `emit_code_step_complete` on the success path WOULD propagate (it's `await`ed before `return`). Treat emit failures as activity failures on the happy path.
- ⚠️ **Counters are observability only** — they're packed into `emit_code_step_complete(columns_written=[...])` as `"key=value"` strings (NOT structured), and returned on the dataclass. The dashboard reads the dataclass; the execution record stores the string list.
- **Decimal import:** module imports `from decimal import Decimal` (line 22) — used by sibling activities' native columns, not by these three. `confidence` numbers flow through as Python `float`/`int` to a `Numeric(3,2)` column (asyncpg coerces).

---

## 6. Undetermined / cross-file
- The `*_lineage` tables named in the task hint (`capability_lineage`, `business_domain_lineage`, `system_lineage`, `application_lineage`) are **not written anywhere in lines 2048–3252**. `application_lineage` is written by `persist_architecture_side_effects` (def at line 3253, the first activity after this range — sibling spec) and by `create_target_app_and_repo` (file 6). The migration-050 lineage tables (`capability_lineage`/`system_lineage`) ARE written — by `realize_target_state_grain` (file 6, def 7005). `business_domain_lineage` has no writer in this module. Capability *splits* in this range are expressed via `capability.parent_capability_id`/`split_at`, **not** a lineage table — this is the intended design per migration 052.
- `_SIDE_EFFECT_COLUMNS` is a large module tuple (defined at lines **791–874**, outside this range, in the file-0 spec's territory). Activity #3 only ever populates the subset listed in §4.4; the full tuple is reproduced/owned by the file-0 spec. The exact full ordering matters only for the generated SQL column order, which is cosmetic (asyncpg binds positionally).
