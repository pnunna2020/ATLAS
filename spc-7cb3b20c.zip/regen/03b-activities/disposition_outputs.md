# Activity Group: `disposition_outputs` — Atomic Regeneration Spec

Source of truth: `/Users/pnunna/Documents/GitHub/foundry/temporal/olympus_workflows/activities/disposition_outputs.py` (578 lines).

Module purpose (P5-S13 / W12): every disposition workflow's terminal step emits the canonical `disposition-output.json` "what did this application become" record. This module provides (a) **pure, side-effect-free synthesis helpers** that build the disposition-output **envelope + payload** dict (called by workflow *code steps* `bundle-pre-gate-evidence` and `bundle-post-gate-evidence`, NOT by Temporal activities), and (b) **exactly one Temporal activity**, `emit_disposition_output_bundle`, which JSON-serialises a bundle, validates it against the JSON-Schema envelope, and commits it to Git on the workflow's working branch.

> **SCOPE NOTE — NO PERSIST/PROJECTION FUNCTIONS IN THIS FILE.** This module contains **no `persist_*` / no DB-projection activity**. It writes to **Git only** (`GitService.commit_file`). There is no SQL, no DB cursor, no table write anywhere in `disposition_outputs.py`. The DB projection of a disposition-output artifact into Postgres rows (if any) is performed by a *different* activity group (the projection activities) reading the committed `disposition-output.json` from Git — it is out of scope for this file. The persist-mapping-table requirement in the task does not apply here because no persist function exists; this is called out explicitly so the gate does not expect a phantom mapping table. The only "artifact → store" mapping present is **dict → JSON file → Git commit**, reproduced in full below.

---

## 0. The `@foundry_activity` wrapper (applies to `emit_disposition_output_bundle`)

Source: `/private/var/folders/qs/dwcdl18n351cyz88x2tc9w3w0000gp/T/tmp.2xQMcqnDWM/foundry_temporal/activities.py` lines 107–165.

`@foundry_activity(config=ActivityConfig(...), name=None, **activity_kwargs)` returns a decorator that wraps the user coroutine `func` and:

1. Applies `@activity.defn(name=name, **activity_kwargs)` over a `@wraps(func)` async `wrapper`. So this **IS** a real Temporal activity definition. **GOTCHA:** a rebuild using bare `@activity.defn` loses everything in steps 2–4 below. You MUST replicate the wrapper.
2. **Observability** (when `config.enable_observability` is True — it is True here): on entry logs `f"Activity {activity_name} starting"` via `get_logger()` with `extra={"inputs": args if config.log_inputs else None}`; on success logs `f"Activity {activity_name} completed"` with `extra={"outputs": result if config.log_outputs else None}`. `activity_name = name or func.__name__` → here `"emit_disposition_output_bundle"`. For this activity `log_inputs`/`log_outputs` default to **False**, so the `inputs`/`outputs` extras are `None`.
3. **Error wrapping** (when `config.enable_error_wrapping` is True — defaults True; this activity does not override it, so True): on any exception it logs `f"Activity {activity_name} failed: {error}"` then:
   - if `isinstance(error, (WorkflowError, ApplicationError))` → `raise` (re-raise unchanged, preserving the original retryability flag);
   - elif `_is_retryable_error(error)` → `raise RetryableError(f"Retryable error in {activity_name}: {error}") from error`;
   - else → `raise NonRetryableError(f"Non-retryable error in {activity_name}: {error}") from error`.
4. `_is_retryable_error(error)` (activities.py:168–183) classifies by **substring match on `str(type(error)).lower()`** against: `timeout, connection, network, temporary, unavailable, overload, busy, throttle, rate_limit`. Match → retryable; else non-retryable.

**Consequence for this activity.** `_validate_bundle` raises `NonRetryableError` (a `WorkflowError` subclass) → re-raised unchanged by branch (a) → Temporal sees `non_retryable=True` and does NOT retry. A `GitServiceError` raised by `commit_file` is **not** a `WorkflowError`/`ApplicationError`; its class string `"...gitserviceerror..."` matches none of the retryable patterns → wrapped as **`NonRetryableError`**. **GOTCHA:** transient GitHub failures surfaced as `GitServiceError` are therefore classified **non-retryable** here, because the substrings don't match. (Network blips raised as `httpx`/`ConnectionError` types *would* match `connection`/`timeout` and become `RetryableError` — but `GitService.commit_file` converts GitHub failures into `GitServiceError`, so in practice this activity does not auto-retry on GitHub errors.)

**Error class hierarchy** (foundry_temporal/errors.py): `WorkflowError(ApplicationError)` with `__init__(message, non_retryable=True)`; `RetryableError(WorkflowError)` sets `non_retryable=False`; `NonRetryableError(WorkflowError)` sets `non_retryable=True`. `ApplicationError` is `temporalio.exceptions.ApplicationError`.

**No `ActivityConfig` timeouts/retry_policy are set** on this activity (only `enable_observability=True`). Therefore start_to_close / schedule_to_close / heartbeat timeouts and the RetryPolicy come **entirely from the calling workflow's `execute_activity(...)` options**, not from the decorator. The decorator's `config.retry_policy` is `None` here.

---

## 1. Activity: `emit_disposition_output_bundle`

**Decorator:** `@foundry_activity(config=ActivityConfig(enable_observability=True))` — disposition_outputs.py:538.
**Temporal activity name:** `emit_disposition_output_bundle` (function name; `name` not overridden).
**Signature:** `async def emit_disposition_output_bundle(input: EmitDispositionOutputBundleInput) -> EmitDispositionOutputBundleResult` (lines 539–541).

### 1.1 Input type — `EmitDispositionOutputBundleInput` (dataclass)
Source: `temporal/olympus_workflows/types.py:2606–2620`. **EVERY field, in order, all required (no defaults):**

| Field | Type | Meaning |
|---|---|---|
| `repo` | `str` | Target repo slug/URL override (the wave's artifact repo). Passed to `_build_git_service(repo_override=...)`. |
| `branch` | `str` | The workflow's working branch the bundle is committed to. |
| `portfolio_id` | `str` | Portfolio UUID; used in the committed path. |
| `app_id` | `str` | Application UUID; used in path + commit message. |
| `bundle` | `dict` | The full disposition-output envelope dict (typically produced by `bundle_pre_gate_evidence` / `bundle_post_gate_evidence`). MUST conform to `schemas/dispositions/disposition-output.schema.json`. |

### 1.2 Output type — `EmitDispositionOutputBundleResult` (dataclass)
Source: `types.py:2624–2628`.

| Field | Type | Source |
|---|---|---|
| `path` | `str` | `result.path` returned by `commit_file` (== the path we passed in). |
| `commit_sha` | `str` | `result.commit_sha` from the new commit. |

### 1.3 Exact body (reproduce line-for-line semantics; lines 549–578)

```
bundle = input.bundle
_validate_bundle(bundle)                       # raises NonRetryableError on schema failure (see §2)

path = _artifact_path(input.portfolio_id, input.app_id)
# == f"dispositions/{portfolio_id}/{app_id}/disposition-output.json"   (line 534-535)

content = json.dumps(bundle, indent=2, sort_keys=True) + "\n"
# ^ pretty-print: 2-space indent, KEYS SORTED, trailing newline appended.

svc = _build_git_service(repo_override=input.repo)   # §3
result = svc.commit_file(
    branch=input.branch,
    path=path,
    content=content,
    commit_message=(
        f"{input.app_id}: disposition-output bundle "
        f"({bundle.get('disposition', '?')}) [P5-S13 / W12]"
    ),
)
logger.info(
    "disposition_output_bundle_emitted",
    extra={
        "app_id": input.app_id,
        "portfolio_id": input.portfolio_id,
        "disposition": bundle.get("disposition"),
        "path": result.path,
        "commit_sha": result.commit_sha,
    },
)
return EmitDispositionOutputBundleResult(path=result.path, commit_sha=result.commit_sha)
```

**Exact-shape facts an identical rebuild MUST honour:**
- **Serialisation:** `json.dumps(bundle, indent=2, sort_keys=True) + "\n"`. **GOTCHA:** `sort_keys=True` — the on-disk JSON has keys in alphabetical order, NOT in the insertion order of the envelope/payload builders. A rebuild that omits `sort_keys=True` or the trailing `"\n"` produces a byte-different commit and breaks any downstream content hash / diff expectation.
- **Commit message format (exact):** `"{app_id}: disposition-output bundle ({disposition}) [P5-S13 / W12]"`, where `{disposition}` is `bundle.get('disposition', '?')` — literally `"?"` when the key is absent. (Note: if absent, `_validate_bundle` would already have failed since `disposition` is a required envelope field; the `'?'` default is a defensive fallback only reachable if validation somehow passes without it, which the schema forbids.)
- **Path is computed from `portfolio_id`/`app_id`**, NOT taken from the bundle's `portfolio_id`/`application_id`. **GOTCHA:** if `input.portfolio_id`/`input.app_id` disagree with the bundle's own `portfolio_id`/`application_id`, the file lands at the *input*-derived path while carrying the *bundle*-derived ids inside. No reconciliation/assertion is performed.
- **Return path == input path** (`commit_file` echoes the `path` it received in `CommitResult.path`).

### 1.4 Idempotency
- Idempotent **per (repo, branch, path, content)** at the Git layer: `commit_file` creates the file if absent, else updates it (see §3). Re-running with the same bundle on the same branch produces a new commit only if content changed; identical content re-commit still produces a new commit SHA via the Contents API update path (GitHub creates a commit even for identical content via `update_file` only if the blob differs — if identical, PyGithub/GitHub returns the existing; behaviorally the activity returns *a* sha). Treat as "converges to the same file state", not "no-op". The activity itself holds no local state.
- No DB write, no PR, no merge.

---

## 2. Validation: `_validate_bundle(bundle: dict) -> None` (lines 499–531) + schema-store loader

This is the gate between the in-memory bundle and the Git write. Reproduce exactly:

1. `envelope_path = _DISPOSITION_SCHEMAS_DIR / "disposition-output.schema.json"`.
   - `_REPO_ROOT = Path(__file__).resolve().parents[3]` (line 480) — walk up **3** parents from `temporal/olympus_workflows/activities/disposition_outputs.py` → repo root `/Users/pnunna/Documents/GitHub/foundry`. **GOTCHA:** `parents[3]` is brittle to relocating this file; it is chosen so schemas resolve identically in CI, worktrees, and local dev. Rebuild must preserve the same relative depth (`activities/` → `olympus_workflows/` → `temporal/` → repo root = 3 hops).
   - `_DISPOSITION_SCHEMAS_DIR = _REPO_ROOT / "schemas" / "dispositions"` (line 481).
2. If `envelope_path` does **not** exist → `raise NonRetryableError("disposition-output schema not found at {envelope_path}. Check your repo layout.")`.
3. Load envelope: `json.load(open(envelope_path))`.
4. `store = _load_schema_store()` (lines 484–496): iterate `_DISPOSITION_SCHEMAS_DIR.glob("*.schema.json")`; for each, `json.load` it, read `schema.get("$id")`, and if `$id` is truthy set `store[$id] = schema`. Returns `{}` if the dir does not exist. **This is how payload `$ref`s resolve** (each `{label}-output.schema.json` registers under its own `$id`).
5. Build `resolver = RefResolver(base_uri=envelope_schema.get("$id", envelope_path.as_uri()), referrer=envelope_schema, store=store)`.
   - `base_uri` is the envelope's `$id` (`https://olympus.framework/schemas/dispositions/disposition-output.schema.json`) when present, else the file URI.
   - **GOTCHA — `jsonschema.RefResolver` is deprecated** in modern `jsonschema` but is what this code uses; a rebuild must use the same resolver+store mechanism (or an equivalent `referencing`-based registry seeded with the same `$id`→schema map) to get identical `$ref` resolution behavior.
6. `validator = Draft202012Validator(envelope_schema, resolver=resolver)`; `errors = list(validator.iter_errors(bundle))`.
7. If `errors` empty → `return` (valid).
8. Else build up to **5** error lines: for each `err` in `errors[:5]`: `f"  {err.json_path}: {err.message}"` (two leading spaces). Raise:
   `NonRetryableError("disposition-output bundle failed schema validation ({len(errors)} error(s)):\n" + "\n".join(lines))`.
   - **GOTCHA:** the count in the message is the **total** error count (`len(errors)`), but only the **first 5** are detailed. Preserve both: total in the header, first 5 in the body.

### 2.1 The envelope schema contract (what validation enforces)
Source: `schemas/dispositions/disposition-output.schema.json`. `$schema` = Draft 2020-12. **`additionalProperties: false`** at the top level. **Required top-level keys:** `application_id, application_name, portfolio_id, wave_id, disposition, status, started_at, completed_at, disposition_decision_ref, approvals, realized_net_impact, payload`.

Field constraints the synthesised bundle must satisfy:
- `application_id`, `portfolio_id`, `wave_id`: `string` + `format: uuid`. `application_name`: `string`, `minLength: 1`.
- `disposition`: enum `["Retire","Retain","Refactor","Rearchitect","Replace","Replatform","Consolidate"]`.
- `status`: enum **`["completed","partial","rolled-back","abandoned"]`**. ⚠️ **GOTCHA:** the *workflow code steps* set `status` to `"in_progress"` (pre-gate, `_base_envelope` line 411) or `"plan_approved"` (Retain post-G-DE-1, per docstring) — **neither is in the schema enum**. The pre-gate bundle is therefore **NOT schema-valid as-is** and would FAIL `_validate_bundle`. This activity is only called with bundles whose `status` is `"completed"` (post-gate non-Retain) or whose status has been normalised by the workflow to a schema-valid value before calling `emit_disposition_output_bundle`. The pure pre-gate/`plan_approved` bundles are committed via the workflow's `write_artifact` step (which does NOT run `_validate_bundle`), not via this activity. Capture this divergence: the helpers emit statuses the envelope enum does not list; only schema-valid statuses survive this activity.
- `started_at`, `completed_at`: `string` + `format: date-time`. Both **required** (so `completed_at: null` from a pre-gate bundle fails `format` → another reason pre-gate bundles don't pass this activity).
- `disposition_decision_ref`: `string`, `minLength: 1` (empty string fails — see §5 note on `wave_id`-less envelopes).
- `approvals`: array, `minItems: 1`; each item `{gate, approved_at, approved_by, record_ref}` all required, `additionalProperties: false`; `gate` enum `["G-DE-1","G-DE-2","G-04a","G-04b","G-04c","G-V1","G-V2","G-V3","G-DP-1","G-DP-2"]`; `approved_at` date-time; `approved_by`/`record_ref` `minLength: 1`. ⚠️ **GOTCHA:** `minItems: 1` means an **empty `approvals` array fails validation**. A pre-gate bundle with `approvals=[]` fails here.
- `realized_net_impact`: object, `additionalProperties: false`, required `[tco_delta, users_affected_actual, users_affected_estimate_ref]`. `tco_delta` required `[annual_savings_usd, one_time_cost_usd, baseline_ref]` (each `number|null`, `baseline_ref` `string|null` with `minLength:1` when string). `users_affected_actual`: `integer|null`, `minimum: 0`. `users_affected_estimate_ref`: `string|null`.
- `payload`: object, required `[disposition]` (a `string`). Discriminated by top-level `disposition`.
- **`allOf` cross-check:** for each of the 7 disposition labels, if top-level `disposition == LABEL` then `payload.disposition` must `const == LABEL`. So the payload's `"disposition"` must equal the envelope's. (Refactor/Rearchitect are listed in the enum/allOf but are **not built by this module** — `_build_payload` raises `ValueError` for them, see §4.7.)

**GOTCHA:** the envelope schema declares only `payload.disposition` as required and does NOT itself `$ref` the per-label payload schemas; the `store` of `{label}-output.schema.json` is loaded so that *if* the envelope (or a payload sub-schema) references them they resolve — but the top-level envelope's `payload` block only constrains `disposition`. So extra payload fields beyond `disposition` are NOT validated by the envelope schema alone. Reproduce as-is (do not add payload validation the code doesn't do).

---

## 3. Git layer used by the activity

`emit_disposition_output_bundle` calls `_build_git_service(repo_override=input.repo)` then `svc.commit_file(...)`. Both are **outside this module** but load-bearing; reproduce their exact behavior.

### 3.1 `_build_git_service(repo_override="")` — `activities/git_operations.py:150–165`
```
from src.git_service import GitService          # imported AT CALL TIME (PyGithub only in worker container)
cfg = {                                          # _git_service_config(), git_operations.py:141-147
    "token":    os.environ.get("GITHUB_TOKEN", ""),
    "repo":     os.environ.get("GITHUB_REPO", ""),
    "base_url": os.environ.get("GITHUB_BASE_URL", "https://api.github.com"),
}
return GitService(GitServiceConfig(
    token=cfg["token"],
    repo=repo_override or cfg["repo"],           # input.repo wins; falls back to env GITHUB_REPO
    base_url=cfg["base_url"],
))
```
- **GOTCHA:** `from src.git_service import GitService` is a deferred import. The real class is `olympus-api/src/services/git_service.py::GitService`, copied into the worker container at Docker build so it imports as `src.git_service`. Outside the worker container this import fails (by design). `GitServiceConfig` comes from `olympus_contracts`.

### 3.2 `GitService.__init__` repo-slug normalisation — `olympus-api/src/services/git_service.py:120–150`
- `Github(auth=Auth.Token(token))`; sets `base_url` kwarg only if `base_url` is set AND != `https://api.github.com`.
- Repo slug accepted as full URL or `owner/repo`: strips `https://`/`http://` scheme+host (`"/".join(slug.split("/")[3:])`), strips leading/trailing `/`, strips a trailing `.git`.
- `self._repo = self._github.get_repo(repo_slug)`; on `GithubException` 404 → `GitServiceError("Repository '{slug}' not found or token lacks access")`; other → `GitServiceError("Cannot connect to repository '{slug}': {exc.data}")`.

### 3.3 `GitService.commit_file(branch, path, content, commit_message) -> CommitResult` — `git_service.py:213–253`
**Exact sequence (this is the entire "what gets written to the store" path):**
1. **Ensure branch:** if `branch != "main"` → `self._ensure_branch(branch)` (see §3.4). (For `branch == "main"`, no branch creation.)
2. **Try update path:** `existing = self._repo.get_contents(path, ref=branch)`.
   - If `existing` is a `list` → `raise GitServiceError(f"Path '{path}' is a directory, not a file")`.
   - Else `result = self._repo.update_file(path=path, message=commit_message, content=content, sha=existing.sha, branch=branch)`.
3. **On `GithubException`:** if `exc.status == 404` (file does not exist) → `result = self._repo.create_file(path=path, message=commit_message, content=content, branch=branch)`. Else → `raise GitServiceError(f"Failed to commit file: {exc.data}") from exc`.
4. `commit_sha = result["commit"].sha`; log `"Committed %s on %s (%s)"`; `return CommitResult(commit_sha=commit_sha, path=path, branch=branch)`.
- **GOTCHA (idempotency/ordering):** create-vs-update is decided by a **404 probe**, not by tracking. Concurrent commits to the same path on the same branch can race (lost update / 409 from GitHub surfaces as a non-404 `GithubException` → `GitServiceError`). Content is passed as a **plain `str`**; PyGithub base64-encodes it for the Contents API.

### 3.4 `GitService._ensure_branch(branch, base_branch="main")` — `git_service.py:188–211`
- `get_git_ref(f"heads/{branch}")` → if it returns, branch exists → `return`. On `GithubException` with `status != 404` → re-raise (unwrapped `GithubException`).
- On 404 (branch absent): `base_ref = get_git_ref("heads/main")`; `create_git_ref(f"refs/heads/{branch}", base_ref.object.sha)`. On `GithubException` 422 (race: created between check and create) → `return`. Other → `GitServiceError("Failed to create branch '{branch}' from '{base_branch}': {exc.data}")`.
- **GOTCHA:** the branch is **always forked from `main`**. The activity does not pass a base; the workflow's working branch must be reachable from `main`.

### 3.5 `CommitResult` — `olympus-contracts/.../git_types.py:50–56`
Dataclass `{commit_sha: str, path: str, branch: str}`. The activity reads `.path` and `.commit_sha`; `.branch` is ignored. `GitServiceError(Exception)` (git_types.py:59–60) is a plain `Exception` (NOT a `WorkflowError`) → see §0 for how the decorator wraps it (→ `NonRetryableError`).

**This activity creates no PR and performs no merge** — there is NO PR/merge/mergeable_state logic in this module. (PR/merge activities live in `git_operations.py` and are a different spec.)

---

## 4. Pure synthesis helpers (called by workflow CODE STEPS, not activities)

These 11 functions are **pure / deterministic** (no I/O, no Temporal) so the workflow replays deterministically; the workflow's `bundle-pre-gate-evidence` / `bundle-post-gate-evidence` code steps call them, then commit the rendered JSON via the workflow's own `write_artifact` step (NOT via these helpers; NOT via `emit_disposition_output_bundle` for the pre-gate case). Reproduce their exact dict shapes — these define the bundle the activity later serialises.

Common input: `step_committed_paths: dict[str, list[str]]` — maps a step-name → list of committed artifact paths for that step.

### 4.1 `_step_path(step_committed_paths, step_name) -> str` (lines 66–76)
```
paths = step_committed_paths.get(step_name, [])
return paths[0] if paths else ""
```
Returns the **first** committed path for `step_name`, else `""`. (Used throughout to pull a single ref per step.)

### 4.2 `_base_envelope(*, app_id, app_name, portfolio_id, wave_id, disposition, status, started_at, completed_at, approvals) -> dict` (lines 79–133)
Builds the common envelope. **All args keyword-only.** Computed refs (all gated on truthy `wave_id`):
- `disposition_decision_ref = f"rationalization/wave-{wave_id}/{app_id}/disposition-recommendation.json"` if `wave_id` else `""`.
- `baseline_ref = f"rationalization/wave-{wave_id}/{app_id}/tco-analysis.json"` if `wave_id` else `""`.
- `user_impact_ref = f"rationalization/wave-{wave_id}/{app_id}/user-impact-analysis.json"` if `wave_id` else `""`.

Returned dict (exact keys/values):
```
{
  "application_id": app_id,
  "application_name": app_name or app_id,          # falls back to app_id when name empty
  "portfolio_id": portfolio_id,
  "wave_id": wave_id,
  "disposition": disposition,
  "status": status,
  "started_at": started_at,
  "completed_at": completed_at,                     # may be None (pre-gate)
  "disposition_decision_ref": disposition_decision_ref,   # "" when no wave_id (⚠ fails schema minLength:1)
  "approvals": list(approvals),                     # shallow copy of the passed list
  "realized_net_impact": {
    "tco_delta": {
      "annual_savings_usd": None,
      "one_time_cost_usd": None,
      "baseline_ref": baseline_ref or None,         # None when "" → schema string|null OK
    },
    "users_affected_actual": None,
    "users_affected_estimate_ref": user_impact_ref or None,
  },
}
```
**GOTCHA:** `payload` is NOT added here — callers (`bundle_*_evidence`) set `envelope["payload"] = _build_payload(...)` afterward. **GOTCHA:** when `wave_id` is falsy, `disposition_decision_ref` is `""`, which violates the schema's `minLength:1` → such an envelope fails `_validate_bundle`. The realized-impact numeric fields are always `None` at synthesis time (realized numbers backfilled later, out of this module's scope).

### 4.3 `_retire_payload(step_committed_paths, *, app_id, include_post_gate) -> dict` (lines 136–172)
| payload key | value | condition |
|---|---|---|
| `disposition` | `"Retire"` | always |
| `decommission_certificate_ref` | `_step_path(.,"infrastructure-decommission") or f"disposition/{app_id}/decommission-certificate.json"` **if `include_post_gate`** else `""` | post-gate only; **fallback** to synthetic path if step has no committed path |
| `archival.archive_locations` | `[]` | always |
| `archival.reconstruction_plan_ref` | `_step_path(.,"data-archival-plan")` | always (pre+post) |
| `archival.data_archival_plan_ref` | `_step_path(.,"data-archival-plan")` | always (same step as above) |
| `consumer_migration.consumers_notified` | `0` | always |
| `consumer_migration.consumers_confirmed_migrated` | `0` | always |
| `consumer_migration.migration_report_ref` | `_step_path(.,"consumer-migration")` **if `include_post_gate`** else `""` | post-gate only |
| `license_reclamation_ref` | `_step_path(.,"license-reclamation")` **if `include_post_gate`** else `""` | post-gate only |
| `infrastructure_torn_down` | `[]` | always |

### 4.4 `_retain_payload(step_committed_paths, *, now_iso) -> dict` (lines 175–205)
Retain has **no post-gate steps** (all steps pre-G-DE-1) → no `include_post_gate` param; shape is constant.
```
{
  "disposition": "Retain",
  "retain_reason": "Retained per Rationalization disposition decision",
  "remediation_outcome": {
    "security_findings_closed": 0,
    "security_remediation_ref": _step_path(.,"security-remediation"),
    "documentation_updates_ref": _step_path(.,"documentation-update"),
    "test_coverage_baseline_pct": 0.0,
    "monitoring_setup_ref": _step_path(.,"monitoring-setup"),
  },
  "sustainment_handoff": {
    "owner_team": "sustainment",
    "handoff_confirmed_at": now_iso,                 # the now_iso arg verbatim
    "handoff_ref": _step_path(.,"sustainment-handoff"),
  },
  "re_evaluation_triggers": ["annual review"],
}
```

### 4.5 `_replace_payload(step_committed_paths, *, include_post_gate) -> dict` (lines 208–244)
| key | value | condition |
|---|---|---|
| `disposition` | `"Replace"` | always |
| `selected_vendor.name` | `"TBD"` | always |
| `selected_vendor.product_version` | `"TBD"` | always |
| `selected_vendor.vendor_evaluation_ref` | `_step_path(.,"vendor-evaluation")` | always |
| `integration.integration_spec_ref` | `_step_path(.,"integration-specification")` | always |
| `integration.cutover_plan_ref` | `_step_path(.,"integration-specification")` | always (**same step** as integration_spec_ref) |
| `data_migration.records_migrated` | `0` | always |
| `data_migration.reconciliation_pass` | `False` | always |
| `data_migration.migration_ref` | `_step_path(.,"data-migration")` **if include_post_gate** else `""` | post-gate only |
| `legacy_decommission_ref` | `_step_path(.,"legacy-decommission")` **if include_post_gate** else `""` | post-gate only |

### 4.6 `_replatform_payload(step_committed_paths, *, include_post_gate) -> dict` (lines 247–295)
| key | value | condition |
|---|---|---|
| `disposition` | `"Replatform"` | always |
| `target_platform.name` | `"TBD"` | always |
| `target_platform.platform_selection_ref` | `_step_path(.,"platform-selection")` | always |
| `workflow_mapping_ref` | `_step_path(.,"workflow-mapping")` | always |
| `component_configuration_ref` | `_step_path(.,"component-configuration")` **if include_post_gate** else `""` | post-gate only |
| `data_migration.records_migrated` | `0` | always |
| `data_migration.reconciliation_pass` | `False` | always |
| `data_migration.migration_ref` | `_step_path(.,"data-migration")` **if include_post_gate** else `""` | post-gate only |
| `validation_cutover_ref` | `_step_path(.,"validation-cutover")` **if include_post_gate** else `""` | post-gate only |
| `legacy_decommission_ref` | `_step_path(.,"legacy-decommission")` **if include_post_gate** else `""` | post-gate only |
| `perf_delta.latency_p95_before_ms` | `None` | always |
| `perf_delta.latency_p95_after_ms` | `None` | always |
| `perf_delta.source` | `"parallel-run-monitor"` | always |
| `cost_delta.monthly_before_usd` | `None` | always |
| `cost_delta.monthly_after_usd` | `None` | always |

### 4.7 `_consolidate_payload(step_committed_paths, *, include_post_gate) -> dict` (lines 298–339)
| key | value | condition |
|---|---|---|
| `disposition` | `"Consolidate"` | always |
| `target_application.id` | `"00000000-0000-0000-0000-000000000000"` | always (sentinel zero-UUID) |
| `target_application.name` | `"TBD"` | always |
| `target_application.target_selection_ref` | `_step_path(.,"target-selection")` | always |
| `feature_gap_analysis_ref` | `_step_path(.,"feature-gap-analysis")` | always |
| `features_ported` | `0` | always |
| `features_dropped` | `[]` | always |
| `enhancement_plan_ref` | `_step_path(.,"enhancement-planning")` | always |
| `data_reconciliation.records_merged` | `0` | always |
| `data_reconciliation.conflicts_resolved` | `0` | always |
| `data_reconciliation.reconciliation_ref` | `_step_path(.,"data-reconciliation")` **if include_post_gate** else `""` | post-gate only |
| `user_migration_ref` | `_step_path(.,"user-migration")` **if include_post_gate** else `""` | post-gate only |
| `absorbed_decommission_ref` | `_step_path(.,"absorbed-decommission")` **if include_post_gate** else `""` | post-gate only |

### 4.8 `_build_payload(disposition, step_committed_paths, *, app_id, include_post_gate, now_iso) -> dict` (lines 342–378)
Dispatch table (string match on `disposition`):
- `"Retire"` → `_retire_payload(., app_id=app_id, include_post_gate=include_post_gate)` (`now_iso` unused).
- `"Retain"` → `_retain_payload(., now_iso=now_iso)` (`include_post_gate`/`app_id` unused — Retain shape is constant).
- `"Replace"` → `_replace_payload(., include_post_gate=include_post_gate)`.
- `"Replatform"` → `_replatform_payload(., include_post_gate=include_post_gate)`.
- `"Consolidate"` → `_consolidate_payload(., include_post_gate=include_post_gate)`.
- **anything else** → `raise ValueError(f"Unsupported disposition for bundle helper: {disposition!r}. Refactor/Rearchitect are handled by DeploymentWorkflow, not here.")`.
- **GOTCHA:** `Refactor` and `Rearchitect` are valid in the *schema* but **not** built here; they raise `ValueError` (note `{disposition!r}` uses `repr`, so the message quotes the value). This `ValueError` is raised inside a *workflow code step* (not inside `emit_disposition_output_bundle`), so it does NOT pass through the `@foundry_activity` wrapper.

### 4.9 `bundle_pre_gate_evidence(*, app_id, app_name, portfolio_id, wave_id, disposition, step_committed_paths, started_at, approvals=None, now_iso="") -> dict` (lines 381–423)
- `envelope = _base_envelope(..., status="in_progress", started_at=started_at, completed_at=None, approvals=approvals or [])`.
- `envelope["payload"] = _build_payload(disposition, step_committed_paths, app_id=app_id, include_post_gate=False, now_iso=now_iso or started_at)`.
- Return `envelope`.
- **GOTCHA:** `now_iso` defaults to `started_at` when empty (`now_iso or started_at`). Produces `status="in_progress"`, `completed_at=None`, possibly `approvals=[]` → as noted in §2.1 this is **NOT** valid against the envelope schema's `status` enum / `completed_at` date-time / `approvals` minItems:1. The pre-gate bundle is committed via the workflow's plain `write_artifact` (unvalidated), not via `emit_disposition_output_bundle`.

### 4.10 `bundle_post_gate_evidence(*, app_id, app_name, portfolio_id, wave_id, disposition, step_committed_paths, started_at, completed_at, approvals, now_iso="") -> dict` (lines 426–475)
- **First:** if `disposition == "Retain"` → `raise ValueError("bundle_post_gate_evidence must not be called for Retain — Retain terminates at G-DE-1 with no G-DE-2 or post-gate synthesis.")`. (Retain's terminal artifact is the pre-gate bundle, flipped to `status="plan_approved"` by the workflow.)
- `envelope = _base_envelope(..., status="completed", started_at=started_at, completed_at=completed_at, approvals=approvals)`.
- `envelope["payload"] = _build_payload(disposition, step_committed_paths, app_id=app_id, include_post_gate=True, now_iso=now_iso or completed_at)`.
- Return `envelope`.
- **GOTCHA:** `now_iso` defaults to `completed_at` when empty. This is the bundle shape (`status="completed"`, real `completed_at`, non-empty `approvals`) that is **schema-valid** and is what `emit_disposition_output_bundle` is meant to receive for non-Retain dispositions.

---

## 5. Module-level constants / helpers
- `_REPO_ROOT = Path(__file__).resolve().parents[3]` (line 480). `_DISPOSITION_SCHEMAS_DIR = _REPO_ROOT / "schemas" / "dispositions"` (line 481). See §2 GOTCHA on `parents[3]`.
- `_artifact_path(portfolio_id, app_id) -> str` (lines 534–535): `f"dispositions/{portfolio_id}/{app_id}/disposition-output.json"`.
- `_load_schema_store()` (lines 484–496): see §2 step 4.
- `logger = logging.getLogger(__name__)`.
- Imports: `json`, `logging`, `pathlib.Path`; `from foundry_temporal.activities import ActivityConfig, foundry_activity`; `from foundry_temporal.errors import NonRetryableError`; `from jsonschema import Draft202012Validator, RefResolver`; `from olympus_workflows.activities.git_operations import _build_git_service`; `from olympus_workflows.types import EmitDispositionOutputBundleInput, EmitDispositionOutputBundleResult`.

---

## 6. End-to-end behavioral checklist for a rebuild (parity bar)
1. Decorate the activity with the `foundry_activity` wrapper (observability on; error-wrapping on; no timeouts/retry in decorator). Re-raise `WorkflowError`/`ApplicationError` unchanged; wrap others by substring-classification (→ `GitServiceError` becomes `NonRetryableError`).
2. `_validate_bundle` BEFORE any Git call; schema failures → `NonRetryableError` (no retry); missing schema file → `NonRetryableError`. Use the envelope schema + a `$id`→schema store seeded from all `*.schema.json` in `schemas/dispositions/`, via a Draft-2020-12 validator with a ref resolver. Report total count + first 5 errors (`  {json_path}: {message}`).
3. Compute path from **input** `portfolio_id`/`app_id` (not the bundle). Serialise with `json.dumps(bundle, indent=2, sort_keys=True) + "\n"`.
4. Build the GitService from env (`GITHUB_TOKEN/REPO/BASE_URL`), `repo_override` from `input.repo`. `commit_file` ensures the branch off `main` (unless `branch=="main"`), then update-or-create-on-404. Return `{path, commit_sha}`.
5. Pure helpers produce the exact dict shapes in §4 (every default, every post-gate-only conditional, the `"TBD"`/zero-UUID/`"?"` sentinels). Retain has constant shape; `bundle_post_gate_evidence` rejects Retain; `_build_payload` rejects Refactor/Rearchitect.
6. Honour the status divergence in §2.1/§4.9: helper-emitted `in_progress`/`plan_approved` bundles are NOT valid against the schema and are committed by the workflow's own write step, not this activity.
