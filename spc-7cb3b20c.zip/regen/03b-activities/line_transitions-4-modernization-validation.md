# Activity Group Spec — `line_transitions.py` Group 4: Modernization + Validation Projections

ATOMIC regeneration spec. Source of truth: `/Users/pnunna/Documents/GitHub/foundry/temporal/olympus_workflows/activities/line_transitions.py`.

**HEAD:** `7cb3b20c`. **Line numbers REFRESHED to HEAD** (see ⚠️ shift note below).
**This file owns ONLY lines 3980–4511**, i.e. the two `@foundry_activity` projection activities:

| Activity | Decorator line | Def line | Body range |
|---|---|---|---|
| `persist_modernization_side_effects` | 3979 | 3980 | 3980–4166 |
| `persist_validation_side_effects` | 4368 | 4369 | 4369–4511 |

> ⚠️ **HEAD `7cb3b20c` line-shift note (citations CORRECTED).** `line_transitions.py` grew by +162 lines via two upstream insertions; this group's symbols shifted by **+125** (Modernization) / **+126** (Validation). `persist_modernization_side_effects` 3855→**3980** (its constants 3640→**3765**, extractors `_extract_extract_side_effects` 3652→**3777**, `_extract_design_side_effects` 3688→**3813**, `_extract_bounded_context_rows` 3747→**3872**, `_extract_generate_side_effects` 3775→**3900**). `persist_validation_side_effects` 4243→**4369** (its constant 4075→**4200**, extractors `_extract_parity_side_effects` 4086→**4211**, `_extract_compliance_side_effects` 4113→**4238**, `_extract_safety_side_effects` 4177→**4302**, `_extract_lifecycle_status` 4203→**4328**). Shared `_build_update_sql` 1111→**1226**; `_SIDE_EFFECT_COLUMNS` (791-874), `_JSONB_COLUMNS` (877-892), `StepExecutionContext` (532-554) UNCHANGED. **`types.py` also grew** (+68): the dataclass citations are CORRECTED. Bodies are behaviorally UNCHANGED — only citations moved.

Both project per-target line artifacts onto `application` (and, for Modernization, `bounded_context`) rows. They follow the "post-gate projection" pattern shared by Discovery / Rationalization / Architecture / Data: parse artifacts best-effort, build a sparse projection dict, run a single dynamic `UPDATE application SET … WHERE id = $N` that touches only the columns the artifacts populated.

The module-private helpers each activity depends on are reproduced in full here even when they sit just outside 3980–4511 (e.g. the Modernization extractors at 3777–3978), because the activities cannot be rebuilt without them. Helpers used purely by the *Sustainment* projection (4534+) are NOT owned here — they belong to the sibling Sustainment group.

---

## 0. CRITICAL PREAMBLE — the `@foundry_activity` decorator

Both activities are decorated with:

```python
@foundry_activity(config=ActivityConfig(enable_observability=True))
```

from `foundry_temporal.activities` (imported at `line_transitions.py:26`). This is **NOT** `@activity.defn`. Reproduce its exact semantics (source: `/private/var/folders/qs/dwcdl18n351cyz88x2tc9w3w0000gp/T/tmp.2xQMcqnDWM/foundry_temporal/activities.py:107-165`):

`foundry_activity(config=None, name=None, **activity_kwargs)` returns a decorator that:

1. Resolves `activity_config = config or ActivityConfig()`. Here `config=ActivityConfig(enable_observability=True)`. **`ActivityConfig` defaults** (`activities.py:27-39`): `retry_policy=None`, all four timeouts `None`, `heartbeat_timeout=None`, `enable_observability=True` (already the default — passing it is a no-op restating intent), `enable_error_wrapping=True`, `log_inputs=False`, `log_outputs=False`. ⚠️ **Because no `retry_policy`/timeouts are set in the config, Temporal's worker/workflow-level defaults govern retries and timeouts — the decorator does NOT inject a RetryPolicy.** Retryability is therefore decided by (a) the error *type* raised and (b) whatever retry policy the workflow attaches when scheduling the activity.
2. Wraps `func` with `@activity.defn(name=name, **activity_kwargs)` over `@wraps(func)`. `name=None` ⇒ Temporal registers the activity under the function's own name (`persist_modernization_side_effects` / `persist_validation_side_effects`).
3. The wrapper (`activities.py:127-161`), on each call:
   - `activity_name = name or func.__name__`.
   - `activity_logger = get_logger()`.
   - If `enable_observability` (true): logs `f"Activity {activity_name} starting"` with `extra={"inputs": args if log_inputs else None}` → here `inputs=None` (log_inputs False).
   - Runs `result = await func(*args, **kwargs)`.
   - On success + observability: logs `f"Activity {activity_name} completed"` with `extra={"outputs": result if log_outputs else None}` → `outputs=None`.
   - On any `Exception error`:
     - If observability: logs `f"Activity {activity_name} failed: {error}"` with `extra={"error": str(error)}`.
     - If `enable_error_wrapping` (true):
       - `isinstance(error, (WorkflowError, ApplicationError))` → `raise` (re-raise unchanged). ⚠️ **`NonRetryableError` and `RetryableError` are subclasses of `WorkflowError`** (`foundry_temporal/errors.py`), so a `NonRetryableError` raised inside the body passes through verbatim — it is NOT re-wrapped, and its non-retryable semantics survive.
       - elif `_is_retryable_error(error)` → `raise RetryableError(f"Retryable error in {activity_name}: {error}") from error`.
       - else → `raise NonRetryableError(f"Non-retryable error in {activity_name}: {error}") from error`.
     - else (`enable_error_wrapping` False — not the case here): bare `raise`.

**`_is_retryable_error(error)`** (`activities.py:168-183`): lowercases `str(type(error))` and returns True if it contains any of: `timeout`, `connection`, `network`, `temporary`, `unavailable`, `overload`, `busy`, `throttle`, `rate_limit`. ⚠️ It matches against the **type's repr string**, not the message. So `asyncpg.exceptions.ConnectionDoesNotExistError` (contains "connection") → retryable; a generic `ValueError` → non-retryable.

**Consequences for these two activities (capture exactly):**
- A raw DB error from `asyncpg.connect` / `conn.execute` whose *type name* matches a retryable pattern (e.g. `*ConnectionError`, `*TimeoutError`) → re-raised by the worker wrapper as `RetryableError` → Temporal retries per the workflow's policy.
- A DB error whose type name matches nothing (e.g. a `PostgresSyntaxError`, `UniqueViolationError`) → re-raised as `NonRetryableError` → no retry.
- An explicitly-raised `NonRetryableError` (invalid UUID / invalid gate_phase) → passes through unchanged (it is a `WorkflowError`).

**Idempotency.** Both activities are effectively idempotent on re-run: every write is either an UPDATE keyed by `application.id` / `(target_app_id, bc_name)` (re-applying the same projection yields the same row state, except `updated_at`/`*_at` timestamps which are re-stamped to `datetime.now(timezone.utc)` on each attempt — see GOTCHAs), or a `bounded_context` INSERT guarded by `ON CONFLICT (target_app_id, bc_name) DO NOTHING`. There is no dedup token; correctness on retry comes from the deterministic projection + idempotent SQL.

---

## 1. Module-level imports & shared helpers (reproduce verbatim — both activities depend on these)

`line_transitions.py:15-28` (relevant subset):
```python
from __future__ import annotations
import json
import os
import uuid
from datetime import datetime, timezone
from typing import Any
import asyncpg
from foundry_temporal.activities import ActivityConfig, foundry_activity
from foundry_temporal.errors import NonRetryableError
```
`logger = logging.getLogger(__name__)` is the module logger. `ExecutionStatus`, `emit_code_step_start`, `emit_code_step_complete` are imported from `olympus_workflows.utils.execution` (import block at lines 72–...).

### 1.1 `_db_url()` — `line_transitions.py:88-94`
```python
def _db_url() -> str:
    host = os.environ.get("DATABASE_HOST", "localhost")
    port = os.environ.get("DATABASE_PORT", "5432")
    user = os.environ.get("DATABASE_USER", "olympus")
    password = os.environ.get("DATABASE_PASSWORD", "olympus")
    db = os.environ.get("DATABASE_NAME", "olympus")
    return f"postgresql://{user}:{password}@{host}:{port}/{db}"
```
Both activities open a **fresh `asyncpg.connect(_db_url())` per call** (no pool) and `await conn.close()` in a `finally`.

### 1.2 `_try_parse_json(text)` — `line_transitions.py:281-297`
Best-effort parse tolerating prose-wrapped JSON:
```python
def _try_parse_json(text: str) -> dict[str, Any] | None:
    if not text:
        return None
    try:
        value = json.loads(text)
    except json.JSONDecodeError:
        start = text.find("{")
        end = text.rfind("}")
        if start == -1 or end <= start:
            return None
        try:
            value = json.loads(text[start : end + 1])
        except json.JSONDecodeError:
            return None
    return value if isinstance(value, dict) else None
```
⚠️ Returns `None` for empty string, unparseable text, OR a top-level JSON value that is not a dict (e.g. a JSON array or scalar). All extractor helpers `isinstance(..., dict)`-guard, so a `None` here means "field contributes nothing."

### 1.3 `_build_update_sql(projections)` — `line_transitions.py:1226-1259` ⚠️ THE PROJECTION ENGINE
This single helper builds the dynamic `UPDATE application` for **both** activities (and all sibling projections). Reproduce **exactly**:
```python
def _build_update_sql(projections: dict[str, Any]) -> tuple[str, list[Any]]:
    assignments: list[str] = []
    params: list[Any] = []
    idx = 1
    for column in _SIDE_EFFECT_COLUMNS:            # FIXED ORDER — see 1.4
        if column not in projections:
            continue
        value = projections[column]
        if column in _JSONB_COLUMNS:               # see 1.5
            value = json.dumps(value)
        assignments.append(f"{column} = ${idx}")
        params.append(value)
        idx += 1
    assignments.append(f"updated_at = ${idx}")     # ALWAYS appended
    params.append(datetime.now(timezone.utc))
    idx += 1
    where_idx = idx
    sql = "UPDATE application SET " + ", ".join(assignments) + f" WHERE id = ${where_idx}"
    return sql, params
```
Critical properties to preserve for parity:
- **Column iteration order is `_SIDE_EFFECT_COLUMNS` tuple order, NOT `projections` insertion order.** Placeholder numbers ($1, $2, …) are assigned in tuple order. Caller must append the `target_uuid` to `params` AFTER the returned list so it lands at `$where_idx` (the last placeholder). Both activities do `params.append(target_uuid)` after the call.
- **A projection key that is NOT in `_SIDE_EFFECT_COLUMNS` is silently dropped** (the loop only iterates the whitelist). The extractors only ever emit whitelisted keys, so this is a safety net, not a live path.
- **`updated_at` is ALWAYS set** to `now(utc)` even when only `updated_at` would change (i.e. an empty projections dict still yields `UPDATE application SET updated_at = $1 WHERE id = $2`). The callers, however, guard against empty projections before calling this (see each activity), so an all-empty `_build_update_sql` is not reached in normal flow.
- **JSONB columns are `json.dumps`'d to a Python `str`** and passed as a string param. The SQL has no explicit `::jsonb` cast — asyncpg sends a text param; the `application` columns are JSONB so PostgreSQL casts on assignment. Non-JSONB columns are passed as native Python objects (asyncpg encodes `datetime` → timestamptz, `int`/`float` → numeric, `str` → text, `list[str]`/`list[UUID]` → array natively).

### 1.4 `_SIDE_EFFECT_COLUMNS` — `line_transitions.py:791-874` (FULL TUPLE, order-significant)
This is the closed whitelist of `application` columns any projection may write. Reproduce in this exact order (placeholder assignment depends on it):
```
description, business_domain, archetype, complexity_tier, safety_tier,
risk_tier, risk_tier_source, tech_stack, size_metrics, architecture,
business_logic, quality, ux_assessment, tco,
portfolio_score, disposition, disposition_source, disposition_rationale_ref,
architecture_blueprint_ref, architecture_pattern, architecture_decided_at, source_app_ids,
target_repo_url, target_service_id,
data_architecture_ref, data_migration_plan_ref, data_decided_at, data_pattern, data_domains, data_current_status,
extraction_ref, extraction_at, design_ref, design_at, modernization_pattern, bounded_contexts, generated_module_refs, generate_at, modernization_current_status,
validation_parity_score, validation_critical_vuln_count, validation_accessibility_score, validation_safety_case_ref, validation_completed_at, validation_current_status,
deployed_at, deployment_env, cutover_strategy, parallel_run_duration_days, cost_savings_realized_usd, license_reclamation_usd, legacy_decommissioned_at, deployment_current_status,
disposition_output_ref, disposition_completed_at, disposition_current_status, cost_savings_annual_usd
```
The **Modernization-owned** columns are the block `extraction_ref … modernization_current_status` (9 columns). The **Validation-owned** columns are the block `validation_parity_score … validation_current_status` (6 columns). Each activity only ever emits keys from its own block (plus `updated_at` auto), but `_build_update_sql` would happily write any of the 57 if a projection dict contained them.

### 1.5 `_JSONB_COLUMNS` — `line_transitions.py:877-892` (FULL SET)
Columns whose value is `json.dumps`'d before binding:
```
tech_stack, size_metrics, architecture, business_logic, quality, ux_assessment, tco,
portfolio_score, data_domains, bounded_contexts, generated_module_refs
```
⚠️ For **this group**, the only JSONB columns in play are `bounded_contexts` and `generated_module_refs` (both Modernization). **None of the six Validation columns are JSONB** — they bind natively (`validation_parity_score`/`validation_accessibility_score` as float→numeric, `validation_critical_vuln_count` as int→integer, `validation_safety_case_ref`/`validation_current_status` as str→text, `validation_completed_at` as datetime→timestamptz). Modernization's `extraction_ref`/`design_ref`/`modernization_pattern`/`modernization_current_status` are text; `extraction_at`/`design_at`/`generate_at` are datetime; `bounded_contexts`/`generated_module_refs` are JSONB (list[str] → JSON array string).

### 1.6 Observability helpers (`olympus_workflows/utils/execution.py`)
- **`StepExecutionContext`** (`types.py:532-554`), forwarded on `input.execution_context` (may be `None`): fields `portfolio_id: str` (required), `line_id: str`, `step_id: str`, `app_id: str = ""`, `wave_id: str = ""`, `input_artifact_paths: list[str] = []`, `gate_id: str = ""`.
- **`emit_code_step_start(ctx, *, function_name, columns_writable=None) -> uuid.UUID | None`** (`execution.py:283-321`): if `ctx is None` → returns `None` immediately (no emission). Else reads `workflow_id`/`attempt` from `temporalio.activity.info()` (falling back to `""`/`1` on any exception), builds `payload={"function": function_name}` (+ `columns_written` if `columns_writable` truthy), and calls `emit_execution_record(EmitExecutionRecordInput(portfolio_id=ctx.portfolio_id, line_id=ctx.line_id, step_id=ctx.step_id, step_kind=StepKind.CODE, workflow_id=..., app_id=ctx.app_id or None, wave_id=ctx.wave_id or None, attempt=..., payload=payload, status=ExecutionStatus.RUNNING))`. Returns the new `step_execution` row UUID (or `None`).
- **`emit_code_step_complete(execution_id, *, status=ExecutionStatus.COMPLETED, columns_written=None, error=None) -> None`** (`execution.py:324-345`): if `columns_written is not None` builds `payload_merge={"columns_written": columns_written}`; calls `update_execution_record(execution_id, status=status, payload_merge=payload_merge, last_error=error)`. ⚠️ `update_execution_record` tolerates `execution_id is None` (no-op) — so when `ctx is None`, start returns `None` and complete is a no-op.
- **`ExecutionStatus`** (`execution.py:66-74`): str-enum; values used here are `RUNNING="running"`, `COMPLETED="completed"`, `FAILED="failed"`.

---

# ACTIVITY 1 — `persist_modernization_side_effects` (3980–4166)

## 1.A Signature & contracts
```python
@foundry_activity(config=ActivityConfig(enable_observability=True))
async def persist_modernization_side_effects(
    input: PersistModernizationSideEffectsInput,
) -> PersistModernizationSideEffectsResult:
```

### Input dataclass — `PersistModernizationSideEffectsInput` (`types.py:2297-2338`)
```python
@dataclass
class PersistModernizationSideEffectsInput:
    target_app_id: str
    gate_phase: str                 # "extract" | "design" | "generate"
    extraction_report_json: str = ""   # extract phase
    extraction_ref: str = ""           # extract phase
    module_map_json: str = ""          # design phase
    design_review_json: str = ""       # design phase
    design_ref: str = ""               # design phase
    gate_review_package_json: str = "" # generate phase
    decided_at: str = ""               # shared, ISO-8601 merge timestamp
    execution_context: StepExecutionContext | None = None
```

### Output dataclass — `PersistModernizationSideEffectsResult` (`types.py:2340-2356`)
```python
@dataclass
class PersistModernizationSideEffectsResult:
    target_app_id: str
    gate_phase: str
    extraction_persisted: bool = False
    design_persisted: bool = False
    generate_persisted: bool = False
    modernization_pattern: str = ""
    bounded_context_rows_inserted: int = 0
    bounded_context_rows_updated: int = 0
```

### Purpose
Projects per-target Modernization artifacts onto `application` + `bounded_context`. Called **three times per target run**, once after each gate (G-04a / G-04b / G-04c), selected by `gate_phase`. Best-effort: unparseable artifacts log a warning and return a near-empty result rather than raising (matches Discovery/Rationalization/Architecture/Data).

## 1.B Phase constants & whitelists (3765-3776)
```python
_MODERNIZATION_PATTERNS = frozenset({"monolith-lift", "microservices-decompose", "bc-per-service", "hybrid"})
_BOUNDED_CONTEXT_STATUSES = frozenset({"design-complete", "generate-active", "generate-complete", "escalated", "abandoned"})
_GATE_PHASES = frozenset({"extract", "design", "generate"})
```

## 1.C Extractor helpers (reproduce verbatim — the projection IS these functions)

### `_extract_extract_side_effects(report, *, extraction_ref, decided_at)` → dict — (3777-3812)
G-04a projections. Control flow:
1. `out = {}`.
2. If `extraction_ref` truthy → `out["extraction_ref"] = extraction_ref`.
3. If `decided_at` truthy → try `out["extraction_at"] = datetime.fromisoformat(decided_at.replace("Z", "+00:00"))`; on `(TypeError, ValueError)` log warning `"extract decided_at not ISO-8601"` (extra `decided_at`) and **omit** the column.
4. If `isinstance(report, dict)`: `bcs = report.get("bounded_contexts")`; if `isinstance(bcs, list)` → `clean = [bc for bc in bcs if isinstance(bc, str) and bc]`; if `clean` non-empty → `out["bounded_contexts"] = clean` (drops non-str / empty-str entries, no failure).
5. Return `out`.

### `_extract_design_side_effects(module_map, design_review, *, design_ref, decided_at)` → dict — (3813-3871)
G-04b projections. Control flow:
1. `out = {}`.
2. If `design_ref` truthy → `out["design_ref"] = design_ref`.
3. If `decided_at` truthy → try `out["design_at"] = datetime.fromisoformat(decided_at.replace("Z","+00:00"))`; on `(TypeError, ValueError)` log `"design decided_at not ISO-8601"` and omit.
4. Pattern resolution: `pattern=None`; if `isinstance(design_review, dict)` → `pattern = design_review.get("modernization_pattern")`; if `pattern is None and isinstance(module_map, dict)` → `pattern = module_map.get("modernization_pattern")`. Then: if `isinstance(pattern, str) and pattern in _MODERNIZATION_PATTERNS` → `out["modernization_pattern"] = pattern`; elif `pattern` truthy (but not whitelisted) → log `"modernization_pattern not in whitelist"` (extra `pattern`) and omit. ⚠️ design_review takes precedence over module_map for the pattern.
5. Refined BCs: `refined_bcs=[]`; if `isinstance(module_map, dict)` → `modules = module_map.get("modules") or module_map.get("bounded_contexts")`; if `isinstance(modules, list)` iterate: for each `mod`, if `dict` use `mod.get("name") or mod.get("bc_name")` (append if str & truthy), elif `str` & truthy append the string. If `refined_bcs` non-empty → `out["bounded_contexts"] = refined_bcs`. ⚠️ NOT de-duped here (unlike `_extract_bounded_context_rows`).
6. Return `out`.

### `_extract_bounded_context_rows(module_map)` → list[dict] — (3872-3899)
Builds one row per BC for INSERT at G-04b. Control flow:
1. If not `isinstance(module_map, dict)` → return `[]`.
2. `modules = module_map.get("modules") or module_map.get("bounded_contexts")`; if not `isinstance(modules, list)` → return `[]`.
3. `rows=[]`, `seen=set()`. For each `mod`: derive `name` (dict→`name`/`bc_name`; str→itself; else None). Skip if not str, empty, or `name in seen`. Else `seen.add(name)`; `rows.append({"bc_name": name, "status": "design-complete"})`. ⚠️ De-duped by first-seen name.
4. Return `rows`.

### `_extract_generate_side_effects(package, *, decided_at)` → tuple[dict, list[dict]] — (3900-3978)
G-04c projections. Returns `(app_out, bc_updates)`. Control flow:
1. `app_out={}`, `bc_updates=[]`.
2. If `decided_at` truthy → try `app_out["generate_at"] = datetime.fromisoformat(decided_at.replace("Z","+00:00"))`; on `(TypeError, ValueError)` log `"generate decided_at not ISO-8601"` and omit.
3. If not `isinstance(package, dict)` → **early-return `(app_out, bc_updates)`** (so generate_at can still be set even with an unparseable package).
4. `bc_entries = package.get("bounded_contexts")`; `paths=[]`; `escalated_count=0`. If `isinstance(bc_entries, list)`, for each `bc`:
   - skip if not dict.
   - `name = bc.get("bc_name") or bc.get("name")`; skip if not str or empty.
   - `status = bc.get("status")`; if not str or `status not in _BOUNDED_CONTEXT_STATUSES` → **`status = "generate-complete"`** (default-green; escalated/abandoned must be explicit & whitelisted).
   - `update = {"bc_name": name, "status": status}`.
   - if `status in {"escalated","abandoned"}` → `escalated_count += 1`.
   - `ralph_iter = bc.get("ralph_iterations")`; if `isinstance(ralph_iter, int)` → `update["ralph_iterations"] = ralph_iter`.
   - `escalations = bc.get("escalations")`; if `isinstance(escalations, list)` → `update["escalations"] = escalations`.
   - `path = bc.get("generated_path")`; if `isinstance(path, str) and path` → `update["generated_path"] = path`; `paths.append(path)`.
   - `bc_updates.append(update)`.
5. If `paths` non-empty → `app_out["generated_module_refs"] = paths`. ⚠️ Only paths from BCs that actually had a `generated_path` are collected; the app-level list is the union of those.
6. Lifecycle status (only if `bc_updates` non-empty): `escalated_count == 0` → `"modernization_complete"`; `0 < escalated_count < len(bc_updates)` → `"modernization_partial"`; else (all escalated/abandoned) → `"modernization_failed"`. Stored at `app_out["modernization_current_status"]`. ⚠️ If `bc_updates` is empty, NO status is set.
7. Return `(app_out, bc_updates)`.

## 1.D Activity control flow (3980-4166) — reproduce exactly

```python
async def persist_modernization_side_effects(input) -> PersistModernizationSideEffectsResult:
    exec_id = await emit_code_step_start(
        input.execution_context,
        function_name=f"persist_modernization_side_effects({input.gate_phase})",
    )
    # --- (a) validate target_app_id ---
    try:
        target_uuid = uuid.UUID(input.target_app_id)
    except (ValueError, TypeError) as exc:
        await emit_code_step_complete(exec_id, status=ExecutionStatus.FAILED, error=str(exc))
        raise NonRetryableError(f"Invalid target_app_id: {input.target_app_id!r}") from exc

    # --- (b) validate gate_phase ---
    if input.gate_phase not in _GATE_PHASES:
        await emit_code_step_complete(exec_id, status=ExecutionStatus.FAILED,
                                      error=f"Invalid gate_phase: {input.gate_phase!r}")
        raise NonRetryableError(
            f"Invalid gate_phase: {input.gate_phase!r}. Expected one of {sorted(_GATE_PHASES)}.")

    # --- (c) per-phase extraction ---
    projections: dict[str, Any] = {}
    bc_rows_to_insert: list[dict[str, Any]] = []
    bc_rows_to_update: list[dict[str, Any]] = []

    if input.gate_phase == "extract":
        report = _try_parse_json(input.extraction_report_json)
        projections.update(_extract_extract_side_effects(
            report, extraction_ref=input.extraction_ref, decided_at=input.decided_at))
    elif input.gate_phase == "design":
        module_map = _try_parse_json(input.module_map_json)
        design_review = _try_parse_json(input.design_review_json)
        projections.update(_extract_design_side_effects(
            module_map, design_review, design_ref=input.design_ref, decided_at=input.decided_at))
        bc_rows_to_insert = _extract_bounded_context_rows(module_map)
    else:  # generate
        package = _try_parse_json(input.gate_review_package_json)
        app_out, bc_updates = _extract_generate_side_effects(package, decided_at=input.decided_at)
        projections.update(app_out)
        bc_rows_to_update = bc_updates

    # --- (d) nothing-to-do short-circuit ---
    if not projections and not bc_rows_to_insert and not bc_rows_to_update:
        logger.info("persist_modernization_side_effects: nothing extractable",
                    extra={"target_app_id": input.target_app_id, "gate_phase": input.gate_phase})
        await emit_code_step_complete(exec_id, columns_written=[])
        return PersistModernizationSideEffectsResult(
            target_app_id=input.target_app_id, gate_phase=input.gate_phase)

    # --- (e) single DB transaction ---
    conn = await asyncpg.connect(_db_url())
    bc_inserted = 0
    bc_updated = 0
    try:
        async with conn.transaction():
            if projections:
                sql, params = _build_update_sql(projections)
                params.append(target_uuid)
                await conn.execute(sql, *params)
            for row in bc_rows_to_insert:
                result = await conn.execute(
                    """
                    INSERT INTO bounded_context (
                        target_app_id, bc_name, status, created_at, updated_at)
                    VALUES ($1, $2, $3, $4, $4)
                    ON CONFLICT (target_app_id, bc_name) DO NOTHING
                    """,
                    target_uuid, row["bc_name"], row["status"], datetime.now(timezone.utc))
                if result.endswith(" 1"):
                    bc_inserted += 1
            for update in bc_rows_to_update:
                assignments = ["status = $3", "updated_at = $4"]
                params_list = [target_uuid, update["bc_name"], update["status"], datetime.now(timezone.utc)]
                idx = 5
                if "ralph_iterations" in update:
                    assignments.append(f"ralph_iterations = ${idx}"); params_list.append(update["ralph_iterations"]); idx += 1
                if "escalations" in update:
                    assignments.append(f"escalations = ${idx}"); params_list.append(json.dumps(update["escalations"])); idx += 1
                if "generated_path" in update:
                    assignments.append(f"generated_path = ${idx}"); params_list.append(update["generated_path"]); idx += 1
                sql = "UPDATE bounded_context SET " + ", ".join(assignments) + " WHERE target_app_id = $1 AND bc_name = $2"
                result = await conn.execute(sql, *params_list)
                if result.endswith(" 1"):
                    bc_updated += 1
    finally:
        await conn.close()

    logger.info("modernization side-effects persisted",
                extra={"target_app_id": input.target_app_id, "gate_phase": input.gate_phase,
                       "columns_written": sorted(projections.keys()),
                       "bc_rows_inserted": bc_inserted, "bc_rows_updated": bc_updated})
    await emit_code_step_complete(exec_id, columns_written=sorted(projections.keys()))
    return PersistModernizationSideEffectsResult(
        target_app_id=input.target_app_id,
        gate_phase=input.gate_phase,
        extraction_persisted=(input.gate_phase == "extract" and "extraction_ref" in projections),
        design_persisted=(input.gate_phase == "design" and "design_ref" in projections),
        generate_persisted=(input.gate_phase == "generate" and "generated_module_refs" in projections),
        modernization_pattern=str(projections.get("modernization_pattern", "")),
        bounded_context_rows_inserted=bc_inserted,
        bounded_context_rows_updated=bc_updated,
    )
```

### Result-flag derivation (exact)
- `extraction_persisted` = `gate_phase=="extract"` AND `"extraction_ref" in projections`.
- `design_persisted` = `gate_phase=="design"` AND `"design_ref" in projections`.
- `generate_persisted` = `gate_phase=="generate"` AND `"generated_module_refs" in projections`. ⚠️ Note: generate is "persisted" only if at least one BC carried a `generated_path` (because that's the only source of `generated_module_refs`). A generate run with BCs but no paths returns `generate_persisted=False` despite having written `bounded_context` updates + a status.
- `modernization_pattern` = `str(projections.get("modernization_pattern", ""))` (only ever set in design phase).
- `bounded_context_rows_inserted` / `_updated` = running counts from the loops.

## 1.E Modernization — COMPLETE artifact-field → table.column mapping

### Target table `application` (UPDATE keyed by `id = target_uuid`)
| gate_phase | Source artifact path → value | application.column | Type / JSONB | Condition written |
|---|---|---|---|---|
| extract | `input.extraction_ref` | `extraction_ref` | text | when `extraction_ref` truthy |
| extract | `input.decided_at` → `datetime.fromisoformat(decided_at.replace("Z","+00:00"))` | `extraction_at` | datetime → timestamptz (native) | when `decided_at` truthy AND parses as ISO-8601 (else warn+omit) |
| extract | `extraction_report.bounded_contexts` (filtered to non-empty str) | `bounded_contexts` | **JSONB** (`json.dumps(list[str])`) | when report is dict, value is list, and filtered list non-empty |
| design | `input.design_ref` | `design_ref` | text | when `design_ref` truthy |
| design | `input.decided_at` → ISO datetime | `design_at` | datetime → timestamptz (native) | when `decided_at` truthy AND parses (else warn+omit) |
| design | `design_review.modernization_pattern` ELSE `module_map.modernization_pattern` | `modernization_pattern` | text | only if str AND in `_MODERNIZATION_PATTERNS` (else warn+omit) |
| design | `module_map.modules[*].name`/`.bc_name` or `module_map.bounded_contexts[*]` (str list) | `bounded_contexts` | **JSONB** (`json.dumps(list[str])`) | when module_map is dict, modules is list, and ≥1 name resolved |
| generate | `input.decided_at` → ISO datetime | `generate_at` | datetime → timestamptz (native) | when `decided_at` truthy AND parses (else warn+omit) |
| generate | union of `package.bounded_contexts[*].generated_path` (str, non-empty) | `generated_module_refs` | **JSONB** (`json.dumps(list[str])`) | when package is dict AND ≥1 BC had a generated_path |
| generate | derived from `escalated_count` vs `len(bc_updates)` | `modernization_current_status` | text | when `bc_updates` non-empty; value ∈ {`modernization_complete`,`modernization_partial`,`modernization_failed`} |
| (all, auto) | `datetime.now(utc)` | `updated_at` | timestamptz | ALWAYS appended by `_build_update_sql` when `projections` non-empty |

⚠️ The UPDATE to `application` runs **only if `projections` is non-empty** (line `if projections:` inside the txn). In design phase, `projections` may be empty (e.g. no design_ref, bad decided_at, no pattern, no module names) while `bc_rows_to_insert` is non-empty — then `application` is NOT updated but `bounded_context` rows ARE inserted.

### Target table `bounded_context` — INSERT (design phase, from `bc_rows_to_insert`)
SQL (verbatim):
```sql
INSERT INTO bounded_context (target_app_id, bc_name, status, created_at, updated_at)
VALUES ($1, $2, $3, $4, $4)
ON CONFLICT (target_app_id, bc_name) DO NOTHING
```
| param | Source | column |
|---|---|---|
| $1 | `target_uuid` (parsed from `input.target_app_id`) | `target_app_id` |
| $2 | `row["bc_name"]` (from `_extract_bounded_context_rows`) | `bc_name` |
| $3 | `row["status"]` = constant `"design-complete"` | `status` |
| $4 | `datetime.now(timezone.utc)` (bound once, used for BOTH `created_at` and `updated_at`) | `created_at`, `updated_at` |

⚠️ `ON CONFLICT (target_app_id, bc_name) DO NOTHING` makes G-04b idempotent across rework re-runs (re-running design never errors, never re-stamps an existing row). `bc_inserted` increments only when `result.endswith(" 1")` (asyncpg returns `"INSERT 0 1"` for a real insert, `"INSERT 0 0"` on conflict). Columns NOT touched on insert: `ralph_iterations`, `escalations`, `generated_path` (left at their schema defaults until G-04c).

### Target table `bounded_context` — UPDATE (generate phase, from `bc_rows_to_update`) — DYNAMIC
Base SQL (always): `UPDATE bounded_context SET status = $3, updated_at = $4 WHERE target_app_id = $1 AND bc_name = $2`, with optional appended assignments. Per-row mapping:
| Source key in `update` dict | column | bind | Condition (column written ONLY when key present) |
|---|---|---|---|
| `target_uuid` | `target_app_id` (WHERE) | $1 | always |
| `update["bc_name"]` | `bc_name` (WHERE) | $2 | always |
| `update["status"]` (whitelisted or defaulted `generate-complete`) | `status` | $3 | always |
| `datetime.now(utc)` | `updated_at` | $4 | always |
| `update["ralph_iterations"]` (int) | `ralph_iterations` | $5 (first optional) | only if `"ralph_iterations" in update` |
| `update["escalations"]` → `json.dumps(...)` | `escalations` | next idx | only if `"escalations" in update`; ⚠️ **JSON-serialized inline here** (NOT via `_JSONB_COLUMNS`) — `escalations` is a JSONB column on `bounded_context`, written as `json.dumps(list)` text |
| `update["generated_path"]` (str) | `generated_path` | next idx | only if `"generated_path" in update` |

⚠️ Placeholder numbering for the optional columns is computed by a running `idx` starting at 5 and incremented per appended assignment, in the FIXED order ralph_iterations → escalations → generated_path. `bc_updated` increments only when `result.endswith(" 1")` — i.e. a row existed (provisioned at G-04b) and matched. A generate update for a BC that was never inserted at G-04b matches 0 rows and does NOT increment `bc_updated` (silent no-op, no error). `created_at` is never touched on update.

## 1.F Modernization — error handling / retries / idempotency / GOTCHAs
- **Invalid `target_app_id`** (not a UUID) → `emit_code_step_complete(FAILED, error=str(exc))` then `raise NonRetryableError(...)`. Non-retryable (NonRetryableError is WorkflowError → passes through wrapper unchanged).
- **Invalid `gate_phase`** (not in `_GATE_PHASES`) → `emit_code_step_complete(FAILED, error=...)` then `raise NonRetryableError(...)`. Non-retryable.
- **Unparseable artifacts** → NOT an error. `_try_parse_json` returns `None`, extractors return empty, and if everything is empty the activity short-circuits at (d): logs "nothing extractable", `emit_code_step_complete(columns_written=[])`, returns a result with all flags False/0. ⚠️ **This is a COMPLETED (not FAILED) terminal state** — the docstring's "return an empty result rather than raising."
- ⚠️ **ASYMMETRIC error path vs ACTIVITY 2:** the modernization activity has **NO outer `try/except Exception`** around the DB work. If `asyncpg.connect`/`conn.execute`/the transaction raises, the `finally` closes the conn and the exception propagates **without** calling `emit_code_step_complete(FAILED)`. So a mid-transaction DB failure leaves the `step_execution` row stuck in `RUNNING` (it is never updated to FAILED). The worker-level `@foundry_activity` wrapper still classifies/wraps the error (retryable vs non-retryable per §0). Contrast: `persist_validation_side_effects` DOES wrap everything and always emits FAILED. **Reproduce this asymmetry exactly — do not "fix" it.**
- **Transaction atomicity:** the `application` UPDATE + all `bounded_context` INSERTs/UPDATEs run inside one `async with conn.transaction():`. A failure on any statement rolls back the whole projection for that gate_phase. ⚠️ `bc_inserted`/`bc_updated` counters are incremented inside the txn from `result.endswith(" 1")`; on a rollback the function never reaches the success-path return, so the counters are not observed.
- **Timestamp non-determinism on retry:** `extraction_at`/`design_at`/`generate_at` come from `input.decided_at` (stable across retries — good), but `updated_at`, `bounded_context.created_at`/`updated_at`, and all `datetime.now(timezone.utc)` calls re-stamp on each attempt. Re-running a gate_phase therefore changes those timestamp columns (and, for already-inserted BCs at G-04b, leaves them untouched due to `DO NOTHING`).
- **Fresh connection per call**, closed in `finally`. No pooling, no statement cache reuse across calls.

---

# ACTIVITY 2 — `persist_validation_side_effects` (4369–4511)

## 2.A Signature & contracts
```python
@foundry_activity(config=ActivityConfig(enable_observability=True))
async def persist_validation_side_effects(
    input: PersistValidationSideEffectsInput,
) -> PersistValidationSideEffectsResult:
```

### Input dataclass — `PersistValidationSideEffectsInput` (`types.py:2358-2396`)
```python
@dataclass
class PersistValidationSideEffectsInput:
    target_app_id: str
    risk_tier: str = ""               # "1" | "2" | "3"; gates which fields project
    parity_report_json: str = ""      # G-V1 parity-report.json
    security_report_json: str = ""    # G-V2 security stream
    accessibility_audit_json: str = ""# G-V2 accessibility stream
    safety_case_json: str = ""        # G-V3 Tier-1 only; "" for Tier-2/3
    safety_case_ref: str = ""         # Tier-1 only; committed safety-case.json path
    decided_at: str = ""
    execution_context: StepExecutionContext | None = None
```
⚠️ `decided_at` is part of the input but is **NOT consumed** by this activity (no `*_at` column is derived from it — `validation_completed_at` is set to `now(utc)` in `_extract_lifecycle_status`, not from `decided_at`). Capture that it is present but unused.

### Output dataclass — `PersistValidationSideEffectsResult` (`types.py:2412-2425`)
```python
@dataclass
class PersistValidationSideEffectsResult:
    target_app_id: str
    parity_score_persisted: bool = False
    critical_vuln_count_persisted: bool = False
    accessibility_score_persisted: bool = False
    safety_case_persisted: bool = False
    validation_status: str = ""
```

### Purpose
Runs **once per target** after the terminal Validation gate approves (G-V2 for Tier-2/Tier-3, G-V3 for Tier-1). Consolidates evidence from the three always-on streams (parity, security, accessibility) plus the Tier-1 safety stream into one UPDATE that touches only populated columns. Failures are observability-only — the workflow continues even if projection raises (the activity re-raises, but the workflow swallows; see §2.E).

## 2.B Validation constant (4200-4210)
```python
_VALIDATION_LIFECYCLE_VALUES = frozenset({
    "validation_in_progress", "validation_parity_approved", "validation_compliance_approved",
    "validation_complete", "validation_failed"})
```
⚠️ Declared for reviewer clarity but **not referenced** by the activity (the lifecycle extractor emits literal strings directly). Capture as documentation of the closed enum the column accepts.

## 2.C Extractor helpers (reproduce verbatim)

### `_extract_parity_side_effects(parity)` → dict — (4211-4237)
1. If not `isinstance(parity, dict)` → `return {}`.
2. `score = parity.get("parity_score")`; if `None` → `score = parity.get("score")` (canonical first, `score` shorthand fallback).
3. If not `isinstance(score, (int, float))` → `return {}`.
4. If not `(0.0 <= float(score) <= 100.0)` → log warning `"validation_parity_score outside 0-100 range; dropping"` (extra `score`) and `return {}`. ⚠️ NUMERIC(5,2) column but range-gated to 0–100 (gate-threshold semantics). ⚠️ `bool` is a subclass of `int` in Python — `True`/`False` would pass the isinstance check and be coerced to `1.0`/`0.0`; in practice agents emit numerics.
5. Return `{"validation_parity_score": float(score)}`.

### `_extract_compliance_side_effects(security_report, accessibility_audit)` → dict — (4238-4301)
G-V2 fields; the two outputs are independent.
**Critical vuln count** (only if `isinstance(security_report, dict)`):
- `count = None`. `raw_count = security_report.get("critical_vuln_count")`; if `isinstance(raw_count, int) and raw_count >= 0` → `count = raw_count`.
- else: `vuln_counts = security_report.get("vuln_counts")`; if `isinstance(vuln_counts, dict)` → `nested = vuln_counts.get("critical")`; if `isinstance(nested, int) and nested >= 0` → `count = nested`.
- if `count is None`: `findings = security_report.get("findings")`; if `isinstance(findings, list)` → `count = sum(1 for f in findings if isinstance(f, dict) and str(f.get("severity","")).lower()=="critical" and str(f.get("classification","")).upper()=="TRUE_POSITIVE")`. ⚠️ This computes a count of `0` when findings is a list with no matches → `count` becomes `0` (not None), so `validation_critical_vuln_count=0` IS written. But if `findings` is absent/not a list, `count` stays `None` and the column is omitted.
- if `count is not None` → `out["validation_critical_vuln_count"] = count`.
⚠️ Priority: top-level int → nested `vuln_counts.critical` → derived from findings. Each tier is gated on the prior being absent/invalid.

**Accessibility score** (only if `isinstance(accessibility_audit, dict)`):
- `score = accessibility_audit.get("accessibility_score")`; if `None` → `score = accessibility_audit.get("wcag_conformance_pct")`.
- if `isinstance(score, (int, float)) and 0.0 <= float(score) <= 100.0` → `out["validation_accessibility_score"] = float(score)`.
- elif `score is not None` (present but invalid/out-of-range) → log `"validation_accessibility_score invalid; dropping"` (extra `score`); omit.
Return `out`.

### `_extract_safety_side_effects(safety_case, *, safety_case_ref, risk_tier)` → dict — (4302-4327)
G-V3, **Tier-1 only**.
1. If `risk_tier != "1"` → `return {}` (unconditional — column stays NULL for non-Tier-1 by design).
2. If not `safety_case_ref` (empty) → `return {}`.
3. Return `{"validation_safety_case_ref": safety_case_ref}`.
⚠️ The `safety_case` payload is **accepted but unused** — only the ref (the committed path) is projected.

### `_extract_lifecycle_status(*, parity_persisted, security_persisted, accessibility_persisted, safety_persisted, risk_tier)` → dict — (4328-4367)
Derives `validation_current_status` (+ `validation_completed_at`) from the four boolean flags.
1. `required = parity_persisted and security_persisted and accessibility_persisted`.
2. If `risk_tier == "1"` → `required = required and safety_persisted`.
3. If `required` → `return {"validation_current_status": "validation_complete", "validation_completed_at": datetime.now(timezone.utc)}`. ⚠️ `validation_completed_at` is stamped **only** in the complete branch, with `now(utc)` (NOT `decided_at`).
4. elif `parity_persisted or security_persisted or accessibility_persisted` → `return {"validation_current_status": "validation_compliance_approved"}` (no completed_at).
5. else → `return {}` (defensive; should not happen — means no dimension projected).

## 2.D Activity control flow (4369-4511) — reproduce exactly

```python
async def persist_validation_side_effects(input) -> PersistValidationSideEffectsResult:
    exec_id = await emit_code_step_start(input.execution_context,
                                         function_name="persist_validation_side_effects")
    try:
        # validate target_app_id
        try:
            target_uuid = uuid.UUID(input.target_app_id)
        except (ValueError, TypeError) as exc:
            await emit_code_step_complete(exec_id, status=ExecutionStatus.FAILED, error=str(exc))
            raise NonRetryableError(f"Invalid target_app_id: {input.target_app_id!r}") from exc

        parity = _try_parse_json(input.parity_report_json)
        security_report = _try_parse_json(input.security_report_json)
        accessibility_audit = _try_parse_json(input.accessibility_audit_json)
        safety_case = _try_parse_json(input.safety_case_json)

        projections: dict[str, Any] = {}
        projections.update(_extract_parity_side_effects(parity))
        projections.update(_extract_compliance_side_effects(security_report, accessibility_audit))
        projections.update(_extract_safety_side_effects(
            safety_case, safety_case_ref=input.safety_case_ref, risk_tier=input.risk_tier))
        projections.update(_extract_lifecycle_status(
            parity_persisted="validation_parity_score" in projections,
            security_persisted="validation_critical_vuln_count" in projections,
            accessibility_persisted="validation_accessibility_score" in projections,
            safety_persisted="validation_safety_case_ref" in projections,
            risk_tier=input.risk_tier))

        if not projections:
            logger.info("persist_validation_side_effects: nothing extractable",
                        extra={"target_app_id": input.target_app_id})
            await emit_code_step_complete(exec_id, columns_written=[])
            return PersistValidationSideEffectsResult(target_app_id=input.target_app_id)

        sql, params = _build_update_sql(projections)
        params.append(target_uuid)

        conn = await asyncpg.connect(_db_url())
        try:
            await conn.execute(sql, *params)
        finally:
            await conn.close()

        logger.info("validation side-effects persisted",
                    extra={"target_app_id": input.target_app_id,
                           "columns_written": sorted(projections.keys())})
        await emit_code_step_complete(exec_id, columns_written=sorted(projections.keys()))
        return PersistValidationSideEffectsResult(
            target_app_id=input.target_app_id,
            parity_score_persisted=("validation_parity_score" in projections),
            critical_vuln_count_persisted=("validation_critical_vuln_count" in projections),
            accessibility_score_persisted=("validation_accessibility_score" in projections),
            safety_case_persisted=("validation_safety_case_ref" in projections),
            validation_status=str(projections.get("validation_current_status", "")),
        )
    except Exception as exc:
        await emit_code_step_complete(exec_id, status=ExecutionStatus.FAILED, error=str(exc))
        raise
```

⚠️ **Order of `projections.update` matters for lifecycle:** parity → compliance (vuln+a11y) → safety → lifecycle. The lifecycle extractor reads the `in projections` membership AFTER the first three updates, so its flags reflect exactly what was projected. The four data extractors emit disjoint keys, so update-order does not cause key collisions among them; lifecycle adds `validation_current_status`/`validation_completed_at` last.

### Result-flag derivation (exact)
- `parity_score_persisted` = `"validation_parity_score" in projections`.
- `critical_vuln_count_persisted` = `"validation_critical_vuln_count" in projections`. ⚠️ True even when the count is `0` (from findings-with-no-matches), since the key is present.
- `accessibility_score_persisted` = `"validation_accessibility_score" in projections`.
- `safety_case_persisted` = `"validation_safety_case_ref" in projections` (always False for Tier-2/Tier-3).
- `validation_status` = `str(projections.get("validation_current_status", ""))` — `""` when lifecycle returned `{}`, else `"validation_complete"` / `"validation_compliance_approved"`.

## 2.E Validation — COMPLETE artifact-field → application.column mapping
Single target table: **`application`** (UPDATE via `_build_update_sql`, keyed `WHERE id = target_uuid`). NONE of these are JSONB.
| Source artifact → value | application.column | Type bind | Condition written |
|---|---|---|---|
| `parity_report.parity_score` ELSE `.score` (float, 0–100) | `validation_parity_score` | float → NUMERIC(5,2) (native) | parity dict, numeric, in [0,100] (else warn/omit) |
| `security_report.critical_vuln_count` (int≥0) ELSE `.vuln_counts.critical` (int≥0) ELSE count of findings with severity=="critical" & classification=="TRUE_POSITIVE" | `validation_critical_vuln_count` | int → integer (native) | security dict AND a resolvable count (incl. 0 from findings); omitted if no findings list and no explicit count |
| `accessibility_audit.accessibility_score` ELSE `.wcag_conformance_pct` (numeric 0–100) | `validation_accessibility_score` | float → numeric (native) | a11y dict, numeric, in [0,100] (else warn/omit) |
| `input.safety_case_ref` | `validation_safety_case_ref` | str → text (native) | **only if `risk_tier=="1"` AND `safety_case_ref` non-empty** |
| `datetime.now(utc)` | `validation_completed_at` | datetime → timestamptz (native) | only when status resolves to `validation_complete` |
| derived literal (`validation_complete` / `validation_compliance_approved`) | `validation_current_status` | str → text (native) | when ≥1 dimension projected; omitted if none |
| `datetime.now(utc)` | `updated_at` | timestamptz | ALWAYS (appended by `_build_update_sql`) when `projections` non-empty |

⚠️ **`validation_complete` requires ALL of parity + security + accessibility (and, for Tier-1, safety) to have been projected.** A Tier-1 run missing the safety ref (or any of the three) downgrades to `validation_compliance_approved` (or `{}` if none). A Tier-2/3 run with parity+security+accessibility all present → `validation_complete` (safety not required).

## 2.F Validation — error handling / retries / idempotency / GOTCHAs
- **Invalid `target_app_id`** → inside the outer try: `emit_code_step_complete(FAILED, error=str(exc))` then `raise NonRetryableError(...)`. ⚠️ The outer `except Exception` ALSO catches this re-raised `NonRetryableError` and calls `emit_code_step_complete(FAILED, error=str(exc))` a **second time** (double-emit on the same exec_id) before re-raising. Both calls hit `update_execution_record` with FAILED; the net effect is the row ends FAILED. Reproduce the double-emit faithfully (it is benign but observable).
- **Nothing extractable** → all four `_try_parse_json` return None / extractors empty → `projections` empty → log "nothing extractable", `emit_code_step_complete(columns_written=[])` (COMPLETED), return result with all flags False and `validation_status=""`. Terminal state is COMPLETED, not FAILED.
- ⚠️ **SYMMETRIC outer `try/except Exception`** (unlike ACTIVITY 1): ANY exception — DB connect/execute failure, unexpected error — is caught, `emit_code_step_complete(exec_id, status=FAILED, error=str(exc))` is called, then `raise` re-raises the ORIGINAL exception. So a DB failure here DOES mark the `step_execution` row FAILED (the modernization activity does not). After re-raise, the `@foundry_activity` worker wrapper classifies/wraps per §0 (retryable type-name match → `RetryableError`, else `NonRetryableError`).
- **"Failures are observability-only / workflow continues":** the activity itself re-raises on DB failure; the docstring's promise that the *workflow* continues means the **calling workflow** wraps this activity call to swallow failures (the projection is non-critical to the line's terminal state). The activity does not itself swallow DB errors.
- **No transaction wrapper** — a single `await conn.execute(sql, *params)` (one UPDATE) on a fresh connection, closed in `finally`. Atomicity is trivially that of one statement.
- **Idempotency:** re-run yields the identical UPDATE except `updated_at` and (in the complete branch) `validation_completed_at` re-stamp to a new `now(utc)`. The data columns are deterministic from the input artifacts + risk_tier.
- **Fresh `asyncpg.connect(_db_url())` per call**, closed in `finally`.

---

## 3. Cross-activity GOTCHAs / parity checklist
1. ⚠️ **Error-path asymmetry between the two activities** (§1.F vs §2.F) — modernization has no outer try/except (DB failure leaves RUNNING); validation does (DB failure → FAILED). This is the single most important non-obvious difference. Do not normalize them.
2. ⚠️ Both rely on `_build_update_sql` iterating `_SIDE_EFFECT_COLUMNS` in **tuple order** for placeholder numbering, and on `params.append(target_uuid)` being done by the caller AFTER the helper returns so the app_id is the final `$N` in the WHERE.
3. ⚠️ JSONB serialization split: `_build_update_sql` serializes only columns in `_JSONB_COLUMNS` (for this group: `bounded_contexts`, `generated_module_refs`). The Modernization `bounded_context.escalations` column is serialized **inline in the activity body** with its own `json.dumps`, NOT through `_JSONB_COLUMNS`.
4. ⚠️ Timestamp sources: `decided_at` (input, stable) feeds `extraction_at`/`design_at`/`generate_at`; everything else (`updated_at`, `validation_completed_at`, bounded_context `created_at`/`updated_at`) uses `datetime.now(timezone.utc)` and re-stamps on retry. `validation_completed_at` does NOT come from `decided_at` despite `decided_at` being an input field.
5. ⚠️ `_try_parse_json` returning a non-dict JSON value (array/scalar) yields `None`, treated identically to "unparseable" — extractors contribute nothing.
6. ⚠️ Modernization design-phase: `application` UPDATE and `bounded_context` INSERT are independent — projections may be empty while BC rows are inserted, and vice versa is impossible (insert rows derive from module_map which also drives `bounded_contexts`/pattern, but pattern/ref can be empty while names exist).
7. ⚠️ asyncpg command-tag parsing: insert/update success is detected via `result.endswith(" 1")` (`"INSERT 0 1"`, `"UPDATE 1"`). `ON CONFLICT DO NOTHING` yields `"INSERT 0 0"` → not counted. A G-04c update for a never-provisioned BC yields `"UPDATE 0"` → not counted, no error.

## 4. Undetermined / external dependencies
- Exact DDL of `application` and `bounded_context` (column SQL types, the `UNIQUE (target_app_id, bc_name)` constraint backing `ON CONFLICT`, JSONB-ness of `escalations`/`bounded_contexts`/`generated_module_refs`, NUMERIC precision of score columns) lives in the migrations under the data layer (Phase 9), not in this file. Types inferred from the code's `json.dumps` usage, the `_JSONB_COLUMNS` set, range comments ("NUMERIC(5,2)"), and column comments are accurate for behavioral parity but the authoritative DDL is owned elsewhere.
- `emit_execution_record` / `update_execution_record` internals (the `step_execution` table write) are owned by `olympus_workflows/utils/execution.py` (a sibling/utility group), summarized here only as far as needed.
