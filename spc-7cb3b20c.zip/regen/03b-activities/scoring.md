# Activity Group: Scoring

ATOMIC regeneration spec for `temporal/olympus_workflows/activities/scoring.py`.

Source of truth: `/Users/pnunna/Documents/GitHub/foundry/temporal/olympus_workflows/activities/scoring.py` (450 lines).

This group contains **3 Temporal activities** plus **6 module-level helper functions** and **2 module-level constants**. An engineer with no access to the code must be able to reproduce identical behavior from this file alone. The bar is **behavioral parity**, including the exact scoring arithmetic, the exact SQL, and the exact column-by-column projection mapping for the persist activity.

Activities:
1. `calculate_readiness_score` — reads Discovery evidence from `gate.evidence_data`, computes a 6-dimension + overall readiness vector on the **1–5 scale**, falling back to hard-coded defaults.
2. `record_score_snapshot` — appends **7 rows** (6 dimensions + `overall`) into `score_history` for trend analysis.
3. `persist_portfolio_score` — parses `portfolio-scorer` skill JSON, sanitizes a 6-dimension readiness vector on the **0–100 scale**, computes a weighted overall, and writes the whole payload to `application.portfolio_score` (JSONB UPDATE).

⚠️ **Two different scales coexist in this module.** `calculate_readiness_score` / `record_score_snapshot` operate on a **1–5 scale** (the "Discovery readiness score"). `persist_portfolio_score` operates on a **0–100 scale** (the "P3.5-R3.3 portfolio readiness vector"). They are unrelated pipelines that happen to live in the same file. Do not unify them.

---

## 0. THE DECORATOR — `@foundry_activity` (capture once, applies to ALL 3 activities)

All three activities are decorated with:

```python
@foundry_activity(config=ActivityConfig(enable_observability=True))
```

from `foundry_temporal.activities` (NOT plain `@temporalio.activity.defn`). Source: `foundry_temporal/activities.py:107-165`. A rebuild that uses plain `@activity.defn` **loses error-wrapping + retryability classification** and is non-conformant.

### `ActivityConfig` dataclass (`activities.py:27-39`)
All fields optional with defaults:
| field | type | default |
|---|---|---|
| `retry_policy` | `RetryPolicy \| None` | `None` |
| `start_to_close_timeout` | `timedelta \| None` | `None` |
| `schedule_to_close_timeout` | `timedelta \| None` | `None` |
| `schedule_to_start_timeout` | `timedelta \| None` | `None` |
| `heartbeat_timeout` | `timedelta \| None` | `None` |
| `enable_observability` | `bool` | `True` |
| `enable_error_wrapping` | `bool` | `True` |
| `log_inputs` | `bool` | `False` |
| `log_outputs` | `bool` | `False` |

All three scoring activities pass **only** `enable_observability=True`. Therefore each runs with: `enable_error_wrapping=True` (default, NOT disabled), `log_inputs=False`, `log_outputs=False`, and **no** `retry_policy`/timeouts set at the decorator level (timeouts/retry come from the workflow's `execute_activity` call, not here).

### What `foundry_activity(config)` does (exact, `activities.py:122-163`)
It returns a `decorator(func)` that:
1. Resolves `activity_config = config or ActivityConfig()`.
2. Wraps `func` in an `async def wrapper(*args, **kwargs)` that is itself decorated `@activity.defn(name=name, **activity_kwargs)` and `@wraps(func)`. **`name` is `None` for all three here**, so the Temporal-registered activity name is the function's `__name__` (i.e. `calculate_readiness_score`, `record_score_snapshot`, `persist_portfolio_score`). ⚠️ `@wraps(func)` preserves `__name__`/`__wrapped__`; tests invoke the **undecorated** function via `<activity>.__wrapped__(...)` (see `temporal/tests/test_scoring_portfolio.py:205`).
3. On call, sets `activity_name = name or func.__name__`, obtains `activity_logger = get_logger()`.
4. If `enable_observability` (true here): logs INFO `f"Activity {activity_name} starting"` with `extra={"inputs": args if log_inputs else None}` → because `log_inputs=False`, `extra={"inputs": None}`.
5. Runs `result = await func(*args, **kwargs)`.
6. If `enable_observability`: logs INFO `f"Activity {activity_name} completed"` with `extra={"outputs": result if log_outputs else None}` → `{"outputs": None}`.
7. Returns `result`.
8. **Exception path** (`activities.py:148-161`): on any `Exception`:
   - If `enable_observability`: logs ERROR `f"Activity {activity_name} failed: {error}"` with `extra={"error": str(error)}`.
   - If `enable_error_wrapping` (true here):
     - If `isinstance(error, (WorkflowError, ApplicationError))` → **re-raise as-is** (`raise`). ⚠️ This is why `persist_portfolio_score` raising `NonRetryableError` for a bad `app_id` passes through unchanged (it subclasses `WorkflowError`→`ApplicationError`, see `errors.py:24-28,10-14`) and stays **non-retryable**.
     - elif `_is_retryable_error(error)` → `raise RetryableError(f"Retryable error in {activity_name}: {error}") from error`.
     - else → `raise NonRetryableError(f"Non-retryable error in {activity_name}: {error}") from error`.
   - else (`enable_error_wrapping=False`, not the case here): `raise`.

### `_is_retryable_error(error)` — the classifier used by the wrapper (`activities.py:168-183`)
⚠️ This is the **string-pattern classifier**, NOT `errors.is_retryable_error`. It does:
```
error_str = str(type(error)).lower()
retryable_patterns = ["timeout","connection","network","temporary","unavailable",
                       "overload","busy","throttle","rate_limit"]
return any(pattern in error_str for pattern in retryable_patterns)
```
It inspects `str(type(error))` (the class repr, e.g. `"<class 'asyncpg.exceptions.ConnectionDoesNotExistError'>"`), lowercased, for any substring. So an `asyncpg` error whose class name contains `connection`/`timeout` becomes a `RetryableError`; an arbitrary unmatched exception becomes a `NonRetryableError`. **Default for unknown errors is non-retryable.**

### Error classes (`foundry_temporal/errors.py`)
- `WorkflowError(ApplicationError)` — `__init__(message, non_retryable=True)` (errors.py:10-14).
- `RetryableError(WorkflowError)` — sets `non_retryable=False` (errors.py:17-21).
- `NonRetryableError(WorkflowError)` — sets `non_retryable=True` (errors.py:24-28).
The `non_retryable` flag on the resulting `ApplicationError` is what Temporal honors for its own retry decisions.

### ⚠️ Decorator-level retry/timeout gotcha
Because none of the three set `retry_policy` or timeouts in `ActivityConfig`, retryability is governed by **(a)** the `non_retryable` flag baked into the wrapped error, and **(b)** the `RetryPolicy`/timeouts supplied by the **workflow** at `execute_activity`-time. The activity docstrings *recommend* `HTTP_RETRY_POLICY` (`foundry_temporal/retry_policies.py:37-42`: `initial_interval=1s, maximum_interval=15s, maximum_attempts=3, backoff_coefficient=2.0`) but the activity code itself does **not** set it — the caller must. Do not hard-code a retry policy into these activities.

---

## 1. Module-level constants & imports

File header imports (scoring.py:14-33):
```python
from __future__ import annotations
import json, logging, os, uuid
from datetime import datetime, timezone
import asyncpg
from foundry_temporal.activities import ActivityConfig, foundry_activity
from foundry_temporal.errors import NonRetryableError
from olympus_workflows.types import (
    CalculateReadinessScoreInput, PersistPortfolioScoreInput,
    PersistPortfolioScoreResult, ReadinessScoreResult,
    RecordScoreSnapshotInput, RecordScoreSnapshotResult,
)
logger = logging.getLogger(__name__)
```

### `DEFAULT_DISCOVERY_SCORES` (scoring.py:39-46) — 1–5 scale fallback
```python
DEFAULT_DISCOVERY_SCORES: dict[str, float] = {
    "code_quality": 3.0,
    "test_coverage": 2.5,
    "security_posture": 3.0,
    "documentation": 2.0,
    "dependency_currency": 3.0,
    "architecture_clarity": 2.5,
}
```
⚠️ Exact float values are load-bearing. With all defaults and no dimension filter the overall is `(3.0+2.5+3.0+2.0+3.0+2.5)/6 = 16.0/6 = 2.6666… → round(…,2) = 2.67`.

### `DIMENSION_NAMES` (scoring.py:49-56)
Ordered list of the same 6 names (order = deterministic output). Defined for completeness; the activity code does not iterate this list directly (it iterates `scores`), but reproduce it verbatim.
```python
DIMENSION_NAMES = ["code_quality","test_coverage","security_posture",
                   "documentation","dependency_currency","architecture_clarity"]
```

### `_PORTFOLIO_DIMENSIONS` (scoring.py:283-290) — 0–100 scale, tuple
```python
_PORTFOLIO_DIMENSIONS = (
    "technical_readiness",
    "architectural_readiness",
    "operational_readiness",
    "security_readiness",
    "user_experience_readiness",
    "business_readiness",
)
```
⚠️ Length 6 → `default_w = 1/6 ≈ 0.16666…`. Iteration order over this tuple defines the weighted-mean accumulation order and the order of `sanitized` dict insertion.

---

## 2. Shared helper: `_db_url() -> str` (scoring.py:59-66)

Builds a PostgreSQL DSN from env vars with these **exact** defaults:
| env var | default |
|---|---|
| `DATABASE_HOST` | `"localhost"` |
| `DATABASE_PORT` | `"5432"` |
| `DATABASE_USER` | `"olympus"` |
| `DATABASE_PASSWORD` | `"olympus"` |
| `DATABASE_NAME` | `"olympus"` |

Returns `f"postgresql://{user}:{password}@{host}:{port}/{db}"`. Used by all three DB-touching code paths. ⚠️ No connection pooling — each call opens a fresh `asyncpg.connect()` and closes it in a `finally`.

---

## 3. ACTIVITY: `calculate_readiness_score`

### Signature
```python
@foundry_activity(config=ActivityConfig(enable_observability=True))
async def calculate_readiness_score(input: CalculateReadinessScoreInput) -> ReadinessScoreResult
```
Source: scoring.py:136-193.

### Input type `CalculateReadinessScoreInput` (types.py:1024-1029, `@dataclass`)
| field | type | default |
|---|---|---|
| `app_id` | `str` | (required) |
| `dimensions` | `list[str]` | `field(default_factory=list)` → `[]` |

### Output type `ReadinessScoreResult` (types.py:1032-1044, `@dataclass`)
| field | type | default |
|---|---|---|
| `app_id` | `str` | (required) |
| `overall` | `float` | `0.0` |
| `code_quality` | `float` | `0.0` |
| `test_coverage` | `float` | `0.0` |
| `security_posture` | `float` | `0.0` |
| `documentation` | `float` | `0.0` |
| `dependency_currency` | `float` | `0.0` |
| `architecture_clarity` | `float` | `0.0` |
| `calculated_at` | `str` | `""` |

### Algorithm (reproduce exactly)
```
now = datetime.now(timezone.utc).isoformat()              # ISO-8601 string, computed FIRST

evidence = await _fetch_evidence_from_gate(input.app_id)  # dict | None  (see §3.1)
real_scores = _extract_scores_from_evidence(evidence) if evidence else None   # dict | None (see §3.2)

# Choose source: real scores win; else a COPY of the defaults
scores = real_scores if real_scores else dict(DEFAULT_DISCOVERY_SCORES)
#  ⚠️ truthiness check: real_scores is None OR {} -> use defaults. dict(...) makes a fresh copy.

# Optional dimension filter
if input.dimensions:                                       # non-empty list
    scores = {k: v for k, v in scores.items() if k in input.dimensions}
#  ⚠️ filter keeps ONLY requested dims that exist in scores. Unknown requested names are silently dropped.

# Overall = simple arithmetic mean of whatever survived (EQUAL weights)
overall = sum(scores.values()) / len(scores) if scores else 0.0
#  ⚠️ if scores becomes empty (e.g. dimensions filter matched nothing) -> overall = 0.0 (guard against /0)

source = "evidence" if real_scores else "defaults"
logger.info("Readiness score calculated", extra={
    "app_id": input.app_id, "overall": overall,
    "dimensions": list(scores.keys()), "source": source})

return ReadinessScoreResult(
    app_id=input.app_id,
    overall=round(overall, 2),                             # ⚠️ overall is rounded to 2 dp
    code_quality        = scores.get("code_quality", 0.0),
    test_coverage       = scores.get("test_coverage", 0.0),
    security_posture    = scores.get("security_posture", 0.0),
    documentation       = scores.get("documentation", 0.0),
    dependency_currency = scores.get("dependency_currency", 0.0),
    architecture_clarity= scores.get("architecture_clarity", 0.0),
    calculated_at=now,
)
```

⚠️ **Per-dimension fields are NOT rounded** — only `overall` is `round(…, 2)`. Per-dimension values are emitted verbatim (e.g. `float(score)` from evidence, or the raw default).
⚠️ **Dimension-filter asymmetry:** if `input.dimensions` is set, the filter shrinks `scores`, which shrinks BOTH the overall denominator AND the per-dimension output. A filtered-out dimension reports `scores.get(name, 0.0) = 0.0` in the result even though its "true" value existed in the source. So the filter changes both the mean and the individual emitted values.

### Inputs READ from DB
Via `_fetch_evidence_from_gate` → one `gate` row's `evidence_data` JSONB. No writes.

### Outputs WRITTEN
None to DB. Returns a `ReadinessScoreResult` dataclass only.

### 3.1 Helper `_fetch_evidence_from_gate(app_id: str) -> dict | None` (scoring.py:98-133)
```
try:
    conn = await asyncpg.connect(_db_url())
    try:
        row = await conn.fetchrow(
            """
            SELECT evidence_data
            FROM gate
            WHERE application_id = $1::uuid
              AND gate_type = 'G-DC'
            ORDER BY requested_at DESC
            LIMIT 1
            """,
            uuid.UUID(app_id),                 # $1 — Python UUID, cast ::uuid in SQL
        )
    finally:
        await conn.close()
except (OSError, asyncpg.PostgresError) as exc:
    logger.warning("Could not fetch gate evidence; falling back to defaults",
                   extra={"app_id": app_id, "error": str(exc)})
    return None

if row is None or row["evidence_data"] is None:
    return None

evidence = row["evidence_data"]
if isinstance(evidence, str):                  # ⚠️ asyncpg may return JSONB as str OR dict
    evidence = json.loads(evidence)
return evidence
```
- Targets the **latest `G-DC` gate** (Discovery Complete) for the app, by `requested_at DESC LIMIT 1`.
- ⚠️ `gate_type = 'G-DC'` is a literal compared against the `gate_type_enum` column (003_create_workflow_tables.py:66). Only G-DC evidence is consulted; other gate types are ignored.
- ⚠️ **`uuid.UUID(app_id)` is OUTSIDE the try/except.** If `app_id` is not a valid UUID, `ValueError` is raised here and propagates up to the activity body (the activity has no try/except around the call), then through the `@foundry_activity` wrapper. `str(type(ValueError))` contains none of the retryable patterns → wrapped as **`NonRetryableError`**.
- ⚠️ Only `OSError` and `asyncpg.PostgresError` are caught → DB connection/query failures degrade gracefully to `None` (then the activity uses defaults). Any other exception (e.g. the UUID `ValueError`, or a `json.JSONDecodeError` from a malformed JSONB string) escapes.

### 3.2 Helper `_extract_scores_from_evidence(evidence_data: dict) -> dict[str,float] | None` (scoring.py:69-95)
Reads the synthesis-pass readiness vector out of the gate evidence. **Exact JSON path read:** `evidence_data["passes"]["synthesis"]["modernization_readiness_score"]["dimensions"]` → list of `{name, score}`.
```
passes    = evidence_data.get("passes") or {}
synthesis = passes.get("synthesis") or {}
readiness = synthesis.get("modernization_readiness_score")
if not readiness:            return None          # ⚠️ missing OR falsy (e.g. {}) -> None
dimensions = readiness.get("dimensions")
if not dimensions:           return None          # ⚠️ missing OR empty list -> None
scores = {}
for dim in dimensions:
    name  = dim.get("name")
    score = dim.get("score")
    if name and score is not None:                # name truthy AND score not None (0 is allowed)
        scores[name] = float(score)               # coerce to float
return scores if scores else None                 # ⚠️ empty dict -> None
```
- ⚠️ Accepts **any** dimension names present in evidence — it does NOT filter against `DIMENSION_NAMES`. So evidence could supply extra/renamed dims; they flow into `scores` and then into `overall` (but only the 6 known names map to result fields; unknown names contribute to the mean but are not emitted as fields).
- ⚠️ `score == 0` is kept (only `score is None` is rejected). `name == ""`/`None`/`0` is rejected (falsy).
- ⚠️ A non-float-coercible `score` raises `ValueError`/`TypeError` inside the loop, which escapes `_extract_scores_from_evidence` (no local catch) and the activity → wrapped as `NonRetryableError`.

### Error handling / retries / idempotency
- **Idempotent / read-only / pure** w.r.t. DB given the same gate row. No writes.
- DB unreachable → `None` → falls back to `DEFAULT_DISCOVERY_SCORES` (graceful; activity still succeeds). This is the resilience contract: scoring never fails just because the DB is down.
- Bad UUID or malformed evidence JSON → exception → `NonRetryableError` (string classifier doesn't match).

---

## 4. ACTIVITY: `record_score_snapshot`

### Signature
```python
@foundry_activity(config=ActivityConfig(enable_observability=True))
async def record_score_snapshot(input: RecordScoreSnapshotInput) -> RecordScoreSnapshotResult
```
Source: scoring.py:196-268.

### Input type `RecordScoreSnapshotInput` (types.py:1047-1053, `@dataclass`)
| field | type | default |
|---|---|---|
| `app_id` | `str` | (required) |
| `scores` | `ReadinessScoreResult` | (required) — the full dataclass from §3 |
| `snapshot_reason` | `str` | `""` |

### Output type `RecordScoreSnapshotResult` (types.py:1056-1062, `@dataclass`)
| field | type | default |
|---|---|---|
| `app_id` | `str` | (required) |
| `snapshot_id` | `str` | `""` |
| `recorded_at` | `str` | `""` |

### Algorithm
```
snapshot_id = f"snap-{uuid.uuid4().hex[:12]}"          # e.g. "snap-1a2b3c4d5e6f"  (12 hex chars)
now      = datetime.now(timezone.utc)                  # tz-aware datetime (object, NOT iso)
now_iso  = now.isoformat()                             # string for the result

dimension_scores = {                                   # ⚠️ dict order = insertion order below
    "code_quality":         input.scores.code_quality,
    "test_coverage":        input.scores.test_coverage,
    "security_posture":     input.scores.security_posture,
    "documentation":        input.scores.documentation,
    "dependency_currency":  input.scores.dependency_currency,
    "architecture_clarity": input.scores.architecture_clarity,
    "overall":              input.scores.overall,       # ⚠️ 7th entry: literal dimension name "overall"
}

try:
    conn = await asyncpg.connect(_db_url())
    try:
        for dimension, score in dimension_scores.items():   # 7 iterations -> 7 INSERTs
            await conn.execute(
                """
                INSERT INTO score_history
                    (id, application_id, dimension, score, recorded_at,
                     source_artifact, governance_cycle)
                VALUES ($1, $2::uuid, $3, $4, $5, $6, $7)
                """,
                uuid.uuid4(),            # $1  id           — NEW uuid per row (7 distinct ids)
                uuid.UUID(input.app_id), # $2  application_id (cast ::uuid)
                dimension,               # $3  dimension    — str
                score,                   # $4  score        — float -> Numeric
                now,                     # $5  recorded_at  — SAME timestamp for all 7 rows
                snapshot_id,             # $6  source_artifact — the "snap-…" id (groups the 7 rows)
                input.snapshot_reason,   # $7  governance_cycle — the snapshot reason string
            )
    finally:
        await conn.close()
except (OSError, asyncpg.PostgresError) as exc:
    logger.warning("Could not write score snapshot to DB; snapshot logged only",
                   extra={"app_id": input.app_id, "error": str(exc)})

logger.info("Score snapshot recorded", extra={
    "app_id": input.app_id, "snapshot_id": snapshot_id,
    "snapshot_reason": input.snapshot_reason,
    "overall_score": input.scores.overall,
    "rows_written": len(dimension_scores)})            # 7

return RecordScoreSnapshotResult(app_id=input.app_id, snapshot_id=snapshot_id, recorded_at=now_iso)
```

### ⚠️ Projection mapping — `score_history` table (one INSERT per dimension, 7 rows)
Target table: **`score_history`** (DDL: `db/alembic/versions/004_create_analytics_tables.py:55-68`; indexes 005:48-53; SQLAlchemy/pydantic mirror `olympus-api/src/models/analytics.py:142-149`). **No unique constraint** on the table (only two non-unique indexes: `ix_score_history_app_recorded` on `(application_id, recorded_at)`, `ix_score_history_dimension` on `(dimension)`), so this INSERT is a **plain append — there is NO ON CONFLICT clause.**

For EACH of the 7 dimensions, one row is written. Column-by-column:

| score_history column | DB type / constraint | source expression (`$n`) | default / condition |
|---|---|---|---|
| `id` | UUID, PK, `server_default gen_random_uuid()` | `uuid.uuid4()` ($1) | ⚠️ **explicitly supplied per row** — overrides server default; a fresh UUID for each of the 7 rows |
| `application_id` | UUID, FK→`application.id` `ON DELETE CASCADE`, NOT NULL | `uuid.UUID(input.app_id)` ($2, cast `::uuid`) | always written; same value for all 7 rows |
| `dimension` | `VARCHAR(100)`, NOT NULL | loop key `dimension` ($3) | one of the 6 dim names or the literal `"overall"` |
| `score` | `NUMERIC`, NOT NULL | loop value `score` ($4) | the float from the matching `ReadinessScoreResult` field (asyncpg adapts `float`→`numeric`) |
| `recorded_at` | `TIMESTAMPTZ`, NOT NULL, `server_default now()` | `now` ($5) | ⚠️ **explicitly supplied** — overrides server default; **identical** tz-aware timestamp for all 7 rows |
| `source_artifact` | `TEXT`, nullable | `snapshot_id` ($6) | always written here = `"snap-<12hex>"`; this is the **grouping key** that ties the 7 rows into one snapshot |
| `governance_cycle` | `VARCHAR(100)`, nullable | `input.snapshot_reason` ($7) | always written = the snapshot reason; defaults to `""` if caller passed no reason |

**All 7 columns are written on every row.** There are no conditional/partial columns in this projection.

⚠️ **Semantic repurposing of columns** (do NOT "fix" this — it is the contract the read API expects): `source_artifact` carries the synthetic `snapshot_id` (not a Git artifact path), and `governance_cycle` carries the free-text `snapshot_reason` (not a cycle id). The read side (`ScoreHistoryEntry`, analytics.py:142-149) surfaces these fields raw.

### Inputs READ / Outputs WRITTEN
- READ: none.
- WRITTEN: 7 rows into `score_history` (best-effort; see error handling).

### Error handling / retries / idempotency
- ⚠️ **Best-effort persistence:** `OSError`/`asyncpg.PostgresError` during connect or any INSERT is **caught and swallowed** (logged at WARNING). The activity **still returns success** with the `snapshot_id`. So a DB outage yields a "recorded" result with no rows in the table — the snapshot was "logged only."
- ⚠️ **Partial-write window:** the 7 INSERTs are **NOT wrapped in a transaction** (`conn.execute` autocommits each statement). If the connection dies on, say, row 4, rows 1–3 are already committed, the `except` swallows the error, and the activity returns success. Rebuild MUST preserve the no-transaction, swallow-and-succeed behavior (do not add a `BEGIN/COMMIT` or re-raise).
- ⚠️ **Bad UUID:** `uuid.UUID(input.app_id)` runs **inside** the loop body but its `ValueError` is **NOT** an `OSError`/`asyncpg.PostgresError`, so it is **not** caught here → escapes to the wrapper → `NonRetryableError`. (Note: the first iteration constructs the UUID; the exception fires on row 1 before any row is written.)
- **Idempotency:** **NOT idempotent.** Re-running appends another 7 rows with new `id`s and a new `snapshot_id`/`recorded_at`. Trend analysis dedups by `source_artifact`(=snapshot_id)+`recorded_at`, not by upsert. Temporal at-least-once delivery → duplicate snapshots possible on retry; this is accepted.

---

## 5. ACTIVITY: `persist_portfolio_score` (PROJECTION — P3.5-R3.3)

### Signature
```python
@foundry_activity(config=ActivityConfig(enable_observability=True))
async def persist_portfolio_score(input: PersistPortfolioScoreInput) -> PersistPortfolioScoreResult
```
Source: scoring.py:360-449. Registered with the worker at `temporal/olympus_workflows/worker.py:105,210` (NOT re-exported from `activities/__init__.py`). Tests call `persist_portfolio_score.__wrapped__(...)` (test_scoring_portfolio.py).

### Input type `PersistPortfolioScoreInput` (types.py:1264-1280, `@dataclass`)
| field | type | default |
|---|---|---|
| `app_id` | `str` | (required) |
| `score_json` | `str` | `""` — raw JSON (possibly embedded in agent prose) from the `portfolio-scorer` skill |
| `weights` | `dict[str, float]` | `field(default_factory=dict)` → `{}` — optional per-dimension weight override (workflow looks these up from the profile's `scoring.yaml`) |

### Output type `PersistPortfolioScoreResult` (types.py:1283-1293, `@dataclass`)
| field | type | default |
|---|---|---|
| `app_id` | `str` | (required) |
| `persisted` | `bool` | `False` |
| `overall_weighted` | `float \| None` | `None` |
| `dimensions_persisted` | `list[str]` | `field(default_factory=list)` → `[]` |

### Pattern note (scoring.py:271-280)
Mirrors `persist_classification`: defensive parsing, **partial writes land what's valid**, entirely-unparseable output is a **no-op** (returns `persisted=False`, no DB write). Returns the sanitized payload + computed overall so the workflow can feed the `sequencer` without re-reading the DB.

### Control flow (exact)
```
# 1. Validate app_id FIRST — bad id is a hard, non-retryable failure
try:
    app_uuid = uuid.UUID(input.app_id)
except (ValueError, TypeError) as exc:
    raise NonRetryableError(f"Invalid app_id: {input.app_id!r}") from exc
#  ⚠️ This is the ONE place this module raises an explicit typed error.
#     NonRetryableError -> WorkflowError -> ApplicationError(non_retryable=True);
#     the @foundry_activity wrapper re-raises it AS-IS (isinstance ApplicationError) -> stays non-retryable.
#     Note {input.app_id!r} uses repr() (quotes the value).

# 2. Parse JSON tolerantly (see §5.1)
parsed = _parse_portfolio_score_json(input.score_json)
if not parsed:                                    # {} -> unparseable
    logger.warning("persist_portfolio_score: unparseable skill output",
                   extra={"app_id": input.app_id})
    return PersistPortfolioScoreResult(app_id=input.app_id, persisted=False)
    #  ⚠️ NO-OP: no DB write, persisted=False, overall_weighted=None, dimensions_persisted=[]

# 3. Sanitize each known dimension (see §5.2). Only keep dims that sanitize to non-None.
raw_scores = parsed.get("scores") or {}           # ⚠️ "scores" missing/falsy -> {}
sanitized = {}
for dim in _PORTFOLIO_DIMENSIONS:                 # iterate the 6 known dims IN TUPLE ORDER
    entry = _sanitize_portfolio_dimension(raw_scores.get(dim))
    if entry is not None:
        sanitized[dim] = entry

if not sanitized:                                 # parsed JSON but no recognizable dims
    logger.warning("persist_portfolio_score: no valid dimensions in skill output",
                   extra={"app_id": input.app_id, "parsed_keys": list(parsed.keys())})
    return PersistPortfolioScoreResult(app_id=input.app_id, persisted=False)
    #  ⚠️ NO-OP again.
#  ⚠️ Only the 6 names in _PORTFOLIO_DIMENSIONS are considered. Extra keys in raw_scores are dropped.

# 4. Coerce weights (override) if provided
weights = None
if input.weights:                                 # non-empty dict
    try:
        weights = {k: float(v) for k, v in input.weights.items()}
    except (TypeError, ValueError):
        weights = None                            # ⚠️ ANY bad weight value -> discard ALL weights -> equal-weight fallback
#  Note: weight keys are NOT validated against _PORTFOLIO_DIMENSIONS here; only dims present in
#  `sanitized` consume a weight (see §5.3), unknown weight keys are simply never looked up.

# 5. Compute weighted overall over non-null dims (see §5.3)
overall = _compute_portfolio_overall(sanitized, weights)        # float | None

# 6. methodology_version — string, default "1.0.0"
methodology_version = str(parsed.get("methodology_version") or "1.0.0")
#  ⚠️ falsy (missing/None/"" /0) -> "1.0.0"; otherwise str() of whatever was supplied

# 7. Build the JSONB payload
payload = {
    "scores": sanitized,                          # {dim: {score, rationale, evidence}}
    "overall_weighted": overall,                  # float | None
    "methodology_version": methodology_version,   # str
    "computed_at": datetime.now(timezone.utc).isoformat(),   # ISO string, computed at build time
}

# 8. Write — single UPDATE on application
conn = await asyncpg.connect(_db_url())
try:
    await conn.execute(
        """
        UPDATE application
        SET portfolio_score = $1::jsonb,
            updated_at = $2
        WHERE id = $3
        """,
        json.dumps(payload),                      # $1 — payload serialized to a JSON string, cast ::jsonb
        datetime.now(timezone.utc),               # $2 — ⚠️ SECOND now() call (distinct from computed_at)
        app_uuid,                                 # $3 — Python UUID (no ::uuid cast; column is uuid, asyncpg adapts)
    )
finally:
    await conn.close()

logger.info("Portfolio score persisted", extra={
    "app_id": input.app_id,
    "dimensions_persisted": sorted(sanitized.keys()),    # ⚠️ SORTED alphabetically
    "overall_weighted": overall})

return PersistPortfolioScoreResult(
    app_id=input.app_id,
    persisted=True,
    overall_weighted=overall,
    dimensions_persisted=sorted(sanitized.keys()),       # ⚠️ SORTED alphabetically, NOT tuple order
)
```

### ⚠️ Projection mapping — `application` table (single UPDATE, JSONB blob)
Target table: **`application`** (base DDL `002_create_core_tables.py:47-55`: `id` UUID PK, `updated_at` TIMESTAMPTZ NOT NULL). Column `portfolio_score` added by `024_add_application_portfolio_score.py:43-47` as **`JSONB`, nullable**.

SQL is an **UPDATE … WHERE id = $3** (no INSERT, no ON CONFLICT, no UPSERT). If the app row doesn't exist, the UPDATE matches 0 rows and **silently succeeds** (asyncpg `execute` returns `"UPDATE 0"`, not checked). Columns touched:

| application column | DB type | source expression ($n) | written when |
|---|---|---|---|
| `portfolio_score` | `JSONB`, nullable | `json.dumps(payload)` ($1, cast `::jsonb`) | **always** when reaching step 8 (i.e. ≥1 sanitized dim) — overwrites any prior value wholesale |
| `updated_at` | `TIMESTAMPTZ`, NOT NULL | `datetime.now(timezone.utc)` ($2) | **always** alongside the write |
| `id` | UUID PK | `app_uuid` ($3) — **WHERE clause only**, not SET | row selector |

⚠️ **Only `portfolio_score` and `updated_at` are written.** No other application column is touched. The write is **all-or-nothing per call**: either the no-op early-returns fire (no write at all) or the full JSONB blob replaces the column.

#### The `portfolio_score` JSONB payload — internal field map (what lands inside the column)
The JSONB document written has EXACTLY these 4 top-level keys:

| payload key | type | value / source |
|---|---|---|
| `scores` | object | `sanitized` — map of dim-name → `{score, rationale, evidence}` (only valid dims; see §5.2 shape) |
| `overall_weighted` | number \| null | `_compute_portfolio_overall(sanitized, weights)` (2-dp rounded or `null`) |
| `methodology_version` | string | `str(parsed.get("methodology_version") or "1.0.0")` |
| `computed_at` | string | `datetime.now(timezone.utc).isoformat()` (build-time) |

Each entry inside `scores[dim]` (from `_sanitize_portfolio_dimension`):
| sub-field | type | rule |
|---|---|---|
| `score` | float \| null | clamped to `[0.0, 100.0]`, or `null` if absent/uncoercible |
| `rationale` | string \| null | coerced to `str` if present and not already str; `null` if absent |
| `evidence` | list[str] | each element `str()`-coerced; `[]` if absent or not a list |

(Mirror read models: `PortfolioScoreDimension`/`PortfolioScoreResponse`, analytics.py:161-204.)

⚠️ **`computed_at` (in payload) vs `updated_at` (column) are produced by TWO SEPARATE `datetime.now(timezone.utc)` calls** (scoring.py:416 vs 429). They will differ by microseconds. Reproduce as two distinct calls — do not reuse one timestamp.

### 5.1 Helper `_parse_portfolio_score_json(raw: str) -> dict` (scoring.py:293-307)
```
if not raw:                       return {}                 # "" / None -> {}
try:
    return json.loads(raw) if isinstance(raw, str) else {}  # ⚠️ non-str input -> {} (even if dict-like)
except json.JSONDecodeError:
    start = raw.find("{")
    end   = raw.rfind("}")
    if start == -1 or end <= start: return {}
    try:
        return json.loads(raw[start : end + 1])             # substring from first { to last }
    except json.JSONDecodeError:    return {}
```
⚠️ Tolerant: handles raw JSON, JSON embedded in prose (extracts the first-`{` … last-`}` slice), and gives up to `{}` on failure. ⚠️ If `json.loads(raw)` succeeds but returns a non-dict (e.g. a JSON array or scalar), it is returned **as-is** (not coerced) — then `parsed.get(...)` at the call site would raise `AttributeError` on a list/scalar; in practice skill output is an object. Reproduce the literal `return json.loads(raw)` with no type guard on the happy path.

### 5.2 Helper `_sanitize_portfolio_dimension(entry) -> dict | None` (scoring.py:310-334)
```
if not isinstance(entry, dict):   return None               # ⚠️ non-dict (incl. None) -> drop dimension
score = entry.get("score")
if score is not None:
    try:    score = float(score)
    except (TypeError, ValueError):  score = None
    if score is not None:
        score = max(0.0, min(100.0, score))                 # ⚠️ CLAMP to [0,100]
rationale = entry.get("rationale")
if rationale is not None and not isinstance(rationale, str):
    rationale = str(rationale)
evidence = entry.get("evidence")
if not isinstance(evidence, list):  evidence = []
else:                               evidence = [str(e) for e in evidence]
return {"score": score, "rationale": rationale, "evidence": evidence}
```
- ⚠️ Returns `None` ONLY when `entry` is not a dict. A dict with no `score` still returns `{"score": None, ...}` and is **kept** in `sanitized` (counts toward `dimensions_persisted` but contributes nothing to the weighted mean). So "valid dimension" = "is a dict," not "has a usable score."
- `score` clamped to `[0.0, 100.0]`. `null`/uncoercible score → `None` (legitimate "N/A" e.g. UX for headless archetypes).
- `rationale` coerced to str (or `None`). `evidence` → list of stringified elements (or `[]`).

### 5.3 Helper `_compute_portfolio_overall(scores: dict[str,dict], weights: dict[str,float] | None) -> float | None` (scoring.py:337-357)
```
total_w = 0.0
total   = 0.0
default_w = 1.0 / len(_PORTFOLIO_DIMENSIONS)          # = 1/6 ≈ 0.166666…
for dim in _PORTFOLIO_DIMENSIONS:                     # iterate 6 known dims in tuple order
    entry = scores.get(dim) or {}
    score = entry.get("score")
    if score is None:        continue                 # ⚠️ null-score dims EXCLUDED from mean (no penalty)
    w = (weights or {}).get(dim, default_w)           # per-dim weight, default 1/6 if not overridden
    total   += score * w
    total_w += w
if total_w <= 0:             return None              # ⚠️ no scorable dims -> None
return round(total / total_w, 2)                      # ⚠️ weighted mean, rounded to 2 dp
```
- **Weighted mean over non-null dimensions only.** Equal weights (`1/6` each) when `weights` is `None`/empty. UX-null (or any null) dims are skipped so headless archetypes aren't penalized.
- ⚠️ **Normalization by `total_w` (sum of the weights actually used), not by a fixed denominator.** If only 3 dims have scores and equal weights, denominator = `3 × (1/6) = 0.5`, so result = `(Σ score×(1/6)) / 0.5` = plain mean of the 3 present scores. With custom `weights` it's the weight-normalized mean over present dims.
- ⚠️ When supplied, a `weights` dict need not sum to 1 — the division by `total_w` re-normalizes. A dim present in `scores` but absent from `weights` uses `default_w = 1/6` (mixed default/override weighting is possible).
- Returns `None` if no dimension had a numeric score (matches `overall_weighted=None` in the result and JSONB).

### Inputs READ / Outputs WRITTEN
- READ: none from DB (input JSON only). ⚠️ Unlike most persist activities, it does **not** read the existing row first — it blind-overwrites `portfolio_score`.
- WRITTEN: `application.portfolio_score` + `application.updated_at` for one row (when ≥1 valid dim).

### Error handling / retries / idempotency
- **Bad `app_id`** → explicit `NonRetryableError` (the only typed raise). Re-raised as-is by the wrapper.
- **Unparseable / no-valid-dims** → graceful no-op, `persisted=False`, **no exception, no DB write.**
- ⚠️ **The DB UPDATE block has NO try/except.** Unlike the other two activities (which swallow `OSError`/`asyncpg.PostgresError`), here a connection/query failure **propagates**. `asyncpg.connect()` failure (e.g. `ConnectionDoesNotExistError`/timeout-named class) → wrapper's `_is_retryable_error` may match `connection`/`timeout` substrings → **`RetryableError`** (Temporal retries). A non-matching DB error → `NonRetryableError`. ⚠️ This is an asymmetry vs `record_score_snapshot`: a DB outage here **fails the activity**, it does not silently succeed.
- **Idempotency:** **Idempotent for a given parse result** — repeated UPDATEs write the same `scores`/`overall_weighted`/`methodology_version` (only `computed_at`/`updated_at` timestamps differ). Safe under Temporal at-least-once retries. No row-count check; UPDATE-0-rows (missing app) is a silent success.

---

## 6. Cross-reference: portfolio-score side-effect projection (NOT in this file)
`persist_portfolio_score` writes the JSONB blob; a **separate** projection `_extract_portfolio_score_side_effects` in `temporal/olympus_workflows/activities/line_transitions.py:2747` derives downstream side-effect columns from that blob. That logic is out of scope for this group (spec'd with the `line_transitions` group). Noted here so the data dependency is not lost: `application.portfolio_score` is the upstream source for those side effects.

## 7. Undetermined / assumptions
- The `portfolio-scorer` skill's exact output schema (the producer of `input.score_json`) is defined by the skill contract, not this activity; this activity only parses defensively. The expected shape inferred from the code: `{"scores": {<dim>: {"score": <0-100|null>, "rationale": <str>, "evidence": [<str>...]}}, "methodology_version": <str>}`.
- `weights` provenance (profile `scoring.yaml`) is the caller's responsibility (per `PersistPortfolioScoreInput` docstring); this activity treats `weights` as an opaque override.
- Nothing else undetermined: all 3 activities, both scales, all SQL, and all column mappings are fully reproduced from source + verified against the DDL migrations.
