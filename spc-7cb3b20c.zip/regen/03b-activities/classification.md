# Phase 4 — Activity Group Spec: `classification`

ATOMIC regeneration spec. Source of truth:
`temporal/olympus_workflows/activities/classification.py` (211 lines).

Scope: the two Rationalization classification activities —
`persist_classification` and `confirm_classification_tier_1`. Both write to a
single table (`application`). This file reproduces the tier-assignment logic
and the **exact** column-by-column projection so the data layer can be rebuilt
to behave identically.

Behavioral-parity bar: an engineer with no access to the code must reproduce
the SQL byte-for-byte (placeholder indices included), the validation gates,
the no-op short-circuits, the typed-error mapping, and the result-object
echoes.

---

## 0. THE DECORATOR — `@foundry_activity` (applies to BOTH activities)

Source: `foundry_temporal/activities.py` lines 107-165 (`foundry_activity`),
24-40 (`ActivityConfig`), 168-183 (`_is_retryable_error`).
Error classes: `foundry_temporal/errors.py` lines 10-53.

Both activities are decorated:

```python
@foundry_activity(config=ActivityConfig(enable_observability=True))
```

`foundry_activity(config=..., name=None, **activity_kwargs)` returns a
decorator that wraps the user function `func` in an async `wrapper`, and
applies `@activity.defn(name=name, **activity_kwargs)` + `@wraps(func)` to that
wrapper. A plain `@activity.defn` rebuild **loses** the observability logging
and the error wrapping/retryability classification described below — do NOT
substitute it.

`ActivityConfig` fields and the defaults in force here (only
`enable_observability=True` is passed; everything else is the dataclass
default):
- `retry_policy=None`, `start_to_close_timeout=None`,
  `schedule_to_close_timeout=None`, `schedule_to_start_timeout=None`,
  `heartbeat_timeout=None` (timeouts/retries are supplied by the **caller**
  via `workflow.execute_activity(...)`, see §3; the decorator does not set
  them).
- `enable_observability=True` (explicit here).
- `enable_error_wrapping=True` (**default — in force**).
- `log_inputs=False`, `log_outputs=False` (**defaults — in force**). Because
  both are False, the observability logs deliberately pass `extra={"inputs":
  None}` / `extra={"outputs": None}` — i.e. the wrapper does NOT log argument
  or return payloads. (Reproduce this exactly; logging the inputs would leak
  classification payloads.)

`name` is `None` for both → activity name defaults to the function name
(`activity_name = name or func.__name__`), i.e. registered as
`"persist_classification"` and `"confirm_classification_tier_1"`.

### Wrapper control flow (exact, lines 127-161)

```
activity_name = name or func.__name__          # function name here
activity_logger = get_logger()                 # foundry_temporal.logging.get_logger
if enable_observability:                        # True
    activity_logger.info(f"Activity {activity_name} starting",
                         extra={"inputs": args if log_inputs else None})  # → None
try:
    result = await func(*args, **kwargs)
    if enable_observability:
        activity_logger.info(f"Activity {activity_name} completed",
                             extra={"outputs": result if log_outputs else None})  # → None
    return result
except Exception as error:
    if enable_observability:
        activity_logger.error(f"Activity {activity_name} failed: {error}",
                              extra={"error": str(error)})
    if enable_error_wrapping:                    # True
        if isinstance(error, (WorkflowError, ApplicationError)):
            raise                                # re-raise unchanged (preserves non_retryable flag)
        elif _is_retryable_error(error):
            raise RetryableError(f"Retryable error in {activity_name}: {error}") from error
        else:
            raise NonRetryableError(f"Non-retryable error in {activity_name}: {error}") from error
    else:
        raise
```

### Error-wrapping semantics that matter for THIS group

1. **`NonRetryableError` raised inside the body passes through UNCHANGED.**
   `NonRetryableError` (errors.py:24) subclasses `WorkflowError` (errors.py:10)
   which subclasses `temporalio.exceptions.ApplicationError`. The
   `isinstance(error, (WorkflowError, ApplicationError))` branch is hit first →
   bare `raise`. So the explicit `raise NonRetryableError(f"Invalid app_id:
   ...")` in both activities reaches Temporal as a **non-retryable**
   `ApplicationError` (constructed with `non_retryable=True`, errors.py:27-28)
   — Temporal will NOT retry it regardless of the caller's `retry_policy`. The
   message is NOT re-prefixed with `"Non-retryable error in ..."` because it
   never enters the `else` branch.

2. **An unexpected raw exception** (e.g. asyncpg connection failure, a
   `asyncpg.PostgresError`) is classified by
   `_is_retryable_error(error)` (activities.py:168-183): it lowercases
   `str(type(error))` and returns True iff any of these substrings appear:
   `timeout`, `connection`, `network`, `temporary`, `unavailable`, `overload`,
   `busy`, `throttle`, `rate_limit`. ⚠️ **GOTCHA**: this matches on the
   **type's repr string**, not on the message or on any structured attribute.
   `asyncpg.exceptions.ConnectionDoesNotExistError` →
   `str(type(...))` contains `"connection"` → **RetryableError**.
   `asyncpg.exceptions.PostgresSyntaxError` → no substring match →
   **NonRetryableError**. A bare Python `ConnectionError` →
   `str(type(...))` == `"<class 'ConnectionError'>"` → contains `"connection"`
   → RetryableError. This is the only retry classification these activities
   get from the decorator; there is no body-level try/except around the DB
   call.

3. Note `foundry_temporal/errors.is_retryable_error` (errors.py:56-103) is a
   *different, richer* classifier (handles httpx status codes, OSError errno,
   etc.) — it is **NOT** used by the `foundry_activity` wrapper. The wrapper
   uses the module-private `_is_retryable_error` (the substring matcher). Do
   not conflate them.

### Idempotency posture (both activities)

Neither activity uses a transaction, advisory lock, or idempotency key. Each
opens a fresh asyncpg connection per invocation, runs one `UPDATE`, closes.
Idempotency comes from the **shape of the UPDATE**, not from any guard:
- `persist_classification` — last-writer-wins on the touched columns; re-running
  with the same parsed JSON re-writes the same values + a new `updated_at`.
- `confirm_classification_tier_1` — naturally idempotent via its `WHERE`
  predicate (only flips rows still at `risk_tier_source='auto'`; see §2).

Because Temporal may retry the activity (on a RetryableError or a worker
crash mid-flight), the UPDATE **must be safe to apply more than once** — both
are (idempotent / last-writer-wins).

---

## 1. `persist_classification`

Source lines 69-171. Decorator: `@foundry_activity(config=ActivityConfig(
enable_observability=True))` (line 69).

### Signature

```python
async def persist_classification(
    input: PersistClassificationInput,
) -> PersistClassificationResult
```

### Input type — `PersistClassificationInput` (`types.py` 1216-1233)

| field | type | default | used? |
|---|---|---|---|
| `app_id` | `str` | (required) | YES — parsed to UUID; the `WHERE id` target |
| `classification_artifact_path` | `str` | `""` | NO — never read by the activity (caller bookkeeping only) |
| `classification_json` | `str` | `""` | YES — the raw skill output parsed via `_parse_classification` |

⚠️ **GOTCHA**: `classification_artifact_path` is accepted but **ignored** by
the activity body — it exists only so the workflow can record provenance. Do
not read it.

### Output type — `PersistClassificationResult` (`types.py` 1235-1248)

| field | type | default |
|---|---|---|
| `app_id` | `str` | (required) |
| `risk_tier` | `int \| None` | `None` |
| `complexity_tier` | `str` | `""` |
| `archetype` | `str` | `""` |
| `tier_1_flag` | `bool` | `False` |

The result is a **pure echo for observability + the `tier_1_flag` control
signal**; the workflow branches on `tier_1_flag` (see §3) but does not re-read
the DB.

### The classification JSON shape READ (from `classification_json`)

`_parse_classification` returns a dict; the activity reads exactly these keys
(line 101-104):

| JSON key | read as | expected values |
|---|---|---|
| `complexity_tier` | `parsed.get("complexity_tier")` | `"simple"` / `"moderate"` / `"complex"` (else dropped) |
| `risk_tier` | `parsed.get("risk_tier")` | int-coercible to 1 / 2 / 3 (else dropped) |
| `archetype` | `parsed.get("archetype")` | one of `_ARCHETYPES` (else dropped) |
| `tier_1_flag` | `bool(parsed.get("tier_1_flag"))` | truthy → True |

All other keys in the JSON are ignored. Example happy-path input:
`{"risk_tier": 2, "complexity_tier": "moderate", "archetype": "api-service",
"tier_1_flag": false}`.

### `_parse_classification(raw: str) -> dict` (lines 49-66) — REPRODUCE EXACTLY

Tolerant JSON parser handling agent prose-wrap. Control flow:

```
if not raw:                              return {}      # "" / None / falsy
try:
    return json.loads(raw) if isinstance(raw, str) else {}   # non-str → {}
except json.JSONDecodeError:
    start = raw.find("{")
    end   = raw.rfind("}")
    if start == -1 or end <= start:      return {}      # no/empty brace window
    try:
        return json.loads(raw[start : end + 1])         # parse inner slice
    except json.JSONDecodeError:         return {}
```

⚠️ Detail: the second attempt slices `raw[start : end+1]` — first `{` to last
`}` inclusive. `"prefix {not valid} suffix"` slices to `"{not valid}"` which
fails `json.loads` → `{}`. A bare object embedded in prose
(`"Here's my analysis:\n{...}\nLet me know"`) parses on the second attempt.
Returns `{}` on every failure path; `{}` is the documented "no-op, write
nothing" sentinel.

### Module constants (lines 39-46) — the validation allow-lists

```python
_ARCHETYPES = {"web-app", "batch-etl", "api-service", "scheduled-job", "hybrid"}
_COMPLEXITY = {"simple", "moderate", "complex"}
```
(There is no `_RISK` set; risk is validated by the int-coercion path below.)
These mirror `olympus_contracts.enums.Archetype` / `ComplexityTier` and the
Postgres `archetype_enum` / `complexity_tier_enum` value sets exactly.

### Full control flow (lines 88-171)

```
1. try: app_uuid = uuid.UUID(input.app_id)
   except (ValueError, TypeError): raise NonRetryableError(f"Invalid app_id: {input.app_id!r}")
       # ⚠️ uses !r — message shows the repr (quoted). Caller test matches /Invalid app_id/.

2. parsed = _parse_classification(input.classification_json)
   if not parsed:                                   # {} → unparseable / empty
       logger.warning("persist_classification: unparseable skill output",
                      extra={"app_id": input.app_id})
       return PersistClassificationResult(app_id=input.app_id)   # bare result, NO DB connection opened

3. complexity = parsed.get("complexity_tier")
   risk       = parsed.get("risk_tier")
   archetype  = parsed.get("archetype")
   tier_1_flag = bool(parsed.get("tier_1_flag"))

4. # Validation (only write what is valid)
   validated_complexity = complexity if complexity in _COMPLEXITY else None
   try:
       risk_int = int(risk) if risk is not None else None      # int("2")→2 ; int(2.0)→2 ; int("high")→ValueError
       validated_risk = str(risk_int) if risk_int in (1,2,3) else None   # back to STRING "1"/"2"/"3"
   except (TypeError, ValueError):
       validated_risk = None
   validated_archetype = archetype if archetype in _ARCHETYPES else None

5. # Build dynamic SET clause — see column mapping table below.
   set_parts = []; params = []
   if validated_risk is not None:
       set_parts += [f"risk_tier = ${len(params)+1}"];        params.append(validated_risk)   # str "1"/"2"/"3"
       set_parts += [f"risk_tier_source = ${len(params)+1}"]; params.append("auto")
   if validated_complexity is not None:
       set_parts += [f"complexity_tier = ${len(params)+1}"];        params.append(validated_complexity)
       set_parts += [f"complexity_tier_source = ${len(params)+1}"]; params.append("auto")
   if validated_archetype is not None:
       set_parts += [f"archetype = ${len(params)+1}"];        params.append(validated_archetype)
       set_parts += [f"archetype_source = ${len(params)+1}"]; params.append("auto")

6. if not set_parts:                                # parseable JSON but no field valid
       logger.warning("persist_classification: no valid fields to write",
                      extra={"app_id": input.app_id, "parsed": parsed})
       return PersistClassificationResult(app_id=input.app_id)   # bare result, NO DB connection opened

7. set_parts.append(f"updated_at = ${len(params)+1}")  # always appended when ≥1 field valid
   params.append(datetime.now(timezone.utc))           # tz-aware UTC
   params.append(app_uuid)                             # ⚠️ appended for WHERE — see placeholder note

8. sql = f"UPDATE application SET {', '.join(set_parts)} WHERE id = ${len(params)}"

9. conn = await asyncpg.connect(_db_url())
   try:    await conn.execute(sql, *params)
   finally: await conn.close()                         # always closed

10. logger.info("Classification persisted", extra={app_id, risk_tier=validated_risk,
        complexity_tier=validated_complexity, archetype=validated_archetype, tier_1_flag})

11. return PersistClassificationResult(
        app_id=input.app_id,
        risk_tier=int(validated_risk) if validated_risk else None,   # back to INT for the result
        complexity_tier=validated_complexity or "",
        archetype=validated_archetype or "",
        tier_1_flag=tier_1_flag,
    )
```

⚠️ **GOTCHA — risk_tier double type-flip**: `risk` JSON value → `int()` →
checked `in (1,2,3)` → **stringified** (`str(risk_int)`) for the DB param
(because the Postgres column is `risk_tier_enum` whose labels are the STRINGS
`'1'/'2'/'3'`, migration 002 line 25) → then in the result object flipped
**back to int** (`int(validated_risk)`). DB stores `'2'`; result echoes `2`.
Reproduce both directions.

⚠️ **GOTCHA — placeholder indexing for WHERE**: at step 7 `app_uuid` is
appended to `params` **before** the SQL string is built. So after appending
`updated_at` (param k) and `app_uuid` (param k+1), `len(params)` == k+1 and
the WHERE clause is `WHERE id = $<k+1>` — which correctly binds `app_uuid`
(the last param). The ordering is load-bearing: `app_uuid` MUST be the final
positional arg and `${len(params)}` is computed AFTER both `updated_at` and
`app_uuid` are appended. Example with all three fields valid (6 field params +
updated_at + id):
```
UPDATE application SET risk_tier = $1, risk_tier_source = $2, complexity_tier = $3,
  complexity_tier_source = $4, archetype = $5, archetype_source = $6,
  updated_at = $7 WHERE id = $8
params = ['2','auto','moderate','auto','api-service','auto',<utcnow>,<app_uuid>]
```
Example with only complexity valid (`{"complexity_tier":"simple"}`):
```
UPDATE application SET complexity_tier = $1, complexity_tier_source = $2,
  updated_at = $3 WHERE id = $4
params = ['simple','auto',<utcnow>,<app_uuid>]
```

⚠️ **GOTCHA — `risk_int in (1,2,3)` and bool**: Python `True in (1,2,3)` is
`True` (bool is an int subclass, `True==1`). So `{"risk_tier": true}` →
`int(True)`==1 → `validated_risk="1"`. Faithful reproduction must allow this
(do not add an explicit bool guard). `{"risk_tier": 2.9}` → `int(2.9)`==2 →
`"2"` (truncation). `{"risk_tier": "high"}` → `int("high")` raises ValueError
→ caught → `validated_risk=None`.

⚠️ **GOTCHA — no DB connection on no-op paths**: steps 2 and 6 return WITHOUT
calling `asyncpg.connect`. Tests assert `asyncpg_mock.connect.assert_not_called()`
for unparseable and all-invalid inputs. A rebuild that opens a connection
eagerly (e.g. before parsing) breaks parity.

### Column projection map — `application` table

Target table: **`application`** (migration 002 lines 76-104; archetype cols
added migration 021 lines 43-67). UPDATE only; never INSERT. Row located by
`WHERE id = <app_uuid>`. **Every column the activity can write is listed.**

| artifact/source field | → table.column | column type (DDL) | value written | condition (column touched ONLY when…) | source default |
|---|---|---|---|---|---|
| `parsed["risk_tier"]` (int-coerced, re-stringified) | `application.risk_tier` | `risk_tier_enum` ('1'/'2'/'3'), nullable | `validated_risk` = `str(int(risk))` | `int(risk) in (1,2,3)` (else not written) | — |
| literal | `application.risk_tier_source` | `tier_source_enum` (auto/confirmed/overridden), nullable | `"auto"` | written iff `risk_tier` is written (same `if` block) | — |
| `parsed["complexity_tier"]` | `application.complexity_tier` | `complexity_tier_enum` (simple/moderate/complex), nullable | `validated_complexity` (verbatim) | `complexity in _COMPLEXITY` | — |
| literal | `application.complexity_tier_source` | `tier_source_enum`, nullable | `"auto"` | written iff `complexity_tier` is written | — |
| `parsed["archetype"]` | `application.archetype` | `archetype_enum` (web-app/batch-etl/api-service/scheduled-job/hybrid), nullable | `validated_archetype` (verbatim) | `archetype in _ARCHETYPES` | — |
| literal | `application.archetype_source` | `tier_source_enum`, nullable | `"auto"` | written iff `archetype` is written | — |
| `datetime.now(timezone.utc)` | `application.updated_at` | `timestamptz` NOT NULL (server_default `now()`) | tz-aware UTC `datetime` | written iff ≥1 of the above field-pairs is written (i.e. `set_parts` non-empty) | server_default `now()` |
| `uuid.UUID(input.app_id)` | `application.id` (WHERE key, not SET) | `uuid` PK | — | always (WHERE predicate) | — |

Columns NOT touched by this activity (it does a targeted partial UPDATE):
`portfolio_id, name, repo_url, business_domain, owner, current_line,
current_step, current_status, decomposition_map, user_context, ux_assessment,
disposition, user_impact, wave_assignment, analyzed_commit_sha, created_at`.

Notes:
- The three `*_source` columns are **never** written independently of their
  paired value column — they are appended in the same `if` block. There is no
  path that writes `risk_tier_source` without `risk_tier`.
- All written `*_source` values are the literal `"auto"`. `"confirmed"` is only
  ever written by `confirm_classification_tier_1` (§2); `"overridden"` is
  written elsewhere (manual override path, out of scope).
- ⚠️ The `risk_tier` DB value is a **string label**, not an integer — passing
  an int `2` to the `risk_tier_enum` column would fail. asyncpg binds the
  Python `str` `"2"` to the enum label `'2'`.

### Errors / retries / idempotency

- `uuid.UUID(input.app_id)` raises `ValueError` (bad format) or `TypeError`
  (non-str) → caught → `raise NonRetryableError(f"Invalid app_id: {input.app_id!r}")`
  → passes through decorator unchanged → Temporal does NOT retry. (Test:
  `test_invalid_app_id_raises_non_retryable`, matches `Invalid app_id`.)
- A DB failure inside `conn.execute` propagates raw out of the `try/finally`
  (the `finally` only closes the conn) → decorator classifies via the
  substring matcher (§0.2). Connection-class asyncpg errors → RetryableError →
  Temporal retries under the caller's `transient` policy. Syntax/constraint
  errors → NonRetryableError.
- Idempotent: last-writer-wins on the touched columns + a fresh `updated_at`.
  Safe to retry. No transaction (single statement is atomic in PG).

---

## 2. `confirm_classification_tier_1`

Source lines 174-211. Decorator: `@foundry_activity(config=ActivityConfig(
enable_observability=True))` (line 174).

### Signature

```python
async def confirm_classification_tier_1(
    input: ConfirmClassificationInput,
) -> None
```

Returns `None` (the decorator logs `extra={"outputs": None}` because
`log_outputs=False` anyway).

### Input type — `ConfirmClassificationInput` (`types.py` 1251-1262)

| field | type | default | used? |
|---|---|---|---|
| `app_id` | `str` | (required) | YES — parsed to UUID; the `WHERE id` target |
| `approved_by` | `str` | `""` | logged only (not written to DB) |

⚠️ **GOTCHA**: `approved_by` is **NOT persisted** by this activity. It appears
only in the final `logger.info(... extra={"app_id", "approved_by"})` (lines
207-210). The audit trail for who approved lives in the workflow / gate
records, not in the `application` row. A rebuild that adds an
`approved_by` column write diverges.

### Control flow (lines 185-210) — REPRODUCE EXACTLY

```
1. try: app_uuid = uuid.UUID(input.app_id)
   except (ValueError, TypeError): raise NonRetryableError(f"Invalid app_id: {input.app_id!r}")

2. conn = await asyncpg.connect(_db_url())
   try:
       await conn.execute(
           """
           UPDATE application
           SET risk_tier_source = 'confirmed',
               updated_at = $1
           WHERE id = $2
             AND risk_tier = '1'
             AND risk_tier_source = 'auto'
           """,
           datetime.now(timezone.utc),   # $1
           app_uuid,                      # $2
       )
   finally:
       await conn.close()

3. logger.info("Tier 1 classification confirmed",
               extra={"app_id": input.app_id, "approved_by": input.approved_by})
```

⚠️ The SQL is a **fixed string literal** (unlike `persist_classification`'s
dynamic builder). Two positional params only: `$1 = now(utc)`, `$2 = app_uuid`.
The literals `'confirmed'`, `'1'`, `'auto'` are inlined in the SQL text
(single-quoted enum labels). Tests assert the SQL contains
`risk_tier_source = 'confirmed'`, `risk_tier = '1'`, and
`risk_tier_source = 'auto'` verbatim.

### Column projection map — `application` table

| source | → table.column | value written | condition |
|---|---|---|---|
| literal | `application.risk_tier_source` | `'confirmed'` | only rows matching the full WHERE predicate |
| `datetime.now(timezone.utc)` ($1) | `application.updated_at` | tz-aware UTC | same rows |
| `uuid.UUID(input.app_id)` ($2) | `application.id` (WHERE) | — | WHERE key |

WHERE predicate (3 conjuncts — ALL must hold for any write):
`id = $2 AND risk_tier = '1' AND risk_tier_source = 'auto'`.

No other column is touched.

### Idempotency / no-op semantics (THE design point)

⚠️ **GOTCHA — idempotency via WHERE, not via guard**: the activity only flips
rows still at `risk_tier_source = 'auto'` AND `risk_tier = '1'`.
- Run once: row at `('1','auto')` → flipped to `('1','confirmed')`, 1 row
  updated.
- Run again (retry / double-signal): the row is now `('1','confirmed')` → WHERE
  no longer matches → **0 rows updated, no error** (asyncpg `execute` returns
  `"UPDATE 0"`). Safe to retry.
- If a stakeholder manually set `risk_tier_source='overridden'` in the
  interim → WHERE doesn't match → **no-op** (this is the documented "manual
  override wins" behavior, docstring lines 182-184).
- If `risk_tier != '1'` (not actually Tier 1) → no-op. The activity can be
  called defensively without first checking the tier.

The activity does NOT report how many rows it touched (returns `None`) and does
NOT raise if zero rows matched. A rebuild must not raise on the no-op path.

### Errors / retries / idempotency

- Bad `app_id` → `NonRetryableError(f"Invalid app_id: {input.app_id!r}")`
  (non-retryable, passes through decorator). (Test:
  `test_invalid_app_id_raises_non_retryable`.)
- DB failure → propagates → decorator substring-classifies (§0.2).
- Idempotent by WHERE predicate (above). No transaction needed (single
  statement).

---

## 3. Caller context (for fidelity of the control loop)

Caller: `RationalizationWorkflow` in
`temporal/olympus_workflows/workflows/rationalization.py`.

`persist_classification` is invoked (lines 448-461):
```python
persist_result = await workflow.execute_activity(
    persist_classification,
    PersistClassificationInput(
        app_id=app_id,
        classification_artifact_path=classification_artifact_path,
        classification_json=(classification_result.output_artifacts[0]
                             if classification_result.output_artifacts else ""),
    ),
    start_to_close_timeout=timedelta(seconds=60),
    retry_policy=RETRY_POLICIES["transient"],
)
```
⚠️ The `classification_json` passed is `classification_result.output_artifacts[0]`
— i.e. the **first output artifact STRING** of the prior `classify-application`
agent dispatch (the raw skill output the workflow already committed to Git). If
the agent produced no output artifacts, `""` is passed → `_parse_classification`
returns `{}` → no-op. (`classification_artifact_path` is passed but the
activity ignores it — §1.)

If `persist_result.tier_1_flag` (lines 467-487): the workflow sets
`self._current_step = "classification-awaiting-tier1-approval"`, then
`await workflow.wait_condition(lambda: self._tier1_approved_by is not None
or self.cancelled)`. On cancel → returns `"cancelled"`. Otherwise it invokes:
```python
await workflow.execute_activity(
    confirm_classification_tier_1,
    ConfirmClassificationInput(app_id=app_id, approved_by=self._tier1_approved_by),
    start_to_close_timeout=timedelta(seconds=30),
    retry_policy=RETRY_POLICIES["transient"],
)
```
`self._tier1_approved_by` is set by the `stakeholder_approved` signal handler
(rationalization.py:671-687) when it receives a `StakeholderApprovedSignal`
with `signal.scope == "tier-1-classification"`.

### `RETRY_POLICIES["transient"]` (governs BOTH calls)

`retry_policies.py:33,110`: `TRANSIENT_RETRY_POLICY = HTTP_RETRY_POLICY`
(foundry-temporal's HTTP policy — per the module comment lines 31-33: **3
retries, exponential backoff 1-15s**). `start_to_close_timeout` is 60s for
`persist_classification`, 30s for `confirm_classification_tier_1`.
Consequence: a `NonRetryableError` (bad app_id) is NOT retried even though the
policy permits retries — the `non_retryable=True` flag on the
`ApplicationError` overrides the policy. A connection-class DB error IS retried
(up to the policy's attempts) because the decorator wraps it as RetryableError.

---

## 4. DB connection helper `_db_url()` (lines 30-36)

```python
def _db_url() -> str:
    host = os.environ.get("DATABASE_HOST", "localhost")
    port = os.environ.get("DATABASE_PORT", "5432")
    user = os.environ.get("DATABASE_USER", "olympus")
    password = os.environ.get("DATABASE_PASSWORD", "olympus")
    db = os.environ.get("DATABASE_NAME", "olympus")
    return f"postgresql://{user}:{password}@{host}:{port}/{db}"
```
Both activities call `await asyncpg.connect(_db_url())` per invocation (no pool;
fresh connection each time) and always `await conn.close()` in a `finally`.
Env var names + defaults are load-bearing (`olympus/olympus@localhost:5432/olympus`).

---

## 5. Imports / module constants (lines 9-46)

```python
import json, logging, os, uuid
from datetime import datetime, timezone
import asyncpg
from foundry_temporal.activities import ActivityConfig, foundry_activity
from foundry_temporal.errors import NonRetryableError
from olympus_workflows.types import (
    ConfirmClassificationInput, PersistClassificationInput, PersistClassificationResult,
)
logger = logging.getLogger(__name__)
_ARCHETYPES = {"web-app", "batch-etl", "api-service", "scheduled-job", "hybrid"}
_COMPLEXITY = {"simple", "moderate", "complex"}
```
`NonRetryableError` is imported directly from `foundry_temporal.errors` (the
same class re-exported via `olympus_workflows.types`). Worker registration:
both functions are listed in `worker.py` (imports lines 49-50; registered in
the activities list lines 208-209).

---

## 6. Parity checklist (must ALL hold)

- [ ] Both decorated with `@foundry_activity(config=ActivityConfig(enable_observability=True))`; name defaults to func name; `log_inputs/log_outputs` False (no payload logging).
- [ ] `NonRetryableError` body-raises pass through the wrapper unchanged (non-retryable in Temporal); unexpected exceptions classified by the **substring** matcher on `str(type(error))`.
- [ ] `persist_classification`: bad app_id → `NonRetryableError("Invalid app_id: <repr>")`; uses `!r`.
- [ ] `_parse_classification`: 4-branch tolerant parser; `{}` on every failure; brace-window slice `raw[start:end+1]`.
- [ ] No-op (return bare result, NO `asyncpg.connect`) when parse == `{}` OR no field validated.
- [ ] risk validated by `int()` then `in (1,2,3)`; stored as STRING `'1'/'2'/'3'`; echoed as INT in result; `True`/`2.9` quirks preserved.
- [ ] complexity validated against `_COMPLEXITY`; archetype against `_ARCHETYPES`; each `*_source="auto"` written ONLY alongside its value column.
- [ ] Dynamic `$N` placeholders; `updated_at` appended (param k) then `app_uuid` (param k+1); `WHERE id = ${len(params)}` after both.
- [ ] Result echoes: `complexity_tier or ""`, `archetype or ""`, `tier_1_flag=bool(parsed.get("tier_1_flag"))`.
- [ ] `confirm_classification_tier_1`: fixed SQL; `SET risk_tier_source='confirmed', updated_at=$1 WHERE id=$2 AND risk_tier='1' AND risk_tier_source='auto'`; params `(now_utc, app_uuid)`; returns `None`.
- [ ] `approved_by` logged, NOT persisted.
- [ ] confirm idempotency from WHERE predicate (0-row no-op, no raise) on retry / already-confirmed / overridden.
- [ ] Fresh asyncpg connection per call from `_db_url()` (env defaults `olympus/olympus@localhost:5432/olympus`); always closed in `finally`.

---

## 7. Undetermined / assumptions

- `foundry_temporal.retry_policies.HTTP_RETRY_POLICY` exact numbers are stated
  per the in-repo comment ("3 retries, exp backoff 1-15s",
  `retry_policies.py:32-33`); the upstream `foundry_temporal` package source for
  `HTTP_RETRY_POLICY` was not opened in this pass. If byte-exact retry tuning
  matters, confirm against `foundry_temporal/retry_policies.py`.
- `foundry_temporal.logging.get_logger()` behavior (formatter/handler) not
  inspected here — only that the wrapper calls it for `.info/.error`. Not
  load-bearing for activity behavior; relevant only to log formatting.
- The `application.id` WHERE match assumes the row already exists (the
  Rationalization workflow runs after Discovery seeds the row). If the row is
  absent, both activities run `UPDATE ... WHERE id=...` matching 0 rows → silent
  no-op, no error. No INSERT path exists in either activity.
