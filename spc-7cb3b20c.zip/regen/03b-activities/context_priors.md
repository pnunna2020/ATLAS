# Activity Group: `context_priors` — Atomic Regeneration Spec

**Source of truth:** `temporal/olympus_workflows/activities/context_priors.py` (166 lines).
**Module docstring intent:** This activity reads *human-reviewed context priors* from the active client profile and returns them keyed by skill id. Context priors are markdown documents the profile owner authors to give agents "a starting opinion to check their work against — a human already thought about this; read it before finalizing your recommendation." **They are NOT authoritative inputs.** The workflow folds the return value into `AgentTaskInput.context['context_priors']` so the agent receives them through the standard A2A envelope. Canonical declaration format lives at `profiles/faa/context-priors/manifest.yaml`.

This group contains exactly **ONE** activity: `load_context_priors`. There are **no** `persist_*` / projection activities, **no** DB writes, **no** Git operations, and **no** agent-dispatch in this file. It is pure filesystem + YAML read, best-effort, never raises for content errors. (Confirmed: the only DB/Git/agent activities live in sibling files `scoring.py`, `git_operations.py`, `agent_dispatch.py`, `gate_operations.py` — see `activities/__init__.py`.)

---

## PREAMBLE — The `@foundry_activity` wrapper (applies to `load_context_priors`)

`load_context_priors` is decorated with `@foundry_activity(config=ActivityConfig(enable_observability=True))` from `foundry_temporal.activities` (NOT plain `@activity.defn`). Source: `/private/var/folders/qs/dwcdl18n351cyz88x2tc9w3w0000gp/T/tmp.2xQMcqnDWM/foundry_temporal/activities.py:107-165`. **A rebuild using plain `@activity.defn` loses error-wrapping + retryability classification.** Reproduce the wrapper exactly:

`foundry_activity(config=None, name=None, **activity_kwargs)` returns a `decorator(func)` that:

1. Resolves `activity_config = config or ActivityConfig()`. For this activity `config = ActivityConfig(enable_observability=True)` — all other `ActivityConfig` fields take their dataclass defaults (see below).
2. Applies **`@activity.defn(name=name, **activity_kwargs)`** to an inner `wrapper`, then `@wraps(func)`. For this activity `name=None` and no `activity_kwargs`, so Temporal registers the activity under its **function name `load_context_priors`** (Temporal's default when `name=None`). `@wraps` preserves `__name__`/`__doc__` so the registered name resolves to `load_context_priors`.
3. The `wrapper(*args, **kwargs)` coroutine does, in order:
   - `activity_name = name or func.__name__` → `"load_context_priors"`.
   - `activity_logger = get_logger()` (from `foundry_temporal...logging`).
   - **If `activity_config.enable_observability`** (TRUE here): logs `f"Activity load_context_priors starting"` with `extra={"inputs": args if activity_config.log_inputs else None}`. Because `log_inputs` defaults **False**, `extra["inputs"]` is `None` (inputs are NOT logged — privacy/size).
   - `result = await func(*args, **kwargs)` — the real activity body.
   - On success, **if `enable_observability`**: logs `f"Activity load_context_priors completed"` with `extra={"outputs": result if log_outputs else None}`. `log_outputs` defaults **False** → `extra["outputs"]` is `None` (the prior content is never logged).
   - Returns `result`.
   - **On `except Exception as error`:** if `enable_observability`, logs `f"Activity load_context_priors failed: {error}"` with `extra={"error": str(error)}`. Then **if `enable_error_wrapping`** (defaults **True**):
     - if `isinstance(error, (WorkflowError, ApplicationError))` → bare `raise` (re-raise unchanged; preserves any already-classified Temporal/`WorkflowError`),
     - **elif `_is_retryable_error(error)`** → `raise RetryableError(f"Retryable error in load_context_priors: {error}") from error`,
     - **else** → `raise NonRetryableError(f"Non-retryable error in load_context_priors: {error}") from error`.
   - if `enable_error_wrapping` were False, bare `raise`.

   `RetryableError` / `NonRetryableError` / `WorkflowError` are imported from `foundry_temporal.activities.errors` (re-exported in this module's `.errors`). `ApplicationError` is `temporalio.exceptions.ApplicationError`.

4. **`_is_retryable_error(error)`** (`activities.py:168-183`): lowercases `str(type(error))` and returns `True` if ANY of these substrings appears: `timeout`, `connection`, `network`, `temporary`, `unavailable`, `overload`, `busy`, `throttle`, `rate_limit`. Matching is on the **exception class repr string**, not the message. ⚠️ GOTCHA: classification keys off `str(type(error))` (e.g. `"<class 'TimeoutError'>"`), so `TimeoutError`, `ConnectionError`, `asyncio.TimeoutError` classify retryable; a plain `OSError`/`ValueError` classifies non-retryable.

**`ActivityConfig` field defaults** (`activities.py:27-39`, dataclass): `retry_policy=None`, `start_to_close_timeout=None`, `schedule_to_close_timeout=None`, `schedule_to_start_timeout=None`, `heartbeat_timeout=None`, `enable_observability=True`, `enable_error_wrapping=True`, `log_inputs=False`, `log_outputs=False`. ⚠️ GOTCHA: `ActivityConfig` does **not** set Temporal timeouts/retry — those are supplied by the **caller** at `workflow.execute_activity(...)`. The decorator's config only governs observability + error wrapping. So the timeouts/retry below come from the workflow call sites, not the decorator.

⚠️ CRITICAL FOR THIS ACTIVITY: **the body almost never reaches the wrapper's `except` branch.** `load_context_priors` is written to *swallow* all content/IO/YAML errors internally (try/except returning `""` or `[]`) and return a valid `LoadContextPriorsResult`. The wrapper's error-wrapping path only triggers if something outside those guarded sections raises — e.g. a non-`OSError` during `read_bytes`, an unexpected exception in `.resolve()`, or a pydantic/serialization failure constructing the result. In normal operation the activity returns successfully (possibly with `priors=[]`).

---

## ACTIVITY: `load_context_priors`

### Signature

```python
@foundry_activity(config=ActivityConfig(enable_observability=True))
async def load_context_priors(input: LoadContextPriorsInput) -> LoadContextPriorsResult
```

`from __future__ import annotations` is active (line 15) — annotations are strings; no runtime effect on behavior.

### INPUT type — `LoadContextPriorsInput` (`types.py:2755-2766`)

```python
@dataclass
class LoadContextPriorsInput:
    skill_id: str          # the ONLY field; required, no default
```
- `skill_id` is matched against each manifest entry's `skills` list; entries that don't list this skill are skipped.
- Plain `@dataclass` (not pydantic). Single positional/kw field `skill_id`.

### OUTPUT type — `LoadContextPriorsResult` (`types.py:2784-2789`)

```python
@dataclass
class LoadContextPriorsResult:
    priors: list[dict]     # ALWAYS a list; empty list == "no priors for this skill"
```
- `priors` is a `list[dict]` — **NOT** `list[ContextPrior]`. ⚠️ GOTCHA: although a `ContextPrior` dataclass exists (`types.py:2769-2781`, fields `id, path, purpose, content`), the result field type is the raw `list[dict]` and the activity body constructs plain dicts with exactly those four keys (see "WRITTEN JSON shape"). Callers do `getattr(result, "priors", None) or []` and pass the dicts through verbatim; they never instantiate `ContextPrior`. Rebuild must emit dicts, not dataclass instances, for the over-the-wire (Temporal data-converter) shape to match.
- Empty list is the expected "no priors" shape — callers do **not** branch on emptiness beyond "if truthy, attach."

### Module-level constant

`_MAX_PRIOR_BYTES = 128 * 1024` (= **131072**, 128 KiB) — hard per-prior byte cap (line 38). Rationale (docstring): keep activity output under Temporal's 2 MB payload limit; **per-prior** cap (not a shared budget) for simpler accounting and predictable per-prior truncation.

### JSON / data shapes READ

**(a) `OLYMPUS_PROFILE_ROOT` env var** — a directory path string. **(b) `<profile_root>/context-priors/manifest.yaml`** — YAML document of shape:

```yaml
version: 1                     # read but IGNORED by the activity (not validated/used)
priors:                        # MUST be a list, else treated as no priors
  - id: <string>               # REQUIRED truthy, else entry skipped
    path: <string>             # REQUIRED truthy, else entry skipped; relative to context-priors/
    skills:                    # list of skill ids; entry matches when input.skill_id ∈ skills
      - <skill-id>
      - ...
    purpose: |                 # optional free text; defaults to "" if missing/falsy
      <multi-line text>
```
Canonical example (`profiles/faa/context-priors/manifest.yaml`): two priors —
- `subfactor-1-rationalization-business-value` → path `subfactor-1-portfolio-rationalization-business-value.md`, skills `[disposition-recommender, analyze-portfolio-redundancy, capability-consolidation-advisor]`.
- `subfactor-3-target-state-architecture` → path `subfactor-3-target-state-architecture.md`, skills `[target-state-mapper, blueprint-assembly, migration-strategy-advisor]`.

**(c) Each prior markdown file** — read as raw bytes, decoded UTF-8 (`errors="replace"`).

### JSON shape WRITTEN (the return)

`LoadContextPriorsResult(priors=[ ... ])` where each element is a dict with EXACTLY these four string keys, in this insertion order:

| key       | value                                              | source / coercion |
|-----------|----------------------------------------------------|-------------------|
| `id`      | `str(entry.get("id"))`                             | manifest entry `id`, forced to str |
| `path`    | `str(rel_path)`                                    | manifest entry `path` (the *relative* path, NOT resolved absolute) |
| `purpose` | `str(entry.get("purpose") or "")`                  | manifest entry `purpose`; empty string when missing/falsy |
| `content` | the (possibly truncated) markdown body, UTF-8 text | from `_read_prior_content(file_path)` |

⚠️ GOTCHA: `path` in the output is the **relative** manifest path (`rel_path`), even though resolution/validation used the absolute `file_path`. Do not emit the absolute path.

### CONTROL FLOW — exact, step by step (`load_context_priors`, lines 107-165)

1. `profile_root = _profile_root_from_env()`. **If `None` → `return LoadContextPriorsResult(priors=[])`** immediately. (lines 122-124)
2. `priors_dir = profile_root / "context-priors"`. **If `not priors_dir.is_dir()` → return `priors=[]`.** (lines 126-128)
3. `manifest = _load_manifest(priors_dir / "manifest.yaml")`. **If `not manifest` (empty list) → return `priors=[]`.** (lines 130-132)
4. `matched: list[dict] = []`. Iterate `for entry in manifest:` (lines 134-163):
   a. `skills = entry.get("skills") or []`.
   b. **If `not isinstance(skills, list)` OR `input.skill_id not in skills` → `continue`** (skip entry). (line 137) ⚠️ The `not isinstance(skills, list)` guard catches a `skills` that is e.g. a string — without it, `in` on a string would do substring matching. Note: `entry.get("skills") or []` already turned a missing/falsy `skills` into `[]`, so the isinstance check primarily defends a non-list truthy value.
   c. `rel_path = entry.get("path") or ""`.
   d. **If `not isinstance(rel_path, str)` → `continue`.** (Note: `_load_manifest` already required `path` truthy, but type isn't guaranteed there.) (line 140-141)
   e. `file_path = (priors_dir / rel_path).resolve()` — absolute, symlinks/`..` resolved.
   f. **Path-escape defense:** `try: file_path.relative_to(priors_dir.resolve())` — **on `ValueError`** (file_path is outside priors_dir, e.g. manifest used `../`), log warning `"context_priors: manifest path escapes priors dir: %s"` with `rel_path` and **`continue`**. (lines 145-152) ⚠️ SECURITY GOTCHA: this is the only guard preventing a malicious/buggy manifest from exfiltrating arbitrary files via `../`. Must compare *both* resolved (`file_path` is resolved, compared against `priors_dir.resolve()`).
   g. `content = _read_prior_content(file_path)`.
   h. **If `not content` (empty string) → `continue`** (unreadable / empty file skipped — empty priors never surface). (lines 154-155)
   i. Append the 4-key dict (table above) to `matched`. (lines 156-163)
5. `return LoadContextPriorsResult(priors=matched)`. (line 165)

⚠️ ORDERING GOTCHA: a prior is included **only if** its manifest entry has a truthy `id` AND truthy `path` (enforced in `_load_manifest`), `skills` is a list containing `input.skill_id`, the resolved file stays inside `priors_dir`, and the file is non-empty after read. Output order = manifest declaration order, filtered. Multiple entries matching the same `skill_id` all appear (no dedup).

### Helper: `_profile_root_from_env() -> Path | None` (lines 41-59)

1. `env = os.environ.get("OLYMPUS_PROFILE_ROOT")`.
2. **If `env` is truthy:** `p = Path(env).resolve()`; **if `p.is_dir()` → return `p`.** (If `env` set but not a dir, fall through to the fallback — does NOT return None yet.)
3. **Fallback (local dev):** `repo_root = Path(__file__).resolve().parents[3]` (this file is at `temporal/olympus_workflows/activities/context_priors.py`; repo root is **three** parents up — `parents[3]` because `parents[0]=activities`, `[1]=olympus_workflows`, `[2]=temporal`, `[3]=repo root`). `candidate = repo_root / "profiles" / "faa"`.
4. **Return `candidate` if `candidate.is_dir()` else `None`.**

⚠️ GOTCHA: env-var presence alone is not trusted — the path must be an existing directory. ⚠️ GOTCHA: the local-dev fallback **hardcodes the `faa` profile** (`profiles/faa`). In production, worker bootstrap (`worker_bootstrap.py`, wired via compose + helm) writes `OLYMPUS_PROFILE_ROOT` before worker start; the fallback only matters for local dev where the env var may be unset. ⚠️ `parents[3]` is brittle to file relocation — moving this module changes the resolved repo root.

### Helper: `_load_manifest(manifest_path: Path) -> list[dict[str, Any]]` (lines 62-84)

1. **If `not manifest_path.exists()` → return `[]`.**
2. `try: data = yaml.safe_load(manifest_path.read_text()) or {}` — `or {}` coerces a `None`/empty YAML to `{}`. **`except yaml.YAMLError as exc:`** log warning `"context_priors: manifest YAML unparseable at %s: %s"` (path, exc) and **return `[]`** (never raises on bad YAML). ⚠️ Only `yaml.YAMLError` is caught here; a non-YAMLError (e.g. `UnicodeDecodeError` from `read_text`) would propagate out of this helper → up to the activity wrapper → classified non-retryable. In practice manifest is small ASCII/UTF-8.
3. `priors = data.get("priors")`. **If `not isinstance(priors, list)` → return `[]`.**
4. Iterate entries; build `out: list[dict]`:
   - **`if not isinstance(entry, dict): continue`** (skip non-dict list members).
   - **`if not entry.get("id") or not entry.get("path"): continue`** — entry MUST have truthy `id` and truthy `path`, else skipped.
   - else `out.append(entry)` (the whole raw dict, unmodified).
5. Return `out`.

⚠️ GOTCHA: `_load_manifest` validates only `id` and `path` presence/truthiness. It does NOT validate `skills` or `purpose` here — those are handled in the activity loop. `version` is never inspected.

### Helper: `_read_prior_content(path: Path) -> str` (lines 87-104)

1. `try: raw = path.read_bytes()`. **`except OSError as exc:`** log warning `"context_priors: could not read %s: %s"` (path, exc) and **return `""`** (empty → entry skipped upstream). Only `OSError` is caught; other exception types propagate.
2. **If `len(raw) > _MAX_PRIOR_BYTES` (131072):** truncate —
   - `truncated = raw[:_MAX_PRIOR_BYTES].decode("utf-8", errors="replace")`
   - return `truncated + "\n\n[TRUNCATED: prior exceeded " + f"{_MAX_PRIOR_BYTES // 1024} KiB; full text at " + str(path.relative_to(path.parents[2])) + "]\n"`.
   - i.e. the literal appended marker is: `\n\n[TRUNCATED: prior exceeded 128 KiB; full text at <path-relative-to-parents[2]>]\n` where `128 = _MAX_PRIOR_BYTES // 1024`.
   - ⚠️ GOTCHA: the marker's "full text at" path is `path.relative_to(path.parents[2])`. `path` is the resolved absolute file path; `path.parents[2]` is two-and-a-bit levels up. For `.../profiles/faa/context-priors/<file>.md`: `parents[0]=context-priors`, `[1]=faa`, `[2]=profiles` → relative path is `faa/context-priors/<file>.md`. ⚠️ FRAGILE: `path.parents[2]` assumes the prior sits exactly at `<...>/profiles/faa/context-priors/<file>` depth; a prior in a subdirectory of `context-priors/`, or a profile not named under a 3-deep layout, yields a different (or potentially erroring) relative segment. If `path` has fewer than 3 parents the `relative_to` would raise `ValueError` (uncaught here → propagates to wrapper). The canonical FAA layout is exactly 3-deep so this holds.
   - ⚠️ TRUNCATION GOTCHA: byte-slice at `[:131072]` can split a multi-byte UTF-8 sequence; `errors="replace"` substitutes U+FFFD for the dangling bytes — no crash, but final char may be a replacement glyph.
3. Else (within cap): return `raw.decode("utf-8", errors="replace")`.

### Error handling / retries / idempotency

- **Internal best-effort:** all expected failure modes return a benign value (`None`/`[]`/`""`) and log a warning — the activity is documented to "Never raise for content errors." So in normal operation the wrapper's success path runs and returns `LoadContextPriorsResult`.
- **Wrapper-level (see PREAMBLE):** any *unexpected* exception that escapes the guarded sections is wrapped: `WorkflowError`/`ApplicationError` re-raised as-is; class-name matches a retryable substring → `RetryableError`; else `NonRetryableError`.
- **Caller-supplied Temporal retry/timeout** (the policy that actually governs re-execution): both call sites use `start_to_close_timeout=timedelta(seconds=10)` and `retry_policy=RETRY_POLICIES["transient"]`.
  - `RETRY_POLICIES["transient"]` (`olympus_workflows/retry_policies.py:33,110`) **=** `TRANSIENT_RETRY_POLICY` **=** `HTTP_RETRY_POLICY` (imported from `foundry_temporal.retry_policies`, defined at `.../foundry_temporal/retry_policies.py:37-42`):
    ```python
    RetryPolicy(initial_interval=1s, maximum_interval=15s, maximum_attempts=3, backoff_coefficient=2.0)
    ```
  - So Temporal retries up to **3 attempts**, backoff 1s→2s (capped 15s), **unless** the activity raised a `NonRetryableError`/`ApplicationError(non_retryable=True)`, which the framework will not retry. A `RetryableError` is a normal exception → retried within the 3-attempt budget.
- **Idempotency:** fully idempotent / side-effect-free — pure read of env + filesystem + YAML. No DB, no Git, no network, no writes. Re-execution yields the same result given unchanged files. Safe to retry; safe to replay (but see determinism note: the *caller* gates dispatch — see below).

### How callers consume it (calling contract — needed for parity of the surrounding behavior)

Two folding sites; both treat the activity as best-effort and **never block dispatch on failure**:

1. **`workflows/wave_rationalization.py:953-995` — `_with_context_priors(context: dict, skill_id: str) -> dict`:**
   - `result = await workflow.execute_activity(load_context_priors, LoadContextPriorsInput(skill_id=skill_id), start_to_close_timeout=timedelta(seconds=10), retry_policy=RETRY_POLICIES["transient"])`.
   - **`except Exception`** → `workflow.logger.warning("context_priors load failed (continuing without priors): %s", exc, extra={"skill_id": skill_id})` and **return `context` unchanged**.
   - `priors = getattr(result, "priors", None) or []`; **if `not priors`: return `context`** (no key added).
   - else `merged = dict(context); merged["context_priors"] = priors; return merged`. ⚠️ Returns a *copy*; original `context` untouched. The `context_priors` value is the raw `list[dict]` from the activity. Used at call sites lines 1774, 1857, 2393, 3277 to build the agent dispatch `context`.

2. **`workflows/base.py:402-425` — inside step dispatch (`_run_step`-style):**
   - **`if workflow.patched("context-priors-v1"):`** — ⚠️ DETERMINISM GOTCHA: the *entire* prior-loading is **patch-gated** via `workflow.patched("context-priors-v1")`. Pre-patch in-flight workflow runs **replay without** executing `load_context_priors`, preserving deterministic event history (no new activity in old histories). A rebuild MUST keep this `workflow.patched("context-priors-v1")` guard around the `execute_activity` call in `base.py`, or replays of pre-patch runs will non-determinism-fail. (The `wave_rationalization._with_context_priors` site is NOT patch-gated in the same way — it's a newer helper; verify against its workflow's own versioning if rebuilding that workflow.)
   - On success: `priors = getattr(priors_result, "priors", None) or []`; `if priors: context["context_priors"] = priors` (mutates the local `context` dict directly — no copy here, unlike the wave_rationalization helper).
   - **`except Exception`** → `workflow.logger.warning("context_priors load failed (continuing): %s", exc, extra={"skill_id": skill_id, "step": step_name})`; dispatch proceeds without priors.
   - The resulting `context` (with or without `context_priors`) is passed into `AgentTaskInput(task_type=..., app_id=..., skill_id=skill_id, context=...)` (line 426+), i.e. folded into `AgentTaskInput.context['context_priors']` exactly as the module docstring states.

### Registration

- Exported from `olympus_workflows/activities/__init__.py` (`from olympus_workflows.activities.context_priors import load_context_priors`; listed in `__all__`).
- Registered on the worker in `worker.py` (imported line 52-53, included in the activity registration list line 216). Temporal activity type name = **`load_context_priors`** (function name, since decorator `name=None`).

---

## Sibling reference (FYI — the manifest README)

`profiles/faa/context-priors/README.md` (3867 bytes) documents the authoring contract for profile owners. The two FAA prior files are real and large: `subfactor-1-...md` (53030 bytes) and `subfactor-3-...md` (34970 bytes) — both **under** the 131072-byte cap, so neither truncates in practice; the truncation branch is exercised only by hypothetically larger priors.
