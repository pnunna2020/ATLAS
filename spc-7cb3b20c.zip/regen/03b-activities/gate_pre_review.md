# Activity Group: `gate_pre_review` — Atomic Regeneration Spec

**Source file:** `temporal/olympus_workflows/activities/gate_pre_review.py`
**Scope:** `store_gate_pre_review` activity + the `_parse_pre_review` parser + the workflow-side pre-review dispatch logic (`_run_gate_pre_review`) that feeds this activity.

This is the activity that takes the **raw markdown** emitted by the `gate-pre-review` AI skill, parses a structured recommendation out of it with a deliberately-lenient regex pipeline, and merges that recommendation into the `gate.evidence_data` JSONB column via an **atomic JSONB `||` merge** — so the dashboard can render the AI's advisory verdict without a schema migration.

Behavioral parity bar: an engineer with no access to this code must reproduce (a) the exact regex pipeline and its fall-back rules, (b) the exact SQL and the column it touches, (c) the exact dict / dataclass shapes read and written, and (d) the best-effort fault-tolerant dispatch envelope around it. Over-specified on purpose.

---

## 0. THE DECORATOR — `@foundry_activity` (capture once, applies to `store_gate_pre_review`)

`store_gate_pre_review` is decorated with:

```python
@foundry_activity(config=ActivityConfig(enable_observability=True))
```

`foundry_activity` is defined in `foundry_temporal/activities.py:107-165` (the external `foundry_temporal` package). **It is NOT plain `@activity.defn`.** A rebuild that uses `@activity.defn` directly loses error-wrapping + retryability classification and will NOT behave identically. Reproduce the wrapper exactly:

### `ActivityConfig` (dataclass, `activities.py:27-39`)
| field | type | default | effect here |
|---|---|---|---|
| `retry_policy` | `RetryPolicy \| None` | `None` | unused by this activity (retry comes from the workflow `execute_activity` call, see §5) |
| `start_to_close_timeout` | `timedelta \| None` | `None` | unused at decorator level |
| `schedule_to_close_timeout` | `timedelta \| None` | `None` | unused |
| `schedule_to_start_timeout` | `timedelta \| None` | `None` | unused |
| `heartbeat_timeout` | `timedelta \| None` | `None` | unused |
| `enable_observability` | `bool` | `True` | **explicitly set `True`** → emits start/complete/fail logs via `get_logger()` |
| `enable_error_wrapping` | `bool` | `True` | **defaulted `True`** → wraps raised exceptions (see below) |
| `log_inputs` | `bool` | `False` | inputs are NOT logged in the observability log line |
| `log_outputs` | `bool` | `False` | outputs are NOT logged |

### What the wrapper does at runtime (`activities.py:122-163`)
1. Applies `@activity.defn(name=None)` → activity registered under its **function name** `store_gate_pre_review` (no custom `name=` passed). `@wraps(func)` preserves `__name__`.
2. `activity_name = name or func.__name__` → `"store_gate_pre_review"`.
3. Calls `activity_logger = get_logger()` (from `foundry_temporal.logging`).
4. Because `enable_observability=True`: logs `INFO "Activity store_gate_pre_review starting"` with `extra={"inputs": None}` (None because `log_inputs=False`).
5. `result = await func(*args, **kwargs)` — runs the real body.
6. On success: logs `INFO "Activity store_gate_pre_review completed"` with `extra={"outputs": None}` (None because `log_outputs=False`); returns `result`.
7. On `except Exception as error`:
   - logs `ERROR "Activity store_gate_pre_review failed: {error}"` with `extra={"error": str(error)}`.
   - because `enable_error_wrapping=True`, applies the **classification chain** (`activities.py:154-159`):
     - `if isinstance(error, (WorkflowError, ApplicationError)): raise` — re-raise unchanged (preserves the existing `non_retryable` flag).
     - `elif _is_retryable_error(error):` → `raise RetryableError(f"Retryable error in store_gate_pre_review: {error}") from error`.
     - `else:` → `raise NonRetryableError(f"Non-retryable error in store_gate_pre_review: {error}") from error`.

### `_is_retryable_error` (the decorator's classifier, `activities.py:168-183`)
**⚠ GOTCHA — string-match on the type repr, NOT the `errors.py` `is_retryable_error`.** This is the classifier `foundry_activity` actually calls. It does:
```python
error_str = str(type(error)).lower()
retryable_patterns = ["timeout","connection","network","temporary","unavailable","overload","busy","throttle","rate_limit"]
return any(pattern in error_str for pattern in retryable_patterns)
```
It matches against `str(type(error))` (e.g. `"<class 'asyncpg.exceptions.ConnectionDoesNotExistError'>"`). So an asyncpg `ConnectionDoesNotExistError` → contains `"connection"` → **Retryable**. A generic `asyncpg.PostgresError` or a `ValueError` → no pattern match → **NonRetryable**.

### Error classes raised (from `foundry_temporal/errors.py`)
- `WorkflowError(ApplicationError)` — `__init__(message, non_retryable=True)` (errors.py:10-14). Base, `non_retryable` defaults True.
- `RetryableError(WorkflowError)` — calls `super().__init__(message, non_retryable=False)` (errors.py:17-21). **Temporal WILL retry.**
- `NonRetryableError(WorkflowError)` — `super().__init__(message, non_retryable=True)` (errors.py:24-28). **Temporal will NOT retry.**

**Net effect for `store_gate_pre_review`:** the body itself raises nothing typed; if `asyncpg.connect` / `conn.execute` throws a connection-flavored error it becomes `RetryableError`; any other DB error becomes `NonRetryableError`. The workflow caller additionally swallows *all* exceptions (see §6), so in normal operation a failure here is logged-and-ignored, not fatal.

---

## 1. Imports & module-level helpers

```python
from __future__ import annotations
import json, logging, os, re
import asyncpg
from foundry_temporal.activities import ActivityConfig, foundry_activity
from olympus_workflows.types import StoreGatePreReviewInput, StoreGatePreReviewResult
logger = logging.getLogger(__name__)
```
**⚠ GOTCHA:** module uses the stdlib `logging.getLogger(__name__)` for its own `logger.warning/info` calls (gate_pre_review.py:21), **separate** from the decorator's `get_logger()`. Both fire.

### `_db_url() -> str` (gate_pre_review.py:24-31)
Builds the DSN from env vars with these exact defaults:
| env var | default |
|---|---|
| `DATABASE_HOST` | `localhost` |
| `DATABASE_PORT` | `5432` |
| `DATABASE_USER` | `olympus` |
| `DATABASE_PASSWORD` | `olympus` |
| `DATABASE_NAME` | `olympus` |

Returns `f"postgresql://{user}:{password}@{host}:{port}/{db}"`. No URL-encoding of password.

---

## 2. `_parse_pre_review(markdown: str) -> dict` (gate_pre_review.py:34-141)

Pure function (no I/O). Extracts structured data from the skill's markdown. **Intentionally lenient** to absorb emoji shortcodes, bold/no-bold, prose, different table delimiters.

### Initial result dict (gate_pre_review.py:46-53) — exact keys & defaults
```python
result = {
    "confidence_score": 0,      # int
    "recommendation": "",       # str
    "summary": "",              # str
    "full_markdown": markdown,  # str — the verbatim input, ALWAYS the unmodified arg
    "score_breakdown": {},      # dict[str, {"score": int, "weight": float}]
    "flags": [],                # list[str]
}
```

### 2.1 Confidence score (gate_pre_review.py:60-72)
Try these 4 regexes **in order**; first match whose captured int is `0 <= val <= 100` wins; `break`. If none matches/validates, stays `0`.
```python
score_patterns = [
  r"[Cc]onfidence[^:]*:\s*\*{0,2}\s*(\d+)\s*/?\s*100\s*\*{0,2}",  # "Confidence: **82/100**"
  r"(\d+)\s*/\s*100",                                            # bare "82/100"
  r"(\d+)\s+(?:out\s+)?of\s+100",                                # "82 out of 100" / "82 of 100"
  r"[Cc]onfidence[^.]*?(\d{1,3})(?:\s|$|\.|\*)",                 # "Confidence: 82"
]
for pattern in score_patterns:
    score_match = re.search(pattern, markdown)
    if score_match:
        val = int(score_match.group(1))
        if 0 <= val <= 100:
            result["confidence_score"] = val
            break
```
**⚠ GOTCHA:** the range check is inside the loop **but there is no `else: continue` to the next pattern when out-of-range** — if a pattern matches but `val` is >100, the loop simply does not `break` and proceeds to the next pattern on the *next iteration*. (i.e. an out-of-range match for pattern N is discarded and pattern N+1 is tried.) Reproduce exactly. Pinned by `test_unstructured_extracts_confidence` ("75 out of 100" → 75 via pattern 3).

### 2.2 Recommendation level (gate_pre_review.py:76-82)
```python
rec_match = re.search(r"(APPROVE|REVIEW\s+THOROUGHLY|LIKELY\s+REJECT)", markdown, re.IGNORECASE)
if rec_match:
    result["recommendation"] = rec_match.group(1).upper()
    result["recommendation"] = re.sub(r"\s+", " ", result["recommendation"])  # collapse whitespace
```
First case-insensitive hit, upper-cased, internal whitespace collapsed to single spaces. Canonical outputs: `"APPROVE"`, `"REVIEW THOROUGHLY"`, `"LIKELY REJECT"`. Stays `""` if none present (pinned: `test_garbage_input_returns_defaults`).

### 2.3 Summary — primary attempt (gate_pre_review.py:86-93)
Only if `result["recommendation"]` is truthy:
```python
summary_match = re.search(
    r"(?:APPROVE|REVIEW\s+THOROUGHLY|LIKELY\s+REJECT).*?\n\n(.+?)(?:\n\n|\n#)",
    markdown, re.DOTALL | re.IGNORECASE)
if summary_match:
    result["summary"] = summary_match.group(1).strip()
```
Captures the first paragraph after the recommendation line, terminated by a blank line OR a line starting with `#`. `.strip()` applied. Pinned: `test_extracts_summary`.

### 2.4 Summary — fallback via `## Recommendation` heading (gate_pre_review.py:96-112)
Only if `result["summary"]` is still falsy:
```python
rec_section = re.search(r"##\s*Recommendation\s*\n+(.+?)(?:\n\n|\n##)", markdown, re.DOTALL | re.IGNORECASE)
if rec_section:
    lines = rec_section.group(1).strip().split("\n")
    rec_pat = r"APPROVE|REJECT|THOROUGHLY|Confidence|\d+/100"
    summary_lines = [line for line in lines if not re.search(rec_pat, line, re.IGNORECASE)]
    if summary_lines:
        result["summary"] = " ".join(line.strip() for line in summary_lines if line.strip())
```
Grabs the block under a `## Recommendation` heading, drops every line that looks like the rec/score header (matches `rec_pat`, case-insensitive), joins the survivors with single spaces (each stripped, empties dropped). Pinned: `test_review_thoroughly_extracts_summary`, `test_case_insensitive_recommendation`.

### 2.5 Score breakdown table (gate_pre_review.py:116-129)
```python
dimension_rows = re.findall(r"\|\s*([^|]+?)\s*\|\s*(\d+)\s*\|\s*([^|]+?)\s*\|", markdown)
for dim_name, score, third_col in dimension_rows:
    dim_key = dim_name.strip().lower().replace(" ", "_").replace("&", "and")
    if dim_key and dim_key not in ("dimension", "---", "--------"):
        try:
            weight = float(third_col.strip())
        except ValueError:
            weight = 0.0  # "Notes" column — no numeric weight
        result["score_breakdown"][dim_key] = {"score": int(score), "weight": weight}
```
Matches 3-column markdown rows where col-2 is digits. Key normalization: lowercased, spaces→`_`, `&`→`and`. Excludes header (`dimension`) and separator rows (`---`, `--------`). **⚠ GOTCHA:** the separator-exclusion only covers col-1 being exactly `---`/`--------`; but `(\d+)` in col-2 means typical `|---|---|---|` separator rows fail the regex anyway (no digits in col 2). Third column → float weight, or **`0.0`** when it's prose like a "Notes" column. Pinned: `test_extracts_score_breakdown` (weight 0.3), `test_emoji_shortcode_extracts_notes_column` (Notes col → score kept, weight 0.0).

### 2.6 Flags (gate_pre_review.py:133-139)
```python
flag_matches = re.findall(
    r"[-*]\s*\*{0,2}(BLOCKER|WARNING|INFO(?:RMATIONAL)?|CRITICAL|NOTE)\*{0,2}[:\s—–-]*(.+?)(?:\n|$)",
    markdown, re.IGNORECASE)
for severity, description in flag_matches:
    result["flags"].append(f"{severity.upper()}: {description.strip()}")
```
Bullet lines (`-` or `*`) whose first token is one of `BLOCKER|WARNING|INFO|INFORMATIONAL|CRITICAL|NOTE` (bold optional, separator may be `:`, whitespace, em/en dash, hyphen). Output format: `"{SEVERITY_UPPER}: {description_stripped}"`. Pinned: `test_extracts_flags`, `test_extracts_blocker_flags`.

Returns `result`.

---

## 3. `store_gate_pre_review` — Activity

### Signature
```python
@foundry_activity(config=ActivityConfig(enable_observability=True))
async def store_gate_pre_review(input: StoreGatePreReviewInput) -> StoreGatePreReviewResult
```
Registered in worker at `worker.py:67` (import) and `worker.py:184` (activities list).

### Input — `StoreGatePreReviewInput` (dataclass, `types.py:2631-2636`) — EVERY field
| field | type | default | notes |
|---|---|---|---|
| `gate_id` | `str` | (required) | the `gate.id` value (a UUID **string**; passed straight into SQL `$2` — see §4 GOTCHA) |
| `agent_output` | `str` | (required) | raw markdown from the `gate-pre-review` skill |

### Output — `StoreGatePreReviewResult` (dataclass, `types.py:2639-2646`) — EVERY field
| field | type | default |
|---|---|---|
| `gate_id` | `str` | (required, echoed from input) |
| `stored` | `bool` | `False` |
| `recommendation` | `str` | `""` (`"APPROVE"`/`"REVIEW THOROUGHLY"`/`"LIKELY REJECT"`) |
| `confidence_score` | `int` | `0` |

### Control flow (gate_pre_review.py:144-220)

1. `parsed = _parse_pre_review(input.agent_output)`.
2. **Fallback branch when `not parsed["recommendation"]`** (gate_pre_review.py:161-188):
   - Build `preview = input.agent_output[:500] if input.agent_output else "(empty)"`.
   - `logger.warning("Could not parse recommendation from pre-review output for gate %s. Output preview: %s", input.gate_id, preview)`.
   - **If `input.agent_output.strip()` is truthy** (we have *some* content but couldn't classify):
     - `parsed["recommendation"] = "REVIEW THOROUGHLY"` (safe default — never silently approve).
     - `parsed["confidence_score"] = parsed.get("confidence_score") or 50` (keep a parsed score if any; else **50**).
     - If `not parsed["summary"]`: scan `input.agent_output.split("\n")` for the **first** line that is non-empty AND does not start with `#` AND does not start with `|`; set `parsed["summary"] = stripped[:200]`; `break`.
     - `logger.info("Falling back to REVIEW THOROUGHLY for gate %s with agent content", input.gate_id)`.
   - **Else (`input.agent_output` is empty/whitespace-only):**
     - `return StoreGatePreReviewResult(gate_id=input.gate_id, stored=False)` — **EARLY RETURN, no DB write.** (`stored=False`, `recommendation=""`, `confidence_score=0`.)
3. `ai_rec_json = json.dumps({"ai_recommendation": parsed})` — wraps the whole parsed dict under the single key `ai_recommendation`.
4. Open connection: `conn = await asyncpg.connect(_db_url())`.
5. In `try` / `finally` (finally = `await conn.close()`): run the UPDATE (see §4).
6. `logger.info("Stored gate pre-review recommendation", extra={"gate_id": ..., "recommendation": parsed["recommendation"], "confidence_score": parsed["confidence_score"]})`.
7. Return:
```python
StoreGatePreReviewResult(
    gate_id=input.gate_id,
    stored=True,
    recommendation=parsed["recommendation"],
    confidence_score=parsed["confidence_score"],
)
```

**⚠ GOTCHA (idempotency / write-even-when-unparseable):** the only path that skips the DB write is *empty/whitespace* agent output. Any non-empty output ALWAYS writes — falling back to `REVIEW THOROUGHLY` / score 50 so a reviewer always sees *something*. Reproduce both branches precisely.

---

## 4. PROJECTION / PERSIST LOGIC — artifact-JSON → DB column mapping

This activity writes to **exactly one table, one column**.

### Target table & column
- **Table:** `gate`
- **Column written:** `gate.evidence_data` (JSONB)
- No other column is read or written. `gate.id` appears only in the `WHERE` predicate (not written).

### The EXACT SQL (gate_pre_review.py:194-202)
```sql
UPDATE gate
SET evidence_data = COALESCE(evidence_data, '{}'::jsonb) || $1::jsonb
WHERE id = $2
```
Parameters (positional, asyncpg `$N`):
- `$1` = `ai_rec_json` (the Python `str` from `json.dumps({"ai_recommendation": parsed})`), cast `::jsonb`.
- `$2` = `input.gate_id` (the Python `str`).

Semantics: `COALESCE(evidence_data, '{}'::jsonb)` makes a NULL `evidence_data` behave as `{}`; the `||` JSONB concatenation operator **merges at the top level**, adding/replacing only the `ai_recommendation` key and **preserving every other existing top-level key** (e.g. `review`, `steps`, `passes`, `findings`, `rationalization_capabilities`, `tier1_approvals`). This is the entire reason the activity exists (no schema migration needed).

**⚠ GOTCHA — no `::uuid` cast on `WHERE id = $2`.** Sibling activities cast the id (`gate_operations.py:1265` uses `WHERE id = $1::uuid`; api `gate.py:309` casts too). Here the predicate is bare `WHERE id = $2` with `input.gate_id` a `str`. This relies on Postgres implicitly coercing the text literal to the `uuid`-typed `id` column for equality. It works because the parameter is sent as text and compared against a `uuid` column (Postgres casts the unknown-typed param to `uuid`). **Reproduce the bare predicate exactly — adding `::uuid` would change parameter binding/typing behavior and is a deviation from this code.**

**⚠ GOTCHA — `||` is top-level shallow merge, NOT deep merge.** If `evidence_data` already had a nested `ai_recommendation` it is **fully replaced**, not deep-merged. Re-running the activity is therefore idempotent in the sense that the latest parse overwrites the prior `ai_recommendation` wholesale.

**⚠ GOTCHA — silent no-op on missing gate.** `UPDATE ... WHERE id = $2` matching zero rows does **not** raise; `conn.execute` returns `"UPDATE 0"` and the activity still returns `stored=True`. The code does not check the affected-row count. Reproduce: do not raise on 0 rows.

### Column-by-column mapping table

Single column, but the **value written is a structured JSON object**. The mapping of the in-Python `parsed` dict → the JSON merged under `evidence_data.ai_recommendation`:

| source (`parsed[...]` key) | written JSON path (within `evidence_data`) | type | default / condition |
|---|---|---|---|
| `parsed["confidence_score"]` | `evidence_data.ai_recommendation.confidence_score` | int | `0` if unparsed & non-empty fallback didn't set; `50` via fallback when content present but no parse; else parsed value |
| `parsed["recommendation"]` | `evidence_data.ai_recommendation.recommendation` | str | parsed level, or `"REVIEW THOROUGHLY"` fallback when content present but unparseable; **never written at all (early return) when output is empty** |
| `parsed["summary"]` | `evidence_data.ai_recommendation.summary` | str | `""` default; primary/heading/fallback first-line extraction |
| `parsed["full_markdown"]` | `evidence_data.ai_recommendation.full_markdown` | str | always the verbatim `input.agent_output` |
| `parsed["score_breakdown"]` | `evidence_data.ai_recommendation.score_breakdown` | object `{dim_key: {"score": int, "weight": float}}` | `{}` default |
| `parsed["flags"]` | `evidence_data.ai_recommendation.flags` | array[str] | `[]` default; each `"SEV: desc"` |

**The whole `parsed` dict is serialized — every one of its 6 keys is written.** There is no per-key conditional pruning; the only conditional is the empty-output early return (no write) and the unparseable-but-non-empty fallback (which mutates `recommendation`/`confidence_score`/`summary` before writing).

### Downstream consumer contract — `AIRecommendation` (`olympus-api/src/models/gate.py:244-252`)
The persisted JSON is read back by the API into this Pydantic model — its fields are exactly the 6 `parsed` keys (so the parser's output shape is load-bearing and MUST match):
```python
class AIRecommendation(BaseModel):
    confidence_score: int
    recommendation: str            # "APPROVE" | "REVIEW THOROUGHLY" | "LIKELY REJECT"
    summary: str
    full_markdown: str
    score_breakdown: dict | None = None
    flags: list[str] | None = None
```
Surfaced on the gate-review UI via `GateEvidencePackage.ai_recommendation` (`gate.py:281`). **Do not rename or drop any of the 6 keys** — the API consumer would break.

---

## 5. Error handling / retries / idempotency (activity-level)

- **Body raises nothing typed.** Failure surface = `asyncpg.connect` (bad DSN / DB down) or `conn.execute` (SQL/connection error). The `finally: await conn.close()` runs even on execute failure (but not if `connect` itself raised, since `conn` wouldn't be bound — note the `try` starts *after* `connect`, so a `connect` failure propagates without a close, which is correct).
- These propagate up through the `@foundry_activity` wrapper (§0): connection-flavored errors → `RetryableError` (Temporal retries per the caller's policy); other DB errors → `NonRetryableError`.
- **Retry policy is supplied by the workflow caller, not the decorator** (`ActivityConfig.retry_policy=None`). The callers (§6) pass `RETRY_POLICIES["transient"]` with `start_to_close_timeout=timedelta(seconds=30)`.
- **`RETRY_POLICIES["transient"]`** = `TRANSIENT_RETRY_POLICY` = foundry's `HTTP_RETRY_POLICY` (`retry_policies.py:33`, `109-116`):
  `RetryPolicy(initial_interval=1s, maximum_interval=15s, maximum_attempts=3, backoff_coefficient=2.0)`.
- **Idempotency:** the UPDATE is idempotent at the top level — re-running replaces `ai_recommendation` wholesale via `||`. Other evidence keys are never disturbed. Safe to retry.

---

## 6. Pre-review dispatch logic (workflow-side caller) — `_run_gate_pre_review`

`store_gate_pre_review` is only ever invoked from `_run_gate_pre_review`, which also performs the **agent-dispatch** that produces the markdown. Two near-identical copies exist:
- `LineWorkflowBase._run_gate_pre_review` — `workflows/base.py:730-807` (used by Discovery, Architecture, Data, Disposition, Deployment, Validation, Modernization, Rationalization).
- `WaveRationalizationWorkflow._run_gate_pre_review` — `workflows/wave_rationalization.py:5424-5525` (inlined port; this workflow deliberately does **not** inherit the base).

Both are required for parity. Reproduce both.

### Signature (identical in both)
```python
async def _run_gate_pre_review(
    self, gate_id: str, gate_type_value: str, evidence_paths: list[str],
    *, artifact_repo: str = "", artifact_ref: str = "",
) -> None
```
**⚠ GOTCHA (`artifact_repo`/`artifact_ref` MUST be passed):** they default to `""` for back-compat, but if empty the agent-side fetch (`_fetch_input_artifacts`, gated on a non-empty `artifact_repo`) silently no-ops; the skill runs with `input_artifacts_dir=""` and the report complains about missing context. Every real dispatcher passes the active wave/app branch. (base.py:746-753; wave_rationalization.py:5440-5446.)

### 6.1 Agent-dispatch — assembling the call
Skill selection is **fixed**: `skill_id="gate-pre-review"`, `task_type="gate-pre-review"`. Dispatched via `dispatch_agent_task` activity with `start_to_close_timeout=timedelta(minutes=10)`, `retry_policy=RETRY_POLICIES["transient"]`.

`AgentTaskInput` (dataclass, `types.py`) is built as:

**Base version (base.py:758-774):**
```python
AgentTaskInput(
    skill_id="gate-pre-review",
    app_id=self._app_id,
    task_type="gate-pre-review",
    input_artifacts=evidence_paths,
    artifact_repo=artifact_repo,
    artifact_ref=artifact_ref,
    context={"gate_id": gate_id, "gate_type": gate_type_value},
    execution_context=self._execution_ctx(
        f"ai-pre-review-{gate_type_value.lower()}",
        gate_id=gate_id, input_artifact_paths=evidence_paths),
)
```
(`wave_id` left default `""`.)

**Wave-rationalization version (wave_rationalization.py:5486-5500):** identical EXCEPT `app_id=""`, `wave_id=self._wave_id`, and a **richer context** (see 6.2):
```python
context = pre_review_context  # built per 6.2
```

`AgentTaskInput` fields that matter here (full dataclass in `types.py`): `task_type`, `app_id`, `skill_id` (required-order positionally but passed by kw), `input_artifacts: list[str]=[]`, `optional_input_artifacts=[]`, `source_repo=""`, `artifact_repo=""`, `artifact_ref=""`, `model_preference=""`, `workspace_key=""`, `timeout_seconds=3600`, `context: dict={}`, `execution_context: StepExecutionContext|None=None`, `wave_id=""`. Exactly-one-of `app_id`/`wave_id` is enforced downstream at `_insert_agent_task_row`.

### 6.2 Wave-rationalization extra context (Issue #186, wave_rationalization.py:5465-5482)
```python
pre_review_context = {"gate_id": gate_id, "gate_type": gate_type_value}
if gate_type_value == "G-DA":
    pre_review_context["tier1_approvals"] = [
        self._tier1_approval_records[app_id] for app_id in sorted(self._tier1_approval_records)
    ]
    pre_review_context["downstream_artifact_kinds"] = [
        "disposition-recommendation", "disposition-governance",
        "user-impact-analysis", "classification", "portfolio-score",
    ]
```
Surfaces Tier-1 human approvals + the downstream rationalization artifact kinds so the skill weights human sign-off as evidence (otherwise Tier-1 waves got spurious "REVIEW THOROUGHLY"). `tier1_approvals` iterated in **sorted(app_id)** order for determinism.

### 6.3 Output extraction → store call (both versions, base.py:778-793 / wave.py:5504-5519)
```python
agent_markdown = (
    pre_review_result.output_artifacts[0]
    if pre_review_result.output_artifacts else ""
)
if not agent_markdown:
    raise ValueError("Gate pre-review produced no output")
await workflow.execute_activity(
    store_gate_pre_review,
    StoreGatePreReviewInput(gate_id=gate_id, agent_output=agent_markdown),
    start_to_close_timeout=timedelta(seconds=30),
    retry_policy=RETRY_POLICIES["transient"],
)
```
**⚠ GOTCHA (the production bug this codifies):** the markdown is `output_artifacts[0]`, **NOT** `pre_review_result.output` — `AgentTaskResult` has no `.output` attr. Pinned by `test_agent_result_has_output_artifacts_not_output`. `AgentTaskResult` fields (`types.py`): `task_id`, `status=TaskStatus.COMPLETED`, `output_artifacts: list[str]=[]`, `output_files`, `model_used`, `duration_ms`, `token_usage_input/output`, `cost_estimate_usd`, `error`.

### 6.4 Fault-tolerance envelope — best-effort, never fatal
Both versions wrap the dispatch+store in `try/except Exception:` that **logs a warning and swallows** (base.py:794-799; wave.py:5520-5525):
```python
except Exception:
    workflow.logger.warning(
        f"Gate pre-review failed for {gate_type_value}; continuing without AI recommendation",
        extra={"gate_id": gate_id})
```
So a flaky pre-review agent OR a `store_gate_pre_review` failure NEVER blocks a reviewer from seeing the gate. **Reproduce: the entire pre-review is advisory and non-blocking.**

### 6.5 `finally` — ready-for-review flip (BASE ONLY)
The **base** version has a `finally` (base.py:800-807) that, guarded by `workflow.patched("mark-gate-ready-for-review-v1")`, executes the `mark_gate_ready_for_review` activity (`start_to_close_timeout=30s`, `retry=transient`). **⚠ GOTCHA:** the **wave-rationalization** inlined copy does NOT have this `finally` — its caller is responsible for flipping the gate to `ready_for_review` separately (wave.py:5451-5453 docstring). This is a deliberate divergence; do not add the flip to the wave copy.

### 6.6 Patch gates at call sites
Callers wrap the dispatch behind `workflow.patched("<line>-gate-pre-review-v1")` markers (e.g. `modernization-gate-pre-review-v1` modernization.py:844/1150/1771; `wave-rationalization-gate-pre-review-v1` wave_rationalization.py:2157/2889). These are Temporal determinism patch markers so existing in-flight histories don't replay the newly-added dispatch. Preserve them (Phase 3 workflow concern; noted here for completeness).

---

## 7. Test-pinned invariants (must hold in a rebuild) — `temporal/tests/test_gate_pre_review.py`
- `82/100` → confidence 82; `**APPROVE**` → "APPROVE"; `**LIKELY REJECT**` → "LIKELY REJECT".
- Summary captures "discovery passes completed…" first paragraph.
- score_breakdown["completeness"] = {score:85, weight:0.3}; Notes-column table → weight 0.0, score preserved.
- 2 flags from SAMPLE (WARNING+INFO); BLOCKER extracted from reject sample.
- `full_markdown` == verbatim input.
- empty `""` → all defaults; garbage prose → rec `""`, score `0`.
- `APPROVE — Confidence: 88/100` (no bold) → "APPROVE", 88.
- `:white_check_mark: **APPROVE** — Confidence: **91/100**` → "APPROVE", 91.
- `## Recommendation\n\n:warning: **REVIEW THOROUGHLY** — Confidence: **62/100**` → "REVIEW THOROUGHLY", 62.
- unstructured "…about 75 out of 100…" → confidence 75.
- mixed-case `Approve — Confidence: 80/100` → "APPROVE", 80.
- Workflow: must use `output_artifacts[0]`, `AgentTaskResult` has no `.output`.
