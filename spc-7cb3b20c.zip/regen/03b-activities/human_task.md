# Activity Group Spec — human-task (paired-work) dispatch

**HEAD:** `7cb3b20c`. **NEW spec** (Phase 6 W1, design §6). Source of truth:
`/Users/pnunna/Documents/GitHub/foundry/temporal/olympus_workflows/activities/human_task_activities.py` (199 lines).

Behavioral-parity target: an engineer with no access to this code must rebuild ONE `@foundry_activity` function — `dispatch_human_task` — plus its two private helpers (`_build_async_database_url`, `_human_task_session`) so it behaves identically: same validation order + raised `ValueError`s, same single `INSERT INTO agent_task` (column-by-column), same JSONB handling, same per-call `AsyncSession` lifecycle.

**Cite path** = `temporal/olympus_workflows/activities/human_task_activities.py` unless noted. Registered in `temporal/olympus_workflows/worker.py` (import `:86`, registration `:241`, with the explanatory comment at `:237-238`: "the delegate-vs-internal trigger; dispatch_human_task creates …").

> **What this activity is (docstring `:1-22`):** the delegated-bundle stack (`bundle_activities.py`) delegates a whole gate-packet / line-step deliverable to a *pool* of portfolio members who claim it. A **human-task** is finer-grained: it assigns ONE specific skill execution to ONE named human (optionally a human-with-local-agent pair). The row lands in `agent_task` with `actor_kind ∈ {human, human_with_agent}` and surfaces in `GET /api/v1/me/tasks` for that user. ⚠️ **No code path created human / human_with_agent rows before this activity** — `dispatch_agent_task` always writes `actor_kind='olympus_agent'`.
>
> Migration **050** (`capability_system_grain`) added the `actor_kind` / `human_user_id` / `local_agent_descriptor` columns + the DB CHECK constraints; migration **044** made `application_id` nullable and added the wave-scoped XOR constraint.

⚠️ **No Temporal workflow currently calls `dispatch_human_task`** (grep of `workflows/` finds none) — it is the paired-work primitive registered on the worker, invoked out-of-band / via the human-task API surface. Reproduce it as a standalone activity; do not assume a calling workflow's retry policy.

---

## 0. The `@foundry_activity` decorator (applies to the one activity here)

`dispatch_human_task` is decorated:
```python
@foundry_activity(config=ActivityConfig(enable_observability=True))
```
imported `from foundry_temporal.activities import ActivityConfig, foundry_activity` (`:35`). **NOT** plain `@activity.defn`. Reproduce the wrapper exactly (`foundry_temporal/activities.py:107-165`):
- Wraps `func` in `async def wrapper` with `@activity.defn(name=None)` + `@wraps`; `name=None` ⇒ registered Temporal name == `dispatch_human_task`.
- `ActivityConfig` passes only `enable_observability=True` (default). Others default: `retry_policy=None`, all timeouts `None`, **`enable_error_wrapping=True`**, `log_inputs/outputs=False`. No decorator-level timeout/retry — the caller sets those.
- **Error wrapping:** on exception out of `func`: `isinstance(error, (WorkflowError, ApplicationError))` → re-raise unchanged; elif `_is_retryable_error(error)` → `RetryableError(...)`; else → `NonRetryableError(...)`. `_is_retryable_error` matches the lowercased `str(type(error))` against `timeout/connection/network/temporary/unavailable/overload/busy/throttle/rate_limit`.
- ⚠️ **The three `ValueError`s this activity raises (§3) are NOT `WorkflowError`/`ApplicationError`**, and `str(type(ValueError))` contains none of the retryable tokens → the decorator wraps them as **`NonRetryableError`** ("Non-retryable error in dispatch_human_task: …"). So a bad `actor_kind` / missing `human_user_id` / app-wave XOR violation surfaces as a non-retryable activity failure (the caller's retry policy will not retry). Reproduce this: those are intentionally non-retryable validation failures, distinct from a DB transient (which would match `connection`/`timeout` → retryable).

---

## 1. Module imports & module constant (`:24-46`)
```python
from __future__ import annotations
import json, logging, os, uuid
from collections.abc import AsyncGenerator
from contextlib import asynccontextmanager
from datetime import datetime, timezone
from urllib.parse import quote_plus
from foundry_temporal.activities import ActivityConfig, foundry_activity
from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker, create_async_engine
logger = logging.getLogger(__name__)

_VALID_HUMAN_ACTOR_KINDS = frozenset({"human", "human_with_agent"})   # :46
```
⚠️ `_VALID_HUMAN_ACTOR_KINDS` excludes `"olympus_agent"` — this activity ONLY creates human/human_with_agent rows (the agent path is `dispatch_agent_task`). ⚠️ Uses **SQLAlchemy async** (`AsyncSession` + `text()` raw SQL), NOT `asyncpg` directly — different from `agent_dispatch.py` / `line_transitions.py` (which use raw `asyncpg`). It mirrors `bundle_activities.py`'s session approach.

## 2. Helpers

### 2.1 `_build_async_database_url() -> str` (`:49-62`)
Composes a `postgresql+asyncpg://` URL from the `DATABASE_*` component env vars (mirrors `bundle_activities._build_async_database_url` so the worker never reads a monolithic `DATABASE_URL`):
```python
host = os.environ.get("DATABASE_HOST", "localhost")
port = os.environ.get("DATABASE_PORT", "5432")
name = os.environ.get("DATABASE_NAME", "olympus")
user = os.environ.get("DATABASE_USER", "olympus")
password = os.environ.get("DATABASE_PASSWORD", "olympus")
encoded = quote_plus(password)
return f"postgresql+asyncpg://{user}:{encoded}@{host}:{port}/{name}"
```
⚠️ Password is **URL-encoded** with `quote_plus` (database-connection-string-composition rule). ⚠️ Driver is `postgresql+asyncpg` (SQLAlchemy async dialect), NOT the bare `postgresql://` DSN used by the raw-asyncpg activities. Defaults: `olympus:olympus@localhost:5432/olympus`.

### 2.2 `_human_task_session()` — async context manager (`:65-81`)
```python
@asynccontextmanager
async def _human_task_session() -> AsyncGenerator[AsyncSession, None]:
    engine = create_async_engine(
        _build_async_database_url(),
        pool_pre_ping=True, pool_recycle=300, pool_timeout=30,
        pool_size=2, max_overflow=2,
    )
    factory = async_sessionmaker(engine, expire_on_commit=False)
    try:
        async with factory() as session:
            yield session
    finally:
        await engine.dispose()
```
⚠️ **A fresh engine is created AND disposed per activity invocation** (identical to `bundle_activities._bundle_session`). The pool settings (`pool_size=2, max_overflow=2, pool_recycle=300, pool_timeout=30, pool_pre_ping=True`) exist but the engine is torn down immediately after the single statement — pooling doesn't span the activity boundary; the settings are inherited-by-convention. `expire_on_commit=False` keeps attributes readable after commit. The `async with` + `finally: await engine.dispose()` guarantee no session/engine leak even on exception.

## 3. Activity: `dispatch_human_task` (`:84-199`)
```python
@foundry_activity(config=ActivityConfig(enable_observability=True))
async def dispatch_human_task(
    task_type: str,
    app_id: str | None,
    wave_id: str | None,
    skill_id: str,
    human_user_id: str,
    actor_kind: str,
    local_agent_descriptor: dict | None,
    input_artifacts: list[str],
    portfolio_id: str,
) -> str:
```
⚠️ **Positional args (NOT a dataclass input)** — 9 parameters, order-significant. Returns the new `agent_task` id **as a string** (so it round-trips through Temporal's payload layer; `uuid.UUID` is not natively serialisable).

### 3.1 Arg semantics (docstring `:101-119`)
- `task_type` — e.g. `"modernization-compliance-review"`.
- `app_id` / `wave_id` — exactly one must be set (the `agent_task_application_or_wave_ck` constraint enforces XOR).
- `skill_id` — the single skill the human is asked to run (written to BOTH `skill_id` AND nothing else; see SQL).
- `human_user_id` — REQUIRED (DB check refuses a human row without an identity).
- `actor_kind` — `'human'` or `'human_with_agent'`.
- `local_agent_descriptor` — `{tool, version, model}` when the human pairs with a local agent; persisted as JSONB. Only meaningful for `human_with_agent`.
- `input_artifacts` — read-only refs handed to the human as starting context (stored in `input_artifact_refs` JSONB).
- `portfolio_id` — recorded for observability (the log `extra`) ONLY; the row is scoped by app/wave, portfolio is derived from the join. ⚠️ `portfolio_id` is NOT written to any column — it appears only in the structured log.

### 3.2 Validation (control flow, in EXACT order — `:121-136`)
1. `actor_kind = (actor_kind or "").strip()` (`:121`). ⚠️ Normalize first (None→`""`, trim whitespace).
2. **Actor-kind gate (`:122-126`):** `if actor_kind not in _VALID_HUMAN_ACTOR_KINDS:` → `raise ValueError(f"dispatch_human_task actor_kind must be one of {sorted(_VALID_HUMAN_ACTOR_KINDS)}; got {actor_kind!r}")`. ⚠️ `sorted(...)` → `['human', 'human_with_agent']` in the message.
3. **Identity gate (`:127-131`):** `if not human_user_id or not str(human_user_id).strip():` → `raise ValueError(f"dispatch_human_task requires a non-empty human_user_id for actor_kind={actor_kind!r}")`. (Belt-and-suspenders over the `agent_task_actor_kind_human_id_chk` DB constraint.)
4. **App/Wave XOR gate (`:132-136`):** `if bool(app_id) == bool(wave_id):` → `raise ValueError(f"dispatch_human_task requires exactly one of app_id / wave_id; got app_id={app_id!r}, wave_id={wave_id!r}")`. ⚠️ `bool(app_id) == bool(wave_id)` is True when BOTH set OR BOTH empty → rejects both cases (mirrors `_insert_agent_task_row` and `dispatch_delegated_bundle`). Validated early so callers get a readable `ValueError` instead of an asyncpg constraint trace.

⚠️ All three raise BEFORE any DB connection is opened → no partial state. Each is a bare `ValueError` → decorator wraps **NonRetryable** (§0).

### 3.3 Row preparation (`:138-152`)
- `application_id_uuid = uuid.UUID(app_id) if app_id else None` (`:138`). `wave_id_uuid = uuid.UUID(wave_id) if wave_id else None` (`:139`). ⚠️ A malformed UUID string here raises `ValueError` from `uuid.UUID(...)` → also NonRetryable-wrapped. Exactly one is non-None (guaranteed by the XOR gate).
- **Descriptor normalization (`:144-148`):** `descriptor_json: str | None = None`; `if actor_kind == "human_with_agent" and isinstance(local_agent_descriptor, dict): descriptor_json = json.dumps(local_agent_descriptor)`. ⚠️ **`human` (plain) ALWAYS gets `descriptor_json = None`** even if a descriptor was passed (mirrors the human_paired_agent service's structural rule: a plain human carries no local-agent descriptor). A non-dict descriptor for `human_with_agent` also stays `None`.
- `refs_json = json.dumps(list(input_artifacts or []))` (`:150`). ⚠️ `input_artifacts or []` tolerates `None`; coerced to a list then JSON-dumped.
- `task_id = uuid.uuid4()` (`:151`). `dispatched_at = datetime.now(timezone.utc)` (`:152`).

### 3.4 The INSERT (`:154-184`) — single statement inside one session
```python
async with _human_task_session() as db:
    await db.execute(
        text(
            """
            INSERT INTO agent_task (
                id, task_type, application_id, wave_id, skill_id,
                status, actor_kind, human_user_id,
                local_agent_descriptor, input_artifact_refs,
                dispatched_at
            ) VALUES (
                :id, :task_type, :application_id, :wave_id, :skill_id,
                'queued', :actor_kind, :human_user_id,
                CAST(:descriptor AS JSONB), CAST(:refs AS JSONB),
                :dispatched_at
            )
            """
        ),
        {
            "id": task_id,
            "task_type": task_type,
            "application_id": application_id_uuid,
            "wave_id": wave_id_uuid,
            "skill_id": skill_id,
            "actor_kind": actor_kind,
            "human_user_id": human_user_id,
            "descriptor": descriptor_json,
            "refs": refs_json,
            "dispatched_at": dispatched_at,
        },
    )
    await db.commit()
```
⚠️ **`status` is the literal `'queued'`** in the VALUES list (NOT a bind param). ⚠️ **`local_agent_descriptor` / `input_artifact_refs` use `CAST(:descriptor AS JSONB)` / `CAST(:refs AS JSONB)`** — the params are JSON strings (or `None` for descriptor) cast to JSONB by Postgres. ⚠️ Bind params use SQLAlchemy `:name` style with `text()` (NOT asyncpg `$1`). ⚠️ **Explicit `await db.commit()`** — the `async_sessionmaker` session does not autocommit; the commit is required for the row to persist. The engine is disposed in `_human_task_session`'s `finally` AFTER the `async with db` block exits (post-commit).

⚠️ **DB-error behavior:** there is NO try/except around the INSERT in this activity (unlike `_insert_agent_task_row` which swallows). A constraint violation (e.g. the `agent_task_actor_kind_human_id_chk` or `agent_task_application_or_wave_ck` if validation were somehow bypassed) or a connection error propagates out of the activity → `@foundry_activity` wraps it (asyncpg/SQLAlchemy connection-error type names containing `connection`/`timeout` → RetryableError; a constraint `IntegrityError` type name has no retryable token → NonRetryableError). Persistence here is NOT best-effort — a failed insert fails the activity.

### 3.5 Structured log + return (`:186-199`)
```python
logger.info(
    "human-task.dispatched",
    extra={"task_id": str(task_id), "task_type": task_type, "skill_id": skill_id,
           "actor_kind": actor_kind, "human_user_id": human_user_id,
           "app_id": app_id, "wave_id": wave_id, "portfolio_id": portfolio_id},
)
return str(task_id)
```
⚠️ Returns `str(task_id)` (the new `agent_task.id`). `portfolio_id` appears ONLY in this log's `extra` (never persisted). The log fires only AFTER a successful commit (it is after the `async with` block).

## 4. Column-by-column mapping — `agent_task` INSERT

Target table `agent_task` (base migration 003; `actor_kind`/`human_user_id`/`local_agent_descriptor` from migration **050**; `wave_id`-nullable + XOR from migration **044**):

| Param / literal | `agent_task` column | Type / constraint | Value form |
|---|---|---|---|
| `uuid.uuid4()` | `id` | UUID PK | bound `:id` (UUID object) |
| `task_type` | `task_type` | (varchar) | bound `:task_type` |
| `uuid.UUID(app_id)` or None | `application_id` | UUID NULL, FK application (migration 044 made nullable) | bound `:application_id`; one of app/wave is NULL (XOR ck) |
| `uuid.UUID(wave_id)` or None | `wave_id` | UUID NULL, FK wave ON DELETE CASCADE (migration 044) | bound `:wave_id` |
| `skill_id` | `skill_id` | (varchar) | bound `:skill_id` |
| literal | `status` | `task_status_enum` (or varchar) | `'queued'` (NOT a bind) |
| `actor_kind` (validated ∈ {human, human_with_agent}) | `actor_kind` | VARCHAR(32) NOT NULL DEFAULT 'olympus_agent'; CHECK `agent_task_actor_kind_chk` IN ('olympus_agent','human','human_with_agent') | bound `:actor_kind` |
| `human_user_id` (validated non-empty) | `human_user_id` | VARCHAR(255) NULL; CHECK `agent_task_actor_kind_human_id_chk` (human/human_with_agent ⇒ NOT NULL) | bound `:human_user_id` |
| `json.dumps(descriptor)` for human_with_agent w/ dict, else None | `local_agent_descriptor` | JSONB NULL | `CAST(:descriptor AS JSONB)`; NULL for plain `human` |
| `json.dumps(list(input_artifacts or []))` | `input_artifact_refs` | JSONB | `CAST(:refs AS JSONB)` |
| `datetime.now(timezone.utc)` | `dispatched_at` | TIMESTAMPTZ | bound `:dispatched_at` |
| — (not set by this INSERT) | `model_requested`, `model_used`, `module_name`, `completed_at`, `duration_ms`, `output_artifact_ref`, `token_usage`, `cost_estimate`, `last_error`, … | various NULL/default | left at schema defaults |
| `portfolio_id` (param) | — (NOT a column) | — | log `extra` only |

⚠️ DB CHECK constraints the row must satisfy (migration 050 `:648-660`, migration 044 `:70-73`):
- `agent_task_actor_kind_chk`: `actor_kind IN ('olympus_agent','human','human_with_agent')` — satisfied (validated `∈ {human, human_with_agent}`).
- `agent_task_actor_kind_human_id_chk`: `(actor_kind='olympus_agent' AND human_user_id IS NULL) OR (actor_kind IN ('human','human_with_agent') AND human_user_id IS NOT NULL)` — satisfied (human row + non-empty `human_user_id`).
- `agent_task_application_or_wave_ck`: `(application_id IS NOT NULL AND wave_id IS NULL) OR (application_id IS NULL AND wave_id IS NOT NULL)` — satisfied (XOR gate).

## 5. Errors / retries / idempotency
- **Three validation `ValueError`s** (bad actor_kind / missing human_user_id / app-wave XOR), plus a `uuid.UUID()` `ValueError` on a malformed app/wave id — all raise BEFORE any DB work and are wrapped **NonRetryable** by `@foundry_activity`.
- **DB errors propagate (NOT swallowed):** a connection blip → RetryableError; an `IntegrityError`/constraint violation → NonRetryableError (per type-name classification). Contrast `dispatch_agent_task`'s `_insert_agent_task_row`, which swallows DB errors (observability-only); here the insert is the activity's whole job, so a failure fails the activity.
- **NOT idempotent:** each invocation mints a fresh `uuid.uuid4()` and INSERTs a new row (no dedup key, no ON CONFLICT). A Temporal retry of a successfully-committed-but-crashed-before-return attempt would create a SECOND `agent_task` row. The activity is meant to be dispatched once per human-task assignment; callers should not attach an aggressive retry policy expecting dedup.
- **Single statement + explicit commit** in one per-call `AsyncSession`; engine disposed in `finally`. No transaction wrapper beyond the implicit one of `db.commit()` over the single INSERT (trivially atomic).

## 6. CONSOLIDATED GOTCHAS
1. **SQLAlchemy async, not raw asyncpg.** `postgresql+asyncpg://` URL, `text()` raw SQL with `:name` binds, explicit `await db.commit()`, fresh engine per call disposed in `finally`. Mirrors `bundle_activities.py`, diverges from `agent_dispatch.py`/`line_transitions.py`.
2. **Validation order is load-bearing + all pre-DB:** strip actor_kind → actor_kind gate → human_user_id gate → app/wave XOR gate → parse UUIDs. All raise `ValueError` → NonRetryable.
3. **Plain `human` never persists a `local_agent_descriptor`** (forced to NULL) even if one is passed; only `human_with_agent` + dict yields a JSONB descriptor.
4. **`status` is literal `'queued'`; `portfolio_id` is log-only** (not a column). The row surfaces in `GET /api/v1/me/tasks` for `human_user_id`.
5. **Insert is NOT best-effort** (no try/except swallow) and NOT idempotent (fresh uuid each call). DB failure fails the activity; retries duplicate rows.
6. **DB constraints (migration 050 + 044)** enforce the same three rules the Python validation checks — the validation exists to give readable errors, the constraints are the storage-layer backstop.

## 7. Undetermined / cross-file
- The full `agent_task` DDL (base columns, `task_status_enum` membership for `'queued'`, the FK targets) lives in migration 003 (extended by 027/044/050) — the human-specific columns + constraints are migration 050 (`db/alembic/versions/050_capability_system_grain.py:605-660`) and the wave XOR is migration 044 (`db/alembic/versions/044_agent_task_wave_scoped.py:70-73`). Types here are quoted from those migrations.
- The `GET /api/v1/me/tasks` read path (how the dispatched row is surfaced to the human, the human_paired_agent service's structural rule referenced in the descriptor normalization) is owned by the olympus-api layer, summarized here only as the consumer of the row.
