# Activity Group Spec — DevSecOps baseline (profile resolve + validate)

**HEAD:** `7cb3b20c`. **NEW spec** (Phase 6 W11). Source of truth:
- `/Users/pnunna/Documents/GitHub/foundry/temporal/olympus_workflows/activities/devsecops_validation.py` (272 lines) — `validate_devsecops_baseline` + pure core `validate_baseline` + 4 module helpers.
- `/Users/pnunna/Documents/GitHub/foundry/temporal/olympus_workflows/activities/profile_devsecops.py` (167 lines) — `resolve_devsecops_profile` + pure core `resolve_baseline_params` + 3 module helpers.

Behavioral-parity target: an engineer with no access to this code must rebuild **two** `@foundry_activity` functions — `validate_devsecops_baseline` and `resolve_devsecops_profile` — plus their pure cores and private helpers so they behave identically: same profile-param resolution (the 8-key block), same presence + structural validation, same branch/early-return behavior, same G-04c gating signal.

**Cite path** = the respective source file unless noted. Both activities are imported by `temporal/olympus_workflows/workflows/modernization.py` (imports at `:71`, `:87`, dataclasses at `:108`, `:110`) and registered in `temporal/olympus_workflows/worker.py` (imports `:58`/`:112`, registration list `:181-182`). They are also re-exported from `temporal/olympus_workflows/activities/__init__.py` (`:6`, `:21`, `__all__` `:37`, `:39`).

> ⚠️ **Design invariant (NON-NEGOTIABLE, user direction 2026-06-11; both module docstrings):** the **agent GENERATES** the DevSecOps baseline files; these activities **author no content**. `resolve_devsecops_profile` reads the active profile and returns the 8 params (threaded into the generating agent's `context['devsecops_baseline']`). `validate_devsecops_baseline` only *confirms* the agent's output is complete + structurally sound. A rebuild that makes either activity write/template baseline content diverges.

---

## 0. The `@foundry_activity` decorator (applies to BOTH activities)

Both activities are decorated EXACTLY:
```python
@foundry_activity(config=ActivityConfig(enable_observability=True))
```
imported `from foundry_temporal.activities import ActivityConfig, foundry_activity` (`devsecops_validation.py:26`, `profile_devsecops.py:27`). This is **NOT** plain `@activity.defn`. Reproduce the wrapper exactly (`foundry_temporal/activities.py:107-165`):

- `foundry_activity(config=None, name=None, **activity_kwargs)` returns a decorator that wraps `func` in `async def wrapper`, applying `@activity.defn(name=name, **activity_kwargs)` over `@wraps(func)`. `name=None` ⇒ Temporal registers under the function name (`validate_devsecops_baseline` / `resolve_devsecops_profile`).
- `ActivityConfig` here passes only `enable_observability=True` (already the default). All other fields default: `retry_policy=None`, all timeouts `None`, **`enable_error_wrapping=True`**, `log_inputs=False`, `log_outputs=False`. ⚠️ No timeout/retry on the decorator — they come from the workflow's `execute_activity(...)` call (see §4).
- **Observability:** entry `info("Activity {name} starting", extra={"inputs": None})`; success `info("Activity {name} completed", extra={"outputs": None})`; exception `error("Activity {name} failed: {error}")`.
- **Error wrapping (`enable_error_wrapping=True`):** on any exception out of `func`:
  - `isinstance(error, (WorkflowError, ApplicationError))` → re-raise unchanged.
  - elif `_is_retryable_error(error)` → `raise RetryableError(f"Retryable error in {name}: {error}") from error`.
  - else → `raise NonRetryableError(f"Non-retryable error in {name}: {error}") from error`.
  - `_is_retryable_error` (`activities.py:168-183`): lowercases `str(type(error))`, True iff it contains any of `timeout, connection, network, temporary, unavailable, overload, busy, throttle, rate_limit` (matches the TYPE repr, not the message).

⚠️ **Neither activity raises its own typed errors.** `validate_baseline` and `resolve_baseline_params` are written to NEVER raise on bad input (best-effort: malformed files become `errors`/`missing` entries or fall back to defaults). So the decorator's wrapping path is exercised only by truly unexpected exceptions (e.g. an `ImportError` of the activity's own deps), which a rebuild should not normally hit. Both activities additionally accept a `dict` input and re-hydrate the dataclass (`if isinstance(input, dict): input = X(**input)`) so Temporal payload round-tripping is tolerated.

---

# PART A — `resolve_devsecops_profile` (`profile_devsecops.py`)

Resolves the active client profile's DevSecOps baseline parameters: the **8-key block** `sast_tool / sbom_required / container_base / license / target_cloud / primary_ecosystem / iac / cicd`. Profile-driven, NO hardcoded FAA (composes with W10). Missing fields fall back to platform defaults (`specifications/phase-5/devsecops-baseline.md` §6).

## A.1 Module docstring / imports (`:1-36`)
`from __future__ import annotations`; `import logging, os`; `from pathlib import Path`; `import yaml`; `from foundry_temporal.activities import ActivityConfig, foundry_activity`; `from olympus_workflows.types import ResolveDevSecOpsProfileInput, ResolveDevSecOpsProfileResult` (`:29-32`). `__all__ = ["resolve_devsecops_profile", "resolve_baseline_params"]` (`:34`). `logger = logging.getLogger(__name__)` (`:36`).

## A.2 Platform defaults `_DEFAULTS` (`:42-51`) — REPRODUCE EXACTLY (order + values)
```python
_DEFAULTS: dict[str, object] = {
    "sast_tool": "codeql",
    "sbom_required": True,
    "container_base": "distroless",
    "license": "",            # ⚠️ NO platform default — profile MUST pick one; empty = "no license file"
    "target_cloud": "aws",
    "primary_ecosystem": "python",
    "iac": "terraform",
    "cicd": "github-actions",
}
```
⚠️ These 8 keys ARE the contract surface. `license` defaults to the empty string deliberately (the template/agent treats `""` as "no LICENSE file" rather than inventing one). `sbom_required` is the only `bool`; everything else is a `str`.

## A.3 Input dataclass — `ResolveDevSecOpsProfileInput` (`types.py:736-740`)
```python
@dataclass
class ResolveDevSecOpsProfileInput:
    profile_id: str = ""
```
The workflow passes `profile_id=input.portfolio_id or ""` (modernization.py:1740). ⚠️ Semantic note: the field is named `profile_id` and the resolver treats it as a profile directory name under `profiles/`.

## A.4 Output dataclass — `ResolveDevSecOpsProfileResult` (`types.py:742-761`, EVERY field)
```python
@dataclass
class ResolveDevSecOpsProfileResult:
    profile_id: str = ""
    sast_tool: str = "codeql"
    sbom_required: bool = True
    container_base: str = "distroless"
    license: str = ""
    target_cloud: str = "aws"
    primary_ecosystem: str = "python"
    iac: str = "terraform"
    cicd: str = "github-actions"
```
(The dataclass defaults mirror `_DEFAULTS` exactly; the activity always fills every field from the resolved params dict — see A.8.)

## A.5 Helper: `_profile_root_from_env() -> Path | None` (`:54-68`)
Resolves the ACTIVE profile root (mirrors `context_priors._profile_root_from_env`):
1. `env = os.environ.get("OLYMPUS_PROFILE_ROOT")`; if `env` truthy → `p = Path(env).resolve()`; `if p.is_dir(): return p`.
2. Else `repo_root = Path(__file__).resolve().parents[3]`; `candidate = repo_root / "profiles" / "faa"`; return `candidate if candidate.is_dir() else None`.
⚠️ The repo-relative fallback is hardcoded `profiles/faa` (local-dev convenience). `parents[3]` walks up from `…/temporal/olympus_workflows/activities/profile_devsecops.py` to the repo root.

## A.6 Helper: `_profile_root_for(profile_id: str | None) -> Path | None` (`:71-84`)
Resolves a profile root **by id** when given, else the active profile:
1. **If `profile_id` truthy:**
   - `explicit = os.environ.get("OLYMPUS_PROFILES_DIR")`; `roots: list[Path] = []`.
   - if `explicit` → `roots.append(Path(explicit))`.
   - `repo_root = Path(__file__).resolve().parents[3]`; `roots.append(repo_root / "profiles")`.
   - for `base in roots`: `candidate = base / profile_id`; `if candidate.is_dir(): return candidate`. (First matching dir wins; `OLYMPUS_PROFILES_DIR` checked before the repo-relative `profiles/`.)
2. **Falls through** to `return _profile_root_from_env()` — i.e. an empty/None `profile_id`, OR a non-empty id whose directory does NOT exist under any root, both resolve to the ACTIVE profile (env `OLYMPUS_PROFILE_ROOT` or `profiles/faa`). ⚠️ Reproduce this fall-through: a bogus `profile_id` does NOT yield `None`/error — it silently resolves to the active profile.

## A.7 Helper: `_load_yaml(path: Path) -> dict` (`:87-94`)
1. `if not path.is_file(): return {}`.
2. `try: return yaml.safe_load(path.read_text(encoding="utf-8")) or {}` (⚠️ `or {}` coerces a YAML doc that parses to `None`/empty into `{}`).
3. `except yaml.YAMLError as exc: logger.warning("profile_devsecops: %s unparseable: %s", path, exc); return {}`. ⚠️ Only `YAMLError` is caught — an `OSError` from `read_text` would propagate (then be wrapped by the decorator), but the `is_file()` guard makes that unlikely.

## A.8 Pure core: `resolve_baseline_params(profile_id: str | None = None) -> dict[str, object]` (`:97-141`) — THE RESOLVER
Pure (no Temporal context), unit-testable. Exact control flow:
1. `params: dict[str, object] = dict(_DEFAULTS)` — start with a COPY of all 8 defaults.
2. `root = _profile_root_for(profile_id)`. **If `root is None`:** `logger.info("profile_devsecops: no profile root resolved; using defaults")`; **`return params`** (pure defaults — early return, no file reads).
3. `profile_doc = _load_yaml(root / "profile.yaml")`.
4. **Profile `devsecops:` block extraction (`:114-122`):** `devsecops = {}`; `profile_block = profile_doc.get("profile")`; `if isinstance(profile_block, dict): maybe = profile_block.get("devsecops"); if isinstance(maybe, dict): devsecops = maybe`. Then **for each of the 8 `_DEFAULTS` keys:** `if key in devsecops and devsecops[key] is not None: params[key] = devsecops[key]`. ⚠️ A key present-but-`None` in the block does NOT override the default (the `is not None` guard). The override reads `profile.yaml` → `profile.devsecops.<key>`.
5. **iac/cicd mirror from `technology.yaml` (`:124-134`):** `tech_doc = _load_yaml(root / "technology.yaml")`; `tech = tech_doc.get("technology")`; `if isinstance(tech, dict): infra = tech.get("infrastructure"); if isinstance(infra, dict):`
   - `if "iac" not in devsecops and infra.get("iac"): params["iac"] = str(infra["iac"]).strip().lower()`.
   - `if "cicd" not in devsecops and infra.get("cicd"): params["cicd"] = str(infra["cicd"]).strip().lower().replace(" ", "-")`.
   - ⚠️ **Precedence:** the `devsecops:` block wins. `technology.infrastructure.{iac,cicd}` is consulted ONLY when the profile's `devsecops` block did NOT set that key (`"iac" not in devsecops`). `cicd` additionally lowercases AND replaces spaces with hyphens (e.g. `"GitHub Actions"` → `"github-actions"`); `iac` only strips+lowercases.
6. **Casing normalization (`:136-139`):** `for key in ("sast_tool", "container_base", "target_cloud", "primary_ecosystem"): if isinstance(params.get(key), str): params[key] = params[key].strip().lower()`. ⚠️ Only these 4 keys are normalized here (so a profile `sast_tool: CodeQL` → `"codeql"`). `license`, `iac`, `cicd` are NOT in this loop (`iac`/`cicd` were already normalized in step 5 IF sourced from technology.yaml; a `devsecops:`-block `iac`/`cicd` value is passed through verbatim — preserve this asymmetry). `sbom_required` is a bool — untouched.
7. `return params`.

## A.9 Activity: `resolve_devsecops_profile` (`:144-167`)
```python
@foundry_activity(config=ActivityConfig(enable_observability=True))
async def resolve_devsecops_profile(input: ResolveDevSecOpsProfileInput) -> ResolveDevSecOpsProfileResult:
```
1. `if isinstance(input, dict): input = ResolveDevSecOpsProfileInput(**input)` (Temporal payload tolerance).
2. `params = resolve_baseline_params(input.profile_id or None)` — ⚠️ `input.profile_id or None` converts the empty-string default into `None` so the resolver takes the active-profile path.
3. **Return** the result, coercing every param to its declared type:
```python
return ResolveDevSecOpsProfileResult(
    profile_id=input.profile_id,
    sast_tool=str(params["sast_tool"]),
    sbom_required=bool(params["sbom_required"]),
    container_base=str(params["container_base"]),
    license=str(params["license"]),
    target_cloud=str(params["target_cloud"]),
    primary_ecosystem=str(params["primary_ecosystem"]),
    iac=str(params["iac"]),
    cicd=str(params["cicd"]),
)
```
⚠️ `profile_id` is echoed from the INPUT (not from the resolved root). The coercions (`str(...)`, `bool(...)`) are defensive — a profile that put a non-string value in its `devsecops:` block gets stringified here.

## A.10 `resolve_devsecops_profile` — errors / retries / idempotency
- **Never raises on data:** missing profile root → defaults; unparseable YAML → `_load_yaml` returns `{}` → defaults for that file. The only escape is an unexpected exception (decorator-wrapped non-retryable). **No DB, no network, no Temporal context** — pure file reads.
- **Idempotent + deterministic** for a fixed filesystem: same profile → same 8 params. No side effects.

---

# PART B — `validate_devsecops_baseline` (`devsecops_validation.py`)

Deterministic confirmation that the agent-generated baseline is **complete + structurally sound**. Its boolean `passed` gates **G-04c** in `ModernizationWorkflow` (replacing the old `xfail` regression test). Runs as an ACTIVITY (not workflow code) because it inspects committed file content.

## B.1 Module docstring / imports (`:1-49`)
`import json, logging`; `from pathlib import Path`; `import yaml`; `from foundry_temporal.activities import ActivityConfig, foundry_activity`; `from olympus_workflows.devsecops_contract import REQUIRED_BASELINE_FILES` (`:28-30`); `from olympus_workflows.types import ValidateDevSecOpsBaselineInput, ValidateDevSecOpsBaselineResult` (`:31-34`). `logger` (`:36`).

### `REQUIRED_CI_JOBS` (`:41-49`) — REPRODUCE EXACTLY (the 7 CI jobs)
```python
REQUIRED_CI_JOBS: tuple[str, ...] = ("lint", "test", "build", "sast", "sca", "secrets-scan", "image-scan")
```
⚠️ Stable job names so branch-protection required-checks don't vary per profile. SAST is carried INLINE as a single `sast` job in `ci.yml` (branches on the profile's `sast_tool` internally) — there is NO separate `codeql.yml`.

### `REQUIRED_BASELINE_FILES` (imported from `olympus_workflows/devsecops_contract.py:48-64`) — the 9 required repo-root paths
```python
(".github/workflows/ci.yml", ".github/dependabot.yml", ".github/branch-protection.yml",
 ".github/CODEOWNERS", "Dockerfile", "deploy/helm/Chart.yaml", "infra/terraform/main.tf",
 "SECURITY.md", "README.md")
```
⚠️ Every one of these 9 must be present (after `_normalize`) in the committed set or it lands in `missing` → `passed=False`.

## B.2 Input dataclass — `ValidateDevSecOpsBaselineInput` (`types.py:697-715`)
```python
@dataclass
class ValidateDevSecOpsBaselineInput:
    app_id: str
    committed_files: list[tuple[str, str]]       # (repo_path, content) pairs the workflow just committed to the target repo root
    sast_tool: str = "codeql"                     # profile-driven; ci.yml MUST name this job/tool
```
The workflow passes the root-bound subset it committed plus `sast_tool=self._devsecops_params.get("sast_tool", "codeql")` (modernization.py:1944-1949).

## B.3 Output dataclass — `ValidateDevSecOpsBaselineResult` (`types.py:718-732`)
```python
@dataclass
class ValidateDevSecOpsBaselineResult:
    app_id: str
    passed: bool
    missing: list[str] = field(default_factory=list)    # required repo-root files not committed
    errors: list[str] = field(default_factory=list)     # structural failures (malformed ci.yml, missing jobs, bad iac-manifest, …)
    files_checked: int = 0
```
⚠️ `passed = not missing and not errors` — clean pass requires BOTH lists empty.

## B.4 Helper: `_normalize(path: str) -> str` (`:52-58`)
```python
norm = path
while norm.startswith("./"):
    norm = norm[2:]
return norm.lstrip("/")
```
⚠️ Strips leading `./` (repeated) and leading slashes — **but does NOT eat a leading dot** (`.github` stays `.github`; only `./` prefixes are stripped, via the `startswith("./")` loop, then `lstrip("/")`). Applied to BOTH the committed paths (building the `by_path` index) and the `REQUIRED_BASELINE_FILES` entries before comparison, so matching is prefix-normalized on both sides.

## B.5 Helper: `_check_ci_yaml(content, sast_tool, errors) -> None` (`:61-105`) — the CI structural check
Appends to `errors` (mutates in place); never raises. Control flow:
1. `try: doc = yaml.safe_load(content)` `except yaml.YAMLError as exc:` → append `f".github/workflows/ci.yml is not valid YAML: {exc}"`; **return**.
2. `if not isinstance(doc, dict):` → append `".github/workflows/ci.yml did not parse to a mapping"`; **return**.
3. `jobs = doc.get("jobs")`; `if not isinstance(jobs, dict):` → append `".github/workflows/ci.yml has no 'jobs' mapping"`; **return**.
4. `missing_jobs = [j for j in REQUIRED_CI_JOBS if j not in jobs]`; `if missing_jobs:` → append `"ci.yml missing required job(s): " + ", ".join(missing_jobs)`. (⚠️ does NOT return — continues to the SAST-tool + placeholder checks.)
5. **SAST-tool presence:** `if sast_tool and sast_tool.lower() not in content.lower():` → append `f"ci.yml does not reference the profile SAST tool {sast_tool!r}; the SAST job may be mis-rendered"`. ⚠️ Case-insensitive substring search over the WHOLE rendered `ci.yml` text — catches a profile mis-render (e.g. a semgrep profile rendering a codeql-only pipeline) AND un-rendered `{{sast_tool}}` placeholders (the literal `sast_tool` value won't appear).
6. **Un-rendered mustache placeholder scan (`:99-105`):** iterate `idx in range(len(content) - 1)`; if `content[idx] == "{" and content[idx+1] == "{"`: if `idx == 0 or content[idx-1] != "$"` → append `"ci.yml contains an un-rendered '{{...}}' placeholder"`; **`break`** (one report max). ⚠️ **Deliberately ignores GitHub Actions expressions `${{ ... }}`:** a `{{` immediately preceded by `$` is a legit Actions expression and does NOT trip the check; a bare `{{` (not preceded by `$`, or at index 0) is an un-rendered template placeholder. Reproduce the `idx == 0 or content[idx-1] != "$"` predicate exactly.

## B.6 Helper: `_check_yaml_parses(name, content, errors) -> None` (`:108-115`)
1. `try: doc = yaml.safe_load(content)` `except yaml.YAMLError as exc:` → append `f"{name} is not valid YAML: {exc}"`; return.
2. `if doc is None:` → append `f"{name} parsed to an empty document"`. ⚠️ An empty `dependabot.yml`/`branch-protection.yml` (parses to `None`) is an error.

## B.7 Helper: `_iac_schema_path() -> Path | None` (`:118-133`)
Locates `iac-scaffolding-generator`'s `output.schema.json` by walking up to the repo root (reuses the skill's contract, not a copy):
- `here = Path(__file__).resolve()`; for `parent in (here, *here.parents):` test `parent / "cross-cutting" / "skills" / "iac-scaffolding-generator" / "schemas" / "output.schema.json"`; return the first that `.is_file()`, else `None`.

## B.8 Helper: `_validate_iac_manifest(content, errors) -> None` (`:136-192`) — IaC manifest validation
Validates an `iac-manifest.json` against the skill's `output.schema.json` + the same semantic referential-integrity rules as the skill's `validate_output.py`. Control flow:
1. `try: data = json.loads(content)` `except (ValueError, TypeError) as exc:` → append `f"iac-manifest.json is not valid JSON: {exc}"`; **return**.
2. **Schema check (best-effort, soft):** `schema_path = _iac_schema_path()`; `if schema_path is not None:` → `try: import jsonschema; schema = json.loads(schema_path.read_text(...)); validator = jsonschema.Draft202012Validator(schema); for err in validator.iter_errors(data): errors.append(f"iac-manifest schema: {err.json_path}: {err.message}")`.
   - `except ImportError: logger.warning("jsonschema not installed; skipping IaC schema check")` (⚠️ jsonschema absence is a WARNING, NOT an error — the manifest still passes the schema gate).
   - `except Exception as exc:  # noqa: BLE001 — malformed schema is non-fatal` → `logger.warning("IaC schema validation skipped: %s", exc)`. ⚠️ A broken schema file is swallowed (non-fatal).
3. **Semantic referential-integrity checks (mirror `validate_output.py`, `:160-192`)** — run regardless of schema availability. `stacks/lambdas/routes/event_rules = data.get(<key>, []) if isinstance(data, dict) else []` for keys `stacks`, `lambda_functions`, `api_routes`, `event_rules`.
   - `lambda_names = {fn.get("function_name") for fn in lambdas}`.
   - **Route → Lambda:** for each `route`: `fn_ref = route.get("lambda_function", "")`; `if fn_ref and fn_ref not in lambda_names:` → append `f"iac-manifest route {route.get('method')} {route.get('path')} references unknown Lambda: {fn_ref}"`.
   - **Event rule → Lambda:** for each `rule`: `target = rule.get("target_lambda", "")`; `if target and target not in lambda_names:` → append `f"iac-manifest event rule {rule.get('rule_name')} targets unknown Lambda: {target}"`.
   - **Construct connectivity:** `construct_ids: set[str] = set()`; first pass collects `construct.get("id", "")` over every `stack["constructs"]`; second pass: for each `construct`, for each `ref in construct.get("connects_to", [])`: `if ref not in construct_ids:` → append `f"iac-manifest construct {construct.get('id')} connects_to unknown: {ref}"`.
   ⚠️ All `.get(..., [])` / `isinstance` guards mean a missing/wrong-typed section contributes no errors (best-effort). A reference is only flagged when it is truthy AND unresolved.

## B.9 Pure core: `validate_baseline(input) -> ValidateDevSecOpsBaselineResult` (`:195-242`) — THE VALIDATOR
Pure (no Temporal context), unit-testable; the activity delegates here. Exact control flow:
1. **Build the normalized path index (`:202-204`):** `by_path: dict[str, str] = {_normalize(p): c for p, c in (input.committed_files or [])}`. ⚠️ `input.committed_files or []` tolerates `None`. Later `(path, content)` pairs with duplicate normalized paths → last wins (dict build).
2. `missing: list[str] = []`; `errors: list[str] = []`.
3. **Presence check (`:209-211`):** `for required in REQUIRED_BASELINE_FILES: if _normalize(required) not in by_path: missing.append(required)`. ⚠️ The ORIGINAL (un-normalized) `required` string is appended to `missing`, but the lookup key is normalized.
4. **Structural checks for present + cheap-to-parse files:**
   - `ci = by_path.get(".github/workflows/ci.yml")`; `if ci is not None: _check_ci_yaml(ci, input.sast_tool, errors)`.
   - `dependabot = by_path.get(".github/dependabot.yml")`; `if dependabot is not None: _check_yaml_parses(".github/dependabot.yml", dependabot, errors)`.
   - `branch_protection = by_path.get(".github/branch-protection.yml")`; `if branch_protection is not None: _check_yaml_parses(".github/branch-protection.yml", branch_protection, errors)`.
   ⚠️ These run on the file CONTENT regardless of whether the file was in `missing` (a present-but-malformed ci.yml adds to BOTH a missing-job error and… no — if present it's not in missing; if absent `by_path.get` is `None` → skipped). Net: a file can contribute to `missing` (absent) OR `errors` (present+malformed), not both.
5. **IaC manifest validation (`:231-233`):** `for path, content in by_path.items(): if path.endswith("iac-manifest.json"): _validate_iac_manifest(content, errors)`. ⚠️ Matches on **basename suffix** so the caller may pass either the root path or the namespaced evidence path (`modernization/{app_id}/generate/iac-manifest.json`). The manifest is NOT in `REQUIRED_BASELINE_FILES` (it's committed as namespaced evidence) — it's validated ONLY if present in the passed set.
6. **`passed = not missing and not errors`** (`:235`).
7. `return ValidateDevSecOpsBaselineResult(app_id=input.app_id, passed=passed, missing=missing, errors=errors, files_checked=len(by_path))`.

## B.10 Activity: `validate_devsecops_baseline` (`:245-272`)
```python
@foundry_activity(config=ActivityConfig(enable_observability=True))
async def validate_devsecops_baseline(input: ValidateDevSecOpsBaselineInput) -> ValidateDevSecOpsBaselineResult:
```
1. `if isinstance(input, dict): input = ValidateDevSecOpsBaselineInput(**input)`.
2. `result = validate_baseline(input)`.
3. **Logging branch (`:258-271`):** `if not result.passed: logger.warning("DevSecOps baseline validation failed for app %s: missing=%s errors=%s", input.app_id, result.missing, result.errors)` `else: logger.info("DevSecOps baseline validated for app %s (%d files)", input.app_id, result.files_checked)`.
4. `return result`.
⚠️ The activity is a thin wrapper: it AUTHORS nothing, only logs + returns. The gating decision lives in the workflow.

## B.11 `validate_devsecops_baseline` — errors / retries / idempotency
- **Never raises on data:** every helper appends to `errors` rather than raising; jsonschema/schema problems are warnings. Pure function of `(committed_files, sast_tool)` + the filesystem (only `_iac_schema_path` touches disk, best-effort).
- **Idempotent + deterministic** for a fixed input/filesystem.

---

## 4. WORKFLOW CALL-SITES + G-04c GATING (`modernization.py`, for behavioral parity of the surrounding pipeline)

The two activities bracket the Generate step. Reproduce the call configuration:

### 4.1 `resolve_devsecops_profile` — once per Generate step (`modernization.py:1736-1755`)
```python
if not self._devsecops_params:                      # cached once; reworks reuse
    ds_params = await workflow.execute_activity(
        resolve_devsecops_profile,
        ResolveDevSecOpsProfileInput(profile_id=input.portfolio_id or ""),
        start_to_close_timeout=timedelta(seconds=30),
        retry_policy=RETRY_POLICIES["transient"],
        activity_id=f"resolve-devsecops-{app_id}",
    )
    self._devsecops_params = {
        "sast_tool": ds_params.sast_tool, "sbom_required": ds_params.sbom_required,
        "container_base": ds_params.container_base, "license": ds_params.license,
        "target_cloud": ds_params.target_cloud, "primary_ecosystem": ds_params.primary_ecosystem,
        "iac": ds_params.iac, "cicd": ds_params.cicd,
    }
```
⚠️ `input.portfolio_id` is used as the `profile_id`. The resolved 8-key dict is threaded into the generating agent's dispatch context at `modernization.py:451-452`: `if self._devsecops_params: context["devsecops_baseline"] = dict(self._devsecops_params)`. The agent renders the baseline templates with these values (`code-synthesis` / `tdd-generation` / `iac-scaffolding-generator` SKILL.md bodies read `context['devsecops_baseline']`).

### 4.2 `validate_devsecops_baseline` — after the Generate commit, gating G-04c (`modernization.py:1942-1979`)
```python
baseline_validation = await workflow.execute_activity(
    validate_devsecops_baseline,
    ValidateDevSecOpsBaselineInput(
        app_id=app_id,
        committed_files=list(self._committed_baseline_files),     # set at :2339 from route_generate_file's root-bound subset
        sast_tool=str(self._devsecops_params.get("sast_tool", "codeql")),
    ),
    start_to_close_timeout=timedelta(seconds=60),
    retry_policy=RETRY_POLICIES["transient"],
    activity_id=f"validate-devsecops-{app_id}",
)
if not baseline_validation.passed:
    workflow.logger.warning("G-04c DevSecOps baseline validation failed; reworking Generate", extra={app_id, missing, errors})
    self._g04c_stakeholder_ea_approved = False
    self._g04c_stakeholder_security_approved = False
    self._bump_rework("G-04c")
    if self._rework_count("G-04c") > MAX_REWORK_ITERATIONS:
        self._status = WorkflowStatus.FAILED
        self._current_step = "generate-baseline-incomplete"
        await self._update_app_status(app_id, "modernization_failed", "generate-baseline-incomplete", "Modernization")
        return "failed"
    continue          # ⚠️ loop back, re-run Generate
```
⚠️ **G-04c gating semantics:** a `passed=False` result does NOT immediately fail — it resets the G-04c stakeholder approvals, bumps the rework counter, and `continue`s the `while True` Generate loop to regenerate. Only after `MAX_REWORK_ITERATIONS` exceeded does the workflow terminate FAILED with step `generate-baseline-incomplete`. This is the standing guard that replaced the old xfail regression test. The PR + gate record (G-04c) are created only AFTER a passing validation (`:1982+`).

---

## 5. CONSOLIDATED GOTCHAS
1. **Agent authors, activities confirm.** `resolve_devsecops_profile` reads the profile; `validate_devsecops_baseline` confirms the agent's output. Neither writes baseline content. (NON-NEGOTIABLE design invariant.)
2. **The 8-key block is the contract:** `sast_tool, sbom_required, container_base, license, target_cloud, primary_ecosystem, iac, cicd`. `license` defaults to `""` (no platform default). `sbom_required` is the only bool.
3. **Precedence in `resolve_baseline_params`:** profile `devsecops:` block > `technology.infrastructure.{iac,cicd}` > `_DEFAULTS`. The technology mirror is consulted ONLY for keys absent from the `devsecops:` block. `cicd` from technology gets spaces→hyphens; only 4 keys (`sast_tool/container_base/target_cloud/primary_ecosystem`) get the final lowercase normalization pass.
4. **Bogus `profile_id` ⇒ active profile, not error.** `_profile_root_for` falls through to `_profile_root_from_env()` for an unknown id. `resolve_devsecops_profile` passes `input.profile_id or None` so empty string also takes the active-profile path.
5. **`_check_ci_yaml` placeholder scan ignores `${{ ... }}`** (legit Actions expressions) but flags a bare `{{` (un-rendered mustache). The SAST-tool substring check is what catches a profile mis-render or an un-rendered `{{sast_tool}}`.
6. **`passed = not missing and not errors`** — both must be empty. Required files absent → `missing`; present-but-malformed cheap files → `errors`; bad iac-manifest → `errors`.
7. **IaC manifest is OPTIONAL + matched by basename suffix** (`endswith("iac-manifest.json")`), validated only if present; it is NOT in `REQUIRED_BASELINE_FILES`. jsonschema absence / broken schema are WARNINGS (non-fatal), not validation errors.
8. **Neither activity raises on data** — best-effort throughout. The `@foundry_activity` error-wrapping path is exercised only by genuinely unexpected exceptions.
9. **G-04c gate is a rework loop, not an immediate fail.** A failed baseline regenerates up to `MAX_REWORK_ITERATIONS`; only then does the workflow go FAILED (`generate-baseline-incomplete`).

## 6. Undetermined / cross-file
- `iac-scaffolding-generator`'s `output.schema.json` exact shape (the keys `stacks/lambda_functions/api_routes/event_rules` and their sub-fields) lives in `cross-cutting/skills/iac-scaffolding-generator/schemas/output.schema.json` — the semantic checks here mirror that skill's `validate_output.py` but the authoritative schema is owned there.
- `route_generate_file` / `is_root_bound` / `ROOT_BOUND_PREFIXES` / `ROOT_BOUND_EXACT` / `WORKFLOW_METADATA` basenames (the routing that decides which agent-produced files land at repo-root vs namespaced, and thus what `committed_files` contains) live in `olympus_workflows/devsecops_contract.py` (import-safe in `workflow.unsafe`) — summarized here only as the source of the validator's input.
