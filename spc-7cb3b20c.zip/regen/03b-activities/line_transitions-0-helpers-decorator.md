# Atomic Regeneration Spec — `line_transitions.py` Part 0: Preamble, Decorator, Helpers, Shared SQL Builders

**Source file:** `/Users/pnunna/Documents/GitHub/foundry/temporal/olympus_workflows/activities/line_transitions.py`
**HEAD:** `7cb3b20c`. **Line numbers REFRESHED to HEAD** — see ⚠️ shift note below.
**This spec owns:** module docstring + imports + module globals (lines 1–104), the two transition/lookup activities `start_next_line_workflow` (105–217) and `fetch_application_source_repos` (219–278), the JSON/list helpers `_try_parse_json` / `_dedupe_str_list` / `_extract_decomposition` (281–404), the activity `persist_decomposition_map` (407–471), **and the shared projection SQL-assembly machinery** that every sibling `persist_*` function in this module depends on: the column registries `_SIDE_EFFECT_COLUMNS` (791–874) / `_JSONB_COLUMNS` (877–892) / `_NATIVE_COLUMNS` (898–919), the metadata merge helper `_merge_application_metadata` (1173–1225), and the dynamic UPDATE builder `_build_update_sql` (1226–1259).

> ⚠️ **Boundary note.** The nominal line range for this group was 1–408, but the prompt's scope explicitly demands the *shared SQL-assembly helpers that drive every projection*. Those (`_SIDE_EFFECT_COLUMNS`, `_JSONB_COLUMNS`, `_NATIVE_COLUMNS`, `_merge_application_metadata`, `_build_update_sql`) physically sit at lines 791–1259. They are reproduced HERE because no sibling `persist_*` spec can rebuild its projection without them. Sibling specs (persist_discovery / persist_rationalization / persist_architecture / persist_data / persist_modernization / persist_validation / persist_deployment / persist_disposition / governance / sustainment) MUST treat `_build_update_sql`, `_merge_application_metadata`, and the three column registries as **imported from this module** and reference this spec for their exact behavior. The per-line `_extract_*` extractors (lines 486–790, 922–1172, 2888+, 3133+, …) belong to the sibling specs; this spec only owns the catalog/synthesis decomposition extractor and the generic builders.

> ⚠️ **HEAD `7cb3b20c` line-shift note (citations CORRECTED from the prior baseline).** `line_transitions.py` grew by +162 lines via two upstream insertions that pushed this group's shared-machinery symbols down. `_SIDE_EFFECT_COLUMNS`/`_JSONB_COLUMNS`/`_NATIVE_COLUMNS` shifted only +3 (788→791 etc.), but `_merge_application_metadata` shifted +115 (1058→1173) and `_build_update_sql` shifted +115 (1111→1226). Every sibling `persist_*` def in §8 moved by +115 (Discovery/Rationalization/Architecture) / +125 (Data/Modernization/Validation) / +152 (Sustainment/Governance/Deployment/Disposition). **`types.py` also grew** (new `ValidateDevSecOpsBaseline*` / `ResolveDevSecOpsProfile*` dataclasses at 698–761 plus others): the dataclass citations in §2/§3/§5 below are CORRECTED to HEAD (`StartNextLineInput` 1742→**1810**, `FetchSourceReposInput` 803→**871**, `PersistDecompositionMapInput` 1296→**1364**, `StepExecutionContext` 531→**532**). `execution.py` citations are UNCHANGED. Bodies are behaviorally UNCHANGED — only citations moved.

---

## 0. THE DECORATOR — `@foundry_activity` (capture-once; referenced by every activity below)

**Source:** `/private/var/folders/qs/dwcdl18n351cyz88x2tc9w3w0000gp/T/tmp.2xQMcqnDWM/foundry_temporal/activities.py:107-165`. Imported in this module at line 26: `from foundry_temporal.activities import ActivityConfig, foundry_activity`.

`@foundry_activity` is **NOT** `@activity.defn`. It is a decorator factory `foundry_activity(config=None, name=None, **activity_kwargs)` that returns a decorator wrapping the user coroutine. A plain `@activity.defn` rebuild **loses observability logging and the retryable/non-retryable error classification** — both are mandatory for behavioral parity.

### `ActivityConfig` dataclass (`activities.py:27-39`)
```python
@dataclass
class ActivityConfig:
    retry_policy: RetryPolicy | None = None
    start_to_close_timeout: timedelta | None = None
    schedule_to_close_timeout: timedelta | None = None
    schedule_to_start_timeout: timedelta | None = None
    heartbeat_timeout: timedelta | None = None
    enable_observability: bool = True
    enable_error_wrapping: bool = True
    log_inputs: bool = False
    log_outputs: bool = False
```
> ⚠️ The timeout/retry fields exist on the config object but `foundry_activity` **does not apply them to the activity definition** — they are NOT forwarded to `@activity.defn`. Activity timeouts/retries are set by the **workflow** at call time (`execute_activity(..., start_to_close_timeout=..., retry_policy=...)`), not here. Only `enable_observability`, `enable_error_wrapping`, `log_inputs`, `log_outputs` are read inside the wrapper. **Every activity in this module passes `config=ActivityConfig(enable_observability=True)` and nothing else** → observability ON, error-wrapping ON (default `True`), input/output logging OFF.

### Exact wrapper behavior (`activities.py:122-165`) — reproduce verbatim
```python
def decorator(func):
    activity_config = config or ActivityConfig()

    @activity.defn(name=name, **activity_kwargs)   # name defaults to None → Temporal uses func.__name__
    @wraps(func)
    async def wrapper(*args, **kwargs):
        activity_name = name or func.__name__
        activity_logger = get_logger()             # foundry_temporal.logging.get_logger()

        if activity_config.enable_observability:
            activity_logger.info(
                f"Activity {activity_name} starting",
                extra={"inputs": args if activity_config.log_inputs else None},
            )
        try:
            result = await func(*args, **kwargs)
            if activity_config.enable_observability:
                activity_logger.info(
                    f"Activity {activity_name} completed",
                    extra={"outputs": result if activity_config.log_outputs else None},
                )
            return result
        except Exception as error:
            if activity_config.enable_observability:
                activity_logger.error(f"Activity {activity_name} failed: {error}", extra={"error": str(error)})
            if activity_config.enable_error_wrapping:
                if isinstance(error, (WorkflowError, ApplicationError)):
                    raise                                            # (1) pass-through, NO re-wrap
                elif _is_retryable_error(error):
                    raise RetryableError(f"Retryable error in {activity_name}: {error}") from error   # (2)
                else:
                    raise NonRetryableError(f"Non-retryable error in {activity_name}: {error}") from error  # (3)
            else:
                raise
    return wrapper
return decorator
```

**Error-classification contract (critical):**
- **(1)** If the raised error is already a `WorkflowError` (base class, `errors.py:10`) **or** `temporalio.exceptions.ApplicationError`, it is **re-raised unchanged** (bare `raise`). This is why activity bodies in this module raise `NonRetryableError(...)` directly for invalid app_id / unknown line / missing app — those are `WorkflowError` subclasses (`NonRetryableError ⊂ WorkflowError ⊂ ApplicationError`, `errors.py:24,17,10`) and pass straight through with `non_retryable=True` preserved.
- **(2)** Otherwise, if `_is_retryable_error(error)` → wrap in `RetryableError` (`errors.py:17`, which is `WorkflowError(message, non_retryable=False)` → Temporal **will retry**).
- **(3)** Otherwise → wrap in `NonRetryableError` (`errors.py:24`, `non_retryable=True` → Temporal **will NOT retry**).

**`_is_retryable_error` (`activities.py:168-183`) — substring heuristic on the exception *type*:**
```python
def _is_retryable_error(error):
    error_str = str(type(error)).lower()   # e.g. "<class 'asyncpg.exceptions.ConnectionDoesNotExistError'>"
    retryable_patterns = ["timeout","connection","network","temporary","unavailable",
                          "overload","busy","throttle","rate_limit"]
    return any(pattern in error_str for pattern in retryable_patterns)
```
> ⚠️ This is a **string match on the class repr**, NOT the structured `is_retryable_error` in `errors.py:56`. A raw `asyncpg` error whose class name contains "connection"/"timeout" (e.g. `ConnectionDoesNotExistError`, `ConnectionFailureError`) → **retryable**. A generic `ValueError`/`KeyError`/`json.JSONDecodeError` → name has none of the patterns → **non-retryable**. So an unexpected DB driver hiccup retries; a programming/data bug does not. Rebuild this substring set exactly.

**`get_logger()`** (`foundry_temporal.logging`) returns a structlog logger outside the Temporal sandbox, or a `StandardLoggerWrapper` over stdlib `logging` inside the workflow sandbox (it detects `temporalio.worker.workflow_sandbox._restrictions` in `sys.modules`). For activity code the practical effect is: structured `.info/.error(msg, extra=...)`-style calls that never throw.

**Idempotency / retry caveat that applies to every activity here:** because Temporal may retry (attempt N>1) on any wrapped `RetryableError` or on worker crash, every activity body must be safe to re-run. All DB writes in this group are **single-row idempotent UPDATEs keyed by `application.id`** (last-writer-wins) — re-running produces the same final row. `start_next_line_workflow` is the one exception (see its GOTCHA).

---

## 1. Module preamble (lines 1–104)

### Module docstring (1–13)
Verbatim purpose: this module centralises assembly-line *handoffs* and *projections*. When one line's workflow finishes, the pipeline continues to the next line; rather than wiring every line workflow to know its successor, the `start_next_line_workflow` activity resolves the application row from Postgres, uses the Temporal **Client API** to start the next line's workflow, and updates `current_line` / `current_status` / `workflow_id` on the application row so the dashboard picks it up. "The activity is deliberately thin — it is a side effect, not a policy. Callers decide which line comes next; this activity just starts it."

### Imports (15–76) — reproduce exactly
```python
from __future__ import annotations
import json, logging, os, uuid
from datetime import datetime, timezone
from decimal import Decimal
from typing import Any
import asyncpg
from foundry_temporal.activities import ActivityConfig, foundry_activity
from foundry_temporal.errors import NonRetryableError
from temporalio.client import Client
from olympus_workflows.types import ( ... 36 dataclasses ... )   # see below
from olympus_workflows.utils.execution import (
    ExecutionStatus, emit_code_step_complete, emit_code_step_start,
)
logger = logging.getLogger(__name__)
```
- `Decimal` is imported at module top (line 22) even though only sibling persist functions use it — keep the import.
- The `types` import block (30–71) pulls **every** Input/Result dataclass used across the whole file (`CreateTargetAppAndRepoInput`, `FetchSourceReposInput/Result`, `LoadWaveRationalizationCapabilitiesInput/Output`, all `Persist*SideEffectsInput/Result`, `PersistCapabilityCatalogInput/Output`, `PersistDecompositionMapInput`, `RealizeTargetStateGrainInput/Result`, `StartNextLineInput/Result`, `TerminateSourceAppWorkflowsInput/Result`, `UpdateApplicationLineProjectionInput/Result`, etc.). A rebuild keeps the full import list (siblings reference them).
- `from olympus_workflows.utils.execution import ExecutionStatus, emit_code_step_complete, emit_code_step_start` — the Layer-B step-execution observability helpers (specified in §6 below).

### Module globals

**`_LINE_TO_WORKFLOW` (81–85)** — the only registry mapping line name → Temporal workflow type name used by `start_next_line_workflow`:
```python
_LINE_TO_WORKFLOW: dict[str, str] = {
    "Discovery": "DiscoveryWorkflow",
    "Rationalization": "RationalizationWorkflow",
    "Modernization": "ModernizationWorkflow",
}
```
> ⚠️ Only **three** lines are startable via this activity. Architecture, Data, Validation, Deployment, Disposition, Sustainment, Governance are NOT here — they are spawned via other paths (`update_application_line_projection`, wave fan-out). Any `next_line` not in this dict → `NonRetryableError`.

### Connection / endpoint helpers (88–102)
```python
def _db_url() -> str:
    host = os.environ.get("DATABASE_HOST", "localhost")
    port = os.environ.get("DATABASE_PORT", "5432")
    user = os.environ.get("DATABASE_USER", "olympus")
    password = os.environ.get("DATABASE_PASSWORD", "olympus")
    db = os.environ.get("DATABASE_NAME", "olympus")
    return f"postgresql://{user}:{password}@{host}:{port}/{db}"

def _temporal_host() -> str:
    return os.environ.get("TEMPORAL_HOST", "temporal:7233")

def _temporal_namespace() -> str:
    return os.environ.get("TEMPORAL_NAMESPACE", "default")
```
- **Connection pattern used by EVERY DB-touching function in this module:** `conn = await asyncpg.connect(_db_url())` … `try: <queries> finally: await conn.close()`. **No pooling** — a fresh asyncpg connection per call, always closed in `finally`. Rebuild this exact pattern; do not introduce a pool.
- `_db_url()` mirrors `utils/execution._db_url()` (same env vars, same defaults) — they are independent copies; keep both.
- Defaults: DB `olympus:olympus@localhost:5432/olympus`; Temporal `temporal:7233` namespace `default`.

---

## 2. Activity — `start_next_line_workflow` (105–217)

```python
@foundry_activity(config=ActivityConfig(enable_observability=True))
async def start_next_line_workflow(input: StartNextLineInput) -> StartNextLineResult
```

### Input — `StartNextLineInput` (`types.py:1810-1822`)
| field | type | default | meaning |
|---|---|---|---|
| `app_id` | `str` | — (required) | application UUID (string form) |
| `next_line` | `str` | — (required) | `AssemblyLineName` value, e.g. `"Rationalization"` |
| `task_queue` | `str` | — (required) | Temporal task queue to start the child on |

### Output — `StartNextLineResult` (`types.py:1825-1829`)
| field | type | default |
|---|---|---|
| `workflow_id` | `str` | — |
| `line` | `str` | — |

### Control flow (exact)
1. `workflow_name = _LINE_TO_WORKFLOW.get(input.next_line)`. If `None` → `raise NonRetryableError(f"No Temporal workflow registered for line {input.next_line!r}")`. (passes through wrapper unchanged → no retry)
2. Parse `app_uuid = uuid.UUID(input.app_id)`; on `(ValueError, TypeError)` → `raise NonRetryableError(f"Invalid app_id: {input.app_id!r}") from exc`.
3. **Connection #1 (read):** `conn = await asyncpg.connect(_db_url())`, then `fetchrow`:
   ```sql
   SELECT a.name, a.portfolio_id, a.repo_url, a.target_repo_url,
          a.architecture_blueprint_ref, p.artifact_repo_url
   FROM application a
   JOIN portfolio p ON p.id = a.portfolio_id
   WHERE a.id = $1            -- $1 = app_uuid
   ```
   closed in `finally`. If `row is None` → `raise NonRetryableError(f"Application {input.app_id} not found")`.
4. Compute identifiers:
   - `run_ts = int(datetime.now(timezone.utc).timestamp())` (unix seconds)
   - `line_slug = input.next_line.lower().replace(" ", "-")` (e.g. `"Rationalization"`→`"rationalization"`)
   - `workflow_id = f"{line_slug}-{input.app_id}-{run_ts}"`
5. **`prior_artifacts`** assembly (153–162): `prior_artifacts: list[str] = []`; if `row.get("architecture_blueprint_ref")` is truthy, append it. This threads the Architecture line's authoritative target-state spec into Modernization's Extract/Design/Generate factory. Empty if the app hasn't passed G-02 → Modernization falls back to source-only Ralph Loop.
6. **Start the child workflow via Client API** (164–181):
   ```python
   client = await Client.connect(_temporal_host(), namespace=_temporal_namespace())
   await client.start_workflow(
       workflow_name,                      # positional: workflow type name string
       {                                   # single dict arg → the child's LineWorkflowInput
           "app_id": str(app_uuid),
           "app_name": row["name"],
           "wave_id": "",
           "portfolio_id": str(row["portfolio_id"]),
           "artifact_repo": row["artifact_repo_url"] or "",
           "source_repo": row["repo_url"] or "",
           "target_repo_url": row.get("target_repo_url") or "",
           "prior_artifacts": prior_artifacts,
       },
       id=workflow_id,
       task_queue=input.task_queue,
   )
   ```
   > ⚠️ `wave_id` is always `""` here (this path is the linear single-app hand-off, not a wave). The arg is a **plain dict**, not a typed dataclass — the child workflow deserializes it into `LineWorkflowInput`. Field names must match the child's dataclass exactly.
7. **Connection #2 (write):** fresh `asyncpg.connect(_db_url())`, then:
   ```python
   status = f"{line_slug.replace('-', '_')}_in_progress"   # e.g. "rationalization_in_progress"
   ```
   ```sql
   UPDATE application
   SET current_status = $1, current_line = $2, current_step = NULL,
       workflow_id = $3, updated_at = $4
   WHERE id = $5
   ```
   params: `(status, input.next_line, workflow_id, datetime.now(timezone.utc), app_uuid)`. Closed in `finally`.
8. `logger.info("Started next line workflow", extra={app_id, next_line, workflow_id, task_queue})`.
9. `return StartNextLineResult(workflow_id=workflow_id, line=input.next_line)`.

### Projection mapping — `start_next_line_workflow` writes to `application`
| source value | → `application` column | condition / note |
|---|---|---|
| `f"{line_slug_underscored}_in_progress"` | `current_status` | always |
| `input.next_line` | `current_line` | always |
| literal `NULL` | `current_step` | always reset |
| `workflow_id` | `workflow_id` | always |
| `datetime.now(utc)` | `updated_at` | always |
(`WHERE id = app_uuid`)

### GOTCHAs
- ⚠️ **Two separate connections** (read at step 3, write at step 7) with the `start_workflow` call **between** them. The write is NOT in a transaction with the read; and the workflow is started **before** the row flip. If the worker dies between start and the UPDATE, the child workflow exists but the row still shows the old line/status — a Temporal retry re-runs the whole activity, **starting a SECOND child workflow with a new `run_ts`/`workflow_id`** (the id embeds the timestamp). This activity is therefore **NOT idempotent across retries** w.r.t. child-workflow creation. Behavioral parity requires reproducing this exact ordering (read → start → write, distinct connections) — do not "fix" it into one transaction.
- ⚠️ `row.get(...)` is used on an asyncpg `Record` (supports mapping `.get`); `row["name"]`/`row["portfolio_id"]` use indexing. `repo_url`, `target_repo_url`, `artifact_repo_url` are coalesced to `""` with `or ""`.
- Errors raised are all `NonRetryableError` (no retry). DB connection failures bubble as raw asyncpg exceptions → wrapper classifies by class-name substring (`connection`/`timeout` → retryable).

---

## 3. Activity — `fetch_application_source_repos` (219–278)

```python
@foundry_activity(config=ActivityConfig(enable_observability=True))
async def fetch_application_source_repos(input: FetchSourceReposInput) -> FetchSourceReposResult
```

### Input — `FetchSourceReposInput` (`types.py:871-886`)
| field | type | default |
|---|---|---|
| `source_app_ids` | `list[str]` | `field(default_factory=list)` |

### Output — `FetchSourceReposResult` (`types.py:889-904`)
| field | type | default | meaning |
|---|---|---|---|
| `anchor_source_repo` | `str` | `""` | repo_url of the FIRST `source_app_ids` entry (consolidate anchor); `""` if missing |
| `source_repos` | `dict[str, str]` | `field(default_factory=dict)` | canonical-uuid-string → `application.repo_url`; apps with no DB row are **omitted** |

### Control flow (exact)
1. If `not input.source_app_ids` → `return FetchSourceReposResult()` (all defaults).
2. Build parsed id list while remembering raw→canonical mapping:
   ```python
   ids: list[uuid.UUID] = []
   raw_to_canonical: dict[str, str] = {}
   for raw in input.source_app_ids:
       try: parsed = uuid.UUID(raw)
       except (ValueError, TypeError): continue        # skip un-parseable, do NOT raise
       ids.append(parsed)
       raw_to_canonical[raw] = str(parsed)
   if not ids: return FetchSourceReposResult()
   ```
3. **Read:** `conn = await asyncpg.connect(_db_url())`, then:
   ```sql
   SELECT id, repo_url FROM application WHERE id = ANY($1::uuid[])    -- $1 = ids (list[UUID])
   ```
   build `source_repos[str(row["id"])] = row["repo_url"] or ""` for each row; `finally: await conn.close()`.
4. Resolve anchor:
   ```python
   anchor_canonical = raw_to_canonical.get(input.source_app_ids[0], "")
   anchor_source_repo = source_repos.get(anchor_canonical, "")
   return FetchSourceReposResult(anchor_source_repo=anchor_source_repo, source_repos=source_repos)
   ```

### Notes / behavior
- **Read-only, idempotent.** Missing rows / unparseable ids never raise — the activity returns empty/partial results so the caller (`WaveRationalizationWorkflow._spawn_children_for_target`) can diff requested vs returned keys to detect gaps. (Per docstring: PR #494, 2026-05-20, fixing empty `source_repo`.)
- `source_repos` keys are **canonical** UUID strings (`str(uuid.UUID(raw))`), which may differ in casing from the raw inputs — anchor lookup goes through `raw_to_canonical` to bridge the two. ⚠️ Don't key by raw input; key by canonical.
- Retry: transient DB errors → wrapper → retryable (class-name match). No `execution_context` / step-execution emission on this activity.

---

## 4. JSON & list helpers (281–404)

### `_try_parse_json(text: str) -> dict[str, Any] | None` (281–297)
Best-effort parse of agent output that may be prose-wrapped JSON.
```python
def _try_parse_json(text):
    if not text: return None
    try:
        value = json.loads(text)
    except json.JSONDecodeError:
        start = text.find("{"); end = text.rfind("}")
        if start == -1 or end <= start: return None
        try: value = json.loads(text[start:end+1])
        except json.JSONDecodeError: return None
    return value if isinstance(value, dict) else None
```
> ⚠️ Returns `None` (not `{}`) for empty/invalid input, and also `None` if the parsed value is not a dict (e.g. a top-level JSON array or scalar). The fallback grabs the substring from the **first `{`** to the **last `}`** (`rfind`) — greedy; designed for a single JSON object embedded in prose. Reproduce the `end <= start` guard exactly (rejects `}{` and equal positions).

### `_dedupe_str_list(xs: list[str]) -> list[str]` (300–308)
Order-preserving dedupe via a `seen: set` + output list. First occurrence wins.

### `_extract_decomposition(catalog, synthesis) -> dict[str, Any]` (311–404)
Harvests `modules` / `integrations` / `tech_stack` from **both** the catalog JSON and the synthesis JSON into the shape the Insights API reads (`decomposition_map.modules[*].name`, `decomposition_map.integrations` = list[str], `decomposition_map.tech_stack` = list[str]). Tolerates two contract shapes: the W19 catalog-application shape and the legacy dependency-mapper shape.

**Algorithm (exact):**
```python
out = {}; modules=[]; integrations=[]; tech_stack=[]
for source in (catalog or {}, synthesis or {}):      # iterate BOTH sources, in this order
    # (A) nested architecture.* (W19 catalog shape)
    arch = source.get("architecture")
    if isinstance(arch, dict):
        mods = arch.get("major_components") or arch.get("components")
        if isinstance(mods, list):
            for m in mods:
                if isinstance(m, dict) and m.get("name"): modules.append({"name": str(m["name"])})
                elif isinstance(m, str): modules.append({"name": m})
        ints = arch.get("integrations")
        if isinstance(ints, list):
            for i in ints:
                if isinstance(i, str): integrations.append(i)
                elif isinstance(i, dict) and i.get("name"): integrations.append(str(i["name"]))
    # (B) top-level modules/components (legacy shape) — ADDITIVE to (A)
    mods = source.get("modules") or source.get("components")
    if isinstance(mods, list):
        for m in mods:
            if isinstance(m, dict) and m.get("name"): modules.append({"name": str(m["name"])})
            elif isinstance(m, str): modules.append({"name": m})
    # (C) top-level integrations/external_systems — ADDITIVE
    ints = source.get("integrations") or source.get("external_systems")
    if isinstance(ints, list):
        for i in ints:
            if isinstance(i, str): integrations.append(i)
            elif isinstance(i, dict) and i.get("name"): integrations.append(str(i["name"]))
    # (D) tech_stack / technologies / stack — list OR dict-of-named-sublists
    ts = source.get("tech_stack") or source.get("technologies") or source.get("stack")
    if isinstance(ts, list):
        for t in ts:
            if isinstance(t, str): tech_stack.append(t)
            elif isinstance(t, dict) and t.get("name"): tech_stack.append(str(t["name"]))
    elif isinstance(ts, dict):
        for key, value in ts.items():
            if isinstance(value, list):
                for item in value:
                    if isinstance(item, str): tech_stack.append(item)
                    elif isinstance(item, dict) and item.get("name"): tech_stack.append(str(item["name"]))
            elif value: tech_stack.append(f"{key}: {value}")
if modules: out["modules"] = modules                          # NOT deduped
if integrations: out["integrations"] = _dedupe_str_list(integrations)
if tech_stack: out["tech_stack"] = _dedupe_str_list(tech_stack)
return out
```
> ⚠️ Behavioral details to preserve exactly:
> - The architecture block (A) and the top-level block (B/C) are **both** harvested from the same source — a source carrying both `architecture.major_components` AND top-level `modules` contributes both (modules can duplicate). `modules` is **never deduped**; `integrations` and `tech_stack` **are** deduped (order-preserving).
> - `or` chaining means `major_components` wins over `components`; `tech_stack` over `technologies` over `stack`; `integrations` over `external_systems`. An empty/falsy first key falls through to the next.
> - dict-shaped `tech_stack`: list-valued sub-keys contribute their string/`{"name":...}` items; **non-list truthy** sub-values are stringified as `"{key}: {value}"`. Falsy sub-values are skipped (`elif value`).
> - Returns `{}` if nothing extracted (no keys present), which `persist_decomposition_map` treats as "skip the write".

---

## 5. Activity — `persist_decomposition_map` (407–471)

```python
@foundry_activity(config=ActivityConfig(enable_observability=True))
async def persist_decomposition_map(input: PersistDecompositionMapInput) -> None
```

### Input — `PersistDecompositionMapInput` (`types.py:1364-1378`)
| field | type | default |
|---|---|---|
| `app_id` | `str` | — (required) |
| `catalog_json` | `str` | `""` |
| `synthesis_json` | `str` | `""` |
| `execution_context` | `StepExecutionContext \| None` | `None` |

Output: `None`.

### Control flow (exact)
```python
exec_id = await emit_code_step_start(input.execution_context, function_name="persist_decomposition_map")
try:
    try: app_uuid = uuid.UUID(input.app_id)
    except (ValueError, TypeError) as exc:
        raise NonRetryableError(f"Invalid app_id: {input.app_id!r}") from exc
    catalog   = _try_parse_json(input.catalog_json)
    synthesis = _try_parse_json(input.synthesis_json)
    decomposition = _extract_decomposition(catalog, synthesis)
    if not decomposition:                                   # nothing extractable
        logger.info("persist_decomposition_map: nothing extractable ...", extra={"app_id": input.app_id})
        await emit_code_step_complete(exec_id, columns_written=[])   # ⚠️ empty list, status defaults COMPLETED
        return
    conn = await asyncpg.connect(_db_url())
    try:
        await conn.execute(
            """UPDATE application
               SET decomposition_map = $1, updated_at = $2
               WHERE id = $3""",
            json.dumps(decomposition),       # $1 — JSONB column, JSON-string-encoded
            datetime.now(timezone.utc),      # $2
            app_uuid,                         # $3
        )
    finally:
        await conn.close()
    logger.info("decomposition_map persisted", extra={app_id, module_count, integration_count, tech_stack_count})
    await emit_code_step_complete(exec_id, columns_written=["decomposition_map", "updated_at"])
except Exception as exc:
    await emit_code_step_complete(exec_id, status=ExecutionStatus.FAILED, error=str(exc))
    raise
```

### Projection mapping — `persist_decomposition_map` writes to `application`
| source | → `application` column | type | condition |
|---|---|---|---|
| `json.dumps(_extract_decomposition(catalog, synthesis))` | `decomposition_map` | **JSONB** (string-encoded) | only when `decomposition` is non-empty |
| `datetime.now(utc)` | `updated_at` | timestamptz | with the write |
(`WHERE id = app_uuid`)

**No write at all** when `_extract_decomposition` returns `{}` — the column stays untouched (NULL or prior value). The Insights tab shows "Run Discovery to extract architecture…" until populated.

### Step-execution observability (Layer B) — exact contract for this activity
- `emit_code_step_start(input.execution_context, function_name="persist_decomposition_map")` → returns `exec_id` (a `uuid.UUID | None`; `None` if no context or any emit failure).
- On the "nothing extractable" early-return: `emit_code_step_complete(exec_id, columns_written=[])` (status defaults `COMPLETED`).
- On success: `emit_code_step_complete(exec_id, columns_written=["decomposition_map", "updated_at"])`.
- On ANY exception (incl. the `NonRetryableError` for bad app_id, and DB errors): `emit_code_step_complete(exec_id, status=ExecutionStatus.FAILED, error=str(exc))` then `raise`. ⚠️ The `try/except` wraps the **entire** body including the app_id parse — so a failed-status record is emitted even for the invalid-app_id path before the error propagates to the `@foundry_activity` wrapper. Reproduce this outer try/except/raise exactly.
- Idempotent: single keyed UPDATE; safe to retry. `emit_code_step_*` are best-effort (swallow their own DB errors, §6).

---

## 6. Layer-B step-execution observability helpers (imported from `utils/execution.py`)

These are imported at line 72–76 and are the *code-step* flavor of the pipeline-execution contract. Source: `/Users/pnunna/Documents/GitHub/foundry/temporal/olympus_workflows/utils/execution.py`. Reproduced here because `persist_decomposition_map` (this spec) and every sibling `persist_*` depend on them.

### `ExecutionStatus` enum (`execution.py:66-74`)
`QUEUED, RUNNING, COMPLETED, FAILED, TIMED_OUT, SKIPPED, ESCALATED, ABANDONED` — `str` enum, lowercase values.

### `StepExecutionContext` (`types.py:532-554`) — the context activities forward
| field | type | default | note |
|---|---|---|---|
| `portfolio_id` | `str` | — | only strictly-required field for emission |
| `line_id` | `str` | — | |
| `step_id` | `str` | — | |
| `app_id` | `str` | `""` | nullable for wave-scoped records |
| `wave_id` | `str` | `""` | nullable for per-app records |
| `input_artifact_paths` | `list[str]` | `field(default_factory=list)` | Layer-A `inputs.artifacts` verbatim |
| `gate_id` | `str` | `""` | |

### `emit_code_step_start(ctx, *, function_name, columns_writable=None) -> uuid.UUID | None` (`execution.py:283-321`)
- If `ctx is None` → return `None` (no emission; legacy call sites tolerated).
- Sources `workflow_id` and `attempt` from `temporalio.activity.info()` inside a `try/except` (falls back to `""` / `1` if not in an activity context).
- Builds `payload = {"function": function_name}`; if `columns_writable` truthy, adds `payload["columns_written"] = columns_writable`.
- Calls `emit_execution_record(EmitExecutionRecordInput(portfolio_id=ctx.portfolio_id, line_id=ctx.line_id, step_id=ctx.step_id, step_kind=StepKind.CODE, workflow_id=..., app_id=ctx.app_id or None, wave_id=ctx.wave_id or None, attempt=..., payload=payload, status=ExecutionStatus.RUNNING))` and returns the resulting `execution_id` (or `None`).

### `emit_code_step_complete(execution_id, *, status=COMPLETED, columns_written=None, error=None)` (`execution.py:324-345`)
- If `columns_written is not None` → `payload_merge = {"columns_written": columns_written}` (an empty list IS a refinement — it overwrites to `[]`); else `payload_merge=None`.
- Calls `update_execution_record(execution_id, status=status, payload_merge=payload_merge, last_error=error)`.

### Underlying `emit_execution_record` (`execution.py:150-219`) — best-effort INSERT
- New `execution_id = uuid.uuid4()`; `started_at = input.started_at or now(utc)`.
- Parses `app_id/wave_id/portfolio_id/agent_task_id/gate_id` via `_parse_uuid` (returns `None` for empty/invalid).
- **If `portfolio_uuid is None` → log warning, return `None`** (no insert). ⚠️ A missing/invalid portfolio_id silently disables the step record.
- INSERT into `step_execution`:
  ```sql
  INSERT INTO step_execution (
      execution_id, app_id, wave_id, portfolio_id,
      line_id, step_id, step_kind, status,
      started_at, attempt, input_artifacts, payload,
      workflow_id, agent_task_id, gate_id)
  VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11::jsonb,$12::jsonb,$13,$14,$15)
  ```
  with `step_kind`/`status` passed as `.value` (lowercase strings), `input_artifacts` = `json.dumps([a.to_dict() for a in input.input_artifacts])`, `payload` = `json.dumps(input.payload or {})`.
- **Best-effort:** the whole INSERT is in `try/except Exception` → on any failure logs a warning and **returns `None`**; the activity continues. Own connection, closed in `finally`.

### Underlying `update_execution_record` (`execution.py:222-275`) — best-effort UPDATE
- If `execution_id is None` → return immediately (no-op).
- `completed = completed_at or now(utc)`; `out_artifacts = [a.to_dict() ...] if output_artifacts else None`.
- UPDATE:
  ```sql
  UPDATE step_execution
     SET status = $2,
         completed_at = $3,
         duration_ms = EXTRACT(EPOCH FROM ($3 - started_at)) * 1000,
         output_artifacts = COALESCE($4::jsonb, output_artifacts),
         payload = payload || COALESCE($5::jsonb, '{}'::jsonb),
         last_error = COALESCE($6, last_error)
   WHERE execution_id = $1
  ```
  - `duration_ms` computed in SQL from `started_at`.
  - `output_artifacts`: COALESCE → only overwritten when provided.
  - `payload`: shallow JSONB merge (`||`) with `payload_merge` (or `{}`).
  - `last_error`: COALESCE → only set when `error` provided.
- Best-effort: `try/except Exception` → warn + swallow. Own connection, closed in `finally`.

> ⚠️ Because `emit_code_step_start` may return `None` (no context, bad portfolio, or DB down), `exec_id` threaded into `emit_code_step_complete` may be `None` → the complete call no-ops. This is intentional: **step-execution emission never affects activity success/failure**.

---

## 7. SHARED PROJECTION SQL MACHINERY (791–1259) — owned here, used by ALL `persist_*` siblings

> This is the projection substrate the prompt requires reproduced in full. Sibling `persist_*` specs MUST import/reference these names from this spec. The per-line `_extract_*` extractors emit a **flat dict** whose keys are a subset of `_SIDE_EFFECT_COLUMNS`; that dict (called `projections`) is fed to `_build_update_sql` to produce the parameterized `UPDATE application SET … WHERE id = $N`.

### 7.1 `_SIDE_EFFECT_COLUMNS` (791–874) — the authoritative whitelist of projectable `application` columns
A `tuple[str, ...]`, **order significant** (drives `$N` placeholder numbering in `_build_update_sql`). Reproduce in this exact order:

```
description, business_domain, archetype, complexity_tier, safety_tier,
risk_tier, risk_tier_source, tech_stack, size_metrics, architecture,
business_logic, quality, ux_assessment, tco,
portfolio_score, disposition, disposition_source, disposition_rationale_ref,
architecture_blueprint_ref, architecture_pattern, architecture_decided_at, source_app_ids,
target_repo_url,
target_service_id,
data_architecture_ref, data_migration_plan_ref, data_decided_at, data_pattern, data_domains, data_current_status,
extraction_ref, extraction_at, design_ref, design_at, modernization_pattern, bounded_contexts, generated_module_refs, generate_at, modernization_current_status,
validation_parity_score, validation_critical_vuln_count, validation_accessibility_score, validation_safety_case_ref, validation_completed_at, validation_current_status,
deployed_at, deployment_env, cutover_strategy, parallel_run_duration_days, cost_savings_realized_usd, license_reclamation_usd, legacy_decommissioned_at, deployment_current_status,
disposition_output_ref, disposition_completed_at, disposition_current_status, cost_savings_annual_usd
```
(58 columns total. Grouped by line in the source with comments: Discovery/Rationalization/Architecture/Data/Modernization/Validation/Deployment/Disposition — see source 791–874 for the per-group provenance comments, e.g. `target_repo_url` from migration 016 first populated by W19 Modernization PR A; `target_service_id` from migration 053.)

> ⚠️ **A column NOT in this tuple cannot be projected by `_build_update_sql`.** If a sibling extractor emits a key outside this tuple, it is silently ignored (the loop `if column not in projections: continue` iterates over the tuple, not the dict — so only whitelisted keys are ever written). This is the single source of truth for "which columns the projection layer can touch." Any new projectable column MUST be added here.

### 7.2 `_JSONB_COLUMNS` (877–892) — columns whose values are `json.dumps`-encoded before binding
`frozenset`:
```
tech_stack, size_metrics, architecture, business_logic, quality, ux_assessment, tco,
portfolio_score, data_domains, bounded_contexts, generated_module_refs
```
> ⚠️ For these columns, `_build_update_sql` calls `json.dumps(value)` on the value before appending to params. All other columns bind the **raw Python value** (asyncpg encodes datetime / `list[UUID]` / Decimal / str natively).

### 7.3 `_NATIVE_COLUMNS` (898–919) — documentation-only set
`frozenset` of columns passed as native Python objects (asyncpg handles them): `architecture_decided_at, source_app_ids, data_decided_at, extraction_at, design_at, generate_at, validation_completed_at, deployed_at, legacy_decommissioned_at, cost_savings_realized_usd, license_reclamation_usd, parallel_run_duration_days, disposition_completed_at, cost_savings_annual_usd`.
> ⚠️ **`_NATIVE_COLUMNS` is never read by any code** — the source comment says it exists "only for reviewer clarity; `_build_update_sql` does the right thing for anything not in `_JSONB_COLUMNS`." Reproduce it for fidelity but do NOT branch on it. The *operative* rule is binary: JSONB-encode iff in `_JSONB_COLUMNS`, else bind raw.

### 7.4 `_build_update_sql(projections: dict[str, Any]) -> tuple[str, list[Any]]` (1226–1259) — the dynamic UPDATE builder
```python
def _build_update_sql(projections):
    assignments = []; params = []; idx = 1
    for column in _SIDE_EFFECT_COLUMNS:        # iterate the WHITELIST in order
        if column not in projections: continue
        value = projections[column]
        if column in _JSONB_COLUMNS:
            value = json.dumps(value)
        assignments.append(f"{column} = ${idx}")
        params.append(value)
        idx += 1
    assignments.append(f"updated_at = ${idx}")  # ALWAYS appended
    params.append(datetime.now(timezone.utc))
    idx += 1
    where_idx = idx
    sql = "UPDATE application SET " + ", ".join(assignments) + f" WHERE id = ${where_idx}"
    return sql, params
```
**Contract / GOTCHAs:**
- Only keys present in `projections` AND in `_SIDE_EFFECT_COLUMNS` produce assignments; absent fields keep existing DB values (partial update). Iteration is over the **tuple** → deterministic column order regardless of dict insertion order.
- ⚠️ `updated_at = now()` is **always** appended (so the dashboard refreshes) — even if `projections` is empty (then the only assignment is `updated_at`). Callers therefore typically guard with `if projections:` before calling (e.g. sibling persist functions skip the UPDATE entirely when their extractors yield `{}`), but `_build_update_sql` itself does not guard.
- ⚠️ Placeholder numbering: assignments get `$1..$k`, `updated_at` gets `$(k+1)`, and the **WHERE id** binds `$(k+2)` — `where_idx` is computed AFTER the `updated_at` increment. Callers MUST append the `app_uuid` as the **last** param: `params.append(app_uuid)` is the caller's responsibility (the builder returns `params` WITHOUT the app id). Sibling usage pattern:
  ```python
  sql, params = _build_update_sql(projections)
  params.append(app_uuid)          # caller appends WHERE-clause id
  await conn.execute(sql, *params)
  ```
- The returned `params` list has length `(#assignments incl. updated_at)`; the SQL references `$1 … $where_idx` where `$where_idx` is the app id the caller appends. Off-by-one here breaks every projection — reproduce the indexing exactly.
- All values for JSONB columns are JSON **strings** (asyncpg casts to jsonb via column type); native columns bind raw.

### 7.5 `_merge_application_metadata(conn, app_uuid, namespace, payload) -> None` (1173–1225) — JSONB namespace merge into `application.metadata`
Used by Discovery/Rationalization/Architecture line transitions to write `application.metadata.<namespace>` (e.g. `compliance`) so the Compliance Posture page has data before Governance runs.
```python
async def _merge_application_metadata(conn, app_uuid, namespace, payload):
    if not payload: return                       # no-op on empty payload
    payload_with_meta = dict(payload)
    payload_with_meta.setdefault("last_assessed", datetime.now(timezone.utc).isoformat())
    namespace_block = json.dumps({namespace: payload_with_meta})
    await conn.execute(
        """UPDATE application
              SET metadata = COALESCE(metadata, '{}'::jsonb) || $1::jsonb,
                  updated_at = $2
            WHERE id = $3::uuid""",
        namespace_block,                 # $1 — {"<namespace>": {...payload..., "last_assessed": iso}}
        datetime.now(timezone.utc),      # $2
        app_uuid,                         # $3
    )
```
**Projection mapping — `_merge_application_metadata` writes to `application`:**
| source | → column | op |
|---|---|---|
| `{namespace: {**payload, "last_assessed": iso}}` (json) | `metadata` | `COALESCE(metadata,'{}'::jsonb) \|\| $1::jsonb` (shallow top-level merge) |
| `now(utc)` | `updated_at` | set |
(`WHERE id = $3::uuid`)

**GOTCHAs:**
- ⚠️ The `||` merge is **shallow at the top level**: it replaces the **entire** `metadata.<namespace>` block (not a deep merge). The docstring explicitly warns callers to pass the **full namespace shape**, not partial deltas, or earlier keys under that namespace are lost. Other namespaces are preserved.
- `last_assessed` is `setdefault` — only injected if the caller didn't already supply it; uses ISO-8601 UTC string.
- `COALESCE(metadata,'{}'::jsonb)` guards pre-migration-051 rows where `metadata` could be NULL.
- Takes an **already-open `conn`** (unlike the standalone activities) — the caller owns connection lifecycle. Idempotent (re-merge same payload only refreshes `last_assessed`/`updated_at`).
- Uses `conn` passed in; takes `namespace`/`payload` from the line-specific compliance extractor (`_extract_discovery_compliance_metadata` etc., owned by sibling specs at 922–1172).

---

## 8. Cross-references for sibling specs
- All `persist_*_side_effects` activities (`persist_discovery` 1263, `persist_rationalization` 2977, `persist_architecture` 3253, `persist_data` 3618, `persist_modernization` 3980, `persist_validation` 4369, `persist_sustainment_sweep` 4899, `persist_governance_sweep` 5514, `persist_deployment` 6004, `persist_disposition` 6279) call `_build_update_sql(projections)` then `params.append(app_uuid)` then `conn.execute(sql, *params)`. Their `_extract_*` helpers populate the flat `projections` dict whose keys MUST be a subset of `_SIDE_EFFECT_COLUMNS` (§7.1) — that is the column whitelist gate.
- `_merge_application_metadata` (§7.5) is invoked by the Discovery/Rationalization/Architecture persist functions for the `compliance` namespace.
- `_db_url`, `_temporal_host`, `_temporal_namespace`, `_LINE_TO_WORKFLOW`, `_try_parse_json`, `_dedupe_str_list` are module-level and reused by siblings; reproduce once (here).
