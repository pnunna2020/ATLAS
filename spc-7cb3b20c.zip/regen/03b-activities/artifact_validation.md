# Activity Group: Artifact Validation + Git-Backed Artifact Storage

> ATOMIC regeneration spec. Behavioral parity bar: rebuild each activity so it behaves IDENTICALLY without access to the original code. Over-specified by design.

## Scope & file provenance

The Phase-4 task title names four activities. **Only one of them physically lives in the named source file.** Trace the others to where they actually are:

| Activity | Defining file:line | Decorator |
|---|---|---|
| `validate_artifact_against_schema` | `temporal/olympus_workflows/activities/artifact_validation.py:379` | `@foundry_activity(config=ActivityConfig(enable_observability=True))` |
| `read_artifact` | `temporal/olympus_workflows/activities/git_operations.py:168` | `@foundry_activity(config=ActivityConfig(enable_observability=True))` |
| `write_artifact` | `temporal/olympus_workflows/activities/git_operations.py:217` | `@foundry_activity(config=ActivityConfig(enable_observability=True))` |
| `write_artifacts_batch` | `temporal/olympus_workflows/activities/git_operations.py:268` | `@foundry_activity(config=ActivityConfig(enable_observability=True))` |

All four are registered for the worker via `temporal/olympus_workflows/activities/__init__.py` (`read_artifact`, `write_artifact`, `write_artifacts_batch` exported there; `validate_artifact_against_schema` exported from `artifact_validation.py.__all__`).

The git-storage activities are thin Temporal wrappers over **`GitService`** (`olympus-api/src/services/git_service.py`), imported at call-time as `from src.git_service import GitService`. ⚠️ `GitService` is authored in `olympus-api/` (needs PyGithub) and **copied into the worker container at Docker build time** so it is importable as `src.git_service` inside the worker. A rebuild MUST reproduce `GitService.read_file`, `GitService.commit_file`, `GitService.commit_files` exactly — they own the actual GitHub-API behavior and the read/write JSON shapes.

The git-storage activities ALSO write a `step_execution` DB row (the only projection in this group) via `_emit_git_start` / `_emit_git_complete` → `emit_execution_record` / `update_execution_record` (`temporal/olympus_workflows/utils/execution.py`). That projection is reproduced column-by-column in §6.

---

## PREAMBLE — the `@foundry_activity` decorator (applies to ALL four activities)

Source: `foundry_temporal/activities.py` (the dependency package; read at `/private/var/folders/qs/dwcdl18n351cyz88x2tc9w3w0000gp/T/tmp.2xQMcqnDWM/foundry_temporal/activities.py`). All four activities use `@foundry_activity(config=ActivityConfig(enable_observability=True))`. **A plain `@activity.defn` rebuild loses error-wrapping + retryability classification and is WRONG.**

`foundry_activity(config=None, name=None, **activity_kwargs)` returns a decorator that wraps `func` as follows (`activities.py:122-165`):

1. `activity_config = config or ActivityConfig()`. With `ActivityConfig(enable_observability=True)`, the relevant defaults are: `enable_observability=True`, `enable_error_wrapping=True` (default), `log_inputs=False`, `log_outputs=False`. (No retry policy / timeouts are set on the config object itself; timeouts and retry policy are supplied by the **workflow** at `execute_activity` call time — see §5.)
2. Inner `wrapper` is decorated `@activity.defn(name=name, **activity_kwargs)` then `@wraps(func)`. So the registered Temporal activity name = `name or func.__name__` (here always the function name: `validate_artifact_against_schema`, `read_artifact`, `write_artifact`, `write_artifacts_batch`).
3. `activity_name = name or func.__name__`; `activity_logger = get_logger()` (from `foundry_temporal.logging`).
4. If `enable_observability`: `activity_logger.info(f"Activity {activity_name} starting", extra={"inputs": args if log_inputs else None})`. Since `log_inputs=False`, `extra={"inputs": None}`.
5. `result = await func(*args, **kwargs)`.
6. On success + observability: `activity_logger.info(f"Activity {activity_name} completed", extra={"outputs": result if log_outputs else None})` → `extra={"outputs": None}`.
7. On `except Exception as error`:
   - If observability: `activity_logger.error(f"Activity {activity_name} failed: {error}", extra={"error": str(error)})`.
   - If `enable_error_wrapping` (True here): **error classification** (`activities.py:154-159`):
     - `if isinstance(error, (WorkflowError, ApplicationError)): raise` — re-raise as-is (preserves `non_retryable`). ⚠️ `WorkflowError`/`RetryableError`/`NonRetryableError` all subclass `temporalio.exceptions.ApplicationError` (`foundry_temporal/errors.py`), so anything the activity itself raised as a typed Olympus error passes through untouched.
     - `elif _is_retryable_error(error): raise RetryableError(f"Retryable error in {activity_name}: {error}") from error`.
     - `else: raise NonRetryableError(f"Non-retryable error in {activity_name}: {error}") from error`.
   - else (`enable_error_wrapping=False`, not our case): bare `raise`.

`_is_retryable_error(error)` (`activities.py:168-183`): lowercases `str(type(error))` and returns True if it contains ANY of: `timeout`, `connection`, `network`, `temporary`, `unavailable`, `overload`, `busy`, `throttle`, `rate_limit`. ⚠️ This matches on the **type repr string**, not the message. So a `GitServiceError` (no pattern match) wrapped from a transient GitHub 5xx becomes a **`NonRetryableError`** unless it is already an `ApplicationError`. **This is the key fragility for git activities:** `GitService` raises plain `GitServiceError(Exception)` (and its subclasses `MergeConflict` / `MergeDivergenceUnresolved` / `MergeBranchProtectionRejected`) — NONE of which are `ApplicationError` and NONE match a retryable type-name pattern → `foundry_activity` wraps them all as `NonRetryableError`. Retryability for the git activities is therefore effectively governed by the **workflow's `retry_policy=` argument** and Temporal's own treatment of `NonRetryableError` (non-retryable), NOT by this classifier. See §3 and §5.

`WorkflowError.__init__(message, non_retryable=True)` → `ApplicationError(message, non_retryable=...)`. `RetryableError` = `non_retryable=False`; `NonRetryableError` = `non_retryable=True`.

`get_logger()` from `foundry_temporal.logging` — structured logger; observability log lines are emitted but not load-bearing for behavior.

---

# 1. `validate_artifact_against_schema`

**File:** `temporal/olympus_workflows/activities/artifact_validation.py:379-432`
**Decorator:** `@foundry_activity(config=ActivityConfig(enable_observability=True))`

### Signature & types

```python
async def validate_artifact_against_schema(input: ValidateArtifactInput) -> ValidateArtifactResult
```

`ValidateArtifactInput` (`types.py:631-643`, `@dataclass`):
| field | type | default |
|---|---|---|
| `artifact_filename` | `str` | (required) — logical filename, e.g. `"disposition-recommendation.json"` |
| `raw_content` | `str` | (required) — UNPARSED string the agent produced (may have markdown fences / preamble) |

`ValidateArtifactResult` (`types.py:646-669`, `@dataclass`):
| field | type | default |
|---|---|---|
| `validated` | `bool` | (required) — `True` iff schema validation **actually ran** (filename known AND parsed to dict AND schema loaded). `False` = "nothing to check" OR "couldn't parse". NOT a synonym for "payload bad". |
| `parsed_payload` | `dict \| None` | (required) — parsed dict from `parse_agent_json`, else `None`. May be populated even when `errors` non-empty (valid JSON, wrong shape). |
| `errors` | `list[str]` | `field(default_factory=list)` — human-readable messages, **capped at first 8**. Empty on success; populated on schema failure OR parse failure. |

### Contract: NEVER raises for validation outcomes

⚠️ The activity is **advisory by design**: it ALWAYS returns a `ValidateArtifactResult`. It raises ONLY `NonRetryableError` and ONLY on the environmental failure "schema file missing" (a build/deploy bug). The caller owns escalation policy. See `artifact_validation.py:1-61` (module docstring) and §1.4.

### Control flow (exact, line-cited)

```
filename = input.artifact_filename
if filename not in _SCHEMA_REGISTRY:                       # _known_artifact()  (line 411)
    return ValidateArtifactResult(validated=False, parsed_payload=None, errors=[])
parsed = parse_agent_json(input.raw_content)               # (line 416)
if not isinstance(parsed, dict):                           # (line 417)
    return ValidateArtifactResult(
        validated=False,
        parsed_payload=None,
        errors=[f"{filename}: agent output could not be parsed as a JSON object "
                "(even with markdown-fence-stripping and brace-scanning fallbacks)."],
    )
schema = _load_schema(_SCHEMA_REGISTRY[filename])          # (line 428) — may raise NonRetryableError
errors = _validate_payload(parsed, schema)                 # (line 429)
return ValidateArtifactResult(validated=True, parsed_payload=parsed, errors=errors)
```

⚠️ Note: a top-level JSON **array** parses fine via `parse_agent_json` (which accepts dict OR list) but fails the `isinstance(parsed, dict)` guard → returns `validated=False` + the "could not be parsed as a JSON object" error. So list-valued payloads are treated as un-validatable here even though they parsed.

### `parse_agent_json(raw)` — the markdown-fence-tolerant parser (MUST reproduce exactly)

Source: `temporal/olympus_workflows/utils/__init__.py:29-92`. Returns `dict | list | None`. Three-tier fallback:

1. **Guard:** `if not raw or not isinstance(raw, str): return None`. Then `s = raw.strip()`.
2. **Fast path:** `json.loads(s)`; on `(ValueError, TypeError)` → `parsed=None`. If `isinstance(parsed, (dict, list))` return it.
3. **Fence strip:** regex `_FENCE_RE = re.compile(r"^\s*```(?:json|jsonc)?\s*\n(.*?)\n```\s*$", re.DOTALL)`. If it matches, `json.loads(m.group(1))` (same exception handling); return if dict/list.
4. **Balanced-brace scan:** `start = s.find("{")`; if `>= 0`, walk chars tracking `depth`, `in_str`, `esc` (escape) — string-aware so braces inside JSON strings don't miscount. When `depth` returns to 0, `json.loads(s[start:i+1])`; return parsed (any type from `json.loads`) on success, `None` on failure. ⚠️ This last tier returns whatever `json.loads` yields without the dict/list check — but since it only triggers on a `{`-prefixed block, it's a dict in practice. If no `{` found or never balances → `return None`.

The Wave-1 failure this fixes: strict `json.loads` on fenced JSON raised; a defensive `except` fell through to empty disposition; G-DA evidence showed "no recommendation" for every app (`artifact_validation.py:5-9`, `utils/__init__.py:31-39`).

### Schema resolution — `_resolve_schemas_dir()` and `_SCHEMA_REGISTRY`

`_resolve_schemas_dir()` (`artifact_validation.py:85-115`) — module-level, evaluated once at import (`_SCHEMAS_DIR = _resolve_schemas_dir()`, line 118). Checks candidates **in order**, returns first that `is_dir()` (resolved), else falls back to candidate[1] even if missing (so the downstream `_load_schema` error is informative):
1. `Path(os.environ["OLYMPUS_SCHEMAS_DIR"])` — IF env var set (compose + helm both set it).
2. `Path(__file__).resolve().parents[3] / "schemas"` — dev-mode repo layout (`temporal/olympus_workflows/activities/` → repo root `schemas/`).
3. `Path("/app/schemas")` — canonical container mount.
4. `Path("/app/repo/schemas")` — alternate mount.

⚠️ `parents[3]` is correct for the dev source tree but is **wrong for a wheel install** (`site-packages/olympus_workflows/activities/` → `site-packages` parents, which has no `schemas/`). That is exactly why the env-var override (candidate 1) and container mounts (3,4) exist. The fallback at line 115 returns candidate[1] (the `parents[3]` path) even when missing, intentionally, so the later "schema not found at {path}" error names a path an operator recognizes.

`_SCHEMA_REGISTRY: dict[str, Path]` (`artifact_validation.py:124-346`) — maps logical artifact filename → absolute schema `Path` (`_SCHEMAS_DIR / <subdir> / <schema-file>`). **41 entries.** Adding an entry enables validation for that artifact automatically (`_known_artifact` is `filename in _SCHEMA_REGISTRY`). Full table (filename → schema path relative to `_SCHEMAS_DIR`):

| # | artifact_filename | schema path (under `_SCHEMAS_DIR/`) |
|---|---|---|
| 1 | `disposition-recommendation.json` | `rationalization/disposition-recommendation.schema.json` |
| 2 | `classification.json` | `rationalization/classification.schema.json` |
| 3 | `portfolio-score.json` | `rationalization/portfolio-score.schema.json` |
| 4 | `redundancy-matrix.json` | `rationalization/redundancy-matrix.schema.json` |
| 5 | `portfolio-redundancy-matrix.json` | `rationalization/rationalization-clustering-plan.schema.json` ⚠️ NOT redundancy-matrix; remapped to clustering-plan by migration 052 / rat-cap layer 2026-05-18. Filename preserved across schemas; only the validator alias changed (so workflow grep/file-list refs stay stable). |
| 5b | (alias of `redundancy-matrix.schema.json`) | — see entries 4, 8 |
| 6 | `shared-identity-report.json` | `rationalization/shared-identity-report.schema.json` |
| 7 | `wave-outcome-synthesis.json` | `rationalization/wave-outcome-synthesis.schema.json` |
| 8 | `intra-app-redundancy.json` | `rationalization/redundancy-matrix.schema.json` (same shape as cross-app redundancy-matrix; skill branches on input context) |
| 9 | `ux-overlap-matrix.json` | `rationalization/ux-overlap-matrix.schema.json` |
| 10 | `business-rule-redundancy.json` | `rationalization/business-rule-redundancy.schema.json` |
| 11 | `integration-graph.json` | `rationalization/integration-graph.schema.json` |
| 12 | `disposition-governance.json` | `rationalization/disposition-governance.schema.json` |
| 13 | `user-impact-analysis.json` | `rationalization/user-impact-analysis.schema.json` |
| 14 | `wave-plan.json` | `rationalization/wave-plan.schema.json` |
| 15 | `wave-plan-validation.json` | `rationalization/wave-plan-validation.schema.json` |
| 16 | `application-catalog-entry.json` | `discovery/catalog.schema.json` |
| 17 | `business-logic.json` | `discovery/business-logic.schema.json` |
| 18 | `quality-risk.json` | `discovery/quality-risk.schema.json` |
| 19 | `ux-accessibility.json` | `discovery/ux-accessibility.schema.json` |
| 20 | `discovery-synthesis.json` | `discovery/discovery-synthesis.schema.json` |
| 21 | `capability-catalog.json` | `discovery/capability-catalog.schema.json` |
| 22 | `architecture-blueprint.json` | `architecture/architecture-blueprint.schema.json` |
| 23 | `cloud-pattern.json` | `architecture/cloud-pattern.schema.json` |
| 24 | `target-application-map.json` | `architecture/target-application-map.schema.json` |
| 25 | `architecture-target-plan.json` | `architecture/architecture-target-plan.schema.json` (wave-scoped; workflow validates strict-fail before commit — non-conforming = NonRetryableError) |
| 26 | `cost-estimate.json` | `architecture/cost-estimate.schema.json` |
| 27 | `ea-compliance-report.json` | `architecture/ea-compliance.schema.json` (written under `files/ea-compliance/`) |
| 28 | `ea-compliance.json` | `architecture/ea-compliance.schema.json` (top-level commit; same schema as 27) |
| 29 | `api-contract-compliance-report.json` | `architecture/integration-arch.schema.json` |
| 30 | `integration-arch.json` | `architecture/integration-arch.schema.json` |
| 31 | `security-arch.json` | `architecture/security-arch.schema.json` |
| 32 | `design-system.json` | `architecture/design-system.schema.json` |
| 33 | `accessibility-review.json` | `architecture/accessibility-review.schema.json` |
| 34 | `ai-ml-integration.json` | `architecture/ai-ml-integration.schema.json` |
| 35 | `well-architected-review.json` | `architecture/well-architected-review.schema.json` |
| 36 | `data-domains.json` | `data/data-domains.schema.json` |
| 37 | `shared-db-analysis.json` | `data/shared-db-analysis.schema.json` (source-grain: requires `source_app_id` + `wave_id`) |
| 38 | `decomposition-strategy.json` | `data/decomposition-strategy.schema.json` |
| 39 | `data-migration-plan.json` | `data/data-migration-plan.schema.json` |
| 40 | `data-product-design.json` | `data/data-product-design.schema.json` (wave-scoped target binding required) |
| 41 | `data-architecture.json` | `data/data-architecture.schema.json` |

(Table is exactly the 41 keys in the registry, in source order. Data-line + wave-scoped target-binding requirements 47-53 of the module docstring are enforced by the **schemas themselves**, not by this activity's code.)

### `_load_schema(schema_path)` (`artifact_validation.py:354-360`)
```
if not schema_path.exists(): raise NonRetryableError(f"schema not found at {schema_path}. Check your repo layout.")
with schema_path.open() as handle: return json.load(handle)
```
⚠️ This is the ONLY raise path inside the activity. `NonRetryableError` propagates through `foundry_activity` (it's an `ApplicationError` subclass → re-raised as-is, `non_retryable=True`). Arrives at the workflow as `temporalio.exceptions.ActivityError` wrapping a non-retryable application error.

### `_validate_payload(payload, schema)` (`artifact_validation.py:363-376`)
```
validator = Draft202012Validator(schema)          # jsonschema, JSON-Schema 2020-12
errors = list(validator.iter_errors(payload))
if not errors: return []
return [f"  {err.json_path or '<root>'}: {err.message}" for err in errors[:8]]
```
⚠️ Exact error-string format: two leading spaces, then `err.json_path` (or literal `<root>` when empty), `": "`, `err.message`. **Capped at the first 8** errors (`errors[:8]`). Uses `jsonschema.Draft202012Validator.iter_errors` (does NOT short-circuit on first error). No schema `$ref` resolver is configured beyond the validator's default, so any `$ref` in the schema must resolve via the validator's built-in registry / `$id` self-references.

### Error handling / retries / idempotency
- **Raises:** only `NonRetryableError` (schema file missing). Everything else returns a result.
- **Retries:** validation never benefits from retry. Strict callers use `retry_policy=RETRY_POLICIES["validation_failure"]` (`maximum_attempts=1`); advisory callers use `RETRY_POLICIES["transient"]` then swallow `ActivityError` (see escalation below).
- **Idempotency:** pure function of `(filename, raw_content, schemas-on-disk)`. No side effects, no DB, no network. Fully deterministic and safe to retry.

### Caller escalation policy (the `on_fail` modes — implemented by the WORKFLOW, not this activity)

The activity has no `on_fail` parameter. Escalation is encoded at the call site. Two reference patterns:

**Advisory mode (warn-and-proceed)** — `wave_rationalization.py:4789-4838` helper `_validate_and_stash(...)`:
```
if not raw_content: return
try:
    result = await workflow.execute_activity(validate_artifact_against_schema,
        ValidateArtifactInput(artifact_filename=..., raw_content=...),
        start_to_close_timeout=timedelta(seconds=30),
        retry_policy=RETRY_POLICIES["transient"])
except ActivityError as exc:           # schema-missing NonRetryableError surfaces here
    workflow.logger.warning(f"{filename} schema validation skipped: {exc}", extra={...,"reason":"validator-unavailable"})
    return                             # advisory mode MUST NOT take down the workflow
if not result.errors: return
warning_key = app_id or f"wave-{wave_id}"
# logger.warning "validation failed" if result.validated else "could not be parsed"
self._validation_warnings.setdefault(warning_key, []).extend(result.errors)
```
The accumulated `self._validation_warnings[app_id]` list surfaces in the **G-DA evidence bundle** so reviewers see marginal agent output; it does NOT block the workflow.

**Strict mode (hard-fail)** — `wave_architecture.py:393-407` for `architecture-target-plan.json`:
```
validation = await workflow.execute_activity(validate_artifact_against_schema,
    ValidateArtifactInput(artifact_filename=_TARGET_PLAN_FILENAME, raw_content=plan_file.content),
    start_to_close_timeout=timedelta(seconds=30),
    retry_policy=RETRY_POLICIES["validation_failure"])     # max_attempts=1
if not validation.validated or validation.errors:
    raise ApplicationError(f"wave plan failed schema validation: {'; '.join(validation.errors[:4])}", non_retryable=True)
```
⚠️ Strict mode treats BOTH `validated=False` AND non-empty `errors` as fatal. Note the workflow re-truncates to first 4 errors for the message even though the activity already capped at 8.

A third documented mode `on_fail="retry-with-feedback"` (re-dispatch the skill with errors stitched into the prompt) is **described in the docstring (`artifact_validation.py:20-26`) but not yet wired** — capture it as future intent, not current behavior.

---

# Git-backed artifact storage activities (2–4)

Shared scaffolding for all three: every activity (a) optionally emits a `step_execution` "running" row via `_emit_git_start`, (b) builds a `GitService` from env, (c) calls one `GitService` method, (d) on exception emits a terminal FAILED row and re-raises, (e) on success emits a terminal COMPLETED row and returns a typed result. The DB emission is **best-effort** (never propagates failure — see §6).

### `_git_service_config()` / `_build_git_service(repo_override="")`
`git_operations.py:141-165`. Reads env:
```
token   = os.environ.get("GITHUB_TOKEN", "")
repo    = os.environ.get("GITHUB_REPO", "")
base_url= os.environ.get("GITHUB_BASE_URL", "https://api.github.com")
```
`_build_git_service` lazily `from src.git_service import GitService` (PyGithub only present in worker container), then `GitService(GitServiceConfig(token=cfg["token"], repo=repo_override or cfg["repo"], base_url=cfg["base_url"]))`. ⚠️ `repo_override` (the per-activity `input.repo`) wins over the env default — this is how per-portfolio / per-target repos are addressed. `GitServiceConfig` (`olympus-contracts/git_types.py:22-28`): `token: str`, `repo: str`, `base_url: str = "https://api.github.com"`.

`GitService.__init__` (`git_service.py:120-150`): builds `Auth.Token(config.token)`; passes `base_url` to `Github()` ONLY if non-default (Enterprise). Normalizes the repo slug: strips `https://`/`http://` scheme+host (`"https://github.com/org/repo"`→`"org/repo"`), strips leading/trailing `/`, strips a trailing `.git`. Then `self._repo = self._github.get_repo(repo_slug)`. On `GithubException`: 404 → `GitServiceError("Repository '{slug}' not found or token lacks access")`; else → `GitServiceError("Cannot connect to repository '{slug}': {exc.data}")`. ⚠️ Constructed eagerly inside the activity's `try`; a bad repo therefore surfaces as a `GitServiceError` → wrapped to `NonRetryableError` by `foundry_activity`.

---

# 2. `read_artifact`

**File:** `git_operations.py:168-214`
**Decorator:** `@foundry_activity(config=ActivityConfig(enable_observability=True))`

### Signature & types
```python
async def read_artifact(input: ReadArtifactInput) -> ReadArtifactResult
```
`ReadArtifactInput` (`types.py:557-565`):
| field | type | default |
|---|---|---|
| `repo` | `str` | required — `owner/name` or full URL (normalized by GitService) |
| `branch` | `str` | required |
| `path` | `str` | required |
| `commit_sha` | `str` | `""` — when set, reads at that exact revision instead of branch HEAD |
| `execution_context` | `StepExecutionContext \| None` | `None` |

`ReadArtifactResult` (`types.py:568-574`): `content: str`, `commit_sha: str`, `path: str`.

### Control flow (`git_operations.py:180-214`)
```
execution_id = await _emit_git_start(input.execution_context, repo=input.repo,
                                     operation="read_artifact", branch=input.branch, paths=[input.path])
try:
    svc = _build_git_service(repo_override=input.repo)
    result = svc.read_file(path=input.path, branch=input.branch, commit_sha=input.commit_sha)
except Exception as exc:
    await _emit_git_complete(execution_id, repo=input.repo, branch=input.branch,
                             status=ExecutionStatus.FAILED, error=str(exc))
    raise                                # re-raise → foundry_activity wraps
await _emit_git_complete(execution_id, repo=input.repo, branch=input.branch,
                         commit_sha=result.commit_sha, output_paths=[result.path])
return ReadArtifactResult(content=result.content, commit_sha=result.commit_sha, path=result.path)
```

### `GitService.read_file(path, branch="main", commit_sha="")` (`git_service.py:317-347`) — the actual read JSON shape
```
ref = commit_sha if commit_sha else branch
try: contents = self._repo.get_contents(path, ref=ref)
except GithubException as exc: raise GitServiceError(f"File '{path}' not found on ref '{ref}': {exc.data}")
if isinstance(contents, list): raise GitServiceError(f"Path '{path}' is a directory, not a file")
decoded = contents.decoded_content.decode("utf-8")        # GitHub returns base64; PyGithub decodes
if commit_sha: ref_sha = commit_sha
else:
    ref_obj = self._repo.get_branch(branch)               # extra API call to resolve branch HEAD sha
    ref_sha = ref_obj.commit.sha
return FileReadResult(content=decoded, commit_sha=ref_sha, path=path)
```
`FileReadResult` (`git_types.py:42-47`): `content`, `commit_sha`, `path`. ⚠️ Reading content is always decoded as **UTF-8 text** (`decoded_content.decode("utf-8")`) — binary artifacts are out of scope. ⚠️ The GitHub Contents API caps single-file reads at ~1 MB; larger files surface a GithubException → `GitServiceError`. ⚠️ When `commit_sha` is empty, `read_file` makes a **second** GitHub call (`get_branch`) just to populate `commit_sha` with the branch HEAD — not the commit that last touched the file. The returned `commit_sha` is the branch tip at read time, not necessarily the file's last-modifying commit.

### Errors / retries / idempotency
- `GitService` raises `GitServiceError` (file-not-found, directory, connect). `foundry_activity` wraps as `NonRetryableError` (GitServiceError is not ApplicationError and "githubexception"/"gitserviceerror" matches no retryable type-name pattern).
- Docstring states intended policy = transient (HTTP_RETRY_POLICY). Caller supplies `retry_policy=` at `execute_activity`. ⚠️ A transient GitHub 5xx becomes `GitServiceError`→`NonRetryableError`, so Temporal will NOT retry it via the activity-wrapper classification; retry only happens if the *raw GithubException* escaped (it does not — GitService catches it). Net: reads are practically not auto-retried on 5xx. (Operationally tolerable: reads are cheap to re-issue from the workflow.)
- Idempotent (pure read). Safe to retry.

---

# 3. `write_artifact`

**File:** `git_operations.py:217-265`
**Decorator:** `@foundry_activity(config=ActivityConfig(enable_observability=True))`

### Signature & types
```python
async def write_artifact(input: WriteArtifactInput) -> WriteArtifactResult
```
`WriteArtifactInput` (`types.py:609-618`):
| field | type | default |
|---|---|---|
| `repo` | `str` | required |
| `branch` | `str` | required |
| `path` | `str` | required |
| `content` | `str` | required — raw file content (text) |
| `commit_message` | `str` | required |
| `execution_context` | `StepExecutionContext \| None` | `None` |

`WriteArtifactResult` (`types.py:621-627`): `commit_sha: str`, `path: str`, `branch: str`.

### Control flow (`git_operations.py:230-265`)
```
execution_id = await _emit_git_start(..., operation="write_artifact", branch=input.branch, paths=[input.path])
try:
    svc = _build_git_service(repo_override=input.repo)
    result = svc.commit_file(branch=input.branch, path=input.path, content=input.content, commit_message=input.commit_message)
except Exception as exc:
    await _emit_git_complete(execution_id, repo=input.repo, branch=input.branch, status=FAILED, error=str(exc)); raise
await _emit_git_complete(execution_id, repo=input.repo, branch=result.branch,     # NOTE: result.branch
                         commit_sha=result.commit_sha, output_paths=[result.path])
return WriteArtifactResult(commit_sha=result.commit_sha, path=result.path, branch=result.branch)
```

### `GitService.commit_file(branch, path, content, commit_message)` (`git_service.py:213-253`) — actual write JSON shape
```
if branch != "main": self._ensure_branch(branch)         # create branch from main if missing
try:
    existing = self._repo.get_contents(path, ref=branch)
    if isinstance(existing, list): raise GitServiceError(f"Path '{path}' is a directory, not a file")
    result = self._repo.update_file(path=path, message=commit_message, content=content, sha=existing.sha, branch=branch)
except GithubException as exc:
    if exc.status == 404:
        result = self._repo.create_file(path=path, message=commit_message, content=content, branch=branch)
    else:
        raise GitServiceError(f"Failed to commit file: {exc.data}")
commit_sha = result["commit"].sha
return CommitResult(commit_sha=commit_sha, path=path, branch=branch)
```
`CommitResult` (`git_types.py:51-55`): `commit_sha`, `path`, `branch`.

⚠️ **Create-or-update via 404 fallthrough:** it FIRST tries `get_contents` to learn the existing blob `sha` and `update_file`; if the path doesn't exist GitHub raises 404 → `create_file`. The `content` is passed as a plain Python `str` — PyGithub base64-encodes it internally for the Contents API. ⚠️ Any non-404 GithubException during the read/update becomes `GitServiceError("Failed to commit file: ...")` and the create-fallthrough does NOT run.

### `_ensure_branch(branch, base_branch="main")` (`git_service.py:188-211`)
```
try: self._repo.get_git_ref(f"heads/{branch}"); return       # exists → no-op
except GithubException as exc:
    if exc.status != 404: raise                              # ⚠️ bare raise (raw GithubException escapes here)
try:
    base_ref = self._repo.get_git_ref(f"heads/{base_branch}")
    self._repo.create_git_ref(f"refs/heads/{branch}", base_ref.object.sha)
except GithubException as exc:
    if exc.status == 422: return                             # race — branch created between check & create → tolerate
    raise GitServiceError(f"Failed to create branch '{branch}' from '{base_branch}': {exc.data}")
```
⚠️ Idempotency-critical: the 422-on-create is swallowed (concurrent sibling created the branch). The "branch already exists" check is the no-op fast path. ⚠️ Only runs when `branch != "main"`; writes to `main` skip branch creation entirely (used by `wave_architecture` committing the target plan straight to `main`).

### Errors / retries / idempotency
- Raises `GitServiceError` (directory path, non-404 GithubException, branch-create failure). Wrapped to `NonRetryableError` by `foundry_activity`. (A non-404 GithubException inside `_ensure_branch` is re-raised RAW and would be wrapped to `NonRetryableError` too — no pattern match.)
- Docstring: "All writes are idempotent -- safe to retry." A retry re-issues create-or-update; updating to identical content is a no-op-ish new commit (GitHub may 422 "no changes"; PyGithub surfaces it — see GOTCHA). The branch-create race is explicitly tolerated.
- ⚠️ Re-committing **identical content** to an existing file: GitHub's update_file with unchanged content can return HTTP 422; that surfaces as a non-404 GithubException → `GitServiceError("Failed to commit file")`. So a literal retry after a successful write (same content, same sha-expectation now stale) is NOT guaranteed clean — but Temporal won't auto-retry a `NonRetryableError`, so the practical risk is bounded.

---

# 4. `write_artifacts_batch`

**File:** `git_operations.py:268-320`
**Decorator:** `@foundry_activity(config=ActivityConfig(enable_observability=True))`

### Signature & types
```python
async def write_artifacts_batch(input: WriteArtifactsBatchInput) -> WriteArtifactsBatchResult
```
`WriteArtifactsBatchInput` (`types.py:672-685`):
| field | type | default |
|---|---|---|
| `repo` | `str` | required |
| `branch` | `str` | required |
| `files` | `list[tuple[str, str]]` | required — list of `(path, content)` pairs |
| `commit_message` | `str` | required |
| `execution_context` | `StepExecutionContext \| None` | `None` |

`WriteArtifactsBatchResult` (`types.py:688-693`): `commit_sha: str`, `paths: list[str]`, `branch: str`.

### Control flow (`git_operations.py:285-320`)
```
paths = [p for p, _ in input.files]                          # extracted once, up front
execution_id = await _emit_git_start(..., operation="write_artifacts_batch", branch=input.branch, paths=paths)
try:
    svc = _build_git_service(repo_override=input.repo)
    result = svc.commit_files(branch=input.branch, files=input.files, commit_message=input.commit_message)
except Exception as exc:
    await _emit_git_complete(execution_id, repo=input.repo, branch=input.branch, status=FAILED, error=str(exc)); raise
await _emit_git_complete(execution_id, repo=input.repo, branch=result.branch,
                         commit_sha=result.commit_sha, output_paths=paths)        # ⚠️ output_paths = ALL input paths
return WriteArtifactsBatchResult(commit_sha=result.commit_sha, paths=paths, branch=result.branch)
```
⚠️ The result `paths` is the FULL input path list (not `result.path`, which is only the first file). `CommitResult.path` is discarded for batch — the activity returns all N paths.

### `GitService.commit_files(branch, files, commit_message)` (`git_service.py:255-315`) — ONE commit for N files via the Git Data API
```
if not files: raise GitServiceError("commit_files requires at least one file")
if branch != "main": self._ensure_branch(branch)
try:
    base_ref = self._repo.get_git_ref(f"heads/{branch}")
    base_commit = self._repo.get_git_commit(base_ref.object.sha)
    base_tree = base_commit.tree
    from github.InputGitTreeElement import InputGitTreeElement
    elements = []
    for path, content in files:
        blob = self._repo.create_git_blob(content, "utf-8")          # one blob per file
        elements.append(InputGitTreeElement(path=path, mode="100644", type="blob", sha=blob.sha))
    new_tree   = self._repo.create_git_tree(elements, base_tree=base_tree)
    new_commit = self._repo.create_git_commit(message=commit_message, tree=new_tree, parents=[base_commit])
    base_ref.edit(new_commit.sha)                                    # advance the ref → fast-forward
except GithubException as exc:
    raise GitServiceError(f"Batch commit on '{branch}' failed: {exc.data}")
first_path = files[0][0]
return CommitResult(commit_sha=new_commit.sha, path=first_path, branch=branch)
```
⚠️ Exact Git-Data-API sequence (MUST reproduce): **get_git_ref → get_git_commit → (per-file) create_git_blob → create_git_tree(base_tree=) → create_git_commit(parents=[base_commit]) → ref.edit(new_sha)**. All file blobs use `mode="100644"` (regular file), `type="blob"`, encoding `"utf-8"`. This produces exactly ONE commit regardless of N (vs. `commit_file`'s N commits + N round-trips). The wall-clock motive: a step emitting summary JSON + N agent file artifacts cost N+1 commits with the loop; this is a fixed ~3–4 calls + N blob creates.
- Empty `files` → `GitServiceError("commit_files requires at least one file")`.
- ⚠️ `base_ref.edit(new_commit.sha)` is a non-force fast-forward ref update. If a concurrent commit advanced the ref between read and edit, GitHub rejects (non-fast-forward) → GithubException → `GitServiceError("Batch commit on '{branch}' failed")`. So batch writes are NOT safe under concurrent writers to the same branch; the design assumes one writer per branch (branch-per-task).

### Errors / retries / idempotency
- Raises `GitServiceError` on empty input, any GithubException in the blob/tree/commit/ref dance. Wrapped to `NonRetryableError`.
- Docstring: "All writes are idempotent on content; a retry re-does the blob/tree/commit dance and simply advances the ref again." ⚠️ But the ref-edit is non-force fast-forward — a retry after a *partial* failure where the ref already advanced will be fine; a retry racing another writer fails non-fast-forward. Idempotent in the single-writer branch-per-task model only.

---

# 5. Workflow-supplied timeouts & retry policies (these are NOT on the decorator)

The `@foundry_activity` config sets no timeout/retry. Those come from the `workflow.execute_activity(...)` call. Observed bindings (for parity of caller behavior):

| Activity | start_to_close | retry_policy | source |
|---|---|---|---|
| `validate_artifact_against_schema` (advisory) | 30s | `RETRY_POLICIES["transient"]` (= `HTTP_RETRY_POLICY`) | `wave_rationalization.py:4798-4799` |
| `validate_artifact_against_schema` (strict) | 30s | `RETRY_POLICIES["validation_failure"]` (`maximum_attempts=1`) | `wave_architecture.py:399-400` |
| `write_artifact` | 60s | `RETRY_POLICIES["transient"]` | `wave_architecture.py:426-427` |

`RETRY_POLICIES` (`retry_policies.py:109-116`):
- `transient` = `HTTP_RETRY_POLICY` (foundry-temporal: 3 retries, exp backoff 1–15s).
- `validation_failure` = `RetryPolicy(maximum_attempts=1)` (no retry).
- `agent_failure` = init 5s, coef 2.0, max 60s, 3 attempts.
- `timeout` = init 30s, coef 2.0, max 60s, 2 attempts.
- `infrastructure` = init 5s, coef 2.0, max 300s, 10 attempts.
- `git_merge` = init 5s, coef 2.0, max 30s, 3 attempts, **non_retryable_error_types = ["MergeConflict","MergeDivergenceUnresolved","MergeBranchProtectionRejected"]** (used by `merge_pr`/`reconcile_and_merge_pr`, not the three storage activities — included for completeness of the git-error model).

The merge error classes (`olympus-contracts/olympus_contracts/errors.py:37-68`) all subclass `GitServiceError` (`git_types.py:59`): `MergeConflict` (`mergeable_state=="dirty"`, non-retryable), `MergeDivergenceUnresolved` (`"behind"`, retryable in bounded loop), `MergeBranchProtectionRejected` (`"blocked"`, non-retryable). They are NOT raised by `read_file`/`commit_file`/`commit_files` — only by the merge methods — but a rebuild of the git error taxonomy must include them and wire their class names into `git_merge`'s non-retryable list (Temporal matches on the class **name string**).

---

# 6. PROJECTION — `step_execution` row (the ONLY DB write in this group)

All three storage activities project to ONE table: **`step_execution`**. The projection is via `_emit_git_start` (INSERT, status RUNNING) and `_emit_git_complete` (UPDATE, terminal). Backed by `emit_execution_record` / `update_execution_record` in `temporal/olympus_workflows/utils/execution.py`. ⚠️ **Best-effort: a DB failure NEVER propagates into the activity result** (`execution.py:212-219, 270-275` swallow all exceptions, log a warning, return). The workflow stays durable even if Postgres is down. `validate_artifact_against_schema` writes NO DB row.

### DB connection (`execution.py:127-133`)
`postgresql://{DATABASE_USER|olympus}:{DATABASE_PASSWORD|olympus}@{DATABASE_HOST|localhost}:{DATABASE_PORT|5432}/{DATABASE_NAME|olympus}` via `asyncpg.connect(...)`, one connection per call, closed in `finally`. ⚠️ No pooling — a fresh connect/close per emit and per update.

### Target table DDL (`db/alembic/versions/033_create_step_execution_table.py:99-166`)
Columns: `execution_id` (UUID PK, default `gen_random_uuid()`), `app_id` (UUID null), `wave_id` (UUID null), `portfolio_id` (UUID NOT NULL), `line_id` (varchar64 NN), `step_id` (varchar128 NN), `step_kind` (enum `step_execution_kind_enum` NN), `status` (enum `step_execution_status_enum` NN), `started_at` (timestamptz null), `completed_at` (timestamptz null), `duration_ms` (bigint null), `attempt` (int NN default 1), `last_error` (text null), `input_artifacts` (jsonb NN default `'[]'`), `output_artifacts` (jsonb NN default `'[]'`), `payload` (jsonb NN default `'{}'`), `workflow_id` (varchar255 NN), `agent_task_id` (UUID FK→`agent_task.id` ON DELETE SET NULL, null), `gate_id` (UUID null).
CHECK constraints: `(step_kind='agent') = (agent_task_id IS NOT NULL)` and `(step_kind='gate') = (gate_id IS NOT NULL)`. ⚠️ For git activities `step_kind='git'` → BOTH `agent_task_id` and `gate_id` MUST be NULL (else INSERT violates a CHECK). The git path always passes both as None (`_emit_git_start` never sets them) — correct by construction.
Enums: `step_execution_kind_enum` = {agent, git, gate, code, terminal}; `step_execution_status_enum` = {queued, running, completed, failed, timed_out, skipped, escalated, abandoned}.

### 6a. INSERT — `_emit_git_start` → `emit_execution_record`

`_emit_git_start(ctx, *, repo, operation, branch="", paths=None)` (`git_operations.py:54-101`):
- If `ctx is None` → return `None` (no row; legacy call sites that pass no `execution_context` skip emission entirely).
- `workflow_id`/`attempt` from `activity.info()`; if unavailable (unit-test) → `workflow_id=""`, `attempt=1`.
- `input_artifacts = resolve_input_artifacts(ctx.input_artifact_paths, repo=repo, ref=branch or "main")` — binds each Layer-A declared path string to a `StepArtifactRef(repo, ref, path)`; `{placeholder}` tokens substituted only if a `substitutions` dict is passed (here none, so raw declared paths, ⚠️ unresolved placeholders pass through verbatim so the stepper can flag them).
- `payload = {"operation": operation, "repo": repo, "branch": branch, "paths": paths or []}`.
- Calls `emit_execution_record(EmitExecutionRecordInput(portfolio_id=ctx.portfolio_id, line_id=ctx.line_id, step_id=ctx.step_id, step_kind=StepKind.GIT, workflow_id=workflow_id, app_id=ctx.app_id or None, wave_id=ctx.wave_id or None, attempt=attempt, input_artifacts=input_artifacts, payload=payload, status=ExecutionStatus.RUNNING))`. ⚠️ `ctx.app_id or None` and `ctx.wave_id or None` convert empty-string dataclass defaults to SQL NULL.

`emit_execution_record` (`execution.py:150-219`):
- `execution_id = uuid.uuid4()` (generated app-side, NOT the column default). `started_at = input.started_at or datetime.now(timezone.utc)`.
- UUID coercion via `_parse_uuid` (`execution.py:136-142`): `None`/`""` → None; invalid → None (NOT an error).
- ⚠️ **Guard:** `if portfolio_uuid is None: log warning + return None` (no INSERT). A non-UUID `portfolio_id` silently skips the row.
- INSERT (exact SQL, `execution.py:179-208`):
```sql
INSERT INTO step_execution (
    execution_id, app_id, wave_id, portfolio_id,
    line_id, step_id, step_kind, status,
    started_at, attempt, input_artifacts, payload,
    workflow_id, agent_task_id, gate_id
) VALUES ($1,$2,$3,$4, $5,$6,$7,$8, $9,$10,$11::jsonb,$12::jsonb, $13,$14,$15)
```
  Bind values: `$1`=execution_id (uuid), `$2`=app_uuid, `$3`=wave_uuid, `$4`=portfolio_uuid, `$5`=line_id, `$6`=step_id, `$7`=step_kind.value (`"git"`), `$8`=status.value (`"running"`), `$9`=started_at, `$10`=attempt, `$11`=`json.dumps([a.to_dict() for a in input_artifacts])`, `$12`=`json.dumps(payload or {})`, `$13`=workflow_id, `$14`=agent_task_uuid (None for git), `$15`=gate_uuid (None for git).
- Returns `execution_id` on success, `None` on ANY exception (logged warning, swallowed).

**Column-by-column INSERT mapping (artifact/source field → table.column):**

| step_execution column | source value | default / condition |
|---|---|---|
| `execution_id` | `uuid.uuid4()` (app-generated) | always set on INSERT (overrides column `gen_random_uuid()` default) |
| `app_id` | `_parse_uuid(ctx.app_id or None)` | NULL if app_id empty/invalid (wave-scoped rows) |
| `wave_id` | `_parse_uuid(ctx.wave_id or None)` | NULL if wave_id empty/invalid (per-app rows) |
| `portfolio_id` | `_parse_uuid(ctx.portfolio_id)` | **REQUIRED**: if None → whole INSERT skipped (no row) |
| `line_id` | `ctx.line_id` | always |
| `step_id` | `ctx.step_id` | always |
| `step_kind` | `StepKind.GIT.value` = `"git"` | constant for all 3 storage activities |
| `status` | `ExecutionStatus.RUNNING.value` = `"running"` | constant at start |
| `started_at` | `input.started_at or now(utc)` | always |
| `attempt` | `activity.info().attempt` (else 1) | Temporal retry counter |
| `input_artifacts` | `json.dumps([ref.to_dict() …])` ::jsonb | from `resolve_input_artifacts(ctx.input_artifact_paths, repo, ref=branch or "main")`; `[]` if none |
| `payload` | `json.dumps({"operation","repo","branch","paths"})` ::jsonb | `operation`∈{read_artifact, write_artifact, write_artifacts_batch}; `paths`=[input.path] or full batch list |
| `workflow_id` | `activity.info().workflow_id` (else `""`) | always |
| `agent_task_id` | None | NEVER set on git rows (CHECK requires NULL when kind≠agent) |
| `gate_id` | None | NEVER set on git rows (CHECK requires NULL when kind≠gate) |
| `completed_at`, `duration_ms`, `last_error`, `output_artifacts` | not in INSERT | rely on column defaults: `output_artifacts`=`'[]'`, others NULL |

`StepArtifactRef.to_dict()` (`execution.py:91-99`): `{"repo":…, "ref":…, "path":…}` and adds `"content_hash"` **only if** `content_hash is not None`. `StepArtifactRef` is `@dataclass(frozen=True)` with `repo, ref, path, content_hash=None`.

### 6b. UPDATE — `_emit_git_complete` → `update_execution_record`

`_emit_git_complete(execution_id, *, output_paths=None, repo="", commit_sha="", pr_number=None, pr_url="", branch="", status=COMPLETED, error=None)` (`git_operations.py:104-138`):
- If `execution_id is None` → return (no-op; covers ctx-None and INSERT-skip cases).
- Builds `payload_merge`: `if commit_sha: payload_merge["commit_sha"]=commit_sha`; `if pr_number is not None: payload_merge["pr_number"]=pr_number`; `if pr_url: payload_merge["pr_url"]=pr_url`. ⚠️ For the 3 storage activities only `commit_sha` is ever set (pr_* unused — those belong to create_pr/merge_pr). On the FAILED path `commit_sha=""` so `payload_merge` stays `{}` → passed as `None`.
- Builds `output_artifacts`: **only if `output_paths AND repo`** → `[StepArtifactRef(repo=repo, ref=branch or commit_sha or "main", path=p) for p in output_paths]`. ⚠️ `ref` precedence: `branch`, then `commit_sha`, then literal `"main"`. On FAILED path no `output_paths` passed → `output_artifacts=None` (column untouched).
- Calls `update_execution_record(execution_id, status=status, output_artifacts=output_artifacts, payload_merge=payload_merge or None, last_error=error)`.

`update_execution_record(execution_id, *, status, completed_at=None, output_artifacts=None, payload_merge=None, last_error=None)` (`execution.py:222-275`):
- `if execution_id is None: return`. `completed = completed_at or now(utc)`. `out_artifacts = [a.to_dict() …] if output_artifacts else None`.
- UPDATE (exact SQL, `execution.py:250-267`):
```sql
UPDATE step_execution
   SET status = $2,
       completed_at = $3,
       duration_ms = EXTRACT(EPOCH FROM ($3 - started_at)) * 1000,
       output_artifacts = COALESCE($4::jsonb, output_artifacts),
       payload = payload || COALESCE($5::jsonb, '{}'::jsonb),
       last_error = COALESCE($6, last_error)
 WHERE execution_id = $1
```
  Binds: `$1`=execution_id, `$2`=status.value, `$3`=completed, `$4`=`json.dumps(out_artifacts) if out_artifacts is not None else None`, `$5`=`json.dumps(payload_merge) if payload_merge else None`, `$6`=last_error.
- Swallows all exceptions (logged warning).

**Column-by-column UPDATE mapping (terminal state):**

| step_execution column | set to | condition / default |
|---|---|---|
| `status` | `$2` = `ExecutionStatus.{COMPLETED\|FAILED}.value` | COMPLETED on success, FAILED on except path |
| `completed_at` | `$3` = `completed_at or now(utc)` | always |
| `duration_ms` | `EXTRACT(EPOCH FROM ($3 - started_at)) * 1000` | computed in SQL from row's `started_at` (ms) |
| `output_artifacts` | `COALESCE($4::jsonb, output_artifacts)` | **only overwritten when `output_paths AND repo` given** (success path); FAILED path leaves prior `'[]'` |
| `payload` | `payload \|\| COALESCE($5::jsonb, '{}'::jsonb)` | **shallow JSONB merge** (`\|\|`); adds `commit_sha` on success; `{}`-merge (no-op) on FAILED (commit_sha empty) |
| `last_error` | `COALESCE($6, last_error)` | set to `str(exc)` on FAILED path; on success `error=None` → keeps prior (NULL) |

⚠️ `output_artifacts` ref value per activity (success path, `git_operations.py:128`): `StepArtifactRef(repo=input.repo, ref=branch or commit_sha or "main", path=p)`.
  - `read_artifact`: `_emit_git_complete(... branch=input.branch, commit_sha=result.commit_sha, output_paths=[result.path])` → ref = `input.branch` (or sha/main).
  - `write_artifact`: `branch=result.branch, commit_sha=result.commit_sha, output_paths=[result.path]` → ref = `result.branch`.
  - `write_artifacts_batch`: `branch=result.branch, commit_sha=result.commit_sha, output_paths=paths` (ALL input paths) → one ref per path.
⚠️ `payload` merge: success adds `{"commit_sha": <sha>}` shallow-merged into the existing `{"operation","repo","branch","paths"}`. FAILED path adds nothing (commit_sha=""), so `payload` keeps its RUNNING-state contents and only `status`/`completed_at`/`duration_ms`/`last_error` change.

**Target tables + approx columns mapped (projection summary):** ONE table — `step_execution` — 20 columns total; INSERT touches 15 explicit (execution_id, app_id, wave_id, portfolio_id, line_id, step_id, step_kind, status, started_at, attempt, input_artifacts, payload, workflow_id, agent_task_id, gate_id), UPDATE touches 6 (status, completed_at, duration_ms, output_artifacts, payload, last_error). `validate_artifact_against_schema` writes NO table.

---

# 7. GOTCHA digest (consolidated)

1. ⚠️ Three of the four "artifact" activities (read/write/batch) are NOT in `artifact_validation.py` — they're in `git_operations.py`; the actual storage logic is in `GitService` (`olympus-api/src/services/git_service.py`), container-copied to be importable as `src.git_service`. A rebuild that puts everything in one file or stubs GitService loses all GitHub-API behavior.
2. ⚠️ `foundry_activity` classifies `GitServiceError` (and subclasses) as **non-retryable** (not ApplicationError, no retryable type-name match). Combined with GitService catching all GithubExceptions, a transient GitHub 5xx is effectively NOT auto-retried by the wrapper — retry depends entirely on the workflow's `retry_policy=` and Temporal's NonRetryableError handling (which won't retry). Net: storage activities are practically single-shot per workflow attempt for GitHub-side failures.
3. ⚠️ `validate_artifact_against_schema` returns a result for ALL validation outcomes and raises ONLY `NonRetryableError` for a missing schema file. The advisory caller catches `ActivityError` and proceeds; the strict caller treats `validated=False OR errors` as fatal. Escalation policy is the CALLER's, not the activity's.
4. ⚠️ `parse_agent_json` accepts dict OR list, but the validator's `isinstance(parsed, dict)` guard rejects top-level lists → `validated=False`. Three-tier fallback (clean → fence-strip → balanced-brace-scan) must be reproduced byte-for-byte (regex `^\s*```(?:json|jsonc)?\s*\n(.*?)\n```\s*$` with DOTALL; string-aware brace scanner).
5. ⚠️ `_resolve_schemas_dir()` uses `parents[3]` which is correct for the dev tree but WRONG for a wheel install — env var `OLYMPUS_SCHEMAS_DIR` + `/app/schemas` + `/app/repo/schemas` are the production resolution; fallback returns the (possibly missing) parents[3] path so the error message is informative.
6. ⚠️ `_SCHEMA_REGISTRY` is evaluated at import using the module-level `_SCHEMAS_DIR` snapshot. Changing `OLYMPUS_SCHEMAS_DIR` after import has no effect. 41 entries; `portfolio-redundancy-matrix.json` maps to `rationalization-clustering-plan.schema.json` (NOT redundancy-matrix) despite the filename — migration 052 remap. `intra-app-redundancy.json` and `redundancy-matrix.json` share one schema; `ea-compliance-report.json`+`ea-compliance.json` share one; `api-contract-compliance-report.json`+`integration-arch.json` share one.
7. ⚠️ `step_execution` projection is best-effort and swallows all DB exceptions — never breaks the activity. `portfolio_id` must be a valid UUID or the INSERT is silently skipped (returns None → all later `_emit_git_complete` calls no-op).
8. ⚠️ CHECK constraints force `agent_task_id` and `gate_id` to be NULL for `step_kind='git'`; the git helpers never set them — do NOT add them in a rebuild or INSERTs will fail.
9. ⚠️ `payload` UPDATE uses JSONB `||` shallow merge — the RUNNING-state `{operation,repo,branch,paths}` keys persist and `commit_sha` is added on success; FAILED path merges `{}` (no-op).
10. ⚠️ `write_artifact` create-or-update: tries `get_contents`+`update_file` FIRST, falls back to `create_file` ONLY on 404. Re-committing identical content can 422 (non-404) → `GitServiceError`.
11. ⚠️ `write_artifacts_batch` uses the Git-Data API (blob/tree/commit/ref) for ONE commit; `base_ref.edit()` is a non-force fast-forward → unsafe under concurrent writers to the same branch (assumes branch-per-task single writer). Empty `files` → `GitServiceError`. Result returns ALL input paths, not just the first.
12. ⚠️ `_ensure_branch` swallows a 422 on branch-create (race-tolerant) but re-raises a non-404 GithubException RAW on the existence check (escapes GitService's GitServiceError wrapping; still wrapped to NonRetryableError by foundry_activity).
13. ⚠️ `read_file` with empty `commit_sha` issues a SECOND GitHub call (`get_branch`) to populate `commit_sha` with the branch TIP — not the file's last-modifying commit. Content is always UTF-8 decoded (no binary support).
14. ⚠️ Merge error classes (`MergeConflict`/`MergeDivergenceUnresolved`/`MergeBranchProtectionRejected`, all subclass `GitServiceError`) are NOT raised by these storage activities (only by merge methods) but their class-name strings must be wired into `RETRY_POLICIES["git_merge"].non_retryable_error_types` for the merge activities (Temporal matches on the class name string, not the type).
