# Activity Group Spec — `line_transitions.py` Part 1: Discovery decomposition / side-effects / capability-catalog projections

**Source file:** `/Users/pnunna/Documents/GitHub/foundry/temporal/olympus_workflows/activities/line_transitions.py`
**HEAD:** `7cb3b20c`. **Line numbers REFRESHED to HEAD** (see ⚠️ shift note). **This file OWNS lines 408–1804** (Discovery decomp/side-effects/capability-catalog; the rat-cap region begins at 1804). Three reproduced persist/projection activities live in that span:

| Activity | Def line | Kind | Returns | Tables/columns written |
|---|---|---|---|---|
| `persist_decomposition_map` | 408 | code/projection | `None` | `application.decomposition_map`, `application.updated_at` |
| `persist_discovery_side_effects` | 1263 | code/projection | `None` | up to 14 `application` columns + `application.metadata` (JSONB merge) + always `updated_at` |
| `persist_capability_catalog` | 1415 | code/grain-UPSERT | `PersistCapabilityCatalogOutput` | `system`, `system_application`, `business_domain`, `capability`, `capability_business_domain` |

> ⚠️ **HEAD `7cb3b20c` line-shift note (citations CORRECTED from prior baseline).** `line_transitions.py` grew by +162 lines via two upstream insertions. Symbols at/below line 1144 shifted by +115 (e.g. `_merge_application_metadata` 1058→**1173**, `_build_update_sql` 1111→**1226**, `persist_discovery_side_effects` 1148→**1263**, `persist_capability_catalog` 1300→**1415**). The `_extract_*` extractors (486–785), `_extract_discovery_compliance_metadata` (922), and the column registries (791–919) did NOT move. **`types.py` also grew** (new DevSecOps dataclasses): the dataclass citations below are CORRECTED (`PersistDecompositionMapInput` 1296→**1364**, `PersistDiscoverySideEffectsInput` 1314→**1382**, `PersistCapabilityCatalogInput` 1347→**1415**, `PersistCapabilityCatalogOutput` 1378→**1446**, `StepExecutionContext` 531→**532**). Bodies are behaviorally UNCHANGED — only citations moved.

> Lines 1804–2047 (`_rat_cap_*` schema helpers + `load_wave_rationalization_capabilities` at 1883) and 2048+ (`persist_rationalization_capabilities` at 2049) are **NOT reproduced here** — sibling spec owns them. Helpers `_try_parse_json` (281), `_dedupe_str_list` (300), `_extract_decomposition` (311), and all the `_extract_*_side_effects` extractors (486–785), `_merge_application_metadata` (1173), `_build_update_sql` (1226), and the `_SIDE_EFFECT_COLUMNS`/`_JSONB_COLUMNS`/`_NATIVE_COLUMNS` tuples (791–919) **ARE reproduced** here because the three owned activities call them. Module-level constants/helpers above 408 (`_db_url`, `_temporal_host`, `_LINE_TO_WORKFLOW`, `start_next_line_workflow`, `fetch_application_source_repos`) are sibling-owned but `_db_url`, `_try_parse_json`, `_dedupe_str_list`, `_extract_decomposition` are duplicated here verbatim because they are load-bearing for the owned activities.

---

## 0. The `@foundry_activity` decorator (capture once; applies to ALL THREE activities)

Source: `/private/var/folders/qs/dwcdl18n351cyz88x2tc9w3w0000gp/T/tmp.2xQMcqnDWM/foundry_temporal/activities.py:107-165`.

All three activities are decorated EXACTLY:
```python
@foundry_activity(config=ActivityConfig(enable_observability=True))
```
`ActivityConfig` (activities.py:27-39) defaults: `retry_policy=None`, all timeouts `None`, `enable_observability=True`, `enable_error_wrapping=True`, `log_inputs=False`, `log_outputs=False`. The call passes only `enable_observability=True` (already the default), so **`enable_error_wrapping=True` is in force**.

`foundry_activity(config, name=None, **activity_kwargs)` returns a decorator that:
1. Applies `@activity.defn(name=name, **activity_kwargs)` with `@wraps(func)`. **`name=None` ⇒ Temporal activity name = the Python function name** (`persist_decomposition_map`, `persist_discovery_side_effects`, `persist_capability_catalog`). A rebuild MUST register under those exact names.
2. On entry (observability on): `get_logger().info(f"Activity {activity_name} starting", extra={"inputs": args if log_inputs else None})`. `log_inputs=False` ⇒ `inputs=None` (the JSON arg blobs are NOT logged at this layer).
3. `await func(...)`; on success logs `"Activity {name} completed"` with `extra={"outputs": result if log_outputs else None}` (`log_outputs=False` ⇒ `outputs=None`).
4. **On exception (error wrapping on):**
   - `isinstance(error, (WorkflowError, ApplicationError))` → **re-raise unchanged** (`raise`). `NonRetryableError`/`RetryableError` subclass `WorkflowError` (errors.py:9-28), so any `NonRetryableError` these activities throw passes through with its `non_retryable=True` flag intact.
   - else if `_is_retryable_error(error)` → wrap as `RetryableError(f"Retryable error in {name}: {error}")` (Temporal will retry).
   - else → wrap as `NonRetryableError(f"Non-retryable error in {name}: {error}")` (Temporal will NOT retry).
   - `_is_retryable_error` (activities.py:168-183): lowercases `str(type(error))` and returns True if it contains any of `timeout, connection, network, temporary, unavailable, overload, busy, throttle, rate_limit`. ⚠️ It inspects the **type repr string**, not the message. `asyncpg.exceptions.ConnectionDoesNotExistError`, `...PostgresConnectionError`, `ConnectionError` → match on `connection` ⇒ **retryable**. A generic `asyncpg.PostgresError` / `KeyError` / `ValueError` ⇒ **non-retryable**.

⚠️ **GOTCHA — interaction with each activity's own try/except:** Each of the three activities wraps its body in `try: … except Exception as exc: await emit_code_step_complete(exec_id, status=FAILED, error=str(exc)); raise`. The bare `raise` re-raises the ORIGINAL exception, which THEN hits the decorator's wrapper and gets classified/wrapped per the rules above. So the FAILED `step_execution` record is written with the raw error string, but the exception that propagates to Temporal is the wrapped `RetryableError`/`NonRetryableError` (or the unchanged `WorkflowError`). A rebuild using plain `@activity.defn` loses BOTH the wrapping and the retry classification.

⚠️ **GOTCHA — `NonRetryableError` for bad UUIDs is intentional + observability-coupled:** All three raise `NonRetryableError(f"Invalid app_id: {input.app_id!r}")` on a malformed UUID. Because this is a `WorkflowError`, the decorator re-raises it (no double-wrap). BUT note this raise happens INSIDE the activity's own `try`, so the `except Exception` clause first writes a FAILED step record and THEN re-raises. The callers (DiscoveryWorkflow) wrap these in best-effort try/except so the workflow continues — see §Caller contract.

---

## 1. Shared module-level helpers (reproduced; load-bearing)

### 1.1 `_db_url()` (line 88-94)
```python
def _db_url() -> str:
    host = os.environ.get("DATABASE_HOST", "localhost")
    port = os.environ.get("DATABASE_PORT", "5432")
    user = os.environ.get("DATABASE_USER", "olympus")
    password = os.environ.get("DATABASE_PASSWORD", "olympus")
    db = os.environ.get("DATABASE_NAME", "olympus")
    return f"postgresql://{user}:{password}@{host}:{port}/{db}"
```
Every activity opens a **fresh `asyncpg.connect(_db_url())`** per DB phase and closes it in `finally`. No pooling, no SQLAlchemy session. (Identical to `utils/execution.py:_db_url`.)

### 1.2 `_try_parse_json(text) -> dict | None` (line 281-297)
Best-effort parse of agent output strings:
1. Empty/falsy `text` → `None`.
2. `json.loads(text)`; on `JSONDecodeError`, find first `{` (`text.find("{")`) and last `}` (`text.rfind("}")`); if `start == -1 or end <= start` → `None`; else `json.loads(text[start:end+1])`; on second failure → `None`.
3. Return `value` only if it `isinstance(value, dict)`, else `None`. ⚠️ A JSON array or scalar parses fine but returns `None` (callers expect dicts only).

### 1.3 `_dedupe_str_list(xs) -> list[str]` (line 300-308)
De-dupe preserving first-seen order via a `seen: set`. Used by `_extract_decomposition` for `integrations` and `tech_stack`.

---

## 2. ACTIVITY: `persist_decomposition_map` (line 408)

### 2.1 Signature
```python
@foundry_activity(config=ActivityConfig(enable_observability=True))
async def persist_decomposition_map(input: PersistDecompositionMapInput) -> None
```

### 2.2 Input type — `PersistDecompositionMapInput` (types.py:1364-1378)
| Field | Type | Default | Notes |
|---|---|---|---|
| `app_id` | `str` | — (required) | parsed to `uuid.UUID`; bad value ⇒ `NonRetryableError` |
| `catalog_json` | `str` | `""` | raw JSON string of the catalog pass (already committed to Git) |
| `synthesis_json` | `str` | `""` | raw JSON string of the synthesis pass |
| `execution_context` | `StepExecutionContext \| None` | `None` | observability emission context |

`StepExecutionContext` (types.py:532-554): `portfolio_id: str` (required), `line_id: str`, `step_id: str`, `app_id: str=""`, `wave_id: str=""`, `input_artifact_paths: list[str]=[]`, `gate_id: str=""`.

### 2.3 Output
`None`. Observability is the only "output" (the `decomposition_map` column write + the `step_execution` record).

### 2.4 Control flow (reproduce exactly)
1. `exec_id = await emit_code_step_start(input.execution_context, function_name="persist_decomposition_map")` (see §6). Returns a `uuid.UUID` or `None` (best-effort; `None` if `execution_context is None` or the insert failed).
2. **Open outer `try` whose `except` writes the FAILED record:**
   ```python
   try:
       try: app_uuid = uuid.UUID(input.app_id)
       except (ValueError, TypeError) as exc: raise NonRetryableError(f"Invalid app_id: {input.app_id!r}") from exc
       catalog = _try_parse_json(input.catalog_json)
       synthesis = _try_parse_json(input.synthesis_json)
       decomposition = _extract_decomposition(catalog, synthesis)
       if not decomposition:
           logger.info("persist_decomposition_map: nothing extractable from agent output", extra={"app_id": input.app_id})
           await emit_code_step_complete(exec_id, columns_written=[])
           return
       conn = await asyncpg.connect(_db_url())
       try:
           await conn.execute(<UPDATE>, json.dumps(decomposition), datetime.now(timezone.utc), app_uuid)
       finally:
           await conn.close()
       logger.info("decomposition_map persisted", extra={...counts...})
       await emit_code_step_complete(exec_id, columns_written=["decomposition_map", "updated_at"])
   except Exception as exc:
       await emit_code_step_complete(exec_id, status=ExecutionStatus.FAILED, error=str(exc))
       raise
   ```

⚠️ **GOTCHA — empty-extraction is a SUCCESS, not a no-op skip:** When `_extract_decomposition` returns `{}` (no modules/integrations/tech_stack found in either JSON), the activity logs, marks the step **COMPLETED** with `columns_written=[]`, and `return`s WITHOUT touching the DB. `decomposition_map` stays NULL. This is distinct from a FAILED record.

### 2.5 `_extract_decomposition(catalog, synthesis) -> dict` (line 311-404) — REPRODUCE FULLY
Maps both shapes (W19 catalog-application AND legacy dependency-mapper) onto the 3 fields the Insights API reads. Iterate `for source in (catalog or {}, synthesis or {})` — i.e. catalog first, synthesis second, accumulating into shared `modules`, `integrations`, `tech_stack` lists:

**Per source:**
- `arch = source.get("architecture")`; if `isinstance(arch, dict)`:
  - `mods = arch.get("major_components") or arch.get("components")`; if list: each item — if `dict` with truthy `"name"` → append `{"name": str(m["name"])}`; elif `str` → append `{"name": m}`.
  - `ints = arch.get("integrations")`; if list: each — if `str` → append; elif `dict` with `"name"` → append `str(i["name"])`.
- `mods = source.get("modules") or source.get("components")`; if list: same module-append rule as above (this runs IN ADDITION to the `architecture.*` harvest — both can contribute; dedupe is NOT applied to modules).
- `ints = source.get("integrations") or source.get("external_systems")`; if list: same integration-append rule.
- `ts = source.get("tech_stack") or source.get("technologies") or source.get("stack")`:
  - if `list`: each — `str` → append; `dict` with `"name"` → append `str(t["name"])`.
  - elif `dict`: for each `key, value` — if `value` is a `list`: each item `str`→append, `dict` w/ `"name"`→append `str(item["name"])`; elif `value` truthy (non-list): append `f"{key}: {value}"`.

**Assemble output:** `out = {}`; if `modules`: `out["modules"] = modules` (NO dedupe — modules kept as-is, possible dupes); if `integrations`: `out["integrations"] = _dedupe_str_list(integrations)`; if `tech_stack`: `out["tech_stack"] = _dedupe_str_list(tech_stack)`. Return `out`.

### 2.6 SQL written
```sql
UPDATE application
SET decomposition_map = $1,   -- json.dumps(decomposition)  → JSONB
    updated_at = $2           -- datetime.now(timezone.utc)
WHERE id = $3                 -- app_uuid (uuid.UUID, native)
```
Params order: `(json.dumps(decomposition), datetime.now(timezone.utc), app_uuid)`.

### 2.7 Column mapping table
| Artifact field (after `_extract_decomposition`) | DB target | Default / condition |
|---|---|---|
| `{"modules": [{"name":…}], "integrations":[str], "tech_stack":[str]}` (the WHOLE dict, `json.dumps`'d) | `application.decomposition_map` (JSONB, nullable, from migration 002:93) | Only written when `decomposition` is non-empty; missing sub-keys simply absent from the JSON |
| (n/a) | `application.updated_at` (TIMESTAMPTZ NOT NULL, 002:102) | Always set to `datetime.now(timezone.utc)` when the UPDATE runs |

### 2.8 Errors / retries / idempotency
- Bad UUID → `NonRetryableError` (re-raised by decorator unchanged). DB-connection failures → decorator classifies as **retryable** (type repr contains `connection`). Generic DB errors → non-retryable.
- **Idempotent:** a full-overwrite UPDATE keyed on PK; re-running with the same artifacts produces the same `decomposition_map`. (No `WHERE` guard on prior value — it clobbers.)
- App-not-found: the UPDATE silently affects 0 rows (no error). Not detected.

---

## 3. ACTIVITY: `persist_discovery_side_effects` (line 1263)

### 3.1 Signature
```python
@foundry_activity(config=ActivityConfig(enable_observability=True))
async def persist_discovery_side_effects(input: PersistDiscoverySideEffectsInput) -> None
```

### 3.2 Input type — `PersistDiscoverySideEffectsInput` (types.py:1382-1413)
| Field | Type | Default | Owner pass |
|---|---|---|---|
| `app_id` | `str` | — | — |
| `catalog_json` | `str` | `""` | catalog-application |
| `structural_json` | `str` | `""` | structural-analysis |
| `business_logic_json` | `str` | `""` | business-logic-extraction |
| `quality_risk_json` | `str` | `""` | quality-risk-assessment |
| `ux_accessibility_json` | `str` | `""` | ux-accessibility |
| `synthesis_json` | `str` | `""` | **no projected side effects** (artifact only — never parsed) |
| `tco_json` | `str` | `""` | tco-baseline |
| `execution_context` | `StepExecutionContext \| None` | `None` | — |

⚠️ `synthesis_json` is in the dataclass but the activity body NEVER reads it (it is committed-to-Git-only). Do not project from it.

### 3.3 Output
`None`.

### 3.4 Control flow (reproduce exactly)
```python
exec_id = await emit_code_step_start(input.execution_context, function_name="persist_discovery_side_effects")
try:
    try: app_uuid = uuid.UUID(input.app_id)
    except (ValueError, TypeError) as exc: raise NonRetryableError(f"Invalid app_id: {input.app_id!r}") from exc

    parsed = {
        "catalog":          _try_parse_json(input.catalog_json),
        "structural":       _try_parse_json(input.structural_json),
        "business_logic":   _try_parse_json(input.business_logic_json),
        "quality_risk":     _try_parse_json(input.quality_risk_json),
        "ux_accessibility": _try_parse_json(input.ux_accessibility_json),
        "tco":              _try_parse_json(input.tco_json),
    }
    projections: dict[str, Any] = {}
    projections.update(_extract_catalog_side_effects(parsed["catalog"]))
    projections.update(_extract_structural_side_effects(parsed["structural"]))
    projections.update(_extract_business_logic_side_effects(parsed["business_logic"]))
    projections.update(_extract_quality_side_effects(parsed["quality_risk"]))
    projections.update(_extract_ux_side_effects(parsed["ux_accessibility"]))
    projections.update(_extract_tco_side_effects(parsed["tco"]))

    compliance_metadata = _extract_discovery_compliance_metadata(parsed["quality_risk"], parsed["ux_accessibility"])

    if not projections and not compliance_metadata:
        logger.info("persist_discovery_side_effects: nothing extractable from Discovery artifacts", extra={"app_id": input.app_id})
        await emit_code_step_complete(exec_id, columns_written=[])
        return

    conn = await asyncpg.connect(_db_url())
    try:
        if projections:
            sql, params = _build_update_sql(projections)
            params.append(app_uuid)
            await conn.execute(sql, *params)
        if compliance_metadata:
            await _merge_application_metadata(conn, app_uuid, "compliance", compliance_metadata)
    finally:
        await conn.close()
    columns_written = sorted(projections.keys())
    if compliance_metadata:
        columns_written.append("metadata.compliance")
    await emit_code_step_complete(exec_id, columns_written=columns_written)
except Exception as exc:
    await emit_code_step_complete(exec_id, status=ExecutionStatus.FAILED, error=str(exc))
    raise

logger.info("discovery side-effects persisted", extra={"app_id": input.app_id, "columns_written": sorted(projections.keys())})
```

⚠️ **GOTCHA — `_merge_application_metadata` ALWAYS fires for Discovery:** `_extract_discovery_compliance_metadata` ALWAYS returns a non-empty block (it seeds `status="pending-ato"`, `cato_state="not-started"`, `source_line="Discovery"` unconditionally). So `compliance_metadata` is never empty for this activity — the `metadata.compliance` namespace is written on EVERY successful run even when no column projections exist. The `if not projections and not compliance_metadata` early-return is effectively `if not projections` here, but coded defensively.

⚠️ **GOTCHA — two SEPARATE statements, NOT one transaction:** The projection UPDATE and the metadata merge run as two `conn.execute` calls on the same connection with **no explicit `conn.transaction()`** wrapper. asyncpg auto-commits each statement. If the merge fails after the UPDATE committed, the columns are written but `metadata.compliance` is not — partial state is possible. (Contrast with `persist_capability_catalog`, which DOES wrap in `async with conn.transaction()`.)

⚠️ **GOTCHA — the final `logger.info` runs OUTSIDE the try/except** (it is dedented, after the `except…raise`). It is unreachable on failure (the `raise` exits first) and references `projections` which is always bound on the success path. On the early-return path it does not execute. This is only reached on full success.

### 3.5 Extractor helpers — REPRODUCE EACH (lines 486-785)

These feed `projections`. **`.update()` ordering matters:** catalog → structural → business_logic → quality → ux → tco. Later writers overwrite earlier keys on collision. The only real collision risk is `architecture` (none — catalog writes `archetype` enum + JSONB blobs, structural writes `architecture`). Keys are flat strings matching `_SIDE_EFFECT_COLUMNS`.

#### `_extract_catalog_side_effects(catalog)` (486-534)
Guard: `if not isinstance(catalog, dict): return {}`. Build `out`:
| Source key | Condition | `out` key (→ column) |
|---|---|---|
| `description` (str) | `.strip()` truthy | `description` = stripped → `application.description` *(see column note)* |
| `business_domain` (str) | `.strip()` truthy | `business_domain` = stripped → `application.business_domain` (VARCHAR 255) |
| `tech_stack` (dict) | non-empty dict | `tech_stack` = dict → `application.tech_stack` (JSONB) |
| `size_metrics` (dict) | non-empty dict | `size_metrics` = dict → `application.size_metrics` (JSONB) |
| `complexity_tier` (str) | value in `{"simple","moderate","complex"}` | `complexity_tier` → `application.complexity_tier` (complexity_tier_enum) |
| `safety_tier` (str) | value in `{"T1","T2","T3"}` | `safety_tier` → `application.safety_tier` (VARCHAR 8) |
| `architecture.archetype` (str) | `architecture` is dict AND `archetype` in `{"web-app","batch","api","scheduled-job","hybrid"}` | `archetype` → `application.archetype` (archetype_enum) |

⚠️⚠️ **CRITICAL ENUM-MISMATCH GOTCHA (archetype):** The code accepts archetype values `{"web-app", "batch", "api", "scheduled-job", "hybrid"}` (line 529-531), but the DB `archetype_enum` (migration 021:37-40) only permits `{'web-app', 'batch-etl', 'api-service', 'scheduled-job', 'hybrid'}`. Values `"batch"` and `"api"` pass the Python guard but **violate the enum constraint** → the UPDATE raises an asyncpg `InvalidTextRepresentationError`/`DataError`. Per the decorator's `_is_retryable_error`, that type repr contains neither retry keyword → classified **non-retryable**, the whole activity FAILs (and its FAILED step record is written). So only `web-app`, `scheduled-job`, `hybrid` round-trip safely; `batch`/`api` are latent landmines. Reproduce the code's `{"web-app","batch","api","scheduled-job","hybrid"}` set exactly (do NOT "fix" it to match the enum — behavioral parity means preserving the bug).

⚠️ Note: `description` is referenced as a column but is NOT in migration 002's `application` table (002 has no `description` column). It IS in `_SIDE_EFFECT_COLUMNS[0]`. A later migration (>028) must add `application.description`; if absent, projecting `description` raises `UndefinedColumnError`. Treat `application.description` (TEXT, nullable) as a required column for the rebuild.

#### `_extract_structural_side_effects(structural)` (537-561)
Guard `isinstance dict` else `{}`. Build `architecture: dict`:
- `mc = structural.get("major_components") or structural.get("modules")`; if `list` and non-empty → `architecture["major_components"] = mc` (the raw list, verbatim).
- `integrations = structural.get("integrations") or structural.get("external_systems")`; if `list` and non-empty → `architecture["integrations"] = integrations`.
- Return `{"architecture": architecture}` if `architecture` truthy else `{}`. → `application.architecture` (JSONB).

#### `_extract_business_logic_side_effects(bl)` (564-604)
Guard `dict` else `{}`.
- `rules = bl.get("rules") or bl.get("business_rules")`.
- If `rules` is `list`: `rule_count = len(rules)`; `critical_count = sum(1 for r in rules if isinstance(r,dict) and r.get("severity")=="critical")`.
- Else (not a list): try precomputed — `rc = bl.get("rule_count")` (use if `int`), `cc = bl.get("critical_rules_count")` (use if `int`).
- If `rule_count is None` → return `{}`.
- Return `{"business_logic": {"rule_count": rule_count, "critical_rules_count": critical_count or 0}}` → `application.business_logic` (JSONB). ⚠️ `critical_count or 0` coerces `None`/`0` to `0`.

#### `_extract_quality_side_effects(qr)` (607-688)
Guard `dict` else `{}`. Build `quality: dict`:
- `debt = qr.get("technical_debt_score")`; if `int|float` → `quality["technical_debt_score"] = float(debt)`.
- `coverage = qr.get("test_coverage")`:
  - if `int|float` → `quality["test_coverage"] = float(coverage)`.
  - elif `dict`: `overall = coverage.get("overall") or coverage.get("average")`; if `int|float` → `float(overall)`; else `per_module = coverage.get("per_module") or coverage`; if `per_module` is `dict`, collect `scores`: for each value `v` — if `int|float` → `float(v)`; elif `dict` → `line = v.get("line") or v.get("percent")`; if `int|float` → `float(line)`. If `scores` non-empty → `quality["test_coverage"] = sum(scores)/len(scores)` (unweighted mean — docstring says "weighted" but code is a plain average; reproduce the average).
- `vulns = qr.get("vulnerabilities")`; if `list`: build `severity_counts: dict[str,int]` — for each `dict` v, `sev = str(v.get("severity","unknown")).lower()`, increment. If non-empty → `quality["vulnerabilities_summary"] = {"total": len(vulns), "by_severity": severity_counts}`.
- `smells = qr.get("code_smells")`; if `list`: build `type_counts` — for each `dict` s, `kind = str(s.get("type") or s.get("kind") or "unknown")`, increment. If non-empty → `quality["code_smells_summary"] = {"total": len(smells), "by_type": type_counts}`.
- `out = {}`; if `quality` non-empty → `out["quality"] = quality` → `application.quality` (JSONB).
- `risk_summary = qr.get("risk_summary")`; if `dict`: `tier = risk_summary.get("tier")`; if `str` and in `{"1","2","3"}` → `out["risk_tier"] = tier` → `application.risk_tier` (risk_tier_enum). Return `out`.

⚠️ `risk_tier` here comes ONLY from `risk_summary.tier`. A top-level `risk_tier` field is NOT read by this extractor (docstring mentions "a direct field" but the code only reads `risk_summary.tier`).

#### `_extract_ux_side_effects(ux)` (691-744)
Guard `dict` else `{}`. Build `assessment: dict`:
- `personas = ux.get("personas")`; if `list` → `assessment["personas_count"] = len(personas)`.
- `adoption = ux.get("adoption_baseline")`; if `dict` non-empty → `total_users = sum(v.get("active_users",0) for v in adoption.values() if isinstance(v,dict))`; `assessment["adoption_baseline_summary"] = {"persona_count": len(adoption), "total_active_users": total_users}`.
- `a11y_findings = ux.get("accessibility_findings")`; if `list`: build `severities` counts (lowercased `severity`, default `"unknown"`); `critical = severities.get("critical",0)`, `serious = severities.get("serious",0)`; `assessment["accessibility_score"] = max(0, 100 - critical*10 - serious*5)` (int).
- `ui_inventory = ux.get("ui_inventory")`; if `list` → `assessment["ui_inventory_summary"] = {"screen_count": len(ui_inventory)}`.
- `ui_complexity = ux.get("ui_complexity_score")`; if `int|float` → `assessment["ui_complexity_score"] = float(ui_complexity)`.
- Return `{"ux_assessment": assessment}` if `assessment` else `{}` → `application.ux_assessment` (JSONB, pre-existing 002:95).

#### `_extract_tco_side_effects(tco)` (747-785)
Guard `dict` else `{}`. Build `projected: dict`:
- `annual = tco.get("annual_total") or tco.get("baseline_annual_usd")`; if `int|float` → `projected["annual_total"] = float(annual)`.
- `breakdown = tco.get("breakdown") or tco.get("cost_breakdown")`; if `dict` non-empty → `projected["breakdown"] = breakdown`.
- `formula = tco.get("formula_applied") or tco.get("formula")`; if `str` and `.strip()` → `projected["formula_applied"] = formula.strip()`.
- `confidence = tco.get("confidence")`; if `str` in `{"high","medium","low"}` → `projected["confidence"] = confidence`; **elif `projected` is already non-empty** → `projected["confidence"] = "low"` (default applied ONLY when other TCO data exists). ⚠️ Ordering matters: this branch runs AFTER annual/breakdown/formula were possibly added, so `projected` truthiness reflects those.
- `data_sources = tco.get("data_sources")`; if `list` → `projected["data_sources"] = [str(ds) for ds in data_sources if isinstance(ds, (str,int))]`.
- Return `{"tco": projected}` if `projected` else `{}` → `application.tco` (JSONB).

#### `_extract_discovery_compliance_metadata(quality_risk, ux_accessibility)` (922-967)
Returns a dict that becomes the `metadata.compliance` namespace. ALWAYS non-empty:
- Seed `block = {"status": "pending-ato", "cato_state": "not-started", "source_line": "Discovery"}`.
- If `quality_risk` is `dict`: `vulns = quality_risk.get("vulnerabilities")`; if `list`: `critical = sum(1 for v in vulns if isinstance(v,dict) and str(v.get("severity","")).lower() in {"critical","high"})`; `block["sast_findings_count"] = len(vulns)`; `block["sast_critical_count"] = critical`. ⚠️ Here `"high"` counts toward `sast_critical_count` (unlike `_extract_quality_side_effects` which keys severities verbatim).
- If `ux_accessibility` is `dict`: `score = ux_accessibility.get("accessibility_score")`; if `int|float`: `block["accessibility_score"] = float(score)`; if `float(score) < 0.85` → `block["status"] = "needs-review"`. ⚠️ Threshold is **0.85** (a 0–1 fraction), but `_extract_ux_side_effects` computes `accessibility_score` on a **0–100** scale. The two scores live in different columns/blocks and use different scales; reproduce both literally.
- Return `block`.

### 3.6 `_build_update_sql(projections) -> (sql, params)` (1226-1259) — REPRODUCE FULLY
Builds a dynamic UPDATE touching ONLY present projection keys, in `_SIDE_EFFECT_COLUMNS` order:
```python
assignments, params, idx = [], [], 1
for column in _SIDE_EFFECT_COLUMNS:        # fixed canonical order
    if column not in projections: continue
    value = projections[column]
    if column in _JSONB_COLUMNS:
        value = json.dumps(value)
    assignments.append(f"{column} = ${idx}")
    params.append(value)
    idx += 1
assignments.append(f"updated_at = ${idx}")  # ALWAYS appended
params.append(datetime.now(timezone.utc))
idx += 1
where_idx = idx
sql = "UPDATE application SET " + ", ".join(assignments) + f" WHERE id = ${where_idx}"
return sql, params
```
Caller then `params.append(app_uuid)` and `conn.execute(sql, *params)`.

⚠️ **GOTCHA — column iteration order is `_SIDE_EFFECT_COLUMNS`, NOT projection-dict order.** Placeholders `$1..$N` are assigned in that fixed order. This makes the SQL deterministic regardless of insertion order into `projections`. A rebuild MUST iterate the canonical tuple, filtering by presence.

⚠️ **GOTCHA — JSONB columns are pre-serialized with `json.dumps` and bound as text into a JSONB column.** asyncpg implicitly casts the text param to JSONB on assignment (the column type drives the cast). NON-JSONB columns (e.g. `complexity_tier`, `safety_tier`, `risk_tier`, `archetype`, `description`, `business_domain`) are bound as raw Python (str). For Discovery, the only relevant `_JSONB_COLUMNS` members are `tech_stack`, `size_metrics`, `architecture`, `business_logic`, `quality`, `ux_assessment`, `tco`. Native-but-non-Discovery columns (datetimes/UUID lists/Decimals) never appear from this activity's extractors.

### 3.7 `_merge_application_metadata(conn, app_uuid, namespace, payload)` (1173-1225) — REPRODUCE FULLY
JSONB-namespace merge (NOT a column overwrite):
```python
if not payload: return                       # no-op guard
payload_with_meta = dict(payload)
payload_with_meta.setdefault("last_assessed", datetime.now(timezone.utc).isoformat())
namespace_block = json.dumps({namespace: payload_with_meta})   # e.g. {"compliance": {...}}
await conn.execute(
    """
    UPDATE application
       SET metadata = COALESCE(metadata, '{}'::jsonb) || $1::jsonb,
           updated_at = $2
     WHERE id = $3::uuid
    """,
    namespace_block, datetime.now(timezone.utc), app_uuid,
)
```
- `||` is a **shallow top-level merge**: the entire `compliance` namespace block REPLACES any prior `compliance` namespace (does not deep-merge into it), while leaving sibling namespaces (e.g. `security`) intact.
- `COALESCE(metadata, '{}'::jsonb)` guards pre-051 NULL rows.
- `last_assessed` defaults to now-ISO only if the caller didn't set it (`setdefault`). For Discovery, callers never set it, so it's always now.
- ⚠️ This is a **second `updated_at` write** within the same activity run (the projection UPDATE also set it). Both set `datetime.now(timezone.utc)` at slightly different instants; the merge runs second so its timestamp wins.

### 3.8 The `_SIDE_EFFECT_COLUMNS` tuple (791-874) — full Discovery-relevant subset
This module-level tuple is the canonical column iteration order shared by ALL persist-side-effects activities across lines. **Discovery's extractors only ever emit these keys** (subset): `description`, `business_domain`, `archetype`, `complexity_tier`, `safety_tier`, `risk_tier`, `tech_stack`, `size_metrics`, `architecture`, `business_logic`, `quality`, `ux_assessment`, `tco`. (`risk_tier_source` is in the tuple but Discovery never sets it.) The remaining ~50 columns in the tuple belong to other lines (Rationalization/Architecture/Data/Modernization/Validation/Deployment/Disposition) and are reproduced in sibling specs; they are listed in the tuple but `persist_discovery_side_effects` never populates them. The FULL tuple (in order) is:
```
description, business_domain, archetype, complexity_tier, safety_tier, risk_tier, risk_tier_source,
tech_stack, size_metrics, architecture, business_logic, quality, ux_assessment, tco,
portfolio_score, disposition, disposition_source, disposition_rationale_ref,
architecture_blueprint_ref, architecture_pattern, architecture_decided_at, source_app_ids, target_repo_url,
target_service_id, data_architecture_ref, data_migration_plan_ref, data_decided_at, data_pattern,
data_domains, data_current_status, extraction_ref, extraction_at, design_ref, design_at,
modernization_pattern, bounded_contexts, generated_module_refs, generate_at, modernization_current_status,
validation_parity_score, validation_critical_vuln_count, validation_accessibility_score,
validation_safety_case_ref, validation_completed_at, validation_current_status,
deployed_at, deployment_env, cutover_strategy, parallel_run_duration_days, cost_savings_realized_usd,
license_reclamation_usd, legacy_decommissioned_at, deployment_current_status,
disposition_output_ref, disposition_completed_at, disposition_current_status, cost_savings_annual_usd
```
`_JSONB_COLUMNS` (877-892): `{tech_stack, size_metrics, architecture, business_logic, quality, ux_assessment, tco, portfolio_score, data_domains, bounded_contexts, generated_module_refs}`. `_NATIVE_COLUMNS` (898-919, informational only — `_build_update_sql` treats anything not in `_JSONB_COLUMNS` as native): `{architecture_decided_at, source_app_ids, data_decided_at, extraction_at, design_at, generate_at, validation_completed_at, deployed_at, legacy_decommissioned_at, cost_savings_realized_usd, license_reclamation_usd, parallel_run_duration_days, disposition_completed_at, cost_savings_annual_usd}`.

### 3.9 Column mapping table — `persist_discovery_side_effects` (Discovery-owned columns ONLY)
| Source pass JSON path | Extractor | `projections` key → DB column (type) | Default / condition |
|---|---|---|---|
| `catalog.description` (str) | catalog | → `application.description` (TEXT) | only if `.strip()` truthy |
| `catalog.business_domain` (str) | catalog | → `application.business_domain` (VARCHAR255) | only if `.strip()` truthy |
| `catalog.tech_stack` (dict) | catalog | → `application.tech_stack` (JSONB) | only if non-empty dict; `json.dumps`'d |
| `catalog.size_metrics` (dict) | catalog | → `application.size_metrics` (JSONB) | only if non-empty dict; `json.dumps`'d |
| `catalog.complexity_tier` (str) | catalog | → `application.complexity_tier` (complexity_tier_enum) | only if in `{simple,moderate,complex}` |
| `catalog.safety_tier` (str) | catalog | → `application.safety_tier` (VARCHAR8) | only if in `{T1,T2,T3}` |
| `catalog.architecture.archetype` (str) | catalog | → `application.archetype` (archetype_enum) | only if in `{web-app,batch,api,scheduled-job,hybrid}` ⚠️ enum-mismatch on batch/api |
| `structural.major_components`/`modules` (list) + `integrations`/`external_systems` (list) | structural | → `application.architecture` (JSONB) `{major_components, integrations}` | only non-empty lists included; key omitted if empty |
| `business_logic.rules`/`business_rules` (list) or precomputed `rule_count`/`critical_rules_count` | business_logic | → `application.business_logic` (JSONB) `{rule_count, critical_rules_count}` | only if a `rule_count` resolved; `critical_rules_count` defaults `0` |
| `quality_risk.technical_debt_score, test_coverage, vulnerabilities, code_smells` | quality | → `application.quality` (JSONB) `{technical_debt_score?, test_coverage?, vulnerabilities_summary?, code_smells_summary?}` | each sub-key conditional; whole key omitted if all absent |
| `quality_risk.risk_summary.tier` (str) | quality | → `application.risk_tier` (risk_tier_enum) | only if in `{1,2,3}` |
| `ux_accessibility.personas, adoption_baseline, accessibility_findings, ui_inventory, ui_complexity_score` | ux | → `application.ux_assessment` (JSONB) `{personas_count?, adoption_baseline_summary?, accessibility_score?, ui_inventory_summary?, ui_complexity_score?}` | each sub-key conditional |
| `tco.annual_total/baseline_annual_usd, breakdown/cost_breakdown, formula_applied/formula, confidence, data_sources` | tco | → `application.tco` (JSONB) `{annual_total?, breakdown?, formula_applied?, confidence?, data_sources?}` | `confidence` defaults `"low"` if other tco data present |
| (always) | — | → `application.updated_at` (TIMESTAMPTZ) | always set by `_build_update_sql` |
| `quality_risk.vulnerabilities` + `ux_accessibility.accessibility_score` | compliance | → `application.metadata` JSONB `compliance` namespace: `{status, cato_state, source_line:"Discovery", sast_findings_count?, sast_critical_count?, accessibility_score?, last_assessed}` | ALWAYS written (seed block non-empty); `status`→`needs-review` if accessibility<0.85 |

### 3.10 Errors / retries / idempotency
- Bad UUID → `NonRetryableError`. DB connection errors → retryable (decorator). asyncpg type/enum errors (e.g. archetype mismatch) → non-retryable.
- **Idempotent:** all writes are PK-keyed full-overwrite UPDATEs / JSONB namespace replacement. Re-running yields the same state (timestamps refresh). No insert, no FK risk.
- **NOT atomic across the two statements** (see §3.4 gotcha) — projection and metadata commits are independent.

---

## 4. ACTIVITY: `persist_capability_catalog` (line 1415)

### 4.1 Signature
```python
@foundry_activity(config=ActivityConfig(enable_observability=True))
async def persist_capability_catalog(input: PersistCapabilityCatalogInput) -> PersistCapabilityCatalogOutput
```

### 4.2 Input type — `PersistCapabilityCatalogInput` (types.py:1415-1444)
| Field | Type | Default |
|---|---|---|
| `app_id` | `str` | — |
| `portfolio_id` | `str` | — |
| `capability_catalog_json` | `str` | `""` |
| `capability_catalog_artifact_ref` | `str` | `""` (logged only) |
| `execution_context` | `StepExecutionContext \| None` | `None` |

### 4.3 Output type — `PersistCapabilityCatalogOutput` (types.py:1446-1461)
| Field | Type | Default | Meaning |
|---|---|---|---|
| `app_id` | `str` | (echoed from input) | |
| `portfolio_id` | `str` | (echoed) | |
| `system_persisted` | `bool` | `False` | set `True` after system row resolved |
| `system_application_persisted` | `bool` | `False` | set `True` after SA upsert |
| `business_domain_rows` | `int` | `0` | count of NEWLY-INSERTED business_domain rows (not updates) |
| `capability_rows` | `int` | `0` | count of NEWLY-INSERTED capability rows |
| `capability_business_domain_rows` | `int` | `0` | count of NEWLY-INSERTED edges |

⚠️ The output is constructed BEFORE the try-block (lines 1429-1432) seeded with `app_id`/`portfolio_id`, and returned both on the validation-skip path (zero rows) and on success. On exception it is NOT returned (the `raise` propagates).

### 4.4 Control flow
1. `exec_id = await emit_code_step_start(input.execution_context, function_name="persist_capability_catalog")`.
2. `out = PersistCapabilityCatalogOutput(app_id=input.app_id, portfolio_id=input.portfolio_id)`.
3. `try:`
   a. Parse `app_uuid = uuid.UUID(input.app_id)` → bad ⇒ `NonRetryableError(f"Invalid app_id: {input.app_id!r}")`.
   b. Parse `portfolio_uuid = uuid.UUID(input.portfolio_id)` → bad ⇒ `NonRetryableError(f"Invalid portfolio_id: {input.portfolio_id!r}")`.
   c. `catalog = _try_parse_json(input.capability_catalog_json)`.
   d. `reason = _validate_capability_catalog(catalog)`; if non-empty `reason`: `logger.info("persist_capability_catalog: skipping — %s", reason, extra={app_id, portfolio_id, artifact_ref})`; `await emit_code_step_complete(exec_id, columns_written=[])`; `return out` (zero-row result, no DB write).
   e. Extract header fields (see §4.6).
   f. `conn = await asyncpg.connect(_db_url())`; `try: async with conn.transaction(): <ALL UPSERTS>; finally: await conn.close()`.
   g. `await emit_code_step_complete(exec_id, columns_written=[f"system={int(out.system_persisted)}", f"system_application={int(out.system_application_persisted)}", f"business_domain={out.business_domain_rows}", f"capability={out.capability_rows}", f"capability_business_domain={out.capability_business_domain_rows}"])`.
4. `except Exception as exc: await emit_code_step_complete(exec_id, status=FAILED, error=str(exc)); raise`.
5. (success only, OUTSIDE try) `logger.info("capability-catalog persisted", extra={...})`; `return out`.

⚠️ **GOTCHA — single transaction for ALL grain writes:** Unlike `persist_discovery_side_effects`, every INSERT/UPDATE here runs inside `async with conn.transaction()` (1482). Either all rows commit or none do — a failure mid-way rolls back system + SA + domains + capabilities + edges. This is the strong-atomicity persist.

### 4.5 `_validate_capability_catalog(catalog) -> str` (1392-1412) + `_CAPABILITY_CATALOG_REQUIRED_KEYS`
`_CAPABILITY_CATALOG_REQUIRED_KEYS = frozenset({"application_id", "legacy_system", "business_domains", "capabilities"})` (1387).
Returns `""` (valid) or a human reason:
- not a dict → `"capability-catalog JSON did not parse to an object"`.
- `missing = REQUIRED - set(catalog.keys())`; if missing → `f"capability-catalog missing required keys: {sorted(missing)}"`.
- `legacy = catalog.get("legacy_system")`; if not dict or no truthy `legacy["name"]` → `"capability-catalog.legacy_system requires a non-empty name"`.
- `domains = catalog.get("business_domains")`; if not a non-empty list → `"capability-catalog.business_domains must be a non-empty list"`.
- `capabilities = catalog.get("capabilities")`; if not a non-empty list → `"capability-catalog.capabilities must be a non-empty list"`.

⚠️ `application_id` must be a KEY in the catalog (validation) but its VALUE is **never used** — the activity uses `input.app_id` for the FK, not `catalog["application_id"]`. The catalog's `application_id` is purely a presence check.

### 4.6 Header field extraction (1463-1471)
```python
legacy = catalog["legacy_system"]
legacy_name = str(legacy["name"]).strip()
legacy_external_id = legacy.get("external_id")
if isinstance(legacy_external_id, str): legacy_external_id = legacy_external_id.strip() or None
else: legacy_external_id = None
legacy_description = legacy.get("description") or ""
role_value = catalog.get("system_application_role") or "primary"
if role_value not in ("primary", "contributing", "deprecated"): role_value = "primary"
```
⚠️ Empty-string external_id collapses to `None` (forces name-based natural key). `role_value` validated against the SA `role` check-constraint vocabulary; any invalid value → `"primary"`.

### 4.7 SQL block 1 — `system` UPSERT (kind='legacy')
**If `legacy_external_id` is set** (1484, INSERT at 1487): conflict-target UPSERT on the partial unique index:
```sql
INSERT INTO system (portfolio_id, name, kind, description, external_id)
VALUES ($1, $2, 'legacy', $3, $4)
ON CONFLICT (portfolio_id, external_id) WHERE external_id IS NOT NULL
DO UPDATE SET
    name = EXCLUDED.name,
    description = COALESCE(NULLIF(EXCLUDED.description, ''), system.description),
    updated_at = now()
RETURNING id
```
params `(portfolio_uuid, legacy_name, legacy_description, legacy_external_id)`. ⚠️ The `WHERE external_id IS NOT NULL` clause MUST be on the `ON CONFLICT` to match the partial unique index `ix_system_portfolio_external_id` (050:158-164). On update, blank description never overwrites a richer existing one (`NULLIF(…, '')`).

**Else (no external_id)** — manual SELECT-then-INSERT (no unique index covers `(portfolio_id, name)`):
```sql
-- ~1520: lookup
SELECT id FROM system WHERE portfolio_id=$1 AND name=$2 AND external_id IS NULL LIMIT 1
```
- If `None` → INSERT `(portfolio_id, name, kind='legacy', description)` RETURNING id (1526).
- Else (exists) → if `legacy_description` truthy, UPDATE `description = COALESCE(NULLIF($2,''), description), updated_at=now() WHERE id=$1` (1541). `system_row = existing`.

`system_id = system_row["id"]`; `out.system_persisted = True` (1552-1553). ⚠️ `system_persisted` is set True even on the pure-lookup path (existing row, no write) — it means "system resolved", not "system inserted".

⚠️ **GOTCHA — race on the name-based path:** Two concurrent Discovery runs for the same `(portfolio, name)` with NULL external_id can both SELECT `None` and both INSERT, creating duplicate systems (no unique constraint to catch it). The transaction does not serialize against other transactions on a non-existent row. The external_id path is race-safe (relies on the partial unique index).

### 4.8 SQL block 2 — `system_application` UPSERT (1558)
```sql
INSERT INTO system_application (system_id, application_id, role)
VALUES ($1, $2, $3)
ON CONFLICT (system_id, application_id) DO UPDATE SET role = EXCLUDED.role
```
params `(system_id, app_uuid, role_value)`. Conflict target = the composite PK `system_application_pkey` (050:201). `out.system_application_persisted = True`.

### 4.9 SQL block 3 — `business_domain` rows (1572-1629)
Build `domain_id_by_name: dict[str, uuid]`. For each `domain` in `catalog["business_domains"]`:
- skip if not a `dict`; `name = str(domain.get("name") or "").strip()`; skip if empty.
- `description = domain.get("description") or ""`; `external_id` strip-or-None (same pattern as system).
- Lookup: `SELECT id FROM business_domain WHERE system_id=$1 AND name=$2 LIMIT 1` (natural key per idempotency contract `(system_id, name)`).
- If `None` → INSERT `(system_id, name, description, external_id)` RETURNING id; `out.business_domain_rows += 1`.
- Else → UPDATE `description = COALESCE(NULLIF($2,''), description), external_id = COALESCE($3, external_id), updated_at=now() WHERE id=$1`; `row = existing` (no counter increment).
- `domain_id_by_name[name] = row["id"]`.

⚠️ Lookup is on `(system_id, name)` only — NOT external_id. The unique index `ix_business_domain_system_external_id` exists but is not used as the conflict target; this is a manual upsert. Two concurrent runs can duplicate a domain row (same race caveat).
⚠️ `external_id = COALESCE($3, external_id)`: a null incoming external_id never clears an existing one.

### 4.10 SQL block 4 — `capability` rows + `capability_business_domain` edges (1632-1738)
For each `cap` in `catalog["capabilities"]`:
- skip if not `dict`; `cap_name = str(cap.get("name") or "").strip()`; skip if empty.
- `cap_description = cap.get("description") or ""`; `cap_external_id` strip-or-None.

**If `cap_external_id` set** (1645) — UPSERT on the partial unique index, with an INSERT-vs-UPDATE discriminator:
```sql
INSERT INTO capability (system_id, name, description, external_id, kind)
VALUES ($1, $2, $3, $4, 'legacy')
ON CONFLICT (system_id, external_id) WHERE external_id IS NOT NULL
DO UPDATE SET
    name = EXCLUDED.name,
    description = COALESCE(NULLIF(EXCLUDED.description, ''), capability.description),
    updated_at = now()
RETURNING id, (xmax = 0) AS inserted
```
⚠️ **GOTCHA — `(xmax = 0) AS inserted`:** Postgres sets `xmax=0` on a freshly-INSERTed tuple and non-zero when the row resulted from the `DO UPDATE` path. So `inserted=True` ⇔ new row, `False` ⇔ updated existing. The code uses `cap_row.get("inserted")` to decide whether to bump `out.capability_rows` (1710). Reproduce this exact discriminator; a naive UPSERT without it would mis-count.

**Else (no external_id)** — manual:
```sql
SELECT id FROM capability WHERE system_id=$1 AND name=$2 AND external_id IS NULL LIMIT 1
```
- If `None` → `INSERT INTO capability (system_id, name, description, kind) VALUES ($1,$2,$3,'legacy') RETURNING id, true AS inserted`.
- Else → if `cap_description` truthy, UPDATE `description = COALESCE(NULLIF($2,''), description), updated_at=now() WHERE id=$1`; then `cap_row = {"id": existing_cap["id"], "inserted": False}` (a plain dict, NOT a Record).

Then: `if cap_row.get("inserted"): out.capability_rows += 1`; `cap_id = cap_row["id"]`.

**Edges:** for each `domain_name in cap.get("business_domain_names") or []`:
- skip if not `str`; `domain_id = domain_id_by_name.get(domain_name.strip())`; skip if `None` (defensive — names not in this catalog's domain set are ignored).
- ```sql
  INSERT INTO capability_business_domain (capability_id, business_domain_id)
  VALUES ($1, $2)
  ON CONFLICT (capability_id, business_domain_id) DO NOTHING
  ```
  params `(cap_id, domain_id)`. Conflict target = PK `capability_business_domain_pkey` (050:378).
- ⚠️ **GOTCHA — counting via command tag string:** `result = await conn.execute(...)` returns the asyncpg command tag string `"INSERT 0 N"`. The code does `if result and result.endswith(" 1"): out.capability_business_domain_rows += 1`. `N=1` ⇒ new edge inserted; `N=0` (string ends `" 0"`) ⇒ already existed (DO NOTHING). Reproduce the `.endswith(" 1")` parse exactly; do NOT use rowcount objects.

### 4.11 Column mapping table — `persist_capability_catalog`
| Source (catalog JSON path) | Target table.column (type) | INSERT default / condition | UPDATE behavior |
|---|---|---|---|
| `legacy_system.name` (str, stripped) | `system.name` (VARCHAR255 NOT NULL) | required | `name = EXCLUDED.name` (ext-id path) / lookup key (name path) |
| (literal) | `system.kind` (VARCHAR32 NOT NULL, check `legacy|target|mixed`) | always `'legacy'` | unchanged on update |
| `legacy_system.description` (or `""`) | `system.description` (TEXT nullable) | inserted as-is (may be `''`) | `COALESCE(NULLIF(EXCLUDED.description,''), system.description)` — blank never clobbers |
| `legacy_system.external_id` (strip-or-None) | `system.external_id` (VARCHAR64 nullable) | inserted only on ext-id path | conflict key; name-path leaves NULL |
| `input.portfolio_id` (uuid) | `system.portfolio_id` (UUID NOT NULL FK→portfolio) | required | — |
| (server) | `system.id`, `system.created_at`, `system.updated_at`, `system.retired_at` | `gen_random_uuid()`, `now()`, `now()`, NULL | `updated_at = now()` on any update path |
| `input.app_id` (uuid) | `system_application.application_id` (UUID NOT NULL FK→application) | required | — |
| (resolved) | `system_application.system_id` (UUID NOT NULL FK→system) | required | — |
| `catalog.system_application_role` (validated) | `system_application.role` (VARCHAR32, default `'primary'`, check `primary\|contributing\|deprecated`) | defaults `'primary'` if absent/invalid | `role = EXCLUDED.role` |
| (server) | `system_application.created_at` | `now()` | — |
| `business_domains[].name` (str, stripped) | `business_domain.name` (VARCHAR255 NOT NULL) | required (skip if empty) | lookup key |
| `business_domains[].description` (or `""`) | `business_domain.description` (TEXT nullable) | as-is | `COALESCE(NULLIF($2,''), description)` |
| `business_domains[].external_id` (strip-or-None) | `business_domain.external_id` (VARCHAR64 nullable) | as-is (may be NULL) | `COALESCE($3, external_id)` — null never clears |
| (resolved) | `business_domain.system_id` (UUID NOT NULL FK→system) | required | — |
| (server) | `business_domain.id/created_at/updated_at/retired_at` | uuid/now/now/NULL | `updated_at=now()` on update |
| `capabilities[].name` (str, stripped) | `capability.name` (VARCHAR255 NOT NULL) | required (skip if empty) | `name=EXCLUDED.name` (ext-id) / lookup key (name) |
| `capabilities[].description` (or `""`) | `capability.description` (TEXT nullable) | as-is | `COALESCE(NULLIF(…,''), capability.description)` |
| `capabilities[].external_id` (strip-or-None) | `capability.external_id` (VARCHAR64 nullable) | as-is | conflict key on ext-id path |
| (literal) | `capability.kind` (VARCHAR32, default `'legacy'`, check `legacy\|derived\|net_new`) | always `'legacy'` | unchanged |
| (resolved) | `capability.system_id` (UUID NOT NULL FK→system) | required | — |
| (NOT written) | `capability.primary_disposition`, `capability.secondary_disposition` | left NULL (set later by Rationalization) | — |
| (server) | `capability.id/created_at/updated_at/retired_at` | uuid/now/now/NULL | `updated_at=now()` on update |
| `capabilities[].business_domain_names[]` (resolved via `domain_id_by_name`) | `capability_business_domain.(capability_id, business_domain_id)` (composite PK, both FK CASCADE) | INSERT … ON CONFLICT DO NOTHING | unknown names skipped |

⚠️ Columns NEVER touched by this activity (kept default/NULL by the schema): `capability.primary_disposition`, `capability.secondary_disposition`, every `*_lineage` table, `system.retired_at`/`capability.retired_at`/`business_domain.retired_at` (all left NULL). Migration 050 also adds `agent_task.*` cols and `agent_task_session_artifact` — NOT touched here.

### 4.12 Errors / retries / idempotency
- Bad `app_id` / `portfolio_id` → `NonRetryableError` (re-raised). Validation failure (`reason`) → **NOT an error** — logs, COMPLETED step, returns zero-row `out`.
- DB connection errors → retryable (decorator); FK violations (e.g. `portfolio_id` not in `portfolio`, `app_id` not in `application`) → asyncpg `ForeignKeyViolationError` → non-retryable → transaction rolls back, all-or-nothing.
- **Idempotency:** re-running Discovery for the same app reconverges on the same rows via the natural keys (ext-id partial-unique-index UPSERT, or `(system_id,name)` manual upsert; SA composite-PK upsert; edge composite-PK DO NOTHING). Counts in `out` reflect only NEW inserts on each run (re-runs → zeros). ⚠️ Name-keyed paths (no external_id) are NOT concurrency-safe (see §4.7 race gotcha).

---

## 5. Caller contract (DiscoveryWorkflow) — for behavioral parity of the surrounding pipeline
Per the activity docstrings (`persist_decomposition_map` 408+ esp. 411; `persist_discovery_side_effects` 1263+ esp. 1268; `persist_capability_catalog` 1415+ esp. 1422 "advisory — the workflow continues even when this fails"): all three are invoked from `DiscoveryWorkflow` AFTER each pass's artifact is committed to Git, wrapped **best-effort** (try/except) by the workflow so a projection failure never fails Discovery. Order: `persist_discovery_side_effects` → then `persist_capability_catalog`. `persist_decomposition_map` feeds the Insights tab specifically. The `*_json` inputs are the raw committed artifact JSON strings (not refs). A rebuild MUST keep these advisory (workflow continues on failure) AND must still let `NonRetryableError`/wrapped errors surface to the activity's own FAILED step record.

---

## 6. Observability helpers (`utils/execution.py`) — REPRODUCE (used by all three)

### `emit_code_step_start(ctx, *, function_name, columns_writable=None) -> uuid.UUID | None` (execution.py:283-321)
- `if ctx is None: return None`.
- Source `workflow_id`/`attempt` from `temporalio.activity.info()` inside try/except (fallback `""`/`1`).
- `payload = {"function": function_name}`; if `columns_writable` add `payload["columns_written"]`.
- Calls `emit_execution_record(EmitExecutionRecordInput(portfolio_id=ctx.portfolio_id, line_id=ctx.line_id, step_id=ctx.step_id, step_kind=StepKind.CODE, workflow_id=…, app_id=ctx.app_id or None, wave_id=ctx.wave_id or None, attempt=…, payload=payload, status=ExecutionStatus.RUNNING))`.

### `emit_execution_record(input) -> uuid.UUID | None` (execution.py:150-219)
- Generates `execution_id = uuid.uuid4()`; `started_at = input.started_at or now()`.
- Parses each id via `_parse_uuid` (None/`""` → None; bad → None). **If `portfolio_uuid is None`: warn + return None** (no insert). ⚠️ A `StepExecutionContext` with empty `portfolio_id` ⇒ NO step record emitted; the activity still does its DB work but is invisible to the stepper.
- INSERT into `step_execution` (cols: `execution_id, app_id, wave_id, portfolio_id, line_id, step_id, step_kind, status, started_at, attempt, input_artifacts::jsonb, payload::jsonb, workflow_id, agent_task_id, gate_id`). `step_kind='code'`, `status='running'`, `input_artifacts=[]` (code steps pass none), `payload=json.dumps({"function": …})`.
- **Best-effort:** any exception → `logger.warning` + return None.

### `emit_code_step_complete(execution_id, *, status=COMPLETED, columns_written=None, error=None)` (execution.py:324-345)
- `payload_merge = {"columns_written": columns_written}` if `columns_written is not None` (note: `[]` IS not None → still merges an empty list).
- Calls `update_execution_record(execution_id, status=status, payload_merge=payload_merge, last_error=error)`.

### `update_execution_record(execution_id, *, status, completed_at=None, output_artifacts=None, payload_merge=None, last_error=None)` (execution.py:222-275)
- `if execution_id is None: return` (so when start emitted nothing, complete is a no-op).
- UPDATE `step_execution SET status=$2, completed_at=$3, duration_ms = EXTRACT(EPOCH FROM ($3-started_at))*1000, output_artifacts = COALESCE($4::jsonb, output_artifacts), payload = payload || COALESCE($5::jsonb, '{}'::jsonb), last_error = COALESCE($6, last_error) WHERE execution_id=$1`.
- `payload || …` shallow-merges the `columns_written` into the existing payload (so the COMPLETE-time refined `columns_written` overwrites the START-time one if present). Best-effort (warns, swallows).

`StepKind.CODE = "code"`; `ExecutionStatus`: `RUNNING="running"`, `COMPLETED="completed"`, `FAILED="failed"` (execution.py:58-74).

---

## 7. Undetermined / cross-file notes
- **`application.description` column:** referenced by `_extract_catalog_side_effects` + `_SIDE_EFFECT_COLUMNS[0]` but NOT present in migration 002's `application` table and NOT in 028. A migration between 028 and current must add `application.description` (TEXT, nullable). Confirmed absent from 002/028; the exact migration that adds it was not located in this pass — the rebuild MUST ensure `application.description` exists or catalog projection of `description` will raise `UndefinedColumnError`.
- **`archetype` enum mismatch** (`batch`/`api` vs DB `batch-etl`/`api-service`) is a real latent defect; reproduced as-is for parity (§3.5).
- `risk_tier_source` is in `_SIDE_EFFECT_COLUMNS` but no Discovery extractor sets it (set by other lines).
- All `system`/`capability`/`business_domain` natural-key manual-upsert paths (no external_id) are NOT concurrency-safe.
