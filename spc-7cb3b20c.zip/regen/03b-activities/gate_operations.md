# Activity Group: Gate Operations

**Source of truth:** `/Users/pnunna/Documents/GitHub/foundry/temporal/olympus_workflows/activities/gate_operations.py` (1358 lines).

Gates are the quality checkpoints between assembly-line steps. This module manages: gate-criteria checking (incl. per-gate threshold predicates), gate-record DB lifecycle (`preparing` → `pending` → decision → `merge_blocked`), evidence submission, decision-pending recording, application-status projection, and read-back of row-level rework feedback.

This file reproduces **7 in-scope activities** plus the **2 additional activities** present in the file (`set_gate_merge_blocked`, `fetch_gate_capability_lineage_rework`) so nothing is lost, plus every module-level constant/helper they depend on.

Activities in this module (all decorated `@foundry_activity(config=ActivityConfig(enable_observability=True))`):

| Activity | Touches DB? | Table(s) | Purpose |
|---|---|---|---|
| `check_gate_criteria` | No | — | Pure-compute gate criteria + threshold evaluation |
| `submit_gate_evidence` | Yes (conditional UPDATE) | `gate` | Store evidence_data + evidence_package_url |
| `wait_for_gate_decision` | No | — | Return PENDING marker (actual wait is in workflow via signals) |
| `create_gate_record` | Yes (INSERT) | `gate` | Insert gate row in `preparing` state |
| `set_gate_merge_blocked` | Yes (UPDATE) | `gate` | Post-decision merge escalation |
| `mark_gate_ready_for_review` | Yes (UPDATE) | `gate` | Flip `preparing` → `pending` |
| `update_application_status` | Yes (UPDATE) | `application` | Project workflow progress to app row |
| `fetch_gate_capability_lineage_rework` | Yes (SELECT) | `gate` | Read row-level rework block from evidence_data |

---

## 0. PREAMBLE — The `@foundry_activity` wrapper (applies to EVERY activity here)

**Source:** `/private/var/folders/qs/dwcdl18n351cyz88x2tc9w3w0000gp/T/tmp.2xQMcqnDWM/foundry_temporal/activities.py` lines 107–165.

Every activity in this module is decorated:

```python
from foundry_temporal.activities import ActivityConfig, foundry_activity

@foundry_activity(config=ActivityConfig(enable_observability=True))
async def <name>(...): ...
```

`foundry_activity(config=None, name=None, **activity_kwargs)` returns a `decorator(func)` that:

1. Resolves `activity_config = config or ActivityConfig()`. Here config is always `ActivityConfig(enable_observability=True)` — and `enable_observability=True` and `enable_error_wrapping=True` are the dataclass defaults (`activities.py:36-37`). `log_inputs`/`log_outputs` default `False`, so inputs/outputs are **not** logged by the wrapper (the activity bodies do their own structured `logger.info` with redacted `extra`).
2. Wraps `func` with `@activity.defn(name=name, **activity_kwargs)` **on top of** `@wraps(func)` (`activities.py:125-126`). ⚠️ **GOTCHA — activity registration name:** `@activity.defn(name=None)` ⇒ Temporal registers the activity under `func.__name__` (e.g. `"check_gate_criteria"`). A rebuild MUST register each activity under its exact Python function name or the workflow's `execute_activity("check_gate_criteria", ...)` lookups break.
3. On call: if `enable_observability`, logs `f"Activity {activity_name} starting"` with `extra={"inputs": args if log_inputs else None}` (so `inputs=None` here). `activity_name = name or func.__name__`.
4. Runs `result = await func(*args, **kwargs)`; on success logs `f"Activity {activity_name} completed"` (`outputs=None`), returns `result`.
5. On `except Exception as error`:
   - If `enable_observability`: logs `f"Activity {activity_name} failed: {error}"` with `extra={"error": str(error)}`.
   - If `enable_error_wrapping` (True here): **error classification** (`activities.py:154-159`):
     - `isinstance(error, (WorkflowError, ApplicationError))` → `raise` (re-raise unchanged; preserves Temporal's own `ApplicationError` and any foundry `WorkflowError` subclass like `RetryableError`/`NonRetryableError`, since those subclass `WorkflowError`).
     - `elif _is_retryable_error(error)` → `raise RetryableError(f"Retryable error in {activity_name}: {error}") from error`.
     - `else` → `raise NonRetryableError(f"Non-retryable error in {activity_name}: {error}") from error`.

`_is_retryable_error(error)` (`activities.py:168-183`): lowercases `str(type(error))` and returns True iff it contains ANY of: `timeout`, `connection`, `network`, `temporary`, `unavailable`, `overload`, `busy`, `throttle`, `rate_limit`. ⚠️ **GOTCHA:** classification keys off the **type's repr string**, not the message. `asyncpg.exceptions.ConnectionDoesNotExistError` → repr contains `"connection"` → **retryable**. `asyncpg.exceptions.PostgresConnectionError` → `"connection"` → retryable. But a `ValueError` (e.g. malformed UUID, or the exactly-one-scope guard in `create_gate_record`) → repr `"<class 'ValueError'>"` matches none → **NonRetryableError** (correct — do not retry a bad UUID). `asyncpg.exceptions.UniqueViolationError` → no keyword match → **NonRetryableError**.

⚠️ **Rebuild note:** A plain `@activity.defn` loses (a) the start/complete/fail observability logs and (b) the retryable-vs-non-retryable wrapping. Both are load-bearing: Temporal retry policies in `retry_policies.py` rely on `NonRetryableError`/`RetryableError` type names (also see `GIT_MERGE_RETRY_POLICY.non_retryable_error_types` which lists the git merge subclasses).

`WorkflowError`, `RetryableError`, `NonRetryableError` are imported in the wrapper from `.errors` (the `foundry_temporal.errors` module). `RetryableError` and `NonRetryableError` both subclass `WorkflowError`.

**Idempotency note (global):** Temporal activities are **at-least-once**. Every DB-writing activity here is written to be safe under re-execution (see per-activity Idempotency). None wraps multiple statements in an explicit transaction — each opens its own `asyncpg` connection, runs exactly one statement, and closes in `finally`.

**`_db_url()` helper** (`gate_operations.py:1034-1041`) — used by every DB-touching activity:
```python
def _db_url() -> str:
    host = os.environ.get("DATABASE_HOST", "localhost")
    port = os.environ.get("DATABASE_PORT", "5432")
    user = os.environ.get("DATABASE_USER", "olympus")
    password = os.environ.get("DATABASE_PASSWORD", "olympus")
    db = os.environ.get("DATABASE_NAME", "olympus")
    return f"postgresql://{user}:{password}@{host}:{port}/{db}"
```
Defaults: host `localhost`, port `5432`, user `olympus`, password `olympus`, db `olympus`. ⚠️ Connection pattern is **one `asyncpg.connect()` per activity call**, `try/finally: await conn.close()`. No pooling.

---

## 1. Module-level imports & enums

```python
from __future__ import annotations
import json, logging, os, uuid
from datetime import datetime, timedelta, timezone
import asyncpg
from foundry_temporal.activities import ActivityConfig, foundry_activity
from olympus_workflows.types import (
    CapabilityLineageRowRework, CheckGateCriteriaInput, CheckGateCriteriaResult,
    CreateGateRecordInput, CreateGateRecordResult,
    FetchGateCapabilityLineageReworkInput, FetchGateCapabilityLineageReworkResult,
    GateDecisionResult, GateStatus, GateType,
    SubmitGateEvidenceInput, SubmitGateEvidenceResult,
    UpdateAppStatusInput, WaitForGateDecisionInput,
)
logger = logging.getLogger(__name__)
```

`GateType` / `GateStatus` are re-exported from `olympus_workflows.types` but **defined in** `olympus_contracts/enums.py` as `enum.StrEnum` (so their members compare equal to their string values):

**`GateType(enum.StrEnum)`** — the 15 standard gate codes (value == code). (`enums.py:80-106`)
```
G_DC="G-DC"  G_RR="G-RR"  G_DA="G-DA"  G_02="G-02"  G_DT="G-DT"
G_04A="G-04a"  G_04B="G-04b"  G_04C="G-04c"
G_DE_1="G-DE-1"  G_DE_2="G-DE-2"
G_V1="G-V1"  G_V2="G-V2"  G_V3="G-V3"  G_DP_1="G-DP-1"  G_DP_2="G-DP-2"
```

**`GateStatus(enum.StrEnum)`** (`enums.py:200-219`):
```
PREPARING="preparing"  PENDING="pending"  APPROVED="approved"  REJECTED="rejected"
OVERRIDDEN="overridden"  ESCALATED="escalated"  MERGE_BLOCKED="merge_blocked"
```

---

## 2. The `gate` table schema (authoritative — every column referenced by this module)

Built across migrations: base `003_create_workflow_tables.py`, columns added by `011`, `012`, `020`, `040`, `042`. Full column set:

| Column | Type | Null | Default | Added by |
|---|---|---|---|---|
| `id` | UUID | no | `gen_random_uuid()` | 003 |
| `gate_type` | `gate_type_enum` | no | — | 003 |
| `portfolio_id` | UUID FK portfolio(id) ON DELETE CASCADE | no | — | 003 |
| `application_id` | UUID FK application(id) ON DELETE CASCADE | **was no → made NULLable in 042** | — | 003 / 042 |
| `status` | `gate_status_enum` | no | `'pending'` | 003 (+ values `escalated` m013, `preparing` m019, `merge_blocked` m040) |
| `requested_at` | timestamptz | no | `now()` | 003 |
| `decided_at` | timestamptz | yes | — | 003 |
| `decided_by` | varchar(255) | yes | — | 003 |
| `justification` | text | yes | — | 003 |
| `retry_count` | integer | no | `0` | 003 |
| `workflow_id` | varchar(255) | yes | — | 011 |
| `sla_deadline` | timestamptz | yes | — | 011 |
| `evidence_package_url` | text | yes | — | 011 |
| `evidence_data` | JSONB | yes | — | 012 |
| `reject_reason_category` | (varchar) | yes | — | 020 (not touched by this module) |
| `merge_failure_detail` | JSONB | yes | — | 040 |
| `wave_id` | UUID FK wave(id) ON DELETE CASCADE | yes | — | 042 |

**`gate_status_enum`** PostgreSQL values (cumulative): `pending, approved, rejected, overridden, escalated, preparing, merge_blocked`. (Note: the original 003 enum had only `pending/approved/rejected/overridden`; `escalated`/`preparing`/`merge_blocked` were `ALTER TYPE ... ADD VALUE IF NOT EXISTS` in later migrations.)

**`gate_type_enum`** values: `G-DC, G-RR, G-DA, G-02, G-DT, G-04a, G-04b, G-04c, G-DE-1, G-DE-2, G-V1, G-V2, G-V3, G-DP-1, G-DP-2`.

⚠️ **CHECK constraint `gate_application_or_wave_ck`** (042): `(application_id IS NOT NULL AND wave_id IS NULL) OR (application_id IS NULL AND wave_id IS NOT NULL)` — i.e. **exactly one** of `application_id`/`wave_id`. Index `ix_gate_wave_id` on `wave_id`.

**`application` table** (002), only columns `update_application_status` writes:

| Column | Type | Null |
|---|---|---|
| `id` | UUID PK | no |
| `current_line` | `assembly_line_enum` | yes |
| `current_step` | varchar(100) | yes |
| `current_status` | varchar(50) | yes |
| `updated_at` | timestamptz | no (default `now()`) |

`assembly_line_enum` values: `Discovery, Rationalization, Architecture, Data, Modernization, Disposition Execution, Validation, Deployment, Sustainment, Governance`. ⚠️ **GOTCHA:** `update_application_status` writes `current_line` from a **plain string** (`input.current_line`). If the string isn't a valid `assembly_line_enum` member, asyncpg raises an enum-cast error (`InvalidTextRepresentationError`, repr does not contain a retryable keyword → wrapped as `NonRetryableError`). Callers must pass exact enum spellings (including the space in `"Disposition Execution"`). `current_status` / `current_step` are free-text varchars, no constraint.

---

## 3. Module-level constants — `GATE_REQUIRED_ARTIFACTS` (gate_operations.py:51-116)

`dict[str, list[str]]` keyed by **gate-code string** (NOT the enum, for robustness after Temporal serialization round-trip). Each value is the list of **required artifact filename suffixes** for that gate. Reproduce EXACTLY:

```python
GATE_REQUIRED_ARTIFACTS = {
  "G-DC":  ["catalog.json","structural-analysis.json","business-logic.json",
            "quality-risk.json","ux-accessibility.json","synthesis.json"],
  "G-RR":  ["redundancy-matrix.json","ux-overlap-matrix.json","integration-graph.json",
            "portfolio-redundancy-matrix.json","shared-identity-report.json"],
  "G-DA":  ["disposition-recommendation.json","disposition-governance.json"],
  "G-02":  ["cloud-pattern-selection.json","ea-compliance.json","integration-architecture.json",
            "security-architecture.json","design-system.json","architecture-blueprint.json"],
  "G-DT":  ["data-domains.json","shared-db-analysis.json","decomposition-strategy.json",
            "data-product-design.json"],
  "G-04a": ["business-rules.yaml","test-scenarios.yaml","cross-validation-report.json"],
  "G-04b": ["module-map.yaml","openapi.yaml","data-model.yaml"],
  "G-04c": ["gate-review-package.json"],
  "G-V1":  ["parity-report.json"],
  "G-V2":  ["security-compliance.json","accessibility-audit.json"],
  "G-V3":  ["safety-case.json"],
  "G-DP-1":["parallel-run-report.json","adoption-verification.json"],
  "G-DP-2":["decommission-certificate.json","cost-savings-certification.json"],
}
```
⚠️ **G-DE-1 and G-DE-2 are intentionally OMITTED** (no key). Rationale per source comment (lines 44-50): DispositionWorkflow runs a different step sequence per disposition (Retire/Retain/Replace/Replatform/Consolidate) so no single fixed artifact list fits; the `minimum_artifact_count` check (≥1 when no required list) catches empty submissions. For an OMITTED gate, `GATE_REQUIRED_ARTIFACTS.get(code, [])` → `[]` → no per-artifact checks, and `min_count` falls back to `1`.

---

## 4. Module-level constant — `GATE_THRESHOLDS` (gate_operations.py:139-696)

`dict[str, list[dict]]` keyed by gate-code string. Each entry is a **threshold predicate** dict with keys:
- `"artifact"`: filename suffix to locate in evidence_data.
- `"path"`: dotted JSON path into that artifact's parsed content.
- `"op"`: one of `">=", ">", "<=", "<", "==", "!="`.
- `"threshold"`: a scalar (number/bool) OR a **tier-scoped dict** keyed by `int` risk_tier (1/2/3) with optional `"default"`.
- `"description"`: human string (used verbatim in check detail).

Reproduce EXACTLY (every entry; tier-scoped thresholds noted):

**G-V1** (2 entries):
1. `parity-report.json` · `parity_pct` · `>=` · `{1:0.995, 2:0.99, 3:0.99, "default":0.99}` — "Functional parity must meet the tier-scaled threshold (Tier 1: 99.5%; Tier 2/3: 99%)"
2. `parity-report.json` · `failed` · `==` · `0` — "Zero failing parity scenarios"

**G-V2** (3 entries):
1. `security-compliance.json` · `sast.critical` · `==` · `0` — "No critical SAST findings"
2. `security-compliance.json` · `dast.critical` · `==` · `0` — "No critical DAST findings"
3. `accessibility-audit.json` · `critical` · `==` · `0` — "No critical accessibility violations"

**G-V3** (3 entries):
1. `safety-case.json` · `traceability.forward_coverage` · `>=` · `0.99` — "Forward traceability ≥ 99% (Tier 1 safety requirement)"
2. `safety-case.json` · `traceability.backward_coverage` · `>=` · `0.99` — "Backward traceability ≥ 99% (Tier 1 safety requirement)"
3. `safety-case.json` · `iv_and_v.sign_off` · `==` · `True` — "Independent IV&V sign-off required"

**G-DP-1** (3 entries):
1. `adoption-verification.json` · `active_user_ratio` · `>=` · `0.80` — "Active user ratio ≥ 80% of baseline"
2. `adoption-verification.json` · `training_completion` · `>=` · `0.70` — "Training completion ≥ 70%"
3. `adoption-verification.json` · `unresolved_critical_issues` · `==` · `0` — "Zero unresolved critical user-reported issues"

**G-DP-2** (2 entries):
1. `decommission-certificate.json` · `rollback_window_expired` · `==` · `True` — "Rollback window must have expired"
2. `decommission-certificate.json` · `data_archival_complete` · `==` · `True` — "Data archival complete"

**G-04a** (2 entries):
1. `traceability.json` · `forward_coverage` · `>=` · `{1:0.99, 2:0.98, 3:0.98, "default":0.98}` — "Forward traceability — Tier 1: 99%, Tier 2/3: 98%"
2. `traceability.json` · `backward_coverage` · `>=` · `{1:0.99, 2:0.98, 3:0.98, "default":0.98}` — "Backward traceability — Tier 1: 99%, Tier 2/3: 98%"

**G-DC** (4 entries) — evidence in `synthesis.json`:
1. `synthesis.json` · `module_coverage_pct` · `>=` · `0.95` — "Module coverage > 95% across analysis passes"
2. `synthesis.json` · `analysis_passes_complete` · `>=` · `4` — "All 4 analysis passes complete (structural, business logic, quality/risk, UX/accessibility)"
3. `synthesis.json` · `dependency_graph_generated` · `==` · `True` — "Dependency graph generated"
4. `synthesis.json` · `tco_baseline_established` · `==` · `True` — "TCO baseline established"

**G-RR** (3 entries) — all in `redundancy-matrix.json`:
1. `matrix_generated` · `==` · `True` — "Redundancy matrix generated"
2. `ux_overlap_matrix_complete` · `==` · `True` — "UX overlap matrix complete"
3. `consolidation_report_produced` · `==` · `True` — "Consolidation report produced"

**G-DA** (4 entries) — split across two artifacts:
1. `disposition-governance.json` · `evidence_traceability_pct` · `>=` · `1.0` — "Every disposition recommendation traces to evidence (100%)"
2. `disposition-governance.json` · `cost_analysis_complete_pct` · `>=` · `1.0` — "Cost analysis complete for all apps (100%)"
3. `disposition-governance.json` · `logical_contradictions` · `==` · `0` — "Zero logical contradictions in the disposition set"
4. `user-impact-analysis.json` · `user_impact_assessment_complete` · `==` · `True` — "User impact assessment complete (required for Retire/Replace/Consolidate)"

**G-02** (4 entries) — split across four step artifacts:
1. `ea-compliance.json` · `block_findings_resolved` · `==` · `True` — "All BLOCK findings resolved"
2. `security-architecture.json` · `security_controls_mapped` · `==` · `True` — "Security controls mapped to architecture components"
3. `integration-architecture.json` · `external_interfaces_preserved` · `==` · `True` — "External interfaces preserved (per-interface preservation plan)"
4. `architecture-blueprint.json` · `user_journeys_preserved` · `==` · `True` — "User journeys preserved or improved (no journey increases step count or depth)"

**G-DT** (4 entries):
1. `data-domains.json` · `domain_ownership_complete` · `==` · `True` — "Domain ownership defined for all entities"
2. `shared-db-analysis.json` · `singular_write_ownership` · `==` · `True` — "Singular write ownership per table (hard constraint)"
3. `decomposition-strategy.json` · `decomposition_validated` · `==` · `True` — "Decomposition strategy validated per shared DB cluster"
4. `decomposition-strategy.json` · `co_wave_constraints_generated` · `==` · `True` — "Co-wave constraints generated and fed to wave plan"

**G-04b** (6 entries) — all in `design-review.json`:
1. `forward_coverage` · `>=` · `{1:0.99, 2:0.98, 3:0.98, "default":0.98}` — "Forward traceability (specs → design elements) — Tier 1: 99%, Tier 2/3: 98%"
2. `bounded_contexts_defined` · `==` · `True` — "All bounded contexts have defined boundaries and APIs"
3. `openapi_valid` · `==` · `True` — "OpenAPI specs validate against schema"
4. `ddd_elements_present` · `==` · `True` — "DDD tactical elements present per BC (aggregates, events, repositories)"
5. `critical_508_violations` · `==` · `0` — "No critical 508/WCAG violations in UI components"
6. `journey_preservation_pct` · `>=` · `1.0` — "Journey preservation verified (all Pass 4 journeys mapped — 100%)"

**G-04c** (5 entries) — all in `gate-review-package.json`:
1. `test_coverage` · `>=` · `{1:0.90, 2:0.80, 3:0.80, "default":0.80}` — "Test coverage — Tier 1: 90%, Tier 2/3: 80%"
2. `tests_passed_pct` · `>=` · `1.0` — "All tests pass (100%)"
3. `critical_508_violations` · `==` · `0` — "No critical 508/WCAG violations"
4. `critical_security_vulnerabilities` · `==` · `0` — "No critical security vulnerabilities"
5. `backward_coverage` · `>=` · `{1:0.99, 2:0.98, 3:0.98, "default":0.98}` — "Backward traceability (code → design → spec → source) — Tier 1: 99%, Tier 2/3: 98%"

**G-DE-1** (4 entries) — all in `disposition-output.json`, paths prefixed `g_de1_readiness.`:
1. `g_de1_readiness.stakeholder_sign_off` · `==` · `True` — "Stakeholder sign-off obtained on disposition plan"
2. `g_de1_readiness.user_transition_addressed` · `==` · `True` — "User transition addressed in plan (retraining, communication, migration path)"
3. `g_de1_readiness.data_archival_defined` · `==` · `True` — "Data archival / migration strategy defined"
4. `g_de1_readiness.rollback_documented` · `==` · `True` — "Rollback approach documented"

**G-DE-2** (6 entries) — all in `decommission-certificate.json`:
1. `data_archived` · `==` · `True` — "Data archived"
2. `reconstruction_capability` · `==` · `True` — "Archived data has reconstruction capability"
3. `consumers_migrated` · `==` · `True` — "All consumers migrated or notified"
4. `user_transition_complete` · `==` · `True` — "User transition complete"
5. `rollback_period_defined` · `==` · `True` — "Rollback period defined (e.g. 30 days post-parallel)"
6. `security_decommission_docs_prepared` · `==` · `True` — "Security decommission documentation prepared"

⚠️ Gates NOT in `GATE_THRESHOLDS` (no threshold list): there are none beyond the above; every gate-code that appears in `GATE_REQUIRED_ARTIFACTS` plus G-DE-1/G-DE-2 has thresholds. A gate code with no entry → `GATE_THRESHOLDS.get(code, [])` → `[]` → Check 4 contributes zero checks.

---

## 5. Helper functions

### 5.1 `_resolve_threshold(value, risk_tier: int | None)` (lines 699-709)
```
if not isinstance(value, dict): return value          # plain scalar/bool
if risk_tier is not None and risk_tier in value: return value[risk_tier]
return value.get("default")                            # may be None
```
⚠️ Returns `None` when value is a tier dict, the tier isn't a key, and there's no `"default"`. The caller treats a `None` resolved-threshold as **skip** (passed=True), NOT fail.

### 5.2 `_find_file_artifact(evidence_data: dict | None, suffix: str) -> dict | None` (lines 712-727)
```
if not evidence_data: return None
steps = evidence_data.get("steps") or {}
for step_def in steps.values():
    for art in step_def.get("file_artifacts") or []:
        path = art.get("path") or ""
        if path.endswith(suffix): return art   # first match wins, across all steps
return None
```
Scans `evidence_data["steps"][*]["file_artifacts"][*]`; returns the **first** artifact dict whose `path` ends with `suffix`. ⚠️ `steps` is iterated by `.values()` — dict insertion order (Python 3.7+ guaranteed). "First match" is therefore deterministic but tied to step ordering.

### 5.3 `_get_json_path(doc: dict, path: str)` (lines 730-742)
```
cur = doc
for segment in path.split("."):
    if not isinstance(cur, dict): return None
    cur = cur.get(segment)
    if cur is None: return None
return cur
```
Walks dotted path; returns `None` if any segment missing OR a non-dict is hit mid-walk. ⚠️ A legitimately-`None`/missing leaf is indistinguishable; both → `None` → caller records a **failed** check ("field … missing").

### 5.4 `_evaluate_threshold(observed, op, threshold) -> bool` (lines 745-766)
```
try:
    if op == ">=": return observed >= threshold
    if op == ">":  return observed >  threshold
    if op == "<=": return observed <= threshold
    if op == "<":  return observed <  threshold
    if op == "==": return observed == threshold
    if op == "!=": return observed != threshold
except TypeError:
    return False        # type mismatch (e.g. str vs float) → fail, do not raise
return False            # unknown op → fail (defensive)
```
⚠️ On `TypeError` (comparing incompatible types) returns `False` rather than raising → recorded as a failed check. Unknown op → `False`.

### 5.5 `_safe_str(value: object) -> str | None` (lines 1354-1358)
```
return value if (isinstance(value, str) and value) else None
```
Non-empty string → itself; everything else (incl. empty string `""`) → `None`.

---

## 6. ACTIVITY: `check_gate_criteria` (lines 769-932)

**Decorator:** `@foundry_activity(config=ActivityConfig(enable_observability=True))`. Pure compute — **no DB, no network**.

**Signature:** `async def check_gate_criteria(input: CheckGateCriteriaInput) -> CheckGateCriteriaResult`

**Input — `CheckGateCriteriaInput`** (`types.py:842-869`, `@dataclass`):
| Field | Type | Default |
|---|---|---|
| `gate_id` | `str` | (required) |
| `gate_type` | `GateType` | (required) |
| `app_id` | `str` | (required) |
| `evidence_paths` | `list[str]` | `field(default_factory=list)` |
| `evidence_data` | `dict \| None` | `None` |
| `risk_tier` | `int \| None` | `None` |

`evidence_data` shape (when provided): `{"steps": {<step_name>: {"file_artifacts": [{"path": str, "content": str(JSON)}, ...], "output": str, ...}}}`.

**Output — `CheckGateCriteriaResult`** (`types.py:872-878`, `@dataclass`):
| Field | Type | Default |
|---|---|---|
| `gate_id` | `str` | (required) |
| `all_passed` | `bool` | (required) |
| `checks` | `list[dict[str, str \| bool]]` | `field(default_factory=list)` |

Each `checks[i]` dict has keys: `"name"` (str), `"passed"` (bool), `"detail"` (str).

### 6.1 EXACT pseudocode (every branch)

```
checks = []
all_passed = True

# --- normalize gate_type to its string code ---
gate_type_str = input.gate_type.value if isinstance(input.gate_type, GateType) else str(input.gate_type)
# ⚠️ GOTCHA: Temporal may deserialize the StrEnum as a bare str; this handles both.

# === CHECK 1: evidence_paths_present ===
has_evidence = len(input.evidence_paths) > 0
checks.append({"name":"evidence_paths_present", "passed":has_evidence,
               "detail": f"{len(input.evidence_paths)} evidence paths provided"})
if not has_evidence: all_passed = False

# === CHECK 2: required artifacts (one check per required suffix) ===
required = GATE_REQUIRED_ARTIFACTS.get(gate_type_str, [])
for required_suffix in required:
    found = any(path.endswith(required_suffix) for path in input.evidence_paths)
    checks.append({"name": f"artifact_{required_suffix}", "passed": found,
                   "detail": f"Required artifact {required_suffix} {'found' if found else 'missing'}"})
    if not found: all_passed = False

# === CHECK 3: minimum_artifact_count ===
min_count = len(required) if required else 1     # ⚠️ no required list → floor of 1
has_minimum = len(input.evidence_paths) >= min_count
checks.append({"name":"minimum_artifact_count", "passed":has_minimum,
               "detail": f"Expected >= {min_count} artifacts, got {len(input.evidence_paths)}"})
if not has_minimum: all_passed = False

# === CHECK 4: threshold predicates (one check per threshold in GATE_THRESHOLDS[code]) ===
thresholds = GATE_THRESHOLDS.get(gate_type_str, [])
for th in thresholds:
    check_name = f"threshold_{th['artifact']}_{th['path']}_{th['op']}"
    artifact = _find_file_artifact(input.evidence_data, th["artifact"])

    if artifact is None:
        # SKIPPED — back-compat. passed=True, does NOT touch all_passed.
        checks.append({"name":check_name, "passed":True,
            "detail": f"Skipped: {th['description']} — {th['artifact']} content not available in evidence_data "
                      f"(add evidence_data to the check_gate_criteria call to enforce)"})
        continue

    content_raw = artifact.get("content") or ""
    try:
        doc = json.loads(content_raw)
    except (json.JSONDecodeError, TypeError):
        # FAIL — present but unparseable.
        checks.append({"name":check_name, "passed":False,
            "detail": f"{th['description']} — could not parse {th['artifact']} as JSON"})
        all_passed = False
        continue

    observed = _get_json_path(doc, th["path"])
    if observed is None:
        # FAIL — field missing.
        checks.append({"name":check_name, "passed":False,
            "detail": f"{th['description']} — field {th['path']} missing in {th['artifact']}"})
        all_passed = False
        continue

    threshold_value = _resolve_threshold(th["threshold"], input.risk_tier)
    if threshold_value is None:
        # SKIPPED — tier-scoped threshold w/ no matching tier and no default. passed=True.
        checks.append({"name":check_name, "passed":True,
            "detail": f"Skipped: {th['description']} — no threshold configured for risk_tier={input.risk_tier!r}"})
        continue

    passed = _evaluate_threshold(observed, th["op"], threshold_value)
    checks.append({"name":check_name, "passed":passed,
        "detail": f"{th['description']} — observed {observed!r} {th['op']} {threshold_value!r}: "
                  f"{'pass' if passed else 'fail'}"})
    if not passed: all_passed = False

# === LOG ===
logger.info("Gate criteria check completed", extra={
    "gate_id": input.gate_id, "gate_type": gate_type_str, "app_id": input.app_id,
    "all_passed": all_passed, "checks_count": len(checks), "threshold_checks": len(thresholds)})

return CheckGateCriteriaResult(gate_id=input.gate_id, all_passed=all_passed, checks=checks)
```

### 6.2 State-machine semantics of the 4 checks
- **Pass/skip taxonomy:** A check can be **pass** (`passed=True`, no effect or positive), **fail** (`passed=False`, sets `all_passed=False`), or **skip** (`passed=True`, detail starts with `"Skipped:"`, deliberately does NOT fail the gate). Only Check-4 produces skips.
- ⚠️ **Backwards-compat is the whole point of skip:** missing `evidence_data`, or an artifact not present in the bundle, or a tier-scoped threshold with no resolution → **skip not fail**. This preserves the mocked-test path (which passes only `evidence_paths`, no `evidence_data`) and pre-F3 submissions. **Present-but-unparseable JSON** and **present-but-missing-field** DO fail (the artifact exists, so we hold it to the bar).
- **Number of checks emitted** = `1 (Check1) + len(required) (Check2) + 1 (Check3) + len(thresholds) (Check4)`.
- **Retry policy (intended):** validation_failure policy — **no retry**; fix evidence and resubmit. (Docstring line 794.) Note: this is a workflow-side `RetryPolicy` choice; the activity itself never raises on a failed criterion — it returns `all_passed=False`. It only raises on programmer error (e.g. malformed `th` dict), which the wrapper would classify NonRetryable.

### 6.3 Idempotency / errors
Pure function of input — deterministic, no side effects, fully idempotent. The only exceptions possible are from `json.loads` (caught) or a malformed threshold dict / missing key (KeyError → NonRetryableError via wrapper). No DB, so no transient/retryable failures expected.

---

## 7. ACTIVITY: `submit_gate_evidence` (lines 935-992)

**Decorator:** `@foundry_activity(config=ActivityConfig(enable_observability=True))`.

**Signature:** `async def submit_gate_evidence(input: SubmitGateEvidenceInput) -> SubmitGateEvidenceResult`

**Input — `SubmitGateEvidenceInput`** (`types.py:881-890`, `@dataclass`):
| Field | Type | Default |
|---|---|---|
| `gate_id` | `str` | (required) |
| `gate_type` | `GateType` | (required) |
| `app_id` | `str` | (required) |
| `artifact_paths` | `list[str]` | `field(default_factory=list)` |
| `pr_url` | `str` | `""` |
| `evidence_data` | `dict \| None` | `None` |

**Output — `SubmitGateEvidenceResult`** (`types.py:893-900`, `@dataclass`):
| Field | Type |
|---|---|
| `gate_id` | `str` |
| `evidence_package_url` | `str` |
| `pr_url` | `str` |

### 7.1 Control flow
```
evidence_url = input.pr_url if input.pr_url else f"evidence/{input.gate_id}"   # ⚠️ empty pr_url → synthetic path

if input.evidence_data:                       # ⚠️ conditional DB write — only when truthy (None or {} → skip UPDATE)
    conn = await asyncpg.connect(_db_url())
    try:
        await conn.execute("""
            UPDATE gate
            SET evidence_data = $1::jsonb,
                evidence_package_url = $2
            WHERE id = $3::uuid
            """,
            json.dumps(input.evidence_data),   # $1
            evidence_url,                       # $2
            uuid.UUID(input.gate_id))           # $3
    finally:
        await conn.close()

logger.info("Gate evidence submitted", extra={
    "gate_id": input.gate_id,
    "gate_type": input.gate_type.value if isinstance(input.gate_type, GateType) else str(input.gate_type),
    "app_id": input.app_id,
    "artifact_count": len(input.artifact_paths),
    "pr_url": input.pr_url,
    "has_evidence_data": input.evidence_data is not None})

return SubmitGateEvidenceResult(gate_id=input.gate_id, evidence_package_url=evidence_url, pr_url=input.pr_url)
```

### 7.2 PROJECTION TABLE (`gate` UPDATE — fires ONLY when `input.evidence_data` is truthy)

| Source (artifact/input field) | → `gate` column | SQL value | Default / Condition |
|---|---|---|---|
| `input.evidence_data` (whole dict) | `evidence_data` (JSONB) | `$1::jsonb = json.dumps(input.evidence_data)` | Written only if `input.evidence_data` truthy |
| `input.pr_url` (or synthetic) | `evidence_package_url` (text) | `$2 = input.pr_url or f"evidence/{gate_id}"` | Same condition |
| `input.gate_id` | (WHERE key) | `$3::uuid = uuid.UUID(input.gate_id)` | row match |

⚠️ **GOTCHA — `evidence_package_url` is co-written with `evidence_data`.** If `evidence_data` is falsy, the UPDATE is skipped entirely and `evidence_package_url` is **NOT** persisted here (it's still returned in the result). The DB row's `evidence_package_url` set at `create_gate_record` time remains. So calling `submit_gate_evidence` with no `evidence_data` is a pure no-op to the DB.

⚠️ **GOTCHA — empty dict `{}` is falsy** → treated as "no evidence_data" → no UPDATE. Only a non-empty dict triggers the write.

⚠️ `json.dumps(input.evidence_data)` then `$1::jsonb` cast. The whole bundle is overwritten (no merge). Re-running overwrites with the same payload → idempotent.

### 7.3 Idempotency / errors
**Idempotent** — single UPDATE keyed by `id`, overwrites both columns; re-execution writes identical values. `uuid.UUID(input.gate_id)` on a bad string → `ValueError` → NonRetryableError. asyncpg connection failures → repr contains `connection`/`timeout` → RetryableError (intended "transient retry policy", docstring line 949 references HTTP_RETRY_POLICY). If the gate row doesn't exist, UPDATE affects 0 rows — **no error**, silent.

---

## 8. ACTIVITY: `wait_for_gate_decision` (lines 995-1031)

**Decorator:** `@foundry_activity(config=ActivityConfig(enable_observability=True))`. **No DB.** Pure marker.

**Signature:** `async def wait_for_gate_decision(input: WaitForGateDecisionInput) -> GateDecisionResult`

**Input — `WaitForGateDecisionInput`** (`types.py:935-942`, `@dataclass`):
| Field | Type | Default |
|---|---|---|
| `gate_id` | `str` | (required) |
| `gate_type` | `GateType` | (required) |
| `app_id` | `str` | (required) |
| `sla_timeout_seconds` | `int` | `172800` (48h) |

**Output — `GateDecisionResult`** (`types.py:1000-1008`, `@dataclass`):
| Field | Type | Default |
|---|---|---|
| `gate_id` | `str` | (required) |
| `status` | `GateStatus` | (required) |
| `decided_by` | `str` | `""` |
| `decided_at` | `str` | `""` |
| `feedback` | `str` | `""` |

### 8.1 Behavior
```
logger.info("Gate decision pending", extra={
    "gate_id": input.gate_id,
    "gate_type": input.gate_type.value if isinstance(input.gate_type, GateType) else str(input.gate_type),
    "app_id": input.app_id, "sla_timeout_seconds": input.sla_timeout_seconds})

return GateDecisionResult(
    gate_id=input.gate_id,
    status=GateStatus.PENDING,                                  # always PENDING
    decided_by="",
    decided_at=datetime.now(timezone.utc).isoformat(),         # ⚠️ "now", NOT a real decision time
    feedback="")
```
⚠️ **GOTCHA — this activity does NOT wait.** Despite the name, it just records that the gate is awaiting a decision and returns `status=PENDING` immediately. The **real waiting** happens in the workflow via signals `gate_approved` / `gate_rejected` (docstring lines 999-1001). `decided_at` is set to the current UTC time even though nothing was decided — it's the "marked-pending-at" timestamp, not a decision timestamp. Fully deterministic except for the timestamp; idempotent (no side effects). Intended retry policy: timeout policy, max 2 retries (docstring line 1009).

---

## 9. ACTIVITY: `create_gate_record` (lines 1044-1116)  ⭐ PERSIST/INSERT

**Decorator:** `@foundry_activity(config=ActivityConfig(enable_observability=True))`.

**Signature:** `async def create_gate_record(input: CreateGateRecordInput) -> CreateGateRecordResult`

**Input — `CreateGateRecordInput`** (`types.py:902-918`, `@dataclass`):
| Field | Type | Default |
|---|---|---|
| `gate_type` | `str` | (required) — **plain str**, NOT enum |
| `portfolio_id` | `str` | (required) |
| `workflow_id` | `str` | (required) |
| `app_id` | `str \| None` | `None` |
| `wave_id` | `str \| None` | `None` |
| `evidence_package_url` | `str` | `""` |
| `sla_timeout_seconds` | `int` | `172800` (48h) |

**Output — `CreateGateRecordResult`** (`types.py:921-932`, `@dataclass`):
| Field | Type | Default |
|---|---|---|
| `gate_id` | `str` | (required) — `str(uuid4)` |
| `gate_type` | `str` | (required) — echoes input |
| `app_id` | `str \| None` | `None` |
| `wave_id` | `str \| None` | `None` |

### 9.1 Control flow
```
# --- exactly-one-scope guard (validated in-process before DB) ---
if bool(input.app_id) == bool(input.wave_id):
    raise ValueError(
        "create_gate_record requires exactly one of app_id / wave_id; "
        f"got app_id={input.app_id!r}, wave_id={input.wave_id!r}")
# ⚠️ bool("") == bool(None) == False → both empty raises; both non-empty raises.

gate_id = uuid.uuid4()
now = datetime.now(timezone.utc)
sla_deadline = now + timedelta(seconds=input.sla_timeout_seconds)

app_uuid  = uuid.UUID(input.app_id)  if input.app_id  else None
wave_uuid = uuid.UUID(input.wave_id) if input.wave_id else None

conn = await asyncpg.connect(_db_url())
try:
    await conn.execute("""
        INSERT INTO gate (id, application_id, wave_id, portfolio_id,
                          gate_type, status, workflow_id, requested_at,
                          sla_deadline, evidence_package_url)
        VALUES ($1, $2, $3, $4::uuid, $5, 'preparing', $6, $7, $8, $9)
        """,
        gate_id,                       # $1
        app_uuid,                      # $2  (None → NULL)
        wave_uuid,                     # $3  (None → NULL)
        uuid.UUID(input.portfolio_id), # $4::uuid
        input.gate_type,               # $5  (raw string code, cast to gate_type_enum implicitly)
        input.workflow_id,             # $6
        now,                           # $7  requested_at
        sla_deadline,                  # $8
        input.evidence_package_url)    # $9
finally:
    await conn.close()

logger.info("Gate record created (preparing)", extra={
    "gate_id": str(gate_id), "gate_type": input.gate_type, "app_id": input.app_id,
    "wave_id": input.wave_id, "workflow_id": input.workflow_id})

return CreateGateRecordResult(gate_id=str(gate_id), gate_type=input.gate_type,
                              app_id=input.app_id, wave_id=input.wave_id)
```

### 9.2 PROJECTION TABLE — INSERT into `gate` (10 columns written; rest defaulted)

| Source (input field / computed) | → `gate` column | SQL placeholder | Notes / Default |
|---|---|---|---|
| `uuid.uuid4()` | `id` | `$1` | generated in-process (not server default) |
| `input.app_id` → `app_uuid` | `application_id` | `$2` | `None` when wave-scoped → NULL |
| `input.wave_id` → `wave_uuid` | `wave_id` | `$3` | `None` when app-scoped → NULL |
| `input.portfolio_id` | `portfolio_id` | `$4::uuid` | required |
| `input.gate_type` (str) | `gate_type` | `$5` | raw code; cast to `gate_type_enum` |
| **literal** `'preparing'` | `status` | (inline literal) | ⚠️ ALWAYS inserted as `'preparing'`, not `'pending'` |
| `input.workflow_id` | `workflow_id` | `$6` | |
| `now` (UTC) | `requested_at` | `$7` | in-process `datetime.now(timezone.utc)` |
| `now + sla_timeout_seconds` | `sla_deadline` | `$8` | `timedelta(seconds=input.sla_timeout_seconds)` |
| `input.evidence_package_url` | `evidence_package_url` | `$9` | default `""` |

**Columns NOT written (rely on table default or stay NULL):** `decided_at` (NULL), `decided_by` (NULL), `justification` (NULL), `retry_count` (DEFAULT `0`), `evidence_data` (NULL), `reject_reason_category` (NULL), `merge_failure_detail` (NULL).

### 9.3 Critical semantics
⚠️ **GOTCHA — status is hardcoded `'preparing'`, not `'pending'`.** The gate is hidden from the reviewer queue (which filters `status = 'pending'`) until `mark_gate_ready_for_review` flips it. This prevents the race where a human opens a gate while the AI pre-review agent is still running (source comment lines 1073-1077).

⚠️ **GOTCHA — exactly-one-scope guard mirrors the DB CHECK.** The in-process `bool(app_id) == bool(wave_id)` raise (lines 1060-1064) gives a readable `ValueError` instead of an asyncpg `CheckViolationError` from `gate_application_or_wave_ck`. Both-empty AND both-set both raise. This guard exists because migration 042's note documents the old bug: workflows used to stuff `app_id=f"wave-{wave_id}"` into `application_id`, and `uuid.UUID("wave-...")` raised `ValueError: badly formed hexadecimal UUID string`, killing the workflow before any insert.

⚠️ **`gate_id` generated client-side** (`uuid.uuid4()`), NOT via the `gen_random_uuid()` server default — the returned `gate_id` must equal the inserted PK so the workflow can reference it.

### 9.4 Idempotency / errors
⚠️ **NOT idempotent across Temporal retries.** Each execution generates a **new** `uuid.uuid4()` and INSERTs a new row. If the activity succeeds at the DB but the worker crashes before reporting completion, Temporal re-runs it → a **second gate row** with a different `id`. There is no `ON CONFLICT` / dedup key. (Workflows mitigate by treating the activity as fire-once at a deterministic workflow step; but the activity body itself does not dedup.) — Flag this as a known duplication risk.
- `ValueError` from the scope guard or any `uuid.UUID(...)` on a bad string → NonRetryableError.
- Constraint violations (FK to portfolio/app/wave missing, or `gate_application_or_wave_ck`) → asyncpg `IntegrityConstraintViolationError` subclasses; type repr has no retryable keyword → NonRetryableError.
- Connection errors → RetryableError.

---

## 10. ACTIVITY: `set_gate_merge_blocked` (lines 1119-1165)  ⭐ PERSIST/UPDATE — W17/P5-S17.4

**Decorator:** `@foundry_activity(config=ActivityConfig(enable_observability=True))`.

**Signature:** `async def set_gate_merge_blocked(gate_id: str, failure_detail: dict) -> None`

⚠️ **Positional args, NOT a dataclass input.** Two bare params: `gate_id: str`, `failure_detail: dict`.

**`failure_detail` shape** (per strategy doc §3.7 and `GateDetail.merge_failure_detail` model comment, `models/gate.py:80-84`): `{reason, failure_type, conflicting_files?, base_sha?, head_sha?, detected_at}`. Stored verbatim as JSONB; the activity does not validate or reshape it.

### 10.1 Control flow & PROJECTION
```
detail_dict = dict(failure_detail) if failure_detail else {}   # ⚠️ normalize Temporal proxy → plain dict; falsy → {}

conn = await asyncpg.connect(_db_url())
try:
    await conn.execute("""
        UPDATE gate
        SET status = 'merge_blocked',
            merge_failure_detail = $1::jsonb
        WHERE id = $2::uuid
        """,
        json.dumps(detail_dict),     # $1
        uuid.UUID(gate_id))          # $2
finally:
    await conn.close()

logger.info("Gate transitioned to merge_blocked", extra={
    "gate_id": gate_id,
    "failure_type": detail_dict.get("failure_type"),
    "reason": detail_dict.get("reason")})
```

| Source | → `gate` column | SQL | Condition/Default |
|---|---|---|---|
| **literal** `'merge_blocked'` | `status` | inline | always |
| `failure_detail` (normalized) | `merge_failure_detail` (JSONB) | `$1::jsonb = json.dumps(detail_dict)` | falsy → `{}` |
| `gate_id` | (WHERE key) | `$2::uuid` | |

⚠️ **GOTCHA — reviewer's approval is preserved.** `decided_at` / `decided_by` are **left untouched**; only `status` flips and `merge_failure_detail` is populated. No WHERE-status filter — it overwrites whatever status the row had (the workflow only calls this on an already-approved gate). (Source comment lines 1130-1133.)

⚠️ **GOTCHA — `dict(failure_detail)` normalization (line 1141).** Temporal's payload converter may deliver `failure_detail` as a dict-like proxy, not a plain `dict`; `dict(...)` coerces it so `json.dumps` works. `if failure_detail else {}` also guards `None`/empty.

### 10.2 Which merge error maps to this activity (Git activity tie-in)
This activity is the **landing point** for the structured merge errors raised by each line workflow's `reconcile_and_merge_pr` activity after Temporal retries exhaust. The three error classes (`olympus_contracts/errors.py`, all subclass `GitServiceError`):

| Error class | `mergeable_state` | Retryable? | Why |
|---|---|---|---|
| `MergeConflict` | `"dirty"` | **No** (non-retryable) | real 3-way content conflict; needs human resolution |
| `MergeBranchProtectionRejected` | `"blocked"` | **No** (non-retryable) | branch-protection rule automation can't satisfy |
| `MergeDivergenceUnresolved` | `"behind"` (persists after update-branch) | **Yes** (bounded retries) | racing merges; usually resolve in seconds |

The non-retryable subclasses (`MergeConflict`, `MergeBranchProtectionRejected`) are listed in `GIT_MERGE_RETRY_POLICY.non_retryable_error_types` (`retry_policies.py`) so Temporal short-circuits. When any of these escapes the merge activity (the retryable one only after its bounded loop also exhausts), the workflow catches it and calls `set_gate_merge_blocked(gate_id, {failure_type: <class name>, reason: ..., ...})`. The gate then waits in `merge_blocked` until a reviewer fires the `merge_retry` signal (via `POST /api/v1/gates/{id}/retry-merge`), which re-enters the merge activity. (See `GateStatus.MERGE_BLOCKED` docstring `enums.py:200-211`.)

### 10.3 Idempotency / errors
⚠️ **Explicitly idempotent** (source comment lines 1137-1138): re-running overwrites `merge_failure_detail` with the latest payload — matches Temporal at-least-once. `uuid.UUID(gate_id)` bad → NonRetryableError. Connection errors → RetryableError. 0-row match (gate gone) → silent no-op.

---

## 11. ACTIVITY: `mark_gate_ready_for_review` (lines 1168-1192)  ⭐ PERSIST/UPDATE

**Decorator:** `@foundry_activity(config=ActivityConfig(enable_observability=True))`.

**Signature:** `async def mark_gate_ready_for_review(gate_id: str) -> None`  (single positional `str`, no dataclass)

### 11.1 Control flow & PROJECTION
```
conn = await asyncpg.connect(_db_url())
try:
    await conn.execute("""
        UPDATE gate
        SET status = 'pending'
        WHERE id = $1::uuid AND status = 'preparing'
        """,
        uuid.UUID(gate_id))    # $1
finally:
    await conn.close()

logger.info("Gate marked ready for review", extra={"gate_id": gate_id})
```

| Source | → `gate` column | SQL | Condition |
|---|---|---|---|
| **literal** `'pending'` | `status` | inline | **only if** current `status = 'preparing'` (WHERE-guarded) |
| `gate_id` | (WHERE key) | `$1::uuid` | combined with `AND status = 'preparing'` |

⚠️ **GOTCHA — guarded transition.** The `AND status = 'preparing'` clause makes this **idempotent and safe**: if the gate already advanced (`approved`/`rejected`/`escalated`/`merge_blocked`/already `pending`), the UPDATE matches 0 rows and is a **no-op** — it will NOT clobber a more-advanced state back to `pending`. This is the deliberate partner to `create_gate_record`'s `'preparing'` insert: queue visibility (`status='pending'`) is flipped only after the AI pre-review finishes (regardless of pre-review success/failure). (Source comment lines 1170-1177.)

### 11.2 Idempotency / errors
**Idempotent by construction** (WHERE-status guard). Bad UUID → NonRetryableError; connection error → RetryableError.

---

## 12. ACTIVITY: `update_application_status` (lines 1195-1229)  ⭐ PERSIST/UPDATE (application table)

**Decorator:** `@foundry_activity(config=ActivityConfig(enable_observability=True))`.

**Signature:** `async def update_application_status(input: UpdateAppStatusInput) -> None`

**Input — `UpdateAppStatusInput`** (`types.py:1011-1018`, `@dataclass`):
| Field | Type | Default |
|---|---|---|
| `app_id` | `str` | (required) |
| `status` | `str` | (required) |
| `current_step` | `str` | `""` |
| `current_line` | `str` | `""` |

### 12.1 Control flow & PROJECTION
```
conn = await asyncpg.connect(_db_url())
try:
    await conn.execute("""
        UPDATE application
        SET current_status = $1, current_step = $2, current_line = $3,
            updated_at = $4
        WHERE id = $5::uuid
        """,
        input.status,                    # $1  → current_status (varchar50)
        input.current_step,              # $2  → current_step (varchar100)
        input.current_line,              # $3  → current_line (assembly_line_enum!)
        datetime.now(timezone.utc),      # $4  → updated_at
        uuid.UUID(input.app_id))         # $5  WHERE id
finally:
    await conn.close()

logger.info("Application status updated", extra={
    "app_id": input.app_id, "status": input.status, "current_step": input.current_step})
```

| Source (input field) | → `application` column | SQL | Type constraint |
|---|---|---|---|
| `input.status` | `current_status` | `$1` | varchar(50), free text |
| `input.current_step` | `current_step` | `$2` | varchar(100), free text; default `""` |
| `input.current_line` | `current_line` | `$3` | **`assembly_line_enum`** — must be a valid enum member |
| `datetime.now(timezone.utc)` | `updated_at` | `$4` | timestamptz |
| `input.app_id` | (WHERE key) | `$5::uuid` | |

⚠️ **GOTCHA — `current_line` is enum-cast.** `$3` is bound to `input.current_line` (a plain `str`) but the column is `assembly_line_enum`. Passing `""` (the default) or any non-member string raises asyncpg `InvalidTextRepresentationError` → wrapper → **NonRetryableError**. Callers MUST pass exact enum spellings, e.g. `"Disposition Execution"` (with the space). The default `current_line=""` will FAIL the cast if the workflow doesn't override it — so this activity is only safe to call with a real line name.
⚠️ `current_status` and `current_step` are plain varchars → any string accepted.

### 12.2 Idempotency / errors
**Idempotent** — single UPDATE keyed by `id`; re-running rewrites the same values (plus a fresh `updated_at`). Bad app UUID → NonRetryableError; bad `current_line` enum value → NonRetryableError; connection error → RetryableError; 0-row match (app gone) → silent.

---

## 13. ACTIVITY: `fetch_gate_capability_lineage_rework` (lines 1232-1351)  ⭐ READ (SELECT)

**Decorator:** `@foundry_activity(config=ActivityConfig(enable_observability=True))`. Phase 5 PR #4 (PR 2) — workflow-side rework-feedback read-back.

**Signature:** `async def fetch_gate_capability_lineage_rework(input: FetchGateCapabilityLineageReworkInput) -> FetchGateCapabilityLineageReworkResult`

**Input — `FetchGateCapabilityLineageReworkInput`** (`types.py:945-958`, `@dataclass`):
| Field | Type |
|---|---|
| `gate_id` | `str` |

**Output — `FetchGateCapabilityLineageReworkResult`** (`types.py:981-997`, `@dataclass`):
| Field | Type | Default |
|---|---|---|
| `gate_id` | `str` | (required) |
| `ratified_count` | `int` | `0` |
| `rejected_count` | `int` | `0` |
| `rejected_rows` | `list[CapabilityLineageRowRework]` | `field(default_factory=list)` |

**`CapabilityLineageRowRework`** (`types.py:961-978`, `@dataclass`):
| Field | Type | Default |
|---|---|---|
| `lineage_id` | `str` | (required) |
| `feedback` | `str` | (required) |
| `source_capability` | `str \| None` | `None` |
| `target_capability` | `str \| None` | `None` |
| `source_system` | `str \| None` | `None` |
| `target_system` | `str \| None` | `None` |
| `relationship` | `str \| None` | `None` |

### 13.1 Source JSON it reads (the write side, for parity)
The gate-decision endpoint persists (via `olympus-api/src/services/gate.py::_persist_capability_lineage_rework_block`, lines 1854-1894) at `gate.evidence_data.review.capability_lineage_rework`:
```json
{ "ratified_count": <int>, "rejected_count": <int>,
  "rejected_rows": [ {"lineage_id": <str>, "feedback": <str>,
                      "source_capability": <str?>, "target_capability": <str?>,
                      "source_system": <str?>, "target_system": <str?>,
                      "relationship": <str?>}, ... ] }
```
(The write side sources `rejected_rows` from `row_summary["rework_feedback"]`.)

### 13.2 EXACT control flow (every defensive branch returns the EMPTY result `FetchGateCapabilityLineageReworkResult(gate_id=input.gate_id)`)

```
# 1. Parse gate_id → UUID
try:
    gate_uuid = uuid.UUID(input.gate_id)
except (ValueError, TypeError):
    return EMPTY            # ⚠️ malformed gate_id never crashes; fall back to free-text-only rework

# 2. SELECT
conn = await asyncpg.connect(_db_url())
try:
    row = await conn.fetchrow("SELECT evidence_data FROM gate WHERE id = $1::uuid", gate_uuid)
finally:
    await conn.close()

# 3. Row missing
if row is None:
    logger.info("fetch_gate_capability_lineage_rework: gate not found", extra={"gate_id": input.gate_id})
    return EMPTY

# 4. evidence_data NULL
raw = row["evidence_data"]
if raw is None:
    return EMPTY

# 5. JSONB decode — handle both shapes ⚠️ asyncpg may return JSONB as dict OR JSON string depending on codec
if isinstance(raw, str):
    try: evidence = json.loads(raw)
    except (json.JSONDecodeError, TypeError): return EMPTY
elif isinstance(raw, dict):
    evidence = raw
else:
    return EMPTY

# 6. Navigate evidence.review
review = evidence.get("review") if isinstance(evidence, dict) else None
if not isinstance(review, dict): return EMPTY

# 7. Navigate review.capability_lineage_rework
block = review.get("capability_lineage_rework")
if not isinstance(block, dict): return EMPTY

# 8. rejected_rows[] — parse & filter
rejected_rows_raw = block.get("rejected_rows") or []
if not isinstance(rejected_rows_raw, list): rejected_rows_raw = []

rejected_rows = []
for entry in rejected_rows_raw:
    if not isinstance(entry, dict): continue
    lineage_id = entry.get("lineage_id")
    feedback   = entry.get("feedback")
    if not isinstance(lineage_id, str) or not isinstance(feedback, str): continue   # ⚠️ drop non-str
    if not feedback.strip(): continue                                                # ⚠️ drop blank feedback
    rejected_rows.append(CapabilityLineageRowRework(
        lineage_id=lineage_id,
        feedback=feedback,
        source_capability=_safe_str(entry.get("source_capability")),
        target_capability=_safe_str(entry.get("target_capability")),
        source_system=_safe_str(entry.get("source_system")),
        target_system=_safe_str(entry.get("target_system")),
        relationship=_safe_str(entry.get("relationship"))))

# 9. counts — coerce non-int → 0
ratified_count = block.get("ratified_count") or 0
rejected_count = block.get("rejected_count") or 0
if not isinstance(ratified_count, int): ratified_count = 0
if not isinstance(rejected_count, int): rejected_count = 0
# ⚠️ ORDER: `or 0` runs first (so None/0/"" → 0), THEN isinstance check (so a non-zero str/float → 0).

logger.info("fetch_gate_capability_lineage_rework", extra={
    "gate_id": input.gate_id, "ratified_count": ratified_count,
    "rejected_count": rejected_count, "rejected_rows": len(rejected_rows)})

return FetchGateCapabilityLineageReworkResult(
    gate_id=input.gate_id, ratified_count=ratified_count,
    rejected_count=rejected_count, rejected_rows=rejected_rows)
```

### 13.3 Critical semantics
⚠️ **Every failure path returns the EMPTY result, never raises** (lines 1251-1301): malformed gate_id, gate not found, NULL evidence_data, unparseable JSON string, non-dict evidence/review/block — ALL fall through to `FetchGateCapabilityLineageReworkResult(gate_id=input.gate_id)` (zero counts, empty rows). Rationale (docstring 1247-1252): a transient corruption must never block a rework iteration; the workflow still re-dispatches with gate-level free-text feedback.
⚠️ **Per-row filtering drops entries** where `lineage_id` or `feedback` is not a `str`, or `feedback` is blank/whitespace-only. `bool(int)` is `int` in Python so `ratified_count`/`rejected_count` accept ints only after the `or 0` + isinstance gate.
⚠️ **`_safe_str` on the 5 denormalized fields** turns empty strings and non-strings into `None`.
⚠️ **JSONB dual-shape handling** (lines 1281-1293): asyncpg returns JSONB as a Python `dict` OR a JSON-encoded `str` depending on driver/codec registration. Both are handled; any other type → EMPTY.

### 13.4 Idempotency / errors
Pure read — **fully idempotent**, no writes. The body swallows all parse/lookup errors into EMPTY. The only exceptions that escape to the wrapper are asyncpg connection failures during `fetchrow` (→ RetryableError). `uuid.UUID` errors are caught internally (return EMPTY), so they do NOT reach the wrapper.

---

## 14. Cross-activity gate STATE TRANSITIONS (the gate lifecycle)

```
                 create_gate_record
                         │  INSERT status='preparing'
                         ▼
                    [preparing]   ← hidden from reviewer queue (queue filters status='pending')
                         │
            mark_gate_ready_for_review (UPDATE ... WHERE status='preparing')
                         │  (called after AI pre-review finishes, success OR failure)
                         ▼
                     [pending]    ← wait_for_gate_decision returns PENDING marker here;
                         │           workflow blocks on gate_approved / gate_rejected signals
        ┌────────────────┼─────────────────┬─────────────────────┐
        ▼                ▼                  ▼                     ▼
   [approved]       [rejected]        [escalated]           [overridden]
   (decided_by/     (rework loop;     (escalation queue)    (admin override)
    decided_at set   re-dispatch via
    by API service)  fetch_gate_capability_lineage_rework
                     + free-text feedback)
        │
        │  (downstream reconcile_and_merge_pr raises MergeConflict /
        │   MergeBranchProtectionRejected / MergeDivergenceUnresolved
        │   after Temporal retries exhaust)
        ▼
  set_gate_merge_blocked (UPDATE status='merge_blocked', merge_failure_detail=...)
        │   decided_at/decided_by PRESERVED
        ▼
  [merge_blocked]  ← reviewer fires merge_retry signal (POST /gates/{id}/retry-merge)
        │            → workflow re-enters reconcile_and_merge_pr
        └──► back to merge attempt (→ approved/merged on success, or merge_blocked again)
```

**Which activity writes which status:**
- `create_gate_record` → INSERT `'preparing'` (hardcoded).
- `mark_gate_ready_for_review` → `'pending'` (only from `'preparing'`).
- `set_gate_merge_blocked` → `'merge_blocked'` (unconditional on status; preserves decision fields).
- `wait_for_gate_decision` → writes NOTHING to DB; returns in-memory `GateStatus.PENDING`.
- `approved` / `rejected` / `escalated` / `overridden` transitions are written by the **API gate service** (`olympus-api/src/services/gate.py`) on the decision endpoint, NOT by activities in this module. This module's activities only own `preparing`/`pending`/`merge_blocked`.

---

## 15. Things undetermined / out of file scope (noted for the rebuild)

- The **workflow-side retry policies** named in docstrings (validation_failure, transient/HTTP_RETRY_POLICY, timeout policy, `GIT_MERGE_RETRY_POLICY`) are defined in `temporal/olympus_workflows/retry_policies.py` — referenced here but not reproduced (separate group). The activity bodies themselves do not set retry policies; that's the caller's `execute_activity(..., retry_policy=...)`.
- The **decision endpoint** (`approved`/`rejected`/`escalated`/`overridden` writes, `_persist_capability_lineage_rework_block`, `_apply_capability_lineage_row_decisions`) lives in `olympus-api/src/services/gate.py` (API layer) — cited for the write-side JSON shape of `capability_lineage_rework` but is outside this Temporal-activities group.
- `failure_detail` for `set_gate_merge_blocked` is stored verbatim; the canonical key set (`reason`, `failure_type`, `conflicting_files?`, `base_sha?`, `head_sha?`, `detected_at`) comes from strategy doc §3.7 / `GateDetail` model — the activity neither validates nor enforces it.
