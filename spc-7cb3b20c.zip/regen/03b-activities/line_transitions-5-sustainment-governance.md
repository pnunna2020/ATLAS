# Activity Group Spec — `line_transitions.py` §5: Sustainment + Governance Sweep Projections

**Source file:** `/Users/pnunna/Documents/GitHub/foundry/temporal/olympus_workflows/activities/line_transitions.py`
**HEAD:** `7cb3b20c`. **Owned line range:** **4898–6003** (this spec reproduces ONLY functions in this range; sibling files own the rest). ⚠️ Line numbers REFRESHED to HEAD: the file grew by +162 since the prior baseline, shifting every symbol from `_INCIDENT_SEVERITIES` (4525) onward by **+152**. Bodies are behaviorally UNCHANGED — only citations moved.
**Activities reproduced (2):**

| Activity | Def line | `@foundry_activity` decorator line | Tables written |
|----------|----------|-------------------------------------|----------------|
| `persist_sustainment_sweep_side_effects` | 4899 | 4898 | `patching_compliance`, `incident_log`, `sla_compliance_record`, `do_not_modify_flag`, `cost_anomaly_record`, `sustainment_override_log`, `application` (2 cols) |
| `persist_governance_sweep_side_effects` | 5514 | 5513 | `drift_alert`, `pattern` (+ reuse_count UPDATE), `health_check`, `factory_capacity_plan`, `model_benchmark_result` |

Both are **projection activities**: parse already-Git-committed artifact JSON best-effort, extract rows via pure helper functions, then bulk-write inside a **single `asyncpg` transaction**. They are deliberately NOT correctness-critical: the calling workflow swallows exceptions at the call site (the sweep-summary commit does not block on the projection). Govern themselves by the migration schemas in `db/alembic/versions/037_create_sustainment_tables.py` (sustainment) and `db/alembic/versions/038_add_governance_sweep_tables.py` + `025_create_governance_tables.py` (governance).

Pure helper extractor functions in range **4525–4896** (sustainment) and **5235–5510** (governance) are reproduced in full below because the projection control-flow depends on them column-for-column.

---

## 0. The `@foundry_activity` decorator (capture once, applies to BOTH activities)

Defined in `foundry_temporal/activities.py` (read at `/private/var/folders/qs/dwcdl18n351cyz88x2tc9w3w0000gp/T/tmp.2xQMcqnDWM/foundry_temporal/activities.py`). Imported here as `from foundry_temporal.activities import ActivityConfig, foundry_activity` (line 26).

Both activities are decorated:
```python
@foundry_activity(config=ActivityConfig(enable_observability=True))
```
`ActivityConfig` is a dataclass with fields (all default unless set): `retry_policy=None`, `start_to_close_timeout=None`, `schedule_to_close_timeout=None`, `schedule_to_start_timeout=None`, `heartbeat_timeout=None`, `enable_observability=True`, `enable_error_wrapping=True`, `log_inputs=False`, `log_outputs=False`. Here only `enable_observability=True` is passed explicitly (already the default) — so **`enable_error_wrapping` is `True`** and **no timeouts/retry policy are set at the decorator level** (they come from the workflow's `execute_activity` call).

`foundry_activity(config, name=None, **activity_kwargs)` returns a decorator that:
1. Applies real `@activity.defn(name=name, **activity_kwargs)` — i.e. the function IS a genuine Temporal activity, registered under its Python function name (no `name` override here, so activity name = `"persist_sustainment_sweep_side_effects"` / `"persist_governance_sweep_side_effects"`).
2. Wraps the body in observability: on entry logs `f"Activity {name} starting"` (extra `inputs` only if `log_inputs`, here False → `None`); on success logs `f"Activity {name} completed"` (extra `outputs` only if `log_outputs`, here False → `None`); on exception logs `f"Activity {name} failed: {error}"`.
3. **Error wrapping** (since `enable_error_wrapping=True`): in the `except Exception as error` branch —
   - if `isinstance(error, (WorkflowError, ApplicationError))` → bare `raise` (preserve typed/Temporal errors verbatim — e.g. a `NonRetryableError` raised inside the body propagates unchanged because `NonRetryableError` is a `WorkflowError` subclass);
   - elif `_is_retryable_error(error)` → `raise RetryableError(f"Retryable error in {name}: {error}") from error`;
   - else → `raise NonRetryableError(f"Non-retryable error in {name}: {error}") from error`.
4. `_is_retryable_error(error)` classifies by **substring match on `str(type(error)).lower()`** against: `timeout, connection, network, temporary, unavailable, overload, busy, throttle, rate_limit`. ⚠️ It matches the **type's repr string**, not the message. So an asyncpg `ConnectionDoesNotExistError` / `*TimeoutError` → retryable; a plain `ValueError`/`KeyError`/`json` error → **non-retryable**.

⚠️ **Rebuild gotcha:** a rebuild using plain `@activity.defn` loses this error-wrapping + retryable/non-retryable classification. Both activities rely on it: an asyncpg transient (connection/timeout) bubbles as `RetryableError`; a programming/parse bug bubbles as `NonRetryableError`. **BUT** — see §1.7/§2.7 — both activities wrap their entire body in a `try/except Exception: emit FAILED; raise` shell, and the *workflow call sites* swallow the re-raised exception. So in practice the decorator's classification mostly affects retry behavior only if the workflow ever schedules them with a retry policy; the dominant control flow is "best-effort, log, return zero counts / partial write".

`RetryableError` / `NonRetryableError` / `WorkflowError` are from `from .errors import ...` (in foundry_temporal) and `NonRetryableError` is re-imported into this module via `from foundry_temporal.errors import NonRetryableError` (line 27). Only `persist_governance_sweep_side_effects` raises `NonRetryableError` directly (invalid `portfolio_id`).

---

## 1. Module-level shared helpers used by these activities

### 1.1 `_db_url() -> str` (line 88)
Builds the asyncpg DSN from env with these exact defaults:
```python
host = os.environ.get("DATABASE_HOST", "localhost")
port = os.environ.get("DATABASE_PORT", "5432")
user = os.environ.get("DATABASE_USER", "olympus")
password = os.environ.get("DATABASE_PASSWORD", "olympus")
db = os.environ.get("DATABASE_NAME", "olympus")
return f"postgresql://{user}:{password}@{host}:{port}/{db}"
```
Both activities `conn = await asyncpg.connect(_db_url())` and `await conn.close()` in a `finally`.

### 1.2 `_try_parse_json(text: str) -> dict[str, Any] | None` (line 281)
Best-effort parse used on EVERY artifact-JSON input field:
```python
if not text:            # empty string OR None
    return None
try:
    value = json.loads(text)
except json.JSONDecodeError:
    start = text.find("{"); end = text.rfind("}")
    if start == -1 or end <= start:
        return None
    try:
        value = json.loads(text[start : end + 1])
    except json.JSONDecodeError:
        return None
return value if isinstance(value, dict) else None
```
⚠️ Returns `None` if the top-level JSON is not a `dict` (e.g. a JSON array or scalar). ⚠️ The fallback path extracts the substring from the first `{` to the last `}` — handles agent prose-wrapped JSON.

### 1.3 Execution-record emission (`olympus_workflows/utils/execution.py`, imported lines 72–76)
`ExecutionStatus(str, enum.Enum)`: `QUEUED, RUNNING, COMPLETED, FAILED, TIMED_OUT, SKIPPED, ESCALATED, ABANDONED`.

`emit_code_step_start(ctx, *, function_name, columns_writable=None) -> uuid.UUID | None` (execution.py:283):
- if `ctx is None` → return `None` (no emission; legacy call sites tolerate this).
- else sources `workflow_id` + `attempt` from `activity.info()` (wrapped in try/except → defaults `""` / `1`).
- builds `payload = {"function": function_name}`; adds `payload["columns_written"]` only if `columns_writable` truthy.
- calls `emit_execution_record(EmitExecutionRecordInput(portfolio_id=ctx.portfolio_id, line_id=ctx.line_id, step_id=ctx.step_id, step_kind=StepKind.CODE, workflow_id, app_id=ctx.app_id or None, wave_id=ctx.wave_id or None, attempt, payload, status=ExecutionStatus.RUNNING))` and returns its record id (or None on best-effort failure).

`emit_code_step_complete(execution_id, *, status=ExecutionStatus.COMPLETED, columns_written=None, error=None) -> None` (execution.py:324):
- if `columns_written is not None` → `payload_merge = {"columns_written": columns_written}` else `None`.
- `await update_execution_record(execution_id, status=status, payload_merge=payload_merge, last_error=error)`.

⚠️ Both emission helpers are **best-effort** (a DB write failure inside them does NOT propagate per the module docstring — they mirror the `agent_task` pattern). `execution_id` may be `None` (when `ctx is None`); `update_execution_record(None, ...)` is a no-op.

`StepExecutionContext` (types.py:532) — the `execution_context` field type. Fields: `portfolio_id: str` (required), `line_id: str`, `step_id: str`, `app_id: str = ""`, `wave_id: str = ""`, `input_artifact_paths: list[str] = []`, `gate_id: str = ""`.

---

## 2. ACTIVITY: `persist_sustainment_sweep_side_effects` (4899–5210)

### 2.1 Signature
```python
@foundry_activity(config=ActivityConfig(enable_observability=True))   # line 4898
async def persist_sustainment_sweep_side_effects(
    input: PersistSustainmentSweepSideEffectsInput,
) -> PersistSustainmentSweepSideEffectsResult:
```

### 2.2 Input dataclass — `PersistSustainmentSweepSideEffectsInput` (types.py:2588, EVERY field)
```python
@dataclass
class PersistSustainmentSweepSideEffectsInput:
    portfolio_id: str                                  # REQUIRED; expected UUID string
    schedule_id: str                                   # REQUIRED; used as sweep_id in all rows
    sweep_completed_at: str = ""                        # ISO-8601; "" → now(UTC)
    cve_triage_json: str = ""                           # raw artifact for patching_compliance
    incident_response_json: str = ""                    # raw artifact for incident_log
    sla_monitoring_json: str = ""                       # raw artifact for sla_compliance_record
    change_conflict_json: str = ""                      # raw artifact for do_not_modify_flag
    cost_anomaly_json: str = ""                          # raw artifact for cost_anomaly_record
    override_decisions: list[dict] = field(default_factory=list)   # override_approved signal payloads
    execution_context: "StepExecutionContext | None" = None
```

### 2.3 Output dataclass — `PersistSustainmentSweepSideEffectsResult` (types.py:2624, EVERY field)
```python
@dataclass
class PersistSustainmentSweepSideEffectsResult:
    portfolio_id: str
    schedule_id: str
    patching_compliance_rows: int = 0
    incident_log_rows: int = 0
    sla_compliance_rows: int = 0
    do_not_modify_flag_rows: int = 0
    cost_anomaly_rows: int = 0
    override_log_rows: int = 0
    application_rows_updated: int = 0
```
⚠️ The result is constructed `PersistSustainmentSweepSideEffectsResult(portfolio_id=..., schedule_id=..., **counts)` where `counts` is the dict built at 4977 — its keys MUST exactly match these field names. The `counts` dict uses keys `patching_compliance_rows, incident_log_rows, sla_compliance_rows, do_not_modify_flag_rows, cost_anomaly_rows, override_log_rows, application_rows_updated` (note: `do_not_modify_flag_rows` and `override_log_rows`, NOT `do_not_modify_rows`/`override_rows`).

### 2.4 Control flow (exact sequence)
1. `exec_id = await emit_code_step_start(input.execution_context, function_name="persist_sustainment_sweep_side_effects")`.
2. Open `try:` (the outer shell that maps any exception → `emit_code_step_complete(exec_id, status=FAILED, error=str(exc)); raise`).
3. Parse five artifacts best-effort (4921–4925):
   - `cve_triage = _try_parse_json(input.cve_triage_json)`
   - `incident_resp = _try_parse_json(input.incident_response_json)`
   - `sla_mon = _try_parse_json(input.sla_monitoring_json)`
   - `change_conflict = _try_parse_json(input.change_conflict_json)`
   - `cost_anomaly = _try_parse_json(input.cost_anomaly_json)`
4. Compute `sweep_completed_at` (4927–4933):
   ```python
   sweep_completed_at = (
       datetime.fromisoformat(input.sweep_completed_at.replace("Z", "+00:00"))
       if input.sweep_completed_at
       else datetime.now(timezone.utc)
   )
   ```
   ⚠️ If `sweep_completed_at` is a non-ISO string this raises `ValueError` → caught by outer shell → FAILED. Not whitelisted. The `.replace("Z","+00:00")` is the standard ISO-Z normalization.
5. Run the SIX extractors + one lifecycle aggregator (each returns plain dicts/lists — see §2.6):
   - `patching_row = _extract_patching_compliance_row(cve_triage, portfolio_id=..., schedule_id=..., evaluated_at=sweep_completed_at)`
   - `incident_rows = _extract_incident_log_rows(incident_resp, portfolio_id=..., schedule_id=..., recorded_at=sweep_completed_at)`
   - `sla_rows = _extract_sla_compliance_rows(sla_mon, portfolio_id=..., schedule_id=..., recorded_at=sweep_completed_at)`
   - `do_not_modify_rows = _extract_do_not_modify_rows(change_conflict, portfolio_id=..., recorded_at=sweep_completed_at)` (NOTE: no `schedule_id`)
   - `cost_rows = _extract_cost_anomaly_rows(cost_anomaly, portfolio_id=..., schedule_id=..., recorded_at=sweep_completed_at)`
   - `override_rows = _extract_sustainment_override_log_rows(input.override_decisions, portfolio_id=..., recorded_at=sweep_completed_at)` (reads the signal list, NOT a parsed artifact)
   - `lifecycle_updates = _extract_application_lifecycle_updates(do_not_modify_rows=..., incident_rows=..., sla_rows=..., cost_rows=..., sweep_completed_at=sweep_completed_at)`
6. Build `counts` dict (4977): `patching_compliance_rows = 1 if patching_row else 0`, the four list lengths, `override_log_rows = len(override_rows)`, `application_rows_updated = 0` (filled later).
7. **Empty short-circuit (4987):** if NONE of `[patching_row, incident_rows, sla_rows, do_not_modify_rows, cost_rows, override_rows, lifecycle_updates]` is truthy → log `"persist_sustainment_sweep_side_effects: nothing extractable"` (extra `portfolio_id`, `schedule_id`), `await emit_code_step_complete(exec_id, columns_written=[])`, and **return** `PersistSustainmentSweepSideEffectsResult(portfolio_id=input.portfolio_id, schedule_id=input.schedule_id)` (all counts default 0). No DB connection is opened.
8. Else open `conn = await asyncpg.connect(_db_url())`, `app_updates_applied = 0`, then `try: async with conn.transaction():` → run all writes (§2.5) → `finally: await conn.close()`.
9. `counts["application_rows_updated"] = app_updates_applied`.
10. Log `"sustainment sweep side-effects persisted"` (extra `portfolio_id` + all counts spread).
11. `await emit_code_step_complete(exec_id, columns_written=[...8 entries...])` — the literal list (5190–5199): `["patching_compliance", "incident_log", "sla_compliance_record", "do_not_modify_flag", "cost_anomaly_record", "sustainment_override_log", "application.sustainment_current_status", "application.sustainment_last_sweep_at"]`. ⚠️ This is a static superset, NOT the actual touched columns — it is emitted regardless of which extractors produced rows. (⚠️ FIXED: prior baseline mis-cited this list as 4038–4047.)
12. `return PersistSustainmentSweepSideEffectsResult(portfolio_id=..., schedule_id=..., **counts)`.
13. Outer `except Exception as exc:` → `await emit_code_step_complete(exec_id, status=ExecutionStatus.FAILED, error=str(exc)); raise`.

⚠️ **Transaction atomicity:** ALL six table writes + the `application` updates happen inside ONE `conn.transaction()`. A failure on any single `INSERT`/`UPDATE` rolls back the entire sweep projection (then bubbles through the outer shell as FAILED, then the decorator wraps it, then the workflow swallows it). There is **no per-row error isolation** inside the transaction.

### 2.5 SQL writes (exact, in execution order inside the transaction)

**(a) `patching_compliance`** — only if `patching_row` truthy (one INSERT, 5014):
```sql
INSERT INTO patching_compliance (
    portfolio_id, sweep_id, critical_open_count,
    high_open_count, medium_open_count, low_open_count,
    sla_compliance_pct, evaluated_at
) VALUES ($1::uuid, $2, $3, $4, $5, $6, $7, $8)
```
Params: `portfolio_id`, `sweep_id`, `critical_open_count`, `high_open_count`, `medium_open_count`, `low_open_count`, `sla_compliance_pct`, `evaluated_at`.

**(b) `incident_log`** — one INSERT per row in `incident_rows` (5034):
```sql
INSERT INTO incident_log (
    portfolio_id, sweep_id, app_id, severity,
    symptom, status, resolution_summary, recorded_at
) VALUES ($1::uuid, $2, NULLIF($3, '')::uuid, $4, $5, $6, $7, $8)
```
Params: `portfolio_id`, `sweep_id`, `row["app_id"] or ""` (⚠️ Python coerces `None`→`""`, then `NULLIF($3,'')::uuid` makes empty → SQL NULL), `severity`, `symptom`, `status`, `resolution_summary`, `recorded_at`.

**(c) `sla_compliance_record`** — one INSERT per row in `sla_rows` (5056):
```sql
INSERT INTO sla_compliance_record (
    portfolio_id, sweep_id, app_id,
    availability_pct, response_time_p95_ms,
    incident_resolution_mean_hours,
    breach_count, recorded_at
) VALUES ($1::uuid, $2, $3::uuid, $4, $5, $6, $7, $8)
```
Params: `portfolio_id`, `sweep_id`, `app_id` (NOT NULLIF'd — `app_id` is always non-empty because the extractor skips rows with empty app_id; column is NOT NULL FK), `availability_pct`, `response_time_p95_ms`, `incident_resolution_mean_hours`, `breach_count`, `recorded_at`.

**(d) `do_not_modify_flag`** — one UPSERT per row in `do_not_modify_rows` (5080):
```sql
INSERT INTO do_not_modify_flag (
    portfolio_id, app_id, flagged_at, wave_id,
    expires_at, active, override_count
) VALUES (
    $1::uuid, $2::uuid, $3::timestamptz,
    NULLIF($4, '')::uuid, $5::timestamptz, $6, $7
)
ON CONFLICT (portfolio_id, app_id) DO UPDATE SET
    wave_id = EXCLUDED.wave_id,
    expires_at = EXCLUDED.expires_at,
    active = EXCLUDED.active,
    override_count = EXCLUDED.override_count
```
Params: `portfolio_id`, `app_id`, `flagged_at`, `row["wave_id"] or ""` (→ NULLIF empty → NULL), `expires_at`, `active`, `override_count`.
⚠️ Conflict target is the unique constraint `uq_do_not_modify_flag_portfolio_app` on `(portfolio_id, app_id)` (migration 037:255). ⚠️ On conflict, `flagged_at` is NOT updated (preserves original flag time) — only `wave_id/expires_at/active/override_count` are overwritten from the new sweep. The extractor passes the artifact's own `override_count` (it does NOT read the existing DB value), so the upsert OVERWRITES `override_count` with whatever the change-conflict artifact declares (the docstring's "preserve override_count" intent is realized only because the change-conflict skill re-declares the current register including override_count).

**(e) `cost_anomaly_record`** — one INSERT per row in `cost_rows` (5107):
```sql
INSERT INTO cost_anomaly_record (
    portfolio_id, sweep_id, app_id,
    baseline_usd, observed_usd, variance_pct,
    flagged, recorded_at
) VALUES ($1::uuid, $2, $3::uuid, $4, $5, $6, $7, $8)
```
Params: `portfolio_id`, `sweep_id`, `app_id` (always non-empty per extractor), `baseline_usd`, `observed_usd`, `variance_pct`, `flagged`, `recorded_at`.

**(f) `sustainment_override_log`** — one INSERT per row in `override_rows` (5129):
```sql
INSERT INTO sustainment_override_log (
    portfolio_id, app_id, gate_id, override_by,
    justification, override_type, recorded_at
) VALUES ($1::uuid, NULLIF($2, '')::uuid, $3, $4, $5, $6, $7)
```
Params: `portfolio_id`, `row["app_id"] or ""` (→ NULLIF → NULL), `gate_id`, `override_by`, `justification`, `override_type`, `recorded_at`.

**(g) `application` lifecycle UPDATE** — per `(app_id, updates)` in `lifecycle_updates` (5150–5178). Dynamically built:
```python
for app_id, updates in lifecycle_updates:
    try:
        target_uuid = uuid.UUID(app_id)
    except (ValueError, TypeError):
        continue                       # skip non-UUID app ids silently
    assignments = []; params = []; idx = 1
    if "sustainment_current_status" in updates:
        assignments.append(f"sustainment_current_status = ${idx}")
        params.append(updates["sustainment_current_status"]); idx += 1
    assignments.append(f"sustainment_last_sweep_at = ${idx}")
    params.append(updates["sustainment_last_sweep_at"]); idx += 1
    assignments.append(f"updated_at = ${idx}")
    params.append(datetime.now(timezone.utc)); idx += 1
    sql = "UPDATE application SET " + ", ".join(assignments) + f" WHERE id = ${idx}"
    params.append(target_uuid)
    result = await conn.execute(sql, *params)
    if result.endswith(" 1"):
        app_updates_applied += 1
```
⚠️ `sustainment_current_status` is written ONLY if present in the per-app `updates` dict (it is absent when the ladder left the app at no-status; see `_extract_application_lifecycle_updates`). `sustainment_last_sweep_at` and `updated_at` are ALWAYS written for every touched app. ⚠️ `app_updates_applied` increments only when the asyncpg command tag ends with `" 1"` (exactly one row matched) — a missing/duplicate app id yields a non-`" 1"` tag and is NOT counted.

### 2.6 Pure extractor helpers for sustainment (REPRODUCE EXACTLY)

Module constants (4525–4531):
```python
_INCIDENT_SEVERITIES = frozenset({"P1","P2","P3","P4","critical","high","medium","low"})
_CVE_SEVERITY_KEYS = ("critical","high","medium","low")
```

**`_extract_patching_compliance_row(artifact, *, portfolio_id, schedule_id, evaluated_at) -> dict | None`** (4534)
- If `artifact` not a dict → `None`.
- `summary = artifact.get("summary") or artifact.get("compliance") or artifact`; if not a dict → `{}`.
- Inner `_count(key)`: value = first truthy of `summary[f"{key}_open_count"]`, `summary[f"{key}_open"]`, `summary[f"open_{key}"]`, else `0`; `int(value)` (TypeError/ValueError → `0`). Compute `crit/high/med/low` from keys `critical/high/medium/low`.
- `sla_pct_raw = summary["sla_compliance_pct"] or summary["sla_compliance"] or summary["compliance_pct"]`; `sla_pct = float(sla_pct_raw) if not None else None` (parse error → `None`).
- ⚠️ **Empty guard:** if `(crit+high+med+low) == 0 and sla_pct is None` → return `None` (nothing to project).
- Else return dict: `{portfolio_id, sweep_id=schedule_id, critical_open_count=crit, high_open_count=high, medium_open_count=med, low_open_count=low, sla_compliance_pct=sla_pct, evaluated_at}`.

**`_extract_incident_log_rows(artifact, *, portfolio_id, schedule_id, recorded_at) -> list[dict]`** (4599)
- Not dict → `[]`.
- `incidents = artifact["incidents"] or artifact["processed_incidents"] or []`; not a list → `[]`.
- Per `inc` dict (skip non-dicts):
  - `app_id = inc["app_id"] or inc["application_id"] or ""`.
  - `severity = str(inc["severity"] or "").strip()`. ⚠️ Whitelist check exists (`if severity and severity not in _INCIDENT_SEVERITIES: pass`) but is a **no-op** — non-whitelisted severities are kept (column is VARCHAR(16)).
  - `symptom = str(inc["symptom"] or inc["category"] or "")`.
  - `status = str(inc["status"] or "open")`.
  - `resolution = str(inc["resolution_summary"] or inc["resolution"] or "")`.
  - row: `{portfolio_id, sweep_id=schedule_id, app_id=str(app_id) if app_id else None, severity=severity[:16] if severity else "unknown", symptom, status, resolution_summary=resolution, recorded_at}`. ⚠️ severity truncated to 16 chars; empty severity → literal `"unknown"`.

**`_extract_sla_compliance_rows(artifact, *, portfolio_id, schedule_id, recorded_at) -> list[dict]`** (4645)
- Not dict → `[]`.
- `apps = artifact["apps"] or artifact["measurements"] or artifact["sla_records"] or []`; not list → `[]`.
- Per `m` dict (skip non-dicts): `app_id = m["app_id"] or m["application_id"] or ""`; ⚠️ **if not app_id → `continue`** (no row; this is why the INSERT can pass non-NULLIF app_id).
  - Inner `_f(keys)`: first non-None key value coerced `float(v)` (parse-error → try next key), else `None`. Inner `_i(keys)`: same but `int(v)`, default `0`.
  - row: `{portfolio_id, sweep_id=schedule_id, app_id=str(app_id), availability_pct=_f(("availability_pct","availability")), response_time_p95_ms=_f(("response_time_p95_ms","p95_ms","latency_p95_ms")), incident_resolution_mean_hours=_f(("incident_resolution_mean_hours","mttr_hours")), breach_count=_i(("breach_count","breaches")), recorded_at}`.

**`_extract_do_not_modify_rows(artifact, *, portfolio_id, recorded_at) -> list[dict]`** (4710) (NO schedule_id)
- Not dict → `[]`.
- `flags = artifact["do_not_modify_flags"] or artifact["flags"] or []`; not list → `[]`.
- Per `f` dict (skip non-dicts): `app_id = f["app_id"] or f["application_id"] or ""`; ⚠️ **if not app_id → continue**.
  - row: `{portfolio_id, app_id=str(app_id), flagged_at = f["flagged_at"] if isinstance str else recorded_at.isoformat(), wave_id = str(f["wave_id"] or "") or None, expires_at = f["expires_at"] if isinstance str else None, active = bool(f.get("active", True)), override_count = int(f.get("override_count", 0) or 0)}`.
  - ⚠️ `flagged_at`/`expires_at` are passed as **strings** to the SQL (cast `$3::timestamptz`/`$5::timestamptz`); `flagged_at` defaults to `recorded_at.isoformat()` (ISO string) when artifact omits it; `expires_at` defaults to `None`. `active` defaults `True`. `override_count` defaults `0`.

**`_extract_cost_anomaly_rows(artifact, *, portfolio_id, schedule_id, recorded_at) -> list[dict]`** (4758)
- Not dict → `[]`.
- `anomalies = artifact["anomalies"] or artifact["apps"] or artifact["findings"] or []`; not list → `[]`.
- Per `a` dict: `app_id = a["app_id"] or a["application_id"] or ""`; ⚠️ **if not app_id → continue**.
  - Inner `_f(keys)` (same float-coerce-first-non-None pattern).
  - row: `{portfolio_id, sweep_id=schedule_id, app_id=str(app_id), baseline_usd=_f(("baseline_usd","baseline")), observed_usd=_f(("observed_usd","observed","actual_usd")), variance_pct=_f(("variance_pct","variance")), flagged=bool(a.get("flagged", False)), recorded_at}`.

**`_extract_sustainment_override_log_rows(override_decisions, *, portfolio_id, recorded_at) -> list[dict]`** (4808)
- `override_decisions` not a list → `[]`.
- Per `dec` dict (skip non-dicts): `gate_id = dec["gate_id"] or ""`.
  - row: `{portfolio_id, app_id = str(dec["app_id"] or "") or None, gate_id = str(gate_id), override_by = str(dec["override_by"] or ""), justification = str(dec["justification"] or ""), override_type = str(dec["override_type"] or ""), recorded_at}`.
  - ⚠️ No app_id filter — override rows always emitted (app_id may be NULL via NULLIF).

**`_extract_application_lifecycle_updates(*, do_not_modify_rows, incident_rows, sla_rows, cost_rows, sweep_completed_at) -> list[tuple[str, dict]]`** (4834)
- `per_app: dict[str, dict] = {}`. Inner `_mark(app_id, status=None)`:
  - if not app_id → return.
  - `entry = per_app.setdefault(app_id, {"sustainment_last_sweep_at": sweep_completed_at})` (every marked app ALWAYS gets `sustainment_last_sweep_at`).
  - Status ladder: `if status == "attention-required": set it`; `elif status == "monitoring" and current != "attention-required": set "monitoring"`. ⚠️ `attention-required` is sticky and wins; an app already attention-required is never downgraded.
- Marking passes (order matters only for which `_mark` calls happen, not final status due to ladder):
  - **incidents:** `sev = str(inc["severity"] or "").lower()`; status = `"attention-required"` if `sev in {"p1","critical"}` else `"monitoring"`; `_mark(str(inc["app_id"] or ""), status)`. ⚠️ lowercase compare against `{"p1","critical"}` — so `"P1"`/`"Critical"` match.
  - **do_not_modify:** for each flag, `if flag.get("active"): _mark(app_id, "attention-required")` (inactive flags don't mark).
  - **sla:** `breach = int(sla["breach_count"] or 0)`; status = `"attention-required"` if `breach > 0` else `"monitoring"`; `_mark(app_id, status)`.
  - **cost:** `if cost.get("flagged"): _mark(app_id, "attention-required") else: _mark(app_id, "monitoring")`.
- Return `list(per_app.items())`.
- ⚠️ An app that only appears with status `None` never happens here (every branch passes a concrete status), BUT note: an app touched ONLY because it was `setdefault`-created without a status would have no `sustainment_current_status` key. In practice every `_mark` here passes a status, so the key is set — EXCEPT the ladder can leave `sustainment_current_status` absent only if `_mark` were called with `status=None` (no caller does). So in this code the key is effectively always present for emitted apps; the `if "sustainment_current_status" in updates` guard in the SQL loop is defensive.

### 2.7 Error handling / retries / idempotency (sustainment)
- **Best-effort by design:** docstring says unparseable artifacts log a warning (inside extractors) and return zero counts rather than raising; the workflow swallows unexpected exceptions at the call site.
- **What CAN raise out of the body:** a malformed `sweep_completed_at` ISO string (`datetime.fromisoformat` → `ValueError`), an asyncpg connection/transaction/constraint error, an invalid `portfolio_id` UUID (asyncpg `$1::uuid` cast error at execute time, not pre-validated here — contrast governance which pre-validates). All caught by outer `except` → `emit_code_step_complete(FAILED)` → `raise` → decorator classification (asyncpg connection/timeout → RetryableError; ValueError → NonRetryableError) → workflow swallows.
- **Idempotency:** NOT idempotent for the append tables (`patching_compliance`, `incident_log`, `sla_compliance_record`, `cost_anomaly_record`, `sustainment_override_log`) — re-running the activity for the same sweep INSERTs duplicate rows (no unique key on `sweep_id`). `do_not_modify_flag` IS idempotent on `(portfolio_id, app_id)` via the upsert. The `application` UPDATE is idempotent (sets the same status/timestamp). ⚠️ Because the workflow swallows failures and may not retry, partial-then-rollback is the failure mode, not partial commit (single transaction).

### 2.8 Column-by-column mapping — `persist_sustainment_sweep_side_effects`

#### Table `patching_compliance` (migration 037:63)
| artifact source → row key | table.column | type / default / NOT NULL | condition |
|---|---|---|---|
| (server) | `patching_compliance.id` | UUID PK, default `gen_random_uuid()` | not written; DB-generated |
| `input.portfolio_id` → `portfolio_id` | `patching_compliance.portfolio_id` | UUID NOT NULL (`$1::uuid`) | always (when patching_row) |
| `input.schedule_id` → `sweep_id` | `patching_compliance.sweep_id` | VARCHAR(255) NOT NULL | always |
| `summary.{critical_open_count\|critical_open\|open_critical}` → `critical_open_count` | `patching_compliance.critical_open_count` | INT NOT NULL default 0 | always (int, 0 fallback) |
| `summary.{high_*}` → `high_open_count` | `patching_compliance.high_open_count` | INT NOT NULL default 0 | always |
| `summary.{medium_*}` → `medium_open_count` | `patching_compliance.medium_open_count` | INT NOT NULL default 0 | always |
| `summary.{low_*}` → `low_open_count` | `patching_compliance.low_open_count` | INT NOT NULL default 0 | always |
| `summary.{sla_compliance_pct\|sla_compliance\|compliance_pct}` → `sla_compliance_pct` | `patching_compliance.sla_compliance_pct` | NUMERIC(5,2) NULL | value or NULL (Python `None`) |
| `sweep_completed_at` → `evaluated_at` | `patching_compliance.evaluated_at` | TIMESTAMPTZ NOT NULL default now() | always |
| — | (row written only if) | — | `(crit+high+med+low)>0 OR sla_pct not None` |

#### Table `incident_log` (migration 037:116) — one row per incident
| artifact source → row key | table.column | type / default / NOT NULL | condition |
|---|---|---|---|
| (server) | `incident_log.id` | UUID PK default `gen_random_uuid()` | DB-generated |
| `input.portfolio_id` | `incident_log.portfolio_id` | UUID NOT NULL (`$1::uuid`) | always |
| `input.schedule_id` → `sweep_id` | `incident_log.sweep_id` | VARCHAR(255) NOT NULL | always |
| `inc.{app_id\|application_id}` → `app_id` (or None) | `incident_log.app_id` | UUID NULL, FK app ON DELETE SET NULL (`NULLIF($3,'')::uuid`) | NULL if empty |
| `inc.severity` (strip, [:16], else "unknown") | `incident_log.severity` | VARCHAR(16) NOT NULL | always (default "unknown") |
| `inc.{symptom\|category}` | `incident_log.symptom` | VARCHAR(255) NULL | always (may be "") |
| `inc.status` (default "open") | `incident_log.status` | VARCHAR(32) NOT NULL | always |
| `inc.{resolution_summary\|resolution}` | `incident_log.resolution_summary` | TEXT NULL | always (may be "") |
| `sweep_completed_at` → `recorded_at` | `incident_log.recorded_at` | TIMESTAMPTZ NOT NULL default now() | always |

#### Table `sla_compliance_record` (migration 037:156) — one row per app (app_id required)
| artifact source → row key | table.column | type / default / NOT NULL | condition |
|---|---|---|---|
| (server) | `sla_compliance_record.id` | UUID PK default `gen_random_uuid()` | DB-generated |
| `input.portfolio_id` | `sla_compliance_record.portfolio_id` | UUID NOT NULL (`$1::uuid`) | always |
| `input.schedule_id` → `sweep_id` | `sla_compliance_record.sweep_id` | VARCHAR(255) NOT NULL | always |
| `m.{app_id\|application_id}` | `sla_compliance_record.app_id` | UUID NOT NULL, FK app ON DELETE CASCADE (`$3::uuid`) | row skipped if empty |
| `m.{availability_pct\|availability}` | `sla_compliance_record.availability_pct` | NUMERIC(5,3) NULL | value or NULL |
| `m.{response_time_p95_ms\|p95_ms\|latency_p95_ms}` | `sla_compliance_record.response_time_p95_ms` | NUMERIC(10,2) NULL | value or NULL |
| `m.{incident_resolution_mean_hours\|mttr_hours}` | `sla_compliance_record.incident_resolution_mean_hours` | NUMERIC(10,2) NULL | value or NULL |
| `m.{breach_count\|breaches}` (int, default 0) | `sla_compliance_record.breach_count` | INT NOT NULL default 0 | always |
| `sweep_completed_at` → `recorded_at` | `sla_compliance_record.recorded_at` | TIMESTAMPTZ NOT NULL default now() | always |

#### Table `do_not_modify_flag` (migration 037:212) — UPSERT on (portfolio_id, app_id)
| artifact source → row key | table.column | type / default / NOT NULL | condition |
|---|---|---|---|
| (server) | `do_not_modify_flag.id` | UUID PK default `gen_random_uuid()` | DB-generated (insert path only) |
| `input.portfolio_id` | `do_not_modify_flag.portfolio_id` | UUID NOT NULL (`$1::uuid`); conflict key | always |
| `f.{app_id\|application_id}` | `do_not_modify_flag.app_id` | UUID NOT NULL, FK app ON DELETE CASCADE (`$2::uuid`); conflict key | row skipped if empty |
| `f.flagged_at` (str) else `recorded_at.isoformat()` | `do_not_modify_flag.flagged_at` | TIMESTAMPTZ NOT NULL default now() (`$3::timestamptz`) | INSERT only; **NOT updated on conflict** |
| `f.wave_id` (str or None) | `do_not_modify_flag.wave_id` | UUID NULL (`NULLIF($4,'')::uuid`) | INSERT + UPDATE (`EXCLUDED.wave_id`) |
| `f.expires_at` (str) else None | `do_not_modify_flag.expires_at` | TIMESTAMPTZ NULL (`$5::timestamptz`) | INSERT + UPDATE (`EXCLUDED.expires_at`) |
| `f.active` (bool, default True) | `do_not_modify_flag.active` | BOOL NOT NULL default true | INSERT + UPDATE (`EXCLUDED.active`) |
| `f.override_count` (int, default 0) | `do_not_modify_flag.override_count` | INT NOT NULL default 0 | INSERT + UPDATE (`EXCLUDED.override_count`) — ⚠️ overwritten from artifact, not incremented |

#### Table `cost_anomaly_record` (migration 037:267) — one row per app (app_id required)
| artifact source → row key | table.column | type / default / NOT NULL | condition |
|---|---|---|---|
| (server) | `cost_anomaly_record.id` | UUID PK default `gen_random_uuid()` | DB-generated |
| `input.portfolio_id` | `cost_anomaly_record.portfolio_id` | UUID NOT NULL (`$1::uuid`) | always |
| `input.schedule_id` → `sweep_id` | `cost_anomaly_record.sweep_id` | VARCHAR(255) NOT NULL | always |
| `a.{app_id\|application_id}` | `cost_anomaly_record.app_id` | UUID NOT NULL, FK app CASCADE (`$3::uuid`) | row skipped if empty |
| `a.{baseline_usd\|baseline}` | `cost_anomaly_record.baseline_usd` | NUMERIC(14,2) NULL | value or NULL |
| `a.{observed_usd\|observed\|actual_usd}` | `cost_anomaly_record.observed_usd` | NUMERIC(14,2) NULL | value or NULL |
| `a.{variance_pct\|variance}` | `cost_anomaly_record.variance_pct` | NUMERIC(7,2) NULL | value or NULL |
| `a.flagged` (bool, default False) | `cost_anomaly_record.flagged` | BOOL NOT NULL default false | always |
| `sweep_completed_at` → `recorded_at` | `cost_anomaly_record.recorded_at` | TIMESTAMPTZ NOT NULL default now() | always |

#### Table `sustainment_override_log` (migration 037:312) — one row per override decision
| artifact source → row key | table.column | type / default / NOT NULL | condition |
|---|---|---|---|
| (server) | `sustainment_override_log.id` | UUID PK default `gen_random_uuid()` | DB-generated |
| `input.portfolio_id` | `sustainment_override_log.portfolio_id` | UUID NOT NULL (`$1::uuid`) | always |
| `dec.app_id` (str or None) | `sustainment_override_log.app_id` | UUID NULL, FK app SET NULL (`NULLIF($2,'')::uuid`) | NULL if empty |
| `dec.gate_id` (str, default "") | `sustainment_override_log.gate_id` | VARCHAR(255) NULL | always (may be "") |
| `dec.override_by` (str, default "") | `sustainment_override_log.override_by` | VARCHAR(255) NOT NULL | always |
| `dec.justification` (str, default "") | `sustainment_override_log.justification` | TEXT NULL | always (may be "") |
| `dec.override_type` (str, default "") | `sustainment_override_log.override_type` | VARCHAR(64) NOT NULL | always |
| `sweep_completed_at` → `recorded_at` | `sustainment_override_log.recorded_at` | TIMESTAMPTZ NOT NULL default now() | always |

#### Table `application` (lifecycle cols, migration 037:344) — UPDATE per touched app
| source → updates key | table.column | type / NULL | condition |
|---|---|---|---|
| ladder result `sustainment_current_status` | `application.sustainment_current_status` | VARCHAR(64) NULL | ⚠️ written ONLY if `"sustainment_current_status" in updates` (i.e. app got a status) |
| `sweep_completed_at` → `sustainment_last_sweep_at` | `application.sustainment_last_sweep_at` | TIMESTAMPTZ NULL | always for every touched app |
| `datetime.now(timezone.utc)` | `application.updated_at` | (pre-existing col) | always written in this UPDATE |
| `uuid.UUID(app_id)` | (WHERE `id = $N`) | — | row must exist + UUID-parseable, else skipped (`continue`) |

⚠️ Columns NOT written by sustainment: every other `application` column (Discovery/Rationalization/Architecture/etc own them). Only `sustainment_current_status`, `sustainment_last_sweep_at`, `updated_at` are touched.

---

## 3. ACTIVITY: `persist_governance_sweep_side_effects` (5514–5790)

### 3.1 Signature
```python
@foundry_activity(config=ActivityConfig(enable_observability=True))   # line 5513
async def persist_governance_sweep_side_effects(
    input: PersistGovernanceSweepSideEffectsInput,
) -> PersistGovernanceSweepSideEffectsResult:
```

### 3.2 Input dataclass — `PersistGovernanceSweepSideEffectsInput` (types.py:2428, EVERY field)
```python
@dataclass
class PersistGovernanceSweepSideEffectsInput:
    portfolio_id: str                                   # REQUIRED; pre-validated as UUID (else NonRetryableError)
    schedule_id: str                                    # REQUIRED; → sweep_id on capacity/model rows
    cadence: str = "weekly"                             # "weekly" | "quarterly"; gates model-benchmark
    drift_detection_json: str = ""                      # → drift_alert
    pattern_extraction_json: str = ""                   # → pattern
    health_report_json: str = ""                        # → health_check
    factory_capacity_json: str = ""                     # → factory_capacity_plan
    model_evaluation_json: str = ""                     # → model_benchmark_result (quarterly only)
    pattern_reuse_acks: list[dict] = field(default_factory=list)   # {pattern_name, delta} → reuse_count UPDATE
    execution_context: "StepExecutionContext | None" = None
```
⚠️ Field is `pattern_reuse_acks` (list of dicts). The docstring mentions `ack_count` but the extractor reads `delta` (default 1) — see `_apply_pattern_reuse_count_updates`.

### 3.3 Output dataclass — `PersistGovernanceSweepSideEffectsResult` (types.py:2461, EVERY field)
```python
@dataclass
class PersistGovernanceSweepSideEffectsResult:
    portfolio_id: str
    schedule_id: str
    drift_alerts_inserted: int = 0
    patterns_inserted: int = 0
    patterns_reuse_count_updated: int = 0
    health_checks_inserted: int = 0
    factory_capacity_plans_inserted: int = 0
    model_benchmark_results_inserted: int = 0
```

### 3.4 Control flow (exact sequence)
1. `exec_id = await emit_code_step_start(input.execution_context, function_name="persist_governance_sweep_side_effects")`.
2. Open outer `try:`.
3. **Validate portfolio_id (5535–5540):** `portfolio_uuid = uuid.UUID(input.portfolio_id)`; on `(ValueError, TypeError)` → `raise NonRetryableError(f"Invalid portfolio_id: {input.portfolio_id!r}")`. ⚠️ This is a hard pre-validation (governance does NOT defer to a SQL cast like sustainment does). `NonRetryableError` is a `WorkflowError` subclass so the decorator re-raises it bare; the outer `except` still runs `emit_code_step_complete(FAILED)` first, then re-raises.
4. Extract rows (best-effort, pure helpers — §3.6):
   - `drift_alert_rows = _extract_drift_alert_side_effects(_try_parse_json(input.drift_detection_json))`
   - `pattern_rows = _extract_pattern_side_effects(_try_parse_json(input.pattern_extraction_json))`
   - `health_row = _extract_health_check_side_effects(_try_parse_json(input.health_report_json))` (dict or None)
   - `capacity_row = _extract_factory_capacity_side_effects(_try_parse_json(input.factory_capacity_json))` (dict or None)
   - **Model benchmark (quarterly gate, 5556–5560):** `model_rows = []`; `if input.cadence == "quarterly" and input.model_evaluation_json:` → `model_rows = _extract_model_benchmark_side_effects(_try_parse_json(input.model_evaluation_json))`. ⚠️ Weekly sweeps (or empty model JSON) skip the extractor entirely.
   - `reuse_updates = _apply_pattern_reuse_count_updates(input.pattern_reuse_acks)`.
5. **Empty short-circuit (5566):** if `not drift_alert_rows and not pattern_rows and health_row is None and capacity_row is None and not model_rows and not reuse_updates` → log `"persist_governance_sweep_side_effects: nothing extractable"` (extra portfolio_id, schedule_id), `await emit_code_step_complete(exec_id, columns_written=[])`, **return** `PersistGovernanceSweepSideEffectsResult(portfolio_id=input.portfolio_id, schedule_id=input.schedule_id)` (counts default 0). No DB connection.
6. `now_ts = datetime.now(timezone.utc)`.
7. `conn = await asyncpg.connect(_db_url())`; init six counters to 0; `try: async with conn.transaction():` → run writes (§3.5) → `finally: await conn.close()`.
8. Log `"governance sweep side-effects persisted"` (extra: portfolio_id, schedule_id, cadence, drift_alerts, patterns, patterns_reuse_updated, health_checks, factory_capacity_plans, model_benchmark_results).
9. `await emit_code_step_complete(exec_id, columns_written=["drift_alert","pattern","health_check","factory_capacity_plan","model_benchmark_result"])` — static literal list (5768–5774).
10. Return `PersistGovernanceSweepSideEffectsResult(portfolio_id, schedule_id, drift_alerts_inserted=drift_inserted, patterns_inserted, patterns_reuse_count_updated=reuse_updated, health_checks_inserted=health_inserted, factory_capacity_plans_inserted=capacity_inserted, model_benchmark_results_inserted=model_inserted)`.
11. Outer `except Exception as exc:` → `await emit_code_step_complete(exec_id, status=ExecutionStatus.FAILED, error=str(exc)); raise`.

⚠️ **Single transaction** for all five tables + reuse_count UPDATE. ⚠️ Governance writes ZERO `application` columns (it is purely portfolio-scoped — see the comment block at 5213–5218).

### 3.5 SQL writes (exact, in execution order inside the transaction)

**(a) `drift_alert`** — one INSERT per row in `drift_alert_rows` (5606):
```sql
INSERT INTO drift_alert (
    type, application_id, details, acknowledged, created_at
) VALUES ($1, $2, $3::jsonb, $4, $5)
```
Per row: resolve `app_uuid` (None unless `row["app_id"]` truthy AND `uuid.UUID(...)` succeeds; parse failure → None). Params: `row["drift_type"]` (→ `type`), `app_uuid` (→ `application_id`), `json.dumps({"severity": row["severity"], **(row.get("details") or {})})` (→ `details::jsonb`), `row["acknowledged"]` (→ `acknowledged`), `now_ts` (→ `created_at`). ⚠️ The `severity` enum value is folded INTO the `details` JSONB (there is no dedicated severity column on `drift_alert`); the artifact's own `details` keys are merged after `severity` (so a `details.severity` would override). `drift_inserted += 1` each.

**(b) `pattern`** — one INSERT per row in `pattern_rows` (5633):
```sql
INSERT INTO pattern (
    name, category, description, wave_id,
    source_apps, reuse_count, content, created_at
) VALUES ($1, $2, $3, $4, $5::jsonb, 0, $6::jsonb, $7)
```
Per row: resolve `wave_uuid` (None unless `row["wave_id"]` truthy and UUID-parseable). Params: `row["name"]`, `row["category"]`, `row.get("description")`, `wave_uuid`, `json.dumps(row["source_apps"])` (→ `source_apps::jsonb`), `json.dumps(row["content"])` (→ `content::jsonb`), `now_ts`. ⚠️ `reuse_count` is **hard-coded literal `0`** on insert (NOT a param). `patterns_inserted += 1` each.

**(c) `pattern.reuse_count` bulk UPDATE** — one UPDATE per `(name, delta)` in `reuse_updates` (5653):
```sql
UPDATE pattern SET reuse_count = reuse_count + $1 WHERE name = $2
```
Params: `delta`, `name`. ⚠️ **In-place increment** (`reuse_count + $1`) so concurrent sweeps don't clobber the counter. Parse the asyncpg command tag `"UPDATE N"`: `count = int(result.rsplit(" ", 1)[-1])` (ValueError/IndexError → 0); `reuse_updated += count`. ⚠️ Matches by `name` (no portfolio scoping) — if multiple patterns share a name, ALL are incremented and counted.

**(d) `health_check`** — single INSERT if `health_row is not None` (5672):
```sql
INSERT INTO health_check (
    portfolio_id, date, health_index, checks, created_at
) VALUES ($1, $2, $3, $4::jsonb, $5)
```
Params: `portfolio_uuid`, `now_ts.date()` (→ `date`, a DATE), `health_row["health_index"]` (float), `json.dumps(health_row["checks"])` (→ `checks::jsonb`), `now_ts`. `health_inserted = 1`.

**(e) `factory_capacity_plan`** — single INSERT if `capacity_row is not None` (5690):
```sql
INSERT INTO factory_capacity_plan (
    portfolio_id, sweep_id, concurrent_wave_max,
    throughput_apps_per_month, cost_per_app_usd,
    gate_first_pass_rate, ralph_loop_iteration_avg,
    escalation_rate, pattern_reuse_rate, automation_ratio,
    time_to_modernize_days, computed_at
) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12)
```
Params: `portfolio_uuid`, `input.schedule_id` (→ `sweep_id`), then `capacity_row.get(<field>)` for each of `concurrent_wave_max, throughput_apps_per_month, cost_per_app_usd, gate_first_pass_rate, ralph_loop_iteration_avg, escalation_rate, pattern_reuse_rate, automation_ratio, time_to_modernize_days`, then `now_ts` (→ `computed_at`). ⚠️ Any field absent from `capacity_row` → `.get()` returns `None` → column NULL. `capacity_inserted = 1`.

**(f) `model_benchmark_result`** — one INSERT per row in `model_rows` (5724) (only populated when quarterly):
```sql
INSERT INTO model_benchmark_result (
    portfolio_id, sweep_id, model_id, tier, task_suite,
    pass_rate, cost_per_call_usd, latency_p95_ms,
    regression_flag, refresh_recommended, benchmarked_at
) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11)
```
Params: `portfolio_uuid`, `input.schedule_id` (→ `sweep_id`), `row["model_id"]`, `row["tier"]`, `row["task_suite"]`, `row.get("pass_rate")`, `row.get("cost_per_call_usd")`, `row.get("latency_p95_ms")`, `row.get("regression_flag", False)`, `row.get("refresh_recommended", False)`, `row.get("benchmarked_at") or now_ts`. ⚠️ `regression_flag`/`refresh_recommended` default `False` when absent; `benchmarked_at` falls back to `now_ts`. `model_inserted += 1` each.

### 3.6 Pure extractor helpers for governance (REPRODUCE EXACTLY)

Module constants (5235–5241):
```python
_DRIFT_TYPES = frozenset({"architecture","compliance","performance","cost","adoption"})
_DRIFT_SEVERITIES = frozenset({"critical","high","medium","low"})
_MODEL_TIERS = frozenset({"Tier-1","Tier-2","Tier-3"})
```

**`_extract_drift_alert_side_effects(artifact) -> list[dict]`** (5244)
- Not dict → `[]`. `alerts = artifact.get("alerts")`; not a list → `[]`.
- Per `entry` dict (skip non-dicts):
  - `drift_type = entry.get("drift_type")`; if not str OR not in `_DRIFT_TYPES` → log warning `"drift_alert row skipped — invalid drift_type"` (extra drift_type) and `continue`.
  - `severity = entry.get("severity")`; if not str OR not in `_DRIFT_SEVERITIES` → log warning `"drift_alert row skipped — invalid severity"` and `continue`.
  - `app_id = entry.get("app_id")`; `details = entry.get("details")`; `acknowledged = entry.get("acknowledged")`.
  - append `{app_id: app_id if isinstance str and truthy else None, drift_type, severity, details: details if isinstance dict else {}, acknowledged: bool(acknowledged) if isinstance bool else False}`.

**`_extract_pattern_side_effects(artifact) -> list[dict]`** (5299)
- Not dict → `[]`. `patterns = artifact.get("patterns")`; not list → `[]`.
- Per `entry` dict (skip non-dicts):
  - `name = entry.get("name")`; if not str or empty → `continue`.
  - `category = entry.get("category")`; if not str or empty → `continue`.
  - `source_apps = entry.get("source_apps")`; if not list → `[]`.
  - `content = entry.get("content")`; if not dict → `{}`.
  - `wave_id = entry.get("wave_id")`; `description = entry.get("description")`.
  - append `{name, category, wave_id: wave_id if isinstance str and truthy else None, source_apps, content, description: description if isinstance str else None}`.

**`_extract_health_check_side_effects(artifact) -> dict | None`** (5348)
- Not dict → `None`.
- `idx = artifact.get("portfolio_health_index") or artifact.get("health_index")`; if not `(int,float)` → `None` (skip; column is NOT NULL — no sentinel insert).
- `checks = artifact.get("per_dimension_findings") or artifact.get("checks") or []`; if not list → `[]`.
- return `{health_index: float(idx), checks}`.
- ⚠️ `idx` uses `or`, so `portfolio_health_index == 0` (falsy) falls through to `health_index` then `0`/None. A literal health index of `0.0` would be treated as falsy and could pick up `health_index` or skip — edge case to preserve.

**`_extract_factory_capacity_side_effects(artifact) -> dict | None`** (5383)
- Not dict → `None`. `out = {}`.
- `scalar_fields = ("concurrent_wave_max","throughput_apps_per_month","cost_per_app_usd","gate_first_pass_rate","ralph_loop_iteration_avg","escalation_rate","pattern_reuse_rate","automation_ratio","time_to_modernize_days")`.
- For each field: `val = artifact.get(field)`; if `isinstance(val,(int,float))` → `out[field] = int(val) if field == "concurrent_wave_max" else float(val)`. ⚠️ `concurrent_wave_max` coerced to **int**, all others to **float**.
- if `out` empty → `None`; else `out`.

**`_extract_model_benchmark_side_effects(artifact) -> list[dict]`** (5415)
- Not dict → `[]`. `results = artifact.get("results")`; not list → `[]`.
- Per `entry` dict (skip non-dicts):
  - `model_id = entry.get("model_id")`; if not str or empty → `continue`.
  - `task_suite = entry.get("task_suite")`; if not str or empty → `continue`.
  - `tier = entry.get("tier")`; if not str OR not in `_MODEL_TIERS` → log warning `"model_benchmark_result row skipped — invalid tier"` (extra model_id, tier) and `continue`.
  - base `row = {model_id, tier, task_suite}`.
  - For `key in ("pass_rate","cost_per_call_usd")`: if `isinstance(val,(int,float))` → `row[key] = float(val)` (else absent).
  - `latency = entry.get("latency_p95_ms")`; if `(int,float)` → `row["latency_p95_ms"] = int(latency)`.
  - For `flag_key in ("regression_flag","refresh_recommended")`: if `isinstance(val, bool)` → `row[flag_key] = val` (else absent → SQL defaults False).
  - `benchmarked_at = entry.get("benchmarked_at")`; if str+truthy → `row["benchmarked_at"] = datetime.fromisoformat(benchmarked_at.replace("Z","+00:00"))` (on TypeError/ValueError → log warning, leave absent → SQL uses now_ts).
  - append row.

**`_apply_pattern_reuse_count_updates(acks) -> list[tuple[str, int]]`** (5487)
- `acks` not a list → `[]`. `totals: dict[str,int] = {}`.
- Per `entry` dict (skip non-dicts):
  - `name = entry.get("pattern_name")`; if not str or empty → `continue`.
  - `delta = entry.get("delta") if isinstance(entry.get("delta"), int) else 1`. ⚠️ Reads key `delta`; defaults to **1** if missing or non-int. ⚠️ `bool` IS an `int` in Python so `delta: True` → 1, `delta: False` → 0.
  - `totals[name] = totals.get(name, 0) + int(delta)` (collapses dup names by summing).
- return `[(name, delta) for name, delta in totals.items() if delta > 0]`. ⚠️ Only positive net deltas survive (a name summing to ≤0 is dropped).

### 3.7 Error handling / retries / idempotency (governance)
- **Pre-validation:** invalid `portfolio_id` → `NonRetryableError` (raised before any DB work). Decorator re-raises bare (WorkflowError subclass), outer except emits FAILED.
- **Best-effort:** unparseable artifacts log warnings inside extractors and contribute no rows; the workflow still commits sweep-summary.json even if this activity raises (docstring).
- **What can raise out of body:** the `NonRetryableError` above; asyncpg connection/transaction errors; a malformed `benchmarked_at` is handled inside the extractor (warn + skip), so it does NOT raise. All caught by outer except → FAILED → re-raise → decorator classify → workflow swallow.
- **Idempotency:** NOT idempotent — `drift_alert`, `pattern`, `health_check`, `factory_capacity_plan`, `model_benchmark_result` all INSERT-only (no unique/sweep key). Re-running duplicates rows. The reuse_count UPDATE is additive — re-running double-counts. ⚠️ This is acceptable because the cron workflow runs once per scheduled sweep and the projection is best-effort/non-retried.

### 3.8 Column-by-column mapping — `persist_governance_sweep_side_effects`

#### Table `drift_alert` (migration 025:55) — one row per alert
| artifact source → row key | table.column | type / default / NULL | condition |
|---|---|---|---|
| (server) | `drift_alert.id` | UUID PK default `gen_random_uuid()` | DB-generated |
| `entry.drift_type` (whitelisted `_DRIFT_TYPES`) → `drift_type` | `drift_alert.type` | VARCHAR(100) NOT NULL | row skipped if invalid |
| `entry.app_id` → resolved `app_uuid` | `drift_alert.application_id` | UUID NULL, FK app ON DELETE CASCADE | NULL if empty/unparseable |
| `{"severity": severity, **details}` | `drift_alert.details` | JSONB NULL (`$3::jsonb`) | always (severity folded in) |
| `entry.acknowledged` (bool, default False) | `drift_alert.acknowledged` | BOOL NOT NULL default false | always |
| `now_ts` | `drift_alert.created_at` | TIMESTAMPTZ NOT NULL default now() | always |
| — | `drift_alert.acknowledged_by` | VARCHAR(255) NULL | NOT written (defaults NULL) |
| — | `drift_alert.acknowledged_at` | TIMESTAMPTZ NULL | NOT written |

#### Table `pattern` (migration 025:94) — INSERT (one per pattern) + reuse_count UPDATE
| artifact source → row key | table.column | type / default / NULL | condition |
|---|---|---|---|
| (server) | `pattern.id` | UUID PK default `gen_random_uuid()` | DB-generated |
| `entry.name` (required non-empty) | `pattern.name` | VARCHAR(255) NOT NULL | row skipped if empty |
| `entry.category` (required non-empty) | `pattern.category` | VARCHAR(100) NOT NULL | row skipped if empty |
| `entry.description` | `pattern.description` | TEXT NULL | always (may be None) |
| `entry.wave_id` → `wave_uuid` | `pattern.wave_id` | UUID NULL | NULL if empty/unparseable |
| `entry.source_apps` (list, default []) | `pattern.source_apps` | JSONB NOT NULL default `'[]'` (`$5::jsonb`) | always |
| literal `0` | `pattern.reuse_count` | INT NOT NULL default 0 | INSERT writes literal 0; later UPDATEd by `reuse_updates` |
| `entry.content` (dict, default {}) | `pattern.content` | JSONB NULL (`$6::jsonb`) | always |
| `now_ts` | `pattern.created_at` | TIMESTAMPTZ NOT NULL default now() | always |
| `reuse_updates` `(name, delta)` | `pattern.reuse_count` (UPDATE `reuse_count + delta` WHERE `name=`) | INT NOT NULL | per reuse ack; matches by name only |

#### Table `health_check` (migration 025:28) — single row per sweep
| artifact source → row key | table.column | type / default / NULL | condition |
|---|---|---|---|
| (server) | `health_check.id` | UUID PK default `gen_random_uuid()` | DB-generated |
| `portfolio_uuid` | `health_check.portfolio_id` | UUID NULL | always (when health_row) |
| `now_ts.date()` | `health_check.date` | DATE NOT NULL | always |
| `{portfolio_health_index\|health_index}` → `health_index` (float) | `health_check.health_index` | NUMERIC(4,3) NOT NULL | row skipped if not numeric |
| `{per_dimension_findings\|checks}` → `checks` (list) | `health_check.checks` | JSONB NOT NULL default `'[]'` (`$4::jsonb`) | always |
| `now_ts` | `health_check.created_at` | TIMESTAMPTZ NOT NULL default now() | always |

#### Table `factory_capacity_plan` (migration 038:47) — single row per sweep
| artifact source → row key | table.column | type / default / NULL | condition |
|---|---|---|---|
| (server) | `factory_capacity_plan.id` | UUID PK default `gen_random_uuid()` | DB-generated |
| `portfolio_uuid` | `factory_capacity_plan.portfolio_id` | UUID NULL | always (when capacity_row) |
| `input.schedule_id` | `factory_capacity_plan.sweep_id` | VARCHAR(255) NOT NULL | always |
| `artifact.concurrent_wave_max` (int) | `factory_capacity_plan.concurrent_wave_max` | INT NULL | NULL if absent/non-numeric |
| `artifact.throughput_apps_per_month` (float) | `factory_capacity_plan.throughput_apps_per_month` | NUMERIC(10,2) NULL | NULL if absent |
| `artifact.cost_per_app_usd` (float) | `factory_capacity_plan.cost_per_app_usd` | NUMERIC(12,2) NULL | NULL if absent |
| `artifact.gate_first_pass_rate` (float) | `factory_capacity_plan.gate_first_pass_rate` | NUMERIC(5,4) NULL | NULL if absent |
| `artifact.ralph_loop_iteration_avg` (float) | `factory_capacity_plan.ralph_loop_iteration_avg` | NUMERIC(6,2) NULL | NULL if absent |
| `artifact.escalation_rate` (float) | `factory_capacity_plan.escalation_rate` | NUMERIC(5,4) NULL | NULL if absent |
| `artifact.pattern_reuse_rate` (float) | `factory_capacity_plan.pattern_reuse_rate` | NUMERIC(5,4) NULL | NULL if absent |
| `artifact.automation_ratio` (float) | `factory_capacity_plan.automation_ratio` | NUMERIC(5,4) NULL | NULL if absent |
| `artifact.time_to_modernize_days` (float) | `factory_capacity_plan.time_to_modernize_days` | NUMERIC(8,2) NULL | NULL if absent |
| `now_ts` | `factory_capacity_plan.computed_at` | TIMESTAMPTZ NOT NULL default now() | always |
| — | (row written only if) | — | `capacity_row is not None` (≥1 numeric scalar present) |

#### Table `model_benchmark_result` (migration 038:91) — one row per (model_id, task_suite); QUARTERLY only
| artifact source → row key | table.column | type / default / NULL | condition |
|---|---|---|---|
| (server) | `model_benchmark_result.id` | UUID PK default `gen_random_uuid()` | DB-generated |
| `portfolio_uuid` | `model_benchmark_result.portfolio_id` | UUID NULL | always (per row) |
| `input.schedule_id` | `model_benchmark_result.sweep_id` | VARCHAR(255) NOT NULL | always |
| `entry.model_id` (required) | `model_benchmark_result.model_id` | VARCHAR(255) NOT NULL | row skipped if empty |
| `entry.tier` (whitelisted `_MODEL_TIERS`) | `model_benchmark_result.tier` | VARCHAR(20) NOT NULL | row skipped if invalid |
| `entry.task_suite` (required) | `model_benchmark_result.task_suite` | VARCHAR(255) NOT NULL | row skipped if empty |
| `entry.pass_rate` (float) | `model_benchmark_result.pass_rate` | NUMERIC(5,4) NULL | NULL if absent |
| `entry.cost_per_call_usd` (float) | `model_benchmark_result.cost_per_call_usd` | NUMERIC(12,6) NULL | NULL if absent |
| `entry.latency_p95_ms` (int) | `model_benchmark_result.latency_p95_ms` | INT NULL | NULL if absent |
| `entry.regression_flag` (bool, default False) | `model_benchmark_result.regression_flag` | BOOL NOT NULL default false | always (`.get(...,False)`) |
| `entry.refresh_recommended` (bool, default False) | `model_benchmark_result.refresh_recommended` | BOOL NOT NULL default false | always (`.get(...,False)`) |
| `entry.benchmarked_at` (ISO→dt) or `now_ts` | `model_benchmark_result.benchmarked_at` | TIMESTAMPTZ NOT NULL default now() | always |
| — | (rows written only if) | — | `cadence == "quarterly"` AND `model_evaluation_json` non-empty |

⚠️ Governance writes NO `application` columns and NO other tables. The `application` row, `cost_anomaly_record`, `sustainment_*`, etc are NOT touched by this activity.

---

## 4. Cross-cutting GOTCHAS (both activities)

1. **Best-effort contract:** Both are projections, not pipeline-critical. The cron workflow swallows their failures so the sweep-summary commit proceeds. A rebuild MUST NOT make these raise into the workflow as fatal — they must be schedulable as fire-and-(mostly)-forget. The internal behavior on bad input is: extractors return empty → empty short-circuit → 0-count result (NOT an exception). Exceptions only escape on DB transients, malformed `sweep_completed_at` (sustainment), or invalid `portfolio_id` (governance).
2. **Single transaction per activity:** All table writes share one `conn.transaction()`. Any failure rolls back the whole projection. There is no partial-commit; the data layer either sees the full sweep projection or none of it.
3. **`emit_code_step_*` columns are static supersets**, emitted regardless of which rows were actually written. Do not infer touched-columns from the emitted list — infer from the result counts.
4. **`NULLIF($n, '')::uuid` idiom:** sustainment passes `row["x"] or ""` to columns that may be NULL (`incident_log.app_id`, `do_not_modify_flag.wave_id`, `sustainment_override_log.app_id`) so the empty string becomes SQL NULL. Governance instead resolves UUIDs in Python (`uuid.UUID(...)` in try/except → None) and binds a real `uuid.UUID | None`. Two different NULL-handling styles in the same file — preserve each per-activity.
5. **`portfolio_id` validation divergence:** governance pre-validates with `uuid.UUID` → `NonRetryableError`; sustainment does NOT — it relies on the `$1::uuid` cast inside the transaction (so a bad portfolio_id surfaces as a generic asyncpg error mid-transaction, not a typed NonRetryableError).
6. **`pattern.reuse_count` race-safety:** must be `reuse_count = reuse_count + $1` (read-modify-write in SQL), NOT a read-then-set, so concurrent governance sweeps don't clobber. Matched by `name` ONLY (no portfolio scope).
7. **`drift_alert` has no severity column:** severity is folded into the `details` JSONB (`{"severity": ..., **details}`). A rebuild adding a real severity column would diverge from the dashboard's read path.
8. **Quarterly gate:** `model_benchmark_result` rows are produced ONLY when `input.cadence == "quarterly"` AND `input.model_evaluation_json` is non-empty. Weekly sweeps never touch that table.
9. **`concurrent_wave_max` is the only int-coerced capacity field**; all other factory-capacity scalars are float-coerced. Numeric precisions differ per column (see mapping) — overflow truncation is the DB's responsibility, the activity does not clamp.
10. **`_try_parse_json` returns None for non-dict top-level JSON** (arrays/scalars), and EVERY extractor guards `if not isinstance(artifact, dict): return [] / None`. So a JSON array artifact silently yields zero rows.
