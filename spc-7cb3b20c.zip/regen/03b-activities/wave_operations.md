# Activity Group: `wave_operations` — Wave Status Transitions & Failure Projection

**Source file:** `temporal/olympus_workflows/activities/wave_operations.py` (310 lines)
**Module purpose:** Wave-level (not per-app) side-effect projections. These write to the **`wave`** table only — deliberately kept out of `line_transitions` (which projects per-app `persist_*_side_effects` onto `application`). All three activities are registered on the Temporal worker by importing this module.

This group contains **3 activities**, all `async def` taking a single dataclass `input` argument:

| Activity | Input type | Output type | Writes to |
|---|---|---|---|
| `persist_wave_failure` | `PersistWaveFailureInput` | `None` | `wave` (status/failed_at/failure_reason/updated_at) |
| `update_wave_status` | `UpdateWaveStatusInput` | `UpdateWaveStatusResult` | `wave` (status/updated_at, conditionally failure_reason/failed_at) |
| `update_wave_architecture_workflow_id` | `UpdateWaveArchitectureWorkflowIdInput` | `None` | `wave` (architecture_workflow_id/updated_at) |

---

## 0. The `@foundry_activity` Decorator (applies to ALL 3 activities)

Every activity here is decorated:
```python
@foundry_activity(config=ActivityConfig(enable_observability=True))
```
imported as `from foundry_temporal.activities import ActivityConfig, foundry_activity`.

**This is NOT plain `@activity.defn`.** A rebuild using `@activity.defn` directly loses error-wrapping + retryability classification + observability logging. Reproduce the wrapper exactly (`foundry_temporal/activities.py` lines 107–165):

### `ActivityConfig` (dataclass, all fields default)
- `retry_policy: RetryPolicy | None = None`
- `start_to_close_timeout / schedule_to_close_timeout / schedule_to_start_timeout / heartbeat_timeout: timedelta | None = None`
- `enable_observability: bool = True`  ← **set True here (explicit)**
- `enable_error_wrapping: bool = True`  ← **defaulted True (NOT set explicitly, but active)**
- `log_inputs: bool = False`
- `log_outputs: bool = False`

### `foundry_activity(config, name=None, **activity_kwargs)` wrapper behavior
The decorator returns a wrapper that:
1. Applies `@activity.defn(name=name, **activity_kwargs)` and `@wraps(func)`. With `name=None`, the Temporal-registered activity name = the function's `__name__` (`persist_wave_failure`, `update_wave_status`, `update_wave_architecture_workflow_id`).
2. Computes `activity_name = name or func.__name__`; gets `activity_logger = get_logger()` (from `foundry_temporal.logging`).
3. **Pre-call:** if `enable_observability` → `activity_logger.info(f"Activity {activity_name} starting", extra={"inputs": args if log_inputs else None})`. Here `log_inputs=False`, so `inputs=None`.
4. Calls `result = await func(*args, **kwargs)`.
5. **Post-success:** if `enable_observability` → `activity_logger.info(f"Activity {activity_name} completed", extra={"outputs": result if log_outputs else None})`. Here `log_outputs=False` → `outputs=None`.
6. **On exception** (the load-bearing part): if `enable_observability` → `activity_logger.error(f"Activity {activity_name} failed: {error}", extra={"error": str(error)})`. Then if `enable_error_wrapping` (True):
   - `isinstance(error, (WorkflowError, ApplicationError))` → **re-raise as-is** (`raise`, preserves non_retryable flag).
   - `elif _is_retryable_error(error)` → `raise RetryableError(f"Retryable error in {activity_name}: {error}") from error`.
   - `else` → `raise NonRetryableError(f"Non-retryable error in {activity_name}: {error}") from error`.

### `_is_retryable_error(error)` (the classifier — `activities.py` lines 168–183)
Operates on **the lowercased string of the exception's TYPE**, NOT the message:
```python
error_str = str(type(error)).lower()
retryable_patterns = ["timeout","connection","network","temporary","unavailable","overload","busy","throttle","rate_limit"]
return any(pattern in error_str for pattern in retryable_patterns)
```
⚠️ **GOTCHA (classification of asyncpg errors):** `asyncpg.connect()` raising `ConnectionDoesNotExistError`, `CannotConnectNowError`, `TooManyConnectionsError`, etc. → their **type repr** contains `"connection"` → classified **RetryableError** → Temporal retries. A `asyncpg.exceptions.CheckViolationError` (e.g. writing a status not in `wave_status_lifecycle_chk`) has type repr `<class 'asyncpg.exceptions.CheckViolationError'>` — contains none of the patterns → classified **NonRetryableError** → Temporal will NOT retry. A bare `ValueError`/`TypeError` (not possible here post-guard; see below) → NonRetryable.

### Error classes (`foundry_temporal/errors.py`)
- `WorkflowError(ApplicationError)` — `__init__(message, non_retryable=True)`.
- `RetryableError(WorkflowError)` — `non_retryable=False`.
- `NonRetryableError(WorkflowError)` — `non_retryable=True`.

⚠️ **GOTCHA — error wrapping is mostly moot for this group at the workflow level.** All three activities catch their *own* "row not found / bad input" conditions internally and return/`return None` rather than raising (best-effort by contract). The only exceptions that escape `func` are connection failures or `CheckViolationError` from `conn.execute`. AND every call site in `WaveRationalizationWorkflow` wraps the `execute_activity` in its own `try/except Exception` that swallows and logs (see §4). So the `foundry_activity` wrapping primarily governs **whether Temporal retries within the activity's own retry budget** before the call-site swallow sees the final failure.

### Module-level DSN helper `_db_url()` (lines 33–45)
Builds the asyncpg DSN from env, **duplicated** (intentionally) so this file has no cross-activity-file imports (keeps each activity file self-contained for worker registration):
```python
host = os.environ.get("DATABASE_HOST", "localhost")
port = os.environ.get("DATABASE_PORT", "5432")
user = os.environ.get("DATABASE_USER", "olympus")
password = os.environ.get("DATABASE_PASSWORD", "olympus")
db = os.environ.get("DATABASE_NAME", "olympus")
return f"postgresql://{user}:{password}@{host}:{port}/{db}"
```
⚠️ Every activity opens a **fresh** `asyncpg.connect(_db_url())` (no pool) and closes it in a `finally`. There is **no transaction wrapper** — each `conn.execute` is an implicit autocommit single statement.

---

## Wave table schema (target columns these activities write)

Reconstructed from Alembic migrations under `db/alembic/versions/`. The `wave` table and the columns touched here:

| Column | Type | Nullable | Default | Added by migration |
|---|---|---|---|---|
| `id` | UUID | no | (PK) | (base) |
| `status` | text | no | server_default `'draft'` (migration 023; was `'planned'`) | (base), constrained by `wave_status_lifecycle_chk` |
| `created_at` | timestamptz | — | — | 006 |
| `updated_at` | timestamptz | — | — | 006 |
| `workflow_id` | text/varchar | yes | — | 007 (points at `WaveRationalizationWorkflow`; NEVER cleared by this group) |
| `failed_at` | `DateTime(timezone=True)` | yes | none (no backfill) | **043** |
| `failure_reason` | `Text` | yes | none (no backfill) | **043** |
| `architecture_workflow_id` | `String(length=255)` | yes | none (no backfill) | **054** |

### `wave_status_lifecycle_chk` CHECK constraint — authoritative allowed values
The constraint is dropped+recreated under a **stable name** `wave_status_lifecycle_chk` across migrations. The **final** allowed set after the latest constraint migration (**049**) is the **10 values**:
```
'draft', 'ready', 'in_progress',
'awaiting-architecture-dispatch', 'architecture-in-flight', 'data-in-flight',
'completed', 'cancelled', 'failed', 'stuck-awaiting-recovery'
```
Constraint evolution:
- **023** introduced: `draft, ready, in_progress, completed, cancelled` (also flipped `status` server_default `planned`→`draft`).
- **043** (docstring says task #104; `revision="043"`, `down_revision="042"`) added `'failed'` (→ 6 values) AND added nullable columns `failed_at` (timestamptz), `failure_reason` (Text). No backfill.
- **045** (`down_revision="044"`) added the three fan-out transients `awaiting-architecture-dispatch`, `architecture-in-flight`, `data-in-flight` (→ 9 values).
- **049** (⚠️ **file docstring header erroneously says `Revision ID: 048 / Revises: 047` — copy-paste artifact**; the actual module code sets `revision="049"`, `down_revision="048"`) added `'stuck-awaiting-recovery'` (→ 10 values, Task #88).

⚠️ **GOTCHA — statuses the workflow sets that are NOT in the CHECK constraint.** `WaveRationalizationWorkflow` calls `_update_wave_status_safe("architecture-dispatched")` (line ~4600) and references `architecture-complete` / `awaiting-architecture-coordinator` (migration 054 docstring). **None of these three are in the 049 allowed set.** Because `update_wave_status` does NOT re-validate the string (by design — see its docstring), Postgres rejects the write with `asyncpg.exceptions.CheckViolationError` from `conn.execute`. Inside the activity that exception propagates (it is NOT one of the `(ValueError, TypeError)` it guards, and there is no try/except around `conn.execute` itself other than the `finally: conn.close()`). The `foundry_activity` wrapper classifies it **NonRetryable** (type repr has no retry pattern) and re-raises `NonRetryableError`; Temporal does not retry; the **call-site** `_update_wave_status_safe` `except Exception` swallows it and logs `"update_wave_status failed"`. Net behavior: the status flip silently no-ops and the wave keeps its prior status. A faithful rebuild MUST preserve this "no re-validation, DB is the guardrail, caller swallows" chain — do NOT add client-side status validation. (A rebuild that DOES validate would change observable behavior by raising/short-circuiting earlier.)

---

## 1. `persist_wave_failure(input: PersistWaveFailureInput) -> None`

**Lines 48–122.** Decorator: `@foundry_activity(config=ActivityConfig(enable_observability=True))`.

**Purpose:** Transition a wave to `status='failed'` and record failure metadata. Called from `WaveRationalizationWorkflow`'s outer `try/except` when it unwinds on a non-retryable error.

### Input: `PersistWaveFailureInput` (`types.py` lines 1562–1581) — dataclass
| Field | Type | Default |
|---|---|---|
| `wave_id` | `str` | (required) |
| `reason` | `str` | `""` |
| `workflow_id` | `str` | `""` |

`reason` is the exception's `str(exc)` already truncated to 500 chars **by the caller** (`wave_rationalization.py:1278` → `reason = str(exc)[:500]`). `workflow_id` carried for audit and **deliberately not written/cleared** (operators need the breadcrumb back into Temporal).

### Output
`None`. Raises **no exception** on a missing wave row (best-effort by contract).

### Control flow (reproduce exactly)
1. **Empty guard:** `if not input.wave_id:` → `logger.warning("persist_wave_failure called with empty wave_id — skipping")` and `return` (no DB touch).
2. **UUID parse guard:**
   ```python
   try: wave_uuid = uuid.UUID(input.wave_id)
   except (ValueError, TypeError):
       logger.warning("persist_wave_failure called with non-UUID wave_id — skipping", extra={"wave_id": input.wave_id})
       return
   ```
3. `now = datetime.now(timezone.utc)` — single timestamp reused for both `failed_at` and `updated_at`.
4. **Defensive re-truncate** (belt-and-braces; caller already truncates): `reason = (input.reason or "")[:500]`.
5. Open `conn = await asyncpg.connect(_db_url())`; in `try/finally`(close) run **one** UPDATE.
6. **No row-count check, no return-value branch.** Logs `logger.info("wave.persist_failure", extra={"wave_id", "workflow_id", "reason_chars": len(reason)})` unconditionally after the UPDATE (even if 0 rows matched).

### Exact SQL (parameterized, asyncpg positional `$N`)
```sql
UPDATE wave
SET status = 'failed',
    failed_at = $2,
    failure_reason = $3,
    updated_at = $2
WHERE id = $1
```
Params bound in order: `$1 = wave_uuid` (UUID), `$2 = now` (datetime, used for BOTH `failed_at` and `updated_at`), `$3 = reason` (truncated str).

### Artifact-field → table.column mapping
| Input field / derived value | `wave` column | Write rule |
|---|---|---|
| literal `'failed'` | `status` | always set |
| `now` (`datetime.now(timezone.utc)`) | `failed_at` | always set (overwrites any prior) |
| `now` (same value) | `updated_at` | always set |
| `reason = (input.reason or "")[:500]` | `failure_reason` | always set (overwrites; empty string written if reason empty) |
| `input.wave_id`→`uuid.UUID` | (`WHERE id = $1`) | row selector only |
| `input.workflow_id` | — (NOT written) | **deliberately never persisted/cleared** |

### Idempotency / retries
- **No `WHERE status != 'failed'` guard** — calling twice with the same failure is effectively idempotent: the 2nd call overwrites `failed_at` with a slightly later timestamp and rewrites the same reason. Chosen idempotent-on-happy-path over racy-on-retry-path given Temporal at-least-once semantics.
- Missing wave row → `UPDATE … WHERE id=$1` matches 0 rows, no error, activity returns None normally.
- **Retries:** governed by the caller's `retry_policy=RETRY_POLICIES["transient"]` (= `HTTP_RETRY_POLICY`: `initial_interval=1s, maximum_interval=15s, maximum_attempts=3, backoff_coefficient=2.0`) + `start_to_close_timeout=timedelta(seconds=30)`. A transient asyncpg connection error → RetryableError (per classifier) → retried up to 3 attempts; on final failure the caller's outer `except Exception` swallows it (see §4).

---

## 2. `update_wave_status(input: UpdateWaveStatusInput) -> UpdateWaveStatusResult`

**Lines 130–233.** Decorator: `@foundry_activity(config=ActivityConfig(enable_observability=True))`.

**Purpose:** Transition `wave.status` to `input.new_status`. Used by the Architecture+Data fan-out to walk `awaiting-architecture-dispatch → architecture-in-flight → data-in-flight → completed`, and (via classifier) `failed` / `stuck-awaiting-recovery`. Best-effort: missing/stale row → returns `updated=False` rather than raising.

### Input: `UpdateWaveStatusInput` (`types.py` lines 1922–1940) — dataclass
| Field | Type | Default |
|---|---|---|
| `wave_id` | `str` | (required) |
| `new_status` | `str` | (required) |
| `reason` | `str` | `""` |

### Output: `UpdateWaveStatusResult` (`types.py` lines 1943–1954) — dataclass
| Field | Type | Default |
|---|---|---|
| `wave_id` | `str` | (echoed) |
| `new_status` | `str` | (echoed) |
| `updated` | `bool` | `False` |

`updated=True` iff exactly one wave row was mutated. Workflow tolerates `False`.

### The status-normalization logic — there is INTENTIONALLY NONE
⚠️ This activity does **NOT** re-validate or normalize `input.new_status`. The CHECK constraint on `wave.status` (final set from migration 049) is the **authoritative guardrail**. Rationale (docstring lines 142–146): future migrations adding statuses need no code change here. So "status normalization" for this group = **pass the raw string straight to the UPDATE; let the DB CHECK accept or reject it.** See the GOTCHA above re: `architecture-dispatched` not being a valid status → silent swallow.

### Control flow (reproduce exactly)
1. **Empty guard:** `if not input.wave_id:` → `logger.warning("update_wave_status: empty wave_id — skipping")` and **return** `UpdateWaveStatusResult(wave_id="", new_status=input.new_status, updated=False)`. ⚠️ Note: returns `wave_id=""` (empty), NOT the input value, in this branch only.
2. **UUID parse guard:**
   ```python
   try: wave_uuid = uuid.UUID(input.wave_id)
   except (ValueError, TypeError):
       logger.warning("update_wave_status: non-UUID wave_id — skipping", extra={"wave_id": input.wave_id})
       return UpdateWaveStatusResult(wave_id=input.wave_id, new_status=input.new_status, updated=False)
   ```
   ⚠️ Here `wave_id=input.wave_id` (the original) IS echoed — asymmetric with the empty-guard branch.
3. **Conditional-reason decision (the key conditional write):**
   ```python
   _FAILURE_STATUSES = {"failed", "stuck-awaiting-recovery"}
   persist_reason = bool(input.reason) and input.new_status in _FAILURE_STATUSES
   reason_truncated = (input.reason or "")[:500]
   now = datetime.now(timezone.utc)
   ```
   ⚠️ `reason` is persisted to `wave.failure_reason` **only** when BOTH: `input.reason` is truthy AND `input.new_status` ∈ {`failed`, `stuck-awaiting-recovery`}. For every other transition (e.g. `in-progress → awaiting-architecture-dispatch`) the `failure_reason` column is **left untouched** so a prior failure narrative is preserved across clean-up attempts (until `/reset` clears it). (Task #88.)
4. Open `conn`; in `try/finally`(close), choose ONE of two UPDATEs based on `persist_reason`.
5. **Row-count parse:** `asyncpg` `conn.execute` returns a command tag string like `"UPDATE 1"`.
   ```python
   try: updated = int(result.split()[-1]) > 0
   except (AttributeError, ValueError, IndexError): updated = False
   ```
   ⚠️ Robust against malformed tags → `updated=False` on any parse failure.
6. `if not updated:` → `logger.warning("update_wave_status: no row updated", extra={"wave_id", "new_status"})`.
7. Always `logger.info("wave.update_status", extra={"wave_id", "new_status", "reason": input.reason})`.
8. `return UpdateWaveStatusResult(wave_id=input.wave_id, new_status=input.new_status, updated=updated)`.

### Exact SQL — branch A (`persist_reason == True`)
```sql
UPDATE wave
SET status = $2,
    updated_at = $3,
    failure_reason = COALESCE(NULLIF($4, ''), failure_reason),
    failed_at = COALESCE(failed_at, $3)
WHERE id = $1
```
Params: `$1 = wave_uuid`, `$2 = input.new_status`, `$3 = now`, `$4 = reason_truncated`.
⚠️ **`failure_reason` semantics:** `NULLIF($4,'')` → if truncated reason is empty string, treat as NULL → `COALESCE(NULL, failure_reason)` = keep existing. Non-empty reason overwrites.
⚠️ **`failed_at` semantics:** `COALESCE(failed_at, $3)` → write `now` **only if `failed_at` is currently NULL** (preserve the FIRST failure timestamp; do not bump it on subsequent failure transitions).

### Exact SQL — branch B (`persist_reason == False`)
```sql
UPDATE wave
SET status = $2,
    updated_at = $3
WHERE id = $1
```
Params: `$1 = wave_uuid`, `$2 = input.new_status`, `$3 = now`. **`failure_reason` and `failed_at` are NOT in the SET list** — untouched.

### Artifact-field → table.column mapping
| Input / derived | `wave` column | Branch A (`persist_reason`) | Branch B (else) |
|---|---|---|---|
| `input.new_status` | `status` | set ($2) | set ($2) |
| `now` | `updated_at` | set ($3) | set ($3) |
| `reason_truncated` via `COALESCE(NULLIF($4,''), failure_reason)` | `failure_reason` | **conditional**: overwrite iff non-empty, else keep | **NOT WRITTEN** |
| `now` via `COALESCE(failed_at, $3)` | `failed_at` | set iff currently NULL | **NOT WRITTEN** |
| `input.wave_id`→UUID | (`WHERE id=$1`) | selector | selector |

Branch A is entered only when `bool(input.reason) and input.new_status in {"failed","stuck-awaiting-recovery"}`.

### Idempotency / retries
- No status precondition in `WHERE` — re-running the same transition rewrites `status`+`updated_at` (idempotent for the value; `updated_at` bumps). In branch A, `failed_at` is sticky (COALESCE) and `failure_reason` only changes on non-empty new reason.
- Caller options identical to §1: `start_to_close_timeout=30s`, `retry_policy=RETRY_POLICIES["transient"]` (3 attempts, exp backoff 1→15s, coeff 2.0). Connection errors → RetryableError → retried; CheckViolation (bad status) → NonRetryable → not retried → swallowed by caller.

---

## 3. `update_wave_architecture_workflow_id(input: UpdateWaveArchitectureWorkflowIdInput) -> None`

**Lines 236–310.** Decorator: `@foundry_activity(config=ActivityConfig(enable_observability=True))`.

**Purpose:** Persist the `WaveArchitectureWorkflow` Temporal handle into `wave.architecture_workflow_id` (column added by migration 054). Called by `WaveRationalizationWorkflow` immediately after spawning the architecture coordinator child. API+UI use this column to route signals (`pre_dispatch_confirmed`, `cancel_all_children`) to the architecture coordinator instead of the rationalization workflow once the wave has handed off. Best-effort: missing row → warning + return, no raise.

### Input: `UpdateWaveArchitectureWorkflowIdInput` (`types.py` lines 2158–2170) — dataclass
| Field | Type | Default |
|---|---|---|
| `wave_id` | `str` | (required) |
| `architecture_workflow_id` | `str` | (required) |

### Output
`None`.

### Control flow (reproduce exactly)
1. **Empty guard (BOTH fields):** `if not input.wave_id or not input.architecture_workflow_id:` → `logger.warning("update_wave_architecture_workflow_id: empty wave_id or workflow_id — skipping", extra={"wave_id", "architecture_workflow_id"})` and `return`.
2. **UUID parse guard:**
   ```python
   try: wave_uuid = uuid.UUID(input.wave_id)
   except (ValueError, TypeError):
       logger.warning("update_wave_architecture_workflow_id: non-UUID wave_id — skipping", extra={"wave_id": input.wave_id})
       return
   ```
3. `now = datetime.now(timezone.utc)`.
4. Open `conn`; in `try/finally`(close) run the UPDATE.
5. **Row-count parse** (identical idiom to §2):
   ```python
   try: updated = int(result.split()[-1]) > 0
   except (AttributeError, ValueError, IndexError): updated = False
   ```
6. ⚠️ **Early-return-on-miss + `return`:** `if not updated:` → `logger.warning("update_wave_architecture_workflow_id: no row updated", extra={"wave_id","architecture_workflow_id"})` **and `return`** — so on a 0-row update the success `logger.info` is **NOT** emitted. (Differs from `persist_wave_failure`, which logs success unconditionally, and from `update_wave_status`, which logs `wave.update_status` even when not updated.)
7. On success: `logger.info("wave.update_architecture_workflow_id", extra={"wave_id","architecture_workflow_id"})`.

### Exact SQL
```sql
UPDATE wave
SET architecture_workflow_id = $2,
    updated_at = $3
WHERE id = $1
```
Params: `$1 = wave_uuid`, `$2 = input.architecture_workflow_id`, `$3 = now`.

### Artifact-field → table.column mapping
| Input / derived | `wave` column | Write rule |
|---|---|---|
| `input.architecture_workflow_id` | `architecture_workflow_id` | always set (when guards pass) |
| `now` | `updated_at` | always set |
| `input.wave_id`→UUID | (`WHERE id=$1`) | selector |

**Does NOT touch:** `status`, `failed_at`, `failure_reason`, `workflow_id` (the rationalization handle stays put — two-column routing design, migration 054).

### Idempotency / retries
- Idempotent: rewriting the same `architecture_workflow_id` is harmless (only `updated_at` bumps).
- Caller (`wave_rationalization.py:3219-3229`): `start_to_close_timeout=30s`, `retry_policy=RETRY_POLICIES["transient"]`, AND a unique `activity_id=f"persist-arch-coordinator-id-{input.wave_id}"` (dedup key — re-dispatch with the same wave_id reuses the activity id). Wrapped in caller `try/except Exception` that logs `"update_wave_architecture_workflow_id failed"` and does NOT fail Rationalization (the coordinator is already running).

---

## 4. Caller context (`WaveRationalizationWorkflow`, `wave_rationalization.py`) — load-bearing for behavioral parity

All three activities are imported under `with workflow.unsafe.imports_passed_through():` (lines 81–85) along with `from olympus_workflows.retry_policies import RETRY_POLICIES`. `RETRY_POLICIES["transient"]` = `HTTP_RETRY_POLICY` = `RetryPolicy(initial_interval=1s, maximum_interval=15s, maximum_attempts=3, backoff_coefficient=2.0)`.

### 4a. `persist_wave_failure` + recoverable two-step (outer `except`, lines ~1277–1344)
On workflow unwind:
```python
classification = classify_failure(exc)        # "recoverable" | (terminal/else)
reason = str(exc)[:500]                        # <-- the 500-char truncation lives HERE
try:
    if classification == "recoverable":
        # STEP 1: persist_wave_failure writes status='failed', failed_at, failure_reason
        await workflow.execute_activity(persist_wave_failure,
            PersistWaveFailureInput(wave_id=input.wave_id, reason=reason,
                                    workflow_id=workflow.info().workflow_id),
            start_to_close_timeout=timedelta(seconds=30), retry_policy=RETRY_POLICIES["transient"])
        # STEP 2: flip status to the recoverable value (failure_reason+failed_at already landed by step 1)
        await workflow.execute_activity(update_wave_status,
            UpdateWaveStatusInput(wave_id=input.wave_id, new_status="stuck-awaiting-recovery", reason=reason),
            start_to_close_timeout=timedelta(seconds=30), retry_policy=RETRY_POLICIES["transient"])
    else:  # terminal
        await workflow.execute_activity(persist_wave_failure,
            PersistWaveFailureInput(wave_id=input.wave_id, reason=reason,
                                    workflow_id=workflow.info().workflow_id),
            start_to_close_timeout=timedelta(seconds=30), retry_policy=RETRY_POLICIES["transient"])
except Exception:
    workflow.logger.warning("persist_wave_failure swallowed secondary exception",
        extra={"wave_id": input.wave_id, "classification": classification})
raise   # ALWAYS re-raise the ORIGINAL exc so Temporal marks the run FAILED
```
⚠️ **Ordering gotcha (recoverable path):** `persist_wave_failure` is **always** called first (even for recoverable failures) so that `failure_reason` + `failed_at` get written by branch-A logic of `persist_wave_failure`. It transiently leaves `status='failed'`, then STEP 2's `update_wave_status("stuck-awaiting-recovery", reason)` flips status to the recoverable value. Because `update_wave_status` branch A uses `failed_at = COALESCE(failed_at, $3)`, the `failed_at` written by step 1 is **preserved** (not overwritten). And `failure_reason = COALESCE(NULLIF($4,''),...)` re-writes the same reason. A rebuild that skips step 1 for the recoverable path would leave `failure_reason`/`failed_at` NULL (because `update_wave_status` would still go through branch A for `stuck-awaiting-recovery`, but `failed_at` would be set then too — however the comment's intent is that step 1 establishes the metadata). **Reproduce the two-call sequence as written.**
⚠️ The persist failure is swallowed; the original `exc` is **always** re-raised so Temporal history shows FAILED regardless of projection success.

### 4b. `_update_wave_status_safe(new_status, reason="")` helper (lines 4436–4463)
The standard best-effort wrapper used for all non-failure transitions:
```python
if not self._wave_id: return
try:
    await workflow.execute_activity(update_wave_status,
        UpdateWaveStatusInput(wave_id=self._wave_id, new_status=new_status, reason=reason),
        start_to_close_timeout=timedelta(seconds=30), retry_policy=RETRY_POLICIES["transient"])
except Exception as exc:  # noqa: BLE001
    workflow.logger.warning("update_wave_status failed",
        extra={"wave_id": self._wave_id, "new_status": new_status, "error": repr(exc)})
```
Observed call values include: `"architecture-in-flight"`, `"completed"`, and ⚠️ `"architecture-dispatched"` (NOT a valid CHECK value → silent CheckViolation swallow, see GOTCHA). Most calls pass `reason=""` → `update_wave_status` takes branch B (no `failure_reason`/`failed_at` write).

### 4c. `update_wave_architecture_workflow_id` call (lines 3219–3241)
Called right after the architecture coordinator child workflow is started, with `activity_id=f"persist-arch-coordinator-id-{input.wave_id}"`; wrapped in best-effort `try/except` logging `"update_wave_architecture_workflow_id failed"` and continuing (does not fail Rationalization).

---

## 5. Cross-activity invariants & summary GOTCHAs

1. **`now` reuse:** each activity computes a single `datetime.now(timezone.utc)` and binds it to multiple columns in one statement (`persist_wave_failure`: `failed_at`+`updated_at`; others: `updated_at` and possibly `failed_at`). Reproduce as one timestamp, not multiple `now()` calls.
2. **No SQL transaction / no pool:** fresh `asyncpg.connect` per call, single autocommit statement, `finally: conn.close()`. No `BEGIN`/`COMMIT`.
3. **Two-branch row-count idiom** (`update_wave_status`, `update_wave_architecture_workflow_id`): parse asyncpg command tag `"UPDATE N"` via `int(result.split()[-1]) > 0`, defaulting `updated=False` on `(AttributeError, ValueError, IndexError)`. `persist_wave_failure` does NOT do this (returns None, ignores row count).
4. **Logging-on-miss asymmetry:** `persist_wave_failure` logs success unconditionally; `update_wave_status` logs `wave.update_status` unconditionally (after a separate `no row updated` warning); `update_wave_architecture_workflow_id` **returns early on miss and skips its success log**.
5. **`wave_id` echo asymmetry in `update_wave_status`:** empty-guard returns `wave_id=""`; non-UUID-guard returns `wave_id=input.wave_id`.
6. **`failure_reason` is written by THREE distinct rules:** `persist_wave_failure` always overwrites (even empty); `update_wave_status` branch A overwrites only-if-nonempty-else-keep; branch B never touches. Never normalize/concat — overwrite-or-keep only.
7. **`workflow_id` is never written by any of these three** (it's set elsewhere at wave creation; this group only ever reads `input.workflow_id` for logs in `persist_wave_failure`).
8. **No status validation anywhere** — the DB CHECK constraint `wave_status_lifecycle_chk` is the sole guardrail; invalid statuses raise CheckViolation → classified NonRetryable → swallowed at the call site.
