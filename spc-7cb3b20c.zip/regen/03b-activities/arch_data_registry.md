# Activity Group: `arch_data_registry` — Arch↔Data Signal Registry

**Source file:** `temporal/olympus_workflows/activities/arch_data_registry.py` (215 lines, authoritative).
**Module-under-spec:** `olympus_workflows.activities.arch_data_registry`
**Activities reproduced:** `publish_arch_data_signal`, `consume_arch_data_signal` (2 total).
**Backing table:** `arch_data_signal_registry` — created by migration `db/alembic/versions/046_create_arch_data_signal_registry.py` (revision `046`, down_revision `045`, Create Date 2026-05-08). DDL reproduced in §4.

This group implements the durable, DB-backed handshake that replaced the pre-2026-05-08 Temporal peer-signal mechanism between `ArchitectureWorkflow` and `DataWorkflow`. There are NO agent-dispatch activities and NO Git activities in this group. Both activities are pure single-connection PostgreSQL operations against one table. The "projection" here is trivial in the sense that the publisher writes a primitive-string `payload` blob into a JSONB column verbatim — but the **registry semantics** (upsert reset-on-republish, atomic claim-or-skip via `UPDATE ... RETURNING` with a COALESCE-preserving idempotency branch) are the load-bearing, must-reproduce-exactly behavior. This file over-specifies all of it.

---

## 0. PREAMBLE — `@foundry_activity` decorator semantics (applies to BOTH activities)

Both activities are decorated with:

```python
@foundry_activity(config=ActivityConfig(enable_observability=True))
```

imported as `from foundry_temporal.activities import ActivityConfig, foundry_activity`
(source of the decorator: `foundry_temporal/activities.py`; error classes: `foundry_temporal/errors.py`).

`foundry_activity` is **NOT** a plain `@activity.defn`. A rebuild that uses bare `@activity.defn` loses error-wrapping and retryability classification and is WRONG. Reproduce the following wrapper behavior exactly:

`foundry_activity(config=None, name=None, **activity_kwargs)` returns a decorator that:

1. Resolves `activity_config = config or ActivityConfig()`. Here `config=ActivityConfig(enable_observability=True)` for both; all other `ActivityConfig` fields take their dataclass defaults: `retry_policy=None`, all four timeouts `None`, `heartbeat_timeout=None`, `enable_observability=True`, **`enable_error_wrapping=True`** (default), `log_inputs=False`, `log_outputs=False`.
   - ⚠️ Because `log_inputs`/`log_outputs` default `False`, the observability log lines carry `extra={"inputs": None}` / `extra={"outputs": None}` — the activity's own `logger.info(...)` calls inside the body (see §1.5, §2.6) are what actually emit the structured signal fields, NOT the wrapper.
2. Wraps the function with `@activity.defn(name=name, **activity_kwargs)` (here `name=None` ⇒ Temporal activity name == Python function name: `"publish_arch_data_signal"` / `"consume_arch_data_signal"`). The wrapper is `@wraps(func)` so `__name__` is preserved.
3. On invoke, computes `activity_name = name or func.__name__`, gets `activity_logger = get_logger()` (from `foundry_temporal.logging`).
4. If `enable_observability` (true here): logs `f"Activity {activity_name} starting"` with `extra={"inputs": args if log_inputs else None}` → `extra={"inputs": None}`.
5. Runs `result = await func(*args, **kwargs)`.
6. On success + observability: logs `f"Activity {activity_name} completed"` with `extra={"outputs": result if log_outputs else None}` → `extra={"outputs": None}`. Returns `result`.
7. On **any** `Exception error`:
   - If observability: logs `f"Activity {activity_name} failed: {error}"` with `extra={"error": str(error)}`.
   - If `enable_error_wrapping` (true here): classify and re-raise:
     - `if isinstance(error, (WorkflowError, ApplicationError)): raise` (re-raise unchanged — preserves an already-typed error and its `non_retryable` flag).
     - `elif _is_retryable_error(error): raise RetryableError(f"Retryable error in {activity_name}: {error}") from error`
     - `else: raise NonRetryableError(f"Non-retryable error in {activity_name}: {error}") from error`
   - Else (`enable_error_wrapping` false — not this group): bare `raise`.

**`_is_retryable_error(error)`** (module function in `foundry_temporal/activities.py`, lines 168–183 — distinct from the richer `errors.is_retryable_error`): lowercases `str(type(error))` and returns True iff it contains ANY of: `"timeout"`, `"connection"`, `"network"`, `"temporary"`, `"unavailable"`, `"overload"`, `"busy"`, `"throttle"`, `"rate_limit"`. ⚠️ This matches on the **type's repr string**, not the message. Mapping for THIS group:

| Raised inside the activity body | `str(type(e))` contains a pattern? | Wrapped as |
|---|---|---|
| `ValueError` from `_require_known_signal_type` | no | **`NonRetryableError`** (correct — a typo'd signal_type must not retry) |
| `ValueError` from `uuid.UUID(...)` (malformed wave_id / target_app_id / workflow_id) | no | **`NonRetryableError`** |
| `asyncpg.exceptions.ConnectionDoesNotExistError`, `...CannotConnectNowError`, `ConnectionError`, connect failures | class name contains `"connection"` | **`RetryableError`** |
| `asyncio.TimeoutError` / asyncpg `*TimeoutError` | class name contains `"timeout"` | **`RetryableError`** |
| asyncpg `TooManyConnectionsError` | name has none of the patterns | **`NonRetryableError`** ⚠️ (would NOT auto-retry despite being transient — accept as-is; rebuild MUST replicate, do not "improve") |
| asyncpg `PostgresError` (generic SQL error, e.g. table missing) | no | **`NonRetryableError`** |
| `asyncpg.exceptions.UniqueViolationError` | no | **`NonRetryableError`** (cannot occur on publish — see §1 GOTCHA-U; theoretically possible only via a logic bug) |

**Error class definitions** (`foundry_temporal/errors.py`):
- `class WorkflowError(ApplicationError)`: `__init__(self, message, non_retryable=True)` → `super().__init__(message, non_retryable=non_retryable)`.
- `class RetryableError(WorkflowError)`: `__init__(message)` → `super().__init__(message, non_retryable=False)`. ⇒ Temporal **will** retry per the activity's RetryPolicy.
- `class NonRetryableError(WorkflowError)`: `__init__(message)` → `super().__init__(message, non_retryable=True)`. ⇒ Temporal will **not** retry; activity fails immediately.

⚠️ **No retry policy / no timeout is set in the decorator config** for either activity. Retry/timeout behavior is dictated entirely by the **caller's** `workflow.execute_activity(...)` arguments (see §3): both callers pass `start_to_close_timeout=timedelta(seconds=30)` and `retry_policy=RETRY_POLICIES["transient"]`. The activity functions themselves declare none.

---

## 1. `publish_arch_data_signal`

### 1.1 Signature
```python
@foundry_activity(config=ActivityConfig(enable_observability=True))
async def publish_arch_data_signal(input: PublishArchDataSignalInput) -> None
```
Returns `None`. (Source lines 82–134.)

### 1.2 Input type — `PublishArchDataSignalInput` (`types.py` 2696–2718)
`@dataclass`, ALL fields required (no defaults), all `str`:

| Field | Type | Meaning |
|---|---|---|
| `signal_type` | `str` | Must be `"target_provisioned"` or `"data_ready_for_target"`. Validated (§1.3). |
| `wave_id` | `str` | UUID **string**. Parsed to `uuid.UUID`. |
| `target_app_id` | `str` | UUID **string**. Parsed to `uuid.UUID`. |
| `payload_json` | `str` | A JSON-serialized snapshot of `TargetProvisionedSignal` or `DataReadyForTargetSignal`. Written verbatim into the `payload` JSONB column. The activity does **not** parse/validate it. May be `""`/`None` only for logging guards (`len(input.payload_json or "")`), but in practice always a non-empty JSON object string from the caller's encoder (§5). |

### 1.3 Control flow (exact order — reproduce verbatim)
1. `_require_known_signal_type(input.signal_type)` — raises `ValueError(f"Unknown arch-data signal_type {signal_type!r}; expected one of {sorted(_ALLOWED_SIGNAL_TYPES)}")` if `signal_type not in _ALLOWED_SIGNAL_TYPES`. `_ALLOWED_SIGNAL_TYPES = frozenset({SIGNAL_TARGET_PROVISIONED, SIGNAL_DATA_READY_FOR_TARGET}) = frozenset({"target_provisioned", "data_ready_for_target"})`. `sorted(...)` ⇒ `['data_ready_for_target', 'target_provisioned']` in the message. ⚠️ This guard runs BEFORE any DB connection — a typo'd signal_type never opens a connection. Rationale (source docstring): the DB has **no** CHECK constraint on `signal_type`, so a misspelled type would silently stash a row no consumer can ever find; fail loud here.
2. `wave_uuid = uuid.UUID(input.wave_id)` — raises `ValueError` on malformed UUID. (Forces canonical UUID; protects the typed `uuid`/`UUID(as_uuid=True)` columns.)
3. `target_uuid = uuid.UUID(input.target_app_id)` — same.
4. `conn = await asyncpg.connect(_db_url())` — opens a fresh single connection (no pool). `_db_url()` builds `f"postgresql://{user}:{password}@{host}:{port}/{db}"` from env (§6).
5. `try:` run the upsert SQL (§1.4); `finally: await conn.close()` — connection ALWAYS closed, even on error.
6. After the `finally`, emit observability log (§1.5).
7. Return `None` (implicit).

⚠️ **Ordering:** the `logger.info("arch_data_registry.publish", ...)` is OUTSIDE/AFTER the `try/finally`, so it only fires on the SUCCESS path (if the SQL raised, control left the function via the exception before reaching the log). The `finally` only closes the connection; it does not swallow.

### 1.4 EXACT SQL — single statement, `conn.execute(...)`
```sql
INSERT INTO arch_data_signal_registry
    (wave_id, target_app_id, signal_type, payload)
VALUES ($1, $2, $3, $4::jsonb)
ON CONFLICT (wave_id, target_app_id, signal_type)
DO UPDATE SET
    payload = EXCLUDED.payload,
    consumed_at = NULL,
    consumed_by_workflow_id = NULL,
    created_at = now()
```
Positional params (asyncpg, `$1..$4`):
- `$1 = wave_uuid` (`uuid.UUID`) → `wave_id`
- `$2 = target_uuid` (`uuid.UUID`) → `target_app_id`
- `$3 = input.signal_type` (`str`) → `signal_type`
- `$4 = input.payload_json` (`str`) → cast `$4::jsonb` → `payload`

⚠️ **`$4::jsonb` cast is mandatory.** The param is bound as a Python `str`; without the explicit `::jsonb` cast asyncpg/PG would reject inserting text into a JSONB column. Reproduce the cast exactly.

⚠️ **ON CONFLICT target is the named tuple `(wave_id, target_app_id, signal_type)`**, which is backed by unique constraint `arch_data_signal_registry_scope_uk` (migration 046). The conflict clause references the **columns**, not the constraint name; PG resolves it to that unique constraint.

### 1.5 Artifact-field → table.column mapping (publish / upsert)

`arch_data_signal_registry` columns and exactly what each upsert touches:

| table.column | INSERT (new row) value | ON CONFLICT DO UPDATE value | Condition / notes |
|---|---|---|---|
| `id` (UUID PK) | DB `server_default gen_random_uuid()` | **untouched** (not in SET list) | Generated only on insert; the existing id survives a republish. |
| `wave_id` (UUID, NOT NULL) | `$1` = `uuid.UUID(input.wave_id)` | **untouched** (it's the conflict key) | Always set on insert. |
| `target_app_id` (UUID, NOT NULL) | `$2` = `uuid.UUID(input.target_app_id)` | **untouched** (conflict key) | Always set on insert. |
| `signal_type` (TEXT, NOT NULL) | `$3` = `input.signal_type` | **untouched** (conflict key) | Always set on insert. |
| `payload` (JSONB, NOT NULL) | `$4::jsonb` = `input.payload_json` | `EXCLUDED.payload` (i.e. the new `$4::jsonb`) | **Always overwritten on republish** — writer-is-source-of-truth. |
| `created_at` (TIMESTAMPTZ, NOT NULL) | DB `server_default now()` | `now()` (re-set on every republish) | ⚠️ On conflict, `created_at` is RESET to current time. So "created_at" effectively means "last published at". This is intentional (republish = fresh payload). |
| `consumed_at` (TIMESTAMPTZ, NULL) | DB default NULL (column not in INSERT list) | `NULL` (explicitly reset) | ⚠️ Republish RESETS consumption so the peer re-consumes the fresher payload, even if the prior payload was already claimed by a (possibly dead) workflow run. |
| `consumed_by_workflow_id` (TEXT, NULL) | DB default NULL (not in INSERT list) | `NULL` (explicitly reset) | Same rationale — clears the claimer. |

**Behavioral summary of upsert:** On first publish for a scope key, inserts a row with a fresh `id`, fresh `created_at=now()`, NULL consume fields, and `payload=input.payload_json`. On any subsequent publish for the SAME `(wave_id, target_app_id, signal_type)`: overwrites `payload`, resets `created_at=now()`, and **nulls** both `consumed_at` and `consumed_by_workflow_id` — re-arming the row for re-consumption. `id`, `wave_id`, `target_app_id`, `signal_type` are not modified.

⚠️ **GOTCHA-U (UniqueViolation impossible):** Because the upsert uses `ON CONFLICT (...) DO UPDATE`, a duplicate key never raises `UniqueViolationError`. There is no INSERT-only path. The `consumed_at IS NULL` partial index (`idx_arch_data_registry_lookup`) is NOT unique and never affects the upsert.

### 1.6 Observability log (success only)
```python
logger.info(
    "arch_data_registry.publish",
    extra={
        "signal_type": input.signal_type,
        "wave_id": input.wave_id,
        "target_app_id": input.target_app_id,
        "payload_chars": len(input.payload_json or ""),
    },
)
```
`logger` is the module logger `logging.getLogger(__name__)` (where `__name__ == "olympus_workflows.activities.arch_data_registry"`). `payload_chars` is `len(input.payload_json or "")` — guards a `None` payload to 0. Reproduce the event name `"arch_data_registry.publish"` and the four `extra` keys exactly (used by metric labels / log greps).

### 1.7 Error handling / retries / idempotency (publish)
- **Idempotency:** Naturally idempotent at the scope-key level via upsert — re-running publish with the same input produces the same final row state (payload overwritten identically, consume fields nulled, `created_at` bumped). ⚠️ Not bit-identical across calls because `created_at` advances each time, but the consumer never reads `created_at`, so this is observationally idempotent for the handshake.
- **Retryable:** Any connection/timeout error inside `connect`/`execute` → wrapped `RetryableError` by the decorator (see preamble table) → Temporal retries per caller's `RETRY_POLICIES["transient"]`. Because the op is an upsert, a retry that lands after a partial first attempt is safe.
- **Non-retryable:** `ValueError` from `_require_known_signal_type` or `uuid.UUID(...)` → `NonRetryableError`. These are deterministic input faults; retrying cannot help.
- **No transaction block / no explicit `BEGIN`:** the single `execute` runs in asyncpg's implicit autocommit. One statement = atomic. No `async with conn.transaction()`.
- **Connection lifecycle:** `await conn.close()` in `finally` guarantees the connection is released on every path. ⚠️ One connection per activity invocation — no pooling/caching across calls.

---

## 2. `consume_arch_data_signal`

### 2.1 Signature
```python
@foundry_activity(config=ActivityConfig(enable_observability=True))
async def consume_arch_data_signal(input: ConsumeArchDataSignalInput) -> ConsumeArchDataSignalResult
```
(Source lines 137–214.)

### 2.2 Input type — `ConsumeArchDataSignalInput` (`types.py` 2721–2734)
`@dataclass`, ALL fields required (no defaults), all `str`:

| Field | Type | Meaning |
|---|---|---|
| `signal_type` | `str` | Must be `"target_provisioned"` or `"data_ready_for_target"`. Validated. |
| `wave_id` | `str` | UUID string → `uuid.UUID`. |
| `target_app_id` | `str` | UUID string → `uuid.UUID`. |
| `workflow_id` | `str` | The CONSUMING workflow's Temporal workflow id (caller passes `workflow.info().workflow_id`). Becomes the claimer (`consumed_by_workflow_id`) and the idempotency key. Bound as **text** (`$4`), NOT a UUID. |

### 2.3 Output type — `ConsumeArchDataSignalResult` (`types.py` 2737–2747)
`@dataclass`:

| Field | Type | Default | Meaning |
|---|---|---|---|
| `found` | `bool` | `False` | True iff a claimable/owned row exists and was returned. |
| `payload_json` | `str` | `""` | The row's `payload` rendered as text (`payload::text`); `""` when `found=False` or the stored payload text was NULL/empty. |

### 2.4 Control flow (exact order)
1. `_require_known_signal_type(input.signal_type)` — same guard/exception as §1.3 step 1.
2. `wave_uuid = uuid.UUID(input.wave_id)`.
3. `target_uuid = uuid.UUID(input.target_app_id)`. (⚠️ `input.workflow_id` is NOT UUID-parsed — it's free text bound directly as `$4`.)
4. `conn = await asyncpg.connect(_db_url())`.
5. `try:` `row = await conn.fetchrow(<UPDATE...RETURNING>, ...)` (§2.5); `finally: await conn.close()`.
6. `if row is None: return ConsumeArchDataSignalResult(found=False, payload_json="")` — early return; **no log emitted** in the not-found branch.
7. Else: `payload_text = row["payload_text"] or ""` (coerce NULL→`""`).
8. Emit observability log (§2.6).
9. `return ConsumeArchDataSignalResult(found=True, payload_json=payload_text)`.

### 2.5 EXACT SQL — single statement, `conn.fetchrow(...)`
```sql
UPDATE arch_data_signal_registry
SET consumed_at = COALESCE(consumed_at, now()),
    consumed_by_workflow_id = COALESCE(
        consumed_by_workflow_id, $4
    )
WHERE wave_id = $1
  AND target_app_id = $2
  AND signal_type = $3
  AND (
      consumed_at IS NULL
      OR consumed_by_workflow_id = $4
  )
RETURNING payload::text AS payload_text
```
Positional params:
- `$1 = wave_uuid` → `wave_id`
- `$2 = target_uuid` → `target_app_id`
- `$3 = input.signal_type` → `signal_type`
- `$4 = input.workflow_id` (**text**) → claimer + idempotency comparator

This is an **atomic claim-or-return-owned** statement. Reproduce all four clauses exactly:

- **`SET consumed_at = COALESCE(consumed_at, now())`** — first claim sets `consumed_at = now()`; a re-claim by the same workflow_id keeps the ORIGINAL `consumed_at` (COALESCE returns the non-NULL existing value). ⚠️ Timestamps reflect the FIRST claim, not the replay — critical for replay/retry idempotency.
- **`SET consumed_by_workflow_id = COALESCE(consumed_by_workflow_id, $4)`** — first claim stamps `$4`; re-claim preserves the existing claimer (which equals `$4` because the WHERE matched on it).
- **`WHERE (consumed_at IS NULL OR consumed_by_workflow_id = $4)`** — the row is updatable/returnable in exactly two cases:
  1. **Unclaimed** (`consumed_at IS NULL`) → this call claims it.
  2. **Already claimed by ME** (`consumed_by_workflow_id = $4`) → idempotent no-op-ish update, still returns the payload. (Handles activity retry / workflow replay / duplicate consume.)
- If the row exists but is claimed by a DIFFERENT workflow_id, the WHERE predicate is FALSE, the UPDATE matches 0 rows, `RETURNING` yields nothing, `fetchrow` returns `None` ⇒ `found=False`. ⚠️ The caller cannot distinguish "no row at all" from "row owned by someone else" — both return `found=False`. Per source docstring this is by design: both mean "wait / keep polling" (the publisher is expected to eventually re-publish, which re-nulls the claim and re-arms the row).
- **`RETURNING payload::text AS payload_text`** — returns the JSONB payload serialized to text. Only the claimed/owned row is returned. ⚠️ `payload::text` (NOT `payload` raw) — asyncpg would otherwise hand back a JSON/dict-ish type; the cast forces a plain string the result dataclass expects. The column alias is exactly `payload_text` and the code reads `row["payload_text"]`.

⚠️ **GOTCHA-A (atomicity / concurrency):** A single `UPDATE ... RETURNING` is one atomic statement under asyncpg autocommit. Two concurrent consumers (different workflow_ids) racing on a fresh unclaimed row: PostgreSQL row-locks during UPDATE; the first commits `consumed_at`/`consumed_by_workflow_id`, the second's WHERE re-evaluates against the now-committed row, sees `consumed_at` non-NULL AND `consumed_by_workflow_id != $4`, matches 0 rows, returns `found=False`. Exactly one consumer wins. Do NOT reimplement as SELECT-then-UPDATE — that reintroduces the race the single statement closes.

### 2.6 Observability log (found-only)
```python
logger.info(
    "arch_data_registry.consume",
    extra={
        "signal_type": input.signal_type,
        "wave_id": input.wave_id,
        "target_app_id": input.target_app_id,
        "workflow_id": input.workflow_id,
        "payload_chars": len(payload_text),
    },
)
```
Event name `"arch_data_registry.consume"`; five `extra` keys. ⚠️ Emitted only when `row is not None` (after the early `found=False` return). `payload_chars = len(payload_text)` (post-COALESCE-to-`""`).

### 2.7 Columns touched by consume (mapping)

| table.column | Read / Written | Value / condition |
|---|---|---|
| `wave_id`, `target_app_id`, `signal_type` | **Read** (WHERE filter) | `$1`, `$2`, `$3`. Scope-key lookup; backed by partial index `idx_arch_data_registry_lookup (wave_id,target_app_id,signal_type) WHERE consumed_at IS NULL` for the unclaimed lookup path. |
| `consumed_at` | **Read** (WHERE) + **Written** (SET, conditional) | Written `COALESCE(consumed_at, now())` only when row matches WHERE. First claim → `now()`; re-claim → unchanged. |
| `consumed_by_workflow_id` | **Read** (WHERE) + **Written** (SET, conditional) | Written `COALESCE(consumed_by_workflow_id, $4)`. First claim → `$4`; re-claim → unchanged. |
| `payload` | **Read** (RETURNING `payload::text`) | Never modified by consume; returned as `payload_text`. |
| `id`, `created_at` | Untouched | Not in WHERE/SET/RETURNING. |

### 2.8 Error handling / retries / idempotency (consume)
- **Idempotency (per workflow_id):** This is the central correctness property. A workflow that already claimed the row (its id == `consumed_by_workflow_id`) re-running consume hits the `OR consumed_by_workflow_id = $4` branch, the COALESCEs preserve the original timestamps, and the SAME payload is returned with `found=True`. Safe across activity retries, workflow replay, and duplicate calls.
- **Retryable / non-retryable:** identical mapping to publish (preamble table): connection/timeout → `RetryableError`; `ValueError` (bad signal_type / bad UUID) → `NonRetryableError`.
- **No explicit transaction:** single statement, autocommit. The atomic claim relies on PG statement-level atomicity + row locking (GOTCHA-A), not a wrapping `BEGIN`.
- **Connection lifecycle:** fresh `asyncpg.connect` per call, `await conn.close()` in `finally`.
- ⚠️ **Retry-after-claim is safe:** if the activity claims the row (commits the UPDATE) but the result is lost (network blip on the way back to the worker) and Temporal retries, the retry re-matches via the `OR consumed_by_workflow_id = $4` branch and returns the same payload — no double-claim, no lost payload.

---

## 3. Caller contract (how the workflows drive these — required for behavioral parity)

Both activities are pure registry primitives; the **polling/publish loop lives in the workflows** (`workflows/architecture.py`, `workflows/data.py`). Reproducing the activities without this contract loses the handshake. Captured here:

### 3.1 Worker registration
Registered in `olympus_workflows/worker.py` (imported lines 38–39, registered in the activities list ~lines 213–214) as bare functions `publish_arch_data_signal`, `consume_arch_data_signal`. Both must be registered on the worker that runs `ArchitectureWorkflow` and `DataWorkflow`.

### 3.2 `workflow.patched("arch-data-registry-v1")` gate
All registry use is gated behind `workflow.patched("arch-data-registry-v1")`. Three branches exist in each waiter (`architecture._wait_for_data_ready`, `data._wait_for_target_provisioned`):
1. **Signal-fast-path + DB-backstop** branch (first patched branch): `workflow.wait_condition(lambda: self._<flag> or self.cancelled, timeout=this_wait)`; on `asyncio.TimeoutError` (`pass`), does ONE `consume_*` DB read per iteration as a backstop. If the in-memory signal flag is set, returns without hitting the DB.
2. **Pure-registry** branch (`elif workflow.patched("arch-data-registry-v1")`): `while True` loop — return immediately if `self._<flag>`; else call `consume_*`; on `result.found` hydrate cached refs (§3.4) and return; else check `self.cancelled` (raise `RuntimeError("cancelled waiting for ...")`), check timeout (raise `RuntimeError("timed out waiting for ...")`), then `await workflow.sleep(_REGISTRY_POLL_INTERVAL_SECONDS)` and add to `elapsed`.
3. **Legacy** branch (`else`): pre-registry in-flight workflows replay here with `workflow.wait_condition(lambda: self._<flag> or self.cancelled)` (pure signal, no activity) to preserve Temporal history equality. ⚠️ This branch MUST be preserved verbatim for deterministic replay of histories started before the patch.

### 3.3 Poll constants (identical in both workflow files)
- `_REGISTRY_POLL_INTERVAL_SECONDS = 15` (`architecture.py:137`, `data.py:137`).
- Architecture wait cap: `_DATA_READY_WAIT_TIMEOUT_SECONDS = 24 * 60 * 60` (`architecture.py:131`).
- Data wait cap: `_TARGET_PROVISIONED_WAIT_TIMEOUT_SECONDS = 24 * 60 * 60` (`data.py:136`).
- Consumer loop: poll every 15s, timeout after 24h ⇒ raises `RuntimeError("timed out waiting for ...registry entry")`.

### 3.4 `execute_activity` arguments (both callers, both directions)
- `publish_arch_data_signal`: `start_to_close_timeout=timedelta(seconds=30)`, `retry_policy=RETRY_POLICIES["transient"]`, `activity_id="publish-target-provisioned"` (Architecture→Data) / `activity_id="publish-data-ready-for-target"` (Data→Architecture).
- `consume_arch_data_signal`: `start_to_close_timeout=timedelta(seconds=30)`, `retry_policy=RETRY_POLICIES["transient"]`, `activity_id="consume-data-ready-for-target"` (Architecture polling) / `activity_id="consume-target-provisioned"` (Data polling).
- ⚠️ `activity_id` is stable per logical call so Temporal de-dupes the activity on replay.

### 3.5 Publish call assembly (Architecture→Data, `architecture.py` ~1812–1859)
- Guarded by `if workflow.patched("arch-data-registry-v1")`; then **`if not input.wave_id: log "...publish skipped — no wave_id..."; return`** — standalone/unit runs without a wave skip publish entirely (registry requires a UUID).
- Builds `PublishArchDataSignalInput(signal_type=SIGNAL_TARGET_PROVISIONED, wave_id=input.wave_id, target_app_id=target_app_id, payload_json=_encode_target_provisioned_payload(payload))`.
- ⚠️ **Wrapped in `try/except Exception: log warning, swallow`** — registry publish is **best-effort** for `target_provisioned`; a failed publish logs `"target-provisioned registry publish failed: %s"` and does NOT fail the workflow (the consumer's poll-with-republish will recover). After success, emits a separate structured `"arch_data_signal_fired"` observability log (signal topology trace, PR #494).
- Data→Architecture publish (`data.py` ~1328–1333) builds `PublishArchDataSignalInput(signal_type=SIGNAL_DATA_READY_FOR_TARGET, ..., payload_json=_encode_data_ready_payload(signal_payload))`.

---

## 4. Backing table DDL (migration 046 — must exist before activities run)

`db/alembic/versions/046_create_arch_data_signal_registry.py` (`revision="046"`, `down_revision="045"`). DDL only, no seed data.

```python
op.create_table(
    "arch_data_signal_registry",
    sa.Column("id", postgresql.UUID(as_uuid=True), primary_key=True,
              server_default=sa.text("gen_random_uuid()")),
    sa.Column("wave_id", postgresql.UUID(as_uuid=True), nullable=False),
    sa.Column("target_app_id", postgresql.UUID(as_uuid=True), nullable=False),
    sa.Column("signal_type", sa.Text(), nullable=False),
    sa.Column("payload", postgresql.JSONB(astext_type=sa.Text()), nullable=False),
    sa.Column("created_at", sa.TIMESTAMP(timezone=True), nullable=False,
              server_default=sa.text("now()")),
    sa.Column("consumed_at", sa.TIMESTAMP(timezone=True), nullable=True),
    sa.Column("consumed_by_workflow_id", sa.Text(), nullable=True),
    sa.UniqueConstraint("wave_id", "target_app_id", "signal_type",
                        name="arch_data_signal_registry_scope_uk"),
)
# Partial index — only unconsumed rows; consume lookup stays O(1) as consumed rows accumulate.
op.execute(
    "CREATE INDEX idx_arch_data_registry_lookup "
    "ON arch_data_signal_registry (wave_id, target_app_id, signal_type) "
    "WHERE consumed_at IS NULL"
)
```
`downgrade()`: `DROP INDEX IF EXISTS idx_arch_data_registry_lookup;` then `op.drop_table("arch_data_signal_registry")`.

**Full column inventory (8 columns):** `id` (UUID PK, default `gen_random_uuid()`), `wave_id` (UUID NOT NULL), `target_app_id` (UUID NOT NULL), `signal_type` (TEXT NOT NULL), `payload` (JSONB NOT NULL), `created_at` (TIMESTAMPTZ NOT NULL default `now()`), `consumed_at` (TIMESTAMPTZ NULL), `consumed_by_workflow_id` (TEXT NULL).
**Constraints/indexes:** PK on `id`; unique `arch_data_signal_registry_scope_uk (wave_id, target_app_id, signal_type)`; partial index `idx_arch_data_registry_lookup (wave_id, target_app_id, signal_type) WHERE consumed_at IS NULL`. ⚠️ No CHECK constraint on `signal_type` — validation is application-side only (`_require_known_signal_type`). Requires the `pgcrypto`/`gen_random_uuid()` function to be available in the DB.

---

## 5. `payload_json` shapes (produced by the caller encoders — what lands in `payload` JSONB)

The activity treats `payload_json` as opaque text. For end-to-end fidelity, the exact JSON object shapes (from the workflow-side encoders) are:

### 5.1 `signal_type == "target_provisioned"` — `_encode_target_provisioned_payload` (`architecture.py:148`)
`json.dumps` of a dict over `TargetProvisionedSignal` (`types.py:207–`), 9 keys, in this order:
```json
{
  "target_app_id": "<uuid str>",
  "portfolio_id": "<str>",
  "architecture_workflow_id": "<temporal wf id, so Data can route the reply>",
  "wave_id": "<uuid str>",
  "disposition": "<Refactor|Replace|Consolidate|Rearchitect|Replatform|Retain|Retire>",
  "target_repo_url": "<str, '' for pre-A3 senders>",
  "target_service_id": "<getattr(...,'') or ''>",
  "relationship": "<getattr(...,'') or ''>",
  "source_app_ids": [ ... list, getattr(...,[]) or [] ]
}
```
`TargetProvisionedSignal` fields: `target_app_id`, `portfolio_id`, `architecture_workflow_id`, `wave_id`, `disposition` (required); `target_repo_url=""`, `target_service_id=""`, `relationship=""`, `source_app_ids` (defaults, W19 additions). Decoder `_decode_target_provisioned_payload` (`data.py:158`) `json.loads`; returns `{}` on falsy/`ValueError`/`TypeError`/non-dict.

### 5.2 `signal_type == "data_ready_for_target"` — `_encode_data_ready_payload` (`data.py:146`)
`json.dumps` over `DataReadyForTargetSignal` (`types.py:190–`), 4 keys:
```json
{
  "target_app_id": "<uuid str>",
  "data_architecture_ref": "<artifact repo path>",
  "data_migration_plan_ref": "<artifact repo path>",
  "approved_at": "<ISO-8601>"
}
```
Decoder `_decode_data_ready_payload` (`architecture.py:175`): same `{}` fallback semantics; consumer reads `data_architecture_ref` / `data_migration_plan_ref` (default `""`).

⚠️ The activity stores whatever string it's handed; if a future caller changes the encoder shape, the registry is agnostic (DB is type-agnostic). The consumer's decoders tolerate missing keys via `.get(key, "")`.

---

## 6. `_db_url()` and module constants

`_db_url()` (lines 51–63) — env-driven DSN, **duplicated** from `gate_operations._db_url` / `wave_operations._db_url` so this activity file has no cross-activity imports (keeps each file self-contained for worker registration). Defaults:
```
DATABASE_HOST  → "localhost"
DATABASE_PORT  → "5432"
DATABASE_USER  → "olympus"
DATABASE_PASSWORD → "olympus"
DATABASE_NAME  → "olympus"
⇒ f"postgresql://{user}:{password}@{host}:{port}/{db}"
```
Module constants (lines 44–48):
- `SIGNAL_TARGET_PROVISIONED = "target_provisioned"`
- `SIGNAL_DATA_READY_FOR_TARGET = "data_ready_for_target"`
- `_ALLOWED_SIGNAL_TYPES = frozenset({SIGNAL_TARGET_PROVISIONED, SIGNAL_DATA_READY_FOR_TARGET})`
- `logger = logging.getLogger(__name__)`

⚠️ The two signal_type string literals must match the **pre-migration Temporal signal handler names verbatim** (`DataWorkflow.target_provisioned`, `ArchitectureWorkflow.data_ready_for_target`) so audit-trail and metric labels stay recognizable. Do not rename.

---

## 7. Reproduction checklist (parity gate)

- [ ] Both activities decorated with `@foundry_activity(config=ActivityConfig(enable_observability=True))`, NOT `@activity.defn`; error-wrapping + retryability classification per preamble.
- [ ] `_require_known_signal_type` runs FIRST (before any UUID parse or DB connect); exact message and `sorted(...)` ordering.
- [ ] UUID-parse `wave_id` + `target_app_id` (publish: both; consume: both, NOT `workflow_id`).
- [ ] Publish: exact upsert SQL with `$4::jsonb` cast and `ON CONFLICT (wave_id,target_app_id,signal_type) DO UPDATE SET payload=EXCLUDED.payload, consumed_at=NULL, consumed_by_workflow_id=NULL, created_at=now()`.
- [ ] Consume: exact `UPDATE ... SET consumed_at=COALESCE(consumed_at,now()), consumed_by_workflow_id=COALESCE(consumed_by_workflow_id,$4) WHERE ... AND (consumed_at IS NULL OR consumed_by_workflow_id=$4) RETURNING payload::text AS payload_text`.
- [ ] Consume returns `found=False, payload_json=""` on `row is None` (no log); else `found=True, payload_json=row["payload_text"] or ""` (+ log).
- [ ] Fresh `asyncpg.connect` per call; `await conn.close()` in `finally`; autocommit (no explicit transaction).
- [ ] Log events `"arch_data_registry.publish"` (success only) and `"arch_data_registry.consume"` (found only) with exact `extra` keys.
- [ ] Table `arch_data_signal_registry` with all 8 columns + unique constraint + partial index.

---

## 8. Undetermined / out-of-scope

- Nothing undetermined for the two activities — both are fully reproduced from source (`arch_data_registry.py` lines 1–215) including SQL, types, DDL, error mapping, and caller contract.
- The full bodies of `ArchitectureWorkflow._wait_for_data_ready` / `DataWorkflow._wait_for_target_provisioned` and the publish call sites belong to the **workflow** specs (Phase 3); summarized here (§3) only to the extent needed to make the activities' polling/idempotency/best-effort semantics reproducible. The legacy/signal-fast-path branches are noted but their full pre-registry signal-handler code is the workflows' responsibility.
- `RETRY_POLICIES["transient"]` exact value is defined in the workflows' shared retry-policy table (Phase 3), not in this activity file.
