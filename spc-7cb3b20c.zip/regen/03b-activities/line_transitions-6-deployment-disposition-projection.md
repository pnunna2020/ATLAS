# Activity Group: line_transitions — Deployment / Disposition / Line Projection / Target-State Grain / Target-App Provisioning / Source Termination

**Source file:** `temporal/olympus_workflows/activities/line_transitions.py`
**HEAD:** `7cb3b20c`. **Range owned:** lines **6004–8369** (read whole file for context; reproduce ONLY this range).
**Sibling files own everything else** in `line_transitions.py` (Discovery/Rationalization/Architecture/Data/Modernization/Validation/Governance/Sustainment projections, `start_next_line_workflow`, `fetch_application_source_repos`, and all shared helpers defined before line 6004).

⚠️ **Line numbers REFRESHED to HEAD.** The file grew by +162 lines since the prior baseline. Every symbol owned by this group shifted by **+152** (the insertion landed upstream of this range). The one exception is the sibling-owned `_build_update_sql`, now at **1226** (was 1111). Bodies are behaviorally UNCHANGED vs the prior baseline — only citations moved.

This group reproduces, in source order:

| # | Symbol | Kind | Lines | Decorated |
|---|--------|------|-------|-----------|
| 1 | `persist_deployment_side_effects` | **Temporal activity** | 6004–6095 | `@foundry_activity` |
| 2 | `persist_disposition_side_effects` | **Temporal activity** | 6279–6408 | `@foundry_activity` |
| 3 | `update_application_line_projection` | **Temporal activity** | 6417–6485 | `@foundry_activity` |
| 4 | `realize_target_state_grain` | **Temporal activity** | 7005–7304 | `@foundry_activity` |
| 5 | `create_target_app_and_repo` | **Temporal activity** | 7689–8142 | `@foundry_activity` |
| 6 | `terminate_source_app_workflows` | **Temporal activity** | 8321–8369 | `@foundry_activity` |

Plus module-level constants and **non-activity helper functions** that ONLY these activities call (reproduced because they carry load-bearing logic): deployment extractors (5825–6000), disposition extractors (6124–6275), target-state-grain helpers (6498–7001), source-artifacts-index helpers (7307–7685), and source-termination helpers (8145–8317).

> **Range note on numbering:** `persist_deployment_side_effects` begins at the `@foundry_activity` decorator on line **6003** with the `async def` on **6004**. The prompt cites the `async def` line numbers; this spec cites both decorator and def where it matters.

---

## 0. SHARED PREAMBLE — read before any activity

### 0.1 The `@foundry_activity` decorator wrapper (CRITICAL — applies to all 6 activities)

Every activity in this group is decorated with:

```python
@foundry_activity(config=ActivityConfig(enable_observability=True))
```

from `foundry_temporal.activities` (NOT plain `@activity.defn`). Source of truth: `foundry_temporal/activities.py`. Behavioral-parity requirements for a rebuild:

1. **It applies `@activity.defn(name=None)`** internally (`activity.defn(name=name, **activity_kwargs)` with `name=None` → Temporal uses the function name). So the registered Temporal activity name == the Python function name (`persist_deployment_side_effects`, etc.).
2. **`@wraps(func)`** preserves the wrapped function's name/docstring.
3. **Observability** (because `enable_observability=True`, the default): on entry logs `"Activity {name} starting"`; on success logs `"Activity {name} completed"`; on exception logs `"Activity {name} failed: {error}"` via `get_logger()`. `log_inputs`/`log_outputs` default `False`, so the `extra={"inputs": ...}`/`{"outputs": ...}` payloads are `None`.
4. **Error wrapping (`enable_error_wrapping=True`, the default) — the load-bearing part.** On any exception the wrapper:
   - **re-raises unchanged** if the error is a `WorkflowError` **or** `temporalio.exceptions.ApplicationError` (i.e. `NonRetryableError`/`RetryableError`, which subclass `WorkflowError(ApplicationError)`, pass through with their `non_retryable` flag intact);
   - else if `_is_retryable_error(error)` → wraps in `RetryableError(f"Retryable error in {name}: {error}")` (which is `non_retryable=False`);
   - else → wraps in `NonRetryableError(f"Non-retryable error in {name}: {error}")` (`non_retryable=True`).
   - `_is_retryable_error` lowercases `str(type(error))` and returns True iff it contains any of: `timeout`, `connection`, `network`, `temporary`, `unavailable`, `overload`, `busy`, `throttle`, `rate_limit`. **An UNKNOWN bare `Exception` is therefore wrapped NON-retryable by default.** A rebuild using plain `@activity.defn` loses this classification and Temporal would retry every error per the workflow's RetryPolicy — WRONG.

   ⚠️ **GOTCHA — `asyncpg` errors are wrapped NON-retryable by this rule.** `str(type(asyncpg.PostgresError))` does not contain any retryable token. So a Postgres error that escapes an activity body is classified **non-retryable** and will NOT be retried. The best-effort activities below (`persist_*`) deliberately swallow DB errors *inside* the body precisely so the activity returns success rather than relying on retry. (`OSError` connection-refused from `asyncpg.connect` likewise does not match — non-retryable.)

5. **`config` does not set any timeout/retry policy here** — `ActivityConfig(enable_observability=True)` leaves `retry_policy`, `start_to_close_timeout`, etc. all `None`. Those come from the **caller's** `workflow.execute_activity(...)` options, NOT the decorator. The decorator config in this group only governs observability + error-wrapping.

### 0.2 Module imports / globals used by this range

From the file header (lines 15–78):
```python
import json, logging, os, uuid
from datetime import datetime, timezone
from decimal import Decimal
from typing import Any
import asyncpg
from foundry_temporal.activities import ActivityConfig, foundry_activity
from foundry_temporal.errors import NonRetryableError
from temporalio.client import Client
from olympus_workflows.types import (... all the Input/Result dataclasses ...)
from olympus_workflows.utils.execution import (ExecutionStatus, emit_code_step_complete, emit_code_step_start)
logger = logging.getLogger(__name__)
```

### 0.3 `_db_url()` — connection string builder (line 88)

```python
def _db_url() -> str:
    host = os.environ.get("DATABASE_HOST", "localhost")
    port = os.environ.get("DATABASE_PORT", "5432")
    user = os.environ.get("DATABASE_USER", "olympus")
    password = os.environ.get("DATABASE_PASSWORD", "olympus")
    db = os.environ.get("DATABASE_NAME", "olympus")
    return f"postgresql://{user}:{password}@{host}:{port}/{db}"
```
Every DB access opens a **fresh** `await asyncpg.connect(_db_url())` and closes it in a `finally`. There is no pool. (Identical helper duplicated in `utils/execution.py`.)

### 0.4 `_temporal_host()` / `_temporal_namespace()` (lines 97/101)

```python
def _temporal_host() -> str:      return os.environ.get("TEMPORAL_HOST", "temporal:7233")
def _temporal_namespace() -> str: return os.environ.get("TEMPORAL_NAMESPACE", "default")
```

### 0.5 `_try_parse_json(text)` (line 281) — best-effort agent-output parse

```python
def _try_parse_json(text: str) -> dict[str, Any] | None:
    if not text:
        return None
    try:
        value = json.loads(text)
    except json.JSONDecodeError:
        start = text.find("{"); end = text.rfind("}")
        if start == -1 or end <= start:
            return None
        try:
            value = json.loads(text[start : end + 1])
        except json.JSONDecodeError:
            return None
    return value if isinstance(value, dict) else None
```
Returns a **dict** or **None**. Two-stage: parse whole string; on failure carve out first `{`…last `}` and re-parse. Non-dict JSON (list/scalar) → `None`. Empty/whitespace-only handled by `if not text`.

### 0.6 `emit_code_step_start` / `emit_code_step_complete` (from `utils/execution.py`)

These wrap the `step_execution` table (migration 033). **Behavioral-parity contract:**

- `emit_code_step_start(ctx, *, function_name, columns_writable=None) -> uuid.UUID | None`:
  - If `ctx is None` → returns `None` immediately (no row). (Every activity here passes `input.execution_context`, which may be `None`.)
  - Reads `workflow_id` + `attempt` from `temporalio.activity.info()` (wrapped in try/except → `("", 1)` on failure).
  - Builds `payload = {"function": function_name}`; if `columns_writable` truthy, adds `payload["columns_written"]`.
  - Calls `emit_execution_record(EmitExecutionRecordInput(portfolio_id=ctx.portfolio_id, line_id=ctx.line_id, step_id=ctx.step_id, step_kind=StepKind.CODE, workflow_id=..., app_id=ctx.app_id or None, wave_id=ctx.wave_id or None, attempt=..., payload=payload, status=ExecutionStatus.RUNNING))`.
  - `emit_execution_record` returns `None` (best-effort) if `portfolio_id` is not a valid UUID, or on any DB exception (logs a warning). Otherwise INSERTs into `step_execution` and returns the new `execution_id` (a `uuid.uuid4()`).
  - **INSERT columns:** `execution_id, app_id, wave_id, portfolio_id, line_id, step_id, step_kind('code'), status('running'), started_at(now), attempt, input_artifacts('[]'::jsonb), payload(json), workflow_id, agent_task_id(NULL), gate_id(NULL)`.
  - ⚠️ The `step_execution` CHECK constraints require `(step_kind='agent')=(agent_task_id IS NOT NULL)` and `(step_kind='gate')=(gate_id IS NOT NULL)`. For `code` kind both FK ids must be NULL — which the code-step path satisfies (it never sets them).
- `emit_code_step_complete(execution_id, *, status=ExecutionStatus.COMPLETED, columns_written=None, error=None) -> None`:
  - If `columns_written is not None` → `payload_merge = {"columns_written": columns_written}` (note: empty list `[]` IS `not None`, so it overwrites to empty).
  - Calls `update_execution_record(execution_id, status=status, payload_merge=payload_merge, last_error=error)`.
  - `update_execution_record` no-ops if `execution_id is None`. Otherwise UPDATE `step_execution` SET `status`, `completed_at=now`, `duration_ms=EXTRACT(EPOCH FROM (completed - started_at))*1000`, `output_artifacts=COALESCE($,output_artifacts)`, `payload = payload || COALESCE($::jsonb,'{}')`, `last_error=COALESCE($,last_error)` WHERE `execution_id=$1`. Best-effort (swallows exceptions).

  **Net effect for this group:** when `execution_context` is `None`, `exec_id` is `None` and every `emit_code_step_*` call is a silent no-op. The observability writes never affect activity success.

### 0.7 `ExecutionStatus` enum (used as `ExecutionStatus.FAILED`, `.COMPLETED`)

`str`-Enum: `QUEUED="queued"`, `RUNNING="running"`, `COMPLETED="completed"`, `FAILED="failed"`, `TIMED_OUT`, `SKIPPED`, `ESCALATED`, `ABANDONED`. Only `.COMPLETED` (default) and `.FAILED` are used in this range.

### 0.8 `_build_update_sql(projections)` — shared projection→UPDATE builder (line 1226, sibling-owned but REQUIRED here)

`persist_deployment_side_effects` and `persist_disposition_side_effects` both call this. **Reproduce exactly** — the column ordering is load-bearing for parameter binding.

```python
def _build_update_sql(projections: dict[str, Any]) -> tuple[str, list[Any]]:
    assignments: list[str] = []
    params: list[Any] = []
    idx = 1
    for column in _SIDE_EFFECT_COLUMNS:        # iterate the CANONICAL ordered tuple
        if column not in projections:
            continue
        value = projections[column]
        if column in _JSONB_COLUMNS:
            value = json.dumps(value)
        assignments.append(f"{column} = ${idx}")
        params.append(value)
        idx += 1
    assignments.append(f"updated_at = ${idx}")  # ALWAYS appended
    params.append(datetime.now(timezone.utc))
    idx += 1
    where_idx = idx
    sql = "UPDATE application SET " + ", ".join(assignments) + f" WHERE id = ${where_idx}"
    return sql, params
```

⚠️ **GOTCHA — ordering & parameter binding.** Columns are emitted **in `_SIDE_EFFECT_COLUMNS` tuple order**, NOT dict-insertion order. Caller then does `params.append(<app_uuid>)` so the final `$N` is the WHERE id. The result is a single `UPDATE application SET col=$k, ..., updated_at=$m WHERE id=$n`. `updated_at` is **always** touched even when only one real column changes.

⚠️ **GOTCHA — `_JSONB_COLUMNS` membership decides `json.dumps`.** For this group, the relevant projected columns (`deployed_at`, `deployment_env`, `cutover_strategy`, `parallel_run_duration_days`, `cost_savings_realized_usd`, `license_reclamation_usd`, `legacy_decommissioned_at`, `deployment_current_status`, `disposition_output_ref`, `disposition_completed_at`, `disposition_current_status`, `cost_savings_annual_usd`) are **NOT** in `_JSONB_COLUMNS`, so their values are bound as native Python objects (asyncpg encodes `datetime`→timestamptz, `Decimal`→numeric, `int`→integer, `str`→varchar/text). No `json.dumps` on any column written by this group.

**Canonical `_SIDE_EFFECT_COLUMNS` tuple slice relevant to this group** (positions matter; full tuple at lines 791–874). The Deployment + Disposition columns appear in this fixed order near the tail:
```
... (Validation cols) ...
"deployed_at", "deployment_env", "cutover_strategy",
"parallel_run_duration_days", "cost_savings_realized_usd",
"license_reclamation_usd", "legacy_decommissioned_at", "deployment_current_status",
"disposition_output_ref", "disposition_completed_at",
"disposition_current_status", "cost_savings_annual_usd",
```
`_JSONB_COLUMNS` (frozenset, lines 877–892) = `{tech_stack, size_metrics, architecture, business_logic, quality, ux_assessment, tco, portfolio_score, data_domains, bounded_contexts, generated_module_refs}` — none of which belong to this group.

---

# ACTIVITY 1 — `persist_deployment_side_effects` (lines 6003/6004–6095)

### 1.1 Signature & decorator
```python
@foundry_activity(config=ActivityConfig(enable_observability=True))
async def persist_deployment_side_effects(
    input: PersistDeploymentSideEffectsInput,
) -> PersistDeploymentSideEffectsResult:
```

### 1.2 Input dataclass `PersistDeploymentSideEffectsInput` (types.py 2478)
```python
@dataclass
class PersistDeploymentSideEffectsInput:
    target_app_id: str
    deployment_manifest_json: str = ""
    decommission_certificate_json: str = ""
    license_reclamation_json: str = ""
    cost_savings_certification_json: str = ""
    deployment_current_status: str = ""
    execution_context: "StepExecutionContext | None" = None
```

### 1.3 Result dataclass `PersistDeploymentSideEffectsResult` (types.py 2509)
```python
@dataclass
class PersistDeploymentSideEffectsResult:
    target_app_id: str
    deployed_at_persisted: bool = False
    legacy_decommissioned_at_persisted: bool = False
    cost_savings_realized_persisted: bool = False
    license_reclamation_persisted: bool = False
    deployment_current_status: str = ""
```

### 1.4 Purpose & invocation
Runs **once per target app** at Deployment Step 17 (`persist-deployment-side-effects`) after G-DP-2 merges. Consolidates four extractor helpers into ONE `UPDATE application` that touches only populated columns. **Best-effort by intent** (the workflow continues to the terminal Sustainment handoff even if projection raises) — but note the actual try/except shape below: unlike Activity 2, Activity 1 does **NOT** swallow DB errors; it re-raises after marking the step FAILED. (The *workflow* tolerates the failure, not the activity.)

### 1.5 Control flow (reproduce exactly)
1. `exec_id = await emit_code_step_start(input.execution_context, function_name="persist_deployment_side_effects")`.
2. Outer `try:`. Inside:
   a. Parse `target_uuid = uuid.UUID(input.target_app_id)`; on `(ValueError, TypeError)` → `raise NonRetryableError(f"Invalid target_app_id: {input.target_app_id!r}")`. **⚠️ This raise happens BEFORE the broad `except` (step 3) — it is caught by the outer except, which marks the step FAILED and re-raises.**
   b. Parse the four artifact strings with `_try_parse_json`:
      - `manifest = _try_parse_json(input.deployment_manifest_json)`
      - `certificate = _try_parse_json(input.decommission_certificate_json)`
      - `reclamation = _try_parse_json(input.license_reclamation_json)`
      - `certification = _try_parse_json(input.cost_savings_certification_json)`
   c. Build `projections: dict[str, Any] = {}`, then `.update()` in this order:
      - `_extract_deployment_lifecycle_side_effects(manifest)`
      - `_extract_decommission_side_effects(certificate, reclamation)`
      - `_extract_realized_savings_side_effects(certification)`
      - `_extract_deployment_status(input.deployment_current_status)`
   d. **If `projections` is empty:** log info `"persist_deployment_side_effects: nothing extractable"` (extra `target_app_id`), `await emit_code_step_complete(exec_id, columns_written=[])`, and `return PersistDeploymentSideEffectsResult(target_app_id=input.target_app_id)` (all booleans False, status="").
   e. Else: `sql, params = _build_update_sql(projections)`; `params.append(target_uuid)`.
   f. `conn = await asyncpg.connect(_db_url())`; `try: await conn.execute(sql, *params)`; `finally: await conn.close()`.
   g. Log info `"deployment side-effects persisted"` with `extra={target_app_id, columns_written: sorted(projections.keys())}`.
   h. `await emit_code_step_complete(exec_id, columns_written=sorted(projections.keys()))`.
   i. Build result:
      ```python
      return PersistDeploymentSideEffectsResult(
          target_app_id=input.target_app_id,
          deployed_at_persisted=("deployed_at" in projections),
          legacy_decommissioned_at_persisted=("legacy_decommissioned_at" in projections),
          cost_savings_realized_persisted=("cost_savings_realized_usd" in projections),
          license_reclamation_persisted=("license_reclamation_usd" in projections),
          deployment_current_status=str(projections.get("deployment_current_status", "")),
      )
      ```
3. Outer `except Exception as exc:` → `await emit_code_step_complete(exec_id, status=ExecutionStatus.FAILED, error=str(exc))`; **`raise`** (re-raise original). ⚠️ Because the re-raised error is typically `NonRetryableError` (already a `WorkflowError`), the `@foundry_activity` wrapper passes it through non-retryable. A bare `asyncpg` error from step (f) re-raises here, and `@foundry_activity` wraps it **non-retryable** (no retryable token in its type name).

### 1.6 Deployment extractors (helpers — reproduce fully)

#### `_extract_deployment_lifecycle_side_effects(manifest)` (5846)
Whitelists / parses lifecycle from the manifest dict (None/non-dict → `{}`). Output keys & rules:

| Output key | Source path(s) in `manifest` | Transform | Condition to write |
|---|---|---|---|
| `deployed_at` | `manifest["deployed_at"]` | `datetime.fromisoformat(s.replace("Z","+00:00"))` | value is non-empty `str` AND parses; parse failure → **logged warning, column dropped** |
| `deployment_env` | `manifest["environment"]` OR `manifest["deployment_env"]` (first truthy) | `s.strip()[:64]` (truncate to 64 chars) | value is `str` and `.strip()` non-empty |
| `cutover_strategy` | `manifest["strategy"]` OR `manifest["cutover_strategy"]` | passthrough | value is `str` AND in `_CUTOVER_STRATEGIES`; if truthy-but-not-whitelisted → **warning, dropped** |
| `parallel_run_duration_days` | `manifest["parallel_run"]["observed_duration_days"]` (preferred) else top-level `manifest["parallel_run_duration_days"]` | `int(duration)` | value is `int|float` |

`_CUTOVER_STRATEGIES` (frozenset, 5825) = `{"canary","blue-green","instant","vendor-swap","platform-switch","source-redirect"}`.
⚠️ Preferred parallel-run shape is the nested `parallel_run` object; only if `manifest["parallel_run"]` is NOT a dict does it fall back to the top-level scalar. `int(float)` truncates toward zero.

#### `_extract_decommission_side_effects(certificate, reclamation)` (5907)
Two independent dicts; each may contribute one key.

| Output key | Source | Transform | Condition |
|---|---|---|---|
| `legacy_decommissioned_at` | `certificate["decommissioned_at"]` OR `certificate["completed_at"]` | `datetime.fromisoformat(s.replace("Z","+00:00"))` | `certificate` is dict; value non-empty `str` AND parses; parse failure → warning + dropped |
| `license_reclamation_usd` | `reclamation["total_reclaimed_usd"]` OR `["total_usd"]` OR `["license_reclamation_usd"]` (first truthy) | `Decimal(str(round(float(total), 2)))` | `reclamation` is dict; value is `int|float` |

#### `_extract_realized_savings_side_effects(certification)` (5954)
| Output key | Source | Transform | Condition |
|---|---|---|---|
| `cost_savings_realized_usd` | `certification["cost_savings_realized_usd"]` OR `["annual_savings_usd"]` OR `["realized_annual_savings_usd"]` (first truthy) | `Decimal(str(round(float(realized), 2)))` | `certification` is dict; value is `int|float` |

#### `_extract_deployment_status(status: str)` (5983)
| Output key | Source | Transform | Condition |
|---|---|---|---|
| `deployment_current_status` | the `status` arg (workflow-forwarded, **not parsed from artifact**) | passthrough | `status` is non-empty `str` AND in `_DEPLOYMENT_STATUSES`; else (truthy non-whitelisted) → **warning, `{}`** |

`_DEPLOYMENT_STATUSES` (frozenset, 5830) = `{"orchestrating","shifting","parallel_running","verifying_adoption","awaiting_g_dp1","decommissioning","certifying","awaiting_g_dp2","completed","failed"}`.

### 1.7 COMPLETE artifact-field → DB-column mapping (table `application`)

Single statement: `UPDATE application SET <only-present-columns>, updated_at=now() WHERE id = <target_uuid>`. Columns are conditional (written only when the extractor produced the key).

| `application` column | Type (mig 036) | Source artifact + JSON path | Default if source absent | Condition (key written) |
|---|---|---|---|---|
| `deployed_at` | TIMESTAMPTZ | `deployment-manifest.json` `.deployed_at` | untouched (keeps prior) | ISO-8601 string present & parseable |
| `deployment_env` | VARCHAR(64) | manifest `.environment`/`.deployment_env` | untouched | non-empty str (truncated 64) |
| `cutover_strategy` | VARCHAR(32) | manifest `.strategy`/`.cutover_strategy` | untouched | str in `_CUTOVER_STRATEGIES` |
| `parallel_run_duration_days` | INTEGER | manifest `.parallel_run.observed_duration_days` or top-level `.parallel_run_duration_days` | untouched | int/float present |
| `legacy_decommissioned_at` | TIMESTAMPTZ | `decommission-certificate.json` `.decommissioned_at`/`.completed_at` | untouched | ISO-8601 present & parseable |
| `license_reclamation_usd` | NUMERIC(12,2) | `license-reclamation-record.json` `.total_reclaimed_usd`/`.total_usd`/`.license_reclamation_usd` | untouched | int/float present |
| `cost_savings_realized_usd` | NUMERIC(12,2) | `cost-savings-certification.json` `.cost_savings_realized_usd`/`.annual_savings_usd`/`.realized_annual_savings_usd` | untouched | int/float present |
| `deployment_current_status` | VARCHAR(64) | workflow-forwarded `input.deployment_current_status` | untouched | str in `_DEPLOYMENT_STATUSES` |
| `updated_at` | TIMESTAMPTZ | `datetime.now(timezone.utc)` | **ALWAYS written** | always (when projections non-empty) |

**Columns explicitly NOT written here** (owned by other lines): everything Discovery/Rationalization/Architecture/Data/Modernization/Disposition writes — including `cost_savings_annual_usd` (Disposition's FORECAST, vs Deployment's REALIZED `cost_savings_realized_usd`). Both coexist for Governance's forecast-vs-realized rollup.

### 1.8 Errors / retries / idempotency
- `NonRetryableError` on invalid `target_app_id`.
- Idempotent: a re-run with the same artifacts produces the same column values (only `updated_at` moves). The UPDATE is unconditional on matching `id`; if `id` doesn't exist, asyncpg reports `UPDATE 0` and **no error is raised** (return reflects projections regardless).
- No DB-error swallow in the body — DB failure propagates → step marked FAILED → re-raised → `@foundry_activity` non-retryable wrap. (Caller workflow is expected to tolerate.)

---

# ACTIVITY 2 — `persist_disposition_side_effects` (lines 6278/6279–6408)

### 2.1 Signature & decorator
```python
@foundry_activity(config=ActivityConfig(enable_observability=True))
async def persist_disposition_side_effects(
    input: PersistDispositionSideEffectsInput,
) -> PersistDispositionSideEffectsResult:
```

### 2.2 Input dataclass `PersistDispositionSideEffectsInput` (types.py 2526)
```python
@dataclass
class PersistDispositionSideEffectsInput:
    app_id: str
    disposition: str  # "Retire"|"Retain"|"Replace"|"Replatform"|"Consolidate"
    disposition_output_ref: str = ""
    disposition_output_json: str = ""
    disposition_current_status: str = ""
    completed_at: str = ""
    execution_context: "StepExecutionContext | None" = None
```

### 2.3 Result dataclass `PersistDispositionSideEffectsResult` (types.py 2555)
```python
@dataclass
class PersistDispositionSideEffectsResult:
    app_id: str
    disposition_output_ref_persisted: bool = False
    disposition_completed_at_persisted: bool = False
    disposition_current_status: str = ""
    cost_savings_annual_usd_persisted: bool = False
```

### 2.4 Purpose & invocation
Runs once per app at Disposition's `persist-disposition-side-effects` step after the **terminal gate** merges: **G-DE-2** for non-Retain dispositions, **G-DE-1** for Retain (which has no G-DE-2). Projects four declared fields onto the `application` row. **Best-effort INCLUDING DB errors** — unlike Activity 1, a DB write failure is caught, logged, the step marked FAILED, and an empty-ish result returned (no raise). Signal emission to Deployment happens in the workflow after this returns, independent of projection success.

### 2.5 Constants
- `_DISPOSITION_LIFECYCLE_STATES` (frozenset, 6124) = `{"disposition_in_progress","disposition_plan_approved","disposition_complete","disposition_failed"}`.
- `_DISPOSITION_LABELS` (frozenset, 6133) = `{"Retire","Retain","Replace","Replatform","Consolidate"}` (NOTE: Refactor/Rearchitect deliberately absent — they go through Modernization).

### 2.6 Control flow (reproduce exactly)
1. `exec_id = await emit_code_step_start(input.execution_context, function_name="persist_disposition_side_effects")`.
2. Outer `try:`:
   a. `app_uuid = uuid.UUID(input.app_id)`; on `(ValueError, TypeError)`: `await emit_code_step_complete(exec_id, status=FAILED, error=str(exc))` **then** `raise NonRetryableError(f"Invalid app_id: {input.app_id!r}")`. (⚠️ This is re-caught at the bottom by `except NonRetryableError: raise` — a deliberate dedicated clause, so it is NOT double-marked FAILED.)
   b. `disposition = (input.disposition or "").strip()`. If `disposition` truthy AND **not** in `_DISPOSITION_LABELS` → log warning `"persist_disposition_side_effects: unexpected disposition"` (extra `app_id`, `disposition`) and **continue** (do not raise) — projection just runs empty for unknown labels.
   c. `envelope = _try_parse_json(input.disposition_output_json)`.
   d. Build `projections: dict[str, Any] = {}`, `.update()` in order:
      - `_extract_disposition_output_ref_side_effects(disposition_output_ref=input.disposition_output_ref)`
      - `_extract_cost_savings_side_effects(envelope)`
      - `_extract_disposition_lifecycle_status(envelope=envelope, workflow_supplied_status=input.disposition_current_status, disposition=disposition, completed_at=input.completed_at)`
   e. If `projections` empty → log info `"persist_disposition_side_effects: nothing extractable"`, `emit_code_step_complete(exec_id, columns_written=[])`, return `PersistDispositionSideEffectsResult(app_id=input.app_id)`.
   f. Else `sql, params = _build_update_sql(projections)`; `params.append(app_uuid)`.
   g. **Inner try/except around DB** (the key difference from Activity 1):
      ```python
      try:
          conn = await asyncpg.connect(_db_url())
          try:
              await conn.execute(sql, *params)
          finally:
              await conn.close()
      except Exception as exc:  # best-effort; swallow DB blips
          logger.warning("persist_disposition_side_effects: DB write failed; continuing best-effort", extra={app_id, error})
          await emit_code_step_complete(exec_id, status=ExecutionStatus.FAILED, error=str(exc))
          return PersistDispositionSideEffectsResult(app_id=input.app_id)   # all-default booleans
      ```
   h. Log info `"disposition side-effects persisted"` (extra `app_id`, `disposition`, `columns_written: sorted(projections.keys())`).
   i. `await emit_code_step_complete(exec_id, columns_written=sorted(projections.keys()))`.
   j. Return:
      ```python
      return PersistDispositionSideEffectsResult(
          app_id=input.app_id,
          disposition_output_ref_persisted=("disposition_output_ref" in projections),
          disposition_completed_at_persisted=("disposition_completed_at" in projections),
          disposition_current_status=str(projections.get("disposition_current_status", "")),
          cost_savings_annual_usd_persisted=("cost_savings_annual_usd" in projections),
      )
      ```
3. `except NonRetryableError: raise` (dedicated — lets the invalid-app_id raise from (a) propagate without re-marking FAILED).
4. `except Exception as exc:` → `emit_code_step_complete(exec_id, status=FAILED, error=str(exc))`; `raise`. (Non-DB unexpected error; e.g. a bug in an extractor.)

⚠️ **GOTCHA — two distinct failure paths produce different observability + outcomes:** (g) catches DB errors → returns a benign empty result; (4) catches everything else → re-raises (then `@foundry_activity` non-retryable-wraps a bare error). (3) lets the invalid-UUID `NonRetryableError` through as non-retryable.

### 2.7 Disposition extractors (helpers — reproduce fully)

#### `_extract_disposition_output_ref_side_effects(*, disposition_output_ref: str)` (6138)
Pure presence-gate passthrough. If not `str` → `{}`. `ref = disposition_output_ref.strip()`. If empty → `{}`. Else `{"disposition_output_ref": ref}`.

#### `_extract_cost_savings_side_effects(envelope)` (6158)
None/non-dict → `{}`. Resolution order:
1. **Preferred:** `envelope["realized_net_impact"]` (dict) → `["tco_delta"]` (dict) → `["annual_savings_usd"]`; if `int|float` → `{"cost_savings_annual_usd": float(value)}`.
2. **Fallback:** `envelope["payload"]` (dict) → `["cost_savings_cert"]` (dict) → `["annual_savings_usd"]`; if `int|float` → `{"cost_savings_annual_usd": float(value)}`.
3. Else `{}`.
⚠️ Value cast to **`float`** here (not Decimal) — but the DB column is NUMERIC(12,2); asyncpg encodes the float into numeric. (Contrast: Deployment's realized-savings extractor uses `Decimal(str(round(...,2)))`.)

#### `_extract_disposition_lifecycle_status(*, envelope, workflow_supplied_status, disposition, completed_at)` (6202)
Produces up to two keys: `disposition_current_status` and `disposition_completed_at`.

**Status logic (workflow value dominates):**
- `status = workflow_supplied_status.strip() if workflow_supplied_status else ""`.
- If `status` truthy AND in `_DISPOSITION_LIFECYCLE_STATES` → `out["disposition_current_status"] = status`.
- **elif** `envelope` is a dict: read `env_status = envelope.get("status")`; if `str`, map bare enum → column enum:
  - `"completed"` → `"disposition_complete"`
  - `"plan_approved"` → `"disposition_plan_approved"`
  - `"in_progress"` → `"disposition_in_progress"`
  - (other values → no key written)
- **Retain correction block:** if `disposition == "Retain"` AND `out.get("disposition_current_status") == "disposition_plan_approved"`: if NOT `workflow_supplied_status` (i.e. workflow gave nothing and the value came from envelope) → overwrite `out["disposition_current_status"] = "disposition_complete"` (Retain has no G-DE-2 to advance past; envelope-as-source `plan_approved` maps up to complete). The workflow-supplied value wins when present.

**`completed_at` logic:**
- If `completed_at` truthy: `out["disposition_completed_at"] = datetime.fromisoformat(completed_at.replace("Z","+00:00"))`; on `(TypeError, ValueError)` → log warning `"disposition completed_at not ISO-8601"` and **skip the key** (no raise).

### 2.8 COMPLETE artifact-field → DB-column mapping (table `application`)

Single `UPDATE application SET <present-columns>, updated_at=now() WHERE id = <app_uuid>`.

| `application` column | Type (mig 034) | Source | Default if absent | Condition (key written) |
|---|---|---|---|---|
| `disposition_output_ref` | TEXT | `input.disposition_output_ref` (workflow-supplied git path) | untouched | non-empty after `.strip()` |
| `cost_savings_annual_usd` | NUMERIC(12,2) | envelope `.realized_net_impact.tco_delta.annual_savings_usd` else `.payload.cost_savings_cert.annual_savings_usd` | untouched | int/float present (bound as `float`) |
| `disposition_current_status` | VARCHAR(64) | `input.disposition_current_status` (preferred, must be a valid lifecycle state) else mapped envelope `.status`; Retain correction may bump `plan_approved`→`complete` | untouched | a valid lifecycle state resolved |
| `disposition_completed_at` | TIMESTAMPTZ | `input.completed_at` (ISO-8601) | untouched | parseable ISO-8601 |
| `updated_at` | TIMESTAMPTZ | `now(timezone.utc)` | **ALWAYS** | always (when projections non-empty) |

**Columns explicitly NOT written:** `risk_tier`, `portfolio_score`, `disposition` (all Rationalization); `deployed_at`, `cost_savings_realized_usd` (Deployment). The Disposition projection owns FORECAST `cost_savings_annual_usd`; Deployment owns realized.

### 2.9 Errors / retries / idempotency
- `NonRetryableError` on invalid `app_id` (propagated via dedicated except, then non-retryable).
- DB error → swallowed, returns empty result (NO raise). This is the deliberate divergence from Activity 1.
- Idempotent on re-run (same values; `updated_at` moves). `UPDATE 0` for missing id is not an error.

---

# ACTIVITY 3 — `update_application_line_projection` (lines 6416/6417–6485)

### 3.1 Signature & decorator
```python
@foundry_activity(config=ActivityConfig(enable_observability=True))
async def update_application_line_projection(
    input: UpdateApplicationLineProjectionInput,
) -> UpdateApplicationLineProjectionResult:
```

### 3.2 Input dataclass `UpdateApplicationLineProjectionInput` (types.py 1833)
```python
@dataclass
class UpdateApplicationLineProjectionInput:
    app_id: str
    line: str          # AssemblyLineName, e.g. "Architecture" / "Data"
    workflow_id: str
    status: str        # "in_progress" | "completed" | "failed"
    step: str | None = None
```

### 3.3 Result dataclass `UpdateApplicationLineProjectionResult` (types.py 1857)
```python
@dataclass
class UpdateApplicationLineProjectionResult:
    updated: bool
```

### 3.4 Purpose
Flips `application.current_line` / `current_status` / `current_step` / `workflow_id` for workflows that DON'T go through `start_next_line_workflow`'s linear handoff — specifically the per-target-app Architecture/Data fan-out spawned from `WaveRationalizationWorkflow` post-G-DA. Caller supplies its own `workflow_id` (from `workflow.info()`).

**No `execution_context`, no `emit_code_step_*` calls** in this activity — it has no observability-record emission.

### 3.5 Control flow (reproduce exactly)
1. `app_uuid = uuid.UUID(input.app_id)`; on `(ValueError, TypeError)` → `raise NonRetryableError(f"Invalid app_id: {input.app_id!r}")`.
2. `line_slug = input.line.lower().replace(" ", "-")` (e.g. `"Disposition Execution"` → `"disposition-execution"`).
3. `normalized_status = input.status.strip().lower()`. If NOT in `{"in_progress","completed","failed"}` → `raise NonRetryableError(f"Unsupported status {input.status!r} — expected 'in_progress' | 'completed' | 'failed'")`.
4. `current_status = f"{line_slug.replace('-', '_')}_{normalized_status}"` — e.g. line `"Architecture"`, status `"completed"` → `"architecture_completed"`. ⚠️ **Two-stage slug transform:** first hyphenate spaces (step 2), then underscore the hyphens here. So `"Disposition Execution"` + `"in_progress"` → `current_status = "disposition_execution_in_progress"`, while `input.line` is stored verbatim as `current_line`.
5. `conn = await asyncpg.connect(_db_url())`; `try:`:
   ```sql
   UPDATE application
   SET current_status = $1, current_line = $2, current_step = $3,
       workflow_id = $4, updated_at = $5
   WHERE id = $6
   ```
   bound `(current_status, input.line, input.step, input.workflow_id, datetime.now(timezone.utc), app_uuid)`; `finally: await conn.close()`.
   ⚠️ `input.step` may be `None` → `current_step` set to NULL. `input.line` is bound to `current_line` which is the `assembly_line_enum` column — **the string must be a valid enum label** (`"Architecture"`, `"Data"`, etc.) or Postgres raises (which then becomes non-retryable via the wrapper).
6. Parse asyncpg command tag: `result` is a string like `"UPDATE 1"`. `try: updated = int(result.split()[-1]) > 0` except `(AttributeError, ValueError, IndexError): updated = False`.
7. If not `updated` → log warning `"update_application_line_projection: no row updated"` (extra `app_id`, `line`).
8. `return UpdateApplicationLineProjectionResult(updated=updated)`.

### 3.6 COMPLETE field → DB-column mapping (table `application`)

| `application` column | Type | Source | Condition |
|---|---|---|---|
| `current_status` | VARCHAR(50) | computed `f"{line_slug_underscored}_{normalized_status}"` | always |
| `current_line` | `assembly_line_enum` | `input.line` (verbatim) | always |
| `current_step` | VARCHAR(100) | `input.step` (may be NULL) | always (NULL if step None) |
| `workflow_id` | (varchar; mig 010) | `input.workflow_id` | always |
| `updated_at` | TIMESTAMPTZ | `now(timezone.utc)` | always |

### 3.7 Errors / retries / idempotency
- `NonRetryableError` on invalid app_id or unsupported status.
- Idempotent (re-run rewrites same values; `updated` reflects whether row matched).
- A bad enum value on `current_line` → Postgres error → `@foundry_activity` non-retryable wrap (no retryable token in `asyncpg.exceptions.DataError` type name).

---

# ACTIVITY 4 — `realize_target_state_grain` (lines 7004/7005–7304)

The system/capability grain realizer. Architecture is the **only writer** of target-side `system` (kind='target'/'mixed'), `capability` (kind='derived'/'net_new'), `capability_lineage`, and `system_lineage`. Validates the G-RR-approved `capability-consolidation-plan.json` against its JSON schema BEFORE any DB write; ALL writes happen in ONE transaction (no partial commit).

### 4.1 Signature & decorator
```python
@foundry_activity(config=ActivityConfig(enable_observability=True))
async def realize_target_state_grain(
    input: RealizeTargetStateGrainInput,
) -> RealizeTargetStateGrainResult:
```

### 4.2 Input dataclass `RealizeTargetStateGrainInput` (types.py 1748)
```python
@dataclass
class RealizeTargetStateGrainInput:
    wave_id: str
    portfolio_id: str
    consolidation_plan_artifact_ref: str = ""
    consolidation_plan_json: str = ""
    artifact_repo_root: str = ""
    execution_context: "StepExecutionContext | None" = None
```
Exactly one of `consolidation_plan_json` (inline) / `consolidation_plan_artifact_ref` (disk path) must be supplied. Inline wins.

### 4.3 Result dataclass `RealizeTargetStateGrainResult` (types.py 1789)
```python
@dataclass
class RealizeTargetStateGrainResult:
    wave_id: str
    portfolio_id: str
    plans_processed: int = 0
    plans_skipped_keep_separate: int = 0
    target_systems_upserted: int = 0
    target_capabilities_upserted: int = 0
    capability_lineage_rows_written: int = 0
    system_lineage_rows_written: int = 0
    capability_lineage_rows_skipped: int = 0
    system_lineage_rows_skipped: int = 0
```

### 4.4 Module constants for this activity
- `_AGGREGATE_DISP_TO_SYSTEM_LINEAGE` (dict, 6517) = `{"Consolidate":"consolidate","Rearchitect":"rearchitect-of","Replace":"replace","Retire":"retire"}`. Maps a plan entry's `aggregate_disposition` → the `system_lineage.relationship` enum. **Retain / Refactor / Replatform are absent** → those entries emit NO system_lineage row.
- `_CAP_LINEAGE_RELATIONSHIPS` (frozenset, 6527) = `{"absorbed","partial","transformed","dropped"}` (mirrors DB `capability_lineage_relationship_chk`).
- `_TARGET_CAPABILITY_KINDS` (frozenset, 6534) = `{"derived","net_new"}` ('legacy' is source-side only).
- `_TARGET_SYSTEM_KINDS` (frozenset, 6538) = `{"target","mixed"}`.
- `_CACHED_CONSOLIDATION_PLAN_SCHEMA: dict | None = None` (module global, 6590) — schema cached after first load.

### 4.5 Plan-loading & validation helpers (reproduce fully)

#### `_consolidation_plan_schema_path() -> str | None` (6541)
Locate `capability-consolidation-plan.schema.json`. Candidate dirs in order:
1. `Path(os.environ["OLYMPUS_SCHEMAS_DIR"])` if env set.
2. `Path(__file__).resolve().parents[3] / "schemas"`.
3. `Path("/app/schemas")`.
4. `Path("/app/repo/schemas")`.
For each candidate, test `candidate / "rationalization" / "capability-consolidation-plan.schema.json"`; return `str(.resolve())` of the first that `.is_file()`, else `None`.

#### `_load_consolidation_plan_schema() -> dict` (6568)
Returns cached `_CACHED_CONSOLIDATION_PLAN_SCHEMA` if set. Else resolve path; if `None` → `raise NonRetryableError("capability-consolidation-plan.schema.json not found on this worker — set OLYMPUS_SCHEMAS_DIR or mount the repo schemas directory before invoking realize_target_state_grain.")`. Else `json.load` the file, cache, return. ⚠️ Schema absence is a **deployment bug → NonRetryableError**, not a data condition.

#### `_validate_consolidation_plan(payload: dict) -> None` (6593)
`from jsonschema import Draft202012Validator`; build validator on the loaded schema; `errors = list(validator.iter_errors(payload))`. If empty → return. Else format up to **8** errors as `f"  {err.json_path or '<root>'}: {err.message}"` and `raise NonRetryableError("capability-consolidation-plan.json failed schema validation:\n" + "\n".join(formatted))`.

#### `_read_consolidation_plan_from_disk(artifact_repo_root, artifact_ref) -> dict` (6618)
- Empty `artifact_ref` → `raise NonRetryableError("realize_target_state_grain: consolidation_plan_artifact_ref is empty — cannot read consolidation plan.")`.
- `full = Path(artifact_repo_root)/artifact_ref` if `artifact_repo_root` else `Path(artifact_ref)` (absolute-path unit-test convenience).
- Not `full.is_file()` → `raise NonRetryableError(f"consolidation plan not found at {full!s}. ...")`.
- Read + `json.load`; on `(json.JSONDecodeError, OSError)` → `raise NonRetryableError(f"consolidation plan at {full!s} is not parseable JSON: {exc}")`.

### 4.6 Source-id resolvers (helpers)

#### `_resolve_source_capability_id(conn, *, portfolio_id, source_external_id) -> uuid.UUID | None` (6655)
```sql
SELECT c.id FROM capability c JOIN system s ON s.id = c.system_id
 WHERE s.portfolio_id = $1 AND c.external_id = $2 LIMIT 1
```
Returns `row["id"]` or `None`. (Joins capability→system to scope by portfolio.)

#### `_resolve_source_system_id(conn, *, portfolio_id, source_external_id) -> uuid.UUID | None` (6683)
```sql
SELECT id FROM system WHERE portfolio_id = $1 AND external_id = $2 LIMIT 1
```
Returns `row["id"]` or `None`.

### 4.7 UPSERT helpers (helpers — reproduce SQL exactly)

#### `_upsert_target_system(conn, *, portfolio_id, target_system: dict) -> uuid.UUID` (6704)
Extract: `name = target_system.get("name") or ""`; `description = ... or ""`; `external_id = target_system.get("external_id")`; `kind = target_system.get("kind") or "target"`; if `kind not in _TARGET_SYSTEM_KINDS` → `kind = "target"`.

**Branch A — `external_id` truthy** (idempotent on `(portfolio_id, external_id)`, matching partial unique index `ix_system_portfolio_external_id WHERE external_id IS NOT NULL`):
```sql
INSERT INTO system (portfolio_id, name, description, kind, external_id)
VALUES ($1,$2,$3,$4,$5)
ON CONFLICT (portfolio_id, external_id) WHERE external_id IS NOT NULL
  DO UPDATE SET name=EXCLUDED.name, description=EXCLUDED.description,
                kind=EXCLUDED.kind, updated_at=now()
RETURNING id
```
return `row["id"]`.

**Branch B — no external_id** (natural key `(portfolio_id, name)`, no DB unique index → emulate via SELECT-then-INSERT, race-safe because inside the activity's outer transaction):
```sql
SELECT id FROM system WHERE portfolio_id=$1 AND name=$2 AND external_id IS NULL LIMIT 1
```
- If found → `UPDATE system SET description=$1, kind=$2, updated_at=now() WHERE id=$3`; return existing id.
- Else → `INSERT INTO system (portfolio_id,name,description,kind,external_id) VALUES ($1,$2,$3,$4,NULL) RETURNING id`; return new id.

#### `_upsert_target_capability(conn, *, system_id, target_capability: dict) -> uuid.UUID` (6798)
Extract: `name`, `description` (`or ""`), `external_id`, `kind = target_capability.get("kind") or "derived"`; if `kind not in _TARGET_CAPABILITY_KINDS` → `kind = "derived"`.

**Branch A — external_id truthy** (idempotent on `(system_id, external_id)`, partial unique index `ix_capability_system_external_id`):
```sql
INSERT INTO capability (system_id, name, description, kind, external_id)
VALUES ($1,$2,$3,$4,$5)
ON CONFLICT (system_id, external_id) WHERE external_id IS NOT NULL
  DO UPDATE SET name=EXCLUDED.name, description=EXCLUDED.description,
                kind=EXCLUDED.kind, updated_at=now()
RETURNING id
```

**Branch B — no external_id** (natural key `(system_id, name)`):
```sql
SELECT id FROM capability WHERE system_id=$1 AND name=$2 AND external_id IS NULL LIMIT 1
```
- Found → `UPDATE capability SET description=$1, kind=$2, updated_at=now() WHERE id=$3`; return id.
- Else → `INSERT ... VALUES ($1,$2,$3,$4,NULL) RETURNING id`; return id.

⚠️ Both UPSERTs leave `primary_disposition`/`secondary_disposition` at DB default NULL; `capability.kind` server-default is `'legacy'` but the INSERT always supplies `'derived'`/`'net_new'`.

#### `_upsert_capability_lineage(conn, *, target_capability_id, source_capability_id, relationship, notes, confidence) -> bool` (6881)
- `confidence_decimal = Decimal(str(confidence)).quantize(Decimal("0.01")) if confidence is not None else None`.
- **`target_capability_id is None` (relationship == 'dropped'):** Postgres treats NULL as distinct in UNIQUE, so the `(target,source)` unique constraint won't catch it; emulate via SELECT-then-INSERT at the natural key `(target=NULL, source, relationship='dropped')`:
  ```sql
  SELECT id FROM capability_lineage
   WHERE target_capability_id IS NULL AND source_capability_id=$1 AND relationship='dropped' LIMIT 1
  ```
  - Found → `UPDATE capability_lineage SET notes=$1, confidence=$2, agent_emitted=TRUE WHERE id=$3`; **return False** (UPDATE ≠ insert).
  - Else → `INSERT INTO capability_lineage (target_capability_id, source_capability_id, relationship, notes, confidence, agent_emitted) VALUES (NULL, $1, 'dropped', $2, $3, TRUE)`; **return True**.
- **`target_capability_id` not None:** UPSERT on `(target_capability_id, source_capability_id)` (unique `capability_lineage_target_source_uniq`), using the **`xmax = 0`** INSERT-vs-UPDATE discriminator:
  ```sql
  INSERT INTO capability_lineage (target_capability_id, source_capability_id, relationship, notes, confidence, agent_emitted)
  VALUES ($1,$2,$3,$4,$5,TRUE)
  ON CONFLICT (target_capability_id, source_capability_id)
    DO UPDATE SET relationship=EXCLUDED.relationship, notes=EXCLUDED.notes,
                  confidence=EXCLUDED.confidence, agent_emitted=TRUE
  RETURNING (xmax = 0) AS inserted
  ```
  return `bool(row and row["inserted"])`.
  ⚠️ **GOTCHA — `xmax = 0` trick:** on a true INSERT the row's `xmax` system column is 0; on `ON CONFLICT DO UPDATE` it's non-zero. `RETURNING (xmax = 0)` is the only reliable way to distinguish insert from update for the idempotency counter. Reproduce verbatim — a rebuild that always returns True would over-count `capability_lineage_rows_written`.

#### `_upsert_system_lineage(conn, *, target_system_id, source_system_id, relationship) -> bool` (6974)
```sql
INSERT INTO system_lineage (target_system_id, source_system_id, relationship)
VALUES ($1,$2,$3)
ON CONFLICT (target_system_id, source_system_id) DO UPDATE SET relationship=EXCLUDED.relationship
RETURNING (xmax = 0) AS inserted
```
return `bool(row and row["inserted"])`. (PK is `(target_system_id, source_system_id)` = `system_lineage_pkey`.)

### 4.8 Main activity control flow (reproduce exactly)
1. `exec_id = await emit_code_step_start(input.execution_context, function_name="realize_target_state_grain")`.
2. `portfolio_uuid = uuid.UUID(input.portfolio_id)`; on `(ValueError, TypeError)` → `emit_code_step_complete(exec_id, status=FAILED, error=str(exc))` then `raise NonRetryableError(f"Invalid portfolio_id: {input.portfolio_id!r}")`. ⚠️ Note: **no outer try/except wrapping the rest of this activity** (unlike Activities 1/2). Steps 2–10 each call `emit_code_step_complete(..., FAILED, ...)` immediately before their own raise; there is no broad catch-all.
3. **Load plan (before any DB write):**
   - If `input.consolidation_plan_json` truthy: `plan = json.loads(...)`; on `(JSONDecodeError, ValueError, TypeError)` → `emit_code_step_complete(FAILED)` + `raise NonRetryableError("consolidation_plan_json is not valid JSON: " + str(exc))`.
   - Else: `plan = _read_consolidation_plan_from_disk(input.artifact_repo_root, input.consolidation_plan_artifact_ref)`; wrap in `except NonRetryableError:` → `emit_code_step_complete(FAILED, error="plan read failed")`; `raise`.
4. If `not isinstance(plan, dict)` → `emit_code_step_complete(FAILED, error="plan is not a JSON object")` + `raise NonRetryableError("consolidation plan must be a JSON object")`.
5. **Validate:** `try: _validate_consolidation_plan(plan)` `except NonRetryableError:` → `emit_code_step_complete(FAILED, error="schema validation failed")`; `raise`.
6. `capability_plans = plan.get("capability_plans") or []`. Init eight counters to 0 (`plans_processed`, `plans_skipped_keep_separate`, `target_systems_upserted`, `target_capabilities_upserted`, `capability_lineage_rows_written`, `system_lineage_rows_written`, `capability_lineage_rows_skipped`, `system_lineage_rows_skipped`).
7. **Empty plan** (`not capability_plans`): `emit_code_step_complete(exec_id, columns_written=[])`; `return RealizeTargetStateGrainResult(wave_id=input.wave_id, portfolio_id=input.portfolio_id)` (all counters 0). **Successful no-op run.**
8. `conn = await asyncpg.connect(_db_url())`; `try:` `async with conn.transaction():` **(SINGLE transaction over the whole loop)**:
   For each `entry` in `capability_plans`:
   - `if not isinstance(entry, dict): continue` (silently skip).
   - `pattern = entry.get("consolidation_pattern")`; if `pattern == "keep-separate"` → `plans_skipped_keep_separate += 1; continue`.
   - `target_system_block = entry.get("target_system")`; `target_capability_block = entry.get("target_capability")`. If either is not a dict → log warning `"...skipping plan entry with missing target blocks"` (extra `capability_id`, `pattern`) and `continue`.
   - **Step 1:** `target_system_id = await _upsert_target_system(conn, portfolio_id=portfolio_uuid, target_system=target_system_block)`; `target_systems_upserted += 1`.
   - **Step 2:** `target_capability_id = await _upsert_target_capability(conn, system_id=target_system_id, target_capability=target_capability_block)`; `target_capabilities_upserted += 1`.
   - **Step 3 — capability lineage** from `lineage_rels = target_capability_block.get("lineage_relationships") or []`. For each `rel`:
     - `if not isinstance(rel, dict): capability_lineage_rows_skipped += 1; continue`.
     - `relationship = rel.get("relationship")`; if `relationship not in _CAP_LINEAGE_RELATIONSHIPS` → `skipped += 1; continue`.
     - `source_ext = rel.get("source_capability_external_id")`.
     - If `relationship == "dropped"`: if `not source_ext` → `skipped += 1; continue` (no source row to mark dropped — `source_capability_id` is NOT NULL on the table); set `target_id_for_lineage = None`.
     - Else: if `not source_ext` → `skipped += 1; continue`; set `target_id_for_lineage = target_capability_id`.
     - `source_cap_id = await _resolve_source_capability_id(conn, portfolio_id=portfolio_uuid, source_external_id=source_ext)`. If `None` → log warning `"...source capability external_id not found; skipping lineage row"`; `skipped += 1; continue`.
     - `inserted = await _upsert_capability_lineage(conn, target_capability_id=target_id_for_lineage, source_capability_id=source_cap_id, relationship=relationship, notes=rel.get("notes"), confidence=rel.get("confidence"))`. If `inserted` → `capability_lineage_rows_written += 1`. (UPDATE on existing row → not counted.)
   - **Step 4 — system lineage** from `participating_apps`:
     - `aggregate_disposition = entry.get("aggregate_disposition") or ""`; `sys_lineage_rel = _AGGREGATE_DISP_TO_SYSTEM_LINEAGE.get(aggregate_disposition)`.
     - If `sys_lineage_rel` truthy (i.e. Consolidate/Rearchitect/Replace/Retire): `seen_sources: set[str] = set()`; for each `app` in `entry.get("participating_apps") or []`:
       - `if not isinstance(app, dict): continue`.
       - `src_sys_ext = app.get("source_system_external_id")`; if `not src_sys_ext or src_sys_ext in seen_sources: continue` (dedup per entry).
       - `seen_sources.add(src_sys_ext)`.
       - `src_sys_id = await _resolve_source_system_id(conn, portfolio_id=portfolio_uuid, source_external_id=src_sys_ext)`. If `None` → log warning `"...source system external_id not found; skipping system_lineage"`; `system_lineage_rows_skipped += 1; continue`.
       - If `src_sys_id == target_system_id`: (self-edge meaningless — happens for 'mixed' kind keeping source identity) `system_lineage_rows_skipped += 1; continue`.
       - `inserted_sys = await _upsert_system_lineage(conn, target_system_id=target_system_id, source_system_id=src_sys_id, relationship=sys_lineage_rel)`. If `inserted_sys` → `system_lineage_rows_written += 1`.
     - (If `sys_lineage_rel` is None — Retain/Refactor/Replatform — Step 4 is entirely skipped, no skip-counter increment.)
   - `plans_processed += 1` (end of per-entry processing for non-keep-separate, non-malformed entries).
   `finally: await conn.close()`.
9. Log info `"realize_target_state_grain wrote target-side rows"` with all eight counters + `wave_id`, `portfolio_id`.
10. `await emit_code_step_complete(exec_id, columns_written=["system","capability","capability_lineage","system_lineage"])`.
11. `return RealizeTargetStateGrainResult(...)` with all eight counters + ids echoed.

### 4.9 COMPLETE plan-field → DB-row mapping

**Table `system`** (DDL mig 050). Written by `_upsert_target_system` from `entry.target_system`:
| `system` column | Type | Plan source | Default | Condition |
|---|---|---|---|---|
| `portfolio_id` | UUID FK | `portfolio_uuid` (from `input.portfolio_id`) | — | INSERT |
| `name` | VARCHAR(255) | `target_system.name` | `""` | INSERT / UPDATE-on-conflict (Branch A only updates name) |
| `description` | TEXT | `target_system.description` | `""` | INSERT + UPDATE |
| `kind` | VARCHAR(32) CHECK in (legacy,target,mixed) | `target_system.kind`, coerced to `"target"` if absent/invalid | `"target"` | INSERT + UPDATE |
| `external_id` | VARCHAR(64) | `target_system.external_id` | NULL (Branch B) | only set in Branch A INSERT |
| `updated_at` | TIMESTAMPTZ | `now()` | server-default | UPDATE paths |
| `id`, `created_at`, `retired_at` | — | DB defaults (`gen_random_uuid()`, `now()`, NULL) | — | server-side |

**Table `capability`** (DDL mig 050). Written by `_upsert_target_capability` from `entry.target_capability`:
| `capability` column | Type | Plan source | Default | Condition |
|---|---|---|---|---|
| `system_id` | UUID FK | `target_system_id` (from step 1) | — | INSERT |
| `name` | VARCHAR(255) | `target_capability.name` | `""` | INSERT + UPDATE |
| `description` | TEXT | `target_capability.description` | `""` | INSERT + UPDATE |
| `external_id` | VARCHAR(64) | `target_capability.external_id` | NULL (Branch B) | Branch A INSERT only |
| `kind` | VARCHAR(32) CHECK in (legacy,derived,net_new) | `target_capability.kind`, coerced to `"derived"` if absent/invalid | `"derived"` | INSERT + UPDATE |
| `updated_at` | TIMESTAMPTZ | `now()` | server-default | UPDATE paths |
| `primary_disposition`, `secondary_disposition` | VARCHAR(32) | — | NULL (untouched) | never written here |
| `id`, `created_at`, `retired_at` | — | DB defaults | — | server-side |

**Table `capability_lineage`** (DDL mig 050). Written by `_upsert_capability_lineage`:
| column | Type | Source | Default | Condition |
|---|---|---|---|---|
| `target_capability_id` | UUID FK (nullable) | `target_id_for_lineage` (= `target_capability_id`, or NULL for 'dropped') | — | INSERT |
| `source_capability_id` | UUID FK NOT NULL | resolved `source_cap_id` | — | INSERT |
| `relationship` | VARCHAR(32) CHECK in (absorbed,partial,transformed,dropped) | `rel.relationship` | — | INSERT + UPDATE |
| `notes` | TEXT | `rel.notes` | NULL | INSERT + UPDATE |
| `confidence` | NUMERIC(3,2) CHECK 0..1 | `rel.confidence` → `Decimal(str(c)).quantize(0.01)` | NULL | INSERT + UPDATE |
| `agent_emitted` | BOOL | hard-coded **`TRUE`** | server-default false | always TRUE here |
| `ratified_by`, `ratified_at`, `retired_at` | — | — | NULL | never written |
| `id`, `created_at` | — | DB defaults | — | server-side |
⚠️ CHECK `capability_lineage_target_chk`: `target_capability_id IS NULL` iff `relationship='dropped'`. The control flow guarantees this (target_id_for_lineage is None only for 'dropped').

**Table `system_lineage`** (DDL mig 050). Written by `_upsert_system_lineage`:
| column | Type | Source | Default | Condition |
|---|---|---|---|---|
| `target_system_id` | UUID FK (PK part) | `target_system_id` (step 1) | — | INSERT |
| `source_system_id` | UUID FK (PK part) | resolved `src_sys_id` | — | INSERT |
| `relationship` | VARCHAR(32) CHECK in (consolidate,rearchitect-of,replace,retire) | `_AGGREGATE_DISP_TO_SYSTEM_LINEAGE[aggregate_disposition]` | — | INSERT + UPDATE |
| `created_at`, `retired_at` | — | DB defaults (`now()`, NULL) | — | server-side |

**Tables NEVER written by this activity:** `application`, `application_lineage`, `system_application`, `business_domain`, `business_domain_lineage`, `capability_business_domain`. (`realize_target_state_grain` only touches the four grain tables above.)

### 4.10 Errors / retries / idempotency
- All failures are `NonRetryableError`: invalid portfolio_id, bad JSON, non-object plan, schema-validation failure, missing schema file, missing/unparseable disk plan. Each marks the step FAILED then raises; `@foundry_activity` passes through non-retryable.
- ⚠️ A **bare DB error inside the transaction** (after step 8 starts) is NOT caught locally → the `async with conn.transaction()` rolls back (no partial commit), `conn` closes in `finally`, error propagates out of the activity, `@foundry_activity` wraps it **non-retryable** (asyncpg type name has no retryable token). There is no broad except marking the step FAILED for in-transaction DB errors — so the `step_execution` row stays in `running` state in that case.
- **Idempotent on natural keys:** rerunning with the same plan re-resolves the same systems/capabilities (UPSERTs short-circuit at unique constraints), and the `xmax=0` discriminator means re-run counters return 0 for `*_rows_written` even though rows already exist. Schema validation runs before any write → invalid plan never partial-writes.
- **Transaction atomicity is the central guarantee:** one transaction over all `capability_plans` entries; any raise mid-loop discards every prior UPSERT in this run.

---

# ACTIVITY 5 — `create_target_app_and_repo` (lines 7688/7689–8142)

Provisions the target `application` row + Git repo for one fan-out target (one invocation per non-Retire target from `WaveRationalizationWorkflow.dispatch_architecture`). Branches on disposition. **This is the Git-provisioning + lineage + index-write + source-termination activity.**

### 5.1 Signature & decorator
```python
@foundry_activity(config=ActivityConfig(enable_observability=True))
async def create_target_app_and_repo(
    input: CreateTargetAppAndRepoInput,
) -> CreateTargetAppAndRepoResult:
```

### 5.2 Input dataclass `CreateTargetAppAndRepoInput` (types.py 1870)
```python
@dataclass
class CreateTargetAppAndRepoInput:
    source_app_id: str
    target_app_name: str
    target_repo: str
    wave_id: str
    portfolio_id: str
    disposition: str
    default_branch: str = "main"
    peer_source_app_ids: list[str] = field(default_factory=list)
    source_app_ids: list[str] = field(default_factory=list)   # v2 full source set
    target_service_id: str = ""                                # v2 SF3 catalog id
```

### 5.3 Result dataclass `CreateTargetAppAndRepoResult` (types.py 1920)
```python
@dataclass
class CreateTargetAppAndRepoResult:
    target_app_id: str
    target_repo_url: str
    created_new_app_row: bool = False
    lineage_rows_inserted: int = 0
```

### 5.4 Disposition routing constants
- `_TARGET_EQUALS_SOURCE_DISPOSITIONS` (frozenset, 6498) = `{"Retain","Refactor","Rearchitect","Replatform"}` → `new_target = False` (no new row; self-referential lineage; source row gets its own modernization repo).
- `_NEW_TARGET_DISPOSITIONS` (frozenset, 6503) = `{"Replace","Consolidate"}` → `new_target = True` (mint a fresh `application` row + repo).
- Any other disposition → `raise NonRetryableError("create_target_app_and_repo invoked with unsupported disposition {disposition!r}")`.

### 5.5 `_lineage_relationship_for(disposition) -> str` (7307, helper)
```python
if disposition == "Replace":     return "replace"
if disposition == "Consolidate": return "consolidate"
return f"{disposition.lower()}-of"   # e.g. "refactor-of", "rearchitect-of", "replatform-of", "retain-of"
```
⚠️ This is the `application_lineage.relationship` value (free-form VARCHAR(32), **no CHECK constraint**, mig 030).

### 5.6 `_is_already_exists_error(exc) -> bool` (7673, helper)
```python
message = str(exc).lower()
if "422" in message or "already exists" in message or "name already exists" in message:
    return True
cause = getattr(exc, "__cause__", None)
if cause is not None and getattr(cause, "status", None) == 422:
    return True
return False
```
Detects GitHub 422 ("repo already exists") in both the message and the chained `GithubException.status`.

### 5.7 Control flow (reproduce exactly) — NO `execution_context`/`emit_code_step_*`
1. `source_uuid = uuid.UUID(input.source_app_id)`; on error → `raise NonRetryableError(f"Invalid source_app_id: {input.source_app_id!r}")`.
2. `portfolio_uuid = uuid.UUID(input.portfolio_id) if input.portfolio_id else None`; on error → `raise NonRetryableError(f"Invalid portfolio_id: ...")`.
3. `wave_uuid = uuid.UUID(input.wave_id) if input.wave_id else None`; on error → `wave_uuid = None` (best-effort; the `wave_application` insert is optional).
4. `disposition = input.disposition`. Route: in `_TARGET_EQUALS_SOURCE_DISPOSITIONS` → `new_target = False`; elif in `_NEW_TARGET_DISPOSITIONS` → `new_target = True`; else → `raise NonRetryableError(unsupported)`.
5. **Required `target_repo`:** if `not input.target_repo` → `raise NonRetryableError("create_target_app_and_repo: target_repo is required for disposition {disposition!r} — source {source_app_id!r}")`. (Contract: target modernization repo is ALWAYS a distinct repo, regardless of disposition — source repos stay frozen as Discovery evidence.)
6. **Idempotency probe** (opens a conn, closes in finally):
   - If `portfolio_uuid is not None and input.target_repo`:
     - **new_target:** `SELECT id, target_repo_url FROM application WHERE portfolio_id=$1 AND target_repo_url=$2 LIMIT 1`. If a row exists → log info "target already exists" and `return CreateTargetAppAndRepoResult(target_app_id=str(existing["id"]), target_repo_url=existing["target_repo_url"] or input.target_repo, created_new_app_row=False, lineage_rows_inserted=0)`. **Early return — no repo provisioning, no index write, no termination.**
     - **else (target==source):** `SELECT target_repo_url FROM application WHERE id=$1` (source_uuid). If `existing is not None and existing["target_repo_url"] == input.target_repo` → log info and `return CreateTargetAppAndRepoResult(target_app_id=input.source_app_id, target_repo_url=existing["target_repo_url"], created_new_app_row=False, lineage_rows_inserted=0)`. **Early return.**
7. **Provision the repo** (every disposition): lazy-import GitService:
   - `try: from src.git_service import GitService as _ApiGitService, GitServiceConfig as _ApiGitServiceConfig`; `except ImportError:` try `from olympus_api.services.git_service import ...`; `except ImportError:` set both to `None`.
   - `token = os.environ.get("GITHUB_TOKEN","")`; `base_url = os.environ.get("GITHUB_BASE_URL","https://api.github.com")`.
   - **If GitService available AND token:** build `cfg = _ApiGitServiceConfig(token=token, repo=input.target_repo, base_url=base_url)`; build README string:
     ```
     "# {target_app_name}\n\nOlympus modernization target — disposition: {disposition}.\nSources: {source_app_id}"
     ```
     then if `input.peer_source_app_ids`: `+= ", " + ", ".join(peer_source_app_ids)`; then `+= "\nWave: {wave_id}\n"`.
     - `provisioned_url, _ = _ApiGitService.provision_repository(cfg, repo_slug=input.target_repo, initial_readme=readme, private=True)` (staticmethod; returns `(html_url, created_bool)`, idempotent on slug).
     - `except Exception as exc:` → if `_is_already_exists_error(exc)` → `raise NonRetryableError("Target repository {target_repo!r} already exists and is owned by a different wave or user. Pick a different repo name and retry.")`; **else `raise`** (bubbles up to retry policy; ⚠️ a generic GitServiceError will be wrapped non-retryable unless its type name contains a retryable token).
   - **Else (no token / GitService unavailable):** `provisioned_url = input.target_repo`; log info "GitService unavailable — using slug as repo URL". (Unit-test branch; production always has a token.)
8. **DB writes** (opens conn, `async with conn.transaction():`, closes in finally):
   - **Branch `new_target` (Replace/Consolidate):**
     - `target_uuid = uuid.uuid4()`.
     - **Source-id set resolution:** if `input.source_app_ids` (v2): parse each to UUID (skip+warn invalid); if none parsed → fall back to `[source_uuid]`. Else (v1): `source_ids = [source_uuid]` + parsed `peer_source_app_ids` (skip+warn invalid).
     - `target_service_id = input.target_service_id or None`.
     - INSERT the new application row:
       ```sql
       INSERT INTO application (id, name, portfolio_id, current_line, current_status,
                                target_repo_url, source_app_ids, target_service_id)
       VALUES ($1, $2, $3, NULL, 'onboarded', $4, $5, $6)
       ON CONFLICT (id) DO NOTHING
       ```
       bound `(target_uuid, input.target_app_name, portfolio_uuid, provisioned_url or input.target_repo, source_ids, target_service_id)`. `current_line=NULL`, `current_status='onboarded'`.
     - `created_new = True`.
     - **wave_application bind** (if `wave_uuid is not None`): `INSERT INTO wave_application (wave_id, application_id) VALUES ($1,$2) ON CONFLICT DO NOTHING`.
     - **Lineage edges:** `relationship = _lineage_relationship_for(disposition)`; for each `src` in `source_ids`:
       ```sql
       INSERT INTO application_lineage (target_app_id, source_app_id, relationship, created_at)
       VALUES ($1,$2,$3,$4) ON CONFLICT (target_app_id, source_app_id) DO NOTHING
       ```
       bound `(target_uuid, src, relationship, datetime.now(timezone.utc))`. If `result.endswith(" 1")` → `lineage_inserted += 1`. (⚠️ Reuses the v2-aware `source_ids` so lineage matches `application.source_app_ids` verbatim.)
     - `new_target_result = CreateTargetAppAndRepoResult(target_app_id=str(target_uuid), target_repo_url=provisioned_url or input.target_repo, created_new_app_row=True, lineage_rows_inserted=lineage_inserted)`. **Falls through** (does NOT return inside the transaction) to post-tx index-write + housekeeping.
   - **Branch `not new_target` (Retain/Refactor/Rearchitect/Replatform):**
     - `effective_url = provisioned_url or input.target_repo`.
     - `UPDATE application SET target_repo_url=$2, updated_at=$3 WHERE id=$1` bound `(source_uuid, effective_url, now)`. (Overwrites any stale stub repo with the freshly-minted one.)
     - `relationship = _lineage_relationship_for(disposition)`; self-referential lineage:
       ```sql
       INSERT INTO application_lineage (target_app_id, source_app_id, relationship, created_at)
       VALUES ($1,$2,$3,$4) ON CONFLICT (target_app_id, source_app_id) DO NOTHING
       ```
       bound `(source_uuid, source_uuid, relationship, now)`. `lineage_inserted = 1 if result.endswith(" 1") else 0`.
     - `new_target_result = CreateTargetAppAndRepoResult(target_app_id=input.source_app_id, target_repo_url=effective_url, created_new_app_row=False, lineage_rows_inserted=lineage_inserted)`. **Falls through** to the shared index write.
   - `finally: await conn.close()`.
9. **Commit the target source-artifacts-index** (HARD requirement — runs for BOTH branches):
   - `target_app_id_str = new_target_result.target_app_id`.
   - `anchor_name, peer_pairs, artifact_repo = await _fetch_source_app_names_and_repo(source_app_id=input.source_app_id, peer_source_app_ids=input.peer_source_app_ids, portfolio_uuid=portfolio_uuid)`.
   - `index_payload = _build_source_artifacts_index(target_app_id=target_app_id_str, target_app_name=input.target_app_name, wave_id=input.wave_id, disposition=disposition, anchor_source_app_id=input.source_app_id, anchor_source_app_name=anchor_name, peer_sources=peer_pairs)`.
   - `await _write_target_source_artifacts_index(artifact_repo=artifact_repo, wave_id=input.wave_id, target_app_id=target_app_id_str, index_payload=index_payload)`. ⚠️ **This RAISES on every failure mode** (no artifact_repo / no token / GitService missing / commit fails) — the index is the sole artifact-level link to source Discovery+Rationalization evidence; a silent miss starves downstream lines (the Private Pilot Cert wave incident).
10. **Post-commit housekeeping** (Replace/Consolidate only):
    - If `not new_target:` → `return new_target_result` (target==source dispositions skip termination — the source IS the target).
    - Else build `reason = "source app consolidated into {target_app_id_str}; work transitioned to target"`; build `source_ids_for_cleanup = [input.source_app_id]` + each `peer` in `peer_source_app_ids` not already present.
    - For each `src_id`: `try:` `cancelled = await _cancel_running_source_line_workflows(src_id, reason)`; `status_updated = await _set_application_consolidated_status(src_id)`; log info "source workflows terminated". `except Exception as exc:` → log warning "source termination failed" (housekeeping MUST NOT block — swallowed).
    - `return new_target_result`.

### 5.8 COMPLETE field → DB mapping for Activity 5

**Table `application` — new_target branch INSERT** (existing columns; `id`/`created_at`/`updated_at`/all-other-cols default):
| column | Source | Value |
|---|---|---|
| `id` | `uuid.uuid4()` | new UUID |
| `name` | `input.target_app_name` | — |
| `portfolio_id` | `portfolio_uuid` | — |
| `current_line` | literal | `NULL` |
| `current_status` | literal | `'onboarded'` |
| `target_repo_url` (mig 016) | `provisioned_url or input.target_repo` | — |
| `source_app_ids` (UUID[], mig 030) | resolved `source_ids` (v2 full set or v1 anchor+peers) | non-empty array |
| `target_service_id` (mig 053) | `input.target_service_id or None` | NULL for v1 |
ON CONFLICT (id) DO NOTHING.

**Table `application` — target==source branch UPDATE:**
| column | Source |
|---|---|
| `target_repo_url` | `effective_url` |
| `updated_at` | `now(timezone.utc)` |
WHERE `id = source_uuid`.

**Table `wave_application`** (new_target only, if wave_uuid set): `(wave_id, application_id) = (wave_uuid, target_uuid)`, ON CONFLICT DO NOTHING. (2-col composite PK; no other columns.)

**Table `application_lineage`** (mig 030; PK `(target_app_id, source_app_id)`; ON CONFLICT DO NOTHING):
| column | new_target | target==source |
|---|---|---|
| `target_app_id` | `target_uuid` | `source_uuid` |
| `source_app_id` | each `src` in `source_ids` | `source_uuid` (self-edge) |
| `relationship` | `_lineage_relationship_for(disposition)` ("replace"/"consolidate") | `"{disp}-of"` ("refactor-of"/"rearchitect-of"/"replatform-of"/"retain-of") |
| `created_at` | `now(timezone.utc)` | `now(timezone.utc)` |
(`retired_at` left NULL — DB default.)

### 5.9 Errors / retries / idempotency
- `NonRetryableError`: invalid source_app_id, invalid portfolio_id, unsupported disposition, missing target_repo, repo-already-exists(422), and any failure inside `_write_target_source_artifacts_index` that is `RuntimeError`/`ValueError` (those are NOT WorkflowError → re-wrapped: `ValueError`/`RuntimeError` type names have no retryable token → **non-retryable**).
- Generic repo-provisioning errors (non-422) re-raise raw → `@foundry_activity` wraps (non-retryable unless type name has a retryable token).
- **Idempotency:** (a) new_target short-circuits on existing `(portfolio_id, target_repo_url)` row; (b) target==source short-circuits when source row already carries `target_repo`; (c) `provision_repository` is idempotent on slug; (d) `INSERT ... ON CONFLICT DO NOTHING` on application + wave_application + application_lineage. The index commit re-writes the same content each run (deterministic `json.dumps(sort_keys=True)`).
- ⚠️ **Ordering gotcha:** repo provisioning happens BEFORE the DB transaction; the source-artifacts-index commit happens AFTER the transaction commits (`finally` closes conn first). Housekeeping (workflow cancellation) happens last and is fully best-effort.

### 5.10 source-artifacts-index helpers (reproduce — these define the committed artifact JSON shape)

These constants are resolved **at import time** from the line contracts via `_artifact_filenames_for_steps` (so a producer-output rename flows automatically; drift becomes a worker-startup error, not a runtime 404):

- `_artifact_filenames_for_steps(line_name, step_ids) -> tuple[str,...]` (7344): `from olympus_contracts import get_line`; `line = get_line(line_name)`; for each `step_id`: `step = line.step(step_id)`; `filename = step.artifact_filename`; if falsy and `step.outputs.artifacts` → `filename = step.outputs.artifacts[0].rsplit("/",1)[-1]` (basename); if still falsy → `raise RuntimeError("Line contract drift: {line}.{step!r} declares no artifact filename ...")`. Returns tuple of filenames.
- `_SOURCE_DISCOVERY_STEP_IDS` (7391) = `("catalog","structural-analysis","business-logic-extraction","quality-risk-assessment","ux-accessibility-assessment","data-domain-discovery","shared-database-analysis","synthesis","tco-baseline")` (each carries `# allow: step-list-literal` for the `test_no_hardcoded_step_lists` linter). → `_SOURCE_DISCOVERY_ARTIFACTS = _artifact_filenames_for_steps("Discovery", _SOURCE_DISCOVERY_STEP_IDS)`.
- `_SOURCE_RATIONALIZATION_ARTIFACTS` (7430) = `_artifact_filenames_for_steps("Rationalization", ("disposition-recommendation",))` + `("disposition-recommendation.md",)` + `_artifact_filenames_for_steps("Rationalization", ("classification","portfolio-scoring","intra-app-redundancy","disposition-governance"))`. (The `.md` sidecar is interleaved explicitly — markdown isn't in the yaml outputs.)
- `_WAVE_SHARED_RATIONALIZATION_ARTIFACTS` (7450) = `_artifact_filenames_for_steps("Rationalization", ("cross-app-redundancy","compare-ux-overlap"))`.
- `TARGET_SOURCE_ARTIFACTS_INDEX_SCHEMA_VERSION = "1.0"` (7456).

`_target_source_artifacts_index_path(wave_id, target_app_id)` (7459): returns `f"rationalization/wave-{wave_id}/targets/{target_app_id}/source-artifacts-index.json"`.

`_build_source_artifacts_index(*, target_app_id, target_app_name, wave_id, disposition, anchor_source_app_id, anchor_source_app_name, peer_sources) -> dict` (7472):
- `peer_role = "consolidate-source" if disposition=="Consolidate" else "replace-source" if disposition=="Replace" else f"{disposition.lower()}-source"`.
- Inner `_artifacts_for_source(source_id)` returns `{"discovery": [f"discovery/{source_id}/{name}" for name in _SOURCE_DISCOVERY_ARTIFACTS], "rationalization": [f"rationalization/wave-{wave_id}/{source_id}/{name}" for name in _SOURCE_RATIONALIZATION_ARTIFACTS]}`.
- `sources` = `[{"app_id": anchor_source_app_id, "app_name": anchor_source_app_name, "role": "anchor", "artifacts": _artifacts_for_source(anchor_source_app_id)}]` + one entry per `(peer_id, peer_name)` with `"role": peer_role`.
- Returns:
  ```json
  {"schema_version":"1.0","target_app_id":...,"target_app_name":...,"wave_id":...,
   "disposition":...,"source_apps":[...],
   "shared_artifacts":["rationalization/wave-{wave_id}/{name}" for name in _WAVE_SHARED_RATIONALIZATION_ARTIFACTS]}
  ```

`_fetch_source_app_names_and_repo(*, source_app_id, peer_source_app_ids, portfolio_uuid) -> (anchor_name, [(peer_id,peer_name)...], artifact_repo_url)` (7543):
- Build `ids` list from `source_app_id` + peers (skip unparseable). Open conn:
  - If `ids`: `SELECT id, name FROM application WHERE id = ANY($1::uuid[])` → `id_to_name[str(id)] = name or str(id)`.
  - If `portfolio_uuid is not None`: `SELECT artifact_repo_url FROM portfolio WHERE id=$1` → `artifact_repo = repo_row["artifact_repo_url"] or ""`.
  - `finally: await conn.close()`.
- `anchor_name = id_to_name.get(source_app_id, source_app_id)`; build `peer_pairs` skipping empty/equal-to-anchor; `id_to_name.get(peer_id, peer_id)` for names. Returns `(anchor_name, peer_pairs, artifact_repo)`. (Stub names when row missing — id is authoritative.)

`_write_target_source_artifacts_index(*, artifact_repo, wave_id, target_app_id, index_payload) -> None` (7600):
- `if not artifact_repo: raise ValueError("source-artifacts-index: artifact_repo unavailable for target_app_id=... — portfolio row missing artifact_repo_url")`.
- `token = os.environ.get("GITHUB_TOKEN","")`; `if not token: raise RuntimeError("...GITHUB_TOKEN unset...")`.
- Lazy-import GitService (src → olympus_api fallback); `except ImportError: raise RuntimeError("...GitService unavailable...")`.
- `base_url = os.environ.get("GITHUB_BASE_URL","https://api.github.com")`; `cfg = _GitServiceConfig(token=..., repo=artifact_repo, base_url=...)`; `svc = _GitService(cfg)`.
- `path = _target_source_artifacts_index_path(wave_id, target_app_id)`; `content = json.dumps(index_payload, indent=2, sort_keys=True)`.
- `svc.commit_files(branch="main", files=[(path, content)], commit_message=f"rationalization(wave-{wave_id}): source-artifacts-index for target {target_app_id}")`. Logs info on success.

---

# ACTIVITY 6 — `terminate_source_app_workflows` (lines 8320/8321–8369)

Cancels per-line RUNNING workflows on a source app after Replace/Consolidate and flips its status to `consolidated_into_target`. Two best-effort, idempotent side effects.

### 6.1 Signature & decorator
```python
@foundry_activity(config=ActivityConfig(enable_observability=True))
async def terminate_source_app_workflows(
    input: TerminateSourceAppWorkflowsInput,
) -> TerminateSourceAppWorkflowsResult:
```

### 6.2 Input dataclass `TerminateSourceAppWorkflowsInput` (types.py 1945)
```python
@dataclass
class TerminateSourceAppWorkflowsInput:
    source_app_id: str
    target_app_id: str = ""
    target_app_name: str = ""
    reason: str = ""
```

### 6.3 Result dataclass `TerminateSourceAppWorkflowsResult` (types.py 1975)
```python
@dataclass
class TerminateSourceAppWorkflowsResult:
    source_app_id: str
    cancelled_workflow_ids: list[str] = field(default_factory=list)
    status_updated: bool = False
```

### 6.4 Constants
- `_SOURCE_LINE_SLUGS` (tuple, 8156) = `("architecture","data","modernization","validation","deployment")`. (Discovery + Rationalization deliberately EXCLUDED — they produced the disposition decision and are already complete.)
- `_CONSOLIDATED_STATUS = "consolidated_into_target"` (8164).

### 6.5 Control flow
```python
reason = input.reason or (
    f"source app consolidated into {input.target_app_id}; work transitioned"
    if input.target_app_id
    else "source app consolidated; work transitioned"
)
cancelled = await _cancel_running_source_line_workflows(input.source_app_id, reason)
status_updated = await _set_application_consolidated_status(input.source_app_id)
return TerminateSourceAppWorkflowsResult(
    source_app_id=input.source_app_id,
    cancelled_workflow_ids=cancelled,
    status_updated=status_updated,
)
```
No `execution_context`, no `emit_code_step_*`, no raise (everything inside helpers is swallowed).

### 6.6 `_cancel_running_source_line_workflows(source_app_id, reason) -> list[str]` (8167, helper)
1. `if not source_app_id: return []`.
2. `try: client = await Client.connect(_temporal_host(), namespace=_temporal_namespace())` `except Exception:` log warning, `return []`.
3. `workflow_types = ("ArchitectureWorkflow","DataWorkflow","ModernizationWorkflow","ValidationWorkflow","DeploymentWorkflow")`; `workflow_types_clause = ", ".join(f"'{wt}'" for wt in ...)`.
4. `query = f"WorkflowType IN ({workflow_types_clause}) AND ExecutionStatus = 'Running'"` (Temporal Visibility list query / SQL-like).
5. `acceptable_prefixes = tuple(f"{slug}-{source_app_id}" for slug in _SOURCE_LINE_SLUGS)` (5 prefixes).
6. `attempted: list[str] = []`; `try: async for desc in client.list_workflows(query=query):`
   - `wf_id = getattr(desc, "id", "") or ""`; `if not wf_id: continue`.
   - `if not wf_id.startswith(acceptable_prefixes): continue` (client-side id-prefix filter; `str.startswith(tuple)` matches any).
   - `handle = client.get_workflow_handle(wf_id)`; `try: await handle.cancel(); attempted.append(wf_id); log info "cancelled workflow"`; `except Exception as exc: attempted.append(wf_id); log info "cancel no-op (likely already terminal)"` (still appended — idempotent).
   - `except Exception as exc:` (around the `async for`) → log warning "list_workflows failed", `return attempted`.
7. `return attempted`.

⚠️ **GOTCHA — id-prefix scan, not search-attribute filter.** Visibility query filters by `WorkflowType` + `Running`; the `source_app_id` match is done CLIENT-SIDE via `wf_id.startswith(("architecture-{id}", "data-{id}", ...))`. The workflow-id convention `{line_slug}-{app_id}-{run_ts}` (from `start_next_line_workflow`/`wave_rationalization`) is what makes this work. A search-attribute filter would need a Temporal schema migration; the id-prefix scan avoids that. Returns the ids it **attempted** to cancel (including ones already terminal), never raises.

### 6.7 `_set_application_consolidated_status(source_app_id) -> bool` (8268, helper)
1. `app_uuid = uuid.UUID(source_app_id)`; on `(ValueError, TypeError)` → log warning "invalid source_app_id", `return False`.
2. `conn = None`; `try: conn = await asyncpg.connect(_db_url())`:
   ```sql
   UPDATE application SET current_status = $1, updated_at = $2 WHERE id = $3
   ```
   bound `(_CONSOLIDATED_STATUS, datetime.now(timezone.utc), app_uuid)`.
3. Parse command tag: if `result` is `str` starting `"UPDATE "` → `count = int(result.split(" ",1)[1])`; `return count >= 1` (on `(IndexError, ValueError)` → `return False`). Non-matching tag → `return False`.
4. `except Exception as exc:` → log warning "DB update failed", `return False`. `finally: if conn is not None: await conn.close()`.

**Table `application` mapping:** `current_status = "consolidated_into_target"`, `updated_at = now()`, WHERE `id = source_app_id`. Idempotent (unconditional UPDATE; re-run rewrites same value).

### 6.8 Errors / retries / idempotency
- **Never raises** — both helpers swallow all errors and return empty/False. The activity always returns a `TerminateSourceAppWorkflowsResult` (the `@foundry_activity` error-wrapping path is effectively never exercised by normal operation here).
- Idempotent: cancelling an already-terminal workflow is a no-op (still recorded as attempted); the status UPDATE is unconditional.
- Safe but pointless on non-Consolidate/Replace paths (target==source there) — `create_target_app_and_repo` only invokes the equivalent housekeeping for `_NEW_TARGET_DISPOSITIONS`.

---

## APPENDIX A — Cross-cutting GOTCHA index

1. **`_build_update_sql` parameter ordering** is `_SIDE_EFFECT_COLUMNS` tuple order, not dict order. `updated_at` is always last assignment; app id is the final `$N`. (§0.8)
2. **`@foundry_activity` classifies bare `asyncpg`/`OSError`/`ValueError`/`RuntimeError` as NON-retryable** (their `str(type(...))` lacks retryable tokens). The `persist_*` activities therefore swallow DB errors in-body where they want best-effort. (§0.1)
3. **Activity 1 vs Activity 2 DB-error divergence:** Deployment re-raises DB errors (workflow tolerates); Disposition swallows them and returns a benign empty result. (§1.5 vs §2.6)
4. **`xmax = 0` RETURNING discriminator** in both lineage UPSERTs distinguishes INSERT from UPDATE to keep `*_rows_written` counters honest. (§4.7)
5. **`realize_target_state_grain` is a single transaction with no in-tx error catch** — an in-loop DB error rolls back the whole run and leaves the `step_execution` row in `running`. Validation precedes all writes. (§4.10)
6. **Two-stage line-slug transform** in `update_application_line_projection`: spaces→hyphens then hyphens→underscores; `current_line` stores the raw enum label. (§3.5)
7. **`create_target_app_and_repo` ordering:** repo provision → DB transaction → (after close) index commit (RAISES on any failure) → best-effort housekeeping. The index write being a hard failure is deliberate (Private Pilot Cert incident). (§5.7, §5.9)
8. **`_cancel_running_source_line_workflows` filters by client-side id prefix**, not a Temporal search attribute. Returns attempted ids, never raises. (§6.6)
9. **`emit_code_step_*` are no-ops when `execution_context is None`** — observability never affects activity outcome. (§0.6)
10. **`disposition` Retain correction**: envelope-sourced `plan_approved` is bumped to `disposition_complete` for Retain when the workflow supplied no explicit status (Retain has no G-DE-2). (§2.7)
11. **Cost-savings type mismatch:** Disposition extractor binds `cost_savings_annual_usd` as `float`; Deployment binds `cost_savings_realized_usd`/`license_reclamation_usd` as `Decimal(str(round(x,2)))`. Both land in NUMERIC(12,2). (§1.6, §2.7)

## APPENDIX B — DDL reference (tables this group writes)

- `application` deployment columns: **migration 036** — `deployed_at` TIMESTAMPTZ, `deployment_env` VARCHAR(64), `cutover_strategy` VARCHAR(32), `parallel_run_duration_days` INTEGER, `cost_savings_realized_usd` NUMERIC(12,2), `license_reclamation_usd` NUMERIC(12,2), `legacy_decommissioned_at` TIMESTAMPTZ, `deployment_current_status` VARCHAR(64). All nullable.
- `application` disposition columns: **migration 034** — `disposition_output_ref` TEXT, `disposition_completed_at` TIMESTAMPTZ, `disposition_current_status` VARCHAR(64), `cost_savings_annual_usd` NUMERIC(12,2). All nullable.
- `application` core/projection columns used: `current_line` (`assembly_line_enum`), `current_step` VARCHAR(100), `current_status` VARCHAR(50), `workflow_id` (mig 010), `target_repo_url` (mig 016), `source_app_ids` UUID[] (mig 030), `target_service_id` VARCHAR(64) (mig 053), `updated_at` TIMESTAMPTZ (mig 002).
- `application_lineage`: **migration 030** — PK `(target_app_id, source_app_id)`, `relationship` VARCHAR(32) (NO check constraint), `created_at` TIMESTAMPTZ NOT NULL DEFAULT NOW(), `retired_at` TIMESTAMPTZ NULL. FKs to `application.id` ON DELETE CASCADE.
- `wave_application`: **migration 002** — composite PK `(wave_id, application_id)`, FKs ON DELETE CASCADE, no other columns.
- `system`, `capability`, `capability_lineage`, `system_lineage`: **migration 050** (full DDL incl. CHECK constraints `system_kind_chk`, `capability_kind_chk`, `capability_lineage_relationship_chk`, `capability_lineage_target_chk`, `capability_lineage_confidence_chk`, `system_lineage_relationship_chk`; partial unique indexes `ix_system_portfolio_external_id`, `ix_capability_system_external_id`; unique `capability_lineage_target_source_uniq`).
- `step_execution`: **migration 033** — written indirectly via `emit_code_step_*`/`emit_execution_record`/`update_execution_record` in `utils/execution.py`. (§0.6)

## APPENDIX C — GitService interface contract (consumed by Activity 5 + index helper)

`GitServiceConfig(token, repo, base_url)`. `GitService(cfg)` instance. `GitServiceError` is the typed error.
- **`GitService.provision_repository(config, repo_slug, initial_readme="", private=True) -> tuple[str, bool]`** — STATICMETHOD. Idempotent on slug (returns existing `(html_url, False)` if repo exists). Requires `repo_slug == "owner/name"` (else `GitServiceError`). Raises `GitServiceError` on GitHub failures; a "name already exists" 422 is what `_is_already_exists_error` detects → `create_target_app_and_repo` re-raises as `NonRetryableError`.
- **`svc.commit_files(branch, files: list[(path, content)], commit_message) -> CommitResult`** — INSTANCE method. Single batched commit (blob+tree+commit walk). Creates branch from `main` if `branch != "main"`. Raises `GitServiceError` on empty file list or GithubException.
