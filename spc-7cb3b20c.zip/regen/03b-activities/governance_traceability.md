# Activity Group Spec — Governance Operations & Traceability

ATOMIC regeneration spec. Behavioral-parity bar: an engineer with no access to the
original code must rebuild each activity so it behaves IDENTICALLY.

Source files (reproduce both verbatim-equivalent):

- `temporal/olympus_workflows/activities/governance_operations.py` — governance
  propagation enumeration (F5 compound-growth flywheel).
- `temporal/olympus_workflows/activities/traceability.py` — citation indexing &
  gate traceability validation (both currently STUBS).

**Activities reproduced: 3**

1. `list_active_modernization_workflows`  (governance_operations.py:51-117)
2. `index_artifact_citations`             (traceability.py:56-73)
3. `validate_gate_traceability`           (traceability.py:76-94)

**persist_*/projection functions in scope: 0.** Neither file performs ANY database
write, SQL, UPSERT, or row projection. `governance_operations.py` does Temporal
Visibility API I/O only; both `traceability.py` activities are explicit
return-a-stub functions with NO side effects. There is therefore no
artifact-field → table.column mapping table in this group — by design, not by
omission. (Confirmed by `grep` for `sql|asyncpg|psycopg|execute|INSERT|UPDATE|conn|pool|db|http`
across both files: only matches are inside docstrings/comments. See "Negative
findings" at the end.)

---

## 0. The `@foundry_activity` decorator — captured once, applies to ALL 3 activities

Both files import and decorate every activity with:

```python
from foundry_temporal.activities import ActivityConfig, foundry_activity
...
@foundry_activity(config=ActivityConfig(enable_observability=True))
```

A rebuild that uses plain `@activity.defn` is WRONG: it loses observability logging
AND the error-wrapping/retryability classification described below. You MUST
reproduce the wrapper.

### 0.1 `ActivityConfig` dataclass
(`foundry_temporal/activities.py:27-39`) — fields & defaults:

| field | type | default |
|---|---|---|
| `retry_policy` | `RetryPolicy | None` | `None` |
| `start_to_close_timeout` | `timedelta | None` | `None` |
| `schedule_to_close_timeout` | `timedelta | None` | `None` |
| `schedule_to_start_timeout` | `timedelta | None` | `None` |
| `heartbeat_timeout` | `timedelta | None` | `None` |
| `enable_observability` | `bool` | `True` |
| `enable_error_wrapping` | `bool` | `True` |
| `log_inputs` | `bool` | `False` |
| `log_outputs` | `bool` | `False` |

⚠️ All 3 activities here pass only `enable_observability=True` (which is already the
default). They rely on the OTHER defaults: `enable_error_wrapping=True`,
`log_inputs=False`, `log_outputs=False`. The `retry_policy`/timeout fields on
`ActivityConfig` are **never applied by the wrapper** — they are config holders only;
the effective retry/timeout for an activity is whatever the *workflow* passes at the
`execute_activity` call site (see §1.6). So the `ActivityConfig` timeouts/retry here
are inert.

### 0.2 `foundry_activity(config, name=None, **activity_kwargs)` behavior
(`foundry_temporal/activities.py:107-165`)

It is a decorator factory returning `decorator(func)`. `decorator`:

1. `activity_config = config or ActivityConfig()`.
2. Wraps `func` with an inner `async def wrapper(*args, **kwargs)`, applying BOTH
   `@activity.defn(name=name, **activity_kwargs)` (outermost) and `@wraps(func)`.
   - `name` is `None` for all 3 here ⇒ Temporal activity name = the function's
     `__name__` (`"list_active_modernization_workflows"`,
     `"index_artifact_citations"`, `"validate_gate_traceability"`).
3. Inside `wrapper`:
   - `activity_name = name or func.__name__`.
   - `activity_logger = get_logger()` (from `foundry_temporal.logging`).
   - If `enable_observability`: `activity_logger.info(f"Activity {activity_name} starting", extra={"inputs": args if log_inputs else None})`.
     Since `log_inputs=False`, `extra={"inputs": None}`.
   - `result = await func(*args, **kwargs)` (the real body).
   - If `enable_observability`: `activity_logger.info(f"Activity {activity_name} completed", extra={"outputs": result if log_outputs else None})`. `log_outputs=False` ⇒ `extra={"outputs": None}`.
   - `return result`.
4. **Exception path** (`except Exception as error:`):
   - If `enable_observability`: `activity_logger.error(f"Activity {activity_name} failed: {error}", extra={"error": str(error)})`.
   - If `enable_error_wrapping` (True here):
     - If `isinstance(error, (WorkflowError, ApplicationError))` → bare `raise`
       (preserve original; do NOT re-wrap). `WorkflowError`/`RetryableError`/
       `NonRetryableError` (from `foundry_temporal.errors`) all subclass
       `temporalio.exceptions.ApplicationError`, so any already-typed error passes
       through unchanged with its `non_retryable` flag intact.
     - `elif _is_retryable_error(error)` → `raise RetryableError(f"Retryable error in {activity_name}: {error}") from error`.
     - `else` → `raise NonRetryableError(f"Non-retryable error in {activity_name}: {error}") from error`.
   - else (`enable_error_wrapping=False`, not the case here): bare `raise`.

⚠️ CRITICAL for THIS group: **None of the 3 activities can actually reach the
wrapper's exception path under normal operation.** Each catches its own exceptions
internally and returns a value. So in practice the wrapper's error-classification
branch is dormant for all 3 — but you MUST still reproduce the wrapper because (a)
unexpected/programming errors (e.g. a bug, an `ImportError`) WOULD hit it, and (b)
behavioral parity requires the wrapper to exist.

### 0.3 `_is_retryable_error` — the WRAPPER's classifier (string-based)
(`foundry_temporal/activities.py:168-183`)

⚠️ This is a DIFFERENT, cruder function than `errors.is_retryable_error`. The wrapper
uses THIS one:

```python
def _is_retryable_error(error: Exception) -> bool:
    error_str = str(type(error)).lower()
    retryable_patterns = ["timeout","connection","network","temporary",
        "unavailable","overload","busy","throttle","rate_limit"]
    return any(pattern in error_str for pattern in retryable_patterns)
```

It inspects `str(type(error)).lower()` (the class repr, e.g.
`"<class 'concurrenterror.timeouterror'>"`) — NOT the message, NOT isinstance. So an
exception whose **class name/module** contains any pattern substring → wrapped as
`RetryableError`; otherwise → `NonRetryableError`. (Note: `errors.is_retryable_error`
at `foundry_temporal/errors.py` is the richer httpx/ConnectionError/OSError-aware
classifier, but the `foundry_activity` wrapper does NOT call it. Don't conflate them.)

### 0.4 Error classes (`foundry_temporal/errors.py`)
- `WorkflowError(ApplicationError)`: `__init__(message, non_retryable=True)`.
- `RetryableError(WorkflowError)`: `__init__(message)` → `super().__init__(message, non_retryable=False)`.
- `NonRetryableError(WorkflowError)`: `__init__(message)` → `super().__init__(message, non_retryable=True)`.

`non_retryable=True` makes Temporal stop retrying immediately regardless of the
workflow's `RetryPolicy.maximum_attempts`.

---

## 1. `list_active_modernization_workflows`
File/lines: `governance_operations.py:51-117`.

### 1.1 Signature
```python
@foundry_activity(config=ActivityConfig(enable_observability=True))
async def list_active_modernization_workflows(
    input: ListActiveModernizationWorkflowsInput,
) -> ListActiveModernizationWorkflowsResult: ...
```
Temporal activity name: `"list_active_modernization_workflows"`.

### 1.2 Input type — `ListActiveModernizationWorkflowsInput`
(`temporal/olympus_workflows/types.py:2652-2663`) — `@dataclass`, EVERY field:

| field | type | default | notes |
|---|---|---|---|
| `portfolio_id` | `str` | (required, no default) | only field |

### 1.3 Output type — `ListActiveModernizationWorkflowsResult`
(`types.py:2666-2677`) — `@dataclass`, EVERY field:

| field | type | default |
|---|---|---|
| `workflow_ids` | `list[str]` | `field(default_factory=list)` |

⚠️ `field` is `dataclasses.field` (imported at `types.py:23`:
`from dataclasses import dataclass, field`). The `default_factory=list` MUST be used
(not `= []`) to avoid the shared-mutable-default trap. Rebuild with
`field(default_factory=list)`.

### 1.4 Module-level helpers (reproduce exactly)
(`governance_operations.py:43-48`)
```python
def _temporal_host() -> str:
    return os.environ.get("TEMPORAL_HOST", "temporal:7233")

def _temporal_namespace() -> str:
    return os.environ.get("TEMPORAL_NAMESPACE", "default")
```
Env-var driven; defaults `"temporal:7233"` and `"default"`. Read at call time
(every invocation), not import time.

### 1.5 EXACT control flow (behavioral parity — reproduce branch-for-branch)

The whole function is **best-effort**: every failure path returns a
`ListActiveModernizationWorkflowsResult` (possibly partial/empty), NEVER raises.

1. `portfolio_id = (input.portfolio_id or "").strip()`.
   - ⚠️ Handles `None`/empty/whitespace. `(input.portfolio_id or "")` coerces a
     falsy/`None` portfolio to `""` BEFORE `.strip()`.
2. **Guard:** `if not portfolio_id:` → `return ListActiveModernizationWorkflowsResult(workflow_ids=[])`.
   Empty/whitespace portfolio short-circuits to empty result; NO Temporal connection
   attempted.
3. **Connect:**
   ```python
   try:
       client = await Client.connect(_temporal_host(), namespace=_temporal_namespace())
   except Exception as exc:  # noqa: BLE001 — best-effort fallback
       logger.warning("governance propagation: failed to connect to Temporal: %s",
                      exc, extra={"portfolio_id": portfolio_id})
       return ListActiveModernizationWorkflowsResult(workflow_ids=[])
   ```
   `Client` is `temporalio.client.Client`. ⚠️ Catches **bare `Exception`** — ANY
   connect failure → log WARNING + return empty list. The activity opens its OWN
   Temporal client connection (it does NOT reuse the worker's client). `module-level
   logger = logging.getLogger(__name__)` is used here (NOT the foundry `get_logger`;
   that one is used by the wrapper).
4. **Build query (literal string):**
   ```python
   query = ("WorkflowType = 'ModernizationWorkflow' "
            "AND ExecutionStatus = 'Running'")
   ```
   ⚠️ EXACT visibility-list filter. WorkflowType literally `'ModernizationWorkflow'`,
   ExecutionStatus literally `'Running'`. Note the trailing space after
   `...Workflow' ` so the concatenation yields a single space between the clauses
   (`"...'ModernizationWorkflow' AND ExecutionStatus = 'Running'"`). Reproduce the
   string byte-for-byte.
5. **Iterate visibility results:**
   ```python
   matched: list[str] = []
   try:
       async for desc in client.list_workflows(query=query):
           wf_id = getattr(desc, "id", "") or ""
           if wf_id:
               matched.append(wf_id)
   except Exception as exc:  # noqa: BLE001 — best-effort fallback
       logger.warning("governance propagation: list_workflows failed: %s",
                      exc, extra={"portfolio_id": portfolio_id})
       return ListActiveModernizationWorkflowsResult(workflow_ids=matched)
   ```
   - `client.list_workflows(query=query)` returns an async iterator of
     `WorkflowExecutionDescription`-like objects. For each:
     - `wf_id = getattr(desc, "id", "") or ""` — defensively read `.id`, default `""`
       if attribute missing, then `or ""` coerces a falsy/`None` id to `""`.
     - `if wf_id:` append the (non-empty) id to `matched`.
   - ⚠️ **Partial-failure semantics:** if iteration raises PART-WAY through, the
     `except` returns the IDs collected SO FAR (`matched`), NOT an empty list. (Contrast
     the connect failure which returns `[]`.) Reproduce this distinction exactly.
6. **Success:**
   ```python
   logger.info("governance propagation: found %d active Modernization workflows",
               len(matched), extra={"portfolio_id": portfolio_id})
   return ListActiveModernizationWorkflowsResult(workflow_ids=matched)
   ```

### 1.6 Reads / writes (JSON shapes)
- **Reads:** only `input.portfolio_id` (in-process dataclass field). Reads env vars
  `TEMPORAL_HOST`, `TEMPORAL_NAMESPACE`. Reads Temporal Visibility store via
  `list_workflows` (external I/O, not a DB/JSON artifact). Reads each `desc.id`.
- **Writes:** NOTHING persistent. No DB row, no Git artifact, no file. Output is a
  pure return value. The serialized result shape Temporal records:
  `{"workflow_ids": ["<wf-id>", ...]}` (may be `{"workflow_ids": []}`).

### 1.7 Semantic note — portfolio filter is INTENTIONALLY not applied
⚠️ MAJOR GOTCHA / not-a-bug. Despite the docstrings (and the
`ListActiveModernizationWorkflowsInput` docstring claiming enumeration is "scoped by
the portfolio_id"), the activity body **does NOT filter by portfolio**. It returns
EVERY running `ModernizationWorkflow` in the namespace. The inline comment at
`governance_operations.py:90-98` explains why: current workflow-ID conventions
(`AppWorkflow`, `line_transitions.start_next_line_workflow`) embed `app_id` but NOT
`portfolio_id`, and no search attribute indexes portfolio, so visibility-level
portfolio filtering "isn't feasible without a search attribute." Per-portfolio
filtering is deferred to the signal consumer. `portfolio_id` is used ONLY for the
empty-guard (step 2) and as `extra={}` log context (steps 3,5,6) — it does NOT affect
which workflow IDs are returned. A rebuild that adds a portfolio filter to the query
or client-side filtering would NOT be behaviorally identical.

### 1.8 Error handling / retries / idempotency
- **Internal:** two bare-`Exception` catches (connect; iterate) both downgrade to a
  returned result. The function NEVER raises under I/O failure ⇒ the
  `@foundry_activity` wrapper's exception branch is effectively unreachable here. The
  only way to reach the wrapper's `except` is a non-I/O programming error (e.g. an
  `ImportError`, a bug constructing the result) — which would be classified by the
  string-based `_is_retryable_error` (§0.3): class repr contains none of the patterns
  ⇒ `NonRetryableError`.
- **Retries:** Because the activity returns successfully (empty list) on failure,
  Temporal sees SUCCESS and never retries on the failure paths. Retry only matters if
  the wrapper raises (programming error). The **call-site retry policy** (NOT on the
  activity) — see §1.9.
- **Idempotency:** Pure read; idempotent. Re-running yields the same (or freshly
  current) set of running workflow IDs. No state mutated. Safe to retry/re-run.

### 1.9 Call site (integration context — reproduce for parity of behavior)
Caller: `GovernanceWorkflow._propagate_patterns`
(`temporal/olympus_workflows/workflows/governance.py:480-551`), step 8
(`PROPAGATE_PATTERNS_STEP`, F5 flywheel). The workflow invokes:
```python
result = await workflow.execute_activity(
    list_active_modernization_workflows,
    ListActiveModernizationWorkflowsInput(portfolio_id=input.portfolio_id),
    start_to_close_timeout=timedelta(seconds=60),
    retry_policy=RETRY_POLICIES["transient"],
    activity_id=f"governance-list-modernization-{input.portfolio_id}-{self._schedule_id}",
)
```
- `start_to_close_timeout=60s`.
- `retry_policy=RETRY_POLICIES["transient"]` = `TRANSIENT_RETRY_POLICY` =
  foundry `HTTP_RETRY_POLICY` (`retry_policies.py:33`, `worker` foundry pkg):
  `initial_interval=1s, maximum_interval=15s, maximum_attempts=3, backoff_coefficient=2.0`,
  no `non_retryable_error_types`.
- Deterministic `activity_id` for dedupe within the sweep.
- ⚠️ The workflow ALSO wraps the `execute_activity` call in its own
  `try/except Exception` (governance.py:514-520): on activity failure it logs a
  warning and `return`s from `_propagate_patterns` (skips propagation) — yet another
  best-effort layer. Then `workflow_ids = list(result.workflow_ids or [])`; if empty,
  `return`. Non-empty IDs are each signaled `"wave_patterns_ready"` with
  `WavePatternsReadySignal(wave_id=f"governance-sweep-{self._schedule_id}", patterns=bundle)`
  via `workflow.get_external_workflow_handle(wf_id).signal(...)`, each in its own
  swallow-exception loop (governance.py:535-551). (This signal dispatch is a WORKFLOW
  concern — kept out of the activity to preserve determinism. Document but do not
  re-implement inside the activity.)

### 1.10 Worker registration
Registered in `temporal/olympus_workflows/worker.py` — imported at lines 77-78
(`from ...governance_operations import list_active_modernization_workflows`) and added
to the activities list at line 212. So this activity IS wired into the worker. Rebuild
MUST register it.

---

## 2. `index_artifact_citations`  (STUB)
File/lines: `traceability.py:56-73`.

### 2.1 Signature
```python
@foundry_activity(config=ActivityConfig(enable_observability=True))
async def index_artifact_citations(input: IndexCitationsInput) -> IndexCitationsResult: ...
```
Temporal activity name: `"index_artifact_citations"`.

### 2.2 Input type — `IndexCitationsInput`
(`traceability.py:14-22`) — `@dataclass` defined IN THE SAME FILE (not in
`types.py`). EVERY field, in order:

| field | type | default |
|---|---|---|
| `app_id` | `str` | (required) |
| `source_artifact` | `str` | (required) |
| `artifact_text` | `str` | (required) |
| `source_version` | `str | None` | `None` |
| `produced_by` | `dict | None` | `None` |

### 2.3 Output type — `IndexCitationsResult`
(`traceability.py:25-32`) — `@dataclass`, EVERY field:

| field | type | default |
|---|---|---|
| `app_id` | `str` | (required) |
| `source_artifact` | `str` | (required) |
| `citations_found` | `int` | (required) |
| `citations_indexed` | `int` | (required) |

### 2.4 EXACT body — IT IS A STUB (reproduce literally)
```python
return IndexCitationsResult(
    app_id=input.app_id,
    source_artifact=input.source_artifact,
    citations_found=0,
    citations_indexed=0,
)
```
- ⚠️ It does NOT parse `input.artifact_text`, does NOT touch the DB, does NOT call
  any traceability service. `input.artifact_text`, `input.source_version`,
  `input.produced_by` are accepted but **ignored**. `citations_found` and
  `citations_indexed` are HARD-CODED to `0` regardless of content.
- The docstring (traceability.py:64-67) documents the INTENDED production behavior
  ("1. Call `parse_citations(...)` 2. Call `index_citations(db, ...)`") but this is
  NOT implemented. For behavioral parity you reproduce the STUB: always returns
  `app_id`/`source_artifact` echoed back with both counts `0`. Do NOT implement
  citation parsing — that would break parity.

### 2.5 Reads / writes
- **Reads:** `input.app_id`, `input.source_artifact` only (the other 3 fields
  ignored).
- **Writes:** NOTHING. No DB, no file, no Git. Pure return.
- Output JSON shape:
  `{"app_id": "<echo>", "source_artifact": "<echo>", "citations_found": 0, "citations_indexed": 0}`.

### 2.6 Error handling / retries / idempotency
- The body cannot raise (pure construction). The `@foundry_activity` wrapper's error
  branch is unreachable in practice. No retries triggered (always succeeds).
- Idempotent (no side effects); trivially safe to re-run.

---

## 3. `validate_gate_traceability`  (STUB)
File/lines: `traceability.py:76-94`.

### 3.1 Signature
```python
@foundry_activity(config=ActivityConfig(enable_observability=True))
async def validate_gate_traceability(input: ValidateTraceabilityInput) -> ValidateTraceabilityResult: ...
```
Temporal activity name: `"validate_gate_traceability"`.

### 3.2 Input type — `ValidateTraceabilityInput`
(`traceability.py:35-41`) — `@dataclass`, EVERY field:

| field | type | default |
|---|---|---|
| `app_id` | `str` | (required) |
| `gate_type` | `str` | (required) |
| `risk_tier` | `str | None` | `None` |

### 3.3 Output type — `ValidateTraceabilityResult`
(`traceability.py:44-54`) — `@dataclass`, EVERY field:

| field | type | default |
|---|---|---|
| `app_id` | `str` | (required) |
| `gate_type` | `str` | (required) |
| `coverage_pct` | `float` | (required) |
| `threshold_pct` | `float` | (required) |
| `passed` | `bool` | (required) |
| `detail` | `str` | (required) |

### 3.4 EXACT body — IT IS A STUB (reproduce literally)
```python
return ValidateTraceabilityResult(
    app_id=input.app_id,
    gate_type=input.gate_type,
    coverage_pct=100.0,
    threshold_pct=90.0,
    passed=True,
    detail=f"Traceability validation passed for {input.gate_type}",
)
```
- ⚠️ HARD-CODED pass: `coverage_pct=100.0`, `threshold_pct=90.0`, `passed=True`. NO
  query of any traceability service. `input.risk_tier` is accepted but IGNORED (does
  NOT influence threshold). `detail` is an f-string interpolating `input.gate_type`
  into `"Traceability validation passed for {gate_type}"`.
- Docstring (traceability.py:85-86): "Stub: pass by default so workflows aren't
  blocked." Reproduce the always-pass behavior; do NOT add real coverage logic.

### 3.5 Reads / writes
- **Reads:** `input.app_id`, `input.gate_type` only (`risk_tier` ignored).
- **Writes:** NOTHING. Pure return.
- Output JSON shape (literal values constant except echoed app_id/gate_type):
  `{"app_id":"<echo>","gate_type":"<echo>","coverage_pct":100.0,"threshold_pct":90.0,"passed":true,"detail":"Traceability validation passed for <gate_type>"}`.

### 3.6 Error handling / retries / idempotency
- Cannot raise (pure construction). Wrapper error branch unreachable in practice.
  Always succeeds ⇒ no retries. Idempotent, no side effects.

---

## 4. Negative findings & undetermined items (read before rebuilding)

- **No persist_* / projection / DB logic in this group.** Both files are I/O-thin:
  `governance_operations.py` = Temporal Visibility read only; `traceability.py` = two
  pure stubs. There is intentionally NO column-mapping table. (The data-layer
  projection logic lives in OTHER activity files, e.g.
  `persist_governance_sweep_side_effects` — referenced in `worker.py:205` but NOT in
  these two source files; out of this group's scope.)
- **Git activities:** none in this group (no branch/commit/PR/merge). `GIT_MERGE_RETRY_POLICY`
  in `retry_policies.py` is documented for context only; not used by these activities.
- **Agent-dispatch activities:** none in this group (no skill selection / agent
  runtime calls).
- ⚠️ **The two traceability activities are DEFINED BUT UNWIRED.** Verified by grep:
  `index_artifact_citations` / `validate_gate_traceability` are NOT imported or
  registered in `worker.py`, and have NO callers anywhere in
  `temporal/olympus_workflows/` (excluding the stale `.claude/worktrees/`, which were
  ignored per instructions, and excluding their own definition file). They exist as
  workflow-facing contracts/stubs for a future traceability service. A faithful
  rebuild reproduces them as the same stubs and likewise does NOT need to register
  them (current worker does not). If the rebuild's worker DOES register them, behavior
  is unchanged because they're never invoked.
- **`get_logger` vs module `logger`:** the wrapper uses
  `foundry_temporal.logging.get_logger()`; `governance_operations.py` uses its own
  `logging.getLogger(__name__)` (file line 40) for the in-body WARNING/INFO logs.
  Reproduce both loggers — they are distinct.
- **Async client lifetime gotcha:** `list_active_modernization_workflows` opens a NEW
  `Client.connect(...)` on every call and never explicitly closes it. The original
  relies on GC / process lifetime; reproduce as-is (do not add a `close()`/context
  manager — that's a behavior change, though benign).
- **Nothing undetermined.** All input/output dataclasses (5 total: 2 in `types.py`, 3
  in `traceability.py`), the exact literal query string, env-var defaults, the
  best-effort branch semantics (connect-fail→`[]` vs iterate-fail→partial `matched`),
  the hard-coded stub return values, the decorator's exception classification, and the
  governance call-site retry policy (`transient` = HTTP_RETRY_POLICY:
  1s/15s/3 attempts/×2.0) are fully captured above with path:line citations.
