# Phase 4 Activity Group — `agent_dispatch`

Atomic regeneration spec for `temporal/olympus_workflows/activities/agent_dispatch.py`.

Behavioral-parity target: an engineer with no access to this code must rebuild these two
activities — `dispatch_agent_task` and `update_agent_task_output_ref` — plus their five
private helpers so they behave **identically**: same call to the agent runtime, same
`agent_task` + `step_execution` DB writes (column-by-column), same error classification,
same heartbeat behavior, same idempotency.

This file is the **activity side** of agent dispatch. The deep skill-runtime pipeline
(`/skills/dispatch`, model resolution, prompt assembly inside the runtime, Bedrock streaming)
is Phase 5. Here we capture exactly what leaves the activity and exactly what the activity
does with the response.

Cite path = `temporal/olympus_workflows/activities/agent_dispatch.py` unless noted otherwise.

---

## 0. PREAMBLE — the `@foundry_activity` decorator (applies to BOTH public activities)

Both public functions are decorated:

```python
@foundry_activity(config=ActivityConfig(enable_observability=True))
```

`foundry_activity` is imported from `foundry_temporal.activities` (installed dependency, NOT in the repo tree — cite by package-relative path `foundry_temporal/activities.py:107-165`).
A rebuild using plain `@activity.defn` **loses** observability logging and error
classification. Reproduce EXACTLY:

`foundry_activity(config, name=None, **activity_kwargs)` returns a decorator that wraps `func`
in `wrapper` and applies `@activity.defn(name=name, **activity_kwargs)` on top of `@wraps(func)`
(`activities.py:125-126`). So the registered Temporal activity name = `func.__name__`
(`name` is None here) → `"dispatch_agent_task"` and `"update_agent_task_output_ref"`.

`ActivityConfig` is a dataclass (`activities.py:27-39`) with fields:
`retry_policy=None`, `start_to_close_timeout=None`, `schedule_to_close_timeout=None`,
`schedule_to_start_timeout=None`, `heartbeat_timeout=None`, `enable_observability=True`,
`enable_error_wrapping=True`, `log_inputs=False`, `log_outputs=False`.
Here only `enable_observability=True` is passed; everything else defaults — so
`enable_error_wrapping=True`, `log_inputs=False`, `log_outputs=False`.
⚠️ The timeout/retry fields on `ActivityConfig` are **NOT** consumed by `foundry_activity` —
they are inert metadata. Timeouts + retry policy are set by the WORKFLOW at
`execute_activity(...)` call time (see §4). The decorator never reads them.

Wrapper runtime behavior (`activities.py:127-161`), per call:

1. `activity_name = name or func.__name__`.
2. `activity_logger = get_logger()` (from `foundry_temporal.activities.logging`).
3. If `enable_observability` (true here): `activity_logger.info(f"Activity {activity_name} starting", extra={"inputs": args if log_inputs else None})`. `log_inputs=False` → `extra={"inputs": None}`.
4. `result = await func(*args, **kwargs)`.
5. On success + observability: `activity_logger.info(f"Activity {activity_name} completed", extra={"outputs": result if log_outputs else None})`. `log_outputs=False` → `extra={"outputs": None}`.
6. Return `result`.
7. On `except Exception as error`:
   - If observability: `activity_logger.error(f"Activity {activity_name} failed: {error}", extra={"error": str(error)})`.
   - If `enable_error_wrapping` (true here): **error classification** (`activities.py:154-159`):
     - `if isinstance(error, (WorkflowError, ApplicationError)): raise` (re-raise unchanged — preserves the original typed error + its own retryable flag).
     - `elif _is_retryable_error(error): raise RetryableError(f"Retryable error in {activity_name}: {error}") from error`.
     - `else: raise NonRetryableError(f"Non-retryable error in {activity_name}: {error}") from error`.

`_is_retryable_error(error)` (`activities.py:168-183`): lower-cases `str(type(error))` and
returns True if any of these substrings appear: `timeout`, `connection`, `network`,
`temporary`, `unavailable`, `overload`, `busy`, `throttle`, `rate_limit`. (Note: matches on
the **type repr**, not the message.)

`WorkflowError`, `RetryableError`, `NonRetryableError` are imported in the wrapper module
from `.errors` (`activities.py:21`); `ApplicationError` from `temporalio.exceptions`.

⚠️ **Interaction with this file's own raises.** `dispatch_agent_task` explicitly raises
`RetryableError` / `NonRetryableError` (both subclasses of `WorkflowError` — see §3.7). Because
the wrapper's first branch re-raises `WorkflowError`/`ApplicationError` **unchanged**, those
typed errors pass straight through the decorator without being re-wrapped or re-classified.
The wrapper's `_is_retryable_error` classification therefore only fires for *unexpected*
exceptions that escape `_dispatch_agent_task_inner` un-typed (which the inner body is written
to avoid — it converts everything to `RetryableError`/`NonRetryableError`). Net effect: the
inner function's `_is_retryable()` (message-substring) classifier is the one that actually
decides retryability in practice; the decorator's `_is_retryable_error()` (type-repr) classifier
is a backstop.

**Module-level logger:** `logger = logging.getLogger(__name__)` (`agent_dispatch.py:47`). This
is the logger used inside the activity bodies (distinct from the wrapper's `get_logger()`).

---

## 1. MODULE IMPORTS & CONSTANTS

- `from foundry_temporal.activities import ActivityConfig, foundry_activity` (`:27`)
- `from foundry_temporal.errors import NonRetryableError, RetryableError` (`:28`)
- `from temporalio import activity` (`:29`)
- From `olympus_workflows.types` (`:31-36`): `AgentTaskInput`, `AgentTaskResult`,
  `StepExecutionContext`, `TaskStatus`.
- From `olympus_workflows.utils.execution` (`:37-45`): `EmitExecutionRecordInput`,
  `ExecutionStatus`, `StepArtifactRef`, `StepKind`, `emit_execution_record`,
  `resolve_input_artifacts`, `update_execution_record`.
- `import asyncpg` (`:26`), `json`, `os`, `time`, `uuid`, `asyncio`, `logging`,
  `from datetime import datetime, timezone`.
- `_HEARTBEAT_INTERVAL_SECONDS = 30.0` (`:332`).

`from __future__ import annotations` (`:16`) — all annotations are strings; this is why
`AgentTaskInput.execution_context` typed as `"StepExecutionContext | None"` is a forward ref.

### 1.1 Input dataclass — `AgentTaskInput` (`types.py:469-509`)

EVERY field (dataclass; `field(default_factory=...)` noted):

| Field | Type | Default |
|---|---|---|
| `task_type` | `str` | (required) |
| `app_id` | `str` | (required) |
| `skill_id` | `str` | (required) |
| `input_artifacts` | `list[str]` | `[]` |
| `optional_input_artifacts` | `list[str]` | `[]` |
| `source_repo` | `str` | `""` |
| `artifact_repo` | `str` | `""` |
| `artifact_ref` | `str` | `""` |
| `model_preference` | `str` | `""` |
| `workspace_key` | `str` | `""` |
| `timeout_seconds` | `int` | `3600` |
| `context` | `dict` | `{}` |
| `execution_context` | `StepExecutionContext \| None` | `None` |
| `wave_id` | `str` | `""` |

Scope invariant: exactly one of `app_id` / `wave_id` is populated (per-app vs wave-scoped).
Enforced early in `_insert_agent_task_row` (§2.2) and at the DB by CHECK
`agent_task_application_or_wave_ck` (§6).

### 1.2 Output dataclass — `AgentTaskResult` (`types.py:513-525`)

| Field | Type | Default |
|---|---|---|
| `task_id` | `str` | (required) |
| `status` | `TaskStatus` | `TaskStatus.COMPLETED` |
| `output_artifacts` | `list[str]` | `[]` |
| `output_files` | `list[OutputFile]` | `[]` |
| `model_used` | `str` | `""` |
| `duration_ms` | `int` | `0` |
| `token_usage_input` | `int` | `0` |
| `token_usage_output` | `int` | `0` |
| `cost_estimate_usd` | `float` | `0.0` |
| `error` | `str` | `""` |

`OutputFile` (`types.py:460-465`): `path: str`, `content: str`, `encoding: str = "utf-8"`.

`TaskStatus` (`types.py:47-55`), a `str` Enum: `QUEUED="queued"`, `DISPATCHED="dispatched"`,
`RUNNING="running"`, `COMPLETED="completed"`, `FAILED="failed"`, `TIMED_OUT="timed_out"`.

### 1.3 `StepExecutionContext` (`types.py:532-554`)

`portfolio_id: str` (required), `line_id: str` (required), `step_id: str` (required),
`app_id: str=""`, `wave_id: str=""`, `input_artifact_paths: list[str]=[]`, `gate_id: str=""`.

---

## 2. PRIVATE HELPERS (not Temporal activities — plain coroutines called inside the body)

### 2.1 `_db_url() -> str` (`:143-150`)

Builds DSN from env (defaults in parens): `DATABASE_HOST` (`localhost`), `DATABASE_PORT`
(`5432`), `DATABASE_USER` (`olympus`), `DATABASE_PASSWORD` (`olympus`), `DATABASE_NAME`
(`olympus`). Returns `postgresql://{user}:{password}@{host}:{port}/{db}`. Identical to
`execution._db_url()` (`utils/execution.py:127-133`). ⚠️ Each helper opens its OWN
`asyncpg.connect(...)` and closes it in a `finally` — there is NO shared pool; every DB
touch is one fresh connection (see GOTCHA G6).

### 2.2 `_insert_agent_task_row(input: AgentTaskInput, dispatched_at: datetime) -> uuid.UUID | None` (`:153-215`)

Inserts the queued/dispatched `agent_task` telemetry row. **Best-effort observability** —
returns `None` on DB failure (logged warning) and the workflow continues. BUT scope
validation raises `ValueError` (not swallowed) — see control flow.

Control flow:
1. `app_id = input.app_id or ""`; `wave_id = getattr(input, "wave_id", "") or ""`.
2. **Exactly-one scope gate** (`:171-175`): `if bool(app_id) == bool(wave_id): raise ValueError("agent_task dispatch requires exactly one of app_id / wave_id; got app_id={app_id!r}, wave_id={wave_id!r}")`. ⚠️ This raise happens BEFORE the try/except that swallows DB errors, so it propagates out of the helper and aborts dispatch (then gets wrapped by the decorator as NonRetryable — `ValueError` type-repr has no retryable substring). This is intentional: callers get a readable error, not an asyncpg trace.
3. Parse scope UUIDs (`:177-183`): `app_uuid = uuid.UUID(app_id) if app_id else None`; `wave_uuid = uuid.UUID(wave_id) if wave_id else None`. On `(ValueError, TypeError)` → `raise ValueError(f"agent_task dispatch got malformed scope id: {exc}") from exc` (also propagates).
4. `task_id = uuid.uuid4()` (`:185`).
5. `try:` connect → execute INSERT → `finally: await conn.close()` → `return task_id`.
6. `except Exception as exc:` (`:212-215`) → `logger.warning("Failed to insert agent_task row: %s", exc)` → `return None`.

**EXACT SQL** (`:191-208`):
```sql
INSERT INTO agent_task (
    id, task_type, application_id, wave_id, module_name,
    skill_id, status, model_requested, dispatched_at,
    input_artifact_refs
) VALUES (
    $1, $2, $3, $4, $5, $6, 'dispatched', $7, $8, $9::jsonb
)
```
Params: `$1=task_id (uuid)`, `$2=input.task_type`, `$3=app_uuid`, `$4=wave_uuid`,
`$5=input.skill_id` (→ `module_name`), `$6=input.skill_id` (→ the dedicated `skill_id` column),
`$7=input.model_preference or None`, `$8=dispatched_at`,
`$9=json.dumps(list(input.input_artifacts or []))`.

⚠️ **CHANGED at HEAD (was a documented GOTCHA G2):** the INSERT now writes the skill id to **BOTH** `module_name` AND the dedicated migration-027 `skill_id` column — `input.skill_id` is bound twice (`$5` and `$6`). The prior baseline wrote ONLY `module_name` and left `skill_id` NULL. The `agent_benchmark` rollup view (which groups by `skill_id`) therefore now DOES see dispatch-written rows' skill. The other migration-027 metric columns (`agent_id`, `input_tokens`, `output_tokens`, `quality_score`, …) are still left NULL by this path.

**Column-by-column mapping — INSERT into `agent_task` (queued/dispatched state):**

| `agent_task` column | Source | Default / Condition |
|---|---|---|
| `id` | `uuid.uuid4()` (`task_id`) | always |
| `task_type` | `input.task_type` | always |
| `application_id` | `app_uuid` (= `uuid.UUID(input.app_id)`) | `None` when wave-scoped |
| `wave_id` | `wave_uuid` (= `uuid.UUID(input.wave_id)`) | `None` when app-scoped |
| `module_name` | `input.skill_id` | always (⚠️ skill id is ALSO stored here — legacy column — see G2) |
| `skill_id` | `input.skill_id` | always (⚠️ NEW at HEAD: the dedicated migration-027 column is now populated; see G2) |
| `status` | literal `'dispatched'` | always (cast to `task_status_enum` implicitly by column type) |
| `model_requested` | `input.model_preference or None` | NULL when empty string |
| `dispatched_at` | `dispatched_at` arg (`datetime.now(timezone.utc)` at call site) | always |
| `input_artifact_refs` | `json.dumps(list(input.input_artifacts or []))` cast `::jsonb` | always (empty list → `[]`) |

Columns NOT written here (left to DB default / NULL): `agent_backend`, `agent_session_id`,
`model_used`, `model_source`, `completed_at`, `duration_ms`, `retry_count`(server default 0),
`last_error`, `output_artifact_ref`, `token_usage`, `cost_estimate`, plus the migration-027
metric columns `agent_id`, `workflow_id`, `started_at`, `input_tokens`, `output_tokens`,
`cache_read_tokens`, `cache_write_tokens`, `quality_score`, `error_code`, `artifact_id`.
(⚠️ `skill_id` is NO LONGER in this NOT-written list — it is now populated, see above.) Also NOT
written here: `actor_kind` (server default `'olympus_agent'`), `human_user_id`,
`local_agent_descriptor` — these are the migration-050 human-task columns, populated only by the
separate `dispatch_human_task` activity (see `human_task.md`), never by `dispatch_agent_task`.

⚠️ Historical regression captured in docstring (`:160-167`) + migration 044: before the
wave column existed, callers stuffed `app_id=f"wave-{wave_id}"`; `uuid.UUID("wave-...")`
raised `ValueError`, was caught, returned `None`, silently dropping 11+ telemetry rows per
wave run. The docstring says "migration 043" but the wave schema is migration **044**
(`044_agent_task_wave_scoped.py`); 043 is `wave_failed_status`. Reproduce the code as-is; the
docstring's "043" is a doc bug — do not let it drive the schema.

### 2.3 `_pick_output_ref(result: AgentTaskResult) -> str | None` (`:218-236`)

Chooses a safe value for `agent_task.output_artifact_ref`. The column should hold a path/URL
to a committed artifact, but the agent SDK puts its final **summary prose** in
`output_artifacts[0]`, which is NOT a file ref. Logic:
1. `if result.output_files: return result.output_files[0].path or None` (prefer a concrete file path).
2. `if not result.output_artifacts: return None`.
3. `candidate = str(result.output_artifacts[0])`.
4. **Heuristic reject** (`:234-235`): `if "\n" in candidate or len(candidate) > 512: return None` (a multi-line or >512-char string is prose, not a path).
5. `return candidate or None` (empty string → None).

### 2.4 `_update_agent_task_row(task_id, result, completed_at, error=None) -> None` (`:239-284`)

Updates the row to terminal state with metrics. **Best-effort** — swallows all DB exceptions
(`:283-284` → `logger.warning("Failed to update agent_task row %s: %s", task_id, exc)`).

Control flow:
1. `if task_id is None: return` (skip when the insert failed/returned None — idempotent no-op).
2. `status = "failed" if error else result.status.value.lower()`. ⚠️ When an `error` string is supplied, status is forced to `"failed"` regardless of `result.status`. Otherwise it's the result's status enum value, lower-cased. `TaskStatus` values are already lowercase, so `.lower()` is a defensive no-op except for `TIMED_OUT`→`"timed_out"` (already lower) — net: passes through to `task_status_enum` valid tokens.
3. `output_ref = _pick_output_ref(result)`.
4. `token_usage = {"input": int(result.token_usage_input or 0), "output": int(result.token_usage_output or 0), "total": int((result.token_usage_input or 0) + (result.token_usage_output or 0))}`.
5. connect → execute UPDATE → `finally: close`.

**EXACT SQL** (`:259-269`):
```sql
UPDATE agent_task
SET status = $2::task_status_enum,
    completed_at = $3,
    duration_ms = $4,
    model_used = $5,
    output_artifact_ref = $6,
    token_usage = $7::jsonb,
    cost_estimate = $8,
    last_error = $9
WHERE id = $1
```
Params: `$1=task_id`, `$2=status`, `$3=completed_at`, `$4=int(result.duration_ms or 0)`,
`$5=result.model_used or None`, `$6=output_ref`, `$7=json.dumps(token_usage)`,
`$8=float(result.cost_estimate_usd or 0.0) or None`, `$9=error`.

**Column-by-column mapping — UPDATE `agent_task` (terminal state), WHERE id = task_id:**

| `agent_task` column | Source | Default / Condition |
|---|---|---|
| `status` | `"failed"` if `error` truthy else `result.status.value.lower()` | cast `::task_status_enum` |
| `completed_at` | `completed_at` arg (`datetime.now(timezone.utc)` at call site) | always |
| `duration_ms` | `int(result.duration_ms or 0)` | 0 if falsy |
| `model_used` | `result.model_used or None` | NULL when empty string |
| `output_artifact_ref` | `_pick_output_ref(result)` | NULL when prose/empty/no files (§2.3) |
| `token_usage` | `json.dumps({"input","output","total"})` cast `::jsonb` | always (zeros if no usage) |
| `cost_estimate` | `float(result.cost_estimate_usd or 0.0) or None` | ⚠️ `0.0 or None` → **NULL** when cost is 0.0 |
| `last_error` | `error` arg | NULL when no error |

Columns NOT touched by the UPDATE: `id`(WHERE key), `task_type`, `application_id`, `wave_id`,
`module_name`, `agent_backend`, `agent_session_id`, `model_requested`, `model_source`,
`dispatched_at`, `retry_count`, `input_artifact_refs`, and all migration-027 metric columns
(`agent_id`, `skill_id`, `workflow_id`, `started_at`, `input_tokens`, `output_tokens`,
`cache_read_tokens`, `cache_write_tokens`, `quality_score`, `error_code`, `artifact_id`).
⚠️ This means the migration-027 rollup view `agent_benchmark` (which reads `input_tokens` /
`output_tokens` / `agent_id` / `skill_id` / `quality_score`) sees only NULLs from rows this
activity writes — the dispatch path populates the legacy `token_usage` JSONB + `module_name`,
not the structured rollup columns. Reproduce as-is.

### 2.5 `_emit_agent_start(ctx, input, agent_task_id) -> uuid.UUID | None` (`:50-96`)

Emits the initial RUNNING `step_execution` row for an agent dispatch (Layer B envelope).

Control flow:
1. `if ctx is None or agent_task_id is None: return None`. ⚠️ Both must be present. `agent_task_id` is required because `step_execution`'s CHECK `step_execution_agent_fk_ck` enforces `(step_kind='agent') = (agent_task_id IS NOT NULL)` (migration 033 `:158-161`). If the `agent_task` insert returned None (§2.2 fail), emission is skipped entirely.
2. `try: workflow_id = activity.info().workflow_id; attempt = activity.info().attempt` `except Exception: workflow_id=""; attempt=1` (`:62-66`). Best-effort outside an activity context (mock/tests).
3. `input_artifacts = resolve_input_artifacts(ctx.input_artifact_paths or input.input_artifacts, repo=input.artifact_repo or "", ref=input.artifact_ref or "main")` (`:67-71`). `resolve_input_artifacts` (`utils/execution.py:348-373`) maps each declaration string to a `StepArtifactRef(repo, ref, path)`, applying `{placeholder}` substitutions (none passed here → paths verbatim).
4. Build `payload` dict (`:72-80`):
   ```python
   {
     "task_type": input.task_type,
     "skill_id": input.skill_id,
     "agent_role": input.skill_id,        # agent_role mirrors skill_id
     "model_used": input.model_preference or "",
     "token_usage": {"input": 0, "output": 0, "total": 0},
     "cost_estimate_usd": 0.0,
     "mcp_servers_used": [],
   }
   ```
5. `return await emit_execution_record(EmitExecutionRecordInput(portfolio_id=ctx.portfolio_id, line_id=ctx.line_id, step_id=ctx.step_id, step_kind=StepKind.AGENT, workflow_id=workflow_id, app_id=ctx.app_id or None, wave_id=ctx.wave_id or None, attempt=attempt, input_artifacts=input_artifacts, payload=payload, agent_task_id=str(agent_task_id), status=ExecutionStatus.RUNNING))` (`:81-96`).

`emit_execution_record` (`utils/execution.py:150-219`) is itself best-effort (returns None on
failure / invalid portfolio_id). Its INSERT mapping is documented in §2.5.1 because this
activity is the agent-kind producer.

#### 2.5.1 `emit_execution_record` INSERT — `step_execution` (agent-kind row at start)

`utils/execution.py:150-219`. `execution_id = uuid.uuid4()`; `started_at = input.started_at or
datetime.now(timezone.utc)`. Parses UUIDs via `_parse_uuid` (`""`/`None`→None; bad→None). If
`portfolio_uuid is None` → log warning + return None (no insert). Else INSERT, best-effort.

**EXACT SQL** (`utils/execution.py:180-192`):
```sql
INSERT INTO step_execution (
    execution_id, app_id, wave_id, portfolio_id,
    line_id, step_id, step_kind, status,
    started_at, attempt, input_artifacts, payload,
    workflow_id, agent_task_id, gate_id
) VALUES ($1,$2,$3,$4, $5,$6,$7,$8, $9,$10,$11::jsonb,$12::jsonb, $13,$14,$15)
```

**Column-by-column mapping — INSERT `step_execution` (for the agent dispatch):**

| `step_execution` column | Source (via `_emit_agent_start` → `EmitExecutionRecordInput`) | Default / Condition |
|---|---|---|
| `execution_id` | `uuid.uuid4()` | always (returned to caller) |
| `app_id` | `_parse_uuid(ctx.app_id or None)` | NULL for wave-scoped |
| `wave_id` | `_parse_uuid(ctx.wave_id or None)` | NULL for per-app |
| `portfolio_id` | `_parse_uuid(ctx.portfolio_id)` | **required** — None aborts insert (returns None) |
| `line_id` | `ctx.line_id` | always |
| `step_id` | `ctx.step_id` | always |
| `step_kind` | `StepKind.AGENT.value` = `"agent"` | always |
| `status` | `ExecutionStatus.RUNNING.value` = `"running"` | always |
| `started_at` | `datetime.now(timezone.utc)` | always (no `started_at` passed) |
| `attempt` | `activity.info().attempt` (or 1) | from Temporal |
| `input_artifacts` | `json.dumps([a.to_dict() for a in input_artifacts])` cast `::jsonb` | each `StepArtifactRef.to_dict()` = `{repo,ref,path[,content_hash]}` |
| `payload` | `json.dumps(payload or {})` cast `::jsonb` | the dict from step 4 above |
| `workflow_id` | `activity.info().workflow_id` (or `""`) | always |
| `agent_task_id` | `_parse_uuid(str(agent_task_id))` | the `task_row_id` from §2.2; non-NULL required for agent kind |
| `gate_id` | `_parse_uuid(None)` = None | NULL (no gate_id passed for agent) |

`StepArtifactRef.to_dict()` (`utils/execution.py:91-99`): `{"repo":..., "ref":..., "path":...}`
plus `"content_hash"` only when not None.

### 2.6 `_emit_agent_complete(execution_id, result, *, status=COMPLETED, error=None, artifact_repo="", artifact_ref="") -> None` (`:99-140`)

Updates the `step_execution` row to terminal agent state.

Control flow:
1. `if execution_id is None: return` (idempotent no-op when start emission failed).
2. `token_usage = {"input": int(result.token_usage_input or 0), "output": int(result.token_usage_output or 0), "total": int((result.token_usage_input or 0)+(result.token_usage_output or 0))}`.
3. `payload_merge = {"model_used": result.model_used or "", "token_usage": token_usage, "cost_estimate_usd": float(result.cost_estimate_usd or 0.0)}`.
4. `output_artifacts: list[StepArtifactRef] | None = None`.
   `if result.output_files and artifact_repo:` build a list comp (`:125-133`):
   `output_artifacts = [StepArtifactRef(repo=artifact_repo, ref=artifact_ref or "main", path=f.path) for f in result.output_files if f.path]`. ⚠️ Output artifacts on the execution record are derived from `output_files` ONLY, and ONLY when `artifact_repo` is non-empty. If the dispatch was a failure path called with no `artifact_repo` (see §3.7), `output_artifacts` stays None and is not written.
5. `await update_execution_record(execution_id, status=status, output_artifacts=output_artifacts, payload_merge=payload_merge, last_error=error)`.

#### 2.6.1 `update_execution_record` UPDATE — `step_execution` (terminal)

`utils/execution.py:222-275`. `completed = completed_at or datetime.now(timezone.utc)`.
`out_artifacts = [a.to_dict() for a in output_artifacts] if output_artifacts else None`.
Best-effort.

**EXACT SQL** (`utils/execution.py:251-260`):
```sql
UPDATE step_execution
   SET status = $2,
       completed_at = $3,
       duration_ms = EXTRACT(EPOCH FROM ($3 - started_at)) * 1000,
       output_artifacts = COALESCE($4::jsonb, output_artifacts),
       payload = payload || COALESCE($5::jsonb, '{}'::jsonb),
       last_error = COALESCE($6, last_error)
 WHERE execution_id = $1
```
Params: `$1=execution_id`, `$2=status.value`, `$3=completed`,
`$4=json.dumps(out_artifacts) if out_artifacts is not None else None`,
`$5=json.dumps(payload_merge) if payload_merge else None`, `$6=last_error`.

**Column-by-column mapping — UPDATE `step_execution` (terminal), WHERE execution_id:**

| `step_execution` column | Source | Default / Condition |
|---|---|---|
| `status` | `status.value` (`ExecutionStatus.COMPLETED`→`"completed"` or `FAILED`→`"failed"`) | always |
| `completed_at` | `datetime.now(timezone.utc)` | always (no `completed_at` passed) |
| `duration_ms` | `EXTRACT(EPOCH FROM (completed_at - started_at)) * 1000` | computed in SQL from the row's own `started_at` |
| `output_artifacts` | `COALESCE($4, output_artifacts)` — `$4` = `json.dumps([ref.to_dict()...])` | ⚠️ **only overwritten when non-None**; preserves existing when None (no output_files / no artifact_repo) |
| `payload` | `payload \|\| COALESCE($5,'{}'::jsonb)` — JSONB **shallow merge** of `payload_merge` | merges `{model_used, token_usage, cost_estimate_usd}` over the start-time payload (overwriting those keys, keeping `task_type`/`skill_id`/`agent_role`/`mcp_servers_used`) |
| `last_error` | `COALESCE($6, last_error)` | only set when `error` is non-None; preserves existing otherwise |

⚠️ G7: `duration_ms` is computed **server-side** from `started_at`. If the start row was never
inserted (best-effort failure) `execution_id` is None and this whole update is skipped — there
is no orphan terminal row.

---

## 3. ACTIVITY 1 — `dispatch_agent_task`

`@foundry_activity(config=ActivityConfig(enable_observability=True))`
`async def dispatch_agent_task(input: AgentTaskInput) -> AgentTaskResult` (`:385-436`).

Registered Temporal activity name: `"dispatch_agent_task"`. Registered in
`temporal/olympus_workflows/worker.py:176` and exported from
`activities/__init__.py` (`dispatch_agent_task` in `__all__`, `:32`).

The public function is a **heartbeat-wrapper** around `_dispatch_agent_task_inner` (§3.4). It
exists solely to spawn + reliably cancel the heartbeat loop on every exit path.

### 3.1 Heartbeat wrapper control flow (`:408-436`)

1. `_heartbeat_task: asyncio.Task | None = None`.
2. `try: _heartbeat_task = asyncio.create_task(_heartbeat_loop(task_type=input.task_type, app_id=input.app_id, skill_id=input.skill_id, started_monotonic=time.monotonic()))` `except Exception as exc: logger.debug("Heartbeat loop did not start (%s)", exc)` — if no event loop, proceed without heartbeats (pre-PR behavior).
3. `try: return await _dispatch_agent_task_inner(input)`.
4. `finally:` if `_heartbeat_task is not None and not _heartbeat_task.done(): _heartbeat_task.cancel()` then `try: await asyncio.sleep(0) except Exception: pass`. ⚠️ It yields ONE event-loop tick (`asyncio.sleep(0)`) to let the cancel propagate — it deliberately does NOT `await _heartbeat_task` because that would re-raise `CancelledError` from inside the `finally` and mask the real exit path (success or the typed error from the inner body). Reproduce exactly: do not await the task itself.

### 3.2 `_heartbeat_loop(task_type, app_id, skill_id, started_monotonic) -> None` (`:335-381`)

Rationale (`:341-358`): Bedrock streaming for synthesis-class skills
(data-migration-planning, data-data-synthesis, architecture-blueprint-assembly) can run
> 1 hour. With heartbeats firing every ~30s, the workflow can set `heartbeat_timeout=2m` and
Temporal kills the activity only on a true hang (heartbeats stop), making
`start_to_close_timeout` the upper-bound safety net rather than the primary liveness signal.

Loop body (`:359-381`):
```
while True:
    try: await asyncio.sleep(_HEARTBEAT_INTERVAL_SECONDS)   # 30.0s
    except asyncio.CancelledError: return
    try:
        elapsed_s = int(time.monotonic() - started_monotonic)
        activity.heartbeat({"phase":"agent_streaming","task_type":task_type,"app_id":app_id,"skill_id":skill_id,"elapsed_s":elapsed_s})
    except Exception as exc:
        logger.debug("Heartbeat skipped (%s); stopping heartbeat loop", exc)
        return
```
⚠️ Two distinct exits: (a) `CancelledError` during the sleep → clean return (normal cancel
path from the wrapper finally); (b) `activity.heartbeat()` raising (no activity context in
mock/tests, or heartbeat machinery not wired) → log once at DEBUG and **stop the loop** (don't
spin a doomed loop). The dispatch proceeds either way. The heartbeat **payload** is a dict
detail object — Temporal records it as the latest heartbeat detail.

### 3.3 Workflow-side call configuration (where `heartbeat_timeout` etc. live)

The decorator does NOT set timeouts. The canonical call site is
`temporal/olympus_workflows/workflows/base.py:459-465`:
```python
result = await workflow.execute_activity(
    dispatch_agent_task,
    task_input,
    start_to_close_timeout=timedelta(hours=1),
    retry_policy=RETRY_POLICIES["agent_failure"],
    activity_id=f"agent-{step_name}",
)
```
`RETRY_POLICIES["agent_failure"]` (`retry_policies.py:37-42`): `initial_interval=5s`,
`backoff_coefficient=2.0`, `maximum_interval=60s`, `maximum_attempts=3`. (Note: some call
sites in base.py also use `start_to_close_timeout=timedelta(minutes=10)` at `:1041`; per-call
configurable. `heartbeat_timeout` is set per-call by callers that want the heartbeat safety
net — the activity emits heartbeats unconditionally so whatever the caller configures is
honored.)

### 3.4 `_dispatch_agent_task_inner(input) -> AgentTaskResult` (`:439-624`)

Extracted body so the heartbeat cleanup in §3.1 covers every exit uniformly. Imports done
lazily inside the function (`:445-446`):
`from src.agent_registry import olympus_agent_registry` and
`from src.fallback_adapter import dispatch_via_subprocess`.
⚠️ G3: these are `src.*` imports — they resolve against the **olympus-worker** package
(`olympus-worker/src/agent_registry.py`, `.../fallback_adapter.py`). The worker process must
have `olympus-worker/src` importable as top-level `src`. A rebuild placing these modules
elsewhere must preserve the `src.` import root or the registry lookup silently fails into the
subprocess fallback.

Step-by-step:

1. `logger.info("Dispatching agent task", extra={task_type, app_id, wave_id=getattr(input,"wave_id",""), skill_id, model_preference})` (`:448-457`).
2. `dispatched_at = datetime.now(timezone.utc)` (`:459`).
3. `task_row_id = await _insert_agent_task_row(input, dispatched_at)` (`:460`, §2.2). May be None (best-effort) but a scope ValueError propagates and aborts here.
4. `exec_id = await _emit_agent_start(input.execution_context, input, task_row_id)` (`:461`, §2.5). May be None.
5. **Skill selection / agent resolution** (`:466`): `agent_card = olympus_agent_registry.find_agent_for_skill(input.skill_id)`. See §3.5.

### 3.5 Skill selection — `olympus_agent_registry.find_agent_for_skill(skill_id)`

`olympus-worker/src/agent_registry.py:187-210`. Resolution order:
1. If any registered agent declares `skill_id` in its `skill_ids` list → return the FIRST match (`self._cards[self._skill_index[skill_id][0]]`). `_skill_index` is `skill_id -> [agent_name]` in registration order.
2. Else, return any agent registered with an **empty** `skill_ids` list — the catch-all (P5-S26 Q15: Olympus agents are generic skill dispatchers; the `agents.yaml` catch-all entry handles every otherwise-unclaimed skill). Returns the first such card found while iterating `self._cards.values()`.
3. Else → `logger.warning("No agent found for skill_id=%s", skill_id)` → return None.

`OlympusAgentCard` (`agent_registry.py:44-61`): `name`, `description`, `url`, `skill_ids=[]`,
`capabilities=[]`, `supported_models=[]`, `preferred_model_tier="tier-2"`,
`assembly_lines=[]`, `version="0.1.0"`, `metadata={}`. The registry is a module-level
singleton `olympus_agent_registry` (`:230`), loaded from a YAML config via
`load_from_config` (`:100-162`) with `${VAR:-default}` env expansion on the `url` field. Only
`agent_card.url` is consumed by dispatch.

### 3.6 Primary dispatch path — `agent_card is not None` (`:468-564`)

Inside `try:`:

1. **Dispatcher selection** (`:475-485`):
   - `if os.environ.get("AGENT_RUNTIME_MODE", "live").strip().lower() == "mock":` → `from src.testing.mock_agent_runtime import dispatch_via_mock` → `dispatcher = dispatch_via_mock`. (Mock = fixture-backed; for automated tests only. Production refusal is enforced at worker startup `src/config.py:WorkerConfig.validate_agent_runtime_mode` per DECISION-018; default is `"live"`.)
   - else: `try: from olympus_api.src.services.agent_client import dispatch_via_a2a as dispatcher` (`:481`) `except ImportError: from src.agent_client import dispatch_via_a2a as dispatcher` (`:485`). ⚠️ G4: the **olympus-api** client is preferred over the worker's bundled client. The two differ: only the worker's `src/agent_client.py` has the 503-saturation retry (`_post_with_saturation_retry`) AND adds `artifact_repo`/`artifact_ref` into the A2A context. The api client (`olympus-api/src/services/agent_client.py`) does NOT add `artifact_repo`/`artifact_ref` to context and has no 503 retry. Which one runs depends on whether `olympus_api` is importable in the worker venv. Reproduce both clients (see §5) and the import-preference order.
2. `result = await dispatcher(agent_url=agent_card.url, task_input=input)` (`:487-490`). The dispatcher does the HTTP POST + response mapping (§5). It returns an `AgentTaskResult` (it does NOT raise on a `status=="failed"` response — it returns a FAILED result).
3. **Agent-failure-OR-timeout propagation** (`:500-520`): `if result.status in (TaskStatus.FAILED, TaskStatus.TIMED_OUT):`
   - ⚠️ **CHANGED at HEAD:** the prior baseline branched only on `== TaskStatus.FAILED`. **`TaskStatus.TIMED_OUT` is now propagated identically** (the SDK stream exceeded the skill timeout). The rationale (comment `:492-499`): a timed-out run returns NO `output_files`; if it fell through to the COMPLETED success path the workflow would see empty output and steps with a non-retryable empty-output guard (e.g. PRA's `EmptyPortfolioRedundancyPlan`) would fail the whole wave on what should have been a fresh retry.
   - `_err = result.error or ("agent execution timed out" if result.status == TaskStatus.TIMED_OUT else "unknown error")` (`:501-505`). ⚠️ NEW: the default error message is status-dependent — `"agent execution timed out"` for TIMED_OUT, `"unknown error"` for FAILED.
   - `await _update_agent_task_row(task_row_id, result, datetime.now(timezone.utc), error=_err)` (§2.4 → status forced `"failed"` whenever `error` is truthy — so a TIMED_OUT result also lands `agent_task.status='failed'`, NOT `'timed_out'`, because `_update_agent_task_row` keys status on the presence of the `error` arg, see §2.4 step 2 / G11).
   - `await _emit_agent_complete(exec_id, result, status=ExecutionStatus.FAILED, error=_err, artifact_repo=input.artifact_repo, artifact_ref=input.artifact_ref)` (§2.6).
   - `raise RetryableError(f"Agent task {result.status.value}: {_err}")` (`:518-520`). ⚠️ **CHANGED message:** was `f"Agent task failed: {result.error or 'unknown error'}"`; now interpolates the actual status value → `"Agent task failed: …"` or `"Agent task timed_out: …"`. A failed/timed-out agent result is **always Retryable** (not classified) — Temporal retries under `agent_failure` (3 attempts). `RetryableError` is a `WorkflowError`, so the decorator re-raises it unchanged.
4. **Success path** (`:521-531`):
   - `await _update_agent_task_row(task_row_id, result, datetime.now(timezone.utc))` (no error → status = `result.status.value.lower()`, typically `"completed"`).
   - `await _emit_agent_complete(exec_id, result, status=ExecutionStatus.COMPLETED, artifact_repo=input.artifact_repo, artifact_ref=input.artifact_ref)`.
   - `return result`.

`except` clauses on the primary path (`:533-564`), in order:
- `except ImportError:` (`:533-537`) → `logger.warning("agent_client not available, attempting direct A2A dispatch")` → **fall through** to the subprocess fallback below (does NOT re-dispatch; control exits the `if agent_card is not None` block and proceeds to §3.7's fallback). ⚠️ The docstring comment says "Fall through to try the services module path" but in code it falls through to the SUBPROCESS fallback (`:566+`). An ImportError raised by the dispatcher itself (e.g. mock_agent_runtime import) lands here.
- `except RetryableError: raise` (`:538-539`) — re-raise the failure/timeout-propagation error from step 3 verbatim (don't reclassify it as a generic exception).
- `except Exception as e:` (`:540-564`) — any other dispatch error:
  - `error_str = str(e)`.
  - `failed_result = AgentTaskResult(task_id="", status=TaskStatus.FAILED, error=error_str)`.
  - `await _update_agent_task_row(task_row_id, failed_result, datetime.now(timezone.utc), error=error_str)`.
  - `await _emit_agent_complete(exec_id, failed_result, status=ExecutionStatus.FAILED, error=error_str)`. ⚠️ Note: NO `artifact_repo`/`artifact_ref` passed here → `_emit_agent_complete` writes no `output_artifacts`.
  - **Error classification** via `_is_retryable(error_str)` (§3.8): if retryable → `raise RetryableError(f"A2A dispatch failed (retryable): {error_str}") from e`; else → `raise NonRetryableError(f"A2A dispatch failed (non-retryable): {error_str}") from e`.

### 3.7 Fallback path — subprocess (`:566-624`)

Reached when `agent_card is None` (no agent + no catch-all) OR the primary path raised
`ImportError` and fell through.

1. `logger.warning("No agent found for skill_id=%s or A2A unavailable, using subprocess fallback", input.skill_id)` (`:567-570`).
2. `fallback_module = f"agents.{input.skill_id.lower().replace('-', '_')}"` (`:572`). e.g. `skill_id="portfolio-scorer"` → `"agents.portfolio_scorer"`.
3. `try: result = await dispatch_via_subprocess(module_name=fallback_module, task_input=input)` (`:573-577`).
   - `except Exception as e:` (`:578-597`): `logger.error("Subprocess fallback also failed: %s", e)` → build `failed_result = AgentTaskResult(task_id="", status=TaskStatus.FAILED, error=str(e))` → `_update_agent_task_row(... error=str(e))` → `_emit_agent_complete(... status=FAILED, error=str(e))` (no artifact refs) → `raise RetryableError(f"Both A2A and subprocess dispatch failed: {e}") from e` (always Retryable).
4. `if result.status == TaskStatus.FAILED:` (`:599-612`): ⚠️ NOTE the subprocess-path failure check still branches ONLY on `== TaskStatus.FAILED` (the TIMED_OUT addition in step 3 of §3.6 was NOT mirrored here — `dispatch_via_subprocess` maps its own timeouts to `TaskStatus.TIMED_OUT`, which on THIS path would fall through to success; in practice the fallback is disabled by default, see below). Update row + emit complete (WITH `artifact_repo`/`artifact_ref` this time) → `raise RetryableError(f"Agent task failed: {result.error}")`.
5. Success (`:614-624`): `_update_agent_task_row(... no error)` → `_emit_agent_complete(... COMPLETED, artifact_repo, artifact_ref)` → `return result`.

`dispatch_via_subprocess` (`olympus-worker/src/fallback_adapter.py:40-192`): **deprecated**,
gated behind env `ENABLE_SUBPROCESS_FALLBACK=1` (`_FALLBACK_ENABLED`, `:34`). When disabled
(default) it returns a FAILED `AgentTaskResult` with `error="Subprocess fallback is disabled.
Use A2A dispatch via olympus-agent-runtime."` (`:72-82`) — which then trips step 4 and raises
RetryableError. When enabled: runs `python -m <module> --task-input <json>`, parses a single
JSON object from stdout, maps to `AgentTaskResult`; timeouts → `TaskStatus.TIMED_OUT`.

### 3.8 `_is_retryable(error_msg: str) -> bool` (`:627-638`)

Activity-local classifier (distinct from the decorator's `_is_retryable_error`):
```python
non_retryable = ["not found","invalid input","bad request","unauthorized","forbidden","capability"]
return not any(keyword in error_msg.lower() for keyword in non_retryable)
```
⚠️ Default is **retryable** — only messages containing one of the six substrings are
non-retryable. Substring match on the lower-cased message (e.g. an HTTP 404 "... not found ..."
→ NonRetryable; a 401 "unauthorized" → NonRetryable; a 422 "missing capability" → NonRetryable;
everything else, including 503/500/timeouts → Retryable).

### 3.9 Idempotency & ordering summary for `dispatch_agent_task`

- Temporal retries the WHOLE activity on RetryableError → `_insert_agent_task_row` inserts a **NEW** `agent_task` row (fresh `uuid.uuid4()`) on each attempt. There is no upsert/dedupe. ⚠️ G5: N retries → N `agent_task` rows + N `step_execution` rows for the same logical dispatch. This is accepted (telemetry-only); the workflow keys real state on the returned `AgentTaskResult`, not on row identity.
- All DB writes (`_insert_agent_task_row`, `_update_agent_task_row`, `_emit_agent_start`, `_emit_agent_complete`) are best-effort: a DB failure never changes the activity result or raises (the scope-validation ValueError in `_insert_agent_task_row` is the sole exception and is intentional). Persistence unavailability does not break durability.
- The heartbeat task is always cancelled in the wrapper `finally` regardless of success/raise.

---

## 4. ACTIVITY 2 — `update_agent_task_output_ref`

`@foundry_activity(config=ActivityConfig(enable_observability=True))`
`async def update_agent_task_output_ref(app_id: str, task_type: str, artifact_ref: str) -> None`
(`:288-329`).

Registered Temporal activity name: `"update_agent_task_output_ref"`. Registered in
`temporal/olympus_workflows/worker.py:177`. ⚠️ G8: STILL NOT exported from
`activities/__init__.py.__all__` (verified at HEAD — see `activities/__init__.py:28-43`) —
workflows import it directly via
`from olympus_workflows.activities.agent_dispatch import update_agent_task_output_ref`
(e.g. `workflows/base.py:50`). It is still a fully registered activity; the missing `__all__`
entry is cosmetic.

Purpose: after `_commit_step_artifacts` writes the canonical artifact to Git, replace the
agent's free-form summary text in `output_artifact_ref` with the real committed file path so
the UI's Artifacts tab shows a path, not prose.

Control flow:
1. `if not artifact_ref or not task_type: return` (`:299-300`) — no-op on empty inputs.
2. `try: app_uuid = uuid.UUID(app_id) except (ValueError, TypeError): return` (`:302-304`) — silent no-op on a bad app_id (e.g. wave-scoped callers; this activity is app-scoped only).
3. `try:` connect → execute UPDATE → `finally: close`.
4. `except Exception as exc:` (`:325-329`) → `logger.warning("Failed to update output_artifact_ref (%s/%s): %s", task_type, app_id, exc)` (best-effort; never raises).

**EXACT SQL** (`:309-318`):
```sql
UPDATE agent_task
SET output_artifact_ref = $3
WHERE id = (
    SELECT id FROM agent_task
    WHERE application_id = $1 AND task_type = $2
    ORDER BY dispatched_at DESC NULLS LAST
    LIMIT 1
)
```
Params: `$1=app_uuid`, `$2=task_type`, `$3=artifact_ref`.

**Column-by-column mapping — UPDATE `agent_task`:**

| `agent_task` column | Source | Condition |
|---|---|---|
| `output_artifact_ref` | `artifact_ref` (positional arg) | only the single most-recent matching row |

Row selection: the **most recent** `agent_task` for `(application_id=app_uuid,
task_type=task_type)` by `dispatched_at DESC NULLS LAST LIMIT 1`. ⚠️ NO `task_status_enum`
cast here (unlike `_update_agent_task_row`), because no enum column is touched. ⚠️ Matches on
`task_type` (the free-form string), not skill_id; the caller builds `task_type` as
`f"{self._task_type_prefix()}-{step_name}"` (see §4.1) so it lines up with the `task_type`
stored at insert time. If the dispatch stored a different `task_type` than the caller passes
here, zero rows match and the UPDATE is a silent no-op.

### 4.1 Workflow-side call configuration

Canonical call site `workflows/base.py:850-862` (inside `_commit_step_artifacts`), gated by
`workflow.patched("patch-output-artifact-ref-v1")` at `:850` (so in-flight pre-patch runs don't
trip nondeterminism on replay):
```python
await workflow.execute_activity(
    update_agent_task_output_ref,
    args=[app_id, f"{self._task_type_prefix()}-{step_name}", artifact_path],
    start_to_close_timeout=timedelta(seconds=30),
    retry_policy=RETRY_POLICIES["transient"],
    activity_id=f"patch-output-ref-{step_name}",
)
```
wrapped in `try/except Exception: pass` (observability only). `RETRY_POLICIES["transient"]`
= `HTTP_RETRY_POLICY` from `foundry_temporal.retry_policies` (`retry_policies.py:33`,`:110`).
⚠️ Positional `args` order is `[app_id, task_type, artifact_ref]` — must match the signature.

### 4.2 Idempotency

Fully idempotent: re-running sets the same `output_artifact_ref` on the same most-recent row.
No insert, no side effect beyond the single column write. Returns None.

---

## 5. THE ACTUAL CALL TO THE AGENT RUNTIME (dispatcher internals)

The dispatcher (`dispatch_via_a2a` from either api or worker, OR `dispatch_via_mock`) is
selected in §3.6. ⚠️ NOTE: despite the task naming the "`/skills/dispatch` endpoint", BOTH
`dispatch_via_a2a` implementations POST to **`{agent_url}/a2a/tasks`** (the A2A task endpoint).
The agent runtime internally fans that A2A task out to its own `/skills/dispatch` machinery
(Phase 5). The activity-side wire contract is the `/a2a/tasks` POST below.

### 5.1 Request assembly — how inputs/context/priors become the call

Common to both `dispatch_via_a2a` clients
(`olympus-api/src/services/agent_client.py`, `olympus-worker/src/agent_client.py`):

`task_id = str(uuid.uuid4())` (the dispatcher mints its own id — separate from the
`agent_task.id`). `start_time_ms = int(time.time()*1000)`.

`_build_task_message(task_input)` (api `:55-70`, worker `:70-86`) →
```
f"Execute skill '{skill_id}' for application '{app_id}'. Task type: {task_type}."
```
plus, if `context` non-empty:
` Context: {k1=v1, k2=v2, ...}.` where pairs are `sorted(context.items())` joined by `", "`.
⚠️ This inline-renders caller context (e.g. `gate_type=G-RR`, `fixture_scenario=...`,
`context_priors=...`) into the prompt string so the skill sees workflow metadata. The api
client reads `getattr(task_input,"context",None) or {}`; the worker client reads
`task_input.context` directly — equivalent for the dataclass.

`_build_context(task_input)` → the JSON `context` object:

| key | source | condition |
|---|---|---|
| `app_id` | `task_input.app_id` | always |
| `skill_id` | `task_input.skill_id` | always |
| `task_type` | `task_input.task_type` | always |
| `input_artifacts` | `task_input.input_artifacts` | always |
| `optional_input_artifacts` | `getattr(task_input,"optional_input_artifacts",[])` | always |
| `model_preference` | `task_input.model_preference` | always |
| `source_repo` | `task_input.source_repo` | only if truthy |
| `artifact_repo` | `task_input.artifact_repo` | **WORKER client only**, only if truthy (api client omits) |
| `artifact_ref` | `task_input.artifact_ref` | **WORKER client only**, only if truthy (api client omits) |
| `workspace_key` | `task_input.workspace_key` | only if truthy |
| `extras` | `dict(task_input.context)` | only if `context` non-empty |

⚠️ G4 detail: the api client (`olympus-api/.../agent_client.py:73-92`) does **NOT** add
`artifact_repo`/`artifact_ref` to the context; the worker client
(`olympus-worker/src/agent_client.py:89-114`, specifically `:103-106`) DOES. Skills that need to
know where to commit behave differently depending on which client is loaded. Reproduce both.

**Priors:** "context priors" (human-authored prior opinions) are NOT a first-class field on
the wire. The workflow folds them into `AgentTaskInput.context["context_priors"]` upstream
(see `load_context_priors` activity / `ContextPrior`, `types.py:2850`); they therefore
travel via the `extras` key (and are also inline-rendered into the task message). So
"how priors assemble into the call" = they ride inside `context.extras` and the prompt string,
exactly like any other `context` entry. No separate transport.

**HTTP POST body** (`{agent_url}/a2a/tasks`):
```json
{
  "task": "<task_message>",
  "context": { ...as above... },
  "model_preference": "<task_input.model_preference or ''>"
}
```
⚠️ G9: `model_preference` is sent as `task_input.model_preference or ""` — an EMPTY string when
the caller set no preference. The clients' inline comment (api `:222-228`, worker `:318-324`)
is load-bearing: sending a hard-coded `"tier-2"` here would clobber the agent runtime's own
resolution (it reads the skill's declared tier as `tier_hint` from the skill-dispatch API) and
force every Opus-declared skill down to Sonnet. So you MUST forward empty-when-unset, NOT a
default tier. Model selection is delegated to the runtime; `result.model_used` reports what was
actually chosen.

### 5.2 HTTP transport + 503 handling

**api client** (`olympus-api/src/services/agent_client.py:180-250`, POST at `:216-234`): single
`async with httpx.AsyncClient(timeout=task_input.timeout_seconds) as client:` POST →
`resp.raise_for_status()` → `response = resp.json()`. No 503 special-casing.

**worker client** (`olympus-worker/src/agent_client.py`, `dispatch_via_a2a` `:281-349`):
`_post_with_saturation_retry(agent_url, payload, timeout=task_input.timeout_seconds, task_id)` (`:204-278`):
- Loop `attempt` in `1.._RETRY_ON_503_MAX_ATTEMPTS` (=5):
  - fresh `httpx.AsyncClient(timeout=timeout)` POST `{agent_url}/a2a/tasks`.
  - `if resp.status_code != 503: resp.raise_for_status(); return resp.json()`.
  - On 503: if last attempt → break; else compute delay: honor `Retry-After` header (float; bad header → 0.0) vs exponential backoff `min(_BASE_DELAY_S * _BACKOFF**(attempt-1), _MAX_DELAY_S)` = `min(1.0 * 2.0**(attempt-1), 30.0)`; `delay = max(retry_after_s, backoff_s) + random.uniform(0, 0.5)` (jitter so N workers don't retry in lockstep); `await asyncio.sleep(delay)`.
  - After loop: `last_resp.raise_for_status()` (a 503 raises `httpx.HTTPStatusError`).
- Constants (`:46-49`): `_RETRY_ON_503_MAX_ATTEMPTS=5`, `_RETRY_ON_503_BASE_DELAY_S=1.0`, `_RETRY_ON_503_BACKOFF=2.0`, `_RETRY_ON_503_MAX_DELAY_S=30.0`.
- Rationale (`:210-228`, in the `_post_with_saturation_retry` docstring): the `olympus-agent` HAProxy LB already does `option redispatch` + `retry-on 503` across replicas, so a 503 reaching the client means **every** replica is saturated; the client absorbs pool-wide saturation locally instead of bubbling to Temporal. All non-503 HTTP errors bubble via `raise_for_status` → become exceptions in §3.6's `except Exception` → classified by `_is_retryable` (503 is gone by then; a persistent 503 → HTTPStatusError message → `_is_retryable` default True → RetryableError → Temporal `agent_failure` retry).

### 5.3 Response → `AgentTaskResult` mapping (`_extract_result`, identical in both clients)

api `:95-177` / worker `:117-201`. `duration_ms = int(time.time()*1000) - start_time_ms`.
Defaults: `output_artifacts=[]`, `output_files=[]`, `token_usage_input=0`,
`token_usage_output=0`, `cost_estimate_usd=0.0`, `status=COMPLETED`, `error=""`,
`model_used=""` (the `model_used` param passed in is `""`).

If `isinstance(response, dict)`:
- `output_artifacts` ← `[str(a) for a in response["output_artifacts"]]` if it's a list.
- `output_files` ← for each `f` in `response["output_files"]` (if list): only when `isinstance(f,dict) and "path" in f and "content" in f`, append `OutputFile(path=f["path"], content=f["content"], encoding=f.get("encoding","utf-8"))`.
- `token_usage` ← `response.get("token_usage",{})`; if dict: `token_usage_input=int(usage["input"])` (only if int/float, else 0), `token_usage_output=int(usage["output"])` (same guard).
- `cost_estimate_usd` ← `float(response["cost_estimate_usd"])` if int/float else 0.0.
- `model_used` ← `response["model_used"]` if a non-empty str (overrides `""`).
- `status` ← `TaskStatus.FAILED` iff `response["status"] == "failed"`, and `error = str(response.get("error",""))`. Any other status value (or missing) leaves `status=COMPLETED`.

Returns `AgentTaskResult(task_id=<dispatcher's task_id>, status, output_artifacts,
output_files, model_used, duration_ms, token_usage_input, token_usage_output,
cost_estimate_usd, error)`.

⚠️ The dispatcher NEVER raises on a failed-status response — it returns a FAILED result; the
*activity* (§3.6 step 3) is what converts that into a `RetryableError`.

### 5.4 Mock dispatcher (AGENT_RUNTIME_MODE=mock)

`olympus-worker/src/testing/mock_agent_runtime.py:311-357` `dispatch_via_mock(agent_url,
task_input, model_used="")`: `agent_url`/`model_used` accepted but unused. Resolves a fixture:
- `scenario = str(task_input.context.get("fixture_scenario"))` if `context` set and key present, else None.
- `fixture = load_fixture(task_input.skill_id, scenario)` (`:221-276`): looks under `OLYMPUS_SKILLS_ROOT or <repo>/cross-cutting/skills/<skill_id>/fixtures/*.json`. If `scenario is None` and >1 fixture → `FixtureResolutionError`. If `scenario` given but file missing → `FixtureResolutionError`. No dir/files → `FixtureNotFoundError`. Validates shape (`_validate_shape`) and materializes (`_materialize`) into an `AgentTaskResult` with `task_id=f"mock-{uuid4().hex[:8]}"`.
- If `result.duration_ms == 0`, fills it with `max(elapsed_ms, 1)` (rebuilt as a new `AgentTaskResult`).
- A fixture with `result.status=="failed"` (and required non-empty `error`) flows through the same FAILED→RetryableError path in §3.6.

Fixture file shape (`mock_agent_runtime.py:25-50`): top-level `skill_id`, `scenario`,
`description`, `result{status, output_artifacts, output_files[{path,content,encoding}],
model_used, token_usage{input,output}, cost_estimate_usd, duration_ms, error}`.

---

## 6. DB SCHEMA — `agent_task` and `step_execution` (target tables)

### 6.1 `agent_task` (migration 003 `:82-106`, extended by 027 + 044 + 050)

Base columns (003): `id UUID PK default gen_random_uuid()`, `task_type VARCHAR(100) NOT NULL`,
`application_id UUID FK application(id) ON DELETE CASCADE` (003 had NOT NULL; **044 relaxed to
nullable**), `module_name VARCHAR(255) NULL`, `status task_status_enum NOT NULL default
'queued'`, `agent_backend VARCHAR(100) NULL`, `agent_session_id VARCHAR(255) NULL`,
`model_requested VARCHAR(100) NULL`, `model_used VARCHAR(100) NULL`, `model_source
VARCHAR(100) NULL`, `dispatched_at TIMESTAMPTZ NULL`, `completed_at TIMESTAMPTZ NULL`,
`duration_ms BIGINT NULL`, `retry_count INT NOT NULL default 0`, `last_error TEXT NULL`,
`input_artifact_refs JSONB NULL`, `output_artifact_ref TEXT NULL`, `token_usage JSONB NULL`,
`cost_estimate NUMERIC NULL`.

Migration 027 added (`027_extend_agent_task_for_metrics.py:117-164`): `agent_id VARCHAR(100)`,
`skill_id VARCHAR(150)`, `workflow_id VARCHAR(255)`, `started_at TIMESTAMPTZ`,
`input_tokens INT`, `output_tokens INT`, `cache_read_tokens INT`, `cache_write_tokens INT`,
`quality_score NUMERIC(3,2)`, `error_code VARCHAR(100)`, `artifact_id UUID` — all nullable.
Plus the `agent_benchmark` view. ⚠️ **CHANGED at HEAD:** `skill_id` IS now written by
`dispatch_agent_task` (see §2.2 / G2), so the benchmark view's `skill_id` grouping rolls up
dispatch rows. The OTHER 027 metric columns (`agent_id`, `input_tokens`, `output_tokens`,
`cache_*_tokens`, `quality_score`, `error_code`, `artifact_id`, `workflow_id`, `started_at`)
are still NULL from this path.

Migration 044 (`044_agent_task_wave_scoped.py`): `application_id`→nullable; add `wave_id UUID
NULL FK wave(id) ON DELETE CASCADE`; CHECK `agent_task_application_or_wave_ck` =
`(application_id IS NOT NULL AND wave_id IS NULL) OR (application_id IS NULL AND wave_id IS NOT
NULL)`; index `ix_agent_task_wave_id`.

Migration 050 (`050_capability_system_grain.py:604-660`) added the **human-task discriminator**
columns: `actor_kind VARCHAR(32) NOT NULL DEFAULT 'olympus_agent'`, `human_user_id VARCHAR(255)
NULL`, `local_agent_descriptor JSONB NULL`; CHECK `agent_task_actor_kind_chk` =
`actor_kind IN ('olympus_agent','human','human_with_agent')`; CHECK
`agent_task_actor_kind_human_id_chk` = `(actor_kind='olympus_agent' AND human_user_id IS NULL) OR
(actor_kind IN ('human','human_with_agent') AND human_user_id IS NOT NULL)`. Also a
`agent_task_session_artifact` child table. ⚠️ `dispatch_agent_task` NEVER sets `actor_kind`, so
its rows default to `'olympus_agent'`; the human values are written ONLY by `dispatch_human_task`
(see `human_task.md`). The default keeps backward compat — every reader that ignores
`actor_kind` keeps working.

`task_status_enum` (migration 001, repeated in 003 `:29-33`): `queued`, `dispatched`,
`running`, `completed`, `failed`, `timed_out`.

### 6.2 `step_execution` (migration 033 `:99-166`)

`execution_id UUID PK default gen_random_uuid()`, `app_id UUID NULL`, `wave_id UUID NULL`,
`portfolio_id UUID NOT NULL`, `line_id VARCHAR(64) NOT NULL`, `step_id VARCHAR(128) NOT NULL`,
`step_kind step_execution_kind_enum NOT NULL`, `status step_execution_status_enum NOT NULL`,
`started_at TIMESTAMPTZ NULL`, `completed_at TIMESTAMPTZ NULL`, `duration_ms BIGINT NULL`,
`attempt INT NOT NULL default 1`, `last_error TEXT NULL`,
`input_artifacts JSONB NOT NULL default '[]'`, `output_artifacts JSONB NOT NULL default '[]'`,
`payload JSONB NOT NULL default '{}'`, `workflow_id VARCHAR(255) NOT NULL`,
`agent_task_id UUID NULL FK agent_task(id) ON DELETE SET NULL`, `gate_id UUID NULL`.

CHECKs: `step_execution_agent_fk_ck` = `(step_kind='agent') = (agent_task_id IS NOT NULL)`;
`step_execution_gate_fk_ck` = `(step_kind='gate') = (gate_id IS NOT NULL)`. ⚠️ G1: this is WHY
`_emit_agent_start` returns None when `agent_task_id is None` — an agent-kind row WITHOUT an
`agent_task_id` violates the CHECK and the INSERT would fail. The activity guards against
emitting an invalid row.

`step_execution_kind_enum`: `agent, git, gate, code, terminal`.
`step_execution_status_enum`: `queued, running, completed, failed, timed_out, skipped,
escalated, abandoned`.

---

## 7. CONSOLIDATED GOTCHAS

- **G1** — Agent-kind `step_execution` rows REQUIRE `agent_task_id` (CHECK `step_execution_agent_fk_ck`). `_emit_agent_start` returns None (no emission) if the `agent_task` insert returned None, to avoid violating it. Cascading: no start row ⇒ `exec_id is None` ⇒ `_emit_agent_complete` is a no-op.
- **G2** — ⚠️ **CHANGED at HEAD.** The skill id is now written to **BOTH** `agent_task.module_name` AND the dedicated migration-027 `agent_task.skill_id` column (`input.skill_id` bound to params `$5` and `$6` of the INSERT, `:191-208`). The prior baseline wrote only `module_name` and left `skill_id` NULL; the `agent_benchmark` view (which groups by `skill_id`) NOW rolls up dispatch rows' skill. The other migration-027 metric columns remain NULL on this path.
- **G3** — Lazy `from src.agent_registry...` / `from src.fallback_adapter...` imports resolve against `olympus-worker/src` as top-level `src`. Wrong import root ⇒ silent fallthrough to subprocess fallback.
- **G4** — Dispatcher import preference: `olympus_api.src.services.agent_client.dispatch_via_a2a` is tried FIRST, the worker's `src.agent_client.dispatch_via_a2a` only on ImportError. The two clients differ (503 retry + `artifact_repo`/`artifact_ref` context only in the worker client). Behavior depends on which package is importable.
- **G5** — Each Temporal retry of `dispatch_agent_task` inserts a NEW `agent_task` row (`uuid.uuid4()`) and a NEW `step_execution` row. No dedupe. Accepted telemetry duplication.
- **G6** — Every DB helper opens + closes its own `asyncpg.connect`; no pool. Four DB round trips per successful dispatch (insert + start-emit + update + complete-emit), each a fresh connection.
- **G7** — `step_execution.duration_ms` is computed in SQL (`EXTRACT(EPOCH FROM (completed_at - started_at))*1000`) from the row's own `started_at`. `agent_task.duration_ms` comes from `result.duration_ms` (computed by the dispatcher as wall-clock around the HTTP call). The two durations differ in scope.
- **G8** — `update_agent_task_output_ref` is registered in `worker.py` but missing from `activities/__init__.py.__all__`; workflows import it directly. Still a valid registered activity.
- **G9** — `model_preference` MUST be forwarded as `"" ` when unset, never a default tier — sending `"tier-2"` clobbers the runtime's per-skill tier resolution and downgrades Opus skills to Sonnet.
- **G10** — `cost_estimate` UPDATE param is `float(result.cost_estimate_usd or 0.0) or None`: a genuine `0.0` cost writes SQL NULL (the trailing `or None`), not `0`.
- **G11** — `_update_agent_task_row` forces `status='failed'` whenever an `error` arg is non-empty, overriding the `result.status` enum value. ⚠️ Consequence at HEAD: a `TaskStatus.TIMED_OUT` agent result (which §3.6 step 3 now propagates) passes a non-empty `_err`, so the `agent_task` row is persisted with `status='failed'`, NOT `'timed_out'` — the `timed_out` enum token is never written to `agent_task` by this path.
- **G12** — The docstring in `_insert_agent_task_row` cites "migration 043" for the wave schema; the actual migration is **044** (043 is `wave_failed_status`). Don't let the doc bug drive the schema.
- **G13** — The heartbeat-loop cleanup uses `asyncio.sleep(0)` (one tick), deliberately NOT `await _heartbeat_task`, to avoid masking the real exit path with a re-raised `CancelledError` from the `finally`.
- **G14** — On the primary path's `except Exception` (non-failed-result errors) and the subprocess-failure path, `_emit_agent_complete` is called WITHOUT `artifact_repo`/`artifact_ref`, so the failed `step_execution` row carries no `output_artifacts`. The failed/timed-out-RESULT paths (status in FAILED/TIMED_OUT) DO pass the refs.
- **G15** — Two independent error classifiers: the activity-local `_is_retryable(msg)` (message-substring, default-retryable, 6 non-retryable keywords) decides typed raises inside the body; the decorator's `_is_retryable_error(err)` (type-repr substring) is only a backstop for un-typed escapes. Both must be reproduced.
- **G16** — ⚠️ **NEW at HEAD.** The primary-path failure check (`:500`) now triggers on `result.status in (TaskStatus.FAILED, TaskStatus.TIMED_OUT)`, not just `FAILED`. A timed-out dispatch is raised as `RetryableError(f"Agent task {result.status.value}: {_err}")` → Temporal retries it under `agent_failure`. This is deliberate: a `TIMED_OUT` result carries empty `output_files`; if it fell through to the success path, steps with a non-retryable empty-output guard (e.g. PRA's `EmptyPortfolioRedundancyPlan`) would fail the whole wave instead of getting a fresh retry. ⚠️ The SUBPROCESS fallback's failure check (`:599`) was NOT updated — it still tests `== TaskStatus.FAILED` only (a subprocess `TIMED_OUT` would fall through to success there; moot because the subprocess fallback is disabled by default).
