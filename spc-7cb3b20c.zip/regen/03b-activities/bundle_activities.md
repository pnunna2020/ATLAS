# Activity Group Spec — `bundle_activities` (W20 delegated-bundle lifecycle + reaper)

**Source of truth:** `temporal/olympus_workflows/activities/bundle_activities.py`
**Backing service layer (MUST be reproduced for parity — see §6):**
`olympus-api/src/services/bundle.py`, `olympus-api/src/services/bundle_contract.py`,
`olympus-api/src/models/bundle.py`
**Backing DDL:** `db/alembic/versions/057_create_delegated_bundle.py`
**Backing reaper workflow (the "W20 reaper"):** `temporal/olympus_workflows/workflows/bundle_reaper.py`
**Backing mixin / signals (consumers):** `temporal/olympus_workflows/workflows/bundle_helpers.py`, `temporal/olympus_workflows/types.py`

**HEAD:** `7cb3b20c`. ⚠️ **REFRESHED to HEAD — this file grew substantially.** `bundle_activities.py` now defines **FOUR** `@foundry_activity` functions (the prior baseline had two). The two new ones are **`load_portfolio_delegation_activity`** (read delegation.yaml once at run start) and **`resolve_dispatch_mode`** (the §2.2 layered delegate-vs-internal trigger evaluator). All line citations have moved (see each section). Two BEHAVIORAL changes since the baseline: (1) `dispatch_delegated_bundle` now captures the dispatching Temporal `workflow_id` and persists it on the bundle row (migration **063**); (2) `expire_due_bundles_activity` now returns the REAL `workflow_id` (no longer hardcoded `""`), so the reaper actually signals parent workflows.

This file documents **all four `@foundry_activity` functions** plus the module-level helpers they depend on, and the entire bundle service write path they invoke. Behavioral parity REQUIRES the §6 service+DDL reproduction because the activities are thin shells — almost all observable behavior (every SQL write, every column, every default, every state transition) lives in the service layer the activities delegate to.

---

## 0. PREAMBLE — the `@foundry_activity` wrapper (applies to ALL FOUR activities here)

All four activities are decorated `@foundry_activity(config=ActivityConfig(enable_observability=True))` from `foundry_temporal.activities` — decorators at `bundle_activities.py:322` (`load_portfolio_delegation_activity`), `:347` (`dispatch_delegated_bundle`), `:467` (`resolve_dispatch_mode`), `:532` (`expire_due_bundles_activity`). **NOT** plain `@activity.defn`. Reproduce the wrapper EXACTLY (`foundry_temporal/activities.py:107-165`):

`foundry_activity(config=None, name=None, **activity_kwargs)` returns a decorator that:
1. Resolves `activity_config = config or ActivityConfig()`.
2. Applies `@activity.defn(name=name, **activity_kwargs)` to an inner `@wraps(func)` `wrapper` (so `@wraps` preserves `__wrapped__` — tests call `dispatch_delegated_bundle.__wrapped__(...)` to bypass the Temporal activity context; the wrapped fn is reachable at `.__wrapped__`).
3. `activity_name = name or func.__name__` (no explicit `name=` is passed by any bundle activity, so the registered Temporal activity name == the Python function name: `load_portfolio_delegation_activity`, `dispatch_delegated_bundle`, `resolve_dispatch_mode`, `expire_due_bundles_activity`).
4. **Observability** (because `enable_observability=True`): logs via `get_logger()` (`foundry_temporal.logging`):
   - On entry: `info("Activity {activity_name} starting", extra={"inputs": args if log_inputs else None})`. `ActivityConfig` defaults `log_inputs=False`, so `inputs=None`.
   - On success: `info("Activity {activity_name} completed", extra={"outputs": result if log_outputs else None})`. `log_outputs=False` default → `outputs=None`.
   - On exception: `error("Activity {activity_name} failed: {error}", extra={"error": str(error)})`.
5. **Error wrapping** (because `ActivityConfig.enable_error_wrapping=True` default — neither activity overrides it):
   - If the raised error `isinstance(error, (WorkflowError, ApplicationError))` → `raise` (re-raise unchanged; preserves the original `non_retryable` flag).
   - `elif _is_retryable_error(error)` → `raise RetryableError(f"Retryable error in {activity_name}: {error}") from error`.
   - `else` → `raise NonRetryableError(f"Non-retryable error in {activity_name}: {error}") from error`.
   - `_is_retryable_error(error)` (`foundry_temporal/activities.py:168-183`) is a **STRING-MATCH ON THE TYPE NAME**, NOT the rich `errors.is_retryable_error`. It computes `error_str = str(type(error)).lower()` and returns `True` iff any of these substrings appear: `timeout, connection, network, temporary, unavailable, overload, busy, throttle, rate_limit`.
   - ⚠️ **GOTCHA (consequence for these activities):**
     - `WorkflowError`/`RetryableError`/`NonRetryableError` (`foundry_temporal/errors.py:10-28`) all subclass `temporalio.exceptions.ApplicationError`, so any error already of those types passes straight through with its own `non_retryable` flag.
     - A `ValueError` raised by `dispatch_delegated_bundle`'s own validation (unknown scope_kind, both/neither app/wave, empty target_id, bad UUID) has `str(type(error))` == `"<class 'ValueError'>"` → contains none of the retryable substrings → wrapped as **`NonRetryableError`** ⇒ Temporal will **not** retry it. This is desirable: bad input never retries. (Tests invoke `__wrapped__` so they see the raw `ValueError`; in-workflow execution sees `NonRetryableError`.)
     - `fastapi.HTTPException` raised inside the service layer (e.g. `BUNDLE_UNKNOWN_GATE` 400, `Application not found` 404) → `str(type(error))` == `"<class 'fastapi.exceptions.HTTPException'>"` → no retryable substring → wrapped **`NonRetryableError`**. Bundle dispatch against an unknown gate/step or a missing app/wave fails permanently (correct — re-running won't help).
     - A transient DB error whose type name contains e.g. `Timeout`/`Connection` (many `asyncpg`/SQLAlchemy disconnect classes do — `ConnectionDoesNotExistError`, `TimeoutError`, `OperationalError`→via "operational"? NO: "operational" is not in the list) is matched only by literal substring. `asyncpg.exceptions.ConnectionDoesNotExistError` → "connection" matches → `RetryableError`. A generic `sqlalchemy.exc.OperationalError` → "operationalerror"… contains neither "connection" nor "timeout" → would be wrapped **NonRetryable**. ⚠️ The classification is therefore best-effort and substring-driven; a rebuild MUST copy the exact substring list, not invent a smarter classifier.

`ActivityConfig` dataclass fields (`foundry_temporal/activities.py:27-39`): `retry_policy, start_to_close_timeout, schedule_to_close_timeout, schedule_to_start_timeout, heartbeat_timeout` (all `None`), `enable_observability=True`, `enable_error_wrapping=True`, `log_inputs=False`, `log_outputs=False`. **The bundle activities pass only `enable_observability=True`; every other field is its default.** ⚠️ No timeouts/retry are set on the decorator — they come from the **caller** (`workflow.execute_activity(..., start_to_close_timeout=..., retry_policy=...)`), see §3/§4.

---

## 1. Module-level infrastructure (shared by both activities)

### 1.1 `_build_async_database_url() -> str` (`bundle_activities.py:69-82`)
Composes `postgresql+asyncpg://{user}:{encoded}@{host}:{port}/{name}` from component env vars (NOT a monolithic `DATABASE_URL`):
| env var | default |
|---|---|
| `DATABASE_HOST` | `localhost` |
| `DATABASE_PORT` | `5432` |
| `DATABASE_NAME` | `olympus` |
| `DATABASE_USER` | `olympus` |
| `DATABASE_PASSWORD` | `olympus` |

Password is URL-encoded via `urllib.parse.quote_plus(password)` (database-connection-string-composition rule). Mirrors `olympus-api/src/config.py:get_async_database_url`.

### 1.2 `_bundle_session()` — async context manager (`bundle_activities.py:86-108`)
- `@asynccontextmanager`, yields `AsyncSession`.
- Builds a **fresh engine PER activity invocation**: `create_async_engine(_build_async_database_url(), pool_pre_ping=True, pool_recycle=300, pool_timeout=30, pool_size=2, max_overflow=2)`.
- `factory = async_sessionmaker(engine, expire_on_commit=False)`; yields `async with factory() as session`.
- `finally: await engine.dispose()`.
- ⚠️ **GOTCHA — intentional per-call engine churn.** Temporal worker processes don't run `init_db`; the API layer's process-global `_async_session_factory` is request-scoped and not importable here. So each activity invocation creates AND disposes an engine. Do not "optimize" this into a module-global engine — replay/process isolation depends on it and pool-recycle settings are intentionally irrelevant across the activity boundary. `async with` guarantees no session leak even on exception.

### 1.3 Fallback-policy + delegation-policy constants & loaders
```
_DEFAULT_FALLBACK_POLICY = "internal_fallback"                                   # :116
_VALID_FALLBACK_POLICIES = frozenset({"internal_fallback","escalate","fail","redispatch"})  # :117-119
```

**`_profiles_root() -> Path | None`** (`:122-139`): if `OLYMPUS_PROFILES_DIR` set and is a dir → return it; else walk up from `Path(__file__).resolve()` through `(here, *here.parents)` returning the first `parent/"profiles"` that `is_dir()`; else `None`. (Mirrors worker_bootstrap candidate-walk.)

**`_read_delegation_yaml(profile_id: str | None) -> dict | None`** (`:186-215`) — ⚠️ **NEW shared parse helper at HEAD** (the YAML read was extracted out of `load_fallback_policy_for_portfolio` so both loaders share it). Returns `None` (callers treat as "no delegation config declared") when:
1. `if not profile_id: return None`.
2. `root = _profiles_root()`; `if root is None: return None`.
3. `yaml_path = root / profile_id / "delegation.yaml"`; `if not yaml_path.is_file(): return None`.
4. `try:` local `import yaml`; `with yaml_path.open() as f: data = yaml.safe_load(f) or {}`. `except Exception:` log `warning("delegation.yaml load failed for profile %s: %s", profile_id, exc)` → `return None`.
5. `if not isinstance(data, dict): return None`; else `return data`.

**`load_fallback_policy_for_portfolio(profile_id: str | None) -> str`** (`:142-183`) — ⚠️ **REFACTORED at HEAD** (now thin over `_read_delegation_yaml`). Returns one of the 4 valid policy strings, defaulting to `internal_fallback`:
1. `data = _read_delegation_yaml(profile_id)`; `if data is None: return "internal_fallback"`.
2. `policy = data.get("fallback_policy")`; `if not isinstance(policy, str): return "internal_fallback"`.
3. `policy = policy.strip()`; `if policy not in _VALID_FALLBACK_POLICIES:` log `warning("Unknown fallback_policy %r ... defaulting to %s", policy, profile_id, "internal_fallback")` → return default.
4. else `return policy`.
- YAML shape (top-level, backward-compat): `fallback_policy: internal_fallback   # | escalate | fail | redispatch`.
- ⚠️ **STUB application unchanged:** the loader resolves the string ONLY; actual *application* of the policy is still deferred (design §3.7). It IS now called — by `load_portfolio_delegation_activity` (§3a) at run start; `expire_due_bundles_activity` still reads `fallback_policy` straight off the DB row.
- Tested cases: `None` → default; unknown profile → default; explicit `escalate` → `"escalate"`; `not_a_real_policy` → default; malformed YAML → default; repo FAA profile `faa` → `"internal_fallback"`.

**`_DEFAULT_DELEGATION_POLICY: dict[str, Any]`** (`:222-227`) — ⚠️ **NEW at HEAD.** The conservative Layer-(c) default: `{"default_delegation": "disabled", "delegated_steps": [], "default_expires_hours": 168, "bundle_scope_kind": "gate_packet"}`.

**`load_delegation_policy_for_portfolio(profile_id: str | None) -> dict[str, Any]`** (`:230-271`) — ⚠️ **NEW at HEAD.** Resolves the optional `delegation:` block from the same `delegation.yaml` into a fully-normalised dict (every key present, filled from `_DEFAULT_DELEGATION_POLICY`):
1. `resolved = dict(_DEFAULT_DELEGATION_POLICY)`.
2. `data = _read_delegation_yaml(profile_id)`; `if data is None: return resolved`.
3. `block = data.get("delegation")`; `if not isinstance(block, dict): return resolved`.
4. `default_delegation` → set only if in `("enabled","disabled")`.
5. `delegated_steps` → if a list, `[str(s) for s in steps if s]` (drops falsy).
6. `default_expires_hours` → set only if `isinstance(int)` AND `>= 1`.
7. `bundle_scope_kind` → set only if in `("gate_packet","line_step")`.
8. `return resolved`.
- YAML shape (Layer-(c) block): `delegation: {default_delegation: disabled, delegated_steps: [], default_expires_hours: 168, bundle_scope_kind: gate_packet}`.

**`log_internal_fallback_stub(*, bundle_id, scope_kind, target_id, portfolio_id, application_id, wave_id, fallback_policy, reason) -> None`** (`:274-314`) — all keyword-only; `portfolio_id/application_id/wave_id` are `str | None`. Emits ONE `logger.warning("delegated-bundle.fallback.stub", extra={...})` with `extra` keys: `bundle_id, scope_kind, target_id, portfolio_id, application_id, wave_id, fallback_policy, reason, stub: True, todo: "internal_fallback dispatcher not yet implemented; follow-on chunk wires the equivalent skill chain."`.
- ⚠️ **STUB**: this structured warning is the ONLY behavior wired today for the fallback path. When a bundle expires/releases, the reaper/API emits `BundleExpiredSignal`; the dispatching workflow is supposed to consult `fallback_policy`, but the only thing actually executed is this log. Replace with the real dispatcher when the orchestration layer lands. Reproduce the `extra` dict EXACTLY (a log-scraping operator runbook depends on the keys/message string).

---

## 2. Domain enums & models referenced (from `olympus-api/src/models/bundle.py`)

These are imported **lazily inside the activity bodies** (not at module top — the API service layer pulls FastAPI/structlog/the whole models tree, undesirable at worker-import time). Reproduce as `str, Enum`:

- `BundleScopeKind`: `GATE_PACKET="gate_packet"`, `LINE_STEP="line_step"`.
- `BundleStatus` (7): `OFFERED="offered"`, `CLAIMED="claimed"`, `SUBMITTED="submitted"`, `ACCEPTED="accepted"`, `REJECTED="rejected"`, `EXPIRED="expired"`, `RELEASED="released"`.
- `BundleFallbackPolicy`: `INTERNAL_FALLBACK="internal_fallback"`, `ESCALATE="escalate"`, `FAIL="fail"`, `REDISPATCH="redispatch"`.
- `SessionArtifactKind`: `TRANSCRIPT="transcript"`, `PROMPT="prompt"`, `DIFF="diff"`, `SUMMARY="summary"`.
- `BundleContract` (resolver output): `scope_kind: BundleScopeKind`, `target_id: str`, `inputs: list[BundleArtifactRef]`, `outputs: list[BundleOutputRequirement]`, `metadata: BundleContractMetadata`.
- `BundleArtifactRef`: `artifact_kind: str`, `artifact_ref: str`, `description: str | None = None`.
- `BundleOutputRequirement`: `artifact_kind: str`, `schema_ref: str`, `required: bool = True`, `description: str | None = None`.
- `BundleContractMetadata`: `portfolio_id: uuid.UUID`, `application_id: uuid.UUID | None = None`, `wave_id: uuid.UUID | None = None`, `risk_tier: str | None = None`, `gate_id: str | None = None`, `step_id: str | None = None`.

(The wire-read models — `BundleDetail`, `BundleSummary`, etc. — are used by the API surface, not by these activities; covered in the Phase 8 API spec. They are NOT invoked on the activity write paths reproduced below.)

---

## 2A. ACTIVITY (NEW at HEAD) — `load_portfolio_delegation_activity`

`bundle_activities.py:322-339`. Decorated `@foundry_activity(config=ActivityConfig(enable_observability=True))`.

```python
async def load_portfolio_delegation_activity(profile_id: str | None) -> dict[str, Any]
```
- **One positional arg** `profile_id`. **Returns** `{"fallback_policy": str, "delegation": {...}}` — exactly `{"fallback_policy": load_fallback_policy_for_portfolio(profile_id), "delegation": load_delegation_policy_for_portfolio(profile_id)}` (§1.3). Pure file-I/O delegation; no DB.
- **Why an activity:** disk I/O (`delegation.yaml`) is forbidden in workflow code per the Temporal determinism rule, so a line workflow calls this ONCE at run start and caches the result for the run.
- **Errors:** the loaders never raise (they degrade to defaults), so the only escapes are unexpected `OSError`-class failures inside the YAML read — those are swallowed inside `_read_delegation_yaml` and return `None`/defaults. Effectively non-failing.

---

## 2B. ACTIVITY (NEW at HEAD) — `resolve_dispatch_mode` (the §2.2 layered trigger evaluator)

`bundle_activities.py:467-524`. Decorated `@foundry_activity(config=ActivityConfig(enable_observability=True))`.

Module constants (`:463-464`): `DISPATCH_MODE_INTERNAL_AGENT = "internal_agent"`, `DISPATCH_MODE_DELEGATED_BUNDLE = "delegated_bundle"`. ⚠️ Kept as plain strings (NOT an enum) so they round-trip through Temporal's payload layer; the base-workflow helper compares against these literals.

```python
async def resolve_dispatch_mode(
    scope_kind: str, target_id: str, app_id: str | None, wave_id: str | None,
    profile_id: str | None, is_delegatable: bool,
) -> str
```
**Returns** `"delegated_bundle"` or `"internal_agent"`. Deterministic, observable, no ML routing. Control flow (reproduce EXACTLY — the layer ORDER is load-bearing):
1. **Layer (b) eligibility gate (`:497-498`):** `if not is_delegatable: return DISPATCH_MODE_INTERNAL_AGENT`. ⚠️ A non-delegatable step is NEVER delegated regardless of higher layers — this short-circuits BEFORE any DB read or profile load.
2. Lazy `from src.services import bundle as bundle_svc` (`:500`).
3. `application_id_uuid = uuid.UUID(app_id) if app_id else None`; `wave_id_uuid = uuid.UUID(wave_id) if wave_id else None` (`:502-503`). ⚠️ A malformed UUID raises `ValueError` → decorator wraps NonRetryable.
4. **Layer (a) open-bundle wins (`:506-515`):** inside `async with _bundle_session() as db:` → `exists = await bundle_svc.active_bundle_exists(db, scope_kind=scope_kind, target_id=target_id, application_id=application_id_uuid, wave_id=wave_id_uuid)` (§6.0). `if exists: return DISPATCH_MODE_DELEGATED_BUNDLE`. ⚠️ NOTE `scope_kind` is passed as the raw string here (NOT converted to `BundleScopeKind`) — `active_bundle_exists` matches the string column directly.
5. **Layer (c) portfolio default policy (`:517-522`):** `policy = load_delegation_policy_for_portfolio(profile_id)` (§1.3); `if policy.get("default_delegation") == "enabled": return DELEGATED`; `if target_id in (policy.get("delegated_steps") or []): return DELEGATED`.
6. Else `return DISPATCH_MODE_INTERNAL_AGENT` (`:524`).
- **Why an activity:** Layer (a) needs a DB read and Layer (c) reads `delegation.yaml` — both are I/O, forbidden in workflow code.
- **Errors:** validation/UUID `ValueError` → NonRetryable; a transient DB error in `active_bundle_exists` → classified by the decorator substring rule (connection/timeout → Retryable, else NonRetryable).

---

## 3. ACTIVITY — `dispatch_delegated_bundle`

### 3.1 Signature & I/O
`bundle_activities.py:347-452` (decorator `:347`, `async def` `:348`). Decorated `@foundry_activity(config=ActivityConfig(enable_observability=True))`.

```python
async def dispatch_delegated_bundle(
    scope_kind: str,
    target_id: str,
    app_id: str | None,
    wave_id: str | None,
    expires_in_hours: int,
    fallback_policy: str,
    created_by_user_id: str,
) -> str
```
- **Positional args** (no dataclass). Caller pattern (`bundle_helpers.py:30-40`): `workflow.execute_activity(dispatch_delegated_bundle, args=["gate_packet","G-DA", input.app_id, None, 24*7, "internal_fallback", input.created_by], start_to_close_timeout=timedelta(seconds=30))`. ⚠️ No retry_policy is set by the documented caller → Temporal default retry applies; combined with the error-wrapper, validation/HTTPException errors become `NonRetryableError` and stop immediately.
- **Returns:** `str` — the new bundle id `str(bundle_id)`. ⚠️ **GOTCHA — returns a STRING, not `uuid.UUID`.** `uuid.UUID` is not natively serialisable through Temporal's payload layer. Workflows key `BundleCompletedSignal`/`BundleExpiredSignal` on this string. Do NOT change the return type to UUID.
- **Scope rule:** exactly ONE of `app_id` / `wave_id` must be truthy (XOR).

### 3.2 Control flow (reproduce EXACTLY)
1. Lazy imports: `from src.models.bundle import BundleFallbackPolicy, BundleScopeKind`; `from src.services import bundle as bundle_svc`; `from src.services import bundle_contract`.
2. **Validate scope_kind:** `try: scope = BundleScopeKind(scope_kind)` `except ValueError: raise ValueError(f"Unknown bundle scope_kind {scope_kind!r}; expected one of {[k.value for k in BundleScopeKind]}") from exc`. (Test: `match="Unknown bundle scope_kind"`.)
3. **Validate target_id:** `if not isinstance(target_id, str) or not target_id.strip(): raise ValueError("target_id must be a non-empty string")`. (Test: `match="non-empty"`.)
4. **XOR scope:** `if bool(app_id) == bool(wave_id): raise ValueError("delegated bundle dispatch requires exactly one of app_id / wave_id; got app_id={app_id!r}, wave_id={wave_id!r}")`. ⚠️ Uses `bool(...)` so empty string `""` counts as "not set" just like `None`. Both-set OR neither-set both raise. (Test: `match="exactly one of"`.)
5. **UUID parse:** `application_id_uuid = uuid.UUID(app_id) if app_id else None`; `wave_id_uuid = uuid.UUID(wave_id) if wave_id else None`. ⚠️ A malformed UUID string raises `ValueError` here → wrapped `NonRetryableError`.
6. **Normalize fallback_policy:** `if fallback_policy not in _VALID_FALLBACK_POLICIES:` log `warning("Unknown fallback_policy %r for bundle dispatch; defaulting to %s", fallback_policy, "internal_fallback")`; set `fallback_policy = "internal_fallback"`. Then `fallback_enum = BundleFallbackPolicy(fallback_policy)`. (Test: bogus value → `dispatch` called with `BundleFallbackPolicy.INTERNAL_FALLBACK`.)
7. **Capture dispatching workflow_id (`:416-419`, ⚠️ NEW at HEAD):** `try: dispatching_workflow_id: str | None = activity.info().workflow_id` `except RuntimeError: dispatching_workflow_id = None`. ⚠️ Best-effort — when the activity runs OUTSIDE a workflow context (e.g. a direct integration test) `activity.info()` raises `RuntimeError` and we record `None`, which the reaper treats like an admin-created bundle (structured-log path, no signal).
8. **DB work** inside `async with _bundle_session() as db:` (single session for both calls):
   a. `contract = await bundle_contract.resolve(db, scope_kind=scope, target_id=target_id, application_id=application_id_uuid, wave_id=wave_id_uuid)` → see §6.1.
   b. `bundle_id = await bundle_svc.dispatch(db, contract=contract, fallback_policy=fallback_enum, expires_in_hours=expires_in_hours, created_by_user_id=created_by_user_id, dispatching_workflow_id=dispatching_workflow_id)` → see §6.2 (this is the persist path; it `commit()`s internally). ⚠️ NEW kwarg `dispatching_workflow_id`.
9. Log `info("delegated-bundle.dispatched", extra={bundle_id: str(bundle_id), scope_kind: scope.value, target_id, app_id, wave_id, expires_in_hours, fallback_policy, created_by_user_id, dispatching_workflow_id})` (⚠️ now ALSO logs `dispatching_workflow_id`).
10. `return str(bundle_id)`.

### 3.3 This is NOT an agent-dispatch activity
No skill selection, no agent call, no retry-with-feedback. It dispatches a **delegated bundle** (a unit of work handed to an external human/agent pair via the API/UI), not an agent task. The "dispatch" is pure DB persistence of an `offered` bundle row + its input/output-ref children.

### 3.4 Error/retry/idempotency
- Errors per §0. Validation `ValueError`s and service `HTTPException`s → `NonRetryableError`.
- **Idempotency:** NOT idempotent at the activity level — each successful call `INSERT`s a brand-new row with a fresh `uuid.uuid4()` (§6.2). BUT the DB enforces at-most-one-open-bundle-per-scope via the partial unique index `ux_bundle_one_open_per_scope` (§5.3): a second dispatch for the same `(scope_kind, target_id, COALESCE(application_id,0-uuid), COALESCE(wave_id,0-uuid))` while a prior bundle is still in a non-terminal state (`offered/claimed/submitted`) raises a unique-violation from Postgres → bubbles up → `NonRetryableError` (substring match on the violation class name typically fails → NonRetryable). Reproduce this index; it is the concurrency guard.

---

## 4. ACTIVITY — `expire_due_bundles_activity` (the W20 reaper backing)

### 4.1 Signature & I/O
`bundle_activities.py:532-600` (decorator `:532`, `async def` `:533`). Decorated `@foundry_activity(config=ActivityConfig(enable_observability=True))`.

```python
async def expire_due_bundles_activity() -> list[dict[str, str]]
```
- **No args.**
- **Returns:** `list[dict[str, str]]` — one dict per expired bundle: `{"bundle_id": str, "workflow_id": str}`. ⚠️ **CHANGED at HEAD:** `workflow_id` is now the REAL `dispatching_workflow_id` persisted at dispatch (migration 063), read back from the row as `row.get("dispatching_workflow_id") or ""`. The prior baseline hardcoded `""`. So workflow-dispatched bundles now carry a non-empty `workflow_id` and the reaper workflow ACTUALLY signals the parent (§7); only admin/manual-dispatched bundles (NULL `dispatching_workflow_id`) get `""` and the structured-log path.
- Caller: `BundleReaperWorkflow.run` (§7) via `workflow.execute_activity(expire_due_bundles_activity, start_to_close_timeout=timedelta(minutes=2), retry_policy=RETRY_POLICIES["transient"])`.

### 4.2 Control flow (reproduce EXACTLY)
1. Lazy imports inside body: `from sqlalchemy import text`; `from src.services import bundle as bundle_svc`.
2. `expired: list[dict[str, str]] = []`.
3. `async with _bundle_session() as db:` (single session — both the UPDATE and the per-row SELECTs share it so the reaper sees a consistent view):
   a. `bundle_ids = await bundle_svc.expire_due_bundles(db)` → §6.3 (UPDATE...RETURNING + commit). Returns `list[uuid.UUID]`.
   b. `for bid in bundle_ids:` post-fetch each bundle's metadata (⚠️ SELECT now ALSO reads `dispatching_workflow_id`):
      ```sql
      SELECT scope_kind, target_id, portfolio_id, application_id, wave_id,
             fallback_policy, dispatching_workflow_id
      FROM delegated_bundle WHERE id = :bid
      ```
      via `(await db.execute(text(...), {"bid": bid})).mappings().first()`.
      - `if row is None: continue` — ⚠️ **GOTCHA:** a bundle expired by another writer (or hard-deleted) between the service UPDATE and this SELECT yields `None`; the reaper skips it cleanly (tested: `test_expired_bundle_with_missing_row_skipped`). Note `expire_due_bundles` already `commit()`ted, so the rows are durably `expired`; this SELECT is a best-effort metadata re-read.
   c. `workflow_id = row.get("dispatching_workflow_id") or ""` (⚠️ CHANGED — was hardcoded `""`).
   d. **⚠️ CHANGED — the stub log is now CONDITIONAL:** `if not workflow_id:` → call `log_internal_fallback_stub(bundle_id=str(bid), scope_kind=row["scope_kind"], target_id=row["target_id"], portfolio_id=str(row["portfolio_id"]) if row.get("portfolio_id") else None, application_id=str(row["application_id"]) if row.get("application_id") else None, wave_id=str(row["wave_id"]) if row.get("wave_id") else None, fallback_policy=row["fallback_policy"], reason="expired")`. The prior baseline emitted this stub for EVERY expired bundle; now it fires ONLY for bundles with no parent workflow (admin/manual/pre-063 dispatches) — workflow-dispatched bundles are signalled by the reaper instead and skip the stub.
      - ⚠️ Note the `row.get("portfolio_id")` truthiness guard before `str(...)`: `portfolio_id` is NOT NULL in DDL so it's always present, but `application_id`/`wave_id` are nullable → emitted as `None` (not `"None"`) when absent. `str(...)` is applied only when the value is truthy.
   e. `expired.append({"bundle_id": str(bid), "workflow_id": workflow_id})` (⚠️ unconditional — appended whether or not the stub fired).
4. `if expired: logger.info("delegated-bundle.reaper.expired-batch", extra={"count": len(expired)})`.
5. `return expired`.

### 4.3 Error/retry/idempotency
- Errors per §0. Caller passes `RETRY_POLICIES["transient"]` (== `HTTP_RETRY_POLICY`: `initial_interval=1s`, `maximum_interval=15s`, `maximum_attempts=3`, `backoff_coefficient=2.0` — see `foundry_temporal/retry_policies.py:37-42`). So a transient DB blip retries up to 3 attempts; on exhaustion the reaper workflow's `try/except` swallows it and returns zeros (§7).
- **Idempotency:** YES, naturally idempotent. `expire_due_bundles` only matches `status='claimed' AND expires_at < now()`; once a row is flipped to `expired` it no longer matches, so a re-run after partial success expires only the still-eligible remainder (no double-processing of the same row by the SQL). The per-bundle stub log may re-emit for rows expired in a prior partial run only if those rows somehow re-enter `claimed` (they cannot — `expired` is terminal). Net: safe to retry.
- **Best-effort signalling:** the activity NEVER signals workflows itself; it returns the list and the reaper workflow does signalling. Bundles with no associated workflow get only the structured stub log (operator visibility), so a dead/unreachable workflow never silently drops the expiry notice.

---

## 5. DDL — the five `delegated_bundle*` tables (`db/alembic/versions/057_create_delegated_bundle.py`, rev `057`, down_revision `056`)

⚠️ These server-side defaults are LOAD-BEARING for the persist logic in §6 — the service INSERTs deliberately OMIT columns that the DB defaults (`id`, `created_at`, `updated_at`, `captured_at`, `submitted_at`-on-history, `required`, `status`). Reproduce them or the writes break.

### 5.1 `delegated_bundle` (primary)
| column | type | null | default | notes |
|---|---|---|---|---|
| `id` | UUID | no | `gen_random_uuid()` | PK |
| `portfolio_id` | UUID | no | — | FK→`portfolio.id` |
| `application_id` | UUID | yes | — | FK→`application.id` |
| `wave_id` | UUID | yes | — | FK→`wave.id` |
| `scope_kind` | String(32) | no | — | |
| `target_id` | String(128) | no | — | |
| `status` | String(32) | no | `'offered'` | |
| `claimed_by_user_id` | String(255) | yes | — | |
| `claimed_at` | TIMESTAMP | yes | — | |
| `expires_at` | TIMESTAMP | yes | — | set at CLAIM, null at dispatch |
| `submitted_at` | TIMESTAMP | yes | — | |
| `accepted_at` | TIMESTAMP | yes | — | |
| `local_agent_descriptor` | JSONB | yes | — | also stashes `_expires_in_hours` between dispatch & claim |
| `fallback_policy` | String(32) | no | `'internal_fallback'` | |
| `created_by_user_id` | String(255) | no | — | |
| `created_at` | TIMESTAMP | no | `now()` | |
| `updated_at` | TIMESTAMP | no | `now()` | |
| `dispatching_workflow_id` | String(255) | yes | — | ⚠️ **NEW — migration 063** (`063_bundle_dispatching_workflow.py`). The Temporal workflow_id that issued the bundle; NULL for admin/manual dispatches. Partial index `WHERE dispatching_workflow_id IS NOT NULL`. The reaper reads it to route the `bundle_expired` signal to the parent. |

CHECK constraints:
- `chk_bundle_scope_kind`: `scope_kind IN ('gate_packet','line_step')`.
- `chk_bundle_status`: `status IN ('offered','claimed','submitted','accepted','rejected','expired','released')`.
- `chk_bundle_app_or_wave`: `(application_id IS NOT NULL) OR (wave_id IS NOT NULL)`.
- `chk_bundle_claim_consistency`: `(status='offered' AND claimed_by_user_id IS NULL AND claimed_at IS NULL) OR (status IN ('claimed','submitted','accepted','rejected','released') AND claimed_by_user_id IS NOT NULL AND claimed_at IS NOT NULL) OR (status='expired')`. ⚠️ `dispatch` inserts `offered` with claim columns NULL precisely to satisfy this.
- `chk_bundle_fallback`: `fallback_policy IN ('internal_fallback','escalate','fail','redispatch')`.

Indexes: `ix_bundle_portfolio_status (portfolio_id, status)`; `ix_bundle_application_id (application_id)`; `ix_bundle_wave_id (wave_id)`; `ix_bundle_claimed_by (claimed_by_user_id) WHERE claimed_by_user_id IS NOT NULL`; `ix_bundle_expires_at (expires_at) WHERE status='claimed'` (this powers the reaper sweep).

### 5.2 Child tables
**`delegated_bundle_input_ref`:** `id` UUID PK `gen_random_uuid()`; `bundle_id` UUID NOT NULL FK→`delegated_bundle.id` `ON DELETE CASCADE`; `artifact_kind` String(64) NOT NULL; `artifact_ref` Text NOT NULL; `description` Text NULL. UNIQUE `uq_bundle_input_ref (bundle_id, artifact_ref)`. Index `ix_bundle_input_ref_bundle (bundle_id)`.

**`delegated_bundle_output_ref`:** `id` UUID PK `gen_random_uuid()`; `bundle_id` UUID NOT NULL FK CASCADE; `artifact_kind` String(64) NOT NULL; `schema_ref` Text NOT NULL; `required` Boolean NOT NULL `server_default=TRUE`; `description` Text NULL; `submitted_artifact_ref` Text NULL; `submitted_at` TIMESTAMP NULL. UNIQUE `uq_bundle_output_ref (bundle_id, artifact_kind)`. Index `ix_bundle_output_ref_bundle (bundle_id)`.

**`delegated_bundle_session_artifact`:** `id` UUID PK `gen_random_uuid()`; `bundle_id` UUID NOT NULL FK CASCADE; `kind` String(32) NOT NULL; `artifact_ref` Text NOT NULL; `hash` String(64) NULL; `captured_at` TIMESTAMP NOT NULL `server_default=now()`. CHECK `chk_bundle_session_kind`: `kind IN ('transcript','prompt','diff','summary')`. Index `ix_bundle_session_artifact_bundle (bundle_id)`.

**`delegated_bundle_validation_history`:** `id` UUID PK `gen_random_uuid()`; `bundle_id` UUID NOT NULL FK CASCADE; `submitted_at` TIMESTAMP NOT NULL `server_default=now()`; `submitted_by` String(255) NOT NULL; `outcome` String(32) NOT NULL; `violations` JSONB NULL. CHECK `chk_bundle_validation_outcome`: `outcome IN ('accepted','rejected')`. Index `ix_bundle_validation_history_bundle (bundle_id, submitted_at)`.

### 5.3 Concurrency guard (raw SQL, not `op.create_index`)
```sql
CREATE UNIQUE INDEX ux_bundle_one_open_per_scope
  ON delegated_bundle (
    scope_kind, target_id,
    COALESCE(application_id, '00000000-0000-0000-0000-000000000000'::uuid),
    COALESCE(wave_id,        '00000000-0000-0000-0000-000000000000'::uuid)
  )
  WHERE status NOT IN ('expired','released','rejected','accepted');
```
⚠️ At most one OPEN (non-terminal) bundle per scope tuple. NULL app/wave is normalized via COALESCE-to-zero-UUID so two NULL-app bundles still collide. This is the structural invariant behind `dispatch`'s non-idempotency guard (§3.4).

`downgrade()`: drop the 4 children, `DROP INDEX IF EXISTS ux_bundle_one_open_per_scope`, drop `delegated_bundle`.

---

## 6. BACKING SERVICE WRITE PATHS (MUST reproduce — column-by-column)

The activities delegate ALL persistence here. Reproduce these functions verbatim for parity. (Each opens NO session of its own — the activity passes `db`. The write paths `commit()` internally; the read paths do not.)

### 6.0 READ — `bundle.active_bundle_exists(db, *, scope_kind, target_id, application_id, wave_id) -> bool` (`bundle.py:304-351`) ⚠️ NEW at HEAD
Backs `resolve_dispatch_mode` Layer (a) (§2B). Read-only. Builds a clause list:
- always: `scope_kind = :scope_kind`, `target_id = :target_id`, `status NOT IN ('expired','released','rejected','accepted')` (the same open-predicate as `ux_bundle_one_open_per_scope`).
- if `application_id is not None`: add `application_id = :app_id AND wave_id IS NULL`.
- elif `wave_id is not None`: add `wave_id = :wave_id AND application_id IS NULL`.
- else (both None): `return False` (no scope to match).
- `SELECT 1 FROM delegated_bundle WHERE <AND-joined clauses> LIMIT 1`; `return row is not None`.
⚠️ The other-scope `IS NULL` clause means an app-scoped open bundle never matches a wave-scoped query for the same `target_id` and vice-versa.

### 6.1 `bundle_contract.resolve(db, *, scope_kind, target_id, application_id, wave_id) -> BundleContract` (`bundle_contract.py:466-505`)
Read-only (no writes). Produces the deterministic contract `dispatch` persists.
1. `if application_id is None and wave_id is None:` → `HTTPException(400, {"code":"BUNDLE_SCOPE_REQUIRED", "message":"Either application_id or wave_id must be set on a bundle dispatch."})`. (Defensive — the activity already XOR-validates.)
2. `risk_tier=None`. If `application_id is not None`: `portfolio_id, risk_tier = await _resolve_app_metadata(db, application_id)` and `inputs = await _default_inputs_for_app(db, application_id)`. Else: `portfolio_id = await _resolve_wave_metadata(db, wave_id)`, `inputs = await _default_inputs_for_wave(db, wave_id)`.
3. `outputs = _outputs_for(scope_kind, target_id)`.
4. Return `BundleContract(scope_kind, target_id, inputs, outputs, metadata=BundleContractMetadata(portfolio_id, application_id, wave_id, risk_tier, gate_id=target_id if scope is GATE_PACKET else None, step_id=target_id if scope is LINE_STEP else None))`.

**`_resolve_app_metadata`** (`:355-371`): `SELECT portfolio_id, risk_tier FROM application WHERE id = :aid`; `if row is None: HTTPException(404, "Application not found")`; return `(row["portfolio_id"], row.get("risk_tier"))`.
**`_resolve_wave_metadata`** (`:374-387`): `SELECT portfolio_id FROM wave WHERE id = :wid`; `if None: HTTPException(404, "Wave not found")`; return `row["portfolio_id"]`.
**`_default_inputs_for_app`** (`:390-429`): `SELECT p.artifact_repo_url AS portfolio_repo FROM application a JOIN portfolio p ON p.id = a.portfolio_id WHERE a.id = :aid`; `if None: return []`; if `repo := row.get("portfolio_repo")` truthy → one `BundleArtifactRef(artifact_kind="artifact-repo", artifact_ref=repo, description="Read-only handle to the portfolio's artifact repository. The pair clones, reads upstream artifacts, and pushes outputs into the same repo before submitting.")`. Else `[]`.
**`_default_inputs_for_wave`** (`:432-463`): same via `wave w JOIN portfolio p ON p.id = w.portfolio_id WHERE w.id = :wid`; description "Read-only handle to the portfolio's artifact repository — same starting context the internal wave reviewer would see."

**`_outputs_for(scope, target_id)`** (`:323-352`): if `scope is GATE_PACKET`: `if target_id not in _GATE_OUTPUTS:` → `HTTPException(400, {"code":"BUNDLE_UNKNOWN_GATE","message": f"Gate {target_id!r} is not in the bundle registry. Known gates: {known_gate_targets()}."})`; else return `[o.model_copy() for o in _GATE_OUTPUTS[target_id]]` (defensive deep copy so callers can't mutate the registry). Else (LINE_STEP): same against `_LINE_STEP_OUTPUTS`, error code `BUNDLE_UNKNOWN_STEP`. `known_gate_targets()`/`known_step_targets()` return `sorted(<dict>.keys())`.

⚠️ The registries `_GATE_OUTPUTS` and `_LINE_STEP_OUTPUTS` are hand-curated data-driven dicts — the single source of truth for a bundle's required outputs. Reproduce them VERBATIM (gate→outputs and step→outputs). Each value is a `list[BundleOutputRequirement]`:

`_GATE_OUTPUTS` (`bundle_contract.py:66-257`):
- `G-DC`: `application-catalog-entry` (`schemas/discovery/application-catalog-entry.schema.json`, req), `tech-fingerprint` (`schemas/discovery/tech-fingerprint.schema.json`, req), `analysis-report` (`schemas/discovery/analysis-report.schema.json`, req), `discovery-synthesis` (`schemas/discovery/discovery-synthesis.schema.json`, req). [descriptions: catalog entry per app; languages/frameworks/runtimes; 4-pass analysis; cross-pass synthesis with readiness score]
- `G-RR`: `capability-catalog` (`schemas/discovery/capability-catalog.schema.json`, req), `discovery-synthesis` (`…/discovery-synthesis.schema.json`, req).
- `G-DA`: `analysis-report` (`…/analysis-report.schema.json`, req), `discovery-synthesis` (`…/discovery-synthesis.schema.json`, req).
- `G-DT`: `business-logic` (`schemas/discovery/business-logic.schema.json`, req), `business-rule-inventory` (`schemas/discovery/business-rule-inventory.schema.json`, req).
- `G-04a`: `business-rule-inventory` (`…/business-rule-inventory.schema.json`, req), `quality-risk` (`schemas/discovery/quality-risk.schema.json`, req).
- `G-04b`: `analysis-report` (`…/analysis-report.schema.json`, req).
- `G-04c`: `analysis-report` (`…/analysis-report.schema.json`, req).
- `G-V1`: `analysis-report` (`…/analysis-report.schema.json`, req).
- `G-V2`: `ux-accessibility` (`schemas/discovery/ux-accessibility.schema.json`, req), `quality-risk` (`…/quality-risk.schema.json`, req).
- `G-V3`: `quality-risk` (`…/quality-risk.schema.json`, req).
- `G-DP-1`: `analysis-report` (`…/analysis-report.schema.json`, req).
- `G-DP-2`: `analysis-report` (`…/analysis-report.schema.json`, req).
- ⚠️ `G-02`, `G-DE-1`, `G-DE-2` are intentionally OMITTED (internal-only, not delegated in v1); dispatching against them raises `BUNDLE_UNKNOWN_GATE` 400.

`_LINE_STEP_OUTPUTS` (`bundle_contract.py:260-305`): `discovery.catalog`→`application-catalog-entry`; `discovery.tech-fingerprint`→`tech-fingerprint`; `discovery.analysis`→`analysis-report`; `discovery.synthesis`→`discovery-synthesis`; `modernization.extract`→`business-rule-inventory`; `modernization.design`→`analysis-report` (all `required=True`, schema_refs as in `_GATE_OUTPUTS`; no descriptions on step entries).

### 6.2 PERSIST — `bundle.dispatch(db, *, contract, fallback_policy, expires_in_hours, created_by_user_id, dispatching_workflow_id=None) -> uuid.UUID` (`bundle.py:359-455`)
This is the **projection of `BundleContract` → 3 tables**. Reproduce as the mapping + control flow below. ⚠️ **CHANGED at HEAD:** new keyword param `dispatching_workflow_id: str | None = None`, persisted on the bundle row.

**Step A — generate id:** `bundle_id = uuid.uuid4()` (client-side; NOT relying on `gen_random_uuid()` even though the column has it).

**Step B — INSERT `delegated_bundle`** (status hardcoded `'offered'`; claim cols, expires_at, submitted_at, accepted_at all left NULL → DB; `created_at/updated_at` → `now()` default; `local_agent_descriptor` left NULL initially):
```sql
INSERT INTO delegated_bundle (
  id, portfolio_id, application_id, wave_id,
  scope_kind, target_id, status, fallback_policy, created_by_user_id,
  dispatching_workflow_id
) VALUES (
  :id, :portfolio_id, :application_id, :wave_id,
  :scope_kind, :target_id, 'offered', :fallback_policy, :created_by,
  :dispatching_workflow_id
)
```
| param | source | notes |
|---|---|---|
| `:id` | `bundle_id` (`uuid.uuid4()`) | |
| `:portfolio_id` | `contract.metadata.portfolio_id` | from resolver |
| `:application_id` | `contract.metadata.application_id` | may be None |
| `:wave_id` | `contract.metadata.wave_id` | may be None |
| `:scope_kind` | `contract.scope_kind.value` | `.value` string |
| `:target_id` | `contract.target_id` | |
| (status) | literal `'offered'` | |
| `:fallback_policy` | `fallback_policy.value` | enum `.value` |
| `:created_by` | `created_by_user_id` | → `created_by_user_id` column |
| `:dispatching_workflow_id` | `dispatching_workflow_id or None` | ⚠️ **NEW** — `None` for admin dispatch; the Temporal workflow_id otherwise (migration 063 column) |

**Step C — INSERT one `delegated_bundle_input_ref` per `contract.inputs`** (loop):
```sql
INSERT INTO delegated_bundle_input_ref (bundle_id, artifact_kind, artifact_ref, description)
VALUES (:bid, :kind, :ref, :desc)
```
| param | source |
|---|---|
| `:bid` | `bundle_id` |
| `:kind` | `inp.artifact_kind` |
| `:ref` | `inp.artifact_ref` |
| `:desc` | `inp.description` (may be None) |

**Step D — INSERT one `delegated_bundle_output_ref` per `contract.outputs`** (loop):
```sql
INSERT INTO delegated_bundle_output_ref (bundle_id, artifact_kind, schema_ref, required, description)
VALUES (:bid, :kind, :schema, :required, :desc)
```
| param | source |
|---|---|
| `:bid` | `bundle_id` |
| `:kind` | `out.artifact_kind` |
| `:schema` | `out.schema_ref` |
| `:required` | `out.required` (bool) |
| `:desc` | `out.description` (may be None) |
(`submitted_artifact_ref`, `submitted_at` left NULL — filled later at submit time, not here.)

**Step E — TTL stash (conditional):** `if expires_in_hours is not None:`
```sql
UPDATE delegated_bundle
SET local_agent_descriptor = jsonb_build_object('_expires_in_hours', :hours)
WHERE id = :id
```
params `{"id": bundle_id, "hours": expires_in_hours}`.
⚠️ **GOTCHA — the TTL travels in the descriptor JSONB under the internal key `_expires_in_hours`** (not a dedicated column). The CLAIM handler reads it back and applies `expires_at = claim_time + hours` so it can compute expiry without a registry lookup, then strips all `_`-prefixed keys when merging the caller's real descriptor. If `expires_in_hours is None`, `local_agent_descriptor` stays NULL and claim defaults to `24*7` hours (7 days). The activity always passes an int (workflow caller passes `24*7`; manual API dispatch defaults 7d, ge=1, le=24*30).

**Step F — `await db.commit()`; `return bundle_id`** (the `uuid.UUID`; the activity stringifies it).

**Columns written by `dispatch`:**
- `delegated_bundle`: `id, portfolio_id, application_id, wave_id, scope_kind, target_id, status(=‘offered’), fallback_policy, created_by_user_id, dispatching_workflow_id` (⚠️ NEW; `None` for admin dispatch); later `local_agent_descriptor` (conditional). DB-defaulted (not written): `created_at, updated_at`. Left NULL: `claimed_by_user_id, claimed_at, expires_at, submitted_at, accepted_at`.
- `delegated_bundle_input_ref`: `bundle_id, artifact_kind, artifact_ref, description`. (`id` defaulted.)
- `delegated_bundle_output_ref`: `bundle_id, artifact_kind, schema_ref, required, description`. (`id` defaulted; `submitted_artifact_ref, submitted_at` NULL.)

⚠️ No `ON CONFLICT` clause — concurrency is guarded only by `ux_bundle_one_open_per_scope` (§5.3); a collision raises a unique-violation (NonRetryable per §0).

### 6.3 PERSIST — `bundle.expire_due_bundles(db) -> list[uuid.UUID]` (`bundle.py:988-1008`)
Single statement + commit:
```sql
UPDATE delegated_bundle
SET status = 'expired', updated_at = :now
WHERE status = 'claimed' AND expires_at < :now
RETURNING id
```
params `{"now": datetime.now(timezone.utc)}`. Then `await db.commit()`; `return [r["id"] for r in rows]` (via `.mappings().all()`).
**Columns written:** `delegated_bundle.status` (→`'expired'`), `delegated_bundle.updated_at` (→`now`). Matched rows: only `claimed` past `expires_at`. ⚠️ `now` is computed ONCE in Python (timezone-aware UTC) and used for both the SET and the WHERE comparison — same instant on both sides. The `chk_bundle_claim_consistency` constraint permits `status='expired'` with any claim-column state (third OR-branch), so flipping to expired never trips the constraint.

> NOTE: the other bundle-service functions (`get_bundle`, `list_bundles`, `claim`, `release`, `submit`, `validate_payload`, `get_audit_narrative`, `dispatch_from_kickoff`, and the helpers `_persist_session_artifacts`/`_persist_validation_history`) are reachable via the API surface, NOT via these activities. They are specified in the Phase 8 API/services spec. They are listed here only for cross-reference; do not attribute their writes to this activity group.

---

## 7. The W20 reaper workflow — `BundleReaperWorkflow` (`workflows/bundle_reaper.py`)

`@workflow.defn class BundleReaperWorkflow` with one `@workflow.run async def run(self) -> dict[str, int]`. No signal/query handlers; no inter-run state. Designed for a 15-minute Temporal **Schedule** (provisioned out-of-band, like Sustainment/Governance):
```bash
temporal schedule create --schedule-id bundle-reaper --workflow-id bundle-reaper \
  --workflow-type BundleReaperWorkflow --task-queue olympus-main --interval 15m
```
Sandbox imports (`with workflow.unsafe.imports_passed_through():`): `expire_due_bundles_activity`, `RETRY_POLICIES`, `BundleExpiredSignal`.

`run()` control flow:
1. `try: expired = await workflow.execute_activity(expire_due_bundles_activity, start_to_close_timeout=timedelta(minutes=2), retry_policy=RETRY_POLICIES["transient"])` `except Exception as exc: workflow.logger.warning("bundle-reaper.sweep-failed: %s", exc); return {"expired": 0, "signalled": 0}`. ⚠️ On activity failure (after retry exhaustion) the workflow returns zeros, never fails (tested).
2. `signalled = 0`; `for entry in expired or []:` read `bundle_id = entry.get("bundle_id","")`, `wfid = entry.get("workflow_id","")`.
   - `if not wfid: continue` — the activity already emitted the stub log for these; ONLY manual/admin-dispatched (or pre-063) bundles have empty `wfid`. ⚠️ **CHANGED at HEAD:** workflow-dispatched bundles now carry a real `wfid` (§4.1), so they FALL THROUGH to the signal branch — the reaper actually signals parents now (the prior baseline note "today every entry hits this branch" is STALE).
   - else `try: handle = workflow.get_external_workflow_handle(wfid); await handle.signal("bundle_expired", BundleExpiredSignal(bundle_id=bundle_id, reason="expired")); signalled += 1` `except Exception as exc: workflow.logger.info("bundle-reaper.signal-failed: bundle=%s wf=%s err=%s", ...)` (external workflow likely complete/cancelled — log and continue).
3. `return {"expired": len(expired or []), "signalled": signalled}`.

⚠️ **GOTCHA — signal name string is `"bundle_expired"`** (matches the `@workflow.signal async def bundle_expired` handler name in `BundleAwareMixin`, NOT the dataclass name). Signalled via `get_external_workflow_handle(wfid).signal("bundle_expired", BundleExpiredSignal(...))`.

### 7.1 Consumer side — `BundleAwareMixin` (`workflows/bundle_helpers.py`) and signals (`types.py`)
Not activities, but the contract the reaper/API signal into; reproduce for round-trip parity.
- Signals (dataclasses, `types.py:358-385`): `BundleCompletedSignal(bundle_id: str, outcome: str, outputs: dict[str,str]=field(default_factory=dict), validation_summary: str="")` (fired by API on `accepted`); `BundleExpiredSignal(bundle_id: str, reason: str="expired")` (fired by reaper).
- `BundleAwareMixin.__init__`: calls `super().__init__()` then sets `self._bundle_outcomes={}`, `self._bundle_outputs={}`, `self._bundle_validation_summaries={}` (multi-base safe — doesn't reset across mixins).
- `@workflow.signal bundle_completed(signal)`: `outcome = (signal.outcome or "").strip().lower()`; `if not outcome: return`; `self._bundle_outcomes[signal.bundle_id]=outcome`; if `signal.outputs`: `self._bundle_outputs[bundle_id]=dict(signal.outputs)`; if `signal.validation_summary`: store it.
- `@workflow.signal bundle_expired(signal)`: `reason = (signal.reason or "expired").strip().lower()`; `if reason not in ("expired","released"): reason="expired"`; `self._bundle_outcomes[bundle_id]=reason`. (Tested: unknown reason → `"expired"`.)
- `await_bundle_completion(bundle_id, timeout_seconds) -> BundleOutcome` (Literal `accepted|rejected|expired|released|timeout`): `try: await workflow.wait_condition(lambda: bundle_id in self._bundle_outcomes, timeout=timedelta(seconds=timeout_seconds)) except TimeoutError: return "timeout"`; then read outcome; if not in the 4 terminals → `"timeout"`, else return it. ⚠️ `timeout_seconds` is an independent workflow-internal safety net, separate from the bundle's own `expires_at` (which the reaper enforces).
- Queries: `get_bundle_outcome(bundle_id) -> str` (`""` if unknown), `get_bundle_outputs(bundle_id) -> dict[str,str]` (`{}` if not accepted).

---

## 8. Worker registration (`temporal/olympus_workflows/worker.py`)
- Both activities imported (`:44-46`) and registered in the worker's `activities=[...]` list (`:220-221`): `dispatch_delegated_bundle`, `expire_due_bundles_activity`.
- `BundleReaperWorkflow` imported (`:115`) and registered in `workflows=[...]` (`:160`).
- Task queue: `olympus-main` (worker config default, `:247`). The reaper schedule targets the same queue.

---

## 9. Undetermined / out-of-scope notes
- `workflow_id` persistence on the bundle row is an explicit follow-on (chunk-D ships empty `""`); when added, `expire_due_bundles_activity` will populate it and the reaper's signal branch becomes live. Not in current code.
- The real internal-fallback dispatcher (running the equivalent internal skill chain on expiry/release) is STUBBED everywhere — only `log_internal_fallback_stub` runs. `load_fallback_policy_for_portfolio` resolves the policy string but nothing applies it inside these activities.
- Exact `get_logger()` formatting (`foundry_temporal.logging`) is the foundry observability logger; the `extra={...}` dicts above are what matters for parity (operators scrape `delegated-bundle.fallback.stub`, `delegated-bundle.dispatched`, `delegated-bundle.reaper.expired-batch`).
