# Regen Spec — Phase 8 API: Gates & Escalations Routers

ATOMIC regeneration specification. Behavioral parity is the bar. Two FastAPI routers + the gate
service signal-firing path they depend on.

Source files (cite these exactly):
- `olympus-api/src/routers/gates.py` — **9 `@router` + 1 `wave_gates_router` = 10 path ops** across 2 routers at HEAD `7cb3b20c` (grew from 8/9; +1 `GET /{gate_id}/reviewer-roles`, P6-S6.5)
- `olympus-api/src/routers/escalations.py` — 4 endpoints (1 router)
- `olympus-api/src/services/gate.py` — service layer (signal firing + handler logic), **2574 lines at HEAD**
- `olympus-api/src/services/gate_rbac.py` — **⚠️ NEW at HEAD** (P6-S6.3/.4): gate-type → reviewer-role policy resolution, quorum, oversight, management-override (`rbac-model.md` §5)
- `olympus-api/src/models/gate.py` — gate Pydantic models
- `olympus-api/src/middleware/auth.py` — `CurrentUser`, `get_current_user`, `require_role`
- `olympus-api/src/middleware/pagination.py` — `PaginationParams`, `get_pagination`, `paginated_response`
- `olympus-api/src/middleware/error_handler.py` — `OlympusHTTPException(status_code, code, message, details=None)`
- `olympus-api/src/dependencies.py` — `require_gate_member`, `resolve_portfolio_role`, `verify_portfolio_access`, `filter_portfolio_ids_by_membership`, `get_config`
- `olympus-api/src/models/common.py` — `RBACRole` enum
- `olympus-contracts/olympus_contracts/signals.py` — `GateApprovedSignal`, `GateRejectedSignal`, `GateMergeRetrySignal`
- `temporal/olympus_workflows/types.py:165` — `StakeholderApprovedSignal`

---

## ⚠️⚠️ MAJOR CHANGE AT HEAD — P6-S6 GATE RBAC OVERHAUL

The gates router was rewritten for **gate-type → reviewer-role RBAC** (`specifications/phase-6/rbac-model.md` §5/§6). Highlights (ALL new vs the prior spec):
1. **No more flat `require_role(*REVIEWER_ROLES)` on approve/reject/decision.** Those now use `Depends(get_current_user)` + a per-gate policy enforcement helper (`_enforce_gate_reviewer` / `_enforce_gate_decider`) that resolves the caller's *portfolio-scoped* role and checks it against the gate type's policy.
2. **Quorum + oversight.** Approve no longer flips the gate immediately — it records a `gate_approval` row and the gate advances ONLY when `minimum_approvals` + oversight co-sign are met (`record_gate_approval`). The Temporal signal fires ONLY when the gate `advanced`.
3. **Non-overridable gates.** `force-advance` now 403s `GATE_NOT_OVERRIDABLE` when the gate's policy has `management_override_allowed: false` (e.g. FAA G-V3) — even for `portfolio_admin`.
4. **NEW endpoint** `GET /{gate_id}/reviewer-roles` (P6-S6.5) drives role-aware UI.
5. **`list_pending_wave_gates` NOW EXISTS** (`gate.py:243`) — the prior spec's "UNDETERMINED #1: missing symbol" is RESOLVED; the wave batch path fans out per-gate RBAC + quorum.

---

## ENDPOINT COUNT (the gate will count these)

- **gates router (`/api/v1/gates`) = 9** `@router.*` ops: GET /pending, POST /{gate_id}/approve, POST /{gate_id}/reject, GET /{gate_id}/evidence, **GET /{gate_id}/reviewer-roles ⚠️NEW**, POST /{gate_id}/decision, POST /{gate_id}/retry-merge, POST /{gate_id}/force-advance, POST /{gate_id}/resolve-escalation.
- **wave_gates router (`/api/v1/waves`) = 1**: POST /{wave_id}/gates/approve-pending (`@wave_gates_router.*`).
- **gates.py FILE TOTAL = 10 path ops** (9 on `router` + 1 on `wave_gates_router`). ⚠️ The gate's `grep -cE "@router\."` counts only the 9 `@router.*` (the `@wave_gates_router.*` op is invisible to it) — file `@router` count = **9** (was 8).
- **escalations router (`/api/v1/escalations`) = 4**: GET "", GET /metrics, GET /{escalation_id}, POST /{escalation_id}/resolve.

Per-router endpoint counts for the gate: `gates_router=9`, `wave_gates_router=1` (file gates.py=10), `escalations_router=4`.

---

## ROUTER MOUNT ORDER (`olympus-api/src/main.py`)

⚠️ GOTCHA — Mount order matters for path resolution. Registered in this order in `create_app`:
- `main.py:186` `app.include_router(gates_router)` — prefix `/api/v1/gates`
- `main.py:187` `app.include_router(wave_gates_router)` — prefix `/api/v1/waves`
- `main.py:201` `app.include_router(escalations_router)` — prefix `/api/v1/escalations`

Within each router, path operations are registered in **definition order** (top-to-bottom in the file). Preserve that order on regeneration.

---

## ROUTER DEFINITIONS

### gates.py routers (gates.py:86, gates.py:92)

```python
router = APIRouter(prefix="/api/v1/gates", tags=["Gates"])           # gates.py:86
wave_gates_router = APIRouter(prefix="/api/v1/waves", tags=["Gates", "Waves"])  # gates.py:92
```

### escalations.py router (escalations.py:49)

```python
router = APIRouter(prefix="/api/v1/escalations", tags=["Escalations"])  # escalations.py:49
```

---

## AUTH PRIMITIVES (shared)

### `CurrentUser` (auth.py:32)
Fields: `sub: str`, `roles: list[RBACRole]`, `claims: dict`. Method `has_role(*roles) -> bool` returns `any(r in self.roles for r in roles)`.

### `get_current_user(request)` (auth.py:52) — async dependency
- If env `DEV_AUTH_BYPASS=true` → returns `CurrentUser(sub="local-dev", roles=list(RBACRole), claims={"sub":"local-dev","dev_bypass":True})`.
- Else extract `Authorization: Bearer <token>`; if missing → **HTTP 401** `"Missing authorization token"`.
- `jwt.decode(token, JWT_SECRET, algorithms=[JWT_ALGORITHM], options=...)`. When `AUTH_SKIP_VERIFICATION=true` (default true) options disable signature/exp/aud verification. On `JWTError` → **HTTP 401** `"Invalid or expired token"`.
- `sub = payload.get("sub","anonymous")`; roles parsed from `payload["roles"]` (unknown values logged + skipped); if no valid roles → `roles=[RBACRole.VIEWER]`.

### `require_role(*required_roles)` (auth.py:106) — dependency factory
Returns async dep that calls `get_current_user`; if `not user.has_role(*required_roles)` → **HTTP 403** `detail=f"Requires one of: {[r.value for r in required_roles]}"`. Else returns the `CurrentUser`.

### `require_gate_member` (dependencies.py:172) — path-style dependency
Signature: `(gate_id: uuid.UUID = Path(...), user = Depends(get_current_user), db = Depends(get_db))`.
- If `user.has_role(RBACRole.PORTFOLIO_ADMIN)` → return `user` (bypass).
- Else `await verify_gate_portfolio_access(db, user, gate_id)` then return `user`.
- `verify_gate_portfolio_access` (dependencies.py:356): resolves portfolio via
  `SELECT COALESCE(a.portfolio_id, w.portfolio_id) ... FROM gate g LEFT JOIN application a ... LEFT JOIN wave w ... WHERE g.id=:gid`. If row None or portfolio_id None → **HTTP 404** `"Gate not found"`. Else `verify_portfolio_access` → **HTTP 403** `{"code":"PORTFOLIO_NOT_MEMBER", ...}` if not a member.

### `resolve_portfolio_role(db, user, portfolio_id) -> str | None` (dependencies.py) — ⚠️ NEW, used by P6-S6 enforcement
Returns the caller's PORTFOLIO-SCOPED role string for `portfolio_id` (consults `portfolio_membership.role`, NOT just membership existence). Returns the synthetic `"portfolio_admin"` for a global admin. `None` when the caller is not a member. The gate router uses this (not the JWT roles) to drive gate-type policy checks.

### `verify_portfolio_access(db, user, portfolio_id)` (dependencies.py:105)
Admin bypass; else `membership_svc.is_member(...)`; else **HTTP 403** with `detail={"code":"PORTFOLIO_NOT_MEMBER","message":"Caller is not a member of this portfolio. Ask a portfolio_admin to grant access."}`.

### `filter_portfolio_ids_by_membership(db, user, candidate=None)` (dependencies.py:389)
Returns `None` (no filter) for `portfolio_admin`; else `membership_svc.list_user_portfolio_ids(db, user.sub)` (intersected with `candidate` if provided). Empty list ⇒ caller sees nothing.

### `get_config()` (dependencies.py:28) — `@lru_cache` singleton `AppConfig()`.

### RBAC role lists (gates.py:58-84)
```python
VIEWER_PLUS = [VIEWER, TECH_LEAD, ARCH_LEAD, COMPLIANCE_LEAD, OPERATIONS_LEAD, SAFETY_BOARD, PORTFOLIO_MANAGER, PORTFOLIO_ADMIN]      # gates.py:58
REVIEWER_ROLES = [TECH_LEAD, ARCH_LEAD, COMPLIANCE_LEAD, OPERATIONS_LEAD, SAFETY_BOARD, PORTFOLIO_MANAGER, PORTFOLIO_ADMIN]           # gates.py:69 (VIEWER_PLUS minus VIEWER)
MANAGER_ROLES = [PORTFOLIO_MANAGER, PORTFOLIO_ADMIN]                                                                                 # gates.py:81
```
`RBACRole` enum values (common.py:47): `portfolio_admin`, `portfolio_manager`, `tech_lead`, `arch_lead`, `compliance_lead`, `operations_lead`, `safety_board`, `viewer`, `service`. ⚠️ At HEAD `REVIEWER_ROLES`/`MANAGER_ROLES` are now used ONLY by `retry-merge`, `resolve-escalation`, `force-advance`, and the wave-batch endpoint — approve/reject/decision moved to per-gate policy enforcement (see "gate_rbac" below). `evidence` still uses VIEWER_PLUS.

### ⚠️ NEW — gate_rbac policy resolution (`src/services/gate_rbac.py`)
Pure policy resolution (NO DB, NO auth — the router enforces). `rbac-model.md` §5.
```python
MANAGEMENT_ROLES = ("portfolio_manager", "portfolio_admin")                              # gate_rbac.py:31

@dataclass(frozen=True)
class GateReviewPolicy:                                                                   # gate_rbac.py:77
    gate_type: str
    required_reviewer_roles: tuple[str, ...]
    minimum_approvals: int = 1
    oversight_role: str | None = None
    management_override_allowed: bool = True
    extension_roles: tuple[str, ...] = ()
    def allowed_approver_roles() -> set[str]:        # required_reviewer_roles + (MANAGEMENT_ROLES iff management_override_allowed)
    def is_oversight_role(role) -> bool:             # oversight_role is not None and role == oversight_role

@dataclass(frozen=True)
class ApproverDecision:                                                                    # gate_rbac.py:113
    allowed: bool; is_oversight: bool = False; is_management_override: bool = False

def evaluate_approver(policy, scoped_role) -> ApproverDecision:                            # gate_rbac.py:122
    is_reviewer   = scoped_role in policy.required_reviewer_roles
    is_management = scoped_role in MANAGEMENT_ROLES
    if is_reviewer:   return ApproverDecision(allowed=True, is_oversight=policy.is_oversight_role(scoped_role), is_management_override=False)
    if is_management and policy.management_override_allowed:
                      return ApproverDecision(allowed=True, is_oversight=policy.is_oversight_role(scoped_role), is_management_override=True)
    return ApproverDecision(allowed=False)            # ⚠️ a manager who lacks the reviewer role on a NON-overridable gate is DENIED

def resolve_gate_review_policy(gate_type, *, profile=None) -> GateReviewPolicy:            # gate_rbac.py:175
    # profile defaults to active_profile(). Merge order: profile overrides[gate].rbac block > platform default.
    default_roles, default_min = _PLATFORM_DEFAULTS.get(gate_type, _UNKNOWN_GATE_DEFAULT)  # gate_rbac.py:40 / :64
    required, minimum, oversight, override_allowed = list(default_roles), default_min, None, True
    rbac_block = profile.gates.override(gate_type).rbac if (profile and override exists) else None
    if rbac_block:
        if rbac_block.get("required_reviewer_roles"):    required = [str(r) for r in ...]
        if rbac_block.get("minimum_approvals") is not None: minimum = int(...)
        oversight = str(rbac_block["oversight_role"]) if rbac_block.get("oversight_role") else None
        if rbac_block.get("management_override_allowed") is not None: override_allowed = bool(...)
    return GateReviewPolicy(gate_type, tuple(required), minimum_approvals=max(1,minimum), oversight_role=oversight,
                            management_override_allowed=override_allowed, extension_roles=tuple(sorted(_profile_extension_roles(profile))))
```
`_PLATFORM_DEFAULTS` (gate_rbac.py:40) — `(required_reviewer_roles, minimum_approvals)` per gate type. Notable: `G-V3 → ([safety_board], 2)` (2-person quorum); `G-DA → ([portfolio_manager], 1)`; `G-02 → ([arch_lead], 1)`; unknown gate → `_UNKNOWN_GATE_DEFAULT` = (tech_lead/arch_lead/compliance_lead/operations_lead/safety_board/portfolio_manager, 1) so an unknown gate stays reviewable. ⚠️ `oversight_role`/`management_override_allowed` come ONLY from the profile rbac block (platform default None/True). FAA's G-V3 sets `management_override_allowed: false` in `profiles/faa/gates.yaml` (non-overridable).

### ⚠️ NEW — router-local enforcement helpers (gates.py)
```python
async def _enforce_gate_reviewer(db, user, gate_id) -> (policy, scoped_role, decision):   # gates.py:151
    gate_type, portfolio_id = await gate_svc.get_gate_type_and_portfolio(db, gate_id)      # 404 GATE_NOT_FOUND
    scoped_role = (await resolve_portfolio_role(db, user, portfolio_id)) if portfolio_id is not None \
                  else ("portfolio_admin" if user.has_role(PORTFOLIO_ADMIN) else None)     # ⚠️ orphan gate → admin-bypass only
    if scoped_role is None: raise OlympusHTTPException(403, "PORTFOLIO_NOT_MEMBER", "Caller is not a member of this gate's portfolio.")
    policy = resolve_gate_review_policy(gate_type)
    decision = evaluate_approver(policy, scoped_role)
    if not decision.allowed:
        raise OlympusHTTPException(403, "PORTFOLIO_ROLE_INSUFFICIENT",
            f"Role '{scoped_role}' may not approve a {gate_type} gate. Requires one of: {sorted(policy.allowed_approver_roles())}.")
    return policy, scoped_role, decision

async def _enforce_gate_decider(db, user, gate_id) -> scoped_role:                          # gates.py:198
    # For reject / escalate / retry-merge / decision-reject — action does NOT advance past sign-off.
    gate_type, portfolio_id = await gate_svc.get_gate_type_and_portfolio(db, gate_id)
    scoped_role = (resolve_portfolio_role(...)) or ("portfolio_admin" if admin else None)
    if scoped_role is None: raise OlympusHTTPException(403, "PORTFOLIO_NOT_MEMBER", ...)
    policy = resolve_gate_review_policy(gate_type)
    permitted = set(policy.required_reviewer_roles) | set(MANAGEMENT_ROLES)                 # ⚠️ rework ALWAYS allowed for reviewer|management, independent of management_override_allowed (§5.1)
    if scoped_role not in permitted:
        raise OlympusHTTPException(403, "PORTFOLIO_ROLE_INSUFFICIENT",
            f"Role '{scoped_role}' may not act on a {gate_type} gate. Requires one of: {sorted(permitted)}.")
    return scoped_role
```

### Module-level validated literal sets (gates.py:49-56)
Computed once at import via `set(get_args(...))` (gates.py:53-56):
```python
_ESCALATE_REASONS = {"out-of-scope","policy-conflict","needs-senior-review","safety-concern"}          # from EscalateReasonCategory
_ESCALATION_RESOLUTION_CATEGORIES = {"re-extract","manual-augment","re-disposition","rejected-as-escalated"}  # from EscalationResolutionCategory
```

### Pagination (pagination.py)
- `PaginationParams` dataclass: `page:int`, `per_page:int`, `@property offset -> (page-1)*per_page`.
- `get_pagination(page=Query(1, ge=1), per_page=Query(20, ge=1, le=100)) -> PaginationParams`.
- `paginated_response(items, total, params) -> {"data": items, "pagination": {"page", "per_page", "total", "total_pages"}}` where `total_pages = max(1, ceil(total/per_page))`.

---

## PYDANTIC MODELS (models/gate.py)

### Literal types
```python
RejectReasonCategory = Literal["evidence-incomplete","policy-violation","needs-rework","escalate"]                 # gate.py:18
ApproveReasonCategory = Literal["met-all-criteria","conditional-follow-up","accepted-with-followup","override"]    # gate.py:29
EscalateReasonCategory = Literal["out-of-scope","policy-conflict","needs-senior-review","safety-concern"]          # gate.py:38
EscalationResolutionCategory = Literal["re-extract","manual-augment","re-disposition","rejected-as-escalated"]     # gate.py:48
```
`GateStatus`, `GateType` imported from `olympus_contracts` (via common.py re-export). `GateStatus` includes at least: `preparing`, `pending`, `approved`, `rejected`, `escalated`, `merge_blocked`. `ActorKind`, `LocalAgentDescriptor` from `src.models.human_paired_agent`.

### `GateDetail` (gate.py:75) — primary response model
```
id: UUID
gate_type: GateType
app_id: UUID | None = None
wave_id: UUID | None = None
status: GateStatus
checks: list[dict] | None = None
evidence_package_url: str | None = None
reviewers: list[str] | None = None
sla_deadline: datetime | None = None
decided_at: datetime | None = None
decided_by: str | None = None
created_at: datetime | None = None
justification: str | None = None
reject_reason_category: RejectReasonCategory | None = None
merge_failure_detail: dict | None = None
```
⚠️ `_gate_detail_from_row` (gate.py:252) maps DB columns → model: `created_at = row["requested_at"]` (NOT a `created_at` column), `app_id = row["application_id"]`. Only these fields populated from the row: id, gate_type, application_id→app_id, wave_id, status, decided_at, decided_by, requested_at→created_at, justification, reject_reason_category, merge_failure_detail. `checks`, `evidence_package_url`, `reviewers`, `sla_deadline` are left None by this mapper.

### `GateSummary` (gate.py:56) — used by /pending list
```
id: UUID
gate_type: GateType
app_id: UUID | None = None
wave_id: UUID | None = None
app_name: str = ""
wave_name: str = ""
status: GateStatus
sla_deadline: datetime | None = None
```

### `GateApproveRequest` (gate.py:106)
```
comment: str | None = None
approve_reason_category: ApproveReasonCategory | None = None   # optional audit tag, not persisted to gate row
```

### `GateRejectRequest` (gate.py:126)
```
reason_category: RejectReasonCategory | None = None            # optional; treated as 'needs-rework' if omitted (semantic note)
feedback: str = Field(min_length=1)                            # REQUIRED, non-empty
```

### `GateDecisionRequest` (gate.py:389) — unified decision body
```
action: str                                # "approve" | "reject" | "escalate" (bare str, NOT a Literal)
notes: str | None = None
escalation_reason: str | None = None
reason_category: str | None = None         # bare str; validated per-action at router (see /decision logic)
approve_reason_category: ApproveReasonCategory | None = None
card_decisions: list[CardDecision] | None = None
reviewer_notes: str | None = None
sort_applied: Literal["workflow","severity"] | None = None
bulk_approved: bool | None = None
capability_lineage_decisions: list[CapabilityLineageRowDecision] | None = None
```

### `CardDecision` (gate.py:304)
```
card_id: str                                   # required
artifact_type: str | None = None
decision: Literal["approve","reject"]          # required
note: str | None = None
ai_pre_review_used: bool = False
```

### `CapabilityLineageRowDecision` (gate.py:348)
```
lineage_id: UUID                               # required
decision: Literal["approve","reject"]          # required
feedback: str | None = None                    # required-when-reject is enforced at ROUTER, not model
```

### `GateMergeRetryRequest` (gate.py:490)
```
note: str | None = None
```

### `GateForceAdvanceRequest` (gate.py:513)
```
comment: str = Field(min_length=1)             # REQUIRED non-empty
bypass_evidence_check: bool = False
```

### `GateEscalationResolveRequest` (gate.py:546)
```
resolution_category: EscalationResolutionCategory   # REQUIRED (Field(...)); also re-validated at router
notes: str | None = None
```

### `WaveBatchApproveRequest` (gate.py:149)
```
comment: str = Field(min_length=1)             # REQUIRED non-empty; recorded on every approved gate
```

### `WaveBatchApproveResponse` (gate.py:168)
```
approved: int
gate_ids: list[UUID]                           # approval order
```

### `GateEvidencePackage` (gate.py:255) — response of /evidence
```
gate_id: UUID
gate_type: GateType
app_id: UUID | None = None
wave_id: UUID | None = None
app_name: str = ""
wave_name: str = ""
assembly_line: str
artifacts: list[GateEvidenceArtifact]
validation_results: list[dict] | None = None
pr_url: str | None = None
pr_metadata: dict | None = None
reviewer_guidance: str | None = None
previous_attempts: int = 0
previous_feedback: list[dict] | None = None
ai_recommendation: AIRecommendation | None = None
agent_error_count: int | None = None
validation_warnings: dict[str, list[str]] | None = None
rationalization_capabilities: list[dict] | None = None
```
Sub-models: `GateEvidenceArtifact` (gate.py:196): `artifact_type, title, artifact_path, schema_version="1.0", data:dict, metadata:dict|None, step_name:str|None, step_title:str|None, supporting_artifacts:list[SupportingArtifact]=[], actor_kind:ActorKind="olympus_agent", local_agent_descriptor:LocalAgentDescriptor|None, human_user_id:str|None`. `SupportingArtifact` (gate.py:177): `artifact_type, title, artifact_path, schema_version="1.0", data:dict, metadata:dict|None`. `AIRecommendation` (gate.py:244): `confidence_score:int, recommendation:str, summary:str, full_markdown:str, score_breakdown:dict|None, flags:list[str]|None`.

---

## TEMPORAL SIGNAL PAYLOADS (olympus-contracts/.../signals.py)

⚠️ GOTCHA — `signals.py` deliberately has **NO** `from __future__ import annotations` (signals.py:12 comment): Temporal's payload converter resolves field types via `typing.get_type_hints` against module globals; deferred string annotations break at runtime in the worker. Keep eager annotations on regeneration.

```python
@dataclass
class GateApprovedSignal:               # signals.py:25
    gate_id: str
    approved_by: str
    justification: str = ""
    card_decisions: List[dict] = field(default_factory=list)
    reviewer_notes: Optional[str] = None

@dataclass
class GateRejectedSignal:               # signals.py:47
    gate_id: str
    rejected_by: str
    reason: str
    reason_category: Optional[str] = None
    card_decisions: List[dict] = field(default_factory=list)
    reviewer_notes: Optional[str] = None

@dataclass
class GateMergeRetrySignal:             # signals.py:72
    gate_id: str
    retried_by: str
    note: Optional[str] = None
```

```python
@dataclass
class StakeholderApprovedSignal:        # temporal/olympus_workflows/types.py:165
    approval_id: str
    stakeholder: str
    scope: str
```

---

## ⭐ CRITICAL: `send_gate_temporal_signal` (gate.py:676) — the signal-firing path

This is the gate-decision → Temporal-signal core. Reproduce EVERY branch.

```python
async def send_gate_temporal_signal(db, gate_id: str, action: str, actor: str,
                                    message: str = "", reason_category: str | None = None,
                                    card_decisions: list[dict] | None = None,
                                    reviewer_notes: str | None = None) -> None:
    try:
        # 1) Look up workflow_id + gate_type from the gate row.
        row = (await db.execute(
            text("SELECT workflow_id, gate_type FROM gate WHERE id = :id"),
            {"id": uuid.UUID(gate_id)},      # NOTE: gate_id arrives as str, cast to UUID for bind
        )).mappings().first()

        # 2) No workflow bound → log warning + return (NO raise). Signal silently skipped.
        if not row or not row["workflow_id"]:
            logger.warning("temporal_signal_skipped_no_workflow_id", gate_id=gate_id)
            return

        workflow_id = row["workflow_id"]
        gate_type = row.get("gate_type")     # may be absent in test row shapes → None, skips G-DA branch

        from src.dependencies import get_temporal_client   # lazy import (avoids cycle)
        client = await get_temporal_client()

        # 3) APPROVE
        if action == "approve":
            await client.get_workflow_handle(workflow_id).signal(
                "gate_approved",
                GateApprovedSignal(
                    gate_id=gate_id,
                    approved_by=actor,
                    justification=message,
                    card_decisions=card_decisions or [],
                    reviewer_notes=reviewer_notes,
                ),
            )
            # 3a) ⚠️ G-DA DUAL-SIGNAL: G-DA gate ALSO needs a StakeholderApprovedSignal(scope="g-da")
            #     so the wave_rationalization workflow advances past its stakeholder hold.
            #     The single approver fires BOTH signals.
            if gate_type == "G-DA":
                from olympus_workflows.types import StakeholderApprovedSignal
                await client.get_workflow_handle(workflow_id).signal(
                    "stakeholder_approved",
                    StakeholderApprovedSignal(
                        approval_id=f"gda-{gate_id}",   # literal "gda-" + gate_id
                        stakeholder=actor,
                        scope="g-da",
                    ),
                )
                logger.info("gda_stakeholder_signal_sent", gate_id=gate_id,
                            workflow_id=workflow_id, actor=actor)

        # 4) REJECT
        elif action == "reject":
            await client.get_workflow_handle(workflow_id).signal(
                "gate_rejected",
                GateRejectedSignal(
                    gate_id=gate_id,
                    rejected_by=actor,
                    reason=message,
                    reason_category=reason_category,
                    card_decisions=card_decisions or [],
                    reviewer_notes=reviewer_notes,
                ),
            )

        # 5) MERGE_RETRY (W17 / P5-S17.4)
        elif action == "merge_retry":
            await client.get_workflow_handle(workflow_id).signal(
                "merge_retry",
                GateMergeRetrySignal(
                    gate_id=gate_id,
                    retried_by=actor,
                    note=message or None,     # "" coerced to None
                ),
            )
        # (no else: any other action is a silent no-op)

    # 6) ⚠️ FIRE-AND-FORGET: ANY exception (Temporal unreachable, bad handle, etc.) is
    #    swallowed with a warning log. The DB state was already committed by the caller;
    #    the signal is best-effort and can be retried. NEVER raises to the HTTP layer.
    except Exception:
        logger.warning("temporal_signal_failed", gate_id=gate_id, action=action, exc_info=True)
```

Signal name mapping summary:
| action | signal name (Temporal) | payload type | extra |
|---|---|---|---|
| `approve` | `gate_approved` | `GateApprovedSignal` | + `stakeholder_approved` / `StakeholderApprovedSignal` when `gate_type == "G-DA"` |
| `reject` | `gate_rejected` | `GateRejectedSignal` | — |
| `merge_retry` | `merge_retry` | `GateMergeRetrySignal` | — |

---

## ⭐ NEW AT HEAD: `record_gate_approval` (gate.py:496) — quorum/oversight approval recorder

The P6-S6.4 replacement for an immediate approve. Inserts ONE `gate_approval` row and advances the gate ONLY when quorum + oversight are met. Reproduce EVERY branch.

```python
async def record_gate_approval(db, gate_id, approved_by, approver_role, *,
        minimum_approvals, oversight_role, is_oversight, is_management_override,
        comment=None, card_decisions=None, reviewer_notes=None, sort_applied=None, bulk_approved=None
) -> tuple[GateDetail, bool]:
    row = await _get_gate_or_404(db, gate_id)
    if row["status"] != "pending":
        raise OlympusHTTPException(409, "GATE_ALREADY_DECIDED", f"Gate {gate_id} is already {row['status']}")
    # 1) Idempotent insert — a repeat approval by the SAME user does not double-count.
    INSERT INTO gate_approval (gate_id, approved_by, approver_role, is_oversight, is_management_override, comment)
        VALUES (:gid,:by,:role,:ov,:mo,:comment) ON CONFLICT (gate_id, approved_by) DO NOTHING
    # 2) Re-load all approvals, evaluate quorum + oversight (rbac-model.md §6.3).
    approvals = await _load_gate_approvals(db, gate_id)          # SELECT ... FROM gate_approval WHERE gate_id ORDER BY approved_at
    received   = len(approvals)
    quorum_met = received >= minimum_approvals
    oversight_met = (oversight_role is None) or any(a.get("is_oversight") for a in approvals)
    advanced = quorum_met and oversight_met
    now = utcnow()
    if advanced:
        UPDATE gate SET status='approved', decided_at=:now, decided_by=:by, justification=:comment WHERE id=:id   # ⚠️ decided_by = THIS (final) approver
        await _persist_card_review(db, gate_id, row.get("evidence_data"), card_decisions, reviewer_notes, sort_applied, bulk_approved)
    await db.commit()
    log "gate_approval_recorded" (received, required=minimum_approvals, advanced)
    if advanced:
        row patched: status='approved', decided_at, decided_by  → return _gate_detail_from_row(row), True
    detail = _gate_detail_from_row(row)
    detail.pending_approvals = _build_pending_approvals(approvals, minimum_approvals, oversight_role)   # required/received/remaining/oversight_*
    return detail, False                                        # ⚠️ gate STILL pending — caller MUST NOT fire the signal
```
⚠️ GOTCHA — the `(gate_id, approved_by)` ON CONFLICT means a user re-approving is a no-op for quorum. `_build_pending_approvals` (gate.py:464) returns `PendingApprovals{required, received, remaining=max(0,min-recv), oversight_required, oversight_role, oversight_satisfied, approvals:[GateApprovalRecord...]}` set on `GateDetail.pending_approvals` so the UI shows remaining work. The caller fires the Temporal signal ONLY when the returned `advanced` flag is True.

---

# GATES ROUTER ENDPOINTS (`/api/v1/gates`)

---

## [G1] GET `/api/v1/gates/pending` — list_pending_gates
- **path:line**: gates.py:98 (handler gates.py:99)
- **Method/Path**: `GET /api/v1/gates/pending`
- **Auth**: `user: CurrentUser = Depends(get_current_user)` — ⚠️ NO role gate, NO `require_gate_member`. Any authenticated user. Membership filtering is applied inside the handler.
- **Query params**:
  - `portfolio_id: uuid.UUID | None = Query(None)`
  - `wave_id: uuid.UUID | None = Query(None)`
  - `status: str = Query("pending", pattern="^(pending|rejected|approved|escalated|all)$")` — ⚠️ regex-validated; invalid value → 422.
  - `pagination = Depends(get_pagination)` (page≥1, per_page 1..100 default 20)
  - `db = Depends(get_db)`
- **Request body**: none
- **Response**: `dict` (no `response_model`) → `paginated_response(...)` shape `{"data":[...GateSummary json...], "pagination":{...}}`. Each item is `GateSummary.model_dump(mode="json")`.
- **Status codes**: 200; 403 from `verify_portfolio_access` if `portfolio_id` supplied and caller not a member (non-admin); 422 on bad `status`/pagination; 401 if unauthenticated.
- **Handler logic**:
```python
if portfolio_id is not None:
    await verify_portfolio_access(db, user, portfolio_id)         # 403 if not member (non-admin)
member_ids = await filter_portfolio_ids_by_membership(db, user)   # None for admin, else allowlist
gates, total = await gate_svc.list_pending_gates(
    db, pagination, portfolio_id=portfolio_id, portfolio_ids=member_ids,
    wave_id=wave_id, status=status,
)
return paginated_response([g.model_dump(mode="json") for g in gates], total, pagination)
```
- **Service `list_pending_gates` (gate.py:153)** — query builder:
  - clauses: if `status != "all"` → `g.status = :status`; if `portfolio_ids is not None` → empty list yields literal `FALSE` (⚠️ non-member sees nothing), else `g.portfolio_id = ANY(:pf_ids)`; if `portfolio_id` → `g.portfolio_id = :portfolio_id`; if `wave_id` → `g.wave_id = :wave_id`.
  - `total = SELECT count(*) FROM gate g {where}`.
  - ⚠️ ORDER BY: `status == "rejected"` → `ORDER BY g.decided_at DESC NULLS LAST`; else `ORDER BY g.requested_at ASC`.
  - rows: `SELECT g.*, a.name AS app_name, w.name AS wave_name FROM gate g LEFT JOIN application a ON a.id=g.application_id LEFT JOIN wave w ON w.id=g.wave_id {where} {order_by} LIMIT :limit OFFSET :offset`.
  - Maps to `GateSummary(id, gate_type, app_id=application_id, wave_id, app_name=app_name or "", wave_name=wave_name or "", status)`. ⚠️ `sla_deadline` left as default None (not selected into the summary).

---

## [G2] POST `/api/v1/gates/{gate_id}/approve` — approve_gate ⚠️ REWRITTEN at HEAD (P6-S6)
- **path:line**: gates.py:240 (handler gates.py:245)
- **Method/Path**: `POST /api/v1/gates/{gate_id}/approve`
- **Path param**: `gate_id: uuid.UUID`
- **Decorator deps**: `dependencies=[Depends(require_gate_member)]` (gate-scope membership / 404 / 403)
- **Auth**: `user = Depends(get_current_user)` ⚠️ CHANGED — NO MORE `require_role(*REVIEWER_ROLES)`. The per-gate policy is enforced in-handler by `_enforce_gate_reviewer`.
- **Request body**: `body: GateApproveRequest | None = None` (OPTIONAL).
- **Response model**: `GateDetail` (now carries `pending_approvals` when quorum not yet met).
- **Status codes**: 200; 403 `PORTFOLIO_NOT_MEMBER` / `PORTFOLIO_ROLE_INSUFFICIENT`; 404 `GATE_NOT_FOUND`; 409 `GATE_ALREADY_DECIDED`; 422.
- **Handler logic — reproduce every branch**:
```python
comment = body.comment if body else None
# 1) Resolve + enforce gate-type → reviewer-role policy (scoped role, quorum, oversight, override flags).
policy, scoped_role, decision = await _enforce_gate_reviewer(db, user, gate_id)        # 403 if not allowed
# 2) Record ONE approval toward quorum. ``advanced`` is True only when quorum + oversight met.
result, advanced = await gate_svc.record_gate_approval(
    db, gate_id, user.sub, scoped_role,
    minimum_approvals=policy.minimum_approvals, oversight_role=policy.oversight_role,
    is_oversight=decision.is_oversight, is_management_override=decision.is_management_override,
    comment=comment)
# 3) ⚠️ Fire the Temporal signal ONLY when the gate actually advanced. A pending-quorum gate must NOT signal (rbac-model.md §6.3).
if advanced:
    await gate_svc.send_gate_temporal_signal(db, str(gate_id), "approve", user.sub, comment or "")
return result
```
⚠️ GOTCHA — the gate is NOT immediately decided. For a single-approver gate (`minimum_approvals=1`, no oversight) `advanced` is True on the first approval (same observable result as before). For a multi-person / oversight gate the first approval returns `200` with `status='pending'` and a populated `pending_approvals`, and NO signal fires. ⚠️ A management role approving a gate it lacks the reviewer role for is allowed ONLY if `management_override_allowed` (recorded `is_management_override=True`); on a non-overridable gate it 403s `PORTFOLIO_ROLE_INSUFFICIENT`.
- **Service `record_gate_approval` (gate.py:496)** — see the dedicated section above. (The legacy single-shot `approve_gate` (gate.py:373) still exists and is used by `submit_gate_decision`'s approve path / wave-batch fallbacks, but the `/approve` endpoint now goes through `record_gate_approval`.)

---

## [G3] POST `/api/v1/gates/{gate_id}/reject` — reject_gate ⚠️ auth CHANGED at HEAD
- **path:line**: gates.py:290 (handler gates.py:295)
- **Method/Path**: `POST /api/v1/gates/{gate_id}/reject`
- **Path param**: `gate_id: uuid.UUID`
- **Decorator deps**: `dependencies=[Depends(require_gate_member)]`
- **Auth**: `user = Depends(get_current_user)` ⚠️ CHANGED — enforcement via `_enforce_gate_decider` (reviewer OR management role for the gate type; rework ALWAYS allowed §5.1). NO MORE flat `require_role`.
- **Request body**: `body: GateRejectRequest` (REQUIRED — `feedback` min_length=1).
- **Response model**: `GateDetail`.
- **Status codes**: 200; 403 `PORTFOLIO_NOT_MEMBER`/`PORTFOLIO_ROLE_INSUFFICIENT`; 404; 409 `GATE_ALREADY_DECIDED`; 422 (missing/empty feedback).
- **Handler logic**:
```python
await _enforce_gate_decider(db, user, gate_id)                  # ⚠️ NEW — reviewer|management for gate type
result = await gate_svc.reject_gate(db, gate_id, user.sub, body.feedback, reason_category=body.reason_category)
await gate_svc.send_gate_temporal_signal(db, str(gate_id), "reject", user.sub,
                                         body.feedback, reason_category=body.reason_category)
return result
```
- **Service `reject_gate` (gate.py:605)**: 404 via `_get_gate_or_404`; 409 if status != pending; `UPDATE gate SET status='rejected', decided_at=:now, decided_by=:by, justification=:feedback, reject_reason_category=:category WHERE id=:id`; `_persist_card_review`; commit; return patched `GateDetail`. ⚠️ Signal message arg is `body.feedback`. Reject fires the signal unconditionally (no quorum on reject).

---

## [G4] GET `/api/v1/gates/{gate_id}/evidence` — get_gate_evidence
- **path:line**: gates.py:322 (handler gates.py:327)
- **Method/Path**: `GET /api/v1/gates/{gate_id}/evidence`
- **Path param**: `gate_id: uuid.UUID`
- **Decorator deps**: `dependencies=[Depends(require_gate_member)]`
- **Auth**: `_user = Depends(require_role(*VIEWER_PLUS))` — ⚠️ VIEWER_PLUS (viewers CAN read evidence; this endpoint kept the flat role gate). User unused (named `_user`).
- **Extra dep**: `config = Depends(get_config)` — passed to service to hydrate slim/file-reference evidence from the artifact repo.
- **Request body**: none.
- **Response model**: `GateEvidencePackage`.
- **Status codes**: 200; 403; 404.
- **Handler logic**: `return await gate_svc.get_gate_evidence(db, gate_id, config=config)`.
- **Service `get_gate_evidence(db, gate_id, config=None)` (gate.py:1520)**: reads agent output from gate `evidence_data` JSONB; Discovery stores units under `passes`, other lines under `steps` tagged with `assembly_line`; normalizes into `GateEvidenceArtifact` cards; can hydrate file-reference contents from the artifact repo when `config.github_token` available. (Large; full body gate.py:1520–1847. For parity reproduce the `passes`/`steps` normalization, actor-kind attribution, AI-recommendation assembly, and slim-evidence hydration from that range.)

---

## [G4b] GET `/api/v1/gates/{gate_id}/reviewer-roles` — get_gate_reviewer_roles ⚠️ NEW at HEAD (P6-S6.5)
- **path:line**: gates.py:342 (handler gates.py:346)
- **Method/Path**: `GET /api/v1/gates/{gate_id}/reviewer-roles`
- **Path param**: `gate_id: uuid.UUID`
- **Decorator deps**: `dependencies=[Depends(require_gate_member)]`
- **Auth**: `user = Depends(get_current_user)` (membership via the decorator dep).
- **Response**: `dict` (no response_model). Drives role-aware UI (`rbac-model.md` §7.2 — hide approve when `can_approve` false, hide force-advance when `can_force_advance` false).
- **Status codes**: 200; 403/404 from `require_gate_member`.
- **Handler logic**:
```python
gate_type, portfolio_id = await gate_svc.get_gate_type_and_portfolio(db, gate_id)
scoped_role = (await resolve_portfolio_role(db, user, portfolio_id)) if portfolio_id is not None \
              else ("portfolio_admin" if user.has_role(PORTFOLIO_ADMIN) else None)
policy   = resolve_gate_review_policy(gate_type)
decision = evaluate_approver(policy, scoped_role) if scoped_role is not None else None
return {
  "gate_id": str(gate_id), "gate_type": gate_type,
  "required_reviewer_roles": list(policy.required_reviewer_roles),
  "allowed_approver_roles":  sorted(policy.allowed_approver_roles()),
  "minimum_approvals": policy.minimum_approvals,
  "oversight_role": policy.oversight_role,
  "management_override_allowed": policy.management_override_allowed,
  "caller_role": scoped_role,
  "can_approve": bool(decision and decision.allowed),
  "can_force_advance": (policy.management_override_allowed and scoped_role in MANAGEMENT_ROLES),
}
```
⚠️ This endpoint does NOT raise on a non-member scoped_role — it returns `caller_role=None`, `can_approve=false` (so the UI just hides the buttons). Only `require_gate_member` can 403/404 here.

---

## [G5] POST `/api/v1/gates/{gate_id}/decision` — submit_gate_decision ⚠️ auth CHANGED at HEAD
- **path:line**: gates.py:390 (handler gates.py:395)
- **Method/Path**: `POST /api/v1/gates/{gate_id}/decision`
- **Path param**: `gate_id: uuid.UUID`
- **Decorator deps**: `dependencies=[Depends(require_gate_member)]`
- **Auth**: `user = Depends(get_current_user)` ⚠️ CHANGED — per-action enforcement runs AFTER the cheap 400 validations (see step 4b): `approve` → `_enforce_gate_reviewer`; `reject`/`escalate` → `_enforce_gate_decider`.
- **Request body**: `body: GateDecisionRequest` (REQUIRED).
- **Response model**: `GateDetail`.
- **Status codes**: 200; 403 `PORTFOLIO_NOT_MEMBER`/`PORTFOLIO_ROLE_INSUFFICIENT`; 404; 409 `GATE_ALREADY_DECIDED`; 400 `ESCALATE_REASON_REQUIRED` / `ESCALATE_REASON_INVALID` / `CAPABILITY_LINEAGE_REJECT_FEEDBACK_REQUIRED` / `INVALID_ACTION`; 422 (bad body).
- **Handler logic — reproduce every branch**:
```python
# (1) Escalate validation — router-level (the model keeps reason_category a bare str)
if body.action == "escalate":
    if body.reason_category is None:
        raise OlympusHTTPException(400, "ESCALATE_REASON_REQUIRED",
                                   "Escalate action requires a reason_category.")
    if body.reason_category not in _ESCALATE_REASONS:
        raise OlympusHTTPException(400, "ESCALATE_REASON_INVALID",
            f"Invalid escalate reason_category '{body.reason_category}'. "
            f"Allowed: {sorted(_ESCALATE_REASONS)}")

# (2) Serialize card_decisions to plain dicts (None-able for legacy callers)
card_decisions_payload = (
    [cd.model_dump(mode="python") for cd in body.card_decisions]
    if body.card_decisions else None)

# (3) Serialize capability_lineage_decisions to plain dicts
capability_lineage_decisions_payload = (
    [cld.model_dump(mode="python") for cld in body.capability_lineage_decisions]
    if body.capability_lineage_decisions else None)

# (4) Cross-field check: a reject row-decision MUST carry non-empty feedback
if capability_lineage_decisions_payload:
    for cld in capability_lineage_decisions_payload:
        if cld["decision"] == "reject" and not (cld.get("feedback") or "").strip():
            raise OlympusHTTPException(400, "CAPABILITY_LINEAGE_REJECT_FEEDBACK_REQUIRED",
                f"capability_lineage row {cld['lineage_id']} was rejected without feedback. ...")

# (4b) ⚠️ NEW — P6-S6 RBAC enforcement AFTER the structured-reason 400 checks (so malformed requests fail fast):
if body.action == "approve":
    await _enforce_gate_reviewer(db, user, gate_id)      # 403 PORTFOLIO_ROLE_INSUFFICIENT if not allowed
else:
    await _enforce_gate_decider(db, user, gate_id)       # reject/escalate: reviewer|management for gate type

# (5) Delegate to the service (handles approve/reject/escalate + row decisions)
result = await gate_svc.submit_gate_decision(
    db, gate_id, user.sub, body.action, body.notes, body.escalation_reason,
    reason_category=body.reason_category,
    approve_reason_category=body.approve_reason_category,
    card_decisions=card_decisions_payload,
    reviewer_notes=body.reviewer_notes,
    sort_applied=body.sort_applied,
    bulk_approved=body.bulk_approved,
    capability_lineage_decisions=capability_lineage_decisions_payload,
)

# (6) ⚠️ Fire the Temporal signal ONLY for approve/reject (escalate fires NO signal here)
if body.action in ("approve", "reject"):
    await gate_svc.send_gate_temporal_signal(
        db, str(gate_id), body.action, user.sub, body.notes or "",
        reason_category=(body.reason_category if body.action == "reject" else None),
        card_decisions=card_decisions_payload,
        reviewer_notes=body.reviewer_notes,
    )
return result
```
⚠️ GOTCHA — for the signal, `reason_category` is forwarded **only** when `action=="reject"`; for approve it is forced to None. Escalate path commits in the service but fires NO Temporal signal from this endpoint.

- **Service `submit_gate_decision` (gate.py:2424) — every branch**:
```python
# Apply row-level capability_lineage decisions FIRST (per-row commits)
row_summary = await _apply_capability_lineage_row_decisions(db, decided_by, capability_lineage_decisions)
# If rejected rows produced rework feedback, append a formatted block to BOTH reviewer_notes and notes
augmented_reviewer_notes = reviewer_notes; augmented_notes = notes
if row_summary["rework_feedback"]:
    rework_block = "\n".join(
        f"- [{item.get('source_capability') or '?'} → {item.get('target_capability') or '(none)'}]: {item['feedback']}"
        for item in row_summary["rework_feedback"])
    suffix = "\n\n--- capability_lineage row rework ---\n" + rework_block
    augmented_reviewer_notes = (reviewer_notes or "") + suffix if reviewer_notes is not None else suffix.lstrip("\n")
    augmented_notes = (notes or "") + suffix if notes is not None else suffix.lstrip("\n")

if action == "approve":
    result = await approve_gate(db, gate_id, decided_by, augmented_notes,
        approve_reason_category=approve_reason_category, card_decisions=card_decisions,
        reviewer_notes=augmented_reviewer_notes, sort_applied=sort_applied, bulk_approved=bulk_approved)
    await _persist_capability_lineage_rework_block(db, gate_id, row_summary)
    return result
elif action == "reject":
    feedback = augmented_notes or "Rejected without notes"          # ⚠️ fallback string
    result = await reject_gate(db, gate_id, decided_by, feedback,
        reason_category=reason_category, card_decisions=card_decisions,
        reviewer_notes=augmented_reviewer_notes, sort_applied=sort_applied, bulk_approved=bulk_approved)
    await _persist_capability_lineage_rework_block(db, gate_id, row_summary)
    return result
elif action == "escalate":
    row = await _get_gate_or_404(db, gate_id)
    if row["status"] != "pending":
        raise OlympusHTTPException(409, "GATE_ALREADY_DECIDED", f"Gate {gate_id} is already {row['status']}")
    now = datetime.now(timezone.utc)
    reason = escalation_reason or notes or ""
    UPDATE gate SET status='escalated', decided_at=:now, decided_by=:by, justification=:reason WHERE id=:id
    await _persist_card_review(db, gate_id, row.get("evidence_data"), card_decisions,
                               augmented_reviewer_notes, sort_applied, bulk_approved)
    await db.commit()
    await _persist_capability_lineage_rework_block(db, gate_id, row_summary)
    # structlog "gate_escalated"
    return _gate_detail_from_row(row patched: status=escalated, decided_at, decided_by)
else:
    raise OlympusHTTPException(400, "INVALID_ACTION", f"Unknown action: {action}")
```
⚠️ Approve/reject in the unified path go through the SAME `approve_gate`/`reject_gate` (so the same 409 GATE_ALREADY_DECIDED applies). The router then fires the signal a SECOND time path — but note approve_gate/reject_gate do NOT fire the signal themselves; the signal is fired only by the router for approve/reject.

---

## [G6] POST `/api/v1/gates/{gate_id}/retry-merge` — retry_merge
- **path:line**: gates.py:512 (handler gates.py:517)
- **Method/Path**: `POST /api/v1/gates/{gate_id}/retry-merge`
- **Path param**: `gate_id: uuid.UUID`
- **Decorator deps**: `dependencies=[Depends(require_gate_member)]`
- **Auth**: `user = Depends(require_role(*REVIEWER_ROLES))`
- **Request body**: `body: GateMergeRetryRequest | None = None` (OPTIONAL; only `note`).
- **Response model**: `GateDetail`.
- **Status codes**: 200; 403; 404; 409 `GATE_NOT_MERGE_BLOCKED` (status != merge_blocked).
- **Handler logic**:
```python
note = body.note if body else None
return await gate_svc.retry_merge_gate(db, gate_id, user.sub, note)
```
- **Service `retry_merge_gate` (gate.py:1955)**:
```python
row = await _get_gate_or_404(db, gate_id)
if row["status"] != "merge_blocked":
    raise OlympusHTTPException(409, "GATE_NOT_MERGE_BLOCKED",
        f"Gate {gate_id} is not merge_blocked (status={row['status']})")
# Revert to approved (preserve decided_at/decided_by), clear failure detail
UPDATE gate SET status='approved', merge_failure_detail=NULL WHERE id=:id
await db.commit()
# ⚠️ Signal fired from the SERVICE (not the router) here:
await send_gate_temporal_signal(db, str(gate_id), "merge_retry", retried_by, note or "")
# structlog "gate_merge_retry_signalled"
return _gate_detail_from_row(row patched: status=approved, merge_failure_detail=None)
```
⚠️ GOTCHA — unlike approve/reject (router fires the signal), the merge-retry signal is fired **inside the service** `retry_merge_gate`. The "merge_retry" action maps to the `merge_retry` Temporal signal / `GateMergeRetrySignal` (see signal table).

---

## [G7] POST `/api/v1/gates/{gate_id}/force-advance` — force_advance_gate ⚠️ NON-OVERRIDABLE CHECK added at HEAD
- **path:line**: gates.py:544 (handler gates.py:549)
- **Method/Path**: `POST /api/v1/gates/{gate_id}/force-advance`
- **Path param**: `gate_id: uuid.UUID`
- **Decorator deps**: `dependencies=[Depends(require_gate_member)]`
- **Auth**: `user = Depends(require_role(*MANAGER_ROLES))` — ⚠️ MANAGER_ROLES ONLY (`portfolio_manager`, `portfolio_admin`). Privileged recovery.
- **Request body**: `body: GateForceAdvanceRequest` (REQUIRED; `comment` min_length=1, `bypass_evidence_check` default False).
- **Response model**: `GateDetail`.
- **Status codes**: 200; 403 (role) / **403 `GATE_NOT_OVERRIDABLE` ⚠️NEW**; 404; 409 `GATE_NOT_PREPARING` (status != preparing); 409 `GATE_EVIDENCE_NOT_FOUND` (evidence unverifiable and `bypass_evidence_check` false); 422 (empty comment).
- **Handler logic — ⚠️ NEW non-overridable check at HEAD**:
```python
gate_type, _portfolio_id = await gate_svc.get_gate_type_and_portfolio(db, gate_id)
policy = resolve_gate_review_policy(gate_type)
if not policy.management_override_allowed:
    raise OlympusHTTPException(403, "GATE_NOT_OVERRIDABLE",
        f"{gate_type} is non-overridable: the required sign-off ({sorted(policy.required_reviewer_roles)}) "
        "cannot be force-advanced by any role. Reject for rework instead.")
config = get_config()
return await gate_svc.force_advance_gate(db, gate_id, advanced_by=user.sub,
    comment=body.comment, bypass_evidence_check=body.bypass_evidence_check, config=config)
```
⚠️ GOTCHA — a gate whose profile marks `management_override_allowed: false` (FAA G-V3) CANNOT be force-advanced by ANY role including `portfolio_admin` (the MANAGER_ROLES gate still applies first; then this 403 fires). The gate can still be rejected for rework (`rbac-model.md` §5.1/§5.3).
- **Service `force_advance_gate` (gate.py:2084)** — every branch:
```python
row = await _get_gate_or_404(db, gate_id)
if row["status"] != "preparing":
    raise OlympusHTTPException(409, "GATE_NOT_PREPARING", "...only valid for gates in 'preparing'; ...")
if not bypass_evidence_check:
    has_evidence = await _verify_gate_evidence_exists(row, config)
    if not has_evidence:
        raise OlympusHTTPException(409, "GATE_EVIDENCE_NOT_FOUND", "...no verifiable evidence package...")
now = datetime.now(timezone.utc)
UPDATE gate SET status='approved', decided_at=:now, decided_by=:by, justification=:comment WHERE id=:id
# App-status advancement (app-scoped gates only):
app_id = row.get("application_id")
advanced_app_status = None
if app_id:
    app_row = SELECT current_status FROM application WHERE id=:id
    if app_row:
        current = app_row.get("current_status") or ""
        advance_to = _APP_STATUS_ADVANCE.get(current)        # {line}_in_progress -> {line}_complete
        if advance_to:
            UPDATE application SET current_status=:new_status, updated_at=:now WHERE id=:id
            advanced_app_status = advance_to
# Audit row:
INSERT INTO audit_log (actor, actor_type, action, resource_type, resource_id, details)
VALUES (:actor, 'human', 'gate.force_advance', 'gate', :resource_id, CAST(:details AS JSONB))
# details = {comment, bypass_evidence_check, from_status:"preparing", to_status:"approved", advanced_app_status}
await db.commit()
# structlog.warning "gate_force_advanced"
return _gate_detail_from_row(row patched: status=approved, decided_at, decided_by, justification=comment)
```
- `_APP_STATUS_ADVANCE` map (gate.py:2018): `discovery_in_progress→discovery_complete`, `rationalization_in_progress→rationalization_complete`, `architecture_in_progress→architecture_complete`, `data_in_progress→data_complete`, `modernization_in_progress→modernization_complete`, `validation_in_progress→validation_complete`, `deployment_in_progress→deployment_complete`, `disposition_execution_in_progress→disposition_execution_complete`, `sustainment_in_progress→sustainment_complete`, `governance_in_progress→governance_complete`.
- `_verify_gate_evidence_exists` (gate.py:2032): returns False if no `evidence_package_url` OR no `config.github_token`; parses `https://github.com/<owner>/<repo>/pull/<n>` (requires ≥7 parts and `parts[-2]=="pull"`); attempts `GitService(...)._repo.get_pull(pr_number)` → True on success, False on any exception. ⚠️ Fires NO Temporal signal (workflow already terminated — this is a DB fix-up).

---

## [G8] POST `/api/v1/gates/{gate_id}/resolve-escalation` — resolve_escalation
- **path:line**: gates.py:596 (handler gates.py:601)
- **Method/Path**: `POST /api/v1/gates/{gate_id}/resolve-escalation`
- **Path param**: `gate_id: uuid.UUID`
- **Decorator deps**: `dependencies=[Depends(require_gate_member)]`
- **Auth**: `user = Depends(require_role(*REVIEWER_ROLES))`
- **Request body**: `body: GateEscalationResolveRequest` (REQUIRED; `resolution_category` required, `notes` optional).
- **Response model**: `GateDetail`.
- **Status codes**: 200; 403; 404; 409 `GATE_NOT_ESCALATED`; 400 `ESCALATION_RESOLUTION_INVALID`; 422 (bad body).
- **Handler logic**:
```python
if body.resolution_category not in _ESCALATION_RESOLUTION_CATEGORIES:
    raise OlympusHTTPException(400, "ESCALATION_RESOLUTION_INVALID",
        f"Invalid resolution_category '{body.resolution_category}'. "
        f"Allowed: {sorted(_ESCALATION_RESOLUTION_CATEGORIES)}")
return await gate_svc.resolve_escalation(db, gate_id, user.sub,
                                         body.resolution_category, body.notes)
```
⚠️ The model already types `resolution_category` as the `EscalationResolutionCategory` Literal (so an invalid value → 422 at parse time), but the router ALSO re-checks against the set and returns 400 (`ESCALATION_RESOLUTION_INVALID`). Preserve both checks.

- **Service `resolve_escalation` (gate.py:2223)** — every branch:
```python
row = await _get_gate_or_404(db, gate_id)
if row["status"] != "escalated":
    raise OlympusHTTPException(409, "GATE_NOT_ESCALATED", f"Gate {gate_id} is not escalated (status={row['status']})")
now = datetime.now(timezone.utc)
justification = notes or f"Escalation resolved: {resolution_category}"
if resolution_category == "rejected-as-escalated":
    new_status = "rejected"
else:                                          # re-extract / manual-augment / re-disposition
    new_status = "pending"
UPDATE gate SET status=:status, decided_at=:now, decided_by=:by, justification=:reason WHERE id=:id
#   ⚠️ decided_at bind = (now if new_status != "pending" else None)  -> re-opened gates clear decided_at
await db.commit()
# structlog "escalation_resolved"
return _gate_detail_from_row(row patched: status=new_status,
    decided_at=(now if new_status != "pending" else None), decided_by=resolved_by, justification)
```
⚠️ GOTCHA — `rejected-as-escalated` → `rejected` (kicks rework loop). Other three categories → `pending` AND set `decided_at` back to None (fresh review). Fires NO Temporal signal.

---

# WAVE GATES ROUTER (`/api/v1/waves`)

## [W1] POST `/api/v1/waves/{wave_id}/gates/approve-pending` — approve_pending_wave_gates ⚠️ per-gate RBAC+quorum at HEAD
- **path:line**: gates.py:640 (handler gates.py:644)
- **Method/Path**: `POST /api/v1/waves/{wave_id}/gates/approve-pending`
- **Path param**: `wave_id: uuid.UUID`
- **Decorator deps**: NONE (no `require_gate_member` — there is no single gate; ⚠️ also NO `require_wave_member`).
- **Auth**: `user = Depends(require_role(*REVIEWER_ROLES))`.
- **Query param**: `gate_type: str | None = Query(default=None)` — optional gate-type filter (e.g. `G-RR`).
- **Request body**: `body: WaveBatchApproveRequest` (REQUIRED; `comment` min_length=1).
- **Response model**: `WaveBatchApproveResponse` (`{approved:int, gate_ids:list[UUID]}`).
- **Status codes**: 200; 403; 422 (empty comment). Returns 200 with `approved=0,gate_ids=[]` when no pending gates.
- **Handler logic — reproduce every branch (⚠️ REWRITTEN at HEAD — per-gate RBAC + quorum)**:
```python
rows = await gate_svc.list_pending_wave_gates(db, wave_id, gate_type)   # list[UUID] — RESOLVED (gate.py:243)
if not rows:
    return WaveBatchApproveResponse(approved=0, gate_ids=[])
approved_ids: list[uuid.UUID] = []
for gate_id in rows:
    # 1) Per-gate RBAC. A gate the caller can't approve is SKIPPED (a single forbidden gate doesn't abort the batch).
    try:
        policy, scoped_role, decision = await _enforce_gate_reviewer(db, user, gate_id)
    except OlympusHTTPException as exc:
        if exc.status_code == 403:
            continue
        raise
    # 2) Record this caller's approval toward quorum. Swallow a racey 409 GATE_ALREADY_DECIDED.
    try:
        _result, advanced = await gate_svc.record_gate_approval(
            db, gate_id, user.sub, scoped_role,
            minimum_approvals=policy.minimum_approvals, oversight_role=policy.oversight_role,
            is_oversight=decision.is_oversight, is_management_override=decision.is_management_override,
            comment=body.comment)
    except OlympusHTTPException as exc:
        if exc.code == "GATE_ALREADY_DECIDED":
            continue
        raise
    # 3) ⚠️ Only signal + COUNT gates that actually advanced (quorum met). A gate that needs more approvals
    #    records THIS approval but does NOT advance/signal and is NOT counted in ``approved``.
    if advanced:
        await gate_svc.send_gate_temporal_signal(db, str(gate_id), "approve", user.sub, body.comment)
        approved_ids.append(gate_id)
return WaveBatchApproveResponse(approved=len(approved_ids), gate_ids=approved_ids)
```
⚠️ GOTCHA — `approved` counts ONLY gates that actually advanced (quorum + oversight met). The SAME `comment` is recorded on every approval. A gate the caller may not approve (403) is SKIPPED, not aborted; a racey 409 `GATE_ALREADY_DECIDED` is skipped; any other exception propagates. The `approve` signal fires the G-DA dual signal if a swept gate is `G-DA`.

### ✅ RESOLVED (was UNDETERMINED #1) — `gate_svc.list_pending_wave_gates` NOW EXISTS
At HEAD `7cb3b20c` the function is defined at **`gate.py:243`** (the prior spec flagged it missing). Contract:
```python
async def list_pending_wave_gates(db, wave_id: uuid.UUID, gate_type: str | None = None) -> list[uuid.UUID]:   # gate.py:243
    sql = "SELECT id FROM gate WHERE wave_id = :wid AND status = 'pending'"
    bind = {"wid": wave_id}
    if gate_type: sql += " AND gate_type = :gt"; bind["gt"] = gate_type
    sql += " ORDER BY requested_at"          # ⚠️ ordered by requested_at (oldest first)
    rows = (await db.execute(text(sql), bind)).mappings().all()
    return [r["id"] for r in rows]
```

---

# ESCALATIONS ROUTER (`/api/v1/escalations`)

All endpoints are self-contained in escalations.py (no `gate_svc`; raw SQL on the `escalation` table, migration 003). Schema source: `specifications/api/domains/escalations.yaml`.

### Local types (escalations.py:57-103)
```python
EscalationStatus  = Literal["open","investigating","resolved"]                              # :57
EscalationType    = Literal["Technical","Domain","Strategic","Safety","Infrastructure"]     # :58
EscalationSeverity= Literal["Critical","Standard","Low"]                                    # :59

class EscalationSummary(BaseModel):     # :62
    id: uuid.UUID; type: EscalationType; severity: EscalationSeverity
    status: EscalationStatus; app_id: uuid.UUID; created_at: datetime

class EscalationResolution(BaseModel):  # :71
    resolution_type: str; details: str; resolved_by: str = ""
    resolved_at: datetime | None = None; pattern_extracted: bool = False

class EscalationDetail(BaseModel):      # :79
    id: uuid.UUID; type: EscalationType; severity: EscalationSeverity; status: EscalationStatus
    app_id: uuid.UUID; context: dict[str,Any] = {}; trigger_details: dict[str,Any] = {}
    resolution: EscalationResolution | None = None; created_at: datetime

class EscalationResolveRequest(BaseModel):  # :91
    resolution_type: Literal["Re-Extract","Manual Augment","Re-Disposition"]   # ⚠️ DIFFERENT spelling than gate EscalationResolutionCategory
    details: str

class EscalationMetrics(BaseModel):     # :96
    total: int; open: int; avg_resolution_time_hours: float = 0.0
    pattern_extraction_rate: float = 0.0; by_type: dict[str,int] = {}; by_severity: dict[str,int] = {}
```
⚠️ GOTCHA — `EscalationResolveRequest.resolution_type` uses `"Re-Extract" | "Manual Augment" | "Re-Disposition"` (title-case, space-separated), which is a DIFFERENT literal set than the gate `EscalationResolutionCategory` (`re-extract` / `manual-augment` / `re-disposition` / `rejected-as-escalated`). These are two unrelated escalation concepts (gate escalation vs. standalone escalation domain).

### `_row_to_detail(row: dict) -> EscalationDetail` (escalations.py:110)
```python
resolution = None
if row.get("status") == "resolved" and row.get("resolution"):
    res = row["resolution"] if isinstance(row["resolution"], dict) else {}
    resolution = EscalationResolution(
        resolution_type = row.get("resolution_type") or res.get("resolution_type") or "",
        details = str(res.get("details") or ""),
        resolved_by = str(row.get("resolver") or ""),
        resolved_at = row.get("updated_at"),
        pattern_extracted = bool(row.get("pattern_extracted")),
    )
trigger_details = row.get("trigger_details") or {}
if not isinstance(trigger_details, dict): trigger_details = {}
context = {"line":row.get("line"),"step":row.get("step"),"skill":row.get("skill"),
           "agent":row.get("agent"),"trigger_type":row.get("trigger_type")}
context = {k:v for k,v in context.items() if v is not None}     # strip Nones
return EscalationDetail(id=row["id"], type=row["type"], severity=row["severity"],
    status=row["status"], app_id=row["application_id"], context=context,
    trigger_details=trigger_details, resolution=resolution, created_at=row["created_at"])
```
⚠️ `app_id` in the model is fed from the DB column `application_id`.

---

## [E1] GET `/api/v1/escalations` — list_escalations
- **path:line**: escalations.py:154 (handler escalations.py:155)
- **Method/Path**: `GET /api/v1/escalations` (empty path string `""` on the router → resolves to the prefix exactly).
- **Auth**: `_user = Depends(require_role(*VIEWER_PLUS))` (VIEWER_PLUS local list, escalations.py:32 — identical membership to gates VIEWER_PLUS).
- **Query params**:
  - `status: EscalationStatus | None = None`
  - `type: EscalationType | None = None`
  - `severity: EscalationSeverity | None = None`
  - `app_id: uuid.UUID | None = None`
  - `pagination = Depends(get_pagination)`
- **Request body**: none.
- **Response**: `dict` (no response_model) → `paginated_response`. Each item `EscalationSummary(...).model_dump(mode="json")`.
- **Status codes**: 200; 403; 422 (invalid enum query value).
- **Handler logic**:
```python
where_clauses = []; params = {"limit": pagination.per_page, "offset": pagination.offset}
if status:   where_clauses.append("status = :status");           params["status"]=status
if type:     where_clauses.append("type = :type");               params["type"]=type
if severity: where_clauses.append("severity = :severity");       params["severity"]=severity
if app_id:   where_clauses.append("application_id = :app_id");    params["app_id"]=app_id
where_sql = ("WHERE " + " AND ".join(where_clauses)) if where_clauses else ""
total = (await db.execute(text(f"SELECT count(*) FROM escalation {where_sql}"), params)).scalar() or 0
rows = (await db.execute(text(f"""
    SELECT id, type, severity, status, application_id, created_at
    FROM escalation {where_sql}
    ORDER BY created_at DESC
    LIMIT :limit OFFSET :offset"""), params)).mappings().all()
data = [EscalationSummary(id=r["id"], type=r["type"], severity=r["severity"], status=r["status"],
                          app_id=r["application_id"], created_at=r["created_at"]).model_dump(mode="json")
        for r in rows]
return paginated_response(data, int(total), pagination)
```
⚠️ ORDER BY `created_at DESC`. ⚠️ NO portfolio-membership filtering on this endpoint (unlike gates /pending).

---

## [E2] GET `/api/v1/escalations/metrics` — get_metrics
- **path:line**: escalations.py:219 (handler escalations.py:220)
- **Method/Path**: `GET /api/v1/escalations/metrics`
- **Auth**: `_user = Depends(require_role(*VIEWER_PLUS))`.
- **Query/body**: none.
- **Response model**: `EscalationMetrics`.
- **Status codes**: 200; 403.
- **Handler logic — every query**:
```python
total = int((await db.execute(text("SELECT count(*) FROM escalation"))).scalar() or 0)
open_count = int((await db.execute(text("SELECT count(*) FROM escalation WHERE status != 'resolved'"))).scalar() or 0)
avg_row = (await db.execute(text(
    "SELECT AVG(EXTRACT(EPOCH FROM (updated_at - created_at)) / 3600.0) FROM escalation WHERE status='resolved'"))).scalar()
avg_hours = float(avg_row) if avg_row is not None else 0.0
pattern_row = (await db.execute(text(
    "SELECT SUM(CASE WHEN pattern_extracted THEN 1 ELSE 0 END)::float / NULLIF(count(*)::float, 0) "
    "FROM escalation WHERE status='resolved'"))).scalar()
pattern_rate = float(pattern_row) if pattern_row is not None else 0.0
by_type_rows = (await db.execute(text("SELECT type, count(*) AS cnt FROM escalation GROUP BY type"))).mappings().all()
by_severity_rows = (await db.execute(text("SELECT severity, count(*) AS cnt FROM escalation GROUP BY severity"))).mappings().all()
return EscalationMetrics(total=total, open=open_count,
    avg_resolution_time_hours=round(avg_hours, 2),       # ⚠️ rounded to 2
    pattern_extraction_rate=round(pattern_rate, 4),      # ⚠️ rounded to 4
    by_type={str(r["type"]): int(r["cnt"]) for r in by_type_rows},
    by_severity={str(r["severity"]): int(r["cnt"]) for r in by_severity_rows})
```
⚠️ `open` counts `status != 'resolved'` (includes both `open` and `investigating`). avg uses `updated_at - created_at` epoch hours over resolved rows only.

⚠️⚠️ ROUTE-ORDER GOTCHA — `/metrics` (escalations.py:219) is declared AFTER the list endpoint but BEFORE `/{escalation_id}` (escalations.py:283). Because `/metrics` is a static path it must be matched before the `/{escalation_id}` catch-all. FastAPI resolves in definition order, so `/metrics` is correctly registered before `/{escalation_id}`. Preserve this ordering on regeneration or `/metrics` would be swallowed by `/{escalation_id}` (and fail UUID parsing with 422).

---

## [E3] GET `/api/v1/escalations/{escalation_id}` — get_escalation
- **path:line**: escalations.py:283 (handler escalations.py:284)
- **Method/Path**: `GET /api/v1/escalations/{escalation_id}`
- **Path param**: `escalation_id: uuid.UUID`
- **Auth**: `_user = Depends(require_role(*VIEWER_PLUS))`.
- **Body**: none.
- **Response model**: `EscalationDetail`.
- **Status codes**: 200; 403; 404 `ESCALATION_NOT_FOUND`; 422 (non-UUID path).
- **Handler logic**:
```python
row = (await db.execute(text("SELECT * FROM escalation WHERE id = :id"), {"id": escalation_id})).mappings().first()
if row is None:
    raise OlympusHTTPException(404, "ESCALATION_NOT_FOUND", f"Escalation {escalation_id} not found")
return _row_to_detail(dict(row))
```

---

## [E4] POST `/api/v1/escalations/{escalation_id}/resolve` — resolve_escalation
- **path:line**: escalations.py:303 (handler escalations.py:304)
- **Method/Path**: `POST /api/v1/escalations/{escalation_id}/resolve`
- **Path param**: `escalation_id: uuid.UUID`
- **Auth**: `user = Depends(require_role(*RESOLVER_ROLES))` — ⚠️ RESOLVER_ROLES (escalations.py:43) = `[TECH_LEAD, PORTFOLIO_MANAGER, PORTFOLIO_ADMIN]` ONLY (narrower than gates REVIEWER_ROLES — no arch/compliance/operations/safety).
- **Request body**: `body: EscalationResolveRequest` (REQUIRED; `resolution_type` Literal title-case, `details: str`).
- **Response model**: `EscalationDetail`.
- **Status codes**: 200; 403; 404 `ESCALATION_NOT_FOUND`; 409 `ESCALATION_ALREADY_RESOLVED`; 422 (bad body, e.g. wrong resolution_type literal).
- **Handler logic — every branch**:
```python
row = (await db.execute(text("SELECT * FROM escalation WHERE id = :id"), {"id": escalation_id})).mappings().first()
if row is None:
    raise OlympusHTTPException(404, "ESCALATION_NOT_FOUND", f"Escalation {escalation_id} not found")
if row["status"] == "resolved":
    raise OlympusHTTPException(409, "ESCALATION_ALREADY_RESOLVED", f"Escalation {escalation_id} has already been resolved")
now = datetime.now(timezone.utc)
resolution_payload = {"resolution_type": body.resolution_type, "details": body.details}
await db.execute(text("""
    UPDATE escalation
    SET status='resolved', resolver=:resolver, resolution_type=:resolution_type,
        resolution=CAST(:resolution AS JSONB), updated_at=:now
    WHERE id=:id"""),
    {"id": escalation_id, "resolver": user.sub, "resolution_type": body.resolution_type,
     "resolution": __import__("json").dumps(resolution_payload), "now": now})
await db.commit()
refreshed = (await db.execute(text("SELECT * FROM escalation WHERE id = :id"), {"id": escalation_id})).mappings().first()
return _row_to_detail(dict(refreshed)) if refreshed else _row_to_detail(dict(row))
```
⚠️ GOTCHA — `__import__("json").dumps(...)` is used inline (not a top-level json import in this file). The `resolution` JSONB column stores `{"resolution_type", "details"}`; `resolver` stores `user.sub`; `pattern_extracted` is NOT set here (stays at its DB default — surfaces as False in `_row_to_detail`). Re-fetches after commit so the response reflects persisted state. Fires NO Temporal signal (escalation domain is DB-only, distinct from gate escalations).

---

## CROSS-CUTTING NOTES / GOTCHAS SUMMARY

1. ⚠️ **Two unrelated "resolve escalation" concepts**: gate escalation (`POST /api/v1/gates/{id}/resolve-escalation`, gate.py service, `EscalationResolutionCategory` kebab-case) vs. escalation-domain (`POST /api/v1/escalations/{id}/resolve`, raw SQL, `Re-Extract|Manual Augment|Re-Disposition` title-case). Do NOT merge them.
2. ⚠️ **Signal firing location is inconsistent by design**: approve/reject signals fire from the ROUTER (after the service commits); merge_retry fires from INSIDE the service (`retry_merge_gate`). force-advance, resolve-escalation (gate), escalate-via-/decision, and the entire escalations router fire NO signal.
3. ⚠️ **G-DA dual signal**: an approve on a `G-DA` gate fires BOTH `gate_approved` and `stakeholder_approved(scope="g-da", approval_id=f"gda-{gate_id}")`. Applies to single /approve, /decision approve, AND each swept gate in the wave batch.
4. ⚠️ **send_gate_temporal_signal never raises**: all exceptions swallowed (fire-and-forget). HTTP responses always reflect the committed DB state regardless of Temporal reachability.
5. ⚠️ **Status preconditions** (409 codes): approve/reject/escalate require `pending` → `GATE_ALREADY_DECIDED`; retry-merge requires `merge_blocked` → `GATE_NOT_MERGE_BLOCKED`; force-advance requires `preparing` → `GATE_NOT_PREPARING`; gate resolve-escalation requires `escalated` → `GATE_NOT_ESCALATED`; escalation-domain resolve rejects already-`resolved` → 409 `ESCALATION_ALREADY_RESOLVED`.
6. ⚠️ **OlympusHTTPException** signature: `(status_code, code, message, details=None)`. Renders as `{"error":{"code","message","details","request_id"}}`. The `require_role`/membership deps raise plain `fastapi.HTTPException` (string or dict detail), NOT OlympusHTTPException.
7. ⚠️ **Auth shape changed at HEAD (P6-S6).** `approve`/`reject`/`decision` use `Depends(get_current_user)` + in-handler `_enforce_gate_reviewer` (approve) / `_enforce_gate_decider` (reject/escalate) — gate-type→policy on the caller's PORTFOLIO-SCOPED role, NOT the JWT roles. `retry-merge`/`resolve-escalation` still use `require_role(*REVIEWER_ROLES)`; `force-advance` still `require_role(*MANAGER_ROLES)` PLUS the new `GATE_NOT_OVERRIDABLE` policy check; `evidence` still VIEWER_PLUS; `reviewer-roles` uses get_current_user + require_gate_member; `/pending` is still role-gate-free (membership filtering in-handler).
8. ⚠️ Approve/reject in `submit_gate_decision` delegate to `approve_gate`/`reject_gate`; those service functions do NOT fire the signal — the signal is only fired by the calling router. So a direct service-level test of `submit_gate_decision` does not emit a Temporal signal.
9. ⚠️ **NEW — quorum/oversight.** `/approve` and the wave-batch endpoint go through `record_gate_approval` (gate.py:496): a `gate_approval` row is inserted (ON CONFLICT `(gate_id,approved_by)` DO NOTHING — idempotent), the gate advances and signals ONLY when `count(approvals) >= minimum_approvals` AND oversight co-sign (if any) is satisfied. A pending-quorum approve returns 200 with `status='pending'` + `GateDetail.pending_approvals`, and fires NO signal.
10. ⚠️ **NEW — `GATE_NOT_OVERRIDABLE` (403).** `force-advance` of a gate whose profile sets `management_override_allowed: false` (FAA G-V3) is denied for EVERY role incl. `portfolio_admin`. Reject-for-rework is still allowed (§5.1).
11. ⚠️ **3 new 403 codes from the policy layer:** `PORTFOLIO_ROLE_INSUFFICIENT` (scoped role not permitted for the gate type), `PORTFOLIO_NOT_MEMBER` (scoped role unresolved), `GATE_NOT_OVERRIDABLE`. Policy comes from `gate_rbac.resolve_gate_review_policy(gate_type)` = profile `overrides[gate].rbac` block merged over the `_PLATFORM_DEFAULTS` table.
