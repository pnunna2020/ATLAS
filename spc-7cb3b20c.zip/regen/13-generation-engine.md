# 13 — Generation Engine (Extract → Design → Generate factory + Ralph Loop)

> ATOMIC regeneration spec. Premise: the codebase is deleted; this file is the only surviving artifact for the **code-generation subsystem**. Rebuild so the engine behaves IDENTICALLY: every loop, stop-condition, branch, early-return, exception path. This subsystem was ABSENT from the prior spec — treat every claim as load-bearing.
>
> Scope files (all read in full):
> - `temporal/olympus_workflows/workflows/generate_bc.py` — `GenerateBCWorkflow`, the Ralph Loop carrier.
> - `temporal/olympus_workflows/workflows/modernization.py` — `ModernizationWorkflow`, the Extract→Design→Generate factory + BC fan-out.
> - `temporal/olympus_workflows/workflows/code_generation_router.py` — `select_code_generation_skill`.
> - `temporal/olympus_workflows/activities/agent_dispatch.py` — `dispatch_agent_task` / `_dispatch_agent_task_inner` (the activity each Ralph step runs).
> - `temporal/olympus_workflows/types.py` — constants (`MAX_RALPH_ITERATIONS=10` :134, `MAX_BC_CHILDREN_PER_APP=12` :133), `AgentTaskInput`/`AgentTaskResult`/`GenerateBCInput`/`GenerateBCResult`, `ResolutionType`, `TaskStatus`.
> - `temporal/olympus_workflows/retry_policies.py` — `RETRY_POLICIES["agent_failure"]`.
> - Supporting: `temporal/olympus_workflows/workflows/base.py` (`_wait_for_gate_decision` :1075, `_reconcile_and_merge_with_retry_loop` :1131), `foundry_temporal/signals.py` (`HILSignalsMixin`: `cancelled` flag :37, `cancel_workflow` signal :76). NEW supporting at HEAD: `activities/profile_devsecops.py` (`resolve_devsecops_profile` :145), `activities/devsecops_validation.py` (`validate_devsecops_baseline`, `REQUIRED_CI_JOBS` 7 jobs :41, `passed = not missing and not errors` :235), `devsecops_contract.py` (`is_root_bound` :146, `route_generate_file` :168, `ROOT_BOUND_PREFIXES` :70 / `ROOT_BOUND_EXACT` :92), `workflows/bundle_helpers.py` (`BundleAwareMixin` / `_maybe_dispatch_bundle` — Design delegation).
>
> Cross-refs (do NOT re-reproduce): `regen/02-agent-runtime.md` (the A2A `build_system_prompt` envelope + mock runtime fixture resolution + `parse_agent_json` / `output_validator`), `regen/03-workflows/` (the wave/portfolio/app parent chain that *spawns* `ModernizationWorkflow`), `regen/03b-activities/` (git_operations + gate_operations + line_transitions activities).

---

## 0. One-paragraph mental model (then never rely on it again)

Modernization is a **per-app Temporal workflow** (`ModernizationWorkflow`, now `BundleAwareMixin, LineWorkflowBase`) with three sequential phases — **Extract → Design → Generate** — each terminated by a human gate (G-04a / G-04b / G-04c). Each phase is a `while True:` rework loop: dispatch agent skills, commit artifacts to Git, open a PR, create a gate record, submit evidence, wait for the gate decision signal, and on approval merge + project side-effects + `return "approved"`; on rejection bump a rework counter and loop (fail after >3). The **Design** phase now routes through a delegated-bundle dispatch (`_maybe_dispatch_bundle`) with the internal agent chain (`_dispatch_design_internal`) as fallback. The **Generate** phase additionally: resolves the profile's DevSecOps baseline params ONCE up front (`resolve_devsecops_profile`, 8-key dict, reused across reworks), **fans out one child workflow (`GenerateBCWorkflow`) per bounded context** (capped at 12), `asyncio.gather`s them, synthesizes, runs adversarial-review + security-posture-review + (best-effort) security-scan-review + iac-scaffolding + gate-review-package, commits to the **target repo root** under the W11 contract, then — ⚠️ **INTERPOSED BETWEEN COMMIT AND PR** — runs the deterministic `validate_devsecops_baseline` activity; a failed baseline is a SECOND, machine-driven rework trigger (sharing the G-04c counter) that `continue`s the loop to re-fan-out WITHOUT opening a PR, failing the line after >3. Each child runs the **Ralph Loop**: `while iteration < 10:` { write tests (tdd-generation) → generate code (code-generation-*) → run tests (test-validation) }, returning success the first iteration the test-validation agent reports `COMPLETED` with no error; on exhausting 10 iterations it creates an escalation record and **blocks on a human resolution signal**, where `ABANDON` becomes a terminal "abandoned" status that fails the parent. **All three Ralph steps are agent dispatches** — tests are "run" by the `test-validation` *agent*, not a real pytest subprocess; the loop trusts the agent's self-reported `status`. ⚠️ This trust boundary is the single most important parity fact.

---

## 1. CONSTANTS — exact values, exact source lines

`temporal/olympus_workflows/types.py`:
```
MAX_CONCURRENT_WAVES      = 4    # :131
MAX_APPS_PER_WAVE         = 10   # :132
MAX_BC_CHILDREN_PER_APP   = 12   # :133   ← Generate fan-out cap
MAX_RALPH_ITERATIONS      = 10   # :134   ← Ralph Loop iteration cap
MAX_VALIDATION_STREAMS    = 4    # :135   (not used by this subsystem)
```
`temporal/olympus_workflows/workflows/modernization.py`:
```
MAX_REWORK_ITERATIONS = 3        # :203   ← per-gate rework cap (G-04a/b/c)
```

⚠️ **GOTCHA — docstring/code mismatch on the fan-out cap.** The class docstring says "max 5 children" (`modernization.py:228` "Concurrency: max 5 bounded context children per app") and `generate_bc.py:4` says "up to MAX_BC_CHILDREN_PER_APP in parallel". The **authoritative value is `MAX_BC_CHILDREN_PER_APP = 12`** (`types.py:133`), and the code slices `bc_names[:MAX_BC_CHILDREN_PER_APP]` (`modernization.py:1786`). A rebuild MUST use 12, not 5. The "5" is stale prose.

⚠️ **GOTCHA — `MAX_REWORK_ITERATIONS` is a strict `>` comparison.** A gate may be rejected up to **3 times and still recover** on the 4th submission; failure triggers only when `_rework_count(...) > 3` (`modernization.py:978` G-04a, `:1334` G-04b, `:2090` G-04c human-rejection). I.e. attempts allowed = `MAX_REWORK_ITERATIONS + 1` design/extract/generate cycles. ⚠️ **CHANGED at HEAD:** Generate now has a **SECOND** `> MAX_REWORK_ITERATIONS` site at `:1968` — the DevSecOps-baseline-validation rework branch — which shares the same `G-04c` rework counter as the human-rejection branch at `:2090`. So the 4-cycle budget is consumed by *either* a failed machine baseline-validation *or* a human G-04c rejection. See §2.6.

⚠️ **GOTCHA — Ralph cap is `<` not `<=`.** `while self._iteration < MAX_RALPH_ITERATIONS` (`generate_bc.py:96`) with `self._iteration += 1` as the FIRST statement of the body (`:97`). So the body runs for `_iteration` values `1..10` inclusive — **exactly 10 iterations** — then exits to escalation. Do NOT off-by-one this.

---

## 2. THE EXTRACT → DESIGN → GENERATE FACTORY (`ModernizationWorkflow`)

### 2.0 Class identity, base, configuration

`modernization.py:206-291`:
- `@workflow.defn class ModernizationWorkflow(BundleAwareMixin, LineWorkflowBase)` (`:206-207`). ⚠️ **CHANGED at HEAD:** the base was `LineWorkflowBase` only; it now ALSO inherits `BundleAwareMixin` (Phase 6 W1 delegated-bundle handling — `bundle_completed`/`bundle_expired` signals + `await_bundle_completion`). MRO: `ModernizationWorkflow → BundleAwareMixin → LineWorkflowBase → HILSignalsMixin → object` (`:217-220`). `BundleAwareMixin.__init__` calls `super().__init__()` so the whole chain initialises once.
- Class config attrs (`:232-235`): `ASSEMBLY_LINE = AssemblyLine.MODERNIZATION`, `ARTIFACT_ROOT = "modernization"`, `LINE_LABEL = "Modernization"`, `STATUS_PREFIX = "modernization"`.
- `SINGLE_GATE_KEY` intentionally **unset** (`:236-240`) — Modernization is the only line with three gates; step→gate routing is custom via `_rework_gate_key_for_step` (`:297-335`).
- `__init__` adds (`:242-291`):
  - `self._extract_results: dict[str,list[str]] = {}` (`:248`) — per-step artifact paths for the Extract phase.
  - `self._design_results: dict[str,list[str]] = {}` (`:249`) — same for Design.
  - `self._generate_results: list[GenerateBCResult] = []` (`:250`) — the gathered child results.
  - `self._rework_iterations.update({"G-04a":0,"G-04b":0,"G-04c":0})` (`:256`) — seed per-gate counters so PR-body reads don't `KeyError`.
  - `self._received_patterns: list[dict] = []` (`:264`) — governance-delivered patterns (F5 flywheel), threaded into every dispatch context.
  - `self._g04c_stakeholder_ea_approved = False`, `self._g04c_stakeholder_security_approved = False` (`:272-273`), `self._g04a_stakeholder_sme_approved = False` (`:276`) — Tier-1 triple/SME signal flags.
  - ⚠️ **NEW at HEAD — `self._devsecops_params: dict[str, Any] = {}`** (`:285`) — profile-resolved DevSecOps baseline params (8 keys: `sast_tool`, `sbom_required`, `container_base`, `license`, `target_cloud`, `primary_ecosystem`, `iac`, `cicd`). Empty until the Generate step resolves it once (§2.6). Threaded into every factory dispatch context as `context["devsecops_baseline"]` (§2.3).
  - ⚠️ **NEW at HEAD — `self._committed_baseline_files: list[tuple[str, str]] = []`** (`:291`) — the root-bound `(repo_path, content)` pairs committed to the target repo root during the most recent Generate commit. Repopulated each Generate iteration by `_commit_generate_artifacts` (`:2339`) and handed to the deterministic G-04c baseline validator (§2.6).

Registration: `temporal/olympus_workflows/worker.py` registers `GenerateBCWorkflow`; `ModernizationWorkflow` is registered alongside the other line workflows. ⚠️ Both MUST be registered on the **same task queue** — the child is spawned with `task_queue=workflow.info().task_queue` (`modernization.py:1811`).

### 2.1 Workflow entry `run` (`modernization.py:633-670`)

```
@workflow.run
async def run(input: LineWorkflowInput) -> str:                       # :633
    self._status = WorkflowStatus.RUNNING                             # :642
    self._started_at = _now_iso(); self._updated_at = started_at      # :643-644
    self._app_id = input.app_id                                       # :645
    self._portfolio_id = input.portfolio_id                           # :646
    self._wave_id = input.wave_id                                     # :647
    self._input = input                                               # :650  ⚠ NOW SET
    self._risk_tier = int(input.risk_tier) if input.risk_tier is not None else None   # :651-653
    try:
        return await self._execute_modernization(input)              # :656
    except Exception:                                                 # :657
        self._status = WorkflowStatus.FAILED                          # :658
        self._current_step = "failed"; self._updated_at = _now_iso()  # :659-660
        try:
            await self._update_app_status(input.app_id,
                "modernization_failed", "failed", "Modernization")    # :662-667
        except Exception: pass                                        # :668-669
        raise                                                         # :670
```
Return value: the literal string `"completed"` on full success (used by the parent app/wave workflow). Intermediate non-approval returns propagate the gate decision string (`"failed"` / `"cancelled"`).

⚠️ **GOTCHA — `self._input` IS now set in `run` (`:650`) — CHANGED from old behavior.** The prior spec claimed `self._input` was never set, making `_collect_extract_artifacts`'s blueprint-forwarding branch a no-op. **That is no longer true at HEAD.** `run` explicitly assigns `self._input = input` (`:650`) so the base helpers (`_workflow_input_prior_artifacts` at `:1376-1383`, `_workflow_created_by`) and the delegated-bundle wiring can read it. Consequence: `_collect_extract_artifacts` (`:1353-1374`) NOW forwards architecture/blueprint-shaped prior artifacts into Design — the forwarding is **live**, not inert. `_workflow_input_prior_artifacts` still does `getattr(self,"_input",None)` defensively (returns `[]` only when unit tests stub `run` without setting it).

### 2.2 `_execute_modernization` (`modernization.py:672-733`) — the linear 3-phase spine

```
async def _execute_modernization(input) -> str:                      # :672
    app_id = input.app_id                                            # :674
    self._artifact_repo = input.artifact_repo                        # :680
    repo = getattr(input,"target_repo_url","") or input.artifact_repo # :681  ⚠
    source_repo = input.source_repo                                  # :682
    wf_id = workflow.info().workflow_id                              # :684
    run_suffix = wf_id.rsplit("-",1)[-1] if "-" in wf_id else wf_id[:8]   # :685
    workspace_key = f"modernization-{app_id}-{run_suffix}"          # :686
    await self._seed_patterns_from_registry(input.portfolio_id)     # :692  (F5 cold-start, best-effort)
    await self._load_delegation_config(input.portfolio_id)          # :698  ⚠ NEW — Phase 6 W1 delegation config
    await self._update_app_status(app_id,
        "modernization_in_progress","extract","Modernization")      # :701-703

    extract_result = await self._execute_extract(input, app_id, repo,
                          source_repo, run_suffix, workspace_key)    # :706
    if extract_result != "approved": return extract_result          # :709-710  ← EARLY RETURN

    design_result = await self._execute_design(... same args ...)   # :713
    if design_result != "approved": return design_result            # :716-717  ← EARLY RETURN

    generate_result = await self._execute_generate(... same args ...) # :720
    if generate_result != "approved": return generate_result        # :723-724  ← EARLY RETURN

    await self._update_app_status(app_id,
        "modernization_complete","completed","Modernization")        # :726-728
    self._status = WorkflowStatus.COMPLETED                          # :729
    self._progress_pct = 100.0; self._current_step = "completed"     # :730-731
    self._updated_at = _now_iso()                                    # :732
    return "completed"                                               # :733
```

⚠️ **GOTCHA — commit repo = target repo, not artifact repo.** `repo` (`:681`) is the **target application modernization repo** (`input.target_repo_url`) when populated, falling back to `input.artifact_repo` for pre-A3 callers. Every commit/PR/gate-record/read-module-map in all three phases uses this `repo`. `self._artifact_repo` is separately retained (`:680`) for governance-only paths. A rebuild must thread `target_repo_url` as the commit target.

⚠️ **NEW at HEAD — `_load_delegation_config` (`:698`)** loads the portfolio's delegation config once (Phase 6 W1) so the Design step can route through a delegated bundle when marked delegated, with internal fallback on expiry. Best-effort like `_seed_patterns_from_registry`. See §2.5 (Design now goes through `_maybe_dispatch_bundle`).

⚠️ **GOTCHA — `run_suffix` is parsed from the workflow id.** Branch names (`olympus/modernization/extract/{app_id}/{run_suffix}` etc.) and the child workflow ids embed `run_suffix`. It is the substring after the last `-` of the workflow id, or the first 8 chars if no `-` present (`:685`). This makes branch names and child ids **deterministic per workflow run** — required for Temporal determinism and idempotent child-id collision avoidance.

⚠️ **GOTCHA — `workspace_key` is shared across all three phases and every agent dispatch.** It is `modernization-{app_id}-{run_suffix}` (`:686`) and is passed to `_dispatch_agent(..., workspace_key=...)` for extraction, cross-validation, reconciliation, all design steps, synthesis, adversarial-review, security-posture-review, security-scan-review, iac-scaffolding, gate-review-package. The agent runtime uses this to key a persistent workspace so later skills see earlier skills' files. ⚠️ Child `GenerateBCWorkflow` dispatches do **NOT** set `workspace_key` (see §3.4) — they pass artifact lists explicitly instead.

### 2.3 `_dispatch_agent` override (`modernization.py:409-482`) — how every factory agent call is made

This is the single chokepoint for all factory-phase agent dispatches (NOT the Ralph child — that calls `dispatch_agent_task` directly, see §3).

```
async def _dispatch_agent(app_id, step_name, skill_id, input_artifacts,
                          source_repo="", workspace_key="") -> AgentTaskResult:   # :409
    context = {}                                                     # :435
    gate_key = self._rework_gate_key_for_step(step_name)             # :436
    if gate_key is not None:
        fb = self._rework_feedback.get(gate_key)                     # :438
        if fb is not None: context["rework_feedback"] = fb           # :439-440
    if self._received_patterns:
        context["governance_patterns"] = list(self._received_patterns)  # :445-446
    if self._devsecops_params:                                       # :451  ⚠ NEW
        context["devsecops_baseline"] = dict(self._devsecops_params)  # :452  ⚠ NEW
    task_input = AgentTaskInput(
        task_type=f"modernization-{step_name}",                      # :454
        app_id=app_id, skill_id=skill_id,
        input_artifacts=input_artifacts, source_repo=source_repo,
        workspace_key=workspace_key, context=context,
        execution_context=self._execution_ctx(step_name, app_id=app_id,
            input_artifact_paths=input_artifacts))                   # :453-466
    result = await workflow.execute_activity(
        dispatch_agent_task, task_input,
        start_to_close_timeout=timedelta(hours=1),                   # :470  ← 1h
        retry_policy=RETRY_POLICIES["agent_failure"],                # :471  ← 3 attempts
        activity_id=f"agent-{step_name}")                            # :472
    self._agent_metadata[step_name] = {                              # :474-481
        "model_used","duration_ms","token_usage_input",
        "token_usage_output","cost_estimate_usd","output_files"}     # captured from result
    return result
```

Key facts for parity:
- **Timeout** for every factory agent step: `start_to_close_timeout = 1 hour` (`:470`).
- **Retry**: `RETRY_POLICIES["agent_failure"]` = 3 attempts, exp backoff 5→60s (see §5).
- **`activity_id = f"agent-{step_name}"`** (`:472`) — deterministic, one per step name. ⚠️ Two dispatches with the same `step_name` in one run would collide; the factory never re-uses a step name within one phase pass, but rework loops re-enter with the same ids (acceptable — a fresh attempt of the same logical step).
- **Rework feedback injection** (`:436-440`): only steps that map to a gate via `_rework_gate_key_for_step` get the prior rejection envelope forwarded as `context["rework_feedback"]`. Generate-phase steps return `None` from that helper (Generate reruns *children*, not direct dispatches), so synthesis/adversarial/security-scan-review/iac-scaffolding/gate-review-package never carry rework feedback through this path.
- **Governance patterns** (`:445-446`): forwarded as `context["governance_patterns"]` only when non-empty.
- ⚠️ **NEW at HEAD — DevSecOps baseline injection (`:451-452`):** when `self._devsecops_params` is non-empty (resolved once in Generate, §2.6), forwards a **copy** as `context["devsecops_baseline"]` so the generating agents (`code-synthesis`, `tdd-generation`, `iac-scaffolding-generator`) render the baseline templates with profile-correct `sast_tool`/`target_cloud`/`container_base`/`license`/`primary_ecosystem`/`iac`/`cicd`/`sbom_required`. It is empty (key absent) during Extract/Design — only the Generate phase populates it. NOTE: the Ralph child's `tdd-generation` dispatch does NOT go through this method (§3.4), so the child's TDD agent does NOT receive `devsecops_baseline` — only the factory's Generate-phase dispatches do.

`_rework_gate_key_for_step` (`:297-335`) routing table:
- → `"G-04a"` for: `extraction`, `cross-validation`, `requirement-aggregation`, `business-rule-reconciliation`, `extract`, `synthesis` (`:313-320`). ⚠️ (`synthesis` is in the *extract* set here even though synthesis runs in Generate — a quirk; preserve verbatim. Still present at `:319`.)
- → `"G-04b"` for: `module-design`, `api-specification`, `data-modeling`, `batch-design`, `traceability-audit`, `design`, `adversarial-review`, `gate-review-package` (`:321-330`).
- → `None` otherwise (Generate phase — including the new `security-posture-review`, `security-scan-review`, `iac-scaffolding` steps).

### 2.4 Extract phase (`_execute_extract`, `modernization.py:739-988`)

Produces: extraction artifacts (`business-rules.yaml`, `test-scenarios.yaml`), `cross-validation-report.json`, optionally reconciliation artifacts. Gate: **G-04a**. Feeds: Design phase consumes `_collect_extract_artifacts()`. (Structure unchanged from the prior spec — only line citations shift; no DevSecOps logic in Extract.)

```
branch = f"olympus/modernization/extract/{app_id}/{run_suffix}"      # :753
while True:                                                          # :755  ← REWORK LOOP
    skill_id = self._select_extraction_skill(input)                 # :757  (variant select, §2.4.1)

    # Ensure Discovery Pass-2 business-logic inventory is an explicit input (G6.3)
    business_logic_path = f"discovery/{app_id}/business-logic.json"  # :767
    extract_inputs = list(input.prior_artifacts)                    # :768
    if business_logic_path not in extract_inputs:
        extract_inputs.insert(0, business_logic_path)               # :769-770  ⚠ prepend, dedup-safe

    await self._set_step("extract", 0.0)                            # :771
    extraction_result = await self._dispatch_agent(app_id,
        step_name="extraction", skill_id=skill_id,
        input_artifacts=extract_inputs, source_repo, workspace_key) # :772-779
    self._extract_results["extraction"] = extraction_result.output_artifacts  # :780-782

    await self._set_step("cross-validation", STEP_WEIGHTS["extract"]) # :785-787
    cross_val_result = await self._dispatch_agent(app_id,
        step_name="cross-validation", skill_id="cross-validation",
        input_artifacts=extraction_result.output_artifacts, ...)    # :788-795
    self._extract_results["cross-validation"] = cross_val_result.output_artifacts  # :796-798

    # -- Business Rule Reconciliation (PATCH-GATED) --
    reconciliation_ran = False                                      # :814
    if workflow.patched("br-reconciliation-v1"):                    # :815  ⚠ patch gate
        req_agg_result = await self._dispatch_agent(app_id,
            step_name="requirement-aggregation",
            skill_id="requirement-aggregation",
            input_artifacts=extraction_result.output_artifacts, ...) # :820-827
        self._extract_results["requirement-aggregation"] = req_agg_result.output_artifacts  # :828-830
        reconcile_inputs = list(extraction_result.output_artifacts) \
            + list(req_agg_result.output_artifacts)                 # :837-839
        reconcile_result = await self._dispatch_agent(app_id,
            step_name="business-rule-reconciliation",
            skill_id="business-rule-reconciliation",
            input_artifacts=reconcile_inputs, ...)                  # :840-847
        self._extract_results["business-rule-reconciliation"] = reconcile_result.output_artifacts  # :848-850
        reconciliation_ran = True                                   # :851

    await self._set_step("extract-commit", weights...)              # :854-857
    artifact_paths = await self._commit_extract_artifacts(repo, branch, app_id)  # :858-860  (§2.4.2)
    pr_result = await self._create_extract_pr(repo, branch, app_id, skill_id, reconciliation_ran)  # :863-865
    gate_record = await execute_activity(create_gate_record,
        CreateGateRecordInput(gate_type="G-04a", app_id, portfolio_id,
            workflow_id, evidence_package_url=pr_result.pr_url),
        start_to_close_timeout=30s, retry=transient)                # :868-879
    await self._submit_gate_evidence(gate_id, GateType.G_04A, app_id,
        artifact_paths, pr_url, "Modernization", step="extract")    # :882-890
    if workflow.patched("modernization-gate-pre-review-v1"):        # :899  ⚠ patch gate
        await self._run_gate_pre_review(gate_id,"G-04a",artifact_paths,
            artifact_repo=repo, artifact_ref=branch)                # :900-906
    else:
        await self._mark_ready_for_review(gate_id)                  # :908
    await self._update_app_status(app_id,"gate_review","extract-gate-review","Modernization")  # :910-915
    await self._set_step("extract-gate", weights...)                # :918-923
    decision = await self._wait_for_gate_decision(GateType.G_04A)   # :924  (§2.7, BLOCKS on signal)

    if decision == "cancelled": return "cancelled"                  # :926-927  ← EARLY RETURN
    if decision == "approved":                                      # :929
        if self._risk_tier == 1:                                    # :935  ⚠ Tier-1 SME gate
            await workflow.wait_condition(lambda:
                self._g04a_stakeholder_sme_approved or self.cancelled)  # :936-941  BLOCKS
            if self.cancelled:
                self._status = CANCELLED; return "cancelled"        # :942-944
        cross_val_refs = self._extract_results.get("cross-validation",[])
        extraction_ref = cross_val_refs[0] if cross_val_refs else ""  # :950-953
        report_file = self._find_output_file_content("cross-validation")  # :954-956
        await self._persist_side_effects(app_id,"extract",
            extraction_report_json=report_file, extraction_ref=extraction_ref)  # :957-962
        await self._reconcile_and_merge_with_retry_loop(repo,
            pr_number=pr_result.pr_number, gate_id=gate_record.gate_id,
            merge_method="merge")                                   # :965-970  (§2.7)
        return "approved"                                           # :971  ← SUCCESS RETURN
    # decision == "rejected" → REWORK
    self._g04a_stakeholder_sme_approved = False                     # :975  reset Tier-1 flag
    self._bump_rework("G-04a")                                      # :977
    if self._rework_count("G-04a") > MAX_REWORK_ITERATIONS:         # :978  ⚠ strict >
        self._status = FAILED; self._current_step="extract-max-rework-exceeded"
        await self._update_app_status(app_id,"modernization_failed",...)  # :979-987
        return "failed"                                             # :988  ← FAIL RETURN
    # else: loop back to top of while True → re-extract
```

#### 2.4.1 Extraction variant selection (`_select_extraction_skill`, `:1056-1071`)
```
for artifact in input.prior_artifacts:
    artifact_lower = artifact.lower()
    for lang, skill_id in LANGUAGE_SKILL_MAP.items():   # dict iteration order = insertion
        if lang == "default": continue
        if lang in artifact_lower: return skill_id      # FIRST substring match wins
return LANGUAGE_SKILL_MAP["default"]                    # "extraction"
```
`LANGUAGE_SKILL_MAP` (`:124-130`): `{"cobol":"extraction-cobol","java":"extraction-java","coldfusion":"extraction-coldfusion","python":"extraction-python","default":"extraction"}`.
⚠️ **GOTCHA — substring-in-path matching, first-match-wins, dict-order-dependent.** Matches a *substring* of any prior-artifact path (e.g. a path containing `"cobol"` → `extraction-cobol`). Iteration is over the dict in insertion order (cobol, java, coldfusion, python). A path containing both `java` and `cobol` resolves to whichever appears first in dict iteration for the *outer* artifact loop — actually the OUTER loop is artifacts, INNER is langs, so the first *artifact* that matches any lang, scanned langs in dict order, wins. Preserve exact loop nesting.

#### 2.4.2 Extract commit (`_commit_extract_artifacts`, `:2399-~2600`)
- `workflow.patched("modernization-batch-writes-v1")` — batch vs per-file commit path (behaviorally equivalent output set; batch = one commit per step, non-batch = one commit per file).
- For each step in `["extraction","cross-validation","requirement-aggregation","business-rule-reconciliation"]` with non-empty artifacts: writes a **JSON metadata envelope** at `modernization/{app_id}/extract/{filename}` AND each `output_file` under `modernization/{app_id}/extract/files/{step_name}/{path}`.
- Plus `test-scenarios.yaml` envelope at `modernization/{app_id}/extract/test-scenarios.yaml` when extraction produced artifacts.
- Returns `dedup_paths(committed_paths)`.

⚠️ **GOTCHA — two layers of "module-map".** The top-level `{filename}` path holds a **JSON metadata envelope** (step name, artifact list, model, duration, timestamp) — NOT the parseable YAML. The real skill-emitted file lives under `.../files/{step_name}/{actual_filename}`. This bites the BC parser (§2.5.2): it must read the `files/module-design/module-map.yaml`, not the top-level envelope.

### 2.5 Design phase (`_execute_design`, `modernization.py:1185-1344`)

Produces: `module-map.yaml`, `openapi.yaml`, `data-model.yaml`, optionally `batch-design.yaml`, `traceability-audit` output, and `design-review.json` (F3 threshold evidence). Gate: **G-04b**. Feeds: Generate consumes `_collect_design_artifacts()` AND `_parse_bounded_contexts()` reads the committed module map.

⚠️ **CHANGED at HEAD — Design no longer dispatches the agent chain inline.** The prior spec showed `_execute_design` directly calling `_dispatch_agent` for module-design → api-specification → data-modeling → batch-design → traceability-audit. At HEAD that chain has MOVED into a new method `_dispatch_design_internal` (`:1077-1152`), and `_execute_design` now calls `_maybe_dispatch_bundle(...)` (Phase 6 W1 delegated-bundle) with `_dispatch_design_internal` as the `fallback_fn`. Behavioral parity for the **non-delegated** path is unchanged (the internal chain runs verbatim and returns the traceability-audit `AgentTaskResult`); the **delegated** path returns a dict of `artifact_kind → ref` that is folded into `_design_results` by `_fold_bundle_design_outputs` (`:1154-1184`), with `audit_result` set to `None` so `design-review.json` falls back to the provisional default (§2.5.1).

```
branch = f"olympus/modernization/design/{app_id}/{run_suffix}"       # :1195
design_base = self._sum_weights("extract","cross-validation","extract-commit","extract-gate")  # :1196-1201
while True:                                                          # :1203  ← REWORK LOOP
    await self._set_step("design", design_base)                     # :1204
    # ⚠ CHANGED: bundle-or-internal. _maybe_dispatch_bundle returns the
    # traceability-audit AgentTaskResult (internal path) OR a dict of
    # accepted bundle outputs (delegated path).
    audit_result = await self._maybe_dispatch_bundle(               # :1215-1225
        step_or_gate_id="modernization-design", scope_kind="line_step",
        app_id=app_id, wave_id=None, is_delegatable=True,
        expires_hours=7*24,
        fallback_fn=lambda: self._dispatch_design_internal(input, app_id, source_repo, workspace_key))
    if isinstance(audit_result, dict):                              # :1234  ← delegated path
        self._fold_bundle_design_outputs(audit_result)             # :1235
        audit_result = None                                        # :1236  → provisional design-review.json

    await self._set_step("design-commit", design_base + STEP_WEIGHTS["design"])  # :1240-1242
    artifact_paths = await self._commit_design_artifacts(repo, branch, app_id,
        audit_result=audit_result)                                  # :1243-1245  (emits design-review.json, §2.5.1)
    pr_result = await self._create_design_pr(repo, branch, app_id)  # :1248
    gate_record = create_gate_record(gate_type="G-04b", ...)        # :1250-1261
    await self._submit_gate_evidence(..., GateType.G_04B, ..., step="design")  # :1263-1271
    if workflow.patched("modernization-gate-pre-review-v1"):        # :1273
        await self._run_gate_pre_review(gate_id,"G-04b",...)        # :1274-1280
    else: await self._mark_ready_for_review(gate_id)                # :1282
    await self._update_app_status(app_id,"gate_review","design-gate-review",...)  # :1284-1289
    await self._set_step("design-gate", weights...)                 # :1291-1296
    decision = await self._wait_for_gate_decision(GateType.G_04B)   # :1297  BLOCKS

    if decision == "cancelled": return "cancelled"                  # :1299-1300
    if decision == "approved":                                      # :1302
        module_map_content = self._find_output_file_content("module-design")  # :1308
        design_review_content = self._find_output_file_content("design-review")  # :1311
        design_refs = self._design_results.get("design-review",[])
        design_ref = design_refs[0] if design_refs else ""          # :1314-1315
        await self._persist_side_effects(app_id,"design",
            module_map_json=module_map_content,
            design_review_json=design_review_content, design_ref=design_ref)  # :1316-1322
        await self._reconcile_and_merge_with_retry_loop(repo, pr_result.pr_number, gate_id)  # :1325-1329
        return "approved"                                           # :1330  ← SUCCESS RETURN
    # rejected → REWORK
    self._bump_rework("G-04b")                                      # :1333
    if self._rework_count("G-04b") > MAX_REWORK_ITERATIONS:         # :1334
        self._status = FAILED; ... return "failed"                  # :1335-1344
    # else loop
```
⚠️ Design has **no Tier-1 stakeholder wait** (unlike G-04a/G-04c). PM gate decision alone advances.

**The internal Design chain (`_dispatch_design_internal`, `:1077-1152`)** — verbatim the pre-Phase-6 chain, run when the step isn't delegated OR as the bundle's expiry fallback:
```
module_result = _dispatch_agent("module-design","module-design", self._collect_extract_artifacts(), ...)  # :1096-1103
self._design_results["module-design"] = module_result.output_artifacts                                    # :1104
api_result = _dispatch_agent("api-specification","api-specification", module_result.output_artifacts, ...) # :1107-1114
self._design_results["api-specification"] = api_result.output_artifacts                                    # :1115
data_result = _dispatch_agent("data-modeling","data-modeling", module_result.output_artifacts, ...)        # :1118-1125
self._design_results["data-modeling"] = data_result.output_artifacts                                       # :1126
if self._is_batch_archetype(input):                                                                        # :1129  (substring "batch" in any prior artifact)
    batch_result = _dispatch_agent("batch-design","batch-design", module_result.output_artifacts, ...)     # :1130-1137
    self._design_results["batch-design"] = batch_result.output_artifacts                                   # :1138
# traceability-audit ALWAYS runs (always-on as of W19 PR C)
audit_result = _dispatch_agent("traceability-audit","traceability-audit", self._collect_design_artifacts(), ...)  # :1143-1150
self._design_results["traceability-audit"] = audit_result.output_artifacts                                 # :1151
return audit_result                                                                                        # :1152
```
⚠️ **GOTCHA — `_fold_bundle_design_outputs` key map (`:1167-1176`).** Maps bundle `artifact_kind` → design sub-step: `module-map`/`module_map`→`module-design`, `openapi`/`api-specification`→`api-specification`, `data-model`/`data_model`→`data-modeling`, `batch-design`→`batch-design`, `traceability-audit`→`traceability-audit`. Unknown kinds are stored under their own key (nothing silently dropped). Empty-string refs are skipped. The folded refs land in `_design_results` exactly where the internal agents would have put them, so the gate evidence + `_parse_bounded_contexts` see the same shape.

#### 2.5.1 `design-review.json` emission (`_commit_design_artifacts` :1392-~1600, `_build_design_review_content` :1601-~1700)
- Commits each `DESIGN_SKILLS` step's JSON envelope + output files under `modernization/{app_id}/design/...` and `.../files/{step}/...`.
- Emits `modernization/{app_id}/design/design-review.json` whose body comes from:
  - `audit_result.output_files` — the file ending `design-review.json`, else the first file, used **verbatim** (the skill owns the metrics).
  - If `audit_result` is `None` (delegated path, §2.5) OR produced no files → **provisional placeholder** with pass-threshold defaults (`forward_coverage=0.99`, `bounded_contexts_defined=True`, `openapi_valid=True`, `ddd_elements_present=True`, `"provisional":true`).
- After emission, registers `self._design_results["design-review"]=[review_path]` and a synthetic `self._agent_metadata["design-review"]` carrying the review as an `OutputFile` so it appears in the G-04b evidence bundle.

⚠️ **GOTCHA — `design-review.json` is gate-threshold-critical.** F3 G-04b thresholds (`forward_coverage`, `bounded_contexts_defined`, `openapi_valid`, `ddd_elements_present`, `critical_508_violations`, `journey_preservation_pct`) are evaluated against this artifact by `check_gate_criteria` (gate_operations.py). If it's missing, thresholds "skip" rather than fail. A rebuild MUST emit it every Design cycle (including the delegated-bundle path, where the provisional default keeps it gate-evaluable).

#### 2.5.2 Bounded-context parsing (`_parse_bounded_contexts` :2102-2173 + `parse_bc_names_from_yaml` :2777-~2820)
```
async def _parse_bounded_contexts(repo, app_id) -> list[str]:        # :2102
    module_map_artifacts = self._design_results.get("module-design",[])  # :2120
    if not module_map_artifacts: return ["default"]                 # :2121-2122  ← FALLBACK
    module_map_path = f"modernization/{app_id}/design/files/module-design/module-map.yaml"  # :2127-2129 ⚠
    try:
        read_result = await execute_activity(read_artifact,
            ReadArtifactInput(repo=repo, branch="main", path=module_map_path, ...),
            start_to_close_timeout=60s, retry=transient,
            activity_id=f"read-module-map-{app_id}")                # :2132-2147
        content = read_result.content                              # :2148
    except Exception:
        log.warning("Failed to read module-map.yaml; falling back to default BC")
        return ["default"]                                          # :2149-2154  ← FALLBACK
    bc_names = parse_bc_names_from_yaml(content)                    # :2156
    if not bc_names: return ["default"]                            # :2157-2158  ← FALLBACK
    if len(bc_names) > MAX_BC_CHILDREN_PER_APP:                    # :2160
        log.warning("module-map declares N bounded contexts; truncating fan-out to cap of 12")  # :2161-2172
    return bc_names                                                 # :2173  (NOT truncated here)
```
`parse_bc_names_from_yaml(content)` (`:2777-~2820`):
- Empty/whitespace content → `[]`.
- `yaml.safe_load` (NEVER `yaml.load`); `YAMLError` → `[]`.
- Non-dict root → `[]`.
- `contexts = data.get("bounded_contexts") or data.get("contexts") or data.get("modules")` — ⚠️ first non-empty of THREE keys in that order.
- Non-list / empty → `[]`.
- For each `ctx` that is a dict: `name = ctx.get("name") or ctx.get("id")`; append `name.strip()` if a non-empty string.
- Returns names in **declaration order**; non-dict entries and entries with no valid name are skipped.

⚠️ **GOTCHA — read is from `main` branch.** The parser reads from `branch="main"` (`:2136`), relying on the fact that **G-04b already merged the Design PR to main** (via `_reconcile_and_merge_with_retry_loop` at `:1325`). If a rebuild reads from the design branch instead, it reads pre-merge state. Path is the `files/module-design/module-map.yaml` (the real YAML), not the envelope.

⚠️ **GOTCHA — truncation happens at the CALL SITE, not in the parser.** `parse_bc_names_from_yaml` returns ALL names; `_parse_bounded_contexts` only *warns* on overflow; the cap is applied by slicing `bc_names[:MAX_BC_CHILDREN_PER_APP]` in `_execute_generate` (`:1786`).

### 2.6 Generate phase (`_execute_generate`, `modernization.py:1710-2100`) — DevSecOps resolve + fan-out + synthesis + security/IaC + baseline-validation + G-04c

⚠️ **HEAVILY CHANGED at HEAD (+480 lines across modernization.py).** The old §2.6 (`:1587-1862`) is obsolete. The Generate phase now has a **pre-loop DevSecOps profile resolution** and, inside the loop, **three new agent dispatches** (`security-posture-review`, `security-scan-review`, `iac-scaffolding`) PLUS a **deterministic `validate_devsecops_baseline` activity INTERPOSED between the commit and the PR creation** that can trigger a *second, machine-driven* rework of the Generate phase. Read this section as fully authoritative.

```
branch = f"olympus/modernization/generate/{app_id}/{run_suffix}"     # :1720
generate_base = self._sum_weights("extract","cross-validation","extract-commit",
    "extract-gate","design","design-commit","design-gate")          # :1721-1729

# ── PRE-LOOP: resolve DevSecOps baseline params ONCE per Generate step ──
# (P6-S11.6) Resolved before the while-loop so reworks reuse the same
# params (no re-resolve on loop-back).
if not self._devsecops_params:                                      # :1736  ⚠ NEW, guard
    ds_params = await workflow.execute_activity(
        resolve_devsecops_profile,
        ResolveDevSecOpsProfileInput(profile_id=input.portfolio_id or ""),  # :1739-1741
        start_to_close_timeout=timedelta(seconds=30),               # :1742  30s
        retry_policy=RETRY_POLICIES["transient"],                   # :1743
        activity_id=f"resolve-devsecops-{app_id}")                  # :1744
    self._devsecops_params = {                                      # :1746-1755  ⚠ 8-key dict
        "sast_tool": ds_params.sast_tool,           "sbom_required": ds_params.sbom_required,
        "container_base": ds_params.container_base, "license": ds_params.license,
        "target_cloud": ds_params.target_cloud,     "primary_ecosystem": ds_params.primary_ecosystem,
        "iac": ds_params.iac,                       "cicd": ds_params.cicd}

while True:                                                          # :1757  ← REWORK LOOP
    await self._set_step("generate", generate_base)                 # :1758
    bc_names = await self._parse_bounded_contexts(repo=repo, app_id=app_id)  # :1765-1767  (§2.5.2)

    _FRONTEND_BC_NAMES = {"frontend","ui","web-app","spa"}          # :1781
    _DEFAULT_BACKEND_FRAMEWORK = "express"                          # :1782
    _DEFAULT_FRONTEND = "react"                                     # :1783
    bc_tasks = []                                                   # :1785
    for bc_name in bc_names[:MAX_BC_CHILDREN_PER_APP]:              # :1786  ← CAP=12 SLICE
        bc_name_lower = bc_name.lower()
        if bc_name_lower in _FRONTEND_BC_NAMES:                     # :1788
            bc_framework = None
            bc_frontend = input.target_frontend or _DEFAULT_FRONTEND  # :1790
        else:
            bc_framework = input.target_framework or _DEFAULT_BACKEND_FRAMEWORK  # :1792
            bc_frontend = None
        bc_input = GenerateBCInput(app_id=app_id, bc_name=bc_name,
            wave_id=input.wave_id, portfolio_id=input.portfolio_id,
            artifact_repo=repo, source_repo=source_repo,
            design_artifacts=self._collect_design_artifacts(),
            target_framework=bc_framework, target_frontend=bc_frontend,
            primary_language=input.primary_language)                # :1795-1806
        task = workflow.execute_child_workflow("GenerateBCWorkflow", bc_input,
            id=f"generate-bc-{app_id}-{bc_name}-{run_suffix}",
            task_queue=workflow.info().task_queue)                  # :1807-1812
        bc_tasks.append(task)                                       # :1813

    raw_results = await asyncio.gather(*bc_tasks)                   # :1816  ← AWAIT ALL CHILDREN
    bc_results = [GenerateBCResult(**r) if isinstance(r,dict) else r
                  for r in raw_results]                             # :1818-1821  ⚠ dict re-hydrate
    self._generate_results = list(bc_results)                      # :1822

    await self._set_step("generate-synthesis", ...)                # :1825-1828
    synthesis_result = await self._dispatch_agent(app_id,"synthesis",
        skill_id="code-synthesis",
        input_artifacts=[a for r in bc_results for a in r.output_artifacts],
        source_repo, workspace_key)                                # :1829-1838

    await self._set_step("generate-review", ...)                   # :1841-1846
    # (a) adversarial-review (unchanged)
    await self._dispatch_agent(app_id,"adversarial-review","adversarial-review",
        synthesis_result.output_artifacts, ...)                    # :1847-1854
    # (b) security-posture-review (unchanged — reasons about security DESIGN intent)
    await self._dispatch_agent(app_id,"security-posture-review",
        "security-posture-review", synthesis_result.output_artifacts, ...)  # :1861-1868

    # (c) ⚠ NEW P6-S8.3 — security-scan-review, BEST-EFFORT (try/except).
    #     Triages the SAST/SCA scanner output the generated DevSecOps
    #     baseline ships (CodeQL + Trivy fs) → security-scan-report.json
    #     (G-04c security evidence; RA-5 / SI-2 control evidence).
    #     ⚠ A triage MISS must NOT block the Generate gate.
    try:
        await self._dispatch_agent(app_id,"security-scan-review",
            "security-scan-review", synthesis_result.output_artifacts, ...)  # :1877-1885
    except Exception as exc:                                        # :1886  ← SWALLOWED
        workflow.logger.warning("security-scan-review dispatch failed (non-fatal): %s", exc)  # :1887-1890

    # (d) ⚠ NEW P6-S11.3 — iac-scaffolding-generator (cloud-resource IaC graph:
    #     Lambda / API-GW / Aurora / EventBridge / KMS + remote-state backend,
    #     plus its iac-manifest evidence). NOT best-effort — a raise here
    #     fails the line. Ownership split: it does NOT emit
    #     infra/terraform/main.tf (that's code-synthesis's baseline), so the
    #     two never collide on that path.
    await self._dispatch_agent(app_id,"iac-scaffolding",
        "iac-scaffolding-generator", synthesis_result.output_artifacts, ...)  # :1903-1910

    # (e) gate-review-package (unchanged)
    await self._dispatch_agent(app_id,"gate-review-package","gate-review-package",
        synthesis_result.output_artifacts, ...)                    # :1913-1920

    await self._set_step("generate-commit", ...)                   # :1923-1929
    artifact_paths = await self._commit_generate_artifacts(repo, branch, app_id, bc_results)  # :1930-1932  (§2.6.1)
    # ⚠ side effect: _commit_generate_artifacts repopulates
    #   self._committed_baseline_files (root-bound (path,content) pairs).

    # ── ⚠ NEW P6-S11.5 — DETERMINISTIC BASELINE VALIDATION, INTERPOSED
    #    BETWEEN THE COMMIT (above) AND PR CREATION (below). This is the
    #    standing guard that gates G-04c on a COMPLETE baseline.
    baseline_validation = await workflow.execute_activity(          # :1942-1954
        validate_devsecops_baseline,
        ValidateDevSecOpsBaselineInput(app_id=app_id,
            committed_files=list(self._committed_baseline_files),   # :1946  ← the just-committed root files
            sast_tool=str(self._devsecops_params.get("sast_tool","codeql"))),  # :1947-1949
        start_to_close_timeout=timedelta(seconds=60),               # :1951  60s
        retry_policy=RETRY_POLICIES["transient"],                   # :1952
        activity_id=f"validate-devsecops-{app_id}")                 # :1953
    if not baseline_validation.passed:                              # :1955  ⚠ MACHINE-DRIVEN REWORK BRANCH
        workflow.logger.warning("G-04c DevSecOps baseline validation failed; reworking Generate", ...)  # :1956-1964
        self._g04c_stakeholder_ea_approved = False                 # :1965  reset BOTH Tier-1 flags
        self._g04c_stakeholder_security_approved = False           # :1966
        self._bump_rework("G-04c")                                 # :1967  ← SAME G-04c counter as human reject
        if self._rework_count("G-04c") > MAX_REWORK_ITERATIONS:    # :1968  ⚠ strict >
            self._status = FAILED                                  # :1969
            self._current_step = "generate-baseline-incomplete"    # :1970  ⚠ distinct status string
            self._updated_at = _now_iso()                          # :1971
            await self._update_app_status(app_id,"modernization_failed",
                "generate-baseline-incomplete","Modernization")    # :1972-1977
            return "failed"                                        # :1978  ← FAIL RETURN
        continue                                                   # :1979  ⚠ LOOP-BACK → RE-FAN-OUT (no PR/gate)

    # ── PR + gate G-04c (only reached when baseline passed) ──
    pr_result = await self._create_generate_pr(repo, branch, app_id, bc_results)  # :1982-1984
    gate_record = create_gate_record(gate_type="G-04c", ...)       # :1986-1997
    await self._submit_gate_evidence(..., GateType.G_04C, ..., step="generate")  # :1999-2007
    if workflow.patched("modernization-gate-pre-review-v1"):       # :2009
        await self._run_gate_pre_review(gate_id,"G-04c",...)       # :2010-2016
    else: await self._mark_ready_for_review(gate_id)               # :2018
    await self._update_app_status(app_id,"gate_review","generate-gate-review",...)  # :2020-2025
    await self._set_step("generate-gate", ...)                     # :2027-2034
    decision = await self._wait_for_gate_decision(GateType.G_04C)  # :2035  BLOCKS

    if decision == "cancelled": return "cancelled"                 # :2037-2038
    if decision == "approved":                                     # :2040
        if self._risk_tier == 1:                                   # :2048  ⚠ Tier-1 TRIPLE signal
            await workflow.wait_condition(lambda:
                (self._g04c_stakeholder_ea_approved
                 and self._g04c_stakeholder_security_approved)
                or self.cancelled)                                 # :2049-2057  BLOCKS until BOTH
            if self.cancelled: self._status=CANCELLED; return "cancelled"  # :2058-2060
        package_content = self._find_output_file_content("gate-review-package")  # :2066-2068
        await self._persist_side_effects(app_id,"generate",
            gate_review_package_json=package_content)              # :2069-2073
        await self._reconcile_and_merge_with_retry_loop(repo, pr_result.pr_number, gate_id)  # :2076-2080
        return "approved"                                          # :2081  ← SUCCESS RETURN
    # rejected → REWORK (human G-04c rejection — the SECOND rework trigger)
    self._g04c_stakeholder_ea_approved = False                     # :2086  reset
    self._g04c_stakeholder_security_approved = False               # :2087  reset
    self._bump_rework("G-04c")                                     # :2089
    if self._rework_count("G-04c") > MAX_REWORK_ITERATIONS:        # :2090  ⚠ strict >
        self._status = FAILED                                      # :2091
        self._current_step = "generate-max-rework-exceeded"        # :2092  ⚠ different status string than baseline branch
        await self._update_app_status(app_id,"modernization_failed",
            "generate-max-rework-exceeded","Modernization")        # :2094-2099
        return "failed"                                            # :2100  ← FAIL RETURN
    # else loop → re-parse BCs and RE-FAN-OUT all children
```

⚠️ **GOTCHA — DevSecOps params resolved ONCE, BEFORE the loop, and reused across reworks (`:1736-1755`).** The `if not self._devsecops_params:` guard means the `resolve_devsecops_profile` activity runs exactly once per `_execute_generate` invocation — never re-resolved on a loop-back (machine or human rework). `profile_id` is `input.portfolio_id or ""`. The result is an 8-key dict (`sast_tool`/`sbom_required`/`container_base`/`license`/`target_cloud`/`primary_ecosystem`/`iac`/`cicd`) stored on `self._devsecops_params` and threaded into every subsequent factory dispatch via `context["devsecops_baseline"]` (§2.3, `:451-452`). It is also passed to the validator (`sast_tool` only, `:1947`). The defaults if the profile resolver returns its dataclass defaults: `sast_tool="codeql"`, `sbom_required=True`, `container_base="distroless"`, `license=""`, `target_cloud="aws"`, `primary_ecosystem="python"`, `iac="terraform"`, `cicd="github-actions"` (`types.py:753-761`). ⚠️ Because `self._devsecops_params` is an instance attr seeded empty in `__init__` (`:285`) and only assigned here, a rebuild MUST keep the guard — re-resolving every iteration would be a determinism-safe but wasteful divergence, AND would defeat the "reused across reworks" contract the code comment states.

⚠️ **GOTCHA — `security-scan-review` is the ONLY best-effort dispatch in the whole factory (`:1877-1890`).** It is wrapped in `try/except Exception` and a failure is logged (`security-scan-review dispatch failed (non-fatal)`) and **swallowed** — it does NOT raise, does NOT fail the line, does NOT block the gate. Its triage report (`security-scan-report.json`) is advisory G-04c security evidence. ⚠️ Contrast the adjacent `iac-scaffolding` dispatch (`:1903-1910`) which is NOT wrapped — a raise there propagates and fails the whole line. A rebuild must wrap ONLY security-scan-review, not iac-scaffolding/synthesis/adversarial/security-posture/gate-review-package.

⚠️ **GOTCHA — TWO distinct G-04c rework triggers sharing ONE counter.** There are now **two** `_bump_rework("G-04c")` + `> MAX_REWORK_ITERATIONS` sites: (1) the **machine-driven** baseline-validation failure at `:1967-1968` (status `generate-baseline-incomplete`), and (2) the **human** gate-rejection at `:2089-2090` (status `generate-max-rework-exceeded`). Both increment the SAME `G-04c` rework counter. So a Generate phase that suffers, e.g., 2 baseline-validation failures has only 2 cycles of human-rejection budget left before `> 3` fails. Both reset BOTH Tier-1 stakeholder flags before checking. ⚠️ The status string differs (`generate-baseline-incomplete` vs `generate-max-rework-exceeded`) — preserve both verbatim so dashboards/projection can distinguish a machine-baseline failure from a human-rejection failure.

⚠️ **GOTCHA — the baseline-validation rework is INTERPOSED BETWEEN COMMIT AND PR, and `continue` (`:1979`) loops back WITHOUT creating a PR or a gate record.** This is structurally different from the human-rejection rework (which loops back only AFTER a full PR → gate-record → wait cycle). On baseline failure: commit happened, validation failed, both flags reset, counter bumped — if under cap, `continue` jumps straight to the top of the `while` (`:1757`), re-parses BCs, and **re-fans-out all children from scratch** — NO PR is opened, NO gate record is created, NO human sees this cycle. It is a silent machine-driven regeneration. A rebuild that opened a PR before validating, or that fell through to PR creation on failure, would NOT be at parity. The order is strict: synthesis → reviews → IaC → gate-review-package → COMMIT → **VALIDATE** → (pass?) PR → gate.

⚠️ **GOTCHA — `validate_devsecops_baseline` reads ONLY `self._committed_baseline_files`, no Git round-trip (`:1946`).** The validator receives the root-bound `(path, content)` pairs that `_commit_generate_artifacts` just stashed on `self._committed_baseline_files` (`:2339`). `passed = not missing and not errors` (`devsecops_validation.py:235`): `missing` = required repo-root files absent from the committed set (`REQUIRED_BASELINE_FILES`); `errors` = structural failures (e.g. `.github/workflows/ci.yml` not valid YAML, or missing any of the **7 required CI jobs** `lint`/`test`/`build`/`sast`/`sca`/`secrets-scan`/`image-scan`, or `ci.yml` not naming the profile `sast_tool`, or an un-rendered `{{...}}` placeholder, or a bad `iac-manifest.json`). Both empty → `passed=True`. The agent AUTHORS the baseline; this activity only CONFIRMS it. ⚠️ Because the input is the in-memory committed set (not a re-read of Git), the validator's view is exactly what `_commit_generate_artifacts` wrote this iteration — a rebuild MUST feed it the just-committed root files, not re-read main.

⚠️ **GOTCHA — `asyncio.gather` semantics on child failure.** `await asyncio.gather(*bc_tasks)` (`:1816`) has **no `return_exceptions=True`**. If any child workflow throws (i.e. the child's `run` raises rather than returning a `GenerateBCResult`), `gather` re-raises that exception, which unwinds `_execute_generate` → `run`'s `except Exception` (`:657`) → marks the line `modernization_failed` and re-raises. **BUT** a child that *escalates and is ABANDONED returns a `GenerateBCResult(status="abandoned")` — it does NOT raise** (see §3.6). So abandon is a value, not an exception; the parent collects it and proceeds to synthesis. The parent does **NOT** inspect `r.status` to fail the line — abandon is surfaced only via the post-G-04c side-effect projection (`gate_phase="generate"`) which sets `modernization_current_status=modernization_failed` based on the gate-review package. ⚠️ This is subtle: the parent workflow does not branch on abandon directly; the abandon→failed decision is the human's at G-04c plus the projection.

⚠️ **GOTCHA — child results may arrive as dicts.** Temporal deserializes child-workflow return values as plain dicts in some paths; `:1818-1821` re-hydrates `GenerateBCResult(**r)` when `isinstance(r,dict)`. A rebuild's child-result handling must tolerate both shapes. The same dict-tolerance appears for `output_files` in `_commit_generate_artifacts` via `_output_file_fields` (`:2175-2181`).

⚠️ **GOTCHA — rework re-fans-out from scratch (both triggers).** On EITHER a baseline-validation failure (`continue` at `:1979`) OR a G-04c human rejection (loop fall-through past `:2100`), the loop returns to `:1757`, re-parses BCs from main (the module map hasn't changed), and **re-spawns all child `GenerateBCWorkflow`s with the same ids** (`generate-bc-{app_id}-{bc_name}-{run_suffix}`). Same `run_suffix`, so child ids collide across rework cycles (Temporal completed-child-id reuse — intended). ⚠️ Rework feedback for G-04c is NOT forwarded into the children — `_rework_gate_key_for_step` returns `None` for Generate steps, and the children receive only `design_artifacts`, never the gate rejection envelope NOR the baseline-validation `missing`/`errors`. So a re-fan-out re-runs identical generation unless the human changed upstream artifacts. The ONLY thing that differs on a baseline-driven re-fan-out is that `self._devsecops_params` is already populated (so `context["devsecops_baseline"]` is threaded into the regenerating agents) — but it was already threaded on the first pass too, so the regeneration is genuinely identical. (The standing guard catches a persistently-incomplete baseline after 3 reworks and fails the line.)

#### 2.6.1 Generate commit (`_commit_generate_artifacts` :2183-2340) — W11 root-bound commit contract
⚠️ **CHANGED at HEAD — the commit now routes files to the TARGET REPO ROOT vs the namespaced metadata area, and stashes the root-bound set for the validator.**
- Always writes the workflow-metadata summary `modernization/{app_id}/generate/gate-review-package.json` (each BC's `bc_name`/`status`/`iteration_count`/`escalation_id`/counts) (`:2218-2278`).
- Builds an ordered `sources` list: each `bc_result` with `output_files` (label=bc_name) FIRST (`:2284-2288`), then the parent-level `synthesis` and `iac-scaffolding` agent outputs (label=step, bc_name=None) (`:2292-2296`). ⚠️ Order = **collision precedence (first-writer-wins)**: BC code → synthesis (top-level DevSecOps baseline) → IaC.
- For each `(label, bc_name, output_files)`: `dest = route_generate_file(app_id, bc_name, path)` (`devsecops_contract.py:168`). If `is_root_bound(path)` (`devsecops_contract.py:146`): apply first-writer-wins into `root_files` dict (`if dest in root_files: continue`, `:2307-2309`) — root-bound files are `.github/**`, `Dockerfile`, `deploy/helm/**`, `infra/terraform/**`, `SECURITY.md`, etc. (`ROOT_BOUND_PREFIXES`/`ROOT_BOUND_EXACT`). Else if the basename is `iac-manifest.json`, capture it separately as `iac_manifest` (evidence, not root-bound) (`:2310-2311`). Each file is committed via `write_artifacts_batch` per source (`:2314-2332`), tolerating dict-or-`OutputFile` via `_output_file_fields` (`:2175-2181`).
- ⚠️ **The key new side effect (`:2334-2339`):** `validator_files = list(root_files.items())` + the `iac_manifest` (if any), assigned to `self._committed_baseline_files`. THIS is what the `validate_devsecops_baseline` activity consumes (`:1946`).
- Returns `dedup_paths(committed_paths)`.

### 2.7 Gate decision wait + merge (shared `LineWorkflowBase`)

`_wait_for_gate_decision(gate_type)` (`base.py:1075-1129`) — used at G-04a/b/c:
```
self._status = WAITING_FOR_SIGNAL; self._pending_gate = gate_type    # :1085-1086
consumed = self._gate_decisions_consumed                            # :1089
await workflow.wait_condition(lambda:
    len(self._gate_decisions) > consumed or self.cancelled)         # :1090-1092  BLOCKS
if self.cancelled: self._status=CANCELLED; return "cancelled"       # :1094-1097
entry = self._gate_decisions[consumed]                              # :1099
if len(entry)==5: decision,actor,reason,reason_category,card_decisions = entry  # :1104-1105
else: decision,actor,reason = entry[:3]; reason_category=None; card_decisions=[]  # :1106-1109
self._gate_decisions_consumed = consumed+1                          # :1110
self._pending_gate=None; self._status=RUNNING                      # :1112-1113
if decision == GateStatus.APPROVED:
    self._rework_feedback.pop(gate_key, None); return "approved"    # :1117-1119
self._rework_feedback[gate_key] = {gate, rejected_by, reason,
    reason_category, card_decisions, rejected_at}                   # :1121-1128
return "rejected"                                                   # :1129
```
- Gate decisions arrive via signals into `self._gate_decisions` (handled by `LineWorkflowBase` gate signal handlers — `gate_approved`/`gate_rejected`; consumed by index so multiple gates in one workflow are FIFO-ordered). On approval, prior rework feedback for that gate is cleared; on rejection it is recorded for the next dispatch.

`_reconcile_and_merge_with_retry_loop` (`base.py:1131-~1260`) — used after each gate approval:
```
merge_failure_types = {"MergeConflict","MergeDivergenceUnresolved","MergeBranchProtectionRejected"}  # :1168-1172
while True:
    try:
        await execute_activity(reconcile_and_merge_pr,
            MergePRInput(repo, pr_number, merge_method, ...),
            start_to_close_timeout=60s, retry=RETRY_POLICIES["git_merge"])  # :1180-1190
        return                                                      # :1192  ← SUCCESS
    except (ActivityError, ApplicationError) as outer:
        inner = unwrap to ApplicationError via __cause__ chain       # :1200-1205
        if not ApplicationError: raise                              # :1206-1207
        if inner.type not in merge_failure_types: raise             # :1209-1212  ← non-merge error propagates
        self._merge_retry_signalled = False                         # :1233
        await execute_activity(set_gate_merge_blocked, [gate_id, detail], 30s, transient)
        await workflow.wait_condition(lambda:
            self._merge_retry_signalled or self.cancelled)          # BLOCKS on human retry
        if self.cancelled: return
        # loop → retry merge
```
`git_merge` retry policy: 3 attempts, exp 5→30s, `non_retryable_error_types=["MergeConflict","MergeDivergenceUnresolved","MergeBranchProtectionRejected"]` (`retry_policies.py:98-104`).

### 2.8 Tier-1 stakeholder signals (`stakeholder_approved`, `modernization.py:342-367`)
```
@workflow.signal stakeholder_approved(signal: StakeholderApprovedSignal):  # :342
    if signal.scope == "g-04c-ea":       self._g04c_stakeholder_ea_approved = True       # :356-357
    elif signal.scope == "g-04c-security": self._g04c_stakeholder_security_approved = True # :358-359
    elif signal.scope == "g-04a-sme":    self._g04a_stakeholder_sme_approved = True       # :360-361
    else: log.warning("unrecognized scope")   # :362-366  ⚠ unknown scope = ignore, not fail
    self._updated_at = _now_iso()                                                         # :367
```
- **G-04a Tier-1**: PM gate approval AND `scope="g-04a-sme"` (`:935-944`).
- **G-04c Tier-1**: PM gate approval AND BOTH `scope="g-04c-ea"` AND `scope="g-04c-security"` (`:2048-2060`).
- **G-04b**: PM only (no stakeholder wait).
- Tier-2/3: PM only on all three gates; the `if self._risk_tier == 1` guards skip the stakeholder waits.
- Flags are RESET on EVERY rework branch so early-arriving signals from a prior cycle don't satisfy the next cycle's wait: G-04a reject (`:975`), G-04c machine-baseline-failure (`:1965-1966`), G-04c human-reject (`:2086-2087`).

### 2.9 Governance pattern flywheel (F5)
- `wave_patterns_ready` signal (`modernization.py:369-387`) appends `{wave_id, patterns, received_at}` to `self._received_patterns`.
- `_seed_patterns_from_registry` (`:2657-…`) cold-start reads `governance/{portfolio_id}/latest-patterns.json` from `olympus/{portfolio_id}-governance` on main; best-effort (missing/malformed → empty bundle, no failure). Seeds `_received_patterns` with `source="cold-start-registry"`.
- Every `_dispatch_agent` call forwards `context["governance_patterns"]` when non-empty (`:445-446`).
- Query `get_received_patterns` (`:393-403`) returns a shallow copy for dashboards.

---

## 3. THE RALPH LOOP (`GenerateBCWorkflow`, `generate_bc.py`)

### 3.0 Class identity, state (`generate_bc.py:50-73`)
- `@workflow.defn class GenerateBCWorkflow(HILSignalsMixin)`.
- `__init__` (`:59-73`) sets: `_bc_name=""`, `_app_id=""`, `_status=WorkflowStatus.PENDING`, `_current_step=""`, `_iteration=0`, `_started_at=""`, `_updated_at=""`, and escalation state `_escalation_id=""`, `_escalation_resolved=False`, `_escalation_resolution=""`, `_escalation_resolution_type: ResolutionType|None = None`.
- `super().__init__()` (`:60`) gives `HILSignalsMixin`: the `cancelled` flag (`signals.py:37`) and the `cancel_workflow` signal that sets it (`signals.py:76-78`), plus `approve`/`approved` and plan/document feedback fields (unused by this workflow).

### 3.1 `run` — the exact loop (`generate_bc.py:75-190`)

```
@workflow.run
async def run(input: GenerateBCInput) -> GenerateBCResult:           # :75-76
    self._status = WorkflowStatus.RUNNING                            # :85
    self._started_at = _now_iso(); self._updated_at = started_at     # :86-87
    self._bc_name = input.bc_name                                    # :88
    self._app_id = input.app_id                                      # :89
    self._iteration = 0                                              # :90

    all_output_artifacts: list[str] = []                             # :92
    all_output_files: list = []                                      # :93
    test_results: list[str] = []                                     # :94

    while self._iteration < MAX_RALPH_ITERATIONS:                    # :96  ← STOP CONDITION (10)
        self._iteration += 1                                         # :97  ← increment FIRST
        self._current_step = f"ralph-loop-{self._iteration}"         # :98
        self._updated_at = _now_iso()                                # :99

        # ── Step 1: write tests (tdd-generation) ──
        tdd_result = await workflow.execute_activity(
            dispatch_agent_task,
            AgentTaskInput(
                task_type=f"generate-tdd-{input.bc_name}",           # :105
                app_id=input.app_id,
                skill_id="tdd-generation",                           # :107  FIXED skill
                input_artifacts=input.design_artifacts,              # :108  ← DESIGN artifacts
                source_repo=input.source_repo),                      # :109
            start_to_close_timeout=timedelta(hours=1),               # :111  1h
            retry_policy=RETRY_POLICIES["agent_failure"],            # :112  3 attempts
            activity_id=f"tdd-{input.bc_name}-iter{self._iteration}")  # :113  ⚠ iter-scoped id

        # ── Step 2: generate code (code-generation-* variant) ──
        code_generation_skill_id = select_code_generation_skill(     # :126  (§4)
            target_framework=input.target_framework,
            target_frontend=input.target_frontend,
            primary_language=input.primary_language)
        code_result = await workflow.execute_activity(
            dispatch_agent_task,
            AgentTaskInput(
                task_type=f"generate-code-{input.bc_name}",          # :134
                app_id=input.app_id,
                skill_id=code_generation_skill_id,                   # :136  ROUTED skill
                input_artifacts=tdd_result.output_artifacts,         # :137  ← TDD output feeds codegen
                source_repo=input.source_repo),
            start_to_close_timeout=timedelta(hours=1),               # :140  1h
            retry_policy=RETRY_POLICIES["agent_failure"],            # :141
            activity_id=f"codegen-{input.bc_name}-iter{self._iteration}")  # :142

        # ── Step 3: run tests (test-validation) ──
        test_result = await workflow.execute_activity(
            dispatch_agent_task,
            AgentTaskInput(
                task_type=f"test-validation-{input.bc_name}",        # :149
                app_id=input.app_id,
                skill_id="test-validation",                          # :151  FIXED skill
                input_artifacts=code_result.output_artifacts,        # :152  ← CODE output feeds validation
                source_repo=input.source_repo),
            start_to_close_timeout=timedelta(minutes=15),            # :155  ⚠ 15m (NOT 1h)
            retry_policy=RETRY_POLICIES["agent_failure"],            # :156
            activity_id=f"test-{input.bc_name}-iter{self._iteration}")  # :157

        test_results.extend(test_result.output_artifacts)            # :160  accumulate
        all_output_artifacts.extend(code_result.output_artifacts)    # :161  accumulate
        all_output_files.extend(code_result.output_files)            # :162  accumulate

        # ── Step 4: stop-condition check ──
        raw_status = test_result.status                              # :167
        if isinstance(raw_status, list): raw_status = "".join(raw_status)  # :168-169  ⚠ enum-as-list
        tests_passed = (str(raw_status) == TaskStatus.COMPLETED.value  # :170-171  "completed"
                        and not test_result.error)                   # :172
        if tests_passed:                                             # :174
            self._status = WorkflowStatus.COMPLETED                  # :175
            self._current_step = "completed"; self._updated_at=_now_iso()  # :176-177
            return GenerateBCResult(                                 # :178-185  ← SUCCESS EARLY RETURN
                bc_name=input.bc_name, status="completed",
                test_results=test_results,
                iteration_count=self._iteration,
                output_artifacts=all_output_artifacts,
                output_files=all_output_files)
        # tests failed → continue while loop (next iteration)         # :187

    # ── loop exhausted (ran all 10 iterations without success) ──
    return await self._handle_escalation(input, test_results, all_output_artifacts)  # :190
```

### 3.2 STOP CONDITION — exact predicate (`generate_bc.py:164-174`)

```
tests_passed = (str(raw_status) == TaskStatus.COMPLETED.value) and (not test_result.error)
```
where `TaskStatus.COMPLETED.value == "completed"` (`types.py:53`). 
- **Accept (success):** `test_result.status` normalizes to the string `"completed"` AND `test_result.error` is falsy → return `GenerateBCResult(status="completed", iteration_count=N)` immediately.
- **Reject (continue):** any other status (`"failed"`, `"timed_out"`, `"running"`, etc.) OR a non-empty `error` → fall through, loop to next iteration.

⚠️ **GOTCHA — the "tests" are an AGENT, not a real pytest run.** Step 3 dispatches the `test-validation` *skill* to an agent; the loop's pass/fail decision is **entirely the agent's self-reported `AgentTaskResult.status`/`error`**. There is no subprocess, no junit XML, no coverage gate inside this loop. A rebuild MUST honor this trust boundary: the Ralph Loop's correctness depends on the `test-validation` skill returning `status=COMPLETED, error=""` only when the generated code's tests genuinely pass. (Real validation/coverage enforcement happens later in the Validation assembly line and at G-04c human review — out of scope here.)

⚠️ **GOTCHA — Temporal str-enum deserialization quirk.** `test_result.status` may come back as a **list of single characters** (Temporal deserializing a `str`-enum), so the code joins it back: `if isinstance(raw_status, list): raw_status = "".join(raw_status)` (`:168-169`), then compares `str(raw_status)`. The SAME quirk is handled for `ResolutionType` in escalation (`:248-250`). A rebuild's stop-condition MUST normalize the enum the same way or it will mis-detect "completed".

⚠️ **GOTCHA — a `dispatch_agent_task` that *raises* never reaches the stop-condition.** If the agent fails hard (the dispatch activity raises `RetryableError`/`NonRetryableError` after exhausting the agent_failure retry — see §5), `execute_activity` propagates the exception out of `run`, the child workflow **fails (raises)**, and the parent's `asyncio.gather` (`modernization.py:1816`) re-raises → whole Modernization line fails. Only a *returned* `AgentTaskResult` with a non-completed status keeps the Ralph Loop iterating. This is the critical distinction between "agent reported failure" (loop continues, escalation possible) and "agent dispatch errored" (child crashes, line fails).

### 3.3 STATE CARRIED BETWEEN ITERATIONS + DATA FLOW

In-method locals (reset each `run`, NOT instance attrs):
- `all_output_artifacts: list[str]` (`:92`) — `.extend(code_result.output_artifacts)` every iter (`:161`). Cumulative across ALL iterations.
- `all_output_files: list` (`:93`) — `.extend(code_result.output_files)` every iter (`:162`). Cumulative.
- `test_results: list[str]` (`:94`) — `.extend(test_result.output_artifacts)` every iter (`:160`). Cumulative.

Instance attrs (visible to query/signals):
- `self._iteration: int` (`:65`, `:90`, `:97`) — 1..10; returned as `iteration_count`.
- `self._status`, `self._current_step`, `self._updated_at` — progress reflected in `get_status` query.

**Per-iteration data flow (the pipe):**
```
input.design_artifacts ──▶ Step1 tdd-generation ──▶ tdd_result.output_artifacts
                                                          │
                                                          ▼
                                  Step2 code-generation-* (input_artifacts = tdd_result.output_artifacts)
                                                          │ code_result.output_artifacts
                                                          ▼
                                  Step3 test-validation (input_artifacts = code_result.output_artifacts)
                                                          │ test_result.status / .error
                                                          ▼
                                                   pass? return : continue
```

⚠️ **GOTCHA — iteration N's output does NOT feed iteration N+1's Step 1.** Step 1 (`tdd-generation`) is fed `input.design_artifacts` **every iteration** (`:108`), the immutable design artifacts — NOT the prior iteration's `code_result` or `test_result`. Likewise Step 2 is fed *this iteration's* `tdd_result.output_artifacts` (`:137`), not the prior code. So **there is no explicit in-workflow feedback of failing tests into the next iteration's prompt** — each iteration re-derives tests from the same design and re-generates code from those tests. The accumulators (`all_output_artifacts`, `test_results`) only collect for the final return; they are NOT passed back into any dispatch. The "iterate to fix" intelligence lives entirely in the **shared workspace** (the agent runtime persists files under a workspace; see §3.7) — the activity inputs do NOT thread N→N+1 state. A rebuild that wires `test_result.output_artifacts` into the next `tdd-generation` input would NOT be behavioral parity.

### 3.4 PROMPT ASSEMBLY for the three Ralph steps (`AgentTaskInput` fields)

The system-prompt envelope (`build_system_prompt`, A2A surface, mock-vs-live fixture resolution, `parse_agent_json`) is specified in `regen/02-agent-runtime.md` — NOT re-reproduced. Here is exactly **what generation-specific inputs each step injects** (everything else on `AgentTaskInput` defaults):

| Field | Step 1 (tdd) | Step 2 (codegen) | Step 3 (test-val) |
|---|---|---|---|
| `task_type` | `generate-tdd-{bc_name}` | `generate-code-{bc_name}` | `test-validation-{bc_name}` |
| `skill_id` | `"tdd-generation"` (fixed) | `select_code_generation_skill(...)` (§4) | `"test-validation"` (fixed) |
| `app_id` | `input.app_id` | `input.app_id` | `input.app_id` |
| `input_artifacts` | `input.design_artifacts` | `tdd_result.output_artifacts` | `code_result.output_artifacts` |
| `source_repo` | `input.source_repo` | `input.source_repo` | `input.source_repo` |
| `wave_id` | `""` (default) | `""` | `""` |
| `artifact_repo` | `""` (default) | `""` | `""` |
| `workspace_key` | `""` (default!) | `""` | `""` |
| `context` | `{}` (default) | `{}` | `{}` |
| `execution_context` | `None` (default) | `None` | `None` |
| `model_preference` | `""` (default) | `""` | `""` |

⚠️ **GOTCHA — the Ralph child sets NO `workspace_key`, NO `execution_context`, NO `context`.** Unlike the factory `_dispatch_agent` (§2.3), the child constructs a **bare `AgentTaskInput`** with only the 5 fields above. Consequences for parity:
1. `workspace_key=""` → the agent runtime applies its own default workspace keying for these dispatches (not the factory's `modernization-{app_id}-{run_suffix}`). The cross-step file sharing within one BC relies on the runtime's default behavior given identical `app_id`+`skill`+ artifact lists, NOT an explicit workspace key.
2. `execution_context=None` → `_emit_agent_start` short-circuits (no `step_execution` row for Ralph dispatches; `agent_dispatch.py:56-60`).
3. `context={}` → no rework feedback, no governance patterns injected into the Ralph agents.
4. `input.bc_name`, `input.target_framework/frontend/primary_language` are NOT passed in `context`; only `bc_name` reaches the agent via the `task_type` string and the design artifacts. The framework hints are consumed *only* by `select_code_generation_skill` (§4) to pick the skill variant — they do not appear as agent context fields.

`GenerateBCInput` carries (`types.py:2563-2589`): `app_id, bc_name, wave_id, portfolio_id, artifact_repo, source_repo, module_map (path), design_artifacts (list), target_framework, target_frontend, primary_language`. ⚠️ Of these, the child's dispatches use only `app_id`, `bc_name`, `source_repo`, `design_artifacts`, and the three routing hints (for the router). `wave_id`, `portfolio_id`, `artifact_repo`, `module_map` are **carried but unused by the Ralph dispatches** (the parent uses `artifact_repo` for the commit; the child does not commit — the parent commits the child's `output_files` in `_commit_generate_artifacts`).

**Redaction note:** No secrets appear in any Ralph `AgentTaskInput`. Tokens/credentials are injected by the agent runtime layer (see `regen/02-agent-runtime.md`), not by this workflow.

### 3.5 ESCALATION on loop exhaustion (`_handle_escalation`, `generate_bc.py:192-264`)

Reached only after the `while` exits having run all 10 iterations without a single `tests_passed`.
```
async def _handle_escalation(input, test_results, output_artifacts) -> GenerateBCResult:  # :192
    wf_id = workflow.info().workflow_id                              # :199
    self._escalation_id = f"esc-{wf_id[-8:]}"                        # :200  ⚠ last 8 chars of wf id
    self._current_step = "escalation-pending"                       # :201
    self._status = WorkflowStatus.WAITING_FOR_SIGNAL                # :202
    self._updated_at = _now_iso()

    # Dispatch the escalation-handler skill to recommend a path
    await workflow.execute_activity(dispatch_agent_task,
        AgentTaskInput(
            task_type=f"escalation-{input.bc_name}",                # :209
            app_id=input.app_id,
            skill_id="escalation-handler",                          # :211  FIXED skill
            input_artifacts=test_results,                           # :212  ← accumulated test results
            source_repo=input.source_repo),
        start_to_close_timeout=timedelta(minutes=10),               # :215  ⚠ 10m
        retry_policy=RETRY_POLICIES["agent_failure"],               # :216  3 attempts
        activity_id=f"escalation-{input.bc_name}")                  # :217  ⚠ NOT iter-scoped (one per BC)

    # Block until a human resolves OR the workflow is cancelled
    await workflow.wait_condition(lambda:
        self._escalation_resolved or self.cancelled)                # :221-223  ← THE WAIT PREDICATE

    if self.cancelled:                                              # :225  BRANCH A: cancelled
        self._status = WorkflowStatus.CANCELLED                     # :226
        self._updated_at = _now_iso()
        return GenerateBCResult(                                    # :228-235
            bc_name=input.bc_name, status="cancelled",
            test_results=test_results, iteration_count=self._iteration,
            escalation_id=self._escalation_id,
            output_artifacts=output_artifacts)                      # (no output_files)

    # BRANCH B: resolved
    self._status = WorkflowStatus.COMPLETED                        # :237  ⚠ COMPLETED even for abandon
    self._current_step = "escalation-resolved"                     # :238
    self._updated_at = _now_iso()

    result_status = "escalated"                                    # :246  default
    resolution_type = self._escalation_resolution_type             # :247
    if isinstance(resolution_type, list):                          # :248  enum-as-list quirk
        resolution_type = "".join(resolution_type)                 # :250
    if isinstance(resolution_type, str):                           # :251
        if resolution_type == ResolutionType.ABANDON.value:        # :252  "Abandon"
            result_status = "abandoned"                            # :253  ← ABANDON branch
    elif resolution_type == ResolutionType.ABANDON:                # :254  (enum identity fallback)
        result_status = "abandoned"                                # :255

    return GenerateBCResult(                                       # :257-264
        bc_name=input.bc_name, status=result_status,
        test_results=test_results, iteration_count=self._iteration,
        escalation_id=self._escalation_id,
        output_artifacts=output_artifacts)                        # (no output_files)
```

**Every resolution branch:**
1. **Cancelled** (`self.cancelled` true via `cancel_workflow` signal): `status="cancelled"`, `_status=CANCELLED`. Returns immediately (`:225-235`).
2. **Resolved + `ABANDON`** (`resolution_type == "Abandon"`): `status="abandoned"`, `_status=COMPLETED` (`:252-253`). ⚠️ The *workflow* completes successfully (returns a value, no raise) but signals a **terminal failure of the BC**. The parent's post-G-04c projection turns this into `modernization_failed` (no partial ship). The escalation record stays open for portfolio review (per `types.py:96-99`).
3. **Resolved + any other `ResolutionType`** (`RE_EXTRACT="Re-Extract"`, `MANUAL_AUGMENT="Manual Augment"`, `RE_DISPOSITION="Re-Disposition"`): `status="escalated"` (the default, `:246`). The child returns `status="escalated"`; the actual *enactment* of Re-Extract / Manual-Augment / Re-Disposition is a **parent/operator concern** — this child does NOT itself re-enter the Ralph Loop, restart Extract, or signal Rationalization. It just reports `"escalated"` and the resolution string. (The class docstring `:14-18` describes the intended *semantics* of each escape outcome, but the child's runtime behavior for all non-abandon resolutions is identical: return `"escalated"`.)

⚠️ **GOTCHA — `ResolutionType` four members, only ABANDON changes the status.** `types.py:102-105`: `RE_EXTRACT="Re-Extract"`, `MANUAL_AUGMENT="Manual Augment"`, `RE_DISPOSITION="Re-Disposition"`, `ABANDON="Abandon"`. In `_handle_escalation`, **only `ABANDON` maps to a distinct return status** (`"abandoned"`); the other three all yield `"escalated"`. A rebuild must NOT special-case RE_EXTRACT/MANUAL_AUGMENT/RE_DISPOSITION in this child — they are indistinguishable from each other at this layer.

⚠️ **GOTCHA — escalation dispatch can still hard-fail the child.** The `escalation-handler` dispatch (`:206-218`) uses the agent_failure retry; if it exhausts and raises, `_handle_escalation` raises out of `run`, the child crashes, and the parent's gather re-raises (line fails) — the human never gets to resolve. Preserve: the recommendation dispatch is a hard prerequisite of reaching the wait.

⚠️ **GOTCHA — escalation `wait_condition` blocks indefinitely.** There is **no timeout/timer** on `wait_condition(lambda: self._escalation_resolved or self.cancelled)` (`:221-223`). The child will wait forever for a human `escalation_resolved` or `cancel_workflow` signal. A rebuild must NOT add an SLA timer here (none exists).

### 3.6 SUCCESS vs ESCALATION vs CANCEL — the three terminal return shapes
| Outcome | Reached via | `status` | `_status` | `iteration_count` | `escalation_id` | `output_files` |
|---|---|---|---|---|---|---|
| Tests passed | `:174` early return | `"completed"` | COMPLETED | N (1..10) | `""` | populated |
| Loop exhausted, resolved non-abandon | `:257` | `"escalated"` | COMPLETED | 10 | `esc-{...}` | `[]` (empty) |
| Loop exhausted, resolved ABANDON | `:257` | `"abandoned"` | COMPLETED | 10 | `esc-{...}` | `[]` |
| Loop exhausted, cancelled | `:228` | `"cancelled"` | CANCELLED | 10 | `esc-{...}` | `[]` |
| Any dispatch raises (retry exhausted) | exception | n/a (raises) | — | — | — | — |

⚠️ **GOTCHA — escalation/cancel paths drop `output_files`.** Only the success path (`:178-185`) returns `output_files=all_output_files`. The escalation/cancel returns (`:228-235`, `:257-264`) omit `output_files` (defaults to `[]`). So a BC that escalated contributes its `output_artifacts` but NOT its accumulated code files to the parent's `_commit_generate_artifacts`. Preserve this asymmetry.

### 3.7 Signals & query (`generate_bc.py:270-309`)
- `escalation_resolved(signal: EscalationResolvedSignal)` (`:270-275`): sets `_escalation_resolved=True`, `_escalation_resolution=signal.resolution`, `_escalation_resolution_type=signal.resolution_type`. `EscalationResolvedSignal` fields (`types.py:154-161`): `escalation_id, resolved_by, resolution_type, resolution`.
- `gate_approved` / `gate_rejected` / `wave_patterns_ready` (`:277-287`): **no-ops** except `_updated_at` bump. (Present for signal-surface compatibility; the Ralph child has no gates of its own.)
- `cancel_workflow` (inherited from `HILSignalsMixin`, `signals.py:76-78`): sets `self.cancelled=True`.
- Query `get_status` (`:293-309`): returns `WorkflowStatusResponse` with `current_step = "{bc_name}: {current_step} (iteration {N})"` and `progress_pct = (iteration / MAX_RALPH_ITERATIONS) * 100` (0.0 when iteration==0). ⚠️ Progress is iteration/10 — a BC that escalated at iteration 10 reads 100% even though it failed.

---

## 4. CODE-GENERATION SKILL VARIANT ROUTER (`code_generation_router.py`)

Pure Python, **no Temporal imports** (`:28-31`) — importable from both `modernization.py` and `generate_bc.py`, and unit-testable directly.

`select_code_generation_skill(target_framework, target_frontend, primary_language) -> str` (`:60-92`):
```
# Resolution order, most→least specific:
if primary_language and target_framework:                            # :84
    key = (primary_language.lower(), target_framework.lower())       # :85
    if key in CODE_GENERATION_PAIR_MAP: return CODE_GENERATION_PAIR_MAP[key]  # :86-87  (1) specialist pair
if target_frontend and target_frontend.lower() in CODE_GENERATION_SKILL_MAP:  # :88
    return CODE_GENERATION_SKILL_MAP[target_frontend.lower()]        # :89  (2) frontend
if target_framework and target_framework.lower() in CODE_GENERATION_SKILL_MAP:  # :90
    return CODE_GENERATION_SKILL_MAP[target_framework.lower()]       # :91  (3) framework
return CODE_GENERATION_SKILL_MAP["default"]                          # :92  (4) "code-generation"
```

`CODE_GENERATION_PAIR_MAP` (`:54-57`) — checked FIRST, outranks target-only because it encodes source idioms:
```
("cobol","springboot")   → "code-generation-cobol-to-java"
("natural","springboot") → "code-generation-natural-to-springboot"
```

`CODE_GENERATION_SKILL_MAP` (`:39-48`):
```
"springboot"  → "code-generation-springboot"
"aspnet-core" → "code-generation-dotnet"
"dotnet"      → "code-generation-dotnet"
"fastapi"     → "code-generation-fastapi"
"express"     → "code-generation-node"
"fastify"     → "code-generation-node"
"react"       → "code-generation-react"
"default"     → "code-generation"
```

⚠️ **GOTCHA — case-insensitive key lookup, but maps are lowercase.** All lookups `.lower()` the inputs; the map keys are lowercase. A framework hint `"SpringBoot"` resolves to `code-generation-springboot`.

⚠️ **GOTCHA — frontend is checked BEFORE framework.** If BOTH `target_frontend` and `target_framework` are set and both match, the **frontend variant wins** (`:88` before `:90`). In the Generate fan-out, the parent sets exactly one of `bc_framework`/`bc_frontend` per BC (the other is `None`), so this ordering rarely bites — but a caller that sets both would get the frontend skill.

⚠️ **GOTCHA — pair map requires BOTH language AND framework.** `("cobol", None)` does NOT match the pair map (guard `if primary_language and target_framework`, `:84`). COBOL with no framework falls through to (2)/(3)/(4).

⚠️ **GOTCHA — fan-out default framework is `express` → `code-generation-node`, frontend default is `react` → `code-generation-react`.** From `modernization.py:1781-1806`: BCs named in `{"frontend","ui","web-app","spa"}` (case-insensitive) get `target_frontend = input.target_frontend or "react"` and `target_framework=None`; ALL other BCs get `target_framework = input.target_framework or "express"` and `target_frontend=None`. So in the common wave-coordinator case (no `target_framework` set on the line input), every non-frontend BC routes to `code-generation-node` and frontend BCs to `code-generation-react`. `primary_language` flows from `input.primary_language` (`:1805`) — when set with a matching framework it can promote to a specialist pair, but with the `express`/`react` defaults the pair map never matches (no `("cobol","express")` entry), so the language hint is inert in the default fan-out.

These maps are **re-exported** from `modernization.py` for back-compat (`modernization.py:104-108, 124-129` `__all__`). The authoritative definitions live in `code_generation_router.py`.

---

## 5. THE DISPATCH ACTIVITY (`dispatch_agent_task`, `agent_dispatch.py`) — what actually runs each Ralph/factory step

Every agent step in this subsystem (factory `_dispatch_agent` and all Ralph steps) calls the SAME activity: `dispatch_agent_task`.

### 5.1 Heartbeat wrapper (`dispatch_agent_task`, `agent_dispatch.py:381-433`)
```
@foundry_activity(config=ActivityConfig(enable_observability=True))   # :381
async def dispatch_agent_task(input) -> AgentTaskResult:
    _heartbeat_task = None
    try:
        _heartbeat_task = asyncio.create_task(_heartbeat_loop(        # :407-414
            task_type, app_id, skill_id, started_monotonic=time.monotonic()))
    except Exception: log.debug("Heartbeat loop did not start")       # :415-418
    try:
        return await _dispatch_agent_task_inner(input)               # :421
    finally:
        if _heartbeat_task and not done: _heartbeat_task.cancel(); await asyncio.sleep(0)  # :423-433
```
`_heartbeat_loop` (`:332-378`): every `_HEARTBEAT_INTERVAL_SECONDS = 30.0` (`:329`) emits `activity.heartbeat({phase:"agent_streaming", task_type, app_id, skill_id, elapsed_s})`. On `CancelledError` returns (`:359-360`); on any other exception (no activity context, e.g. mock/tests) logs once and stops (`:370-378`). ⚠️ Rationale (`:338-354`): synthesis-class skills can run >1h legitimately; heartbeats let the workflow rely on `heartbeat_timeout` rather than `start_to_close_timeout` for hang detection. **Note:** the Ralph/factory `execute_activity` calls do NOT set `heartbeat_timeout` explicitly — they set only `start_to_close_timeout` (1h / 15m / 10m). So in practice the start-to-close deadline is the active liveness bound for these calls; the heartbeat is emitted but no `heartbeat_timeout` consumes it at these sites.

### 5.2 Inner dispatch — mock vs live + failure classification (`_dispatch_agent_task_inner`, `agent_dispatch.py:436-609`)
```
async def _dispatch_agent_task_inner(input) -> AgentTaskResult:
    from src.agent_registry import olympus_agent_registry            # :442
    from src.fallback_adapter import dispatch_via_subprocess         # :443
    log.info("Dispatching agent task", {...})                        # :445-454
    dispatched_at = datetime.now(utc)                                # :456
    task_row_id = await _insert_agent_task_row(input, dispatched_at) # :457  (best-effort DB row)
    exec_id = await _emit_agent_start(input.execution_context, input, task_row_id)  # :458  (None ctx→skip)

    agent_card = olympus_agent_registry.find_agent_for_skill(input.skill_id)  # :463

    if agent_card is not None:                                       # :465  ── PRIMARY A2A PATH ──
        try:
            if os.environ.get("AGENT_RUNTIME_MODE","live").strip().lower() == "mock":  # :472  ⚠
                from src.testing.mock_agent_runtime import dispatch_via_mock
                dispatcher = dispatch_via_mock                       # :473-474
            else:
                try: from olympus_api.src.services.agent_client import dispatch_via_a2a as dispatcher  # :478-480
                except ImportError: from src.agent_client import dispatch_via_a2a as dispatcher  # :481-482
            result = await dispatcher(agent_url=agent_card.url, task_input=input)  # :484-487
            if result.status == TaskStatus.FAILED:                   # :490  ← AGENT-REPORTED FAILURE
                await _update_agent_task_row(..., error=...)         # :491-494
                await _emit_agent_complete(..., status=FAILED, ...)  # :495-502
                raise RetryableError(f"Agent task failed: {result.error or 'unknown error'}")  # :503-505 ⚠
            await _update_agent_task_row(task_row_id, result, now)   # :506-508  success
            await _emit_agent_complete(..., status=COMPLETED, ...)   # :509-515
            return result                                            # :516  ← RETURN result
        except ImportError:
            log.warning("agent_client not available..."); # fall through to subprocess  # :518-522
        except RetryableError: raise                                 # :523-524  (re-raise the FAILED→RetryableError)
        except Exception as e:                                       # :525  ← A2A transport/other error
            error_str = str(e)
            failed_result = AgentTaskResult(task_id="", status=FAILED, error=error_str)  # :527-529
            await _update_agent_task_row(...); await _emit_agent_complete(..., FAILED)  # :530-541
            if _is_retryable(error_str):                             # :543
                raise RetryableError(f"A2A dispatch failed (retryable): {error_str}")  # :544-546
            raise NonRetryableError(f"A2A dispatch failed (non-retryable): {error_str}")  # :547-549

    # ── FALLBACK SUBPROCESS PATH (deprecated) — only when agent_card is None ──
    log.warning("No agent found for skill_id=%s ...")                # :552-555
    fallback_module = f"agents.{input.skill_id.lower().replace('-','_')}"  # :557
    try:
        result = await dispatch_via_subprocess(module_name=fallback_module, task_input=input)  # :559-562
    except Exception as e:
        ... failed_result; _update; _emit(FAILED)                    # :563-579
        raise RetryableError(f"Both A2A and subprocess dispatch failed: {e}")  # :580-582
    if result.status == TaskStatus.FAILED:                           # :584
        ... _update(error); _emit(FAILED)
        raise RetryableError(f"Agent task failed: {result.error}")   # :597
    await _update_agent_task_row(...); await _emit_agent_complete(..., COMPLETED)  # :599-608
    return result                                                    # :609
```

⚠️ **GOTCHA — agent-reported `TaskStatus.FAILED` becomes a `RetryableError` and is RE-RAISED.** This is the crux of the Ralph Loop's two failure modes (§3.2):
- If the **dispatcher returns** `result.status == FAILED` (`:490`), the activity raises `RetryableError` (`:503`). Temporal then retries per `agent_failure` (3 attempts). If all 3 attempts return FAILED, the activity FAILS (raises out), the child workflow crashes, the parent gather re-raises → **line fails** (NOT escalation).
- The Ralph Loop's *iterate* path (continue to next iteration) is therefore ONLY reachable when the dispatcher returns a **non-FAILED** status (e.g. `COMPLETED` but with `error` set, or some other status) — i.e. `test-validation` returning `status=COMPLETED, error="3 tests failed"` would set `tests_passed=False` (`:172` `not test_result.error` is False) and continue the loop **without** raising. ⚠️ This means: for the Ralph Loop to iterate (rather than crash), the `test-validation` skill must return `status=COMPLETED` **with a non-empty `error`** on a failing test run, NOT `status=FAILED`. A rebuild's `test-validation` fixture/skill contract MUST encode failing-tests as `COMPLETED+error`, not `FAILED`, or the loop will never iterate — it will crash on the first failing validation. (See `regen/02-agent-runtime.md` for the fixture contract.)

⚠️ **GOTCHA — `AGENT_RUNTIME_MODE` defaults to `"live"`; `"mock"` only for tests.** `os.environ.get("AGENT_RUNTIME_MODE","live").strip().lower() == "mock"` (`:472`). Production refuses to start in mock mode (enforced at worker startup, `src/config.py:WorkerConfig.validate_agent_runtime_mode`, per DECISION-018). Live path imports `dispatch_via_a2a` (preferring `olympus_api.src.services.agent_client`, falling back to bundled `src.agent_client`). Mock path imports `dispatch_via_mock` (fixture-backed). Behavioral parity: tests run with `AGENT_RUNTIME_MODE=mock`; the loop logic is identical either way — only the dispatcher source differs.

⚠️ **GOTCHA — subprocess fallback ONLY triggers when no agent card is found.** `agent_card is None` (`:465` false branch → `:551`). If the registry HAS an agent for the skill, the A2A path is taken and subprocess is never reached (except via the inner `except ImportError` fall-through at `:518` if `dispatch_via_a2a` import fails entirely). The fallback module name is `agents.{skill_id_with_underscores}` (`:557`).

`_is_retryable(error_msg)` (`:612-623`): returns `False` (non-retryable) if the lowercased message contains any of `["not found","invalid input","bad request","unauthorized","forbidden","capability"]`; otherwise `True`. So a "capability" mismatch or "not found" is non-retryable → `NonRetryableError` → no Temporal retry → immediate activity failure.

### 5.3 Observability side-writes (best-effort, never block the dispatch)
- `_insert_agent_task_row` (`:153-212`): inserts a `dispatched` `agent_task` row. ⚠️ Enforces **exactly-one of `app_id`/`wave_id`** (`:171-175`, `bool(app_id)==bool(wave_id)` raises `ValueError`). For Ralph/factory dispatches `app_id` is always set and `wave_id=""`, so this passes. DB failure → logs warning, returns `None` (`:209-212`), dispatch proceeds.
- `_emit_agent_start`/`_emit_agent_complete` (`:50-140`): emit/update a `step_execution` row, but ONLY when `execution_context is not None` AND `agent_task_id is not None` (`:56-60`). ⚠️ Ralph dispatches pass `execution_context=None`, so they emit NO step_execution rows. Factory dispatches pass `execution_context=self._execution_ctx(...)`, so they DO.
- `_update_agent_task_row` (`:236-281`): on terminal, sets status/duration/model/tokens/cost/error. `status = "failed" if error else result.status.value.lower()` (`:245`).

### 5.4 Retry policy `agent_failure` (`retry_policies.py:37-42`, `:109-116`)
```
AGENT_FAILURE_RETRY_POLICY = RetryPolicy(
    initial_interval=timedelta(seconds=5),     # :38
    backoff_coefficient=2.0,                   # :39
    maximum_interval=timedelta(seconds=60),    # :40
    maximum_attempts=3,                         # :41   ← 3 total attempts
)
RETRY_POLICIES["agent_failure"] = AGENT_FAILURE_RETRY_POLICY          # :111
```
- **3 total attempts**, backoff 5s → 10s → (capped 60s). No `non_retryable_error_types` on this policy — but `NonRetryableError` raised by the dispatch (`:547`) is a foundry-temporal non-retryable error type that Temporal won't retry regardless. So: a `RetryableError` (agent FAILED, transport blip) gets up to 3 attempts; a `NonRetryableError` (e.g. "capability" / "not found") fails on attempt 1.
- Other policies referenced in this subsystem: `transient` (= `HTTP_RETRY_POLICY`) for gate-record/commit/read activities; `git_merge` (3 attempts, 5→30s, non-retryable on the three merge errors) for PR merges (`base.py:923`).

---

## 6. FAILURE / REGRESSION HANDLING — end-to-end propagation

### 6.1 Agent failure within a Ralph step
1. Dispatcher returns `FAILED` → `RetryableError` (`agent_dispatch.py:503`) → Temporal retries (3×, agent_failure).
2. All 3 attempts FAILED → activity fails → `execute_activity` raises in `GenerateBCWorkflow.run` → child workflow **fails (raises)**.
3. Parent `asyncio.gather(*bc_tasks)` (`modernization.py:1816`, no `return_exceptions`) **re-raises** → unwinds `_execute_generate` → `_execute_modernization` → `run`'s `except Exception` (`:657`) → sets `_status=FAILED`, best-effort `_update_app_status("modernization_failed")`, re-raises → Modernization workflow fails.

### 6.2 Agent-reported test failure (the normal regression path)
1. `test-validation` returns `status=COMPLETED, error="<failures>"` → `tests_passed=False` (`generate_bc.py:172`) → **no raise**, loop continues.
2. Repeat up to 10 iterations.
3. 10 iterations exhausted with no pass → `_handle_escalation` → dispatch `escalation-handler` → block on human signal → resolve.
   - `ABANDON` → child returns `status="abandoned"` (a VALUE; child completes).
   - other → child returns `status="escalated"`.
4. Parent gathers the (non-exception) result, includes it in the G-04c gate-review-package summary (`_commit_generate_artifacts` `:2222-2236`), proceeds to human G-04c review.
5. Human decision at G-04c + the post-G-04c projection (`gate_phase="generate"`) determine `modernization_current_status` — `abandoned` BCs drive `modernization_failed` (no partial ship).

### 6.3 Non-retryable failure
- `NonRetryableError` (`agent_dispatch.py:547`) raised when `_is_retryable` returns False → Temporal does NOT retry → activity fails on attempt 1 → same crash propagation as §6.1.

### 6.4 Cancellation
- A `cancel_workflow` signal on the child sets `self.cancelled=True`; the Ralph Loop does NOT check `cancelled` inside the `while` (only the escalation wait predicate `:222` and the gate/merge waits in the base check it). So cancellation takes effect only when the child reaches `_handle_escalation`'s wait (or never, if it returns success first). ⚠️ A cancel during an in-flight Ralph dispatch is handled by Temporal's activity cancellation, not by this workflow's logic.
- Parent cancellation: the factory's gate waits and merge waits check `self.cancelled` (base `:1094`, `:1233`-loop; modernization `:942`, `:2058`) and return `"cancelled"`, which propagates up the `if ... != "approved": return` chain.

### 6.5 Parent reaction to child abandon/fail — summary
- **Child raised (hard fail):** whole line fails (§6.1).
- **Child returned `status="abandoned"`/`"escalated"`/`"cancelled"`:** parent does NOT branch on it directly in `_execute_generate`; it flows into the gate-review-package summary and the post-G-04c projection. The line continues to G-04c; the human + projection decide pass/fail.

### 6.6 ⚠️ NEW — DevSecOps baseline incomplete (machine-driven Generate rework/fail)
1. After the Generate commit, `validate_devsecops_baseline` runs on `self._committed_baseline_files` (`modernization.py:1942-1954`). It is NOT an agent — it is a deterministic activity (`transient` retry, 3 attempts) that returns `passed = not missing and not errors`.
2. `not baseline_validation.passed` (`:1955`) → reset BOTH Tier-1 flags, `_bump_rework("G-04c")` (`:1967`) — **NO PR, NO gate record, NO human involvement.**
3. If `_rework_count("G-04c") > MAX_REWORK_ITERATIONS` (`:1968`) → `_status=FAILED`, `_current_step="generate-baseline-incomplete"`, `_update_app_status("modernization_failed")`, `return "failed"` (`:1978`) → the line fails WITHOUT ever reaching G-04c.
4. Else `continue` (`:1979`) → loop-back to `:1757` → **re-parse BCs + re-fan-out all children** (a silent machine-driven regeneration; the standing guard re-checks after the next commit).
5. This SHARES the `G-04c` rework counter with the human-rejection branch (§2.6) — the 4-cycle budget is consumed by either failure mode. Distinguish the two terminal states by `_current_step`: `generate-baseline-incomplete` (machine) vs `generate-max-rework-exceeded` (human).

---

## 7. CONSOLIDATED ⚠️ GOTCHA INDEX (parity-critical)

1. **Fan-out cap = 12** (`types.py:133`), NOT 5 (stale docstring at `modernization.py:228`, `generate_bc.py:4`).
2. **Ralph cap = exactly 10 iterations**: `while _iteration < 10`, `_iteration += 1` first (`generate_bc.py:96-97`).
3. **Tests are agent-run**, not pytest: loop trusts `test_result.status`/`error` (`generate_bc.py:164-174`). The single most important fact.
4. **`test-validation` must report failing tests as `COMPLETED+error`, not `FAILED`** — else the dispatch raises and the child crashes instead of iterating (`agent_dispatch.py:490,503` vs `generate_bc.py:172`).
5. **str-enum-as-list normalization** required for both `TaskStatus` (`generate_bc.py:168-169`) and `ResolutionType` (`:248-250`).
6. **Step 1 fed `input.design_artifacts` every iteration** — no N→N+1 input threading; iteration "memory" lives in the agent runtime workspace, NOT activity inputs (`generate_bc.py:108`).
7. **Ralph child sets NO `workspace_key`/`context`/`execution_context`** — bare `AgentTaskInput` (`generate_bc.py:104-110,133-139,148-154`); factory `_dispatch_agent` sets all three (incl. the new `devsecops_baseline`).
8. **Only ABANDON yields `"abandoned"`**; RE_EXTRACT/MANUAL_AUGMENT/RE_DISPOSITION all yield `"escalated"` at this layer (`generate_bc.py:246-255`).
9. **Escalation wait has no timeout** — blocks forever on `escalation_resolved` or `cancel_workflow` (`generate_bc.py:221-223`).
10. **Abandon/cancel returns drop `output_files`** (`generate_bc.py:228-235,257-264`); only success returns them (`:178-185`).
11. **`asyncio.gather` has no `return_exceptions`** — a raising child fails the whole line (`modernization.py:1816`); but abandon is a VALUE, not a raise.
12. **Child results may be dicts** — re-hydrate `GenerateBCResult(**r)` (`modernization.py:1818-1821`); same for `output_files` via `_output_file_fields` (`:2175-2181`).
13. **Router: frontend before framework; pair-map needs BOTH lang+framework; default framework `express`→node, frontend `react`** (`code_generation_router.py:84-92`; `modernization.py:1781-1806`).
14. **Module-map read from `main`** (post-G-04b-merge) at the `files/module-design/module-map.yaml` real-YAML path, NOT the top-level envelope (`modernization.py:2127-2136`).
15. **Three BC-name fallbacks → `["default"]`** (no module-design results / read fails / parse empty) (`modernization.py:2121,2154,2158`).
16. **`parse_bc_names_from_yaml` key order: `bounded_contexts` → `contexts` → `modules`**; name from `name` or `id`; declaration order (`modernization.py:2777-~2820`).
17. **Truncation at call site** (`bc_names[:12]`, `modernization.py:1786`), parser only warns.
18. **MAX_REWORK strict `>`** → 4 gate cycles allowed before fail (`modernization.py:978` G-04a, `:1334` G-04b, `:1968` G-04c-baseline, `:2090` G-04c-human). ⚠️ The two G-04c sites share one counter.
19. **G-04c rework re-fans-out all children with identical ids** (both the machine-baseline `continue` and the human-reject loop-back) and does NOT forward gate rejection feedback NOR baseline `missing`/`errors` into children (`modernization.py:1757,1786,1979`; `_rework_gate_key_for_step` returns None for Generate).
20. **Tier-1 stakeholder waits**: G-04a needs `g-04a-sme`; G-04c needs BOTH `g-04c-ea`+`g-04c-security`; G-04b none. Flags reset on EVERY rework (incl. the new baseline-failure branch). Unknown scopes ignored (`modernization.py:356-366,935,2048`).
21. **`AGENT_RUNTIME_MODE` default `live`; mock only for tests; prod refuses mock** (`agent_dispatch.py:472`).
22. **`agent_failure` retry = 3 attempts, 5→60s**; `NonRetryableError` (`_is_retryable` keywords) skips retry (`retry_policies.py:37-42`; `agent_dispatch.py:612-623`).
23. **`run_suffix` parsed from workflow id** (`modernization.py:685`) drives branch + child-id determinism.
24. **Commit target = `target_repo_url or artifact_repo`** (`modernization.py:681`).
25. **`design-review.json` is gate-threshold-critical**; emitted every Design cycle from audit output or provisional defaults (delegated-bundle path falls back to provisional) (`modernization.py:1392-~1700`).
26. **`synthesis` step routes to G-04a in `_rework_gate_key_for_step`** despite running in Generate (`modernization.py:319`) — preserve the quirk.
27. **Heartbeats every 30s but no `heartbeat_timeout` set at Ralph/factory call sites** — start-to-close is the effective bound (1h tdd/codegen, 15m test-validation, 10m escalation) (`agent_dispatch.py:329`; `generate_bc.py:111,140,155,215`).
28. ⚠️ **NEW — DevSecOps params resolved ONCE pre-loop, reused across reworks** (`modernization.py:1736-1755`, guard `if not self._devsecops_params`). 8-key dict; threaded into Generate dispatches as `context["devsecops_baseline"]` (`:451-452`); `sast_tool` also feeds the validator.
29. ⚠️ **NEW — `validate_devsecops_baseline` INTERPOSED between Generate commit and PR** (`modernization.py:1942-1979`). `not passed` → reset Tier-1 flags + `_bump_rework("G-04c")`; `>3` → `status="generate-baseline-incomplete"` return `"failed"`; else `continue` (`:1979`) re-fans-out WITHOUT a PR/gate. SECOND machine-driven rework trigger, shares the G-04c counter. `passed = not missing and not errors`; requires 7 CI jobs lint/test/build/sast/sca/secrets-scan/image-scan + named `sast_tool` (`devsecops_validation.py:41,235`).
30. ⚠️ **NEW — `security-scan-review` is the ONLY best-effort dispatch** (`modernization.py:1877-1890`, `try/except` swallowed); `iac-scaffolding` (`:1903-1910`) is NOT wrapped (a raise fails the line). Both are new Generate-phase dispatches; neither carries rework feedback.
31. ⚠️ **NEW — W11 root-bound commit contract**: `_commit_generate_artifacts` routes files via `route_generate_file`/`is_root_bound` to the TARGET REPO ROOT (`.github/**`, `Dockerfile`, `deploy/helm/**`, `infra/terraform/**`, `SECURITY.md`) vs namespaced metadata; first-writer-wins precedence BC → synthesis → IaC; stashes the root set on `self._committed_baseline_files` for the validator (`modernization.py:2183-2340`; `devsecops_contract.py:146,168`).
32. ⚠️ **CHANGED — `self._input = input` is now set in `run`** (`modernization.py:650`); the old "prior-artifact forwarding is inert" gotcha is OBSOLETE — `_collect_extract_artifacts` blueprint forwarding is now live.
33. ⚠️ **CHANGED — Design routes through `_maybe_dispatch_bundle`** (`modernization.py:1215-1236`) with `_dispatch_design_internal` (`:1077-1152`) as the internal/fallback chain; delegated path returns a dict folded by `_fold_bundle_design_outputs` (`:1154-1184`) and sets `audit_result=None` (→ provisional `design-review.json`). Class base is now `BundleAwareMixin, LineWorkflowBase` (`:206-207`).

---

## 8. BEHAVIORAL-PARITY CHECKLIST

A rebuild is at parity iff ALL of the following hold:

**Ralph Loop (`GenerateBCWorkflow.run`):**
- [ ] `while self._iteration < 10` with `_iteration += 1` as the body's first statement → exactly 10 iterations max.
- [ ] Per iteration, exactly 3 sequential `dispatch_agent_task` activities in order: `tdd-generation` (1h), `select_code_generation_skill(...)` (1h), `test-validation` (15m), each with `RETRY_POLICIES["agent_failure"]` and activity_id `{tdd|codegen|test}-{bc_name}-iter{N}`.
- [ ] Step2 input = Step1 `output_artifacts`; Step3 input = Step2 `output_artifacts`; Step1 input = `input.design_artifacts` EVERY iteration (no N→N+1 input threading).
- [ ] Accumulate `test_results`/`all_output_artifacts`/`all_output_files` across iterations; these are NOT fed back into any dispatch.
- [ ] Stop condition: `str(normalize(status))=="completed" and not error` → early-return `GenerateBCResult(status="completed", iteration_count=N, output_files=...)`.
- [ ] str-enum-as-list `"".join(...)` normalization on `test_result.status` and `_escalation_resolution_type`.
- [ ] On exhaustion → `_handle_escalation`: `escalation_id = f"esc-{wf_id[-8:]}"`, dispatch `escalation-handler` (10m), `wait_condition(escalation_resolved or cancelled)` with NO timeout.
- [ ] Escalation branches: cancelled→`"cancelled"`/CANCELLED; ABANDON→`"abandoned"`/COMPLETED; any other resolution→`"escalated"`/COMPLETED; escalation/cancel returns omit `output_files`.
- [ ] `get_status` query: progress = iteration/10*100; signals `escalation_resolved` (sets state), `gate_approved`/`gate_rejected`/`wave_patterns_ready` (no-op + timestamp).

**Factory (`ModernizationWorkflow`):**
- [ ] `run` → `_execute_modernization` → sequential `_execute_extract`/`_execute_design`/`_execute_generate`, each returning `"approved"` to proceed, else early-return its string; top-level `except` → `modernization_failed` + raise.
- [ ] Each phase is `while True:` rework loop: dispatch → commit → PR → create gate record (G-04a/b/c) → submit evidence → pre-review-or-mark-ready → wait gate decision → on approved: optional Tier-1 wait + side-effect projection + reconcile-and-merge + return "approved"; on rejected: bump rework, fail if `>3`, else loop; on cancelled: return "cancelled".
- [ ] Extract: variant select via substring-in-prior-artifact (first match, dict order) → `LANGUAGE_SKILL_MAP`; prepend `discovery/{app_id}/business-logic.json`; cross-validation; optional br-reconciliation (patch-gated); commit; G-04a.
- [ ] Design: via `_maybe_dispatch_bundle("modernization-design", ..., fallback_fn=_dispatch_design_internal)`; internal chain = module-design → api-specification → data-modeling → (batch-design if batch archetype) → traceability-audit (always); delegated path returns dict → `_fold_bundle_design_outputs` + `audit_result=None`; commit with `design-review.json` emission (provisional default when `audit_result` None) → G-04b. NO Tier-1 wait.
- [ ] Generate PRE-LOOP: `if not self._devsecops_params:` resolve `resolve_devsecops_profile(profile_id=portfolio_id or "")` (30s, transient) → 8-key dict; reused across reworks.
- [ ] Generate LOOP: `_parse_bounded_contexts` (read main, `files/module-design/module-map.yaml`, 3 fallbacks to `["default"]`) → `bc_names[:12]` fan-out with per-BC framework routing (`express`/`react` defaults, frontend-name set) → spawn `GenerateBCWorkflow` children (id `generate-bc-{app}-{bc}-{suffix}`, same task queue) → `asyncio.gather` (no return_exceptions) → re-hydrate dict results → `code-synthesis` → `adversarial-review` → `security-posture-review` → `security-scan-review` (TRY/EXCEPT best-effort) → `iac-scaffolding` (NOT wrapped) → `gate-review-package` → `_commit_generate_artifacts` (W11 root-bound, stashes `_committed_baseline_files`) → **`validate_devsecops_baseline` (60s, transient) on `_committed_baseline_files`**.
- [ ] Generate BASELINE GATE (interposed commit→PR): `if not baseline_validation.passed:` reset both Tier-1 flags + `_bump_rework("G-04c")`; if `>3` → `status="generate-baseline-incomplete"` return `"failed"`; else `continue` (re-fan-out, no PR). Only when passed: create PR → G-04c → on approve optional Tier-1 triple-signal wait + projection + merge; on human reject reset flags + `_bump_rework("G-04c")`, `>3` → `status="generate-max-rework-exceeded"` return `"failed"`, else loop.
- [ ] Commit target repo = `target_repo_url or artifact_repo`; `run_suffix` from workflow id; `workspace_key="modernization-{app}-{suffix}"` on all factory dispatches.
- [ ] Tier-1 gate waits exactly as in §2.8; flags reset on EVERY rework (incl. baseline-failure branch).
- [ ] Governance patterns AND `devsecops_baseline` (Generate only) threaded into factory dispatch context when present.

**Router (`select_code_generation_skill`):**
- [ ] Resolution order pair-map(lang,framework) → frontend → framework → `"code-generation"` default; case-insensitive; exact maps per §4.

**Dispatch activity (`dispatch_agent_task`):**
- [ ] Heartbeat loop every 30s, cancelled in `finally`.
- [ ] `AGENT_RUNTIME_MODE` mock-vs-live branch (default live); subprocess fallback only when no agent card.
- [ ] Agent `status==FAILED` → `RetryableError` (re-raised); transport error → `_is_retryable` → Retryable/NonRetryable; success → return result.
- [ ] Best-effort `agent_task` row + `step_execution` row (only when `execution_context` present); never block dispatch.
- [ ] `RETRY_POLICIES["agent_failure"]` = 3 attempts, 5s/2.0/60s.

**Constants:**
- [ ] `MAX_RALPH_ITERATIONS=10`, `MAX_BC_CHILDREN_PER_APP=12`, `MAX_REWORK_ITERATIONS=3`.

---

## 9. THINGS LEFT UNDETERMINED BY THIS SUBSYSTEM (resolve from cross-ref specs)

- The exact A2A prompt envelope and how `input_artifacts`/`source_repo`/skill fixtures become the agent's working context — see `regen/02-agent-runtime.md` (`build_system_prompt`, `dispatch_via_a2a`, `dispatch_via_mock`, fixture resolution, `parse_agent_json`, `output_validator` schema check).
- The `test-validation` / `tdd-generation` / `code-generation-*` / `escalation-handler` SKILL.md contracts and their fixture shapes (what `status`/`error`/`output_artifacts`/`output_files` they return) — see the skill registry and `regen/02-agent-runtime.md`. ⚠️ Parity of the Ralph Loop depends on the `test-validation` fixture encoding failing tests as `COMPLETED+error` (Gotcha #4).
- `LineWorkflowBase` internals NOT reproduced here: `_set_step`, `_update_app_status`, `_submit_gate_evidence`, `_run_gate_pre_review`, `_execution_ctx`, `_bump_rework`/`_rework_count`, the gate signal handlers that populate `self._gate_decisions`, `_persist_side_effects` activity bodies (`persist_modernization_side_effects`) — see `regen/03-workflows/` (base) and `regen/03b-activities/`.
- How `GenerateBCResult.status="abandoned"` is consumed by the post-G-04c projection to set `modernization_current_status=modernization_failed` — the projection logic lives in `persist_modernization_side_effects` (`gate_phase="generate"`), specified in `regen/03b-activities/`.
- The wave/portfolio/app workflow chain that constructs `LineWorkflowInput` (including `target_repo_url`, `target_framework`, `primary_language`, `prior_artifacts`) and spawns `ModernizationWorkflow` — see `regen/03-workflows/`.
