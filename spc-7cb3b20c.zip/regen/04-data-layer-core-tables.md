# 04 — Data Layer: Core Tables (portfolio / wave / application / system / domain hierarchy + lineage)

> ATOMIC regeneration spec. Premise: the codebase is deleted; this file must let the
> 11 named tables be rebuilt **EXACTLY**. Column-by-column, every CHECK value-set in full,
> every index/unique constraint, every JSONB shape, every FK + ON DELETE/UPDATE, the
> migration that introduced each column. Cite `path:line`.
>
> **Tables covered here:** `portfolio`, `wave`, `wave_application`, `application`,
> `application_lineage`, `system`, `system_application`, `system_lineage`,
> `business_domain`, `business_domain_lineage`, `bounded_context`.
>
> Migration directory: `/Users/pnunna/Documents/GitHub/foundry/db/alembic/versions/` (64 files,
> revisions `001`..`066`, with intentional gaps — there is **no `055`**; see §0.3).
> All FK `ON UPDATE` actions are PostgreSQL default (`NO ACTION`) everywhere — SQLAlchemy
> `sa.ForeignKey(...)` is never given `onupdate=`, so it is omitted from the per-column tables
> below (assume `ON UPDATE NO ACTION` universally).

---

## 0. Source-of-truth model, conventions, and the migration DAG

### 0.1 Git-as-source-of-truth + PostgreSQL projection model

Postgres is a **derived, disposable query layer** (CLAUDE.md core principle #4). The
authoritative artifacts live in Git (artifact repos). Rows in these tables are *projected*
from committed artifact JSON by Temporal **`persist_*` activities** (cross-ref
`regen/03b-activities/`). Two distinct write paths exist:

1. **Workflow projection** — `persist_*` activities parse a committed artifact JSON, build a
   sparse projection dict, and `UPDATE`/`UPSERT` rows. These are idempotent on re-run (Temporal
   at-least-once). Detailed per-table in §3 and the JSONB shapes in §4.
2. **API/service writes** — CRUD endpoints write `portfolio`, `wave`, `wave_application`,
   and seed `application` rows directly (onboarding). E.g. wave membership is written by the
   service layer, not an activity: `INSERT INTO wave_application (wave_id,application_id) VALUES (...) ON CONFLICT DO NOTHING`
   (`regen/01-api-services-logic.md:950`).

Per the repo-wide **migration-seeding separation rule**: every Alembic migration is **DDL-only**
(plus the two narrow exceptions noted below). No bulk data load lives in a migration. Seeds live
in `scripts/seed_*.py`.

**DML/data exceptions among the covered tables (NOT DDL):**
- `022_normalize_wave_status_values.py:27-29` — one-time `UPDATE wave SET status='draft' WHERE status='planned'` and `…='in_progress' WHERE status='active'` (idempotent; prepares rows for the 023 CHECK).
- `052_rationalization_capability.py:300-324` and `058_application_disposition_capability_grain.py:93-138` — `CREATE [OR REPLACE] VIEW application_disposition` (a **view**, not a covered table, but it reads `system_application` + `capability`; documented in §3.9 because it is the per-app disposition rollup the dashboard consumes).
- `047_add_consolidated_into_target_status.py:57-70` — `COMMENT ON COLUMN application.current_status` + a partial index (no column change).

### 0.2 DDL conventions (apply to every column below)

- PK UUIDs: `UUID(as_uuid=True)`, `primary_key=True`, `server_default=sa.text("gen_random_uuid()")` (requires `pgcrypto`/`gen_random_uuid`).
- Audit timestamps: `sa.DateTime(timezone=True)` or `sa.TIMESTAMP(timezone=True)` (= `TIMESTAMPTZ`), `nullable=False`, `server_default=sa.text("now()")` (some later migrations spell it `sa.text("NOW()")` — semantically identical).
- Enums referenced by `002`/`004` use `postgresql.ENUM(..., create_type=False)` so SQLAlchemy does **not** re-issue `CREATE TYPE` (the types are created in `001`/`021`). See `002:16-36`.
- **JSONB serialization gotcha:** `persist_*` activities pre-serialize JSONB column values with `json.dumps(...)` and bind them as **text**; asyncpg implicitly casts to JSONB on assignment (the column type drives the cast). The canonical `_JSONB_COLUMNS` frozenset (shared by all per-line persist activities) is: `{tech_stack, size_metrics, architecture, business_logic, quality, ux_assessment, tco, portfolio_score, data_domains, bounded_contexts, generated_module_refs}` (`regen/03b-activities/line_transitions-1-discovery-decomp-capability.md:371`). Anything not in that set is bound natively.

### 0.3 Migration DAG (linear chain with one fan-out/merge; one numbering gap)

Chain (rev ← down_rev). Straight line `001→…→033`, then a **fan-out at 033** (four children
share `down_revision="033"`: 034, 035, 036, 038), then a **merge at 039**
(`down_revision=("034","035","037","038")`), then linear `039→…→066`.

```
001→002→003→004→005→006→007→008→009→010→011→012→013→014→015→016→017→018→019→020
→021→022→023→024→025→026→027→028→029→030→031→032→033
                                                   ├─→034 ─┐
                                                   ├─→035 ─┤
                                                   ├─→036→037 ─┤   (037 down=036)
                                                   └─→038 ─┘
                                          039 (merge: down=(034,035,037,038)) →040→041
→042→043→044→045→046→047→048→049→050→051→052→053→054→ [NO 055] →056→057→058→059
→060→061→062→063→064→065→066  (head)
```

⚠️ **`036` is reachable only via `037`** (036.down=033, 037.down=036, and the 039 merge lists
`037` not `036`). ⚠️ There is **no migration `055`** — `056.down_revision="054"` (intentional
numbering gap; not a missing file). ⚠️ Head is `066`.

⚠️ **Docstring vs. code mismatch (harmless):** `049_add_stuck_awaiting_recovery_wave_status.py`
has a docstring header reading "Revision ID: 048 / Revises: 047" but the executable
`revision="049"`, `down_revision="048"` (`049:46-47`). Trust the code. Likewise `059`'s docstring
claims the wave CHECK was "extended in 023/043/045/047/049" — but **047 never touched the wave
constraint** (it only touched `application.current_status`; see §1.10/§3.9). The true wave-CHECK
mutation chain is `023 → 043 → 045 → 049 → 059` (§1.2.1).

### 0.4 Enum types relevant to the covered tables (created in `001`, `021`)

From `001_create_enum_types.py`:
- `risk_tier_enum` = `('1','2','3')` (`001:22-24`)
- `complexity_tier_enum` = `('simple','moderate','complex')` (`001:26-30`)
- `tier_source_enum` = `('auto','confirmed','overridden')` (`001:32-36`)
- `disposition_enum` = `('Retire','Retain','Refactor','Rearchitect','Replace','Replatform','Consolidate')` (`001:38-43`)
- `assembly_line_enum` = `('Discovery','Rationalization','Architecture','Data','Modernization','Disposition Execution','Validation','Deployment','Sustainment','Governance')` (`001:61-67`)

From `021_add_application_archetype.py:36-41`:
- `archetype_enum` = `('web-app','batch-etl','api-service','scheduled-job','hybrid')`

⚠️ **Enum types are created with plain `CREATE TYPE … AS ENUM (...)` listing all values in one
statement** — there is **no `ALTER TYPE … ADD VALUE`** anywhere in the migration set for the enums
the covered tables use. (The non-transactional `ADD VALUE` ordering hazard does **not** apply here.)
String lifecycle vocabularies that *do* grow incrementally (`wave.status`, `application.current_status`,
`application.*_current_status`) were deliberately modeled as **VARCHAR (+ optional CHECK)**, not enums,
precisely to avoid that hazard — see the "flexibility" note in §1.2.1 and §1.10.

---

## 1. `portfolio` — 8 columns

Created `002_create_core_tables.py:47-58`. The portfolio is the top of the hierarchy (1 portfolio
→ N waves, N applications, N systems).

| # | column | type | nullable | default | FK (→table.col, ON DELETE) | added-by |
|---|--------|------|----------|---------|----------------------------|----------|
| 1 | `id` | `UUID` | NO | `gen_random_uuid()` | PK | `002:49-50` |
| 2 | `name` | `VARCHAR(255)` | NO | — | — | `002:51` |
| 3 | `owner` | `VARCHAR(255)` | NO | — | — | `002:52` |
| 4 | `created_at` | `TIMESTAMPTZ` | NO | `now()` | — | `002:53-54` |
| 5 | `updated_at` | `TIMESTAMPTZ` | NO | `now()` | — | `002:55-56` |
| 6 | `status` | `VARCHAR(50)` | NO | `'active'` (string literal) | — | `002:57` |
| 7 | `artifact_repo_url` | `TEXT` | YES | — | — | `008:23-25` |

**CHECK constraints:** none.
**Indexes:** none declared (PK only).
**Unique constraints:** none beyond PK.
**JSONB columns:** none.

⚠️ `status` is a free-form `VARCHAR(50)` with **no CHECK** — any string is accepted (default `'active'`).
⚠️ `artifact_repo_url` (`008`) holds the GitHub repo URL where Discovery artifacts are stored — the
Git-source-of-truth anchor for the whole portfolio. Nullable; pre-`008` rows read NULL.

**Referenced by (children, ON DELETE CASCADE — mass-delete risk, see §5):** `wave.portfolio_id`,
`application.portfolio_id`, `system.portfolio_id`, `rationalization_capability.portfolio_id`,
plus `chat_message` (`014`) and `portfolio_membership` (`056`). Deleting a `portfolio` row cascades
to **all** waves/apps/systems/rat-caps in the portfolio.

---

## 2. `wave` — 14 columns

Created `002_create_core_tables.py:61-73`. A wave is a scheduled cohort of applications within a
portfolio (1 portfolio → N waves; N:M to applications via `wave_application`).

| # | column | type | nullable | default | FK (→table.col, ON DELETE) | added-by |
|---|--------|------|----------|---------|----------------------------|----------|
| 1 | `id` | `UUID` | NO | `gen_random_uuid()` | PK | `002:63-64` |
| 2 | `portfolio_id` | `UUID` | NO | — | `→portfolio.id` **ON DELETE CASCADE** | `002:65-66` |
| 3 | `wave_number` | `INTEGER` | NO | — | — | `002:67` |
| 4 | `status` | `VARCHAR(50)` | NO | `'planned'` → **flipped to `'draft'`** by `023:39` | — (but gains a CHECK in `023`; see §2.1) | `002:68` |
| 5 | `planned_start` | `DATE` | YES | — | — | `002:69` |
| 6 | `planned_end` | `DATE` | YES | — | — | `002:70` |
| 7 | `actual_start` | `DATE` | YES | — | — | `002:71` |
| 8 | `actual_end` | `DATE` | YES | — | — | `002:72` |
| 9 | `name` | `VARCHAR(255)` | YES | — | — | `006:23` |
| 10 | `created_at` | `TIMESTAMPTZ` | NO | `now()` | — | `006:24-32` |
| 11 | `updated_at` | `TIMESTAMPTZ` | NO | `now()` | — | `006:33-41` |
| 12 | `workflow_id` | `VARCHAR(255)` | YES | — | — | `007:23` (points at `WaveRationalizationWorkflow`) |
| 13 | `description` | `TEXT` | YES | — | — | `041:32-35` |
| 14 | `failed_at` | `TIMESTAMPTZ` | YES | — | — | `043:72-75` |
| 15 | `failure_reason` | `TEXT` | YES | — (≤500 chars by convention; truncated by caller) | — | `043:76-79` |
| 16 | `architecture_workflow_id` | `VARCHAR(255)` | YES | — | — | `054:42-57` (points at `WaveArchitectureWorkflow`) |

(16 physical columns; numbering above is creation order.)

⚠️ **`wave_number` is `NOT NULL` with NO default** — every insert MUST supply it.
⚠️ **Two workflow-handle columns coexist by design** (`054` docstring): `workflow_id` →
`WaveRationalizationWorkflow` (Discovery/Rationalization/G-RR/G-DA); `architecture_workflow_id` →
`WaveArchitectureWorkflow` (post-G-DA target mapping + per-target fan-out). The API routes
signals/queries to the right handle based on `status`. `workflow_id` is **never cleared** on handoff.

### 2.1 `wave.status` — the CHECK constraint `wave_status_lifecycle_chk` (THE key gotcha)

`status` is a **VARCHAR(50)** (not an enum) so its allowed-value set could evolve via cheap
drop+recreate of a CHECK rather than the non-transactional `ALTER TYPE … ADD VALUE` dance. The
constraint is **added in 023** and then **dropped-and-recreated** (same constraint name, widened set)
across four later migrations. Each migration does `ALTER TABLE wave DROP CONSTRAINT IF EXISTS
wave_status_lifecycle_chk` then `ALTER TABLE wave ADD CONSTRAINT wave_status_lifecycle_chk CHECK (status IN (...))`.

Evolution (constraint name is stable = `wave_status_lifecycle_chk` throughout):

| migration | line | values added | resulting full allowed set (in source order) |
|-----------|------|--------------|-----------------------------------------------|
| `023` | `023:34-44` | (initial) `draft, ready, in_progress, completed, cancelled` + default flips `planned`→`draft` | `draft, ready, in_progress, completed, cancelled` |
| `043` | `043:41-68` | `+ failed` | `draft, ready, in_progress, completed, cancelled, failed` |
| `045` | `045:44-72` | `+ awaiting-architecture-dispatch, architecture-in-flight, data-in-flight` | `draft, ready, in_progress, awaiting-architecture-dispatch, architecture-in-flight, data-in-flight, completed, cancelled, failed` |
| `049` | `049:52-84` | `+ stuck-awaiting-recovery` | `draft, ready, in_progress, awaiting-architecture-dispatch, architecture-in-flight, data-in-flight, completed, cancelled, failed, stuck-awaiting-recovery` |
| `059` | `059:40-75` | `+ modernization-in-flight, modernization-complete` | **FINAL (12 values):** `draft, ready, in_progress, awaiting-architecture-dispatch, architecture-in-flight, data-in-flight, modernization-in-flight, modernization-complete, completed, cancelled, failed, stuck-awaiting-recovery` |

**FINAL value set (rebuild target):**
```sql
ALTER TABLE wave ADD CONSTRAINT wave_status_lifecycle_chk CHECK (status IN (
  'draft', 'ready', 'in_progress',
  'awaiting-architecture-dispatch', 'architecture-in-flight', 'data-in-flight',
  'modernization-in-flight', 'modernization-complete',
  'completed', 'cancelled', 'failed', 'stuck-awaiting-recovery'
));
```
⚠️ A clean rebuild that runs all migrations in order arrives at exactly this set. If short-cutting,
emit only the final CHECK. ⚠️ Server-default for `status` is **`'draft'`** after `023` (was `'planned'`
in `002`). ⚠️ `043` ordering: it widens the CHECK to add `failed` **before** adding the
`failed_at`/`failure_reason` columns (`043:59-79`); downgrade reverses (drops columns first, then
narrows CHECK) to avoid orphaned `failed` rows violating the narrowed constraint.

Lifecycle semantics (from docstrings): `draft`=accumulating apps; `ready`=stakeholder flipped,
rationalization about to/already running; `in_progress`=rationalization+downstream running;
`awaiting-architecture-dispatch`=G-DA approved, awaiting reviewer pre-dispatch form;
`architecture-in-flight`/`data-in-flight`/`modernization-in-flight`=per-line fan-out phases;
`modernization-complete`=terminal alias of `completed` keeping line context;
`completed`/`cancelled`=terminal; `failed`=terminal (artifacts may be invalid, full reset+retry);
`stuck-awaiting-recovery`=recoverable (artifacts valid, a downstream handoff failed, `/resume` walks forward).

**Indexes:** `ix_wave_workflow_id` on `(workflow_id)` — `007:24`.
**Unique constraints:** none beyond PK.
**JSONB columns:** none.

### 2.2 `wave` projection writers (activities)

- `persist_wave_failure` → sets `status` + `failed_at` + `failure_reason` + `updated_at`. Single `now=datetime.now(timezone.utc)` reused for `failed_at` and `updated_at`; `failure_reason=(input.reason or "")[:500]` (caller already truncates at `wave_rationalization.py:1278`); `workflow_id` deliberately NOT written/cleared. No `WHERE status!='failed'` guard (idempotent overwrite). `regen/03b-activities/wave_operations.md:10,121,135-162`.
- `update_wave_status` → `status` + `updated_at`; conditionally `failure_reason = COALESCE(NULLIF($4,''), failure_reason)` and `failed_at = COALESCE(failed_at, $3)` **only when** `input.reason` truthy AND `new_status ∈ {failed, stuck-awaiting-recovery}`. Otherwise `failure_reason`/`failed_at` untouched (preserve prior failure narrative). `failed_at` is sticky (first-failure timestamp preserved). `regen/03b-activities/wave_operations.md:11,210-256`.
- `update_wave_architecture_workflow_id` → `architecture_workflow_id` + `updated_at`; empty-guard on both inputs; early-return on 0-row update. `regen/03b-activities/wave_operations.md:12,261-297`.

---

## 3. Hierarchy + lineage tables

### 3.0 `wave_application` — junction (2 columns)

Created `002_create_core_tables.py:107-115`. Pure N:M edge table (composite PK; no own id, no timestamps).

| # | column | type | nullable | default | FK (→table.col, ON DELETE) | added-by |
|---|--------|------|----------|---------|----------------------------|----------|
| 1 | `wave_id` | `UUID` | NO (PK) | — | `→wave.id` **ON DELETE CASCADE** | `002:109-111` |
| 2 | `application_id` | `UUID` | NO (PK) | — | `→application.id` **ON DELETE CASCADE** | `002:112-114` |

**PK:** composite `(wave_id, application_id)` (implicit from both columns `primary_key=True`).
**CHECK / indexes / unique:** none beyond the composite PK. **JSONB:** none.
**Writer:** API service layer (NOT an activity). `INSERT INTO wave_application (wave_id,application_id) VALUES (...) ON CONFLICT DO NOTHING` (`regen/01-api-services-logic.md:950`, idempotent). Membership fixed at wave start.
⚠️ ON DELETE CASCADE on **both** FKs — deleting either a wave or an application removes the edge.

---

### 3.1 `application` — 82 columns (the widest covered table)

Created `002_create_core_tables.py:76-104` with 23 columns; **34 more added** across migrations
`009, 010, 016, 021, 024, 028, 029, 030, 031, 032, 034, 035, 036, 037, 051, 053`. This is the
central projection target: nearly every line's `persist_*_side_effects` activity writes a subset
of these columns via a dynamic `UPDATE application SET … WHERE id=$N`.

**Created in 002 (`002:76-104`):**

| # | column | type | nullable | default | FK (→table.col, ON DELETE) | added-by |
|---|--------|------|----------|---------|----------------------------|----------|
| 1 | `id` | `UUID` | NO | `gen_random_uuid()` | PK | `002:78-79` |
| 2 | `portfolio_id` | `UUID` | NO | — | `→portfolio.id` **ON DELETE CASCADE** | `002:80-81` |
| 3 | `name` | `VARCHAR(255)` | NO | — | — | `002:82` |
| 4 | `repo_url` | `TEXT` | YES | — | — | `002:83` |
| 5 | `business_domain` | `VARCHAR(255)` | YES | — | — | `002:84` |
| 6 | `owner` | `VARCHAR(255)` | YES | — | — | `002:85` |
| 7 | `current_line` | `assembly_line_enum` | YES | — | — | `002:86` |
| 8 | `current_step` | `VARCHAR(100)` | YES | — | — | `002:87` |
| 9 | `current_status` | `VARCHAR(50)` | YES | — | — (no CHECK; COMMENT added in `047`) | `002:88` |
| 10 | `risk_tier` | `risk_tier_enum` | YES | — | — | `002:89` |
| 11 | `risk_tier_source` | `tier_source_enum` | YES | — | — | `002:90` |
| 12 | `complexity_tier` | `complexity_tier_enum` | YES | — | — | `002:91` |
| 13 | `complexity_tier_source` | `tier_source_enum` | YES | — | — | `002:92` |
| 14 | `decomposition_map` | `JSONB` | YES | — | — | `002:93` |
| 15 | `user_context` | `JSONB` | YES | — | — | `002:94` |
| 16 | `ux_assessment` | `JSONB` | YES | — | — | `002:95` |
| 17 | `disposition` | `disposition_enum` | YES | — | — | `002:96` |
| 18 | `user_impact` | `JSONB` | YES | — | — | `002:97` |
| 19 | `wave_assignment` | `INTEGER` | YES | — | — | `002:98` |
| 20 | `analyzed_commit_sha` | `VARCHAR(40)` | YES | — | — | `002:99` |
| 21 | `created_at` | `TIMESTAMPTZ` | NO | `now()` | — | `002:100-101` |
| 22 | `updated_at` | `TIMESTAMPTZ` | NO | `now()` | — | `002:102-103` |

**Added by later migrations:**

| # | column | type | nullable | default | FK | added-by |
|---|--------|------|----------|---------|----|----------|
| 23 | `source_git_token` | `TEXT` | YES | — | — | `009:22-25` |
| 24 | `source_git_base_url` | `TEXT` | YES | — | — | `009:26-29` |
| 25 | `workflow_id` | `VARCHAR(255)` | YES | — | — | `010:22-25` |
| 26 | `description` | `TEXT` | YES | — | — | `016:23-26` |
| 27 | `target_repo_url` | `TEXT` | YES | — | — | `016:27-30` |
| 28 | `target_git_token` | `TEXT` | YES | — | — | `016:31-34` |
| 29 | `target_git_base_url` | `TEXT` | YES | — | — | `016:35-38` |
| 30 | `archetype` | `archetype_enum` | YES | — | — | `021:43-55` |
| 31 | `archetype_source` | `tier_source_enum` | YES | — | — | `021:56-67` |
| 32 | `portfolio_score` | `JSONB` | YES | — | — | `024:44-47` |
| 33 | `tech_stack` | `JSONB` | YES | — | — | `028:76-79` |
| 34 | `size_metrics` | `JSONB` | YES | — | — | `028:80-83` |
| 35 | `safety_tier` | `VARCHAR(8)` | YES | — | — | `028:84-87` |
| 36 | `architecture` | `JSONB` | YES | — | — | `028:88-91` |
| 37 | `business_logic` | `JSONB` | YES | — | — | `028:92-95` |
| 38 | `quality` | `JSONB` | YES | — | — | `028:96-99` |
| 39 | `tco` | `JSONB` | YES | — | — | `028:100-103` |
| 40 | `disposition_source` | `VARCHAR(16)` | YES | — | — | `029:66-69` |
| 41 | `disposition_rationale_ref` | `TEXT` | YES | — | — | `029:70-73` |
| 42 | `architecture_blueprint_ref` | `TEXT` | YES | — | — | `030:79-82` |
| 43 | `architecture_pattern` | `VARCHAR(32)` | YES | — | — | `030:83-86` |
| 44 | `architecture_decided_at` | `TIMESTAMPTZ` | YES | — | — | `030:87-94` |
| 45 | `source_app_ids` | `UUID[]` (`ARRAY(UUID)`) | YES | — | — (denormalized cache of `application_lineage`) | `030:96-103` |
| 46 | `data_architecture_ref` | `TEXT` | YES | — | — | `031:88-91` |
| 47 | `data_migration_plan_ref` | `TEXT` | YES | — | — | `031:92-95` |
| 48 | `data_decided_at` | `TIMESTAMPTZ` | YES | — | — | `031:96-103` |
| 49 | `data_pattern` | `VARCHAR(32)` | YES | — | — | `031:104-107` |
| 50 | `data_domains` | `JSONB` | YES | — | — | `031:108-115` |
| 51 | `data_current_status` | `VARCHAR(64)` | YES | — | — | `031:116-123` |
| 52 | `extraction_ref` | `TEXT` | YES | — | — | `032:96-99` |
| 53 | `extraction_at` | `TIMESTAMPTZ` | YES | — | — | `032:100-107` |
| 54 | `bounded_contexts` | `JSONB` | YES | — | — | `032:108-111` |
| 55 | `design_ref` | `TEXT` | YES | — | — | `032:113-116` |
| 56 | `design_at` | `TIMESTAMPTZ` | YES | — | — | `032:117-124` |
| 57 | `modernization_pattern` | `VARCHAR(32)` | YES | — | — | `032:125-128` |
| 58 | `generated_module_refs` | `JSONB` | YES | — | — | `032:130-133` |
| 59 | `generate_at` | `TIMESTAMPTZ` | YES | — | — | `032:134-141` |
| 60 | `modernization_current_status` | `VARCHAR(64)` | YES | — | — | `032:142-149` |
| 61 | `validation_parity_score` | `NUMERIC(5,2)` | YES | — | — | `035:78-81` |
| 62 | `validation_critical_vuln_count` | `INTEGER` | YES | — | — | `035:82-87` |
| 63 | `validation_accessibility_score` | `NUMERIC(5,2)` | YES | — | — | `035:88-93` |
| 64 | `validation_safety_case_ref` | `TEXT` | YES | — | — | `035:94-97` |
| 65 | `validation_completed_at` | `TIMESTAMPTZ` | YES | — | — | `035:98-105` |
| 66 | `validation_current_status` | `VARCHAR(64)` | YES | — | — | `035:106-111` |
| 67 | `deployed_at` | `TIMESTAMPTZ` | YES | — | — | `036:78-85` |
| 68 | `deployment_env` | `VARCHAR(64)` | YES | — | — | `036:86-89` |
| 69 | `cutover_strategy` | `VARCHAR(32)` | YES | — | — | `036:90-93` |
| 70 | `parallel_run_duration_days` | `INTEGER` | YES | — | — | `036:94-101` |
| 71 | `cost_savings_realized_usd` | `NUMERIC(12,2)` | YES | — | — | `036:103-110` |
| 72 | `license_reclamation_usd` | `NUMERIC(12,2)` | YES | — | — | `036:111-118` |
| 73 | `legacy_decommissioned_at` | `TIMESTAMPTZ` | YES | — | — | `036:119-126` |
| 74 | `deployment_current_status` | `VARCHAR(64)` | YES | — | — | `036:128-135` |
| 75 | `disposition_output_ref` | `TEXT` | YES | — | — | `034:62-65` |
| 76 | `disposition_completed_at` | `TIMESTAMPTZ` | YES | — | — | `034:66-73` |
| 77 | `disposition_current_status` | `VARCHAR(64)` | YES | — | — | `034:74-79` |
| 78 | `cost_savings_annual_usd` | `NUMERIC(12,2)` | YES | — | — | `034:80-87` |
| 79 | `sustainment_current_status` | `VARCHAR(64)` | YES | — | — | `037:345-352` |
| 80 | `sustainment_last_sweep_at` | `TIMESTAMPTZ` | YES | — | — | `037:353-360` |
| 81 | `metadata` | `JSONB` | **NO** | `'{}'::jsonb` | — | `051:42-59` |
| 82 | `target_service_id` | `VARCHAR(64)` | YES | — | — | `053:38-54` |

(82 physical columns. Earlier "57" in the heading undercounts; the authoritative count is **82**.)

#### `application` CHECK constraints
**None at the table level.** ⚠️ `current_status` and all `*_current_status` columns are free-form
`VARCHAR(50/64)` with NO CHECK — by design (see §1.10 / §3.9). The only documentation of allowed
`current_status` values is a `COMMENT ON COLUMN` (added `047`, see §3.9).

#### `application` indexes
- `ix_application_portfolio_id` on `(portfolio_id)` — `005:23-24`
- `ix_application_current_status` on `(current_status)` — `005:25-26`
- `ix_application_disposition` on `(disposition)` — `005:27-28`
- `ix_application_risk_tier` on `(risk_tier)` — `005:29-30`
- `idx_application_consolidated_sources` **partial** on `(current_status) WHERE current_status='consolidated_into_target'` — `047:66-70` (raw `CREATE INDEX IF NOT EXISTS`)

#### `application` unique constraints
None beyond PK.

#### ⚠️ `application` GOTCHAS
- **`disposition` is `disposition_enum`, NOT VARCHAR.** Created in `002:96` as the enum. Migration `029`'s docstring describes it as "VARCHAR(16)" but `029` only ADDS `disposition_source` (VARCHAR(16)) + `disposition_rationale_ref` (TEXT) — it **does not** alter the existing `disposition` column. No migration ever converts `application.disposition` enum→varchar. Rebuild it as `disposition_enum`.
- **`metadata` is the ONLY non-nullable late-added column** (`NOT NULL DEFAULT '{}'::jsonb`, `051`). Every other post-002 column is nullable-with-no-default. The default keeps dashboard reads (`app.metadata.compliance.*`) from special-casing NULL.
- **`current_step`, `current_status`, `current_line`** remain the AppWorkflow/Architecture's portfolio-view lifecycle. The per-line `*_current_status` columns (data/modernization/validation/deployment/disposition/sustainment) live *alongside* and do NOT replace them.
- **`source_app_ids` (UUID[])** is a denormalized cache of `application_lineage` edges (both representations kept by contract decision 2026-04-30, `030` docstring). Empty array for self-dispositions; 1 element for Replace; N for Consolidate.
- **`safety_tier`** is `VARCHAR(8)`, values `{T1,T2,T3}` or NULL — distinct from `risk_tier` (`risk_tier_enum` `1/2/3`).

---

### 3.2 `application_lineage` — 4 columns

Created `030_add_architecture_projection_columns.py:106-135`. Source→target edges for Replace and
Consolidate dispositions. Composite PK, no own id.

| # | column | type | nullable | default | FK (→table.col, ON DELETE) | added-by |
|---|--------|------|----------|---------|----------------------------|----------|
| 1 | `target_app_id` | `UUID` | NO (PK) | — | `→application.id` **ON DELETE CASCADE** | `030:108-113` |
| 2 | `source_app_id` | `UUID` | NO (PK) | — | `→application.id` **ON DELETE CASCADE** | `030:114-119` |
| 3 | `relationship` | `VARCHAR(32)` | NO | — | — | `030:120` |
| 4 | `created_at` | `TIMESTAMPTZ` | NO | `NOW()` | — | `030:121-126` |
| 5 | `retired_at` | `TIMESTAMPTZ` | YES | — | — | `030:127-131` |

**PK:** `application_lineage_pkey` = composite `(target_app_id, source_app_id)` (`030:132-134`).
**Indexes:** `ix_application_lineage_source_app_id` on `(source_app_id)` — `030:138-142`.
**CHECK constraints:** **none** (the `relationship` value-set is enforced in *application code*, not the DB — see writer below). **Unique:** none beyond PK. **JSONB:** none.

**Writer:** `persist_architecture_side_effects` (def `temporal/.../line_transitions-3`, line 3138).
`INSERT INTO application_lineage (target_app_id, source_app_id, relationship, created_at) VALUES ($1,$2,$3,$4) ON CONFLICT (target_app_id, source_app_id) DO NOTHING` with `$4=datetime.now(timezone.utc)` (`regen/03b-activities/line_transitions-3-architecture-data.md:339-343`).
⚠️ **`relationship` whitelist (app-side `_LINEAGE_RELATIONSHIPS`):** `{replace, consolidate, refactor-of, rearchitect-of, replatform-of, retain}` (`…line_transitions-3…:307`). But the four self-disposition values short-circuit to *no edges* (`…:302`), so in practice **only `replace` and `consolidate` ever land rows.** No DB CHECK enforces this — a rebuild that wants the same guarantee must keep it in the writer.
⚠️ **Insert ordering inside the txn:** target `application` row must exist before its lineage edges (FK). For Replace/Consolidate the target row is INSERTed first in the same transaction; source rows are assumed pre-existing (Discovery). A missing source row → FK violation → whole txn rolls back (`…line_transitions-3…:288`).

---

### 3.3 `system` — 9 columns

Created `050_capability_system_grain.py:95-150`. The capability-cohesive layer **above**
`application` (S1..S11 target services; legacy IACRA/RMS/MSS/DMS families). 1 system → 1+ apps.

| # | column | type | nullable | default | FK (→table.col, ON DELETE) | added-by |
|---|--------|------|----------|---------|----------------------------|----------|
| 1 | `id` | `UUID` | NO | `gen_random_uuid()` | PK | `050:97-102` |
| 2 | `portfolio_id` | `UUID` | NO | — | `→portfolio.id` **ON DELETE CASCADE** | `050:103-108` |
| 3 | `name` | `VARCHAR(255)` | NO | — | — | `050:109` |
| 4 | `description` | `TEXT` | YES | — | — | `050:110` |
| 5 | `kind` | `VARCHAR(32)` | NO | — | — (CHECK `system_kind_chk`) | `050:111-121` |
| 6 | `external_id` | `VARCHAR(64)` | YES | — | — | `050:122-132` |
| 7 | `created_at` | `TIMESTAMPTZ` | NO | `now()` | — | `050:133-138` |
| 8 | `updated_at` | `TIMESTAMPTZ` | NO | `now()` | — | `050:139-144` |
| 9 | `retired_at` | `TIMESTAMPTZ` | YES | — | — | `050:145` |

**CHECK constraints:**
- `system_kind_chk`: `kind IN ('legacy', 'target', 'mixed')` (`050:146-149`).

**Indexes:**
- `ix_system_portfolio` on `(portfolio_id)` — `050:151-155`.
- `ix_system_portfolio_external_id` **UNIQUE partial** on `(portfolio_id, external_id) WHERE external_id IS NOT NULL` — `050:158-164`. (NULL external_id allowed and treated distinct.)

**Unique constraints:** only the partial unique index above. **JSONB:** none.

**Writer:** `persist_capability_catalog` (`regen/03b-activities/line_transitions-1-discovery-decomp-capability.md:10,469-493`). `kind` is **always written as literal `'legacy'`** by Discovery (`…:556`). Two UPSERT paths:
- **With external_id:** `INSERT INTO system (portfolio_id, name, kind, description, external_id) VALUES (...,'legacy',...) ON CONFLICT (portfolio_id, external_id) WHERE external_id IS NOT NULL DO UPDATE …` (the `WHERE` MUST match the partial unique index). Blank description never overwrites a richer one via `NULLIF(…,'')`. Race-safe (`…:469-481`).
- **Without external_id:** manual `SELECT id FROM system WHERE portfolio_id=$1 AND name=$2 AND external_id IS NULL LIMIT 1` then INSERT/UPDATE. ⚠️ **Race gotcha:** two concurrent Discovery runs for the same `(portfolio,name)` with NULL external_id can both INSERT → duplicate systems (no unique constraint catches it) (`…:483-493`).

⚠️ Empty-string `external_id` collapses to `None` (forces name-based natural key) (`…:467`).
⚠️ `system_lineage`/`business_domain_lineage` reference `system`/`business_domain` and CASCADE on delete — deleting a `system` cascades to its `capability`, `business_domain`, `system_application`, and `system_lineage` rows (§5).

---

### 3.4 `system_application` — 4 columns (junction, system↔application N:M)

Created `050_capability_system_grain.py:169-208`. Most realizations are 1:1; schema admits N:M.

| # | column | type | nullable | default | FK (→table.col, ON DELETE) | added-by |
|---|--------|------|----------|---------|----------------------------|----------|
| 1 | `system_id` | `UUID` | NO (PK) | — | `→system.id` **ON DELETE CASCADE** | `050:171-176` |
| 2 | `application_id` | `UUID` | NO (PK) | — | `→application.id` **ON DELETE CASCADE** | `050:177-182` |
| 3 | `role` | `VARCHAR(32)` | NO | `'primary'` (string literal) | — (CHECK `system_application_role_chk`) | `050:183-194` |
| 4 | `created_at` | `TIMESTAMPTZ` | NO | `now()` | — | `050:195-200` |

**PK:** `system_application_pkey` = composite `(system_id, application_id)` (`050:201-203`).
**CHECK constraints:**
- `system_application_role_chk`: `role IN ('primary', 'contributing', 'deprecated')` (`050:204-207`).

**Indexes:** `ix_system_application_app` on `(application_id)` — `050:209-213`.
**Unique:** none beyond composite PK. **JSONB:** none.

**Writer:** `persist_capability_catalog`: `INSERT INTO system_application (system_id, application_id, role) VALUES ($1,$2,$3) ON CONFLICT (system_id, application_id) DO UPDATE SET role = EXCLUDED.role` (`regen/03b-activities/line_transitions-1-discovery-decomp-capability.md:495-501`). `role` validated against the CHECK vocabulary; any invalid/absent value → `'primary'` (`…:464-465`).

⚠️ This is the join the per-app **disposition rollup view** (`application_disposition`, §3.9) uses to
reach `capability`-grain dispositions: `capability c JOIN system_application sa ON sa.system_id = c.system_id`.

---

### 3.5 `system_lineage` — 5 columns

Created `050_capability_system_grain.py:555-596`. System-level edge; the architecture-review grain
(G-DA/G-04 reason about this). `application_lineage` is the deployable-unit roll-down.

| # | column | type | nullable | default | FK (→table.col, ON DELETE) | added-by |
|---|--------|------|----------|---------|----------------------------|----------|
| 1 | `target_system_id` | `UUID` | NO (PK) | — | `→system.id` **ON DELETE CASCADE** | `050:557-562` |
| 2 | `source_system_id` | `UUID` | NO (PK) | — | `→system.id` **ON DELETE CASCADE** | `050:563-568` |
| 3 | `relationship` | `VARCHAR(32)` | NO | — | — (CHECK `system_lineage_relationship_chk`) | `050:569-578` |
| 4 | `created_at` | `TIMESTAMPTZ` | NO | `now()` | — | `050:579-584` |
| 5 | `retired_at` | `TIMESTAMPTZ` | YES | — | — | `050:585` |

**PK:** `system_lineage_pkey` = composite `(target_system_id, source_system_id)` (`050:586-590`).
**CHECK constraints:**
- `system_lineage_relationship_chk`: `relationship IN ('consolidate', 'rearchitect-of', 'replace', 'retire')` (`050:591-595`). ⚠️ Note this is a **different value-set** from `application_lineage.relationship` (which is unc'd app-side, and uses `replace/consolidate/refactor-of/rearchitect-of/replatform-of/retain`).

**Indexes:** `ix_system_lineage_source` on `(source_system_id)` — `050:597-601`.
**Unique:** none beyond composite PK. **JSONB:** none.

⚠️ **NO `persist_*` activity writes `system_lineage`** in the workflow projection path. Per
`regen/03b-activities/line_transitions-2-rationalization.md:19,574`, the migration-050 lineage tables
(`system_lineage`, `business_domain_lineage`, `capability_lineage`) have **no activity writer** in the
read range; they are populated only by **seed scripts** (e.g. `scripts/seed_test_portfolio_4_demo_grain.py`,
named in the `050` docstring). Capability *splits* are expressed instead via `capability.parent_capability_id`/`split_at`
(migration `052`), not a lineage table. (DDL must still create the table for behavioral parity.)

---

### 3.6 `business_domain` — 8 columns

Created `050_capability_system_grain.py:319-349`. Coarser business grouping on a system (e.g. "airman
certification", "aeromedical"); holds 1+ capabilities. ⚠️ **NOT to be confused with the
`application.business_domain` VARCHAR(255) column** (`002:84`) — that is a denormalized free-text label;
this is a first-class entity table added in `050`.

| # | column | type | nullable | default | FK (→table.col, ON DELETE) | added-by |
|---|--------|------|----------|---------|----------------------------|----------|
| 1 | `id` | `UUID` | NO | `gen_random_uuid()` | PK | `050:321-326` |
| 2 | `system_id` | `UUID` | NO | — | `→system.id` **ON DELETE CASCADE** | `050:327-332` |
| 3 | `name` | `VARCHAR(255)` | NO | — | — | `050:333` |
| 4 | `description` | `TEXT` | YES | — | — | `050:334` |
| 5 | `external_id` | `VARCHAR(64)` | YES | — | — | `050:335` |
| 6 | `created_at` | `TIMESTAMPTZ` | NO | `now()` | — | `050:336-341` |
| 7 | `updated_at` | `TIMESTAMPTZ` | NO | `now()` | — | `050:342-347` |
| 8 | `retired_at` | `TIMESTAMPTZ` | YES | — | — | `050:348` |

**CHECK constraints:** **none.**
**Indexes:**
- `ix_business_domain_system` on `(system_id)` — `050:350-352`.
- `ix_business_domain_system_external_id` **UNIQUE partial** on `(system_id, external_id) WHERE external_id IS NOT NULL` — `050:353-359`.

**Unique:** only the partial unique index. **JSONB:** none.

**Writer:** `persist_capability_catalog` (manual upsert, NOT using the unique index as conflict target):
`SELECT id FROM business_domain WHERE system_id=$1 AND name=$2` then INSERT `(system_id,name,description,external_id)` RETURNING id, or UPDATE `description = COALESCE(NULLIF($2,''),description), external_id = COALESCE($3, external_id), updated_at=now()` (`regen/03b-activities/line_transitions-1-discovery-decomp-capability.md:506-513`).
⚠️ Lookup is on `(system_id, name)` only — the `external_id` unique index is **not** the conflict target. Concurrent runs can duplicate a domain row (same race caveat as `system` name-path). ⚠️ `COALESCE($3, external_id)` — a null incoming external_id never clears an existing one.

---

### 3.7 `business_domain_lineage` — 9 columns

Created `050_capability_system_grain.py:487-540`. Same shape as `capability_lineage` at the domain grain.

| # | column | type | nullable | default | FK (→table.col, ON DELETE) | added-by |
|---|--------|------|----------|---------|----------------------------|----------|
| 1 | `id` | `UUID` | NO | `gen_random_uuid()` | PK | `050:489-494` |
| 2 | `target_business_domain_id` | `UUID` | **YES** | — | `→business_domain.id` **ON DELETE CASCADE** | `050:495-500` |
| 3 | `source_business_domain_id` | `UUID` | NO | — | `→business_domain.id` **ON DELETE CASCADE** | `050:501-506` |
| 4 | `relationship` | `VARCHAR(32)` | NO | — | — (CHECK `…_relationship_chk`) | `050:507` |
| 5 | `notes` | `TEXT` | YES | — | — | `050:508` |
| 6 | `confidence` | `NUMERIC(3,2)` | YES | — | — | `050:509` |
| 7 | `agent_emitted` | `BOOLEAN` | NO | `false` (string literal) | — | `050:510-515` |
| 8 | `ratified_by` | `VARCHAR(255)` | YES | — | — | `050:516` |
| 9 | `ratified_at` | `TIMESTAMPTZ` | YES | — | — | `050:517` |
| 10 | `created_at` | `TIMESTAMPTZ` | NO | `now()` | — | `050:518-523` |
| 11 | `retired_at` | `TIMESTAMPTZ` | YES | — | — | `050:524` |

(11 physical columns.)

**CHECK constraints:**
- `business_domain_lineage_relationship_chk`: `relationship IN ('absorbed', 'partial', 'transformed', 'dropped')` (`050:530-534`).
- `business_domain_lineage_target_chk`: `(relationship = 'dropped' AND target_business_domain_id IS NULL) OR (relationship <> 'dropped' AND target_business_domain_id IS NOT NULL)` (`050:535-539`). ⚠️ This is why `target_business_domain_id` is **nullable** — `relationship='dropped'` means the source domain retires with no successor (target MUST be NULL); all other relationships REQUIRE a non-NULL target.

**Unique constraints:**
- `business_domain_lineage_target_source_uniq`: UNIQUE `(target_business_domain_id, source_business_domain_id)` (`050:525-529`).

**Indexes:**
- `ix_business_domain_lineage_target` on `(target_business_domain_id)` — `050:541-545`.
- `ix_business_domain_lineage_source` on `(source_business_domain_id)` — `050:546-550`.

**JSONB:** none. **Writer:** none (seed-only; see §3.5 note).

---

### 3.8 `bounded_context` — 8 columns

Created `032_add_modernization_projection_columns.py:152-180`. Per-BC state tracked across the
Generate phase's Ralph-Loop child workflows. Composite PK, no own id.

| # | column | type | nullable | default | FK (→table.col, ON DELETE) | added-by |
|---|--------|------|----------|---------|----------------------------|----------|
| 1 | `target_app_id` | `UUID` | NO (PK) | — | `→application.id` **ON DELETE CASCADE** | `032:154-159` |
| 2 | `bc_name` | `VARCHAR(128)` | NO (PK) | — | — | `032:160` |
| 3 | `status` | `VARCHAR(32)` | NO | — | — (no DB CHECK; app-side whitelist) | `032:161` |
| 4 | `ralph_iterations` | `INTEGER` | YES | — | — | `032:162` |
| 5 | `escalations` | `JSONB` | YES | — | — | `032:163` |
| 6 | `generated_path` | `TEXT` | YES | — | — | `032:164` |
| 7 | `created_at` | `TIMESTAMPTZ` | NO | `NOW()` | — | `032:165-170` |
| 8 | `updated_at` | `TIMESTAMPTZ` | NO | `NOW()` | — | `032:171-176` |

**PK:** `bounded_context_pkey` = composite `(target_app_id, bc_name)` (`032:177-179`).
**CHECK constraints:** **none at DB level.** The `status` lifecycle (`design-complete` → `generate-active` → `generate-complete` | `escalated` | `abandoned`) is documented in the `032` docstring but enforced only by the writer.
**Indexes:** `ix_bounded_context_target_status` on `(target_app_id, status)` — `032:183-187`.
**Unique:** none beyond composite PK.

**JSONB column `escalations` shape** (from writer + `032` docstring): array of escalation records,
each `{iteration, resolution_type, resolution, resolved_at}`. Empty array = zero escalations; NULL =
not yet finalized.

**Writer:** `persist_modernization_side_effects` (3× per target, once per gate G-04a/G-04b/G-04c).
- INSERT: `INSERT INTO bounded_context (target_app_id, bc_name, status, created_at, updated_at) VALUES ($1,$2,$3,$4,$4) ON CONFLICT (target_app_id, bc_name) DO NOTHING` with `$4=datetime.now(timezone.utc)` (`regen/03b-activities/line_transitions-4-modernization-validation.md:324-336`).
- UPDATE: dynamic `UPDATE bounded_context SET status=$3, updated_at=$4 [, ralph_iterations=…][, escalations=…][, generated_path=…] WHERE target_app_id=$1 AND bc_name=$2`; `escalations` value is `json.dumps(update["escalations"])` (`…:337-346`).
⚠️ `ralph_iterations` populated only after the child workflow terminates (NULL for in-flight). `updated_at`/`created_at` are re-stamped on each attempt (`…:53`).

---

### 3.9 `application_disposition` — derived **VIEW** (not a table; per-app disposition rollup)

Not in the covered-table list, but it reads `system_application` + `capability` and is the canonical
per-app disposition projection the dashboard consumes — documented here for completeness.

- **Created** `052_rationalization_capability.py:300-324` (rat-cap grain only): joins
  `capability c JOIN system_application sa ON sa.system_id=c.system_id JOIN rationalization_capability rc ON rc.id=c.rationalization_capability_id AND rc.retired_at IS NULL`, `GROUP BY sa.application_id`, emitting `dispositions[]`, `target_services[]`, `rationalization_capability_ids[]` (all `array_agg(DISTINCT …) FILTER (WHERE … IS NOT NULL)`).
- **Redefined** `058_application_disposition_capability_grain.py:93-138` (`CREATE OR REPLACE`): UNIONs the
  rat-cap grain with a **capability grain** (`primary_disposition`/`secondary_disposition` off `capability` via `system_application`, no rat-cap linkage required) — fixes the empty-donut bug where ATLAS had capability-grain decisions but no rat-cap rows. `target_services`/`rationalization_capability_ids` still come only from the rat-cap grain. `058` downgrade restores the `052` definition verbatim (`058:53-75, 141-143`).
- ⚠️ `058`'s upgrade inlines the SQL as a **string literal** to `op.execute` (not via the module constant) and uses a `FROM (… ) per_app` derived table (not a top-level `WITH`) — both deliberate so `scripts/verify_sql_schema.py` can fold the literal and match the projected outer columns (`058:83-92`).

`application.current_status` allowed-value documentation (the COMMENT from `047:41-52`): canonical set
`{onboarded, discovery_in_progress, rationalization_in_progress, architecture_in_progress,
data_in_progress, modernization_in_progress, validation_in_progress, deployment_in_progress,
sustainment_active, cancelled, consolidated_into_target}` — **no CHECK enforces this; it is free-form VARCHAR(50).**

---

## 4. JSONB column shapes (reproduce exactly)

Shapes are inferred from the `persist_*` activity extractors (authoritative) cross-referenced with
migration docstrings. ⚠️ All are written via `json.dumps(value)` bound as text into the JSONB column.

### 4.1 `application.decomposition_map` (`002:93`)
Writer `persist_decomposition_map` (`regen/03b-activities/line_transitions-1-discovery-decomp-capability.md:67-148`).
Whole dict `json.dumps`'d; missing sub-keys simply absent:
```json
{ "modules": [ { "name": "...", "...": "..." } ],   // kept as-is, NOT deduped (dupes possible)
  "integrations": ["..."],                            // _dedupe_str_list (first-seen order)
  "tech_stack": ["..."] }                             // _dedupe_str_list
```
⚠️ Empty extraction (`{}`) → step COMPLETED, `decomposition_map` stays NULL (full-overwrite UPDATE skipped) (`…:114`).

### 4.2 `application.tech_stack` (`028:76`)
From `catalog.tech_stack` (a dict), persisted only if non-empty. Shape (per `028:16-19` docstring):
```json
{ "languages": [...], "frameworks": [...], "runtimes": [...],
  "databases": [...], "build_tools": [...], "ci_cd": [...] }
```
⚠️ Distinct from `decomposition_map.tech_stack` (a string list). Same column name, different shape/owner.

### 4.3 `application.size_metrics` (`028:80`) — `028:20-23`
```json
{ "loc_total": int, "loc_by_language": {..}, "module_count": int,
  "endpoint_count": int, "table_count": int }
```

### 4.4 `application.architecture` (`028:88`) — `028:27-32`; writer `_extract_structural_side_effects` (`…:260`)
```json
{ "major_components": [...], "integrations": [...] }
```
⚠️ Detailed decomposition requiring code-walk; the one-word `archetype` enum (`021`) stays separate.

### 4.5 `application.business_logic` (`028:92`) — writer `_extract_business_logic_side_effects` (`…:262-268`)
```json
{ "rule_count": int, "critical_rules_count": int }   // critical_rules_count: `critical_count or 0`
```

### 4.6 `application.quality` (`028:96`) — writer `_extract_quality_side_effects` (`…:270-278`)
```json
{ "technical_debt_score": float,
  "test_coverage": float,                              // unweighted mean of per-module scores (docstring says weighted; code averages)
  "vulnerabilities_summary": { "total": int, "by_severity": {"<sev>": int} },  // sev = lowercased verbatim
  "code_smells_summary": { "total": int, "by_type": {"<type>": int} } }
```

### 4.7 `application.tco` (`028:100`) — writer `_extract_tco_side_effects` (`…:292-299`)
```json
{ "annual_total": float, "breakdown": {..}, "formula_applied": str,
  "confidence": "high"|"medium"|"low",                 // defaults "low" ONLY if other tco data present
  "data_sources": [str|int coerced to str] }
```

### 4.8 `application.ux_assessment` (`002:95`) — writer `_extract_ux_side_effects` (`…:280-290`)
Holds ux-accessibility pass projected fields (`personas_count`, `accessibility_score` (0–100 scale),
`ui_complexity_score`, etc.). Whole `assessment` dict persisted if truthy.

### 4.9 `application.portfolio_score` (`024:44`) — writer `_extract_portfolio_score_side_effects` (`regen/03b-activities/line_transitions-2-rationalization.md:490-492`)
⚠️ **The ENTIRE input payload is persisted** (not just `.scores`). Shape (per `024:9-24`): a 6-dimension
readiness vector — each dimension `{score: float[0,100], rationale: str, evidence: [str]}` under keys
`technical_readiness, architectural_readiness, operational_readiness, security_readiness,
user_experience_readiness, business_readiness` (plus whatever else the skill emitted). Persisted only
when `score.scores` is a non-empty dict.

### 4.10 `application.data_domains` (`031:108`) — writer `_extract_data_domains_side_effects` (`regen/03b-activities/line_transitions-3-architecture-data.md:515-518`)
```json
["domain-name", ...]    // list[str], non-empty str entries only, order preserved; column written only if list truthy
```

### 4.11 `application.bounded_contexts` (`032:108`) — writer `_extract_*` (`regen/03b-activities/line_transitions-4-modernization-validation.md:225,234`)
```json
["BC-name", ...]    // list[str]; G-04a from extraction_report.bounded_contexts; G-04b refined from module_map
```

### 4.12 `application.generated_module_refs` (`032:130`) — `…modernization…:249-259`
```json
["modernization/{target_app_id}/generate/{bc_name}/", ...]   // union of per-BC generated_path values
```

### 4.13 `application.metadata` (`051:42`, NOT NULL DEFAULT `'{}'`) — writer `_merge_application_metadata` / `_extract_discovery_compliance_metadata` (`regen/03b-activities/line_transitions-1-discovery-decomp-capability.md:301-320`)
Per-application extensibility slot. The `metadata.compliance` namespace is ALWAYS written on every
successful Discovery run (seeded unconditionally):
```json
{ "compliance": {
    "status": "pending-ato" | "needs-review",       // "needs-review" if accessibility_score < 0.85
    "cato_state": "not-started",
    "source_line": "Discovery",
    "sast_findings_count": int,                        // = len(vulnerabilities)
    "sast_critical_count": int,                        // counts severity in {critical, high}
    "accessibility_score": float                       // 0–1 fraction here (different scale than ux_assessment's 0–100)
  },
  "security": { "sast_findings_count": int, "sbom_signed_at": "..." }  // populated by other line writers
}
```
⚠️ Discovery writes the projection UPDATE and the metadata merge as **two separate `conn.execute`
calls with NO transaction wrapper** — partial state possible if the merge fails after the UPDATE
commits (`…:232`). (Contrast `persist_capability_catalog`, which DOES wrap in `async with conn.transaction()`.)

### 4.14 `application.user_context` / `application.user_impact` (`002:94`, `002:97`)
JSONB, nullable. ⚠️ **No `persist_*` activity in the read range writes these two columns** —
`persist_classification` explicitly lists them among columns it does NOT touch
(`regen/03b-activities/classification.md:352-353`). They are populated (if at all) by other paths
(HCD/user-impact analysis artifacts) or left NULL. Shape: free-form per the originating skill artifact;
not pinned by a DB schema. (DDL must create them as nullable JSONB for parity.)

### 4.15 `bounded_context.escalations` (`032:163`) — see §3.8
```json
[ { "iteration": int, "resolution_type": "...", "resolution": "...", "resolved_at": "..." }, ... ]
```

### 4.16 `rationalization_capability.evidence_refs` (NOT a covered table, but referenced; `052:117-128`)
For completeness (the rat-cap layer feeds the per-app disposition rollup in §3.9):
```json
[ { "capability_id": "...", "application_id": "...", "application_name": "...",
    "capability_name": "...", "citation": "..." }, ... ]
```

---

## 5. Cascade map — mass-delete risk (⚠️)

Every FK below is `ON DELETE CASCADE` unless noted. A single `DELETE FROM portfolio WHERE id=…`
cascades transitively to the **entire** portfolio's hierarchy:

```
portfolio (delete)
 ├─CASCADE→ wave ──CASCADE→ wave_application
 ├─CASCADE→ application ──CASCADE→ wave_application, system_application,
 │                                  application_lineage (target & source),
 │                                  bounded_context, model_override, score_history,
 │                                  traceability_link, chat_message, … (other lines' satellites)
 ├─CASCADE→ system ──CASCADE→ system_application, capability, business_domain,
 │                            system_lineage (target & source)
 │                              └─ business_domain ──CASCADE→ business_domain_lineage (target & source),
 │                                                            capability_business_domain
 └─CASCADE→ rationalization_capability (052)
```

⚠️ **Both** FKs of every lineage/junction table CASCADE — deleting *either* endpoint removes the
edge (e.g. deleting one `application` removes all `application_lineage` rows where it is target OR
source; deleting one `business_domain` removes `business_domain_lineage` rows on either side).

⚠️ **The one ON DELETE exception among `application`'s referrers:** `037`'s sustainment tables include
two FKs to `application.id` with **`ON DELETE SET NULL`** (`037:129`, `037:324`) rather than CASCADE —
those are sustainment-finding/override tables (out of scope here), noted so a rebuild doesn't
over-cascade them. The two columns `037` adds *on* `application` itself (`sustainment_current_status`,
`sustainment_last_sweep_at`) are plain nullable columns, not FKs.

⚠️ `rationalization_capability.wave_id → wave.id` is **ON DELETE SET NULL** (`052:82-86`), not CASCADE
— deleting a wave nulls the rat-cap's wave reference rather than deleting the rat-cap (preserves the
portfolio-scoped gate-decision history).

---

## 6. Per-table column-count ledger (rebuild checklist)

| table | physical columns | PK | CHECKs | unique (excl. PK) | indexes (excl. PK) | JSONB cols | created-in |
|-------|------------------|----|--------|-------------------|--------------------|-----------|------------|
| `portfolio` | 7 | `id` | 0 | 0 | 0 | 0 | `002` |
| `wave` | 16 | `id` | 1 (`wave_status_lifecycle_chk`, 12 values) | 0 | 1 (`ix_wave_workflow_id`) | 0 | `002` |
| `wave_application` | 2 | `(wave_id,application_id)` | 0 | 0 | 0 | 0 | `002` |
| `application` | 82 | `id` | 0 | 0 | 5 (incl. 1 partial) | 15 | `002` |
| `application_lineage` | 5 | `(target_app_id,source_app_id)` | 0 | 0 | 1 | 0 | `030` |
| `system` | 9 | `id` | 1 (`system_kind_chk`) | 1 (partial) | 2 (1 partial-unique) | 0 | `050` |
| `system_application` | 4 | `(system_id,application_id)` | 1 (`system_application_role_chk`) | 0 | 1 | 0 | `050` |
| `system_lineage` | 5 | `(target_system_id,source_system_id)` | 1 (`system_lineage_relationship_chk`) | 0 | 1 | 0 | `050` |
| `business_domain` | 8 | `id` | 0 | 1 (partial) | 2 (1 partial-unique) | 0 | `050` |
| `business_domain_lineage` | 11 | `id` | 2 (`…_relationship_chk`, `…_target_chk`) | 1 (`…_target_source_uniq`) | 2 | 0 | `050` |
| `bounded_context` | 8 | `(target_app_id,bc_name)` | 0 | 0 | 1 (`ix_bounded_context_target_status`) | 1 (`escalations`) | `032` |

**`application` JSONB columns — all 15 (physically JSONB-typed):**
`decomposition_map(002), user_context(002), ux_assessment(002), user_impact(002), portfolio_score(024),
tech_stack(028), size_metrics(028), architecture(028), business_logic(028), quality(028), tco(028),
data_domains(031), bounded_contexts(032), generated_module_refs(032), metadata(051)`.
Of these, the canonical `_JSONB_COLUMNS` serialization set used by the shared `_build_update_sql`
projection path is 11: `{tech_stack, size_metrics, architecture, business_logic, quality, ux_assessment,
tco, portfolio_score, data_domains, bounded_contexts, generated_module_refs}`. The other 4
(`decomposition_map, user_context, user_impact, metadata`) are JSONB-typed but written by dedicated
paths (or not written by any activity, in the case of `user_context`/`user_impact`).

---

## 7. Undetermined / cross-file

1. **`system_lineage`, `business_domain_lineage`** (and the uncovered `capability_lineage`): DDL exists
   (`050`) but **no Temporal `persist_*` activity writes them** in the activity specs read. They are
   seed-script-only (e.g. `scripts/seed_test_portfolio_4_demo_grain.py`, per `050` docstring). The exact
   seed payloads were not inspected here — see the seeds spec. DDL above is sufficient for schema parity.
2. **`application.user_context` / `application.user_impact`** JSONB shapes are not pinned by any persist
   activity in scope (no writer found); their internal structure depends on the HCD/user-impact skill
   artifacts. Reproduced as nullable JSONB.
3. The exact `application` JSONB count is **15** (the §6 table's "13" is an undercount; reconciled in the
   note beneath §6). All other counts in §6 were re-derived from the migration source and are firm.
