# Regen 04 — Data Layer: Orchestration State Tables

> ATOMIC regeneration spec. Bar = **behavioral parity**: each table below must be
> rebuildable EXACTLY, column-by-column, constraint-by-constraint, across the full
> 56-migration history (`/Users/pnunna/Documents/GitHub/foundry/db/alembic/versions/`).
> When in doubt, OVER-specify.
>
> **Scope (11 tables):** `gate`, `escalation`, `agent_task`, `agent_task_session_artifact`,
> `step_execution`, `workflow_signal_inbox`, `arch_data_signal_registry`, `score_history`,
> `gate_approval`, `design_annotation`, `interview_session`.
> These are the orchestration/state-projection tables that back gate review, escalation
> triage, agent telemetry, the Layer-B step-execution envelope, durable signal queues, the
> Arch↔Data handshake registry, score history, RBAC multi-approval (`gate_approval`),
> standalone design-artifact review (`design_annotation`), and the asynchronous Requirements
> Interview (`interview_session`). The last three are routed here by the spine §6c (`04-data-layer.md`).
>
> **Cross-references:**
> - Activity projection writers: `/Users/pnunna/Documents/GitHub/foundry/regen/03b-activities/`
>   (`gate_operations.md`, `agent_dispatch.md`, `arch_data_registry.md`,
>   `line_transitions-0-helpers-decorator.md`).
> - Sibling table specs (core/projection `application`, `wave`, etc.) live in adjacent regen-04 files.

---

## 0. Foundational facts (read first)

### 0.1 Git-as-source-of-truth + projection model

DECISION-004 / CLAUDE.md core-principle #4: **Git is the source of truth; PostgreSQL is a
derived, disposable query layer.** Every row in these tables is a *projection* of a Git
artifact (or of Temporal workflow state) written by an activity (the `persist_*` / `_insert_*`
/ `_update_*` / `emit_execution_record` family) or by an API service handler. The DB can be
dropped and rebuilt: migrations create the empty schema, then re-running the workflows
(or re-projecting committed artifacts) repopulates rows. No row here is canonical state —
the workflow keys real state on its event history and on committed artifacts, not on row
identity. This is why several inserts are **non-idempotent across Temporal retries** (each
retry generates a fresh `uuid.uuid4()` and inserts a *new* row); telemetry duplication is
explicitly accepted (`agent_dispatch.md:559`, `gate_operations.md:666`).

Two write surfaces touch these tables:
1. **Temporal activities** (in `temporal/olympus_workflows/activities/…`, reproduced in
   `regen/03b-activities/`). These open their own `asyncpg` connection, are **best-effort**
   (a DB failure logs a warning and never changes the activity result), and use raw SQL.
2. **API service / router handlers** (`olympus-api/src/…`). These use SQLAlchemy
   `AsyncSession` + `text(...)` raw SQL; transaction boundary controlled by the caller.

### 0.2 Conventions used in the column tables

- **type** — the PostgreSQL type the migration emits. `UUID` = `postgresql.UUID(as_uuid=True)`.
  `JSONB` = `postgresql.JSONB`. `timestamptz` = `DateTime(timezone=True)` / `TIMESTAMP(timezone=True)`
  (both render `TIMESTAMP WITH TIME ZONE`). `String(N)` = `VARCHAR(N)`. `Text` = `TEXT`.
  `Numeric` (no args) = `NUMERIC` (unbounded). `Numeric(3,2)` = `NUMERIC(3,2)`.
  `BigInteger` = `BIGINT`. `Integer` = `INTEGER`. `Boolean` = `BOOLEAN`.
- **nullable** — `NO` = `nullable=False`; `YES` = `nullable=True`.
- **default** — server default literal. `gen_random_uuid()` requires the `pgcrypto`/
  `pg_catalog` function (Postgres 13+ has it built-in). `now()` = `CURRENT_TIMESTAMP`.
- **FK** — `→ table.col (ON DELETE …)`. All FKs here use the implicit `ON UPDATE NO ACTION`
  (PostgreSQL default; no migration sets `onupdate`). Only `ON DELETE` is ever specified.
- **added-by** — migration file (`NNN_*.py`) and `op.create_table`/`op.add_column` line.

### 0.3 ⚠️ Enum→varchar pattern (the "flexibility" choice)

Olympus deliberately uses **two different styles** for constrained string columns:
- **PG ENUM types** (`gate_type_enum`, `gate_status_enum`, `task_status_enum`,
  `escalation_*_enum`, `step_execution_kind_enum`, `step_execution_status_enum`) — created in
  migration `001` (or inside `033` for the step_execution pair). Extending these requires a
  **non-transactional `ALTER TYPE … ADD VALUE`** (see §1.4, §0.4).
- **VARCHAR/TEXT + CHECK constraint** — chosen when "Phase-3 implementers can refine without
  forcing an `ALTER TYPE`" (`020:14-16`). Examples in scope: `gate.reject_reason_category`
  (TEXT, validated only in API Pydantic, **no DB CHECK**); `agent_task.actor_kind`
  (VARCHAR(32) + CHECK); `agent_task.provider_name` (VARCHAR(64), **no CHECK**);
  `step_execution.workflow_id` etc. (plain VARCHAR); `workflow_signal_inbox.status`
  (VARCHAR(32) + CHECK); `arch_data_signal_registry.signal_type` (**TEXT, no DB CHECK** —
  validated in the publish activity, `arch_data_registry.md:83`);
  `agent_task_session_artifact.kind` (VARCHAR(32) + CHECK).

  ⚠️ **None of the in-scope tables performed an in-place enum→varchar *migration* of an
  existing column.** The two styles coexist from creation. (The repo-wide "flexibility
  migration" that converted `application.disposition`/`current_status` etc. from enum to
  varchar+CHECK is migration `050`/`052`/`058` territory and touches `application`/`wave`,
  documented in the sibling core-tables regen spec — it does **not** alter any of this file's
  tables' enum columns.) For the enum-bearing tables in this file the enum columns stay
  PG-ENUM-typed forever; the only mutations are `ADD VALUE` appends to `gate_status_enum`. (The
  three later-added tables — `gate_approval` §12, `design_annotation` §13, `interview_session`
  §14 — use **no PG enum** at all: `gate_approval` is all-scalar; `design_annotation.action` and
  `interview_session.status`/`phase` are VARCHAR/TEXT/INTEGER + CHECK, born loose from creation.)

### 0.4 ⚠️ Non-transactional `ADD VALUE` ordering (gate_status_enum)

`gate_status_enum` is the only in-scope enum that grows after creation. PostgreSQL appends
`ADD VALUE` to the **end** of the value list (no positional `BEFORE`/`AFTER` is used), and
`ALTER TYPE … ADD VALUE` **cannot run inside a transaction block that also uses the value**
(it's why each lives in its own migration). The **final ordered value set** and the migration
that added each:

| ordinal | value | added-by |
|---|---|---|
| 1 | `pending` | `001:56-58` (base) |
| 2 | `approved` | `001:56-58` (base) |
| 3 | `rejected` | `001:56-58` (base) |
| 4 | `overridden` | `001:56-58` (base) |
| 5 | `escalated` | `013:21` `ADD VALUE IF NOT EXISTS 'escalated'` |
| 6 | `preparing` | `019:24` `ADD VALUE IF NOT EXISTS 'preparing'` |
| 7 | `merge_blocked` | `040:48-50` `ADD VALUE IF NOT EXISTS 'merge_blocked'` |

⚠️ **Regeneration ordering is load-bearing.** If you collapse the schema into a single
`CREATE TYPE`, you MUST list these 7 values in this order to preserve `enum_first`/sort
ordering parity. If you keep the migration sequence, each `ADD VALUE` must remain in its own
migration (013, 019, 040) and use `IF NOT EXISTS` (idempotent re-runs in test DBs). All three
downgrades are no-ops — PostgreSQL cannot remove enum values (`013:25-26`, `019:27-28`,
`040:59-62`).

The other enums never grow after their `CREATE TYPE` and are reproduced inline per table below.

---

## 1. `gate` — gate-review state (15 columns)

**Created:** `003_create_workflow_tables.py:62-79` (`op.create_table("gate", …)`).
**Touched by:** 003 (create), 005 (indexes), 011 (+3 cols), 012 (+evidence_data),
013/019/040 (enum ADD VALUE), 020 (+reject_reason_category), 040 (+merge_failure_detail),
042 (wave-scoping: nullable app + wave_id + CHECK + index), 062 (+3 RBAC cols).
(`014` and `033` reference "gate" only as a non-FK string column on other tables — they do
**not** alter `gate`.)

### 1.1 Columns (column | type | nullable | default | FK | added-by)

| # | column | type | nullable | default | FK (ON DELETE) | added-by |
|---|---|---|---|---|---|---|
| 1 | `id` | UUID | NO (PK) | `gen_random_uuid()` | — | `003:64-65` |
| 2 | `gate_type` | `gate_type_enum` | NO | — | — | `003:66` |
| 3 | `portfolio_id` | UUID | NO | — | → `portfolio.id` (**CASCADE**) | `003:67-68` |
| 4 | `application_id` | UUID | **YES** (was NO; relaxed by 042) | — | → `application.id` (**CASCADE**) | `003:69-70`; nullable @ `042:49` |
| 5 | `status` | `gate_status_enum` | NO | `'pending'` | — | `003:71-72` |
| 6 | `requested_at` | timestamptz | NO | `now()` | — | `003:73-74` |
| 7 | `decided_at` | timestamptz | YES | — | — | `003:75` |
| 8 | `decided_by` | VARCHAR(255) | YES | — | — | `003:76` |
| 9 | `justification` | TEXT | YES | — | — | `003:77` |
| 10 | `retry_count` | INTEGER | NO | `0` | — | `003:78` |
| 11 | `workflow_id` | VARCHAR(255) | YES | — | — | `011:22-25` |
| 12 | `sla_deadline` | timestamptz | YES | — | — | `011:26-29` |
| 13 | `evidence_package_url` | TEXT | YES | — | — | `011:30-33` |
| 14 | `evidence_data` | JSONB | YES | — | — | `012:23-26` |
| 15 | `reject_reason_category` | TEXT | YES | — | — | `020:30-33` |
| 16 | `merge_failure_detail` | JSONB | YES | — | — | `040:53-56` |
| 17 | `wave_id` | UUID | YES | — | → `wave.id` (**CASCADE**) | `042:52-60` |
| 18 | `minimum_approvals` | INTEGER | NO | `1` | — | `062:123-132` |
| 19 | `oversight_role` | VARCHAR(64) | YES | — | — | `062:133-141` |
| 20 | `management_override_allowed` | BOOLEAN | NO | `true` | — | `062:142-154` |

> ⚠️ **Final column count = 20** (table started with 10; +3 from 011, +1 from 012, +1 from
> 020, +1 from 040, +1 from 042, +3 from 062). The "15 columns" in the section title refers to
> the originally-modeled gate; the migrated total is 20.
>
> ⚠️ **`application_id` nullable surprise.** Created `NOT NULL` (`003:69`), relaxed to nullable
> by `042:49` (`op.alter_column("gate","application_id",nullable=True)`) so wave-scoped gates
> (G-RR/G-DA) can carry `wave_id` instead. The exactly-one rule is enforced by the CHECK in
> §1.2. A naïve `CREATE TABLE` regeneration MUST emit `application_id … NULL`.
>
> ⚠️ **`status` default vs. activity insert.** Column default is `'pending'` (`003:72`), but
> `create_gate_record` **always inserts the literal `'preparing'`** (`gate_operations.md:619,650`),
> never relying on the default. So a freshly created gate row's `status` is `preparing`, not
> `pending`. The default only applies to a hypothetical insert that omits `status` (no code path
> does this).

### 1.2 CHECK constraints (full value sets)

- **`gate_application_or_wave_ck`** — added `042:63-68`. Full predicate (reproduce verbatim):
  ```
  (application_id IS NOT NULL AND wave_id IS NULL)
  OR (application_id IS NULL AND wave_id IS NOT NULL)
  ```
  Exactly one of `application_id` / `wave_id` must be populated. Mirrored in-process by
  `create_gate_record`'s `bool(app_id) == bool(wave_id)` raise (`gate_operations.md:600-604`)
  — both-empty AND both-set both raise. Drop type = `check` (`042:78`).

> ⚠️ **`gate.reject_reason_category` has NO DB CHECK** (`020:14-16` — "stored as plain TEXT
> (not an enum) so Phase 3 implementers can refine per-gate without forcing an ALTER TYPE.
> Validation lives in the API layer (Pydantic `Literal`)"). Do not add a CHECK on
> regeneration — that would diverge.
>
> ⚠️ **No CHECK** on `gate_type`/`status` beyond the enum type constraint itself.

### 1.3 Indexes & unique constraints

| name | columns | kind / predicate | added-by |
|---|---|---|---|
| (PK) | `id` | primary key | `003:64` |
| `ix_gate_status` | `status` | btree | `005:33-34` |
| `ix_gate_application_id` | `application_id` | btree | `005:35-36` |
| `ix_gate_gate_type` | `gate_type` | btree | `005:37-38` |
| `ix_gate_wave_id` | `wave_id` | btree | `042:71` |

No unique constraints on `gate` (the PK is the only uniqueness). FK indexes on
`portfolio_id`/`wave_id` are explicit (wave_id) or implicit via app/portfolio FKs.

### 1.4 Enum types referenced

- `gate_type_enum` — 15 values, FROZEN (never extended): `'G-DC','G-RR','G-DA','G-02','G-DT',
  'G-04a','G-04b','G-04c','G-DE-1','G-DE-2','G-V1','G-V2','G-V3','G-DP-1','G-DP-2'`
  (`001:46-53`).
- `gate_status_enum` — 7 values, see §0.4 for the ordered set + per-value migration.

### 1.5 JSONB column shapes

**`evidence_data` (JSONB, nullable).** Written by `submit_gate_evidence`
(`gate_operations.md:486-524`) — `UPDATE gate SET evidence_data = $1::jsonb,
evidence_package_url = $2 …` where `$1 = json.dumps(input.evidence_data)`. ⚠️ The UPDATE fires
**only when `input.evidence_data` is truthy** (None or empty `{}` → skipped → pure no-op to the
DB; `gate_operations.md:486,522`). The whole bundle is overwritten (no merge), so re-running is
idempotent. Shape (`gate_operations.md:354`, and the W8 review block from `models/gate.py`):

```json
{
  "steps": {
    "<step_name>": {
      "file_artifacts": [
        { "path": "string", "content": "string (JSON-encoded contents)" }
      ],
      "output": "string",
      "...": "additional step fields"
    }
  },
  "review": {
    "card_decisions": [
      { "...": "per-card reviewer decision (CardDecision shape)" }
    ],
    "...": "reviewer_notes / sort_applied / bulk_approved as supplied"
  },
  "rationalization_capabilities": [ "...row-level rework items surfaced at G-RR/G-DA" ]
}
```
- `steps` is iterated by `.values()`; "first matching file_artifact by path-suffix" is
  deterministic but tied to dict insertion order (`gate_operations.md:302`). The gate
  pre-review activity (`gate_pre_review.md`) is the primary writer of `steps`; the W8
  card-per-check decision path persists to `evidence_data.review.card_decisions`
  (`models/gate.py:434,480`); G-RR/G-DA capability-lineage rework reads from
  `evidence_data.rationalization_capabilities` (`models/gate.py:324`).

**`merge_failure_detail` (JSONB, nullable).** Written by `set_gate_merge_blocked`
(`gate_operations.md:689-696`) — `UPDATE gate SET status='merge_blocked',
merge_failure_detail = $1::jsonb` where `$1 = json.dumps(detail_dict)`, `detail_dict =
dict(failure_detail) if failure_detail else {}` (falsy → `{}`). Stored **verbatim**, the
activity does not validate/reshape. Shape (strategy doc §3.7, `models/gate.py:80-84,103`,
`gate_operations.md:681`):

```json
{
  "reason": "string",
  "failure_type": "MergeConflict | MergeBranchProtectionRejected | MergeDivergenceUnresolved",
  "conflicting_files": ["string"],   // optional
  "base_sha": "string",              // optional
  "head_sha": "string",              // optional
  "detected_at": "ISO-8601 string"
}
```
⚠️ `decided_at`/`decided_by` are **left untouched** by this UPDATE (the reviewer's approval is
preserved); only `status` flips and `merge_failure_detail` is set (`gate_operations.md:712`).

### 1.6 Insert/update projection map (create_gate_record → gate)

`create_gate_record` (`gate_operations.md:615-629`) INSERTs **10 columns**, the rest default/NULL:

| source | → gate column | placeholder | note |
|---|---|---|---|
| `uuid.uuid4()` (client-side) | `id` | `$1` | NOT `gen_random_uuid()` — returned id must equal PK |
| `input.app_id`→`app_uuid` | `application_id` | `$2` | `None` when wave-scoped → NULL |
| `input.wave_id`→`wave_uuid` | `wave_id` | `$3` | `None` when app-scoped → NULL |
| `input.portfolio_id` | `portfolio_id` | `$4::uuid` | required |
| `input.gate_type` (str) | `gate_type` | `$5` | raw code, implicit cast to enum |
| literal `'preparing'` | `status` | inline | ⚠️ ALWAYS `'preparing'` (not the `'pending'` default) |
| `input.workflow_id` | `workflow_id` | `$6` | |
| `now` (UTC) | `requested_at` | `$7` | in-process `datetime.now(timezone.utc)` |
| `now + sla_timeout_seconds` | `sla_deadline` | `$8` | `timedelta(seconds=…)` |
| `input.evidence_package_url` | `evidence_package_url` | `$9` | default `""` |

NOT written (default/NULL): `decided_at`(NULL), `decided_by`(NULL), `justification`(NULL),
`retry_count`(DEFAULT 0), `evidence_data`(NULL), `reject_reason_category`(NULL),
`merge_failure_detail`(NULL), `minimum_approvals`(DEFAULT 1), `oversight_role`(NULL),
`management_override_allowed`(DEFAULT true) (`gate_operations.md:656`).
⚠️ **NOT idempotent** across Temporal retries — fresh `uuid.uuid4()` each run, no `ON CONFLICT`
(`gate_operations.md:666`).

---

## 2. `escalation` — escalation triage state (20 columns)

**Created:** `003_create_workflow_tables.py:109-135` (`op.create_table("escalation", …)`).
**Touched by:** 003 (create), 005 (indexes). **No later migration alters this table.**

### 2.1 Columns

| # | column | type | nullable | default | FK (ON DELETE) | added-by |
|---|---|---|---|---|---|---|
| 1 | `id` | UUID | NO (PK) | `gen_random_uuid()` | — | `003:111-112` |
| 2 | `type` | `escalation_type_enum` | NO | — | — | `003:113` |
| 3 | `severity` | `escalation_severity_enum` | NO | — | — | `003:114` |
| 4 | `application_id` | UUID | NO | — | → `application.id` (**CASCADE**) | `003:115-116` |
| 5 | `line` | `assembly_line_enum` | YES | — | — | `003:117` |
| 6 | `step` | VARCHAR(100) | YES | — | — | `003:118` |
| 7 | `skill` | VARCHAR(100) | YES | — | — | `003:119` |
| 8 | `agent` | VARCHAR(255) | YES | — | — | `003:120` |
| 9 | `trigger_type` | VARCHAR(100) | YES | — | — | `003:121` |
| 10 | `trigger_details` | JSONB | YES | — | — | `003:122` |
| 11 | `status` | `escalation_status_enum` | NO | `'open'` | — | `003:123-124` |
| 12 | `resolver` | VARCHAR(255) | YES | — | — | `003:125` |
| 13 | `resolution_type` | VARCHAR(100) | YES | — | — | `003:126` |
| 14 | `resolution` | JSONB | YES | — | — | `003:127` |
| 15 | `pattern_extracted` | BOOLEAN | NO | `false` | — | `003:128-129` |
| 16 | `pattern_id` | VARCHAR(255) | YES | — | — | `003:130` |
| 17 | `created_at` | timestamptz | NO | `now()` | — | `003:131-132` |
| 18 | `updated_at` | timestamptz | NO | `now()` | — | `003:133-134` |

> Final column count = **18**. ⚠️ `application_id` is **NOT NULL** here (escalations are always
> app-scoped — unlike `gate`/`agent_task`, escalation was never wave-scoped; no migration 042/044
> analog exists).

### 2.2 CHECK constraints

**None.** `escalation` has zero CHECK constraints — all three enum columns (`type`, `severity`,
`status`) are PG ENUM types, and `resolution_type` is a plain VARCHAR(100) with no DB CHECK
(validation lives only in the API: `EscalationResolveRequest.resolution_type` is a Pydantic
`Literal["Re-Extract","Manual Augment","Re-Disposition"]`, `escalations.py:92`).

### 2.3 Indexes & unique constraints

| name | columns | added-by |
|---|---|---|
| (PK) | `id` | `003:111` |
| `ix_escalation_status` | `status` | `005:56-57` |
| `ix_escalation_application_id` | `application_id` | `005:58-59` |

No unique constraints.

### 2.4 Enum types referenced (all FROZEN — never extended)

- `escalation_type_enum` — `'Technical','Domain','Strategic','Safety','Infrastructure'` (`001:82-86`).
- `escalation_severity_enum` — `'Critical','Standard','Low'` (`001:88-92`).
- `escalation_status_enum` — `'open','investigating','resolved'` (`001:76-80`).
- `assembly_line_enum` (for `line`) — `'Discovery','Rationalization','Architecture','Data',
  'Modernization','Disposition Execution','Validation','Deployment','Sustainment','Governance'`
  (`001:61-67`).

### 2.5 JSONB column shapes

**`trigger_details` (JSONB, nullable).** Free-form context about what tripped the escalation.
Surfaced verbatim by the API (`EscalationDetail.trigger_details: dict[str,Any] = {}`,
`escalations.py:86`; reader coerces non-dict → `{}`, `escalations.py:122-124`). No fixed schema
is enforced; the row's flat columns `line`/`step`/`skill`/`agent`/`trigger_type` carry the
typed context (assembled into the response `context` dict, `escalations.py:126-134`).

**`resolution` (JSONB, nullable).** Written by `POST /escalations/{id}/resolve`
(`escalations.py:339-358`) — `UPDATE escalation SET status='resolved', resolver=:resolver,
resolution_type=:resolution_type, resolution=CAST(:resolution AS JSONB), updated_at=:now`.
Shape is fixed by `resolution_payload` (`escalations.py:334-337`):

```json
{
  "resolution_type": "Re-Extract | Manual Augment | Re-Disposition",
  "details": "string (free-text reviewer detail)"
}
```
On read, `EscalationResolution` is hydrated from this blob plus row columns: `resolution_type`
falls back row-col → blob → `""`; `details = str(blob.details or "")`; `resolved_by =
resolver`; `resolved_at = updated_at`; `pattern_extracted` from the row column
(`escalations.py:110-120`). ⚠️ Re-resolving a row already at `status='resolved'` → **409
Conflict** (`escalations.py:326-331`), so the blob is never silently overwritten.

> ⚠️ **No `INSERT INTO escalation` exists in the app or activity code.** Escalation rows are
> created by **seed scripts** (`scripts/seed_demo_faa.py`, `seed_data.py`, `seed_atlas_challenge.py`,
> `seed_modernization_corpus.py` — each does `DELETE FROM escalation …` then bulk-inserts via the
> seed harness) and read by `insights.py` (decisions timeline, `insights.py:683-716`) and the
> `escalations.py` router. The runtime-created escalation path is the **gate escalate** action
> (`gates.py` / `services/gate.py`) which records escalation context; resolution flows through
> `resolve_escalation`. For regeneration parity the table shape above is authoritative; seed
> contents are documented in the seeds regen spec.

---

## 3. `agent_task` — agent dispatch + performance telemetry (final: 36 columns)

**Created:** `003_create_workflow_tables.py:82-106` (`op.create_table("agent_task", …)`).
**Touched by:** 003 (create, 19 cols), 005 (indexes), 027 (+11 perf/metric cols + 5 indexes +
`agent_benchmark` view + started_at backfill), 044 (wave-scoping: nullable app + wave_id + CHECK
+ index), 050 (+3 actor-grain cols + 2 CHECKs + creates `agent_task_session_artifact`),
064 (+2 provider cols).

### 3.1 Columns

| # | column | type | nullable | default | FK (ON DELETE) | added-by |
|---|---|---|---|---|---|---|
| 1 | `id` | UUID | NO (PK) | `gen_random_uuid()` | — | `003:84-85` |
| 2 | `task_type` | VARCHAR(100) | NO | — | — | `003:86` |
| 3 | `application_id` | UUID | **YES** (was NO; relaxed by 044) | — | → `application.id` (**CASCADE**) | `003:87-88`; nullable @ `044:55` |
| 4 | `module_name` | VARCHAR(255) | YES | — | — | `003:89` |
| 5 | `status` | `task_status_enum` | NO | `'queued'` | — | `003:90-91` |
| 6 | `agent_backend` | VARCHAR(100) | YES | — | — | `003:92` |
| 7 | `agent_session_id` | VARCHAR(255) | YES | — | — | `003:93` |
| 8 | `model_requested` | VARCHAR(100) | YES | — | — | `003:94` |
| 9 | `model_used` | VARCHAR(100) | YES | — | — | `003:95` |
| 10 | `model_source` | VARCHAR(100) | YES | — | — | `003:96` |
| 11 | `dispatched_at` | timestamptz | YES | — | — | `003:97` |
| 12 | `completed_at` | timestamptz | YES | — | — | `003:98` |
| 13 | `duration_ms` | BIGINT | YES | — | — | `003:99` |
| 14 | `retry_count` | INTEGER | NO | `0` | — | `003:100` |
| 15 | `last_error` | TEXT | YES | — | — | `003:101` |
| 16 | `input_artifact_refs` | JSONB | YES | — | — | `003:102` |
| 17 | `output_artifact_ref` | TEXT | YES | — | — | `003:103` |
| 18 | `token_usage` | JSONB | YES | — | — | `003:104` |
| 19 | `cost_estimate` | NUMERIC | YES | — | — | `003:105` |
| 20 | `agent_id` | VARCHAR(100) | YES | — | — | `027:117-120` |
| 21 | `skill_id` | VARCHAR(150) | YES | — | — | `027:121-124` |
| 22 | `workflow_id` | VARCHAR(255) | YES | — | — | `027:125-128` |
| 23 | `started_at` | timestamptz | YES | — | — | `027:129-136` |
| 24 | `input_tokens` | INTEGER | YES | — | — | `027:137-140` |
| 25 | `output_tokens` | INTEGER | YES | — | — | `027:141-144` |
| 26 | `cache_read_tokens` | INTEGER | YES | — | — | `027:145-148` |
| 27 | `cache_write_tokens` | INTEGER | YES | — | — | `027:149-152` |
| 28 | `quality_score` | NUMERIC(3,2) | YES | — | — | `027:153-156` |
| 29 | `error_code` | VARCHAR(100) | YES | — | — | `027:157-160` |
| 30 | `artifact_id` | UUID | YES | — | — (FK-less link, per docstring `027:35`) | `027:161-164` |
| 31 | `wave_id` | UUID | YES | — | → `wave.id` (**CASCADE**) | `044:58-66` |
| 32 | `actor_kind` | VARCHAR(32) | NO | `'olympus_agent'` | — | `050:606-619` |
| 33 | `human_user_id` | VARCHAR(255) | YES | — | — (FK-less; user table may not exist yet) | `050:620-632` |
| 34 | `local_agent_descriptor` | JSONB | YES | — | — | `050:633-646` |
| 35 | `provider_name` | VARCHAR(64) | YES | — | — | `064:38-41` |
| 36 | `provider_fallback_from` | VARCHAR(64) | YES | — | — | `064:42-45` |

> Final column count = **36** (19 from 003, +11 from 027, +1 from 044, +3 from 050, +2 from 064).
>
> ⚠️ **`application_id` nullable surprise.** Created `NOT NULL` (`003:87`), relaxed to nullable by
> `044:55` so wave-scoped telemetry rows carry `wave_id`. Exactly-one rule = CHECK §3.2.
>
> ⚠️ **`agent_id` ≠ `model_used` ≠ `agent_backend` ≠ `provider_name`.** Four distinct identity
> dimensions: `agent_id` = canonical agent identity (rollup grain, e.g. `claude-opus-4-7`);
> `model_used` = Bedrock model arn; `agent_backend` = provider/runtime tag; `provider_name` =
> resolved composite provider id (e.g. `bedrock-claude`/`openai`, `064:18-20`). `skill_id` is a
> **string match, not an FK** (`027:22`).
>
> ⚠️ **027 data backfill.** `027:173-177` runs `UPDATE agent_task SET started_at = dispatched_at
> WHERE started_at IS NULL AND dispatched_at IS NOT NULL` — a one-shot column initialization
> (explicitly allowed by the seeding-separation rule). On a fresh empty regeneration this is a
> no-op, but it MUST be present in the migration body for replay parity.

### 3.2 CHECK constraints (full predicates)

- **`agent_task_application_or_wave_ck`** — added `044:69-73`:
  ```
  (application_id IS NOT NULL AND wave_id IS NULL)
  OR (application_id IS NULL AND wave_id IS NOT NULL)
  ```
- **`agent_task_actor_kind_chk`** — added `050:647-650`:
  ```
  actor_kind IN ('olympus_agent', 'human', 'human_with_agent')
  ```
- **`agent_task_actor_kind_human_id_chk`** — added `050:654-659`:
  ```
  (actor_kind = 'olympus_agent' AND human_user_id IS NULL)
  OR (actor_kind IN ('human', 'human_with_agent') AND human_user_id IS NOT NULL)
  ```
  (DB-level guard so a bug can't write a `human` row without an identity, `050:652-653`.)

> ⚠️ **`provider_name`/`provider_fallback_from` have NO CHECK** (`064:13` — additive nullable,
> attribution via analytics-layer COALESCE, no constraint). Do not add one.

### 3.3 Indexes & unique constraints

| name | columns | kind / predicate | added-by |
|---|---|---|---|
| (PK) | `id` | primary key | `003:84` |
| `ix_agent_task_status` | `status` | btree | `005:41-42` |
| `ix_agent_task_application_id` | `application_id` | btree | `005:43-44` |
| `ix_agent_task_task_type` | `task_type` | btree | `005:45-46` |
| `ix_agent_task_agent_started` | `agent_id`, `started_at DESC` | btree (expr) | `027:180-184` |
| `ix_agent_task_skill_started` | `skill_id`, `started_at DESC` | btree (expr) | `027:185-189` |
| `ix_agent_task_workflow_id` | `workflow_id` | btree | `027:190-194` |
| `ix_agent_task_app_started` | `application_id`, `started_at DESC` | btree (expr) | `027:195-199` |
| `ix_agent_task_started_at` | `started_at DESC` | btree (expr) | `027:200-204` |
| `ix_agent_task_wave_id` | `wave_id` | btree | `044:77` |

No unique constraints. 064 adds **no index** (`064:22-23` — provider aggregation rides an
existing full-table scan).

### 3.4 Enum type referenced

- `task_status_enum` — 6 values, FROZEN: `'queued','dispatched','running','completed','failed',
  'timed_out'` (`001:69-74`).

### 3.5 `agent_benchmark` VIEW (created by 027)

A **non-materialized** SQL view `CREATE OR REPLACE VIEW agent_benchmark` grouping `agent_task`
by `(agent_id, skill_id)` where `agent_id IS NOT NULL` (`027:72-112`). Exposed aggregates (full
list, must be reproduced exactly for parity of downstream reads): `sample_count`,
`terminal_count` (status IN completed/failed/timed_out), `success_count`, `failure_count`,
`timeout_count`, `success_rate` (NULL when terminal_count=0 else completed/terminal),
`avg_duration_ms`, `p50_duration_ms` (`percentile_cont(0.5)`), `p95_duration_ms`
(`percentile_cont(0.95)`), `avg_input_tokens`, `avg_output_tokens`, `avg_quality_score`,
`total_cost_estimate`, `avg_cost_estimate`, `first_seen_at` (MIN started_at), `last_seen_at`
(MAX started_at). Promote to a matview only past ~10M rows (`027:50-51`). Dropped on downgrade
(`027:211`).

### 3.6 JSONB column shapes

**`input_artifact_refs` (JSONB, nullable).** Written by `_insert_agent_task_row`
(`agent_dispatch.md:183-205`) — `json.dumps(list(input.input_artifacts or []))` cast `::jsonb`,
**always written** (empty list → `[]`). Shape: a **JSON array of artifact-reference strings**
(artifact-repo paths/URLs the agent consumed). Example: `["discovery/app-x/decomposition-map.json", …]`.

**`token_usage` (JSONB, nullable).** Written by `_update_agent_task_row`
(`agent_dispatch.md:241,253,270`) — `json.dumps(token_usage)` cast `::jsonb`, always written
(zeros when no usage). Fixed shape:
```json
{ "input": 0, "output": 0, "total": 0 }
```
where `input = int(result.token_usage_input or 0)`, `output = int(result.token_usage_output or
0)`, `total = input + output`. (Legacy dispatch-path JSONB; the migration-027 structured
columns `input_tokens`/`output_tokens`/`cache_*` are what the rollups read —
`agent_dispatch.md:27-30,281`.)

**`local_agent_descriptor` (JSONB, nullable).** Set only when `actor_kind IN ('human',
'human_with_agent')` and a local agent was used; NULL for `olympus_agent`/`human`
(`050:639-644`). Shape (from column comment):
```json
{ "tool": "claude-code | cursor | ...", "version": "string", "model": "string" }
```

> ⚠️ **`cost_estimate` writes NULL on genuine 0.0** — `$8 = float(result.cost_estimate_usd or
> 0.0) or None`; the trailing `or None` means a true `0.0` cost writes SQL **NULL**, not `0`
> (`agent_dispatch.md:271,827` — gotcha G10).
>
> ⚠️ **N retries → N rows.** `_insert_agent_task_row` inserts a fresh-uuid row on every Temporal
> retry; no upsert/dedupe (`agent_dispatch.md:559` — gotcha G5). Each agent row may also spawn a
> `step_execution` row (§5). The doc's "migration 043" citation for wave-scoping is a **doc bug**
> — the real migration is **044** (`agent_dispatch.md:829` — G12).

### 3.7 Insert/update projection map (abridged)

- **INSERT** (`_insert_agent_task_row`, `agent_dispatch.md:183`): writes `id`(uuid4),
  `task_type`, `application_id`/`wave_id` (scope-validated; a bad scope raises and aborts),
  `status='queued'`-ish, `agent_backend`, `module_name`, `dispatched_at`, `retry_count`,
  `input_artifact_refs` (always). Best-effort; returns row id or `None`.
- **UPDATE** (`_update_agent_task_row`, `agent_dispatch.md:251-259`): sets
  `status`/`completed_at`/`duration_ms`/`model_used`/`output_artifact_ref`(via `_pick_output_ref`,
  NULL when prose/empty)/`token_usage`(`$7::jsonb`)/`cost_estimate`(`$8`, NULL-on-0.0)/`last_error`(`$9`).

---

## 4. `agent_task_session_artifact` — local-agent transcript capture (6 columns)

**Created:** `050_capability_system_grain.py:665-714` (`op.create_table(
"agent_task_session_artifact", …)`). **No other migration touches it.**

### 4.1 Columns

| # | column | type | nullable | default | FK (ON DELETE) | added-by |
|---|---|---|---|---|---|---|
| 1 | `id` | UUID | NO (PK) | `gen_random_uuid()` | — | `050:667-672` |
| 2 | `agent_task_id` | UUID | NO | — | → `agent_task.id` (**CASCADE**) | `050:673-678` |
| 3 | `kind` | VARCHAR(32) | NO | — | — | `050:679-691` |
| 4 | `artifact_ref` | TEXT | NO | — | — | `050:692-697` |
| 5 | `hash` | VARCHAR(64) | YES | — | — | `050:698-703` |
| 6 | `captured_at` | timestamptz | NO | `now()` | — | `050:704-709` |

> ⚠️ **Cascade mass-delete vector.** `agent_task_id → agent_task.id ON DELETE CASCADE`
> (`050:676`). Deleting an `agent_task` row deletes all its session artifacts. And because
> `agent_task.application_id → application.id ON DELETE CASCADE` and `agent_task.wave_id →
> wave.id ON DELETE CASCADE`, deleting an application OR a wave cascades: app/wave → agent_task →
> agent_task_session_artifact (a 3-level cascade chain). Same chain applies to `step_execution`
> via `agent_task_id ON DELETE SET NULL` (§5 — that one is SET NULL, NOT cascade, so step records
> survive).

### 4.2 CHECK constraints

- **`agent_task_session_artifact_kind_chk`** — added `050:710-713`. Full value set:
  ```
  kind IN ('transcript', 'prompt', 'diff', 'summary')
  ```
  Semantics (`050:683-690`): `transcript` = raw session transcript (Claude Code `.jsonl`, Cursor
  export); `prompt` = the prompt text the human ran; `diff` = resulting code diff; `summary` =
  human-authored summary of what the local agent did.

### 4.3 Indexes & unique constraints

| name | columns | added-by |
|---|---|---|
| (PK) | `id` | `050:667` |
| `ix_agent_task_session_artifact_task` | `agent_task_id` | `050:715-719` |

No unique constraints.

### 4.4 Notes

`artifact_ref` = artifact-repo path to the captured content (`050:696`). `hash` = SHA-256 of the
captured content for an immutability check (`050:702`). No JSONB columns. This table has no
documented activity/service writer in scope (it's populated by the human-paired-agent capture
path introduced by 050's capability/system grain; the backfill helper at
`scripts/seed_capability_system_backfill.py` is referenced in `050:74` for the parent grain
tables, not for this table).

---

## 5. `step_execution` — Layer-B execution envelope (18 columns)

**Created:** `033_create_step_execution_table.py:99-166` (`op.create_table("step_execution", …)`).
**No other migration touches it.** (033 is the branch point for the W19 cascade 034–038; the 039
merge is a no-op.)

### 5.1 Columns

| # | column | type | nullable | default | FK (ON DELETE) | added-by |
|---|---|---|---|---|---|---|
| 1 | `execution_id` | UUID | NO (PK) | `gen_random_uuid()` | — | `033:101-106` |
| 2 | `app_id` | UUID | **YES** | — | — (NOT an FK by design, `033:38-40`) | `033:107` |
| 3 | `wave_id` | UUID | YES | — | — (not an FK) | `033:108` |
| 4 | `portfolio_id` | UUID | NO | — | — (denormalized, not an FK, `033:38-40`) | `033:109` |
| 5 | `line_id` | VARCHAR(64) | NO | — | — | `033:110` |
| 6 | `step_id` | VARCHAR(128) | NO | — | — | `033:111` |
| 7 | `step_kind` | `step_execution_kind_enum` | NO | — | — | `033:112` |
| 8 | `status` | `step_execution_status_enum` | NO | — | — | `033:113` |
| 9 | `started_at` | timestamptz | YES | — | — | `033:114-118` |
| 10 | `completed_at` | timestamptz | YES | — | — | `033:119-123` |
| 11 | `duration_ms` | BIGINT | YES | — | — | `033:124` |
| 12 | `attempt` | INTEGER | NO | `1` | — | `033:125-130` |
| 13 | `last_error` | TEXT | YES | — | — | `033:131` |
| 14 | `input_artifacts` | JSONB | NO | `'[]'::jsonb` | — | `033:132-137` |
| 15 | `output_artifacts` | JSONB | NO | `'[]'::jsonb` | — | `033:138-143` |
| 16 | `payload` | JSONB | NO | `'{}'::jsonb` | — | `033:144-149` |
| 17 | `workflow_id` | VARCHAR(255) | NO | — | — | `033:150` |
| 18 | `agent_task_id` | UUID | YES | — | → `agent_task.id` (**SET NULL**) | `033:151-156` |
| 19 | `gate_id` | UUID | YES | — | — (NOT an FK — see §5.4) | `033:157` |

> Column count = **19**. ⚠️ **Only `agent_task_id` is a real FK** (`ON DELETE SET NULL` so an
> archived agent_task preserves the execution record, `033:34-36`). `app_id`/`wave_id`/
> `portfolio_id`/`gate_id` are deliberately **NOT** FKs (`033:38-40`): wave-scoped records need
> `app_id=NULL`; `portfolio_id` is denormalized (source of truth on `application`).
> ⚠️ `portfolio_id` is `NOT NULL` but has **no default** — the emit helper refuses to insert when
> it can't parse a portfolio_id (returns `None`, no row; `line_transitions-0-helpers-decorator.md:469`).

### 5.2 CHECK constraints (full predicates)

- **`step_execution_agent_fk_ck`** — added `033:158-161`:
  ```
  (step_kind = 'agent') = (agent_task_id IS NOT NULL)
  ```
  i.e. `agent_task_id` is set **iff** `step_kind='agent'` (boolean-equality form).
- **`step_execution_gate_fk_ck`** — added `033:162-165`:
  ```
  (step_kind = 'gate') = (gate_id IS NOT NULL)
  ```
  i.e. `gate_id` is set **iff** `step_kind='gate'`.

### 5.3 Indexes & unique constraints

| name | columns | predicate (partial) | added-by |
|---|---|---|---|
| (PK) | `execution_id` | — | `033:101` |
| `ix_step_execution_workflow_line_step` | `workflow_id`,`line_id`,`step_id` | — | `033:168-172` |
| `ix_step_execution_app_line` | `app_id`,`line_id` | — | `033:173-177` |
| `ix_step_execution_wave_line` | `wave_id`,`line_id` | **WHERE `wave_id IS NOT NULL`** | `033:178-183` |
| `ix_step_execution_agent_task` | `agent_task_id` | **WHERE `agent_task_id IS NOT NULL`** | `033:184-189` |

No unique constraints.

### 5.4 Enum types (created INSIDE migration 033 — not in 001)

⚠️ **Both enums are created in `033` itself**, not in `001`. Pattern (`033:84-97`): explicitly
`ENUM(...).create(bind, checkfirst=True)` first, then referenced on columns with
`create_type=False` (same idiom 003 uses) to avoid duplicate `CREATE TYPE` during
`op.create_table`. Dropped on downgrade with `checkfirst=True` (`033:210-212`).

- `step_execution_kind_enum` — 5 values: `'agent','git','gate','code','terminal'` (`033:60-68,89-92`).
- `step_execution_status_enum` — 8 values: `'queued','running','completed','failed','timed_out',
  'skipped','escalated','abandoned'` (`033:70-81,93-97`). (Matches the Python `ExecutionStatus`
  str-enum, lowercase values, `line_transitions-0-helpers-decorator.md:443`.)

### 5.5 JSONB column shapes

Written by `emit_execution_record` (INSERT) / `update_execution_record` (UPDATE) in
`temporal/olympus_workflows/utils/execution.py`, reproduced in
`line_transitions-0-helpers-decorator.md:466-500`.

**`input_artifacts` (JSONB, NOT NULL, default `[]`).** INSERT value =
`json.dumps([a.to_dict() for a in input.input_artifacts])` (`…helpers…md:479`). Shape: a **JSON
array of artifact descriptors**, each the `.to_dict()` of an `ArtifactRef`:
```json
[ { "path": "string", "kind": "string", "...": "ArtifactRef.to_dict() fields" } ]
```
(The Layer-A `inputs.artifacts` verbatim — `StepExecutionContext.input_artifact_paths`,
`…helpers…md:453`.)

**`output_artifacts` (JSONB, NOT NULL, default `[]`).** Set only on UPDATE and only when provided:
`output_artifacts = COALESCE($4::jsonb, output_artifacts)` where `$4 = json.dumps([a.to_dict()…])`
or NULL → keeps prior value (`…helpers…md:484,491,497`). Same array-of-descriptor shape.

**`payload` (JSONB, NOT NULL, default `{}`).** Kind-specific envelope. On INSERT =
`json.dumps(input.payload or {})`. On UPDATE = **shallow JSONB merge** `payload = payload ||
COALESCE($5::jsonb, '{}'::jsonb)` (`…helpers…md:479,492,498`). For a **code** step
(`emit_code_step_start`, `…helpers…md:459`) the payload is:
```json
{ "function": "<function_name>", "columns_written": ["col", "..."] }
```
(`columns_written` added only when `columns_writable` truthy; an empty list IS a refinement that
overwrites to `[]` on complete, `…helpers…md:463`.) For an **agent** step the payload carries
`{task_type, skill_id, agent_role, mcp_servers_used, model_used, token_usage, cost_estimate_usd}`
(the dispatch path merges `{model_used, token_usage, cost_estimate_usd}` over the start-time
payload, `agent_dispatch.md:356,391`).

### 5.6 Behavioral notes (parity-critical)

- `duration_ms` is computed **in SQL** on UPDATE: `EXTRACT(EPOCH FROM ($3 - started_at)) * 1000`
  (`…helpers…md:490`), not by the caller.
- `last_error = COALESCE($6, last_error)` — only set when an error is passed (`…helpers…md:493`).
- **Best-effort everywhere:** the whole INSERT/UPDATE is wrapped `try/except Exception` → warn +
  swallow + own connection closed in `finally` (`…helpers…md:480,500`). If `portfolio_uuid is
  None` the INSERT is skipped entirely and returns `None` (`…helpers…md:469`). A `None`
  `execution_id` threaded into complete → no-op. Step-execution emission **never** affects
  activity success/failure (`…helpers…md:502`).
- `execution_id` is a client-side `uuid.uuid4()` (`…helpers…md:467`), not the server default.

---

## 6. `workflow_signal_inbox` — durable signal queue (7 columns)

**Created:** `048_create_workflow_signal_inbox.py:64-99` (`op.create_table(
"workflow_signal_inbox", …)`). **No other migration touches it.**

### 6.1 Columns

| # | column | type | nullable | default | FK | added-by |
|---|---|---|---|---|---|---|
| 1 | `id` | UUID | NO (PK) | `gen_random_uuid()` | — | `048:66-71` |
| 2 | `workflow_id` | VARCHAR(255) | NO | — | — | `048:72` |
| 3 | `signal_name` | VARCHAR(255) | NO | — | — | `048:73` |
| 4 | `payload` | JSONB | NO | `'{}'::jsonb` | — | `048:74-79` |
| 5 | `status` | VARCHAR(32) | NO | `'pending'` | — | `048:80-85` |
| 6 | `created_at` | timestamptz | NO | `now()` | — | `048:86-91` |
| 7 | `consumed_at` | timestamptz | YES | — | — | `048:92-94` |

> ⚠️ **`status` column default is `'pending'`** (`048:84`), but the API writer
> (`enqueue_signal`) defaults its parameter to `'sent'` (`signal_inbox.py:31`) and always passes
> an explicit value — so rows are written `'sent'` (Temporal accepted) or `'queued'` (signal
> send failed / workflow dead). The DB default `'pending'` only applies to a value-omitting
> insert (no code path does this). See enum→varchar note §0.3.

### 6.2 CHECK constraints (full value set)

- **`workflow_signal_inbox_status_ck`** — added `048:95-98`:
  ```
  status IN ('pending', 'sent', 'queued', 'consumed', 'failed')
  ```
  Status semantics (`048:34-40`, `signal_inbox.py:1-13`): `sent` = Temporal accepted the wire
  send; `queued` = send raised / workflow dead, awaiting a consumer; `consumed` = drained by the
  workflow-side loop; `pending`/`failed` reserved.

### 6.3 Indexes & unique constraints

| name | columns | predicate (partial) | added-by |
|---|---|---|---|
| (PK) | `id` | — | `048:66` |
| `ix_workflow_signal_inbox_workflow_id` | `workflow_id` | — | `048:100-104` |
| `ix_workflow_signal_inbox_status_pending` | `workflow_id`,`created_at` | **WHERE `status IN ('pending','sent','queued')`** | `048:108-113` |

No unique constraints. ⚠️ Note the partial-index predicate (`'pending','sent','queued'`) is a
**superset** of what `list_pending` actually filters on (`'pending','queued'` only,
`signal_inbox.py:92`) — `sent` rows are indexed but excluded from the operator view.

### 6.4 JSONB shape

**`payload` (JSONB, NOT NULL, default `{}`).** Written by `enqueue_signal`
(`signal_inbox.py:48-61`) — `INSERT … VALUES (…, CAST(:payload AS jsonb), …)` where `:payload =
json.dumps(payload or {})`. **No fixed schema** — it's the signal body for whatever Temporal
signal is being durably recorded. Three signal names are written in scope (all from
`olympus-api/src/routers/waves.py`):
- `signal_name="dispatch_architecture"` → `payload = {"targets": [ {target_app_id, disposition,
  peer_source_app_ids, …}, … ]}` (`waves.py:2469-2476`).
- `signal_name="pre_dispatch_confirmed"` (`waves.py:2257`).
- `signal_name="stakeholder_approved"` (`waves.py:3239`).

### 6.5 Write/read paths

- **INSERT:** `enqueue_signal(db, workflow_id, signal_name, payload, status='sent')` — does **NOT
  commit** (caller owns the transaction boundary so the inbox row lives-or-dies with the rest of
  the request, `signal_inbox.py:40-43`).
- **UPDATE:** `mark_queued(db, row_id)` flips a `sent` row → `queued` after a Temporal signal
  failure (`signal_inbox.py:65-79`).
- **SELECT:** `list_pending` filters `status IN ('pending','queued')`, ORDER BY `created_at ASC`
  (oldest-outstanding first), backing `GET /workflow-signals/pending` (`signal_inbox.py:82-112`,
  `workflow_signals.py:43-71`).

---

## 7. `arch_data_signal_registry` — durable Arch↔Data handshake (7 columns)

**Created:** `046_create_arch_data_signal_registry.py:66-96` (`op.create_table(
"arch_data_signal_registry", …)`). **No other migration touches it.**

### 7.1 Columns

| # | column | type | nullable | default | FK | added-by |
|---|---|---|---|---|---|---|
| 1 | `id` | UUID | NO (PK) | `gen_random_uuid()` | — | `046:68-73` |
| 2 | `wave_id` | UUID | NO | — | — (not an FK) | `046:74` |
| 3 | `target_app_id` | UUID | NO | — | — (not an FK) | `046:75-77` |
| 4 | `signal_type` | TEXT | NO | — | — | `046:78` |
| 5 | `payload` | JSONB | NO | — | — | `046:79-81` |
| 6 | `created_at` | timestamptz | NO | `now()` | — | `046:82-87` |
| 7 | `consumed_at` | timestamptz | YES | — | — | `046:88` |
| 8 | `consumed_by_workflow_id` | TEXT | YES | — | — | `046:89` |

> Column count = **8**. No FK columns (wave_id/target_app_id are bare UUIDs — the registry is
> decoupled from workflow/wave identity by design, `046:9-33`).

### 7.2 CHECK constraints

**None.** ⚠️ **`signal_type` deliberately has NO DB CHECK** (`arch_data_registry.md:83`) — a
misspelled type would silently stash a row no consumer finds, so the **publish activity** fails
loud instead (`_require_known_signal_type` raises `ValueError` before any DB connection;
allowed set = `frozenset({"target_provisioned","data_ready_for_target"})`). See §0.3.

### 7.3 Indexes & unique constraints

| name | columns | kind / predicate | added-by |
|---|---|---|---|
| (PK) | `id` | primary key | `046:68` |
| `arch_data_signal_registry_scope_uk` | `wave_id`,`target_app_id`,`signal_type` | **UNIQUE** | `046:90-95` |
| `idx_arch_data_registry_lookup` | `wave_id`,`target_app_id`,`signal_type` | partial, **WHERE `consumed_at IS NULL`** (raw `op.execute`) | `046:100-104` |

⚠️ The partial index is **NOT unique** and never affects the upsert
(`arch_data_registry.md:132`). The upsert's `ON CONFLICT (wave_id, target_app_id, signal_type)`
resolves to the named **unique constraint** `arch_data_signal_registry_scope_uk`
(`arch_data_registry.md:113`).

### 7.4 JSONB shape

**`payload` (JSONB, NOT NULL).** Written **verbatim** by `publish_arch_data_signal`
(`arch_data_registry.md:95-108`) — `$4::jsonb = input.payload_json` (a JSON-serialized snapshot;
the activity does not parse/validate). The blob is the JSON encoding of one of two dataclasses
(`temporal/olympus_workflows/types.py`):

- **`TargetProvisionedSignal`** (`signal_type='target_provisioned'`, `types.py:208-235`):
  ```json
  {
    "target_app_id": "string",
    "portfolio_id": "string",
    "architecture_workflow_id": "string",
    "wave_id": "string",
    "disposition": "Refactor | Replace | Consolidate | Retain | Retire | ..."
  }
  ```
- **`DataReadyForTargetSignal`** (`signal_type='data_ready_for_target'`, `types.py:191-204`):
  ```json
  {
    "target_app_id": "string",
    "data_architecture_ref": "string (artifact repo path)",
    "data_migration_plan_ref": "string (artifact repo path)",
    "approved_at": "ISO-8601 string"
  }
  ```

### 7.5 Upsert semantics (parity-critical — `publish_arch_data_signal`)

INSERT…ON CONFLICT DO UPDATE (`arch_data_registry.md:95-128`):
```sql
INSERT INTO arch_data_signal_registry (wave_id, target_app_id, signal_type, payload)
VALUES ($1, $2, $3, $4::jsonb)
ON CONFLICT (wave_id, target_app_id, signal_type) DO UPDATE SET
    payload = EXCLUDED.payload,
    consumed_at = NULL,
    consumed_by_workflow_id = NULL,
    created_at = now()
```
- First publish: fresh `id` (server default), `created_at=now()`, NULL consume fields.
- **Republish (writer-wins):** overwrites `payload`, **resets `created_at` to now()** (so
  `created_at` effectively means "last published at"), and **NULLs both `consumed_at` and
  `consumed_by_workflow_id`** — re-arming the row for re-consumption even if a (possibly dead)
  workflow already claimed the prior payload (`arch_data_registry.md:126-130`). `id`/`wave_id`/
  `target_app_id`/`signal_type` are not modified. Naturally idempotent at the scope-key level
  (observationally; `created_at` advances but no consumer reads it, `arch_data_registry.md:149`).

**Consume** (`consume_arch_data_signal`, `arch_data_registry.md:157+`): atomic claim via
`UPDATE … RETURNING` with a COALESCE-preserving idempotency branch (claims the row by setting
`consumed_at`/`consumed_by_workflow_id` only if still unclaimed). All registry use is gated
behind `workflow.patched("arch-data-registry-v1")` (`arch_data_registry.md:271`).

---

## 8. `score_history` — scoring-dimension audit trail (7 columns)

**Created:** `004_create_analytics_tables.py:56-68` (`op.create_table("score_history", …)`).
**Touched by:** 004 (create), 005 (2 indexes). **No other migration alters it.**

### 8.1 Columns

| # | column | type | nullable | default | FK (ON DELETE) | added-by |
|---|---|---|---|---|---|---|
| 1 | `id` | UUID | NO (PK) | `gen_random_uuid()` | — | `004:58-59` |
| 2 | `application_id` | UUID | NO | — | → `application.id` (**CASCADE**) | `004:60-61` |
| 3 | `dimension` | VARCHAR(100) | NO | — | — | `004:62` |
| 4 | `score` | NUMERIC | NO | — | — | `004:63` |
| 5 | `recorded_at` | timestamptz | NO | `now()` | — | `004:64-65` |
| 6 | `source_artifact` | TEXT | YES | — | — | `004:66` |
| 7 | `governance_cycle` | VARCHAR(100) | YES | — | — | `004:67` |

> Column count = **7**. `score` is unbounded `NUMERIC` (no precision/scale — `004:63`).
> `dimension` is a free-form VARCHAR (scoring dimensions come from the Scoring Dimension
> Registry / profile, not a DB enum). No JSONB columns.

### 8.2 CHECK constraints

**None.**

### 8.3 Indexes & unique constraints

| name | columns | added-by |
|---|---|---|
| (PK) | `id` | `004:58` |
| `ix_score_history_app_recorded` | `application_id`,`recorded_at` | `005:49-51` |
| `ix_score_history_dimension` | `dimension` | `005:52-53` |

No unique constraints. (Append-only history: multiple rows per `(application_id, dimension)`
are expected — `recorded_at` differentiates them.)

### 8.4 Write path

Score history rows are projected during scoring/governance flows (see `regen/03b-activities/scoring.md`
and the governance sweep). `source_artifact` cites the artifact the score derived from;
`governance_cycle` tags rows recorded by a governance re-scoring sweep (NULL for the initial
Discovery/Rationalization score). The Scoring Dimension Registry is the source of valid
`dimension` values (validated upstream, not at the DB).

---

## 9. Migration DAG (linear except the W19 fan-out merge)

The full chain (`revision <- down_revision`) is **linear** from `001` to `066` **except** the
W19 reconciliation fan-out, where `034/035/036/037/038` all branch off `033` and `039` merges
them. In-scope tables' creating migrations sit on the main spine:

```
001 (enums) → 002 (core) → 003 (gate, agent_task, escalation)
  → 004 (score_history, …) → 005 (indexes)
  → … 011,012,013 (gate cols + escalated) …
  → 019,020 (gate preparing + reject_reason) …
  → 027 (agent_task perf cols + agent_benchmark view)
  → … 033 (step_execution)  ──┬─→ 034 (disposition cols) ─┐
                              ├─→ 035 (validation cols) ───┤
                              ├─→ 036 (deployment) → 037 (sustainment) ─┤
                              └─→ 038 (governance) ────────┴─→ 039 (MERGE, no-op)
                                                                  │  Revises: (034,035,037,038)
  → 040 (gate merge_blocked) → 041 → 042 (gate wave-scope)
  → 043 → 044 (agent_task wave-scope) → 045
  → 046 (arch_data_signal_registry) → 047
  → 048 (workflow_signal_inbox) → 049
  → 050 (agent_task grain cols + agent_task_session_artifact)
  → 051 → 052 → 053 → 054 → [no 055] → 056 → 057 → 058 → 059 → 060 → 061
  → 062 (gate RBAC cols + gate_approval) → 063 → 064 (agent_task provider cols)
  → 065 → 066 (head)
```

Per-migration ledger (in-scope migrations only):

| migration | down_revision | net effect on in-scope tables |
|---|---|---|
| `001` | None | CREATE TYPE × all enums (gate_type/gate_status/task_status/escalation_*/assembly_line/actor_type) |
| `003` | `002` | CREATE `gate` (10 col), `agent_task` (19 col), `escalation` (18 col) |
| `004` | `003` | CREATE `score_history` (7 col) |
| `005` | `004` | indexes on gate(3), agent_task(3), score_history(2), escalation(2) |
| `011` | `010` | gate +workflow_id,+sla_deadline,+evidence_package_url |
| `012` | `011` | gate +evidence_data (JSONB) |
| `013` | `012` | gate_status_enum ADD VALUE `'escalated'` |
| `019` | `018` | gate_status_enum ADD VALUE `'preparing'` |
| `020` | `019` | gate +reject_reason_category (TEXT, no CHECK) |
| `027` | `026` | agent_task +11 cols, +5 indexes, started_at backfill, `agent_benchmark` VIEW |
| `033` | `032` | CREATE step_execution (19 col) + 2 enums + 4 indexes + 2 CHECKs |
| `039` | `(034,035,037,038)` | no-op merge (consolidates W19 heads) |
| `040` | `039` | gate_status_enum ADD VALUE `'merge_blocked'`; gate +merge_failure_detail (JSONB) |
| `042` | `041` | gate.application_id → NULL; +wave_id FK(CASCADE); +gate_application_or_wave_ck; +ix_gate_wave_id |
| `044` | `043` | agent_task.application_id → NULL; +wave_id FK(CASCADE); +agent_task_application_or_wave_ck; +ix_agent_task_wave_id |
| `046` | `045` | CREATE arch_data_signal_registry (8 col) + unique constraint + partial index |
| `048` | `047` | CREATE workflow_signal_inbox (7 col) + status CHECK + 2 indexes |
| `050` | `049` | agent_task +actor_kind/+human_user_id/+local_agent_descriptor + 2 CHECKs; CREATE agent_task_session_artifact (6 col) + CHECK + index |
| `062` | `061` | gate +minimum_approvals/+oversight_role/+management_override_allowed; CREATE `gate_approval` (8 col, 1 CHECK-free, UNIQUE + 1 idx) — see §12 |
| `064` | `063` | agent_task +provider_name/+provider_fallback_from (no CHECK, no index) |
| `065` | `064` | CREATE `design_annotation` (10 col, 2 CHECKs, 2 idx) — see §13 |
| `066` | `065` | CREATE `interview_session` (14 col, 2 CHECKs, 2 JSONB, 2 idx) — **HEAD** — see §14 |

---

## 10. ⚠️ Gotcha index (mass-delete cascades, nullable surprises, enum→varchar)

1. **Mass-delete cascade chains.** Deleting one parent row cascades down:
   - `application` → (CASCADE) `gate`, `agent_task`, `escalation`, `score_history`,
     `model_override`, `traceability_link`, `design_annotation` (§13, `065:48`),
     `interview_session` (§14, `066:49`).
   - `portfolio` → (CASCADE) `interview_session.portfolio_id` (§14, `066:55`; nullable FK).
   - `wave` → (CASCADE) `gate.wave_id`, `agent_task.wave_id`, `gate_approval` (via gate).
   - `agent_task` → (CASCADE) `agent_task_session_artifact`; → (**SET NULL**) `step_execution.agent_task_id`.
   - `gate` → (CASCADE) `gate_approval` (§12, `062:64`).
   ⚠️ So dropping an `application` transitively deletes its agent_tasks AND their session
   artifacts (3-level), but its `step_execution` rows survive (agent_task_id nulled, app_id is
   non-FK and untouched). `step_execution.app_id`/`portfolio_id`/`gate_id` are deliberately NOT
   FKs — no cascade from there.

2. **Nullable-with-no-default surprises.**
   - `gate.application_id`: created `NOT NULL`, **relaxed to NULL** by 042. Regenerate as NULL.
   - `agent_task.application_id`: created `NOT NULL`, **relaxed to NULL** by 044. Regenerate as NULL.
   - `step_execution.portfolio_id`: `NOT NULL` with **no default** — the emit helper silently
     skips the insert when it can't supply one.
   - `gate.status` / `workflow_signal_inbox.status`: have DB defaults (`'pending'`) that the
     writers **override** (`'preparing'` / `'sent'`); the default never actually applies.

3. **Enum vs. varchar+CHECK (no in-place conversions on any table in this file).** PG-ENUM columns:
   `gate.gate_type`, `gate.status`, `agent_task.status`, `escalation.{type,severity,status}`,
   `escalation.line`, `step_execution.step_kind`, `step_execution.status`. VARCHAR/TEXT/INTEGER+CHECK:
   `agent_task.actor_kind`, `workflow_signal_inbox.status`, `agent_task_session_artifact.kind`,
   `design_annotation.action` (§13), `interview_session.status` + `interview_session.phase` (§14).
   VARCHAR/TEXT with **NO DB CHECK** (validated only in app code): `gate.reject_reason_category`,
   `escalation.resolution_type`, `agent_task.provider_name`, `agent_task.provider_fallback_from`,
   `arch_data_signal_registry.signal_type`, `score_history.dimension`, `gate_approval.approver_role`
   (§12), `design_annotation.artifact_type`/`skill_id` (§13). ⚠️ Do not "helpfully" add CHECKs to
   the no-CHECK columns on regeneration — that diverges from observed behavior.

4. **gate_status_enum non-transactional ADD VALUE ordering** — see §0.4. The single most
   fragile regeneration detail: the 7 values MUST be in the order
   `pending, approved, rejected, overridden, escalated, preparing, merge_blocked`.

5. **step_execution enums born in 033, not 001.** A regenerator that mechanically collects all
   `CREATE TYPE`s into a single "enums" migration must remember `step_execution_kind_enum` and
   `step_execution_status_enum` are created (and dropped) inside `033`, with the explicit
   `.create(bind, checkfirst=True)` + `create_type=False` idiom.

6. **Non-idempotent telemetry inserts.** `create_gate_record` and `_insert_agent_task_row` both
   generate a fresh `uuid.uuid4()` per Temporal retry with no `ON CONFLICT` → N retries produce N
   rows. By contrast `publish_arch_data_signal` IS idempotent (upsert on the scope unique key) and
   `enqueue_signal` is once-per-request (caller-controlled).

---

## 11. Undetermined / out-of-this-file's-scope

- **`escalation` runtime INSERT path.** No `INSERT INTO escalation` / ORM `Escalation(...)`
  constructor exists in `olympus-api` or the activities; rows are created by the **seed scripts**
  (and the gate-escalate action records escalation context via `services/gate.py`, but the exact
  column-level INSERT there was not traced in this pass — the resolve UPDATE is fully captured in
  §2.5). `trigger_details`/`resolution` shapes ARE captured; the precise creation-time column
  population belongs to the seeds spec / gate-service spec.
- **`agent_task_session_artifact` writer** is not a Temporal activity in scope; its population path
  (human-paired-agent capture) is owned by the capability/system-grain feature (050) and is
  documented at the feature level, not the activity level.
- **`score_history` writer** is the scoring/governance projection (`regen/03b-activities/scoring.md`,
  governance sweep); the per-call INSERT column mapping lives in that activity spec, not here.
- `gate_approval` (created by 062), `design_annotation` (065), and `interview_session` (066) are
  fully specified in **§12 / §13 / §14** of this file (the spine §6c routes all three here). The
  earlier draft of this file excluded `gate_approval`; that exclusion is **rescinded** — see §12.

---

## 12. `gate_approval` — RBAC multi-person / oversight approval (8 columns)

**Created:** `062_rbac_gate_approval.py:52-116` (`op.create_table("gate_approval", …)`).
**No other migration touches it.** Backs Phase 6 W6 multi-approval / oversight co-sign /
management-override (`specifications/phase-6/rbac-model.md` §6, §9). Migration 062 is **DDL-only,
no DML** — the three companion columns it adds to `gate` (`minimum_approvals`/`oversight_role`/
`management_override_allowed`, §1.1 rows 18-20) default so existing single-approval gates keep
their behavior (`062:9-35`).

One row **per distinct human approval** of a gate. The `UNIQUE(gate_id, approved_by)` constraint
makes a repeat approval by the same user idempotent (the service uses `ON CONFLICT DO NOTHING`,
`062:14-16`).

### 12.1 Columns

| # | column | type | nullable | default | FK (ON DELETE) | added-by |
|---|---|---|---|---|---|---|
| 1 | `id` | UUID | NO (PK) | `gen_random_uuid()` | — | `062:54-60` |
| 2 | `gate_id` | UUID | NO | — | → `gate.id` (**CASCADE**) | `062:61-67` |
| 3 | `approved_by` | VARCHAR(255) | NO | — | — | `062:68-73` |
| 4 | `approver_role` | VARCHAR(64) | NO | — | — | `062:74-82` |
| 5 | `is_oversight` | BOOLEAN | NO | `false` | — | `062:83-89` |
| 6 | `is_management_override` | BOOLEAN | NO | `false` | — | `062:90-99` |
| 7 | `comment` | TEXT | YES | — | — | `062:100-105` |
| 8 | `approved_at` | timestamptz | NO | `now()` | — | `062:106-112` |

> Column count = **8**. Semantics (`062:13-20`): `approved_by` = the approver's `user.sub`;
> `approver_role` = the portfolio-scoped role held **at approval time** (a platform `RBACRole`
> value OR a profile-extension role string — no enum, no CHECK, free-form VARCHAR(64));
> `is_oversight` = TRUE when this approval satisfies the gate's `oversight_role` co-sign
> requirement; `is_management_override` = TRUE when a `portfolio_manager`/`portfolio_admin`
> approved a gate whose required reviewer role they did not otherwise hold.
>
> ⚠️ **`gate_id` FK is `ON DELETE CASCADE`** (`062:64`) — deleting a `gate` row deletes all its
> approvals. Combined with `gate.application_id → application.id ON DELETE CASCADE` and
> `gate.wave_id → wave.id ON DELETE CASCADE`, deleting an application OR a wave cascades:
> app/wave → gate → gate_approval (a 3-level cascade chain; matches the gotcha index §10.1).

### 12.2 CHECK constraints

**None.** `approver_role` is a free-form VARCHAR(64) validated only in the API/service layer (it
may hold a profile-extension role string, `062:78-81`) — do **not** add a CHECK on regeneration.
`is_oversight`/`is_management_override` are plain BOOLEANs constrained only by NOT NULL + default.

### 12.3 Indexes & unique constraints

| name | columns | kind / predicate | added-by |
|---|---|---|---|
| (PK) | `id` | primary key | `062:54-60` |
| `uq_gate_approval_gate_user` | `gate_id`, `approved_by` | **UNIQUE constraint** | `062:113-115` |
| `ix_gate_approval_gate` | `gate_id` | btree index | `062:117-121` |

⚠️ The `UNIQUE(gate_id, approved_by)` constraint (`uq_gate_approval_gate_user`) is the
idempotency key: the approval writer relies on `ON CONFLICT (gate_id, approved_by) DO NOTHING`
so a user double-clicking "Approve" inserts at most one row (`062:14-16`). Reproduce the named
unique constraint (not a bare index) so the `ON CONFLICT` target resolves.

### 12.4 No JSONB columns

`gate_approval` has **no JSONB columns** (all scalar). `comment` is plain nullable TEXT.

### 12.5 Projection / write model

Authoritative orchestration state (not a Git projection — it records who approved a gate and in
what role at decision time). Written by the gate-approval service/API path (cross-ref the
gate-operations / RBAC service spec, `regen/03b-activities/gate_operations.md`); the spine §5.3
routes `gate` + `gate_approval` writes to `gate_operations.md` / `gate_pre_review.md`. The
`approved_at`/`id` are DB-defaulted; `approved_by`/`approver_role` are supplied per approval;
`is_oversight`/`is_management_override` default `false` and are set TRUE only on the co-sign /
override branches.

---

## 13. `design_annotation` — standalone design-artifact review (10 columns)

**Created:** `065_create_design_annotation.py:37-94` (`op.create_table("design_annotation", …)`).
**No other migration touches it.** Backs the standalone design-review surface
(`/applications/:appId/design-review`, P6-S9.3 / W9): reviewers annotate an application's design
artifacts **outside a gate**; annotations marked `flag_for_revision` are batched into a
lightweight rework signal dispatched to the originating agent (P6-S9.4). Design:
`specifications/phase-6/design-artifact-review.md` §10.2 (Option A — dedicated table, chosen over
JSONB-on-artifact for independent queryability + reviewer attribution). DDL-only, no seed
(`065:17`).

### 13.1 Columns

| # | column | type | nullable | default | FK (ON DELETE) | added-by |
|---|---|---|---|---|---|---|
| 1 | `id` | UUID | NO (PK) | `gen_random_uuid()` | — | `065:39-44` |
| 2 | `app_id` | UUID | NO | — | → `application.id` (**CASCADE**) | `065:45-50` |
| 3 | `artifact_id` | VARCHAR(512) | NO | — | — (NOT an FK — Git-backed artifact store, `065:51`) | `065:52` |
| 4 | `artifact_type` | TEXT | NO | — | — | `065:53` |
| 5 | `skill_id` | TEXT | YES | — | — | `065:54` |
| 6 | `annotation_text` | TEXT | NO | — | — | `065:55-59` |
| 7 | `action` | TEXT | NO | — | — | `065:60` |
| 8 | `reviewer_id` | VARCHAR(255) | NO | — | — | `065:65` (comment `065:61-64`) |
| 9 | `feedback_sent_at` | timestamptz | YES | — | — | `065:67` (comment `065:66`) |
| 10 | `created_at` | timestamptz | NO | `now()` | — | `065:68-73` |
| 11 | `updated_at` | timestamptz | NO | `now()` | — | `065:74-79` |

> ⚠️ **Physical column count = 11** (`grep -c "sa.Column(" 065_*.py` = 11). The "10 columns" in
> this section's header is a logical undercount (it folds the `created_at`/`updated_at` audit pair
> into one). For parity, reproduce **all 11 columns shown**: `id`, `app_id`, `artifact_id`,
> `artifact_type`, `skill_id`, `annotation_text`, `action`, `reviewer_id`, `feedback_sent_at`,
> `created_at`, `updated_at`.
>
> ⚠️ **`artifact_id` is `VARCHAR(512)`, NOT an FK** (`065:51-52`) — it references the cross-store
> (Git-backed) artifact repo, so it carries no referential integrity; a 512-char string id.
> ⚠️ **`reviewer_id` is `VARCHAR(255)`** holding the reviewer's `user.sub` — the **same string
> identity** the gate tables persist for the approver (`gate.decided_by`); stored as text rather
> than a UUID FK to `user_account` so local-dev and IdP users are attributed uniformly without a
> fragile sub→UUID resolution (`065:61-64`).
> ⚠️ **`feedback_sent_at` non-null ⇒ already dispatched.** A non-NULL `feedback_sent_at` means the
> annotation has already been sent to the agent runtime and MUST NOT reappear in a future "Submit
> feedback" batch (`065:20,66`). NULL until dispatched.
> ⚠️ **`app_id` FK is `ON DELETE CASCADE`** (`065:48`) — deleting an `application` deletes all its
> design annotations.

### 13.2 CHECK constraints (full value sets)

- **`design_annotation_text_nonempty_ck`** — added `065:80-83`. Full predicate (reproduce verbatim):
  ```
  length(annotation_text) > 0
  ```
  Rejects empty annotation bodies at the DB.
- **`design_annotation_action_ck`** — added `065:84-87`. Full value set (reproduce verbatim):
  ```
  action IN ('flag_for_revision', 'mark_reviewed', 'note_only')
  ```
  Only `flag_for_revision` annotations are batched into the rework signal (P6-S9.4);
  `mark_reviewed` / `note_only` are advisory-only.

> ⚠️ **`artifact_type`/`skill_id`/`reviewer_id` have NO CHECK** — only `action` and
> `annotation_text` are DB-constrained. Do not add CHECKs the migration lacks.

### 13.3 Indexes & unique constraints

| name | columns | kind | added-by |
|---|---|---|---|
| (PK) | `id` | primary key | `065:39-44` |
| `design_annotation_app_id_idx` | `app_id` | btree | `065:89-91` |
| `design_annotation_artifact_idx` | `artifact_id` | btree | `065:92-94` |

No unique constraints (a reviewer may file multiple annotations on the same artifact).

### 13.4 No JSONB columns

`design_annotation` has **no JSONB columns** — `annotation_text`/`artifact_type`/`skill_id`/
`action` are TEXT, `artifact_id`/`reviewer_id` are VARCHAR. All scalar.

### 13.5 Projection / write model

Authoritative review state (not a Git projection — it records reviewer attribution + the
flag-for-revision decision). Written by the design-review API/service path
(`/applications/:appId/design-review`, P6-S9.3); the rework-batch dispatch (P6-S9.4) reads
`action='flag_for_revision' AND feedback_sent_at IS NULL`, dispatches the batch, then stamps
`feedback_sent_at = now()`. `id`/`created_at`/`updated_at` are DB-defaulted; `app_id`/
`artifact_id`/`artifact_type`/`annotation_text`/`action`/`reviewer_id` supplied per annotation;
`skill_id`/`feedback_sent_at` nullable.

---

## 14. `interview_session` — asynchronous Requirements Interview (14 columns) — HEAD

**Created:** `066_create_interview_session.py:37-127` (`op.create_table("interview_session", …)`).
**066 is the current schema HEAD.** **No other migration touches it.** Backs the asynchronous,
multi-turn Requirements Interview UI
(`/portfolios/:portfolioId/applications/:appId/interview`) for the interview-driven Build intake
path (P6-S5.12 / W5). Design: `specifications/phase-6/greenfield-build-line.md` §3.3 (the
Discovery workflow pauses at `wait_for_interview_completion`; the API emits `interview_completed`
on submit) and §15 OQ-1 (14-day completion timeout; on timeout the API fires `interview_expired`
and preserves the partial artifact). DDL-only, no seed (`066:21`).

One row per interview session, keyed by `app_id`. The partial `requirements-capability` artifact
and the full Q&A transcript are persisted on **every turn** as JSONB so the stakeholder can pause
and resume across sessions (`066:13-19`).

### 14.1 Columns

| # | column | type | nullable | default | FK (ON DELETE) | added-by |
|---|---|---|---|---|---|---|
| 1 | `id` | UUID | NO (PK) | `gen_random_uuid()` | — | `066:40-45` |
| 2 | `app_id` | UUID | NO | — | → `application.id` (**CASCADE**) | `066:46-51` |
| 3 | `portfolio_id` | UUID | **YES** | — | → `portfolio.id` (**CASCADE**) | `066:52-57` |
| 4 | `workflow_id` | VARCHAR(255) | YES | — | — | `066:61` (comment `066:58-60`) |
| 5 | `stakeholder_name` | TEXT | YES | — | — | `066:63` (comment `066:62`) |
| 6 | `stakeholder_role` | TEXT | YES | — | — | `066:64` |
| 7 | `status` | TEXT | NO | `'active'` | — | `066:67-72` (comment `066:65-66`) |
| 8 | `phase` | INTEGER | NO | `1` | — | `066:74-79` (comment `066:73`) |
| 9 | `transcript` | JSONB | NO | `'[]'::jsonb` | — | `066:81-86` (comment `066:80`) |
| 10 | `partial_artifact` | JSONB | NO | `'{}'::jsonb` | — | `066:88-93` (comment `066:87`) |
| 11 | `created_by` | VARCHAR(255) | YES | — | — | `066:96` (comment `066:94-95`) |
| 12 | `created_at` | timestamptz | NO | `now()` | — | `066:97-102` |
| 13 | `updated_at` | timestamptz | NO | `now()` | — | `066:103-108` |
| 14 | `expires_at` | timestamptz | YES | — | — | `066:111` (comment `066:109-110`) |
| 15 | `completed_at` | timestamptz | YES | — | — | `066:112` |

> ⚠️ **Physical column count = 15** (`grep -c "sa.Column(" 066_*.py` = 15). The "14 columns" in
> this section's header is a logical undercount (folding the `created_at`/`updated_at` audit pair).
> For parity, reproduce **all 15 columns shown**.
>
> ⚠️ **`app_id` FK CASCADE + `portfolio_id` FK CASCADE** (`066:49`, `066:55`) — deleting an
> `application` OR a `portfolio` deletes the interview session. `portfolio_id` is **nullable**
> (`066:52-57`) so a standalone local-dev/fixture interview need not be portfolio-scoped.
> ⚠️ **`workflow_id` is nullable VARCHAR(255), NOT an FK** (`066:58-61`) — it is the Discovery
> (Build-mode) workflow handle the completion/expiry signal targets; NULL when the UI drives a
> standalone interview in local-dev/fixture mode where no workflow is waiting.
> ⚠️ **`created_by` is `VARCHAR(255)`** = the stakeholder's `user.sub`, the same text identity the
> gate / `design_annotation` tables persist (`066:94-96`). Nullable.
> ⚠️ **`status`/`phase` have DB defaults (`'active'` / `1`)** that the create path relies on for a
> freshly-opened session.
> ⚠️ **`expires_at`** = the 14-day completion deadline (design §15 OQ-1): set at creation to
> `now() + 14 days`; on expiry the API fires `interview_expired` (`066:109-111`). Nullable (set by
> the writer, no DB default). `completed_at` set when the interview is submitted.

### 14.2 CHECK constraints (full value sets)

- **`interview_session_status_ck`** — added `066:113-116`. Full value set (reproduce verbatim):
  ```
  status IN ('active', 'completed', 'expired')
  ```
  Semantics (`066:65-66`): `active` = in progress; `completed` = submitted + `interview_completed`
  signal fired; `expired` = 14-day timeout elapsed before completion (`interview_expired` fired,
  partial artifact preserved).
- **`interview_session_phase_ck`** — added `066:117-120`. Full predicate (reproduce verbatim):
  ```
  phase >= 1 AND phase <= 5
  ```
  The five-phase elicitation flow (design §3.3); `phase` is `1..5` inclusive.

> ⚠️ **`status`/`phase` are VARCHAR/INTEGER + CHECK (NOT PG enums)** — the same "flexibility"
> pattern as `workflow_signal_inbox.status` (§0.3). Reproduce the CHECKs, not an `ALTER TYPE`.

### 14.3 Indexes & unique constraints

| name | columns | kind | added-by |
|---|---|---|---|
| (PK) | `id` | primary key | `066:40-45` |
| `interview_session_app_id_idx` | `app_id` | btree | `066:122-124` |
| `interview_session_status_idx` | `status` | btree | `066:125-127` |

No unique constraints — the design notes "one row per interview session, keyed by `app_id`"
(`066:13`) but enforces no DB UNIQUE on `app_id` (multiple sessions per app are physically
permitted; the API governs at most one active session).

### 14.4 ⭐ JSONB column shapes (2)

Both JSONB columns are **NOT NULL with a JSONB default** and are rewritten on every interview turn
so the stakeholder can pause/resume (`066:13-19,80-93`).

**`transcript` (JSONB, NOT NULL, default `'[]'::jsonb`).** A **JSON array** of Q&A turn objects —
the full elicitation transcript. Shape per element (`066:80-86`):
```json
[
  {
    "question_id": "string",
    "phase": 1,
    "question": "string (the prompt shown to the stakeholder)",
    "answer": "string (the stakeholder's response)"
  }
]
```
`phase` within a transcript element is the 1..5 phase that question belonged to. Empty (no turns
yet) → `[]`.

**`partial_artifact` (JSONB, NOT NULL, default `'{}'::jsonb`).** The **partial
`requirements-capability` artifact object**, accumulated per turn (`066:87-93`). It is the
in-progress projection of the Build-intake requirements-capability artifact (the same artifact the
Discovery Build path ultimately commits to Git); free-form object shape, whatever the
interview-elicitation accumulator has filled so far. Empty (nothing elicited yet) → `{}`. On
`interview_completed` this partial artifact is finalized and committed; on `interview_expired` it
is preserved as-is (design §15 OQ-1).

### 14.5 Projection / write model

Authoritative **resumable** session state (not a Git projection while in flight — but its
`partial_artifact` is the in-progress projection of a Git artifact, finalized + committed on
completion). Written by the interview API/service path
(`/portfolios/:portfolioId/applications/:appId/interview`): each turn rewrites `transcript` +
`partial_artifact` and stamps `updated_at`; `status`/`phase` advance through the flow; submit sets
`status='completed'` + `completed_at` and fires `interview_completed` to `workflow_id`; the 14-day
sweep sets `status='expired'` and fires `interview_expired`. `id`/`created_at`/`updated_at` and the
two JSONB defaults are DB-defaulted; `app_id` required; `portfolio_id`/`workflow_id`/
`stakeholder_*`/`created_by`/`expires_at`/`completed_at` nullable.
