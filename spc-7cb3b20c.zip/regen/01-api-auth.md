# Regeneration Spec — Phase 8 API: Auth, Users, Me, Agent-Roles

ATOMIC regeneration target. Behavioral-parity bar. This file owns four routers plus the
platform-wide **AUTH DEEP-DIVE** (JWT/OIDC, scopes, token validation, how scopes guard endpoints).

Source files (all under `/Users/pnunna/Documents/GitHub/foundry/`):
- `olympus-api/src/routers/auth.py` — 10 endpoints
- `olympus-api/src/routers/users.py` — 6 endpoints
- `olympus-api/src/routers/me.py` — 1 endpoint
- `olympus-api/src/routers/agent_roles.py` — 1 endpoint

**Endpoint count gate: auth=10, users=6, me=1, agent_roles=1 (total 18).**

Supporting modules reproduced here because they are load-bearing for parity:
`olympus-api/src/middleware/auth.py`, `olympus-api/src/auth/service_tokens.py`,
`olympus-api/src/auth/user_tokens.py`, `olympus-api/src/services/oidc.py`,
`olympus-api/src/services/identity_config.py`, `olympus-api/src/services/password.py`,
`olympus-api/src/services/user.py`, `olympus-api/src/services/agent_roles.py`,
`olympus-api/src/dependencies.py`, `olympus-api/src/middleware/pagination.py`,
`olympus-api/src/middleware/error_handler.py`, `olympus-api/src/models/user.py`,
`olympus-api/src/models/common.py`, `olympus-api/src/models/agent_role.py`,
`olympus-api/src/models/portfolio_membership.py`.

---

## 0. ROUTER MOUNT ORDER & PREFIXES

Routers are mounted in `olympus-api/src/main.py` via `app.include_router(...)`. Mount order for
these four (relative to the whole app; full app has ~40 routers):

```
main.py:180   app.include_router(auth_router)            # prefix /api/v1/auth   tags=["Auth"]
main.py:210   app.include_router(agent_roles_router)      # prefix /api/v1/agent-roles  tags=["Agent Roles"]
main.py:215   app.include_router(users_router)            # prefix /api/v1/users  tags=["Users"]
main.py:216   app.include_router(me_router)               # prefix /api/v1/me     tags=["Me"]
```

⚠️ GOTCHA — within `auth.py` the route registration order matters for FastAPI path matching.
`GET /me` (`auth.py:176`) is registered BEFORE `GET /users` (`auth.py:417`); `PUT /users/{user_id}/roles`
(`auth.py:437`) is a literal-then-param path. These never collide because prefixes differ, but the
declared order MUST be preserved: service-token, login, logout, me, config, oidc/login, oidc/callback,
roles, users (list), users/{user_id}/roles (put). Reproduce in this exact source order.

⚠️ GOTCHA — `auth.py` exposes BOTH `/api/v1/auth/users` (list-only alias, `auth.py:417`) AND
`/api/v1/auth/users/{user_id}/roles` (PUT, `auth.py:437`). The PRIMARY user CRUD surface is the
separate `users.py` router at `/api/v1/users`. The `/auth/*` ones are thin aliases that exist solely
so the OpenAPI contract test (`specifications/api/domains/auth.yaml`) sees matching shapes. Both must exist.

Router objects:
- `auth.py:69` — `router = APIRouter(prefix="/api/v1/auth", tags=["Auth"])`
- `users.py:45` — `router = APIRouter(prefix="/api/v1/users", tags=["Users"])`
- `me.py:27` — `router = APIRouter(prefix="/api/v1/me", tags=["Me"])`
- `agent_roles.py:43` — `router = APIRouter(prefix="/api/v1/agent-roles", tags=["Agent Roles"])`

---

## 1. AUTH DEEP-DIVE (JWT / OIDC / SCOPES / TOKEN VALIDATION)

### 1.1 RBAC roles (the only scopes)

`olympus-api/src/models/common.py:47-56` — `class RBACRole(str, enum.Enum)`. **9 values** (string values):

| Enum member | string value |
|---|---|
| `PORTFOLIO_ADMIN` | `"portfolio_admin"` |
| `PORTFOLIO_MANAGER` | `"portfolio_manager"` |
| `TECH_LEAD` | `"tech_lead"` |
| `ARCH_LEAD` | `"arch_lead"` |
| `COMPLIANCE_LEAD` | `"compliance_lead"` |
| `OPERATIONS_LEAD` | `"operations_lead"` |
| `SAFETY_BOARD` | `"safety_board"` |
| `VIEWER` | `"viewer"` |
| `SERVICE` | `"service"` |

⚠️ GOTCHA — the `middleware/auth.py` docstring says "8 RBAC roles" but the enum has **9** (it omits
`service` in the prose). `service` is a real role minted by service tokens. Reproduce all 9.

There are **no OAuth scope strings** — "scope" in Olympus == an `RBACRole`. Endpoint authorization is
"caller's `roles` list contains at least one of the required roles" (OR semantics, never AND).

### 1.2 JWT shapes (two issuers, one decoder)

Both token issuers produce HS256 JWTs signed with `JWT_SECRET`; the single decoder in
`middleware/auth.py` accepts either shape.

**Service token** — `olympus-api/src/auth/service_tokens.py:22-49`, `issue_service_token(service, *, ttl_seconds=DEFAULT_TTL_SECONDS, secret=None, algorithm=None)`:
- `DEFAULT_TTL_SECONDS = 3600` (1h) — `service_tokens.py:18`
- `SERVICE_IDENTITIES = ("agent-runtime", "worker")` — `service_tokens.py:19`
- Raises `ValueError` if `service not in SERVICE_IDENTITIES` (`service_tokens.py:33-37`).
- Payload (`service_tokens.py:40-46`):
  ```
  {
    "sub":     "service:<service>",     # e.g. "service:agent-runtime"
    "roles":   ["service"],             # [RBACRole.SERVICE.value]
    "iat":     <now epoch int>,
    "exp":     <now + ttl_seconds>,
    "service": "<service>",
  }
  ```
- `effective_secret = secret or os.environ["JWT_SECRET" default "olympus-dev-secret"]`
- `effective_algorithm = algorithm or os.environ["JWT_ALGORITHM" default "HS256"]`
- Returns `jwt.encode(payload, effective_secret, algorithm=effective_algorithm)`.

**User token** — `olympus-api/src/auth/user_tokens.py:21-48`, `issue_user_token(*, user_id, username, roles: list[str], identity_provider, ttl_seconds=DEFAULT_USER_TTL_SECONDS, secret=None, algorithm=None)`:
- `DEFAULT_USER_TTL_SECONDS = 8 * 60 * 60 = 28800` (8h working session) — `user_tokens.py:18`
- Payload (`user_tokens.py:38-45`):
  ```
  {
    "sub":               str(user_id),    # UUID string — stable across username/email changes
    "username":          <username>,
    "roles":             list(roles),     # list[str]
    "identity_provider": <identity_provider>,
    "iat":               <now epoch int>,
    "exp":               <now + ttl_seconds>,
  }
  ```
- Same secret/algorithm resolution and `jwt.encode` as service token.

### 1.3 The auth dependency — `get_current_user` (PSEUDOCODE, every branch)

`olympus-api/src/middleware/auth.py`. Module-level config read ONCE at import (`auth.py:26-29`):
```
_JWT_SECRET             = env "JWT_SECRET"             default "olympus-dev-secret"
_JWT_ALGORITHM          = env "JWT_ALGORITHM"          default "HS256"
_AUTH_SKIP_VERIFICATION = (env "AUTH_SKIP_VERIFICATION" default "true").lower() == "true"   # default TRUE
_DEV_AUTH_BYPASS        = (env "DEV_AUTH_BYPASS"        default "").lower()     == "true"   # default FALSE
```

⚠️ GOTCHA — `_AUTH_SKIP_VERIFICATION` **defaults to `true`**. In default/dev config the JWT signature,
expiry, and audience are NOT verified — the token is decoded for claims only. Production must set
`AUTH_SKIP_VERIFICATION=false`. ⚠️ GOTCHA — these are read at import time; changing the env var after
import has no effect (tests monkeypatch the module globals directly).

`CurrentUser` class (`auth.py:32-41`):
```
class CurrentUser:
    __init__(self, sub: str, roles: list[RBACRole], claims: dict):
        self.sub = sub; self.roles = roles; self.claims = claims
    has_role(self, *roles: RBACRole) -> bool:
        return any(r in self.roles for r in roles)     # OR semantics
```

`_extract_token(request)` (`auth.py:44-49`):
```
auth = request.headers.get("Authorization", "")
if auth.startswith("Bearer "):  return auth[7:]
return None
```

`async def get_current_user(request) -> CurrentUser` (`auth.py:52-103`) — PSEUDOCODE:
```
if _DEV_AUTH_BYPASS:                                    # auth.py:61
    return CurrentUser(
        sub="local-dev",
        roles=list(RBACRole),                           # ALL 9 roles
        claims={"sub": "local-dev", "dev_bypass": True},
    )

token = _extract_token(request)
if token is None:                                       # auth.py:69
    raise HTTPException(401, detail="Missing authorization token")

try:
    options = {}
    if _AUTH_SKIP_VERIFICATION:                         # auth.py:74 — default path
        options = {"verify_signature": False, "verify_exp": False, "verify_aud": False}
    payload = jwt.decode(token, _JWT_SECRET, algorithms=[_JWT_ALGORITHM], options=options)
except JWTError as exc:                                 # auth.py:86
    log.warning("jwt_decode_failed", error=str(exc))
    raise HTTPException(401, detail="Invalid or expired token") from exc

sub       = payload.get("sub", "anonymous")             # auth.py:90
raw_roles = payload.get("roles", [])

roles = []
for r in raw_roles:                                     # auth.py:94
    try:    roles.append(RBACRole(r))
    except ValueError:  log.warning("unknown_role_in_token", role=r)   # unknown role string → skipped, NOT fatal

if not roles:                                           # auth.py:100
    roles = [RBACRole.VIEWER]                           # empty/all-unknown roles default to VIEWER

return CurrentUser(sub=sub, roles=roles, claims=payload)
```
⚠️ GOTCHA — a token with `sub` missing yields `sub="anonymous"`. A token with no/unknown roles is
NOT rejected — it silently becomes `[VIEWER]`. Bare 401s here are raised as plain `HTTPException`
(detail string), which the global handler maps to `{"error":{"code":"UNAUTHORIZED",...}}` (see §1.6).

### 1.4 The scope guard — `require_role` (PSEUDOCODE)

`olympus-api/src/middleware/auth.py:106-119` — factory returning a FastAPI dependency:
```
def require_role(*required_roles: RBACRole):
    async def _check(user = Depends(get_current_user)) -> CurrentUser:
        if not user.has_role(*required_roles):          # OR: needs ≥1 of required_roles
            raise HTTPException(403, detail=f"Requires one of: {[r.value for r in required_roles]}")
        return user
    return _check
```
- `Depends(require_role(RBACRole.PORTFOLIO_ADMIN))` → 403 unless caller has `portfolio_admin`.
- `Depends(require_role(*VIEWER_PLUS))` → 403 unless caller has any of the 9 (effectively any
  authenticated user, since `[VIEWER]` default satisfies it).
- 403 detail is a plain string; global handler maps to `{"error":{"code":"FORBIDDEN",...}}`.

### 1.5 OIDC flow (authorization-code + PKCE) — `olympus-api/src/services/oidc.py`

**Config dataclass** `OIDCProviderConfig` (`oidc.py:78-111`), frozen, safe-to-log:
```
provider_id: str                       # "okta" | "entra" | "ping" ...
label: str                             # button text
issuer: str
client_id: str
client_secret_env: str = "OIDC_CLIENT_SECRET"
authorization_url: str = ""
token_url: str = ""
userinfo_url: str = ""
jwks_url: str = ""
redirect_uri: str = ""
scopes: tuple[str,...] = ("openid","profile","email")
role_mapping: dict[str, RBACRole] = {}
default_role: RBACRole = RBACRole.VIEWER
groups_claim: str = "groups"           # IdP-specific: OKTA "groups", Entra "roles"
get_client_secret() -> str:  return os.environ.get(self.client_secret_env, "")   # empty in dev/test
```

**Claims dataclass** `OIDCUserClaims` (`oidc.py:114-123`): `subject, email, preferred_username,
full_name, groups: tuple[str,...]=(), raw: dict={}`.

**`OIDCClient`** (`oidc.py:131-293`) — wraps the flow. Constructor caches JWKS in `_jwks_cache`.
- `generate_pkce() -> (verifier, challenge)` STATIC (`oidc.py:150-156`):
  ```
  verifier  = secrets.token_urlsafe(64)[:96]
  digest    = sha256(verifier.encode("ascii")).digest()
  challenge = base64.urlsafe_b64encode(digest).rstrip(b"=").decode("ascii")   # S256
  ```
- `get_authorization_url(state, code_challenge, *, nonce=None) -> str` (`oidc.py:158-177`):
  builds `{authorization_url}?` urlencode of
  `{response_type=code, client_id, redirect_uri, scope=" ".join(scopes), state, code_challenge,
  code_challenge_method=S256}` (+ `nonce` if given).
- `async exchange_code(code, code_verifier) -> dict` (`oidc.py:179-206`): POST to `token_url` form-body
  `{grant_type=authorization_code, code, redirect_uri, client_id, client_secret=get_client_secret(),
  code_verifier}` with `Accept: application/json`. If `status_code >= 400` → raise `OIDCAuthError`.
  Uses injected `self._http` or a fresh `httpx.AsyncClient(timeout=10.0)` (closed after if self-created).
- `async validate_id_token(id_token) -> OIDCUserClaims` (`oidc.py:208-232`) — PSEUDOCODE:
  ```
  keys   = await self._get_jwks()                         # cached after first fetch
  header = jwt.get_unverified_header(id_token);  kid = header.get("kid")
  last_error = None
  for key in keys:
      if kid and key.get("kid") != kid:  continue          # match by kid when present
      try:
          claims = jwt.decode(
              id_token,
              jwk.construct(key).to_dict(),
              algorithms=[key.get("alg", "RS256")],
              issuer=self.config.issuer,                    # verifies iss
              audience=self.config.client_id,               # verifies aud
              options={"verify_at_hash": False},
          )
          return self._claims_from_payload(claims)
      except JWTError as exc:  last_error = exc; continue
  raise OIDCAuthError(f"id_token signature validation failed: {last_error}")
  ```
- `_get_jwks()` (`oidc.py:236-250`): returns cache if set; else GET `jwks_url`, `raise_for_status()`,
  cache `payload.get("keys") or []`.
- `_claims_from_payload(claims)` (`oidc.py:252-275`): `subject=str(sub or "")`,
  `email=str(email or "")`, `preferred=str(preferred_username or email or subject)`,
  `full_name=claims.get("name")`. `groups_raw=claims.get(groups_claim) or []`: if str → split on ","
  dropping empties; if list → tuple of str; else `()`. If `not subject` → raise
  `OIDCAuthError("id_token is missing a 'sub' claim")`.
- `resolve_roles(claims) -> list[RBACRole]` (`oidc.py:277-293`) — PSEUDOCODE:
  ```
  resolved = []
  for group in claims.groups:
      mapped = self.config.role_mapping.get(group)
      if mapped is not None:  resolved.append(mapped)
  if not resolved:  resolved.append(self.config.default_role)   # fallback default_role (VIEWER)
  # dedupe preserving insertion order:
  return unique(resolved)
  ```

**`MockOIDCProvider`** (`oidc.py:301-352`) — test double, no crypto. `seed_token`, `link_code`;
`exchange_code` returns `{access_token, id_token, token_type:"Bearer", expires_in:3600}` if code
linked else `OIDCAuthError`; `validate_id_token` returns seeded claims or `OIDCAuthError`.

**`load_identity_config(profile_root) -> OIDCProviderConfig | None`** (`oidc.py:360-438`):
- Reads `<profile_root>/config/identity.yaml`. If file absent → `None` (`oidc.py:373`).
- `mode = (raw.get("identity_mode") or "local").lower()`. If `"local"` → `None`. If not in
  `{local,oidc}` → `OIDCConfigError`.
- `oidc_block = raw.get("oidc") or {}`; required keys = `(provider_id, issuer, client_id,
  authorization_url, token_url)` — any missing → `OIDCConfigError` (`oidc.py:391-396`).
- `role_mapping`: each value coerced `RBACRole(role_name)`; bad value → `OIDCConfigError`.
- `default_role` defaults to `RBACRole.VIEWER.value`; bad → `OIDCConfigError`.
- `scopes` defaults `["openid","profile","email"]`; must be list[str].
- `label` defaults `f"Sign in with {provider_id}"`.

**Active-profile cache** — `olympus-api/src/services/identity_config.py`:
- `get_identity_config() -> OIDCProviderConfig | None` (`identity_config.py:49-73`): module-level
  thread-locked cache (`_CACHE`, `_CACHE_LOADED`). Resolves profile root via `active_profile()` else
  `OLYMPUS_PROFILE`+`OLYMPUS_PROFILES_DIR`; `None` root → cache `None`. `OIDCConfigError` propagates.
- ⚠️ GOTCHA — cached process-wide. `refresh_identity_config()` (`:76-82`) wipes cache after profile
  switch; `set_identity_config_for_test(cfg)` (`:85-90`) injects directly. `/auth/config` & OIDC
  endpoints feature-detect off this: `None` ⇒ OIDC disabled ⇒ those endpoints 404.

### 1.6 Password hashing — `olympus-api/src/services/password.py`

- bcrypt direct (not passlib). `_DEFAULT_COST=12`, `_BCRYPT_MAX_LEN=72` (`password.py:18-19`).
- `_cost()` reads env `BCRYPT_COST`; must be int in `[4,15]` else `PasswordError` (`password.py:26-36`).
- `_encode(pw)`: utf-8 encode; if `> 72 bytes` → `PasswordError` (`password.py:39-45`).
- `hash_password(pw)`: empty → `PasswordError`; else `bcrypt.hashpw(encoded, gensalt(rounds=_cost()))`.
- `verify_password(pw, hashed|None) -> bool` (`password.py:57-70`): returns `False` if either falsy
  (covers OIDC users with NULL hash); `bcrypt.checkpw(...)`; on `PasswordError|ValueError` → `False`
  (never raises into auth paths). ⚠️ GOTCHA — wrong-but-valid AND malformed-hash both return `False`.

### 1.7 Error envelope (status→code mapping)

`olympus-api/src/middleware/error_handler.py`. `OlympusHTTPException(status_code, code, message, details=None)`
subclasses Starlette's HTTPException (`:20-32`). Global handlers (`register_error_handlers`):
- `OlympusHTTPException` → `{"error":{"code":<code>,"message":<detail>,"details":<details or {}>,"request_id":<id>}}`.
- plain `StarletteHTTPException`/`HTTPException` → code via map (`:63-71`):
  `400→BAD_REQUEST, 401→UNAUTHORIZED, 403→FORBIDDEN, 404→NOT_FOUND, 409→CONFLICT, 422→VALIDATION_ERROR,
  429→RATE_LIMITED`, else `"ERROR"`.
- `RequestValidationError` → 422 `VALIDATION_ERROR` with sanitized `details.errors` (non-primitive
  `ctx`/`input` stringified).
- unhandled `Exception` → 500 `INTERNAL_ERROR` "An internal error occurred".

### 1.8 Pagination contract — `olympus-api/src/middleware/pagination.py`

- `PaginationParams(page, per_page)`, `.offset = (page-1)*per_page` (`:16-25`).
- `get_pagination(page=Query(1, ge=1), per_page=Query(20, ge=1, le=100)) -> PaginationParams` (`:28-33`).
- `paginated_response(items, total, params) -> dict` (`:36-47`):
  `{"data": items, "pagination": {"page", "per_page", "total", "total_pages"}}` where
  `total_pages = max(1, ceil(total/per_page))`.

### 1.9 Portfolio-membership dependencies (used by agent_roles) — `olympus-api/src/dependencies.py`

- `verify_portfolio_access(db, user, portfolio_id)` (`dependencies.py:105-133`): if user has
  `PORTFOLIO_ADMIN` → return (bypass); elif `membership_svc.is_member(db, portfolio_id, user.sub)` →
  return; else raise `HTTPException(403, detail={"code":"PORTFOLIO_NOT_MEMBER","message":...})`.
- `filter_portfolio_ids_by_membership(db, user, candidate=None) -> list[UUID] | None` (`:389-411`):
  if `PORTFOLIO_ADMIN` → `None` (means "no filter, sees all"); else
  `member_ids = membership_svc.list_user_portfolio_ids(db, user.sub)`; if candidate None →
  `member_ids`; else intersection.
  ⚠️ GOTCHA — `None` return == admin/unfiltered; a `[]` return == non-admin with zero memberships
  (sees nothing). agent_roles passes this straight into the service as `portfolio_ids`.

---

## 2. ENDPOINTS — `auth.py` (10) — prefix `/api/v1/auth`, tags `["Auth"]`

### 2.1 `POST /api/v1/auth/service-token` — `auth.py:91-107`
- **Auth**: NONE (no `Depends`). Guarded by shared secret in body.
- **Request model** `ServiceTokenRequest` (`auth.py:77-82`):
  - `service: str` (required) — service identity.
  - `provisioning_secret: str` (required) — shared secret.
  - `ttl_seconds: int = DEFAULT_TTL_SECONDS(3600)`, constraints `gt=0, le=86400`.
- **Response model** `ServiceTokenResponse` (`auth.py:85-88`): `token: str`, `expires_in: int`, `service: str`. (200 default)
- **Handler** (PSEUDOCODE):
  ```
  expected = env "SERVICE_TOKEN_PROVISIONING_SECRET" default ""
  if not expected or body.provisioning_secret != expected:
      raise HTTPException(401, "Invalid provisioning secret")        # plain → code UNAUTHORIZED
  if body.service not in SERVICE_IDENTITIES:                          # ("agent-runtime","worker")
      raise HTTPException(400, f"Unknown service identity. Known: {list(SERVICE_IDENTITIES)}")
  token = issue_service_token(body.service, ttl_seconds=body.ttl_seconds)
  return ServiceTokenResponse(token=token, expires_in=body.ttl_seconds, service=body.service)
  ```
- ⚠️ GOTCHA — empty `SERVICE_TOKEN_PROVISIONING_SECRET` env ⇒ ALL requests 401 (fail-closed).
- **Status**: 200, 401, 400, 422 (body validation).

### 2.2 `POST /api/v1/auth/login` — `auth.py:129-158`
- **Auth**: NONE. `db: AsyncSession = Depends(get_db)`.
- **Request model** `LoginRequest` (`user.py:149-153`): `email_or_username: str` (min 3, max 255),
  `password: str` (min 1, max 256).
- **Response model** `TokenResponse` (`user.py:156-162`): `access_token: str`,
  `token_type: str = "bearer"`, `expires_in: int`, `user: UserProfile`.
- **Handler** (PSEUDOCODE):
  ```
  row = await get_user_by_login(db, body.email_or_username)          # case-insensitive email OR username, is_active=true only
  if row is None or not row.get("is_active", False):
      raise OlympusHTTPException(401, "INVALID_CREDENTIALS", "Invalid credentials")
  if row["identity_provider"] != "local":                            # SSO account
      raise OlympusHTTPException(401, "SSO_USER",
            "This account uses single sign-on. Use the SSO login button.")
  if not verify_password(body.password, row.get("password_hash")):
      raise OlympusHTTPException(401, "INVALID_CREDENTIALS", "Invalid credentials")
  await record_login(db, row["id"]); await db.commit()
  profile = await get_user(db, row["id"]); assert profile is not None
  return _profile_to_token(profile)
  ```
- `_profile_to_token(user)` (`auth.py:115-126`): `token = issue_user_token(user_id=user.id,
  username=user.username, roles=[r.value for r in user.roles], identity_provider=user.identity_provider)`;
  returns `TokenResponse(access_token=token, expires_in=DEFAULT_USER_TTL_SECONDS(28800), user=user)`.
- ⚠️ GOTCHA — OIDC-only users (`identity_provider != "local"`) are rejected here with code `SSO_USER`
  so a leaked local password can't bypass SSO. Inactive users and unknown users both → `INVALID_CREDENTIALS`.
- **Status**: 200, 401 (codes `INVALID_CREDENTIALS` / `SSO_USER`), 422.

### 2.3 `POST /api/v1/auth/logout` — `auth.py:161-168`
- **Auth**: NONE.
- **Request**: none.
- **Response**: `dict[str, bool]` → `{"success": True}`. (200, stateless — server holds no session.)
- **Status**: 200 always.

### 2.4 `GET /api/v1/auth/me` — `auth.py:176-212`
- **Auth**: `user: Annotated[CurrentUser, Depends(get_current_user)]` (any authenticated caller).
  `db: AsyncSession = Depends(get_db)`.
- **Request**: none.
- **Response model** `UserProfile` (see §5.1).
- **Handler** (PSEUDOCODE):
  ```
  profile = None
  try:    profile = await get_user(db, uuid.UUID(user.sub))           # sub may be UUID
  except (ValueError, TypeError):  profile = None                     # sub is "service:..." / "local-dev"
  if profile is not None:  return profile
  # service-token / dev-bypass synthetic profile (no DB row):
  now = datetime.now(timezone.utc)
  return UserProfile(
      id=UUID("00000000-0000-0000-0000-000000000000"),
      username=user.sub, email=f"{user.sub}@local", full_name=None,
      roles=user.roles, identity_provider="local", is_active=True,
      last_login_at=None, created_at=now, updated_at=now,
  )
  ```
- ⚠️ GOTCHA — never 404s. Non-UUID `sub` (service tokens, dev bypass) gets a synthetic all-zeros-id
  profile so the dashboard banner always renders. `roles` mirror the token's roles.
- **Status**: 200; 401 if no/invalid token (from `get_current_user`).

### 2.5 `GET /api/v1/auth/config` — `auth.py:220-236`
- **Auth**: NONE (public feature-flag probe; never emits secrets).
- **Request**: none.
- **Response model** `AuthModeConfig` (`user.py:171-178`): `local_enabled: bool`, `oidc_enabled: bool`,
  `oidc_provider_id: str|None`, `oidc_provider_label: str|None`, `oidc_login_url: str|None`.
- **Handler** (PSEUDOCODE):
  ```
  oidc = get_identity_config()
  if oidc is None:  return AuthModeConfig(local_enabled=True, oidc_enabled=False)
  return AuthModeConfig(local_enabled=True, oidc_enabled=True,
      oidc_provider_id=oidc.provider_id, oidc_provider_label=oidc.label,
      oidc_login_url="/api/v1/auth/oidc/login")
  ```
- **Status**: 200.

### 2.6 `GET /api/v1/auth/oidc/login` — `auth.py:287-305`
- **Auth**: NONE. Params: `request: Request`, `redirect_after: str|None = None` (query).
- **Response**: `RedirectResponse` 302 to the IdP `/authorize` URL.
- **Handler** (PSEUDOCODE):
  ```
  config = _require_oidc_config()                                     # 404 OIDC_DISABLED if get_identity_config() is None
  client = _build_oidc_client(config)                                 # OIDCClient(config); overridable in tests
  verifier, challenge = client.generate_pkce()
  state = secrets.token_urlsafe(32)
  _clean_oidc_states()                                                # evict entries older than _OIDC_STATE_TTL
  _OIDC_STATES[state] = _OIDCStateEntry(verifier, redirect_after)     # in-memory PKCE store
  url = client.get_authorization_url(state=state, code_challenge=challenge)
  log.info("oidc.login.redirect", provider=config.provider_id, state=state[:6]+"...")
  return RedirectResponse(url=url, status_code=302)
  ```
- **In-memory state store** (`auth.py:247-269`): `_OIDC_STATES: dict[str,_OIDCStateEntry]`;
  `_OIDCStateEntry(verifier, created_at=time.time(), redirect_after)`;
  `_OIDC_STATE_TTL = float(env "OIDC_STATE_TTL" default "300")` (5 min);
  `_clean_oidc_states()` pops entries where `now - created_at > _OIDC_STATE_TTL`.
- `_require_oidc_config()` (`auth.py:271-279`): `cfg = get_identity_config()`; if `None` raise
  `OlympusHTTPException(404, "OIDC_DISABLED", "Single sign-on is not enabled for this deployment.")`.
- ⚠️ GOTCHA — state store is **process-local** (not Redis). Horizontal replicas do not share PKCE
  state ⇒ callback must hit the SAME replica that issued the login, or you get 400 `OIDC_UNKNOWN_STATE`.
- **Status**: 302; 404 (`OIDC_DISABLED`) when SSO off.

### 2.7 `GET /api/v1/auth/oidc/callback` — `auth.py:308-370`
- **Auth**: NONE. Params: `request: Request`, `code: str|None`, `state: str|None`, `error: str|None`
  (all query), `db: AsyncSession = Depends(get_db)`.
- **Response**: `Any` — either `TokenResponse` (JSON 200, programmatic clients) OR `RedirectResponse`
  302 to `{redirect_after}#access_token=...&expires_in=...` (browser clients).
- **Handler** (PSEUDOCODE, every branch):
  ```
  if error:
      raise OlympusHTTPException(400, "OIDC_PROVIDER_ERROR", f"OIDC provider returned error: {error}")
  if not code or not state:
      raise OlympusHTTPException(400, "OIDC_MISSING_PARAMS", "Missing 'code' or 'state' query parameter")
  entry = _OIDC_STATES.pop(state, None)                               # single-use; pop immediately
  if entry is None:
      raise OlympusHTTPException(400, "OIDC_UNKNOWN_STATE", "Unknown or expired OIDC state")
  _clean_oidc_states()
  config = _require_oidc_config()                                     # 404 OIDC_DISABLED
  client = _build_oidc_client(config)
  try:
      tokens   = await client.exchange_code(code, entry.verifier)
      id_token = tokens.get("id_token")
      if not id_token:  raise OIDCAuthError("Provider response missing id_token")
      claims   = await client.validate_id_token(id_token)
  except OIDCAuthError as exc:
      log.warning("oidc.callback.failed", error=str(exc))
      raise OlympusHTTPException(401, "OIDC_AUTH_FAILED", str(exc)) from exc
  profile = await upsert_oidc_user(
      db,
      provider_id=config.provider_id,
      external_id=claims.subject,
      email=claims.email or f"{claims.subject}@{config.provider_id}",
      username=claims.preferred_username or claims.subject,
      full_name=claims.full_name,
      default_roles=client.resolve_roles(claims) or [RBACRole.VIEWER],
  )
  await record_login(db, profile.id); await db.commit()
  token_response = _profile_to_token(profile)
  if entry.redirect_after:                                           # browser path
      redirect = f"{entry.redirect_after}#access_token={token_response.access_token}&expires_in={token_response.expires_in}"
      return RedirectResponse(url=redirect, status_code=302)
  return token_response                                              # API path → JSON TokenResponse
  ```
- ⚠️ GOTCHA — state is consumed (`pop`) BEFORE the OIDC config check, so a replay of a valid state
  returns 400 `OIDC_UNKNOWN_STATE` even if everything else is fine. ⚠️ GOTCHA — token lands on a URL
  **fragment** (`#access_token=...`), never a query param, so it isn't sent to the server / logged.
- **`upsert_oidc_user`** (`services/user.py:378-436`) — PSEUDOCODE:
  ```
  full_provider = provider_id if provider_id.startswith("oidc:") else f"oidc:{provider_id}"
  provider = identity_provider_id(full_provider)                     # validates slug shape
  existing = await get_user_by_external_identity(db, provider, external_id)
  if existing:
      UPDATE user_account SET email, username, full_name, updated_at WHERE id=existing.id  # roles UNTOUCHED
      return await get_user(db, existing["id"])
  return await create_user(db, username, email, full_name,
      roles=default_roles or [VIEWER], identity_provider=provider, external_id=external_id, password=None)
  ```
  ⚠️ GOTCHA — idempotent on `(provider, external_id)`; repeat logins refresh display attrs but
  **preserve roles** so admin role edits survive re-login. Roles only set on first-login create.
- **Status**: 200 (JSON) or 302 (browser); 400 (`OIDC_PROVIDER_ERROR` / `OIDC_MISSING_PARAMS` /
  `OIDC_UNKNOWN_STATE`); 401 (`OIDC_AUTH_FAILED`); 404 (`OIDC_DISABLED`).

### 2.8 `GET /api/v1/auth/roles` — `auth.py:405-414`
- **Auth**: `_user: Annotated[CurrentUser, Depends(require_role(RBACRole.PORTFOLIO_ADMIN))] = None`
  → **admin-only**. ⚠️ GOTCHA — default `= None` so the param is keyword-defaulted; FastAPI still
  resolves the dependency (the default is never used).
- **Request**: none.
- **Response**: `dict` → `{"data": [{"role": <value>, "description": <str>, "scope": <str>}, ...]}`.
- **Handler**: iterates `_ROLE_DESCRIPTIONS` (`auth.py:383-402`) — a `dict[RBACRole,(desc,scope)]`:
  ```
  PORTFOLIO_ADMIN   → ("Portfolio administration (user + config management)", "platform")
  PORTFOLIO_MANAGER → ("Wave planning, app onboarding, gate decisions", "portfolio")
  TECH_LEAD         → ("Technical review of gates and artifacts", "line")
  ARCH_LEAD         → ("Architecture review of gates and artifacts", "line")
  COMPLIANCE_LEAD   → ("Compliance review of gates and artifacts", "line")
  OPERATIONS_LEAD   → ("Operations review of gates and artifacts", "line")
  SAFETY_BOARD      → ("Safety-critical review for tier-1 applications", "safety")
  VIEWER            → ("Read-only access", "platform")
  SERVICE           → ("Platform service account (agent-runtime, worker)", "internal")
  ```
  ⚠️ GOTCHA — emits all **9** roles (includes SERVICE), in dict-insertion order above.
- **Status**: 200, 401 (no token), 403 (not admin).

### 2.9 `GET /api/v1/auth/users` — `auth.py:417-434`  (spec-alias for `GET /users`)
- **Auth**: `_user: Depends(require_role(RBACRole.PORTFOLIO_ADMIN)) = None` → admin-only.
  `pagination: PaginationParams = Depends(get_pagination)`, `db = Depends(get_db)`.
- **Request**: query `page` (≥1, default 1), `per_page` (1–100, default 20).
- **Response**: `dict` paginated envelope (see §1.8). `data` = list of `UserProfile.model_dump(mode="json")`.
- **Handler**: `users, total = await list_users(db, offset=pagination.offset, limit=pagination.per_page,
  include_inactive=False)` then `paginated_response([u.model_dump(mode="json") for u in users], total, pagination)`.
- ⚠️ GOTCHA — this alias hard-codes `include_inactive=False` (no query toggle), unlike the primary
  `GET /users` which exposes `include_inactive`.
- **Status**: 200, 401, 403, 422.

### 2.10 `PUT /api/v1/auth/users/{user_id}/roles` — `auth.py:437-450`
- **Auth**: `_user: Depends(require_role(RBACRole.PORTFOLIO_ADMIN)) = None` → admin-only.
  Path `user_id: uuid.UUID`. `db = Depends(get_db)`.
- **Request model** `RoleAssignmentRequest` (`user.py:165-168`): `roles: list[RBACRole]`.
- **Response model** `UserProfile`.
- **Handler** (PSEUDOCODE):
  ```
  profile = await update_user(db, user_id, roles=body.roles)         # patch-style; replaces roles
  if profile is None:  await db.rollback(); raise OlympusHTTPException(404,"USER_NOT_FOUND",f"User {user_id} not found")
  await db.commit(); return profile
  ```
- **Status**: 200, 401, 403, 404 (`USER_NOT_FOUND`), 422.

---

## 3. ENDPOINTS — `users.py` (6) — prefix `/api/v1/users`, tags `["Users"]`

Helpers (`users.py:48-59`):
- `_is_self(current, user_id) -> bool`: `current.sub == str(user_id)`.
- `_require_admin_or_self(current, user_id)`: if `current.has_role(PORTFOLIO_ADMIN)` → ok; elif
  `_is_self` → ok; else raise `OlympusHTTPException(403, "FORBIDDEN", "Only an admin or the user
  themselves may access this record.")`.

### 3.1 `GET /api/v1/users` — `users.py:67-85`  (list)
- **Auth**: `_user: Depends(require_role(RBACRole.PORTFOLIO_ADMIN)) = None` → admin-only.
- **Request**: query `include_inactive: bool = False`; `pagination` (`page`,`per_page`); `db`.
- **Response**: `dict` paginated envelope; `data` = `[UserProfile.model_dump(mode="json")]`.
- **Handler**: `users, total = await list_users(db, offset, limit, include_inactive)`;
  `paginated_response(...)`.
- **Status**: 200, 401, 403, 422.

### 3.2 `GET /api/v1/users/{user_id}` — `users.py:88-99`  (detail)
- **Auth**: `current: Depends(get_current_user)` (any auth) + `_require_admin_or_self` in body.
  Path `user_id: uuid.UUID`. `db`.
- **Response model** `UserProfile`.
- **Handler** (PSEUDOCODE):
  ```
  _require_admin_or_self(current, user_id)                            # 403 FORBIDDEN if neither
  profile = await get_user(db, user_id)
  if profile is None:  raise OlympusHTTPException(404,"USER_NOT_FOUND",f"User {user_id} not found")
  return profile
  ```
- ⚠️ GOTCHA — authorization (admin-or-self) runs BEFORE existence; a non-admin asking for another
  id gets 403 even if that id doesn't exist (no enumeration). Self/admin asking for a missing id → 404.
- **Status**: 200, 401, 403, 404.

### 3.3 `POST /api/v1/users` — `users.py:107-137`  (create, status_code=201)
- **Auth**: `_user: Depends(require_role(RBACRole.PORTFOLIO_ADMIN)) = None` → admin-only.
- **Request model** `UserCreateRequest` (`user.py:93-119`):
  - `username: str` (min 3, max 150; validator `_validate_username` regex `^[A-Za-z0-9._@-]{3,150}$`).
  - `email: str` (validator `_validate_email` regex `^[A-Za-z0-9._%+\-]+@[A-Za-z0-9.\-]+\.[A-Za-z]{2,}$`).
  - `full_name: str|None` (max 255).
  - `roles: list[RBACRole] = [RBACRole.VIEWER]`.
  - `identity_provider: str = "local"` (validator `identity_provider_id`: `"local"` or `"oidc:<slug>"`,
    slug regex `^[a-z0-9][a-z0-9_-]*$`).
  - `external_id: str|None` (max 255).
  - `password: str|None` (min 12, max 256).
- **Response model** `UserProfile` (201).
- **Handler** (PSEUDOCODE):
  ```
  try:
      profile = await create_user(db, username, email, full_name, roles,
                                  identity_provider, external_id, password)
  except ValueError as exc:                                          # invariant breach (see create_user)
      await db.rollback(); raise OlympusHTTPException(400, "USER_INVALID", str(exc))
  try:
      await db.commit()
  except IntegrityError as exc:                                      # unique(email/username/external) clash
      await db.rollback()
      raise OlympusHTTPException(409, "USER_CONFLICT",
            "A user with that email, username, or external identity already exists.")
  return profile
  ```
- **`create_user` invariants** (`services/user.py:178-262`):
  - local (`identity_provider == "local"`): `password` required else `ValueError`; `external_id` MUST be
    None else `ValueError`; hashes password.
  - oidc (`oidc:<slug>`): `password` MUST be None else `ValueError`; `external_id` required else
    `ValueError`; `password_hash = None`.
  - INSERTs roles as JSONB (`json.dumps([r.value...])`), `is_active=True`, fresh uuid4 id + UTC timestamps.
- **Status**: 201, 400 (`USER_INVALID`), 401, 403, 409 (`USER_CONFLICT`), 422.

### 3.4 `PUT /api/v1/users/{user_id}` — `users.py:140-177`  (update)
- **Auth**: `current: Depends(get_current_user)` + `_require_admin_or_self`; admin-only for role/active
  fields (enforced in body). Path `user_id: uuid.UUID`. `db`.
- **Request model** `UserUpdateRequest` (`user.py:122-137`): all optional —
  `email: str|None` (validated if present), `full_name: str|None` (max 255),
  `roles: list[RBACRole]|None`, `is_active: bool|None`.
- **Response model** `UserProfile`.
- **Handler** (PSEUDOCODE, every branch):
  ```
  _require_admin_or_self(current, user_id)                            # 403 FORBIDDEN
  admin_only = (body.roles is not None) or (body.is_active is not None)
  if admin_only and not current.has_role(PORTFOLIO_ADMIN):
      raise OlympusHTTPException(403, "ADMIN_ONLY",
            "Role and activation changes require the portfolio_admin role.")
  profile = await update_user(db, user_id, email=body.email, full_name=body.full_name,
                              roles=body.roles, is_active=body.is_active)
  if profile is None:  await db.rollback(); raise OlympusHTTPException(404,"USER_NOT_FOUND",...)
  try:    await db.commit()
  except IntegrityError:  await db.rollback()
                          raise OlympusHTTPException(409,"USER_CONFLICT","A user with that email already exists.")
  return profile
  ```
- ⚠️ GOTCHA — a non-admin self-editing can change `email`/`full_name` but NOT `roles`/`is_active`
  (those trigger `ADMIN_ONLY` 403). `update_user` ignores None fields; if every field is None it just
  re-reads + returns the row (no UPDATE).
- **Status**: 200, 401, 403 (`FORBIDDEN` or `ADMIN_ONLY`), 404, 409, 422.

### 3.5 `DELETE /api/v1/users/{user_id}` — `users.py:180-200`  (soft-delete, status_code=204)
- **Auth**: `current: Annotated[CurrentUser, Depends(require_role(RBACRole.PORTFOLIO_ADMIN))]`
  → admin-only (no `=None` default here; it's a positional Annotated dependency). Path
  `user_id: uuid.UUID`. `db`.
- **Request**: none. **Response**: none (204).
- **Handler** (PSEUDOCODE):
  ```
  if _is_self(current, user_id):
      raise OlympusHTTPException(400, "CANNOT_DELETE_SELF", "Admins cannot deactivate their own account.")
  ok = await deactivate_user(db, user_id)                            # UPDATE is_active=false WHERE id AND is_active=true
  if not ok:
      raise OlympusHTTPException(404, "USER_NOT_FOUND", f"User {user_id} not found or already inactive")
  await db.commit()
  ```
- ⚠️ GOTCHA — soft delete only (`is_active=false`); already-inactive or unknown id both → 404.
  Admin cannot delete self → 400 `CANNOT_DELETE_SELF`.
- **Status**: 204, 400 (`CANNOT_DELETE_SELF`), 401, 403, 404.

### 3.6 `POST /api/v1/users/{user_id}/password` — `users.py:208-255`  (status_code=204)
- **Auth**: `current: Depends(get_current_user)` + `_require_admin_or_self`. Path `user_id: uuid.UUID`. `db`.
- **Request model** `PasswordUpdateRequest` (`user.py:140-146`): `current_password: str|None = None`,
  `new_password: str` (min 12, max 256).
- **Response**: none (204).
- **Handler** (PSEUDOCODE, every branch):
  ```
  _require_admin_or_self(current, user_id)                            # 403 FORBIDDEN
  if not current.has_role(PORTFOLIO_ADMIN):                          # self-service path — verify current pw
      row = await get_user_by_login(db, current.sub)                 # sub may be UUID OR service id
      if row is None:                                                # fallback: look up by user_id (raw SQL)
          row = SELECT id, password_hash, identity_provider FROM user_account WHERE id = :user_id  (first mapping)
      if (not body.current_password) or (not verify_password(body.current_password, (row or {}).get("password_hash"))):
          raise OlympusHTTPException(401, "INVALID_CREDENTIALS", "Current password is incorrect.")
  try:
      await set_password(db, user_id, body.new_password)             # rejects OIDC accounts (ValueError)
  except LookupError as exc:                                         # user not found
      await db.rollback(); raise OlympusHTTPException(404, "USER_NOT_FOUND", str(exc))
  except ValueError as exc:                                          # OIDC account — no local pw
      await db.rollback(); raise OlympusHTTPException(400, "PASSWORD_NOT_APPLICABLE", str(exc))
  await db.commit()
  ```
- **`set_password`** (`services/user.py:302-339`): SELECT `identity_provider`; not found → `LookupError`;
  if `!= "local"` → `ValueError` ("Cannot set password on an OIDC-managed account…"); else UPDATE hash.
- ⚠️ GOTCHA — admin path skips current-password verification entirely (reset any local user). Non-admin
  MUST supply correct `current_password`. ⚠️ GOTCHA — fallback raw-SQL lookup uses `__import__("sqlalchemy").text(...)`
  inline (`users.py:233`) when `get_user_by_login` misses (e.g. service-identity `sub`).
- **Status**: 204, 400 (`PASSWORD_NOT_APPLICABLE`), 401 (`INVALID_CREDENTIALS`), 403 (`FORBIDDEN`),
  404 (`USER_NOT_FOUND`), 422.

---

## 4. ENDPOINTS — `me.py` (1) & `agent_roles.py` (1)

### 4.1 `GET /api/v1/me/portfolios` — `me.py:30-91`, tags `["Me"]`
- **Auth**: `user: Annotated[CurrentUser, Depends(get_current_user)]` (any auth).
  `db: Annotated[AsyncSession, Depends(get_db)]`.
- **Request**: none.
- **Response model** `list[MyPortfolioListItem]` (`models/portfolio_membership.py:42-48`):
  each item `portfolio_id: UUID`, `portfolio_name: str`, `role: RBACRole`, `granted_at: datetime`.
- **Handler** (PSEUDOCODE, both branches):
  ```
  if user.has_role(PORTFOLIO_ADMIN):                                 # admin → every portfolio
      rows = SELECT id AS portfolio_id, name AS portfolio_name,
                    :role AS role, created_at AS granted_at
             FROM portfolio ORDER BY name
             (param role = RBACRole.PORTFOLIO_ADMIN.value)
      return [MyPortfolioListItem(portfolio_id, portfolio_name, role=RBACRole(role), granted_at) for r in rows]
  # non-admin → membership rows joined to portfolio name
  rows = SELECT m.portfolio_id, p.name AS portfolio_name, m.role, m.granted_at
         FROM portfolio_membership m JOIN portfolio p ON p.id = m.portfolio_id
         WHERE m.user_id = :uid ORDER BY p.name        (param uid = user.sub)
  return [MyPortfolioListItem(...) for r in rows]
  ```
- ⚠️ GOTCHA — for admins, every row's `role` is reported as `portfolio_admin` regardless of any actual
  membership rows; sorted by `name`. Non-admin keyed on `user.sub` (string) vs `m.user_id`.
- **Status**: 200; 401 if no/invalid token.

### 4.2 `GET /api/v1/agent-roles` — `agent_roles.py:46-76`, tags `["Agent Roles"]`
- **Auth**: TWO dependencies (both resolve `get_current_user` under the hood):
  - `_user: CurrentUser = Depends(require_role(*VIEWER_PLUS))` — any of the 9 roles. `VIEWER_PLUS`
    (`agent_roles.py:31-41`) = `[VIEWER, TECH_LEAD, ARCH_LEAD, COMPLIANCE_LEAD, OPERATIONS_LEAD,
    SAFETY_BOARD, PORTFOLIO_MANAGER, PORTFOLIO_ADMIN, SERVICE]`.
  - `user: CurrentUser = Depends(get_current_user)` — the resolved caller used for scoping.
- **Request** (query):
  - `portfolio_id: uuid.UUID | None = Query(None, ...)` — scopes per-role activity counts to a portfolio.
  - `since: str = Query("30d", pattern="^(7d|30d|all)$", ...)` — ⚠️ GOTCHA — reserved/no-op
    (`# noqa: ARG001`); impl ALWAYS reports a fixed 30-day window regardless of value. Pattern is still
    enforced (bad value → 422).
- **Response model** `AgentRoleListResponse` (`models/agent_role.py:56-59`): `data: list[AgentRoleSummary]`.
  `AgentRoleSummary` (`models/agent_role.py:27-53`): `name: str`, `description: str=""`,
  `model_tier: str|None`, `preferred_model_tier: str|None`, `assembly_lines: list[str]=[]`,
  `skill_ids: list[str]=[]`, `capabilities: list[str]=[]`, `version: str="0.0.0"`, `tasks_total: int=0`,
  `tasks_last_30d: int=0`, `success_rate_30d: float|None` (ge 0, le 1), `last_active_at: datetime|None`,
  `status: Literal["active","declared-inactive"]="declared-inactive"`.
- **Handler** (PSEUDOCODE):
  ```
  if portfolio_id is not None:
      await verify_portfolio_access(db, user, portfolio_id)          # 403 PORTFOLIO_NOT_MEMBER if not member (non-admin)
  member_ids = await filter_portfolio_ids_by_membership(db, user)    # None for admin; list (maybe []) otherwise
  roles = await agent_roles_svc.get_agent_roles(db, portfolio_id=portfolio_id, portfolio_ids=member_ids)
  return AgentRoleListResponse(data=roles)
  ```
- **`get_agent_roles` service** (`services/agent_roles.py:331-385`) — PSEUDOCODE:
  ```
  role_entries = load_agent_roles_config(None)                       # parse agents.yaml (search order; [] on miss)
  if not role_entries:  return []
  now = utcnow(); since_30d = now - 30 days
  per_skill = await _aggregate_per_skill(db, since_30d=since_30d, portfolio_id=portfolio_id, portfolio_ids=portfolio_ids)
  for role in role_entries:
      tier, preferred = _resolve_model_tier(role)                    # model_tier defaults to preferred_model_tier
      agg = _combine_per_role(role, per_skill)                       # sum across role.skill_ids
      status = "active" if agg.tasks_last_30d > 0 else "declared-inactive"
      emit AgentRoleSummary(name, description, model_tier=tier, preferred_model_tier=preferred,
           assembly_lines, skill_ids, capabilities, version, tasks_total, tasks_last_30d,
           success_rate_30d, last_active_at, status)
  ```
- **`_aggregate_per_skill`** (`agent_roles.py:178-271`) — ⚠️ GOTCHA branches:
  - `has_filter = portfolio_id is not None OR portfolio_ids is not None`.
  - if `portfolio_ids is not None` and EMPTY `[]` → returns `{}` immediately (non-admin, no memberships).
  - filtered branch INNER JOINs `application` (excludes wave-scoped `agent_task` rows where
    `application_id IS NULL`); unfiltered branch queries `agent_task` alone (spans all portfolios).
  - aggregates per `skill_id`: `tasks_total`, `tasks_30d` (started_at≥since), `success_30d`
    (status='completed' in window), `terminal_30d` (status IN completed/failed/timed_out in window),
    `last_active_at=MAX(started_at)`.
  - `_safe_execute` swallows missing-relation/column errors (pre-migration envs) → `[]`.
- **`_combine_per_role`** (`agent_roles.py:274-307`): sums per-skill aggs over `role.skill_ids`;
  `success_rate_30d = success_30d / terminal_30d` only if `terminal_30d` truthy else `None`;
  `last_active_at` = max over skills.
- ⚠️ GOTCHA — `agents.yaml` resolved by `_worker_config_dir()` (`agent_roles.py:49-98`): env
  `OLYMPUS_WORKER_CONFIG_DIR` first, else walk up from module/CWD for `olympus-worker/config/`, else
  `/app/repo/olympus-worker/config` or `/app/olympus-worker/config`; `None` (unfound) ⇒ empty list ⇒
  endpoint returns `{"data": []}` (never 500).
- **Status**: 200; 401 (no token); 403 (`PORTFOLIO_NOT_MEMBER` when `portfolio_id` given and caller not
  a member); 422 (bad `since` pattern / bad `portfolio_id` uuid).

---

## 5. SHARED MODELS

### 5.1 `UserProfile` — `olympus-api/src/models/user.py:78-90`
```
id: uuid.UUID
username: str
email: str
full_name: str | None = None
roles: list[RBACRole]
identity_provider: str = "local"          # IDENTITY_LOCAL
is_active: bool = True
last_login_at: datetime | None = None
created_at: datetime
updated_at: datetime
```
`_row_to_profile` (`services/user.py:37-64`): coerces JSONB/str `roles`; tolerates & DROPS unknown
role strings (never 500s a listing); defaults `identity_provider` to `"local"`, `is_active` to True.

### 5.2 Validators (`models/user.py`)
- `EMAIL_PATTERN` (`:23-25`): `^[A-Za-z0-9._%+\-]+@[A-Za-z0-9.\-]+\.[A-Za-z]{2,}$` (lightweight; no
  email-validator dep). `_validate_email` strips + fullmatch else `ValueError`.
- `USERNAME_PATTERN` (`:62`): `^[A-Za-z0-9._@-]{3,150}$`.
- `identity_provider_id(value)` (`:41-59`): accepts `"local"` or `"oidc:<slug>"` where slug matches
  `^[a-z0-9][a-z0-9_-]*$`; else `ValueError`.

---

## 6. AUTH MATRIX (quick reference)

| Method | Path | Auth dependency | Required role(s) | Success | Notable error codes |
|---|---|---|---|---|---|
| POST | /api/v1/auth/service-token | none (shared secret) | — | 200 | 401 (bad secret), 400 (unknown service) |
| POST | /api/v1/auth/login | none | — | 200 | 401 INVALID_CREDENTIALS / SSO_USER |
| POST | /api/v1/auth/logout | none | — | 200 | — |
| GET | /api/v1/auth/me | get_current_user | any auth | 200 | 401 |
| GET | /api/v1/auth/config | none | — | 200 | — |
| GET | /api/v1/auth/oidc/login | none | — | 302 | 404 OIDC_DISABLED |
| GET | /api/v1/auth/oidc/callback | none | — | 200/302 | 400 OIDC_*, 401 OIDC_AUTH_FAILED, 404 OIDC_DISABLED |
| GET | /api/v1/auth/roles | require_role | PORTFOLIO_ADMIN | 200 | 401, 403 |
| GET | /api/v1/auth/users | require_role | PORTFOLIO_ADMIN | 200 | 401, 403 |
| PUT | /api/v1/auth/users/{user_id}/roles | require_role | PORTFOLIO_ADMIN | 200 | 404 USER_NOT_FOUND |
| GET | /api/v1/users | require_role | PORTFOLIO_ADMIN | 200 | 401, 403 |
| GET | /api/v1/users/{user_id} | get_current_user + admin-or-self | self or PORTFOLIO_ADMIN | 200 | 403 FORBIDDEN, 404 |
| POST | /api/v1/users | require_role | PORTFOLIO_ADMIN | 201 | 400 USER_INVALID, 409 USER_CONFLICT |
| PUT | /api/v1/users/{user_id} | get_current_user + admin-or-self | self (limited) / admin | 200 | 403 ADMIN_ONLY, 404, 409 |
| DELETE | /api/v1/users/{user_id} | require_role | PORTFOLIO_ADMIN | 204 | 400 CANNOT_DELETE_SELF, 404 |
| POST | /api/v1/users/{user_id}/password | get_current_user + admin-or-self | self (verify) / admin (reset) | 204 | 401 INVALID_CREDENTIALS, 400 PASSWORD_NOT_APPLICABLE, 404 |
| GET | /api/v1/me/portfolios | get_current_user | any auth | 200 | 401 |
| GET | /api/v1/agent-roles | require_role(*VIEWER_PLUS) + get_current_user | any of 9 | 200 | 403 PORTFOLIO_NOT_MEMBER, 422 |

---

## 7. UNDETERMINED / NOTES
- `record_login`, `deactivate_user`, `list_users`, `get_user`, `update_user`, `create_user`,
  `get_user_by_login`, `get_user_by_external_identity`, `set_password`, `upsert_oidc_user` are raw-SQL
  against table `user_account` (migration 026) — reproduced inline where load-bearing; full DDL belongs
  to the Phase 9 data-layer spec.
- `membership_svc.is_member` / `list_user_portfolio_ids` (used by dependencies) live in
  `src/services/portfolio_membership.py` — out of scope for this file (data/services phase); behavior
  used here is documented in §1.9.
- `active_profile()` (profile activation) referenced by `identity_config` is in
  `src/services/profile_activation.py` — out of scope; only its None/non-None contract matters here.
