# Skill Authoring Contract (ATOMIC regeneration spec)

> **Purpose.** This document is the **complete, self-contained contract** for authoring a conformant Olympus skill. It is written for a skill-builder environment that will **never see the Olympus runtime code**. Every behavior the runtime imposes on a skill is restated here. If you follow this document exactly, your skill will load, receive the documented prompt envelope, and pass validation — without reading any runtime source.
>
> **Behavioral-parity bar.** A skill is a *prompt template* plus a *machine-checkable output contract* plus *registry metadata*. This spec captures all three precisely. Where a value, ordering, or casing is load-bearing it is marked ⚠️ GOTCHA.
>
> **Citations.** Each non-trivial claim cites `path:line` against the original repository so the claim is auditable even though the author cannot open the file. Primary sources:
> - `cross-cutting/skills/CONVENTIONS.md` — authoritative skill schema (the "spec of record" for authors).
> - `cross-cutting/skills/registry.yaml` — registry schema documented in its header comment + every entry.
> - `olympus-agent-runtime/src/services/skill_loader.py` — how SKILL.md frontmatter + enrichment is parsed (the loader).
> - `olympus-agent-runtime/src/services/agent_executor.py` `build_system_prompt()` — the exact prompt envelope assembly.
> - `olympus-agent-runtime/src/services/output_validator.py` — the (agent-runtime) validation contract + retry-feedback shape. ⚠️ Dormant on the live API-load path — see top-of-§5.
> - `olympus-api/src/services/return_payload_validator.py` — the place `output_schemas` IS enforced live: the human-paired RETURN-payload validator (re-parses your SKILL.md frontmatter from disk). See top-of-§5.
> - `olympus-agent-runtime/src/services/profile_context.py` — mission/program context injection.
> - `schemas/` (repo-root) — the JSON Schemas an output is validated against (the SAME schema set captured by this spec set; never copy them — declare against their relative paths).

---

## 0. Two distinct schemas, one skill — read this first

⚠️ **GOTCHA — there are TWO separate metadata documents per skill, with DIFFERENT field names. Do not conflate them.**

1. **`SKILL.md` YAML frontmatter** — lives at `cross-cutting/skills/<skill-id>/SKILL.md`. Parsed by the **runtime loader** (`skill_loader.py`). Field names are: `name`, `description`, `agent`, `allowed-tools`, `output_schemas`, `disable-model-invocation`. This is what shapes the prompt the agent sees.

2. **`registry.yaml` entry** — one list item under `skills:` in `cross-cutting/skills/registry.yaml`. Parsed by the **API/catalog layer** (not by the agent runtime). Field names are: `id`, `version`, `category`, `enrichment`, `line`, `step`, `is_orchestration`, `variants`, `profile_overrides`, `depends_on`, plus optional `currency` and benchmark-metadata blocks. This is what CI enforces and what the dashboard/governance tooling reads.

The task brief's field list maps onto these two documents as follows (the brief uses some abstract names; here are the real ones):

| Brief name | Real field | Lives in | Notes |
|------------|-----------|----------|-------|
| `id` | `id` (registry) / `name` (frontmatter — must equal the id) | both | `name` MUST equal the directory name and the registry `id`. |
| `version` | `version` | registry | semver. |
| `category` | `category` | registry | free-text category label (closed set in practice, see §7.3). |
| `agent_role` | `agent` | frontmatter | model tier: `opus`/`sonnet`/`haiku`. |
| `depends_on` | `depends_on` | registry | required list (may be empty). |
| `output_schemas` | `output_schemas` | frontmatter | your declared output contract. ⚠️ **Authoritative source-of-truth, but NOT runtime-enforced on the agent-runtime A2A dispatch path** (the dispatch API's `SkillDetail` does not carry this field, so the runtime gets `[]`). It IS enforced live by the human-paired RETURN-payload validator and is honored on the deprecated filesystem load path. See the prominent ⚠️ GOTCHA at the top of §5. |
| `inputs` | (prose `## Inputs` section) | SKILL.md body | inputs are documented prose, not a structured field (see §3, §6). |
| currency block | `currency` | registry | optional recency metadata. |
| `is_orchestration` | `is_orchestration` | registry | `false` for real skills. |

⚠️ **GOTCHA — `id`/`category`/`version`/`depends_on`/`is_orchestration` are NOT frontmatter fields.** They are registry fields. The runtime loader never reads them. The only frontmatter fields the loader recognizes are `name`, `description`, `agent`, `allowed-tools`, `output_schemas` (`skill_loader.py:88-93`). Any other frontmatter key (e.g. `required_outputs`) is silently ignored by the loader (`skill_loader.py:88-93` only pulls those five keys; everything else in the dict is dropped). The `disposition-recommender` SKILL.md declares a `required_outputs:` block that the loader does not consume — it is documentation only.

---

## 1. What a skill is (and is not)

- A skill is a **prompt template**: the markdown body below the SKILL.md frontmatter is loaded verbatim as (part of) the LLM **system prompt** at dispatch time (`CONVENTIONS.md:11`; loader stores the body as `system_prompt`, `skill_loader.py:108`; executor appends it, `agent_executor.py:216-217`).
- A skill is **one prompt → one LLM call → one (or a few) artifact(s)** (`CONVENTIONS.md:19`).
- A skill is **NOT** orchestration. Fan-out, sequencing, merge/synthesis, and conditional branching live in Temporal workflows, never in a SKILL.md (`CONVENTIONS.md:13`, `CONVENTIONS.md:20-24`).

**Skill-vs-orchestration test** (`CONVENTIONS.md:17-24`):

| Pattern | It is a… |
|---------|----------|
| One prompt → one LLM call → one artifact | **Skill** |
| Fan out to N skills, then merge | **Orchestration** (workflow, not a skill) |
| Pick one of N skills based on a runtime condition | **Orchestration** |
| Sequence several skills with gates between them | **Orchestration** |

If the step's job is "do the thinking," it is a skill. If its job is "pick who thinks next," it is orchestration (`CONVENTIONS.md:24`).

---

## 2. Directory + naming rules

- One skill = one directory: `cross-cutting/skills/<skill-id>/` containing `SKILL.md` (required) and optional `references/`, `assets/`, `scripts/`, `config.json` (`CONVENTIONS.md:56-99`, enrichment levels §4 below).
- **Skill ids are descriptive noun phrases, lowercase, hyphen-separated.** Name what the skill *produces/evaluates*, not an imperative verb (`CONVENTIONS.md:32-36`).
  - ✅ `legacy-business-rule-extractor`, `redundancy-analyzer`, `disposition-recommender`, `drift-detection-architecture`, `tdd-generation`.
  - ❌ `extract-business-rules` (imperative → looks like orchestration), `check-drift` (too generic).
- ⚠️ **GOTCHA — the prefixes `plan-*`, `step-*`, `execute-*` are RESERVED for orchestration step names and MUST NOT be a SKILL.md directory name** (`CONVENTIONS.md:40`, `CONVENTIONS.md:44`). CI flags any skill directory using these prefixes (`CONVENTIONS.md:265`).
- **Variant naming**: a technology/archetype variant is `base + suffix` and lives in its own directory. The base stays at `<base>/`; variants at `<base>-<suffix>/` (`CONVENTIONS.md:48-52`). Example: base `extraction/`, variants `extraction-cobol/`, `extraction-java/`, `extraction-python/`, `batch-extraction/`. The registry declares the variant relationship (see §7.4). Variant **dispatch is decided by the workflow at runtime**, not by the skill (`registry.yaml` `code-generation` comment, ~`registry.yaml:2386-2393`).
- ⚠️ **GOTCHA — `name` in frontmatter MUST exactly equal the directory name** (`CONVENTIONS.md:105`). The loader falls back to the directory name only if `name` is absent (`skill_loader.py:88`), so a mismatch silently mis-labels the skill rather than erroring. Workflows dispatch skills by this exact id string — there is no alias layer (`CONVENTIONS.md:251-252`).

---

## 3. SKILL.md structure (body + frontmatter)

### 3.1 File layout

```markdown
---
<YAML frontmatter — see §3.2>
---

# <Skill Title>

## Purpose
<What this skill produces and why. 1–3 sentences.>

## Inputs
<What the agent receives — artifact references, configuration, context.>

## Outputs
<What the agent must produce — format, schema, quality criteria.>

## Methodology
<Step-by-step approach the agent should follow.>

## Constraints
<Hard requirements — compliance standards, schema adherence, traceability rules.>
```

**Required body sections, in this order**: `## Purpose`, `## Inputs`, `## Outputs`, `## Methodology`, `## Constraints` (`CONVENTIONS.md:58-89`; checklist `CONVENTIONS.md:278`).

**Optional body sections** (`CONVENTIONS.md:91-99`): `## Quality Criteria`, `## Validation`, `## References`, `## Variants`, `## Gotchas` / `## Anti-Patterns`, `## Artifact Output`, `## Currency`.

⚠️ **GOTCHA — the body is parsed as "everything after the second `---`".** The loader splits on the first three `---` markers: text before the first `---` is ignored, the block between markers 1 and 2 is YAML frontmatter, and **all** text after marker 2 is the body (`skill_loader.py:261-279`). The body is `.strip()`-ed (`skill_loader.py:108`). If the file does **not** start with `---`, the whole file is treated as body and frontmatter is empty `{}` (`skill_loader.py:263-264`). If there are fewer than three `---` markers, same fallback (`skill_loader.py:266-267`). Therefore: **start the file with `---` on line 1, and do not use a bare `---` horizontal rule inside the frontmatter region.**

⚠️ **GOTCHA — frontmatter that fails YAML parse does not fail the load.** A `yaml.YAMLError` is swallowed and frontmatter becomes `{}` (`skill_loader.py:273-277`), meaning your skill would silently load with default tier `tier-2`, no tools, no output schemas. Validate your YAML.

### 3.2 Frontmatter fields (the loader's view)

These are the ONLY frontmatter keys the runtime reads (`skill_loader.py:88-93`):

| Key | Required | Type | Allowed values / meaning | Source |
|-----|:--------:|------|--------------------------|--------|
| `name` | ✅ | string | Must equal the directory name and the registry `id`. Loader default = directory name if omitted. | `CONVENTIONS.md:105`, `skill_loader.py:88` |
| `description` | ✅ | string (one paragraph; YAML `>` folded block is conventional) | One paragraph: what the skill does, when invoked, what triggers it. Used by the registry/catalog as the summary and by agent-selection logic. `.strip()`-ed by loader. | `CONVENTIONS.md:106`, `skill_loader.py:89,101` |
| `agent` | ✅ | string enum | Model tier. One of `opus` (Tier 1, deepest reasoning), `sonnet` (Tier 2, standard), `haiku` (Tier 3, fast). ⚠️ Case-insensitive: loader lowercases (`str(agent_hint).lower()`). The literal tier names `tier-1`/`tier-2`/`tier-3` are also accepted. Unknown/absent value → defaults to `tier-2` (i.e. behaves like `sonnet`). | `CONVENTIONS.md:107`, `skill_loader.py:22-29,90-91` |
| `allowed-tools` | optional | list[string] | Tool names the skill may use. ⚠️ Note the **hyphen** (`allowed-tools`, not `allowed_tools`). If absent or not a list, treated as empty list. | `CONVENTIONS.md:108`, `skill_loader.py:92,104` |
| `output_schemas` | optional (declare it if the skill emits structured `.json`) | list[ {path, schema} ] | Your declared output contract. ⚠️ Authoritative + enforced by the human-paired RETURN validator + the (dormant) filesystem path, but NOT enforced on agent-runtime A2A dispatch as currently wired — see the prominent ⚠️ GOTCHA at the top of §5. ⚠️ Note **underscore** (`output_schemas`). | `skill_loader.py:93,113-151`; example `legacy-business-rule-extractor/SKILL.md` frontmatter |
| `disable-model-invocation` | optional | bool | `true` when the skill is dispatched by orchestration only, never by model auto-selection. | `CONVENTIONS.md:109` |

⚠️ **GOTCHA — `allowed-tools` (hyphen) vs `output_schemas` (underscore).** The two list fields use *different* separators. The loader reads `frontmatter.get("allowed-tools")` and `frontmatter.get("output_schemas")` literally (`skill_loader.py:92-93`). Misspelling either silently drops it (no error): wrong-spelled tools → empty tool list (executor then falls back to a default tool set, see §3.4); wrong-spelled schemas → **no validation at all** (the skill's output becomes unenforced).

### 3.3 The `agent` tier → model resolution

The loader maps the `agent` hint to a canonical tier string stored as `model_tier` (`skill_loader.py:22-29,90-91`):

```
opus   | tier-1  → "tier-1"
sonnet | tier-2  → "tier-2"
haiku  | tier-3  → "tier-3"
(anything else, or missing) → "tier-2"
```

The tier is later resolved to a concrete model id by the dispatcher (out of scope here — the skill author only chooses the tier). Pick `opus` for deep reasoning / gate-critical / safety work, `sonnet` for standard analysis, `haiku` for fast/low-stakes passes.

### 3.4 `allowed-tools` runtime behavior

- If the skill omits `allowed-tools` (empty list), the runtime substitutes a default tool set: `["Read", "Glob", "Grep", "Write", "Bash"]` (`agent_executor.py:1072`).
- ⚠️ **GOTCHA — the `Agent` (sub-agent) tool is ALWAYS injected**, appended to whatever tool list results, even if the skill did not request it (`agent_executor.py:1073-1074`). Your skill is always able to spawn parallel sub-agents; the envelope explicitly tells it so (see §4.2). You cannot opt out of the `Agent` tool via `allowed-tools`.
- The agent runs with `permission_mode` defaulting to `acceptEdits` and the workspace root added as an allowed write directory (`agent_executor.py:929,1119-1126`).

### 3.5 `config.json` (optional)

If `cross-cutting/skills/<skill-id>/config.json` exists, it is parsed and stored on the skill as `config` (`skill_loader.py:97,308-317`). Shape is **free-form JSON** — there is no fixed schema. Examples:

```json
// api-contract-validator/config.json
{ "openapi_spec_path": "", "service_url": "", "gravitee_api_id": "" }

// safety-critical-verifier/config.json
{ "app_name": "", "safety_tier": "T1", "nas_functions": [] }
```

⚠️ **GOTCHA — `config.json` is loaded into `skill.config` but is NOT injected into the system prompt and does NOT populate MCP servers.** `build_system_prompt()` never reads `skill.config` (audit of `agent_executor.py:204-379` — only body, references, assets, output_schemas, and context strings are folded in). Separately, the executor will attach MCP servers from `skill.mcp_servers` if non-empty (`agent_executor.py:1129-1130`), but the **filesystem loader never populates `mcp_servers` from `config.json`** (`skill_loader.py` sets `mcp_servers` only via the default `{}`; only the API-load path could set it, and even then from a separate `config_data` field, `skill_loader.py:45,99-110,195`). **Conclusion for an author: do not rely on `config.json` to change the prompt or to wire MCP servers in the filesystem-loaded path. It is inert config metadata unless a script/asset/reference consumes it.** Malformed `config.json` is swallowed → `{}` (`skill_loader.py:314-317`).

---

## 4. THE EXACT INPUT/CONTEXT/PRIORS ENVELOPE (what the agent actually sees)

This is the single most important section for behavioral parity. The system prompt the LLM receives is assembled by `build_system_prompt()` (`agent_executor.py:184-379`) by concatenating the pieces below **with `"\n".join(parts)`**, in **exactly this order**. Author your body knowing every other section that will surround it.

### 4.0 Section order (authoritative)

```
[1]  Program / mission context        (only if a profile declares one)
[2]  Skill body                       (your SKILL.md markdown, stripped)
[3]  Reference docs                    (one block per references/*.md, name-sorted)
[4]  Output templates                  (one block per assets/* text file, name-sorted)
[5]  Output Contract                   (only if output_schemas reaches the runtime as non-empty — see ⚠️ below)
[6]  Context block                     (app id, input-artifacts dir, output dir)
[7]  Platform Capability: Parallel Sub-Agents     (always)
[8]  Platform Capability: Parallel Tool Calls      (always)
[9]  PREVIOUS ATTEMPT FAILED SCHEMA VALIDATION     (only on a validation-retry)
```

Source for the order: `agent_executor.py:204` (`parts = []`) then appends in this sequence at lines 209-213 (1), 216-217 (2), 220-221 (3), 224-225 (4), 233-273 (5), 276-292 (6), 299-320 (7), 331-354 (8), 364-377 (9); final `return "\n".join(parts)` at `agent_executor.py:379`.

⚠️ **GOTCHA — sections [5] (Output Contract) and [9] (validation-retry feedback) are DORMANT on the live API-load path.** Both are gated on `skill.output_schemas` reaching the runtime as non-empty — and on the live API-first load path (the live-stack default) it is ALWAYS empty, because the dispatch API's `SkillDetail` response carries no `output_schemas` field (full explanation in the prominent ⚠️ GOTCHA at the top of §5). So in practice **section [5] is not emitted and section [9] never fires for API-loaded skills**, regardless of what your frontmatter declares. They render only via the deprecated filesystem load path (non-functional in the live stack) or after a future API change. Author your `## Outputs` body and your `.json` discipline anyway — the same schema is enforced live by the human-paired RETURN-payload validator (§5, §5.5), and the runtime machinery activates the moment a contract-bearing load path exists.

⚠️ **GOTCHA — mission context comes FIRST, before your skill body.** "Agents read top-down, so the program's mission framing must come first" (`agent_executor.py:198-203`). Your skill body is section [2], not [1]. Write your body assuming the agent has already read a (possibly large) program-mission document above it.

⚠️ **GOTCHA — the validation-retry feedback comes LAST**, so the corrective signal is freshest in context (`agent_executor.py:356-363`). On a first attempt this section is absent.

### 4.1 Section [1] — Program / mission context

- Injected **only** when the active client profile declares a `mission_context` block in its `profile.yaml` and the runtime is pointed at that profile via `OLYMPUS_PROFILE_ROOT` (`profile_context.py:1-25,58-90`).
- Rendered as:
  ```
  # {heading}

  {body}

  ---
  ```
  where `body` is the **entire contents** of the markdown document at the declared `path`, and `heading` defaults to `"Program Context"` if not set (`agent_executor.py:209-213`; heading default `profile_context.py:40,163-168`).
- `body.rstrip()` is applied; the trailing `\n\n---` is a literal separator (`agent_executor.py:211-212`).
- If no profile / no `mission_context` / unreadable path → the section is **omitted entirely** and dispatch proceeds (mission injection never fails a dispatch — `profile_context.py:14-21,99-161`).
- ⚠️ **GOTCHA — an empty/whitespace mission body is skipped** (`agent_executor.py:209` guards on `mission_context.body.strip()`).

For the FAA profile this document is the FAA ATLAS Statement of Objectives (`profile_context.py:6-8`). **You cannot see it from the skill-builder environment, but you must assume a strategic program-framing document precedes your body.** Do not hard-code program-specific facts into the body — read them from this preceding context at runtime.

### 4.2 Sections [7] and [8] — Platform-capability boilerplate (always present)

Every skill prompt, unconditionally, ends with two platform-capability blocks (`agent_executor.py:299-354`). You do **not** author these; the runtime appends them. Their content (paraphrased — reproduced so you know what the agent is told):

- **[7] Parallel Sub-Agents** (`agent_executor.py:299-320`): "You have the `Agent` tool. Decompose work into parallel sub-agents whenever analysis splits along independent dimensions (per module/directory/file-class/feature). Launching multiple sub-agents in one tool-call round runs them concurrently and cuts wall-clock time. When you invoke a sub-agent, include explicit batching guidance in its prompt (e.g. 'Read all files in parallel by emitting every Read in a single turn')."
- **[8] Parallel Tool Calls** (`agent_executor.py:331-354`): "Emit multiple independent tool calls in a single assistant turn; the runtime executes tool_use blocks in one turn concurrently. Batch Reads for context-gathering, batch Grep/Glob/LS exploration, batch independent Bash probes, batch non-referencing Writes. Only serialize when a later call needs an earlier call's output."

**Implication for authors:** do not repeat generic "use parallel sub-agents / batch your reads" instructions in your body — they are already injected. Spend your body on the domain methodology.

### 4.3 Section [6] — Context block (where inputs physically arrive)

After your body, references, templates, and output contract, the runtime appends a `--- Context ---` block built from up to three strings (`agent_executor.py:276-292`):

```
--- Context ---
Application ID: {app_id}
Input Artifacts Directory: {input_artifacts_dir}
Prior assembly-line artifacts have been staged here. Read them to inform your analysis.
Output Directory: {output_dir}
All output files MUST be written to this directory. Use subdirectories as needed to organize deliverables.
```

- `Application ID:` appears only if an app id was supplied (`agent_executor.py:277-278`).
- `Input Artifacts Directory:` appears only if prior artifacts were staged (`agent_executor.py:279-284`).
- `Output Directory:` appears only if an output dir was supplied (`agent_executor.py:285-290`). ⚠️ **GOTCHA — output files MUST be written under this directory.** Only files written here (the `artifacts/` subtree) are collected and returned; files written elsewhere in the workspace are NOT collected (see §5.1).

### 4.4 How PRIOR ARTIFACTS are presented to the skill

⚠️ **GOTCHA — priors are NOT inlined into the prompt. They are staged as FILES on disk; the agent must Read them.**

- The runtime fetches the skill's declared upstream artifacts from the Git artifact repo and writes them into the **Input Artifacts Directory** (`agent_executor.py:551-701,1008-1043`). The prompt only tells the agent the directory path and "Read them to inform your analysis" (`agent_executor.py:280-284`).
- Two classes of input artifacts exist:
  - **Required** inputs — if any cannot be found on the feature ref or the default branch, the dispatch **fails before the agent runs** (`agent_executor.py:1011-1027`; missing → `FileNotFoundError`, `agent_executor.py:664-671`).
  - **Optional** inputs — missing ones are logged and skipped; never fail the dispatch (`agent_executor.py:1028-1043`, `agent_executor.py:591-593,672-676`).
- Artifact paths are repo-relative file paths inside the artifact repo; they are mirrored into the input dir at the same relative path (`agent_executor.py:694-697`).
- **Which artifacts get staged is decided by the workflow/dispatcher, not by the SKILL.md.** The skill's registry `depends_on` (§6) is the *declaration of intent*; the workflow turns those into the concrete `input_artifacts` list it passes to the runtime. ⚠️ As an author you therefore (a) declare `depends_on` in the registry, (b) document in your `## Inputs` body section the **artifact filenames you will read from the Input Artifacts Directory**, and (c) read them at runtime. You cannot assume any artifact you did not arrange to be staged.

### 4.5 The task message (the user turn)

Separately from the system prompt, the agent receives a **task message** as the user-turn prompt (`agent_executor.py:1198` `query(prompt=task_message, ...)`). This is a short natural-language instruction supplied by the dispatching workflow (e.g. "Catalog application X"). The skill author does not write it, but should ensure the body's `## Methodology` works given a terse imperative task line plus the staged inputs.

### 4.6 References and assets injection (sections [3], [4])

If your skill ships enrichment subdirectories, they are folded into the prompt:

- **`references/*.md`**: each markdown file is appended as a block, **name-sorted** (`skill_loader.py:282-290`, `agent_executor.py:220-221`):
  ```
  --- Reference: {filename} ---
  {file contents}
  ```
- **`assets/*` (text files only)**: each text asset is appended as a block, **name-sorted**; binary assets that fail UTF-8 decode are skipped (`skill_loader.py:293-305`, `agent_executor.py:224-225`):
  ```
  --- Output Template: {filename} ---
  {file contents}
  ```
- ⚠️ **GOTCHA — only `references/*.md` are loaded (markdown only).** Non-`.md` files in `references/` are ignored (`skill_loader.py:288`). Assets load any text file regardless of extension (`skill_loader.py:299-304`).
- ⚠️ Ordering is lexicographic by filename (`sorted(...)`). If you need a deterministic reading order, prefix filenames (`01-...`, `02-...`).

---

## 5. THE OUTPUT CONTRACT — declaration, resolution, validation, retry

> ⚠️ **GOTCHA — READ THIS BEFORE THE REST OF §5. The "runtime validates your declared `.json` output and hard-fails the dispatch on a violation" model described in this section is, as the system is CURRENTLY WIRED, NOT in force on the agent-runtime A2A dispatch path.**
>
> When a skill is loaded the way the live stack loads it — via the API, i.e. `GET /api/v1/skills/dispatch/{id}` — the response object (`SkillDetail`) **does not carry `output_schemas` at all**. It has no such field, the backing skill table has no such column, and the row→model mapper never populates it; unknown keys are dropped by the response model. The agent runtime therefore receives `output_schemas == []` for every API-loaded skill and **validates nothing after dispatch**. There is no post-run schema check, no hard failure on a malformed `.json`, and **no folded-in retry-with-feedback** for skills dispatched this way. (You cannot observe this from runtime symptoms as an author; it is stated here so you do not build a false mental model. The dispositive proof lives in regen `02-agent-runtime.md` §5.2: `SkillDetail` at `olympus-api/src/models/skill.py:57` lists 22 fields, none `output_schemas`; the skill-table column list is `db/seeds/initial-data.sql:94`; the mapper is `_row_to_detail` `olympus-api/src/services/skill.py:18-44`; zero references to `output_schemas` exist in the API skill service/router/model.)
>
> **So is `output_schemas` pointless? No — and this is the part you must get right:**
> 1. **It is the authoritative source-of-truth for your output contract.** Declare it. It documents, for every human and every downstream consumer, exactly which file conforms to which JSON Schema.
> 2. **It IS enforced LIVE — on a different endpoint.** The human-paired-agent RETURN-payload flow (`POST /agent-tasks/{id}/return`) DOES enforce your declared schema. `olympus-api/src/services/return_payload_validator.py` — `load_output_schemas_for_skill(skill_id)` (`:166-191`) — re-parses the `output_schemas` block **directly from your `SKILL.md` file on disk** (not from `SkillDetail`), then `validate_return_output_payload` (`:315-413`) runs `Draft202012Validator` against the submitted payload and rejects violations with HTTP 400 `OUTPUT_SPEC_VIOLATION` (raised by its caller `human_paired_agent.py:266`). So an authored `output_schemas` block is binding for return-payload submissions for in-scope skills (currently the 6 Rationalization-line skills that declare it: `analyze-portfolio-redundancy`, `classify-application`, `disposition-recommender`, `portfolio-scorer`, `redundancy-analyzer`, `wave-outcome-synthesizer`).
> 3. **It IS honored on the deprecated filesystem load path** (the runtime loader DOES parse it from frontmatter) — but that path is non-functional in the live stack because the dispatch-id map (`skill_mapping.yaml`) is intentionally empty, so it is never taken in practice.
> 4. **Any future surfacing of `output_schemas` on the dispatch API would immediately turn the agent-runtime validation on.** The runtime machinery (Section 5 of the prompt envelope, post-run validation, one-shot retry) is fully built and waiting; it is fed an empty list today only because the API does not return the field.
>
> **Authoring rule of thumb:** *Always declare `output_schemas` (it is authoritative, it drives the return-payload validator, and it future-proofs you for API-surfaced enforcement). But do NOT assume that agent-runtime A2A dispatch currently validates your `.json` output or that a violation will hard-fail the dispatch and trigger a folded-in retry — on the live API-load path it does not.* The rest of §5 documents the runtime's validation/retry behavior **as it is reachable via the filesystem path or any future API change** (and the §5.5 schema-conformance discipline is exactly what the return-payload validator checks); treat §5.4 (the in-prompt contract block), §5.5 (post-run hard-fail), and §5.7 (one-shot retry) as describing **the agent-runtime path's intended/dormant behavior**, not a guarantee that fires on today's API dispatch.

### 5.0 `output_schemas` declaration form (frontmatter)

```yaml
output_schemas:
  - path: business-logic.json
    schema: schemas/discovery/business-logic.schema.json
```

Each entry is a mapping with **exactly two string keys**: `path` and `schema` (`skill_loader.py:113-151`; canonical example `legacy-business-rule-extractor/SKILL.md`, `catalog-application/SKILL.md`, `disposition-recommender/SKILL.md`).

- `path` — the output **filename** (or repo-relative output path) your skill will write. Matched against produced files (see §5.2 matching).
- `schema` — a **repo-relative path** to a JSON Schema file under `schemas/` (resolution in §5.3). Absolute paths are also accepted.

Coercion rules (`skill_loader.py:113-151`):
- ⚠️ Must be a **list**. A scalar/dict/missing value → coerced to empty list `[]` (validation disabled), with only a debug log. **No error.**
- ⚠️ Each entry must be a `dict` with **both** `path` and `schema` as **strings**. Entries failing this are silently skipped (`skill_loader.py:138-150`). A typo in either key name drops that entry.

### 5.1 What "output" means (file collection)

- The agent writes files into the **Output Directory** (the `artifacts/` subtree of the workspace, §4.3).
- After the agent finishes, the runtime walks that directory and collects **only files created during this run** (the delta versus a pre-run snapshot) (`agent_executor.py:1142-1150,1304-1309`, `_collect_artifacts` `agent_executor.py:858-905`).
- Text files are returned as UTF-8 strings; binary files (by extension, e.g. `.png .pdf .zip …`) are base64-encoded (`agent_executor.py:90-96,886-898`).
- ⚠️ **GOTCHA — only the `path`s you declare in `output_schemas` are validated. Other emitted files are NOT validated** (`output_validator.py:144-189`). When validation runs, every file you declare a schema for MUST validate or the whole dispatch fails (§5.5). ⚠️ But note: "when validation runs" excludes the live API-load path, where validation is dormant (top-of-§5 GOTCHA); this matching/validation behavior applies to the filesystem path and to a future API-surfaced contract.
- ⚠️ **GOTCHA — base64 (binary) outputs are skipped by the validator** even if a schema is declared for them (`output_validator.py:191-193`). Schemas only bind UTF-8/JSON outputs.

### 5.2 ⚠️ GOTCHA — `path` matching is by full path OR basename

When validating, the runtime matches a declared `path` against each produced file by **either** the full repo-relative path **or** the bare basename (`output_validator.py:181,186-188`):

```python
schema_path = by_path.get(rel_path) or by_path.get(PurePosixPath(rel_path).name)
```

So `path: business-logic.json` matches a file produced at any depth whose basename is `business-logic.json`. Both styles (bare filename and full path) are used across existing skills. Prefer a **bare filename** unless you must disambiguate same-named files in different subdirs.

### 5.3 ⚠️ GOTCHA — how `schema:` paths RESOLVE

A relative `schema:` path is resolved against a **schema root** determined at runtime (`output_validator.py:76-92,107-117`):

1. If env var `OLYMPUS_SCHEMA_ROOT` is set and points at a directory → that directory is the root.
2. Otherwise the runtime walks up from its own file location looking for a directory that **contains a `schemas/` subdirectory**; the parent of that `schemas/` (i.e. the **repo root**) becomes the root.
3. The schema file is then `root / <your schema: path>`.

**Consequence for authors:** write `schema:` as a path **relative to the repo root**, beginning with `schemas/`. Example: `schemas/discovery/business-logic.schema.json`. This is exactly the path you would use from the repo root. The schema files live under the repo-root `schemas/` tree (see §5.6) — **declare against those paths; never copy a schema into your skill directory.**

If the schema cannot be located/loaded:
- At prompt-build time, the contract section still renders but tells the agent the schema "could not be loaded… the runtime cannot enforce a schema that isn't loadable" (`agent_executor.py:250-260`; `load_schema` returns `None`, `output_validator.py:118-125`).
- At validation time, an unloadable schema for a declared path is itself a **failure** ("schema … could not be loaded", `output_validator.py:222-232`). ⚠️ So a broken `schema:` path does NOT silently pass — it fails the output. Get the path right.

### 5.4 The Output Contract section the agent sees (section [5])

⚠️ **GOTCHA — this section is NOT shown to the agent on the live API-load path.** The block below is emitted by the runtime only when `skill.output_schemas` is non-empty, and on the API-first load path it is always `[]` (see the prominent ⚠️ GOTCHA at the top of §5). So an API-loaded agent **never sees this Output Contract block** and is never told post-run validation will occur. The block renders only via the deprecated filesystem load path or a future API change. (It is reproduced here verbatim so it is correct when that path is active.)

If `output_schemas` is non-empty, the runtime folds the **full JSON Schema text** of every declared entry into the system prompt (`agent_executor.py:233-273`). The agent sees, verbatim:

```
--- Output Contract (STRICT — your output MUST conform) ---
Every file path listed below has a binding JSON Schema. The Olympus runtime
validates your output against these schemas after you finish; any violation
returns a hard failure. The schemas are reproduced verbatim — read them before
you write the first byte of any output file.

### {path}
Schema source: {schema:path}
```json
{ ...the entire JSON Schema, pretty-printed... }
```
```

(one `### {path}` block per declared entry; `agent_executor.py:242-273`.) **You do not write this block — it is generated from your `output_schemas` + the resolved schema file.** Your job is to make `## Outputs` in the body consistent with it.

### 5.5 THE VALIDATION CONTRACT (post-run, hard-fail)

⚠️ **GOTCHA — WHEN this validation actually runs.** The post-run hard-fail algorithm below executes only when the loaded skill carries a non-empty `output_schemas`. It therefore **does NOT run on the live API-load path** (where `output_schemas == []` always — top-of-§5 GOTCHA): `validate_output_files` short-circuits at `if not output_schemas: return output_files` and nothing is checked. The exact same Draft-2020-12 conformance discipline IS, however, applied LIVE — by the human-paired RETURN-payload validator (`return_payload_validator.validate_return_output_payload`, `olympus-api/src/services/return_payload_validator.py:315-413`, which re-reads your SKILL.md frontmatter from disk and rejects violations with HTTP 400). So the schema-shaping rules below are not academic — they are exactly what the return-payload flow enforces, and what the agent-runtime path will enforce the moment `output_schemas` is surfaced on the dispatch API. Author to them.

After collecting output files, the runtime validates them on the agent-runtime path (`agent_executor.py:1329-1342`; validator `output_validator.py:144-267`). The algorithm, exactly:

```
validate_output_files(output_files, output_schemas):
    if output_schemas is empty:            # no contract → nothing to check
        return output_files                # (output_validator.py:169-170)

    by_path := { entry.path : entry.schema for entry in output_schemas }   # (181)
    failures := []
    for f in output_files:                                                 # (184)
        schema_ref := by_path[f.path]  OR  by_path[basename(f.path)]       # (186-188)
        if no schema_ref:        continue        # file not under contract # (189)
        if f.encoding != "utf-8": continue       # binary skipped          # (191-193)

        if f.content is empty/whitespace:                                  # (196-205)
            failures += OutputValidationError("<path>: file is empty",
                                              violations=["empty file ..."])
            continue

        try: payload := json.loads(f.content)                              # (207-208)
        except ValueError as e:                                           # (209-220)
            head := first 120 chars of content, newlines→spaces
            failures += OutputValidationError(
                "<path>: JSON parse failed: <e>. First chars: '<head>'")
            continue                          # ← "prose in a .json file" lands here

        schema := load_schema(schema_ref)                                  # (222)
        if schema is None:                                                 # (223-232)
            failures += OutputValidationError(
                "<path>: schema '<ref>' could not be loaded")
            continue

        errors := Draft202012Validator(schema).iter_errors(payload)        # (234)
        if errors:                                                        # (235-245)
            violations := [ f"{err.json_path or '<root>'}: {err.message}"  # (133-141)
                            for first 10 errors ]
                          (+ "... and N more" if >10)
            failures += OutputValidationError("<path>: <n> schema violation(s)",
                                              violations=violations)

    if failures is empty: return output_files                              # (247-248)

    raise OutputValidationError(   # coalesced — ALL failed files in one error # (254-267)
        message = "agent output failed schema validation:\n" +
                  per-file bulleted summary,
        path = ";".join(failed paths),
        schema_path = ";".join(failed schema refs),
        violations = ["<path>: <violation>", ... across all files])
```

Hard rules an author must internalize:
- ⚠️ **JSON Schema dialect is Draft 2020-12** (`output_validator.py:173,234`). Write your `schema:` files in 2020-12. The Olympus `schemas/` files already declare `$schema`, `$id`, `title`, `description` (`schemas/validate.sh:11-30`) — match that convention if you add a new schema.
- ⚠️ **A declared `.json` output that contains prose/markdown FAILS** at `json.loads` (`output_validator.py:207-220`). This is the #1 failure mode the platform engineers against. Structured artifacts (`.json`) must be **pure JSON, no preamble, no code fences, no trailing prose**.
- ⚠️ **An empty/whitespace declared output FAILS** ("file is empty", `output_validator.py:196-205`).
- ⚠️ **Validation is all-or-nothing for the dispatch.** The loop collects **all** failed files, then raises a single coalesced error (`output_validator.py:247-267`). Any one failing declared output fails the entire dispatch with `status="failed"` (`agent_executor.py:1331-1342`).
- **Narrative belongs in `.md` sidecars.** Convention: emit the structured artifact as `<name>.json` (validated) and any human-readable narrative as `<name>.md` (not validated). The retry feedback explicitly reminds the agent of this (`agent_executor.py:368-372`). The `disposition-recommender` pairs `disposition-recommendation.json` (schema-bound) with `disposition-recommendation.md` (narrative).

### 5.6 Where the schemas live (declare against these)

Repo-root `schemas/` tree (do **not** copy these — point `schema:` at them). Subdirectories (`schemas/`): `architecture/`, `common/`, `cross-cutting/`, `data/`, `design/`, `discovery/`, `dispositions/`, `gates/`, `modernization/`, `profiles/`, `rationalization/`, `samples/`. Each schema file is named `<name>.schema.json`.

**Which schema does a skill of a given type satisfy?** The skill author chooses the schema that matches the artifact the skill produces, by assembly line / domain. There is no automatic type→schema map in the runtime — the binding is explicit in your `output_schemas`. Use the directory matching the consuming line:

| Skill's assembly line / domain | Schema directory | Representative schemas |
|--------------------------------|------------------|------------------------|
| Discovery | `schemas/discovery/` | `catalog.schema.json`, `business-logic.schema.json`, `business-rule-inventory.schema.json`, `tech-fingerprint.schema.json`, `quality-risk.schema.json`, `ux-accessibility.schema.json`, `discovery-synthesis.schema.json`, `analysis-report.schema.json`, `identity-landscape.schema.json` |
| Rationalization | `schemas/rationalization/` | `disposition-recommendation.schema.json`, `redundancy-matrix.schema.json`, `classification.schema.json`, `portfolio-score.schema.json`, `tco-analysis.schema.json`, `wave-plan.schema.json`, `capability-consolidation-plan.schema.json`, `user-impact-analysis.schema.json`, `ux-overlap-matrix.schema.json` |
| Architecture | `schemas/architecture/` | (architecture artifacts) |
| Data | `schemas/data/` | (data products / domain models) |
| Modernization | `schemas/modernization/` | (extract/design/generate artifacts) |
| Design | `schemas/design/` | `application-state-machine.schema.json`, domain rule schemas |
| Disposition outputs (5R/7R) | `schemas/dispositions/` | `disposition-output.schema.json`, `retire-output`, `retain-output`, `refactor-output`, `rearchitect-output`, `replace-output`, `replatform-output`, `consolidate-output` |
| Gates / gate evidence | `schemas/gates/` | `gate-evidence-package.schema.json`, `gate-review-checklist.schema.json`, `escalation-record.schema.json` |
| Cross-cutting (traceability, events, metrics, scores) | `schemas/cross-cutting/` | `traceability-report.schema.json`, `audit-event.schema.json`, `metric.schema.json`, `event-envelope.schema.json`, `score-snapshot.schema.json`, `attestation-chain.schema.json` |
| Citations | `schemas/common/` | `traceability-citation.schema.json` |
| Profiles | `schemas/profiles/` | (profile config schemas) |

(Listing from the captured `schemas/` tree; if a new artifact type has no schema, author one under the matching directory following the 2020-12 + `$schema`/`$id`/`title`/`description` convention, `schemas/validate.sh:11-30`, and reference it by its repo-relative path.)

### 5.7 THE RETRY-FEEDBACK FORMAT (section [9]) — exact shape

⚠️ **GOTCHA — the one-shot retry-with-feedback does NOT happen on the live API-load path.** The entire marker-write → retry → folded-in-feedback chain below is triggered by a post-run validation *failure* inside the runtime, which can only occur when `skill.output_schemas` is non-empty. On the API-first load path it is always `[]` (top-of-§5 GOTCHA), so validation never fails on that basis and **no retry feedback is ever produced** for API-loaded skills. (The human-paired RETURN-payload validator, §5, rejects a bad payload with HTTP 400 but does NOT drive this agent-runtime retry loop — that flow has no marker and no re-dispatch.) The behavior below is the agent-runtime path's intended/dormant mechanism, reachable via the filesystem path or a future API change; reproduce it for parity but do not assume your skill currently gets an automatic corrective re-run after a malformed `.json`.

⚠️ This is a load-bearing behavior (when reachable): a skill gets **exactly one** self-correction retry with folded-in violations.

**On a validation failure**, before the workspace is cleaned up, the runtime writes a marker file `.previous-validation-failure.json` into the persistent workspace (`agent_executor.py:110,1333-1334`; writer `agent_executor.py:133-165`). Its JSON shape:

```json
{
  "feedback": "Path: {path}\nSchema: {schema_path}\nViolations:\n  - {v1}\n  - {v2}\n  ...",
  "path": "{semicolon-joined failed paths}",
  "schema_path": "{semicolon-joined failed schema refs}",
  "violations": ["{path}: {violation}", "..."]
}
```

(The `feedback` string is built at `agent_executor.py:145-156`: lines `Path: …`, `Schema: …`, `Violations:`, then `  - {v}` per violation.)

**On the next dispatch attempt** (Temporal retries against the same `workspace_key`), the runtime reads the marker (`agent_executor.py:113-130,1057-1059`) and **appends section [9] to the system prompt** (`agent_executor.py:364-377`). The agent sees, verbatim:

```
--- IMPORTANT: PREVIOUS ATTEMPT FAILED SCHEMA VALIDATION ---
Your previous output for this task did NOT conform to the declared output_schemas
contract. Read the validation violations below carefully and emit ONLY valid JSON
for the structured artifacts. Do NOT include any prose, markdown, preamble, or
explanation in the .json file paths — narrative belongs in the .md sidecar files only.

{feedback}            ← the "Path: … / Schema: … / Violations: …" block above

Re-run the analysis from the input artifacts that were staged for you and re-emit
every output file. Do not partially patch the previous output — produce a fresh,
schema-valid set.
```

⚠️ **GOTCHA — feedback is appended LAST in the prompt and instructs a full fresh re-emit, not a patch.** Author your methodology so it can deterministically regenerate the complete output set from the staged inputs (idempotent re-run), because that is what the retry asks for.

⚠️ **GOTCHA — the marker is per-`workspace_key` and is cleared on the next clean run** (`agent_executor.py:168-181,1344-1347`). Stale feedback never bleeds into an unrelated dispatch. On an ephemeral (no `workspace_key`) workspace the marker write is a no-op (`agent_executor.py:119,133-144`), so the one-shot retry feedback only materializes for persistent workspaces — but as an author you should always assume it may appear and design for the fresh-re-emit contract.

---

## 6. PROFILE OVERLAYS and `depends_on`

### 6.1 `depends_on` (registry field, REQUIRED)

- Every registry entry MUST declare `depends_on` — a list of **direct** upstream skill ids whose artifacts this skill reads at dispatch time. **Declare `[]` if there are none; it must be present** (`CONVENTIONS.md:154-168`; CI enforces presence, `CONVENTIONS.md:266`).
- List only **direct** dependencies (the named upstream artifact is read at dispatch) (`CONVENTIONS.md:166-167`).
- Do **NOT** list orchestration dependencies ("runs after gate G-04a") — those live in the workflow (`CONVENTIONS.md:168`).
- ⚠️ When an upstream skill's artifact schema changes, **bump the downstream skill's `version`** to signal the break (`CONVENTIONS.md:170`).
- Ordering: `depends_on` declares the data-flow DAG; the **workflow** decides execution order and which artifacts to stage (the runtime stages whatever `input_artifacts` the dispatcher passes — §4.4). There is no implicit ordering enforcement inside the SKILL.md.

### 6.2 Profile overlays — three mechanisms, fixed precedence

A cross-cutting skill is the abstract base; a client profile (e.g. `profiles/faa/`) may override it through three mechanisms (`CONVENTIONS.md:128-150`; implemented in `skill_loader.py:320-485`). Precedence, least → most authoritative (`CONVENTIONS.md:139-144`):

1. **Cross-cutting SKILL.md body** (base).
2. **Config-variable substitution** — `profiles/<client>/config/<skill-id>.yaml` (and `config/common.yaml` for cross-skill defaults) supply values for `{{token}}` placeholders in the base body; per-skill overrides common (`skill_loader.py:360-382`). Substitution replaces every `{{key}}` occurrence; **unknown tokens are left literally in place** so a miss is visible (`skill_loader.py:343-357`; `CONVENTIONS.md:135`).
3. **Reference additions** — `profiles/<client>/skills/<skill-id>/references/*.md` are merged on top of the base references; **profile keys override base keys on filename collision** (`skill_loader.py:396-406`; `CONVENTIONS.md:136,142`).
4. **Full SKILL.md overlay** — `profiles/<client>/skills/<skill-id>/SKILL.md` replaces the body entirely; its frontmatter wins per-key where present, else base frontmatter is kept (`skill_loader.py:385-393,446-468`; `CONVENTIONS.md:137,144`).

⚠️ **Authoring guidance** (`CONVENTIONS.md:146-150`):
- **Prefer config variables over full overlays** — they keep methodology in one place.
- **Never hard-code client-specific terms in a cross-cutting body.** If a cross-cutting SKILL.md mentions e.g. "Gravitee" or "OKTA" literally, it is a **bug** — extract it to a `{{api_gateway}}` / `{{identity_provider}}` config variable (`CONVENTIONS.md:150`). Build a generic cross-cutting skill first, then overlay only when the methodology genuinely differs under a profile (`CONVENTIONS.md:148-149`).

⚠️ **GOTCHA — overlay precedence interacts with output_schemas.** When a full overlay is applied, the resolved `SkillDefinition` keeps the **base** `output_schemas` (and base `config`, base `assets`) — the overlay path only replaces body/description/tier/tools and merges references (`skill_loader.py:474-485`). So a profile overlay cannot change the output contract; if a profile needs a different output schema, that is a different skill, not an overlay.

⚠️ **GOTCHA — the mission-context overlay (§4.1) is a SEPARATE mechanism from these three.** Mission context is injected by the *runtime* from `profile.yaml`'s `mission_context` block (`profile_context.py`), independent of the per-skill overlay loader. Both can be active simultaneously.

---

## 7. REGISTRY ENTRY (the catalog metadata)

Every skill has exactly one entry under `skills:` in `cross-cutting/skills/registry.yaml`. Adding/removing/renaming a skill MUST update this file (`registry.yaml:10-13`; `CONVENTIONS.md:174-175`). The catalog API loads this file (`registry.yaml:8`); runtime *metrics* live in a DB table keyed by id, **never** in this YAML (`registry.yaml:14-15`; `CONVENTIONS.md:190`).

### 7.1 Required v1 fields

```yaml
- id: <skill-id>                 # required; MUST match directory name + frontmatter name
  version: 1.0.0                 # required; semver
  category: <category-name>      # required (see §7.3 for the closed set)
  enrichment: minimal|partial|full   # required (see §7.2)
  line: <assembly-line-name>     # required; primary consuming line
  step: <step-or-activity-name>  # optional; where in the line it runs
  is_orchestration: false        # required; false for skills, true for orchestration step-names
  variants: []                   # optional; list of {id, when:{...}} variant specs
  profile_overrides: []          # optional; list of profile ids that overlay this skill
  depends_on: []                 # required (may be empty, must be present)
```

(`CONVENTIONS.md:176-188`; registry header `registry.yaml:16-52`.)

### 7.2 `enrichment` values + meaning

Allowed: `Minimal` | `Partial` | `Full` (`CONVENTIONS.md:113-123,184`). ⚠️ **GOTCHA — case is not enforced**; the registry contains both `full` and one `Full` in practice (`registry.yaml` audit). Use lowercase to match the majority; treat it as case-insensitive.

| Level | Contents present | When sufficient |
|-------|------------------|-----------------|
| `Minimal` | SKILL.md only | Exploratory / low-stakes analysis |
| `Partial` | SKILL.md + `references/` | Standard analysis with domain grounding |
| `Full` | SKILL.md + `references/` + `scripts/` + `assets/` + `config.json` | Code generation, compliance artifacts, gate-critical outputs (implies deterministic validation scripts + templated assets) |

(`CONVENTIONS.md:117-123`.)

### 7.3 `category` — closed set in practice

`category` is free-text in the schema but the catalog uses a fixed set (12-category taxonomy). Observed values (use one of these verbatim): `Analysis & Assessment`, `Architecture & Design`, `Business Process & Automation`, `CI/CD & Deployment`, `Code Quality & Review`, `Code Scaffolding & Templates`, `Compliance & Evidence`, `Cross-Cutting`, `Data Fetching & Analysis`, `Data Modeling & Schema Design`, `Documentation`, `Identity & Auth`, `Infrastructure Operations`, `Legacy Analysis`, `Library & API Reference`, `Meta-Tooling`, `Product Verification`, `Runbooks & Operations`, `Synthesis` (enumerated from `registry.yaml`). Pick the closest match to what the skill produces.

### 7.4 `variants` shape

```yaml
variants:
  - id: discovery-patterns-mainframe
    when:
      tech_family: mainframe
  - id: discovery-patterns-oracle
    when:
      database: oracle
```

Each variant is `{ id: <variant-skill-id>, when: {<condition-key>: <value>} }` (`registry.yaml` `discovery-patterns` entry ~`:111-121`; `code-generation` entry ~`:2380-2393`). ⚠️ **The `when:` conditions are matched by the WORKFLOW's router at runtime** (e.g. `discovery_patterns_router`, `code_generation_router`) — they document the routing key, but the dispatch decision is workflow code, not SKILL.md logic (`registry.yaml` `code-generation` comment ~`:2380-2392`; `CONVENTIONS.md:21`). Each variant id is also a real skill directory with its own SKILL.md (`CONVENTIONS.md:48-52`).

### 7.5 `is_orchestration`

- `false` → this is a skill with a SKILL.md on disk (the normal case).
- `true` → this is a **workflow orchestration step-name** (e.g. `plan-retirement`, `drift-detection`). It is listed in the registry ONLY because a line README references it; it has **NO SKILL.md on disk** and is audited to keep step-names distinct from skill-names (`registry.yaml:22-27`; example `drift-detection` entry `registry.yaml:2352-2365`). ⚠️ **As a skill author you set `is_orchestration: false`.** Never create a SKILL.md for an orchestration step.

### 7.6 Optional `currency` block (recency/revalidation)

Optional metadata, inspired by 14 CFR Part 61 §§61.56–61.57 (`CONVENTIONS.md:192-215,295-329`; registry header `registry.yaml:29-40`). **Declarative only — no runtime enforcement at this revision** (`CONVENTIONS.md:327-329`; `registry.yaml:38-40`). Skills without it are treated as always-fresh.

```yaml
currency:
  recency_window_days: 90          # int — rolling window for "recent successful executions"
  minimum_recent_executions: 3     # int — min successful runs within the window (often 3)
  revalidation_interval_days: 180  # int — max age of last full benchmark before re-benchmark required
  lapsed_action: benchmark_required  # enum (see below)
```

⚠️ **GOTCHA — if you declare the block, declare all four fields** (`CONVENTIONS.md:206`). `lapsed_action` ∈ { `benchmark_required` (run benchmark before next dispatch — default), `human_review_required` (route next invocation through human review regardless of tier), `quarantine` (block autonomous dispatch until manual re-certification) } (`CONVENTIONS.md:208-213,309-314`).

**When to declare** (`CONVENTIONS.md:316-325`): strongly recommended for skills dispatched on **T1 (safety-critical)** or **T2 (mission-support)** applications, skills feeding **gate decisions**, multi-step generators where errors compound silently, or skills whose `references/` may age with the portfolio. Optional for Minimal/Partial skills on T3. The authoring checklist says: for any skill ever dispatched on T1/T2, **consider declaring a `currency` block; skip only with explicit justification** (`CONVENTIONS.md:284`).

### 7.7 Optional benchmark-metadata fields

Any subset of these four independent fields may be declared (`CONVENTIONS.md:218-245`; registry header `registry.yaml:42-52`). Missing fields → treated as empty/always-compatible.

```yaml
validation_commands:        # list[str] — shell commands the OUTPUT must survive; run post-dispatch
  - pytest -q               #            by deterministic validation gates. NO chained && (keep each self-contained)
  - ruff check
supported_stacks:           # list[str] — tech stacks the skill applies to (from reference/tech-stack.md);
  - python                  #            dispatch-time compatibility checks refuse unsupported stacks
  - fastapi
failure_classes:            # list[str] — named failure modes the currency-tracker watches
  - test-generation-drift
benchmark_tags:             # list[str] — tags grouping skills for benchmark runs (tag-intersection selector)
  - ralph-loop
```

⚠️ **GOTCHA — `validation_commands` must each be self-contained; no `&&` chaining** (`CONVENTIONS.md:240`). ⚠️ Unknown nested fields are ignored by the loader, so these can be adopted incrementally (`CONVENTIONS.md:245`; `registry.yaml:39-40`).

---

## 8. CI enforcement (what will block a PR)

The skill-CI job (P4-S7.H1) runs on every PR and enforces (`CONVENTIONS.md:258-268`; `registry.yaml:11-13`):
- Every skill name dispatched by a workflow has a SKILL.md on disk.
- Every skill listed in a line README `Skills` table exists on disk.
- No duplicated skill registration between `registry.yaml` and any other mapping file.
- Skill directory names match the §2 naming convention (noun phrases; `plan-*`/`step-*`/`execute-*` prefixes flagged).
- Every registry entry has `depends_on` declared (present, may be empty).

⚠️ Violations block the PR — **fix the underlying issue; do not add to a suppressions list** (`CONVENTIONS.md:268`).

---

## 9. Worked example (assembling everything)

A minimal Discovery-line skill that reads no upstream skill artifacts and emits one schema-bound JSON plus a narrative sidecar.

**`cross-cutting/skills/catalog-application/SKILL.md`** (frontmatter shape — body omitted per scope):
```yaml
---
name: catalog-application
description: >
  Produce the standardized Application Catalog entry and tech fingerprint for a
  legacy application. Runs as Step 1 of the Discovery line... Triggers on cataloging.
agent: sonnet
allowed-tools:
  - Read
  - Write
  - Bash
  - Grep
output_schemas:
  - path: application-catalog-entry.json
    schema: schemas/discovery/catalog.schema.json
---
# ... body with ## Purpose / ## Inputs / ## Outputs / ## Methodology / ## Constraints ...
```
(verbatim frontmatter from `catalog-application/SKILL.md`.)

**Registry entry** (`registry.yaml`):
```yaml
- id: catalog-application
  version: 1.0.0
  category: Data Fetching & Analysis
  enrichment: minimal
  line: Discovery
  step: Step 1 — Catalog
  is_orchestration: false
  variants: []
  profile_overrides: []
  depends_on: []
```
(verbatim from `registry.yaml:76-85`.)

At runtime this skill's agent sees: `[mission context if FAA]` → `[catalog-application body]` → `[Context: App ID + Output Directory]` → `[Parallel Sub-Agents]` → `[Parallel Tool Calls]`. It must write `application-catalog-entry.json` (pure JSON conforming to `schemas/discovery/catalog.schema.json`) into the Output Directory.

⚠️ **GOTCHA — the worked example omits the Output Contract section ([5]) on purpose.** On the live API-load path this skill's `output_schemas` does NOT reach the runtime (it is not on the `SkillDetail` response — top-of-§5 GOTCHA), so the agent sees **no inlined `catalog.schema.json`**, the runtime performs **no post-dispatch validation** of `application-catalog-entry.json`, and a malformed `.json` does **not** trigger a dispatch failure or a folded-in retry on this path. (Had the skill been loaded via the deprecated filesystem path — non-functional in the live stack — the contract block would be inlined as `[Output Contract with catalog.schema.json inlined]` after the body, and post-run validation + one-shot retry would apply.) You still declare `output_schemas` exactly as shown: it is the authoritative contract, it is enforced if this skill's output is submitted through the human-paired RETURN endpoint, and it future-proofs the skill for API-surfaced enforcement.

---

## 10. Conformance checklist for a new skill

**Directory & naming**
- [ ] Directory `cross-cutting/skills/<skill-id>/` created; id is a lowercase hyphenated **noun phrase** (§2; `CONVENTIONS.md:32-36`).
- [ ] id does **not** start with `plan-` / `step-` / `execute-` (§2; `CONVENTIONS.md:40`).
- [ ] If a variant: directory is `<base>-<suffix>/` and the base skill exists (§2; `CONVENTIONS.md:48-52`).

**SKILL.md frontmatter** (`skill_loader.py:88-93`)
- [ ] File starts with `---` on line 1; exactly one frontmatter block delimited by two `---` (§3.1; `skill_loader.py:261-279`).
- [ ] `name:` present and **exactly equals** the directory name (§3.2; `CONVENTIONS.md:105`).
- [ ] `description:` present — one paragraph (what / when / triggers) (§3.2; `CONVENTIONS.md:106`).
- [ ] `agent:` present and ∈ {`opus`,`sonnet`,`haiku`} (§3.2-3.3; `CONVENTIONS.md:107`).
- [ ] `allowed-tools:` (hyphen!) is a YAML list if present (§3.2; ⚠️ not `allowed_tools`).
- [ ] No client-specific literals in the body — use `{{tokens}}` for profile-substitutable values (§6.2; `CONVENTIONS.md:150`).

**SKILL.md body** (`CONVENTIONS.md:58-89`)
- [ ] Required sections present and in order: `## Purpose`, `## Inputs`, `## Outputs`, `## Methodology`, `## Constraints`.
- [ ] `## Inputs` names the **artifact filenames** the skill will Read from the Input Artifacts Directory (priors are files, not inlined — §4.4).
- [ ] Body does **not** duplicate the always-injected parallel-sub-agents / parallel-tool-calls boilerplate (§4.2).
- [ ] Methodology is idempotent — can regenerate the full output set from staged inputs (the agent-runtime retry contract, §5.7, asks for a full fresh re-emit when it fires; note that retry is dormant on the live API-load path — top-of-§5 GOTCHA — but design for it regardless).

**Output contract** (if the skill emits structured output)
- [ ] ⚠️ Understand the enforcement reality (top-of-§5 GOTCHA): `output_schemas` is **authoritative and declared**, is **enforced live by the human-paired RETURN-payload validator** (`return_payload_validator.py:166-191`) and on the **deprecated filesystem load path**, but is **NOT enforced on agent-runtime A2A dispatch** as currently wired (the dispatch API's `SkillDetail` does not carry the field → runtime sees `[]`). Declare it; do not rely on agent-runtime dispatch to validate it today.
- [ ] `output_schemas:` (underscore!) is a list of `{path, schema}` string mappings (§5.0; `skill_loader.py:113-151`).
- [ ] Each `schema:` is a **repo-root-relative** path beginning with `schemas/...` that exists in the captured schema tree (§5.3, §5.6).
- [ ] Each `path:` is the (basename or full) output filename the skill will write into the Output Directory (§5.1-5.2).
- [ ] `.json` outputs are pure JSON (no prose/fences); narrative goes in a `.md` sidecar (§5.5). This discipline is enforced LIVE by the return-payload validator (`return_payload_validator.py:374` runs `Draft202012Validator`) and on the dormant agent-runtime path (`agent_executor.py:368-372`).
- [ ] Declared schema is valid JSON Schema **Draft 2020-12** with `$schema`/`$id`/`title`/`description` (§5.5-5.6; agent-runtime `output_validator.py:173,234`; return-payload `return_payload_validator.py:369,374`; `schemas/validate.sh:11-30`).

**Enrichment subdirs** (optional)
- [ ] `references/` contains only `.md` files you intend the agent to read (non-`.md` ignored) (§4.6; `skill_loader.py:288`).
- [ ] `assets/` text templates are named for deterministic ordering (lexicographic load) (§4.6).
- [ ] `config.json`, if present, is valid JSON and is treated as **inert config** (not injected into the prompt; does not wire MCP in the FS path) (§3.5).

**Registry entry** (`cross-cutting/skills/registry.yaml`)
- [ ] Entry added with all required v1 fields: `id`, `version`, `category`, `enrichment`, `line`, `is_orchestration`, `depends_on` (§7.1; `CONVENTIONS.md:176-188`).
- [ ] `id` matches the directory name and frontmatter `name` (§7.1).
- [ ] `is_orchestration: false` (§7.5).
- [ ] `depends_on` present (may be `[]`); lists only **direct** upstream skill ids (§6.1; `CONVENTIONS.md:154-168`).
- [ ] `enrichment` ∈ {minimal,partial,full} and matches what's actually on disk (§7.2).
- [ ] `category` is one of the closed-set values (§7.3).
- [ ] `variants`/`profile_overrides` declared if applicable (§7.4; `CONVENTIONS.md:184-188`).
- [ ] If dispatched on T1/T2 or feeds a gate: `currency` block considered (all four fields if declared) or skip justified (§7.6; `CONVENTIONS.md:284`).

**Wiring & versioning**
- [ ] At least one workflow dispatches the skill by its exact id, or it is declared cross-cutting in the taxonomy (`CONVENTIONS.md:281`).
- [ ] Listed in the consuming line README `Skills` table unless cross-cutting (`CONVENTIONS.md:282`).
- [ ] On modification: `version` bumped (semver — major for breaking output/`depends_on` change) and downstream `depends_on` bumped if the artifact schema changed (§6.1; `CONVENTIONS.md:170,288-291`).
