# Regeneration Spec 02 — Agent Runtime & Skill Interface (ATOMIC)

**Premise.** The codebase will be deleted; this file is the only surviving artifact for the agent runtime. Rebuild so it behaves IDENTICALLY. Every branch, loop, early-return, and exception path is reproduced as pseudocode. `path:line` citations are load-bearing — they point at the exact behavior to reproduce. **Citations are current as of HEAD `7cb3b20c`.**

**Scope.** The `olympus-agent-runtime/` FastAPI service (the A2A skill executor) plus the cross-service plumbing that defines its contract: the worker-side dispatch client (`olympus-worker/src/agent_client.py`), the mock runtime (`olympus-worker/src/testing/mock_agent_runtime.py`), the Temporal dispatch activity that drives validation retries (`temporal/olympus_workflows/activities/agent_dispatch.py`), and the `/api/v1/skills/dispatch/{id}` endpoint the runtime consumes for skill loading (`olympus-api/src/routers/skills.py`). **NEW at HEAD: the multi-provider dispatch subsystem (`src/services/provider_*.py`, `src/services/tool_executor.py`, `src/services/model_rates.py`, `src/services/gateway_router.py`, `src/providers/`) and the workspace memory-backend abstraction (`src/services/memory_backend.py`).**

**Companion contract.** Section 1's *system-prompt envelope* (`build_system_prompt`) is the exact contract that the skill-authoring doc (Phase 5's other file) and every `SKILL.md` must match. It is reproduced verbatim — section order, headers, and content — because a skill that mis-formats its output against this envelope fails validation and gets retried/abandoned.

---

## 0. Component Map & File Inventory

| File | Role |
|---|---|
| `olympus-agent-runtime/src/main.py` | FastAPI app factory; **imports `src.providers` to populate the provider registry at startup**; wires concurrency semaphore into health + a2a routers |
| `olympus-agent-runtime/src/config.py` | `AgentRuntimeConfig` (pydantic-settings); env-driven. **NEW fields: inference-profile ARNs, AgentCore spike flags, `skill_timeout_seconds`/`skill_max_turns`/`skill_max_budget_usd`** |
| `olympus-agent-runtime/src/routers/a2a.py` | `POST /a2a/tasks` endpoint; semaphore fail-fast (503); skill load → **provider+tier resolution (FedRAMP fail-closed)** → model select → `_dispatch` (with one cross-provider fallback hop) |
| `olympus-agent-runtime/src/routers/health.py` | `GET /health`, `GET /health/ready` |
| `olympus-agent-runtime/src/models/a2a.py` | `A2AContext`, `A2ATaskRequest`, `A2ATaskResponse`, `TokenUsage`, `OutputFile` |
| `olympus-agent-runtime/src/services/agent_executor.py` | `execute_skill` pipeline (now `:1183`); workspace mgmt; **S3 source-clone cache**; prompt assembly; artifact fetch/collect; validation; failure markers; **`asyncio.timeout` wrapper + timeout response**; `normalize_system_prompt` |
| `olympus-agent-runtime/src/services/memory_backend.py` | **NEW** — `MemoryBackend` ABC; `LocalWorkspaceMemoryBackend` (default, delegates to executor); `AgentCoreMemoryBackend` (flag-gated spike); `resolve_memory_backend` |
| `olympus-agent-runtime/src/services/output_validator.py` | Strict JSON-Schema validation; `OutputValidationError`; schema resolution |
| `olympus-agent-runtime/src/services/model_selector.py` | `ModelSelector.select` → **`ModelSelection(model_id, canonical_model)`**; tier→model resolution + fallback chain; **inference-profile ARN substitution; `bedrock`→`bedrock-claude` shim; `fedramp_compliant` + `hosting_provider`** |
| `olympus-agent-runtime/src/services/provider_client.py` | **NEW** — `ProviderClient` ABC + `ProviderCapabilities` dataclass (the multi-provider dispatch contract) |
| `olympus-agent-runtime/src/services/provider_factory.py` | **NEW** — provider registry (`register`/`get_provider`/`get_capabilities`/`list_providers`) |
| `olympus-agent-runtime/src/services/provider_selection.py` | **NEW** — `resolve_provider_and_tier` (5-layer precedence + FedRAMP fail-closed `FedRampComplianceError`); `select_fallback_provider`; `provider_is_fedramp_compliant` |
| `olympus-agent-runtime/src/services/tool_executor.py` | **NEW** — `ToolExecutor`: Olympus-owned sandboxed Read/Write/Glob/Grep/Bash for non-Claude providers |
| `olympus-agent-runtime/src/services/model_rates.py` | **NEW** — reads `rates`/`fedramp_compliant`/`provider_fallback_order` from `models.yaml` |
| `olympus-agent-runtime/src/services/gateway_router.py` | **NEW** — `ToolRouter` ABC; `DirectToolRouter` (default); `AgentCoreGatewayRouter` (flag-gated spike); `resolve_tool_router` |
| `olympus-agent-runtime/src/providers/__init__.py` | **NEW** — imports each provider module so it self-registers |
| `olympus-agent-runtime/src/providers/bedrock_claude.py` | **NEW** — live; thin adapter that calls `execute_skill` |
| `olympus-agent-runtime/src/providers/openai_provider.py` | **NEW** — live; OpenAI SDK + `ToolExecutor` tool loop + rate-table cost |
| `olympus-agent-runtime/src/providers/gemini_vertex.py` | **NEW** — scaffold (`live=False`, `execute` raises) |
| `olympus-agent-runtime/src/providers/_bedrock_converse_scaffold.py` | **NEW** — shared base for Nova/Mistral/Llama scaffolds |
| `olympus-agent-runtime/src/providers/bedrock_nova.py`, `bedrock_mistral.py`, `bedrock_llama.py` | **NEW** — scaffolds subclassing `BedrockConverseScaffold` |
| `olympus-agent-runtime/src/services/skill_loader.py` | `SkillDefinition` (now carries `provider` + `config_model_tier`); API-first + filesystem skill loading; profile overlays |
| `olympus-agent-runtime/src/services/profile_context.py` | `MissionContext`, `load_mission_context`; **NEW `load_agent_dispatch_config`** from `OLYMPUS_PROFILE_ROOT` |
| `olympus-agent-runtime/src/services/task_recorder.py` | Fire-and-forget telemetry to Agents API (**+`provider_name`/`provider_fallback_from`/`ERROR_CODE_FEDRAMP`**) |
| `olympus-agent-runtime/config/models.yaml` | **REWRITTEN** — multi-provider catalog (tiers, fallback, aliases, **rates, `fedramp_compliant`, `hosting_provider`, `sdk`, `provider_fallback_order`**) |
| `olympus-agent-runtime/config/skill_mapping.yaml` | Legacy dispatch-id→dir map (intentionally EMPTY) |
| `olympus-worker/src/agent_client.py` | `dispatch_via_a2a` + 503 saturation retry (worker → runtime) |
| `olympus-worker/src/testing/mock_agent_runtime.py` | `dispatch_via_mock` fixture-backed runtime (DECISION-018) |
| `olympus-worker/src/config.py` | `AGENT_RUNTIME_MODE` validation; production-refuses-mock gate |
| `olympus-worker/src/worker.py` | Worker bootstrap; calls `validate_agent_runtime_mode()` at startup |
| `temporal/olympus_workflows/activities/agent_dispatch.py` | `dispatch_agent_task` activity; `AGENT_RETRY_POLICY`; mock-vs-live routing; agent_task DB rows |
| `olympus-api/src/routers/skills.py` | `GET /api/v1/skills/dispatch/{id}` (skill load source for API-first path) |

⚠️ **GOTCHA — two services, one contract.** The agent runtime (`olympus-agent-runtime`) and the worker (`olympus-worker`) are SEPARATE deployables. `AGENT_RUNTIME_MODE` lives in the **worker** (`olympus-worker/src/config.py`), NOT in the runtime. The worker chooses whether to call the runtime over HTTP (live) or short-circuit to fixtures (mock); the runtime then chooses (per dispatch) which **provider** to execute through. The runtime's `src/` has ZERO references to `AGENT_RUNTIME_MODE` or `MockAgentRuntime`.

⚠️ **GOTCHA — CHANGED: the runtime no longer "always executes via the Claude Agent SDK".** At HEAD it executes through a resolved `ProviderClient` (§6). The Claude path (`bedrock-claude`) still routes to `execute_skill`/the Claude Agent SDK and is byte-for-byte the prior behavior — but OpenAI is a live alternate provider, and Nova/Mistral/Llama/Gemini are registered scaffolds. Provider selection happens per-request in the a2a router (§4.4, §6.2).

---

## 1. THE `execute_skill` PIPELINE (the core)

`agent_executor.py:1183` `async def execute_skill(...)`. **Signature CHANGED at HEAD** (`:1183-1202`) — gained `timeout_seconds`, `max_turns`, `max_budget_usd`, `memory_backend`:

```
execute_skill(
    skill: SkillDefinition,
    task_message: str,
    model_id: str,                              # already fully-qualified (e.g. "us.anthropic.claude-sonnet-4-6[1m]") OR an inference-profile ARN
    app_id: str = "",
    source_repo: str = "",
    workspace_key: str = "",
    workspace_dir: str = "/workspace",
    permission_mode: str = "acceptEdits",
    task_type: str = "",
    input_artifacts: list[str] | None = None,
    optional_input_artifacts: list[str] | None = None,
    artifact_repo: str = "",
    artifact_ref: str = "",
    mission_context: MissionContext | None = None,
    timeout_seconds: int | None = None,         # NEW — wall-clock ceiling around the query() stream (None = no ceiling)
    max_turns: int | None = None,               # NEW — ClaudeAgentOptions.max_turns (None = SDK default)
    max_budget_usd: float | None = None,        # NEW — ClaudeAgentOptions.max_budget_usd (None = SDK default)
    memory_backend: "MemoryBackend | None" = None,  # NEW — pluggable workspace backend; None → resolved from config
) -> A2ATaskResponse
```

### 1.1 Full pipeline pseudocode (preserve EVERY branch)

```
FUNCTION execute_skill(skill, task_message, model_id, app_id, source_repo,
                       workspace_key, workspace_dir, permission_mode,
                       task_type, input_artifacts, optional_input_artifacts,
                       artifact_repo, artifact_ref, mission_context,
                       timeout_seconds, max_turns, max_budget_usd, memory_backend):

  # --- Step 0: SDK availability guard (:1230) ---
  IF NOT _SDK_AVAILABLE:                                   # module import of claude_agent_sdk failed
      RAISE RuntimeError("claude_agent_sdk is not installed. "
                         "Install with: pip install 'olympus-agent-runtime[agent]'")
      # NOTE: this is a *raise*, not a failed-response. The a2a router's _dispatch
      # (a2a.py:205, the bedrock/bedrock-claude branch around execute_skill) catches
      # RuntimeError and re-raises it as _ProviderUnavailable → the router attempts ONE
      # fallback hop, then if none qualifies returns status=failed +
      # ERROR_CODE_SDK_UNAVAILABLE (§4.4). (The BedrockClaudeProvider class itself does
      # NOT catch it — its execute() just calls execute_skill; bedrock_claude.py is 123 lines.)

  start_ms = int(time.time() * 1000)                       # :1236 wall-clock start

  # --- Step 0.5: resolve memory backend (:1248-1252) — NEW ---
  IF memory_backend is None:
      from src.config import get_config
      from src.services.memory_backend import resolve_memory_backend
      memory_backend = resolve_memory_backend(get_config())   # §1.7
      # DEFAULT PATH: OLYMPUS_AGENTCORE_MEMORY_ENABLED false → LocalWorkspaceMemoryBackend,
      # whose setup/cleanup delegate VERBATIM to _setup_workspace / _cleanup_workspace.
      # So the flag-off path is byte-for-byte the prior behavior.

  os.makedirs(workspace_dir, exist_ok=True)                # :1255 ensure base dir

  workspace_path = None; artifacts_dir = ""; cwd = None    # :1258-1260

  # --- Step 1: workspace setup via the memory backend (:1262-1292) ---
  TRY:
      workspace_path, source_dir, artifacts_dir = memory_backend.setup_workspace(
          workspace_dir=workspace_dir, workspace_key=workspace_key,
          source_repo=source_repo, task_type=task_type)   # delegates to _setup_workspace (§1.4)
      IF _repo_already_cloned(source_dir):                 # source_dir/.git exists
          cwd = source_dir                                 # agent CWD = the cloned repo
      ELSE:
          cwd = workspace_path                             # else workspace root
      LOG info "Workspace ready" {workspace, cwd, artifacts_dir, reused=bool(workspace_key)}
  EXCEPT Exception as exc:                                 # ANY setup failure
      LOG error "Failed to set up workspace: %s"
      RETURN A2ATaskResponse(status="failed", model_used=model_id,
                             duration_ms=now_ms - start_ms,
                             error=f"Failed to set up workspace: {exc}")
      # early-return #1 — NO workspace cleanup (nothing created reliably)

  # --- Step 2: input-artifact fetch (:1294-1329) ---
  input_artifacts_dir = ""
  IF (input_artifacts OR optional_input_artifacts) AND artifact_repo:
      input_artifacts_dir = workspace_path / "input-artifacts"
      IF input_artifacts:                                  # REQUIRED inputs
          TRY:
              _fetch_input_artifacts(artifact_repo, list(input_artifacts),
                                     input_artifacts_dir,
                                     artifact_ref=artifact_ref, required=True)   # §1.5
          EXCEPT Exception as exc:
              LOG error "Failed to fetch input artifacts: %s"
              RETURN A2ATaskResponse(status="failed", model_used=model_id,
                                     duration_ms=now_ms - start_ms,
                                     error=f"Failed to fetch input artifacts: {exc}")
              # early-return #2 — required-artifact miss is fatal. NO cleanup.
      IF optional_input_artifacts:                         # OPTIONAL inputs
          TRY:
              _fetch_input_artifacts(..., required=False)  # missing paths logged+skipped
          EXCEPT Exception as exc:
              LOG warning "Error fetching optional input artifacts (continuing): %s"
              # swallow — optional inputs NEVER fail the dispatch

  # --- Step 3: resolve mission context (:1335-1337) ---
  resolved_mission_context = mission_context if mission_context is not None else load_mission_context()
      # caller-supplied wins; else env-var / cached (§5)

  # --- Step 4: read retry feedback marker (:1343-1345) ---
  previous_failure_feedback = _read_failure_marker(workspace_path) if workspace_path else ""
      # marker = ".previous-validation-failure.json" written by a PRIOR attempt (§2.4)

  # --- Step 5: BUILD SYSTEM PROMPT (:1347-1354) — THE ENVELOPE, §1.2 ---
  system_prompt = build_system_prompt(
      skill, app_id, artifacts_dir, input_artifacts_dir,
      mission_context=resolved_mission_context,
      previous_failure_feedback=previous_failure_feedback)
      # ⚠️ positional args: output_dir=artifacts_dir, input_artifacts_dir passed positionally.

  # --- Step 6: tool list (:1358-1360) ---
  tools = skill.allowed_tools OR ["Read", "Glob", "Grep", "Write", "Bash"]   # default when empty
  IF "Agent" NOT in tools:
      tools = [*tools, "Agent"]                            # Agent tool ALWAYS appended

  # --- Step 7: build SDK options (:1418-1425) ---
  options = ClaudeAgentOptions(
      allowed_tools=tools,
      system_prompt=system_prompt_param,                   # str OR file-dict (see Step 7b)
      permission_mode=permission_mode,                     # default "acceptEdits"
      model=model_id,
      cwd=cwd,
      add_dirs=[workspace_path] if workspace_path else [],  # ⚠️ ONLY this dispatch's workspace_path (NOT parent workspace_dir) — cross-app read isolation
  )

  # --- Step 7b: system-prompt spill-to-file (:1387-1403; computed BEFORE options) ---
  system_prompt_param = system_prompt                      # default: inline string
  _SYSTEM_PROMPT_FILE_THRESHOLD = 64 * 1024
  IF workspace_path AND len(system_prompt.encode("utf-8")) > 64KB:
      system_prompt_path = workspace_path / "system-prompt.txt"
      write system_prompt to that file (utf-8)
      LOG info "System prompt size %d bytes exceeds inline threshold; spilling ..."
      system_prompt_param = {"type": "file", "path": system_prompt_path}
      # ⚠️ GOTCHA: SDK passes a plain string as `--system-prompt <inline>` (argv);
      #   composite skills can exceed OS ARG_MAX (~256KB Linux; observed [Errno 7]
      #   Argument list too long at ~150KB). The dict {"type":"file","path":...}
      #   switches the CLI to `--system-prompt-file <path>` (bounded by disk size).

  # --- Step 8: harness safety bounds (:1433-1436) — NEW ---
  IF max_turns is not None:    options.max_turns = max_turns           # cap agentic loop length
  IF max_budget_usd is not None: options.max_budget_usd = max_budget_usd  # cap cost
      # ⚠️ Both no-ops when None (SDK default). The WALL-CLOCK timeout is enforced
      #   SEPARATELY via asyncio.timeout around the stream (Step 11) — the SDK exposes
      #   no query-level timeout.

  # --- Step 8b: stderr capture (:1441-1444) — NEW ---
  DEFINE _log_cli_stderr(line): LOG warning "claude-cli stderr: %s" % line.rstrip()
  options.stderr = _log_cli_stderr
      # The SDK's query() goes silent when a child (sub-agent) subprocess stalls;
      # surfacing the CLI's stderr gives a breadcrumb for *why*.

  # --- Step 8c: MCP servers (:1447-1448) ---
  IF skill.mcp_servers:                                    # from config.json
      options.mcp_servers = skill.mcp_servers

  LOG info "Executing skill via Claude Agent SDK" {skill, model, tools=skill.allowed_tools}

  # --- Step 9: snapshot pre-existing artifacts (delta basis) (:1460-1468) ---
  _pre_existing_files = set()
  IF artifacts_dir AND Path(artifacts_dir).exists():
      _pre_existing_files = { relpath(p) for p in artifacts_dir.rglob("*") if p.is_file() }
      # only files NEW after the run get collected.

  # --- Step 10: telemetry/timing accumulators (:1470-1513) ---
  result_text = None; total_cost = 0.0; input_tokens = 0; output_tokens = 0
  tool_call_counts = {}; tool_call_samples = []; _SAMPLE_CAP = 20
  llm_ms = 0; tool_ms = 0; phase = "llm"; phase_start_ns = time.monotonic_ns()
  # _flush_phase(new_phase): delta = (now_ns - phase_start_ns)//1e6;
  #   if phase=="llm": llm_ms += delta; elif phase=="tool": tool_ms += delta;
  #   phase = new_phase; phase_start_ns = now_ns.   (:1503-1513)

  # --- Step 11: STREAM the SDK query, WRAPPED IN A WALL-CLOCK TIMEOUT (:1524-1655) — CHANGED ---
  _effective_timeout = timeout_seconds if (timeout_seconds and timeout_seconds > 0) else None   # :1524-1526
  TRY:
      ASYNC WITH asyncio.timeout(_effective_timeout):                # :1528 — NEW wrapper
          ASYNC FOR message IN query(prompt=task_message, options=options):   # :1529

              IF _ResultMessage is not None AND isinstance(message, _ResultMessage):   # :1531 (None-guarded)
                  _flush_phase("llm")                           # remaining time = final LLM output
                  result_text = message.result OR ""
                  total_cost = getattr(message,"total_cost_usd",None) OR 0.0
                  usage = getattr(message,"usage",None)
                  IF isinstance(usage, dict):
                      input_tokens = usage.get("input_tokens", 0)
                      output_tokens = usage.get("output_tokens", 0)
                  num_turns = getattr(message,"num_turns",None)   # NEW — logged
                  stop_reason = getattr(message,"stop_reason",None)  # NEW — logged (e.g. "end_turn", "max_turns")
                  LOG info "Agent completed, cost=$.. llm_ms=.. tool_ms=.. num_turns=.. stop_reason=.. tool_calls=.."
                  CONTINUE

              IF _AssistantMessage is not None AND isinstance(message, _AssistantMessage):   # :1567 (None-guarded)
                  has_tool_use = False
                  FOR block IN (message.content OR []):
                      IF _ToolUseBlock is None OR not isinstance(block, _ToolUseBlock): CONTINUE   # None-guard
                      has_tool_use = True
                      name = getattr(block,"name","unknown")
                      tool_call_counts[name] += 1
                      IF len(tool_call_samples) < 20:          # capture first 20 distinct calls
                          raw_input = getattr(block,"input",{}) OR {}
                          truncated = { k: (v if (not str or len<240) else v[:240]+"…") for k,v in raw_input }
                          tool_call_samples.append({"tool":name,"input":truncated})
                          LOG info "Agent tool call #N: name input=.."
                  _flush_phase("tool" if has_tool_use else "llm")   # next wait = tool exec OR more LLM
                  CONTINUE

              IF _UserMessage is not None AND isinstance(message, _UserMessage):   # :1615 (None-guarded)
                  has_tool_result = False
                  IF _ToolResultBlock is not None:
                      FOR block IN (message.content OR []):
                          IF isinstance(block, _ToolResultBlock): has_tool_result = True; BREAK
                  IF has_tool_result:
                      _flush_phase("llm")                      # tool finished → back to waiting on LLM
                  CONTINUE

  EXCEPT (TimeoutError, asyncio.TimeoutError):                 # :1627 — NEW 6th early-return
      _flush_phase("llm")
      duration_ms = now_ms - start_ms
      LOG error "Agent execution timed out after %ss (skill=.., app=..) — likely a stalled sub-agent; tool_calls=.."
      IF workspace_path: memory_backend.cleanup_workspace(workspace_path=workspace_path, workspace_key=workspace_key)
      RETURN A2ATaskResponse(status="timeout", model_used=model_id, duration_ms=duration_ms,
                             error=f"skill execution exceeded {_effective_timeout}s (stalled stream / sub-agent)")
      # ⚠️ early-return #6 — status="timeout" (NOT "failed"). The async with cancels the generator;
      #   the SDK transport SIGTERM/SIGKILLs child subprocesses on __aexit__ (no leaked node procs).
      #   Cleanup runs (ephemeral wiped, persistent kept). NO failure marker written (this is not a
      #   validation failure — it's a stall). The a2a router maps "timeout" → terminal "timed_out"
      #   + ERROR_CODE_TIMEOUT (§4.4).

  EXCEPT Exception as exc:                                     # :1656 SDK raised mid/after stream
      IF result_text is not None:                              # we already saw a ResultMessage
          LOG warning "SDK raised after ResultMessage (treating as success): %s"
          # ⚠️ GOTCHA: SDK may raise on non-zero CLI exit AFTER a valid ResultMessage.
          #   The agent DID complete (artifacts written, cost recorded) → fall through.
      ELSE:
          LOG error "Agent execution failed: %s"
          IF workspace_path: memory_backend.cleanup_workspace(workspace_path=..., workspace_key=...)  # cleanup only if ephemeral
          duration_ms = now_ms - start_ms
          RETURN A2ATaskResponse(status="failed", model_used=model_id,
                                 duration_ms=duration_ms, error=str(exc))
          # early-return #3 — genuine SDK failure, no result captured.

  duration_ms = now_ms - start_ms                              # :1682

  # --- Step 12: collect NEW artifacts (delta) (:1685-1695) ---
  output_files = _collect_artifacts(artifacts_dir, exclude=_pre_existing_files) if artifacts_dir else []
  IF output_files: LOG info "Collected %d artifact files from %s"

  # --- Step 13: STRICT VALIDATION (:1709-1724) — §2 ---
  TRY:
      validate_output_files(output_files, skill.output_schemas)
  EXCEPT OutputValidationError as exc:
      LOG error "Output validation failed: %s"
      IF workspace_path:
          _write_failure_marker(workspace_path, exc)           # persist violations for NEXT attempt (§2.4)
          memory_backend.cleanup_workspace(workspace_path=..., workspace_key=...)  # ⚠️ marker survives if workspace_key set; tempdir wiped if not
      RETURN A2ATaskResponse(status="failed", model_used=model_id,
                             duration_ms=duration_ms,
                             output_files=output_files,         # ⚠️ failed response STILL carries the files
                             error=f"output validation failed: {exc}")
      # early-return #4 — validation failure. Marker drives Temporal retry-with-feedback.

  # ⚠️ GOTCHA — STEP 13 IS DORMANT ON THE LIVE API-LOAD PATH (unchanged from prior baseline).
  #   `validate_output_files(output_files, skill.output_schemas)` only does work when
  #   `skill.output_schemas` is non-empty. On the live API-first load path it is ALWAYS []
  #   (§5.2). So `validate_output_files` hits its `IF not schemas: RETURN output_files`
  #   short-circuit (output_validator.py:169-170), early-return #4 is unreachable, NO failure
  #   marker is written, and §2.6's retry chain never starts — for skills loaded via the API.
  #   This path is exercised ONLY via the deprecated filesystem load (§5.3) or a future API
  #   change. (The frontmatter field IS still enforced live, but on a DIFFERENT endpoint —
  #   the human-paired RETURN flow, §5.2.1 path 3.)

  # --- Step 14: clear stale marker on clean run (:1728-1729) ---
  IF workspace_path: _clear_failure_marker(workspace_path)     # success → remove any leftover marker

  # --- Step 15: cleanup ephemeral workspace (:1732-1735) ---
  IF workspace_path: memory_backend.cleanup_workspace(workspace_path=..., workspace_key=...)
      # _cleanup_workspace only rmtrees when workspace_key == "" (ephemeral). Persistent kept for reuse.

  # --- Step 16: missing-result guard (:1737-1744) ---
  IF result_text is None:                                      # stream ended w/o ResultMessage
      RETURN A2ATaskResponse(status="failed", model_used=model_id,
                             duration_ms=duration_ms, output_files=output_files,
                             error="No result message received from SDK")
      # early-return #5

  # --- Step 17: success response (:1749-1764) ---
  tool_call_total = sum(tool_call_counts.values())
  RETURN A2ATaskResponse(
      status="completed",
      output_artifacts=[result_text],                          # the final agent summary text (single-element list)
      output_files=output_files,
      model_used=model_id,
      token_usage=TokenUsage(input=input_tokens, output=output_tokens,
                             llm_ms=int(llm_ms), tool_ms=int(tool_ms),
                             tool_call_count=int(tool_call_total)),
      cost_estimate_usd=total_cost,
      duration_ms=duration_ms)
```

⚠️ **GOTCHA — SIX early-returns now, not five. The timeout branch (#6) is NEW.** Order on the wire: #1 setup-fail, #2 fetch-fail (both before any cleanup), #3 SDK-fail-no-result, #4 validation-fail, **#6 timeout (`status="timeout"`)**, #5 no-result-tail. #6 lives in the `except (TimeoutError, asyncio.TimeoutError)` clause that wraps the whole `async with asyncio.timeout(...)` stream. A re-implementer that omits the `asyncio.timeout` wrapper reproduces a hang: a stalled sub-agent blocks the `async for` forever (observed ~48 min before the worker's 60-min HTTP ReadTimeout killed it and re-ran the whole skill).

⚠️ **GOTCHA — cleanup asymmetry (CHANGED to go through `memory_backend.cleanup_workspace`).** Cleanup happens on: SDK-failure (#3), **timeout (#6)**, validation-failure (#4 — after writing the marker), and the success/no-result tails (#15/#16). The workspace-setup failure (#1) and artifact-fetch failure (#2) early-returns do NOT clean up. All cleanup calls now go through `memory_backend.cleanup_workspace(...)` (default backend delegates to `_cleanup_workspace`, which rmtrees ONLY when `workspace_key == ""`).

⚠️ **GOTCHA — `output_files` on failure.** The validation-failure response (#4) and no-result response (#16) include `output_files`. The SDK-failure (#3), timeout (#6), and setup/fetch failures (#1/#2) do not.

⚠️ **GOTCHA — None-guards on SDK message types.** Every `isinstance(message, _ResultMessage|_AssistantMessage|_UserMessage)` is preceded by `_X is not None` (the module-level type sentinels, set only on successful SDK import — `:66-94`). Same for `_ToolUseBlock`/`_ToolResultBlock` inside the loops. Reproduce these guards: without them, a stripped install where the SDK import failed would `NameError` instead of cleanly raising the Step-0 `RuntimeError`.

### 1.2 ⚠️ THE SYSTEM-PROMPT ENVELOPE — `build_system_prompt` (`agent_executor.py:193`)

This is the **precise contract** every skill receives. The function concatenates `parts` (a `list[str]`) and returns `"\n".join(parts)`. The PRECISE SECTION ORDER and headers (reproduce verbatim — unchanged from the prior baseline; only the line numbers shifted):

```
build_system_prompt(skill, app_id="", output_dir="", input_artifacts_dir="",
                    mission_context=None, previous_failure_feedback=""):     # :193
  parts = []

  # ── SECTION 1 — PROGRAM/MISSION CONTEXT (FIRST; :218-222) ──
  IF mission_context is not None AND mission_context.body.strip():
      parts.append( "# {mission_context.heading}\n\n"
                    "{mission_context.body.rstrip()}\n\n---" )
      # ⚠️ Intentionally the FIRST thing the agent sees — strategic framing.

  # ── SECTION 2 — CORE SKILL INSTRUCTIONS (:225-226) ──
  IF skill.system_prompt:                                   # the SKILL.md markdown body
      parts.append(skill.system_prompt)

  # ── SECTION 3 — REFERENCE DOCS (one block each; :229-230) ──
  FOR ref_name, ref_content IN skill.references.items():    # dict iteration = sorted *.md (loader sorts)
      parts.append( "\n\n--- Reference: {ref_name} ---\n{ref_content}" )

  # ── SECTION 4 — OUTPUT TEMPLATES (one block each; :233-234) ──
  FOR asset_name, asset_content IN skill.assets.items():    # from assets/ dir (loader sorts)
      parts.append( "\n\n--- Output Template: {asset_name} ---\n{asset_content}" )

  # ── SECTION 5 — OUTPUT CONTRACT (STRICT) (:242-282) ──
  # ⚠️ GOTCHA — SECTION 5 IS DORMANT ON THE LIVE API-LOAD PATH (skill.output_schemas == [] there; §5.2).
  #   Reproduce the guard exactly; do NOT make Section 5 appear on the API path.
  IF skill.output_schemas:                                  # list of {path, schema}
      contract_lines = [
        "\n\n--- Output Contract (STRICT — your output MUST conform) ---",
        "Every file path listed below has a binding JSON Schema. The Olympus "
        "runtime validates your output against these schemas after you finish; "
        "any violation returns a hard failure. The schemas are reproduced "
        "verbatim — read them before you write the first byte of any output file." ]
      FOR entry IN skill.output_schemas:
          path = entry.get("path",""); schema_ref = entry.get("schema","")
          IF not path OR not schema_ref: CONTINUE           # skip malformed entries
          schema_doc = load_schema(schema_ref)              # §2.2
          IF schema_doc is None:                            # declared but unloadable
              contract_lines.append(
                "\n### {path}\nDeclared schema: {schema_ref}\n"
                "Schema file could not be loaded by the runtime. Emit valid JSON "
                "conforming to your skill's stated structure; the runtime cannot "
                "enforce a schema that isn't loadable, but a downstream consumer "
                "may still reject malformed output." )
              CONTINUE
          TRY: schema_text = json.dumps(schema_doc, indent=2)
          EXCEPT (TypeError,ValueError): schema_text = str(schema_doc)
          contract_lines.append(
            "\n### {path}\nSchema source: {schema_ref}\n```json\n{schema_text}\n```" )
      parts.append("\n".join(contract_lines))

  # ── SECTION 6 — CONTEXT (:285-301) ──
  ctx_parts = []
  IF app_id:                          ctx_parts.append("Application ID: {app_id}")
  IF input_artifacts_dir:             ctx_parts.append("Input Artifacts Directory: {input_artifacts_dir}\n"
                                                        "Prior assembly-line artifacts have been staged here. "
                                                        "Read them to inform your analysis.")
  IF output_dir:                      ctx_parts.append("Output Directory: {output_dir}\n"
                                                        "All output files MUST be written to this directory. "
                                                        "Use subdirectories as needed to organize deliverables.")
  IF ctx_parts:
      parts.append("\n\n--- Context ---\n" + "\n".join(ctx_parts))

  # ── SECTION 7 — PLATFORM CAPABILITY: PARALLEL SUB-AGENTS (always; :308-329) ──
  parts.append("\n\n--- Platform Capability: Parallel Sub-Agents ---\n"
               "You have the ``Agent`` tool available via the Claude Agent SDK. "
               "[full text: decompose per module/dir/file-class/sibling feature; single tool-call "
               "round → concurrent; bounded activity timeout; prefer parallel over linear pass] ... "
               "When you DO invoke a sub-agent (Agent tool), include explicit batching guidance in "
               "its ``prompt`` ... add a line like \"Read all files in parallel by emitting every "
               "Read in a single turn\".")

  # ── SECTION 8 — PLATFORM CAPABILITY: PARALLEL TOOL CALLS (always; :340-363) ──
  parts.append("\n\n--- Platform Capability: Parallel Tool Calls ---\n"
               "When you need to make multiple independent tool calls in the same step, emit them "
               "ALL in a single assistant turn ... Default to batching.\n\nStrong rules:\n"
               "- **Reads for context gathering**: ... issue every Read in the first turn ...\n"
               "- **Grep + Glob + LS exploration**: ... batch ...\n"
               "- **Bash probes** ...: batch when independent.\n"
               "- **Write calls**: ... emit every Write in one turn.\n\n"
               "Only serialize tool calls when a later call genuinely needs output from an earlier one ...")

  # ── SECTION 9 — PREVIOUS-FAILURE FEEDBACK (LAST; only if present; :373-386) ──
  IF previous_failure_feedback.strip():
      parts.append("\n\n--- IMPORTANT: PREVIOUS ATTEMPT FAILED SCHEMA VALIDATION ---\n"
                   "Your previous output for this task did NOT conform to the declared output_schemas "
                   "contract. Read the validation violations below carefully and emit ONLY valid JSON for "
                   "the structured artifacts. Do NOT include any prose, markdown, preamble, or explanation "
                   "in the .json file paths — narrative belongs in the .md sidecar files only.\n\n"
                   "{previous_failure_feedback.strip()}\n\n"
                   "Re-run the analysis from the input artifacts that were staged for you and re-emit every "
                   "output file. Do not partially patch the previous output — produce a fresh, schema-valid set.")

  RETURN "\n".join(parts)
```

⚠️ **GOTCHA — ENVELOPE ORDER IS THE CONTRACT.** Fixed and load-bearing: (1) mission/program context → (2) skill body → (3) references → (4) assets/templates → (5) output contract w/ verbatim JSON schemas → (6) context (app_id / input dir / output dir) → (7) parallel sub-agents → (8) parallel tool calls → (9) failure feedback. Mission FIRST, corrective feedback LAST. Sections 7+8 are ALWAYS appended (no conditional).

⚠️ **GOTCHA — where inputs/context/priors land:**
- **Mission/profile context** → Section 1 (whole document body, prepended).
- **Prior assembly-line artifacts (input_artifacts)** → fetched onto disk under `workspace_path/input-artifacts/<repo-relative-path>` (§1.5); the *directory path* is announced in Section 6. Contents are NOT inlined — the agent must `Read` them.
- **Output contract** → Section 5 inlines each declared JSON Schema verbatim.
- **`app_id`** → Section 6.
- **Workflow `extras`** (e.g. `gate_type: G-RR`) → NOT in `build_system_prompt`. They reach the agent via the `task_message` only (worker's `_build_task_message` renders `context` inline — §4.2).

### 1.2.1 ⚠️ NEW: `normalize_system_prompt(raw, provider)` (`agent_executor.py:391`)

Adapts a Claude-flavored prompt for a non-Claude provider. Used by `OpenAIProvider.execute` (§6.3), NOT by the Claude `execute_skill` path.

```
normalize_system_prompt(raw, provider):
  IF provider in ("", "bedrock-claude", "anthropic"):  RETURN raw          # Claude family: verbatim (:410-411)
  marker = "\n\n--- Platform Capability: Parallel Sub-Agents ---"
  idx = raw.find(marker)
  IF idx == -1:  RETURN raw                                                # no sub-agent block → unchanged
  rest = raw[idx+len(marker):]
  next_section = rest.find("\n\n--- ")
  IF next_section == -1:  RETURN raw[:idx].rstrip()                        # drop everything from marker on
  RETURN (raw[:idx].rstrip() + "\n" + rest[next_section:]).rstrip()        # excise ONLY the sub-agent block
```

⚠️ **GOTCHA — only the Parallel Sub-Agents block (Section 7) is stripped for non-Claude providers** (they lack the SDK `Agent` tool). The Output Contract (Section 5) and Parallel-Tool-Calls (Section 8) sections are PRESERVED — they are provider-agnostic.

### 1.3 `SkillDefinition` (`skill_loader.py:32-65`) — CHANGED (two new fields)

```
@dataclass SkillDefinition:
  name: str
  description: str
  skill_dir: str
  model_tier: str = "tier-2"
  allowed_tools: list[str] = []
  system_prompt: str = ""              # the SKILL.md body (frontmatter stripped, .strip()'d)
  references: dict[str,str] = {}       # {filename: content} from references/*.md (sorted)
  assets: dict[str,str] = {}           # {filename: content} from assets/* text files (sorted)
  config: dict = {}                    # config.json contents
  mcp_servers: dict = {}               # populated from config (attached to SDK options if present)
  provider: str = ""                   # NEW (P6-S2.5) — per-skill provider override; "" = inherit profile/global default
  config_model_tier: str = ""          # NEW (P6-S2.5) — per-skill tier override from config.json model_tier
  output_schemas: list[dict] = []      # [{"path":..., "schema":...}] — drives validation + Section 5
```

⚠️ **GOTCHA — `provider` precedence: config.json wins over SKILL.md frontmatter.** `load_skill`/`load_skill_from_api` compute `provider = _coerce_provider(config["provider"]) or _coerce_provider(frontmatter/data["provider"])` (`skill_loader.py:114-116, 230-232`). `config_model_tier = _coerce_str(config["model_tier"])`. Both feed the selection resolver (§4.3). A malformed `provider` value coerces to `""` (falls through to default), never raises.

### 1.4 `_setup_workspace` (`agent_executor.py:751`) — CHANGED (S3 source-clone cache)

```
_setup_workspace(workspace_dir, workspace_key, source_repo, task_type) -> (workspace_path, source_dir, artifacts_dir):
  # --- path-segment safety (CodeQL py/path-injection) (:775-786) ---
  safe_workspace_key = workspace_key IF _is_safe_path_segment(workspace_key) ELSE ""
  IF workspace_key AND not safe_workspace_key: LOG warning "Rejected unsafe workspace_key ...; using tempdir"
  safe_task_type = task_type IF _is_safe_path_segment(task_type) ELSE ""
  IF task_type AND not safe_task_type: LOG warning "Rejected unsafe task_type ...; using unscoped artifacts dir"
  # ⚠️ unsafe inputs DO NOT raise — they degrade (tempdir / unscoped). Dispatch still runs.

  IF safe_workspace_key: workspace_path = workspace_dir / safe_workspace_key          # PERSISTENT
  ELSE:                  workspace_path = tempfile.mkdtemp(prefix="olympus-workspace-", dir=workspace_dir)  # EPHEMERAL

  source_dir = workspace_path / "source"
  IF safe_task_type: artifacts_dir = workspace_path / "artifacts" / safe_task_type    # per-pass scoping
  ELSE:              artifacts_dir = workspace_path / "artifacts"

  # --- defense-in-depth boundary check (realpath + commonpath) (:808-814) ---
  workspace_dir_abs = realpath(workspace_dir)
  FOR candidate IN (workspace_path, source_dir, artifacts_dir):
      IF commonpath([workspace_dir_abs, realpath(candidate)]) != workspace_dir_abs:
          RAISE ValueError("workspace path escape detected; refusing to operate")    # ⚠️ raise (programmer bug)

  makedirs(source_dir, exist_ok=True)

  # --- ⚠️ GOTCHA: clean the task-scoped artifacts dir at dispatch start (:827-829) ---
  IF safe_task_type AND isdir(artifacts_dir):  shutil.rmtree(artifacts_dir)   # avoid prior-attempt leak into delta
  makedirs(artifacts_dir, exist_ok=True)
  # ⚠️ ONLY the task-scoped subdir is wiped; the parent artifacts/ carries OTHER passes' outputs.

  # --- clone source if needed, S3-cache-first (:843-847) — CHANGED ---
  IF source_repo AND not _repo_already_cloned(source_dir):
      restored = _restore_source_from_cache(source_repo, source_dir)   # best-effort S3 tarball restore (§1.4a)
      IF not restored:
          _clone_repo(source_repo, source_dir)                          # git clone --depth 1
          _upload_source_to_cache(source_repo, source_dir)              # best-effort S3 tarball upload

  RETURN (workspace_path, source_dir, artifacts_dir)
```

Helpers:
- `_is_safe_path_segment(v)` (`:61`): `bool(v) AND _SAFE_PATH_SEGMENT.match(v)` where `_SAFE_PATH_SEGMENT = ^[A-Za-z0-9][A-Za-z0-9_.-]{0,127}$` (`:58`). Allows kebab/snake ids; max 128 chars.
- `_repo_already_cloned(d)` (`:852`): `isdir(d/.git)`.
- `_resolve_clone_url(url)` (`:1059`): full `http(s)://` passes through; else expand `owner/repo` slug against `GITHUB_BASE_URL` host (`api.github.com`→`github.com`); append `.git` if absent.
- `_clone_repo(url, target)` (`:1084`): resolves clone URL; injects `GITHUB_TOKEN` as `https://x-access-token:{token}@...` ONLY when `target_host == base_host` (enterprise). ⚠️ Public github.com clones anonymously. Runs `git clone --depth 1 <url> <target>` with `check=True, capture_output=True, timeout=120`.
- `_cleanup_workspace(path, key)` (`:1171`): rmtree ONLY when `key == ""` (ephemeral); logs warning on `OSError`.

#### 1.4a ⚠️ NEW: the S3-backed source-clone cache (`agent_executor.py:857-1056`)

In deployed Fargate, `/workspace` is per-replica ephemeral (no shared volume; EFS blocked), so the "clone once, reuse" optimization was fully defeated (measured 25 clones / 0 reuse hits in 3h). This cache restores it WITHOUT EFS, content-addressed by repo identity. **It is purely a cost/perf optimization for the source clone — entirely best-effort; any S3 error MUST fall back to `git clone` and NEVER fail the dispatch. Git remains the source of truth for ARTIFACTS.**

- `_workspace_cache_bucket()` (`:895`): env `AGENT_WORKSPACE_S3_BUCKET` (empty → caching OFF, so local/test unaffected); kill-switch env `AGENT_WORKSPACE_CACHE_ENABLED` in `{0,false,no,off}` → `""`.
- `_workspace_cache_prefix()` (`:906`): env `AGENT_WORKSPACE_S3_PREFIX`, default `agent-workspace`.
- `_source_cache_key(repo, rev="")` (`:926`): `{prefix}/{sanitized-slug}/{rev or "default"}/source.tar.gz`. `_sanitize_cache_segment` (`:914`) collapses non-`[A-Za-z0-9._-]` to `_`.
- `_s3_client()` (`:940`): lazy `import boto3` (ImportError → LOG warning, `None` → cache disabled); regional client if `AWS_REGION` set.
- `_restore_source_from_cache(repo, source_dir)` (`:958`): bucket/repo/client guards → download to a temp `.tar.gz`, `tar.extractall(source_dir, filter="data")` (Python 3.12+ traversal guard), remove temp; ANY exception → LOG info "cache miss/error ... will clone", RETURN False. RETURN True only if `_repo_already_cloned(source_dir)` after unpack.
- `_upload_source_to_cache(repo, source_dir)` (`:1013`): guards → tar+gzip `source_dir` with `arcname="."`, `client.upload_file`; ANY exception → LOG warning, swallow.

### 1.5 `_fetch_input_artifacts` (`agent_executor.py:598`) — Trees + Blobs API (unchanged behavior)

```
_fetch_input_artifacts(artifact_repo, artifact_paths, target_dir, artifact_ref="", required=True):
  makedirs(target_dir, exist_ok=True)
  token = env GITHUB_TOKEN (default "")
  base  = env GITHUB_BASE_URL (default "https://api.github.com").rstrip("/")
  artifact_repo = _normalize_repo_slug(artifact_repo)        # strips scheme/host/.git → owner/name (:429)

  paths = ordered-unique(p for p in artifact_paths if p)     # dedupe + drop empties, preserve order
  IF not paths: RETURN
  LOG info "Fetching %d {required|optional} input artifacts from {repo}{(ref=..)}"

  # --- Step 1: build path→sha maps (:672-690) ---
  ref_tree = None
  IF artifact_ref:
      ref_tree = _build_path_to_sha_map(base, repo, artifact_ref, token)   # None if ref 404s
      IF ref_tree is None: LOG info "Ref %s not found ...; using default branch only"
  head_tree = _build_path_to_sha_map(base, repo, "HEAD", token)
  IF head_tree is None:
      RAISE RuntimeError("Default branch tree not found for {repo}; repo configuration error")

  # --- Step 2: resolve each path → (path, sha, source) (:695-709) ---
  resolved = []; missing = []
  FOR path IN paths:
      IF ref_tree is not None AND path in ref_tree:  resolved.append((path, ref_tree[path], artifact_ref))   # ⚠️ ref tree WINS
      ELIF path in head_tree:                        resolved.append((path, head_tree[path], "HEAD"))
      ELSE:                                          missing.append(path)

  # --- missing handling (:711-723) ---
  IF missing:
      IF required: RAISE FileNotFoundError("Required input artifact(s) not present on {repo} (ref=.. or default): {missing[:5]}" + " (+N more)" if >5)
      ELSE:        FOR p IN missing: LOG info "Optional artifact %s not present on %s; skipping"
  IF not resolved: RETURN

  # --- Step 3: parallel blob fetch, 8 workers (:731-748) ---
  WITH ThreadPoolExecutor(max_workers=8) as pool:
      futures = [pool.submit(_do, path, sha, source) for (path,sha,source) in resolved]   # _do → (path, _fetch_blob(...), source)
      FOR fut IN as_completed(futures):
          path, content, source = fut.result()
          dest = target_dir / path; makedirs(dirname(dest), exist_ok=True); write content bytes to dest
          LOG debug "Wrote %s (%d bytes) from %s/%s"
```

Supporting fetchers:
- `_gh_get_json(url, token, timeout=30)` (`:450`): urllib GET; `Accept: application/vnd.github+json`; `Authorization: token {token}` if present; decode JSON.
- `_resolve_ref_to_commit_sha(base, repo, ref, token)` (`:462`): if `ref=="HEAD"` → GET `/repos/{repo}` (HTTPError→None), `ref = body.default_branch or "main"`. Then per-segment URL-quote (`safe=""`); GET `/repos/{repo}/git/refs/heads/{quoted}`; 404→None, other HTTPError re-raise; return `body.object.sha` (str, non-empty) else None. ⚠️ **GOTCHA**: branch names with slashes (`olympus/architecture/{uuid}/{run}`) CANNOT be a trees-API path component (GHE router stops at first `/`) — must resolve to SHA first.
- `_build_path_to_sha_map(base, repo, ref, token)` (`:514`): resolve to commit_sha (None→None). GET `/repos/{repo}/git/trees/{commit_sha}?recursive=1`; 404→None, other HTTPError re-raise. IF `body.truncated`: RAISE RuntimeError (>100k entries; no paginated fallback). Return `{entry.path: entry.sha for entry in body.tree if type=="blob" and path and sha}`.
- `_fetch_blob(base, repo, sha, token, timeout=30)` (`:564`): GET `/repos/{repo}/git/blobs/{sha}`; encoding=`base64`→`b64decode`; `utf-8`→`encode`; else RAISE RuntimeError("Unexpected blob encoding").

⚠️ **GOTCHA — at most 2 tree calls.** Trees+Blobs = 2 tree calls + N parallel blob fetches (~10s total for 100 artifacts; pre-2026-05-20 serial contents-API was ~17min). Trees API reads directly from the git DB (no indexing lag).

### 1.6 `_collect_artifacts` (`agent_executor.py:1121`)

```
_collect_artifacts(artifacts_dir, exclude=None) -> list[OutputFile]:
  IF not Path(artifacts_dir).exists(): RETURN []
  output_files = []
  FOR file_path IN sorted(artifacts_path.rglob("*")):       # ⚠️ SORTED — deterministic order
      IF not file_path.is_file(): CONTINUE
      rel_path = str(relative_to(artifacts_path))
      IF exclude AND rel_path in exclude: CONTINUE           # delta filter
      IF file_path.suffix.lower() in _BINARY_EXTENSIONS:     # .png/.jpg/.pdf/.zip/.woff/.so/.pyc/... (:99-105)
          content = base64(read_bytes); encoding="base64"
      ELSE:
          TRY: content = read_text(utf-8); encoding="utf-8"
          EXCEPT UnicodeDecodeError: content = base64(read_bytes); encoding="base64"
      output_files.append(OutputFile(path=rel_path, content=content, encoding=encoding))
  RETURN output_files
```

`_BINARY_EXTENSIONS` (frozenset, `:99`): `.png .jpg .jpeg .gif .bmp .ico .webp .pdf .zip .tar .gz .bz2 .xz .woff .woff2 .ttf .otf .eot .bin .exe .dll .so .dylib .pyc .pyo .class .jar`.

### 1.7 ⚠️ NEW: the workspace MemoryBackend abstraction (`memory_backend.py`)

A pluggable seam (P6-S3 / Phase 6 W3 SPIKE) under which `execute_skill`'s workspace ops run. It is **storage, not dispatch** — it sits BENEATH the `ProviderClient` layer (§6), so enabling it is identical regardless of model vendor. **The flag-off default is byte-for-byte the prior `_setup_workspace`/`_cleanup_workspace` behavior.**

```
class MemoryBackend(abc.ABC):                                # :45
  name: str = "memory-backend"
  @abstractmethod setup_workspace(*, workspace_dir, workspace_key, source_repo, task_type="") -> (workspace_path, source_dir, artifacts_dir)
  @abstractmethod cleanup_workspace(*, workspace_path, workspace_key) -> None
  # Implementations MUST be stateless per-dispatch (no per-task state on self).

class LocalWorkspaceMemoryBackend(MemoryBackend):            # :91 — DEFAULT (flag-off)
  name = "local-workspace"
  setup_workspace(...):   from src.services import agent_executor; RETURN agent_executor._setup_workspace(workspace_dir, workspace_key, source_repo, task_type)
  cleanup_workspace(...): from src.services import agent_executor; agent_executor._cleanup_workspace(workspace_path, workspace_key)
  # ⚠️ lazy import keeps the dependency direction one-way (agent_executor imports nothing from this module at runtime).

class AgentCoreMemoryBackend(MemoryBackend):                 # :137 — SPIKE, flag-gated
  name = "agentcore-memory"
  __init__(*, memory_id="", region=""): store; do NOT import boto3 here.
  _load_client(): lazy `import boto3` (ImportError → AgentCoreMemoryUnavailableError); boto3.client("bedrock-agentcore", ...)
                  → always raises AgentCoreMemoryUnavailableError today (the preview SDK isn't vendored).
  setup_workspace(...): IF not self._memory_id: RAISE AgentCoreMemoryUnavailableError("... AGENTCORE_MEMORY_ID is empty ...")
                        self._load_client()    # ALWAYS raises in the spike
                        RAISE AgentCoreMemoryUnavailableError("read-through not implemented")   # pragma: no cover
  cleanup_workspace(...): RETURN None          # clean no-op (setup never succeeds)

resolve_memory_backend(config) -> MemoryBackend:             # :249
  enabled = bool(getattr(config, "olympus_agentcore_memory_enabled", False))
  IF not enabled: RETURN LocalWorkspaceMemoryBackend()       # ⚠️ DEFAULT — byte-for-byte prior behavior
  LOG warning "AgentCore Memory backend ENABLED (spike) — feature-flagged throwaway code ..."
  RETURN AgentCoreMemoryBackend(memory_id=str(getattr(config,"agentcore_memory_id","") or ""),
                                region=str(getattr(config,"aws_region","") or ""))
```

⚠️ **GOTCHA — flag-on path fails LOUD by design.** With `OLYMPUS_AGENTCORE_MEMORY_ENABLED=true`, `setup_workspace` always raises `AgentCoreMemoryUnavailableError` (no live AgentCore endpoint, SDK not vendored). That propagates into `execute_skill` Step 1's `except Exception` → early-return #1 (`status="failed"`, "Failed to set up workspace: ..."). The spike intentionally surfaces the gap rather than silently falling back. `config` is duck-typed (no hard import on `AgentRuntimeConfig`).

⚠️ **GOTCHA — companion `gateway_router.py` (`ToolRouter`) exists but is NOT wired into the executor at HEAD.** `resolve_tool_router` / `DirectToolRouter` / `AgentCoreGatewayRouter` mirror the memory-backend discipline (flag `OLYMPUS_AGENTCORE_GATEWAY_ENABLED`, default false → `DirectToolRouter` identity pass-through). `execute_skill` does NOT call `resolve_tool_router` — the tool list is built inline (Step 6). The router is reachable code (and unit-tested) but no dispatch path consumes it yet; reproduce it as a standalone module.

---

## 2. OUTPUT VALIDATION LOOP (`output_validator.py`)

⚠️ **GOTCHA — THIS ENTIRE SECTION (§2 validation + §2.6 retry chain) IS DORMANT ON THE LIVE API-LOAD PATH.** The validation loop only does work when the loaded skill carries a non-empty `output_schemas`. On the live API-first load path (`SKILL_API_URL` set), `skill.output_schemas` is **ALWAYS `[]`** (full proof in §5.2). With an empty contract, `validate_output_files` short-circuits at `IF not schemas: RETURN output_files` (`:169-170`); the strict validator, the failure marker (§2.4), the Section-9 retry feedback (§1.2), and the whole §2.6 second-failure `RetryableError` chain **never fire** for API-loaded skills. Reachable only via the deprecated filesystem load path (§5.3 — itself non-functional per empty `skill_mapping.yaml`, §5.1) or a future API change. (The declared `output_schemas` IS still enforced LIVE on a *different* endpoint — the human-paired RETURN flow, §5.2.1 path 3.) **Reproduce §2 exactly** so a future contract-bearing load path behaves identically.

**Design invariant** (`:1-26`): strict, hard-fail, no advisory mode, no env escape hatch. A violation raises `OutputValidationError` → executor turns it into `status="failed"` + marker → Temporal retry folds violations into the next prompt. **There is no in-process retry loop** — "retry-once-with-feedback" is realized ACROSS Temporal activity attempts.

### 2.1 `OutputValidationError` (`:38-62`)

```
class OutputValidationError(RuntimeError):
  __init__(message, *, path="", schema_path="", violations=None):
      super().__init__(message); self.path=path; self.schema_path=schema_path; self.violations=list(violations or [])
  to_feedback_dict() -> {"path", "schema_path", "message"=str(self), "violations"}
```

### 2.2 Schema resolution: `_resolve_schema_root` + `load_schema`

```
_resolve_schema_root() -> Path | None:                      # (:76 region)
  override = env OLYMPUS_SCHEMA_ROOT (stripped)
  IF override: RETURN Path(override) IF is_dir ELSE None
  here = Path(__file__).resolve()
  FOR parent IN here.parents:                               # walk UP
      IF (parent/"schemas").is_dir(): RETURN parent         # repo root (schemas/ sibling)
  RETURN None

load_schema(schema_path) -> dict | None:                    # PUBLIC (also used by build_system_prompt §1.2)
  p = Path(schema_path)
  IF not p.is_absolute():
      root = _resolve_schema_root()
      IF root is None: LOG error "Schema root not resolvable ... Set OLYMPUS_SCHEMA_ROOT ..."; RETURN None
      p = root / schema_path
  IF not p.is_file(): LOG error "Schema file not found: %s"; RETURN None
  TRY: RETURN json.loads(p.read_text(utf-8))
  EXCEPT (OSError, ValueError): LOG error "Failed to load schema %s: %s"; RETURN None
```

⚠️ **GOTCHA — `OLYMPUS_SCHEMA_ROOT` points at the repo ROOT, not `schemas/`.** Relative `schema:` refs are joined onto the root; the auto-walk returns the directory CONTAINING a `schemas/` dir.

### 2.3 `validate_output_files` (`:144`) — full pseudocode

```
validate_output_files(output_files, schemas) -> list:
  IF not schemas: RETURN output_files                        # no contract → pass-through (:169-170)
  TRY: from jsonschema import Draft202012Validator
  EXCEPT ImportError: RAISE OutputValidationError("jsonschema not installed — cannot enforce output contracts")   # ⚠️ deployment bug, not graceful-skip
  by_path = { entry["path"]: entry["schema"] for entry in schemas }
  failures = []
  FOR f IN output_files:
      rel_path = getattr(f,"path","")
      schema_path = by_path.get(rel_path) OR by_path.get(PurePosixPath(rel_path).name)   # ⚠️ full repo-relative path OR bare basename
      IF not schema_path: CONTINUE                            # no wired schema → not validated here
      IF getattr(f,"encoding","utf-8") != "utf-8": CONTINUE   # base64 outputs aren't structured artifacts
      content = getattr(f,"content","")
      IF not content.strip(): failures.append(OVE("{rel}: file is empty", ..., violations=["empty file ..."])); CONTINUE
      TRY: payload = json.loads(content)
      EXCEPT ValueError as exc:                               # PROSE-IN-JSON / parse failure
          head = content.lstrip()[:120].replace("\n"," "); msg = "JSON parse failed: {exc}. First chars: {head!r}"
          failures.append(OVE("{rel}: {msg}", ..., violations=[msg])); CONTINUE
      schema = load_schema(schema_path)
      IF schema is None: failures.append(OVE("{rel}: schema {sp!r} could not be loaded", ..., violations=["schema file missing or unreadable: {sp}"])); CONTINUE
      errors = list(Draft202012Validator(schema).iter_errors(payload))
      IF not errors: CONTINUE                                 # VALID
      failures.append(OVE("{rel}: {len(errors)} schema violation(s)", ..., violations=_format_violations(errors)))   # §2.5
  IF not failures: RETURN output_files                        # ALL CLEAN
  # --- coalesce ALL failures into ONE error ---
  summary_lines=[]; all_violations=[]
  FOR fail IN failures:
      summary_lines.append("- {fail.path}:")
      FOR v IN fail.violations: summary_lines.append("    {v}"); all_violations.append("{fail.path}: {v}")
  RAISE OutputValidationError("agent output failed schema validation:\n" + "\n".join(summary_lines),
      path=";".join(f.path for f in failures), schema_path=";".join(f.schema_path for f in failures),   # ⚠️ semicolon-joined
      violations=all_violations)
```

⚠️ **GOTCHA — whole-set validation, single raise.** Every file is checked even after the first violation; failures accumulate and one coalesced error is raised AFTER the loop (so the retry marker is rich). Prose-in-`.json` fails `json.loads` → surfaces as the parse-error path. One enforcement path, not two.

### 2.4 The retry-with-feedback marker (lives in `agent_executor.py`)

`_FAILURE_MARKER_FILENAME = ".previous-validation-failure.json"` (`:119`).
- `_read_failure_marker(workspace_path)` (`:122`): `""` when path empty; open marker; on `FileNotFoundError|ValueError|OSError`→`""`; return `data["feedback"]` if non-blank str, else `""`.
- `_write_failure_marker(workspace_path, exc)` (`:142`): no-op if empty path. Builds feedback lines (`Path:`, `Schema:`, `Violations:`, then `  - {v}` each); `payload={feedback, path, schema_path, violations}`; `makedirs(workspace_path, exist_ok=True)`; `json.dump`. `OSError`→LOG warning, swallow.
- `_clear_failure_marker(workspace_path)` (`:177`): no-op if empty; `os.remove`; `FileNotFoundError`→return; other `OSError`→LOG warning.

### 2.5 `_format_violations` (`output_validator.py`)

```
_format_violations(errors) -> list[str]:
  lines=[]
  FOR err IN errors[:10]:                                   # ⚠️ CAP AT 10
      path = err.json_path OR "<root>"; lines.append("{path}: {err.message}")
  IF len(errors) > 10: lines.append("... and {len(errors)-10} more")
  RETURN lines
```

### 2.6 ⚠️ EXACTLY what happens on the SECOND failure (do NOT infer — this is the spec)

⚠️ **DORMANT ON THE LIVE API-LOAD PATH** (gated on a Step-13 validation failure, which only occurs with non-empty `output_schemas`; §5.2). Reproduce faithfully regardless. The "retry-once" semantics are realized by three layers:

1. **Attempt 1**: `execute_skill` runs against `workspace_key`. Output fails validation → `OutputValidationError`. `execute_skill` catches it, `_write_failure_marker` (marker persists — `workspace_key` set), `cleanup_workspace` (NO-OP for persistent), and RETURNS `A2ATaskResponse(status="failed", error="output validation failed: ...", output_files=...)`. **`execute_skill` does NOT raise** — it returns a failed response.
2. The **a2a router** receives the failed response, records terminal telemetry (`ERROR_CODE_EXECUTION`), returns HTTP 200 with `status="failed"`.
3. The **worker dispatch client** (`agent_client.py:_extract_result`) maps `status=="failed"` → `AgentTaskResult(status=TaskStatus.FAILED, error=...)`.
4. The **Temporal activity** `dispatch_agent_task`: `IF result.status == TaskStatus.FAILED:` → updates row + emits FAILED record → **`RAISE RetryableError(f"Agent task failed: {result.error}")`**.
5. **Temporal's `AGENT_RETRY_POLICY`**: `initial_interval=5s, backoff=2.0, max_interval=60s, maximum_attempts=3`. Reschedules **Attempt 2** (SAME `AgentTaskInput`, SAME `workspace_key`).
6. **Attempt 2**: `execute_skill` Step 4 `_read_failure_marker` finds the marker → returns feedback. Step 5 folds it into **Section 9**. The agent gets ONE corrective pass. On a clean Attempt 2: Step 14 `_clear_failure_marker`.
7. **SECOND failure**: returns `status="failed"` again, writes marker again, activity RAISES `RetryableError` again → Attempt 3 (still within `maximum_attempts=3`). On the THIRD failure, `maximum_attempts=3` is exhausted → Temporal surfaces the activity failure to the workflow. ⚠️ **GOTCHA**: the "exactly one feedback retry" language in the code comments (`:370-372`) describes the *intended author-facing* model; the *actual* policy allows up to 3 total attempts. No separate hard "give up after 2" branch — exhaustion is purely the retry-policy cap.

⚠️ **GOTCHA — ephemeral workspaces get NO retry feedback.** If `workspace_key == ""`, `cleanup_workspace` rmtrees the tempdir on the failure path, destroying the marker before any retry. Marker-driven self-correction ONLY works when the dispatch carries a `workspace_key`.

⚠️ **GOTCHA — timeout (#6) is NOT a validation failure and writes NO marker.** A `status="timeout"` return (Step 11 except-clause) skips `_write_failure_marker` entirely. The activity still maps a FAILED/timeout result to a `RetryableError` (so Temporal retries), but the next attempt gets NO Section-9 feedback from a timeout — there were no violations to record.

---

## 3. MODEL SELECTION (`model_selector.py`) — CHANGED (now returns `ModelSelection`; ARNs; FedRAMP/hosting)

### 3.1 `ModelSelection` dataclass (`:19-31`) — NEW

```
@dataclass(frozen=True) ModelSelection:
  model_id: str          # what is SENT to the provider — either {prefix}.{base} OR an inference-profile ARN
  canonical_model: str   # stable, prefix-free name (e.g. "claude-sonnet-4-6") for telemetry roll-ups
```

### 3.2 `ModelSelector.__init__` + `select` (`:49`, `:81`) — CHANGED

```
ModelSelector(config_dir, provider="bedrock", prefix="us", inference_profile_arns=None):   # :49
  self._provider=provider; self._prefix=prefix; self._arns = inference_profile_arns or {}
  self._models={}; self._fallback={}; self._aliases={}
  self._fedramp_compliant=False        # set by _load_config; default False (fail closed)  (:65)
  self._hosting_provider=""             # set by _load_config; drives the prefix logic       (:68)
  self._load_config(config_dir)
  # NOTE: there is dead code after `return self._fedramp_compliant` (:72-79): the
  # _availability_cache/_cache_ttl assignments are UNREACHABLE (placed after the property
  # return). check_availability still works by lazily reading .get on a missing attr? No —
  # those attrs are set inside check_availability's own try via the cache dict default. See §3.6.

select(preference, default_tier="tier-2") -> ModelSelection:        # :81 — RETURN TYPE CHANGED
  tier = _resolve_tier(preference, default_tier)                    # §3.3
  chain = self._fallback.get(tier, [tier])                          # fallback list, or [tier] if none
  FOR candidate_tier IN chain:
      base = self._models.get(candidate_tier, "")
      IF base: RETURN self._build_selection(base)                   # first non-empty wins
  # LAST RESORT:
  base = self._models.get(tier, "") OR self._models.get("tier-2", "")
  IF base: RETURN self._build_selection(base)
  RETURN ModelSelection(model_id="", canonical_model="unknown-agent")
```

⚠️ **GOTCHA — `select()` does NOT call `check_availability`.** The live `select()` path walks the fallback chain purely by config presence (non-empty `_get_model_id`). `check_availability` (boto3 `list_foundation_models`, `True` on any exception — `:184-208`) exists but is NOT invoked by `select`. Reproduce `select` exactly: no availability gating.

### 3.3 `_build_selection` (`:108`) + `_resolve_tier` (`:129`) — `_build_selection` is NEW

```
_build_selection(base) -> ModelSelection:                           # :108 — NEW
  canonical = derive_agent_id(base)                                 # e.g. "claude-sonnet-4-6"
  arn = self._arns.get(canonical)
  IF arn: RETURN ModelSelection(model_id=arn, canonical_model=canonical)   # ⚠️ ARN sent to Bedrock for cost attribution
  IF self._hosting_provider == "bedrock" OR self._provider == "bedrock":
      RETURN ModelSelection(model_id="{self._prefix}.{base}", canonical_model=canonical)   # bedrock-hosted: {prefix}.{base}
  RETURN ModelSelection(model_id=base, canonical_model=canonical)   # direct-vendor SDKs (anthropic-api/openai/gemini): bare base

_resolve_tier(preference, default_tier) -> str:                     # :129
  IF not preference: RETURN default_tier
  IF preference in {"tier-1","tier-2","tier-3"}: RETURN preference  # _TIER_PATTERN (:16)
  alias_tier = self._aliases.get(preference)                        # e.g. "claude-sonnet-4-6" → "tier-2"
  IF alias_tier: RETURN alias_tier
  LOG debug "Unknown model preference '%s', using default tier"; RETURN default_tier   # unknown → default (NOT an error)
```

### 3.4 `_load_config` (`:143`) — CHANGED (`bedrock`↔`bedrock-claude` shim; fedramp; hosting_provider)

```
_load_config(config_dir):
  path = config_dir/models.yaml; missing → LOG warning, RETURN (empty config)
  data = yaml.safe_load(path)
  providers = data.get("providers", {})
  # --- back-compat shim (one release): bedrock ↔ bedrock-claude (:158-168) ---
  provider_key = self._provider
  IF provider_key not in providers:
      shim = {"bedrock":"bedrock-claude", "bedrock-claude":"bedrock"}
      alias = shim.get(provider_key)
      IF alias and alias in providers:
          IF provider_key == "bedrock": LOG warning "DEPRECATION: provider 'bedrock' is now 'bedrock-claude'; ..."
          provider_key = alias
  provider_cfg = providers.get(provider_key, {})
  self._models   = provider_cfg.get("models", {})
  self._fallback = provider_cfg.get("fallback_order", {})
  self._aliases  = data.get("aliases", {})                          # top-level
  self._fedramp_compliant = bool(provider_cfg.get("fedramp_compliant", False))
  self._hosting_provider  = provider_cfg.get("hosting_provider",
                              "bedrock" if provider_key in ("bedrock","bedrock-claude") else "")   # legacy key → bedrock-hosted
```

### 3.5 Driving config — `config/models.yaml` (REWRITTEN, multi-provider)

The catalog now carries, per provider entry: `hosting_provider`, `sdk`, `fedramp_compliant`, `models` (tier→base id), `fallback_order` (tier→list), `rates` (model→`{input_per_1m, output_per_1m}`), plus a top-level `provider_fallback_order` list and `aliases`. ⚠️ **Reproduce verbatim, including the `[1m]` suffixes and the `fedramp_compliant` flags** (FedRAMP enforcement depends on them).

```yaml
providers:
  bedrock-claude:                    # composite id == {sdk}-on-{hosting}
    hosting_provider: bedrock
    sdk: anthropic                   # Claude Agent SDK today
    fedramp_compliant: true          # Bedrock is FedRAMP High (GovCloud) — the default FAA path
    models:
      tier-1: "anthropic.claude-opus-4-8[1m]"        # ⚠️ CHANGED: opus-4-8 (was opus-4-7)
      tier-2: "anthropic.claude-sonnet-4-6[1m]"
      tier-3: "anthropic.claude-haiku-4-5-20251001-v1:0"
    fallback_order: { tier-1: [tier-1,tier-2], tier-2: [tier-2,tier-3,tier-1], tier-3: [tier-3,tier-2] }
    rates:
      anthropic.claude-opus-4-8:   { input_per_1m: 15.00, output_per_1m: 75.00 }
      anthropic.claude-sonnet-4-6: { input_per_1m: 3.00,  output_per_1m: 15.00 }
      anthropic.claude-haiku-4-5-20251001: { input_per_1m: 1.00, output_per_1m: 5.00 }
  anthropic:                         # Direct Anthropic API (non-Bedrock) — Olympus Lite + tests
    hosting_provider: anthropic-api
    sdk: anthropic
    fedramp_compliant: false         # raw Anthropic API is NOT FedRAMP — never an FAA path
    models: { tier-1: "claude-opus-4-8", tier-2: "claude-sonnet-4-6", tier-3: "claude-haiku-4-5-20251001" }
    fallback_order: { tier-1: [tier-1,tier-2], tier-2: [tier-2,tier-3,tier-1], tier-3: [tier-3,tier-2] }
    rates: { claude-opus-4-8: {15.00,75.00}, claude-sonnet-4-6: {3.00,15.00}, claude-haiku-4-5-20251001: {1.00,5.00} }
  openai:                            # LIVE second provider
    hosting_provider: openai-api
    sdk: openai
    fedramp_compliant: false         # blocked under FAA require_fedramp_provider
    models: { tier-1: "o3", tier-2: "gpt-4.1", tier-3: "gpt-4.1-mini" }
    fallback_order: { tier-1: [tier-1,tier-2], tier-2: [tier-2,tier-3], tier-3: [tier-3,tier-2] }
    rates: { o3: {10.00,40.00}, gpt-4.1: {2.00,8.00}, gpt-4.1-mini: {0.40,1.60} }
  gemini-vertex:                     # SCAFFOLD
    hosting_provider: gcp-vertex; sdk: gemini; fedramp_compliant: false   # NOT verified — fail closed
    models: { tier-1: "gemini-2.5-pro", tier-2: "gemini-2.5-flash", tier-3: "gemini-2.5-flash-lite" }
    fallback_order: {...}; rates: { gemini-2.5-pro: {1.25,10.00}, gemini-2.5-flash: {0.30,2.50} }
  bedrock-nova:                      # SCAFFOLD
    hosting_provider: bedrock; sdk: bedrock-converse; fedramp_compliant: true   # inherits Bedrock compliance
    models: { tier-1: "amazon.nova-pro-v1:0", tier-2: "amazon.nova-lite-v1:0", tier-3: "amazon.nova-micro-v1:0" }
  bedrock-mistral:                   # SCAFFOLD
    hosting_provider: bedrock; sdk: bedrock-converse; fedramp_compliant: true
    models: { tier-2: "mistral.mistral-large-2402-v1:0", tier-3: "mistral.mistral-7b-instruct-v0:2" }
  bedrock-llama:                     # SCAFFOLD
    hosting_provider: bedrock; sdk: bedrock-converse; fedramp_compliant: true
    models: { tier-1: "meta.llama3-70b-instruct-v1:0", tier-2: "meta.llama3-8b-instruct-v1:0" }

# Cross-provider fallback chain (§4.4). Scaffolds excluded by convention.
provider_fallback_order:
  - bedrock-claude
  - anthropic
  - openai

aliases:                             # model-name → tier (reverse lookup)
  claude-opus-4: tier-1; claude-opus-4-6: tier-1; claude-opus-4-7: tier-1; claude-opus-4-8: tier-1
  claude-sonnet-4: tier-2; claude-sonnet-4-6: tier-2
  claude-haiku-3.5: tier-3; claude-haiku-4-5: tier-3
  gpt-4: tier-2; gpt-4-turbo: tier-2; gpt-4.1: tier-2; o3: tier-1; o4-mini: tier-3
```

⚠️ **GOTCHA — the `us.` prefix is applied at runtime** (bedrock-hosted only). Stored base ids have NO region prefix; `_build_selection` prepends `{prefix}.` → `us.anthropic.claude-sonnet-4-6[1m]`. The `[1m]` suffix (1M-context variant) is preserved verbatim. Direct-vendor providers (anthropic-api/openai/gemini) send the bare base id.

⚠️ **GOTCHA — CHANGED: tier-1 is now opus-4-8.** Both `bedrock-claude` and `anthropic` tier-1 pin `claude-opus-4-8` (was `opus-4-7`). `derive_agent_id` and the aliases list both recognize `opus-4-8` (and `opus-4-5`/`sonnet-4-5` — see §4.8).

### 3.6 `check_availability` (`:184`) — present, unused-by-select

`check_availability(model_id)`: 5-min cache (`_availability_cache` dict keyed `model_id → (available, ts)`); on miss, lazy `import boto3`, `bedrock.list_foundation_models()`, membership test; **`except Exception: RETURN True`** ("if we can't check, assume available"). Not called by `select`.

### 3.7 SKILL.md `agent:` hint → tier (`skill_loader.py:22-29`, `:103-104`)

```
_AGENT_TIER_MAP = { "opus":"tier-1", "sonnet":"tier-2", "haiku":"tier-3",
                    "tier-1":"tier-1", "tier-2":"tier-2", "tier-3":"tier-3" }
model_tier = _AGENT_TIER_MAP.get(str(frontmatter.get("agent","sonnet")).lower(), "tier-2")
```
`skill.model_tier` is one of several tier hints the selection resolver uses (§4.3).

---

## 4. PROVIDER+TIER RESOLUTION, A2A ENDPOINT, LIVE vs MOCK, TELEMETRY

### 4.1 `AGENT_RUNTIME_MODE` resolution + production refusal (`olympus-worker/src/config.py`)

```
AGENT_RUNTIME_MODE_LIVE="live"; AGENT_RUNTIME_MODE_MOCK="mock"; _VALID={"live","mock"}; _NON_TEST_ENVS={"production","prod","staging","stage"}
WorkerConfig.agent_runtime_mode: str = "live"   # default
WorkerConfig.app_env: str = "development"

validate_agent_runtime_mode():                   # called ONCE at worker startup (worker.py)
  mode = (agent_runtime_mode or "").strip().lower()
  IF mode not in {"live","mock"}: RAISE InvalidAgentRuntimeModeError("AGENT_RUNTIME_MODE={!r} is invalid. Expected ['live','mock'].")
  env = (app_env or "").strip().lower()
  IF mode=="mock" AND env in _NON_TEST_ENVS:
      RAISE MockInProductionError("Refusing to start: AGENT_RUNTIME_MODE=mock is forbidden when APP_ENV={!r}. ... see DECISION-018.")
```

⚠️ **GOTCHA — why production refuses mock.** DECISION-018: the mock returns canned fixtures, never an LLM. The gate is a LOUD, FATAL raise at worker startup, before connecting to Temporal — `run_worker` does NOT catch it. Both error classes are `RuntimeError` subclasses.

### 4.2 Live dispatch (worker → runtime over HTTP): `dispatch_via_a2a` (`agent_client.py`)

```
dispatch_via_a2a(agent_url, task_input: AgentTaskInput, model_used="") -> AgentTaskResult:
  task_id = uuid4()
  task_message = _build_task_message(task_input)
      # = "Execute skill '{skill_id}' for application '{app_id}'. Task type: {task_type}."
      #   + " Context: k=v, k=v." (sorted context items)  IF task_input.context
  context = _build_context(task_input)
  payload = { "task": task_message, "context": context, "model_preference": task_input.model_preference or "" }
      # ⚠️ GOTCHA: leave model_preference BLANK when caller hasn't set one — the runtime's
      #   resolver reads the skill's declared tier and uses THAT. Sending "tier-2" here clobbers
      #   the resolution and forces every Opus-declared skill down to Sonnet.
  response = await _post_with_saturation_retry(agent_url, payload, task_input.timeout_seconds, task_id)   # §4.5
  result = _extract_result(response, task_id, "", start_time_ms)    # model_used comes FROM response
  RETURN result
```

`_build_context`: `{app_id, skill_id, task_type, input_artifacts, optional_input_artifacts, model_preference}`; conditionally add `source_repo, artifact_repo, artifact_ref, workspace_key`; if `task_input.context` non-empty add `extras = dict(task_input.context)`.

`_extract_result`: reads `output_artifacts`, `output_files` (path+content→`OutputFile`), `token_usage.{input,output}`, `cost_estimate_usd`, `model_used` (overrides), `status=="failed"`→`TaskStatus.FAILED` + `error`. Default status `COMPLETED`.

### 4.3 ⚠️ NEW: provider+tier resolution — `resolve_provider_and_tier` (`provider_selection.py:48`)

Resolves the dispatch `(provider_name, tier)` BEFORE `get_provider()` / model selection, via a 5-layer precedence, and enforces `require_fedramp_provider` **fail-closed**.

```
resolve_provider_and_tier(skill, profile_cfg, runtime_inference_provider, runtime_default_tier, request, *, config_dir="", skill_id="") -> (provider, tier):
  overrides = profile_cfg.get("skill_provider_overrides", {}) or {}
  resolved_skill_id = skill_id or (skill.name if skill else "")

  # PROVIDER precedence (highest → lowest):
  provider = (skill.provider if skill else "")          # 1. skill config.json/frontmatter
             or overrides.get(resolved_skill_id)        # 2. profile skill_provider_overrides[skill_id]
             or profile_cfg.get("default_provider")     # 3. profile default_provider
             or runtime_inference_provider              # 4. AgentRuntimeConfig.inference_provider
             or _DEFAULT_PROVIDER                        # 5. hard default "bedrock-claude"
  IF provider == "bedrock":                              # legacy env value → composite id
      LOG warning "DEPRECATION: provider 'bedrock' resolved to 'bedrock-claude'; ..."
      provider = "bedrock-claude"

  # TIER precedence:
  tier = request.model_preference                        # explicit request preference
         or (skill.config_model_tier if skill else "")   # config.json model_tier override
         or (skill.model_tier if skill else "")          # SKILL.md agent alias
         or profile_cfg.get("default_tier")              # profile default_tier
         or runtime_default_tier                         # runtime default
         or _DEFAULT_TIER                                 # hard default "tier-2"

  # --- FedRAMP enforcement (FAIL CLOSED) ---
  IF profile_cfg.get("require_fedramp_provider", False):
      IF not provider_is_fedramp_compliant(provider, config_dir):
          RAISE FedRampComplianceError("Skill '{id}' resolved to provider '{provider}', whose hosting provider is not "
                "fedramp_compliant. The active profile sets require_fedramp_provider: true. Dispatch rejected before "
                "execution. Route this skill to a FedRAMP-compliant provider (e.g. bedrock-claude) or remove the flag.")
  RETURN provider, tier
```

`provider_is_fedramp_compliant(provider, config_dir)` (`:35`): prefer the live `ProviderCapabilities` (`provider_factory.get_capabilities(provider)` → `caps.fedramp_compliant`); else fall back to `model_rates.provider_is_fedramp_compliant(config_dir, provider)` (reads `models.yaml`). ⚠️ **Unknown provider → False (fail closed).**

`profile_cfg` comes from `load_agent_dispatch_config()` (`profile_context.py:179`): reads the `agent_dispatch:` block (top-level or nested under `profile:`) from `OLYMPUS_PROFILE_ROOT/profile.yaml`; `{}` when no profile / no block.

### 4.4 The a2a router `POST /a2a/tasks` (`a2a.py:67`) — saturation gate + REWRITTEN pipeline

```
Module globals: _task_semaphore=None, _max_concurrent=0, _max_queued_waiters=2, _queued_waiters=0, _RETRY_AFTER_SECONDS="5".
init_semaphore(sem, max_concurrent, max_queued_waiters) called at startup (main.py:45).

execute_task(request, response, config):                    # (:67)
  start_ms = now_ms
  LOG info "Received A2A task" {skill_id, app_id, task_type, model_preference}
  semaphore = _task_semaphore OR Semaphore(config.max_concurrent_tasks)
  max_queued = _max_queued_waiters IF _task_semaphore is not None ELSE config.max_queued_waiters

  # --- SATURATION FAIL-FAST (:109-133) ---
  IF max_queued >= 0 AND semaphore.locked() AND _queued_waiters >= max_queued:
      LOG warning "A2A replica saturated — returning 503"
      response.status_code = 503; response.headers["Retry-After"] = "5"
      RETURN A2ATaskResponse(status="failed", model_used="", duration_ms=now-start_ms,
                             error="agent runtime saturated — retry against a different replica (Retry-After set)")
      # semaphore.locked() is True only when value==0 (all slots in use).

  _queued_waiters += 1; acquired = False
  TRY:
      await semaphore.acquire(); acquired = True; _queued_waiters -= 1
      RETURN await _execute(request, config, start_ms)
  FINALLY:
      IF acquired: semaphore.release()
      ELSE IF _queued_waiters > 0: _queued_waiters -= 1      # never transitioned queued→active; fix gauge
```

`_execute` (`:238`) — Phases B/C/D, now provider-aware:

```
_execute(request, config, start_ms):
  # Phase B — load skill (:244-259)
  config_dir = <agent-runtime>/config   # parents[2]/config relative to a2a.py
  skill = None
  TRY:
      skill = resolve_and_load_skill(request.context.skill_id, config.skills_dir, config_dir, api_url=config.skill_api_url)
      LOG info "Skill loaded" {skill, tier}
  EXCEPT (KeyError, FileNotFoundError) as exc: LOG warning "Skill loading failed: %s"   # skill stays None

  # Phase C — RESOLVE PROVIDER+TIER (fail-closed), then select model (:268-325) — NEW
  profile_cfg = load_agent_dispatch_config()
  TRY:
      resolved_provider, preference = resolve_provider_and_tier(skill, profile_cfg,
            config.inference_provider, config.default_model_tier, request,
            config_dir=config_dir, skill_id=request.context.skill_id)               # §4.3
  EXCEPT FedRampComplianceError as exc:                      # ⚠️ FedRAMP rejection
      duration_ms = now-start_ms; LOG error "FedRAMP enforcement rejected dispatch: %s"
      task_id_fr = new_task_id()
      record_task_start(task_id_fr, agent_id="fedramp-rejected", skill_id=.., task_type=.., application_id=..)
      record_task_complete(task_id_fr, status="failed", duration_ms=.., error_code=ERROR_CODE_FEDRAMP)
      RETURN A2ATaskResponse(status="failed", model_used="", duration_ms=.., error=str(exc))   # early return

  selector = ModelSelector(config_dir, provider=resolved_provider, prefix=config.bedrock_model_prefix,
                           inference_profile_arns=config.bedrock_inference_profile_arns)
  selection = selector.select(preference, default_tier=config.default_model_tier)   # → ModelSelection
  model_id = selection.model_id; canonical_model = selection.canonical_model        # model_id may be an ARN
  LOG info "Provider + model selected" {provider, model_id, canonical_model, preference}

  # Phase D — telemetry start + dispatch (with ONE fallback hop) (:328-503)
  duration_ms = now-start_ms
  task_id = new_task_id(); agent_id = derive_agent_id(canonical_model)
  record_task_start(task_id, agent_id, skill_id=.., task_type=.., application_id=..,
        model_requested=preference or None, model_used=canonical_model,
        agent_backend=config.inference_provider, provider_name=resolved_provider)   # NEW: provider_name

  IF not skill:
      record_task_complete(task_id, status="failed", duration_ms=.., error_code=ERROR_CODE_EXECUTION, model_used=canonical_model)
      RETURN A2ATaskResponse(status="failed", model_used=canonical_model, duration_ms=.., error="Skill '{id}' could not be loaded")

  mission_context = load_mission_context()                   # cached; None unless OLYMPUS_PROFILE_ROOT set

  fallback_from = None
  TRY:
      result = await _dispatch(provider_name=resolved_provider, skill=skill, request=request,
                               config=config, config_dir=config_dir, model_id=model_id, mission_context=mission_context)   # §4.4a
  EXCEPT _ProviderUnavailable as exc:                        # creds/SDK/scaffold — try ONE fallback hop
      fallback = select_fallback_provider(resolved_provider, profile_cfg, config_dir)   # §4.4b
      IF fallback is None:
          duration_ms = now-start_ms; LOG error "Provider unavailable, no fallback: %s"
          record_task_complete(task_id, status="failed", duration_ms=.., error_code=ERROR_CODE_SDK_UNAVAILABLE, model_used=canonical_model)
          RETURN A2ATaskResponse(status="failed", model_used=canonical_model, duration_ms=.., error=str(exc))
      LOG warning "Provider fallback" {skill_id, original_provider, fallback_provider, reason}
      fallback_from = resolved_provider
      fb_selector = ModelSelector(config_dir, provider=fallback, prefix=.., inference_profile_arns=..)
      fb_selection = fb_selector.select(preference, default_tier=config.default_model_tier)
      canonical_model = fb_selection.canonical_model
      record_task_start(new_task_id(), agent_id=derive_agent_id(canonical_model), skill_id=.., task_type=.., application_id=..,
            model_requested=preference or None, model_used=canonical_model, agent_backend=config.inference_provider,
            provider_name=fallback, provider_fallback_from=fallback_from)            # NEW: provenance
      TRY:
          result = await _dispatch(provider_name=fallback, skill=skill, request=request, config=config,
                                   config_dir=config_dir, model_id=fb_selection.model_id, mission_context=mission_context)
          resolved_provider = fallback
      EXCEPT _ProviderUnavailable as exc2:                   # ⚠️ AT MOST ONE HOP — do not cascade
          duration_ms = now-start_ms; LOG error "Fallback provider also unavailable: %s"
          record_task_complete(task_id, status="failed", duration_ms=.., error_code=ERROR_CODE_SDK_UNAVAILABLE, model_used=canonical_model)
          RETURN A2ATaskResponse(status="failed", model_used=canonical_model, duration_ms=.., error=str(exc2))

  # map executor status → terminal enum (:469-498)
  term_status = "completed" IF result.status=="completed" ELSE "timed_out" IF result.status=="timeout" ELSE "failed"
  error_code = ERROR_CODE_EXECUTION IF (term_status=="failed" AND result.error) ELSE ERROR_CODE_TIMEOUT IF term_status=="timed_out" ELSE None
  record_task_complete(task_id, status=term_status, duration_ms=result.duration_ms,
        input_tokens=result.token_usage.input or None, output_tokens=result.token_usage.output or None,
        cost_estimate=result.cost_estimate_usd or None, model_used=canonical_model,   # ⚠️ canonical, NOT the ARN result.model_used echoes
        error_code=error_code, llm_ms=.., tool_ms=.., tool_call_count=..)
  result.model_used = canonical_model                        # report canonical name (not ARN) to caller
  RETURN result
```

#### 4.4a `_dispatch` (`a2a.py:163`) — provider routing — NEW

```
_dispatch(*, provider_name, skill, request, config, config_dir, model_id, mission_context) -> A2ATaskResponse:
  IF provider_name in ("bedrock-claude", "bedrock"):
      TRY:
          RETURN await execute_skill(skill=skill, task_message=request.task, model_id=model_id,
                app_id=.., source_repo=.., workspace_key=.., workspace_dir=config.workspace_dir,
                permission_mode=config.permission_mode, task_type=.., input_artifacts=list(..),
                optional_input_artifacts=list(..), artifact_repo=.., artifact_ref=.., mission_context=mission_context,
                timeout_seconds=config.skill_timeout_seconds, max_turns=config.skill_max_turns,    # NEW bounds threaded in
                max_budget_usd=config.skill_max_budget_usd)
      EXCEPT RuntimeError as exc:
          RAISE _ProviderUnavailable(str(exc)) from exc      # SDK-not-installed = availability failure → fallback signal
  # Non-Claude providers go through the factory abstraction:
  TRY:
      provider = provider_factory.get_provider(provider_name, config_dir=config_dir,
            prefix=config.bedrock_model_prefix, inference_profile_arns=config.bedrock_inference_profile_arns)
  EXCEPT (ValueError, RuntimeError) as exc: RAISE _ProviderUnavailable(str(exc)) from exc   # unknown / scaffold / unavailable
  RETURN await provider.execute(skill=skill, task_message=request.task, model_id=model_id, system_prompt="",
        tools=skill.allowed_tools, app_id=.., source_repo=.., workspace_key=.., workspace_dir=config.workspace_dir,
        workspace_path="", artifacts_dir="", cwd="", permission_mode=config.permission_mode,
        task_type=request.context.task_type, mission_context=mission_context)
```

⚠️ **GOTCHA — the `bedrock-claude` path calls `execute_skill` DIRECTLY (not through the `BedrockClaudeProvider` class).** This is deliberate so the Claude dispatch behavior — and every existing test that patches `a2a.execute_skill` — is unchanged. The `BedrockClaudeProvider` ProviderClient (§6.3a) is a thin wrapper around the same `execute_skill`; it exists for capability declaration + factory uniformity, but the live a2a path short-circuits to `execute_skill` for `bedrock`/`bedrock-claude`.

⚠️ **GOTCHA — `_ProviderUnavailable` vs an execution failure.** `_ProviderUnavailable` (creds missing / SDK absent / scaffold / unknown name) triggers the ONE fallback hop. A provider that *ran* but returned `status="failed"` does NOT — that result is returned as-is. `execute_skill`'s Step-0 SDK-unavailable `RuntimeError` is mapped to `_ProviderUnavailable` (availability, not execution).

#### 4.4b `select_fallback_provider` (`provider_selection.py:120`) — NEW

```
select_fallback_provider(original_provider, profile_cfg, config_dir) -> str | None:
  chain = model_rates.provider_fallback_order(config_dir)    # ["bedrock-claude","anthropic","openai"]
  require_fedramp = bool(profile_cfg.get("require_fedramp_provider", False))
  start = chain.index(original_provider)+1 IF original_provider in chain ELSE 0   # scan AFTER original's position
  FOR candidate IN chain[start:]:
      IF candidate == original_provider: CONTINUE
      caps = provider_factory.get_capabilities(candidate)
      IF caps is None OR not caps.live: CONTINUE             # ⚠️ scaffold/unregistered never a fallback target
      IF require_fedramp AND not provider_is_fedramp_compliant(candidate, config_dir): CONTINUE   # filtered, not silently used
      RETURN candidate
  RETURN None
```

⚠️ **GOTCHA — at most ONE fallback hop per dispatch; scaffolds and (under FedRAMP) non-compliant providers are filtered out, never silently used.** If no candidate qualifies, the dispatch fails with `ERROR_CODE_SDK_UNAVAILABLE`.

### 4.5 `_post_with_saturation_retry` (worker side, `agent_client.py`)

```
_RETRY_ON_503_MAX_ATTEMPTS=5; _BASE_DELAY_S=1.0; _BACKOFF=2.0; _MAX_DELAY_S=30.0
_post_with_saturation_retry(agent_url, payload, timeout, task_id) -> object:
  last_resp = None
  FOR attempt IN 1..5:
      WITH AsyncClient(timeout=timeout): resp = await POST "{agent_url}/a2a/tasks" json=payload
      last_resp = resp
      IF resp.status_code != 503: resp.raise_for_status(); RETURN resp.json()   # 2xx done; other 4xx/5xx → raise
      IF attempt >= 5: BREAK
      retry_after_s = float(resp.headers.get("Retry-After","")) or 0.0          # ValueError→0.0
      backoff_s = min(1.0 * 2.0**(attempt-1), 30.0)
      delay = max(retry_after_s, backoff_s) + random.uniform(0, 0.5)            # jitter
      LOG warning "Agent returned 503 (saturated) — retrying" {attempt, delay_s, retry_after_header}
      await asyncio.sleep(delay)
  assert last_resp is not None; last_resp.raise_for_status(); RETURN last_resp.json()
```

⚠️ **GOTCHA — two retry layers.** (1) An HAProxy `olympus-agent` LB in front of the pool uses `option redispatch` + `retry-on 503`. (2) This worker-side loop retries 5× with exp-backoff + jitter to absorb pool-wide saturation before bubbling to Temporal. Other HTTP errors bubble immediately via `raise_for_status` for `AGENT_RETRY_POLICY` (3 attempts).

### 4.6 The Temporal dispatch activity `dispatch_agent_task` (`agent_dispatch.py`)

```
AGENT_RETRY_POLICY = RetryPolicy(initial_interval=5s, backoff=2.0, max_interval=60s, maximum_attempts=3)

dispatch_agent_task(input: AgentTaskInput):                 # @foundry_activity
  spawn _heartbeat_loop (every 30s, best-effort); finally cancel it
  RETURN await _dispatch_agent_task_inner(input)

_dispatch_agent_task_inner(input):
  dispatched_at = now_utc
  task_row_id = await _insert_agent_task_row(input, dispatched_at)       # best-effort; exactly-one app_id XOR wave_id
  exec_id = await _emit_agent_start(input.execution_context, input, task_row_id)
  agent_card = olympus_agent_registry.find_agent_for_skill(input.skill_id)

  IF agent_card is not None:                                 # PRIMARY: A2A
      TRY:
          IF env AGENT_RUNTIME_MODE (default "live").strip().lower() == "mock":
              from src.testing.mock_agent_runtime import dispatch_via_mock; dispatcher = dispatch_via_mock
          ELSE:
              TRY: from olympus_api.src.services.agent_client import dispatch_via_a2a as dispatcher
              EXCEPT ImportError: from src.agent_client import dispatch_via_a2a as dispatcher
          result = await dispatcher(agent_url=agent_card.url, task_input=input)
          IF result.status == TaskStatus.FAILED:
              update agent_task row (error); emit FAILED execution record
              RAISE RetryableError("Agent task failed: {result.error or 'unknown error'}")   # → retry (§2.6)
          update agent_task row; emit COMPLETED record (output_artifacts = StepArtifactRef per output_file)
          RETURN result
      EXCEPT ImportError: LOG warning; fall through to subprocess
      EXCEPT RetryableError: RAISE
      EXCEPT Exception as e:
          mark agent_task + execution FAILED
          IF _is_retryable(str(e)): RAISE RetryableError(...)
          ELSE: RAISE NonRetryableError(...)

  # FALLBACK: CLI subprocess (deprecated)
  fallback_module = "agents.{skill_id.lower().replace('-','_')}"
  result = await dispatch_via_subprocess(module_name=fallback_module, task_input=input)
  ... same FAILED→RetryableError handling ...
```

`_is_retryable(msg)`: NOT retryable if lowercased msg contains any of `["not found","invalid input","bad request","unauthorized","forbidden","capability"]`; retryable otherwise.

`_pick_output_ref(result)`: prefer `output_files[0].path`; else `output_artifacts[0]` only if short single-line path-ish (`"\n" not in` and `len<=512`); else None — ⚠️ never store the prose summary as an artifact ref.

⚠️ **GOTCHA — `status="timeout"` is NOT `TaskStatus.FAILED` at the worker boundary.** `_extract_result` only maps `status=="failed"` → `TaskStatus.FAILED`. A runtime `status="timeout"` response (executor early-return #6) is therefore NOT one of the two recognized states; the worker treats the non-`failed`, non-`completed` status as `COMPLETED` by default. In practice the timeout path is more often triggered by the worker's own HTTP read-timeout (an exception → `_is_retryable` → `RetryableError`), but a fast structured `"timeout"` body short-circuits the long wait. Reproduce the executor's `"timeout"` status verbatim; the a2a router (§4.4) maps it to `"timed_out"` + `ERROR_CODE_TIMEOUT` for telemetry regardless of how the worker classifies it.

### 4.7 Mock runtime `dispatch_via_mock` + fixtures (`mock_agent_runtime.py`)

Drop-in for `dispatch_via_a2a`: `dispatch_via_mock(agent_url, task_input, model_used="")` — `agent_url`/`model_used` accepted but unused.

```
dispatch_via_mock(agent_url, task_input, model_used=""):
  scenario = str(task_input.context.get("fixture_scenario")) IF set ELSE None
  start = time.time(); fixture = load_fixture(task_input.skill_id, scenario)
  result = fixture.result
  IF result.duration_ms == 0: result = copy with duration_ms = max(int((now-start)*1000), 1)
  RETURN result
```

Fixture path: `<skills_root>/<skill_id>/fixtures/<scenario>.json`. `skills_root` = env `OLYMPUS_SKILLS_ROOT` else walk-up to `cross-cutting/skills`.

`load_fixture(skill_id, scenario=None)` resolution: dir/`*.json` missing → `FixtureNotFoundError`; `scenario None` + >1 fixture → `FixtureResolutionError`; `scenario` given but missing → `FixtureResolutionError`; `_validate_shape` (require `skill_id, scenario, result`; `result` dict; `status∈{completed,failed}`; `failed`⇒non-empty `error`; `output_artifacts` list; `output_files` list of dicts with `path`+`content`); `skill_id` mismatch → `FixtureSchemaError`; `_materialize` → `AgentTaskResult(...)`.

⚠️ **GOTCHA — fixtures validated at test-collection time.** `validate_all_fixtures` loads + materializes every fixture; a shape that doesn't match `AgentTaskResult` fails CI (DECISION-018).

### 4.8 Telemetry / task recording (`task_recorder.py`) — CHANGED (provider fields, FedRAMP code)

- **Enabled** only when env `OLYMPUS_API_URL` is set (`_enabled`). Else every record fn returns immediately.
- **Headers**: `Content-Type: application/json`; `Authorization: Bearer {OLYMPUS_API_TOKEN}` if set.
- `new_task_id()`: `str(uuid4())` — one UUID per task shared by start + complete (server dedupes on `task_id`).
- `derive_agent_id(model_id)` (`:88`): match substrings — **`opus-4-8`→`claude-opus-4-8`** (NEW), `opus-4-7`, `opus-4-6`, **`opus-4-5`** (NEW), `sonnet-4-6`, **`sonnet-4-5`** (NEW), `haiku-4-5`, `haiku-4-4`; else strip prefixes `us.anthropic.`/`global.anthropic.`/`eu.anthropic.`/`anthropic.`; else raw id; empty→`"unknown-agent"`.
- `record_task_start(...)` (`:112`): `POST {OLYMPUS_API_URL}/api/v1/agents/tasks` body `{task_id, agent_id, skill_id, task_type, started_at}` + optional `application_id, workflow_id, model_requested, model_used, agent_backend`, **NEW `provider_name`, `provider_fallback_from`**. `timeout=2.0`. ⚠️ **Fire-and-forget**.
- `record_task_complete(...)` (`:172`): `POST {base}/api/v1/agents/tasks/{task_id}/complete` body `{status, completed_at}` + optional `duration_ms, input_tokens, output_tokens, cache_read_tokens, cache_write_tokens, cost_estimate, model_used, quality_score, error_code, artifact_id`. ⚠️ Timing fields (`llm_ms, tool_ms, tool_call_count`) packed into a nested `"timing"` sub-object (persisted as `agent_task.token_usage.timing`). `status MUST be 'completed'|'failed'|'timed_out'`.
- **Error codes** (enum tokens, NEVER stack traces; `:41-51`): `SDK_UNAVAILABLE, WORKSPACE_SETUP_FAILED, ARTIFACT_FETCH_FAILED, NO_RESULT, EXECUTION_FAILED, TIMEOUT`, **`FEDRAMP_REJECTED`** (NEW — `ERROR_CODE_FEDRAMP`, for fail-closed compliance rejections).

---

## 5. SKILL LOADING & THE `/skills/dispatch/{id}` API

### 5.1 `resolve_and_load_skill` (`skill_loader.py:252`)

```
resolve_and_load_skill(skill_id, skills_dir, config_dir, *, api_url=None) -> SkillDefinition:
  effective_url = api_url OR env SKILL_API_URL
  IF effective_url:
      skill = load_skill_from_api(skill_id, effective_url)   # §5.2
      IF skill is not None: RETURN skill
      LOG info "API load failed for '%s'; falling back to filesystem."
  # --- filesystem fallback (DEPRECATED) ---
  LOG warning "Loading skill '%s' from filesystem (deprecated). Set SKILL_API_URL ..."
  mapping = load_skill_mapping(config_dir)                   # skill_mapping.yaml (EMPTY by design)
  dir_name = mapping.get(skill_id)
  IF dir_name is None: RAISE KeyError("Skill ID '{skill_id}' not found in skill_mapping.yaml. Known IDs: [...]")
  RETURN load_skill(skills_dir, dir_name)                    # §5.3
```

⚠️ **GOTCHA — `skill_mapping.yaml` is intentionally EMPTY.** Skills dispatch by canonical directory id directly. A filesystem fallback with the empty map → `KeyError`. The API-first path is the only working path; `SKILL_API_URL` is set in the live stack.

### 5.2 `load_skill_from_api` (`:193`) ↔ `GET /api/v1/skills/dispatch/{id}`

```
load_skill_from_api(dispatch_id, api_url, *, timeout=10.0, token=None) -> SkillDefinition | None:
  url = "{api_url.rstrip('/')}/api/v1/skills/dispatch/{dispatch_id}"
  effective_token = token OR env OLYMPUS_API_TOKEN
  headers = {"Authorization": "Bearer {token}"} IF token ELSE {}
  TRY: resp = httpx.get(url, timeout, headers); resp.raise_for_status(); data = resp.json()
  EXCEPT Exception: LOG debug "API skill fetch failed ..."; RETURN None    # ANY error → None (triggers fallback)
  config_data = data.get("config_data", {}) or {}
  provider = _coerce_provider(config_data.get("provider")) or _coerce_provider(data.get("provider"))   # NEW
  config_model_tier = _coerce_str(config_data.get("model_tier"))                                        # NEW
  RETURN SkillDefinition(
      name=data.get("name", dispatch_id), description=data.get("description",""),
      skill_dir=data.get("skill_path",""), model_tier=data.get("model_tier","tier-2"),
      allowed_tools=data.get("allowed_tools",[]), system_prompt=data.get("system_prompt",""),
      references=data.get("references_data",{}), assets=data.get("assets_data",{}),
      config=config_data, provider=provider, config_model_tier=config_model_tier,
      output_schemas=_coerce_output_schemas(data.get("output_schemas")))
```

**The endpoint** (`olympus-api/src/routers/skills.py:174`): `GET /api/v1/skills/dispatch/{dispatch_id}` → `SkillDetail` (auth: `require_role(*VIEWER_PLUS)`; SERVICE role allowed). `get_skill_by_dispatch_id`: `SELECT * FROM skill WHERE dispatch_ids @> CAST(:dispatch_ids AS jsonb) AND status='active'` (GIN index); None → `OlympusHTTPException(404, "SKILL_NOT_FOUND")`; else `_row_to_detail(row)`.

⚠️ **GOTCHA — field-name mapping.** The loader reads `skill_path` (not `skill_dir`), `references_data`/`assets_data`/`config_data` (JSONB columns). `model_tier` defaults to `tier-2`. NEW: `provider` from `config_data["provider"]` (or top-level `data["provider"]`), `config_model_tier` from `config_data["model_tier"]`.

⚠️ **GOTCHA — `output_schemas` is ALWAYS `[]` on the live API-first load path. THIS IS DISPOSITIVE (unchanged at HEAD).** `data.get("output_schemas")` on the API path is **always `None`** → `_coerce_output_schemas(None)` → `[]`. Proof:
- The dispatch endpoint returns a `SkillDetail` (`olympus-api/src/models/skill.py`), which declares its fields and **none is `output_schemas`**; it has no `model_config=ConfigDict(extra="allow")`, so Pydantic v2 drops unknown keys.
- `_row_to_detail` maps explicit columns only; never `output_schemas`.
- The skill **table has no `output_schemas` column** (`db/seeds/initial-data.sql` COPY header). The SKILL.md `output_schemas:` frontmatter survives only as raw text inside the `content` column.
- Zero references to `output_schemas` in the entire API skill surface.

**Consequence: on the live API-first load path, `skill.output_schemas == []` ALWAYS.** The Section-5/§2 validation machinery is fed an empty contract on this path. (Honored elsewhere — §5.2.1.)

### 5.2.1 ⚠️ Where `output_schemas` IS still honored (the parity map)

1. **Agent-runtime A2A dispatch (this doc's primary subject) — DORMANT.** Skill loaded via `load_skill_from_api` → `output_schemas == []` → `validate_output_files(output_files, [])` returns files unchecked. Section 5 omitted. No marker, no §2.6 retry. **This is the live behavior; reproduce it.**
2. **Deprecated filesystem load path — HONORED but non-functional in the live stack.** `load_skill` (§5.3) DOES parse `output_schemas` from frontmatter; full §2 validation + §2.6 retry would run — but reachable only when `SKILL_API_URL` unset AND `skill_mapping.yaml` has the id, and that file is intentionally EMPTY (§5.1) → `KeyError`. Honored in code, unreachable as configured.
3. **Human-paired-agent RETURN-payload flow (a DIFFERENT API, a DIFFERENT service) — HONORED and LIVE.** `olympus-api/src/services/return_payload_validator.py` `load_output_schemas_for_skill(skill_id)` opens `cross-cutting/skills/<skill_id>/SKILL.md` **on disk**, parses frontmatter, runs `_coerce_output_schemas` (same coercion). `validate_return_output_payload(...)` selects a schema (per-skill `_PRIMARY_PATH_BY_SKILL`, else first), loads it (repo-relative `_resolve_schema_root`), runs `Draft202012Validator(...).iter_errors(...)`. Caller: `human_paired_agent.py` `return_task` → non-empty violations raise `OUTPUT_SPEC_VIOLATION` HTTP 400. Scope: the 6 Rationalization-line skills (`analyze-portfolio-redundancy`, `classify-application`, `disposition-recommender`, `portfolio-scorer`, `redundancy-analyzer`, `wave-outcome-synthesizer`).

⚠️ **GOTCHA — same frontmatter field, two enforcement realities.** Inert for agent-runtime A2A dispatch (path 1); binding for the human-paired RETURN endpoint (path 3, which re-parses the file directly). Do NOT add `output_schemas` to `SkillDetail`/the table to "fix" path 1 — it would change observable behavior.

### 5.3 Filesystem `load_skill` (`:79`) + frontmatter parse — CHANGED (provider/config_model_tier)

```
load_skill(skills_dir, skill_dir_name) -> SkillDefinition:
  skill_md = skills_dir/skill_dir_name/SKILL.md
  IF not exists: RAISE FileNotFoundError
  frontmatter, body = _parse_frontmatter(raw)               # split on "---" ×3; YAML; bad YAML → {}
  name = fm.get("name", skill_dir_name); description = fm.get("description","")
  agent_hint = fm.get("agent","sonnet"); model_tier = _AGENT_TIER_MAP.get(str(agent_hint).lower(), "tier-2")
  allowed_tools = fm.get("allowed-tools", []) (must be list else [])
  output_schemas = _coerce_output_schemas(fm.get("output_schemas"))
  references = _load_references (sorted references/*.md)
  assets     = _load_assets (sorted assets/* text; skip binary on UnicodeDecodeError)
  config     = _load_config (config.json or {})
  provider   = _coerce_provider(config.get("provider")) or _coerce_provider(fm.get("provider"))   # NEW — config.json wins
  config_model_tier = _coerce_str(config.get("model_tier"))                                        # NEW
  RETURN SkillDefinition(name, description.strip(), skill_dir=str(path), model_tier, allowed_tools,
                         system_prompt=body.strip(), references, assets, config,
                         provider=provider, config_model_tier=config_model_tier, output_schemas=output_schemas)
```

`_coerce_output_schemas(value)` (`:152`): None→`[]`; non-list→LOG debug, `[]`; per entry: dict with str `path` + str `schema` else skip(LOG debug); returns `[{"path":..., "schema":...}]`.
`_coerce_provider(value)`/`_coerce_str(value)` (`:142`/`:135`): non-empty stripped str else `""`.

### 5.4 Profile overlays — `load_skill_with_profile` (`:459`)

(Used by the API skill-ingest path.) Precedence (CONVENTIONS.md §5): (1) base body → (2) profile config variables (`profiles/<client>/config/{common.yaml,<skill_id>.yaml}`) substitute `{{var}}` (`_resolve_variables` — unknown tokens LEFT VISIBLE) → (3) profile references additions (profile wins on name collision) → (4) profile `SKILL.md` overlay (replaces body; frontmatter merge — overlay wins per-key). ⚠️ Provider resolution carried through: overlay frontmatter `provider:` wins over base, else base.provider (which already prefers config.json); `config_model_tier`/`output_schemas` carried from base.

---

## 6. ⚠️ NEW: THE MULTI-PROVIDER DISPATCH SUBSYSTEM

The A2A protocol is provider-neutral. At HEAD, every model-vendor SDK lives behind a uniform `ProviderClient` contract so the a2a `_execute` pipeline never knows which provider it called (except the `bedrock-claude` short-circuit, §4.4a). The three dimensions a provider declares — **hosting provider** (owns auth/compliance), **SDK** (speaks to the model), **FedRAMP compliance** (an attribute of the HOSTING provider, not the model) — are separated so a future `bedrock-openai` (OpenAI models served VIA Bedrock) can be FedRAMP-compliant while raw `openai` is not.

### 6.1 `ProviderClient` + `ProviderCapabilities` (`provider_client.py`)

```
@dataclass(frozen=True) ProviderCapabilities:               # :22
  name: str                  # composite id, e.g. "bedrock-claude", "openai", "gemini-vertex" (== {sdk}-on-{hosting})
  hosting_provider: str       # "bedrock" | "openai-api" | "gcp-vertex" | "azure-foundry" | "anthropic-api"
  sdk: str                    # "anthropic" | "openai" | "gemini" | "bedrock-converse"
  fedramp_compliant: bool     # attribute of the HOSTING provider (bedrock→True; openai-api/gcp-vertex/anthropic-api→False)
  supports_tools: bool; supports_streaming: bool; supports_sub_agents: bool
  live: bool                  # True = wired to a real API; False = scaffold stub

class ProviderClient(abc.ABC):                              # :50 — stateless per-execution
  @classmethod @abstractmethod capabilities(cls) -> ProviderCapabilities
  @abstractmethod async execute(*, skill, task_message, model_id, system_prompt, tools, app_id="", source_repo="",
        workspace_key="", workspace_dir="/workspace", workspace_path="", artifacts_dir="", cwd="",
        permission_mode="acceptEdits") -> A2ATaskResponse
  @abstractmethod is_available() -> bool
```

⚠️ **CONTRACT (`execute` MUST/MUST NOT, `:88-105`).** MUST: `status="completed"` on success; `status="failed"` + non-empty `error` on recoverable failure; populate `token_usage.{input,output}` when the API provides them; populate `cost_estimate_usd` when computable; set `model_used` to the canonical name (not an opaque ARN); **NEVER raise for execution failures — catch and return a failed response** (so the caller's error path is uniform). MUST NOT: block the event loop; store task-specific state on `self`; call `sys.exit()`/`os._exit()`.

⚠️ **GOTCHA — scaffolds intentionally BREAK the no-raise contract.** `GeminiVertexProvider.execute` and `BedrockConverseScaffold.execute` `raise NotImplementedError(...)`. They are never *reached* with this contract live because `is_available()` returns False → `get_provider` raises `RuntimeError` first (caught as `_ProviderUnavailable` at the router, §4.4a). The raise is the "this scaffold isn't wired" tripwire.

### 6.2 Registry + factory (`provider_factory.py`)

```
_REGISTRY: dict[str, type[ProviderClient]] = {}            # populated at import time
register(name, cls):                                        # :23 — each provider module calls this at import
  IF name in _REGISTRY: LOG warning "Provider '%s' already registered; overwriting"
  _REGISTRY[name] = cls
get_provider(name, *, config_dir="", prefix="us", inference_profile_arns=None) -> ProviderClient:   # :34
  cls = _REGISTRY.get(name)
  IF cls is None: RAISE ValueError("Unknown provider '{name}'. Registered providers: {sorted(_REGISTRY)}")
  instance = cls(config_dir=config_dir, prefix=prefix, inference_profile_arns=inference_profile_arns or {})
  IF not instance.is_available():
      caps = cls.capabilities()
      IF not caps.live: RAISE RuntimeError("Provider '{name}' is a scaffold stub (live=False). ...")
      RAISE RuntimeError("Provider '{name}' is not available — check credentials and SDK installation. ...")
  RETURN instance
get_capabilities(name) -> ProviderCapabilities | None:      # :82 — does NOT instantiate (reads class-level capabilities())
list_providers() -> sorted(_REGISTRY); is_registered(name) -> name in _REGISTRY
```

⚠️ **GOTCHA — registry populated at IMPORT time, no filesystem scanning.** `main.py` does `import src.providers as _providers` at startup (`main.py:12`); `providers/__init__.py` imports `bedrock_claude, bedrock_llama, bedrock_mistral, bedrock_nova, gemini_vertex, openai_provider`, each of which calls `register(...)` at module scope. The import list IS the exhaustive provider declaration. ⚠️ Callers MUST NOT cache the `get_provider` instance across requests (per-instance state would break concurrency).

### 6.3 The provider implementations (`src/providers/`)

#### 6.3a `BedrockClaudeProvider` (`bedrock_claude.py`) — LIVE

```
capabilities(): name="bedrock-claude", hosting_provider="bedrock", sdk="anthropic", fedramp_compliant=True,
                supports_tools=True, supports_streaming=True, supports_sub_agents=True, live=True
is_available(): RETURN bool(agent_executor._SDK_AVAILABLE)   # reads the module flag; never a live Bedrock call
execute(...): RETURN await agent_executor.execute_skill(... all orchestration kwargs incl. timeout_seconds/max_turns/max_budget_usd ...)
```

⚠️ Thin adapter — the Claude path builds its own system prompt + tool list INSIDE `execute_skill` (the SDK provides the tool runtime), so the `system_prompt`/`tools` interface params are accepted for uniformity but unused. Behavior is identical to the pre-refactor call. (The live a2a router does NOT route through this class for `bedrock-claude`; it calls `execute_skill` directly — §4.4a.)

#### 6.3b `OpenAIProvider` (`openai_provider.py`) — LIVE

```
capabilities(): name="openai", hosting_provider="openai-api", sdk="openai", fedramp_compliant=False,
                supports_tools=True, supports_streaming=False, supports_sub_agents=False, live=True
is_available(): RETURN _OPENAI_AVAILABLE AND bool(env OPENAI_API_KEY.strip())   # reads env every call (rotation w/o restart)

execute(*, skill, task_message, model_id, system_prompt="", tools=None, app_id="", ..., mission_context=None, **_ignored):
  start_ms = now_ms
  tools = tools or skill.allowed_tools or ["Read","Glob","Grep","Write","Bash"]
  # --- workspace: reuse shared executor utilities when caller didn't pre-build (:199-221) ---
  own_workspace = not workspace_path
  IF own_workspace:
      os.makedirs(workspace_dir, exist_ok=True)
      TRY: workspace_path, source_dir, artifacts_dir = agent_executor._setup_workspace(workspace_dir, workspace_key, source_repo, task_type)
      EXCEPT Exception as exc: RETURN A2ATaskResponse(status="failed", model_used=model_id, duration_ms=.., error="Failed to set up workspace: {exc}")
      cwd = source_dir IF agent_executor._repo_already_cloned(source_dir) ELSE workspace_path
  # --- prompt: build from skill if none, then normalize for OpenAI (drop sub-agent block) (:226-234) ---
  IF not system_prompt: system_prompt = agent_executor.build_system_prompt(skill, app_id, artifacts_dir, "", mission_context=mission_context)
  prompt = agent_executor.normalize_system_prompt(system_prompt, "openai")          # §1.2.1
  sandbox_root = workspace_path or cwd or workspace_dir
  executor = ToolExecutor(sandbox_root)                                              # §6.4
  tool_schema = _openai_tools_schema([t for t in tools if t != "Agent"])            # ⚠️ Agent tool excluded
  TRY: client = self._make_client()                                                 # AsyncOpenAI(api_key=..., base_url?, organization?)
  EXCEPT Exception as exc: RETURN A2ATaskResponse(status="failed", ..., error="failed to initialize OpenAI client: {exc}")
  messages = [{"role":"system","content":prompt}, {"role":"user","content":task_message}]
  total_input=0; total_output=0; final_text=""
  TRY:
      FOR _round IN range(_MAX_TOOL_ROUNDS=25):                                       # ⚠️ cap on tool rounds
          kwargs = {"model":model_id, "messages":messages}; IF tool_schema: kwargs["tools"]=tool_schema
          resp = await client.chat.completions.create(**kwargs)
          usage = getattr(resp,"usage",None); IF usage: total_input += prompt_tokens; total_output += completion_tokens
          message = resp.choices[0].message; tool_calls = getattr(message,"tool_calls",None)
          IF not tool_calls: final_text = message.content or ""; BREAK              # done
          messages.append(assistant echo with tool_calls)
          FOR tc IN tool_calls:
              result = await self._run_tool(executor, tc)                            # §below
              messages.append({"role":"tool","tool_call_id":tc.id,"content":result})
      ELSE:                                                                          # loop exhausted (no break)
          LOG warning "OpenAI dispatch hit max tool rounds (%d) for skill %s"        # final_text stays ""
  EXCEPT Exception as exc:
      LOG error "OpenAI dispatch failed: %s"
      IF own_workspace AND workspace_path: agent_executor._cleanup_workspace(workspace_path, workspace_key)
      RETURN A2ATaskResponse(status="failed", model_used=model_id, duration_ms=.., error=str(exc))
  duration_ms = now-start_ms
  output_files = agent_executor._collect_artifacts(artifacts_dir) if artifacts_dir else []   # ⚠️ NO delta-exclude (full collect)
  IF own_workspace AND workspace_path: agent_executor._cleanup_workspace(workspace_path, workspace_key)
  RETURN A2ATaskResponse(status="completed", output_artifacts=[final_text] if final_text else [],
        output_files=output_files, model_used=model_id, token_usage=TokenUsage(input=total_input, output=total_output),
        cost_estimate_usd=self._cost(model_id, total_input, total_output), duration_ms=duration_ms)

_run_tool(executor, tool_call) -> str:
  args = json.loads(tool_call.function.arguments or "{}")  (ValueError/TypeError → "ERROR: could not parse arguments ...")
  TRY: RETURN await executor.dispatch(name, args if dict else {})
  EXCEPT ToolExecutionError as exc: RETURN "ERROR: {exc}"
  EXCEPT Exception as exc: LOG warning; RETURN "ERROR: tool '{name}' failed: {exc}"   # never crash the loop

_cost(model_id, input_tokens, output_tokens) -> float:
  rates = load_rates(self._config_dir, "openai")  (model_rates §6.5); rate = rates.get(model_id)
  IF rate is None: LOG warning "No rate-table entry ...; cost set to 0.0"; RETURN 0.0
  RETURN input_tokens*rate["input_per_1m"]/1e6 + output_tokens*rate["output_per_1m"]/1e6
```

⚠️ **GOTCHA — OpenAI differs from Claude in several behaviors a re-implementer must preserve:** (1) no SDK subprocess tool runtime → tool calls run through the Olympus `ToolExecutor` (§6.4); (2) the `Agent` sub-agent tool is excluded from the schema; (3) cost is computed from the `models.yaml` rate table, not returned by the API; (4) `_MAX_TOOL_ROUNDS=25` caps the tool loop (exhaustion → empty `final_text`, still `status="completed"`); (5) `_collect_artifacts` runs WITHOUT a pre-existing-files snapshot (no delta exclusion — collects everything in `artifacts_dir`); (6) NO output-schema validation, NO failure marker, NO mission-context-first-then-feedback envelope ordering beyond what `build_system_prompt` produces; (7) `**_ignored` swallows orchestration kwargs (`input_artifacts`, `artifact_repo`, `timeout_seconds`, …) the Claude path consumes — **OpenAI does not fetch input artifacts and has no wall-clock timeout**.

#### 6.3c Scaffolds — `gemini_vertex.py`, `_bedrock_converse_scaffold.py`, `bedrock_nova/mistral/llama.py`

- `GeminiVertexProvider` (`gemini_vertex.py`): `capabilities()` → `gcp-vertex`/`gemini`/`fedramp_compliant=False`/`live=False`; `is_available()`→False; `execute(...)`→`raise NotImplementedError(_SCAFFOLD_MESSAGE)`.
- `BedrockConverseScaffold` (`_bedrock_converse_scaffold.py`): base for Nova/Mistral/Llama. `capabilities()` reads class attrs `PROVIDER_NAME`/`DISPLAY_CLASS` → `hosting_provider="bedrock"`, `sdk="bedrock-converse"`, **`fedramp_compliant=True`** (inherits Bedrock's boundary), `live=False`. `is_available()`→False; `execute(...)`→`raise NotImplementedError("{DISPLAY_CLASS} is a scaffold. ...")`.
- `bedrock_nova.py`/`bedrock_mistral.py`/`bedrock_llama.py`: subclass `BedrockConverseScaffold`, set `PROVIDER_NAME`/`DISPLAY_CLASS`, call `register(name, cls)`.

⚠️ **GOTCHA — the Bedrock Converse scaffolds are `fedramp_compliant=True` even though `live=False`.** Compliance is a hosting-provider attribute; being unwired (`live=False`) is orthogonal. They're still excluded from fallback (`select_fallback_provider` filters `not caps.live`, §4.4b), but under `require_fedramp_provider` they would NOT be rejected on compliance grounds if ever selected directly — they'd fail on `is_available()`→`RuntimeError`→`_ProviderUnavailable` instead.

### 6.4 `ToolExecutor` (`tool_executor.py`) — Olympus-owned sandboxed tools for non-Claude providers

```
class ToolExecutor:                                          # :37
  SUPPORTED_TOOLS = ("Read","Write","Glob","Grep","Bash")    # ⚠️ Agent (sub-agents) intentionally absent (§5.2, §11.1)
  __init__(workspace_root): self._root = Path(workspace_root).resolve()
  _resolve_within_sandbox(path) -> Path:                     # :54
      candidate = Path(path); IF not absolute: candidate = self._root / candidate
      resolved = candidate.resolve()
      TRY: resolved.relative_to(self._root)
      EXCEPT ValueError: RAISE ToolExecutionError("path '{path}' escapes the workspace sandbox; refused")   # ⚠️ THE sandbox boundary
      RETURN resolved
  async read(file_path): target=_resolve_within_sandbox; IF not is_file: RAISE ToolExecutionError("file not found"); RETURN to_thread(read_text,"utf-8")
  async write(file_path, content): target=_resolve_within_sandbox; mkdir parents; write_text; RETURN "wrote {n} bytes to {file_path}"
  async glob(pattern): RETURN sorted workspace-relative paths from self._root.rglob(pattern) (files only)
  async grep(pattern, path=""): try ripgrep (rg --no-heading --line-number, timeout=60s; FileNotFound/Timeout→None) else _grep_python (substring scan)
  async bash(command): create_subprocess_shell(cwd=self._root, stdout=PIPE, stderr=STDOUT, env={**os.environ});
                       wait_for(communicate(), timeout=120s); on timeout: proc.kill() + RAISE ToolExecutionError("bash command exceeded 120s")
  async dispatch(tool_name, arguments) -> str:               # :167 — routes a model-emitted tool call
      "Read"→read(file_path|path); "Write"→write(file_path|path, content); "Glob"→"\n".join(glob(pattern or "*"));
      "Grep"→grep(pattern, path); "Bash"→bash(command); else RAISE ToolExecutionError("unsupported tool '{tool_name}'; supported: {SUPPORTED_TOOLS}")
```

⚠️ **GOTCHA — the sandbox is the security boundary.** Every path is resolved and confirmed under `workspace_root` before any FS op; an escaping path raises `ToolExecutionError` (caught by `_run_tool` → returned as an `"ERROR: ..."` tool-result string, never crashes the loop). `_BASH_TIMEOUT_SECONDS=120`, `_GREP_TIMEOUT_SECONDS=60`.

### 6.5 `model_rates.py` — rate table + compliance + fallback chain from `models.yaml`

```
load_rates(config_dir, provider) -> {model_id: {input_per_1m, output_per_1m}}:   # :54
  data = _load_models_yaml; key = _resolve_provider_key(providers, provider)      # honors bedrock↔bedrock-claude alias both ways
  RETURN providers[key].get("rates", {})  (empty when absent — missing rate → cost 0.0, never an error)
provider_is_fedramp_compliant(config_dir, provider) -> bool:                      # :68
  key = _resolve_provider_key(...); entry = providers.get(key)
  IF entry not a dict: RETURN False                                               # ⚠️ unknown provider → fail closed
  RETURN bool(entry.get("fedramp_compliant", False))
provider_fallback_order(config_dir) -> list[str]:                                 # :84
  RETURN [str(p) for p in data.get("provider_fallback_order", [])]  (else [])
```

⚠️ **GOTCHA — `model_rates.provider_is_fedramp_compliant` is the YAML fallback for `provider_selection.provider_is_fedramp_compliant`.** The selection module prefers the live `ProviderCapabilities` declaration when the provider is registered; it only re-parses `models.yaml` via this function for an UNregistered provider. Both default to False for unknown providers.

### 6.6 `gateway_router.py` — tool-routing backend abstraction (spike, NOT wired)

See §1.7's GOTCHA. `ToolRouter` ABC + `DirectToolRouter` (flag-off default; `route_tools(tools) -> list(tools)` identity) + `AgentCoreGatewayRouter` (flag-gated spike; `route_tools` always raises `AgentCoreGatewayUnavailableError`) + `resolve_tool_router(config)` (flag `OLYMPUS_AGENTCORE_GATEWAY_ENABLED`, default false → `DirectToolRouter`). Reproduce as a standalone module; no executor/dispatch path calls it at HEAD.

---

## 7. CONFIG REFERENCE (`AgentRuntimeConfig`, `config.py`) — CHANGED

| Field | Default | Notes |
|---|---|---|
| `service_name` | `olympus-agent-runtime` | |
| `version` | `0.1.0` | |
| `log_level` | `INFO` | |
| `agent_name` | `discovery-analyst` | |
| `agent_port` | `8100` | |
| `skills_dir` | `/app/skills` | filesystem fallback root |
| `skill_api_url` | `""` | e.g. `http://olympus-api:8000` — enables API-first loading |
| `inference_provider` | **`bedrock-claude`** | ⚠️ CHANGED default (was `bedrock`). Composite provider id matching a `models.yaml` key. Legacy `bedrock` still accepted (shim → `bedrock-claude`). Feeds the selection resolver layer 4 + telemetry `agent_backend` |
| `default_model_tier` | `tier-2` | |
| `aws_region` | `us-east-1` | |
| `bedrock_model_prefix` | `us` | `us`/`global`/`eu` — the `ModelSelector` prefix |
| `bedrock_inference_profile_arns` | `{}` | **NEW** — canonical model name → application inference-profile ARN. When a selected model's canonical name has an entry, the ARN is sent to Bedrock (cost attribution). Env `BEDROCK_INFERENCE_PROFILE_ARNS` (JSON; blank → `{}` via `NoDecode` + `_parse_arns` validator) |
| `claude_code_use_bedrock` | `1` | |
| `permission_mode` | `acceptEdits` | ⚠️ NOT `dontAsk` — see below |
| `workspace_dir` | `/workspace` | persistent base dir |
| `olympus_agentcore_memory_enabled` | **`False`** | **NEW** — flag-gates `AgentCoreMemoryBackend` (§1.7). Default false → `LocalWorkspaceMemoryBackend` (byte-for-byte prior behavior). boto3/bedrock-agentcore imported lazily inside the guard |
| `olympus_agentcore_gateway_enabled` | **`False`** | **NEW** — flag-gates `AgentCoreGatewayRouter` (§6.6). Default false → `DirectToolRouter` |
| `agentcore_memory_id` | `""` | **NEW** — managed memory store id; consulted only when the Memory flag is true |
| `max_concurrent_tasks` | `12` | raised 4→12 (2026-05-08); semaphore capacity |
| `max_queued_waiters` | `2` | 503 fail-fast cap |
| `skill_timeout_seconds` | **`1800`** (30 min) | **NEW** — wall-clock ceiling around the `query()` stream (`execute_skill` Step 11). Fires ONLY on a silent stall. Set below the worker's `start_to_close_timeout` so the agent fails first with a structured `"timeout"` |
| `skill_max_turns` | **`None`** | **NEW** — `ClaudeAgentOptions.max_turns`. DEFAULT OFF (a correctness bound; low values kill good work — legit discovery runs hit 169-264 tool rounds). Compounds across sub-agents |
| `skill_max_budget_usd` | **`None`** | **NEW** — `ClaudeAgentOptions.max_budget_usd`. DEFAULT OFF (kills an expensive-but-working run; Olympus optimizes for work-done, not cost) |

`model_config = {"env_file": ".env", "env_file_encoding": "utf-8"}`. `get_config()` memoizes a module-level singleton.

⚠️ **GOTCHA — NO `OLYMPUS_AGENTCORE_RUNTIME_ENABLED` flag exists, by design.** AgentCore Runtime would displace the Temporal activity boundary and regress durability. There is deliberately no Runtime flag/import anywhere; adding one requires an explicit architectural-review override.

⚠️ **GOTCHA — `permission_mode="acceptEdits"`.** `acceptEdits` silently ACCEPTS file edits within allowed dirs (no human prompt in headless dispatch). The previous `dontAsk` mode silently DENIED edits → agents burned turns retrying the same Write. Combined with `add_dirs=[workspace_path]`, Writes under `artifacts/` succeed.

⚠️ **GOTCHA — `add_dirs=[workspace_path]` only (NOT `workspace_dir`).** Per-dispatch read isolation: the agent may read/write ONLY this dispatch's `workspace_path` (`.../<workspace_dir>/<workspace_key>`), never the parent `workspace_dir` where sibling apps' runs accumulate on a shared ephemeral replica. This is the fix behind the 2026-06-12 cross-app-bleed incident.

⚠️ **GOTCHA — health `_active_tasks` reads `Semaphore._value`.** `health.py`: `active = _max_concurrent - _task_semaphore._value` (private attr). `/health/ready` returns `"busy"` (still HTTP 200) when `active >= _max_concurrent`. `_max_concurrent` is overwritten to 12 at startup via `init_concurrency` (`main.py:44`).

---

## 8. ⚠️ AGGREGATED GOTCHAS (ordering / fragility)

1. **Envelope section order is the cross-doc contract** (§1.2). Mission first, feedback last, sections 7+8 always present.
2. **`extras` never enters `build_system_prompt`** — only the `task_message` (worker renders `context` inline, §4.2).
3. **`model_preference` blank-vs-`"tier-2"`** (§4.2): the worker must send `""` when no explicit preference, or every Opus-declared skill silently drops to Sonnet.
4. **Validation retry rides the workspace marker** (§2.6); ephemeral workspaces (`workspace_key==""`) get NO feedback (cleanup destroys the marker). Timeout (#6) writes NO marker.
5. **Task-scoped artifacts dir is rmtree'd at dispatch start** (§1.4) — avoid snapshotting prior-attempt files as `pre_existing`.
6. **Delta collection** (§1.6): only files NOT in the pre-existing snapshot are returned; `rglob` SORTED. ⚠️ OpenAI provider does FULL collect (no exclude, §6.3b).
7. **SDK-raises-after-ResultMessage = success** (§1.1 Step 11) — do not treat as failure if `result_text` is set.
8. **System-prompt >64KB spills to file** (§1.1 Step 7b) — `{"type":"file","path":...}` → `--system-prompt-file` (ARG_MAX guard).
9. **`Agent` tool always appended** for the Claude path (§1.1 Step 6); default tools `[Read,Glob,Grep,Write,Bash]` when none. ⚠️ Non-Claude providers EXCLUDE `Agent` (no sub-agents; §6.3b/§6.4).
10. **NEW: wall-clock timeout = 6th early-return** (§1.1 Step 11) — `asyncio.timeout` wrapper → `status="timeout"`; without it, a stalled sub-agent hangs forever.
11. **NEW: `execute_skill` workspace ops go through `memory_backend`** (§1.7); flag-off default = byte-for-byte prior `_setup_workspace`/`_cleanup_workspace`. Flag-on fails LOUD.
12. **NEW: provider+tier resolution runs BEFORE model selection** (§4.3) with a 5-layer precedence and **FedRAMP fail-closed** (`FedRampComplianceError` → `ERROR_CODE_FEDRAMP`).
13. **NEW: one cross-provider fallback hop** on `_ProviderUnavailable` (§4.4/§4.4b); scaffolds + (under FedRAMP) non-compliant providers filtered; at most ONE hop.
14. **NEW: `ModelSelector.select` returns `ModelSelection(model_id, canonical_model)`** (§3); ARN substitution for cost attribution; `bedrock`↔`bedrock-claude` shim; bedrock-hosted gets `{prefix}.{base}`, direct SDKs get bare base. Telemetry/`model_used` reports the CANONICAL name, not the ARN.
15. **`select()` ignores availability** (§3.2) — pure config-presence fallback walk.
16. **`us.` prefix + `[1m]` suffix** (§3.5) preserved verbatim; ⚠️ CHANGED: tier-1 is now `opus-4-8`.
17. **`OLYMPUS_SCHEMA_ROOT` = repo root** (§2.2), not `schemas/`.
18. **Ref tree wins over HEAD tree** in artifact resolution (§1.5); branch names with slashes resolve to SHA first.
19. **Production refuses mock** at worker startup via a fatal raise (§4.1); the runtime service has no such gate.
20. **Validation failure / no-result responses carry `output_files`** but SDK-failure / timeout / setup-fetch failures do not (§1.1).
21. **Telemetry is fire-and-forget** — disabled unless `OLYMPUS_API_URL` set; errors swallowed (§4.8); error codes are enum tokens, NEVER stack traces; NEW `provider_name`/`provider_fallback_from`/`FEDRAMP_REJECTED`.
22. **NEW: provider registry populated at import time** (§6.2); `main.py` imports `src.providers`; no filesystem scanning; never cache `get_provider` instances.
23. **NEW: `output_schemas` still `[]` on the API path** (§5.2 — DISPOSITIVE, unchanged); §2 validation dormant for A2A dispatch; honored only by the human-paired RETURN flow (§5.2.1 path 3).
24. **NEW: S3 source-clone cache is best-effort** (§1.4a) — any S3 error falls back to `git clone`, never fails the dispatch; OFF when `AGENT_WORKSPACE_S3_BUCKET` unset.
25. **NEW: None-guards on every SDK message `isinstance`** (§1.1) — required so a stripped (SDK-absent) install raises the clean Step-0 `RuntimeError` instead of `NameError`.

---

## 9. BEHAVIORAL-PARITY CHECKLIST

A reimplementation passes parity iff ALL hold:

- [ ] `execute_skill` reproduces all steps with the **SIX** early-returns (#1 setup-fail, #2 fetch-fail, #3 SDK-fail-no-result, #4 validation-fail, **#6 timeout→`status="timeout"`**, #5 no-result-tail) and identical cleanup placement (cleanup on #3/#4/#6/#15/#16, NOT #1/#2; all via `memory_backend.cleanup_workspace`).
- [ ] Signature includes `timeout_seconds`/`max_turns`/`max_budget_usd`/`memory_backend`; `memory_backend is None` resolves via `resolve_memory_backend(get_config())`.
- [ ] `asyncio.timeout(_effective_timeout)` wraps the `async for` stream; `except (TimeoutError, asyncio.TimeoutError)` → cleanup + `A2ATaskResponse(status="timeout", ...)`; `_effective_timeout = timeout_seconds if timeout_seconds>0 else None`.
- [ ] `max_turns`/`max_budget_usd` set `options.max_turns`/`max_budget_usd` only when not None; `options.stderr = _log_cli_stderr`; `ResultMessage.num_turns`/`stop_reason` logged; every SDK `isinstance` check is None-guarded.
- [ ] `build_system_prompt` emits the 9 sections in EXACT documented order/headers; mission first, feedback last, sections 7+8 unconditional, joined by `"\n"`; Section 5 inlines loadable schemas verbatim (```` ```json ````), "could not be loaded" fallback, skips entries missing path/schema; Section 6 announces `Application ID`/`Input Artifacts Directory`/`Output Directory` only when non-empty.
- [ ] `normalize_system_prompt`: verbatim for `("","bedrock-claude","anthropic")`; else excises ONLY the Parallel-Sub-Agents block (preserves Output Contract + Parallel-Tool-Calls).
- [ ] `MemoryBackend`: `LocalWorkspaceMemoryBackend` delegates verbatim to `_setup_workspace`/`_cleanup_workspace`; `resolve_memory_backend` returns Local when flag off; `AgentCoreMemoryBackend.setup_workspace` raises `AgentCoreMemoryUnavailableError` (empty memory_id OR `_load_client`); lazy boto3 import inside the guard.
- [ ] `_setup_workspace`: persistent-vs-ephemeral on `workspace_key`; unsafe segments degrade (no raise); boundary check raises `ValueError`; task-scoped artifacts rmtree'd at start; source clone is S3-cache-first (restore → else clone + upload), all best-effort.
- [ ] `_fetch_input_artifacts`: ≤2 tree calls; ref-tree-wins; 8-worker parallel blob fetch; required-miss → `FileNotFoundError`; optional-miss → skip; truncated → `RuntimeError`; HEAD-tree-None → `RuntimeError`.
- [ ] `_collect_artifacts`: sorted rglob; delta via `exclude`; binary-ext base64; UnicodeDecodeError → base64.
- [ ] `validate_output_files`: pass-through on no schemas; jsonschema-missing → `OutputValidationError`; path match full-path OR basename; base64 skipped; empty/parse-fail/unloadable/schema-violation each appended; whole-set; single coalesced raise with `;`-joined path/schema_path; `_format_violations` capped at 10.
- [ ] Failure-marker round-trip: write on validation fail (persistent only), read feeds Section 9 next attempt, clear on clean run; timeout writes NO marker.
- [ ] Second-failure: `execute_skill` returns `status="failed"` (does NOT raise) → activity raises `RetryableError` → `AGENT_RETRY_POLICY(maximum_attempts=3)` reschedules → marker drives feedback each attempt → exhaustion at attempt 3 surfaces to workflow (no separate "give up" branch).
- [ ] `ModelSelector.select` returns `ModelSelection`; ARN substitution by canonical name; bedrock-hosted → `{prefix}.{base}`, else bare base; `bedrock`↔`bedrock-claude` shim in `_load_config`; `_fedramp_compliant`/`_hosting_provider` set from the matched provider entry; availability NOT consulted in `select`; last-resort `_models[tier] or _models["tier-2"]` or `ModelSelection("", "unknown-agent")`.
- [ ] `models.yaml` tiers/fallback/aliases/**rates/fedramp_compliant/hosting_provider/sdk/provider_fallback_order** reproduced verbatim incl. `[1m]` suffixes and tier-1=`opus-4-8`.
- [ ] `resolve_provider_and_tier`: 5-layer provider precedence (skill→overrides→profile default→runtime→`bedrock-claude`), `bedrock`→`bedrock-claude` warn; tier precedence (request→config_model_tier→skill.model_tier→profile→runtime→`tier-2`); `require_fedramp_provider` → `FedRampComplianceError` when resolved provider not compliant (unknown → not compliant).
- [ ] `select_fallback_provider`: walks `provider_fallback_order` after the original; skips `not caps.live` and (under FedRAMP) non-compliant; returns first eligible or None; at most one hop.
- [ ] A2A `_execute`: Phase B skill-load (KeyError/FileNotFoundError → warn, skill=None); Phase C provider+tier resolve (FedRAMP rejection → `ERROR_CODE_FEDRAMP` failed response) then `ModelSelector`; Phase D telemetry start (`provider_name`), `_dispatch`, one `_ProviderUnavailable` fallback hop (re-select model, record provenance), terminal-status map incl. `timeout`→`timed_out`+`ERROR_CODE_TIMEOUT`; reports `canonical_model` (not ARN).
- [ ] `_dispatch`: `bedrock`/`bedrock-claude` → `execute_skill` directly (with timeout/turns/budget bounds); `RuntimeError` → `_ProviderUnavailable`; others → `provider_factory.get_provider` (ValueError/RuntimeError → `_ProviderUnavailable`) → `provider.execute(...)`.
- [ ] `ProviderClient`/`ProviderCapabilities`: ABC + frozen dataclass with the 8 fields; `execute` MUST-NOT-raise contract (scaffolds raise NotImplementedError but are gated behind `is_available()`→False).
- [ ] `provider_factory`: import-time `register`; `get_provider` raises `ValueError` (unknown) / `RuntimeError` (scaffold or unavailable); `get_capabilities` reads class-level without instantiating; `main.py` imports `src.providers` at startup.
- [ ] Providers: `bedrock-claude` (live, `is_available`=`_SDK_AVAILABLE`, calls `execute_skill`); `openai` (live, env-key check, `ToolExecutor` tool loop, `_MAX_TOOL_ROUNDS=25`, rate-table cost, full artifact collect, sub-agent stripped); `gemini-vertex` + Nova/Mistral/Llama scaffolds (`live=False`, `is_available`=False, `execute` raises); Converse scaffolds `fedramp_compliant=True`.
- [ ] `ToolExecutor`: `SUPPORTED_TOOLS=(Read,Write,Glob,Grep,Bash)` (no Agent); `_resolve_within_sandbox` raises `ToolExecutionError` on escape; bash 120s / grep 60s timeouts; `dispatch` routes by name, unknown → `ToolExecutionError`.
- [ ] `model_rates`: `load_rates` (empty when absent → cost 0.0); `provider_is_fedramp_compliant` (unknown → False); `provider_fallback_order`; `bedrock`↔`bedrock-claude` key resolution both directions.
- [ ] `gateway_router`: `DirectToolRouter` identity (flag-off default); `AgentCoreGatewayRouter.route_tools` raises `AgentCoreGatewayUnavailableError`; NOT consumed by the executor.
- [ ] Worker `dispatch_via_a2a`: sends `model_preference or ""`; `_post_with_saturation_retry` 5×, exp-backoff capped 30s, `max(retry_after, backoff)+jitter`; non-503 → `raise_for_status`.
- [ ] `AGENT_RUNTIME_MODE`: default `live`; mode∉{live,mock} → `InvalidAgentRuntimeModeError`; `mock`+`APP_ENV∈{production,prod,staging,stage}` → `MockInProductionError`; gate runs once at worker startup.
- [ ] `dispatch_via_mock`: fixture resolution (explicit `fixture_scenario` > single-file > error); `_validate_shape`; `_materialize`; duration backfill when 0; signature parity.
- [ ] `dispatch_agent_task` mode routing: env `AGENT_RUNTIME_MODE=="mock"` → `dispatch_via_mock`; else `olympus_api...agent_client.dispatch_via_a2a` (ImportError → bundled `src.agent_client`); FAILED result → `RetryableError`; `_is_retryable` keyword classification.
- [ ] Skill loading: API-first → `SkillDetail` mapped (`skill_path`, `*_data`, NEW `provider`/`config_model_tier`); any HTTP error → None → filesystem fallback (KeyError on empty map). `SkillDefinition` carries `provider` + `config_model_tier` (config.json wins over frontmatter).
- [ ] ⚠️ `SkillDetail` reproduced WITHOUT `output_schemas`; skill table has NO such column; `_row_to_detail` does NOT map one → `load_skill_from_api` yields `skill.output_schemas == []` ALWAYS → §2 validation + Section 5 + §2.6 retry DORMANT on the API path. Do NOT add `output_schemas` to `SkillDetail`/table. Enforced LIVE only by the human-paired RETURN flow.
- [ ] Telemetry fire-and-forget: enabled only on `OLYMPUS_API_URL`; `Bearer` token; start/complete share one UUID; `derive_agent_id` substring/prefix mapping (incl. `opus-4-8`/`opus-4-5`/`sonnet-4-5`); timing fields nested under `"timing"`; errors swallowed; enum error codes only (incl. `FEDRAMP_REJECTED`).
- [ ] `AgentRuntimeConfig` defaults reproduced: `inference_provider="bedrock-claude"`, `permission_mode="acceptEdits"`, `max_concurrent_tasks=12`, `max_queued_waiters=2`, `bedrock_model_prefix="us"`, `default_model_tier="tier-2"`, `skill_timeout_seconds=1800`, `skill_max_turns=None`, `skill_max_budget_usd=None`, both AgentCore flags False, `bedrock_inference_profile_arns={}` (blank env → `{}`).
- [ ] SDK options: `allowed_tools`, `system_prompt` (str or file-dict), `permission_mode`, `model`, `cwd`, `add_dirs=[workspace_path]` (ONLY, for cross-app isolation), optional `mcp_servers`, optional `max_turns`/`max_budget_usd`, `stderr` callback.
