# 05 — Dashboard Design System + API Client (Atomic Regeneration Spec)

> **Scope.** This document specifies, with full reproduction fidelity, three load-bearing
> sub-systems of the Olympus dashboard (`/Users/pnunna/Documents/GitHub/foundry/dashboard`):
>
> 1. **The USWDS design-token / branding system** — every CSS file, every custom property,
>    every override of `@trussworks/react-uswds` / `@uswds/uswds` defaults. Reproduce this and
>    the dashboard *looks* identical.
> 2. **The Axios API client** — base URL, auth header injection, the error-normalization
>    interceptor, the 265 typed endpoint functions, demo-mode interception, blob downloads,
>    and `sendBeacon` telemetry.
> 3. **Fixtures / config** — `glossary.ts`, `gateConsequences.ts`, the cATO fixture, and the
>    `data/` stub helpers.
>
> **Companion docs.** Pages/routes/components (props, state) are spec'd in `regen/05-dashboard-*`
> companion files (App.tsx routing summarized in §1.4 here for completeness). Backend endpoint
> bodies are in `regen/01-api*.md` — cross-referenced per endpoint in §2.
>
> **Citation convention.** `path:line`. All paths absolute. ⚠️ GOTCHA marks fragile/non-obvious
> behavior that WILL break parity if reproduced naively.

---

## 0. Tech Stack & Build Wiring (reproduce exactly)

`dashboard/package.json` (`/Users/pnunna/Documents/GitHub/foundry/dashboard/package.json:21-73`):

```jsonc
"dependencies": {
  "@tanstack/react-query": "^5.101.0",   // server-state cache (useQueries.ts)
  "@tanstack/react-table": "^8.21.3",    // DataGrid
  "@trussworks/react-uswds": "^11.0.1",  // React USWDS component lib
  "@types/react-syntax-highlighter": "^15.5.13",
  "@uswds/uswds": "^3.13.0",             // USWDS CSS + tokens (Sass compiled to css/uswds.css)
  "@xyflow/react": "^12.11.0",           // node-graph pipeline viz (React Flow)
  "axios": "^1.17.0",                    // API client transport
  "dompurify": "^3.4.10",                // sanitize markdown HTML
  "focus-trap-react": "^12.0.2",         // modal focus trap (also pinned as USWDS override)
  "jszip": "^3.10.1",                    // client-side zip (bundle artifacts)
  "mermaid": "^11.15.0",                 // diagram rendering in artifact viewer
  "react": "^19.2.7",
  "react-dom": "^19.2.7",
  "react-markdown": "^10.1.0",
  "react-router-dom": "^7.17.0",         // routing (BrowserRouter)
  "react-syntax-highlighter": "^16.1.1", // code blocks in viewers
  "recharts": "^3.8.1",                  // all charts (themed via useChartTheme)
  "remark-gfm": "^4.0.1",                // GitHub-flavored markdown tables
  "sonner": "^2.0.7"                     // toast notifications
}
```

⚠️ **GOTCHA — `overrides` block is required** (`package.json:42-49`): npm `overrides` pins
`eslint-plugin-react-hooks`→`$eslint` and forces `@trussworks/react-uswds`'s transitive
`focus-trap-react` to the root `$focus-trap-react` (v12). Omitting this lets react-uswds pull an
older focus-trap that conflicts with React 19 and breaks every modal.

Build: Vite 8 + `@vitejs/plugin-react`. `"build": "tsc -b && vite build"` (`package.json:8`).
TypeScript `~6.0.3`. Tests: Vitest 4 + jsdom 29 + Testing Library; Playwright 1.60 for e2e/visual/a11y.

**Environment variables** (`dashboard/src/vite-env.d.ts`, `dashboard/.env.example`):

| Var | Default | Purpose |
|---|---|---|
| `VITE_API_BASE_URL` | `http://localhost:8000` | Axios base URL (`client.ts:9-10`) |
| `VITE_WS_BASE_URL` | `ws://localhost:8000` | WebSocket base (`useWebSocket.ts`) |
| `VITE_LEGACY_PIPELINE_VIZ` | (unset)→V2 graph | Feature flag: legacy pipeline viz vs `@xyflow/react` node graph |
| `VITE_DEMO_MODE` | (unset)→live | Recording-safe mode (toast suppression, frozen clock, fixture interception, polling pause) — see §2.7 |

---

## 1. USWDS DESIGN SYSTEM

### 1.1 How USWDS is imported & initialized

**Entry chain:** `index.html` → `main.tsx` → `styles/index.css`.

`dashboard/index.html:1-13` — minimal HTML shell. `<html lang="en">`, viewport meta, inline SVG
favicon (a rounded-rect `#005ea2` USWDS-blue badge with white "O"), title **"Olympus Dashboard"**,
`<div id="root">`, ESM entry `/src/main.tsx`.

`dashboard/src/main.tsx:1-13`:
```tsx
import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import App from "./App";
import "./styles/index.css";          // ← single CSS entrypoint

const rootElement = document.getElementById("root");
if (!rootElement) throw new Error("Root element not found");
createRoot(rootElement).render(<StrictMode><App /></StrictMode>);
```

⚠️ **GOTCHA — no USWDS JS init.** The dashboard imports **only USWDS CSS** (`@uswds/uswds/css/uswds.css`,
see §1.2). It does **not** call `@uswds/uswds`'s JS `init()`. All interactive USWDS behavior
(accordions, modals, comboboxes) comes from `@trussworks/react-uswds` React components, not the
vanilla USWDS JS. Do **not** add a `uswds.min.js` init script — it will double-bind event handlers.

**CSS manifest** — `dashboard/src/styles/index.css` (full file, `:1-14`):
```css
@import "./base.css";
@import "./layout.css";
@import "./components.css";
@import "./gate-review.css";
@import "../components/GateReviewCards/GateReviewCards.css";
@import "./app-detail.css";
@import "./chat.css";
@import "./assembly-lines.css";
```
⚠️ **Import order is load-bearing.** `base.css` imports `uswds.css` FIRST (line 6 below), so every
subsequent partition can override USWDS rules by specificity/cascade. Reordering breaks the overrides.

### 1.2 Font + USWDS CSS import (`base.css:6-7`)

```css
@import "@uswds/uswds/css/uswds.css";
@import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;900&display=swap');
```
- **USWDS 3.13 compiled CSS** is the foundation layer (resolved from `node_modules/@uswds/uswds/css/uswds.css`).
- **Inter** is the brand font, loaded from Google Fonts CDN at weights 400/500/600/700/900.
  ⚠️ GOTCHA: this is a **runtime network dependency**. Offline/air-gapped builds fall back to the
  system stack in the `body` rule below.

### 1.3 Design Tokens — CSS Custom Properties (`base.css:9-46`)

The entire palette is a small set of CSS variables on `:root`, overridden under `[data-theme="dark"]`.
**Reproduce these byte-for-byte** — every component references them.

#### Light theme (`:root`, `base.css:10-29`)

| Token | Value | Role |
|---|---|---|
| `--olympus-primary` | `#211D1E` | Near-black brand ink; headings, top-nav bg, primary text |
| `--olympus-teal` | `#177480` | Primary brand teal; sidebar active, tabs, score-bar start |
| `--olympus-cyan` | `#23D2D7` | Bright cyan accent; brand icon, nav underline, score-bar end |
| `--olympus-accent` | `#00A5B5` | Mid teal-cyan; card top-border, links, focus rings |
| `--olympus-gate` | `#6B4FBB` | Violet reserved for gate phase boundaries (no status uses it) ⚠️ deliberately distinct from all workflow-status colors |
| `--olympus-bg` | `#F2F7F7` | Pale teal-grey page background |
| `--olympus-bg-card` | `#ffffff` | Card / panel surface |
| `--olympus-text` | `#211D1E` | Body text |
| `--olympus-text-light` | `#464646` | Muted/secondary text, labels |
| `--olympus-text-inverse` | `#ffffff` | Text on dark surfaces (top-nav) |
| `--olympus-border` | `#E8E8E8` | Hairline borders, dividers |
| `--olympus-shadow` | `0 1px 3px rgba(0,0,0,0.12), 0 1px 2px rgba(0,0,0,0.06)` | Resting card shadow |
| `--olympus-shadow-md` | `0 4px 6px rgba(0,0,0,0.07), 0 2px 4px rgba(0,0,0,0.06)` | Hover/elevated shadow |
| `--olympus-radius` | `8px` | Global corner radius |
| `--olympus-sidebar-width` | `240px` | Sidebar + top-nav navbar width |
| `--olympus-topnav-height` | `56px` | Header height (drives `calc()` layout height) |

#### Dark theme (`[data-theme="dark"]`, `base.css:32-46`) — overrides only

| Token | Dark value |
|---|---|
| `--olympus-primary` | `#ffffff` |
| `--olympus-teal` | `#23D2D7` |
| `--olympus-cyan` | `#5CE0E4` |
| `--olympus-accent` | `#23D2D7` |
| `--olympus-gate` | `#B49CF0` |
| `--olympus-bg` | `#161213` |
| `--olympus-bg-card` | `#211D1E` |
| `--olympus-text` | `#E8E8E8` |
| `--olympus-text-light` | `#999999` |
| `--olympus-text-inverse` | `#000000` |
| `--olympus-border` | `#352F30` |
| `--olympus-shadow` | `0 1px 3px rgba(0,0,0,0.4), 0 1px 2px rgba(0,0,0,0.3)` |
| `--olympus-shadow-md` | `0 4px 6px rgba(0,0,0,0.35), 0 2px 4px rgba(0,0,0,0.3)` |

⚠️ Dark mode does **not** redefine `--olympus-radius`, `--olympus-sidebar-width`, or
`--olympus-topnav-height` — they inherit from `:root`.

#### Theme application mechanism (`hooks/useTheme.ts`)
- `data-theme` attribute is set on `document.documentElement` (`<html>`), NOT body.
- Persisted in `localStorage` key **`olympus-theme`** (`useTheme.ts:10`). Values `"light"|"dark"`.
- ⚠️ **GOTCHA — flash-of-wrong-theme prevention** (`useTheme.ts:22-24`): the initial theme is read
  and applied to `<html>` **at module-load time**, *before* React renders. Reproduce this top-level
  side effect or the page flashes light-then-dark on dark-mode reload.
- `useTheme()` returns `{ theme, toggle }`; `toggle` flips light↔dark and re-persists (`:38-42`).
- Default when no storage / storage throws: `"light"` (`:12-20`).

#### Recharts color themes (`hooks/useChartTheme.ts`)
⚠️ **GOTCHA — Recharts cannot read CSS variables.** Recharts paints inline SVG `fill`/`stroke`
attributes, so it cannot consume `var(--olympus-*)`. A parallel JS palette exists. `useChartTheme()`
(`:66-69`) returns `DARK_THEME` when `useTheme().theme === "dark"`, else `LIGHT_THEME`.

`ChartTheme` interface (`useChartTheme.ts:9-34`): `{ primary, accent, series[], grid, text, tooltipBg, tooltipText, background, success, warning, error, muted }`.

`LIGHT_THEME` (`:36-49`):
```
primary "#177480", accent "#23D2D7",
series ["#177480","#23D2D7","#00A5B5","#5B9BD5","#8B5CF6","#F59E0B","#EF4444"],
grid "#E8E8E8", text "#464646", tooltipBg "#ffffff", tooltipText "#211D1E",
background "transparent", success "#00A91C", warning "#FFBE2E", error "#D54309", muted "#A9AEB1"
```
`DARK_THEME` (`:51-64`):
```
primary "#23D2D7", accent "#177480",
series ["#23D2D7","#00A5B5","#5B9BD5","#8B5CF6","#F59E0B","#EF4444","#177480"],
grid "#3A3334", text "#C4C0C1", tooltipBg "#2A2526", tooltipText "#E8E8E8",
background "transparent", success "#4ADE80", warning "#FBBF24", error "#F87171", muted "#6B6566"
```

### 1.4 Base resets, typography & shared primitives (`base.css`)

- **`body`** (`:49-53`): `font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;`
  `background: var(--olympus-bg); margin: 0;`. Dark: `[data-theme="dark"] body { color: var(--olympus-text); }` (`:55-57`).
- **`.usa-skipnav:focus`** (`:60-62`): `z-index:10000` so the USWDS skip-nav link sits above all chrome.
- **`h1`** (`:65-69`): `1.75rem`, `color: var(--olympus-primary)`, `margin-bottom:1rem`. Dark→`#ffffff`.
- **`h2`** (`:71-77`): `1.25rem`, `var(--olympus-primary)`, `padding-bottom:8px`, **`border-bottom:2px solid var(--olympus-accent)`** (the signature section-underline), `margin-bottom:1rem`. Dark→white text, accent border kept.
- **`.empty-state`** (`:89-102`): centered `48px 24px` padding, muted text, white bg, radius, resting shadow. `p` is `0.9rem`, max-width `36rem`, centered.
- **`.usa-alert--info`** (`:110-112`): override USWDS info-alert left border to `var(--olympus-accent)`. Dark variant tints bg `rgba(23,116,128,0.15)`, border cyan.
- ⚠️ **GOTCHA — visited links pinned** (`base.css:119-126`): `a:visited { color: #005ea2; }`. USWDS's
  default visited purple (`#54278f`) reads as "stale" in a dashboard that revisits the same entity
  repeatedly (issue #264). Visited = unvisited USWDS blue. Dark mode: all `a`/`a:hover`/`a:visited`
  forced to cyan `#23D2D7`/`#5CE0E4` (`:129-139`). More-specific rules (e.g. `.dg-entity-link:visited`) still win.
- **Onboarding/discovery forms** (`:142-188`): `.onboarding-form`, `.form-field`, `.form-actions`,
  `.discovery-action` — card-surfaced forms, max-width `36rem`, `.usa-hint` is `0.8rem` muted.
- **`.placeholder-page`** (`:191-204`) and **`.skill-edit-form`** input max-width clamp (`:207-211`).
- ⚠️ **GOTCHA — USWDS search-input normalization** (`base.css:213-228`): USWDS ships
  `[type="search"]` with `float:left; max-width:480px` (meant for `.usa-search` composites). A bare
  `<TextInput type="search">` outside `.usa-search` collapses its wrapper and clips. The override
  `.usa-input[type="search"]:not(.usa-search .usa-input)` neutralizes float/max-width, removes radius,
  sets `border-right:1px solid #565c65`, `height:2.5rem`, `box-sizing:border-box`. Reproduce verbatim.
- **Responsive** (`:231-235`): `@media (max-width:1024px) { .olympus-main { padding:20px; } }`.

### 1.5 Layout shell — header, sidebar, breadcrumbs (`layout.css`)

This is the **FAA/USWDS branding chrome**. Reproduce precisely for visual parity.

#### Top nav / header (`layout.css:7-89`)
- **`.usa-header`** (`:7-10`): `background: var(--olympus-primary) !important;` (near-black `#211D1E`),
  `box-shadow:0 2px 8px rgba(0,0,0,0.2)`. ⚠️ The `!important` is required to beat USWDS's white header.
- `.usa-nav-container` (`:12-17`): `max-width:none; margin:0; padding:8px 0; align-items:center!important`
  — full-bleed, not the USWDS centered grid.
- `.usa-navbar` (`:19-24`): width pinned to `var(--olympus-sidebar-width)` (240px) so the logo block
  aligns over the sidebar; `border-bottom:none; flex-shrink:0; padding-left:16px`.
- Logo text (`:35-42`): `color: var(--olympus-text-inverse)!important; font-weight:700; font-size:1.2rem; text-decoration:none`.
- Nav links (`:48-65`): label spans `rgba(255,255,255,0.7)`, `0.875rem`, weight 500; hover/current→`#fff`;
  the USWDS active-underline `::after` recolored to `var(--olympus-cyan)!important`.
- **`.olympus-brand-icon`** (`:68-79`): 36×36 `var(--olympus-cyan)` rounded (`8px`) square, inline-flex
  centered, `margin-right:10px` — the cyan "O" badge in the header.
- **`.olympus-brand`** (`:81-89`): flex row, `gap:10px`, inverse text, weight 700, `1.2rem`.

#### Portfolio picker + profile badge (header-right) (`layout.css:91-216`)
- `.portfolio-picker--single` (`:97-104`): pill of `rgba(255,255,255,0.08)`, `0.8rem` semibold,
  `rgba(255,255,255,0.85)`.
- `.portfolio-picker__select` (`:106-129`): translucent `<select>`, `1px rgba(255,255,255,0.15)` border,
  `appearance:auto`, max-width 200px ellipsized; focus outline `2px solid var(--olympus-accent)`;
  `option` forced to dark-on-white (so the native dropdown is readable).
- `.active-profile-badge` (`:141-171`): read-only inline pill, uppercase `0.7rem` label + `0.8rem` value,
  translucent bg+border. `--loading` variant min-width `8rem`, fainter bg.
- `.header-right-group` (`:179-185`): `margin-left:auto`, `gap:0.5rem`, `padding-right:1rem` — right cluster.
- **`.connection-indicator`** (`:188-216`): WebSocket status pill, `rgba(255,255,255,0.7)`, rounded `20px`,
  translucent border. `.connection-dot` 0.5rem circle; `--connected` green `#22c55e` with glow,
  `--disconnected` red `#ef4444`.

#### Layout grid + sidebar (`layout.css:218-335`)
- **`.olympus-layout`** (`:219-223`): `display:flex; height: calc(100vh - var(--olympus-topnav-height)); overflow:hidden`.
- **`.olympus-sidebar`** (`:226-237`): width `var(--olympus-sidebar-width)`, white bg, right hairline border,
  `padding:16px 0 0`, `transition: width 0.2s ease`, flex-column. ⚠️ `--collapsed` modifier (`:298-314`)
  forces width `56px!important`, hides section titles + link text, centers icons.
- `.usa-sidenav a` overrides (`:249-280`): `padding:8px 16px; font-size:0.85rem; color:var(--olympus-text); border-left:3px solid transparent; flex; gap:10px`.
  - Hover (`:261-265`): bg `#F2F7F7`, text+left-border `var(--olympus-teal)`.
  - **Active** `.usa-current` (`:267-272`): bg `#e0f2f3`, text `var(--olympus-teal)`, weight 600, left-border teal; USWDS's `::after` active marker hidden (`:274-276`).
- `.sidebar-section-title` (`:283-295`): uppercase `0.7rem` weight 700, letter-spacing `0.08em`, muted, group label.
- `.sidebar-collapse-toggle` (`:317-335`): bottom-pinned button, top hairline, hover→teal text + bg.
- `.sidebar-icon` (`:400-415`): 24×24 inline-flex badge, `0.7rem` semibold muted; `.sidebar-link-with-icon` flex+gap.

#### Main content + breadcrumbs + theme toggle (`layout.css:337-397`)
- **`.olympus-main`** (`:338-344`): `flex:1; min-width:0; padding:24px 32px; background:var(--olympus-bg); overflow-y:auto` — the scroll container.
- **`.olympus-breadcrumbs.usa-breadcrumb`** (`:347-371`): transparent bg, bottom hairline, `0.8rem`
  items, muted links, teal hover; last-child/current stays muted weight-400 (no bold "you are here").
- **`.theme-toggle`** (`:374-397`): translucent rounded-`20px` button, `rgba(255,255,255,0.7)`,
  `0.75rem`; hover→cyan border+text. `.theme-icon` `0.85rem`.

#### Dark-mode layout overrides (`layout.css:423-501`)
- `.usa-header`→`#161213!important` with `border-bottom:1px solid #177480` (`:424-427`).
- Sidebar→`#161213`, border `#352F30`; links `#CCCCCC`; hover bg `#2A2526` cyan; active bg `rgba(23,116,128,0.2)` cyan (`:437-456`).
- Theme toggle, collapse toggle, breadcrumbs, brand, sidebar icons all retinted (`:429-494`).
- **Responsive** (`:497-501`): `@media (max-width:1024px) { .olympus-sidebar { display:none; } }`.

### 1.6 Shared components (`components.css`)

#### Utilities
- ⚠️ **`.cursor-link`** (`components.css:19-33`): the canonical "interactive but NOT a link" primitive
  for chevrons/toggles/disclosure triggers. `cursor:pointer; color:inherit; text-decoration:none;
  background:transparent; border:none; padding:0; font:inherit`. Pairs with a `:focus-visible` outline
  (`2px solid var(--olympus-accent,#005ea2)`, offset 2px, radius 2px). **Design rule (P5-S18):
  underline is reserved for real `<a href>` navigation only.** Reproduce this convention across the app.

#### Stat cards (`.usa-card__*`) (`components.css:36-75`)
- ⚠️ **Heavy USWDS card override** (`:36-47`): `.usa-card__container` gets `border-radius:var(--olympus-radius)!important`,
  `box-shadow:var(--olympus-shadow)!important`, `border:none!important`, **`border-top:3px solid var(--olympus-accent)!important`**
  (the signature accent top-stripe), hover lift `translateY(-2px)` + `--olympus-shadow-md`. All `!important` (beats USWDS).
- `.usa-card__heading` (`:49-55`): `0.85rem!important`, muted, weight 500, uppercase, letter-spacing.
- `.stat-value` (`:57-62`): `2.5rem` weight 700 primary, `line-height:1`. Dark→`#23D2D7`.

#### Status badges (`components.css:78-106`)
`.status-badge` base (`:78-86`): inline-block `0.75rem` weight 600, `padding:2px 10px`, `border-radius:12px`, UPPERCASE, letter-spacing `0.03em`. Per-status (light):

| Modifier | bg | color |
|---|---|---|
| `--pending` | `#FEF3C7` | `#92400E` |
| `--approved` / `--complete` | `#dcfce7` | `#166534` |
| `--rejected` / `--failed` | `#fee2e2` | `#991b1b` |
| `--active` | `#e0f2f3` | `var(--olympus-teal)` |
| `--onboarded` | `#e0e7ff` | `#3730a3` |
| `--in-progress` | `#dbeafe` | `#1e40af` |
| `--escalated` | `#fef3c7` | `#92400e` |

Dark variants (`:98-106`) use `rgba(...,0.12–0.20)` tinted bg with brighter text (e.g. `--pending`→`#FCD34D`).

#### Assembly-line tags (`components.css:108-168`)
`.line-tag` base (`:109-115`): `0.75rem` weight 600, `border-radius:4px`, `padding:2px 10px`. Each of the
10+ lines has a `--<line>` (solid) and `--<line>-step` (lighter) pair. **Light palette (memorize the line→hue mapping):**

| Line | `--<line>` bg/color | `--<line>-step` bg/color |
|---|---|---|
| discovery (teal) | `#ccfbf1`/`#115e59` | `#e6faf6`/`#1a7a72` |
| rationalization (indigo) | `#e0e7ff`/`#3730a3` | `#eef2ff`/`#4f46e5` |
| architecture (blue) | `#dbeafe`/`#1e40af` | `#eff6ff`/`#2563eb` |
| data (cyan) | `#cffafe`/`#155e75` | `#e4fdff`/`#0e7490` |
| modernization (violet) | `#ede9fe`/`#5b21b6` | `#f5f3ff`/`#7c3aed` |
| disposition-execution (amber) | `#fef3c7`/`#92400e` | `#fefce8`/`#a16207` |
| validation (emerald) | `#d1fae5`/`#065f46` | `#ecfdf5`/`#059669` |
| deployment (slate) | `#e2e8f0`/`#334155` | `#f1f5f9`/`#475569` |
| sustainment (rose) | `#ffe4e6`/`#9f1239` | `#fff1f2`/`#be123c` |
| governance (gold) | `#ffedd5`/`#9a3412` | `#fff7ed`/`#c2410c` |

Dark variants (`:149-168`): `rgba(<hue>,0.18)`/`0.10` tints with light text. ⚠️ This 10-line color
system is referenced from `assembly-lines.css` icons and across page components — keep hue assignments stable.

#### Tables (`components.css:170-202`)
- `.usa-table` (`:171-179`): radius, `1px var(--olympus-border)`, resting shadow, `border-collapse:separate; border-spacing:0`, card bg, `overflow:hidden`.
- ⚠️ **Header override** (`:181-190`): `thead th { background-color:#1b3a5c !important; color:#fff !important; }` —
  a **dark navy** header bar (NOT a USWDS token), `0.8rem` UPPERCASE weight 600. The `!important` and the
  literal `#1b3a5c` are required. Corner radii rounded on first/last header cells (`:192-193`).
- Body cells `0.875rem` with top hairline; bottom corner radii on last row; hover row bg `#F5F7FA` (`:194-197`).
- Dark (`:199-202`): table border `#352F30`, **header stays `#1b3a5c`** (text `#e0e0e0`), hover `#2A2526`.

#### DataGrid (TanStack Table wrapper) (`components.css:204-281`)
- `.datagrid-container` (`:205`): radius + overflow hidden.
- `.datagrid-pagination` (`:208-247`): space-between bar, `0.82rem` muted; `__btn` 2rem square outlined buttons,
  hover→teal-filled, `:disabled` opacity 0.35; `__page` semibold.
- ⚠️ **`.dg-entity-link`** (`:250-262`): the canonical in-grid entity link — weight 600, **`border-bottom:1.5px solid var(--olympus-accent)`** (underline-as-border, not text-decoration), `:visited` stays `var(--olympus-text)` (overrides the global `#005ea2`), hover→accent. This is why grid links look different from body links.
- `.dg-action-btn` (`:265-281`): outlined pill action buttons; `--review` (accent) and `--view` (teal) fill on hover.

#### Score bars (`components.css:283-290`)
`.score-bar` flex row; `__label` 10rem muted; `__track` 0.625rem `#e5e7eb` pill; **`__fill` `linear-gradient(90deg, var(--olympus-teal), var(--olympus-cyan))`** with width transition; `__value` 3rem right-aligned bold. Dark track→`#352F30`.

#### Tab navigation (`components.css:292-328`)
`.tab-nav` flex with `2px var(--olympus-border)` bottom border. `.tab-nav__tab` borderless, `0.85rem` weight 500, muted, `margin-bottom:-2px` (overlaps the rail). `--active` → teal text + `2px` teal bottom-border + weight 600. `.tab-panel` min-height 200px.

#### Chart cards + widget grids (`components.css:330-408`)
- `.chart-card` (`:331-342`): card-surfaced, radius, `1px` border, resting shadow, `padding:20px`, hover lift.
- `.chart-card__header` (`:344-349`) flex space-between; `__title` `0.85rem` weight 600 UPPERCASE muted; `__value` 2rem bold; `__subtitle` `0.8rem` muted.
- **`.widget-grid`** (`:375-400`): CSS Grid, `gap:20px`. Modifiers: `--2col`/`--3col`/`--4col`
  (`repeat(N,1fr)`), `--metrics` (`repeat(auto-fit, minmax(180px,1fr))`). 3/4-col & metrics center their card content.
- **Responsive** (`:386-400`): ≤1200px→4col/3col collapse to 2col; ≤768px→all to 1col, metrics to 2col; ≤480px→metrics to 1col.
- `.recharts-responsive-container { min-height:0; }` (`:403`) — required so Recharts shrinks inside grid cells.

### 1.7 Gate review surfaces (`gate-review.css`, 1230 lines)

Powers `pages/GateReview.tsx` + evidence/decision panels. Key structures:

- **`.gate-review-layout`** (`:45-50`): CSS Grid `320px 1fr`, `gap:1.5rem`, `min-height:60vh`. Left
  column (`:52-59`) is sticky, max-height `calc(100vh - 200px)`. ⚠️ Responsive (`:1221-1229`): ≤1024px
  collapses to single column, left becomes static.
- **`.gate-review-header__subject`** (`:21-32`): the wave/app subject promoted from inline `<strong>` to a `1.35rem` weight-600 heading; `__subject-label` muted.
- **Evidence panel** (`:66-313`): card surface, scrollable. `.evidence-item` (`:95-145`) left-border-accent rows with hover/active teal states + truncating titles. `.evidence-item__type--file` blue pill. Progress bar `__progress*` (`:147-172`) teal fill. Collapsible `<details>` groups `.evidence-group*` (`:181-249`) with a CSS chevron (`::before content:"\25B6"` rotating 90° when `[open]`, `:208-218`) — webkit marker hidden. Checkboxes `.evidence-item__checkbox` use `accent-color:var(--olympus-teal)`; reviewed items get `line-through` + opacity (`:265-275`).
- **Decision panel** (`:316-352`): card; `__notes textarea` full-width min-80px; `__actions` flex-wrap; `__success` green `#166534`.
- **Viewer area** (`:355-509`): card min-height 400px; `.viewer-nav` header (also re-declared `:1179-1183` as flex+gap — the later wins); `.viewer-nav__position` muted. **`.viewer-pager`** (`:392-476`) is a **sticky bottom** pagination strip (round arrow buttons + dot indicators; current dot teal-filled with ring, done dots teal). `.file-viewer__*` (`:478-509`): mono path with `#005ea2` left-border, `#f0f0f0` content well.
- **Skeleton loading** (`:511-547`): `@keyframes shimmer` (`-200%`→`200%` bg-position) + `.skeleton` gradient (border→white→border), `.skeleton-text--short/medium/long` (40/65/90% width), `.skeleton-viewer` 400px. Dark variant retints the gradient.
- **Previous attempts** (`:549-597`): amber-left-border (`#f59e0b`) recap card. Dark→amber tint.
- **Modals** (`:599-636`): `.confirm-modal-overlay` fixed `inset:0` `rgba(0,0,0,0.5)` `z-index:2000`; `.confirm-modal` card max-`28rem`, `box-shadow:0 8px 30px rgba(0,0,0,0.25)`. `CreateModal` reuses this shell with `.create-modal__header/__subheading` (`:643-658`).
- ⚠️ **Agent-errors link** (`:660-674`): `.gate-review-header__agent-errors` uses the danger palette `#d54309`/`#b03a00` and **keeps its underline** (it IS a real anchor — F6 rule). Contrast with `.cursor-link`.
- **Gate-queue empty state** (`:676-714`): `.gate-queue-empty*` composite block (heading/body/note/actions).
- **AI recommendation banner + modal** (`:905-1056`): `.ai-recommendation-banner` flex content + outlined `__action` button; `.ai-recommendation-modal` flex-column card max-`48rem`, `max-height:85vh`, scrolling `__content`. Heading border-bottom recolors by severity: `--success #00a91c`, `--warning #ffbe2e`, `--error #d83933`, `--info` border token (`:1014-1025`).
- **Consequence banner** (`:1058-1135`): `.consequence-banner` card with `4px` accent left-border, renders `GATE_CONSEQUENCES` copy (§3.2). `__chip--approve` green `#047857`, `__chip--reject` red `#b91c1c` pills.
- **Ask-AI button** (`:1137-1177`): `.ask-ai-button` outlined accent button, fills on hover; `--panel` full-width, `--viewer` `margin-left:auto`.
- **Approve/escalate reason pickers** (`:1185-1218`): `.decision-summary__approve-reason*` / `__escalate-reason*` fieldset legends + wrap option rows.
- ⚠️ **Dark-mode viewer overrides** (`:716-903`): an extensive block forcing USWDS utility bgs (`.bg-base-lightest`/`.bg-base-lighter`→`#1E1A1B!important`), `pre`/`code`/tables/`.usa-tag` inside `.viewer-area` to dark-safe colors. Required because viewer renders arbitrary markdown/HTML artifacts that ship light-mode USWDS utility classes. Many use `!important`.

### 1.8 GateReviewCards (`components/GateReviewCards/GateReviewCards.css`, 712 lines)

⚠️ Imported from `index.css:10` (NOT under `styles/`). Card-per-check gate review (W8/P5-S9).
- ⚠️ **F6 underline strip** (`:28-38`): `.gate-review-cards .usa-button--unstyled` (and `.gate-review-card`)
  forced `text-decoration:none` (incl. hover/focus). USWDS `Button unstyled` inherits underline from the
  `typeset-link` mixin; every unstyled button here is a toggle/sort/disclosure, not navigation. Real anchors keep underline.
- `.gate-review-cards__ai-banner` (`:41-48`): `rgba(0,80,216,0.08)` bg with `4px #0050d8` left-border.
- `.gate-review-cards__toolbar` (`:51-102`): card bar, sort buttons (`--active` blue-tinted), progress text.
- `.gate-review-cards__escalate` (`:105-113`): `#d9ca4a` border + `rgba(255,190,46,0.08)` warning panel.
- **`.gate-review-card`** (`:143-169`): card, radius 6px, **`4px solid transparent` left-border** recolored by status; hover shadow bump. Status left-borders (`:171-193`): `--approved #00a91c`, `--rejected #d54309`, `--escalated #ffbe2e`, `--pending/--preparing #a9aeb1`, `--in_review #0050d8` (USWDS system colors, not olympus tokens).
- `.gate-review-card__header-toggle` (`:207-229`): full-row clickable, `rgba(0,80,216,0.06)` hover, focus outline `2px #005ea2`. `__chevron` (`:231-242`) rotates/recolors blue when expanded.
- **`.gate-review-card__status`** pill (`:278-319`): per-status bg/color/border tints (preparing grey, in_review blue, approved green, rejected `#d54309`, escalated `#8a6300`).
- **`.gate-review-card__severity`** badge (`:322-349`): `--critical #d54309`, `--high #8a6300`, `--medium #0050d8`, `--low #565c65` — uppercase pills.
- `.gate-review-card__summary` (`:384-399`): 2-line clamp (`-webkit-line-clamp:2` + `line-clamp:2`); `--expanded` removes the clamp.
- Decision zone (`:402-512`): collapsed actions space-between; expanded `__decision-zone` stacks evidence→note→buttons. ⚠️ F7 reading order: evidence first, decide after. Approve `--active` green, reject `--active` `#d54309` on white.
- ⚠️ **F4 inline required reject note** (`:514-539`): `.gate-review-card__reject-note` is **pinned/non-collapsible** (`#d54309` border, tinted bg) — reproduce so reviewers can't lose the field.
- Dialog field styles `.gate-review-dialog__*` (`:546-592`) shared by Approve/Reject dialogs (tips `<details>` disclosure blue summary).
- Supporting-artifacts nested accordion `.gate-review-card__supporting*` (`:627-712`).
- **Responsive** (`:595-625`): ≤720px stacks toolbar/actions; ≥1280px widens cards (`padding:1rem 1.25rem`).

### 1.9 App detail (`app-detail.css`, 210 lines)

`pages/ApplicationDetail.tsx` chrome. `.app-detail-header` (`:7-13`) card. `__top`/`__title-row`/`__actions`
flex rows (`:16-35`). **Metrics strip** `.app-detail-metric*` (`:38-78`): bordered `var(--olympus-bg)` tiles,
`0.65rem` uppercase label + `1rem` bold value; `--score` value tinted teal. Repo cards `.app-detail-repo-card`
(`:105-127`) bordered tiles with uppercase label + break-all url; `.app-detail-repos-toggle` accent text button.
Edit form 2-col grid `.app-detail-edit-grid` (`:134-159`) with `--full` (`grid-column:1/-1`) + fieldset/legend.
**Discovery banner** `.discovery-banner` (`:162-209`): flex callout with `1px` border, `--onboarded` (accent
tint), `--error` (`#ef4444`), `--stalled` (`#f59e0b`) variants; dark deepens the tints.

### 1.10 Chat (`chat.css`, 322 lines)

Floating "Ask Agent" assistant. `.chat-fab` (`:7-17`): fixed bottom-right `z-index:900`, rounded-`24px` pill,
shadow. **`.chat-drawer`** (`:20-35`): fixed bottom-right `z-index:1000`, `32em × 42em` (max `calc(100vh - 5em)`),
flex-column card, `box-shadow:0 8px 30px rgba(0,0,0,0.2)`. ⚠️ GOTCHA: drawer dimensions are in **`em`**, not
`rem`/`px` — they scale with the drawer's own font-size. Header (`:37-88`) with clear/close icon buttons.
`.chat-panel` (`:91-133`) flex-column; `__messages` scroll region; `__suggestion` accent text button.
**Messages** (`:136-249`): `.chat-message` radius card; `--reviewer` teal-tinted with `3px` teal left-border;
`--agent` `var(--olympus-bg)` with border left-border. `__body` (`:165-244`) has a full markdown typography
reset (headings, lists, tables w/ borders, blockquote teal bar+tint, inline `code` chip, `pre` block, `hr`).
`__typing` italic muted. `.chat-panel__input` (`:251-277`) bottom textarea with teal focus outline. Dark
overrides (`:279-321`).

### 1.11 Assembly lines (`assembly-lines.css`, 838 lines)

Per-line dashboards + spotlight visualizations (`pages/AssemblyLines`). Highlights:
- `.line-dashboard__icon` (`:18-29`): 40×40 rounded-`10px` white-on-color line badge (color set inline per line from the §1.6 palette).
- `.line-sla-tag` (`:31-52`): outlined `currentColor` SLA pill. `.line-tag--attention` (`:54-62`) amber.
- **Kanban board** (`:65-138`): `.kanban-board` horizontal-scroll flex; `.kanban-column` min-160px bordered, accent top-border header; `.kanban-card` small bordered tile; `--empty` dashed italic placeholder.
- **Gate queue** (`:140-193`): `.gate-queue__item` bordered rows, `--overdue` red left-border; `__gate` is **monospace bold** (`ui-monospace,SFMono-Regular,Menlo`).
- **Risk pills** (`:195-211`): `.risk-pill--tier1` red `#fee2e2`/`#991b1b`, `--tier2` amber, `--tier3` blue `#e0f2fe`/`#0369a1`. Dark tints.
- **Activity feed** (`:213-275`): `.activity-feed__item` hairline rows; `--escalation` red gradient wash, `--gate` green gradient wash.
- **Spotlight grids** (`:277-310`): `.spotlight-grid--1-1` / `--2-1` two-column layouts collapsing ≤900px.
- Per-line spotlight blocks (each a distinct visualization): Discovery passes/readiness buckets (`:312-382`), Rationalization overlap-bar + disposition-mix (`:384-440`), Data domain-grid (tier-colored left-borders) + ownership rows (`:442-502`), Modernization Ralph KPIs (`:504-534`), Disposition execution tiles + runbook steps (`:536-620`), Validation parity grid/bar with good/warn/bad colors `#10B981`/`#F59E0B`/`#DC2626` (`:622-668`), Deployment canary banner + wave ladder (`:670-729`), Sustainment SLO pills + rings (`:731-764`), Governance pattern library (`:766-802`). `.line-empty` italic placeholder (`:804-810`). Dark touch-ups (`:812-837`).

### 1.12 USWDS override inventory (⚠️ the fragile bits)

A single consolidated list of where Olympus deviates from stock USWDS — reproduce ALL or the look drifts:

| Override | File:line | What/why |
|---|---|---|
| `.usa-header` bg→`#211D1E!important` | layout.css:7-10 | Dark top nav (USWDS default is white) |
| `.usa-card__container` border/shadow/radius + `3px` accent top-border, all `!important` | components.css:36-47 | Branded stat cards |
| `.usa-table thead th` bg→`#1b3a5c!important` color white | components.css:181-190 | Navy table headers |
| `a:visited`→`#005ea2` | base.css:124-126 | Kill USWDS stale-purple visited links |
| `.usa-input[type="search"]:not(.usa-search .usa-input)` float/max-width reset | base.css:219-228 | Fix bare search inputs clipping |
| `.usa-nav__link::after` underline→`var(--olympus-cyan)` | layout.css:59-61 | Cyan nav active marker |
| `.usa-sidenav a` padding/border-left/active rewrite | layout.css:249-276 | Left-accent sidenav |
| `.usa-alert--info` left-border→accent | base.css:110-112 | Branded info alert |
| `.usa-button--unstyled` underline strip (gate-review only) | GateReviewCards.css:28-38 | F6 underline-for-navigation-only |
| Dark-mode `.viewer-area` USWDS utility bg/`pre`/table/`tag` overrides (`!important`) | gate-review.css:716-903 | Dark-safe arbitrary-artifact rendering |

---

## 2. API CLIENT

Two source files: `dashboard/src/api/client.ts` (3656 lines, **265 exports**) and
`dashboard/src/api/bundlesApi.ts` (353 lines). All response types in `dashboard/src/types/api.ts`
(2194 lines) plus inline interfaces co-located in `client.ts`.

### 2.1 Axios instance, base URL, timeout (`client.ts:1-18`)

```ts
import axios from "axios";
import { getDemoFixture, isDemoMode } from "../demo-mode";

const API_BASE_URL = import.meta.env.VITE_API_BASE_URL ?? "http://localhost:8000";

const apiClient = axios.create({
  baseURL: API_BASE_URL,
  headers: { "Content-Type": "application/json" },
  timeout: 30_000,                       // 30s default
});
```
- Default base URL `http://localhost:8000` when env unset.
- Default timeout **30s** — overridden per-call only for uploads (10min, §2.5).
- `export default apiClient` (`:127`) — bundlesApi.ts and tests import it.

### 2.2 Auth token management + request interceptor (`client.ts:20-62`)

⚠️ **Auth model: JWT bearer in `localStorage`.**
- Storage key: **`olympus:auth:token`** (`client.ts:29`). (Distinct from the theme key `olympus-theme`.)
- `setAuthToken(token)` / `clearAuthToken()` / `getAuthToken(): string|null` (`:31-53`) — each wrapped in
  try/catch to swallow quota/privacy-mode errors (return null on read failure).
- **Request interceptor** (`:55-62`): reads `getAuthToken()`; if present, sets
  `config.headers.Authorization = \`Bearer ${token}\``. Applied to **every** request.
- Login flow calls `loginLocal()` then `setAuthToken(resp.access_token)`; logout calls `logoutSession()`
  which POSTs `/api/v1/auth/logout` (errors ignored) then `clearAuthToken()` (`:2046-2051`).

### 2.3 Error-normalization response interceptor (`client.ts:64-125`)

⚠️ **Single source of truth for error messages — reproduce the exact resolution order.** Every endpoint
function relies on this; callers `try/catch` and read `error.message`.

```ts
apiClient.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response) {
      const data = error.response.data;
      let detail: string | undefined;
      // 1. Olympus error envelope { error: { code, message, details } }
      if (data?.error?.message) detail = data.error.message;
      // 2. FastAPI default detail (string)
      else if (typeof data?.detail === "string") detail = data.detail;
      // 3. Generic message
      else if (typeof data?.message === "string") detail = data.message;
      // 4. Pydantic validation errors: detail = [{loc:['body','field'], msg, type}]
      else if (Array.isArray(data?.detail)) {
        detail = data.detail
          .map((e) => {
            const field = Array.isArray(e.loc) ? e.loc.filter(p => p!=="body").join(".") : "";
            return field ? `${field}: ${e.msg}` : e.msg;
          })
          .filter(Boolean).join("; ");
      }
      const msg = detail ? `${error.response.status}: ${detail}`
                         : `Server error (${error.response.status})`;
      return Promise.reject(new Error(msg));            // ← always rejects with an Error
    }
    if (error.request)                                   // no response (network down)
      return Promise.reject(new Error(`Unable to reach API at ${API_BASE_URL}. Is the server running?`));
    return Promise.reject(error);                        // setup error — passthrough
  },
);
```
⚠️ **GOTCHA — error messages are prefixed with the HTTP status** (e.g. `"404: ..."`, `"422: field: msg"`).
Several callers branch on this string: e.g. `fetchWaveArtifact` checks `err.message.startsWith("404:")`
to map 404→`null` (`:1298`). If you change the prefix format you break those callers.
- Maps to the FastAPI error envelope in `regen/01-api*.md` (the `{error:{code,message,details}}` shape from
  `olympus-api/src/errors`).

### 2.4 Endpoint-function conventions

Every typed helper follows one of these shapes (all `async`, all return the unwrapped `data`):
```ts
export async function fetchX(...): Promise<T> {
  const { data } = await apiClient.get<T>("/api/v1/...", { params });   // GET
  return data;
}
export async function doX(id, body): Promise<T> {
  const { data } = await apiClient.post<T>(`/api/v1/.../${id}`, body);  // POST/PATCH/PUT
  return data;
}
export async function deleteX(id): Promise<void> { await apiClient.delete(`/api/v1/.../${id}`); }
```
Conventions to reproduce:
- **All routes under `/api/v1/...`.** Path params interpolated; some use `encodeURIComponent(...)` (bundles,
  systems, governance — those touching free-form ids), most apps/waves do not (UUIDs).
- **Query params** passed via Axios `{ params }` (objects are serialized; `undefined`/absent keys dropped by
  the caller, e.g. `fetchPendingGates` builds a `Record` and conditionally adds `portfolio_id`, `:412-423`).
- **List endpoints return `PaginatedResponse<T>`** = `{ data: T[]; pagination: PaginationMeta }`
  (`api.ts:976-979`). Examples: `fetchApplications` (`:207-215`), `fetchPendingGates` (`:412-423`).
- **Some list endpoints unwrap a `{data:[...]}` envelope** themselves: `fetchRoles` returns `data.data`
  (`:2053-2058`). Reproduce per-endpoint.
- **404-to-null** pattern for "optional resource" reads: `fetchSourceArtifactsIndex` try/catch→`null`
  (`:397-410`); `fetchActiveProfile`→`null`; `fetchWaveArtifact`→`null` on `"404:"`.
- **Array-guard** on responses that must be arrays: `fetchApplicationGateEvidence` returns
  `Array.isArray(data) ? data : []` (`:469-476`); `fetchViewerAnalyticsSummary` guards `.sections` + `.total_events`.

### 2.5 Special transport cases (⚠️ reproduce exactly)

- **Multipart file upload** — `uploadApplicationZip` (`client.ts:588-618`): builds `FormData`
  (`name`, `file`, optional `description`/`portfolio_id`/`tags` as JSON), POSTs to
  `/api/v1/applications/upload` with `headers:{ "Content-Type":"multipart/form-data" }` and
  **`timeout: 10*60*1000`** (10min). ⚠️ Setting only the MIME type lets the browser/axios append the
  `boundary=...` — do not hardcode a full multipart header (drops the boundary, server fails to parse).
- **Blob download** — `downloadComplianceEvidence` (`:3376-3401`): GET
  `/api/v1/governance/portfolios/{id}/compliance-evidence-export?format=oscal|pdf|zip` with
  `responseType:"blob"`. Parses `content-disposition` for `filename="..."` (fallback
  `compliance-evidence-{id}.zip`), wraps in `Blob({type:"application/zip"})`, creates an object URL,
  programmatically clicks an `<a download>`, then revokes. Returns the filename string.
- **`navigator.sendBeacon` telemetry** — `beaconViewerDwell` (`:3603-3621`): on page-unload/hidden,
  beacons a JSON `Blob` to `${API_BASE_URL}/api/v1/analytics/viewer-events` (constant
  `VIEWER_EVENTS_PATH`, `:3578`). Returns `true` if queued, else `false` so callers fall back to
  `recordViewerDwell` (`:3585-3594`, a best-effort POST that **never surfaces errors** — logs only in `import.meta.env.DEV`).
- ⚠️ **GOTCHA — beacon bypasses the interceptors.** `sendBeacon` is a raw browser API; it does NOT carry
  the `Authorization` header injected by the request interceptor and does NOT go through error
  normalization. The viewer-events endpoint must accept unauthenticated/cookie-auth beacons (or treat them as best-effort).

### 2.6 Endpoint catalog (all 265 functions in `client.ts` + 13 in `bundlesApi.ts`)

Grouped by domain. Format: `fn(args) → ReturnType` · `METHOD path` · `client.ts:line`. Cross-reference the
backend router in `regen/01-api-*.md` as noted per group.

**Auth & users** (`client.ts:2010-2136`; backend → `regen/01-api-auth.md`)
- `fetchAuthConfig() → AuthModeConfig` · GET `/api/v1/auth/config` · :2026
- `fetchCurrentUser() → UserProfile` · GET `/api/v1/auth/me` · :2031
- `loginLocal(LoginRequest) → TokenResponse` · POST `/api/v1/auth/login` · :2036
- `logoutSession() → void` · POST `/api/v1/auth/logout` (+`clearAuthToken`) · :2046
- `fetchRoles() → RoleSummary[]` · GET `/api/v1/auth/roles` (unwraps `.data`) · :2053
- `fetchGateReviewerRoles(gateId) → GateReviewerRoles` · GET `/api/v1/gates/{id}/reviewer-roles` · :2064
- `fetchAuditLog(params?) → ...` · GET `/api/v1/...audit...` · :2074
- `fetchUsers(params?)`, `fetchUser(id) → UserProfile` (`/api/v1/users/{id}`), `createUser(UserCreate)`
  (POST `/api/v1/users`), `updateUserProfile`, `deactivateUserProfile`, `updateUserPassword` · :2090-2136

**Portfolios** (backend → `regen/01-api-portfolio-lines-misc.md`)
- `fetchPortfolios() → PortfolioListItem[]` · GET `/api/v1/portfolio` · :200
- `createPortfolio(PortfolioCreate) → PortfolioDetail` · POST `/api/v1/portfolio` · :535
- `seedSamplePortfolio(...) → SeedSamplePortfolioResponse` · :558
- `fetchProfiles() → ProfileSummary[]` · GET `/api/v1/profiles` · :2358
- `fetchActiveProfile() → ActiveProfileDetail|null` · :2363
- `switchPortfolioProfile(...)` · :2370 ; `fetchPortfolioProfileBundle(...) → ProfileBundleResponse` · :2395

**Applications** (backend → `regen/01-api-applications.md`)
- `fetchApplications({page,per_page,portfolio_id}) → PaginatedResponse<ApplicationDetail>` · GET `/api/v1/applications` · :207
- `fetchApplicationDetail(id) → ApplicationDetail` · GET `/api/v1/applications/{id}` · :217
- `fetchApplicationRationale(id) → ApplicationRationale` · `/{id}/rationale` · :236
- `fetchApplicationStatus(id) → ApplicationStatus` · `/{id}/status` · :245
- `fetchApplicationDispositions(id) → ApplicationDispositionsResponse` · `/{id}/dispositions` · :338
- `fetchApplicationLineage(id) → ApplicationLineageResponse` · `/{id}/lineage` · :355
- `fetchSourceArtifactsIndex(id) → SourceArtifactsIndex|null` · `/{id}/source-artifacts-index` (404→null) · :397
- `createApplication(ApplicationCreate)` (POST `/api/v1/applications`) · :568
- `uploadApplicationZip({name,file,...}) → ApplicationDetail` · POST `/api/v1/applications/upload` (multipart, 10min) · :588
- `updateApplication(id, ApplicationUpdate) → ApplicationDetail` · PATCH `/api/v1/applications/{id}` · :620
- Discovery triggers: `startDiscovery(appId)` (:631), `startDiscoveryAlias` (:650), `retryDiscovery` (:659), `rerunDiscovery` (:668)
- Design-artifact review: `fetchDesignArtifacts(appId,{line,artifact_type,page,per_page}) → DesignArtifactsResponse` (`/{appId}/design-artifacts`, :256), `submitDesignFeedback(appId, DesignFeedbackRequest)` (`/{appId}/design-feedback`, :267)
- Requirements interview: `startInterview(appId, StartInterviewRequest={})` (POST `/{appId}/interview`, :280), `fetchInterview(appId)` (GET same, :291), `submitInterviewTurn(appId, answer)` (POST `/{appId}/interview/turns`, :300), `completeInterview(appId) → CompleteInterviewResponse` (POST `/{appId}/interview/complete`, :311)
- `fetchApplicationInsights(...) → InsightsResponse` (:869), `fetchApplicationDecisions(...) → DecisionsTimelineResponse` (:878)
- `fetchStructuralAnalysis(...) → StructuralAnalysis` (:2286)

**Gates & escalations** (backend → `regen/01-api-gates-escalations.md`)
- `fetchPendingGates(portfolioId?, status="pending"|"rejected"|"approved"|"escalated") → PaginatedResponse<GateSummary>` · GET `/api/v1/gates/pending` · :412
- `fetchWaveGates(waveId)` · GET `/api/v1/gates/pending?wave_id&status=all&per_page=50` · :431
- `approveGate(id, comment?)` · POST `/api/v1/gates/{id}/approve {comment}` · :441
- `rejectGate(id, feedback)` · POST `/api/v1/gates/{id}/reject {feedback}` · :448
- `fetchGateEvidence(gateId) → GateEvidencePackage` · `/{gateId}/evidence` · :455
- `fetchApplicationGateEvidence(appId) → GateEvidencePackage[]` (array-guarded; perf #260 batch) · `/{appId}/gate-evidence` · :469
- `submitGateDecision(gateId, GateDecisionRequest) → GateDetail` · POST `/{gateId}/decision` · :478
- `forceAdvanceGate(gateId,{comment,bypass_evidence_check?}) → GateDetail` · POST `/{gateId}/force-advance` (manager-only; 409 unless `preparing`) · :496
- `resolveEscalation(gateId,{resolution_category:"re-extract"|"manual-augment"|"re-disposition"|"rejected-as-escalated", notes?}) → GateDetail` · POST `/{gateId}/resolve-escalation` · :513

**Waves & rationalization** (backend → `regen/01-api-waves.md`)
- `fetchWaves`, `createWave(WaveCreate)` (POST `/api/v1/waves`, :901), `fetchWaveDetail(id)` (GET `/api/v1/waves/{id}`, :906), `updateWave`, `deleteWave` (:922)
- `startWave` (:926), `startRationalization` (:943), `cancelWaveRationalization` (:960), `retryWaveRationalization` (:982), `resetWave` (:1000), `resumeWave → WaveResumeResponse` (:1045)
- `assignWaves(WaveAssignRequest) → WaveAssignResult` (:1059), `assignAppsToWave` (:1168), `removeAppsFromWave` (:1184), `bulkOnboardApps` (:1104), `cancelAllWaveChildren → WaveCancelAllChildrenResponse` (:1091), `markWaveReady` (:1126), `cancelWave` (:1142), `revertWaveToDraft` (:1154)
- `fetchWavePendingGates → WavePendingGatesResponse` (:1076), `fetchWaveAppProgress → WaveAppProgressResponse` (:1203), `fetchWaveProgress → WaveProgressResponse` (:1222), `fetchWavePerformanceReport → WavePerformanceReport` (:1240)
- `fetchWaveArtifact(waveId, path) → WaveArtifactResponse|null` · GET `/api/v1/waves/{id}/artifacts?path=` (⚠️ demo-fixture intercept, §2.7; 404→null) · :1266
- `fetchWaveOutcomeSynthesis(...)` (:2159, discriminated error type `WaveSynthesisFetchError`), `fetchWaveCapabilityLineage → WaveCapabilityLineageResponse` (:2819), `ratifyCapabilityLineageRow`/`rejectCapabilityLineageRow` (:2829/:2845), `fetchWaveAppActivity → WaveAppActivityResponseView` (:3472)

**Workflows / orchestration** (backend → `regen/01-api-chat-workflows-signals.md`)
- `fetchStepExecution → StepExecutionRecord` (:677), `fetchWorkflowDetails → WorkflowDetailsResponse` (:688)
- `startLineWorkflow(...,DelegationChoice) → WorkflowStartResponse` (:710), `cancelWorkflow → WorkflowActionResponse` (:722), `retryWorkflow` (:731), `resetWorkflow(WorkflowResetRequest) → WorkflowResetResponse` (:753)
- Workflow-health admin: `fetchWorkflowHealthList → WorkflowHealthListResponse` (:768), `fetchWorkflowHealthDetail → WorkflowHealthDetail` (:778), `restartWorkflowHealth`/`failWorkflowHealth → WorkflowHealthActionResponse` (:787/:796)
- Architecture dispatch (V1+V2): `fetchDispatchPreview → DispatchPreviewResponse` (:2452), `dispatchArchitecture → DispatchArchitectureResponse` (:2496), `fetchDispatchTargetPreview → DispatchTargetPreviewResponse` (:2575), `dispatchArchitectureV2` (:2619), `normaliseDispatchTargets` (pure helper, :2703), `fetchDispatchStatus → DispatchStatusResponse` (:2712), `dispatchRetry` (:2735), `fetchGitRepoAvailable → GitRepoAvailableResponse` (:2758)

**Agents / models** (backend → `regen/01-api-skills-analytics.md`)
- `fetchAgentRunRecentErrors → AgentRunErrorListResponse` (:811), `fetchAgentRoles → AgentRoleListResponse` (:837), `fetchModelUsage → ModelUsageResponse` (:857)

**Analytics & scoring** (backend → `regen/01-api-skills-analytics.md`)
- `fetchReadinessScores → ReadinessScoreEntry[]` (:1309), `fetchOverlapMatrix → OverlapMatrixEntry[]` (:1322), `fetchPortfolioHealth → PortfolioHealthResponse` (:1332), `fetchPortfolioScoringHeatMap → PortfolioScoringHeatMapResponse` (:1349), `fetchDispositionConfidence → DispositionConfidenceEntry[]` (:1359), `fetchCompoundGrowth → CompoundGrowthResponse` (:1369), `fetchGatePassRate → GatePassRateResponse` (:1379), `fetchScoreHistory → ScoreHistoryEntry[]` (:1389)
- `fetchLineStatus → LineStatusResponse` (:1440), `fetchLineThroughput → LineThroughputResponse` (:1454)
- `fetchPortfolioTargetStateRollup` (:2200, returns via inline `import("../types/api")` type)

**Dimension/scoring registry + extensibility** (backend → `regen/01-api-registries.md`)
- `fetchDimensionRegistry → DimensionRegistryResponse` (:1399), `updateDimensionRegistry` (:1410)
- `fetchRegistriesIndex → RegistryIndexEntry[]` (:1820), `fetchRegistryEntries → RegistryEntryRow[]` (:1834)

**Traceability** (backend → `regen/01-api-traceability-bundles.md`)
- `fetchTraceability → TraceabilityLink[]` (:1472), `fetchForwardTrace` (:1514), `fetchBackwardTrace` (:1525), `fetchTraceabilityCoverage → TraceabilityCoverage` (:1536), `validateGateTraceability` (:1545), `fetchCrossValidation → CrossValidationIssue[]` (:1556), `fetchStaleArtifacts → StaleArtifact[]` (:1565)
- Renditions: `generateRendition(RenditionGenerateRequest)` (:1588), `fetchRenditions(appId) → RenditionItem[]` (:1599)

**Skills** (backend → `regen/01-api-skills-analytics.md`, registry → `regen/11-skill-registry.md`)
- `fetchSkills({...}) → ...` (:1613), `fetchSkill(skillId) → SkillDetail` (:1627), `fetchSkillByDispatch` (:1635), `createSkill(SkillCreate)` (POST `/api/v1/skills`, :1644), `updateSkill` (:1649), `deleteSkill` (:1660), `fetchSkillMetricsByLine → SkillMetricsByLineResponse` (:1703)

**Governance / health / compliance** (backend → `regen/01-api-governance-systems.md`)
- `fetchDetailedHealth → DetailedHealthResponse` (:1716)
- `fetchGovernanceLatestHealthCheck → GovernanceHealthCheck|null` (:1753), `fetchGovernanceHealthChecks` (:1760), `fetchGovernanceDriftAlerts` (:1771), `acknowledgeDriftAlert` (:1784), `fetchGovernancePatterns → GovernancePatternSummary[]` (:1793)
- `startGovernanceSweep(GovernanceSweepRequest) → GovernanceSweepResponse` (:3279), `fetchGovernanceSweeps` (:3297), `triggerGovernanceSweep(portfolioId, cadence="weekly"|"quarterly")` (POST `/api/v1/governance/sweep`, :3404)
- `fetchPortfolioComplianceSystemRollup → PortfolioComplianceRollup` (:2896)
- cATO: `fetchPortfolioCatoEvidence → PortfolioCatoEvidence` (GET `/api/v1/governance/portfolios/{id}/cato-evidence`, :3362), `downloadComplianceEvidence(portfolioId, format) → string` (blob, §2.5, :3376)
- Tier-1 approvals: `fetchTier1Pending → Tier1PendingResponse` (:3541), `submitTier1Approval(Tier1ApprovalRequest) → Tier1ApprovalResponse` (:3550)

**Systems / capabilities (SF1/SF3 grain)** (backend → `regen/01-api-governance-systems.md`)
- `fetchSystems → SystemSummary[]` (:3030), `fetchSystemDetail → SystemDetail` (:3041), `fetchSystemCapabilities → CapabilitySummary[]` (:3051), `fetchSystemLineage → SystemLineageView` (:3061), `fetchCapabilityLineage → CapabilityLineageView` (:3076)

**Chat / assistant** (backend → `regen/01-api-chat-workflows-signals.md`)
- `sendChat(...) → ChatResponse` (:1903), `sendGateChat(...)` (:1914), `fetchChatHistory → ChatHistoryResponse` (:1933), `fetchGateChatHistory` (:1951), `clearChatHistory` (:1968)
- Types: `ChatContextType="gate"|"application"|"portfolio"` (:1851), `ChatMessage`/`UnifiedChatMessage`/`ChatSourceItem`/`ChatResponse`/`ChatHistoryMessage`/`ChatHistoryResponse` (:1853-1901)

**Activity / dwell telemetry** (backend → `regen/01-api-skills-analytics.md`)
- `fetchRecentActivity(...) → ActivityEvent[]` (:1997), `recordViewerDwell(ViewerDwellEvent)` (POST `/api/v1/analytics/viewer-events`, :3585), `beaconViewerDwell(ViewerDwellEvent) → boolean` (sendBeacon, :3603), `fetchViewerAnalyticsSummary(artifactType?, limit=50) → ViewerAnalyticsSummary` (:3642)

**My tasks (human-paired-agent)** (backend → `regen/01-api-traceability-bundles.md` / bundles)
- `fetchMyTasks({...}) → MyTasksResponse` (:3185), `submitTaskReturn(taskId, TaskReturnRequest) → TaskReturnResponse` (:3217), `acceptTask(taskId) → TaskReturnResponse` (:3229), `fetchTaskAuditNarrative(taskId) → TaskAuditNarrative` (:3236)
- Types: `ActorKind="olympus_agent"|"human"|"human_with_agent"` (:3101), `TaskReturnStatus="completed"|"needs_help"` (:3103), `LocalAgentDescriptor`, `MyTaskSummary`, `MyTasksResponse`, `LocalAgentSession`, `TaskReturnRequest/Response`, `TaskAuditNarrative` (:3106-3183)

**Disposition output**
- `fetchDispositionOutput(...)` (:2237, discriminated error type `DispositionOutputFetchError`)

**Bundles & portfolio membership** (`bundlesApi.ts`; backend → `regen/01-api-traceability-bundles.md`)
- Pair-facing: `listBundles(filters?) → BundleSummary[]` (GET `/api/v1/me/bundles`, :205), `getBundle(id) → BundleDetail` (`/api/v1/bundles/{id}`, :224), `claimBundle(id, BundleClaimRequest?)` (POST `/{id}/claim`, :232), `releaseBundle(id, ...)` (`/{id}/release`, :244), `validateBundle(id, BundleSubmitRequest) → BundleValidationResult` (`/{id}/validate`, :256), `submitBundle(id, ...) → BundleSubmitSuccess` (`/{id}/submit`, :278), `getBundleAudit(id) → BundleAuditNarrative` (`/{id}/audit`, :290)
- Admin: `listPortfolioMembers(pid)` / `addPortfolioMember(pid, ...)` / `removePortfolioMember(pid,userId)` (`/api/v1/admin/portfolios/{pid}/members`, :303-330), `createBundle(pid, BundleDispatchRequest)` (POST `/api/v1/admin/portfolios/{pid}/bundles`, :332), `forceReleaseBundle(bundleId, ...)` (POST `/api/v1/admin/bundles/{id}/force-release`, :343)
- ⚠️ Bundle endpoints use `encodeURIComponent` on every id.
- Enum unions (`bundlesApi.ts:20-41`): `BundleScopeKind`, `BundleStatus` (offered|claimed|submitted|accepted|rejected|expired|released), `BundleFallbackPolicy`, `BundleSessionArtifactKind`. `RBACRoleValue` (`:165-174`) mirrors `RBACRole`.

### 2.7 Demo-mode interception in the client (`demo-mode.ts` + 2 call-sites)

⚠️ **GOTCHA — `VITE_DEMO_MODE=true` changes API behavior. Every branch is a strict no-op when unset.**
- `IS_DEMO_MODE = import.meta.env.VITE_DEMO_MODE === "true"` evaluated once at module load
  (`demo-mode.ts:59-60`); Vite dead-code-eliminates the branches in a normal build.
- `getDemoFixture(name)` (`:140-162`): fetches `/test-data/demo/atlas-challenge/<name>.json` from
  `dashboard/public/`; returns `null` on miss/parse-error/non-demo so callers fall back to live API.
- **Call-site 1** — `fetchWaveArtifact` (`client.ts:1277-1290`): in demo mode, derives a fixture name from
  the artifact path's basename, and if a fixture exists returns a **synthetic** `WaveArtifactResponse`
  (`commit_sha:"demo-fixture"`) without hitting the backend; else falls through to the live GET.
- **Call-site 2** — gate decisions: `shouldShortCircuitGateDecision()` (`:170-172`) returns `true` in demo
  mode; the `useSubmitGateDecision` hook (`useQueries.ts`, imports `shouldShortCircuitGateDecision`) then
  treats the optimistic local mutation as final and **never POSTs** the decision.
- Other demo helpers (used app-wide, not in client.ts): `installDemoToastGuard(toast)` (toast suppression via
  monkey-patch of sonner variants, escape hatch `toastForDemo`/`__demo_passthrough__`), `useDemoClock()`
  (frozen `FIXED_DEMO_CLOCK_ISO = "2026-05-08T14:22:00Z"`, `:73`), `shouldPollTick()` (pauses polling when
  document hidden, consumed by `usePollingBackoff`). `DemoModeIndicator` renders a "DEMO MODE" pill.

### 2.8 React Query layer (`hooks/useQueries.ts`) — how the client is consumed

`App.tsx:110-117` creates the single `QueryClient`:
```ts
new QueryClient({ defaultOptions: { queries: { staleTime: 30_000, refetchOnWindowFocus: true } } });
```
- `useQueries.ts` wraps client functions in `useQuery`/`useMutation` (TanStack Query v5).
- ⚠️ **GOTCHA — portfolio-scoped query keys** (`useQueries.ts:42+`, P5-AUDIT-016/Cluster C): every
  portfolio-scoped query key **includes the portfolio id** so switching the active portfolio (header
  picker) invalidates and refetches. Reproduce or stale cross-portfolio data leaks across switches.
- Mutations invalidate related keys via `useQueryClient()`. `useSubmitGateDecision` consults
  `shouldShortCircuitGateDecision()` (demo bypass, §2.7).
- Polling/backoff lives in `usePollingBackoff.ts` (+ `useWebSocket.ts` for the live connection indicator,
  base `VITE_WS_BASE_URL`).

### 2.9 Shared response types (`types/api.ts`) — the enums to reproduce verbatim

These string-literal unions drive UI mapping (colors, labels, glossary) and MUST match the backend Pydantic enums:
- `Disposition` (`api.ts:10-19`): `Retire|Retain|Refactor|Rearchitect|Replace|Replatform|Consolidate|Build` — ⚠️ **8 values** (the 8th, `"Build"`, is Phase-6 net-new greenfield; the framework doc cites 7 — the dashboard type adds Build).
- `RiskTier` (`:21`): `1|2|3` (numeric). `ComplexityTier` (`:23`): `"simple"|"moderate"|"complex"`.
- `GateType` (`:25-40`): the **15 canonical gates** `G-DC,G-RR,G-DA,G-02,G-DT,G-04a,G-04b,G-04c,G-DE-1,G-DE-2,G-V1,G-V2,G-V3,G-DP-1,G-DP-2`.
- ⚠️ `BuildGateType` (`:50`): `"G-NEW-1"|"G-NEW-2"|"G-NEW-3"` — **distinct** from `GateType`; Build-line-local, NOT in `GATE_METADATA`/`GATE_CONSEQUENCES`.
- `GateStatus` (`:52-58`): `preparing|pending|approved|rejected|overridden|escalated`.
- `AssemblyLineName` (`:60-72`): `Discovery|Rationalization|Architecture|Data|Modernization|Build|Disposition Execution|Validation|Deployment|Sustainment|Governance` — ⚠️ **11 values** (includes `"Build"`; note the spaces in `"Disposition Execution"`).
- `EventType` (`:74-86`): 12 WebSocket/activity event types (`app.status_changed`, `gate.ready`, `gate.decided`, `task.*`, `escalation.*`, `alert.drift`, `alert.staleness`, `wave.progress`, `health.check_complete`).
- `RBACRole` (`:1594-1603`): `portfolio_admin|portfolio_manager|tech_lead|arch_lead|compliance_lead|operations_lead|safety_board|viewer|service` (9 roles).
- `PaginatedResponse<T>` (`:976-979`) = `{ data: T[]; pagination: PaginationMeta }`.
- Auth shapes (`:1605-1694`): `UserProfile`, `UserCreate`, `UserUpdate`, `LoginRequest{email_or_username,password}`, `TokenResponse{access_token,token_type:"bearer",expires_in,user}`, `AuthModeConfig{local_enabled,oidc_enabled,oidc_provider_id,oidc_provider_label,oidc_login_url}`, `RoleSummary{role,description,scope}`, `GateReviewerRoles`, `AuditEvent`.

---

## 3. FIXTURES & CONFIG

### 3.1 `config/glossary.ts` — tooltip term→definition map

Source of truth `reference/terminology.md`, manually extracted to avoid bundling a markdown parser
(`glossary.ts:1-18`).
- `GlossaryEntry = { label: string; definition: string }` (`:20-25`).
- `export const GLOSSARY: Record<string, GlossaryEntry>` (`:34-206`) — keyed by the **literal term a
  reviewer sees** (case-sensitive). Covers:
  - **15 gate codes** `G-DC … G-DP-2` — label format `"Friendly Name (CODE)"`, 1–3 sentence definition (`:38-112`).
  - **7 dispositions** Retire/Retain/Refactor/Rearchitect/Replace/Replatform/Consolidate (`:115-149`). (⚠️ `Build` is NOT glossed.)
  - **3 risk tiers** `"Tier 1"|"Tier 2"|"Tier 3"` (`:152-166`).
  - **3 complexity tiers** `simple|moderate|complex` (`:169-184`).
  - **Scoring/feature terms**: `"Disposition Confidence"`, `"Skill Dispatch"`, `"Forward Trace"`, `"Backward Trace"` (`:186-205`).
- `getGlossaryEntry(term): GlossaryEntry|null` (`:213-215`) — `GLOSSARY[term] ?? null`, case-sensitive. Consumed by the `<Glossary>` tooltip component.

### 3.2 `config/gateConsequences.ts` — approve/reject consequence copy

Plain-language "if you approve / if you reject" copy for the gate-review **consequence banner**
(`gateConsequences.ts:1-16`; rendered by `GateReview.tsx`, styled `.consequence-banner*` §1.7).
- `GateConsequence = { approved: string; rejected: string }` (`:19-24`).
- `export const GATE_CONSEQUENCES: Record<GateType, GateConsequence>` (`:27-118`) — ⚠️ **typed to `GateType`**
  so it MUST cover **all 15 canonical gates exactly** (TS enforces exhaustiveness). Each entry is one
  reviewer-facing sentence per branch. Source of truth: `assembly-lines/*` READMEs, `reference/terminology.md`,
  `specifications/decisions.md`.
- `getGateConsequence(gateType: GateType|string): GateConsequence|null` (`:125-131`) — null for unknown/bespoke gates.

### 3.3 `fixtures/cato-evidence-IACRA.json` — demo cATO artifact

14.7 KB OSCAL-flavored fixture for the per-application cATO viewer (`pages/Compliance/ApplicationCompliance`,
route `/compliance/:appId`). ⚠️ **Demo placeholder** — the App.tsx route comment notes "Swap for a fetched
artifact once the cato-compliance skill is wired into the workflow" (`App.tsx:282-284`).
- Top-level keys: `schema_version, generated_at, generated_by, app, app_id, framework, control_baseline,
  artifact_schema_version, framework_system_id, framework_control_label, fips_199_level,
  authorization_boundary, compliance_authority, inherited_control_providers, overall_posture,
  family_counts, controls[], poam[], sbom_summary`.
- Shape mirrors `PortfolioCatoEvidence`/`SystemCatoEvidence`/`CatoControlEvidence` (`client.ts:3313-3360`).

### 3.4 `data/` stub & metadata helpers

⚠️ **GOTCHA — `data/*` are NOT live API data.** They are stubs/metadata for gaps with no backend endpoint.
- `data/stubData.ts`: header comment "ONLY for metrics that have no backend API yet" — e.g.
  `gatePassRateTrend` (hardcoded Wave 1–4 rates). ⚠️ Real data always preferred; these fill visual gaps in the demo.
- `data/assemblyLineStubData.ts`: ⚠️ (P5-AUDIT-004) previously shipped fake agents/KPIs that rendered next to
  real data — now **shape-only** (TS interfaces + one zeroed empty instance). `AssemblyLineDashboard.tsx`
  consumes real APIs directly; this file survives only as a type scaffold. Do NOT reintroduce fake data.
- `data/gateMetadata.ts`: `GATE_METADATA` — maps the 15 gate codes → friendly name + assembly line. Code
  (e.g. `G-DC`) is the stable id (URLs/Git/schemas/API); friendly name (`Discovery Complete`) is the
  human-facing label. Both source-of-truth (signed-off naming table P5-S3). ⚠️ Keep in sync with backend gate naming.
- `data/bundles.ts`: bundle plain-English helpers — `(scope_kind, target_id)` → friendly verb + formatting,
  joins with app/wave name. Falls back to the gate's friendly name when uncertain.
- `data/line-contracts/`: parsed assembly-line contract data (generated by `scripts/parse-line-contracts.mjs`,
  npm `build:line-contracts`).

---

## 4. Reproduction Checklist (behavioral parity gates)

1. **Tokens** — copy the `:root` + `[data-theme="dark"]` custom-property blocks (§1.3) byte-for-byte; wire
   `useTheme` to set `data-theme` on `<html>` at module-load (pre-render) + persist `olympus-theme`.
2. **Import chain** — `main.tsx`→`styles/index.css`; preserve the 8-file `@import` order (USWDS CSS first via `base.css`).
3. **Inter font** from Google Fonts at 400/500/600/700/900.
4. **Every USWDS override** in §1.12 (each `!important` matters): dark `#211D1E` header, navy `#1b3a5c` table
   headers, `3px` accent card top-border, visited-link pin, bare-search normalization, sidenav left-accent,
   gate-review unstyled-button underline strip.
5. **Recharts JS palette** (`useChartTheme`) — Recharts cannot read CSS vars; reproduce both LIGHT/DARK palettes.
6. **API client**: Axios base `VITE_API_BASE_URL ?? http://localhost:8000`, 30s timeout; bearer-from-localStorage
   request interceptor (key `olympus:auth:token`); the 4-step error-normalization interceptor that rejects with
   `Error("STATUS: detail")`; all 265+ endpoint functions return unwrapped `data`.
7. **Special transports**: multipart upload (10min, MIME-only header), blob download (object-URL click), `sendBeacon`
   (no auth header, no interceptor).
8. **Demo-mode no-op contract**: all `VITE_DEMO_MODE` branches dead by default; fixture intercept on
   `fetchWaveArtifact`; gate-decision short-circuit.
9. **Config tables**: `GLOSSARY` (case-sensitive), `GATE_CONSEQUENCES` (exhaustive over 15 `GateType`),
   `GATE_METADATA`; do NOT reintroduce `assemblyLineStubData` fake data.
10. **Enums** in `types/api.ts`: 8 dispositions (incl. Build), 15 `GateType` + 3 `BuildGateType`, 11
    `AssemblyLineName`, 6 `GateStatus`, 9 `RBACRole`, 12 `EventType`.

---

## 5. Undetermined / out-of-scope-for-this-doc

- **Component-level props/state** (e.g. `<Layout>`, `<DataGrid>`, `<GateReviewCards>` internal state machines)
  are spec'd in the companion `regen/05-dashboard-*` page/component docs — this doc covers only design tokens,
  CSS, the API client, fixtures, and config.
- **OIDC callback handling** (`pages/Auth/OidcCallback`) token exchange detail is in the pages doc; the client
  side only exposes `fetchAuthConfig` (provides `oidc_login_url`) + `loginLocal` + `setAuthToken`.
- A handful of `client.ts` functions take/return **inline `import("../types/api").X` types** rather than top-level
  imports (e.g. `fetchApplicationRationale` :238, `fetchPortfolioTargetStateRollup` :2203) — their exact response
  shapes live in `types/api.ts` and are catalogued in `regen/01-api*.md`; not re-expanded here.
- `data/line-contracts/` generated content depends on `scripts/parse-line-contracts.mjs` parsing the
  `assembly-lines/*` line-contract YAML — regenerate via `npm run build:line-contracts` rather than hand-authoring.
