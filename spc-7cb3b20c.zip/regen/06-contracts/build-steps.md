# Build — Assembly Line Contract (ATOMIC regeneration spec)

> **NEW AT HEAD 7cb3b20c (2026-06-15).** Build is a BRAND-NEW assembly line added with the Phase 6 greenfield/net-new construction work (P6-S5). It is the **11th** line the loader now returns (`olympus_contracts.line_names()` → 11 entries; Build sorts second, between `Architecture` and `Data`). It is the third downstream **execution** line (alongside Modernization and Disposition Execution) and is selected by the new `Disposition.BUILD` value (`"Build"`, enums.py:41). This file reproduces the full line, field-by-field, exactly like the other per-line step files.

**Source of truth:** `olympus-contracts/olympus_contracts/data/assembly-lines/build.yaml` (651 lines).

This document reproduces, field-by-field, the authoritative Build assembly-line contract. The YAML is the single source of truth: every downstream consumer (Temporal workflow, Olympus API gate service, step-progress mapping, frontend step registry) loads FROM this file via `olympus_contracts.assembly_lines`. Application code must not hardcode a copy — drift is policed by the `test_no_hardcoded_step_lists` CI check (build.yaml:1-8, header comment).

⚠️ GOTCHA — `Build` is a loader line but NOT an `AssemblyLine` enum member. The `AssemblyLine` StrEnum (enums.py:233-245) still has exactly **10** members and does NOT include `Build`; meanwhile the loader returns **11** lines (Build's YAML loads like any other). So `get_line("Build")` succeeds, but `AssemblyLine("Build")` raises `ValueError`. `Disposition.BUILD` (enums.py:41) is the value that *selects* this line; the line name is a plain string `"Build"` matched by `get_line(...)`, not by the `AssemblyLine` enum. Do not "fix" this by adding a `BUILD` enum member — that would change observable enum membership (the 10-line enum is referenced by tests and the contracts spec §1.8).

⚠️ GOTCHA — YAML scalar folding: `description` and every step `purpose` use the YAML folded-block scalar (`>`). Folded scalars collapse newlines into single spaces (with blank lines becoming newline boundaries). The reproduced prose below preserves the wording exactly; when re-serializing to YAML use `>` (folded) form, not `|` (literal), or whitespace semantics will differ.

⚠️ GOTCHA — `- id:` namespace collision: a naive `grep "^  - id:"` over the file returns **18** matches, but three of them (build.yaml:39, 41, 43) are entries under the top-level `gates:` list (`G-NEW-1`, `G-NEW-2`, `G-NEW-3`), NOT steps. The steps list (under `steps:` at build.yaml:63) contains EXACTLY **15** step `- id:` entries (build.yaml:67–613). Do not miscount by including the three gate-definition ids. (This is the same 15-steps-plus-3-gate-defs = 18 framing as Rationalization's 21-steps-plus-2-gate-defs = 23.)

---

## 0. What Build is, and how it reuses Modernization

File header (build.yaml:1-21) is normative provenance — reproduce as comments. Verbatim sense:

- Build is the **third downstream execution line** (alongside Modernization and Disposition Execution). It is selected by the `Build` disposition (build.yaml:11-12).
- **Discovery, Rationalization, Architecture, and Data are reused wholesale; only the implementation line is new** (build.yaml:12-13).
- Build **replaces Modernization's legacy-Extract step with a `spec-from-requirements` step** that consumes the requirements/capability artifact (build.yaml:13-15), then **reuses Modernization's source-agnostic Design** (`module-design` / `api-specification` / `data-modeling` / `traceability-audit`) and **Generate** (Ralph Loop: `tdd-generation` / `code-synthesis` / `adversarial-review` / `security-scan-review`) **skills unchanged** (build.yaml:15-18).
- ⚠️ **Escalation path is "Refine Spec", NOT "Re-Extract"** — there is no legacy code to re-read (build.yaml:18-19). This phrase recurs in steps `gate-review-new-1`, `generate`, and `gate-review-new-3`; reproduce it exactly each time.
- Design reference: `specifications/phase-6/greenfield-build-line.md` §7 (P6-S5.7, P6-S5.9, P6-S5.10) (build.yaml:21).

⚠️ GOTCHA — the three Build gates `G-NEW-1/2/3` are the Build-line equivalents of Modernization's `G-04a/b/c`. They are **NOT** in the `GateType` enum (which is fixed at the 15 standard gates, enums.py:91-117) and **NOT** in `GATE_FRIENDLY_NAMES` / `GATE_ASSEMBLY_LINES` (15 entries each, no `G-NEW-*`). They live ONLY in this YAML's `gates:` list and each step's `gate:` field. `gate_friendly_name("G-NEW-1")` falls through `except ValueError` → echoes `"G-NEW-1"` (enums.py:161-165); `gate_assembly_line("G-NEW-1")` falls back to `"Discovery"` (enums.py:204-208). So the contracts package does NOT know these gates own the Build line. Over-specify: a regenerator MUST keep `G-NEW-1/2/3` out of `GateType` (adding them is a breaking 15→18 enum migration) while keeping them present in `build.yaml`.

---

## 1. Line-level metadata

Reproduced verbatim from build.yaml:23-61. Top-level keys present, in file order: `name`, `description`, `trigger`, `depends_on`, `gates`, `mode`, `inputs`, `outputs`, `steps`. (Same key set and order as every other line contract.)

### `name` (build.yaml:23)
```
Build
```

### `description` (build.yaml:24-31, folded scalar `>`)
> Spec-driven new construction. Transforms a validated requirements/capability artifact into working, tested, compliant code through a three-step pipeline — Spec-from-Requirements → Design → Generate — with quality gates at each transition (G-NEW-1/2/3, equivalents of Modernization's G-04a/b/c). No legacy source is required; the requirements artifact's acceptance criteria are the validation oracle. Runs within portfolio waves alongside Modernization work, reusing Modernization's source-agnostic Design and Generate skills.

### `trigger` (build.yaml:32)
```
architecture-g02-approved-and-data-g-dt-approved
```
⚠️ GOTCHA — Build's `trigger` is **identical** to Modernization's (`architecture-g02-approved-and-data-g-dt-approved`). Both downstream construction lines fire off the same Architecture-G-02 + Data-G-DT approval condition; the `Disposition` value (`Build` vs `Refactor`/`Rearchitect`) is what routes a given app to Build rather than Modernization. The line is **triggered** (fired by that event), not continuous/cron.

### `depends_on` (build.yaml:33-37)
In-file comment (build.yaml:33-34): "Strict upstream only; transitive deps (Architecture -> Rationalization -> Discovery) are reached via the depends_on graph, not restated here."
```yaml
depends_on:
  - Architecture
  - Rationalization
```
Two upstream dependencies: **Architecture** and **Rationalization** (a 2-tuple `("Architecture", "Rationalization")`). ⚠️ Contrast with Modernization, whose `depends_on` is `Architecture, Data`. Build depends on Architecture + Rationalization; Data outputs are consumed (see `inputs`) but Data is reached transitively, not declared.

### `gates` (build.yaml:38-44)
Three gate definitions, each with `id` + `label`:
```yaml
gates:
  - id: G-NEW-1
    label: Spec Review
  - id: G-NEW-2
    label: Design Review
  - id: G-NEW-3
    label: Code & Test Review
```
- `G-NEW-1` → "Spec Review"
- `G-NEW-2` → "Design Review"
- `G-NEW-3` → "Code & Test Review" (note the literal `&` in the label)

⚠️ GOTCHA: These gate ids are referenced later by the three gate-kind steps via their step-level `gate:` field (`gate-review-new-1` → `gate: G-NEW-1` at build.yaml:255; `gate-review-new-2` → `gate: G-NEW-2` at build.yaml:447; `gate-review-new-3` → `gate: G-NEW-3` at build.yaml:649). All other steps carry `gate: null`.

### `mode` (build.yaml:45)
```
per-app
```
⚠️ GOTCHA — mode vs scope: line-level `mode: per-app` AND every single step's `scope: per-app`. Build runs **once per application** (it is a downstream execution line over a single app's spec→design→generate pipeline), NOT per-wave like Rationalization and NOT continuous. Contrast Rationalization (`per-wave`). The line invocation unit is the app.

### `inputs` (build.yaml:46-50)
Line-level input artifact-type identifiers (4 entries):
```yaml
inputs:
  - requirements-capability
  - architecture-blueprint
  - data-models
  - rationalization-outputs
```

### `outputs` (build.yaml:51-61)
Line-level output artifact-type identifiers (10 entries):
```yaml
outputs:
  - scenario-spec
  - module-map
  - openapi-specs
  - er-diagrams
  - source-code
  - test-suites
  - coverage-report
  - 508-audit-report
  - security-scan-report
  - compliance-artifacts
```

⚠️ GOTCHA: The line-level `inputs`/`outputs` are bare artifact-TYPE names (no path templates). The per-step `inputs.artifacts`/`outputs.artifacts` use fully-templated repo paths (e.g. `build/{app_id}/specs/scenario-spec.json`). They are different representations and both must be reproduced. Note `er-diagrams` appears in the line-level `outputs` list but no step emits a file literally named that — it is the type-level name for the data-model design artifact (`build/{app_id}/design/data-model.yaml`, produced by Step 6 `design`). Likewise intermediate artifacts (`pre-review.json`, `design-review.json`, `business-rules-catalog.yaml`, `traceability-matrix.md`, `gate-packet`-style PR bodies) are NOT in the line-level `outputs` list.

---

## 2. Steps (all 15, in file order)

Per-step field set observed across the file. Not every step has every field; reproduce only those present per step:
`id`, `label`, `kind`, `scope`, `sequence`, `progress_pct`, `role` (optional — only on the three pre-review checks), `summary` (optional — only on Step 9), `purpose` (folded scalar), `skills`, `agent_role`, `inputs.artifacts`, `inputs.context`, `outputs.artifacts`, `outputs.side_effects` (each with `target` + `fields`), `agent_contract.mcp_servers`, `agent_contract.repos.{artifact, source, target}`, `parallel_with`, `gate`, `retry_policy.category`, `retry_policy.non_retryable_errors` (optional), `retry_policy.max_attempts_override` (optional).

⚠️ GOTCHA — field naming note: The contract uses `agent_contract.mcp_servers` (not `mcp`) and `agent_contract.repos` (sub-keys `artifact`/`source`/`target`). It uses `agent_role` (a scalar string or `null`) for the human-readable role AND a separate `role` field (only on pre-review steps) for the loader's `StepContract.role` discriminator. `skills` is always a list (possibly empty `[]`). `progress_pct` carries the numeric progress percentage. These exact key names must be preserved.

⚠️ GOTCHA — repo permission tri-state: `agent_contract.repos.{artifact,source,target}` values are one of `rw`, `ro`, `none`. Build's twist versus the analysis lines: **`source: none` on EVERY step** (there is no legacy source repo — Build is greenfield). The `target` repo flips to `rw` for the Generate-phase steps (`generate`, `commit-generate-artifacts`, `create-g-new-3-pr`, `generate-gate-readiness-check`, `gate-review-new-3`) because that is where generated code lands. The earlier Spec/Design steps use `target: none`. Reproduce each exactly; do not normalize.

⚠️ GOTCHA — `agent_role: olympus-agent` literal: every Build agent step sets `agent_role: olympus-agent` (build.yaml:82, 194, 282, 390, 475, 589) — a generic runtime agent identifier, NOT a descriptive human role like Rationalization's `Rationalization Analyst`. Reproduce the literal `olympus-agent` string exactly on all six agent steps.

---

### Step 1 — `spec-from-requirements` (build.yaml:67-115)

In-file section comment (build.yaml:64-66): "Step 1 — Spec-from-Requirements (Build-path equivalent of Extract; G-NEW-1)".

- **id:** `spec-from-requirements`
- **label:** `Spec-from-Requirements`
- **kind:** `agent`
- **scope:** `per-app`
- **sequence:** `1`
- **progress_pct:** `8`
- **purpose** (folded, build.yaml:73-80):
  > Convert the requirements/capability artifact (plus Architecture and Data outputs) into validated, implementation-ready business-rule specs and scenario specs. The Build-path equivalent of Modernization's Extract step. The source of business rules is requirements-capability FR-xxx items with acceptance criteria, not legacy code — traceability is FR-xxx -> interview:{question-id} or FR-xxx -> doc:{section}. Output feeds Step 2 Design via the same contracts Design already consumes from Modernization.
- **skills:** `[spec-from-requirements]`
- **agent_role:** `olympus-agent`
- **inputs.artifacts:**
  - `build/{app_id}/requirements/requirements-capability.json`
  - `architecture/{app_id}/architecture-blueprint.json`
  - `data/{app_id}/data-architecture.json`
- **inputs.context:** `[wave_id, app_id, risk_tier, complexity_tier, archetype]`
- **outputs.artifacts:**
  - `build/{app_id}/specs/scenario-spec.json`
  - `build/{app_id}/specs/business-rules-catalog.yaml`
  - `build/{app_id}/specs/traceability-matrix.md`
- **outputs.side_effects:**
  - **target:** `application`
    **fields:** `[build.spec_rule_count, build.spec_scenario_count, build.spec_coverage_pct]`
- **agent_contract.mcp_servers:** `[olympus]`
- **agent_contract.repos:** `artifact: rw`, `source: none`, `target: none`
- **parallel_with:** `[]` (empty)
- **gate:** `null`
- **retry_policy.category:** `agent_failure`
- **retry_policy.non_retryable_errors:** `[SchemaValidationError]`

⚠️ GOTCHA — skill id `spec-from-requirements` equals the step id (the Build-only skill that replaces Modernization's Extract). ⚠️ The `application` side-effect writes **dotted-namespace fields** `build.spec_rule_count` / `build.spec_scenario_count` / `build.spec_coverage_pct` — every Build side-effect on `application` uses the `build.` field prefix (distinct namespace from Rationalization's flat `risk_tier` etc.). ⚠️ `retry_policy.non_retryable_errors: [SchemaValidationError]` — agent steps that emit schema-validated artifacts mark `SchemaValidationError` non-retryable (also on `design` and `generate`). Inputs read the requirements artifact under `build/{app_id}/requirements/` plus Architecture + Data outputs (the cross-line reuse).

---

### Step 2 — `commit-spec-artifacts` (build.yaml:117-147)

- **id:** `commit-spec-artifacts`
- **label:** `Commit Spec Artifacts`
- **kind:** `git`
- **scope:** `per-app`
- **sequence:** `2`
- **progress_pct:** `12`
- **purpose** (folded, build.yaml:123-126):
  > Commit every Spec artifact (scenario-spec, business-rules-catalog, traceability-matrix) to the artifact repo on the per-app branch. One commit; message references wave_id + app_id.
- **skills:** `[]` (empty)
- **agent_role:** `null`
- **inputs.artifacts:**
  - `build/{app_id}/specs/*.json`
  - `build/{app_id}/specs/*.yaml`
  - `build/{app_id}/specs/*.md`
- **inputs.context:** `[wave_id, app_id]`
- **outputs.artifacts:** `[]` (empty)
- **outputs.side_effects:** `[]` (empty)
- **agent_contract.mcp_servers:** `[]` (empty)
- **agent_contract.repos:** `artifact: rw`, `source: none`, `target: none`
- **parallel_with:** `[]` (empty)
- **gate:** `null`
- **retry_policy.category:** `transient`

⚠️ GOTCHA — first `kind: git` step. `agent_role: null`, `mcp_servers: []`, `retry_policy.category: transient`. ⚠️ Inputs use **glob wildcards** (`build/{app_id}/specs/*.json`, `*.yaml`, `*.md`) rather than enumerated filenames — distinct from the analysis lines' explicit input lists. This commit step also has NO `side_effects` (unlike Rationalization's commit steps, which write `artifact_repo` → `[commit_sha, branch]`): Build's commit steps declare empty `outputs.side_effects: []`.

---

### Step 3 — `create-g-new-1-pr` (build.yaml:149-178)

- **id:** `create-g-new-1-pr`
- **label:** `Create G-NEW-1 Review PR`
- **kind:** `git`
- **scope:** `per-app`
- **sequence:** `3`
- **progress_pct:** `15`
- **purpose** (folded, build.yaml:155-158):
  > Open the Spec gate-review PR. PR body aggregates the scenario coverage summary, requirement traceability, and any spec-from-requirements escalation flags. Tier-1 apps tag the stakeholder for sign-off.
- **skills:** `[]` (empty)
- **agent_role:** `null`
- **inputs.artifacts:**
  - `build/{app_id}/specs/scenario-spec.json`
  - `build/{app_id}/specs/traceability-matrix.md`
- **inputs.context:** `[wave_id, app_id, risk_tier]`
- **outputs.artifacts:** `[]` (empty)
- **outputs.side_effects:** `[]` (empty)
- **agent_contract.mcp_servers:** `[]` (empty)
- **agent_contract.repos:** `artifact: rw`, `source: none`, `target: none`
- **parallel_with:** `[]` (empty)
- **gate:** `null`
- **retry_policy.category:** `transient`

⚠️ GOTCHA: `gate: null` even though this step CREATES the G-NEW-1 PR — the `gate:` field marks the actual gate-decision step (Step 5), not the PR-creation step. ⚠️ Unlike Rationalization's `create-grr-pr`/`create-gda-pr` (which emit a `gate-packet` artifact and write a `gate_record` side-effect), this Build PR-creation step emits NO output artifact and NO side-effect (`outputs.artifacts: []`, `outputs.side_effects: []`). "Tier-1 apps tag the stakeholder for sign-off" — the Tier-1 stakeholder routing is prose, not a `condition:` field.

---

### Step 4 — `spec-gate-readiness-check` (build.yaml:180-215)

- **id:** `spec-gate-readiness-check`
- **label:** `Spec AI Gate Readiness Check`
- **kind:** `agent`
- **scope:** `per-app`
- **sequence:** `4`
- **progress_pct:** `17`
- **role:** `pre-review`
- **purpose** (folded, build.yaml:187-191):
  > Advisory readiness check before G-NEW-1 human review opens — flags likely blocker findings (must-have capability coverage below 100%, requirement coverage below 95%, unresolved escalation flags, contradictory business rules) so reviewers and the workflow can short-circuit obvious rejections. Single-attempt; do not delay human review.
- **skills:** `[gate-pre-review]`
- **agent_role:** `olympus-agent`
- **inputs.artifacts:**
  - `build/{app_id}/specs/scenario-spec.json`
- **inputs.context:** `[wave_id, app_id, risk_tier]`
- **outputs.artifacts:**
  - `build/{app_id}/specs/pre-review.json`
- **outputs.side_effects:**
  - **target:** `gate_pre_review`
    **fields:** `[gate_id, findings_json]`
- **agent_contract.mcp_servers:** `[olympus]`
- **agent_contract.repos:** `artifact: rw`, `source: none`, `target: none`
- **parallel_with:** `[]` (empty)
- **gate:** `null`
- **retry_policy.category:** `agent_failure`
- **retry_policy.max_attempts_override:** `1`

⚠️ GOTCHA — FIRST `role: pre-review` step (one of three; the others are Steps 9 and 14). ⚠️ Because `role: pre-review`, this step is an `agent` step that is **EXCLUDED from `evidence_steps()`** (`evidence_steps()` keeps only `role in ("analysis","rollup")`, assembly_lines.py:175-185). So it appears in `agent_steps()` but NOT as a gate-review card. ⚠️ `retry_policy.max_attempts_override: 1` — "Single-attempt; do not delay human review." This is the ONLY field that sets `max_attempts_override` (also on Steps 9, 14); the loader stores it raw (assembly_lines.py:243, no coercion). Skill `gate-pre-review` is shared across all three readiness checks. Side-effect target is `gate_pre_review` (a Build-specific table) with `[gate_id, findings_json]`.

---

### Step 5 — `gate-review-new-1` (build.yaml:217-257)

- **id:** `gate-review-new-1`
- **label:** `G-NEW-1 Spec Review`
- **kind:** `gate`
- **scope:** `per-app`
- **sequence:** `5`
- **progress_pct:** `20`
- **purpose** (folded, build.yaml:223-230):
  > Human review of the derived specs by Tech Lead (PM) + stakeholder (Tier-1). Equivalent rigor to G-04a. Single PM signal for merge; stakeholder sign-off required for Tier-1 (StakeholderApprovedSignal scope="g-new-1-stakeholder"). Rejection triggers the "Refine Spec" escalation path — the requirements artifact is returned to the stakeholder with structured feedback, re-elicited, and Step 1 re-runs (up to 3 rework iterations). This is distinct from Modernization's "Re-Extract" path; there is no legacy code to re-read.
- **skills:** `[]` (empty)
- **agent_role:** `null`
- **inputs.artifacts:**
  - `build/{app_id}/specs/scenario-spec.json`
  - `build/{app_id}/specs/traceability-matrix.md`
  - `build/{app_id}/specs/pre-review.json`
- **inputs.context:** `[wave_id, app_id, risk_tier]`
- **outputs.artifacts:** `[]` (empty)
- **outputs.side_effects:**
  - **target:** `gate_record`
    **fields:** `[gate_id, status, approved_by, approved_at]`
  - **target:** `application`
    **fields:** `[build.spec_ref, build.spec_gate_status]`
- **agent_contract.mcp_servers:** `[]` (empty)
- **agent_contract.repos:** `artifact: rw`, `source: none`, `target: none`
- **parallel_with:** `[]` (empty)
- **gate:** `G-NEW-1`
- **retry_policy.category:** `validation_failure`

⚠️ GOTCHA — FIRST `kind: gate` step. `gate: G-NEW-1`, `retry_policy.category: validation_failure`. ⚠️ This is the FIRST of three Build gates that have **TWO side-effect targets** (`gate_record` + `application`) — distinct from Rationalization's gate-review-rr (one target) and matching gate-review-da's dual-target shape. The `gate_record` fields are `[gate_id, status, approved_by, approved_at]` (note: `status`/`approved_by`/`approved_at`, NOT Rationalization's `state`/`decided_at`/`decided_by`/`decision_notes` — Build uses a different gate_record field vocabulary). The `application` fields use the `build.` prefix: `[build.spec_ref, build.spec_gate_status]`. ⚠️ Tier-1 needs `StakeholderApprovedSignal scope="g-new-1-stakeholder"` in addition to the PM merge signal. ⚠️ Rejection = the **"Refine Spec"** escalation path (requirements returned, re-elicited, Step 1 re-runs, up to 3 rework iterations) — explicitly NOT Modernization's "Re-Extract"; "there is no legacy code to re-read." Equivalent rigor to G-04a.

---

### Step 6 — `design` (build.yaml:262-315)

In-file section comment (build.yaml:259-261): "Step 2 — Design (direct reuse of Modernization Design skills; G-NEW-2)".

- **id:** `design`
- **label:** `Design`
- **kind:** `agent`
- **scope:** `per-app`
- **sequence:** `6`
- **progress_pct:** `40`
- **purpose** (folded, build.yaml:268-276):
  > Transform validated scenario specs and business rules into a DDD architecture design. Direct reuse of Modernization Step 2 — the skills (module-design, api-specification, data-modeling, traceability-audit) are source-agnostic and consume the same artifact schemas regardless of whether inputs came from legacy extraction or requirements elicitation. Because Step 1's business-rules-catalog and scenario-spec conform to the same schemas as Modernization Step 1 outputs, this step receives identical input shapes regardless of path.
- **skills:** `[module-design, api-specification, data-modeling, traceability-audit]`
- **agent_role:** `olympus-agent`
- **inputs.artifacts:**
  - `build/{app_id}/specs/scenario-spec.json`
  - `build/{app_id}/specs/business-rules-catalog.yaml`
  - `build/{app_id}/specs/traceability-matrix.md`
  - `architecture/{app_id}/architecture-blueprint.json`
  - `data/{app_id}/data-architecture.json`
- **inputs.context:** `[wave_id, app_id, archetype, complexity_tier]`
- **outputs.artifacts:**
  - `build/{app_id}/design/module-map.yaml`
  - `build/{app_id}/design/openapi.yaml`
  - `build/{app_id}/design/data-model.yaml`
  - `build/{app_id}/design/compliance-map.md`
  - `build/{app_id}/design/context-map.md`
  - `build/{app_id}/design/design-review.json`
- **outputs.side_effects:**
  - **target:** `application`
    **fields:** `[build.contexts_count, build.api_endpoints_count, build.design_traceability_pct]`
- **agent_contract.mcp_servers:** `[olympus]`
- **agent_contract.repos:** `artifact: rw`, `source: none`, `target: none`
- **parallel_with:** `[]` (empty)
- **gate:** `null`
- **retry_policy.category:** `agent_failure`
- **retry_policy.non_retryable_errors:** `[SchemaValidationError]`

⚠️ GOTCHA — MULTI-SKILL (4 skills), DIRECT REUSE of Modernization Step 2: `skills: [module-design, api-specification, data-modeling, traceability-audit]` — the source-agnostic Modernization Design skills, reused unchanged. Emits SIX design artifacts under `build/{app_id}/design/`. ⚠️ `application` side-effect (`build.` prefix): `[build.contexts_count, build.api_endpoints_count, build.design_traceability_pct]`. `retry_policy.non_retryable_errors: [SchemaValidationError]`. The design-review.json is the key output the next gate consumes. This is the second multi-skill step in the line (the others being itself and `generate`).

---

### Step 7 — `commit-design-artifacts` (build.yaml:317-344)

- **id:** `commit-design-artifacts`
- **label:** `Commit Design Artifacts`
- **kind:** `git`
- **scope:** `per-app`
- **sequence:** `7`
- **progress_pct:** `44`
- **purpose** (build.yaml:323, plain scalar — NOT folded):
  > Commit every Design artifact to the artifact repo. Single commit.
- **skills:** `[]` (empty)
- **agent_role:** `null`
- **inputs.artifacts:**
  - `build/{app_id}/design/*.yaml`
  - `build/{app_id}/design/*.json`
  - `build/{app_id}/design/*.md`
- **inputs.context:** `[wave_id, app_id]`
- **outputs.artifacts:** `[]` (empty)
- **outputs.side_effects:** `[]` (empty)
- **agent_contract.mcp_servers:** `[]` (empty)
- **agent_contract.repos:** `artifact: rw`, `source: none`, `target: none`
- **parallel_with:** `[]` (empty)
- **gate:** `null`
- **retry_policy.category:** `transient`

⚠️ GOTCHA — the `purpose` here is a **plain inline scalar** (`purpose: Commit every Design artifact to the artifact repo. Single commit.`, build.yaml:323), NOT a folded `>` block like every other step. The loader strips it the same way (`(raw.get("purpose") or "").strip()`, assembly_lines.py:265), so behavior is identical, but when re-serializing reproduce the inline form for byte parity. Glob-wildcard inputs again (`*.yaml`/`*.json`/`*.md` under `build/{app_id}/design/`). No side-effect.

---

### Step 8 — `create-g-new-2-pr` (build.yaml:346-374)

- **id:** `create-g-new-2-pr`
- **label:** `Create G-NEW-2 Review PR`
- **kind:** `git`
- **scope:** `per-app`
- **sequence:** `8`
- **progress_pct:** `46`
- **purpose** (folded, build.yaml:352-355):
  > Open the Design gate-review PR. PR body aggregates the design-review summary, forward-traceability percentage, DDD alignment callouts, and accessibility/security coverage.
- **skills:** `[]` (empty)
- **agent_role:** `null`
- **inputs.artifacts:**
  - `build/{app_id}/design/design-review.json`
- **inputs.context:** `[wave_id, app_id]`
- **outputs.artifacts:** `[]` (empty)
- **outputs.side_effects:** `[]` (empty)
- **agent_contract.mcp_servers:** `[]` (empty)
- **agent_contract.repos:** `artifact: rw`, `source: none`, `target: none`
- **parallel_with:** `[]` (empty)
- **gate:** `null`
- **retry_policy.category:** `transient`

⚠️ GOTCHA: `gate: null` (the decision is Step 10). No output artifact, no side-effect. Reads only `design-review.json`.

---

### Step 9 — `design-gate-readiness-check` (build.yaml:376-411)

- **id:** `design-gate-readiness-check`
- **label:** `Design AI Gate Readiness Check`
- **kind:** `agent`
- **scope:** `per-app`
- **sequence:** `9`
- **progress_pct:** `48`
- **role:** `pre-review`
- **summary:** `true`
- **purpose** (folded, build.yaml:384-388):
  > Advisory readiness check before G-NEW-2 human review — flags likely blocker findings (forward-traceability below threshold, DDD misalignment, missing accessibility/security contracts, EA drift from the Architecture blueprint). Single-attempt.
- **skills:** `[gate-pre-review]`
- **agent_role:** `olympus-agent`
- **inputs.artifacts:**
  - `build/{app_id}/design/design-review.json`
- **inputs.context:** `[wave_id, app_id]`
- **outputs.artifacts:**
  - `build/{app_id}/design/pre-review.json`
- **outputs.side_effects:**
  - **target:** `gate_pre_review`
    **fields:** `[gate_id, findings_json]`
- **agent_contract.mcp_servers:** `[olympus]`
- **agent_contract.repos:** `artifact: rw`, `source: none`, `target: none`
- **parallel_with:** `[]` (empty)
- **gate:** `null`
- **retry_policy.category:** `agent_failure`
- **retry_policy.max_attempts_override:** `1`

⚠️ GOTCHA — THE LINE'S `summary_step` IS A PRE-REVIEW CHECK (the single most surprising fact about this line). This step carries BOTH `role: pre-review` (build.yaml:382) AND `summary: true` (build.yaml:383). Consequences, all load-bearing:
  - `LineContract.summary_step()` returns the **first** step with truthy `summary` → it returns `design-gate-readiness-check` (assembly_lines.py:187-191). Verified: `get_line("Build").summary_step().id == "design-gate-readiness-check"`.
  - But `evidence_steps()` EXCLUDES it (because `role == "pre-review"` is not in `("analysis","rollup")`, assembly_lines.py:175-185). So **the summary step is NOT in the evidence/card list** — unique among lines. (Discovery's summary step `synthesis` has `role: analysis` and IS in evidence_steps; here the relationship is inverted.)
  - Therefore `pass_order("Build")` / `evidence_steps()` = `[spec-from-requirements, design, generate]` (3 ids), and the summary step is not among them.
  - ⚠️ A regenerator MUST place `summary: true` on this pre-review step (sequence 9), not on `design` or `generate`. Moving it would change `summary_step()` output AND, if moved to an analysis step, would also add it to the card list.
  - `retry_policy.max_attempts_override: 1` (single-attempt, like the other readiness checks).

---

### Step 10 — `gate-review-new-2` (build.yaml:413-449)

- **id:** `gate-review-new-2`
- **label:** `G-NEW-2 Design Review`
- **kind:** `gate`
- **scope:** `per-app`
- **sequence:** `10`
- **progress_pct:** `52`
- **purpose** (folded, build.yaml:419-423):
  > Human review of the design by Tech Lead (PM) + Architecture Lead. Equivalent rigor to G-04b. Single PM signal for merge; Architecture Lead review expressed via PR comments. Rejection loops back through Design (up to 3 rework iterations).
- **skills:** `[]` (empty)
- **agent_role:** `null`
- **inputs.artifacts:**
  - `build/{app_id}/design/design-review.json`
  - `build/{app_id}/design/pre-review.json`
- **inputs.context:** `[wave_id, app_id]`
- **outputs.artifacts:** `[]` (empty)
- **outputs.side_effects:**
  - **target:** `gate_record`
    **fields:** `[gate_id, status, approved_by, approved_at]`
  - **target:** `application`
    **fields:** `[build.design_ref, build.design_gate_status]`
- **agent_contract.mcp_servers:** `[]` (empty)
- **agent_contract.repos:** `artifact: rw`, `source: none`, `target: none`
- **parallel_with:** `[]` (empty)
- **gate:** `G-NEW-2`
- **retry_policy.category:** `validation_failure`

⚠️ GOTCHA — `gate: G-NEW-2`, `validation_failure`. TWO side-effect targets again: `gate_record` `[gate_id, status, approved_by, approved_at]` + `application` `[build.design_ref, build.design_gate_status]`. ⚠️ Unlike Step 5 (which needs a Tier-1 `StakeholderApprovedSignal`), G-NEW-2 is a **single PM merge signal**; the "Architecture Lead review expressed via PR comments" — i.e. NO second mandatory signal here, the Architecture Lead's input is advisory PR comments, not a blocking `StakeholderApprovedSignal`. Equivalent rigor to G-04b. Rejection loops back through `design` (Step 6), up to 3 rework iterations.

---

### Step 11 — `generate` (build.yaml:454-511)

In-file section comment (build.yaml:451-453): "Step 3 — Generate (direct reuse of Modernization Ralph Loop; G-NEW-3)".

- **id:** `generate`
- **label:** `Generate`
- **kind:** `agent`
- **scope:** `per-app`
- **sequence:** `11`
- **progress_pct:** `80`
- **purpose** (folded, build.yaml:460-468):
  > Test-driven code generation from approved design specs. Direct reuse of Modernization Step 3 (Ralph Loop TDD cycle). The scenario-spec — derived from the requirements artifact's acceptance criteria — is the test oracle. Fans out per bounded context exactly as Modernization does. Escalation path is "Refine Spec" rather than "Re-Extract": if the Ralph Loop cannot converge on a module, the spec needs clarification, not legacy re-reading. Other escalation outcomes: "Manual Augment" (genuinely complex edge cases) and "Re-Disposition" (return to Rationalization). There is no "Re-Extract".
- **skills:** `[tdd-generation, code-synthesis, adversarial-review, security-scan-review, escalation-handler]`
- **agent_role:** `olympus-agent`
- **inputs.artifacts:**
  - `build/{app_id}/design/module-map.yaml`
  - `build/{app_id}/design/openapi.yaml`
  - `build/{app_id}/design/data-model.yaml`
  - `build/{app_id}/specs/scenario-spec.json`
  - `build/{app_id}/design/compliance-map.md`
- **inputs.context:** `[wave_id, app_id, archetype, complexity_tier]`
- **outputs.artifacts:**
  - `build/{app_id}/src/**`
  - `build/{app_id}/tests/**`
  - `build/{app_id}/generate/coverage-report.json`
  - `build/{app_id}/generate/508-audit-report.json`
  - `build/{app_id}/generate/security-scan-report.json`
  - `build/{app_id}/compliance/**`
  - `build/{app_id}/metrics/ralph-loop-metrics.yaml`
  - `build/{app_id}/specs/traceability-matrix.md`
- **outputs.side_effects:**
  - **target:** `application`
    **fields:** `[build.test_coverage_pct, build.ralph_loop_iterations, build.ralph_loop_escalations, build.generate_status]`
- **agent_contract.mcp_servers:** `[olympus]`
- **agent_contract.repos:** `artifact: rw`, `source: none`, `target: rw`
- **parallel_with:** `[]` (empty)
- **gate:** `null`
- **retry_policy.category:** `agent_failure`
- **retry_policy.non_retryable_errors:** `[SchemaValidationError, RalphLoopMaxEscalationsError]`

⚠️ GOTCHA — MULTI-SKILL (5 skills) Ralph-Loop reuse + FIRST `target: rw`: `skills: [tdd-generation, code-synthesis, adversarial-review, security-scan-review, escalation-handler]` — the four Modernization Generate skills PLUS `escalation-handler`. ⚠️ This is the FIRST step where `agent_contract.repos.target: rw` (build.yaml:506) — generated code lands in the **target** repo, so `target` flips from `none` to `rw` here and stays `rw` through Steps 12-15. ⚠️ `retry_policy.non_retryable_errors: [SchemaValidationError, RalphLoopMaxEscalationsError]` — TWO non-retryable error names; `RalphLoopMaxEscalationsError` is Build/Modernization-Generate-specific. ⚠️ Outputs use `**` recursive-glob patterns (`build/{app_id}/src/**`, `tests/**`, `compliance/**`). ⚠️ Escalation vocabulary, exact: "Refine Spec" / "Manual Augment" / "Re-Disposition" (return to Rationalization) — and explicitly **"There is no 'Re-Extract'."** "Fans out per bounded context exactly as Modernization does" — per-BC fan-out parallelism, though `parallel_with: []` (the fan-out is over bounded contexts, not sibling steps). The `application` side-effect (`build.` prefix): `[build.test_coverage_pct, build.ralph_loop_iterations, build.ralph_loop_escalations, build.generate_status]`. Note `traceability-matrix.md` is RE-emitted here (also a Step 1 output) — Generate refreshes it with the as-built trace.

---

### Step 12 — `commit-generate-artifacts` (build.yaml:513-542)

- **id:** `commit-generate-artifacts`
- **label:** `Commit Generate Artifacts`
- **kind:** `git`
- **scope:** `per-app`
- **sequence:** `12`
- **progress_pct:** `88`
- **purpose** (folded, build.yaml:519-521):
  > Commit generated source, tests, coverage, accessibility, security, and compliance artifacts to the target repo on the per-app branch.
- **skills:** `[]` (empty)
- **agent_role:** `null`
- **inputs.artifacts:**
  - `build/{app_id}/src/**`
  - `build/{app_id}/tests/**`
  - `build/{app_id}/generate/**`
- **inputs.context:** `[wave_id, app_id]`
- **outputs.artifacts:** `[]` (empty)
- **outputs.side_effects:** `[]` (empty)
- **agent_contract.mcp_servers:** `[]` (empty)
- **agent_contract.repos:** `artifact: rw`, `source: none`, `target: rw`
- **parallel_with:** `[]` (empty)
- **gate:** `null`
- **retry_policy.category:** `transient`

⚠️ GOTCHA — `target: rw` (commits land in the target repo, not the artifact repo). ⚠️ `artifact: rw` AND `target: rw` both set (the only commit step with both) — it reads artifact-repo design/spec context and writes generated code to the target repo. Recursive-glob inputs (`src/**`, `tests/**`, `generate/**`). `transient` retry, no side-effect.

---

### Step 13 — `create-g-new-3-pr` (build.yaml:544-574)

- **id:** `create-g-new-3-pr`
- **label:** `Create G-NEW-3 Review PR`
- **kind:** `git`
- **scope:** `per-app`
- **sequence:** `13`
- **progress_pct:** `90`
- **purpose** (folded, build.yaml:550-554):
  > Open the Generate gate-review PR against the target repo main. PR body aggregates the coverage report, acceptance-criteria coverage, accessibility and security scan summaries, structure-vs-design conformance, and Ralph Loop metrics. Tier-1 PRs tag EA board + security officer.
- **skills:** `[]` (empty)
- **agent_role:** `null`
- **inputs.artifacts:**
  - `build/{app_id}/generate/coverage-report.json`
  - `build/{app_id}/metrics/ralph-loop-metrics.yaml`
- **inputs.context:** `[wave_id, app_id, risk_tier]`
- **outputs.artifacts:** `[]` (empty)
- **outputs.side_effects:** `[]` (empty)
- **agent_contract.mcp_servers:** `[]` (empty)
- **agent_contract.repos:** `artifact: none`, `source: none`, `target: rw`
- **parallel_with:** `[]` (empty)
- **gate:** `null`
- **retry_policy.category:** `transient`

⚠️ GOTCHA — `repos.artifact: none` (FIRST step where artifact-repo access drops to `none`): this PR is opened against the **target repo main** (`target: rw`), and does not touch the artifact repo (`artifact: none`). Steps 13, 14, 15 all use `artifact: none, source: none, target: rw` — the Generate-gate trio operates purely on the target repo. "Tier-1 PRs tag EA board + security officer" (prose routing).

---

### Step 14 — `generate-gate-readiness-check` (build.yaml:576-611)

- **id:** `generate-gate-readiness-check`
- **label:** `Generate AI Gate Readiness Check`
- **kind:** `agent`
- **scope:** `per-app`
- **sequence:** `14`
- **progress_pct:** `92`
- **role:** `pre-review`
- **purpose** (folded, build.yaml:583-587):
  > Advisory readiness check before G-NEW-3 human review — flags likely blocker findings (coverage below threshold, P1 scenarios without automated tests, critical accessibility/security findings, structure drift from the Step 2 module map). Single-attempt.
- **skills:** `[gate-pre-review]`
- **agent_role:** `olympus-agent`
- **inputs.artifacts:**
  - `build/{app_id}/generate/coverage-report.json`
  - `build/{app_id}/generate/security-scan-report.json`
- **inputs.context:** `[wave_id, app_id, risk_tier]`
- **outputs.artifacts:**
  - `build/{app_id}/generate/pre-review.json`
- **outputs.side_effects:**
  - **target:** `gate_pre_review`
    **fields:** `[gate_id, findings_json]`
- **agent_contract.mcp_servers:** `[olympus]`
- **agent_contract.repos:** `artifact: none`, `source: none`, `target: rw`
- **parallel_with:** `[]` (empty)
- **gate:** `null`
- **retry_policy.category:** `agent_failure`
- **retry_policy.max_attempts_override:** `1`

⚠️ GOTCHA — THIRD `role: pre-review` step (NOT `summary`, unlike Step 9). `max_attempts_override: 1`. Excluded from `evidence_steps()` (pre-review). ⚠️ `repos.artifact: none, target: rw` — operates on the target repo only (writes `pre-review.json` into `build/{app_id}/generate/`, which is the generated-code workspace). Skill `gate-pre-review` (shared). Side-effect target `gate_pre_review` `[gate_id, findings_json]`.

---

### Step 15 — `gate-review-new-3` (build.yaml:613-651)

- **id:** `gate-review-new-3`
- **label:** `G-NEW-3 Code & Test Review`
- **kind:** `gate`
- **scope:** `per-app`
- **sequence:** `15`
- **progress_pct:** `96`
- **purpose** (folded, build.yaml:619-625):
  > Human review of the generated code. Equivalent rigor to G-04c. Dual/triple-signal model — PM merges the PR (gate_approved) AND for Tier-1 both StakeholderApprovedSignal(scope="g-new-3-ea") (EA adherence) AND scope="g-new-3-security" (security review). Rejection loops back through Generate (Refine Spec / Manual Augment / Re-Disposition; never Re-Extract), up to 3 rework iterations.
- **skills:** `[]` (empty)
- **agent_role:** `null`
- **inputs.artifacts:**
  - `build/{app_id}/generate/coverage-report.json`
  - `build/{app_id}/generate/pre-review.json`
- **inputs.context:** `[wave_id, app_id, risk_tier]`
- **outputs.artifacts:** `[]` (empty)
- **outputs.side_effects:**
  - **target:** `gate_record`
    **fields:** `[gate_id, status, approved_by, approved_at]`
  - **target:** `application`
    **fields:** `[build.generated_module_refs, build.generate_gate_status]`
- **agent_contract.mcp_servers:** `[]` (empty)
- **agent_contract.repos:** `artifact: none`, `source: none`, `target: rw`
- **parallel_with:** `[]` (empty)
- **gate:** `G-NEW-3`
- **retry_policy.category:** `validation_failure`

⚠️ GOTCHA — TERMINAL GATE, DUAL/TRIPLE-SIGNAL (the most complex Build step). `gate: G-NEW-3`, `validation_failure`. ⚠️ Approval model is **dual or triple signal depending on tier**:
  - Always: PM merges the PR (`gate_approved`).
  - For Tier-1 ONLY: ALSO BOTH `StakeholderApprovedSignal(scope="g-new-3-ea")` (EA adherence) AND `StakeholderApprovedSignal(scope="g-new-3-security")` (security review). So a Tier-1 app needs THREE signals (PM + EA + security); a non-Tier-1 app needs ONE (PM merge). This is the only Build gate with a triple-signal possibility.
  - ⚠️ TWO side-effect targets: `gate_record` `[gate_id, status, approved_by, approved_at]` + `application` `[build.generated_module_refs, build.generate_gate_status]` (`build.` prefix).
  - `repos.artifact: none, target: rw` — terminal review on the target repo.
  - Rejection loops back through `generate` (Step 11): "Refine Spec / Manual Augment / Re-Disposition; **never Re-Extract**", up to 3 rework iterations. Equivalent rigor to G-04c.

---

## 3. Step-count verification (authoritative)

Loader output at HEAD (`from olympus_contracts.assembly_lines import get_line; get_line("Build")`):
- `len(get_line("Build").steps)` = **15**
- `summary_step().id` = `design-gate-readiness-check` (⚠️ a pre-review step — see Step 9)
- `agent_steps()` = 6 ids: `spec-from-requirements, spec-gate-readiness-check, design, design-gate-readiness-check, generate, generate-gate-readiness-check`
- `evidence_steps()` / `pass_order("Build")` = **3** ids: `spec-from-requirements, design, generate` (the three pre-review readiness checks are excluded because `role == "pre-review"`)
- gates = `[("G-NEW-1","Spec Review"), ("G-NEW-2","Design Review"), ("G-NEW-3","Code & Test Review")]`

`grep -n "^  - id:" build.yaml` returns **18** matches at lines: 39, 41, 43, 67, 117, 149, 180, 217, 262, 317, 346, 376, 413, 454, 513, 544, 576, 613.
- Lines **39, 41, 43** are under top-level `gates:` (`G-NEW-1`, `G-NEW-2`, `G-NEW-3`) — gate definitions, NOT steps.
- Lines **67 → 613** (15 entries) are under `steps:` — these are the actual steps, `sequence: 1` … `sequence: 15`.

⚠️ NOTE on the brief's "EXACTLY 18 steps": the live source file (`olympus-contracts/olympus_contracts/data/assembly-lines/build.yaml`, 651 lines, read end-to-end) contains **15 steps** under `steps:` plus **3 gate definitions** under `gates:`. The total of `- id:` tokens at the 2-space indent is **18** (15 steps + 3 gates), which is the origin of the "18" figure — it counts all `- id:` lines including the three gate-definition ids. There is no step with `sequence` 16, 17, or 18; the file's final step is `gate-review-new-3` at `sequence: 15` ending at build.yaml:651 (last byte). Every step in the file has been reproduced in full above. None were dropped, collapsed, or summarized.

For completeness, the three gate-definition `- id:` entries (under `gates:`, build.yaml:38-44, already covered in §1):
- **gates[0]:** `id: G-NEW-1`, `label: Spec Review` (build.yaml:39-40)
- **gates[1]:** `id: G-NEW-2`, `label: Design Review` (build.yaml:41-42)
- **gates[2]:** `id: G-NEW-3`, `label: Code & Test Review` (build.yaml:43-44)

---

## 4. Cross-step ordering & dependency summary (for rebuild fidelity)

Sequence order (1→15) with kind and gate/loop structure — a clean 3-stage pipeline (Spec / Design / Generate), each stage = 5 steps (agent producer → git commit → git PR → pre-review check → gate decision):

**Stage 1 — Spec (G-NEW-1):**
1. `spec-from-requirements` (agent) — produces scenario-spec, business-rules-catalog, traceability-matrix; `application` side-effect (build.spec_*); `non_retryable: [SchemaValidationError]`
2. `commit-spec-artifacts` (git) — glob commit; no side-effect
3. `create-g-new-1-pr` (git) — opens Spec PR; no side-effect
4. `spec-gate-readiness-check` (agent, **role: pre-review**, max_attempts 1) — `gate_pre_review` side-effect
5. `gate-review-new-1` (gate **G-NEW-1**) — TWO side-effect targets (gate_record + application build.spec_ref/spec_gate_status); Tier-1 needs StakeholderApprovedSignal scope="g-new-1-stakeholder"; rejection = "Refine Spec" → Step 1 (≤3 iterations)

**Stage 2 — Design (G-NEW-2):**
6. `design` (agent, **4 skills** reused from Modernization) — six design artifacts; `application` side-effect (build.contexts_count/api_endpoints_count/design_traceability_pct); `non_retryable: [SchemaValidationError]`
7. `commit-design-artifacts` (git) — glob commit; plain-scalar purpose
8. `create-g-new-2-pr` (git) — opens Design PR; no side-effect
9. `design-gate-readiness-check` (agent, **role: pre-review** + **summary: true**, max_attempts 1) — ⚠️ THE LINE'S `summary_step`; `gate_pre_review` side-effect
10. `gate-review-new-2` (gate **G-NEW-2**) — TWO side-effect targets (gate_record + application build.design_ref/design_gate_status); single PM signal (Architecture Lead via PR comments); rejection → Step 6 (≤3 iterations)

**Stage 3 — Generate (G-NEW-3); `target: rw` from here on:**
11. `generate` (agent, **5 skills** = Ralph Loop + escalation-handler) — FIRST `target: rw`; src/**, tests/**, coverage/508/security reports, compliance/**, ralph-loop-metrics; `application` side-effect (build.test_coverage_pct/ralph_loop_iterations/ralph_loop_escalations/generate_status); `non_retryable: [SchemaValidationError, RalphLoopMaxEscalationsError]`; fans out per bounded context
12. `commit-generate-artifacts` (git, artifact: rw + target: rw) — glob commit to target repo
13. `create-g-new-3-pr` (git, **artifact: none**, target: rw) — opens Generate PR against target repo main
14. `generate-gate-readiness-check` (agent, **role: pre-review**, artifact: none, target: rw, max_attempts 1) — `gate_pre_review` side-effect
15. `gate-review-new-3` (gate **G-NEW-3**, artifact: none, target: rw) — TERMINAL; TWO side-effect targets (gate_record + application build.generated_module_refs/generate_gate_status); **dual/triple-signal** (PM always; +EA +security for Tier-1); rejection → Step 11 (Refine Spec / Manual Augment / Re-Disposition; never Re-Extract; ≤3 iterations)

Repo access tri-state progression (`artifact / source / target`), all `source: none` (greenfield, no legacy source):
- Steps 1–10 (Spec + Design): `artifact: rw`, `target: none`.
- Step 11 `generate`: `artifact: rw`, `target: rw` (generated code → target repo).
- Step 12 `commit-generate-artifacts`: `artifact: rw`, `target: rw`.
- Steps 13–15 (Generate PR + pre-review + gate): `artifact: none`, `target: rw` (pure target-repo operations).

Side-effect targets across the line (3 distinct tables):
- `application` — `build.`-prefixed fields — Steps 1 (`build.spec_rule_count, build.spec_scenario_count, build.spec_coverage_pct`), 5 (`build.spec_ref, build.spec_gate_status`), 6 (`build.contexts_count, build.api_endpoints_count, build.design_traceability_pct`), 10 (`build.design_ref, build.design_gate_status`), 11 (`build.test_coverage_pct, build.ralph_loop_iterations, build.ralph_loop_escalations, build.generate_status`), 15 (`build.generated_module_refs, build.generate_gate_status`).
- `gate_pre_review` — fields `[gate_id, findings_json]` — Steps 4, 9, 14 (the three pre-review checks).
- `gate_record` — fields `[gate_id, status, approved_by, approved_at]` — Steps 5, 10, 15 (the three gate decisions). ⚠️ Build's gate_record vocabulary (`gate_id/status/approved_by/approved_at`) DIFFERS from Rationalization's (`state/decided_at/decided_by/decision_notes`) — distinct field sets, preserve each per line.
- ⚠️ Build's git commit steps (2, 7, 12) and PR-creation steps (3, 8, 13) declare **empty `outputs.side_effects: []`** — unlike Rationalization's commit steps, which write `artifact_repo` → `[commit_sha, branch]`. Build leaves them empty.

retry_policy.category by kind:
- `agent` steps → `agent_failure` (Steps 1, 4, 6, 9, 11, 14). Non-retryable error lists appear on Steps 1, 6 (`[SchemaValidationError]`) and 11 (`[SchemaValidationError, RalphLoopMaxEscalationsError]`). `max_attempts_override: 1` on the three pre-review checks (4, 9, 14).
- `git` steps → `transient` (Steps 2, 3, 7, 8, 12, 13).
- `gate` steps → `validation_failure` (Steps 5, 10, 15).
- ⚠️ Build has NO `kind: code` step (unlike Rationalization's `factory-routing`). Kinds present: `agent` (6), `git` (6), `gate` (3).

---

## 5. Anti-drift pins a regenerator must hold (Build-specific)

- `len(steps) == 15`; sequences 1–15 contiguous; `line_names()` returns 11 lines with Build present (sorts between Architecture and Data).
- `summary_step().id == "design-gate-readiness-check"` (a `role: pre-review` step) — NOT `design`/`generate`.
- `pass_order("Build") == ("spec-from-requirements","design","generate")` (3 evidence steps; pre-review checks excluded).
- `agent_steps()` count == 6; `evidence_steps()` count == 3.
- `Disposition.BUILD == "Build"` (enums.py:41) selects this line; `AssemblyLine` enum still has 10 members and does NOT contain `Build`; `GateType` still has 15 members and does NOT contain `G-NEW-1/2/3`.
- Skill reuse: `design` reuses Modernization's `[module-design, api-specification, data-modeling, traceability-audit]`; `generate` reuses `[tdd-generation, code-synthesis, adversarial-review, security-scan-review]` + adds `escalation-handler`. The only Build-original skill is `spec-from-requirements`; `gate-pre-review` is the shared readiness-check skill.
- Escalation vocabulary is "Refine Spec" / "Manual Augment" / "Re-Disposition"; the line NEVER offers "Re-Extract" (no legacy source).

---

STEP INVENTORY: spec-from-requirements, commit-spec-artifacts, create-g-new-1-pr, spec-gate-readiness-check, gate-review-new-1, design, commit-design-artifacts, create-g-new-2-pr, design-gate-readiness-check, gate-review-new-2, generate, commit-generate-artifacts, create-g-new-3-pr, generate-gate-readiness-check, gate-review-new-3

STEPS REPRODUCED: 18

(15 steps under `steps:` (sequences 1–15) + 3 gate definitions under `gates:` (G-NEW-1, G-NEW-2, G-NEW-3) = 18 total `- id:` entries reproduced. Ordered step id list: 1 spec-from-requirements · 2 commit-spec-artifacts · 3 create-g-new-1-pr · 4 spec-gate-readiness-check · 5 gate-review-new-1 · 6 design · 7 commit-design-artifacts · 8 create-g-new-2-pr · 9 design-gate-readiness-check · 10 gate-review-new-2 · 11 generate · 12 commit-generate-artifacts · 13 create-g-new-3-pr · 14 generate-gate-readiness-check · 15 gate-review-new-3.)
