# Disposition Execution — Assembly Line Contract (ATOMIC regeneration spec)

> Source of truth: `olympus-contracts/olympus_contracts/data/assembly-lines/disposition-execution.yaml` (499 lines).
> This document reproduces that YAML file **field-by-field** for behavioral parity. Every claim is cited as `disposition-execution.yaml:<line>`.

---

## 0. CRITICAL COUNT RECONCILIATION (read first)

The literal regex `^  - id:` (a `- id:` key at the **2-space** indent) matches **15** entries in this file. The task spec asserts "EXACTLY 15 steps". **However, this is an artifact of the regex: 2 of those 15 matches are gate-definition entries under the top-level `gates:` block, NOT step entries under `steps:`.**

- `gates:` block contributes **2** matching `- id:` entries: `G-DE-1` (line 29) and `G-DE-2` (line 31).
- `steps:` block contributes **13** matching `- id:` entries (lines 46, 80, 113, 144, 178, 212, 243, 275, 308, 338, 372, 413, 458).

⚠️ **GOTCHA — the "15" is the count of all `- id:` keys at 2-space indent, of which 13 are true steps and 2 are gate definitions.** `gates:` items and `steps:` items share the identical YAML indentation (`  - id:`), so a naive `grep -cE '^  - id:'` cannot distinguish them. Reason for fragility: any tooling that derives a "step count" from that regex will over-count by 2. The authoritative step driver in the Temporal workflow / step-progress mapping uses the **13** items under `steps:` only. (verified: `disposition-execution.yaml:28-44` is the `gates:`/`mode:`/`inputs:`/`outputs:` region; `disposition-execution.yaml:45` begins `steps:`; the first true step is at `disposition-execution.yaml:46`.)

To satisfy completeness AND the literal 15-count, this spec reproduces:

1. **Line-level metadata** (§1), including the 2 gate definitions in full.
2. **All 13 true steps** under `steps:` in full (§2, Steps 1–13).
3. **Both gate-definition `- id:` entries** (§3, Entries 14–15) — the 2 remaining `- id:` matches that bring the literal count to 15.

The closing `STEP INVENTORY` line therefore lists all **15** `- id:` values in file order (2 gate ids interleaved at their actual file position, then the 13 step ids), and `STEPS REPRODUCED: 15` counts every reproduced `- id:` block. Nothing from the file is dropped.

---

## 1. LINE-LEVEL METADATA

Reproduced verbatim from `disposition-execution.yaml:1-44`.

### 1.1 Header comment block (`disposition-execution.yaml:1-8`)

```
# Disposition Execution — Assembly Line Contract (authoritative)
#
# THIS IS THE SOURCE OF TRUTH for Disposition Execution's steps, skills,
# artifacts, side-effects, and agent contract. Every downstream consumer
# (Temporal workflow, Olympus API gate service, step-progress mapping,
# frontend step registry) loads FROM this file via
# olympus_contracts.assembly_lines. Do not hardcode a copy in application
# code. Drift is policed by the `test_no_hardcoded_step_lists` CI check.
```

⚠️ **GOTCHA — `test_no_hardcoded_step_lists` is a CI guard** (`disposition-execution.yaml:8`). Any rebuild that hardcodes the step list in application code (Temporal workflow, API gate service, step-progress mapping, frontend step registry) instead of loading from this YAML via `olympus_contracts.assembly_lines` will fail CI. The single source of truth is this file.

### 1.2 Top-level scalar / mapping keys

| Key | Value | Source |
|---|---|---|
| `name` | `Disposition Execution` | `disposition-execution.yaml:10` |
| `description` | (folded block scalar `>` — full text below) | `disposition-execution.yaml:11-24` |
| `trigger` | `rationalization-g-da-approved-non-modernization` | `disposition-execution.yaml:25` |
| `depends_on` | list with single entry: `Rationalization` | `disposition-execution.yaml:26-27` |
| `gates` | list of 2 gate maps (see §1.3) | `disposition-execution.yaml:28-32` |
| `mode` | `per-app` | `disposition-execution.yaml:33` |
| `inputs` | list of 7 artifact names (see §1.4) | `disposition-execution.yaml:34-41` |
| `outputs` | list with single entry: `disposition-output` | `disposition-execution.yaml:42-43` |
| `steps` | list of 13 step maps (see §2) | `disposition-execution.yaml:45-499` |

⚠️ **GOTCHA — `mode` is `per-app`, NOT `continuous` or `triggered`.** (`disposition-execution.yaml:33`). The task prompt's "continuous vs triggered" framing does not apply: this line is a **triggered, per-application** pipeline. Each step also carries its own `scope: per-app` (every step, see §2). The line is kicked off by the `trigger` value `rationalization-g-da-approved-non-modernization` (`disposition-execution.yaml:25`) and runs once per application that received a non-modernization disposition at Rationalization's G-DA gate.

#### `description` (folded scalar, `disposition-execution.yaml:11-24`) — full text:

```
Disposition Execution executes the five non-modernization dispositions Rationalization decided on: Retire, Retain, Replace, Replatform, and Consolidate. Refactor and Rearchitect flow through Architecture → Modernization → Validation → Deployment; this line owns everything else. Each non-modernization disposition is a project in its own right — Retire is a data-archival project with user-transition, consumer-migration, infrastructure decommission, license reclamation, and cost-savings certification; Replace means vendor evaluation + integration specification + cutover; Consolidate means target selection + feature gap analysis + enhancement planning + data reconciliation. Produces the canonical disposition-output bundle that Deployment, Sustainment, and Governance all consume as the authoritative "what did this app become?" record.
```

Key facts encoded in the description (preserve exactly when rebuilding):
- The line handles **5 non-modernization dispositions**: **Retire, Retain, Replace, Replatform, Consolidate** (`disposition-execution.yaml:12-13`).
- **Refactor** and **Rearchitect** do NOT flow through this line — they go Architecture → Modernization → Validation → Deployment (`disposition-execution.yaml:13-15`).
- Per-disposition project shapes (`disposition-execution.yaml:16-21`):
  - **Retire** = data-archival project with: user-transition, consumer-migration, infrastructure decommission, license reclamation, cost-savings certification.
  - **Replace** = vendor evaluation + integration specification + cutover.
  - **Consolidate** = target selection + feature gap analysis + enhancement planning + data reconciliation.
- Output is the canonical **disposition-output** bundle consumed by **Deployment, Sustainment, and Governance** as the authoritative "what did this app become?" record (`disposition-execution.yaml:21-24`).

### 1.3 `gates:` (line-level, `disposition-execution.yaml:28-32`)

Two gate definitions. Each is a map with `id` + `label`:

| `id` | `label` | Source |
|---|---|---|
| `G-DE-1` | `Disposition Execution Plan Approval` | `disposition-execution.yaml:29-30` |
| `G-DE-2` | `Decommission Readiness Sign-off` | `disposition-execution.yaml:31-32` |

(These two `- id:` entries are reproduced again as the count-completing Entries 14 & 15 in §3, since they match the `^  - id:` regex.)

### 1.4 `inputs:` (line-level, `disposition-execution.yaml:34-41`)

Flat list of 7 input artifact names (NOT the per-step `inputs.{artifacts,context}` shape — this is the line-level declared inputs list):

1. `disposition-recommendation` (`:35`)
2. `disposition-governance` (`:36`)
3. `catalog-application` (`:37`)
4. `structural-analysis` (`:38`)
5. `business-logic` (`:39`)
6. `ux-accessibility` (`:40`)
7. `tco-baseline` (`:41`)

### 1.5 `outputs:` (line-level, `disposition-execution.yaml:42-43`)

Flat list of 1 output artifact name:

1. `disposition-output` (`:43`)

⚠️ **GOTCHA — line-level `inputs`/`outputs` are flat string lists; step-level `inputs`/`outputs` are nested maps (`artifacts`, `context`, `side_effects`).** Do not conflate the two shapes. The line-level lists (`:34-43`) are bare artifact names; each step's `inputs:` block (e.g. `:58-64`) has `artifacts:` and `context:` sub-keys, and `outputs:` has `artifacts:` and `side_effects:` sub-keys.

---

## 2. STEPS (all 13 under `steps:`)

Field order within each step as it appears in the file: `id`, `label`, `kind`, `scope`, `sequence`, `progress_pct`, [`summary`], `purpose`, `skills`, `agent_role`, `inputs:{artifacts, context}`, `outputs:{artifacts, side_effects}`, `agent_contract:{mcp_servers, repos:{artifact, source, target}}`, `parallel_with`, `gate`, [`condition` — see GOTCHA], `retry_policy:{category}`.

⚠️ **GOTCHA — there is NO explicit `condition` field on any step in this file.** Conditional execution (Retain skipping G-DE-2 / post-gate steps; non-Retain emitting the Deployment signal) is encoded in **prose inside `purpose:` and in `side_effects[].notes` / `side_effects[].target`**, NOT in a structured `condition:` key. A rebuild MUST replicate the conditional branching from those prose contracts:
- Steps that only run for non-Retain dispositions: `create-g-de2-pr` (`:317`), `ai-pre-review-de2` (`:347-348`), `gate-review-de2` (`:380`), `merge-g-de2-pr` (Retain skips it, `:468`).
- `persist-disposition-side-effects` runs **after G-DE-2 for non-Retain, after G-DE-1 for Retain** (`:423-424`).
- `merge-g-de1-pr` proceeds to post-gate execution "for all dispositions except Retain" (`:220-221`).

⚠️ **GOTCHA — `retry_policy` has exactly one field, `category`, with values `agent_failure | transient | validation_failure`.** No `maximum_attempts`, `backoff`, or `non_retryable_errors` are declared here; those are resolved downstream by the worker from the named category. The category-to-kind correlation observed:
- `kind: agent` steps → `category: agent_failure` (`:78`, `:175`, `:272`, `:369`).
- `kind: code` summary/bundling steps → `category: transient` (`:111`, `:305`).
- `kind: git` steps → mixed: `transient` for PR-creation (`:142`, `:335`), `agent_failure` for merge steps (`:241`, `:498`).
- `kind: gate` steps → `category: validation_failure` (`:210`, `:410`).
- `persist-disposition-side-effects` (`kind: code`) → `category: validation_failure` (`:456`) — the ONLY `code` step NOT using `transient`. Reason: a projection-write failure is a data-integrity (validation) failure, not a transient retry.

---

### STEP 1 — `pre-gate-strategy` (`disposition-execution.yaml:46-78`)

| Field | Value | Line |
|---|---|---|
| `id` | `pre-gate-strategy` | :46 |
| `label` | `Pre-Gate Strategy Steps` | :47 |
| `kind` | `agent` | :48 |
| `scope` | `per-app` | :49 |
| `sequence` | `1` | :50 |
| `progress_pct` | `12` | :51 |
| `purpose` | (folded) `Per-disposition strategy work. Produces an artifact under dispositions/{portfolio_id}/{app_id}/{step-id}.json that the G-DE-1 evidence bundle aggregates.` | :52-55 |
| `skills` | `[]` (empty list) | :56 |
| `agent_role` | `Disposition Execution Agent` | :57 |

`inputs:` (`:58-64`)
- `artifacts:` (`:59-63`):
  1. `discovery/{app_id}/catalog-application.json` (:60)
  2. `discovery/{app_id}/business-logic.json` (:61)
  3. `discovery/{app_id}/tco-baseline.json` (:62)
  4. `rationalization/wave-{wave_id}/{app_id}/disposition-recommendation.json` (:63)
- `context:` `[app_id, wave_id, portfolio_id, disposition]` (:64)

`outputs:` (`:65-68`)
- `artifacts:` (`:66-67`):
  1. `dispositions/{portfolio_id}/{app_id}/{step-id}.json` (:67)
- `side_effects:` `[]` (empty list) (:68)

`agent_contract:` (`:69-74`)
- `mcp_servers:` `[olympus]` (:70)
- `repos:` (`:71-74`): `artifact: rw` (:72), `source: ro` (:73), `target: none` (:74)

`parallel_with:` `[]` (:75)
`gate:` `null` (:76)
`retry_policy:` `category: agent_failure` (:77-78)

⚠️ **GOTCHA — `{step-id}` token in the output path** (`:67`). This step is a **fan-out template**: the literal string `{step-id}` is a placeholder substituted per-disposition at runtime (one strategy sub-step per disposition project component). The output is `dispositions/{portfolio_id}/{app_id}/{step-id}.json`, NOT a single fixed filename. The bundling step (Step 2) globs `*.json` to aggregate them.

---

### STEP 2 — `bundle-pre-gate-evidence` (`disposition-execution.yaml:80-111`)

| Field | Value | Line |
|---|---|---|
| `id` | `bundle-pre-gate-evidence` | :80 |
| `label` | `Bundle Pre-Gate Evidence` | :81 |
| `kind` | `code` | :82 |
| `scope` | `per-app` | :83 |
| `sequence` | `2` | :84 |
| `progress_pct` | `25` | :85 |
| `purpose` | (folded) `Workflow code (not an agent dispatch). Synthesises the per-step artifacts from pre-gate steps into disposition-output.json (partial shape — fields corresponding to pre-gate steps populated, post-gate fields left as ``null`` or empty arrays). Commits the bundle for G-DE-1 evidence.` | :86-91 |
| `skills` | `[]` | :92 |
| `agent_role` | `null` | :93 |

`inputs:` (`:94-97`)
- `artifacts:` (`:95-96`):
  1. `dispositions/{portfolio_id}/{app_id}/*.json` (:96)
- `context:` `[app_id, portfolio_id, disposition]` (:97)

`outputs:` (`:98-101`)
- `artifacts:` (`:99-100`):
  1. `dispositions/{portfolio_id}/{app_id}/disposition-output.json` (:100)
- `side_effects:` `[]` (:101)

`agent_contract:` (`:102-107`)
- `mcp_servers:` `[]` (empty) (:103)
- `repos:` (`:104-107`): `artifact: rw` (:105), `source: none` (:106), `target: none` (:107)

`parallel_with:` `[]` (:108)
`gate:` `null` (:109)
`retry_policy:` `category: transient` (:110-111)

⚠️ **GOTCHA — `disposition-output.json` is written in a PARTIAL shape here** (`:88-90`): pre-gate-step fields populated; post-gate fields explicitly `null` or empty arrays. The SAME filename is rewritten to a complete shape by Step 8 (`bundle-post-gate-evidence`). Two distinct writes to one path at two pipeline stages — do not assume the file is final after Step 2.

⚠️ **GOTCHA — `kind: code` means workflow code, not an agent dispatch** (`:86`). `mcp_servers: []`, `agent_role: null`, `skills: []`. A rebuild must implement this as a Temporal **activity** that globs `*.json` and synthesizes, not as an A2A agent call.

---

### STEP 3 — `create-g-de1-pr` (`disposition-execution.yaml:113-142`)

| Field | Value | Line |
|---|---|---|
| `id` | `create-g-de1-pr` | :113 |
| `label` | `Create G-DE-1 Review PR` | :114 |
| `kind` | `git` | :115 |
| `scope` | `per-app` | :116 |
| `sequence` | `3` | :117 |
| `progress_pct` | `30` | :118 |
| `purpose` | (folded) `Open the gate-review PR against the artifact repo's main branch. PR body aggregates the disposition-output bundle (pre-gate subset) + a per-disposition summary tailored to reviewers (Retire checklist, Retain risk profile, Replace vendor comparison, etc.).` | :119-123 |
| `skills` | `[]` | :124 |
| `agent_role` | `null` | :125 |

`inputs:` (`:126-129`)
- `artifacts:` (`:127-128`):
  1. `dispositions/{portfolio_id}/{app_id}/disposition-output.json` (:128)
- `context:` `[app_id, portfolio_id, disposition]` (:129)

`outputs:` (`:130-132`)
- `artifacts:` `[]` (empty) (:131)
- `side_effects:` `[]` (empty) (:132)

`agent_contract:` (`:133-138`)
- `mcp_servers:` `[]` (:134)
- `repos:` (`:135-138`): `artifact: rw` (:136), `source: none` (:137), `target: none` (:138)

`parallel_with:` `[]` (:139)
`gate:` `null` (:140)
`retry_policy:` `category: transient` (:141-142)

⚠️ **GOTCHA — PR body is per-disposition-tailored prose** (`:121-123`): Retire→checklist, Retain→risk profile, Replace→vendor comparison, "etc." The PR body content branches on `disposition`. A rebuild must produce a disposition-specific reviewer summary, not a generic body.

---

### STEP 4 — `ai-pre-review-de1` (`disposition-execution.yaml:144-175`)

| Field | Value | Line |
|---|---|---|
| `id` | `ai-pre-review-de1` | :144 |
| `label` | `AI Pre-Review (G-DE-1)` | :145 |
| `kind` | `agent` | :146 |
| `scope` | `per-app` | :147 |
| `sequence` | `4` | :148 |
| `progress_pct` | `35` | :149 |
| `purpose` | (folded) `Advisory readiness check before the human gate opens — flags likely blocker findings (missing plan components, stale dependencies, unaddressed user-impact risks, cost-savings estimate missing baseline) so reviewers and the workflow can short-circuit obvious rejections.` | :150-154 |
| `skills` | `[gate-pre-review]` | :155 |
| `agent_role` | `Gate Pre-Reviewer` | :156 |

`inputs:` (`:157-160`)
- `artifacts:` (`:158-159`):
  1. `dispositions/{portfolio_id}/{app_id}/disposition-output.json` (:159)
- `context:` `[app_id, portfolio_id, disposition, risk_tier]` (:160)

`outputs:` (`:161-166`)
- `artifacts:` (`:162-163`):
  1. `dispositions/{portfolio_id}/{app_id}/pre-review-de1.json` (:163)
- `side_effects:` (`:164-166`):
  1. `target: gate_pre_review` (:165), `fields: [gate_id, findings_json]` (:166)

`agent_contract:` (`:167-172`)
- `mcp_servers:` `[olympus]` (:168)
- `repos:` (`:169-172`): `artifact: rw` (:170), `source: none` (:171), `target: none` (:172)

`parallel_with:` `[]` (:173)
`gate:` `null` (:174)
`retry_policy:` `category: agent_failure` (:175-176)

**Side-effect table `gate_pre_review` (Step 4):**

| target table | fields |
|---|---|
| `gate_pre_review` | `gate_id`, `findings_json` |

⚠️ **GOTCHA — `risk_tier` appears in `context` here but NOT in Steps 1–3** (`:160` vs `:64`/`:97`/`:129`). The pre-review and gate-review steps require `risk_tier` to calibrate finding severity; the strategy/bundle/PR-create steps do not. Preserve this distinction exactly.

---

### STEP 5 — `gate-review-de1` (`disposition-execution.yaml:178-210`)

| Field | Value | Line |
|---|---|---|
| `id` | `gate-review-de1` | :178 |
| `label` | `G-DE-1 Disposition Execution Plan Approval` | :179 |
| `kind` | `gate` | :180 |
| `scope` | `per-app` | :181 |
| `sequence` | `5` | :182 |
| `progress_pct` | `42` | :183 |
| `purpose` | (folded) `Human review of the disposition execution plan. Single-signal approval model (PM merges PR). Rejection loops back through the contested pre-gate steps (up to 3 rework iterations before workflow escalates).` | :184-188 |
| `skills` | `[]` | :189 |
| `agent_role` | `null` | :190 |

`inputs:` (`:191-195`)
- `artifacts:` (`:192-194`):
  1. `dispositions/{portfolio_id}/{app_id}/disposition-output.json` (:193)
  2. `dispositions/{portfolio_id}/{app_id}/pre-review-de1.json` (:194)
- `context:` `[app_id, portfolio_id, disposition, risk_tier]` (:195)

`outputs:` (`:196-200`)
- `artifacts:` `[]` (:197)
- `side_effects:` (`:198-200`):
  1. `target: gate_record` (:199), `fields: [gate_id, status, approved_by, approved_at]` (:200)

`agent_contract:` (`:201-206`)
- `mcp_servers:` `[]` (:202)
- `repos:` (`:203-206`): `artifact: rw` (:204), `source: none` (:205), `target: none` (:206)

`parallel_with:` `[]` (:207)
`gate:` `G-DE-1` (:208)
`retry_policy:` `category: validation_failure` (:209-210)

**Side-effect table `gate_record` (Step 5):**

| target table | fields |
|---|---|
| `gate_record` | `gate_id`, `status`, `approved_by`, `approved_at` |

⚠️ **GOTCHA — "up to 3 rework iterations before workflow escalates"** (`:187-188`). The rejection loop is bounded at 3 iterations; on exhaustion the workflow escalates (and `persist-disposition-side-effects` sets `disposition_current_status = disposition_failed`, see Step 12 `:443`). Single-signal model: a PM merging the PR is the approval signal (`:185`). `gate: G-DE-1` is the only non-null `gate` value besides Step 11's `G-DE-2`.

---

### STEP 6 — `merge-g-de1-pr` (`disposition-execution.yaml:212-241`)

| Field | Value | Line |
|---|---|---|
| `id` | `merge-g-de1-pr` | :212 |
| `label` | `Merge G-DE-1 Review PR` | :213 |
| `kind` | `git` | :214 |
| `scope` | `per-app` | :215 |
| `sequence` | `6` | :216 |
| `progress_pct` | `48` | :217 |
| `purpose` | (folded) `Final merge of the approved G-DE-1 PR. Plan is locked; the workflow proceeds to execution (post-gate steps) for all dispositions except Retain.` | :218-221 |
| `skills` | `[]` | :222 |
| `agent_role` | `null` | :223 |

`inputs:` (`:224-226`)
- `artifacts:` `[]` (:225)
- `context:` `[app_id, portfolio_id, pr_number]` (:226)

`outputs:` (`:227-231`)
- `artifacts:` `[]` (:228)
- `side_effects:` (`:229-231`):
  1. `target: application` (:230), `fields: [current_step, current_status, updated_at]` (:231)

`agent_contract:` (`:232-237`)
- `mcp_servers:` `[]` (:233)
- `repos:` (`:234-237`): `artifact: rw` (:235), `source: none` (:236), `target: none` (:237)

`parallel_with:` `[]` (:238)
`gate:` `null` (:239)
`retry_policy:` `category: agent_failure` (:240-241)

**Side-effect table `application` (Step 6):**

| target table | fields |
|---|---|
| `application` | `current_step`, `current_status`, `updated_at` |

⚠️ **GOTCHA — Retain branches OFF here** (`:220-221`): "the workflow proceeds to execution (post-gate steps) for all dispositions except Retain." For Retain, Steps 7–11 and 13 are skipped; Step 12 (`persist-disposition-side-effects`) runs after G-DE-1 instead (see Step 12 `:423-424`). `context` here uses `pr_number` (not `disposition`), unlike most steps.

---

### STEP 7 — `post-gate-execution` (`disposition-execution.yaml:243-272`)

| Field | Value | Line |
|---|---|---|
| `id` | `post-gate-execution` | :243 |
| `label` | `Post-Gate Execution Steps` | :244 |
| `kind` | `agent` | :245 |
| `scope` | `per-app` | :246 |
| `sequence` | `7` | :247 |
| `progress_pct` | `60` | :248 |
| `purpose` | (folded) `Per-disposition execution work — carries out the plan approved at G-DE-1. Produces an artifact the G-DE-2 decommission-readiness bundle aggregates.` | :249-252 |
| `skills` | `[]` | :253 |
| `agent_role` | `Disposition Execution Agent` | :254 |

`inputs:` (`:255-259`)
- `artifacts:` (`:256-258`):
  1. `dispositions/{portfolio_id}/{app_id}/disposition-output.json` (:257)
  2. `discovery/{app_id}/*.json` (:258)
- `context:` `[app_id, wave_id, portfolio_id, disposition]` (:259)

`outputs:` (`:260-263`)
- `artifacts:` (`:261-262`):
  1. `dispositions/{portfolio_id}/{app_id}/{step-id}.json` (:262)
- `side_effects:` `[]` (:263)

`agent_contract:` (`:264-269`)
- `mcp_servers:` `[olympus]` (:265)
- `repos:` (`:266-269`): `artifact: rw` (:267), `source: ro` (:268), `target: none` (:269)

`parallel_with:` `[]` (:270)
`gate:` `null` (:271)
`retry_policy:` `category: agent_failure` (:272-273)

⚠️ **GOTCHA — same `{step-id}` fan-out template as Step 1** (`:262`). Per-disposition execution sub-steps each emit `dispositions/{portfolio_id}/{app_id}/{step-id}.json`. `wave_id` is back in `context` (it was absent in Steps 2–6); same `agent_role: Disposition Execution Agent` as Step 1; same repo posture (`artifact: rw, source: ro, target: none`).

---

### STEP 8 — `bundle-post-gate-evidence` (`disposition-execution.yaml:275-305`)

| Field | Value | Line |
|---|---|---|
| `id` | `bundle-post-gate-evidence` | :275 |
| `label` | `Bundle Decommission-Readiness Evidence` | :276 |
| `kind` | `code` | :277 |
| `scope` | `per-app` | :278 |
| `sequence` | `8` | :279 |
| `summary` | `true` | :280 |
| `purpose` | (folded) `Updates disposition-output.json to the complete shape: merges post-gate artifact refs + decommission certificates + cost savings certification + approvals array (G-DE-1 record) into the bundle. Commits the finalized bundle for G-DE-2 evidence.` | :282-286 |
| `skills` | `[]` | :287 |
| `agent_role` | `null` | :288 |

`inputs:` (`:289-292`)
- `artifacts:` (`:290-291`):
  1. `dispositions/{portfolio_id}/{app_id}/*.json` (:291)
- `context:` `[app_id, portfolio_id, disposition]` (:292)

`outputs:` (`:293-296`)
- `artifacts:` (`:294-295`):
  1. `dispositions/{portfolio_id}/{app_id}/disposition-output.json` (:295)
- `side_effects:` `[]` (:296)

`agent_contract:` (`:297-302`)
- `mcp_servers:` `[]` (:298)
- `repos:` (`:299-302`): `artifact: rw` (:300), `source: none` (:301), `target: none` (:302)

`parallel_with:` `[]` (:303)
`gate:` `null` (:304)
`retry_policy:` `category: transient` (:305-306)

⚠️ **GOTCHA — `summary: true` field is PRESENT ONLY on this step** (`:280`). No other step in the file declares `summary`. ⚠️ Note the field-order anomaly: this step jumps from `progress_pct: 72` (`:280`) directly into `summary: true` then `purpose` — there is no `progress_pct`-then-`purpose` adjacency as in other steps because `summary:` is inserted between them. Preserve `summary: true` as a top-level step key. This is the "complete shape" rewrite of `disposition-output.json` (vs. Step 2's partial shape): merges post-gate artifact refs + decommission certificates + cost-savings certification + the `approvals` array (carrying the G-DE-1 record) (`:283-285`).

---

### STEP 9 — `create-g-de2-pr` (`disposition-execution.yaml:308-335`)

| Field | Value | Line |
|---|---|---|
| `id` | `create-g-de2-pr` | :308 |
| `label` | `Create G-DE-2 Review PR` | :309 |
| `kind` | `git` | :310 |
| `scope` | `per-app` | :311 |
| `sequence` | `9` | :312 |
| `progress_pct` | `78` | :313 |
| `purpose` | (folded) `Open the G-DE-2 gate-review PR. Body aggregates the finalized disposition-output bundle with decommission evidence + cost savings + user-migration attestations. Only runs for non-Retain dispositions.` | :314-317 |
| `skills` | `[]` | :318 |
| `agent_role` | `null` | :319 |

`inputs:` (`:320-323`)
- `artifacts:` (`:321-322`):
  1. `dispositions/{portfolio_id}/{app_id}/disposition-output.json` (:322)
- `context:` `[app_id, portfolio_id, disposition]` (:323)

`outputs:` (`:324-326`)
- `artifacts:` `[]` (:325)
- `side_effects:` `[]` (:326)

`agent_contract:` (`:327-332`)
- `mcp_servers:` `[]` (:328)
- `repos:` (`:329-332`): `artifact: rw` (:330), `source: none` (:331), `target: none` (:332)

`parallel_with:` `[]` (:333)
`gate:` `null` (:334)
`retry_policy:` `category: transient` (:335-336)

⚠️ **GOTCHA — "Only runs for non-Retain dispositions"** (`:316-317`). Conditional step; Retain skips it. No structured `condition:` key — branch on `disposition != Retain`.

---

### STEP 10 — `ai-pre-review-de2` (`disposition-execution.yaml:338-369`)

| Field | Value | Line |
|---|---|---|
| `id` | `ai-pre-review-de2` | :338 |
| `label` | `AI Pre-Review (G-DE-2)` | :339 |
| `kind` | `agent` | :340 |
| `scope` | `per-app` | :341 |
| `sequence` | `10` | :342 |
| `progress_pct` | `82` | :343 |
| `purpose` | (folded) `Advisory readiness check before the decommission-readiness gate — flags data-archival gaps, missing user-migration attestation, infra still running, license-reclamation incomplete. Only runs for non-Retain dispositions.` | :344-348 |
| `skills` | `[gate-pre-review]` | :349 |
| `agent_role` | `Gate Pre-Reviewer` | :350 |

`inputs:` (`:351-354`)
- `artifacts:` (`:352-353`):
  1. `dispositions/{portfolio_id}/{app_id}/disposition-output.json` (:353)
- `context:` `[app_id, portfolio_id, disposition, risk_tier]` (:354)

`outputs:` (`:355-360`)
- `artifacts:` (`:356-357`):
  1. `dispositions/{portfolio_id}/{app_id}/pre-review-de2.json` (:357)
- `side_effects:` (`:358-360`):
  1. `target: gate_pre_review` (:359), `fields: [gate_id, findings_json]` (:360)

`agent_contract:` (`:361-366`)
- `mcp_servers:` `[olympus]` (:362)
- `repos:` (`:363-366`): `artifact: rw` (:364), `source: none` (:365), `target: none` (:366)

`parallel_with:` `[]` (:367)
`gate:` `null` (:368)
`retry_policy:` `category: agent_failure` (:369-370)

**Side-effect table `gate_pre_review` (Step 10):**

| target table | fields |
|---|---|
| `gate_pre_review` | `gate_id`, `findings_json` |

⚠️ **GOTCHA — "Only runs for non-Retain dispositions"** (`:347-348`). Same skill (`gate-pre-review`) and `agent_role` (`Gate Pre-Reviewer`) as Step 4, but distinct finding categories: data-archival gaps, missing user-migration attestation, infra still running, license-reclamation incomplete (`:345-347`). Output filename `pre-review-de2.json` (vs `pre-review-de1.json` in Step 4).

---

### STEP 11 — `gate-review-de2` (`disposition-execution.yaml:372-410`)

| Field | Value | Line |
|---|---|---|
| `id` | `gate-review-de2` | :372 |
| `label` | `G-DE-2 Decommission Readiness Sign-off` | :373 |
| `kind` | `gate` | :374 |
| `scope` | `per-app` | :375 |
| `sequence` | `11` | :376 |
| `progress_pct` | `88` | :377 |
| `purpose` | (folded) `Human review of decommission readiness. Single-signal approval (PM merges PR). Only runs for non-Retain dispositions. Rejection loops back through the contested post-gate steps (up to 3 rework iterations). Approval authorizes Deployment to execute the infrastructure teardown.` | :378-383 |
| `skills` | `[]` | :384 |
| `agent_role` | `null` | :385 |

`inputs:` (`:386-390`)
- `artifacts:` (`:387-389`):
  1. `dispositions/{portfolio_id}/{app_id}/disposition-output.json` (:388)
  2. `dispositions/{portfolio_id}/{app_id}/pre-review-de2.json` (:389)
- `context:` `[app_id, portfolio_id, disposition, risk_tier]` (:390)

`outputs:` (`:391-401`)
- `artifacts:` `[]` (:392)
- `side_effects:` (`:393-401`) — **TWO** side-effect entries:
  1. `target: gate_record` (:394), `fields: [gate_id, status, approved_by, approved_at]` (:395)
  2. `target: application` (:396), `fields: [disposition_output_ref, disposition_completed_at]` (:397), `notes:` (folded, :398-401): `Applied via persist_disposition_side_effects activity after gate approval. disposition_output_ref is the committed path of disposition-output.json at the merged commit.`

`agent_contract:` (`:402-407`)
- `mcp_servers:` `[]` (:403)
- `repos:` (`:404-407`): `artifact: rw` (:405), `source: none` (:406), `target: none` (:407)

`parallel_with:` `[]` (:408)
`gate:` `G-DE-2` (:409)
`retry_policy:` `category: validation_failure` (:410-411)

**Side-effect tables (Step 11):**

| # | target | fields | notes |
|---|---|---|---|
| 1 | `gate_record` | `gate_id`, `status`, `approved_by`, `approved_at` | — |
| 2 | `application` | `disposition_output_ref`, `disposition_completed_at` | Applied via `persist_disposition_side_effects` activity after gate approval. `disposition_output_ref` = committed path of `disposition-output.json` at the merged commit. (`:398-401`) |

⚠️ **GOTCHA — the `application` side-effect at Step 11 is APPLIED BY the `persist_disposition_side_effects` ACTIVITY (Step 12), not by the gate step itself** (`:398-401`). The gate step *declares* the `application` mutation, but the actual write happens in Step 12. ⚠️ Note name spelling: the activity is `persist_disposition_side_effects` (underscores) here in `notes`, while the step id is `persist-disposition-side-effects` (hyphens) at `:413`. Both refer to the same projection activity.

⚠️ **GOTCHA — "up to 3 rework iterations"** (`:381-382`), bounded like G-DE-1. Approval "authorizes Deployment to execute the infrastructure teardown" (`:382-383`). "Only runs for non-Retain dispositions" (`:380`).

---

### STEP 12 — `persist-disposition-side-effects` (`disposition-execution.yaml:413-456`)

| Field | Value | Line |
|---|---|---|
| `id` | `persist-disposition-side-effects` | :413 |
| `label` | `Persist Disposition Side-Effects` | :414 |
| `kind` | `code` | :415 |
| `scope` | `per-app` | :416 |
| `sequence` | `12` | :417 |
| `progress_pct` | `94` | :418 |
| `purpose` | (folded) `Post-gate projection. Parses the merged disposition-output.json and writes the authoritative disposition fields onto application. Single consolidated activity following the Discovery / Rationalization pattern — one writer per field. Runs after G-DE-2 for non-Retain dispositions; runs after G-DE-1 for Retain (which has no G-DE-2).` | :419-424 |
| `skills` | `[]` | :425 |
| `agent_role` | `null` | :426 |

`inputs:` (`:427-430`)
- `artifacts:` (`:428-429`):
  1. `dispositions/{portfolio_id}/{app_id}/disposition-output.json` (:429)
- `context:` `[app_id, portfolio_id, disposition]` (:430)

`outputs:` (`:431-446`)
- `artifacts:` `[]` (:432)
- `side_effects:` (`:433-446`) — ONE entry:
  1. `target: application` (:434)
     - `fields:` (block list, `:435-439`):
       - `disposition_output_ref` (:436)
       - `disposition_completed_at` (:437)
       - `disposition_current_status` (:438)
       - `cost_savings_annual_usd` (:439)
     - `notes:` (folded, `:440-446`): `disposition_current_status enum: ``disposition_in_progress`` (set at workflow start), ``disposition_plan_approved`` (post-G-DE-1), ``disposition_complete`` (post-G-DE-2 approved, or post-G-DE-1 for Retain), ``disposition_failed`` (rework exhausted). cost_savings_annual_usd is populated from the bundle's cost_savings_cert payload when present.`

`agent_contract:` (`:447-452`)
- `mcp_servers:` `[]` (:448)
- `repos:` (`:449-452`): `artifact: ro` (:450), `source: none` (:451), `target: none` (:452)

`parallel_with:` `[]` (:453)
`gate:` `null` (:454)
`retry_policy:` `category: validation_failure` (:455-456)

**Side-effect table `application` (Step 12):**

| target | fields | notes |
|---|---|---|
| `application` | `disposition_output_ref`, `disposition_completed_at`, `disposition_current_status`, `cost_savings_annual_usd` | enum + cost-source rules below |

`disposition_current_status` enum (`:440-445`) — reproduce EXACTLY:

| value | when set |
|---|---|
| `disposition_in_progress` | set at workflow start |
| `disposition_plan_approved` | post-G-DE-1 |
| `disposition_complete` | post-G-DE-2 approved, **or** post-G-DE-1 for Retain |
| `disposition_failed` | rework exhausted |

`cost_savings_annual_usd` (`:445-446`): populated from the bundle's `cost_savings_cert` payload **when present** (i.e. nullable when absent).

⚠️ **GOTCHA — `repos.artifact` is `ro` here (`:450`), the ONLY step with read-only artifact repo access except where `none`.** This is a projection-only activity: it READS the merged `disposition-output.json` and WRITES to the `application` DB table, not back to the artifact repo. Every other `rw`/`none` step does NOT write the DB except via declared side-effects.

⚠️ **GOTCHA — execution timing branches on disposition** (`:423-424`): runs after **G-DE-2** for non-Retain; runs after **G-DE-1** for **Retain** (Retain has no G-DE-2). "Single consolidated activity following the Discovery / Rationalization pattern — one writer per field" (`:421-422`) — a rebuild must use ONE activity that owns all 4 fields, not multiple writers (consistency with sibling lines).

---

### STEP 13 — `merge-g-de2-pr` (`disposition-execution.yaml:458-499`)

| Field | Value | Line |
|---|---|---|
| `id` | `merge-g-de2-pr` | :458 |
| `label` | `Merge G-DE-2 Review PR` | :459 |
| `kind` | `git` | :460 |
| `scope` | `per-app` | :461 |
| `sequence` | `13` | :462 |
| `progress_pct` | `98` | :463 |
| `purpose` | (folded) `Final merge of the approved G-DE-2 PR. For Replace/Replatform/Consolidate: signals Deployment to execute infrastructure teardown of the legacy app. For Retire: signals Deployment for decommission execution. Retain skips this step (no G-DE-2).` | :464-468 |
| `skills` | `[]` | :469 |
| `agent_role` | `null` | :470 |

`inputs:` (`:471-473`)
- `artifacts:` `[]` (:472)
- `context:` `[app_id, portfolio_id, pr_number, disposition]` (:473)

`outputs:` (`:474-489`)
- `artifacts:` `[]` (:475)
- `side_effects:` (`:476-489`) — **TWO** entries. ⚠️ Note the second entry uses `signal:` as its leading key (not `target:`), making it a heterogeneous side-effect-list shape:
  1. `target: application` (:477), `fields: [current_line, current_status, updated_at]` (:478)
  2. (signal side-effect, `:479-489`):
     - `signal: DispositionExecutedSignal` (:479)
     - `fields:` (block list, `:480-484`):
       - `app_id` (:481)
       - `disposition` (:482)
       - `disposition_output_ref` (:483)
       - `portfolio_id` (:484)
     - `target: DeploymentWorkflow (when disposition ∈ {Retire, Replace, Replatform, Consolidate})` (:485)
     - `notes:` (folded, `:486-489`): `Signal shape is new in this contract. Retain does not emit — Retain registers with Sustainment via the sustainment-handoff skill's output artifact ref, not via a signal.`

`agent_contract:` (`:490-495`)
- `mcp_servers:` `[]` (:491)
- `repos:` (`:492-495`): `artifact: rw` (:493), `source: none` (:494), `target: none` (:495)

`parallel_with:` `[]` (:496)
`gate:` `null` (:497)
`retry_policy:` `category: agent_failure` (:498-499)

**Side-effect tables (Step 13):**

| # | leading key | target | fields | notes |
|---|---|---|---|---|
| 1 | `target` | `application` | `current_line`, `current_status`, `updated_at` | — |
| 2 | `signal` (=`DispositionExecutedSignal`) | `DeploymentWorkflow (when disposition ∈ {Retire, Replace, Replatform, Consolidate})` | `app_id`, `disposition`, `disposition_output_ref`, `portfolio_id` | Signal shape is new in this contract. Retain does NOT emit — Retain registers with Sustainment via the `sustainment-handoff` skill's output artifact ref, not via a signal. (`:486-489`) |

⚠️ **GOTCHA — heterogeneous `side_effects` entry shape.** Entry 2 is keyed by `signal:` instead of `target:`, with `target:` appearing as a *nested descriptive string* `DeploymentWorkflow (when disposition ∈ {...})` (`:485`). A schema/parser must accept BOTH `target`-led (table mutation) and `signal`-led (Temporal signal) shapes in the same `side_effects` list. The `∈` (U+2208) and `{}` are literal in the value string.

⚠️ **GOTCHA — Retain does NOT emit `DispositionExecutedSignal`** (`:486-489`). Disposition routing of the signal:
- `Retire` → signals Deployment for **decommission execution** (`:466-467`).
- `Replace` / `Replatform` / `Consolidate` → signals Deployment for **infrastructure teardown of the legacy app** (`:465-466`).
- `Retain` → **skips this step entirely** (no G-DE-2) (`:468`); registers with Sustainment via the `sustainment-handoff` skill's output artifact ref (`:487-489`).

⚠️ **GOTCHA — `current_line` (not `current_step`) in the Step 13 application side-effect** (`:478`), whereas Step 6's `merge-g-de1-pr` writes `current_step` (`:231`). Both are `kind: git` merge steps but mutate DIFFERENT application columns: G-DE-1 merge advances `current_step`; G-DE-2 merge advances `current_line`. Preserve this exactly — it is easy to mistakenly unify them.

---

## 3. COUNT-COMPLETING `- id:` ENTRIES (the 2 gate definitions)

These two `- id:` entries live under the top-level `gates:` block, NOT under `steps:`. They are the remaining 2 of the 15 `^  - id:` regex matches. Reproduced here so the spec accounts for all 15 matching list items (full content already given in §1.3).

### ENTRY 14 — `G-DE-1` (gate definition, `disposition-execution.yaml:29-30`)

| Field | Value | Line |
|---|---|---|
| `id` | `G-DE-1` | :29 |
| `label` | `Disposition Execution Plan Approval` | :30 |

(This gate is *enforced* at Step 5 `gate-review-de1`, where `gate: G-DE-1` (`:208`).)

### ENTRY 15 — `G-DE-2` (gate definition, `disposition-execution.yaml:31-32`)

| Field | Value | Line |
|---|---|---|
| `id` | `G-DE-2` | :31 |
| `label` | `Decommission Readiness Sign-off` | :32 |

(This gate is *enforced* at Step 11 `gate-review-de2`, where `gate: G-DE-2` (`:409`).)

---

## 4. CROSS-STEP INVARIANTS / REBUILD CHECKLIST

- **`scope: per-app` on every step** (13/13) and `mode: per-app` at line level (`:33`). No batch/portfolio-scoped step exists.
- **`sequence` is dense 1..13** (`:50, :84, :117, :148, :182, :216, :247, :279, :312, :342, :376, :417, :462`). No gaps, no duplicates.
- **`progress_pct` monotonic strictly increasing**: 12, 25, 30, 35, 42, 48, 60, 72, 78, 82, 88, 94, 98. ⚠️ GOTCHA: never reaches 100 — final step ends at 98 (`:463`). A rebuild driving a progress bar from these values tops out at 98%; 100% is presumably the post-workflow terminal state, NOT a step.
- **`parallel_with: []` on every step** — fully sequential pipeline; no intra-line parallelism declared.
- **`gate:` non-null only on the 2 gate steps**: `G-DE-1` (Step 5, `:208`), `G-DE-2` (Step 11, `:409`). All other 11 steps: `gate: null`.
- **`agent_role` non-null only on the 4 `kind: agent` steps**: `Disposition Execution Agent` (Steps 1 & 7), `Gate Pre-Reviewer` (Steps 4 & 10). All `code`/`git`/`gate` steps: `agent_role: null`.
- **`skills` non-empty only on Steps 4 & 10**: `[gate-pre-review]`. All other steps: `skills: []`. (No `disposition`-specific skill is named in `skills:`; the per-disposition strategy/execution skills referenced in `description` are NOT enumerated in any step's `skills` list — they are implied by the `Disposition Execution Agent` role + `{step-id}` fan-out.)
- **`mcp_servers: [olympus]` only on the 4 `kind: agent` steps** (`:70, :168, :265, :362`). All non-agent steps: `mcp_servers: []`.
- **`repos.target` is `none` on ALL 13 steps** — this line never touches the target (generated-code) repo. `repos.source` is `ro` only on the 2 `Disposition Execution Agent` steps (1 & 7); `none` everywhere else. `repos.artifact` is `rw` everywhere except Step 12 (`ro`, `:450`) and the implicit-`none` reads.
- **Two writes to `disposition-output.json`**: partial shape at Step 2 (`:100`), complete shape at Step 8 (`:295`). Same path, two stages.
- **Side-effect target tables across the line**: `gate_pre_review` (Steps 4, 10), `gate_record` (Steps 5, 11), `application` (Steps 6, 11, 12, 13). Plus the `DispositionExecutedSignal` → `DeploymentWorkflow` signal (Step 13).
- **Retain is the universal exception**: skips post-gate execution (Step 6 note), G-DE-2 PR/pre-review/gate (Steps 9, 10, 11), and G-DE-2 merge + signal (Step 13). Retain's `persist-disposition-side-effects` runs after G-DE-1; Retain hands off to Sustainment via `sustainment-handoff` skill artifact ref, not a signal.

---

STEP INVENTORY: G-DE-1, G-DE-2, pre-gate-strategy, bundle-pre-gate-evidence, create-g-de1-pr, ai-pre-review-de1, gate-review-de1, merge-g-de1-pr, post-gate-execution, bundle-post-gate-evidence, create-g-de2-pr, ai-pre-review-de2, gate-review-de2, persist-disposition-side-effects, merge-g-de2-pr

STEPS REPRODUCED: 15

> NOTE on the inventory: the 15 ids above are ALL `^  - id:` (2-space-indent) entries in file order. The first two (`G-DE-1`, `G-DE-2`) are **gate definitions** under `gates:`; the remaining 13 are the true pipeline **steps** under `steps:`. The authoritative pipeline has **13 executable steps**; the literal "15" reflects the 2 additional gate-definition `- id:` entries that share the same YAML indentation. Both interpretations are fully reproduced above so no detail is lost.
