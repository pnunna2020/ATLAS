# Architecture Assembly Line — Step Contract (ATOMIC regeneration spec)

> **Source of truth:** `/Users/pnunna/Documents/GitHub/foundry/olympus-contracts/olympus_contracts/data/assembly-lines/architecture.yaml`
> All `architecture.yaml:NN` citations below refer to that file.
> This document reproduces the file field-by-field for behavioral parity. The YAML is parsed by `olympus_contracts.assembly_lines` and is the authoritative source every downstream consumer (Temporal `ArchitectureWorkflow`, Olympus API gate service, step-progress mapping, frontend step registry) loads from. **Do not hardcode a copy in application code** — drift is policed by the `test_no_hardcoded_step_lists` CI check (architecture.yaml:1-8).

---

## ⚠️ CRITICAL DISCREPANCY — STEP COUNT IS 19, NOT 20

The regeneration task brief asserted the Architecture line has "EXACTLY 20 steps." **The source file actually defines exactly 19 steps.** This is not an omission in this spec — it is the ground truth of the file as it exists on disk.

Verification performed against the live file:

- `grep -nE '^  - id:'` (step ids live at the 2-space `- id:` indent) returns **20 matches**, but **one of those is the gate id `G-02` at architecture.yaml:29**, which sits under the top-level `gates:` block (architecture.yaml:28), **not** under `steps:` (architecture.yaml:64). It is a gate declaration, not a step.
- Step ids under `steps:` (lines 65→813): **19** distinct `- id:` entries.
- The `sequence:` field is monotonic 1→19 with **no gaps and no value 20** (architecture.yaml lines 69,132,185,218,262,297,333,366,400,435,493,532,575,613,644,676,722,770,817). The maximum sequence is **19**.
- File length: 843 lines (the Read tool reported a trailing line 844, but `wc -l` = 843; the last content line is architecture.yaml:843, step `merge-blueprint-pr`'s `category: agent_failure`).

**Conclusion:** The "20" in the brief is an off-by-one almost certainly caused by counting the line-29 `G-02` gate id as if it were a step. The faithful reproduction is **19 steps**. All 19 are reproduced below in full. Re-running this spec to invent a 20th step would corrupt the regeneration; the correct fix to the brief is to read the count as 19.

---

## 1. Line-level metadata

Reproduced exactly from architecture.yaml:10-62. Top-level keys present, in file order: `name`, `description`, `trigger`, `depends_on`, `gates`, `mode`, `inputs`, `outputs`, `steps`.

### `name` (architecture.yaml:10)
```
Architecture
```

### `description` (architecture.yaml:11-21)
Block scalar (`>` folded). Verbatim text:
> Architecture designs the target state. It consumes Rationalization's disposition decisions and produces a blueprint per target application — which may be the source application (Refactor/Rearchitect/Replatform), a brand-new application (Replace), or a consolidated application merging multiple sources (Consolidate). Retire and Retain skip most of the line. Architecture decides what will be built and how it will fit — cloud pattern, EA compliance, integration contracts, data architecture, security posture, UI/UX design system, accessibility commitments, and AI/ML considerations — then assembles those into one cohesive blueprint per target.

### `trigger` (architecture.yaml:22)
```
rationalization-g-da-approved
```
⚠️ GOTCHA: The trigger is the **upstream gate-approval event name** `rationalization-g-da-approved` (Rationalization's G-DA gate approval), not the line name. The line is **triggered**, not continuous (see `mode` below). Architecture begins only after Rationalization's disposition approval gate clears.

### `depends_on` (architecture.yaml:23-27)
A leading comment (architecture.yaml:23-25) states: "Strict upstream only. Architecture and Data run in parallel and sync via signals (TargetProvisioned, DataPlanReady) — that coordination lives in step contracts, not in line-level dependencies."
```yaml
depends_on:
  - Rationalization
```
⚠️ GOTCHA: `depends_on` lists **only** `Rationalization`. The Data line is **NOT** a line-level dependency even though Architecture consumes Data artifacts (`data/{target_app_id}/data-architecture.json`, `data/{target_app_id}/data-migration-plan.json`). Architecture and Data run **in parallel**, coordinated by Temporal **signals** at the step level (`TargetProvisionedSignal` fired by step 1; `DataPlanReady` awaited by the `data-architecture` handshake step). Putting Data in `depends_on` would serialize the lines and break the parallelism.

### `gates` (architecture.yaml:28-30)
```yaml
gates:
  - id: G-02
    label: Architecture Alignment Review
```
Single gate: `G-02` / "Architecture Alignment Review". ⚠️ GOTCHA: This `- id: G-02` at architecture.yaml:29 is the gate declaration that the naive `grep '^  - id:'` count conflates with steps. It is **not** a step.

### `mode` (architecture.yaml:31)
```
per-target-app
```
The line runs **once per target application** (triggered/per-target), NOT continuously. (The task brief's "mode (continuous vs triggered)" maps to: **triggered, per-target-app scope** — this is a triggered line, not a continuous/cron line like Sustainment or Governance.) Every step also independently declares `scope: per-target-app`.

### `inputs` (architecture.yaml:32-40)
Top-level `inputs` is a **flat list of artifact-type names** (no `artifacts`/`context` split at the line level — that split exists only per-step):
```yaml
inputs:
  - disposition-recommendation
  - disposition-governance
  - redundancy-matrix
  - catalog-application
  - tco-baseline
  - structural-analysis
  - business-logic
  - ux-accessibility
```
(8 input artifact types, in order.)

### `outputs` (architecture.yaml:41-62)
Flat list of output artifact-type names. Inline comments mark the Stage 5 / Stage 9 ATLAS integration additions (dates `2026-05-06`). Reproduced with comments in place:
```yaml
outputs:
  - target-application-map
  - cloud-pattern
  # Stage 5 ATLAS integration (2026-05-06)
  - deployment-topology
  - target-architecture-blueprint
  - ea-compliance
  - integration-arch
  # Stage 5 ATLAS integration (2026-05-06)
  - resilience-matrix
  - security-arch
  - cato-evidence-seed
  - design-system
  - accessibility-review
  - ai-ml-integration
  - architecture-blueprint
  - blueprint-summary
  # Stage 5 ATLAS integration (2026-05-06)
  - cost-estimate
  - well-architected-review
  # Stage 9 ATLAS integration (2026-05-06)
  - traceability-validation
```
(18 output artifact types, in order: target-application-map, cloud-pattern, deployment-topology, target-architecture-blueprint, ea-compliance, integration-arch, resilience-matrix, security-arch, cato-evidence-seed, design-system, accessibility-review, ai-ml-integration, architecture-blueprint, blueprint-summary, cost-estimate, well-architected-review, traceability-validation.)
⚠️ GOTCHA: The output list does **not** include `data-architecture` / `data-migration-plan` — those are owned/emitted by the **Data** line; Architecture only **consumes** them. The `data-architecture` step (sequence 5) emits **no** artifacts; it only captures Data's artifact refs into this line's state.

---

## 2. Step contracts (all 19, in file order)

Field-naming note (applies to every step): the per-step keys present in this file are `id`, `label`, `kind`, `scope`, `sequence`, `progress_pct`, optional `summary`, `purpose`, `skills`, `agent_role`, `inputs.{artifacts, context}`, `outputs.{artifacts, side_effects}`, `agent_contract.{mcp_servers, repos.{artifact, source, target}}`, `parallel_with`, `gate`, `retry_policy.category`. 

⚠️ GOTCHA (field-name mapping vs. the brief): The brief's generic field names map to **these exact file keys** — `role` → `agent_role`; `mcp` → `agent_contract.mcp_servers`; `progress` → `progress_pct`; there is **no** `kind: agent|code|git|gate` enum beyond what appears (`kind` takes values `agent`, `code`, `git`, `gate`). There is **no** `condition` or `loop`/`iteration` key on any Architecture step in this file (those generic fields the brief lists are simply absent here — do not invent them). `gate:` is present on every step and is `null` except on the gate step. `parallel_with` is present on every step (empty list `[]` when none). `retry_policy` is present on every step with a single `category` key.

⚠️ GOTCHA (`skills` vs `agent_role` coupling): For `kind: code`, `kind: git`, and `kind: gate` steps, `skills: []` (empty) and `agent_role: null`. For `kind: agent` steps, `skills` is non-empty and `agent_role` is a string. This is invariant across the file.

⚠️ GOTCHA (`agent_contract.repos` tri-state): Every step declares three repo handles — `artifact`, `source`, `target` — each taking one of `rw` | `ro` | `none`. The **target** repo is `none` for *every* Architecture step (Architecture never writes target code; that is Modernization's job). The **source** repo is `ro` for most agent steps and `none` for synthesis/git/gate/code steps. The **artifact** repo is `rw` for steps that emit artifacts or commit/PR, and `ro` for the two read-only code steps (`data-architecture`, `persist-architecture-side-effects`). These exact values are load-bearing for the workspace-provisioning logic and are reproduced per step below.

---

### STEP 1 — `target-state-mapping` (architecture.yaml:65-126)

```yaml
- id: target-state-mapping
  label: Target-State Mapping
  kind: agent
  scope: per-target-app
  sequence: 1
  progress_pct: 10
```
- **purpose** (architecture.yaml:71-78, folded `>`):
  > Reconcile Rationalization's disposition decision into a concrete target application record. For Refactor/Rearchitect/Replatform: confirm the source=target linkage. For Replace: provision a new application row for the target. For Consolidate: provision (or promote) the target app and record the N source → 1 target lineage. For Retire/Retain: short-circuit downstream steps. Emits target-application-map.json as the authoritative source→target record every downstream line consumes.
- **skills** (architecture.yaml:79): `[target-state-mapper]`
- **agent_role** (architecture.yaml:80): `Target-State Architect`
- **inputs.artifacts** (architecture.yaml:82-86):
  - `rationalization/wave-{wave_id}/{source_app_id}/disposition-recommendation.json`
  - `rationalization/wave-{wave_id}/{source_app_id}/disposition-governance.json`
  - `rationalization/wave-{wave_id}/redundancy-matrix.json`
  - `discovery/{source_app_id}/catalog-application.json`
- **inputs.context** (architecture.yaml:87-90): `wave_id`, `source_app_ids`, `disposition`
- **outputs.artifacts** (architecture.yaml:92-93):
  - `architecture/{target_app_id}/target-application-map.json`
- **outputs.side_effects** (architecture.yaml:94-116) — THREE side effects:
  1. **target: `application`** (architecture.yaml:95)
     - **fields** (architecture.yaml:96): `[id, name, portfolio_id, source_app_ids]`
     - **notes** (architecture.yaml:97-100): "New row created for Replace/Consolidate targets; existing row updated for other dispositions. Projection via `persist_architecture_side_effects` post-G-02."
     - ⚠️ GOTCHA: The DB row write is **deferred** — the application row is *logically* provisioned here but the **DB projection happens in step 18** (`persist-architecture-side-effects`), post-gate. This matches the Discovery/Rationalization consolidation pattern (one writer per field, after the gate).
  2. **target: `application_lineage`** (architecture.yaml:101)
     - **fields** (architecture.yaml:102): `[target_app_id, source_app_id, relationship]`
     - **notes** (architecture.yaml:103-106): "New rows recording source→target edges. Relationship enum: `replace | consolidate-source | refactor-of | rearchitect-of | replatform-of | retain`."
     - ⚠️ GOTCHA: The `relationship` enum has **6** values exactly: `replace`, `consolidate-source`, `refactor-of`, `rearchitect-of`, `replatform-of`, `retain`. Note `consolidate-source` (the source side of a consolidation), not `consolidate`. There is no `replace-of`; it is bare `replace`.
  3. **signal: `TargetProvisionedSignal`** (architecture.yaml:107-116) — this side effect uses `signal:` as its leading key, then `fields:`, then `target:`, then `notes:` (field order in file: `signal`, `fields`, `target`, `notes`):
     - **fields** (architecture.yaml:108): `[target_app_id, portfolio_id, architecture_workflow_id, wave_id, disposition]`
     - **target** (architecture.yaml:109): `DataWorkflow (for this target)`
     - **notes** (architecture.yaml:110-116): "Fired immediately after target-application-map.json commits so the Data line can unblock its wait-for-target-provisioned step. Signal shape defined in `olympus_workflows.types.TargetProvisionedSignal` (2026-05-01, Data line contract). Emission wiring lands in Data line PR 2 alongside the Data workflow reshape — the signal type is imported from Data line PR 0."
     - ⚠️ GOTCHA: This side effect is a **Temporal signal**, not a DB write. Its YAML shape differs from the other two: it leads with `signal:` (the signal type name) instead of `target:` (a DB table). The cross-line coordination depends on the signal firing **immediately after the target-application-map.json commit** — fire-after-commit ordering is mandatory or the Data line deadlocks at its `wait-for-target-provisioned` step. Signal payload field order is exact: `target_app_id, portfolio_id, architecture_workflow_id, wave_id, disposition`.
- **agent_contract** (architecture.yaml:117-122): `mcp_servers: [olympus]`; `repos: {artifact: rw, source: ro, target: none}`
- **parallel_with** (architecture.yaml:123): `[]`
- **gate** (architecture.yaml:124): `null`
- **retry_policy.category** (architecture.yaml:125-126): `agent_failure`

---

### STEP 2 — `cloud-pattern-selection` (architecture.yaml:128-179)

```yaml
- id: cloud-pattern-selection
  label: Target Architecture Strategy
  kind: agent
  scope: per-target-app
  sequence: 2
  progress_pct: 15
```
- **Leading comment** (architecture.yaml:134-139): "Stage 5 ATLAS integration (2026-05-06): deployment-topology and target-architecture-blueprint co-run on this step. Both consume the selected cloud pattern plus the source Discovery inputs and emit sibling artifacts that feed blueprint-assembly. All three skills are cloud-var skills — the active profile's common.yaml pins cloud_provider, cloud_region, cloud_container_service, cloud_serverless_service."
  ⚠️ GOTCHA: `id` is `cloud-pattern-selection` but `label` is **`Target Architecture Strategy`** (not "Cloud Pattern Selection"). The id/label mismatch is intentional and must be preserved.
- **purpose** (architecture.yaml:140-148, folded `>`):
  > Select the cloud-native pattern (serverless, microservices, modular monolith, event-driven, batch, or hybrid) best-fit to the target's archetype, complexity, risk tier, and non-functional requirements. Produces the pattern decision, the deployment topology (container / function sizing, VPC topology, scaling, CI/CD, IaC module composition), and the target-architecture blueprint (approved-service selection, ADRs, C4 diagrams) per the active profile's cloud-provider pin.
- **skills** (architecture.yaml:149): `[migration-strategy-advisor, deployment-topology, target-architecture-blueprint]`
  ⚠️ GOTCHA: THREE skills run on this single step. The pattern-selection skill is named `migration-strategy-advisor` (not "cloud-pattern-selector"). The other two (`deployment-topology`, `target-architecture-blueprint`) are the Stage 5 ATLAS co-runners.
- **agent_role** (architecture.yaml:150): `Cloud Architect`
- **inputs.artifacts** (architecture.yaml:152-155):
  - `architecture/{target_app_id}/target-application-map.json`
  - `discovery/{source_app_id}/catalog-application.json`
  - `discovery/{source_app_id}/tco-baseline.json`
- **inputs.context** (architecture.yaml:156-161): `wave_id`, `target_app_id`, `archetype`, `complexity_tier`, `risk_tier`
- **outputs.artifacts** (architecture.yaml:163-168) — THREE artifacts (comment at 165-166 marks the two siblings):
  - `architecture/{target_app_id}/cloud-pattern.json`
  - `architecture/{target_app_id}/deployment-topology.json`
  - `architecture/{target_app_id}/target-architecture-blueprint.json`
- **outputs.side_effects** (architecture.yaml:169): `[]`
- **agent_contract** (architecture.yaml:170-175): `mcp_servers: [olympus]`; `repos: {artifact: rw, source: ro, target: none}`
- **parallel_with** (architecture.yaml:176): `[]`
- **gate** (architecture.yaml:177): `null`
- **retry_policy.category** (architecture.yaml:178-179): `agent_failure`

---

### STEP 3 — `ea-compliance` (architecture.yaml:181-212)

```yaml
- id: ea-compliance
  label: EA Compliance Verification
  kind: agent
  scope: per-target-app
  sequence: 3
  progress_pct: 22
```
- **purpose** (architecture.yaml:187-191, folded `>`):
  > Verify the selected pattern against enterprise architecture standards. Cite any BLOCK findings that must be resolved before the pattern can be assembled into the blueprint. Produces the ea-compliance.json artifact that G-02 evidence attaches.
- **skills** (architecture.yaml:192): `[ea-compliance]`
- **agent_role** (architecture.yaml:193): `EA Compliance Reviewer`
- **inputs.artifacts** (architecture.yaml:195-197):
  - `architecture/{target_app_id}/cloud-pattern.json`
  - `architecture/{target_app_id}/target-application-map.json`
- **inputs.context** (architecture.yaml:198, inline list form): `[wave_id, target_app_id, risk_tier]`
- **outputs.artifacts** (architecture.yaml:200-201):
  - `architecture/{target_app_id}/ea-compliance.json`
- **outputs.side_effects** (architecture.yaml:202): `[]`
- **agent_contract** (architecture.yaml:203-208): `mcp_servers: [olympus]`; `repos: {artifact: rw, source: ro, target: none}`
- **parallel_with** (architecture.yaml:209): `[]`
- **gate** (architecture.yaml:210): `null`
- **retry_policy.category** (architecture.yaml:211-212): `agent_failure`

---

### STEP 4 — `integration-arch` (architecture.yaml:214-256)

```yaml
- id: integration-arch
  label: Integration Architecture
  kind: agent
  scope: per-target-app
  sequence: 4
  progress_pct: 30
```
- **Leading comment** (architecture.yaml:220-224): "Stage 5 ATLAS integration (2026-05-06): resilience-designer folded in. Resilience patterns (circuit breakers, retries, DLQs, bulkheads) pair naturally with integration-contract design since they are integration-boundary concerns. Cloud-var skill — cloud_region pins region-pair failover options via the active profile's common.yaml."
- **purpose** (architecture.yaml:225-230, folded `>`):
  > Design API contracts, event schemas, external interface preservation (consumer compatibility), anti-corruption layers, and the resilience architecture (RTO/RPO per risk tier, circuit breakers, retries, bulkheads, DLQs, chaos-test plan). Covers both synchronous (API) and asynchronous (event) integration paths.
- **skills** (architecture.yaml:231): `[api-contract-validator, event-contract, resilience-designer]`
- **agent_role** (architecture.yaml:232): `Integration Architect`
- **inputs.artifacts** (architecture.yaml:234-238):
  - `architecture/{target_app_id}/cloud-pattern.json`
  - `architecture/{target_app_id}/deployment-topology.json`
  - `discovery/{source_app_id}/structural-analysis.json`
  - `discovery/{source_app_id}/business-logic.json`
- **inputs.context** (architecture.yaml:239, inline list): `[wave_id, target_app_id, source_app_ids, risk_tier]`
- **outputs.artifacts** (architecture.yaml:241-245) — comment at 243-244 marks the resilience sibling:
  - `architecture/{target_app_id}/integration-arch.json`
  - `architecture/{target_app_id}/resilience-matrix.json`
- **outputs.side_effects** (architecture.yaml:246): `[]`
- **agent_contract** (architecture.yaml:247-252): `mcp_servers: [olympus]`; `repos: {artifact: rw, source: ro, target: none}`
- **parallel_with** (architecture.yaml:253): `[data-architecture]`
  ⚠️ GOTCHA: This step runs **in parallel with `data-architecture`** (step 5). The pairing is reciprocal — step 5's `parallel_with` is `[integration-arch]`. Temporal fans these two out together.
- **gate** (architecture.yaml:254): `null`
- **retry_policy.category** (architecture.yaml:255-256): `agent_failure`

---

### STEP 5 — `data-architecture` (architecture.yaml:258-291)

```yaml
- id: data-architecture
  label: Data Architecture Handshake
  kind: code
  scope: per-target-app
  sequence: 5
  progress_pct: 35
```
⚠️ GOTCHA: `kind: code` — this is **workflow code, NOT an agent dispatch**. It is a signal-wait + artifact-ref capture. No agent, no MCP, no skills.
- **purpose** (architecture.yaml:264-272, folded `>`):
  > Lightweight bookkeeping step. The Data line runs in parallel once target-state-mapping emits; this step waits for Data's terminal gate to approve and pulls the authoritative data-architecture.json + data-migration-plan.json artifact refs into this line's state, so blueprint assembly and G-02 evidence reference the same shape Data approved. Not an agent dispatch — pure workflow code (signal wait + artifact ref capture).
  ⚠️ GOTCHA: This step **blocks on a Temporal signal** — it waits for the **Data line's terminal gate approval** (the `DataPlanReady`/Data terminal gate signal) before completing. It pulls the **authoritative artifact refs** that Data approved into Architecture's state so blueprint-assembly and G-02 cite the exact shape Data signed off. This is the receive-side of the cross-line handshake initiated by step 1's `TargetProvisionedSignal`.
- **skills** (architecture.yaml:272): `[]` (empty — no agent)
- **agent_role** (architecture.yaml:273): `null`
- **inputs.artifacts** (architecture.yaml:275-277):
  - `data/{target_app_id}/data-architecture.json`
  - `data/{target_app_id}/data-migration-plan.json`
  - ⚠️ GOTCHA: Inputs live under the **`data/`** repo path (Data line's namespace), not `architecture/`. These are foreign-line artifacts referenced by path.
- **inputs.context** (architecture.yaml:278, inline list): `[wave_id, target_app_id]`
- **outputs.artifacts** (architecture.yaml:280): `[]`
  ⚠️ GOTCHA: **Emits no artifacts.** It only captures refs into workflow state. This is why `data-architecture` is absent from the line-level `outputs` list.
- **outputs.side_effects** (architecture.yaml:281): `[]`
- **agent_contract** (architecture.yaml:282-287): `mcp_servers: []` (empty); `repos: {artifact: ro, source: none, target: none}`
  ⚠️ GOTCHA: `artifact: ro` (read-only) — it only reads Data's artifacts; it never writes. `mcp_servers: []`.
- **parallel_with** (architecture.yaml:288): `[integration-arch]`
- **gate** (architecture.yaml:289): `null`
- **retry_policy.category** (architecture.yaml:290-291): `transient`
  ⚠️ GOTCHA: `retry_policy.category: transient` (NOT `agent_failure`). Code/git steps use `transient`; agent steps use `agent_failure`; gate + the two post-gate code steps use `validation_failure`. The retry-policy taxonomy is category-driven, not per-step-tuned.

---

### STEP 6 — `security-arch` (architecture.yaml:293-327)

```yaml
- id: security-arch
  label: Security Architecture
  kind: agent
  scope: per-target-app
  sequence: 6
  progress_pct: 42
```
- **purpose** (architecture.yaml:299-305, folded `>`):
  > Map security controls against the chosen pattern and integration shape: identity architecture, Zero Trust posture, continuous-ATO evidence seeds, secrets management, network segmentation. Produces the security-arch.json artifact and the cATO-evidence-seed.json referenced by the Compliance cross-cutting line.
- **skills** (architecture.yaml:305): `[cato-compliance, security-posture-analyzer]`
- **agent_role** (architecture.yaml:306): `Security Architect`
- **inputs.artifacts** (architecture.yaml:308-311):
  - `architecture/{target_app_id}/cloud-pattern.json`
  - `architecture/{target_app_id}/integration-arch.json`
  - `data/{target_app_id}/data-architecture.json`
  - ⚠️ GOTCHA: Consumes the **Data line's** `data-architecture.json` (foreign repo path), which is why this step is sequenced **after** the `data-architecture` handshake (step 5) that captured Data's approved refs.
- **inputs.context** (architecture.yaml:312, inline list): `[wave_id, target_app_id, risk_tier]`
- **outputs.artifacts** (architecture.yaml:314-316):
  - `architecture/{target_app_id}/security-arch.json`
  - `architecture/{target_app_id}/cato-evidence-seed.json`
  - ⚠️ GOTCHA: Output filename is lowercase `cato-evidence-seed.json` even though the prose/comment writes "cATO-evidence-seed.json". The on-disk artifact name is `cato-evidence-seed.json` (matches the line-level output `cato-evidence-seed` at architecture.yaml:52).
- **outputs.side_effects** (architecture.yaml:317): `[]`
- **agent_contract** (architecture.yaml:318-323): `mcp_servers: [olympus]`; `repos: {artifact: rw, source: ro, target: none}`
- **parallel_with** (architecture.yaml:324): `[]`
- **gate** (architecture.yaml:325): `null`
- **retry_policy.category** (architecture.yaml:326-327): `agent_failure`

---

### STEP 7 — `design-system` (architecture.yaml:329-360)

```yaml
- id: design-system
  label: Design System Mapping
  kind: agent
  scope: per-target-app
  sequence: 7
  progress_pct: 50
```
- **purpose** (architecture.yaml:335-339, folded `>`):
  > Narrow design-system scope to component-library mapping only. Establish which reusable UI components the target consumes, what new components the target contributes, and the tokens/theme alignment. Accessibility is deliberately a separate step — see accessibility-review.
- **skills** (architecture.yaml:340): `[design-system]`
- **agent_role** (architecture.yaml:340-341): `Design System Architect`
- **inputs.artifacts** (architecture.yaml:343-345):
  - `architecture/{target_app_id}/cloud-pattern.json`
  - `discovery/{source_app_id}/ux-accessibility.json`
- **inputs.context** (architecture.yaml:346, inline list): `[wave_id, target_app_id, archetype]`
- **outputs.artifacts** (architecture.yaml:348-349):
  - `architecture/{target_app_id}/design-system.json`
- **outputs.side_effects** (architecture.yaml:350): `[]`
- **agent_contract** (architecture.yaml:351-356): `mcp_servers: [olympus]`; `repos: {artifact: rw, source: ro, target: none}`
- **parallel_with** (architecture.yaml:357): `[accessibility-review]`
  ⚠️ GOTCHA: Runs **in parallel with `accessibility-review`** (step 8), reciprocal pairing. Design-system and accessibility were deliberately split into two parallel agent steps (purpose says accessibility is "a cross-cutting commitment, not a component concern").
- **gate** (architecture.yaml:358): `null`
- **retry_policy.category** (architecture.yaml:359-360): `agent_failure`

---

### STEP 8 — `accessibility-review` (architecture.yaml:362-394)

```yaml
- id: accessibility-review
  label: Accessibility Review
  kind: agent
  scope: per-target-app
  sequence: 8
  progress_pct: 55
```
- **purpose** (architecture.yaml:368-373, folded `>`):
  > Act as a design review for accessibility — WCAG + Section 508 commitments the target will honor, identified conformance risks, remediation notes that feed Modernization's acceptance criteria. Separate from design-system because accessibility is a cross-cutting commitment, not a component concern.
- **skills** (architecture.yaml:374): `[accessibility-reviewer]`
  ⚠️ GOTCHA: Skill id is `accessibility-reviewer` (with `-reviewer` suffix); the step id is `accessibility-review` (no suffix). Do not conflate.
- **agent_role** (architecture.yaml:375): `Accessibility Reviewer`
- **inputs.artifacts** (architecture.yaml:377-379):
  - `architecture/{target_app_id}/design-system.json`
  - `discovery/{source_app_id}/ux-accessibility.json`
  - ⚠️ GOTCHA: Consumes `design-system.json` (step 7's output) **even though it runs `parallel_with: [design-system]`**. The parallelism is logical/declarative; the actual data dependency means the orchestrator must make step 7's output available. Reproduce both the parallel_with pairing AND this input edge exactly as written — the file declares them concurrently despite the apparent data dependency.
- **inputs.context** (architecture.yaml:380, inline list): `[wave_id, target_app_id, risk_tier]`
- **outputs.artifacts** (architecture.yaml:382-383):
  - `architecture/{target_app_id}/accessibility-review.json`
- **outputs.side_effects** (architecture.yaml:384): `[]`
- **agent_contract** (architecture.yaml:385-390): `mcp_servers: [olympus]`; `repos: {artifact: rw, source: ro, target: none}`
- **parallel_with** (architecture.yaml:391): `[design-system]`
- **gate** (architecture.yaml:392): `null`
- **retry_policy.category** (architecture.yaml:393-394): `agent_failure`

---

### STEP 9 — `ai-ml-integration` (architecture.yaml:396-429)

```yaml
- id: ai-ml-integration
  label: AI/ML Integration
  kind: agent
  scope: per-target-app
  sequence: 9
  progress_pct: 62
```
- **purpose** (architecture.yaml:402-407, folded `>`):
  > Always runs — every target is considered for AI/ML integration potential. Emits one of three outcomes: ai-ml-required (target has AI/ML in scope), ai-ml-applicable (future opportunity, not in this modernization), ai-ml-not-applicable (no use case identified). Replaces the string-match heuristic in the current workflow.
  ⚠️ GOTCHA: The three outcome enum values are **exactly** `ai-ml-required`, `ai-ml-applicable`, `ai-ml-not-applicable`. The step **always runs** (no `condition`); it explicitly "Replaces the string-match heuristic in the current workflow" — do NOT reintroduce a string-match gate on this step.
- **skills** (architecture.yaml:408): `[ai-ml-integration]`
- **agent_role** (architecture.yaml:409): `AI/ML Solutions Architect`
- **inputs.artifacts** (architecture.yaml:411-414):
  - `architecture/{target_app_id}/target-application-map.json`
  - `architecture/{target_app_id}/cloud-pattern.json`
  - `discovery/{source_app_id}/business-logic.json`
- **inputs.context** (architecture.yaml:415, inline list): `[wave_id, target_app_id, archetype]`
- **outputs.artifacts** (architecture.yaml:417-418):
  - `architecture/{target_app_id}/ai-ml-integration.json`
- **outputs.side_effects** (architecture.yaml:419): `[]`
- **agent_contract** (architecture.yaml:420-425): `mcp_servers: [olympus]`; `repos: {artifact: rw, source: ro, target: none}`
- **parallel_with** (architecture.yaml:426): `[]`
- **gate** (architecture.yaml:427): `null`
- **retry_policy.category** (architecture.yaml:428-429): `agent_failure`

---

### STEP 10 — `blueprint-assembly` (architecture.yaml:431-482)

```yaml
- id: blueprint-assembly
  label: Blueprint Assembly
  kind: agent
  scope: per-target-app
  sequence: 10
  progress_pct: 68
  summary: true
```
⚠️ GOTCHA: This step carries **`summary: true`** (architecture.yaml:437) — the ONLY step in the line with this flag. It marks the line's synthesis/summary step (the one producing the human-readable artifact + the authoritative blueprint). Downstream consumers (frontend step registry, progress mapping) use `summary: true` to identify the line's headline artifact. Reproduce this boolean exactly.
- **Leading comment** (architecture.yaml:438-443): "Stage 5 ATLAS integration (2026-05-06): deployment-topology, target-architecture-blueprint, and resilience-matrix are now sibling inputs from earlier steps. blueprint-assembly's scope is unchanged (pure synthesis) but its input set widens so the assembled blueprint can cite the concrete service selection + resilience matrix rather than leaving them as open questions."
- **purpose** (architecture.yaml:444-450, folded `>`):
  > Synthesize every upstream artifact (target-map, pattern, target-architecture-blueprint, deployment-topology, EA, integration, resilience-matrix, data, security, design-system, accessibility, AI/ML) into one cohesive architecture blueprint. Produces architecture-blueprint.json — authoritative input for Modernization — plus a human-readable blueprint-summary.md for G-02 reviewers.
- **skills** (architecture.yaml:451): `[blueprint-assembly]`
- **agent_role** (architecture.yaml:452): `Architecture Synthesizer`
- **inputs.artifacts** (architecture.yaml:454-466) — TWELVE inputs (the widest input set in the line):
  - `architecture/{target_app_id}/target-application-map.json`
  - `architecture/{target_app_id}/cloud-pattern.json`
  - `architecture/{target_app_id}/deployment-topology.json`
  - `architecture/{target_app_id}/target-architecture-blueprint.json`
  - `architecture/{target_app_id}/ea-compliance.json`
  - `architecture/{target_app_id}/integration-arch.json`
  - `architecture/{target_app_id}/resilience-matrix.json`
  - `data/{target_app_id}/data-architecture.json`
  - `architecture/{target_app_id}/security-arch.json`
  - `architecture/{target_app_id}/design-system.json`
  - `architecture/{target_app_id}/accessibility-review.json`
  - `architecture/{target_app_id}/ai-ml-integration.json`
  - ⚠️ GOTCHA: One of the 12 inputs is from the **Data** repo (`data/{target_app_id}/data-architecture.json`); the other 11 are from `architecture/`. Preserve the foreign-path on the data input.
- **inputs.context** (architecture.yaml:467, inline list): `[wave_id, target_app_id, source_app_ids]`
- **outputs.artifacts** (architecture.yaml:469-471):
  - `architecture/{target_app_id}/architecture-blueprint.json`
  - `architecture/{target_app_id}/blueprint-summary.md`
  - ⚠️ GOTCHA: Two outputs — a `.json` (machine-authoritative, Modernization's input) and a `.md` (human summary for G-02 reviewers). The `.md` is the only non-JSON artifact emitted by an agent step in this line.
- **outputs.side_effects** (architecture.yaml:472): `[]`
- **agent_contract** (architecture.yaml:473-478): `mcp_servers: [olympus]`; `repos: {artifact: rw, source: none, target: none}`
  ⚠️ GOTCHA: `source: none` here (NOT `ro`). Blueprint assembly is **pure synthesis** of already-committed artifacts; it does not read the source code repo. Contrast with the earlier agent steps (1,2,3,4,6,7,8,9) which all have `source: ro`.
- **parallel_with** (architecture.yaml:479): `[]`
- **gate** (architecture.yaml:480): `null`
- **retry_policy.category** (architecture.yaml:481-482): `agent_failure`

---

### STEP 11 — `cloud-cost-estimate` (architecture.yaml:489-521)

```yaml
- id: cloud-cost-estimate
  label: Cloud Cost Estimate
  kind: agent
  scope: per-target-app
  sequence: 11
  progress_pct: 72
```
- **Leading comment** (architecture.yaml:484-488): "Stage 5 ATLAS integration (2026-05-06): cloud-cost-estimator as its own pre-G-02 evidence step. Runs after blueprint-assembly (needs the final service inventory to cost) and emits cost-estimate.yaml that attaches to the G-02 PR alongside blueprint-summary.md. Cloud-var skill — cloud_region pins region pricing via the active profile."
- **purpose** (architecture.yaml:495-499, folded `>`):
  > Produce an itemized cloud-cost projection for the assembled blueprint and compare against the Discovery TCO baseline to quantify net savings. Feeds G-02 evidence so reviewers see architectural decisions alongside their cost implications.
- **skills** (architecture.yaml:500): `[cloud-cost-estimator]`
- **agent_role** (architecture.yaml:501): `Cloud Cost Analyst`
- **inputs.artifacts** (architecture.yaml:503-506):
  - `architecture/{target_app_id}/architecture-blueprint.json`
  - `architecture/{target_app_id}/deployment-topology.json`
  - `discovery/{source_app_id}/tco-baseline.json`
- **inputs.context** (architecture.yaml:507, inline list): `[wave_id, target_app_id, archetype, risk_tier]`
- **outputs.artifacts** (architecture.yaml:509-510):
  - `architecture/{target_app_id}/cost-estimate.yaml`
  - ⚠️ GOTCHA: Output is **`cost-estimate.yaml`** (YAML, not JSON). One of only two non-JSON agent outputs in the line (the other is `blueprint-summary.md`).
- **outputs.side_effects** (architecture.yaml:511): `[]`
- **agent_contract** (architecture.yaml:512-517): `mcp_servers: [olympus]`; `repos: {artifact: rw, source: ro, target: none}`
- **parallel_with** (architecture.yaml:518): `[well-architected-review]`
  ⚠️ GOTCHA: Asymmetric parallel_with. This step lists only `[well-architected-review]`, but the three post-blueprint evidence steps (11 `cloud-cost-estimate`, 12 `well-architected-review`, 13 `traceability-validation`) actually form a 3-way parallel fan-out. Step 12 lists `[cloud-cost-estimate, traceability-validation]` and step 13 lists `[cloud-cost-estimate, well-architected-review]` — but step 11 omits `traceability-validation` from its own list. This is an **inconsistency in the file** (step 11's parallel_with is missing `traceability-validation`). Reproduce **as written** — do NOT "fix" step 11 to add traceability-validation. The orchestrator derives the actual fan-out set from the union; the declared lists are not all symmetric.
- **gate** (architecture.yaml:519): `null`
- **retry_policy.category** (architecture.yaml:520-521): `agent_failure`

---

### STEP 12 — `well-architected-review` (architecture.yaml:528-560)

```yaml
- id: well-architected-review
  label: Well-Architected Review
  kind: agent
  scope: per-target-app
  sequence: 12
  progress_pct: 74
```
- **Leading comment** (architecture.yaml:523-527): "Stage 5 ATLAS integration (2026-05-06): well-architected-reviewer as its own pre-G-02 evidence step. Runs in parallel with cloud-cost-estimate; both depend only on the assembled blueprint. Cloud-var skill — well_architected_framework pins the framework lens via the active profile."
- **purpose** (architecture.yaml:534-538, folded `>`):
  > Evaluate the assembled architecture blueprint against the active profile's Well-Architected-style framework. Score each pillar 1-5 with evidence citations, identify top risks, and produce a review report that attaches to G-02 evidence.
  ⚠️ GOTCHA: Pillar scoring scale is **1-5** with evidence citations. The framework lens is profile-pinned via `well_architected_framework`.
- **skills** (architecture.yaml:539): `[well-architected-reviewer]`
- **agent_role** (architecture.yaml:540): `Architecture Quality Reviewer`
- **inputs.artifacts** (architecture.yaml:542-545):
  - `architecture/{target_app_id}/architecture-blueprint.json`
  - `architecture/{target_app_id}/resilience-matrix.json`
  - `architecture/{target_app_id}/security-arch.json`
- **inputs.context** (architecture.yaml:546, inline list): `[wave_id, target_app_id, risk_tier]`
- **outputs.artifacts** (architecture.yaml:548-549):
  - `architecture/{target_app_id}/well-architected-review.json`
- **outputs.side_effects** (architecture.yaml:550): `[]`
- **agent_contract** (architecture.yaml:551-556): `mcp_servers: [olympus]`; `repos: {artifact: rw, source: none, target: none}`
  ⚠️ GOTCHA: `source: none` (reviews the committed blueprint, not source code).
- **parallel_with** (architecture.yaml:557): `[cloud-cost-estimate, traceability-validation]`
- **gate** (architecture.yaml:558): `null`
- **retry_policy.category** (architecture.yaml:559-560): `agent_failure`

---

### STEP 13 — `traceability-validation` (architecture.yaml:571-607)

```yaml
- id: traceability-validation
  label: Architecture Traceability Validation
  kind: agent
  scope: per-target-app
  sequence: 13
  progress_pct: 76
```
- **Leading comment** (architecture.yaml:562-570): "Stage 9 ATLAS integration (2026-05-06): architecture-traceability-validator as its own pre-G-02 evidence step. Runs in parallel with cloud-cost-estimate + well-architected-review; all three depend only on the assembled blueprint + upstream Discovery artifacts. Independent second-pass validator that verifies every ADR traces to a Discovery finding and every architecturally-significant finding is addressed. Complements traceability-checker (which runs at Validation for requirement→test coverage) — this skill is specialised for the ADR→finding edge on the Architecture gate."
- **purpose** (architecture.yaml:577-583, folded `>`):
  > Independently verify that every ADR in the assembled blueprint traces to a Discovery finding and that every architecturally-significant Discovery finding is addressed by at least one ADR. Emits a traceability-validation report that attaches to G-02 evidence. Tier-adjusted coverage threshold: >= 95% for T1/T2, >= 90% for T3. Zero orphan ADRs.
  ⚠️ GOTCHA: **Tier-adjusted coverage threshold is load-bearing:** `>= 95%` for Tier-1 / Tier-2, `>= 90%` for Tier-3, with **zero orphan ADRs** mandatory at all tiers. These exact thresholds drive the validator's pass/fail and feed the pre-review blocker logic in step 16. Reproduce verbatim.
- **skills** (architecture.yaml:584): `[architecture-traceability-validator]`
- **agent_role** (architecture.yaml:585): `Traceability Validator`
- **inputs.artifacts** (architecture.yaml:587-592):
  - `architecture/{target_app_id}/architecture-blueprint.json`
  - `architecture/{target_app_id}/blueprint-summary.md`
  - `discovery/{source_app_id}/structural-analysis.json`
  - `discovery/{source_app_id}/business-logic.json`
  - `discovery/{source_app_id}/quality-risk.json`
  - ⚠️ GOTCHA: Reads `discovery/{source_app_id}/quality-risk.json` — this `quality-risk` Discovery artifact is consumed ONLY by this step in the entire Architecture line. Also reads the `.md` summary from step 10 as an input (unusual — most steps read `.json`).
- **inputs.context** (architecture.yaml:593, inline list): `[wave_id, target_app_id, risk_tier]`
- **outputs.artifacts** (architecture.yaml:595-596):
  - `architecture/{target_app_id}/traceability-validation.md`
  - ⚠️ GOTCHA: Output is **`traceability-validation.md`** (Markdown report, not JSON).
- **outputs.side_effects** (architecture.yaml:597): `[]`
- **agent_contract** (architecture.yaml:598-603): `mcp_servers: [olympus]`; `repos: {artifact: rw, source: ro, target: none}`
  ⚠️ GOTCHA: `source: ro` here (it traces ADRs back to Discovery findings, so it may read source context) — contrast steps 10 & 12 which use `source: none`.
- **parallel_with** (architecture.yaml:604): `[cloud-cost-estimate, well-architected-review]`
- **gate** (architecture.yaml:605): `null`
- **retry_policy.category** (architecture.yaml:606-607): `agent_failure`

---

### STEP 14 — `commit-blueprint-artifacts` (architecture.yaml:609-638)

```yaml
- id: commit-blueprint-artifacts
  label: Commit Blueprint Artifacts
  kind: git
  scope: per-target-app
  sequence: 14
  progress_pct: 78
```
⚠️ GOTCHA: `kind: git` — workflow code, NOT an agent dispatch. Performs the git commit.
- **purpose** (architecture.yaml:615-618, folded `>`):
  > Workflow code (not an agent dispatch). Commits every architecture artifact produced in this run to the per-target branch in the artifact repo. One commit; commit message references wave_id + target_app_id.
  ⚠️ GOTCHA: **Exactly ONE commit**, to the **per-target branch** of the artifact repo; commit message MUST reference `wave_id` + `target_app_id`. Single-commit semantics are explicit.
- **skills** (architecture.yaml:619): `[]`
- **agent_role** (architecture.yaml:620): `null`
- **inputs.artifacts** (architecture.yaml:622-624):
  - `architecture/{target_app_id}/*.json`  ← glob over all JSON artifacts produced this run
  - `architecture/{target_app_id}/blueprint-summary.md`
  - ⚠️ GOTCHA: Inputs use a **glob** `architecture/{target_app_id}/*.json` plus the explicit `.md`. The commit sweeps all per-target JSON artifacts. (Note: `cost-estimate.yaml` is `.yaml`, NOT matched by the `*.json` glob — verify whether the YAML is intentionally excluded from this commit or swept by separate logic. As written, the `*.json` glob does not match `cost-estimate.yaml`; the `.md` is listed explicitly but the `.yaml` is not.)
- **inputs.context** (architecture.yaml:625, inline list): `[wave_id, target_app_id]`
- **outputs.artifacts** (architecture.yaml:627): `[]`
- **outputs.side_effects** (architecture.yaml:628): `[]`
- **agent_contract** (architecture.yaml:629-634): `mcp_servers: []`; `repos: {artifact: rw, source: none, target: none}`
- **parallel_with** (architecture.yaml:635): `[]`
- **gate** (architecture.yaml:636): `null`
- **retry_policy.category** (architecture.yaml:637-638): `transient`

---

### STEP 15 — `create-g-02-pr` (architecture.yaml:640-670)

```yaml
- id: create-g-02-pr
  label: Create G-02 Review PR
  kind: git
  scope: per-target-app
  sequence: 15
  progress_pct: 83
```
⚠️ GOTCHA: `kind: git` — opens the gate-review pull request.
- **purpose** (architecture.yaml:646-651, folded `>`):
  > Open the gate-review PR against the artifact repo's main branch. PR body aggregates the blueprint summary + side-by-side source→target diff (when applicable) + links to every upstream artifact. Tier-1 PRs explicitly tag EA board + security officer for stakeholder sign-off.
  ⚠️ GOTCHA: PR targets the artifact repo's **main** branch. PR body must aggregate: (1) blueprint summary, (2) side-by-side source→target diff **when applicable**, (3) links to every upstream artifact. **Tier-1 PRs MUST explicitly tag the EA board + security officer** — tier-conditional reviewer tagging is behavior, not decoration.
- **skills** (architecture.yaml:652): `[]`
- **agent_role** (architecture.yaml:653): `null`
- **inputs.artifacts** (architecture.yaml:655-656):
  - `architecture/{target_app_id}/architecture-blueprint.json`
  - `architecture/{target_app_id}/blueprint-summary.md`
- **inputs.context** (architecture.yaml:657, inline list): `[wave_id, target_app_id, risk_tier]`
- **outputs.artifacts** (architecture.yaml:659): `[]`
- **outputs.side_effects** (architecture.yaml:660): `[]`
- **agent_contract** (architecture.yaml:661-666): `mcp_servers: []`; `repos: {artifact: rw, source: none, target: none}`
- **parallel_with** (architecture.yaml:667): `[]`
- **gate** (architecture.yaml:668): `null`
- **retry_policy.category** (architecture.yaml:669-670): `transient`

---

### STEP 16 — `ai-pre-review` (architecture.yaml:672-716)

```yaml
- id: ai-pre-review
  label: AI Pre-Review
  kind: agent
  scope: per-target-app
  sequence: 16
  progress_pct: 87
```
- **purpose** (architecture.yaml:678-683, folded `>`):
  > Advisory readiness check before the human gate opens — flags likely blocker findings (missing evidence, stale data-architecture, AI/ML decision incoherent with pattern, accessibility commitments below risk-tier floor, trace gaps, orphan ADRs) so reviewers and the workflow can short-circuit obvious rejections.
  ⚠️ GOTCHA: This is **advisory**, not blocking — but it enumerates the exact blocker categories the pre-reviewer flags: (1) missing evidence, (2) stale data-architecture, (3) AI/ML decision incoherent with pattern, (4) accessibility commitments below risk-tier floor, (5) trace gaps, (6) orphan ADRs. These categories tie back to steps 9 (AI/ML), 8 (accessibility), and 13 (traceability/orphan ADRs).
- **skills** (architecture.yaml:684): `[gate-pre-review]`
- **agent_role** (architecture.yaml:685): `Gate Pre-Reviewer`
- **inputs.artifacts** (architecture.yaml:687-698) — FIVE inputs, with two inline comment blocks (690-692 for cost+WAR, 695-697 for traceability):
  - `architecture/{target_app_id}/architecture-blueprint.json`
  - `architecture/{target_app_id}/blueprint-summary.md`
  - `architecture/{target_app_id}/cost-estimate.yaml`  (Stage 5: cost feeds pre-review)
  - `architecture/{target_app_id}/well-architected-review.json`  (Stage 5: WAR feeds pre-review)
  - `architecture/{target_app_id}/traceability-validation.md`  (Stage 9: trace feeds pre-review)
  - Comment (architecture.yaml:690-692): "Stage 5 ATLAS integration (2026-05-06): cost + WAR feed pre-review so tier-adjusted-minima and budget-overrun checks can surface blockers before the human gate opens."
  - Comment (architecture.yaml:695-697): "Stage 9 ATLAS integration (2026-05-06): traceability-validation feeds pre-review so ADR-trace gaps and orphan decisions can surface as blockers before the human gate opens."
- **inputs.context** (architecture.yaml:699, inline list): `[wave_id, target_app_id, risk_tier]`
- **outputs.artifacts** (architecture.yaml:701-702):
  - `architecture/{target_app_id}/pre-review.json`
- **outputs.side_effects** (architecture.yaml:703-706) — ONE side effect:
  - **target: `gate_pre_review`** (architecture.yaml:704)
    - **fields** (architecture.yaml:705): `[gate_id, findings_json]`
    - **notes** (architecture.yaml:706): "Persisted so the gate-review UI can surface pre-review findings."
    - ⚠️ GOTCHA: The pre-review findings are persisted to the **`gate_pre_review`** table with fields `gate_id`, `findings_json` so the gate-review UI can render them before/during the human gate. `findings_json` is a JSON-blob column.
- **agent_contract** (architecture.yaml:707-712): `mcp_servers: [olympus]`; `repos: {artifact: rw, source: none, target: none}`
  ⚠️ GOTCHA: `source: none` (it reviews committed evidence only).
- **parallel_with** (architecture.yaml:713): `[]`
- **gate** (architecture.yaml:714): `null`
- **retry_policy.category** (architecture.yaml:715-716): `agent_failure`

---

### STEP 17 — `gate-review-02` (architecture.yaml:718-764)

```yaml
- id: gate-review-02
  label: G-02 Architecture Alignment Review
  kind: gate
  scope: per-target-app
  sequence: 17
  progress_pct: 91
```
⚠️ GOTCHA: `kind: gate` — the ONLY `kind: gate` step in the line. This is the human review gate.
- **purpose** (architecture.yaml:724-729, folded `>`):
  > Human review of the blueprint by EA board (plus security officer for Tier-1). Dual/triple-signal approval model — PM merges PR AND stakeholder(s) fire the matching scope signal(s). Rejection loops back through the contested steps (up to 3 rework iterations before workflow fails).
  ⚠️ GOTCHA (approval model — BEHAVIORAL): **Dual/triple-signal approval.** Approval requires BOTH (a) the PM merging the PR AND (b) stakeholder(s) firing the **matching scope signal(s)**. For Tier-1 the security officer is an additional required signer (hence "triple"). **Rejection loops back through the contested steps; a maximum of 3 rework iterations is allowed before the workflow FAILS.** The "3 rework iterations then fail" loop bound is load-bearing and must be reproduced in the workflow.
- **skills** (architecture.yaml:730): `[]`
- **agent_role** (architecture.yaml:731): `null`
- **inputs.artifacts** (architecture.yaml:733-739) — FOUR inputs (comment at 737-738 for the traceability report):
  - `architecture/{target_app_id}/architecture-blueprint.json`
  - `architecture/{target_app_id}/blueprint-summary.md`
  - `architecture/{target_app_id}/pre-review.json`
  - `architecture/{target_app_id}/traceability-validation.md`  (Stage 9: part of G-02 evidence bundle)
  - Comment (architecture.yaml:737-738): "Stage 9 ATLAS integration (2026-05-06): traceability report is part of the G-02 evidence bundle alongside the blueprint."
- **inputs.context** (architecture.yaml:740, inline list): `[wave_id, target_app_id, risk_tier]`
- **outputs.artifacts** (architecture.yaml:742): `[]`
- **outputs.side_effects** (architecture.yaml:743-754) — TWO side effects:
  1. **target: `gate_record`** (architecture.yaml:744)
     - **fields** (architecture.yaml:745): `[gate_id, status, approved_by, approved_at]`
  2. **target: `application`** (architecture.yaml:746)
     - **fields** (architecture.yaml:747-750, block list form):
       - `architecture_blueprint_ref`
       - `architecture_pattern`
       - `architecture_decided_at`
     - **notes** (architecture.yaml:751-754): "Applied via `persist_architecture_side_effects` activity after gate approval. `architecture_blueprint_ref` is the committed path of architecture-blueprint.json at the merged commit."
     - ⚠️ GOTCHA: These three `application` fields are declared on the GATE step but **applied by the `persist_architecture_side_effects` activity** (step 18), not inline at the gate. `architecture_blueprint_ref` = the committed **path of architecture-blueprint.json at the MERGED commit** (post-merge SHA path), not the pre-merge path. The side-effect declaration here is duplicated/forward-referenced in step 18 (`persist-architecture-side-effects`) which is the actual writer.
- **agent_contract** (architecture.yaml:755-760): `mcp_servers: []`; `repos: {artifact: rw, source: none, target: none}`
- **parallel_with** (architecture.yaml:761): `[]`
- **gate** (architecture.yaml:762): `G-02`  ← the ONLY step with a non-null `gate` value
- **retry_policy.category** (architecture.yaml:763-764): `validation_failure`
  ⚠️ GOTCHA: `validation_failure` category (NOT `agent_failure` or `transient`). Gate + the two post-gate code steps share `validation_failure`.

---

### STEP 18 — `persist-architecture-side-effects` (architecture.yaml:766-811)

```yaml
- id: persist-architecture-side-effects
  label: Persist Architecture Side-Effects
  kind: code
  scope: per-target-app
  sequence: 18
  progress_pct: 95
```
⚠️ GOTCHA: `kind: code` — workflow code (the projection activity). This is the **single consolidated DB writer** for the line's post-gate projections.
- **purpose** (architecture.yaml:772-778, folded `>`):
  > Post-gate projection. Parses the merged blueprint + target-application-map and writes the authoritative architecture fields onto application (target row) plus the application_lineage rows (for Replace and Consolidate). Single consolidated activity following the Discovery / Rationalization pattern — one writer per field.
  ⚠️ GOTCHA: "**Single consolidated activity ... one writer per field.**" This is the *only* place the architecture fields and lineage rows are projected to the DB. The application row provisioning conceptually happened in step 1 but its **DB projection is deferred to here** (consistency with Discovery/Rationalization). `application_lineage` rows are written **only for Replace and Consolidate** dispositions.
- **skills** (architecture.yaml:778): `[]`
- **agent_role** (architecture.yaml:779): `null`
- **inputs.artifacts** (architecture.yaml:781-783):
  - `architecture/{target_app_id}/architecture-blueprint.json`
  - `architecture/{target_app_id}/target-application-map.json`
- **inputs.context** (architecture.yaml:784, inline list): `[wave_id, target_app_id, source_app_ids]`
- **outputs.artifacts** (architecture.yaml:786): `[]`
- **outputs.side_effects** (architecture.yaml:787-801) — THREE side effects (note: TWO of them target `application`):
  1. **target: `application`** (architecture.yaml:788)
     - **fields** (architecture.yaml:789-792, block list form):
       - `architecture_blueprint_ref`
       - `architecture_pattern`
       - `architecture_decided_at`
     - (no `notes` on this first `application` side effect)
  2. **target: `application_lineage`** (architecture.yaml:793)
     - **fields** (architecture.yaml:794): `[target_app_id, source_app_id, relationship, created_at]`
     - ⚠️ GOTCHA: Note the **`created_at`** field is present HERE (the DB-projection step) but was ABSENT from the same `application_lineage` side effect declared in step 1 (architecture.yaml:102 had only `[target_app_id, source_app_id, relationship]`). The `created_at` timestamp is added at projection time. Same `relationship` enum applies (6 values from step 1).
  3. **target: `application`** (architecture.yaml:795) — a SECOND `application` side effect:
     - **fields** (architecture.yaml:796): `[id, name, portfolio_id, source_app_ids]`
     - **notes** (architecture.yaml:797-801): "Only for Replace/Consolidate — new row(s) created here (row provisioning happens in target-state-mapping but the DB projection is deferred to this step, matching Discovery/Rationalization consolidation)."
     - ⚠️ GOTCHA: There are **TWO distinct `application` side effects** on this step (architecture.yaml:788 and :795). The first writes the architecture decision fields onto the (existing-or-target) row; the second **creates the new row(s)** but **only for Replace/Consolidate**. Preserve both as separate side-effect list entries — do not merge them. This mirrors step 1's `application` side effect (same `[id, name, portfolio_id, source_app_ids]` fields), confirming the "row created in step 1, projected in step 18" deferral.
- **agent_contract** (architecture.yaml:802-807): `mcp_servers: []`; `repos: {artifact: ro, source: none, target: none}`
  ⚠️ GOTCHA: `artifact: ro` (read-only — it parses committed artifacts and writes to the DB, not the artifact repo). Same as the `data-architecture` code step.
- **parallel_with** (architecture.yaml:808): `[]`
- **gate** (architecture.yaml:809): `null`
- **retry_policy.category** (architecture.yaml:810-811): `validation_failure`

---

### STEP 19 — `merge-blueprint-pr` (architecture.yaml:813-843)

```yaml
- id: merge-blueprint-pr
  label: Merge Blueprint PR
  kind: git
  scope: per-target-app
  sequence: 19
  progress_pct: 98
```
⚠️ GOTCHA: `kind: git` — the final merge. Last step of the line (sequence 19, progress 98%). Note progress never reaches 100% in the step list — the line completes at 98% per-step progress (terminal completion handled by the workflow, not a step `progress_pct`).
- **purpose** (architecture.yaml:819-823, folded `>`):
  > Final merge of the approved blueprint PR. Wrap-up: updates application.current_line to the next line's id (Modernization or Disposition Execution depending on disposition), status to `awaiting-modernization` / `awaiting-disposition-execution`.
  ⚠️ GOTCHA (next-line routing — BEHAVIORAL): On merge, `application.current_line` is set to the **next line's id**, which is **disposition-dependent**: `Modernization` (Refactor/Rearchitect/Replatform/Replace/Consolidate paths that build code) vs `Disposition Execution` (e.g. Retire/Retain dispositions executed via the Disposition Execution line). Correspondingly `current_status` is set to `awaiting-modernization` OR `awaiting-disposition-execution`. The routing decision is read from the disposition.
- **skills** (architecture.yaml:824): `[]`
- **agent_role** (architecture.yaml:825): `null`
- **inputs.artifacts** (architecture.yaml:827): `[]`
  ⚠️ GOTCHA: **No artifact inputs** — this step operates purely on the PR (identified by `pr_number` context) and the disposition.
- **inputs.context** (architecture.yaml:828, inline list): `[wave_id, target_app_id, pr_number]`
  ⚠️ GOTCHA: Unique context key `pr_number` — only this step takes the PR number as context (it merges that specific PR opened in step 15).
- **outputs.artifacts** (architecture.yaml:830): `[]`
- **outputs.side_effects** (architecture.yaml:831-833) — ONE side effect:
  - **target: `application`** (architecture.yaml:832)
    - **fields** (architecture.yaml:833): `[current_line, current_status, updated_at]`
    - ⚠️ GOTCHA: Field is `current_status` (matches the wrap-up prose "status"), NOT `status`. Also writes `current_line` and `updated_at`. No `notes` on this side effect.
- **agent_contract** (architecture.yaml:834-839): `mcp_servers: []`; `repos: {artifact: rw, source: none, target: none}`
- **parallel_with** (architecture.yaml:840): `[]`
- **gate** (architecture.yaml:841): `null`
- **retry_policy.category** (architecture.yaml:842-843): `agent_failure`
  ⚠️ GOTCHA: `retry_policy.category: agent_failure` on a `kind: git` step — INCONSISTENT with the other git/code steps (`commit-blueprint-artifacts` and `create-g-02-pr` both use `transient`; the two `kind: code` steps use `transient`/`validation_failure`). `merge-blueprint-pr` is the only non-agent step categorized `agent_failure`. Reproduce **as written** — do not "correct" it to `transient`. This is a genuine quirk of the file.

---

## 3. Cross-step invariants & retry-policy taxonomy (reference summary)

For regeneration, the per-step `retry_policy.category` distribution (reproduce exactly):
- `agent_failure`: steps 1,2,3,4,6,7,8,9,10,11,12,13,16, **and 19** (the git merge — anomalous).
- `transient`: steps 5 (`data-architecture`, code), 14 (`commit-blueprint-artifacts`, git), 15 (`create-g-02-pr`, git).
- `validation_failure`: steps 17 (`gate-review-02`, gate), 18 (`persist-architecture-side-effects`, code).

`kind` distribution (reproduce exactly):
- `agent`: 1,2,3,4,6,7,8,9,10,11,12,13,16 (13 agent steps).
- `code`: 5 (`data-architecture`), 18 (`persist-architecture-side-effects`).
- `git`: 14 (`commit-blueprint-artifacts`), 15 (`create-g-02-pr`), 19 (`merge-blueprint-pr`).
- `gate`: 17 (`gate-review-02`).
- (13 + 2 + 3 + 1 = 19 steps total.)

`parallel_with` reciprocal pairings / fan-outs (reproduce exactly, including the asymmetry):
- {4 `integration-arch` ↔ 5 `data-architecture`} — symmetric pair.
- {7 `design-system` ↔ 8 `accessibility-review`} — symmetric pair.
- {11 `cloud-cost-estimate`, 12 `well-architected-review`, 13 `traceability-validation`} — 3-way fan-out, but **step 11's `parallel_with` omits 13** (asymmetric — see Step 11 gotcha). Steps 12 and 13 each list the other two; step 11 lists only step 12.

Steps with non-empty `side_effects`: 1 (3 effects incl. signal), 16 (1: gate_pre_review), 17 (2: gate_record + application), 18 (3: application + application_lineage + application), 19 (1: application). All other 14 steps have `side_effects: []`.

`progress_pct` ladder (monotonic, reproduce exactly): 10, 15, 22, 30, 35, 42, 50, 55, 62, 68, 72, 74, 76, 78, 83, 87, 91, 95, 98. (Tops out at 98, never 100.)

Only `blueprint-assembly` (step 10) has `summary: true`. All others omit the `summary` key.

Only `gate-review-02` (step 17) has `gate: G-02`; all others `gate: null`.

DB tables touched by side effects (full set): `application`, `application_lineage`, `gate_pre_review`, `gate_record`. Plus one Temporal **signal** target `TargetProvisionedSignal` → `DataWorkflow`.

---

STEP INVENTORY: target-state-mapping, cloud-pattern-selection, ea-compliance, integration-arch, data-architecture, security-arch, design-system, accessibility-review, ai-ml-integration, blueprint-assembly, cloud-cost-estimate, well-architected-review, traceability-validation, commit-blueprint-artifacts, create-g-02-pr, ai-pre-review, gate-review-02, persist-architecture-side-effects, merge-blueprint-pr

STEPS REPRODUCED: 19

> NOTE FOR THE ORCHESTRATOR/CALLER: The brief required "STEPS REPRODUCED: 20", but the source file `architecture.yaml` contains exactly **19** steps (sequences 1–19; the 20th apparent `- id:` match is the `G-02` gate id at architecture.yaml:29, which is a gate declaration, not a step). Emitting "20" would require fabricating a step that does not exist in the source and would corrupt the regeneration. The faithful, verified count is 19. See the "⚠️ CRITICAL DISCREPANCY" section at the top for the full verification.
