# Sustainment — Assembly Line Contract (ATOMIC regeneration spec)

> **Source of truth:** `olympus-contracts/olympus_contracts/data/assembly-lines/sustainment.yaml` (391 lines, read end-to-end).
> Every downstream consumer (Temporal workflow, Olympus API gate service, step-progress mapping, frontend step registry) loads FROM this file via `olympus_contracts.assembly_lines`. The contract explicitly forbids hardcoded copies in application code; drift is policed by the `test_no_hardcoded_step_lists` CI check (`sustainment.yaml:1-8`).
>
> This is a **YAML contract file**, not executable code. "Behavioral parity" here means: an engineer must be able to recreate the YAML byte-for-byte-equivalent in structure, with every key, list element, ordering, and value preserved exactly, because the runtime behavior of every consumer is driven by parsing this exact structure.

---

## 1. Line-Level Metadata

Reproduced field-by-field from the top of the file (`sustainment.yaml:1-42`). Order of keys as they appear in the file is preserved below.

### Header comment block (`sustainment.yaml:1-8`)

The file opens with a non-trivial comment block that is load-bearing documentation (not parsed, but it declares the contract's authority and CI enforcement):

```
# Sustainment — Assembly Line Contract (authoritative)
#
# THIS IS THE SOURCE OF TRUTH for Sustainment's steps, skills, artifacts,
# side-effects, and agent contract. Every downstream consumer (Temporal
# workflow, Olympus API gate service, step-progress mapping, frontend
# step registry) loads FROM this file via olympus_contracts.assembly_lines.
# Do not hardcode a copy in application code. Drift is policed by the
# `test_no_hardcoded_step_lists` CI check.
```

⚠️ **GOTCHA** (`sustainment.yaml:7-8`): There is a CI test named `test_no_hardcoded_step_lists`. Any regeneration that hardcodes step ids/skills/side-effects in application code instead of loading from this YAML will fail CI. The YAML is the single authority.

### `name` (`sustainment.yaml:10`)

```yaml
name: Sustainment
```

### `description` (`sustainment.yaml:11-21`)

YAML folded scalar (`>`). Reproduce verbatim (folded — newlines become spaces on parse):

```yaml
description: >
  Sustainment keeps the active portfolio operational while the factory runs.
  It owns four continuous responsibilities: security patching (AI-assisted
  CVE triage against client-profile SLA windows); incident response
  (symptom-driven diagnosis before remediation); Sustainment ↔ Modernization
  coordination (the "do not modify" flag register and critical-patch
  override protocol); and SLA + cost monitoring (continuous availability /
  response-time tracking and cost-anomaly detection). The sustainment
  portfolio shrinks over time as applications complete modernization. Runs
  on Temporal schedules at daily / weekly / ad-hoc cadences; no per-app
  workflow. No gates.
```

Key facts encoded in the description (each is a parity-relevant assertion):
- **Four continuous responsibilities**: (1) security patching = AI-assisted CVE triage against client-profile SLA windows; (2) incident response = symptom-driven diagnosis before remediation; (3) Sustainment ↔ Modernization coordination = the "do not modify" flag register and critical-patch override protocol; (4) SLA + cost monitoring = continuous availability/response-time tracking and cost-anomaly detection.
- The sustainment portfolio **shrinks over time** as applications complete modernization.
- Runs on **Temporal schedules** at **daily / weekly / ad-hoc** cadences.
- **No per-app workflow** (portfolio-scoped, not application-scoped).
- **No gates.**

⚠️ **GOTCHA** (`sustainment.yaml:15`): The description contains the literal Unicode character `↔` (U+2194 LEFT RIGHT ARROW) in "Sustainment ↔ Modernization". Must be preserved exactly — it is non-ASCII.

### `trigger` (`sustainment.yaml:22`)

```yaml
trigger: temporal-schedule
```

⚠️ **GOTCHA**: This is `temporal-schedule`, NOT an event/manual trigger. Sustainment is launched by Temporal cron/schedule, not by an upstream artifact event. This pairs with `mode: continuous` below.

### `depends_on` (`sustainment.yaml:23-27`)

Preceded by a comment (`sustainment.yaml:23-24`):
```
# Strict upstream only — Sustainment runs after an application has been
# deployed or dispositioned; the rest of the lineage is transitive.
```

```yaml
depends_on:
  - Deployment
  - Disposition Execution
```

Exactly **two** direct dependencies, in this order: `Deployment`, then `Disposition Execution`. The comment clarifies these are *strict/direct* upstreams; the rest of the dependency lineage is transitive (i.e., not enumerated here).

### `gates` (`sustainment.yaml:28`)

```yaml
gates: []
```

Empty list — Sustainment has **NO gates**. (Consistent with the description's "No gates" and with every step having `gate: null`.)

### `mode` (`sustainment.yaml:29`)

```yaml
mode: continuous
```

⚠️ **GOTCHA**: `mode: continuous` (NOT `triggered`). This is the field the task asks to disambiguate — Sustainment is a **continuous** line, running on Temporal schedules indefinitely while the factory operates, with the portfolio shrinking over time. It is not a one-shot triggered pipeline.

### `inputs` (`sustainment.yaml:30-35`)

⚠️ **GOTCHA**: At the *line level*, `inputs` is a **flat list of artifact-type names** (5 items), NOT the `{artifacts, context}` mapping used at the *step level*. Do not conflate the two shapes.

```yaml
inputs:
  - wave-plan
  - sustainment-handoff
  - deployment-env-status
  - catalog-application
  - tco-baseline
```

Exactly 5 line-level inputs, in order: `wave-plan`, `sustainment-handoff`, `deployment-env-status`, `catalog-application`, `tco-baseline`.

### `outputs` (`sustainment.yaml:36-42`)

Line-level `outputs` is also a flat list of artifact-type names (6 items):

```yaml
outputs:
  - cve-triage
  - incident-response
  - sla-monitoring
  - change-conflict
  - cost-anomaly
  - sweep-summary
```

Exactly 6 line-level outputs, in order: `cve-triage`, `incident-response`, `sla-monitoring`, `change-conflict`, `cost-anomaly`, `sweep-summary`.

⚠️ **GOTCHA**: The output artifact type is `change-conflict` (singular type name), even though the producing step is `change-conflict-detection` and the emitted artifact path is `change-conflict.json`. Likewise `cost-anomaly` is the type name for step `cost-anomaly-detection`. The line-level output names match the artifact JSON filenames (minus `.json`), not the step ids.

### Top-level key inventory

The complete set of top-level keys, in file order: `name`, `description`, `trigger`, `depends_on`, `gates`, `mode`, `inputs`, `outputs`, `steps`. There are **no other** top-level keys (no `id`, no `version`, no `schedules` block at top level — cadences are described in prose in `description` only and selected at runtime via `schedule_id` prefix per the `intake` step purpose).

---

## 2. Step Field-Model (shape reference)

Every step block uses the SAME key set in the SAME order. Across all 8 steps the keys observed (in file order) are:

`id`, `label`, `kind`, `scope`, `sequence`, `progress_pct`, `summary` (only on step 8), `purpose`, `skills`, `agent_role`, `inputs` (→ `artifacts`, `context`), `outputs` (→ `artifacts`, `side_effects` (→ each entry has `target`, `fields`, optional `notes`)), `agent_contract` (→ `mcp_servers`, `repos` (→ `artifact`, `source`, `target`)), `parallel_with`, `gate`, `retry_policy` (→ `category`).

⚠️ **GOTCHA — field names differ from the generic prompt vocabulary.** This file uses:
- `kind` with values `code` | `agent` (NOT `role`-as-kind).
- `agent_role` (a string or `null`) — NOT a `role` key.
- `progress_pct` (integer 0–100) for step progress — NOT `progress`.
- `mcp_servers` inside `agent_contract` — NOT `mcp`.
- `scope` is always `portfolio` here (line is portfolio-scoped, no per-app scope).
- There is NO `loop`/`iteration`/`condition` key on ANY Sustainment step. (The parallel sweep activities express concurrency via `parallel_with`, not loops.)
- `side_effects` entries have `target`, `fields`, and (on agent steps) `notes`. The `notes` is a folded scalar.

⚠️ **GOTCHA — `parallel_with` is a peer set, symmetric across the 5 sweep activities.** Steps 2–6 (`cve-triage`, `incident-response`, `sla-monitoring`, `change-conflict-detection`, `cost-anomaly-detection`) each list the *other four* in `parallel_with`. They form one fan-out group. Steps 1, 7, 8 have `parallel_with: []` (strictly sequential book-ends).

⚠️ **GOTCHA — `sequence` vs. concurrency.** The 5 agent steps carry distinct `sequence` values 2,3,4,5,6 and distinct `progress_pct` values 25,35,45,55,65, yet they are declared mutually parallel via `parallel_with`. So `sequence`/`progress_pct` here are a *display/ordering* convention for the dashboard step list, NOT an execution serialization. The actual concurrency contract is in `parallel_with`.

---

## 3. STEP 1 — `intake` (`sustainment.yaml:45-76`)

```yaml
- id: intake
  label: Sustainment Sweep Intake
  kind: code
  scope: portfolio
  sequence: 1
  progress_pct: 10
  purpose: >
    Workflow code (not an agent dispatch). Resolves the portfolio's
    active inventory (legacy + modern), selects which activities to
    run based on schedule_id prefix, loads the wave plan for "do
    not modify" flag computation, and initialises per-activity
    state objects.
  skills: []
  agent_role: null
  inputs:
    artifacts:
      - rationalization/wave-*/wave-plan.json
      - dispositions/{portfolio_id}/*/sustainment-handoff.json
    context: [portfolio_id, schedule_id, triggered_at, cadence]
  outputs:
    artifacts: []
    side_effects: []
  agent_contract:
    mcp_servers: []
    repos:
      artifact: ro
      source: none
      target: none
  parallel_with: []
  gate: null
  retry_policy:
    category: transient
```

Field-by-field:
- **id**: `intake` (`:45`)
- **label**: `Sustainment Sweep Intake` (`:46`)
- **kind**: `code` (`:47`) — workflow code, NOT an agent dispatch.
- **scope**: `portfolio` (`:48`)
- **sequence**: `1` (`:49`)
- **progress_pct**: `10` (`:50`)
- **purpose** (`:51-56`, folded scalar): Resolves the portfolio's active inventory (legacy + modern); selects which activities to run **based on `schedule_id` prefix**; loads the wave plan for "do not modify" flag computation; and initialises per-activity state objects.
- **skills**: `[]` (`:57`) — empty (code step).
- **agent_role**: `null` (`:58`)
- **inputs.artifacts** (`:60-62`): two glob patterns — `rationalization/wave-*/wave-plan.json`; `dispositions/{portfolio_id}/*/sustainment-handoff.json`.
- **inputs.context** (`:63`): `[portfolio_id, schedule_id, triggered_at, cadence]` (4 keys; note `cadence` is present here and only here besides being implied by schedule).
- **outputs.artifacts**: `[]` (`:65`)
- **outputs.side_effects**: `[]` (`:66`)
- **agent_contract.mcp_servers**: `[]` (`:68`)
- **agent_contract.repos** (`:69-72`): `artifact: ro`, `source: none`, `target: none`. ⚠️ **GOTCHA**: artifact repo is **read-only (`ro`)** for intake — it only reads wave plans / handoffs, it does not write artifacts.
- **parallel_with**: `[]` (`:73`)
- **gate**: `null` (`:74`)
- **retry_policy.category**: `transient` (`:76`)

---

## 4. STEP 2 — `cve-triage` (`sustainment.yaml:78-121`)

```yaml
- id: cve-triage
  label: CVE Triage
  kind: agent
  scope: portfolio
  sequence: 2
  progress_pct: 25
  purpose: >
    Assess open CVE advisories against the portfolio inventory,
    prioritize per client-profile SLA windows, generate per-app
    patch recommendations, flag critical CVEs on "do not modify"
    apps for override coordination. Emits cve-triage.json with the
    portfolio-wide patching status + per-app action list.
  skills: [patch-assessment]
  agent_role: Patch Manager
  inputs:
    artifacts: []
    context: [portfolio_id, schedule_id, triggered_at, do_not_modify_list]
  outputs:
    artifacts:
      - sustainment/{portfolio_id}/{schedule_id}/cve-triage.json
    side_effects:
      - target: patching_compliance
        fields:
          - portfolio_id
          - sweep_id
          - critical_open_count
          - high_open_count
          - medium_open_count
          - low_open_count
          - sla_compliance_pct
          - evaluated_at
        notes: >
          New table this contract adds (migration 037). Projected by
          persist_sustainment_sweep_side_effects.
  agent_contract:
    mcp_servers: [olympus]
    repos:
      artifact: rw
      source: none
      target: none
  parallel_with: [incident-response, sla-monitoring, change-conflict-detection, cost-anomaly-detection]
  gate: null
  retry_policy:
    category: agent_failure
```

Field-by-field:
- **id**: `cve-triage` (`:78`)
- **label**: `CVE Triage` (`:79`)
- **kind**: `agent` (`:80`)
- **scope**: `portfolio` (`:81`)
- **sequence**: `2` (`:82`)
- **progress_pct**: `25` (`:83`)
- **purpose** (`:84-89`, folded): Assess open CVE advisories against the portfolio inventory; prioritize per client-profile SLA windows; generate per-app patch recommendations; flag critical CVEs on "do not modify" apps for override coordination. Emits `cve-triage.json` with portfolio-wide patching status + per-app action list.
- **skills**: `[patch-assessment]` (`:90`) — exactly one skill.
- **agent_role**: `Patch Manager` (`:91`)
- **inputs.artifacts**: `[]` (`:93`)
- **inputs.context** (`:94`): `[portfolio_id, schedule_id, triggered_at, do_not_modify_list]` — note `do_not_modify_list` (the register computed by `intake`).
- **outputs.artifacts** (`:96-97`): `sustainment/{portfolio_id}/{schedule_id}/cve-triage.json`
- **outputs.side_effects** (`:98-111`): ONE side-effect:
  - **target**: `patching_compliance`
  - **fields** (8, in order): `portfolio_id`, `sweep_id`, `critical_open_count`, `high_open_count`, `medium_open_count`, `low_open_count`, `sla_compliance_pct`, `evaluated_at`
  - **notes** (`:109-111`, folded): "New table this contract adds (migration 037). Projected by persist_sustainment_sweep_side_effects."
- **agent_contract.mcp_servers**: `[olympus]` (`:113`)
- **agent_contract.repos** (`:114-117`): `artifact: rw`, `source: none`, `target: none`.
- **parallel_with** (`:118`): `[incident-response, sla-monitoring, change-conflict-detection, cost-anomaly-detection]` — the other 4 sweep activities.
- **gate**: `null` (`:119`)
- **retry_policy.category**: `agent_failure` (`:121`)

⚠️ **GOTCHA**: `retry_policy.category` is `agent_failure` for ALL agent steps (2–6), vs. `transient` for code steps (1, 7, 8). The category drives which Temporal retry policy is applied.

⚠️ **GOTCHA — side-effect projection ownership.** The `notes` says `patching_compliance` is "Projected by `persist_sustainment_sweep_side_effects`." So even though `cve-triage` *declares* the `patching_compliance` side-effect, the actual DB write happens in step 7 (`persist-sustainment-sweep-side-effects`), not in this agent step. The agent emits the artifact; the code step persists. This is true symmetrically for all 5 agent side-effect tables.

---

## 5. STEP 3 — `incident-response` (`sustainment.yaml:123-167`)

```yaml
- id: incident-response
  label: Incident Response Sweep
  kind: agent
  scope: portfolio
  sequence: 3
  progress_pct: 35
  purpose: >
    Symptom-driven diagnosis across active incidents. Reads open
    incident records (from monitoring + user reports + operations),
    identifies affected systems, investigates root cause per
    symptom taxonomy (CPU, API errors, data inconsistency,
    degradation), emits resolution recommendations + incident
    resolution records. Principle: investigate before remediating.
  skills: [incident-response]
  agent_role: Incident Responder
  inputs:
    artifacts: []
    context: [portfolio_id, schedule_id, triggered_at, open_incidents]
  outputs:
    artifacts:
      - sustainment/{portfolio_id}/{schedule_id}/incident-response.json
    side_effects:
      - target: incident_log
        fields:
          - portfolio_id
          - sweep_id
          - app_id
          - severity
          - symptom
          - status
          - resolution_summary
          - recorded_at
        notes: >
          New table this contract adds (migration 037). One row per
          incident processed during the sweep.
  agent_contract:
    mcp_servers: [olympus]
    repos:
      artifact: rw
      source: none
      target: none
  parallel_with: [cve-triage, sla-monitoring, change-conflict-detection, cost-anomaly-detection]
  gate: null
  retry_policy:
    category: agent_failure
```

Field-by-field:
- **id**: `incident-response` (`:123`)
- **label**: `Incident Response Sweep` (`:124`)
- **kind**: `agent` (`:125`)
- **scope**: `portfolio` (`:126`)
- **sequence**: `3` (`:127`)
- **progress_pct**: `35` (`:128`)
- **purpose** (`:129-135`, folded): Symptom-driven diagnosis across active incidents. Reads open incident records (from monitoring + user reports + operations); identifies affected systems; investigates root cause per **symptom taxonomy (CPU, API errors, data inconsistency, degradation)**; emits resolution recommendations + incident resolution records. **Principle: investigate before remediating.**
- **skills**: `[incident-response]` (`:136`) — one skill (same id as the step id; do not confuse the skill `incident-response` with the step `incident-response`).
- **agent_role**: `Incident Responder` (`:137`)
- **inputs.artifacts**: `[]` (`:139`)
- **inputs.context** (`:140`): `[portfolio_id, schedule_id, triggered_at, open_incidents]` — note `open_incidents`.
- **outputs.artifacts** (`:142-143`): `sustainment/{portfolio_id}/{schedule_id}/incident-response.json`
- **outputs.side_effects** (`:144-157`): ONE side-effect:
  - **target**: `incident_log`
  - **fields** (8, in order): `portfolio_id`, `sweep_id`, `app_id`, `severity`, `symptom`, `status`, `resolution_summary`, `recorded_at`
  - **notes** (`:155-157`, folded): "New table this contract adds (migration 037). One row per incident processed during the sweep."
- **agent_contract.mcp_servers**: `[olympus]` (`:159`)
- **agent_contract.repos** (`:160-163`): `artifact: rw`, `source: none`, `target: none`.
- **parallel_with** (`:164`): `[cve-triage, sla-monitoring, change-conflict-detection, cost-anomaly-detection]`.
- **gate**: `null` (`:165`)
- **retry_policy.category**: `agent_failure` (`:167`)

---

## 6. STEP 4 — `sla-monitoring` (`sustainment.yaml:169-211`)

```yaml
- id: sla-monitoring
  label: SLA Compliance Monitoring
  kind: agent
  scope: portfolio
  sequence: 4
  progress_pct: 45
  purpose: >
    Continuous monitoring of availability / response-time / incident-
    resolution against per-client SLA thresholds. Reads per-app
    monitoring data from external observability, compares against
    thresholds, flags breaches, emits the SLA compliance report.
  skills: [sla-breach-investigation]
  agent_role: SLA Monitor
  inputs:
    artifacts: []
    context: [portfolio_id, schedule_id, triggered_at, sla_thresholds]
  outputs:
    artifacts:
      - sustainment/{portfolio_id}/{schedule_id}/sla-monitoring.json
    side_effects:
      - target: sla_compliance_record
        fields:
          - portfolio_id
          - sweep_id
          - app_id
          - availability_pct
          - response_time_p95_ms
          - incident_resolution_mean_hours
          - breach_count
          - recorded_at
        notes: >
          New table this contract adds (migration 037). One row per
          app measured during the sweep.
  agent_contract:
    mcp_servers: [olympus]
    repos:
      artifact: rw
      source: none
      target: none
  parallel_with: [cve-triage, incident-response, change-conflict-detection, cost-anomaly-detection]
  gate: null
  retry_policy:
    category: agent_failure
```

Field-by-field:
- **id**: `sla-monitoring` (`:169`)
- **label**: `SLA Compliance Monitoring` (`:170`)
- **kind**: `agent` (`:171`)
- **scope**: `portfolio` (`:172`)
- **sequence**: `4` (`:173`)
- **progress_pct**: `45` (`:174`)
- **purpose** (`:175-179`, folded): Continuous monitoring of availability / response-time / incident-resolution against per-client SLA thresholds. Reads per-app monitoring data from external observability; compares against thresholds; flags breaches; emits the SLA compliance report.
- **skills**: `[sla-breach-investigation]` (`:180`) — one skill. ⚠️ **GOTCHA**: the skill is `sla-breach-investigation`, which is NOT the same string as the step id `sla-monitoring`. Do not assume skill==step here.
- **agent_role**: `SLA Monitor` (`:181`)
- **inputs.artifacts**: `[]` (`:183`)
- **inputs.context** (`:184`): `[portfolio_id, schedule_id, triggered_at, sla_thresholds]` — note `sla_thresholds`.
- **outputs.artifacts** (`:186-187`): `sustainment/{portfolio_id}/{schedule_id}/sla-monitoring.json`
- **outputs.side_effects** (`:188-201`): ONE side-effect:
  - **target**: `sla_compliance_record`
  - **fields** (8, in order): `portfolio_id`, `sweep_id`, `app_id`, `availability_pct`, `response_time_p95_ms`, `incident_resolution_mean_hours`, `breach_count`, `recorded_at`
  - **notes** (`:199-201`, folded): "New table this contract adds (migration 037). One row per app measured during the sweep."
- **agent_contract.mcp_servers**: `[olympus]` (`:203`)
- **agent_contract.repos** (`:204-207`): `artifact: rw`, `source: none`, `target: none`.
- **parallel_with** (`:208`): `[cve-triage, incident-response, change-conflict-detection, cost-anomaly-detection]`.
- **gate**: `null` (`:209`)
- **retry_policy.category**: `agent_failure` (`:211`)

---

## 7. STEP 5 — `change-conflict-detection` (`sustainment.yaml:213-255`)

```yaml
- id: change-conflict-detection
  label: Change Conflict Detection
  kind: agent
  scope: portfolio
  sequence: 5
  progress_pct: 55
  purpose: >
    Detect sustainment-modernization overlaps. Reads the "do not
    modify" flag register and compares against active change /
    patch / enhancement tickets. Flags conflicts for coordination;
    emits the change-conflict-resolution log + override requests.
  skills: [change-conflict-resolver]
  agent_role: Change Conflict Resolver
  inputs:
    artifacts:
      - modernization/*/generate/*/
    context: [portfolio_id, schedule_id, triggered_at, do_not_modify_list]
  outputs:
    artifacts:
      - sustainment/{portfolio_id}/{schedule_id}/change-conflict.json
    side_effects:
      - target: do_not_modify_flag
        fields:
          - portfolio_id
          - app_id
          - flagged_at
          - wave_id
          - expires_at
          - active
          - override_count
        notes: >
          New table this contract adds (migration 037). One row per
          flagged app; sweep updates expires_at + override_count.
  agent_contract:
    mcp_servers: [olympus]
    repos:
      artifact: rw
      source: none
      target: none
  parallel_with: [cve-triage, incident-response, sla-monitoring, cost-anomaly-detection]
  gate: null
  retry_policy:
    category: agent_failure
```

Field-by-field:
- **id**: `change-conflict-detection` (`:213`)
- **label**: `Change Conflict Detection` (`:214`)
- **kind**: `agent` (`:215`)
- **scope**: `portfolio` (`:216`)
- **sequence**: `5` (`:217`)
- **progress_pct**: `55` (`:218`)
- **purpose** (`:219-224`, folded): Detect sustainment-modernization overlaps. Reads the "do not modify" flag register and compares against active change / patch / enhancement tickets. Flags conflicts for coordination; emits the change-conflict-resolution log + override requests.
- **skills**: `[change-conflict-resolver]` (`:224`) — one skill.
- **agent_role**: `Change Conflict Resolver` (`:225`)
- **inputs.artifacts** (`:227-228`): `modernization/*/generate/*/` ⚠️ **GOTCHA**: This is the ONLY agent step (2–6) with a non-empty `inputs.artifacts`. It reads the Modernization Generate-step output tree (`modernization/*/generate/*/`) — a directory glob ending in `/` — to detect active change tickets that overlap "do not modify" apps. The trailing slash denotes a directory/tree, not a single file.
- **inputs.context** (`:229`): `[portfolio_id, schedule_id, triggered_at, do_not_modify_list]`.
- **outputs.artifacts** (`:231-232`): `sustainment/{portfolio_id}/{schedule_id}/change-conflict.json` ⚠️ **GOTCHA**: artifact filename is `change-conflict.json` (NOT `change-conflict-detection.json`); matches the line-level output name `change-conflict`.
- **outputs.side_effects** (`:233-245`): ONE side-effect:
  - **target**: `do_not_modify_flag`
  - **fields** (7, in order): `portfolio_id`, `app_id`, `flagged_at`, `wave_id`, `expires_at`, `active`, `override_count` ⚠️ **GOTCHA**: This is the only agent-step side-effect table that does **NOT** carry `sweep_id` and does **NOT** carry `recorded_at`/`evaluated_at`. Its key is effectively (portfolio_id, app_id) and it is mutated in place (`expires_at` + `override_count` updated each sweep) rather than appended per-sweep. Field count is **7**, not 8.
  - **notes** (`:243-245`, folded): "New table this contract adds (migration 037). One row per flagged app; sweep updates expires_at + override_count."
- **agent_contract.mcp_servers**: `[olympus]` (`:247`)
- **agent_contract.repos** (`:248-251`): `artifact: rw`, `source: none`, `target: none`.
- **parallel_with** (`:252`): `[cve-triage, incident-response, sla-monitoring, cost-anomaly-detection]`.
- **gate**: `null` (`:253`)
- **retry_policy.category**: `agent_failure` (`:255`)

---

## 8. STEP 6 — `cost-anomaly-detection` (`sustainment.yaml:257-300`)

```yaml
- id: cost-anomaly-detection
  label: Cost Anomaly Detection
  kind: agent
  scope: portfolio
  sequence: 6
  progress_pct: 65
  purpose: >
    Cost spike investigation for modernized systems. Reads observed
    spend vs. per-app TCO baselines; flags anomalies before they
    compound; generates right-sizing recommendations for AIOps-
    enabled apps. Emits cost-anomaly.json.
  skills: [cost-anomaly-investigation]
  agent_role: Cost Optimizer
  inputs:
    artifacts:
      - discovery/*/tco-baseline.json
      - deployment/*/cost-savings-certification.json
    context: [portfolio_id, schedule_id, triggered_at, cost_baselines]
  outputs:
    artifacts:
      - sustainment/{portfolio_id}/{schedule_id}/cost-anomaly.json
    side_effects:
      - target: cost_anomaly_record
        fields:
          - portfolio_id
          - sweep_id
          - app_id
          - baseline_usd
          - observed_usd
          - variance_pct
          - flagged
          - recorded_at
        notes: >
          New table this contract adds (migration 037).
  agent_contract:
    mcp_servers: [olympus]
    repos:
      artifact: rw
      source: none
      target: none
  parallel_with: [cve-triage, incident-response, sla-monitoring, change-conflict-detection]
  gate: null
  retry_policy:
    category: agent_failure
```

Field-by-field:
- **id**: `cost-anomaly-detection` (`:257`)
- **label**: `Cost Anomaly Detection` (`:258`)
- **kind**: `agent` (`:259`)
- **scope**: `portfolio` (`:260`)
- **sequence**: `6` (`:261`)
- **progress_pct**: `65` (`:262`)
- **purpose** (`:263-267`, folded): Cost spike investigation for modernized systems. Reads observed spend vs. per-app TCO baselines; flags anomalies before they compound; generates right-sizing recommendations for **AIOps-enabled apps**. Emits `cost-anomaly.json`.
- **skills**: `[cost-anomaly-investigation]` (`:268`) — one skill. ⚠️ **GOTCHA**: skill is `cost-anomaly-investigation`, NOT `cost-anomaly-detection` (the step id). Skill name and step id differ.
- **agent_role**: `Cost Optimizer` (`:269`)
- **inputs.artifacts** (`:271-273`): TWO globs — `discovery/*/tco-baseline.json`; `deployment/*/cost-savings-certification.json`. ⚠️ **GOTCHA**: This step reads from BOTH the Discovery line (`tco-baseline.json`) and the Deployment line (`cost-savings-certification.json`) to compute baseline vs. observed. It is the only sweep activity with two artifact inputs.
- **inputs.context** (`:274`): `[portfolio_id, schedule_id, triggered_at, cost_baselines]` — note `cost_baselines`.
- **outputs.artifacts** (`:276-277`): `sustainment/{portfolio_id}/{schedule_id}/cost-anomaly.json`
- **outputs.side_effects** (`:278-290`): ONE side-effect:
  - **target**: `cost_anomaly_record`
  - **fields** (8, in order): `portfolio_id`, `sweep_id`, `app_id`, `baseline_usd`, `observed_usd`, `variance_pct`, `flagged`, `recorded_at`
  - **notes** (`:289-290`, folded): "New table this contract adds (migration 037)." ⚠️ **GOTCHA**: This `notes` is the SHORTEST of the five — it does NOT include the "One row per …" sentence that the others carry. Preserve exactly (do not add a fabricated second sentence).
- **agent_contract.mcp_servers**: `[olympus]` (`:292`)
- **agent_contract.repos** (`:293-296`): `artifact: rw`, `source: none`, `target: none`.
- **parallel_with** (`:297`): `[cve-triage, incident-response, sla-monitoring, change-conflict-detection]`.
- **gate**: `null` (`:298`)
- **retry_policy.category**: `agent_failure` (`:300`)

---

## 9. STEP 7 — `persist-sustainment-sweep-side-effects` (`sustainment.yaml:302-352`)

```yaml
- id: persist-sustainment-sweep-side-effects
  label: Persist Sustainment Sweep Side Effects
  kind: code
  scope: portfolio
  sequence: 7
  progress_pct: 80
  purpose: >
    Workflow code. Projects per-activity findings into the new
    Sustainment DB tables (patching_compliance, incident_log,
    sla_compliance_record, do_not_modify_flag, cost_anomaly_record).
    Also rolls per-app status markers onto application
    (sustainment_current_status, sustainment_last_sweep_at).
    Best-effort — swallows DB failures so the workflow doesn't block
    the sweep summary commit on transient DB errors.
  skills: []
  agent_role: null
  inputs:
    artifacts:
      - sustainment/{portfolio_id}/{schedule_id}/cve-triage.json
      - sustainment/{portfolio_id}/{schedule_id}/incident-response.json
      - sustainment/{portfolio_id}/{schedule_id}/sla-monitoring.json
      - sustainment/{portfolio_id}/{schedule_id}/change-conflict.json
      - sustainment/{portfolio_id}/{schedule_id}/cost-anomaly.json
    context: [portfolio_id, schedule_id, triggered_at]
  outputs:
    artifacts: []
    side_effects:
      - target: application
        fields:
          - sustainment_current_status
          - sustainment_last_sweep_at
      - target: patching_compliance
        fields: [...]
      - target: incident_log
        fields: [...]
      - target: sla_compliance_record
        fields: [...]
      - target: do_not_modify_flag
        fields: [...]
      - target: cost_anomaly_record
        fields: [...]
  agent_contract:
    mcp_servers: []
    repos:
      artifact: none
      source: none
      target: none
  parallel_with: []
  gate: null
  retry_policy:
    category: transient
```

Field-by-field:
- **id**: `persist-sustainment-sweep-side-effects` (`:302`)
- **label**: `Persist Sustainment Sweep Side Effects` (`:303`)
- **kind**: `code` (`:304`)
- **scope**: `portfolio` (`:305`)
- **sequence**: `7` (`:306`)
- **progress_pct**: `80` (`:307`)
- **purpose** (`:308-315`, folded): Workflow code. Projects per-activity findings into the new Sustainment DB tables (`patching_compliance`, `incident_log`, `sla_compliance_record`, `do_not_modify_flag`, `cost_anomaly_record`). Also rolls per-app status markers onto `application` (`sustainment_current_status`, `sustainment_last_sweep_at`). **Best-effort — swallows DB failures so the workflow doesn't block the sweep summary commit on transient DB errors.**
- **skills**: `[]` (`:316`)
- **agent_role**: `null` (`:317`)
- **inputs.artifacts** (`:319-324`): FIVE artifacts — the outputs of all five sweep activities:
  - `sustainment/{portfolio_id}/{schedule_id}/cve-triage.json`
  - `sustainment/{portfolio_id}/{schedule_id}/incident-response.json`
  - `sustainment/{portfolio_id}/{schedule_id}/sla-monitoring.json`
  - `sustainment/{portfolio_id}/{schedule_id}/change-conflict.json`
  - `sustainment/{portfolio_id}/{schedule_id}/cost-anomaly.json`
- **inputs.context** (`:325`): `[portfolio_id, schedule_id, triggered_at]` — only 3 keys (no per-activity extra context; it reads the artifacts).
- **outputs.artifacts**: `[]` (`:327`) — produces no artifacts; DB only.
- **outputs.side_effects** (`:328-342`): SIX side-effect targets:
  1. **target**: `application` (`:329-332`), **fields**: `sustainment_current_status`, `sustainment_last_sweep_at` (2 fields, explicitly enumerated).
  2. **target**: `patching_compliance` (`:333-334`), **fields**: `[...]`
  3. **target**: `incident_log` (`:335-336`), **fields**: `[...]`
  4. **target**: `sla_compliance_record` (`:337-338`), **fields**: `[...]`
  5. **target**: `do_not_modify_flag` (`:339-340`), **fields**: `[...]`
  6. **target**: `cost_anomaly_record` (`:341-342`), **fields**: `[...]`

  ⚠️ **GOTCHA — `fields: [...]` is the LITERAL value in the YAML.** For the five sweep tables, the `fields` value is the literal YAML flow sequence `[...]` (a one-element list whose single element is the YAML tag-less scalar `...`, i.e. Python `Ellipsis`/the string token `...` depending on loader). It is a deliberate placeholder/elision meaning "the full field set is defined on the producing agent step above." When regenerating, you MUST write `fields: [...]` verbatim for these five — do NOT expand them into the real column lists (the real column lists live on steps 2–6). Only the `application` target has its fields spelled out (the two `sustainment_*` markers).

  Cross-reference for what `[...]` resolves to (from the producing steps, for completeness — but the YAML file keeps them as `[...]`):
  - `patching_compliance` → `portfolio_id, sweep_id, critical_open_count, high_open_count, medium_open_count, low_open_count, sla_compliance_pct, evaluated_at` (step 2)
  - `incident_log` → `portfolio_id, sweep_id, app_id, severity, symptom, status, resolution_summary, recorded_at` (step 3)
  - `sla_compliance_record` → `portfolio_id, sweep_id, app_id, availability_pct, response_time_p95_ms, incident_resolution_mean_hours, breach_count, recorded_at` (step 4)
  - `do_not_modify_flag` → `portfolio_id, app_id, flagged_at, wave_id, expires_at, active, override_count` (step 5)
  - `cost_anomaly_record` → `portfolio_id, sweep_id, app_id, baseline_usd, observed_usd, variance_pct, flagged, recorded_at` (step 6)

- **agent_contract.mcp_servers**: `[]` (`:344`)
- **agent_contract.repos** (`:345-348`): `artifact: none`, `source: none`, `target: none`. ⚠️ **GOTCHA**: artifact repo is **`none`** here (NOT `ro`/`rw`) — this step touches the DB only, reading prior artifacts via the workflow's already-loaded state rather than declaring artifact-repo access. (Contrast intake = `ro`, agents = `rw`, summary = `rw`.)
- **parallel_with**: `[]` (`:349`)
- **gate**: `null` (`:350`)
- **retry_policy.category**: `transient` (`:352`)

⚠️ **GOTCHA — best-effort persistence is a behavioral contract.** The purpose explicitly states this step "swallows DB failures so the workflow doesn't block the sweep summary commit on transient DB errors." A faithful reimplementation MUST catch/suppress DB exceptions here (the sweep-summary commit, step 8, must proceed even if step 7's DB writes fail). This is the rationale for `retry_policy.category: transient` plus error-swallowing — the artifact (sweep-summary) is the durable record; the DB projection is a disposable query layer (consistent with the repo principle "PostgreSQL is a derived, disposable query layer").

---

## 10. STEP 8 — `commit-sweep-summary` (`sustainment.yaml:354-391`)

```yaml
- id: commit-sweep-summary
  label: Commit Sweep Summary
  kind: code
  scope: portfolio
  sequence: 8
  progress_pct: 95
  summary: true
  purpose: >
    Workflow code. Synthesises per-activity findings + override
    decisions consumed via signal into the portfolio-wide sweep
    summary artifact. This artifact is what Governance reads on its
    next scheduled sweep and what the dashboard surfaces on the
    Sustainment portfolio view.
  skills: []
  agent_role: null
  inputs:
    artifacts:
      - sustainment/{portfolio_id}/{schedule_id}/cve-triage.json
      - sustainment/{portfolio_id}/{schedule_id}/incident-response.json
      - sustainment/{portfolio_id}/{schedule_id}/sla-monitoring.json
      - sustainment/{portfolio_id}/{schedule_id}/change-conflict.json
      - sustainment/{portfolio_id}/{schedule_id}/cost-anomaly.json
    context: [portfolio_id, schedule_id, triggered_at, override_decisions]
  outputs:
    artifacts:
      - sustainment/{portfolio_id}/{schedule_id}/sweep-summary.json
    side_effects: []
  agent_contract:
    mcp_servers: []
    repos:
      artifact: rw
      source: none
      target: none
  parallel_with: []
  gate: null
  retry_policy:
    category: transient
```

Field-by-field:
- **id**: `commit-sweep-summary` (`:354`)
- **label**: `Commit Sweep Summary` (`:355`)
- **kind**: `code` (`:356`)
- **scope**: `portfolio` (`:357`)
- **sequence**: `8` (`:358`)
- **progress_pct**: `95` (`:359`)
- **summary**: `true` (`:360`) ⚠️ **GOTCHA**: This is the ONLY step in the entire line that carries the `summary` key, and it is set to `true`. It marks this as the line's terminal summary/synthesis step. No other step has a `summary` key at all (absent ≠ `false` in some consumers — preserve its presence here and absence elsewhere).
- **purpose** (`:361-366`, folded): Workflow code. Synthesises per-activity findings + **override decisions consumed via signal** into the portfolio-wide sweep summary artifact. This artifact is what **Governance reads on its next scheduled sweep** and what the **dashboard surfaces on the Sustainment portfolio view**.
- **skills**: `[]` (`:367`)
- **agent_role**: `null` (`:368`)
- **inputs.artifacts** (`:370-375`): FIVE artifacts — the same five sweep-activity outputs as step 7:
  - `sustainment/{portfolio_id}/{schedule_id}/cve-triage.json`
  - `sustainment/{portfolio_id}/{schedule_id}/incident-response.json`
  - `sustainment/{portfolio_id}/{schedule_id}/sla-monitoring.json`
  - `sustainment/{portfolio_id}/{schedule_id}/change-conflict.json`
  - `sustainment/{portfolio_id}/{schedule_id}/cost-anomaly.json`
- **inputs.context** (`:376`): `[portfolio_id, schedule_id, triggered_at, override_decisions]` ⚠️ **GOTCHA**: This step's context includes `override_decisions` — a 4th key absent from step 7. The purpose says these override decisions are "consumed via signal," i.e. delivered to the running Temporal workflow via a **Temporal signal** (the critical-patch override protocol decisions from human reviewers). The workflow must block/await or merge a signal payload before committing the summary. This is the only place `override_decisions` appears.
- **outputs.artifacts** (`:378-379`): ONE artifact — `sustainment/{portfolio_id}/{schedule_id}/sweep-summary.json` (the line's headline output; matches line-level output `sweep-summary`).
- **outputs.side_effects**: `[]` (`:380`) — no DB side-effects (DB projection already done in step 7).
- **agent_contract.mcp_servers**: `[]` (`:382`)
- **agent_contract.repos** (`:383-386`): `artifact: rw`, `source: none`, `target: none`. ⚠️ **GOTCHA**: artifact repo returns to **`rw`** here (it writes the sweep-summary artifact), unlike step 7's `none`.
- **parallel_with**: `[]` (`:387`)
- **gate**: `null` (`:388`)
- **retry_policy.category**: `transient` (`:390`)

---

## 11. Cross-Step Invariants & Reproduction Checklist

These hold across the whole line and must be preserved for parity:

1. **8 steps, fixed order, fixed `sequence`**: `sequence` = 1..8 maps exactly to file order. `progress_pct` ascends: 10, 25, 35, 45, 55, 65, 80, 95 (never reaches 100 — there is no 100% step; the line is continuous).
2. **kind partition**: steps 1, 7, 8 are `kind: code` (workflow code); steps 2–6 are `kind: agent`. Code steps have `skills: []`, `agent_role: null`, `mcp_servers: []`, `retry_policy.category: transient`. Agent steps have exactly one skill, a non-null `agent_role`, `mcp_servers: [olympus]`, `retry_policy.category: agent_failure`.
3. **scope** is `portfolio` on ALL 8 steps. No per-app scope anywhere.
4. **gate** is `null` on ALL 8 steps; line-level `gates: []`. Sustainment has zero gates.
5. **`parallel_with` fan-out group** = {cve-triage, incident-response, sla-monitoring, change-conflict-detection, cost-anomaly-detection}; each lists the other four. Book-end steps (intake, persist, commit) have empty `parallel_with`.
6. **artifact-repo access ladder**: intake `ro`; agents 2–6 `rw`; persist `none`; commit `rw`. `source` and `target` repos are `none` for ALL 8 steps (Sustainment never touches source/target code repos — it operates on artifacts + DB only).
7. **side-effect tables introduced by this contract (migration 037)**: `patching_compliance`, `incident_log`, `sla_compliance_record`, `do_not_modify_flag`, `cost_anomaly_record`. Plus marker columns on existing `application` table: `sustainment_current_status`, `sustainment_last_sweep_at`. All five new tables are *declared* on the producing agent step and *written* by step 7 (`persist-sustainment-sweep-side-effects`).
8. **Field-count quirks**: four sweep tables have 8 fields (patching_compliance, incident_log, sla_compliance_record, cost_anomaly_record); `do_not_modify_flag` has only **7** (no `sweep_id`, no timestamp-of-record — it is upserted/mutated, not appended).
9. **`fields: [...]` literal placeholder** appears 5× on step 7 only — preserve verbatim; do not expand.
10. **Signal dependency**: only step 8 consumes `override_decisions` via Temporal signal; the workflow must await/merge that signal before writing `sweep-summary.json`.
11. **Non-ASCII**: the line `description` contains `↔` (U+2194). The `cve-triage`/`incident-response`/`change-conflict` purposes contain literal double-quotes around `"do not modify"`.

---

STEP INVENTORY: intake, cve-triage, incident-response, sla-monitoring, change-conflict-detection, cost-anomaly-detection, persist-sustainment-sweep-side-effects, commit-sweep-summary

STEPS REPRODUCED: 8
