# Phase 1 — Schema Inventory (Atomic Regeneration Spec)

**Scope:** Every JSON Schema file in this repository. Two roots:
- `schemas/` — 84 `*.schema.json` + 24 `*.sample.json` = **108 files**
- `olympus-contracts/schemas/` — **2 `*.schema.json`**

**Grand total: 110 JSON files (86 schemas + 24 samples).**

This document is sufficient to recreate every schema's identity (`$id`), metaschema dialect (`$schema`), `title`, `required` set, and top-level property shape, plus the exact CI/local validation behavior and the `$id`-host inconsistencies that are load-bearing for `$ref` resolution.

---

## 0. TL;DR — the load-bearing facts

1. **FOUR distinct `$id` hosts coexist** (and one group with NO host). They are NOT interchangeable; `$ref` resolution and the CI sample-validation store key off the literal `$id` string. See §3.
   - `https://olympus.framework` — 68 schemas (the dominant convention)
   - `https://olympus.faa.gov` — 3 schemas (1 in `schemas/`, 2 in `olympus-contracts/`)
   - `https://olympus.dev` — 2 schemas (both in `schemas/modernization/`)
   - **relative path strings with no host** — 14 schemas (all `draft-07`; see §3.4)
   - **(no `$id` at all)** — all 24 samples + nothing else.
2. **TWO metaschema dialects coexist**: JSON Schema **2020-12** (69 schemas) and **draft-07** (17 schemas). The local validator's banner says "2020-12" but it does NOT enforce any dialect (§2.1). The CI validator (`check-jsonschema --check-metaschema`) DOES enforce per-file dialect (§2.2).
3. **`make validate-schemas` (local) ≠ CI validation.** They are two different code paths with materially different behavior. The local `schemas/validate.sh`:
   - Only checks **presence** of `$schema`/`$id`/`title`/`description` keys — never validates structure against a metaschema, despite the banner text.
   - **Iterates a hard-coded list of 10 directories that OMITS `design/`** (6 schemas) — so the 6 `schemas/design/*.schema.json` are never touched by `make validate-schemas`. (§2.1, §4)
   - Validates samples are valid JSON **with a `$schema` key present** — it does NOT validate samples against their target schema.
4. **CI (`ci.yml`)** uses `check-jsonschema --check-metaschema` over `schemas/**/*.schema.json` (covers all 84 because every schema lives exactly one level deep) AND separately validates the 24 samples against their referenced schema using `jsonschema.Draft202012Validator` + `RefResolver` with a store keyed by `$id`. (§2.2)
5. **One sample has NO `$schema` and is therefore silently skipped** by CI sample-validation: `schemas/samples/disposition-recommendation.sample.json`. (§5)
6. There is **no allowlist/skiplist file**. Exclusions are implicit in the glob/loop construction. (§4)

---

## 1. Directory inventory & counts

### 1.1 `schemas/` (84 schema files + 24 samples)

| Directory | `*.schema.json` | Notes |
|---|---:|---|
| `schemas/architecture/` | 12 | all 2020-12, host `olympus.framework` |
| `schemas/common/` | 4 | all 2020-12, host `olympus.framework` |
| `schemas/cross-cutting/` | 10 | **mixed**: 4 are 2020-12 (`olympus.framework`); 6 are draft-07 with **relative/no-host `$id`** |
| `schemas/data/` | 6 | all 2020-12, host `olympus.framework` |
| `schemas/design/` | 6 | **all draft-07, all relative/no-host `$id`** — **EXCLUDED from `validate.sh`** |
| `schemas/discovery/` | 12 | 11 are 2020-12 (`olympus.framework`); 1 (`eligibility-rule-engine`) is draft-07 + relative `$id` |
| `schemas/dispositions/` | 8 | all 2020-12, host `olympus.framework` |
| `schemas/gates/` | 3 | all 2020-12, host `olympus.framework` |
| `schemas/modernization/` | 5 | 3 are 2020-12 (`olympus.framework`); 2 (`modern-requirements`, `rule-reconciliation-matrix`) are draft-07 + host `olympus.dev` |
| `schemas/profiles/` | 1 | 2020-12, host `olympus.framework` |
| `schemas/rationalization/` | 17 | 16 are 2020-12 (`olympus.framework`); 1 (`rationalization-clustering-plan`) is 2020-12 but host `olympus.faa.gov` AND filename ends `.json` not `.schema.json`?? — NO: it is `.schema.json`; the `$id` ends `.json` (see ⚠️ §3.3) |
| `schemas/samples/` | 0 schemas / 24 samples | samples are `*.sample.json`; **none has `$id`** |

Per-directory schema count sum: 12+4+10+6+6+12+8+3+5+1+17 = **84**. ✓

### 1.2 `olympus-contracts/schemas/` (2 files)

| Directory | File | Dialect | `$id` host |
|---|---|---|---|
| `discovery/` | `business-logic.schema.json` | draft-07 | `olympus.faa.gov` |
| `pipeline-execution/` | `step-execution-record.schema.json` | draft-07 | `olympus.faa.gov` |

⚠️ **GOTCHA — name collision:** `olympus-contracts/schemas/discovery/business-logic.schema.json` (title **"Business Logic Catalog"**, host `olympus.faa.gov`, draft-07) and `schemas/discovery/business-logic.schema.json` (title **"Business Logic Inventory"**, host `olympus.framework`, 2020-12) are **two different schemas with the same relative path** under two different roots. They have different `$id`, different `required`, different shape. Do not conflate. (See §6.18 vs §App-B.1.)

---

## 2. Validation: the two code paths

### 2.1 Local: `make validate-schemas` → `schemas/validate.sh`

Cited: `Makefile:120-121`, `schemas/validate.sh:1-71`.

```
Makefile:120  validate-schemas: ## Validate all JSON Schemas (metaschema + shape).
Makefile:121      @bash schemas/validate.sh
```

`schemas/validate.sh` behavior, line by line:

- `:5` `set -e` — abort on first error of a non-`if`-guarded command.
- `:7` `SCHEMA_DIR="$(cd "$(dirname "$0")" && pwd)"` → resolves to `schemas/` absolute.
- `:8` `ERRORS=0`.
- `:10` Banner: `"=== Validating schemas against JSON Schema 2020-12 metaschema ==="` — ⚠️ **MISLEADING**: no 2020-12 metaschema is ever loaded or applied.
- `:11` **The loop glob (hard-coded directory list):**
  ```
  "$SCHEMA_DIR"/common/*.schema.json
  "$SCHEMA_DIR"/discovery/*.schema.json
  "$SCHEMA_DIR"/rationalization/*.schema.json
  "$SCHEMA_DIR"/architecture/*.schema.json
  "$SCHEMA_DIR"/data/*.schema.json
  "$SCHEMA_DIR"/modernization/*.schema.json
  "$SCHEMA_DIR"/gates/*.schema.json
  "$SCHEMA_DIR"/cross-cutting/*.schema.json
  "$SCHEMA_DIR"/profiles/*.schema.json
  "$SCHEMA_DIR"/dispositions/*.schema.json
  ```
  ⚠️ **GOTCHA — `schemas/design/` is NOT in this list.** The 6 `design/*.schema.json` files are silently skipped by `make validate-schemas`. Order is also non-alphabetical (common, discovery, rationalization, architecture, data, modernization, gates, cross-cutting, profiles, dispositions). The `if [ -f "$schema" ]` guard at `:12` means a directory with zero matches (glob stays literal) is harmlessly skipped.
- `:14-27` For each file: a Python one-liner that:
  - loads JSON (parse failure → exception → `2>/dev/null` swallows stderr → non-zero exit → `FAIL`).
  - `:18` if `$schema` not in doc → print `MISSING $schema`; exit 1.
  - `:20` if `$id` not in doc → exit 1.
  - `:22` if `title` not in doc → exit 1.
  - `:24` if `description` not in doc → exit 1.
  - `:26` else print OK.
  ⚠️ It **never** checks the *value* of `$schema`, never validates the document against any metaschema, never checks property types. It is a 4-key presence check.
- `:29-32` On failure: echo `FAIL`, `ERRORS++`. (Note `set -e` does not trip here because the failing command is the condition of an `if`.)
- `:38-55` Samples loop over `samples/*.sample.json`: Python one-liner that loads JSON and checks **only** that `$schema` key is present (`:45-46`). It does NOT resolve or validate against the referenced schema.
- `:59` `SCHEMA_COUNT=$(find "$SCHEMA_DIR" -name "*.schema.json" ! -path "*/samples/*" | wc -l ...)` → counts **all 84** (find is recursive; it includes `design/`). ⚠️ So the printed "Schemas: N" (84) does NOT equal the number actually checked by the loop (78 = 84 − 6 design).
- `:60` `SAMPLE_COUNT` → 24.
- `:65-70` exit 1 if `ERRORS>0`, else "ALL VALIDATIONS PASSED".

### 2.2 CI: `.github/workflows/ci.yml` (contracts job)

Cited: `.github/workflows/ci.yml:160` (path trigger), `:266-321` (validation steps).

- `:160` `CONTRACTS_CHANGED=$(match '^schemas/|^specifications/api/|^olympus-contracts/')` — the contracts job runs when any of those paths change.
- `:266-268` **Install:** `pip install check-jsonschema jsonschema` (guarded by `hashFiles('schemas/**/*.schema.json') != ''`).
- `:270-277` **Metaschema check** (guarded the same way):
  ```bash
  export PATH="$HOME/.local/bin:$PATH"
  for schema in schemas/**/*.schema.json; do
    echo "Validating $schema..."
    check-jsonschema --check-metaschema "$schema"
  done
  ```
  - `check-jsonschema --check-metaschema` reads each file's own `$schema` and validates the file against **that** dialect's metaschema (so draft-07 files are checked against draft-07, 2020-12 against 2020-12). This is real structural validation, unlike `validate.sh`.
  - ⚠️ **GOTCHA — glob reach:** GitHub Actions `run:` blocks execute under `bash -e` **without `globstar`** enabled by default. With `globstar` OFF, `schemas/**/*.schema.json` expands `**` as a single `*` → it matches files **exactly one directory deep** under `schemas/`. Empirically this matches **84 files** because *every* `.schema.json` in this repo lives exactly one level below `schemas/` (no deeper nesting exists). So today CI covers all 84 including `design/`. **If anyone ever adds a schema two levels deep (e.g. `schemas/foo/bar/x.schema.json`), it would be silently skipped** by both the `for` loop here and the `hashFiles` guard's intent. The `Path('schemas').rglob(...)` in the sample step (below) WOULD see it, creating an asymmetry.
- `:279-321` **Sample validation** (guarded by `hashFiles('schemas/samples/*.json') != ''`), inline Python:
  - `:289-294` Build `store = {}` mapping `s['$id'] -> s` for every `Path('schemas').rglob('*.schema.json')` that has an `$id`. ⚠️ This is **recursive** (`rglob`), unlike the metaschema `for` loop. The store key is the literal `$id` string.
  - `:297-320` For each `sorted(Path('schemas/samples').glob('*.json'))`:
    - `:300` `schema_ref = data.pop('$schema', None)` — pops the sample's `$schema` (a **relative path**, e.g. `../dispositions/retire-output.schema.json`).
    - `:301-302` `if not schema_ref: continue` — ⚠️ **samples with no `$schema` are silently skipped** (this is why `disposition-recommendation.sample.json` is never validated; see §5).
    - `:303` `schema_file = (sample_path.parent / schema_ref).resolve()` — resolves the relative path from `schemas/samples/`.
    - `:306-310` `RefResolver(base_uri=schema.get('$id', schema_file.as_uri()), referrer=schema, store=store)`.
      ⚠️ **GOTCHA — `$ref` resolution depends on `$id`-host consistency.** A `$ref` inside a schema is resolved relative to `base_uri` (= the schema's `$id`). If a schema `$ref`s another schema by an `$id`-style URI, that target must be present in `store` under the **identical `$id` string**. Cross-host `$ref`s (e.g. an `olympus.framework` schema referencing an `olympus.faa.gov` `$id`) only work if BOTH `$id`s are in the store AND the `$ref` text matches the target's `$id` byte-for-byte. Trailing-slash / http-vs-https / hostname mismatches break this. (See §3 for the full host map.)
    - `:311-312` `Draft202012Validator(schema, resolver=resolver)` then `iter_errors`. ⚠️ **Every sample is validated with the 2020-12 validator regardless of the target schema's actual dialect.** For the draft-07 targets that have samples (`business-rules`? no — `business-rules` is 2020-12; the draft-07-targeted samples are `modern-requirements.sample.json` → `modern-requirements.schema.json` (draft-07) and `rule-reconciliation-matrix.sample.json` → draft-07), the validator applies 2020-12 semantics to a draft-07 schema. Most keywords overlap; differences (e.g. `$recursiveRef`, `dependentRequired`) could diverge silently.
    - `:313-317` collect errors, print `FAIL ...` with `e.json_path` + `e.message`, `errors+=1`.
    - `:320` `sys.exit(1 if errors else 0)`.

### 2.3 Other validators (NOT general schema validation, listed for completeness)

- `make validate-objectives` → `scripts/validate_objectives.py` (`Makefile:123-124`) — validates `profiles/*/objectives.yaml` against `schemas/profiles/objectives.schema.json` + registries. Separate from `validate-schemas`.
- `scripts/validate_consolidation_examples.py` — validates consolidation example artifacts (used by `tests/`).
- `scripts/validate_skill_registry.py` — skill registry, not JSON Schemas.
- `tests/test_schema_contracts.py` and sibling per-schema tests under `tests/` and per-service `tests/` exercise individual schemas in pytest; they are not part of `make validate-schemas`.

---

## 3. `$id` HOST INVENTORY (⚠️ load-bearing for `$ref` resolution)

### 3.1 Distinct hosts and counts (across all 86 schemas)

| `$id` host prefix | # schemas | Dialect(s) | Where |
|---|---:|---|---|
| `https://olympus.framework` | 68 | 2020-12 | the bulk of `schemas/` |
| `https://olympus.faa.gov` | 3 | 1×2020-12, 2×draft-07 | `schemas/rationalization/rationalization-clustering-plan` (2020-12) + both `olympus-contracts/` schemas (draft-07) |
| `https://olympus.dev` | 2 | draft-07 | `schemas/modernization/modern-requirements`, `schemas/modernization/rule-reconciliation-matrix` |
| **(none — relative path string)** | 14 | draft-07 | see §3.4 |

⚠️ **There is no single canonical host.** An engineer rebuilding this MUST preserve each schema's exact `$id` string verbatim, because (a) the CI sample-validation store is keyed by `$id`, and (b) any intra-repo `$ref` that uses an absolute `$id` URI must match.

### 3.2 The `olympus.framework` convention (the "correct" pattern)
`$id` = `https://olympus.framework/schemas/<dir>/<file>.schema.json` and **matches** the repo path (`schemas/<dir>/<file>.schema.json`). `https` scheme, no trailing slash, host = `olympus.framework`. 68 schemas follow this.

### 3.3 The `olympus.faa.gov` outlier in `schemas/rationalization/`
⚠️ **GOTCHA:** `schemas/rationalization/rationalization-clustering-plan.schema.json` has
`$id = https://olympus.faa.gov/schemas/rationalization/rationalization-clustering-plan.json`.
Two anomalies vs the dominant convention: (1) host is `olympus.faa.gov` not `olympus.framework`; (2) the `$id` path ends `...clustering-plan.json` (NO `.schema` segment) while the actual file is `...clustering-plan.schema.json`. So `$id` does **not** match the file path. Any `$ref` to this schema must use the `.json`-suffixed, faa.gov-hosted URI exactly.

### 3.4 The relative / no-host group (14 draft-07 schemas)
These set `$id` to a bare repo-relative path string (no scheme, no host):

| File | `$id` |
|---|---|
| `schemas/cross-cutting/attestation-chain.schema.json` | `schemas/cross-cutting/attestation-chain.schema.json` |
| `schemas/cross-cutting/audit-event.schema.json` | `schemas/cross-cutting/audit-event.schema.json` |
| `schemas/cross-cutting/event-envelope.schema.json` | `schemas/cross-cutting/event-envelope.schema.json` |
| `schemas/cross-cutting/journey-fsm.schema.json` | `schemas/cross-cutting/journey-fsm.schema.json` |
| `schemas/cross-cutting/oidc-server-config.schema.json` | `schemas/cross-cutting/oidc-server-config.schema.json` |
| `schemas/cross-cutting/temporal-workflow-contract.schema.json` | `schemas/cross-cutting/temporal-workflow-contract.schema.json` |
| `schemas/design/8710-field-dependency-graph.schema.json` | `schemas/design/8710-field-dependency-graph.schema.json` |
| `schemas/design/application-state-machine.schema.json` | `schemas/design/application-state-machine.schema.json` |
| `schemas/design/faa-pilot-cert-domain.schema.json` | `schemas/design/faa-pilot-cert-domain.schema.json` |
| `schemas/design/form-8710-rules.schema.json` | `schemas/design/form-8710-rules.schema.json` |
| `schemas/design/medical-cert-class.schema.json` | `schemas/design/medical-cert-class.schema.json` |
| `schemas/design/principal-mapping.schema.json` | `schemas/design/principal-mapping.schema.json` |
| `schemas/discovery/eligibility-rule-engine.schema.json` | `schemas/discovery/eligibility-rule-engine.schema.json` |

⚠️ **GOTCHA:** For these, in CI sample-validation the `RefResolver` `base_uri` becomes the literal relative string (e.g. `schemas/design/medical-cert-class.schema.json`), which is not a resolvable URI. None of these are referenced by any sample, so it does not currently break — but it would break any future `$ref` against them and breaks the `$id`↔path identity model.

### 3.5 Summary of distinct `$id` HOSTS to report
`https://olympus.framework`, `https://olympus.faa.gov`, `https://olympus.dev`, and **(relative, no host)**. → **4 distinct host situations** (3 real hosts + 1 hostless group).

---

## 4. Schemas EXCLUDED from CI / local validation

| Exclusion | Mechanism | Files affected |
|---|---|---|
| **`schemas/design/*` (6 files) excluded from `make validate-schemas`** | `schemas/validate.sh:11` directory list omits `design/` | `8710-field-dependency-graph`, `application-state-machine`, `faa-pilot-cert-domain`, `form-8710-rules`, `medical-cert-class`, `principal-mapping` |
| **`olympus-contracts/schemas/*` (2 files) excluded from BOTH `validate.sh` and the CI metaschema loop** | `validate.sh` only walks `schemas/`; CI loop is `schemas/**/*.schema.json` (does not include `olympus-contracts/`) | `discovery/business-logic`, `pipeline-execution/step-execution-record` |
| **`disposition-recommendation.sample.json` skipped by CI sample-validation** | no `$schema` key → `ci.yml:301-302 if not schema_ref: continue` | that one sample |
| **All `schemas/design/*` ARE covered by CI metaschema** (one level deep) | `ci.yml:274` glob matches them | (covered, not excluded, in CI) |

**There is NO explicit allowlist/skiplist file.** Searched `Makefile`, `schemas/validate.sh`, and `scripts/`; exclusions are purely implicit in the hard-coded directory list (`validate.sh:11`) and the glob shape (`ci.yml:274`).

⚠️ **Net coverage matrix:**
- `make validate-schemas` (local) checks **78** of 84 `schemas/` schemas (presence-only), skips 6 `design/`, skips 2 `olympus-contracts/`.
- CI metaschema-check covers all **84** `schemas/` schemas (real check), skips 2 `olympus-contracts/`.
- Neither path validates the 2 `olympus-contracts/schemas/` files via `make`/CI-contracts. (They are exercised by pytest in `olympus-api`/`temporal` tests instead.)

---

## 5. Samples (`schemas/samples/`, 24 files)

All samples are instance documents (NOT schemas): no `$id`, and a `$schema` that is a **relative path** to the target schema (consumed by CI sample-validation §2.2). Mapping (sample → target `$schema`):

| Sample | `$schema` (relative target) |
|---|---|
| `business-rule-inventory.sample.json` | `../discovery/business-rule-inventory.schema.json` |
| `business-rules.sample.json` | `../modernization/business-rules.schema.json` |
| `consolidate-output.sample.json` | `../dispositions/consolidate-output.schema.json` |
| `disposition-output.sample.json` | `../dispositions/disposition-output.schema.json` |
| `disposition-recommendation.sample.json` | **(NONE — no `$schema`; skipped by CI)** ⚠️ |
| `escalation-record.sample.json` | `../gates/escalation-record.schema.json` |
| `gate-evidence-package.sample.json` | `../gates/gate-evidence-package.schema.json` |
| `modern-requirements.sample.json` | `../modernization/modern-requirements.schema.json` (draft-07 target) |
| `module-map.sample.json` | `../modernization/module-map.schema.json` |
| `portfolio-target-state-rollup.sample.json` | `../rationalization/portfolio-target-state-rollup.schema.json` |
| `rearchitect-output.sample.json` | `../dispositions/rearchitect-output.schema.json` |
| `redundancy-matrix.sample.json` | `../rationalization/redundancy-matrix.schema.json` |
| `refactor-output.sample.json` | `../dispositions/refactor-output.schema.json` |
| `rendition-manifest.sample.json` | `../cross-cutting/rendition-manifest.schema.json` |
| `replace-output.sample.json` | `../dispositions/replace-output.schema.json` |
| `replatform-output.sample.json` | `../dispositions/replatform-output.schema.json` |
| `retain-output.sample.json` | `../dispositions/retain-output.schema.json` |
| `retire-output.sample.json` | `../dispositions/retire-output.schema.json` |
| `rule-reconciliation-matrix.sample.json` | `../modernization/rule-reconciliation-matrix.schema.json` (draft-07 target) |
| `score-snapshot.sample.json` | `../cross-cutting/score-snapshot.schema.json` |
| `tech-fingerprint.sample.json` | `../discovery/tech-fingerprint.schema.json` |
| `test-scenarios.sample.json` | `../modernization/test-scenarios.schema.json` |
| `traceability-report.sample.json` | `../cross-cutting/traceability-report.schema.json` |
| `wave-outcome-synthesis.sample.json` | `../rationalization/wave-outcome-synthesis.schema.json` |

⚠️ Sample-validation runs `data.pop('$schema')` so the `$schema` is removed before validation; the remaining instance is validated against the resolved target. The resolved schema is loaded directly from disk (`ci.yml:303-305`), not from `store`; `store` is only used to satisfy the resolver's cross-`$ref` lookups.

---

## 6. Per-schema detail — `schemas/`

> Format per schema: **path** · `$id` · `$schema` (dialect) · `title` · `additionalProperties` · `required` · `$defs` · top-level properties (name: type; nested-object child keys noted as `{...}`; `$ref` and `enum` noted inline). "object(free)" = `type: object` with no declared `properties` (free-form). "array<X>" = `type: array` with `items` of type/`$ref` X.

### 6.1 `schemas/architecture/` (12 — all 2020-12, host `olympus.framework`)

**accessibility-review.schema.json** — `$id: https://olympus.framework/schemas/architecture/accessibility-review.schema.json` · 2020-12 · title "Accessibility Review" · addlProps **true** · required `[schema_version, target_app_id, wave_id]` · no $defs
Props: `schema_version:string`, `artifact_type:string`, `target_app_id:string`, `target_name:string`, `wave_id:string`, `disposition:string`, `assessment_date:string`, `reviewer_skill:string`, `conformance_target:string`, `conformance_rationale:string`, `design_system_baseline:object(free)`, `source_findings_disposition:array<object>`, `risks:array<object>`, `remediation_commitments:array<object>`, `open_questions:array<object>`, `handoff_to_validation:object(free)`, `provenance:object(free)`.

**ai-ml-integration.schema.json** — `$id: .../architecture/ai-ml-integration.schema.json` · 2020-12 · title "AI/ML Integration Architecture" · addlProps **true** · required `[application_id, skill_id, step, target_app_id, wave_id]`
Props: `step:string`, `skill_id:string`, `application_id:string`, `application_name:string`, `target_app_id:string`, `disposition:string`, `wave_id:string`, `timestamp:string`, `profile:string`, `outcome:string`, `outcome_rationale:object(free)`, `roadmap_opportunities:array<object>`, `governance_placeholder_if_adopted:object(free)`, `data_ecosystem_alignment:object(free)`, `architecture_sections_omitted:object(free)`, `open_questions:array<object>`, `side_effects:object(free)`, `provenance:object(free)`.

**architecture-blueprint.schema.json** — `$id: .../architecture/architecture-blueprint.schema.json` · 2020-12 · title "Architecture Blueprint" · addlProps **true** · required `[application_id, skill_id, step, wave_id]`
Props: `skill_id:string`, `step:string`, `application_id:string`, `application_name:string`, `wave_id:string`, `generated:string`, `model_notes:string`, `disposition:object(free)`, `classification:object(free)`, `archetypes:object(free)`, `cloud_pattern:object(free)`, `cloud_profile:object(free)`, `target_stack:object(free)`, `services:array<object>`, `lambda_workers_count:integer|number`, `service_catalog_approval_status:string`, `approved_services:array<string>`, `services_rejected:array<object>`, `region_verification_open_items:array<string>`, `mandatory_integrations_status:object(free)`, `tier_t1_augmentations:array<string>`, `rto_preliminary_hours:integer|number`, `rpo_preliminary_minutes:integer|number`, `rto_rpo_pending_safety_tier:boolean`, `cost_estimate_monthly_usd:object(free)`, `cost_estimate_annual_usd_expected:integer|number`, `savings_vs_baseline_5yr_usd:integer|number`, `savings_confidence:string`, `adrs:array<string>`, `c4_diagrams:array<string>`, `handoff_next:array<string>`, `open_items_blocking_g04b:array<string>`, `side_effects_performed:string`.

**architecture-target-plan.schema.json** — `$id: .../architecture/architecture-target-plan.schema.json` · 2020-12 · title "Architecture Target Plan" · addlProps **true** · required `[wave_id, generated_at, targets, target_app_count, summary]`
Props: `$schema:string`, `portfolio_id:string`, `wave_id:string`, `generated_at:string`, `targets:array<object>`, `system_repo_target_id:string`, `target_app_count:integer`, `summary:string`.

**cloud-pattern.schema.json** — `$id: .../architecture/cloud-pattern.schema.json` · 2020-12 · title "Cloud Pattern Selection" · addlProps **true** · required `[skill, target_app_id, wave_id]`
Props: `skill:string`, `task_type:string`, `target_app_id:string`, `target_name:string`, `wave_id:string`, `disposition_consumed:object(free)`, `complexity_profile:object(free)`, `pattern_recommendation:object(free)`, `cutover_shape:object(free)`, `cloud_stack_selection:object(free)`, `resilience_design:object(free)`, `govcloud_compatibility_checklist:array<object>`, `cost_projection:object(free)`, `migration_timeline:object(free)`, `traceability:object(free)`, `side_effects:object(free)`, `provenance:object(free)`.

**cost-estimate.schema.json** — `$id: .../architecture/cost-estimate.schema.json` · 2020-12 · title "Cloud Cost Estimate" · addlProps **true** · required `[application_id, skill_id, step, wave_id]`
Props: `skill_id:string`, `step:string`, `application_id:string`, `application_name:string`, `wave_id:string`, `generated:string`, `cloud_provider:string`, `cloud_flavor:string`, `primary_region:string`, `dr_region:string`, `govcloud_premium_pct:integer|number`, `risk_tier:integer|number`, `confidence:string`, `confidence_variance_pct:integer|number`, `tco_baseline:object(free)`, `production_monthly:object(free)`, `staging_monthly:object(free)`, `dev_monthly:object(free)`, `all_environments:object(free)`, `full_program_tco:object(free)`, `savings_plans:array<object>`, `total_savings_plan_savings_monthly_usd:number`, `total_savings_plan_savings_annual_usd:number`, `tco_comparison:object(free)`, `govcloud_premium_impact:object(free)`, `conditional_costs:object(free)`, `cost_risks:array<object>`, `risk_adjusted_high_production_monthly_usd:integer|number`, `blueprint_cost_estimate_reconciliation:object(free)`, `file_artifacts:array<string>`, `quality_checklist:object(free)`, `handoff_next:array<string>`.

**design-system.schema.json** — `$id: .../architecture/design-system.schema.json` · 2020-12 · title "Design System Selection" · addlProps **true** · required `[application_id, schema_version, wave_id]`
Props: `schema_version:string`, `artifact_type:string`, `application_id:string`, `application_name:string`, `wave_id:string`, `generated_at:string`, `disposition:string`, `ui_framework:object(free)`, `design_tokens:object(free)`, `portal_consolidation:object(free)`, `component_library:object(free)`, `legacy_component_migration_map:array<object>`, `accessibility:object(free)`, `wcag_compliance_status:object(free)`, `rich_text_replacement:object(free)`, `telemetry_instrumentation:object(free)`, `multi_app_consistency:object(free)`, `domain_specific_patterns:object(free)`, `provenance:object(free)`.

**ea-compliance.schema.json** — `$id: .../architecture/ea-compliance.schema.json` · 2020-12 · title "EA Compliance Report" · addlProps **true** · required `[application_id, schema_version, wave_id]`
Props: `schema_version:string`, `report_type:string`, `application_id:string`, `application_name:string`, `wave_id:string`, `disposition:string`, `disposition_confidence:number`, `risk_tier:integer|number`, `risk_tier_confidence:number`, `safety_tier:null|string|number|boolean|object|array` (⚠️ permissive 6-way union), `assessment_date:string`, `gate:string`, `gate_result:string`, `gate_result_rationale:string`, `summary:object(free)`, `dimension_results:array<object>`, `prewave_actions:array<object>`, `faa_ea_findings:array<object>`, `ams_findings:array<object>`, `nist_800_53_rev5_findings:array<object>`, `inherited_control_map:array<object>`, `zero_trust_findings:array<object>`, `approved_services_confirmed:array<string>`, `approved_services_unverified:array<string>`, `provenance:object(free)`.

**integration-arch.schema.json** — `$id: .../architecture/integration-arch.schema.json` · 2020-12 · title "Integration Architecture / API Contract Compliance" · addlProps **true** · required `[application_id, schema_version, wave_id]`
Props: `schema_version:string`, `report_type:string`, `application_id:string`, `application_name:string`, `wave_id:string`, `assessment_date:string`, `api_gateway:string`, `disposition:string`, `phase:string`, `executive_summary:object(free)`, `openapi_spec_validation:object(free)`, `contract_test_execution:object(free)`, `external_consumer_compatibility:object(free)`, `gateway_route_validation:object(free)`, `async_interface_assessment:object(free)`, `versioning_strategy:object(free)`, `target_api_contracts_required:array<object>`, `compliance_summary:object(free)`, `findings:array<object>`, `provenance:object(free)`.

**security-arch.schema.json** — `$id: .../architecture/security-arch.schema.json` · 2020-12 · title "Security Architecture" · addlProps **true** · required `[application_id, schema_version, wave_id]`
Props: `schema_version:string`, `report_type:string`, `application_id:string`, `application_name:string`, `wave_id:string`, `assessment_date:string`, `risk_tier:integer|number`, `risk_tier_confidence:number`, `safety_tier:null|string|number|boolean|object|array`, `safety_tier_status:string`, `safety_tier_pending_stakeholders:array<string>`, `disposition:string`, `disposition_confidence:number`, `phase:string`, `overall_security_posture:object(free)`, `current_state_findings:object(free)`, `prewave_remediation_actions:array<object>`, `target_state_security_architecture:object(free)`, `zero_trust_architecture:object(free)`, `nist_800_53_control_implementations:array<object>`, `inherited_control_map:object(free)`, `threat_model:object(free)`, `security_gates:object(free)`, `open_items:array<object>`, `target_microservices:array<object>`, `provenance:object(free)`.

**target-application-map.schema.json** — `$id: .../architecture/target-application-map.schema.json` · 2020-12 · title "Target Application Map" · addlProps **true** · required `[target_app_id, wave_id]`
Props: `target_app_id:string`, `target_name:string`, `target_portfolio_id:null|string|number|boolean|object|array`, `disposition:string`, `disposition_confidence:number`, `relationship:string`, `wave_id:string`, `sources:array<object>`, `provisioned_new_row:boolean`, `requires_manual_target_definition:boolean`, `rationale:string`, `target_hint_consumed:object(free)`, `governance_context:object(free)`, `redundancy_matrix_cross_check:object(free)`, `context_priors_alignment:object(free)`, `downstream_guidance:object(free)`, `provenance:object(free)`.

**well-architected-review.schema.json** — `$id: .../architecture/well-architected-review.schema.json` · 2020-12 · title "Well-Architected Review" · addlProps **true** · required `[application_id, skill, wave_id]`
Props: `skill:string`, `application_id:string`, `wave_id:string`, `review_date:string`, `framework:string`, `lens:string`, `cloud_provider:string`, `cloud_region_primary:string`, `cloud_region_dr:string`, `risk_tier:string`, `risk_tier_confidence:number`, `safety_tier:null|string|number|boolean|object|array`, `safety_tier_status:string`, `rto_preliminary_hours:integer|number`, `rpo_preliminary_minutes:integer|number`, `blueprint_reference:string`, `weighting_model:object(free)`, `tier_adjusted_minimums:object(free)`, `scoring_scale:object(free)`, `pillars:array<object>`, `overall:object(free)`, `action_items:array<object>`, `next_steps:array<string>`, `provenance:object(free)`.

### 6.2 `schemas/common/` (4 — all 2020-12, host `olympus.framework`)

**confidence-level.schema.json** — `$id: .../common/confidence-level.schema.json` · 2020-12 · title "Confidence Level" · addlProps **false** · required `[level, score, rationale]`
Props: `level:string enum[high,medium,low]`, `score:number`, `rationale:string`, `factors:array<object>`.

**evidence-reference.schema.json** — `$id: .../common/evidence-reference.schema.json` · 2020-12 · title "Evidence Reference" · addlProps **false** · required `[title, artifact_path, artifact_type, finding_summary, citations]`
Props: `id:string`, `title:string`, `artifact_path:string`, `artifact_version:string`, `artifact_type:string enum[analysis-report, catalog-entry, tech-fingerprint, redundancy-matrix, disposition-entry, business-rules, module-map, test-scenarios, parity-report, security-assessment, accessibility-audit, tco-analysis, score-snapshot, traceability-report, other]`, `section:string`, `finding_summary:string`, `citations:array<$ref traceability-citation.schema.json>` (⚠️ **relative-file `$ref`** to sibling `traceability-citation.schema.json`, not an `$id` URI), `collected_at:string`, `collected_by:string`.

**risk-tier-annotation.schema.json** — `$id: .../common/risk-tier-annotation.schema.json` · 2020-12 · title "Risk Tier Annotation" · addlProps **false** · required `[tier, source]`
Props: `tier:integer enum[1,2,3]`, `source:string enum[auto,confirmed,overridden]`, `classified_at:string`, `classified_by:string`, `justification:string`, `previous_tier:integer enum[1,2,3]`, `profile_reference:string`.

**traceability-citation.schema.json** — `$id: .../common/traceability-citation.schema.json` · 2020-12 · title "Traceability Citation" · addlProps **(unset)** · required **[]** (none at top level) · ⚠️ **uses `oneOf`** (two mutually-exclusive shapes), not flat properties:
- Branch A (artifact citation): required `[type, artifact, section]`, addlProps **false**; props `type:const "artifact"`, `artifact:string(minLength 1)`, `section:string(minLength 1)`, `finding_id:string(pattern ^[A-Z]{1,5}-[0-9]+$)`.
- Branch B (source citation): required `[type, repository, file, line_start]`, addlProps **false**; props `type:const "source"`, `repository:string(minLength 1)`, `file:string(minLength 1)`, `line_start:integer(min 1)`, `line_end:integer(min 1)`, `commit_sha:string(pattern ^[0-9a-f]{7,40}$)`.
This is the canonical citation shape referenced by `evidence-reference` and embedded in `traceability-report`'s `$defs`.

### 6.3 `schemas/cross-cutting/` (10 — MIXED dialect)

**attestation-chain.schema.json** — `$id: schemas/cross-cutting/attestation-chain.schema.json` (⚠️ **relative/no-host**) · **draft-07** · title "Attestation Chain (3-link)" · addlProps **true** · required `[link_1_hash, link_2_signature, link_3_timestamp, signed_at, signer]`
Props: `link_1_hash:object{algorithm,value,subject_uri}`, `link_2_signature:object{algorithm,signature,key_id}`, `link_3_timestamp:object{tsa_url,token,tst_info_hash}`, `signed_at:string`, `signer:object{role,id,name}`.

**audit-event.schema.json** — `$id: schemas/cross-cutting/audit-event.schema.json` (relative) · **draft-07** · title "Audit Event" · addlProps **true** · required `[event_id, occurred_at, actor, verb, subject, row_hash]`
Props: `event_id:string`, `occurred_at:string`, `actor:object{kind,id,role}`, `verb:string`, `subject:object{aggregate_type,aggregate_id}`, `attributes:object(free)`, `trace_id:string`, `prev_hash:string|null`, `row_hash:string`, `retention_until:string`.

**event-envelope.schema.json** — `$id: schemas/cross-cutting/event-envelope.schema.json` (relative) · **draft-07** · title "Event Envelope" · addlProps **true** · required `[event_id, aggregate_id, aggregate_type, type, version, occurred_at, payload]`
Props: `event_id:string`, `aggregate_id:string`, `aggregate_type:string`, `type:string`, `version:integer`, `occurred_at:string`, `actor:object{kind,id}`, `payload:object(free)`, `trace_id:string`, `causation_id:string`, `correlation_id:string`.

**journey-fsm.schema.json** — `$id: schemas/cross-cutting/journey-fsm.schema.json` (relative) · **draft-07** · title "Journey FSM Definition" · addlProps **true** · required `[id, initial, context, states]`
Props: `id:string`, `initial:string`, `context:object{application_id,applicant_ftn,medical_id,stage}`, `states:object(free)`.

**metric.schema.json** — `$id: https://olympus.framework/schemas/cross-cutting/metric.schema.json` · **2020-12** · title "Metric Registry Entry" · addlProps **false** · required `[metrics]` · **$defs (7): MetricId, Unit, Aggregation, SourceKind, TrendWindow, Source, Metric**
Props: `version:string`, `metrics:array<$ref #/$defs/Metric>`.
$defs detail:
- `MetricId`: `string`, pattern `^[a-z][a-z0-9_]*(\.[a-z][a-z0-9_]*)+$`, minLength 3, maxLength 200.
- `Unit`: `string` enum `[count,pct,usd,days,weeks,months,years,ratio,bytes,ms]`.
- `Aggregation`: `string` enum `[latest,sum,avg,rate]`.
- `SourceKind`: `string` enum `[sql_view,api_endpoint,postgres_query]`.
- `TrendWindow`: `string`, pattern `^[0-9]+_(waves|days|weeks|months|years)$`.
- `Source`: required `[kind]`; props `kind,ref,query,value_column,timestamp_column`.
- `Metric`: required `[id,unit,aggregation,source]`; props `id,unit,description,source,aggregation,default_trend_window,category,owner,traces_to`.
⚠️ `metric.schema.json` is co-referenced by the objectives validator (`ci.yml:162` lists it under OBJECTIVES_CHANGED triggers).

**oidc-server-config.schema.json** — `$id: schemas/cross-cutting/oidc-server-config.schema.json` (relative) · **draft-07** · title "OIDC Server Configuration" · addlProps **true** · required `[provider, realm_id, clients, claims]`
Props: `provider:string enum[keycloak,auth0,okta,cognito,custom]`, `realm_id:string`, `clients:array<object>`, `identity_brokers:array<object>`, `claims:array<object>`, `session_policy:object{access_token_lifetime_seconds,refresh_token_lifetime_seconds,sso_idle_timeout_seconds}`.

**rendition-manifest.schema.json** — `$id: https://olympus.framework/schemas/cross-cutting/rendition-manifest.schema.json` · **2020-12** · title "Rendition Manifest" · addlProps **false** · required `[application_name, renditions]`
Props: `$schema:string`, `application_name:string`, `generated_date:string`, `renditions:array<object>`.

**score-snapshot.schema.json** — `$id: https://olympus.framework/schemas/cross-cutting/score-snapshot.schema.json` · **2020-12** · title "Score Snapshot" · addlProps **false** · required `[application_id, application_name, recorded_at, dimensions]`
Props: `$schema:string`, `application_id:string`, `application_name:string`, `recorded_at:string`, `source_artifact:string`, `governance_cycle:string`, `dimensions:array<object>`, `composite_scores:object{modernization_readiness,portfolio_health,disposition_confidence}`.

**temporal-workflow-contract.schema.json** — `$id: schemas/cross-cutting/temporal-workflow-contract.schema.json` (relative) · **draft-07** · title "Temporal Workflow Contract" · addlProps **true** · required `[name, task_queue, activities]`
Props: `name:string`, `task_queue:string`, `deterministic_invariants:array<string>`, `signals:array<object>`, `queries:array<object>`, `activities:array<object>`.

**traceability-report.schema.json** — `$id: https://olympus.framework/schemas/cross-cutting/traceability-report.schema.json` · **2020-12** · title "Traceability Report" · addlProps **false** · required `[application_name, coverage_percentage]` · **$defs (1): traceability-citation** (a local inline copy — required `[]`, body mirrors the `common/traceability-citation` oneOf shape)
Props: `$schema:string`, `application_name:string`, `generated_date:string`, `coverage_percentage:number`, `forward_traceability:array<object>`, `reverse_traceability:array<object>`, `coverage_gaps:array<object>`, `traceability_scores:array<object>`.

### 6.4 `schemas/data/` (6 — all 2020-12, host `olympus.framework`, all addlProps **false**)

⚠️ **GOTCHA — shared `required` quartet:** 5 of the 6 data schemas (`data-architecture`, `data-domains`, `data-migration-plan`, `data-product-design`, `decomposition-strategy`) share the **identical** required set `[target_app_id, target_service_id, relationship, source_app_ids]` and a shared `relationship` enum `[replace, consolidate, refactor, rearchitect, replatform, retain]`. `shared-db-analysis` differs (required `[source_app_id, wave_id]`).

**data-architecture.schema.json** — `$id: .../data/data-architecture.schema.json` · 2020-12 · title "Data Architecture" · addlProps **false** · required `[target_app_id, target_service_id, relationship, source_app_ids]`
Props: `$schema:string`, `absorbed_sources:array<object>`, `analysis_date:string`, `application_id:string`, `application_name:string`, `architecture_artifacts_absent:oneOf`, `architecture_inputs_status:object(free)`, `architecture_summary:object(free)`, `cross_domain_consistency_checks:array<object>`, `cross_target_references:array<object>`, `data_domains:array<object>`, `data_products:oneOf`, `decomposition_plan:object(free)`, `generated_at:string`, `inputs_consumed:object(free)`, `lineage:object(free)`, `metadata:object(free)`, `methodology_bias:string`, `methodology_compliance_summary:object(free)`, `migration_summary:object(free)`, `misalignments_and_block_findings:array<object>`, `open_questions:array<object>`, `open_questions_inherited:array<object>`, `pass:string`, `pii_and_classification_preservation:object(free)`, `references:object(free)`, `relationship:string enum[replace,consolidate,refactor,rearchitect,replatform,retain]`, `side_effect_projections:object(free)`, `side_effects_preview:object(free)`, `skill_id:string`, `source_app_ids:array<string>`, `source_app_names:array<string>`, `step:string`, `synthesis_flags:object(free)`, `synthesis_type:string`, `target_app_id:string`, `target_data_stores:array<object>`, `target_name:string`, `target_service_id:string`, `task_type:string`, `upstream_artifacts_loaded:oneOf`, `wave_id:string`.

**data-domains.schema.json** — `$id: .../data/data-domains.schema.json` · 2020-12 · title "Data Domain Discovery" · addlProps **false** · required `[target_app_id, target_service_id, relationship, source_app_ids]`
Props: `$schema:string`, `absorbed_sources:array<object>`, `application_id:string`, `application_name:string`, `boundary_arbitration_decisions:array<object>`, `arbitration_ledger:array<object>`, `boundary_arbitration_ledger:array<object>`, `boundary_violations_carried_forward:array<object>`, `cross_domain_reference_map:array<object>`, `cross_target_inbound_references:array<object>`, `deployment_coupling_constraints:array<string>`, `domains:array<object>`, `downstream_handoff:object(free)`, `entity_assignment_summary:object(free)`, `evidence_provenance:oneOf`, `fan_out_decision:object(free)`, `generated_at:string`, `generated_date:string`, `heuristics_applied:array<string>`, `hub_entities_and_coupling_hotspots:array<object>`, `metadata:object(free)`, `method:string`, `method_notes:oneOf`, `method_rationale:string`, `model_used:string`, `notes:array<string>`, `open_questions:array<object>`, `out_of_scope_for_target:array<object>`, `relationship:string enum[replace,consolidate,refactor,rearchitect,replatform,retain]`, `scope:object(free)`, `skill:string`, `skill_id:string`, `source_app_ids:array<string>`, `source_app_names:array<string>`, `sources:array<string>`, `summary:object(free)`, `target:object(free)`, `target_app_id:string`, `target_canonical_domains:array<object>`, `target_canonical_name:string`, `target_name:string`, `target_service_id:string`, `target_service_name:string`, `task:string`, `task_type:string`, `wave_id:string`.

**data-migration-plan.schema.json** — `$id: .../data/data-migration-plan.schema.json` · 2020-12 · title "Data Migration Plan" · addlProps **false** · required `[target_app_id, target_service_id, relationship, source_app_ids]`
Props: `$schema:string`, `absorbed_sources:array<object>`, `analysis_date:string`, `application_id:string`, `application_name:string`, `cloud_pattern_hint:string`, `cloud_pattern_hint_note:string`, `clusters:object(free)`, `data_freshness_sla_crosscheck:object(free)`, `generated_at:string`, `inputs_consumed:object(free)`, `metadata:object(free)`, `methodology_bias:string`, `methodology_compliance:object(free)`, `open_questions:array<object>`, `plan_summary:object(free)`, `references:object(free)`, `relationship:string enum[...same six...]`, `side_effects:object(free)`, `skill_id:string`, `source_app_ids:array<string>`, `source_app_names:array<string>`, `step:string`, `target_app_id:string`, `target_name:string`, `target_service_id:string`, `task_type:string`, `wave_id:string`.

**data-product-design.schema.json** — `$id: .../data/data-product-design.schema.json` · 2020-12 · title "Data Product Design" · addlProps **false** · required `[target_app_id, target_service_id, relationship, source_app_ids]`
Props: `$schema:string`, `absorbed_sources:array<object>`, `analysis_date:string`, `app_id:string`, `application_id:string`, `application_name:string`, `collation:string`, `extensions:array<string>`, `consumer_migration_paths:array<object>`, `data_products:array<object>`, `generated_at:string`, `inputs_consumed:object(free)`, `integration_contracts:array<object>`, `lineage:object(free)`, `metadata:object(free)`, `methodology_bias:string`, `methodology_compliance:object(free)`, `migration_risks:array<object>`, `nls_charset:string`, `open_questions:array<object>`, `pass:string`, `quality_rules:array<object>`, `references:object(free)`, `relationship:string enum[...six...]`, `skill_id:string`, `source_database:oneOf`, `source_app_ids:array<string>`, `source_app_names:array<string>`, `step:string`, `summary:object(free)`, `target_app_id:string`, `target_name:string`, `target_service_id:string`, `task_type:string`, `wave_id:string`.

**decomposition-strategy.schema.json** — `$id: .../data/decomposition-strategy.schema.json` · 2020-12 · title "Decomposition Strategy" · addlProps **false** · required `[target_app_id, target_service_id, relationship, source_app_ids]`
Props: `$schema:string`, `absorbed_sources:array<object>`, `analysis_date:string`, `application_id:string`, `application_name:string`, `cluster_strategies:array<object>`, `consolidation_summary:object(free)`, `decision_tree_trace:object(free)`, `downstream_projection:object(free)`, `faa_rac_guidance_applicable:boolean`, `faa_rac_guidance_rationale:string`, `generated_at:string`, `inputs_consumed:object(free)`, `metadata:object(free)`, `methodology_bias:string`, `methodology_compliance:object(free)`, `open_questions:array<object>`, `pass:string`, `references:object(free)`, `regeneration_note:string`, `relationship:string enum[...six...]`, `risks_and_mitigations:array<object>`, `side_effect_projections:object(free)`, `skill_id:string`, `source_app_ids:array<string>`, `source_app_names:array<string>`, `step:string`, `strategies:array<object>`, `strategy_summary:object(free)`, `target_app_id:string`, `target_name:string`, `target_pattern:string`, `target_service_id:string`, `wave_id:string`, `write_ownership_after_cutover:object(free)`.

**shared-db-analysis.schema.json** — `$id: .../data/shared-db-analysis.schema.json` · 2020-12 · title "Shared Database Analysis" · addlProps **false** · required `[source_app_id, wave_id]`
Props: `$schema:string`, `application_id:string`, `application_name:string`, `cross_application_sharing_summary:object(free)`, `faa_portfolio_notes:object(free)`, `generated_at:string`, `meta:object(free)`, `open_questions:array<object>`, `shared_database_clusters:array<object>`, `skill_id:string`, `source_app_id:string`, `step:string`, `task_type:string`, `top_risks_for_decomposition:array<object>`, `wave_id:string`.

### 6.5 `schemas/design/` (6 — all draft-07, all relative/no-host `$id`, all addlProps **true**) — ⚠️ EXCLUDED from `make validate-schemas` (§4)

**8710-field-dependency-graph.schema.json** — `$id: schemas/design/8710-field-dependency-graph.schema.json` · draft-07 · title "Form 8710-1 Field Dependency Graph" · required `[form_version, fields]`
Props: `form_version:string`, `fields:array<object>`.

**application-state-machine.schema.json** — `$id: schemas/design/application-state-machine.schema.json` · draft-07 · title "Application State Machine" · required `[initial, states, transitions]`
Props: `initial:string`, `states:array<object>`, `transitions:array<object>`.

**faa-pilot-cert-domain.schema.json** — `$id: schemas/design/faa-pilot-cert-domain.schema.json` · draft-07 · title "FAA Pilot Certification Domain Model" · required `[entities, migrations]`
Props: `entities:array<object>`, `migrations:array<object>`, `propagation_rules:array<object>`.

**form-8710-rules.schema.json** — `$id: schemas/design/form-8710-rules.schema.json` · draft-07 · title "FAA Form 8710 Validation Rules" · required `[form_variant, fields, dependencies]`
Props: `form_variant:string enum[8710-1, 8710-1F]`, `fields:array<object>`, `dependencies:array<object>`, `variant_overrides:object{added_fields,dropped_fields}`.

**medical-cert-class.schema.json** — `$id: schemas/design/medical-cert-class.schema.json` · draft-07 · title "FAA Medical Certification Class" · required `[class, validity_periods, disqualifying_conditions, si_pathway, soda_pathway]`
Props: `class:string enum[1st,2nd,3rd,BasicMed]`, `validity_periods:object{under_40_months,over_40_months}`, `privileges:array<string>`, `downgrade_on_expiry:string enum[1st,2nd,3rd,none]`, `disqualifying_conditions:array<object>`, `si_pathway:object{applicable_classes,review_period_months,renewal_required}`, `soda_pathway:object{applicable_classes,permanent}`, `amcd_referral_triggers:array<string>`.

**principal-mapping.schema.json** — `$id: schemas/design/principal-mapping.schema.json` · draft-07 · title "JWT Claim → Principal Mapping" · required `[principal_shape, claim_extractions]`
Props: `principal_shape:object{fields}`, `claim_extractions:array<object>`, `scope_to_role_map:object(free)`, `validation_rules:array<object>`.

### 6.6 `schemas/discovery/` (12 — 11×2020-12 `olympus.framework`; 1 draft-07 relative)

**analysis-report.schema.json** — `$id: .../discovery/analysis-report.schema.json` · 2020-12 · title "4-Pass Analysis Report" · addlProps **false** · required `[metadata, modernization_readiness_score]`
Props: `metadata:object{application_name,analyzed_date,analyst,codebase_location,catalog_reference,complexity_tier,analyzed_commit_sha}`, `executive_summary:string`, `modernization_readiness_score:object{dimensions,overall}`, `pass_1_architecture:object{module_architecture,dependency_graph,database_schema,external_interfaces,configuration_model}`, `pass_2_business_logic:object{business_rules,validation_rules,workflows,data_transformations,implicit_logic}`, `pass_3_quality_risk:object{security_findings,technical_debt,test_assessment,dependency_currency,maintainability_hotspots}`, `pass_4_ux_accessibility:object{ui_inventory,user_journeys,accessibility_assessment,ux_debt,ux_complexity_score}`, `key_risks:array<object>`, `preliminary_recommendation:string`, `open_questions:array<string>`.

**application-catalog-entry.schema.json** — `$id: .../discovery/application-catalog-entry.schema.json` · 2020-12 · title "Application Catalog Entry" · addlProps **false** · required `[application]`
Props: `application:object{name,cataloged_date,codebase_location,cataloged_by,archetype,business_domain}`, `technology_stack:array<object>`, `size_metrics:object{total_loc,languages_breakdown,modules_count,api_endpoints,database_tables,test_files,estimated_test_coverage}`, `data_entities:array<object>`, `business_operations:array<object>`, `external_integrations:array<object>`, `authentication:object{method,description}`, `user_context:object{personas,entry_points,accessibility_baseline,business_criticality}`, `deployment:object{model,description}`, `notable_characteristics:array<string>`, `open_questions:array<string>`, `tech_fingerprint:$ref tech-fingerprint.schema.json` (⚠️ relative-file `$ref` to sibling).

**business-logic.schema.json** — `$id: .../discovery/business-logic.schema.json` · 2020-12 · title "Business Logic Inventory" · addlProps **true** · required `[application_id, rules]`
Props: `$schema:string`, `application_id:string`, `discovery_pass:string`, `extraction_date:string`, `source_root:string`, `totals:object(free)`, `module_summary:object(free)`, `rules:array<object>`, `state_machines:array<object>`, `implicit_logic:array<object>`. (⚠️ distinct from the `olympus-contracts` "Business Logic Catalog"; §1.2.)

**business-rule-inventory.schema.json** — `$id: .../discovery/business-rule-inventory.schema.json` · 2020-12 · title "Business Rule Inventory (Discovery)" · addlProps **false** · required `[application, summary, rules]`
Props: `$schema:string`, `application:object{name,archetype,extraction_date,analyst,analyzed_commit_sha}`, `summary:object{rule_count,rules_by_category,rules_by_complexity,implicit_behaviors_detected,modules_covered,coverage_percent}`, `rules:array<object>`, `open_questions:array<object>`.

**capability-catalog.schema.json** — `$id: .../discovery/capability-catalog.schema.json` · 2020-12 · title "Capability Catalog" · addlProps **false** · required `[application_id, legacy_system, business_domains, capabilities]`
Props: `application_id:string`, `legacy_system:object{name,external_id,description,evidence_refs}`, `system_application_role:string enum[primary,contributing,deprecated]`, `business_domains:array<object>`, `capabilities:array<object>`, `open_questions:array<string>`.

**catalog.schema.json** — `$id: .../discovery/catalog.schema.json` · 2020-12 · title "Application Catalog Entry" (⚠️ **same title** as `application-catalog-entry`, different schema) · addlProps **true** · required `[application_id, tech_stack, architecture]`
Props: `$schema:string`, `application_id:string`, `application_name:string`, `description:string`, `business_domain:string`, `tech_stack:object{languages,frameworks,runtimes,databases,build_tools,ci_cd}`, `architecture:object{archetype,archetype_rationale}`, `size_metrics:object(free)`, `complexity_tier:string`, `safety_tier:string|null`, `user_facing:boolean`, `open_questions:array<object>`.

**discovery-synthesis.schema.json** — `$id: .../discovery/discovery-synthesis.schema.json` · 2020-12 · title "Discovery Synthesis" · addlProps **true** · required `[application_id, summary]`
Props: `$schema:string`, `application_id:string`, `application_name:string`, `synthesis_pass:string`, `generated:string`, `input_passes:object(free)`, `scope_caveat:string`, `summary:object{system_classification,high_confidence_findings,medium_confidence_findings,low_confidence_findings}`, `per_module_view:array<object>`, `contradictions:array<object>`, `confidence_scores:object(free)`, `open_questions:array<object>`, `downstream_consumer_summary:object(free)`.

**eligibility-rule-engine.schema.json** — `$id: schemas/discovery/eligibility-rule-engine.schema.json` (⚠️ **relative/no-host**) · **draft-07** · title "Eligibility Rule Engine" · addlProps **true** · required `[rules]`
Props: `rules:array<object>`.

**identity-landscape.schema.json** — `$id: .../discovery/identity-landscape.schema.json` · 2020-12 · title "Identity Landscape Analysis" · addlProps **true** · required `[portfolio_id, analyzed_date, identity_models, assurance_gaps, proliferation_findings]`
Props: `portfolio_id:string`, `analyzed_date:string`, `identity_models:array<object>`, `assurance_gaps:array<object>`, `proliferation_findings:array<object>`, `retire_recommendations:array<object>`, `broker_recommendation:object{recommended_pattern,broker_technology,fronted_idps,rationale}`.

**quality-risk.schema.json** — `$id: .../discovery/quality-risk.schema.json` · 2020-12 · title "Quality & Risk Assessment" · addlProps **true** · required `[application_id, risk_summary]`
Props: `$schema:string`, `application_id:string`, `application_name:string`, `assessment_date:string`, `assessment_pass:string`, `structural_map_source:string`, `risk_summary:object{overall_risk_tier,top_risk_drivers,highest_risk_modules,regulatory_surface_flags}`, `technical_debt_score:object(free)`, `vulnerabilities:array<object>`, `test_coverage:object(free)`, `code_smells:array<object>`, `escalation_triggers:array<object>`.

**tech-fingerprint.schema.json** — `$id: .../discovery/tech-fingerprint.schema.json` · 2020-12 · title "Tech Fingerprint" · addlProps **false** · required `[application, technology]`
Props: `$schema:string`, `application:object{name,repository,archetype}`, `technology:object{primary_language,language_breakdown,frameworks,runtime,databases,middleware,build_tool,container,ci_cd}`, `deployment:object{target,iac_coverage,iac_tool}`, `age_indicators:object{oldest_commit,last_commit,framework_eol,deprecated_apis}`, `complexity_proposal:object{tier,loc,modules,endpoints,tables,integrations}`. (Referenced via relative `$ref` by `application-catalog-entry`.)

**ux-accessibility.schema.json** — `$id: .../discovery/ux-accessibility.schema.json` · 2020-12 · title "UX & Accessibility Assessment" · addlProps **true** · required `[application_id, ui_inventory, personas, accessibility_findings]`
Props: `$schema:string`, `application_id:string`, `application_name:string`, `assessment_date:string`, `measurement_window:string`, `scope_caveat:string`, `ui_inventory:array<object>`, `personas:array<object>`, `adoption_baseline:object(free)`, `training_state:object(free)`, `accessibility_findings:object{applicable_standards,findings,finding_counts}`, `open_questions:array<object>`.

### 6.7 `schemas/dispositions/` (8 — all 2020-12, host `olympus.framework`, all addlProps **false**)

⚠️ **GOTCHA — `disposition` is a `const`** in each of the 7 per-disposition payload schemas (not an enum). The orchestrator `disposition-output` bundle wraps one of these in `payload`.

**consolidate-output.schema.json** — title "Consolidate Disposition Output Payload" · required `[disposition, target_application, feature_gap_analysis_ref, features_ported, features_dropped, enhancement_plan_ref, data_reconciliation, user_migration_ref, absorbed_decommission_ref]`
Props: `disposition:const "Consolidate"`, `target_application:object{id,name,target_selection_ref}`, `feature_gap_analysis_ref:string`, `features_ported:integer`, `features_dropped:array<object>`, `enhancement_plan_ref:string`, `data_reconciliation:object{records_merged,conflicts_resolved,reconciliation_ref}`, `user_migration_ref:string`, `absorbed_decommission_ref:string`.

**disposition-output.schema.json** — title "Disposition Output Bundle" · required `[application_id, application_name, portfolio_id, wave_id, disposition, status, started_at, completed_at, disposition_decision_ref, approvals, realized_net_impact, payload]`
Props: `application_id:string`, `application_name:string`, `portfolio_id:string`, `wave_id:string`, `disposition:string enum[Retire,Retain,Refactor,Rearchitect,Replace,Replatform,Consolidate]`, `status:string enum[completed,partial,rolled-back,abandoned]`, `started_at:string`, `completed_at:string`, `disposition_decision_ref:string`, `approvals:array<object>`, `realized_net_impact:object{tco_delta,users_affected_actual,users_affected_estimate_ref}`, `payload:object{disposition}` (the inner per-disposition payload; ⚠️ has its own nested `disposition` discriminator).

**rearchitect-output.schema.json** — title "Rearchitect Disposition Output Payload" · required `[disposition, modernized_repo_url, blueprint_ref, bounded_context_map_ref, generation_run_ref, parity_report_ref, test_coverage, deployment]`
Props: `disposition:const "Rearchitect"`, `modernized_repo_url:string`, `blueprint_ref:string`, `bounded_context_map_ref:string`, `generation_run_ref:string`, `parity_report_ref:string`, `test_coverage:object{before_pct,after_pct,coverage_report_ref}`, `deployment:object{environment,endpoint,deployment_ref}`.

**refactor-output.schema.json** — title "Refactor Disposition Output Payload" · required `[disposition, modernized_repo_url, blueprint_ref, generation_run_ref, parity_report_ref, test_coverage, deployment]`
Props: `disposition:const "Refactor"`, `modernized_repo_url:string`, `blueprint_ref:string`, `generation_run_ref:string`, `parity_report_ref:string`, `test_coverage:object{before_pct,after_pct,coverage_report_ref}`, `deployment:object{environment,endpoint,deployment_ref}`. (⚠️ identical to rearchitect minus `bounded_context_map_ref`.)

**replace-output.schema.json** — title "Replace Disposition Output Payload" · required `[disposition, selected_vendor, integration, data_migration, legacy_decommission_ref]`
Props: `disposition:const "Replace"`, `selected_vendor:object{name,product_version,vendor_evaluation_ref}`, `integration:object{integration_spec_ref,cutover_plan_ref}`, `data_migration:object{records_migrated,reconciliation_pass,migration_ref}`, `legacy_decommission_ref:string`.

**replatform-output.schema.json** — title "Replatform Disposition Output Payload" · required `[disposition, target_platform, workflow_mapping_ref, component_configuration_ref, data_migration, validation_cutover_ref, legacy_decommission_ref, perf_delta, cost_delta]`
Props: `disposition:const "Replatform"`, `target_platform:object{name,platform_selection_ref}`, `workflow_mapping_ref:string`, `component_configuration_ref:string`, `data_migration:object{records_migrated,reconciliation_pass,migration_ref}`, `validation_cutover_ref:string`, `legacy_decommission_ref:string`, `perf_delta:object{latency_p95_before_ms,latency_p95_after_ms,source}`, `cost_delta:object{monthly_before_usd,monthly_after_usd}`.

**retain-output.schema.json** — title "Retain Disposition Output Payload" · required `[disposition, retain_reason, remediation_outcome, sustainment_handoff, re_evaluation_triggers]`
Props: `disposition:const "Retain"`, `retain_reason:string`, `remediation_outcome:object{security_findings_closed,security_remediation_ref,documentation_updates_ref,test_coverage_baseline_pct,monitoring_setup_ref}`, `sustainment_handoff:object{owner_team,handoff_confirmed_at,handoff_ref}`, `re_evaluation_triggers:array<string>`.

**retire-output.schema.json** — title "Retire Disposition Output Payload" · required `[disposition, decommission_certificate_ref, archival, consumer_migration, license_reclamation_ref, infrastructure_torn_down]`
Props: `disposition:const "Retire"`, `decommission_certificate_ref:string`, `archival:object{archive_locations,reconstruction_plan_ref,data_archival_plan_ref}`, `consumer_migration:object{consumers_notified,consumers_confirmed_migrated,migration_report_ref}`, `license_reclamation_ref:string`, `infrastructure_torn_down:array<string>`.

### 6.8 `schemas/gates/` (3 — all 2020-12, host `olympus.framework`, all addlProps **false**)

⚠️ The **15-gate enum** is repeated verbatim in `gate-evidence-package` and `gate-review-checklist`:
`[G-DC, G-RR, G-DA, G-02, G-DT, G-04a, G-04b, G-04c, G-DE-1, G-DE-2, G-V1, G-V2, G-V3, G-DP-1, G-DP-2]`.

**escalation-record.schema.json** — title "Escalation Record" · required `[id, type, severity, application_name, trigger, status]`
Props: `$schema:string`, `id:string`, `type:string enum[ralph_loop_exhausted, gate_rejection, synthesis_conflict, agent_failure, validation_failure, compliance_block, stakeholder_required, other]`, `severity:string enum[critical,high,medium,low]`, `application_id:string`, `application_name:string`, `assembly_line:string`, `step:string`, `skill:string`, `agent:string`, `trigger:object{trigger_type,details,iteration_count,failing_tests,error_message}`, `created_at:string`, `status:string enum[open,investigating,resolved]`, `resolution:object{resolver,resolution_type,description,resolved_at}`, `pattern_extracted:boolean`, `pattern_id:string`.

**gate-evidence-package.schema.json** — title "Gate Evidence Package" · required `[gate_id, application_name, prepared_by, assembly_line, evidence_items]` · **$defs (2): risk-tier-annotation, evidence-reference**
Props: `$schema:string`, `gate_id:string enum[15 gates]`, `application_name:string`, `portfolio_id:string`, `wave_id:string`, `prepared_date:string`, `prepared_by:string`, `assembly_line:string enum[discovery,rationalization,architecture,data,modernization,disposition-execution,validation,deployment]`, `risk_tier:$ref #/$defs/risk-tier-annotation`, `evidence_items:array<$ref #/$defs/evidence-reference>`, `validation_results:array<object>`, `traceability_score:object{forward_coverage,backward_coverage,threshold,status}`, `reviewer_guidance:string`, `previous_attempts:integer`, `previous_feedback:array<object>`.
$defs: `risk-tier-annotation` (required `[tier,source]`; props `tier,source,classified_at,classified_by,justification,previous_tier,profile_reference` — inline copy of `common/risk-tier-annotation`); `evidence-reference` (required `[title,artifact_path,artifact_type,finding_summary,citations]`; props `id,title,artifact_path,artifact_version,artifact_type,section,finding_summary,citations,collected_at,collected_by` — inline copy of `common/evidence-reference`). ⚠️ These are **inline duplicates** (`$defs`) rather than `$ref`s to `common/`, so the gate package is self-contained — divergence risk if `common/` ever changes.

**gate-review-checklist.schema.json** — title "Gate Review Checklist" · required `[gate_id, application_name, checklist_items]`
Props: `gate_id:string enum[15 gates]`, `application_name:string`, `risk_tier:integer enum[1,2,3]`, `checklist_items:array<object>`, `overall_verdict:string enum[approved,rejected,pending]`, `reviewer:string`, `reviewed_at:string`, `rejection_feedback:string`.

### 6.9 `schemas/modernization/` (5 — MIXED host/dialect)

**business-rules.schema.json** — `$id: https://olympus.framework/schemas/modernization/business-rules.schema.json` · **2020-12** · title "Business Rules Catalog" · addlProps **false** · required `[application, rules]`
Props: `$schema:string`, `application:object{name,archetype,extraction_date,analyst}`, `rules:array<object>`, `batch_rules:array<object>`, `message_rules:array<object>`.

**modern-requirements.schema.json** — `$id: https://olympus.dev/schemas/modernization/modern-requirements.schema.json` (⚠️ **host `olympus.dev`**) · **draft-07** · title "Modern Requirements Catalog" · addlProps **(unset)** · required `[metadata, requirements]`
Props: `metadata:object{generated_date,application_id,application_name,sources}`, `requirements:array<object>`.

**module-map.schema.json** — `$id: https://olympus.framework/schemas/modernization/module-map.schema.json` · **2020-12** · title "Module Map" · addlProps **false** · required `[application, contexts, context_map]`
Props: `$schema:string`, `application:object{name,architecture_pattern,bounded_contexts}`, `contexts:array<object>`, `context_map:object{relationships}`, `cross_cutting:object{authentication,authorization,logging,error_handling,event_bus}`.

**rule-reconciliation-matrix.schema.json** — `$id: https://olympus.dev/schemas/modernization/rule-reconciliation-matrix.schema.json` (⚠️ **host `olympus.dev`**) · **draft-07** · title "Business Rule Reconciliation Matrix" · addlProps **(unset)** · required `[metadata, reconciliation, summary]`
Props: `metadata:object{generated_date,application_id,application_name,legacy_rules_count,modern_requirements_count,reconciliation_version}`, `reconciliation:array<object>`, `summary:object{coverage_percentage,disposition_breakdown,action_required_breakdown,reconciliation_metrics,deprecation_rate,net_new_rate,conflict_rate}`.

**test-scenarios.schema.json** — `$id: https://olympus.framework/schemas/modernization/test-scenarios.schema.json` · **2020-12** · title "Test Scenario Suite" · addlProps **false** · required `[application, scenarios]`
Props: `$schema:string`, `application:object{name,generated_date,analyst}`, `summary:object{total_scenarios,coverage_percentage}`, `scenarios:array<object>`.

### 6.10 `schemas/profiles/` (1 — 2020-12, host `olympus.framework`)

**objectives.schema.json** — `$id: .../profiles/objectives.schema.json` · 2020-12 · title "Agency Objectives" · addlProps **false** · required `[version, objectives]` · **$defs (10): NamespacedId, Unit, Direction, MetricReference, Kpi, Target, CustomContribution, ContributesFrom, SubObjective, Objective**
Props: `version:string`, `objectives:array<$ref #/$defs/Objective>`.
$defs detail:
- `NamespacedId`: `string`, pattern `^[a-z0-9][a-z0-9_-]*\.[a-z0-9][a-z0-9._-]*$`, minLength 3, maxLength 120.
- `Unit`: `string` enum `[count,pct,usd,days,weeks,months,years,ratio,bytes,ms]` (⚠️ identical enum to `metric.schema.json`'s `Unit`).
- `Direction`: `string` enum `[higher_is_better,lower_is_better]`.
- `MetricReference`: required `[metric,unit,direction]`; props `metric,unit,direction,label`.
- `Kpi`: required `[primary]`; props `primary,secondary,thresholds`.
- `Target`: required `[value,by]`; props `value,by,baseline`.
- `CustomContribution`: required `[type,selector]`; props `type,selector,label`.
- `ContributesFrom`: required `[]`; props `lines,gates,dispositions,risk_tiers,compliance_domains,skills,custom`.
- `SubObjective`: required `[id,label,kpi,contributes_from]`; props `id,label,kpi,target,contributes_from`.
- `Objective`: required `[id,label,order,narrative_template,kpi,target,contributes_from]`; props `id,label,order,owner,icon,description,narrative_template,kpi,target,contributes_from,sub_objectives,narrative_generator`.
⚠️ Validated by `scripts/validate_objectives.py` (the `make validate-objectives` target), NOT only by `validate-schemas`.

### 6.11 `schemas/rationalization/` (17 — 16×2020-12 `olympus.framework`; 1 `olympus.faa.gov`)

**business-rule-redundancy.schema.json** — `$id: .../rationalization/business-rule-redundancy.schema.json` · 2020-12 · title "Cross-App Business Rule Redundancy" · addlProps **false** · required `[wave_id, summary, clusters]`
Props: `$schema:string`, `wave_id:string`, `analyzed_at:string`, `methodology_version:string`, `summary:string`, `clusters:array<object>`, `unclustered_rules_count:integer`, `single_app_rule_categories:array<object>`, `analysis_pass_citations:array<string>`.

**capability-consolidation-plan.schema.json** — `$id: .../rationalization/capability-consolidation-plan.schema.json` · 2020-12 · title "Capability Consolidation Plan" · addlProps **false** · required `[metadata, capability_plans]` · **$defs (1): capability_plan_entry**
Props: `metadata:object{wave_id,portfolio_id,generated_date,generator,capabilities_analyzed,source_artifact_digests}`, `capability_plans:array<$ref #/$defs/capability_plan_entry>`.
$defs `capability_plan_entry`: required `[capability_id,capability_name,participating_apps,aggregate_disposition,consolidation_pattern,sequencing,risks,estimated_effort,evidence]`; props `capability_id,rationalization_capability_id,rationalization_capability_external_id,capability_name,participating_apps,aggregate_disposition,consolidation_pattern,canonical_target,target_capability,target_system,sequencing,strangler_justification,risks,estimated_effort,evidence`.

**classification.schema.json** — `$id: .../rationalization/classification.schema.json` · 2020-12 · title "Application Risk Classification" · addlProps **false** · required `[app_id, risk_tier, risk_confidence, risk_rationale, tier_1_flag, computed_at]`
Props: `app_id:string`, `risk_tier:integer enum[1,2,3]`, `risk_confidence:number`, `risk_rationale:string`, `tier_1_flag:boolean`, `referenced_catalog:object{archetype,complexity_tier}`, `computed_at:string`, `source_system_id:string|null`, `source_capability_ids:array<string>`.

**disposition-governance.schema.json** — `$id: .../rationalization/disposition-governance.schema.json` · 2020-12 · title "Disposition Governance Package" · addlProps **true** · required `[schema_version, wave_id, application_id, disposition_summary, stakeholder_matrix, approval_tracking]`
Props: `schema_version:string`, `governance_artifact_id:string`, `generated_at:string`, `wave_id:string`, `application_id:string`, `application_name:string`, `application_full_name:string`, `upstream_recommendation_ref:string`, `governance_grain:string enum[application, rat_cap]`, `note_on_grain:string`, `disposition_summary:object{rat_cap_count,primary_disposition_mix,highest_consequence_rat_caps}`, `stakeholder_matrix:object{note,required_sign_off,informational_notify}`, `user_migration_plan:object(free)`, `evidence_package:object(free)`, `policy_compliance_checks:array<object>`, `open_questions_requiring_resolution:array<object>`, `approval_tracking:object{overall_status,approval_rounds,exceptions_log}`.

**disposition-recommendation.schema.json** — `$id: .../rationalization/disposition-recommendation.schema.json` · 2020-12 · title "Disposition Recommendation" · addlProps **false** · required `[metadata, rationalization_capability_dispositions]` · **$defs (3): alternative, evidence-ref, rat-cap-disposition**
Props: `metadata:object{portfolio_id,wave_id,input_rat_cap_count,agent_run_id}`, `rationalization_capability_dispositions:array<$ref #/$defs/rat-cap-disposition>`, `open_questions:array<string>`.
$defs: `alternative` (required `[disposition,rationale]`; props `disposition,score,rationale`); `evidence-ref` (required `[kind,citation]`; props `kind,rationalization_capability_id,external_id,citation`); `rat-cap-disposition` (required `[rationalization_capability_name,primary_disposition,rationale,confidence,evidence_refs]`; props `rationalization_capability_id,rationalization_capability_name,rationalization_capability_external_id,primary_disposition,secondary_disposition,target_service_external_id,rationale,confidence,evidence_refs,alternatives_considered`).

**integration-graph.schema.json** — `$id: .../rationalization/integration-graph.schema.json` · 2020-12 · title "Portfolio Integration Graph" · addlProps **true** · required `[metadata, systems, data_flows, shared_identifiers, cross_system_capabilities]`
Props: `$schema:string`, `metadata:object{generated_date,wave_id,applications_analyzed,analyst,source_artifacts,decomposed_apps,isolated_systems,unresolved_references}`, `systems:array<object>`, `data_flows:array<object>`, `shared_identifiers:array<object>`, `external_deps:array<object>`, `cross_system_capabilities:array<object>`.

**portfolio-score.schema.json** — `$id: .../rationalization/portfolio-score.schema.json` · 2020-12 · title "Portfolio Score" · addlProps **false** · required `[app_id, scores, overall_weighted, methodology_version, computed_at]` · **$defs (1): dimension-score**
Props: `app_id:string`, `scores:object{technical_readiness,architectural_readiness,operational_readiness,security_readiness,user_experience_readiness,business_readiness}` (each child is a `$ref` to `#/$defs/dimension-score`), `overall_weighted:number`, `methodology_version:string`, `computed_at:string`, `source_system_id:string|null`, `source_capability_ids:array<string>`.
$defs `dimension-score`: required `[score,rationale,evidence]`; props `score,rationale,evidence`.

**portfolio-target-state-rollup.schema.json** — `$id: .../rationalization/portfolio-target-state-rollup.schema.json` · 2020-12 · title "Portfolio Target-State Rollup" · addlProps **false** · required `[portfolio_id, computed_at, waves_included, waves_omitted, counts, disposition_mix, aggregate_net_impact]`
Props: `portfolio_id:string`, `computed_at:string`, `waves_included:array<object>`, `waves_omitted:array<object>`, `counts:object{apps_total,target_state_system_count,retired,consolidated_absorbed,surviving}`, `disposition_mix:object{Retire,Retain,Refactor,Rearchitect,Replace,Replatform,Consolidate}` (⚠️ keys are the 7 disposition names), `aggregate_net_impact:object{annual_savings_usd,one_time_cost_usd,tier1_reduction,users_affected}`.

**rationalization-clustering-plan.schema.json** — `$id: https://olympus.faa.gov/schemas/rationalization/rationalization-clustering-plan.json` (⚠️ **host `olympus.faa.gov` + `.json` (no `.schema`) suffix; `$id`≠path**) · **2020-12** · title "Rationalization Capability Clustering Plan" · addlProps **false** · required `[metadata, rationalization_capabilities, capability_assignments, capability_splits]`
Props: `metadata:object{portfolio_id,wave_id,input_capability_count,input_application_count,agent_run_id}`, `rationalization_capabilities:array<object>`, `capability_assignments:array<object>`, `capability_splits:array<object>`, `open_questions:array<string>`.

**redundancy-matrix.schema.json** — `$id: .../rationalization/redundancy-matrix.schema.json` · 2020-12 · title "Redundancy Matrix" · addlProps **false** · required `[metadata, entity_overlap, operation_overlap]`
Props: `$schema:string`, `metadata:object{generated_date,applications_analyzed,analyst}`, `entity_overlap:array<object>`, `operation_overlap:array<object>`, `high_overlap_pairs:array<object>`, `data_sot_conflicts:array<object>`, `consolidation_candidates:array<object>`.

**shared-identity-report.schema.json** — `$id: .../rationalization/shared-identity-report.schema.json` · 2020-12 · title "Shared Identity Report" · addlProps **false** · required `[apps, cross_app_matches]` · **$defs (3): confidence-tier, identifier-record, privacy-finding**
Props: `apps:array<object>`, `cross_app_matches:array<object>`, `privacy_findings:array<$ref #/$defs/privacy-finding>`.
$defs: `confidence-tier` (`string` enum `[none,low,medium,high]`); `identifier-record` (required `[column_hits,regex_hits,var_hits,confidence]`; props same 4); `privacy-finding` (required `[identifier,regulatory_class,apps,detail]`; props same 4).

**tco-analysis.schema.json** — `$id: .../rationalization/tco-analysis.schema.json` · 2020-12 · title "TCO Analysis" · addlProps **false** · required `[application_name, analyst, current_costs]`
Props: `application_name:string`, `analysis_date:string`, `analyst:string`, `currency:string`, `current_costs:object{infrastructure,licensing,operations_maintenance,personnel,other,total_annual}`, `disposition_projections:array<object>`, `cost_drivers:array<object>`, `notes:string`.

**user-impact-analysis.schema.json** — `$id: .../rationalization/user-impact-analysis.schema.json` · 2020-12 · title "User Impact Analysis" · addlProps **true** · required `[application_id, disposition, personas, disruption_profile, accessibility_regressions]`
Props: `$schema:string`, `application_id:string`, `wave_id:string`, `disposition:string`, `assessed_at:string`, `users_affected:integer|null`, `journeys_disrupted:integer|null`, `training_burden_hours:number|null`, `personas:array<object>`, `disruption_profile:object{severity,duration_weeks,cutover_model,fallback_available}`, `training:object{modalities,total_hours,breakdown_by_persona}`, `accessibility_regressions:array<object>`, `source_refs:object(free)`, `source_system_id:string|null`, `source_capability_ids:array<string>`.

**ux-overlap-matrix.schema.json** — `$id: .../rationalization/ux-overlap-matrix.schema.json` · 2020-12 · title "UX Overlap Matrix" · addlProps **false** · required `[wave_id, personas, persona_task_matrix, swivel_chair_patterns, fragmented_journeys, pair_scores]`
Props: `$schema:string`, `wave_id:string`, `generated_at:string`, `methodology_version:string`, `personas:array<object>`, `persona_task_matrix:array<object>`, `swivel_chair_patterns:array<object>`, `fragmented_journeys:array<object>`, `pair_scores:array<object>`, `summary:object{total_personas,total_journeys,fragmented_journey_count,swivel_chair_pattern_count,avg_ux_overlap_pct}`.

**wave-outcome-synthesis.schema.json** — `$id: .../rationalization/wave-outcome-synthesis.schema.json` · 2020-12 · title "Wave Outcome Synthesis" · addlProps **false** · required (16 fields) `[wave_id, wave_number, wave_name, portfolio_id, synthesized_at, app_count, target_state_system_count, retired_count, consolidated_into_count, surviving_count, disposition_mix, estimated_net_impact, consolidated_capabilities_map, technology_simplification_score, narrative_target_state_architecture, source_artifact_refs]`
Props: `wave_id:string`, `wave_number:integer`, `wave_name:string`, `portfolio_id:string`, `synthesized_at:string`, `app_count:integer`, `target_state_system_count:integer`, `retired_count:integer`, `consolidated_into_count:integer`, `surviving_count:integer`, `disposition_mix:object{Retire,Retain,Refactor,Rearchitect,Replace,Replatform,Consolidate}`, `estimated_net_impact:object{tco_delta,velocity_delta,risk_delta,user_impact_summary}`, `consolidated_capabilities_map:array<object>`, `technology_simplification_score:number`, `narrative_target_state_architecture:string`, `source_artifact_refs:object{redundancy_matrix,disposition_recommendations,tco_analyses,user_impact_reports,classifications,wave_plan,disposition_output_bundles}`, `realized_vs_planned:object{apps_with_bundles,apps_missing_bundles,realized_annual_savings_usd,planned_annual_savings_usd,realized_vs_planned_savings_delta_usd,realized_users_affected,source}`.

**wave-plan-validation.schema.json** — `$id: .../rationalization/wave-plan-validation.schema.json` · 2020-12 · title "Wave Plan Validation Report" · addlProps **true** · required `[wave_id, status, summary, errors, warnings]`
Props: `$schema:string`, `wave_id:string`, `validated_at:string`, `methodology_version:string`, `validator:string`, `status:string enum[passed,warnings,failed]`, `summary:object{errors_count,warnings_count,blocking,g_da_unblocked}`, `errors:array<object>`, `warnings:array<object>`, `checks_run:array<string>`, `checks_passed:array<string>`, `checks_failed:array<string>`.

**wave-plan.schema.json** — `$id: .../rationalization/wave-plan.schema.json` · 2020-12 · title "Wave Modernization Plan" · addlProps **true** · required `[wave_id, apps, total_duration_days]`
Props: `$schema:string`, `wave_id:string`, `portfolio_name:string`, `generated_at:string`, `methodology_version:string`, `generator:string`, `metadata:object{wave_id,input_application_count,source_artifacts,disposition_source,readiness_source,duration_unit,schedule_anchor}`, `apps:array<object>`, `critical_path:array<string>`, `critical_path_alternates:array<object>`, `total_duration_days:integer`, `peak_concurrency:integer`, `concurrency_timeline:array<object>`, `risk_balance_warnings:array<string>`, `phases:array<object>`, `external_anchors:array<object>`, `override_register:array<object>`, `forecast:object{wave_forecasts}`.

---

## 7. Per-schema detail — `olympus-contracts/schemas/` (2)

**discovery/business-logic.schema.json** — `$id: https://olympus.faa.gov/schemas/discovery/business-logic.schema.json` · **draft-07** · title "Business Logic Catalog" · addlProps **(unset)** · required `[version, application, extraction_metadata, business_rules]` · **definitions (1): business_rule** (note key is `definitions`, draft-07 idiom, not `$defs`)
Props: `version:string`, `application:object`, `extraction_metadata:object`, `business_rules:array<$ref #/definitions/business_rule>`.

**pipeline-execution/step-execution-record.schema.json** — `$id: https://olympus.faa.gov/schemas/pipeline-execution/step-execution-record.schema.json` · **draft-07** · title "Step Execution Record" · addlProps **(unset)** · required (19 fields) `[execution_id, app_id, wave_id, portfolio_id, line_id, step_id, step_kind, status, started_at, completed_at, duration_ms, attempt, last_error, input_artifacts, output_artifacts, payload, workflow_id, agent_task_id, gate_id]` · **definitions (8): StepArtifactRef, AgentPayload, GitPayload, GatePayload, GateDecision, CodePayload, TerminalPayload, FanoutBlock**
Props: `execution_id:string`, `app_id:string|null`, `wave_id:string|null`, `portfolio_id:string`, `line_id:string`, `step_id:string`, `step_kind:string enum[agent,git,gate,code,terminal]`, `status:string enum[queued,running,completed,failed,timed_out,skipped,escalated,abandoned]`, `started_at:string|null`, `completed_at:string|null`, `duration_ms:integer|null`, `attempt:integer`, `last_error:string|null`, `input_artifacts:array<$ref #/definitions/StepArtifactRef>`, `output_artifacts:array<$ref #/definitions/StepArtifactRef>`, `payload:object`, `workflow_id:string`, `agent_task_id:string|null`, `gate_id:string|null`.
⚠️ This is the projection contract consumed by the API/Temporal layers (`olympus-api/tests/test_contract_step_execution_projection.py`, `temporal/tests/test_contract_envelope_schema.py`). `step_kind` enum and `status` enum are the canonical pipeline-step taxonomy.

---

## 8. Metaschema & `$ref` resolution — how it works

### 8.1 Metaschema dialects
- **JSON Schema 2020-12** (`$schema: https://json-schema.org/draft/2020-12/schema`) — 69 schemas. Uses `$defs`, `const`, type-array unions.
- **draft-07** (`$schema: http://json-schema.org/draft-07/schema#`) — 17 schemas. Uses `definitions` (the 2 `olympus-contracts` ones) — but several draft-07 schemas in `schemas/` declare no `definitions`/`$defs` at all and use inline `object{...}` shapes. Note the draft-07 URI is **http** with a trailing `#`, while the 2020-12 URI is **https** with no fragment.
⚠️ **GOTCHA:** the CI metaschema validator (`check-jsonschema --check-metaschema`) selects the metaschema **from the file's own `$schema`**, so it correctly validates draft-07 files against draft-07. But CI **sample**-validation hard-codes `Draft202012Validator` (§2.2) for ALL targets, including the 2 draft-07-targeted samples (`modern-requirements`, `rule-reconciliation-matrix`). Recreate this asymmetry exactly.

### 8.2 `$ref` styles observed (three kinds)
1. **Relative-file `$ref`** (resolves against the schema's directory): e.g. `common/evidence-reference.schema.json` → `citations: {$ref: "traceability-citation.schema.json"}`; `discovery/application-catalog-entry.schema.json` → `tech_fingerprint: {$ref: "tech-fingerprint.schema.json"}`. These resolve to a sibling file in the same directory.
2. **Local-pointer `$ref`** (`#/$defs/...` or `#/definitions/...`): used by `metric`, `objectives`, `gate-evidence-package`, `traceability-report`, `capability-consolidation-plan`, `disposition-recommendation`, `portfolio-score`, `shared-identity-report`, and both `olympus-contracts` schemas. Self-contained; no external resolution needed.
3. (No absolute-`$id`-URI cross-`$ref`s are present in the corpus — i.e. nothing `$ref`s `https://olympus.framework/schemas/...` of another file.) ⚠️ This is why the host inconsistencies (§3) do not currently break validation: every cross-file `$ref` is relative-file, not `$id`-URI. The `store` keyed by `$id` in CI (§2.2) is built but effectively unused for resolution today; it is a latent foot-gun if anyone introduces an `$id`-URI `$ref`.

### 8.3 Resolver / registry
- **No external resolver library, no `$ref` registry file, no `$schema` bundling step** beyond the inline CI Python (`ci.yml:283-321`). The only resolver instance is `jsonschema.RefResolver` constructed per-sample with `base_uri = schema.$id` (or the schema file URI fallback) and a `store` dict of `{$id: schema}`.
- ⚠️ `RefResolver` is **deprecated** in modern `jsonschema` (≥4.18 prefers `referencing`), but the CI pins behavior by simply importing it; recreate with a `jsonschema` version that still ships `RefResolver`.
- The OpenAPI spec (`specifications/api/openapi.yaml`) is validated separately via `@redocly/cli lint` + `bundle` (`ci.yml:256-264`); not part of JSON-Schema validation and out of scope for this inventory.

---

## Appendix A — Full enum reference (verbatim)

| Schema :: property | enum values |
|---|---|
| `common/confidence-level` :: `level` | `high, medium, low` |
| `common/evidence-reference` :: `artifact_type` | `analysis-report, catalog-entry, tech-fingerprint, redundancy-matrix, disposition-entry, business-rules, module-map, test-scenarios, parity-report, security-assessment, accessibility-audit, tco-analysis, score-snapshot, traceability-report, other` |
| `common/risk-tier-annotation` :: `tier` / `previous_tier` | `1, 2, 3` (integer) |
| `common/risk-tier-annotation` :: `source` | `auto, confirmed, overridden` |
| `cross-cutting/metric` $defs `Unit` | `count, pct, usd, days, weeks, months, years, ratio, bytes, ms` |
| `cross-cutting/metric` $defs `Aggregation` | `latest, sum, avg, rate` |
| `cross-cutting/metric` $defs `SourceKind` | `sql_view, api_endpoint, postgres_query` |
| `cross-cutting/oidc-server-config` :: `provider` | `keycloak, auth0, okta, cognito, custom` |
| `design/form-8710-rules` :: `form_variant` | `8710-1, 8710-1F` |
| `design/medical-cert-class` :: `class` | `1st, 2nd, 3rd, BasicMed` |
| `design/medical-cert-class` :: `downgrade_on_expiry` | `1st, 2nd, 3rd, none` |
| `discovery/capability-catalog` :: `system_application_role` | `primary, contributing, deprecated` |
| `data/*` (5 schemas) :: `relationship` | `replace, consolidate, refactor, rearchitect, replatform, retain` |
| `dispositions/disposition-output` :: `disposition` | `Retire, Retain, Refactor, Rearchitect, Replace, Replatform, Consolidate` |
| `dispositions/disposition-output` :: `status` | `completed, partial, rolled-back, abandoned` |
| `dispositions/{retire,retain,refactor,rearchitect,replace,replatform,consolidate}-output` :: `disposition` | `const` = the matching capitalized name |
| `gates/escalation-record` :: `type` | `ralph_loop_exhausted, gate_rejection, synthesis_conflict, agent_failure, validation_failure, compliance_block, stakeholder_required, other` |
| `gates/escalation-record` :: `severity` | `critical, high, medium, low` |
| `gates/escalation-record` :: `status` | `open, investigating, resolved` |
| `gates/gate-evidence-package` & `gates/gate-review-checklist` :: `gate_id` | `G-DC, G-RR, G-DA, G-02, G-DT, G-04a, G-04b, G-04c, G-DE-1, G-DE-2, G-V1, G-V2, G-V3, G-DP-1, G-DP-2` |
| `gates/gate-evidence-package` :: `assembly_line` | `discovery, rationalization, architecture, data, modernization, disposition-execution, validation, deployment` |
| `gates/gate-review-checklist` :: `risk_tier` | `1, 2, 3` (integer) |
| `gates/gate-review-checklist` :: `overall_verdict` | `approved, rejected, pending` |
| `profiles/objectives` $defs `Unit` | `count, pct, usd, days, weeks, months, years, ratio, bytes, ms` |
| `profiles/objectives` $defs `Direction` | `higher_is_better, lower_is_better` |
| `rationalization/classification` :: `risk_tier` | `1, 2, 3` (integer) |
| `rationalization/disposition-governance` :: `governance_grain` | `application, rat_cap` |
| `rationalization/shared-identity-report` $defs `confidence-tier` | `none, low, medium, high` |
| `rationalization/wave-plan-validation` :: `status` | `passed, warnings, failed` |
| `olympus-contracts/.../step-execution-record` :: `step_kind` | `agent, git, gate, code, terminal` |
| `olympus-contracts/.../step-execution-record` :: `status` | `queued, running, completed, failed, timed_out, skipped, escalated, abandoned` |

## Appendix B — Pattern reference (regex constraints)

| Schema :: location | pattern |
|---|---|
| `common/traceability-citation` branch A :: `finding_id` | `^[A-Z]{1,5}-[0-9]+$` |
| `common/traceability-citation` branch B :: `commit_sha` | `^[0-9a-f]{7,40}$` |
| `cross-cutting/metric` $defs `MetricId` | `^[a-z][a-z0-9_]*(\.[a-z][a-z0-9_]*)+$` (minLen 3, maxLen 200) |
| `cross-cutting/metric` $defs `TrendWindow` | `^[0-9]+_(waves|days|weeks|months|years)$` |
| `profiles/objectives` $defs `NamespacedId` | `^[a-z0-9][a-z0-9_-]*\.[a-z0-9][a-z0-9._-]*$` (minLen 3, maxLen 120) |
