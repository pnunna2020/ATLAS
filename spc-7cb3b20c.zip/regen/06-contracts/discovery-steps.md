# Discovery Assembly Line — Step Contract (ATOMIC REGEN SPEC)

**Source of truth:** `olympus-contracts/olympus_contracts/data/assembly-lines/discovery.yaml`
**All citations below are `discovery.yaml:<line>` unless otherwise stated.**

This document reproduces the Discovery assembly-line contract field-by-field for behavioral
parity. The YAML file declares itself the authoritative source consumed by the Temporal
workflow, the Olympus API gate service, the step-progress mapping, and the frontend step
registry — all of which load FROM this file via `olympus_contracts.assembly_lines`. The
file header (`discovery.yaml:1-8`) states that no application code may hardcode a copy, and
that drift is policed by the `test_no_hardcoded_step_lists` CI check.

> **STEP-COUNT CORRECTION (verified against source).** The task brief asserted "EXACTLY 15
> steps." The authoritative file `discovery.yaml` contains **EXACTLY 14** step list items
> under `steps:` (the `- id:` entries at 2-space indent), verified three ways: (a)
> `grep -cE "^  - id:"` over lines ≥41 returns **14**; (b) there is a single `steps:` block
> at `discovery.yaml:41` and no second one; (c) the file is 679 source lines and its final
> step is `gate-review` ending with `retry_policy.category: validation_failure`. The
> `- id: G-DC` at `discovery.yaml:21` is under the top-level `gates:` key (`discovery.yaml:20`),
> **NOT** a step, and is correctly excluded. There is no 15th step to reproduce; inventing one
> would be a fabrication. ALL 14 real steps are reproduced in full below. The closing inventory
> reflects the true count of 14.

⚠️ GOTCHA (`discovery.yaml:1-8`): This YAML is the ONLY legitimate definition of Discovery's
steps/skills/artifacts/side-effects/agent-contract. Any divergent copy in a Temporal
workflow, API service, progress map, or frontend registry is a defect caught by
`test_no_hardcoded_step_lists`. Reproduce this file exactly; do not normalize, reorder, or
collapse fields.

---

## 1. Line-Level Metadata

Reproduced exactly from `discovery.yaml:10-39`.

| Key | Value | Cite |
|-----|-------|------|
| `name` | `Discovery` | `discovery.yaml:10` |
| `description` | (block scalar, folded `>` — see verbatim below) | `discovery.yaml:11-17` |
| `trigger` | `onboarding` | `discovery.yaml:18` |
| `depends_on` | `[]` (empty list — Discovery has NO upstream line dependencies) | `discovery.yaml:19` |
| `gates` | one gate entry (see below) | `discovery.yaml:20-22` |
| `mode` | `per-app` | `discovery.yaml:23` |
| `inputs` | 3-element list (see below) | `discovery.yaml:24-27` |
| `outputs` | 11-element list (see below) | `discovery.yaml:28-39` |

### 1.1 `description` (verbatim, folded block scalar `>`)

`discovery.yaml:11-17`:

> Per-application intake. Ingests an application's source tree, produces a standardized
> catalog entry, runs a four-pass structural + behavioral analysis, establishes a TCO
> baseline, and writes a reviewable artifact bundle to the portfolio's artifact repo.
> Terminal gate G-DC signals that the application is ready for Rationalization. Every
> downstream line depends on Discovery outputs.

### 1.2 `gates` (`discovery.yaml:20-22`)

A list with a single map entry:

```yaml
gates:
  - id: G-DC
    label: Discovery Complete
```

- `gates[0].id` = `G-DC` (`discovery.yaml:21`)
- `gates[0].label` = `Discovery Complete` (`discovery.yaml:22`)

### 1.3 `mode` (`discovery.yaml:23`)

`mode: per-app`.

⚠️ GOTCHA: This line is **triggered per-app, NOT continuous**. `trigger: onboarding`
(`discovery.yaml:18`) + `mode: per-app` (`discovery.yaml:23`) means Discovery runs once per
application onboarded, not on a continuous cron. (Contrast with the continuous Sustainment /
Governance lines.) Every step also independently carries `scope: per-app`.

### 1.4 `inputs` (line-level, `discovery.yaml:24-27`)

A flat 3-element list (NOT split into artifacts/context at line level — that split only
exists per-step):

1. `legacy-source` (`discovery.yaml:25`)
2. `documentation` (`discovery.yaml:26`)
3. `stakeholder-context` (`discovery.yaml:27`)

### 1.5 `outputs` (line-level, `discovery.yaml:28-39`)

A flat 11-element list:

1. `application-catalog-entry` (`discovery.yaml:29`)
2. `tech-fingerprint` (`discovery.yaml:30`)
3. `structural-analysis` (`discovery.yaml:31`)
4. `business-logic` (`discovery.yaml:32`)
5. `quality-risk` (`discovery.yaml:33`)
6. `ux-accessibility` (`discovery.yaml:34`)
7. `data-domains` (`discovery.yaml:35`)
8. `shared-db-analysis` (`discovery.yaml:36`)
9. `capability-catalog` (`discovery.yaml:37`)
10. `discovery-synthesis` (`discovery.yaml:38`)
11. `tco-baseline` (`discovery.yaml:39`)

⚠️ GOTCHA: The line-level `outputs` list uses artifact IDs that differ from some per-step
`outputs.artifacts` IDs. E.g. line-level `data-domains` / `shared-db-analysis` /
`capability-catalog` (hyphenated) match their step output artifact IDs, but several
intermediate per-step artifacts (`database-schema-summary`, `interface-inventory`,
`state-machines`, `implicit-logic`) are NOT in the line-level `outputs` — they are internal
hand-offs between steps, not declared line outputs. Do not assume line `outputs` ==
union of step `outputs.artifacts`.

⚠️ GOTCHA: There is NO top-level `id` key on the line; the line is identified solely by
`name: Discovery` (`discovery.yaml:10`). There is no `retry_policy`, no `agent_contract`,
and no `version` at the line level — those exist only per-step.

---

## 2. Steps (ALL 14, in file order)

There are exactly **14** steps under `steps:` (`discovery.yaml:41`). The `- id:` items at
2-space indent are at lines 42, 83, 158, 202, 246, 291, 338, 385, 444, 490, 533, 577, 611,
647. (The `- id: G-DC` at `discovery.yaml:21` is under `gates:`, NOT a step, and is excluded
from the step count.)

Common shape notes (apply across steps unless overridden):
- Every step has `scope: per-app`.
- `kind` is one of `agent` (11 steps), `git` (2 steps: commit-artifacts, create-pr), `gate`
  (1 step: gate-review). Note `gate-readiness-check` is `kind: agent` with `role: pre-review`.
- `agent_contract.repos` is a 3-key map: `artifact` / `source` / `target`, each one of
  `rw` / `ro` / `none`.
- `retry_policy.category` is one of `agent_failure`, `transient`, `validation_failure`.
- For `agent_failure` steps, `non_retryable_errors: [SchemaValidationError]` is always present.
- ⚠️ GOTCHA: The field is `agent_contract.mcp_servers` (plural, with `_servers`), NOT `mcp`.
  Its value is a list — `[olympus]` for agent steps, `[]` (empty) for git/gate steps.
- ⚠️ GOTCHA: There is NO standalone `parallel_with`-at-top vs nested distinction; every step
  has a `parallel_with` list (possibly empty). Two parallel clusters exist: the sequence-3
  six-way fan-out and the sequence-4 two-way pair. See clusters in §3.

---

### STEP 1 — `catalog` (`discovery.yaml:42-81`)

| Field | Value | Cite |
|-------|-------|------|
| `id` | `catalog` | `discovery.yaml:42` |
| `label` | `Catalog` | `discovery.yaml:43` |
| `kind` | `agent` | `discovery.yaml:44` |
| `scope` | `per-app` | `discovery.yaml:45` |
| `sequence` | `1` | `discovery.yaml:46` |
| `progress_pct` | `10` | `discovery.yaml:47` |
| `progress_weight` | `10` | `discovery.yaml:48` |
| `artifact_filename` | `catalog.json` | `discovery.yaml:49` |
| `purpose` | folded block scalar (verbatim below) | `discovery.yaml:50-53` |
| `skills` | `[catalog-application]` | `discovery.yaml:54` |
| `agent_role` | `Analysis Agent` | `discovery.yaml:55` |
| `inputs.artifacts` | `[]` (empty) | `discovery.yaml:57` |
| `inputs.context` | `[source-repo-clone, cmdb-exports, existing-docs]` | `discovery.yaml:58` |
| `outputs.artifacts` | `[application-catalog-entry, tech-fingerprint]` | `discovery.yaml:60` |
| `outputs.side_effects` | one entry, target `application` (below) | `discovery.yaml:61-70` |
| `agent_contract.mcp_servers` | `[olympus]` | `discovery.yaml:72` |
| `agent_contract.repos.artifact` | `rw` | `discovery.yaml:74` |
| `agent_contract.repos.source` | `ro` | `discovery.yaml:75` |
| `agent_contract.repos.target` | `none` | `discovery.yaml:76` |
| `parallel_with` | `[]` (empty) | `discovery.yaml:77` |
| `gate` | `null` | `discovery.yaml:78` |
| `retry_policy.category` | `agent_failure` | `discovery.yaml:80` |
| `retry_policy.non_retryable_errors` | `[SchemaValidationError]` | `discovery.yaml:81` |

`purpose` verbatim (`discovery.yaml:50-53`):
> Produce the standardized Application Catalog entry and tech fingerprint from the
> application's source tree. First step in Discovery; populates the application-detail page.

`outputs.side_effects[0]` (`discovery.yaml:61-70`):
- `target`: `application` (`discovery.yaml:62`)
- `fields` (7, in order, `discovery.yaml:63-70`):
  1. `description`
  2. `architecture.archetype`
  3. `tech_stack`
  4. `business_domain`
  5. `size_metrics`
  6. `complexity_tier`
  7. `safety_tier`

⚠️ GOTCHA: `catalog` is the ONLY agent step whose `inputs.artifacts` is empty (`[]`) — it is
the head of the line and consumes only context (the cloned source + CMDB + docs). Its output
`tech-fingerprint` is what `discovery_patterns_router` later keys on to route the structural
specialist (see Step 2 purpose).

---

### STEP 2 — `structural-analysis` (`discovery.yaml:83-156`)

| Field | Value | Cite |
|-------|-------|------|
| `id` | `structural-analysis` | `discovery.yaml:83` |
| `label` | `Application & Data Mapping` | `discovery.yaml:84` |
| `kind` | `agent` | `discovery.yaml:85` |
| `scope` | `per-app` | `discovery.yaml:86` |
| `sequence` | `2` | `discovery.yaml:87` |
| `progress_pct` | `25` | `discovery.yaml:88` |
| `progress_weight` | `15` | `discovery.yaml:89` |
| `artifact_filename` | `structural-analysis.json` | `discovery.yaml:90` |
| `purpose` | folded block scalar w/ embedded `#` comments (verbatim below) | `discovery.yaml:91-117` |
| `skills` | 13-element block list (below) | `discovery.yaml:118-131` |
| `agent_role` | `Analysis Agent` | `discovery.yaml:132` |
| `inputs.artifacts` | `[application-catalog-entry, tech-fingerprint]` | `discovery.yaml:134` |
| `inputs.context` | `[source-repo-clone]` | `discovery.yaml:135` |
| `outputs.artifacts` | `[structural-analysis, database-schema-summary, interface-inventory]` | `discovery.yaml:137-140` |
| `outputs.side_effects` | one entry, target `application` (below) | `discovery.yaml:141-145` |
| `agent_contract.mcp_servers` | `[olympus]` | `discovery.yaml:147` |
| `agent_contract.repos.artifact` | `rw` | `discovery.yaml:149` |
| `agent_contract.repos.source` | `ro` | `discovery.yaml:150` |
| `agent_contract.repos.target` | `none` | `discovery.yaml:151` |
| `parallel_with` | `[]` (empty) | `discovery.yaml:152` |
| `gate` | `null` | `discovery.yaml:153` |
| `retry_policy.category` | `agent_failure` | `discovery.yaml:154` |
| `retry_policy.non_retryable_errors` | `[SchemaValidationError]` | `discovery.yaml:155` |

`purpose` verbatim (`discovery.yaml:91-104`, the folded prose portion):
> Map the application's architecture: modules, components, call graphs, database schema,
> external interfaces, configuration, and deployment topology. The module/component map
> produced here defines the decomposition boundaries used by every downstream pass and by the
> Modernization line's Extract step. `legacy-architecture-mapper` produces the generic
> structural skeleton; conditional tech-stack specialists (`discovery-patterns-*`) augment it
> with idiom-specific findings (mainframe, oracle, sqlserver, dotnet, doc-only). Dispatch of
> the tech-stack specialist is runtime-routed by
> `olympus_workflows.workflows.discovery_patterns_router` based on the `tech_fingerprint`
> emitted by `catalog-application`; when no specialist matches, the generic
> `discovery-patterns` base runs.

`purpose` embedded `#` comment block (`discovery.yaml:105-117`) — preserved verbatim because
it documents the Stage 8 ATLAS deep-analysis helpers and the conditional `tiff-corpus-assessor`:
> Stage 8 ATLAS integration (2026-05-06): Pass 1 expanded with deep-analysis helpers —
> legacy-language-reader (shared language-detection + reader-dispatch manifest),
> legacy-database-archaeologist (stored-proc classification, shadow schemas, ADABAS DDMs, EOL
> engines, cross-app schema sharing), legacy-data-flow-tracer (per-app data-element lifecycle
> tracing for cross-system chains), identity-landscape-analyzer (portfolio-scope NIST 800-63
> identity inventory), compliance-citation-mapper (regex-driven USC/CFR/PL/FR/EO/agency-order
> citation scan), and tiff-corpus-assessor (conditional — fires only when the application
> catalog sets `has_image_corpus: true`; workflow-level dispatch routing arrives in Stage 11).

`skills` — 13 elements, in exact order (`discovery.yaml:118-131`):
1. `legacy-architecture-mapper` (`:119`)
2. `legacy-language-reader` (`:120`)
3. `legacy-database-archaeologist` (`:121`)
4. `legacy-data-flow-tracer` (`:122`)
5. `identity-landscape-analyzer` (`:123`)
6. `compliance-citation-mapper` (`:124`)
7. `tiff-corpus-assessor` (`:125`)
8. `discovery-patterns` (`:126`)
9. `discovery-patterns-mainframe` (`:127`)
10. `discovery-patterns-oracle` (`:128`)
11. `discovery-patterns-sqlserver` (`:129`)
12. `discovery-patterns-dotnet` (`:130`)
13. `discovery-patterns-doc-only` (`:131`)

`outputs.artifacts` (3, in order, `discovery.yaml:138-140`):
1. `structural-analysis`
2. `database-schema-summary`
3. `interface-inventory`

`outputs.side_effects[0]` (`discovery.yaml:141-145`):
- `target`: `application` (`discovery.yaml:142`)
- `fields` (2, in order, `discovery.yaml:144-145`):
  1. `architecture.major_components`
  2. `architecture.integrations`

⚠️ GOTCHA: The 13 `skills` are NOT all dispatched. Per the purpose: the
`discovery-patterns-*` family is mutually-exclusive runtime routing — exactly ONE of the
5 specialists OR the generic `discovery-patterns` base runs, selected by
`discovery_patterns_router` keyed on `tech_fingerprint`. `tiff-corpus-assessor` fires ONLY
when the catalog sets `has_image_corpus: true` (workflow dispatch routing was deferred to
Stage 11). The skill list is the *available* set, not the guaranteed-executed set.

⚠️ GOTCHA: `structural-analysis` emits `database-schema-summary` and `interface-inventory`
as artifacts that downstream sequence-3 passes consume (e.g. `data-domain-discovery`,
`shared-database-analysis`, `business-logic-extraction` read `database-schema-summary`;
`ux-accessibility-assessment` reads `interface-inventory`). These artifacts are NOT in the
line-level `outputs` list — losing them breaks the fan-out cluster's inputs.

---

### STEP 3 — `business-logic-extraction` (`discovery.yaml:158-200`)

| Field | Value | Cite |
|-------|-------|------|
| `id` | `business-logic-extraction` | `discovery.yaml:158` |
| `label` | `Business Logic Extraction` | `discovery.yaml:159` |
| `kind` | `agent` | `discovery.yaml:160` |
| `scope` | `per-app` | `discovery.yaml:161` |
| `sequence` | `3` | `discovery.yaml:162` |
| `progress_pct` | `35` | `discovery.yaml:163` |
| `progress_weight` | `10` | `discovery.yaml:164` |
| `artifact_filename` | `business-logic.json` | `discovery.yaml:165` |
| `purpose` | folded block scalar (verbatim below) | `discovery.yaml:166-169` |
| `skills` | `[legacy-business-rule-extractor]` | `discovery.yaml:170` |
| `agent_role` | `Business Logic Extractor` | `discovery.yaml:171` |
| `inputs.artifacts` | `[structural-analysis, database-schema-summary]` | `discovery.yaml:173` |
| `inputs.context` | `[source-repo-clone, regulatory-knowledge-base]` | `discovery.yaml:174` |
| `outputs.artifacts` | `[business-logic, state-machines, implicit-logic]` | `discovery.yaml:176-179` |
| `outputs.side_effects` | one entry, target `application` (below) | `discovery.yaml:180-184` |
| `agent_contract.mcp_servers` | `[olympus]` | `discovery.yaml:186` |
| `agent_contract.repos.artifact` | `rw` | `discovery.yaml:188` |
| `agent_contract.repos.source` | `ro` | `discovery.yaml:189` |
| `agent_contract.repos.target` | `none` | `discovery.yaml:190` |
| `parallel_with` | 5-element list (below) | `discovery.yaml:191-196` |
| `gate` | `null` | `discovery.yaml:197` |
| `retry_policy.category` | `agent_failure` | `discovery.yaml:198` |
| `retry_policy.non_retryable_errors` | `[SchemaValidationError]` | `discovery.yaml:200` |

`purpose` verbatim (`discovery.yaml:166-169`):
> Extract explicit and implicit business rules, validation logic, workflows, state machines,
> and edge cases from the legacy source. Includes regulatory traceability where a compliance
> profile applies.

`outputs.artifacts` (3, in order, `discovery.yaml:177-179`):
1. `business-logic`
2. `state-machines`
3. `implicit-logic`

`outputs.side_effects[0]` (`discovery.yaml:180-184`):
- `target`: `application` (`discovery.yaml:181`)
- `fields` (2, in order, `discovery.yaml:183-184`):
  1. `business_logic.rule_count`
  2. `business_logic.critical_rules_count`

`parallel_with` (5, in order, `discovery.yaml:192-196`):
1. `quality-risk-assessment`
2. `ux-accessibility-assessment`
3. `data-domain-discovery`
4. `shared-database-analysis`
5. `capability-extraction`

---

### STEP 4 — `quality-risk-assessment` (`discovery.yaml:202-244`)

| Field | Value | Cite |
|-------|-------|------|
| `id` | `quality-risk-assessment` | `discovery.yaml:202` |
| `label` | `Quality & Risk Assessment` | `discovery.yaml:203` |
| `kind` | `agent` | `discovery.yaml:204` |
| `scope` | `per-app` | `discovery.yaml:205` |
| `sequence` | `3` | `discovery.yaml:206` |
| `progress_pct` | `35` | `discovery.yaml:207` |
| `progress_weight` | `10` | `discovery.yaml:208` |
| `artifact_filename` | `quality-risk.json` | `discovery.yaml:209` |
| `purpose` | folded block scalar (verbatim below) | `discovery.yaml:210-213` |
| `skills` | `[quality-risk-assessor]` | `discovery.yaml:214` |
| `agent_role` | `Analysis Agent` | `discovery.yaml:215` |
| `inputs.artifacts` | `[structural-analysis]` | `discovery.yaml:217` |
| `inputs.context` | `[source-repo-clone, dependency-manifests, sca-output]` | `discovery.yaml:218` |
| `outputs.artifacts` | `[quality-risk]` | `discovery.yaml:220` |
| `outputs.side_effects` | one entry, target `application` (below) | `discovery.yaml:221-228` |
| `agent_contract.mcp_servers` | `[olympus]` | `discovery.yaml:230` |
| `agent_contract.repos.artifact` | `rw` | `discovery.yaml:232` |
| `agent_contract.repos.source` | `ro` | `discovery.yaml:233` |
| `agent_contract.repos.target` | `none` | `discovery.yaml:234` |
| `parallel_with` | 5-element list (below) | `discovery.yaml:235-240` |
| `gate` | `null` | `discovery.yaml:241` |
| `retry_policy.category` | `agent_failure` | `discovery.yaml:242` |
| `retry_policy.non_retryable_errors` | `[SchemaValidationError]` | `discovery.yaml:244` |

`purpose` verbatim (`discovery.yaml:210-213`):
> Score technical debt, identify CVEs, measure test-coverage gaps, catalogue code-quality
> smells, and produce a rolled-up risk summary. Feeds Rationalization's risk scoring.

`outputs.side_effects[0]` (`discovery.yaml:221-228`):
- `target`: `application` (`discovery.yaml:222`)
- `fields` (5, in order, `discovery.yaml:224-228`):
  1. `quality.technical_debt_score`
  2. `quality.test_coverage`
  3. `quality.vulnerabilities_summary`
  4. `quality.code_smells_summary`
  5. `risk_tier`

`parallel_with` (5, in order, `discovery.yaml:236-240`):
1. `business-logic-extraction`
2. `ux-accessibility-assessment`
3. `data-domain-discovery`
4. `shared-database-analysis`
5. `capability-extraction`

⚠️ GOTCHA: The 5th side-effect field is `risk_tier` (top-level on the application record),
NOT under the `quality.` namespace — it is a sibling of `quality.*`, not nested. This feeds
Rationalization's risk scoring directly.

---

### STEP 5 — `ux-accessibility-assessment` (`discovery.yaml:246-289`)

| Field | Value | Cite |
|-------|-------|------|
| `id` | `ux-accessibility-assessment` | `discovery.yaml:246` |
| `label` | `UX & Accessibility Assessment` | `discovery.yaml:247` |
| `kind` | `agent` | `discovery.yaml:248` |
| `scope` | `per-app` | `discovery.yaml:249` |
| `sequence` | `3` | `discovery.yaml:250` |
| `progress_pct` | `35` | `discovery.yaml:251` |
| `progress_weight` | `10` | `discovery.yaml:252` |
| `artifact_filename` | `ux-accessibility.json` | `discovery.yaml:253` |
| `purpose` | folded block scalar (verbatim below) | `discovery.yaml:254-258` |
| `skills` | `[ux-accessibility-assessor]` | `discovery.yaml:259` |
| `agent_role` | `UX Journey Analyzer` | `discovery.yaml:260` |
| `inputs.artifacts` | `[structural-analysis, interface-inventory]` | `discovery.yaml:262` |
| `inputs.context` | `[source-repo-clone, usage-telemetry, training-inventory, support-tickets]` | `discovery.yaml:263` |
| `outputs.artifacts` | `[ux-accessibility]` | `discovery.yaml:265` |
| `outputs.side_effects` | one entry, target `application` (below) | `discovery.yaml:266-273` |
| `agent_contract.mcp_servers` | `[olympus]` | `discovery.yaml:275` |
| `agent_contract.repos.artifact` | `rw` | `discovery.yaml:277` |
| `agent_contract.repos.source` | `ro` | `discovery.yaml:278` |
| `agent_contract.repos.target` | `none` | `discovery.yaml:279` |
| `parallel_with` | 5-element list (below) | `discovery.yaml:280-285` |
| `gate` | `null` | `discovery.yaml:286` |
| `retry_policy.category` | `agent_failure` | `discovery.yaml:287` |
| `retry_policy.non_retryable_errors` | `[SchemaValidationError]` | `discovery.yaml:289` |

`purpose` verbatim (`discovery.yaml:254-258`):
> Capture who uses the system, how they use it, current adoption and training state, and
> where the UI fails Section 508 / WCAG 2.1 AA. Composes with accessibility-checker for
> automated WCAG audit. This is the baseline adoption-analytics compares against
> post-cutover.

`outputs.side_effects[0]` (`discovery.yaml:266-273`):
- `target`: `application` (`discovery.yaml:267`)
- `fields` (5, in order, `discovery.yaml:269-273`):
  1. `ux.personas_count`
  2. `ux.adoption_baseline_summary`
  3. `ux.accessibility_score`
  4. `ux.ui_inventory_summary`
  5. `ux.ui_complexity_score`

`parallel_with` (5, in order, `discovery.yaml:281-285`):
1. `business-logic-extraction`
2. `quality-risk-assessment`
3. `data-domain-discovery`
4. `shared-database-analysis`
5. `capability-extraction`

⚠️ GOTCHA: The purpose names `accessibility-checker` as a composed skill, but the step's
`skills` list contains ONLY `[ux-accessibility-assessor]` (`discovery.yaml:259`). The
composition is internal to `ux-accessibility-assessor` (it invokes the checker), not a
declared step-level skill. Do not add `accessibility-checker` to the step `skills` list.

---

### STEP 6 — `data-domain-discovery` (`discovery.yaml:291-336`)

| Field | Value | Cite |
|-------|-------|------|
| `id` | `data-domain-discovery` | `discovery.yaml:291` |
| `label` | `Data Domain Discovery` | `discovery.yaml:292` |
| `kind` | `agent` | `discovery.yaml:293` |
| `scope` | `per-app` | `discovery.yaml:294` |
| `sequence` | `3` | `discovery.yaml:295` |
| `progress_pct` | `35` | `discovery.yaml:296` |
| `progress_weight` | `5` | `discovery.yaml:297` |
| `artifact_filename` | `data-domains.json` | `discovery.yaml:298` |
| `purpose` | folded block scalar (verbatim below) | `discovery.yaml:299-309` |
| `skills` | `[data-domain-patterns]` | `discovery.yaml:310` |
| `agent_role` | `Data Landscape Analyst` | `discovery.yaml:311` |
| `inputs.artifacts` | `[structural-analysis, database-schema-summary]` | `discovery.yaml:313-315` |
| `inputs.context` | `[source-repo-clone]` | `discovery.yaml:316-317` |
| `outputs.artifacts` | `[data-domains]` | `discovery.yaml:319` |
| `outputs.side_effects` | `[]` (empty) | `discovery.yaml:320` |
| `agent_contract.mcp_servers` | `[olympus]` | `discovery.yaml:322` |
| `agent_contract.repos.artifact` | `rw` | `discovery.yaml:324` |
| `agent_contract.repos.source` | `ro` | `discovery.yaml:325` |
| `agent_contract.repos.target` | `none` | `discovery.yaml:326` |
| `parallel_with` | 5-element list (below) | `discovery.yaml:327-332` |
| `gate` | `null` | `discovery.yaml:333` |
| `retry_policy.category` | `agent_failure` | `discovery.yaml:334` |
| `retry_policy.non_retryable_errors` | `[SchemaValidationError]` | `discovery.yaml:336` |

`purpose` verbatim (`discovery.yaml:299-309`):
> Discovery-line pass that catalogs the application's existing data domains — logical
> groupings of entities that change together, are queried together, and share an ownership /
> lifecycle boundary. Produces a descriptive map of "what data domains does this app actually
> carry today?" which feeds Rationalization's cross-app redundancy matrix (shared
> identifiers, overlapping domains) and is refined later by the Data line's own
> `domain-discovery` step on the target application. This is a Discovery pass — it describes
> the legacy landscape; it does NOT design the target-state domain model.

`outputs.side_effects` = `[]` (empty list, `discovery.yaml:320`).

`parallel_with` (5, in order, `discovery.yaml:328-332`):
1. `business-logic-extraction`
2. `quality-risk-assessment`
3. `ux-accessibility-assessment`
4. `shared-database-analysis`
5. `capability-extraction`

⚠️ GOTCHA: Unlike Step 6's analog in the Data line, this Discovery pass has NO side effects
(`side_effects: []`) — it is purely descriptive and writes only its `data-domains` artifact.
It does NOT touch the application record. (Contrast Step 9 `capability-extraction`, which
DOES persist rows.)

---

### STEP 7 — `shared-database-analysis` (`discovery.yaml:338-383`)

| Field | Value | Cite |
|-------|-------|------|
| `id` | `shared-database-analysis` | `discovery.yaml:338` |
| `label` | `Shared Database Analysis` | `discovery.yaml:339` |
| `kind` | `agent` | `discovery.yaml:340` |
| `scope` | `per-app` | `discovery.yaml:341` |
| `sequence` | `3` | `discovery.yaml:342` |
| `progress_pct` | `35` | `discovery.yaml:343` |
| `progress_weight` | `5` | `discovery.yaml:344` |
| `artifact_filename` | `shared-db-analysis.json` | `discovery.yaml:345` |
| `purpose` | folded block scalar (verbatim below) | `discovery.yaml:346-356` |
| `skills` | `[decomposition-patterns]` | `discovery.yaml:357` |
| `agent_role` | `Data Landscape Analyst` | `discovery.yaml:358` |
| `inputs.artifacts` | `[structural-analysis, database-schema-summary]` | `discovery.yaml:360-362` |
| `inputs.context` | `[source-repo-clone]` | `discovery.yaml:363-364` |
| `outputs.artifacts` | `[shared-db-analysis]` | `discovery.yaml:366` |
| `outputs.side_effects` | `[]` (empty) | `discovery.yaml:367` |
| `agent_contract.mcp_servers` | `[olympus]` | `discovery.yaml:369` |
| `agent_contract.repos.artifact` | `rw` | `discovery.yaml:371` |
| `agent_contract.repos.source` | `ro` | `discovery.yaml:372` |
| `agent_contract.repos.target` | `none` | `discovery.yaml:373` |
| `parallel_with` | 5-element list (below) | `discovery.yaml:374-379` |
| `gate` | `null` | `discovery.yaml:380` |
| `retry_policy.category` | `agent_failure` | `discovery.yaml:381` |
| `retry_policy.non_retryable_errors` | `[SchemaValidationError]` | `discovery.yaml:383` |

`purpose` verbatim (`discovery.yaml:346-356`):
> Discovery-line pass that catalogs the application's participation in shared database
> clusters as observed today: which tables it reads / writes / owns, which other apps likely
> share the same tables (based on schema evidence), stored-procedure / trigger / DB-link
> entanglement, and coupling severity. Produces the application's descriptive perspective on
> the shared-DB landscape, which feeds Rationalization's redundancy + dependency analysis.
> Refined later by the Data line's own `shared-db-analysis` step on the target application —
> Data inherits this artifact as input so it refines rather than re-discovers.

`outputs.side_effects` = `[]` (empty list, `discovery.yaml:367`).

`parallel_with` (5, in order, `discovery.yaml:375-379`):
1. `business-logic-extraction`
2. `quality-risk-assessment`
3. `ux-accessibility-assessment`
4. `data-domain-discovery`
5. `capability-extraction`

⚠️ GOTCHA: Skill is `decomposition-patterns` (`discovery.yaml:357`) — NOT a "shared-db"-named
skill. The Shared Database Analysis pass reuses the decomposition-patterns skill. Also, like
Step 6, `side_effects: []` — descriptive artifact only.

---

### STEP 8 — `capability-extraction` (`discovery.yaml:385-442`)

| Field | Value | Cite |
|-------|-------|------|
| `id` | `capability-extraction` | `discovery.yaml:385` |
| `label` | `Capability + System Grain` | `discovery.yaml:386` |
| `kind` | `agent` | `discovery.yaml:387` |
| `scope` | `per-app` | `discovery.yaml:388` |
| `sequence` | `3` | `discovery.yaml:389` |
| `progress_pct` | `35` | `discovery.yaml:390` |
| `progress_weight` | `5` | `discovery.yaml:391` |
| `artifact_filename` | `capability-catalog.json` | `discovery.yaml:392` |
| `purpose` | folded block scalar (verbatim below) | `discovery.yaml:393-406` |
| `skills` | `[capability-extraction]` | `discovery.yaml:407` |
| `agent_role` | `Analysis Agent` | `discovery.yaml:408` |
| `inputs.artifacts` | `[application-catalog-entry, structural-analysis, data-domains, interface-inventory]` | `discovery.yaml:410-414` |
| `inputs.context` | `[source-repo-clone, client-profile]` | `discovery.yaml:415-417` |
| `outputs.artifacts` | `[capability-catalog]` | `discovery.yaml:419` |
| `outputs.side_effects` | one entry, target `legacy_system_grain` (below) | `discovery.yaml:420-426` |
| `agent_contract.mcp_servers` | `[olympus]` | `discovery.yaml:428` |
| `agent_contract.repos.artifact` | `rw` | `discovery.yaml:430` |
| `agent_contract.repos.source` | `ro` | `discovery.yaml:431` |
| `agent_contract.repos.target` | `none` | `discovery.yaml:432` |
| `parallel_with` | 5-element list (below) | `discovery.yaml:433-438` |
| `gate` | `null` | `discovery.yaml:439` |
| `retry_policy.category` | `agent_failure` | `discovery.yaml:440` |
| `retry_policy.non_retryable_errors` | `[SchemaValidationError]` | `discovery.yaml:442` |

`purpose` verbatim (`discovery.yaml:393-406`):
> Discovery-line pass that extracts the capability + business-domain + legacy-system grain for
> a single application from already-discovered artifacts. Runs in the sequence-3 parallel
> cluster alongside the other passes; emits a structured ``capability-catalog.json`` artifact
> that the Discovery persist activity UPSERTs into the ``business_domain``, ``capability``
> (kind=legacy), ``system`` (kind=legacy), ``system_application``, and
> ``capability_business_domain`` tables. This is the source of truth Rationalization reads
> from when proposing target-state consolidation; without it the rationalization recommender
> has no FK-grounded grain to consolidate. Replaces the one-shot
> ``seed_capability_system_backfill.py`` script — Discovery is now the writer.

`inputs.artifacts` (4, in order, `discovery.yaml:411-414`):
1. `application-catalog-entry`
2. `structural-analysis`
3. `data-domains`
4. `interface-inventory`

`inputs.context` (2, in order, `discovery.yaml:416-417`):
1. `source-repo-clone`
2. `client-profile`

`outputs.side_effects[0]` (`discovery.yaml:420-426`):
- `target`: `legacy_system_grain` (`discovery.yaml:421`)
- `fields` (4, in order, `discovery.yaml:423-426`):
  1. `business_domain_rows`
  2. `capability_rows`
  3. `system_row`
  4. `system_application_row`

`parallel_with` (5, in order, `discovery.yaml:434-438`):
1. `business-logic-extraction`
2. `quality-risk-assessment`
3. `ux-accessibility-assessment`
4. `data-domain-discovery`
5. `shared-database-analysis`

⚠️ GOTCHA: This is the ONLY sequence-3 pass with side effects, and its `target` is the
**special `legacy_system_grain`** sink (`discovery.yaml:421`), NOT `application`. The
side-effect `fields` are row-set names (`business_domain_rows`, `capability_rows`,
`system_row`, `system_application_row`) that the Discovery persist activity UPSERTs into FIVE
tables named in the purpose: `business_domain`, `capability` (kind=legacy), `system`
(kind=legacy), `system_application`, and `capability_business_domain`. The five-table write
is documented in the purpose but the side-effect `fields` list only enumerates four
row-groups — the `capability_business_domain` join rows are implied by the persist activity,
not a separate field. Preserve both the table list (purpose) and the field list.

⚠️ GOTCHA (input dependency): `capability-extraction` reads `data-domains`
(`discovery.yaml:413`) — an artifact produced by Step 6 (`data-domain-discovery`), which runs
in the SAME sequence-3 parallel cluster and lists `capability-extraction` in its
`parallel_with`. This is a logical intra-cluster data dependency despite both being declared
"parallel". The workflow must ensure `data-domains` exists before/at-input to
`capability-extraction`; treat `parallel_with` as eligibility for concurrency, not a
guarantee of zero ordering constraints. The line author chose to keep them in one cluster
and let the artifact-availability gate the consumer.

---

### STEP 9 — `synthesis` (`discovery.yaml:444-488`)

| Field | Value | Cite |
|-------|-------|------|
| `id` | `synthesis` | `discovery.yaml:444` |
| `label` | `Discovery Synthesis` | `discovery.yaml:445` |
| `kind` | `agent` | `discovery.yaml:446` |
| `scope` | `per-app` | `discovery.yaml:447` |
| `sequence` | `4` | `discovery.yaml:448` |
| `progress_pct` | `65` | `discovery.yaml:449` |
| `progress_weight` | `10` | `discovery.yaml:450` |
| `artifact_filename` | `synthesis.json` | `discovery.yaml:451` |
| `summary` | `true` | `discovery.yaml:452` |
| `purpose` | folded block scalar w/ embedded `#` comment (verbatim below) | `discovery.yaml:453-462` |
| `skills` | `[discovery-synthesizer, srs-from-discovery]` | `discovery.yaml:463` |
| `agent_role` | `Synthesis Agent` | `discovery.yaml:464` |
| `inputs.artifacts` | 7-element list (below) | `discovery.yaml:466-473` |
| `inputs.context` | `[]` (empty) | `discovery.yaml:474` |
| `outputs.artifacts` | `[discovery-synthesis]` | `discovery.yaml:476` |
| `outputs.side_effects` | `[]` (empty) | `discovery.yaml:477` |
| `agent_contract.mcp_servers` | `[olympus]` | `discovery.yaml:479` |
| `agent_contract.repos.artifact` | `rw` | `discovery.yaml:481` |
| `agent_contract.repos.source` | `ro` | `discovery.yaml:482` |
| `agent_contract.repos.target` | `none` | `discovery.yaml:483` |
| `parallel_with` | `[tco-baseline]` | `discovery.yaml:484` |
| `gate` | `null` | `discovery.yaml:485` |
| `retry_policy.category` | `agent_failure` | `discovery.yaml:486` |
| `retry_policy.non_retryable_errors` | `[SchemaValidationError]` | `discovery.yaml:488` |

`purpose` verbatim folded prose (`discovery.yaml:453-458`):
> Merge the four Discovery pass outputs into a consolidated digest. Reconciles contradictions,
> scores per-finding confidence, and produces the Discovery output set that Rationalization
> and Modernization's Extract step consume as authoritative. Rendered first in gate review as
> the reviewer-facing summary of the whole line.

`purpose` embedded `#` comment (`discovery.yaml:459-462`) — preserved verbatim:
> Stage 8 ATLAS integration (2026-05-06): terminal rollup also dispatches srs-from-discovery
> to transform descriptive Discovery findings into a prescriptive SRS, bridging Discovery →
> Architecture/Modernization before G-DC.

`inputs.artifacts` (7, in order, `discovery.yaml:467-473`):
1. `structural-analysis`
2. `business-logic`
3. `quality-risk`
4. `ux-accessibility`
5. `data-domains`
6. `shared-db-analysis`
7. `capability-catalog`

`outputs.side_effects` = `[]` (empty list, `discovery.yaml:477`).

⚠️ GOTCHA: This is the ONLY step with `summary: true` (`discovery.yaml:452`). That flag marks
it as the reviewer-facing rollup rendered FIRST in gate review (per purpose). Do not omit it.

⚠️ GOTCHA: The purpose says "Merge the **four** Discovery pass outputs" but `inputs.artifacts`
lists **seven** artifacts (`discovery.yaml:467-473`). The "four" is stale prose from before
the data-domains / shared-db / capability passes were added; the authoritative input set is
the 7-element list. Reproduce the 7-element list, not "four".

⚠️ GOTCHA: `skills` has TWO entries (`discovery.yaml:463`): `discovery-synthesizer` (the merge)
and `srs-from-discovery` (the Stage-8 SRS bridge that runs in this terminal rollup). Both are
dispatched here; `srs-from-discovery` transforms descriptive findings into a prescriptive SRS
before G-DC. Do not drop the second skill.

---

### STEP 10 — `tco-baseline` (`discovery.yaml:490-531`)

| Field | Value | Cite |
|-------|-------|------|
| `id` | `tco-baseline` | `discovery.yaml:490` |
| `label` | `TCO Baseline` | `discovery.yaml:491` |
| `kind` | `agent` | `discovery.yaml:492` |
| `scope` | `per-app` | `discovery.yaml:493` |
| `sequence` | `4` | `discovery.yaml:494` |
| `progress_pct` | `65` | `discovery.yaml:495` |
| `progress_weight` | `10` | `discovery.yaml:496` |
| `artifact_filename` | `tco-baseline.json` | `discovery.yaml:497` |
| `purpose` | folded block scalar (verbatim below) | `discovery.yaml:498-502` |
| `skills` | `[tco-analyzer]` | `discovery.yaml:503` |
| `agent_role` | `TCO Analyzer` | `discovery.yaml:504` |
| `inputs.artifacts` | `[application-catalog-entry, structural-analysis]` | `discovery.yaml:506` |
| `inputs.context` | `[source-repo-clone, cost-context-bundle, client-profile]` | `discovery.yaml:507-510` |
| `outputs.artifacts` | `[tco-baseline]` | `discovery.yaml:512` |
| `outputs.side_effects` | one entry, target `application` (below) | `discovery.yaml:513-520` |
| `agent_contract.mcp_servers` | `[olympus]` | `discovery.yaml:522` |
| `agent_contract.repos.artifact` | `rw` | `discovery.yaml:524` |
| `agent_contract.repos.source` | `ro` | `discovery.yaml:525` |
| `agent_contract.repos.target` | `none` | `discovery.yaml:526` |
| `parallel_with` | `[synthesis]` | `discovery.yaml:527` |
| `gate` | `null` | `discovery.yaml:528` |
| `retry_policy.category` | `agent_failure` | `discovery.yaml:529` |
| `retry_policy.non_retryable_errors` | `[SchemaValidationError]` | `discovery.yaml:531` |

`purpose` verbatim (`discovery.yaml:498-502`):
> Establish the per-application TCO baseline following the client profile's cost formula.
> Best-effort when a cost-context bundle is not supplied at onboarding — in that case the
> skill infers from code/IaC/repo signals and flags low confidence for gate review.

`inputs.context` (3, in order, `discovery.yaml:508-510`):
1. `source-repo-clone`
2. `cost-context-bundle`
3. `client-profile`

`outputs.side_effects[0]` (`discovery.yaml:513-520`):
- `target`: `application` (`discovery.yaml:514`)
- `fields` (5, in order, `discovery.yaml:516-520`):
  1. `tco.annual_total`
  2. `tco.breakdown`
  3. `tco.formula_applied`
  4. `tco.confidence`
  5. `tco.data_sources`

⚠️ GOTCHA: `tco-baseline` and `synthesis` are mutually `parallel_with` each other
(`discovery.yaml:484` and `:527`) — the sequence-4 two-way fan-out. `tco-baseline` is
"best-effort": when `cost-context-bundle` is absent the skill infers from code/IaC/repo
signals and sets `tco.confidence` low for gate review (per purpose). The step never hard-fails
on missing cost context — that's encoded behaviorally in the skill, but the contract exposes
`tco.confidence` as the field that carries the low-confidence flag.

---

### STEP 11 — `commit-artifacts` (`discovery.yaml:533-575`)

| Field | Value | Cite |
|-------|-------|------|
| `id` | `commit-artifacts` | `discovery.yaml:533` |
| `label` | `Commit Artifacts` | `discovery.yaml:534` |
| `kind` | `git` | `discovery.yaml:535` |
| `scope` | `per-app` | `discovery.yaml:536` |
| `sequence` | `5` | `discovery.yaml:537` |
| `progress_pct` | `75` | `discovery.yaml:538` |
| `progress_weight` | `5` | `discovery.yaml:539` |
| `purpose` | folded block scalar (verbatim below) | `discovery.yaml:540-543` |
| `skills` | `[]` (empty) | `discovery.yaml:544` |
| `agent_role` | `null` | `discovery.yaml:545` |
| `inputs.artifacts` | 10-element list (below) | `discovery.yaml:547-557` |
| `inputs.context` | `[]` (empty) | `discovery.yaml:558` |
| `outputs.artifacts` | `[]` (empty) | `discovery.yaml:560` |
| `outputs.side_effects` | two entries (below) | `discovery.yaml:561-565` |
| `agent_contract.mcp_servers` | `[]` (empty) | `discovery.yaml:567` |
| `agent_contract.repos.artifact` | `rw` | `discovery.yaml:569` |
| `agent_contract.repos.source` | `none` | `discovery.yaml:570` |
| `agent_contract.repos.target` | `none` | `discovery.yaml:571` |
| `parallel_with` | `[]` (empty) | `discovery.yaml:572` |
| `gate` | `null` | `discovery.yaml:573` |
| `retry_policy.category` | `transient` | `discovery.yaml:575` |

`purpose` verbatim (`discovery.yaml:540-543`):
> Commit all Discovery artifacts to the per-task branch in the portfolio's artifact repo. Also
> projects the decomposition map onto the application record so the insights UI can render it.

`inputs.artifacts` (10, in order, `discovery.yaml:548-557`):
1. `application-catalog-entry`
2. `structural-analysis`
3. `business-logic`
4. `quality-risk`
5. `ux-accessibility`
6. `data-domains`
7. `shared-db-analysis`
8. `capability-catalog`
9. `discovery-synthesis`
10. `tco-baseline`

`outputs.side_effects` — TWO entries:
- `side_effects[0]` (`discovery.yaml:562-563`):
  - `target`: `artifact-repo` (`discovery.yaml:562`)
  - `fields` (2, in order, `discovery.yaml:563`): `branch_created`, `artifacts_committed`
- `side_effects[1]` (`discovery.yaml:564-565`):
  - `target`: `application` (`discovery.yaml:564`)
  - `fields` (1, `discovery.yaml:565`): `decomposition_map`

⚠️ GOTCHA: `kind: git` step — `agent_role: null`, `skills: []`, `mcp_servers: []`, and
`retry_policy` has ONLY `category: transient` (NO `non_retryable_errors` key —
`discovery.yaml:574-575`). Git steps use the `transient` retry category (retry on transient
git/network failures) rather than `agent_failure`. Do not add `non_retryable_errors` to git
steps.

⚠️ GOTCHA: `repos.source: none` here (`discovery.yaml:570`) — unlike all agent steps which
have `source: ro`. The commit step does not touch the source repo, only the artifact repo
(`artifact: rw`).

⚠️ GOTCHA: The 10-artifact `inputs.artifacts` list is the union of the LINE-LEVEL outputs (the
11-item line `outputs` minus `tech-fingerprint`, which is folded into the catalog entry). It
intentionally excludes the intermediate hand-off artifacts (`database-schema-summary`,
`interface-inventory`, `state-machines`, `implicit-logic`). Reproduce exactly these 10.

---

### STEP 12 — `create-pr` (`discovery.yaml:577-609`)

| Field | Value | Cite |
|-------|-------|------|
| `id` | `create-pr` | `discovery.yaml:577` |
| `label` | `Create Gate PR` | `discovery.yaml:578` |
| `kind` | `git` | `discovery.yaml:579` |
| `scope` | `per-app` | `discovery.yaml:580` |
| `sequence` | `6` | `discovery.yaml:581` |
| `progress_pct` | `80` | `discovery.yaml:582` |
| `progress_weight` | `5` | `discovery.yaml:583` |
| `purpose` | folded block scalar (verbatim below) | `discovery.yaml:584-587` |
| `skills` | `[]` (empty) | `discovery.yaml:588` |
| `agent_role` | `null` | `discovery.yaml:589` |
| `inputs.artifacts` | `[]` (empty) | `discovery.yaml:591` |
| `inputs.context` | `[git-branch]` | `discovery.yaml:592` |
| `outputs.artifacts` | `[]` (empty) | `discovery.yaml:594` |
| `outputs.side_effects` | two entries (below) | `discovery.yaml:595-599` |
| `agent_contract.mcp_servers` | `[]` (empty) | `discovery.yaml:601` |
| `agent_contract.repos.artifact` | `rw` | `discovery.yaml:603` |
| `agent_contract.repos.source` | `none` | `discovery.yaml:604` |
| `agent_contract.repos.target` | `none` | `discovery.yaml:605` |
| `parallel_with` | `[]` (empty) | `discovery.yaml:606` |
| `gate` | `null` | `discovery.yaml:607` |
| `retry_policy.category` | `transient` | `discovery.yaml:609` |

`purpose` verbatim (`discovery.yaml:584-587`):
> Open a pull request against the portfolio's artifact repo carrying every Discovery
> artifact. The PR is the vehicle for G-DC review and the long-term audit trail for this
> application's Discovery outputs.

`outputs.side_effects` — TWO entries:
- `side_effects[0]` (`discovery.yaml:596-597`):
  - `target`: `artifact-repo` (`discovery.yaml:596`)
  - `fields` (2, in order, `discovery.yaml:597`): `pr_url`, `pr_number`
- `side_effects[1]` (`discovery.yaml:598-599`):
  - `target`: `gate_record` (`discovery.yaml:598`)
  - `fields` (2, in order, `discovery.yaml:599`): `gate_id`, `evidence_package_url`

⚠️ GOTCHA: `kind: git`, `retry_policy.category: transient` with NO `non_retryable_errors`
(`discovery.yaml:608-609`). Same git-step shape as Step 11.

⚠️ GOTCHA: `inputs.context` is `[git-branch]` (`discovery.yaml:592`) — note the artifact ID is
`git-branch` here, while Step 11's side-effect field is `branch_created`. The PR step consumes
the branch produced by the commit step as a context input named `git-branch` (NOT
`branch_created`). These are distinct identifiers; do not unify them.

⚠️ GOTCHA: This step writes to the `gate_record` sink (`gate_id`, `evidence_package_url`) —
the PR creation is what stamps the gate record with its evidence package URL, priming G-DC.

---

### STEP 13 — `gate-readiness-check` (`discovery.yaml:611-645`)

| Field | Value | Cite |
|-------|-------|------|
| `id` | `gate-readiness-check` | `discovery.yaml:611` |
| `label` | `Gate Readiness Check` | `discovery.yaml:612` |
| `kind` | `agent` | `discovery.yaml:613` |
| `role` | `pre-review` | `discovery.yaml:614` |
| `scope` | `per-app` | `discovery.yaml:615` |
| `sequence` | `7` | `discovery.yaml:616` |
| `progress_pct` | `85` | `discovery.yaml:617` |
| `progress_weight` | `5` | `discovery.yaml:618` |
| `purpose` | folded block scalar (verbatim below) | `discovery.yaml:619-623` |
| `skills` | `[gate-pre-review]` | `discovery.yaml:624` |
| `agent_role` | `Pre-Review Agent` | `discovery.yaml:625` |
| `inputs.artifacts` | `[gate-packet]` | `discovery.yaml:627` |
| `inputs.context` | `[pr-url]` | `discovery.yaml:628` |
| `outputs.artifacts` | `[gate-readiness-check]` | `discovery.yaml:630` |
| `outputs.side_effects` | one entry, target `gate_record` (below) | `discovery.yaml:631-633` |
| `agent_contract.mcp_servers` | `[olympus]` | `discovery.yaml:635` |
| `agent_contract.repos.artifact` | `ro` | `discovery.yaml:637` |
| `agent_contract.repos.source` | `none` | `discovery.yaml:638` |
| `agent_contract.repos.target` | `none` | `discovery.yaml:639` |
| `parallel_with` | `[]` (empty) | `discovery.yaml:640` |
| `gate` | `null` | `discovery.yaml:641` |
| `retry_policy.category` | `agent_failure` | `discovery.yaml:643` |
| `retry_policy.non_retryable_errors` | `[SchemaValidationError]` | `discovery.yaml:644` |
| `retry_policy.max_attempts_override` | `1` | `discovery.yaml:645` |

`purpose` verbatim (`discovery.yaml:619-623`):
> Automated readiness check of the Discovery PR. Surfaces likely rejections (coverage gaps,
> traceability breaks, missing evidence) so humans only see PRs that meet the automated bar.
> Advisory — does not block. Single-attempt to avoid delaying gate review.

`outputs.side_effects[0]` (`discovery.yaml:631-633`):
- `target`: `gate_record` (`discovery.yaml:632`)
- `fields` (2, in order, `discovery.yaml:633`): `ai_pre_review_verdict`, `ai_pre_review_notes`

⚠️ GOTCHA: This is `kind: agent` BUT carries an extra top-level `role: pre-review`
(`discovery.yaml:614`) — the ONLY step with a `role` field distinct from `agent_role`. Both
exist: `role: pre-review` and `agent_role: Pre-Review Agent`. Reproduce both.

⚠️ GOTCHA: This is the ONLY step whose `retry_policy` carries `max_attempts_override: 1`
(`discovery.yaml:645`). It is single-attempt (advisory, must not delay gate review). The retry
block here has THREE keys: `category: agent_failure`, `non_retryable_errors:
[SchemaValidationError]`, AND `max_attempts_override: 1`. Do not drop the override.

⚠️ GOTCHA: This agent step has `repos.artifact: ro` (`discovery.yaml:637`), NOT `rw` — it only
READS the gate packet/artifacts to render a verdict; it does not write artifacts. (Contrast all
the analysis agent steps with `artifact: rw`.) `source: none`, `target: none`.

⚠️ GOTCHA: Advisory — "does not block" (per purpose). The verdict (`ai_pre_review_verdict`) is
written to the gate record but does NOT gate the workflow; G-DC is decided by the human at Step
15. Do not wire this step as a blocking gate.

---

### STEP 14 — `gate-review` (`discovery.yaml:647-680`)

| Field | Value | Cite |
|-------|-------|------|
| `id` | `gate-review` | `discovery.yaml:647` |
| `label` | `Discovery Complete Gate` | `discovery.yaml:648` |
| `kind` | `gate` | `discovery.yaml:649` |
| `scope` | `per-app` | `discovery.yaml:650` |
| `sequence` | `8` | `discovery.yaml:651` |
| `progress_pct` | `90` | `discovery.yaml:652` |
| `progress_weight` | `10` | `discovery.yaml:653` |
| `purpose` | folded block scalar (verbatim below) | `discovery.yaml:654-657` |
| `skills` | `[]` (empty) | `discovery.yaml:658` |
| `agent_role` | `null` | `discovery.yaml:659` |
| `inputs.artifacts` | `[gate-packet, gate-readiness-check]` | `discovery.yaml:661` |
| `inputs.context` | `[]` (empty) | `discovery.yaml:662` |
| `outputs.artifacts` | `[gate-decision]` | `discovery.yaml:664` |
| `outputs.side_effects` | two entries (below) | `discovery.yaml:665-669` |
| `agent_contract.mcp_servers` | `[]` (empty) | `discovery.yaml:670` |
| `agent_contract.repos.artifact` | `rw` | `discovery.yaml:672` |
| `agent_contract.repos.source` | `none` | `discovery.yaml:673` |
| `agent_contract.repos.target` | `none` | `discovery.yaml:674` |
| `parallel_with` | `[]` (empty) | `discovery.yaml:676` |
| `gate` | `G-DC` | `discovery.yaml:677` |
| `retry_policy.category` | `validation_failure` | `discovery.yaml:679` |

`purpose` verbatim (`discovery.yaml:654-657`):
> Portfolio Manager signs off that this application is fully catalogued, analyzed, and ready
> to enter Rationalization. Blocks downstream lines until approved. Rejection carries rework
> feedback back into the passes.

`outputs.side_effects` — TWO entries:
- `side_effects[0]` (`discovery.yaml:666-667`):
  - `target`: `gate_record` (`discovery.yaml:666`)
  - `fields` (4, in order, `discovery.yaml:667`): `state`, `decided_at`, `decided_by`,
    `decision_notes`
- `side_effects[1]` (`discovery.yaml:668-669`):
  - `target`: `application` (`discovery.yaml:668`)
  - `fields` (2, in order, `discovery.yaml:669`): `discovery_status`, `discovery_completed_at`

⚠️ GOTCHA: This is the ONLY step with a non-null `gate` (`gate: G-DC`, `discovery.yaml:677`)
and the ONLY `kind: gate`. Its `retry_policy.category` is `validation_failure`
(`discovery.yaml:679`) — distinct from both `agent_failure` and `transient`, and it has NO
`non_retryable_errors` key. This is the human sign-off gate; it has `skills: []`,
`agent_role: null`, `mcp_servers: []`.

⚠️ GOTCHA: Despite being the human gate, `repos.artifact: rw` (`discovery.yaml:672`) — the gate
WRITES the `gate-decision` artifact into the artifact repo. `source: none`, `target: none`.

⚠️ GOTCHA: Rejection semantics: per purpose, rejection "carries rework feedback back into the
passes" — i.e., a rejected G-DC loops the application back to the sequence-3 passes for rework.
The contract captures the gate's terminal position (`sequence: 8`, `progress_pct: 90`) and the
two side-effect sinks (`gate_record`, `application`); the rework-loop behavior is workflow
logic keyed off the `state` field written here.

---

## 3. Parallelism / Sequencing Map (derived, for parity)

Reconstructed strictly from per-step `sequence` and `parallel_with` fields. No invented data.

| seq | step id | parallel cluster | cite |
|-----|---------|------------------|------|
| 1 | `catalog` | (solo) | `:46`, `:77` |
| 2 | `structural-analysis` | (solo) | `:87`, `:152` |
| 3 | `business-logic-extraction` | 6-way fan-out | `:162`, `:191-196` |
| 3 | `quality-risk-assessment` | 6-way fan-out | `:206`, `:235-240` |
| 3 | `ux-accessibility-assessment` | 6-way fan-out | `:250`, `:280-285` |
| 3 | `data-domain-discovery` | 6-way fan-out | `:295`, `:327-332` |
| 3 | `shared-database-analysis` | 6-way fan-out | `:342`, `:374-379` |
| 3 | `capability-extraction` | 6-way fan-out | `:389`, `:433-438` |
| 4 | `synthesis` | 2-way (w/ tco-baseline) | `:448`, `:484` |
| 4 | `tco-baseline` | 2-way (w/ synthesis) | `:494`, `:527` |
| 5 | `commit-artifacts` | (solo) | `:537`, `:572` |
| 6 | `create-pr` | (solo) | `:581`, `:606` |
| 7 | `gate-readiness-check` | (solo) | `:616`, `:640` |
| 8 | `gate-review` | (solo) | `:651`, `:676` |

The sequence-3 cluster: each of the six passes lists the OTHER five in its `parallel_with`
(every pass's `parallel_with` has exactly 5 entries, omitting itself). Verified pairwise
symmetric across `:191-196`, `:235-240`, `:280-285`, `:327-332`, `:374-379`, `:433-438`.

⚠️ GOTCHA: `progress_pct` values are NOT monotonically dense and several steps SHARE the same
`progress_pct` (the two sequence-4 steps both 65 at `:449`/`:495`; all six sequence-3 passes
share 35 at `:163`/`:207`/`:251`/`:296`/`:343`/`:390`). `progress_pct` is the displayed
percent-complete for the step's stage, while `progress_weight` is the step's contribution to
the rollup. They are independent fields — `progress_weight` values are 10/15/10/10/10/5/5/5/10/
10/5/5/5/10 across the 14 steps (sum = 105, NOT 100 — see below).

⚠️ GOTCHA: Sum of all 14 `progress_weight` values = 10+15+10+10+10+5+5+5+10+10+5+5+5+10 = **105**,
not 100. The weights do NOT normalize to 100 in the contract; any consumer computing a
percentage must normalize against the actual sum (105), not assume 100. Reproduce the literal
weights.

---

## 4. Field-Presence Matrix (which optional fields appear where)

For parity, the following fields are NOT universal — preserve their presence/absence exactly:

- `summary: true` — ONLY on `synthesis` (`:452`). Absent on all other 14 steps.
- `role: pre-review` — ONLY on `gate-readiness-check` (`:614`). (Distinct from `agent_role`.)
- `gate: <non-null>` — ONLY on `gate-review` (`gate: G-DC`, `:677`). All other 14 have
  `gate: null`.
- `retry_policy.non_retryable_errors` — present on the 11 `agent_failure` steps; ABSENT on the
  two `transient` git steps (`:575`, `:609`) and the one `validation_failure` gate step
  (`:679`).
- `retry_policy.max_attempts_override: 1` — ONLY on `gate-readiness-check` (`:645`).
- `artifact_filename` — present on all 11 agent steps + ... NOTE: present on steps with an
  emitted artifact file: `catalog` (`:49`), `structural-analysis` (`:90`),
  `business-logic-extraction` (`:165`), `quality-risk-assessment` (`:209`),
  `ux-accessibility-assessment` (`:253`), `data-domain-discovery` (`:298`),
  `shared-database-analysis` (`:345`), `capability-extraction` (`:392`), `synthesis` (`:451`),
  `tco-baseline` (`:497`). ABSENT on `commit-artifacts`, `create-pr`, `gate-readiness-check`,
  and `gate-review` (the two git steps, the pre-review, and the gate). ⚠️ GOTCHA:
  `gate-readiness-check` emits artifact `gate-readiness-check` (`:630`) but has NO
  `artifact_filename` key — its artifact filename is not declared in this contract.
- `outputs.side_effects: []` (empty) — on `data-domain-discovery` (`:320`),
  `shared-database-analysis` (`:367`), `synthesis` (`:477`). All other steps have ≥1 side
  effect. `create-pr` / `commit-artifacts` / `gate-review` each have 2 side-effect entries;
  the rest have 1.

### Side-effect target sinks (complete enumeration)

The contract uses these distinct side-effect `target` values:
- `application` — Steps 1,2,3,4,5,10,11(2nd),14(2nd) (`:62,:142,:181,:222,:267,:514,:564,:668`)
- `legacy_system_grain` — Step 8 ONLY (`:421`)
- `artifact-repo` — Steps 11(1st),12(1st) (`:562,:596`)
- `gate_record` — Steps 12(2nd),13,14(1st) (`:598,:632,:666`)

⚠️ GOTCHA: Target sink naming is INCONSISTENT in casing/separator: `application`,
`gate_record`, `legacy_system_grain` use snake_case, while `artifact-repo` uses kebab-case.
This is as-authored in the file; reproduce the exact strings. Do NOT normalize `artifact-repo`
to `artifact_repo` or vice-versa.

---

STEP INVENTORY: catalog, structural-analysis, business-logic-extraction, quality-risk-assessment, ux-accessibility-assessment, data-domain-discovery, shared-database-analysis, capability-extraction, synthesis, tco-baseline, commit-artifacts, create-pr, gate-readiness-check, gate-review

STEPS REPRODUCED: 14 (the authoritative discovery.yaml has 14 step list items, NOT 15; the task brief's count was off-by-one because `- id: G-DC` at discovery.yaml:21 is a gate entry under `gates:`, not a step. All 14 real steps reproduced in full above.)
