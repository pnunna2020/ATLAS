# Validation Assembly Line — Authoritative Step Contract (Phase 1)

**Source of truth:** `olympus-contracts/olympus_contracts/data/assembly-lines/validation.yaml`
(repo-relative). All path:line citations below refer to this file unless otherwise noted.

This document reproduces the Validation assembly-line contract field-by-field for behavioral
parity. Every downstream consumer (the Temporal workflow, the Olympus API gate service, the
step-progress mapping, the frontend step registry) loads FROM this YAML via
`olympus_contracts.assembly_lines`. There is no hardcoded copy in application code; drift is
policed by the `test_no_hardcoded_step_lists` CI check (per the file header,
validation.yaml:1-8).

---

## ⚠️ GOTCHA 0 — STEP COUNT IS 20, NOT 23

The orchestrating task brief asserted "EXACTLY 23 steps" under `steps:`. **The on-disk file
contains exactly 20 steps** under the `steps:` key (each at the 2-space `- id:` indent), at
lines 74, 118, 156, 195, 233, 282, 321, 361, 392, 427, 472, 502, 536, 573, 611, 644, 674,
707, 743, 790.

The "23" almost certainly arises from counting **all** `- id:` tokens in the file: there are
**3 gate entries** under the top-level `gates:` key (`G-V1` @ validation.yaml:27, `G-V2` @
validation.yaml:29, `G-V3` @ validation.yaml:31) **plus 20 steps** = 23 total `- id:` lines.
The gate entries are line-level metadata, **not** steps. Verified two ways:

- `grep -nE '^  - id:' validation.yaml` → 23 hits (3 gates + 20 steps).
- `grep -nE '^  - id:' validation.yaml | awk -F: '$1 >= 73'` → 20 hits (steps only; the
  `steps:` key is at validation.yaml:73, file ends at line 829, confirmed by `wc -l`).

Only one `validation.yaml` exists in the repo (confirmed via `find ... -name validation.yaml
-not -path '*/.claude/worktrees/*'`); there is no alternate 23-step variant. **Reproducing a
phantom 23 steps would violate behavioral parity.** This spec reproduces the actual 20 steps
in full, plus the 3 gate metadata entries, so a rebuild is byte-faithful to source.

---

## 1. Line-Level Metadata

Reproduced verbatim from the top of the file (validation.yaml:10-71).

### 1.1 `name` (validation.yaml:10)
```
Validation
```

### 1.2 `description` (validation.yaml:11-21)
YAML folded scalar (`>`). Reproduced with original line breaks preserved as authored (folded
scalars join lines with single spaces on parse; the authored wrapping is shown for fidelity):

> Validation is the quality firewall between Modernization and Deployment.
> It independently verifies the modernized code is correct, compliant, and
> — for Tier-1 applications — safe, across four parallel streams:
> Functional Parity, Security & Compliance, Accessibility & UX, and (Tier-1
> only) Safety Assurance. Streams run in parallel; gates run serially. The
> three always-on streams (Parity, Security, Accessibility) fan out together
> after Validation opens; their outputs feed G-V1 (Parity) and G-V2
> (Security + Accessibility rolled up). Tier-1 then runs the Safety stream
> and G-V3 sequentially. Validation does not modify code — if findings
> exceed thresholds the rework loop kicks back to Modernization.

### 1.3 `trigger` (validation.yaml:22)
```
modernization-g-04c-approved-with-generate-artifacts
```
⚠️ GOTCHA: The trigger string encodes a *specific* upstream gate: Modernization's G-04c
approval, *with* the generate artifacts present. This is the exact event Validation listens
for; a rebuild must emit/consume this exact token.

### 1.4 `depends_on` (validation.yaml:23-25)
Preceded by inline comment at validation.yaml:23: `# Strict upstream only; Architecture/Data/Discovery reached transitively.`
```yaml
depends_on:
  - Modernization
```
⚠️ GOTCHA: Declares **only** `Modernization` as a direct dependency. Architecture, Data, and
Discovery artifacts are consumed (see step inputs below) but reached *transitively* — they are
deliberately NOT listed in `depends_on`. Do not add them on rebuild.

### 1.5 `gates` (validation.yaml:26-32)
Three gate metadata entries (each a `{id, label}` pair). These are NOT steps.
```yaml
gates:
  - id: G-V1
    label: Functional Parity          # validation.yaml:27-28
  - id: G-V2
    label: Compliance & Security       # validation.yaml:29-30
  - id: G-V3
    label: Safety Assurance            # validation.yaml:31-32
```

### 1.6 `mode` (validation.yaml:33)
```
per-app
```
This is a **triggered, per-application** line (not continuous). Every step also carries
`scope: per-app`.

### 1.7 `inputs` (validation.yaml:34-47)
Top-level inputs is a **flat list of 13 artifact short-names** (NOT the `{artifacts, context}`
structure used at step level):
```yaml
inputs:
  - gate-review-package        # :35
  - architecture-blueprint     # :36
  - data-architecture          # :37
  - accessibility-review       # :38
  - security-arch              # :39
  - cato-evidence-seed         # :40
  - data-migration-plan        # :41
  - ux-accessibility           # :42
  - quality-risk               # :43
  - structural-analysis        # :44
  - business-logic             # :45
  - integration-arch           # :46
  - design-system              # :47
```

### 1.8 `outputs` (validation.yaml:48-71)
Flat list of **24 output short-names**. The last three are annotated with the inline comment
`# Stage 9 ATLAS integration (2026-05-06)` at validation.yaml:68:
```yaml
outputs:
  - parity-report                  # :49
  - api-contract-report            # :50
  - external-consumer-compat       # :51
  - acceptable-divergences         # :52
  - security-assessment-report     # :53
  - ssp                            # :54
  - poam                           # :55
  - authorization-recommendation   # :56
  - accessibility-audit            # :57
  - design-system-compliance       # :58
  - uat-results                    # :59
  - training-package               # :60
  - g-v1-evidence                  # :61
  - g-v2-evidence                  # :62
  - safety-case                    # :63
  - ivnv-results                   # :64
  - traceability-report            # :65
  - safety-impact-assessment       # :66
  - g-v3-evidence                  # :67
  # Stage 9 ATLAS integration (2026-05-06)   :68
  - test-plan                      # :69
  - remediation-plan               # :70
  - compliance-gap-matrix          # :71
```

### 1.9 Top-level key inventory
All top-level keys present, in file order: `name`, `description`, `trigger`, `depends_on`,
`gates`, `mode`, `inputs`, `outputs`, `steps`. No other top-level keys.

### 1.10 Per-step field schema (fields observed across all 20 steps)
Each step is an object. Field set observed (a given step contains a subset):
`id`, `label`, `kind`, `scope`, `sequence`, `progress_pct`, `purpose`, `skills`, `agent_role`,
`inputs` (`.artifacts`, `.context`), `outputs` (`.artifacts`, `.side_effects`), `agent_contract`
(`.mcp_servers`, `.repos.{artifact,source,target}`), `parallel_with`, `gate`, `retry_policy`
(`.category`).

⚠️ GOTCHA: The brief's field-name guesses differ from the actual keys. **Actual keys are:**
`scope` (not "role"), `progress_pct` (not "progress"), `purpose` (not "summary"),
`agent_role` (not part of `agent_contract`), `agent_contract.mcp_servers` (not "mcp"),
`agent_contract.repos` (a 3-key object `{artifact, source, target}`, NOT a list). There is
**no** `condition`, `loop`, or `iteration` field on any step in this file. `retry_policy` has
exactly one key: `category`.

⚠️ GOTCHA: `repos` values are role-access strings drawn from the set
`{ro, rw, none}` applied per repo dimension `artifact` / `source` / `target`. `ro`=read-only,
`rw`=read-write, `none`=no access. These are load-bearing — a rebuild must grant exactly these
accesses per step.

⚠️ GOTCHA: `parallel_with` is the ONLY field encoding concurrency. Only the three always-on
streams reference each other in it; every other step has `parallel_with: []` and runs serially
in `sequence` order. The fan-out/gather is implemented by the workflow reading these arrays.

---

## 2. Steps (all 20, in full, in file order)

> Convention below: every field present on the step is reproduced. Empty collections are shown
> as `[]` exactly as in source. `null` is reproduced as `null`.

---

### STEP 1 — `intake` (validation.yaml:74-107)

- **id:** `intake` (validation.yaml:74)
- **label:** `Validation Intake` (validation.yaml:75)
- **kind:** `code` (validation.yaml:76)
- **scope:** `per-app` (validation.yaml:77)
- **sequence:** `1` (validation.yaml:78)
- **progress_pct:** `5` (validation.yaml:79)
- **purpose** (folded `>`, validation.yaml:80-84):
  > Workflow code (not an agent dispatch). Resolves the target app's disposition, risk tier,
  > and input artifact refs; sets application.current_line to "Validation" and current_step to
  > "intake"; initialises the per-stream state objects.
- **skills:** `[]` (validation.yaml:85)
- **agent_role:** `null` (validation.yaml:86)
- **inputs** (validation.yaml:87-92):
  - **artifacts** (validation.yaml:88-91):
    - `modernization/{target_app_id}/gate-review-package-g-04c.json`
    - `architecture/{target_app_id}/architecture-blueprint.json`
    - `data/{target_app_id}/data-architecture.json`
  - **context:** `[target_app_id, portfolio_id, risk_tier, disposition]` (validation.yaml:92)
- **outputs** (validation.yaml:93-97):
  - **artifacts:** `[]` (validation.yaml:94)
  - **side_effects** (validation.yaml:95-97):
    - target: `application`; fields: `[current_line, current_step, updated_at]`
- **agent_contract** (validation.yaml:98-103):
  - **mcp_servers:** `[]` (validation.yaml:99)
  - **repos:** `artifact: ro`, `source: none`, `target: ro` (validation.yaml:101-103)
- **parallel_with:** `[]` (validation.yaml:104)
- **gate:** `null` (validation.yaml:105)
- **retry_policy:** `category: transient` (validation.yaml:106-107)

---

### STEP 2 — `formal-test-plan-authoring` (validation.yaml:118-154)

Preceded by the block comment at validation.yaml:109-117 (Stage 9 ATLAS integration,
2026-05-06): `formal-test-plan-generator` authors the IEEE-829 / ISO-29119 formal test plan
document ahead of the three parallel Validation streams so auditors and T1 gate reviewers have
a signed, traceable test plan in the G-V1 evidence packet. Mandatory for T1 and T2 (before
G-V1); T3 receives a lightweight smoke-test-only plan so Deployment reviewers still have a
signed document in the package. Authoring only — does not run tests; test-validation +
parity-verifier produce the results the plan's §9 Test Deliverables cites.

- **id:** `formal-test-plan-authoring` (validation.yaml:118)
- **label:** `Formal Test Plan Authoring` (validation.yaml:119)
- **kind:** `agent` (validation.yaml:120)
- **scope:** `per-app` (validation.yaml:121)
- **sequence:** `2` (validation.yaml:122)
- **progress_pct:** `8` (validation.yaml:123)
- **purpose** (folded `>`, validation.yaml:124-132):
  > Author the reviewer-ready formal test plan document (test-plan.md) per IEEE-829 / ISO 29119
  > canonical structure. Synthesizes the extracted business rules catalog, the target
  > architecture blueprint, the application's risk tier, and the selected disposition into the
  > fourteen-section test plan. Required ahead of G-V1 for T1/T2 apps; T3 produces the
  > smoke-test-only variant so Deployment reviewers still have a signed document in the package.
- **skills:** `[formal-test-plan-generator]` (validation.yaml:133)
- **agent_role:** `Validation Lead (Test Plan Author)` (validation.yaml:134)
- **inputs** (validation.yaml:135-140):
  - **artifacts** (validation.yaml:136-139):
    - `discovery/{source_app_id}/business-logic.json`
    - `architecture/{target_app_id}/architecture-blueprint.json`
    - `discovery/{source_app_id}/catalog-application.json`
  - **context:** `[target_app_id, source_app_ids, risk_tier, disposition]` (validation.yaml:140)
- **outputs** (validation.yaml:141-144):
  - **artifacts** (validation.yaml:142-143):
    - `validation/{target_app_id}/test-plan.md`  ⚠️ GOTCHA: `.md`, not `.json` — the only
      Markdown artifact emitted by Validation. Consumed by step 7 (`bundle-g-v1-evidence`).
  - **side_effects:** `[]` (validation.yaml:144)
- **agent_contract** (validation.yaml:145-150):
  - **mcp_servers:** `[olympus]` (validation.yaml:146)
  - **repos:** `artifact: ro`, `source: ro`, `target: rw` (validation.yaml:148-150)
- **parallel_with:** `[]` (validation.yaml:151)
- **gate:** `null` (validation.yaml:152)
- **retry_policy:** `category: agent_failure` (validation.yaml:153-154)

---

### STEP 3 — `functional-parity` (validation.yaml:156-193)

- **id:** `functional-parity` (validation.yaml:156)
- **label:** `Functional Parity Verification` (validation.yaml:157)
- **kind:** `agent` (validation.yaml:158)
- **scope:** `per-app` (validation.yaml:159)
- **sequence:** `3` (validation.yaml:160)
- **progress_pct:** `15` (validation.yaml:161)
- **purpose** (folded `>`, validation.yaml:162-167):
  > Compare modernized behaviour to the legacy baseline (or the approved target spec for
  > Replace/Rearchitect). Runs the generated test suite, compares API contracts, verifies
  > external-consumer compatibility, and computes the parity score. Emits the parity-report
  > artifact G-V1 evidence references.
- **skills:** `[parity-verifier, acceptable-divergences]` (validation.yaml:168)
- **agent_role:** `Parity Verification Agent` (validation.yaml:169)
- **inputs** (validation.yaml:170-176):
  - **artifacts** (validation.yaml:171-175):
    - `modernization/{target_app_id}/generate/*/`  ⚠️ GOTCHA: glob path (`generate/*/`) — points
      at all per-BC generate output dirs, not a single file.
    - `discovery/{source_app_id}/structural-analysis.json`
    - `discovery/{source_app_id}/business-logic.json`
    - `architecture/{target_app_id}/integration-arch.json`
  - **context:** `[target_app_id, source_app_ids, disposition, risk_tier]` (validation.yaml:176)
- **outputs** (validation.yaml:177-183):
  - **artifacts** (validation.yaml:178-182):
    - `validation/{target_app_id}/parity-report.json`
    - `validation/{target_app_id}/api-contract-report.json`
    - `validation/{target_app_id}/external-consumer-compat.json`
    - `validation/{target_app_id}/acceptable-divergences.json`
  - **side_effects:** `[]` (validation.yaml:183)
- **agent_contract** (validation.yaml:184-189):
  - **mcp_servers:** `[olympus]` (validation.yaml:185)
  - **repos:** `artifact: ro`, `source: ro`, `target: rw` (validation.yaml:187-189)
- **parallel_with:** `[security-compliance, accessibility-ux]` (validation.yaml:190)
- **gate:** `null` (validation.yaml:191)
- **retry_policy:** `category: agent_failure` (validation.yaml:192-193)

---

### STEP 4 — `security-compliance` (validation.yaml:195-231)

- **id:** `security-compliance` (validation.yaml:195)
- **label:** `Security & Compliance Assessment` (validation.yaml:196)
- **kind:** `agent` (validation.yaml:197)
- **scope:** `per-app` (validation.yaml:198)
- **sequence:** `4` (validation.yaml:199)
- **progress_pct:** `20` (validation.yaml:200)
- **purpose** (folded `>`, validation.yaml:201-206):
  > Triage CI/CD scanner output (SAST / SCA / container / IaC findings), classify
  > vulnerabilities, compile the SSP / SAR / POA&M package, and validate cATO evidence
  > completeness. Zero critical vulns is the absolute threshold; the skill emits the
  > authorization recommendation in client-profile format (default OSCAL).
- **skills:** `[security-scan-review, cato-evidence-validator]` (validation.yaml:207)
- **agent_role:** `Security & Compliance Agent` (validation.yaml:208)
- **inputs** (validation.yaml:209-214):
  - **artifacts** (validation.yaml:210-213):
    - `modernization/{target_app_id}/generate/*/`  (glob)
    - `architecture/{target_app_id}/security-arch.json`
    - `architecture/{target_app_id}/cato-evidence-seed.json`
  - **context:** `[target_app_id, risk_tier, compliance_baseline]` (validation.yaml:214)
- **outputs** (validation.yaml:215-221):
  - **artifacts** (validation.yaml:216-220):
    - `validation/{target_app_id}/security-assessment-report.json`
    - `validation/{target_app_id}/ssp.json`
    - `validation/{target_app_id}/poam.json`
    - `validation/{target_app_id}/authorization-recommendation.json`
  - **side_effects:** `[]` (validation.yaml:221)
- **agent_contract** (validation.yaml:222-227):
  - **mcp_servers:** `[olympus]` (validation.yaml:223)
  - **repos:** `artifact: ro`, `source: none`, `target: rw` (validation.yaml:225-227)  ⚠️ GOTCHA:
    `source: none` here (no legacy source access needed — scans the generated/target code), in
    contrast to `functional-parity` which has `source: ro`.
- **parallel_with:** `[functional-parity, accessibility-ux]` (validation.yaml:228)
- **gate:** `null` (validation.yaml:229)
- **retry_policy:** `category: agent_failure` (validation.yaml:230-231)

---

### STEP 5 — `accessibility-ux` (validation.yaml:233-270)

- **id:** `accessibility-ux` (validation.yaml:233)
- **label:** `Accessibility & UX Audit` (validation.yaml:234)
- **kind:** `agent` (validation.yaml:235)
- **scope:** `per-app` (validation.yaml:236)
- **sequence:** `5` (validation.yaml:237)
- **progress_pct:** `25` (validation.yaml:238)
- **purpose** (folded `>`, validation.yaml:239-244):
  > Automated WCAG 2.1 AA + Section 508 audit against the modernized code, design-system
  > compliance check, UAT result packaging, and training / change-communication package
  > assembly. Distinct from Architecture-stage accessibility-reviewer (design-time commitment);
  > this stream audits the actual shipped UI.
- **skills:** `[accessibility-checker, design-system]` (validation.yaml:245)
- **agent_role:** `Accessibility Auditor` (validation.yaml:246)
- **inputs** (validation.yaml:247-253):
  - **artifacts** (validation.yaml:248-252):
    - `modernization/{target_app_id}/generate/*/`  (glob)
    - `architecture/{target_app_id}/accessibility-review.json`
    - `architecture/{target_app_id}/design-system.json`
    - `discovery/{source_app_id}/ux-accessibility.json`
  - **context:** `[target_app_id, source_app_ids, risk_tier]` (validation.yaml:253)
- **outputs** (validation.yaml:254-260):
  - **artifacts** (validation.yaml:255-259):
    - `validation/{target_app_id}/accessibility-audit.json`
    - `validation/{target_app_id}/design-system-compliance.json`
    - `validation/{target_app_id}/uat-results.json`
    - `validation/{target_app_id}/training-package.json`
  - **side_effects:** `[]` (validation.yaml:260)
- **agent_contract** (validation.yaml:261-266):
  - **mcp_servers:** `[olympus]` (validation.yaml:262)
  - **repos:** `artifact: ro`, `source: ro`, `target: rw` (validation.yaml:264-266)
- **parallel_with:** `[functional-parity, security-compliance]` (validation.yaml:267)
- **gate:** `null` (validation.yaml:268)
- **retry_policy:** `category: agent_failure` (validation.yaml:269-270)

⚠️ GOTCHA — the parallel fan-out triad: Steps 3/4/5 (`functional-parity`,
`security-compliance`, `accessibility-ux`) mutually reference each other via `parallel_with`
(each lists the other two). These are the "three always-on streams" that fan out together
after intake. They run concurrently; their outputs feed G-V1 (parity) and G-V2 (security +
accessibility rolled up).

---

### STEP 6 — `security-anomaly-resolution` (validation.yaml:282-319)

Preceded by the block comment at validation.yaml:272-281 (Stage 9 ATLAS integration,
2026-05-06): `security-anomaly-resolution` consumes the triaged findings emitted by
`security-scan-review` (run inside `security-compliance` at seq 4), runs the anomaly-detection
pass (George SRS methodology), maps findings to OWASP Top 10 and the active profile's
compliance controls, prioritizes via composite risk score, and emits a remediation plan with
effort estimates, compliance gap matrix, and gate-ready evidence. Runs ahead of G-V2 (the
compliance gate) so remediation evidence is attached to the G-V2 bundle. Runs sequentially
after `security-compliance` — anomaly resolution requires the triaged finding list.

- **id:** `security-anomaly-resolution` (validation.yaml:282)
- **label:** `Security Anomaly Resolution` (validation.yaml:283)
- **kind:** `agent` (validation.yaml:284)
- **scope:** `per-app` (validation.yaml:285)
- **sequence:** `6` (validation.yaml:286)
- **progress_pct:** `30` (validation.yaml:287)
- **purpose** (folded `>`, validation.yaml:288-295):
  > Downstream of security-scan-review: consume the triaged finding list plus anomaly-detection
  > results, map every item to OWASP Top 10 and the active profile's compliance controls,
  > prioritize via composite risk score, and emit a remediation plan with effort estimates,
  > before/after code samples, a compliance gap matrix, and gate-ready evidence artifacts.
  > Authored output feeds the G-V2 evidence bundle.
- **skills:** `[security-anomaly-resolution]` (validation.yaml:296)
- **agent_role:** `Security Anomaly Resolver` (validation.yaml:297)
- **inputs** (validation.yaml:298-304):
  - **artifacts** (validation.yaml:299-303):
    - `validation/{target_app_id}/security-assessment-report.json`  ⚠️ GOTCHA: this is an
      *intra-line* dependency — it consumes step 4's output, which is why it runs sequentially
      (`parallel_with: []`) after the triad, not inside it.
    - `architecture/{target_app_id}/security-arch.json`
    - `architecture/{target_app_id}/cato-evidence-seed.json`
    - `discovery/{source_app_id}/structural-analysis.json`
  - **context:** `[target_app_id, risk_tier, compliance_baseline]` (validation.yaml:304)
- **outputs** (validation.yaml:305-309):
  - **artifacts** (validation.yaml:306-308):
    - `validation/{target_app_id}/remediation-plan.json`
    - `validation/{target_app_id}/compliance-gap-matrix.json`
  - **side_effects:** `[]` (validation.yaml:309)
- **agent_contract** (validation.yaml:310-315):
  - **mcp_servers:** `[olympus]` (validation.yaml:311)
  - **repos:** `artifact: ro`, `source: ro`, `target: rw` (validation.yaml:313-315)
- **parallel_with:** `[]` (validation.yaml:316)
- **gate:** `null` (validation.yaml:317)
- **retry_policy:** `category: agent_failure` (validation.yaml:318-319)

---

### STEP 7 — `bundle-g-v1-evidence` (validation.yaml:321-359)

- **id:** `bundle-g-v1-evidence` (validation.yaml:321)
- **label:** `Bundle G-V1 Parity Evidence` (validation.yaml:322)
- **kind:** `code` (validation.yaml:323)
- **scope:** `per-app` (validation.yaml:324)
- **sequence:** `7` (validation.yaml:325)
- **progress_pct:** `32` (validation.yaml:326)
- **purpose** (folded `>`, validation.yaml:327-333):
  > Workflow code. Waits for the Parity stream to complete (via asyncio.gather), synthesises the
  > G-V1 evidence bundle (parity-report + api-contract + external-consumer-compat +
  > acceptable-divergences + formal test-plan.md), computes the pass/fail verdict against the
  > tier-adjusted threshold, and commits the bundle for G-V1 review.
  - ⚠️ GOTCHA: `asyncio.gather` is named in the purpose — the bundle step is the join point
    that awaits the parallel triad before proceeding. Rebuild must gather the streams here.
- **skills:** `[]` (validation.yaml:334)
- **agent_role:** `null` (validation.yaml:335)
- **inputs** (validation.yaml:336-345):
  - **artifacts** (validation.yaml:337-344):
    - `validation/{target_app_id}/parity-report.json`
    - `validation/{target_app_id}/api-contract-report.json`
    - `validation/{target_app_id}/external-consumer-compat.json`
    - `validation/{target_app_id}/acceptable-divergences.json`
    - (inline comment validation.yaml:342-343: Stage 9 ATLAS integration (2026-05-06): formal
      test plan authored in seq 2 is part of the G-V1 evidence packet.)
    - `validation/{target_app_id}/test-plan.md`  (validation.yaml:344)
  - **context:** `[target_app_id, risk_tier]` (validation.yaml:345)
- **outputs** (validation.yaml:346-349):
  - **artifacts** (validation.yaml:347-348):
    - `validation/{target_app_id}/g-v1-evidence.json`
  - **side_effects:** `[]` (validation.yaml:349)
- **agent_contract** (validation.yaml:350-355):
  - **mcp_servers:** `[]` (validation.yaml:351)
  - **repos:** `artifact: none`, `source: none`, `target: rw` (validation.yaml:353-355)
- **parallel_with:** `[]` (validation.yaml:356)
- **gate:** `null` (validation.yaml:357)
- **retry_policy:** `category: transient` (validation.yaml:358-359)

---

### STEP 8 — `create-g-v1-pr` (validation.yaml:361-390)

- **id:** `create-g-v1-pr` (validation.yaml:361)
- **label:** `Create G-V1 Review PR` (validation.yaml:362)
- **kind:** `git` (validation.yaml:363)
- **scope:** `per-app` (validation.yaml:364)
- **sequence:** `8` (validation.yaml:365)
- **progress_pct:** `36` (validation.yaml:366)
- **purpose** (folded `>`, validation.yaml:367-371):
  > Open the gate-review PR against target_repo main. PR body carries the parity verdict +
  > divergence list + test-suite summary; tags PM for the acknowledgement merge (G-V1 is
  > automated pass/fail — PM merges to acknowledge, does not re-evaluate).
- **skills:** `[]` (validation.yaml:372)
- **agent_role:** `null` (validation.yaml:373)
- **inputs** (validation.yaml:374-377):
  - **artifacts** (validation.yaml:375-376):
    - `validation/{target_app_id}/g-v1-evidence.json`
  - **context:** `[target_app_id, portfolio_id]` (validation.yaml:377)
- **outputs** (validation.yaml:378-380):
  - **artifacts:** `[]` (validation.yaml:379)
  - **side_effects:** `[]` (validation.yaml:380)
- **agent_contract** (validation.yaml:381-386):
  - **mcp_servers:** `[]` (validation.yaml:382)
  - **repos:** `artifact: none`, `source: none`, `target: rw` (validation.yaml:384-386)
- **parallel_with:** `[]` (validation.yaml:387)
- **gate:** `null` (validation.yaml:388)
- **retry_policy:** `category: transient` (validation.yaml:389-390)

---

### STEP 9 — `gate-review-v1` (validation.yaml:392-425)

- **id:** `gate-review-v1` (validation.yaml:392)
- **label:** `G-V1 Functional Parity` (validation.yaml:393)
- **kind:** `gate` (validation.yaml:394)
- **scope:** `per-app` (validation.yaml:395)
- **sequence:** `9` (validation.yaml:396)
- **progress_pct:** `40` (validation.yaml:397)
- **purpose** (folded `>`, validation.yaml:398-404):
  > Automated pass/fail. If parity >= threshold and no test-suite failures: PM merges PR and the
  > workflow advances to G-V2. If parity < threshold: workflow auto-rejects and routes contested
  > findings back to Modernization (rework iteration bump). Parity threshold is tier-adjusted:
  > Tier-1 >= 99%, Tier-2 >= 98%, Tier-3 >= 95%.
  - ⚠️ GOTCHA: Tier-adjusted thresholds are load-bearing constants: **T1 ≥ 99%, T2 ≥ 98%,
    T3 ≥ 95%**. Failure triggers rework loop back to Modernization with an iteration bump.
- **skills:** `[]` (validation.yaml:405)
- **agent_role:** `null` (validation.yaml:406)
- **inputs** (validation.yaml:407-410):
  - **artifacts** (validation.yaml:408-409):
    - `validation/{target_app_id}/g-v1-evidence.json`
  - **context:** `[target_app_id, risk_tier]` (validation.yaml:410)
- **outputs** (validation.yaml:411-415):
  - **artifacts:** `[]` (validation.yaml:412)
  - **side_effects** (validation.yaml:413-415):
    - target: `gate_record`; fields: `[gate_id, status, approved_by, approved_at]`
- **agent_contract** (validation.yaml:416-421):
  - **mcp_servers:** `[]` (validation.yaml:417)
  - **repos:** `artifact: none`, `source: none`, `target: rw` (validation.yaml:419-421)
- **parallel_with:** `[]` (validation.yaml:422)
- **gate:** `G-V1` (validation.yaml:423)  ⚠️ GOTCHA: this step's `gate` field is set (vs `null`
  on non-gate steps). The `gate` field ties the step to the gate metadata entry at
  validation.yaml:27.
- **retry_policy:** `category: validation_failure` (validation.yaml:424-425)

---

### STEP 10 — `bundle-g-v2-evidence` (validation.yaml:427-470)

- **id:** `bundle-g-v2-evidence` (validation.yaml:427)
- **label:** `Bundle G-V2 Compliance Evidence` (validation.yaml:428)
- **kind:** `code` (validation.yaml:429)
- **scope:** `per-app` (validation.yaml:430)
- **sequence:** `10` (validation.yaml:431)
- **progress_pct:** `45` (validation.yaml:432)
- **purpose** (folded `>`, validation.yaml:433-438):
  > Synthesises the G-V2 evidence bundle: security assessment + SSP + POA&M + cATO evidence +
  > accessibility audit + design-system compliance + UAT results + remediation plan + compliance
  > gap matrix. Computes the vuln-classification roll-up (must have zero critical). Commits the
  > bundle.
  - ⚠️ GOTCHA: "zero critical" vuln roll-up is computed here and enforced as the hard floor at
    G-V2 (step 13).
- **skills:** `[]` (validation.yaml:439)
- **agent_role:** `null` (validation.yaml:440)
- **inputs** (validation.yaml:441-456):
  - **artifacts** (validation.yaml:442-455):
    - `validation/{target_app_id}/security-assessment-report.json`
    - `validation/{target_app_id}/ssp.json`
    - `validation/{target_app_id}/poam.json`
    - `validation/{target_app_id}/authorization-recommendation.json`
    - `validation/{target_app_id}/accessibility-audit.json`
    - `validation/{target_app_id}/design-system-compliance.json`
    - `validation/{target_app_id}/uat-results.json`
    - `validation/{target_app_id}/training-package.json`
    - (inline comment validation.yaml:451-453: Stage 9 ATLAS integration (2026-05-06):
      remediation plan + compliance gap matrix emitted by security-anomaly-resolution (seq 6)
      are part of the G-V2 evidence packet.)
    - `validation/{target_app_id}/remediation-plan.json`  (validation.yaml:454)
    - `validation/{target_app_id}/compliance-gap-matrix.json`  (validation.yaml:455)
  - **context:** `[target_app_id, risk_tier, compliance_baseline]` (validation.yaml:456)
- **outputs** (validation.yaml:457-460):
  - **artifacts** (validation.yaml:458-459):
    - `validation/{target_app_id}/g-v2-evidence.json`
  - **side_effects:** `[]` (validation.yaml:460)
- **agent_contract** (validation.yaml:461-466):
  - **mcp_servers:** `[]` (validation.yaml:462)
  - **repos:** `artifact: none`, `source: none`, `target: rw` (validation.yaml:464-466)
- **parallel_with:** `[]` (validation.yaml:467)
- **gate:** `null` (validation.yaml:468)
- **retry_policy:** `category: transient` (validation.yaml:469-470)

---

### STEP 11 — `create-g-v2-pr` (validation.yaml:472-500)

- **id:** `create-g-v2-pr` (validation.yaml:472)
- **label:** `Create G-V2 Review PR` (validation.yaml:473)
- **kind:** `git` (validation.yaml:474)
- **scope:** `per-app` (validation.yaml:475)
- **sequence:** `11` (validation.yaml:476)
- **progress_pct:** `48` (validation.yaml:477)
- **purpose** (folded `>`, validation.yaml:478-481):
  > Open the G-V2 gate-review PR. Body aggregates the security + cATO + accessibility evidence +
  > roll-up verdict. Tier-1 PRs tag the compliance lead + security officer for stakeholder
  > sign-off.
- **skills:** `[]` (validation.yaml:482)
- **agent_role:** `null` (validation.yaml:483)
- **inputs** (validation.yaml:484-487):
  - **artifacts** (validation.yaml:485-486):
    - `validation/{target_app_id}/g-v2-evidence.json`
  - **context:** `[target_app_id, risk_tier]` (validation.yaml:487)
- **outputs** (validation.yaml:488-490):
  - **artifacts:** `[]` (validation.yaml:489)
  - **side_effects:** `[]` (validation.yaml:490)
- **agent_contract** (validation.yaml:491-496):
  - **mcp_servers:** `[]` (validation.yaml:492)
  - **repos:** `artifact: none`, `source: none`, `target: rw` (validation.yaml:494-496)
- **parallel_with:** `[]` (validation.yaml:497)
- **gate:** `null` (validation.yaml:498)
- **retry_policy:** `category: transient` (validation.yaml:499-500)

---

### STEP 12 — `ai-pre-review-v2` (validation.yaml:502-534)

- **id:** `ai-pre-review-v2` (validation.yaml:502)
- **label:** `AI Pre-Review (G-V2)` (validation.yaml:503)
- **kind:** `agent` (validation.yaml:504)
- **scope:** `per-app` (validation.yaml:505)
- **sequence:** `12` (validation.yaml:506)
- **progress_pct:** `52` (validation.yaml:507)
- **purpose** (folded `>`, validation.yaml:508-512):
  > Advisory readiness check before G-V2 opens — flags likely blocker findings (critical vulns
  > still present, SSP gaps, accessibility barriers above threshold, incomplete POA&M).
  > Reviewers can short-circuit obvious rejections.
- **skills:** `[gate-pre-review]` (validation.yaml:513)
- **agent_role:** `Gate Pre-Reviewer` (validation.yaml:514)
- **inputs** (validation.yaml:515-518):
  - **artifacts** (validation.yaml:516-517):
    - `validation/{target_app_id}/g-v2-evidence.json`
  - **context:** `[target_app_id, risk_tier]` (validation.yaml:518)
- **outputs** (validation.yaml:519-524):
  - **artifacts** (validation.yaml:520-521):
    - `validation/{target_app_id}/pre-review-v2.json`
  - **side_effects** (validation.yaml:522-524):
    - target: `gate_pre_review`; fields: `[gate_id, findings_json]`
- **agent_contract** (validation.yaml:525-530):
  - **mcp_servers:** `[olympus]` (validation.yaml:526)
  - **repos:** `artifact: none`, `source: none`, `target: rw` (validation.yaml:528-530)  ⚠️ GOTCHA:
    `artifact: none` here even though `kind: agent` — the pre-reviewer reads the evidence bundle
    from the target repo, not the artifact repo.
- **parallel_with:** `[]` (validation.yaml:531)
- **gate:** `null` (validation.yaml:532)
- **retry_policy:** `category: agent_failure` (validation.yaml:533-534)

---

### STEP 13 — `gate-review-v2` (validation.yaml:536-571)

- **id:** `gate-review-v2` (validation.yaml:536)
- **label:** `G-V2 Compliance & Security` (validation.yaml:537)
- **kind:** `gate` (validation.yaml:538)
- **scope:** `per-app` (validation.yaml:539)
- **sequence:** `13` (validation.yaml:540)
- **progress_pct:** `56` (validation.yaml:541)
- **purpose** (folded `>`, validation.yaml:542-549):
  > Human review of the compliance + security + accessibility bundle. Tier-1 triple-signal: PM
  > merges PR AND compliance lead (scope="g-v2-compliance") AND security officer
  > (scope="g-v2-security") all fire stakeholder_approved. Tier-2/3 single-signal (PM only).
  > Rejection routes contested findings back to Modernization (rework iteration bump). Zero
  > critical vulns is the hard floor — rejection is automatic when present.
  - ⚠️ GOTCHA: **Tier-1 triple-signal** approval. Three independent stakeholder signals with
    EXACT scope strings: PM merge + `scope="g-v2-compliance"` + `scope="g-v2-security"`, all
    firing `stakeholder_approved`. Tier-2/3 require only PM. Zero-critical-vuln is an automatic
    hard-floor rejection independent of human signals.
- **skills:** `[]` (validation.yaml:550)
- **agent_role:** `null` (validation.yaml:551)
- **inputs** (validation.yaml:552-556):
  - **artifacts** (validation.yaml:553-555):
    - `validation/{target_app_id}/g-v2-evidence.json`
    - `validation/{target_app_id}/pre-review-v2.json`
  - **context:** `[target_app_id, risk_tier]` (validation.yaml:556)
- **outputs** (validation.yaml:557-561):
  - **artifacts:** `[]` (validation.yaml:558)
  - **side_effects** (validation.yaml:559-561):
    - target: `gate_record`; fields: `[gate_id, status, approved_by, approved_at]`
- **agent_contract** (validation.yaml:562-567):
  - **mcp_servers:** `[]` (validation.yaml:563)
  - **repos:** `artifact: none`, `source: none`, `target: rw` (validation.yaml:565-567)
- **parallel_with:** `[]` (validation.yaml:568)
- **gate:** `G-V2` (validation.yaml:569)  (ties to gate metadata at validation.yaml:29)
- **retry_policy:** `category: validation_failure` (validation.yaml:570-571)

---

### STEP 14 — `safety-assurance` (validation.yaml:573-609)

- **id:** `safety-assurance` (validation.yaml:573)
- **label:** `Safety Assurance` (validation.yaml:574)
- **kind:** `agent` (validation.yaml:575)
- **scope:** `per-app` (validation.yaml:576)
- **sequence:** `14` (validation.yaml:577)
- **progress_pct:** `62` (validation.yaml:578)
- **purpose** (folded `>`, validation.yaml:579-584):
  > Tier-1 only. Runs IV&V (independent verification & validation), traceability verification
  > (requirement → test coverage must be >= 99%), safety case updates, and safety impact
  > assessment. Only runs after G-V1 + G-V2 approve — the safety case references the parity +
  > compliance evidence those gates produced.
  - ⚠️ GOTCHA: **Tier-1 only** step — skipped entirely for Tier-2/Tier-3. Gated on BOTH G-V1
    and G-V2 having approved first. Traceability coverage floor is **≥ 99%** (requirement → test).
- **skills:** `[safety-critical-verifier, traceability-checker]` (validation.yaml:585)
- **agent_role:** `Safety Assurance Agent` (validation.yaml:586)
- **inputs** (validation.yaml:587-592):
  - **artifacts** (validation.yaml:588-591):
    - `validation/{target_app_id}/g-v1-evidence.json`
    - `validation/{target_app_id}/g-v2-evidence.json`
    - `architecture/{target_app_id}/security-arch.json`
  - **context:** `[target_app_id, risk_tier]` (validation.yaml:592)
- **outputs** (validation.yaml:593-599):
  - **artifacts** (validation.yaml:594-598):
    - `validation/{target_app_id}/safety-case.json`
    - `validation/{target_app_id}/ivnv-results.json`
    - `validation/{target_app_id}/traceability-report.json`
    - `validation/{target_app_id}/safety-impact-assessment.json`
  - **side_effects:** `[]` (validation.yaml:599)
- **agent_contract** (validation.yaml:600-605):
  - **mcp_servers:** `[olympus]` (validation.yaml:601)
  - **repos:** `artifact: none`, `source: none`, `target: rw` (validation.yaml:603-605)  ⚠️ GOTCHA:
    `artifact: none` despite `kind: agent` — safety inputs are read from the target repo's
    committed evidence bundles, not the artifact repo.
- **parallel_with:** `[]` (validation.yaml:606)
- **gate:** `null` (validation.yaml:607)
- **retry_policy:** `category: agent_failure` (validation.yaml:608-609)

---

### STEP 15 — `bundle-g-v3-evidence` (validation.yaml:611-642)

- **id:** `bundle-g-v3-evidence` (validation.yaml:611)
- **label:** `Bundle G-V3 Safety Evidence` (validation.yaml:612)
- **kind:** `code` (validation.yaml:613)
- **scope:** `per-app` (validation.yaml:614)
- **sequence:** `15` (validation.yaml:615)
- **progress_pct:** `68` (validation.yaml:616)
- **purpose** (folded `>`, validation.yaml:617-619):
  > Synthesises the G-V3 evidence bundle for safety board review. Combines safety case + IV&V +
  > traceability + impact assessment.
- **skills:** `[]` (validation.yaml:620)
- **agent_role:** `null` (validation.yaml:621)
- **inputs** (validation.yaml:622-628):
  - **artifacts** (validation.yaml:623-627):
    - `validation/{target_app_id}/safety-case.json`
    - `validation/{target_app_id}/ivnv-results.json`
    - `validation/{target_app_id}/traceability-report.json`
    - `validation/{target_app_id}/safety-impact-assessment.json`
  - **context:** `[target_app_id]` (validation.yaml:628)
- **outputs** (validation.yaml:629-632):
  - **artifacts** (validation.yaml:630-631):
    - `validation/{target_app_id}/g-v3-evidence.json`
  - **side_effects:** `[]` (validation.yaml:632)
- **agent_contract** (validation.yaml:633-638):
  - **mcp_servers:** `[]` (validation.yaml:634)
  - **repos:** `artifact: none`, `source: none`, `target: rw` (validation.yaml:636-638)
- **parallel_with:** `[]` (validation.yaml:639)
- **gate:** `null` (validation.yaml:640)
- **retry_policy:** `category: transient` (validation.yaml:641-642)

---

### STEP 16 — `create-g-v3-pr` (validation.yaml:644-672)

- **id:** `create-g-v3-pr` (validation.yaml:644)
- **label:** `Create G-V3 Review PR` (validation.yaml:645)
- **kind:** `git` (validation.yaml:646)
- **scope:** `per-app` (validation.yaml:647)
- **sequence:** `16` (validation.yaml:648)
- **progress_pct:** `72` (validation.yaml:649)
- **purpose** (folded `>`, validation.yaml:650-653):
  > Open the G-V3 gate-review PR. Body aggregates the safety case + IV&V + traceability verdict.
  > Tags safety board + certifying authority.
- **skills:** `[]` (validation.yaml:654)
- **agent_role:** `null` (validation.yaml:655)
- **inputs** (validation.yaml:656-659):
  - **artifacts** (validation.yaml:657-658):
    - `validation/{target_app_id}/g-v3-evidence.json`
  - **context:** `[target_app_id]` (validation.yaml:659)
- **outputs** (validation.yaml:660-662):
  - **artifacts:** `[]` (validation.yaml:661)
  - **side_effects:** `[]` (validation.yaml:662)
- **agent_contract** (validation.yaml:663-668):
  - **mcp_servers:** `[]` (validation.yaml:664)
  - **repos:** `artifact: none`, `source: none`, `target: rw` (validation.yaml:666-668)
- **parallel_with:** `[]` (validation.yaml:669)
- **gate:** `null` (validation.yaml:670)
- **retry_policy:** `category: transient` (validation.yaml:671-672)

---

### STEP 17 — `ai-pre-review-v3` (validation.yaml:674-705)

- **id:** `ai-pre-review-v3` (validation.yaml:674)
- **label:** `AI Pre-Review (G-V3)` (validation.yaml:675)
- **kind:** `agent` (validation.yaml:676)
- **scope:** `per-app` (validation.yaml:677)
- **sequence:** `17` (validation.yaml:678)
- **progress_pct:** `76` (validation.yaml:679)
- **purpose** (folded `>`, validation.yaml:680-683):
  > Advisory readiness check before G-V3. Flags likely safety-board blockers (traceability <
  > 99%, IV&V gaps, safety case missing hazard analysis).
- **skills:** `[gate-pre-review]` (validation.yaml:684)
- **agent_role:** `Gate Pre-Reviewer` (validation.yaml:685)
- **inputs** (validation.yaml:686-689):
  - **artifacts** (validation.yaml:687-688):
    - `validation/{target_app_id}/g-v3-evidence.json`
  - **context:** `[target_app_id]` (validation.yaml:689)
- **outputs** (validation.yaml:690-695):
  - **artifacts** (validation.yaml:691-692):
    - `validation/{target_app_id}/pre-review-v3.json`
  - **side_effects** (validation.yaml:693-695):
    - target: `gate_pre_review`; fields: `[gate_id, findings_json]`
- **agent_contract** (validation.yaml:696-701):
  - **mcp_servers:** `[olympus]` (validation.yaml:697)
  - **repos:** `artifact: none`, `source: none`, `target: rw` (validation.yaml:699-701)
- **parallel_with:** `[]` (validation.yaml:702)
- **gate:** `null` (validation.yaml:703)
- **retry_policy:** `category: agent_failure` (validation.yaml:704-705)

---

### STEP 18 — `gate-review-v3` (validation.yaml:707-741)

- **id:** `gate-review-v3` (validation.yaml:707)
- **label:** `G-V3 Safety Assurance` (validation.yaml:708)
- **kind:** `gate` (validation.yaml:709)
- **scope:** `per-app` (validation.yaml:710)
- **sequence:** `18` (validation.yaml:711)
- **progress_pct:** `82` (validation.yaml:712)
- **purpose** (folded `>`, validation.yaml:713-719):
  > Safety board review of the safety case. Tier-1 triple-signal: PM merges PR AND safety board
  > chair (scope="g-v3-safety") AND certifying authority (scope="g-v3-cert") fire
  > stakeholder_approved. Rejection routes safety-case gaps back to Architecture (safety-arch
  > re-design) or traceability gaps back to Modernization.
  - ⚠️ GOTCHA: **Tier-1 triple-signal** with EXACT scope strings: PM merge + `scope="g-v3-safety"`
    + `scope="g-v3-cert"`, all firing `stakeholder_approved`. ⚠️ GOTCHA: rejection routing is
    *split by gap type* — safety-case gaps go back to **Architecture** (safety-arch re-design);
    traceability gaps go back to **Modernization**. Two distinct rework targets from one gate.
- **skills:** `[]` (validation.yaml:720)
- **agent_role:** `null` (validation.yaml:721)
- **inputs** (validation.yaml:722-726):
  - **artifacts** (validation.yaml:723-725):
    - `validation/{target_app_id}/g-v3-evidence.json`
    - `validation/{target_app_id}/pre-review-v3.json`
  - **context:** `[target_app_id]` (validation.yaml:726)
- **outputs** (validation.yaml:727-731):
  - **artifacts:** `[]` (validation.yaml:728)
  - **side_effects** (validation.yaml:729-731):
    - target: `gate_record`; fields: `[gate_id, status, approved_by, approved_at]`
- **agent_contract** (validation.yaml:732-737):
  - **mcp_servers:** `[]` (validation.yaml:733)
  - **repos:** `artifact: none`, `source: none`, `target: rw` (validation.yaml:735-737)
- **parallel_with:** `[]` (validation.yaml:738)
- **gate:** `G-V3` (validation.yaml:739)  (ties to gate metadata at validation.yaml:31)
- **retry_policy:** `category: validation_failure` (validation.yaml:740-741)

---

### STEP 19 — `persist-validation-side-effects` (validation.yaml:743-788)

- **id:** `persist-validation-side-effects` (validation.yaml:743)
- **label:** `Persist Validation Side-Effects` (validation.yaml:744)
- **kind:** `code` (validation.yaml:745)
- **scope:** `per-app` (validation.yaml:746)
- **sequence:** `19` (validation.yaml:747)
- **progress_pct:** `90` (validation.yaml:748)
- **purpose** (folded `>`, validation.yaml:749-753):
  > Post-gate projection. Parses the merged G-V1 / G-V2 (+ G-V3 for Tier-1) evidence bundles and
  > writes the authoritative validation fields onto application. Single consolidated activity
  > following the Discovery / Rationalization pattern — one writer per field.
- **skills:** `[]` (validation.yaml:754)
- **agent_role:** `null` (validation.yaml:755)
- **inputs** (validation.yaml:756-761):
  - **artifacts** (validation.yaml:757-760):
    - `validation/{target_app_id}/g-v1-evidence.json`
    - `validation/{target_app_id}/g-v2-evidence.json`
    - `validation/{target_app_id}/g-v3-evidence.json`  ⚠️ GOTCHA: g-v3-evidence is listed
      unconditionally as an input, but per the purpose note it is only present for Tier-1;
      Tier-2/3 runs parse only G-V1/G-V2. Rebuild must tolerate a missing g-v3-evidence.json.
  - **context:** `[target_app_id, risk_tier]` (validation.yaml:761)
- **outputs** (validation.yaml:762-778):
  - **artifacts:** `[]` (validation.yaml:763)
  - **side_effects** (validation.yaml:764-778):
    - target: `application` (validation.yaml:765)
    - **fields** (validation.yaml:766-772):
      - `validation_parity_score`
      - `validation_critical_vuln_count`
      - `validation_accessibility_score`
      - `validation_safety_case_ref`
      - `validation_completed_at`
      - `validation_current_status`
    - **notes** (folded `>`, validation.yaml:773-778):
      > validation_current_status enum: validation_in_progress →
      > validation_parity_approved → validation_compliance_approved →
      > validation_complete (all gates merged) OR validation_failed
      > (rework exhausted). validation_safety_case_ref is NULL for
      > Tier-2/Tier-3 by design.
      - ⚠️ GOTCHA: `validation_current_status` is an ordered state enum with EXACTLY these
        transitions: `validation_in_progress` → `validation_parity_approved` →
        `validation_compliance_approved` → `validation_complete` (terminal, all gates merged)
        OR `validation_failed` (terminal, rework exhausted). ⚠️ GOTCHA:
        `validation_safety_case_ref` is **NULL for Tier-2/Tier-3 by design** — not an error.
- **agent_contract** (validation.yaml:779-784):
  - **mcp_servers:** `[]` (validation.yaml:780)
  - **repos:** `artifact: none`, `source: none`, `target: ro` (validation.yaml:782-784)  ⚠️ GOTCHA:
    `target: ro` (read-only) even though this step writes the validation fields. The write
    target is the `application` DB projection (a `side_effect`), not the target git repo — the
    repo is only read. Do not grant `target: rw` here.
- **parallel_with:** `[]` (validation.yaml:785)
- **gate:** `null` (validation.yaml:786)
- **retry_policy:** `category: validation_failure` (validation.yaml:787-788)

---

### STEP 20 — `merge-final-gate-pr` (validation.yaml:790-829)

- **id:** `merge-final-gate-pr` (validation.yaml:790)
- **label:** `Merge Final Gate PR` (validation.yaml:791)
- **kind:** `git` (validation.yaml:792)
- **scope:** `per-app` (validation.yaml:793)
- **sequence:** `20` (validation.yaml:794)
- **progress_pct:** `98` (validation.yaml:795)
- **purpose** (folded `>`, validation.yaml:796-799):
  > Final merge of the last approved gate PR (G-V2 for Tier-2/Tier-3, G-V3 for Tier-1). Emits
  > ValidationApprovedSignal to Deployment so it can proceed with environment provisioning +
  > deploy execution.
  - ⚠️ GOTCHA: which PR is "final" is tier-dependent: **G-V2 PR for Tier-2/Tier-3, G-V3 PR for
    Tier-1.**
- **skills:** `[]` (validation.yaml:801)
- **agent_role:** `null` (validation.yaml:802)
- **inputs** (validation.yaml:803-804):
  - **artifacts:** `[]` (validation.yaml:803)  ⚠️ GOTCHA: the only step (besides gate steps) with
    empty input artifacts — it operates purely on context + a previously-opened PR.
  - **context:** `[target_app_id, portfolio_id, pr_number, risk_tier]` (validation.yaml:804)
- **outputs** (validation.yaml:805-819):
  - **artifacts:** `[]` (validation.yaml:806)
  - **side_effects** (validation.yaml:807-819) — TWO side-effect entries:
    1. **target: `application`** (validation.yaml:808-809); fields:
       `[current_line, current_status, updated_at]`
    2. **signal entry** (validation.yaml:810-819):
       - **signal:** `ValidationApprovedSignal` (validation.yaml:810)
       - **fields** (validation.yaml:811-815):
         - `target_app_id`
         - `portfolio_id`
         - `validation_output_refs`
         - `approved_at`
       - **target:** `DeploymentWorkflow` (validation.yaml:816)
       - **notes** (folded `>`, validation.yaml:817-819):
         > Signal shape is new in this contract. Deployment reads the
         > signal's validation_output_refs to compile its cATO package.
       - ⚠️ GOTCHA: This side-effect entry uses keys `signal` + `target` + `fields` + `notes`
         (a *signal* emission, NOT a DB-table side-effect). It is structurally different from
         the table side-effects elsewhere (which use `target` + `fields` only, where `target`
         is a DB table). Here `target` is a **Temporal workflow** (`DeploymentWorkflow`) and the
         emission is a cross-workflow signal `ValidationApprovedSignal`. Rebuild must signal the
         Deployment workflow with EXACTLY these 4 fields. This is the hand-off out of Validation.
- **agent_contract** (validation.yaml:820-825):
  - **mcp_servers:** `[]` (validation.yaml:821)
  - **repos:** `artifact: none`, `source: none`, `target: rw` (validation.yaml:823-825)
- **parallel_with:** `[]` (validation.yaml:826)
- **gate:** `null` (validation.yaml:827)
- **retry_policy:** `category: agent_failure` (validation.yaml:828-829)  ⚠️ GOTCHA: this final
  merge step uses `category: agent_failure` for retry, NOT `transient` — unusual for a
  `kind: git` step (the other git steps `create-g-v1/v2/v3-pr` all use `transient`). Preserve
  exactly.

---

## 3. Cross-Step Invariants & Derived Behavior (for parity)

These are derived from the fields above; reproduced so a rebuild matches behavior.

1. **`sequence` is contiguous 1..20** and matches file order. `progress_pct` is monotonically
   non-decreasing: 5, 8, 15, 20, 25, 30, 32, 36, 40, 45, 48, 52, 56, 62, 68, 72, 76, 82, 90, 98.
   ⚠️ GOTCHA: it never reaches 100 — the line completes at 98 (`merge-final-gate-pr`); the jump
   to "done" is implied by the emitted `ValidationApprovedSignal`, not a 100% step.

2. **`kind` distribution:** `code` ×5 (intake, bundle-g-v1, bundle-g-v2, bundle-g-v3,
   persist-validation-side-effects), `agent` ×8 (formal-test-plan-authoring, functional-parity,
   security-compliance, accessibility-ux, security-anomaly-resolution, ai-pre-review-v2,
   safety-assurance, ai-pre-review-v3), `git` ×4 (create-g-v1-pr, create-g-v2-pr, create-g-v3-pr,
   merge-final-gate-pr), `gate` ×3 (gate-review-v1, gate-review-v2, gate-review-v3). Total = 20.

3. **`retry_policy.category` distribution:** `transient` on all `code` steps + the 3 `create-*-pr`
   git steps (8 total); `agent_failure` on all `agent` steps + `merge-final-gate-pr` (9 total);
   `validation_failure` on the 3 `gate` steps (3 total). Total = 20.
   ⚠️ GOTCHA: the only categories present are `{transient, agent_failure, validation_failure}`.

4. **`gate` field set only on the 3 gate steps** (`G-V1`/`G-V2`/`G-V3`); `null` on the other 17.

5. **Only concurrency edges:** the triad functional-parity ↔ security-compliance ↔
   accessibility-ux. Every other step is serial (`parallel_with: []`).

6. **`mcp_servers`:** `[olympus]` on all `agent` steps (8); `[]` on every `code`/`git`/`gate`
   step. No other MCP server is referenced.

7. **`skills` non-empty only on agent steps:** formal-test-plan-authoring→[formal-test-plan-generator];
   functional-parity→[parity-verifier, acceptable-divergences];
   security-compliance→[security-scan-review, cato-evidence-validator];
   accessibility-ux→[accessibility-checker, design-system];
   security-anomaly-resolution→[security-anomaly-resolution];
   ai-pre-review-v2→[gate-pre-review]; safety-assurance→[safety-critical-verifier, traceability-checker];
   ai-pre-review-v3→[gate-pre-review]. All other steps `skills: []`.

8. **Tier branching summary (load-bearing):**
   - T3: formal-test-plan = smoke-only variant; G-V1 parity floor 95%; G-V2 single PM signal;
     NO safety-assurance / G-V3; `validation_safety_case_ref` = NULL; final merge = G-V2 PR.
   - T2: formal-test-plan = full; G-V1 floor 98%; G-V2 single PM signal; NO safety stream;
     `validation_safety_case_ref` = NULL; final merge = G-V2 PR.
   - T1: formal-test-plan = full; G-V1 floor 99%; G-V2 triple-signal
     (PM + g-v2-compliance + g-v2-security); runs safety-assurance + G-V3 (triple-signal
     PM + g-v3-safety + g-v3-cert; traceability ≥ 99%); final merge = G-V3 PR.

9. **Side-effect targets observed (exhaustive):** DB table `application` (steps intake, persist,
   merge-final), DB table `gate_record` (the 3 gate steps), DB table `gate_pre_review`
   (ai-pre-review-v2, ai-pre-review-v3), and Temporal signal `ValidationApprovedSignal` →
   `DeploymentWorkflow` (merge-final-gate-pr only). No other side-effect targets.

---

## 4. STEP INVENTORY

STEP INVENTORY: intake, formal-test-plan-authoring, functional-parity, security-compliance, accessibility-ux, security-anomaly-resolution, bundle-g-v1-evidence, create-g-v1-pr, gate-review-v1, bundle-g-v2-evidence, create-g-v2-pr, ai-pre-review-v2, gate-review-v2, safety-assurance, bundle-g-v3-evidence, create-g-v3-pr, ai-pre-review-v3, gate-review-v3, persist-validation-side-effects, merge-final-gate-pr

STEPS REPRODUCED: 20

> NOTE: The source file `validation.yaml` contains exactly 20 steps under `steps:` (verified by
> grep + line-range filtering; file is 829 lines, ends at the `merge-final-gate-pr` block). The
> task brief's "23" counts the 3 `gates:` metadata entries (G-V1/G-V2/G-V3) plus the 20 steps
> = 23 total `- id:` tokens. All 20 steps AND all 3 gate entries are reproduced above. Emitting
> 23 *steps* would be a fabrication and a behavioral-parity failure. See GOTCHA 0.
