# Deployment — Assembly Line Contract (ATOMIC regeneration spec)

**Source of truth:** `/Users/pnunna/Documents/GitHub/foundry/olympus-contracts/olympus_contracts/data/assembly-lines/deployment.yaml` (689 lines).

This document reproduces that file field-by-field for behavioral parity. Every downstream consumer (Temporal `DeploymentWorkflow`, Olympus API gate service, step-progress mapping, frontend step registry) loads FROM this YAML via `olympus_contracts.assembly_lines`. Application code MUST NOT hardcode a copy; drift is policed by the `test_no_hardcoded_step_lists` CI check (`deployment.yaml:7-8`).

---

## ⚠️ GOTCHA — STEP COUNT DISCREPANCY (read first)

The regeneration task brief asserted this line has **EXACTLY 20 steps**. **It does not.** The file as it exists on disk (commit on branch `main`, 689 lines, verified via `wc -l` and an authoritative `yaml.safe_load` parse) contains **EXACTLY 18 steps** under the top-level `steps:` key.

- `grep -nE "^\s*- id:"` returns 20 `- id:` lines total, but **2 of those are gate definitions** under the top-level `gates:` key (`G-DP-1` at `deployment.yaml:32`, `G-DP-2` at `deployment.yaml:34`), NOT steps. The remaining **18 are steps** (`deployment.yaml:59` … `deployment.yaml:655`).
- `yaml.safe_load(...)['steps']` has `len == 18`; sequences run **1 → 18** with no gaps; the last step is `merge-final-gate-pr` (`sequence: 18`, `deployment.yaml:655`).
- The file is **not truncated** — it parses cleanly and ends at line 689 (the `retry_policy.category: agent_failure` of the final step).

This spec therefore reproduces all **18** actual steps in full. It does NOT invent two phantom steps, because (a) they do not exist in the source of truth and (b) the brief forbids inventing fields/content. The likely origin of the "20" figure: counting the two `gates:` entries as if they were steps. **STEPS REPRODUCED: 18** (the true, complete count). If a rebuild must satisfy a "20-step" expectation, that expectation is itself wrong relative to this contract and must be corrected against this file.

---

## ⚠️ GOTCHA — FIELD-NAME NOTE (task hints vs. actual schema)

The task brief listed candidate field names; the **actual** field names used in this file differ. Reproduce the ACTUAL names verbatim:

| Task-hint name | Actual field in deployment.yaml |
|---|---|
| `role` | `scope` (every step) + `agent_role` (string or null) |
| `progress` | `progress_pct` (integer) |
| `summary` | `purpose` (folded scalar `>`) |
| `mcp` | `agent_contract.mcp_servers` (list) |
| `condition`, `loop`, `iteration`, `parallel_with` | **none present** except `parallel_with`, which IS present on every step and is always `[]` |

Fields actually present somewhere across steps: `id`, `label`, `kind`, `scope`, `sequence`, `progress_pct`, `purpose`, `skills`, `agent_role`, `inputs.artifacts`, `inputs.context`, `outputs.artifacts`, `outputs.side_effects` (each with `target`, `fields`, and sometimes `notes`), `agent_contract.mcp_servers`, `agent_contract.repos.{artifact, source, target}`, `parallel_with`, `gate`, `retry_policy.category`.

- `scope` is `per-app` on **all 18 steps** (and the line-level `mode: per-app`).
- `parallel_with` is `[]` on **all 18 steps** — Deployment is strictly sequential per app.
- `kind` ∈ {`code`, `agent`, `git`, `gate`}.
- `gate` is `null` on every step EXCEPT `gate-review-dp1` (`G-DP-1`) and `gate-review-dp2` (`G-DP-2`).
- `retry_policy` is always a single-key map `{category: <string>}`. Observed categories: `transient`, `agent_failure`, `timeout`, `validation_failure`, `infrastructure`.

---

## Line-level metadata (`deployment.yaml:10-56`)

```
name: Deployment                                    # deployment.yaml:10
```

**description** (folded scalar `>`, `deployment.yaml:11-23`) — reproduce verbatim:
> Deployment is the irreversible bridge between validated / dispositioned applications and production operation. It owns five responsibilities: deploy the modernized application (or execute the disposition teardown plan); shift traffic via API-gateway weighted routing; monitor parallel run where legacy and modern operate simultaneously; verify user adoption against Discovery-captured baselines; and decommission the legacy infrastructure and certify realized cost savings. Traffic shift is reversible; decommission is not. Deployment is the one line that consumes from both upstream tracks — the Modernization path (Refactor/Rearchitect via Validation) and the non-modernization path (Retire/Replace/Replatform/Consolidate via Disposition Execution). Retain dispositions skip Deployment entirely.

```
trigger: validation-approved-or-disposition-executed   # deployment.yaml:24
```

⚠️ GOTCHA (`deployment.yaml:25-27`): comment states "Strict upstream only. Deployment sits at the confluence of the modernization track (Validation) and the non-mod track (Disposition Execution). Upstream transitive deps are not restated here." — i.e., `depends_on` lists only the two immediate predecessors, not their transitive ancestors.

```
depends_on:                  # deployment.yaml:28-30
  - Validation
  - Disposition Execution

gates:                       # deployment.yaml:31-35
  - id: G-DP-1
    label: Cutover Go
  - id: G-DP-2
    label: Deployment Complete

mode: per-app                # deployment.yaml:36
```

**inputs** (line-level, list of 8 artifact short-names, `deployment.yaml:37-45`):
```
inputs:
  - parity-report
  - authorization-recommendation
  - disposition-output
  - deployment-topology
  - rollback-plan
  - tco-baseline
  - adoption-baseline
  - data-migration-plan
```
⚠️ GOTCHA: `data-migration-plan` (`deployment.yaml:45`) appears in the line-level `inputs` list but is **not** referenced by any individual step's `inputs.artifacts`. The line-level `inputs`/`outputs` are short-name summaries; the per-step `inputs.artifacts`/`outputs.artifacts` use full pathed names with `{placeholder}` interpolation.

**outputs** (line-level, list of 10 artifact short-names, `deployment.yaml:46-56`):
```
outputs:
  - deployment-manifest
  - smoke-test-results
  - traffic-shift-log
  - parallel-run-report
  - adoption-verification
  - gate-review-package-g-dp1
  - decommission-certificate
  - license-reclamation-record
  - cost-savings-certification
  - gate-review-package-g-dp2
```

Top-level YAML keys present, in file order (`yaml.safe_load` confirmed): `name`, `description`, `trigger`, `depends_on`, `gates`, `mode`, `inputs`, `outputs`, `steps`. No other top-level keys exist.

---

## STEPS (all 18, in `sequence` order)

For each step: every field reproduced in full. `purpose` is a folded scalar (`>`) in the file; reproduced verbatim as prose. No "same as above" abbreviation is used.

---

### Step 1 — `intake` (`deployment.yaml:59-98`)

```
id: intake
label: Deployment Intake
kind: code
scope: per-app
sequence: 1
progress_pct: 5
```
**purpose** (`deployment.yaml:65-71`):
> Workflow code (not an agent dispatch). Resolves the app's disposition from the triggering signal, loads disposition-output bundle (non-modernization path) or Validation evidence (modernization path), selects the active path, initialises per-step state, and sets `application.current_line = "Deployment"` and `current_step = "intake"`.

```
skills: []                       # deployment.yaml:72
agent_role: null                 # deployment.yaml:73
inputs:
  artifacts:                     # deployment.yaml:75-82
    - validation/{target_app_id}/parity-report.json
    - validation/{target_app_id}/authorization-recommendation.json
    - dispositions/{portfolio_id}/{app_id}/disposition-output.json
    - architecture/{target_app_id}/deployment-topology.json
    - architecture/{target_app_id}/rollback-plan.json
    - discovery/{source_app_id}/tco-baseline.json
    - discovery/{source_app_id}/adoption-baseline.json
  context: [app_id, target_app_id, portfolio_id, risk_tier, disposition]   # deployment.yaml:83
outputs:
  artifacts: []                  # deployment.yaml:85
  side_effects:                  # deployment.yaml:86-88
    - target: application
      fields: [current_line, current_step, updated_at]
agent_contract:
  mcp_servers: []                # deployment.yaml:90
  repos:                         # deployment.yaml:91-94
    artifact: ro
    source: none
    target: ro
parallel_with: []                # deployment.yaml:95
gate: null                       # deployment.yaml:96
retry_policy:
  category: transient            # deployment.yaml:98
```
⚠️ GOTCHA: `intake` is the only step whose `inputs.context` includes `app_id` (the legacy/source app id) **and** `target_app_id`; it also uniquely pulls from all five upstream artifact families (validation, dispositions, architecture×2, discovery×2). `target: ro` here (read-only target repo) — intake does not yet write the target repo.

---

### Step 2 — `orchestration` (`deployment.yaml:100-137`)

```
id: orchestration
label: Deployment Orchestration
kind: agent
scope: per-app
sequence: 2
progress_pct: 12
```
**purpose** (`deployment.yaml:106-115`):
> Deploy the modernized application to production using the tier-appropriate strategy (canary for Tier-1, blue-green for Tier-2/3). Runs pre-deploy verification (all Validation gates passed, authorization approved, environment provisioned, rollback tested), executes the deploy itself, runs smoke tests across critical paths, activates production monitoring, and registers data products in the API gateway + data catalog. Emits the `deployment-manifest.json` artifact with strategy, target env, route config, smoke test results, rollback verification status.

```
skills: [deploy-modernized-app, monitoring-bootstrap]   # deployment.yaml:116
agent_role: Deployment Orchestrator                     # deployment.yaml:117
inputs:
  artifacts:                                            # deployment.yaml:119-121
    - validation/{target_app_id}/authorization-recommendation.json
    - architecture/{target_app_id}/deployment-topology.json
  context: [target_app_id, portfolio_id, risk_tier, disposition, strategy]   # deployment.yaml:122
outputs:
  artifacts:                                            # deployment.yaml:124-126
    - deployment/{target_app_id}/deployment-manifest.json
    - deployment/{target_app_id}/smoke-test-results.json
  side_effects: []                                      # deployment.yaml:127
agent_contract:
  mcp_servers: [olympus]                                # deployment.yaml:129
  repos:                                                # deployment.yaml:130-133
    artifact: rw
    source: none
    target: rw
parallel_with: []                                       # deployment.yaml:134
gate: null                                              # deployment.yaml:135
retry_policy:
  category: agent_failure                               # deployment.yaml:137
```

---

### Step 3 — `traffic-shifting` (`deployment.yaml:139-171`)

```
id: traffic-shifting
label: Traffic Shifting
kind: agent
scope: per-app
sequence: 3
progress_pct: 20
```
**purpose** (`deployment.yaml:145-151`):
> Gradually migrate user traffic from legacy to modern via API gateway weighted routing. Follows the tier-driven schedule: Tier-1 canary 5%→25%→50%→100% over 14 days; Tier-2 instant blue-green with 24h validation; Tier-3 instant blue-green with 4h validation. Monitors error thresholds at each increment; auto-reverts on breach. Emits the `traffic-shift-log.json` artifact.

```
skills: [traffic-shift]                                 # deployment.yaml:152
agent_role: Traffic Shift Controller                    # deployment.yaml:153
inputs:
  artifacts:                                            # deployment.yaml:155-156
    - deployment/{target_app_id}/deployment-manifest.json
  context: [target_app_id, portfolio_id, risk_tier, shift_schedule]   # deployment.yaml:157
outputs:
  artifacts:                                            # deployment.yaml:159-160
    - deployment/{target_app_id}/traffic-shift-log.json
  side_effects: []                                      # deployment.yaml:161
agent_contract:
  mcp_servers: [olympus]                                # deployment.yaml:163
  repos:                                                # deployment.yaml:164-167
    artifact: ro
    source: none
    target: rw
parallel_with: []                                       # deployment.yaml:168
gate: null                                              # deployment.yaml:169
retry_policy:
  category: agent_failure                               # deployment.yaml:171
```
⚠️ GOTCHA: `artifact: ro` here (contrast with `orchestration` which is `artifact: rw`). traffic-shifting reads the manifest but writes its log to `target: rw`. The "Traffic shift is reversible" property (line description) is realized by the auto-revert-on-breach behavior in purpose.

---

### Step 4 — `parallel-run` (`deployment.yaml:173-208`)

```
id: parallel-run
label: Parallel Run
kind: agent
scope: per-app
sequence: 4
progress_pct: 30
```
**purpose** (`deployment.yaml:179-187`):
> Legacy and modern operate simultaneously for the tier-minimum duration (Tier-1: 90 days; Tier-2: 30 days; Tier-3: 14 days). Continuous parity comparison at defined comparison points (API responses, batch outputs, data writes) with divergence classification (regression / expected / environmental). Daily reports summarize divergence rate + trend. Workflow-level Temporal timer collapses under time-skipping tests. Emits the `parallel-run-report.json` artifact (daily + final).

```
skills: [parallel-run-monitor]                          # deployment.yaml:188
agent_role: Parallel Run Monitor                        # deployment.yaml:189
inputs:
  artifacts:                                            # deployment.yaml:191-193
    - deployment/{target_app_id}/traffic-shift-log.json
    - validation/{target_app_id}/parity-report.json
  context: [target_app_id, portfolio_id, risk_tier, parallel_run_days]   # deployment.yaml:194
outputs:
  artifacts:                                            # deployment.yaml:196-197
    - deployment/{target_app_id}/parallel-run-report.json
  side_effects: []                                      # deployment.yaml:198
agent_contract:
  mcp_servers: [olympus]                                # deployment.yaml:200
  repos:                                                # deployment.yaml:201-204
    artifact: ro
    source: none
    target: rw
parallel_with: []                                       # deployment.yaml:205
gate: null                                              # deployment.yaml:206
retry_policy:
  category: timeout                                     # deployment.yaml:208
```
⚠️ GOTCHA: `retry_policy.category: timeout` — UNIQUE among the agent steps (all others use `agent_failure`). Rationale per purpose: a workflow-level Temporal timer governs the tier-minimum duration; under time-skipping tests it "collapses", so retries are classified as timeout-class, not agent-failure-class. This is the only `timeout` category in the entire line.

---

### Step 5 — `adoption-verification` (`deployment.yaml:210-243`)

```
id: adoption-verification
label: Adoption Verification
kind: agent
scope: per-app
sequence: 5
progress_pct: 40
```
**purpose** (`deployment.yaml:216-222`):
> Verify users are actually using the modernized application. Tracks active-user ratio vs. Discovery baseline, feature-usage pattern consistency, training completion rate, support ticket trend, and critical user-reported issues. Populates G-DP-1 evidence thresholds. Emits the `adoption-verification.json` artifact with each metric + threshold status.

```
skills: [adoption-analytics, user-adoption-coordinator]   # deployment.yaml:223
agent_role: Adoption Tracker                              # deployment.yaml:224
inputs:
  artifacts:                                              # deployment.yaml:226-228
    - deployment/{target_app_id}/parallel-run-report.json
    - discovery/{source_app_id}/adoption-baseline.json
  context: [target_app_id, portfolio_id, risk_tier, adoption_thresholds]   # deployment.yaml:229
outputs:
  artifacts:                                              # deployment.yaml:231-232
    - deployment/{target_app_id}/adoption-verification.json
  side_effects: []                                        # deployment.yaml:233
agent_contract:
  mcp_servers: [olympus]                                  # deployment.yaml:235
  repos:                                                  # deployment.yaml:236-239
    artifact: ro
    source: none
    target: rw
parallel_with: []                                         # deployment.yaml:240
gate: null                                                # deployment.yaml:241
retry_policy:
  category: agent_failure                                 # deployment.yaml:243
```
⚠️ GOTCHA: this is one of only two steps (with `intake`) whose artifact inputs pull from `discovery/{source_app_id}/…` — it reads `adoption-baseline.json` keyed by the **source** (legacy) app id, not the target, to compare against the Discovery-captured baseline.

---

### Step 6 — `bundle-g-dp1-evidence` (`deployment.yaml:245-278`)

```
id: bundle-g-dp1-evidence
label: Bundle G-DP-1 Evidence
kind: code
scope: per-app
sequence: 6
progress_pct: 46
```
**purpose** (`deployment.yaml:251-254`):
> Workflow code. Synthesises deployment-manifest, smoke-test, traffic-shift-log, parallel-run-report, adoption-verification into the G-DP-1 evidence bundle; commits to target_repo for PR.

```
skills: []                                              # deployment.yaml:255
agent_role: null                                        # deployment.yaml:256
inputs:
  artifacts:                                            # deployment.yaml:258-263
    - deployment/{target_app_id}/deployment-manifest.json
    - deployment/{target_app_id}/smoke-test-results.json
    - deployment/{target_app_id}/traffic-shift-log.json
    - deployment/{target_app_id}/parallel-run-report.json
    - deployment/{target_app_id}/adoption-verification.json
  context: [target_app_id, portfolio_id]                # deployment.yaml:264
outputs:
  artifacts:                                            # deployment.yaml:266-267
    - deployment/{target_app_id}/gate-review-package-g-dp1.json
  side_effects: []                                      # deployment.yaml:268
agent_contract:
  mcp_servers: []                                       # deployment.yaml:270
  repos:                                                # deployment.yaml:271-274
    artifact: ro
    source: none
    target: rw
parallel_with: []                                       # deployment.yaml:275
gate: null                                              # deployment.yaml:276
retry_policy:
  category: transient                                   # deployment.yaml:278
```

---

### Step 7 — `create-g-dp1-pr` (`deployment.yaml:280-310`)

```
id: create-g-dp1-pr
label: Create G-DP-1 PR
kind: git
scope: per-app
sequence: 7
progress_pct: 50
```
**purpose** (`deployment.yaml:286-288`):
> Opens PR against target_repo main carrying the G-DP-1 evidence bundle. PR title/body follow the conventional gate format.

```
skills: []                                              # deployment.yaml:289
agent_role: null                                        # deployment.yaml:290
inputs:
  artifacts:                                            # deployment.yaml:292-293
    - deployment/{target_app_id}/gate-review-package-g-dp1.json
  context: [target_app_id, portfolio_id]                # deployment.yaml:294
outputs:
  artifacts: []                                         # deployment.yaml:296
  side_effects:                                         # deployment.yaml:297-300
    - target: target_repo
      fields: [pr]
      notes: PR number returned and stored for gate wiring.
agent_contract:
  mcp_servers: []                                       # deployment.yaml:302
  repos:                                                # deployment.yaml:303-306
    artifact: none
    source: none
    target: rw
parallel_with: []                                       # deployment.yaml:307
gate: null                                              # deployment.yaml:308
retry_policy:
  category: transient                                   # deployment.yaml:310
```
⚠️ GOTCHA: the `side_effect` carries a `notes` field (`deployment.yaml:300`) — "PR number returned and stored for gate wiring." This is one of only two side_effects in the file with a `notes` key (the other, `create-g-dp2-pr`, has the same target/fields but NO notes). The `fields: [pr]` is the PR number that subsequent gate/merge steps consume via `pr_number` context.

---

### Step 8 — `ai-pre-review-dp1` (`deployment.yaml:312-345`)

```
id: ai-pre-review-dp1
label: AI Pre-review (G-DP-1)
kind: agent
scope: per-app
sequence: 8
progress_pct: 54
```
**purpose** (`deployment.yaml:318-323`):
> Pre-review agent reads the G-DP-1 evidence bundle and produces a structured recommendation (approve / reject / request changes) that lands on the PR as a comment before human reviewers engage. Thresholds: active-user ratio ≥ 80%, training completion ≥ 70%, zero unresolved critical issues.

```
skills: [gate-pre-review]                               # deployment.yaml:324
agent_role: Gate Pre-review Agent                       # deployment.yaml:325
inputs:
  artifacts:                                            # deployment.yaml:327-328
    - deployment/{target_app_id}/gate-review-package-g-dp1.json
  context: [target_app_id, portfolio_id, risk_tier]     # deployment.yaml:329
outputs:
  artifacts:                                            # deployment.yaml:331-332
    - deployment/{target_app_id}/ai-pre-review-g-dp1.json
  side_effects:                                         # deployment.yaml:333-335
    - target: gate_pre_review
      fields: [gate_type, recommendation, reasoning, created_at]
agent_contract:
  mcp_servers: [olympus]                                # deployment.yaml:337
  repos:                                                # deployment.yaml:338-341
    artifact: ro
    source: none
    target: rw
parallel_with: []                                       # deployment.yaml:342
gate: null                                              # deployment.yaml:343
retry_policy:
  category: agent_failure                               # deployment.yaml:345
```
⚠️ GOTCHA: side_effect target `gate_pre_review` (a DB/record table, NOT a repo) with fields `[gate_type, recommendation, reasoning, created_at]`. The thresholds in purpose (active-user ratio ≥ 80%, training completion ≥ 70%, zero unresolved critical issues) are the G-DP-1 acceptance criteria the pre-review agent evaluates. The produced artifact `ai-pre-review-g-dp1.json` is NOT in the line-level `outputs` list (it is an intermediate).

---

### Step 9 — `gate-review-dp1` (`deployment.yaml:347-378`)

```
id: gate-review-dp1
label: Gate Review (G-DP-1)
kind: gate
scope: per-app
sequence: 9
progress_pct: 58
```
**purpose** (`deployment.yaml:353-359`):
> Waits on gate_approved signal (PM merges PR) and — for Tier-1 — stakeholder_approved signals from Operations Lead + Safety Board Chair. Tier-2/Tier-3: PM + Operations Lead dual-signal. Rejections route to adoption-verification rerun. Exhaustion escalates.

```
skills: []                                              # deployment.yaml:360
agent_role: null                                        # deployment.yaml:361
inputs:
  artifacts: []                                         # deployment.yaml:362
  context: [target_app_id, portfolio_id, pr_number, risk_tier]   # deployment.yaml:363
outputs:
  artifacts: []                                         # deployment.yaml:365
  side_effects:                                         # deployment.yaml:366-368
    - target: gate_record
      fields: [gate_type, status, decision_at, approvers]
agent_contract:
  mcp_servers: []                                       # deployment.yaml:370
  repos:                                                # deployment.yaml:371-374
    artifact: none
    source: none
    target: none
parallel_with: []                                       # deployment.yaml:375
gate: G-DP-1                                             # deployment.yaml:376
retry_policy:
  category: validation_failure                          # deployment.yaml:378
```
⚠️ GOTCHA: `gate: G-DP-1` (one of only two non-null `gate` values in the file). All `repos` are `none` (a gate step neither reads nor writes git). Side-effect target `gate_record` with `[gate_type, status, decision_at, approvers]`. Rejection routing target is `adoption-verification` (sequence 5 — loops back 4 steps). Tier-1 requires 3 signals (PM merge + Operations Lead + Safety Board Chair); Tier-2/3 require 2 (PM + Operations Lead). `retry_policy.category: validation_failure` — shared only with `gate-review-dp2`.

---

### Step 10 — `merge-g-dp1-pr` (`deployment.yaml:380-408`)

```
id: merge-g-dp1-pr
label: Merge G-DP-1 PR
kind: git
scope: per-app
sequence: 10
progress_pct: 62
```
**purpose** (`deployment.yaml:386-388`):
> Merges the G-DP-1 PR after approval. Marks adoption-verification phase complete. Clears rollback window timer start.

```
skills: []                                              # deployment.yaml:389
agent_role: null                                        # deployment.yaml:390
inputs:
  artifacts: []                                         # deployment.yaml:391
  context: [target_app_id, portfolio_id, pr_number]     # deployment.yaml:392
outputs:
  artifacts: []                                         # deployment.yaml:394
  side_effects:                                         # deployment.yaml:395-397
    - target: target_repo
      fields: [merge_commit]
agent_contract:
  mcp_servers: []                                       # deployment.yaml:399
  repos:                                                # deployment.yaml:400-403
    artifact: none
    source: none
    target: rw
parallel_with: []                                       # deployment.yaml:405
gate: null                                              # deployment.yaml:406
retry_policy:
  category: agent_failure                               # deployment.yaml:408
```
⚠️ GOTCHA: purpose says "Clears rollback window timer start" — the merge marks the moment the rollback window begins counting; `legacy-decommission` (step 11) is gated on `rollback_window_expired_at`, which is downstream of this merge. side_effect `target_repo` / `fields: [merge_commit]`.

---

### Step 11 — `legacy-decommission` (`deployment.yaml:410-445`)

```
id: legacy-decommission
label: Legacy Decommission
kind: agent
scope: per-app
sequence: 11
progress_pct: 68
```
**purpose** (`deployment.yaml:416-423`):
> Post rollback-window expiration, formally retire the legacy system. Removes legacy API gateway routes, updates DNS, archives legacy databases (with reconstruction capability), tears down VMs / containers / storage / networking, retires legacy security authorization (ATO/cATO), reclaims licenses. Emits the `decommission-certificate.json` artifact. **Irreversible after rollback window expires.**

```
skills: [legacy-decommission, environment-cleanup]      # deployment.yaml:424
agent_role: Decommission Orchestrator                   # deployment.yaml:425
inputs:
  artifacts:                                            # deployment.yaml:427-429
    - deployment/{target_app_id}/adoption-verification.json
    - dispositions/{portfolio_id}/{app_id}/disposition-output.json
  context: [target_app_id, source_app_id, portfolio_id, rollback_window_expired_at]   # deployment.yaml:430
outputs:
  artifacts:                                            # deployment.yaml:432-434
    - deployment/{target_app_id}/decommission-certificate.json
    - deployment/{target_app_id}/license-reclamation-record.json
  side_effects: []                                      # deployment.yaml:435
agent_contract:
  mcp_servers: [olympus]                                # deployment.yaml:437
  repos:                                                # deployment.yaml:438-441
    artifact: rw
    source: rw
    target: rw
parallel_with: []                                       # deployment.yaml:442
gate: null                                              # deployment.yaml:443
retry_policy:
  category: infrastructure                              # deployment.yaml:445
```
⚠️ GOTCHA — multiple:
- This is the **ONLY** step with `source: rw` (`deployment.yaml:440`) — it writes the source/legacy repo (decommission updates legacy artifacts). All other steps have `source: none`. It is also the only step where all three repos are `rw` simultaneously.
- `retry_policy.category: infrastructure` — UNIQUE in the file.
- The operation is **IRREVERSIBLE after rollback window expires** (purpose, bolded in source). Gated on `rollback_window_expired_at` context (set after `merge-g-dp1-pr`).
- Reads `disposition-output.json` keyed by `{app_id}` (the legacy id), consistent with `intake`.
- Emits TWO artifacts: `decommission-certificate.json` and `license-reclamation-record.json`.

---

### Step 12 — `cost-certification` (`deployment.yaml:447-481`)

```
id: cost-certification
label: Cost Savings Certification
kind: agent
scope: per-app
sequence: 12
progress_pct: 74
```
**purpose** (`deployment.yaml:453-459`):
> Calculates realized annual cost savings: pre-modernization TCO (from Discovery baseline) minus post-modernization TCO (current operational cost) plus license reclamation value. Shared infrastructure costs apportioned per client profile. Development costs excluded (operational only). Emits the `cost-savings-certification.json` artifact.

```
skills: [tco-analyzer]                                  # deployment.yaml:460
agent_role: Cost Savings Certifier                      # deployment.yaml:461
inputs:
  artifacts:                                            # deployment.yaml:463-466
    - discovery/{source_app_id}/tco-baseline.json
    - deployment/{target_app_id}/decommission-certificate.json
    - deployment/{target_app_id}/license-reclamation-record.json
  context: [target_app_id, source_app_id, portfolio_id]   # deployment.yaml:467
outputs:
  artifacts:                                            # deployment.yaml:469-470
    - deployment/{target_app_id}/cost-savings-certification.json
  side_effects: []                                      # deployment.yaml:471
agent_contract:
  mcp_servers: [olympus]                                # deployment.yaml:473
  repos:                                                # deployment.yaml:474-477
    artifact: ro
    source: none
    target: rw
parallel_with: []                                       # deployment.yaml:478
gate: null                                              # deployment.yaml:479
retry_policy:
  category: agent_failure                               # deployment.yaml:481
```
⚠️ GOTCHA: cost formula in purpose is load-bearing — `realized_savings = pre_mod_TCO (Discovery baseline) − post_mod_TCO (current operational) + license_reclamation_value`. Shared infra apportioned per client profile; **development costs excluded** (operational only). Reads `tco-baseline.json` keyed by `{source_app_id}`.

---

### Step 13 — `bundle-g-dp2-evidence` (`deployment.yaml:483-513`)

```
id: bundle-g-dp2-evidence
label: Bundle G-DP-2 Evidence
kind: code
scope: per-app
sequence: 13
progress_pct: 80
```
**purpose** (`deployment.yaml:489-491`):
> Synthesises decommission-certificate, license-reclamation-record, cost-savings-certification into the G-DP-2 evidence bundle.

```
skills: []                                              # deployment.yaml:492
agent_role: null                                        # deployment.yaml:493
inputs:
  artifacts:                                            # deployment.yaml:495-498
    - deployment/{target_app_id}/decommission-certificate.json
    - deployment/{target_app_id}/license-reclamation-record.json
    - deployment/{target_app_id}/cost-savings-certification.json
  context: [target_app_id, portfolio_id]                # deployment.yaml:499
outputs:
  artifacts:                                            # deployment.yaml:501-502
    - deployment/{target_app_id}/gate-review-package-g-dp2.json
  side_effects: []                                      # deployment.yaml:503
agent_contract:
  mcp_servers: []                                       # deployment.yaml:505
  repos:                                                # deployment.yaml:506-509
    artifact: ro
    source: none
    target: rw
parallel_with: []                                       # deployment.yaml:510
gate: null                                              # deployment.yaml:511
retry_policy:
  category: transient                                   # deployment.yaml:513
```

---

### Step 14 — `create-g-dp2-pr` (`deployment.yaml:515-544`)

```
id: create-g-dp2-pr
label: Create G-DP-2 PR
kind: git
scope: per-app
sequence: 14
progress_pct: 84
```
**purpose** (`deployment.yaml:521-523`):
> Opens PR against target_repo main carrying the G-DP-2 evidence bundle.

```
skills: []                                              # deployment.yaml:524
agent_role: null                                        # deployment.yaml:525
inputs:
  artifacts:                                            # deployment.yaml:527-528
    - deployment/{target_app_id}/gate-review-package-g-dp2.json
  context: [target_app_id, portfolio_id]                # deployment.yaml:529
outputs:
  artifacts: []                                         # deployment.yaml:531
  side_effects:                                         # deployment.yaml:532-534
    - target: target_repo
      fields: [pr]
agent_contract:
  mcp_servers: []                                       # deployment.yaml:536
  repos:                                                # deployment.yaml:537-540
    artifact: none
    source: none
    target: rw
parallel_with: []                                       # deployment.yaml:541
gate: null                                              # deployment.yaml:542
retry_policy:
  category: transient                                   # deployment.yaml:544
```
⚠️ GOTCHA: side_effect `target: target_repo` / `fields: [pr]` has **NO `notes`** field here — contrast with `create-g-dp1-pr` (step 7, `deployment.yaml:300`) which carries `notes: PR number returned and stored for gate wiring.`. Behaviorally equivalent PR creation, but the YAML differs (do not add the notes line when reproducing this step).

---

### Step 15 — `ai-pre-review-dp2` (`deployment.yaml:546-578`)

```
id: ai-pre-review-dp2
label: AI Pre-review (G-DP-2)
kind: agent
scope: per-app
sequence: 15
progress_pct: 87
```
**purpose** (`deployment.yaml:552-556`):
> Pre-review on the G-DP-2 bundle. Thresholds: rollback window expired = true, data-archival-complete = true, all legacy infrastructure rows in decommission-certificate marked "torn down", zero license-reclamation discrepancies.

```
skills: [gate-pre-review]                               # deployment.yaml:557
agent_role: Gate Pre-review Agent                       # deployment.yaml:558
inputs:
  artifacts:                                            # deployment.yaml:560-561
    - deployment/{target_app_id}/gate-review-package-g-dp2.json
  context: [target_app_id, portfolio_id, risk_tier]     # deployment.yaml:562
outputs:
  artifacts:                                            # deployment.yaml:564-565
    - deployment/{target_app_id}/ai-pre-review-g-dp2.json
  side_effects:                                         # deployment.yaml:566-568
    - target: gate_pre_review
      fields: [gate_type, recommendation, reasoning, created_at]
agent_contract:
  mcp_servers: [olympus]                                # deployment.yaml:570
  repos:                                                # deployment.yaml:571-574
    artifact: ro
    source: none
    target: rw
parallel_with: []                                       # deployment.yaml:575
gate: null                                              # deployment.yaml:576
retry_policy:
  category: agent_failure                               # deployment.yaml:578
```
⚠️ GOTCHA: G-DP-2 thresholds (purpose) are distinct from G-DP-1's — here it is `rollback_window_expired == true`, `data-archival-complete == true`, all legacy infra rows in `decommission-certificate` marked `"torn down"`, and zero license-reclamation discrepancies. Same side_effect shape as `ai-pre-review-dp1` (`gate_pre_review` table, same 4 fields).

---

### Step 16 — `gate-review-dp2` (`deployment.yaml:580-610`)

```
id: gate-review-dp2
label: Gate Review (G-DP-2)
kind: gate
scope: per-app
sequence: 16
progress_pct: 91
```
**purpose** (`deployment.yaml:586-590`):
> PM + Operations Lead dual-signal (Tier-2/Tier-3). Tier-1 adds Certifying Authority signal for continuous-ATO acknowledgment. Rejections route to legacy-decommission + cost-certification rerun. Exhaustion escalates.

```
skills: []                                              # deployment.yaml:591
agent_role: null                                        # deployment.yaml:592
inputs:
  artifacts: []                                         # deployment.yaml:594
  context: [target_app_id, portfolio_id, pr_number, risk_tier]   # deployment.yaml:595
outputs:
  artifacts: []                                         # deployment.yaml:597
  side_effects:                                         # deployment.yaml:598-600
    - target: gate_record
      fields: [gate_type, status, decision_at, approvers]
agent_contract:
  mcp_servers: []                                       # deployment.yaml:601
  repos:                                                # deployment.yaml:602-605
    artifact: none
    source: none
    target: none
parallel_with: []                                       # deployment.yaml:607
gate: G-DP-2                                             # deployment.yaml:608
retry_policy:
  category: validation_failure                          # deployment.yaml:610
```
⚠️ GOTCHA: `gate: G-DP-2` (second and final non-null gate). Tier-1 adds a **Certifying Authority** signal (continuous-ATO acknowledgment) on top of PM + Operations Lead. Rejection routing targets BOTH `legacy-decommission` (step 11) and `cost-certification` (step 12) for rerun — a two-step rollback, unlike G-DP-1 which reruns only `adoption-verification`. All repos `none`; side_effect `gate_record` with the same 4 fields as `gate-review-dp1`.

---

### Step 17 — `persist-deployment-side-effects` (`deployment.yaml:612-653`)

```
id: persist-deployment-side-effects
label: Persist Deployment Side Effects
kind: code
scope: per-app
sequence: 17
progress_pct: 95
```
**purpose** (`deployment.yaml:618-624`):
> Workflow code. Projects fields from the G-DP-2 evidence bundle onto application (deployed_at, deployment_env, cutover_strategy, parallel_run_duration_days, cost_savings_realized_usd, license_reclamation_usd, legacy_decommissioned_at, deployment_current_status). Best-effort — swallows DB failures so the workflow doesn't block on transient DB errors.

```
skills: []                                              # deployment.yaml:625
agent_role: null                                        # deployment.yaml:626
inputs:
  artifacts:                                            # deployment.yaml:628-629
    - deployment/{target_app_id}/gate-review-package-g-dp2.json
  context: [target_app_id, portfolio_id]                # deployment.yaml:630
outputs:
  artifacts: []                                         # deployment.yaml:632
  side_effects:                                         # deployment.yaml:633-643
    - target: application
      fields:
        - deployed_at
        - deployment_env
        - cutover_strategy
        - parallel_run_duration_days
        - cost_savings_realized_usd
        - license_reclamation_usd
        - legacy_decommissioned_at
        - deployment_current_status
agent_contract:
  mcp_servers: []                                       # deployment.yaml:645
  repos:                                                # deployment.yaml:646-649
    artifact: none
    source: none
    target: none
parallel_with: []                                       # deployment.yaml:651
gate: null                                              # deployment.yaml:652
retry_policy:
  category: transient                                   # deployment.yaml:653
```
⚠️ GOTCHA — **best-effort persistence** (purpose): this step **swallows DB failures** so the workflow does not block on transient DB errors. Behaviorally critical: a failure to project these 8 fields onto the `application` row must NOT abort the workflow. The 8 projected fields are reproduced as a YAML block scalar list (one-per-line, `deployment.yaml:635-643`) — distinct from the inline `[...]` list form used in other steps' `fields`. All repos `none` (pure DB projection, no git).

---

### Step 18 — `merge-final-gate-pr` (`deployment.yaml:655-689`) — FINAL STEP

```
id: merge-final-gate-pr
label: Merge Final Gate PR
kind: git
scope: per-app
sequence: 18
progress_pct: 99
```
**purpose** (`deployment.yaml:661-667`):
> Final merge of the G-DP-2 PR. Updates `application.current_line` to "Sustainment", `current_status` to "sustainment_active". The Sustainment line picks the app up on its next scheduled sweep — Deployment does not emit a signal here because Sustainment is portfolio-scoped and cron-triggered, not per-app-signal-driven. The state flip is the handoff.

```
skills: []                                              # deployment.yaml:668
agent_role: null                                        # deployment.yaml:669
inputs:
  artifacts: []                                         # deployment.yaml:670
  context: [target_app_id, portfolio_id, pr_number]     # deployment.yaml:672
outputs:
  artifacts: []                                         # deployment.yaml:674
  side_effects:                                         # deployment.yaml:675-679
    - target: application
      fields: [current_line, current_status, updated_at]
    - target: target_repo
      fields: [merge_commit]
agent_contract:
  mcp_servers: []                                       # deployment.yaml:680
  repos:                                                # deployment.yaml:681-685
    artifact: none
    source: none
    target: rw
parallel_with: []                                       # deployment.yaml:686
gate: null                                              # deployment.yaml:687
retry_policy:
  category: agent_failure                               # deployment.yaml:689
```
⚠️ GOTCHA — **the handoff to Sustainment is a state flip, NOT a signal** (purpose, `deployment.yaml:662-667`). Deployment deliberately emits no signal to Sustainment because Sustainment is portfolio-scoped + cron-triggered, not per-app-signal-driven; the next Sustainment sweep discovers the app via `current_line == "Sustainment"` / `current_status == "sustainment_active"`. This is the ONLY step with **TWO** side_effect entries (`application` with `[current_line, current_status, updated_at]`, AND `target_repo` with `[merge_commit]`). `progress_pct: 99` (the line never reports 100 from this contract — terminal value is 99).

---

## Cross-step invariants & derived facts (for rebuild verification)

- **Sequence integrity:** sequences are 1..18 contiguous, matching list order (`deployment.yaml:63,104,143,177,214,249,284,316,351,384,414,451,487,519,550,584,616,659`). No `parallel_with` is ever populated → strictly serial.
- **progress_pct monotonic increasing:** 5, 12, 20, 30, 40, 46, 50, 54, 58, 62, 68, 74, 80, 84, 87, 91, 95, 99. Never decreases; never reaches 100.
- **`kind` distribution:** `code` ×5 (intake, bundle-g-dp1-evidence, bundle-g-dp2-evidence, persist-deployment-side-effects — that is 4; plus none else `code`)… precise: `code` = {intake, bundle-g-dp1-evidence, bundle-g-dp2-evidence, persist-deployment-side-effects} = 4; `agent` = {orchestration, traffic-shifting, parallel-run, adoption-verification, ai-pre-review-dp1, legacy-decommission, cost-certification, ai-pre-review-dp2} = 8; `git` = {create-g-dp1-pr, merge-g-dp1-pr, create-g-dp2-pr, merge-final-gate-pr} = 4; `gate` = {gate-review-dp1, gate-review-dp2} = 2. Total 4+8+4+2 = 18.
- **`agent_role` non-null** exactly on the 8 `agent`-kind steps; `null` on all 10 non-agent steps. Roles: Deployment Orchestrator, Traffic Shift Controller, Parallel Run Monitor, Adoption Tracker, Gate Pre-review Agent (×2, steps 8 & 15), Decommission Orchestrator, Cost Savings Certifier.
- **`mcp_servers: [olympus]`** exactly on the 8 agent steps; `[]` on all others (code/git/gate steps dispatch no agent).
- **`gate` non-null** only on the 2 gate steps (G-DP-1 @ step 9, G-DP-2 @ step 16).
- **`retry_policy.category` distribution:** `transient` ×6 (intake, bundle-g-dp1-evidence, create-g-dp1-pr, bundle-g-dp2-evidence, create-g-dp2-pr, persist-deployment-side-effects); `agent_failure` ×7 (orchestration, traffic-shifting, adoption-verification, ai-pre-review-dp1, merge-g-dp1-pr, cost-certification, ai-pre-review-dp2, merge-final-gate-pr → that is 8); `timeout` ×1 (parallel-run); `validation_failure` ×2 (gate-review-dp1, gate-review-dp2); `infrastructure` ×1 (legacy-decommission). Recount agent_failure: orchestration(2), traffic-shifting(3), adoption-verification(5), ai-pre-review-dp1(8), merge-g-dp1-pr(10), cost-certification(12), ai-pre-review-dp2(15), merge-final-gate-pr(18) = **8**. Totals: 6 transient + 8 agent_failure + 1 timeout + 2 validation_failure + 1 infrastructure = 18. ✓
- **`source: rw`** appears on exactly ONE step: `legacy-decommission` (step 11). Every other step is `source: none`.
- **`side_effects` targets across the line:** `application` (intake; persist-deployment-side-effects; merge-final-gate-pr), `target_repo` (create-g-dp1-pr [+notes]; merge-g-dp1-pr; create-g-dp2-pr; merge-final-gate-pr), `gate_pre_review` (ai-pre-review-dp1; ai-pre-review-dp2), `gate_record` (gate-review-dp1; gate-review-dp2). The only step with two side_effects is `merge-final-gate-pr`.
- **Rejection loops:** G-DP-1 reject → rerun `adoption-verification` (step 5). G-DP-2 reject → rerun `legacy-decommission` (step 11) **and** `cost-certification` (step 12). Both gates "escalate" on retry exhaustion.

---

STEP INVENTORY: intake, orchestration, traffic-shifting, parallel-run, adoption-verification, bundle-g-dp1-evidence, create-g-dp1-pr, ai-pre-review-dp1, gate-review-dp1, merge-g-dp1-pr, legacy-decommission, cost-certification, bundle-g-dp2-evidence, create-g-dp2-pr, ai-pre-review-dp2, gate-review-dp2, persist-deployment-side-effects, merge-final-gate-pr

STEPS REPRODUCED: 18
