# Governance Assembly Line — Step Contract (ATOMIC regeneration spec)

> Source of truth: `/Users/pnunna/Documents/GitHub/foundry/olympus-contracts/olympus_contracts/data/assembly-lines/governance.yaml`
> All citations in this document are `governance.yaml:<line>` against that file.
> This document reproduces the contract field-by-field for behavioral parity. Reproduce EXACTLY.

---

## 0. File header / authoritative-source banner (governance.yaml:1-8)

The file opens with a comment block (NOT YAML data — `#`-prefixed) that is load-bearing as documentation of the contract's role. Reproduce verbatim:

```
# Governance — Assembly Line Contract (authoritative)
#
# THIS IS THE SOURCE OF TRUTH for Governance's steps, skills, artifacts,
# side-effects, and agent contract. Every downstream consumer (Temporal
# workflow, Olympus API gate service, step-progress mapping, frontend
# step registry) loads FROM this file via olympus_contracts.assembly_lines.
# Do not hardcode a copy in application code. Drift is policed by the
# `test_no_hardcoded_step_lists` CI check.
```

⚠️ GOTCHA (governance.yaml:6): the contract is loaded at runtime via the `olympus_contracts.assembly_lines` package accessor. Application code must NOT keep its own copy of the step list — a CI check named `test_no_hardcoded_step_lists` (cited at governance.yaml:8) fails the build if any consumer hardcodes the steps. Any regeneration must preserve a single-source-of-truth loader, not inline step lists.

---

## 1. Line-level metadata (top-level keys)

Reproduce every top-level key. Order in the file is: `name`, `description`, `trigger`, `depends_on`, `gates`, `mode`, `inputs`, `outputs`, `steps`.

### `name` (governance.yaml:10)
```yaml
name: Governance
```

### `description` (governance.yaml:11-21)
Multi-line folded scalar (`>`). Reproduce content exactly (folded → single logical string with normalized internal whitespace):

> Governance has two superordinate responsibilities with six parallel activities. A) Govern the portfolio: portfolio health monitoring; drift detection across architecture / compliance / performance / cost / adoption; new application intake review; user outcome tracking. B) Improve Olympus: pattern extraction & skill evolution (the compound-growth engine), factory analytics & capacity management. Runs on Temporal schedules at weekly and quarterly cadences; quarterly adds model benchmarking. Governance reads from every upstream line and writes ZERO fields to the application row — all its writes land in portfolio-scoped tables. No gates. The only line whose outputs feed every other line.

⚠️ GOTCHA (governance.yaml:19-21): the description encodes three hard invariants that the rest of the contract enforces structurally — (a) Governance writes ZERO fields to the application row; ALL side-effect writes target portfolio-scoped tables (confirmed: no step has an `application` target); (b) NO gates (`gates: []` at line 28 AND every step `gate: null`); (c) it is the only line whose outputs feed every other line.

### `trigger` (governance.yaml:22)
```yaml
trigger: temporal-schedule
```
Preceded by an inline comment block (governance.yaml:23-26) documenting `depends_on`:
```
# Governance is a continuous cross-line observer; it reads from every
# upstream line but does not block on any. Per the extensibility registry,
# its ``depends_on`` is empty so it can run regardless of assembly-line
# completion state.
```

### `depends_on` (governance.yaml:27)
```yaml
depends_on: []
```
⚠️ GOTCHA (governance.yaml:27, with comment at 23-26): `depends_on` MUST be the empty list. The extensibility registry treats an empty `depends_on` as "no completion-state dependency" so Governance can be scheduled regardless of any assembly-line completion state. A non-empty value would block the cross-line observer behavior.

### `gates` (governance.yaml:28)
```yaml
gates: []
```
Governance defines NO gates. (Consistent with each step's `gate: null`.)

### `mode` (governance.yaml:29)
```yaml
mode: continuous
```
⚠️ GOTCHA (governance.yaml:29): `mode: continuous` (NOT `triggered`). Combined with `trigger: temporal-schedule`, Governance is a continuous cross-line observer driven by Temporal schedules (weekly + quarterly cadences per the description), not a one-shot triggered line.

### `inputs` (governance.yaml:30-38)
Line-level inputs are a flat list of artifact TYPE names (8 entries). Reproduce in order:
```yaml
inputs:
  - wave-plan
  - sweep-summary
  - architecture-blueprint
  - data-architecture
  - cost-savings-certification
  - pattern-extraction
  - ralph-loop-metrics
  - escalation-record
```
⚠️ GOTCHA (governance.yaml:36): `pattern-extraction` appears in BOTH `inputs` (line 36) AND `outputs` (line 41). This is intentional — Governance reads the previous sweep's `pattern-extraction` as input (e.g. for skill-evolution / model-evaluation cross-sweep continuity) and emits a new `pattern-extraction` as output. Same for `sweep-summary` (input line 31, output line 47).

### `outputs` (governance.yaml:39-47)
Line-level outputs are a flat list of artifact TYPE names (8 entries). Reproduce in order:
```yaml
outputs:
  - drift-detection
  - pattern-extraction
  - latest-patterns
  - health-report
  - skill-evolution
  - factory-capacity
  - model-evaluation
  - sweep-summary
```
⚠️ GOTCHA (governance.yaml:42): `latest-patterns` is a line-level output that does NOT correspond to a step named `latest-patterns` — it is the registry/cold-start artifact `governance/{portfolio_id}/latest-patterns.json` emitted by the `pattern-extraction` step (step output at governance.yaml:159) and re-committed by the `propagate-patterns` step (input at governance.yaml:375). Note it is NOT schedule-scoped (no `{schedule_id}` segment): one rolling latest-patterns file per portfolio.

---

## 2. Steps — invariants common to ALL 10 steps

These hold for every step (verify per-step in section 3, but stated once here):
- `scope: portfolio` on every step (governance.yaml:53, 86, 137, 188, 230, 265, 359, 404, 451 — and 313 for model-evaluation). ⚠️ No step is application-scoped; reinforces "writes ZERO fields to the application row."
- `gate: null` on every step (no gates anywhere).
- `sequence` runs 1..10 in file order; `progress_pct` is strictly increasing: 8, 20, 30, 40, 50, 60, 70, 80, 88, 96.
- Each step carries `retry_policy.category` — one of `transient` (code steps) or `agent_failure` (agent steps).
- `kind` is `code` for steps {intake, propagate-patterns, persist-governance-sweep-side-effects, commit-sweep-summary} and `agent` for the six middle activities {drift-detection, pattern-extraction, health-report, skill-evolution, factory-capacity, model-evaluation}.

⚠️ GOTCHA (field naming): this contract uses `agent_role` (NOT `role`), `mcp_servers` (NOT `mcp`), `progress_pct` (NOT `progress`), `scope` (NOT a separate `parallel_with`-only model), `label` (NOT `name` at step level), and `purpose` (NOT `summary` — except the dedicated boolean `summary: true` flag on the final step). The `agent_contract.repos` map uses keys `artifact`/`source`/`target` with values from {`ro`, `rw`, `none`}. There is no `loop`/`iteration`/`condition` field on ANY step in this contract — do not invent them. The "skipped on weekly cadence" behavior of model-evaluation is expressed in PROSE in its `purpose`, not as a structured `condition` field.

⚠️ GOTCHA (parallelism model): the six agent steps (sequence 2–7) all declare each other in `parallel_with` (the fan-out), but each lists only the OTHER five, never itself. The four code steps (sequence 1, 8, 9, 10) have `parallel_with: []` — they are strictly sequential bookends/joins around the parallel fan-out. Reproduce each `parallel_with` list EXACTLY as written per step; the membership differs (see drift-detection's list is 4 entries because it omits model-evaluation, while model-evaluation's list is 5 entries — see GOTCHA in §3.7).

---

## 3. Steps — field-by-field (all 10)

### 3.1 Step 1 — `intake` (governance.yaml:50-81)

```yaml
- id: intake
  label: Governance Sweep Intake
  kind: code
  scope: portfolio
  sequence: 1
  progress_pct: 8
  purpose: >
    Workflow code (not an agent dispatch). Resolves the portfolio's
    cadence from schedule_id prefix (weekly vs. quarterly), selects
    the active activity set, loads portfolio inventory + upstream-
    line completion metadata (from application row + per-line
    artifact paths), and initialises per-activity state objects.
  skills: []
  agent_role: null
  inputs:
    artifacts:
      - rationalization/wave-*/wave-plan.json
      - sustainment/{portfolio_id}/*/sweep-summary.json
    context: [portfolio_id, schedule_id, triggered_at, cadence]
  outputs:
    artifacts: []
    side_effects: []
  agent_contract:
    mcp_servers: []
    repos:
      artifact: ro
      source: none
      target: none
  parallel_with: []
  gate: null
  retry_policy:
    category: transient
```

Field-by-field:
- **id** (`intake`) — governance.yaml:50
- **label** (`Governance Sweep Intake`) — governance.yaml:51
- **kind** (`code`) — governance.yaml:52
- **scope** (`portfolio`) — governance.yaml:53
- **sequence** (`1`) — governance.yaml:54
- **progress_pct** (`8`) — governance.yaml:55
- **purpose** (folded) — governance.yaml:56-61. Reproduce: "Workflow code (not an agent dispatch). Resolves the portfolio's cadence from schedule_id prefix (weekly vs. quarterly), selects the active activity set, loads portfolio inventory + upstream-line completion metadata (from application row + per-line artifact paths), and initialises per-activity state objects."
- **skills** (`[]`) — governance.yaml:62. Empty: code step, no agent skill.
- **agent_role** (`null`) — governance.yaml:63
- **inputs.artifacts** — governance.yaml:65-67: `rationalization/wave-*/wave-plan.json`, `sustainment/{portfolio_id}/*/sweep-summary.json`
- **inputs.context** — governance.yaml:68: `[portfolio_id, schedule_id, triggered_at, cadence]`
- **outputs.artifacts** (`[]`) — governance.yaml:70
- **outputs.side_effects** (`[]`) — governance.yaml:71
- **agent_contract.mcp_servers** (`[]`) — governance.yaml:73
- **agent_contract.repos** — governance.yaml:74-77: `artifact: ro`, `source: none`, `target: none`
- **parallel_with** (`[]`) — governance.yaml:78
- **gate** (`null`) — governance.yaml:79
- **retry_policy.category** (`transient`) — governance.yaml:81

⚠️ GOTCHA (governance.yaml:75): `intake` is the ONLY step whose `repos.artifact` is `ro` (read-only). It reads upstream artifacts and the application row to initialize state but writes nothing to Git. (All six agent steps + `commit-sweep-summary` are `rw`; `propagate-patterns` + `persist-governance-sweep-side-effects` are `none`.)
⚠️ GOTCHA (governance.yaml:57-58): cadence (weekly vs. quarterly) is resolved from the `schedule_id` PREFIX, not from a separate field. The selected "active activity set" depends on cadence — this is the mechanism by which `model-evaluation` is skipped on weekly cadence (see §3.7).

---

### 3.2 Step 2 — `drift-detection` (governance.yaml:83-132)

```yaml
- id: drift-detection
  label: Drift Detection
  kind: agent
  scope: portfolio
  sequence: 2
  progress_pct: 20
  purpose: >
    Detect applications deviating from approved baselines across 5
    drift categories: architecture (runtime config vs. blueprint),
    compliance (security + accessibility + authorization),
    performance (P95 latency / error-rate / availability trends),
    cost (observed vs. certified-savings baseline), adoption
    (post-deployment active-user trend). Critical drift generates
    immediate alerts to line leads; non-critical drift aggregates
    into the quarterly health report. Emits drift-detection.json.
  skills: [drift-detection]
  agent_role: Governance Drift Monitor
  inputs:
    artifacts:
      - architecture/*/architecture-blueprint.json
      - data/*/data-architecture.json
      - deployment/*/cost-savings-certification.json
    context: [portfolio_id, schedule_id, triggered_at, cadence, drift_thresholds]
  outputs:
    artifacts:
      - governance/{portfolio_id}/{schedule_id}/drift-detection.json
    side_effects:
      - target: drift_alert
        fields:
          - portfolio_id
          - sweep_id
          - app_id
          - drift_type
          - severity
          - details
          - acknowledged
          - created_at
        notes: >
          Existing table (migration 025). Governance appends rows;
          dashboard surface + ack workflow already in place.
  agent_contract:
    mcp_servers: [olympus]
    repos:
      artifact: rw
      source: none
      target: none
  parallel_with: [pattern-extraction, health-report, skill-evolution, factory-capacity]
  gate: null
  retry_policy:
    category: agent_failure
```

Field-by-field:
- **id** (`drift-detection`) — governance.yaml:83
- **label** (`Drift Detection`) — governance.yaml:84
- **kind** (`agent`) — governance.yaml:85
- **scope** (`portfolio`) — governance.yaml:86
- **sequence** (`2`) — governance.yaml:87
- **progress_pct** (`20`) — governance.yaml:88
- **purpose** (folded) — governance.yaml:89-97. The 5 drift categories are: architecture (runtime config vs. blueprint), compliance (security + accessibility + authorization), performance (P95 latency / error-rate / availability trends), cost (observed vs. certified-savings baseline), adoption (post-deployment active-user trend). Critical drift → immediate alerts to line leads; non-critical → aggregates into the quarterly health report. Emits drift-detection.json.
- **skills** (`[drift-detection]`) — governance.yaml:98
- **agent_role** (`Governance Drift Monitor`) — governance.yaml:99
- **inputs.artifacts** — governance.yaml:101-104: `architecture/*/architecture-blueprint.json`, `data/*/data-architecture.json`, `deployment/*/cost-savings-certification.json`
- **inputs.context** — governance.yaml:105: `[portfolio_id, schedule_id, triggered_at, cadence, drift_thresholds]`
- **outputs.artifacts** — governance.yaml:108: `governance/{portfolio_id}/{schedule_id}/drift-detection.json`
- **outputs.side_effects[0]** — governance.yaml:110-119:
  - **target**: `drift_alert`
  - **fields** (8, in order): `portfolio_id`, `sweep_id`, `app_id`, `drift_type`, `severity`, `details`, `acknowledged`, `created_at`
  - **notes** (governance.yaml:120-122): "Existing table (migration 025). Governance appends rows; dashboard surface + ack workflow already in place."
- **agent_contract.mcp_servers** (`[olympus]`) — governance.yaml:124
- **agent_contract.repos** — governance.yaml:125-128: `artifact: rw`, `source: none`, `target: none`
- **parallel_with** — governance.yaml:129: `[pattern-extraction, health-report, skill-evolution, factory-capacity]` (4 entries — omits self AND omits model-evaluation)
- **gate** (`null`) — governance.yaml:130
- **retry_policy.category** (`agent_failure`) — governance.yaml:132

⚠️ GOTCHA (governance.yaml:129): drift-detection's `parallel_with` has only 4 entries — it lists pattern-extraction, health-report, skill-evolution, factory-capacity but NOT model-evaluation. Each of the weekly-cadence activities (sequence 2–6) omits model-evaluation from its `parallel_with` (because model-evaluation only runs on quarterly cadence). Only model-evaluation itself lists all 5 others (§3.7).
⚠️ GOTCHA (governance.yaml:110-119): `drift_alert` table has fields `acknowledged` + `created_at` and is described as having an existing "ack workflow" + dashboard surface (migration 025). Governance only APPENDS rows; it does not own acknowledgment state transitions.

---

### 3.3 Step 3 — `pattern-extraction` (governance.yaml:134-183)

```yaml
- id: pattern-extraction
  label: Pattern Extraction
  kind: agent
  scope: portfolio
  sequence: 3
  progress_pct: 30
  purpose: >
    Compound growth engine. Analyzes completed modernization
    artifacts (code templates, architecture patterns, integration
    patterns) + gate-pass correlation data to extract reusable
    patterns. Adds to pattern library, records acknowledgments from
    downstream Modernization workflows. Emits pattern-extraction.json
    + feeds _propagate_patterns + _commit_latest_patterns_registry
    helpers.
  skills: [skill-builder]
  agent_role: Pattern Extractor
  inputs:
    artifacts:
      - modernization/*/generate/*/
      - modernization/*/ralph-loop-metrics.json
      - modernization/*/escalation-record.json
    context: [portfolio_id, schedule_id, triggered_at, cadence, pattern_library_state]
  outputs:
    artifacts:
      - governance/{portfolio_id}/{schedule_id}/pattern-extraction.json
      - governance/{portfolio_id}/latest-patterns.json
    side_effects:
      - target: pattern
        fields:
          - name
          - category
          - wave_id
          - source_apps
          - reuse_count
          - content
          - portfolio_id
          - created_at
        notes: >
          Existing table (migration 025). Governance appends new
          patterns. Reuse_count updated on wave_patterns_ready ack.
  agent_contract:
    mcp_servers: [olympus]
    repos:
      artifact: rw
      source: none
      target: none
  parallel_with: [drift-detection, health-report, skill-evolution, factory-capacity]
  gate: null
  retry_policy:
    category: agent_failure
```

Field-by-field:
- **id** (`pattern-extraction`) — governance.yaml:134
- **label** (`Pattern Extraction`) — governance.yaml:135
- **kind** (`agent`) — governance.yaml:136
- **scope** (`portfolio`) — governance.yaml:137
- **sequence** (`3`) — governance.yaml:138
- **progress_pct** (`30`) — governance.yaml:139
- **purpose** (folded) — governance.yaml:140-147. "Compound growth engine. Analyzes completed modernization artifacts (code templates, architecture patterns, integration patterns) + gate-pass correlation data to extract reusable patterns. Adds to pattern library, records acknowledgments from downstream Modernization workflows. Emits pattern-extraction.json + feeds _propagate_patterns + _commit_latest_patterns_registry helpers."
- **skills** (`[skill-builder]`) — governance.yaml:148
- **agent_role** (`Pattern Extractor`) — governance.yaml:149
- **inputs.artifacts** — governance.yaml:151-154: `modernization/*/generate/*/`, `modernization/*/ralph-loop-metrics.json`, `modernization/*/escalation-record.json`
- **inputs.context** — governance.yaml:155: `[portfolio_id, schedule_id, triggered_at, cadence, pattern_library_state]`
- **outputs.artifacts** — governance.yaml:157-159: `governance/{portfolio_id}/{schedule_id}/pattern-extraction.json` AND `governance/{portfolio_id}/latest-patterns.json`
- **outputs.side_effects[0]** — governance.yaml:161-170:
  - **target**: `pattern`
  - **fields** (8, in order): `name`, `category`, `wave_id`, `source_apps`, `reuse_count`, `content`, `portfolio_id`, `created_at`
  - **notes** (governance.yaml:171-173): "Existing table (migration 025). Governance appends new patterns. Reuse_count updated on wave_patterns_ready ack."
- **agent_contract.mcp_servers** (`[olympus]`) — governance.yaml:175
- **agent_contract.repos** — governance.yaml:176-179: `artifact: rw`, `source: none`, `target: none`
- **parallel_with** — governance.yaml:180: `[drift-detection, health-report, skill-evolution, factory-capacity]` (4 entries — omits self + model-evaluation)
- **gate** (`null`) — governance.yaml:181
- **retry_policy.category** (`agent_failure`) — governance.yaml:182

⚠️ GOTCHA (governance.yaml:159): pattern-extraction emits TWO artifacts — the schedule-scoped `pattern-extraction.json` AND the rolling, NON-schedule-scoped `latest-patterns.json` (no `{schedule_id}`). The latter is the cold-start registry artifact later (re)committed by `propagate-patterns` (§3.8).
⚠️ GOTCHA (governance.yaml:145-147): purpose names two private workflow helpers by exact name: `_propagate_patterns` and `_commit_latest_patterns_registry`. These are the implementation hooks fed by this step; preserve their names in any regen for traceability.
⚠️ GOTCHA (governance.yaml:173): `pattern.reuse_count` is mutated OUT-OF-BAND — it is "updated on wave_patterns_ready ack", i.e., updated when downstream Modernization workflows acknowledge consuming the patterns (via the `wave_patterns_ready` signal, see §3.10), not at pattern-extraction time. Governance APPENDS new pattern rows here; the reuse counter is a feedback loop closed by the ack path.

---

### 3.4 Step 4 — `health-report` (governance.yaml:185-225)

```yaml
- id: health-report
  label: Portfolio Health Report
  kind: agent
  scope: portfolio
  sequence: 4
  progress_pct: 40
  purpose: >
    Portfolio health monitoring + quarterly deep scans. Aggregates
    Sustainment's patching_compliance + incident_log +
    sla_compliance_record + cost_anomaly_record tables;
    Validation's parity + vuln + accessibility columns;
    Deployment's cost-savings-realized column into a single
    health index + per-dimension breakdown. Emits health-report.json.
  skills: [portfolio-health-check]
  agent_role: Portfolio Health Checker
  inputs:
    artifacts: []
    context: [portfolio_id, schedule_id, triggered_at, cadence, health_thresholds]
  outputs:
    artifacts:
      - governance/{portfolio_id}/{schedule_id}/health-report.json
    side_effects:
      - target: health_check
        fields:
          - portfolio_id
          - health_index
          - checks
          - date
        notes: >
          Existing table (migration 025). One row per sweep for
          trend analysis.
  agent_contract:
    mcp_servers: [olympus]
    repos:
      artifact: rw
      source: none
      target: none
  parallel_with: [drift-detection, pattern-extraction, skill-evolution, factory-capacity]
  gate: null
  retry_policy:
    category: agent_failure
```

Field-by-field:
- **id** (`health-report`) — governance.yaml:185
- **label** (`Portfolio Health Report`) — governance.yaml:186
- **kind** (`agent`) — governance.yaml:187
- **scope** (`portfolio`) — governance.yaml:188
- **sequence** (`4`) — governance.yaml:189
- **progress_pct** (`40`) — governance.yaml:190
- **purpose** (folded) — governance.yaml:191-197. "Portfolio health monitoring + quarterly deep scans. Aggregates Sustainment's patching_compliance + incident_log + sla_compliance_record + cost_anomaly_record tables; Validation's parity + vuln + accessibility columns; Deployment's cost-savings-realized column into a single health index + per-dimension breakdown. Emits health-report.json."
- **skills** (`[portfolio-health-check]`) — governance.yaml:198
- **agent_role** (`Portfolio Health Checker`) — governance.yaml:199
- **inputs.artifacts** (`[]`) — governance.yaml:201. ⚠️ EMPTY — health-report reads from DATABASE TABLES/COLUMNS (named in purpose), not from Git artifacts.
- **inputs.context** — governance.yaml:202: `[portfolio_id, schedule_id, triggered_at, cadence, health_thresholds]`
- **outputs.artifacts** — governance.yaml:205: `governance/{portfolio_id}/{schedule_id}/health-report.json`
- **outputs.side_effects[0]** — governance.yaml:207-212:
  - **target**: `health_check`
  - **fields** (4, in order): `portfolio_id`, `health_index`, `checks`, `date`
  - **notes** (governance.yaml:213-215): "Existing table (migration 025). One row per sweep for trend analysis."
- **agent_contract.mcp_servers** (`[olympus]`) — governance.yaml:217
- **agent_contract.repos** — governance.yaml:218-221: `artifact: rw`, `source: none`, `target: none`
- **parallel_with** — governance.yaml:222: `[drift-detection, pattern-extraction, skill-evolution, factory-capacity]` (4 entries — omits self + model-evaluation)
- **gate** (`null`) — governance.yaml:224
- **retry_policy.category** (`agent_failure`) — governance.yaml:225

⚠️ GOTCHA (governance.yaml:201): health-report is the only AGENT step with `inputs.artifacts: []`. Its inputs are cross-line DATABASE tables/columns enumerated in the purpose: Sustainment's `patching_compliance` + `incident_log` + `sla_compliance_record` + `cost_anomaly_record` tables; Validation's `parity` + `vuln` + `accessibility` columns; Deployment's `cost-savings-realized` column. A regen that wires this step to Git artifacts would be WRONG — it consumes the derived query layer.
⚠️ GOTCHA (governance.yaml:210): `health_check.checks` is a structured/JSONB-style column (the "per-dimension breakdown"), distinct from the scalar `health_index`. One row per sweep (notes) — `date`-keyed for trend analysis.

---

### 3.5 Step 5 — `skill-evolution` (governance.yaml:227-260)

```yaml
- id: skill-evolution
  label: Skill Evolution
  kind: agent
  scope: portfolio
  sequence: 5
  progress_pct: 50
  purpose: >
    Skill lifecycle management — observe → extract → create → test →
    publish → measure → refine. Analyzes factory execution for
    successful patterns and failures; produces new / refined SKILL.md
    recommendations + test plans. Skill approval is dashboard-
    mediated (humans review before publish); workflow produces the
    recommendation, not the publish decision.
  skills: [skill-builder]
  agent_role: Skill Evolution Agent
  inputs:
    artifacts:
      - governance/*/pattern-extraction.json
      - modernization/*/ralph-loop-metrics.json
    context: [portfolio_id, schedule_id, triggered_at, cadence, skill_registry_state]
  outputs:
    artifacts:
      - governance/{portfolio_id}/{schedule_id}/skill-evolution.json
    side_effects: []
  agent_contract:
    mcp_servers: [olympus]
    repos:
      artifact: rw
      source: none
      target: none
  parallel_with: [drift-detection, pattern-extraction, health-report, factory-capacity]
  gate: null
  retry_policy:
    category: agent_failure
```

Field-by-field:
- **id** (`skill-evolution`) — governance.yaml:227
- **label** (`Skill Evolution`) — governance.yaml:228
- **kind** (`agent`) — governance.yaml:229
- **scope** (`portfolio`) — governance.yaml:230
- **sequence** (`5`) — governance.yaml:231
- **progress_pct** (`50`) — governance.yaml:232
- **purpose** (folded) — governance.yaml:233-239. "Skill lifecycle management — observe → extract → create → test → publish → measure → refine. Analyzes factory execution for successful patterns and failures; produces new / refined SKILL.md recommendations + test plans. Skill approval is dashboard-mediated (humans review before publish); workflow produces the recommendation, not the publish decision."
- **skills** (`[skill-builder]`) — governance.yaml:240
- **agent_role** (`Skill Evolution Agent`) — governance.yaml:241
- **inputs.artifacts** — governance.yaml:243-245: `governance/*/pattern-extraction.json`, `modernization/*/ralph-loop-metrics.json`
- **inputs.context** — governance.yaml:246: `[portfolio_id, schedule_id, triggered_at, cadence, skill_registry_state]`
- **outputs.artifacts** — governance.yaml:249: `governance/{portfolio_id}/{schedule_id}/skill-evolution.json`
- **outputs.side_effects** (`[]`) — governance.yaml:250. ⚠️ EMPTY — skill-evolution writes NO DB side-effects.
- **agent_contract.mcp_servers** (`[olympus]`) — governance.yaml:251
- **agent_contract.repos** — governance.yaml:252-255: `artifact: rw`, `source: none`, `target: none`
- **parallel_with** — governance.yaml:257: `[drift-detection, pattern-extraction, health-report, factory-capacity]` (4 entries — omits self + model-evaluation)
- **gate** (`null`) — governance.yaml:258
- **retry_policy.category** (`agent_failure`) — governance.yaml:259

⚠️ GOTCHA (governance.yaml:250): skill-evolution has `side_effects: []` — it produces a recommendation ARTIFACT only, NO DB write and NO publish action. Publish is "dashboard-mediated (humans review before publish)" per the purpose (governance.yaml:237-239). The workflow produces the recommendation, not the publish decision. A regen that auto-publishes skills would violate the contract.
⚠️ GOTCHA (governance.yaml:244): skill-evolution consumes `governance/*/pattern-extraction.json` — i.e., it reads the output of an EARLIER step in the SAME sweep (and/or prior sweeps). Despite being declared `parallel_with` pattern-extraction (governance.yaml:257), there is a logical data dependency on pattern-extraction's artifact. The contract models them as parallel; the data dependency is satisfied because pattern-extraction commits its artifact before skill-evolution reads (an ordering reliance to preserve — see also model-evaluation §3.7).

---

### 3.6 Step 6 — `factory-capacity` (governance.yaml:262-308)

```yaml
- id: factory-capacity
  label: Factory Capacity Management
  kind: agent
  scope: portfolio
  sequence: 6
  progress_pct: 60
  purpose: >
    Factory analytics + concurrent-wave capacity planning. Computes
    throughput, cost-per-app, gate-first-pass-rate, Ralph-Loop-
    iteration average, escalation-rate, pattern-reuse-rate,
    automation-ratio, time-to-modernize. Produces the concurrent-
    wave capacity plan that Rationalization consumes. Emits
    factory-capacity.json + compound-growth metrics feed.
  skills: [factory-capacity-manager]
  agent_role: Factory Capacity Planner
  inputs:
    artifacts:
      - rationalization/wave-*/wave-plan.json
    context: [portfolio_id, schedule_id, triggered_at, cadence, historical_metrics]
  outputs:
    artifacts:
      - governance/{portfolio_id}/{schedule_id}/factory-capacity.json
    side_effects:
      - target: factory_capacity_plan
        fields:
          - portfolio_id
          - sweep_id
          - concurrent_wave_max
          - throughput_apps_per_month
          - cost_per_app_usd
          - gate_first_pass_rate
          - ralph_loop_iteration_avg
          - escalation_rate
          - pattern_reuse_rate
          - automation_ratio
          - time_to_modernize_days
          - computed_at
  agent_contract:
    mcp_servers: [olympus]
    repos:
      artifact: rw
      source: none
      target: none
  parallel_with: [drift-detection, pattern-extraction, health-report, skill-evolution]
  gate: null
  retry_policy:
    category: agent_failure
```

Field-by-field:
- **id** (`factory-capacity`) — governance.yaml:262
- **label** (`Factory Capacity Management`) — governance.yaml:263
- **kind** (`agent`) — governance.yaml:264
- **scope** (`portfolio`) — governance.yaml:265
- **sequence** (`6`) — governance.yaml:266
- **progress_pct** (`60`) — governance.yaml:267
- **purpose** (folded) — governance.yaml:268-274. "Factory analytics + concurrent-wave capacity planning. Computes throughput, cost-per-app, gate-first-pass-rate, Ralph-Loop-iteration average, escalation-rate, pattern-reuse-rate, automation-ratio, time-to-modernize. Produces the concurrent-wave capacity plan that Rationalization consumes. Emits factory-capacity.json + compound-growth metrics feed."
- **skills** (`[factory-capacity-manager]`) — governance.yaml:275
- **agent_role** (`Factory Capacity Planner`) — governance.yaml:276
- **inputs.artifacts** — governance.yaml:278-279: `rationalization/wave-*/wave-plan.json`
- **inputs.context** — governance.yaml:280: `[portfolio_id, schedule_id, triggered_at, cadence, historical_metrics]`
- **outputs.artifacts** — governance.yaml:283: `governance/{portfolio_id}/{schedule_id}/factory-capacity.json`
- **outputs.side_effects[0]** — governance.yaml:285-298:
  - **target**: `factory_capacity_plan`
  - **fields** (12, in order): `portfolio_id`, `sweep_id`, `concurrent_wave_max`, `throughput_apps_per_month`, `cost_per_app_usd`, `gate_first_pass_rate`, `ralph_loop_iteration_avg`, `escalation_rate`, `pattern_reuse_rate`, `automation_ratio`, `time_to_modernize_days`, `computed_at`
  - **notes**: NONE (this side-effect has no `notes` key — see GOTCHA)
- **agent_contract.mcp_servers** (`[olympus]`) — governance.yaml:300
- **agent_contract.repos** — governance.yaml:301-304: `artifact: rw`, `source: none`, `target: none`
- **parallel_with** — governance.yaml:305: `[drift-detection, pattern-extraction, health-report, skill-evolution]` (4 entries — omits self + model-evaluation)
- **gate** (`null`) — governance.yaml:306
- **retry_policy.category** (`agent_failure`) — governance.yaml:307

⚠️ GOTCHA (governance.yaml:285-298): `factory_capacity_plan` side-effect has NO `notes` key (unlike drift_alert/pattern/health_check which each note "Existing table (migration 025)"). Per the `persist-...` step purpose (governance.yaml:409-411), `factory_capacity_plan` + `model_benchmark_result` are NEW tables, not from migration 025. This is the table that Rationalization consumes for its concurrent-wave capacity plan (governance.yaml:271-272) — a cross-line write target. Reproduce ALL 12 fields in exact order; this is the widest side-effect in the line.
⚠️ GOTCHA (field naming): note `factory_capacity_plan` uses `sweep_id` (NOT `schedule_id`) as the sweep identifier column — consistent with `drift_alert` (governance.yaml:112) and `model_benchmark_result` (governance.yaml:336). The artifact PATH uses `{schedule_id}` but the DB column is `sweep_id`. Do not conflate.

---

### 3.7 Step 7 — `model-evaluation` (governance.yaml:310-354)

```yaml
- id: model-evaluation
  label: Model Evaluation
  kind: agent
  scope: portfolio
  sequence: 7
  progress_pct: 70
  purpose: >
    Quarterly model-benchmark run. Evaluates Tier-1/Tier-2/Tier-3
    models on held-out task suites; identifies regressions,
    cost-effectiveness changes, refresh recommendations. Output
    feeds Orchestration's skill-to-model routing. Skipped on weekly
    cadence.
  skills: [model-benchmark]
  agent_role: Model Evaluator
  inputs:
    artifacts:
      - governance/*/pattern-extraction.json
    context: [portfolio_id, schedule_id, triggered_at, cadence, model_registry_state]
  outputs:
    artifacts:
      - governance/{portfolio_id}/{schedule_id}/model-evaluation.json
    side_effects:
      - target: model_benchmark_result
        fields:
          - portfolio_id
          - sweep_id
          - model_id
          - tier
          - task_suite
          - pass_rate
          - cost_per_call_usd
          - latency_p95_ms
          - regression_flag
          - refresh_recommended
          - benchmarked_at
  agent_contract:
    mcp_servers: [olympus]
    repos:
      artifact: rw
      source: none
      target: none
  parallel_with: [drift-detection, pattern-extraction, health-report, skill-evolution, factory-capacity]
  gate: null
  retry_policy:
    category: agent_failure
```

Field-by-field:
- **id** (`model-evaluation`) — governance.yaml:310
- **label** (`Model Evaluation`) — governance.yaml:311
- **kind** (`agent`) — governance.yaml:312
- **scope** (`portfolio`) — governance.yaml:313
- **sequence** (`7`) — governance.yaml:314
- **progress_pct** (`70`) — governance.yaml:315
- **purpose** (folded) — governance.yaml:316-321. "Quarterly model-benchmark run. Evaluates Tier-1/Tier-2/Tier-3 models on held-out task suites; identifies regressions, cost-effectiveness changes, refresh recommendations. Output feeds Orchestration's skill-to-model routing. Skipped on weekly cadence."
- **skills** (`[model-benchmark]`) — governance.yaml:322
- **agent_role** (`Model Evaluator`) — governance.yaml:323
- **inputs.artifacts** — governance.yaml:325-326: `governance/*/pattern-extraction.json`
- **inputs.context** — governance.yaml:327: `[portfolio_id, schedule_id, triggered_at, cadence, model_registry_state]`
- **outputs.artifacts** — governance.yaml:330: `governance/{portfolio_id}/{schedule_id}/model-evaluation.json`
- **outputs.side_effects[0]** — governance.yaml:332-344:
  - **target**: `model_benchmark_result`
  - **fields** (11, in order): `portfolio_id`, `sweep_id`, `model_id`, `tier`, `task_suite`, `pass_rate`, `cost_per_call_usd`, `latency_p95_ms`, `regression_flag`, `refresh_recommended`, `benchmarked_at`
  - **notes**: NONE (no `notes` key — NEW table per persist-step purpose)
- **agent_contract.mcp_servers** (`[olympus]`) — governance.yaml:346
- **agent_contract.repos** — governance.yaml:345-350: `artifact: rw`, `source: none`, `target: none`
- **parallel_with** — governance.yaml:351: `[drift-detection, pattern-extraction, health-report, skill-evolution, factory-capacity]` (5 entries — ALL other agent steps)
- **gate** (`null`) — governance.yaml:352
- **retry_policy.category** (`agent_failure`) — governance.yaml:353

⚠️ GOTCHA (governance.yaml:319-321 + 351): model-evaluation is the ONLY agent step whose `parallel_with` has 5 entries (every other agent step). The asymmetry is deliberate: the five weekly activities (sequence 2–6) each OMIT model-evaluation from their `parallel_with` (4 entries) because model-evaluation runs ONLY on quarterly cadence ("Skipped on weekly cadence"). When the quarterly cadence runs, all six fan out together. The skip is enforced by the `intake` step's activity-set selection (governance.yaml:57-59), NOT by a structured `condition` field on this step.
⚠️ GOTCHA (governance.yaml:325-326): model-evaluation's only artifact input is `governance/*/pattern-extraction.json` (same intra-sweep data reliance noted for skill-evolution, §3.5). Its primary inputs (the actual model task-suite results) are implied by `model_registry_state` context + the `model-benchmark` skill, not a Git artifact.
⚠️ GOTCHA (governance.yaml:319-320): model-evaluation output "feeds Orchestration's skill-to-model routing" — a cross-line consumer (Orchestration). The benchmark covers Tier-1/Tier-2/Tier-3 models on held-out task suites.

---

### 3.8 Step 8 — `propagate-patterns` (governance.yaml:356-399)

```yaml
- id: propagate-patterns
  label: Propagate Patterns to Modernization
  kind: code
  scope: portfolio
  sequence: 8
  progress_pct: 80
  purpose: >
    Workflow code. Pushes the pattern bundle from this sweep to
    every active Modernization workflow in the portfolio via
    Temporal external-handle signal emission. Best-effort — a
    sweep that can't reach any consumers still commits the
    summary. Also commits the cold-start registry artifact so
    Modernization workflows that start later can load patterns at
    intake.
  skills: []
  agent_role: null
  inputs:
    artifacts:
      - governance/{portfolio_id}/{schedule_id}/pattern-extraction.json
      - governance/{portfolio_id}/latest-patterns.json
    context: [portfolio_id, schedule_id, triggered_at, active_mod_workflow_ids]
  outputs:
    artifacts: []
    side_effects:
      - signal: WavePatternsReadySignal
        fields:
          - wave_id
          - patterns
          - portfolio_id
          - ready_at
        target: ModernizationWorkflow (each active instance)
        notes: >
          Existing signal shape; reality already emits. Contract
          documents the shape here for cross-line visibility.
  agent_contract:
    mcp_servers: []
    repos:
      artifact: none
      source: none
      target: none
  parallel_with: []
  gate: null
  retry_policy:
    category: transient
```

Field-by-field:
- **id** (`propagate-patterns`) — governance.yaml:356
- **label** (`Propagate Patterns to Modernization`) — governance.yaml:357
- **kind** (`code`) — governance.yaml:358
- **scope** (`portfolio`) — governance.yaml:359
- **sequence** (`8`) — governance.yaml:360
- **progress_pct** (`80`) — governance.yaml:361
- **purpose** (folded) — governance.yaml:362-369. "Workflow code. Pushes the pattern bundle from this sweep to every active Modernization workflow in the portfolio via Temporal external-handle signal emission. Best-effort — a sweep that can't reach any consumers still commits the summary. Also commits the cold-start registry artifact so Modernization workflows that start later can load patterns at intake."
- **skills** (`[]`) — governance.yaml:370
- **agent_role** (`null`) — governance.yaml:371
- **inputs.artifacts** — governance.yaml:373-375: `governance/{portfolio_id}/{schedule_id}/pattern-extraction.json`, `governance/{portfolio_id}/latest-patterns.json`
- **inputs.context** — governance.yaml:376: `[portfolio_id, schedule_id, triggered_at, active_mod_workflow_ids]`
- **outputs.artifacts** (`[]`) — governance.yaml:378
- **outputs.side_effects[0]** — governance.yaml:380-388. ⚠️ THIS SIDE-EFFECT USES `signal` AS ITS PRIMARY KEY, NOT `target`:
  - **signal**: `WavePatternsReadySignal` (governance.yaml:380)
  - **fields** (4, in order): `wave_id`, `patterns`, `portfolio_id`, `ready_at` (governance.yaml:381-385)
  - **target**: `ModernizationWorkflow (each active instance)` (governance.yaml:386) — here `target` is the SIGNAL RECIPIENT, not a DB table
  - **notes** (governance.yaml:387-389): "Existing signal shape; reality already emits. Contract documents the shape here for cross-line visibility."
- **agent_contract.mcp_servers** (`[]`) — governance.yaml:391
- **agent_contract.repos** — governance.yaml:392-395: `artifact: none`, `source: none`, `target: none`
- **parallel_with** (`[]`) — governance.yaml:396
- **gate** (`null`) — governance.yaml:397
- **retry_policy.category** (`transient`) — governance.yaml:398

⚠️ GOTCHA (governance.yaml:380-386): this is the ONLY side-effect in the entire line keyed on `signal:` (`WavePatternsReadySignal`) instead of `target:` (a DB table). Its `target:` field (line 386) names the SIGNAL RECIPIENT (`ModernizationWorkflow (each active instance)`), not a table. The signal payload is the wave-patterns bundle: `wave_id`, `patterns`, `portfolio_id`, `ready_at`. ⚠️ The signal CLASS NAME is `WavePatternsReadySignal` (governance.yaml:380), but the ACK signal that closes the loop elsewhere is referred to as `wave_patterns_ready` (governance.yaml:173, 462, 472) — the contract uses two spellings for the two directions; preserve both exactly.
⚠️ GOTCHA (governance.yaml:364-369): BEST-EFFORT semantics — "a sweep that can't reach any consumers still commits the summary." Signal emission failure to active Modernization workflows must NOT abort the sweep. `retry_policy.category: transient`. The step ALSO commits the cold-start registry artifact (the `latest-patterns.json` re-commit) so workflows that start LATER can load patterns at intake — note `repos.artifact: none` here, so the actual Git commit is via a separate mechanism (the `_commit_latest_patterns_registry` helper named in pattern-extraction's purpose), not this step's artifact repo handle.
⚠️ GOTCHA (governance.yaml:392-395): `repos.artifact: none` even though the purpose says "commits the cold-start registry artifact." The pattern-extraction step (governance.yaml:159) already emitted `latest-patterns.json` with `rw`; propagate-patterns reads it (input line 375) and re-commits via the helper. The `none` value reflects that signal emission is the dominant action of this step.

---

### 3.9 Step 9 — `persist-governance-sweep-side-effects` (governance.yaml:401-446)

```yaml
- id: persist-governance-sweep-side-effects
  label: Persist Governance Sweep Side Effects
  kind: code
  scope: portfolio
  sequence: 9
  progress_pct: 88
  purpose: >
    Workflow code. Projects per-activity findings into the
    Governance DB tables (drift_alert, pattern, health_check exist;
    factory_capacity_plan + model_benchmark_result are new). Best-
    effort — swallows DB failures so the workflow doesn't block
    the sweep summary commit on transient DB errors.
  skills: []
  agent_role: null
  inputs:
    artifacts:
      - governance/{portfolio_id}/{schedule_id}/drift-detection.json
      - governance/{portfolio_id}/{schedule_id}/pattern-extraction.json
      - governance/{portfolio_id}/{schedule_id}/health-report.json
      - governance/{portfolio_id}/{schedule_id}/skill-evolution.json
      - governance/{portfolio_id}/{schedule_id}/factory-capacity.json
      - governance/{portfolio_id}/{schedule_id}/model-evaluation.json
    context: [portfolio_id, schedule_id, triggered_at, cadence]
  outputs:
    artifacts: []
    side_effects:
      - target: drift_alert
        fields: [...]
      - target: pattern
        fields: [...]
      - target: health_check
        fields: [...]
      - target: factory_capacity_plan
        fields: [...]
      - target: model_benchmark_result
        fields: [...]
  agent_contract:
    mcp_servers: []
    repos:
      artifact: none
      source: none
      target: none
  parallel_with: []
  gate: null
  retry_policy:
    category: transient
```

Field-by-field:
- **id** (`persist-governance-sweep-side-effects`) — governance.yaml:401
- **label** (`Persist Governance Sweep Side Effects`) — governance.yaml:402
- **kind** (`code`) — governance.yaml:403
- **scope** (`portfolio`) — governance.yaml:404
- **sequence** (`9`) — governance.yaml:405
- **progress_pct** (`88`) — governance.yaml:406
- **purpose** (folded) — governance.yaml:407-412. "Workflow code. Projects per-activity findings into the Governance DB tables (drift_alert, pattern, health_check exist; factory_capacity_plan + model_benchmark_result are new). Best-effort — swallows DB failures so the workflow doesn't block the sweep summary commit on transient DB errors."
- **skills** (`[]`) — governance.yaml:413
- **agent_role** (`null`) — governance.yaml:414
- **inputs.artifacts** — governance.yaml:416-422 (all SIX per-activity artifacts):
  - `governance/{portfolio_id}/{schedule_id}/drift-detection.json`
  - `governance/{portfolio_id}/{schedule_id}/pattern-extraction.json`
  - `governance/{portfolio_id}/{schedule_id}/health-report.json`
  - `governance/{portfolio_id}/{schedule_id}/skill-evolution.json`
  - `governance/{portfolio_id}/{schedule_id}/factory-capacity.json`
  - `governance/{portfolio_id}/{schedule_id}/model-evaluation.json`
- **inputs.context** — governance.yaml:423: `[portfolio_id, schedule_id, triggered_at, cadence]`
- **outputs.artifacts** (`[]`) — governance.yaml:425
- **outputs.side_effects** — governance.yaml:427-436. FIVE side-effect targets, each with `fields: [...]` (literal ellipsis placeholder — see GOTCHA):
  - **target**: `drift_alert`, **fields**: `[...]` (governance.yaml:427-428)
  - **target**: `pattern`, **fields**: `[...]` (governance.yaml:429-430)
  - **target**: `health_check`, **fields**: `[...]` (governance.yaml:431-432)
  - **target**: `factory_capacity_plan`, **fields**: `[...]` (governance.yaml:433-434)
  - **target**: `model_benchmark_result`, **fields**: `[...]` (governance.yaml:435-436)
- **agent_contract.mcp_servers** (`[]`) — governance.yaml:438
- **agent_contract.repos** — governance.yaml:439-442: `artifact: none`, `source: none`, `target: none`
- **parallel_with** (`[]`) — governance.yaml:443
- **gate** (`null`) — governance.yaml:444
- **retry_policy.category** (`transient`) — governance.yaml:445

⚠️ GOTCHA (governance.yaml:428, 430, 432, 434, 436): the `fields: [...]` value is a LITERAL YAML flow-sequence containing a single string item `...` (i.e., `["..."]`), used as a "see canonical definition above" placeholder. This step does NOT redeclare the field lists — the AUTHORITATIVE field lists live on the producing agent steps: `drift_alert` → §3.2 (8 fields), `pattern` → §3.3 (8 fields), `health_check` → §3.4 (4 fields), `factory_capacity_plan` → §3.6 (12 fields), `model_benchmark_result` → §3.7 (11 fields). A regen MUST resolve `[...]` to those canonical lists when actually persisting; it is a deliberate non-DRY placeholder. ⚠️ When parsing this YAML, `[...]` is NOT a YAML alias/anchor and NOT a Python Ellipsis — it parses as a list whose single element is the 3-character string `"..."`.
⚠️ GOTCHA (governance.yaml:410-412): BEST-EFFORT / fault-isolated persistence — "swallows DB failures so the workflow doesn't block the sweep summary commit on transient DB errors." The DB projection step must NOT propagate exceptions; the sweep-summary commit (step 10) proceeds even if persistence fails. `retry_policy.category: transient`.
⚠️ GOTCHA (governance.yaml:439-442): `repos.artifact: none` — this step READS the six per-activity artifacts as INPUTS (lines 416-422) but does NOT write Git; it writes only to the 5 DB tables. The artifacts were already committed by the producing agent steps (rw). This is the projection step from Git→DB query layer.
⚠️ GOTCHA (sequence dependency): although these are the SAME six artifacts the agent steps already wrote to the DB inline (each agent step has its own DB side-effect), this step re-projects ALL findings. The agent-step side-effects + this consolidated projection both target the same tables — a regen must not double-insert. The contract's intent is that the agent-step side-effects are the per-finding writes; this step is the consolidated, fault-isolated reconciliation (best-effort).

---

### 3.10 Step 10 — `commit-sweep-summary` (governance.yaml:448-487) — SUMMARY STEP

```yaml
- id: commit-sweep-summary
  label: Commit Sweep Summary
  kind: code
  scope: portfolio
  sequence: 10
  progress_pct: 96
  summary: true
  purpose: >
    Workflow code. Synthesises per-activity findings + pattern-
    ready acknowledgments (consumed via wave_patterns_ready signal
    mid-sweep) into the portfolio-wide sweep summary artifact.
    This artifact is what the dashboard Governance panel renders
    and what Sustainment / Rationalization / Orchestration consume
    on their next cycles.
  skills: []
  agent_role: null
  inputs:
    artifacts:
      - governance/{portfolio_id}/{schedule_id}/drift-detection.json
      - governance/{portfolio_id}/{schedule_id}/pattern-extraction.json
      - governance/{portfolio_id}/{schedule_id}/health-report.json
      - governance/{portfolio_id}/{schedule_id}/skill-evolution.json
      - governance/{portfolio_id}/{schedule_id}/factory-capacity.json
      - governance/{portfolio_id}/{schedule_id}/model-evaluation.json
    context: [portfolio_id, schedule_id, triggered_at, cadence, wave_patterns_ready_log]
  outputs:
    artifacts:
      - governance/{portfolio_id}/{schedule_id}/sweep-summary.json
    side_effects: []
  agent_contract:
    mcp_servers: []
    repos:
      artifact: rw
      source: none
      target: none
  parallel_with: []
  gate: null
  retry_policy:
    category: transient
```

Field-by-field:
- **id** (`commit-sweep-summary`) — governance.yaml:448
- **label** (`Commit Sweep Summary`) — governance.yaml:449
- **kind** (`code`) — governance.yaml:450
- **scope** (`portfolio`) — governance.yaml:451
- **sequence** (`10`) — governance.yaml:452
- **progress_pct** (`96`) — governance.yaml:453
- **summary** (`true`) — governance.yaml:454. ⚠️ The ONLY step in the line carrying `summary: true`.
- **purpose** (folded) — governance.yaml:455-461. "Workflow code. Synthesises per-activity findings + pattern-ready acknowledgments (consumed via wave_patterns_ready signal mid-sweep) into the portfolio-wide sweep summary artifact. This artifact is what the dashboard Governance panel renders and what Sustainment / Rationalization / Orchestration consume on their next cycles."
- **skills** (`[]`) — governance.yaml:463
- **agent_role** (`null`) — governance.yaml:464
- **inputs.artifacts** — governance.yaml:466-471 (all SIX per-activity artifacts, identical list to step 9):
  - `governance/{portfolio_id}/{schedule_id}/drift-detection.json`
  - `governance/{portfolio_id}/{schedule_id}/pattern-extraction.json`
  - `governance/{portfolio_id}/{schedule_id}/health-report.json`
  - `governance/{portfolio_id}/{schedule_id}/skill-evolution.json`
  - `governance/{portfolio_id}/{schedule_id}/factory-capacity.json`
  - `governance/{portfolio_id}/{schedule_id}/model-evaluation.json`
- **inputs.context** — governance.yaml:472: `[portfolio_id, schedule_id, triggered_at, cadence, wave_patterns_ready_log]`
- **outputs.artifacts** — governance.yaml:475: `governance/{portfolio_id}/{schedule_id}/sweep-summary.json`
- **outputs.side_effects** (`[]`) — governance.yaml:476
- **agent_contract.mcp_servers** (`[]`) — governance.yaml:477
- **agent_contract.repos** — governance.yaml:479-482: `artifact: rw`, `source: none`, `target: none`
- **parallel_with** (`[]`) — governance.yaml:483
- **gate** (`null`) — governance.yaml:484
- **retry_policy.category** (`transient`) — governance.yaml:485

⚠️ GOTCHA (governance.yaml:454): `summary: true` marks this as the line's terminal synthesis step. This is the field downstream consumers (step-progress mapping, workflow) key on to identify the summary artifact. No other step has this flag.
⚠️ GOTCHA (governance.yaml:456-458 + 472): the sweep summary synthesizes per-activity findings PLUS "pattern-ready acknowledgments (consumed via wave_patterns_ready signal mid-sweep)". The acks arrive ASYNCHRONOUSLY during the sweep (from Modernization workflows acknowledging the `WavePatternsReadySignal` emitted in step 8) and are accumulated into `wave_patterns_ready_log` (context key, line 472). ⚠️ ORDERING/CONCURRENCY: acks can arrive at any time before this step runs; the workflow must collect them mid-sweep into the log. This closes the loop with `pattern.reuse_count` (§3.3 GOTCHA). The ack signal name is `wave_patterns_ready` (snake_case), distinct from the emit-direction `WavePatternsReadySignal` (PascalCase, §3.8).
⚠️ GOTCHA (governance.yaml:459-461): `sweep-summary.json` is the cross-line hand-off artifact — it is what (a) the dashboard Governance panel renders and (b) Sustainment / Rationalization / Orchestration consume on their NEXT cycles. It is `rw` (writes Git). Note `sweep-summary` is ALSO a line-level input (governance.yaml:31, via `sustainment/{portfolio_id}/*/sweep-summary.json` read at intake, governance.yaml:67) AND a line-level output (governance.yaml:47) — Governance both reads Sustainment's sweep-summary and writes its own.

---

## 4. Cross-step / cross-line summary tables (for regen verification)

### 4.1 progress_pct ladder (must be strictly increasing, file order)
| seq | id | progress_pct | kind | retry category |
|----|----|----|----|----|
| 1 | intake | 8 | code | transient |
| 2 | drift-detection | 20 | agent | agent_failure |
| 3 | pattern-extraction | 30 | agent | agent_failure |
| 4 | health-report | 40 | agent | agent_failure |
| 5 | skill-evolution | 50 | agent | agent_failure |
| 6 | factory-capacity | 60 | agent | agent_failure |
| 7 | model-evaluation | 70 | agent | agent_failure |
| 8 | propagate-patterns | 80 | code | transient |
| 9 | persist-governance-sweep-side-effects | 88 | code | transient |
| 10 | commit-sweep-summary | 96 | code | transient |

⚠️ GOTCHA: progress never reaches 100 in this contract — the final step is at 96. (Completion to 100 is presumably handled by the workflow harness after the summary commits.)

### 4.2 repos.artifact handle per step
| id | repos.artifact | repos.source | repos.target |
|----|----|----|----|
| intake | ro | none | none |
| drift-detection | rw | none | none |
| pattern-extraction | rw | none | none |
| health-report | rw | none | none |
| skill-evolution | rw | none | none |
| factory-capacity | rw | none | none |
| model-evaluation | rw | none | none |
| propagate-patterns | none | none | none |
| persist-governance-sweep-side-effects | none | none | none |
| commit-sweep-summary | rw | none | none |

⚠️ GOTCHA: EVERY step has `repos.source: none` and `repos.target: none` — Governance NEVER touches source or target code repos, only the artifact repo (and only ro/rw/none). This structurally enforces "writes ZERO fields to the application row / no code changes."

### 4.3 Side-effect targets (canonical field lists)
| step | side-effect key | target/recipient | # fields | notes present? | migration |
|----|----|----|----|----|----|
| drift-detection | target | `drift_alert` | 8 | yes | existing (025) |
| pattern-extraction | target | `pattern` | 8 | yes | existing (025) |
| health-report | target | `health_check` | 4 | yes | existing (025) |
| factory-capacity | target | `factory_capacity_plan` | 12 | no | NEW |
| model-evaluation | target | `model_benchmark_result` | 11 | no | NEW |
| propagate-patterns | **signal** | `WavePatternsReadySignal` → ModernizationWorkflow | 4 | yes | signal (not table) |
| persist-...side-effects | target ×5 | drift_alert, pattern, health_check, factory_capacity_plan, model_benchmark_result | `[...]` placeholders → resolve to canonical | n/a | mixed |

Canonical field lists (reproduce EXACTLY, in order):
- `drift_alert` (8): portfolio_id, sweep_id, app_id, drift_type, severity, details, acknowledged, created_at
- `pattern` (8): name, category, wave_id, source_apps, reuse_count, content, portfolio_id, created_at
- `health_check` (4): portfolio_id, health_index, checks, date
- `factory_capacity_plan` (12): portfolio_id, sweep_id, concurrent_wave_max, throughput_apps_per_month, cost_per_app_usd, gate_first_pass_rate, ralph_loop_iteration_avg, escalation_rate, pattern_reuse_rate, automation_ratio, time_to_modernize_days, computed_at
- `model_benchmark_result` (11): portfolio_id, sweep_id, model_id, tier, task_suite, pass_rate, cost_per_call_usd, latency_p95_ms, regression_flag, refresh_recommended, benchmarked_at
- `WavePatternsReadySignal` (4): wave_id, patterns, portfolio_id, ready_at

### 4.4 Skills / agent_role per agent step
| id | skills | agent_role | mcp_servers |
|----|----|----|----|
| drift-detection | [drift-detection] | Governance Drift Monitor | [olympus] |
| pattern-extraction | [skill-builder] | Pattern Extractor | [olympus] |
| health-report | [portfolio-health-check] | Portfolio Health Checker | [olympus] |
| skill-evolution | [skill-builder] | Skill Evolution Agent | [olympus] |
| factory-capacity | [factory-capacity-manager] | Factory Capacity Planner | [olympus] |
| model-evaluation | [model-benchmark] | Model Evaluator | [olympus] |

⚠️ GOTCHA: `pattern-extraction` and `skill-evolution` SHARE the `skill-builder` skill (governance.yaml:148, 240) but have DIFFERENT `agent_role` values (Pattern Extractor vs Skill Evolution Agent). The four `code` steps have `skills: []` + `agent_role: null` + `mcp_servers: []` (no agent dispatch).

### 4.5 parallel_with membership (EXACT — differs per step)
| id | parallel_with | count |
|----|----|----|
| intake | [] | 0 |
| drift-detection | [pattern-extraction, health-report, skill-evolution, factory-capacity] | 4 |
| pattern-extraction | [drift-detection, health-report, skill-evolution, factory-capacity] | 4 |
| health-report | [drift-detection, pattern-extraction, skill-evolution, factory-capacity] | 4 |
| skill-evolution | [drift-detection, pattern-extraction, health-report, factory-capacity] | 4 |
| factory-capacity | [drift-detection, pattern-extraction, health-report, skill-evolution] | 4 |
| model-evaluation | [drift-detection, pattern-extraction, health-report, skill-evolution, factory-capacity] | 5 |
| propagate-patterns | [] | 0 |
| persist-governance-sweep-side-effects | [] | 0 |
| commit-sweep-summary | [] | 0 |

⚠️ GOTCHA: the asymmetry (weekly activities list 4 omitting model-evaluation; model-evaluation lists all 5) is the structural encoding of "model-evaluation runs only quarterly." Reproduce each list MEMBER-FOR-MEMBER; do not normalize to a single fan-out set.

---

STEP INVENTORY: intake, drift-detection, pattern-extraction, health-report, skill-evolution, factory-capacity, model-evaluation, propagate-patterns, persist-governance-sweep-side-effects, commit-sweep-summary
STEPS REPRODUCED: 10
