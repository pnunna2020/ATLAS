# Data — Assembly Line Contract (ATOMIC regeneration spec)

**Source of truth:** `olympus-contracts/olympus_contracts/data/assembly-lines/data.yaml`
(every line citation below is `data.yaml:<line>`)

This file is the authoritative contract for the **Data** assembly line's steps,
skills, artifacts, side-effects, and agent contract. Per the file header
(`data.yaml:1-8`), every downstream consumer (Temporal workflow, Olympus API
gate service, step-progress mapping, frontend step registry) loads FROM this
file via `olympus_contracts.assembly_lines`. Application code must NOT hardcode
a copy. Drift is policed by the `test_no_hardcoded_step_lists` CI check
(`data.yaml:8`).

---

## 1. Line-Level Metadata

Reproduced field-by-field from `data.yaml:10-49`.

### `name` (`data.yaml:10`)
```
Data
```

### `description` (`data.yaml:11-21`)
Multi-line folded scalar (`>`). Full text, verbatim semantics:
> Data designs the target-state data architecture per target application. It
> defines how each target owns its data, how shared databases decompose into
> target-owned stores, how data migrates from legacy to modern, and how each
> target exposes its data as data products for the broader enterprise. Data
> runs in parallel with Architecture for every non-skip disposition. Both lines
> begin after Architecture's target-state-mapping emits TargetProvisionedSignal;
> Data's terminal gate fires DataReadyForTargetSignal back to Architecture so
> its blueprint can reference the approved data shape. Data migration planning
> lives here; migration execution lives in Modernization.

### `trigger` (`data.yaml:22`)
```
architecture-target-provisioned
```
⚠️ GOTCHA: The trigger is NOT a calendar/cron or an upstream-line-completion
event. Data is triggered specifically by Architecture's target-state-mapping
emitting `TargetProvisionedSignal` (see step `wait-for-target-provisioned`).
The `trigger` string is the symbolic name; the actual unblock is a Temporal
signal wait inside step 1.

### `depends_on` (`data.yaml:27-28`)
```yaml
depends_on:
  - Rationalization
```
⚠️ GOTCHA (`data.yaml:23-26` comment): Strict upstream is **Rationalization
only**. Data coordinates with Architecture via signals (`TargetProvisioned`,
`DataReadyForTarget`) — that coordination lives in **step contracts, not in
line-level dependencies**. Discovery is reached *transitively* through
Rationalization, so it is intentionally NOT listed in `depends_on`. Do not add
Architecture or Discovery to `depends_on` during regeneration; the signal
handshake is what couples Data and Architecture, and the dependency graph must
stay `[Rationalization]`.

### `gates` (`data.yaml:29-31`)
```yaml
gates:
  - id: G-DT
    label: Data Architecture Review
```
Exactly one line-level gate: `G-DT` / "Data Architecture Review".

### `mode` (`data.yaml:32`)
```
per-target-app
```
This is **triggered / per-target-app**, NOT continuous. The line instantiates
once per target application (every non-skip disposition). Every step also
carries `scope: per-target-app`.

### `inputs` (`data.yaml:33-40`)
Line-level input artifact list (7 entries, in order):
```yaml
inputs:
  - target-application-map
  - catalog-application
  - structural-analysis
  - business-logic
  - wave-plan
  - cloud-pattern
  - integration-arch
```

### `outputs` (`data.yaml:41-49`)
Line-level output artifact list (8 entries, in order):
```yaml
outputs:
  - data-domains
  - shared-db-analysis
  - decomposition-strategy
  - co-wave-constraints
  - data-migration-plan
  - data-product-design
  - data-architecture
  - data-architecture-summary
```

### Top-level key inventory
The complete set of top-level keys present in `data.yaml` is exactly:
`name`, `description`, `trigger`, `depends_on`, `gates`, `mode`, `inputs`,
`outputs`, `steps`. No other top-level keys exist. (Comments at lines 1-8,
23-26 are non-key.)

---

## 2. Steps (ALL 14, in order)

The `steps:` list begins at `data.yaml:51`. Each step is a list item at the
2-space `- id:` indent. There are exactly 14. Reproduced below in full, in
sequence order, preserving every field present on each step.

⚠️ GOTCHA (field-presence consistency across the file): Every step carries the
field set `id, label, kind, scope, sequence, progress_pct, purpose, skills,
agent_role, inputs{artifacts, context}, outputs{artifacts, side_effects},
agent_contract{mcp_servers, repos{artifact, source, target}}, parallel_with,
gate, retry_policy{category}`. The prompt's generic field list mentions `role`,
`inputs.context`, `agent_contract.mcp`, `loop/iteration`, `condition`,
`summary`, `progress` — in THIS file those appear as: `agent_role` (not
`role`), `agent_contract.mcp_servers` (not `mcp`), `progress_pct` (not
`progress`). No step in this file has `loop`, `iteration`, or `condition`.
Only ONE step (`data-synthesis`) carries `summary: true`. `parallel_with` is
present on every step but is `[]` (empty) on all 14 — i.e. no step declares a
sibling-parallel relationship in this contract (Data's parallelism with
Architecture is expressed at the line/signal level, not via `parallel_with`).

---

### STEP 1 — `wait-for-target-provisioned` (`data.yaml:52-84`)

- **id:** `wait-for-target-provisioned` (`data.yaml:52`)
- **label:** `Wait for Target Provisioned` (`data.yaml:53`)
- **kind:** `code` (`data.yaml:54`)
- **scope:** `per-target-app` (`data.yaml:55`)
- **sequence:** `1` (`data.yaml:56`)
- **progress_pct:** `8` (`data.yaml:57`)
- **purpose** (`data.yaml:58-63`, folded `>`):
  > Block until Architecture's target-state-mapping emits
  > TargetProvisionedSignal for this target_app_id. Captures the
  > architecture_workflow_id from the signal so the post-G-DT signal can route
  > back to the correct Architecture workflow. Not an agent dispatch — pure
  > workflow code (signal wait + id capture).
- **skills:** `[]` (`data.yaml:64`) — none
- **agent_role:** `null` (`data.yaml:65`)
- **inputs.artifacts** (`data.yaml:67-68`):
  - `architecture/{target_app_id}/target-application-map.json`
- **inputs.context** (`data.yaml:69-71`):
  - `wave_id`
  - `target_app_id`
- **outputs.artifacts:** `[]` (`data.yaml:73`)
- **outputs.side_effects:** `[]` (`data.yaml:74`)
- **agent_contract.mcp_servers:** `[]` (`data.yaml:76`)
- **agent_contract.repos** (`data.yaml:77-80`):
  - `artifact: ro`
  - `source: none`
  - `target: none`
- **parallel_with:** `[]` (`data.yaml:81`)
- **gate:** `null` (`data.yaml:82`)
- **retry_policy.category:** `transient` (`data.yaml:83-84`)

⚠️ GOTCHA: This is `kind: code`, a pure workflow step (Temporal signal wait +
id capture), NOT an agent dispatch. Two responsibilities, both load-bearing:
(1) block on `TargetProvisionedSignal` keyed by `target_app_id`; (2) capture
`architecture_workflow_id` from that signal — that captured id is consumed much
later by step 12 (`persist-data-side-effects`) to route
`DataReadyForTargetSignal` back to the originating Architecture workflow. If
regeneration drops the id-capture, the post-gate handshake to Architecture
breaks.

---

### STEP 2 — `domain-discovery` (`data.yaml:86-124`)

- **id:** `domain-discovery` (`data.yaml:86`)
- **label:** `Data Domain Discovery` (`data.yaml:87`)
- **kind:** `agent` (`data.yaml:88`)
- **scope:** `per-target-app` (`data.yaml:89`)
- **sequence:** `2` (`data.yaml:90`)
- **progress_pct:** `15` (`data.yaml:91`)
- **purpose** (`data.yaml:92-97`, folded `>`):
  > Identify logical data domains from schema analysis, business capability
  > mapping, and entity relationship analysis. Assign every data entity the
  > target touches to exactly one domain. Domains follow business capability
  > boundaries, not application boundaries — a single domain may span many
  > targets; a single target may participate in many domains.
- **skills** (`data.yaml:98`): `[data-domain-patterns]`
- **agent_role:** `Data Architecture Lead` (`data.yaml:99`)
- **inputs.artifacts** (`data.yaml:101-105`):
  - `architecture/{target_app_id}/target-application-map.json`
  - `discovery/{source_app_id}/catalog-application.json`
  - `discovery/{source_app_id}/structural-analysis.json`
  - `rationalization/wave-{wave_id}/{source_app_id}/disposition-recommendation.json`
- **inputs.context** (`data.yaml:106-110`):
  - `wave_id`
  - `target_app_id`
  - `source_app_ids`
  - `disposition`
- **outputs.artifacts** (`data.yaml:112-113`):
  - `data/{target_app_id}/data-domains.json`
- **outputs.side_effects:** `[]` (`data.yaml:114`)
- **agent_contract.mcp_servers** (`data.yaml:116`): `[olympus]`
- **agent_contract.repos** (`data.yaml:117-120`):
  - `artifact: rw`
  - `source: ro`
  - `target: none`
- **parallel_with:** `[]` (`data.yaml:121`)
- **gate:** `null` (`data.yaml:122`)
- **retry_policy.category:** `agent_failure` (`data.yaml:123-124`)

⚠️ GOTCHA: `source_app_ids` is plural in context, but the artifact path
templates use singular `{source_app_id}` (e.g.
`discovery/{source_app_id}/catalog-application.json`). A target may map from
multiple source apps; the runtime must expand the singular-templated paths
across each id in `source_app_ids`.

---

### STEP 3 — `shared-db-analysis` (`data.yaml:126-163`)

- **id:** `shared-db-analysis` (`data.yaml:126`)
- **label:** `Shared Database Analysis` (`data.yaml:127`)
- **kind:** `agent` (`data.yaml:128`)
- **scope:** `per-target-app` (`data.yaml:129`)
- **sequence:** `3` (`data.yaml:130`)
- **progress_pct:** `25` (`data.yaml:131`)
- **purpose** (`data.yaml:132-138`, folded `>`):
  > Identify this target's participation in any shared database clusters: which
  > tables it reads, writes, owns; which other apps share the same tables;
  > coupling severity; stored-procedure / trigger / DB-link entanglement that
  > creates invisible coupling. Produces the target's perspective on the
  > cluster, not a global cluster view (global view is synthesized at wave
  > level from all targets' shared-db-analysis outputs).
- **skills** (`data.yaml:139`): `[decomposition-patterns]`
- **agent_role:** `Data Decomposition Architect` (`data.yaml:140`)
- **inputs.artifacts** (`data.yaml:142-145`):
  - `data/{target_app_id}/data-domains.json`
  - `discovery/{source_app_id}/structural-analysis.json`
  - `discovery/{source_app_id}/business-logic.json`
- **inputs.context** (`data.yaml:146-149`):
  - `wave_id`
  - `target_app_id`
  - `source_app_ids`
- **outputs.artifacts** (`data.yaml:151-152`):
  - `data/{target_app_id}/shared-db-analysis.json`
- **outputs.side_effects:** `[]` (`data.yaml:153`)
- **agent_contract.mcp_servers** (`data.yaml:155`): `[olympus]`
- **agent_contract.repos** (`data.yaml:156-159`):
  - `artifact: rw`
  - `source: ro`
  - `target: none`
- **parallel_with:** `[]` (`data.yaml:160`)
- **gate:** `null` (`data.yaml:161`)
- **retry_policy.category:** `agent_failure` (`data.yaml:162-163`)

⚠️ GOTCHA: This step deliberately produces only the **target's perspective** on
each shared-DB cluster, NOT a global cluster view. The global view is
synthesized at wave level by aggregating all targets' `shared-db-analysis`
outputs (`data.yaml:137-138`). Regeneration must not over-reach into a global
synthesis inside this per-target step.

---

### STEP 4 — `decomposition-strategy` (`data.yaml:165-204`)

- **id:** `decomposition-strategy` (`data.yaml:165`)
- **label:** `Decomposition Strategy` (`data.yaml:166`)
- **kind:** `agent` (`data.yaml:167`)
- **scope:** `per-target-app` (`data.yaml:168`)
- **sequence:** `4` (`data.yaml:169`)
- **progress_pct:** `35` (`data.yaml:170`)
- **purpose** (`data.yaml:171-178`, folded `>`):
  > Select the decoupling approach for each shared-DB cluster the target
  > participates in. Whitelisted patterns: database-per-service |
  > strangler-fig | db-facade | dedicated | shared-read-only. For each cluster,
  > emits the target's role (read | write | owner | both) and the pattern.
  > Produces co-wave constraints (must co-wave, must sequence, adjacent-wave)
  > that feed observability — the Rationalization feedback loop is
  > observational, not automatic.
- **skills** (`data.yaml:179`): `[decomposition-patterns]`
- **agent_role:** `Data Decomposition Architect` (`data.yaml:180`)
- **inputs.artifacts** (`data.yaml:182-185`):
  - `data/{target_app_id}/shared-db-analysis.json`
  - `data/{target_app_id}/data-domains.json`
  - `rationalization/wave-{wave_id}/wave-plan.json`
- **inputs.context** (`data.yaml:186-189`):
  - `wave_id`
  - `target_app_id`
  - `disposition`
- **outputs.artifacts** (`data.yaml:191-193`):
  - `data/{target_app_id}/decomposition-strategy.json`
  - `data/{target_app_id}/co-wave-constraints.json`
- **outputs.side_effects:** `[]` (`data.yaml:194`)
- **agent_contract.mcp_servers** (`data.yaml:196`): `[olympus]`
- **agent_contract.repos** (`data.yaml:197-200`):
  - `artifact: rw`
  - `source: ro`
  - `target: none`
- **parallel_with:** `[]` (`data.yaml:201`)
- **gate:** `null` (`data.yaml:202`)
- **retry_policy.category:** `agent_failure` (`data.yaml:203-204`)

⚠️ GOTCHA (whitelists — load-bearing enums, reproduce exactly):
- **Decomposition pattern whitelist** (`data.yaml:172-174`):
  `database-per-service | strangler-fig | db-facade | dedicated | shared-read-only`.
  This is the SAME pattern enum referenced by the `shared_db_cluster.pattern`
  side-effect note in step 12 (`data.yaml:519-520`: "pattern enum matches
  application.data_pattern whitelist").
- **Role enum** (`data.yaml:175`): `read | write | owner | both` — reproduced
  again in the step-12 `shared_db_cluster` side-effect note (`data.yaml:519`).
- **Co-wave constraint kinds** (`data.yaml:176`): `must co-wave`,
  `must sequence`, `adjacent-wave`.
- ⚠️ The Rationalization feedback loop driven by these co-wave constraints is
  **observational, not automatic** (`data.yaml:177-178`). Do not wire an
  automatic re-plan; the constraints "feed observability."
- This is the only non-summary, non-gate agent step that emits **two**
  artifacts (`decomposition-strategy.json` + `co-wave-constraints.json`).

---

### STEP 5 — `migration-planning` (`data.yaml:206-245`)

- **id:** `migration-planning` (`data.yaml:206`)
- **label:** `Migration Planning` (`data.yaml:207`)
- **kind:** `agent` (`data.yaml:208`)
- **scope:** `per-target-app` (`data.yaml:209`)
- **sequence:** `5` (`data.yaml:210`)
- **progress_pct:** `45` (`data.yaml:211`)
- **purpose** (`data.yaml:212-219`, folded `>`):
  > Design the detailed migration path for each database the target consumes:
  > schema transformation rules, data-sync strategy (CDC / dual-write / batch /
  > event-driven), cutover strategy (big-bang / rolling / blue-green), rollback
  > plan, and executable data-quality validation rules. Plans only —
  > Modernization's Generate step executes them. Consumes Architecture's
  > cloud-pattern best-effort to pick migration targets (e.g., Oracle → Aurora
  > PostgreSQL vs. Oracle → DynamoDB).
- **skills** (`data.yaml:220`): `[data-migration-planner]`
- **agent_role:** `Data Migration Planner` (`data.yaml:221`)
- **inputs.artifacts** (`data.yaml:223-227`):
  - `data/{target_app_id}/decomposition-strategy.json`
  - `data/{target_app_id}/shared-db-analysis.json`
  - `architecture/{target_app_id}/cloud-pattern.json`
  - `architecture/{target_app_id}/integration-arch.json`
- **inputs.context** (`data.yaml:228-231`):
  - `wave_id`
  - `target_app_id`
  - `disposition`
- **outputs.artifacts** (`data.yaml:233-234`):
  - `data/{target_app_id}/data-migration-plan.json`
- **outputs.side_effects:** `[]` (`data.yaml:235`)
- **agent_contract.mcp_servers** (`data.yaml:237`): `[olympus]`
- **agent_contract.repos** (`data.yaml:236-241`):
  - `artifact: rw`
  - `source: ro`
  - `target: none`
- **parallel_with:** `[]` (`data.yaml:242`)
- **gate:** `null` (`data.yaml:243`)
- **retry_policy.category:** `agent_failure` (`data.yaml:244-245`)

⚠️ GOTCHA (enums — reproduce exactly):
- **Data-sync strategy** (`data.yaml:214-215`): `CDC / dual-write / batch / event-driven`.
- **Cutover strategy** (`data.yaml:215-216`): `big-bang / rolling / blue-green`.
- ⚠️ "Plans only — Modernization's Generate step executes them"
  (`data.yaml:216-217`). This step PLANS migration; it does NOT migrate.
  Execution lives in the Modernization line. Regeneration must keep this step
  side-effect-free (planning artifact only).
- ⚠️ Architecture's `cloud-pattern.json` is consumed **best-effort**
  (`data.yaml:217-218`) to pick migration targets — it may be absent at this
  point (Data runs in parallel with Architecture); the agent must degrade
  gracefully when it is not yet available.

---

### STEP 6 — `data-product-design` (`data.yaml:247-285`)

- **id:** `data-product-design` (`data.yaml:247`)
- **label:** `Data Product Design` (`data.yaml:248`)
- **kind:** `agent` (`data.yaml:249`)
- **scope:** `per-target-app` (`data.yaml:250`)
- **sequence:** `6` (`data.yaml:251`)
- **progress_pct:** `55` (`data.yaml:252`)
- **purpose** (`data.yaml:253-260`, folded `>`):
  > Define the data products this target exposes: formal contracts with owner,
  > SLA (availability, latency, freshness), versioned schemas, access API,
  > quality guarantees, lineage documentation. Data products are the enduring
  > interface through which this target's data is consumed by the broader
  > enterprise (data mesh, lake, warehouse, or whichever construct the org
  > adopts). Consumes Architecture's integration-arch.json best-effort to align
  > API gateway routes.
- **skills** (`data.yaml:261`): `[data-product-specification]`
- **agent_role:** `Data Product Designer` (`data.yaml:262`)
- **inputs.artifacts** (`data.yaml:264-267`):
  - `data/{target_app_id}/data-domains.json`
  - `data/{target_app_id}/decomposition-strategy.json`
  - `architecture/{target_app_id}/integration-arch.json`
- **inputs.context** (`data.yaml:268-271`):
  - `wave_id`
  - `target_app_id`
  - `disposition`
- **outputs.artifacts** (`data.yaml:273-274`):
  - `data/{target_app_id}/data-product-design.json`
- **outputs.side_effects:** `[]` (`data.yaml:275`)
- **agent_contract.mcp_servers** (`data.yaml:277`): `[olympus]`
- **agent_contract.repos** (`data.yaml:276-281`):
  - `artifact: rw`
  - `source: ro`
  - `target: none`
- **parallel_with:** `[]` (`data.yaml:282`)
- **gate:** `null` (`data.yaml:283`)
- **retry_policy.category:** `agent_failure` (`data.yaml:284-285`)

⚠️ GOTCHA: The data-product contract MUST carry the full field set
(`data.yaml:254-256`): owner, SLA (the SLA sub-triple is **availability,
latency, freshness**), versioned schemas, access API, quality guarantees,
lineage documentation. Architecture's `integration-arch.json` is consumed
**best-effort** (`data.yaml:259-260`) to align API gateway routes — may be
absent during parallel execution.

---

### STEP 7 — `data-synthesis` (`data.yaml:287-332`)

- **id:** `data-synthesis` (`data.yaml:287`)
- **label:** `Data Architecture Synthesis` (`data.yaml:288`)
- **kind:** `agent` (`data.yaml:289`)
- **scope:** `per-target-app` (`data.yaml:290`)
- **sequence:** `7` (`data.yaml:291`)
- **progress_pct:** `65` (`data.yaml:292`)
- **summary:** `true` (`data.yaml:293`)  ← ⚠️ the ONLY step in this file with `summary`
- **purpose** (`data.yaml:294-302`, folded `>`):
  > Synthesize every upstream Data artifact (domains, shared-db analysis,
  > decomposition strategy, migration plan, data products) plus Architecture
  > context (best-effort) into one cohesive data architecture artifact.
  > Produces data-architecture.json — authoritative input for Architecture's
  > blueprint assembly and Modernization's Generate step — plus a human-readable
  > data-architecture-summary.md for G-DT reviewers. data-mesh-architecture
  > skill methodology is a reference consideration here, not a dispatched skill;
  > data-modeling owns the synthesis.
- **skills** (`data.yaml:303`): `[data-modeling]`
- **agent_role:** `Data Architecture Lead` (`data.yaml:304`)
- **inputs.artifacts** (`data.yaml:306-313`):
  - `data/{target_app_id}/data-domains.json`
  - `data/{target_app_id}/shared-db-analysis.json`
  - `data/{target_app_id}/decomposition-strategy.json`
  - `data/{target_app_id}/data-migration-plan.json`
  - `data/{target_app_id}/data-product-design.json`
  - `architecture/{target_app_id}/cloud-pattern.json`
  - `architecture/{target_app_id}/integration-arch.json`
- **inputs.context** (`data.yaml:314-317`):
  - `wave_id`
  - `target_app_id`
  - `source_app_ids`
- **outputs.artifacts** (`data.yaml:319-321`):
  - `data/{target_app_id}/data-architecture.json`
  - `data/{target_app_id}/data-architecture-summary.md`
- **outputs.side_effects:** `[]` (`data.yaml:322`)
- **agent_contract.mcp_servers** (`data.yaml:324`): `[olympus]`
- **agent_contract.repos** (`data.yaml:325-328`):
  - `artifact: rw`
  - `source: none`  ← ⚠️ NOTE: `source: none` here, unlike steps 2–6 which use `source: ro`
  - `target: none`
- **parallel_with:** `[]` (`data.yaml:329`)
- **gate:** `null` (`data.yaml:330`)
- **retry_policy.category:** `agent_failure` (`data.yaml:331-332`)

⚠️ GOTCHA: This is the **summary step** (`summary: true`, `data.yaml:293`) — the
only one in the line. It produces the two terminal artifacts consumed
downstream: `data-architecture.json` (authoritative input to Architecture's
blueprint assembly AND Modernization's Generate step) and the human-readable
`data-architecture-summary.md` (for G-DT reviewers).
⚠️ GOTCHA: `data-mesh-architecture` skill is a **reference consideration**, NOT
a dispatched skill (`data.yaml:301-302`). The ONLY dispatched skill is
`data-modeling`, which "owns the synthesis." Do not add `data-mesh-architecture`
to the `skills` list during regeneration.
⚠️ GOTCHA: `agent_contract.repos.source` is `none` here (`data.yaml:327`),
diverging from the `source: ro` used by steps 2–6. Synthesis reads only
already-emitted Data/Architecture artifacts from the artifact repo, never the
source repo. Cloud-pattern + integration-arch are consumed best-effort
(`data.yaml:296`).

---

### STEP 8 — `commit-data-artifacts` (`data.yaml:334-363`)

- **id:** `commit-data-artifacts` (`data.yaml:334`)
- **label:** `Commit Data Artifacts` (`data.yaml:335`)
- **kind:** `git` (`data.yaml:336`)
- **scope:** `per-target-app` (`data.yaml:337`)
- **sequence:** `8` (`data.yaml:338`)
- **progress_pct:** `72` (`data.yaml:339`)
- **purpose** (`data.yaml:340-343`, folded `>`):
  > Workflow code (not an agent dispatch). Commits every data artifact produced
  > in this run to the per-target branch in the artifact repo. One commit;
  > commit message references wave_id + target_app_id.
- **skills:** `[]` (`data.yaml:344`)
- **agent_role:** `null` (`data.yaml:345`)
- **inputs.artifacts** (`data.yaml:347-349`):
  - `data/{target_app_id}/*.json`   ← glob over all JSON artifacts
  - `data/{target_app_id}/data-architecture-summary.md`
- **inputs.context** (`data.yaml:350`): `[wave_id, target_app_id]` (inline flow sequence)
- **outputs.artifacts:** `[]` (`data.yaml:352`)
- **outputs.side_effects:** `[]` (`data.yaml:353`)
- **agent_contract.mcp_servers:** `[]` (`data.yaml:355`)
- **agent_contract.repos** (`data.yaml:356-359`):
  - `artifact: rw`
  - `source: none`
  - `target: none`
- **parallel_with:** `[]` (`data.yaml:360`)
- **gate:** `null` (`data.yaml:361`)
- **retry_policy.category:** `transient` (`data.yaml:362-363`)

⚠️ GOTCHA: `kind: git`, workflow code (not agent). Exactly **ONE commit**
(`data.yaml:342`); the commit message MUST reference `wave_id` + `target_app_id`.
Commit lands on the **per-target branch** in the artifact repo (not main). The
input artifact set is specified as a glob (`data/{target_app_id}/*.json`) plus
the explicit `.md` summary — i.e. it sweeps every JSON artifact this run
produced, not an enumerated list.

---

### STEP 9 — `create-g-dt-pr` (`data.yaml:365-397`)

- **id:** `create-g-dt-pr` (`data.yaml:365`)
- **label:** `Create G-DT Review PR` (`data.yaml:366`)
- **kind:** `git` (`data.yaml:367`)
- **scope:** `per-target-app` (`data.yaml:368`)
- **sequence:** `9` (`data.yaml:369`)
- **progress_pct:** `78` (`data.yaml:370`)
- **purpose** (`data.yaml:371-376`, folded `>`):
  > Open the gate-review PR against the artifact repo's main branch. PR body
  > aggregates the data-architecture-summary + co-wave constraints callout (if
  > any) + data-product catalog preview + links to every upstream artifact.
  > Tier-1 PRs explicitly tag data-governance board + security officer for
  > stakeholder sign-off.
- **skills:** `[]` (`data.yaml:377`)
- **agent_role:** `null` (`data.yaml:378`)
- **inputs.artifacts** (`data.yaml:380-383`):
  - `data/{target_app_id}/data-architecture.json`
  - `data/{target_app_id}/data-architecture-summary.md`
  - `data/{target_app_id}/co-wave-constraints.json`
- **inputs.context** (`data.yaml:384`): `[wave_id, target_app_id, risk_tier]`
- **outputs.artifacts:** `[]` (`data.yaml:386`)
- **outputs.side_effects:** `[]` (`data.yaml:387`)
- **agent_contract.mcp_servers:** `[]` (`data.yaml:389`)
- **agent_contract.repos** (`data.yaml:390-393`):
  - `artifact: rw`
  - `source: none`
  - `target: none`
- **parallel_with:** `[]` (`data.yaml:394`)
- **gate:** `null` (`data.yaml:395`)
- **retry_policy.category:** `transient` (`data.yaml:396-397`)

⚠️ GOTCHA: PR is opened against the artifact repo's **main** branch
(`data.yaml:372`). PR body composition is load-bearing — it MUST aggregate, in
this order: (1) the `data-architecture-summary`; (2) a co-wave constraints
callout **if any** (conditional inclusion); (3) data-product catalog preview;
(4) links to every upstream artifact (`data.yaml:372-374`).
⚠️ GOTCHA: **Tier-1 conditional** — when `risk_tier` is Tier 1, the PR MUST
explicitly tag the data-governance board **and** the security officer for
stakeholder sign-off (`data.yaml:374-376`). `risk_tier` is in context precisely
to drive this branch.

---

### STEP 10 — `ai-pre-review` (`data.yaml:399-435`)

- **id:** `ai-pre-review` (`data.yaml:399`)
- **label:** `AI Pre-Review` (`data.yaml:400`)
- **kind:** `agent` (`data.yaml:401`)
- **scope:** `per-target-app` (`data.yaml:402`)
- **sequence:** `10` (`data.yaml:403`)
- **progress_pct:** `82` (`data.yaml:404`)
- **purpose** (`data.yaml:405-411`, folded `>`):
  > Advisory readiness check before the human gate opens — flags likely blocker
  > findings (write-ownership conflicts on shared tables, unreversible migration
  > plans, data-product SLAs incoherent with cloud-pattern choice, accessibility
  > of data products, quality rules not executable) so reviewers and the
  > workflow can short-circuit obvious rejections.
- **skills** (`data.yaml:412`): `[gate-pre-review]`
- **agent_role:** `Gate Pre-Reviewer` (`data.yaml:413`)
- **inputs.artifacts** (`data.yaml:415-417`):
  - `data/{target_app_id}/data-architecture.json`
  - `data/{target_app_id}/data-architecture-summary.md`
- **inputs.context** (`data.yaml:418`): `[wave_id, target_app_id, risk_tier]`
- **outputs.artifacts** (`data.yaml:420-421`):
  - `data/{target_app_id}/pre-review.json`
- **outputs.side_effects** (`data.yaml:422-425`):
  - **side_effect #1:**
    - `target: gate_pre_review`
    - `fields: [gate_id, findings_json]`
    - `notes: Persisted so the gate-review UI can surface pre-review findings.`
- **agent_contract.mcp_servers** (`data.yaml:427`): `[olympus]`
- **agent_contract.repos** (`data.yaml:428-431`):
  - `artifact: rw`
  - `source: none`
  - `target: none`
- **parallel_with:** `[]` (`data.yaml:432`)
- **gate:** `null` (`data.yaml:433`)
- **retry_policy.category:** `agent_failure` (`data.yaml:434-435`)

⚠️ GOTCHA: This is **advisory only** — it does NOT gate. Its purpose is to flag
likely blockers so reviewers/workflow "can short-circuit obvious rejections"
(`data.yaml:410-411`). The blocker-finding categories enumerated
(`data.yaml:407-410`) are: write-ownership conflicts on shared tables;
unreversible migration plans; data-product SLAs incoherent with cloud-pattern
choice; accessibility of data products; quality rules not executable.
⚠️ GOTCHA: First step in the line with a non-empty `side_effects`. It writes to
the `gate_pre_review` table with exactly fields `gate_id`, `findings_json`. This
persistence is what lets the gate-review UI surface pre-review findings — the
side effect is not optional decoration.

**Side-effect table — `gate_pre_review`:**
| field | source |
|---|---|
| `gate_id` | `data.yaml:424` |
| `findings_json` | `data.yaml:424` |

---

### STEP 11 — `gate-review-dt` (`data.yaml:437-482`)

- **id:** `gate-review-dt` (`data.yaml:437`)
- **label:** `G-DT Data Architecture Review` (`data.yaml:438`)
- **kind:** `gate` (`data.yaml:439`)
- **scope:** `per-target-app` (`data.yaml:440`)
- **sequence:** `11` (`data.yaml:441`)
- **progress_pct:** `88` (`data.yaml:442`)
- **purpose** (`data.yaml:443-448`, folded `>`):
  > Human review of the data architecture by data-governance board (plus
  > security officer for Tier-1). Dual/triple-signal approval model — PM merges
  > PR AND stakeholder(s) fire the matching scope signal(s). Rejection loops
  > back through the contested steps (up to 3 rework iterations before workflow
  > fails).
- **skills:** `[]` (`data.yaml:449`)
- **agent_role:** `null` (`data.yaml:450`)
- **inputs.artifacts** (`data.yaml:452-455`):
  - `data/{target_app_id}/data-architecture.json`
  - `data/{target_app_id}/data-architecture-summary.md`
  - `data/{target_app_id}/pre-review.json`
- **inputs.context** (`data.yaml:456`): `[wave_id, target_app_id, risk_tier]`
- **outputs.artifacts:** `[]` (`data.yaml:458`)
- **outputs.side_effects** (`data.yaml:459-472`):
  - **side_effect #1:**
    - `target: gate_record`
    - `fields: [gate_id, status, approved_by, approved_at]`
  - **side_effect #2:**
    - `target: application`
    - `fields` (block list, `data.yaml:463-468`):
      - `data_architecture_ref`
      - `data_migration_plan_ref`
      - `data_pattern`
      - `data_decided_at`
      - `data_domains`
    - `notes` (`data.yaml:469-472`, folded `>`):
      > Applied via persist_data_side_effects activity after gate approval.
      > data_architecture_ref is the committed path of data-architecture.json at
      > the merged commit.
- **agent_contract.mcp_servers:** `[]` (`data.yaml:473`)
- **agent_contract.repos** (`data.yaml:474-478`):
  - `artifact: rw`
  - `source: none`
  - `target: none`
- **parallel_with:** `[]` (`data.yaml:479`)
- **gate:** `G-DT` (`data.yaml:480`)  ← only step with a non-null `gate`
- **retry_policy.category:** `validation_failure` (`data.yaml:481-482`)

⚠️ GOTCHA (approval model — reproduce exactly, `data.yaml:445-447`):
**Dual/triple-signal approval** — the PM merges the PR **AND** stakeholder(s)
fire the matching scope signal(s). It is NOT a single approval. "Triple" applies
for Tier-1 (data-governance board + security officer both sign, plus PM merge).
⚠️ GOTCHA (rejection loop — `data.yaml:447-448`): Rejection loops back through
the **contested steps**, with a hard cap of **up to 3 rework iterations before
the workflow fails**. Regeneration must enforce the 3-iteration ceiling.
⚠️ GOTCHA (side-effect provenance): The `application` side-effect on THIS gate
step is annotated "Applied via persist_data_side_effects activity after gate
approval" (`data.yaml:469-471`). So although the field write is *declared* on
the gate step, it is *physically performed* by step 12
(`persist-data-side-effects`). The two steps share the identical
`application`-table field set — this is intentional (the gate declares the
contract; the post-gate code step executes it). `data_architecture_ref` = the
committed path of `data-architecture.json` at the merged commit
(`data.yaml:471-472`).

**Side-effect table #1 — `gate_record`:**
| field | source |
|---|---|
| `gate_id` | `data.yaml:461` |
| `status` | `data.yaml:461` |
| `approved_by` | `data.yaml:461` |
| `approved_at` | `data.yaml:461` |

**Side-effect table #2 — `application`:**
| field | source |
|---|---|
| `data_architecture_ref` | `data.yaml:464` |
| `data_migration_plan_ref` | `data.yaml:465` |
| `data_pattern` | `data.yaml:466` |
| `data_decided_at` | `data.yaml:467` |
| `data_domains` | `data.yaml:468` |

---

### STEP 12 — `persist-data-side-effects` (`data.yaml:484-537`)

- **id:** `persist-data-side-effects` (`data.yaml:484`)
- **label:** `Persist Data Side-Effects` (`data.yaml:485`)
- **kind:** `code` (`data.yaml:486`)
- **scope:** `per-target-app` (`data.yaml:487`)
- **sequence:** `12` (`data.yaml:488`)
- **progress_pct:** `94` (`data.yaml:489`)
- **purpose** (`data.yaml:490-497`, folded `>`):
  > Post-gate projection. Parses the merged data-architecture +
  > decomposition-strategy and writes the authoritative data fields onto
  > application (target row) plus shared_db_cluster rows (one per cluster this
  > target participates in). Single consolidated activity following the
  > Discovery / Rationalization / Architecture pattern — one writer per field.
  > Fires DataReadyForTargetSignal at the end so Architecture's step 5 unblocks.
- **skills:** `[]` (`data.yaml:498`)
- **agent_role:** `null` (`data.yaml:499`)
- **inputs.artifacts** (`data.yaml:501-503`):
  - `data/{target_app_id}/data-architecture.json`
  - `data/{target_app_id}/decomposition-strategy.json`
- **inputs.context** (`data.yaml:504`): `[wave_id, target_app_id, architecture_workflow_id]`
- **outputs.artifacts:** `[]` (`data.yaml:506`)
- **outputs.side_effects** (`data.yaml:507-527`):
  - **side_effect #1:**
    - `target: application`
    - `fields` (block list, `data.yaml:509-514`):
      - `data_architecture_ref`
      - `data_migration_plan_ref`
      - `data_pattern`
      - `data_decided_at`
      - `data_domains`
  - **side_effect #2:**
    - `target: shared_db_cluster`
    - `fields: [target_app_id, cluster_id, role, pattern, created_at]` (`data.yaml:516`)
    - `notes` (`data.yaml:517-520`, folded `>`):
      > One row per shared-DB cluster this target participates in. role enum:
      > read | write | owner | both. pattern enum matches application.data_pattern
      > whitelist.
  - **side_effect #3 (signal):**
    - `signal: DataReadyForTargetSignal` (`data.yaml:521`)
    - `fields: [target_app_id, data_architecture_ref, data_migration_plan_ref, approved_at]` (`data.yaml:522`)
    - `target: ArchitectureWorkflow (architecture_workflow_id from Step 0)` (`data.yaml:523`)
    - `notes` (`data.yaml:524-527`, folded `>`):
      > Fired at the end of this step so Architecture's data-architecture
      > handshake unblocks. The target architecture_workflow_id was captured from
      > TargetProvisionedSignal in Step 0.
- **agent_contract.mcp_servers:** `[]` (`data.yaml:528`)
- **agent_contract.repos** (`data.yaml:529-533`):
  - `artifact: ro`  ← ⚠️ read-only here (reads merged artifacts; does not write artifact repo)
  - `source: none`
  - `target: none`
- **parallel_with:** `[]` (`data.yaml:534`)
- **gate:** `null` (`data.yaml:535`)
- **retry_policy.category:** `validation_failure` (`data.yaml:536-537`)

⚠️ GOTCHA: `kind: code`, post-gate projection. It PARSES the merged
`data-architecture.json` + `decomposition-strategy.json` and writes the
authoritative fields. "Single consolidated activity following the Discovery /
Rationalization / Architecture pattern — **one writer per field**"
(`data.yaml:493-495`). Do not split this into multiple writers per field; the
one-writer-per-field invariant is shared across lines.
⚠️ GOTCHA (signal fan-out — the crux of the Data↔Architecture handshake): This
step FIRES `DataReadyForTargetSignal` at its very end (`data.yaml:496-497`,
`521-527`). The signal targets `ArchitectureWorkflow` using the
`architecture_workflow_id` that was **captured back in Step 0/Step 1**
(`wait-for-target-provisioned`, `data.yaml:526-527` references "Step 0";
`data.yaml:523` says "architecture_workflow_id from Step 0"). ⚠️ Numbering note:
the contract's prose calls the capture step "Step 0" (`data.yaml:523, 527`)
while the list `sequence` numbers it `1`. They refer to the SAME step
(`wait-for-target-provisioned`). The signal unblocks **Architecture's step 5**
(`data.yaml:497`) / "Architecture's data-architecture handshake"
(`data.yaml:524-525`). If `architecture_workflow_id` was not captured in step 1,
this signal cannot route and Architecture deadlocks.
⚠️ GOTCHA (shared_db_cluster row cardinality): ONE row per shared-DB cluster
this target participates in (`data.yaml:517-518`). `role` enum =
`read | write | owner | both` (`data.yaml:518-519`); `pattern` enum matches the
`application.data_pattern` whitelist (`data.yaml:519-520`) — i.e. the step-4
decomposition pattern whitelist `database-per-service | strangler-fig |
db-facade | dedicated | shared-read-only`.
⚠️ GOTCHA (duplicate application-field write): The `application`-table field set
here (`data.yaml:509-514`) is IDENTICAL to the one declared on step 11's gate
(`data.yaml:463-468`). This is the physical executor of step 11's declared
contract — not a contradiction. Both list `data_architecture_ref`,
`data_migration_plan_ref`, `data_pattern`, `data_decided_at`, `data_domains`.

**Side-effect table #1 — `application`:**
| field | source |
|---|---|
| `data_architecture_ref` | `data.yaml:510` |
| `data_migration_plan_ref` | `data.yaml:511` |
| `data_pattern` | `data.yaml:512` |
| `data_decided_at` | `data.yaml:513` |
| `data_domains` | `data.yaml:514` |

**Side-effect table #2 — `shared_db_cluster`:**
| field | source | notes |
|---|---|---|
| `target_app_id` | `data.yaml:516` | |
| `cluster_id` | `data.yaml:516` | |
| `role` | `data.yaml:516` | enum: `read \| write \| owner \| both` |
| `pattern` | `data.yaml:516` | enum matches `application.data_pattern` whitelist |
| `created_at` | `data.yaml:516` | |

**Side-effect #3 — signal `DataReadyForTargetSignal`:**
| field | source |
|---|---|
| `target_app_id` | `data.yaml:522` |
| `data_architecture_ref` | `data.yaml:522` |
| `data_migration_plan_ref` | `data.yaml:522` |
| `approved_at` | `data.yaml:522` |

Signal target: `ArchitectureWorkflow` (resolved by `architecture_workflow_id`
captured in step 1). (`data.yaml:523`)

---

### STEP 13 — `merge-data-pr` (`data.yaml:539-575`)

- **id:** `merge-data-pr` (`data.yaml:539`)
- **label:** `Merge Data PR` (`data.yaml:540`)
- **kind:** `git` (`data.yaml:541`)
- **scope:** `per-target-app` (`data.yaml:542`)
- **sequence:** `13` (`data.yaml:543`)
- **progress_pct:** `98` (`data.yaml:544`)
- **purpose** (`data.yaml:545-551`, folded `>`):
  > Final merge of the approved data PR. Wrap-up: updates
  > application.current_line to Architecture (when Architecture is still
  > running; Data's merge is usually the gate-blocker, not the wave-exit point),
  > status to `data_complete`. Note: Data's terminal step does not advance
  > current_line to Modernization — Architecture's G-02 merge is the wave-exit
  > for the target.
- **skills:** `[]` (`data.yaml:552`)
- **agent_role:** `null` (`data.yaml:553`)
- **inputs.artifacts:** `[]` (`data.yaml:555`)
- **inputs.context** (`data.yaml:556`): `[wave_id, target_app_id, pr_number]`
- **outputs.artifacts:** `[]` (`data.yaml:558`)
- **outputs.side_effects** (`data.yaml:559-564`):
  - **side_effect #1:**
    - `target: application`
    - `fields: [data_current_status, updated_at]` (`data.yaml:561`)
    - `notes` (`data.yaml:562-564`, folded `>`):
      > Data-line-specific status tracking; does NOT touch current_line
      > (Architecture owns that for the target).
- **agent_contract.mcp_servers:** `[]` (`data.yaml:565`)
- **agent_contract.repos** (`data.yaml:566-570`):
  - `artifact: rw`
  - `source: none`
  - `target: none`
- **parallel_with:** `[]` (`data.yaml:571`)
- **gate:** `null` (`data.yaml:572`)
- **retry_policy.category:** `agent_failure` (`data.yaml:573-575`)

⚠️ GOTCHA (the central wave-exit subtlety, `data.yaml:546-551` vs side-effect
note `562-564`): The PROSE purpose says the wrap-up "updates
application.current_line to Architecture ... status to `data_complete`"
(`data.yaml:546-549`). BUT the side-effect declaration writes only
`data_current_status` + `updated_at` (`data.yaml:561`) and its note EXPLICITLY
says it "does NOT touch current_line (Architecture owns that for the target)"
(`data.yaml:562-564`). The authoritative side-effect contract wins: **this step
must NOT write `current_line`.** The prose mention of `current_line → Architecture`
is descriptive context for the surrounding wave behavior, while the binding
side-effect set is `{data_current_status, updated_at}`. Regeneration must write
only those two fields on `application` and leave `current_line` untouched.
⚠️ GOTCHA: Data's terminal step does **NOT** advance `current_line` to
Modernization (`data.yaml:549-551`). The wave-exit for the target is
**Architecture's G-02 merge**, not Data's merge. Data's merge is "usually the
gate-blocker, not the wave-exit point" (`data.yaml:547-548`). The status value
written is `data_complete` (note the field is `data_current_status`, a
Data-line-specific status column, per `data.yaml:563`).
⚠️ GOTCHA: `retry_policy.category` is `agent_failure` here (`data.yaml:574`)
even though `kind: git` (not an agent). The other `git`/`code` steps use
`transient` or `validation_failure`. This is an intentional (if surprising)
classification in the contract — preserve it verbatim; do not "correct" it to
`transient`.

**Side-effect table #1 — `application`:**
| field | source | notes |
|---|---|---|
| `data_current_status` | `data.yaml:561` | set to `data_complete`; Data-line-specific; does NOT touch `current_line` |
| `updated_at` | `data.yaml:561` | |

---

## 3. ⚠️ STEP COUNT — AUTHORITATIVE DISCREPANCY WITH THE TASK BRIEF

The regeneration task brief asserted this file has "EXACTLY 14 steps." **It does
not.** The actual `data.yaml` (full file is 575 lines, verified read end-to-end)
contains **EXACTLY 13** steps under the `steps:` block.

Evidence (do not trust prose, trust the file):
- `steps:` begins at `data.yaml:51`.
- The list items at the `2-space '- id:'` indent *within* `steps:` are, in order
  and with their literal line numbers:
  1. `data.yaml:52`  `wait-for-target-provisioned`
  2. `data.yaml:86`  `domain-discovery`
  3. `data.yaml:126` `shared-db-analysis`
  4. `data.yaml:165` `decomposition-strategy`
  5. `data.yaml:206` `migration-planning`
  6. `data.yaml:247` `data-product-design`
  7. `data.yaml:287` `data-synthesis`
  8. `data.yaml:334` `commit-data-artifacts`
  9. `data.yaml:365` `create-g-dt-pr`
  10. `data.yaml:399` `ai-pre-review`
  11. `data.yaml:437` `gate-review-dt`
  12. `data.yaml:484` `persist-data-side-effects`
  13. `data.yaml:539` `merge-data-pr`  ← last item; file ends at line 575.
- The `sequence:` fields run `1..13` with no gaps and no duplicates — one per
  step, exactly 13 distinct values.
- There is a 14th `- id:` token in the file at `data.yaml:30` (`- id: G-DT`),
  but it lives under the **`gates:`** block (`data.yaml:29-31`), NOT under
  `steps:`. A naive `grep "^  - id:"` returns 14 matches and conflates the
  gate-list entry with the step-list entries. That gate entry is line-level
  metadata (already reproduced in §1), not a step.

**Conclusion for the regenerating engineer:** rebuild Data with **13 steps**, in
the order above. Do NOT fabricate a 14th step to satisfy the brief — there is no
source for one, and inventing it would break behavioral parity (the Temporal
workflow, gate service, progress map, and frontend step registry all load these
13 from this file; `test_no_hardcoded_step_lists` would reject a phantom step).

⚠️ Narrative "Step 0" vs `sequence: 1`: The contract's prose for
`persist-data-side-effects` refers to the capture step as "Step 0"
(`data.yaml:523, 527`), while that step carries `sequence: 1` in the list. They
are the SAME step (`wait-for-target-provisioned`). Narrative numbering and the
`sequence` field are offset by one for the first step; treat each step's own
`sequence:` value as authoritative for ordering.

## 4. Cross-Step Invariants & Reproduction Notes

- **`scope`:** `per-target-app` on all 13 steps (matches line-level
  `mode: per-target-app`).
- **`repos.source` divergence:** steps 2–6 (`domain-discovery`,
  `shared-db-analysis`, `decomposition-strategy`, `migration-planning`,
  `data-product-design`) set `source: ro`; the other 8 steps (1, 7, 8, 9, 10,
  11, 12, 13) set `source: none`. Step 12 (`persist-data-side-effects`)
  additionally sets `artifact: ro` (read-only) — unique among the steps that
  otherwise hold `artifact: rw`. Every one of the 13 steps sets `target: none`
  (Data never writes the target application code repo).
- **`mcp_servers`:** `[olympus]` on all 6 agent steps (sequences 2,3,4,5,6,7,10);
  `[]` on all `code`/`git`/`gate` steps (sequences 1,8,9,11,12,13).
- **`retry_policy.category` by kind:** `code`→ step 1 `transient`, step 12
  `validation_failure`; `agent`→ all six `agent_failure`; `git`→ step 8
  `transient`, step 9 `transient`, step 13 `agent_failure` (⚠️ anomaly: a `git`
  step with `agent_failure`, noted on step 13); `gate`→ step 11
  `validation_failure`.
- **Only one `summary: true`** step: `data-synthesis` (sequence 7,
  `data.yaml:293`).
- **Only one non-null `gate`** field: `G-DT` on `gate-review-dt` (sequence 11,
  `data.yaml:480`).
- **Side-effects appear on exactly 4 steps:** step 10 (`gate_pre_review`),
  step 11 (`gate_record` + `application`), step 12 (`application` +
  `shared_db_cluster` + signal `DataReadyForTargetSignal`), step 13
  (`application`). The other 9 steps have `side_effects: []`.
- **`parallel_with` is `[]` on all 13 steps.** Data's parallelism with
  Architecture is expressed at line/signal scope (TargetProvisionedSignal /
  DataReadyForTargetSignal), never via this field.
- **Signal handshake (Data ↔ Architecture):** step 1 captures
  `architecture_workflow_id` from `TargetProvisionedSignal`; step 12 fires
  `DataReadyForTargetSignal` back to that workflow id. These are the only two
  signal touch-points and they bracket the entire line.

---

STEP INVENTORY: wait-for-target-provisioned, domain-discovery, shared-db-analysis, decomposition-strategy, migration-planning, data-product-design, data-synthesis, commit-data-artifacts, create-g-dt-pr, ai-pre-review, gate-review-dt, persist-data-side-effects, merge-data-pr

STEPS REPRODUCED: 13 (the source file `data.yaml` contains 13 steps under `steps:`, not 14; the 14th `- id:` token at data.yaml:30 is the `G-DT` entry under `gates:`, reproduced in §1 as line-level metadata)
