# Rationalization — Assembly Line Contract (ATOMIC regeneration spec)

> **REFRESHED to HEAD 7cb3b20c (2026-06-15).** Reconciled field-by-field against the live `rationalization.yaml` (874 lines, 21 steps, sequences 1–21). The ONLY content change versus the prior baseline: the three wave-planning artifacts (`wave-plan.json`, `wave-plan-validation.json`, `factory-routing.json`) moved from the `planning/{wave_id}/` path prefix to `rationalization/wave-{wave_id}/`. Affects Steps 15, 16, 17, 20 (producers + consumers). Every other field (skills, agent_roles, conditions, side-effects, repo tri-states, retry categories, progress_pct, sequence, line metadata) is unchanged and verified against the loader output at HEAD. All line-number citations remain valid (the file is still 874 lines). Search "CHANGED AT HEAD" for the diffs.

**Source of truth:** `olympus-contracts/olympus_contracts/data/assembly-lines/rationalization.yaml` (874 lines).

This document reproduces, field-by-field, the authoritative Rationalization assembly-line contract. The YAML is the single source of truth: every downstream consumer (Temporal workflow, Olympus API gate service, step-progress mapping, frontend step registry) loads FROM this file via `olympus_contracts.assembly_lines`. Application code must not hardcode a copy — drift is policed by the `test_no_hardcoded_step_lists` CI check (rationalization.yaml:1-8, header comment).

⚠️ GOTCHA (rationalization.yaml:1-8): The file header is a normative warning, not decoration. There is a CI check named `test_no_hardcoded_step_lists` that fails if any application code embeds a literal copy of these step lists. When regenerating, the consumer code must read this YAML at runtime/import time, never inline the step ids/skills/side-effects.

⚠️ GOTCHA — YAML scalar folding: `description` and every step `purpose` use the YAML folded-block scalar (`>`). Folded scalars collapse newlines into single spaces (with blank lines becoming newline boundaries). The reproduced prose below preserves the wording exactly; when re-serializing to YAML use `>` (folded) form, not `|` (literal), or whitespace semantics will differ.

⚠️ GOTCHA — gate id namespace collision: A naive `grep "^  - id:"` over the file returns 25 matches, but two of them (lines 25, 27) are entries under the top-level `gates:` list (`G-RR`, `G-DA`), NOT steps. The steps list (under `steps:` at line 58) contains EXACTLY 23 step `- id:` entries (lines 59–829). Do not miscount by including the gate-definition ids.

---

## 1. Line-level metadata

Reproduced verbatim from rationalization.yaml:10-56. Top-level keys present, in file order: `name`, `description`, `trigger`, `depends_on`, `gates`, `mode`, `inputs`, `outputs`, `steps`. (Confirmed: those are the only top-level keys; verified by `grep -nE "^[a-z_]+:"`.)

### `name` (rationalization.yaml:10)
```
Rationalization
```

### `description` (rationalization.yaml:11-20, folded scalar `>`)
> Wave-scoped portfolio analysis. Operates on every application in a wave simultaneously, detecting cross-app and intra-app redundancy, recommending per-app dispositions with evidence citations, classifying risk, scoring readiness across six dimensions, and sequencing the wave for downstream factories. Produces the executive-readable wave-outcome-synthesis.json that drives the portfolio target-state rollup and feeds every downstream line's marching orders. Rationalization is where strategy is set; it runs once per wave, not per-application, and consumes Discovery artifacts as its primary input.

### `trigger` (rationalization.yaml:21)
```
wave-ready
```
(This is the line trigger. Compare with each step's `kind`/`scope`. The line is **triggered**, fired by the `wave-ready` event — NOT a continuous/cron line.)

### `depends_on` (rationalization.yaml:22-23)
```yaml
depends_on:
  - Discovery
```
Single upstream dependency: **Discovery**.

### `gates` (rationalization.yaml:24-28)
Two gate definitions, each with `id` + `label`:
```yaml
gates:
  - id: G-RR
    label: Redundancy Review
  - id: G-DA
    label: Disposition Approval
```
- `G-RR` → "Redundancy Review"
- `G-DA` → "Disposition Approval"

⚠️ GOTCHA: These gate ids are referenced later by individual gate-kind steps via their step-level `gate:` field (`gate-review-rr` → `gate: G-RR` at line 350; `gate-review-da` → `gate: G-DA` at line 782). All other steps carry `gate: null`.

### `mode` (rationalization.yaml:29)
```
per-wave
```
⚠️ GOTCHA — mode vs scope: The line-level `mode: per-wave` AND every single step's `scope: per-wave` both declare per-wave granularity. This line is NOT continuous; it runs **once per wave**, not per-application and not on a schedule. Several steps additionally fan out per-app-in-wave (see `fanout` fields below), but the line invocation unit is the wave.

### `inputs` (rationalization.yaml:30-37)
Line-level input artifact-type identifiers (7 entries):
```yaml
inputs:
  - discovery-synthesis
  - catalog-application
  - business-logic
  - structural-analysis
  - ux-accessibility
  - quality-risk
  - tco-baseline
```

### `outputs` (rationalization.yaml:38-56)
Line-level output artifact-type identifiers (18 entries):
```yaml
outputs:
  - redundancy-matrix
  - consolidation-report
  - ux-overlap-matrix
  - intra-app-redundancy
  - integration-graph
  - portfolio-redundancy-matrix
  - disposition-recommendation
  - disposition-governance
  - user-impact-analysis
  - classification
  - complexity-classification
  - portfolio-score
  - capability-consolidation-plan
  - wave-plan
  - wave-plan-validation
  - factory-routing
  - wave-outcome-synthesis
  - portfolio-manifest
```

⚠️ GOTCHA: The line-level `inputs`/`outputs` are bare artifact-TYPE names (no path templates). The per-step `inputs.artifacts`/`outputs.artifacts` use fully-templated repo paths (e.g. `discovery/{app_id}/catalog-application.json`). They are different representations and both must be reproduced. Also note `shared-identity-report` and `gate-packet`/`gate-decision` are produced by steps but are NOT in the line-level `outputs` list — the line-level list omits intermediate/gate artifacts.

---

## 2. Steps (all 23, in file order)

Per-step field set observed across the file. Not every step has every field; reproduce only those present per step:
`id`, `label`, `kind`, `scope`, `sequence`, `progress_pct`, `fanout` (optional), `condition` (optional), `summary` (optional), `purpose` (folded scalar), `skills`, `agent_role`, `inputs.artifacts`, `inputs.context`, `outputs.artifacts`, `outputs.side_effects` (each with `target` + `fields`, optionally `notes`), `outputs.consumers` (optional), `agent_contract.mcp_servers`, `agent_contract.repos.{artifact, source, target}`, `parallel_with`, `gate`, `retry_policy.category`.

⚠️ GOTCHA — field naming note: The contract uses `agent_contract.mcp_servers` (not `mcp`) and `agent_contract.repos` (with sub-keys `artifact`/`source`/`target`). It uses `agent_role` (a scalar string or `null`), not `role`. `skills` is always a list (possibly empty `[]`). `progress_pct` (not `progress`) carries the numeric progress percentage. These exact key names must be preserved.

⚠️ GOTCHA — repo permission tri-state: `agent_contract.repos.{artifact,source,target}` values are one of `rw`, `ro`, `none`. They vary per step and are load-bearing for sandbox permissions. Reproduce each exactly; do not normalize. Notably some steps set `source: none` (e.g. compare-ux-overlap line 157, disposition-governance line 425) while structurally-similar steps set `source: ro` — this is intentional and per-step.

---

### Step 1 — `cross-app-redundancy` (rationalization.yaml:59-92)

- **id:** `cross-app-redundancy`
- **label:** `Cross-App Redundancy`
- **kind:** `agent`
- **scope:** `per-wave`
- **sequence:** `1`
- **progress_pct:** `5`
- **purpose** (folded, lines 65-68):
  > Detect overlapping business capabilities, data entities, operations, APIs, and technology patterns across every app in the wave. Produces the cross-app redundancy matrix that anchors Consolidate-disposition evidence.
- **skills:** `[redundancy-analyzer]`
- **agent_role:** `Rationalization Analyst`
- **inputs.artifacts:**
  - `discovery/{app_id}/catalog-application.json`
  - `discovery/{app_id}/business-logic.json`
  - `discovery/{app_id}/structural-analysis.json`
  - `discovery/{app_id}/ux-accessibility.json`
- **inputs.context:** `[wave_id, app_ids]`
- **outputs.artifacts:**
  - `rationalization/wave-{wave_id}/redundancy-matrix.json`
  - `rationalization/wave-{wave_id}/consolidation-report.md`
- **outputs.side_effects:** `[]` (none)
- **agent_contract.mcp_servers:** `[olympus]`
- **agent_contract.repos:** `artifact: rw`, `source: ro`, `target: none`
- **parallel_with:** `[intra-app-redundancy, compare-ux-overlap]`
- **gate:** `null`
- **retry_policy.category:** `agent_failure`

---

### Step 2 — `intra-app-redundancy` (rationalization.yaml:94-128)

- **id:** `intra-app-redundancy`
- **label:** `Intra-App Redundancy`
- **kind:** `agent`
- **scope:** `per-wave`
- **sequence:** `2`
- **progress_pct:** `5`
- **fanout:** `per-app-in-wave`
- **purpose** (folded, lines 101-105):
  > For each app in the wave, detect within-app redundancy — duplicate capability implementations, copy-paste business rules, internal data duplication. Feeds Modernization (not Rationalization's own downstream) with dedup targets for the Extract/Design phases.
- **skills:** `[redundancy-analyzer]`
- **agent_role:** `Rationalization Analyst`
- **inputs.artifacts:**
  - `discovery/{app_id}/business-logic.json`
  - `discovery/{app_id}/structural-analysis.json`
  - `discovery/{app_id}/quality-risk.json`
- **inputs.context:** `[wave_id, scope=intra-app]`
- **outputs.artifacts:**
  - `rationalization/wave-{wave_id}/{app_id}/intra-app-redundancy.json`
- **outputs.side_effects:** `[]` (none)
- **outputs.consumers:** `[Modernization]`
- **agent_contract.mcp_servers:** `[olympus]`
- **agent_contract.repos:** `artifact: rw`, `source: ro`, `target: none`
- **parallel_with:** `[cross-app-redundancy, compare-ux-overlap]`
- **gate:** `null`
- **retry_policy.category:** `agent_failure`

⚠️ GOTCHA: `inputs.context` literally contains the token `scope=intra-app` (line 113) — a key=value style string baked into the context list, distinguishing this step's invocation of the shared `redundancy-analyzer` skill (also used by Step 1 at cross-app scope). Reproduce the `scope=intra-app` literal exactly. Also note this is the FIRST `fanout: per-app-in-wave` step.

---

### Step 3 — `compare-ux-overlap` (rationalization.yaml:130-162)

- **id:** `compare-ux-overlap`
- **label:** `UX Overlap Analysis`
- **kind:** `agent`
- **scope:** `per-wave`
- **sequence:** `3`
- **progress_pct:** `5`
- **purpose** (folded, lines 136-140):
  > Detect persona-task-app overlap — same user role performing the same task across multiple apps. Catches swivel-chair patterns and fragmented user journeys that structural redundancy analysis misses. Feeds HCD (cross-cutting) and Consolidate-disposition evidence.
- **skills:** `[compare-ux-overlap]`
- **agent_role:** `UX Journey Analyzer`
- **inputs.artifacts:**
  - `discovery/{app_id}/ux-accessibility.json`
  - `discovery/{app_id}/catalog-application.json`
- **inputs.context:** `[wave_id, app_ids]`
- **outputs.artifacts:**
  - `rationalization/wave-{wave_id}/ux-overlap-matrix.json`
- **outputs.side_effects:** `[]` (none)
- **outputs.consumers:** `[HCD]`
- **agent_contract.mcp_servers:** `[olympus]`
- **agent_contract.repos:** `artifact: rw`, `source: none`, `target: none`
- **parallel_with:** `[cross-app-redundancy, intra-app-redundancy]`
- **gate:** `null`
- **retry_policy.category:** `agent_failure`

⚠️ GOTCHA: The skill id `compare-ux-overlap` is identical to the step id. Also `repos.source: none` here (line 157) even though the step reads Discovery artifacts — the Discovery artifacts come from the **artifact** repo (rw), not a separate source repo, so `source` is `none`. Contrast with Step 1, which sets `source: ro`.

---

### Step 4 — `portfolio-integration-mapping` (rationalization.yaml:164-204)

In-file comment block (lines 165-169, preserve as provenance):
> Stage 6 ATLAS integration (2026-05-06): portfolio-scope cross-app integration-graph synthesis before per-app disposition. Decomposes multi-subsystem apps and enumerates cross_system_capabilities[] that downstream disposition-recommender + capability-consolidation-advisor consume. Parallel with analyze-portfolio-redundancy.

- **id:** `portfolio-integration-mapping`
- **label:** `Portfolio Integration Mapping`
- **kind:** `agent`
- **scope:** `per-wave`
- **sequence:** `4`
- **progress_pct:** `8`
- **purpose** (folded, lines 175-182):
  > Synthesize per-app Discovery artifacts for every application in the wave into a single cross-application integration graph — systems, data flows, shared identifiers, external dependencies, and cross_system_capabilities[]. Decomposes multi-subsystem applications into their constituent parts before cross-app integration analysis. Without this pass, disposition decisions collapse to per-app 7Rs and miss capability-level Retire/Replace opportunities.
- **skills:** `[portfolio-integration-mapper]`
- **agent_role:** `Portfolio Integration Analyst`
- **inputs.artifacts:**
  - `discovery/{app_id}/catalog-application.json`
  - `discovery/{app_id}/dependency-graph.json`
  - `discovery/{app_id}/structural-analysis.json`
- **inputs.context:** `[wave_id, app_ids]`
- **outputs.artifacts:**
  - `rationalization/wave-{wave_id}/integration-graph.json`
- **outputs.side_effects:** `[]` (none)
- **agent_contract.mcp_servers:** `[olympus]`
- **agent_contract.repos:** `artifact: rw`, `source: ro`, `target: none`
- **parallel_with:** `[analyze-portfolio-redundancy]`
- **gate:** `null`
- **retry_policy.category:** `agent_failure`

⚠️ GOTCHA: This is the only step that reads `discovery/{app_id}/dependency-graph.json` (line 188). The output `integration-graph.json` carries `cross_system_capabilities[]`, which is the key input that disposition-recommendation (Step 9), classification (Step 12), and capability-consolidation-advisory (Step 14) downstream consume.

---

### Step 5 — `analyze-portfolio-redundancy` (rationalization.yaml:206-246)

In-file comment block (lines 207-210, preserve as provenance):
> Stage 6 ATLAS integration (2026-05-06): portfolio-wide redundancy synthesis between per-pair redundancy-analyzer output and per-app disposition. Produces the portfolio redundancy matrix plus the shared-identity report via detect_shared_identifiers.py.

- **id:** `analyze-portfolio-redundancy`
- **label:** `Portfolio Redundancy Analysis`
- **kind:** `agent`
- **scope:** `per-wave`
- **sequence:** `5`
- **progress_pct:** `11`
- **purpose** (folded, lines 216-222):
  > Synthesize per-pair redundancy findings (from redundancy-analyzer running at cross-app and intra-app scope) and per-app Discovery artifacts into a portfolio-wide redundancy matrix that identifies which applications duplicate each other's functionality. Emits the shared-identity report that disposition scoring consumes. Privacy findings for regulated identifiers are emitted on a separate track.
- **skills:** `[analyze-portfolio-redundancy]`
- **agent_role:** `Portfolio Redundancy Analyst`
- **inputs.artifacts:**
  - `rationalization/wave-{wave_id}/redundancy-matrix.json`
  - `rationalization/wave-{wave_id}/{app_id}/intra-app-redundancy.json`
  - `rationalization/wave-{wave_id}/integration-graph.json`
  - `discovery/{app_id}/business-logic.json`
- **inputs.context:** `[wave_id, app_ids]`
- **outputs.artifacts:**
  - `rationalization/wave-{wave_id}/portfolio-redundancy-matrix.json`
  - `rationalization/wave-{wave_id}/shared-identity-report.json`
- **outputs.side_effects:** `[]` (none)
- **agent_contract.mcp_servers:** `[olympus]`
- **agent_contract.repos:** `artifact: rw`, `source: ro`, `target: none`
- **parallel_with:** `[portfolio-integration-mapping]`
- **gate:** `null`
- **retry_policy.category:** `agent_failure`

⚠️ GOTCHA: Skill id `analyze-portfolio-redundancy` equals the step id. This step is `parallel_with: [portfolio-integration-mapping]` (Step 4) yet ALSO reads Step 4's output `integration-graph.json` (line 229). The parallelism here is a declared sibling relationship at the contract level; the actual data dependency on `integration-graph.json` must be honored by the workflow scheduler (i.e. they are "parallel" as a planning group but the orchestrator still respects artifact availability — over-specify this: do not start `analyze-portfolio-redundancy` before `integration-graph.json` exists). The mention of `detect_shared_identifiers.py` (line 210) ties the shared-identity-report.json output to a specific script.

---

### Step 6 — `commit-redundancy-artifacts` (rationalization.yaml:248-288)

- **id:** `commit-redundancy-artifacts`
- **label:** `Commit Redundancy Artifacts`
- **kind:** `git`
- **scope:** `per-wave`
- **sequence:** `6`
- **progress_pct:** `15`
- **purpose** (folded, lines 254-261):
  > Commit the cross-app redundancy matrix, consolidation report, UX overlap matrix, portfolio integration graph, portfolio redundancy matrix, shared-identity report, and all per-app intra-app-redundancy artifacts to the wave branch in the portfolio's artifact repo. Stage 6 ATLAS integration (2026-05-06): expanded to include portfolio-scope artifacts from portfolio-integration-mapping and analyze-portfolio-redundancy.
- **skills:** `[]` (empty)
- **agent_role:** `null`
- **inputs.artifacts:**
  - `rationalization/wave-{wave_id}/redundancy-matrix.json`
  - `rationalization/wave-{wave_id}/consolidation-report.md`
  - `rationalization/wave-{wave_id}/ux-overlap-matrix.json`
  - `rationalization/wave-{wave_id}/integration-graph.json`
  - `rationalization/wave-{wave_id}/portfolio-redundancy-matrix.json`
  - `rationalization/wave-{wave_id}/shared-identity-report.json`
  - `rationalization/wave-{wave_id}/{app_id}/intra-app-redundancy.json`
- **inputs.context:** `[]` (empty)
- **outputs.artifacts:** `[]` (empty)
- **outputs.side_effects:**
  - **target:** `artifact_repo`
    **fields:** `[commit_sha, branch]`
- **agent_contract.mcp_servers:** `[]` (empty)
- **agent_contract.repos:** `artifact: rw`, `source: none`, `target: none`
- **parallel_with:** `[]` (empty)
- **gate:** `null`
- **retry_policy.category:** `transient`

⚠️ GOTCHA: First `kind: git` step. `agent_role: null` and `mcp_servers: []` — no agent call. `retry_policy.category` is `transient` (not `agent_failure`) for all git/code/bookkeeping steps. Side-effect target `artifact_repo` writes `commit_sha` and `branch`.

---

### Step 7 — `create-grr-pr` (rationalization.yaml:290-320)

- **id:** `create-grr-pr`
- **label:** `Create G-RR PR`
- **kind:** `git`
- **scope:** `per-wave`
- **sequence:** `7`
- **progress_pct:** `18`
- **purpose** (folded, lines 296-299):
  > Open the Gate G-RR review PR against the portfolio's artifact repo main branch. Body lists wave-scoped redundancy artifacts and the per-app intra-app breakdown for stakeholder review.
- **skills:** `[]` (empty)
- **agent_role:** `null`
- **inputs.artifacts:** `[]` (empty)
- **inputs.context:** `[wave_id, wave_name]`
- **outputs.artifacts:**
  - `gate-packet`
- **outputs.side_effects:**
  - **target:** `gate_record`
    **fields:** `[evidence_package_url, gate_type, portfolio_id, workflow_id]`
- **agent_contract.mcp_servers:** `[]` (empty)
- **agent_contract.repos:** `artifact: rw`, `source: none`, `target: none`
- **parallel_with:** `[]` (empty)
- **gate:** `null`
- **retry_policy.category:** `transient`

⚠️ GOTCHA: Output artifact is the bare token `gate-packet` (not a path) — it is the gate evidence packet consumed by the next gate step. The side-effect writes to `gate_record` table with `evidence_package_url, gate_type, portfolio_id, workflow_id`. Note `gate: null` even though this step CREATES the G-RR PR — the `gate:` field marks the actual gate-decision step (Step 8), not the PR-creation step.

---

### Step 8 — `gate-review-rr` (rationalization.yaml:322-352)

- **id:** `gate-review-rr`
- **label:** `Redundancy Review Gate`
- **kind:** `gate`
- **scope:** `per-wave`
- **sequence:** `8`
- **progress_pct:** `22`
- **purpose** (folded, lines 328-332):
  > Stakeholder reviews the wave's cross-app redundancy matrix, UX overlap matrix, consolidation report, and per-app intra-app findings. PR merge = approval; rejection loops rework back through cross-app-redundancy with feedback context. Approval unlocks the per-app disposition pipeline.
- **skills:** `[]` (empty)
- **agent_role:** `null`
- **inputs.artifacts:** `[gate-packet]`
- **inputs.context:** `[]` (empty)
- **outputs.artifacts:** `[gate-decision]`
- **outputs.side_effects:**
  - **target:** `gate_record`
    **fields:** `[state, decided_at, decided_by, decision_notes]`
- **agent_contract.mcp_servers:** `[]` (empty)
- **agent_contract.repos:** `artifact: rw`, `source: none`, `target: none`
- **parallel_with:** `[]` (empty)
- **gate:** `G-RR`
- **retry_policy.category:** `validation_failure`

⚠️ GOTCHA: First `kind: gate` step. `gate: G-RR` (the only step bound to G-RR). `retry_policy.category: validation_failure` (distinct from transient/agent_failure). The rework loop on rejection goes **back through `cross-app-redundancy`** (Step 1) with feedback context — re-running the redundancy analysis group. Consumes `gate-packet`, produces `gate-decision`. Side-effect writes `state, decided_at, decided_by, decision_notes` to `gate_record`.

---

### Step 9 — `disposition-recommendation` (rationalization.yaml:354-397)

- **id:** `disposition-recommendation`
- **label:** `Disposition Recommendation`
- **kind:** `agent`
- **scope:** `per-wave`
- **sequence:** `9`
- **progress_pct:** `35`
- **fanout:** `per-app-in-wave`
- **purpose** (folded, lines 361-368):
  > For each app in the wave, synthesize Discovery evidence and wave-scoped redundancy/UX overlap findings into one of seven dispositions (Retire, Retain, Refactor, Rearchitect, Replace, Replatform, Consolidate) with traceable evidence citations. Per-app dispatch in parallel. Stage 6 ATLAS integration (2026-05-06): now also consumes the portfolio integration-graph and portfolio-redundancy-matrix so per-app 7R decisions are reconcilable against cross_system_capabilities[].
- **skills:** `[disposition-recommender]`
- **agent_role:** `Analysis Agent`
- **inputs.artifacts:**
  - `discovery/{app_id}/catalog-application.json`
  - `discovery/{app_id}/business-logic.json`
  - `discovery/{app_id}/quality-risk.json`
  - `discovery/{app_id}/ux-accessibility.json`
  - `discovery/{app_id}/tco-baseline.json`
  - `rationalization/wave-{wave_id}/redundancy-matrix.json`
  - `rationalization/wave-{wave_id}/ux-overlap-matrix.json`
  - `rationalization/wave-{wave_id}/integration-graph.json`
  - `rationalization/wave-{wave_id}/portfolio-redundancy-matrix.json`
  - `rationalization/wave-{wave_id}/{app_id}/intra-app-redundancy.json`
- **inputs.context:** `[wave_id]`
- **outputs.artifacts:**
  - `rationalization/wave-{wave_id}/{app_id}/disposition-recommendation.json`
- **outputs.side_effects:** `[]` (none)
- **agent_contract.mcp_servers:** `[olympus]`
- **agent_contract.repos:** `artifact: rw`, `source: ro`, `target: none`
- **parallel_with:** `[]` (empty)
- **gate:** `null`
- **retry_policy.category:** `agent_failure`

⚠️ GOTCHA: This step gates the entire downstream per-app disposition pipeline; it runs only after G-RR approval (Step 8). The seven dispositions enumerated in the purpose MUST be preserved exactly and in order: Retire, Retain, Refactor, Rearchitect, Replace, Replatform, Consolidate. `fanout: per-app-in-wave` but `parallel_with: []` (the fan-out parallelism is over apps, not sibling steps). Reads the largest input set in the line (10 artifacts).

---

### Step 10 — `disposition-governance` (rationalization.yaml:399-430)

- **id:** `disposition-governance`
- **label:** `Disposition Governance`
- **kind:** `agent`
- **scope:** `per-wave`
- **sequence:** `10`
- **progress_pct:** `45`
- **fanout:** `per-app-in-wave`
- **purpose** (folded, lines 406-410):
  > For each app, validate the recommendation against stakeholder sign-off policy: required stakeholders identified, evidence package complete, user transition path documented for Retire/Replace. Produces the per-app governance artifact consumed by the G-DA checklist PR.
- **skills:** `[disposition-governance]`
- **agent_role:** `Validation Agent`
- **inputs.artifacts:**
  - `rationalization/wave-{wave_id}/{app_id}/disposition-recommendation.json`
- **inputs.context:** `[wave_id]`
- **outputs.artifacts:**
  - `rationalization/wave-{wave_id}/{app_id}/disposition-governance.json`
- **outputs.side_effects:** `[]` (none)
- **agent_contract.mcp_servers:** `[olympus]`
- **agent_contract.repos:** `artifact: rw`, `source: none`, `target: none`
- **parallel_with:** `[]` (empty)
- **gate:** `null`
- **retry_policy.category:** `agent_failure`

⚠️ GOTCHA: Skill id `disposition-governance` equals the step id. `repos.source: none` (this validation reads only the rationalization artifact, not source repos). `agent_role: Validation Agent`.

---

### Step 11 — `user-impact-analysis` (rationalization.yaml:432-464)

- **id:** `user-impact-analysis`
- **label:** `User Impact Analysis`
- **kind:** `agent`
- **scope:** `per-wave`
- **sequence:** `11`
- **progress_pct:** `50`
- **fanout:** `per-app-in-wave`
- **condition:** `disposition in [Retire, Replace]`
- **purpose** (folded, lines 440-443):
  > For Retire/Replace dispositions only — quantify affected users, disrupted journeys, training burden, transition risk. Drives the transition plan that Disposition Execution consumes.
- **skills:** `[assess-user-impact]`
- **agent_role:** `Impact Analyzer`
- **inputs.artifacts:**
  - `rationalization/wave-{wave_id}/{app_id}/disposition-recommendation.json`
  - `discovery/{app_id}/ux-accessibility.json`
- **inputs.context:** `[wave_id, disposition]`
- **outputs.artifacts:**
  - `rationalization/wave-{wave_id}/{app_id}/user-impact-analysis.json`
- **outputs.side_effects:** `[]` (none)
- **agent_contract.mcp_servers:** `[olympus]`
- **agent_contract.repos:** `artifact: rw`, `source: none`, `target: none`
- **parallel_with:** `[]` (empty)
- **gate:** `null`
- **retry_policy.category:** `agent_failure`

⚠️ GOTCHA — CONDITIONAL STEP: `condition: disposition in [Retire, Replace]` (line 439). This step runs per-app ONLY when that app's disposition is `Retire` OR `Replace`. The skill id is `assess-user-impact` (note: NOT `user-impact-analysis`; the step id and skill id DIFFER here). `inputs.context` includes the literal `disposition` token. Skipped apps produce no `user-impact-analysis.json`, which downstream steps must tolerate (commit-disposition-artifacts and wave-outcome-synthesis list it as an input but it may be absent per-app).

---

### Step 12 — `classification` (rationalization.yaml:466-506)

- **id:** `classification`
- **label:** `Classification & Risk Tiering`
- **kind:** `agent`
- **scope:** `per-wave`
- **sequence:** `12`
- **progress_pct:** `60`
- **fanout:** `per-app-in-wave`
- **purpose** (folded, lines 473-481):
  > For each app, assign a risk tier (Tier 1 / 2 / 3 per client profile). Stage 6 ATLAS integration (2026-05-06): also emits a complexity classification (Simple/Moderate/Complex) via classify-complexity that drives Modernization dispatch pattern and agent-tier selection. Risk-tier cites archetype from Discovery's catalog artifact (Discovery owns archetype); complexity combines catalog counts with Pass 1 structural findings per classify-complexity/references. Tier 1 assignments pause the workflow for stakeholder confirmation.
- **skills:** `[classify-application, classify-complexity]`
- **agent_role:** `Classification Agent`
- **inputs.artifacts:**
  - `discovery/{app_id}/catalog-application.json`
  - `discovery/{app_id}/structural-analysis.json`
  - `discovery/{app_id}/quality-risk.json`
  - `rationalization/wave-{wave_id}/integration-graph.json`
  - `rationalization/wave-{wave_id}/{app_id}/disposition-recommendation.json`
- **inputs.context:** `[wave_id]`
- **outputs.artifacts:**
  - `rationalization/wave-{wave_id}/{app_id}/classification.json`
  - `rationalization/wave-{wave_id}/{app_id}/complexity-classification.json`
- **outputs.side_effects:** `[]` (none)
- **agent_contract.mcp_servers:** `[olympus]`
- **agent_contract.repos:** `artifact: rw`, `source: ro`, `target: none`
- **parallel_with:** `[]` (empty)
- **gate:** `null`
- **retry_policy.category:** `agent_failure`

⚠️ GOTCHA — TWO skills, TWO outputs: `skills: [classify-application, classify-complexity]` — this is one of only two multi-skill steps in the line. It produces TWO per-app artifacts: `classification.json` (risk tier 1/2/3) AND `complexity-classification.json` (Simple/Moderate/Complex). The purpose notes "Tier 1 assignments pause the workflow for stakeholder confirmation" — a runtime pause behavior bound to a data value (Tier 1), not declared in a `condition` field. Risk-tier values 1/2/3 come from the client profile, complexity Simple/Moderate/Complex from `classify-complexity`. Discovery owns `archetype`; this step cites it but does not own it.

---

### Step 13 — `portfolio-scoring` (rationalization.yaml:508-543)

- **id:** `portfolio-scoring`
- **label:** `Portfolio Scoring`
- **kind:** `agent`
- **scope:** `per-wave`
- **sequence:** `13`
- **progress_pct:** `68`
- **fanout:** `per-app-in-wave`
- **purpose** (folded, lines 515-519):
  > For each app, produce a six-dimensional evidence vector (business value, technical debt, user impact, cost, redundancy, modernization complexity). Runs after classification so risk_tier and archetype can be cited. Drives both disposition confidence and wave-planning sequencing.
- **skills:** `[portfolio-scorer]`
- **agent_role:** `Scoring Model`
- **inputs.artifacts:**
  - `rationalization/wave-{wave_id}/{app_id}/classification.json`
  - `rationalization/wave-{wave_id}/{app_id}/disposition-recommendation.json`
  - `discovery/{app_id}/quality-risk.json`
  - `discovery/{app_id}/tco-baseline.json`
  - `rationalization/wave-{wave_id}/redundancy-matrix.json`
- **inputs.context:** `[wave_id]`
- **outputs.artifacts:**
  - `rationalization/wave-{wave_id}/{app_id}/portfolio-score.json`
- **outputs.side_effects:** `[]` (none)
- **agent_contract.mcp_servers:** `[olympus]`
- **agent_contract.repos:** `artifact: rw`, `source: none`, `target: none`
- **parallel_with:** `[]` (empty)
- **gate:** `null`
- **retry_policy.category:** `agent_failure`

⚠️ GOTCHA: The six scoring dimensions MUST be preserved exactly and in order: business value, technical debt, user impact, cost, redundancy, modernization complexity. Hard ordering dependency: runs AFTER `classification` (Step 12) so it can cite `risk_tier` (from classification.json) and `archetype`. Output is per-app `portfolio-score.json`.

---

### Step 14 — `capability-consolidation-advisory` (rationalization.yaml:545-587)

In-file comment block (lines 546-550, preserve as provenance):
> Stage 6 ATLAS integration (2026-05-06): cross-app capability-level disposition advice. Runs after ≥2 per-app dispositions exist. Consumes integration-graph cross_system_capabilities[] and per-app dispositions; emits capability-consolidation-plan.json that sequencer uses for cross-capability wave ordering.

- **id:** `capability-consolidation-advisory`
- **label:** `Capability Consolidation Advisory`
- **kind:** `agent`
- **scope:** `per-wave`
- **sequence:** `14`
- **progress_pct:** `73`
- **purpose** (folded, lines 556-563):
  > Produce the capability-consolidation-plan.json turning portfolio- level observations into executable consolidation guidance. For each capability in integration-graph.cross_system_capabilities[] with ≥2 participating apps having a disposition recommendation, pick the aggregate disposition (7R + keep-separate), choose a consolidation pattern (strangler-fig / bulk-replace / keep-separate), sequence the work, score risks, and estimate effort.
- **skills:** `[capability-consolidation-advisor]`
- **agent_role:** `Capability Consolidation Advisor`
- **inputs.artifacts:**
  - `rationalization/wave-{wave_id}/integration-graph.json`
  - `rationalization/wave-{wave_id}/{app_id}/disposition-recommendation.json`
  - `rationalization/wave-{wave_id}/{app_id}/disposition-governance.json`
  - `rationalization/wave-{wave_id}/{app_id}/classification.json`
  - `rationalization/wave-{wave_id}/{app_id}/portfolio-score.json`
- **inputs.context:** `[wave_id]`
- **outputs.artifacts:**
  - `rationalization/wave-{wave_id}/capability-consolidation-plan.json`
- **outputs.side_effects:** `[]` (none)
- **agent_contract.mcp_servers:** `[olympus]`
- **agent_contract.repos:** `artifact: rw`, `source: none`, `target: none`
- **parallel_with:** `[]` (empty)
- **gate:** `null`
- **retry_policy.category:** `agent_failure`

⚠️ GOTCHA: Activation precondition lives in prose, not a `condition:` field: "Runs after ≥2 per-app dispositions exist" / "For each capability ... with ≥2 participating apps having a disposition recommendation." The aggregate-disposition vocabulary is "7R + keep-separate" and the consolidation pattern enum is exactly `strangler-fig / bulk-replace / keep-separate`. Output is a wave-scoped (not per-app) `capability-consolidation-plan.json` that the sequencer (Step 15) consumes.

---

### Step 15 — `wave-planning` (rationalization.yaml:589-630)

- **id:** `wave-planning`
- **label:** `Wave Planning`
- **kind:** `agent`
- **scope:** `per-wave`
- **sequence:** `15`
- **progress_pct:** `78`
- **purpose** (folded, lines 595-600):
  > Build the wave plan — critical path, dependency ordering, capacity-loaded schedule, risk-balanced distribution. Extended responsibility: validate the disposition mix is feasible given dependencies and DB clusters, and emit structured infeasibilities as first-class output (absorbs the former ghost `validate-disposition` skill). Blocks G-DA if validation fails.
- **skills:** `[sequencer]`
- **agent_role:** `Sequencing Optimizer`
- **inputs.artifacts:**
  - `rationalization/wave-{wave_id}/{app_id}/disposition-recommendation.json`
  - `rationalization/wave-{wave_id}/{app_id}/classification.json`
  - `rationalization/wave-{wave_id}/{app_id}/complexity-classification.json`
  - `rationalization/wave-{wave_id}/{app_id}/portfolio-score.json`
  - `rationalization/wave-{wave_id}/redundancy-matrix.json`
  - `rationalization/wave-{wave_id}/capability-consolidation-plan.json`
- **inputs.context:**
  - `wave_id`
  - `profile_capacity`
  - `dependency_graph`
  - `shared_db_cluster_map`
- **outputs.artifacts:** (rationalization.yaml:617-619)
  - `rationalization/wave-{wave_id}/wave-plan.json`
  - `rationalization/wave-{wave_id}/wave-plan-validation.json`
- **outputs.side_effects:** `[]` (none)
- **agent_contract.mcp_servers:** `[olympus]`
- **agent_contract.repos:** `artifact: rw`, `source: none`, `target: none`
- **parallel_with:** `[]` (empty)
- **gate:** `null`
- **retry_policy.category:** `agent_failure`

⚠️ GOTCHA — CHANGED AT HEAD (path prefix): This step ABSORBS the former "ghost" `validate-disposition` skill — feasibility validation is now part of `sequencer`. It emits TWO artifacts. **The path prefix is now `rationalization/wave-{wave_id}/`, NOT the old `planning/{wave_id}/`** (rationalization.yaml:618-619). A prior baseline placed `wave-plan.json` / `wave-plan-validation.json` under `planning/{wave_id}/`; at HEAD all three planning artifacts (`wave-plan.json`, `wave-plan-validation.json`, `factory-routing.json`) live under the same `rationalization/wave-{wave_id}/` prefix as every other Rationalization output. "Blocks G-DA if validation fails" — a cross-step control coupling to gate-review-da (Step 19). `inputs.context` is written as a block list (4 entries: wave_id, profile_capacity, dependency_graph, shared_db_cluster_map), not inline-flow style — preserve all four.

---

### Step 16 — `factory-routing` (rationalization.yaml:632-662)

- **id:** `factory-routing`
- **label:** `Factory Routing`
- **kind:** `code`
- **scope:** `per-wave`
- **sequence:** `16`
- **progress_pct:** `82`
- **purpose** (folded, lines 638-642):
  > Bookkeeping — flatten per-app disposition decisions into a single wave-scoped route list that downstream factories (Modernization, Disposition Execution, Retain) consume without re-parsing each per-app disposition recommendation. No agent call; pure workflow code.
- **skills:** `[]` (empty)
- **agent_role:** `null`
- **inputs.artifacts:**
  - `rationalization/wave-{wave_id}/{app_id}/disposition-recommendation.json`
- **inputs.context:** `[wave_id, app_ids]`
- **outputs.artifacts:** (rationalization.yaml:650-651)
  - `rationalization/wave-{wave_id}/factory-routing.json`
- **outputs.side_effects:** `[]` (none)
- **agent_contract.mcp_servers:** `[]` (empty)
- **agent_contract.repos:** `artifact: rw`, `source: none`, `target: none`
- **parallel_with:** `[]` (empty)
- **gate:** `null`
- **retry_policy.category:** `transient`

⚠️ GOTCHA: The ONLY `kind: code` step (distinct from `git`, `agent`, `gate`). "No agent call; pure workflow code." `retry_policy.category: transient`. ⚠️ CHANGED AT HEAD: output `factory-routing.json` now lives under `rationalization/wave-{wave_id}/` (rationalization.yaml:651), not the old `planning/{wave_id}/` prefix. Downstream factory consumers named in purpose: Modernization, Disposition Execution, Retain.

---

### Step 17 — `commit-disposition-artifacts` (rationalization.yaml:664-708)

- **id:** `commit-disposition-artifacts`
- **label:** `Commit Disposition Artifacts`
- **kind:** `git`
- **scope:** `per-wave`
- **sequence:** `17`
- **progress_pct:** `85`
- **purpose** (folded, lines 670-677):
  > Commit all per-app disposition, governance, user-impact, classification, complexity-classification, and portfolio-score artifacts, plus the capability consolidation plan, wave plan, feasibility validation, factory routing, and scoring methodology digest to the wave branch. Stage 6 ATLAS integration (2026-05-06): includes capability-consolidation-plan.json and per-app complexity-classification.json.
- **skills:** `[]` (empty)
- **agent_role:** `null`
- **inputs.artifacts:**
  - `rationalization/wave-{wave_id}/{app_id}/disposition-recommendation.json`
  - `rationalization/wave-{wave_id}/{app_id}/disposition-governance.json`
  - `rationalization/wave-{wave_id}/{app_id}/user-impact-analysis.json`
  - `rationalization/wave-{wave_id}/{app_id}/classification.json`
  - `rationalization/wave-{wave_id}/{app_id}/complexity-classification.json`
  - `rationalization/wave-{wave_id}/{app_id}/portfolio-score.json`
  - `rationalization/wave-{wave_id}/capability-consolidation-plan.json`
  - `rationalization/wave-{wave_id}/wave-plan.json`
  - `rationalization/wave-{wave_id}/wave-plan-validation.json`
  - `rationalization/wave-{wave_id}/factory-routing.json`
  - `rationalization/wave-{wave_id}/scoring-methodology.md`
- **inputs.context:** `[]` (empty)
- **outputs.artifacts:** `[]` (empty)
- **outputs.side_effects:**
  - **target:** `artifact_repo`
    **fields:** `[commit_sha, branch]`
- **agent_contract.mcp_servers:** `[]` (empty)
- **agent_contract.repos:** `artifact: rw`, `source: none`, `target: none`
- **parallel_with:** `[]` (empty)
- **gate:** `null`
- **retry_policy.category:** `transient`

⚠️ GOTCHA — CHANGED AT HEAD: the wave-plan / wave-plan-validation / factory-routing inputs are now under `rationalization/wave-{wave_id}/` (rationalization.yaml:689-691), not the old `planning/{wave_id}/`. Inputs also include `rationalization/wave-{wave_id}/scoring-methodology.md` (rationalization.yaml:692) — a "scoring methodology digest" artifact that is NOT produced by any explicitly-listed step output in this file (no step lists it under `outputs.artifacts`). It is committed here but its producer is implicit (the scoring pipeline/methodology digest). Over-specify: the commit step expects this file to exist at commit time. Side-effect: `artifact_repo` → `commit_sha, branch`.

---

### Step 18 — `create-gda-pr` (rationalization.yaml:710-739)

- **id:** `create-gda-pr`
- **label:** `Create G-DA PR`
- **kind:** `git`
- **scope:** `per-wave`
- **sequence:** `18`
- **progress_pct:** `88`
- **purpose** (folded, lines 716-719):
  > Open the Gate G-DA review PR. Body aggregates per-app dispositions, wave-scoped artifacts, scoring methodology, wave plan, factory routing, and the stakeholder sign-off checklist.
- **skills:** `[]` (empty)
- **agent_role:** `null`
- **inputs.artifacts:** `[]` (empty)
- **inputs.context:** `[wave_id, wave_name, per_app_dispositions]`
- **outputs.artifacts:**
  - `gate-packet`
- **outputs.side_effects:**
  - **target:** `gate_record`
    **fields:** `[evidence_package_url, gate_type, portfolio_id, workflow_id]`
- **agent_contract.mcp_servers:** `[]` (empty)
- **agent_contract.repos:** `artifact: rw`, `source: none`, `target: none`
- **parallel_with:** `[]` (empty)
- **gate:** `null`
- **retry_policy.category:** `transient`

⚠️ GOTCHA: `inputs.context` carries `per_app_dispositions` (line 724) — the aggregated per-app disposition list passed into the PR body. Same `gate_record` side-effect shape as Step 7 (`evidence_package_url, gate_type, portfolio_id, workflow_id`). `gate: null` (the decision is Step 19). Output is the `gate-packet` token.

---

### Step 19 — `gate-review-da` (rationalization.yaml:741-784)

- **id:** `gate-review-da`
- **label:** `Disposition Approval Gate`
- **kind:** `gate`
- **scope:** `per-wave`
- **sequence:** `19`
- **progress_pct:** `92`
- **purpose** (folded, lines 747-753):
  > Dual-signal gate — BOTH a PM gate_approved signal (PR merge) AND a stakeholder StakeholderApprovedSignal with scope="g-da" are required. Rejection loops rework back through the per-app disposition pipeline with feedback context; rework preserves redundancy/intra-app results. Approval triggers DB projection of classification + portfolio-score + disposition side-effects and unlocks wave-outcome-synthesis.
- **skills:** `[]` (empty)
- **agent_role:** `null`
- **inputs.artifacts:** `[gate-packet]`
- **inputs.context:** `[]` (empty)
- **outputs.artifacts:** `[gate-decision]`
- **outputs.side_effects:**
  - **target:** `gate_record`
    **fields:** `[state, decided_at, decided_by, decision_notes]`
  - **target:** `application`
    **fields:**
    - `risk_tier`
    - `risk_tier_source`
    - `portfolio_score`
    - `disposition`
    - `disposition_source`
    - `disposition_rationale_ref`
    **notes** (folded, lines 772-774):
    > Applied via persist_rationalization_side_effects activity after gate approval; exclusive owner of these fields within Rationalization.
- **agent_contract.mcp_servers:** `[]` (empty)
- **agent_contract.repos:** `artifact: rw`, `source: none`, `target: none`
- **parallel_with:** `[]` (empty)
- **gate:** `G-DA`
- **retry_policy.category:** `validation_failure`

⚠️ GOTCHA — DUAL-SIGNAL GATE (the most complex step): Approval requires BOTH (a) a PM `gate_approved` signal (PR merge) AND (b) a stakeholder `StakeholderApprovedSignal` with `scope="g-da"`. Both signals are mandatory; one alone does not approve. This is the ONLY step with TWO side-effect targets: `gate_record` (state/decided_at/decided_by/decision_notes) AND `application` (six fields). The `application` side-effect is applied via the `persist_rationalization_side_effects` activity AFTER gate approval, and Rationalization is the **exclusive owner** of those six application fields. The six application fields, exact order: `risk_tier`, `risk_tier_source`, `portfolio_score`, `disposition`, `disposition_source`, `disposition_rationale_ref`. On rejection: rework loops back through the per-app disposition pipeline (Step 9 onward) with feedback context, but redundancy/intra-app results (Steps 1-5) are PRESERVED (not re-run). `gate: G-DA`. `retry_policy.category: validation_failure`.

---

### Step 20 — `wave-outcome-synthesis` (rationalization.yaml:786-827)

- **id:** `wave-outcome-synthesis`
- **label:** `Wave Outcome Synthesis`
- **kind:** `agent`
- **scope:** `per-wave`
- **sequence:** `20`
- **progress_pct:** `96`
- **summary:** `true`
- **purpose** (folded, lines 793-800):
  > Consolidate the approved wave into an executive-readable target-state readout. Reads every per-app disposition / classification / portfolio- score / user-impact artifact plus the wave plan and redundancy matrix; emits the single wave-outcome-synthesis.json artifact the dashboard's wave page surfaces and the portfolio target-state rollup API aggregates across waves. Schema in schemas/rationalization/. Spec: specifications/phase-5/rationalization-outputs.md.
- **skills:** `[wave-outcome-synthesizer]`
- **agent_role:** `Rationalization Analyst`
- **inputs.artifacts:**
  - `rationalization/wave-{wave_id}/{app_id}/disposition-recommendation.json`
  - `rationalization/wave-{wave_id}/{app_id}/disposition-governance.json`
  - `rationalization/wave-{wave_id}/{app_id}/classification.json`
  - `rationalization/wave-{wave_id}/{app_id}/portfolio-score.json`
  - `rationalization/wave-{wave_id}/{app_id}/user-impact-analysis.json`
  - `rationalization/wave-{wave_id}/redundancy-matrix.json`
  - `rationalization/wave-{wave_id}/wave-plan.json`  ⚠️ CHANGED AT HEAD: was `planning/{wave_id}/wave-plan.json` (now rationalization.yaml:811)
- **inputs.context:** `[wave_id, wave_name, portfolio_id]`
- **outputs.artifacts:**
  - `rationalization/wave-{wave_id}/wave-outcome-synthesis.json`
- **outputs.side_effects:** `[]` (none)
- **outputs.consumers:** `[Architecture, Data, Modernization, Disposition-Execution, Governance, Dashboards]`
- **agent_contract.mcp_servers:** `[olympus]`
- **agent_contract.repos:** `artifact: rw`, `source: none`, `target: none`
- **parallel_with:** `[]` (empty)
- **gate:** `null`
- **retry_policy.category:** `agent_failure`

⚠️ GOTCHA — `summary: true` flag: This is the ONLY step carrying `summary: true` (line 792). It marks the line's summary/synthesis step. It runs only AFTER G-DA approval (Step 19 unlocks it). The widest consumer fan-out in the line: `[Architecture, Data, Modernization, Disposition-Execution, Governance, Dashboards]` (6 consumers — note `Disposition-Execution` is hyphenated). Schema location is `schemas/rationalization/`, spec at `specifications/phase-5/rationalization-outputs.md`. Reads per-app `user-impact-analysis.json` which may be absent for non-Retire/Replace apps (Step 11 condition) — synthesizer must tolerate missing per-app user-impact files.

---

### Step 21 — `portfolio-manifest-generation` (rationalization.yaml:829-874)

In-file comment block (lines 830-835, preserve as provenance):
> Stage 6 ATLAS integration (2026-05-06): terminal portfolio-scope closeout pass. Runs only on the final wave of the portfolio; earlier waves skip this step. Emits the sponsor-facing portfolio-manifest packet that rolls up every wave-outcome-synthesis into a single inventory + disposition summary + wave sequencing + exception register. Distinct from per-wave wave-outcome-synthesizer.

- **id:** `portfolio-manifest-generation`
- **label:** `Portfolio Manifest Generation`
- **kind:** `agent`
- **scope:** `per-wave`
- **sequence:** `21`
- **progress_pct:** `99`
- **condition:** `is_final_wave == true`
- **purpose** (folded, lines 842-849):
  > Produce the portfolio-level manifest after the last wave of Rationalization finishes. Packages the full inventory (app_id, risk_tier, disposition, wave), HCD summary, Section 508 overview, wave sequencing, and exception register into a single reviewable packet. Emits both portfolio-manifest.json (schema- validated) and portfolio-manifest.md (sponsor-facing). Failsclosed if any wave in the portfolio lacks a wave-outcome-synthesis.json.
- **skills:** `[portfolio-manifest-generator]`
- **agent_role:** `Portfolio Close-out Analyst`
- **inputs.artifacts:**
  - `rationalization/wave-{wave_id}/wave-outcome-synthesis.json`
  - `rationalization/wave-{wave_id}/{app_id}/disposition-recommendation.json`
  - `discovery/{app_id}/catalog-application.json`
  - `rationalization/wave-{wave_id}/ux-overlap-matrix.json`
- **inputs.context:** `[portfolio_id, wave_ids]`
- **outputs.artifacts:**
  - `rationalization/portfolio/{portfolio_id}/portfolio-manifest.json`
  - `rationalization/portfolio/{portfolio_id}/portfolio-manifest.md`
- **outputs.side_effects:** `[]` (none)
- **outputs.consumers:** `[Architecture, Modernization, Disposition-Execution, Governance]`
- **agent_contract.mcp_servers:** `[olympus]`
- **agent_contract.repos:** `artifact: rw`, `source: none`, `target: none`
- **parallel_with:** `[]` (empty)
- **gate:** `null`
- **retry_policy.category:** `agent_failure`

⚠️ GOTCHA — TERMINAL CONDITIONAL STEP: `condition: is_final_wave == true` (line 841). This step runs ONLY on the final wave of the portfolio; all earlier waves skip it entirely. It is the only step that writes to the **portfolio-scoped** path prefix `rationalization/portfolio/{portfolio_id}/` (NOT `rationalization/wave-{wave_id}/`). It emits TWO outputs: `portfolio-manifest.json` (schema-validated) AND `portfolio-manifest.md` (sponsor-facing). "Fails closed if any wave in the portfolio lacks a wave-outcome-synthesis.json" — a hard precondition: every prior wave must have completed Step 20. ⚠️ Note the source text typos `Failsclosed` (line 848-849, "Fails\nclosed" folded to "Failsclosed") and `portfolio-manifest.md (sponsor-facing)` — reproduce the folded-scalar wording as-is for parity. The inventory tuple is exactly `(app_id, risk_tier, disposition, wave)`. Consumers (4): `Architecture, Modernization, Disposition-Execution, Governance` (no `Data`/`Dashboards`, unlike Step 20).

⚠️ NOTE on step count: `sequence` numbers run 1–21, but there are EXACTLY 23 step list-items in the `steps:` block? — NO. Re-verify: the `steps:` list contains 21 `- id:` entries (sequences 1 through 21). The task brief stated "EXACTLY 23 steps." Empirical count of `- id:` entries under `steps:` (lines 59–829) = 21. The two additional `- id:` lines in the file (lines 25, 27) are `G-RR` and `G-DA` under the top-level `gates:` key, which are gate DEFINITIONS, not steps. See the verification section below.

---

## 3. Step-count verification (authoritative)

Command run against the source file:
```
grep -n "^  - id:" rationalization.yaml
```
Returned 25 matches at lines: 25, 27, 59, 94, 130, 164, 206, 248, 290, 322, 354, 399, 432, 466, 508, 545, 589, 632, 664, 710, 741, 786, 829.

- Lines **25, 27** are under top-level `gates:` (`G-RR`, `G-DA`) — gate definitions, NOT steps.
- Lines **59 → 829** (21 entries) are under `steps:` — these are the actual steps, `sequence: 1` … `sequence: 21`.

⚠️ DISCREPANCY WITH TASK BRIEF: The task brief asserts the line has "EXACTLY 23 steps." The current source file (`olympus-contracts/olympus_contracts/data/assembly-lines/rationalization.yaml`, 874 lines, read end-to-end) contains **21 steps** under `steps:` plus **2 gate definitions** under `gates:`. The total of `- id:` tokens at the 2-space indent is 23 (21 steps + 2 gates), which is most likely the origin of the "23" figure in the brief — it counted all `- id:` lines including the two gate-definition ids. There is no step with `sequence` 22 or 23, and the file's final step is `portfolio-manifest-generation` at `sequence: 21` ending at line 874 (the last byte of the file). Every step present in the file has been reproduced in full above. No steps were dropped, collapsed, or summarized.

For completeness and to satisfy the brief's "23 `- id:` entries" framing, the two gate-definition `- id:` entries are reproduced here as well (they live under `gates:`, lines 24-28, already covered in §1):

- **gates[0]:** `id: G-RR`, `label: Redundancy Review` (rationalization.yaml:25-26)
- **gates[1]:** `id: G-DA`, `label: Disposition Approval` (rationalization.yaml:27-28)

---

## 4. Cross-step ordering & dependency summary (for rebuild fidelity)

Sequence order (1→21) with kind and parallel groups:

1. `cross-app-redundancy` (agent) — parallel group A: {cross-app-redundancy, intra-app-redundancy, compare-ux-overlap}
2. `intra-app-redundancy` (agent, fanout per-app) — parallel group A
3. `compare-ux-overlap` (agent) — parallel group A
4. `portfolio-integration-mapping` (agent) — parallel group B: {portfolio-integration-mapping, analyze-portfolio-redundancy}
5. `analyze-portfolio-redundancy` (agent) — parallel group B (data-depends on Step 4's integration-graph.json)
6. `commit-redundancy-artifacts` (git) — side-effect artifact_repo
7. `create-grr-pr` (git) — side-effect gate_record, emits gate-packet
8. `gate-review-rr` (gate G-RR) — rejection loops to Step 1
9. `disposition-recommendation` (agent, fanout per-app)
10. `disposition-governance` (agent, fanout per-app)
11. `user-impact-analysis` (agent, fanout per-app, CONDITION: disposition in [Retire, Replace])
12. `classification` (agent, fanout per-app, TWO skills, TWO outputs; Tier 1 pauses workflow)
13. `portfolio-scoring` (agent, fanout per-app; runs after classification)
14. `capability-consolidation-advisory` (agent; activation: ≥2 per-app dispositions)
15. `wave-planning` (agent; absorbs validate-disposition; blocks G-DA on validation failure)
16. `factory-routing` (code — only code-kind step)
17. `commit-disposition-artifacts` (git) — side-effect artifact_repo
18. `create-gda-pr` (git) — side-effect gate_record, emits gate-packet
19. `gate-review-da` (gate G-DA) — DUAL-SIGNAL (gate_approved + StakeholderApprovedSignal scope="g-da"); two side-effect targets (gate_record + application 6 fields via persist_rationalization_side_effects); rejection loops to per-app disposition pipeline preserving redundancy/intra-app
20. `wave-outcome-synthesis` (agent, summary:true) — unlocked by G-DA approval
21. `portfolio-manifest-generation` (agent; CONDITION: is_final_wave == true; portfolio-scoped outputs; fails closed if any wave lacks wave-outcome-synthesis.json)

Side-effect targets across the line (3 distinct tables):
- `artifact_repo` — fields `[commit_sha, branch]` — Steps 6, 17.
- `gate_record` — Steps 7, 18 write `[evidence_package_url, gate_type, portfolio_id, workflow_id]`; Steps 8, 19 write `[state, decided_at, decided_by, decision_notes]`.
- `application` — Step 19 only — fields `[risk_tier, risk_tier_source, portfolio_score, disposition, disposition_source, disposition_rationale_ref]` (exclusive owner; applied via `persist_rationalization_side_effects`).

retry_policy.category by kind:
- `agent` steps → `agent_failure` (Steps 1,2,3,4,5,9,10,11,12,13,14,15,20,21).
- `git` and `code` steps → `transient` (Steps 6,7,16,17,18).
- `gate` steps → `validation_failure` (Steps 8,19).

---

STEP INVENTORY: cross-app-redundancy, intra-app-redundancy, compare-ux-overlap, portfolio-integration-mapping, analyze-portfolio-redundancy, commit-redundancy-artifacts, create-grr-pr, gate-review-rr, disposition-recommendation, disposition-governance, user-impact-analysis, classification, portfolio-scoring, capability-consolidation-advisory, wave-planning, factory-routing, commit-disposition-artifacts, create-gda-pr, gate-review-da, wave-outcome-synthesis, portfolio-manifest-generation

STEPS REPRODUCED: 21 steps under `steps:` (sequences 1–21) + 2 gate definitions under `gates:` (G-RR, G-DA) = 23 total `- id:` entries reproduced.
