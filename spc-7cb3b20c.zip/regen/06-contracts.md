# 06 — Contracts Layer (`olympus-contracts`)

> **ATOMIC REGENERATION SPEC.** This document plus the per-line step files under
> `regen/06-contracts/` are the *only* surviving description of the
> `olympus-contracts` package. An engineer must be able to rebuild the package
> so it behaves **byte-for-byte identically** at the API/serialization boundary.
> Reproduce HOW, not WHAT. When in doubt, the source citations (`path:line`) win.

> **REFRESHED to HEAD 7cb3b20c (2026-06-15).** Reconciled against the live tree. Material changes captured: (a) `Disposition` gained an 8th value `BUILD` (§1.1); (b) a NEW pure-stdlib module `net.py` providing TCP-keepalive socket options for long-lived agent dispatch (§4a); (c) a BRAND-NEW `Build` assembly line (`build.yaml`, 15 steps) — the loader now returns **11** lines, reproduced in `regen/06-contracts/build-steps.md`; (d) Rationalization's wave-planning artifacts moved to the `rationalization/wave-{wave_id}/` prefix (see `regen/06-contracts/rationalization-steps.md`). All enum `path:line` citations were re-synced to current lines (the Disposition class growing shifted every member/table below it). The loader (`assembly_lines.py`), `signals.py`, `git_types.py`, and `errors.py` are byte-unchanged from the prior baseline — their citations remain valid.

This is the **entry document** for the contracts layer. It fully reproduces, at
field level:

1. `olympus_contracts/enums.py` — 8 enum classes + 2 lookup tables + 2 resolver functions.
2. `olympus_contracts/signals.py` — 3 cross-service Temporal signal payloads.
3. `olympus_contracts/git_types.py` — branch regex + 4 dataclasses + 1 base exception.
4. `olympus_contracts/errors.py` — 3 merge-error subclasses + retryable semantics.
4a. `olympus_contracts/net.py` — **NEW** — TCP-keepalive socket-option builder for byte-silent agent dispatch (pure `os`+`socket`).
5. `olympus_contracts/assembly_lines.py` — THE LOADER: 9 frozen dataclasses, YAML→dataclass parse pipeline, query API, load-time invariants.
6. Anti-drift guard tests.
7. Index to the **11** per-line step files (each line's YAML reproduced field-by-field there).

**Per-line step contracts** (the actual content of each `data/assembly-lines/*.yaml`) live in:
`regen/06-contracts/discovery.md`, `rationalization-steps.md`, `architecture.md`, `data.md`, `modernization.md`, `disposition-execution.md`, `validation.md`, `deployment.md`, `sustainment.md`, `governance.md`, and the NEW `build-steps.md`. See the index table at the end.

---

## 0. Package layout, packaging, and Python-version constraints

```
olympus-contracts/
├── pyproject.toml
├── olympus_contracts/
│   ├── __init__.py            # re-export surface + __version__ (does NOT re-export net.py)
│   ├── enums.py               # 8 enums + tables + resolvers (251 lines at HEAD)
│   ├── signals.py             # 3 Temporal signal dataclasses
│   ├── git_types.py           # branch regex + result dataclasses + GitServiceError
│   ├── errors.py              # 3 merge-error subclasses
│   ├── net.py                 # NEW — keepalive_socket_options() (pure os+socket, 99 lines)
│   ├── assembly_lines.py      # THE LOADER (403 lines)
│   └── data/
│       └── assembly-lines/    # 11 authoritative YAML contracts (one per line) — Build is NEW
│           ├── architecture.yaml
│           ├── build.yaml          # NEW (651 lines, 15 steps)
│           ├── data.yaml
│           ├── deployment.yaml
│           ├── discovery.yaml
│           ├── disposition-execution.yaml
│           ├── governance.yaml
│           ├── modernization.yaml
│           ├── rationalization.yaml
│           ├── sustainment.yaml
│           └── validation.yaml
└── tests/
    ├── test_assembly_lines.py
    ├── test_no_hardcoded_step_lists.py
    └── test_skill_manifest.py
```

⚠️ **GOTCHA — `net.py` is NOT re-exported by `__init__.py`.** Unlike enums/signals/errors/git_types/assembly_lines, `net.py` is imported directly by its consumers (`from olympus_contracts.net import keepalive_socket_options`), not via the package root. `keepalive_socket_options` is absent from `__init__.__all__` (§0 re-export surface). The `package-data` stanza still only ships `data/assembly-lines/*.yaml`; `net.py` is normal package source.

### `pyproject.toml` (`olympus-contracts/pyproject.toml:1`)

```toml
[build-system]
requires = ["setuptools>=68.0", "wheel"]
build-backend = "setuptools.build_meta"

[project]
name = "olympus-contracts"
version = "0.4.0"
description = "Shared domain types and authoritative assembly-line contracts for the Olympus platform"
requires-python = ">=3.11"
dependencies = ["pyyaml>=6.0"]

[tool.ruff]
target-version = "py311"
line-length = 100

[tool.ruff.lint]
select = ["E", "F", "I", "W"]

[tool.setuptools.packages.find]
include = ["olympus_contracts*"]

[tool.setuptools.package-data]
olympus_contracts = ["data/assembly-lines/*.yaml"]
```

- ⚠️ **CHANGED AT HEAD — `version = "0.4.0"`** (`pyproject.toml:7`; was `0.3.0` in the prior baseline). The packaging version bumped (Build line + net.py + Disposition.BUILD additions). See the version-drift gotcha after `__init__.py` below.
- **The only runtime dependency is `pyyaml>=6.0`** (`pyproject.toml:10`). No pydantic, no Temporal SDK — everything here is pure stdlib + YAML so it imports inside the worker, the API, the MCP server, and codegen alike. `net.py` (§4a) is also pure-stdlib (`os`+`socket`) and adds no dependency.
- ⚠️ **GOTCHA — Python 3.11+ is HARD-REQUIRED** (`requires-python = ">=3.11"`, `pyproject.toml:9`). Two language features make 3.11 the floor and break on 3.10/3.9:
  - `enum.StrEnum` (PEP 663 / 3.11) is used in `enums.py:15` etc. — does not exist before 3.11.
  - `@dataclass(frozen=True, slots=True)` (`assembly_lines.py:62`) — the `slots=` kwarg was added in 3.10. On 3.9 it raises `TypeError: dataclass() got an unexpected keyword argument 'slots'` at *import* time. (Confirmed empirically: the repo's system `python3` is 3.9.6 and import fails on this exact line.)
- ⚠️ **GOTCHA — package_data ships the YAML** (`pyproject.toml:22-23`). `olympus_contracts = ["data/assembly-lines/*.yaml"]` is what makes `importlib.resources.files("olympus_contracts").joinpath("data/assembly-lines")` resolve at runtime inside an installed wheel / Docker layer. The glob now matches **11** YAML files (Build added). If you regenerate `pyproject.toml` and omit this stanza, `_load_all()` raises `RuntimeError("no assembly-line contracts found …")` (`assembly_lines.py:322-326`) in any environment where the source tree isn't present (e.g. the worker container). The loader's own error message names this stanza.

### `__init__.py` re-export surface (`olympus_contracts/__init__.py:1`)

The package root re-exports a curated, alphabetically-sorted `__all__`. Reproduce it exactly — downstream packages import from `olympus_contracts` directly (e.g. `from olympus_contracts import list_lines` in the drift guard at `tests/test_no_hardcoded_step_lists.py:32`).

- Imports from `assembly_lines` (`__init__.py:9-27`): `AgentContract, GateRef, LineContract, RepoAccess, RetryPolicy, SideEffect, StepContract, StepIO, discovery_passes, get_line, get_step, line_names, list_lines, pass_order, skill_for_step, step_progress, step_weights`.
- Imports from `enums` (`__init__.py:28-42`): `GATE_ASSEMBLY_LINES, GATE_FRIENDLY_NAMES, Archetype, AssemblyLine, AssemblyLineName, ComplexityTier, Disposition, GateStatus, GateType, RiskTier, TierSource, gate_assembly_line, gate_friendly_name`.
- Imports from `errors` (`__init__.py:43-47`): `MergeBranchProtectionRejected, MergeConflict, MergeDivergenceUnresolved`.
- Imports from `git_types` (`__init__.py:48-55`): `BRANCH_PATTERN, CommitResult, FileReadResult, GitServiceConfig, GitServiceError, PRResult`.
- Imports from `signals` (`__init__.py:56-60`): `GateApprovedSignal, GateMergeRetrySignal, GateRejectedSignal`.
- `__version__ = "0.2.0"` (`__init__.py:62`).
- `__all__` lists all of the above (`__init__.py:64-107`) — alphabetically sorted, 44 names. Note `step_weights` is exported here even though it is *not* in `assembly_lines.__all__` (see §5.3).

⚠️ **GOTCHA — version string drift (WIDENED AT HEAD).** `__init__.py:62` still hardcodes `__version__ = "0.2.0"` while `pyproject.toml:7` now declares `version = "0.4.0"` (was `0.3.0`). The two disagree more than before in the live tree. Reproduce both values as-is (do not "fix" the drift — behavioral parity means preserving it); a regenerator that unifies them changes observable `olympus_contracts.__version__` (which is `"0.2.0"`, NOT the packaging `"0.4.0"`).

---

## 1. `enums.py` — 8 enum classes

File header (`enums.py:1-13`): module docstring states these are the canonical definitions consumed by `olympus-api`, `olympus-workflows`, `olympus-worker`, and the MCP server, that consuming packages re-export them, and that they are aligned with `specifications/api/components/schemas.yaml`. `from __future__ import annotations` (line 10) and `import enum` (line 12) are the only imports.

### 1.1 `Disposition` — `enum.StrEnum` (`enums.py:15`)

⚠️ **CHANGED AT HEAD — now 8 dispositions (was 7).** `BUILD = "Build"` (`enums.py:41`) was added for the new net-new construction line (Phase 6 W5, P6-S5.2).

| Member | Value |
|---|---|
| `RETIRE` | `"Retire"` |
| `RETAIN` | `"Retain"` |
| `REFACTOR` | `"Refactor"` |
| `REARCHITECT` | `"Rearchitect"` |
| `REPLACE` | `"Replace"` |
| `REPLATFORM` | `"Replatform"` |
| `CONSOLIDATE` | `"Consolidate"` |
| `BUILD` | `"Build"` |

(`enums.py:34-41`)

⚠️ **GOTCHA — `BUILD` is the disposition that SELECTS the downstream execution line.** The rewritten docstring (`enums.py:16-32`) is explicit and load-bearing: "A disposition is precisely the value that selects the downstream execution line: `Refactor`/`Rearchitect` → Modernization, `Retire`/`Retain`/`Replace`/`Replatform` → Disposition Execution, `Consolidate` → a hybrid of both, and `Build` → the new Build line." The first seven derive from analyzing an *existing* application; `BUILD` is the net-new construction disposition — declared at intake for a greenfield application that has no legacy source, and confirmed (or pivoted) by Rationalization's redundancy engine. ⚠️ Adding `BUILD` is **backward-compatible for in-flight workflows that never encounter it** (per docstring `enums.py:30-31`) — a `StrEnum` member addition does not break round-trip of pre-existing values.

⚠️ **GOTCHA — `Disposition.BUILD` exists but there is NO `AssemblyLine.BUILD`.** The Build *line* is loaded from `build.yaml` (the loader returns 11 lines, §5.8) and matched by the plain string `"Build"`, but the `AssemblyLine` StrEnum (§1.8) still has only 10 members and does NOT include `Build`. So `Disposition("Build")` succeeds and `get_line("Build")` succeeds, but `AssemblyLine("Build")` raises `ValueError`. Do not add a `BUILD` member to `AssemblyLine` to "fix" this — the 10-member enum is pinned by §1.8 and downstream tests.

⚠️ **GOTCHA — base type is `StrEnum`, NOT `(str, Enum)`** (`enums.py:15`, docstring lines 16-32). The docstring states: "Uses StrEnum (not `str, Enum`) so Temporal's default payload converter can round-trip values through workflow input boundaries — the converter explicitly special-cases StrEnum subclasses (same rationale as `RiskTier` being IntEnum)." A `StrEnum` JSON-serializes as its **string value** ("Retire"), and Temporal's `DefaultPayloadConverter` has explicit handling for `StrEnum`/`IntEnum` subclasses; a plain `(str, Enum)` does not round-trip cleanly through the converter. If you regenerate this as `class Disposition(str, enum.Enum)` you will reintroduce the bug this class was migrated to fix.

### 1.2 `RiskTier` — `enum.IntEnum` (`enums.py:44`)

Risk classification tiers. Docstring: "1 = Critical, 2 = Standard, 3 = Low-Risk."

| Member | Value |
|---|---|
| `TIER_1` | `1` |
| `TIER_2` | `2` |
| `TIER_3` | `3` |

(`enums.py:52-54`)

⚠️ **GOTCHA — `IntEnum`, NOT `(int, Enum)`** (`enums.py:44`, docstring lines 45-50). Same Temporal-converter rationale: the default payload converter special-cases `IntEnum` subclasses so the value round-trips as the integer `1`/`2`/`3` through workflow input boundaries. `TIER_1` is the **highest** criticality (Tier 1), per the framework's "Tier 1 highest" convention — the integer ordering is intentionally inverse to severity.

### 1.3 `ComplexityTier` — `enum.StrEnum` (`enums.py:57`)

Application complexity tiers.

| Member | Value |
|---|---|
| `SIMPLE` | `"simple"` |
| `MODERATE` | `"moderate"` |
| `COMPLEX` | `"complex"` |

(`enums.py:64-66`)

⚠️ **GOTCHA — lowercase values.** Unlike `Disposition` (Title-Case), the values here are lowercase. `StrEnum` chosen "for consistent Temporal payload round-trip — see the Disposition / RiskTier migration rationale" (`enums.py:58-62`).

### 1.4 `Archetype` — `enum.StrEnum` (`enums.py:69`)

Application archetype — "determines which agent team composition and modernization strategy the Modernization line applies. Set by Rationalization Step 5 (Classification & Risk Tiering)" (`enums.py:70-74`).

| Member | Value |
|---|---|
| `WEB_APP` | `"web-app"` |
| `BATCH_ETL` | `"batch-etl"` |
| `API_SERVICE` | `"api-service"` |
| `SCHEDULED_JOB` | `"scheduled-job"` |
| `HYBRID` | `"hybrid"` |

(`enums.py:76-80`)

⚠️ **GOTCHA — hyphenated kebab-case values** (`"web-app"`, `"batch-etl"`, `"api-service"`, `"scheduled-job"`). The Python member names use underscores; the wire values use hyphens. Do not collapse.

### 1.5 `TierSource` — `enum.StrEnum` (`enums.py:83`)

How a tier classification was determined.

| Member | Value |
|---|---|
| `AUTO` | `"auto"` |
| `CONFIRMED` | `"confirmed"` |
| `OVERRIDDEN` | `"overridden"` |

(`enums.py:86-88`)

### 1.6 `GateType` — `enum.StrEnum` (`enums.py:91`)

The 15 standard gate identifiers. Docstring (`enums.py:92-101`): the enum **value is the stable code** (e.g. `"G-DC"`) used in URLs, Git commits, contract schemas, registry IDs, and DB columns — **"It MUST NOT be renamed without a migration."**

⚠️ **GOTCHA — still exactly 15 gates; the new Build line's gates `G-NEW-1/2/3` are NOT here.** The Build assembly line (`build.yaml`, regen/06-contracts/build-steps.md) declares three gates `G-NEW-1/2/3`, but they live ONLY in that YAML's `gates:` list — `GateType` is unchanged at 15 members, and neither `GATE_FRIENDLY_NAMES` nor `GATE_ASSEMBLY_LINES` (§1.6.1/§1.6.3, 15 entries each) gained `G-NEW-*` rows. `gate_friendly_name("G-NEW-1")` therefore echoes `"G-NEW-1"` (ValueError fallback) and `gate_assembly_line("G-NEW-1")` returns `"Discovery"` (the legacy-row default). Do NOT add `G-NEW-*` to `GateType` — that is a breaking 15→18 enum migration.

| Member | Value |
|---|---|
| `G_DC` | `"G-DC"` |
| `G_RR` | `"G-RR"` |
| `G_DA` | `"G-DA"` |
| `G_02` | `"G-02"` |
| `G_DT` | `"G-DT"` |
| `G_04A` | `"G-04a"` |
| `G_04B` | `"G-04b"` |
| `G_04C` | `"G-04c"` |
| `G_DE_1` | `"G-DE-1"` |
| `G_DE_2` | `"G-DE-2"` |
| `G_V1` | `"G-V1"` |
| `G_V2` | `"G-V2"` |
| `G_V3` | `"G-V3"` |
| `G_DP_1` | `"G-DP-1"` |
| `G_DP_2` | `"G-DP-2"` |

(`enums.py:103-117`)

⚠️ **GOTCHA — value-case is irregular and load-bearing.** `G_04A/B/C` map to **lowercase-suffixed** `"G-04a"/"G-04b"/"G-04c"`, but `G_DC`, `G_RR`, etc. are all-uppercase. The member names normalize the case (`G_04A`) but the **values do not** (`G-04a`). Because these strings are DB-column / URL / Git-commit identifiers, a single character-case change is a breaking migration. Reproduce verbatim.

#### 1.6.1 `GATE_FRIENDLY_NAMES: dict[GateType, str]` (`enums.py:133`)

Authoritative plain-English label table. Docstring (`enums.py:120-131`) requires it be kept in sync with `dashboard/src/data/gateMetadata.ts` (`GATE_METADATA`), `dashboard/src/config/glossary.ts` (`GLOSSARY`), and `cross-cutting/gates/README.md` (Unified Gate Registry table). Strictly additive — codes remain the stable identifiers.

| Key | Friendly name |
|---|---|
| `GateType.G_DC` | `"Discovery Complete"` |
| `GateType.G_RR` | `"Portfolio Rationalization Approval"` |
| `GateType.G_DA` | `"Disposition Plan Approval"` |
| `GateType.G_02` | `"Architecture Alignment Review"` |
| `GateType.G_DT` | `"Data Architecture Review"` |
| `GateType.G_04A` | `"Extracted Specifications Review"` |
| `GateType.G_04B` | `"Modernization Design Review"` |
| `GateType.G_04C` | `"Generated Code Review"` |
| `GateType.G_DE_1` | `"Disposition Execution Plan Approval"` |
| `GateType.G_DE_2` | `"Decommission Readiness Sign-off"` |
| `GateType.G_V1` | `"Functional Parity Confirmation"` |
| `GateType.G_V2` | `"Compliance & Security Certification"` |
| `GateType.G_V3` | `"Safety Assurance Sign-off"` |
| `GateType.G_DP_1` | `"Production Deployment Approval"` |
| `GateType.G_DP_2` | `"Legacy Decommission Authorization"` |

(`enums.py:133-149`)

#### 1.6.2 `gate_friendly_name(gate_type: GateType | str) -> str` (`enums.py:152`)

Resolver. Logic, reproduce exactly (`enums.py:161-165`):

```python
try:
    key = GateType(gate_type)         # accepts enum instance OR raw string code
except ValueError:
    return str(gate_type)             # unknown gate → echo raw code (defensive)
return GATE_FRIENDLY_NAMES.get(key, str(gate_type))
```

⚠️ **GOTCHA — double fallback.** Two distinct fallbacks return `str(gate_type)`: (a) the `except ValueError` when the input is not a valid `GateType`, and (b) the `.get(key, str(gate_type))` default when the key is a valid `GateType` *missing from the dict* (can happen if an extension registry introduces a gate the core enum knows but the table doesn't). Both keep audit-trail/log output readable. Calling `GateType(x)` where `x` is already a `GateType` instance is the idempotent identity path.

#### 1.6.3 `GATE_ASSEMBLY_LINES: dict[GateType, str]` (`enums.py:178`)

Gate → owning assembly-line mapping. Docstring (`enums.py:168-176`): single source of truth consumed by both the API gate service and the scoring analytics engine; introduced because services previously hardcoded `"Discovery"` as the default owner, which is wrong for 10 of the 15 gates (P5-AUDIT-014, Cluster D).

| Key | Owning line |
|---|---|
| `GateType.G_DC` | `"Discovery"` |
| `GateType.G_RR` | `"Rationalization"` |
| `GateType.G_DA` | `"Rationalization"` |
| `GateType.G_02` | `"Architecture"` |
| `GateType.G_DT` | `"Data"` |
| `GateType.G_04A` | `"Modernization"` |
| `GateType.G_04B` | `"Modernization"` |
| `GateType.G_04C` | `"Modernization"` |
| `GateType.G_DE_1` | `"Disposition Execution"` |
| `GateType.G_DE_2` | `"Disposition Execution"` |
| `GateType.G_V1` | `"Validation"` |
| `GateType.G_V2` | `"Validation"` |
| `GateType.G_V3` | `"Validation"` |
| `GateType.G_DP_1` | `"Deployment"` |
| `GateType.G_DP_2` | `"Deployment"` |

(`enums.py:178-194`) — the line-name strings here **must equal** the `AssemblyLine` enum values (§1.8) and the YAML `gates[].id` references (verified by load-time invariants; see §5.6 / per-line files).

#### 1.6.4 `gate_assembly_line(gate_type: GateType | str) -> str` (`enums.py:197`)

Resolver, mirrors `gate_friendly_name` but the fallback is `"Discovery"`, not the raw code (`enums.py:204-208`):

```python
try:
    key = GateType(gate_type)
except ValueError:
    return "Discovery"
return GATE_ASSEMBLY_LINES.get(key, "Discovery")
```

⚠️ **GOTCHA — fallback is `"Discovery"` (legacy-row safety), not the raw input.** This deliberately differs from `gate_friendly_name`'s echo-the-code fallback. Docstring: "falls back to `"Discovery"` for unknown gates so legacy rows don't break the rendering path."

### 1.7 `GateStatus` — `enum.StrEnum` (`enums.py:211`)

Gate decision status.

| Member | Value |
|---|---|
| `PREPARING` | `"preparing"` |
| `PENDING` | `"pending"` |
| `APPROVED` | `"approved"` |
| `REJECTED` | `"rejected"` |
| `OVERRIDDEN` | `"overridden"` |
| `ESCALATED` | `"escalated"` |
| `MERGE_BLOCKED` | `"merge_blocked"` |

(`enums.py:224-230`)

⚠️ **GOTCHA — `MERGE_BLOCKED` is a post-decision state, with a specific recovery handshake** (W17 / P5-S17.4, docstring `enums.py:212-222`). It means: the reviewer **already approved** the gate, but the downstream artifact-repo merge hit a non-retryable condition (`MergeConflict` / `MergeBranchProtectionRejected` / `MergeDivergenceUnresolved` after retries exhausted — see §4). The gate waits in `merge_blocked` until a reviewer clicks "Resolve & Retry Merge" in the UI (or the API's `POST /gates/{id}/retry-merge` fires a `merge_retry` signal → `GateMergeRetrySignal`, §2.3), at which point the workflow retries the merge. Value uses an underscore (`"merge_blocked"`), unlike the other lowercase single-word values.

### 1.8 `AssemblyLine` — `enum.StrEnum` (`enums.py:233`)

The 10 assembly-line names. ⚠️ **GOTCHA — still 10 members at HEAD, even though the loader now returns 11 lines.** The new Build line (`build.yaml`) is loaded as a `LineContract` (so `list_lines()`/`line_names()` return 11 — §5.8) and is selected by `Disposition.BUILD` (§1.1), but `AssemblyLine` was deliberately NOT extended — there is no `BUILD` member. `AssemblyLine("Build")` raises `ValueError`. Reproduce exactly 10 members; do not add `Build`.

| Member | Value |
|---|---|
| `DISCOVERY` | `"Discovery"` |
| `RATIONALIZATION` | `"Rationalization"` |
| `ARCHITECTURE` | `"Architecture"` |
| `DATA` | `"Data"` |
| `MODERNIZATION` | `"Modernization"` |
| `DISPOSITION_EXECUTION` | `"Disposition Execution"` |
| `VALIDATION` | `"Validation"` |
| `DEPLOYMENT` | `"Deployment"` |
| `SUSTAINMENT` | `"Sustainment"` |
| `GOVERNANCE` | `"Governance"` |

(`enums.py:236-245`)

⚠️ **GOTCHA — `"Disposition Execution"` contains a space.** It is a single enum value with an embedded space, and it must match the YAML `name:` field of `disposition-execution.yaml` and the `LineContract.name` key used by `get_line(...)`. The file name is hyphenated (`disposition-execution.yaml`) but the **canonical name is the spaced string**.

#### 1.8.1 Backward-compatible alias

```python
AssemblyLineName = AssemblyLine   # enums.py:250
```

Comment (`enums.py:248-249`): the API and MCP server historically used `AssemblyLineName` while Temporal workflows used `AssemblyLine`. Both names point at the **same enum object** — `AssemblyLineName is AssemblyLine` is `True`. Re-exported from `__init__` (`__init__.py:33`).

---

## 2. `signals.py` — 3 cross-service Temporal signal payloads

Module docstring (`signals.py:1-10`): these dataclasses are used by Temporal workflows (receive signals) and the olympus-api gate service (send signals). **Only signal types that cross service boundaries live here.** Workflow-internal signals (`OverrideApprovedSignal`, `EscalationResolvedSignal`, etc.) remain in `temporal/olympus_workflows/types.py`.

⚠️ **GOTCHA — DELIBERATELY NO `from __future__ import annotations`** (explicit comment block `signals.py:12-18`). Reproduce this *absence* exactly. Reason verbatim: "Temporal's payload converter resolves field types via `typing.get_type_hints` against the module globals. Deferred string annotations force `Any` lookups that fail at runtime with `NameError` in the worker process (W8 regression seen on `card_decisions: list[dict[str, Any]]`). Keeping the eager form is the simplest fix and matches how the rest of `olympus_contracts` expects signals to be introspected." If a regenerator adds the `__future__` import "for consistency," the worker breaks at signal deserialization with `NameError`.

Imports (`signals.py:20-21`):
```python
from dataclasses import dataclass, field
from typing import Any, List, Optional
```
⚠️ Uses the **legacy capitalized typing generics** (`List`, `Optional`) rather than PEP 585 builtins (`list`, `Optional[...]` vs `... | None`). This is intentional and tied to the eager-annotation requirement above — keep `List[dict]` / `Optional[str]` exactly. Note fields are annotated `List[dict]` (not `List[dict[str, Any]]` — the per-card dict is opaque).

All three are **plain `@dataclass` (NOT frozen, NOT pydantic, NOT slots)**. They must be JSON-serializable for the Temporal payload converter.

### 2.1 `GateApprovedSignal` (`signals.py:24`)

Sent when a gate is approved via the review UI.

| Field | Type | Default |
|---|---|---|
| `gate_id` | `str` | (required) |
| `approved_by` | `str` | (required) |
| `justification` | `str` | `""` |
| `card_decisions` | `List[dict]` | `field(default_factory=list)` |
| `reviewer_notes` | `Optional[str]` | `None` |

(`signals.py:39-43`)

Docstring detail (W8 card-per-check / P5-S9, `signals.py:25-37`):
- `card_decisions` — list of per-card reviewer decisions captured by the card-per-check UI. **Each entry is a dict with keys: `card_id`, `artifact_type`, `decision`, `note`, `ai_pre_review_used`.** Empty for legacy callers that submit a single-decision approve.
- `reviewer_notes` — gate-level notes specific to the card UI, kept distinct from `justification` so downstream consumers can tell them apart. Optional.

⚠️ **GOTCHA — `card_decisions` uses `field(default_factory=list)`**, never a bare mutable default. The per-card dict schema (5 keys) is a contract that downstream rework logic reads; preserve the key names verbatim.

### 2.2 `GateRejectedSignal` (`signals.py:46`)

Sent when a gate is rejected with feedback.

| Field | Type | Default |
|---|---|---|
| `gate_id` | `str` | (required) |
| `rejected_by` | `str` | (required) |
| `reason` | `str` | (required) |
| `reason_category` | `Optional[str]` | `None` |
| `card_decisions` | `List[dict]` | `field(default_factory=list)` |
| `reviewer_notes` | `Optional[str]` | `None` |

(`signals.py:63-68`)

Docstring detail (`signals.py:47-61`):
- `reason_category` — structured category a reviewer picked in the Gate Review UI. **Optional** so Phase 3 gate implementers can drive per-gate rework behavior off it without forcing pre-2.5D producers to populate it. The free-text `reason` is **always present** (required, no default).
- `card_decisions` (W8/P5-S9) — per-card decisions; the agent uses the `reject` entries' `note` fields to target its rework. Empty for legacy callers.
- `reviewer_notes` — gate-level notes distinct from `reason`.

⚠️ **GOTCHA — field ORDER vs `GateApprovedSignal`.** Here the required `reason` comes before `reason_category`. Dataclass field order is part of the positional-construction contract; do not reorder. The three required positional fields are `gate_id, rejected_by, reason`.

### 2.3 `GateMergeRetrySignal` (`signals.py:71`)

Sent when a reviewer clicks "Resolve & Retry Merge" on a `merge_blocked` gate (W17 / P5-S17.4).

| Field | Type | Default |
|---|---|---|
| `gate_id` | `str` | (required) |
| `retried_by` | `str` | (required) |
| `note` | `Optional[str]` | `None` |

(`signals.py:87-89`)

Docstring detail (`signals.py:72-85`): emitted by `POST /api/v1/gates/{id}/retry-merge` after the reviewer resolved the underlying merge condition out-of-band (rebased the PR branch, relaxed branch protection, or resolved a content conflict). The workflow catches this signal via a `merge_retry` handler that flips an internal `_merge_retry_signalled` flag; the main loop wakes from `workflow.wait_condition` and re-invokes the merge activity (strategy doc §3.7).

⚠️ **GOTCHA — the wire signal name is `merge_retry`** (the workflow handler), even though the class is `GateMergeRetrySignal`. The class is the *payload*; the *signal channel name* the workflow registers is `merge_retry`.

### 2.4 `__all__` (`signals.py:94-99`)

```python
__all__ = [
    "GateApprovedSignal",
    "GateMergeRetrySignal",
    "GateRejectedSignal",
    "Any",          # <-- intentionally re-exported
]
```

⚠️ **GOTCHA — `Any` is in `__all__` on purpose** (comment `signals.py:92-93`): "Keep `Any` importable in case future signal additions want it (W8 card-per-check payloads carry opaque per-card dicts)." Reproduce this — it means `from olympus_contracts.signals import *` also binds `Any`.

---

## 3. `git_types.py` — branch regex + 4 result dataclasses + base exception

Module docstring (`git_types.py:1-6`): the `GitService` class itself lives in olympus-api (requires PyGithub) and is *copied into the worker container at Docker build time*. These pure-stdlib types can be imported anywhere without pulling in PyGithub. Has `from __future__ import annotations` (line 8). Imports `re` and `from dataclasses import dataclass` (lines 10-11).

### 3.1 `BRANCH_PATTERN` (`git_types.py:14`)

Compiled regex for the branch-naming convention. Comment (line 13): `olympus/{line}/{app_id}/{step}`.

```python
BRANCH_PATTERN = re.compile(
    r"^olympus/"
    r"(?P<line>[a-z][a-z0-9-]*)/"
    r"(?P<app_id>[a-z0-9][a-z0-9-]*)/"
    r"(?P<step>[a-z0-9][a-z0-9-]*)$"
)
```

(`git_types.py:14-19`)

⚠️ **GOTCHA — three named capture groups + asymmetric first-char rules.** The pattern is anchored `^…$` (whole-string match). Named groups: `line`, `app_id`, `step`. The `line` segment **must start with a lowercase letter** (`[a-z]`), while `app_id` and `step` may start with a letter **or digit** (`[a-z0-9]`). All three then allow `[a-z0-9-]*`. There is no uppercase, no underscore, no slash inside a segment. Exactly **3** path segments after the literal `olympus/` prefix. Reproduce the character classes precisely — branch creation and the drift between `app_id`/`step` (digit-leading allowed) vs `line` (letter-leading only) is load-bearing.

### 3.2 `GitServiceConfig` — `@dataclass` (`git_types.py:22`)

| Field | Type | Default |
|---|---|---|
| `token` | `str` | (required) |
| `repo` | `str` | (required) |
| `base_url` | `str` | `"https://api.github.com"` |

(`git_types.py:23-28`)

### 3.3 `PRResult` — `@dataclass` (`git_types.py:31`)

| Field | Type | Default |
|---|---|---|
| `pr_number` | `int` | (required) |
| `pr_url` | `str` | (required) |
| `source_branch` | `str` | (required) |
| `target_branch` | `str` | (required) |

(`git_types.py:32-37`)

### 3.4 `FileReadResult` — `@dataclass` (`git_types.py:41`)

| Field | Type | Default |
|---|---|---|
| `content` | `str` | (required) |
| `commit_sha` | `str` | (required) |
| `path` | `str` | (required) |

(`git_types.py:42-47`)

### 3.5 `CommitResult` — `@dataclass` (`git_types.py:50`)

| Field | Type | Default |
|---|---|---|
| `commit_sha` | `str` | (required) |
| `path` | `str` | (required) |
| `branch` | `str` | (required) |

(`git_types.py:51-56`)

⚠️ **GOTCHA — field-order differs between `FileReadResult` and `CommitResult`.** Both have `commit_sha` + `path`, but `FileReadResult` leads with `content` then `commit_sha, path`, while `CommitResult` is `commit_sha, path, branch`. Keep the orders distinct (positional construction differs).

### 3.6 `GitServiceError(Exception)` (`git_types.py:59`)

```python
class GitServiceError(Exception):
    """Raised when a Git service operation fails."""
```

(`git_types.py:59-60`). All four dataclasses are **plain `@dataclass`** (not frozen). This base exception is the parent of all three merge errors in `errors.py` (§4). ⚠️ It lives in **`git_types.py`, not `errors.py`** — `errors.py` imports it from here (`errors.py:34`). This split is deliberate: `git_types` is the pure-stdlib leaf, and `GitServiceError` must be importable without dragging in the merge-error subclasses.

---

## 4. `errors.py` — 3 merge-error subclasses + RETRYABLE semantics

Module docstring (`errors.py:1-30`) — read it as the canonical spec for retry behavior. Introduced by W17 / P5-S17.3a (2026-05-04). Before this module, **all** Git-service failures surfaced as a single `GitServiceError` with a string-only `mergeable_state` embedded in the message, making it impossible for Temporal retry policies / gate-recovery paths to distinguish a transient divergence from a content conflict from a branch-protection rejection. Full strategy: `specifications/phase-5/artifact-repo-merge-strategy.md` §3.4.

Imports: `from __future__ import annotations` (line 32); `from olympus_contracts.git_types import GitServiceError` (line 34).

**All three inherit from `GitServiceError`** (so legacy `except GitServiceError` call sites keep working; new sites discriminate on subclass). The class bodies are docstring-only (`pass`-equivalent) — no extra fields or `__init__`.

### 4.1 Retryability is signalled by **type name**, not a flag

⚠️ **GOTCHA — there is NO `retryable` attribute anywhere.** Retryable-ness is encoded purely by **which exception class is raised**, and is enforced *externally* by Temporal. The docstring (`errors.py:26-29`) states the exception type *names* are listed in `temporal/olympus_workflows/retry_policies.py`'s `GIT_MERGE_RETRY_POLICY.non_retryable_error_types`, so Temporal short-circuits retry on the non-retryable subclasses. A class is "non-retryable" iff its **string name** appears in that policy's `non_retryable_error_types` tuple. Therefore the *class names themselves are an API contract* — renaming `MergeConflict` → `MergeContentConflict` would silently make it retryable again (the string would no longer match the policy list).

| Class | `mergeable_state` trigger | Retryable? | Mechanism |
|---|---|---|---|
| `MergeConflict` | `"dirty"` | **NON-retryable** | name in `non_retryable_error_types` |
| `MergeDivergenceUnresolved` | `"behind"` (after update-branch) | **RETRYABLE** | name NOT in the list → bounded outer retries |
| `MergeBranchProtectionRejected` | `"blocked"` | **NON-retryable** | name in `non_retryable_error_types` |

The non-retryable ones drive the gate into `GateStatus.MERGE_BLOCKED` (§1.7) and wait for a `GateMergeRetrySignal` (§2.3).

### 4.2 `MergeConflict(GitServiceError)` (`errors.py:37`)

"PR has real content conflicts with its base branch." Surfaced when GitHub reports `mergeable_state == "dirty"`. **Non-retryable** — automation cannot resolve a three-way merge conflict without a human. Workflows catching this should transition the gate to `merge_blocked` and wait for a reviewer to rebase + resolve + push, then signal the workflow to retry (strategy doc §3.7). (`errors.py:37-46`)

### 4.3 `MergeDivergenceUnresolved(GitServiceError)` (`errors.py:49`)

"PR branch is behind its base and an automatic rebase did not converge." Surfaced when `mergeable_state == "behind"` **persists after** a `reconcile_and_merge_pr` invocation has already called the GitHub update-branch API. Typically means another PR merged while we were rebasing (a race) — **retryable**; Temporal's outer retry loop resolves it with a bounded number of additional attempts (see `GIT_MERGE_RETRY_POLICY`). (`errors.py:49-58`)

⚠️ **GOTCHA — this is the only retryable one**, and only because its name is *omitted* from `non_retryable_error_types`. The condition (`"behind"`) is itself ambiguous: `"behind"` *before* an update-branch attempt is normal/auto-fixable; `"behind"` *after* the attempt (what raises this) means a live race. The retry policy assumes seconds-scale resolution.

### 4.4 `MergeBranchProtectionRejected(GitServiceError)` (`errors.py:61`)

"Merge refused by a branch-protection rule that automation cannot satisfy." Surfaced when `mergeable_state == "blocked"` (required status check failing, required review missing, etc.). **Non-retryable without operator intervention** — retrying the same request produces the same rejection. (`errors.py:61-68`)

---

## 4a. `net.py` — TCP-keepalive socket options (NEW MODULE, 99 lines)

⚠️ **NEW AT HEAD.** `net.py` did not exist in the prior baseline. It is a pure-stdlib (`os` + `socket`, no httpx, no pyyaml) helper that builds `socket_options` enabling TCP keepalive for long-lived, byte-silent agent dispatches. Module docstring (`net.py:1-31`).

Imports (`net.py:33-36`): `from __future__ import annotations`; `import os`; `import socket`. ⚠️ Unlike `signals.py` (which deliberately OMITS `from __future__ import annotations`), `net.py` DOES use it — it is fine here because nothing in this module is introspected by Temporal's payload converter; it's plain functions returning tuples of ints.

### 4a.1 Why it exists (docstring, `net.py:7-30`)

Multiple services dispatch to the agent runtime over the same long-lived, byte-silent HTTP pattern — `olympus-worker` and `olympus-api` both ship a `dispatch_via_a2a` client, and `olympus-api` also has a chat-with-agent path. Each holds one connection open for the entire skill/chat run (minutes) and sends **zero bytes** until the agent returns its final JSON. When that connection crosses a device with a TCP idle timeout — the olympus-demo NLB's listeners enforce a fixed **~350s** idle timeout — the device silently severs any flow that's been byte-idle past the limit; the caller then blocks on a dead socket until its much larger read timeout fires, the work is retried, and long dispatches never complete end-to-end even though the agent finished. Enabling TCP keepalive makes the kernel emit probe packets on the otherwise-idle connection, so the LB always sees bytes within its idle window. Centralizing the option-builder here means every agent client gets the same protection from one source of truth (`net.py:21-25`). Callers wrap the result in their HTTP library's transport, e.g. `httpx.AsyncHTTPTransport(socket_options=keepalive_socket_options())` (`net.py:28-31`).

### 4a.2 Module constants (`net.py:42-44`)

```python
_DEFAULT_IDLE_S = 60
_DEFAULT_INTERVAL_S = 30
_DEFAULT_COUNT = 5
```

⚠️ **GOTCHA — both 60s idle + 30s interval MUST stay well under the smallest LB idle timeout in any path (~350s)** (comment `net.py:38-41`). 60s idle + 30s interval fires the first probe with wide margin. Tunable via env so the cadence can be retuned for a different LB **without rebuilding any image**.

### 4a.3 `_env_flag(name: str, default: bool) -> bool` (`net.py:47`)

```python
raw = os.environ.get(name)
if raw is None:
    return default
return raw.strip().lower() not in ("0", "false", "no", "off")
```

(`net.py:47-51`) ⚠️ **GOTCHA — falsy-string set is exactly `{"0","false","no","off"}`** (case-insensitive, whitespace-stripped). ANY other non-None value (including `""` after strip → not in the set → `True`, and `"1"`/`"yes"`/`"on"`/garbage) reads as **enabled**. Only those four tokens disable. An *unset* var returns `default` (which is `True` for the keepalive flag, §4a.5).

### 4a.4 `_env_int(name: str, default: int) -> int` (`net.py:54`)

```python
raw = os.environ.get(name)
if raw is None or not raw.strip():
    return default
try:
    return int(raw)
except ValueError:
    return default
```

(`net.py:54-61`) ⚠️ **GOTCHA — unset OR blank OR non-int all fall back to `default`** (no exception escapes). `int(raw)` is called on the *raw* (un-stripped) string; `int()` itself tolerates surrounding whitespace, so `" 90 "` parses to `90`. A negative or zero value is accepted as-is (no range check) — passing it to the socket option is the caller's/kernel's problem.

### 4a.5 `keepalive_socket_options() -> list[tuple[int, int, int]] | None` (`net.py:64`)

The single public function. Docstring (`net.py:65-81`) lists the four env overrides. Logic, reproduce exactly (`net.py:82-98`):

```python
if not _env_flag("A2A_TCP_KEEPALIVE", True):
    return None

idle_s = _env_int("A2A_TCP_KEEPALIVE_IDLE_S", _DEFAULT_IDLE_S)
interval_s = _env_int("A2A_TCP_KEEPALIVE_INTERVAL_S", _DEFAULT_INTERVAL_S)
count = _env_int("A2A_TCP_KEEPALIVE_COUNT", _DEFAULT_COUNT)

opts: list[tuple[int, int, int]] = [
    (socket.SOL_SOCKET, socket.SO_KEEPALIVE, 1)
]
if hasattr(socket, "TCP_KEEPIDLE"):
    opts.append((socket.IPPROTO_TCP, socket.TCP_KEEPIDLE, idle_s))
if hasattr(socket, "TCP_KEEPINTVL"):
    opts.append((socket.IPPROTO_TCP, socket.TCP_KEEPINTVL, interval_s))
if hasattr(socket, "TCP_KEEPCNT"):
    opts.append((socket.IPPROTO_TCP, socket.TCP_KEEPCNT, count))
return opts
```

Behavior / env overrides (all optional):
- `A2A_TCP_KEEPALIVE` — enable/disable (default **enabled**). Disabled → returns `None` so callers fall back to their HTTP library's default transport (`net.py:82-83`).
- `A2A_TCP_KEEPALIVE_IDLE_S` — seconds idle before first probe (default 60).
- `A2A_TCP_KEEPALIVE_INTERVAL_S` — seconds between probes (default 30).
- `A2A_TCP_KEEPALIVE_COUNT` — failed probes before drop (default 5).

⚠️ **GOTCHA — return type is `list[...] | None`, and the list ALWAYS starts with `(SOL_SOCKET, SO_KEEPALIVE, 1)`** when enabled. The three `TCP_KEEPIDLE`/`TCP_KEEPINTVL`/`TCP_KEEPCNT` tuples are **conditionally appended only when the running platform exposes those constants** (`hasattr(socket, ...)`). On Linux (the deployed stack) all four are present; on **macOS / Windows dev hosts** those constants are absent so the function returns just the single `SO_KEEPALIVE` tuple. The docstring is explicit this is fine — "the byte-silent-NLB path only exists in the deployed Linux stack" (`net.py:72-74`). ⚠️ A regenerator MUST keep the `hasattr` guards: unconditionally referencing `socket.TCP_KEEPIDLE` raises `AttributeError` at call time on macOS, breaking every dev-host import path that calls this.

⚠️ **GOTCHA — disabled-vs-enabled is `None` vs a list, NOT an empty list.** Callers branch on `None` to mean "use library default." Returning `[]` when disabled would be a different contract (it would set no socket options but still install a custom transport). Preserve the `return None` early exit.

⚠️ **GOTCHA — `net.py` is NOT in `__init__.__all__`** (§0). Consumers import `from olympus_contracts.net import keepalive_socket_options` directly. Do not add it to the re-export surface — that would change `from olympus_contracts import *`.

---

## 5. `assembly_lines.py` — THE LOADER (403 lines)

The authoritative assembly-line contract loader. Module docstring (`assembly_lines.py:1-26`): "ONE source of truth for every line's steps, skills, artifacts, side-effects, and agent contract." The YAML files under `data/assembly-lines/` are authoritative; this module loads them into typed, frozen dataclasses **at import time** (via the lru-cached loader, lazily on first query) and exposes a small query API. **"Do NOT hardcode step lists, skill names, or pass orders in application code. The `test_no_hardcoded_step_lists` CI guard fails the build if you try."** (§6).

Imports (`assembly_lines.py:28-35`):
```python
from __future__ import annotations
from dataclasses import dataclass, field
from functools import lru_cache
from importlib.resources import files
from typing import Any
import yaml
```

`__all__` (`assembly_lines.py:37-54`), alphabetically sorted: `AgentContract, GateRef, LineContract, RepoAccess, RetryPolicy, SideEffect, StepContract, StepIO, discovery_passes, get_line, get_step, list_lines, line_names, pass_order, skill_for_step, step_progress`.

⚠️ **GOTCHA — `step_weights` is NOT in `assembly_lines.__all__`** even though the function is defined (`assembly_lines.py:393`) AND re-exported from the package root `__init__.__all__` (`__init__.py:106`). So `from olympus_contracts.assembly_lines import *` will NOT bind `step_weights`, but `from olympus_contracts import step_weights` works. Preserve this asymmetry.

### 5.1 The 9 frozen dataclasses

All declared `@dataclass(frozen=True, slots=True)`. ⚠️ **GOTCHA — `slots=True` + `frozen=True`** means instances are immutable AND cannot grow attributes; mutation raises `dataclasses.FrozenInstanceError` (a subclass of `AttributeError`) — the `test_frozen` test (§5.7) catches `(AttributeError, TypeError)`. Defaults that are themselves dataclasses use `field(default_factory=...)` (never a shared mutable default). Tuples (not lists) are used everywhere a collection appears, because frozen+hashable contracts must be immutable.

**(1) `RepoAccess`** (`assembly_lines.py:62`) — per-repo access level for a step's agent contract.

| Field | Type | Default |
|---|---|---|
| `artifact` | `str` | `"none"` |
| `source` | `str` | `"none"` |
| `target` | `str` | `"none"` |

Comment (line 65): values are `rw | ro | none`.

**(2) `AgentContract`** (`assembly_lines.py:71`) — "what the step's agent is allowed to touch."

| Field | Type | Default |
|---|---|---|
| `mcp_servers` | `tuple[str, ...]` | `()` |
| `repos` | `RepoAccess` | `field(default_factory=RepoAccess)` |

**(3) `SideEffect`** (`assembly_lines.py:79`) — "a projection from a step's output onto another system of record."

| Field | Type | Default |
|---|---|---|
| `target` | `str` | (required) |
| `fields` | `tuple[str, ...]` | `()` |

Comment (line 83): `target` e.g. `"application"`, `"gate_record"`, `"artifact-repo"`.

**(4) `StepIO`** (`assembly_lines.py:87`) — step inputs or outputs: "artifact keys plus free-form context tags."

| Field | Type | Default |
|---|---|---|
| `artifacts` | `tuple[str, ...]` | `()` |
| `context` | `tuple[str, ...]` | `()` |
| `side_effects` | `tuple[SideEffect, ...]` | `()` |

**(5) `RetryPolicy`** (`assembly_lines.py:96`) — "retry policy hint consumed by the Temporal activity wrapper."

| Field | Type | Default |
|---|---|---|
| `category` | `str` | `"transient"` |
| `non_retryable_errors` | `tuple[str, ...]` | `()` |
| `max_attempts_override` | `int \| None` | `None` |

**(6) `GateRef`** (`assembly_lines.py:105`) — "reference to a gate emitted by a line."

| Field | Type | Default |
|---|---|---|
| `id` | `str` | (required) |
| `label` | `str` | `""` |

**(7) `StepContract`** (`assembly_lines.py:113`) — one step in an assembly line. Docstring: "Fields mirror the yaml schema exactly. `summary=True` marks the step that rolls up the line's findings (rendered first in gate review)."

| Field | Type | Default | Notes (comments in source) |
|---|---|---|---|
| `id` | `str` | (required) | |
| `label` | `str` | (required) | |
| `kind` | `str` | (required) | `agent \| git \| gate \| deterministic` (comment line 124) |
| `scope` | `str` | (required) | `per-app \| per-wave \| per-target-app \| …` (comment line 125) |
| `sequence` | `int` | (required) | |
| `purpose` | `str` | (required) | |
| `skills` | `tuple[str, ...]` | `()` | |
| `agent_role` | `str \| None` | `None` | |
| `role` | `str` | `"analysis"` | `analysis \| pre-review \| rollup \| operational` (comment line 129) |
| `inputs` | `StepIO` | `field(default_factory=StepIO)` | |
| `outputs` | `StepIO` | `field(default_factory=StepIO)` | |
| `agent_contract` | `AgentContract` | `field(default_factory=AgentContract)` | |
| `parallel_with` | `tuple[str, ...]` | `()` | |
| `gate` | `str \| None` | `None` | |
| `retry_policy` | `RetryPolicy` | `field(default_factory=RetryPolicy)` | |
| `progress_pct` | `int \| None` | `None` | |
| `progress_weight` | `float \| None` | `None` | |
| `artifact_filename` | `str \| None` | `None` | |
| `summary` | `bool` | `False` | |

(`assembly_lines.py:121-139`) — **19 fields.** Field order is the positional/repr contract; reproduce exactly.

⚠️ **GOTCHA — `kind` and `role` are plain `str`, NOT enums.** The loader does NOT validate them against a closed set at parse time. The *test* `test_every_step_has_valid_kind` (§5.7) is what enforces the allowed kinds — and its allowed set is **wider** than what the docstring comment lists (see §5.7). A regenerator that turns `kind` into an enum would reject YAML the tests currently allow.

**(8) `LineContract`** (`assembly_lines.py:142`) — a full assembly-line contract.

| Field | Type | Default | Comment |
|---|---|---|---|
| `name` | `str` | (required) | |
| `description` | `str` | (required) | |
| `trigger` | `str` | (required) | |
| `depends_on` | `tuple[str, ...]` | (required) | |
| `gates` | `tuple[GateRef, ...]` | (required) | |
| `mode` | `str` | (required) | `per-app \| per-wave \| per-target-app \| continuous` (line 151) |
| `inputs` | `tuple[str, ...]` | (required) | |
| `outputs` | `tuple[str, ...]` | (required) | |
| `steps` | `tuple[StepContract, ...]` | (required) | |

(`assembly_lines.py:144-154`) — **9 fields, all required (no defaults).**

`LineContract` also carries **4 methods** (it is a query object, not just data — §5.2).

> Dataclass count = **8** typed models (the 7 small ones + `StepContract` + `LineContract`)… counting precisely: `RepoAccess, AgentContract, SideEffect, StepIO, RetryPolicy, GateRef, StepContract, LineContract` = **8 frozen dataclasses** in this module. (The status line at the end reports **8** loader dataclasses; `GitServiceConfig`/`PRResult`/etc. live in `git_types.py`, not here.)

### 5.2 `LineContract` methods (`assembly_lines.py:160-192`)

- **`step(self, step_id: str) -> StepContract`** (`:160`) — linear scan `for s in self.steps: if s.id == step_id: return s`; on miss raises `KeyError(f"{self.name} has no step {step_id!r}")`. ⚠️ O(n) scan, not a dict — order-preserving and case-sensitive.
- **`step_ids(self) -> tuple[str, ...]`** (`:167`) — `tuple(s.id for s in self.steps)`, in workflow declaration order (= YAML order).
- **`agent_steps(self) -> tuple[StepContract, ...]`** (`:171`) — `tuple(s for s in self.steps if s.kind == "agent")`. **All** agent steps regardless of role.
- **`evidence_steps(self) -> tuple[StepContract, ...]`** (`:175`) — `tuple(s for s in self.steps if s.kind == "agent" and s.role in ("analysis", "rollup"))`. ⚠️ **GOTCHA — excludes `pre-review` and `operational` agent steps** so the gate-review UI only renders cards for analytical passes (catalog, synthesis, …), not for the gate-readiness-checks that review the PR itself. ⚠️ **CHANGED AT HEAD — now TWO lines have excluded agent steps:** **Discovery** (`gate-readiness-check`, role `pre-review` → 11 agent / 10 evidence) and the NEW **Build** (THREE pre-review checks `spec-gate-readiness-check` / `design-gate-readiness-check` / `generate-gate-readiness-check` → 6 agent / 3 evidence; evidence = `spec-from-requirements, design, generate`). For all other lines `agent_steps == evidence_steps`.
- **`summary_step(self) -> StepContract | None`** (`:187`) — first step with `s.summary` truthy, else `None`. ⚠️ Returns the *first* match; the YAML must declare at most one `summary: true` per line (not enforced by the loader, but tested for Discovery only). Lines **Deployment** and **Validation** have NO summary step (`summary_step()` → `None`). ⚠️ **GOTCHA (NEW Build line) — `summary_step()` and `evidence_steps()` can return DISJOINT sets.** Build's summary step is `design-gate-readiness-check` (`role: pre-review`, `summary: true`), so `summary_step()` returns it while `evidence_steps()` EXCLUDES it (pre-review filtered out). Build is the first line where the summary step is not also an evidence/card step. A `summary: true` on a pre-review step is therefore valid and intentional — do not "normalize" the summary flag onto an analysis step.

### 5.3 Parse helpers (private)

- **`_t(value: Any) -> tuple`** (`assembly_lines.py:200`) — normalizes `None`/list/tuple/scalar into a tuple:
  - `None` → `()` (`:202-203`)
  - `list` or `tuple` → `tuple(value)` (`:204-205`)
  - else (scalar) → `(value,)` 1-tuple (`:206`)
  ⚠️ **GOTCHA — a bare YAML scalar (e.g. `depends_on: Rationalization`) becomes a 1-tuple `("Rationalization",)`, not a string.** This is why every list-shaped field tolerates a scalar in the YAML. A string passed here is NOT iterated char-by-char (it hits the scalar branch, since `str` is not `list`/`tuple`).
- **`_parse_step_io(raw: dict | None) -> StepIO`** (`:209`) — `raw = raw or {}`; builds `side_effects` as a tuple of `SideEffect(target=se.get("target",""), fields=_t(se.get("fields")))` for each `se` in `(raw.get("side_effects") or [])`; returns `StepIO(artifacts=_t(raw.get("artifacts")), context=_t(raw.get("context")), side_effects=…)`. ⚠️ Missing `target` in a side-effect defaults to `""` (empty string), not an error.
- **`_parse_agent_contract(raw: dict | None) -> AgentContract`** (`:225`) — `raw = raw or {}`; `repos_raw = raw.get("repos") or {}`; returns `AgentContract(mcp_servers=_t(raw.get("mcp_servers")), repos=RepoAccess(artifact=repos_raw.get("artifact","none"), source=repos_raw.get("source","none"), target=repos_raw.get("target","none")))`. ⚠️ Each repo access defaults to `"none"` when absent.
- **`_parse_retry_policy(raw: dict | None) -> RetryPolicy`** (`:238`) — `raw = raw or {}`; returns `RetryPolicy(category=raw.get("category","transient"), non_retryable_errors=_t(raw.get("non_retryable_errors")), max_attempts_override=raw.get("max_attempts_override"))`. ⚠️ `max_attempts_override` passes through raw (no coercion) — `None` if absent.
- **`_parse_gates(raw: list | None) -> tuple[GateRef, ...]`** (`:247`) — `raw = raw or []`; for each `g`: if `isinstance(g, str)` → `GateRef(id=g)` (label defaults `""`); elif `isinstance(g, dict)` → `GateRef(id=g["id"], label=g.get("label",""))`. ⚠️ **GOTCHA — gates accept BOTH a bare string AND a `{id, label}` dict** in the same YAML list. Anything that is neither str nor dict is **silently skipped** (no else branch). A dict missing `id` raises `KeyError` (hard `g["id"]`, not `.get`).

### 5.4 `_parse_step(raw: dict) -> StepContract` (`assembly_lines.py:258`)

Maps every YAML key to a `StepContract` field. Reproduce the per-field defaults exactly (`:259-279`):

| Field | Source expression | Default behavior |
|---|---|---|
| `id` | `raw["id"]` | **required** — `KeyError` if missing |
| `label` | `raw.get("label", raw["id"])` | ⚠️ falls back to the **id** if `label` absent (and will `KeyError` on missing `id` while computing the default) |
| `kind` | `raw.get("kind", "agent")` | defaults `"agent"` |
| `scope` | `raw.get("scope", "per-app")` | defaults `"per-app"` |
| `sequence` | `int(raw.get("sequence", 0))` | coerced to int; defaults `0` |
| `purpose` | `(raw.get("purpose") or "").strip()` | ⚠️ `None`→`""`, and **whitespace-stripped** |
| `skills` | `_t(raw.get("skills"))` | tuple-normalized |
| `agent_role` | `raw.get("agent_role")` | `None` if absent |
| `role` | `raw.get("role", "analysis")` | defaults `"analysis"` |
| `inputs` | `_parse_step_io(raw.get("inputs"))` | empty `StepIO` if absent |
| `outputs` | `_parse_step_io(raw.get("outputs"))` | empty `StepIO` if absent |
| `agent_contract` | `_parse_agent_contract(raw.get("agent_contract"))` | default `AgentContract` if absent |
| `parallel_with` | `_t(raw.get("parallel_with"))` | tuple-normalized |
| `gate` | `raw.get("gate")` | `None` if absent |
| `retry_policy` | `_parse_retry_policy(raw.get("retry_policy"))` | default `RetryPolicy` if absent |
| `progress_pct` | `raw.get("progress_pct")` | `None` if absent (no int coercion!) |
| `progress_weight` | `raw.get("progress_weight")` | `None` if absent (no float coercion at parse) |
| `artifact_filename` | `raw.get("artifact_filename")` | `None` if absent |
| `summary` | `bool(raw.get("summary", False))` | coerced to bool; defaults `False` |

⚠️ **GOTCHA — `sequence` is int-coerced but `progress_pct` is NOT.** `sequence` goes through `int(...)`; `progress_pct` is stored raw. `step_progress()` later filters on `is not None` and treats it as int (the YAML must supply ints). `progress_weight` is stored raw and only `float(...)`-coerced inside `step_weights()` (`:401`), not at parse.

⚠️ **GOTCHA — `label` default uses `raw["id"]`.** If a step omits both `id` and `label`, the `KeyError` fires while evaluating the *default*, surfacing as `KeyError: 'id'`.

### 5.5 `_parse_line(raw: dict) -> LineContract` (`assembly_lines.py:282`)

```python
steps = tuple(_parse_step(s) for s in raw.get("steps", []))
return LineContract(
    name=raw["name"],                                   # required → KeyError if missing
    description=(raw.get("description") or "").strip(),  # None→"", stripped
    trigger=raw.get("trigger", ""),                      # default ""
    depends_on=_t(raw.get("depends_on")),                # tuple-normalized
    gates=_parse_gates(raw.get("gates")),
    mode=raw.get("mode", "per-app"),                     # default "per-app"
    inputs=_t(raw.get("inputs")),
    outputs=_t(raw.get("outputs")),
    steps=steps,
)
```

⚠️ `name` is the only hard-required line field (`raw["name"]`). `steps` defaults to `()` if the `steps:` key is absent — but `test_every_line_has_at_least_one_step` (§5.7) then fails. Steps are parsed in **YAML document order** and stored as an ordered tuple (declaration order == workflow order).

### 5.6 `_load_all()` — the cached file walker (`assembly_lines.py:297`)

Decorated `@lru_cache(maxsize=1)`. Docstring (`:298-303`): "Load every yaml under `data/assembly-lines/` and index by name. Cached — contracts are immutable at runtime. Tests that need a fresh read call `_load_all.cache_clear`."

Logic, reproduce exactly (`:304-327`):

```python
data_root = files("olympus_contracts").joinpath("data/assembly-lines")
lines: dict[str, LineContract] = {}
for entry in sorted(data_root.iterdir(), key=lambda p: p.name):
    if not entry.name.endswith(".yaml") or entry.name.startswith("_"):
        continue
    with entry.open("r", encoding="utf-8") as fh:
        raw = yaml.safe_load(fh)
    if not isinstance(raw, dict) or "name" not in raw:
        raise ValueError(f"assembly-line contract {entry.name} missing top-level 'name'")
    line = _parse_line(raw)
    if line.name in lines:
        raise ValueError(f"duplicate assembly-line contract for {line.name!r} (file {entry.name})")
    lines[line.name] = line
if not lines:
    raise RuntimeError("no assembly-line contracts found — check olympus_contracts/data/assembly-lines/ ships with the package")
return lines
```

Load-time behaviors / invariants (each is a hard runtime check that fires on first query):

1. **Files iterated in filename-sorted order** (`sorted(..., key=lambda p: p.name)`, `:306`). ⚠️ Deterministic ordering → `list_lines()` returns lines in *line-name* sorted order (because dict insertion follows the by-filename walk, then `.values()` is returned; the filenames happen to sort to the same order as the line names — verified: `['Architecture','Data','Deployment','Discovery','Disposition Execution','Governance','Modernization','Rationalization','Sustainment','Validation']`). The `test_list_lines_sorted` test pins `list(line_names()) == sorted(line_names())`.
2. **Skip rule** (`:307-308`): any entry whose name does NOT end `.yaml`, OR that **starts with `_`**, is skipped. ⚠️ So a `_template.yaml` or `_shared.yaml` is intentionally ignored.
3. **Files read as UTF-8** (`encoding="utf-8"`, `:309`) and parsed with `yaml.safe_load` (`:310`) — **safe_load**, never `load` (no arbitrary tag construction).
4. **INVARIANT: top-level must be a dict with a `name`** (`:311-314`). Raises `ValueError("assembly-line contract {file} missing top-level 'name'")` otherwise. Catches a YAML that parses to a list, a scalar, or a mapping without `name`.
5. **INVARIANT: no duplicate line names** (`:316-320`). Raises `ValueError("duplicate assembly-line contract for {name!r} (file {file})")` if two files declare the same `LineContract.name`.
6. **INVARIANT: at least one contract must load** (`:322-326`). Raises `RuntimeError("no assembly-line contracts found …")` if the dict is empty — the canary for a wheel that didn't ship the `package_data` YAML (§0).

⚠️ **GOTCHA — `lru_cache(maxsize=1)` makes the load happen exactly once per process.** Editing a YAML at runtime has no effect until `_load_all.cache_clear()` is called. Every test's `setup_function` does exactly this (`test_assembly_lines.py:27-29`). A regenerator that drops the cache decorator changes performance (re-reads disk on every `get_line`) and breaks the tests' cache-clear contract; one that uses a larger maxsize is harmless but non-faithful.

### 5.7 Public query API

- **`list_lines() -> tuple[LineContract, ...]`** (`:335`) — `tuple(_load_all().values())`. Docstring says "sorted by name" (true by construction, see §5.6 inv. 1).
- **`line_names() -> tuple[str, ...]`** (`:340`) — `tuple(_load_all().keys())`. "Just the line names, sorted."
- **`get_line(name: str) -> LineContract`** (`:345`) — dict lookup; on `KeyError` re-raises `KeyError(f"unknown assembly line {name!r}; known: {list(_load_all())}")` with `from exc`. ⚠️ Error message embeds the full list of known line names.
- **`get_step(line_name: str, step_id: str) -> StepContract`** (`:355`) — `get_line(line_name).step(step_id)` (chains both KeyErrors).
- **`skill_for_step(line_name: str, step_id: str) -> str | None`** (`:360`) — `step.skills[0] if step.skills else None`. ⚠️ Returns only the **first** skill; deterministic (git/gate/no-agent) steps with empty `skills` return `None`.
- **`pass_order(line_name: str) -> tuple[str, ...]`** (`:368`) — `tuple(s.id for s in get_line(line_name).evidence_steps())`. The ordered analytical-agent step ids a reviewer sees as gate-review cards. Excludes pre-review + operational agents (docstring `:369-375`).
- **`discovery_passes() -> tuple[str, ...]`** (`:379`) — shortcut for `pass_order("Discovery")`.
- **`step_progress(line_name: str) -> dict[str, int]`** (`:385`) — `{s.id: s.progress_pct for s in line.steps if s.progress_pct is not None}`. Consumed by the API's application-progress calculator.
- **`step_weights(line_name: str) -> dict[str, float]`** (`:393`) — `{s.id: float(s.progress_weight) for s in line.steps if s.progress_weight is not None}`. ⚠️ `float(...)` coercion happens **here**, not at parse. Used by workflows that publish cumulative progress by summing per-step weights.

### 5.8 Authoritative per-line metadata (from running the loader at HEAD — 11 lines)

⚠️ **CHANGED AT HEAD — `list_lines()` now returns 11 lines (was 10). `Build` was added** and sorts second (between `Architecture` and `Data`) because the by-filename walk + by-name sort coincide (`build.yaml` sorts after `architecture.yaml`, before `data.yaml`). Verified order: `['Architecture','Build','Data','Deployment','Discovery','Disposition Execution','Governance','Modernization','Rationalization','Sustainment','Validation']`. The `test_list_lines_sorted` invariant (`list(line_names()) == sorted(line_names())`) still holds with Build present.

| Line (`name`) | `mode` | `trigger` | `depends_on` | gates (`id`s) | summary step |
|---|---|---|---|---|---|
| Architecture | per-target-app | rationalization-g-da-approved | Rationalization | G-02 | blueprint-assembly |
| **Build** (NEW) | per-app | architecture-g02-approved-and-data-g-dt-approved | Architecture, Rationalization | G-NEW-1, G-NEW-2, G-NEW-3 | design-gate-readiness-check ⚠️ |
| Data | per-target-app | architecture-target-provisioned | Rationalization | G-DT | data-synthesis |
| Deployment | per-app | validation-approved-or-disposition-executed | Validation, Disposition Execution | G-DP-1, G-DP-2 | (none) |
| Discovery | per-app | onboarding | () | G-DC | synthesis |
| Disposition Execution | per-app | rationalization-g-da-approved-non-modernization | Rationalization | G-DE-1, G-DE-2 | bundle-post-gate-evidence |
| Governance | continuous | temporal-schedule | () | (none) | commit-sweep-summary |
| Modernization | per-target-app | architecture-g02-approved-and-data-g-dt-approved | Architecture, Data | G-04a, G-04b, G-04c | design-pre-review |
| Rationalization | per-wave | wave-ready | Discovery | G-RR, G-DA | wave-outcome-synthesis |
| Sustainment | continuous | temporal-schedule | Deployment, Disposition Execution | (none) | commit-sweep-summary |
| Validation | per-app | modernization-g-04c-approved-with-generate-artifacts | Modernization | G-V1, G-V2, G-V3 | (none) |

⚠️ **GOTCHA — Build's `summary_step` is `design-gate-readiness-check`, which has `role: pre-review`.** This is unique: `summary_step()` returns it (first `summary: true` step), but `evidence_steps()`/`pass_order("Build")` EXCLUDE it (pre-review is not in `{analysis, rollup}`). So Build's summary step is NOT in its card list. (Modernization's summary step `design-pre-review` is likewise a pre-review-style step — Build mirrors that pattern.) Full Build reproduction: `regen/06-contracts/build-steps.md`.

⚠️ **GOTCHA — Build's `gates` (`G-NEW-1/2/3`) are NOT `GateType` members** (§1.6) and NOT in `GATE_ASSEMBLY_LINES` (§1.6.3). The "gates must equal `AssemblyLine` values / `GateType` codes" invariant in §1.6.3 applies to the 10 standard-enum lines; Build's gates are line-local strings in `build.yaml` only.

⚠️ **GOTCHA — only 4 step kinds actually occur in the data: `agent`, `code`, `gate`, `git`** (Build uses only `agent`/`gate`/`git` — no `code` step). The `StepContract.kind` docstring comment names `agent | git | gate | deterministic` (`assembly_lines.py:124`) and the test allows `{agent, git, gate, deterministic, code, terminal}` — but `deterministic` and `terminal` are **allowed-but-unused** in the current YAML. `code` (deterministic workflow code: handshake/signal-wait steps) and `terminal` (no-op summary anchor) are documented in the test comment (`test_assembly_lines.py:55-57`). Reproduce all six as allowed kinds even though only four appear.

---

## 6. ANTI-DRIFT mechanisms — `tests/test_no_hardcoded_step_lists.py`

Purpose (docstring `:1-23`): a CI drift guard. The failure mode: someone hardcodes a literal list of step ids in application code, the contract later renames a step, and the literal goes stale. **The 2026-05-05 gate-review bug that dropped 4 of 7 cards was exactly this** — `_DISCOVERY_ORDER` in `olympus-api/src/services/gate.py` had stale keys. The rule it enforces: no scanned `.py` file may encode a **cluster** of step-id string literals from any one line.

### 6.1 What it scans (`:34-52`)

- `REPO_ROOT = Path(__file__).resolve().parents[2]` — two levels up from `tests/` (the foundry repo root).
- `SCAN_DIRS` (`:37-41`): `olympus-api/src`, `olympus-worker/src`, `temporal/olympus_workflows`.
- `SKIP_PATTERNS` (`:44-52`): any path containing `/.venv/`, `/__pycache__/`, `/build/`, `/.agents/`, `/.codex/`, `/tests/`, `/registries/defaults/`. ⚠️ `/tests/` is skipped because test fixtures legitimately enumerate step ids; `/registries/defaults/` is yaml/generated.

### 6.2 The two waiver regexes (`:56-68`)

- **Per-line waiver** `ALLOWLIST_RE` (`:56-59`): `#\s*allow:\s*step-list-literal\s*[—\-]\s*(\S[^\n]*)`, case-insensitive. The reason (group 1) must be non-empty. Valid only on the same line or the immediately-preceding line (`_line_is_allowed`, `:91-101`).
- **File-scoped waiver** `FILE_ALLOWLIST_RE` (`:65-68`): `#\s*allow-file:\s*step-list-literal\s*[—\-]\s*(\S[^\n]*)`, case-insensitive — anywhere in the file waives the whole file. Docstring: use SPARINGLY, only when the entire file is the legitimate literal source (e.g. legacy `step_mapping.py` dicts pending contracts-v2).

⚠️ **GOTCHA — the waiver accepts an em-dash `—` OR a hyphen `-`** (`[—\-]`). The CLAUDE.md / canonical waiver text uses the em-dash form `# allow: step-list-literal — <reason>`.

### 6.3 The detection algorithm (`:104-176`)

Constants: `CLUSTER_WINDOW = 10`, `CLUSTER_THRESHOLD = 5` (`:104-105`).

Parametrized over **each line's set of step ids** (`_collect_step_ids()`, `:71-77`, one `pytest.param(..., id=f"line-{i}")` per line, `:108-111`). For each scanned `.py` file (via `_iter_py_files`, `:80-88`):

1. Read the file (UTF-8); on any read exception, `continue` (`:125-127`).
2. If `FILE_ALLOWLIST_RE` matches anywhere → whole-file waiver, `continue` (`:129-130`).
3. For each source line, if it contains `f'"{step_id}"'` OR `f"'{step_id}'"` for any step_id in this line's set, record the line number once (`break` after first hit per line) → `hit_line_nums` (`:132-137`). ⚠️ **Matches quoted literals only** — `"catalog"` or `'catalog'`. A bareword `catalog` (e.g. a variable) does NOT trigger.
4. If `< CLUSTER_THRESHOLD` (5) total hits → `continue` (`:138-139`). So ≤4 scattered step-id literals in a file are always fine.
5. Slide a window over `hit_line_nums` (`:142-154`): for each start `i`, take the next `CLUSTER_THRESHOLD` hits; if `window[-1] - window[0] < CLUSTER_WINDOW` (i.e. 5 hits within a 10-line span), extend forward while still inside the 10-line window, and record the cluster.
6. Drop clusters where **every** line is allowlisted (`_line_is_allowed`, `:157-161`).
7. If any live cluster remains, append a violation message naming the file, the cluster size, the line range, and instructing to load from `olympus_contracts.pass_order(...)` / `get_line(...)` or add the per-line waiver comment (`:164-171`).

Final assertion (`:173-176`): `assert not violations`, listing every violation.

⚠️ **GOTCHA — it flags a CLUSTER (≥5 step-id literals within any 10-line window), NOT individual references.** The windowed design lets legitimate per-step producer writes pass — e.g. `self._set_step("catalog", ...)` on line 40 and `self._set_step("synthesis", ...)` on line 90 are fine (far apart). A hand-written dict enumerating step ids one-after-another is what gets blocked. So a regenerator that scatters individual `_set_step(...)` calls is safe; one that reconstructs a `_DISCOVERY_ORDER = ["catalog", "structural-analysis", …]` literal trips it. **How it fails on drift:** the literal list is detected as a 5+ cluster *today* (passing only if waived); the moment a contract step is renamed and the literal isn't, the stale literal is *still* a cluster (so it keeps being flagged unless waived) — the actual protection is cultural+mechanical: you cannot land a fresh hardcoded list without either loading from the contract or writing a justified waiver, so the stale-list class of bug is structurally prevented at PR time.

### 6.4 The other guard tests in `tests/`

`tests/test_assembly_lines.py` is itself a drift guard (the "first line of defence" per its docstring `:1-6`). Each test names the invariant it protects:

| Test (`test_assembly_lines.py`) | What it guards | How it fails on drift |
|---|---|---|
| `TestLoader.test_discovery_loads` (`:33`) | Discovery's identity: `name=="Discovery"`, `mode=="per-app"`, `trigger=="onboarding"`, `depends_on==()`, `"G-DC"` in gate ids | renaming Discovery's mode/trigger/gate breaks here |
| `test_every_line_has_unique_step_ids` (`:43`) | per-line step ids are unique (`len(ids)==len(set(ids))`) | a copy-pasted duplicate step id fails |
| `test_every_line_has_at_least_one_step` (`:50`) | every line has ≥1 step | a stub line with no `steps:` fails |
| `test_every_step_has_valid_kind` (`:54`) | `step.kind ∈ {agent, git, gate, deterministic, code, terminal}` (`:58`) | a typo'd/new kind fails; **note the allowed set here is the authority, wider than the dataclass docstring** |
| `test_list_lines_sorted` (`:65`) | `list(line_names()) == sorted(line_names())` | a filename that breaks the sort-equals-name ordering fails |
| `test_unknown_line_raises` (`:69`) | `get_line("NotALine")` raises `KeyError` matching `"unknown assembly line"` | a swallowed-error refactor fails |
| `TestDiscoveryContract.test_analysis_passes_in_canonical_order` (`:77`) | **pins the exact 10-tuple** of Discovery pass ids: `("catalog","structural-analysis","business-logic-extraction","quality-risk-assessment","ux-accessibility-assessment","data-domain-discovery","shared-database-analysis","capability-extraction","synthesis","tco-baseline")` | any reorder/rename/add/remove of a Discovery evidence step fails (this is the strongest single anti-drift pin in the suite) |
| `test_synthesis_is_the_summary_step` (`:101`) | `summary_step().id == "synthesis"` | moving the summary flag fails |
| `test_gate_readiness_check_is_excluded_from_passes` (`:107`) | `"gate-readiness-check" NOT in discovery_passes()` but IS in `agent_steps()` ids | flipping its role from `pre-review` to `analysis` fails |
| `test_every_analysis_step_has_a_skill` (`:116`) | every Discovery `evidence_steps()` has non-empty `skills` | an evidence step with no skill fails |
| `test_skill_for_step` (`:120`) | `skill_for_step("Discovery","catalog")=="catalog-application"`; `…"synthesis")=="discovery-synthesizer"`; `…"commit-artifacts") is None` | renaming those skills fails |
| `test_step_progress_monotonic_for_sequential_steps` (`:126`) | progress never decreases within a line (`p >= last`) | a YAML progress regression fails |
| `test_pass_order_matches_evidence_steps` (`:139`) | `pass_order("Discovery") == tuple(s.id for s in evidence_steps())` | a divergence between the two derivations fails |
| `TestStepLookup.test_get_step_returns_typed_step` (`:146`) | `get_step("Discovery","synthesis")` is `StepContract`, `summary is True`, `agent_role=="Synthesis Agent"` | renaming synthesis's agent_role fails |
| `test_get_step_unknown_raises` (`:152`) | unknown step raises `KeyError` matching `"no step"` | error-message drift fails |
| `test_step_io_tuples` (`:156`) | `catalog` inputs.context & outputs.artifacts are **tuples**, and `"application-catalog-entry" in catalog.outputs.artifacts` | a list-not-tuple regression (e.g. dropping `_t`) fails |
| `test_agent_contract_preserved` (`:163`) | `catalog.agent_contract.repos.artifact=="rw"`, `.source=="ro"`, `"olympus" in mcp_servers` | a repo-access drift fails |
| `test_frozen` (`:169`) | assigning `d.name="Rewritten"` raises `(AttributeError, TypeError)` | dropping `frozen=True` fails |

`tests/test_skill_manifest.py` guards the **SKILL.md frontmatter** under `cross-cutting/skills/` (not the contracts dataclasses, but the same drift-prevention philosophy applied to the skill side of the contract). Key checks: every `SKILL.md` has parseable, non-empty frontmatter (`:74`); has `name` + `description` (`:81`); optional `output_schemas` is a list of `{path, schema}` string mappings when present (`:98`); wired schema paths resolve on disk (`:136`, regression guard so a rename doesn't silently no-op validation); a large `required_wiring` map (`:168-231`) asserts ~40 critical-path skills declare specific `output_schemas` `path` values (`:160`); `redundancy-analyzer` wires BOTH `redundancy-matrix.json` (cross-app) and `intra-app-redundancy.json` (intra-app) scopes (`:251`); `sequencer` wires BOTH `wave-plan.json` and `wave-plan-validation.json` (`:279`). ⚠️ These pin the skill→artifact contract that the assembly-line YAML `skills:` + `outputs.artifacts:` reference; drift on either side breaks here. (This test belongs primarily to the skills layer — see the skills regen doc — but is enumerated here because it lives in `olympus-contracts/tests/` and runs in the contracts package's `pytest`.)

---

## 7. Index — per-line step contract files

Each file below reproduces, field-by-field, the corresponding `olympus_contracts/data/assembly-lines/*.yaml` (every step's `id`, `label`, `kind`, `scope`, `sequence`, `purpose`, `skills`, `agent_role`, `role`, `inputs`, `outputs`, `agent_contract`, `parallel_with`, `gate`, `retry_policy`, `progress_pct`, `progress_weight`, `artifact_filename`, `summary`) plus the line header fields.

**Step counts are the AUTHORITATIVE counts produced by the loader** (`len(LineContract.steps)` = number of direct children under the YAML `steps:` key), not a naive grep of `- id:` lines (which over-counts because `gates:` entries and nested keys also use `id:`).

| # | Line (`name`) | YAML file | Regen step file | Steps | Agent steps | Evidence (card) steps | Gates |
|---|---|---|---|---|---|---|---|
| 1 | Discovery | `discovery.yaml` | `regen/06-contracts/discovery.md` | **14** | 11 | 10 | G-DC |
| 2 | Rationalization | `rationalization.yaml` | `regen/06-contracts/rationalization-steps.md` | **21** | 14 | 14 | G-RR, G-DA |
| 3 | Architecture | `architecture.yaml` | `regen/06-contracts/architecture.md` | **19** | 13 | 13 | G-02 |
| 4 | Data | `data.yaml` | `regen/06-contracts/data.md` | **13** | 7 | 7 | G-DT |
| 5 | Modernization | `modernization.yaml` | `regen/06-contracts/modernization.md` | **33** | 15 | 15 | G-04a, G-04b, G-04c |
| 6 | Disposition Execution | `disposition-execution.yaml` | `regen/06-contracts/disposition-execution.md` | **13** | 4 | 4 | G-DE-1, G-DE-2 |
| 7 | Validation | `validation.yaml` | `regen/06-contracts/validation.md` | **20** | 8 | 8 | G-V1, G-V2, G-V3 |
| 8 | Deployment | `deployment.yaml` | `regen/06-contracts/deployment.md` | **18** | 8 | 8 | G-DP-1, G-DP-2 |
| 9 | Sustainment | `sustainment.yaml` | `regen/06-contracts/sustainment.md` | **8** | 5 | 5 | (none) |
| 10 | Governance | `governance.yaml` | `regen/06-contracts/governance.md` | **10** | 6 | 6 | (none) |
| 11 | **Build** (NEW) | `build.yaml` | `regen/06-contracts/build-steps.md` | **15** | 6 | 3 | G-NEW-1, G-NEW-2, G-NEW-3 |
| | **TOTAL** | | | **184** | 97 | 93 | 18 distinct gate ids |

⚠️ **CHANGED AT HEAD — Build added (row 11).** Totals rose from 169/91/90 (10 lines) to **184/97/93** (11 lines). Distinct gate ids rose from 15 to **18** (the 15 standard `GateType` codes + Build's 3 line-local `G-NEW-1/2/3`). Step-file table order is by registration #; the *loader* order (§5.8) is by name, where Build sorts 2nd.

Notes:
- "Evidence (card) steps" = `LineContract.evidence_steps()` (agent steps with `role in (analysis, rollup)`). Two lines now differ from agent-step count: **Discovery** (10 vs 11, `gate-readiness-check` is `role: pre-review`) and **Build** (3 vs 6 — its THREE pre-review readiness checks `spec-/design-/generate-gate-readiness-check` are excluded). For all other lines `agent_steps == evidence_steps`.
- The **15** distinct standard gate ids are exactly the 15 `GateType` values (§1.6): G-RR/G-DA → Rationalization; G-04a/b/c → Modernization; G-V1/2/3 → Validation; G-DP-1/2 → Deployment; G-DE-1/2 → Disposition Execution; G-DC → Discovery; G-02 → Architecture; G-DT → Data — matching `GATE_ASSEMBLY_LINES` (§1.6.3). ⚠️ Build's **G-NEW-1/2/3** are the 16th–18th distinct gate ids and are NOT in `GateType` / `GATE_ASSEMBLY_LINES` — they exist only in `build.yaml`.

---

## 8. Cross-reference summary for the regenerator

- **Enums → wire format:** `StrEnum`/`IntEnum` base types are non-negotiable for Temporal round-trip (§1.1, §1.2). Gate codes (§1.6) and line names (§1.8) are DB/URL/Git identifiers — character-exact.
- **Signals → no `__future__` import** (§2 GOTCHA). Plain dataclasses, legacy `typing` generics, `Any` re-exported.
- **Errors → retryability by class name** registered in `temporal/olympus_workflows/retry_policies.py:GIT_MERGE_RETRY_POLICY.non_retryable_error_types` (§4.1). Only `MergeDivergenceUnresolved` is retryable.
- **Loader → frozen+slots dataclasses, lru_cache(1), 6 load-time invariants** (§5.6), YAML is the single source of truth.
- **Anti-drift → cluster detector (≥5 quoted step-id literals / 10 lines)** in scanned app code (§6) + the exhaustive Discovery contract pins in `test_assembly_lines.py` (§6.4).
