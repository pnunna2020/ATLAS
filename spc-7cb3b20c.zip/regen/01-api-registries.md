# Regeneration Spec — Phase 8 API: Registries Router (6 Extension Points)

**Source of truth:** `/Users/pnunna/Documents/GitHub/foundry/olympus-api/src/routers/registries.py` (874 lines).
**Mount:** `app.include_router(registries_router)` at `olympus-api/src/main.py:184` (import at `:50`). No extra prefix applied at mount — the router carries its own prefix.
**Router object:** `registries.py:57` — `APIRouter(prefix="/api/v1/registries", tags=["registries"])`.
**Endpoint count:** 32. (1 index + 6 registries × {list, get, upsert, delete, version-bump} = 30, plus `scoring-dimensions/replace-all` = 31… see ⚠️ COUNT note below — actual total is **32** because scoring has 6 routes not 5.)

> ⚠️ **COUNT GOTCHA:** Five of the six registries have exactly 5 routes (list, get/{id}, post, delete/{id}, post/{id}/version-bump). **Scoring-dimensions has 6** (adds `POST /scoring-dimensions/replace-all`). Index = 1. Total = `1 + (5×5) + 6 = 32`. Per-registry route counts at the bottom of this file.

---

## 0. Cross-cutting behavior (applies to ALL endpoints)

### 0.1 Auth dependency

- Imports: `from src.middleware.auth import CurrentUser, require_role` (`registries.py:52`); `from src.models.common import RBACRole` (`:53`).
- **All write endpoints** (POST upsert, POST replace-all, DELETE, POST version-bump) carry the dependency parameter:
  ```python
  _user: Annotated[CurrentUser, Depends(require_role(RBACRole.PORTFOLIO_ADMIN))]
  ```
- **All read endpoints** (GET list, GET {id}, and `GET ""` index) have **NO auth dependency** — open to any caller, including unauthenticated. (Docstring `registries.py:12-14`: "Reads are open to every authenticated caller — the dashboards and extensibility audits are viewer-safe." In practice no `get_current_user` dependency is attached, so reads are fully anonymous.)
- `RBACRole.PORTFOLIO_ADMIN == "portfolio_admin"` (`olympus-api/src/models/common.py:48`).

`require_role` (defined `olympus-api/src/middleware/auth.py:106-119`) returns an async dependency `_check`:
```
async _check(user = Depends(get_current_user)):
    if not user.has_role(*required_roles):   # has_role = any(r in user.roles)
        raise HTTPException(403, detail=f"Requires one of: {[r.value for r in required_roles]}")
        # i.e. detail == "Requires one of: ['portfolio_admin']"
    return user
```

`get_current_user` (`auth.py:52-103`) behavior — the auth chain that runs BEFORE `require_role`:
```
if env DEV_AUTH_BYPASS == "true":
    return CurrentUser(sub="local-dev", roles=list(RBACRole) /*all 8 roles*/, claims={...,"dev_bypass":True})
token = bearer token from "Authorization: Bearer <t>" header, else None
if token is None: raise HTTPException(401, "Missing authorization token")
try:
    options = {}
    if env AUTH_SKIP_VERIFICATION (default "true"):
        options = {verify_signature:False, verify_exp:False, verify_aud:False}
    payload = jwt.decode(token, JWT_SECRET(default "olympus-dev-secret"), algorithms=[JWT_ALGORITHM(default "HS256")], options=options)
except JWTError: raise HTTPException(401, "Invalid or expired token")
sub = payload.get("sub","anonymous")
roles = [RBACRole(r) for r in payload.get("roles",[]) if valid]   # unknown roles logged + dropped
if not roles: roles = [RBACRole.VIEWER]
return CurrentUser(sub, roles, payload)
```
⚠️ **AUTH GOTCHA:** Defaults make auth permissive in dev: `AUTH_SKIP_VERIFICATION=true` (signatures NOT checked) and `DEV_AUTH_BYPASS=true` grants ALL roles with no token. A regenerated impl MUST preserve these env-var names and defaults.

⚠️ **STATUS-CODE ORDERING GOTCHA:** For write endpoints, FastAPI resolves the path/body and the `Depends(require_role(...))` dependency. Order of failures a client can observe: 401 (missing/invalid token) or 403 (wrong role) come from the dependency; 422 (request body validation) comes from Pydantic. FastAPI runs request validation and dependency resolution such that **body-validation (422) generally fires before the dependency body executes** for malformed bodies, but a missing token still yields 401. Preserve all three codes.

### 0.2 Registry backing stores (in-process singletons)

Imported at `registries.py:31-49` from `olympus_workflows.registries`:
`ANALYSIS_PASS_REGISTRY, ASSEMBLY_LINE_REGISTRY, DISPOSITION_REGISTRY, GATE_PROVIDER_REGISTRY, SCORING_DIMENSION_REGISTRY, SKILL_COMPOSITION_REGISTRY` plus entity classes `AnalysisPass, AssemblyLine, DispositionStrategy, GateProvider, ScoringDimensionEntry, SkillComposition`, errors `CircularDependencyError, EntityHasDependents, EntityNotFound, RegistryValidationError`, and `StepSpec` (`from olympus_workflows.registries.disposition import StepSpec`, `:49`).

⚠️ **PERSISTENCE GOTCHA (`registries.py:18-22`):** Writes are **in-process only** — they do NOT persist to profile YAML on disk. The registries are module-level singletons populated at import + during profile activation (`main.py:104-108` calls `activate_profile()` in the lifespan before any request is served). Restart / re-import resets to defaults+profile. Each registry default-populates at import (see entity sections). `SKILL_COMPOSITION_REGISTRY` starts **EMPTY** (no default population in `skill_composition.py`); the others ship defaults.

### 0.3 Error translation helper — `_translate_registry_error` (`registries.py:266-275`)

Used by every write handler that wraps registry calls in `try/except Exception`:
```
def _translate_registry_error(exc) -> HTTPException:
    if isinstance(exc, EntityNotFound):            return HTTPException(404, str(exc))
    if isinstance(exc, RegistryValidationError):   return HTTPException(422, str(exc))
    if isinstance(exc, CircularDependencyError):   return HTTPException(422, str(exc))
    if isinstance(exc, EntityHasDependents):       return HTTPException(409, str(exc))
    return HTTPException(500, str(exc))            # fallthrough — any other exception → 500
```
⚠️ Note `EntityNotFound` subclasses `KeyError` AND `RegistryError`. `isinstance` order above matters only that NotFound is checked first; it is. `CircularDependencyError` is **not** exported in the handler import list explicitly used in isinstance? — it IS imported (`registries.py:40`). All four are real classes from `engine.py`.

### 0.4 Engine primitives (shared `Registry[T]`, `temporal/olympus_workflows/registries/engine.py`)

Every concrete registry wraps a generic `Registry[T]` (`engine.py:181-454`). Behaviorally relevant methods the API depends on:

**`register(entity, *, overwrite=True, version=None)`** (`engine.py:256-303`) — concrete registries call `.upsert()` which is `register(overwrite=True)`:
```
self.validate(entity)                     # runs all validators; wraps non-RegistryValidationError in RegistryValidationError
key = id_getter(entity) normalized        # lower() unless case_sensitive
if not overwrite and key in entities: raise EntityExists
previous = entities.get(key); previous_version = versions.get(key)
entities[key] = entity                    # stage
try: _assert_no_cycle(key)                # DFS over depends_on
except CircularDependencyError:
    rollback (restore previous or del); raise
if version is not None: versions[key] = VersionRecord(version=version)
elif previous_version is None: versions[key] = VersionRecord()   # fresh 1.0.0
# else keep existing version across overwrite  ⚠️ overwrite PRESERVES version
```
⚠️ **VERSION-PRESERVE GOTCHA:** Re-`POST`ing (upsert) an existing entity REPLACES its data but KEEPS its prior VersionRecord (version + history). Only first insert seeds `1.0.0`. So upsert never resets version.

**`get(entity_id)`** (`engine.py:309-316`): returns entity or raises `EntityNotFound(f"No entity registered for {id!r}. Known: {...}")`.

**`delete(entity_id)`** (`engine.py:333-354`):
```
key = normalize(id)
if key not in entities: raise EntityNotFound
dependents = self.dependents(id)              # any other entity whose depends_on contains id
if dependents: raise EntityHasDependents(f"Cannot delete {id!r}: depended on by {sorted}")
removed = entities.pop(key); versions.pop(key, None); return removed
```

**`version(entity_id)`** (`engine.py:365-371`): lazily creates a `VersionRecord()` (1.0.0) if entity exists but has no record; raises `EntityNotFound` if entity absent. Returns the version string.

**`bump_version(entity_id, kind)`** (`engine.py:377-387`):
```
key = normalize(id)
if key not in entities: raise EntityNotFound
record = versions.setdefault(key, VersionRecord())
return record.bump(kind)   # bump_semver then append to history
```
`bump_semver(current, kind)` (`engine.py:126-141`): major→`{M+1}.0.0`, minor→`{M}.{m+1}.0`, patch→`{M}.{m}.{p+1}`; any other kind raises `ValueError` (→ caught by `except Exception` → 500). ⚠️ But the request model (`VersionBumpRequest.kind`) is regex-constrained `^(major|minor|patch)$` so a bad kind yields **422 from Pydantic** before the handler runs — the `ValueError`→500 path is unreachable via the API for `kind`.
`VersionRecord` (`engine.py:144-165`): `version="1.0.0"`, `history: list[str]` (append-only; seeded to `[version]` in `__post_init__`). `parse_semver` validates eagerly.

**Cycle detection** `_assert_no_cycle` (`engine.py:416-438`): DFS over `dep_getter(entity)` using `visiting`/`visited` sets; raises `CircularDependencyError(f"Circular dependency detected involving {key!r}")`. Only Assembly Lines and Analysis Passes have non-trivial `dep_getter` (`depends_on`); disposition/scoring/gate/skill-composition have empty dep extractors (no cycles possible).

**`dependents(entity_id)`** (`engine.py:403-414`): scans all other entities; collects ids whose `dep_getter` (normalized) contains the needle. Drives DELETE's 409.

Case sensitivity: all registries normalize ids to lowercase **except** Scoring Dimensions (`case_sensitive=True`, `scoring_dimension.py:79`). ⚠️ So `GET /assembly-lines/DISCOVERY` resolves the same as `discovery`, but `GET /scoring-dimensions/Code-Quality` ≠ `code-quality`.

---

## 1. Shared request/response models

Defined `registries.py:65-81`:

**`VersionBumpRequest`** (`:65-70`) — request body for all 6 version-bump endpoints:
| field | type | constraint |
|---|---|---|
| `kind` | `str` | required; `pattern="^(major|minor|patch)$"`; description "Semver component to bump: major | minor | patch." |

**`VersionBumpResponse`** (`:73-75`) — response for all 6 version-bump endpoints:
| field | type |
|---|---|
| `id` | `str` |
| `version` | `str` |

**`DeleteResponse`** (`:78-80`) — response for all 6 delete endpoints:
| field | type | default |
|---|---|---|
| `id` | `str` | — |
| `deleted` | `bool` | `True` |

**`RegistryIndexEntry`** (`:283-286`) — element of index response:
| field | type |
|---|---|
| `name` | `str` |
| `count` | `int` |
| `endpoint` | `str` |

---

## 2. Entity body models (request AND response per registry)

Each `*Body` is used both as the POST request body and the GET/POST response model. Defaults shown are Pydantic field defaults (these apply to inbound requests when fields are omitted).

### 2.1 `AssemblyLineBody` (`registries.py:88-98`)
| field | type | default |
|---|---|---|
| `name` | `str` | required |
| `description` | `str` | `""` |
| `steps` | `list[str]` | `[]` |
| `gates` | `list[str]` | `[]` |
| `depends_on` | `list[str]` | `[]` |
| `inputs` | `list[str]` | `[]` |
| `outputs` | `list[str]` | `[]` |
| `mode` | `str` | `"per-app"` |
| `metadata` | `dict[str, Any]` | `{}` |
| `version` | `str` | `"1.0.0"` |

⚠️ `version` is accepted on POST but IGNORED — `upsert_assembly_line` constructs `AssemblyLine(...)` without passing version into `register` (no `version=` arg), so the registry seeds 1.0.0 on first insert / keeps existing on overwrite. The response `version` is read back via `ASSEMBLY_LINE_REGISTRY.version(name)`, NOT echoed from request.

### 2.2 `DispositionStrategyBody` (`registries.py:101-110`)
| field | type | default |
|---|---|---|
| `label` | `str` | required |
| `workflow` | `str` | `"DispositionWorkflow"` |
| `required_gates` | `list[str]` | `[]` |
| `has_gate2` | `bool` | `True` |
| `max_rework_iterations` | `int` | `3` |
| `pre_gate1_steps` | `list[dict[str, str]]` | `[]` |
| `post_gate1_steps` | `list[dict[str, str]]` | `[]` |
| `metadata` | `dict[str, Any]` | `{}` |
| `version` | `str` | `"1.0.0"` |

Step dict shape (each element of pre/post lists): `{"step": str, "skill_id": str, "artifact": str}`. ⚠️ On response, `required_gates` is `effective_required_gates()` (see 4.2), NOT the raw stored field.

### 2.3 `AnalysisPassBody` (`registries.py:113-122`)
| field | type | default |
|---|---|---|
| `name` | `str` | required |
| `skill_id` | `str` | required |
| `artifact` | `str` | required |
| `depends_on` | `list[str]` | `[]` |
| `pass_number` | `int` | `0` |
| `synthesis_rule` | `str` | `"synthesis"` |
| `parallel_with` | `list[str]` | `[]` |
| `metadata` | `dict[str, Any]` | `{}` |
| `version` | `str` | `"1.0.0"` |

### 2.4 `ScoringDimensionBody` (`registries.py:125-134`)
| field | type | default |
|---|---|---|
| `name` | `str` | required |
| `weight` | `float` | required |
| `default_weight` | `float | None` | `None` |
| `rationale` | `str` | `""` |
| `data_source` | `str` | `""` |
| `scoring_function` | `str` | `""` |
| `bounds` | `tuple[float, float]` | `(0.0, 1.0)` |
| `metadata` | `dict[str, Any]` | `{}` |
| `version` | `str` | `"1.0.0"` |

### 2.5 `GateProviderBody` (`registries.py:137-144`)
| field | type | default |
|---|---|---|
| `id` | `str` | required |
| `description` | `str` | `""` |
| `supports_automated` | `bool` | `False` |
| `requires_human` | `bool` | `True` |
| `implemented` | `bool` | `True` |
| `metadata` | `dict[str, Any]` | `{}` |
| `version` | `str` | `"1.0.0"` |

⚠️ Validator (`gate_provider.py:275-285`) rejects `supports_automated AND requires_human` both True → `ValueError` → wrapped `RegistryValidationError` → **422**.

### 2.6 `SkillCompositionBody` (`registries.py:147-155`)
| field | type | default |
|---|---|---|
| `name` | `str` | required |
| `skills` | `list[str]` | required |
| `mode` | `str` | `"sequential"` |
| `description` | `str` | `""` |
| `conditions` | `dict[str, str]` | `{}` |
| `variant_selectors` | `dict[str, str]` | `{}` |
| `metadata` | `dict[str, Any]` | `{}` |
| `version` | `str` | `"1.0.0"` |

⚠️ Validator (`skill_composition.py:83-101`): `mode` must be in `{sequential, parallel, conditional}`; `skills` non-empty; if `mode=="conditional"`, EVERY skill must have a `conditions` entry — else `ValueError` → 422.

### 2.7 `ScoringBulkReplaceRequest` (`registries.py:641-644`) — request body for replace-all only
| field | type |
|---|---|
| `dimensions` | `list[ScoringDimensionBody]` |
Docstring: "Atomic replacement of the full scoring-dimension set (weights must sum to 1.0)."

---

## 3. Serialization helpers (entity → body)

These produce the response objects. Each takes `(entity, version: str)`. Defined `registries.py:163-258`. Key non-obvious mappings:

- `_assembly_line_to_body` (`:163-175`): tuples → lists, `metadata` copied, `version` injected.
- `_disposition_to_body` (`:178-197`): `required_gates = list(strategy.effective_required_gates())` ⚠️ (computed, see 4.2); `pre_gate1_steps`/`post_gate1_steps` via inner `_step_rows` → `[{"step","skill_id","artifact"}, ...]`.
- `_analysis_pass_to_body` (`:200-213`): straightforward tuple→list.
- `_scoring_to_body` (`:216-229`): `bounds = tuple(dim.bounds)`; passes `default_weight` through.
- `_gate_provider_to_body` (`:232-243`): passes `supports_automated`, `requires_human`, `implemented`.
- `_composition_to_body` (`:246-258`): `conditions`, `variant_selectors`, `metadata` all dict-copied.

---

## 4. ENDPOINTS (in router-mount/source order)

### 4.0 Index

#### **GET `/api/v1/registries`** — `list_registries` (`registries.py:289-323`)
- Path: `""` appended to prefix → `/api/v1/registries`.
- Auth: **none**.
- Request: none.
- Response: `list[RegistryIndexEntry]`. Status 200.
- Logic (returns a FIXED-ORDER list of 6 entries; order is load-bearing for any UI):
  ```
  [ {name:"assembly-lines",        count:len(ASSEMBLY_LINE_REGISTRY.list_all()),    endpoint:"/api/v1/registries/assembly-lines"},
    {name:"disposition-strategies",count:len(DISPOSITION_REGISTRY.list_all()),      endpoint:"/api/v1/registries/disposition-strategies"},
    {name:"analysis-passes",       count:len(ANALYSIS_PASS_REGISTRY.list_all()),    endpoint:"/api/v1/registries/analysis-passes"},
    {name:"scoring-dimensions",    count:len(SCORING_DIMENSION_REGISTRY.list_all()),endpoint:"/api/v1/registries/scoring-dimensions"},
    {name:"gate-providers",        count:len(GATE_PROVIDER_REGISTRY.list_all()),    endpoint:"/api/v1/registries/gate-providers"},
    {name:"skill-compositions",    count:len(SKILL_COMPOSITION_REGISTRY.list_all()),endpoint:"/api/v1/registries/skill-compositions"} ]
  ```

---

### 4.1 Assembly Lines (entity `AssemblyLine`, `assembly_line.py:41-60`; registry case-insensitive; default-populated from contract yaml at import, `assembly_line.py:156-187`)

Entity fields: `name`, `description=""`, `steps=()`, `gates=()`, `depends_on=()`, `inputs=()`, `outputs=()`, `mode="per-app"`, `metadata={}`.
Validator (`assembly_line.py:75-86`): name non-blank; `mode in {per-app, per-wave, per-target-app, continuous}`; `depends_on` must be distinct (no dupes).

#### **GET `/api/v1/registries/assembly-lines`** — `list_assembly_lines` (`:331-336`)
- Auth: none. Request: none. Response: `list[AssemblyLineBody]`. Status 200.
- Logic: `[_assembly_line_to_body(line, ASSEMBLY_LINE_REGISTRY.version(line.name)) for line in ASSEMBLY_LINE_REGISTRY.list_all()]` (insertion order).

#### **GET `/api/v1/registries/assembly-lines/{name}`** — `get_assembly_line` (`:339-345`)
- Auth: none. Path param `name: str`. Response: `AssemblyLineBody`. Status 200 / 404.
- Logic:
  ```
  try: line = ASSEMBLY_LINE_REGISTRY.get(name)        # case-insensitive
  except EntityNotFound as exc: raise _translate_registry_error(exc)   # → 404
  return _assembly_line_to_body(line, ASSEMBLY_LINE_REGISTRY.version(line.name))
  ```

#### **POST `/api/v1/registries/assembly-lines`** — `upsert_assembly_line` (`:348-372`)
- Auth: `require_role(PORTFOLIO_ADMIN)`. Request body: `AssemblyLineBody`. Response: `AssemblyLineBody`. **Status 201** (`status.HTTP_201_CREATED`) / 422 / 409 / 500.
- Logic:
  ```
  line = AssemblyLine(name, description, steps=tuple(body.steps), gates=tuple(body.gates),
                      depends_on=tuple(body.depends_on), inputs=tuple(body.inputs),
                      outputs=tuple(body.outputs), mode=body.mode, metadata=dict(body.metadata))
  try: ASSEMBLY_LINE_REGISTRY.register(line)         # = upsert(overwrite=True): validate, stage, cycle-check
  except Exception as exc: raise _translate_registry_error(exc)
  return _assembly_line_to_body(line, ASSEMBLY_LINE_REGISTRY.version(body.name))
  ```
  ⚠️ `body.version` ignored. Validation failure (bad mode / dup depends_on) → `RegistryValidationError` → 422. Cycle → `CircularDependencyError` → 422.

#### **DELETE `/api/v1/registries/assembly-lines/{name}`** — `delete_assembly_line` (`:375-384`)
- Auth: `require_role(PORTFOLIO_ADMIN)`. Path param `name`. Response: `DeleteResponse`. Status 200 / 404 / 409 / 500.
- Logic:
  ```
  try: ASSEMBLY_LINE_REGISTRY.delete(name)
  except Exception as exc: raise _translate_registry_error(exc)   # EntityNotFound→404, EntityHasDependents→409
  return DeleteResponse(id=name)   # {"id": name, "deleted": True}
  ```
  ⚠️ 409 if any other line declares `name` in its `depends_on`.

#### **POST `/api/v1/registries/assembly-lines/{name}/version-bump`** — `bump_assembly_line_version` (`:387-400`)
- Auth: `require_role(PORTFOLIO_ADMIN)`. Path param `name`. Body: `VersionBumpRequest`. Response: `VersionBumpResponse`. Status 200 / 404 / 422(bad kind via regex) / 500.
- Logic:
  ```
  try: version = ASSEMBLY_LINE_REGISTRY.bump_version(name, body.kind)
  except Exception as exc: raise _translate_registry_error(exc)   # EntityNotFound→404
  return VersionBumpResponse(id=name, version=version)
  ```

---

### 4.2 Disposition Strategies (entity `DispositionStrategy`, `disposition.py:66-149`; case-insensitive; default-populated with 5 strategies — Retire, Retain, Replace, Replatform, Consolidate — at import, `disposition.py:465-491`)

Entity fields: `label`, `pre_gate1_steps: tuple[StepSpec,...]`, `post_gate1_steps: tuple[StepSpec,...]`, `has_gate2: bool`, `max_rework_iterations=3`, `workflow="DispositionWorkflow"`, `required_gates=()`, `metadata={}`. `StepSpec`= `{step, skill_id, artifact}` (`disposition.py:52-63`).
Validator (`disposition.py:166-176`): label non-blank; `max_rework_iterations >= 0`; `workflow` non-blank.

**`effective_required_gates()`** (`disposition.py:133-149`) — used in EVERY disposition response:
```
if self.required_gates:        # explicitly populated → wins verbatim
    return self.required_gates
gates = []
if self.has_gate1: gates.append("G-DE-1")   # has_gate1 is a @property == True always (disposition.py:102-111)
if self.has_gate2: gates.append("G-DE-2")
return tuple(gates)
```
⚠️ So a default Retire (required_gates empty, has_gate2=True) reports `["G-DE-1","G-DE-2"]`; Retain (has_gate2=False) reports `["G-DE-1"]`. If a POST sets `required_gates` explicitly, that list is echoed verbatim instead.

Helper `_steps_from_rows(rows)` (`:408-424`) — builds `tuple[StepSpec,...]` from list-of-dicts:
```
for row in rows:
    try: out.append(StepSpec(step=row["step"], skill_id=row["skill_id"], artifact=row["artifact"]))
    except KeyError as exc: raise HTTPException(422, f"Disposition step missing key: {exc}")
return tuple(out)
```
⚠️ Missing any of the 3 keys in a step dict → **422** (raised directly, not via `_translate_registry_error`).

#### **GET `/api/v1/registries/disposition-strategies`** — `list_dispositions` (`:427-434`)
- Auth: none. Response: `list[DispositionStrategyBody]`. Status 200.
- Logic: `[_disposition_to_body(s, DISPOSITION_REGISTRY.version(s.label)) for s in DISPOSITION_REGISTRY.list_all()]`.

#### **GET `/api/v1/registries/disposition-strategies/{label}`** — `get_disposition` (`:437-448`)
- Auth: none. Path param `label`. Response: `DispositionStrategyBody`. Status 200 / 404.
- Logic: `get(label)` (case-insensitive); `EntityNotFound`→404; else `_disposition_to_body(strategy, version(strategy.label))`. ⚠️ Registry's `get` raises `UnknownDispositionError` which subclasses `EntityNotFound` → 404.

#### **POST `/api/v1/registries/disposition-strategies`** — `upsert_disposition` (`:451-476`)
- Auth: `require_role(PORTFOLIO_ADMIN)`. Body: `DispositionStrategyBody`. Response: `DispositionStrategyBody`. **Status 201** / 422 / 500.
- Logic:
  ```
  strategy = DispositionStrategy(
      label=body.label,
      pre_gate1_steps=_steps_from_rows(body.pre_gate1_steps),    # may raise 422
      post_gate1_steps=_steps_from_rows(body.post_gate1_steps),  # may raise 422
      has_gate2=body.has_gate2,
      max_rework_iterations=body.max_rework_iterations,
      workflow=body.workflow,
      required_gates=tuple(body.required_gates),
      metadata=dict(body.metadata))
  try: DISPOSITION_REGISTRY.register(strategy)
  except Exception as exc: raise _translate_registry_error(exc)
  return _disposition_to_body(strategy, DISPOSITION_REGISTRY.version(body.label))
  ```
  ⚠️ `_steps_from_rows` runs BEFORE registry register, so a malformed step dict 422s before validation/registration.

#### **DELETE `/api/v1/registries/disposition-strategies/{label}`** — `delete_disposition` (`:479-490`)
- Auth: `require_role(PORTFOLIO_ADMIN)`. Path param `label`. Response: `DeleteResponse`. Status 200 / 404 / 500.
- Logic: `delete(label)`; `except Exception` → `_translate_registry_error` (NotFound→404). No dependents possible (empty dep extractor) → 409 unreachable. `DeleteResponse(id=label)`.

#### **POST `/api/v1/registries/disposition-strategies/{label}/version-bump`** — `bump_disposition_version` (`:493-506`)
- Auth: `require_role(PORTFOLIO_ADMIN)`. Path param `label`. Body: `VersionBumpRequest`. Response: `VersionBumpResponse`. Status 200 / 404 / 500.
- Logic: `version = DISPOSITION_REGISTRY.bump_version(label, body.kind)`; `except Exception`→404 on NotFound; `VersionBumpResponse(id=label, version=version)`.

---

### 4.3 Analysis Passes (entity `AnalysisPass`, `analysis_pass.py:34-50`; case-insensitive; default-populated from Discovery contract at import, `analysis_pass.py:116-171`)

Entity fields: `name`, `skill_id`, `artifact`, `depends_on=()`, `pass_number=0`, `synthesis_rule="synthesis"`, `parallel_with=()`, `metadata={}`.
Validator (`analysis_pass.py:57-67`): name/skill_id/artifact non-blank; `pass_number >= 0`. Has `depends_on` → cycle detection active.

#### **GET `/api/v1/registries/analysis-passes`** — `list_analysis_passes` (`:514-519`)
- Auth: none. Response: `list[AnalysisPassBody]`. Status 200.
- Logic: `[_analysis_pass_to_body(p, ANALYSIS_PASS_REGISTRY.version(p.name)) for p in ANALYSIS_PASS_REGISTRY.list_all()]`.

#### **GET `/api/v1/registries/analysis-passes/{name}`** — `get_analysis_pass` (`:522-530`)
- Auth: none. Path param `name`. Response: `AnalysisPassBody`. Status 200 / 404.
- Logic: `get(name)`; `EntityNotFound`→404; `_analysis_pass_to_body(pass_, version(pass_.name))`.

#### **POST `/api/v1/registries/analysis-passes`** — `upsert_analysis_pass` (`:533-558`)
- Auth: `require_role(PORTFOLIO_ADMIN)`. Body: `AnalysisPassBody`. Response: `AnalysisPassBody`. **Status 201** / 422 / 500.
- Logic:
  ```
  pass_ = AnalysisPass(name, skill_id, artifact, depends_on=tuple(body.depends_on),
                       pass_number=body.pass_number, synthesis_rule=body.synthesis_rule,
                       parallel_with=tuple(body.parallel_with), metadata=dict(body.metadata))
  try: ANALYSIS_PASS_REGISTRY.register(pass_)
  except Exception as exc: raise _translate_registry_error(exc)
  return _analysis_pass_to_body(pass_, ANALYSIS_PASS_REGISTRY.version(body.name))
  ```
  ⚠️ Self-referential or back-edge `depends_on` → `CircularDependencyError` → 422.

#### **DELETE `/api/v1/registries/analysis-passes/{name}`** — `delete_analysis_pass` (`:561-570`)
- Auth: `require_role(PORTFOLIO_ADMIN)`. Path param `name`. Response: `DeleteResponse`. Status 200 / 404 / 409 / 500.
- Logic: `delete(name)`; `except Exception`→`_translate_registry_error` (NotFound→404, **HasDependents→409** if another pass depends on it). `DeleteResponse(id=name)`.

#### **POST `/api/v1/registries/analysis-passes/{name}/version-bump`** — `bump_analysis_pass_version` (`:573-586`)
- Auth: `require_role(PORTFOLIO_ADMIN)`. Path param `name`. Body: `VersionBumpRequest`. Response: `VersionBumpResponse`. Status 200 / 404 / 500.
- Logic: `version = ANALYSIS_PASS_REGISTRY.bump_version(name, body.kind)`; `except Exception`→404; `VersionBumpResponse(id=name, version=version)`.

---

### 4.4 Scoring Dimensions (entity `ScoringDimensionEntry`, `scoring_dimension.py:31-48`; **CASE-SENSITIVE**; default-populated with 6 dimensions via `replace_all` at import, `scoring_dimension.py:154-205`) — **6 ROUTES**

Entity fields: `name`, `weight: float`, `default_weight: float|None=None`, `rationale=""`, `data_source=""`, `scoring_function=""`, `bounds=(0.0,1.0)`, `metadata={}`.
Validator (`scoring_dimension.py:51-64`): name non-blank; `weight >= 0`; `weight <= 1.0 + 1e-6`; `bounds.low <= bounds.high`.
Default dims (sum=1.0): code-quality 0.20, test-coverage 0.15, security-posture 0.20, documentation 0.10, dependency-currency 0.15, architecture-clarity 0.20.

⚠️ **NOTE:** This registry's `get()` returns `None` instead of raising (`scoring_dimension.py:108-112`), and `delete()` raises **`KeyError`** not `EntityNotFound` (`:120-124`). The handlers account for this with bespoke error handling (below) — they do NOT uniformly use `_translate_registry_error`.

#### **GET `/api/v1/registries/scoring-dimensions`** — `list_scoring_dimensions` (`:594-599`)
- Auth: none. Response: `list[ScoringDimensionBody]`. Status 200.
- Logic: `[_scoring_to_body(d, SCORING_DIMENSION_REGISTRY.version(d.name)) for d in SCORING_DIMENSION_REGISTRY.list_all()]`.

#### **GET `/api/v1/registries/scoring-dimensions/{name}`** — `get_scoring_dimension` (`:602-612`)
- Auth: none. Path param `name`. Response: `ScoringDimensionBody`. Status 200 / 404.
- Logic (bespoke — registry returns None):
  ```
  dim = SCORING_DIMENSION_REGISTRY.get(name)     # returns None if absent (no raise)
  if dim is None: raise HTTPException(404, f"No scoring dimension registered for {name!r}")
  return _scoring_to_body(dim, SCORING_DIMENSION_REGISTRY.version(name))
  ```
  ⚠️ CASE-SENSITIVE: `name` must match exactly.

#### **POST `/api/v1/registries/scoring-dimensions`** — `upsert_scoring_dimension` (`:615-638`)
- Auth: `require_role(PORTFOLIO_ADMIN)`. Body: `ScoringDimensionBody`. Response: `ScoringDimensionBody`. **Status 201** / 422 / 500.
- Logic:
  ```
  dim = ScoringDimensionEntry(name, weight, default_weight, rationale, data_source,
                              scoring_function, bounds=tuple(body.bounds), metadata=dict(body.metadata))
  try: SCORING_DIMENSION_REGISTRY.register(dim)
  except Exception as exc: raise _translate_registry_error(exc)   # weight>1 / bounds invalid → RegistryValidationError → 422
  return _scoring_to_body(dim, SCORING_DIMENSION_REGISTRY.version(body.name))
  ```
  ⚠️ **Single-dim register does NOT enforce weight-sum=1.0** — registry intentionally allows off-total intermediate states (`scoring_dimension.py:67-74`). Sum enforcement is ONLY in `replace_all`.

#### **POST `/api/v1/registries/scoring-dimensions/replace-all`** — `replace_all_scoring_dimensions` (`:647-677`)
- Auth: `require_role(PORTFOLIO_ADMIN)`. Body: `ScoringBulkReplaceRequest` (`{dimensions: [ScoringDimensionBody]}`). Response: `list[ScoringDimensionBody]`. **Status 200** (no 201 set). 422 / 500.
- Logic:
  ```
  new_set = [ScoringDimensionEntry(name=d.name, weight=d.weight, default_weight=d.default_weight,
              rationale=d.rationale, data_source=d.data_source, scoring_function=d.scoring_function,
              bounds=tuple(d.bounds), metadata=dict(d.metadata)) for d in body.dimensions]
  try: SCORING_DIMENSION_REGISTRY.replace_all(new_set)
  except ValueError as exc: raise HTTPException(422, str(exc))         # ⚠️ weights-sum-!=1.0 → 422 here
  except Exception as exc: raise _translate_registry_error(exc)
  return [_scoring_to_body(d, SCORING_DIMENSION_REGISTRY.version(d.name)) for d in SCORING_DIMENSION_REGISTRY.list_all()]
  ```
  `replace_all` (`scoring_dimension.py:90-106`):
  ```
  total = sum(d.weight for d in dimensions)
  if not math.isclose(total, 1.0, abs_tol=1e-3): raise ValueError(f"...sum to 1.0 (got {total:.4f})")
  for d in dimensions: _validate_scoring_dimension(d)   # validate ALL before mutating
  engine.clear(); for d in dimensions: engine.upsert(d)
  ```
  ⚠️ **ATOMIC GOTCHA:** sum check + per-entry validation happen BEFORE `clear()`, so a rejected batch leaves the registry untouched. But ⚠️ `clear()` wipes existing VersionRecords — so every dimension's version resets to 1.0.0 after a successful replace-all (new upserts seed fresh records).

#### **DELETE `/api/v1/registries/scoring-dimensions/{name}`** — `delete_scoring_dimension` (`:680-691`)
- Auth: `require_role(PORTFOLIO_ADMIN)`. Path param `name`. Response: `DeleteResponse`. Status 200 / 404.
- Logic (bespoke — catches `KeyError`, NOT generic):
  ```
  try: SCORING_DIMENSION_REGISTRY.delete(name)
  except KeyError as exc: raise HTTPException(404, str(exc))
  return DeleteResponse(id=name)
  ```
  ⚠️ Registry `delete` re-raises `EntityNotFound` as `KeyError` (`scoring_dimension.py:120-124`); the handler catches `KeyError`. No dependents → no 409. ⚠️ `EntityNotFound` IS a `KeyError` subclass, so this works.

#### **POST `/api/v1/registries/scoring-dimensions/{name}/version-bump`** — `bump_scoring_dimension_version` (`:694-707`)
- Auth: `require_role(PORTFOLIO_ADMIN)`. Path param `name`. Body: `VersionBumpRequest`. Response: `VersionBumpResponse`. Status 200 / 404 / 500.
- Logic: `version = SCORING_DIMENSION_REGISTRY.bump_version(name, body.kind)`; `except Exception`→`_translate_registry_error` (EntityNotFound is a KeyError+RegistryError → 404). `VersionBumpResponse(id=name, version=version)`.

⚠️ **ROUTE-ORDER GOTCHA:** `POST /scoring-dimensions/replace-all` (`:647`) is declared BEFORE `DELETE /scoring-dimensions/{name}` (`:680`) and `POST /scoring-dimensions/{name}/version-bump` (`:694`), but it is a distinct literal path so no shadowing of `{name}`. However `replace-all` is a POST to a literal sibling of the `POST /scoring-dimensions` collection route — both are POSTs at different paths, no conflict. Preserve declaration order regardless.

---

### 4.5 Gate Providers (entity `GateProvider`, `gate_provider.py:254-268`; case-insensitive; default-populated with 4 providers at import, `gate_provider.py:368-407`: github-pr [default], automated-only, servicenow [stub], jira [stub])

Entity fields: `id`, `description=""`, `supports_automated=False`, `requires_human=True`, `metadata={}`, `implemented=True`. ⚠️ Field order in dataclass: metadata BEFORE implemented — but `GateProviderBody` lists implemented before metadata; handler constructs by keyword so order is irrelevant.
Validator (`gate_provider.py:275-285`): id non-blank; **NOT** (`supports_automated AND requires_human`) → else ValueError → 422.

#### **GET `/api/v1/registries/gate-providers`** — `list_gate_providers` (`:715-720`)
- Auth: none. Response: `list[GateProviderBody]`. Status 200.
- Logic: `[_gate_provider_to_body(p, GATE_PROVIDER_REGISTRY.version(p.id)) for p in GATE_PROVIDER_REGISTRY.list_all()]`.

#### **GET `/api/v1/registries/gate-providers/{provider_id}`** — `get_gate_provider` (`:723-731`)
- Auth: none. Path param `provider_id`. Response: `GateProviderBody`. Status 200 / 404.
- Logic: `get(provider_id)`; `EntityNotFound`→404; `_gate_provider_to_body(provider, version(provider.id))`.

#### **POST `/api/v1/registries/gate-providers`** — `upsert_gate_provider` (`:734-757`)
- Auth: `require_role(PORTFOLIO_ADMIN)`. Body: `GateProviderBody`. Response: `GateProviderBody`. **Status 201** / 422 / 500.
- Logic:
  ```
  provider = GateProvider(id=body.id, description=body.description, supports_automated=body.supports_automated,
                          requires_human=body.requires_human, implemented=body.implemented, metadata=dict(body.metadata))
  try: GATE_PROVIDER_REGISTRY.register(provider)
  except Exception as exc: raise _translate_registry_error(exc)   # both-true contradiction → 422
  return _gate_provider_to_body(provider, GATE_PROVIDER_REGISTRY.version(body.id))
  ```

#### **DELETE `/api/v1/registries/gate-providers/{provider_id}`** — `delete_gate_provider` (`:760-771`)
- Auth: `require_role(PORTFOLIO_ADMIN)`. Path param `provider_id`. Response: `DeleteResponse`. Status 200 / 404 / 500.
- Logic: `delete(provider_id)`; `except Exception`→`_translate_registry_error` (NotFound→404). `DeleteResponse(id=provider_id)`. (No dep extractor → no 409.)

#### **POST `/api/v1/registries/gate-providers/{provider_id}/version-bump`** — `bump_gate_provider_version` (`:774-787`)
- Auth: `require_role(PORTFOLIO_ADMIN)`. Path param `provider_id`. Body: `VersionBumpRequest`. Response: `VersionBumpResponse`. Status 200 / 404 / 500.
- Logic: `version = GATE_PROVIDER_REGISTRY.bump_version(provider_id, body.kind)`; `except Exception`→404; `VersionBumpResponse(id=provider_id, version=version)`.

---

### 4.6 Skill Compositions (entity `SkillComposition`, `skill_composition.py:42-71`; case-insensitive; ⚠️ **NO DEFAULT POPULATION** — registry starts EMPTY at `skill_composition.py:194`, populated only by profile activation)

Entity fields: `name`, `skills: tuple[str,...]`, `mode="sequential"`, `description=""`, `conditions={}`, `variant_selectors={}`, `metadata={}`.
Validator (`skill_composition.py:83-101`): name non-blank; `mode in {sequential, parallel, conditional}`; `skills` non-empty; conditional ⇒ every skill has a `conditions` entry. ⚠️ A skill-presence validator MAY be attached at API startup via `add_validator(make_skill_presence_validator(...))` — when a non-empty catalog is supplied it rejects compositions naming unknown skills with `RegistryValidationError` → 422 (`skill_composition.py:104-132`).

#### **GET `/api/v1/registries/skill-compositions`** — `list_skill_compositions` (`:795-800`)
- Auth: none. Response: `list[SkillCompositionBody]`. Status 200.
- Logic: `[_composition_to_body(c, SKILL_COMPOSITION_REGISTRY.version(c.name)) for c in SKILL_COMPOSITION_REGISTRY.list_all()]`.

#### **GET `/api/v1/registries/skill-compositions/{name}`** — `get_skill_composition` (`:803-813`)
- Auth: none. Path param `name`. Response: `SkillCompositionBody`. Status 200 / 404.
- Logic: `get(name)`; `EntityNotFound`→404; `_composition_to_body(comp, version(comp.name))`.

#### **POST `/api/v1/registries/skill-compositions`** — `upsert_skill_composition` (`:816-840`)
- Auth: `require_role(PORTFOLIO_ADMIN)`. Body: `SkillCompositionBody`. Response: `SkillCompositionBody`. **Status 201** / 422 / 500.
- Logic:
  ```
  comp = SkillComposition(name=body.name, skills=tuple(body.skills), mode=body.mode,
                          description=body.description, conditions=dict(body.conditions),
                          variant_selectors=dict(body.variant_selectors), metadata=dict(body.metadata))
  try: SKILL_COMPOSITION_REGISTRY.register(comp)
  except Exception as exc: raise _translate_registry_error(exc)   # bad mode / empty skills / missing condition / unknown skill → 422
  return _composition_to_body(comp, SKILL_COMPOSITION_REGISTRY.version(body.name))
  ```

#### **DELETE `/api/v1/registries/skill-compositions/{name}`** — `delete_skill_composition` (`:843-854`)
- Auth: `require_role(PORTFOLIO_ADMIN)`. Path param `name`. Response: `DeleteResponse`. Status 200 / 404 / 500.
- Logic: `delete(name)`; `except Exception`→`_translate_registry_error` (NotFound→404). `DeleteResponse(id=name)`.

#### **POST `/api/v1/registries/skill-compositions/{name}/version-bump`** — `bump_skill_composition_version` (`:857-870`)
- Auth: `require_role(PORTFOLIO_ADMIN)`. Path param `name`. Body: `VersionBumpRequest`. Response: `VersionBumpResponse`. Status 200 / 404 / 500.
- Logic: `version = SKILL_COMPOSITION_REGISTRY.bump_version(name, body.kind)`; `except Exception`→404; `VersionBumpResponse(id=name, version=version)`.

---

## 5. Endpoint inventory per "router" (single router; grouped by registry)

The file defines ONE `APIRouter` (`registries.py:57`). Grouping the 32 routes by registry section:

- `index = 1` (GET "")
- `assembly-lines = 5` (GET list, GET {name}, POST, DELETE {name}, POST {name}/version-bump)
- `disposition-strategies = 5`
- `analysis-passes = 5`
- `scoring-dimensions = 6` (adds POST /replace-all)
- `gate-providers = 5`
- `skill-compositions = 5`

**TOTAL = 32.**

`__all__ = ["router"]` (`registries.py:873`).

## 6. Regeneration must-preserve checklist

1. Router prefix `/api/v1/registries`, tag `registries`, mounted last-ish at `main.py:184` with no extra prefix.
2. Reads anonymous; writes gated by `Depends(require_role(RBACRole.PORTFOLIO_ADMIN))`.
3. POST upsert returns **201**; POST replace-all and POST version-bump return **200** (default). DELETE returns 200.
4. Error mapping: NotFound→404, RegistryValidation/CircularDependency→422, HasDependents→409, else→500; scoring get/delete use bespoke None-check/KeyError→404.
5. `kind` regex `^(major|minor|patch)$` on `VersionBumpRequest`.
6. Disposition response `required_gates` = `effective_required_gates()` (computed), step dicts validated by `_steps_from_rows` (missing key→422).
7. Scoring is the only case-sensitive registry; single-register skips sum check; replace-all enforces sum=1.0 (abs_tol 1e-3) atomically and resets versions.
8. `body.version` on every entity body is IGNORED on write; response version always read from registry `.version(id)`.
9. Upsert preserves prior VersionRecord across overwrite (only first insert seeds 1.0.0).
10. Index returns the 6 entries in fixed order with live `len(...list_all())` counts.

## 7. Undetermined / out-of-spec-scope

- **Default ENTITY CONTENTS** for assembly-lines and analysis-passes are loaded at import from `olympus-contracts` yaml (`assembly_line.py:156-178`, `analysis_pass.py:116-162`) — exact default rows are a contracts-package concern (Phase 1/2 spec), not this router. Disposition (5), gate-provider (4), scoring (6) defaults are reproduced inline above from their modules.
- **Skill-presence validator** attachment at API startup: `add_validator` exists (`skill_composition.py:152-161`) but whether `main.py` wires `make_skill_presence_validator` was not confirmed in the lifespan slice read (`main.py:90-135`); profile activation (`activate_profile()` at `main.py:105`) is the likely wiring point — verify in the profile-activation service spec. Behaviorally: if no catalog is wired, unknown-skill rejection is skipped (permissive).
- Whether any router-level `dependencies=[...]` or global middleware adds auth to GETs: none on this router; confirm no app-level auth middleware blankets `/api/v1/registries` GETs (none observed in the main.py slice).
