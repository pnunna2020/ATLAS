# Phase 0B — Environment & Bring-Up (ATOMIC Regeneration Spec)

> Scope: everything needed to STAND UP the Olympus stack on a clean machine that is **not** application logic.
> Goal: behavioral parity of the *environment* — same containers, same env, same volumes, same seed state, same Make targets.
> Repo root: `/Users/pnunna/Documents/GitHub/foundry`. All citations are `path:line`.
> Sources read end-to-end: `docker-compose.yml`, `Makefile`, `.env.example`, the three service `config.py` files, `db/Dockerfile`, `db/init/01-create-databases.sh`, `db/alembic.ini`, `db/alembic/env.py`, `infra/temporal/dynamicconfig.yaml`, `infra/haproxy/agent-lb.cfg`, `scripts/seed_all.py`, `scripts/seed_service_tokens.py`, `scripts/demo_smoke.py`, the 5 service Dockerfiles, `olympus-worker/src/worker.py`, `temporal/olympus_workflows/worker.py`, `olympus-worker/config/agents.yaml`, `scripts/csn-fargate/*`.

---

## 0. Top-level facts (orient before booting)

- `docker-compose.yml` defines **13 services** (`docker-compose.yml:9-494`): `postgres`, `redis`, `localstack`, `db-migrate`, `temporal-server`, `temporal-namespace-init`, `temporal-ui`, `olympus-api`, `olympus-temporal-worker`, `olympus-dashboard`, `olympus-agent-runtime`, `olympus-agent` (HAProxy LB), `olympus-mcp-server`.
- **4 named volumes** (`docker-compose.yml:496-500`): `postgres-data`, `redis-data`, `localstack-data`, `agent-workspace`.
- The compose file has **no top-level `name:`** → project name defaults to the directory name (`foundry`). Container names are therefore `foundry-<service>-<N>` (referenced literally in `db/seeds/README.md` as `foundry-postgres-1`).
- **Python base image everywhere**: `public.ecr.aws/docker/library/python:3.14-slim` (all 5 Python Dockerfiles). Dashboard uses `public.ecr.aws/docker/library/node:22-slim` (`dashboard/Dockerfile:1`).
- **Shared task queue**: `olympus-main` (worker config default `olympus-worker/src/config.py:42`; compose env `docker-compose.yml:233`).
- **Temporal namespace**: `default` (everywhere). Retention pinned to **720h (30 days)** by a one-shot init container (`docker-compose.yml:105-117`).
- **8 agent replicas** is the *Make* default (`AGENT_SCALE ?= 8`, `Makefile:28`) applied via `--scale olympus-agent=8`. The compose file's own default replica count for `olympus-agent-runtime` is **3** (`deploy.replicas: ${AGENT_REPLICAS:-3}`, `docker-compose.yml:411`). ⚠️ GOTCHA: there are **two different replica knobs and they target different services** — see §3.3.
- **Vendored wheels** (local-dev fallback for foundry-internal packages), `vendor/wheels/` — exactly 3 (`ls`): `foundry_strands_agents-0.4.0-py3-none-any.whl`, `foundry_temporal-1.3.0-py3-none-any.whl`, `olympus_contracts-0.3.0-py3-none-any.whl`. These satisfy `foundry_temporal`, `olympus_contracts`, and strands deps before pip reaches `PIP_EXTRA_INDEX_URL`.

---

## 1. docker-compose services (all 13, in file order)

For each: image/build, ports, depends_on, healthcheck, command/entrypoint, environment, volumes. Defaults shown as `${VAR:-default}` exactly as in compose.

### 1.1 `postgres` — `docker-compose.yml:13-28`
- **image**: `postgres:16`
- **ports**: `5432:5432`
- **environment**:
  - `POSTGRES_USER: ${POSTGRES_USER:-olympus}`
  - `POSTGRES_PASSWORD: ${POSTGRES_PASSWORD:-olympus_dev}`
  - `POSTGRES_DB: ${POSTGRES_DB:-postgres}` ← ⚠️ GOTCHA: the *bootstrap* DB is `postgres`, **not** `olympus`. The app DB `olympus` (plus `temporal`, `temporal_visibility`) are created by the init script (§5.1). Connecting to `olympus` before init runs fails.
- **volumes**:
  - `postgres-data:/var/lib/postgresql/data` (persistent)
  - `./db/init:/docker-entrypoint-initdb.d` (init scripts — run **only on first launch when the data dir is empty**)
- **healthcheck**: `pg_isready -U ${POSTGRES_USER:-olympus}`; interval 5s, timeout 5s, retries 10.
- **depends_on**: none.

### 1.2 `redis` — `docker-compose.yml:30-40`
- **image**: `redis:7`
- **ports**: `6379:6379`
- **volumes**: `redis-data:/data`
- **healthcheck**: `redis-cli ping`; interval 5s, timeout 3s, retries 5.
- **environment/depends_on**: none.

### 1.3 `localstack` — `docker-compose.yml:42-50`
- **image**: `localstack/localstack:latest`
- **ports**: `4566:4566`
- **environment**: `SERVICES: s3,secretsmanager`; `DEFAULT_REGION: us-east-1`
- **volumes**: `localstack-data:/var/lib/localstack`
- **healthcheck/depends_on**: none.
- ⚠️ GOTCHA: LocalStack emulates **S3 + Secrets Manager only**, **not Bedrock**. The agent runtime's inference path must reach **real** AWS Bedrock (see `.env.example:40-41` and §2). No compose service consumes `AWS_ENDPOINT_URL`; it's defined in `.env.example:35` for code that opts into LocalStack but is not wired into any `environment:` block here.

### 1.4 `db-migrate` — `docker-compose.yml:52-65`
- **build**: context `.`, dockerfile `db/Dockerfile`.
- **command/entrypoint**: image `CMD ["alembic", "upgrade", "head"]` (`db/Dockerfile:13`). One-shot.
- **environment**:
  - `DATABASE_HOST: postgres`
  - `DATABASE_PORT: "5432"`
  - `DATABASE_NAME: olympus`
  - `DATABASE_USER: ${POSTGRES_USER:-olympus}`
  - `DATABASE_PASSWORD: ${POSTGRES_PASSWORD:-olympus_dev}`
- **depends_on**: `postgres` (`service_healthy`).
- **restart**: `"no"` (one-shot; exits 0 then stops).
- Other services that touch the DB wait on this via `condition: service_completed_successfully` (api, worker, mcp-server). ⚠️ GOTCHA: it migrates **only the `olympus` DB**; the `temporal`/`temporal_visibility` schemas are managed by the Temporal auto-setup image, not Alembic.

### 1.5 `temporal-server` — `docker-compose.yml:70-95`
- **image**: `temporalio/auto-setup:latest`
- **ports**: `7233:7233` (gRPC frontend)
- **environment**:
  - `DB: postgres12` (auto-setup's Postgres driver selector)
  - `DB_PORT: "5432"`
  - `POSTGRES_USER: ${POSTGRES_USER:-olympus}`
  - `POSTGRES_PWD: ${POSTGRES_PASSWORD:-olympus_dev}`
  - `POSTGRES_SEEDS: postgres` (the Postgres host)
  - `DYNAMIC_CONFIG_FILE_PATH: "config/dynamicconfig/docker.yaml"`
- **volumes**: `./infra/temporal/dynamicconfig.yaml:/etc/temporal/config/dynamicconfig/docker.yaml:ro` — overrides the empty default to raise blob-size limits (§3.4).
- **depends_on**: `postgres` (`service_healthy`).
- **healthcheck**: `tctl --address temporal-server:7233 cluster health 2>/dev/null || nc -z localhost 7233`; interval 10s, timeout 5s, retries 20, start_period 30s.

### 1.6 `temporal-namespace-init` — `docker-compose.yml:105-117`
- **image**: `temporalio/auto-setup:latest`
- **entrypoint**: `["sh", "-c"]`
- **command** (single arg, `docker-compose.yml:114-116`):
  ```sh
  temporal operator namespace update -n default --retention 720h && \
  temporal operator namespace describe -n default | grep RetentionTtl
  ```
- **environment**: `TEMPORAL_ADDRESS: temporal-server:7233`
- **depends_on**: `temporal-server` (`service_healthy`).
- **restart**: `"no"`.
- Purpose: auto-setup creates `default` with the 24h cluster default; this pins it to 30 days so closed waves remain inspectable. Idempotent (`namespace update` is a no-op when value already matches). Spec ref in comment: `specifications/phase-5/temporal-retention-and-aged-out-workflows.md`.

### 1.7 `temporal-ui` — `docker-compose.yml:119-128`
- **image**: `temporalio/ui:latest`
- **ports**: `8080:8080`
- **environment**:
  - `TEMPORAL_ADDRESS: temporal-server:7233`
  - `TEMPORAL_CORS_ORIGINS: http://localhost:3000`
- **depends_on**: `temporal-server` (`service_healthy`).
- **healthcheck**: none.

### 1.8 `olympus-api` — `docker-compose.yml:133-217`
- **build**: context `.`, dockerfile `olympus-api/Dockerfile`, build-arg `PIP_EXTRA_INDEX_URL: ${PIP_EXTRA_INDEX_URL}`.
- **command** (from Dockerfile `olympus-api/Dockerfile:34`): `uvicorn src.main:create_app --factory --host 0.0.0.0 --port 8000`.
- **ports**: `8000:8000`
- **environment** (complete, `docker-compose.yml:142-183`):
  - `API_PORT: "8000"`
  - `DATABASE_HOST: postgres`
  - `DATABASE_PORT: "5432"`
  - `DATABASE_NAME: olympus`
  - `DATABASE_USER: ${POSTGRES_USER:-olympus}`
  - `DATABASE_PASSWORD: ${POSTGRES_PASSWORD:-olympus_dev}`
  - `TEMPORAL_HOST: temporal-server:7233`
  - `TEMPORAL_NAMESPACE: default`
  - `REDIS_URL: redis://redis:6379/0`
  - `LOG_LEVEL: INFO`
  - `GITHUB_TOKEN: ${GITHUB_TOKEN:-}`
  - `GITHUB_BASE_URL: ${GITHUB_BASE_URL:-https://api.github.com}`
  - `GITHUB_WEBHOOK_SECRET: ${GITHUB_WEBHOOK_SECRET:-}`
  - `DEV_AUTH_BYPASS: "true"` ← ⚠️ GOTCHA: bypasses auth for **all** API calls in local compose. With this on, the service tokens minted by `seed-tokens` are *unused* (`docker-compose.yml:368-371` comment, and Makefile note `Makefile:101`). Production must run with this off.
  - `AWS_REGION: ${AWS_REGION:-us-east-1}`
  - `AWS_PROFILE: ${AWS_PROFILE:-ATLAS}`
  - `MCP_SERVER_URL: http://olympus-mcp-server:3001`
  - `SKILLS_ROOT: /app/repo`
  - `OLYMPUS_PROFILES_DIR: /app/repo/profiles` (P5-AUDIT-005: makes `GET /api/v1/profiles` enumerate bundles instead of 500-ing)
  - `OLYMPUS_WORKER_CONFIG_DIR: /app/repo/olympus-worker/config` (source for `/api/v1/agent-roles`)
  - `RATE_LIMIT_ENABLED: ${RATE_LIMIT_ENABLED:-false}` ← ⚠️ GOTCHA: rate limiting **off** in compose because the dashboard fires 15-20 requests per page nav and trips the default 60/min/IP limit, leaving the page showing "no data" until refresh (`docker-compose.yml:169-175`).
  - `JWT_SECRET: ${JWT_SECRET:-olympus-dev-secret}`
  - `SERVICE_TOKEN_PROVISIONING_SECRET: ${SERVICE_TOKEN_PROVISIONING_SECRET:-olympus-dev-provisioning}`
  - `SOURCE_INTAKE_ROOT: /workspace/sources` (P5-S14/W13 — non-Git source intake; must match the agent-runtime path, both bind `agent-workspace` at `/workspace`)
  - `SOURCE_INTAKE_MAX_UPLOAD_BYTES: ${SOURCE_INTAKE_MAX_UPLOAD_BYTES:-524288000}` (500 MB)
  - `SOURCE_INTAKE_S3_REGION: ${SOURCE_INTAKE_S3_REGION:-}`
- **volumes** (`docker-compose.yml:184-202`):
  - `~/.aws:/root/.aws:ro` (host AWS creds for Bedrock/S3)
  - `./cross-cutting/skills:/app/repo/cross-cutting/skills:ro`
  - `./profiles:/app/repo/profiles:ro` (full tree; previously only `profiles/faa/skills/` was mounted → 500 on profiles router, P5-AUDIT-005)
  - `./olympus-worker/config:/app/repo/olympus-worker/config:ro`
  - `agent-workspace:/workspace` (shared with agent-runtime for source intake)
- **depends_on**: `db-migrate` (`service_completed_successfully`), `postgres` (`service_healthy`), `temporal-server` (`service_healthy`), `redis` (`service_healthy`).
- **healthcheck**: `curl -sf http://localhost:8000/health || exit 1`; interval 10s, timeout 5s, retries 5, start_period 15s. NOTE: uses `/health` (basic liveness, always 200 when process up — `olympus-api/src/routers/health.py:33-42`), **not** `/health/ready`.

### 1.9 `olympus-temporal-worker` — `docker-compose.yml:219-302`
- **build**: context `.`, dockerfile `olympus-worker/Dockerfile` (multi-stage), build-arg `PIP_EXTRA_INDEX_URL`.
- **command** (from Dockerfile `olympus-worker/Dockerfile`): `python -m src.worker`.
- **ports**: none (scale-compatible background process).
- **environment** (`docker-compose.yml:230-268`):
  - `TEMPORAL_HOST: temporal-server:7233`
  - `TEMPORAL_NAMESPACE: default`
  - `TASK_QUEUE: olympus-main`
  - `WORKER_IDENTITY`: **intentionally unset** — derived at runtime from hostname+pid (§3.2).
  - `DATABASE_HOST/PORT/NAME/USER/PASSWORD`: `postgres` / `"5432"` / `olympus` / `${POSTGRES_USER:-olympus}` / `${POSTGRES_PASSWORD:-olympus_dev}`
  - `LOG_LEVEL: INFO`
  - `OLYMPUS_AGENT_URL: http://olympus-agent:8100` (the HAProxy LB, not a runtime replica directly)
  - `GITHUB_TOKEN: ${GITHUB_TOKEN:-}`
  - `GITHUB_BASE_URL: ${GITHUB_BASE_URL:-https://api.github.com}`
  - `GITHUB_REPO: ${GITHUB_REPO:-}`
  - `OLYMPUS_PROFILE_ROOT: /app/repo/profiles/faa` ← ⚠️ GOTCHA: `load_context_priors` resolves priors from `<root>/context-priors/manifest.yaml`; without this env priors **silently return empty** (`docker-compose.yml:259-262`).
  - `OLYMPUS_SCHEMAS_DIR: /app/repo/schemas` ← ⚠️ GOTCHA: `validate_artifact_against_schema` reads JSON-Schema from here; the wheel-installed activity can't reach the repo via `parents[3]` path math, so without this env, advisory schema validation logs a warning and **continues** (`docker-compose.yml:263-268`).
- **volumes** (`docker-compose.yml:269-275`):
  - `~/.aws:/root/.aws:ro`
  - `./profiles:/app/repo/profiles:ro`
  - `./schemas:/app/repo/schemas:ro`
- **depends_on**: `db-migrate` (`service_completed_successfully`), `temporal-server` (`service_healthy`), `postgres` (`service_healthy`).
- **healthcheck** (`docker-compose.yml:295-302`): liveness only — scans `/proc` for another process whose cmdline contains `src.worker`, excluding own pid:
  ```sh
  python -c "import os,pathlib,sys; me=os.getpid(); ok=any(p.name.isdigit() and int(p.name)!=me and 'src.worker' in (p/'cmdline').read_bytes().decode('utf-8','replace') for p in pathlib.Path('/proc').iterdir()); sys.exit(0 if ok else 1)"
  ```
  interval 15s, timeout 5s, retries 5, start_period 30s.
  ⚠️ GOTCHA: `procps`/`pgrep` is **not** installed in `python:3.14-slim`, hence the manual `/proc` scan. Self-pid is excluded to avoid a tautology (the healthcheck command's own cmdline contains the literal `src.worker`). Previous version urlopen'd Temporal's gRPC port and falsely reported "unhealthy" while polling fine (fixed P5-S15/W14).
- **scaling**: `docker compose up -d --scale olympus-temporal-worker=N`; each replica polls the shared `olympus-main` queue.

### 1.10 `olympus-dashboard` — `docker-compose.yml:304-329`
- **build**: context `./dashboard`, dockerfile `Dockerfile` (note: **dashboard build context is `./dashboard`**, not repo root — different from all Python services).
- **command** (Dockerfile `dashboard/Dockerfile` final CMD): `sh -c '. /etc/profile.d/zscaler-ca.sh 2>/dev/null || true; exec npx vite --host 0.0.0.0 --port 3000 --force'` → **Vite dev server**, not a production build.
- **ports**: `3000:3000`
- **environment**:
  - `API_URL: http://olympus-api:8000`
  - `VITE_API_BASE_URL: http://localhost:8000`
  - `VITE_WS_BASE_URL: ws://localhost:8000`
  ⚠️ GOTCHA: `VITE_*` are **browser-facing** so they point at `localhost` (resolved by the user's browser), while `API_URL` is the in-network name. These must differ.
- **volumes** (`docker-compose.yml:314-324`):
  - `./dashboard/src:/app/src`
  - `./dashboard/index.html:/app/index.html`
  - `./docs:/docs:ro` ← needed because `AboutContinuity` imports `../../../../docs/phase1-continuity-matrix.md?raw`; vite.config widens `fs.allow` to repo root but the bind mount is what makes the file exist (`docker-compose.yml:317-324`).
- **depends_on**: `olympus-api` (`service_healthy`).
- **healthcheck**: `node -e "fetch('http://localhost:3000').then(r=>{process.exit(r.ok?0:1)}).catch(()=>process.exit(1))"` (no interval/timeout/retries specified → Docker defaults).

### 1.11 `olympus-agent-runtime` — `docker-compose.yml:346-422`
- **build**: context `.`, dockerfile `olympus-agent-runtime/Dockerfile` (multi-stage), build-arg `PIP_EXTRA_INDEX_URL`.
- **command** (Dockerfile final CMD): `uvicorn src.main:create_app --factory --host 0.0.0.0 --port 8100`.
- **ports**: **none** (replicas live behind the LB; the LB exposes 8100 on the host).
- **environment** (`docker-compose.yml:352-379`):
  - `AGENT_NAME: ${AGENT_NAME:-discovery-analyst}` (selects registered identity; with the catch-all agents.yaml this is largely vestigial — §3.5)
  - `AGENT_PORT: "8100"`
  - `SKILLS_DIR: /app/skills`
  - `INFERENCE_PROVIDER: ${INFERENCE_PROVIDER:-bedrock}`
  - `DEFAULT_MODEL_TIER: tier-2`
  - `AWS_REGION: ${AWS_REGION:-us-east-1}`
  - `AWS_PROFILE: ${AWS_PROFILE:-ATLAS}`
  - `CLAUDE_CODE_USE_BEDROCK: "1"`
  - `MAX_CONCURRENT_TASKS: "12"`
  - `MAX_QUEUED_WAITERS: "2"`
  - `LOG_LEVEL: INFO`
  - `GITHUB_TOKEN: ${GITHUB_TOKEN:-}`
  - `GITHUB_BASE_URL: ${GITHUB_BASE_URL:-https://api.github.com}`
  - `WORKSPACE_DIR: /workspace`
  - `SKILL_API_URL: http://olympus-api:8000`
  - `OLYMPUS_API_TOKEN: ${OLYMPUS_AGENT_RUNTIME_TOKEN:-}` ← consumes the JWT minted by `seed-tokens` (unused while `DEV_AUTH_BYPASS=true`).
  - `OLYMPUS_SCHEMA_ROOT: /app/repo` ← ⚠️ GOTCHA: `build_system_prompt` folds declared `output_schemas` into the prompt and `output_validator` strict-checks against this root; without it every `load_schema` returns None and the agent dispatches with an empty contract section (`docker-compose.yml:372-379`).
- **volumes** (`docker-compose.yml:380-386`):
  - `~/.aws:/root/.aws:ro`
  - `./cross-cutting/skills:/app/skills:ro`
  - `./schemas:/app/repo/schemas:ro`
  - `agent-workspace:/workspace` (shared with API for source intake)
- **shm_size**: `${AGENT_SHM_SIZE:-512m}` (bumped from Docker's 64 MiB default to guard subprocess-based tool-call fallbacks).
- **deploy** (`docker-compose.yml:410-416`):
  - `replicas: ${AGENT_REPLICAS:-3}`
  - `resources.limits.memory: ${AGENT_MEMORY_LIMIT:-6G}`
  - `resources.reservations.memory: ${AGENT_MEMORY_RESERVATION:-2G}`
  - CPU **uncapped** (workload is I/O-bound on Bedrock + MCP). Sizing rationale: SDK sessions ~200 MiB each × MAX_CONCURRENT_TASKS=12 ≈ 2.4 GiB peak.
- **depends_on**: none listed (but the LB depends on *it*).
- **healthcheck**: `curl -sf http://localhost:8100/health || exit 1`; interval 10s, timeout 5s, retries 5, start_period 15s.

### 1.12 `olympus-agent` (HAProxy LB) — `docker-compose.yml:450-470`
- **image**: `haproxy:2.9-alpine`
- **ports**: `8100:8100` (single host port — replicas no longer bind directly).
- **volumes**: `./infra/haproxy/agent-lb.cfg:/usr/local/etc/haproxy/haproxy.cfg:ro`
- **depends_on**: `olympus-agent-runtime` (`service_healthy`).
- **healthcheck**: `wget -qO- http://127.0.0.1:8100/lb-health || exit 1`; interval 10s, timeout 5s, retries 5, start_period 5s.
  ⚠️ GOTCHA: uses `127.0.0.1`, **not** `localhost` — alpine resolves `localhost`→`::1` (IPv6) first, but HAProxy `bind *:8100` is IPv4-only, so a `localhost` probe gets connection-refused even when the LB is up (`docker-compose.yml:463-466`).
- ⚠️ GOTCHA: the service is named `olympus-agent` (the LB), while the runtime pool is `olympus-agent-runtime`. Callers keep `OLYMPUS_AGENT_URL=http://olympus-agent:8100` unchanged. `make up`/`make demo-up` **scale `olympus-agent`** (the LB!) via `--scale olympus-agent=8` — see §3.3 GOTCHA.

### 1.13 `olympus-mcp-server` — `docker-compose.yml:472-494`
- **build**: context `.`, dockerfile `mcp-server/Dockerfile`.
- **command** (Dockerfile final CMD): `python3 -m olympus_mcp.server --host 0.0.0.0 --port 3001` (argparse defaults are `127.0.0.1`/`3001`, `mcp-server/olympus_mcp/server.py:326-335`; compose overrides host to `0.0.0.0`).
- **ports**: `3001:3001`
- **environment**: `DATABASE_HOST: postgres`, `DATABASE_PORT: "5432"`, `DATABASE_NAME: olympus`, `DATABASE_USER: ${POSTGRES_USER:-olympus}`, `DATABASE_PASSWORD: ${POSTGRES_PASSWORD:-olympus_dev}`. The MCP server reads these via `os.environ.get` directly (`mcp-server/olympus_mcp/db.py:27-31`, defaults `localhost`/`5432`/`olympus`/`olympus`/`olympus`).
- **depends_on**: `db-migrate` (`service_completed_successfully`), `postgres` (`service_healthy`).
- **healthcheck**: `python -c "import urllib.request; urllib.request.urlopen('http://localhost:3001/')" || exit 1`; interval 10s, timeout 5s, retries 5, start_period 10s.

---

## 2. Environment variables (full inventory)

### 2.1 `.env.example` (copy to `.env`) — `.env.example:1-49`
| Var | Purpose | Example / default |
|---|---|---|
| `PIP_EXTRA_INDEX_URL` | Artifactory PyPI index for foundry packages (anonymous read on `agentic-ai-pypi`); local fallback is `vendor/wheels/` | `https://jfrog-platform.bah-ss-nonprod.te-test-domain.com/artifactory/api/pypi/agentic-ai-pypi/simple` |
| `POSTGRES_USER` | Postgres superuser / app user | `olympus` |
| `POSTGRES_PASSWORD` | Postgres password | `olympus_dev` |
| `POSTGRES_DB` | Bootstrap DB (init creates `olympus`/`temporal`/`temporal_visibility`) | `postgres` |
| `API_PORT` | API listen port | `8000` |
| `DATABASE_HOST` | DB host (compose: `postgres`; host scripts: `localhost`) | `postgres` |
| `DATABASE_PORT` | DB port | `5432` |
| `DATABASE_NAME` | App DB | `olympus` |
| `DATABASE_USER` | App DB user | `olympus` |
| `DATABASE_PASSWORD` | App DB password | `olympus_dev` |
| `TEMPORAL_HOST` | Temporal frontend addr | `temporal-server:7233` |
| `TEMPORAL_NAMESPACE` | Temporal namespace | `default` |
| `LOG_LEVEL` | Log level | `INFO` |
| `GITHUB_TOKEN` | GitHub PAT — portfolio creation (validate repo) + Discovery (commit artifacts) | `<redacted>` (empty default) |
| `GITHUB_BASE_URL` | GitHub API root (set for GHE) | `https://api.github.com` |
| `REDIS_URL` | Redis URL | `redis://redis:6379/0` |
| `AWS_ENDPOINT_URL` | LocalStack endpoint (S3/SecretsMgr only; opt-in by code, **not** wired in compose) | `http://localstack:4566` |
| `AWS_ACCESS_KEY_ID` | LocalStack dummy creds | `test` |
| `AWS_SECRET_ACCESS_KEY` | LocalStack dummy creds | `<redacted>` (`test`) |
| `AWS_DEFAULT_REGION` | AWS default region | `us-east-1` |
| `AWS_REGION` | Bedrock region | `us-east-1` |
| `INFERENCE_PROVIDER` | Inference backend | `bedrock` |
| `CLAUDE_CODE_USE_BEDROCK` | Route Claude Agent SDK to Bedrock | `1` |
| `OLYMPUS_AGENT_URL` | Single runtime URL for all agent identities (DECISION-019) → the LB | `http://olympus-agent:8100` |

### 2.2 Vars in compose `environment:` blocks NOT in `.env.example`
These have inline `${VAR:-default}` defaults so they need no `.env` entry to boot, but they exist:
- `GITHUB_WEBHOOK_SECRET` (`docker-compose.yml:154`, default empty), `GITHUB_REPO` (`docker-compose.yml:257`, default empty)
- `DEV_AUTH_BYPASS="true"` (api, hardcoded `docker-compose.yml:155`)
- `AWS_PROFILE` (`${AWS_PROFILE:-ATLAS}`, api + runtime)
- `MCP_SERVER_URL`, `SKILLS_ROOT`, `OLYMPUS_PROFILES_DIR`, `OLYMPUS_WORKER_CONFIG_DIR` (api)
- `RATE_LIMIT_ENABLED` (`${...:-false}`), `JWT_SECRET` (`${...:-olympus-dev-secret}`), `SERVICE_TOKEN_PROVISIONING_SECRET` (`${...:-olympus-dev-provisioning}`)
- `SOURCE_INTAKE_ROOT`, `SOURCE_INTAKE_MAX_UPLOAD_BYTES` (`${...:-524288000}`), `SOURCE_INTAKE_S3_REGION`
- `TASK_QUEUE=olympus-main` (worker), `OLYMPUS_PROFILE_ROOT`, `OLYMPUS_SCHEMAS_DIR` (worker)
- `OLYMPUS_AGENT_URL` (worker), `AGENT_NAME` (`${...:-discovery-analyst}`), `AGENT_PORT`, `SKILLS_DIR`, `DEFAULT_MODEL_TIER`, `MAX_CONCURRENT_TASKS`, `MAX_QUEUED_WAITERS`, `WORKSPACE_DIR`, `SKILL_API_URL`, `OLYMPUS_API_TOKEN` (=`${OLYMPUS_AGENT_RUNTIME_TOKEN:-}`), `OLYMPUS_SCHEMA_ROOT` (runtime)
- `API_URL`, `VITE_API_BASE_URL`, `VITE_WS_BASE_URL` (dashboard)
- Compose-interpolation knobs: `AGENT_REPLICAS` (`:-3`), `AGENT_MEMORY_LIMIT` (`:-6G`), `AGENT_MEMORY_RESERVATION` (`:-2G`), `AGENT_SHM_SIZE` (`:-512m`)
- `TEMPORAL_ADDRESS` (namespace-init, ui), `TEMPORAL_CORS_ORIGINS` (ui), Temporal server: `DB`, `DB_PORT`, `POSTGRES_PWD`, `POSTGRES_SEEDS`, `DYNAMIC_CONFIG_FILE_PATH`
- LocalStack: `SERVICES`, `DEFAULT_REGION`

### 2.3 Vars read by `config.py` / code that have NO compose entry (rely on pydantic defaults)
From `olympus-api/src/config.py` (`AppConfig`): `service_name=olympus-api`, `version=0.1.0`, `temporal_task_queue=olympus-main`, `temporal_ui_base_url=http://localhost:8080`, `workflow_staleness_minutes=30`, `workflow_cancel_grace_seconds=30`, `cors_origins=[http://localhost:3000]` (`olympus-api/src/config.py:19-72`).
From `olympus-worker/src/config.py` (`WorkerConfig`): `max_concurrent_activities=100`, `max_concurrent_workflow_tasks=50`, `agent_runtime_mode=live`, `app_env=development` (`olympus-worker/src/config.py:45-64`). ⚠️ GOTCHA: `agent_runtime_mode` defaults to `live`; setting it to `mock` while `app_env ∈ {production,prod,staging,stage}` raises `MockInProductionError` at startup (`olympus-worker/src/config.py:21,68-86`). Invalid values raise `InvalidAgentRuntimeModeError`.
From `olympus-agent-runtime/src/config.py` (`AgentRuntimeConfig`): `service_name`, `version=0.1.0`, `bedrock_model_prefix=us` (`"us"|"global"|"eu"`), `permission_mode=acceptEdits` (⚠️ silently *accepts* file edits in headless dispatch; the prior `dontAsk` silently *denied* and burned turns — `olympus-agent-runtime/src/config.py:30-41`), `max_concurrent_tasks=12`, `max_queued_waiters=2` (`olympus-agent-runtime/src/config.py:11-58`).

### 2.4 Secrets / token-related (auth) vars
- `JWT_SECRET` — HS256 signing key for service tokens (`olympus-api/src/auth/service_tokens.py:47`); dev default `olympus-dev-secret`.
- `JWT_ALGORITHM` — default `HS256` (`olympus-api/src/auth/service_tokens.py:48`).
- `OLYMPUS_AGENT_RUNTIME_TOKEN`, `OLYMPUS_WORKER_TOKEN` — JWTs written into `.service-tokens.env` by `seed-tokens` (§5.3).
- `DATABASE_MIGRATION_USER` / `DATABASE_MIGRATION_PASSWORD` — optional migration-specific creds; Alembic `env.py` prefers them, falling back to `DATABASE_USER`/`DATABASE_PASSWORD` (`db/alembic/env.py:51-58`). Also supports `DATABASE_URL` as a monolithic override (`db/alembic/env.py:41-43`).
- `WORKER_IDENTITY` — optional explicit override for Temporal worker identity (`olympus-worker/src/worker.py:50-54`).
- `AGENT_CONFIG_PATH` — worker agent-registry YAML path, default `config/agents.yaml` (`olympus-worker/src/worker.py:59`).
- `OLYMPUS_PROFILE` — read by `temporal/olympus_workflows/worker.py:232` to bootstrap a profile into the 6 registries before the worker accepts tasks (compose worker entrypoint is `src.worker`, which calls the same registry bootstrap path).

> ⚠️ Database-URL composition rule (applies to api, worker, mcp, alembic): the URL is **never** hardcoded; it is composed at runtime from `DATABASE_HOST/PORT/NAME/USER/PASSWORD`, password is `quote_plus`-encoded, and missing fields fail-fast by name (`olympus-api/src/config.py:76-92`; `olympus-worker/src/config.py:88-104`; `db/alembic/env.py:28-88`). Async variants swap scheme to `postgresql+asyncpg://`.

---

## 3. Temporal configuration

### 3.1 Namespace, queue, addresses
- **Namespace**: `default` (all services). Retention **720h** pinned by `temporal-namespace-init` (§1.6).
- **Task queue**: single shared queue `olympus-main` (`olympus-worker/src/config.py:42`; compose `docker-compose.yml:233`). `temporal/olympus_workflows/worker.py:246-247` defensively rewrites the foundry default queue `foundry-workflows` → `olympus-main`.
- **Frontend**: `temporal-server:7233` (gRPC). **UI**: `:8080`.
- **Persistence**: Postgres DBs `temporal` + `temporal_visibility` (created in §5.1), driver `postgres12`.

### 3.2 Worker identity resolution — `olympus-worker/src/worker.py:35-54`
```
function _resolve_worker_identity(task_queue):
    existing = env["WORKER_IDENTITY"].strip()
    if existing: return existing                       # explicit override wins
    hostname = socket.gethostname() or "local"
    return f"olympus-worker-{task_queue}-{hostname}-{pid}"
```
⚠️ GOTCHA: `WORKER_IDENTITY` is deliberately left unset in compose so each `--scale` replica derives a unique identity from its container hostname; setting it in compose would evaluate against the docker host, not the container, and collide (`docker-compose.yml:234-240`).

### 3.3 Worker concurrency + replicas
- Worker concurrency (foundry `WorkerConfig`): `max_concurrent_activities=100`, `max_concurrent_workflow_tasks=50` (`olympus-worker/src/config.py:45-46`), copied onto `FoundryWorkerConfig` at startup (`olympus-worker/src/worker.py:118-119`).
- Worker bootstrap: `run_worker()` calls `config.validate_agent_runtime_mode()` → `_load_agent_config()` (agents.yaml) → registers SIGHUP hot-reload → builds `FoundryWorkerConfig.from_env()` and overrides host/namespace/queue/concurrency/identity → `create_temporal_client` → `create_worker_with_defaults(workflows=ALL_WORKFLOWS, activities=ALL_ACTIVITIES)` (`olympus-worker/src/worker.py:92-142`).
- **⚠️ GOTCHA — "8 agent replicas" actually scales the LB, not workers.** `make up`/`make demo-up` run `docker compose up -d --scale olympus-agent=$(AGENT_SCALE)` with `AGENT_SCALE=8` (`Makefile:28,48,107`). `olympus-agent` is the **HAProxy LB service** (`docker-compose.yml:450`), so this command requests 8 LB containers (all binding host port 8100 → only one can bind; the rest fail/conflict in practice). The **agent runtime pool** scales via the separate `${AGENT_REPLICAS:-3}` `deploy.replicas` knob (`docker-compose.yml:411`) or `--scale olympus-agent-runtime=N`. The Makefile comments still describe the older round-robin-DNS model (pre task #200) where `olympus-agent` *was* the runtime pool; the architecture was later split (LB `olympus-agent` in front of pool `olympus-agent-runtime`) but the Make target string was not updated. A faithful rebuild should reproduce the Makefile text verbatim **and** carry this discrepancy note. To actually get N runtimes: `make up AGENT_REPLICAS=N` or `docker compose up -d --scale olympus-agent-runtime=N`. Throughput math in `Makefile:24-27`: "8 replicas × 12 concurrent tasks = 96 in-flight agents."
- The worker's own scale path (background process, no port): `--scale olympus-temporal-worker=N` (`docker-compose.yml:219-224`).

### 3.4 Dynamic config (blob-size override) — `infra/temporal/dynamicconfig.yaml:23-26`
```
limit.blobSize.warn:   [{ value: 1048576 }]   # 1 MiB
limit.blobSize.error:  [{ value: 4194304 }]   # 4 MiB
```
⚠️ GOTCHA: this is a **band-aid**, explicitly documented as such (`infra/temporal/dynamicconfig.yaml:7-21`). Temporal defaults are warn=512 KiB / error=2 MiB. Raised because Discovery gate-evidence for the AAM apps (42 artifacts) produces ~5.7 MiB of workflow history and a ~2.1 MiB activity input that would otherwise terminate the workflow. The durable fix (slim `_build_evidence_data` in `temporal/olympus_workflows/workflows/base.py` to ship git-tracked artifact *paths* not *contents*) is on the punchlist. Must be reproduced to avoid Discovery workflow terminations on real portfolios.

### 3.5 Agent registry — `olympus-worker/config/agents.yaml`
- A **single catch-all agent** named `olympus-agent` with `skill_ids: []` (empty = matches any skill the workflow dispatches), `url: ${OLYMPUS_AGENT_URL:-http://olympus-agent:8100}`, `version: 2.0.0`, capabilities `[generic-skill-dispatch]`, all 10 assembly lines listed.
- ⚠️ GOTCHA: per P5-S26 Q15 (2026-05-04), per-line agent roles (`discovery-analyst`, etc.) were **retired** to stop skill/role drift. The `AGENT_NAME=discovery-analyst` default in compose (`docker-compose.yml:353`) is now effectively vestigial — every dispatch routes to the one catch-all. Skill→model-tier routing lives in Admin (Skill Routing table, P5-S26), not in this file.
- Loaded at worker startup; **hot-reloadable on SIGHUP** (`olympus-worker/src/worker.py:63-66,111`).

### 3.6 Registered workflows & activities — `temporal/olympus_workflows/worker.py:135-222`
- **`ALL_WORKFLOWS`** (18): PortfolioWorkflow, WaveWorkflow, AppWorkflow, DiscoveryWorkflow, RationalizationWorkflow, WaveRationalizationWorkflow, WaveArchitectureWorkflow, ArchitectureWorkflow, DataWorkflow, ModernizationWorkflow, GenerateBCWorkflow, ValidationWorkflow, DeploymentWorkflow, DispositionWorkflow, SustainmentWorkflow, GovernanceWorkflow, SmokeTestAgentDispatchWorkflow (hand-started smoke only), BundleReaperWorkflow (cron, 15-min cadence via Temporal Schedules).
- **`ALL_ACTIVITIES`** (≈57): dispatch_agent_task, update_agent_task_output_ref, read_artifact, write_artifact, write_artifacts_batch, emit_disposition_output_bundle, create_pr, merge_pr, reconcile_and_merge_pr, provision_target_repo, check_gate_criteria, create_gate_record, mark_gate_ready_for_review, set_gate_merge_blocked, submit_gate_evidence, update_application_status, wait_for_gate_decision, calculate_readiness_score, record_score_snapshot, store_gate_pre_review, start_next_line_workflow, update_application_line_projection, create_target_app_and_repo, fetch_application_source_repos, terminate_source_app_workflows, update_wave_status, update_wave_architecture_workflow_id, persist_decomposition_map, persist_discovery_side_effects, persist_capability_catalog, load_wave_rationalization_capabilities, persist_rationalization_capabilities, persist_rationalization_capability_dispositions, persist_rationalization_side_effects, persist_architecture_side_effects, realize_target_state_grain, persist_data_side_effects, persist_modernization_side_effects, persist_sustainment_sweep_side_effects, persist_validation_side_effects, persist_governance_sweep_side_effects, persist_deployment_side_effects, persist_disposition_side_effects, persist_classification, confirm_classification_tier_1, persist_portfolio_score, persist_wave_failure, list_active_modernization_workflows, publish_arch_data_signal, consume_arch_data_signal, validate_artifact_against_schema, load_context_priors, dispatch_delegated_bundle, expire_due_bundles_activity. (Exact list `temporal/olympus_workflows/worker.py:164-222`; full behavioral specs are Phases 3–4.)

---

## 4. Volumes — persistence vs disposable

Named volumes (`docker-compose.yml:496-500`):
| Volume | Mounted at | Persists? | Disposable? |
|---|---|---|---|
| `postgres-data` | postgres `/var/lib/postgresql/data` | Yes — survives `down`; holds **olympus app DB + Temporal DBs** | Dropped by `down -v` / `reset` / `demo-nuke`. ⚠️ Treat as derived/disposable per project doctrine (Git is source of truth; PG is rebuildable) — but dropping it loses all seeded portfolios + all Temporal history. |
| `redis-data` | redis `/data` | Yes | Disposable (cache/rate-limit state). |
| `localstack-data` | localstack `/var/lib/localstack` | Yes | Disposable. |
| `agent-workspace` | api + agent-runtime `/workspace` | Yes | Holds **unpacked non-Git sources** under `/workspace/sources/<application_id>`; both API (writer) and agent-runtime (reader) mount it. Dropping it loses uploaded zip/S3 sources. |

Bind mounts (host→container, all read-only unless noted) — these reflect **host repo state live**, so editing source on the host updates the container (esp. dashboard `./dashboard/src`, which is read-write-ish for HMR): `./db/init`, `./infra/temporal/dynamicconfig.yaml`, `./cross-cutting/skills`, `./profiles`, `./olympus-worker/config`, `./schemas`, `./docs`, `./dashboard/src`, `./dashboard/index.html`, `./infra/haproxy/agent-lb.cfg`, `~/.aws`.

⚠️ GOTCHA — `db/init` only runs on first launch: Postgres runs `/docker-entrypoint-initdb.d/*` **only when the data dir is empty**. If `postgres-data` already exists (any prior `up` without `-v`), the init script that creates `olympus`/`temporal`/`temporal_visibility` is **skipped**. After editing `01-create-databases.sh` you must `down -v` (or `demo-nuke`) to re-run it.

---

## 5. Bootstrap mechanics (init, migrations, tokens) + seed data

### 5.1 DB init — `db/init/01-create-databases.sh:8-17`
```sh
psql -v ON_ERROR_STOP=1 -U $POSTGRES_USER -d $POSTGRES_DB <<-EOSQL
    CREATE DATABASE olympus;
    CREATE DATABASE temporal;
    CREATE DATABASE temporal_visibility;
    GRANT ALL PRIVILEGES ON DATABASE olympus TO $POSTGRES_USER;
    GRANT ALL PRIVILEGES ON DATABASE temporal TO $POSTGRES_USER;
    GRANT ALL PRIVILEGES ON DATABASE temporal_visibility TO $POSTGRES_USER;
EOSQL
```
Runs once on first postgres launch (`$POSTGRES_DB`=`postgres`). Creates all 3 DBs.

### 5.2 Alembic migrations — `db/Dockerfile`, `db/alembic.ini`, `db/alembic/env.py`
- Runner image: `python:3.14-slim`, installs `db/requirements.txt` (`alembic>=1.13,<2.0`, `psycopg2-binary>=2.9,<3.0`, `sqlalchemy>=2.0,<3.0`), copies `alembic.ini` + `alembic/`, `CMD alembic upgrade head`.
- **Migration chain**: base revision `001` (`down_revision=None`, `db/alembic/versions/001_create_enum_types.py:15-16`) → head revision `057` (`db/alembic/versions/057_create_delegated_bundle.py:37-38`). **56 version files** present (`ls | wc -l`). `head` = `057`.
- `env.py` composes URL from env (migration-user-aware), `NullPool`, never logs password (`db/alembic/env.py:104-118`).
- ⚠️ GOTCHA (deployed only): `db/seeds/README.md` references "alembic head `050`" and a 2026-05-20 snapshot; the live chain is now `057`. Snapshot/data-seed docs lag the schema — re-dump after schema changes.

### 5.3 Service tokens — `scripts/seed_service_tokens.py` + `olympus-api/src/auth/service_tokens.py`
```
seed_service_tokens.main():
    if "JWT_SECRET" not in env: env["JWT_SECRET"]="olympus-dev-secret"; warn
    runtime_token = issue_service_token("agent-runtime")
    worker_token  = issue_service_token("worker")
    write .service-tokens.env:
        OLYMPUS_AGENT_RUNTIME_TOKEN=<jwt>
        OLYMPUS_WORKER_TOKEN=<jwt>
issue_service_token(service):                       # service_tokens.py:22-49
    if service not in ("agent-runtime","worker"): raise ValueError
    payload = {sub:f"service:{service}", roles:[RBACRole.SERVICE], iat:now, exp:now+3600, service}
    return jwt.encode(payload, JWT_SECRET (or "olympus-dev-secret"), HS256)
```
- TTL **1 hour** (`DEFAULT_TTL_SECONDS = 3600`, `service_tokens.py:18`). Rotation = re-run + redeploy.
- `.service-tokens.env` is sourced by `make up` via a **second** `--env-file` (§6 `up`). With `DEV_AUTH_BYPASS=true` the tokens are unused (1-hour expiry is therefore harmless locally).

### 5.4 Seed orchestration — `scripts/seed_all.py` (driven by `make demo-seed`)
```
seed_all._main():                                   # seed_all.py:41-103
    require asyncpg (else exit 1)                    # guarded in __main__
    args: --reset (bool), --portfolio-name (default "Test Portfolio 4")
    faa    = load("seed_demo_faa.py")
    corpus = load("seed_modernization_corpus.py")
    seeds = [
       ("FAA demo portfolio",            faa.run(reset, portfolio_name)),
       ("Modernization Corpus portfolio", corpus.run(reset, corpus.PORTFOLIO_NAME)),
    ]
    for label, runner in seeds:
        try: asyncio.run(runner())
        except Exception: failures.append(label); print stderr
    return 1 if failures else 0
```
- `make demo-seed` calls `python scripts/seed_all.py --reset` (`Makefile:69-71`).
- **`--reset` semantics**: portfolio-scoped wipe-then-reseed; deletes only each seed's own portfolio rows, **preserves other portfolios** (`seed_all.py:46-48`). Both seeds are idempotent via deterministic `uuid5(namespace, app_key)`.
- Host-side seeds connect using `DATABASE_*` env defaulting to `localhost:5432 olympus/olympus/olympus` (`scripts/seed_demo_faa.py:49-56`). ⚠️ GOTCHA — the **Makefile exports `DATABASE_PASSWORD ?= olympus_dev`** (`Makefile:33`) so `make demo-seed` connects with `olympus_dev`, but the seed scripts' own intrinsic default is `olympus` (`seed_demo_faa.py:53`, `seed_modernization_corpus.py` header). Run seeds via `make` (gets `olympus_dev`) or export `DATABASE_PASSWORD=olympus_dev` if invoking the script directly; the bare script default `olympus` will fail auth against the compose Postgres.

**FAA demo seed** (`scripts/seed_demo_faa.py`): ~16 FAA-adjacent applications across all 10 assembly lines in varied states (running/completed; approved/pending/rejected gates), one target portfolio (default name **"Test Portfolio 4"**). Deterministic UUIDs from `DEMO_NS=7b2ff4ae-dae3-4fa0-0000-000000000000`. `run(reset, portfolio_name)` at `seed_demo_faa.py:976`.

**Modernization Corpus seed** (`scripts/seed_modernization_corpus.py`): the **14** public modernization-corpus repos onboarded into a dedicated portfolio `PORTFOLIO_NAME="Modernization Corpus"` (owner `Claudius`, artifact repo `Test-Portfolios/test-corpus-1`), **all left in `status='onboarded'`** — no agent_tasks, gates, scores, or waves (intentional: ready to start Discovery manually). Namespace `CORPUS_NS=c0a7b1e0-c012-4051-8000-000000000000` (distinct from DEMO_NS to avoid collisions). `run(reset, portfolio_name)` at `seed_modernization_corpus.py:354`.

Other seed scripts present (not in `seed_all`, invoked manually): `seed_admin_user.py` (local `portfolio_admin` bootstrap, prints password once), `seed_skills.py`, `seed_data.py`, `seed_phase5_testdata.py`, `seed_atlas_*`, `seed_test_portfolio_4_demo_grain.py`, `seed_portfolio_memberships.py`, etc. (`ls scripts/`).

### 5.5 Smoke — `scripts/demo_smoke.py` (driven by `make demo-smoke`)
```
demo_smoke.main():                                  # demo_smoke.py:57-122
    GET /health/ready  -> must be 200 AND json.status=="ready"   (else FAIL)
    GET /api/v1/portfolio -> 200, parse list
    by_name = {p.name: p}
    for expected in ("Modernization Corpus", DEMO_PORTFOLIO="Test Portfolio 4"):
        p = by_name[expected]            (FAIL if missing)
        GET /api/v1/applications?portfolio_id=p.id  -> 200
        apps = payload.data | payload.items | payload  (FAIL if empty)
    return 1 if any failure else 0
```
- Env: `API_URL` (default `http://localhost:8000`), `DEMO_PORTFOLIO_NAME` (default `Test Portfolio 4`). Stdlib only (CI-safe).
- ⚠️ GOTCHA — `make demo-wait` (`Makefile:58-67`) polls only for **HTTP 200** from `/health/ready`. But `/health/ready` **always returns 200** even when not ready: its handler sets no `status_code` and returns `{"status": "not_ready", ...}` with the default 200 when Temporal is unreachable or `skill_count==0` (`olympus-api/src/routers/health.py:114-145` — readiness is in the JSON `status` field, never the HTTP code). So `demo-wait` can declare the API "ready" while skills aren't loaded / Temporal is down; only `demo-smoke` catches it (it asserts `status=="ready"`, `demo_smoke.py:69`). Readiness criteria in the handler: Temporal `check_health()` ok **AND** `get_skill_count() > 0`.

---

## 6. Makefile targets (all 24)

Defaults (`Makefile:20-39`): `COMPOSE=docker compose`, `PYTHON=python3`, `AGENT_SCALE=8`, exported `DATABASE_HOST=localhost DATABASE_PORT=5432 DATABASE_USER=olympus DATABASE_PASSWORD=olympus_dev DATABASE_NAME=olympus`, `API_URL=http://localhost:8000`, `READY_RETRIES=60`, `READY_INTERVAL=2`. `SHELL=/bin/bash`, `.ONESHELL` (each recipe runs in one bash invocation).

| # | Target | Recipe (cite) | What it does |
|---|---|---|---|
| 1 | `help` | `Makefile:43-44` | `grep` `##`-annotated targets, pretty-print. |
| 2 | `demo-up` | `Makefile:46-56` | `compose up -d --scale olympus-agent=$(AGENT_SCALE)` → `demo-wait` → `demo-seed` → `demo-smoke`; prints dashboard/API/Temporal URLs. ⚠️ does **not** run `seed-tokens` and **does not** pass `--env-file`, so it relies on docker's default `.env` lookup only (no `.service-tokens.env`). Differs from `up`. |
| 3 | `demo-wait` | `Makefile:58-67` | Polls `$(API_URL)/health/ready` up to `READY_RETRIES=60` × `READY_INTERVAL=2`s (=120s) for **HTTP 200**; exits 1 on timeout. See §5.5 GOTCHA. |
| 4 | `demo-seed` | `Makefile:69-71` | `python3 scripts/seed_all.py --reset` (FAA + Corpus). |
| 5 | `demo-reset` | `Makefile:73-76` | `demo-wait` → `demo-seed` → `demo-smoke` (no container restart; wipe+reseed against a running stack). |
| 6 | `demo-down` | `Makefile:78-79` | `compose down` (volumes preserved). |
| 7 | `demo-nuke` | `Makefile:81-82` | `compose down -v` (drops all volumes — destructive). |
| 8 | `demo-smoke` | `Makefile:84-86` | `python3 scripts/demo_smoke.py`. |
| 9 | `seed-tokens` | `Makefile:97-98` | `python3 scripts/seed_service_tokens.py` → writes `.service-tokens.env` (§5.3). |
| 10 | `up` | `Makefile:100-107` | Depends on `seed-tokens`; `compose --env-file .env --env-file .service-tokens.env up -d --scale olympus-agent=$(AGENT_SCALE)`. ⚠️ `--env-file` replaces docker's default `.env` lookup so **both** files must be listed explicitly. |
| 11 | `down` | `Makefile:109-110` | `compose down`. |
| 12 | `reset` | `Makefile:112-114` | `compose down -v` → `make up` (destructive — drops volumes, then full bring-up). |
| 13 | `validate-schemas` | `Makefile:120-121` | `bash schemas/validate.sh` — checks each `*.schema.json` has `$schema/$id/title/description` against 2020-12 metaschema, and samples have a `$schema` ref (`schemas/validate.sh:1-60`). |
| 14 | `validate-objectives` | `Makefile:123-124` | `python3 scripts/validate_objectives.py` — validates `profiles/*/objectives.yaml` against schema + registries. |
| 15 | `render-exec` | `Makefile:131-132` | depends `validate-objectives`; `python3 scripts/render_exec_microsite.py` → `presentation/exec/data/`. |
| 16 | `render-exec-generic` | `Makefile:134-135` | depends `validate-objectives`; `render_exec_microsite.py --profile test-generic` (portability demo). |
| 17 | `serve-exec` | `Makefile:138-142` | depends `render-exec`; `python3 -m http.server $(EXEC_PORT=8765) --directory presentation` → http://localhost:8765/exec/ . |
| 18 | `csn-apply` | `Makefile:149-150` | `cd infra/terraform/environments/dev-csn-fargate && terraform apply`. |
| 19 | `csn-deploy-dashboard` | `Makefile:152-153` | `scripts/csn-fargate/build-and-push-dashboard.sh` — buildx ARM64 prod image with VITE_* baked from NLB DNS, push to ECR (date tag), `terraform apply -var dashboard_image_tag`, poll rollout. |
| 20 | `csn-seed-admin` | `Makefile:155-156` | `scripts/csn-fargate/seed-admin.sh` — Fargate one-shot: gen 24-char password, bcrypt(rounds=12), upsert `user_account` (roles `["portfolio_admin"]`, `identity_provider='local'`), write plaintext to Secrets Manager `foundry/dev/admin-user`. |
| 21 | `csn-migrate-data` | `Makefile:158-159` | `scripts/csn-fargate/migrate-local-data.sh` — upload `db/seeds/initial-data.sql` to S3, Fargate task TRUNCATEs target tables CASCADE then `psql -1 -f` (single txn, ON_ERROR_STOP). |
| 22 | `csn-bootstrap` | `Makefile:161` | `csn-apply` → `csn-seed-admin` → `csn-migrate-data` → `csn-deploy-dashboard` (full first-time bring-up after image push). |
| 23 | `csn-status` | `Makefile:168-173` | `aws ecs describe-services` for the 7 ECS services on cluster `foundry-dev`, table of desired/running/rolloutState. |
| 24 | `csn-admin-password` | `Makefile:163-166` | Print current admin username/email/password from Secrets Manager `foundry/dev/admin-user` (jq). |

> ⚠️ GOTCHA — `.PHONY` (`Makefile:41`) lists targets but **omits** `up`/`down`/`reset`/`help` from the explicit list… actually it includes `up down reset` and `help`. (Confirmed present at `Makefile:41`.) All 24 targets above are real recipes.

---

## 7. Local vs deployed (CSN-Fargate) differences

The `csn-*` targets drive a deployed **CSN-Fargate** environment (Terraform at `infra/terraform/environments/dev-csn-fargate`, `Makefile:147`). Key deltas vs the local compose stack:

- **Orchestrator**: local = Docker Compose; deployed = **AWS ECS Fargate** (cluster `foundry-dev`, ARM64), Terraform-managed. `csn-status` checks 7 ECS services: `olympus-api olympus-worker olympus-agent olympus-mcp-server olympus-dashboard temporal-server temporal-ui` (`Makefile:171`).
- **AWS account/region**: deployed pins `AWS_PROFILE=foundry-admin`, `AWS_REGION=us-east-1`, `ACCOUNT_ID=081142215512`, artifacts bucket `foundry-dev-artifacts-081142215512` (`scripts/csn-fargate/lib.sh:13-17`). `csn-admin-password` hardcodes `--profile foundry-admin --region us-east-1` (`Makefile:164`). ⚠️ This account (`081142215512`) is **different** from the S6/CARES substrate account `669403677560` referenced in memory — do not conflate.
- **Database**: local = compose Postgres container (`postgres-data` volume). Deployed = **RDS** with `sslmode=require` (`seed-admin.sh` SEED_PY `psycopg2.connect(..., sslmode="require")`), schema applied by a `db-migrate` ECS task, data seeded from `db/seeds/initial-data.sql` (data-only `pg_dump` of `skill/application/portfolio/wave/wave_application/chat_message/score_history`) via the `foundry-dev-data-migrate` task (`db/seeds/README.md`, `migrate-local-data.sh`).
- **Dashboard build**: local = **Vite dev server** with bind-mounted `src` (HMR), VITE_* point at `localhost` (`dashboard/Dockerfile` CMD `npx vite --host 0.0.0.0`). Deployed = **production build + nginx**, ARM64 image via `dashboard/Dockerfile.fargate`, with `VITE_API_BASE_URL=http://<NLB>:8000` / `VITE_WS_BASE_URL=ws://<NLB>:8000` **baked at build time** (`build-and-push-dashboard.sh`). ⚠️ NLB hostname changes require a full dashboard rebuild+redeploy (ECR tag-immutability forces a unique date tag each push).
- **Admin bootstrap**: local = `scripts/seed_admin_user.py` prints password once to stdout. Deployed = `csn-seed-admin` writes the plaintext to **Secrets Manager** (`foundry/dev/admin-user`), bcrypt rounds=12, roles `["portfolio_admin"]`, `identity_provider='local'`; if an existing user has `identity_provider != 'local'` the script exits 2 ("rotate at IdP").
- **Auth**: local sets `DEV_AUTH_BYPASS=true` and `RATE_LIMIT_ENABLED=false` (`docker-compose.yml:155,175`). Deployed keeps the default auth + rate limiting on (Helm/Terraform values), and service JWTs are real (KMS-backed signer mentioned in `service_tokens.py:4`).
- **Agent LB / inference**: HAProxy config is portable via 3 env knobs (`infra/haproxy/agent-lb.cfg:38-67`): `RESOLVER_ADDRESS` (compose `127.0.0.11:53` / Fargate `169.254.169.253:53` / EKS kube-dns), `BACKEND_DNS_NAME` (`olympus-agent-runtime` / `...olympus.local` Cloud Map / headless Service), `MAX_BACKENDS` (default 16). `presetenv` preserves compose defaults so the local stack runs unchanged.
- **Foundry packages**: local installs from `vendor/wheels/`; CI/prod from `PIP_EXTRA_INDEX_URL` (Artifactory) (`olympus-api/Dockerfile:8-22`).
- **Zscaler**: dashboard image conditionally installs `ZscalerRootCertificate*.crt` if present in the build context (Booz Allen laptops); off-network/CI no-ops (`dashboard/Dockerfile:7-37`). The cert is `.gitignored`.
- **Other deployed infra present** (not local-compose): ArgoCD ApplicationSets (`infra/argocd/`), Prometheus/Grafana dashboards + alert rules (`infra/grafana/`, `infra/prometheus/`), DMS migration tasks + GFI legacy-restore (`infra/dms/`, `infra/gfi/`). These are out of scope for local bring-up.

---

## 8. FROM-ZERO bring-up runbook (clean machine → smoke-passing stack)

Prerequisites: Docker Desktop (or a Docker engine + `docker compose` v2), `make`, `python3` with `asyncpg` available on the host (for the host-side seed scripts), and real AWS credentials in `~/.aws` if you want agents to actually run against Bedrock (LocalStack does **not** emulate Bedrock; without creds the stack still boots and serves the dashboard/API, but agent dispatch will fail at inference).

```bash
# 0. Clone and enter the repo
git clone <repo-url> foundry
cd foundry                                  # /Users/.../foundry

# 1. Create .env from the template, then fill in what you need.
cp .env.example .env
#    - GITHUB_TOKEN=<pat>        (required for portfolio create + Discovery commits)
#    - AWS creds via ~/.aws (mounted ro into api/worker/runtime); set AWS_PROFILE if not ATLAS
#    - JWT_SECRET / SERVICE_TOKEN_PROVISIONING_SECRET: leave defaults for local
#    Everything else has a working compose default.

# 2. (Optional) ensure host python can run the seeds:
pip install asyncpg                          # seed_all.py exits 1 without it

# 3. Bring the whole stack up + wait + seed + smoke in one shot:
make demo-up
#    Internally:
#      docker compose up -d --scale olympus-agent=8      (Makefile:48)
#        - postgres starts, runs db/init/01-create-databases.sh ONCE
#          (creates olympus, temporal, temporal_visibility)        [§5.1]
#        - db-migrate runs `alembic upgrade head` (001 -> 057), exits 0  [§5.2]
#        - temporal-server (auto-setup) provisions temporal DBs
#        - temporal-namespace-init pins `default` retention to 720h [§1.6]
#        - api, worker, mcp-server, dashboard, agent-runtime(x3), olympus-agent(LB) start
#      make demo-wait    -> polls GET /health/ready for HTTP 200 (<=120s) [§5.5 GOTCHA]
#      make demo-seed    -> python3 scripts/seed_all.py --reset
#                           (FAA "Test Portfolio 4" ~16 apps + "Modernization Corpus" 14 apps) [§5.4]
#      make demo-smoke   -> asserts status==ready + both portfolios have apps [§5.5]

# 4. Open the UIs:
#    Dashboard:   http://localhost:3000
#    API:         http://localhost:8000  (docs at /docs)
#    Temporal UI: http://localhost:8080
```

If you instead want the **service-token / production-shaped** bring-up (mints JWTs, passes both env-files):
```bash
make up            # = seed-tokens + compose --env-file .env --env-file .service-tokens.env up -d --scale olympus-agent=8
make demo-wait
make demo-seed
make demo-smoke
```

To actually scale the **agent runtime pool** (the Makefile's `--scale olympus-agent=N` scales the LB, not runtimes — §3.3 GOTCHA):
```bash
docker compose up -d --scale olympus-agent-runtime=8      # or: make up AGENT_REPLICAS=8
```

Lifecycle:
```bash
make demo-down     # stop, keep volumes (DB + seeds + temporal history preserved)
make demo-reset    # re-wait + re-seed against a running stack (no restart)
make reset         # down -v + full up (DROPS volumes — re-runs db/init, loses seeds)
make demo-nuke     # down -v (DROPS volumes)
```

⚠️ First-boot pitfalls to expect:
1. If `postgres-data` already exists from a prior run, `db/init` is skipped (§4 GOTCHA) — `down -v` to force DB (re)creation.
2. Seeds run on the **host** and need `DATABASE_PASSWORD=olympus_dev` (Make exports it; direct script invocation defaults to `olympus` and fails auth — §5.4 GOTCHA).
3. `demo-wait` may pass before skills/Temporal are truly ready (§5.5 GOTCHA); a failing `demo-smoke` is the real signal.
4. Agent dispatch requires **real Bedrock creds** in `~/.aws`; LocalStack covers only S3 + Secrets Manager (§1.3).
5. Without `OLYMPUS_PROFILE_ROOT`/`OLYMPUS_SCHEMAS_DIR`/`OLYMPUS_SCHEMA_ROOT` set (compose sets all three), priors return empty and schema validation degrades to warnings (§1.9, §1.11 GOTCHAs).
