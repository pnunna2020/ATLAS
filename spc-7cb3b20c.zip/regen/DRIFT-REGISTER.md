# DRIFT-REGISTER.md — Consolidated Divergence Register

**Spec pin.** This register, like every doc under `regen/`, is pinned to **HEAD `7cb3b20c`**
(`regen/.SPEC_COMMIT` → `7cb3b20c7ee5bd773acd0da7779987e5fb4e01ce`; `7cb3b20c` =
*"fix(agents): treat agent timeout as retryable, not a non-retryable empty-output wave failure (#594)"*).
All `path:line` citations below were re-derived against the live tree at that commit.

**Baseline supersession (read first).** An earlier baseline — `a1016458` (`2026-06-01`, *"Update
service-build-tracker.md"*) — was superseded **mid-generation** by a `git pull` that advanced `main`
to `7cb3b20c`. The **data-layer** (`regen/04-data-layer*.md`) and **dashboard** (`regen/05-dashboard*.md`)
docs were authored **directly at HEAD `7cb3b20c`**; **all other changed areas were refreshed to HEAD**.
The pull pulled in the entire **Phase-6** body of work that the `06-01` baseline lacked
(Build assembly line + 8th disposition, DevSecOps generation/validation, multi-provider agent
dispatch, AgentCore Memory/Gateway spike, GFI data-cleansing + shared-memory lineage, strict
output-schema enforcement). **Three landmines the old baseline recorded as live are now REVERSED at
HEAD** — see **§1 D-9** (this is the single most important consumer-facing change in this revision).
Anyone comparing this register to a spec frozen at the `06-01` baseline must read §1 D-9 and §1 D-10.

**Scope.** Three registers: (1) code-vs-docs drift in the live repo, (2) the master `⚠️ GOTCHA`
landmine list collected from every `regen/` doc, (3) every `TODO/FIXME/HACK/XXX` in non-test source.
Paths are absolute-relative to repo root `/Users/pnunna/Documents/GitHub/foundry/`.
Repo state at audit: `main` @ `7cb3b20c`. **Worktrees under `.claude/worktrees/` are explicitly OUT OF
SCOPE** and never cited as ground truth except where the prompt names one (D-1). Orchestration/audit
scratch dirs (`regen/.workflows/`, `regen/.audit*`, `regen/_audit/`) are excluded from all counts.

Each §1 item is tagged **[SPEC FAITHFUL]** (spec already reproduces the drift verbatim),
**[SPEC DRIFT]** (spec's stated value lags current `main`), or **[REPO DRIFT]** (the doc-vs-code
mismatch lives in the repo itself, independent of the spec).

---

## SECTION 1 — CODE-VS-DOCS DRIFT

### D-1. `foundry_temporal` / `@foundry_activity` (28 files on `main`) vs in-flight `temporal_base` refactor — [SPEC FAITHFUL to HEAD; imminent drift, unrecorded ADR]

- **Live HEAD `7cb3b20c` state:** the private package `foundry_temporal` (providing `@foundry_activity`
  and the error classes `NonRetryableError` / `RetryableError`) is imported in **exactly 28 files under
  `temporal/olympus_workflows/`** (matching the prompt). Representative imports:
  - `temporal/olympus_workflows/types.py:25` — `from foundry_temporal.errors import (...)`.
  - `temporal/olympus_workflows/activities/artifact_validation.py:71` — `from foundry_temporal.errors import NonRetryableError`.
  - `temporal/olympus_workflows/worker.py`, `.../retry_policies.py`, and all 18 activity modules + 7 workflow modules.
  - Two **new Phase-6** activity modules are in this set: `devsecops_validation.py`, `profile_devsecops.py`.
  - Repo-wide (excluding `.claude/worktrees/`) the string appears in **35** files (the 28 source modules
    + 6 test modules + `temporal/uv.lock`).
- The regen spec treats it as a **private Artifactory dependency** and **explicitly declares it OUT OF SCOPE**:
  - `regen/09-regeneration-order.md:57-58` — *"`foundry_temporal` / `foundry_strands_agents` is OUT OF
    SCOPE for these regen docs — they must be sourced from the foundry monorepo. `foundry_temporal`
    provides `@foundry_activity`."*
  - `regen/00-overview.md:70,80,104,299` and `regen/09-regeneration-order.md:52,55,201,311,349,571,593` —
    pinned as `foundry-temporal>=1.3.0` (private Artifactory wheel), consumed by `olympus-api`,
    `olympus-worker`, `olympus-workflows`. The spec **correctly reproduces the HEAD state.**
- **The imminent drift (DECISION-021 as the prompt frames it):** the refactor to an **in-repo
  `temporal_base`** on OSS `temporalio` exists only on the **uncommitted worktree branch**
  `worktree-feat+drop-foundry-temporal`. Direct grep at HEAD: **zero** `temporal_base` imports anywhere
  on `main` (`grep -rln temporal_base --include='*.py' . | grep -v .claude/worktrees` → 0). When that
  branch lands, every `from foundry_temporal …` import the spec records becomes stale.
- **⚠️ DECISION-021 mismatch (re-confirmed at HEAD):** the prompt frames this Temporal refactor as
  DECISION-021, but **DECISION-021 does not exist in `specifications/decisions.md`** — the ledger tops
  out at **DECISION-020** (`specifications/decisions.md:30,366`; `grep -c DECISION-021` → **0**). The only
  "DECISION-021" string in the committed tree is a **PROPOSED** ADR titled **"Regulation-as-Authority
  Chain"** in `specifications/regulation-to-mission-throughline.md:169,175,220` — a wholly different topic
  (regulatory authority chain). **Conclusion:** the `temporal_base` migration is real (worktree) but is
  **not backed by any committed decision record**; the "DECISION-021 = temporal_base" linkage is not in
  the repo. Treat the spec's `foundry_temporal` description as correct-at-HEAD, flagged in-flight + unrecorded.

### D-2. Temporal coverage floor: `CLAUDE.md` 87% vs `temporal/pyproject.toml` **78** — [REPO DRIFT; SPEC FAITHFUL]

- **The doc-vs-code mismatch lives in the REPO:** `CLAUDE.md:71` says `cd temporal && pytest # 87% floor`,
  but `temporal/pyproject.toml:115` has `addopts = "... --cov-fail-under=78"`. CLAUDE.md is the drifting
  doc; **78 is ground truth.**
- **The regen spec is FAITHFUL** — it records 78 and explains the gap:
  - `regen/00-overview.md:106` — *"`--cov-fail-under=78` … transitional floor … reproduce the floor as
    78 … the intended target is ≥87."*
  - `regen/00-overview.md:325`, `regen/09-regeneration-order.md:314-315` — both state **78%**.
  - `regen/08-build-ci.md:9` (TOP-LEVEL GOTCHA) — *"COVERAGE FLOORS IN THE TASK PROMPT AND `CLAUDE.md`
    ARE WRONG … reproduce the pyproject numbers, NOT the prose."*
- **All committed floors (direct grep at HEAD):** olympus-api `--cov-fail-under=87` (+`--ignore=tests/integration`),
  olympus-worker `90`, olympus-agent-runtime `90`, mcp-server `90`, temporal **`78`**.
  Dashboard (`dashboard/vitest.config.ts:62-65`): lines **81** / branches **70** / functions **76** /
  statements **78** (a comment at `:56` notes *"P5-S26: dropped statements 79 → 78 to match the main-branch drift"*).

### D-3. Skill count: live registry **170** entries / **19** categories — [REPO DRIFT in legacy snapshots; SPEC DRIFT (spec 3 low)]

- **Live ground truth at HEAD** (`cross-cutting/skills/registry.yaml`):
  - **170** top-level entries (`grep -c '^  - id:'`).
  - **194** total `- id:` tokens (170 top-level + **24** nested `variants:` ids).
  - **19** distinct `category:` values (top three: `Code Scaffolding & Templates` 31, `Business Process &
    Automation` 31, `Product Verification` 20).
  - **1** `is_orchestration: true` entry (it is `drift-detection` — see D-5/D1).
- **`CLAUDE.md:124` (current on disk) already says "170 skills"** — the *file* is up to date. The
  CLAUDE.md **snapshot embedded in the system prompt** ("137 skills across 12 categories") is **stale
  text**; the spec also flags "137/12" as stale (`regen/11-skill-registry.md:194-195`,
  `regen/11-skill-registry.md:187`).
- **⚠️ SPEC DRIFT (registry grew after spec freeze):** the spec was written against **167** registry
  entries / **178** core SKILL.md:
  - `regen/11-skill-registry.md:31` — *"Registry top-level entries (`^  - id:`) | **167**"*; repeated at
    `:33,76,81,84,109,119,143,153,158,185,195`, in `regen/11-skill-registry-wiring.md`, and
    `regen/09-regeneration-order.md:261`.
  - **Live now:** **170** registry entries (167 → 170, **+3**) and **181** core `SKILL.md` under
    `cross-cutting/skills/` (spec said 178 → **+3**), plus **15** FAA-profile `SKILL.md` under
    `profiles/faa/skills/`. **19** categories is still correct.
- **Net:** category count (19) faithful; entry/SKILL.md counts in the spec are **3 low** vs HEAD. A
  rebuilder MUST re-derive the count from `registry.yaml` at build time (the spec itself instructs this).

### D-4. Ralph fan-out cap: docstrings say "max 5 children" but `MAX_BC_CHILDREN_PER_APP = 12` is authoritative — [REPO DRIFT; SPEC FAITHFUL]

- **The mismatch is in the code's own docstrings (re-confirmed at HEAD):**
  - `temporal/olympus_workflows/workflows/modernization.py:23` — *"Fan-out: per bounded context in
    Generate step (max 5 children)"*.
  - `temporal/olympus_workflows/workflows/modernization.py:228` — *"Concurrency: max 5 bounded context
    children per app in Generate step."*
  - `temporal/olympus_workflows/workflows/generate_bc.py:4` — *"up to MAX_BC_CHILDREN_PER_APP in parallel"*
    (refers to the constant → correct).
- **Authoritative value:** `temporal/olympus_workflows/types.py:133` → `MAX_BC_CHILDREN_PER_APP = 12`.
  The cap is **applied by slicing** `bc_names[:MAX_BC_CHILDREN_PER_APP]` at `modernization.py:1786`; the
  overflow warning is at `:2160-2170` and the call-site truncation note at `:2789`. Truncation is at the
  **call site** (`_execute_generate`), not in the BC parser.
- **The regen spec is FAITHFUL:** `regen/13-generation-engine.md:39` — *"docstring/code mismatch on the
  fan-out cap … authoritative value is `MAX_BC_CHILDREN_PER_APP = 12` (`types.py:133`) … A rebuild MUST
  use 12, not 5."* (Also `regen/13-generation-engine.md:386`.)

### D-5. Phase-6 skill drift D1-D4 — [REPO DRIFT; partially SPEC FAITHFUL — all re-verified at HEAD]

- **D1 — `drift-detection` is `is_orchestration: true` yet ships a `SKILL.md`:** the registry block at
  `cross-cutting/skills/registry.yaml:2431-2437` declares `id: drift-detection`, `category: Product
  Verification`, `line: Governance`, `step: Activity 2 — Drift Detection`, **`is_orchestration: true`**
  (the **only** `true` in the file). The registry header convention (`registry.yaml:21-27`) states *"true:
  … does NOT have SKILL.md on disk."* **But** `cross-cutting/skills/drift-detection/SKILL.md` exists on
  disk (7,098 bytes) + a `fixtures/` dir. So the entry **violates its own convention** — an orchestration
  entry that nonetheless ships a skill body. Its `depends_on` lists the five real sub-skills
  (`drift-detection-architecture/-compliance/-performance/-cost/-adoption`); each of those **has** a
  SKILL.md on disk.
- **D2 — `extraction-*` variants registry-declared with no SKILL.md (only `fixtures/`):** the parent
  `extraction` entry (`registry.yaml:1174`, `is_orchestration: false`, `:1180`) declares
  `variants:` (`:1181` onward): `extraction-cobol`, `extraction-coldfusion`, `extraction-dotnet`,
  `extraction-java`, `extraction-python`. On disk:
  - `extraction-cobol/`, `extraction-java/`, `extraction-python/`, `extraction-coldfusion/` →
    **`fixtures/` ONLY, no SKILL.md**.
  - `extraction-dotnet/` → **HAS** SKILL.md (+ `fixtures/ references/ schemas/ scripts/ templates/`) — the odd one out.
  - None of the five variant ids is a registry **top-level** id; they live only under the parent's
    `variants:` list. Four variants are dispatchable-by-name yet have no skill body (they rely on the
    parent's SKILL.md + their own fixtures).
- **D3 — 3 FAA skills cite schemas in prose that DON'T exist on disk** (each re-confirmed MISSING across
  `schemas/`, `olympus-contracts/schemas/`, everywhere non-worktree):
  - `profiles/faa/skills/faa-form-schema-generator/SKILL.md:8` → `schemas/design/faa-form-schema.schema.json` — **MISSING**.
  - `profiles/faa/skills/medxpress-confirmation-binder/SKILL.md:8,56` → `schemas/cross-cutting/medxpress-confirmation-binding.schema.json` — **MISSING**.
  - `profiles/faa/skills/ame-decision-workflow-scaffolder/SKILL.md:9,58` → `schemas/design/ame-decision-tree.schema.json` — **MISSING**.
  - **⚠️ Prompt-attribution correction (still valid at HEAD):** the medxpress-missing-schema reference
    belongs to **`medxpress-confirmation-binder`**, NOT `aerospace-medical-certification-mapper`. The
    latter cites `schemas/design/medical-cert-class.schema.json` (`.../aerospace-medical-certification-mapper/SKILL.md:8,52`)
    **which EXISTS** (`schemas/design/medical-cert-class.schema.json`).
  - All three missing refs are draft-07 design schemas; `schemas/design/` is **EXCLUDED from `validate.sh`**
    (`regen/06-contracts/schemas-inventory.md:42`), so the dangling refs never trip CI.
- **D4 — the spec's own "113 SKILL.md declare schema paths" premise was wrong (already self-corrected):**
  `regen/11-skill-registry.md:42` — *"Only **35** SKILL.md files declare a frontmatter `output_schemas:`
  block (36 distinct paths; all 36 resolve)."* **[SPEC FAITHFUL]** — captured and corrected.

### D-6. Phase-0 environment findings — [REPO DRIFT; SPEC FAITHFUL — re-verified at HEAD]

- **HAProxy `least_conn` LB vs README's round-robin-DNS `8100-8109` model.** The README still documents the
  **pre-W14** model:
  - `README.md:256` — *"… Docker DNS round-robins to a different replica — cheap health-aware routing
    without a sidecar."*
  - `README.md:267,275` — describes the `8100-8109:8100` host-port range and embedded-DNS round-robin
    ("limited by the `8100-8109` host-port range").
  - **Actual compose** uses a single **HAProxy** LB on host `:8100` with `least_conn`:
    `docker-compose.yml:252-253` (*"`least_conn` so requests go to the least-loaded replica … rather than
    round-robin"*), `:341,344` (*"W14 (round-robin DNS) → task #200 (least_conn nginx LB)"*), `:428-442`
    (HAProxy rationale + `server-template`), `:457` (`"8100:8100"`).
  - **Spec FAITHFUL** — dissected at `regen/00b-environment.md:329` (the *"'8 agent replicas' actually
    scales the LB, not workers"* gotcha). `CLAUDE.md:54` ("8 agent replicas") maps to the
    `--scale olympus-agent-runtime=8` default.
- **`db/seeds/README` alembic-head snapshot is ~16 revisions stale.** `db/seeds/README.md:11` —
  *"alembic head `050`, captured 2026-05-20."* Live migration chain in `db/alembic/versions/` reaches
  **`066`** (**65** `.py` migration files; max numeric prefix `066`). The seeds README snapshot is **~16
  revisions stale.**
- **`demo-wait` HTTP-200 passes even when `/health/ready` is `not_ready`.** `Makefile:61-70` (`demo-wait`)
  polls `curl -s -o /dev/null -w "%{http_code}" .../health/ready` and accepts on `[ "$code" = "200" ]`.
  **But** the handler `olympus-api/src/routers/health.py:114-145` returns a **plain dict** with no
  `status_code` override → FastAPI serializes it as **HTTP 200 unconditionally** — even when
  `status = "not_ready"` (set at `:138` when Temporal `check_health()` fails **or** `get_skill_count()
  == 0`, `:124-137`). So `demo-wait` can declare the API "ready" while skills are unloaded / Temporal is
  down; only `demo-smoke` catches it (`scripts/demo_smoke.py` asserts `payload["status"] == "ready"`).
  **Spec FAITHFUL** — `regen/00b-environment.md:443`.

### D-7. `$id` host inconsistencies across `schemas/` — [REPO DRIFT; SPEC FAITHFUL with one count refresh]

From the Phase-1 schema inventory (`regen/06-contracts/schemas-inventory.md`). **`$ref` resolution and the
CI sample-validation store key off the literal `$id` string** (`schemas-inventory.md:15,131-132,186-189`).
Direct grep at HEAD over `schemas/`:

| `$id` host | # schemas | Dialect | Where / note |
|---|---:|---|---|
| `https://olympus.framework` | **80** | 2020-12 | dominant; `$id` matches repo path `schemas/<dir>/<file>.schema.json`, https, no trailing slash |
| `https://olympus.dev` | **3** | draft-07 | `schemas/modernization/modern-requirements`, `.../rule-reconciliation-matrix`, **and `schemas/profiles/delegation.schema.json`** (the 3rd — newer than the spec's "2") |
| `https://olympus.faa.gov` | **1** | 2020-12 | `schemas/rationalization/rationalization-clustering-plan.schema.json` — **TWO anomalies**: host is `faa.gov` not `framework`, AND the `$id` path ends `…clustering-plan.json` (no `.schema` segment) so `$id` ≠ file path |
| **(relative / no host)** | **15** | draft-07 | bare repo-relative `$id` strings (e.g. `"schemas/design/medical-cert-class.schema.json"`); all 6 in `schemas/design/` are here and are **EXCLUDED from `validate.sh`**. **Now also includes the 2 new Phase-6 build schemas** `schemas/build/requirements-capability.schema.json` + `schemas/build/scenario-spec.schema.json` |
| **(no `$id` at all)** | **24 samples** | — | `schemas/samples/*.sample.json` — none has `$id` |

(Total `.schema.json` files = **96**; **all 96** carry a `$id`. The 24 samples are separate.)

Load-bearing consequences flagged in the spec (all still valid):
- **Name collision** (`schemas-inventory.md:60`): `olympus-contracts/schemas/discovery/business-logic.schema.json`
  (title *"Business Logic Catalog"*, host `olympus.faa.gov`, draft-07) vs `schemas/discovery/business-logic.schema.json`
  (title *"Business Logic Inventory"*, host `olympus.framework`, 2020-12) — two different schemas, same
  relative path, different roots. Do not conflate.
- **`$ref` resolution depends on byte-for-byte `$id`-host match** (`:131-132`).
- **Hostless `$id` footgun** (`:186`) — relative `$id` → non-resolvable `base_uri`; harmless today, breaks any future `$ref`.
- **`globstar`-OFF glob reach** (`:124`): GitHub Actions `run:` under `bash -e` with `globstar` **off**;
  `schemas/**/*.schema.json` matches exactly **one** directory deep — a schema nested two levels deep would
  silently escape metaschema validation.

### D-8. Additional doc/impl mismatches (re-verified at HEAD — line numbers refreshed)

- **`traceability.py` module-docstring undercount** — the module docstring
  (`olympus-api/src/routers/traceability.py:1-9`) lists only **6** routes and OMITS
  `GET .../traceability/cross-validate`; there are **7** `@router.get` decorators (the cross-validate
  route is at `traceability.py:147`). A regenerator transcribing the docstring drops `cross-validate`.
  [SPEC FAITHFUL — `regen/01-api-traceability-bundles.md:87`.]
- **`analytics.py` module-docstring undercount** — the module docstring
  (`olympus-api/src/routers/analytics.py:1-11`) lists 11 lines (incl. `model-usage`) but **OMITS
  `GET /api/v1/analytics/portfolio-scoring`** (the heat-map route, `analytics.py:136`). A regenerator
  transcribing the docstring drops `portfolio-scoring`. [SPEC FAITHFUL — `regen/01-api-skills-analytics.md:7`.]
- **`bundles.py` docstring claims a signal it doesn't fire** — `bundles.py:14` —
  *"… the bundle is `accepted` and a Temporal signal is fired (chunk D)."* The signal fire is **not
  implemented** in the code (the wait/fire is roadmapped to chunk D). [SPEC FAITHFUL —
  `regen/01-api-traceability-bundles.md:18`.]
- **Workflow status strings absent from the DB CHECK constraint** — `WaveRationalizationWorkflow` /
  `wave_operations.py` references statuses like `awaiting-architecture-dispatch` (`wave_operations.py:136,166`)
  / `architecture-dispatched` / `architecture-complete` that are **not in the migration-049 CHECK
  constraint**; the `_update_wave_status_safe` wrapper swallows the resulting violation. [SPEC FAITHFUL —
  `regen/03b-activities/wave_operations.md:104`.]
- **`archetype` Python guard vs DB enum mismatch** — `temporal/olympus_workflows/activities/line_transitions.py:528-531`
  accepts `{"web-app","batch","api","scheduled-job","hybrid"}`, but the DB `archetype_enum` (migration
  `021`) permits `{'web-app','batch-etl','api-service','scheduled-job','hybrid'}` — values `"batch"` and
  `"api"` pass the Python guard but **violate the enum** at write time. [SPEC FAITHFUL —
  `regen/03b-activities/line_transitions-1-discovery-decomp-capability.md:252`.]
- **`agent_executor` ignores `config.json` for the *system prompt*** — `config.json` is loaded into
  `skill.config` but is **never injected into `build_system_prompt()`** (`agent_executor.py:193-…` folds
  body/references/assets/output_schemas/context only). **⚠️ PARTIAL REVERSAL at HEAD — see D-9 item 2:**
  config.json's `mcp_servers` ARE now wired into the SDK options. [SPEC PARTIALLY STALE —
  `regen/skill-authoring-contract.md:157`.]
- **`wait_for_gate_decision` does not wait** — `temporal/olympus_workflows/activities/gate_operations.py:996`:
  despite the name, it records the gate as pending and returns `status=GateStatus.PENDING` immediately
  (`:1027`); `decided_at` is set to "now" (`:1029`) even though no decision was made. The real wait is in
  the workflow via `gate_approved`/`gate_rejected` signals. [SPEC FAITHFUL —
  `regen/03b-activities/gate_operations.md:568`.]
- **`drift-detection` advisory mode swallows `NonRetryableError`** — `artifact_validation.py:10` (*"runs in
  advisory mode by default"*) + `:406-407` (*"Only raises `NonRetryableError` on environmental failures
  (schema file missing). That's a build/deployment bug …"*). A missing schema arrives wrapped as
  `ActivityError`; advisory mode catches it, logs `reason: validator-unavailable`, and returns as if
  nothing happened — a packaging defect that hides a schema **silently disables** that artifact's
  validation. [SPEC FAITHFUL — `regen/07-framework.md:1308`.]

### D-9. ⚠️ THREE landmines the `06-01` baseline recorded as LIVE are REVERSED at HEAD `7cb3b20c` — [SPEC STALE vs HEAD]

These were faithful against the `a1016458` baseline but the `git pull` to HEAD merged the fixes. **A
rebuilder targeting HEAD must invert these.** This is the most consequential delta in this revision.

1. **Output-schema validation is NO LONGER dormant on the live dispatch path** (HEAD commit `40d910fa`
   *"fix(platform): wire strict output-schema enforcement end-to-end (was silently disabled) (#593)"*).
   - The spec's central §2.5 + skill-authoring §[5]/§[9] landmine — *"THE ENTIRE validation + retry chain
     IS DORMANT because `skill.output_schemas` is ALWAYS `[]`; the dispatch API's `SkillDetail` has no
     such field/column"* (`regen/02-agent-runtime.md:582,252`; `regen/skill-authoring-contract.md:181,435`)
     — is now **FALSE on `main`**:
     - `olympus-api/src/models/skill.py:79` — `output_schemas: list[dict] | None = None` (**the field NOW
       EXISTS** on the API `SkillDetail` model).
     - `olympus-api/src/services/skill.py:32-38` populates it via `load_output_schemas_for_skill(skill_id)`;
       the in-code comment at `skill.py:27` confirms the regression history: *"… before this the dispatch
       response carried `output_schemas: null` …"*.
     - `olympus-agent-runtime/src/services/agent_executor.py:1710` now calls
       `validate_output_files(output_files, skill.output_schemas)` on the headless path, persisting a
       `_write_failure_marker` before cleanup for the retry loop (`:237-251` also inject the contract into
       the system prompt). The validator still short-circuits `if not schemas: return output_files`
       (`output_validator.py:169-170`) — but `schemas` is **no longer always empty.**
   - **Net for HEAD:** reproduce §2 validation as **ACTIVE** on the dispatch path, not dormant.
2. **`config.json` MCP servers are NOW wired into the SDK** (partial reversal of the §2.2 / D-8
   `config.json`-ignored landmine).
   - `olympus-agent-runtime/src/services/skill_loader.py:45` — `mcp_servers: dict = field(default_factory=dict)`
     (loaded from `config.json`).
   - `olympus-agent-runtime/src/services/agent_executor.py:1446-1448` — *"If skill defines MCP servers
     (from config.json), attach them"* → `if skill.mcp_servers: options.mcp_servers = skill.mcp_servers`.
   - **Net for HEAD:** the spec's *"config.json … does NOT populate MCP servers"* is now **STALE** — MCP
     servers ARE populated. Only the **system-prompt non-injection** half of the landmine remains true.
3. **`record_lineage` NOW WRITES DB state** (HEAD commit `97c800a8` *"docs(phase-6): GFI data cleansing +
   shared memory"* + surrounding Phase-6 work).
   - The activity was **relocated** out of `git_operations.py` into
     `temporal/olympus_workflows/activities/line_transitions.py`.
   - It now performs real writes: `INSERT INTO application_lineage (…)` at `line_transitions.py:3402`
     with `lineage_rows_inserted=lineage_inserted` (a computed variable, **not** a hardcoded 0) at
     `:3441,3454,7994,8047`; the helper `_upsert_capability_lineage` (`:6881`) does real UPSERTs into
     `capability_lineage` (`:6934,6952`) and `system_lineage` (`:6989`).
   - **Net for HEAD:** the spec's *"`record_lineage` writes no DB state; `lineage_rows_inserted` always 0"*
     (`regen/03b-activities/git_operations.md:362`) is **STALE** — at HEAD it writes lineage and reports
     actual row counts. (Note also the **path moved** `git_operations.py` → `line_transitions.py`.)

### D-10. NEW HEAD features the `06-01` baseline lacked — [informational; for anyone comparing to an older spec]

All present at HEAD and described by the refreshed `regen/` docs; flagged so an older-spec comparison
doesn't mistake them for additions-to-be-removed.

- **Build assembly line + 8th disposition.** `assembly-lines/build/README.md` — *"The Build line is
  Olympus's third downstream execution line … selected by the `Build` disposition — the 8th disposition
  (Phase 6 W5) — for net-new, greenfield applications … no legacy source code to extract."* It replaces
  Modernization's `Extract` with a `spec-from-requirements` step, reuses Design/Generate unchanged;
  escalation is *"Refine Spec"*. Runtime contract:
  `olympus-contracts/.../data/assembly-lines/build.yaml`; design:
  `specifications/phase-6/greenfield-build-line.md`. New API surface: `olympus-api/src/models/interview.py`,
  `olympus-api/src/services/interview.py` (Requirements Interview UI/workflow, P6-S5.12/5.13, commit
  `82195e7a`). New schemas: `schemas/build/requirements-capability.schema.json`,
  `schemas/build/scenario-spec.schema.json`.
  - **NOTE the writing-guideline drift this introduces:** `CLAUDE.md` still says *"Olympus uses **7**
    dispositions"* and lists *"Retire, Retain, Refactor, Rearchitect, Replace, Replatform, Consolidate"* —
    the **8th (`Build`) is now live** but absent from that CLAUDE.md sentence. [REPO DRIFT — CLAUDE.md lags.]
- **DevSecOps generation + validation activities (Phase 6 W11).**
  - `temporal/olympus_workflows/activities/devsecops_validation.py` — deterministic baseline validator
    (*"the agent GENERATES the baseline; this activity only confirms it"*): asserts required repo-root
    baseline files exist + cheap structural checks (`ci.yml` parses with 7 required jobs + profile-correct
    SAST job; `dependabot.yml` / `branch-protection.yml` valid YAML; IaC manifest validates against
    `iac-scaffolding-generator`'s `output.schema`). Its boolean result **gates G-04c**.
  - `temporal/olympus_workflows/activities/profile_devsecops.py` — resolves the active profile's
    `devsecops:` block (`sast_tool`, `target_cloud`, `container_base`, `license`, `primary_ecosystem`,
    `iac`, `cicd`) and folds it into `AgentTaskInput.context['devsecops_baseline']`.
  - Spec: `specifications/phase-6/devsecops-generation.md`.
- **Multi-provider agent dispatch (Phase 6 W2 / P6-S2.2).** `olympus-agent-runtime/src/providers/` now
  holds a provider factory registered at import (`providers/__init__.py:13` — *"each module triggers its
  `register(...)` call"*): `bedrock_claude.py`, `bedrock_llama.py`, `bedrock_mistral.py`, `openai_provider.py`,
  `gemini_vertex.py`, plus `_bedrock_converse_scaffold.py`. Selected via
  `olympus-agent-runtime/src/config.py:33` → `inference_provider: str = "bedrock-claude"` (composite
  provider id, default Claude on Bedrock).
- **AgentCore Memory/Gateway spike (Phase 6 W3 / P6-S3) — SPIKE/THROWAWAY, feature-flagged OFF by
  default.** `olympus-agent-runtime/src/services/memory_backend.py` introduces a `MemoryBackend`
  interface beneath the provider layer (provider-agnostic; behind the A2A/Temporal-activity boundary;
  **no AgentCore Runtime** client). Config (`olympus-agent-runtime/src/config.py:90-98`):
  `olympus_agentcore_memory_enabled: bool = False`, `olympus_agentcore_gateway_enabled: bool = False`
  (env `OLYMPUS_AGENTCORE_MEMORY_ENABLED` / `OLYMPUS_AGENTCORE_GATEWAY_ENABLED`), optional
  `agentcore_memory_id: str = ""`. **No `OLYMPUS_AGENTCORE_RUNTIME_ENABLED` flag** (deliberate —
  Runtime would displace the Temporal activity boundary). Flag-off path returns
  `LocalWorkspaceMemoryBackend`, delegating verbatim to existing executor functions; `boto3` /
  `bedrock-agentcore` imported lazily inside guarded methods. Spec:
  `specifications/phase-6/cloud-native-agent-spike.md`. `agent_executor.py:1249-1252` resolves the backend
  via `resolve_memory_backend(get_config())`.

### D-11. Other minor doc/impl mismatches found in this audit

- **`temporal/dynamicconfig.yaml` comment-vs-value lag** — `infra/temporal/dynamicconfig.yaml:15-16`
  comments cite the *old* defaults *"limit.blobSize.warn = 512 KiB / error = 2 MiB"*, but the **actual**
  configured values are `warn: 1048576` (**1 MiB**, `:24`) and `error: 4194304` (**4 MiB**, `:26`). The
  spec's §2.11 phrasing ("raises warn/error from 512 KiB/2 MiB") describes the pre-change baseline; the
  live error cap is **4 MiB**, not 2 MiB. [Minor — values are self-consistent; only the comment narrates the old baseline.]
- **Contract enum name: `RiskTier`, not `TierLevel`** — the `IntEnum` the spec's §2.1 landmine calls
  *"`TierLevel`"* is actually `class RiskTier(enum.IntEnum)` at `olympus-contracts/olympus_contracts/enums.py:44`
  (*"Uses IntEnum (not `int, Enum`) so Temporal's default payload converter … special-cases
  IntEnum/StrEnum subclasses"*, `:47-49`). The behavioral claim (IntEnum round-trips 1/2/3 as ints) is
  correct; only the **type name** in the spec text differs. [Cosmetic — rebuilder must name it `RiskTier`.]

---

## SECTION 2 — MASTER `⚠️ GOTCHA` LANDMINE LIST

**Scale note (read first — counts refreshed at HEAD `7cb3b20c`).** A raw `grep -rn "GOTCHA" regen/`
returns **3,257** lines; excluding the orchestration/audit scratch dirs (`regen/.workflows/`,
`regen/.audit*`, `regen/_audit/`) yields **3,223** genuine gotcha-callout lines across the authoritative
`regen/` docs. **These counts GREW substantially since the spec was frozen** (the prior register recorded
~2,227 callouts / 1,309 in Workflows) because the refresh-to-HEAD expanded the per-doc landmine coverage —
most heavily in Workflows (now **2,168**) and Contracts (now **401**). A verbatim dump would be ~300 KB
and unusable. This register provides, **per area**: (a) the callout count, (b) the authoritative source
docs (open them for the exhaustive list), and (c) the **highest-value** landmines with exact `path:line`.
**The per-doc `regen/` files remain the exhaustive, authoritative source; this is the triage layer.**

**Distribution (3,223 callouts / 11 areas, measured at HEAD):**

| Area | Callouts | Authoritative source docs |
|---|---:|---|
| Workflows | 2,168 | `regen/03-workflows/*.md` (32 files) |
| Contracts & schemas | 401 | `regen/06-contracts.md`, `regen/06-contracts/*.md` |
| API & services | 155 | `regen/01-api*.md` |
| Activities | 134 | `regen/03b-activities/*.md` |
| Framework / profiles / skill-authoring | 129 + 37 | `regen/07-framework*.md`, `regen/skill-authoring-contract.md` |
| Agent runtime | 52 | `regen/02-agent-runtime.md` |
| Generation engine / Ralph | 38 | `regen/13-generation-engine.md` |
| Dashboard | 38 | `regen/05-dashboard*.md` |
| Build / CI / env / overview / regen-order | 31 + 16 + 4 | `regen/00-overview.md`, `regen/00b-environment.md`, `regen/08-build-ci.md`, `regen/09-regeneration-order.md` |
| Data layer | 8 | `regen/04-data-layer*.md` |
| Skill registry | 8 | `regen/11-skill-registry.md`, `regen/11-skill-registry-wiring.md` |

> The areas below carry the **highest-value** landmines. Numbers are HEAD counts; per-file indices for the
> dense areas (Workflows, Contracts) are in the prior register / the per-doc files themselves.

### 2.1 CONTRACTS & SCHEMAS (401 callouts)

- **DELIBERATELY NO `from __future__ import annotations`** in `signals.py` — reproduce the *absence*
  exactly. The eager form is required because Temporal's payload converter resolves field types via
  `typing.get_type_hints` against module globals; deferred string annotations force `Any` lookups that
  fail at runtime (`NameError` in the worker, the W8 `card_decisions` regression). The codebase records
  this in an explicit NOTE comment at `olympus-contracts/olympus_contracts/signals.py:12-18`.
  `regen/06-contracts.md:338`.
- **`RiskTier` is `IntEnum`, NOT `(int, Enum)`** — the default payload converter special-cases `IntEnum`
  so 1/2/3 round-trip as ints across workflow boundaries (`enums.py:44-49`). `regen/06-contracts.md:139`.
  *(Spec text calls this `TierLevel`; the class is `RiskTier` — see §1 D-11.)*
- **GateType value-case is irregular and load-bearing** — `G_04A/B/C` → lowercase-suffixed `"G-04a/b/c"`
  (`enums.py:108-110`), but `G_DC/G_RR/G_DA/…` are all-uppercase (`enums.py:103-…`); these strings are
  DB-column / URL / Git-commit ids, one char breaks everything. `regen/06-contracts.md:207`.
- **No `retryable` attribute exists anywhere** — retryable-ness is encoded purely by exception class and
  enforced externally by Temporal's `non_retryable_error_types`. `regen/06-contracts.md:507`; the one
  retryable git error is retryable only because its name is *omitted* from the policy list, `:525`.
- **GateType→str has a double fallback** — `except ValueError` (invalid input) AND `.get(key,
  str(gate_type))` (valid-but-unmapped, e.g. an extension-registry gate). `regen/06-contracts.md:245`.
- **`lru_cache(maxsize=1)` loads YAML once per process** — runtime YAML edits no-op until
  `_load_all.cache_clear()`; every test does this in `setup_function`. `regen/06-contracts.md:755`.
- **`card_decisions` uses `field(default_factory=list)`** — never a bare mutable default; the per-card
  5-key dict is a contract read by rework logic — preserve key names. `regen/06-contracts.md:367`.
- **Gate-id namespace collision when counting steps** — a naive `grep "^  - id:"` over
  `rationalization-steps` returns 25 but 2 are `gates:` entries (G-RR, G-DA); the `steps:` list has
  exactly **23**. `regen/06-contracts/rationalization-steps.md:11`.
- **Asymmetric `parallel_with`** in architecture steps — step lists only `[well-architected-review]` while
  three post-blueprint evidence steps fan out. `regen/06-contracts/architecture-steps.md:486`.
- **`$id`-host inventory / name collision / `globstar`-OFF glob reach** — see §D-7.
  `regen/06-contracts/schemas-inventory.md:60,124,131-132,186`.

### 2.2 WORKFLOWS (2,168 callouts; 32 files — the largest area; consult the per-file docs exhaustively before touching any workflow)

- **DataRouter Step-3 first-match determinism** — `tokens` is a Python `set` (unstable iteration order);
  determinism holds only because every database token maps to the same target. `regen/03-workflows/DataRouter.md:201`.
- **DataRouter priority is strict & short-circuiting** — Step 1 (mainframe) ALWAYS wins over Step 2/3: a
  NATURAL/COBOL shop with a SQL Server replica routes to `data-product-design-mainframe`. `regen/03-workflows/DataRouter.md:198`.
- **DataRouter is consulted for EXACTLY one step name** — the literal `"data-product-design"`. `regen/03-workflows/DataRouter.md:30`.
- **DataRouter token-bag source keys are fixed** — only `languages/frameworks/platforms/tech_stack` (+
  scalar `tech_family`); `database`/`primary_language` are NOT flattened here. `regen/03-workflows/DataRouter.md:157`.
- **Child-spawn defaults** — several child workflows are spawned with NO explicit
  retry/timeout/cancellation-type (inherit Temporal defaults). `regen/03-workflows/WaveWorkflow.md:324`.
- **`pending_gate` is NEVER set → always defaults to `None`** in AppWorkflow queries. `regen/03-workflows/AppWorkflow.md:481`.
- **G-04b merge uses the DEFAULT merge method** in the reconcile-and-merge retry loop. `regen/03-workflows/ModernizationWorkflow-1-state-extract-design.md:1145`.
- **Governance step-10 DB write is best-effort** — try/except logs + swallows; a DB failure never blocks
  the step. `regen/03-workflows/GovernanceWorkflow.md:697`.
- **Wave-rationalization validation is advisory & never blocks** — an `ActivityError` (schema missing /
  NonRetryable) is logged, not raised. `regen/03-workflows/WaveRationalizationWorkflow-2-run-execute-a.md:222`.
- **DataWorkflow `data-parallel-fanout-v1` patch must be reproduced verbatim** for replay determinism. `regen/03-workflows/DataWorkflow.md:585`.

### 2.3 API & SERVICES (155 callouts; 12 files)

- **FastAPI route mount order matters** — literal `POST /upload` (`applications.py:203`) is declared
  BEFORE the `{app_id}` path routes so it isn't swallowed; preserve file order.
  `regen/01-api-applications.md:16`. Same trap for escalations: `/metrics` (`escalations.py:219`) must
  precede `/{escalation_id}` (`:283`). `regen/01-api-gates-escalations.md:886`.
- **`require_application_member` is a route dependency** that runs even when the handler doesn't take
  `user`; resolves `get_current_user` (401) AND membership, and does its own plain-text 404 that can RACE
  the handler's structured 404. `regen/01-api-applications.md:52`.
- **Portfolio filter is an INTERSECTION** — `portfolio_id = :portfolio_id` AND `= ANY(:pf_ids)` both apply
  for non-admin; explicit non-member portfolio → 403, explicit-member-but-out-of-allowlist → empty
  result (not 403). `regen/01-api-applications.md:117`.
- **501 scaffold path returns a hand-rolled `JSONResponse`** (NOT `OlympusHTTPException`); `request_id` is
  `""` and header `X-Implementation-Status: scaffold` is set — preserve both. `regen/01-api-applications.md:157`.
- **`ApplicationCreate` model-validator runs at body parse** — GIT requires `repository_url` (422 else),
  ZIP skips validation, every other type requires `source_uri`. `regen/01-api-applications.md:158`. Zip
  intake: `UPLOAD_TOO_LARGE → 413`, all other intake errors → 422. `regen/01-api-applications.md:213`.
- **Dev-permissive auth defaults** — `AUTH_SKIP_VERIFICATION=true` and `DEV_AUTH_BYPASS=true`; preserve
  env-var names and defaults. `regen/01-api-registries.md:50`.
- **Registry writes are in-process only** — they do NOT persist to profile YAML; module-level singletons
  populated at import + `activate_profile()` in the lifespan; restart resets. `regen/01-api-registries.md:59`.
- **`profile == "default"` (case-insensitive) deactivates the profile + resets registries**; switching
  mid-flight is blocked (409) for Temporal determinism. `regen/01-api-portfolio-lines-misc.md:478`.
- **`traceability.py` docstring undercounts (6 vs 7 routes)** — do not drop `cross-validate`.
  `regen/01-api-traceability-bundles.md:87`. (Also §D-8.)
- **cATO governance math** — per-control status is uniform across all 11 controls (derived from system
  `cato_state`); totals are control-COUNTS (each system contributes 11). `regen/01-api-governance-systems.md:394`.

### 2.4 ACTIVITIES (134 callouts; 13 files)

- **Workflow sets statuses NOT in the CHECK constraint** (`architecture-dispatched`, `awaiting-architecture-dispatch`)
  — the safe wrapper swallows the violation. `regen/03b-activities/wave_operations.md:104`. (Also §D-8.)
- **`archetype` Python guard accepts values the DB enum rejects** (`"batch"`,`"api"`).
  `regen/03b-activities/line_transitions-1-discovery-decomp-capability.md:252`. (Also §D-8.)
- **`GitServiceError` is classified NON-retryable** because the substring matcher keys off the type's repr
  (`connection`/`timeout`), and `GitService` converts GitHub failures into `GitServiceError` whose repr
  doesn't match — transient GitHub blips do NOT retry. `regen/03b-activities/disposition_outputs.md:25`;
  classifier keys off the type-repr string, `regen/03b-activities/gate_operations.md:50`.
- **create-vs-update decided by a 404 probe, not tracking** — concurrent commits to the same path/branch
  can race (lost update / 409). `regen/03b-activities/disposition_outputs.md:175`.
- **`ContextPrior` dataclass exists but the activity returns raw `list[dict]`** with 4 keys; callers do
  `getattr(result,"priors",None) or []`. `regen/03b-activities/context_priors.md:69`.
- **Data status-marker ordering bug** — `data_current_status="data_complete"` is appended BEFORE the
  nothing-extractable check, so a non-empty `cluster_rows` with empty scalar projections still fires the
  UPDATE. `regen/03b-activities/line_transitions-3-architecture-data.md:504`.
- **Single `UPDATE … RETURNING` is the atomic claim primitive** — two concurrent consumers race under
  asyncpg autocommit; PG row-locks, first wins. `regen/03b-activities/arch_data_registry.md:227`.
- **`wait_for_gate_decision` does not wait** — returns PENDING immediately; `decided_at` set to "now"
  regardless (`gate_operations.py:996,1027,1029`). `regen/03b-activities/gate_operations.md:568`. (Also §D-8.)
- **⚠️ HEAD REVERSAL — `record_lineage` NOW writes** (was the §D-8 "writes nothing" landmine; relocated to
  `line_transitions.py`, real `INSERT`/UPSERT). See §1 D-9 item 3. `regen/03b-activities/git_operations.md:362` is **STALE** at HEAD.

### 2.5 AGENT RUNTIME (52 callouts; `regen/02-agent-runtime.md`)

- **⚠️ HEAD REVERSAL — the §2 validation + §2.6 retry chain is NO LONGER dormant on the live dispatch path.**
  The spec's central landmine — *"`skill.output_schemas` is ALWAYS `[]` … `validate_output_files`
  short-circuits at `IF not schemas: RETURN`"* (`regen/02-agent-runtime.md:582,252`) — was true at the
  `06-01` baseline but is **FALSE at HEAD** (commit `40d910fa`): `SkillDetail.output_schemas` now exists
  (`olympus-api/src/models/skill.py:79`), is populated (`olympus-api/src/services/skill.py:32-38`), and is
  enforced live (`agent_executor.py:1710` `validate_output_files`). See §1 D-9 item 1. **Reproduce §2 as
  ACTIVE, not dormant, for a HEAD rebuild.** (The `if not schemas: return` short-circuit at
  `output_validator.py:169-170` still exists but is no longer always taken.)
- **Workspace-cleanup asymmetry** — cleanup runs ONLY on SDK-failure, validation-failure (after the
  marker), and success/no-result tails; the setup-failure and artifact-fetch-failure early-returns do NOT
  clean up. `regen/02-agent-runtime.md:292`.
- **"exactly one feedback retry" comment is wrong** — the actual Temporal policy allows up to **3** total
  attempts (`maximum_attempts=3`), each reading the prior attempt's marker; `RetryableError` raised on the
  3rd. `regen/02-agent-runtime.md:728`.
- **`us.` region prefix applied at runtime** — stored base ids have no prefix; bedrock provider prepends
  `{prefix}.` (default `us`) → `us.anthropic.claude-sonnet-4-6[1m]`; the `[1m]` (1M-context variant) is
  part of the id, preserved verbatim. `regen/02-agent-runtime.md:804`.
- **Production refuses mock (LOUD FATAL) at worker startup** — DECISION-018;
  `olympus-worker/src/worker.py:100` calls `config.validate_agent_runtime_mode()` which raises
  `MockInProductionError` (`olympus-worker/src/config.py:28`) before connecting to Temporal; invalid
  values → `InvalidAgentRuntimeModeError` (`config.py:24`). `regen/02-agent-runtime.md:842`.
- **`permission_mode="acceptEdits"`** silently accepts file edits in allowed dirs (no human prompt in
  headless dispatch). `regen/02-agent-runtime.md:1235`.
- **Health reads `Semaphore._value` (private attr)** — `active = _max_concurrent - _task_semaphore._value`;
  `/health/ready` returns `"busy"` but **still HTTP 200** at saturation; `_max_concurrent` default 4 is
  overwritten to 12 at startup. `regen/02-agent-runtime.md:1237`.
- **⚠️ HEAD PARTIAL REVERSAL — `config.json` MCP servers ARE now wired** (`agent_executor.py:1446-1448`,
  `skill_loader.py:45`); only the system-prompt-non-injection half of the old landmine remains. See §1 D-9 item 2.
- **API↔loader field-name mapping** — loader reads `skill_path` (not `skill_dir`),
  `references_data/assets_data/config_data`; `model_tier` defaults to `tier-2` if omitted. `regen/02-agent-runtime.md:1156`.

### 2.6 GENERATION ENGINE / RALPH LOOP (38 callouts; `regen/13-generation-engine.md`)

- **Ralph cap is `<` not `<=`** — `while self._iteration < MAX_RALPH_ITERATIONS` (`generate_bc.py:96`) with
  `self._iteration += 1` as the FIRST body statement (`:97`) → body runs `_iteration` 1..10 inclusive =
  exactly 10 iterations. `regen/13-generation-engine.md:43`.
- **Fan-out cap docstring mismatch (max 5 vs 12)** — authoritative `MAX_BC_CHILDREN_PER_APP = 12`
  (`types.py:133`). `regen/13-generation-engine.md:39`. (See §D-4.)
- **Truncation happens at the CALL SITE, not the parser** — `parse_bc_names_from_yaml` returns ALL names;
  the cap is applied by `bc_names[:MAX_BC_CHILDREN_PER_APP]` in `_execute_generate`
  (`modernization.py:1786`). `regen/13-generation-engine.md:386`.
- **`run_suffix` is parsed from the workflow id** — substring after the last `-`, or first 8 chars if no
  `-`. `regen/13-generation-engine.md:126`.
- **Read is from the `main` branch** — the BC parser reads `branch="main"`, relying on G-04b having merged
  the Design PR to main. `regen/13-generation-engine.md:384`.
- **Rework re-fans-out from scratch** — on G-04c rejection the loop re-parses BCs from main, re-spawns all
  child `GenerateBCWorkflow`s with the SAME ids; child-id-reuse policy applies. `regen/13-generation-engine.md:478`.
- **A hard agent failure never reaches the stop-condition** — `dispatch_agent_task` raising propagates out
  of `run`, the child fails, the parent's `gather` re-raises. `regen/13-generation-engine.md:659`;
  escalation dispatch can ALSO hard-fail the child, `:781`.
- **`self._input` is NOT set in `run`** — `_workflow_input_prior_artifacts` does
  `getattr(self,"_input",None)` → `[]`. `regen/13-generation-engine.md:89`.
- **Frontend checked BEFORE framework** — if both `target_frontend` and `target_framework` match, frontend
  wins; fan-out default framework `express → code-generation-node`, frontend default
  `react → code-generation-react`; BCs named `{frontend,ui,web-app,spa}` (case-insensitive) get the
  frontend path. `regen/13-generation-engine.md:841,845`.

### 2.7 FRAMEWORK / PROFILES / SKILL-AUTHORING (129 + 37 callouts; 3 files)

- **Advisory mode swallows even the environmental `NonRetryableError`** (missing schema → silently
  disabled validation; `artifact_validation.py:406-407`). `regen/07-framework.md:1308`. (Also §D-8.)
- **A line `workflow_id` is time-stamped and NOT idempotent** — `f"{line_slug}-{app_id}-{run_ts}"` embeds
  a UNIX timestamp; an activity retry at a different second starts a SECOND child workflow. `regen/07-framework.md:1516`.
- **Registry registration uses staging-then-rollback ordering** — entity inserted into `_entities` BEFORE
  cycle detection, removed/restored on failure; a rejected registration leaves `_entities` byte-for-byte
  unchanged. `regen/07-framework.md:207`.
- **Profile overrides are idempotent by construction, not by guard** — idempotency emerges from
  `replace_all` / clear-then-readd. `regen/07-framework.md:862`.
- **`allowed-tools` (hyphen) vs `output_schemas` (underscore)** — different separators; the loader reads
  each literally, a misspelling **silently drops** the field. `regen/skill-authoring-contract.md:124`.
- **Frontmatter `name` MUST equal the directory name** — loader falls back to dir name only if `name` is
  absent, so a mismatch **silently mislabels** the skill. `regen/skill-authoring-contract.md:72`.
- **YAML-parse failure in frontmatter does NOT fail the load** — `YAMLError` swallowed → frontmatter `{}`
  → skill silently loads as tier-2, no tools, no schemas. `regen/skill-authoring-contract.md:109`.
- **`config.json` is loaded but never injected into the system prompt** — note the HEAD partial reversal:
  MCP servers ARE now wired (§1 D-9 item 2). `regen/skill-authoring-contract.md:157`.
- **SKILL.md sections [5] Output Contract & [9] validation-retry feedback** — the spec marks these DORMANT
  on the live API-load path; **at HEAD they are LIVE** (§1 D-9 item 1). `regen/skill-authoring-contract.md:181,435`.

### 2.8 DASHBOARD (38 callouts; 3 files)

- **Top-level theme side effect** — `useTheme.ts:23-24` runs
  `document.documentElement.setAttribute("data-theme", initial)` at MODULE load (before any render).
  `regen/05-dashboard.md:498`, `regen/05-dashboard-design-system.md:173`.
- **Provider order matters** — `useChatContext` (consumed in Layout) must be wrapped correctly; reproduce
  the provider nesting exactly. `regen/05-dashboard.md:54,73`.
- **npm `overrides` block is REQUIRED** (`package.json:42-49`) — pins transitive deps. `regen/05-dashboard-design-system.md:52`.
- **No USWDS JS init** — the dashboard imports only USWDS CSS; no USWDS JS. `regen/05-dashboard-design-system.md:93`.
- **Runtime network dependency (mermaid CDN)** — offline/air-gapped builds fall back. `regen/05-dashboard-design-system.md:120`.
- **Visited-link color pinned** (`base.css:119-126`, `a:visited { color:#005ea2 }`). `regen/05-dashboard-design-system.md:210`.
- **Markdown renderer composition** — caller `components` win EXCEPT mermaid `code` → `MermaidBlock` and
  `pre` default; `replaceEmojiShortcodes` runs BEFORE render. `regen/05-dashboard-components.md:136`.
- **Derived-state-from-prop pattern** — components reset state DURING render on prop change; a microtask
  defer is used elsewhere for the same lint. `regen/05-dashboard-components.md:100,221`.

### 2.9 BUILD / CI / ENV / OVERVIEW / REGEN-ORDER (31 + 16 + 4 callouts)

- **COVERAGE FLOORS IN THE PROMPT AND CLAUDE.md ARE WRONG** — reproduce the `pyproject`
  `--cov-fail-under` numbers, not the prose. `regen/08-build-ci.md:9`. **Coverage floors only move UP**
  (DECISION-017). `regen/00-overview.md:64`, `regen/09-regeneration-order.md:515`.
- **`demo-wait` accepts HTTP 200 even when `not_ready`** — `/health/ready` always 200. `regen/00b-environment.md:443`. (See §D-6.)
- **"8 agent replicas" actually scales the LB, not workers** — runtime pool scales via
  `${AGENT_REPLICAS:-3}` / `--scale olympus-agent-runtime=N`. `regen/00b-environment.md:329`. (See §D-6.)
- **Temporal history/blob size raised as a band-aid** — `infra/temporal/dynamicconfig.yaml:24,26` raises
  warn→1 MiB / error→4 MiB (comments at `:15-16` cite the old 512 KiB/2 MiB) because AAM Discovery
  gate-evidence (42 artifacts) produces ~5.7 MiB history + ~2.1 MiB activity input. `regen/00b-environment.md:337`. (See §D-11.)
- **Build graph ≠ boot graph** — two distinct orderings coexist; the determinism contract is procedural,
  not enforced. `regen/09-regeneration-order.md:35,211`.
- **Rate limiting OFF in compose** — `RATE_LIMIT_ENABLED: ${RATE_LIMIT_ENABLED:-false}`
  (`docker-compose.yml:175`); the dashboard fires 15-20 requests per nav and would trip the default
  60/min/IP limit, leaving "no data" until refresh. `regen/00b-environment.md:129`.
- **`load_context_priors` needs an env var** — resolves priors from `<root>/context-priors/manifest.yaml`;
  without the env var priors silently return empty. `regen/00b-environment.md:159`.
- **`AGENT_RUNTIME_MODE` defaults to `live`** — setting `mock` while `APP_ENV ∈
  {production,prod,staging,stage}` raises `MockInProductionError` at startup
  (`olympus-worker/src/config.py:14-16,24,28`); invalid values → `InvalidAgentRuntimeModeError`.
  `regen/00b-environment.md:292`.

### 2.10 DATA LAYER (8 callouts; 4 files)

- **TTL travels inside JSONB under `_expires_in_hours`, NOT a dedicated column** — the CLAIM handler reads
  it to compute `expires_at = claim_time + hours`, then strips all `_`-prefixed keys when merging the
  caller descriptor; `None` → column stays NULL. `regen/04-data-layer-platform-tables.md:540`.
- **Do NOT add DB CHECK constraints to sweep tables** — columns accept any string; the gate is
  application-layer; adding a CHECK would diverge. `regen/04-data-layer-sweep-tables.md:27`.
- **CASCADE + NOT NULL `app_id`** — deleting an `application` row mass-deletes all its
  `sla_compliance_record` rows. `regen/04-data-layer-sweep-tables.md:130`.
- **`gate_status_enum` shape must be reproduced verbatim.** `regen/04-data-layer.md:61,76`.

### 2.11 SKILL REGISTRY (8 callouts; 2 files)

- **The "113 SKILL.md declare schema paths" premise is WRONG — only 35 do.** `regen/11-skill-registry.md:42`. (See §D-5/D4.)
- **Two different "category" axes** — section comments (assembly-line) are organizational only; the
  authoritative taxonomy is the per-entry `category:` field (19 values), orthogonal to `line:`. CLAUDE.md
  "137 skills / 12 categories" snapshot is stale. `regen/11-skill-registry.md:187`.
- **Step-1 13-skill list is the AVAILABLE set, not all dispatched.** `regen/11-skill-registry-wiring.md:52`.
- **Disposition-strategy skills are NOT wired as step `skills:` in the YAML.** `regen/11-skill-registry-wiring.md:288`.

---

## SECTION 3 — EVERY `TODO/FIXME/HACK/XXX` IN NON-TEST SOURCE (at HEAD `7cb3b20c`)

`grep -rnE "TODO|FIXME|HACK|XXX|BUG:"` over `olympus-api/src`, `olympus-agent-runtime/src`, `mcp-server`,
`temporal/olympus_workflows`, `dashboard/src`, `olympus-contracts` (`*.py`/`*.ts`/`*.tsx`), excluding tests
and `.claude/worktrees/`. **Exactly 8** hits at HEAD. **No `FIXME`, `HACK`, `XXX`, or `BUG:` markers exist
in non-test source — all 8 are `TODO`.** Five are one logical cluster (stub source-intake connectors).

1. **`olympus-api/src/services/source_intake.py:502`** — inside `_ScaffoldProvider.unpack()`
   (`source_intake.py:484`), which raises `SourceIntakeNotImplemented("SOURCE_TYPE_NOT_IMPLEMENTED",
   f"… scaffolded but not yet implemented. TODO: {self.todo}")` (`:500-502`). Base class for all
   not-yet-built source connectors; surfaces the per-subclass `todo` string in the error.
2. **`olympus-api/src/services/source_intake.py:509`** — `ConfluenceSourceProvider` (`:506`) docstring
   TODO: *auth via Atlassian API token + email header; iterate pages under the space key via REST
   `/wiki/rest/api/content`; write each page body as markdown to the workspace.*
3. **`olympus-api/src/services/source_intake.py:524`** — `SharePointSourceProvider` (`:521`) docstring
   TODO: *auth via Azure AD client credentials; use Microsoft Graph `/sites/{siteId}/drive/items` to walk
   the library; download each file preserving folder layout.*
4. **`olympus-api/src/services/source_intake.py:539`** — `GDriveSourceProvider` (`:536`) docstring TODO:
   *auth via service account + domain-wide delegation; walk the folder via Drive v3 `files.list`; export
   Docs→markdown, Sheets→csv, else raw bytes.*
5. **`olympus-api/src/services/source_intake.py:554`** — `GCSSourceProvider` (`:551`) docstring TODO: *use
   `google-cloud-storage` with application-default credentials; list blobs under `gs://bucket/prefix`;
   download each preserving the key layout.*
   - **Intent (items 1-5):** these source types are deliberately **scaffolded-not-implemented**; calling
     `unpack()` raises a structured `501`-style error carrying the `todo`. A rebuild MUST preserve the
     scaffold (the provider subclasses + the raised code `SOURCE_TYPE_NOT_IMPLEMENTED`) — intentional
     stubs, not bugs.
6. **`dashboard/src/shared/components/workflowActions.ts:290`** — in the `reset-line` case: *"TODO:
   advanced reset modes (before_step / at_event) — surface a secondary affordance once the power-user UX
   is designed."* Currently hard-codes `resetWorkflow(appId, { mode: "before_failure" })` (`:292`).
7. **`dashboard/src/shared/components/appActions.ts:420`** — identical TODO in the `reset-workflow` case
   (sibling dispatcher): same `{ mode: "before_failure" }` default (`:422`), same future
   `before_step`/`at_event` modes.
   - **Intent (6-7):** the reset UX intentionally ships only the `before_failure` mode; the server computes
     the reset event id; advanced modes await a future power-user UX. Preserve the single-mode behavior.
8. **`dashboard/src/pages/GateReview/GateReview.tsx:292`** — *"TODO: remove the cast once
   `GateEvidencePackage` carries the field natively."* (Phase 5 W20 / Chunk F.) `bundle_evidence_source`
   is read defensively via an `as unknown as {…}` cast because the gate API extension that populates it is
   still roadmapped (design memo §10.5, narrated at `:288-291`).
   - **Intent:** the cast is a deliberate forward-compat shim so the Chunk-D workflow integration can flip
     the field on without further dashboard work — preserve the defensive read.
