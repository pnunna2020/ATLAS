---
name: faa-form-family-catalog-expander
description: >
  Cross-link every FAA form (`Form 8500-8`, `Form 8710-1`, `Form 8710-11`,
  `Form 8060-71`, `Form 8060-4`) to the apps that implement, validate,
  sign, store, or produce downstream output from it. App-to-app-level
  catalog counterpart to the source-code-level `form-8710-family-
  extractor`. Produces a portfolio-wide form-to-app dependency map
  that downstream `capability-consolidation-advisor` and
  `wave-planner` consume to sequence form-handling modernization.
  Runs as a Discovery supplementary skill when ≥1 app in the
  portfolio carries FAA form implementation. Triggers on FAA form
  catalog expansion, form-handling consolidation analysis, or
  @faa-form-family-catalog-expander.
agent: sonnet
allowed-tools:
  - Read
  - Write
  - Grep
  - Glob
validation_commands:
  - "python -m olympus.validators.schema_validator faa-form-catalog.json"
  - "python -m olympus.validators.schema_validator faa-form-role-assignments.json"
supported_stacks:
  - faa-form
  - form-8500
  - form-8710
  - form-8060
anti_target_stacks:
  - non-faa
  - static-site
failure_classes:
  - form-variant-conflated-with-form-family
  - signature-producer-vs-storage-merged
  - downstream-consumer-chain-truncated
  - per-app-variant-number-lost
benchmark_tags:
  - discovery-supplementary
  - faa-form-catalog
  - form-modernization-sequencing
  - multi-app-form-handling
---

# faa-form-family-catalog-expander

## Purpose
For each FAA form in scope, enumerate which apps play which role
(implementer, validator, signer, storer, downstream consumer) and
produce a catalog that preserves form-variant granularity. The
`form-8710-family-extractor` skill extracts form-specific source code
per app; this skill is the portfolio-level aggregator that makes
decisions about form-handling consolidation possible.

## Inputs
- Per-app `form-8710-family-extractor` outputs (`form-family-
  inventory.json`, `form-field-manifest.json`) for every participating
  app that has form-handling code.
- Application catalog entries from `catalog-application`.
- Portfolio integration graph (`integration-graph.json`) from
  `portfolio-integration-mapper`.
- Client-profile compliance configuration listing the in-scope FAA
  forms.
- Optional: source-materials directory listing canonical form PDFs
  from the FAA for field-layout parity.

## Outputs
- `faa-form-catalog.json` — per form family + variant:
  `{form_number, form_family (8500 | 8710 | 8060 | ...), variant,
  revision, statutory_authority[], implementing_apps[],
  validator_apps[], signer_apps[], storer_apps[], downstream_consumers[],
  form_layout_canonical_pdf, prescribed_wording_findings_ref}`.
- `faa-form-role-assignments.json` — per (form, app) pair:
  `{form_number, app, roles[] (implementer | validator | signer |
  storer | consumer), source_file_references[], implementation_status
  (complete | partial | stub | zero_byte_sentinel)}`.

## Methodology
1. **Enumerate forms in scope.** Read each app's `form-family-
   inventory.json`. Union by form number + variant.
2. **Classify per-app role for each form.**
   - `implementer` — app renders the form for data entry (`.aspx`
     pages).
   - `validator` — app runs validation rules against form data (often
     the same app as implementer; sometimes a distinct review app).
   - `signer` — app captures the legal signature (IACRA for Form
     8710 e-signature).
   - `storer` — app persists the signed form record (RMS for
     airmen applications post-approval).
   - `consumer` — app reads the form's record downstream (AMCS
     consumes Form 8500-8 from MedXPress).
3. **Reconstruct the form's workflow chain.** For each form, order
   the apps by role: intake → review → sign → store → consume.
   Emit as a directed graph edge list.
4. **Identify variants.** IACRA's `forms/Added`, `forms/CFR`,
   `forms/Original`, `forms/ReinstatementAirman`, `forms/Standard`
   each represents a distinct variant of Form 8710-1. Emit one
   catalog entry per variant, not per form family.
5. **Capture zero-byte sentinels.** IACRA's `forms/` subtrees
   contain zero-byte files marking variants that exist in design
   but have no implementation. Record as sentinel-only variants
   with `implementation_status: zero_byte_sentinel`.
6. **Cross-reference prescribed wording.** For every form-handling
   app with regulatory-wording preservation findings (from
   `part-67-letter-wording-preservation-tracer`), include the
   finding reference in the form's catalog entry.
7. **Emit two manifests with `{repo}:{file}:{line}` citations** for
   every role assignment + source reference.

## Tech-Stack Dispatch

No external references.

## Gotchas
- **Form variants are not the same as form revisions.** Variants
  represent functional branches (reinstatement vs original); revisions
  represent regulatory updates (Rev 07/2019 vs Rev 10/2023).
  Preserve both independently.
- **One app, many roles.** AMCS is implementer + validator + consumer
  for Form 8500-8 (it implements the review UI, validates the data,
  and consumes the record). Don't force one-role-per-app.
- **Zero-byte sentinels are real catalog entries.** An IACRA form
  variant marked by a zero-byte file in `forms/Added/` is part of
  the catalog even though no code implements it; it signals a
  known-but-unimplemented variant.
- **Signer role requires legal weight.** A signing pad widget is not
  a signer role unless the signature has legal force. IACRA's
  `DigitalSignatureLibrary` + `IACRASignatureBLL` produce legally-
  binding signatures under 14 CFR Part 61; MedXPress's PIN capture
  is authentication, not legal signature.
- **Downstream consumer chain can be transitive.** MedXPress → AMCS
  → DIWS for Form 8500-8. Record every leg; don't collapse to
  source-and-sink.
- **Per-app revision drift.** One app may still use Rev 07/2019 of
  Form 8500-8 while a peer uses Rev 10/2023 — record the revision
  per (form, app) pair, not per form.
- **Cross-form references.** Form 8060-71 (Temporary Airman
  Certificate) is produced as output of a Form 8710-1 submission.
  Record as cross-form dependency, not as a single form.
- **Paper-equivalent parity.** Each form number corresponds to a
  printed FAA form; modernization must preserve field sequence +
  prescribed wording verbatim (`14 CFR Part 183` considerations).

## Quality Rules
- [ ] Every in-scope FAA form has a catalog entry.
- [ ] Each form's catalog entry enumerates every app that plays
      any role for it.
- [ ] Variants are preserved as separate entries (no flattening).
- [ ] Zero-byte sentinels recorded with
      `implementation_status: zero_byte_sentinel`.
- [ ] Every role assignment carries `{repo}:{file}:{line}` citations.
- [ ] Revision per (form, app) pair populated.
- [ ] Cross-form dependencies (e.g., 8710 → 8060-71) recorded.

## Common Failure Modes

| Failure Mode | Symptom | Prevention |
|---|---|---|
| Variants collapsed | Form 8710-1 catalog entry merged with 8710-11 | Key on (form_number, variant) |
| Sentinel omitted | `forms/Added/*.aspx` (0 bytes) ignored | Detect zero-byte files; catalog as sentinel |
| Signer role mis-assigned | PIN capture tagged as signer | Require legal-signature evidence (crypto lib + 14 CFR cite) |
| Transitive chain truncated | Form catalog shows only MedXPress → AMCS | Walk integration graph transitively for consumer chain |

## Handoff Summary
When this skill completes, verify:
1. Every in-scope FAA form and variant is cataloged.
2. Every participating app's role(s) per form are recorded with
   citations.
3. Cross-form dependencies captured.
4. Zero-byte sentinels preserved.

Then proceed to: `capability-consolidation-advisor` (Rationalization
supplementary) — which uses the form catalog to evaluate whether
form handling can consolidate (e.g., one shared form-submission
service) across the AAM suite; `wave-planner` — which sequences
form-handling modernization.

## References
None — logic inline.

## Changelog
- 0.1.0 (2026-05-08) — Initial skill. Authored as FAA-proposal-P2
  (see `docs/testing/faa-proposal-skill-assessment.md` Section 9).
