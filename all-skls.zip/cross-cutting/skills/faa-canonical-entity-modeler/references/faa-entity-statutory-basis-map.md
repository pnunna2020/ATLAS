# FAA Entity Statutory-Basis Map

Per-entity statutory and regulatory citation table, retention-schedule
references, CDC latency SLA rationale, and field-naming conventions
used by `faa-canonical-entity-modeler/SKILL.md`.

## Primary Source Map

Every canonical entity MUST cite both an enabling statute (USC) and an
implementing regulation (CFR). Citing one without the other is a
`regulatory-basis-partial` failure.

| Entity | Enabling Statute | Implementing Regulation | SoR (ATLAS) |
|---|---|---|---|
| Airman | 49 USC §44703 — Airman certificates | 14 CFR Part 61 — Certification of pilots, flight instructors, and ground instructors | RMS CAIS |
| Aircraft | 49 USC §44101-44104 — Aircraft registration | 14 CFR Part 47 — Aircraft registration | RMS AR |
| Certificate | 49 USC §44703 — Airman certificates | 14 CFR Part 61 (pilots); Part 63 (flight engineers); Part 65 (other airmen) | IACRA at issuance; RMS post-permanent |
| Designee | 49 USC §44702 — Issuance of certificates | 14 CFR Part 183 — Representatives of the Administrator | DMS |
| MedicalExam | 49 USC §44703 — Airman certificates | 14 CFR Part 67 — Medical standards and certification | AMCS (decision authority) |
| DrugTest | 49 USC §45102 — Alcohol and controlled substances testing | 14 CFR Part 120 — Drug and alcohol testing program | CPDSS |
| Application | 49 USC §44703 — Airman certificates | 14 CFR Part 61 §61.13 — Issuance of airman certificates | IACRA (in-flight, pre-issuance) |
| InspectorReport | 49 USC §44701 — General safety authority | 14 CFR Parts 91, 121, 135 (inspection authority by op) | Flag out-of-ATLAS-scope |

## PilotRecord (Future Scope)

14 CFR Part 111 (Pilot Record Database) introduces a distinct
PilotRecord entity with training history, disciplinary actions, and
proficiency check results. The PRD surface is substantially larger than
Airman and MUST NOT be conflated. Enabling statute: 49 USC §44703 plus
the PRIA-update provisions. Implementing regulation: 14 CFR Part 111.
Flag as FUTURE SCOPE if the ATLAS 8-app set does not include the PRD
application.

## ICAO Annex 1 Equivalence

Certificate ratings taxonomy MUST align with ICAO Annex 1 (Personnel
Licensing) where international equivalence matters (Part 61 pilot
certificates, Part 63 flight engineer, Part 65 air traffic control
tower operator / dispatcher / mechanic). Include an
`icao_equivalence` field on Certificate that cites the Annex 1
license category when one exists; emit `null` for FAA-only certificates.

## Retention Schedule Summary

Retention is statutory, not discretionary. Use the citation list below
when populating `retention_policy_cfr` on each entity.

| Entity | Retention | Authority |
|---|---|---|
| Airman (certification record) | Permanent | 44 USC §3301 (federal records); 14 CFR §61.3 |
| Aircraft (registration record) | Permanent (lifetime of aircraft + archival) | 14 CFR Part 47; 44 USC §3301 |
| Certificate (issued) | Permanent (airman record) | 14 CFR §61.19; 44 USC §3301 |
| Designee (authorization record) | Life of designee + 5 years | 14 CFR Part 183 retention |
| MedicalExam (Form 8500-8) | Life of airman + N years per medical class | 14 CFR Part 67 retention schedule |
| DrugTest (Part 120 record) | Per Part 120 record-keeping timeline (differs by test type: 1 year for negative, 5 years for positive / refusal) | 14 CFR Part 120 subpart E |
| Application (in-flight) | Until certificate issuance or denial; then merged with Certificate retention | 14 CFR §61.13 |
| InspectorReport | Per Part 91/121/135 retention schedules (typically 4 years operator-side; FAA retains longer) | 14 CFR Parts 91/121/135 |

Flattening to a single retention policy violates statute. Cite the
specific CFR section in `retention_policy_cfr`.

## PII Classification Guidance

PII classification is field-level. The table below is the FedRAMP High
baseline (applies to RMS, IACRA, DMS). FedRAMP Moderate (MSS suite)
permits AES-256 encryption without FIPS 140-3 module validation but
the field-level classification is unchanged.

| Field pattern | PII Level | Encryption at Rest |
|---|---|---|
| SSN (Social Security Number) | High | FIPS 140-3 validated (FedRAMP High); AES-256 (FedRAMP Moderate) |
| Date of Birth | Medium | FIPS 140-3 (FedRAMP High); AES-256 (FedRAMP Moderate) |
| Full Legal Name | Medium | Per deployment policy |
| Medical status / diagnosis (PHI) | High | FIPS 140-3; KMS CMK required |
| Physical / mailing address | Medium | Per deployment policy |
| Email address | Medium | Per deployment policy |
| Phone number | Medium | Per deployment policy |
| CAIS ID (opaque 7-char) | Low | Not required (identifier is opaque) |
| N-number | Low | Not required (public registry) |
| Certificate number | Low | Not required (public on ramp) |
| Flight hours / ratings | Low | Not required |
| Designee category | Low | Not required |
| Drug test result | High | FIPS 140-3 (FedRAMP High); AES-256 (FedRAMP Moderate) |
| Form 8500-8 free-text (medical) | High | FIPS 140-3; KMS CMK |

Encryption-at-rest requirements cascade to backup media, log files that
retain field values, and any cross-region replication. The
`canonical-entity-model.json` field row carries
`encryption_required` with the value `fips-140-3`, `aes-256`, or
`not-required` — no other values.

## CDC Latency SLA Rationale

CDC latency SLA drives integration-design transport choices. Use the
rationale below when populating `replica_apps[].latency_sla`.

| Entity | SLA | Rationale | Transport |
|---|---|---|---|
| Airman (identity replication RMS CAIS → IACRA/MSS/CHAPS) | < 60s | Airman identity changes (name corrections, status transitions) must reach dependent apps before the next authorization check; CDC from Aurora PG via AWS DMS | cdc-stream + EventBridge fan-out |
| Aircraft (registration RMS AR → inspector-facing reads) | < 24h (nightly) | Registration changes are low-frequency; nightly batch is acceptable and cheaper | nightly-batch via Glue |
| Certificate (IACRA → RMS on issuance) | < 5 min | Certificate issuance event must reach RMS before post-issuance workflows (IACRA-to-RMS SoR transition) | event-bus (EventBridge custom event) |
| MedicalExam (AMCS → CHAPS, DIWS) | < 60s (CHAPS); async S3 drop (DIWS) | CHAPS reads medical status for workflow decisions; DIWS holds imaged documents and can tolerate async file-drop | cdc-stream + event-bus (CHAPS); Step Functions + S3 (DIWS) |
| MedXPress → AMCS (form-8500 intake) | < 5 min (target); current state is nightly batch | Intake data feeds next-day exam scheduling; near-real-time reduces scheduling error | event-bus (target); nightly-batch (legacy) |
| Designee (DMS → inspector-workflow app) | < 60s | Designee authority changes affect in-flight inspection decisions | cdc-stream + event-bus |
| DrugTest (CPDSS → external partner notification) | < 15 min | Part 120 requires external reporting of positive / refusal results within statutory timelines | event-bus + Lambda partner-notification |

Do not default entities to a single SLA. Over-tight SLAs force MSK
instead of EventBridge and inflate cost; under-tight SLAs cause
workflow errors and audit-retention gaps.

## Field-Naming Conventions

Pick one convention per surface and document it on the
`canonical-entity-model.json` root as `field_naming_conventions`:

| Surface | Convention | Example |
|---|---|---|
| Legacy (existing apps, unchanged) | Per-app legacy style (e.g., UPPER_SNAKE_CASE for Oracle, PascalCase for SQL Server) | `AIRMAN_ID`, `AirmanID` |
| Target database (Aurora PG) | snake_case | `airman_id`, `cert_issue_date` |
| API (REST / event payloads) | camelCase | `airmanId`, `certIssueDate` |
| Event schema (EventBridge / MSK) | camelCase (matches API) | `airmanId`, `certIssueDate` |

`source_column_map` on each field carries the per-app legacy column
names so integration-design can build the transformation layer without
guessing. Drift between the three surfaces produces integration bugs
that surface only in production; honoring the conventions on day one
is cheaper than retrofitting.

## Certificate SoR Transition

Certificate is the only canonical entity whose SoR changes during the
record lifecycle. Model it with an explicit `sor_transition` field:

```
{
  "entity_id": "CERTIFICATE",
  "sor_app_id": "IACRA",  // during issuance
  "sor_transition": {
    "post_issuance_sor_app_id": "RMS",
    "transition_trigger": "certificate_issued_event",
    "transition_citation": "target-architecture.json:events:certificate-issued",
    "evidence_citation": "14 CFR §61.19:certificate-duration"
  },
  ...
}
```

Integration design uses the `sor_transition` field to route
post-issuance writes to RMS instead of IACRA. Skipping the transition
model leaves downstream integrations ambiguous about which app owns
the mutable permanent certificate record.

## Airman CAIS ID Immutability

The 7-char CAIS ID is the canonical Airman identifier. It is:
- Opaque (no personal information encoded)
- Immutable across name changes, status changes, and certificate
  transitions
- The canonical integration key across IACRA, MSS, CHAPS, and DMS

Do not propose a new identifier in the target design. Legacy apps
carry their own internal airman identifiers; those map to CAIS ID via
`source_column_map`. Integration events carry CAIS ID by value;
personal data (SSN, DOB, Name) carries by reference (CAIS ID) to
prevent PII sprawl.

## Aircraft N-number Mutability

N-number is canonical but mutable over the aircraft lifecycle
(re-registration, ownership transfer). Emit an `aircraft_registration_id`
(opaque, immutable) alongside the N-number for cross-system
integration; N-number is the human-readable surface.

## Designee Part 183 Taxonomy

14 CFR Part 183 enumerates 15 designee categories. The canonical
Designee entity MUST carry a `designee_category` field constrained to
the Part 183 enum. Common categories: DER (Designated Engineering
Representative), DMIR (Designated Manufacturing Inspection
Representative), AME (Aviation Medical Examiner), DPE (Designated
Pilot Examiner). The enum is authoritative; free-form category values
are a schema violation.

## Medical Certification Cross-App Span

Medical Certification is the most complex cross-app entity span in
the ATLAS set:
- **MedXPress** holds the airman-submitted intake (pre-exam state).
- **AMCS** holds the examiner's decision and is the SoR for
  MedicalExam.
- **CHAPS** reads medical status for workflow authorization.
- **DIWS** holds imaged supporting documents (S3 object storage with
  metadata pointer into AMCS).

Emit four `replica_apps[]` entries on MedicalExam, one per app, with
distinct `refresh_mechanism` and `latency_sla`. Do not collapse into
a single "MSS suite" replica — the per-app transports differ
substantially.

## Drug Test External Reporting

Part 120 mandates external reporting of positive and refusal results
within statutory timelines. CPDSS is the SoR; EventBridge emits a
partner-notification event; a Lambda delivers to the partner endpoint
with idempotency keys and a dead-letter topic for unprocessable
events. Retention for the notification receipt is the same as the
underlying DrugTest record (per Part 120 subpart E).
