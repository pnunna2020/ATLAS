---
name: faa-canonical-entity-modeler
description: >
  Build the enterprise canonical data model for FAA aviation entities across
  the 8-app portfolio (IACRA, RMS, MSS suite (AMCS+MedXPress+CHAPS+CPDSS+DIWS),
  DMS). Defines Airman, Aircraft, Certificate, Designee, MedicalExam,
  DrugTest, Application, and InspectorReport as canonical entities with
  statutory basis (14 CFR Parts 61/67/111/120/183, 49 USC §44703), PII
  classification, field-level encryption requirements, retention schedule,
  source-of-truth app, replica fan-out, and CDC latency SLA. Emits
  canonical-entity-model.json (full entity definitions) plus
  entity-mapping-matrix.csv (per-entity x per-app residency table:
  SoR | authoritative_replica | operational_replica | not_present). Fires in
  the Design phase when tech_stack contains FAA/aviation/federal markers or
  when client_profile is faa. Triggers on canonical data model, FAA entity
  modeling, airman-entity design, certificate-entity design, medical-exam
  entity, CFR retention, or @faa-canonical-entity-modeler.
agent: sonnet
allowed-tools:
  - Read
  - Write
  - Grep
phase: design
triggers:
  tech_stack_contains: [faa, aviation, federal]
  client_profile: faa
validation_commands:
  - "python -m olympus.validators.schema_validator canonical-entity-model.json"
  - "python -m olympus.validators.schema_validator entity-mapping-matrix.csv"
supported_stacks:
  - faa
  - aviation
  - federal
  - airman-certification
  - aircraft-registration
  - medical-certification
  - designee-management
anti_target_stacks:
  - non-federal
  - non-aviation
  - static-site
failure_classes:
  - pii-classification-drift
  - retention-statute-missing
  - sor-ambiguity
  - entity-conflation
  - field-name-convention-drift
  - cdc-latency-unspecified
  - regulatory-basis-partial
benchmark_tags:
  - canonical-entity-model
  - faa-data-model
  - cfr-retention
---

# faa-canonical-entity-modeler

## Purpose
Own the enterprise canonical data model for FAA aviation entities at the
Design phase. Each of the 8 ATLAS-scope apps holds a fragmented physical
view of Airman, Aircraft, Certificate, Designee, MedicalExam, DrugTest,
Application, and InspectorReport; the same logical entity is stored with
different field names, different identifiers, and different retention
policies across IACRA, RMS, the MSS suite, and DMS. Without a canonical
model, integration design drifts into pairwise schema gymnastics and
retention obligations fall between the seams of 14 CFR Part 61, Part 67,
Part 111, Part 120, and Part 183. This skill produces the single
authoritative map: for each entity, the source-of-truth app, the replica
fan-out, the PII classification (which drives FIPS 140-3 encryption), the
retention schedule keyed to the enabling statute, and the field-level
mapping that lets downstream integration design honor
data-minimization under Part 67. SOO Sub-factor 3 §5.1 Theme A
(Current-State) and §5.2 Theme B (Target-State) both require a canonical
enterprise data view; this skill is the Design-phase input to that
evaluation.

## Inputs
- Discovery output for each app: `application-catalog-entry.json`,
  `business-rule-inventory.json`, and (where present) data-dictionary
  extracts from legacy schemas (Oracle DDL, SQL Server DDL, ADABAS FDT).
- Disposition recommendations from Rationalization — Consolidate
  dispositions drive entity convergence candidates.
- Regulatory reference material, located in
  `/Users/pnunna/Documents/Background_Information/`:
  - `14 CFR Part 61 (up to date as of 12-02-2025).md` — Airman,
    Certificate, Rating structure. §61.3 identity requirement; §61.19
    certificate duration.
  - `14 CFR Part 67 (Medical).url` plus AMCS/MedXPress Discovery evidence
    — MedicalExam (Form 8500-8) field surface and retention schedule.
  - `49 U.S. Code § 44703 - Airman certificates.md` — statutory basis for
    Airman + Certificate.
  - `14 CFR Part 111 Pilot Record Database on Federal Register.md` —
    introduces PilotRecord entity (distinct from Airman; flag as FUTURE
    SCOPE if not in ATLAS 8-app set).
  - `ICAO-Annex-1-Personnel-licensing.md` — international equivalence;
    informs Certificate ratings taxonomy.
- Client profile `profiles/faa/profile.yaml` for PII tier policy and the
  encryption-at-rest standard (FIPS 140-3 for High).
- Reference: `references/faa-entity-statutory-basis-map.md`.

## Outputs
- `canonical-entity-model.json` — per-entity definition. Each
  `entities[]` row carries:
  - `entity_id` (stable slug, for example `AIRMAN`, `CERTIFICATE`),
  - `name`, `definition`,
  - `statutory_basis` (object with `enabling_statute` and
    `implementing_regulation`; for example
    `{enabling_statute: "49 USC §44703", implementing_regulation: "14 CFR
    Part 61"}`),
  - `sor_app_id` (the single source-of-truth app for the canonical entity),
  - `pii_level` in `{high, medium, low, none}`,
  - `retention_policy_cfr` (citation into the retention-schedule
    reference, for example `44 USC §3301` for permanent records;
    `14 CFR Part 67 retention schedule` for medical records),
  - `fields[]` — each field carries `name`, `type`, `required`, `pii`,
    `encryption_required`, `source_column_map` (per-app legacy column
    name list),
  - `replica_apps[]` — each replica carries `app_id`,
    `refresh_mechanism` (`cdc-stream | event-bus | nightly-batch |
    file-drop`), `latency_sla` (for example `<60s`, `<24h`),
  - `relationships[]` — cross-entity links (for example
    `AIRMAN 1..* CERTIFICATE`).
- `entity-mapping-matrix.csv` — entity x app matrix. Columns: `entity_id`,
  `IACRA`, `RMS-CAIS`, `RMS-AR`, `AMCS`, `MedXPress`, `CHAPS`, `CPDSS`,
  `DIWS`, `DMS`. Cell values from the enum: `SoR | authoritative_replica
  | operational_replica | not_present`.
- Validator reports written sibling to each artifact.

## Methodology
1. Load the 8-app Discovery set plus the Rationalization dispositions.
   Enumerate every candidate entity from legacy-schema DDL and from the
   business-logic extraction (capabilities that manipulate persistent
   data imply an entity). The initial candidate set is the eight
   canonical entities above; additional candidates surface in Discovery
   and are added with a justification citation.
2. For each entity, pin the statutory basis. Cite BOTH the enabling
   statute AND the implementing regulation — citing one without the
   other is a `regulatory-basis-partial` failure. Example: Airman is
   enabled by 49 USC §44703 and implemented by 14 CFR Part 61. Medical
   certification is enabled by 49 USC §44703 and implemented by 14 CFR
   Part 67. Designee authority is enabled by 49 USC §44702 and
   implemented by 14 CFR Part 183.
3. Pin the source-of-truth app per entity. Use the decision rules in
   `references/faa-entity-statutory-basis-map.md`. Key SoRs:
   - Airman → RMS CAIS (7-char CAIS ID is canonical, immutable).
   - Aircraft → RMS AR (N-number is canonical, mutable over lifecycle).
   - Certificate → IACRA at issuance, then RMS post-permanent
     (Temporary Airman Certificate lifecycle crosses the boundary — see
     Gotchas).
   - MedicalExam → AMCS (decision authority). MedXPress is intake
     (pre-exam state); CHAPS reads; DIWS holds imaged documents.
   - Designee → DMS (Part 183 taxonomy; 15 designee categories).
   - DrugTest → CPDSS (Part 120 mandated records).
   - Application → IACRA (in-flight airman application; pre-certificate
     issuance state).
   - InspectorReport → the inspector-workflow app (flag `not_in_scope`
     if outside the ATLAS 8-app set).
4. Classify PII per field, not per entity. SSN is High; DOB is Medium;
   Name is Medium; CAIS ID is Low (opaque 7-char identifier);
   N-number is Low (public registry). Medical status is High (PHI).
   Flight hours and ratings are Low. The field-level classification
   drives the encryption-required flag; FIPS 140-3 is mandatory for High
   fields under FedRAMP High (RMS, IACRA, DMS) and strongly recommended
   for High fields under FedRAMP Moderate (MSS suite).
5. Pin retention per entity. Airman certification records are
   permanent under 44 USC §3301. Medical certification records are
   life-of-airman-plus-N-years per the Part 67 retention schedule.
   DrugTest records follow the Part 120 record-keeping timeline.
   Designee records follow the Part 183 surveillance schedule. Do not
   flatten to a single retention policy — per-entity retention is
   statutory, not discretionary.
6. Build replica fan-out. For each entity, list every app that holds a
   copy; classify each replica as `authoritative_replica` (near-real-time
   CDC; downstream of the SoR) or `operational_replica` (batched; used
   for read-heavy workflows). Record the `refresh_mechanism` and
   `latency_sla`. Airman identity replicates to IACRA, MSS, CHAPS with
   sub-60s latency (CDC); Aircraft registration replicates nightly to
   inspector-facing reads.
7. Map fields per app. `source_column_map` carries the legacy column
   name for each app. Field-name stability matters across modernization
   — legacy `AIRMAN_ID` vs target `airman_id` vs API `airmanId`. Pick
   one convention (snake_case for target database; camelCase for API)
   and stick. `references/faa-entity-statutory-basis-map.md` has the
   convention table.
8. Emit `entity-mapping-matrix.csv`. Every entity row has exactly one
   `SoR` column; zero or more `authoritative_replica` columns; zero or
   more `operational_replica` columns; remaining cells are `not_present`.
   No entity has two SoR columns — if two apps claim authority, resolve
   with the statutory-basis rule (the app closest to the regulation
   wins) and raise a finding.
9. Validate. `canonical-entity-model.json` passes its schema.
   `entity-mapping-matrix.csv` passes column-count and enum-cell checks.
   Every field with `pii = true` has an explicit `encryption_required`
   flag set.

## Gotchas
- **PII classification is field-level, not entity-level.** The Airman
  entity has both High-PII fields (SSN) and Low-PII fields (CAIS ID).
  Coarse entity-level PII tagging over-encrypts and under-encrypts
  simultaneously. Classify every field.
- **Encryption-at-rest is FIPS 140-3 for High PII under FedRAMP High.**
  Do not emit `encryption_required: false` for any High-PII field on
  RMS, IACRA, or DMS. FedRAMP Moderate (MSS suite) permits AES-256
  without FIPS 140-3 validation; the reference spells out the exact
  policy.
- **Retention schedule is per-entity and statutory.** Airman
  certification records are permanent (44 USC §3301); medical
  certification records are life-of-airman-plus-N-years (Part 67).
  Flattening to a single policy violates statute. Cite both the
  enabling-statute retention rule AND the implementing-regulation
  schedule.
- **Canonical entity is abstract; physical tables stay fragmented.**
  The canonical model is the contract for cross-app integration. It
  does not force physical consolidation; Consolidate dispositions may
  converge physical tables over time, but the canonical model stands
  on day one.
- **Cross-entity relationships cross SoR boundaries.** Airman → MedicalExam
  spans RMS ↔ AMCS; Airman → Certificate spans RMS ↔ IACRA. Those are
  integration concerns that feed
  `cross-system-data-integration-designer`; emit the relationship in
  the canonical model and let the integration designer pick the
  transport.
- **Regulatory basis must cite both statute and regulation.** 49 USC
  §44703 alone is not enough; 14 CFR Part 61 alone is not enough. Both
  citations are mandatory. The `regulatory-basis-partial` failure
  class catches one-sided citations.
- **CDC latency SLA varies per entity.** Airman identity replicates
  sub-60s; Aircraft registration replicates nightly. Do not default
  everything to a single SLA — the SLA drives integration-design
  transport choices, and a wrong SLA cascades into over-costly or
  under-fresh integrations.
- **Flattening entities violates data-minimization.** Collapsing
  MedicalExam into Airman (one table with embedded medical status)
  violates Part 67 data-minimization and breaks the audit-of-medical-
  records obligation. Keep the entity boundary.
- **Field-name stability matters.** Legacy `AIRMAN_ID` vs target
  `airman_id` vs API `airmanId` — pick one convention per surface
  (snake_case for target DB, camelCase for API) and document the
  convention in the model. Drift produces integration bugs that
  surface only in production.
- **PilotRecord (Part 111 PRD) is distinct from Airman.** Pilot Record
  Database introduces a separate, larger entity with training and
  disciplinary history. Do not conflate with Airman. Flag as FUTURE
  SCOPE if the ATLAS 8-app set does not include the PRD application.
- **Certificate SoR transitions during lifecycle.** Temporary Airman
  Certificate is SoR'd by IACRA during issuance; the permanent
  certificate is SoR'd by RMS post-issuance. Model this as a
  `sor_transition` field on the Certificate entity with the transition
  trigger cited (certificate issuance event).

## Quality Rules
- [ ] Every entity in `canonical-entity-model.json` has both
      `statutory_basis.enabling_statute` and
      `statutory_basis.implementing_regulation` populated with a
      citation that resolves to a real CFR/USC section.
- [ ] Every entity has exactly one `sor_app_id` in
      `entity-mapping-matrix.csv` (SoR column appears exactly once per
      row).
- [ ] Every field with `pii: true` has `encryption_required` populated;
      fields with `pii_level = high` on RMS/IACRA/DMS apps require
      `encryption_required: fips-140-3`.
- [ ] Every entity has a `retention_policy_cfr` citation that resolves
      to an enabling statute and an implementing retention schedule.
- [ ] Every replica in `replica_apps[]` has a populated
      `refresh_mechanism` and `latency_sla`; no defaults.
- [ ] `relationships[]` cross-entity links cite both endpoints' SoR
      apps (feeds integration design).
- [ ] `entity-mapping-matrix.csv` cells are from the enum `{SoR,
      authoritative_replica, operational_replica, not_present}` only;
      no free-form values.
- [ ] Airman `sor_app_id = RMS-CAIS`; Aircraft `sor_app_id = RMS-AR`;
      MedicalExam `sor_app_id = AMCS`; Designee `sor_app_id = DMS`;
      DrugTest `sor_app_id = CPDSS`. These are the baseline SoRs; any
      deviation requires a finding with a statutory-basis citation.
- [ ] Certificate entity carries a `sor_transition` field modeling the
      IACRA-to-RMS handoff on issuance.
- [ ] Both artifacts pass their schemas with zero errors.

## Common Failure Modes
| Failure Mode | Symptom | Prevention |
|---|---|---|
| PII classification drift (entity-level tagging instead of field-level) | Entity tagged "high" forces encryption on Low-PII fields; performance regressions | Classify every field; the schema enforces `fields[].pii_level` per-field |
| Retention statute missing | Retention listed as a generic policy with no CFR citation; audit fails | Cite both the enabling statute (44 USC §3301, etc.) and the implementing retention schedule (Part 67, Part 120, etc.) |
| SoR ambiguity (two apps claim authority) | Matrix has two SoR columns; integration design cannot pick a canonical source | Resolve with the statutory-basis rule — the app closest to the regulation wins; flag as a governance finding |
| Entity conflation (MedicalExam collapsed into Airman) | Flat Airman table with embedded medical fields; Part 67 data-minimization violated | Keep MedicalExam as a distinct entity; model the relationship in `relationships[]` |
| Field-name convention drift across surfaces | `AIRMAN_ID` in legacy, `airman_id` in target, `airmanID` in API — integration bugs in production | Pick one convention per surface (snake_case for DB, camelCase for API) and document in the model |
| CDC latency SLA defaulted to one value | Aircraft registration at the same sub-60s SLA as Airman identity; integration over-costly | Per-entity SLA with reference-document rationale; no single default |
| Regulatory basis partial (statute cited, regulation missing) | Audit reviewer cannot trace from code to regulation | Cite both; the `regulatory-basis-partial` failure class catches one-sided citations |
| PilotRecord (Part 111) conflated with Airman | PRD scope leaks into Airman entity; out-of-scope entity fields pollute the model | Flag PilotRecord as a separate entity with FUTURE SCOPE unless the ATLAS set includes the PRD app |

## Handoff Summary
When this skill completes, verify:
1. `canonical-entity-model.json` exists, passes its schema, and every
   entity has both statutory-basis citations populated.
2. `entity-mapping-matrix.csv` exists, has exactly one SoR per row, and
   all cells are from the enum.
3. Every High-PII field on a FedRAMP High app has
   `encryption_required: fips-140-3`.
4. Certificate entity carries the IACRA-to-RMS `sor_transition` model.
5. No entity conflates MedicalExam into Airman; no entity conflates
   PilotRecord into Airman.

Then proceed to `cross-system-data-integration-designer` (consumes
`canonical-entity-model.json` to design CDC streams, event-bus edges,
and per-edge data contracts) and to `rationalization-to-architecture-traceability`
(uses the SoR map to validate that Consolidate dispositions name a
valid target host service). The next gate is **G-DT** (Design
Traceability) where the canonical model is accepted as evidence for
SOO Sub-factor 3 §5.1 / §5.2 data-view consistency.

## References
- `references/faa-entity-statutory-basis-map.md` — per-entity
  statutory / regulatory citation table, retention-schedule references,
  CDC latency SLA rationale, field-naming convention.
- Background regulatory sources in
  `/Users/pnunna/Documents/Background_Information/` — CFR and USC
  primary sources.
- `docs/testing/architecture-data-skill-assessment.md` §7 — identifies
  canonical entity modeling as a required Design-phase skill.

## Changelog
- 0.1.0 (2026-05-06) — Initial skill. Defines Airman, Aircraft,
  Certificate, Designee, MedicalExam, DrugTest, Application, and
  InspectorReport as canonical entities with per-field PII, per-entity
  retention, SoR map, replica fan-out, and CDC SLA. Cites 14 CFR Parts
  61/67/111/120/183 and 49 USC §44703. Emits canonical-entity-model.json
  and entity-mapping-matrix.csv. Feeds G-DT gate and SOO Sub-factor 3
  §5.1 / §5.2 data-view evidence.
