---
name: data-domain-patterns
description: >
  Identify business capability boundaries and map data entities to logical data domains.
  Used during Data line domain discovery and data product design. Triggers on domain
  boundary identification, data domain mapping, or entity-to-domain assignment.
agent: opus
allowed-tools:
  - Read
  - Write
  - Grep
---

# Data Domain Patterns

## Purpose
Map data entities to logical business domains based on ownership, lifecycle, and
access patterns — forming the foundation for data mesh architecture.

## Inputs
- Application catalog entries from Discovery
- 4-pass analysis outputs (especially Pass 1 structural and Pass 2 business logic)
- Data entity inventory (tables, collections, schemas)
- Business capability mapping

## Outputs
- Data domain model (YAML)
- Entity-to-domain assignment matrix
- Domain boundary documentation with justification
- Domain ownership assignments

## Methodology
Apply domain boundary heuristics:
1. **Changes together** — entities modified in the same transactions belong together
2. **Queried together** — entities frequently joined in queries share a domain
3. **Same lifecycle** — entities created and archived on the same schedule
4. **Same security classification** — same access control requirements
5. **Same business owner** — same organizational unit responsible

## Gotchas
- **One domain may span 15+ applications**: Domains follow business capability
  boundaries, NOT application boundaries. Don't assume one-domain-per-app.
- **Every entity must be assigned to exactly ONE domain**: No shared ownership.
  If an entity appears to belong to two domains, it's a data product boundary.
- **Cross-domain references become data product interfaces**: When two domains
  need the same data, one owns it and the other consumes it via a data product API.

## Domain-Boundary and Canonicalization References
- Bounded-context alignment, producer ownership, consumer contracts, and
  domain event taxonomy → `references/data-mesh-domain-boundaries.md`
- FAA-specific golden-record patterns (Airman/Aircraft/Designee/Medical)
  and the SSN-as-join-key anti-pattern →
  `references/faa-entity-canonicalization.md`

## Quality Rules
- [ ] Every data entity is assigned to exactly one domain — no shared ownership
- [ ] Domain boundaries are justified by at least 3 of the 5 heuristics (changes together, queried together, same lifecycle, same security class, same owner)
- [ ] Cross-domain references are identified and documented as data product interface candidates
- [ ] Domain model accounts for entities spanning multiple applications — domains follow business capabilities, not app boundaries
- [ ] Entity-to-domain assignment matrix has zero unassigned entities
- [ ] Domain ownership assignments identify a specific organizational unit or team
- [ ] Domain boundaries cite bounded-context evidence (ubiquitous language, lifecycle, ownership team) — not just structural heuristics
- [ ] When the FAA profile is active, FTN is chosen as the canonical airman ID; MID, Designee Number, and Certificate Number are modeled as attributes; SSN is verification-only, never a join key

## Common Failure Modes
| Failure Mode | Symptom | Prevention |
|-------------|---------|------------|
| One-domain-per-app mapping | Domains mirror application boundaries; cross-app business capabilities are split | Apply domain heuristics based on business capability, not application inventory |
| Shared entity ownership | Entity assigned to two domains; downstream data products have conflicting ownership | Enforce single-owner rule; resolve contested ownership with the "primary writer" heuristic |
| Missing cross-domain references | Domains defined in isolation; integration points between domains not identified | Catalog all cross-domain data access patterns; convert to data product interfaces |
| Heuristics applied selectively | Domain boundary justified by only 1 heuristic; boundary is fragile | Require at least 3 of 5 heuristics to support each boundary decision |

## Handoff Summary
When this skill completes, verify:
1. Entity-to-domain assignment is complete (zero unassigned entities, single ownership)
2. Domain boundaries are justified by at least 3 heuristics each
3. Cross-domain references are documented as data product interface candidates
Then proceed to: `data-product-specification` for formal data product definitions, and `data-mesh-architecture` (P2.2) for the overall data architecture
