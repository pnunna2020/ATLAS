# Data-Mesh Domain Boundaries

How to draw data-mesh domain boundaries so each domain owns a coherent
slice of business capability and exposes well-shaped data products.

## Four Decision Axes

### 1. Bounded-Context Alignment
One bounded context per domain — one ubiquitous language, one lifecycle,
one ownership team. If two entities use the same word with different
meanings (e.g., "certificate" as airman credential vs. aircraft
airworthiness), they belong to different domains.

### 2. Producer Ownership
Exactly one domain mints and mutates each entity. The producer owns the
schema, publishes events on state change, and guarantees SLA and data
quality. Consumers read from data-product interfaces; they never reach
into producer storage.

### 3. Consumer Contracts
Every cross-domain dependency is a versioned contract covering schema,
event cadence, freshness SLO, PII classification, and deprecation
policy. A boundary without a contract is a shared database in disguise.

### 4. Domain Event Taxonomy
Events are past-tense business facts, not CRUD operations. Name events
in the producer's language (`AirmanCertificateIssued`, not
`row_inserted`). Events must be self-contained — consumers should not
need a callback to interpret them.

## FAA Example

- **Airmen domain** — owns the airman golden record. Sources: CAIS, ACIS.
  Produces `AirmanRegistered`, `AirmanCertificateIssued`.
- **Medical domain** — owns medical certification. Source: MSS DIWS.
  Produces `MedicalCertificateIssued`, `MedicalExpired`.
- **Designee domain** — owns designee authority. Source: DMS. Produces
  `DesigneeAppointed`, `DesigneeRevoked`.
- **Imaging domain** — owns document capture. Source: IMS. Produces
  `DocumentCaptured`, `DocumentIndexed`.

## Smell Tests

- Two domains share write access to a table — collapse or split
- An event needs a callback to interpret — enrich the event
- No producer responsibility — it is a view, not a domain
- Many consumers, no SLA — formalize the contract
