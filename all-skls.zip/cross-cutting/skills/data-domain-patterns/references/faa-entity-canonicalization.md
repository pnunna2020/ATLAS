# FAA Entity Canonicalization Patterns

Canonical identity choices for FAA entities that appear across multiple
legacy systems. Apply when the FAA client profile is active.

## Airman Golden Record

Source systems: IACRA, CAIS, ACIS, DMS, MSS DIWS.

- **Canonical PK:** `ftn` (FAA Tracking Number). Assigned at first
  application via IACRA/CAIS, stable for life, external-facing.
- **Attributes (former IDs):**
  - `mid` — ACIS master ID, internal only
  - `designee_number` — DMS, present only for designees
  - `certificate_number` — CAIS, changes on upgrade/replacement
- **Verification-only attribute:** `ssn` — used for identity matching
  during record consolidation, **never as a runtime join key**.
- **Primary SoR:** CAIS for airman master; DMS for designee status; MSS
  DIWS for medical.

## Aircraft Registration Golden Record

- **Canonical PK:** `n_number` for active registrations; fall back to
  `serial_number` + `manufacturer_code` for pre-registration and
  deregistered states (N-numbers are re-issued).
- **Attributes:** prior N-numbers, registration status, owner FTN.
- **Primary SoR:** Aircraft Registry.

## Designee Golden Record

- **Canonical PK:** `ftn` (a designee is first an airman). Designee
  Number becomes an attribute on the Designee sub-entity.
- **Primary SoR:** DMS for designee authority, expiration, scope.

## Medical Record

- **Canonical PK:** `ftn` (medical is attached to the airman).
- **Primary SoR:** MSS DIWS. Do not replicate medical-decision logic in
  CAIS or ACIS; consume MSS DIWS events.

## Anti-Pattern: SSN as Join Key

SSN is PII, is not guaranteed unique across history (re-use,
corrections, typos), and is not always present (foreign airmen). Use
SSN only:
- during one-time record-linkage runs
- as a tie-breaker when FTN is missing
- as an identity-verification challenge at authentication

Never expose SSN in data-product interfaces or event payloads.
