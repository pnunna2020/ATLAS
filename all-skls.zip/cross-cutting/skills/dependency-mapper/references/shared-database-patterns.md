# Shared Database Dependency Patterns

Detect hidden couplings where two apps share a database, schema, or table.
Invisible at the API layer and almost always **hard**: deploying one app
can corrupt the other's data.

## Connection-string signals

Normalize each app's `host + port + database + schema` and cluster matches.

- Java: `spring.datasource.url`, `jdbc:oracle:thin:@//host:port/SID`,
  `hibernate.default_schema`.
- .NET: `ConnectionStrings:Default` in `appsettings.json`, `web.config`.
- Node: `DATABASE_URL`, `PG_HOST`, `MYSQL_DATABASE`.
- Python: `SQLALCHEMY_DATABASE_URI`, Django `DATABASES['default']`.
- ColdFusion: `Application.cfc` `datasource`, `<cfquery datasource="">`.

Apps in one cluster imply a soft edge for wave adjacency and a hard edge
on any schema-changing deploy.

## Permission / grant signals

- Oracle: `GRANT SELECT ON schema_a.table TO schema_b`; `dba_tab_privs`.
- PostgreSQL: `GRANT USAGE ON SCHEMA a TO role_b`, table grants.
- SQL Server: `GRANT` and `sys.database_permissions`.

A grant from A to the role used by B creates edge A -> B.

## Cross-schema query signals

Grep source and stored procedures for fully qualified names:

- Oracle: `OTHER_SCHEMA.TABLE` in procedures, views, MVs.
- SQL Server: three-part `db.schema.table`, `OPENQUERY`, linked servers.
- PostgreSQL: `schema.table`, `dblink`, foreign data wrappers.

Reads = read-dependency; writes / MERGE = **hard** write-dependency.

## Hidden-dependency flag

Mark edge `hidden=true` when all of:

1. No API or message integration exists.
2. Dependency only observable via DB metadata or query-plan cache.
3. App teams may not know the coupling exists.

Surface hidden edges with a remediation note — break the coupling or
plan both apps into the same wave.

## Common misses

- Views that join across schemas.
- Shared sequences, synonyms, DB links.
- ETL writing "shared staging" schemas consumed by multiple apps.
- Read-replica usage is still schema coupling.
