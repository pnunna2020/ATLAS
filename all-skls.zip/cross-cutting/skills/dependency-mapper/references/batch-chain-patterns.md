# Batch Chain and Temporal Dependency Patterns

Detect time-based dependencies between batch jobs. No API, no message —
Job A finishes at 02:00, writes a file; Job B starts at 02:30, reads it.
Hard dependency, invisible from code alone.

## Scheduler signals

- **cron / systemd**: `crontab -l`, `/etc/cron.d/*`, `.timer`/`.service`.
- **Windows**: `schtasks /query`, `Get-ScheduledTask`.
- **Control-M**: `IN_CONDITION`, `OUT_CONDITION`, `CONDITION_TABLE` —
  explicit job-to-job edges.
- **Autosys**: `.jil` `condition: success(job_a)`.
- **TWS/IWS**: database and prodsked exports.
- **Airflow / Prefect / Dagster**: `upstream >> downstream`, `after=[...]`.

Scheduler exports encode edges directly — parse them first.

## File-based temporal coupling

Most common hidden batch dependency:

1. Job A writes `/shared/out/dailyfeed-YYYYMMDD.csv` at 02:00.
2. Job B reads `/shared/in/dailyfeed-*.csv` at 02:30.
3. Neither job references the other.

Detection:

- Grep for `write`/`rename`/`mv` to shared paths.
- Grep for `read`/`load`/`copy` from same paths or overlapping globs.
- Correlate path prefix + filename pattern (same date stamp).
- B after A reading A's pattern = edge A -> B.

## DB-based temporal coupling

- Job A writes staging rows with `batch_id = today`.
- Job B selects `WHERE batch_id = today AND status = 'READY'`.

## Trigger-file / sentinel patterns

- Job A writes `/shared/flags/job_a.done`.
- Job B polls in a wrapper: `while [ ! -f ... ]`, `wait-for-file`.

## Classification

- Scheduler-declared chain: **hard**, `temporal=scheduler:<name>`.
- File-drop coupling: **hard**, `temporal=file-drop`.
- Idempotent independent reruns: **soft**.

## Output

Emit each edge with `time_window` (e.g. `"02:00-02:29"`) so wave-planner
avoids disrupting the chain.

## Common misses

- Manual operator steps between jobs, only in runbooks.
- Monthly / quarterly / year-end jobs absent during audit.
- Jobs that look idempotent but rely on prior-run state.
