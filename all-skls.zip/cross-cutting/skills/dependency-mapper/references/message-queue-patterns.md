# Message Queue and Event Dependency Patterns

Detect async dependencies through brokers, queues, topics, and event
buses. Edges follow data flow: **producer -> consumer**.

## JMS / MQ / Rabbit signals

- Java: `@JmsListener(destination = "queue.orders")`,
  `JmsTemplate.convertAndSend(...)`, `@RabbitListener(queues = "...")`.
- Spring Cloud Stream:
  `spring.cloud.stream.bindings.<name>.destination`.
- Config: `jms.xml`, `mq.ini`, named queues/topics in connection
  factories. Each destination = node; each binding = edge.

## Apache Kafka

- Producer: `KafkaTemplate.send("topic", ...)`,
  `new ProducerRecord("topic", ...)`.
- Consumer: `@KafkaListener(topics = "...")`, `subscribe([...])`.
- Kafka Connect source/sink connectors — external integration edge.
- Schema Registry usage — annotate edges `contract=avro`.

## AWS / Azure / GCP

- SQS: `sqs.sendMessage({ QueueUrl })`, `sqs.receiveMessage`.
- SNS: `sns.publish({ TopicArn })` + every SQS subscription = edge.
- EventBridge: source `detail-type` = producer; target ARN = consumer.
- Azure Service Bus: `CreateSender`, `CreateProcessor`.
- Pub/Sub: `PublisherClient.Create(TopicName)`; subscriber pulls.

## Ownership rules

Assign **one owner** per topic/queue. Multiple producers to the same
destination = shared-ownership risk; schema change requires producer
coordination. Consumers form the producer's outbound dependent list.

## Classification

- Sync request/reply over queue (correlation IDs, reply queues): **hard**.
- Fire-and-forget with durable queue + DLQ: **soft**.
- Ordered/partitioned topic with required ordering: **hard**, annotate
  `ordering=required`.

## Common misses

- DLQs consumed by a separate ops app — still a dependent consumer.
- Webhook receivers classified as APIs when semantically event consumers.
- Scheduled functions triggered by queue-depth metrics: producer is
  still a dependency.
