# TIFF-over-FTP and File-Drop Integration Patterns

Detect file-drop integrations where one app writes to a shared landing
zone (SFTP, NFS, S3, share) and another consumes on a schedule.

Canonical FAA example: **IACRA** renders certificate forms to TIFF and
pushes via secure FTP to **CAIS**, which ingests them. Pure filesystem
handoff, missed by API-centric scans.

## SFTP / FTPS signals

- Hosts/ports: `sftp://`, `ftps://`, port 22/990/21.
- Creds: `*_SFTP_USER`, `*_SFTP_KEY`, `*_FTP_PASSWORD`.
- Libs: `JSch`, `SSHJ`, `commons-vfs2`, `paramiko`, `WinSCP .NET`.
- Scripts: `sftp -b`, `lftp -e`, `psftp -b`.
- Operators: `SFTPOperator`, Control-M file-transfer, MFT products
  (Sterling, Axway, GoAnywhere).

Each `host + directory` is a landing-zone node. Writers = producer;
readers = consumer.

## Scheduled file-move signals

Often moves, not live pushes:

- cron: `rsync`, `scp`, `aws s3 cp`, `mv /out/*.tiff /dropbox/`.
- Windows: `robocopy`, `Send-SFTPItem`.
- MFT flows with poll + file-mask trigger.

Third-team (ops/MFT) ownership is common — still record the edge.

## Filename-convention signals

- `IACRA_8710_YYYYMMDD_HHMM.tif` — TIFF handoff.
- `APPLICANT_<id>_<timestamp>.xml|.pdf` — form handoff.
- `*.ready`, `*.done`, `*.trg` — sentinels.

Grep extensions (`.tif`, `.pdf`, `.xml`, `.csv`, `.edi`) paired with
`*YYYYMMDD*` or `*.ready`.

## Classification

- Critical-path handoff (IACRA -> CAIS): **hard**.
- Landing zones owned by neither app: synthetic "MFT" owner node.
- External partner SFTP (airlines, DoD, ICAO): `external=true`,
  **immovable**.

## Emit per edge

- `type: "file"`, `subtype: sftp|nfs|s3|mft`.
- `landing_zone: "<host>:<path>"`.
- `filename_pattern`, `schedule`, `sentinel` when known.
- `hidden: true` when neither source references the other.

## Common misses

- Manual Friday uploads never codified.
- Re-drop loops (consumer rejects, producer resends).
- Archival copies picked up by analytics/retention apps.
