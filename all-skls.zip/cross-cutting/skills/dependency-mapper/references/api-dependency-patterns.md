# API Dependency Detection Patterns

Detect runtime API dependencies between apps. Visible but easy to miss when
calls are wrapped, configured, or routed through a gateway.

## Code signals by stack

- **Java/JVM**: `RestTemplate`, `WebClient`, `HttpClient`, `OkHttpClient`,
  `Retrofit`, `@FeignClient(name = "other-service")`, JAX-RS
  `ClientBuilder`. Base URLs in `application.yml`: `*.base-url`,
  `*.endpoint`, `*-service.url`.
- **.NET**: `HttpClient`, `IHttpClientFactory.CreateClient("name")`,
  Refit `RestService.For<IThing>`. `AddHttpClient("name", c => c.BaseAddress = ...)`.
- **Node/TS**: `fetch`, `axios`, `got`, `node-fetch`, `undici`. Generated
  OpenAPI clients. Env vars ending in `_URL`, `_ENDPOINT`, `_API`, `_BASE`.
- **Python**: `requests`, `httpx`, `aiohttp`, `urllib3`. Generated clients
  from openapi-generator. Pydantic `BaseSettings` attrs holding URLs.

## Contract and gateway signals

- OpenAPI / Swagger files imported or referenced at build time.
- gRPC `.proto` imports — `import "other-service.proto"` is an edge.
- GraphQL federation `@key` directives.
- API gateway route tables (Kong, Apigee, AWS API Gateway, Azure APIM) —
  every upstream is a dependency.
- Service mesh destinations: Istio `VirtualService`, Linkerd `ServiceProfile`.
- Ingress YAML `backend.service.name` values.

## Classification

- Synchronous hot-path call: **hard**.
- Cached call with fallback / circuit breaker with default: **soft**.
- Health or metrics endpoint only: **soft**, annotate `observability`.
- External third-party host (SWIM, ICAO, airline gateway): mark
  `external=true` and immovable.

## Common misses

- Calls hidden inside shared SDK jars / npm packages — open the package,
  not just the caller.
- URLs built via runtime string concat — grep `http://`, `https://`
  literals in source and config.
- Service name resolved only at deploy time — read the deployment
  manifest, not just the source tree.
