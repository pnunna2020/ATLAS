---
name: dependency-mapper
description: >
  Map cross-application dependencies including API calls, shared databases,
  message flows, batch job chains, and file-drop handoffs. Use during P0.2 for
  dependency graphing and P1.4 for wave constraint identification. Triggers on
  dependency mapping, dependency graph, cross-app dependencies, or integration
  mapping mentions.
agent: opus
allowed-tools:
  - Read
  - Write
  - Bash
  - Grep
validation_commands:
  - "python scripts/detect_cycles.py"
  - "python -m olympus.validators.integration_graph"
supported_stacks:
  - cobol
  - natural
  - csharp
  - dotnet
  - java
  - coldfusion
  - oracle-plsql
  - tsql
anti_target_stacks: []
failure_classes:
  - dangling-reference
  - missing-integration
  - circular-dependency
  - silent-wave-violation
benchmark_tags:
  - discovery-graph
  - wave-sequencing
  - integration-coverage
---

# Cross-Application Dependency Mapping

## Purpose
Build the dependency graph that determines wave sequencing. An unmapped
dependency is a deployment failure waiting to happen. This skill also emits a
portfolio-level `shared-db-clusters.json` sibling artifact when 2+ apps share
a canonicalized database so `wave-planner` can consume cluster membership
directly instead of re-inferring it from edges.

## Workflow
1. Collect integration evidence from P0.1/P0.2 outputs
2. Build dependency graph (directed: A depends-on B)
3. Identify circular dependencies (these MUST be broken)
4. Classify dependencies by type (API, DB, message, batch, file, external)
5. Identify hard vs soft dependencies (hard = fails without, soft = degraded)
6. Validate graph with `scripts/detect_cycles.py` as a hard gate
7. Cluster shared-database members: after the graph is built, group apps
   whose canonicalized database connection resolves to the same
   `(host, database_name)` tuple. Emit `shared-db-clusters.json` alongside
   `dependency-graph.json` when any cluster has 2+ members.
8. Output graph in format consumable by P1.4 wave planning

## Shared-DB Cluster Methodology (step 7 detail)

After the dependency graph is complete, pivot on the DB edges to produce a
portfolio-level grouping that `wave-planner` can consume without re-inferring
cluster membership:

1. For every app, extract the database connection strings discovered during
   dependency mapping (from `appsettings.json`, `spring.datasource.url`,
   `Application.cfc`, `DATABASE_URL`, etc.).
2. **Canonicalize** each connection string before comparison. Apply, in order:
   - `strip-credentials` -- remove `user:password@` segments, `;User Id=`,
     `;Password=`, `;uid=`, `;pwd=`
   - `lowercase-host` -- hostnames are case-insensitive; `ORADB01` and
     `oradb01` are the same cluster
   - `strip-default-port` -- `:1521` for Oracle, `:1433` for SQL Server,
     `:5432` for Postgres -- port-explicit and port-default strings collide
   - `normalize-engine` -- accept `sql-server`/`mssql` -> `sqlserver`,
     `postgresql` -> `postgres`, etc. (the schema stores only the normalized
     form; aliases live in this canonicalization layer, not in the schema)
3. Group apps by the canonical `(host, database_name)` tuple OR by the full
   canonicalized connection string when host and database are not
   independently extractable. A group with **2 or more** members becomes a
   cluster; singletons are dropped (trivially not-shared).
4. Record the canonicalization rules applied in the top-level
   `canonicalization_rules` array of the artifact -- operators reading the
   artifact need to know which normalizations ran (audit trail).
5. Per-member data:
   - `access_pattern` -- `read-only` / `read-write` / `write-only` / `admin`,
     inferred from grants, query patterns, or DDL
   - `connection_string_evidence` -- citation to the exact config file and
     line where the connection was declared
   - `schemas_touched` -- the schema names referenced in the app queries
6. Cluster-level data:
   - `shared_tables` -- tables referenced by 2+ members, with reader/writer
     app_id breakdown (enables contention analysis)
   - `risk_factors` -- `write-contention`, `schema-drift`,
     `cross-app-transactions`, `no-canonical-owner`, or `other`, each with
     severity (`blocker`/`major`/`minor`) and evidence

## Outputs

This skill emits **two artifacts**:

1. `dependency-graph.json` -- the cross-application dependency graph
   (always emitted). See `assets/dependency-graph-template.json`.
2. `shared-db-clusters.json` -- portfolio-level clustering of apps sharing a
   canonicalized database. Emitted when 2+ apps share at least one database
   (see `schemas/discovery/shared-db-clusters.schema.json`). The artifact is
   a portfolio-level deliverable -- it does **not** duplicate per-app edges
   already present in `dependency-graph.json`; it groups them so
   `wave-planner` can consume cluster membership directly without
   re-inferring it from the edge list.

## Detection References
Load the appropriate reference(s) based on the integration types present:

| Integration type | Reference |
|---|---|
| API / HTTP / gRPC / gateway | `references/api-dependency-patterns.md` |
| Shared DB / schema / grants | `references/shared-database-patterns.md` |
| Queues / topics / events | `references/message-queue-patterns.md` |
| Cron / Control-M / DAG chains | `references/batch-chain-patterns.md` |
| SFTP / MFT / file-drop (IACRA-CAIS) | `references/tiff-over-ftp-patterns.md` |

## Tools and Assets
- `scripts/detect_cycles.py` -- DFS-based cycle detector. Reads the graph
  JSON from stdin or `$1`, prints each cycle with type/hard annotations,
  exits non-zero when cycles exist. `--dot` flag emits a Graphviz snippet.
- `assets/dependency-graph-template.json` -- canonical schema skeleton
  with `_comment_*` fields documenting every edge field.

## Gotchas
- **Hidden dependencies through shared databases**: App A and App B may
  have no direct API calls but share an Oracle schema. HARD dependency,
  invisible at the application layer. See `shared-database-patterns.md`.
- **Batch job chains are timing dependencies**: Job A produces a file
  that Job B consumes at 2am. No runtime integration, still an edge.
- **File-drop handoffs look like nothing from the apps**: IACRA -> CAIS
  TIFF-over-SFTP has no code-level signals in either app. See
  `tiff-over-ftp-patterns.md`.
- **External dependencies (SWIM, airlines, ICAO) are immovable**:
  constraints, not dependencies you can refactor away.
- **A shared DB cluster is evidence, not a disposition**: a single shared
  database does not imply apps should be consolidated -- the cluster is
  evidence feeding `wave-planner`, not a Retire/Consolidate recommendation.
  Let the rationalization line decide; this skill only records the signal.

## Quality Rules
- [ ] Dependency graph covers all integration types: API calls, shared databases, message queues, batch job chains, and file transfers
- [ ] Every dependency is typed as API / DB / message / batch / file / external -- no untyped edges
- [ ] Hard vs soft classification is applied to every edge -- no missing `hard` field
- [ ] Hidden shared-database dependencies are detected -- not just direct API integrations
- [ ] Cycles are enumerated via `scripts/detect_cycles.py` before wave planning; zero cycles remaining or every remaining cycle has a documented break
- [ ] External/immovable dependencies (SWIM, airlines, ICAO) are marked explicitly with `external=true`
- [ ] Batch-chain temporal dependencies are detected -- cron schedules AND file-drop patterns, not just scheduler-declared chains
- [ ] Graph output matches `assets/dependency-graph-template.json` schema so wave-planner can ingest it without reshaping
- [ ] Every app in a `shared-db-clusters.json` cluster cites schema/DB evidence via `connection_string_evidence`
- [ ] Clusters with member count < 2 are not emitted (they are trivially not-shared; singletons are dropped)
- [ ] Database connection strings are canonicalized before comparison (strip credentials, lowercase host, normalize default port, normalize engine alias) and the applied rules are recorded in `canonicalization_rules`

## Common Failure Modes
| Failure Mode | Symptom | Prevention |
|-------------|---------|------------|
| Shared DB dependency missed | Apps appear independent at API layer but share an Oracle schema; deployment of one breaks the other | Include shared database analysis in dependency mapping; normalize connection strings and check grants per `shared-database-patterns.md` |
| Batch timing dependency missed | Job A produces file consumed by Job B; modernizing A without B breaks the chain | Scan for batch job chains with file-based or temporal dependencies; parse scheduler exports per `batch-chain-patterns.md` |
| Circular dependency not detected | Wave planning creates impossible deployment order; deadlock during migration | Run `scripts/detect_cycles.py` on the emitted graph; break cycles before wave assignment |
| External dependency treated as refactorable | Team plans to change SWIM interface; external consumers cannot adapt | Mark all external dependencies as `external=true` and immovable; plan around them, not through them |
| TIFF-over-FTP or file-drop integration missed | Apps appear independent but one produces a file (TIFF, PDF, XML) the other consumes; deploying either breaks the handoff | Scan for SFTP configs, scheduled file moves, and landing-zone filename patterns per `tiff-over-ftp-patterns.md` |
| Cycles passed through to wave-planner | Topological sort in wave-planner fails or silently drops nodes | Run `scripts/detect_cycles.py` as a hard gate before emitting the graph; resolve every cycle with a documented edge break |
| Wave-planner re-infers shared DB clusters | Planner scans edges for DB type and guesses membership; drift between skill and planner | Emit `shared-db-clusters.json` alongside `dependency-graph.json` so the planner reads cluster membership directly |

## Handoff Summary
When this skill completes, verify:
1. Dependency graph covers all integration types (API, DB, message, batch, file, external)
2. Every edge has a type and a hard/soft classification
3. `scripts/detect_cycles.py` returns exit 0, or every cycle has a documented break
4. External constraints are marked as immovable
5. Output conforms to `assets/dependency-graph-template.json` schema
6. If any database is shared by 2+ apps, `shared-db-clusters.json` is emitted
   with `canonicalization_rules`, `clusters` (each with `member_applications`
   minItems 2), and a populated `summary`
Then proceed to: wave planning (P1.4) using the dependency graph as scheduling constraints, and `decomposition-patterns` for shared DB strategy
