#!/usr/bin/env python3
"""Detect cycles in a dependency graph from the dependency-mapper skill.

Input JSON (stdin or $1):
    {"nodes": ["app-a", ...],
     "edges": [{"from": "app-a", "to": "app-b", "type": "api", "hard": true}, ...]}

Prints each cycle as: app-a -> app-b -> app-a (via type=api, hard=true)
Exits 0 if acyclic, 1 if cycles found. Flag --dot emits a Graphviz snippet.
"""
from __future__ import annotations

import json
import sys
from collections import defaultdict


def load_graph(source: str) -> dict:
    raw = json.loads(source)
    nodes = list(raw.get("nodes", []))
    edges = list(raw.get("edges", []))
    adjacency: dict[str, list[dict]] = defaultdict(list)
    for edge in edges:
        adjacency[edge["from"]].append(edge)
        for endpoint in (edge["from"], edge["to"]):
            if endpoint not in nodes:
                nodes.append(endpoint)
    return {"nodes": nodes, "adjacency": adjacency}


def find_cycles(graph: dict) -> list[list[dict]]:
    adjacency = graph["adjacency"]
    visited: set[str] = set()
    stack: list[str] = []
    stack_set: set[str] = set()
    path_edges: list[dict] = []
    cycles: list[list[dict]] = []

    def dfs(node: str) -> None:
        visited.add(node)
        stack.append(node)
        stack_set.add(node)
        for edge in adjacency.get(node, []):
            target = edge["to"]
            if target in stack_set:
                start = stack.index(target)
                cycles.append(path_edges[start:] + [edge])
                continue
            if target not in visited:
                path_edges.append(edge)
                dfs(target)
                path_edges.pop()
        stack.pop()
        stack_set.discard(node)

    for node in graph["nodes"]:
        if node not in visited:
            dfs(node)
    return cycles


def format_cycle(cycle: list[dict]) -> str:
    nodes = [cycle[0]["from"]] + [edge["to"] for edge in cycle]
    annotations = ", ".join(
        f"type={edge.get('type', 'unknown')}, "
        f"hard={str(edge.get('hard', False)).lower()}"
        for edge in cycle
    )
    return f"{' -> '.join(nodes)} (via {annotations})"


def emit_dot(cycles: list[list[dict]]) -> str:
    lines = ["digraph cycles {", "  rankdir=LR;", "  node [shape=box];"]
    seen: set[tuple[str, str]] = set()
    highlighted: set[str] = set()
    for cycle in cycles:
        for edge in cycle:
            highlighted.update((edge["from"], edge["to"]))
            key = (edge["from"], edge["to"])
            if key in seen:
                continue
            seen.add(key)
            label = f'{edge.get("type", "?")}/{"hard" if edge.get("hard") else "soft"}'
            lines.append(
                f'  "{edge["from"]}" -> "{edge["to"]}" '
                f'[color=red, label="{label}"];'
            )
    for node in sorted(highlighted):
        lines.append(f'  "{node}" [style=filled, fillcolor=mistyrose];')
    lines.append("}")
    return "\n".join(lines)


def main(argv: list[str]) -> int:
    want_dot = "--dot" in argv
    args = [a for a in argv[1:] if a != "--dot"]
    source = open(args[0], encoding="utf-8").read() if args else sys.stdin.read()
    cycles = find_cycles(load_graph(source))
    if not cycles:
        print("no cycles detected")
        return 0
    for cycle in cycles:
        print(format_cycle(cycle))
    if want_dot:
        print()
        print(emit_dot(cycles))
    return 1


if __name__ == "__main__":
    sys.exit(main(sys.argv))
