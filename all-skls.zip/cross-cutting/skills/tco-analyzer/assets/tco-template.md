# Total Cost of Ownership (TCO) Baseline Template

Template for capturing pre-modernization and post-modernization TCO for a
single FAA application. Use this as a worksheet; the final output feeds the
portfolio governance dashboard (P6.2) and cost savings certification (P6.3).

## Application Identity

- Application ID: <FAA-NNNN>
- Application name:
- Risk tier: <T1 / T2 / T3>
- Baseline fiscal year:
- Analyst:

## Annual Cost Breakdown

Per the FAA Announcement Element 7 definition, application TCO is the sum of
three categories only: Cloud/Infrastructure hosting, O&M labor, and licensing.
Development costs are EXCLUDED from operational TCO.

### 1. Cloud / Infrastructure Hosting
| Line Item                    | Monthly | Annual | Notes |
|------------------------------|---------|--------|-------|
| Compute (EC2/Fargate/Lambda) |         |        |       |
| Storage (S3, EBS, EFS)       |         |        |       |
| Database (Aurora, DynamoDB)  |         |        |       |
| Networking (data transfer)   |         |        |       |
| Monitoring & Logs            |         |        |       |
| Shared infrastructure share  |         |        | Apportioned per usage |
| **Subtotal hosting**         |         |        |       |

### 2. O&M Labor
| Role                         | Hours/Year | Rate | Annual | Notes |
|------------------------------|------------|------|--------|-------|
| Application support engineer |            |      |        |       |
| Database administrator       |            |      |        |       |
| Security / compliance        |            |      |        |       |
| **Subtotal O&M labor**       |            |      |        |       |

### 3. Licensing
| License                      | Quantity | Annual Cost | Notes |
|------------------------------|----------|-------------|-------|
| Database (Oracle, etc.)      |          |             |       |
| Application server           |          |             |       |
| Middleware                   |          |             |       |
| Third-party libraries        |          |             |       |
| **Subtotal licensing**       |          |             |       |

### Grand Total Annual TCO
- **Annual TCO** = hosting + O&M labor + licensing

## Apportionment Notes

Document any shared infrastructure cost that was apportioned across apps and
the apportionment methodology (usage-based / equal-share / other).

## Evidence Sources

Cite the source for each cost category: AWS Cost Explorer export date, O&M
contract identifier, license inventory snapshot, etc. Post-modernization TCO
must use actual AWS billing data, not estimates.

<!-- TODO(skill-author): Once the FAA standardizes on an xlsx template,
     replace this markdown worksheet with the binary template and document
     the tab layout and named-range conventions. Until then, this markdown
     version is the reference format. -->
