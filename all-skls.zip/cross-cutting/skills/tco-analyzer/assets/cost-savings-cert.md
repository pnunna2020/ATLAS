# Cost Savings Certification

## Application: {{APP_NAME}}
## Certification Date: {{DATE}}

| Cost Category | Pre-Modernization (Annual) | Post-Modernization (Annual) | Savings |
|--------------|---------------------------|----------------------------|---------|
| Cloud/Infrastructure | ${{PRE_INFRA}} | ${{POST_INFRA}} | ${{INFRA_SAVINGS}} |
| Operations & Maintenance | ${{PRE_OM}} | ${{POST_OM}} | ${{OM_SAVINGS}} |
| Licensing | ${{PRE_LICENSE}} | ${{POST_LICENSE}} | ${{LICENSE_SAVINGS}} |
| **Total** | **${{PRE_TOTAL}}** | **${{POST_TOTAL}}** | **${{TOTAL_SAVINGS}}** |

## Cost Reduction: {{PERCENT}}%
## Annual Savings: ${{TOTAL_SAVINGS}}
## 5-Year Projected Savings: ${{FIVE_YEAR}}

Certified by: _______________
Date: _______________
