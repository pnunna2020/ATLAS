---
name: tco-analyzer
description: >
  Calculate Total Cost of Ownership baselines and track cost changes through
  modernization. Use during P0.3 for baseline, P6.2 for tracking, and P6.3
  for cost savings certification. Triggers on TCO, cost baseline, cost savings,
  cost analysis, or application cost mentions.
agent: sonnet
allowed-tools:
  - Read
  - Write
  - Bash
---

# TCO Analysis & Cost Tracking

## Purpose
Establish per-app cost baselines before modernization, then track and certify
savings after deployment. This feeds the portfolio governance dashboard (P6.2)
and cost savings certification (P6.3).

## Workflow
1. Collect cost data: hosting, licensing, O&M labor, support contracts
2. Calculate pre-modernization annual TCO using `assets/tco-template.md`
3. After modernization: calculate post-modernization TCO
4. Generate cost savings certification using `assets/cost-savings-cert.md`

## Gotchas
- **Application cost = Cloud/Infra hosting + O&M + hosting** per the FAA
  definition in the Announcement (Element 7 footnote). Don't include
  development costs, only operational costs.
- **Shared infrastructure costs must be apportioned**: If 10 apps share an
  Oracle RAC cluster, each app's TCO includes 1/10 of the cluster cost
  (or proportional to actual usage if data is available).
- **License reclamation is a real savings**: When a legacy Oracle DB is
  decommissioned, those licenses are reclaimed. Track and quantify this.

## Quality Rules
- [ ] TCO includes all three cost categories: Cloud/Infra hosting, O&M labor, and licensing — per FAA Element 7 definition
- [ ] Shared infrastructure costs are apportioned (proportional to usage or equal split if usage data unavailable)
- [ ] License reclamation savings are tracked and quantified when legacy databases are decommissioned
- [ ] Pre-modernization TCO uses the standard template from `assets/tco-template.md`
- [ ] Post-modernization TCO uses actual AWS billing data, not estimates
- [ ] Cost savings certification uses `assets/cost-savings-cert.md` with auditable numbers

## Common Failure Modes
| Failure Mode | Symptom | Prevention |
|-------------|---------|------------|
| Development costs included | TCO inflated by including modernization development costs; not operational TCO | Use FAA Element 7 definition: Cloud/Infra hosting + O&M labor + licensing only |
| Shared infrastructure not apportioned | Oracle RAC cluster cost attributed entirely to one app; other apps show zero DB cost | Apportion shared costs proportionally to usage or equally across consuming apps |
| License reclamation not tracked | Oracle licenses freed by decommission but not reclaimed; savings not realized | Track license inventory changes at decommission; verify reclamation with procurement |
| Estimated post-modernization costs | Post-deployment TCO based on projections instead of actual AWS billing; inaccurate savings | Use actual AWS Cost Explorer data for post-modernization TCO after deployment stabilizes |

## Handoff Summary
When this skill completes, verify:
1. TCO baseline includes hosting, O&M, and licensing categories
2. Shared costs are properly apportioned
3. Post-modernization TCO uses actual billing data
4. Cost savings certification is generated with auditable figures
Then proceed to: `legacy-decommission` (P6.3) for cost savings certification, and `portfolio-health-check` for cost trend analysis
