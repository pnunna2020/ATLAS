---
name: program-context-reader
description: >
  Read the program / regulatory context documents attached to the application
  via ``--context-path`` and emit two schema-adjacent manifests:
  ``program-context-inventory.json`` (per-document metadata) and
  ``program-context-citations.json`` (per-regulatory-citation index with
  quote excerpts). Detects each document's ``document_type`` from YAML
  frontmatter, extracts citations using the same 14 CFR / 49 USC / FAA
  Order / ICAO patterns that ``compliance-citation-mapper`` consumes,
  distinguishes mandatory citations from illustrative ones, and flags
  CUI-adjacent vendor content (e.g. FAA toolchain). Triggers on program
  context documents, SOO / evaluation criteria reading, regulatory
  inventory, ATLAS proposal context, or @program-context-reader.
agent: sonnet
allowed-tools:
  - Read
  - Write
  - Grep
  - Bash
validation_commands:
  - "python -m olympus.validators.schema_validator program-context-inventory.json"
  - "python -m olympus.validators.schema_validator program-context-citations.json"
supported_stacks:
  - markdown
  - plaintext
  - faa-regulatory-corpus
  - atlas-proposal-docs
anti_target_stacks:
  - binary-pdf-only
  - encrypted-archive
  - office-docx-unparsed
failure_classes:
  - missing-frontmatter
  - binary-extraction-artifacts
  - illustrative-citation-false-positive
  - cui-adjacent-leak
  - zero-byte-file-counted
  - url-shortcut-treated-as-content
benchmark_tags:
  - program-context-reading
  - regulatory-citation-extraction
  - soo-inventory
  - atlas-faa-context
---

# program-context-reader

## Purpose
Own the reading and structured inventorying of the program / regulatory
context folder that an Olympus application points at via its
``context_path`` column (set by ``olympus add-app --context-path`` or
``olympus config-app --context-path``). Previously, FAA ATLAS apps had to
symlink the SOO + Background Information folders into each application's
``source_path`` tree so Discovery agents would find them, which polluted
citations (every rule looked like it came from a symlink) and duplicated
the same 26 markdown files across every app. This skill replaces that
workaround: the context folder is read *once* per Discovery / Rationalization
run, and the resulting inventory + citation manifests become the
load-bearing bridge between the regs corpus and every downstream
compliance-citation-mapper / disposition-recommender decision.

## Inputs
- ``app_context.context_path`` — absolute filesystem path to a directory of
  markdown / plain-text documents, set by the Olympus CLI and surfaced
  via ``olympus.fsm.worker._build_app_context``.
- Individual ``.md`` / ``.txt`` files under that directory, walked
  recursively. Typical FAA ATLAS contents:
  - SOO / Phase 2 Announcement / Evaluation Criteria / Deliverables
    Checklist / Clarification Questions (``/Users/.../SOO-Announcement/``)
  - 14 CFR Part 61, 14 CFR Part 67, 49 U.S.C. §44703, §44709, ICAO Annex 1,
    FAA Order 8080.6h, PRD guides, FAA toolchain, pain-point spreadsheets
    (``/Users/.../Background_Information/``)
- Optional YAML frontmatter on each document with:
  - ``source_file`` (original filename before extraction)
  - ``extracted_at`` (ISO timestamp)
  - ``source_folder`` (pre-extraction parent)
  - ``document_type`` — one of ``regulation`` | ``statute`` | ``guidance``
    | ``advisory-circular`` | ``reference`` | ``form`` | ``procedure`` |
    ``evaluation-criteria`` | ``clarification-questions`` | ``other``
- Regulatory citation patterns reference: ``references/regulatory-citation-patterns.md``

## Outputs
- ``program-context-inventory.json`` — one row per document:
  ``{document_id, source_path, document_type, title, summary, citation_key_prefix, regulatory_citations[], byte_size, cui_adjacent}``
  where ``document_id`` is a stable slug derived from the relative path
  (lowercase, hyphenated), ``citation_key_prefix`` is the token downstream
  skills use to cite back (e.g. ``SOO`` for the Statement of Objectives,
  ``14CFR61`` for Part 61), and ``regulatory_citations[]`` is the
  deduplicated list of citation tokens that appear in the document.
- ``program-context-citations.json`` — one row per *unique* regulatory
  citation the skill surfaced:
  ``{citation, document_id, quote_excerpt, source_line, citation_class}``
  where ``citation`` is the canonicalized citation string
  (e.g. ``"14 CFR §67.103"``, ``"49 USC §44703"``,
  ``"FAA Order 8080.6H"``, ``"ICAO Annex 1 §2.3"``), ``source_line`` is
  the 1-based line number inside ``source_path``, ``quote_excerpt`` is
  up to 240 characters of surrounding text, and ``citation_class`` is
  either ``mandatory`` (appears as a normative reference, "per", "in
  accordance with", "required by") or ``illustrative`` ("for example",
  "such as", "see also").

## Methodology
1. Read ``app_context.context_path`` from the agent's context block. If
   it is empty or missing, write both output files as empty arrays with
   an explanatory ``_note`` key and return immediately — the skill is a
   no-op for apps that have no context_path set, by design.
2. Walk the directory recursively with deterministic sort (POSIX path
   ascending). Skip hidden files, ``__pycache__`` descendants, zero-byte
   files, and anything not ending in ``.md`` / ``.txt``. Also skip
   ``.url`` shortcuts — a common Windows-clipboard artifact in the FAA
   background-information set. Never follow symlinks outside the root.
3. For each file, parse the first YAML frontmatter block (``---``
   fenced) into a dict. When frontmatter is missing, derive
   ``document_type`` heuristically from the filename:
   - contains ``CFR`` → ``regulation``
   - contains ``U.S. Code`` or ``USC`` → ``statute``
   - starts with ``AC_`` → ``advisory-circular``
   - contains ``Order`` → ``guidance``
   - contains ``Evaluation Criteria`` / ``Deliverables Checklist`` /
     ``Clarification`` → ``evaluation-criteria`` / ``clarification-questions``
   - contains ``Statement of Objectives`` / ``SOO`` → ``reference``
   - default → ``reference``
4. Extract a one-line ``title`` (the first Markdown H1, or the filename
   stem when no H1 is present) and a ≤ 400-char ``summary`` (the first
   meaningful paragraph after any H1 / frontmatter).
5. Scan the body for regulatory citations per
   ``references/regulatory-citation-patterns.md``. Capture one row per
   *occurrence* with the 1-based ``source_line`` number and a
   ``quote_excerpt`` spanning ±120 chars around the citation. Canonicalize
   the citation string (``"14 CFR §61.23"``, not ``"14cfr 61.23"``).
6. Classify each citation as ``mandatory`` or ``illustrative`` using
   the surrounding-sentence heuristics listed in
   ``references/regulatory-citation-patterns.md``. When the sentence
   contains any of {"for example", "such as", "e.g.", "see also",
   "among other"}, tag ``illustrative``; otherwise ``mandatory``.
   Unclear cases default to ``mandatory`` so downstream
   compliance-citation-mapper does not miss a normative reference.
7. Flag CUI-adjacent content. When a document body mentions any of the
   vendor-name tokens {"Booz Allen", "Deloitte", "Ernst & Young", "IBM",
   "Kentro", "KSGC"}, set ``cui_adjacent: true`` on the inventory row
   and emit the evidence in ``summary``. Do NOT embed those tokens in
   ``program-context-citations.json`` — the citation manifest must stay
   safe to share.
8. Deduplicate ``regulatory_citations[]`` per document (preserve first
   occurrence order). The citation manifest keeps *every* occurrence —
   downstream consumers need the per-line evidence.
9. Write both artifacts with sort-stable JSON output so identical inputs
   produce byte-identical manifests run-to-run.
10. Self-check: every ``regulatory_citations[]`` entry on the inventory
    side MUST appear at least once in the citation manifest, and every
    ``document_id`` in the citation manifest MUST correspond to an
    inventory row. Inconsistencies block handoff — the Rationalization
    pipeline's compliance-citation-mapper assumes both manifests are
    mutually consistent.

## Gotchas
- **YAML frontmatter may be missing.** Hand-converted PDFs in the
  FAA background-information set often arrive without frontmatter at all.
  Fall back to the filename heuristic in Methodology step 3 rather than
  dropping the document. Never invent a ``document_type`` — when the
  heuristic fails, use ``reference``.
- **PDF-to-text extraction artifacts.** Documents converted via
  ``pdftotext`` routinely lose layout: page headers repeat, column
  breaks merge into mid-sentence joins, and hyphenated line breaks
  split words. Citation extraction should tolerate a single whitespace
  run in the middle of ``"14 CFR § 61.23"`` and treat it as a single
  citation.
- **"For example" cites are not load-bearing.** The SOO quotes
  ``"e.g., 14 CFR §67.113"`` to illustrate a concept, not to bind the
  proposal to that specific regulation. Treating every quote as
  mandatory inflates the compliance-citation map and forces
  disposition-recommender to over-weight regulatory risk. Use the
  illustrative-vs-mandatory classifier in step 6.
- **``FAA toolchain.docx`` mentions vendor names that are CUI-adjacent.**
  The raw markdown extract lists several federal-contractor names. Flag
  the document in the inventory but keep the citation manifest vendor-free
  — the latter is meant to be committed / diffed.
- **``.url`` shortcuts are not content.** Windows-style URL shortcuts
  appear in the FAA background-information folder (``14 CFR Part 67
  (Medical).url``). They are 80-byte Windows INI files, not regulatory
  text. Skip them in step 2.
- **Zero-byte files are not real documents.** An empty ``.md`` file can
  slip into an extraction batch after a failed pdftotext run. Treat
  zero-byte as "no content" and skip.
- **Case-insensitive citation canonicalization.** ``"14 cfr part 67"``
  and ``"14 CFR Part 67"`` and ``"14CFR §67.103"`` must all collapse
  to the same canonical form so ``regulatory_citations[]`` does not
  contain three near-duplicates.
- **Every occurrence is cited separately.** Two quotes of the same
  citation on different lines MUST produce two rows in the citation
  manifest; the per-line evidence is what downstream skills use to
  attribute letter-wording and CFR sub-paragraph sourcing.

## Quality Rules
- [ ] Every row in ``program-context-inventory.json`` has a non-empty
      ``document_id`` and a ``document_type`` from the enum in the Inputs
      section.
- [ ] Every row in ``program-context-citations.json`` has a 1-based
      integer ``source_line`` that resolves to a real line in the named
      ``source_path`` (no zeros, no -1 placeholders).
- [ ] ``quote_excerpt`` length is ≤ 240 characters and contains the
      canonical citation string.
- [ ] Each document's ``regulatory_citations[]`` on the inventory side is
      a superset of the ``citation`` values appearing in the citation
      manifest for the same ``document_id``.
- [ ] Zero-byte files and ``.url`` shortcuts never appear in either
      manifest.
- [ ] ``cui_adjacent`` is ``true`` for any document body that contains
      vendor tokens in {"Booz Allen", "Deloitte", "Ernst & Young", "IBM",
      "Kentro", "KSGC"}; otherwise ``false``.
- [ ] The two manifests are byte-identical when re-run against the
      same context_path directory (deterministic output).
- [ ] ``citation_class`` on every citation row is exactly ``mandatory``
      or ``illustrative`` (no ``null``, no free-form values).

## Common Failure Modes
| Failure Mode | Symptom | Prevention |
|---|---|---|
| Missing frontmatter silently mapped to wrong document_type | Downstream compliance-citation-mapper routes the document through the wrong extraction path (e.g. treats a statute as a regulation) | Always run the filename-heuristic fallback in step 3; never default to ``regulation``; unclear cases go to ``reference`` |
| Binary extraction artifacts (repeated page headers, mid-word breaks) inflate citation count | ``program-context-citations.json`` has duplicate rows for the same line | Tolerate single whitespace runs inside canonical citations; dedupe per (citation, source_path, source_line) |
| "For example" cite treated as mandatory | disposition-recommender over-weights regulatory risk; proposal cites illustrative CFR sections as binding | Implement the illustrative-sentence classifier in step 6; default to ``mandatory`` only when neither class matches, log a warning |
| CUI-adjacent vendor name leaks into citation manifest | ``program-context-citations.json`` cannot be committed; diff workflow breaks | Vendor-name filter runs ONLY on the inventory ``summary`` field; the citation manifest never contains document body text beyond the ≤ 240-char quote excerpt, which must also pass the vendor-name filter |
| Zero-byte file counted as a document | Inventory has a row with empty title + summary + no citations; downstream skill wastes tokens | Skip ``stat().st_size == 0`` in step 2 |
| ``.url`` shortcut treated as content | 80-byte INI parsed as markdown; citation extraction produces garbage | Filter by extension whitelist (``.md``, ``.txt``) in step 2 |

## Handoff Summary
When this skill completes, verify:
1. ``program-context-inventory.json`` exists with one row per non-empty
   ``.md`` / ``.txt`` file under ``app_context.context_path``, excluding
   ``.url`` shortcuts and zero-byte files.
2. ``program-context-citations.json`` is internally consistent with the
   inventory (every citation ties back to a ``document_id`` present in
   the inventory; every inventory ``regulatory_citations[]`` entry has
   at least one citation row).
3. ``cui_adjacent`` flags are honest: the FAA toolchain document is
   flagged, the CFR / USC / ICAO documents are not.
4. ``citation_class`` is populated on every row with ``mandatory`` or
   ``illustrative``.

Then proceed to: ``compliance-citation-mapper`` in Rationalization (consumes
``program-context-citations.json`` as a first-class citation source
alongside source-code-derived citations), and ``disposition-recommender``
(reads ``program-context-inventory.json`` to understand the regulatory
surface of the application before scoring Retire / Consolidate options).

## References
- ``references/regulatory-citation-patterns.md`` — regex patterns for
  14 CFR, 49 USC, FAA Order, ICAO Annex, Advisory Circular, and Public
  Law citations; per-document-type extraction rules; illustrative-vs-
  mandatory classifier word lists.
- ``cross-cutting/skills/compliance-citation-mapper/SKILL.md`` — the
  downstream consumer whose citation format this skill must match.
- ``cross-cutting/skills/business-logic-extractor/SKILL.md`` — structural
  reference for the 9-field frontmatter shape used here.

## Changelog
- 2026-05-08 — Initial skill landing with the ``--context-path`` CLI flag
  feature. Declared as a Discovery supplementary and Rationalization
  supplementary skill in ``olympus/olympus/skills/registry.yaml``.
