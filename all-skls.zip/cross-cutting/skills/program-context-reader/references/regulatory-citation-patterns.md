# Regulatory Citation Patterns

This reference file defines the citation patterns and classification
heuristics the ``program-context-reader`` skill uses when scanning
``.md`` / ``.txt`` files under an application's ``context_path``.

Citation canonicalization matters because downstream consumers
(``compliance-citation-mapper``, ``disposition-recommender``,
``part-67-letter-wording-preservation-tracer``) group by the canonical
form — duplicates inflate regulatory risk scoring.

---

## Canonical forms

Every citation is normalized to one of these forms before it lands in
``program-context-citations.json`` or the inventory's
``regulatory_citations[]``:

| Source family | Canonical form | Example |
|---|---|---|
| 14 CFR Part | ``14 CFR Part <N>`` | ``14 CFR Part 67`` |
| 14 CFR section | ``14 CFR §<N>.<M>`` | ``14 CFR §67.103`` |
| 14 CFR paragraph | ``14 CFR §<N>.<M>(<letter>)`` | ``14 CFR §61.23(a)(2)`` |
| 49 USC section | ``49 USC §<N>`` | ``49 USC §44703`` |
| 49 USC paragraph | ``49 USC §<N>(<letter>)`` | ``49 USC §44709(b)`` |
| Public Law | ``Pub. L. <NNN>-<NN>`` | ``Pub. L. 111-216`` |
| Federal Register | ``<vol> FR <page>`` | ``85 FR 71530`` |
| Executive Order | ``EO <NNNNN>`` | ``EO 13526`` |
| FAA Order | ``FAA Order <NNNN>.<NN><letter>`` | ``FAA Order 8080.6H`` |
| FAA Advisory Circular | ``AC <NN-NN><letter>`` | ``AC 120-68J`` |
| ICAO Annex | ``ICAO Annex <N>`` or ``ICAO Annex <N> §<M>.<N>`` | ``ICAO Annex 1 §2.3.1`` |
| NIST SP | ``NIST SP <NNN-NN>`` | ``NIST SP 800-53`` |

**Case normalization.** Uppercase the framework token (``CFR``, ``USC``,
``FR``, ``FAA``, ``ICAO``, ``AC``, ``EO``, ``NIST``), lowercase the
``§`` marker input (``section``, ``sec.``, ``§``) into the Unicode
``§`` (U+00A7), and strip redundant whitespace to a single space.

**Hyphenation.** FAA Order suffix letters appear in both lower and
upper case in source documents (``8080.6h`` vs ``8080.6H``). Canonicalize
to uppercase (``8080.6H``).

---

## Regex pattern catalog

The following patterns are tuned for tolerant matching — they allow a
single run of whitespace inside the citation (common in pdftotext
output) and are case-insensitive on the framework token.

### 14 CFR
```
(?ix)
\b 14 \s* CFR \s*
(?:
  Part \s* (?P<cfr_part>\d{1,3})
  |
  (?:§|section|sec\.)? \s*
  (?P<cfr_section>\d{1,3} \. \d{1,4})
  (?: \s* \( (?P<cfr_para>[a-z0-9]+) \) )*
)
```

### 49 USC
```
(?ix)
\b 49 \s* U\.? \s* S\.? \s* (?:Code|C\.?) \s*
(?:§|section|sec\.)? \s*
(?P<usc_section>\d{3,5})
(?: \s* \( (?P<usc_para>[a-z0-9]+) \) )*
```

### Public Law
```
(?ix)
\b (?:Pub\.? \s* L\.? \s* (?:No\.?)? | Public \s+ Law ) \s*
(?P<pl_num>\d{2,3}) \s* [-–] \s* (?P<pl_chap>\d{1,4})
```

### Federal Register
```
(?ix)
\b (?P<fr_vol>\d{2,3}) \s+ FR \s+ (?P<fr_page>\d{3,6})
```

### FAA Order
```
(?ix)
\b FAA \s+ Order \s* (?P<order_num>\d{4} \. \d{1,2} [A-Za-z]?)
```

### FAA Advisory Circular
```
(?ix)
\b AC \s* (?P<ac_num>\d{1,3} - \d{1,3} [A-Za-z]?)
```

### ICAO Annex
```
(?ix)
\b ICAO \s+ Annex \s+ (?P<annex_num>\d{1,2})
(?: \s+ §? \s* (?P<annex_section>\d{1,2} \. \d{1,4}(?:\.\d{1,4})*) )*
```

### NIST Special Publication
```
(?ix)
\b NIST \s+ SP \s* (?P<nist_num>\d{3} - \d{1,3}[A-Za-z]?)
```

### Executive Order
```
(?ix)
\b (?:EO|Executive \s+ Order) \s* (?P<eo_num>\d{5})
```

---

## Per-document-type extraction rules

### ``regulation`` (14 CFR, 49 CFR, etc.)
- Walk the document top to bottom; every ``§`` occurrence opens a
  potential citation.
- Preserve sub-paragraph levels up to three deep
  (``§67.103(a)(2)(iii)``).
- Ignore citations that appear inside a markdown code fence
  (```` ``` ``` ````) — those are examples, not normative references.

### ``statute`` (49 USC, 18 USC, ...)
- Section numbers are 3-5 digits, no period. Reject accidental matches
  like ``49 USC 2026`` that are actually calendar years — check that the
  digit group falls in the published USC title range (§40101-§60301 for
  49 USC).
- Paragraph letters always lowercase ``(a)``, ``(b)``, ...; strip the
  paragraph from the canonical form when it is ``(1)`` alone (numeric
  sub-paragraph without a parent letter is invalid).

### ``advisory-circular``
- AC numbers follow ``<subject>-<revision><letter>`` format
  (``120-68J``, ``61-94``). Letter suffix is optional.
- When the AC cites a CFR section in its body, emit *two* rows: one for
  the AC citation and one for the CFR. The AC is the
  ``quote_excerpt`` source; the CFR is the referenced authority.

### ``guidance`` (FAA Order)
- Orders carry a numeric + decimal + single letter (``8080.6H``).
- Legacy citations in the body may omit the letter suffix (``8080.6``);
  canonicalize to the document's own header letter when the bare form
  appears.

### ``evaluation-criteria`` / ``clarification-questions`` / ``reference``
- These are proposal / programmatic documents. Expect *heavy* mixing of
  citation families (CFR, USC, FAA Order, ICAO, NIST) plus frequent
  illustrative use.
- Apply the illustrative-vs-mandatory classifier aggressively — roughly
  30% of citations in the SOO and Evaluation Criteria are illustrative.

### ``form``
- Forms (Change Your Airman Certificate Number, etc.) rarely carry
  citations in body text; when they do, it's typically a single line
  referencing the governing CFR. Extract the one-or-two citations and
  move on.

### ``procedure``
- Procedural docs (Getting_started in PRD, How to Review Pilot
  Records) may contain zero citations or a dense cluster in the
  "authority" section. Treat zero-citation docs as valid (not broken
  extraction).

---

## Illustrative vs mandatory classifier

For each citation occurrence, extract the containing sentence (bounded
by ``.``, ``?``, ``!``, newline-newline, or the start/end of the body).
Check that sentence for any of the following *illustrative markers*:

```
for example
such as
e.g.
i.e.
among others
among other
see also
see e.g.
see, e.g.
for instance
or similar
including but not limited to
by way of example
```

When any marker is present, classify the citation as ``illustrative``.
Otherwise, classify as ``mandatory``.

Additional *mandatory markers* strengthen confidence (not strictly
required, but useful for audit logs):

```
per
pursuant to
in accordance with
as required by
as defined in
subject to
governed by
per the requirements of
```

When the sentence boundary cannot be determined (pdftotext layout
damage), default to ``mandatory``. It is safer to over-weight regulatory
risk than to silently drop a normative reference.

---

## CUI-adjacent vendor token filter

``FAA toolchain.docx`` mentions the following federal-contractor names
in the context of current ATLAS tooling ownership. The ``program-context-
reader`` skill flags any document whose body contains any of these
tokens with ``cui_adjacent: true`` on the inventory row, and filters
them out of the citation-manifest quote excerpts:

```
Booz Allen
Booz Allen Hamilton
Deloitte
Ernst & Young
EY LLP
IBM
Kentro
KSGC
```

Do NOT remove the document from the inventory — the presence of the
file is public signal that the FAA toolchain doc was part of the
context. The flag lets downstream consumers decide whether to include
the summary in a shareable artifact.

---

## Test vectors (pin the canonicalization)

| Raw input | Canonical form |
|---|---|
| ``14 cfr 67.103`` | ``14 CFR §67.103`` |
| ``14CFR § 61.23 (a) (2)`` | ``14 CFR §61.23(a)(2)`` |
| ``14 CFR Part 67`` | ``14 CFR Part 67`` |
| ``49 U.S.C. § 44703`` | ``49 USC §44703`` |
| ``49 USC 44709(b)`` | ``49 USC §44709(b)`` |
| ``FAA order 8080.6h`` | ``FAA Order 8080.6H`` |
| ``AC 120-68J`` | ``AC 120-68J`` |
| ``ICAO Annex 1 section 2.3`` | ``ICAO Annex 1 §2.3`` |
| ``Public Law No. 111-216`` | ``Pub. L. 111-216`` |
| ``85 FR 71530`` | ``85 FR 71530`` |
| ``NIST SP 800-53`` | ``NIST SP 800-53`` |
