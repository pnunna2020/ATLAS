---
name: rdlc-reportviewer-extractor
description: >
  Extract the data model, parameters, layout, VB.NET expression surface,
  embedded code, and subreport graph of Microsoft RDLC client-side reports
  consumed by the ReportViewer control, during Discovery Pass 3 or
  Modernization Extract. Emits seven schema-validated manifests —
  rdlc-report-inventory.json, rdlc-dataset-manifest.json,
  rdlc-parameter-manifest.json, rdlc-expression-surface.json,
  rdlc-code-embedded.json, rdlc-subreport-graph.json, and
  rdlc-modernization-risk-findings.json — with `{repo}:{file}:{line}`
  traceability on every claim. Distinguishes client-side RDLC from
  server-side SSRS RDL (same XML, different runtime), surfaces
  ReportViewer-bound code-behind, flags the .NET-Framework-only
  ReportViewer dependency as a modernization blocker, and captures
  14 CFR Part 67 legally-mandated report outputs. Runs when the repo
  contains `.rdlc` or `.rdl` files or the tech stack fingerprint lists
  rdlc, reportviewer, or ssrs. Triggers on RDLC extraction, ReportViewer
  modernization, SSRS migration, report inventory, or
  @rdlc-reportviewer-extractor.
agent: sonnet
allowed-tools:
  - Read
  - Write
  - Grep
  - Bash
validation_commands:
  - "python -m olympus.validators.schema_validator rdlc-report-inventory.json"
  - "python -m olympus.validators.schema_validator rdlc-dataset-manifest.json"
  - "python -m olympus.validators.schema_validator rdlc-parameter-manifest.json"
  - "python -m olympus.validators.schema_validator rdlc-expression-surface.json"
  - "python -m olympus.validators.schema_validator rdlc-code-embedded.json"
  - "python -m olympus.validators.schema_validator rdlc-subreport-graph.json"
  - "python -m olympus.validators.schema_validator rdlc-modernization-risk-findings.json"
supported_stacks:
  - rdlc
  - reportviewer
  - ssrs
  - dotnet
  - csharp
  - vbnet
anti_target_stacks:
  - crystal-reports
  - jasper-reports
  - pure-html-reports
failure_classes:
  - rdlc-rdl-confusion
  - embedded-code-skipped
  - subreport-graph-broken
  - reportviewer-dependency-missed
  - parameter-binding-dropped
  - part67-compliance-regression
benchmark_tags:
  - modernization-report-extract
  - rdlc-traceability
  - reportviewer-risk
---

# rdlc-reportviewer-extractor

## Purpose
Own the extraction of Microsoft RDLC client-side reports as a first-class,
independently runnable skill. RDLC is the XML report format consumed by the
ReportViewer WinForms and WebForms control, rendered locally by the hosting
.NET application rather than by an SSRS server. ReportViewer is not
supported on .NET Core or .NET 5+, so every RDLC-bound legacy application
carries a modernization blocker inside a pair of
`ReportViewer1.LocalReport.ReportPath = "Foo.rdlc"` lines in code-behind.
The data model, parameters, layout, VB.NET expressions, and subreport graph
must be extracted before the report can be ported to SSRS, HTML/PDF, Power
BI Paginated, or a ReportViewerCore fork. This skill decomposes each
`.rdlc` into seven structured manifests so downstream skills
(`disposition-recommender`, `report-migration-designer`, Modernization
Generate) can reason about portability without re-reading XML.

## Inputs
- Application source tree containing `.rdlc` (client-side) and/or
  `.rdl` (server-side SSRS) files — scanned per file, not per solution
- Application catalog entry
  (`schemas/discovery/application-catalog-entry.schema.json`) —
  supplies `application_id`, module list, stack fingerprint
- Pass 1 .NET architecture fingerprint — identifies code-behind
  projects hosting ReportViewer
- Backup folders (e.g., `CpdssReports_Backup_2016/`) — branch-by-copy
  history, not silently deduplicated
- `references/rdlc-report-definition-patterns.md`,
  `references/ssrs-vs-rdlc-modernization-paths.md`

## Outputs
- `rdlc-report-inventory.json` — per report: `report_path`,
  `parent_project`, `rdlc_namespace_version`, `report_item_tree`
  (tablix/matrix/chart/gauge/image/textbox/subreport), `dataset_refs[]`,
  `parameter_refs[]`, `is_rdlc_not_rdl`, `citation`.
- `rdlc-dataset-manifest.json` — per dataset: `dataset_name`,
  `data_source`, `command_type`, `command_text` (credentials
  redacted), `field_bindings[]`, `filters[]`, `calculated_fields[]`.
- `rdlc-parameter-manifest.json` — per parameter: `name`, `data_type`,
  `default_value`, `prompt`, `allow_null`, `allow_blank`,
  `allow_multiple`, `available_values`.
- `rdlc-expression-surface.json` — every VB.NET expression: `site`,
  raw text, `references_fields[]`, `references_parameters[]`,
  `references_embedded_code`, `references_external_assembly`.
- `rdlc-code-embedded.json` — `<Code>` block content verbatim,
  declared classes and functions, `<CodeModules>` external assemblies,
  call-site cross-reference.
- `rdlc-subreport-graph.json` — nodes, parent-to-child edges,
  unresolved edges, cycles.
- `rdlc-modernization-risk-findings.json` — ReportViewer code-behind
  sites, ReportViewer2015+ SDK references,
  `Microsoft.ReportViewer.WebForms`/`.WinForms` package dependencies,
  DataSet/DataTable bindings, 14 CFR Part 67 compliance flags.

## Methodology
1. Enumerate every `.rdlc` and `.rdl` file. Read the XML namespace on
   the root `<Report>` element to classify the definition version
   (2008, 2010, 2016). Emit one inventory row per file. Record
   `is_rdlc_not_rdl` — the XML is identical; the distinction is
   runtime (ReportViewer LocalReport vs. SSRS server). Never collapse
   RDLC and RDL into one artifact.
2. Walk `ReportSections → Page → Body ReportItems` per report and
   build the report-item tree. Classify each node as `Tablix`,
   `Matrix` (legacy 2005), `Chart`, `Gauge`, `Image`, `Textbox`,
   `Rectangle`, `List`, or `Subreport`. Flag Matrix as legacy.
   Record the full path from root to each leaf so the layout is
   recomputable.
3. Extract dataset declarations from `<DataSets>`. Emit
   `dataset_name`, `<DataSourceName>`, `<CommandType>`,
   `<CommandText>` (credentials redacted), `<Fields>`, and filters.
   When `CommandType` is `StoredProcedure`, record the proc name so
   the PL/SQL or T-SQL extractor picks it up downstream.
4. Extract `<ReportParameters>` declarations. Each parameter emits
   `DataType`, `DefaultValue`, `Prompt`, `AllowNull`, `AllowBlank`,
   `MultiValue`, and `ValidValues` (static list or
   `DataSetReference` for dynamic). Parameters with a
   `DataSetReference` couple to a dataset — record the coupling so
   migration preserves it.
5. Walk every expression site: textbox and cell `<Value>`,
   `<Hidden>`, group and sort expressions, `<FilterExpression>`,
   parameter substitution in `<CommandText>`, and conditional
   formatting. Record the raw expression, classify references
   (`Fields!`, `Parameters!`, `Code.Foo(...)`,
   `Code!ClassName.Method(...)`, aggregates). Flag expressions that
   call embedded code — they cannot port independently of `<Code>`.
6. Extract `<Code>` blocks verbatim. VB.NET syntax even inside C#
   projects. Record declared classes and functions; cross-reference
   every call site. Parse `<CodeModules>` for external assemblies;
   external assemblies are a hard portability blocker.
7. Build the subreport graph. Walk `<Subreport><ReportName>` and
   resolve each to a filesystem path under the parent's project
   folder. Emit parent-to-child edges; flag unresolved references
   and cycles — ReportViewer does not render cyclic graphs.
8. Scan code-behind (`.cs` / `.vb`) for ReportViewer binding.
   Grep for `LocalReport.ReportPath`,
   `LocalReport.ReportEmbeddedResource`,
   `LocalReport.DataSources.Add`, `ReportParameter(`,
   `SetParameters(`, `RefreshReport()`. Each site is a
   modernization-risk finding with the bound `.rdlc` and the
   `DataSet`/`DataTable`/collection supplying rows. Scan `.csproj`
   and `packages.config` for `Microsoft.ReportViewer.*`.
9. Flag FAA compliance reports. Names matching `Part67*`,
   `MedicalCertificate*`, `SodaForm*`, `WorkflowItemHistory*`,
   `ApplicantNotes*` are 14 CFR Part 67 mandated outputs. Record
   the compliance constraint so `disposition-recommender` weighs
   Replace against Rearchitect.
10. Validate every manifest against its schema. Cross-check that
    every `parameter_refs[]` resolves into the parameter manifest,
    every `dataset_refs[]` into the dataset manifest, every
    `references_embedded_code: true` expression into the embedded
    code manifest, and every subreport edge terminates at a node.
    Dangling references are an auto-reject.

## Tech-Stack Dispatch

| Trigger | Key patterns |
|---|---|
| `.rdlc` file present | Client-side report; ReportViewer LocalReport in the hosting app |
| `.rdl` file present | Server-side report; SSRS runtime; same XML, different target |
| `Microsoft.ReportViewer.WebForms`/`.WinForms` reference | ReportViewer 2010/2012/2015 SDK; .NET Framework only |
| `LocalReport.ReportPath` or `LocalReport.ReportEmbeddedResource` | Code-behind binds RDLC to runtime data; XML alone is incomplete |
| Report project per `.rdlc` (DIWS pattern) | Solution inflation; backups carry branch-by-copy history |

Detection is mechanical. Overlap with `dotnet-discovery-patterns` is
explicit — this skill runs after the .NET fingerprint.

## Gotchas
- **RDLC and RDL share the same XML schema.** The `<Report>` root is
  identical; the distinction is runtime — ReportViewer LocalReport vs.
  the SSRS server. Treating them as one format (`rdlc-rdl-confusion`)
  collapses modernization paths that are not interchangeable: RDL may
  stay on SSRS or move to Power BI Paginated; RDLC must escape the
  ReportViewer runtime entirely.
- **ReportViewer is .NET Framework only.** Microsoft ships no
  supported ReportViewer package for .NET Core, 5, 6, or 8.
  `ReportViewerCore.NETCore` is a community fork with partial
  compatibility. Record the Framework dependency as a blocker —
  `reportviewer-dependency-missed` is the most common failure class.
- **Embedded VB.NET in `<Code>` is hidden business logic.** An
  expression like `=Code.CalculateAge(Fields!DOB.Value, Today())`
  carries a rule inside the `.rdlc`, not in the hosting app. Skipping
  `<Code>` (`embedded-code-skipped`) loses the logic on migration.
  Cross-link every call to a definition.
- **`Code.Foo()` vs. `Code!ClassName.Method()`.** The first calls the
  report's own `<Code>` block; the second calls an assembly declared
  in `<CodeModules>`. Migration paths diverge — external assemblies
  rarely port; embedded code always does.
- **DataSet/DataTable binding lives in code-behind.**
  `LocalReport.DataSources.Add(new ReportDataSource("DS1", dt))` is
  the only place the runtime row source appears. The `.rdlc` alone
  shows field shape; dropping the code-behind binding is
  `parameter-binding-dropped` applied to datasets.
- **Subreports resolve by filesystem lookup.** `<Subreport>
  <ReportName>Foo</ReportName>` takes no extension; ReportViewer
  appends `.rdlc` and looks under the parent's folder at runtime.
  Missing subreports pass XML schema — they fail only at render.
- **Project-per-report inflates complexity.** The DIWS pattern —
  `MSS.DIWSReports.{Report}` — gives one .NET project per `.rdlc`,
  with seven projects, seven `.csproj` files, and seven ReportViewer
  references. Emit one inventory row per `.rdlc`; never merge.
- **Backup folders carry independent history.** Folders named
  `CpdssReports_Backup_2016` or `*_Backup` are pre-source-control
  branch-by-copy. Each contained `.rdlc` is a historical version,
  not a duplicate. Flag `in_backup_folder: true`.
- **RDLC expressions are VB.NET even in C# projects.** `=IIF(...)`,
  `=Nothing`, `=CDate(...)`, `=Format(..., "C")` are VB forms.
  A C# parser fails on them.
- **Filter expressions live in three places.** Dataset, data region,
  and group filters. Only capturing dataset filters loses row-level
  filtering on tablix bodies.
- **14 CFR Part 67 reports are legally mandated.** Medical
  certificate, SODA, Part 67 summary, workflow history, and
  applicant-notes reports are federally required. Flag
  `part67-compliance-regression` so disposition does not pick
  Rearchitect where Replace is the only compliant option.

## Quality Rules
- [ ] Every `.rdlc` and `.rdl` has an inventory row with
      `rdlc_namespace_version`, `report_item_tree`, `dataset_refs[]`,
      and `parameter_refs[]` populated.
- [ ] Every citation uses `{repo}:{file}:{line}` form; no bare paths.
- [ ] Every `parameter_refs[]` and `dataset_refs[]` entry resolves
      into its sibling manifest.
- [ ] Every `<Code>` block is captured verbatim with referenced
      assemblies enumerated.
- [ ] Every `references_embedded_code: true` expression has a matching
      class/function in `rdlc-code-embedded.json`.
- [ ] Every subreport edge resolves to a node or is flagged
      `unresolved: true` with the lookup path cited.
- [ ] Every `LocalReport.ReportPath` site becomes one risk finding.
- [ ] `Microsoft.ReportViewer.*` references are findings with package
      id, version, and consuming project.
- [ ] 14 CFR Part 67 report names carry `compliance_mandated: true`
      with the regulatory citation.
- [ ] All seven manifests pass schema validation with zero errors.

## Common Failure Modes
| Failure Mode | Symptom | Prevention |
|---|---|---|
| RDLC/RDL confusion | SSRS path chosen for ReportViewer-bound RDLC; runtime mismatch at deploy | Branch on XML namespace; emit `is_rdlc_not_rdl` explicitly |
| Embedded code skipped | `Code.Foo(...)` calls lose implementation on port; render errors | Parse every `<Code>` verbatim; cross-link all calls |
| Subreport graph broken | Subreport renders blank or throws at runtime; parent-level tests pass | Resolve every `<Subreport>` to a filesystem path; flag unresolved |
| ReportViewer dependency missed | .NET Core port throws at first render; no .NET Core ReportViewer | Scan `.csproj`/`packages.config`; flag framework constraint |
| Parameter binding dropped | Code-behind `SetParameters` values missed; XML-only extraction incomplete | Scan `SetParameters`, `ReportParameter(`, `DataSources.Add` sites |
| Part 67 compliance regression | Rearchitect alters medical-certificate layout; FAA rejects output | Flag `compliance_mandated: true`; disposition must weight Replace |

## Handoff Summary
When this skill completes, verify:
1. All seven manifests exist and pass their schemas with zero errors.
2. Every `.rdlc` and `.rdl` has exactly one inventory row with the
   RDLC/RDL distinction recorded explicitly.
3. Every `<Code>` block is captured; every embedded-code call has a
   resolved definition.
4. Every subreport edge terminates at a node or is flagged
   `unresolved`; every cycle is flagged.
5. Every ReportViewer code-behind site and every
   `Microsoft.ReportViewer.*` package reference is in risk findings.
6. 14 CFR Part 67 reports carry `compliance_mandated: true` with the
   regulatory citation.

Then proceed to: `disposition-recommender` (uses risk findings to
weight Retire / Replace / Rearchitect per report);
`report-migration-designer` (Modernization Design — picks target
runtime per report from SSRS / HTML+PDF / Power BI Paginated /
ReportViewerCore); and, for Rearchitect apps, Modernization Extract
consumes the manifests directly. The next gate is **G-DT** (Discovery
Traceability) where every claim carries `{repo}:{file}:{line}`.

## References
- `references/rdlc-report-definition-patterns.md` — `.rdlc` XML
  anatomy, namespace versions, report-item tree, dataset and
  parameter extraction, expression parsing, `<Code>` block handling,
  `<CodeModules>` external assemblies, subreport resolution.
- `references/ssrs-vs-rdlc-modernization-paths.md` — five migration
  paths (stay on Framework, SSRS, HTML/PDF, Power BI Paginated,
  ReportViewerCore), 14 CFR Part 67 compliance preservation,
  DataSet/DataTable to modern DTO migration.

## Changelog
- 0.1.0 (2026-05-06) — Initial skill. `.rdlc`/`.rdl` enumeration,
  report-item tree, dataset and parameter manifests, expression
  surface, embedded `<Code>` extraction, subreport graph,
  ReportViewer code-behind detection, 14 CFR Part 67 flagging. Seven
  schema-validated manifests; feeds `disposition-recommender`,
  `report-migration-designer`, Modernization Extract.
