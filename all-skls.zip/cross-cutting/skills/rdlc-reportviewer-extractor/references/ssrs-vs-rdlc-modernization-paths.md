# SSRS vs. RDLC Modernization Paths

This reference documents the five realistic modernization paths for an
application that today renders reports through Microsoft's ReportViewer
control against `.rdlc` files, and the trade-offs each path forces onto
the hosting application, the data pipeline, and the rendered output.
The extractor surfaces findings; `disposition-recommender` and the
Modernization Design step choose the path.

## Why the paths matter

RDLC and RDL share an XML schema but not a runtime. RDL runs on an
SSRS server; RDLC runs inside the hosting application's process via
ReportViewer. Microsoft has not shipped a supported ReportViewer
package for .NET Core, .NET 5, .NET 6, or .NET 8. The last supported
version is the 2015 SDK on .NET Framework 4.x. Any application
dispositioned Rearchitect or Replatform inherits a report-runtime
decision whether or not the team realizes it.

## Path 1 — Stay on .NET Framework 4.8

Keep the hosting application on .NET Framework 4.8 indefinitely and
continue to use the ReportViewer 2015 SDK. Microsoft's long-term
support for .NET Framework 4.8 extends as long as the underlying
Windows Server release does; the runtime is not going away on a
calendar date. Reports render unchanged; no business-logic migration
is required.

Trade-offs:

- The hosting application is blocked from any modernization that
  requires .NET Core or later — no Linux containers, no modern ASP.NET
  Core middleware, no .NET 8 performance wins.
- ReportViewer 2015 carries known CVEs that Microsoft does not backport
  aggressively. The security posture of the application is pinned.
- The modernization program sees the report as frozen capability, not
  modernized capability. If the portfolio target is "everything on
  .NET 8 in containers," this path fails the portfolio goal.

Use when: the application is dispositioned Retain, or the regulatory
surface (14 CFR Part 67) makes any rendered-output change a
non-starter and the hosting app is otherwise stable.

## Path 2 — Port to SSRS (RDL)

Convert each `.rdlc` to a `.rdl`, deploy to a SQL Server Reporting
Services instance, and replace in-process rendering with a call-out
to the SSRS server. The XML conversion is trivial because the schemas
are compatible; the runtime work is substantial.

Trade-offs:

- Moves rendering out of the hosting application's process. The .NET
  Core port of the hosting app becomes unblocked — the ReportViewer
  dependency disappears from the hosting app's `.csproj`.
- Adds an operational dependency on an SSRS server, which is itself a
  .NET Framework product. The problem moves rather than disappearing.
- Authentication model changes from in-process (the hosting app's
  identity) to server-side (SSRS's authentication, typically Windows
  Integrated or forms). Any per-user data filtering expressed as
  `=Fields!X.Value = User!UserID` in expressions must be audited — the
  `User!UserID` value differs between runtimes.
- Connection strings move from the hosting app's `web.config` to the
  SSRS data-source definition. Credential rotation paths change.
- Embedded `<Code>` blocks port unchanged; external `<CodeModules>`
  assemblies must be deployed to the SSRS server's bin folder.
- Subreport resolution changes from filesystem lookup (parent report's
  project folder) to catalog lookup (SSRS's `/ReportFolder/`
  convention). Every subreport reference must be re-pointed.

Use when: the organization already runs SSRS; the hosting app is a
good candidate for the .NET Core port but the reports are not the
bottleneck; a server-side rendering model is acceptable.

## Path 3 — Port to HTML/PDF

Replace RDLC with a modern report-generation library that emits HTML
(for browser display) and PDF (for download and archive). Candidates
include QuestPDF, iTextSharp (PDF only), DinkToPdf (HTML-to-PDF
wrapper), or hand-rolled Razor templates with a headless browser for
PDF export.

Trade-offs:

- Full control over the hosting-app runtime — works on .NET 8, Linux
  containers, and modern auth. The ReportViewer dependency vanishes.
- The `.rdlc` XML is discarded; the report must be re-implemented. The
  data model (datasets, parameters, fields) ports by shape; the
  layout (tablix, charts, expressions) is rebuilt.
- VB.NET expressions in `<Code>` blocks must be ported to C#. `IIF`,
  `Switch`, `CDate`, `Format` have C# equivalents but not 1:1
  semantics — `IIF` evaluates both branches always, `? :` does not.
- Pagination is the hardest part. RDLC paginates at render time with
  widow/orphan control; HTML-to-PDF tooling paginates at CSS
  print-media-query time, which is less precise. For regulated
  outputs (14 CFR Part 67 medical certificates), the page break
  positions may be legally significant.
- Subreports become partial views; the subreport graph must be
  re-implemented as Razor partial calls.
- Effort: 2-5 days per RDLC for a straightforward tablix report; 10+
  days for a report with embedded code, charts, and subreports.

Use when: the hosting app is moving to .NET 8; the rendered output
tolerates re-layout; pagination is not regulated.

## Path 4 — Port to Power BI Paginated Reports

Deploy each report as a Paginated Report in Power BI Service or Power
BI Report Server. Paginated Reports accept RDL directly; `.rdlc`
conversion to `.rdl` is the same trivial XML step as Path 2.

Trade-offs:

- Offloads rendering and scaling to the Microsoft cloud. The hosting
  application calls the Power BI REST API to render; no in-process
  rendering, no ReportViewer dependency.
- Requires Power BI Pro or Premium licensing; cost model is different
  from on-prem SSRS.
- Authentication is Azure AD. FAA applications on-premises with
  Windows Integrated auth must bridge to Azure AD, which is often a
  separate program.
- Row-level security via `User!UserID` in expressions does not map
  cleanly to Power BI's row-level security model. Audit every
  expression that references `User!`.
- Data connection lives in the Paginated Report's dataset definition,
  not in the hosting app. `CommandType = StoredProcedure` is
  supported; the stored procedure itself must be reachable from the
  Power BI gateway.
- Subreports are supported, but only up to one level of nesting in
  some Paginated-Report cloud tiers. Deeply nested subreport graphs
  may require flattening.

Use when: the organization is standardizing on Power BI; the cost and
auth changes are acceptable; cloud rendering of regulated documents
is policy-compatible.

## Path 5 — ReportViewerCore.NETCore (community fork)

The `ReportViewerCore.NETCore` community fork ports the RDLC
rendering engine to .NET Core / .NET 5+. It accepts `.rdlc` files
mostly unchanged and exposes a `LocalReport` API similar to the
Microsoft original.

Trade-offs:

- Minimal code-behind rewrite — `LocalReport.ReportPath`,
  `LocalReport.DataSources.Add`, `SetParameters`, `Render` work with
  small API changes.
- The fork is community-maintained; no Microsoft support contract, no
  security advisory pipeline from MSRC. For an FAA portfolio, this is
  typically a governance blocker, not a technical one.
- Expression compatibility is good but not exact. VB.NET expressions
  compile via the fork's own expression host; some `Microsoft.VisualBasic`
  runtime functions behave differently. External `<CodeModules>`
  assemblies must be .NET Standard or .NET Core compatible — legacy
  .NET Framework-only DLLs do not load.
- `Microsoft.ReportViewer.WebForms` UI control is not ported. The
  render surface is programmatic (`LocalReport.Render(format, ...)`)
  and must be wrapped in a custom UI if the original app used the
  ReportViewer visual control.
- PDF, Excel, Word, and image format rendering is supported; HTML
  rendering (the ReportViewer default) is partial.

Use when: minimum-viable modernization is needed to unblock the .NET
Core port; governance accepts a community dependency for reports;
the hosting app renders to PDF/Excel rather than the ReportViewer UI
control.

## 14 CFR Part 67 compliance preservation

Medical-certificate reports (MEDXPRESS `PKG_MX_REPORT` outputs), Part
67 summaries (CPDSS `CPDSS_PART67_Reports`), SODA forms, workflow-item
history, and applicant-notes reports are legally-mandated outputs
under 14 CFR Part 67. Any change to the rendered layout, field
ordering, or field content requires FAA approval.

Path 1 (stay on Framework) is automatically compliant.

Path 2 (SSRS) is compliant if the rendering is byte-identical; SSRS
and ReportViewer share the same render engine at the 2015 SDK level,
so byte-identity is achievable but not free — test every Part 67
report against a reference render.

Path 3 (HTML/PDF) is compliant only if the rebuilt layout is
reviewed and approved as equivalent. This is typically a multi-month
FAA coordination effort. The extractor must flag every Part 67 report
as `compliance_mandated: true` so the disposition skill weights
Replace against Rearchitect; the disposition recommender should not
silently choose Path 3 for a mandated output.

Path 4 (Power BI Paginated) is compliant only if the rendered output
is byte-identical to the SSRS reference; the same test burden applies.

Path 5 (ReportViewerCore) is compliant as long as the fork's render
output matches the Microsoft original; community-fork drift is the
risk and must be regression-tested per release.

## Data-binding migration (DataSet/DataTable to modern DTO)

Legacy code-behind binds `DataSet` and `DataTable` to RDLC datasets:

```csharp
ReportViewer1.LocalReport.DataSources.Add(
    new ReportDataSource("DS_Applicants", dtApplicants));
```

Modern .NET code returns typed collections (`List<ApplicantDto>`) from
services. ReportViewer's runtime happily accepts `IEnumerable` as a
data source, including `List<T>`, as long as the property names match
the RDLC `<Field Name="...">` declarations. The migration step is:

1. Replace the `DataTable` with `List<T>` of a DTO whose properties
   match the `Field.Name` attributes (case-sensitive) in the `.rdlc`.
2. For calculated fields (`<Field><Value>=...</Value>`), add computed
   properties or pre-compute in the service layer.
3. For `DataSet.Relations`-backed master-detail reports, flatten the
   relation into nested collections on the parent DTO.

This migration is orthogonal to the runtime choice — it applies
under Paths 3, 4, and 5 equally.
