# RDLC Report Definition Patterns

This reference documents the XML anatomy of a Microsoft RDLC client-side
report and the specific constructs the `rdlc-reportviewer-extractor` skill
must identify, parse, and emit into the seven output manifests. The
structure is identical to server-side SSRS RDL — the distinction is the
runtime, not the markup.

## Root element and namespace versions

Every `.rdlc` opens with a `<Report>` root element carrying an XML
namespace declaration that pins the definition schema version. The
namespace is the single authoritative source of version truth — the
file extension does not distinguish versions, and the presence or
absence of specific elements is an unreliable signal because new
versions are largely backward-compatible supersets.

- `http://schemas.microsoft.com/sqlserver/reporting/2008/01/reportdefinition`
  — RDL 2008. Introduces the Tablix data region (replaces the 2005
  Table/Matrix/List trio as a unified model). Most FAA-era reports sit
  here.
- `http://schemas.microsoft.com/sqlserver/reporting/2010/01/reportdefinition`
  — RDL 2010. Adds the map data region, data bar, indicator, sparkline,
  and rotated text. Expressions are unchanged.
- `http://schemas.microsoft.com/sqlserver/reporting/2016/01/reportdefinition`
  — RDL 2016. Adds tree map and sunburst charts, parameter layout
  improvements. Still VB.NET expressions.

Record the matched namespace URI in `rdlc_namespace_version`. When
ReportViewer loads an RDLC, it refuses newer namespaces than its SDK
version supports — ReportViewer 2010 cannot render a 2016-namespaced
RDLC. The version pairing is a modernization finding.

## Top-level structure

A well-formed RDLC contains, in this order:

- `<AutoRefresh>` (optional) — seconds between automatic render cycles;
  ignored by ReportViewer LocalReport, honored by SSRS.
- `<DataSources>` — list of `<DataSource>` elements. Each carries a
  `Name` attribute, a `<ConnectionProperties>` block (for RDL) or is
  declared but left empty (for RDLC, which gets its connection at
  runtime from code-behind).
- `<DataSets>` — list of `<DataSet>` elements. This is the data model.
- `<ReportSections>` — container for `<ReportSection>` elements. Each
  section carries a `<Body>` (the visible report surface) and a
  `<Page>` (the paper canvas).
- `<ReportParameters>` — parameter declarations.
- `<Code>` (optional) — embedded VB.NET code block.
- `<CodeModules>` (optional) — references to external assemblies.
- `<EmbeddedImages>` (optional) — base64-encoded images stored in the
  report itself.
- `<DataElementName>`, `<DataSchema>`, `<DataElementStyle>` — XML
  export shape; typically inherited from default.

The extractor walks `<ReportSections>/<ReportSection>/<Body>/<ReportItems>`
to build the report-item tree. Each `<ReportItems>` is a container;
children are the visible widgets.

## Report-item tree

Children of `<ReportItems>` are typed by their element name:

- `<Textbox>` — atomic value rendering. Carries a `<Value>` child whose
  content is either a literal or an expression prefixed with `=`.
- `<Tablix>` — 2008+ unified tabular data region. Subsumes the 2005
  `<Table>`, `<Matrix>`, `<List>`. Contains `<TablixBody>`,
  `<TablixColumnHierarchy>`, `<TablixRowHierarchy>`, and
  `<DataSetName>` (binds to a dataset).
- `<Matrix>` — legacy 2005 format. Still accepted by 2008+ namespaces
  for backward compatibility; flag as `legacy_format: true`. Prefer
  Tablix in any migration.
- `<Chart>` — chart region. Contains `<ChartSeriesCollection>`,
  `<ChartCategoryHierarchy>`, `<ChartAreas>`.
- `<Gauge>` — radial or linear gauge. Rare in FAA reports.
- `<Image>` — image widget. `<Source>` is one of `External` (URL),
  `Embedded` (reference into `<EmbeddedImages>`), or `Database`
  (binary field in a dataset).
- `<Rectangle>` — grouping container. May hold nested `<ReportItems>`.
- `<Subreport>` — embedded child report. `<ReportName>` names the
  sibling `.rdlc` without extension.
- `<List>` — legacy 2005 free-form data region. Superseded by Tablix.

The extractor emits the full path from `Body` to each leaf, e.g.,
`Body/Rectangle1/Tablix_Main/TablixBody/TablixCells[3]/Textbox_Total`.
The path is what gives the emitted report-item tree its reproducibility.

## Dataset extraction

Each `<DataSet>` carries:

- `Name` attribute — the dataset identifier referenced by data regions.
- `<Query>/<DataSourceName>` — name of the declared data source.
- `<Query>/<CommandType>` — `Text`, `StoredProcedure`, or
  `TableDirect`.
- `<Query>/<CommandText>` — SQL text or stored procedure name.
  Redact any inline credentials before emitting.
- `<Query>/<QueryParameters>` — parameter substitution into the command.
- `<Fields>` — `<Field Name="..." DataField="..." TypeName="..." />`
  rows. `DataField` is the column name from the result set; `Name` is
  what the report uses in expressions (`=Fields!Name.Value`).
- `<Filters>` — dataset-level filtering expressed as
  `<Filter><FilterExpression>...` triplets.
- `<CaseSensitivity>`, `<Collation>`, `<AccentSensitivity>` — locale
  handling.

Calculated fields appear as `<Field>` elements with `<Value>` (an
expression) rather than `<DataField>`. These are derived columns
computed in the report; they carry business logic that must survive
migration.

## Parameter declarations

`<ReportParameters>/<ReportParameter Name="...">` carries:

- `<DataType>` — `Boolean | DateTime | Integer | Float | String`.
- `<DefaultValue>` — either `<Values><Value>literal</Value>` for static
  defaults or `<DataSetReference>` for defaults computed from a dataset.
- `<Prompt>` — user-facing label.
- `<AllowBlank>`, `<Nullable>`, `<MultiValue>` — validation flags.
- `<ValidValues>` — either `<ParameterValues>` for a static pick list or
  `<DataSetReference>` for a dynamic pick list. Dynamic pick lists
  couple the parameter to a dataset — record the coupling explicitly.
- `<Hidden>` — parameter not shown in the UI but still settable from
  code-behind.

Parameters with `<DataSetReference>` for defaults or valid values
cannot be migrated independently of their backing dataset.

## Expression surface

Expressions are VB.NET syntax, always. Every site that can hold an
expression is recognized by a `<Value>` child whose text starts with
`=`. Expression sites include:

- Textbox `<Value>`.
- Tablix cell `<Textbox><Value>`.
- `<Hidden>` visibility expressions on any report item.
- `<Group><GroupExpressions>` on tablix row/column groups.
- `<SortExpressions>` on groups and data regions.
- `<FilterExpression>` on dataset, data region, or group filters.
- `<CommandText>` for parameter substitution within SQL text.
- Conditional formatting inside `<Style>`: `<Color>`, `<BackgroundColor>`,
  `<FontWeight>`, `<TextDecoration>`.
- Calculated field `<Value>` elements in `<Fields>`.

Expression classification categories the extractor must emit:

- `field_reference` — `Fields!ColumnName.Value`.
- `parameter_reference` — `Parameters!ParamName.Value`.
- `aggregate` — `Sum(...)`, `Count(...)`, `First(...)`, `RowNumber(...)`.
- `builtin_function` — `IIF(...)`, `Switch(...)`, `CDate(...)`,
  `Format(...)`, `Today()`, `Now()`.
- `embedded_code_call` — `Code.FunctionName(...)`. Binds to the report's
  `<Code>` block.
- `external_code_call` — `Code!ClassName.Method(...)`. Binds to an
  assembly declared in `<CodeModules>`.
- `globals_reference` — `Globals!ExecutionTime`, `User!UserID`,
  `Globals!PageNumber`.

## Embedded code block

`<Code>` content is a CDATA block of VB.NET source. It runs as a class
named `Code` at report-render time, with whatever functions are
declared inside accessible as `Code.FunctionName(...)`. Imports default
to `Microsoft.VisualBasic`, `System.Convert`, `System.Math`.

The block is VB.NET regardless of the hosting application language. A
C# project that parses the `<Code>` text with a C# parser fails on
`Dim`, `If ... Then`, `Function ... End Function`. The extractor must
preserve the block verbatim and cross-link each call in the expression
surface to a declared function.

## External assemblies

`<CodeModules>/<CodeModule>` elements name assemblies to load at
render time. Format is `AssemblyName, Version=..., Culture=...,
PublicKeyToken=...`. The DLLs live next to the hosting application or
in the GAC. Calls to these assemblies use the form
`Code!ClassName.Method(...)` — note the `!` delimiter, not `.`.

External assemblies are a migration blocker: they rarely ship as
.NET Standard, and ReportViewer's replacement runtimes may not accept
them. Record every `<CodeModule>` reference in the embedded-code
manifest with a migration risk flag.

## Subreport resolution

`<Subreport>/<ReportName>` gives a logical name without extension.
ReportViewer appends `.rdlc` and looks under the parent report's
project folder. The extractor must walk the filesystem to resolve
each subreport reference to a concrete path; unresolved references
are flagged, not silently dropped. Subreports may nest, and a cycle
(A references B references A) is a bug — flag cycles in the graph.

Subreports carry their own parameters. The parent passes values via
`<Subreport>/<Parameters>/<Parameter>/<Value>` expressions. Record
the parameter bindings as subreport-edge metadata.

## Backup folder convention

Several FAA codebases (`CpdssReports_Backup_2016`, `MSS.DIWSReports
.Backup`) store pre-source-control history as copied folders. Each
`.rdlc` inside a backup folder is a distinct historical version, not
a duplicate. Emit inventory rows for all; flag
`in_backup_folder: true`. The rationalization step decides whether the
historical versions are retained or retired.
