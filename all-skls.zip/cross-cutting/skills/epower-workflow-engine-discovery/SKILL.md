---
name: epower-workflow-engine-discovery
description: >
  Surface ePower workflow-engine integration as a first-class Discovery output
  for the FAA Aviation Medicine (AAM) application portfolio (DIWS, AMCS,
  MEDXPRESS). ePower is a proprietary FAA case-routing engine referenced
  across AAM repositories only as a project suffix (`.EPower`), a SQL filename
  suffix (`*_EpoweOnly`, `*_EPowerOnly`), or an environment-gating marker
  (`DHS_*_EpoweOnly.sql`). It is never documented as a first-class integration
  point, so modernization can silently orphan the workflow-engine contract.
  This skill finds every ePower touchpoint, preserves typo variance
  (`Epowe`/`EPower`/`epower`/`Epower`) for traceability, reconstructs the
  cross-app routing flow, and emits six schema-validated manifests. Outputs
  are an evidence inventory plus a gap report — not a disposition. Triggers
  on ePower discovery, DHS SQL gating review, AAM workflow engine discovery,
  FAA workflow audit, or @epower-workflow-engine-discovery.
agent: sonnet
allowed-tools:
  - Read
  - Grep
  - Glob
  - Write
validation_commands:
  - "python -m olympus.validators.schema_validator epower-integration-surface.json"
  - "python -m olympus.validators.schema_validator epower-dotnet-surface.json"
  - "python -m olympus.validators.schema_validator epower-sql-surface.json"
  - "python -m olympus.validators.schema_validator epower-cross-app-flow.json"
  - "python -m olympus.validators.schema_validator epower-modernization-findings.json"
  - "python -m olympus.validators.schema_validator epower-environment-gating-findings.json"
supported_stacks:
  - dotnet
  - csharp
  - plsql
  - tsql
  - oracle
  - aspnet-webforms
anti_target_stacks:
  - static-site
  - pure-cdn-asset
  - mainframe-cobol
failure_classes:
  - typo-variant-missed
  - dhs-conflation
  - environment-gate-normalized-away
  - proprietary-engine-guessed
  - cross-app-leg-silently-dropped
  - filename-metadata-lost
benchmark_tags:
  - discovery-workflow-integration
  - faa-aam-portfolio
  - environment-gated-sql
  - cross-app-flow-reconstruction
  - proprietary-vendor-gap
---

# epower-workflow-engine-discovery

## Purpose
Elevate ePower — a proprietary FAA workflow / case-routing engine used across
the Aviation Medicine (AAM) portfolio — from an accidental naming convention
to a first-class Discovery artifact. Today ePower is visible only through
project suffixes (`MSS.DIWSWorkflow.EPower`), SQL filename suffixes
(`DHS_Auto_Insert_Query_EpoweOnly.sql`), and an inferred cross-app flow from
MedXPress intake through AMCS processing into DIWS routing. Because no vendor
documentation ships with the ATLAS delivery, Discovery cannot characterize
the engine's internals; instead this skill enumerates every touchpoint, cites
every line, and flags every unknown as a gap report. Carried from FAA4-1 as
**G-9** and tracked in the ATLAS gap report as **ATLAS-R-8**: a hard
modernization blocker — without this inventory, any disposition on
DIWS/AMCS/MedXPress risks dropping the ePower contract silently.

## Inputs
- Source repositories for the AAM portfolio — DIWS (.NET API solution with
  17 projects including `MSS.DIWSWorkflow.EPower`), AMCS (.NET Web Forms and
  Oracle SQL scripts), and MEDXPRESS (.NET and shared MSS schema touches).
- Application catalog entries for each AAM app (`schemas/discovery/application-catalog-entry.schema.json`)
  whose `tech_stack` contains `epower` or `dhs`, OR whose file tree matches
  the ePower / Epowe / EpoweOnly / DHS_ patterns.
- Tech fingerprint from `dotnet-discovery-patterns` Pass 1 (when available)
  — used to locate `.csproj` projects whose name ends in `.EPower` and to
  bound the SQL-script search to Oracle MSS back-ends.
- Shared MSS Oracle schema DDL (when shipped) — the `MSS.` prefix on
  the DIWS workflow project hints that ePower writes through this schema.
- Reference material — `references/epower-integration-patterns.md` for file
  and namespace pattern rules; `references/dhs-environment-gated-sql-patterns.md`
  for filename-suffix environment-gating catalog and DHS disambiguation.

## Outputs
- `epower-integration-surface.json` — per-app roll-up. One record per AAM
  application with `application_id`, `has_dedicated_project` (boolean),
  `project_path` (when present), `workflow_step_count_estimate`,
  `data_entry_points[]` (DB tables touched by ePower code paths), and
  `environment_gating_detected` (true when any `DHS_*_EpoweOnly.sql` sits
  in the repo).
- `epower-dotnet-surface.json` — for repos with a dedicated ePower .NET
  project, a full inventory of every class, interface, method, data
  contract, and event. Every entry carries a `{repo}:{file}:{line}`
  citation. Records whether ePower state machines are encoded in code or
  deferred to SQL.
- `epower-sql-surface.json` — every SQL script whose filename matches the
  ePower family (`*_EpoweOnly*`, `*_EPowerOnly*`, `*_EPower*`, `*_Epowe*`).
  Per script: purpose classification (`auto-insert | entry-criteria |
  update | cleanup | seed | unknown`), ticket-id extraction when the
  filename is ticket-keyed, and environment-gate indicator. The original
  filename is preserved byte-for-byte — typos included.
- `epower-cross-app-flow.json` — reconstructed workflow path across the
  AAM portfolio: MedXPress intake → AMCS processing → DIWS routing (via
  ePower) → DocumentQueue terminal. Each leg cites source evidence; legs
  with no in-repo evidence are emitted as reconstruction gaps, not as
  assumptions.
- `epower-modernization-findings.json` — the "what we cannot know from
  Discovery alone" report. Includes at minimum: `engine_type_unknown`
  (workflow engine vs. message bus vs. batch chain vs. human-task queue),
  `state_persistence_unknown`, `vendor_docs_absent`, `internal_contract_unknown`.
  Each unknown is cited to the absence of an artifact, not to a guess.
- `epower-environment-gating-findings.json` — catalog of every filename-as-
  metadata suffix (`_RunOnlyOnLowerEnvironment`, `_RunOnlyOnTEST`,
  `_EpoweOnly`, `_RunOnce`) with the environment matrix they encode; this
  convention must survive modernization.
- Schema-validation reports are written sibling to each artifact by
  `olympus.validators.schema_validator`; never hand-edit them.

## Methodology
1. **Scope the portfolio.** Read the catalog entries for DIWS, AMCS, and
   MEDXPRESS. Confirm each is in-scope via `tech_stack` (`epower`/`dhs`)
   or a filename glob for `*EPower*`, `*Epowe*`, `*_EpoweOnly*`, `DHS_*`.
   Do not narrow on display name — use `application_id`.
2. **Enumerate dedicated .NET projects.** For each repo, walk `*.sln`
   and `*.csproj` files. Flag every project whose name, namespace, or
   root namespace ends in `.EPower` or contains `EPower` as a segment
   (DIWS's `MSS.DIWSWorkflow.EPower` is the reference case). Record the
   project path, root namespace, total line count, class count, and
   interface count. A project over ~500 LOC is a thick adapter; under
   ~150 is a thin shim. Cite the finding as `{repo}:{csproj}:line-of-root-namespace`.
3. **Extract the .NET surface.** For every project flagged in step 2,
   read every `.cs` / `.vb` file. Emit one record per public class,
   interface, method, data contract (DTO / POCO / request / response),
   and event. Include the XML-doc comment when present; note that the
   DIWS ePower project characteristically has **no XML-doc and no inline
   rationale** — record "no-doc" as a finding, not as missing data.
4. **Enumerate the SQL surface.** Run a case-insensitive glob across the
   entire repo for `*EPower*`, `*EPowerOnly*`, `*Epowe*`, `*EpoweOnly*`,
   and any `DHS_*.sql`. Include the typo variant (`Epowe` with no 'r')
   — this is a deliberate preservation requirement, not a matching bug.
   Per script, classify purpose from the filename prefix (`Auto_Insert`,
   `Entry_Criteria`, `Update`, `Cleanup`, `Seed`) and record any trailing
   ticket-id pattern (e.g., `_CR12345`, `_JIRA-4567`). Do not rewrite
   the filename in the artifact — cite it verbatim.
5. **Reconstruct the cross-app flow.** Walk the inferred path: MedXPress
   intake writes `AM_APPLICANTS` (shared MSS), AMCS processes via
   `DHS_*_EpoweOnly.sql` scripts, DIWS's ePower project routes, terminal
   state lands in `AM_APPLICANTS_HISTORY`. Grep that table across all
   three repos to confirm the terminal leg. Emit legs without source
   evidence as reconstruction gaps flagged `evidence_absent: true`.
6. **Detect environment gating.** For every `DHS_*_EpoweOnly.sql`,
   `*_RunOnlyOnLowerEnvironment*`, `*_RunOnlyOnTEST*`, and `*_RunOnce*`
   file, record the suffix, the inferred deploy-environment (prod /
   test / lower / one-shot), and the deployment-script that reads the
   suffix (if findable). The filename is the contract — do not
   normalize, do not strip, do not "fix" the typo.
7. **Disambiguate DHS.** Emit an explicit finding that `DHS_` in this
   portfolio denotes **Department of Homeland Security** (airman
   background-check / vetting data exchange), not the Oracle engine
   and not a generic "ePower" prefix. The conflation risk is high
   enough that a silent mapping fails downstream consumers.
8. **Record what is unknown.** Proprietary engine internals, vendor-owned
   state-machine definitions, and any upstream ePower configuration not
   checked into the repo must be emitted as explicit unknowns in
   `epower-modernization-findings.json`. Discovery does not guess;
   Discovery flags.
9. **Validate and hand off.** Run schema validation on all six
   artifacts. Confirm every `{repo}:{file}:{line}` resolves. Confirm
   every filename citation preserves the original case and the typo.
   Hand off to `portfolio-integration-mapper` and the
   `cross-app-dependency-analyzer`.

## Tech-Stack Dispatch

| Trigger | Key patterns |
|---|---|
| `tech_stack_contains: epower` or project namespace ends `.EPower` | Dedicated .NET adapter project; extract full class / interface surface |
| Filename matches `*_EpoweOnly*` / `*_EPowerOnly*` (case-insensitive) | Environment-gated SQL deploy-time script; classify purpose and gate |
| Filename matches `DHS_*.sql` | Cross-agency (Dept. of Homeland Security) data-exchange SQL — disambiguate from ePower |
| `AM_APPLICANTS_HISTORY` table referenced in repo | Terminal state for cross-app ePower flow; cite as flow-leg evidence |
| No XML-doc on classes in a `.EPower` project | Tribal-knowledge integration; emit no-doc finding, not missing-data |

Detection is mechanical: one signal fires the matching reference pattern.
The `epower-integration-patterns.md` reference covers code-side detection;
`dhs-environment-gated-sql-patterns.md` covers SQL-side detection and the
DHS disambiguation.

## Gotchas
- **ePower is proprietary and undocumented in the ATLAS delivery.** No
  vendor manual ships with the repos. Discovery MUST NOT infer engine
  internals; guessing triggers the `proprietary-engine-guessed` failure
  class.
- **Typo variance is real and must be preserved.** `Epowe` (no 'r'),
  `EPower`, `epower`, and `Epower` all denote the same system. Matching
  is case-insensitive and dropped-'r' tolerant. Citation MUST preserve
  the original — `DHS_Auto_Insert_Query_EpoweOnly.sql` is NOT rewritten
  to `...EPowerOnly.sql`.
- **Environment gating is by filename suffix.** No config file, no
  feature flag. Deploy scripts inspect the suffix to decide application.
  Renaming or normalizing during modernization silently breaks the
  deploy contract (`filename-metadata-lost`).
- **`DHS_` is Department of Homeland Security, not the Oracle engine.**
  Cross-agency vetting / background-check data flow. Emit an explicit
  disambiguation finding to prevent the `dhs-conflation` failure class.
- **DIWS's `MSS.DIWSWorkflow.EPower` could be a thick adapter or a thin
  shim.** LOC, class count, and interface count distinguish the two.
  Record all three; do not guess from the name.
- **Cross-app flow is inferential.** AMCS writes the ePower SQL, DIWS
  hosts the .NET project, MedXPress has neither — the asymmetry itself
  is a finding. Legs without evidence are gaps, not assumptions
  (`cross-app-leg-silently-dropped`).
- **`MSS` is the shared Oracle schema.** The namespace
  `MSS.DIWSWorkflow.EPower` suggests ePower is a workflow integration
  layer on top of the shared schema, not an external service. Record
  as hypothesis, not conclusion.
- **No XML-doc on ePower project classes is diagnostic, not missing
  data.** Emit a `documentation_absent: true` finding per class —
  evidence of contractor-authored tribal knowledge.
- **`ImportApplication.aspx` in AMCS may be an ePower inbound
  endpoint.** Check page-level code for ePower import patterns.
- **Capability overlap risk.** `MSS.DIWSWorkflow` (non-EPower) may
  duplicate `.EPower` behaviour. Extract both surfaces; mark overlap
  candidates for `portfolio-integration-mapper`.
- **No disposition from Discovery alone.** Output is evidence inventory
  + gap report; Retire/Rearchitect/Replatform decisions wait for
  Rationalization.

## Quality Rules
- [ ] Every AAM app in the portfolio (DIWS, AMCS, MEDXPRESS) has a
      record in `epower-integration-surface.json`, even if
      `has_dedicated_project` is false.
- [ ] Every dedicated `.EPower` project has a full class / interface /
      method inventory in `epower-dotnet-surface.json`, each row cited
      as `{repo}:{file}:{line}`.
- [ ] Every SQL script matching the ePower family is in
      `epower-sql-surface.json` with its filename preserved byte-for-byte,
      including typos.
- [ ] Every leg of the cross-app flow has either a source citation or an
      explicit `evidence_absent: true` flag — no silent drops.
- [ ] `epower-modernization-findings.json` carries at least the four
      baseline unknowns: `engine_type_unknown`, `state_persistence_unknown`,
      `vendor_docs_absent`, `internal_contract_unknown`.
- [ ] DHS disambiguation is emitted as a named finding in
      `epower-environment-gating-findings.json`.
- [ ] Environment-gate filenames are listed with original casing and
      typos; no normalization.
- [ ] All six artifacts pass `olympus.validators.schema_validator` with
      `status: pass`.

## Common Failure Modes
| Failure Mode | Symptom | Prevention |
|---|---|---|
| Typo variant missed (`Epowe` without 'r' silently skipped) | SQL surface understates ePower footprint; AMCS scripts dropped | Glob case-insensitively AND accept the dropped-'r' pattern; do not rely on a single canonical spelling |
| DHS conflated with ePower | `DHS_` files mis-classified as ePower; cross-agency vetting flow attributed to the workflow engine | Emit explicit DHS disambiguation finding; classify `DHS_*.sql` as cross-agency unless the filename also carries `EpoweOnly`/`EPowerOnly` |
| Environment gating normalized away | Filenames rewritten to a "clean" form during modernization; deploy scripts silently stop matching | Preserve original filename verbatim in every citation; reference the filename-as-metadata convention in the environment-gating findings |
| Proprietary engine internals guessed | Discovery emits "ePower is a BPMN engine" or similar; Rationalization plans around a wrong assumption | Emit only what source evidence supports; unknowns are first-class in `epower-modernization-findings.json` |
| Cross-app leg silently dropped | MedXPress leg has no evidence, so the flow artifact omits it entirely; terminal-state reconstruction is wrong | Every leg is emitted with either evidence or `evidence_absent: true`; omission is never the right answer |
| Filename metadata lost in artifact | Artifact cites `DHS_Auto_Insert_Query_EPowerOnly.sql` when the real filename is `...EpoweOnly.sql`; deploy-time gating contract broken | Copy filenames verbatim from the filesystem; never round-trip through a normalizer |

## Handoff Summary
When this skill completes, verify:
1. All six artifacts exist next to the AAM portfolio catalog entries
   and pass schema validation.
2. Every filename cited preserves original casing and typo variance.
3. Every cross-app flow leg carries source evidence or an explicit
   reconstruction-gap flag.
4. The DHS-vs-ePower disambiguation is emitted as a named finding.
5. Proprietary-engine unknowns are the first-class output, not an
   afterthought.

Then proceed to: `portfolio-integration-mapper` (scores AAM portfolio
coupling from the cross-app flow and integration surface),
`dependency-mapper` (folds the .NET project list into the per-app
graph), and — during Rationalization — `disposition-recommender`
(uses the gap report to avoid Retire/Replace dispositions that would
orphan ePower). The next gate is **G-DC** (Discovery Completeness).
