# ePower Integration Patterns

This reference catalogs the code-side and namespace-side signals that
betray ePower integration across the FAA AAM portfolio. It is the
companion to `SKILL.md` for the `.NET` / `C#` surface; the SQL side is
covered in `dhs-environment-gated-sql-patterns.md`. ePower itself is
proprietary and undocumented in the ATLAS delivery — every rule below
is evidence-anchored to what does appear in the repos.

## 1. File-Pattern Matching

The ePower footprint in source is visible through four filename /
namespace conventions. Matching MUST be case-insensitive and MUST
tolerate the dropped-'r' typo (`Epowe` without 'r').

| Pattern | Where it appears | Example |
|---|---|---|
| `*.EPower` (project / namespace suffix) | `.csproj`, `.sln`, root namespace | `MSS.DIWSWorkflow.EPower.csproj` |
| `*EPower*` (token in filename) | `.cs` / `.vb` files inside the dedicated project | `EPowerWorkflowClient.cs` |
| `*Epowe*` (dropped-'r' typo) | SQL filenames, rarely in code | `DHS_Auto_Insert_Query_EpoweOnly.sql` |
| `*_EpoweOnly*` / `*_EPowerOnly*` (filename suffix) | Deploy-time SQL scripts | `DHS_Entry_Criteria_Query_EPowerOnly.sql` |

The matcher in Discovery MUST emit a record for any of the four
variants without normalization. A single `Epowe` hit is sufficient —
the spelling mistake is not a rendering artifact, it is a real
filename on disk.

## 2. Dedicated-Project Detection

The cleanest signal of ePower integration is a dedicated .NET project.
In the reference case — DIWS — the project is named
`MSS.DIWSWorkflow.EPower` and is one of 17 projects in the DIWS API
solution.

Detection rules, in order:

1. Walk every `*.sln` and extract the project list.
2. For each project, read the `.csproj` / `.vbproj` root namespace
   (`<RootNamespace>`) and the file-system path.
3. Flag the project when either:
   - The project filename contains `EPower` (case-insensitive), OR
   - The root namespace ends in `.EPower`, OR
   - The project folder name ends in `.EPower`.
4. Record the project as a dedicated ePower adapter and emit
   `has_dedicated_project: true` in `epower-integration-surface.json`.

A project whose namespace merely references `EPower` in a `using`
statement is NOT a dedicated project — it is a consumer. Record the
distinction: dedicated projects are extraction targets; consumers feed
the cross-app flow reconstruction.

## 3. Namespace Analysis

The namespace `MSS.DIWSWorkflow.EPower` decomposes as:

- `MSS` — shared Oracle schema (Medical Support System). Indicates
  that ePower is not an external service but an integration layer on
  top of the shared schema.
- `DIWSWorkflow` — DIWS-owned workflow abstraction. Suggests ePower
  is one workflow flavor among several; `MSS.DIWSWorkflow` (non-EPower)
  likely exists and must be enumerated for capability-overlap
  comparison.
- `.EPower` — the ePower-specific routing logic.

Inference: ePower is likely a specialization of a general DIWS
workflow surface, not a parallel external system. Record this as a
hypothesis in the integration surface artifact; confirm or refute
during extraction.

## 4. Inference Rules From .NET Project Size

Because no vendor docs ship with ePower, the project's size is the
only in-repo hint at whether the adapter is thick or thin.

| LOC range | Class count | Interpretation |
|---|---|---|
| < 150 | 1–3 | Thin shim. Likely a client stub calling an external service or stored procedures; modernization risk is moderate (contract is narrow) |
| 150–500 | 4–10 | Adapter with embedded state handling. Modernization risk is moderate-to-high; may encode business rules that belong upstream |
| 500–1500 | 10–25 | Thick adapter. Likely embeds workflow step definitions, retry logic, or compensation. High modernization risk |
| > 1500 | > 25 | Embedded engine. The ePower project IS (partly) the engine; replacement requires vendor cooperation |

Record the LOC and class count in
`epower-dotnet-surface.json`; do not guess the category when the
numbers are near a boundary — emit the raw values and let
Rationalization call it.

## 5. Method / Interface Surface Extraction

For every class in a dedicated ePower project, emit:

- Fully-qualified class name
- File path and line of the class declaration
- Base class / implemented interfaces
- Public method signatures (name, parameters, return type, XML-doc
  if present)
- Data contracts (DTOs / POCOs) declared in the same file or
  imported
- Events declared (`event EventHandler<...>`) — ePower adapters
  frequently use events for step-transition callbacks

Particular attention:

- **State-machine encoding.** Look for `enum WorkflowStep`,
  `enum EPowerState`, or a switch statement keyed on a string step
  name. Record whether state is encoded in code or deferred to SQL
  (it is often deferred in FAA-style integrations).
- **Idempotency markers.** Look for duplicate-detection logic on
  incoming messages or a processed-ID cache. ePower integrations
  that lack these are fragile to re-run.
- **Transactional boundaries.** Look for `TransactionScope`,
  `BeginTransaction`, or `SqlTransaction` — these determine whether
  modernization can safely split the adapter across service
  boundaries.

## 6. Cross-Repo Flow Reconstruction Methodology

ePower is not a single repo's concern — it routes across the AAM
portfolio. Reconstruction proceeds as follows:

1. Identify the terminal-state table. For AAM, this is
   `AM_APPLICANTS_HISTORY` (DIWS schema, may also be accessed from
   AMCS). Grep the table name across all three repos.
2. Identify the intake. MedXPress forms post to `AM_APPLICANTS`
   (or a staging equivalent). Grep for the insert site.
3. Identify the processing leg. AMCS `DHS_*_EpoweOnly.sql` scripts
   read from staging and write into ePower-owned queues / tables.
   Enumerate the scripts.
4. Identify the routing leg. DIWS's `MSS.DIWSWorkflow.EPower`
   consumes the queues and routes cases. Enumerate the entry-point
   classes.
5. Identify the completion leg. Completion is inferred from writes
   to `AM_APPLICANTS_HISTORY`. Grep for insert / update sites.

Each leg is emitted with source evidence. Legs with no evidence are
emitted as `evidence_absent: true` gaps — the absence itself is a
finding. The asymmetry (AMCS has SQL, DIWS has .NET, MedXPress has
neither) is a diagnostic: ePower's write side lives in AMCS SQL,
execution lives in DIWS .NET, and MedXPress participates only as an
upstream feeder.

## 7. Known Limitations: Proprietary = Black Box

Discovery CANNOT answer the following from source alone:

- What workflow engine does ePower actually use internally? (BPMN?
  a home-grown state machine? a message bus? a batch job chain? a
  human-task queue?)
- How is workflow state persisted? (Dedicated tables? A column on
  `AM_APPLICANTS`? An external store?)
- What is the ePower service's authentication / authorization
  model?
- Are there out-of-repo ePower configuration files that the .NET
  project reads at runtime?
- What SLAs / retry semantics does the engine promise?

Every one of these MUST be emitted as an explicit unknown in
`epower-modernization-findings.json`. Guessing is the
`proprietary-engine-guessed` failure class and will mislead
Rationalization. The skill's value is precisely to surface the
unknowns, not to paper over them.

## 8. ImportApplication.aspx and Inbound Endpoints

`ImportApplication.aspx` in the AMCS .NET Web Forms codebase is a
page-level candidate for an ePower inbound endpoint. Check:

- The `Page_Load` handler for calls into `MSS.*` stored procedures
  or `EPower*` classes.
- Query-string / form-post parameters named `ePowerCaseId`,
  `WorkflowId`, or `EPowerStep`.
- Hidden fields or `ViewState` entries referencing ePower step
  names.

A positive hit means AMCS is an ePower-aware page. Record it as an
inbound-endpoint finding, distinct from the SQL-side integration.

## 9. Capability Overlap With Non-EPower Workflow

`MSS.DIWSWorkflow` (no `.EPower` suffix) likely exists as a sibling
project or namespace. Enumerate its surface in parallel and emit a
capability-overlap candidate record when the two share method names,
data contracts, or target tables. The `portfolio-integration-mapper`
will use this overlap to score consolidation opportunities.

Overlap is NOT evidence that ePower is redundant — it is evidence
that the two workflow flavors may share abstractions. Modernization
will decide; Discovery records.

## 10. Traceability Rules

Every record emitted by this reference's rules MUST carry:

- Source citation: `{repo}:{file}:{line}` for the deciding line.
- Artifact citation: `{artifact}:{section}:{finding-id}` for the
  cross-skill handoff (e.g.,
  `epower-dotnet-surface.json:classes:F-012`).
- Original filename and casing when the finding is SQL- or
  filename-driven. Never normalize.

Records without both citations are dropped by the validator.

## 11. Documentation-Absent Finding

The DIWS ePower project characteristically has no XML-doc, no
inline rationale, and no README. This is a DIAGNOSTIC finding, not
a data gap. Emit one `documentation_absent: true` record per class
in the project; the pattern is evidence of contractor-authored
tribal-knowledge integration, which itself is a modernization risk
signal.

## 12. Quick-Reference Matcher

Pseudocode for the file-matcher used in step 1 of the skill's
methodology:

```
for path in repo.walk():
    name = basename(path)
    lower = name.lower()
    if any(m in lower for m in ["epower", "epowe"]):
        emit(path, original_name=name)
    if "dhs_" in lower and path.endswith(".sql"):
        emit(path, original_name=name, disambiguation="dhs")
```

The `original_name=name` argument is the traceability guarantee:
downstream consumers see the real on-disk name, typo and all.
