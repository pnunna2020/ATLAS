# DHS and Environment-Gated SQL Patterns

This reference catalogs the filename-as-metadata convention used by the
AAM portfolio's Oracle deploy-time SQL scripts. The convention is
undocumented outside the filenames themselves, but the deploy scripts
that apply them inspect the suffix to decide whether and when to run.
Modernization MUST preserve the convention; Discovery MUST inventory it.

It also disambiguates the `DHS_` prefix (Department of Homeland
Security cross-agency flow) from ePower (FAA workflow engine) — the
two co-occur in filenames and are easily conflated.

## 1. Filename-Suffix Convention Catalog

Every suffix below is real and has been observed in AAM source. The
matcher is case-insensitive, but the artifact MUST preserve the
original casing.

| Suffix | Meaning | Deploy-time effect |
|---|---|---|
| `_EpoweOnly` (dropped-'r' typo) | Run this script only when deploying for ePower environments | Skipped in non-ePower deploys |
| `_EPowerOnly` | Run only when deploying for ePower environments | Skipped in non-ePower deploys |
| `_EPower` | ePower-related (purpose implicit from context) | Applied when ePower is in scope |
| `_RunOnlyOnLowerEnvironment` | Run only in DEV / TEST / QA / UAT | Skipped in production |
| `_RunOnlyOnTEST` | Run only in the TEST environment | Skipped in DEV, QA, UAT, PROD |
| `_RunOnce` | One-shot script; must not be re-applied | Deploy script tracks applied state |
| `_Cleanup` | Post-deploy cleanup | Runs after the primary deploy |
| `_Seed` | Seed / reference data | Runs on fresh environments only |

A single filename may carry more than one suffix (e.g.,
`Fix_Applicant_Status_RunOnlyOnTEST_RunOnce.sql`). Parse every
suffix; record every gate.

## 2. Deployment-Script Inference

AAM does not ship a single canonical deploy orchestrator with the
ATLAS delivery. Evidence for the gating convention comes from:

- PowerShell / batch files in the repo root that glob SQL scripts
  and filter by suffix (e.g., `Get-ChildItem *_EpoweOnly.sql`).
- Oracle-side deploy logs whose script-names match the suffix
  pattern.
- Comments in a SQL script referencing sibling scripts by suffix.

When the deploy orchestrator is in the repo, extract its filter
logic and record it as a gating-contract finding. When it is not
in the repo, emit a `deploy_orchestrator_absent: true` finding —
the convention is still enforced by the filenames, but the
enforcer lives outside Discovery's reach.

## 3. Environment-Matrix Reconstruction

For each gated script, reconstruct the deploy matrix:

| Script suffix | DEV | TEST | QA | UAT | PROD | ePower env |
|---|---|---|---|---|---|---|
| `_RunOnlyOnLowerEnvironment` | yes | yes | yes | yes | no | depends on prod flag |
| `_RunOnlyOnTEST` | no | yes | no | no | no | no |
| `_EpoweOnly` / `_EPowerOnly` | depends | depends | depends | depends | depends | yes |
| `_RunOnce` | yes (once) | yes (once) | yes (once) | yes (once) | yes (once) | same |

Emit one matrix row per script in
`epower-environment-gating-findings.json`. The row is the deploy
contract; modernization must preserve it or explicitly replace it.

## 4. Cross-App vs. Per-App Gating

Environment gates apply at the per-script level but aggregate at
the per-app level. A single AMCS deploy pipeline may apply:

- All non-suffixed scripts (always)
- Scripts ending in `_RunOnlyOnLowerEnvironment` (in lower envs)
- Scripts ending in `_EpoweOnly` (when the target env participates
  in the ePower flow)
- Scripts ending in `_RunOnce` (only the first time the pipeline
  runs against a given target)

Record the per-app aggregation in the integration surface artifact:
for each AAM app, list how many scripts fall into each gating
bucket. This is the deploy-time fingerprint of the app's ePower
participation.

## 5. Typo Preservation Rules for Traceability

The following rules are non-negotiable:

1. **Never normalize `Epowe` to `EPower` in citations.** The
   filesystem has the typo; the deploy script reads the typo; the
   artifact MUST carry the typo.
2. **Never up-case, down-case, or camel-case filenames.** The
   glob is case-insensitive for matching; the citation is
   byte-exact.
3. **Preserve trailing `.sql`.** It is part of the filename, not a
   meta-extension.
4. **Preserve ticket-id suffixes** (`_CR12345`, `_JIRA-4567`,
   `_Ticket_9876`). These are audit trails.
5. **Do not collapse duplicated underscores.** `DHS__Entry_Criteria_Query_EPowerOnly.sql`
   is a real pattern; the double underscore is the filename.
6. **When citing, include directory.** `{repo}:sql/deploy/DHS_Auto_Insert_Query_EpoweOnly.sql:1`
   is correct; bare `DHS_Auto_Insert_Query_EpoweOnly.sql` is not.

Violating any rule breaks the deploy contract or the audit trail.

## 6. Environment-Gating vs. Feature-Gating Distinction

These two gate types are NOT the same and MUST NOT be merged:

| Kind | Mechanism | Where it lives | Example |
|---|---|---|---|
| Environment gating | Filename suffix | Filesystem / deploy orchestrator | `_RunOnlyOnTEST` |
| Feature gating | Runtime flag / config | Application code / config file | `app.config` `<appSettings>` `EnableEPowerRouting=false` |

The AAM portfolio uses environment gating exclusively for deploy-time
SQL. Feature gating would require runtime evaluation and is NOT how
these scripts work. Discovery MUST emit them as environment gates
even when the filenames superficially resemble feature flags — the
enforcement mechanism is the deploy script, not the running app.

## 7. DHS Disambiguation

`DHS_` at the start of a SQL filename denotes **Department of
Homeland Security** — cross-agency data exchange for airman
background checks and vetting. It is a data-source prefix, not an
engine prefix. ePower routes these records through its workflow
after DHS enrichment, which is why `DHS_*_EpoweOnly.sql` co-occurs:
"this is a DHS-sourced script that runs only in ePower deploys."

Conflation risks: a reviewer may misread `DHS` as "Data Handling
System" or a generic prefix; an ePower-keyed search may exclude
`DHS_` files without `EpoweOnly`; a DHS-keyed search may include
non-ePower `DHS_Audit_Log.sql`.

Discovery MUST emit an explicit `dhs_disambiguation` finding with
`finding_id`, `prefix: DHS_`, `meaning: Department of Homeland
Security`, `context: cross-agency airman background check /
vetting`, `not_to_be_read_as: [Data Handling System, generic prefix,
ePower alias]`, and a `citation` to an on-disk example filename.

## 8. Purpose Classification From Filename

Extract purpose from the filename prefix before the gate suffix:

| Prefix | Purpose |
|---|---|
| `Auto_Insert_` | Idempotent insert of seed / reference rows |
| `Entry_Criteria_` | Workflow entry-criteria query (does this record qualify for ePower routing?) |
| `Update_` | Column / row update against existing rows |
| `Fix_` | One-shot correction script |
| `Cleanup_` | Post-deploy cleanup |
| `Migration_` | Schema / data migration |
| `Report_` | Reporting / audit query |

Record the purpose per script in `epower-sql-surface.json`. When the
prefix does not match, emit `purpose: unknown` and cite the
filename — do not guess.

## 9. Ticket-Id Extraction

Some filenames embed a ticket id as the final token before `.sql`.
Patterns observed:

- `_CR12345` (change request)
- `_JIRA-4567` (JIRA key)
- `_Ticket_9876` (generic ticket)
- `_Defect_2345` (defect tracker)

Extract with a regex (`_(CR|JIRA|Ticket|Defect)[-_]?\d+`) and record
the ticket id alongside the script. These ids are the audit trail
for why the script exists; Rationalization will ask.

## 10. Quick-Reference Matcher for SQL Gating

Pseudocode for environment-gate extraction — walk the repo for
`*.sql`, lowercase the basename, test each gate suffix against it,
and emit `{path, original_name, gates, dhs, purpose, ticket_id}`
with `original_name` preserved byte-for-byte (typos included). The
`original_name` preservation is the contract; downstream consumers
MUST see the real filename.

## 11. Contract Summary

The environment-gating convention is a deploy-time contract that
survives only as long as the filenames do. Discovery's job:
enumerate every gated script preserving filename verbatim, classify
by gate type and purpose, disambiguate `DHS_` from ePower, and hand
the environment matrix to modernization so replacement mechanisms
(pipeline variables, feature flags, tagged scripts) can preserve
equivalent gating. Without this inventory, modernization either
keeps filenames it does not understand (fragile) or renames them
into a new convention it cannot verify is equivalent (broken).
