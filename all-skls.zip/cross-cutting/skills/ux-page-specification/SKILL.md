---
name: ux-page-specification
description: >
  Generate page-level specifications from discovered user flows. Translates legacy
  UI pages into structured specs for modern reimplementation with component inventories,
  data bindings, interaction catalogs, and accessibility assessments. Use during
  Modernization Extract phase (P4.1) after ux-flow-derivation completes. Triggers on
  page specification, UI spec, screen spec, page inventory, layout analysis, page design.
agent: opus
allowed-tools:
  - Read
  - Write
  - Grep
  - Bash
---

# UX Page Specification

## Purpose
Produce a complete, implementation-ready specification for every page in the legacy
application. Each page spec is a contract: it tells the modernization team exactly
what must appear on the page, how it behaves, what data it needs, and how users
interact with it.

This skill transforms the flow-level understanding (from ux-flow-derivation) into
page-level detail. Flows tell us what pages exist and how users navigate between them.
Page specifications tell us what each page contains and how it works. Without page
specs, developers must reverse-engineer the legacy UI during code generation, leading
to incomplete reimplementation, missed interactions, and broken accessibility.

This skill is the second step in the George methodology's UX pipeline:
1. ux-flow-derivation (flows between pages)
2. **ux-page-specification** (what each page contains) -- you are here
3. ux-component-specification (how each component works)

## Inputs
- UX flow derivation artifact (from ux-flow-derivation): the flow inventory,
  navigation map, form flow catalog, and complexity assessments
- Source code discovery artifact (from analyze-application or sdr-area-interface):
  the interface inventory for endpoint details
- Extraction artifact (from extraction skill): business rules, data models,
  and functional area groupings for understanding data bindings
- Source code repository (local path): direct access for analyzing view templates,
  stylesheets, and client-side code

## Outputs
- **Per-page specification documents** covering every page identified in the flow
  inventory
- **Page inventory index**: Master list of all pages with metadata (URL, auth,
  role, flow references)
- **Component inventory table** per page: every UI element typed, data-bound,
  and behavior-documented
- **Data requirements catalog** per page: APIs, queries, and data shapes needed
- **Interaction catalog** per page: every user action mapped to system response
- **Accessibility assessment** per page: current state and remediation requirements
- **Cross-page consistency report**: shared patterns, inconsistencies, and
  standardization opportunities

## Methodology

### Step 1 -- Build Page Inventory from Flows
Extract the complete page list from the flow derivation artifact:
- Every entry point (EP-NNN) from the flow inventory is a page
- Every intermediate step in a flow that renders a distinct screen is a page
- Modal dialogs, popups, and overlay panels that have distinct content are sub-pages
- Error pages (404, 500, validation error) are pages

For each page, record:
- Page ID (PG-NNN)
- Page name (descriptive, e.g., "User Profile Edit")
- URL pattern (from entry point or route definition)
- HTTP method for initial load
- Authentication required (yes/no)
- Role restrictions (list of roles)
- Flow references (which flows FL-NNN include this page)
- View template file (file:line reference to the source)
- Controller/handler file (file:line reference)

Cross-reference: every entry point in the flow inventory must have a page spec.
Any page appearing in flow diagrams but not in the page inventory is a gap.

### Step 2 -- Analyze Layout Structure
For each page, analyze the visual layout by reading the view template and
associated stylesheets:

**Layout zones** (identify which exist on each page):
- Header: branding, global navigation, user info, notifications
- Primary navigation: sidebar, top nav, breadcrumbs
- Content area: main functional content
- Secondary content: sidebars, related links, contextual help
- Footer: legal text, secondary navigation, version info
- Modals/overlays: popup content that overlays the main page

**Layout description format** (text-based wireframe):
```
+------------------------------------------+
| HEADER: Logo | Nav | User Menu           |
+--------+-----------------------------+---+
| SIDEBAR| CONTENT                     |   |
| Nav    | [Component A]               |   |
| Links  | [Component B]               |   |
|        | [Component C]               |   |
+--------+-----------------------------+---+
| FOOTER: Legal | Links | Version          |
+------------------------------------------+
```

Identify the layout template or master page that provides shared structure
(e.g., _Layout.cshtml, Master Page, base template). Shared layout elements
are documented once and referenced by all pages using that layout.

### Step 3 -- Inventory UI Components
For each page, catalog every UI component present:

| Component ID | Type | Label/Name | Data Binding | Behavior | Location |
|-------------|------|-----------|-------------|----------|----------|
| PG-001-C01 | text-input | "First Name" | user.firstName | Required, max 50 chars | Content zone |
| PG-001-C02 | dropdown | "State" | states API | Loaded on page init, filters city | Content zone |
| PG-001-C03 | data-table | "Recent Orders" | /api/orders?user={id} | Sortable, paginated, 25/page | Content zone |
| PG-001-C04 | button | "Save" | POST /users/{id} | Validates form, submits, redirects | Content zone |

**Component types to identify** (use this standardized taxonomy):
- **Input components**: text-input, textarea, number-input, date-picker, time-picker,
  file-upload, checkbox, radio-group, toggle, slider, color-picker
- **Selection components**: dropdown, multi-select, autocomplete, typeahead,
  transfer-list, tree-select
- **Display components**: data-table, list, card, badge, tag, tooltip, popover,
  progress-bar, chart, statistic, timeline, avatar
- **Navigation components**: link, button, tab-group, breadcrumb, pagination,
  stepper, menu, sidebar-nav
- **Layout components**: accordion, modal, drawer, collapse-panel, divider,
  space, grid
- **Feedback components**: alert, notification, message, spinner, skeleton-loader,
  empty-state, error-boundary
- **Form components**: form-group, field-label, validation-message, help-text,
  form-section, fieldset

For each component, document:
- Component ID (PG-NNN-CNN)
- Type (from taxonomy above)
- Visible label or name
- Data binding (what data field or API it connects to)
- Behavior summary (key interactions)
- Layout zone (where on the page it appears)
- Source reference (file:line in view template)

### Step 4 -- Map Data Requirements
For each page, document all data the page needs to render and function:

**Data sources**:
- Server-rendered data (passed from controller to view)
- API endpoints called during page load (REST, GraphQL, SOAP)
- API endpoints called on user interaction (lazy-loaded data)
- Static reference data (lookup tables, enums, configuration)
- Session/cookie data used on the page
- URL parameters consumed

**Data shape** per source:
```
Source: GET /api/users/{id}
Shape: {
  id: number,
  firstName: string,
  lastName: string,
  email: string,
  role: string,
  department: { id: number, name: string },
  recentOrders: [{ id: number, date: string, total: number }]
}
Used by: PG-001-C01 (firstName), PG-001-C02 (role), PG-001-C03 (recentOrders)
```

**Write operations**:
- Form submissions (which API/endpoint receives data)
- Inline edits (which fields can be edited in-place)
- Delete operations (what can be removed from this page)
- Bulk operations (multi-select + action patterns)

Map every data binding in the component inventory to a specific data source.
Unresolved data bindings (components that reference data not traceable to a source)
are gaps that must be resolved before handoff.

### Step 5 -- Document State Management
For each page, identify all state the page manages:

**URL state**: Query parameters, path parameters, hash fragments that affect
page rendering. Document which state is URL-encoded (and therefore bookmarkable/
shareable) versus transient.

**Form state**: Input values, validation state (pristine/dirty/invalid), which
fields have been touched, draft save state.

**Session state**: What the page reads from or writes to the server session.
What breaks if the session expires mid-interaction.

**Client-side state**: JavaScript variables, cookies, localStorage/sessionStorage
values that affect page behavior. For SPA pages: component state, store state
(Redux/Vuex/NgRx).

**Cross-page state passing**: How data moves from one page to the next:
- URL query strings (e.g., ?userId=123)
- POST data (form submission to next page)
- Session storage (server-side session)
- Client storage (localStorage, cookies)
- Hidden fields in intermediate forms

### Step 6 -- Build Interaction Catalog
For each page, document every user interaction and its result:

| Event | Trigger | Action | Result | Error Handling |
|-------|---------|--------|--------|---------------|
| Click "Save" | Button click | Validate form, POST /users/{id} | Redirect to profile view, success toast | Show inline validation errors, preserve form data |
| Sort table | Column header click | Re-query with ?sort=col&dir=asc | Table re-renders with sorted data | Show error toast, preserve current sort |
| Filter dropdown | Selection change | Re-query with ?status=active | Table updates, URL params update | Reset to "All" on error |
| Delete item | Click delete icon + confirm dialog | DELETE /items/{id} | Remove row, show success toast | Show error toast, row unchanged |

Categories of interactions to capture:
- **Navigation**: Clicking links, submitting forms, using browser back/forward
- **Data manipulation**: Creating, editing, deleting records
- **View manipulation**: Sorting, filtering, paginating, expanding/collapsing
- **Validation**: Field-level validation on blur, form-level on submit
- **Feedback**: Loading states, success messages, error messages
- **Keyboard shortcuts**: Tab order, enter-to-submit, escape-to-close,
  accessibility keyboard navigation

### Step 7 -- Assess Accessibility
For each page, evaluate against WCAG 2.1 AA criteria relevant to page content:

**Current state assessment**:
- Does the page have a logical heading hierarchy (h1 > h2 > h3)?
- Do all images have alt text?
- Do all form inputs have associated labels?
- Is the tab order logical (follows visual layout)?
- Are color contrast ratios >= 4.5:1 for normal text, >= 3:1 for large text?
- Can all interactive elements be reached and activated via keyboard?
- Are error messages associated with their form fields (aria-describedby)?
- Do data tables have proper header markup (th, scope)?
- Are dynamic content updates announced to screen readers (aria-live)?
- Is focus managed correctly after modal open/close, page navigation, AJAX updates?

**Remediation requirements** (for the modernized version):
- Missing ARIA attributes that must be added
- Keyboard navigation gaps that must be fixed
- Color contrast violations that must be corrected
- Focus management improvements needed
- Screen reader announcement improvements needed

For FAA systems: Section 508 compliance is a legal requirement, not optional.
Every page spec must include accessibility requirements. Reference the USWDS
accessibility guidelines for implementation guidance.

### Step 8 -- Identify Cross-Page Patterns
After all individual page specs are complete, analyze across pages:

**Shared patterns**:
- Common layout templates (how many distinct layouts exist?)
- Repeated component combinations (e.g., search + filter + data table pattern)
- Consistent navigation patterns (breadcrumbs, back buttons)
- Standard form patterns (create, edit, view detail)

**Inconsistencies**:
- Pages using different patterns for the same purpose (some tables paginate,
  others scroll)
- Inconsistent error display (some inline, some toast, some separate page)
- Inconsistent form layout (some horizontal, some vertical)
- Navigation inconsistencies (breadcrumbs on some pages but not others)

**Standardization opportunities**:
- Components that could be unified across pages
- Patterns that should be standardized in the modernized version
- Layout templates that should be consolidated

## Gotchas
- **View templates are not the complete picture**: JavaScript may dynamically add
  components, hide/show sections, or load content via AJAX. Read the JS too.
- **Master pages/layouts contain components**: Navigation, headers, and footers
  are in shared layouts. Document them once, reference them in each page spec.
- **Data binding is often indirect**: ColdFusion `#variables.foo#`, JSP EL
  `${bean.foo}`, Razor `@Model.Foo` all look different but are the same concept.
  Normalize to a consistent format.
- **Legacy CSS reveals layout**: When view templates use CSS classes like
  `col-md-6` or `float:left`, these encode layout decisions. Capture them.
- **Hidden fields carry state**: Forms often have hidden inputs carrying page
  state (CSRF tokens, entity IDs, wizard step indicators). These are real
  components even though users do not see them.
- **Accessibility is usually poor in legacy apps**: Do not just document the
  current state. Document what the modernized version MUST have for WCAG 2.1 AA.
- **SPA pages may have multiple "views" at one URL**: A tabbed interface or
  accordion may present multiple logical pages at a single URL. Treat each
  distinct view as a separate page spec if the content is substantially different.

## Quality Rules
- [ ] Every page in the flow inventory has a corresponding page specification -- zero gaps
- [ ] Every component in the component inventory uses the standardized type taxonomy
- [ ] Data bindings trace to actual data sources in the codebase (API, query, session) -- no unresolved bindings
- [ ] Interaction catalog covers all user-triggerable events on the page, not just primary actions
- [ ] Accessibility assessment evaluates against WCAG 2.1 AA criteria, not just visual review
- [ ] Layout descriptions use the structured wireframe format, not prose descriptions
- [ ] State management documents ALL state types (URL, form, session, client-side, cross-page)
- [ ] Source references (file:line) are included for view templates, controllers, and significant components
- [ ] Cross-page consistency analysis identifies shared patterns and inconsistencies
- [ ] For FAA systems: Section 508 remediation requirements are documented per page
- [ ] Modal dialogs and popups have their own component inventories, not just "modal exists"
- [ ] Form pages include both client-side and server-side validation rules from the form flow catalog

## Common Failure Modes

| Failure | Symptom | Prevention |
|---------|---------|------------|
| Static-only analysis | JavaScript-driven components missing from inventory; AJAX-loaded content invisible | Read JavaScript files for each page; trace dynamic DOM manipulation and AJAX calls |
| Shallow component inventory | Components listed as "form" or "table" without detail; useless for generation | Every component needs type, data binding, behavior, and interactions documented |
| Missing shared layout | Header/nav/footer components repeated in every page spec, or worse, omitted | Identify master pages/layouts first; document shared components once, reference elsewhere |
| Data binding guesswork | Data sources listed as "probably from database" without tracing actual code | Trace from component back through controller to query/API; document the complete chain |
| Accessibility afterthought | WCAG assessment is generic ("needs improvement") instead of specific per-page findings | Evaluate each page against specific WCAG criteria; document violations and remediation |
| No cross-page analysis | Each page spec exists in isolation; shared patterns and inconsistencies not found | After individual specs, do a cross-page pass to find patterns and standardization opportunities |
| SPA content missed | Single-page app shows as one page spec when it actually has 20+ distinct views | Analyze client-side routing; each distinct view/route gets its own page spec |
| Interaction catalog incomplete | Only "click button" interactions captured; keyboard, hover, drag, resize interactions missed | Systematically catalog all interaction types: navigation, data, view, validation, feedback, keyboard |

## Handoff Summary
When this skill completes, verify:
1. **Coverage**: Every page from the flow inventory has a page specification (PG-NNN)
2. **Component depth**: Every component has type, data binding, behavior, and source reference
3. **Data traceability**: All data bindings resolve to actual data sources in the codebase
4. **Accessibility**: Every page has WCAG 2.1 AA assessment with specific remediation requirements
5. **Consistency**: Cross-page analysis identifies shared patterns and standardization opportunities
6. Archive the page specification artifact as a versioned artifact in the artifacts directory
7. Proceed to **ux-component-specification** to produce component-level specs from these page inventories
8. Feed the component inventory into **design-system** skill for USWDS mapping and FAA branding alignment
