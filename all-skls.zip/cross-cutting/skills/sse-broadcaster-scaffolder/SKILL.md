---
name: sse-broadcaster-scaffolder
description: Generate Server-Sent Events (SSE) broadcaster + client components for real-time push of state changes from API → dashboard, with reconnection, heartbeats, and backpressure semantics.
phase: generate
category: modernization
status: stub-2026-05-27
maturity: minimal
inputs:
  - event-catalog.json     # which events to push to which subscriber roles
  - role-permission-matrix.yaml
outputs:
  - apps/api/src/domain/services/sse-broadcaster.ts
  - apps/api/src/handlers/<dashboard>/stream.ts
  - apps/web/src/hooks/useSseStream.ts (optional)
contract_invariants:
  - "SSE responses set Content-Type: text/event-stream + X-Accel-Buffering: no"
  - "Heartbeat every 15s; client reconnects on close"
  - "Per-role event filtering enforced server-side, not client-side"
  - "Backpressure: per-connection ring buffer; drop oldest on overflow with telemetry"
related_skills:
  - outbox-pattern-scaffolder  # outbox feeds SSE
  - local-cloud-adapter-scaffolder  # event-bus adapter sources SSE
  - node-api-generation         # handler housing the SSE endpoint
---

# sse-broadcaster-scaffolder

## Purpose

Stand up the server-side SSE broadcasting service plus the streaming HTTP endpoint. Used by the ATLAS Phase 3 prototype to push journey state updates and AME/CFI queue changes to role-specific dashboards in real time.

## When to use

- Dashboards need real-time updates (queue claim, decision posted, journey advanced).
- WebSockets are over-spec; one-way server-push is sufficient.
- Event volumes per connection are bounded (≤ a few/sec).

## Outputs

- Broadcaster service: ring buffer per connection, heartbeat, role-filtered emission.
- HTTP handler: long-lived SSE endpoint with proper headers.
- Optional client hook: `useSseStream<T>(url, onEvent)` with reconnect.

## Contract enforcement

- **Header check**: post-generation test asserts SSE-required headers.
- **Heartbeat**: integration test verifies heartbeat frame within 15s.
- **Role isolation**: contract test verifies no event leaks to wrong role.

## Phase 3 prototype usage

- `apps/api/src/domain/services/sse-broadcaster.ts`
- `apps/api/src/handlers/dashboard/stream.ts`

## Status

**STUB — 2026-05-27.** Full Phase 4.
