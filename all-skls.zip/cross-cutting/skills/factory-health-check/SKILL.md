---
name: factory-health-check
description: >
  Validate that all factory components are correctly configured for the current wave: agent manifests, skill assignments, hook configs, pipeline states. Use during P3.1 setup and P7.2 monitoring. Triggers on factory health, factory validation, configuration check, or factory status.
agent: sonnet
---

# Factory Health Check
## Purpose
Validate the factory is correctly configured before starting a wave's
Transform & Build phase. Catches configuration errors early.

## Checks
1. Every app in the wave has an agent manifest in the Registry
2. Every agent manifest references existing SKILL.md files
3. All hooks are registered and responding
4. Git worktrees are configured for parallel execution
5. CI/CD pipelines are connected and green
6. Test data is provisioned (P3.3 complete)
7. Target environments are provisioned (P3.2 complete)

## Gotchas
- **Skills added since last wave may not be in manifests**: When P7.1 creates
  new skills, they need to be added to the template manifest for future waves.
- **Hook registration is per-session**: Hooks from skills are only active when
  the skill is loaded. Verify hooks activate correctly in a test session.

## Quality Rules
- [ ] All 7 checks pass before a wave enters Transform & Build phase
- [ ] Every app in the wave has an agent manifest referencing valid SKILL.md files
- [ ] All hooks are registered and verified in a test session — not just listed in config
- [ ] Git worktrees are configured and accessible for parallel execution
- [ ] Test data (P3.3) and target environments (P3.2) are provisioned and verified
- [ ] New skills created since the last wave are included in the template manifest

## Common Failure Modes
| Failure Mode | Symptom | Prevention |
|-------------|---------|------------|
| Missing skill references | Agent manifest references a skill that was renamed or removed; agent fails at runtime | Validate all skill references against actual SKILL.md file paths during health check |
| Hooks not activated | Hooks registered in config but not activated in session; quality automation does not trigger | Test hook activation in a dedicated test session before wave start |
| Stale test data | P3.3 test data not provisioned or outdated; validation tests produce false results | Verify test data freshness and completeness as part of the health check |
| New skills missing from manifests | P7.1 created new skills but template manifest not updated; new apps miss improved capabilities | Check for skills created after last manifest update; add to template if applicable |

## Handoff Summary
When this skill completes, verify:
1. All 7 checks pass (manifests, skills, hooks, worktrees, CI/CD, test data, environments)
2. Any failures are resolved before proceeding to Transform & Build
3. Health check report is archived for the wave
Then proceed to: `extraction` (P4.1) to begin the Transform & Build phase for the wave
