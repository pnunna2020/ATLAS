---
name: phase-commitment-traceback
description: >
  Author the 10-page Phase 3 written narrative for FAA ATLAS SF2: capability-
  to-Phase-2 mapping table, eliminated-duplication evidence, service-
  decomposition decisions, implementation deviations / tradeoffs / modified
  assumptions (BASE-C and Bedrock excluded as silence-not-commitment
  deviations), scalability, operational readiness, and enterprise reuse.
  Hard cap: 10 pages, 1" margins, 12pt body in Times/Aptos/Arial/Calibri.
  Use during Phase 3 build day 9. Triggers on written narrative, traceability
  narrative, Phase 2 to Phase 3 mapping, deviation log, 10-page document, or
  SF2 narrative mentions.
agent: sonnet
enrichment_level: Full
tags:
  - traceability
  - evidence-generation
  - factory-ops
allowed-tools:
  - Read
  - Write
  - Bash
---

# Phase 2 → Phase 3 Traceability Narrative Builder

## Purpose
Author the 10-page MS Word narrative that maps every Phase 3 prototype
capability back to a Phase 2 commitment, names every implementation
deviation, and articulates scalability, operational readiness, and enterprise
reuse. This is the single most carefully-graded artifact in the SF2
submission (per gap matrix §4 NEW-4 and build plan §4 D2): the FAA
evaluator scores Phase 3 on traceability to Phase 2.

The narrative is **not** a brochure. It is a structured, citation-heavy,
format-bounded document. Page count, font, and margin compliance are MUST
requirements (P3-R54..R61); content traceability is the difference between
a high-confidence and some-confidence rating.

## When to use

Invoke this skill on Phase 3 build day 9 (per `docs/phase3/build-demo-skills-plan.md`
§6 D2), **after** the prototype manifest is stable (services deployed,
routes pinned, IaC modules committed, persona-keyed UI screens demoable
end-to-end). Re-invoke whenever:

- A prototype capability is added or removed and the capability-map table
  must be re-issued.
- A new deviation is identified during dry runs.
- The Q&A rehearsal surfaces a contradiction with the narrative — re-author
  the offending section.

Do not invoke this skill before Day 9. Invoking earlier produces a
narrative against an unfinished prototype, and the rewriting cost
exceeds the time saved.

## Inputs

```yaml
phase2_source:
  primary: docs/phase3/phase2-commitments.md
  required_sections:                # the canonical anchor list
    - A.1                           # per-system disposition table
    - A.2                           # cross-system business value
    - B.1                           # 6-layer target operating model
    - B.2                           # 11 target services S1-S11
    - B.3                           # technology choices (USWDS, OpenAPI 3.1, etc)
    - B.4                           # data strategy, 8 canonical entities
    - B.5                           # cATO posture, 10 NIST families
    - C.1                           # 5 waves
    - C.2                           # gating events
    - C.3                           # assumptions A1-A11
    - C.4                           # risks R1-R5
    - D.1                           # 22-stage J08
    - E                             # 12 roles
    - F.1                           # headline reductions
    - F.2                           # eliminated workflows
    - F.3                           # eliminated cross-system inefficiencies
    - G.1-G.7                       # high-confidence verb commitments
    - H.5                           # per-system A6 prerequisites (deviation seeds)
    - H.7                           # BASE-C / Bedrock not in P2 sources
prototype_manifest:
  services_deployed:                # one entry per running service
    - { name: s1-identity, image: ghcr.io/.../s1:abc1234, openapi: openapi/s1.yaml, source: services/s1/ }
    - { name: s2-guided-intake, image: ..., openapi: ..., source: ... }
    # ... s3, s5, s6, s7, s8, s9, s11 (s4, s10 are stubs)
  ui_screens:
    - { route: /dashboard, role: applicant, source: web/applicant/src/pages/Dashboard.tsx }
    - { route: /ame/console, role: ame, source: web/applicant/src/pages/AMEConsole.tsx }
    # ... all role views from pilot-certification-dashboard-spec
  iac_modules:
    - infra/cdk/lib/vpc-stack.ts
    - infra/cdk/lib/api-stack.ts
    - infra/cdk/lib/data-stack.ts
    - infra/helm/charts/services/   # Phase 4 stub only
    - infra/docker-compose.yml
  pipeline_evidence:
    pipeline_run_summary: evidence/pipeline-run-summary.json
    oscal_dir: evidence/oscal/
    sast_reports: evidence/sast/
    sca_reports: evidence/sca/
    container_scan_reports: evidence/container-scan/
    iac_scan_reports: evidence/iac-scan/
    dast_reports: evidence/dast/
deviation_log:
  source: docs/phase3/skills-gap-matrix.md  # §5 deviation register
  count_required: 6                          # the canonical six from build-demo-skills-plan.md §1.1
  base_c_handling: "exclude as silence-not-commitment per phase2-commitments.md §H.7"
  bedrock_handling: "exclude as silence-not-commitment per phase2-commitments.md §H.7"
format:
  page_size: letter                  # 8.5 x 11 in
  margins_inches: 1.0                # all four sides
  body_font: calibri                 # one of TNR / Aptos / Arial / Calibri (P3-R57)
  body_size_pt: 12
  table_min_size_pt: 8
  header_footer_min_size_pt: 10
  max_pages: 10                      # HARD cap (P3-R54)
output:
  primary_format: docx               # MS Word per P3-R61
  fallback_format: pdf               # also emit a searchable PDF
  filename: "Phase3-Written-Narrative.docx"
```

## Outputs

| Path | Purpose |
|------|---------|
| `submission/written-submission/Phase3-Written-Narrative.md` | Markdown source. |
| `submission/written-submission/Phase3-Written-Narrative.docx` | MS Word render via the `docx` skill. |
| `submission/written-submission/Phase3-Written-Narrative.pdf` | Searchable PDF, fallback per P3-R61. |
| `submission/written-submission/capability-map.csv` | Phase 3 capability ↔ Phase 2 anchor table, machine-readable. |
| `submission/written-submission/deviation-log.json` | Structured deviation entries the runbook + Q&A pack consume. |
| `submission/written-submission/format-validation-report.txt` | Page count, font, margin, point size validation results. |

## Procedure

1. **Validate inputs.** Reject if:
   - The prototype manifest lists fewer than 7 deployed services (we
     committed S1, S2, S3, S5, S6, S8, S9, S11 in build plan §1.2).
   - The prototype manifest references BASE-C or Bedrock anywhere (these
     are silence-not-commitments per phase2-commitments.md §H.7; their
     absence is enforced upstream — fail loud here as a defense in depth).
   - `format.body_font` is not in the allowed list (TNR / Aptos / Arial /
     Calibri per P3-R57).
   - `format.max_pages` ≠ 10.
   - `phase2_source.primary` is not readable.

2. **Build the capability-map table** (`capability-map.csv`). One row per
   prototype capability. Columns:
   - `capability_id` — assign sequentially (CAP-01, CAP-02, ...).
   - `capability_name` — human-readable label.
   - `phase3_evidence` — pointer into the prototype manifest (service +
     route + source path).
   - `p2_anchor_section` — section in phase2-commitments.md (e.g.,
     "B.2 S2 Guided Intake", "F.1 row duplicate-FTN→0").
   - `p2_anchor_quote` — the exact one-line commitment from Phase 2.
   - `p2_disposition_row` — SF1 Table 4 row (M1–M19) if applicable.
   - `j08_stages` — list of J08 stages this capability serves.
   - `roles` — list of roles that exercise it.
   - `deviation_flag` — `none` | `<deviation_id>` if this capability
     deviates.

   Target row count: 30–50 capabilities. Fewer than 30 misses scope;
   more than 50 dilutes evidence.

   Reject if any capability has `p2_anchor_section = NEW-IN-PHASE-3`
   AND `deviation_flag = none` simultaneously — that's a silent
   deviation, blocked by P3-R67.

3. **Build the deviation log** (`deviation-log.json`). One entry per
   deviation. Schema:
   ```json
   {
     "deviation_id": "DEV-1",
     "phase2_commitment": "AWS GovCloud as primary hosting (§B.3)",
     "phase3_implementation": "docker-compose locally for the 75-min oral",
     "deviation": "Local docker stack instead of GovCloud deployment",
     "reason": "75-min oral cannot tolerate a GovCloud-network dependency; Tyrion ATT not granted in 12-day window",
     "risk_if_unflagged": "P3-R5.2 automated code analysis would find no GovCloud CDK deployed, contradicting any oral GovCloud claim",
     "phase4_remediation": "AWS CDK GovCloud stack set ships with the prototype under infra/cdk/, synth-green; runs when AWS credentials are provided"
   }
   ```

   Required entries (per build plan §1.1, the canonical six):
   - **DEV-1**: docker-compose vs AWS GovCloud.
   - **DEV-2**: local stack vs Tyrion / Horizon FedRAMP landing zone.
   - **DEV-3**: OpenSSL CA + freetsa.org RFC 3161 vs AWS Private CA + ACM.
   - **DEV-4**: Keycloak (Login.gov-compatible) vs live Login.gov.
   - **DEV-5**: Postgres LISTEN/NOTIFY vs Step Functions / EventBridge.
   - **DEV-6**: BASE-C and Bedrock are NOT used; both are excluded as
     silence-not-commitments per phase2-commitments.md §H.7. This entry is
     mandatory: stating "we did not use BASE-C/Bedrock" pre-empts the
     evaluator interpreting absence as either silent adoption or silent
     omission.

   Optional entries from gap matrix §5 (DEV-7..DEV-19) — include those
   the prototype actually exercises (e.g., DEV-9 J08 stage subset is
   real for any Phase 3 implementation; DEV-13 RFC 3161 is real if
   freetsa.org is used).

4. **Author the narrative section by section.** Use this fixed page
   allocation, total exactly 10 pages.

   | § | Section | Pages | P3-R closed |
   |---|---|---|---|
   | 1 | Executive summary | 0.5 | R62, R63 (preamble) |
   | 2 | Phase 2 → Phase 3 capability map | 2.0 | R62, R63, R64, R66 |
   | 3 | Implemented workflow consolidations | 1.0 | R64 |
   | 4 | Eliminated duplicate-entry points | 1.0 | R65, R23a |
   | 5 | Service decomposition decisions | 1.0 | R66 |
   | 6 | Implementation deviations | 1.5 | R67 |
   | 7 | Tradeoffs, deferrals, modified assumptions | 1.0 | R68, R69, R70 |
   | 8 | Scalability, operational readiness, enterprise reuse | 1.0 | R71, R72, R73 |
   | 9 | Tactical path to production + risk register + SOO alignment | 1.0 | R46–R50, R116, R118 |
   | **Total** | | **10.0** | |

   §1 — **Executive summary** (½ page). Five sentences:
     1. What the prototype is (a working PPC certification system —
        applicant + AME + CFI + DPE flows; 8 of 11 target services
        deployed; full DevSecOps pipeline emitting OSCAL evidence).
     2. What Phase 2 commitments it traces to (the 11 target services,
        the 22-stage J08, the 5 waves, the 10 NIST control families).
     3. What it explicitly does not do (Aircraft Registration; the 22-22
        stage J08; live Login.gov federation; AWS Private CA in production).
     4. Where it deviates (six named deviations, all in §6).
     5. Where it is portable to in Phase 4 (GovCloud, Tyrion, Login.gov
        sandbox, AWS Private CA — paths documented).

   §2 — **Capability map** (2 pages). A table rendered from
     `capability-map.csv`, plus an introductory paragraph naming the
     traceability convention. Format the table at 8 pt to fit
     35-line rows; if more than 50 capabilities, cut to the highest-
     evidence rows. Cite SF1 Table 4 row IDs (M1–M19) explicitly.

   §3 — **Workflow consolidations** (1 page). Show the 17→8 stage
     reduction (SF1 §6 / J08 §D mapping). One paragraph per consolidation
     with the cite. Examples to include:
     - F3: Paper Form 8710 fallback eliminated (S2 + S5).
     - F7: Cross-system case reconstruction by phoning FSDOs eliminated
       (S5 Shared Case).
     - F8: Nightly SSIS designee mirror eliminated (S7 real-time API).
     - F9: AMC-700 paper-letter re-keying eliminated (S10 §61.15
       online — note: S10 stubbed in Phase 3, but the workflow consolidation
       is real for Wave 1).
     - 6 cross-system handoffs → 0 (S5 + S8).

   §4 — **Eliminated duplicate-entry points** (1 page). The headline
     P3-R23a / P3-R65 evidence. Use the per-form ledger from the
     `duplicate-entry-eliminator-verifier` skill (or its manual
     equivalent if not run). Show before/after for at least 3 forms:
     - Form 8710 cert application: 0 fields → reused from S8.
     - Form 8500-8 medical: 17 fields → reused from S8.
     - US Agent designation: 0 fields → reused from S1.
     - Address change: 1 field → reused from S8 with §61.60 30-day
       compliance auto-tracking.

     Quote the J08 §3 commitment: "17 fields pre-filled from profile."
     Cite Phase 2 §F.1 "duplicate-FTN→0" and §F.1 row "Form8500 dedup."

   §5 — **Service decomposition decisions** (1 page). Eight deployed
     services + three stubbed (S4, S10, parts of S6/S7). For each
     deployed service, give the one-paragraph rationale:
     - **What boundary did we draw?**
     - **Why?** (cite SF1 Table 5 row + SF3 §1.1 Table 2).
     - **What internal types stay private vs which canonical entities
       cross the boundary?** (cite §B.4 8 canonical entities).

     Include the table from build plan §1.2 (S1–S11 disposition in
     Phase 3) at 8 pt.

   §6 — **Implementation deviations** (1.5 pages). The six canonical
     deviations from `deviation-log.json`. For each:
     - One-paragraph statement.
     - Why deviated.
     - Phase 4 remediation path.
     Order: cloud / Tyrion / PKI / Login.gov / event bus / BASE-C-Bedrock.
     The BASE-C-Bedrock paragraph reads: "Phase 2 sources commit to AWS
     GovCloud + Azure Government portable + FAA Tyrion / Horizon. BASE-C
     and Amazon Bedrock are not named in any Phase 2 source (verified
     against the eight A6 files, the journey HTMLs, and SF1/SF3/Factor 2
     deliverables; see phase2-commitments.md §H.7). Our Phase 3
     prototype does not depend on either. We make this explicit because
     silence in Phase 2 sources should not be construed as either
     adoption or rejection of these tools — only that Phase 3 was built
     against the cited Phase 2 commitments. If FAA Phase 4 direction
     selects BASE-C as the Kubernetes substrate, our container-native
     architecture (Helm chart in `infra/helm/`) is portable."

   §7 — **Tradeoffs, deferrals, modified assumptions** (1 page).
     - **Tradeoffs**: name 3–5 explicit choices with their costs.
       Example: "We chose Node 20 + Express + TypeScript over Spring Boot
       for prototype velocity and for clean Lambda portability via
       `@vendia/serverless-express` per `docs/phase3/local-first-architecture.md` §5;
       production Wave 1 may swap individual services to Spring Boot for
       the Java-team operational profile per Phase 2 §A.6 RMS A6 §6 Y1."
     - **Deferrals**: name 5–8 capabilities deferred to Wave 2+.
       Example: "AADOCS+CAIS merge (Wave 2 per Phase 2 §C.1)" /
       "ADABAS retirement (Wave 4)" / "MSS three-medical-UIs collapse
       (Wave 3 per Phase 2 §C.1)" / "Stages 13–22 of J08 (sustainment +
       lifecycle events)."
     - **Modified assumptions**: name 2–4 Phase 2 §C.3 assumptions the
       Phase 3 prototype suggests revisiting. Example: "A1 PPC scope —
       we confirm IACRA + RMS + MSS + DMS is implementable in
       12 days at prototype scope; Aircraft Registration remains
       out-of-scope as committed."

   §8 — **Scalability, operational readiness, enterprise reuse** (1 page).
     Three paragraphs:
     - **Scalability**: Phase 2 §G.3 commits to "Olympus re-runs against
       ~200 apps and ~3,000 databases." The factory model demonstrated
       in the oral is the same factory; per-app config under
       `profiles/`. The prototype's architecture (ephemeral immutable
       compute per §B.3, Postgres canonical store, OpenAPI 3.1
       contracts, OPA policy bundles per §B.5) scales horizontally
       through container replication.
     - **Operational readiness**: OTEL traces published to Loki +
       Prometheus + Grafana; cATO Grafana panel shows live AU-12 audit
       presence and SI-4 anomaly rate; runbooks committed under
       `docs/runbooks/` for each service; on-call rotation mapped to
       service-ownership in `OWNERS.md`. Citing §B.5 "continuous
       monitoring, anomaly detection, control telemetry."
     - **Enterprise reuse**: ~110 cross-cutting skills committed under
       `cross-cutting/skills/`. Each is a versioned, composable unit
       with declared inputs/outputs. The 11-target-service decomposition
       reuses across the ATLAS portfolio per §G.3 (Wave 4 promotion
       gate). USWDS visual layer per §B.3 normalizes UX across the
       portfolio.

   §9 — **Tactical path + risks + SOO alignment** (1 page). Four
     paragraphs:
     - **Tactical path** (P3-R46–R49): six-month rollout. Wave 0:
       Tyrion landing zone (3 weeks). Wave 0 closing: Login.gov sandbox
       approval. Wave 1: first end-to-end PPC application live in pilot
       (next 8 weeks). Wave 1 closing: duplicate-FTN-rate verified zero
       in production telemetry. Wave 2: managed-PKI-signed 8710 in
       production (next 12 weeks).
     - **Risks** (P3-R47): three named risks with L·I — R1 IACRA cutover
       (M·H, mitigated by feature flags + parallel reads), R2 RMS
       ADABAS migration drift (M·H, mitigated by row-level checksum +
       delta reports per Phase 2 §C.4), R5 conversational AI low-confidence
       (M·H, mitigated by D5 routing under 95% confidence to human, never
       autonomous).
     - **AMS alignment** (P3-R116): cite FAA Order 1370.121 (P3-R118)
       and AMS standards. Reference `cato-compliance` skill output for
       the full mapping.
     - **NIST 800-53 alignment** (P3-R117): list the 10 named families
       and pointer to `evidence/oscal/by-control/`.

5. **Render the markdown to .docx.** Invoke the existing `docx` skill
   with the markdown file and the format constraints. Validate the
   output:
   - Page count ≤ 10 (P3-R54).
   - Page size 8.5 × 11 (P3-R55).
   - Margins 1" all sides (P3-R56).
   - Body font in {Times New Roman, Aptos, Arial, Calibri} (P3-R57).
   - Body size ≥ 12 pt (P3-R58).
   - Tables/figures ≥ 8 pt (P3-R59).
   - Header/footer ≥ 10 pt (P3-R60).
   - Searchable text (no scanned images of text) (P3-R61).
   If any check fails, the orchestrator must trim content. The skill
   does NOT silently truncate.

6. **Render the PDF.** Use the `docx` skill's PDF export. Verify text
   is selectable (open the PDF, select-all, paste — must round-trip).

7. **Emit the format validation report** at
   `submission/written-submission/format-validation-report.txt`. List
   each P3-R54..R61 check with PASS/FAIL and the measured value.

## Validation / acceptance criteria

- [ ] Page count = 10 (or ≤ 10 if final pass-trim runs short; never > 10).
- [ ] Capability-map table has 30–50 rows; every row has a `p2_anchor_section`
      and `p2_anchor_quote`.
- [ ] Deviation log has the 6 canonical deviations (DEV-1..DEV-6); each has
      `phase2_commitment`, `phase3_implementation`, `reason`, and
      `phase4_remediation`.
- [ ] BASE-C and Bedrock appear ONLY in §6 (the BASE-C-Bedrock deviation
      paragraph). No mention in §1, §2, §3, §4, §5, §7, §8, §9.
- [ ] Every prototype capability listed in §2 cites a Phase 2 section by
      ID (e.g., "B.2 S2", "F.1 row Form8500 dedup", "SF1 Table 4 M9").
      Capabilities tagged `NEW-IN-PHASE-3` must also have a deviation
      entry in §6.
- [ ] Every NIST family in `oscal.control_families` (AC-2, AC-3, AC-4,
      IA-5, AU-2, AU-10, AU-12, SC-12, SC-28, SI-10) is cited in §9
      P3-R117 paragraph.
- [ ] §6 covers all 6 canonical deviations; section length is between 1.4
      and 1.6 pages.
- [ ] §4 (duplicate-entry-elimination) names at least 3 forms with
      before/after counts.
- [ ] §9 risk register has at least 3 named risks with L·I framing.
- [ ] Format-validation-report.txt has all 8 P3-R54..R61 checks at PASS.
- [ ] Rendered .docx and .pdf exist and the PDF is searchable.
- [ ] No emoji, no Unicode bullet that doesn't render in Calibri 12pt
      across Word and macOS Preview.

## Examples

### Example 1: capability map table excerpt

| ID | Capability | Phase 3 evidence | P2 anchor | M-row | J08 stage | Roles | Deviation |
|---|---|---|---|---|---|---|---|
| CAP-01 | One-FTN-per-airman single-write authority | services/s8/router.py:post_ftn_resolve | F.1 row "duplicate-FTN→0" | M3 | 2 | applicant | none |
| CAP-02 | Form 8500-8 prefill, 17 fields | services/s2/intake.py:get_prefill | F.1 row "Form8500 dedup", D.1 stage 3 | M9 | 3 | applicant | none |
| CAP-03 | AME exam shared case (no import step) | services/s5/case.py:get_for_role + web/applicant/AMEConsole.tsx | B.1 Layer 2, D.1 stage 5 | M10, M11 | 5 | ame, applicant | none |
| CAP-04 | PHI boundary enforcement at gateway | iac/opa/medical-boundary.rego, services/s6/router.py | B.4 medical.cert-status, F.3 F4 | M10, M12 | 5, 6, 19 | ame, faa_cami | none |
| CAP-05 | CFI digital endorsement, RFC 3161 | services/s9/sign.py + iac/openssl-ca/ | B.3 RFC 3161 TSA, D.1 stage 9 | (S9 row) | 9 | cfi | DEV-3 (freetsa vs Private CA) |
| CAP-06 | DPE issuance — full event chain to Reporting | services/s5→s8→s9→s3→s11 | B.3 event bus, D.1 stage 12 | M2, M5 | 12 | dpe, applicant | DEV-5 (LISTEN/NOTIFY vs EventBridge) |
| ... | (30–50 rows total) | | | | | | |

### Example 2: deviation §6 paragraph (DEV-1)

> **DEV-1: Hosting — docker-compose locally instead of AWS GovCloud.**
> Phase 2 §B.3 commits AWS GovCloud as the primary hosting target with
> Azure Government as a portability fallback (SF1 §2 ¶3, §5 Wave 0).
> The Phase 3 prototype runs in `docker-compose` on the team's laptop
> for the 75-minute oral. We chose this path because the oral cannot
> tolerate a GovCloud-network dependency we do not control inside the
> Zoom.gov screen-share window. The AWS CDK v2 (TypeScript) stack set
> under `infra/cdk/` is checked in and synth-green; it
> deploys when AWS GovCloud credentials and Tyrion landing-zone
> authority are provisioned in Wave 0 (Phase 2 §C.2 gating event "FAA
> Authority-to-Test granted"). Per `docs/phase3/local-first-architecture.md` §4,
> handler and domain code never imports `@aws-sdk/*` directly — adapters
> mediate every cloud dependency, so the deviation is the substrate, not
> the architecture.

### Example 3: §1 executive summary (½ page)

> The Phase 3 prototype implements the Private Pilot Certification
> workflow described in Booz Allen ATLAS Phase 2 SF1 §1 and SF3 §1.1
> against the 22-stage target user journey from Phase 2 §D.1. It
> deploys eight of the eleven target services committed in §B.2 — S1
> Identity, S2 Guided Intake, S3 Notification, S5 Shared Case, S6
> Medical Readiness, S8 Registry Canonical API, S9 Digital Credential,
> S11 Reporting & Analytics — with three stubs (S4 Conversational AI
> per §B.5 "no AI/ML feature is in-scope," S7 Designee partial, S10
> Compliance partial). All eight deployed services run behind a Traefik
> edge gateway with mTLS and OPA policy-as-code (Phase 2 §B.5);
> compliance evidence is generated per build via the
> `compliance-trestle` toolchain against the ten named NIST 800-53
> control families (Phase 2 §B.5: AC-2, AC-3, AC-4, IA-5, AU-2,
> AU-10, AU-12, SC-12, SC-28, SI-10). The prototype runs locally in
> `docker-compose`; the AWS CDK GovCloud stack set under `infra/cdk/`
> is checked in and synth-green for Phase 4 promotion. Six
> implementation deviations are named in §6 with reasons and Phase 4
> remediation paths. Aircraft Registration remains out of scope per
> Phase 2 §C.3 A1.

## Gotchas

- **Page count is the wall, not the goal.** Going to exactly 10 with
  jam-packed text is worse than landing at 9.5. Reviewers fatigue at
  8 pt tables; the body is 12 pt for a reason. If trimming is required,
  cut from §3 (consolidations) and §8 (reuse) before §6 (deviations) or
  §2 (capability map).
- **Capability map is THE evidence row.** Every claim in the oral runbook
  should appear as a row. If the runbook claims "we eliminate duplicate
  FTN minting" but the capability map has no row for that, the oral and
  written submission contradict each other (a P3-R5.2 risk). Run the
  cross-consistency check between this skill's capability-map.csv and
  the runbook's expected-state-checkpoints.
- **BASE-C / Bedrock paragraph is non-negotiable.** Skipping it means
  the FAA evaluator may infer one of two things: silent adoption (P3-R67
  failure) or silent omission (perceived as incompetence). Naming the
  absence is what blocks both inferences.
- **NEW-IN-PHASE-3 capabilities require deviation entries.** A capability
  that does not trace to Phase 2 is by definition a deviation. Examples:
  using Anthropic SDK / Claude Code subagents for the build (DEV-17 in
  gap matrix §5), using local OpenSSL CA (DEV-13). If the team uses
  these, list them.
- **Don't write headlines that the prototype can't back.** "We have
  achieved Zero Trust" is unverifiable; "We enforce mTLS between
  services and OPA per-request authorization at the edge gateway" is
  testable and audit-friendly. The narrative is read alongside the code;
  every claim must be locally falsifiable.
- **Format compliance trumps prose quality.** A beautifully-written
  narrative at 11 pages or in 11 pt body fails P3-R54 / P3-R58 — and
  failing format compliance auto-downgrades the SF2 rating regardless
  of substance. Validate format BEFORE the final review pass.
- **Cite by section ID, not by page number.** Phase 2 sources may
  re-paginate; section IDs (B.2, F.1, M3, J08 §3) are stable.
- **The narrative is final at Day 11 freeze.** Day 12 is HDD prep, not
  rewrites. Plan ≥ 2 internal review cycles before Day 11; reserve a
  sub-30-minute trim pass for Day 11 morning.

## References

- Closes Phase 3 requirements: P3-R54, R55, R56, R57, R58, R59, R60, R61
  (format); P3-R62, R63 (capability map); P3-R64 (consolidations);
  P3-R65 (duplicate-entry elimination); P3-R66 (service decomposition);
  P3-R67 (deviations); P3-R68 (tradeoffs); P3-R69 (deferrals); P3-R70
  (modified assumptions); P3-R71 (scalability); P3-R72 (operational
  readiness); P3-R73 (enterprise reuse); P3-R116 (AMS alignment);
  P3-R117 (NIST 800-53); P3-R118 (FAA Order 1370.121).
- Phase 2 grounding:
  - All sections in `phase2-commitments.md` per the input list.
  - Particularly: §H.7 — BASE-C / Bedrock not named (mandates §6 paragraph).
- Build plan: `docs/phase3/build-demo-skills-plan.md` §4 D2 (this skill);
  §6 Day 9 (drop-in date); §1.1 (the 6 canonical deviations).
- Gap matrix: `docs/phase3/skills-gap-matrix.md` §4 NEW-4; §5
  (deviation register source).
- Adjacent skills:
  - `docx` (Anthropic skill) — used as rendering backend.
  - `traceability-checker` — validates citations are well-formed.
  - `architecture-traceability-validator` — validates the capability
    map against the deployed architecture.
  - `demo-runbook-generator` — cross-consistency target; runbook claims
    must appear in this narrative's capability map.
  - `submission-package-builder` — packages the .docx + .pdf into the
    "Written Submission" HDD folder.
  - `cato-compliance` (EDIT-1) — emits the OSCAL fragments cited in §9.

## Anti-patterns

- **Do not** generate a 12-page narrative and trust the orchestrator
  will trim. Format compliance is binary.
- **Do not** restate Phase 2 commitments without naming the Phase 3
  evidence. The narrative is a traceability document, not a Phase 2
  recap.
- **Do not** include screenshots as evidence. Word's PDF export
  dithers screenshots and they fail the searchable-text check.
  Reference the artifact path instead (e.g., "see
  `evidence/dast/zap-baseline-latest.html`").
- **Do not** silently omit deviations. If the team adopts BASE-C
  during Phase 3 (against the build plan), name it as DEV-7+ — silent
  adoption is the worst possible outcome.
- **Do not** use marketing language. "Industry-leading observability"
  fails the P3-R5.2 cross-consistency check (the FAA evaluator's
  automated analysis cannot verify "industry-leading"). Specific,
  measurable claims only.
- **Do not** leave the §6 BASE-C-Bedrock paragraph as a TODO. It is
  the highest-leverage paragraph in the entire document; missing it
  is the most common path to a P3-R67 failure.
