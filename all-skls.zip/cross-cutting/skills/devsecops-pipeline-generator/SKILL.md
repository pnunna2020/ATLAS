---
name: devsecops-pipeline-generator
description: >
  Emit production-quality GitHub Actions workflow YAML for the FAA ATLAS Phase 3
  prototype: lint, build, unit/integration test, SBOM (Syft), SCA (Grype), SAST
  (Semgrep), container scan (Trivy), DAST (OWASP ZAP baseline), IaC scan
  (tfsec/Checkov), policy gate (OPA/Conftest), ephemeral preview deploy, e2e
  smoke, OSCAL fragment generation (compliance-trestle), and evidence
  publication. Use during Phase 3 build day 3 to wire CI for every service.
  Triggers on devsecops, GitHub Actions, CI/CD, pipeline YAML, security
  scanning, SBOM, SAST, DAST, OSCAL evidence, or compliance gate mentions.
agent: sonnet
enrichment_level: Full
tags:
  - devsecops-pipeline
  - cato-compliance
  - evidence-generation
  - codegen-iac
allowed-tools:
  - Read
  - Write
  - Bash
  - Grep
---

# DevSecOps Pipeline Generator

## Purpose
Emit the actual `.github/workflows/*.yml` files that drive the Phase 3
prototype's CI/CD substrate. This skill is **not** a design-time advisor — it
writes runnable workflow YAML and the supporting reusable workflow library,
branch-protection ruleset, and required-secrets list. Every stage is wired so
that the FAA evaluator can re-run the entire pipeline from the submitted code
without contacting Booz Allen (P3-R88).

The output of this skill is the single highest-volume source of evaluator-
visible artifacts in Phase 3: pipeline run logs, scan reports, SBOMs, OSCAL
fragments, and deploy provenance all flow from the workflows it emits.

## When to use

Invoke this skill on Phase 3 build day 3 (per `docs/phase3/build-demo-skills-plan.md` §6),
**after** the IaC scaffold (`aws-deployment-topology --emit-cdk` and `--emit-compose` per
`docs/phase3/local-first-architecture.md` §2) and service skeletons exist, and **before**
any service tries to push code that would otherwise hit an empty CI. Re-invoke whenever:

- A new service is added to the repo and needs a build matrix entry.
- A new scanner is mandated mid-Phase 3 (FAA real-world-conditions injection,
  P3-R5.1) and must be spliced into the security workflow.
- A new NIST control family must be bound to the OSCAL emit stage.

Do **not** invoke this skill for Jenkins or GitLab CI — Phase 3 is GitHub
Actions only per the build plan §1.1. Cross-CI portability is a Phase 4
concern.

## Inputs

The skill expects a JSON or YAML build manifest with these fields. Treat any
missing field as a hard error — fail loud, never guess.

```yaml
project:
  repo_root: faa-atlas-phase3-prototype
  default_branch: main
languages:
  - typescript: { runtime: "node-20", package_manager: "npm", test_runner: "vitest" }
services:                       # one entry per deployable service
  - name: s8-registry-canonical
    path: apps/api                      # see local-first-architecture.md §3
    language: typescript
    container: true
    dockerfile: apps/api/Dockerfile
    expose_port: 8080
    healthcheck: /healthz
    lambda_handler: apps/api/src/http/lambda-handler.handler   # AWS entry
  - name: web-applicant
    path: apps/web
    language: typescript
    container: true
    dockerfile: apps/web/Dockerfile
iac:
  cdk_root: infra/cdk                   # AWS CDK v2 (TypeScript) — see local-first-architecture.md §2
  helm_chart_root: infra/helm           # Phase 4 stub only
  compose_file: infra/docker-compose.yml
target:
  cloud: aws
  region: us-gov-west-1            # or "local-docker-compose" for the demo
  k8s: false                       # Phase 3 demo runs docker-compose; k8s manifests still lint
oscal:
  catalog: nist-800-53-rev5
  control_families:                # the 10 named families per Phase 2 §B.5
    - AC-2
    - AC-3
    - AC-4
    - IA-5
    - AU-2
    - AU-10
    - AU-12
    - SC-12
    - SC-28
    - SI-10
secrets_required:
  - DOCKERHUB_TOKEN
  - AWS_ROLE_ARN
  - SEMGREP_APP_TOKEN              # optional; falls back to OSS rules
  - ZAP_AUTH_HEADER                # optional; for authenticated DAST
```

## Outputs

The skill writes files into the consumer repo and emits a single index file
the orchestrator can read.

| Path | Purpose |
|------|---------|
| `.github/workflows/build.yml` | Lint, unit test, integration test, container build, SBOM emit, image push to GHCR. |
| `.github/workflows/security.yml` | Semgrep SAST, Grype SCA, Trivy (image + IaC), tfsec, Checkov, OPA/Conftest, OWASP ZAP baseline. |
| `.github/workflows/deploy.yml` | `cdk synth` + `cdk diff` + `cdk deploy` against ephemeral preview env, smoke test, optional blue-green promote. |
| `.github/workflows/cato-evidence.yml` | Run compliance-trestle, emit per-control OSCAL fragments, archive SSP/SAR/POA&M deltas to `evidence/oscal/`. |
| `.github/workflows/_reusable-build.yml` | Reusable workflow consumed by `build.yml` per service. |
| `.github/workflows/_reusable-scan.yml` | Reusable workflow consumed by `security.yml`. |
| `.github/workflows/_reusable-deploy.yml` | Reusable workflow consumed by `deploy.yml`. |
| `.github/branch-protection.yml` | Ruleset for `main`: require PR review, require all 4 workflows passing, require signed commits, require linear history. |
| `docs/devsecops/REQUIRED_SECRETS.md` | Documentation block listing every secret the pipelines consume + how to set it (no actual values). |
| `docs/devsecops/README.md` | Per-stage explanation aimed at the FAA evaluator. |
| `evidence/pipeline-run-schema.json` | JSON Schema for the run-summary artifact each pipeline produces; consumed downstream by `demo-runbook-generator` and `submission-package-builder`. |

## Procedure

1. **Validate the build manifest.** Reject if any service lacks a Dockerfile
   path, if `oscal.control_families` does not contain all 10 named families,
   or if `secrets_required` omits `AWS_ROLE_ARN` (the deploy stage cannot run
   without it). Validation failures are fatal — do not emit partial pipelines.

2. **Generate `_reusable-build.yml`.** A single reusable workflow, parameterized
   by `service-name`, `service-path`, `language`, `dockerfile`. Stages, in order:
   1. `actions/checkout@v4` with `fetch-depth: 0`.
   2. Language setup (`actions/setup-python@v5` or `actions/setup-node@v4`).
   3. Cache dependencies keyed on the manifest file hash.
   4. Install dependencies — fail on lockfile drift (`pip install --require-hashes`
      or `npm ci`).
   5. Lint (`ruff check` for Python, `eslint` for TypeScript) — fail on any error.
   6. Unit tests with coverage (`pytest --cov=. --cov-fail-under=70` for Python;
      `vitest run --coverage` for TypeScript).
   7. Build container image with `docker/build-push-action@v5`, tagged
      `ghcr.io/<org>/<service>:${{ github.sha }}`.
   8. Generate SBOM with `anchore/sbom-action@v0` (Syft) — emit SPDX JSON to
      `evidence/sbom/<service>-${{ github.sha }}.spdx.json`.
   9. Upload SBOM as a workflow artifact AND commit to `evidence/sbom/` on
      pushes to `main`.

3. **Generate `_reusable-scan.yml`.** Stages, run in parallel where possible:
   1. **Semgrep SAST** — `returntocorp/semgrep-action@v1` with `p/owasp-top-ten`,
      `p/cwe-top-25`, and `p/python` or `p/typescript` rule packs. Output SARIF
      to `evidence/sast/semgrep-${{ github.sha }}.sarif`. Fail on `ERROR`-severity
      findings; warn on `WARNING`.
   2. **Grype SCA** — `anchore/scan-action@v3` reading the SBOM emitted in
      build. Fail on `critical` or `high` CVEs unless an explicit POA&M item
      exists in `evidence/poam/exceptions.yml`.
   3. **Trivy (container image)** — `aquasecurity/trivy-action@master` against
      the GHCR image. SARIF output to `evidence/container-scan/`.
   4. **Trivy (IaC)** — same action with `scan-type: config` against the
      synthesised CloudFormation under `infra/cdk/cdk.out/` (produced by
      `cdk synth`) and `infra/helm/`. SARIF output to `evidence/iac-scan/`.
   5. **cdk-nag** — run `npx cdk synth --aspects "AwsSolutionsChecks"` against
      `infra/cdk/`. Treat any `AwsSolutions-*` rule violation as a fail.
   6. **Checkov** — `bridgecrewio/checkov-action@master` with `framework: cloudformation`
      against `infra/cdk/cdk.out/` and `framework: helm` against `infra/helm/`.
   7. **OPA / Conftest** — `instrumenta/conftest-action@master` evaluating
      policy bundles in `policy/conftest/` against the Helm chart and the
      synthesised CloudFormation JSON from `cdk synth`. Fail on any deny.
   8. **OWASP ZAP baseline** — `zaproxy/action-baseline@v0.10.0` against the
      ephemeral preview URL emitted by the deploy workflow. Run only after
      deploy completes; otherwise skip with `if: needs.deploy.result == 'success'`.

4. **Generate `_reusable-deploy.yml`.** Stages:
   1. Configure AWS credentials via `aws-actions/configure-aws-credentials@v4`
      using OIDC (no static keys). Assume `AWS_ROLE_ARN`.
   2. `cd infra/cdk && npm ci && npx cdk synth && npx cdk diff > diff.txt`.
      Upload `cdk.out/` and `diff.txt` as artifacts.
   3. Run **policy gate** against `cdk.out/*.template.json` (re-uses Conftest
      from scan stage, evaluating `policy/conftest/iac/`). Fail closed.
   4. `npx cdk deploy --require-approval never --outputs-file outputs.json`.
      On deploy failure, run `npx cdk destroy --force` against the ephemeral
      stack(s) and bubble the error.
   5. Copy `outputs.json` to `evidence/iac-apply/<run-id>-outputs.json`.
   6. Smoke test: poll the deployed `/healthz` endpoint of every service
      named in the manifest. Fail after 30 attempts at 5s intervals.
   7. e2e smoke: invoke `npx playwright test --project=smoke` against the
      preview URL. Upload Playwright trace zip + screenshots on failure.
   8. On success, post a PR comment with the preview URL, the commit SHA, the
      pipeline run URL, and a summary of pass/fail per service.

5. **Generate `_reusable-cato.yml`.** Stages:
   1. `pip install compliance-trestle`.
   2. Run `trestle init` against `evidence/oscal/` if the workspace is fresh.
   3. For each control family in `oscal.control_families`, invoke
      `scripts/emit_control_evidence.py <family>` (a script committed to the
      consumer repo by the `cato-compliance` skill, NOT this skill). Each
      script emits an OSCAL fragment to
      `evidence/oscal/by-control/<family>.json` with `prop` entries for the
      build SHA, the deployed image digest, and the smoke-test run ID.
   4. Run `trestle assemble -t ssp` to merge fragments into a build-scoped SSP.
   5. Run `trestle validate` — fail on any schema error.
   6. Archive `evidence/oscal/` as a workflow artifact AND commit on `main`.
   7. Emit a `evidence/pipeline-run-summary.json` matching the schema written
      to `evidence/pipeline-run-schema.json` (see Outputs).

6. **Generate the four top-level workflows.** Each is a thin wrapper that
   `uses:` the matching reusable workflow with a matrix over `services`:

   - `build.yml` triggers on `pull_request` and `push: main`.
   - `security.yml` triggers on the same events plus `schedule: cron 0 6 * * *`
     (daily SCA refresh per AU-12).
   - `deploy.yml` triggers only on `push: main` with concurrency group
     `deploy-${{ github.ref }}` and `cancel-in-progress: false` to prevent
     rollback races.
   - `cato-evidence.yml` triggers on `workflow_run: deploy.yml completed`
     so OSCAL fragments always reference the actual running prototype
     (closes P3-R45).

7. **Generate `branch-protection.yml`.** Encode as a GitHub Repository Rules
   API document with: required PR reviewers ≥ 1, required status checks =
   the four top-level workflows, required signed commits, required linear
   history, dismiss stale reviews on push, restrict force-pushes.

8. **Generate `REQUIRED_SECRETS.md`.** One row per secret in
   `secrets_required` plus any optional secrets the workflows reference.
   Document where each is read in the YAML (line reference) and how to
   provision (GitHub Environments for `AWS_ROLE_ARN`, repo secrets for
   tokens). Never commit secret values.

9. **Generate `docs/devsecops/README.md`.** This is the file the FAA
   evaluator reads to understand the pipeline at a glance. Include:
   - The pipeline graph (Mermaid) showing build → security → deploy → cato.
   - One-paragraph description per stage, naming the tool and the artifact
     it produces.
   - The exact path under `evidence/` where each artifact lands.
   - The mapping from each pipeline stage to the P3-R requirements it
     closes (R03–R10, R37, R89–R92).

10. **Emit the run-summary schema.** `evidence/pipeline-run-schema.json` is
    JSON Schema 2020-12 with required fields: `run_id`, `commit_sha`,
    `started_at`, `finished_at`, `services` (array of `{name, image_digest,
    sbom_path, sast_findings, sca_findings, container_findings,
    iac_findings, deploy_status, smoke_status}`), `oscal_artifacts`
    (array of `{control_family, fragment_path, status: pass|fail|warn}`).
    The `demo-runbook-generator` and `submission-package-builder` skills
    consume this schema; do not change it without notifying both.

## Validation / acceptance criteria

- [ ] All four top-level workflows pass `actionlint` and parse with `yq`.
- [ ] `branch-protection.yml` round-trips through the GitHub Rules API
      `--dry-run` without error.
- [ ] Every secret named in any workflow appears in `REQUIRED_SECRETS.md`
      and in the manifest's `secrets_required` (or is documented as
      optional with a working fallback path).
- [ ] The OSCAL emit stage produces a fragment per family in
      `oscal.control_families` and `trestle validate` exits 0.
- [ ] `docs/devsecops/README.md` cites every P3-R it closes (R03, R04,
      R05, R06, R10, R37, R89, R90, R91; underpins R13 and R94).
- [ ] No workflow uses a third-party action without a pinned SHA (not a
      tag) — Trivy and friends rotate; pin to commit.
- [ ] No stage shells out to `bash -c "$untrusted_input"` — all dynamic
      inputs go through `env:` or workflow inputs.
- [ ] Deploy workflow uses OIDC for AWS auth — no `AWS_ACCESS_KEY_ID` /
      `AWS_SECRET_ACCESS_KEY` static credentials anywhere.
- [ ] Smoke and e2e stages fail the deploy workflow if either fails —
      no green-with-warnings.
- [ ] All artifacts written under `evidence/` are committed on pushes to
      `main` (so the HDD submission picks them up automatically) AND
      uploaded as workflow artifacts (so PR reviewers can grab them).
- [ ] `actions/checkout@v4` uses `persist-credentials: false` everywhere
      except the deploy workflow, which needs commit-back access for the
      evidence files.

## Examples

### Example 1: emit `build.yml` for a 2-service repo

Manifest:
```yaml
services:
  - { name: s8-registry-canonical, path: services/s8, language: python, container: true, dockerfile: services/s8/Dockerfile }
  - { name: web-applicant, path: web/applicant, language: typescript, container: true, dockerfile: web/applicant/Dockerfile }
```

Emitted `build.yml` (excerpt):
```yaml
name: build
on:
  pull_request:
  push:
    branches: [main]
permissions:
  contents: read
  packages: write
  id-token: write
jobs:
  matrix:
    strategy:
      fail-fast: false
      matrix:
        service:
          - { name: s8-registry-canonical, path: services/s8, language: python, dockerfile: services/s8/Dockerfile }
          - { name: web-applicant, path: web/applicant, language: typescript, dockerfile: web/applicant/Dockerfile }
    uses: ./.github/workflows/_reusable-build.yml
    with:
      service-name: ${{ matrix.service.name }}
      service-path: ${{ matrix.service.path }}
      language: ${{ matrix.service.language }}
      dockerfile: ${{ matrix.service.dockerfile }}
    secrets:
      DOCKERHUB_TOKEN: ${{ secrets.DOCKERHUB_TOKEN }}
```

### Example 2: emit a `policy/conftest/deny-public-s3.rego` reference

```rego
package main

deny[msg] {
  resource := input.resource_changes[_]
  resource.type == "aws_s3_bucket_public_access_block"
  resource.change.after.block_public_acls == false
  msg := sprintf("S3 bucket %v must block public ACLs (SC-28)", [resource.address])
}
```

The `_reusable-scan.yml` Conftest stage runs `conftest test plan.json --policy policy/conftest`
and fails closed.

## Gotchas

- **Pin third-party actions to SHAs**, not tags. `aquasecurity/trivy-action@master`
  is convenient but unpinned actions are a SLSA-3 violation and the FAA
  evaluator will flag it. Use `aquasecurity/trivy-action@<commit-sha>`.
- **OIDC, not access keys.** Phase 2 §B.5 commits to "no persistent OS to
  patch" and Zero Trust by structural enforcement. Static AWS keys in
  GitHub secrets contradict that posture; use `aws-actions/configure-aws-credentials@v4`
  with `role-to-assume`.
- **`packages: write` permission** is needed for GHCR push. Scope it to
  the build job only — don't grant it at the workflow level.
- **ZAP baseline** needs an authenticated header for any role-keyed
  surface (DPE / AME / FAA reviewer views). Pass via `cmd_options:
  '-z "-config replacer.full_list(0).description=auth -config
  replacer.full_list(0).matchstr=REGEX_REPLACE -config
  replacer.full_list(0).replacement=Bearer $ZAP_AUTH_HEADER"'`.
  Without auth, ZAP only scans the public landing page — useless for
  the role-based UI requirement (P3-R15).
- **OSCAL fragments must reference the running prototype.** If the
  cato-evidence workflow runs from a stale build (not the one just
  deployed), `cato-evidence-validator --phase3-acceptance` will fail.
  Always trigger cato-evidence on `workflow_run: deploy.yml` — never
  on `push`.
- **No mocks in the deploy path.** `adversarial-review` will flag stub
  responses reachable from production entry points. The smoke test
  must hit a real `/health` endpoint that depends on real DB
  connectivity, not a hardcoded `return 200`.
- **Branch protection is enforced by ruleset, not config.** The legacy
  `branch protection rules` API silently accepts but does not enforce
  required-checks for force-pushed commits. Use Repository Rules
  (`/repos/{owner}/{repo}/rulesets`) — that's what `branch-protection.yml`
  encodes.

## References

- Closes Phase 3 requirements: P3-R03, P3-R04, P3-R05, P3-R06, P3-R10,
  P3-R37, P3-R89, P3-R90, P3-R91. Underpins P3-R13 (cATO automation),
  P3-R88 (FAA can re-run independently), P3-R94 (compliance evidence
  emission).
- Phase 2 grounding:
  - SF3 §4.2 Table 4 — full DevSecOps stage list (commit / build / test /
    deploy / run scans).
  - §B.5 — "OSCAL-formatted control evidence per build ingested into FAA
    CSAM."
  - §B.5 — 10 NIST 800-53 control families AC-3, AC-2, AC-4, IA-5, AU-2,
    AU-10, AU-12, SC-12, SC-28, SI-10.
  - §B.3 — "ephemeral, immutable compute" forbids static AWS credentials
    in CI.
- Build plan: `docs/phase3/build-demo-skills-plan.md` §3 B6 (this skill);
  §6 Day 3 (drop-in date).
- Gap matrix: `docs/phase3/skills-gap-matrix.md` §4 NEW-1.
- Adjacent skills:
  - `cato-compliance` (EDIT-1) — emits the per-control evidence scripts
    this pipeline invokes.
  - `cato-evidence-validator` (EDIT-5) — runs in `cato-evidence.yml`'s
    final stage to assert per-family pass/fail.
  - `aws-deployment-topology` (EDIT-2) — emits the AWS CDK v2 stacks
    (`infra/cdk/`) and Helm charts the deploy stage applies.
  - `security-scan-review` (EDIT-7) — packages the SARIF outputs this
    pipeline produces into the SF2 evidence bundle.

## Anti-patterns

- **Do not** emit a single monolithic `ci.yml`. Use four files plus three
  reusable workflows. The FAA evaluator must be able to read a 200-line
  workflow per concern, not a 1,200-line god-file.
- **Do not** allow `continue-on-error: true` on any security or compliance
  stage. The pipeline IS the evidence; a yellow check looks fine on the
  GitHub UI but breaks the cATO automation claim.
- **Do not** generate a `Jenkinsfile` or `.gitlab-ci.yml` "as a fallback."
  Phase 3 is GitHub Actions only (build plan §1.1). A multi-CI fallback
  doubles the maintenance surface and dilutes the evidence trail.
- **Do not** invent new scan tools beyond the build-plan stack (Semgrep,
  Trivy, Grype, Syft, ZAP, tfsec, Checkov, Conftest). If a reviewer asks
  for Snyk, decline — the build plan §1.1 commits to OSS-only scanners
  for HDD reproducibility.
- **Do not** reference BASE-C or Bedrock in any workflow, comment, or
  README emitted by this skill. Neither is a Phase 2 commitment
  (phase2-commitments.md §H.7); referencing them here would manufacture a
  silent deviation and trigger P3-R67 / P3-R5.2 evaluator flags.
