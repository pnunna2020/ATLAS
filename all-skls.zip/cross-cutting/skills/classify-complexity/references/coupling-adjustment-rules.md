# Coupling Adjustment Rules

Raw counts frequently over- or understate decomposition difficulty. Apply after the first-pass threshold match, before emitting the tier. Every adjustment must cite a Pass 1 finding ID in `evidence.source_citations[]`.

## Downgrade signals (raw counts OVERSTATE)

- **Directories without modules.** High module count but Pass 1 shows one class / program holds >70% of LOC. Downgrade one tier.
- **God class dominance.** One class exceeds 30% of LOC with inbound fan-in > 20. Downgrade one tier.
- **Generated code inflates LOC.** >40% is generated (protobuf, OpenAPI clients, migrations). Subtract and re-apply.
- **Duplicated module copies.** Vendored multi-env forks inflate module count. Deduplicate first.
- **Dead / quarantined code.** Pass 1 marks `unreachable` / `legacy-archive`. Exclude from counts.

## Upgrade signals (raw counts UNDERSTATE)

- **Multi bounded contexts, small LOC.** Pass 1 finds ≥5 bounded contexts at <15K LOC. Upgrade one tier.
- **Deep integration fan-out.** `integration_surface_count` > 15 even at Simple LOC. Upgrade one tier.
- **Polyglot mixing within a module.** Same module blends ≥3 languages needing distinct strategies. Upgrade one tier.
- **DB-resident business logic.** ≥50 stored procedures, triggers, or functions carrying rules. Add `stored-proc-count / 10` to effective module count before re-comparing.
- **Cross-context transactions.** 2PC or cross-schema foreign keys spanning bounded contexts. Force Complex.

## Net adjustment cap

Maximum net adjustment is one tier per direction. A two-tier jump requires a Tech Lead override with the full override template — not an automatic adjustment.

## Recording

Append to `evidence.source_citations[]`:
`analyze-application:pass-1-coupling:<finding-id> — <downgrade|upgrade> per coupling-adjustment-rules.md`
