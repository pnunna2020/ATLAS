# Dispatch Strategy Mapping

Maps each tier to Modernization dispatch pattern, agent tier, timeout, and token-budget hint. The classifier MUST emit these combinations; mismatches fail validation.

## Tier-to-dispatch table

| Tier | Pattern | Agent Tier | Timeout (min) | Token Budget |
|---|---|---|---|---|
| Simple | `single-agent-sequential` | `tier-3-fast` | `30` | `75,000` |
| Moderate | `fan-out-per-module-then-synthesize` | `tier-2-standard` | `90` | `400,000` |
| Complex | `fan-out-per-bounded-context-then-synthesize` | `tier-1-reasoning` | `240` | `1,200,000` |

## Pattern definitions

- **single-agent-sequential** — One agent runs Extract, Design, Generate against the whole app. Only safe when it fits one context window and has one bounded context.
- **fan-out-per-module-then-synthesize** — One worker per module; synthesis merges artifacts. Use when modules are loosely coupled but numerous.
- **fan-out-per-bounded-context-then-synthesize** — One worker per bounded context; integration layer reconciles contracts, then synthesis assembles. Required when contexts cross transactional, data-ownership, or team lines.

## Agent tier semantics

- **tier-1-reasoning** — Highest-capability. Cross-context synthesis and contract reconciliation.
- **tier-2-standard** — Balanced. Default for per-module extraction and design.
- **tier-3-fast** — Lowest cost. Structured extraction on small self-contained apps.

Model names resolve in the model-router. Emit tier labels only.

## Timeout and token budget

Timeouts are wall-clock budgets for the Modernization pass. Token budgets are orchestration sizing hints — they do NOT bind calls. Profiles override via `profiles/<client>/rationalization.yaml` under `dispatch_overrides`.

## Validation invariants

- Simple forbids `fan-out-per-bounded-context-then-synthesize`.
- Complex forbids `single-agent-sequential`.
- `agent_tier` escalates monotonically with tier.
- `timeout_minutes` and `estimated_token_budget` must be present and positive.
