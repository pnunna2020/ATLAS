# Complexity Threshold Defaults

Defaults when no client profile overrides exist. Record in output as `thresholds.profile_source = "defaults:classify-complexity/references/threshold-defaults.md"`.

## Default boundaries

| Dimension | Simple | Moderate | Complex |
|---|---|---|---|
| LOC | `< 10K` | `10K – 100K` | `> 100K` |
| Module count | `< 5` | `5 – 20` | `> 20` |
| Bounded contexts | `1` | `2 – 4` | `> 4` |
| Endpoints | `< 25` | `25 – 150` | `> 150` |
| Tables | `< 20` | `20 – 100` | `> 100` |
| Integration surfaces | `< 5` | `5 – 15` | `> 15` |
| Languages | `1` | `2` | `> 2` |

## Rationale

- **LOC 10K / 100K** — Below 10K fits one long-context agent; above 100K, Pass 1 tokens exceed practical per-call budgets.
- **Modules 5 / 20** — Under 5, sequential beats fan-out overhead; above 20, fan-out amortizes synthesis cost.
- **Bounded contexts 1 / 4** — One fits a single agent; more than four forces an integration layer.
- **Endpoints 25 / 150** — Mid-sized service surface; 150+ makes per-endpoint contract work dominate.
- **Tables 20 / 100** — Matches `legacy-database-archaeologist` decomposition findings.
- **Integration surfaces 5 / 15** — Each adds contract, auth, retry work; 15+ is Complex alone.
- **Languages 2 / >2** — Polyglot stacks need per-language prompt conditioning.

## Selecting the tier

Use the **most restrictive dimension**. If LOC says Simple but bounded-context count says Complex, the tier is Complex. Then apply `coupling-adjustment-rules.md`.

## Client profile overrides

Override via `profiles/<client>/rationalization.yaml` (may not yet exist; loader reads top-level `complexity_thresholds`):

```yaml
complexity_thresholds:
  simple_loc_max: 8000
  simple_module_max: 4
  moderate_loc_max: 80000
  moderate_module_max: 18
```

Missing keys fall back to defaults. Record `thresholds.profile_source` as the profile YAML path when any key is overridden.
