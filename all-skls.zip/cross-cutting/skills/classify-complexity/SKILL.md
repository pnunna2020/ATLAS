---
name: classify-complexity
description: >
  Auto-classify applications as Simple, Moderate, or Complex using catalog metrics refined with Pass 1 structural analysis. Drives Modernization dispatch strategy and agent model tier. Output per schemas/rationalization/complexity-classification.schema.json. Triggers on complexity classification, app tiering, dispatch strategy, or @classify-complexity.
agent: sonnet
allowed-tools:
  - Read
  - Write
  - Grep
---

# Classify Complexity

## Purpose
Assign a Simple / Moderate / Complex tier to each application at Rationalization Step 5 so that every downstream Modernization dispatch decision — single-agent-sequential vs. fan-out-per-module vs. fan-out-per-bounded-context — and every agent model-tier selection is deterministic, evidence-cited, and traceable. This skill exists because raw catalog counts (LOC, module count, endpoint count) frequently mislead: a 30-directory repo may be a single god class, and a 10K-LOC repo may span ten bounded contexts. The classifier combines catalog metrics with Pass 1 structural findings so the emitted tier reflects actual decomposition difficulty, not directory cardinality.

## Inputs
- Application catalog entry (JSON per `schemas/discovery/application-catalog-entry.schema.json`) from `catalog-application`
- Pass 1 structural analysis output from `analyze-application` (module/component map, coupling indicators, bounded-context inventory)
- Integration graph (JSON per `schemas/rationalization/integration-graph.schema.json`)
- Client profile thresholds (`profiles/<client>/rationalization.yaml` if present; otherwise the defaults in `references/threshold-defaults.md`)
- Tech fingerprint from Discovery Step 1 (for `archetype` confirmation)
- Tech Lead override input (optional — supplied only when the auto classification is challenged)

## Outputs
- Complexity classification document (JSON) validating against `schemas/rationalization/complexity-classification.schema.json`
- Fillable skeleton at `assets/complexity-classification-template.json` — the canonical shape this skill populates
- Override record at `assets/override-justification-template.md` when `classification_method != auto`
- Dispatch-strategy recommendation (`pattern`, `agent_tier`, `timeout_minutes`, `estimated_token_budget`) embedded in the output per `references/dispatch-strategy-mapping.md`
- Threshold provenance recorded in `thresholds.profile_source` — either the client profile path or `defaults:classify-complexity/references/threshold-defaults.md`

## Methodology
1. Load the catalog entry, Pass 1 structural report, and integration graph. Confirm `application.id` and `application.archetype` match across all three inputs; halt with an error if they disagree.
2. Resolve thresholds: prefer `profiles/<client>/rationalization.yaml` if available. Fall back to `references/threshold-defaults.md`. Record the chosen source in `thresholds.profile_source`.
3. Compute raw evidence counts: `loc`, `module_count`, `bounded_context_count`, `endpoint_count`, `table_count`, `integration_surface_count`, `language_count`. Pull each value from its authoritative artifact and attach a `{artifact}:{section}:{finding-id}` citation to `evidence.source_citations[]`.
4. Run the first-pass tier assignment by comparing raw counts to the resolved thresholds. Use the most restrictive dimension — if LOC says Simple but bounded-context count says Complex, the tier is Complex.
5. Apply coupling adjustments per `references/coupling-adjustment-rules.md`. Downgrade when directories overstate decomposition (e.g., high module count with a single god class and circular imports). Upgrade when small LOC hides multiple bounded contexts or mixed languages.
6. Map the adjusted tier to a dispatch strategy and agent tier using `references/dispatch-strategy-mapping.md`. Populate `dispatch_strategy.pattern`, `agent_tier`, `timeout_minutes`, and `estimated_token_budget`.
7. If a Tech Lead override is supplied, set `classification_method` to `auto-then-human-confirmed` or `human-override`, populate the `override` block using `assets/override-justification-template.md`, and append a `reclassification_history[]` row.
8. Validate the document against `schemas/rationalization/complexity-classification.schema.json`. Reject any output missing required fields or failing enum checks.
9. Emit the classification and hand off to wave planning and Modernization dispatch.

## Gotchas
- **Directory count is not module count.** A repo with 30 source folders may be a single god class; a repo with 4 folders may host 10 bounded contexts. Always cross-check module count against Pass 1 coupling indicators before trusting it.
- **Bounded-context count dominates when it disagrees with LOC.** Modernization dispatch is driven by decomposition difficulty, not file size. 8K LOC across 6 bounded contexts is Complex for dispatch purposes even if LOC says Simple.
- **Thresholds must be traceable.** Every classification must cite either a client profile path or the defaults reference. Silent threshold choice breaks audit.
- **Archetype mismatches invalidate dispatch.** If the catalog archetype and the Pass 1 archetype disagree, halt — do not guess. An incorrect archetype routes to the wrong Modernization team composition.
- **Override without justification is a hard fail.** The `override` block requires a ≥20-char justification per the schema. Do not emit a human-override classification with an empty rationale.
- **Tier Complex implies fan-out-per-bounded-context.** Assigning Complex while leaving `dispatch_strategy.pattern = single-agent-sequential` is a self-inconsistent output and will fail downstream Modernization planning.
- **Language count matters for token budget.** Polyglot apps (≥3 languages) raise token budget even at Simple LOC because each language needs distinct prompt conditioning.

## Quality Rules
- [ ] Output validates against `schemas/rationalization/complexity-classification.schema.json` with no schema errors
- [ ] `tier` is one of `Simple`, `Moderate`, `Complex` and is consistent with the adjusted counts in `evidence` after coupling adjustments are applied
- [ ] `evidence.source_citations[]` is non-empty and every citation uses `{artifact}:{section}:{finding-id}` or `{repo}:{file}:{line}` format
- [ ] `thresholds.profile_source` is populated and points either to a client profile file under `profiles/` or to `defaults:classify-complexity/references/threshold-defaults.md`
- [ ] `dispatch_strategy.pattern` matches the tier per `references/dispatch-strategy-mapping.md` — no Complex tier with `single-agent-sequential`, no Simple tier with `fan-out-per-bounded-context-then-synthesize`
- [ ] `dispatch_strategy.agent_tier`, `timeout_minutes`, and `estimated_token_budget` are all populated
- [ ] When `classification_method != auto`, the `override` block is populated with `original_tier`, a `justification` string of at least 20 characters, an `approver`, and an `approved_date`, matching `assets/override-justification-template.md`
- [ ] `application.archetype` matches the archetype value in the Discovery Step 1 tech fingerprint
- [ ] Coupling-adjustment decisions (upgrade or downgrade from raw counts) are cited with a Pass 1 finding ID in `evidence.source_citations[]`

## Common Failure Modes
| Failure Mode | Symptom | Prevention |
|---|---|---|
| Directory count conflated with module count | Raw `module_count = 30` triggers Complex tier on a single-god-class monolith | Apply coupling adjustments per `references/coupling-adjustment-rules.md`; downgrade when Pass 1 reports high inbound fan-in on one class |
| Complex tier assigned but dispatch pattern stays single-agent | Output has `tier = Complex` and `dispatch_strategy.pattern = single-agent-sequential` | Enforce the tier-to-pattern mapping from `references/dispatch-strategy-mapping.md` in the validator before emit |
| Thresholds not traceable | `thresholds.profile_source` is empty or a free-text string | Require either a `profiles/<client>/rationalization.yaml` path or the `defaults:` sentinel; reject empty values |
| Override emitted without justification | `classification_method = human-override` with empty or boilerplate `override.justification` | Require ≥20 chars per the schema and evidence citations in the justification per the override template |
| Bounded-context count ignored | Small LOC app classified Simple while Pass 1 shows 8 bounded contexts | Use the most restrictive dimension in Step 4; upgrade per `references/coupling-adjustment-rules.md` when bounded-context count dominates |
| Archetype drift between catalog and fingerprint | Classifier emits Complex web-app while fingerprint says batch-etl | Halt on archetype mismatch; do not continue with a guessed archetype |

## Handoff Summary
When this skill completes, verify:
1. The classification document validates against `schemas/rationalization/complexity-classification.schema.json`.
2. Every count in `evidence` has a `{artifact}:{section}:{finding-id}` or `{repo}:{file}:{line}` citation and the threshold source is recorded.
3. `dispatch_strategy` is internally consistent with `tier` per `references/dispatch-strategy-mapping.md`.
4. Any override is fully populated per `assets/override-justification-template.md` with approver, date, and a ≥20-char evidence-cited justification.

Then proceed to: wave planning (Rationalization Step 7) for sequencing, Modernization line dispatch for agent team allocation, and gate `G-RR` (Rationalization Ready) for classification review.
