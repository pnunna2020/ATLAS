# Complexity Classification Override Justification

Use this template whenever `classification_method` is `auto-then-human-confirmed` or `human-override`. The populated content maps directly into the `override` block of the classification document.

## Header

- **Application ID:** `<application.id>`
- **Application Name:** `<application.name>`
- **Classification Date:** `<YYYY-MM-DD>`

## Tier Change

| Field | Value |
|---|---|
| Original Tier (auto) | `Simple` \| `Moderate` \| `Complex` |
| Overridden Tier | `Simple` \| `Moderate` \| `Complex` |
| Classification Method | `auto-then-human-confirmed` \| `human-override` |

## Evidence Cited

List every artifact and source citation that supports the override. Use `{artifact}:{section}:{finding-id}` or `{repo}:{file}:{line}` format.

- `<citation-1>` — what it shows
- `<citation-2>` — what it shows
- `<citation-3>` — what it shows

Minimum: two independent citations for a one-step tier change; three for a two-step change (Simple to Complex or Complex to Simple).

## Rationale

Write at least 20 characters. Explain *why* the auto classification was incorrect and *what evidence* supports the new tier. Examples:

- "Raw module count 30 overstates decomposition — Pass 1 finding F-PASS1-0042 shows a single 8K-line god class with 28 direct callers; true module count is 3."
- "LOC 6K understates complexity — integration graph I-G-17 shows 9 bounded contexts spanning payments, auth, ledger, and fraud; fan-out-per-bounded-context required."

## Approval

- **Approver:** `<name or role — Tech Lead, Chief Architect, etc.>`
- **Approved Date:** `<YYYY-MM-DD>`
- **Recorded in reclassification_history:** yes / no

## Downstream Impacts Acknowledged

- [ ] Dispatch strategy updated per `references/dispatch-strategy-mapping.md`
- [ ] Agent tier updated
- [ ] Timeout and token budget updated
- [ ] Wave plan notified if tier change alters capacity estimate
