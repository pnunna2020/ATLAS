# Architecture Blueprint: {application_name}

> **Archetype**: {archetype}
> **Risk Tier**: {risk_tier}
> **Disposition**: {disposition}
> **Wave**: {wave_number}
> **Blueprint Version**: {version}
> **Last Updated**: {date}

---

## Table of Contents

1. [Executive Summary](#1-executive-summary)
2. [Architecture Pattern](#2-architecture-pattern)
3. [Cloud Service Selection Matrix](#3-cloud-service-selection-matrix)
4. [Compute Tier Design](#4-compute-tier-design)
5. [Data Tier Design](#5-data-tier-design)
6. [Integration Tier Design](#6-integration-tier-design)
7. [Identity and Authorization Design](#7-identity-and-authorization-design)
8. [Observability Design](#8-observability-design)
9. [Resilience Design](#9-resilience-design)
10. [Deployment Topology](#10-deployment-topology)
11. [Security Architecture](#11-security-architecture)
12. [Cost Estimate](#12-cost-estimate)
13. [Architecture Decision Records](#13-architecture-decision-records)
14. [Traceability Matrix](#14-traceability-matrix)
15. [Well-Architected Review Scores](#15-well-architected-review-scores)

---

## 1. Executive Summary

**Application Name**: {application_name}
**Current State**: {brief description of legacy application}
**Target State**: {brief description of modernized application}

### Key Decisions
| Decision | Choice | Rationale |
|----------|--------|-----------|
| Architecture pattern | {pattern} | {one-line rationale} |
| Compute platform | {service} | {one-line rationale} |
| Data platform | {service} | {one-line rationale} |
| Integration approach | {approach} | {one-line rationale} |

### Risk Summary
- **Top Risk 1**: {risk and mitigation}
- **Top Risk 2**: {risk and mitigation}
- **Top Risk 3**: {risk and mitigation}

---

## 2. Architecture Pattern

**Selected Pattern**: {Modular Monolith | Microservices | Event-Driven | Serverless | Hybrid}

**Rationale**: {Why this pattern was selected, with reference to Discovery findings}

**Alternatives Considered**:
| Pattern | Pros | Cons | Why Not Selected |
|---------|------|------|-----------------|
| {alt1} | {pros} | {cons} | {reason} |
| {alt2} | {pros} | {cons} | {reason} |

**Bounded Contexts** (if Microservices or Modular Monolith):
1. {context_name}: {responsibility}
2. {context_name}: {responsibility}

---

## 3. Cloud Service Selection Matrix

| Capability | Primary Service | Alternative | GovCloud Available | Justification |
|-----------|----------------|-------------|-------------------|---------------|
| Compute | {service} | {alt} | Yes/No | {reason} |
| Database | {service} | {alt} | Yes/No | {reason} |
| Cache | {service} | {alt} | Yes/No | {reason} |
| Object Storage | {service} | {alt} | Yes/No | {reason} |
| API Gateway | {service} | {alt} | Yes/No | {reason} |
| Messaging | {service} | {alt} | Yes/No | {reason} |
| Event Bus | {service} | {alt} | Yes/No | {reason} |
| CDN | {service} | {alt} | Yes/No | {reason} |
| Secrets | {service} | {alt} | Yes/No | {reason} |
| Monitoring | {service} | {alt} | Yes/No | {reason} |

---

## 4. Compute Tier Design

### Service Configuration
{Fargate task definitions, Lambda function configurations, or EC2 instance specifications}

### Scaling Strategy
- **Scaling metric**: {CPU | memory | request count | custom}
- **Target value**: {percentage or count}
- **Min capacity**: {number}
- **Max capacity**: {number}
- **Scale-in cooldown**: {seconds}
- **Scale-out cooldown**: {seconds}

### Container Architecture (if Fargate)
{Base image, multi-stage build strategy, health check configuration}

---

## 5. Data Tier Design

### Primary Database
- **Service**: {Aurora PostgreSQL Serverless v2 | Aurora Provisioned | DynamoDB}
- **Configuration**: {ACU range, instance type, or capacity mode}
- **Schema strategy**: {migration tool, versioning approach}

### Cache Layer (if applicable)
- **Service**: {ElastiCache Redis | DAX}
- **Cache strategy**: {cache-aside | write-through | write-behind}
- **TTL policy**: {default TTL and per-entity overrides}

### Object Storage
- **Bucket structure**: {bucket naming, prefix conventions}
- **Lifecycle policy**: {tier transitions and retention}

### Data Migration Strategy
{How data moves from legacy database to target database}

---

## 6. Integration Tier Design

### API Gateway
- **Service**: {Gravitee | API Gateway}
- **Auth**: {OKTA OIDC | API key | mTLS}
- **Rate limiting**: {requests per second per client}

### Event-Driven Integrations
| Event | Source | Target | Bus/Queue | Schema |
|-------|--------|--------|-----------|--------|
| {event} | {source} | {target} | {EventBridge/SQS} | {schema ref} |

### External System Integrations
| System | Protocol | Auth | Direction | Frequency |
|--------|----------|------|-----------|-----------|
| {system} | {REST/SOAP/SFTP} | {method} | {inbound/outbound} | {real-time/batch} |

---

## 7. Identity and Authorization Design

### User Authentication
- **Provider**: {OKTA}
- **Flow**: {Authorization Code + PKCE | Client Credentials}
- **Session management**: {token lifetime, refresh strategy}

### Service-to-Service Authentication
- **Method**: {mTLS | IAM roles | service mesh}
- **Certificate management**: {ACM | CyberArk}

### External System Authentication
| System | Auth Method | Credential Storage |
|--------|------------|-------------------|
| {system} | {method} | {Secrets Manager / CyberArk} |

### Authorization Model
- **Strategy**: {RBAC | ABAC | hybrid}
- **Role definitions**: {list of roles and permissions}

---

## 8. Observability Design

### Monitoring
- **Metrics**: {CloudWatch custom metrics, Container Insights}
- **Key metrics**: {list of application-specific metrics}
- **Dashboard**: {CloudWatch dashboard configuration}

### Logging
- **Destination**: {CloudWatch Logs}
- **Format**: {structured JSON}
- **Retention**: {days}
- **Log levels**: {per-environment configuration}

### Tracing
- **Service**: {X-Ray}
- **Sampling rate**: {percentage}
- **Instrumentation**: {SDK | auto-instrumentation}

### Alerting
| Alert | Condition | Severity | Notification |
|-------|-----------|----------|-------------|
| {alert} | {condition} | {P1/P2/P3} | {SNS/PagerDuty} |

---

## 9. Resilience Design

### High Availability
- **Deployment model**: {multi-AZ | multi-region}
- **Minimum healthy targets**: {count}
- **Health check**: {path, interval, threshold}

### Disaster Recovery
- **Strategy**: {pilot light | warm standby | active-active}
- **RTO**: {minutes/hours}
- **RPO**: {minutes/hours}

### Failover Matrix
| Component | Failure Mode | Detection | Recovery | RTO |
|-----------|-------------|-----------|----------|-----|
| {component} | {failure} | {method} | {action} | {time} |

### Circuit Breakers
| Integration | Threshold | Timeout | Fallback |
|------------|-----------|---------|----------|
| {service} | {error rate %} | {seconds} | {behavior} |

---

## 10. Deployment Topology

### VPC Design
- **CIDR**: {range}
- **Subnets**: {public, private app, private data per AZ}
- **VPC endpoints**: {list of endpoints}

### Environment Configuration
| Environment | Sizing | Scaling | Access |
|------------|--------|---------|--------|
| Production | {spec} | {auto-scaling} | {restricted} |
| Staging | {spec} | {scheduled} | {team} |
| Development | {spec} | {scheduled} | {developers} |

### CI/CD Pipeline
- **Source**: {Git repository}
- **Build**: {CodeBuild / GitHub Actions}
- **Deploy**: {CodeDeploy / ECS rolling / blue-green}
- **Promotion**: {dev -> staging -> prod with gate approvals}

---

## 11. Security Architecture

### Network Security
- **Security groups**: {inbound/outbound rules summary}
- **NACLs**: {network ACL rules}
- **WAF**: {rule sets and custom rules}

### Encryption
- **At rest**: {KMS key policy, per-service encryption}
- **In transit**: {TLS 1.2+, mTLS for service-to-service}

### Zero Trust Controls
- **Microsegmentation**: {security group per service, deny-by-default}
- **Identity verification**: {per-request authentication}
- **Least privilege**: {IAM role boundaries, task roles}

### Compliance Seeds
- **SSP sections covered**: {list of NIST control families}
- **Inherited controls**: {list with provider references}
- **POA&M items**: {known gaps requiring remediation}

---

## 12. Cost Estimate

### Summary
| Category | Current TCO (Monthly) | Projected Cloud (Monthly) |
|----------|----------------------|--------------------------|
| Compute | ${amount} | ${amount} |
| Data | ${amount} | ${amount} |
| Networking | ${amount} | ${amount} |
| Integration | ${amount} | ${amount} |
| Observability | ${amount} | ${amount} |
| Security | ${amount} | ${amount} |
| **Total** | **${amount}** | **${amount}** |

### Savings Applied
{Savings Plans, Spot instances, scheduled scaling, lifecycle policies}

### Net Savings
- **Monthly savings**: ${amount}
- **Annual savings**: ${amount}
- **ROI**: {percentage}

---

## 13. Architecture Decision Records

### ADR-001: {Decision Title}
- **Status**: Accepted
- **Context**: {Why this decision was needed}
- **Decision**: {What was decided}
- **Consequences**: {Impact of this decision}
- **Traces to**: {discovery_artifact}:{section}:{finding_id}

{Repeat for each ADR}

---

## 14. Traceability Matrix

| ADR ID | Decision Summary | Discovery Artifact | Finding ID | Finding File | Rationale |
|--------|-----------------|-------------------|------------|-------------|-----------|
| ADR-001 | {summary} | {artifact} | {finding_id} | {file:line} | {rationale} |

### Coverage
- **Total ADRs**: {count}
- **Traced to Discovery**: {count}
- **Coverage**: {percentage}

---

## 15. Well-Architected Review Scores

| Pillar | Score (1-5) | Key Finding |
|--------|-------------|-------------|
| Operational Excellence | {score} | {finding} |
| Security | {score} | {finding} |
| Reliability | {score} | {finding} |
| Performance Efficiency | {score} | {finding} |
| Cost Optimization | {score} | {finding} |
| Sustainability | {score} | {finding} |

**Overall Score**: {weighted average}

### Top Risks
1. {risk and recommended action}
2. {risk and recommended action}
3. {risk and recommended action}
