---
name: blueprint-assembler
description: >
  Assemble the final architecture blueprint by synthesizing outputs from all
  Architecture line steps (target architecture, resilience, topology,
  integration, security, design system, cost estimate). Validates completeness,
  resolves cross-references, detects contradictions, and builds the traceability
  matrix. Used at Architecture Step 6. Triggers on blueprint assembly,
  architecture synthesis, or blueprint finalization mentions.
agent: sonnet
allowed-tools:
  - Read
  - Write
  - Bash
  - Grep
---

# Blueprint Assembler

## Purpose
Synthesize all Architecture line outputs into a single, coherent architecture
blueprint document. This is the authoritative artifact for the Modernization
line and the primary input to gate G-02 (Architecture Review).

## Inputs
- Target architecture design (Step 1 output)
- Resilience design (Step 2 output)
- Deployment topology (Step 3 output)
- Security architecture and control mapping (Step 4 output)
- Cost estimate (Step 5 output)
- Integration design (from target architecture)
- Design system selection (from target architecture)
- Discovery artifacts (for traceability verification)

## Outputs
- Final architecture blueprint (from `assets/blueprint-template.md`)
- Traceability matrix (from `assets/traceability-matrix-template.yaml`)
- Cross-reference validation report
- Contradiction detection report (if any found)

## Methodology
1. Load all Step 1-5 outputs from the artifact store
2. Validate completeness: confirm all required sections are present per the blueprint template
3. Resolve cross-references: verify service selections are consistent across sections (e.g., if Step 1 selects Aurora, Steps 2-5 must reference Aurora, not RDS MySQL)
4. Detect contradictions: flag inconsistencies (e.g., security requires encryption at rest but topology omits KMS key provisioning)
5. Build traceability matrix: map every Architecture Decision Record to its originating Discovery finding
6. Produce final blueprint document with table of contents, cross-linked sections, and appendices

## Cross-Reference Validation Rules
- Every service named in the compute tier must appear in the deployment topology
- Every data store in the data tier must have a backup/DR strategy in the resilience design
- Every external integration must have an auth mechanism in the security architecture
- Every service must have a cost line item in the cost estimate
- Every security control must map to at least one architecture component

## Gotchas
- **Contradictions are common across independent steps**: Steps 1-5 are often
  produced by different skill invocations. Service name inconsistencies
  ("ElastiCache" vs "Redis" vs "cache layer") must be normalized.
- **Missing sections are not acceptable at G-02**: The blueprint template has
  15 sections. Every section must be present, even if a section states "Not
  applicable" with justification.
- **Traceability gaps block the gate**: Every ADR must trace to a Discovery
  finding. An ADR justified only by "best practice" without evidence will be
  rejected at G-02.

## Quality Rules
- [ ] All 15 blueprint template sections are present and populated (or explicitly marked N/A with justification)
- [ ] Service names are normalized across all sections (no aliases or inconsistent naming)
- [ ] Cross-reference validation passes: every service appears in compute, topology, resilience, security, and cost sections
- [ ] Zero contradictions between sections (or contradictions are documented with resolution)
- [ ] Traceability matrix maps every ADR to at least one Discovery finding with artifact:section:finding-id citation
- [ ] Cost estimate total matches the sum of individual service line items

## Common Failure Modes
| Failure Mode | Symptom | Prevention |
|-------------|---------|------------|
| Inconsistent service naming | Step 1 says "Aurora Serverless" but Step 3 says "PostgreSQL RDS"; reviewer confused | Normalize all service names in a glossary pass before assembly |
| Missing blueprint section | Security architecture section absent; G-02 reviewer rejects blueprint | Validate all 15 sections against template checklist before submission |
| Orphan ADR without trace | ADR-007 says "selected event-driven pattern" but no Discovery finding supports it | Run traceability validator; require every ADR to cite evidence |
| Cross-section contradiction | Resilience requires multi-region failover but topology deploys single-region | Run contradiction detection across all section pairs |

## Handoff Summary
When this skill completes, verify:
1. All 15 blueprint sections are complete and internally consistent
2. Cross-reference validation passes with zero errors
3. No unresolved contradictions remain
4. Traceability matrix achieves >= 95% coverage
Then proceed to: `architecture-traceability-validator` for independent trace verification, `well-architected-reviewer` for pillar scoring, and gate `G-02` for architecture review
