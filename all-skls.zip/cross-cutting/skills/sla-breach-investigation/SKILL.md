---
name: sla-breach-investigation
description: >
  Investigate availability SLA breaches or approaching-threshold alerts for sustainment applications. Use during ST.1 when 99.9% availability is threatened. Triggers on SLA breach, availability alert, uptime investigation, or downtime analysis.
agent: sonnet
---

# SLA Breach Investigation
## Purpose
When an application's availability drops below 99.9% (or trends toward it),
systematically diagnose the cause before it becomes a sustained outage.

## Investigation Steps
1. Confirm the alert: Is it a real outage or a monitoring false positive?
2. Check Datadog synthetic monitors for the affected application
3. Review recent changes: Was there a deployment, patch, or config change?
4. Check infrastructure: EC2/ECS health, RDS connections, network ACLs
5. Check dependencies: Did a shared service (OKTA, Gravitee, Oracle) degrade?
6. Check external factors: Network outage, AWS region issues, DNS propagation

## Gotchas
- **99.9% availability = 8.7 hours downtime per YEAR**: Every minute counts.
  A 30-minute outage in January uses 5.7% of the annual budget.
- **Shared infrastructure failures affect multiple apps**: If Oracle RAC has
  issues, it may affect dozens of sustainment apps simultaneously.

## Quality Rules
- [ ] Alert is confirmed as real outage or false positive before investigation proceeds
- [ ] Investigation checks all 6 categories: monitoring, recent changes, infrastructure, dependencies, external factors
- [ ] Root cause is identified with evidence from Datadog, CloudWatch, or Gravitee analytics
- [ ] Impact on 99.9% annual availability budget is calculated (8.7 hours total per year)
- [ ] Shared infrastructure failures are assessed for portfolio-wide impact, not just the alerting app
- [ ] Investigation report includes timeline, root cause, resolution, and prevention recommendation

## Common Failure Modes
| Failure Mode | Symptom | Prevention |
|-------------|---------|------------|
| False positive not filtered | Investigation launched for a monitoring glitch; wasted effort | Confirm alert with secondary monitoring source (synthetic monitors, health checks) before full investigation |
| Recent change not checked | Deployment 2 hours before outage not considered; root cause missed | Always check change log and deployment history within 24 hours of the alert |
| Shared infrastructure impact missed | Oracle RAC issue affects 30 apps but only alerting app investigated | Check shared infrastructure components; assess portfolio-wide impact for infrastructure root causes |
| Availability budget not tracked | Multiple short outages consume annual budget without awareness; SLA breach at year-end | Track cumulative downtime against 8.7-hour annual budget; alert at 50% consumption |

## Handoff Summary
When this skill completes, verify:
1. Alert is confirmed (real outage vs false positive)
2. Root cause is identified with evidence
3. Availability budget impact is calculated
4. Prevention recommendation is documented
Then proceed to: `incident-response` if immediate remediation is needed, `patch-assessment` if a vulnerability is the root cause, or normal monitoring if resolved
