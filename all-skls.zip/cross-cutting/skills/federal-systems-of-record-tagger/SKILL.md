---
name: federal-systems-of-record-tagger
description: >
  Explicitly tag each application as a federal system of record or a
  downstream replica, cite the statutory authority that establishes
  legal-record status, and enumerate downstream replicas consuming the
  record. `compliance-citation-mapper` emits every USC/CFR/PL/FR/EO/FAA
  Order citation but does NOT isolate which citation establishes
  legal-record authority — a critical input to Tier-1 disposition
  decisions. Without this tag, Disposition-Recommender and
  Assess-User-Impact cannot correctly elevate Retain/Refactor decisions
  for legally-mandated record systems (e.g., 49 USC §44107 for RMS
  airmen registry; 14 CFR Part 61/63/65 for IACRA certificate issuance;
  14 CFR Part 183 for DMS designee authority; 14 CFR Part 67 for AAM
  medical certification). Runs as a Discovery conditional skill when
  the application catalog entry has either a regulatory citation or an
  authoritative-database pattern. Triggers on system-of-record tagging,
  legal-record authority analysis, downstream-replica enumeration, or
  @federal-systems-of-record-tagger.
agent: sonnet
allowed-tools:
  - Read
  - Write
  - Grep
  - Glob
validation_commands:
  - "python -m olympus.validators.schema_validator system-of-record.json"
  - "python -m olympus.validators.schema_validator legal-record-authority-findings.json"
  - "python -m olympus.validators.schema_validator replica-topology.json"
supported_stacks:
  - any
anti_target_stacks:
  - ephemeral-cache
  - pure-static-site
  - test-fixture
failure_classes:
  - sor-conflated-with-replica
  - statutory-citation-missing
  - replica-chain-unresolved
  - soft-law-vs-hard-law-confused
  - multi-sor-per-app-flattened
  - record-system-designation-not-cited
  - downstream-replica-treated-as-sor
benchmark_tags:
  - discovery-governance
  - system-of-record-tagging
  - legal-record-authority
  - tier-1-disposition-input
---

# federal-systems-of-record-tagger

## Purpose
Produce a machine-readable tag on each application that answers three
questions: (a) is this a federal system of record with legal-record
authority, a replica/downstream consumer, or neither; (b) which
statute or regulation establishes the authority; (c) which other
applications consume the record as a downstream replica. These tags
drive Tier-1 disposition decisions because legally-mandated record
systems cannot be casually Retired, Replaced, or Consolidated — the
statutory authority must be preserved through modernization. Without
this skill, Disposition-Recommender sees only a generic compliance-
citation list and cannot distinguish a system whose retirement
triggers a legal-record-custody transfer from one whose retirement
is operationally trivial.

## Inputs
- Application catalog entry from `catalog-application` with the app's
  purpose, owner, and mission context.
- Compliance citation inventory from `compliance-citation-mapper`
  (`citation-validation.json`) — provides the raw USC/CFR/PL/FR/EO
  citation pool.
- Database archaeology output from `legacy-database-archaeologist`
  (`db-archaeology.json`) — identifies authoritative-database patterns
  (non-replica schemas, primary-key ownership).
- Client-profile regulatory taxonomy (`profiles/<client>/compliance.yaml`)
  — provides the authoritative citation-to-authority-type mapping.
- Optional: portfolio-wide integration graph (`integration-graph.json`)
  — enables downstream-replica resolution.
- Per-app READMEs, system-overview docs, data-dictionary documents when
  present in the repo.

## Outputs
- `system-of-record.json` — per application: `{app_id, app_name,
  designation (system_of_record | authoritative_replica |
  downstream_replica | operational_only | unknown), primary_sor_database,
  primary_sor_platform, statutory_authorities[], record_types[],
  legal_custody_implications, tier_elevation_recommended (true/false)}`.
- `legal-record-authority-findings.json` — one record per statutory
  citation that establishes legal-record authority: `{app_id, citation,
  authority_type (statute | regulation | executive_order |
  presidential_directive), scope (agency-wide | app-specific | record-
  type-specific), source_location, citation_strength (explicit |
  inferred | inherited)}`.
- `replica-topology.json` — downstream-replica graph: per record type,
  which app holds the SoR copy and which apps hold replicas:
  `{record_type, sor_app, replica_apps[] (app_id, replica_platform,
  refresh_mechanism (nightly_etl | change_stream | manual |
  scheduled_feed), drift_tolerance)}`.

## Methodology
1. **Enumerate candidate SoR citations.** Read
   `citation-validation.json` from `compliance-citation-mapper`.
   Filter to citations whose text or section number matches the
   client-profile's record-authority patterns. For FAA:
   - `49 USC §44107` → airmen registry authority (RMS CAIS).
   - `49 USC §44103` → aircraft registration authority (RMS AR).
   - `14 CFR Part 61 / 63 / 65` → airman certificate issuance authority (IACRA).
   - `14 CFR Part 67` → medical certification authority (AAM suite).
   - `14 CFR Part 183` → designee authority (DMS).
   - `44 USC §3301 et seq.` (Federal Records Act) → generic federal
     record-retention authority.
   - `44 USC §3541 et seq.` (FISMA) → authorization-to-operate
     boundary (NOT record authority, but frequently co-occurs —
     record separately).
2. **Classify designation per citation.** For each matching citation,
   determine whether it establishes: (a) the app as the authoritative
   holder (`system_of_record`); (b) a legally-recognized authoritative
   replica for specific purposes (`authoritative_replica`); or (c) an
   operational copy with no legal-record status (`downstream_replica`).
   Authority types that create SoR designation: statute
   ("shall maintain"), regulation with "record" or "registry" language,
   executive order directing record custody.
3. **Confirm authoritative-database pattern from DB archaeology.**
   Cross-reference `db-archaeology.json`. A true SoR typically: owns
   the primary key of the record type; is the transactional write
   target (not a load target); has no upstream ETL (or the upstream
   is purely reference data). A replica typically: has a last-refresh
   timestamp column; is populated by scheduled feed; does not own
   inbound edits to the record type.
4. **Enumerate record types.** For each app tagged SoR, enumerate the
   record types it holds authority over. RMS example: airman record
   (name, certificate number, DOB, medical-certification status),
   aircraft record (N-number, owner, type, airworthiness). DMS example:
   designee record (designation, authority scope, expiration).
5. **Reconstruct downstream-replica chains.** For each SoR record type,
   walk the portfolio integration graph forward to enumerate apps that
   maintain replicas. RMS airman records flow to AMCS, MedXPress,
   CHAPS, IACRA (via D48 nightly feed). IACRA application records flow
   to RMS (via ApplicationTransferToRMS). Each replica carries a
   refresh mechanism + drift tolerance.
6. **Emit tier-elevation recommendation.** When an app is tagged
   `system_of_record` with statutory authority, emit
   `tier_elevation_recommended: true` — Disposition-Recommender should
   raise the risk-tier floor regardless of the app's operational
   profile.
7. **Cite every designation claim.** Every designation record in
   `system-of-record.json` must carry a `statutory_authorities[]` list
   with at least one citation grounded in
   `citation-validation.json` via `{artifact}:{section}:{finding-id}`.

## Tech-Stack Dispatch

| Trigger | Reference loaded |
|---|---|
| Presence of `citation-validation.json` in prior artifacts | `references/legal-record-authority-patterns.md` |
| FAA client profile active | `references/faa-record-authority-citations.md` |

## Gotchas
- **SoR is a legal designation, not a technical one.** An app can be
  the operational source of truth for a record type without being the
  federal system of record — only statute or regulation establishes
  SoR. Do not tag based on primary-key ownership alone.
- **Record-authority citations are often inherited from parent
  statute.** 14 CFR Part 67 is the regulation; its enabling statute is
  49 USC §44703. Emit both with `citation_strength: explicit` for the
  CFR and `inherited` for the USC parent.
- **Multiple SoRs can coexist per app.** RMS holds airman records
  (49 USC §44107) AND aircraft records (49 USC §44103) — two distinct
  SoR designations in one app. Do not collapse.
- **Downstream replicas can become authoritative replicas.** When a
  replica is specifically designated in statute as the authoritative
  copy for a purpose (e.g., a read-only portal for public access),
  it is `authoritative_replica`, not `downstream_replica`.
- **Record custody transfer triggers statutory obligations.**
  Retiring, replacing, or consolidating a SoR app requires transferring
  record custody to a successor system — the `legal_custody_implications`
  field must enumerate these obligations (NARA coordination, SORN
  notice, Privacy Act notice, 44 USC §3301 et seq. compliance).
- **Privacy Act SORN is separate from the SoR designation.** A System
  of Records Notice (SORN) under 5 USC §552a is required for
  privacy-covered records but does not by itself establish a federal
  system of record in the custody sense. Record separately; do not
  conflate.
- **FISMA boundary ≠ record custody boundary.** FISMA establishes an
  authorization-to-operate boundary; record custody is established
  independently by records-management statutes. An app may span
  one FISMA boundary but hold records under multiple statutes.
- **Inherited designation from portfolio context.** When an app
  inherits SoR status from being part of a suite (e.g., the AAM suite
  for 14 CFR Part 67 records), record the citation with
  `scope: agency-wide` or `scope: suite-wide` and
  `citation_strength: inherited`.
- **Test / dev / sandbox instances are never SoRs.** Even if they
  contain real record data, only the designated production instance
  holds the SoR designation. Filter by `archetype` and environment.
- **Legacy apps predating current statute.** RMS / CAIS predates
  current 49 USC compilation; the record authority chain goes back to
  Civil Aeronautics Act of 1938 and 1958 amendments. Record the
  current governing citation, not the historical one, unless the
  client profile specifies otherwise.
- **Citation strength matters for governance gates.** An `explicit`
  citation quoted verbatim in the source passes governance review
  automatically; an `inferred` citation requires human adjudication.
  Emit the strength per citation.

## Quality Rules
- [ ] Every application in the input catalog has a designation
      record in `system-of-record.json` (even if designation is
      `unknown` — no app is unlabeled).
- [ ] Every `system_of_record` or `authoritative_replica`
      designation carries at least one citation in
      `statutory_authorities[]` with source-file + line.
- [ ] Multiple SoR designations per app are recorded as separate
      records in the same app's entry (not collapsed).
- [ ] Every SoR record type has a downstream-replica chain entry
      in `replica-topology.json` (even if replica list is empty).
- [ ] `legal_custody_implications` enumerates NARA / SORN / Privacy
      Act / 44 USC §3301 obligations where applicable.
- [ ] `tier_elevation_recommended` is set for every SoR app.
- [ ] Every designation record cites `{repo}:{file}:{line}` or
      `{citation-validation.json}:{finding-id}` for its evidence.
- [ ] `citation_strength` (explicit | inferred | inherited) is
      populated per citation.
- [ ] Unknown-designation apps are not silently omitted — they
      carry `designation: unknown` + an open-question record.

## Common Failure Modes

| Failure Mode | Symptom | Prevention |
|---|---|---|
| SoR confused with replica | RMS tagged as downstream_replica because airmen data also lives in AMCS | Require a statutory citation explicitly establishing SoR, not just primary-key ownership |
| Statutory citation missing | Designation recorded without statutory_authorities | Refuse to emit SoR/authoritative_replica designation without at least one citation |
| Inherited citation lost | AAM-suite Part-67 records tagged only at suite level; per-app designation not emitted | Expand suite-wide citations into per-app inherited designations |
| Privacy Act SORN conflated with SoR | SORN presence treated as SoR evidence | Distinguish via citation authority type — 5 USC §552a is privacy, not custody |
| FISMA boundary mistaken for record boundary | ATO package treated as SoR scope | Record-authority analysis uses records-management statutes only |
| Multi-SoR apps flattened | RMS recorded as one SoR instead of airman + aircraft separately | Enumerate per record type, not per app |
| Replica chain truncated | Replica app listed but its own downstream replicas ignored | Walk the integration graph transitively |

## Handoff Summary
When this skill completes, verify:
1. Every app has a designation record, including `designation: unknown`
   entries for apps where the evidence is ambiguous.
2. Every SoR designation carries a grounded statutory citation.
3. The replica-topology graph is transitively closed — no SoR has an
   unresolved replica edge.
4. `tier_elevation_recommended` is set consistently for legal-record
   systems.
5. `legal_custody_implications` enumerates the statutory obligations
   that disposition decisions must address.

Then proceed to: `disposition-recommender` (Rationalization primary) —
which consumes `system-of-record.json` to raise the tier floor and
narrow the disposition set for SoR apps; `disposition-governance` —
which uses `legal_custody_implications` to compose the governance
package; and, for SoR apps facing Retire/Replace/Consolidate,
`assess-user-impact` for record-custody-transfer planning.

## References
- `references/legal-record-authority-patterns.md` — general patterns
  for identifying legal-record authority from statute, regulation,
  executive orders; authority-type taxonomy; strength classification
  (explicit / inferred / inherited); multi-SoR-per-app handling;
  Privacy Act SORN distinction; FISMA-boundary distinction.
- `references/faa-record-authority-citations.md` — FAA-specific
  citation catalog mapping agency apps to governing authorities:
  49 USC Subtitle VII (airmen registry, aircraft registration,
  certificate issuance), 14 CFR (Parts 61, 63, 65, 67, 183), relevant
  FAA Orders, and NARA-approved retention schedules for airmen /
  aircraft / medical / designee records.

## Changelog
- 0.1.0 (2026-05-08) — Initial skill. Covers SoR / authoritative-
  replica / downstream-replica designation, statutory-authority
  citation, record-type enumeration, downstream-replica topology,
  tier-elevation recommendation. Emits three manifests with
  `{repo}:{file}:{line}` traceability. Authored as FAA-proposal-P0
  (see `docs/testing/faa-proposal-skill-assessment.md` Section 9).
