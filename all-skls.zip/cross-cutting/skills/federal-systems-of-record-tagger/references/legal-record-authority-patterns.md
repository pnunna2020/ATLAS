# Legal-Record-Authority Patterns

Coverage for identifying which USC/CFR/PL/FR/EO citations establish
federal-system-of-record authority vs operational or privacy-only
authority.

## Authority Taxonomy

Not every regulatory citation establishes SoR. Classify into four
authority types:

| Type | Examples | SoR-establishing? |
|---|---|---|
| `statute` (USC, PL) | `49 USC §44107`, `5 USC §552a` (Privacy Act) | Yes when record-custody language is present |
| `regulation` (CFR, FR) | `14 CFR Part 67`, `14 CFR Part 183` | Yes when "record", "registry", or "system of records" is used |
| `executive_order` | EO 13556 (Controlled Unclassified Info) | Rarely SoR-establishing; usually operational |
| `presidential_directive` | HSPD-12 (PIV) | Operational, not custody |

## Record-Custody Language Markers

Phrases that signal record-custody authority:

- "shall maintain records of"
- "shall establish and maintain a registry"
- "system of records"
- "official record of"
- "authoritative record"
- "record copy" (NARA GSA-defined term)
- "legal custody"
- "record-keeping requirements"

Phrases that do NOT by themselves establish SoR:

- "shall maintain" (without "records")
- "shall retain" (retention is NARA-scoped; independent of custody)
- "shall report" (reporting is downstream)
- "shall be made available" (access, not custody)

## Citation Strength Classification

| Strength | Meaning | Gate behavior |
|---|---|---|
| `explicit` | Citation text quoted verbatim in the app's source, config, docs, or deployed UI | Auto-pass governance |
| `inferred` | Citation reasonably applies given the app's function, but not quoted in-source | Requires human adjudication |
| `inherited` | Citation applies because the app is part of a suite/portfolio covered by the citation | Emit with rationale; human reviews |

## Multi-SoR Per App

A single app can hold SoR designation for multiple record types
under different statutes. Emit one designation record per record
type, not per app. Example:

```json
{
  "app_id": "rms-001",
  "designations": [
    {
      "designation": "system_of_record",
      "record_type": "airman_certification_record",
      "statutory_authorities": ["49 USC §44107", "14 CFR Part 61"],
      "primary_sor_database": "CAIS (ADABAS on z/OS)"
    },
    {
      "designation": "system_of_record",
      "record_type": "aircraft_registration_record",
      "statutory_authorities": ["49 USC §44103"],
      "primary_sor_database": "ar_aircraft_data (SQL Server)"
    }
  ]
}
```

## Privacy Act SORN vs SoR

The Privacy Act of 1974 (5 USC §552a) requires a System of Records
Notice (SORN) for any system containing records retrieved by personal
identifier. A SORN is a *privacy* designation, not a *custody*
designation. An app can:

- Be a SoR without a SORN (e.g., aircraft registration — no personal
  data retrieval pattern).
- Have a SORN without being a SoR (e.g., a downstream replica that
  is retrievable by name).
- Be both (common — e.g., airmen registry).

Record Privacy Act SORN presence separately in a `sorn_citations[]`
field, not in `statutory_authorities[]`.

## FISMA Boundary Distinction

FISMA (44 USC §3541 et seq.) establishes an Authorization to Operate
(ATO) boundary. This is a *security* boundary, not a record-custody
boundary. Modernization crossing a FISMA boundary is expensive
(re-ATO required); modernization crossing a record-custody boundary
is *legally* constrained (record transfer required).

- Record-custody boundary: established by records-management statute.
- FISMA boundary: established by ATO package.
- These often overlap but do not always coincide.

Use `ato-boundary-analyzer` (sibling skill) for FISMA; use this skill
for record custody.

## Downstream Replica Classification

A replica is `authoritative_replica` when:

- Statute or regulation explicitly designates it as authoritative for
  a defined purpose (e.g., a public-facing read-only portal).
- It is legally substitutable for the SoR in that purpose.

A replica is `downstream_replica` when:

- It is operationally populated from the SoR via ETL, feed, or change
  stream.
- It has no statutory recognition as authoritative.
- It is not legally substitutable for the SoR.

## Refresh Mechanism Taxonomy

| Mechanism | Typical cadence | Drift tolerance |
|---|---|---|
| `change_stream` | Near-real-time | Low (seconds-minutes) |
| `nightly_etl` | Daily | Moderate (one business day) |
| `scheduled_feed` | Hourly/daily at fixed time | Moderate |
| `on_demand` | Triggered by event | Varies |
| `manual` | Human-initiated | High (days-weeks) |

Record per replica; drift tolerance determines whether the replica
can legally substitute for the SoR in time-sensitive operations.

## Legal-Custody Implications Checklist

For every app tagged `system_of_record`, enumerate which of these
apply:

- **NARA coordination required:** records must be transferred to
  NARA-approved successor before retirement (44 USC §3301).
- **SORN amendment required:** if Privacy-Act-covered, SORN must
  be amended before system changes per 5 USC §552a(e)(4).
- **Records schedule update required:** NARA-approved retention
  schedule must be updated to reflect new system.
- **Public notice required:** some statutes require Federal Register
  notice before record-system changes.
- **Operational continuity required:** airmen-facing / safety-critical
  record systems cannot have observable service gaps during
  modernization.
- **Data-migration audit required:** record-by-record accounting
  of transferred records, typically with signed attestation.
- **Record-custody transfer document required:** signed instrument
  transferring custody to successor system, retained as part of
  the old system's closed-records file.

## Tier Elevation Logic

When `designation = system_of_record` AND statutory authority exists,
recommend tier elevation:

- Current tier T3 → elevate to T2.
- Current tier T2 → elevate to T1.
- Current tier T1 → maintain; record the basis for T1.

Rationale: a legally-mandated record system cannot experience
observable service gaps or uncontrolled data loss. Risk tiers are
defined by client profile; the elevation recommendation is a
Rationalization input, not an automatic change.

## Emission Pseudocode

```
for each app in catalog:
    citations = read_citations(app)
    matches = filter(citations, client_profile.record_authority_patterns)
    for match in matches:
        if matches_custody_language(match):
            emit_designation(app, system_of_record, match, record_type=infer_record_type(match))
        elif matches_authoritative_replica_language(match):
            emit_designation(app, authoritative_replica, match, ...)
    if no matches:
        emit_designation(app, downstream_replica if has_etl else operational_only)
    for each sor_designation:
        walk_integration_graph_forward(app, record_type) -> emit replica_topology edges
```
