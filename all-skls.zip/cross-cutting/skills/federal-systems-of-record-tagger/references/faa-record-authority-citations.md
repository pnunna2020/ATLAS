# FAA-Specific Record-Authority Citations

Catalog mapping FAA applications to governing statutes and
regulations. Use when the client profile is FAA (default for ATLAS
Challenge portfolio).

## Primary Statutory Framework

### 49 USC Subtitle VII — Aviation Programs

The core federal aviation statute. Subpart III (Safety) establishes
most record authorities.

| Citation | Record authority | ATLAS apps |
|---|---|---|
| `49 USC §44103` | Aircraft registration — FAA Administrator maintains registry | RMS (AR side) |
| `49 USC §44107` | Airmen records — Administrator maintains record of each airman certificate | RMS (CAIS side) |
| `49 USC §44108` | Aircraft registration by documentation | RMS |
| `49 USC §44701` | General authority to prescribe regulations for aviation safety | Enabling for 14 CFR |
| `49 USC §44703` | Airman certificates | Enabling for 14 CFR Part 61 — IACRA, RMS |
| `49 USC §44704` | Type / production / airworthiness certificates | Not in ATLAS scope |
| `49 USC §44709` | Amendments / modifications / suspensions / revocations | AMCS, CPDSS, DMS |

### 14 CFR — Aeronautics and Space

The FAA's regulatory corpus under 49 USC authority.

| Citation | Scope | ATLAS apps |
|---|---|---|
| `14 CFR Part 61` | Certification of pilots, flight instructors, ground instructors | IACRA, RMS |
| `14 CFR Part 63` | Certification of flight crewmembers other than pilots | IACRA, RMS |
| `14 CFR Part 65` | Certification of airmen other than flight crewmembers | IACRA, RMS |
| `14 CFR Part 67` | Medical standards and certification | MedXPress, AMCS, CHAPS, CPDSS, DIWS |
| `14 CFR Part 91` | General operating and flight rules | Not record authority |
| `14 CFR Part 183` | Representatives of the Administrator (designees) | DMS |

## Per-Application Authority Map

### RMS — Registry Management System

**Dual SoR.**

Airman record side:
- Primary statute: `49 USC §44107` (Airmen records).
- Implementing regulation: `14 CFR Part 61` (pilot certification),
  `Part 63`, `Part 65`.
- Cross-reference: `14 CFR Part 67` (medical certification status is
  a required field in the airman record, but CPMS/AMCS hold the
  medical SoR).
- Primary SoR database: CAIS (ADABAS on IBM z/OS).
- Downstream replicas: `aa_airman_data` SQL Server replica;
  AMCS / MedXPress / CHAPS (for medical-cert status field);
  IACRA (during application in-flight).

Aircraft record side:
- Primary statute: `49 USC §44103` (Aircraft registration).
- Cross-reference: `49 USC §44108` (registration by documentation).
- Primary SoR database: `ar_aircraft_data` SQL Server.
- Downstream replicas: external Aircraft Registry Inquiry services,
  NASA ASRS references, FAA public Aircraft Registry query site.

### IACRA — Integrated Airman Certification and Rating Application

**Transactional SoR for in-flight applications; record-of-issuance
authority for Temporary Airman Certificates.**

- Primary statute: `49 USC §44703` (Airman certificates).
- Implementing regulation: `14 CFR Part 61`, `Part 63`, `Part 65`.
- Record types: application-in-progress, signed application,
  Temporary Airman Certificate.
- Primary SoR database: IACRA SQL Server (in-flight applications);
  IACRA's Temporary-Airman-Certificate TIFF pipeline (issuance
  record).
- Downstream replicas: RMS (permanent record post-approval via
  ApplicationTransferToRMS); CAIS Export feed.
- **Legal-record caveat:** Temporary Airman Certificates have legal
  force under 14 CFR Part 61 — the TIFF files are authoritative-copy
  records until superseded by RMS-issued permanent certificates.
  Modernization must preserve TIFF-byte fidelity (see
  `tiff-generator-extractor` and `part-67-letter-wording-
  preservation-tracer`).

### DMS — Designee Management System

**SoR for designee authority.**

- Primary regulation: `14 CFR Part 183` (Representatives of the
  Administrator).
- Implementing authority: `49 USC §44702` (Administrator may
  delegate to persons under Part 183).
- Record types: designation, designee authority scope, designee
  activities, designee termination.
- Primary SoR database: DMS / ODA (SQL Server via SSDT).
- Downstream replicas: IACRA (designee lookup for signature
  workflows); public-facing designee lookup portals.
- **Legal-record caveat:** Designee termination must be recorded
  before the date of revocation for legal effect.

### MedXPress — Airman Medical Examination Intake

**Upstream intake SoR for Form 8500-8 applications pre-AME-exam;
downstream replica for medical certification records.**

- Primary regulation: `14 CFR Part 67` (Medical standards).
- Enabling statute: `49 USC §44703`.
- Record types: airman medical application (Form 8500-8 intake
  state).
- Primary SoR database: MSS Oracle schema (MedXPress side).
- Downstream replicas: AMCS (processing), DIWS (imaging), CHAPS
  (records access).

### AMCS — Aeromedical Certification Subsystem

**SoR for medical certificate issuance / denial / suspension /
revocation decisions.**

- Primary regulation: `14 CFR Part 67`.
- Enabling statute: `49 USC §44703`, `49 USC §44709` (for amendments
  / suspensions / revocations).
- Record types: AME exam, FAA review decision, certificate issuance,
  denial, suspension, revocation.
- Primary SoR database: MSS Oracle schema (AMCS side).
- Downstream replicas: DIWS (imaging of supporting documents); RMS
  (airman record medical-cert-status field update).

### CHAPS — Consolidated Health Aeromedical Processing System

**Authoritative replica for medical records access; not transactional
SoR.**

- Primary regulation: `14 CFR Part 67` (inherited).
- Record types: read-access to medical records for staff.
- Primary SoR database: shared MSS Oracle schema (read side).
- **Designation:** `authoritative_replica` — CHAPS is not the
  write-target for medical records but is designated for staff
  read-access.

### CPDSS — Civil Pilot Drug Surveillance System

**SoR for drug/alcohol testing records.**

- Primary regulation: `14 CFR Part 67` (medical standards bridge);
  `14 CFR Part 120` (drug and alcohol testing of persons holding
  certain airman certificates) — note: Part 120 replaced earlier
  Appendix-I/Appendix-J drug/alcohol testing rules; CPDSS is the
  historical Part 67 Appendix I/J system.
- Enabling statute: `49 USC §45102` (Random drug / alcohol testing).
- Record types: drug test result, alcohol test result, clearance,
  violation.
- Primary SoR database: MSS Oracle schema (CPDSS partitions).

### DIWS — Document Imaging Workflow System

**Record-retention SoR for imaged medical documents.**

- Primary statute: `44 USC §3301 et seq.` (Federal Records Act —
  record-retention obligation).
- Enabling regulation: `14 CFR Part 67` (the underlying record
  type).
- Record types: imaged medical-application documents, supporting
  documents, case notes, workflow history.
- Primary SoR database: MSS Oracle schema (DIWS partitions);
  imaged-document store (Unisys InfoImage / TIFF corpus).
- **Note:** DIWS is the *imaging* SoR, not the transactional-
  decision SoR. AMCS owns the decision record; DIWS owns the
  imaged-document record.

## NARA-Approved Retention Schedules

Record-system modernization triggers NARA coordination for
retention-schedule updates. Known schedules for FAA record types:

| Record type | NARA schedule reference | Retention period |
|---|---|---|
| Airman certification record | (verify with FAA Records Office) | Permanent |
| Aircraft registration record | (verify with FAA Records Office) | Permanent |
| Medical certification record | (verify with FAA Records Office) | Life of airman + N years |
| Designee record | (verify with FAA Records Office) | Permanent |
| Drug / alcohol testing record | (verify with FAA Records Office) | Term-of-service + statute-of-limitations |

Schedule references must be verified with the FAA Records Office;
NARA approval is per-system.

## Citation-Strength Assignment for FAA Apps

| App | Authority | Strength |
|---|---|---|
| RMS airman | 49 USC §44107 | explicit (quoted in RMS documentation) |
| RMS aircraft | 49 USC §44103 | explicit |
| IACRA | 49 USC §44703, 14 CFR Part 61 | explicit |
| DMS | 14 CFR Part 183 | explicit |
| MedXPress | 14 CFR Part 67 | explicit |
| AMCS | 14 CFR Part 67, 49 USC §44709 | explicit |
| CHAPS | 14 CFR Part 67 | inherited (AAM suite) |
| CPDSS | 14 CFR Part 120 / 49 USC §45102 | explicit |
| DIWS | 44 USC §3301 (records retention) | inferred (imaging role) |

## Tier Elevation Summary

| App | Current tier (assumed) | Recommended tier |
|---|---|---|
| RMS | T1 | T1 (maintain; primary SoR x 2) |
| IACRA | T1 | T1 (maintain; issuance authority) |
| DMS | T2 | T1 (designee authority; legal force) |
| MedXPress | T2 | T2 (upstream intake) |
| AMCS | T2 | T1 (certification decisions) |
| CHAPS | T3 | T2 (authoritative replica) |
| CPDSS | T2 | T2 |
| DIWS | T2 | T2 (retention SoR) |

Tier elevation is a Rationalization input — the final tier is
determined by `disposition-recommender` + human governance review.
