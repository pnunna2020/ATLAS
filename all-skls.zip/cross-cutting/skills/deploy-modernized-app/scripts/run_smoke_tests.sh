#!/usr/bin/env bash
#
# Run deployment smoke tests against the staged modernized application.
#
# Smoke tests validate that the deployment is healthy enough to begin traffic
# shifting. They are NOT a substitute for the full P5.1 validation suite —
# they are a pre-flight check after the application is deployed to the target
# environment.
#
# Usage: run_smoke_tests.sh <environment> <base-url>
#   environment: staging | production
#   base-url: URL to the deployed application (e.g., https://app.staging.faa.gov)

set -euo pipefail

if [[ $# -lt 2 ]]; then
    echo "Usage: $0 <environment> <base-url>" >&2
    exit 2
fi

ENVIRONMENT="$1"
BASE_URL="$2"

echo "Running smoke tests against $BASE_URL ($ENVIRONMENT)"

# Core smoke test categories
#
# 1. Liveness — /health responds 200
# 2. Readiness — /ready responds 200
# 3. Critical path — representative API call succeeds
# 4. Auth — OKTA OAuth2 flow returns a valid token
# 5. Dependencies — database, cache, message bus connectivity
# 6. Observability — Datadog traces reaching the backend

# TODO(skill-author): Wire real checks. This stub only hits /health.

FAIL_COUNT=0

check() {
    local name="$1"
    local url="$2"
    local expected_status="${3:-200}"
    local status
    status=$(curl -sS -o /dev/null -w "%{http_code}" "$url" || echo "000")
    if [[ "$status" == "$expected_status" ]]; then
        echo "  PASS: $name ($status)"
    else
        echo "  FAIL: $name ($status, expected $expected_status)"
        FAIL_COUNT=$((FAIL_COUNT + 1))
    fi
}

check "liveness" "$BASE_URL/health"
check "readiness" "$BASE_URL/ready"

# TODO(skill-author): Add critical-path, auth, dependencies, and observability
# checks tuned to the specific application under deployment.

if [[ $FAIL_COUNT -gt 0 ]]; then
    echo "$FAIL_COUNT smoke test(s) failed"
    exit 1
fi

echo "All smoke tests passed"
