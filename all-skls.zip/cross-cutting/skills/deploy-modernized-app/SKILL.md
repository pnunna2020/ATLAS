---
name: deploy-modernized-app
description: >
  Execute blue-green or canary deployment of modernized FAA applications, including smoke tests, Gravitee route updates, and rollback preparation. Use during P6.1. Triggers on deployment, blue-green, canary, production release, or deploy mentions.
agent: sonnet
allowed-tools:
  - Read
  - Write
  - Bash
---

# Modernized Application Deployment
## Workflow
1. Pre-deploy: Verify all P5 validations passed, cATO approved
2. Deploy to staging environment (blue-green or canary based on safety tier)
3. Run smoke tests via `scripts/run_smoke_tests.sh`
4. If smoke tests pass: begin traffic shift via Gravitee
5. Monitor error rates during shift (compose with AIOps monitoring)
6. If errors exceed threshold: automatic rollback
7. If clean: complete traffic shift, mark deployment successful

## Safety Tier Deployment Rules
- T1 (Safety-Critical): Canary with 5% → 25% → 50% → 100% over 14 days
- T2 (Mission Support): Blue-green with 24-hour validation
- T3 (Admin): Blue-green with 4-hour validation

## Gotchas
- **Gravitee route updates are the traffic shift mechanism**: Don't modify DNS.
  Shift traffic by updating Gravitee route weights.
- **Rollback scripts must be PRE-TESTED**: Test the rollback procedure BEFORE
  deploying, not during an incident.
- **Database migrations must be backward-compatible**: If the new app uses a
  new schema, the old app must still be able to read the DB during parallel run.

## Quality Rules
- [ ] All P5 validations (parity, security, performance) passed before deployment is initiated
- [ ] cATO approval is documented and linked in the deployment record
- [ ] Deployment strategy matches safety tier: T1=canary (5/25/50/100% over 14 days), T2=blue-green (24h), T3=blue-green (4h)
- [ ] Rollback scripts are pre-tested in staging BEFORE production deployment begins
- [ ] Smoke tests pass in staging before any traffic shift begins
- [ ] Gravitee route weights are used for traffic shifting — DNS changes are not used
- [ ] Database migrations are backward-compatible — legacy app can still read the DB during parallel run
- [ ] Error rate monitoring is active during traffic shift with automatic rollback threshold configured
- [ ] Deployment record includes timestamps, approvers, traffic shift percentages, and rollback plan

## Common Failure Modes
| Failure Mode | Symptom | Prevention |
|-------------|---------|------------|
| Untested rollback | Rollback attempted during incident and fails; extended outage | Pre-test rollback procedure in staging as part of the deployment checklist |
| Wrong deployment strategy for tier | T1 safety-critical app deployed with blue-green instead of canary; insufficient validation window | Check safety tier in config before selecting deployment strategy; enforce tier-strategy mapping |
| Smoke tests skipped | Traffic shifted to new version that has a critical defect; users impacted immediately | Make smoke test passage a blocking gate before any traffic shift |
| DNS-based traffic shift | Traffic shift bypasses Gravitee; monitoring and rate limiting not applied | Enforce Gravitee route weight changes as the sole traffic shift mechanism |
| Non-backward-compatible DB migration | Rollback fails because legacy app cannot read the new schema; data corruption risk | Validate backward compatibility of all schema changes before deploying; use expand-contract pattern |

## Handoff Summary
When this skill completes, verify:
1. Deployment is complete and traffic is fully shifted to the modernized application
2. Error rates are within acceptable thresholds post-shift
3. Rollback procedure was tested and documented (even if not used)
4. Deployment record is complete with all timestamps and approvals
Then proceed to: `parallel-run-monitor` for ongoing comparison during stabilization, `legacy-decommission` after stabilization period, and gate `G-DP-1` for deployment certification
