---
name: adversarial-review
description: >
  Spawn a fresh-eyes subagent to critique generated code, finding bugs, security issues, and design flaws. Iterates until findings degrade to nitpicks. Use before @commit or @create-pr at P4.3. Triggers on adversarial review, code review, fresh-eyes review, or pre-PR review.
agent: sonnet
allowed-tools:
  - Read
  - Write
  - Bash
  - Grep
---

# Adversarial Code Review
## Purpose
A dedicated subagent reviews generated code with zero context from the
generation session — simulating a human reviewer who sees the code for the
first time.

## Workflow
1. Spawn a review subagent with NO generation context
2. Subagent reads the generated code and module design spec
3. Subagent produces findings: CRITICAL, MAJOR, MINOR, NITPICK
4. If CRITICAL or MAJOR findings exist, fix and re-review
5. Iterate until only MINOR/NITPICK findings remain
6. Log all findings for P7.1 pattern extraction

## Gotchas
- **The reviewer MUST be a separate subagent**: Using the same context that
  generated the code will miss the same blind spots. Fresh context is the point.
- **Don't fix nitpicks**: The goal is shipping working code, not perfect code.
  Stop when findings degrade to style preferences.
- **Security findings are always CRITICAL**: Even if the code "works," a SQL
  injection or XSS vulnerability is a gate failure.

## Quality Rules
- [ ] Review subagent is spawned with zero generation context — completely fresh perspective
- [ ] All CRITICAL and MAJOR findings are resolved before the code proceeds to commit/PR
- [ ] Security findings are always classified as CRITICAL regardless of exploitability assessment
- [ ] Each finding includes: severity (CRITICAL/MAJOR/MINOR/NITPICK), file:line location, and remediation suggestion
- [ ] Review iterates until only MINOR/NITPICK findings remain — MAJOR items are never deferred
- [ ] All findings are logged for P7.1 pattern extraction to improve future generation quality

## Common Failure Modes
| Failure Mode | Symptom | Prevention |
|-------------|---------|------------|
| Same-context review | Reviewer shares generation context; same blind spots produce same misses | Always spawn a separate subagent with no generation session history |
| Nitpick chasing | Review cycles endlessly on style preferences; delivery delayed without quality improvement | Stop iteration when only MINOR/NITPICK findings remain; do not fix nitpicks |
| Security findings downgraded | SQL injection classified as MINOR because "it's an internal API"; vulnerability ships | Enforce rule: all security findings are CRITICAL with no exceptions |
| Findings not logged | Review finds and fixes issues but patterns are not captured; same issues recur in future modules | Log all findings to the P7.1 pattern database before closing the review |

## Handoff Summary
When this skill completes, verify:
1. Zero CRITICAL or MAJOR findings remain in the final review pass
2. All findings are logged with severity, location, and resolution
3. Review subagent was a fresh instance (no shared generation context)
Then proceed to: commit/PR creation, then gate `G-04c` for generation quality review
