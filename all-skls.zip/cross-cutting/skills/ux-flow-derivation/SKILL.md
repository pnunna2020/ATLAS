---
name: ux-flow-derivation
description: >
  Derive user flows from legacy source code by analyzing UI entry points, navigation
  patterns, form submissions, and page transitions. Produces structured flow
  inventories with Mermaid-compatible diagrams. Use during Modernization Extract
  phase (P4.1) after discovery completes. Triggers on UX flow analysis, user flow
  derivation, navigation mapping, page transition analysis, UI flow extraction.
agent: opus
allowed-tools:
  - Read
  - Grep
  - Bash
---

# UX Flow Derivation

## Purpose
Derive every user-facing flow from the legacy source code. A "flow" is a sequence
of user interactions that achieves a goal: logging in, submitting a form, completing
a multi-step wizard, viewing a report, or navigating between functional areas. This
skill produces the foundational UX artifact that all downstream UX skills depend on.

Without this skill, the modernized system's user experience is designed from
assumptions rather than evidence. Legacy applications encode years of user workflow
decisions in their navigation structures, form sequences, and error handling paths.
These flows represent real user needs refined through production usage. Losing them
means forcing users to relearn their work in the modernized system.

This skill is part of the George methodology's UX pipeline, positioned between
Discovery (which inventories the codebase) and UX Page Specification (which
produces per-page specs from the flows derived here).

## Inputs
- Source code discovery artifact (from analyze-application or sdr-area-interface):
  the interface inventory listing all endpoints, controllers, views, and routes
- Extraction artifact (from extraction skill): the module/feature inventory with
  business rules, data models, and functional area groupings
- Source code repository (local path from config): direct access to the codebase
  for tracing navigation patterns that discovery may have summarized

## Outputs
- **Flow inventory**: Complete list of all user flows with unique IDs, entry points,
  step counts, and complexity assessments
- **Flow diagrams**: Mermaid-compatible flowcharts for every flow (text-based, not images)
- **Navigation map**: Page-to-page transition matrix with triggers (link, redirect,
  form action, AJAX, router navigation)
- **Form flow catalog**: Every form submission traced from input through validation
  to processing to response
- **Authentication flow map**: Login, logout, session management, role-gated access
  paths, and authorization failure handling
- **Flow complexity assessment**: Per-flow complexity rating (simple/moderate/complex)
  based on step count, branching factor, state dependencies, and error paths

## Methodology

### Step 1 — Identify All UI Entry Points
Scan the codebase for every point where a user can enter the application:
- **Pages/screens**: HTML files, JSP/JSF pages, .aspx/.cshtml views, .cfm templates,
  PHP templates, React/Vue/Angular route components
- **Endpoints serving HTML**: Controllers that render views (not API-only endpoints)
- **Deep links**: URL patterns that allow direct access to interior pages
- **Bookmarkable states**: URLs with parameters that restore specific application state
- **Public vs. authenticated**: Classify each entry point as requiring authentication
  or publicly accessible

For each entry point, record:
- Entry point ID (EP-NNN)
- URL pattern
- HTTP method(s)
- Controller/handler file and line
- Authentication requirement
- Role restrictions (if any)
- Page title or screen name

Cross-reference against the interface inventory from discovery. Every user-facing
endpoint in the interface inventory must appear here. Any endpoint in the interface
inventory classified as "user-facing" that does not appear is a gap.

### Step 2 — Map Navigation Patterns
Trace how users move between pages by analyzing:

**Static navigation**:
- HTML anchor tags (`<a href="...">`) with internal URLs
- Navigation menus (header, sidebar, footer, breadcrumbs)
- Sitemap files or auto-generated navigation structures

**Programmatic navigation**:
- Server-side redirects (HTTP 301/302, framework redirect methods)
- Form action attributes pointing to processing endpoints
- JavaScript-driven navigation (`window.location`, `history.pushState`, router.navigate)
- Framework-specific routing (React Router `<Link>`, Vue Router `<router-link>`,
  Angular routerLink, ColdFusion `cflocation`)

**Conditional navigation**:
- Role-based redirects (admin goes to dashboard, user goes to profile)
- State-based redirects (unauthenticated users redirected to login)
- Error-based redirects (validation failure returns to form with errors)
- Workflow-based redirects (step completion advances to next step)

For each navigation transition, record:
- Source page (entry point ID)
- Target page (entry point ID)
- Trigger type (link, redirect, form submit, AJAX, programmatic)
- Condition (if conditional: role, state, error, workflow step)
- Source code reference (file:line)

### Step 3 — Trace Form Submission Flows
For every HTML form in the application, trace the complete lifecycle:

1. **Form display**: Which page renders the form, what data pre-populates it,
   what dynamic elements exist (dropdowns loaded from API, conditional fields)
2. **Client-side validation**: JavaScript validation rules, required field checks,
   format validation, cross-field validation
3. **Form submission**: HTTP method, target endpoint, encoding type (URL-encoded,
   multipart, JSON), CSRF protection
4. **Server-side validation**: Input sanitization, business rule validation,
   database constraint checks
5. **Processing**: What happens with valid input (database writes, API calls,
   file operations, email sends, state transitions)
6. **Success response**: Redirect target, success message, updated page state
7. **Error response**: Error display method (inline, flash message, error page),
   form data preservation (are inputs retained on error?), specific error messages

For each form flow, record:
- Form flow ID (FF-NNN)
- Form page (entry point ID)
- Fields inventory (name, type, required, validation rules)
- Submission endpoint (controller, file:line)
- Validation rules (client and server, with source references)
- Success path (target page, state changes)
- Error path (error display, data preservation)
- Data written (tables/columns affected)

### Step 4 — Identify Authentication and Authorization Flows
Map the complete authentication lifecycle:
- **Login flow**: Form location, credential fields, authentication method (DB lookup,
  LDAP, SSO/SAML, OAuth), MFA if present, session creation, post-login redirect
- **Logout flow**: Logout trigger, session destruction, post-logout redirect,
  cleanup actions
- **Session management**: Session timeout behavior, remember-me functionality,
  concurrent session handling
- **Authorization gates**: Which pages/actions require specific roles, how role
  checks are implemented (middleware, annotations, inline checks), what happens
  on authorization failure (redirect, 403, error message)
- **Password management**: Reset flow, change flow, expiration handling

Record each auth flow with its complete step sequence and code references.

### Step 5 — Map Error and Exception Flows
Identify how the application handles errors at the UI level:
- **Global error handlers**: Framework-level error pages (404, 500, custom)
- **Validation errors**: How form validation failures are displayed
- **Business logic errors**: How domain-level failures surface to users
- **Session expiration**: What happens when a session times out mid-operation
- **Network/timeout errors**: Client-side error handling for AJAX failures
- **Concurrency errors**: Optimistic locking failures, stale data detection

For each error flow, record the trigger condition, the user-visible response,
and whether the user can recover (retry, correct input, navigate away).

### Step 6 — Detect Multi-Step Wizard Flows
Identify sequential, multi-step processes:
- **Wizard detection patterns**: Step indicators in URL (step=1, step=2), session
  state tracking step progress, sequential form submissions, progress bar components
- **State management**: How wizard state persists between steps (session, URL params,
  hidden fields, database draft records)
- **Navigation within wizard**: Can users go back? Skip steps? Save and resume later?
- **Completion handling**: What happens at final step (commit transaction, send
  notification, generate document)
- **Abandonment handling**: What happens if user leaves mid-wizard (draft saved?
  session data cleared? timeout behavior?)

### Step 7 — Map API-Driven Flows (SPA Patterns)
For applications using AJAX, SPA frameworks, or WebSocket patterns:
- **AJAX calls**: Identify all XHR/fetch calls, map to backend endpoints, trace
  the UI update that follows each response
- **SPA routing**: Client-side route definitions, lazy-loaded components, route
  guards (authentication checks on the client)
- **WebSocket interactions**: Real-time updates, notification channels, live data
  streams
- **Polling patterns**: Periodic data refresh, long-polling for status updates
- **Optimistic updates**: UI changes before server confirmation, rollback on failure

### Step 8 — Assess Flow Complexity
Rate each flow using these criteria:

| Rating | Step Count | Branching Factor | State Dependencies | Error Paths |
|--------|-----------|------------------|--------------------|-------------|
| Simple | 1-3 steps | Linear (no branches) | Stateless or URL-only | Single error path |
| Moderate | 4-8 steps | 2-3 branch points | Session state | 2-4 error paths |
| Complex | 9+ steps | 4+ branch points | Multi-source state | 5+ error paths, recovery flows |

Complexity drives modernization effort estimation and testing priority.

### Step 9 — Produce Flow Diagrams
Generate a Mermaid flowchart for every flow. Use consistent notation:
- Rectangles for pages/screens
- Diamonds for decision points (role checks, validation, conditional navigation)
- Rounded rectangles for start/end states
- Arrows labeled with trigger type and condition
- Subgraphs for multi-step wizards and authentication-gated sections

Example format:
```mermaid
flowchart TD
    A[Login Page] -->|Submit credentials| B{Valid?}
    B -->|Yes| C{Role?}
    B -->|No| D[Login Page + Error]
    D -->|Retry| A
    C -->|Admin| E[Admin Dashboard]
    C -->|User| F[User Home]
```

## Tech-Stack Dispatch
Before analysis, detect the source technology and adapt discovery patterns:
- **ColdFusion**: .cfm templates, `<cfform>` tags, `<cflocation>` redirects,
  Application.cfc onRequestStart for auth, FW/1 or ColdBox routing
- **Java EE**: JSP/JSF pages, Struts config, Spring MVC @RequestMapping,
  web.xml security constraints, JSTL form tags
- **.NET WebForms**: .aspx pages with code-behind, PostBack model, ViewState,
  web.config authorization sections, Master Pages for layout
- **.NET MVC**: Razor views, attribute routing, [Authorize] decorators,
  _Layout.cshtml for navigation
- **PHP**: Blade/Twig templates, Laravel route middleware, WordPress template
  hierarchy, form handling via $_POST
- **React/Angular/Vue (SPA)**: Route definitions, component hierarchy, state
  management (Redux/Vuex/NgRx), API service layers
- **COBOL/mainframe**: CICS screen definitions (BMS maps), transaction flow,
  COMMAREA for screen-to-screen data passing

## Quality Rules
- [ ] Every user-facing endpoint from the interface inventory is traced to at least one flow
- [ ] No user-facing endpoint is missing from the flow inventory — 100% coverage required
- [ ] Flows have clear start states (entry point) and end states (goal achieved or abandoned)
- [ ] Navigation transitions reference actual source code locations (file:line format)
- [ ] Form flows capture both client-side and server-side validation rules with source references
- [ ] Authentication flows are complete: login, logout, session management, authorization gates
- [ ] Error flows document user-visible behavior, not just server-side exception handling
- [ ] Multi-step wizards document state management, back-navigation, and abandonment handling
- [ ] Flow complexity assessments use the defined rating criteria (not subjective judgment)
- [ ] Mermaid diagrams are syntactically valid and match the textual flow descriptions
- [ ] Every flow has a unique ID (FL-NNN) and descriptive name
- [ ] API-driven flows (AJAX, SPA) are traced end-to-end including UI state updates

## Common Failure Modes

| Failure | Symptom | Prevention |
|---------|---------|------------|
| Missing AJAX flows | Only server-rendered pages found; SPA interactions invisible | Scan JavaScript for fetch/XHR/axios calls; trace to backend endpoints |
| Navigation-only analysis | Forms found but submission flows not traced through processing | Follow every form action to its handler; trace validation + processing + response |
| Auth flows assumed, not traced | Login flow described generically without code evidence | Trace actual authentication code: credential check, session creation, redirect |
| Error paths ignored | Only happy-path flows documented; error handling unknown | For every decision point, trace BOTH outcomes (success and failure) |
| Wizard state not analyzed | Multi-step flows found but state management not documented | Check session, URL params, hidden fields, and DB drafts for wizard state storage |
| Client-side routing missed | SPA client routes not found because only server endpoints analyzed | Scan JavaScript routing configs (React Router, Vue Router, Angular routes) |
| Copy-paste from discovery | Flow inventory is just the endpoint list reformatted, not actual flow analysis | Flows must trace sequences of user actions, not just list individual pages |
| Complexity ratings inflated | Every flow rated "complex" to pad effort estimates | Apply the rating rubric mechanically: step count, branching factor, state, errors |

## Handoff Summary
When this skill completes, verify:
1. **Coverage**: Every user-facing endpoint from discovery appears in at least one flow
2. **Completeness**: Each flow has entry point, steps, decision points, end states, and error paths
3. **Traceability**: All navigation transitions and form actions reference source code (file:line)
4. **Diagrams**: Every flow has a valid Mermaid flowchart that matches the textual description
5. **Complexity**: Every flow has a rated complexity (simple/moderate/complex) using the defined rubric
6. Archive the flow derivation artifact as a versioned artifact in the artifacts directory
7. Proceed to **ux-page-specification** to produce per-page specifications from these flows
8. Feed flow complexity data into effort estimation for Rationalization scoring
