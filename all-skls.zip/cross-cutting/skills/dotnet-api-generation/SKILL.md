---
name: dotnet-api-generation
description: Generate .NET 8 Web API code from module-design + api-spec + data-model artifacts
agent: sonnet
allowed-tools:
  - Read
  - Write
  - Bash
  - Grep
---

# .NET 8 Web API Generation

## Purpose
Generate production-ready .NET 8 (ASP.NET Core) Web API code from the module-design,
api-spec, and data-model artifacts produced by the Design step of the Modernization
factory. This skill produces compilable, convention-following ASP.NET Core 8 solutions
with controllers, application services, EF Core data access, DTOs, configuration, and
xUnit test projects — ready for the Ralph Loop (tdd-generation) to validate through
test-driven iteration.

Invoke this skill after `code-generation-abstract` has produced the project scaffold
and implementation plan, and only when the target architecture blueprint specifies
.NET 8 / ASP.NET Core. It replaces TODO stubs with real C# implementation code,
following the generation order (data layer -> domain layer -> application layer ->
API layer -> tests).

## When to Use
Invoke when the architecture blueprint, technology profile, or design artifacts
specify any of the following:

- `target_language` in {`csharp`, `dotnet`, `C#`}
- `target_framework` in {`aspnetcore8`, `net8`, `ASP.NET Core 8`, `dotnet8`}
- Existing stack is .NET Framework / .NET Core and the disposition is Refactor
- Client profile technology stack lists `.NET 8` as the Web API archetype

Do NOT invoke this skill when the target is Spring Boot, FastAPI, Node.js, or any
non-.NET stack. Verify the tech stack before proceeding.

## Inputs
- `module-design.json` — bounded contexts, aggregates, module boundaries, dependency edges
- `api-spec.json` — OpenAPI 3.x specification with paths, operations, schemas, auth
- `data-model.json` — tables, columns, relationships, constraints, indexes
- Abstract scaffold (project layout, TODO stubs, interfaces) from `code-generation-abstract`
- Extraction artifact — business rules, test scenarios, rule IDs for traceability
- Risk tier (T1, T2, T3) from Rationalization

## Generation Contract

### Project Layout
Generated solution follows clean-architecture layering with four primary projects
plus two test projects. Root folder is the module name in PascalCase:

```
<Module>/
  <Module>.sln
  Directory.Packages.props          # Central NuGet version management
  Directory.Build.props             # Shared MSBuild properties
  global.json                       # .NET SDK pin (8.0.x)
  src/
    <Module>.Api/                   # ASP.NET Core Web API host
      Controllers/                  # REST controllers
      Middleware/                   # Correlation ID, exception handling
      Program.cs                    # Minimal host + DI wiring
      appsettings.json              # Shared config
      appsettings.Development.json
      appsettings.Production.json
      <Module>.Api.csproj
    <Module>.Application/           # Use cases, orchestrators, DTOs
      Abstractions/                 # Interfaces consumed by Api
      Commands/ Queries/ Handlers/  # CQRS-style handlers (MediatR optional)
      Mapping/                      # AutoMapper/Mapster profiles
      <Module>.Application.csproj
    <Module>.Domain/                # Entities, value objects, domain services
      Entities/
      ValueObjects/
      Services/
      Events/
      <Module>.Domain.csproj
    <Module>.Infrastructure/        # EF Core, external integrations
      Persistence/                  # DbContext, Configurations, Migrations
      Repositories/
      Identity/
      <Module>.Infrastructure.csproj
  tests/
    <Module>.UnitTests/             # Fast, in-process tests
      <Module>.UnitTests.csproj
    <Module>.IntegrationTests/      # WebApplicationFactory + Testcontainers
      <Module>.IntegrationTests.csproj
```

### .csproj Conventions
All projects target `net8.0` with nullable and implicit usings enabled:

```xml
<Project Sdk="Microsoft.NET.Sdk.Web">
  <PropertyGroup>
    <TargetFramework>net8.0</TargetFramework>
    <Nullable>enable</Nullable>
    <ImplicitUsings>enable</ImplicitUsings>
    <TreatWarningsAsErrors>true</TreatWarningsAsErrors>
    <GenerateDocumentationFile>true</GenerateDocumentationFile>
  </PropertyGroup>
</Project>
```

NuGet versions are declared centrally in `Directory.Packages.props`, not per-project.
See `references/dotnet-project-structure.md` for the pinned version list.

## Technology Choices

| Concern | Choice | Rationale |
|---|---|---|
| API style | Controllers (`[ApiController]`) | Familiarity, attribute routing, model binding maturity |
| ORM | EF Core 8 with PostgreSQL (Npgsql) or SQL Server | First-party, migrations, LINQ, tracking hygiene |
| Tests | xUnit + FluentAssertions + WebApplicationFactory<Program> | Standard .NET stack, readable assertions |
| Integration tests DB | Testcontainers for .NET (Postgres or MSSQL image) | Real engine, isolated per run, no shared state |
| Logging | Serilog via `UseSerilog()` host builder | Structured JSON, enrichers, sinks |
| OpenAPI | Swashbuckle.AspNetCore | Swagger UI, XML comments, operation filters |
| Health checks | `AddHealthChecks()` + `/health` endpoint | Liveness/readiness split, DB probe |
| Configuration | Strongly-typed `IOptions<T>` | Validation at startup, no magic strings |
| Validation | FluentValidation per request DTO | Composable, testable, async rules |
| Mapping | Mapster or AutoMapper | No hand-written mapping code |
| AuthN/AuthZ | JWT Bearer + policy-based authorization | Stateless, FAA OKTA-compatible |

Details and code patterns live in:

- `references/dotnet-project-structure.md`
- `references/ef-core-patterns.md`
- `references/xunit-patterns.md`
- `references/structured-logging.md`

## Quality Rules
- [ ] Solution builds with `dotnet build` — zero errors, zero warnings (TreatWarningsAsErrors)
- [ ] All controllers have `[ApiController]` and attribute routing (`[Route("api/v1/[controller]")]`)
- [ ] Nullable reference types enabled in every project
- [ ] All dependencies injected via constructor — no service locator, no static access
- [ ] EF Core DbContext registered via `AddDbContextPool` for request-scoped lifetime
- [ ] Migrations are reviewed and committed (`dotnet ef migrations add`)
- [ ] Every controller action has an XML doc comment used by Swashbuckle
- [ ] Request DTOs validated by FluentValidation; model-state filter short-circuits on invalid input
- [ ] `/health` endpoint exposed and registered; readiness probe checks DB connectivity
- [ ] Serilog configured via `UseSerilog()` — no `Console.WriteLine`, no `ILogger<T>` + string concat
- [ ] xUnit test projects use FluentAssertions; tests follow `Given_When_Then` or `Method_State_Expected` naming
- [ ] Integration tests use `WebApplicationFactory<Program>` with Testcontainers for the database
- [ ] Secrets are bound via `IOptions<T>` from environment variables, not appsettings.json literals
- [ ] Swashbuckle security definition exists when the API uses JWT Bearer authentication

## Common Failure Modes

| Failure | Symptom | Prevention |
|---|---|---|
| Implicit DbContext tracking | Stale entities returned; unexpected updates on read paths | Default read queries to `.AsNoTracking()`; only track when writing |
| N+1 from lazy loading | Query count explodes under load; lazy proxies enabled accidentally | Keep lazy loading OFF; use `.Include()` or projections; `.AsSplitQuery()` for large graphs |
| Async void in controllers | Exceptions lost; process crashes | Return `Task<IActionResult>`/`Task<ActionResult<T>>`; never `async void` |
| Service locator anti-pattern | Hidden dependencies; brittle tests; `IServiceProvider.GetService` sprinkled | Constructor injection only; register via `AddScoped/Singleton/Transient` |
| Secrets in appsettings.json | Security scan fails at G-04c; rotation requires a deploy | Bind through `IOptions<T>` + environment variables; use User Secrets for local dev |
| No correlation across logs | Debugging distributed flows requires guessing | Correlation-ID middleware + `LogContext.PushProperty`; enrich every log event |
| Missing CancellationToken | Long operations cannot cancel; graceful shutdown times out | Pipe `CancellationToken` through handlers, EF queries, and HttpClient calls |
| Warnings demoted, not fixed | Build green but codebase rots | `TreatWarningsAsErrors=true` in every csproj; fix the warning, never suppress blindly |
| Missing migration | Runtime `PendingModelChanges` exception | Run `dotnet ef migrations add` after every model change; commit migration files |

## Handoff Summary
When this skill completes, the following artifacts exist and are produced to Git:

1. `<Module>.sln` builds cleanly with `dotnet build -c Release`
2. `src/<Module>.Api/` — controllers matching the api-spec paths, methods, status codes
3. `src/<Module>.Application/` — command/query handlers with business logic
4. `src/<Module>.Domain/` — entities/aggregates/value objects matching data-model.json
5. `src/<Module>.Infrastructure/` — EF Core DbContext, configurations, migrations
6. `tests/<Module>.UnitTests/` — xUnit unit tests, one file per handler/service
7. `tests/<Module>.IntegrationTests/` — WebApplicationFactory-based API tests
8. `Directory.Packages.props` — centralized NuGet versions
9. `Dockerfile` — multi-stage build, non-root runtime, health check
10. `README.md` — build, run, test commands

Hand off to: `tdd-generation` (Ralph Loop for P4.3), `security-scan-review` for SAST,
and gate `G-04c` for generation quality review.

## References
- `references/dotnet-project-structure.md` — solution layout, csproj, NuGet pinning
- `references/ef-core-patterns.md` — DbContext, migrations, tracking, concurrency
- `references/xunit-patterns.md` — Fact/Theory, fixtures, WebApplicationFactory, Testcontainers
- `references/structured-logging.md` — Serilog, enrichers, correlation, masking
