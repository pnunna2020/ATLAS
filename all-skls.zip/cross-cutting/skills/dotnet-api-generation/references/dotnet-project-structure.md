# .NET 8 Project Structure Reference

This reference defines the solution layout, project types, dependency direction, NuGet
package pinning, and MSBuild conventions used by the `dotnet-api-generation` skill.

## Clean Architecture Layering

The generated solution enforces an inward dependency rule: outer layers depend on
inner layers, never the reverse.

```
Api  ->  Application  ->  Domain
            ^                ^
            |                |
     Infrastructure  --------+
```

| Layer | Knows About | Can Reference |
|---|---|---|
| Domain | Nothing else | — |
| Application | Domain only | `<Module>.Domain` |
| Infrastructure | Domain + external tech (EF Core, HTTP clients) | `<Module>.Domain`, `<Module>.Application` (for interface impls) |
| Api | Application + cross-cutting | `<Module>.Application`, `<Module>.Infrastructure` (composition root only) |

The Domain project references no other project and no infrastructure NuGet packages.
It may reference tiny utility packages (e.g. `NodaTime`) but never EF Core, Serilog,
AutoMapper, or ASP.NET Core.

## Solution Structure

```
<Module>/
  <Module>.sln
  global.json                      # { "sdk": { "version": "8.0.100", "rollForward": "latestFeature" } }
  Directory.Build.props            # Shared MSBuild: LangVersion, Nullable, Warnings
  Directory.Packages.props         # Central NuGet versions
  .editorconfig                    # Code style rules
  src/
    <Module>.Api/
    <Module>.Application/
    <Module>.Domain/
    <Module>.Infrastructure/
  tests/
    <Module>.UnitTests/
    <Module>.IntegrationTests/
  Dockerfile
  README.md
```

## Directory.Build.props

Applied to every project in the repository. Keeps csproj files terse.

```xml
<Project>
  <PropertyGroup>
    <TargetFramework>net8.0</TargetFramework>
    <LangVersion>latest</LangVersion>
    <Nullable>enable</Nullable>
    <ImplicitUsings>enable</ImplicitUsings>
    <TreatWarningsAsErrors>true</TreatWarningsAsErrors>
    <AnalysisLevel>latest-recommended</AnalysisLevel>
    <EnforceCodeStyleInBuild>true</EnforceCodeStyleInBuild>
    <GenerateDocumentationFile>true</GenerateDocumentationFile>
    <NoWarn>$(NoWarn);CS1591</NoWarn>
  </PropertyGroup>
</Project>
```

## Directory.Packages.props (Central Package Management)

Central Package Management (CPM) is ON. Individual csproj files declare
`<PackageReference Include="..." />` with no `Version` attribute.

```xml
<Project>
  <PropertyGroup>
    <ManagePackageVersionsCentrally>true</ManagePackageVersionsCentrally>
    <CentralPackageTransitivePinningEnabled>true</CentralPackageTransitivePinningEnabled>
  </PropertyGroup>
  <ItemGroup>
    <!-- ASP.NET Core -->
    <PackageVersion Include="Microsoft.AspNetCore.OpenApi" Version="8.0.11" />
    <PackageVersion Include="Swashbuckle.AspNetCore" Version="6.9.0" />
    <PackageVersion Include="Microsoft.AspNetCore.Authentication.JwtBearer" Version="8.0.11" />

    <!-- EF Core -->
    <PackageVersion Include="Microsoft.EntityFrameworkCore" Version="8.0.11" />
    <PackageVersion Include="Microsoft.EntityFrameworkCore.Design" Version="8.0.11" />
    <PackageVersion Include="Microsoft.EntityFrameworkCore.Relational" Version="8.0.11" />
    <PackageVersion Include="Npgsql.EntityFrameworkCore.PostgreSQL" Version="8.0.10" />
    <PackageVersion Include="Microsoft.EntityFrameworkCore.SqlServer" Version="8.0.11" />

    <!-- Logging -->
    <PackageVersion Include="Serilog.AspNetCore" Version="8.0.3" />
    <PackageVersion Include="Serilog.Enrichers.Environment" Version="3.0.1" />
    <PackageVersion Include="Serilog.Enrichers.Thread" Version="4.0.0" />
    <PackageVersion Include="Serilog.Sinks.Console" Version="6.0.0" />
    <PackageVersion Include="Serilog.Sinks.File" Version="6.0.0" />
    <PackageVersion Include="Serilog.Formatting.Compact" Version="3.0.0" />

    <!-- Validation & Mapping -->
    <PackageVersion Include="FluentValidation.AspNetCore" Version="11.3.0" />
    <PackageVersion Include="Mapster" Version="7.4.0" />
    <PackageVersion Include="Mapster.DependencyInjection" Version="1.0.1" />

    <!-- Test stack -->
    <PackageVersion Include="Microsoft.NET.Test.Sdk" Version="17.11.1" />
    <PackageVersion Include="xunit" Version="2.9.2" />
    <PackageVersion Include="xunit.runner.visualstudio" Version="2.8.2" />
    <PackageVersion Include="FluentAssertions" Version="6.12.2" />
    <PackageVersion Include="Microsoft.AspNetCore.Mvc.Testing" Version="8.0.11" />
    <PackageVersion Include="Testcontainers.PostgreSql" Version="4.0.0" />
    <PackageVersion Include="Testcontainers.MsSql" Version="4.0.0" />
    <PackageVersion Include="NSubstitute" Version="5.3.0" />
    <PackageVersion Include="Bogus" Version="35.6.1" />
  </ItemGroup>
</Project>
```

Use exact versions (not floating). Any bump is a deliberate PR.

## Per-project csproj Patterns

### `<Module>.Domain.csproj`

```xml
<Project Sdk="Microsoft.NET.Sdk">
  <!-- Inherits TargetFramework, Nullable, etc. from Directory.Build.props -->
  <ItemGroup>
    <!-- Domain has no external dependencies -->
  </ItemGroup>
</Project>
```

### `<Module>.Application.csproj`

```xml
<Project Sdk="Microsoft.NET.Sdk">
  <ItemGroup>
    <PackageReference Include="FluentValidation" />
    <PackageReference Include="Mapster" />
    <ProjectReference Include="..\<Module>.Domain\<Module>.Domain.csproj" />
  </ItemGroup>
</Project>
```

### `<Module>.Infrastructure.csproj`

```xml
<Project Sdk="Microsoft.NET.Sdk">
  <ItemGroup>
    <PackageReference Include="Microsoft.EntityFrameworkCore" />
    <PackageReference Include="Microsoft.EntityFrameworkCore.Relational" />
    <PackageReference Include="Npgsql.EntityFrameworkCore.PostgreSQL" />
    <ProjectReference Include="..\<Module>.Application\<Module>.Application.csproj" />
    <ProjectReference Include="..\<Module>.Domain\<Module>.Domain.csproj" />
  </ItemGroup>
</Project>
```

### `<Module>.Api.csproj`

```xml
<Project Sdk="Microsoft.NET.Sdk.Web">
  <ItemGroup>
    <PackageReference Include="Microsoft.AspNetCore.OpenApi" />
    <PackageReference Include="Swashbuckle.AspNetCore" />
    <PackageReference Include="Microsoft.AspNetCore.Authentication.JwtBearer" />
    <PackageReference Include="Serilog.AspNetCore" />
    <PackageReference Include="FluentValidation.AspNetCore" />
    <ProjectReference Include="..\<Module>.Application\<Module>.Application.csproj" />
    <ProjectReference Include="..\<Module>.Infrastructure\<Module>.Infrastructure.csproj" />
  </ItemGroup>
</Project>
```

### Test project csproj

```xml
<Project Sdk="Microsoft.NET.Sdk">
  <PropertyGroup>
    <IsPackable>false</IsPackable>
    <IsTestProject>true</IsTestProject>
  </PropertyGroup>
  <ItemGroup>
    <PackageReference Include="Microsoft.NET.Test.Sdk" />
    <PackageReference Include="xunit" />
    <PackageReference Include="xunit.runner.visualstudio" />
    <PackageReference Include="FluentAssertions" />
    <PackageReference Include="NSubstitute" />
  </ItemGroup>
</Project>
```

Integration tests additionally reference `Microsoft.AspNetCore.Mvc.Testing` and
`Testcontainers.PostgreSql` (or MsSql).

## Program.cs (Minimal Host)

```csharp
var builder = WebApplication.CreateBuilder(args);

builder.Host.UseSerilog((ctx, lc) => lc.ReadFrom.Configuration(ctx.Configuration));

builder.Services
    .AddControllers()
    .AddJsonOptions(o => o.JsonSerializerOptions.PropertyNamingPolicy = JsonNamingPolicy.CamelCase);

builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();
builder.Services.AddHealthChecks().AddDbContextCheck<AppDbContext>();

builder.Services.AddOptions<AuthOptions>()
    .Bind(builder.Configuration.GetSection("Auth"))
    .ValidateDataAnnotations()
    .ValidateOnStart();

builder.Services.AddDbContextPool<AppDbContext>(opts =>
    opts.UseNpgsql(builder.Configuration.GetConnectionString("Default")));

builder.Services.AddApplication();    // extension in Application
builder.Services.AddInfrastructure(); // extension in Infrastructure

var app = builder.Build();

app.UseSerilogRequestLogging();
app.UseMiddleware<CorrelationIdMiddleware>();
app.UseExceptionHandler("/error");
app.UseAuthentication();
app.UseAuthorization();
app.MapControllers();
app.MapHealthChecks("/health");
app.UseSwagger();
app.UseSwaggerUI();

app.Run();

public partial class Program; // exposed for WebApplicationFactory<Program>
```

## global.json

Pin the SDK to avoid surprise upgrades on CI:

```json
{
  "sdk": {
    "version": "8.0.100",
    "rollForward": "latestFeature",
    "allowPrerelease": false
  }
}
```

## .editorconfig Essentials

- `csharp_style_namespace_declarations = file_scoped:error`
- `dotnet_style_readonly_field = true:error`
- `csharp_style_var_when_type_is_apparent = true:suggestion`
- `dotnet_diagnostic.CA2007.severity = none` (ConfigureAwait not required in ASP.NET Core)
- `dotnet_diagnostic.CA1848.severity = warning` (prefer `LoggerMessage` source generator)

## Dockerfile (multi-stage)

```dockerfile
FROM mcr.microsoft.com/dotnet/sdk:8.0 AS build
WORKDIR /src
COPY . .
RUN dotnet restore <Module>.sln
RUN dotnet publish src/<Module>.Api/<Module>.Api.csproj -c Release -o /app/publish --no-restore

FROM mcr.microsoft.com/dotnet/aspnet:8.0 AS runtime
WORKDIR /app
RUN adduser --disabled-password --gecos "" --uid 10001 appuser
USER appuser
COPY --from=build /app/publish .
HEALTHCHECK --interval=30s --timeout=3s CMD curl -f http://localhost:8080/health || exit 1
ENV ASPNETCORE_URLS=http://+:8080
EXPOSE 8080
ENTRYPOINT ["dotnet", "<Module>.Api.dll"]
```
