# Structured Logging Reference (Serilog on ASP.NET Core 8)

Every generated `<Module>.Api` uses Serilog. Logs are JSON by default in non-dev
environments, indexable by Splunk/Datadog/OpenSearch.

## Host Builder Wire-Up

```csharp
var builder = WebApplication.CreateBuilder(args);

builder.Host.UseSerilog((context, services, lc) => lc
    .ReadFrom.Configuration(context.Configuration)
    .ReadFrom.Services(services)
    .Enrich.FromLogContext()
    .Enrich.WithMachineName()
    .Enrich.WithEnvironmentName()
    .Enrich.WithThreadId()
    .Enrich.WithProperty("Application", "<Module>.Api"));
```

`UseSerilog()` replaces the default `ILoggerFactory`, so every `ILogger<T>`
injection receives the Serilog-backed logger. No code changes are needed in
application or domain layers — they keep using `ILogger<T>`.

## appsettings.json Sinks and Overrides

```json
{
  "Serilog": {
    "MinimumLevel": {
      "Default": "Information",
      "Override": {
        "Microsoft.AspNetCore": "Warning",
        "Microsoft.EntityFrameworkCore.Database.Command": "Warning",
        "System.Net.Http.HttpClient": "Warning"
      }
    },
    "WriteTo": [
      {
        "Name": "Console",
        "Args": { "formatter": "Serilog.Formatting.Compact.CompactJsonFormatter, Serilog.Formatting.Compact" }
      },
      {
        "Name": "File",
        "Args": {
          "path": "/var/log/<module>/app-.log",
          "rollingInterval": "Day",
          "retainedFileCountLimit": 14,
          "formatter": "Serilog.Formatting.Compact.CompactJsonFormatter, Serilog.Formatting.Compact"
        }
      }
    ],
    "Enrich": [ "FromLogContext", "WithMachineName", "WithEnvironmentName", "WithThreadId" ],
    "Properties": { "Application": "<Module>.Api" }
  }
}
```

CompactJsonFormatter emits one JSON object per line — easy for Datadog / ELK / Loki
to ingest.

## Enrichers

| Enricher | Package | Adds |
|---|---|---|
| `FromLogContext` | built-in | properties pushed via `LogContext.PushProperty` |
| `WithMachineName` | `Serilog.Enrichers.Environment` | `MachineName` |
| `WithEnvironmentName` | `Serilog.Enrichers.Environment` | `EnvironmentName` (Dev/Staging/Prod) |
| `WithThreadId` | `Serilog.Enrichers.Thread` | `ThreadId` |
| `WithClientIp` / `WithClientAgent` | `Serilog.Enrichers.ClientInfo` | IP + User-Agent from HttpContext |

## Correlation ID Middleware

A correlation ID threads through a request so every log line from a single HTTP
request can be filtered together. Propagate the header to downstream HttpClients
and database calls.

```csharp
public sealed class CorrelationIdMiddleware(RequestDelegate next)
{
    private const string Header = "X-Correlation-Id";

    public async Task InvokeAsync(HttpContext ctx)
    {
        var correlationId = ctx.Request.Headers.TryGetValue(Header, out var v) && !string.IsNullOrWhiteSpace(v)
            ? v.ToString()
            : Guid.NewGuid().ToString("n");

        ctx.Response.Headers[Header] = correlationId;
        ctx.TraceIdentifier = correlationId;

        using (LogContext.PushProperty("CorrelationId", correlationId))
        using (LogContext.PushProperty("RequestPath", ctx.Request.Path))
        {
            await next(ctx);
        }
    }
}
```

Register early in the pipeline, before authentication:

```csharp
app.UseMiddleware<CorrelationIdMiddleware>();
```

## ASP.NET Core Request Logging

Serilog ships a concise one-line-per-request logger. Replace the default ASP.NET
Core request-logging middleware with:

```csharp
app.UseSerilogRequestLogging(opts =>
{
    opts.MessageTemplate = "HTTP {RequestMethod} {RequestPath} responded {StatusCode} in {Elapsed:0.0} ms";
    opts.EnrichDiagnosticContext = (diag, http) =>
    {
        diag.Set("ClientIP", http.Connection.RemoteIpAddress?.ToString());
        diag.Set("UserAgent", http.Request.Headers.UserAgent.ToString());
        diag.Set("UserId", http.User.Identity?.IsAuthenticated == true ? http.User.FindFirst("sub")?.Value : null);
    };
    opts.GetLevel = (http, elapsed, ex) =>
        ex is not null ? LogEventLevel.Error
      : http.Response.StatusCode >= 500 ? LogEventLevel.Error
      : http.Response.StatusCode >= 400 ? LogEventLevel.Warning
      : LogEventLevel.Information;
});
```

## Log Scopes from Application Code

Push ambient properties for the duration of a unit of work. Any log line emitted
from inside the `using` block inherits the properties.

```csharp
using (LogContext.PushProperty("ScheduleId", scheduleId))
using (LogContext.PushProperty("TenantId", tenantId))
{
    _logger.LogInformation("Publishing schedule");
    await _publisher.PublishAsync(schedule, ct);
}
```

Prefer message templates over string interpolation — Serilog captures each
parameter as a structured property:

```csharp
// Good
_logger.LogInformation("Created schedule {ScheduleId} for {FlightNumber}", id, flightNumber);

// Bad: loses structure, prevents search/aggregation
_logger.LogInformation($"Created schedule {id} for {flightNumber}");
```

## Destructuring Policies

When logging a complex object, tell Serilog to destructure with `@`:

```csharp
_logger.LogInformation("Processing command {@Command}", command);
```

To avoid logging a noisy DTO, override destructuring in the bootstrapper:

```csharp
.Destructure.ByTransforming<HttpRequestMessage>(r => new { r.Method, Uri = r.RequestUri?.ToString() })
```

## Sensitive Data Masking

Never log credentials, tokens, SSNs, or PII. Apply masking via destructuring
policies or a central `IDestructuringPolicy`.

```csharp
public sealed class MaskSensitivePolicy : IDestructuringPolicy
{
    private static readonly HashSet<string> Sensitive = new(StringComparer.OrdinalIgnoreCase)
    {
        "Password", "Secret", "Token", "ApiKey", "Authorization", "Ssn", "SocialSecurityNumber", "CreditCard"
    };

    public bool TryDestructure(object value, ILogEventPropertyValueFactory f, out LogEventPropertyValue? result)
    {
        if (value is null) { result = null; return false; }
        var type = value.GetType();
        if (type.IsPrimitive || value is string) { result = null; return false; }

        var props = type.GetProperties()
            .Select(p => new LogEventProperty(
                p.Name,
                Sensitive.Contains(p.Name)
                    ? new ScalarValue("***")
                    : f.CreatePropertyValue(p.GetValue(value), destructureObjects: true)));

        result = new StructureValue(props);
        return true;
    }
}
```

Register via `.Destructure.With<MaskSensitivePolicy>()`.

Also strip secrets from URLs when logging outbound HTTP requests, and never log
raw request/response bodies for auth or payment endpoints.

## Health Check Logging

Health endpoints can be noisy. Silence them at Information level while still
logging failures:

```csharp
"Override": { "Microsoft.AspNetCore.Hosting.Diagnostics": "Warning" }
```

Or use a request-logging filter:

```csharp
opts.GetLevel = (http, elapsed, ex) =>
    http.Request.Path.StartsWithSegments("/health") && ex is null
        ? LogEventLevel.Debug
        : LogEventLevel.Information;
```

## Do / Don't

| Do | Don't |
|---|---|
| Inject `ILogger<T>` | Use static `Log.Logger` inside application code |
| Use message templates with `{Placeholders}` | Build strings with interpolation or `string.Format` |
| Push correlation/tenant via `LogContext` | Pass correlation IDs through every method signature |
| Emit structured JSON in Staging/Prod | Emit plain text that breaks downstream parsers |
| Mask Authorization headers and tokens | Log raw cookies, bearer tokens, or SSNs |
| Route failures at `Error`, 4xx at `Warning` | Log everything at `Information` and rely on filters |
