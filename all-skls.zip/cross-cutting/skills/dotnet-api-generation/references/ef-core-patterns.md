# EF Core 8 Patterns Reference

Patterns used by generated `<Module>.Infrastructure` code. Targets Npgsql (PostgreSQL)
by default; SQL Server patterns are noted where they diverge.

## DbContext Design

Keep DbContexts narrow: one DbContext per bounded context. Shared infrastructure
(audit, outbox) lives in a base class.

```csharp
public sealed class AppDbContext(DbContextOptions<AppDbContext> options) : DbContext(options)
{
    public DbSet<FlightSchedule> FlightSchedules => Set<FlightSchedule>();
    public DbSet<Crew> Crews => Set<Crew>();

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.ApplyConfigurationsFromAssembly(typeof(AppDbContext).Assembly);
        modelBuilder.HasDefaultSchema("flight");
    }

    protected override void ConfigureConventions(ModelConfigurationBuilder configurationBuilder)
    {
        configurationBuilder.Properties<string>().HaveMaxLength(512);
        configurationBuilder.Properties<DateTimeOffset>().HaveColumnType("timestamptz");
    }
}
```

Register via pooling to reduce allocation cost per request:

```csharp
services.AddDbContextPool<AppDbContext>(opts =>
    opts.UseNpgsql(connectionString, npg => npg.EnableRetryOnFailure(maxRetryCount: 3))
        .UseSnakeCaseNamingConvention());
```

## Entity Configuration (Fluent API)

Prefer `IEntityTypeConfiguration<T>` in its own file per entity over data annotations.
This keeps the domain entity free of EF attributes.

```csharp
public sealed class FlightScheduleConfiguration : IEntityTypeConfiguration<FlightSchedule>
{
    public void Configure(EntityTypeBuilder<FlightSchedule> b)
    {
        b.ToTable("flight_schedule");
        b.HasKey(x => x.Id);

        b.Property(x => x.Id).ValueGeneratedNever();
        b.Property(x => x.FlightNumber).HasMaxLength(8).IsRequired();
        b.Property(x => x.RowVersion).IsRowVersion();          // concurrency token

        b.OwnsOne(x => x.Route, r =>
        {
            r.Property(p => p.Origin).HasColumnName("origin").HasMaxLength(4).IsRequired();
            r.Property(p => p.Destination).HasColumnName("destination").HasMaxLength(4).IsRequired();
        });

        b.HasMany(x => x.Legs)
            .WithOne()
            .HasForeignKey(l => l.ScheduleId)
            .OnDelete(DeleteBehavior.Cascade);

        b.HasIndex(x => new { x.FlightNumber, x.DepartureDate }).IsUnique();

        // Soft delete: filter out tombstones globally
        b.HasQueryFilter(x => !x.IsDeleted);
    }
}
```

## Owned Entities vs Value Objects

Use `OwnsOne`/`OwnsMany` for value objects that share a lifetime with the aggregate
root but need their own columns.

```csharp
public sealed record Money(decimal Amount, string Currency);

b.OwnsOne(x => x.Price, p =>
{
    p.Property(m => m.Amount).HasColumnName("price_amount").HasPrecision(18, 2);
    p.Property(m => m.Currency).HasColumnName("price_currency").HasMaxLength(3);
});
```

## Tracking: Read-Heavy vs Write Paths

Default read queries to `AsNoTracking`. Change-tracking is only needed when the
query result will be mutated and saved.

```csharp
// Read path
public Task<List<FlightScheduleDto>> ListAsync(CancellationToken ct) =>
    _db.FlightSchedules
       .AsNoTracking()
       .ProjectToType<FlightScheduleDto>()   // Mapster
       .ToListAsync(ct);

// Write path
public async Task<FlightSchedule?> GetForUpdateAsync(Guid id, CancellationToken ct)
    => await _db.FlightSchedules.FirstOrDefaultAsync(x => x.Id == id, ct);
```

For bulk read of many unrelated entities in one round trip, use
`AsNoTrackingWithIdentityResolution`.

## Include vs Projection vs AsSplitQuery

- Small, single-level children: `.Include(x => x.Legs)`.
- Multi-level graph that causes cartesian explosion: `.AsSplitQuery()` so EF emits
  multiple SQL statements.
- API response shape: project directly with `Select(x => new Dto { ... })` or
  Mapster's `ProjectToType<T>()`. Projections avoid loading unused columns.

```csharp
await _db.FlightSchedules
    .AsNoTracking()
    .Include(x => x.Legs)
    .Include(x => x.Crew)
        .ThenInclude(c => c.Members)
    .AsSplitQuery()
    .FirstOrDefaultAsync(x => x.Id == id, ct);
```

## Migrations

Migrations live in `<Module>.Infrastructure/Persistence/Migrations`. They are source
code and are committed to Git.

```
dotnet ef migrations add <Name> \
  --project src/<Module>.Infrastructure \
  --startup-project src/<Module>.Api \
  --output-dir Persistence/Migrations

dotnet ef database update \
  --project src/<Module>.Infrastructure \
  --startup-project src/<Module>.Api
```

Rules:

- One migration per model change. No "bigbang" migrations.
- Manually review generated SQL; EF can generate destructive DDL (e.g. drop column
  instead of rename). Edit the migration code or add a custom `MigrationOperation`.
- Seed reference data with `HasData()` inside configurations; treat changes as new
  migrations, not hand-edits to old ones.
- Never hand-edit an already-applied migration. Add a new one instead.

## Transactions

EF opens an implicit transaction around a single `SaveChangesAsync`. Wrap multiple
operations explicitly only when you need cross-aggregate atomicity:

```csharp
await using var tx = await _db.Database.BeginTransactionAsync(ct);
try
{
    _db.FlightSchedules.Add(schedule);
    _db.Outbox.Add(new OutboxMessage(nameof(ScheduleCreated), payload));
    await _db.SaveChangesAsync(ct);
    await tx.CommitAsync(ct);
}
catch
{
    await tx.RollbackAsync(ct);
    throw;
}
```

For read-committed snapshot semantics with retries, combine with
`EnableRetryOnFailure` and an `IExecutionStrategy`:

```csharp
var strategy = _db.Database.CreateExecutionStrategy();
await strategy.ExecuteAsync(async () =>
{
    await using var tx = await _db.Database.BeginTransactionAsync(ct);
    // ...
});
```

## Soft Delete

A global query filter (see configuration above) removes tombstones from normal
queries. To include them in admin tools, call `.IgnoreQueryFilters()`.

```csharp
var all = await _db.FlightSchedules.IgnoreQueryFilters().ToListAsync(ct);
```

Mark rows soft-deleted in a SaveChanges interceptor rather than per call site:

```csharp
public sealed class SoftDeleteInterceptor : SaveChangesInterceptor
{
    public override ValueTask<InterceptionResult<int>> SavingChangesAsync(
        DbContextEventData e, InterceptionResult<int> result, CancellationToken ct = default)
    {
        foreach (var entry in e.Context!.ChangeTracker.Entries<ISoftDeletable>())
        {
            if (entry.State == EntityState.Deleted)
            {
                entry.State = EntityState.Modified;
                entry.Entity.IsDeleted = true;
                entry.Entity.DeletedAtUtc = DateTimeOffset.UtcNow;
            }
        }
        return base.SavingChangesAsync(e, result, ct);
    }
}
```

Register via `opts.AddInterceptors(new SoftDeleteInterceptor())`.

## Concurrency Tokens

Declare a `[Timestamp]` byte[] column (SQL Server `rowversion`) or use `xmin` for
PostgreSQL:

```csharp
// PostgreSQL
b.UseXminAsConcurrencyToken();

// SQL Server
b.Property(x => x.RowVersion).IsRowVersion();
```

Handle `DbUpdateConcurrencyException` in the application layer, compare current
database state, and surface a 409 Conflict to callers.
