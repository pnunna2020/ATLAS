# xUnit Test Patterns Reference

Standard for `<Module>.UnitTests` and `<Module>.IntegrationTests`. Uses xUnit +
FluentAssertions + NSubstitute + Testcontainers.

## Test Naming

All test method names follow `MethodOrScenario_Condition_ExpectedResult` or the
Given/When/Then variant:

- `CreateFlight_WhenOriginIsInvalid_ReturnsValidationError`
- `GivenValidRequest_WhenPostFlight_ThenReturns201`
- `ListFlights_WithNoFilter_ReturnsAllActive`

Class names end with `Tests` and match the system under test:

- `FlightScheduleServiceTests`
- `FlightsControllerIntegrationTests`

## Fact vs Theory

Use `[Fact]` for a single scenario. Use `[Theory]` with `[InlineData]` or
`[MemberData]` for parameterized cases.

```csharp
public sealed class FlightNumberValidatorTests
{
    [Theory]
    [InlineData("AA1",   true)]
    [InlineData("BA9999", true)]
    [InlineData("",       false)]
    [InlineData(null,     false)]
    [InlineData("12345",  false)]
    public void IsValid_ReturnsExpected(string? input, bool expected)
    {
        var sut = new FlightNumberValidator();

        var actual = sut.IsValid(input);

        actual.Should().Be(expected);
    }
}
```

For larger datasets or when sharing cases across tests:

```csharp
public static IEnumerable<object?[]> InvalidRoutes =>
    new[]
    {
        new object?[] { "JFK", "JFK", "origin equals destination" },
        new object?[] { "",    "LAX", "missing origin" },
        new object?[] { "JFK", "",    "missing destination" },
    };

[Theory]
[MemberData(nameof(InvalidRoutes))]
public void Create_Rejects_InvalidRoutes(string origin, string destination, string reason)
{
    var act = () => Route.Create(origin, destination);
    act.Should().Throw<DomainException>().WithMessage("*" + reason + "*");
}
```

## Arrange / Act / Assert

Every test has three sections separated by blank lines. Avoid a single-line test
because it hides intent.

```csharp
[Fact]
public async Task Handle_AddsScheduleAndReturnsId()
{
    // Arrange
    var repo = Substitute.For<IFlightScheduleRepository>();
    var handler = new CreateScheduleHandler(repo, NullLogger<CreateScheduleHandler>.Instance);
    var cmd = new CreateScheduleCommand("AA100", "JFK", "LAX", DateOnly.FromDateTime(DateTime.UtcNow));

    // Act
    var result = await handler.Handle(cmd, CancellationToken.None);

    // Assert
    result.Should().NotBeEmpty();
    await repo.Received(1).AddAsync(Arg.Is<FlightSchedule>(s => s.FlightNumber == "AA100"), Arg.Any<CancellationToken>());
}
```

## FluentAssertions Style

Prefer domain-specific matchers. They produce readable failure messages.

```csharp
response.StatusCode.Should().Be(HttpStatusCode.Created);
body.Items.Should().HaveCount(3).And.OnlyContain(x => x.IsActive);
action.Should().ThrowAsync<ValidationException>().WithMessage("*Origin*");
schedule.Should().BeEquivalentTo(expected, opts => opts.Excluding(s => s.RowVersion));
```

Avoid chained `Assert.True(x == y)`; it hides the diff.

## Fixtures

xUnit creates a new test class instance per test method. For expensive, shared
setup, use a class fixture.

```csharp
public sealed class DatabaseFixture : IAsyncLifetime
{
    public PostgreSqlContainer Container { get; } = new PostgreSqlBuilder()
        .WithImage("postgres:16-alpine")
        .WithDatabase("tests")
        .Build();

    public string ConnectionString => Container.GetConnectionString();

    public async Task InitializeAsync() => await Container.StartAsync();
    public async Task DisposeAsync()    => await Container.DisposeAsync();
}

[CollectionDefinition("Database")]
public sealed class DatabaseCollection : ICollectionFixture<DatabaseFixture> { }

[Collection("Database")]
public sealed class FlightRepositoryTests(DatabaseFixture db)
{
    [Fact]
    public async Task Save_And_Load_RoundTrips()
    {
        await using var ctx = CreateContext(db.ConnectionString);
        // ...
    }
}
```

Collection fixtures reuse the container across every test class in the collection,
keeping the Docker cold-start cost to once per run.

## Integration Tests via WebApplicationFactory

`WebApplicationFactory<Program>` boots the real Program.cs, then lets you override
services for the test host.

```csharp
public sealed class ApiFactory(DatabaseFixture db) : WebApplicationFactory<Program>
{
    protected override void ConfigureWebHost(IWebHostBuilder builder)
    {
        builder.ConfigureServices(services =>
        {
            // Remove production DbContext registration
            services.RemoveAll<DbContextOptions<AppDbContext>>();
            services.AddDbContextPool<AppDbContext>(opts =>
                opts.UseNpgsql(db.ConnectionString));

            // Optional: stub external HTTP clients
            services.RemoveAll<IExternalFlightApi>();
            services.AddSingleton(Substitute.For<IExternalFlightApi>());
        });

        builder.UseEnvironment("Testing");
    }
}
```

Tests then use `factory.CreateClient()`:

```csharp
[Collection("Database")]
public sealed class FlightsEndpointTests(DatabaseFixture db)
{
    [Fact]
    public async Task Post_CreatesSchedule_Returns201_WithLocationHeader()
    {
        await using var factory = new ApiFactory(db);
        var client = factory.CreateClient();

        var response = await client.PostAsJsonAsync("/api/v1/flights",
            new { flightNumber = "AA100", origin = "JFK", destination = "LAX" });

        response.StatusCode.Should().Be(HttpStatusCode.Created);
        response.Headers.Location.Should().NotBeNull();
    }
}
```

The `public partial class Program;` line at the bottom of `Program.cs` makes
`Program` visible as a generic type argument to `WebApplicationFactory<Program>`.

## Testcontainers

Never connect to a shared dev database. Use Testcontainers to spin up a fresh
container per test run.

| Engine | Package | Builder |
|---|---|---|
| PostgreSQL | `Testcontainers.PostgreSql` | `PostgreSqlBuilder()` |
| SQL Server | `Testcontainers.MsSql` | `MsSqlBuilder()` |

Respect test isolation: reset the database between tests using Respawn or by
wrapping each test in a transaction that rolls back. For WebApplicationFactory-
driven tests, Respawn is the simpler option:

```csharp
private static readonly Respawner Respawner = await Respawner.CreateAsync(conn,
    new RespawnerOptions { DbAdapter = DbAdapter.Postgres, SchemasToInclude = new[] { "public" } });

public async Task ResetAsync() => await Respawner.ResetAsync(_db.ConnectionString);
```

## Cancellation and Async

All test methods that call `async` code should be `async Task`, not `async void`.
Pipe a real `CancellationToken` or `TestContext.Current.CancellationToken` through
to exercise cancellation paths.

## What NOT to Test

- Framework behavior (model binding, routing) — covered by ASP.NET Core's own tests
- EF Core internals — test your DbContext configuration by round-tripping through
  a real database, not by asserting on expression trees
- Third-party library wiring — assert on outputs, not method-call counts against
  stable third-party APIs
