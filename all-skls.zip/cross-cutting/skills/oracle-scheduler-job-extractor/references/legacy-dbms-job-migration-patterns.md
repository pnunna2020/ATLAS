# Legacy `DBMS_JOB` Migration Patterns

Coverage for the deprecated-but-still-functional `DBMS_JOB` API
(Oracle 10g and earlier; still compiles in 19c/21c). ATLAS AAM apps
occasionally retain `DBMS_JOB` calls in legacy migration scripts —
extract and flag them for migration to `DBMS_SCHEDULER`.

## DBMS_JOB.SUBMIT

Schedules a one-shot or recurring PL/SQL block.

```
DECLARE
    l_job_id NUMBER;
BEGIN
    DBMS_JOB.SUBMIT(
        job       => l_job_id,
        what      => 'BEGIN my_proc; END;',
        next_date => TRUNC(SYSDATE + 1) + 2/24,        -- tomorrow at 02:00
        interval  => 'TRUNC(SYSDATE + 1) + 2/24',      -- every day at 02:00
        no_parse  => FALSE
    );
    COMMIT;
END;
```

Key differences from `DBMS_SCHEDULER`:
- `job_id` is numeric, auto-assigned — NOT a named job. Consequence:
  a re-run of the `SUBMIT` call produces a different job_id, making
  idempotent deployment impossible.
- `interval` is a raw PL/SQL expression — must parse + evaluate to
  determine recurrence semantics. Standard patterns:

| Interval expression | Semantics |
|---|---|
| `SYSDATE + 1/24` | hourly (every 60 min from last run) |
| `SYSDATE + 1` | daily (24h from last run) |
| `TRUNC(SYSDATE + 1)` | daily at midnight |
| `TRUNC(SYSDATE + 1) + 2/24` | daily at 02:00 |
| `NEXT_DAY(TRUNC(SYSDATE), 'MONDAY') + 6/24` | weekly Monday 06:00 |
| `LAST_DAY(ADD_MONTHS(SYSDATE, 1))` | last day of next month |
| `NULL` | one-shot (remove job after run) |
| `''` | treated as NULL in some versions |

- No named schedules, programs, chains, or job classes.
- No `SET_ATTRIBUTE`; use `DBMS_JOB.CHANGE` / `.WHAT` / `.NEXT_DATE` /
  `.INTERVAL` instead.
- No arguments bound by name; positional via string concatenation in
  the `what` block.
- No explicit enabled/disabled — jobs are either submitted or
  removed.

## DBMS_JOB.REMOVE

```
DBMS_JOB.REMOVE(l_job_id);
COMMIT;
```

Requires the numeric job_id — usually stored in a lookup table or
queried via `SELECT job FROM user_jobs WHERE what LIKE '%my_proc%'`.

## DBMS_JOB.CHANGE

```
DBMS_JOB.CHANGE(
    job       => l_job_id,
    what      => NULL,  -- keep current
    next_date => TRUNC(SYSDATE + 1) + 3/24,
    interval  => 'TRUNC(SYSDATE + 1) + 3/24'
);
```

Partial update — passing NULL keeps the current value.

## Migration to DBMS_SCHEDULER — One-to-One Mapping

Most `DBMS_JOB` submissions map cleanly to `DBMS_SCHEDULER.CREATE_JOB`:

| DBMS_JOB field | DBMS_SCHEDULER equivalent |
|---|---|
| `job` (numeric) | `job_name` (string; assign a stable name during migration) |
| `what` | `job_type => 'PLSQL_BLOCK'`, `job_action => <what>` |
| `next_date` | `start_date` |
| `interval` | `repeat_interval` — **requires translation** from PL/SQL expression to `FREQ=...` grammar |

### Interval translation cases that lose fidelity

- `SYSDATE + 1/24` — runs every 60 minutes from last completion,
  NOT every hour on the hour. Closest `DBMS_SCHEDULER` equivalent
  is `FREQ=HOURLY` but semantics differ: DBMS_SCHEDULER fires on
  `start_date + INTERVAL`, not `last_run_completion + INTERVAL`.
  Emit finding: "interval semantics changed from last-run-relative
  to absolute schedule".
- Expressions with side effects (e.g., calling a function in the
  interval expression) — DBMS_SCHEDULER has no equivalent; the
  function must be lifted into a chain rule.
- `NEXT_DAY(TRUNC(SYSDATE), 'MONDAY') + 6/24` — translatable to
  `FREQ=WEEKLY;BYDAY=MON;BYHOUR=6`.

## External Trigger Detection

Oracle jobs scheduled via `DBMS_SCHEDULER` can be fired externally
by invoking `DBMS_SCHEDULER.RUN_JOB('name')`. The caller is the
hidden dependency.

### Detection targets

1. **Control-M JIL files (`*.jil`, `*.ctm`)** — grep for
   `RUN_JOB` or `sqlplus` blocks calling PL/SQL. Pattern:

   ```
   JOB:NIGHTLY_DIWS_REFRESH
   APPL: MSS
   SUB_APPLICATION: DIWS
   CMDLINE: sqlplus -s mss/secret@prod @-<<EOF
     EXEC DBMS_SCHEDULER.RUN_JOB('DIWS.NIGHTLY_REFRESH');
   EOF
   ```

2. **Autosys definitions** — similar; `command:` attribute on a
   `JOB_TYPE: c` (command) entry.

3. **Jenkins pipelines** — `sh` or `powershell` blocks invoking
   `sqlplus` or `sqlcl` with `EXEC DBMS_SCHEDULER.RUN_JOB`.
   Example:

   ```
   stage('Nightly MSS refresh') {
       steps {
           sh '''
           echo "EXEC DBMS_SCHEDULER.RUN_JOB('MSS.NIGHTLY_REFRESH');" | \\
               sqlplus -s ${DB_USER}/${DB_PASSWORD}@${DB_TNS}
           '''
       }
   }
   ```

4. **Cron files** — `/etc/cron.d/*`, user `crontab`. Similar
   `sqlplus` invocation pattern.

5. **Application code** — a `.cs` / `.java` / `.py` file that
   opens a connection and calls `DBMS_SCHEDULER.RUN_JOB`. Grep
   source files for the literal string.

6. **PL/SQL packages called from outside** — a package procedure
   whose only purpose is to invoke `RUN_JOB`, called from
   Jenkins/Control-M. Detect via the package's usage — if the
   only caller is external, the job is externally triggered.

### Emission format

One `oracle-external-trigger-findings.json` entry per external
trigger:

```json
{
  "job_name": "MSS.NIGHTLY_REFRESH",
  "trigger_type": "control-m",
  "trigger_location": "ops-repo:control-m/mss.jil:42",
  "trigger_owner_repo": "ATLAS-CHALLENGE/MSS-OPS",
  "severity": "P0",
  "modernization_note": "Must migrate Control-M + Oracle scheduler jointly"
}
```

## Modernization Target Options

The target scheduler must handle: named jobs, calendar schedules,
step chains with conditional flow, resource management, and
external invocation.

| Target | Strengths | Weaknesses |
|---|---|---|
| **Airflow** | Rich DAG model with dependencies; native conditional branching; Python operators | Requires Airflow infrastructure (scheduler + workers + meta DB); steep learning curve for Oracle-only teams |
| **Kubernetes CronJobs** | Native K8s; declarative; good for simple periodic jobs | No chain / dependency concept; one job per pod; logging via K8s only |
| **AWS EventBridge Scheduler** | Managed; cron and rate expressions; integrates with Lambda/ECS/SQS | Cloud-only; EventBridge is single-step (use Step Functions for chains) |
| **AWS Step Functions** | Strong chain/state-machine model; visual editor; integrates with Lambda/Fargate | Cloud-only; JSON state-language learning curve; expensive at high throughput |
| **Celery Beat** | Python-native; periodic tasks; integrates with Celery workers | Single-leader scheduler (SPOF); no chain model (use Celery chord/group) |
| **Dagster** | Assets-first model; strong lineage; Python | Newer; smaller ecosystem than Airflow |
| **Temporal** | Durable workflows; strong failure semantics; chain-native | Different programming model; migration is a rewrite, not a translation |

### Migration order of operations

1. Extract full scheduler inventory (this skill's output).
2. Separate externally-triggered jobs from internally-scheduled
   jobs.
3. For internally-scheduled jobs, translate `repeat_interval` to
   target cron/DAG schedule. Flag non-translatable expressions
   (BYSETPOS, last-run-relative, function-call intervals).
4. For chains, re-author as target DAG / state machine.
5. For externally-triggered jobs, migrate trigger source +
   in-db job together.
6. For job classes with RAC service affinity or resource groups,
   emit modernization-decision findings — target schedulers
   rarely have equivalents.
7. Validate: run parity tests against known inputs, compare
   outputs row-by-row, confirm no silent drift.
