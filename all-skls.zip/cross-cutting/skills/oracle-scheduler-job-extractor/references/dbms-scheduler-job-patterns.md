# DBMS_SCHEDULER Job Patterns

Coverage for modern Oracle Scheduler (10g+). Every call takes named
arguments — positional calls are legal but rare. The extractor must
parse named-argument form and also handle positional fallbacks.

## CREATE_JOB

Primary surface; six forms distinguished by `job_type`.

```
DBMS_SCHEDULER.CREATE_JOB(
    job_name            => 'schema.my_job',
    job_type            => 'PLSQL_BLOCK',         -- or STORED_PROCEDURE, EXECUTABLE, CHAIN, PROGRAM
    job_action          => 'BEGIN my_proc(); END;',
    number_of_arguments => 0,
    start_date          => TO_TIMESTAMP_TZ('01-JAN-2024 02:00:00 AMERICA/NEW_YORK', 'DD-MON-YYYY HH24:MI:SS TZR'),
    repeat_interval     => 'FREQ=DAILY;BYHOUR=2;BYMINUTE=0',
    end_date            => NULL,
    job_class           => 'DEFAULT_JOB_CLASS',
    enabled             => TRUE,
    auto_drop           => FALSE,
    comments            => 'Nightly data mart refresh'
);
```

### job_type values

| Value | Action semantics |
|---|---|
| `PLSQL_BLOCK` | `job_action` is a raw PL/SQL block wrapped in BEGIN/END |
| `STORED_PROCEDURE` | `job_action` is a schema-qualified procedure name |
| `EXECUTABLE` | `job_action` is an OS binary path — requires ORACLE_SCHED external agent; security-sensitive |
| `CHAIN` | `job_action` is a chain name; chain must be defined separately |
| `PROGRAM` | `job_action` is a program name; program must be defined separately |

### repeat_interval grammar

Oracle-specific calendaring. Key tokens:

- `FREQ` — YEARLY | MONTHLY | WEEKLY | DAILY | HOURLY | MINUTELY | SECONDLY
- `INTERVAL` — positive integer, step within FREQ
- `BYMONTH` — 1-12 (or JAN, FEB, ...)
- `BYMONTHDAY` — 1 to 31 (negative from end: -1 = last)
- `BYDAY` — MON, TUE, WED, THU, FRI, SAT, SUN (with optional
  ordinal prefix: `1MON` = first Monday, `-1FRI` = last Friday)
- `BYHOUR` — 0-23
- `BYMINUTE` — 0-59
- `BYSECOND` — 0-59
- `BYSETPOS` — which occurrence within a period
  (e.g., `BYDAY=MON,TUE,WED,THU,FRI;BYSETPOS=-1` = last weekday of period)

Examples:

```
FREQ=DAILY;BYHOUR=2;BYMINUTE=0                      -- every day at 02:00
FREQ=WEEKLY;BYDAY=MON;BYHOUR=6                       -- every Monday at 06:00
FREQ=MONTHLY;BYMONTHDAY=1                            -- 1st of every month
FREQ=MONTHLY;BYDAY=1MON                              -- first Monday of each month
FREQ=YEARLY;BYMONTH=1;BYMONTHDAY=1                   -- Jan 1st every year
FREQ=MONTHLY;BYDAY=MON,TUE,WED,THU,FRI;BYSETPOS=-1   -- last weekday of each month
```

### Cron translation

Some intervals translate cleanly to cron; others do not. Cases
that don't round-trip:
- `BYSETPOS` — standard cron has no "nth occurrence" operator
- `BYDAY=1MON` — cron has `0 0 * * 1#1` on some implementations
  (GNU), but not POSIX
- Timestamps with time zones — cron is timezone-naive (depends on
  system TZ)
- `INTERVAL > 1` — cron's step operator `*/n` only works from the
  period start, not from an arbitrary start date

Emit cron-equivalent as a separate `cron_approximation` field; never
replace the original `repeat_interval`.

## CREATE_PROGRAM

Reusable units — multiple jobs can reference one program.

```
DBMS_SCHEDULER.CREATE_PROGRAM(
    program_name        => 'schema.my_program',
    program_type        => 'PLSQL_BLOCK',         -- or STORED_PROCEDURE, EXECUTABLE
    program_action      => 'BEGIN my_proc(:1); END;',
    number_of_arguments => 1,
    enabled             => TRUE,
    comments            => 'Parameterized data refresh'
);

-- Arguments bound separately
DBMS_SCHEDULER.DEFINE_PROGRAM_ARGUMENT(
    program_name      => 'schema.my_program',
    argument_position => 1,
    argument_name     => 'target_schema',
    argument_type     => 'VARCHAR2',
    default_value     => 'MSS'
);
```

## CREATE_SCHEDULE

Named schedules are reusable across jobs.

```
DBMS_SCHEDULER.CREATE_SCHEDULE(
    schedule_name   => 'schema.nightly_2am',
    start_date      => TO_TIMESTAMP_TZ('01-JAN-2024 02:00:00 AMERICA/NEW_YORK', 'DD-MON-YYYY HH24:MI:SS TZR'),
    repeat_interval => 'FREQ=DAILY;BYHOUR=2;BYMINUTE=0',
    end_date        => NULL,
    comments        => 'Shared nightly 2am schedule'
);
```

When `CREATE_JOB` uses `schedule_name` instead of `repeat_interval`,
the named schedule is the source of truth. Must resolve the reference.

## CREATE_CHAIN

Chains encode multi-step workflows with conditional flow.

```
-- Define the chain
DBMS_SCHEDULER.CREATE_CHAIN(
    chain_name => 'schema.nightly_pipeline',
    comments   => 'Data mart refresh pipeline'
);

-- Add steps
DBMS_SCHEDULER.DEFINE_CHAIN_STEP(
    chain_name   => 'schema.nightly_pipeline',
    step_name    => 'LOAD_STAGING',
    program_name => 'schema.load_staging_prog'
);
DBMS_SCHEDULER.DEFINE_CHAIN_STEP(
    chain_name   => 'schema.nightly_pipeline',
    step_name    => 'VALIDATE',
    program_name => 'schema.validate_prog'
);
DBMS_SCHEDULER.DEFINE_CHAIN_STEP(
    chain_name   => 'schema.nightly_pipeline',
    step_name    => 'MERGE_TO_MART',
    program_name => 'schema.merge_prog'
);

-- Define flow rules
DBMS_SCHEDULER.DEFINE_CHAIN_RULE(
    chain_name => 'schema.nightly_pipeline',
    condition  => 'TRUE',
    action     => 'START LOAD_STAGING'
);
DBMS_SCHEDULER.DEFINE_CHAIN_RULE(
    chain_name => 'schema.nightly_pipeline',
    condition  => 'LOAD_STAGING SUCCEEDED',
    action     => 'START VALIDATE'
);
DBMS_SCHEDULER.DEFINE_CHAIN_RULE(
    chain_name => 'schema.nightly_pipeline',
    condition  => 'VALIDATE SUCCEEDED',
    action     => 'START MERGE_TO_MART'
);
DBMS_SCHEDULER.DEFINE_CHAIN_RULE(
    chain_name => 'schema.nightly_pipeline',
    condition  => 'LOAD_STAGING FAILED OR VALIDATE FAILED',
    action     => 'END'
);

-- Enable
DBMS_SCHEDULER.ENABLE('schema.nightly_pipeline');
```

Rules use step outcome predicates: `SUCCEEDED`, `FAILED`,
`COMPLETED` (either), `STOPPED`, `PAUSED`. Actions are `START <step>`,
`END`, `STOP`, `PAUSE`.

The extractor must emit the full (step + rule) graph — not just a
list of steps.

## CREATE_JOB_CLASS

Job classes group jobs for resource management.

```
DBMS_SCHEDULER.CREATE_JOB_CLASS(
    job_class_name          => 'BATCH_REPORTS',
    resource_consumer_group => 'LOW_GROUP',
    service                 => 'BATCH_SVC',
    logging_level           => DBMS_SCHEDULER.LOGGING_FULL,
    log_history             => 30,
    comments                => 'Low-priority batch report jobs'
);
```

Fields:
- `resource_consumer_group` — ties to DBMS_RESOURCE_MANAGER plans
- `service` — Oracle RAC service affinity (which node runs the job)
- `logging_level` — `LOGGING_OFF | LOGGING_RUNS | LOGGING_FAILED_RUNS | LOGGING_FULL`
- `log_history` — days of run history retained

Modern scheduler targets rarely have RAC service affinity or
DBMS_RESOURCE_MANAGER groups — emit finding on every non-default
job class.

## Argument Binding

`DEFINE_PROGRAM_ARGUMENT` and `SET_JOB_ARGUMENT_VALUE` bind values
to program arguments.

```
DBMS_SCHEDULER.DEFINE_PROGRAM_ARGUMENT(
    program_name      => 'schema.my_program',
    argument_position => 1,
    argument_name     => 'target_schema',
    argument_type     => 'VARCHAR2',
    default_value     => 'MSS'
);

DBMS_SCHEDULER.SET_JOB_ARGUMENT_VALUE(
    job_name          => 'schema.my_job',
    argument_position => 1,
    argument_value    => 'DIWS'
);
```

Argument values can carry PII (connection strings, email
addresses, PIN-length policies). Redact values in manifests,
keep argument names.

## SET_ATTRIBUTE

Post-creation mutation of any job/program/schedule/chain
property.

```
DBMS_SCHEDULER.SET_ATTRIBUTE(
    name      => 'schema.my_job',
    attribute => 'enabled',
    value     => TRUE
);
DBMS_SCHEDULER.SET_ATTRIBUTE(
    name      => 'schema.my_job',
    attribute => 'repeat_interval',
    value     => 'FREQ=HOURLY;BYMINUTE=30'
);
```

Must apply SET_ATTRIBUTE calls in source order after the
corresponding CREATE to reconstruct the final state.

## RUN_JOB

Executes a job immediately, outside its schedule.

```
DBMS_SCHEDULER.RUN_JOB('schema.my_job', use_current_session => FALSE);
```

If `RUN_JOB` appears in a non-job context — a PL/SQL package called
from application code, a Jenkins pipeline, Control-M JIL — the job is
externally triggered. This is the Tier-1 finding for
`oracle-external-trigger-findings.json`.

## ENABLE / DISABLE / DROP

State-change operators:

```
DBMS_SCHEDULER.ENABLE('schema.my_job');
DBMS_SCHEDULER.DISABLE('schema.my_job');
DBMS_SCHEDULER.DROP_JOB('schema.my_job');
```

Apply in source order when reconstructing state.
