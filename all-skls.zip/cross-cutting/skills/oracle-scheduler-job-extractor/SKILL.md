---
name: oracle-scheduler-job-extractor
description: >
  Inventory every Oracle scheduled job, program, schedule, chain, and
  job class in a repo's `db/` directory — both the modern `DBMS_SCHEDULER`
  API (10g+) and the deprecated-but-still-functional `DBMS_JOB` (10g and
  earlier). Also detects externally-triggered jobs where Control-M,
  Autosys, or cron invokes `DBMS_SCHEDULER.RUN_JOB` rather than the
  in-database schedule — a Tier-1 hidden-dependency finding because
  modernization cannot port to an in-db scheduler without also migrating
  the external trigger mechanism. Runs as a Modernization Extract
  conditional skill when `database` contains `oracle` AND the repo has
  a `Scheduler Jobs/` directory or `DBMS_SCHEDULER` / `DBMS_JOB`
  references in any `.sql` file. Triggers on Oracle scheduler extraction,
  DBMS_SCHEDULER inventory, DBMS_JOB migration, Control-M dependency
  detection, or @oracle-scheduler-job-extractor.
agent: sonnet
allowed-tools:
  - Read
  - Write
  - Grep
  - Glob
validation_commands:
  - "python -m olympus.validators.schema_validator oracle-job-inventory.json"
  - "python -m olympus.validators.schema_validator oracle-program-manifest.json"
  - "python -m olympus.validators.schema_validator oracle-schedule-manifest.json"
  - "python -m olympus.validators.schema_validator oracle-job-chain-manifest.json"
  - "python -m olympus.validators.schema_validator oracle-job-class-manifest.json"
  - "python -m olympus.validators.schema_validator oracle-external-trigger-findings.json"
  - "python -m olympus.validators.schema_validator oracle-legacy-dbms-job-findings.json"
supported_stacks:
  - oracle
  - plsql
  - dbms-scheduler
  - dbms-job
anti_target_stacks:
  - sqlserver
  - postgresql
  - mysql
  - sqlite
  - cron
failure_classes:
  - calendar-syntax-translated-blindly
  - external-trigger-missed
  - named-schedule-reference-unresolved
  - auto-drop-one-shot-ignored
  - job-arguments-with-credentials-leaked
  - legacy-dbms-job-unflagged
  - job-class-resource-group-lost
  - timezone-normalized-to-utc
  - create-program-without-create-job-ignored
  - executable-job-type-security-unflagged
benchmark_tags:
  - modernization-extract
  - oracle-scheduler-inventory
  - external-trigger-detection
  - legacy-scheduler-migration
---

# oracle-scheduler-job-extractor

## Purpose
Produce a complete inventory of the Oracle in-database scheduler surface
from source `.sql` files — jobs, programs, schedules, chains, job classes,
enabled/disabled state, calendaring semantics, argument bindings, external
triggers — so the Design step can author a target scheduler configuration
(Airflow DAGs, Kubernetes CronJobs, AWS EventBridge, Celery Beat) with
equivalent behavior. Modernization without this inventory silently breaks
nightly data-mart refreshes, PIN expiry sweeps, and cross-system handoffs
after cutover. The skill is also the authoritative detector for
externally-triggered jobs — where a Control-M, Autosys, cron, or Jenkins
pipeline invokes `DBMS_SCHEDULER.RUN_JOB('FOO')` rather than letting
Oracle fire the job on its own schedule. Those are hidden dependencies:
the Oracle schedule is a false signal, and migration must include the
external scheduler too.

## Inputs
- Repository `db/` tree (or equivalent) containing `.sql` files. For
  MEDXPRESS the canonical directory is `db/Scheduler Jobs/`; for other
  AAM apps the scheduler calls are inlined in migration scripts.
- Application catalog entry from `catalog-application` with
  `database: oracle` confirmed.
- Tech fingerprint from `oracle-discovery-patterns` to confirm the
  Oracle version (10g, 11g, 12c, 18c, 19c, 21c) — affects which
  features are available.
- Optional: Control-M / Autosys / Jenkins pipeline definitions from
  the repo or a sibling ops repo — used to resolve external triggers.
- Optional: `pkg_mx_*` / `pkg_amcs*` package-body source where jobs
  are invoked from PL/SQL — used to resolve `RUN_JOB` callers.

## Outputs
- `oracle-job-inventory.json` — per job: `{schema, job_name,
  job_type (PLSQL_BLOCK | STORED_PROCEDURE | EXECUTABLE | CHAIN |
  PROGRAM), job_action, schedule_name_or_repeat_interval, start_date,
  end_date, enabled, auto_drop, job_class, comments,
  source_file_line}`.
- `oracle-program-manifest.json` — per program:
  `{schema, program_name, program_type (PLSQL_BLOCK | STORED_PROCEDURE |
  EXECUTABLE), program_action, number_of_arguments, enabled,
  source_file_line}`.
- `oracle-schedule-manifest.json` — per named schedule:
  `{schema, schedule_name, repeat_interval, start_date, end_date,
  comments, source_file_line}`.
- `oracle-job-chain-manifest.json` — per chain: `{chain_name, steps[]
  (step_name, program_name, skip, pause), rules[] (condition, action),
  comments}`. Rules reference step outcomes
  (`FOO SUCCEEDED`, `BAR FAILED`).
- `oracle-job-class-manifest.json` — per job class:
  `{job_class_name, resource_consumer_group, service, logging_level,
  log_history, comments}`.
- `oracle-external-trigger-findings.json` — jobs where a
  `RUN_JOB('foo')` call is located in an external artifact (Control-M
  JIL, Autosys definition, Jenkins pipeline, cron file, PL/SQL
  procedure called from outside the database). One record per
  external trigger: `{job_name, trigger_location, trigger_type
  (control-m | autosys | cron | jenkins | plsql-external |
  application-code), trigger_owner_repo}`.
- `oracle-legacy-dbms-job-findings.json` — per `DBMS_JOB` call:
  `{job_id_or_binding_var, what (the PL/SQL block passed),
  next_date, interval_expression, source_file_line,
  recommended_dbms_scheduler_translation}`.

## Methodology
1. **Enumerate candidate files.** Glob for `**/*.sql`, `**/*.pks`,
   `**/*.pkb`, `**/*.pls`, `**/*.prc`, `**/*.fnc` under the repo.
   Grep case-insensitively for `DBMS_SCHEDULER` or `DBMS_JOB`. Do not
   restrict to a `Scheduler Jobs/` directory — the convention is
   common but not contractual (AMCS inlines scheduler calls in
   ticket-keyed migration scripts).
2. **Parse `DBMS_SCHEDULER.CREATE_JOB` calls.** The call takes named
   arguments: `job_name`, `job_type`, `job_action`, `schedule_name` or
   `repeat_interval`, `start_date`, `end_date`, `enabled`, `auto_drop`,
   `job_class`, `comments`, `number_of_arguments`. Capture all.
3. **Parse `DBMS_SCHEDULER.CREATE_PROGRAM` calls.** Same named-argument
   shape. Programs are reusable — multiple jobs can reference the same
   program name. Build a program-to-jobs edge set.
4. **Parse `DBMS_SCHEDULER.CREATE_SCHEDULE` calls.** Record
   `schedule_name` + `repeat_interval`. Detect shared schedules (one
   schedule referenced by multiple jobs).
5. **Parse chain definitions.** Chains need `CREATE_CHAIN`,
   `DEFINE_CHAIN_STEP` (per step), `DEFINE_CHAIN_RULE` (per rule), and
   `ENABLE` to activate. Reconstruct the step + rule graph.
6. **Parse `CREATE_JOB_CLASS` calls.** Record resource consumer group
   affinity and service affinity — modernization targets rarely map
   cleanly.
7. **Detect `SET_ATTRIBUTE` calls.** Jobs and programs can be mutated
   after creation: `SET_ATTRIBUTE('MY_JOB', 'enabled', TRUE)`. Apply
   the mutations in source order to reconstruct the final state.
8. **Detect `RUN_JOB` calls.** Any `DBMS_SCHEDULER.RUN_JOB` call in a
   PL/SQL package, application code, or external trigger artifact is
   an external trigger. Record the caller location as the
   `trigger_location`.
9. **Parse `DBMS_JOB.SUBMIT` / `DBMS_JOB.REMOVE` / `DBMS_JOB.CHANGE`
   calls.** Record `what` (the PL/SQL block), `next_date`,
   `interval` expression. Emit per occurrence; `DBMS_JOB` is deprecated
   but still compiles.
10. **Detect external triggers beyond the database.** Look for
    Control-M JIL files (`*.jil`, `*.ctm`), Autosys definitions
    (`*.jil`, `autorep` outputs), Jenkinsfile `sh 'sqlplus -s ...'`
    blocks, cron files (`crontab`, `/etc/cron.d/*`), systemd timer
    units. Resolve each to a job name.
11. **Emit manifests with `{repo}:{file}:{line}` citations.** Every
    job, program, schedule, chain, class, and finding record carries
    a source citation.

## Tech-Stack Dispatch

| Trigger | Reference loaded |
|---|---|
| `CREATE_JOB` / `CREATE_PROGRAM` / `CREATE_SCHEDULE` / `CREATE_CHAIN` calls | `references/dbms-scheduler-job-patterns.md` |
| `DBMS_JOB.SUBMIT` / `REMOVE` / `CHANGE` calls | `references/legacy-dbms-job-migration-patterns.md` |
| Control-M JIL, Autosys, Jenkins `sqlplus` blocks, cron invoking `RUN_JOB` | Both references (external-trigger section) |

## Gotchas
- **`DBMS_JOB` (deprecated) vs `DBMS_SCHEDULER` (current).**
  `DBMS_JOB.SUBMIT` returns a numeric job_id and uses `NEXT_DATE`
  plus an `interval` expression of raw PL/SQL
  (`SYSDATE + 1/24`). `DBMS_SCHEDULER.CREATE_JOB` uses named jobs
  and ISO-style `repeat_interval` strings. Don't conflate. `DBMS_JOB`
  still compiles in 19c/21c but Oracle has formally deprecated it.
- **Calendaring syntax is Oracle-specific.**
  `FREQ=DAILY;BYHOUR=2;BYMINUTE=0` is NOT standard cron — it is
  Oracle's repeat-interval grammar. Preserve the original string and
  emit a cron-equivalent as a separate field, not a replacement.
- **Job Class is a resource-management grouping.** Tied to resource
  consumer groups and service affinity. Modernization targets
  (Celery, K8s CronJobs, Airflow) don't have a 1:1 analog — flag.
- **Jobs can invoke chains.** Chains have steps with conditional
  rules — multi-step workflows inside Oracle that need to be
  reconstructed. A single `job_type = CHAIN` entry in the inventory
  expands to a multi-node graph.
- **External triggers are a hidden dependency.** Control-M or a
  Jenkins pipeline calling `DBMS_SCHEDULER.RUN_JOB('FOO')` means the
  Oracle schedule is a false signal — the real trigger is outside
  the database. Modernization must migrate BOTH sides. Tier-1
  finding.
- **`EXECUTABLE` job_type runs OS binaries.** Requires
  `ORACLE_SCHED` external-procedure-agent setup on the database
  host. Rare but legal; flag as security-sensitive.
- **Jobs can self-drop.** `auto_drop => TRUE` means the job
  disappears after its scheduled run — a one-shot. Running the
  extractor against a live DB misses these; only source-file
  extraction is reliable.
- **Job arguments may contain PII or credentials.** PIN lengths,
  email addresses, connection strings. Redact argument values in
  manifests; keep argument names.
- **Enabled vs disabled is stateful.** Source scripts often
  `CREATE_JOB(..., enabled => FALSE)` and a later manual `ENABLE`
  activates the job. Reconstruct the final state by applying
  `SET_ATTRIBUTE` calls in source order.
- **`Scheduler Jobs/` as a directory is convention, not contract.**
  Grep across ALL `.sql` files; AMCS inlines scheduler calls in
  ticket-keyed migration scripts (`AMCS-1141_*.sql`).
- **`CREATE_PROGRAM` without a matching `CREATE_JOB`** means a
  reusable program exists but nothing schedules it — emit finding;
  may be invoked ad-hoc via `RUN_JOB` instead.
- **Named-schedule references must resolve.**
  `CREATE_JOB(..., schedule_name => 'SYS.MY_SCHED')` needs the
  named schedule; emit `named_schedule_unresolved` if the referenced
  schedule is not defined in the repo.
- **Time zones in `start_date` are load-bearing.**
  `'01-JAN-2024 02:00:00 AMERICA/NEW_YORK'` is a different job
  than `'01-JAN-2024 02:00:00 UTC'`. Don't normalize to UTC
  silently — preserve original.
- **`DBMS_SCHEDULER.EVALUATE_CALENDAR_STRING`** is Oracle's own
  verifier for calendar strings. Do not execute it from the
  extractor (read-only analysis); recommend it as a validation
  step in the handoff.
- **SET_ATTRIBUTE can mutate nearly everything.** A job's
  `job_action`, `schedule_name`, `enabled`, `auto_drop` can all
  change after creation. The final state is source-order
  dependent.

## Quality Rules
- [ ] Every `DBMS_SCHEDULER.CREATE_JOB` call has an entry in
      `oracle-job-inventory.json` with all named arguments
      captured.
- [ ] Every `DBMS_SCHEDULER.CREATE_PROGRAM` call has an entry in
      `oracle-program-manifest.json`.
- [ ] Every `DBMS_SCHEDULER.CREATE_SCHEDULE` call has an entry in
      `oracle-schedule-manifest.json`.
- [ ] Every chain has a reconstructed step + rule graph.
- [ ] Every `DBMS_JOB.SUBMIT` / `REMOVE` / `CHANGE` call is
      recorded with a migration-to-`DBMS_SCHEDULER`
      recommendation.
- [ ] External triggers have `trigger_location` pointing at the
      external artifact (Control-M JIL file, Jenkinsfile stage,
      cron line).
- [ ] `SET_ATTRIBUTE` mutations are applied in source order to
      produce the final state.
- [ ] Time zones in `start_date` are preserved verbatim.
- [ ] Argument values are redacted; names are preserved.
- [ ] Every record carries `{repo}:{file}:{line}` traceability.

## Common Failure Modes

| Failure Mode | Symptom | Prevention |
|---|---|---|
| Cron-equivalent overwrites original repeat_interval | Oracle `FREQ=DAILY;BYHOUR=2` replaced by `0 2 * * *` cron; semantic drift on edge cases (BYSETPOS, BYMONTHDAY) | Emit cron as a separate field, preserve original |
| External trigger not detected | Jobs appear unscheduled in the manifest but are actually fired by Control-M | Grep all non-SQL artifacts (JIL, Jenkinsfile, cron, systemd) for `RUN_JOB` |
| SET_ATTRIBUTE mutations ignored | Job appears disabled per CREATE_JOB but is actually enabled after a later SET_ATTRIBUTE | Process SET_ATTRIBUTE in source order after each CREATE |
| Chain structure flattened | Multi-step workflow reported as a single CHAIN job | Parse DEFINE_CHAIN_STEP and DEFINE_CHAIN_RULE into a graph |
| Argument credentials leaked | Connection strings or passwords in CREATE_JOB `arguments` emitted verbatim | Redact argument values, keep names |
| Named schedule reference orphaned | Manifest lists `schedule_name='FOO_SCHED'` with no FOO_SCHED in schedules | Post-extraction resolve step; emit `named_schedule_unresolved` finding |

## Handoff Summary
When this skill completes, verify:
1. Every scheduler artifact in the source (jobs, programs, schedules,
   chains, classes) has an inventory record with source citation.
2. Every externally-triggered job is flagged with a `trigger_location`
   pointing at the specific artifact (Control-M JIL line, Jenkins
   stage, cron entry).
3. Every `DBMS_JOB` call carries a migration-to-`DBMS_SCHEDULER`
   recommendation.
4. SET_ATTRIBUTE mutations are applied to produce the final state.
5. Time zones and argument values preserve original content with
   PII redacted.

Then proceed to: `module-design` (Design primary) — which consumes
the scheduler inventory to shape the target scheduler configuration;
`migration-strategy-advisor` — which assesses migration to Airflow
vs Kubernetes CronJobs vs EventBridge; and, for apps with external
triggers, a Control-M / Autosys migration workstream alongside the
in-database scheduler port.

## References
- `references/dbms-scheduler-job-patterns.md` — `CREATE_JOB` /
  `CREATE_PROGRAM` / `CREATE_SCHEDULE` / `CREATE_CHAIN` syntax,
  all five job_types, calendaring syntax (`FREQ`, `INTERVAL`,
  `BYHOUR`, `BYDAY`, `BYMONTHDAY`, `BYSETPOS`), chain steps and
  rules, job classes and resource groups, logging modes,
  argument binding.
- `references/legacy-dbms-job-migration-patterns.md` —
  `DBMS_JOB.SUBMIT` / `REMOVE` / `CHANGE` syntax, interval
  expression arithmetic, migration path to `DBMS_SCHEDULER` with
  one-to-one mapping limits, external-trigger detection
  methodology, modernization targets (Airflow, K8s CronJobs,
  Celery Beat, AWS EventBridge, Dagster) with trade-offs.

## Changelog
- 0.1.0 (2026-05-07) — Initial skill. Covers `DBMS_SCHEDULER` +
  deprecated `DBMS_JOB` inventory, chain graph reconstruction,
  external-trigger detection (Control-M, Autosys, cron, Jenkins),
  SET_ATTRIBUTE mutation tracking, time zone preservation, PII
  redaction in arguments. Emits seven manifests with
  `{repo}:{file}:{line}` traceability. Authored as ATLAS-R-13.
