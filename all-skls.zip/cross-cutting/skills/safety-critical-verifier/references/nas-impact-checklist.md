# NAS Impact Assessment Checklist

## Failure Mode Analysis
For each system function, answer:
- [ ] If this function fails, can aircraft positions still be tracked?
- [ ] If this function fails, can controllers still communicate with pilots?
- [ ] If this function fails, can weather data still reach operations?
- [ ] If this function fails, can NOTAMs still be disseminated?
- [ ] If this function fails, can flight plans still be processed?

## Degradation Assessment
- [ ] What is the maximum duration of outage before NAS safety is affected?
- [ ] What manual procedures exist as fallback?
- [ ] How are adjacent systems affected by this system's failure?
- [ ] What is the blast radius (geographic/functional) of a failure?

## Rollback Assessment
- [ ] Can the legacy system be restored within the RTO?
- [ ] Has the rollback procedure been tested under realistic conditions?
- [ ] What data might be lost during rollback?
- [ ] Are parallel operations still active during the assessment period?
