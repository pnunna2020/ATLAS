# Independent Verification and Validation (IV&V) Methodology

IV&V methodology applied to T1 safety-critical FAA applications during P5.4.

## Purpose
IV&V is independent review of code against specifications by an agent or team
that was not involved in generating the code. For T1 systems that affect the
National Airspace System (NAS), this is a mandatory verification gate — the
generation agent's blind spots must not become verification blind spots.

## Independence Requirements

Independence is NOT a procedural checkbox. It is an evidence-backed claim.

- The verification agent MUST be a distinct Claude Code session (fresh context,
  no shared history with the generation session).
- The verification agent MUST NOT be given the generator's intermediate notes,
  plans, or Ralph Loop transcripts. Only the final code, tests, and specs.
- The verification agent's tool access should be read-only for source files
  during the initial analysis pass.
- If the same human operator supervises both agents, the operator records
  the agent identities, session IDs, and time stamps as audit evidence.

## Verification Activities

### 1. Requirements Traceability Audit
For every SRS requirement, verify there exists implementing code AND tests.
Bidirectional: every code module must trace back to at least one requirement.
Target: 99%+ bidirectional coverage.

### 2. Code-to-Spec Correctness Review
For a sample of modules (minimum 20% of LOC weighted by risk), read the code
without reference to the generator's explanations and compare against the
SRS. Flag any behavior that does not match the spec.

### 3. Test Adequacy Review
Review the test suite for:
- Boundary conditions on every input domain
- Error paths and exception handling
- State transitions for every state machine defined in the SRS
- Integration tests exercising every external boundary

### 4. Static Analysis and Mutation Testing
Run language-appropriate static analyzers and mutation testing tools.
Surviving mutants indicate untested logic branches.

### 5. Safety Property Verification
For T1 systems, verify that documented safety properties (fail-safe modes,
resource limits, deadlock freedom) hold in the final implementation.

## Outputs

- IV&V report with findings classified CRITICAL / MAJOR / MINOR
- Traceability audit summary with coverage percentages
- Sign-off recommendation (approve / conditional / reject)

<!-- TODO(skill-author): Add the specific static analysis and mutation testing
     tools mandated by the FAA profile, along with acceptable-finding thresholds
     per tier. -->
