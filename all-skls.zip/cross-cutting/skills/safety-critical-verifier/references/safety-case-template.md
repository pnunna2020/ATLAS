# Safety Case Template

Structure for the safety case document assembled for T1 safety-critical FAA
applications. The safety case is a legal artifact — it may be reviewed in
incident investigations — so every claim must be factually defensible with
evidence citations.

## Document Structure

### 1. System Identification
- Application name and version
- Risk tier (must be T1 for this template)
- Primary NAS functions the system supports
- Operational environment

### 2. Hazard Analysis
- Hazards identified during Discovery and Architecture phases
- Severity classification for each hazard (Catastrophic / Hazardous / Major /
  Minor / No Effect, per FAA safety engineering conventions)
- Likelihood classification
- Risk level matrix combining severity and likelihood

### 3. Safety Requirements
- Derived safety requirements traced to hazards
- Each requirement has: unique ID, prescriptive SHALL statement, traceability
  to hazard, verification method

### 4. Design Measures
- Design choices that mitigate identified hazards
- Redundancy, fail-safe modes, defensive checks
- Each measure cites the specific code or configuration implementing it

### 5. Verification Evidence
Each safety requirement MUST have verification evidence. Acceptable forms:
- Test case with result and execution timestamp
- Code review citation with reviewer identity and date
- Static analysis result with tool and version
- Formal proof or model-checking output (if used)

### 6. Residual Risk Assessment
- Hazards not fully mitigated, with rationale
- Compensating operational controls (procedures, monitoring)
- Accepted residual risk sign-off

### 7. Assumptions and Dependencies
- Assumptions about the operational environment
- Dependencies on other systems
- Change-impact triggers (what changes require safety case revision)

### 8. Sign-off Record
- FAA Safety Board reviewer signatures
- Date of review
- Approval status (approved / conditional / rejected)

## Evidence Traceability Format

Every claim in the safety case uses structured citations:

```
Claim: The system SHALL reject flight plans with invalid altitudes.
Evidence:
  - Test: tests/flight/test_altitude_validation.py::test_altitude_range
    Result: PASS on 2026-04-20
    Framework: pytest 8.x
  - Code: src/flight/plan_validator.py:118-145
  - Requirement: REQ-SAFE-042 (traced from HAZ-017)
```

<!-- TODO(skill-author): Add the FAA Safety Board review checklist and
     reviewer rubric once it is approved for inclusion in this reference. -->

<!-- TODO(skill-author): Add specific severity / likelihood definitions used
     by the FAA profile so they do not drift from agency policy. -->
