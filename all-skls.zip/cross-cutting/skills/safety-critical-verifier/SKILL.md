---
name: safety-critical-verifier
description: >
  Enhanced verification for T1 safety-critical FAA applications. Executes
  IV&V checks, NAS impact assessment, and enhanced traceability verification
  (99%+). Use during P5.4 for safety-critical assurance. Triggers on T1
  safety, IV&V, NAS impact, safety case, or safety-critical verification.
agent: opus
---

# Safety-Critical Assurance (T1)

## Purpose
T1 applications affect the National Airspace System (NAS). They require
verification rigor beyond standard modernization — this skill implements
the enhanced requirements of P5.4.

## Workflow
1. Verify safety tier is T1 (refuse to run on T2/T3 — those use standard validation)
2. Check traceability matrix: must be ≥99% (vs 98% standard)
3. Verify formal test plans exist (mandatory for T1, optional otherwise)
4. Execute IV&V analysis: independent review of code against specs
5. Run NAS impact assessment using `references/nas-impact-checklist.md`
6. Assemble FAA safety board review package

## Gotchas
- **99% traceability is NOT negotiable for T1**: Every requirement must trace
  to code, and every code module must trace to a requirement. The 1% gap must
  be explicitly documented and justified.
- **IV&V must be INDEPENDENT**: The verification agent must not be the same
  agent that generated the code. Use a fresh subagent with no context from
  the generation session.
- **NAS impact assessment requires domain expertise**: This isn't a generic
  risk assessment. It must address: "If this system fails, what happens to
  aircraft in flight?" Don't generate generic risk language.
- **Safety case documentation is a legal artifact**: It may be reviewed in
  incident investigations. Every statement must be factually defensible.

## Reference Files
- `references/nas-impact-checklist.md` — NAS impact assessment criteria
- `references/safety-case-template.md` — Safety case structure
- `references/iv-and-v-methodology.md` — Independent verification methodology

## Quality Rules
- [ ] Safety tier verified as T1 before execution — skill refuses to run on T2/T3 apps
- [ ] Traceability matrix achieves >=99% (bidirectional: requirement-to-code and code-to-requirement)
- [ ] Formal test plans exist and are reviewed (mandatory for T1, not optional)
- [ ] IV&V is performed by an independent subagent with no generation context — not the code author
- [ ] NAS impact assessment uses domain-specific criteria from `references/nas-impact-checklist.md`, not generic risk language
- [ ] Safety case documentation is factually defensible — every statement can be verified against evidence

## Common Failure Modes
| Failure Mode | Symptom | Prevention |
|-------------|---------|------------|
| Same-agent IV&V | Verification performed by the same agent that generated code; same blind spots produce same misses | Spawn a fresh subagent with zero generation context for IV&V; verify agent identity |
| Generic NAS impact assessment | Impact assessment says "system failure could affect operations" without specifics; safety board rejects it | Use NAS-specific criteria: "If this system fails, what happens to aircraft in flight?" with concrete scenarios |
| 98% traceability accepted | T1 app passes with standard 98% threshold instead of required 99%; 1% gap not justified | Enforce 99% threshold for T1; require explicit justification and documentation for any gap |
| Safety case with unsupported claims | Documentation makes claims about system reliability without evidence citations; legal liability | Every claim in the safety case must reference specific evidence (test results, code analysis, design decisions) |

## Handoff Summary
When this skill completes, verify:
1. Traceability matrix achieves >=99% with any gaps explicitly justified
2. IV&V was performed by an independent agent
3. NAS impact assessment addresses specific failure scenarios
4. Safety case documentation is complete and evidence-backed
Then proceed to: FAA Safety Board review with the assembled safety review package, and gate `G-V2` for safety-critical validation sign-off
