---
name: module-design
description: >
  Generate module designs from extracted specifications, producing service boundaries, internal architecture, and component designs. Use during P4.2 design phase. Triggers on module design, service design, component architecture, or P4.2 design.
agent: opus
allowed-tools:
  - Read
  - Write
  - Bash
  - Grep
---

# Module Design

## Purpose
Transform extracted specifications into cloud-native module designs that are ready for code generation.

## Gotchas
- **Design granularity matters**: Too coarse = monolith recreated. Too fine =
  200 Lambda functions for one app. Target 5-15 modules per typical app.
- **Every module must map to extracted specs**: Forward traceability from
  spec → module is required for G-04b. Don't design modules that aren't
  justified by extracted requirements.
- **DDD bounded contexts, not technical layers**: Organize by business domain
  (FlightSchedule, UserManagement) not technical layer (Controller, Service, DAO).

## Quality Rules
- [ ] Module count is within the 5-15 range for a typical application; deviations are justified in design notes
- [ ] Every module maps to at least one extracted specification via rule ID — no modules without spec justification
- [ ] Module boundaries align with DDD bounded contexts (business domain), not technical layers
- [ ] Inter-module communication uses well-defined contracts (API, events, shared schema) — no implicit coupling
- [ ] Each module has a clearly defined data ownership boundary — no shared mutable state across modules
- [ ] Forward traceability matrix exists: every extracted spec maps to exactly one module (no gaps, no ambiguity)
- [ ] Module designs include error handling strategy, retry policy, and circuit breaker patterns where applicable
- [ ] Each module design specifies its deployment target (Lambda, Fargate, ECS) based on workload characteristics

## Common Failure Modes
| Failure Mode | Symptom | Prevention |
|-------------|---------|------------|
| Recreated monolith | All extracted specs land in 1-2 large modules; no meaningful decomposition | Enforce minimum module count; validate each module has a single bounded context |
| Microservice explosion | 50+ tiny modules for a medium app; operational complexity exceeds the benefit | Enforce maximum module count; merge modules that share the same domain and data |
| Technical layer organization | Modules named "controllers", "services", "repositories" instead of business domains | Review module names for domain alignment; reject technical-layer naming |
| Missing traceability | Modules exist but cannot be traced back to extracted specs; gate G-04b fails | Build forward traceability matrix during design; validate no orphaned specs or modules |
| Shared database coupling | Multiple modules read/write the same database tables; runtime coupling defeats decomposition | Assign data ownership per module; use events or APIs for cross-module data access |

## Handoff Summary
When this skill completes, verify:
1. Module count is justified and within acceptable range (5-15 typical)
2. Forward traceability matrix is complete — every extracted spec maps to a module
3. No shared mutable state or direct database coupling across module boundaries
4. Each module specifies its deployment target and communication contracts
Then proceed to: `api-specification` (P4.2) for inter-module API contracts, `tdd-generation` (P4.3) for code generation, and gate `G-04b` for design quality review
