---
name: oracle-discovery-patterns
description: >
  Enumerate Oracle-specific database objects, host-code driver signatures, and
  NLS/character-set configuration during Discovery for any application whose
  fingerprint records `database: oracle`. Extracts PL/SQL packages, procedures,
  functions, triggers, sequences, synonyms, materialized views, DB links,
  DBMS_SCHEDULER jobs, and Advanced Queuing (AQ) objects; maps tablespace and
  partitioning layout; and catalogs OCI/ODP.NET driver calls and TNS/EZConnect
  connection strings in application code. Triggers on Oracle discovery, PL/SQL
  inventory, Oracle connection-string scan, tablespace mapping, or
  @oracle-discovery-patterns.
tier: 1
triggers:
  database: [oracle]
agent: sonnet
enrichment_level: Full
version: 0.1.0
allowed-tools:
  - Read
  - Grep
  - Write
---

# Oracle Discovery Patterns

## Purpose
Produce the Oracle-specific addendum to an application's Discovery bundle when
`analyze-application` Pass 1 records `database: oracle`. Generic Discovery
skills (`analyze-application`, `db-schema-mapper`) surface tables, views, and
constraints but miss Oracle-only constructs — PL/SQL packages, DBMS_SCHEDULER
jobs, Advanced Queuing (AQ), materialized views with query rewrite,
tablespace/partition layout, and NLS settings — that carry business logic and
migration risk. This skill enumerates those objects and the host-side Oracle
driver calls that depend on them so Rationalization, Architecture, and the
Modernization Extract step see the full Oracle footprint.

## Inputs
- Source code repository (Git URL or local path) for the application under
  Discovery.
- Application catalog entry (JSON per
  `schemas/discovery/application-catalog-entry.schema.json`) with `database`
  confirmed as Oracle.
- Tech fingerprint from `analyze-application` Pass 1 (JSON) — must contain
  `database: oracle` to activate this skill.
- Database schema exports when available: `expdp` metadata dump, SQL Developer
  DDL export, Liquibase/Flyway migration history, or a live read-only
  connection to the database.
- PL/SQL source files in the repo (`*.pks`, `*.pkb`, `*.sql`, `*.plb`,
  `*.fnc`, `*.prc`, `*.trg`).
- Application host code (Java, C#, PL/SQL-wrapper scripts) that references
  Oracle drivers (JDBC OCI, ODP.NET, cx_Oracle / oracledb, Pro*C).
- Client-profile risk-classification (`profiles/<client>/risk-classification.yaml`)
  for tier banding of database-tier objects.

## Outputs
- Oracle object inventory (YAML, written into the Discovery working set):
  packages, procedures, functions, triggers, sequences, synonyms,
  materialized views, DB links, scheduler jobs, AQ queues/topics — each
  entry with `{schema}.{object_name}` and `{repo}:{file}:{line}` citations.
- Tablespace + partitioning map (YAML): tablespace → objects, partitioned
  tables with partition strategy, LOB segments, index-organized tables.
- Host-code driver-usage report (Markdown) listing every OCI / ODP.NET /
  cx_Oracle / Pro*C call site with connection-string shape (TNS alias,
  EZConnect, full descriptor) and `{repo}:{file}:{line}` citation.
- NLS + character-set findings → inline section of the object inventory
  (database character set, national character set, `NLS_LANG` environment
  usage, session-level `ALTER SESSION SET NLS_*` statements).
- Oracle-specific datatype register — every column using `NUMBER(p,s)`,
  `CLOB`, `BLOB`, `XMLType`, `RAW`, `LONG`, `ROWID`, `BFILE`, or
  `INTERVAL` types with target-database mapping notes.
- Addendum to the application's `tech-fingerprint.schema.json` document
  with an `oracle_findings` block summarizing object counts and risk flags.
- Traceability citations for every finding using
  `{repo}:{file}:{line}` for source-file references and
  `{schema}.{object_name}` for database-object references.

## Procedure
1. **Confirm activation.** Read the tech fingerprint; abort unless
   `database: oracle`. Emit a `skill-not-applicable` breadcrumb so the
   orchestrator does not retry with the same inputs.
2. **Extract PL/SQL packages, procedures, and functions.** Parse `*.pks`
   (package spec) and `*.pkb` (package body) files; grep for
   `CREATE (OR REPLACE )?(PACKAGE|PROCEDURE|FUNCTION)` in `*.sql`. Capture
   name, schema, parameter list, return type, and the `{repo}:{file}:{line}`
   location of the definition. Record the package spec's `PRAGMA` declarations
   (`AUTONOMOUS_TRANSACTION`, `SERIALLY_REUSABLE`, `RESTRICT_REFERENCES`) —
   they constrain any rewrite.
3. **Enumerate triggers.** Grep `CREATE (OR REPLACE )?TRIGGER`; record
   target table/view, timing (`BEFORE`/`AFTER`/`INSTEAD OF`), event
   (`INSERT`/`UPDATE`/`DELETE`), row-level vs. statement-level, and the
   triggering condition (`WHEN` clause). Trigger bodies often carry
   business rules that do not appear anywhere else in the code — cite every
   trigger's location and body length in lines.
4. **Map tablespaces and partitioning.** From DDL or `dba_segments` export,
   build the tablespace → segment map. For partitioned tables, record the
   partition strategy (`RANGE`, `LIST`, `HASH`, `COMPOSITE`), partition key
   column(s), interval (for interval partitioning), and subpartition
   template. Flag index-organized tables (IOT), global indexes on
   partitioned tables, and LOB segments stored out-of-line.
5. **Inventory sequences, synonyms, materialized views, DB links.** Capture
   every `CREATE SEQUENCE` (with `INCREMENT BY`, `CACHE`, `CYCLE` settings),
   every `CREATE (PUBLIC )?SYNONYM` (target schema.object), every
   `CREATE MATERIALIZED VIEW` (with refresh mode: `ON COMMIT`, `ON DEMAND`,
   fast/complete/force, and query-rewrite enablement), and every
   `CREATE DATABASE LINK` (remote user, service, and authentication method).
   DB links are migration blockers — flag each one with tier T1.
6. **Enumerate scheduler jobs and AQ.** Query `dba_scheduler_jobs` or grep
   `DBMS_SCHEDULER.CREATE_JOB` / `DBMS_JOB.SUBMIT`. Capture job name,
   schedule, program action, and run-as user. For AQ, grep
   `DBMS_AQADM.CREATE_QUEUE_TABLE` / `CREATE_QUEUE` and every `ENQUEUE` /
   `DEQUEUE` call site; record payload type (object type, JMS, raw).
7. **Scan host code for driver signatures.** Grep the application source for:
   - JDBC: `jdbc:oracle:thin:@`, `jdbc:oracle:oci:@`,
     `OracleDataSource`, `OracleDriver`, `oracle.jdbc.*` imports.
   - ODP.NET: `Oracle.DataAccess.Client`, `Oracle.ManagedDataAccess`,
     `OracleConnection`, `OracleCommand`.
   - Python: `cx_Oracle`, `oracledb`, `makedsn`, `create_pool`.
   - Pro*C / Pro*COBOL: `EXEC SQL` blocks, `SQLLIB` linkage.
   Record each call site as `{repo}:{file}:{line}` with the detected driver
   family and whether the connection uses a thin or OCI client.
8. **Classify connection strings.** For every connection string literal or
   config entry, classify as TNS alias (`@<alias>`), EZConnect
   (`host:port/service`), or full descriptor
   (`(DESCRIPTION=(ADDRESS=...)(CONNECT_DATA=...))`). Flag every plaintext
   password, wallet path, or `NLS_LANG` override and cite
   `{repo}:{file}:{line}`.
9. **Capture Oracle-specific datatypes and NLS.** List every column whose
   type is Oracle-only or requires a conversion rule when migrating to
   PostgreSQL or SQL Server — `NUMBER(p,s)` with no target scale,
   `CLOB`/`BLOB` (map to `TEXT`/`BYTEA`), `XMLType` (map to `xml` /
   `nvarchar(max)`), `RAW` and `LONG RAW`, `ROWID` and `UROWID`, `BFILE`
   (external-file pointer), and `INTERVAL DAY TO SECOND` /
   `INTERVAL YEAR TO MONTH`. Record the database character set
   (`NLS_CHARACTERSET`) and national character set (`NLS_NCHAR_CHARACTERSET`)
   from `v$nls_parameters` or the DDL header; flag non-AL32UTF8 databases
   as migration-risk T1.
10. **Emit the Oracle findings block.** Write the object inventory, storage
    layout, driver-usage report, datatype register, and NLS findings to the
    Discovery working set. Attach citations to every finding. Halt and emit
    `oracle-findings-incomplete` if any section is empty when the database
    export indicates objects of that kind exist.

## Quality Rules
- [ ] Every PL/SQL package, procedure, function, and trigger has a
      `{repo}:{file}:{line}` citation to its definition source.
- [ ] Every trigger entry records timing, event, row/statement scope, and
      body length — not just the trigger name.
- [ ] Every partitioned table records its partition strategy, key column(s),
      and (for interval partitioning) the interval.
- [ ] Every sequence records `INCREMENT BY`, `CACHE`, and `CYCLE` settings.
- [ ] Every database link is flagged tier T1 and lists remote service,
      remote user, and authentication method.
- [ ] Every materialized view records refresh mode (`ON COMMIT` /
      `ON DEMAND`, fast/complete/force) and query-rewrite enablement.
- [ ] Every DBMS_SCHEDULER job and AQ queue has an owner, schedule/payload
      type, and `{schema}.{object_name}` citation.
- [ ] Every host-code driver call site is cited as `{repo}:{file}:{line}`
      with detected driver family (JDBC thin / JDBC OCI / ODP.NET /
      cx_Oracle / oracledb / Pro*C).
- [ ] Every connection string is classified as TNS / EZConnect / full
      descriptor, with plaintext passwords flagged as a security finding.
- [ ] Database character set and national character set are recorded; a
      non-AL32UTF8 database is flagged as migration-risk T1.
- [ ] Oracle-specific datatype register covers every column whose type is
      `NUMBER`, `CLOB`, `BLOB`, `XMLType`, `RAW`, `LONG`, `ROWID`, `BFILE`,
      or `INTERVAL` — no silent omissions.

## Common Failure Modes
| Failure Mode | Symptom | Prevention |
|---|---|---|
| Trigger bodies skipped | Business rules embedded in `AFTER UPDATE` triggers never surface in Extract; rewrite produces silent behavior loss | Always enumerate triggers with body length; treat any trigger > 20 lines as a business-rule carrier and hand off to `extraction` |
| DB links treated as configuration | Cross-database joins to a remote Oracle instance disappear in the migration plan; data flow breaks at cutover | Flag every DB link as tier T1; list the remote service and authenticate it with the portfolio integration graph |
| Partitioning strategy lost | Target schema created as a single table; queries that depended on partition pruning slow by 10x–100x | Record partition strategy (`RANGE`, `LIST`, `HASH`, composite) + key column(s); the target DDL must reproduce the partitioning or justify a replacement index |
| Materialized views rebuilt as plain views | Refresh semantics (`ON COMMIT`) and query-rewrite optimization are lost; downstream reports return stale data or slow by an order of magnitude | Record refresh mode and rewrite flag; the target platform's equivalent (e.g., PostgreSQL `MATERIALIZED VIEW` + scheduled refresh) must match |
| Connection strings hard-coded with passwords | Plaintext credentials in `tnsnames.ora` or config files survive into the artifact store | Flag every plaintext password at discovery; route the finding to `identity-landscape-analyzer` and the security gate |
| Non-AL32UTF8 character set ignored | Data migrated byte-for-byte; multi-byte characters corrupt on load | Record `NLS_CHARACTERSET` and `NLS_NCHAR_CHARACTERSET`; emit a migration-risk T1 finding when the source is WE8ISO8859P1, WE8MSWIN1252, or similar |
| AQ queues missed | Asynchronous workflows disappear from the data-flow graph; consumer services stop receiving events at cutover | Grep `DBMS_AQADM` and every `ENQUEUE`/`DEQUEUE`; record payload type and propagate to the portfolio integration graph as an external flow |

## Handoff Summary
When this skill completes, verify:
1. Oracle object inventory covers packages, procedures, functions, triggers,
   sequences, synonyms, materialized views, DB links, scheduler jobs, and AQ
   objects — with `{repo}:{file}:{line}` or `{schema}.{object_name}` citations
   on every entry.
2. Tablespace and partitioning map identifies every partitioned table's
   strategy and key column(s).
3. Host-code driver-usage report cites every JDBC / ODP.NET / cx_Oracle /
   Pro*C call site and classifies its connection string.
4. NLS and character-set findings are present; non-AL32UTF8 is flagged T1.
5. Oracle-specific datatype register is complete — no column using an
   Oracle-only type is missing from the mapping notes.

Then proceed to: `db-schema-mapper` (for the vendor-neutral schema map that
Rationalization consumes), `portfolio-integration-mapper` (to merge DB links
and AQ flows into the cross-portfolio integration graph), and
`identity-landscape-analyzer` (for any plaintext-credential findings). The
next gate is **G-DC** (Discovery Completeness) — the Oracle findings block
must be attached to the application's Discovery bundle before G-DC can pass.

## References
- Oracle Database PL/SQL Language Reference — package, procedure, function,
  and trigger DDL grammar.
- Oracle Database Administrator's Guide — `dba_scheduler_jobs`,
  `dba_segments`, `dba_part_tables`, `v$nls_parameters` catalog views.
- Oracle Database Advanced Queuing User's Guide — `DBMS_AQADM`,
  `DBMS_AQ` procedures.
- `reference/tech-stack.md` — Olympus target-database guidance (PostgreSQL
  first) for Oracle-to-target mapping notes.
- `schemas/discovery/tech-fingerprint.schema.json` — schema of the
  `oracle_findings` block this skill emits.
- `cross-cutting/skills/analyze-application/SKILL.md` — Pass 1 fingerprint
  that activates this skill.
- `cross-cutting/skills/db-schema-mapper/SKILL.md` — downstream consumer of
  the object inventory.
- `cross-cutting/skills/portfolio-integration-mapper/SKILL.md` — downstream
  consumer of DB-link and AQ findings.

## Changelog
- **0.1.0** (2026-04-28) — Initial Full-enrichment skill covering PL/SQL
  object enumeration, tablespace/partitioning map, scheduler + AQ
  inventory, host-code driver scan, connection-string classification,
  Oracle-specific datatype register, and NLS/character-set findings.
  Implements Olympus task T1-4b.
