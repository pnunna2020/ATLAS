---
name: legacy-data-flow-tracer
description: >
  Trace data elements through legacy systems: entry points, transformations, persistence, exit points. Output per schemas/discovery/data-flow-trace.schema.json. Critical for multi-system chains (e.g., CAIS<->AADOCS<->IMS, MedXPress->AMCS->DIWS). Triggers on data flow trace, data lineage, cross-system data tracking, or @legacy-data-flow-tracer.
agent: opus
allowed-tools:
  - Read
  - Write
  - Grep
---

# legacy-data-flow-tracer

## Purpose
Trace the complete lifecycle of a business data element across a legacy system — from the moment it enters (web form, batch feed, TIFF upload, SFTP drop), through every transformation (explicit and implicit), across every persistence point (relational tables, Adabas files, TIFF images, queues), and out to every exit (downstream systems, reports, email, print). Produce a `data-flow-trace.schema.json`-conformant artifact that downstream `extraction`, `module-design`, and data-migration skills consume as the canonical source of truth for what data actually exists, where it really lives, and how many copies have silently drifted. This skill is specifically scoped to data boundaries — it is distinct from `legacy-architecture-mapper` (which maps module structure) and `extraction` (which captures business rules). It catches the invisible transformations — type coercion, null coalescing, encoding flips, scope-chained defaults — that neither an architecture map nor a business-rule catalog will surface on their own.

## Inputs
- Application catalog entry (JSON per `schemas/discovery/application-catalog-entry.schema.json`) — target app identity and scope.
- Architecture map from `legacy-architecture-mapper` (JSON) — module boundaries, external interfaces, DB objects.
- Database archaeology output from `legacy-database-archaeologist` (JSON per `schemas/discovery/db-archaeology.schema.json`) — tables, columns, stored procs, triggers, FKs.
- Integration graph (JSON per `schemas/rationalization/integration-graph.schema.json`) — cross-app edges when available.
- Source code repository (Git URL or local path) for grep-based citation lookup.
- Interface inventory (file drop schedules, SFTP routes, message-queue topics, scheduled-job logs if accessible).
- Client profile PII/PHI classification rules (e.g., `profiles/faa/compliance.yaml`).

## Outputs
- Data flow trace artifact → `schemas/discovery/data-flow-trace.schema.json` (machine-validated).
- Fillable YAML skeleton the agent populates during tracing → `assets/data-flow-trace-template.yaml`.
- Cross-flow findings list (redundant stores, unreconciled copies, PII leakage paths) embedded in the trace artifact under `cross_flow_findings`.
- Per-flow `risk_findings` tagged with `category` from the schema enum (`data-loss`, `pii-leak`, `redundant-store`, `unreconciled-copy`, `orphaned-data`, `type-coercion`, `encoding-mismatch`).

## Methodology
1. **Enumerate candidate data elements.** Pull the top N business nouns from the catalog entry, the DB archaeology column list, and interface specs. Prioritize elements flagged PII/PHI/FTI and any element named in compliance scope.
2. **Locate every entry point per element.** For each data element, grep the source tree and interface specs for entry interfaces (web-form, api, batch-file, queue, sftp, direct-db, tiff-upload, manual-entry). Record `{file}:{line}` citations for each. Missing an entry point means the element is either inferred-only (flag) or discovered via persistence-first (note and continue).
3. **Walk transformations in order.** From each entry point, follow the element through the call graph. Record every `validate`, `normalize`, `enrich`, `redact`, `aggregate`, `split`, `encode`, `decode`, `calculate`, `translate`, or `route` operation. Mark `implicit: true` when the transformation is a side effect of the runtime (ColdFusion scope chaining, SQL implicit casts, ASP.NET ViewState serialization) rather than an explicit business rule. See `references/implicit-transformation-detection.md`.
4. **Map persistence points.** For each store the element touches, record `store_type` (relational-table, adabas-file, tiff-image, file-system, queue-topic, cache, session-state, xml-document, json-document), `location` (table name, file path, queue topic), `retention`, and `source_of_truth` (exactly one per element unless explicitly justified in `risk_findings`).
5. **Map exit points.** Record every egress: api, file-export, queue, report, screen, batch-feed, print, email. Mark `external_consumer: true` for anything leaving the trust boundary.
6. **Flag cross-boundary flows.** Set `crosses_system_boundary: true` whenever the element traverses systems owned by different teams, deployed in different runtimes, or communicating through out-of-process interfaces (SFTP, queues, shared DB links). Set `crosses_identity_boundary: true` when the element crosses identity stores (e.g., CAIS credential context into AADOCS session). Apply patterns from `references/cross-system-tracing-patterns.md`.
7. **Classify PII/PHI/sensitive data.** Assign `pii_classification` from the schema enum (`none`, `pii`, `phi`, `sensitive`, `fti`). Use `references/pii-phi-tracking.md` to tag every persistence and exit that handles classified data. Every PII/PHI/FTI flow must have at least one `risk_findings` entry of severity ≥ medium if the classification is absent at any persistence or exit.
8. **Synthesize cross-flow findings.** Compare flows to detect duplicate stores (same element in ≥ 2 `source_of_truth=true` locations), unreconciled copies (multiple stores with no reconciliation job cited), and orphaned data (persistence with no exit and no retention rule).
9. **Emit schema-valid artifact.** Populate `assets/data-flow-trace-template.yaml`, validate against `schemas/discovery/data-flow-trace.schema.json`, and hand off.

## Gotchas
- **File drops are invisible in application code.** SFTP ingestions and scheduled TIFF uploads leave no trace in app source — they land via cron or scheduler. Always cross-reference the interface inventory and scheduled-job logs. The FAA IACRA → CAIS TIFF-over-FTP pipeline is the canonical example: the TIFF filename encodes airman ID, the file bytes carry the PII, and the application never parses the upload logic — it just reads from a staging directory.
- **Implicit transformations outnumber explicit ones in older runtimes.** ColdFusion scope chaining silently coalesces `form.x`, `url.x`, `session.x`, and `application.x` in that order. SQL Server `varchar`/`nvarchar` implicit casts silently truncate. JavaScript `==` coerces numerically. Every runtime has a defaults-and-coercion cheat sheet — if you do not mark these `implicit: true`, downstream extraction will miss them. See `references/implicit-transformation-detection.md`.
- **A "temporary" staging table is still a persistence point.** If the element lands in a table — even a nightly-truncated staging table — record it. Downstream migration must know every place the data ever sat, because operational reports frequently read from staging.
- **PII classification must travel with the data, not with the column.** The same SSN value may land in a `customer_id` column in one system and a `gov_id` column in another. Assign `pii_classification` to the flow, not to the column, or reconciled stores will silently shed their classification.
- **Every finding needs `{file}:{line}` or `{artifact}:{section}:{finding-id}` traceability.** Downstream consumers (extraction, gate reviewers, migration planners) must trace back to the exact source. A flow without citations is a hypothesis, not a finding.
- **One "source of truth" per element.** If you cannot choose a single `source_of_truth=true` persistence point, record the ambiguity as an `unreconciled-copy` risk finding. Do not silently mark two stores authoritative.
- **Cross-identity flows hide authorization drift.** When an element crosses an identity boundary (CAIS → AADOCS), the original authorization context is lost or re-derived. Always flag `crosses_identity_boundary: true` and raise a `pii-leak` risk if the re-derivation is not cited.

## Quality Rules
- [ ] Every flow has exactly one `entry_point`, at least one `persistence_points` entry, and at least one `exit_points` entry (schema `required` minima).
- [ ] Every flow has a `flow_id` matching `^DF-[A-Z0-9]+-[0-9]{3}$`.
- [ ] Every `entry_point`, `persistence_points` entry, `exit_points` entry, and `transformations` step has a `citation` in `{file}:{line}` or `{artifact}:{section}:{finding-id}` format.
- [ ] Every `transformations` entry with `implicit: true` has a `description` that explains which runtime behavior (coercion, scope chain, encoding, null coalescing) caused it.
- [ ] Every `data_element` has a `pii_classification` assigned from the schema enum (`none`, `pii`, `phi`, `sensitive`, `fti`) — no nulls.
- [ ] Flows that traverse systems owned by different teams or communicating out-of-process have `crosses_system_boundary: true` and at least one `risk_findings` entry.
- [ ] Every flow has exactly one persistence point with `source_of_truth: true`, or a `risk_findings` entry of `category: unreconciled-copy` justifying the ambiguity.
- [ ] Every persistence point has a `retention` value or an explicit `risk_findings` entry of `category: orphaned-data`.
- [ ] PII/PHI/FTI classified flows have at least one `risk_findings` entry of severity ≥ medium when exiting the trust boundary (`exit_points[*].external_consumer: true`).
- [ ] `cross_flow_findings` is populated when ≥ 2 flows share a persistence `location` (duplicate store detection).

## Common Failure Modes
| Failure Mode | Symptom | Prevention |
|---|---|---|
| Application-code-only tracing | File drops, SFTP ingests, and scheduled TIFF uploads missing from the trace; data "appears" in a staging table with no entry point cited | Cross-reference interface inventory, cron/scheduler configs, and the patterns in `references/cross-system-tracing-patterns.md` before closing a flow |
| Implicit transformations omitted | Modernized system diverges on nulls, empty strings, type boundaries, or encoding flips; defects discovered only in UAT | Apply `references/implicit-transformation-detection.md` per detected runtime; mark every side-effect transformation `implicit: true` with a runtime-behavior description |
| PII travels without classification | Sensitive elements land in downstream stores or exports without `pii_classification`; compliance gate fails late | Assign `pii_classification` to the data element at the first trace step; verify classification is carried through every persistence and exit per `references/pii-phi-tracking.md` |
| Two stores silently marked authoritative | Downstream migration writes back to both, creating split-brain; reconciliation never ran in legacy either | Enforce single `source_of_truth: true` per flow; raise `unreconciled-copy` finding when genuine ambiguity exists |
| Cross-boundary flow marked internal | Identity and trust-boundary transitions lost; authorization drift unrecorded | Treat any out-of-process hop (SFTP, queue, shared DB link, DB link, file drop) as a system boundary; set `crosses_system_boundary: true` and cite the transport |

## Handoff Summary
When this skill completes, verify:
1. The emitted artifact validates against `schemas/discovery/data-flow-trace.schema.json` (run the schema validator; zero errors).
2. Every flow has entry, persistence, exit, PII classification, and citations per the Quality Rules.
3. Cross-boundary flows are explicitly flagged and every implicit transformation is marked `implicit: true` with a runtime cause.
4. `cross_flow_findings` surfaces every duplicate store and unreconciled-copy situation detected across the flow set.

Then proceed to: `extraction` (Discovery Step 3 Pass 2) using the flow map to scope business-rule extraction around transformations marked `implicit: true`, and gate `G-DC` for Discovery completeness review.
