# Implicit Transformation Detection

Catch transformations the runtime applies silently. Mark each `implicit: true` and describe the runtime cause.

## Type coercion

**CF scope chaining.** `#x#` without scope resolves form -> url -> cgi -> cookie -> session -> application -> request. Lower scopes silently substitute. Grep `#[a-zA-Z_][a-zA-Z0-9_]*#`. `operation: translate`.

**JS `==`.** `"" == 0`, `null == undefined`, `"0" == false` all true. Grep `\b==\b` excluding `===`. `operation: normalize`.

**SQL implicit casts.** `WHERE varchar_col = 123` forces CAST; `WHERE int_col = '0123'` strips zeros. SQL Server truncates `varchar`; Oracle raises `ORA-01401`. `operation: encode|decode`.

**.NET nullable boxing.** `int? x = null; object o = x;` boxes to `null`, not boxed zero.

## Nulls

- CF treats `""` and `null` as interchangeable (`len(x) eq 0`).
- Java JDBC returns `0` for `getInt` on NULL unless `wasNull()` is checked.
- Oracle treats `''` as NULL; SQL Server treats them distinct.
- Every cross-runtime hop is a null-drift point. Cite both sides.

## Encoding

**EBCDIC -> ASCII.** Mainframe extracts (Adabas, VSAM, DB2 z/OS) land EBCDIC; UNIX assumes ASCII. Braces, brackets, cent sign drift. Cite conversion job; if none, raise `category: encoding-mismatch`.

**UTF-8 vs Latin-1.** CF defaults Latin-1 on older JVMs; modern clients send UTF-8. Mojibake (`Ã©` for `é`). `operation: encode`.

**UTF-16 BOMs.** Windows emits UTF-16+BOM; Unix parsers treat BOM as data.

## Date format drift

- `MM/DD/YYYY` vs `DD/MM/YYYY` — ambiguous first 12 days each month.
- Two-digit years — CF pivots at 30; Oracle `RR` at 50; Excel at 29.
- Timezone drops — SQL Server `datetime`, Oracle `DATE` have no zone. Record zone per persistence.
- `operation: translate`, source and target named.

## Checklist

- Concat with literal -> encode.
- Cross-runtime comparison -> coercion.
- DB read without type check -> null drift.
- Timestamp without timezone -> zone drift.
