# Cross-System Tracing Patterns

Following data across a legacy boundary. Apply in Methodology step 6. Set `crosses_system_boundary: true` and cite the transport.

## File drops
A writes; B polls. Coupling is in filesystem perms and cron, not app code.
- Writers: grep `FileWrite|cffile action="write"|File.WriteAllText`.
- Readers: grep `DirectoryWatcher|Directory.EnumerateFiles`.
- Cite writer line AND poll-job crontab line.

## SFTP drops
A pushes; B pulls on schedule.
- Writers: grep `sftp|ssh|pscp|WinSCP`.
- Schedulers: `crontab -l`, Task Scheduler, Autosys JIL.
- Landing-zone retention often exceeds endpoint assumptions — flag `orphaned-data`.

## Message queues
MQ, RabbitMQ, Kafka, Oracle AQ, JMS.
- Producers: `send|publish|enqueue`; consumers: `subscribe|listen|dequeue`.
- Record topic as `store_type: queue-topic` — in-flight is data at rest for retention.

## Shared database tables
Two apps write/read the same schema (common in CF, classic ASP).
- Map DB grants to app identities to find cross-app writers.
- `crosses_system_boundary: true` plus `category: unreconciled-copy` when both sides mutate without reconciliation.

## TIFF-over-FTP (FAA IACRA -> CAIS)
IACRA emits a TIFF per application; airman ID, type, timestamp are in the filename. CAIS ingests via SFTP, parses the filename, stores TIFF, writes an index row.
- Entry: `tiff-upload` at SFTP receiver.
- Persistence: TIFF vault (`tiff-image`) + index row (`relational-table`).
- Cite the filename regex — it is the data contract.
- PII: TIFF bytes and filename both `pii`.

## Direct SQL links
Oracle DB links, SQL Server linked servers, ODBC linked tables.
- Grep `@DBLINK|OPENQUERY|LinkedServer|\[app_b\]\.\.`.
- Always `crosses_system_boundary: true`; link credentials imply `crosses_identity_boundary: true`.

## Batch chains
Reconstruct from scheduler metadata. Each step is a separate transformation, cite `{job}:{step}`. Mid-chain shape changes drop fields silently — flag `data-loss`.
