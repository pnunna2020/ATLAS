# PII / PHI Tracking

Assign `pii_classification` from the schema enum (`none`, `pii`, `phi`, `sensitive`, `fti`) per data element. Classification travels with the flow, not the column.

## Enum

- **none** — no regulated content; default only after verification.
- **pii** — name, address, SSN, DOB, license, airman cert number, biometrics.
- **phi** — HIPAA: medical records, diagnosis codes, meds, MedXPress answers, AME results.
- **sensitive** — unregulated: case IDs, status, dispositions.
- **fti** — Federal Tax Info (IRS Pub 1075). Separate trust boundary.

## Rules

1. **Classify at the element, not the column.** Same value, different columns -> same class.
2. **Monotonic.** A `phi` entry stays `phi` until an explicit `operation: redact` is cited. Downgrades without `redact` raise `category: pii-leak`.
3. **Aggregation can elevate.** ZIP + DOB + gender re-identifies — treat as `pii`, record `operation: aggregate`.
4. **Filename-encoded PII counts.** IACRA airman-ID-in-filename is `pii` independently of TIFF bytes.

## Requirements

| Class | Per flow |
|---|---|
| pii | `risk_findings` when `external_consumer: true`; retention per persistence. |
| phi | pii reqs + HIPAA boundary cited; no BAA -> `pii-leak`. |
| sensitive | Retention cited; consumer list explicit. |
| fti | Separate trust boundary; mingling with non-fti -> `pii-leak` `critical`. |

## Detection

- Grep columns: `/ssn|tin|tax_id|dob|birth|airman|license|medical|diagnosis|icd|rx/i`.
- Profile `compliance.yaml` — FAA: airman cert number `pii`, medical questionnaire `phi`.
- Regulator counterparty (IRS, CMS, SSA, VA) implies `fti`/`phi`.

## Redaction

A `redact` cites the function and fields redacted. A redact without a field list is an assertion. Example: `redact_pii.cfc:47`, "Masks middle 5 of SSN."

## Cross-boundary

Any `{pii, phi, fti}` flow with `crosses_system_boundary: true` carries ≥ 1 `risk_findings`. `crosses_identity_boundary: true` raises severity to `high`.
