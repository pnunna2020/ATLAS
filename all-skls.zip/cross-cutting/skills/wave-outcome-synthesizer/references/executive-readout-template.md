# Executive Readout Template

Use this layout when producing wave-outcome-synthesis.md. One page. Decisions over analysis.

---

## Wave {wave_id} - Disposition Approval Readout

Synthesis date: {synthesis_date}
Applications in wave: {applications_count}
Recommended gate decision: **{G-DA approve | conditional | reject}**

### Disposition Summary

| Disposition | Count | % of wave |
|---|---:|---:|
| Retire | X | XX% |
| Retain | X | XX% |
| Refactor | X | XX% |
| Rearchitect | X | XX% |
| Replace | X | XX% |
| Replatform | X | XX% |
| Consolidate | X | XX% |

### Section 508 Posture

- Apps assessed: X / Y
- Average compliance score: XX.X / 100
- Blocking violations: X
- Non-compliant apps: [list]

### Throughput Projection

- Apps in scope for modernization: X
- Estimated delivery: X quarters
- Parallelism assumed: X
- Capacity constraints: [list the top 2-3]

### Sustainment Drawdown

- Baseline annual cost (pre-disposition): USD X,XXX,XXX
- Projected annual cost (post-disposition): USD X,XXX,XXX
- Drawdown: XX%
- Key assumptions: [list]

### Top Risks

1. {risk_id} - {description} [severity] {affected_apps}
2. ...

### Evidence

{count} citations across per-app disposition-recommendation, compliance-assessment, and tco-analysis artifacts.
