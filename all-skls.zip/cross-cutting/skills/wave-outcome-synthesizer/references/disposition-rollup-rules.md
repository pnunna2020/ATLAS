# Disposition Rollup Rules

Pin the rollup arithmetic so reruns produce identical synthesis JSON from identical per-app inputs.

## Disposition count aggregation
1. For each app, use disposition_recommendation.recommended_disposition (the final field, not the prior candidates).
2. disposition_counts uses exactly the seven canonical disposition names: Retire, Retain, Refactor, Rearchitect, Replace, Replatform, Consolidate. Case-sensitive, title case.
3. Every key must be present in the output even when value is zero - validator requires it.
4. Sum invariant: sum of all seven values == len(applications).

## Section 508 rollup
1. apps_with_508_assessment = count of apps with a compliance-assessment.json or ux-accessibility.json declaring 508 status.
2. avg_compliance_score = arithmetic mean of per-app compliance_score (0-100) rounded to one decimal. Apps without a score are excluded from the mean and logged.
3. blocking_violations_total = sum of violations where severity == blocking. Advisory/minor items are reported separately but do NOT roll into this total.
4. compliant_apps = apps where compliance_score >= 90 AND blocking_violations == 0.
5. non_compliant_apps = apps_with_508_assessment minus compliant_apps. Apps without a 508 assessment at all appear in neither list.

## Throughput projection
1. total_apps = len(applications).
2. apps_in_scope_for_modernization = count of apps whose disposition is in {Refactor, Rearchitect, Replace, Replatform, Consolidate}. Retire and Retain do NOT consume factory capacity.
3. parallelism_assumption = minimum(concurrent_factory_capacity, in_scope_count). Default concurrent_factory_capacity = 2 for FAA per factory-capacity-manager, overridable via wave_context.
4. estimated_delivery_quarters = ceiling(in_scope_count * avg_app_quarters / parallelism_assumption). Must be >= 1. avg_app_quarters defaults to 1.0 per modernization-plan estimates; profiles can override.
5. capacity_constraints[] lists machine-readable constraints surfaced from factory-capacity-manager or tier-specific ralph-loop extension requests.

## Sustainment drawdown
1. baseline_annual_cost_usd = sum of per-app tco-analysis.total_annual_cost where available; apps without TCO contribute 0 and are called out in assumptions.
2. For each app whose disposition is Retire OR Replace OR Consolidate AND disposition_confidence >= 0.7: post_annual contribution = 0. Otherwise post_annual contribution = that apps current annual cost.
3. post_disposition_annual_cost_usd = sum of post_annual contributions.
4. drawdown_pct = (baseline - post) / max(baseline, 1.0) * 100.0. Round to one decimal.
5. assumptions[] must include: confidence threshold used, whether modernization transient cost is folded in or omitted, and the projection time horizon (default = 12 months post-disposition).

## Risk summary
1. Blockers: surface every item from disposition-validation.json where severity == blocker and every ux-overlap-matrix.overlap_findings with severity == blocker.
2. Majors: surface every item tagged major with a documented mitigation plan.
3. Minors: do not list - the one-pager is for gate decisions, not exhaustive inventory.
4. Every risk entry must carry at least one evidence citation in {artifact}:{section}:{finding-id} format.
