---
name: wave-outcome-synthesizer
description: >
  Synthesize one wave worth of Rationalization outputs into a G-DA gate
  readout. Rolls up per-app dispositions by type, summarizes Section 508
  compliance posture, projects throughput, estimates sustainment drawdown,
  and flags residual blocking risks. Emits wave-outcome-synthesis.json per
  schema for automation and a one-page executive-readout markdown for the
  gate reviewer. Triggers on wave synthesis, G-DA readout, disposition
  rollup, sustainment drawdown, or @wave-outcome-synthesizer.
agent: opus
allowed-tools:
  - Read
  - Write
  - Grep
---

# wave-outcome-synthesizer

## Purpose
Execute the wave-level synthesis pass in wave-envelope Rationalization (ART-P1-1) after every per-app Rationalization has finished and before the G-DA (Disposition Approval) gate. Per-app disposition-recommendation.json files answer what should happen to this app - the gate reviewer needs to know what happens across the wave: how many Retires, how bad is our 508 posture, will we clear the backlog on time, how much sustainment spend drops off, and what risks have to escalate with the decision. This skill produces both the machine-readable JSON (schema-validated) and the human-readable one-pager (gate packet).

## Inputs
- Per-app disposition-recommendation.json for every application in the wave (primary input).
- Per-app complexity-classification.json and portfolio-scorecard entries for the wave (throughput signal).
- Per-app tco-analysis.json (sustainment drawdown baseline).
- Per-app accessibility-report or ux-accessibility.json findings (Section 508 rollup).
- Optional: redundancy-matrix.json and ux-overlap-matrix.json for the wave (supplementary context).

## Outputs
- wave-outcome-synthesis.json - schema at schemas/rationalization/wave-outcome-synthesis.schema.json. Required sections: wave_id, synthesis_date, gate_passed (G-DA or other), applications, disposition_counts (7 dispositions), section_508_rollup, throughput_projection, sustainment_drawdown, risk_summary, evidence.
- wave-outcome-synthesis.md - one-page executive readout. Layout: disposition summary table, 508 status row, throughput projection, sustainment drawdown with assumptions, top 5 residual risks, recommended gate decision. See references/executive-readout-template.md.

## Methodology
1. Load every disposition-recommendation.json in the wave. Fail if any app in wave scope is missing its recommendation - synthesis without a full wave is non-defensible.
2. Tabulate disposition_counts for the seven dispositions (Retire, Retain, Refactor, Rearchitect, Replace, Replatform, Consolidate). Every key must be present even if zero - the schema requires it.
3. Roll up Section 508 posture. For each app with a 508 assessment, count blocking violations and collect the compliance score. Compute apps_with_508_assessment, avg_compliance_score (0-100), blocking_violations_total, compliant_apps[], non_compliant_apps[].
4. Project throughput per references/disposition-rollup-rules.md. total_apps = apps in wave. apps_in_scope_for_modernization = count of dispositions in {Refactor, Rearchitect, Replace, Replatform, Consolidate}. estimated_delivery_quarters uses parallelism_assumption (factory capacity) with a minimum of 1. Capture capacity_constraints[] as strings.
5. Estimate sustainment drawdown. baseline_annual_cost_usd = sum of current TCO across all apps. post_disposition_annual_cost_usd = baseline minus TCO of every Retire/Replace/Consolidate with disposition confidence >= 0.7 (others stay full cost until the gate approves them). drawdown_pct = (baseline - post)/baseline * 100 (negative allowed if modernization adds transient cost - rare but possible). List every assumption.
6. Compile risk_summary. Include every risk classified as blocker from per-app disposition-validation reports, every UX overlap finding with severity blocker, and any unmitigated compliance waiver surfaced in per-app compliance-assessment.
7. Populate evidence[]. Every disposition-count, 508 stat, and risk entry must cite the per-app artifact it came from.
8. Compose the wave-outcome-synthesis.md using references/executive-readout-template.md. Keep to one page - decisions, not analysis.
9. Self-check: disposition_counts sums to len(applications); every compliant_app appears in applications; every non_compliant_app appears in applications; throughput_projection.estimated_delivery_quarters >= 1.

## Gotchas
- **Do not double-count TCO savings.** A Retire and a Consolidate on the same app cannot both contribute to drawdown - resolve to the single final disposition per app before summing.
- **Sustainment drawdown is contingent on the gate.** Always state clearly in assumptions that savings realize only after G-DA approval and post-disposition execution.
- **Section 508 rollup must distinguish blocking vs advisory.** Count blocking_violations_total separately from total findings; advisory items do not affect gate flow.
- **Throughput projection must acknowledge ralph-loop cost.** If any app in the wave is Tier 1 and slated for Generation, note the extended Ralph Loop iteration cap (5-10) in capacity_constraints.
- **Risks without mitigation plans are not risks - they are issues.** Escalate to blocker severity and recommend the gate reject until mitigation is attached.

## Quality Rules
- [ ] disposition_counts has all seven keys and their sum equals len(applications).
- [ ] section_508_rollup.avg_compliance_score is in [0, 100]; compliant_apps + non_compliant_apps are disjoint subsets of applications.
- [ ] throughput_projection.estimated_delivery_quarters >= 1 and parallelism_assumption >= 1.
- [ ] sustainment_drawdown.drawdown_pct is within [-100, 100]; assumptions[] is non-empty.
- [ ] risk_summary[*].severity in (blocker, major, minor) and affected_apps are subsets of applications.
- [ ] evidence[] cites at least one artifact per disposition_counts bucket (one per non-zero bucket minimum).
- [ ] JSON validates against schemas/rationalization/wave-outcome-synthesis.schema.json.
- [ ] Markdown readout is one page and names the recommended gate decision (G-DA approve / G-DA reject / G-DA conditional).

## Common Failure Modes
| Failure Mode | Symptom | Prevention |
|---|---|---|
| Disposition counts sum != applications | Gate reviewer cannot reconcile rollup to roster | Pre-build per-app final_disposition index; assert sum == len(applications) before emitting |
| 508 rollup mixes blocking with advisory | Gate thinks wave is compliant when it is not | Count blocking_violations_total separately; per references/disposition-rollup-rules.md |
| Sustainment drawdown hides transient costs | Finance refutes the savings claim on audit | List modernization transient cost as a negative adjustment in assumptions[] |
| Risks without citations | Gate reviewer rejects the readout as hand-waving | Require {artifact}:{section}:{finding-id} citation for every risk entry |

## Handoff Summary
When this skill completes, verify:
1. wave-outcome-synthesis.json validates against the schema.
2. wave-outcome-synthesis.md is produced as a sibling and fits in one page.
3. Every disposition-count, 508 stat, throughput constraint, and risk is traceable via evidence[].

Then proceed to: the G-DA gate reviewer (human or agent) uses the markdown as the primary decision artifact; the JSON feeds portfolio-manifest-generator on the final wave of the portfolio.
