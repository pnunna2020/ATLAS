---
name: sdr-area-logic
description: >
  Deprecated — use `extraction` instead. Retained as a redirect stub so old
  references keep resolving. Unique content (3-pass methodology, anomaly
  resolution rules, business rules catalog template) has been folded into
  the `extraction` skill.
deprecated: true
replaced_by: extraction
agent: sonnet
---

# Deprecated — use `extraction`

This skill is retained only as a redirect. Unique content has been folded
into `cross-cutting/skills/extraction/` (see the legacy-business-rules
discovery reference plus the migrated business-rules-catalog-template and
anomaly-resolution-rules YAML assets in that skill). Update registry
references to point at `extraction`.
