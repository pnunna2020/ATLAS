# In-Tree `Backup/` Folder Patterns

Detection, classification, and LOC-correction rules for `Backup/` folders
that duplicate source trees inside a repository — a VSS-era workflow
residue that still shows up in .NET repositories two decades later.

## Name-Pattern Inventory

Backup folders are named by developer convention and by Windows
Explorer's "Copy" default. The full name-pattern space:

| Pattern | Source | Example |
|---|---|---|
| `Backup/` | Manual rename | `wwDataBinder/Backup/` (CPDSS) |
| `Backup1/`, `Backup2/` | Manual numeric suffix | `CPDSSNET/Backup1/` |
| `Backup N/` (space + digit) | Windows "Copy" N-th time | `src/Backup 2/` |
| `Backup - Copy/` | Windows first Copy | `Solutions/Backup - Copy/` |
| `Backup - Copy (N)/` | Windows N-th Copy | `Solutions/Backup - Copy (3)/` |
| `Backup of Foo/` | Manual "Backup of X" | `Backup of CpdssTestUI/` |
| `Copy of Foo/` | Windows "Copy of" default | `Copy of CpdssTestUI/` |
| `Foo.bak/` | Suffix on folder name | `CpdssTestUI.bak/` |
| `Foo.old/` | Suffix on folder name | `CpdssTestUI.old/` |
| `OLD/`, `_OLD/`, `_backup/` | Ad-hoc developer conventions | Variable |

Canonical detection regex (normalized to POSIX bracket expressions):

```
^(Backup|Copy\ of\ .+|Backup\ of\ .+|.*\.(bak|old)|OLD|_OLD|_backup)(\d+|\ \d+|\ -\ Copy(\ \(\d+\))?)?$
```

Matching is case-insensitive on Windows-origin repositories. The regex
must be applied at every folder level, not just the repository root.

## The Sibling-Solution Signature

A Backup folder duplicates an active solution when its parent contains
a `.sln` whose base name appears inside the Backup subtree. Canonical
example, from CPDSS:

```
repo/DotnetComponents/wwDataBinder/
├── wwDataBinder.sln          ← main
├── wwDataBinder1.sln         ← duplicate-sln variant (VSS branch-by-copy)
├── Backup/
│   ├── wwDataBinder.sln      ← Backup copy
│   └── wwDataBinder.csproj
└── wwDataBinder.csproj
```

Three variants coexist in the same folder:

1. `wwDataBinder.sln` (current main)
2. `wwDataBinder1.sln` (a VSS branch-by-copy sibling)
3. `Backup/wwDataBinder.sln` (a Backup copy)

Which is authoritative is knowable only through build-output
inspection — the file tree alone cannot tell you. `likely_current` in
`duplicate-sln-variant-inventory.json` is advisory-only, based on
last-modified.

Set `duplicates_sibling_solution: true` on the Backup folder's row
whenever this pattern fires.

## Drift-vs-Dead Classification

Backup folders fall into four activity classes. Classification drives
severity and the LOC-correction math.

### `active`

Any child file in the Backup folder is newer than the corresponding
main-tree file with the same relative path. This is the dual-editing
hazard: a developer is actively modifying both copies. Severity
`blocker` — surface immediately.

Signals:
- `max(last_modified)` in Backup > `max(last_modified)` in main, OR
- `delta < 30 days` between Backup's most recent edit and main's

### `stale`

All Backup children are older than the main-tree counterpart, but not
by more than 180 days. The Backup may still be referenced in human
memory ("last month's attempt"). Severity `major` — flag for
disposition review, do not auto-delete.

### `dead`

All Backup children are older than the main-tree counterpart AND older
than 180 days. High-confidence safely-deletable, but still requires a
human-signed disposition decision. Severity `major` for LOC impact;
`minor` for cleanup priority.

### `build-output-only`

The Backup folder contains only build artifacts (`.dll`, `.pdb`,
`.exe`, `.obj`, `.ilk`, `.pch`). This is a build leak, not a source
duplicate. Severity `info`. EXCLUDE from LOC correction — it does not
contribute to double-counted source LOC.

## LOC-Correction Math

Discovery metrics without Backup correction overstate codebase size
by 2x in small repos (one Backup per solution) down to roughly 10% in
large repos (a few Backup folders inside a much larger active tree).

### Formula

```
backup_loc_to_subtract = sum(child_loc_estimate)
                        over Backup folders where
                          activity_class in {'stale', 'dead'}
                          AND duplicates_sibling_solution = true
                          AND activity_class != 'build-output-only'

corrected_loc = raw_loc_uncorrected - backup_loc_to_subtract
overstatement_ratio = raw_loc_uncorrected / corrected_loc
```

### Exclusions

- `active` Backup folders are NOT subtracted — both copies may contain
  unique logic that must be reconciled before correction is safe.
- `build-output-only` is NOT subtracted — the Backup carries no source
  LOC in the first place.
- Backup folders where `duplicates_sibling_solution: false` are NOT
  subtracted — they may be genuine archive material (reference copies,
  historical versions) unrelated to the current tree.

### `child_loc_estimate`

Sum line counts across these extensions (add VB6 / Classic ASP when
present):

- Source: `.cs`, `.vb`, `.asp`, `.aspx`, `.ascx`, `.asmx`, `.cshtml`,
  `.vbhtml`, `.ts`, `.js`, `.sql`
- Project/solution: `.sln`, `.csproj`, `.vbproj`, `.fsproj`
- Config (only when part of the duplicate source set): `.config`

Exclude generated files (`obj/`, `bin/`) and package directories
(`packages/`, `node_modules/`).

### Flagging

`overstatement_ratio > 1.10` triggers a `major`-severity finding in
`vss-risk-findings.json`. Discovery consumers (Rationalization cost
models, disposition recommenders) must consume `corrected_loc`, never
raw.

## Why Backup Folders Exist

VSS workflows predated cheap branches. Developers created Backup folders
to simulate a branch:

- **Point-in-time snapshot** before a risky refactor
- **A/B experiments** where both variants had to remain buildable
- **Pre-merge save** in the absence of reliable VSS branching
- **"Belt and suspenders"** redundancy against VSS database corruption
  (a real hazard — VSS had a reputation for corrupting bound repos)

Modern replacement: Git branches, Git worktrees, or `git stash`. The
cleanup-plan hint for a Backup folder should recommend:

1. If content-drift vs main: create a Git branch `backup/<name>` from
   a commit that contains the Backup's content, then delete the folder
2. If metadata-only-drift or identical: delete the folder
3. If active: STOP — resolve the dual-edit manually first, then apply
   one of the above

## Modernization-Era Replacement

Post-Backup cleanup should leave the repo with:

- One canonical `.sln` per solution (duplicate-sln variants resolved)
- Zero `Backup/` folders at any depth
- Git branches or tags preserving historically-significant Backup
  content
- A Disposition Execution commit documenting which Backup folders were
  deleted, merged, or preserved as branches

The `vss-legacy-detector` skill never performs these edits. It emits
the `cleanup_hint` text so the Disposition Execution line can
schedule a reviewed PR.

## Detection Heuristics Summary

- Walk every folder depth; apply the canonical Backup regex to each
  basename; case-insensitive
- Normalize space characters before matching (`Backup Copy` is a
  non-breaking-space variant seen in Word-copied folder names)
- For each Backup hit, compute `child_file_count`, `child_loc_estimate`,
  `last_modified_iso`, and `duplicates_sibling_solution`
- Classify `activity_class` from last-modified deltas against main
- Never delete; emit cleanup-plan hints only
