# VSS Bindings and `.vssscc` Patterns

Anatomy and detection rules for the five Visual SourceSafe (VSS) marker
file types that still leak into modern .NET repositories after 20+ years.

## The Five Marker Types

VSS bindings are distributed across five distinct file types. A complete
inventory MUST capture all five; missing any one leaves a phantom binding
that trips modern Visual Studio on solution open.

| File | Scope | Purpose |
|---|---|---|
| `*.vssscc` | Project | VSS binding metadata for a `.csproj` / `.vbproj` |
| `*.vspscc` | Project-user | Per-user VSS preferences (developer-specific) |
| `*.scc` (at solution root, e.g., `FooSolution.scc`) | Solution | Solution-level binding |
| `vssver.scc` | Folder | Per-folder version marker (one per bound folder) |
| `MSSCCPRJ.SCC` | Solution pointer | Points the solution at a VSS database path |

The five-type rule is counter-intuitive. Engineers searching for "`.vssscc`"
alone miss the four other types and conclude a repo is clean when it is
not. Always enumerate all five.

## `.vssscc` File Structure

A `.vssscc` file is an XML-ish, Windows-INI-adjacent key-value document.
Modern Visual Studio treats it as opaque metadata, but the structure is
stable and parseable. Canonical fields:

```
"FILE_VERSION" = "9237"
"ENLISTMENT_CHOICE" = "NEVER"
"PROJECT_FILE_RELATIVE_PATH" = ""
"NUMBER_OF_EXCLUDED_FILES" = "0"
"ORIGINAL_PROJECT_FILE_PATH" = ""
"NUMBER_OF_NESTED_PROJECTS" = "0"
"SOURCE_CONTROL_SETTINGS_PROVIDER" = "PROJECT"
```

For detection purposes the three load-bearing fields are:
- `SccProjectName` — logical project name inside the VSS database
  (e.g., `$/CHAPS/ChapsTestWeb`)
- `SccLocalPath` — relative filesystem path the binding applies to
  (typically `.`)
- `SccAuxPath` — VSS server UNC path or file URL
  (e.g., `\\faa-dev-vss\\VSSRepo`)
- `SccProvider` — GUID identifying the VSS provider
  (`{4CA58AB2-18FA-4F8D-95D4-32DDF27D184C}` is the canonical VSS 6.0
  provider GUID)

Any one of these four is sufficient evidence that the file is a VSS
binding, not a generic `.scc` file. Record all four when present.

## `.vspscc` and `CheckedOutByName` — the PII Leak

The `.vspscc` file is the per-user sibling to `.vssscc`. It carries the
same structural fields plus per-user preferences. Critically, VSS wrote
the current checkout holder's Windows username into `CheckedOutByName`:

```
"CheckedOutByName" = "jsmith"
"CheckedOutByUser" = "FAA\\jsmith"
```

These names are PII under most client compliance regimes (developer
identity tied to code ownership). The `vss-legacy-detector` skill MUST
redact these before emitting a finding:

- Replace the value with a boolean flag
  (`checked_out_by_name_redacted: true`)
- Never write the raw name into `vss-binding-inventory.json`
- If a secondary artifact (e.g., a disposition review note) needs the
  name, route through the same compliance-aware redaction pipeline used
  for `security-scan-review`

A finding that contains a raw developer name fails the Olympus schema
validator's `pii-leaked-in-finding` check.

## Solution-Level Bindings

Two files live at the solution root:

1. **`*.scc`** — mirrors the `.vssscc` structure but applies to the
   `.sln`. Rarely the same basename as the solution; often
   `MSSCCPRJ.SCC` replaces it in newer VSS versions.
2. **`MSSCCPRJ.SCC`** — a fixed-name file that points the solution at
   the VSS database. Canonical form:

```
SCC = This is a Source Code Control file

[FooSolution.sln]
SCC_Aux_Path = "\\faa-dev-vss\\VSSRepo"
SCC_Local_Path = "."
SCC_Project_Name = "$/FooSolution"
SCC_Provider = "MSSCCI:Microsoft Visual SourceSafe"
```

When `MSSCCPRJ.SCC` is present, the solution's `.sln` almost always
contains a `GlobalSection(SourceCodeControl)` block referencing the
same `SCC_*` values. Strip plans must remove both.

## `vssver.scc` — the Per-Folder Marker

`vssver.scc` is a binary-ish per-folder marker containing the last-known
VSS version stamp for files in that folder. Its sole diagnostic value is
presence/absence: its existence confirms the folder was under VSS
binding at some point. The internal version payload is obsolete.

Detection: glob-recursive for `vssver.scc`. Every hit is a finding row
in `vss-binding-inventory.json` with `file_type: folder-version-marker`.

Note: when `vssver.scc` is present without any `.vssscc` / `.vspscc` /
`MSSCCPRJ.SCC` in the repo, it is usually a stranded marker left behind
by a partial strip. File as severity `info` — not a live binding, but
a cleanup opportunity.

## VS-Version-Specific Handling

Different Visual Studio releases react differently to `.vssscc`
bindings with a dead or unreachable provider path:

| VS Version | Behavior on `.vssscc` with dead provider |
|---|---|
| VS 2010 / 2012 | Silently ignores; no prompt |
| VS 2013 | Hangs for 30-60s on solution open waiting for provider |
| VS 2015 | Hangs; sometimes requires task-kill |
| VS 2017+ | Prompts "Source control provider not available"; dismissible |
| VS 2019 / 2022 | Same prompt; noisier in the Output window |
| Rider | Silently ignores; no prompt |
| VS Code | Silently ignores; no prompt |

Because the prompt/hang is deterministic across the VS 2013+ line, a
`.vssscc` in a `.csproj` file should be ranked `critical` in
`vss-risk-findings.json`. The "dismissible" nature of the prompt does
not reduce severity — every developer who opens the solution pays.

## Strip-Plan Generation

Removing a `.vssscc` binding is a multi-file edit:

1. **Delete** the `.vssscc` / `.vspscc` file itself
2. **Edit** the sibling `.csproj` / `.vbproj` to remove four XML
   elements:
   - `<SccProjectName>`
   - `<SccLocalPath>`
   - `<SccAuxPath>`
   - `<SccProvider>`
3. **Delete** every `vssver.scc` in the project's folder tree
4. **Edit** the `.sln` to remove the `GlobalSection(SourceCodeControl)`
   block (if present) — the block's `SccNumberOfProjects`,
   `SccProjectUniqueName*`, and `SccProjectName*` lines must all go
5. **Delete** `MSSCCPRJ.SCC` at the solution root

This is emitted as `cleanup_hint` text in `vss-risk-findings.json`.
The skill NEVER executes the edits — a future Disposition Execution PR
owns the changes, allowing CODEOWNERS review before the strip lands.

## Co-Location with Modern Git

When `.vssscc` is tracked in Git AND points to a VSS server (even a
dead one), the binding is doubly version-controlled. Practical
implications:

- Merge conflicts on the binding file itself during branch merges
  (especially when two developers' `.vspscc` preferences differ)
- Restore operations (`git checkout` of an old revision) may
  re-introduce a binding that the team thought was stripped
- Git history carries the full `CheckedOutByName` PII trail —
  rewriting history may be required for full PII remediation

Surface as a `major` finding in `vss-risk-findings.json`. The cleanup
hint should recommend `git filter-repo` or BFG Repo-Cleaner when PII
remediation is required, with the caveat that history rewrite requires
force-push coordination.

## Detection Heuristics Summary

- Glob `**/*.vssscc` → project bindings
- Glob `**/*.vspscc` → project-user bindings (PII-redact)
- Glob `**/vssver.scc` → folder-version markers
- Glob at solution root for `MSSCCPRJ.SCC` and `*.scc`
- Parse every hit for `SccProjectName`, `SccLocalPath`, `SccAuxPath`,
  `SccProvider`
- Redact `CheckedOutByName` / `CheckedOutByUser` at parse time
- Emit one inventory row per file; emit one risk finding per
  severity-ranked hazard
- Emit strip-plan hint text; never execute edits
