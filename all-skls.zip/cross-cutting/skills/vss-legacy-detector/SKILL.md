---
name: vss-legacy-detector
description: >
  Detect Visual SourceSafe (VSS) legacy bindings, in-tree Backup folders,
  duplicate-suffix solution files, and VSS-era anti-patterns that still leak
  into .NET repositories 20+ years after VSS was retired. Emits five schema-
  validated artifacts — vss-binding-inventory.json, in-tree-backup-folder-
  inventory.json, duplicate-sln-variant-inventory.json, solution-file-drift-
  findings.json, vss-risk-findings.json — plus a loc-double-counting-
  correction.json delta that prevents Discovery metrics from overstating
  codebase size by 2x to 10%. Every finding carries {repo}:{file}:{line}
  traceability and a severity ranking that separates active dual-edit hazards
  from safely-deletable dead Backup folders. Runs as a Discovery conditional
  skill when tech_stack_contains visual-sourcesafe or vss, OR when the repo
  contains any of .vssscc, .vspscc, vssver.scc, MSSCCPRJ.SCC, or a Backup/
  Backup1/ Backup2/ folder at any depth. Triggers on VSS discovery, Visual
  SourceSafe discovery, .vssscc detection, Backup folder detection, or
  @vss-legacy-detector.
agent: sonnet
allowed-tools:
  - Read
  - Write
  - Grep
  - Glob
  - Bash
validation_commands:
  - "python -m olympus.validators.schema_validator vss-binding-inventory.json"
  - "python -m olympus.validators.schema_validator in-tree-backup-folder-inventory.json"
  - "python -m olympus.validators.schema_validator duplicate-sln-variant-inventory.json"
  - "python -m olympus.validators.schema_validator solution-file-drift-findings.json"
  - "python -m olympus.validators.schema_validator vss-risk-findings.json"
  - "python -m olympus.validators.schema_validator loc-double-counting-correction.json"
supported_stacks:
  - dotnet
  - csharp
  - vbnet
  - classic-asp
  - vb6
  - mixed-microsoft
anti_target_stacks:
  - pure-java
  - pure-python
  - static-site
  - pure-cdn-asset
failure_classes:
  - backup-folder-missed
  - vss-binding-missed
  - loc-double-counted
  - pii-leaked-in-finding
  - active-backup-auto-deleted
  - drift-vs-dead-misclassified
benchmark_tags:
  - discovery-vss-legacy
  - backup-folder-inventory
  - loc-correction
  - binding-cleanup-plan
---

# vss-legacy-detector

## Purpose
Visual SourceSafe (VSS) was Microsoft's first-party source-control system,
retired in 2005. Two decades later, VSS-era artifacts still leak into modern
.NET repositories migrated forward through TFS, Subversion, and finally Git.
These artifacts — `.vssscc` / `.vspscc` / `.scc` binding files, `vssver.scc`
version markers, the `MSSCCPRJ.SCC` solution pointer, and in-tree `Backup/`
folders duplicating entire solutions — are not cosmetic. They confuse modern
Visual Studio, pollute diffs, hide drift between forks, inflate Discovery
LOC counts by 2x-10%, and occasionally leak developer names
(`CheckedOutByName`) as PII. The general-purpose `dotnet-discovery-patterns`
skill only glances at these markers. This skill owns them as first-class
findings, emits severity-ranked risk records, and produces the LOC-
correction delta that keeps Rationalization's size-and-cost math honest.
Output also feeds a strip-plan hint for Disposition Execution — this skill
never auto-strips and never auto-deletes.

## Inputs
- Source repository containing `.vssscc`, `.vspscc`, `.scc`, `vssver.scc`,
  `MSSCCPRJ.SCC`, or `Backup` / `Backup1` / `Backup2` / `Backup N` /
  `Backup - Copy` folders at any depth.
- Application catalog entry stub (per
  `schemas/discovery/application-catalog-entry.schema.json`) —
  `application_id` and optional `tech_stack` containing
  `visual-sourcesafe` or `vss`.
- `.NET` architecture fingerprint from `dotnet-discovery-patterns` when
  available — the `.sln` / `.csproj` / `.vbproj` set Backup folders may
  shadow.
- File-system last-modified timestamps for Backup children.
- Reference patterns: `references/vss-bindings-and-vsssc-patterns.md`,
  `references/in-tree-backup-folder-patterns.md`.

## Outputs
- `vss-binding-inventory.json` — every `.vssscc`, `.vspscc`, solution-level
  `.scc`, `vssver.scc`, `MSSCCPRJ.SCC`. Per entry: `path`, `size_bytes`,
  `file_type` (`project-binding` | `project-user-binding` |
  `solution-binding` | `folder-version-marker` | `solution-pointer`),
  `citation`, optional `scc_project_name` / `scc_provider` / `scc_aux_path`,
  and a PII-redacted `checked_out_by_name_redacted` boolean.
- `in-tree-backup-folder-inventory.json` — every Backup folder. Per entry:
  `path`, `parent_folder`, `child_file_count`, `child_loc_estimate`,
  `duplicates_sibling_solution` (true when a sibling `.sln` matches
  base name), `last_modified_iso`, `activity_class` (`active` | `stale` |
  `dead` | `build-output-only`), `citation`.
- `duplicate-sln-variant-inventory.json` — sibling `.sln` variants
  (`Foo.sln` + `Foo1.sln` + `Foo.sln.bak` + `Foo.sln.old` +
  `Copy of Foo.sln`). Per entry: `base_name`, `variants[]` (`path`,
  `size_bytes`, `last_modified_iso`), `likely_current` (advisory),
  `citation`.
- `solution-file-drift-findings.json` — when a Backup copy of `.sln` /
  `.csproj` differs from main. Per entry: `main_path`, `backup_path`,
  `diff_summary` (added / removed / modified line counts), `drift_class`
  (`content-drift` | `metadata-only-drift` | `identical`), `severity`,
  `citation`.
- `vss-risk-findings.json` — severity-ranked records. `blocker` for active
  Backup duplicating a currently-edited solution; `critical` for `.vssscc`
  bindings in `.csproj` / `.vbproj` (VS prompts for a non-existent server
  on every open); `major` for dead Backup folders double-counting LOC or
  content-drift; `minor` for stale solution-level `.vssscc`; `info` for
  isolated `vssver.scc`. Per entry: `finding_id` (`VSS-RISK-NNN`),
  `severity`, `category`, `description`, `cleanup_hint`, `citation`.
- `loc-double-counting-correction.json` — per-repo LOC delta:
  `raw_loc_uncorrected`, `backup_loc_to_subtract`, `corrected_loc`,
  `overstatement_ratio` (raw / corrected), `per_backup_delta[]`,
  `citation`.

## Methodology
1. **Detect trigger or marker presence.** Check catalog `tech_stack` for
   `visual-sourcesafe` or `vss`. In parallel, glob the repo for `*.vssscc`,
   `*.vspscc`, `vssver.scc`, `MSSCCPRJ.SCC`, and any folder matching
   `^Backup(\d+| \d+| - Copy( \(\d+\))?)?$`. Either signal activates the
   skill. If neither fires, emit empty-inventory artifacts and exit — do
   not hallucinate.
2. **Inventory VSS bindings.** For every `.vssscc` and `.vspscc`, parse the
   XML-ish key-value payload and record `SccProjectName`, `SccLocalPath`,
   `SccAuxPath`, `SccProvider`. Never emit raw `CheckedOutByName` — redact
   to boolean. Classify by `file_type`: project-level (`.vssscc`),
   project-user (`.vspscc`), solution-level (`.scc` at solution root),
   folder-version (`vssver.scc`), solution-pointer (`MSSCCPRJ.SCC`). See
   `references/vss-bindings-and-vsssc-patterns.md`.
3. **Inventory Backup folders.** Walk the tree; for each folder matching
   the Backup regex, record path, child count, LOC estimate (sum of `.cs`,
   `.vb`, `.asp`, `.aspx`, `.sql`, `.sln`, `.csproj` line counts), and
   last-modified. Classify `activity_class` per
   `references/in-tree-backup-folder-patterns.md`: `active` (child newer
   than matching main-tree file), `stale` (within 180 days), `dead` (all
   children older than main and older than 180 days), `build-output-only`
   (Backup contains only `.dll`, `.pdb`, `.exe`, `.obj`).
4. **Detect sibling-solution duplication.** For each Backup, check the
   parent for a `.sln` whose base name appears in the Backup subtree.
   Set `duplicates_sibling_solution: true` and record the parallel pair.
   CPDSS's `wwDataBinder/Backup/` alongside `wwDataBinder.sln` and
   `wwDataBinder1.sln` in the same folder is the canonical three-variant
   case.
5. **Inventory duplicate `.sln` variants.** Group `.sln` files by base
   name after stripping trailing digits, ` - Copy`, `.bak`, `.old`, and
   `Copy of ` prefixes. Any group with ≥ 2 members is a cluster. Mark
   the most recently modified as `likely_current` (advisory only —
   build-output inspection is authoritative and out of Discovery scope).
6. **Compute solution-file drift.** For every Backup folder shadowing a
   `.sln` or `.csproj`, diff Backup vs main. Classify as `identical`
   (byte-identical), `metadata-only-drift` (only `<FileUpgradeFlags>`,
   `<UpgradeBackupLocation>`, or GUID timestamps differ), or
   `content-drift` (compile items, references, or target framework
   differ). Content-drift is `major` or higher — two forks of the same
   solution live in one repo.
7. **Rank risk findings.** Apply the severity ladder from Outputs.
   `blocker` only fires when an active Backup shadows a main-tree
   solution AND the last-modified delta is under 30 days (dual-editing
   hazard). `critical` fires on every `.vssscc` in a project file — the
   VS prompt-on-open symptom is deterministic. Emit one `VSS-RISK-NNN`
   per row.
8. **Compute the LOC-correction delta.** Sum `child_loc_estimate` over
   Backup folders classified `dead` or `stale` with
   `duplicates_sibling_solution: true`. Subtract from the repo raw LOC.
   Emit `overstatement_ratio = raw / corrected`. Flag ratio > 1.10 as a
   `major` finding in `vss-risk-findings.json`.
9. **Emit strip-plan hints, never strip-plan execution.** For each
   `.vssscc` / `.vspscc`, record the per-project edits a future cleanup
   PR would need (`<Scc*>` removal from `.csproj` / `.vbproj`, sibling
   `.vssscc` deletion, `GlobalSection(SourceCodeControl)` removal from
   `.sln`). `cleanup_hint` text only; never mutate repo files.
10. **Validate.** Run every output through
    `olympus.validators.schema_validator`. Self-check that no binding
    entry contains a raw `CheckedOutByName` string; the validator flags
    this as a PII leak.

## Tech-Stack Dispatch

| Trigger | Key patterns |
|---|---|
| `*.vssscc` present | Per-project VSS bindings; 5-element `Scc*` block to strip from `.csproj` |
| `*.vspscc` present | Per-user bindings; developer names often leak here |
| `MSSCCPRJ.SCC` at solution root | Solution-to-VSS-database pointer; obsolete provider path |
| `vssver.scc` inside folder | Per-folder version marker; exists in every bound folder |
| `Backup/` or `Backup\d+/` | In-tree solution duplicate; requires activity classification |
| `Backup - Copy/` or `Backup N/` | Windows Explorer "copy of" convention; same class as Backup1 |
| `Foo.sln` + `Foo1.sln` | VSS branch-by-copy residue; drift check required |
| `trunk/` + `branches/` | SVN, not VSS — flag as legacy-source-control-leak but distinguish |

Detection is mechanical. Overlap with `dotnet-discovery-patterns` is
intentional — that skill notes these markers in passing; this skill owns
them exhaustively.

## Gotchas
- **Five marker file types, not one.** `.vssscc` (project), `.vspscc`
  (project-user), bare `.scc` (solution), `vssver.scc` (folder),
  `MSSCCPRJ.SCC` (solution pointer). Missing any one leaves a phantom
  binding that trips modern VS on solution open.
- **Modern VS handles `.vssscc` by prompting for a dead provider.** VS
  2017+ prompts then fails silently; 2013/2015 hangs. Report `critical`
  for `.vssscc` in `.csproj` — every developer who opens the solution
  pays the cost.
- **Backup folder is not equivalent to unused.** CPDSS's
  `wwDataBinder/Backup/` coexists with `wwDataBinder.sln` +
  `wwDataBinder1.sln` in the same folder. Which is "current" is knowable
  only from build-output inspection. Never delete during Discovery.
- **All four suffix classes matter.** `.sln` + `.sln1` + `.sln.bak` +
  `.sln.old` are all classic VSS-era variants; numeric-only detectors
  miss `.bak` and `.old`. `Backup N/` with a space is the Windows
  Explorer "Copy" convention (`Backup - Copy/`, `Backup - Copy (2)/`);
  normalize spaces before matching.
- **Build-output-only Backup folders are a different class.** A Backup
  containing only `.dll`, `.pdb`, `.exe`, `.obj` is a build leak, not a
  source duplicate. Flag `build-output-only` and exclude from LOC
  correction.
- **Dead bindings and Backup folders are strippable but not auto-
  strippable.** Removing a `.vssscc` requires editing every `.csproj` /
  `.vbproj`. Emit cleanup-plan hints; never execute. Never delete Backup
  folders during Discovery either — humans sometimes A/B manually;
  Disposition Execution owns deletion.
- **`.vssscc` leaks PII via `CheckedOutByName`.** Developer names are
  PII under most compliance regimes. Store only a redacted flag; never
  echo the name into `vss-binding-inventory.json`.
- **Co-located `.vssscc` + modern Git means double version control.**
  The binding is tracked in Git AND points to a VSS server. Restore
  operations can produce merge conflicts on the binding file itself —
  a `major` finding.
- **SVN `trunk/` + `branches/` is a different legacy.** IACRA's
  `IACRATrainingPortal/` uses Subversion, not VSS. Same family
  (legacy source-control leak), different species. File under
  `svn-layout-leak`.

## Quality Rules
- [ ] Every VSS marker file (`.vssscc`, `.vspscc`, `.scc`, `vssver.scc`,
      `MSSCCPRJ.SCC`) has a row with `file_type` and `citation` populated.
- [ ] No row contains a raw `CheckedOutByName` value; the redaction flag
      is set when that field was present in the source.
- [ ] Every Backup folder has `activity_class` set to `active`, `stale`,
      `dead`, or `build-output-only`.
- [ ] Every duplicate-sln cluster has ≥ 2 variants with size and
      last-modified populated.
- [ ] Every drift finding cites `main_path` + `backup_path` and classifies
      as `identical`, `metadata-only-drift`, or `content-drift`.
- [ ] Every `vss-risk-findings.json` entry has a `VSS-RISK-NNN`
      `finding_id`, a severity in `blocker|critical|major|minor|info`,
      and a non-empty `cleanup_hint`.
- [ ] `loc-double-counting-correction.json` has `raw_loc_uncorrected`,
      `backup_loc_to_subtract`, `corrected_loc`, `overstatement_ratio` ≥
      1.0, with citations into the Backup inventory.
- [ ] No repo file is mutated; cleanup is `cleanup_hint` text only.
- [ ] SVN `trunk/` + `branches/` patterns file under `svn-layout-leak`,
      never the VSS inventory.

## Common Failure Modes
| Failure Mode | Symptom | Prevention |
|---|---|---|
| Backup folder missed (space, suffix variant) | `Backup - Copy/`, `Backup 2/` skipped; LOC under-counts | Normalize basename regex to `^Backup(\d+| \d+| - Copy( \(\d+\))?)?$`; walk every folder depth |
| VSS binding missed (only `.vssscc` inventoried) | `.vspscc` and `vssver.scc` phantoms leave VS prompting even after strip | Inventory all five marker types; emit separate `file_type` rows |
| LOC double-counted (Backup not subtracted) | Discovery overstates repo size 2x-10%; disposition misweights cost | Always emit `loc-double-counting-correction.json`; flag ratio > 1.10 as its own finding |
| PII leaked (`CheckedOutByName` echoed) | Secret-scan trips on the Discovery artifact; compliance rejects | Redact to boolean at parse time; never write the raw name |
| Active Backup auto-deleted | Human dual-editing broken; "current" variant lost | Never mutate repo files; emit cleanup-plan hints only |
| Drift vs dead misclassified | `content-drift` treated as safely-deletable; real fork hidden | Diff Backup vs main before classifying; default higher on ambiguity |

## Handoff Summary
When this skill completes, verify:
1. Every VSS marker type is inventoried with `file_type` and `citation`,
   and PII is redacted.
2. Every Backup folder is classified with `duplicates_sibling_solution`
   set.
3. `loc-double-counting-correction.json` shows ratio ≥ 1.0 and cites
   contributing Backup rows.
4. No repo file has been modified; cleanup is plan-only.
5. SVN layout leaks are filed under `svn-layout-leak`.

Then proceed to: `dotnet-discovery-patterns` (consumes inventories to
correct project enumeration), `catalog-application` (folds LOC correction
into catalog size), and `disposition-recommender` (weighs active-Backup
severity). The next gate is **G-DC** (Discovery Completeness).

## References
- `references/vss-bindings-and-vsssc-patterns.md` — anatomy of `.vssscc`,
  `.vspscc`, `.scc`, `vssver.scc`, `MSSCCPRJ.SCC`: XML-ish key-value
  structure, `SccProjectName` / `SccLocalPath` / `SccAuxPath` /
  `SccProvider` semantics, co-location rules, VS-version handling,
  strip-plan generation, PII redaction.
- `references/in-tree-backup-folder-patterns.md` — name patterns,
  sibling-solution detection, drift-vs-dead classification, LOC-
  correction math, activity detection, Git-branch replacement,
  cleanup-plan emission.

## Changelog
- 0.1.0 (2026-05-06) — Initial skill for VSS legacy detection. Covers
  five binding file types, Backup classification, duplicate-sln
  clustering, drift detection, severity-ranked risk findings, and LOC
  correction. Emits six artifacts; never mutates repo files; redacts
  PII. Feeds `dotnet-discovery-patterns`, `catalog-application`, and
  `disposition-recommender`.
