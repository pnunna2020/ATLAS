---
name: cato-evidence-validator
description: >
  Validate that generated cATO evidence artifacts (OSCAL SSP/SAR/POA&M) are
  schema-compliant and complete before gate review. Use before P5.2 certification.
  Triggers on cATO validation, OSCAL check, evidence review, or security
  artifact validation mentions.
agent: sonnet
allowed-tools:
  - Read
  - Bash
---

# cATO Evidence Validator

## Purpose
Quality gate for security artifacts — ensures OSCAL documents are valid and
all required controls have evidence before certification review.

## Workflow
1. Run the OSCAL validator from the `cato-compliance` skill on each artifact
2. Check control coverage: every applicable control has an implemented-requirement
3. Check evidence linkage: every control references specific by-components
4. Check POA&M items have scheduled dates and responsible parties
5. Generate validation summary

## Gotchas
- **Coverage ≠ compliance**: Having an SSP entry for AC-2 doesn't mean the
  control is actually implemented. This validator checks document completeness,
  not implementation correctness.
- **Moderate vs High baseline**: The control set differs. Verify config has
  correct FIPS 199 categorization before checking coverage.

## Quality Rules
- [ ] All OSCAL artifacts pass schema validation via the `cato-compliance` skill's OSCAL validator (OSCAL 1.1.2)
- [ ] Every applicable control has an implemented-requirement entry — coverage gaps are flagged
- [ ] Every control references specific by-component evidence — no controls with empty evidence
- [ ] POA&M items have scheduled completion dates and responsible parties — no vague items
- [ ] FIPS 199 categorization is verified in config before checking control coverage (Moderate vs High baseline)
- [ ] Validation distinguishes between document completeness and implementation correctness — completeness is checked, not claimed compliance

## Common Failure Modes
| Failure Mode | Symptom | Prevention |
|-------------|---------|------------|
| Wrong FIPS 199 baseline | Moderate control set checked for a High-categorized system; controls missing at certification | Verify FIPS 199 categorization from config before loading the applicable control set |
| Completeness mistaken for compliance | SSP has entries for all controls but evidence is placeholder text; ISSO rejects during review | Flag entries with generic or template text; require specific by-component references |
| POA&M items incomplete | Items have descriptions but no dates, owners, or compensating controls; certification delayed | Validate all four required fields (risk, date, owner, compensating control) per POA&M item |
| Stale evidence references | Evidence points to components that were refactored or renamed; links are broken | Cross-reference evidence artifacts against current codebase before certification submission |

## Phase 3 — ATLAS ChBA

> **Trace:** Closes P3-R34..R37 and P3-R44. Source: `docs/phase3/phase2-commitments.md` §B.5; gap matrix EDIT-5. Pairs with `cross-cutting/skills/cato-compliance` (Phase 3 EDIT) and the new `cross-cutting/skills/cato-runtime-evidence-collector` (P1).

### `--phase3-acceptance` mode

Add a new validation mode that runs after every pipeline build. It enforces:

1. **Per-family pass/fail emission.** All 10 named NIST 800-53 families (AC-3, AC-2, AC-4, IA-5, AU-2, AU-10, AU-12, SC-12, SC-28, SI-10) must each appear with a non-null `status` of `pass` | `fail` | `waived`. A missing family is a hard fail.
2. **Build-vs-evidence-freshness.** OSCAL artifact `metadata.last-modified` must be newer than the latest `deploy` job in the same pipeline run. If the deploy has rolled forward but the evidence has not, fail with `STALE_EVIDENCE`.
3. **Live-component reference check.** Every `by-component` MUST reference a service whose build hash exists in the current container registry tag set. Stub-only references (no running container) fail with `NO_LIVE_COMPONENT` — directly mitigates the P3-R5.2 risk (mocks-in-prod-path findings).
4. **CSAM-format export check.** When `--csam-export` is set, validate the CSAM-shaped JSON envelope before archive.

Invocation contract:

```bash
python scripts/validate_oscal.py \
  --mode phase3-acceptance \
  --evidence-dir evidence/oscal/<build-sha>/ \
  --build-sha "$GITHUB_SHA" \
  --image-digests-file evidence/build/image-digests.json
```

### OSCAL fragment validation (compliance-trestle)

Use `compliance-trestle` as the canonical OSCAL toolkit (per `docs/phase3/build-demo-skills-plan.md` §1.1). Key contracts:

- **Profile:** `profiles/phase3-named-families.json` — explicit catalog import limited to the 10 families.
- **SSP fragments:** one per service S1..S11; merged on emit.
- **SAR fragments:** one per pipeline run, references SAST/DAST/SCA scan outputs (handed in from `cross-cutting/skills/security-scan-review` Phase 3 EDIT).
- **POA&M fragments:** one per open finding from the security stage; auto-closed when a follow-up scan shows the finding is gone.

Validation steps in `--phase3-acceptance` mode:

1. `trestle validate -f evidence/oscal/<build-sha>/ssp.json` — schema validation.
2. `trestle validate -t profile -f profiles/phase3-named-families.json` — profile sanity.
3. `scripts/check_family_coverage.py --required AC-3,AC-2,AC-4,IA-5,AU-2,AU-10,AU-12,SC-12,SC-28,SI-10` — coverage gate.
4. `scripts/check_evidence_freshness.py --build-sha $SHA` — freshness gate.
5. `scripts/check_live_components.py --digests image-digests.json` — live-component gate.

### Runtime evidence schema (contract with `cato-runtime-evidence-collector`)

`cato-runtime-evidence-collector` (NEW skill, P1) emits incremental OSCAL deltas at runtime. The contract this validator enforces:

```jsonc
{
  "schema": "olympus.cato.runtime-evidence/v1",
  "build_sha": "<git-sha>",
  "emitted_at": "<rfc3339>",
  "family": "AU-12",
  "signal_source": "loki|prometheus|otel|inspector|guardduty",
  "signal_type": "audit-coverage|anomaly-rate|secret-rotation|...",
  "observation": { ... },
  "oscal_delta": { /* OSCAL POA&M-fragment or implemented-requirement update */ }
}
```

Validator rules for runtime evidence:

- [ ] `family` is one of the 10 named families.
- [ ] `signal_source` corresponds to a service component referenced in the SSP.
- [ ] `oscal_delta` validates against OSCAL 1.1.2 fragment schema.
- [ ] Stale runtime evidence (older than 1 h for SI-4-style families, older than 24 h for AU-12-style families) is flagged WARN, not FAIL.

### Chain-of-custody pattern (closes P3-R34..R37)

Every evidence artifact carries:

1. **Producer signature** — pipeline job ID + builder identity (e.g., GitHub Actions `${{ github.actor }}` + `${{ github.run_id }}`).
2. **Source-of-truth hash** — SHA-256 of the raw input the evidence summarizes (scan report, log query, OPA policy snapshot).
3. **Predecessor link** — pointer to the prior evidence artifact for the same family (forms a tamper-evident chain).
4. **Sigstore signature** (Phase 4 path; Phase 3 prototype emits the unsigned manifest with sigstore-ready fields populated).

The validator checks (1)–(3) on every fragment. (4) is enforced post-Phase-3.

### Phase 3 acceptance signals

- [ ] `--phase3-acceptance` exits 0 on a clean build.
- [ ] Family coverage report (`evidence/oscal/<build-sha>/family-status.json`) lists all 10 families with non-null status.
- [ ] Stale-evidence gate fails the pipeline when `last-modified` predates `deploy.completed_at`.
- [ ] Runtime-evidence schema rejects fragments missing `family` / `oscal_delta` fields.
- [ ] Chain-of-custody links resolve back to genesis (first emission for that family).

## Handoff Summary
When this skill completes, verify:
1. All OSCAL artifacts pass schema validation
2. Control coverage is complete for the correct FIPS 199 baseline
3. No controls have empty or placeholder evidence
4. POA&M items are fully specified
5. **Phase 3:** `--phase3-acceptance` reports pass; all 10 named families covered with live-component references
Then proceed to: P5.2 security certification review, and gate `G-V2` for security validation sign-off
