# AWS GovCloud Service Catalog

Per-service availability, FIPS endpoint status, FedRAMP tier restrictions, and
typical use in the FAA 8-app portfolio. Availability codes: **HIGH** = authorized
at FedRAMP High in GovCloud; **MODERATE** = authorized at FedRAMP Moderate
only; **NOT_AVAILABLE** = not authorized in GovCloud at either tier as of
2026-05. FIPS column lists whether the service exposes a FIPS-validated
endpoint that must be used at FedRAMP High.

Cross-reference this catalog when populating `target-architecture.json`
`services[]` rows. The `govcloud_service_availability_validator` consults this
file at validation time; a service row declaring a tier not listed here will
fail validation.

---

## Compute

| Service | GovCloud availability | FIPS endpoint | Tier notes | Typical FAA use |
|---|---|---|---|---|
| EC2 | HIGH | Yes | All instance families authorized; dedicated hosts available for tenant-isolation requirements | Rarely first-choice; use only for legacy workloads incompatible with container runtimes |
| ECS | HIGH | Yes | Fargate and EC2 launch types both authorized | DMS (ASP.NET Core), IACRA post-rearch container target, RMS aircraft-side services |
| EKS | HIGH | Yes | Kubernetes 1.27+ versions authorized; cluster-autoscaler and managed node groups supported | MSS suite (EKS for domain-scoped services), RMS airman-side NATURAL-replacement services |
| Fargate | HIGH | Yes | Fargate platform version 1.4.0+ authorized; Fargate Spot not available in GovCloud | Default compute for new .NET and Node services: IACRA, DMS |
| Lambda | HIGH | Yes | Newer runtimes (Python 3.12, Node 20, .NET 8) generally available 3-6 months after commercial | IACRA TIFF generation, MSS letter generation event handlers, low-traffic API endpoints |
| Batch | HIGH | Yes | Managed compute environments and job queues authorized | Drug-surveillance batch pipelines (CPDSS), DMS nightly reports |
| App Runner | NOT_AVAILABLE | N/A | Not authorized in GovCloud as of 2026-05 | Do not select — use Fargate instead |
| Lightsail | NOT_AVAILABLE | N/A | Not authorized in GovCloud | Do not select |

## Containers and orchestration

| Service | GovCloud availability | FIPS endpoint | Tier notes | Typical FAA use |
|---|---|---|---|---|
| ECR | HIGH | Yes | Image scanning and lifecycle policies authorized; pull-through cache authorized | Container image registry for all rearch apps |
| ECS Exec | HIGH | Yes | Requires SSM agent; audit logging to CloudWatch | Operator break-glass access to Fargate tasks |
| App Mesh | MODERATE | Yes | Service mesh for EKS/ECS; FedRAMP High boundary work-in-progress | MSS suite service-to-service mesh at Moderate |
| Service Connect (ECS) | HIGH | Yes | Native ECS service-discovery; authorized at High | Preferred over App Mesh for High-tier workloads |

## Database and data stores

| Service | GovCloud availability | FIPS endpoint | Tier notes | Typical FAA use |
|---|---|---|---|---|
| RDS (MySQL) | HIGH | Yes | All supported engine versions authorized | Rare in FAA portfolio |
| RDS (PostgreSQL) | HIGH | Yes | PostgreSQL 15+ authorized; some extensions lag commercial | Audit databases (DMS audit), standalone PG workloads |
| RDS (Oracle) | HIGH | Yes | Oracle 19c authorized with BYOL; 21c lag | MSS suite if staying on Oracle during transition |
| RDS (SQL Server) | HIGH | Yes | SQL Server 2019 Standard and Enterprise authorized; 2022 lag | DMS transitional, RMS aircraft-side transitional |
| Aurora (PostgreSQL) | HIGH | Yes | Aurora PostgreSQL 14+ authorized; pgvector lagged commercial availability — check at design time; pgAudit available | Default target for rearch data tier: IACRA, RMS both sides, MSS consolidation, DMS future-state |
| Aurora (MySQL) | HIGH | Yes | Aurora MySQL 3 authorized | Rare in FAA portfolio |
| DynamoDB | HIGH | Yes | Global tables across GovCloud partitions authorized; DAX authorized | Session stores, idempotency tokens, high-throughput key-value |
| DocumentDB | MODERATE | Yes | MongoDB-compatible; FedRAMP High work-in-progress | MSS suite document-store use cases |
| Neptune | NOT_AVAILABLE | N/A | Graph database not authorized in GovCloud | Do not select |
| Timestream | NOT_AVAILABLE | N/A | Time-series DB not authorized in GovCloud | Do not select — use Aurora PG time-series partitioning |
| Keyspaces (Cassandra) | MODERATE | Yes | Authorized at Moderate | Rare in FAA portfolio |
| QLDB | NOT_AVAILABLE | N/A | Quantum Ledger DB not authorized in GovCloud | Do not select — use DynamoDB + streams for audit-ledger patterns |
| MemoryDB (Redis) | HIGH | Yes | Redis 7+ authorized; multi-AZ | Cache layer for high-throughput read workloads |
| ElastiCache (Redis) | HIGH | Yes | Authorized at High; multi-AZ | Session cache, computed-view cache |
| ElastiCache (Memcached) | HIGH | Yes | Authorized at High | Legacy caching; prefer Redis |

## Storage

| Service | GovCloud availability | FIPS endpoint | Tier notes | Typical FAA use |
|---|---|---|---|---|
| S3 | HIGH | Yes | All storage classes authorized; S3 Object Lock authorized (WORM for 7-year retention) | TIFF archive (IACRA), document imaging (DIWS, RMS InfoImage successor), lakehouse storage |
| S3 Glacier / Deep Archive | HIGH | Yes | Authorized for long-term retention | 7-year retention for audit logs, cold archive for historical records |
| EFS | HIGH | Yes | Multi-AZ authorized; IAM authentication authorized | Shared filesystems for Fargate / EC2 where required |
| FSx for Windows File Server | HIGH | Yes | Authorized; AD integration authorized | Legacy Windows shares (DMS transitional), rare in rearch targets |
| FSx for Lustre | MODERATE | Yes | HPC-class filesystem; not commonly used in FAA | Do not select without strong justification |
| FSx for OpenZFS | MODERATE | Yes | Authorized at Moderate | Rare in FAA portfolio |
| FSx for NetApp ONTAP | MODERATE | Yes | Authorized at Moderate | Rare in FAA portfolio |
| Backup | HIGH | Yes | Centralized backup for RDS, Aurora, EFS, DynamoDB, S3 | Backup plan enforcement per FedRAMP control CP-9 |

## Networking and edge

| Service | GovCloud availability | FIPS endpoint | Tier notes | Typical FAA use |
|---|---|---|---|---|
| VPC | HIGH | N/A | Authorized at both tiers; flow logs mandatory per CIS benchmark | All workloads |
| Transit Gateway | HIGH | N/A | Authorized; inter-region peering within GovCloud partition authorized | Landing-zone backbone |
| Direct Connect | HIGH | N/A | Authorized; MACsec authorized | On-prem connectivity to FAA data centers |
| VPC Endpoints (Interface / Gateway) | HIGH | Yes | Interface endpoints for S3, DynamoDB, KMS, Secrets Manager authorized | Mandatory for private-only workloads |
| Route 53 | HIGH | Yes | DNS authorized; Resolver authorized; DNS Firewall authorized | Public-facing apps (IACRA, DMS) |
| CloudFront | HIGH | Yes | CDN authorized; WAF integration authorized; FIPS viewer policies authorized | Public-facing apps (IACRA); do not use for internal-only |
| WAF | HIGH | Yes | WAF v2 authorized; managed rule groups authorized | All public-facing apps |
| Shield Standard | HIGH | N/A | Automatic DDoS protection | All CloudFront and ALB endpoints |
| Shield Advanced | HIGH | N/A | Authorized; requires subscription | Consider for highest-traffic public apps |
| ALB | HIGH | Yes | FIPS-only security policies required at High | All Fargate / EKS / EC2 fronting |
| NLB | HIGH | Yes | Authorized at High | TCP-layer workloads only |
| API Gateway (REST / HTTP) | HIGH | Yes | Authorized at High; mutual-TLS authorized | Public API fronts for IACRA and DMS; internal API fronts for RMS and MSS |
| API Gateway (WebSocket) | MODERATE | Yes | Authorized at Moderate | Rare in FAA portfolio |
| Global Accelerator | HIGH | Yes | Authorized; cross-region routing within GovCloud partition | Multi-region DR for IACRA |
| PrivateLink | HIGH | Yes | Authorized at High | Partner integrations (Login.gov) |

## Identity and access

| Service | GovCloud availability | FIPS endpoint | Tier notes | Typical FAA use |
|---|---|---|---|---|
| IAM | HIGH | Yes | Authorized at both tiers | All workloads |
| IAM Identity Center | HIGH | Yes | Authorized at High; SAML 2.0 and OIDC federation | Staff SSO via PIV-via-ADFS |
| Cognito (User Pools) | HIGH | Yes | Authorized at High; federation with external SAML/OIDC IdPs authorized | Login.gov federation for IACRA public users; Cognito fronting for DMS public users |
| Cognito (Identity Pools) | HIGH | Yes | Authorized at High | STS credential vending for client-side SDK access |
| KMS | HIGH | Yes | FIPS endpoint mandatory at High; customer-managed keys mandatory for sensitive data | All encryption keys |
| CloudHSM | HIGH | Yes | FIPS 140-2 Level 3 | Digital-signature workloads (IACRA cert signing) |
| ACM | HIGH | Yes | Authorized at High; private CA authorized | TLS certs for public and private endpoints |
| Certificate Manager Private CA | HIGH | Yes | Authorized at High | Internal mutual-TLS for service-to-service |

## Secrets and configuration

| Service | GovCloud availability | FIPS endpoint | Tier notes | Typical FAA use |
|---|---|---|---|---|
| Secrets Manager | HIGH | Yes | Automatic rotation authorized; KMS-encrypted | Credential-class secrets with ≤ 30-day rotation |
| Systems Manager Parameter Store (SecureString) | HIGH | Yes | KMS-encrypted at rest | Configuration-class secrets, feature flags |
| Systems Manager (SSM) | HIGH | Yes | Session Manager, Patch Manager, Run Command authorized | Operator access, patching, run command |
| AppConfig | HIGH | Yes | Feature-flag and configuration delivery | Feature flags for staged rollouts |

## Observability and governance

| Service | GovCloud availability | FIPS endpoint | Tier notes | Typical FAA use |
|---|---|---|---|---|
| CloudWatch (Logs / Metrics / Alarms) | HIGH | Yes | Authorized at both tiers; Logs retention configurable to 7+ years | All workloads; retention aligned with federal 7-year floor |
| CloudWatch Synthetics | HIGH | Yes | Canary-based monitoring | Public-endpoint health canaries |
| X-Ray | HIGH | Yes | Distributed tracing authorized | Service-to-service tracing in MSS, RMS airman-side, IACRA |
| CloudTrail | HIGH | Yes | Management and data events authorized; Organizations-level trail authorized | Mandatory per FedRAMP AU-family controls |
| Config | HIGH | Yes | Authorized at both tiers; conformance packs authorized | Landing-zone guardrail enforcement |
| Security Hub | HIGH | Yes | Authorized at both tiers; CIS, PCI, NIST 800-53 standards enabled | Aggregated finding view per account |
| GuardDuty | HIGH | Yes | Threat detection authorized; EKS protection authorized | Runtime threat detection for all workloads |
| Macie | HIGH | Yes | S3 sensitive-data discovery authorized | DIWS imaging bucket, IACRA TIFF bucket scans |
| Inspector (v2) | HIGH | Yes | Container and EC2 vulnerability scanning authorized | Image scanning for ECR, EC2 scanning |
| Audit Manager | HIGH | Yes | Evidence collection for FedRAMP, NIST 800-53 | FedRAMP continuous compliance evidence (feeds `continuous-compliance-evidence-designer`) |
| Control Tower | HIGH | Yes | Landing-zone orchestration authorized; guardrails authorized | Landing zone per `aws-govcloud-landing-zone-designer` |
| Organizations | HIGH | Yes | SCPs, Organizational Units authorized | Multi-account topology |
| Trusted Advisor | HIGH | N/A | Cost, security, performance checks | Ongoing hygiene |

## Event, messaging, integration

| Service | GovCloud availability | FIPS endpoint | Tier notes | Typical FAA use |
|---|---|---|---|---|
| EventBridge | HIGH | Yes | Authorized at both tiers; schema registry authorized | Default event bus for cross-service integration |
| SNS | HIGH | Yes | Authorized at both tiers; FIFO authorized | Notifications, fan-out |
| SQS | HIGH | Yes | Standard and FIFO authorized; server-side encryption with KMS | Asynchronous work queues |
| Kinesis Data Streams | HIGH | Yes | Authorized at both tiers | High-throughput streaming (CDC ingest from DMS) |
| Kinesis Data Firehose | HIGH | Yes | Authorized at both tiers | Log delivery to S3, Redshift, OpenSearch |
| Kinesis Data Analytics | MODERATE | Yes | Authorized at Moderate | Rare in FAA portfolio |
| MSK (Managed Kafka) | HIGH | Yes | Authorized at both tiers; MSK Serverless authorized at Moderate | Event backbone for MSS suite, RMS airman-side CDC |
| MQ (ActiveMQ / RabbitMQ) | HIGH | Yes | Authorized at High | Legacy-protocol message brokers |
| Step Functions | HIGH | Yes | Authorized at both tiers; Express workflows authorized | Letter-generation orchestration, cert-issuance workflows |
| AppFlow | MODERATE | Yes | SaaS integration; FedRAMP High work-in-progress | Rare in FAA portfolio |

## Analytics and ML

| Service | GovCloud availability | FIPS endpoint | Tier notes | Typical FAA use |
|---|---|---|---|---|
| Glue | HIGH | Yes | Authorized at both tiers; Data Catalog authorized | Data lake catalog for analytics plane |
| Athena | HIGH | Yes | Authorized at both tiers | Ad-hoc queries over S3 data lake |
| Redshift | HIGH | Yes | Authorized at both tiers; RA3 nodes authorized; Spectrum authorized | Analytics warehouse for portfolio-level reporting |
| OpenSearch | HIGH | Yes | Authorized at both tiers; AD integration authorized | Document search (Unisys InfoImage → S3 + OpenSearch migration for RMS), log analytics |
| EMR | HIGH | Yes | Authorized at both tiers; EMR Serverless at Moderate | Batch analytics; rare in FAA rearch targets |
| QuickSight | HIGH | Yes | Authorized at both tiers | Portfolio-level BI dashboards |
| Lake Formation | HIGH | Yes | Authorized at both tiers | Data lake governance layer |
| DataZone | NOT_AVAILABLE | N/A | Not authorized in GovCloud as of 2026-05 | Do not select |
| SageMaker (Training / Hosting) | HIGH | Yes | Authorized at both tiers | Drug-surveillance ML (CPDSS), any future ML workloads |
| SageMaker Feature Store | MODERATE | Yes | Authorized at Moderate; High availability varies by region within GovCloud — verify before committing | MSS ML feature pipelines if applicable |
| SageMaker Model Monitor | HIGH | Yes | Authorized at High | Drift detection for deployed models |
| Bedrock | NOT_AVAILABLE | N/A | Not authorized in GovCloud as of 2026-05; revisit in future catalog updates | Do not assume availability; isolate any foundation-model inference path to SageMaker-hosted approved models |
| Comprehend | HIGH | Yes | Authorized at both tiers; medical entity extraction is a separate authorization | Text extraction from MSS letters, DIWS documents |
| Textract | HIGH | Yes | Authorized at both tiers | Forms extraction from scanned FAA documents |
| Rekognition | MODERATE | Yes | Authorized at Moderate | Rare in FAA portfolio |
| Translate | HIGH | Yes | Authorized at both tiers | Rare in FAA portfolio |
| Transcribe | MODERATE | Yes | Authorized at Moderate | Rare in FAA portfolio |

## Developer tools and CI/CD

| Service | GovCloud availability | FIPS endpoint | Tier notes | Typical FAA use |
|---|---|---|---|---|
| CodeCommit | HIGH | Yes | Authorized at both tiers | Source control for generated code; often superseded by agency GitHub Enterprise |
| CodeBuild | HIGH | Yes | Authorized at both tiers | CI build runner |
| CodePipeline | HIGH | Yes | Authorized at both tiers | Pipeline orchestration |
| CodeDeploy | HIGH | Yes | Authorized at both tiers; ECS / EKS / Lambda deployment authorized | Deployment controller for rearch apps |
| CodeArtifact | HIGH | Yes | Authorized at both tiers | Package repository for private dependencies |

---

## Region selection guidance

| Criterion | us-gov-west-1 | us-gov-east-1 |
|---|---|---|
| Service maturity | Longer availability history; typically receives new service authorizations first | Newer region; some services lag us-gov-west-1 by 6-12 months |
| Physical latency to FAA Mid-Atlantic | Higher (cross-country) | Lower |
| Disaster recovery | Pairs with us-gov-east-1 for cross-region DR | Pairs with us-gov-west-1 for cross-region DR |
| Typical primary placement | Default for FedRAMP High workloads needing maximum service coverage | Default when latency to Mid-Atlantic is load-bearing and the service set is sufficient |

Record the selection rationale on `target-architecture.json`. Do not leave
region selection implicit.

## FIPS endpoint guidance

At FedRAMP High, every cryptographic operation must use a FIPS-validated
endpoint. The canonical endpoint forms:

- `kms.us-gov-west-1.amazonaws.com` → non-FIPS (do not use at High)
- `kms-fips.us-gov-west-1.amazonaws.com` → FIPS (required at High)
- ALB FIPS security policy: `ELBSecurityPolicy-FS-1-2-Res-2020-10` or newer FIPS-only
- CloudFront FIPS viewer policy: `TLSv1.2_2021` with FIPS-only ciphersuite subset

Every service row in `target-architecture.json` that performs a cryptographic
operation at FedRAMP High must record the FIPS-validated endpoint class, not
the default endpoint. The `fedramp_tier_validator` enforces this at validation
time.
