---
name: aws-govcloud-target-architecture
description: >
  Emit a per-app target-state AWS GovCloud architecture with service-by-service
  placement, FedRAMP-tier-aware constraints, region and availability-zone
  layout, identity boundary, observability stack, secrets strategy, and cost
  envelope rationale. Produces target-architecture.json and a 1-2 page
  target-architecture-narrative.md per application. Inherits from
  aws-target-architecture but narrows the service catalog to what is actually
  authorized in us-gov-west-1 / us-gov-east-1 at the claimed FedRAMP tier
  (High for RMS, IACRA, DMS; Moderate for the MSS suite), enforces
  FIPS-validated endpoints for cryptographic operations at FedRAMP High, and
  cites NIST 800-53 control families inherited from the GovCloud P-ATO per
  service selection. Triggers on target architecture, GovCloud design, FedRAMP
  target state, or @aws-govcloud-target-architecture.
agent: sonnet
allowed-tools:
  - Read
  - Write
  - Grep
  - Bash
validation_commands:
  - "python -m olympus.validators.schema_validator target-architecture.json"
  - "python -m olympus.validators.fedramp_tier_validator target-architecture.json"
  - "python -m olympus.validators.govcloud_service_availability_validator target-architecture.json"
supported_stacks:
  - aws
  - aws-govcloud
  - dotnet
  - java
  - nodejs
  - python
  - oracle
  - sqlserver
  - postgresql
  - natural
  - adabas
anti_target_stacks:
  - on-premises-only
  - azure-gov-exclusive
  - gcp
failure_classes:
  - govcloud-service-unavailable
  - fedramp-tier-mismatch
  - fips-endpoint-omitted
  - missing-nist-control-citation
  - region-az-layout-incomplete
  - cost-rationale-omitted
benchmark_tags:
  - architecture-target-state
  - govcloud-compliance
  - fedramp-tier-gating
  - nist-control-inheritance
---

# aws-govcloud-target-architecture

## Purpose
Produce the authoritative per-app target-state architecture for a FAA workload
landing in AWS GovCloud. This is the architecture-phase artifact that feeds
Sub-factor 3 of the SOO evaluation (per
`/Users/pnunna/Documents/SOO-Announcement/Phase2_Evaluation_Criteria.md` §5),
and it is the binding service-selection record that downstream skills
(`transition-strategy-designer`, `service-interaction-mapper`,
`fedramp-posture-designer`, `rationalization-to-architecture-traceability`)
consume. A generic `aws-target-architecture` emits a cloud-agnostic shape.
This skill narrows that shape to the GovCloud catalog: it rejects services
that are not authorized in us-gov-west-1 or us-gov-east-1 at the declared
FedRAMP tier, requires FIPS-validated endpoints for cryptographic operations
at FedRAMP High, pins a region plus multi-AZ layout, cites the NIST 800-53
control families inherited from the GovCloud P-ATO per service, and records
a cost-envelope rationale sufficient for the Sub-factor 3 written narrative.

## Inputs
- Application catalog entry (`schemas/discovery/application-catalog-entry.schema.json`) —
  `application_id`, `primary_language`, `tech_stack`, `archetype`, data stores.
- Rationalization output — `disposition-recommendation.json` — confirms the app
  is Rearchitect / Replatform / Replace / Consolidate (not Retire / Retain).
- ATO boundary analysis — `ato-boundary.json` (from `ato-boundary-analyzer`) —
  supplies the declared FedRAMP tier (High / Moderate) and the data
  classifications that flow through the workload.
- Domain decomposition — `domain-decomposition.json` (from
  `faa-domain-decomposition-designer`) — supplies the bounded-context shape
  so the target architecture aligns with service boundaries, not legacy
  module boundaries.
- GovCloud service catalog reference — `references/aws-govcloud-service-catalog.md` —
  per-service GovCloud availability, FIPS endpoint status, tier restrictions,
  and typical FAA use.
- Landing-zone context (when present) — `aws-govcloud-landing-zone.json`
  (from `aws-govcloud-landing-zone-designer`) — supplies the shared VPC
  topology, Transit Gateway, shared services VPC, and guardrail SCPs. The
  target architecture must fit inside the landing zone, not redesign it.

## Outputs
- `target-architecture.json` per application. Required shape:
  - `app_id` — matches the catalog entry exactly.
  - `fedramp_tier` — `High` | `Moderate` (the ATO-declared value).
  - `region` — `us-gov-west-1` | `us-gov-east-1` with selection rationale.
  - `availability_zones` — array of AZ ids used; minimum of two for any
    production tier; three for FedRAMP High stateful services.
  - `services[]` — one row per AWS service chosen. Each row:
    - `name` (e.g., `Aurora PostgreSQL`, `ECS Fargate`, `CloudFront`)
    - `type` (`compute` | `data` | `event` | `identity` | `observability`
      | `secrets` | `edge` | `network` | `analytics` | `ml`)
    - `purpose` — one-sentence statement of what it does for this app.
    - `tier_tier_rationale` — why this service is allowable at the declared
      FedRAMP tier; references `references/aws-govcloud-service-catalog.md`
      for the authorization evidence.
    - `nist_controls_inherited[]` — 800-53 control families (e.g., `AC-2`,
      `SC-12`, `SI-4`) inherited from the GovCloud P-ATO for this service.
  - `service_interactions[]` — per edge: `source_service`, `target_service`,
    `protocol` (`https-fips` | `tls-12-fips` | `grpc-mtls` | `sqs` |
    `eventbridge` | `kinesis-stream`), and `data_classification`.
  - `data_stores[]` — per store: name, type (`aurora-postgresql` | `rds-*`
    | `dynamodb` | `s3` | `opensearch` | `efs` | `fsx`), encryption
    (`kms-fips` mandatory at High), backup posture, and the bounded context
    that owns it (per `domain-decomposition.json`).
  - `identity_boundary` — describes the Cognito / Login.gov federation /
    PIV-via-ADFS topology, the user pools, and the token exchange path.
  - `observability_stack` — CloudWatch logs / metrics, X-Ray traces, AWS
    Config, Security Hub aggregation, CloudTrail retention.
  - `secrets_strategy` — Secrets Manager vs Parameter Store split, rotation
    cadence, KMS key scoping.
  - `cost_envelope_rationale` — narrative (not numeric) explanation of cost
    drivers: compute class, data-transfer posture, multi-AZ replication
    multiplier, reserved-capacity assumptions.
- `target-architecture-narrative.md` — 1-2 page human-readable narrative
  summarizing the decisions, suitable for inclusion in the Sub-factor 3
  written response. Plain Markdown; no diagrams (those come from
  `architecture-diagram-generator`).

## Methodology
1. Read the catalog entry and pin `app_id`. Read `disposition-recommendation.json`
   to confirm the app is subject to architecture work (not Retire or Retain).
   Read `ato-boundary.json` to extract the FedRAMP tier; if absent, fail
   fast — do not guess.
2. Read `aws-govcloud-landing-zone.json` (when present) and record the
   shared VPC and Transit Gateway layout. The target architecture lives
   inside this landing zone; it must not re-declare the VPC CIDR or the
   peering topology.
3. Select region. Prefer `us-gov-west-1` for FedRAMP High workloads (longer
   service maturity). Select `us-gov-east-1` only when the landing zone
   dictates it or when disaster-recovery topology requires the opposite
   region. Record the selection rationale on the artifact.
4. Select availability zones. Minimum two for any production tier; three
   for FedRAMP High stateful services (RDS / Aurora, DynamoDB Global,
   OpenSearch). Record the AZ ids and the service-to-AZ placement.
5. Select services per tier. Walk the workload's logical components
   (web, API, worker, batch, data store, cache, queue, event bus, identity,
   observability, secrets) and pick a GovCloud-available service for each.
   Cross-check `references/aws-govcloud-service-catalog.md` for the claimed
   tier. If a service is not authorized at the declared tier in GovCloud,
   reject the selection and record the reason.
6. Enforce FIPS endpoints. At FedRAMP High, every cryptographic operation
   must use a FIPS-validated endpoint. KMS uses `*.kms-fips.us-gov-*.amazonaws.com`.
   TLS terminations at CloudFront, ALB, and API Gateway must use a FIPS
   ciphersuite policy. Record the endpoint class on each service row.
7. Map NIST 800-53 control families per service. GovCloud's P-ATO inherits
   a large share of the infrastructure controls (AC-family access controls,
   SC-family communications protections, SI-family integrity controls,
   AU-family audit controls). Record which control families each service
   inherits so the later `nist-control-automation-mapper` can close the loop
   between inheritance and automation.
8. Describe the identity boundary. For public-facing apps (IACRA, DMS
   external-facing components), Cognito fronts Login.gov federation for
   public users and PIV-via-ADFS for staff. For internal-only apps (RMS
   aircraft-reg back office, MSS suite), Cognito fronts PIV-via-ADFS only.
   Record the user pool, identity provider, and token exchange path.
9. Describe the observability stack and secrets strategy explicitly.
   CloudWatch logs with mandated retention per the agency policy,
   X-Ray sampling rate, AWS Config rules enforcing the landing-zone
   guardrails, Security Hub as aggregator, CloudTrail retention aligned
   with the 7-year federal retention floor. Secrets Manager for
   credential-class secrets with ≤ 30-day rotation; Parameter Store
   SecureString for configuration-class secrets.
10. Write `cost_envelope_rationale`. This is narrative, not numeric —
    name the drivers (compute class, data-transfer egress, multi-AZ
    replication, GovCloud premium) so the evaluator can reason about cost
    without a line-item model (which is Phase 3 work).
11. Render the narrative Markdown. 1-2 pages. Sections: Summary,
    Compute & Runtime, Data Tier, Identity, Observability, Secrets,
    Cost & Capacity Envelope. Cite the artifact's structured JSON rows
    in-line where a decision is load-bearing.
12. Validate. The JSON must pass its schema and both custom validators
    (`fedramp_tier_validator`, `govcloud_service_availability_validator`).
    The narrative is not schema-validated but is linted against a minimum
    section set.

## Tech-Stack Dispatch

| Workload profile | Preferred compute | Preferred data tier | FedRAMP tier |
|---|---|---|---|
| IACRA (.NET WebForms + VB.NET + Node) | ECS Fargate (containerized .NET rewrite), Lambda for TIFF generation | Aurora PostgreSQL (from SQL Server) | High |
| RMS airman-side (z/OS NATURAL/ADABAS) | EKS for NATURAL-replacement services | Aurora PostgreSQL (from ADABAS via DMS + custom CDC); S3 + OpenSearch (from Unisys InfoImage) | High |
| RMS aircraft-side (Windows SQL Server) | ECS Fargate | Aurora PostgreSQL (from SQL Server) | High |
| MSS suite (AMCS / MedXPress / CHAPS / CPDSS / DIWS) on shared Oracle | EKS (domain-scoped services) | Aurora PostgreSQL (domain-scoped DBs from the shared Oracle schema) | Moderate |
| DMS (ASP.NET Core + Angular 8 + SQL Server + Postgres audit) | ECS Fargate (already containerizable) | Aurora PostgreSQL (migrate from SQL Server) + RDS PostgreSQL (audit) | High |

## Gotchas
- GovCloud region service availability lags commercial AWS by months to
  years. Do not assume a service launched in commercial is also in
  us-gov-west-1. Cross-check `references/aws-govcloud-service-catalog.md`
  before emitting the row.
- Aurora PostgreSQL in GovCloud is missing some extensions available in
  commercial (notably some pgvector and pgAudit minor versions). Record
  the extension set on the data store row; downstream
  `aurora-postgresql-data-modeling` will reject designs that depend on
  a missing extension.
- Amazon Bedrock is not authorized in GovCloud High as of 2026-05. If
  the workload requires foundation-model inference, isolate the inference
  boundary to a non-Bedrock path (SageMaker endpoint hosting an approved
  model) or defer the capability to a future phase. Do not assume
  Bedrock availability.
- KMS FIPS endpoints are mandatory for cryptographic operations at
  FedRAMP High. Using the non-FIPS endpoint even once is a finding.
  Every service that calls KMS must be pinned to
  `*.kms-fips.us-gov-*.amazonaws.com`.
- FIPS-validated TLS ciphers only. The modern ELB security policies
  that end in `-FIPS-*` are the only compliant choices at FedRAMP High;
  the default security policy is not FIPS-only.
- Public-facing apps (IACRA, DMS external components) must terminate
  TLS at CloudFront or a regional WAF-fronted ALB. Terminating at the
  origin directly is a finding because the WAF cannot inspect pre-TLS
  traffic.
- Cross-region replication requires Transit Gateway + peered VPCs; there
  is no VPC peering across GovCloud partitions and commercial partitions.
  Replication to a commercial region is blocked by partition isolation.
- Managed NAT Gateway HA differs between commercial and GovCloud: some
  NAT Gateway availability-zone-local modes were delivered later in
  GovCloud; design for AZ-local NAT per AZ, not a single regional NAT.
- Service quotas in GovCloud are often smaller than commercial defaults
  (e.g., Lambda concurrent executions, API Gateway requests per second).
  Record anticipated quota needs on the cost-envelope rationale; quota
  increases must be requested before go-live.
- FedRAMP High inheritance from the GovCloud P-ATO covers infrastructure
  controls but not app-layer controls. AC-4 (information flow enforcement)
  at the app layer, AU-6 (audit review) at the app layer, and SI-10 (input
  validation) at the app layer are still the app team's responsibility.
  Record this split explicitly in `nist_controls_inherited[]` so the
  evaluator does not over-credit inheritance.
- SageMaker Feature Store availability varies by region within GovCloud.
  Verify the offline store backing (S3) and online store backing (managed
  DynamoDB) are both in the selected region before committing.
- The choice between us-gov-west-1 and us-gov-east-1 is load-bearing:
  latency to the typical FAA co-located workload in the Mid-Atlantic is
  lower from us-gov-east-1, but us-gov-west-1 has longer service
  availability history. Record the rationale; do not leave it implicit.

## Quality Rules
- [ ] `app_id` equals the catalog entry's `application_id` exactly.
- [ ] `fedramp_tier` matches `ato-boundary.json` exactly (no upgrade or
      downgrade without an explicit linked authorization change).
- [ ] `region` is one of `us-gov-west-1` | `us-gov-east-1` with a
      rationale string of at least one sentence.
- [ ] `availability_zones[]` has ≥ 2 entries (≥ 3 for FedRAMP High
      stateful services).
- [ ] Every row in `services[]` cites the GovCloud catalog for its tier
      authorization and records `nist_controls_inherited[]` non-empty.
- [ ] Every cryptographic service at FedRAMP High uses a FIPS-validated
      endpoint (checked by `fedramp_tier_validator`).
- [ ] Every service chosen is listed as available at the declared tier
      in `references/aws-govcloud-service-catalog.md` (checked by
      `govcloud_service_availability_validator`).
- [ ] `identity_boundary` names the Cognito user pool, federation
      partners, and the token exchange path.
- [ ] `observability_stack` names retention (CloudWatch logs, CloudTrail)
      aligned with the 7-year federal retention floor or cites the
      applicable policy deviation.
- [ ] `cost_envelope_rationale` names at least three cost drivers and
      the multi-AZ multiplier explicitly.
- [ ] Narrative Markdown has the seven required sections and is 1-2 pages.

## Common Failure Modes
| Failure Mode | Symptom | Prevention |
|---|---|---|
| GovCloud service unavailable at declared tier | Validator rejects because the service row points to a commercial-only service or to a Moderate-only service declared under High | Cross-check `references/aws-govcloud-service-catalog.md` per service; never carry a commercial-AWS reference architecture into GovCloud unmodified |
| FedRAMP tier mismatch with ATO boundary | Tier in `target-architecture.json` contradicts `ato-boundary.json`; downstream FedRAMP posture and NIST mapping misalign | Read `ato-boundary.json` first; fail fast when the value is missing; never infer the tier from the app name |
| FIPS endpoint omitted at High | KMS or TLS path uses the non-FIPS endpoint; finding at later security review blocks gate G-04b | Pin every cryptographic interaction to the FIPS endpoint; record the endpoint class on each service row |
| Missing NIST control citation | `nist_controls_inherited[]` is empty or generic; NIST automation mapper cannot reconcile inheritance | Cite 800-53 control families per service with the GovCloud P-ATO as the evidence source; do not leave the array empty |
| Region/AZ layout incomplete | Single-AZ placement for a production tier; DR posture undefined | Default to multi-AZ everywhere; require three AZs for High stateful services; record AZ ids, not just count |
| Cost rationale omitted | `cost_envelope_rationale` is absent or one line; evaluator cannot score capacity planning | Write at least three cost drivers and the multi-AZ multiplier; narrative not numeric, but non-empty |

## Handoff Summary
When this skill completes, verify:
1. `target-architecture.json` exists per app, passes its schema, passes
   `fedramp_tier_validator`, and passes
   `govcloud_service_availability_validator`.
2. `target-architecture-narrative.md` exists per app with the seven
   required sections and is 1-2 pages.
3. Every service is authorized at the declared FedRAMP tier in GovCloud
   per the service-catalog reference.
4. Every cryptographic path at FedRAMP High pins a FIPS-validated
   endpoint.
5. `nist_controls_inherited[]` is populated per service with 800-53
   control families.

Then proceed to: `service-interaction-mapper` (consumes the service list
and produces the edge-level topology), `transition-strategy-designer`
(consumes the target architecture to sequence the cutover mechanics),
`rationalization-to-architecture-traceability` (closes the loop between
disposition rows and target-architecture elements for Sub-factor 3
Consistency Check §8.1), and `architecture-diagram-generator` (renders
the logical, deployment, and data-flow views). The next gate is
**G-DA** (Design Acceptance).

## References
- `references/aws-govcloud-service-catalog.md` — per-service GovCloud
  availability, FIPS status, tier restrictions, typical FAA use.
- `schemas/architecture/target-architecture.schema.json` — canonical
  target-architecture JSON shape.
- `/Users/pnunna/Documents/SOO-Announcement/Phase2_Evaluation_Criteria.md`
  §5 Sub-factor 3 — written-response scoring rubric this skill feeds.

## Changelog
- 0.1.0 (2026-05-06) — Initial skill. Narrows generic
  `aws-target-architecture` to the GovCloud service catalog, pins FedRAMP
  tier per ATO boundary, enforces FIPS endpoints at High, cites NIST
  800-53 control-family inheritance per service, and emits a 1-2 page
  narrative alongside the structured JSON. Covers the four FAA app
  suites (IACRA, RMS dual-side, MSS five-app shared-Oracle, DMS).
