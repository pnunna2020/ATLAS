---
name: svn-trunk-branches-layout-detector
description: >
  Detect Subversion's canonical `trunk/`, `branches/`, `tags/` layout
  preserved inside a git-tracked repository. When an SVN repo was
  migrated to git, the `trunk/` + `branches/` hierarchy is often
  retained verbatim because the dev team's muscle memory depends on
  it. IACRA's `IACRATrainingPortal/` carries this pattern
  (`trunk/db/`, `trunk/src/`, `branches/Portal_Before_Facelift/`).
  These layouts confuse git-native tooling (diffs cross branches,
  code search finds duplicated trunk/branch copies, blame is
  wrong). Flag for cleanup. Runs as Discovery conditional when
  the repo has a directory containing both `trunk/` and
  `branches/` children. Triggers on SVN layout detection, legacy-
  version-control cleanup, or @svn-trunk-branches-layout-detector.
agent: sonnet
allowed-tools:
  - Read
  - Write
  - Grep
  - Glob
validation_commands:
  - "python -m olympus.validators.schema_validator svn-layout-inventory.json"
  - "python -m olympus.validators.schema_validator svn-branch-drift-findings.json"
supported_stacks:
  - svn
  - subversion
  - legacy-vcs
anti_target_stacks:
  - git-native
  - github-flow
  - gitflow
failure_classes:
  - branches-counted-as-features
  - trunk-loc-double-counted-with-branch
  - tags-ignored
  - non-svn-directory-named-trunk-misclassified
benchmark_tags:
  - discovery-structure
  - svn-legacy-layout
  - vcs-migration-cleanup
---

# svn-trunk-branches-layout-detector

## Purpose
Detect SVN-style directory layouts preserved inside git repos and
emit findings that guide cleanup. Legacy layout confuses modern
tooling, inflates LOC counts via branch copies, and makes git
blame useless across the "branch" boundaries.

## Inputs
- Repository tree.

## Outputs
- `svn-layout-inventory.json` — per occurrence: `{parent_path,
  trunk_path, branches_paths[], tags_paths[], branch_count,
  trunk_loc, branches_total_loc, earliest_branch_name,
  latest_branch_name}`.
- `svn-branch-drift-findings.json` — per branch: `{branch_path,
  drift_from_trunk (diff line count), age_days, probably_dead
  (true if age_days > 730)}`.

## Methodology
1. Walk directory tree. For each directory, check if children
   include BOTH `trunk` and `branches`.
2. For confirmed SVN layouts, inventory `trunk/` contents,
   `branches/*/` subdirs, `tags/*/` subdirs.
3. Compute LOC per trunk and per branch.
4. Emit drift findings: per-branch diff against trunk.
5. Flag branches > 2 years old as probably-dead.

## Tech-Stack Dispatch

No external references.

## Gotchas
- A directory named `trunk/` WITHOUT a sibling `branches/` is
  probably a naming coincidence, not SVN layout.
- Old tags in `tags/` are historical; not active branches.
- Branch-copied projects double-count LOC — correct Discovery
  metrics.
- Some teams retained trunk/branches in migration on purpose
  (legal audit preservation); flag but don't auto-remove.

## Quality Rules
- [ ] Every trunk/branches pair inventoried.
- [ ] LOC corrected for branch duplication.
- [ ] Dead-branch findings emitted for > 2 years.
- [ ] Every record cites `{repo}:{file}:{line}`.

## Common Failure Modes

| Failure Mode | Symptom | Prevention |
|---|---|---|
| Branch LOC double-counted | Reported code size is 2x actual | Subtract shared code |
| False positive on `trunk/` | Unrelated dir named trunk misclassified | Require sibling `branches/` |

## Handoff Summary
SVN layouts inventoried; cleanup findings emitted. Proceed to
`migration-strategy-advisor` for VCS cleanup planning.

## References
None.

## Changelog
- 0.1.0 (2026-05-07) — Initial skill. Authored as ATLAS-R-19.
