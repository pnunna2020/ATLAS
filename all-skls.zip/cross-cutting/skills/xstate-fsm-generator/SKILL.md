---
name: xstate-fsm-generator
description: Generate XState v5 finite-state machines from declarative state-flow specs, with typed events, guards, and persistence hooks suitable for journey FSMs (e.g., FAA pilot certification T1–T8).
phase: generate
category: modernization
status: stub-2026-05-27
maturity: minimal
inputs:
  - fsm-spec.yaml              # states, events, guards, actions, context shape
  - persistence-strategy.yaml  # snapshot-vs-event-sourced persistence choice
outputs:
  - apps/api/src/domain/workflow/<name>-fsm.ts
  - apps/api/src/domain/workflow/<name>-persistence.ts
  - docs/contracts/<name>-fsm.json
contract_invariants:
  - "Every state has a defined entry/exit semantic OR is documented as 'pure transition'"
  - "Every transition has either an explicit guard or a comment noting why it's unconditional"
  - "FSM context shape is fully typed (no any)"
  - "Persistence layer round-trips state without information loss"
related_skills:
  - temporal-workflow-scaffolder    # FSM drives workflow design
  - decomposition-patterns          # FSM is one of the documented patterns
  - node-api-generation             # API handlers consume FSM state
---

# xstate-fsm-generator

## Purpose

Produce a typed, persistable XState v5 finite-state machine from a declarative spec. Used by the ATLAS Phase 3 prototype to model the 8-stage pilot certification journey (T1 Identity → T8 Self-serve) with typed events and guards.

## When to use

- A workflow has well-defined discrete states with side-effecting transitions.
- Guards reflect business rules that must be auditable (e.g., "T6 only from T5b after AME-cleared + AKTR ≥70").
- The FSM state is queryable from API handlers (`/journey/:id/state`).

## Inputs

| Input | Source | Purpose |
|---|---|---|
| `fsm-spec.yaml` | hand-authored from `module-design` output | States, events, guards, actions, context |
| `persistence-strategy.yaml` | `data-modeling` output | Snapshot table or event-sourced log |

## Outputs

```
apps/api/src/domain/workflow/
├── <name>-fsm.ts             # XState v5 createMachine() definition
├── <name>-persistence.ts     # snapshot save/restore + state-from-events derivation
└── ../../docs/contracts/<name>-fsm.json   # design-time JSON for evaluator
```

## Contract enforcement

- **Type completeness**: post-generation TS check on FSM context type — no `any`.
- **State coverage**: every state must reach a terminal or be documented as `parallel: true`.
- **Persistence round-trip**: generated tests verify `restore(snapshot(state)) === state`.

## Phase 3 prototype usage

Used to scaffold:

- `apps/api/src/domain/workflow/journey-fsm.ts` (T1..T8, 19 states, typed context)
- `apps/api/src/domain/workflow/journey-persistence.ts`
- `prototype/docs/contracts/journey-fsm.json`

## Status

**STUB — 2026-05-27.** Created retroactively. Full implementation Phase 4.

## Related work

- ATLAS Phase 3 prototype `apps/api/src/domain/workflow/journey-fsm.ts`
- `prototype/docs/contracts/journey-fsm.json` (design-time export)
