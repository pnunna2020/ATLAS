---
name: change-conflict-resolver
description: >
  Resolve conflicts between sustainment changes and upcoming modernization factory work. Manage 'do not modify' flags. Use during ST.2. Triggers on change conflict, sustainment coordination, do-not-modify, or modernization conflict.
agent: sonnet
---

# Change Conflict Resolution
## Purpose
Prevent sustainment patches from conflicting with factory modernization work.
When an app is approaching its modernization wave, changes must be coordinated.

## Decision Tree
```
Is the app entering factory within 30 days?
├── YES: Is the change CRITICAL (security/outage)?
│   ├── YES: Apply patch, notify factory team, document delta
│   └── NO: DEFER change, set "do not modify" flag
└── NO: Apply change normally, log in sustainment backlog
```

## Gotchas
- **"Do not modify" is not absolute**: Critical security patches and outage
  fixes override the flag. But they MUST be documented so the factory team
  knows the codebase changed.
- **Factory team needs to know about every sustainment change**: Even routine
  patches change the codebase that P4.1 will extract from. Undocumented
  changes mean extraction may miss or misinterpret recent additions.

## Quality Rules
- [ ] Decision tree is followed for every change request — no ad-hoc approvals
- [ ] "Do not modify" flag is set for apps entering factory within 30 days
- [ ] Critical security patches applied during "do not modify" period are documented with full delta description
- [ ] Factory team is notified of every sustainment change to apps in the current or upcoming wave
- [ ] Change log is updated with timestamp, change description, and author for every applied patch

## Common Failure Modes
| Failure Mode | Symptom | Prevention |
|-------------|---------|------------|
| Undocumented sustainment change | Extraction at P4.1 misses or misinterprets recent patches; specs are incomplete | Require change log entry for every sustainment patch; notify factory team automatically |
| "Do not modify" applied too late | Non-critical change applied 2 weeks before factory intake; extraction scope is inconsistent | Set "do not modify" flag at 30 days before wave start, not at wave start |
| Critical patch not communicated | Security fix applied during freeze but factory team not notified; extraction uses stale assumptions | Require factory team notification for any critical patch that overrides "do not modify" |
| Deferred changes lost | Changes deferred during freeze are never re-applied post-modernization; functionality gaps | Track deferred changes in sustainment backlog; review after modernization completes |

## Handoff Summary
When this skill completes, verify:
1. Decision tree was followed for the change request
2. Change log is updated and factory team is notified (if applicable)
3. "Do not modify" flag is correctly set or respected
4. Deferred changes are logged in the sustainment backlog
Then proceed to: `extraction` (P4.1) if the change affects an app entering the factory, or normal sustainment workflow if not
