---
name: cross-system-data-integration-designer
description: >
  Design the event-driven integration topology across the 8-app FAA portfolio
  (IACRA, RMS, MSS suite (AMCS+MedXPress+CHAPS+CPDSS+DIWS), DMS) on AWS
  GovCloud. Produces per-edge data contracts (schema + SLA + freshness +
  sensitivity), CDC-stream choices (AWS DMS, Aurora logical replication,
  Debezium), event-bus choices (EventBridge default, MSK for >1000 eps),
  transactional outbox / inbox patterns for idempotency, schema-evolution
  strategy per edge (additive-only | versioned | breaking-with-migration),
  and backpressure + dead-letter policies. Replaces the current implicit
  integration surface (ETL scripts, nightly feeds, DB triggers). Consumes
  portfolio-integration-mapper output plus canonical-entity-model.json and
  emits cross-system-data-integration.json plus integration-topology.mmd.
  Fires in the Design phase when portfolio-integration-mapper output is
  present AND target_cloud includes aws-govcloud. Triggers on data
  integration design, CDC design, event-bus design, cross-system edges,
  schema evolution, transactional outbox, or @cross-system-data-integration-designer.
agent: sonnet
allowed-tools:
  - Read
  - Write
  - Grep
phase: design
triggers:
  prior_artifacts_present:
    - portfolio-integration-map.json
  target_cloud:
    - aws-govcloud
validation_commands:
  - "python -m olympus.validators.schema_validator cross-system-data-integration.json"
  - "python -m olympus.validators.mermaid_validator integration-topology.mmd"
supported_stacks:
  - aws-govcloud
  - aws
  - aurora-postgresql
  - oracle
  - sqlserver
  - eventbridge
  - msk
  - aws-dms
  - kinesis
anti_target_stacks:
  - on-prem-only
  - non-federal
  - static-site
failure_classes:
  - cdc-type-conversion-gap
  - schema-evolution-breaking
  - eventbridge-rule-overflow
  - missing-idempotency-key
  - pii-by-value-leak
  - dead-letter-missing
  - govcloud-service-unavailable
  - throughput-ceiling-missed
benchmark_tags:
  - integration-topology
  - cdc-design
  - event-driven-architecture
---

# cross-system-data-integration-designer

## Purpose
Design the event-driven integration topology that replaces the FAA
portfolio's current implicit integration surface — nightly ETL scripts,
DB triggers, SFTP file drops, and point-to-point API pulls — with a
schema-validated set of CDC streams, event buses, and per-edge data
contracts on AWS GovCloud. The 8-app portfolio spans FedRAMP High
(RMS, IACRA, DMS) and FedRAMP Moderate (MSS suite); the integration
topology must honor the tier boundary, carry PII by reference not by
value, and define schema-evolution rules that let producers change
without breaking consumers. Without this skill, the Target Architecture
ships with service-level decomposition but no authoritative map of
cross-service edges, leaving integration to emerge accidentally from
implementation. SOO Sub-factor 3 §5.2 Theme B (Target-State
Architecture) explicitly requires an event-driven integration plan;
this skill is that plan.

## Inputs
- `portfolio-integration-map.json` (from
  `portfolio-integration-mapper`) — lists every current and target
  cross-app edge.
- `canonical-entity-model.json` (from `faa-canonical-entity-modeler`) —
  supplies SoR, replica fan-out, PII classification per field,
  CDC-latency SLA per entity.
- `target-architecture.json` (from `target-architecture-designer`) —
  names target services and their bounded contexts.
- `disposition-recommendation.json` — integration edges involving
  Retire-dispositioned capabilities are excluded from the target
  topology.
- AWS GovCloud service availability (check at build time — the list
  changes): EventBridge, MSK, Kinesis, DMS, Step Functions, Glue, Aurora
  logical replication, Debezium on MSK Connect. FedRAMP High vs
  Moderate availability differs per service.
- Client profile — `profiles/faa/profile.yaml` supplies the FedRAMP
  tier map, KMS CMK policy, and default transport preferences.
- Reference: `references/event-driven-integration-patterns.md`.

## Outputs
- `cross-system-data-integration.json` — one `integration_edges[]` row
  per cross-app edge. Each row carries:
  - `edge_id` (stable slug, for example `EDGE-RMS-CAIS-IACRA-AIRMAN`),
  - `source_app`, `source_entity`,
  - `target_app`, `target_usage` in
    `{replica | derived_view | notification}`,
  - `transport` in
    `{cdc-stream | event-bus | api-pull | file-drop}`,
  - `transport_service` in
    `{aws-dms | eventbridge | msk | kinesis | step-functions | glue |
      aurora-logical | debezium | api-gateway | sftp}`,
  - `schema_contract_id`,
  - `sla_freshness` (matches canonical-entity-model SLA),
  - `sla_availability` (for example `99.9%`),
  - `sensitivity_class` in `{public | internal | pii | phi | part-120}`,
  - `backpressure_strategy` (describes consumer-side flow control),
  - `schema_evolution_strategy` in
    `{additive-only | versioned | breaking-with-migration}`,
  - `idempotency_strategy` (required for every event-bus edge),
  - `dead_letter_topic` (required for every event-bus and stream edge),
  - `encryption_in_transit` (always `tls-1.2-plus` on GovCloud),
  - `kms_cmk_required` (true when sensitivity is `pii` / `phi` /
    `part-120`),
  - `evidence_citations[]`.
- `integration-topology.mmd` — Mermaid diagram of cross-app edges
  color-coded by transport
  (`cdc-stream` blue, `event-bus` green, `api-pull` orange,
  `file-drop` gray). Every edge label shows `schema_contract_id` and
  `sla_freshness`.
- Validator reports written sibling to each artifact.

## Methodology
1. Load `portfolio-integration-map.json` and build the target edge set.
   Exclude edges involving Retire-dispositioned capabilities. Cross-check
   against `canonical-entity-model.json.relationships[]` — every
   cross-entity relationship that spans SoR boundaries MUST appear as at
   least one edge; missing edges are a `missing-integration-edge`
   finding.
2. For each edge, pick `transport`. The decision rules in
   `references/event-driven-integration-patterns.md` §Transport Selection
   are:
   - **cdc-stream** when the target usage is replica and the source
     supports CDC (Aurora logical replication, Oracle LogMiner via AWS
     DMS, SQL Server CDC).
   - **event-bus** when the target usage is notification or derived-view
     with event-sourced semantics.
   - **api-pull** when the target usage is on-demand read with
     latency tolerant to the round-trip (typically > 5s).
   - **file-drop** only for legacy continuity (retained SFTP /
     Globalscape EFT integrations pending target-system maturity).
3. Pick `transport_service` per transport. Rules:
   - CDC from Aurora PG → AWS DMS with Kinesis Data Streams sink.
   - CDC from Oracle → AWS DMS (LogMiner mode); flag type-conversion
     gaps (NUMBER precision loss, CLOB → VARCHAR truncation, RAW →
     BYTEA), emit findings for each.
   - CDC from SQL Server → AWS DMS (MS-CDC mode).
   - CDC from ADABAS / mainframe → target depends; Debezium on MSK
     Connect is not GovCloud-available for all legacy sources — verify
     at build time.
   - Event bus default: EventBridge (managed, GovCloud available,
     FedRAMP High + Moderate).
   - Event bus for >1000 events/sec: MSK (Kafka-compatible, higher
     throughput).
   - Event bus for ordered streaming at high throughput: Kinesis Data
     Streams.
   - Multi-step workflows: Step Functions (standard or express depending
     on duration).
   - Batch ETL (legacy continuity, nightly): Glue.
4. Assign `schema_contract_id`. Every edge has a schema contract
   registered in EventBridge Schema Registry or Glue Schema Registry.
   The contract id is stable across versions (for example
   `airman-identity-v1`, then `airman-identity-v2` when a
   breaking-with-migration change lands). The schema-registry
   selection is authoritative — ad-hoc JSON schemas in code are not.
5. Pick `schema_evolution_strategy` per edge:
   - `additive-only` (default) — producers may add optional fields;
     consumers ignore unknown fields.
   - `versioned` — when a field's semantic changes (not just the
     shape), emit a new version id; both versions run in parallel
     during a documented dual-write window.
   - `breaking-with-migration` — last resort; requires a dual-write
     period, a consumer-migration plan, and an explicit sunset date
     cited in evidence. Never make a silent breaking change.
6. Define `idempotency_strategy` for every event-bus edge. Producers
   emit an idempotency key (for example a hash of source-event-id +
   entity-id + version) in the event envelope; consumers persist
   processed keys in an inbox table and skip duplicates. Transactional
   outbox on the producer side and inbox on the consumer side are the
   default pattern — see the reference for the full catalog. Missing
   idempotency key = `missing-idempotency-key` blocker.
7. Define `dead_letter_topic` for every event-bus and stream edge.
   Unprocessable events route to the dead-letter topic with consumer,
   error, original event, and retry-count metadata. No edge ships
   without a dead-letter policy — `dead-letter-missing` is a blocker.
8. Apply the PII-by-reference rule. Integration events carry
   `entity_id` (CAIS ID, N-number, certificate_id) not PII values
   (SSN, name, DOB). Consumers that need PII pull from the canonical
   store using the reference. This prevents PII sprawl across event
   streams and reduces the encryption-in-transit surface. A PII value
   in an event envelope is a `pii-by-value-leak` blocker.
9. Apply backpressure and throughput checks:
   - EventBridge: default limit is 300 rules per event bus. Plan
     consumer routing such that rule count stays well below the ceiling;
     if the edge set requires more, shard across multiple event buses.
   - MSK: capacity-plan for >1000 eps edges with partition count and
     replication factor documented.
   - Kinesis: size shards per 1 MB/s or 1000 records/s per shard;
     document the shard count in the contract.
10. Apply GovCloud availability checks. For every
    `transport_service`, verify availability in AWS GovCloud US at the
    app's FedRAMP tier. Common gaps (re-verify at build time):
    EventBridge Scheduler region limits, Bedrock model restrictions,
    Lambda@Edge absence, limited Aurora Serverless v2. Emit
    `govcloud-service-unavailable` findings per gap.
11. Encrypt in transit and at rest. TLS 1.2+ on every edge; KMS CMK
    required when `sensitivity_class` is `pii`, `phi`, or `part-120`.
    Cross-region GovCloud replication (GovCloud-East ↔ GovCloud-West)
    is expensive and is reserved for Tier-1 resilience requirements;
    document the justification when used.
12. Emit `integration-topology.mmd`. Color-code edges by transport;
    label each edge with `schema_contract_id` and `sla_freshness`.
    Validate the Mermaid with `olympus.validators.mermaid_validator`.

## Gotchas
- **CDC type-conversion gaps are source-specific.** Oracle NUMBER with
  high precision → PostgreSQL NUMERIC loses precision above 38 digits;
  CLOB > 1 GB → VARCHAR truncation; RAW → BYTEA with encoding surprises;
  SQL Server DATETIME2 → TIMESTAMP loses sub-microsecond precision.
  Flag every type-conversion with a `cdc-type-conversion-gap` finding
  and cite the source column.
- **Schema-evolution default is additive-only.** Consumers outnumber
  producers; a breaking change forces a dual-write and a
  consumer-migration plan. Never make a silent breaking change; the
  `schema-evolution-breaking` failure class catches it.
- **EventBridge rule ceiling is real.** Default is 300 rules per event
  bus. A portfolio-wide single bus exceeds the ceiling quickly; plan
  multiple event buses (per bounded context) or shard by event-type
  prefix. Emit `eventbridge-rule-overflow` when the rule count
  approaches 80% of the ceiling.
- **MSK is the throughput choice, not the default.** MSK costs more
  than EventBridge and requires capacity planning. Use it only when
  the edge exceeds 1000 eps or requires strict ordering at high
  throughput. Missing the throughput-ceiling check when >1000 eps
  is a `throughput-ceiling-missed` blocker.
- **Idempotency key is mandatory on every event-bus edge.** At-least-once
  delivery produces duplicates; without an idempotency key, consumers
  apply side-effects twice. The key must be stable across retries
  (hash of source-event-id + entity-id + version; not a timestamp).
- **Transactional outbox + inbox pattern is the default.** Producer
  writes the event to an outbox table in the same DB transaction as
  the state change; a relay reads the outbox and publishes to the bus;
  consumer writes the inbox table in the same DB transaction as the
  state change it applies. This gives exactly-once semantics over an
  at-least-once bus. See the reference.
- **Dead-letter topic per edge, not per app.** A shared dead-letter
  topic hides the source-edge of unprocessable events and forces
  reviewers to correlate by payload inspection. One DLT per edge
  keeps the failure mode traceable.
- **PII by reference, not by value.** SSN, DOB, and full Name must
  not appear in event payloads; send `entity_id` instead and let
  consumers read the canonical store. Encryption in transit helps but
  does not remove the sprawl risk — every consumer logging the event
  now has PII in its logs.
- **PHI events need KMS CMK.** Medical certification events carry
  references only (MedicalExam ID), but the envelope still requires
  KMS CMK encryption. FedRAMP Moderate permits AWS-managed KMS
  keys; FedRAMP High typically requires customer-managed CMKs with
  tenant-specific rotation.
- **Cross-GovCloud-region replication is expensive.** GovCloud-East ↔
  GovCloud-West replication is priced at premium rates; reserve it for
  Tier-1 resilience (RMS, IACRA, DMS). MSS suite (FedRAMP Moderate)
  typically does not justify cross-region replication; document in the
  architecture evidence when it is used.
- **Legacy file-drop integrations persist during migration.** SFTP and
  Globalscape EFT remain until the target integration matures. Emit
  them as `transport: file-drop`, `transport_service: sftp` edges with
  a `sunset_target_date` citation; do not silently drop them from the
  topology.
- **Schema-registry is authoritative.** EventBridge Schema Registry or
  Glue Schema Registry is the single source of truth for event
  schemas. Ad-hoc JSON schemas in application code are a
  `schema-registry-bypass` finding — the contract is the registry row,
  not the code.
- **Dual-write window is mandatory for versioned changes.** When
  `schema_evolution_strategy = versioned`, producers emit BOTH v1 and
  v2 envelopes until all consumers migrate; the dual-write window has
  a documented end date and a consumer-migration checklist.

## Quality Rules
- [ ] Every `integration_edges[]` row has `transport`,
      `transport_service`, `schema_contract_id`, `sla_freshness`,
      `sensitivity_class`, `idempotency_strategy`, `dead_letter_topic`,
      and `schema_evolution_strategy` populated.
- [ ] Every event-bus edge has a non-null `idempotency_strategy` and a
      non-null `dead_letter_topic`.
- [ ] No event payload carries PII values; every PII-dependent consumer
      pulls via entity_id reference.
- [ ] `sla_freshness` matches the canonical-entity-model SLA for the
      source entity — drift is a finding.
- [ ] Every edge with `sensitivity_class` in `{pii, phi, part-120}` has
      `kms_cmk_required: true` and `encryption_in_transit:
      tls-1.2-plus`.
- [ ] Every `transport_service` appears in AWS GovCloud US at the app's
      FedRAMP tier; GovCloud-unavailable services emit
      `govcloud-service-unavailable` findings.
- [ ] EventBridge rule count per event bus stays below 240 (80% of
      the 300-rule default); approaching the ceiling emits
      `eventbridge-rule-overflow` findings.
- [ ] Every edge exceeding 1000 eps uses MSK or Kinesis, not
      EventBridge.
- [ ] `schema_evolution_strategy = breaking-with-migration` rows cite a
      dual-write plan and a sunset date.
- [ ] `integration-topology.mmd` compiles under `mermaid_validator` and
      shows all `integration_edges[]` rows.
- [ ] Both artifacts pass their schemas with zero errors.

## Common Failure Modes
| Failure Mode | Symptom | Prevention |
|---|---|---|
| CDC type-conversion gap ignored | Silent data corruption on replication (NUMBER precision, CLOB truncation) | Enumerate source column types against target column types; emit findings per gap before enabling the stream |
| Schema evolution breaks consumers | Producer adds a required field; consumers fail on deserialization | Default to additive-only; require dual-write window for versioned; document breaking changes with sunset date |
| EventBridge rule overflow | 301st rule rejected at runtime; integration edges silently drop | Plan multiple event buses per bounded context; emit warnings above 240 rules |
| Missing idempotency key on event-bus edge | Duplicate delivery applies side-effects twice; financial or regulatory impact | Mandate idempotency key on every event envelope; consumer inbox table dedups on key |
| PII leaked by value in event payload | SSN / DOB / name visible in event logs across every consumer | Send entity_id reference only; consumers pull from canonical store when PII needed |
| Dead-letter missing | Unprocessable events drop silently; no audit trail | One dead-letter topic per edge; reviewer can trace by edge_id |
| GovCloud service unavailable | Target topology names a service not in GovCloud US at the app's tier; discovered at deployment | Cross-check every transport_service against GovCloud availability at build time |
| Throughput ceiling missed | EventBridge chosen for a >1000 eps edge; throttles in production | Measure expected throughput; MSK or Kinesis for >1000 eps edges |

## Handoff Summary
When this skill completes, verify:
1. `cross-system-data-integration.json` exists, passes its schema, and
   every edge has idempotency + dead-letter + encryption populated.
2. `integration-topology.mmd` compiles and shows every edge with
   transport color, schema contract id, and freshness SLA.
3. No PII value appears in any event envelope.
4. Every edge's `sla_freshness` matches the source entity's canonical
   SLA.
5. No transport service is named that is unavailable in AWS GovCloud
   at the app's FedRAMP tier.

Then proceed to `rationalization-to-architecture-traceability` (the
integration topology cross-checks the target architecture's service
inventory), to `target-deployment-designer` (consumes the topology
for VPC / subnet / security-group planning), and to the **G-DT**
Design Traceability gate, which accepts this artifact as evidence for
SOO Sub-factor 3 §5.2 Theme B event-driven integration plan.

## References
- `references/event-driven-integration-patterns.md` — transport
  selection rules, transactional outbox / inbox, SAGA for multi-system
  transactions, compensating actions, schema-evolution playbook.
- `canonical-entity-model.json` from
  `faa-canonical-entity-modeler/SKILL.md` — SoR map and CDC SLA
  source.
- `docs/testing/architecture-data-skill-assessment.md` §7 — identifies
  cross-system integration design as a required Design-phase skill.

## Changelog
- 0.1.0 (2026-05-06) — Initial skill. Emits
  cross-system-data-integration.json and integration-topology.mmd.
  Enforces transactional outbox / inbox, idempotency keys, dead-letter
  topics, PII-by-reference, EventBridge rule ceiling, MSK throughput
  threshold, schema-registry authority, GovCloud availability checks,
  FIPS 140-3 / KMS CMK for PII/PHI/Part-120 data. Feeds G-DT gate and
  SOO Sub-factor 3 §5.2 Theme B evidence.
