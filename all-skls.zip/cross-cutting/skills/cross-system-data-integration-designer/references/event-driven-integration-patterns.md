# Event-Driven Integration Patterns

Catalog of patterns consumed by
`cross-system-data-integration-designer/SKILL.md`. Covers transport
selection, transactional outbox / inbox, SAGA for multi-system
transactions, compensating actions, schema-evolution playbook, and
GovCloud-specific constraints.

## Transport Selection Rules

Apply the rules in order; the first match wins.

1. **cdc-stream** — use when target usage is `replica` and the source
   supports CDC (Aurora logical replication, Oracle LogMiner via AWS
   DMS, SQL Server CDC).
2. **event-bus** — use when target usage is `notification` or
   `derived_view` with event-sourced semantics.
3. **api-pull** — use when target usage is on-demand read with latency
   tolerant to the round-trip (typically >5s) and the source has a
   stable API surface.
4. **file-drop** — legacy continuity only. Retained SFTP, Globalscape
   EFT, or S3-drop integrations pending target-system maturity. Carries
   a `sunset_target_date` citation.

## Transport-Service Map (AWS GovCloud)

| Transport | Service | When to pick |
|---|---|---|
| cdc-stream | aws-dms | Default CDC engine for Aurora, Oracle, SQL Server sources. Kinesis Data Streams sink standard |
| cdc-stream | aurora-logical | Aurora PG source with in-database replication; lower operational overhead than DMS when both ends are Aurora PG |
| cdc-stream | debezium (on MSK Connect) | Use when CDC source is not in DMS supported source list AND Debezium connector is GovCloud-available (verify at build time) |
| event-bus | eventbridge | Default. Managed, GovCloud available, FedRAMP High + Moderate. 300-rule-per-bus ceiling |
| event-bus | msk | >1000 eps or strict ordering at high throughput. Kafka-compatible. Capacity planning required |
| stream | kinesis | Ordered streaming 1 MB/s or 1000 records/s per shard; cheaper than MSK at moderate throughput |
| workflow | step-functions | Multi-step orchestration (standard workflows for long-running, express for short bursts under 5 min) |
| batch-etl | glue | Legacy nightly batch continuity only; do not pick for new flows |
| api-pull | api-gateway (proxy) | On-demand read where provider exposes REST |
| file-drop | sftp / transfer-family | Legacy continuity; S3 as landing zone |

Verify GovCloud availability at build time — the list changes.
FedRAMP High vs Moderate availability differs per service.

## CDC Type-Conversion Gap Catalog

| Source | Type | Target | Risk |
|---|---|---|---|
| Oracle | NUMBER(38, 0) | Postgres NUMERIC | Precision preserved to 38 digits; above 38 is lossy |
| Oracle | CLOB | Postgres TEXT | OK for <1 GB; truncation risk >1 GB unless chunked |
| Oracle | BLOB | Postgres BYTEA | Size-limit differences; plan S3 offload for >1 GB |
| Oracle | RAW | Postgres BYTEA | Encoding differences; verify byte-order on conversion |
| Oracle | DATE (includes time) | Postgres TIMESTAMP | OK; column rename suggested for clarity |
| Oracle | TIMESTAMP WITH TIME ZONE | Postgres TIMESTAMP WITH TIME ZONE | OK; confirm zone handling across AWS DMS versions |
| SQL Server | DATETIME2(7) | Postgres TIMESTAMP | Loses sub-microsecond precision (DATETIME2 has 100ns; TIMESTAMP has 1us) |
| SQL Server | UNIQUEIDENTIFIER | Postgres UUID | OK; case-handling difference |
| SQL Server | NVARCHAR(MAX) | Postgres TEXT | OK |
| SQL Server | HIERARCHYID | Postgres TEXT | Lossy; custom migration required if hierarchy semantics matter |
| ADABAS | PE / MU fields | Postgres composite / array | No direct mapping; pick array or JSONB with documented convention |

Every CDC edge emits a `cdc-type-conversion-gap` finding per risk
column. Flag per `{source.table.column}`; never silently convert.

## Transactional Outbox Pattern

Producer-side idempotency:

```
BEGIN;
  UPDATE airman SET status = 'active' WHERE cais_id = 'A123456';
  INSERT INTO outbox (id, topic, payload, created_at)
    VALUES (uuid_v7(), 'airman-status-changed-v1',
            jsonb_build_object('cais_id', 'A123456', 'status', 'active'),
            now());
COMMIT;
```

A relay process reads the outbox table, publishes to the event bus,
and marks the row as published. The event's idempotency key is the
outbox row id. Crash between publish and mark produces at-least-once
delivery; consumer-side inbox dedups.

Outbox table schema:
- `id` — stable idempotency key (UUID v7 sortable)
- `topic` — schema contract id (for example `airman-identity-v1`)
- `payload` — JSONB event envelope (PII by reference; no values)
- `created_at`, `published_at` — lifecycle markers
- `retry_count`, `last_error` — publish-side failure tracking

## Consumer Inbox Pattern

Consumer-side dedup:

```
BEGIN;
  INSERT INTO inbox (idempotency_key, processed_at)
    VALUES ($event.idempotency_key, now())
    ON CONFLICT DO NOTHING
    RETURNING 1;
  -- if no row returned, event was already processed; skip
  UPDATE local_replica SET status = $event.status
    WHERE cais_id = $event.cais_id;
COMMIT;
```

Inbox table schema:
- `idempotency_key` — primary key (matches outbox id)
- `processed_at` — for retention / audit
- `retention` — TTL per edge (typically 30 days after last-seen key)

## SAGA for Multi-System Transactions

When a business operation spans multiple systems (for example
certificate issuance spans IACRA and RMS), use the SAGA pattern via
Step Functions:

1. Step 1 — IACRA creates in-flight certificate record (local
   commit + outbox).
2. Step 2 — RMS receives event, creates permanent certificate record
   (local commit + inbox).
3. Step 3 — RMS emits `certificate-persisted-v1` event.
4. Step 4 — IACRA receives persisted event, marks its record
   transferred; SoR transitions to RMS.

On failure at step 2, execute the compensating action: IACRA emits
`certificate-rollback-v1`; RMS deletes its tentative record; IACRA
rolls back its in-flight record. The SAGA is coordinated by Step
Functions; the compensating actions are first-class steps, not
afterthoughts.

## Compensating Actions

Every SAGA step has a paired compensating action. The pair is
documented as:

| Forward | Compensating |
|---|---|
| create-permanent-certificate | delete-permanent-certificate (tentative only) |
| publish-designee-activation | revoke-designee-activation |
| record-drug-test-positive | retract-drug-test-positive |
| activate-medical-certificate | deactivate-medical-certificate |

Compensating actions run under the same idempotency regime; a
compensating event carries its own idempotency key and is itself
dedup'd by the consumer inbox.

## Schema-Evolution Playbook

Three strategies, applied per edge:

### Additive-only (default)
- Producers may add optional fields at any time.
- Consumers ignore unknown fields.
- Contract id does not change.
- Schema-registry version bumps but the contract id stays stable.

### Versioned
- Applied when a field's semantics change (not just shape). Example:
  `certificate_status` enum expands from {active, revoked} to
  {active, revoked, suspended}.
- New contract id is emitted (for example
  `airman-identity-v2`).
- Producers emit BOTH v1 and v2 during a documented dual-write window.
- Consumers migrate on their own schedule within the window.
- Sunset date cited in evidence; v1 is retired after sunset.

### Breaking-with-migration
- Last resort. Applied when a required field is removed or a schema
  is incompatibly restructured.
- Requires a dual-write period, a consumer-migration plan, a sunset
  date, and an explicit review artifact.
- Emit a `breaking-change-notice-v1` event with the timeline so
  consumers can plan.

Never make a silent breaking change. The `schema-evolution-breaking`
failure class exists to catch exactly that.

## Backpressure Strategy

Consumer-side flow control per transport:

| Transport | Backpressure |
|---|---|
| EventBridge | Lambda concurrency limit; SQS buffering between EventBridge and Lambda when burst tolerance needed |
| MSK | Consumer group poll rate; partition count planning; retention period (default 7 days) |
| Kinesis | Enhanced fan-out (dedicated shard throughput per consumer); checkpoint frequency |
| CDC (DMS) | Replication task throttling; target-side batch size tuning |

Document the chosen backpressure strategy per edge; do not assume
defaults.

## EventBridge Rule Ceiling

Default: 300 rules per event bus. Portfolio-wide single-bus quickly
exceeds the ceiling.

Mitigation:
- Shard by bounded context (one event bus per bounded context).
- Shard by event-type prefix within a bus (airman-*, certificate-*,
  medical-*) with wildcard rules per consumer.
- Request quota increase (GovCloud caps are lower than commercial AWS
  in some cases).

Emit `eventbridge-rule-overflow` finding when the rule count reaches
240 (80% of 300). Plan shard at 80%; do not wait for the cap.

## MSK Capacity Planning

When choosing MSK (>1000 eps or strict ordering):
- Partition count = target throughput / per-partition throughput
  (5-10 MB/s typical).
- Replication factor = 3 (default for durability).
- Retention = 7 days default; longer for audit-heavy edges (up to 30
  days).
- Broker instance type = kafka.m5.large baseline; step up for heavy
  edges.
- Enable tiered storage for long retention without broker storage
  cost.

Cite the capacity plan in the edge's evidence.

## Kinesis Shard Sizing

- Each shard: 1 MB/s ingress, 2 MB/s egress, 1000 records/s.
- Split shards when throughput exceeds; merge when under-utilized.
- Enhanced fan-out = 2 MB/s dedicated per consumer per shard.
- Record retention default 24h; extend to 7 days for audit.

## PII-by-Reference Contract

Event envelopes carry entity references only:

```
{
  "event_id": "uuid-v7",
  "event_type": "airman-status-changed-v1",
  "idempotency_key": "sha256(source+entity+version)",
  "occurred_at": "2026-05-06T12:34:56Z",
  "entity_ref": {
    "entity_type": "AIRMAN",
    "entity_id": "A123456"
  },
  "change": {
    "field": "status",
    "old_value_ref": "prior_version_id",
    "new_value_ref": "new_version_id"
  }
}
```

Consumers that need the actual PII values read from the canonical
store using `entity_ref.entity_id`. This prevents PII sprawl.

## KMS CMK Strategy

- FedRAMP High (RMS, IACRA, DMS): customer-managed CMKs with
  tenant-specific rotation (90-day minimum).
- FedRAMP Moderate (MSS suite): AWS-managed KMS keys acceptable;
  customer-managed optional.
- Multi-region replication: use multi-region KMS keys to avoid
  re-encryption at the boundary.
- Event-bus encryption: KMS CMK on the bus when `sensitivity_class`
  is `pii`, `phi`, or `part-120`.
- CDC-stream encryption: KMS CMK on Kinesis stream when PII replicates.

## Dead-Letter Topic Conventions

One dead-letter topic per edge. Topic name: `dlt-<edge-id>`. Every
DLT message carries:
- Original event envelope (preserved as-is)
- Consumer id that failed
- Error message and stack trace
- Retry count at failure
- Timestamp of final failure

Retention: 30 days minimum; 90 days for regulated edges (PHI, Part
120). Reviewers use DLT as the incident-response starting point.

## Cross-GovCloud-Region Replication

GovCloud-East ↔ GovCloud-West replication is priced at premium data
transfer rates. Reserve for:
- Tier-1 resilience (RMS, IACRA, DMS) where RTO < 4h and RPO < 5 min.
- Regulatory continuity where loss of a single region breaks a
  statutory obligation.

Avoid for:
- MSS suite (FedRAMP Moderate) unless specifically required by the
  FAA Security Authorization.
- Derived-view edges where re-derivation is cheaper than replication.

Document the justification in the edge's evidence when used.

## Schema-Registry Authority

EventBridge Schema Registry or Glue Schema Registry is the single
authoritative source for event schemas. Ad-hoc schemas in code
duplicate the registry and drift independently; treat code-side
schemas as derived artifacts, generated from the registry, not the
other way around.

Rules:
- Schema contract id is registered in the registry before any edge
  uses it.
- Contract versions are managed in the registry; producers and
  consumers reference a version explicitly.
- Schema-registry access is audited; changes flow through a PR
  process with the schema-registry-bypass failure class catching
  code-only schema edits.

## Legacy File-Drop Continuity

Not every cross-app edge migrates to CDC or event-bus on day one.
Legacy SFTP / Globalscape EFT / S3-drop integrations remain during
the transition. Emit them as:

```
{
  "transport": "file-drop",
  "transport_service": "sftp",
  "schema_contract_id": "legacy-nightly-v1",
  "sunset_target_date": "2027-Q3",
  "sunset_target_evidence": "target-architecture.json:migration-plan:nightly-retirement"
}
```

The `sunset_target_date` is non-negotiable; without it, the edge
lingers indefinitely and the modernization narrative breaks.

## Anti-Patterns

- Emitting PII values in event envelopes ("temporarily, until
  refactor") — the refactor never happens.
- Single DLT across all edges — hides the source of failures.
- Schema-registry bypass ("just put the schema in code for now") —
  drift guaranteed.
- Breaking change without dual-write — consumers break in production.
- EventBridge for >1000 eps edges — throttles under burst.
- Missing idempotency key — duplicate side-effects, financial impact.
- Compensating action as a wiki note instead of a first-class
  SAGA step — rollback not exercised until it is needed.
- Cross-region GovCloud replication as default — premium cost for
  unneeded resilience.
