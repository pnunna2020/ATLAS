# SSDT `.sqlproj` Extraction

Companion reference to `sqlserver-extraction-patterns`. Covers SQL Server
Data Tools (SSDT) project shape, declarative-vs-imperative detection,
`.refactorlog` rename history, `.publish.xml` deployment profiles,
`.dacpac` and `.bacpac` artifact extraction, pre/post-deployment scripts,
and the direction-of-travel choice (preserve SSDT vs. flatten to
migrations) that Design must make downstream.

## What SSDT is

SSDT is Microsoft's declarative database-development toolchain. A
`.sqlproj` is an MSBuild project that treats every database object —
every table, procedure, view, function, trigger, synonym, type — as its
own `.sql` file in the source tree. The build produces a `.dacpac`
(data-tier application package): a zip archive containing `model.xml`
(the logical schema), `Origin.xml` (source metadata), and optional
pre/post-deployment scripts. Deploying a `.dacpac` is a schema
*comparison* against the target: the tool computes the delta and applies
it. This is fundamentally different from imperative migrations, which
apply a predetermined sequence of scripts.

## Detecting SSDT vs. migration shape

**Presence of `.sqlproj` is the authoritative signal.** A repo with any
`.sqlproj` file should be extracted as SSDT-declarative for the
subtrees covered by that project's `<ItemGroup>` includes.

**Absence of `.sqlproj`** plus the presence of ordered script names —
`V001__*.sql`, `2024-01-15-*.sql`, `001_init.sql`, or a migration tool's
directory convention (Flyway `migration/`, DbUp `Scripts/`, EF
`Migrations/`) — indicates imperative shape.

**Mixed shape** is legal and occurs in the wild. FAA DMS ships
`Dms.Database/Dms.Database.sqlproj` (SSDT) alongside
`AuditLog.Database/Scripts/build.sql` (imperative) in the same repo.
Extraction runs both paths and emits one manifest record per covered
subtree, keyed by the governing project file (or its absence).

## `.sqlproj` structure

A `.sqlproj` is MSBuild XML. The extraction-relevant elements:

    <Project DefaultTargets="Build" ToolsVersion="Current"
             xmlns="http://schemas.microsoft.com/developer/msbuild/2003">
      <PropertyGroup>
        <Name>Dms.Database</Name>
        <DSP>Microsoft.Data.Tools.Schema.Sql.Sql150DatabaseSchemaProvider</DSP>
        <ModelCollation>1033, CI</ModelCollation>
        <DefaultSchema>dbo</DefaultSchema>
        <OutputType>Database</OutputType>
        <IncludeCompositeObjects>True</IncludeCompositeObjects>
      </PropertyGroup>
      <ItemGroup>
        <Build Include="dbo\Tables\Users.sql" />
        <Build Include="dbo\StoredProcedures\GetUser.sql" />
        ...
      </ItemGroup>
      <ItemGroup>
        <None Include="Scripts\PreDeployment\Init.sql" />
        <PostDeploy Include="Scripts\PostDeployment\Seed.sql" />
      </ItemGroup>
      <ItemGroup>
        <RefactorLog Include="Dms.Database.refactorlog" />
      </ItemGroup>
    </Project>

Fields to capture per project:
- `Name` — project name (drives the `.dacpac` filename)
- `DSP` — Database Schema Provider, encodes the target SQL Server
  version (`Sql150` = 2019, `Sql160` = 2022). Downstream Design must
  not target a version older than the DSP.
- `DefaultSchema` — usually `dbo`; schema-qualification inference falls
  back to this.
- `IncludeCompositeObjects` — when `True`, the project references other
  `.dacpac`s (cross-database dependencies).
- `<Build Include=...>` — one element per schema object; the filename
  is the object name (e.g., `dbo/Tables/Users.sql` defines `dbo.Users`).
- `<PreDeploy Include=...>` / `<PostDeploy Include=...>` — scripts run
  before/after the schema comparison applies. Typically seed data or
  one-time data migrations. Must be preserved.
- `<None Include=...>` — non-build files; usually documentation.
- `<RefactorLog Include=...>` — pointer to the `.refactorlog` (see
  below).

## `.refactorlog` — the critical rename history

SSDT's schema comparison is name-based. If a developer renames
`dbo.Customer` to `dbo.Client` in source, the comparison sees `Customer`
in the target (not in source) and `Client` in source (not in target) —
it drops `Customer` and creates `Client`, destroying all the data.

SSDT fixes this by recording every rename, move, or column-rename as an
entry in the `.refactorlog`. The file is a simple XML log:

    <Operations Version="1.0"
                xmlns="http://schemas.microsoft.com/sqlserver/dac/Serialization/2012/02">
      <Operation Name="Rename Refactor" Key="<guid>" ChangeDateTime="...">
        <Property Name="ElementName" Value="[dbo].[Customer]" />
        <Property Name="ElementType" Value="SqlTable" />
        <Property Name="NewName" Value="[Client]" />
      </Operation>
      ...
    </Operations>

During deployment, SSDT reads the `.refactorlog`, looks up each entry,
and emits `sp_rename` instead of drop-create.

**Extraction requirement.** Preserve `.refactorlog` files verbatim and
reference them by path in the schema manifest. Do not normalize, do not
rewrite, do not deduplicate entries. Downstream Design must carry the
rename history forward when translating to any other shape (including
Flyway migrations or Liquibase changesets); losing it causes data loss
on the next deployment.

## `.publish.xml` — deployment profiles

SSDT deployment profiles are XML files that parameterize a `.dacpac`
publish for a target environment. Typical contents:

    <Project ToolsVersion="Current"
             xmlns="http://schemas.microsoft.com/developer/msbuild/2003">
      <PropertyGroup>
        <TargetDatabaseName>DmsDev</TargetDatabaseName>
        <TargetConnectionString>Data Source=...;Integrated Security=True;</TargetConnectionString>
        <BlockOnPossibleDataLoss>True</BlockOnPossibleDataLoss>
        <DropObjectsNotInSource>False</DropObjectsNotInSource>
        <GenerateSmartDefaults>True</GenerateSmartDefaults>
      </PropertyGroup>
      <ItemGroup>
        <SqlCmdVariable Include="Environment">
          <Value>Dev</Value>
        </SqlCmdVariable>
      </ItemGroup>
    </Project>

Fields to capture:
- `TargetDatabaseName` — deployment target database name per profile.
- `TargetConnectionString` — redact any embedded credentials before
  emitting to the manifest. Emit a finding for hardcoded credentials.
- `BlockOnPossibleDataLoss` — critical safety flag; record per profile.
  Profiles that disable it (`False`) get a security finding.
- `DropObjectsNotInSource` — when `True`, anything in the target not in
  source is dropped. Record per profile.
- `SqlCmdVariable` entries — parameterize the deployment; each script
  variable must be resolvable at deploy time.

Repos often have one profile per environment (`DmsDev.publish.xml`,
`DmsProd.publish.xml`). Emit one record per profile; flag any profile
with `BlockOnPossibleDataLoss = False` as high severity.

## `.dacpac` and `.bacpac` — compiled artifacts

Both are zip archives with a well-defined internal structure:

    my.dacpac
    ├── [Content_Types].xml
    ├── model.xml           — logical schema (primary extraction target)
    ├── Origin.xml          — build metadata, source server version
    └── ...

- `.dacpac` — schema only. Produced by building a `.sqlproj`. Used for
  deploying schema changes.
- `.bacpac` — schema + data. Produced by `Export Data-tier Application`
  from an existing database. Used for logical backup / move between
  servers.

**Extraction without SQL Server.** Both are zip files — unzip and
inspect. The `model.xml` contains the full logical schema as XML
elements. Parse it as XML; do NOT feed it to a T-SQL parser.

**Extraction with `sqlpackage`.** When `sqlpackage` is installed:

    sqlpackage /Action:Extract     /SourceFile:my.bacpac /TargetFile:my.dacpac
    sqlpackage /Action:Script      /SourceFile:my.dacpac /TargetFile:schema.sql

The `/Action:Script` form emits a single `schema.sql` DDL file equivalent
to the `.dacpac`. This is a useful extraction shortcut but requires
`sqlpackage` to be installed on the extraction host.

## Pre- and post-deployment scripts

SSDT supports exactly one pre-deployment script and one post-deployment
script per project, referenced in the `.sqlproj` via `<PreDeploy>` and
`<PostDeploy>`. These scripts run as SQLCMD — see
`tsql-extraction-patterns.md` for SQLCMD mode parsing. They commonly
contain `:r` includes to modularize seed data.

Pre-deployment typical content:
- Schema stubbing before the comparison runs (rare)
- One-time data fix-ups that must happen before the schema change

Post-deployment typical content:
- Lookup-table seeding (`INSERT INTO dbo.Status VALUES ...`)
- Permission grants that depend on the deployed schema
- `:r` includes of per-environment seed-data files

These must be preserved verbatim in the programmability manifest as
`pre_deploy_body` and `post_deploy_body`. Do not attempt to split them
into individual statements; the order inside the script is part of the
contract.

## The directionality choice — preserve vs. flatten

Downstream Design has a decision: when modernizing an SSDT-shaped tier,
does it keep the SSDT shape (one `.sql` per object, build to `.dacpac`,
deploy via schema comparison) or flatten to migrations (Flyway/DbUp/
EF Core Migrations)?

Extraction does NOT make this choice. It emits both:
- `schema_snapshot_source: "ssdt"` with pointer to the `.sqlproj`
- `migrations: []` (empty for declarative repos)

plus a decision-input block:

    {
      "ssdt_refactor_log_entries": 47,
      "ssdt_has_predeploy": true,
      "ssdt_has_postdeploy": true,
      "ssdt_cross_database_dacpac_refs": ["Common.Database.dacpac"],
      "suggests_flattening": false,
      "rationale": "Non-empty refactor log and cross-database references"
    }

Design reads this and decides. Losing the refactor log entries, cross-
database `.dacpac` references, or post-deployment seed scripts usually
makes flattening to migrations destructive; the decision-input block
must be accurate.

## Common SSDT repo shapes observed in the ATLAS portfolio

- **DMS.** `Dms.Database/` contains `Dms.Database.sqlproj`,
  `Dms.Database.refactorlog`, tables/procs/views/functions split by
  schema, and a `Scripts/PostDeployment/` subtree. `Oda.Database/` is a
  second SSDT project in the same solution. Separately,
  `AuditLog.Database/Scripts/` is a hand-rolled imperative tree with
  `build.sql`, `run.ps1`, and a `.pgpass` pointing to PostgreSQL — so
  the "SQL Server" tier is actually heterogeneous.
- **IACRA.** No `.sqlproj`. Tree is imperative-declarative-hybrid:
  `Tables/`, `StoredProcedures/`, `Views/`, `Functions/`, `Triggers/`,
  `Data/`, `DropScripts/`, `ProdDataFixes/`, `HelperScripts/`. Emit as
  imperative with schema-object-tree shape.
- **RMS.** Very little T-SQL source. The ground truth is inside two
  `.bak` files. SSDT path does not apply; see
  `sqlserver-backup-restore-patterns.md`.

## Extraction algorithm — SSDT path

1. Parse `.sqlproj` XML. Extract project name, DSP, default schema,
   build item list, pre/post-deploy pointers, refactorlog pointer.
2. For each `<Build Include=...>`: open the referenced `.sql` file,
   run the T-SQL extraction per `tsql-extraction-patterns.md`, emit
   one schema or programmability manifest record. The file path
   determines the object kind: `*/Tables/*.sql` → table, `*/
   StoredProcedures/*.sql` → proc, `*/Views/*.sql` → view, etc.
3. Read the `.refactorlog` XML. Emit one record per operation into
   the schema manifest's `refactor_log` array with `operation`,
   `element_name`, `element_type`, `new_name`, `change_datetime`.
4. Read pre- and post-deploy scripts in SQLCMD mode. Emit as
   programmability manifest entries of kind `pre_deploy` and
   `post_deploy`.
5. For each `.publish.xml`: parse and emit to the security manifest's
   `deployment_profiles` array, redacting credentials.
6. Emit the `schema_snapshot_source: "ssdt"` pointer and the decision-
   input block.
