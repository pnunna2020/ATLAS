# SQL Server Backup-Restore Patterns

Companion reference to `sqlserver-extraction-patterns`. Covers handling
native `.bak` deliverables during Extract: inspecting without restoring
(`RESTORE HEADERONLY` / `RESTORE FILELISTONLY`), the version compatibility
matrix, schema extraction from the system catalog after restore, exporting
schema as JSON via `SELECT ... FOR JSON`, full/differential/log backup
chains, and bulk data extraction via `bcp` or `INSERT ... SELECT`.

## What a `.bak` is

A native SQL Server backup is a file (or set of files) in Microsoft's
proprietary Virtual Backup Device Interface (VBDI) format. There is no
public parser; no third-party library can read a `.bak` directly. The
only supported extraction path is:

1. Stand up a SQL Server instance at or above the source version.
2. `RESTORE DATABASE` the `.bak` to that instance.
3. Query the system catalog to extract schema and data.

Skipping any of these steps is not possible. When the delivery contains
only `.bak` files (FAA RMS ships `aa_airman_data_20260410.bak` and
`ar_aircraft_data_20260410.bak` with 44KB of T-SQL source), extraction
emits a *restore plan* and a prerequisite finding; schema extraction
completes only after the restore step runs.

## Inspecting without restoring — `RESTORE HEADERONLY` and `FILELISTONLY`

Before committing to a full restore, probe the `.bak` for metadata. Both
commands require a SQL Server instance but do not mutate any database.

### `RESTORE HEADERONLY`

    RESTORE HEADERONLY FROM DISK = 'C:\deliveries\dms_new_20260410.bak';

Returns one row per backup set in the file, with columns including:
- `BackupName` — backup description text
- `BackupType` — 1 = full, 2 = log, 5 = differential, 6 = file, 7 = filegroup
- `DatabaseName` — source database name at backup time
- `DatabaseVersion` — internal schema version; used to derive source
  SQL Server version
- `ServerName` — source instance name
- `BackupStartDate` / `BackupFinishDate`
- `RecoveryModel` — FULL / BULK_LOGGED / SIMPLE
- `Compressed` — compression flag
- `IsEncrypted` — encryption flag; encrypted backups require the
  certificate/key to restore

`DatabaseVersion` mapping (subset):
- 904 → SQL Server 2016
- 852 → SQL Server 2017
- 869 → SQL Server 2019
- 904 → SQL Server 2022

Record the source version in the backup manifest. A backup from SQL
Server 2022 cannot restore to SQL Server 2019 — plan the target
instance accordingly.

### `RESTORE FILELISTONLY`

    RESTORE FILELISTONLY FROM DISK = 'C:\deliveries\dms_new_20260410.bak';

Returns one row per logical file in the database with columns:
- `LogicalName` — logical data/log file name (e.g., `Dms_Primary`, `Dms_Log`)
- `PhysicalName` — original path on the source server
- `Type` — `D` (data), `L` (log), `F` (fulltext)
- `FileGroupName` — owning filegroup
- `Size` / `MaxSize`

The physical paths are source-server paths and usually do not exist on
the target extraction host. The restore step must supply `WITH MOVE
'<LogicalName>' TO '<new-path>'` for every logical file.

## Templated restore plan

The backup manifest's `restore_commands` field is an ordered list of
T-SQL commands parameterized for execution on any target instance. A
well-formed restore plan looks like:

    -- Step 1: probe source version and backup set metadata
    RESTORE HEADERONLY FROM DISK = N'$(BakPath)';

    -- Step 2: enumerate logical files to determine MOVE targets
    RESTORE FILELISTONLY FROM DISK = N'$(BakPath)';

    -- Step 3: restore with MOVE per logical file (fill in after step 2)
    RESTORE DATABASE [$(TargetDbName)] FROM DISK = N'$(BakPath)' WITH
        MOVE N'<LogicalDataName>' TO N'$(DataDir)\$(TargetDbName).mdf',
        MOVE N'<LogicalLogName>'  TO N'$(DataDir)\$(TargetDbName)_log.ldf',
        REPLACE,
        STATS = 5,
        NORECOVERY;   -- NORECOVERY if more backups to apply; else RECOVERY

    -- Step 4 (if a differential backup accompanies the full):
    RESTORE DATABASE [$(TargetDbName)] FROM DISK = N'$(DiffBakPath)' WITH
        NORECOVERY;

    -- Step 5 (if transaction log backups accompany):
    RESTORE LOG [$(TargetDbName)] FROM DISK = N'$(LogBakPath)' WITH
        NORECOVERY;
    -- repeat for each log backup in chain, then:
    RESTORE LOG [$(TargetDbName)] FROM DISK = N'$(FinalLogBakPath)' WITH
        RECOVERY;

Variables use SQLCMD `$(...)` substitution. The target host supplies
`BakPath`, `TargetDbName`, and `DataDir` at run time.

## Version compatibility matrix

A `.bak` from version N can restore to version N and later, never
earlier. The compatibility level of the restored database remains that
of the source until explicitly upgraded via `ALTER DATABASE`.

| Source | Restores to |
|---|---|
| SQL Server 2012 (11.0) | 2012, 2014, 2016, 2017, 2019, 2022 |
| SQL Server 2014 (12.0) | 2014, 2016, 2017, 2019, 2022 |
| SQL Server 2016 (13.0) | 2016, 2017, 2019, 2022 |
| SQL Server 2017 (14.0) | 2017, 2019, 2022 |
| SQL Server 2019 (15.0) | 2019, 2022 |
| SQL Server 2022 (16.0) | 2022 |

SQL Server 2019 is the recommended extraction target: it supports
sources back to SQL Server 2012 and has mature `FOR JSON` and system-
catalog coverage. SQL Server 2022 adds minor features but costs more.

If `RESTORE HEADERONLY` has not run and the source version is unknown,
emit a prerequisite finding `SOURCE_VERSION_UNKNOWN` and do not attempt
restore against a 2019 instance; the backup may be from a newer engine.

## Schema extraction via the system catalog

After restore, query the system catalog to emit the schema manifest.
Core views:

- `sys.tables` — user tables (schema_id, object_id, name, type)
- `sys.columns` — columns (object_id, column_id, name, system_type_id,
  user_type_id, max_length, precision, scale, is_nullable, is_computed,
  collation_name)
- `sys.indexes` — indexes (object_id, index_id, type_desc, is_unique,
  filter_definition, data_space_id)
- `sys.index_columns` — index columns (object_id, index_id, column_id,
  key_ordinal, is_included_column)
- `sys.foreign_keys` / `sys.foreign_key_columns` — FK relationships
- `sys.check_constraints` — CHECK constraints with definition
- `sys.default_constraints` — DEFAULT constraints with definition
- `sys.computed_columns` — computed-column definitions
- `sys.objects` — catch-all; `type` column discriminates
  (`U` = user table, `V` = view, `P` = procedure, `FN` = scalar function,
  `IF` = inline TVF, `TF` = multi-statement TVF, `TR` = DML trigger,
  `TT` = table type, `SN` = synonym, `SQ` = sequence)
- `sys.sql_modules` — body text for procs/functions/views/triggers
- `sys.parameters` — proc/function parameter list
- `sys.synonyms` — synonym mappings
- `sys.sequences` — sequence definitions
- `sys.types` — user-defined types
- `sys.triggers` — DML triggers (joins to `sys.sql_modules` for body)
- `sys.server_triggers` / `sys.triggers WHERE parent_class = 0` — DDL
  triggers
- `sys.security_policies` / `sys.security_predicates` — Row-Level
  Security
- `sys.column_master_keys` / `sys.column_encryption_keys` — Always
  Encrypted keys
- `sys.masked_columns` — Dynamic Data Masking specs
- `sys.database_principals` / `sys.server_principals` / `sys.database
  _permissions` — security manifest sources

Example extraction query for tables and columns (JSON-shaped):

    SELECT
      s.name AS [schema],
      t.name AS [table],
      (SELECT c.name                   AS [name],
              tp.name                  AS [type],
              c.max_length             AS [max_length],
              c.precision              AS [precision],
              c.scale                  AS [scale],
              c.is_nullable            AS [is_nullable],
              c.is_computed            AS [is_computed],
              cc.definition            AS [computed_expression],
              dc.definition            AS [default_expression],
              c.collation_name         AS [collation]
         FROM sys.columns c
         JOIN sys.types tp ON tp.user_type_id = c.user_type_id
         LEFT JOIN sys.computed_columns cc
                ON cc.object_id = c.object_id AND cc.column_id = c.column_id
         LEFT JOIN sys.default_constraints dc
                ON dc.parent_object_id = c.object_id AND dc.parent_column_id = c.column_id
        WHERE c.object_id = t.object_id
        FOR JSON PATH) AS [columns]
    FROM sys.tables t
    JOIN sys.schemas s ON s.schema_id = t.schema_id
    FOR JSON PATH, ROOT('tables');

Run analogous queries for indexes, FKs, constraints, procedures, views,
functions, triggers, types, synonyms, sequences. `FOR JSON PATH` emits
JSON directly; redirect the single-column result to a file and the
extraction host deserializes it into the schema manifest.

## Backup chain reconstruction

A production backup set is commonly a chain:
- one **full** backup (BackupType = 1) as the anchor
- zero or more **differential** backups (BackupType = 5) since the
  last full
- zero or more **transaction log** backups (BackupType = 2) since the
  last full or differential

To restore to a point in time, apply: full → latest-differential-before-
target → all log backups in LSN order up to the target time.

The backup manifest must record the chain relationships when multiple
`.bak` files are delivered together. Use `RESTORE HEADERONLY` on each;
the `FirstLSN`/`LastLSN`/`CheckpointLSN`/`DatabaseBackupLSN` fields
link them.

When only one `.bak` is delivered and `BackupType = 1`, extraction
restores to the backup's point in time and proceeds. When `BackupType =
2` or `5` without a corresponding full, emit `INCOMPLETE_BACKUP_CHAIN`
as a critical finding.

## Data extraction — `bcp` and `INSERT SELECT`

After restore, data extraction has two common paths:

### `bcp` — bulk copy utility

    bcp dbo.Airmen out airmen.dat -S <server> -d <db> -T -c -t "|"

Fast, single-table, parallelizable. Emits one flat file per table.
`-c` requests character output, `-t "|"` sets the field separator.
Use when the downstream consumer wants flat files.

### `INSERT ... SELECT` across linked servers

    INSERT INTO target_db.dbo.Airmen
    SELECT * FROM source_db.dbo.Airmen;

Slower but transactional; useful when source and target are both SQL
Server and the target-tier shape is similar. Becomes linked-server
query when source and target are different instances; add the four-
part name.

### Emitting data extraction plan

The backup manifest's `data_extraction_plan` field is per-table:

    {
      "schema": "dbo",
      "table": "Airmen",
      "row_count_probe": "SELECT COUNT_BIG(*) FROM dbo.Airmen;",
      "bcp_command": "bcp dbo.Airmen out $(OutDir)/dbo.Airmen.dat -S ... -c -t \"|\"",
      "estimated_size_mb": null
    }

Populate `row_count_probe` during extraction; execute it on the
restored instance to size the plan. Do not ship the actual row counts
in the manifest if they reveal sensitive volume information — leave
`estimated_size_mb` null and let the secure-handoff step size locally.

## Handling encrypted backups

`IsEncrypted = 1` in `RESTORE HEADERONLY` means the `.bak` is
encrypted. Restoring requires the encryption certificate or asymmetric
key from the source instance, re-imported on the target. Emit a
prerequisite finding `BACKUP_ENCRYPTED_KEY_REQUIRED` with the
certificate thumbprint from the header; extraction cannot proceed
without the key.

## Handling compressed backups

`Compressed = 1` means backup compression is applied. This is
transparent to restore — no additional step is required. Record the
flag for reference only.

## Observed FAA-portfolio shapes

- **DMS.** One `.bak` (`dms_new_20260410.bak`, 39MB) accompanying a
  full SSDT source tree. The `.bak` is a sanity check; SSDT is the
  schema ground truth.
- **IACRA.** One `.bak` (`iacra_20260410.bak`, 30MB) accompanying
  88KB of T-SQL source. Both paths are authoritative in theory; in
  practice the `.bak` contains production data fix-ups that the
  source tree's `ProdDataFixes/` directory also attempts to capture,
  and the two sometimes disagree.
- **RMS.** Two `.bak` files (`aa_airman_data_20260410.bak`,
  `ar_aircraft_data_20260410.bak`) with 44KB of T-SQL source. The
  `.bak` files are the ground truth; the source tree is partial.
  Schema extraction for RMS *requires* the restore step.

## Extraction algorithm — `.bak` path

1. Enumerate `.bak` files in the repo.
2. For each, record `{path, size_bytes, suspected_database_name}` in
   the backup manifest.
3. Emit the templated restore plan. Do not execute yet; plan is the
   extraction output.
4. If the extraction pipeline has an attached SQL Server 2019+
   instance: execute `RESTORE HEADERONLY` and `RESTORE FILELISTONLY`;
   populate `source_version`, `database_version`, `logical_files[]`,
   `is_encrypted`, `is_compressed`, `backup_type`, `recovery_model`.
5. If `is_encrypted`, emit prerequisite finding and stop.
6. If `backup_type in {2, 5}` without a paired full, emit
   `INCOMPLETE_BACKUP_CHAIN` and stop.
7. Execute the `RESTORE DATABASE` with `WITH MOVE` templated from the
   `FILELISTONLY` output.
8. Run the system-catalog extraction queries. Write the schema
   manifest records with `source: "restored_bak"` and
   `bak_path: "<original path>"`.
9. Run `row_count_probe` per table to size the data extraction plan.
10. Do NOT include actual data in the manifest. The data extraction
    plan is the manifest's output for `.bak`-sourced tiers; data
    movement is a separate, secure-handoff step.
