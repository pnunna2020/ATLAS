# T-SQL Extraction Patterns

Companion reference to `sqlserver-extraction-patterns`. Covers the parser-level
details of extracting from T-SQL source: batch boundaries, SQLCMD mode,
parameter and return-type parsing, nested cursor detection, dynamic-SQL
call-site classification, the well-known `MERGE` pitfalls, temp table vs.
table variable lifecycle, CTE forms, and the `APPLY` operators.

## Batch boundaries — `GO` is not a statement terminator

T-SQL distinguishes **statement terminators** (`;`, optional in most places)
from **batch separators** (`GO`, handled by the client, not the server).
Standard SQL parsers split on `;` and corrupt T-SQL output.

**Rule.** Split on `GO` only when all of the following hold:
- `GO` is on its own line (ignoring leading/trailing whitespace)
- Comparison is case-insensitive
- Optional trailing integer count (`GO 5` runs the prior batch five times)
- `GO` is not inside a string literal or block comment

Everything between two `GO` markers (or between a `GO` and file boundaries)
is one batch. `CREATE PROCEDURE`, `CREATE FUNCTION`, `CREATE VIEW`, and
`CREATE TRIGGER` must each be the first statement of their batch — so a
correct parse produces one batch per programmability object.

A batch may contain zero or more statements separated by `;`. Do not split
the batch on `;` for extraction purposes; preserve the batch body verbatim
in the programmability manifest's `body` field.

## SQLCMD mode

SQLCMD is the Microsoft command-line client for SQL Server. Its scripts
contain directives that are not valid T-SQL and cause parse errors in any
T-SQL-only parser.

Directives to detect and handle:
- `:r <path>` — include another file inline; resolve relative to the
  including file's directory. Emit as a dependency edge; never inline the
  included text into the manifest.
- `:setvar NAME value` — set a script variable substitutable as `$(NAME)`.
  Record the variable assignment as a finding; warn that substitution is
  environment-dependent and downstream tooling must preserve the variable.
- `:on error exit` — script-level error handling; record as a finding, no
  action required.
- `!!` — invoke an OS shell command; record as a finding and flag as a
  sandbox-escape risk.
- `:connect`, `:list`, `:listvar`, `:ed`, `:out`, `:perftrace` — record
  presence; does not affect extraction.

**Detection.** A file is in SQLCMD mode if any of the above directives
appears on a line by itself (possibly indented). Switch to SQLCMD-aware
parsing for the whole file; a file is either SQLCMD mode or plain T-SQL,
never a mix within one file.

## Parameter extraction — stored procedures and functions

Parameter lists follow the grammar:

    CREATE {PROCEDURE|FUNCTION} [schema.]name
        [ @param [AS] type [= default] [OUTPUT] [READONLY] ] [, ...]
    [RETURNS type | TABLE (...) | @var TABLE (...)]
    [WITH {RECOMPILE | ENCRYPTION | EXECUTE AS ... | SCHEMABINDING} [, ...]]
    AS
    BEGIN
        ...body...
    END

Per-parameter fields to capture:
- `name` — including the leading `@`
- `type` — may be a built-in (`int`, `nvarchar(max)`), an alias type, or
  a user-defined table type (`dbo.OrderLines READONLY`)
- `default` — the expression after `=`, verbatim
- `is_output` — `true` if `OUTPUT` (or the alias `OUT`) present
- `is_readonly` — `true` if `READONLY` present (required for table-type
  parameters)

For functions, capture `returns_shape` as one of:
- `scalar` — `RETURNS <scalar type>` with `RETURN <expr>` in body
- `inline_tvf` — `RETURNS TABLE` with a single `RETURN (<select>)` body
- `multi_statement_tvf` — `RETURNS @var TABLE (<columns>)` with body
  inserting into `@var` and a final `RETURN`
- `clr` — body is `EXTERNAL NAME <assembly>.<class>.<method>`

The three TVF shapes have different optimizer behavior; Design downstream
chooses differently per shape. Do not collapse them.

## Nested cursor detection

T-SQL cursors (`DECLARE <name> CURSOR FOR ...`) are a performance
anti-pattern on their own; a cursor inside another cursor's loop is
exponential. Nested cursors are common in legacy reporting procs.

**Detection.** Walk the body with a simple stack. Push on
`DECLARE ... CURSOR`, pop on `DEALLOCATE <name>` or `CLOSE <name>` followed
by `DEALLOCATE <name>`. When the stack depth exceeds 1 at any `DECLARE`,
emit a `NESTED_CURSOR` finding with the file, line, and containing
procedure name.

## Dynamic SQL — call sites

Dynamic SQL cannot be statically analyzed. Two entry points:

1. `EXEC(@sql)` or `EXECUTE(@sql)` — a string in a variable, executed.
   Emit `DYNAMIC_SQL_EXEC` with file and line.
2. `sp_executesql @sql, @params, ...` — parameterized dynamic SQL.
   Emit `DYNAMIC_SQL_SPEXEC` with file and line.

Also flag:
- `EXEC @result = <proc>` where `<proc>` is in a variable — indirect proc
  invocation.
- String concatenation of user-controlled values into a dynamic-SQL
  variable — SQLi risk. Grep the assignment lines feeding the variable
  for `+` with user-tainted sources (`@p`, `@username`).

## `MERGE` pitfalls — emit a finding on every occurrence

The `MERGE` statement has at least five well-known correctness bugs:

1. **NULL handling.** `MERGE` uses equality semantics that treat NULL
   matches as non-matches, silently duplicating rows whose key contains
   NULL.
2. **Unique-index violation under concurrency.** `MERGE` is not
   atomic with respect to the unique constraint enforcement; two
   concurrent `MERGE`s can both see "not matched" and both insert.
3. **Halloween protection failure.** Under some plans, the optimizer
   can read a row that the same `MERGE` is in the process of updating,
   producing incorrect results.
4. **`OUTPUT` clause data loss.** Combined with `WHEN NOT MATCHED BY
   SOURCE THEN DELETE`, the `OUTPUT` clause can emit rows that are
   immediately deleted, confusing audit triggers.
5. **Filtered-index miscosting.** The optimizer can choose a filtered
   index that does not cover the `MERGE` predicate, producing wrong
   results under plan changes.

Microsoft's own documentation now recommends `INSERT` + `UPDATE` pairs
or `INSERT ... ON CONFLICT` patterns (in later engines) instead of
`MERGE`. Emit `MERGE_REVIEW_REQUIRED` with file, line, and the target
table name for every `MERGE` occurrence. Do not attempt to rewrite.

## Temp tables vs. table variables vs. CTEs

Three superficially similar constructs with very different lifecycles:

- `#temp` / `##global_temp` — **temp table**, backed by `tempdb`, has
  statistics, participates in the query optimizer's cost-based plans,
  persists for the session (`#`) or globally (`##`). Can be indexed.
- `@var` — **table variable**, backed by `tempdb` but treated by the
  optimizer as having one row regardless of contents (pre-2019; 2019+
  has deferred compilation). No statistics.
- `WITH cte AS (...)` — **CTE**, not materialized; inlined into the
  consuming query. Recursive CTEs have `UNION ALL` + anchor-recursive
  split; non-recursive are plain subqueries with a name.

Extraction must record which construct is used at each call site; the
Design step chooses differently per construct. Grep for `CREATE TABLE #`,
`DECLARE @[A-Za-z_]+ TABLE`, and `WITH [A-Za-z_]+ AS \(`.

## CTEs — recursive vs. non-recursive

A CTE is **recursive** if the CTE body references the CTE's own name. The
grammar requires `UNION ALL` separating the anchor member from the
recursive member:

    WITH recursive_cte AS (
        SELECT ... FROM base WHERE ...      -- anchor
        UNION ALL
        SELECT ... FROM recursive_cte r     -- recursive reference
        JOIN ...
    )
    SELECT * FROM recursive_cte
    OPTION (MAXRECURSION 100)

Record the `MAXRECURSION` hint when present; the default is 100 and can
silently truncate deep trees. Non-recursive CTEs are treated as inline
views.

## `CROSS APPLY` and `OUTER APPLY`

`APPLY` invokes a table-valued expression once per outer row — the SQL
Server answer to a correlated subquery returning multiple columns.

- `CROSS APPLY` — inner-join semantics (outer rows without matches are
  dropped).
- `OUTER APPLY` — left-join semantics (outer rows preserved; inner
  columns NULL when no match).

Both require the right-hand side to reference the outer row. Record
every `APPLY` site as a dialect finding; direct translation to ANSI SQL
requires a `LATERAL` join in PostgreSQL or a correlated subquery
rewrite.

## Other T-SQL-specific constructs worth flagging

- `TOP n WITH TIES` — includes rows tied at position `n`; ANSI
  `FETCH FIRST n ROWS WITH TIES` is near-equivalent but requires an
  explicit `ORDER BY`.
- `OUTPUT` clause on DML — emits affected rows; useful for audit.
- `OPENROWSET` / `OPENQUERY` — out-of-database reads, including ad-hoc
  OLEDB. Flag as linked-server edges.
- `TRY_CONVERT(type, expr)` — returns NULL on conversion failure
  instead of raising.
- `FOR XML` / `FOR JSON` — serializes query result. Capture the mode
  (`AUTO`, `PATH`, `RAW`, `EXPLICIT`) — they have very different output
  shapes.
- `PIVOT` / `UNPIVOT` — record for translation-complexity.
- `WAITFOR` — pause execution; usually a smell in production code.

## Output — one finding per construct

Every construct in this reference emits a row into
`tsql-dialect-findings.json` with fields:

    {
      "id": "TSQL-<construct>-<ordinal>",
      "construct": "merge" | "dynamic_sql_exec" | ...,
      "file": "<relative path>",
      "line": <integer>,
      "severity": "info" | "low" | "medium" | "high" | "critical",
      "notes": "<short rationale>",
      "containing_object": "<schema.name or null>"
    }

The Design step consumes this file to plan translation complexity. High-
or critical-severity findings (every `MERGE`, every dynamic SQL, every
nested cursor) trigger human review at G-DE-2.
