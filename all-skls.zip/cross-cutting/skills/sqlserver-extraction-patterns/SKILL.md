---
name: sqlserver-extraction-patterns
description: >
  Extract a structured, citation-traceable representation of a SQL Server data
  tier from source artifacts during Modernization Extract. Parses `.sql` DDL
  scripts, SSDT `.sqlproj` declarative projects, migration directories, stored
  procedures, triggers, views, functions, user-defined types, and emits a
  restore plan for `.bak` binary backups. Respects T-SQL batch boundaries
  (`GO`), SQLCMD mode includes (`:r`, `:setvar`), and distinguishes declarative
  SSDT shape from imperative migration-script shape. Surfaces `MERGE` pitfalls,
  dynamic-SQL call sites, Row-Level Security policies, linked-server edges,
  and Always Encrypted column keys. Runs as an Extract conditional skill when
  `database` is `sqlserver`, `mssql`, or `sql server`. Emits schema, program-
  mability, migration-timeline, security, T-SQL dialect, and backup manifests
  with `{repo}:{file}:{line}` traceability on every claim. Triggers on SQL
  Server extraction, T-SQL extraction, SSDT extraction, sqlproj analysis,
  `.bak` inspection, or @sqlserver-extraction-patterns.
tier: 1
triggers:
  database: [sqlserver, mssql, "sql server"]
agent: sonnet
enrichment_level: Full
version: 0.1.0
allowed-tools:
  - Read
  - Write
  - Grep
  - Glob
  - Bash
validation_commands:
  - "python -m olympus.validators.schema_validator sqlserver-schema-manifest.json"
  - "python -m olympus.validators.schema_validator sqlserver-programmability-manifest.json"
  - "python -m olympus.validators.schema_validator sqlserver-migration-timeline.json"
  - "python -m olympus.validators.schema_validator sqlserver-security-manifest.json"
  - "python -m olympus.validators.schema_validator tsql-dialect-findings.json"
  - "python -m olympus.validators.schema_validator sqlserver-backup-manifest.json"
supported_stacks:
  - sqlserver
  - mssql
  - tsql
  - ssdt
  - sqlproj
anti_target_stacks:
  - oracle
  - postgresql
  - mysql
  - sqlite
  - static-site
failure_classes:
  - go-batch-separator-misparsed
  - sqlcmd-mode-unrecognized
  - ssdt-vs-migration-shape-confused
  - merge-pitfall-unflagged
  - dynamic-sql-opaque-unrecorded
  - bak-inspection-not-planned
  - refactorlog-discarded
  - linked-server-edge-missed
  - row-level-security-skipped
benchmark_tags:
  - modernization-extract
  - sqlserver-source-extraction
  - ssdt-declarative-handling
  - bak-restore-planning
---

# SQL Server Extraction Patterns

## Purpose
Recover a complete, schema-validated representation of a SQL Server data tier
from source artifacts during the Modernization Extract step so that Design and
Generate can reason about tables, programmability, migration order, and
security without re-parsing T-SQL. This skill is the SQL Server counterpart to
`oracle-extraction-patterns` and `postgres-extraction-patterns`: given a mixed
delivery of SSDT `.sqlproj` projects, raw T-SQL scripts, migration directories,
and native `.bak` backups, it emits a deterministic set of manifests covering
schema, programmability, migration timeline, security, T-SQL dialect findings,
and backup-restore plans. Without this pass, downstream Design sees SQL Server
as an opaque "sqlserver" token, cannot choose between preserving SSDT
declarative shape and generating Flyway-style migrations, and cannot plan for
`.bak`-only deliveries that require a live SQL Server instance to inspect.

## Inputs
- Source code repository containing `.sql`, `.sqlproj`, `.sln`, `.refactorlog`,
  `.publish.xml`, `.dacpac`, `.bacpac`, or `.bak` files.
- Application catalog entry (per
  `schemas/discovery/application-catalog-entry.schema.json`) with `database`
  field populated as `sqlserver`, `mssql`, or `sql server`.
- Discovery fingerprint (`dotnet-fingerprint.json` or equivalent) when the
  application is a .NET tier on SQL Server, to cross-reference connection
  strings and `DbContext` configuration.
- Client-profile risk-classification config
  (`profiles/<client>/risk-classification.yaml`) for tier banding of findings.
- Optional: a reachable SQL Server 2019+ instance for `.bak` restore plan
  execution. When absent, the skill emits restore commands as a prerequisite
  finding rather than attempting schema extraction from binary backups.
- Optional: SSDT command-line tools (`sqlpackage.exe`, `SqlPackage` on
  Linux/macOS) for `.dacpac`/`.bacpac` inspection.

## Outputs
- `sqlserver-schema-manifest.json` — one record per table, including columns
  (type, nullability, computed expression, default, collation), primary and
  foreign keys, unique constraints, check constraints, indexes (clustered,
  nonclustered, filtered, covering, columnstore, XML, spatial), synonyms,
  sequences, DML triggers, and user-defined types (table types, CLR types,
  alias types).
- `sqlserver-programmability-manifest.json` — stored procedures, scalar
  functions, inline TVFs, multi-statement TVFs, views (including indexed and
  schema-bound), DDL triggers, each with parameter list, body, and declared
  dependency list. Body preserved verbatim including `GO` batch boundaries.
- `sqlserver-migration-timeline.json` — ordered migration scripts when the
  repo uses an imperative pattern (`V001__init.sql`, `20240115_add_users.sql`,
  Flyway, DbUp, or a hand-rolled `DropScripts/`+`Tables/`+`Data/` layout).
  When the repo is SSDT-declarative, emits an empty timeline and a
  `schema_snapshot_source: "ssdt"` pointer to the `.sqlproj`.
- `sqlserver-security-manifest.json` — logins, server roles, database users,
  database roles, schema ownership, GRANT/REVOKE/DENY statements, Row-Level
  Security policies (`CREATE SECURITY POLICY`), predicate functions, Always
  Encrypted column master keys (CMK) and column encryption keys (CEK),
  Dynamic Data Masking specifications, and audit specifications.
- `tsql-dialect-findings.json` — call sites for T-SQL-specific constructs:
  `TOP n WITH TIES`, `OUTPUT` clause, `OPENROWSET`, `OPENQUERY`, `CROSS APPLY`
  / `OUTER APPLY`, `MERGE` (each `MERGE` flagged for review), `TRY_CONVERT`,
  window functions, `FOR XML`, `FOR JSON`, temp tables (`#t`), table
  variables (`@t`), CTEs (recursive and non-recursive), SQLCMD `:r` includes,
  and `:setvar` environment-dependent substitutions.
- `sqlserver-backup-manifest.json` — one record per discovered `.bak` with
  `{path, size_bytes, suspected_database_name, restore_commands,
  requires_live_instance: true, source_version_probe: "RESTORE HEADERONLY"}`.
- Finding records with canonical citation form
  `{artifact}:{section}:{finding-id}` and `{repo}:{file}:{line}` source
  evidence on every claim.

## Methodology
1. **Enumerate data-tier artifacts.** Walk the repository for the full SQL
   Server file family: `*.sql`, `*.sqlproj`, `*.sln`, `*.refactorlog`,
   `*.publish.xml`, `*.dacpac`, `*.bacpac`, `*.bak`. Bucket each artifact into
   one of {declarative, imperative, binary, deployment-profile, refactor-log,
   packaged}. Record the bucket distribution per repo — it drives the
   declarative-vs-imperative decision in step 3.
2. **Detect repo shape.** If one or more `.sqlproj` files exist, treat the
   covered directories as SSDT-declarative; load
   `references/ssdt-sqlproj-extraction.md` and parse the project XML for
   `<Build Include=...>` and
   `<None Include=...>` items, pre/post-deployment scripts, and the default
   schema. If only raw `.sql` files exist in numbered or dated directories
   (`V001__*.sql`, `2024-01-15-*.sql`, `Tables/`+`StoredProcedures/`+
   `Views/`+`Functions/`+`Triggers/`+`Data/`+`DropScripts/`), treat the
   repo as imperative-migration and follow the migration-timeline path.
   A single repo may contain both (DMS mixes SSDT `Dms.Database/` with raw
   `AuditLog.Database/Scripts/`); run both paths and emit separate records.
3. **Parse T-SQL respecting batches.** Use the T-SQL batch parser from
   `references/tsql-extraction-patterns.md`. Split on `GO` as a batch
   separator only when `GO` appears on its own line (case-insensitive,
   optional trailing count). Never split on `;` — it is a statement
   terminator, not a batch boundary. When SQLCMD markers (`:r`, `:setvar`,
   `:on error exit`, `!!`) appear, switch to SQLCMD mode and resolve `:r`
   includes relative to the including file's directory. Record each
   resolved include as a dependency edge.
4. **Extract schema objects.** For each `CREATE TABLE` batch, capture
   schema-qualified name, columns with type/nullability/computed/default/
   collation, primary key, foreign keys (with `ON DELETE`/`ON UPDATE`
   actions), unique constraints, check constraints, and inline indexes.
   For each `CREATE INDEX`, capture the index kind (clustered,
   nonclustered, unique, filtered with `WHERE`, covering with `INCLUDE`,
   columnstore, XML, spatial) and the owning table. For `CREATE TYPE`,
   distinguish table types, alias types, and CLR types (`EXTERNAL NAME`).
   Emit one schema-manifest record per object with the full source batch
   preserved as the `body` field.
5. **Extract programmability objects.** For each `CREATE PROCEDURE`,
   `CREATE FUNCTION`, `CREATE VIEW`, `CREATE TRIGGER`, capture
   schema-qualified name, parameter list (name, type, default, OUTPUT),
   return type (for functions), `WITH` options (`SCHEMABINDING`,
   `ENCRYPTION`, `EXECUTE AS`), and body. Parse the body for three
   dependency classes: static object references (resolved via regex over
   `FROM`/`JOIN`/`EXEC`/`INSERT INTO`), cursor declarations (emit a
   finding for every nested cursor — see gotcha), and dynamic SQL call
   sites (`EXEC(@sql)`, `sp_executesql`). Emit a finding for every
   dynamic-SQL site; static analysis cannot resolve its target.
6. **Build migration timeline.** For imperative repos, sort migration
   scripts by filename prefix (lexicographic for Flyway-style `V001__`,
   chronological for `YYYYMMDD_` prefixes). Record each script's path,
   ordinal, derived version string, detected operation class
   (schema-change | data-seed | permission-change | mixed), and whether
   it is reversible (presence of a paired `U###__*.sql` undo file). For
   SSDT repos, emit `migrations: []` and set `schema_snapshot_source` to
   the `.sqlproj` path.
7. **Extract security surface.** Grep for `CREATE LOGIN`, `CREATE USER`,
   `CREATE ROLE`, `ALTER ROLE ... ADD MEMBER`, `GRANT`, `REVOKE`, `DENY`,
   `CREATE SECURITY POLICY`, `CREATE COLUMN MASTER KEY`, `CREATE COLUMN
   ENCRYPTION KEY`, `MASKED WITH`, and `CREATE SERVER AUDIT`. Emit one
   record per finding. Row-Level Security is easily missed because its
   predicate function looks like any scalar function — explicitly match
   `SECURITY POLICY` as the authoritative signal.
8. **Emit T-SQL dialect findings.** For each T-SQL-specific construct
   enumerated in `references/tsql-extraction-patterns.md`, emit a
   finding with the construct name, file, line, and a short notes field.
   Every `MERGE` statement receives a `MERGE_REVIEW_REQUIRED` finding;
   Microsoft's own guidance now recommends `INSERT` + `UPDATE` pairs for
   correctness. Every dynamic-SQL site and every four-part name
   (`server.db.schema.object`) receives a finding.
9. **Emit backup manifest and restore plan.** For each `.bak` discovered,
   record path, size, and a suspected database name derived from the
   filename (`dms_new_20260410.bak` → `dms_new`). Emit restore commands:
   `RESTORE HEADERONLY FROM DISK = '<path>'` to probe source version and
   backup type, `RESTORE FILELISTONLY FROM DISK = '<path>'` to enumerate
   logical data/log files, and a parameterized `RESTORE DATABASE` with
   `WITH MOVE` clauses templated for the target instance. See
   `references/sqlserver-backup-restore-patterns.md`. Do NOT attempt to
   parse the `.bak` as text — it is proprietary binary and the manifest
   must flag it as requiring a live SQL Server 2019+ instance.
10. **Emit findings with traceability.** Every schema object,
    programmability object, migration record, security record, dialect
    finding, and backup record must carry both
    `{artifact}:{section}:{finding-id}` and at least one
    `{repo}:{file}:{line}` source citation. Records without citations are
    dropped by the validator.
11. **Validate and hand off.** Validate each emitted manifest against its
    schema under `schemas/extraction/sqlserver-*.schema.json`. Write all
    six manifests to the Extract working set and update the modernization
    plan's `data_tier` field with pointers to each.

## Tech-Stack Dispatch

| Trigger | Key patterns |
|---|---|
| `.sqlproj` present | SSDT declarative project, one `.sql` per object, `.refactorlog` renames, `.publish.xml` deployment profile, builds to `.dacpac` |
| Numbered `V###__*.sql` or dated `YYYYMMDD_*.sql` files | Flyway/DbUp-style imperative migration; ordinal timeline required |
| `Tables/`+`StoredProcedures/`+`Views/`+`Functions/`+`Triggers/`+`Data/` tree without `.sqlproj` | Hand-rolled declarative layout; treat as SSDT-equivalent shape but with no project-file metadata |
| `.bak` present, no `.sql` | Binary-only delivery; restore-plan only, schema extraction deferred until live instance available |
| `.dacpac` or `.bacpac` present | Compiled SSDT artifact; extract via `sqlpackage /Action:Extract` or unzip (they are zip files with a model.xml inside) |
| `:r ` or `:setvar ` on any line | SQLCMD mode required; plain T-SQL parsers miss includes |

Detection is mechanical: presence of one signal triggers the matching
reference pattern. Multiple signals fire simultaneously in mixed repos
(DMS is the canonical case). Overlap with `sqlserver-discovery-patterns`
is explicit — discovery runs in Discovery and identifies the database
engine; extraction runs in Modernization Extract and consumes that
finding to decide whether to run at all.

## Gotchas
- **`.bak` is binary and requires a live SQL Server.** Native backups use
  Microsoft's proprietary virtual-device format. There is no public parser.
  When the only delivery is `.bak` (FAA RMS ships two: `aa_airman_data_
  20260410.bak` and `ar_aircraft_data_20260410.bak`), this skill emits a
  restore plan and a prerequisite finding rather than schema. Design and
  Generate cannot proceed until the restore plan is executed.
- **SSDT declarative and migration imperative are fundamentally different
  extraction shapes.** SSDT stores the *target state* as one `.sql` per
  object; migrations store an *ordered sequence* of state changes. Emitting
  a migration timeline from an SSDT repo produces nonsense ordinals.
  Detect via `.sqlproj` presence before choosing shape.
- **DMS mixes both shapes in one repo.** `Dms.Database/Dms.Database.sqlproj`
  is SSDT; `AuditLog.Database/Scripts/` is a hand-rolled migration set
  with `build.sql`, `run.ps1`, and even a `.pgpass` pointing to PostgreSQL.
  Both extraction paths must run; emit separate manifest records keyed by
  source subdirectory.
- **`GO` is a batch separator, not a statement terminator.** Standard SQL
  parsers split on `;` and produce wrong output for T-SQL. Split only on
  `GO` when it is on its own line (case-insensitive, optional trailing
  count). Missing this produces batches that mix unrelated objects.
- **SQLCMD mode is not T-SQL.** `:r`, `:setvar`, `:on error exit`, `!!`
  are SQLCMD-utility directives and will cause parse errors in any
  T-SQL-only parser. Detect the first SQLCMD marker at file head and
  switch modes. Resolve `:r` includes as dependency edges; never inline.
- **`MERGE` has at least five documented correctness bugs.** Null handling,
  unique-index violations under concurrent inserts, Halloween-protection
  edge cases, `OUTPUT` clause data loss, and incorrect results with
  filtered indexes. Microsoft's own documentation now cautions against
  `MERGE`. Emit `MERGE_REVIEW_REQUIRED` for every occurrence.
- **Dynamic SQL is unanalyzable statically.** `EXEC(@sql)` and
  `sp_executesql @sql` build SQL at runtime. Static analysis cannot
  resolve their targets. Emit a finding for every call site so Design
  knows manual review is required.
- **`.refactorlog` records SSDT renames.** Without `.refactorlog`, a
  schema comparison interprets a rename as a drop-and-recreate, which
  destroys data on deployment. Preserve `.refactorlog` files verbatim in
  the extraction output; do not normalize or rewrite.
- **Pre-existing typos in paths are preservation targets, not cleanup
  targets.** MedXPress ships a `Strored Procedures/` directory (double
  `r`). Extraction must preserve the original name in all manifests.
  Normalizing it silently breaks every downstream reference.
- **Newer `.bak` cannot restore to older SQL Server.** A backup from SQL
  Server 2022 cannot restore to 2019. The restore plan must probe the
  source version via `RESTORE HEADERONLY` and emit a prerequisite
  finding when the version is unknown or exceeds the target instance.
- **Row-Level Security is grep-only.** `CREATE SECURITY POLICY` and its
  paired predicate function are easy to miss in a large repo because the
  predicate function looks like any scalar function. Grep explicitly for
  `SECURITY POLICY`.
- **Linked servers create cross-database edges.** `sp_addlinkedserver`,
  `OPENQUERY`, `OPENROWSET`, and four-part names
  (`server.db.schema.object`) reach outside the database and do not
  appear in schema-only extraction. Emit findings for every occurrence;
  dependency-mapper consumes them.
- **Always Encrypted keys live outside the database.** The CMK points to
  an external key store (Azure Key Vault, Windows Certificate Store, HSM)
  via a provider URI. Schema extraction sees only the CEK wrapped by the
  CMK; the CMK itself is out-of-repo. Flag as a prerequisite finding.
- **`.dacpac` and `.bacpac` are zip files.** They are openable without
  SQL Server — unzip and parse `model.xml`. The schema is XML, not SQL;
  do not feed it to the T-SQL parser.

## Quality Rules
- [ ] Every table, view, procedure, function, trigger, index, synonym,
      sequence, and user-defined type has exactly one record in the
      appropriate manifest, with `body` preserved verbatim including
      `GO` batch markers.
- [ ] Every manifest record cites at least one `{repo}:{file}:{line}`
      source line.
- [ ] The T-SQL batch parser splits only on `GO` on its own line
      (case-insensitive), never on `;`.
- [ ] Every `MERGE` statement emits a `MERGE_REVIEW_REQUIRED` dialect
      finding with file:line citation.
- [ ] Every dynamic-SQL call site (`EXEC(@sql)`, `sp_executesql`) emits
      a `DYNAMIC_SQL` finding.
- [ ] Every four-part name and every `OPENQUERY`/`OPENROWSET` call
      emits a `LINKED_SERVER` finding.
- [ ] Every `CREATE SECURITY POLICY` emits an `RLS_POLICY` record in the
      security manifest with the associated predicate function resolved.
- [ ] Every `.bak` file discovered has a backup-manifest record with
      `requires_live_instance: true` and a `RESTORE HEADERONLY` command
      templated with its path.
- [ ] SSDT `.refactorlog` files are preserved verbatim and referenced by
      path in the schema manifest.
- [ ] Pre-existing directory-name typos are preserved; no normalization.
- [ ] Emitted manifests validate against their schemas under
      `schemas/extraction/sqlserver-*.schema.json` with no
      `additionalProperties` violations.

## Common Failure Modes
| Failure Mode | Symptom | Prevention |
|---|---|---|
| T-SQL parser splits on `;` instead of `GO` | Batches mix unrelated objects; `CREATE PROCEDURE` bodies split mid-statement; downstream Design sees malformed DDL | Implement the batch splitter against `GO` on its own line, case-insensitive; never treat `;` as a batch boundary |
| SSDT repo treated as imperative migration | Empty migration timeline emitted as if ordered scripts existed; Design generates redundant DDL | Detect `.sqlproj` before choosing extraction path; emit `schema_snapshot_source: "ssdt"` and skip timeline |
| `.bak` parsed as text | Garbage tokens emitted as schema; extraction "succeeds" with nonsense manifests | Bucket files by extension first; `.bak` goes to the backup manifest with a restore plan, never to the T-SQL parser |
| SQLCMD `:r` includes silently dropped | Dependency graph missing edges; objects reference "undefined" tables that exist in an included file | Detect SQLCMD mode at file head; resolve `:r` relative to the including file and emit dependency edges |
| `MERGE` statements emitted without review findings | Downstream Generate produces code that silently carries `MERGE` correctness bugs into the modernized tier | Emit `MERGE_REVIEW_REQUIRED` on every occurrence, no exceptions |
| `.refactorlog` discarded during extraction | Schema comparison on deployment drops and recreates renamed objects, destroying data | Preserve `.refactorlog` as a first-class artifact; reference from schema manifest |
| Pre-existing typo normalized | `Strored Procedures/` silently rewritten to `Stored Procedures/`; every downstream reference breaks | Treat original filenames as immutable; preserve verbatim including known typos |
| RLS policy missed | Security manifest omits row-filter predicates; modernized tier exposes data that was filtered in source | Explicit grep for `CREATE SECURITY POLICY`; never infer RLS from predicate-function naming |

## Handoff Summary
When this skill completes, verify:
1. Every discovered `.sql`, `.sqlproj`, and `.bak` appears in exactly one
   manifest (schema, programmability, migration-timeline, security, or
   backup) with `{repo}:{file}:{line}` traceability.
2. The repo-shape decision (SSDT declarative vs. imperative migration vs.
   mixed) is recorded explicitly in the schema manifest's
   `extraction_shape` field.
3. Every `.bak` has a restore plan that includes `RESTORE HEADERONLY`,
   `RESTORE FILELISTONLY`, and a parameterized `RESTORE DATABASE` with
   `WITH MOVE` clauses. No `.bak` is silently skipped.
4. Every `MERGE`, dynamic-SQL site, linked-server reference, and RLS
   policy has a finding.
5. All six manifests validate against their schemas.

Then proceed to: `data-tier-designer` in Modernization Design — which
consumes the schema manifest and migration timeline to plan the target
data-tier shape; `security-policy-extractor` — which consumes the
security manifest; and `dependency-mapper` — which folds linked-server
edges into the cross-application dependency graph. The next gate is
**G-DE-1** (Data Extraction Completeness) where manifests must be
accepted before Design begins.

## References
- `references/tsql-extraction-patterns.md` — T-SQL dialect parsing:
  `GO` batch boundaries, SQLCMD mode, stored-proc parameter extraction,
  nested cursor detection, dynamic SQL call sites, `MERGE` pitfalls,
  temp tables vs table variables, recursive CTEs, `CROSS APPLY`/
  `OUTER APPLY`.
- `references/ssdt-sqlproj-extraction.md` — SSDT project structure,
  declarative vs imperative detection, `.refactorlog` rename history,
  `.publish.xml` deployment profiles, `.dacpac`/`.bacpac` extraction,
  pre/post-deployment scripts, the SSDT-to-migration directionality
  choice during modernization.
- `references/sqlserver-backup-restore-patterns.md` — `.bak` inspection
  via `RESTORE HEADERONLY` / `RESTORE FILELISTONLY`, version
  compatibility matrix, schema extraction via `sys.tables` /
  `sys.columns` / `sys.foreign_keys` / `sys.indexes`, schema export via
  `SELECT ... FOR JSON`, full/differential/log backup chains, data
  extraction via `bcp` and `INSERT SELECT`.
- `schemas/extraction/sqlserver-schema-manifest.schema.json`
- `schemas/extraction/sqlserver-programmability-manifest.schema.json`
- `schemas/extraction/sqlserver-migration-timeline.schema.json`
- `schemas/extraction/sqlserver-security-manifest.schema.json`
- `schemas/extraction/tsql-dialect-findings.schema.json`
- `schemas/extraction/sqlserver-backup-manifest.schema.json`

## Changelog
- 0.1.0 (2026-05-06) — Initial skill scaffolded for ATLAS Extract
  coverage. Handles SSDT `.sqlproj` declarative projects, T-SQL
  migration directories, raw DDL trees, and `.bak` restore-plan
  emission. Emits six manifests: schema, programmability, migration
  timeline, security, T-SQL dialect findings, and backup plan. Full
  enrichment level; feeds `data-tier-designer`,
  `security-policy-extractor`, and `dependency-mapper` downstream.
  Validated against FAA DMS (SSDT + PostgreSQL audit mix), FAA IACRA
  (mixed declarative/migration tree, 88KB T-SQL + 30MB `.bak`), and
  FAA RMS (two `.bak` deliverables, 44KB T-SQL).
