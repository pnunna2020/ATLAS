---
name: discovery-readiness-gate
description: >
  Quality firewall ensuring Discovery outputs are complete, consistent, and
  traceable before feeding into Rationalization and downstream assembly lines.
  Use after all SDR area passes complete. Triggers on discovery gate, readiness
  check, quality validation, discovery completeness, G-DC gate.
agent: sonnet
allowed-tools:
  - Read
  - Grep
---

# Discovery Readiness Gate

## Purpose
Act as a quality firewall between Discovery and all downstream consumers:
Rationalization, Architecture, Data, and Modernization assembly lines. No
discovery output may proceed downstream until this gate validates completeness,
consistency, and traceability.

This gate exists because incomplete discovery is the single most expensive
failure mode in the pipeline. A missing endpoint discovered during Modernization
means rework across Architecture, Data, and Modernization lines. A contradictory
business rule discovered during Validation means the entire Extract-Design-Generate
cycle must restart. Catching these issues here costs hours; catching them
downstream costs weeks.

## Inputs
- Interface inventory (from sdr-area-interface)
- Business rules catalog (from extraction)
- Persistence inventory (from sdr-area-persistence)
- Source code repository (for file:line verification)
- Configuration (coverage threshold, artifact paths)

## Outputs
- Readiness report (assets/readiness-checklist-template.md)
- Pass/Fail determination with detailed justification
- Gap report (if FAIL) identifying specific deficiencies per area skill

## Validation Checks

### Check 1 — Source File Coverage (>= 95%)
Verify that the discovery process visited substantially all source files:
- List all source files in the repository (exclude vendor, node_modules, build)
- Cross-reference against files mentioned in interface inventory handler_file,
  business rules catalog source_file, and persistence inventory source_file
- Calculate coverage percentage
- Files not visited may contain undiscovered endpoints, rules, or data access

Threshold: coverage_threshold from config (default 95%). Below threshold = FAIL.

### Check 2 — File:Line Reference Integrity
Verify that all file:line references in discovery artifacts resolve to actual code:
- Sample minimum 20% of all file:line references across all three inventories
- For each reference, read the file and verify the line number contains relevant
  code (not blank lines, comments, or unrelated code)
- Any reference that does not resolve is a traceability failure

Threshold: 100% of sampled references must resolve. Any failure = FAIL.

### Check 3 — Interface Inventory Completeness
Verify the interface inventory covers all discoverable endpoints:
- Run an independent route scan (grep for framework-specific route patterns)
- Compare independent scan results against interface inventory
- Every endpoint found by independent scan must appear in the inventory
- Endpoints in inventory but not in scan are acceptable (manually discovered)

Threshold: 100% of independently-scanned endpoints must be in inventory. Missing = FAIL.

### Check 4 — Business Rules Catalog Completeness
Verify the business rules catalog has no incomplete entries:
- No rule may have empty or TBD fields for: id, category, description,
  source_file, source_line, logic
- Every rule must have at least one test scenario
- Cross-validation section must be populated (contradictions and gaps documented)
- 3-pass completion flag must be set

Threshold: Zero incomplete entries. Any incomplete entry = FAIL.

### Check 5 — Schema Inventory Accuracy
Verify the persistence inventory matches the actual database schema:
- If live database access is available, compare inventory against
  information_schema or system catalogs
- If not, compare against ORM model definitions, migration files, and DDL scripts
- Every table in the schema must appear in the inventory
- Every stored procedure must be classified (CRUD-only vs business-logic)

Threshold: 100% table coverage. Missing tables = FAIL.

### Check 6 — Cross-Artifact Consistency
Verify there are no contradictions between the three discovery artifacts:
- Every endpoint handler in the interface inventory should have corresponding
  business rules in the rules catalog (unless classified as pure CRUD)
- Every table in the persistence inventory should be referenced by at least
  one data access trace
- Stored procedures classified as containing business logic must have
  corresponding entries in the business rules catalog
- No business rule should reference a table not in the persistence inventory

Threshold: Zero unresolved contradictions. Any contradiction = FAIL.

### Check 7 — Dependency Graph Completeness
Verify all discovered integrations are documented:
- External services from interface inventory must all have connection details
- Shared database patterns from persistence inventory must identify all
  consuming applications
- Message consumers must have corresponding queue/topic documentation
- Batch job dependencies must form a valid DAG (no circular dependencies)

Threshold: All integrations documented. Undocumented integration = FAIL.

## Scoring
Each check produces: PASS, FAIL, or WARN (non-blocking concern).

**Overall determination:**
- All 7 checks PASS = **GATE PASSED** (proceed to Rationalization)
- Any check FAIL = **GATE FAILED** (return to specific area skill)
- WARN only = **GATE PASSED WITH CONDITIONS** (proceed but track warnings)

## Quality Rules
- [ ] All 7 validation checks have been executed (not skipped)
- [ ] File:line sampling covers minimum 20% of all references
- [ ] Independent route scan was performed (not just inventory review)
- [ ] Cross-artifact consistency check covers all three inventories
- [ ] Gap report (if FAIL) identifies specific remediation actions
- [ ] Readiness report uses the standard template with pass/fail per check
- [ ] No check result is estimated or assumed — each is based on actual verification

## Common Failure Modes

| Failure | Symptom | Prevention |
|---------|---------|------------|
| Rubber-stamp pass | Gate always passes regardless of quality | Run independent scans, verify file:line references |
| Incomplete sampling | Issues missed because sample was too small | Enforce minimum 20% sample for file:line checks |
| Missing cross-check | Contradictions between artifacts not caught | Check all three artifacts against each other |
| Scope creep in gate | Gate takes too long, becomes a bottleneck | Stick to the 7 defined checks, no ad-hoc analysis |
| False fail on vendor code | Vendor/library files counted as unvisited | Exclude vendor directories from coverage calculation |

## Handoff Summary
**If PASS:**
1. Generate readiness report documenting all check results
2. Archive discovery artifacts as gate-approved versions
3. Proceed to Rationalization assembly line
4. Discovery artifacts are now the authoritative source for downstream lines

**If FAIL:**
1. Generate gap report identifying every deficiency
2. Map each deficiency to the responsible area skill:
   - Missing endpoints -> sdr-area-interface
   - Incomplete rules -> extraction
   - Missing schema objects -> sdr-area-persistence
3. Return to the specific area skill(s) for remediation
4. Re-run this gate after remediation is complete
