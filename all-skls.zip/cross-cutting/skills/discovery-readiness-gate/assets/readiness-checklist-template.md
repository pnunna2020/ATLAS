# Discovery Readiness Gate — Checklist Report

## Application
- **Name**: 
- **Repository**: 
- **Assessment Date**: 
- **Assessor**: discovery-readiness-gate (automated)

---

## Overall Determination

**Result**: PASS / FAIL / PASS WITH CONDITIONS

---

## Check Results

### Check 1 — Source File Coverage

| Metric | Value |
|--------|-------|
| Total source files in scope | |
| Files visited by discovery | |
| Coverage percentage | |
| Threshold | 95% |
| **Result** | PASS / FAIL |

**Unvisited files (if any):**
- 

---

### Check 2 — File:Line Reference Integrity

| Metric | Value |
|--------|-------|
| Total file:line references | |
| Sample size (minimum 20%) | |
| References verified | |
| References failed | |
| **Result** | PASS / FAIL |

**Failed references (if any):**
- File: , Line: , Expected: , Found: 

---

### Check 3 — Interface Inventory Completeness

| Metric | Value |
|--------|-------|
| Endpoints in inventory | |
| Endpoints from independent scan | |
| Missing from inventory | |
| **Result** | PASS / FAIL |

**Missing endpoints (if any):**
- Route: , Method: , Source: 

---

### Check 4 — Business Rules Catalog Completeness

| Metric | Value |
|--------|-------|
| Total rules in catalog | |
| Rules with complete fields | |
| Rules with test scenarios | |
| 3-pass flag set | Yes / No |
| Cross-validation populated | Yes / No |
| **Result** | PASS / FAIL |

**Incomplete rules (if any):**
- Rule ID: , Missing fields: 

---

### Check 5 — Schema Inventory Accuracy

| Metric | Value |
|--------|-------|
| Tables in database/DDL | |
| Tables in inventory | |
| Stored procs classified | |
| Missing tables | |
| **Result** | PASS / FAIL |

**Missing schema objects (if any):**
- Object: , Type: , Source: 

---

### Check 6 — Cross-Artifact Consistency

| Metric | Value |
|--------|-------|
| Endpoints without business rules (non-CRUD) | |
| Business rules referencing unknown tables | |
| Stored procs with logic but no rule entry | |
| Tables with no data access trace | |
| Contradictions found | |
| **Result** | PASS / FAIL |

**Contradictions (if any):**
- Artifact A: , Artifact B: , Description: 

---

### Check 7 — Dependency Graph Completeness

| Metric | Value |
|--------|-------|
| External services documented | |
| Shared DB patterns documented | |
| Message consumers documented | |
| Batch dependencies valid (no cycles) | Yes / No |
| Undocumented integrations | |
| **Result** | PASS / FAIL |

**Undocumented integrations (if any):**
- Type: , Evidence: , Location: 

---

## Warnings (Non-Blocking)

- 

---

## Gap Report (If FAIL)

### Remediation Actions Required

| Gap | Responsible Skill | Specific Action | Priority |
|-----|-------------------|-----------------|----------|
| | sdr-area-interface / extraction / sdr-area-persistence | | |

### Estimated Remediation Effort

- 

---

## Sign-Off

- **Gate executed by**: discovery-readiness-gate
- **Date**: 
- **Next step**: Rationalization (if PASS) / Remediation (if FAIL)
