---
name: cross-validation
description: >
  Cross-validate extracted specifications against source code to find contradictions, gaps, and implicit behaviors. Use after extraction pass 1-2, before G-04a gate. Triggers on cross-validation, spec validation, extraction verification.
agent: sonnet
allowed-tools:
  - Read
  - Write
  - Bash
  - Grep
---

# Cross Validation

## Purpose
The quality gate for extraction — catches the 5-15% of specs that look right but are wrong.

## Gotchas
- **Cross-validation finds contradictions between passes**: If Pass 1 says
  "discount is 10% for orders > $100" but Pass 2's test expects 15%, that's
  a contradiction that must be resolved with SME input.
- **Implicit behaviors are the hardest to catch**: Legacy code may depend on
  database default values, environment variables, or execution order that
  isn't documented anywhere. Look for absent assertions.

## Quality Rules
- [ ] Every contradiction between Pass 1 (rules) and Pass 2 (tests) is identified and documented
- [ ] Each contradiction has a resolution: keep, discard, or merge — no unresolved items
- [ ] Implicit behaviors (DB defaults, env vars, execution order) are documented as explicit rules
- [ ] Cross-validation covers both application code and database-resident logic (stored procedures, triggers)
- [ ] Absent assertions (behaviors assumed but not tested) are flagged for SME review
- [ ] Cross-validation output includes a reconciled specification that supersedes individual pass outputs

## Common Failure Modes
| Failure Mode | Symptom | Prevention |
|-------------|---------|------------|
| Contradictions shipped unresolved | Pass 1 says 10% discount, Pass 2 tests 15%; generated code implements one arbitrarily | Require explicit resolution (keep/discard/merge) for every contradiction before handoff |
| Implicit behavior missed | Modernized app behaves differently because DB default or env variable dependency was not captured | Scan for DB defaults, environment references, and execution-order dependencies during cross-validation |
| Scope limited to application code | Stored procedure business logic not cross-validated; specs incomplete | Include all database-resident logic in cross-validation scope |
| Cross-validation skipped for speed | Extraction looks complete but has 5-15% internal inconsistencies; downstream generation fails | Enforce cross-validation as mandatory Pass 3 — never optional, never deferred |

## Handoff Summary
When this skill completes, verify:
1. All contradictions are resolved (zero unresolved items)
2. Implicit behaviors are documented as explicit rules
3. Reconciled specification is produced and supersedes individual pass outputs
4. Database-resident logic is included in cross-validation scope
Then proceed to: gate `G-04a` for extraction completeness review, then `module-design` (P4.2)
