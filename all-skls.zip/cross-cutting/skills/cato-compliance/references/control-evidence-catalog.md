# Control Evidence Catalog — What Satisfies Each Control

## AC-2 Account Management
- Evidence: OKTA configuration export showing account provisioning rules
- Evidence: Screenshot/export of quarterly access review completion
- Automated: `scripts/check_okta_config.py` validates required policies exist

## AU-2 Audit Events
- Evidence: CloudWatch/Datadog log configuration showing required event types
- Evidence: Sample log entries demonstrating all required fields present
- Automated: `scripts/validate_log_format.py` checks log schema compliance

## CM-2 Baseline Configuration
- Evidence: Terraform/CDK code defining infrastructure baseline
- Evidence: Drift detection report showing no unauthorized changes
- Automated: IaC scan in CI/CD pipeline

## SC-28 Protection at Rest
- Evidence: AWS Config rule showing encryption enforcement
- Evidence: KMS key policy showing access restrictions
- Automated: `scripts/check_encryption.py` scans all data stores
