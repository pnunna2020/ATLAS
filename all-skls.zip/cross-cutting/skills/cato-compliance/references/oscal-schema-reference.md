# OSCAL 1.1.2 Schema Quick Reference

## SSP Structure
```json
{
  "system-security-plan": {
    "uuid": "uuid-v4",
    "metadata": { "title": "", "version": "", "oscal-version": "1.1.2" },
    "import-profile": { "href": "nist-800-53-rev5-high-baseline" },
    "system-characteristics": {
      "system-name": "",
      "system-id": { "identifier-type": "faa-system-id" },
      "security-sensitivity-level": "moderate|high",
      "system-information": { "information-types": [] },
      "security-impact-level": {
        "security-objective-confidentiality": "moderate",
        "security-objective-integrity": "moderate|high",
        "security-objective-availability": "high"
      },
      "authorization-boundary": { "description": "" }
    },
    "system-implementation": {
      "users": [],
      "components": [],
      "inventory-items": []
    },
    "control-implementation": {
      "implemented-requirements": []
    }
  }
}
```

## Implemented Requirement Structure
```json
{
  "uuid": "uuid-v4",
  "control-id": "ac-2",
  "statements": [{
    "statement-id": "ac-2_smt",
    "by-components": [{
      "component-uuid": "reference-to-component",
      "description": "How this component satisfies the control",
      "implementation-status": { "state": "implemented|partial|planned" }
    }]
  }]
}
```

## CRITICAL: Always use `by-components` to link controls to specific components.
## A control without a component reference is an audit finding.
