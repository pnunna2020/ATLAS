---
name: cato-compliance
description: >
  Generate OSCAL-formatted SSP, SAR, and POA&M artifacts for continuous
  Authority to Operate (cATO). Use at every P4 stage for evidence generation,
  at P5.2 for security certification, and at P3.2 for cATO collector setup.
  Triggers on mentions of cATO, OSCAL, SSP, SAR, POA&M, security authorization,
  or ATO evidence.
agent: sonnet
allowed-tools:
  - Read
  - Write
  - Bash
---

# cATO Compliance — OSCAL Artifact Generation

## Purpose
Generate machine-readable security authorization evidence at every stage of
the factory pipeline. The goal is embedded security, not bolt-on — artifacts
are generated as code is generated, not after.

## Quick Reference

| Artifact | Format | When Generated | Gate |
|----------|--------|---------------|------|
| SSP (System Security Plan) | OSCAL JSON | P4.2 (design) | G-04b |
| SAR (Security Assessment Report) | OSCAL JSON | P5.2 (validate) | Certification |
| POA&M (Plan of Action & Milestones) | OSCAL JSON | P5.2 (validate) | Certification |
| Control Evidence | Structured JSON | P4.3 (generate) | G-04c |
| Vulnerability Scan Results | SARIF + OSCAL | P4.3, P5.2 | G-04c |

## Workflow

1. Check `config.json` for app safety tier (T1/T2/T3) — this determines rigor
2. Read the current pipeline stage from config
3. Load `references/oscal-schema-reference.md` for the artifact type needed
4. Generate the artifact using the appropriate template from `assets/`
5. Run `scripts/validate_oscal.py` to verify schema compliance
6. If validation fails, fix and re-validate before proceeding

## Gotchas

- **OSCAL version matters**: FAA expects OSCAL 1.1.2. Claude sometimes generates
  1.0.x schema. Always validate with `scripts/validate_oscal.py`.
- **Don't generate SSP from scratch each time**: The SSP is a living document.
  For subsequent apps, MERGE new controls into the existing SSP rather than
  regenerating. Use `scripts/merge_oscal_ssp.py`.
- **Inherited controls must reference the provider**: When a control is inherited
  from OKTA or CyberArk, the SSP must include a `by-component` reference to
  the shared service. Claude often omits this linkage.
- **POA&M is not a to-do list**: Each POA&M item needs a risk assessment,
  scheduled completion date, responsible party, and compensating control.
  Claude tends to generate POA&M items that are too vague.
- **T1 safety-critical apps need ADDITIONAL evidence**: Beyond standard cATO,
  T1 apps require safety case documentation that cross-references security
  controls. See `references/t1-safety-security-crosswalk.md`.

## Reference Files
- `references/oscal-schema-reference.md` — OSCAL 1.1.2 schema quick reference
- `references/control-evidence-catalog.md` — What evidence satisfies each control
- `references/t1-safety-security-crosswalk.md` — Safety-critical security requirements

## Quality Rules
- [ ] All OSCAL artifacts validate against OSCAL 1.1.2 schema via `scripts/validate_oscal.py` — no 1.0.x artifacts
- [ ] SSP includes `by-component` references for all inherited controls (OKTA, CyberArk, shared infrastructure)
- [ ] Every POA&M item has a risk assessment, scheduled completion date, responsible party, and compensating control
- [ ] Control evidence is generated at the same pipeline stage as the code it describes — not bolted on after the fact
- [ ] T1 safety-critical apps have additional safety case documentation cross-referencing security controls
- [ ] SSP updates for subsequent apps use merge strategy (`scripts/merge_oscal_ssp.py`), not full regeneration
- [ ] Vulnerability scan results are in both SARIF and OSCAL formats for toolchain compatibility
- [ ] SAR findings are traceable to specific controls and include remediation recommendations
- [ ] All artifacts reference the correct safety tier (T1/T2/T3) from `config.json`

## Common Failure Modes
| Failure Mode | Symptom | Prevention |
|-------------|---------|------------|
| Wrong OSCAL version | Artifacts generated with OSCAL 1.0.x schema; FAA tooling rejects them | Always validate with `scripts/validate_oscal.py` which enforces 1.1.2; check schema version in output |
| Inherited controls missing provider reference | SSP lists controls as "implemented" that are actually inherited from OKTA or CyberArk | Cross-reference shared service catalog; ensure `by-component` linkage for every inherited control |
| Vague POA&M items | POA&M entries say "fix vulnerability" without risk level, date, owner, or compensating control | Validate each POA&M item against the 4-field completeness check before accepting |
| SSP regenerated instead of merged | New app deployment overwrites existing SSP, losing previous app control documentation | Use `scripts/merge_oscal_ssp.py` for all SSP updates after the first generation |
| T1 safety evidence gap | Safety-critical app passes standard cATO but lacks safety case cross-references; ISSO flags it | Check safety tier in config; if T1, require `references/t1-safety-security-crosswalk.md` evidence |

## Phase 3 — ATLAS ChBA

> **Trace:** Phase 2 §B.5 commits OSCAL-formatted control evidence per build, ingested into FAA CSAM, with structurally-validated NIST 800-53 control families. Closes P3-R13, P3-R38, P3-R41, P3-R44, P3-R45, P3-R94, P3-R117. Source-of-truth: `docs/phase3/phase2-commitments.md` §B.5 + SF3 §4.3.

### Bind to the 10 named NIST 800-53 control families (RISK-3 closer)

The Phase 2 commitment is to ten *named* NIST 800-53 families. The Phase 3 OSCAL emission MUST enumerate per-family pass/fail — not just "controls implemented" in the aggregate. Drift on the named list is a graded inconsistency in the FAA evaluator's hands.

| Family | What Phase 2 commits | Phase 3 artifact that proves it | How to validate |
|---|---|---|---|
| **AC-3 (Access Enforcement)** | Policy-as-code at edge gateway + service mesh; per-request authorization (P2 §B.5; SF3 §4.1) | OPA policy bundle in `iac/opa/`, Traefik middleware config, role-keyed route guards in React shell | OSCAL `implemented-requirement` references `by-component` of OPA policy bundle + edge gateway; runtime test in `tests/cato/test_ac3_enforcement.py` exercises a deny path |
| **AC-2 (Account Management)** | Login.gov for applicants; FICAM/PIV/CAC for FAA staff; single FTN per identity (P2 §B.3; §F.1) | Keycloak realm export with role/scope mapping; `/applications/admin/users` audit endpoint | Evidence references Keycloak realm hash; `scripts/validate_oscal.py --check-ac2-coverage` |
| **AC-4 (Information Flow Enforcement)** | PHI never crosses the `medical.cert-status` boundary; S6 exposes only boolean + expDate (P2 §B.4) | OPA policy `phi-boundary.rego` rejecting cross-boundary reads; FastAPI middleware that strips PHI fields at S5↔S6 boundary | `tests/cato/test_phi_boundary.py` proves S5 cannot read PHI; OSCAL fragment cites the boundary policy |
| **IA-5 (Authenticator Management)** | NIST SP 800-63-3 IAL/AAL bar; PBKDF2 password migration (P2 §B.3, A6 DIWS §1) | Keycloak password policy config; secrets in Doppler/Docker secrets, not source | OSCAL fragment cites Keycloak policy export + secrets-management config; secrets scan (Trivy) shows zero hits |
| **AU-2 (Auditable Events)** | Immutable audit logs; security-relevant events captured (P2 §B.5) | OTEL audit-event tap + Loki ingestion; `audit.event` canonical entity (P2 §B.4) | OSCAL fragment cites Loki index + retention policy; `tests/cato/test_au2_event_coverage.py` |
| **AU-10 (Non-repudiation)** | RFC 3161 trusted timestamps on credentials and signatures (P2 §B.3) | S9 PKI signer + RFC 3161 TSA call (Phase 3 prototype: freetsa.org); production: AWS Private CA + ACM | OSCAL fragment cites S9 build hash and TSA endpoint; sample signed credential in `evidence/au10/` |
| **AU-12 (Audit Generation)** | Centralized audit log pipeline; correlation IDs across services (P2 §B.5) | OTEL SDK in every service; Loki centralized logging; correlation-ID middleware | OSCAL fragment cites the OTEL config + Loki index; `tests/cato/test_au12_correlation.py` proves a request hop is traceable end-to-end |
| **SC-12 (Cryptographic Key Establishment & Management)** | Per-bounded-context key hierarchy; AesGcm w/ random nonce as the portfolio reference (P2 §B.3; DMS A6 §1) | KMS/key-management config (Phase 3: local OpenSSL CA + key-rotation script; production: AWS KMS); per-service key isolation | OSCAL fragment cites the key-management config; key-isolation test in `tests/cato/test_sc12_keyhierarchy.py` |
| **SC-28 (Protection of Information at Rest)** | Column-level encryption protects PHI in S6; SSN tokenization vault (P2 §B.3) | Postgres column-encryption (`pgcrypto`) for PHI table; tokenization vault module | OSCAL fragment cites the encryption-at-rest config; `tests/cato/test_sc28_atrest.py` |
| **SI-10 (Information Input Validation)** | Address-withheld status enforced at API boundary; OpenAPI 3.1 contract tests (P2 §B.4, §B.5) | Pydantic v2 validators on every FastAPI endpoint; Schemathesis contract tests in CI | OSCAL fragment cites the contract-test stage of the pipeline; `evidence/si10/schemathesis-report.json` |

### Build-provenance binding (closes P3-R45)

OSCAL artifacts MUST reference the actual running prototype. Each per-build emission embeds:

1. **Build hash** — Git SHA + builder image digest (e.g., from `devsecops-pipeline-generator` job env).
2. **Deployed artifact hash** — container image digest pulled from ECR (production) or local registry (Phase 3 prototype).
3. **Evidence freshness window** — OSCAL artifact MUST be fresher than the latest deploy (validated by `cato-evidence-validator` per its Phase 3 EDIT).
4. **Per-service link** — every `implemented-requirement` cites the service name (S1..S11) and its build-hash so the evaluator can drill from OSCAL → running container.

### CI integration contract

Wire emission into the new `cross-cutting/skills/devsecops-pipeline-generator` skill (NEW, P0): `cato-evidence` is one stage in the pipeline, runs after `deploy`, and writes to `evidence/oscal/<build-sha>/`. The pipeline stage:

1. Invokes `compliance-trestle` with the named-family profile.
2. Calls `scripts/emit_per_family_status.py` (NEW under this skill) which produces per-family `pass`/`fail`/`waived` rows.
3. Hands off to `cross-cutting/skills/cato-evidence-validator` (`--phase3-acceptance` mode) for gating.
4. On pass, archives to a CSAM-format export (CSAM ingestion is a Phase 4+ FAA-side step — Phase 3 emits CSAM-ready artifacts but does not push to CSAM live; documented as DEV-12 in `docs/phase3/skills-gap-matrix.md` §5).

### Phase 3 acceptance signals

- [ ] OSCAL SSP enumerates all 10 named families with at least one `implemented-requirement` per family.
- [ ] Each `implemented-requirement` references a `by-component` whose hash matches the deployed prototype's image digest.
- [ ] `evidence/oscal/<build-sha>/family-status.json` is committed per pipeline run.
- [ ] CSAM-format export passes `scripts/validate_csam_export.py`.
- [ ] No family is silently absent from the SSP (validator EDIT-5 will fail the pipeline if so).

## Handoff Summary
When this skill completes, verify:
1. All OSCAL artifacts (SSP, SAR, POA&M) pass schema validation via `scripts/validate_oscal.py`
2. Inherited controls have `by-component` provider references
3. POA&M items are complete (risk, date, owner, compensating control)
4. T1 apps have safety case cross-references
5. **Phase 3:** All 10 named NIST families emit per-family pass/fail and reference live build/deploy hashes
Then proceed to: gate `G-04b` (for design-phase artifacts) or `G-04c` (for generation-phase artifacts), and `deploy-modernized-app` (P6.1) after certification
