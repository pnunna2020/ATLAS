#!/usr/bin/env python3
"""
OSCAL Schema Validator
Validates generated OSCAL artifacts against 1.1.2 schema.
Usage: python validate_oscal.py <oscal_json_path>
"""
import sys
import json

REQUIRED_SSP_FIELDS = [
    "system-security-plan.uuid",
    "system-security-plan.metadata.oscal-version",
    "system-security-plan.system-characteristics.system-name",
    "system-security-plan.control-implementation.implemented-requirements",
]

def validate(path):
    with open(path) as f:
        doc = json.load(f)
    errors = []
    for field_path in REQUIRED_SSP_FIELDS:
        obj = doc
        for key in field_path.split('.'):
            if isinstance(obj, dict) and key in obj:
                obj = obj[key]
            else:
                errors.append(f"Missing required field: {field_path}")
                break
    # Check OSCAL version
    try:
        ver = doc["system-security-plan"]["metadata"]["oscal-version"]
        if ver != "1.1.2":
            errors.append(f"Wrong OSCAL version: {ver} (expected 1.1.2)")
    except KeyError:
        pass
    # Check for controls without by-components
    try:
        reqs = doc["system-security-plan"]["control-implementation"]["implemented-requirements"]
        for req in reqs:
            for stmt in req.get("statements", []):
                if not stmt.get("by-components"):
                    errors.append(f"Control {req.get('control-id','')} statement missing by-components")
    except (KeyError, TypeError):
        pass
    return {"status": "PASS" if not errors else "FAIL", "errors": errors}

if __name__ == "__main__":
    result = validate(sys.argv[1])
    print(json.dumps(result, indent=2))
