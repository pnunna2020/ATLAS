#!/usr/bin/env python3
"""Merge new control implementations into existing SSP."""
import sys
import json

def merge(base_path, additions_path, output_path):
    with open(base_path) as f:
        base = json.load(f)
    with open(additions_path) as f:
        adds = json.load(f)
    existing = {r["control-id"]: r for r in
        base["system-security-plan"]["control-implementation"]["implemented-requirements"]}
    for req in adds.get("implemented-requirements", []):
        cid = req["control-id"]
        if cid in existing:
            existing[cid]["statements"].extend(req.get("statements", []))
        else:
            existing[cid] = req
    base["system-security-plan"]["control-implementation"]["implemented-requirements"] = list(existing.values())
    with open(output_path, 'w') as f:
        json.dump(base, f, indent=2)
    print(f"Merged {len(adds.get('implemented-requirements',[]))} controls into {output_path}")

if __name__ == "__main__":
    merge(sys.argv[1], sys.argv[2], sys.argv[3])
