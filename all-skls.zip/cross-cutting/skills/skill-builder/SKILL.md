---
name: skill-builder
description: >
  Extract patterns from completed modernization waves and formalize them into new
  or refined SKILL.md files for reuse in subsequent waves. Used during Governance
  line pattern extraction. Triggers on pattern extraction, skill creation, skill
  refinement, or wave retrospective.
agent: opus
allowed-tools:
  - Read
  - Write
  - Bash
  - Grep
---

# Skill Builder

## Purpose
Extract reusable patterns from factory execution data and encode them as new or
refined skills, driving the compound growth model where each wave improves the next.

## Inputs
- Completed modernization artifacts (source code, test suites, specifications)
- Gate pass/fail data (what patterns correlate with first-pass success)
- Ralph Loop metrics (which modules required most iterations, and why)
- Escalation records (why auto-generation failed, what manual fixes were needed)
- Archetype-specific outcomes (what approaches work best for web vs. batch vs. API)

## Outputs
- New SKILL.md files or refinements to existing skills
- Technology-specific or archetype-specific skill variants
- Anti-pattern catalog entries
- Updated skill metadata (enrichment level, usage metrics)

## Methodology
1. **Observe** — Monitor factory execution for successful patterns and failures
2. **Extract** — Formalize observed patterns into reusable templates
3. **Create** — Write new SKILL.md files or refine existing ones
4. **Test** — Validate skill on historical data (does it improve outcomes?)
5. **Publish** — Add to skill registry via `skill-validator` for next wave
6. **Measure** — Track whether new/refined skill improves factory metrics
7. **Refine** — Iterate based on measurement

## Evolution Types
| Type | Trigger | Example |
|------|---------|---------|
| Refinement | Gate failure pattern | Add constraint for null aggregate root handling |
| Anti-pattern | Repeated Ralph Loop failures | Don't generate monolithic services for >5 aggregate BCs |
| Reference enrichment | Successful wave pattern | Add code template to references/ |
| Variant creation | New technology encountered | Create extraction-rust from base extraction |
| Deprecation | Skill superseded | Mark deprecated, point to replacement |

## Gotchas
- **Extracted skills have medium quality**: They need validation via
  `skill-validator` before entering the registry. Don't ship unvalidated skills.
- **Prioritize high-frequency, high-failure skills**: A skill used 100 times
  with 20% gate failure rate has more leverage than a rarely-used skill.
- **Anti-patterns are as valuable as patterns**: Documenting what NOT to do
  prevents repeat failures across waves.

## Quality Rules
- [ ] New or refined skills pass `skill-validator` before entering the registry — no unvalidated skills
- [ ] Patterns are extracted from actual factory execution data (gate results, Ralph Loop metrics, escalation records)
- [ ] Anti-patterns are documented alongside patterns — what NOT to do is as valuable as what to do
- [ ] Skill priority is based on frequency x failure rate — high-frequency, high-failure skills are refined first
- [ ] Every new skill includes: Purpose, Inputs, Outputs, Methodology, Gotchas, Quality Rules, Common Failure Modes, Handoff Summary
- [ ] Deprecated skills point to their replacement and are not removed from the registry until replacement is validated

## Common Failure Modes
| Failure Mode | Symptom | Prevention |
|-------------|---------|------------|
| Unvalidated skill deployed | New skill produces unpredictable outputs; downstream failures in next wave | Always run `skill-validator` before registry entry; no exceptions |
| Low-impact skill prioritized | Rare-use skill refined while high-frequency, high-failure skill stays unchanged | Prioritize by frequency x failure rate metric; track impact on factory-wide gate pass rate |
| Anti-patterns not captured | Same failure pattern recurs across waves because only successes were extracted | Explicitly catalog anti-patterns alongside patterns; mine escalation records for failure patterns |
| Deprecated skill still in use | Old skill not updated in agent manifests; agents load deprecated skill instead of replacement | Update agent manifests when deprecating; validate no references remain |

## Handoff Summary
When this skill completes, verify:
1. New/refined skills pass `skill-validator` checks
2. Anti-pattern catalog is updated with any new failure patterns
3. Agent manifests for the next wave include new skills
4. Factory metrics baseline is updated to measure skill improvement impact
Then proceed to: `skill-validator` for formal validation, then update the skill registry for the next wave
