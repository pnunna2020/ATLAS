---
name: batch-design
description: >
  Design modernized batch processing using AWS Step Functions, EventBridge rules, and Lambda. Use during P4.2 for batch archetype applications. Triggers on batch design, Step Functions, EventBridge scheduling, or batch modernization.
agent: sonnet
allowed-tools:
  - Read
  - Write
  - Bash
  - Grep
---

# Batch Design

## Purpose
Transform legacy cron/scheduler batch jobs into cloud-native event-driven workflows.

## Gotchas
- **Not everything needs Step Functions**: Simple scheduled tasks → EventBridge
  rule + Lambda. Complex multi-step → Step Functions. Don't over-engineer.
- **Preserve execution windows**: If the legacy batch runs at 2am EST because
  that's when NAS traffic is lowest, the modern batch should run at the same
  time for the same reason.
- **Idempotency is non-negotiable**: Modern batch jobs MUST be idempotent
  (safe to re-run). Legacy jobs often aren't. This is a design requirement.

## Quality Rules
- [ ] Each batch job is assigned the appropriate technology: simple scheduled tasks use EventBridge + Lambda; complex multi-step workflows use Step Functions
- [ ] Legacy execution windows are preserved in the modernized schedule (same time, same timezone, same reason)
- [ ] Every modernized batch job is designed to be idempotent — safe to re-run without side effects
- [ ] Error handling, retry strategy, and dead-letter queue configuration are specified for each job
- [ ] Job dependency chains from `batch-extraction` are preserved in Step Functions state machine or EventBridge rule ordering
- [ ] Data volume estimates from legacy batch are used to size Lambda memory/timeout or Fargate resource allocation

## Common Failure Modes
| Failure Mode | Symptom | Prevention |
|-------------|---------|------------|
| Over-engineered simple tasks | Simple nightly file transfer built as a 10-step Step Functions workflow; unnecessary complexity | Evaluate complexity first: simple → EventBridge + Lambda; complex multi-step → Step Functions |
| Execution window shifted | Batch job moved from 2am EST to UTC midnight; conflicts with NAS traffic patterns | Preserve original execution windows with explicit timezone documentation |
| Non-idempotent design | Re-running a failed batch job creates duplicate records or double-processes transactions | Design idempotency into every job; use deduplication keys and upsert patterns |
| Missing retry strategy | Transient failure causes permanent batch job failure; manual intervention required at 2am | Define retry policy with backoff for every job; configure dead-letter queues for persistent failures |

## Handoff Summary
When this skill completes, verify:
1. Technology selection (Step Functions vs EventBridge+Lambda) is justified for each job
2. Execution windows match legacy schedules with timezone documentation
3. Idempotency is designed into every job
4. Error handling and retry strategies are specified
Then proceed to: `batch-generation` (P4.3) for implementation, and gate `G-04b` for design quality review
