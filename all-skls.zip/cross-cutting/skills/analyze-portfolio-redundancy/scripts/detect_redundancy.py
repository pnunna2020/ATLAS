#!/usr/bin/env python3
"""Detect redundancy between applications in the FAA portfolio.

Consumes P0.3 business capability models for every application in scope,
builds a capability x application matrix, and produces pairwise redundancy
scores (0-100%) for every application pair.

Redundancy score combines:
- Capability overlap weight
- User base overlap weight
- Data dependency similarity weight

Outputs a redundancy matrix JSON and a sorted list of consolidation candidates
(apps above a redundancy threshold).
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from typing import Any


# TODO(skill-author): Replace these weight constants with values loaded from
# references/scoring-methodology.md or a profile-specific config file.
DEFAULT_CAPABILITY_WEIGHT = 0.5
DEFAULT_USER_BASE_WEIGHT = 0.3
DEFAULT_DATA_DEPENDENCY_WEIGHT = 0.2
DEFAULT_CONSOLIDATION_THRESHOLD = 60.0


def load_capability_models(directory: Path) -> dict[str, dict[str, Any]]:
    """Load every P0.3 business capability model from `directory`.

    Each file is expected to be a JSON document with at least:
      - app_id: str
      - capabilities: list of {name, depth}
      - user_base: list of role identifiers
      - data_dependencies: list of table/system identifiers
    """
    # TODO(skill-author): Implement real loader. Placeholder returns {}.
    return {}


def compute_pairwise_score(
    app_a: dict[str, Any],
    app_b: dict[str, Any],
) -> float:
    """Compute redundancy score between two applications (0-100)."""
    # TODO(skill-author): Replace stub with real Jaccard / cosine overlap
    # calculation across capabilities, user base, and data dependencies.
    return 0.0


def build_matrix(models: dict[str, dict[str, Any]]) -> list[dict[str, Any]]:
    """Build the sorted list of redundancy pairs above threshold."""
    results: list[dict[str, Any]] = []
    app_ids = sorted(models.keys())
    for i, app_a in enumerate(app_ids):
        for app_b in app_ids[i + 1 :]:
            score = compute_pairwise_score(models[app_a], models[app_b])
            if score >= DEFAULT_CONSOLIDATION_THRESHOLD:
                results.append(
                    {
                        "app_a": app_a,
                        "app_b": app_b,
                        "score": score,
                    }
                )
    results.sort(key=lambda pair: pair["score"], reverse=True)
    return results


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--input-dir",
        type=Path,
        required=True,
        help="Directory containing P0.3 capability model JSON files",
    )
    parser.add_argument(
        "--output",
        type=Path,
        required=True,
        help="Path for the output redundancy matrix JSON",
    )
    args = parser.parse_args(argv)

    models = load_capability_models(args.input_dir)
    if not models:
        print("No capability models found — aborting", file=sys.stderr)
        return 1

    matrix = build_matrix(models)
    args.output.write_text(json.dumps(matrix, indent=2), encoding="utf-8")
    print(f"Wrote {len(matrix)} redundancy candidates to {args.output}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
