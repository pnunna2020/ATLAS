#!/usr/bin/env python3
"""Detect shared-identity keys across one or more application source trees.

Usage:
    python detect_shared_identifiers.py <path1> [<path2> ...] [--max-files N]

For every path given, walks the tree and counts evidence for known identifiers
on three detection channels:

    * column_hits  — schema/migration files (``.sql``, ``.ddl``, ``.dml``)
                     whose ``CREATE TABLE`` / ``ALTER TABLE`` column names match
                     per-identifier column-name patterns
    * regex_hits   — total regex matches in readable text files, capped per file
    * var_hits     — identifiers used as variable or property names in source
                     files (``.cs``, ``.vb``, ``.py``, ``.java``, ``.js``,
                     ``.ts``, ``.rb``)

Per-app confidence is then derived per identifier:
    * column_hits ≥ 1 AND regex_hits ≥ 1 AND var_hits ≥ 1      → high
    * (column_hits ≥ 1 OR var_hits ≥ 1) AND regex_hits ≥ 1     → medium
    * regex_hits ≥ 1 only                                      → low
    * otherwise                                                → none

Cross-app match: an identifier with confidence ≥ low in ≥ 2 apps. The match's
confidence is the minimum of the participating apps' confidences.

Output (stdout, JSON):

    {
      "apps": [
        {
          "path": "<absolute path>",
          "identifiers": {
            "ftn": {
              "column_hits": ["Ftns.FtnNumber", ...],
              "regex_hits": 142,
              "var_hits": ["ftnNumber", "FtnId"],
              "confidence": "high"
            },
            ...
          }
        },
        ...
      ],
      "cross_app_matches": [
        {"identifier": "ftn", "apps": ["iacra-mock", ...], "confidence": "high"}
      ]
    }

Stdlib only. See ``references/shared-identity-patterns.md`` for detection rules.
"""
from __future__ import annotations

import argparse
import json
import re
import sys
from collections import defaultdict
from pathlib import Path
from typing import Iterable

# ── Configuration ─────────────────────────────────────────────────────────

_SKIP_DIRS = frozenset({
    ".git", "node_modules", "bin", "obj", "target", "dist", "build",
    ".venv", "venv", "__pycache__", "packages", ".idea", ".vs",
})

_SCHEMA_EXTS = frozenset({".sql", ".ddl", ".dml"})
_CODE_EXTS = frozenset({
    ".cs", ".vb", ".py", ".java", ".js", ".ts", ".rb", ".php",
    ".cfc", ".cfm", ".go", ".kt", ".scala",
})
_TEXT_EXTS = frozenset({
    ".txt", ".md", ".json", ".yaml", ".yml", ".xml", ".properties",
    ".config", ".ini", ".cfg", ".csv", ".tsv",
}) | _SCHEMA_EXTS | _CODE_EXTS

_DEFAULT_MAX_FILES = 10000
_MAX_FILE_SIZE_BYTES = 1_000_000  # skip files > 1 MB
_MAX_REGEX_HITS_PER_FILE = 100
_MAX_EVIDENCE_PER_IDENTIFIER = 20


# ── Identifier catalog ────────────────────────────────────────────────────
# Each entry: (identifier-key, regex, column-name patterns, var-name patterns)
# Column and variable patterns are normalized lowercase substrings/regexes.

# Columns: parsed from CREATE TABLE column declarations; matched against
# these lowercase substrings (exact match after normalization).
# Variables: matched against lower-cased source text using word-boundary regex.

_IDENTIFIERS: list[dict] = [
    {
        "key": "ftn",
        "regex": re.compile(r"\b[A-Za-z]\d{7}\b"),
        "column_patterns": {
            "ftn", "ftn_number", "ftn_id", "ftn_num", "ftnnumber", "ftnid",
            "tracking_number", "faa_tracking_number", "airman_ftn",
        },
        "var_patterns": (
            re.compile(r"\bftn\b", re.IGNORECASE),
            re.compile(r"\bftnnumber\b", re.IGNORECASE),
            re.compile(r"\bftnid\b", re.IGNORECASE),
            re.compile(r"\bftnnum\b", re.IGNORECASE),
            re.compile(r"\bfaatrackingnumber\b", re.IGNORECASE),
            re.compile(r"\btrackingnumber\b", re.IGNORECASE),
        ),
    },
    {
        "key": "n_number",
        "regex": re.compile(r"\bN\d{1,5}[A-Z]{0,2}\b"),
        "column_patterns": {
            "n_number", "nnumber", "n_num", "nnum", "tail_number",
            "tail_num", "tailnumber", "registration_number",
            "aircraft_id", "aircraft_reg",
        },
        "var_patterns": (
            re.compile(r"\bnnumber\b", re.IGNORECASE),
            re.compile(r"\bn_number\b", re.IGNORECASE),
            re.compile(r"\btailnumber\b", re.IGNORECASE),
            re.compile(r"\bregistrationnumber\b", re.IGNORECASE),
            re.compile(r"\baircraftreg\b", re.IGNORECASE),
        ),
    },
    {
        "key": "airman_cert",
        "regex": re.compile(r"\b(?:cert|airman)[_-]?(?:num|number|no)\b", re.IGNORECASE),
        "column_patterns": {
            "cert_number", "certificate_number", "airman_cert",
            "airman_cert_number", "cert_num", "certnumber", "certnum",
        },
        "var_patterns": (
            re.compile(r"\bcertnumber\b", re.IGNORECASE),
            re.compile(r"\bcertificatenumber\b", re.IGNORECASE),
            re.compile(r"\bairmancertnumber\b", re.IGNORECASE),
            re.compile(r"\bairmancert\b", re.IGNORECASE),
        ),
    },
    {
        "key": "medical_cert",
        "regex": re.compile(r"\bMED[A-Z0-9]{6,10}\b"),
        "column_patterns": {
            "medical_cert", "med_cert", "medical_cert_number",
            "medxpress_id", "medicalcert", "medcert",
        },
        "var_patterns": (
            re.compile(r"\bmedicalcert\b", re.IGNORECASE),
            re.compile(r"\bmedcert\b", re.IGNORECASE),
            re.compile(r"\bmedicalcertnumber\b", re.IGNORECASE),
            re.compile(r"\bmedxpressid\b", re.IGNORECASE),
        ),
    },
    {
        "key": "designee",
        "regex": re.compile(r"\b(?:DER|DMIR|DAR|DPE)[-_]?\d{3,6}\b"),
        "column_patterns": {
            "designee_number", "designee_id", "der_number",
            "dar_number", "dpe_number", "designeenumber", "designeeid",
        },
        "var_patterns": (
            re.compile(r"\bdesigneenumber\b", re.IGNORECASE),
            re.compile(r"\bdesigneeid\b", re.IGNORECASE),
            re.compile(r"\bdernumber\b", re.IGNORECASE),
            re.compile(r"\bdarnumber\b", re.IGNORECASE),
        ),
    },
    {
        "key": "email",
        "regex": re.compile(r"\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}\b"),
        "column_patterns": {
            "email", "email_address", "user_email", "primary_email",
            "contact_email", "emailaddress",
        },
        "var_patterns": (
            re.compile(r"\bemail\b", re.IGNORECASE),
            re.compile(r"\bemailaddress\b", re.IGNORECASE),
            re.compile(r"\buseremail\b", re.IGNORECASE),
        ),
    },
    {
        "key": "employee_id",
        "regex": re.compile(r"\b(?:EMP|USR|EID)\d{4,8}\b"),
        "column_patterns": {
            "employee_id", "emp_id", "user_id", "staff_id",
            "personnel_number", "employeeid", "empid", "userid",
        },
        "var_patterns": (
            re.compile(r"\bemployeeid\b", re.IGNORECASE),
            re.compile(r"\bempid\b", re.IGNORECASE),
            re.compile(r"\bstaffid\b", re.IGNORECASE),
        ),
    },
    {
        "key": "ssn",
        "regex": re.compile(r"\b\d{3}-\d{2}-\d{4}\b"),
        "column_patterns": {"ssn", "social_security_number", "social_security"},
        "var_patterns": (
            re.compile(r"\bssn\b", re.IGNORECASE),
            re.compile(r"\bsocialsecurity\b", re.IGNORECASE),
        ),
    },
]

_IDENTIFIER_KEYS: tuple[str, ...] = tuple(d["key"] for d in _IDENTIFIERS)


# ── Detection helpers ─────────────────────────────────────────────────────


_CREATE_TABLE_RE = re.compile(
    r"CREATE\s+TABLE\s+(?:IF\s+NOT\s+EXISTS\s+)?"
    r"(?:\[?(?P<schema>\w+)\]?\.)?"
    r"\[?(?P<table>\w+)\]?"
    r"\s*\((?P<body>.*?)\)\s*(?:;|$)",
    re.IGNORECASE | re.DOTALL,
)
# Column line inside a CREATE TABLE body: first bracketed or bare identifier.
_COLUMN_LINE_RE = re.compile(
    r"^\s*(?:\[(?P<bracketed>[^\]]+)\]|(?P<bare>[A-Za-z_][A-Za-z0-9_]*))",
)


def _is_skipped_path(path: Path) -> bool:
    return any(part in _SKIP_DIRS for part in path.parts)


def _safe_read_text(path: Path) -> str | None:
    """Read a text file, return None for binary/unreadable/too-large."""
    try:
        if path.stat().st_size > _MAX_FILE_SIZE_BYTES:
            return None
    except OSError:
        return None
    try:
        with path.open("rb") as handle:
            head = handle.read(8192)
            if b"\x00" in head:
                return None
            rest = handle.read()
    except OSError:
        return None
    try:
        return (head + rest).decode("utf-8", errors="replace")
    except UnicodeDecodeError:
        return None


def _extract_columns_from_schema(text: str) -> list[tuple[str, str]]:
    """Return (table_name, column_name) pairs from CREATE TABLE statements."""
    pairs: list[tuple[str, str]] = []
    for match in _CREATE_TABLE_RE.finditer(text):
        table = match.group("table") or ""
        body = match.group("body") or ""
        # Split on commas at the top level — naive but works for most DDL.
        # Filter out CONSTRAINT / PRIMARY KEY / FOREIGN KEY / CHECK lines.
        for raw_line in body.split(","):
            line = raw_line.strip()
            if not line:
                continue
            lower = line.lower()
            if lower.startswith(("constraint", "primary key", "foreign key",
                                 "check", "unique", "key ", "index ")):
                continue
            col_match = _COLUMN_LINE_RE.match(line)
            if not col_match:
                continue
            col = col_match.group("bracketed") or col_match.group("bare") or ""
            if col:
                pairs.append((table, col))
    return pairs


def _normalize_column(col: str) -> str:
    return col.strip().lower().replace("-", "_")


def _count_regex(text: str, pattern: re.Pattern) -> int:
    count = 0
    for _ in pattern.finditer(text):
        count += 1
        if count >= _MAX_REGEX_HITS_PER_FILE:
            break
    return count


def _find_var_hits(text: str, patterns: Iterable[re.Pattern]) -> set[str]:
    """Return the set of distinct variable-name matches across patterns."""
    hits: set[str] = set()
    for pattern in patterns:
        for m in pattern.finditer(text):
            hits.add(m.group(0))
    return hits


# ── Per-app scan ──────────────────────────────────────────────────────────


def _empty_identifier_record() -> dict:
    return {
        "column_hits": [],
        "regex_hits": 0,
        "var_hits": [],
        "confidence": "none",
    }


def scan_app(app_path: Path, max_files: int) -> dict:
    """Walk one app and collect identifier evidence. Returns the per-app record."""
    # Per-identifier accumulators.
    column_hits: dict[str, list[str]] = defaultdict(list)
    regex_hits: dict[str, int] = defaultdict(int)
    var_hits: dict[str, set[str]] = defaultdict(set)

    total_files = 0
    for path in sorted(app_path.rglob("*")):
        if path.is_dir():
            continue
        if _is_skipped_path(path):
            continue
        suffix = path.suffix.lower()
        if suffix not in _TEXT_EXTS:
            continue
        total_files += 1
        if total_files > max_files:
            break

        text = _safe_read_text(path)
        if text is None:
            continue
        rel = str(path.relative_to(app_path)).replace("\\", "/")

        # Schema columns
        if suffix in _SCHEMA_EXTS:
            for table, col in _extract_columns_from_schema(text):
                norm = _normalize_column(col)
                for ident in _IDENTIFIERS:
                    if norm in ident["column_patterns"]:
                        key = ident["key"]
                        evidence = f"{table}.{col}" if table else col
                        if evidence not in column_hits[key] and \
                                len(column_hits[key]) < _MAX_EVIDENCE_PER_IDENTIFIER:
                            column_hits[key].append(evidence)

        # Regex matches in every text file (schemas included)
        for ident in _IDENTIFIERS:
            key = ident["key"]
            regex_hits[key] += _count_regex(text, ident["regex"])

        # Variable-name hits only in code files (avoid schema false positives)
        if suffix in _CODE_EXTS:
            for ident in _IDENTIFIERS:
                key = ident["key"]
                found = _find_var_hits(text, ident["var_patterns"])
                for hit in found:
                    if len(var_hits[key]) < _MAX_EVIDENCE_PER_IDENTIFIER:
                        var_hits[key].add(hit)

    identifiers: dict[str, dict] = {}
    for key in _IDENTIFIER_KEYS:
        record = _empty_identifier_record()
        record["column_hits"] = sorted(column_hits.get(key, []))
        record["regex_hits"] = int(regex_hits.get(key, 0))
        record["var_hits"] = sorted(var_hits.get(key, set()))
        record["confidence"] = _classify_confidence(record)
        identifiers[key] = record

    return {
        "path": str(app_path),
        "identifiers": identifiers,
        "total_files_scanned": min(total_files, max_files),
    }


def _classify_confidence(record: dict) -> str:
    col = len(record["column_hits"])
    reg = int(record["regex_hits"])
    var = len(record["var_hits"])
    # Three channels firing is the strongest in-static-analysis signal.
    if col >= 1 and reg >= 1 and var >= 1:
        return "high"
    # A schema or variable hit plus regex corroboration is medium.
    if (col >= 1 or var >= 1) and reg >= 1:
        return "medium"
    # A schema or variable hit alone (no regex value in corpus) still
    # implies the column/field is declared — flag as medium for review.
    if col >= 1 or var >= 1:
        return "medium"
    # Regex-only is the weakest signal; shape without corroboration.
    if reg >= 1:
        return "low"
    return "none"


# ── Cross-app match ───────────────────────────────────────────────────────


_CONFIDENCE_ORDER: dict[str, int] = {"none": 0, "low": 1, "medium": 2, "high": 3}


def cross_app_matches(apps: list[dict]) -> list[dict]:
    """Find identifiers present at ≥low confidence in ≥2 apps."""
    matches: list[dict] = []
    for key in _IDENTIFIER_KEYS:
        participating: list[tuple[str, str]] = []  # (app label, confidence)
        for app in apps:
            record = app["identifiers"][key]
            conf = record["confidence"]
            if _CONFIDENCE_ORDER[conf] >= _CONFIDENCE_ORDER["low"]:
                participating.append((_app_label(app), conf))
        if len(participating) < 2:
            continue
        min_conf_idx = min(_CONFIDENCE_ORDER[c] for _, c in participating)
        min_conf = next(
            name for name, idx in _CONFIDENCE_ORDER.items() if idx == min_conf_idx
        )
        matches.append({
            "identifier": key,
            "apps": sorted(label for label, _ in participating),
            "confidence": min_conf,
        })
    # Sort: high → medium → low, then alphabetical by identifier
    matches.sort(
        key=lambda m: (-_CONFIDENCE_ORDER[m["confidence"]], m["identifier"])
    )
    return matches


def _app_label(app: dict) -> str:
    """Label an app by the final path segment (or the full path as fallback)."""
    path = Path(app["path"])
    return path.name or str(path)


# ── CLI ───────────────────────────────────────────────────────────────────


def _parse_args(argv: list[str]) -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description=(
            "Detect shared-identity keys across one or more application source "
            "trees. See references/shared-identity-patterns.md for rules."
        ),
    )
    parser.add_argument(
        "paths",
        nargs="+",
        type=Path,
        help="One or more application source directories",
    )
    parser.add_argument(
        "--max-files",
        type=int,
        default=_DEFAULT_MAX_FILES,
        help=f"Cap files scanned per app (default: {_DEFAULT_MAX_FILES})",
    )
    return parser.parse_args(argv)


def main(argv: list[str] | None = None) -> int:
    args = _parse_args(argv or sys.argv[1:])
    max_files = max(1, args.max_files)

    apps: list[dict] = []
    for raw in args.paths:
        root = raw.resolve()
        if not root.exists() or not root.is_dir():
            print(
                json.dumps({"error": f"not a directory: {root}"}),
                file=sys.stderr,
            )
            return 2
        apps.append(scan_app(root, max_files=max_files))

    output = {
        "apps": apps,
        "cross_app_matches": cross_app_matches(apps),
    }
    print(json.dumps(output, indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
