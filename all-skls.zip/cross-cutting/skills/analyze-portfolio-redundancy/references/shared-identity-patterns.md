# Shared Identity Patterns — Cross-App Key Detection

## Purpose

This reference equips the `analyze-portfolio-redundancy` skill to detect **shared-identity keys** — the signal that two or more applications store, reference, or transport the *same* user/entity identity even when the applications do not share a database. Shared identity is the single most actionable cross-app signal for Rationalization: it tells us two apps can be consolidated, co-located, or joined through a canonical identity service.

Scope: greppable, deterministic heuristics for schema files, code, and sample data. No AST, no ML, no cross-process joins. Output feeds the portfolio redundancy matrix and disposition scoring.

Provenance: derives from ATLAS-CHALLENGE corpus findings where FAA Tracking Number (FTN) `A1234567` appears across iacra-mock, rms-mock, and dms-mock as the common airman identifier. See `docs/atlas-challenge-discovery-rationalization-gap-analysis.md` §3.3 "Cross-App / Portfolio Gaps" for the gap driving this reference.

---

## 1. Detection Signals

Three independent detection channels. Every channel that fires raises confidence; channels are complementary, not redundant.

### 1.1 Schema signals (column names in SQL)

Scan `.sql`, `.ddl`, `.dml`, Flyway/Liquibase migrations, Rails `schema.rb`, EF Core `Migrations/*.cs`, and similar declarative schemas for `CREATE TABLE`, `ALTER TABLE`, and `ADD COLUMN`. Capture column names, normalize to lowercase with underscores, match against the known-identifier catalog (section 3). Schema hits are the strongest single signal because they imply persistent storage.

### 1.2 Regex signals (value shape in text)

Run an identifier-shaped regex across text files (source, docs, configs, fixtures). Count matches per app. Cap per-file matches at 100 to avoid pathological files (log dumps, test fixtures). Regex alone is weak — many unrelated strings share a shape — but combined with schema or variable-name hits it reinforces confidence.

### 1.3 Code signals (variable / property / parameter names)

Scan source files for identifier variable names. Recognize common case conventions: `snake_case`, `camelCase`, `PascalCase`, `SCREAMING_SNAKE`. For C# and Java also match property declarations (`public string FtnNumber { get; set; }`). Variable-name hits prove the identifier is part of app logic — not a one-off string in a comment.

---

## 2. Detection Scope

What to scan, what to skip.

**Include:**
- Schema and migration files: `*.sql`, `*.ddl`, `*.dml`, `schema.rb`, EF migration classes
- Source files: `.cs`, `.vb`, `.py`, `.java`, `.js`, `.ts`, `.rb`, `.php`, `.cfc`, `.cfm`, `.nsp`, `.nsn`, `.cbl`
- Config files: `.json`, `.yaml`, `.yml`, `.xml`, `.properties`, `.config`
- Docs: `.md`, `.txt` (counts toward regex hits only)

**Skip:**
- Binary files (heuristic: null-byte in first 8 KB)
- Vendor / build dirs: `node_modules`, `.git`, `bin`, `obj`, `target`, `dist`, `build`, `.venv`, `venv`, `__pycache__`, `packages`
- Large fixture dumps (cap file scan at 1 MB)
- TIFF/PDF/image/media assets

**Caps:**
- Max files scanned per app: 10000 (configurable)
- Max regex matches per file: 100
- Max evidence-path samples per identifier: 20

---

## 3. Per-Identifier Profile Catalog

Each profile names the identifier, the recognition regex, typical column-name patterns, typical variable-name patterns, and privacy classification. Regex patterns are Python-flavored, anchored by `\b` word boundaries so they survive when embedded in prose.

### 3.1 FTN — FAA Tracking Number

- **Regex:** `\b[A-Z]\d{7}\b` (one letter + 7 digits — case-insensitive match permitted, normalize to uppercase)
- **Column names:** `ftn`, `ftn_number`, `ftn_id`, `ftn_num`, `tracking_number`, `faa_tracking_number`, `airman_ftn`
- **Variable names:** `ftn`, `ftnNumber`, `FtnNumber`, `FtnId`, `FtnNum`, `faaTrackingNumber`, `trackingNumber`
- **Privacy:** PII (restricted — links directly to an airman)
- **Notes:** Historically tied to an SSN seed (pre-2018 airmen) but FAA now issues synthetic FTNs. Treat as pseudo-SSN — cross-app join is valid and actionable.
- **Example apps in ATLAS corpus:** iacra-mock (Applicants.FtnNumber), rms-mock (CAIS AA-BASIC AAB-FTN), dms-mock (IacraClient.GetApplicantByFtn)

### 3.2 N-Number — Aircraft tail number

- **Regex:** `\bN\d{1,5}[A-Z]{0,2}\b` (N + 1-5 digits + optional 1-2 letter suffix; FAA allocation rules cap at 6 chars)
- **Column names:** `n_number`, `nnumber`, `n_num`, `tail_number`, `tail_num`, `registration_number`, `aircraft_id`
- **Variable names:** `nNumber`, `NNumber`, `tailNumber`, `registrationNumber`, `aircraftReg`
- **Privacy:** Public (FAA Aircraft Registry is publicly queryable)
- **Notes:** Shares shape with some ham-radio callsigns and abbreviations — require column or variable corroboration before claiming a join. N-number is unique globally but ownership changes over time.
- **Example apps:** rms-mock aircraft-reg subsystem; any FAA system touching aircraft identity

### 3.3 Airman Certificate Number

- **Regex:** `\b[A-Z]?\d{7,10}\b` (loose — airman cert numbers overlap with FTN shape pre-2000; more specific corroboration needed)
- **Column names:** `cert_number`, `certificate_number`, `airman_cert`, `airman_cert_number`, `cert_num`
- **Variable names:** `certNumber`, `CertNumber`, `certificateNumber`, `airmanCertNumber`
- **Privacy:** PII
- **Notes:** Structurally overlaps with FTN for legacy airmen. Use column/variable name to disambiguate.

### 3.4 Airman Medical Certificate

- **Regex:** `\bMED[A-Z0-9]{6,10}\b` (FAA medical-cert numbers; format varies by class)
- **Column names:** `medical_cert`, `med_cert`, `medical_cert_number`, `medxpress_id`
- **Variable names:** `medicalCert`, `medCert`, `medicalCertNumber`
- **Privacy:** PII + HIPAA-sensitive
- **Example apps:** medxpress-mock

### 3.5 Designee Number (14 CFR Part 183)

- **Regex:** `\b(DER|DMIR|DAR|DPE)[-_]?\d{3,6}\b` (designee-type prefix + number)
- **Column names:** `designee_number`, `designee_id`, `der_number`, `dar_number`, `dpe_number`
- **Variable names:** `designeeNumber`, `designeeId`, `derNumber`
- **Privacy:** Semi-public (designee rolls are published; name linkage is PII)

### 3.6 Aircraft Serial Number

- **Regex:** `\b[A-Z0-9]{3,15}\b` — too loose; always requires column corroboration
- **Column names:** `serial_number`, `aircraft_serial`, `airframe_serial`, `sn`
- **Variable names:** `serialNumber`, `aircraftSerial`, `airframeSerial`
- **Privacy:** Public (FAA Registry)

### 3.7 Type Certificate

- **Regex:** `\b[A-Z0-9]{3,8}[A-Z]{2}\b` (e.g., `A1SW`, `1A4`) — shape only; column corroboration required
- **Column names:** `type_cert`, `type_certificate`, `tcds`, `tc_number`
- **Variable names:** `typeCert`, `typeCertificate`, `tcNumber`
- **Privacy:** Public

### 3.8 Generic — Email address

- **Regex:** `\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}\b`
- **Column names:** `email`, `email_address`, `user_email`, `primary_email`, `contact_email`
- **Variable names:** `email`, `emailAddress`, `userEmail`
- **Privacy:** PII
- **Notes:** Ubiquitous. Use *email domain* (the RHS of `@`) as the join — shared domain across apps is the portfolio signal, not shared email. A multi-app SSO platform typically shows `faa.gov` in every app.

### 3.9 Generic — Employee ID / user ID

- **Regex:** `\b(EMP|USR|EID)\d{4,8}\b` (enterprise-style prefixed IDs)
- **Column names:** `employee_id`, `emp_id`, `user_id`, `staff_id`, `personnel_number`
- **Variable names:** `employeeId`, `empId`, `userId`, `staffId`
- **Privacy:** Internal (semi-PII)

### 3.10 Generic — SSN (anti-pattern; see section 6)

- **Regex:** `\b\d{3}-\d{2}-\d{4}\b`
- **Privacy:** PII + regulated (PCI/GDPR/PII)
- **Notes:** Flag as a **privacy finding**, not a join opportunity.

---

## 4. Cross-App Join Signals

A cross-app join exists when two or more apps each contain hits for the **same identifier** on at least one detection channel. Strength depends on which channels fire and whether they agree:

- **App A, schema hit (column `ftn_number`)** + **App B, schema hit (column `FtnId`)** + **regex present in both** → high-confidence join on FTN
- **App A, schema only** + **App B, variable name only** → medium-confidence join (likely join key but one side may be transport-only)
- **App A, regex only** + **App B, regex only** → low-confidence join; the shape is common, the signal is weak
- **App A, schema + sample data values match app B's regex hits** → highest-confidence join; human-reviewable

The redundancy matrix carries the join candidate as a structured recommendation:
> "Apps iacra-mock, rms-mock, dms-mock share identifier FTN with high confidence (schema + variable + regex in all three). Recommend consolidation evaluation via canonical airman-identity service (Rationalization Step 3)."

Human review is **always** required before a consolidation recommendation is issued. The heuristic is a filter, not an oracle.

---

## 5. Confidence Tiers

| Tier | Criteria | Use |
|---|---|---|
| **highest** | Schema hit + regex hit in actual data rows (sample values match identifier regex) | Act on immediately |
| **high** | Schema hit in app A + Schema or Variable hit in app B (both with regex corroboration) | Recommend for Rationalization |
| **medium** | Variable hit in app A + Variable hit in app B (regex corroboration on at least one side) | Flag for human review |
| **low** | Regex hit only in both apps — no schema, no variable names | Information only; do not recommend |
| **none** | No shared channel, or only privacy-regulated identifiers (SSN, full email) | Report privacy concern; do not join |

Scoring rule inside `detect_shared_identifiers.py`:
- column_hits ≥ 1 AND regex_hits ≥ 1 AND (var_hits ≥ 1 OR column name matches known catalog): **high**
- column_hits ≥ 1 OR var_hits ≥ 1 (with regex corroboration): **medium**
- regex_hits ≥ 1 only: **low**
- Cross-app match takes the minimum confidence across participating apps.

---

## 6. Anti-Patterns

Things to reject, warn on, or refuse.

1. **Joining on SSN across systems** — raises privacy-regulation scope (GDPR, PII). Report SSN hits as a **privacy finding**, never as a join recommendation. The right fix is a canonical identity service, not cross-database SSN joins.
2. **Assuming format implies identity** — N-number matches registration shape, but an N-number in app A and an N-number in app B may refer to two different aircraft at two different points in time. A join on N-number is a join on "aircraft-at-time-T" not "same aircraft today."
3. **Collapsing shape-equivalent identifiers** — FTN `A1234567` and an Airman Cert `A1234567` share shape but have different semantics. Require column or variable disambiguation before claiming equivalence.
4. **Email-address join across personal + corporate** — emails change when people leave jobs. The *domain* is the portfolio signal; the local part is not reliable.
5. **Regex-only joins on short identifiers** — a 5-character alphanumeric ID has many false-positive matches. Require corroboration.
6. **Case-sensitive comparisons** — FAA identifiers are case-insensitive. Always normalize to uppercase before comparison.
7. **Counting comment mentions as evidence** — stripping comments is expensive; instead, require at least one non-regex channel (schema or variable) before claiming medium confidence.

---

## 7. FAA-Specific Identifier Summary

| Identifier | Regex | Typical Columns | Privacy |
|---|---|---|---|
| FTN | `[A-Z]\d{7}` | `ftn`, `ftn_number`, `ftn_id` | PII |
| N-Number | `N\d{1,5}[A-Z]{0,2}` | `n_number`, `tail_number` | Public |
| Airman Cert | `[A-Z]?\d{7,10}` | `cert_number`, `airman_cert` | PII |
| Medical Cert | `MED[A-Z0-9]{6,10}` | `medical_cert`, `med_cert` | PII + HIPAA |
| Designee | `(DER\|DMIR\|DAR\|DPE)[-_]?\d{3,6}` | `designee_number`, `der_number` | Semi-public |
| Aircraft Serial | too loose | `serial_number`, `aircraft_serial` | Public |
| Type Cert | too loose | `type_cert`, `tcds` | Public |
| Email | `...@...` | `email`, `email_address` | PII |
| Employee ID | `(EMP\|USR\|EID)\d{4,8}` | `employee_id`, `emp_id` | Internal |
| SSN | `\d{3}-\d{2}-\d{4}` | (privacy finding only) | PII |

See per-identifier profiles above for variable-name patterns and caveats.

---

## 8. Findings Checklist

The skill must emit at least the following findings (when present):

- [ ] Per-app identifier inventory — for each app, list every identifier with ≥1 hit and its confidence tier
- [ ] Cross-app high-confidence matches — list of identifiers shared across ≥2 apps at high confidence
- [ ] Cross-app medium-confidence matches — same, at medium confidence, flagged for human review
- [ ] Privacy findings — any app with SSN-shape hits, regardless of join potential
- [ ] PII scope summary — for each high/medium match, classify whether it crosses privacy boundaries (PII crossing between systems with different auth boundaries is a data-sharing event)
- [ ] Consolidation-evaluation recommendation — for each high-confidence match, recommend a canonical identity service
- [ ] Orphaned identifiers — identifiers present in exactly one app (no join potential; informational)
- [ ] Evidence trail — for every match, include at least 3 source citations using `{repo}:{file}:{line}` format
- [ ] Anti-pattern warnings — if any match fails a section-6 rule, call it out explicitly
- [ ] Confidence-tier summary — count of matches per tier, so reviewers can gauge scope

Each finding must carry a traceability citation back to the detection artifact so a downstream reviewer can verify.

---

## 9. Integration Notes

- **Feeds:** `cross-cutting/skills/analyze-portfolio-redundancy/scripts/detect_shared_identifiers.py`
- **Consumed by:** `disposition-recommender` (Rationalization Step 3) — shared-identity matches raise the redundancy score and flag consolidation candidates
- **Companion skill:** `portfolio-integration-mapper` — shared identity at the data layer, integration-mapper at the transport layer. They complement each other; neither replaces the other.
- **Human review gate:** G-RR (Rationalization Recommendation). Every high-confidence consolidation recommendation from shared-identity detection lands in the G-RR review packet.
