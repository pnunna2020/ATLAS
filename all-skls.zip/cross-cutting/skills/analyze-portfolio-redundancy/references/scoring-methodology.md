# Portfolio Redundancy Scoring Methodology

## Scoring Dimensions (total: 100 points)
1. **Business Capability Overlap** (40 points)
   - Identical capabilities: 40
   - Similar capabilities (80%+ overlap): 30
   - Partial overlap (50-79%): 20
   - Minimal overlap (<50%): 0

2. **Data Domain Overlap** (25 points)
   - Same data domain and entities: 25
   - Same domain, different entities: 15
   - Related domains: 5
   - Unrelated: 0

3. **User Base Overlap** (20 points)
   - Same users: 20
   - Overlapping user groups: 10
   - Different users: 0

4. **Integration Overlap** (15 points)
   - Same downstream consumers: 15
   - Overlapping consumers: 8
   - Different consumers: 0

## Disposition Thresholds
- Score ≥ 80: Strong consolidation candidate
- Score 50-79: Evaluate for consolidation
- Score 20-49: Retain separately, share components
- Score < 20: No redundancy concern
