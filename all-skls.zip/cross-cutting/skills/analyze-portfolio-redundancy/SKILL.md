---
name: analyze-portfolio-redundancy
description: >
  Detect duplicated business rules, redundant data structures, overlapping
  functionality, and shared-identity keys across the FAA application
  portfolio. Use during P1.1 for portfolio scoring and rationalization.
  Triggers on portfolio redundancy, duplicate detection, redundancy matrix,
  cross-app identity detection, shared identity, or
  @analyze-portfolio-redundancy.
disable-model-invocation: true
agent: opus
---

# Portfolio Redundancy Analysis

## Purpose
Identify which of the ~200 FAA apps duplicate each other's functionality,
enabling consolidation decisions that reduce the portfolio footprint.

## Workflow
1. Load all P0.3 analysis reports (business capability models)
2. Build capability × application matrix
3. Run `scripts/detect_redundancy.py` to find overlapping capabilities
4. Score each app pair for redundancy (0-100%)
5. Generate redundancy matrix and consolidation recommendations
6. Feed results to P1.1 disposition scoring

## Gotchas
- **Same capability ≠ same implementation**: Two apps may both "manage flight
  schedules" but serve different user communities. Redundancy requires same
  CAPABILITY + same USER BASE to recommend consolidation.
- **Data dependencies prevent simple consolidation**: Even if App A and App B
  do the same thing, if they feed different downstream systems, consolidation
  requires re-routing those downstream integrations.
- **This is portfolio-scale, not per-app**: Use Batch API to process all ~200
  apps simultaneously. Per-app sequential analysis will take too long.

## Reference Files
- `references/scoring-methodology.md` — Redundancy scoring weights and criteria
- `references/shared-identity-patterns.md` — Detection rules for cross-app identity keys (FTN, N-number, airman cert, etc.) with regex, column, and variable-name patterns

## Shared-Identity Detection
Cross-app identity detection is the portfolio-scale signal that two or more
apps operate on the *same* user/entity identity even when they have no shared
database. In the ATLAS corpus this shows up as FAA Tracking Number (FTN,
format `A1234567`) appearing across iacra-mock, rms-mock, and dms-mock.

- Read `references/shared-identity-patterns.md` for detection signals,
  per-identifier profiles, confidence tiers, and anti-patterns (e.g., never
  recommend an SSN-based cross-system join).
- Run `scripts/detect_shared_identifiers.py <app-path> [<app-path> ...]`
  across all apps in scope. Output is a per-app identifier inventory plus a
  cross-app match list with confidence tiers (low / medium / high).
- Feed high-confidence cross-app matches into the redundancy matrix as
  consolidation candidates; feed medium matches into the Rationalization
  human-review packet; treat low matches as informational only.

## Quality Rules
- [ ] Redundancy matrix covers all ~200 FAA apps — no applications excluded from comparison
- [ ] Redundancy scores distinguish between same capability + same user base (true redundancy) and same capability + different user base (not redundant)
- [ ] Consolidation recommendations identify both source and target apps and verify both are in scope
- [ ] Data dependencies are documented for each consolidation candidate — downstream integration re-routing is assessed
- [ ] Portfolio-scale analysis uses Batch API for efficiency — sequential per-app analysis is not used for the full portfolio
- [ ] Scoring weights reference `references/scoring-methodology.md` — no ad-hoc weight assignments

## Common Failure Modes
| Failure Mode | Symptom | Prevention |
|-------------|---------|------------|
| Capability match without user base match | Two apps flagged as redundant but serve completely different user communities; false consolidation | Require both capability overlap AND user base overlap for redundancy classification |
| Data dependency ignored | Consolidation recommended but downstream systems depend on specific data formats from both apps | Map downstream integrations for every consolidation candidate; assess re-routing feasibility |
| Sequential processing bottleneck | Portfolio analysis takes days because apps are processed one at a time | Use Batch API for parallel processing of all ~200 apps simultaneously |
| Stale analysis reports | Redundancy matrix built from outdated P0.3 analysis; recent changes not reflected | Verify analysis report freshness; flag reports older than 90 days for refresh |

## Handoff Summary
When this skill completes, verify:
1. Redundancy matrix covers the complete portfolio with no gaps
2. High-overlap pairs (>60%) are flagged for consolidation evaluation
3. Data dependencies are documented for all consolidation candidates
Then proceed to: `disposition-recommender` (Rationalization Step 3) where the redundancy matrix feeds consolidation decisions
