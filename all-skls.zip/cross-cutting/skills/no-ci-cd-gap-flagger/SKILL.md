---
name: no-ci-cd-gap-flagger
description: >
  Detect repositories that ship without a CI/CD pipeline definition —
  no `Jenkinsfile`, no GitHub Actions, no GitLab CI, no Azure
  Pipelines, no CircleCI config. In a legacy portfolio where sibling
  repos DO ship Jenkinsfiles, a missing CI/CD definition is a
  modernization-readiness gap: deploys are manual, undocumented, and
  tribal. CHAPS is the ATLAS case — unique among 8 real repos in
  shipping no Jenkinsfile. Runs as Discovery conditional when the
  repo has no recognizable CI/CD definition file. Triggers on
  CI/CD inventory or @no-ci-cd-gap-flagger.
agent: sonnet
allowed-tools:
  - Read
  - Write
  - Grep
  - Glob
validation_commands:
  - "python -m olympus.validators.schema_validator no-ci-cd-findings.json"
supported_stacks:
  - any
anti_target_stacks:
  - ci-configured
  - static-site-with-gh-pages
failure_classes:
  - shared-pipeline-in-parent-repo-missed
  - deploy-script-mistaken-for-pipeline
  - portfolio-level-pipeline-ignored
benchmark_tags:
  - discovery-cicd
  - no-ci-gap
  - deployment-readiness
---

# no-ci-cd-gap-flagger

## Purpose
Surface repos without a CI/CD definition so modernization plans
include establishing one.

## Inputs
- Repository tree.
- Optional: sibling repos' CI/CD patterns for comparison.

## Outputs
- `no-ci-cd-findings.json` — `{repo, has_jenkinsfile,
  has_github_actions, has_gitlab_ci, has_azure_pipelines,
  has_circleci, has_any_ci_cd, manual_deploy_indicators[]}`.

## Methodology
1. Check for: `Jenkinsfile*` at any depth, `.github/workflows/*.yml`,
   `.gitlab-ci.yml`, `azure-pipelines.yml`, `.circleci/config.yml`,
   `.drone.yml`, `buildspec.yml`, `cloudbuild.yaml`.
2. If none found, emit finding.
3. Detect manual-deploy indicators: `DEPLOY.md`,
   `INSTALL.md` with manual steps, root `build.ps1` / `deploy.sh`
   without pipeline wrapper, README "Building" section with
   CLI-only instructions.

## Tech-Stack Dispatch

No external references.

## Gotchas
- Shared pipeline repos exist: an org-level Jenkins shared library
  might define the pipeline elsewhere. Emit
  `external-pipeline-suspected`; don't auto-mark absolute.
- `deploy.sh` / `deploy.ps1` in repo root is a manual-deploy script,
  NOT a pipeline.
- Portfolio-level pipelines (one Jenkinsfile covering multiple
  repos) may exist in a sibling ops repo.

## Quality Rules
- [ ] Every CI/CD file type checked.
- [ ] Manual-deploy indicators enumerated.
- [ ] Every finding cites `{repo}:{file}:{line}`.

## Common Failure Modes

| Failure Mode | Symptom | Prevention |
|---|---|---|
| Shared pipeline missed | Repo flagged no-CI when ops repo has Jenkinsfile | Emit `external-pipeline-suspected` rather than absolute |
| Deploy script mistaken for pipeline | Finding says has-CI when only deploy.sh exists | Distinguish pipeline config from deploy scripts |

## Handoff Summary
Findings emitted. Proceed to `migration-strategy-advisor` and
`jenkinsfile-pipeline-extractor`.

## References
None.

## Changelog
- 0.1.0 (2026-05-07) — Initial skill. Authored as ATLAS-R-19.
