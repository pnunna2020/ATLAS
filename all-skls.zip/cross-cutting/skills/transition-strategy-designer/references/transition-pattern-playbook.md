# Transition Pattern Playbook

Per-pattern playbook for the eight transition mechanics consumed by
`transition-strategy-designer`. Each entry covers when to use, when to
avoid, entry criteria, exit criteria, rollback mechanics, and a sample
runbook structure. Worked FAA examples appear inline where the pattern
has a concrete application in the 8-app portfolio.

Use this playbook when populating `transition_patterns[]` rows in
`transition-strategy.json`. Citations back to this file belong in the
`entry_criteria` prose when a pattern-specific condition is load-bearing.

---

## 1. Strangler-fig

**Intent.** Replace a legacy system incrementally by routing a
capability-by-capability subset of traffic to the new system while the
legacy continues to handle the rest. The new system grows, the legacy
shrinks, until the legacy is empty and can be retired.

**When to use.** The legacy system is externally addressable (has an
HTTP entry point, a queue, or a database the new system can proxy or
shadow). Capabilities are independent enough to be extracted one at a
time. The transition is expected to run over weeks or months, not
hours.

**When to avoid.** The legacy system cannot be fronted by a router or
gateway. The capabilities are so tightly coupled that extracting one
requires rewriting five. The transition must be fast (hours) rather
than incremental (weeks).

**Entry criteria.**
- Router or gateway is in place between the caller and the legacy
  (API Gateway, ALB with path-based routing, or feature-flag-backed
  SDK).
- First capability to be extracted is named and its target
  implementation exists in the target architecture.
- Legacy remains addressable for the duration; legacy retirement is
  a separate event that follows 100% fig completion.

**Exit criteria.**
- 100% of capabilities are routed to the target.
- Legacy receives no production traffic for ≥ N business days
  (recommended ≥ 14).
- Decommission checklist is signed off.

**Rollback mechanics.** Per capability: flip the router rule back to
the legacy path; drain in-flight requests to the target; replay the
CDC tail to the legacy data store; verify parity; mark the
capability as rolled back in the runbook.

**Sample runbook structure.** Pre-flight → pick the capability →
route 1% traffic → monitor for N hours → escalate to 10%, 50%, 100% →
verify parity → mark cut → repeat for next capability.

**FAA example.** IACRA Rearchitect uses strangler-fig around WebForms,
one form family per sprint. The API Gateway routes AFS-760 Section A
to the target starting in week 4, Section B in week 6, and so on;
the legacy IACRA continues to handle the remaining sections until
every form family is routed to the target. Legacy retirement follows
full fig completion.

---

## 2. Parallel-run

**Intent.** Run the legacy and target systems side by side against the
same inputs; compare outputs; cut over only when parity is verified.

**When to use.** Regulatory byte-preservation applies (14 CFR Part 67
medical letter wording must be preserved bit-for-bit through the
transition). The target output must be verified against the legacy
output before the target becomes authoritative. RTO tolerance requires
the legacy path to remain available through verification.

**When to avoid.** The workload is write-heavy to external systems
where duplicate writes are not idempotent. Infrastructure cost doubling
is not budgeted.

**Entry criteria.**
- Both systems receive the same inputs (production-traffic capture or
  active dual-dispatch).
- Output-comparison harness exists and is backed by a schema-validated
  parity report.
- Cost envelope in `target-architecture.json` accommodates the
  doubled infrastructure.

**Exit criteria.**
- Parity report shows ≥ 99.9% output-match across a statistically
  valid sample size (per pattern agreement with FAA authority).
- For byte-preservation: letter-text parity is byte-for-byte across
  all template types, not a sample.
- Legacy is drained; target becomes authoritative.

**Rollback mechanics.** Because the legacy is still running, rollback
is "stop routing to target; resume legacy-only". Rollback is the
cheapest of any pattern here, which is why parallel-run is the
pattern of choice for byte-preservation workloads.

**Sample runbook structure.** Pre-flight → enable dual-dispatch →
capture N samples → generate parity report → present to authority →
authorization to cutover → flip authoritative → drain legacy.

**FAA example.** MSS Regulatory Letter Generation. Every Part 67
medical denial, special-issuance authorization, and drug-case letter
runs through both AMCS and the target letter-generation service for
the duration of the parallel window. Letter-text parity is verified
byte-for-byte before the target becomes authoritative. The parallel
window is expected to run at least 90 days.

---

## 3. Big-bang cutover

**Intent.** Cut over all users from legacy to target in a single
planned maintenance window. Legacy is unavailable during the
cutover; target becomes authoritative at the end.

**When to use.** Tier-1 legal-record apps where an incremental
transition would split the authoritative record across two systems
(creating a correctness risk worse than a scheduled outage). The FAA
has published a maintenance window that accommodates the cutover.
Rollback can be executed within the same window.

**When to avoid.** Any pattern that can avoid a full outage should
avoid big-bang. RTO tolerance cannot accommodate a multi-hour cutover
window. Rollback time exceeds the maintenance window.

**Entry criteria.**
- FAA operational sign-off on the maintenance window.
- Rollback drill completed end-to-end.
- Data migration cut-over staging is prepared (final CDC delta
  applied, target data store verified).
- Operator on-call rotation is in place for the cutover weekend.

**Exit criteria.**
- All user traffic is on the target.
- Legacy is in a "frozen" state (read-only or powered off).
- Validation gates G-V1, G-V2, G-V3 pass against the target.
- Post-cutover monitoring shows no regression over 72 hours.

**Rollback mechanics.** Flip DNS / routing back to legacy; restore
legacy to read-write (if frozen); replay CDC tail from target to
legacy to capture any cutover-window writes; announce rollback to
user population. Rollback must be executable within the maintenance
window; if it is not, big-bang is the wrong pattern.

**Sample runbook structure.** Pre-flight (week before) → freeze
legacy writes → final CDC delta → validation gates → cutover →
post-cutover monitoring → all-clear at T+72h.

**FAA example.** RMS aircraft-side SQL Server → Aurora PG cutover.
The aircraft-registry data store is legal-record per 49 USC §44107;
splitting the authoritative record across two data stores during
transition is not viable. The cutover happens on a published
weekend maintenance window with a rollback drill the week before.

---

## 4. Data-double-write

**Intent.** Write every change to both legacy and target data stores
simultaneously for a period. Reads can come from either side; the
divergence between the two is monitored continuously.

**When to use.** The target data store is being populated while the
legacy remains authoritative. A future cutover will flip read
authority to the target. Both stores must stay in sync during the
transition window.

**When to avoid.** The two data stores have materially different
semantics (e.g., NUMBER(p,s) in Oracle vs NUMERIC(p,s) in PostgreSQL
with divergent rounding). Conflict resolution rules are undefined.

**Entry criteria.**
- Both data stores are writable.
- A write fan-out mechanism is in place (application-level, CDC-
  replicated, or queue-based).
- Conflict-resolution rule is defined (`last-write-wins`, `merge`,
  or `arbiter-service`).

**Exit criteria.**
- Divergence report shows zero divergence across a representative
  sample window.
- Read authority flips to target; legacy writes cease.

**Rollback mechanics.** Stop writing to target; resume legacy-only.
Any target-side writes that happened after rollback need to be
reconciled via CDC or manual review; the rule set for this
reconciliation is part of the rollback posture.

**Sample runbook structure.** Pre-flight → enable dual-write →
monitor divergence daily → address divergences → flip read authority
→ stop legacy writes.

**FAA example.** IACRA SQL Server → Aurora PG migration uses
data-double-write for the cert-application store. Application-layer
dual-write fans out to both stores; the divergence report runs
nightly; read authority flips to Aurora at cutover.

---

## 5. Branch-by-abstraction

**Intent.** Introduce an abstraction layer inside the legacy codebase
that can dispatch to either the legacy implementation or a new
implementation. Build the new implementation behind the abstraction
while legacy continues in production. Flip at cutover.

**When to use.** The capability is embedded inside a legacy module
that cannot be externally fronted by a router (typical of NATURAL /
COBOL / VB6 monoliths where the module is called in-process).
The team controls the legacy code enough to insert an abstraction.

**When to avoid.** The legacy code is closed-source or third-party.
The abstraction layer would itself be a rewrite of similar scale
to the transition.

**Entry criteria.**
- Abstraction interface is designed and approved.
- Legacy code is refactored to call through the abstraction.
- New implementation exists behind the abstraction.

**Exit criteria.**
- All calls through the abstraction route to the new
  implementation.
- Old implementation is removed from the abstraction; abstraction
  itself may be retained or inlined later.

**Rollback mechanics.** Flip the abstraction's dispatch to the old
implementation. Because the abstraction is in-process, rollback
does not require a deployment if the dispatch is feature-flag-
backed; otherwise, rollback is a redeployment of the prior build.

**Sample runbook structure.** Pre-flight → design abstraction →
refactor legacy to dispatch through it → implement new behind it →
dark-launch N% → cut dispatch to new → retire old.

**FAA example.** RMS NATURAL CAIS reads. Wrap the CAIS airman-read
NATURAL subroutine in an abstraction; implement the target API call
behind the abstraction; shadow-mode N% of reads to the target;
flip dispatch to target when parity is verified.

---

## 6. Feature-flag-rollout

**Intent.** Gate a user-visible capability behind a feature flag;
progressively enable for user cohorts; disable quickly if issues
arise.

**When to use.** UI changes or user-visible behavior changes that
benefit from cohort-based rollout. A/B tests where legacy and target
behavior are compared per user. Any rollout where a fast off-switch
is valuable.

**When to avoid.** Back-end-only changes with no user-visible
surface (prefer dark-launch or shadow-mode). Changes where the flag
itself becomes a bottleneck or a fragility source.

**Entry criteria.**
- Feature-flag infrastructure is in place (AWS AppConfig or
  equivalent).
- Cohort targeting rules are defined.
- Metrics for success and rollback triggers are defined.

**Exit criteria.**
- Flag is enabled for 100% of the user population.
- Flag is removed from the code on a later sprint.

**Rollback mechanics.** Flip the flag off. That is the whole point of
the pattern; rollback is mechanical and fast.

**Sample runbook structure.** Pre-flight → enable flag for N%
cohort → monitor → expand cohort → full rollout → schedule flag
removal.

**FAA example.** DMS Angular 8 → Angular 17 UI rollout. The new UI
is behind a feature flag; a designee cohort tests first; rollout
expands over weeks; the flag is removed after stabilization.

---

## 7. Dark-launch

**Intent.** Deploy the target code path into production where it
runs silently — it produces outputs but does not surface them to
users. Used to collect production-traffic performance and parity
data before a cut.

**When to use.** Back-end changes where the code path can run
silently (e.g., a new risk-scoring algorithm running in parallel
with the old one, with its outputs logged but not displayed). High-
risk changes where prior non-production testing is not sufficient.

**When to avoid.** Changes that have side effects on external systems
(emails, payments, external API calls). The dark-launched path must
be side-effect-free for the pattern to be safe.

**Entry criteria.**
- Target code path can be invoked without user-visible side effects.
- Logging and observability are in place to capture the dark-
  launched outputs.
- Comparison harness exists (matches dark output against live
  output).

**Exit criteria.**
- Dark output matches live output within the agreed tolerance for
  ≥ N days.
- Cutover to target (using a different pattern, often feature-flag
  or strangler-fig) begins.

**Rollback mechanics.** Disable the dark-launched code path via
feature flag or deployment. No user-visible impact if the dark
launch was side-effect-free.

**Sample runbook structure.** Pre-flight → enable dark path →
capture outputs → compare → iterate → disable dark path → move to
cutover pattern.

**FAA example.** CPDSS drug-risk scoring model upgrade. New scoring
model runs dark alongside the old; outputs are logged and compared;
when the team has confidence in the new model, cutover happens via
feature-flag rollout.

---

## 8. Shadow-mode

**Intent.** Route production traffic to both legacy and target;
legacy responds authoritatively; target receives the traffic but
its responses are discarded. Used to verify the target can handle
production load and produce correct responses before giving it
authoritative status.

**When to use.** The target must be verified under production-
traffic conditions. The target is a full replacement for a legacy
path; shadow-mode is the last step before cut.

**When to avoid.** The target has side effects that cannot be
isolated (writes to shared data stores, external notifications).
Shadow-mode requires the target to be side-effect-free during
shadow or requires careful isolation.

**Entry criteria.**
- Traffic duplication mechanism is in place (reverse proxy,
  queue fan-out, or request-cloning layer).
- Target has a data store separate from the legacy or a safe
  isolation mode.
- Response-comparison harness is in place.

**Exit criteria.**
- Target responses match legacy responses across the agreed
  tolerance over ≥ N days of production load.
- Cutover to target (typically via big-bang or strangler-fig)
  begins.

**Rollback mechanics.** Stop duplicating traffic to the target.
Legacy was always authoritative; no user-visible impact.

**Sample runbook structure.** Pre-flight → enable traffic
duplication → monitor target health and parity → expand duplication
to 100% → confirm readiness → move to cutover pattern.

**FAA example.** RMS airman-side target services receive shadow
traffic from the NATURAL CAIS front-end for 4+ weeks before the
branch-by-abstraction flip. Target response parity is verified
across all call signatures; target operational posture
(latency, error rate) is validated under production load before
cutover.

---

## Pattern-combination notes

Patterns often layer. Common combinations:

- **Strangler-fig + feature-flag.** The router rule per capability
  is backed by a feature flag so that rollback is a flag flip, not
  a router-config deployment. Recommended for any strangler-fig.
- **Dark-launch + shadow-mode.** A capability runs dark (silent
  outputs logged) while the front-end runs in shadow (production
  traffic duplicated). The pair gives the team end-to-end parity
  evidence before any cutover action.
- **Parallel-run + data-double-write.** When the target's data store
  diverges from the legacy's, parallel-run on the compute plane
  pairs with data-double-write on the data plane to keep both in
  sync.
- **Big-bang + shadow-mode precursor.** A big-bang cutover is
  de-risked by running shadow-mode for weeks prior. The cutover is
  still atomic (single maintenance window) but the target is
  pre-verified.
- **Branch-by-abstraction + dark-launch.** The abstraction dispatches
  a small percentage of calls to a dark path that logs outputs
  without surfacing them; production parity data accumulates before
  dispatch flips.

Record the pattern combination explicitly in `transition_patterns[]`
rationale when more than one pattern applies. The
`cutover_dependency_validator` accepts combinations only when the
`entry_criteria` reference the downstream pattern explicitly.
