---
name: transition-strategy-designer
description: >
  Select and sequence per-app and per-capability transition mechanics that
  move a FAA legacy workload to its AWS GovCloud target state. Picks among
  strangler-fig, parallel-run, big-bang cutover, data-double-write,
  branch-by-abstraction, feature-flag-rollout, dark-launch, and shadow-mode
  patterns per capability. For each selection, records cutover sequence,
  entry and exit criteria, dependencies, rollback posture, data migration
  approach (bulk-load, incremental-CDC, logical-replication, dual-write),
  validation gates, and GFI (Government Furnished Information) continuity
  plan. Consumes wave-plan.json (sequencing), rationalization-to-architecture-
  traceability (mapping), and dependency-graph.json (blocking edges). Emits
  transition-strategy.json and a cutover-runbook.md per cutover window.
  Triggers on transition strategy, cutover planning, strangler-fig design,
  rollback design, or @transition-strategy-designer.
agent: sonnet
allowed-tools:
  - Read
  - Write
  - Grep
  - Bash
validation_commands:
  - "python -m olympus.validators.schema_validator transition-strategy.json"
  - "python -m olympus.validators.rollback_posture_validator transition-strategy.json"
  - "python -m olympus.validators.cutover_dependency_validator transition-strategy.json"
supported_stacks:
  - aws-govcloud
  - aws
  - azure-gov
  - dotnet
  - java
  - natural
  - adabas
  - oracle
  - sqlserver
  - postgresql
anti_target_stacks:
  - retire-only
  - retain-only
failure_classes:
  - aspirational-rollback
  - parallel-run-cost-unbudgeted
  - data-migration-bandwidth-underestimated
  - byte-preservation-parity-skipped
  - cutover-window-conflict
  - strangler-fig-legacy-retired-early
  - dual-write-conflict-resolution-missing
benchmark_tags:
  - architecture-transition-mechanics
  - cutover-sequencing
  - rollback-safety
  - gfi-continuity
---

# transition-strategy-designer

## Purpose
Choose the mechanical patterns by which each capability transitions from
legacy to target, and sequence those patterns into cutover windows that
respect FAA operational constraints. Sub-factor 3 of the SOO evaluation
(per `/Users/pnunna/Documents/SOO-Announcement/Phase2_Evaluation_Criteria.md`
§5) scores transition risk posture heavily: an evaluator must see that
the proposer understands when strangler-fig is correct, when parallel-run
is required by law (14 CFR Part 67 byte-preservation of medical letter
wording through the transition), when big-bang is the only viable choice
(legal-record Tier-1 apps on FAA-published maintenance windows), and
when a dual-write pattern requires explicit conflict-resolution rules.
This skill emits those choices with the dependencies and rollback
posture downstream operators need to execute the cutover safely.

## Inputs
- Application catalog entry per app and the matching
  `disposition-recommendation.json` row — the pattern set differs by
  disposition (Rearchitect vs Replatform vs Replace vs Consolidate).
- Target architecture per app — `target-architecture.json` (from
  `aws-govcloud-target-architecture`) — names the target services that
  will replace legacy capabilities.
- Rationalization-to-architecture traceability —
  `rationalization-traceability.json` (from
  `rationalization-to-architecture-traceability`) — maps every legacy
  capability to its target architecture element.
- Wave plan — `wave-plan.json` and the arch-dependency wave overlay
  (`modernization-wave-sequencing.json`) — supplies the blocking-edge
  sequence (landing zone before tenants; shared identity before apps;
  canonical-entity-model before consuming apps).
- Dependency graph — `dependency-graph.json` — supplies the per-capability
  blocking edges within an app.
- Business-logic capability inventory — `business-logic.json` per app —
  supplies the capability set at the granularity this skill operates on.
- Domain decomposition — `domain-decomposition.json` (from
  `faa-domain-decomposition-designer`) — supplies the bounded-context
  view so cutover sequencing respects context boundaries.
- Transition pattern playbook reference —
  `references/transition-pattern-playbook.md` — authoritative per-pattern
  entry criteria, exit criteria, and rollback mechanics.
- Regulatory scope — 14 CFR Part 61/63/65 (IACRA), Part 67 (medical
  letters), Part 183 (DMS), 49 USC §44107 (aircraft registry). Not read
  programmatically but informs pattern selection (byte-preservation
  requirements force parallel-run with letter-text parity verification).

## Outputs
- `transition-strategy.json` per application. Required shape:
  - `app_id` — matches the catalog entry.
  - `transition_patterns[]` — one row per capability:
    - `capability` — capability id from `business-logic.json`.
    - `pattern` — `strangler-fig` | `parallel-run` | `big-bang` |
      `data-double-write` | `branch-by-abstraction` | `feature-flag` |
      `dark-launch` | `shadow-mode`.
    - `sequence_order` — integer cutover-sequence position within the
      app.
    - `dependencies[]` — capability ids or external artifacts that must
      be complete before this capability begins.
    - `entry_criteria` — prose list of conditions that must hold at the
      start; cite the validation_gates required.
    - `exit_criteria` — prose list of conditions that must hold to mark
      the capability cut over.
    - `rollback_posture` — prose plan for mechanical rollback; must be
      specific, not aspirational ("we will re-enable the legacy route"
      is not a rollback posture — "we flip feature flag X to 'legacy',
      drain in-flight requests, replay CDC tail to legacy, verify
      parity" is).
    - `data_migration_approach` — `bulk-load` | `incremental-cdc` |
      `logical-replication` | `dual-write` | `none` (for stateless
      capabilities).
    - `validation_gates[]` — gate ids (G-V1, G-V2, G-V3 typically)
      that must pass for the capability cutover.
  - `phase_duration_weeks` — target duration for the entire transition
    in weeks; derived from the sum of `transition_patterns[]` sequence
    plus parallelizable slack.
  - `risk_register[]` — per risk: description, probability, impact,
    mitigation pattern, owner.
  - `gfi_continuity_plan` — how Government Furnished Information
    (government-provided data, government-provided systems access)
    remains accessible through the transition; required by most FAA
    contracts.
- `cutover-runbook.md` per cutover window. Human-readable operator
  runbook. Sections: Pre-flight, Go-decision criteria, Cutover steps,
  Validation checks, Rollback triggers, Rollback steps, Post-cutover
  monitoring, All-clear criteria.

## Methodology
1. Read the catalog entry, disposition row, target architecture, and
   rationalization traceability. If disposition is Retire or Retain,
   stop — this skill is not applicable (validator flags
   `disposition-out-of-scope`).
2. Enumerate capabilities from `business-logic.json`. Each capability
   is a candidate transition unit. Cross-check against the bounded
   contexts in `domain-decomposition.json` — a capability that
   crosses a context boundary is split.
3. Select the transition pattern per capability. Apply decision rules,
   stopping at the first match:
   - `parallel-run` when regulatory byte-preservation applies (all 14
     CFR Part 67 medical letter templates; always parallel-run with
     letter-text parity verification before cutover).
   - `strangler-fig` when the legacy system is accessible throughout
     and capabilities can be replaced one at a time (IACRA WebForms,
     one form family per sprint).
   - `data-double-write` when two data stores must stay in sync
     through the transition (SQL Server legacy + Aurora PostgreSQL
     target for IACRA, until parity verified).
   - `branch-by-abstraction` when the capability is embedded in a
     legacy module that cannot be accessed externally (NATURAL reads
     from CAIS — wrap in abstraction, implement both legacy and
     target behind the abstraction, flip at cutover).
   - `feature-flag` when the capability is user-visible and needs
     staged rollout (UI changes, A/B tests of target flows).
   - `dark-launch` when the capability must run in production but
     not be visible to users (new algorithm running silently to
     collect parity data).
   - `shadow-mode` when the target system runs alongside legacy
     receiving a copy of production traffic without responding
     authoritatively (common precursor to cutover for high-risk
     capabilities).
   - `big-bang` as the fallback for Tier-1 legal-record capabilities
     where a single cutover on a published FAA maintenance window is
     the only viable option.
4. Pick the data migration approach per capability. Rules:
   - `bulk-load` for small static reference data.
   - `incremental-cdc` when continuous change capture from the legacy
     source is available (AWS DMS for Oracle, custom CDC for ADABAS,
     logical decoding for PostgreSQL).
   - `logical-replication` when both sides are PostgreSQL (within
     Aurora and between RDS PostgreSQL and Aurora).
   - `dual-write` when both systems must accept writes through the
     transition. Always accompanied by conflict-resolution rules
     (`last-write-wins`, `merge`, or `arbiter-service`).
   - `none` for stateless capabilities (request/response compute
     with no durable state).
5. Sequence the capabilities within the app. Apply the wave-plan
   blocking edges and the internal dependency graph. Record
   `sequence_order` as an integer; identical `sequence_order` values
   denote parallel-cut capabilities.
6. Write `entry_criteria` and `exit_criteria` per capability. Entry
   criteria cite the validation_gates that must be passing at the
   start. Exit criteria describe the measurable parity conditions
   (e.g., "99.99% of in-flight requests succeed through the target
   for 7 consecutive days", "letter-text parity verified byte-for-byte
   across 100% of sample letters").
7. Write `rollback_posture` per capability. Rollback must be
   mechanical and documented — never aspirational. Cite the runbook
   section that executes the rollback. `rollback_posture_validator`
   rejects posture that lacks (a) a named rollback action, (b) a
   named validation that rollback succeeded, and (c) a named
   operator role.
8. Populate `risk_register[]`. Minimum risks to enumerate: data-
   migration bandwidth underestimate (especially 146M TIFF corpus
   for RMS), Oracle-to-PG stored-proc translation gap, cutover-window
   conflict with FAA published maintenance windows, byte-preservation
   parity failure, rollback-time-exceeds-maintenance-window.
9. Write `gfi_continuity_plan`. The agency provides data, systems
   access, and sometimes operator staff; the transition cannot
   interrupt the GFI continuity without a contract modification.
   Name the GFI items per app, the continuity posture through each
   phase, and the named owner.
10. Render `cutover-runbook.md` per cutover window. Sections listed
    in Outputs. Runbook is the operator's binding reference during
    cutover; the JSON is the planner's reference during design.
11. Validate. The JSON must pass its schema and both custom
    validators (`rollback_posture_validator`,
    `cutover_dependency_validator`). The runbook is linted against
    required sections but not schema-validated.

## Tech-Stack Dispatch

| Disposition + stack | Default pattern set |
|---|---|
| IACRA Rearchitect (WebForms + VB.NET + Node + SQL Server) | Strangler-fig around WebForms forms family by family; data-double-write to SQL Server + Aurora PG; parallel-run for cert-issuance path; big-bang final cutover on FAA maintenance window |
| RMS Rearchitect (NATURAL/ADABAS + Windows SQL Server) | Branch-by-abstraction around CAIS reads and writes; AWS DMS + custom CDC for ADABAS → Aurora PG; shadow-mode first (read-only), then write-through, then cutover; TN3270 user training 4+ weeks pre-cutover |
| MSS Consolidation (AMCS + MedXPress + CHAPS + CPDSS + DIWS on shared Oracle) | Shared-db-decomposition patterns first — split Oracle schema into domain-scoped DBs in-place; then consolidate apps onto new schemas one bounded context at a time using strangler-fig; parallel-run mandatory for letter generation (Part 67 byte-preservation) |
| DMS Replatform (ASP.NET Core + Angular 8 + SQL Server + Postgres audit) | Lift-and-shift EC2 → ECS Fargate (minimal code change); Angular 8 → Angular 17 upgrade in a separate track; SQL Server → Aurora PG migration as a discrete sub-project with data-double-write then cutover |

## Gotchas
- Strangler-fig requires the legacy system to remain addressable
  throughout the transition. Do not retire the legacy prematurely —
  the fig's whole premise is that the legacy tree is load-bearing until
  it is completely replaced. Retiring early is the
  `strangler-fig-legacy-retired-early` failure class.
- Parallel-run doubles infrastructure cost for the duration. Budget
  for it explicitly in the cost-envelope rationale of
  `target-architecture.json`. A parallel-run that is not budgeted
  gets cut mid-transition, leaving the legacy in flight and the
  target unverified.
- Dual-write needs conflict-resolution rules from day one. Choose
  `last-write-wins` when one side is clearly the authoritative writer
  during the transition (target side in most cases); choose `merge`
  when both sides write non-overlapping fields; choose `arbiter-
  service` when neither is viable and a third service adjudicates.
  A dual-write without rules is the
  `dual-write-conflict-resolution-missing` failure class.
- Big-bang cutover on Tier-1 legal-record apps (IACRA permanent cert
  ledger, RMS aircraft registry) requires explicit FAA operational
  sign-off. Maintenance windows are published publicly; plan around
  them, do not ask for bespoke windows unless the contract authorizes
  it.
- Rollback posture must be mechanical, not aspirational. "We will
  figure it out" and "we'll monitor and revert if needed" are not
  rollback posture. Every rollback posture cites a named action, a
  named validation, and a named operator role. The validator enforces
  this; aspirational rollback is the `aspirational-rollback` failure
  class.
- Data migration bandwidth is always underestimated. The 146M TIFF
  corpus on RMS represents hundreds of terabytes; DMS cutover for
  the Aurora migration is not constrained by compute speed but by
  network egress from the legacy data center. Plan for Snowball or
  Direct Connect bulk transfer alongside CDC tail.
- Oracle-to-PostgreSQL migration via AWS DMS has known gaps:
  stored-procedure translation is incomplete; data-type precision
  for NUMBER(p,s) may not round-trip exactly; empty string vs NULL
  handling differs. Run AWS Schema Conversion Tool first and triage
  the gaps in `risk_register[]`.
- Cutover windows for FAA apps are limited. IACRA operates 24/7
  with published maintenance windows (typically weekend overnight).
  RMS is similarly constrained. MSS has narrower windows due to AAM
  operational posture. Cross-check the FAA published maintenance
  window schedule before assigning a cutover date.
- 14 CFR Part 67 letter wording byte-preservation applies through
  the transition. Parallel-run must verify letter-text parity
  byte-for-byte across a statistically valid sample (all template
  types, at minimum). A transition that cuts over Regulatory Letter
  Generation without byte-parity evidence is the
  `byte-preservation-parity-skipped` failure class.
- RTO and RPO targets per SOO Objective 3 (99.9%+ availability)
  constrain the pattern choice. Big-bang can only clear the RTO
  envelope if the rollback plan is executable within the same
  maintenance window. Parallel-run always clears RTO (the legacy
  path is available) but may fail RPO (divergent writes during
  the parallel window).
- Shadow-mode and dark-launch are complementary: shadow-mode is
  about the target receiving real traffic silently; dark-launch
  is about the target's code path running silently inside a
  production deployment without being user-visible. Both can run
  simultaneously; do not confuse them in the runbook.
- GFI continuity is contract-load-bearing. FAA provides identity
  federation (PIV issuance, Login.gov access), operator staff,
  and in some cases legacy systems access. Any pattern that
  requires an interruption of GFI requires a contract mod; the
  `gfi_continuity_plan` on each app spells out which GFI items
  apply and how the pattern preserves continuity.

## Quality Rules
- [ ] Every `transition_patterns[]` row cites a capability id that
      resolves to a capability in `business-logic.json`.
- [ ] Every `pattern` is one of the eight enum values
      (`strangler-fig` | `parallel-run` | `big-bang` |
      `data-double-write` | `branch-by-abstraction` | `feature-flag` |
      `dark-launch` | `shadow-mode`).
- [ ] Every `rollback_posture` names a rollback action, a validation,
      and an operator role (validator:
      `rollback_posture_validator`).
- [ ] Every `dependencies[]` reference resolves to a capability id or
      a named external artifact (validator:
      `cutover_dependency_validator`).
- [ ] `data_migration_approach` is one of the six enum values; `dual-
      write` entries include a conflict-resolution rule in
      `entry_criteria`.
- [ ] Every 14 CFR Part 67 letter-generation capability uses
      `pattern = parallel-run` and cites byte-preservation parity in
      `exit_criteria`.
- [ ] `phase_duration_weeks` is an integer ≥ 1 and consistent with
      the sum of sequenced capabilities.
- [ ] `risk_register[]` has ≥ 3 rows and every row has probability,
      impact, mitigation, and owner.
- [ ] `gfi_continuity_plan` names the GFI items and the owner for
      each phase.
- [ ] `cutover-runbook.md` has all eight required sections.

## Common Failure Modes
| Failure Mode | Symptom | Prevention |
|---|---|---|
| Aspirational rollback | Rollback posture says "we will monitor and revert" with no named action | Every `rollback_posture` names an action, a validation, and a role; validator rejects narrative-only posture |
| Parallel-run cost unbudgeted | Parallel pattern selected but `target-architecture.json` cost_envelope_rationale omits the double-infrastructure line | Cross-check the cost envelope when parallel-run is selected; update the target architecture if missing |
| Data-migration bandwidth underestimated | 146M TIFF corpus scheduled for a single weekend cutover | Treat bulk data migration as its own sub-project; schedule Snowball or Direct Connect; cite the bandwidth assumption in `risk_register[]` |
| Byte-preservation parity skipped | Letter-generation cutover in `exit_criteria` does not cite byte-for-byte parity evidence | Every Part 67 letter capability pins parallel-run with letter-text parity in exit criteria; no exceptions |
| Cutover-window conflict | Scheduled cutover date collides with an FAA published maintenance window for another app | Cross-check FAA maintenance-window schedule when placing cutover dates; stagger windows across apps |
| Strangler-fig legacy retired early | Legacy system scheduled for retirement before the fig is complete; downstream capabilities lose their source | Strangler-fig exit criteria require 100% of capabilities cut over; legacy retirement follows, not precedes, the final cut |
| Dual-write conflict resolution missing | `data_migration_approach: dual-write` row without a conflict rule | Require `entry_criteria` to name the conflict-resolution rule whenever `dual-write` is selected |

## Handoff Summary
When this skill completes, verify:
1. `transition-strategy.json` exists per app, passes its schema, and
   passes both custom validators.
2. Every capability from `business-logic.json` has a corresponding
   `transition_patterns[]` row or an explicit exclusion rationale.
3. Every rollback posture is mechanical (named action + validation +
   role).
4. Every Part 67 letter-generation capability uses parallel-run with
   byte-preservation parity in exit criteria.
5. `cutover-runbook.md` exists per cutover window with all eight
   required sections.
6. `gfi_continuity_plan` is populated per app.

Then proceed to: `arch-dependency-wave-synthesizer` (consumes the
per-app transition strategies to produce the portfolio-level wave
sequencing), `continuous-compliance-evidence-designer` (consumes the
validation gate list per pattern to design the evidence pipeline),
and the implementation-phase operator work that executes each
`cutover-runbook.md`. The next gate is **G-DA** (Design Acceptance),
after which the Modernization line Extract→Design→Generate cycle
uses the transition strategy to sequence the Generate wave.

## References
- `references/transition-pattern-playbook.md` — per-pattern playbook:
  when to use, when to avoid, entry criteria, exit criteria, rollback
  mechanics, sample runbook structure, worked FAA examples.
- `schemas/architecture/transition-strategy.schema.json` — canonical
  JSON shape.
- `/Users/pnunna/Documents/SOO-Announcement/Phase2_Evaluation_Criteria.md`
  §5 Sub-factor 3 — evaluator rubric for transition mechanics scoring.

## Changelog
- 0.1.0 (2026-05-06) — Initial skill. Enumerates eight transition
  patterns (strangler-fig, parallel-run, big-bang, data-double-write,
  branch-by-abstraction, feature-flag, dark-launch, shadow-mode),
  six data-migration approaches, and mechanical rollback posture
  requirements. Covers IACRA Rearchitect, RMS dual-side Rearchitect,
  MSS Consolidation (with shared-db-decomposition-first sequencing),
  and DMS Replatform.
