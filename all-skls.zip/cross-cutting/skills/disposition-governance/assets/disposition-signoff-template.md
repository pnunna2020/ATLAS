# Disposition Decision Sign-off Request

Template for requesting stakeholder approval on an application disposition
(Retire, Retain, Refactor, Rearchitect, Replace, Replatform, Consolidate).
Use during P1.2 governance gate.

## Application

- Application ID: <FAA-NNNN>
- Application name: <fill-in>
- Risk tier: <T1 / T2 / T3>
- Current status: <In Production / Reduced Use / Deprecated>

## Recommended Disposition

- Recommendation: <Retire / Retain / Refactor / Rearchitect / Replace / Replatform / Consolidate>
- Target wave: <Wave N or "Not scheduled">
- Target assembly line(s): <Modernization / Disposition Execution / Retain>

## Rationale

Summarize the disposition recommendation in plain language. Reference the
P1.1 scoring output and cite specific Discovery findings that drove the
decision. Use `{artifact}:{section}:{finding-id}` traceability citations.

## Evidence Package

- P1.1 scoring results: <link or artifact path>
- Scoring methodology version: <from scoring.yaml profile bundle>
- Impact analysis: <link>
- TCO baseline: <link>
- User migration plan (required for Retire): <link or "N/A">
- Consolidation target (required for Consolidate): <target app ID>
- Replacement target (required for Replace): <COTS product or SaaS>

## Stakeholders

Every sign-off request MUST include both IT and business stakeholders. Populate
from application ownership data.

| Role                     | Name | Org | Required | Status   | Date |
|--------------------------|------|-----|----------|----------|------|
| Application Owner (IT)   |      |     | Yes      | Pending  |      |
| Business Owner           |      |     | Yes      | Pending  |      |
| ISSO / Security Officer  |      |     | Yes      | Pending  |      |
| Enterprise Architect     |      |     | Yes      | Pending  |      |
| Portfolio Manager        |      |     | Yes      | Pending  |      |

## Dissenting Opinions

If any stakeholder disagrees, log the objection here with the rationale and
the resolution (accepted / overridden / deferred). Do not suppress dissent.

## Decision

- Final decision: <approved / rejected / deferred>
- Decision date: <YYYY-MM-DD>
- Decision recorder: <name>
- Overrides or exceptions: <describe or "none">

<!-- TODO(skill-author): Convert this template into a machine-readable
     artifact (YAML or JSON) so dashboards can ingest sign-off status without
     scraping markdown. -->
