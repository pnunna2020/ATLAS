# Disposition Override Register

Append-only record of every stakeholder override of a data-driven disposition recommendation. One entry per override. Never edit existing entries; add a new entry that references the prior one to correct a record.

---

## Override Entry

**Entry ID:** `OVR-{app-id}-{YYYYMMDD}-{sequence}`
**Application:** `{app-id}` — `{app-name}`
**Entry Date:** `{YYYY-MM-DD}`
**Supersedes Entry (if correction):** `{prior-entry-id or "none"}`

### Override Source

| Field | Value |
|---|---|
| Name | `{stakeholder full name}` |
| Role | `{role — e.g., Business Owner, IT Owner, CIO}` |
| Source of Authority | `{CMDB record / CODEOWNERS / SLA signatory / etc.}` |

### Recommendations

| Field | Value |
|---|---|
| Data-Driven Recommendation | `{Retire / Retain / Refactor / Rearchitect / Replace / Replatform / Consolidate}` |
| Recommendation Score | `{0.00-1.00}` |
| Top Contributing Factors | 1. `{factor}`  2. `{factor}`  3. `{factor}` |
| Override Recommendation | `{chosen disposition}` |

### Justification

`{3-6 sentence paragraph. Must reference a specific fact not visible to the scoring model — e.g., pending regulatory change, upcoming contract renewal, dependent program milestone, known user-migration blocker. Generic business-priority language is not acceptable.}`

### Approver

| Field | Value |
|---|---|
| Approver Name | `{approver full name, must differ from Override Source}` |
| Approver Role | `{role with authority to approve at this disposition level}` |
| Approval Date | `{YYYY-MM-DDTHH:MM:SSZ}` |
| Risk Acknowledgement | `[ ] I have read the data-driven recommendation and accept the residual risk of the override` |

### Dissent (if any)

| Dissenting Stakeholder | Objection | Resolution | Rationale |
|---|---|---|---|
| `{name, role}` | `{verbatim objection}` | `{accepted / rejected / escalated}` | `{rationale}` |

### Escalation History (if any)

| Date | Event | Actor | Outcome |
|---|---|---|---|
| `{YYYY-MM-DD}` | `{no-response / portfolio-manager-review / deadline-extension / ratification}` | `{name}` | `{outcome}` |

### Audit Trail Links

- Sign-off packet: `{artifact ref}`
- Scoring evidence: `{artifact ref}`
- Gate record: `{G-DC gate instance id}`

---

*Append new override entries below this line.*
