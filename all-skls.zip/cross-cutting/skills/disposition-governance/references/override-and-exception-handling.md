# Override and Exception Handling

When a stakeholder chooses a disposition different from the data-driven recommendation, record the override in full so the audit trail shows both paths and the reasoning.

## Fields to Capture on Every Override

1. **Override source** — role and name of the stakeholder initiating.
2. **Data-driven recommendation** — disposition from P1.1 scoring, with score and top three factors.
3. **Override recommendation** — the chosen disposition.
4. **Justification paragraph** — 3-6 sentences citing a specific fact not visible to the scoring model. Generic "business priority" is not acceptable.
5. **Approver identity and role** — named human authorizing the override. Self-approval is prohibited; approver must differ from override source.
6. **Approval date** — ISO 8601 timestamp.
7. **Risk-acknowledgement checkbox** — approver confirms they read the recommendation and accept residual risk. Unchecked invalidates the override.

## Dissent Registration

If a required stakeholder objects, record the objection verbatim, the resolution (accepted, rejected, escalated), and the rationale. Dissent does not block sign-off but must be visible. Unresolved dissent from a required approver blocks the gate.

## Escalation Rules

- No response from a required approver within **5 business days** of packet issuance escalates to the portfolio manager.
- Portfolio manager may re-assign the slot, extend the deadline once (max 5 more business days), or ratify under delegated authority. All outcomes logged.
- Two escalations on one app in a quarter trigger a governance review.

## Audit-Trail Preservation

- Overrides are immutable once approved. Corrections require a new record referencing the prior one.
- The data-driven recommendation is preserved verbatim; never overwritten.
- The override register (`assets/override-register-template.md`) is append-only.
- Records retained for the app's full retention period or 7 years, whichever is longer.
