# Stakeholder Identification Heuristics

Find the right approvers for every application before issuing sign-off. Identification happens in two tracks that must both succeed.

## IT Owner Discovery

Resolve in order; stop at the first authoritative source:

1. CMDB record — `technical_owner` or `system_owner` field.
2. Repository `CODEOWNERS` — top-listed team is primary; individuals on the deployment manifest path are co-owners.
3. Deployment pipeline approvers — required reviewers in the CI/CD config for production.
4. Infra runbook `on_call` rotation lead when the above are absent.

Record the source used so the audit trail shows why that person was chosen.

## Business Owner Discovery

Resolve in order:

1. Application catalog `user_context.business_owner`.
2. SLA or contract signatory on the active service agreement.
3. Org chart — the VP/Director whose cost center funds the app.
4. Compliance register — the named official who signs the ATO, PIA, or SORN. Mandatory co-approver when compliance obligations exist, even if step 1 resolved.

## Fallback Chain When Catalog Is Silent

When no business owner is named in any authoritative system:

1. Most recent production-incident escalation record — the executive who received the page.
2. Billing cost center owner from the finance system.
3. Most recent stakeholder email thread in the repo (`docs/`, `CHANGELOG`, mailing list) — the senior non-IT recipient.

If all three fail, escalate to the portfolio manager to assign an acting business owner. Do not proceed to sign-off without a named human in the business-owner slot.

## Quality Checks

- Every stakeholder row has: name, role, source of record, contact, scope.
- At least one IT owner and one business owner named before packet generation.
- Privacy officer added automatically when data classification includes PII, PHI, or CUI.
