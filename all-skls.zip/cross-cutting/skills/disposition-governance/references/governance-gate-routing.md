# Governance Gate Routing

Which disposition triggers which approval path. Required paths must complete before the disposition is accepted at gate G-DC. Optional paths trigger only when listed criteria are met.

## Routing Table

| Disposition | Required Approvers | Optional Approvers | Trigger for Optional |
|---|---|---|---|
| Retire | Business owner + IT owner | Privacy officer | Data classification Sensitive or higher (PII/PHI/CUI) |
| Replace | Business owner + IT owner | CIO, procurement lead | COTS/SaaS with new contract, OR value exceeds CIO threshold ($250K/yr default) |
| Consolidate | Source owners (biz + IT) AND target owners (biz + IT) | Data steward | Migration moves regulated data or changes record-of-truth |
| Rearchitect | IT owner | CIO | Cost exceeds rearchitect threshold ($500K default) OR spans more than one fiscal year |
| Replatform | IT owner | Platform team lead | Target not on approved platform catalog, OR introduces a new runtime |
| Refactor | IT owner | — | — |
| Retain | IT owner | — | — |

## Mandatory Additions

Added to any disposition when the condition holds, regardless of base routing:

- **Privacy officer** — data classification Sensitive or higher. Always required for Retire involving PII.
- **Security officer** — app holds an active ATO and the disposition changes the authorization boundary (Retire, Replace, Rearchitect, Replatform, Consolidate).
- **Records officer** — disposition affects retention-scheduled records (most Retire and Consolidate cases).

## "Optional" Semantics

"Optional" means not on default routing but **required when trigger criteria are met**. The skill evaluates every optional criterion at packet-assembly time and promotes approvers when triggered. "Optional" is not "skippable."

## Output

Record routing in the packet header as a table of approvers, each tagged `required` or `promoted`, with the triggering criterion cited for every promotion.
