---
name: disposition-governance
description: >
  Manage the stakeholder sign-off process for application disposition decisions (Retire, Retain, Refactor, Rearchitect, Replace, Replatform, Consolidate). Use during P1.2 governance gate. Triggers on disposition governance, stakeholder sign-off, retirement approval, compliance-gate review, policy override, or disposition decision.
agent: opus
allowed-tools:
  - Read
  - Write
  - Grep
---

# Disposition Governance Workflow

## Purpose
Close the Rationalization loop at step P1.2 by turning a disposition recommendation into an auditable, risk-tier-aware governance record: stakeholder sign-offs, compliance-gate evaluations, policy overrides, and an explicit approved/conditionally-approved/rejected/pending-sign-off status. This is the authoritative artifact the Disposition Approval gate reads, and the record Disposition Execution cites before any destructive action. Governance reasoning is high-stakes (a bad sign-off can retire an active app, waive a compliance control, or mis-route a Tier 1 decision), which is why this skill runs on the `opus` model.

## Inputs
- Disposition recommendation (JSON per `schemas/rationalization/disposition-recommendation.schema.json`) — supplies `disposition`, `risk_tier`, `confidence`, and the underlying rationale. The governance record copies `application_id`, `disposition`, and `risk_tier` from this input verbatim.
- Portfolio scorecard (JSON per `schemas/rationalization/portfolio-scorecard.schema.json`) — provides dimension scores, methodology citation, and heat-map position for stakeholder packets.
- Client profile compliance config — `profiles/<client>/compliance.yaml` lists the frameworks in scope (fedramp, cato, nist-800-53, fisma, section-508, faa-policy, other) and the evidence bar for each.
- Client profile risk-classification — `profiles/<client>/risk-classification.yaml` supplies the tier definitions used to interpret `risk_tier` and set the required sign-off quorum.
- Client profile gates config — `profiles/<client>/gates.yaml` declares which governance gates (G-RR, G-04a, etc.) apply to this disposition and what their pass/fail rubric is.
- Application catalog entry (JSON per `schemas/discovery/application-catalog-entry.schema.json`) — resolves the business owner, data classification, and stakeholder contacts used for routing.

## Outputs
- `disposition-governance.json` per `schemas/rationalization/disposition-governance.schema.json`. Required top-level fields: `application_id`, `governance_date`, `disposition`, `risk_tier`, `sign_offs[]`, `compliance_gates[]`, `policy_overrides[]`, `required_sign_offs_met`, `governance_status`, `blocking_issues[]`, `evidence[]`. Tier-specific `allOf`+`if/then` rules enforce:
  - T1 → `sign_offs[]` must contain at least one `business-owner` AND one `security` role.
  - T2 → `sign_offs[]` must contain at least one of `business-owner` OR `security`.
  - T3 → `sign_offs[]` must have at least one entry of any role.
- Sign-off request packet — `assets/disposition-signoff-template.md` (stakeholder-facing markdown included in the evidence bundle).
- Override register — `assets/override-register-template.md` (only when `policy_overrides[]` is non-empty).

## Methodology
1. Load the disposition recommendation, portfolio scorecard, application catalog entry, and the active client profile's `compliance.yaml`, `risk-classification.yaml`, and `gates.yaml`. Copy `application_id`, `disposition`, and `risk_tier` from the recommendation into the governance record so the audit trail links 1:1.
2. Identify required stakeholders using `references/stakeholder-identification-heuristics.md`. Business-owner resolution falls back through the catalog's `business_owner`, application owner, portfolio-manager, and finally the profile's default escalation contact. Every resolved stakeholder must carry a `stakeholder_id` and a `stakeholder_role`.
3. Route approvers per `references/governance-gate-routing.md`. Evaluate every optional approver's trigger criteria (PII/PHI/CUI data classifications route the privacy officer; Tier 1 auto-adds security; Section 508 reviews demand accessibility sign-off) and promote each trigger-firing optional approver to required before packet assembly.
4. Evaluate every in-scope compliance gate declared by the profile's `compliance.yaml` and `gates.yaml`. For each gate emit `{gate_id, framework, status, evidence, waiver_justification?}`. Status is `pass` when the evidence satisfies the gate's rubric, `fail` when it does not, `waived` when an override is in play (a matching entry must exist in `policy_overrides[]` with a non-empty `waiver_justification`), or `not-applicable` when the gate does not apply to this disposition.
5. Verify the tier-specific sign-off quorum is reachable given the identified stakeholders. T1 requires business-owner+security. T2 requires business-owner OR security. T3 requires one of any role. If the quorum is not reachable (e.g., no security stakeholder exists for a T1 app), emit a blocking issue and stop before collecting signatures.
6. Assemble the sign-off request using `assets/disposition-signoff-template.md`. Include the scorecard methodology reference, heat-map position, disposition rationale, user-migration plan (for Retire/Replace/Consolidate), and the list of compliance-gate statuses so stakeholders sign against evidence rather than opinion.
7. Capture each sign-off as it arrives: `{stakeholder_id, stakeholder_role, decision, decision_date, rationale, citation}`. Rationales are required on every decision (`approved`, `rejected`, or `abstain`); `rejected` and `abstain` entries must include a citation to the dissenting evidence. Enforce the 5-business-day SLA — escalate to the portfolio manager on breach and log the escalation as evidence.
8. Register every policy override in the `policy_overrides[]` array per `references/override-and-exception-handling.md` and `assets/override-register-template.md`. Every override needs an explicit `policy_reference`, `justification`, `approver_role`, `decision_date`, and `citation`. Never accept an override without the risk-acknowledgement checkbox captured in the register.
9. Compute `required_sign_offs_met` from the schema's tier rules (T1: business-owner AND security; T2: business-owner OR security; T3: any role). Set `governance_status` accordingly: `approved` when all required sign-offs are `approved` and there are no blocking issues; `conditionally-approved` when one or more conditions (dated remediation, post-deploy review) are attached; `rejected` when any required sign-off is `rejected`; `pending-sign-off` while any required signature is outstanding.
10. Populate `blocking_issues[]` with any unresolved quorum gaps, failed compliance gates without waivers, rejected sign-offs, or overdue signatures. A non-empty `blocking_issues[]` MUST force `governance_status` to something other than `approved`. Emit `disposition-governance.json` and validate it against the schema before handing off to the Disposition Approval gate.

## Gotchas
- **Retirement requires explicit user migration plan.** You cannot retire an app without answering "where do the users go?" Every Retire/Replace/Consolidate governance record must reference the `user-impact-analysis.json.user_migration_path` for the same application.
- **Stakeholders may be outside IT.** Business owners, not just IT managers, must approve retirements. Claude tends to focus on technical stakeholders — force the catalog's `business_owner` into the required set.
- **Document dissenting opinions.** If a stakeholder rejects or abstains, log the objection and its resolution. This is an audit trail, not a filter — never drop a rejection from `sign_offs[]`.
- **Optional approvers are not skippable.** Evaluate every optional trigger in the routing table at packet-assembly time; promote to required when criteria fire (e.g., PII data classification auto-promotes the privacy officer; Tier 1 auto-promotes security).
- **Tier rules are quorum floors, not ceilings.** T1 must include business-owner AND security; adding more roles is fine. Shrinking below the floor is a schema-level failure that downstream gates will reject.
- **Policy overrides cost evidence, not just a justification.** Every entry in `policy_overrides[]` needs a `policy_reference`, a named `approver_role`, and a `citation` back to the signed risk acknowledgement. An override with only free-text justification is rejected by the validator.
- **`governance_status = approved` with non-empty `blocking_issues[]` is contradictory.** The schema tolerates it but the validator and Disposition Approval gate treat the combination as a failure. Downgrade to `conditionally-approved` or `pending-sign-off` instead.

## Quality Rules
- [ ] `application_id`, `disposition`, and `risk_tier` match the upstream `disposition-recommendation.json` exactly.
- [ ] `sign_offs[]` meets the tier quorum: T1 contains both `business-owner` AND `security`; T2 contains at least one of `business-owner` OR `security`; T3 contains at least one entry of any role.
- [ ] Every `sign_offs[]` entry has a non-empty `rationale` and a `citation` in `{artifact}:{section}:{finding-id}` format — rejections and abstentions included.
- [ ] Required stakeholders include both IT managers AND business owners for the application; optional approvers are promoted to required whenever their trigger criteria fire.
- [ ] Privacy officer sign-off is present whenever the application's data classification indicates PII, PHI, or CUI.
- [ ] Every framework declared in `profiles/<client>/compliance.yaml` appears as an entry in `compliance_gates[]` with status `pass`/`fail`/`waived`/`not-applicable`; `waived` entries carry a non-empty `waiver_justification` AND a matching `policy_overrides[]` row.
- [ ] `policy_overrides[]` entries each carry `override_id`, `policy_reference`, `justification`, `approver_role`, `decision_date`, and `citation` per `references/override-and-exception-handling.md`; no entry is recorded without a checked risk-acknowledgement box.
- [ ] `required_sign_offs_met` is `true` only when the tier quorum is met AND every required sign-off has `decision=approved`.
- [ ] `governance_status == "approved"` implies `blocking_issues[]` is empty; non-empty blockers downgrade the status to `conditionally-approved`, `rejected`, or `pending-sign-off`.
- [ ] Sign-off request uses the standard template from `assets/disposition-signoff-template.md`; override register (when present) uses `assets/override-register-template.md`.
- [ ] `disposition-governance.json` validates against `schemas/rationalization/disposition-governance.schema.json`.
- [ ] Sign-off SLA is measured from packet issuance; no response within 5 business days escalates to the portfolio manager and logs an evidence entry.

## Common Failure Modes
| Failure Mode | Symptom | Prevention |
|-------------|---------|------------|
| Technical-only stakeholders | Business owner not consulted; retirement approved but business users object post-facto | Identify and include business stakeholders from the catalog's `business_owner`, not just IT contacts |
| Missing user migration plan | Retirement approved but active users have no alternative; app cannot actually be retired | Require `user-impact-analysis.json.user_migration_path` to be referenced in evidence for every Retire/Replace/Consolidate record |
| Dissent suppressed | Stakeholder concerns not documented; audit finds gaps in decision trail | Log every `rejected`/`abstain` sign-off with the objection and its resolution, regardless of outcome |
| Evidence package incomplete | Sign-off requested without scoring results or impact analysis; stakeholders cannot make an informed decision | Validate evidence package completeness (scorecard, methodology, user-impact, compliance gates) before sending the request |
| T1 app missing security sign-off | Schema validator fails the governance record; Disposition Approval gate rejects the packet | Pre-check the tier quorum in Methodology step 5; block the run if the required roles cannot be resolved |
| Privacy officer not included for PII Retire | Retirement of a PII-handling app proceeds without privacy sign-off; downstream ATO or PIA review finds the gap | Auto-promote the privacy officer to required whenever data classification is Sensitive or higher, per `references/governance-gate-routing.md` |
| Override accepted without risk-acknowledgement checkbox | Data-driven recommendation overridden; auditors later cannot prove the approver accepted residual risk | Reject any override entry where the risk-acknowledgement checkbox is unchecked, per `references/override-and-exception-handling.md` |
| `governance_status` set to `approved` with open blockers | Gate downstream rejects the record; run must restart | Enforce the "approved implies empty blockers" invariant at emit time; downgrade status instead |
| Compliance gate waived without corresponding override | Auditor finds a waiver with no recorded decision-maker or justification | For every `compliance_gates[].status == "waived"`, require a matching `policy_overrides[]` entry by `policy_reference` |

## Phase 3 — ATLAS ChBA

> **Trace:** Source: `docs/phase3/phase2-commitments.md` §A.1 (per-system disposition table); gap matrix DEV-15, DEV-16 (in §5 Deviation Register) + RISK-3 (in §6 Build Risk Register). The 10-page narrative MUST reconcile two specific Phase 2 internal tensions; this skill emits that reconciliation as governance evidence.

### Phase 2 internal tensions to reconcile (P3-R67, P3-R70)

Two rows in `docs/phase3/phase2-commitments.md` §A.1 carry contradictions or gaps that the FAA evaluator will see if not preempted:

#### CHAPS missing-A6 reconciliation (DEV-16)

- **Tension:** P2 §A.1 row CHAPS — "No A6 file authored (only A1–A4 present)." The per-system A6 disposition document does not exist. SF1 Table 4 M11 calls CHAPS "Re-architect"; SF3 Table 3 says CHAPS is absorbed into S6 alongside MedXPress, AMCS, CPDSS.
- **Resolution narrative:** Phase 3 acknowledges the missing A6 in the 10-page narrative. The operative guidance is SF1 Table 4 M11 (Re-architect) + SF3 Table 3 (absorbed into S6). The Phase 3 governance record cites both sources and explicitly flags "no A6 disposition file in Phase 2."
- **Required governance evidence:**
  - `policy_overrides[]` entry with `policy_reference: "phase2-chaps-a6-missing"`, `justification: "CHAPS A6 disposition file not authored in Phase 2; SF1 Table 4 M11 + SF3 Table 3 are the operative sources."`, `approver_role: "Phase 2 author / capture lead"`.
  - `evidence[]` includes citations to both SF1 and SF3 anchors.
  - `blocking_issues[]` is empty after the override is registered (the missing A6 is acknowledged, not concealed).

#### DMS Retain vs Re-architect tension (DEV-15)

- **Tension:** P2 §A.1 row DMS — A6 says **Retain** (with mandatory P0 remediation sprint + Consolidate-inbound for IACRA DMSWebApp Y1). SF1 Table 4 M16 says **Re-architect** (with retire of the SSIS mirror). The two Phase 2 sources disagree on the disposition tag.
- **Resolution narrative:** The A6 is more specific. The reconciled disposition is **Retain + Refactor (cATO P0) + Consolidate-inbound (IACRA DMSWebApp Y1)**. The SF1 "Re-architect" label is a high-level disposition tag that resolves to Olympus-Refactor mapped to FAA-Retain. The SSIS mirror retire is consistent with both sources.
- **Required governance evidence:**
  - `disposition` field uses the FAA-5 vocabulary: `Retain`. Olympus-7 mapping is `Refactor` (cATO P0) per `references/disposition-mapping.md`.
  - `compliance_gates[]` includes per-source citation: SF1 Table 4 M16 + DMS A6 §1, §3.4, §7.
  - `blocking_issues[]` is empty after the reconciliation paragraph is captured in `references/p2-disposition-reconciliations.md`.

### Narrative pattern — how Phase 3 reconciles each tension

Maintain `references/p2-disposition-reconciliations.md` (NEW reference) with one section per tension. Section template:

```markdown
## <System> — <Phase 2 source A> vs <Phase 2 source B>

**Tension.** Source A says <X>. Source B says <Y>. (Cite both.)

**Resolution.** The operative guidance is <one source / a synthesis>. Reasoning: <one or two sentences>.

**Olympus-7 → FAA-5 mapping.** <How the seven Olympus dispositions resolve to the five FAA dispositions for this row.>

**Phase 3 evidence anchor.** <What artifact in the prototype proves the resolution: e.g., S6 absorption code, S7 OPA policy bundle, etc.>

**Citations.** [Source A]; [Source B]; [Phase 3 evidence].
```

This file is consumed by the new `cross-cutting/skills/phase-commitment-traceback` skill into Section 5 of the 10-page narrative ("Phase 2 internal tensions reconciled").

### Implementation-deviation logging (Phase 3 governance scope extension)

Beyond the 7-disposition governance scope, this skill now also tracks **implementation deviations** between Phase 2 commitments and Phase 3 reality. The new `cross-cutting/skills/implementation-deviation-log` (NEW skill, P1) is the canonical logger; this skill provides the *governance* trail (sign-off + evidence chain) over each deviation entry.

Required for Phase 3:
- [ ] CHAPS missing-A6 entry registered as a `policy_overrides[]` row.
- [ ] DMS Retain-vs-Re-architect entry registered as a reconciliation in `references/p2-disposition-reconciliations.md`.
- [ ] Each entry signed off by the Phase 2 capture lead (the role with the most context on the Phase 2 sources).
- [ ] The 10-page narrative cites both reconciliations explicitly (handed off to `phase-commitment-traceback`).

### Phase 3 acceptance signals

- [ ] `references/p2-disposition-reconciliations.md` exists and has sections for CHAPS and DMS.
- [ ] `disposition-governance.json` for any DMS or CHAPS row includes the reconciliation citation.
- [ ] Both reconciliations appear in the 10-page narrative §5 ("Phase 2 internal tensions reconciled").
- [ ] FAA evaluator inspecting the narrative finds explicit acknowledgement, not silent papering-over.

## Handoff Summary
When this skill completes, verify:
1. `disposition-governance.json` validates against `schemas/rationalization/disposition-governance.schema.json`, and `application_id`/`disposition`/`risk_tier` match the upstream `disposition-recommendation.json`.
2. Tier-specific sign-off quorum is met (T1: business-owner+security; T2: business-owner|security; T3: any role), and every required sign-off has `decision=approved` if `governance_status=="approved"`.
3. Every in-scope compliance gate from the profile is represented in `compliance_gates[]`, every `waived` status has a matching `policy_overrides[]` row, and `blocking_issues[]` is empty when `governance_status="approved"`.
4. Evidence package is complete (scorecard, methodology, user-impact, compliance-gate statuses) and every override is logged with justification, approver identity, and a checked risk-acknowledgement box.
5. **Phase 3:** CHAPS missing-A6 and DMS Retain-vs-Re-architect reconciliations are recorded; both surface in the 10-page narrative.

Then proceed to: the Disposition Approval gate (G-04a for Tier 1 dispositions), then to the approved disposition assembly line — Modernization for Rearchitect/Refactor, Disposition Execution for Retire/Replace/Consolidate — and wave planning (P1.4) for scheduling.
