# Skills

> AI behavior definitions that govern how agents perform specific tasks. Skills are the programmable control plane of Olympus — changing a skill changes factory behavior without altering pipeline structure.

---

## Purpose

Define, manage, and evolve the SKILL.md files that instruct AI agents on how to perform specific tasks within Olympus. Skills are the bridge between process (what to do) and execution (how to do it). They are the primary lever for improving factory quality over time — the Governance line extracts patterns from completed waves and encodes them as skill refinements.

---

## What Is a Skill?

A skill is a structured definition (SKILL.md) that tells an AI agent:
- **What** to produce (output format, schema, quality criteria)
- **How** to approach the task (methodology, patterns, constraints)
- **What to reference** (domain knowledge, standards, examples)
- **How to validate** (deterministic checks, test scripts)

Skills are not code — they are instructions. The same skill can be executed by different agent implementations (Claude, GPT, Gemini, open-source models). This separation is critical: skills define factory behavior; models provide the execution capability.

---

## Skill Anatomy

```
skills/<skill-name>/
├── SKILL.md              # Core behavior definition
├── references/           # Domain knowledge, standards, examples
├── scripts/              # Deterministic validation scripts (model-independent)
├── assets/               # Output templates, schema examples, config templates
└── config.json           # Per-app/per-wave parameterization
```

Not every skill requires every component. Minimal skills have only SKILL.md. Enriched skills include references, scripts, and assets for higher reliability and consistency.

### SKILL.md Structure

Every SKILL.md follows a consistent structure:

```markdown
# Skill: [Skill Name]

## Purpose
[What this skill does and why]

## Trigger
[When/where this skill is invoked in the assembly line]

## Inputs
[What the agent receives — artifact references, configuration, context]

## Outputs
[What the agent must produce — format, schema, quality criteria]

## Methodology
[Step-by-step approach the agent should follow]

## Constraints
[Hard requirements — compliance standards, schema adherence, traceability rules]

## Quality Criteria
[How to determine if the output is good enough — measurable, testable]

## Validation
[Deterministic checks — scripts or schema validators that verify output quality]

## References
[Links to domain knowledge, standards, examples in the references/ directory]

## Variants
[Technology-specific or archetype-specific variants, if any]

## Anti-Patterns
[Common mistakes to avoid — extracted from Governance line pattern analysis]
```

---

## Skill Categories

| Category | Skills | Purpose |
|----------|:------:|---------|
| **Legacy Analysis** | 5 | Analyze legacy code: architecture mapping, business rule extraction, dependency analysis, data lineage, tech debt assessment |
| **Library & API Reference** | 8 | Encode domain knowledge: EA standards, cATO/OSCAL compliance, design systems, coding standards, Zero Trust patterns |
| **Code Scaffolding & Templates** | 11 | Generate code and specs: extraction, module design, API specification, data modeling, TDD generation, batch extraction |
| **Product Verification** | 5 | Verify quality: parity verification, accessibility checking, safety-critical verification, cross-validation |
| **Data Fetching & Analysis** | 4 | Analyze data: application analysis, dependency mapping, TCO calculation, redundancy detection |
| **Business Process & Automation** | 5 | Orchestrate processes: wave status reporting, escalation handling, gate review packaging, disposition validation |
| **Code Quality & Review** | 4 | Review code: adversarial review, code standards enforcement, traceability checking |
| **CI/CD & Deployment** | 4 | Deploy and operate: deployment orchestration, parallel run monitoring, traffic shifting |
| **Runbooks & Operations** | 4 | Sustain operations: incident response, patch assessment, SLA breach investigation, change conflict resolution |
| **Infrastructure Operations** | 4 | Manage infrastructure: environment cleanup, factory health checking, capacity management |
| **Meta-Tooling** | 3 | Build skills: skill creation from patterns, skill validation, legacy skill templates |
| **Cross-Cutting** | 5 | Shared concerns: documentation rendering, security posture analysis, migration strategy advising |

**59 core skills** (SKILL.md files in `cross-cutting/skills/`) + 3 client-specific skills in `profiles/faa/skills/`. **62 total.**

---

## Skill Registry

The skill registry is the authoritative index of all available skills:

```yaml
# skills/registry.yaml
skills:
  - name: "extraction"
    category: "Code Scaffolding & Templates"
    version: "1.2.0"
    enrichment: "Full"
    used_by: ["Modernization — Extract"]
    variants:
      - name: "extraction-cobol"
        variant_for: {language: "COBOL"}
      - name: "extraction-coldfusion"
        variant_for: {language: "ColdFusion"}
      - name: "extraction-java"
        variant_for: {language: "Java"}
    metrics:
      invocations_total: 142
      gate_pass_rate: 0.89
      avg_quality_score: 0.91

  - name: "parity-verifier"
    category: "Product Verification"
    version: "2.0.1"
    enrichment: "Full"
    used_by: ["Validation — Stream 1"]
    variants: []
    metrics:
      invocations_total: 87
      gate_pass_rate: 0.94
      avg_quality_score: 0.96
```

The registry supports:
- **Lookup by name** — find a specific skill
- **Lookup by category** — find all skills in a category
- **Lookup by line/step** — find skills used at a specific point in the pipeline
- **Lookup by variant criteria** — find the right variant for a given language/archetype
- **Enrichment status filtering** — find skills needing enrichment

---

## Skill Enrichment Levels

Skills range from minimal (SKILL.md only) to fully enriched:

| Level | Contents | Reliability | When Sufficient |
|-------|----------|-------------|-----------------|
| **Minimal** | SKILL.md only | Depends on model capability | Exploratory tasks, low-stakes analysis |
| **Partial** | SKILL.md + references | Better domain grounding | Standard analysis and documentation tasks |
| **Full** | SKILL.md + references + scripts + assets + config | Highest: deterministic validation, templated output | Code generation, compliance artifacts, gate-critical outputs |

### Enrichment Priority

The Governance line tracks enrichment status and prioritizes enrichment investment based on:

| Factor | Weight | Rationale |
|--------|:------:|-----------|
| Invocation frequency | High | High-frequency skills have the most leverage |
| Gate failure rate | High | Skills causing gate failures need enrichment most |
| Escalation rate | Medium | Skills causing escalations waste human time |
| Output variability | Medium | Inconsistent outputs signal need for better constraints |
| Risk tier exposure | Medium | Skills used on Tier 1 apps need highest reliability |

---

## Skill Composition

Skills are composable — complex tasks can chain multiple skills:

### Sequential Composition

Output of one skill feeds input of the next:

```
extraction → cross-validation → module-design → api-specification → tdd-generation
```

### Parallel Composition

Multiple skills run concurrently on different aspects:

```
┌─ accessibility-checker ─┐
│─ security-scan-review  ─│─→ gate-review-package
└─ parity-verifier       ─┘
```

### Conditional Composition

Skill selection based on app characteristics:

```
if archetype == "batch":
    use: batch-extraction
elif archetype == "api":
    use: api-extraction
else:
    use: extraction  # default web app extraction
```

### Variant Selection

Technology-specific variants of the same base skill:

```
base: extraction
variants:
  - extraction-cobol     (when language == COBOL)
  - extraction-java      (when language == Java)
  - extraction-coldfusion (when language == ColdFusion)
  - extraction-python    (when language == Python)
```

Variant selection is automatic based on application metadata from Discovery.

---

## Skill Lifecycle

```
Create → Validate → Register → Execute → Evaluate → Evolve
  ↑                                                    │
  └────────────────────────────────────────────────────┘
```

### 1. Creation

Skills are created from three sources:

| Source | How | Quality |
|--------|-----|---------|
| **Manual authoring** | Human expert writes SKILL.md with references | High (expert knowledge) |
| **Pattern extraction** | Governance line `skill-builder` analyzes successful factory runs | Medium (needs validation) |
| **Variant derivation** | New variant created from base skill for a new technology | Medium (inherits base quality) |

### 2. Validation

Before a skill enters the registry, it must pass structural validation:

| Check | What's Validated |
|-------|-----------------|
| Structure | SKILL.md follows the required section structure |
| Output schema | Output format is defined and parseable |
| References | All referenced files exist in the skill directory |
| Scripts | Validation scripts execute without error on sample inputs |
| Conflict check | No conflicting skill names or overlapping variant criteria |

The `skill-validator` meta-skill performs this validation.

### 3. Registration

Validated skills are added to the registry with version tracking:

- **Semantic versioning** — major (breaking output changes), minor (new capabilities), patch (refinements)
- **Registry entry** — name, category, version, enrichment level, used-by, variants, metrics
- **Activation** — newly registered skills are available to the next wave

### 4. Execution

Skills are invoked by agents within assembly line activities:

1. Orchestrator dispatches activity to agent
2. Agent receives skill reference + input artifacts
3. Agent loads SKILL.md + references + config
4. Agent produces output following skill methodology
5. Validation scripts run against output (if present)
6. Output committed to Git branch

### 5. Evaluation

Skill effectiveness is tracked per invocation:

| Metric | Source | Purpose |
|--------|--------|---------|
| Gate pass rate | Gate results | Did the skill's output pass the quality gate? |
| Iteration count | Ralph Loop metrics | How many iterations did the skill need? |
| Escalation rate | Escalation records | Did the skill cause human escalation? |
| Output consistency | Cross-run comparison | Are outputs consistent across similar inputs? |
| Cost | Token/API metrics | How expensive is each invocation? |

### 6. Evolution

Skills evolve through the Governance line's pattern extraction:

| Evolution Type | Trigger | Example |
|---------------|---------|---------|
| **Refinement** | Gate failure pattern | "Add constraint: always include error handling for null aggregate roots" |
| **Anti-pattern addition** | Repeated Ralph Loop failures | "Anti-pattern: don't generate monolithic service classes for bounded contexts with >5 aggregates" |
| **Reference enrichment** | Successful pattern from completed wave | Add new code template to references/ |
| **Variant creation** | New technology encountered | Create extraction-rust variant from base extraction |
| **Deprecation** | Skill superseded by better approach | Mark as deprecated, point to replacement |

---

## Skill-to-Line Mapping

| Assembly Line | Step/Activity | Skills |
|--------------|--------------|--------|
| **Discovery** | Catalog | `legacy-architecture-mapper`, `dependency-mapper` |
| **Discovery** | 4-Pass Analysis | `analyze-application`, `extraction`, `accessibility-checker` |
| **Rationalization** | Redundancy | `analyze-portfolio-redundancy`, `redundancy-analyzer` |
| **Rationalization** | Disposition | `disposition-recommender`, `tco-analyzer` |
| **Rationalization** | Governance | `disposition-governance` |
| **Architecture** | Cloud Patterns | `ea-compliance`, `migration-strategy-advisor` |
| **Architecture** | Security | `cato-compliance`, `security-posture-analyzer` |
| **Architecture** | Design System | `design-system`, `accessibility-checker` |
| **Architecture** | Integration | `event-contract`, `api-contract-validator` |
| **Architecture** | AI/ML | `ai-ml-integration` |
| **Data** | Domain Discovery | `data-domain-patterns`, `data-mesh-architecture` |
| **Data** | Decomposition | `shared-db-decomposition`, `decomposition-patterns` |
| **Data** | Data Products | `data-product-specification` |
| **Modernization** | Extract | `extraction` (+ variants), `cross-validation`, `batch-extraction` |
| **Modernization** | Design | `module-design`, `api-specification`, `data-modeling`, `batch-design` |
| **Modernization** | Generate | `tdd-generation`, `batch-generation`, `test-validation`, `adversarial-review` |
| **Modernization** | Gate Submission | `gate-review-package` |
| **Modernization** | Escalation | `escalation-handler` |
| **Disposition Execution** | All dispositions | `legacy-decommission`, `change-mgmt-coordinator`, `tco-analyzer` |
| **Validation** | Parity | `parity-verifier`, `acceptable-divergences` |
| **Validation** | Compliance | `cato-compliance`, `cato-evidence-validator`, `security-scan-review`, `api-contract-validator` |
| **Validation** | Accessibility | `accessibility-checker`, `design-system` |
| **Validation** | Safety | `safety-critical-verifier`, `traceability-checker` |
| **Deployment** | Deploy | `deploy-modernized-app`, `traffic-shift` |
| **Deployment** | Parallel Run | `parallel-run-monitor` |
| **Deployment** | Decommission | `legacy-decommission`, `environment-cleanup` |
| **Deployment** | Cost | `tco-analyzer` |
| **Sustainment** | O&M | `incident-response`, `patch-assessment`, `sla-breach-investigation` |
| **Sustainment** | Coordination | `change-conflict-resolver` |
| **Sustainment** | AIOps | `cost-anomaly-investigation` |
| **Governance** | Health | `portfolio-health-check`, `factory-health-check` |
| **Governance** | Capacity | `factory-capacity-manager`, `wave-status-report` |
| **Governance** | Patterns | `skill-builder`, `adversarial-review` |
| **Governance** | Drift | `traceability-checker`, `accessibility-checker` |

---

## Configuration

Skills accept per-app and per-wave configuration through `config.json`:

```json
{
  "skill": "extraction",
  "version": "1.2.0",
  "config": {
    "language": "Java",
    "archetype": "web",
    "risk_tier": "Tier 2",
    "traceability_threshold": 0.98,
    "output_format": "yaml",
    "client_profile": "faa",
    "additional_constraints": [
      "Include FAA Order 1370.121 security controls",
      "Flag NAS-related business rules with safety annotation"
    ]
  }
}
```

Configuration cascades: **client profile defaults → wave overrides → app-specific overrides**.

---

## Dashboard

| Widget | Data Source | Visualization |
|--------|-----------|---------------|
| Skill registry | Registry YAML | Searchable table with enrichment badges |
| Enrichment coverage | Registry metrics | Pie chart (Full / Partial / Minimal) |
| Top skills by usage | Invocation metrics | Bar chart — most-invoked skills |
| Skills needing attention | Gate failure + escalation rates | Alert list — skills with declining quality |
| Skill evolution timeline | Version history | Timeline — when skills were created/refined |
| Pattern-to-skill pipeline | Governance extraction | Funnel — patterns observed → extracted → skills created |
