---
name: pilot-certification-dashboard-spec
description: >
  Specify the §6.1.1.1.1.2 pilot-facing dashboard for the FAA ATLAS Phase 3
  prototype: real-time certification status, completed steps, pending actions,
  required inputs/validations, role-keyed views (applicant, AME, CFI, DPE,
  FAA-CAMI reviewer, registry admin), USWDS pattern composition, SSE-driven
  updates from the workflow FSM service, and WCAG 2.1 AA / Section 508
  compliance. Use during Phase 3 build day 4. Triggers on dashboard spec,
  pilot certification dashboard, role-based UI, USWDS step indicator, real-time
  status, or §6.1.1.1.1.2 dashboard mentions.
agent: sonnet
enrichment_level: Full
tags:
  - dashboard-ux
  - accessibility-uswds
  - target-arch-design
  - codegen-frontend
allowed-tools:
  - Read
  - Write
  - Grep
---

# Pilot Certification Dashboard Specification

## Purpose
Author the dashboard specification that `react-page-generation` consumes to
emit the role-keyed, real-time pilot-certification dashboard. The dashboard is
the single most evaluator-visible surface in the Phase 3 oral demo: it appears
in every one of the five demo journeys (D1–D5 in build-demo-skills-plan.md
§2), it is the canonical answer to P3-R26..R32, and it carries the headline
"enter once, reuse downstream" evidence (P3-R23a, P3-R65).

This skill writes the contract. Implementation is downstream
(`react-page-generation` consumes the JSON output; `uswds-role-layout-library`
composes the USWDS patterns; `pilot-certification-workflow-fsm` publishes the
SSE events the dashboard subscribes to).

## When to use

Invoke this skill on Phase 3 build day 4, **after** the workflow FSM
(`pilot-certification-workflow-fsm`) and the API contracts
(`api-specification`) for S5 Shared Case and S8 Registry Canonical exist, and
**before** `react-page-generation` runs. Re-invoke whenever:

- A new role is added (e.g., FAA inspector for Stage 16 §61.15 review) —
  rerun to emit the new role-keyed view spec.
- The 22-stage J08 sequence changes (it should not for Phase 3, but
  defensive).
- The FSM event vocabulary changes — the SSE wiring spec must stay in lockstep.

## Inputs

```yaml
journey:
  source: docs/phase3/phase2-commitments.md  # §D.1, 22 stages
  phase3_implemented_stages: [1, 2, 3, 4, 5, 9, 10, 11, 12]  # the 5 demo journeys + setup stages
roles:
  source: docs/phase3/phase2-commitments.md  # §E, 12 roles
  phase3_in_scope:
    - applicant            # primary; appears in every journey
    - ame                  # Stages 4, 5, 19
    - cfi                  # Stages 8, 9, 18, 20
    - dpe                  # Stages 9, 10, 11, 12
    - faa_cami_reviewer    # Stages 6, 19
    - registry_admin       # background, S8 / S11
fsm_events:                # event names this dashboard subscribes to
  - WorkflowTransition       # from pilot-certification-workflow-fsm
  - CertStatusChanged
  - AirmanChanged
  - DesigneeCLOAChanged
  - MedicalCertStatusChanged
  - AuditEvent
api_contracts:
  - openapi/s5-shared-case.yaml
  - openapi/s8-registry-canonical.yaml
  - openapi/s6-medical-readiness.yaml
  - openapi/s9-digital-credential.yaml
  - openapi/s11-reporting.yaml
realtime_transport:
  primary: sse                # Server-Sent Events from the Express SSE route (Node 20 + Express + TypeScript per docs/phase3/local-first-architecture.md §2)
  fallback: polling           # 10s interval if SSE connection fails
  reasoning: |
    SSE is one-way and survives FAA-typical proxy stacks better than WebSocket.
    Phase 3 has no client→server push needs the dashboard cannot satisfy with
    REST POST. WebSocket is deferred to Phase 4 if collaboration features land.
uswds_version: 3.x
accessibility_target: WCAG_21_AA  # Section 508 = WCAG 2.0 AA, but Phase 2 commits 2.1 AA
```

## Outputs

| Path | Purpose |
|------|---------|
| `specs/dashboard/applicant.json` | Applicant dashboard widget tree, data bindings, role-keyed nav. |
| `specs/dashboard/ame.json` | AME console spec. |
| `specs/dashboard/cfi.json` | CFI endorsement view spec. |
| `specs/dashboard/dpe.json` | DPE checkride view spec. |
| `specs/dashboard/faa-cami-reviewer.json` | FAA-CAMI deferral queue spec. |
| `specs/dashboard/registry-admin.json` | Registry admin / MDM queue spec. |
| `specs/dashboard/component-contract.ts` | Shared TypeScript types every dashboard consumes. |
| `specs/dashboard/uswds-pattern-map.md` | Per-role USWDS pattern composition (header / banner / step indicator / summary box / alert / button group / side nav / process list). |
| `specs/dashboard/a11y-checklist.md` | Per-widget WCAG 2.1 AA criteria with test method (axe-core rule + manual screen-reader script). |
| `specs/dashboard/sse-wiring.md` | The Postgres LISTEN/NOTIFY → Node/Express SSE → React store contract. |
| `specs/dashboard/fixtures/*.json` | Seed-data fixtures for each role view, used by `frontend-parity-test-generator`. |
| `specs/dashboard/wireframes/*.mmd` | Mermaid block diagrams for each role view (one per role). |

## Procedure

1. **Build the role × stage matrix.** From J08 §D.1 + §D.2, derive which
   stages each role participates in. The matrix anchors which widgets appear
   in which role view. Phase 3 in-scope stages are 1–12 (per build plan §2);
   stages 13–22 are summarized but not interactive.

2. **Define the canonical widget vocabulary.** The dashboard composes from
   exactly these widgets — no ad-hoc UI. Each widget binds to a USWDS pattern.

   | Widget | USWDS pattern | Bound API/event | Roles using it |
   |---|---|---|---|
   | `CertificationProgressTimeline` | Step Indicator (`usa-step-indicator`) | `GET /api/v1/cases/{ftn}` + `WorkflowTransition` SSE | applicant, ame, cfi, dpe |
   | `CompletedStepsCard` | Summary Box (`usa-summary-box`) | derived from progress timeline | applicant |
   | `PendingActionsInbox` | Process List (`usa-process-list`) | `GET /api/v1/cases/{ftn}/pending-actions` | applicant, ame, cfi, dpe, cami |
   | `RequiredInputsChecklist` | Form / Process List | `GET /api/v1/forms/{form_id}/required-fields?case={ftn}` | applicant |
   | `RealTimeStatusBanner` | Site Alert (`usa-site-alert`) | `CertStatusChanged` SSE | all roles |
   | `CurrencyClocks` | Card grid + Tag (`usa-tag`) | `GET /api/v1/airman/{ftn}/currency` | applicant (Stage 13 carry-forward summary) |
   | `ActiveCaseCard` | Card (`usa-card`) | `GET /api/v1/cases/{ftn}/active` | applicant, ame, cfi, dpe |
   | `RoleKeyedNav` | Side Nav (`usa-sidenav`) + Header (`usa-header --extended`) | role from JWT | all |
   | `EvidenceDrillDown` | Collection (`usa-collection`) + Modal | `GET /api/v1/cases/{ftn}/evidence/{evidence_id}` | applicant (read), reviewer roles (read+annotate) |
   | `AnnouncementsBanner` | Banner (`usa-banner`) | static (FAA gov banner) | all |
   | `IdentityVerificationStatus` | Tag + Tooltip | `GET /api/v1/identity/{ftn}/proofing-record` | applicant |
   | `DigitalCredentialViewer` | Card with QR | `GET /api/v1/credentials/{credential_id}` | applicant |

   Reject any view that introduces a widget not in this list. New widgets
   require an explicit edit to this skill, not a one-off in `react-page-generation`.

3. **Author the per-role spec JSON.** Use this canonical shape:

   ```json
   {
     "role": "applicant",
     "route": "/dashboard",
     "page_title": "My Pilot Certification — Dashboard",
     "skip_link_target": "#main-content",
     "uswds_layout": "extended-header-with-side-nav",
     "primary_nav": [
       { "label": "Dashboard", "route": "/dashboard", "active_match": "exact" },
       { "label": "Applications", "route": "/applications" },
       { "label": "Medical", "route": "/medical" },
       { "label": "Credentials", "route": "/credentials" }
     ],
     "widgets": [
       { "id": "active-case", "type": "ActiveCaseCard", "grid": { "col_span": 12 }, "data_source": { "api": "/api/v1/cases/active", "sse_subscriptions": ["WorkflowTransition"] } },
       { "id": "progress", "type": "CertificationProgressTimeline", "grid": { "col_span": 12 }, "data_source": { "api": "/api/v1/cases/{caseId}", "sse_subscriptions": ["WorkflowTransition"] } },
       { "id": "pending", "type": "PendingActionsInbox", "grid": { "col_span": 6 }, "data_source": { "api": "/api/v1/cases/{caseId}/pending-actions", "sse_subscriptions": ["WorkflowTransition"] } },
       { "id": "required", "type": "RequiredInputsChecklist", "grid": { "col_span": 6 }, "data_source": { "api": "/api/v1/forms/{currentFormId}/required-fields", "sse_subscriptions": [] } },
       { "id": "currency", "type": "CurrencyClocks", "grid": { "col_span": 12 }, "data_source": { "api": "/api/v1/airman/{ftn}/currency", "sse_subscriptions": ["CertStatusChanged"] } },
       { "id": "credential", "type": "DigitalCredentialViewer", "grid": { "col_span": 6 }, "data_source": { "api": "/api/v1/credentials/active", "sse_subscriptions": ["CertStatusChanged"] } }
     ],
     "auth": {
       "required_role": "applicant",
       "required_scopes": ["read:own-case", "read:own-credential"],
       "redirect_unauthorized": "/login"
     },
     "a11y": {
       "skip_link": true,
       "focus_on_route_change": "h1#page-title",
       "live_region_for": ["progress", "pending", "currency"],
       "min_contrast_ratio": 4.5
     }
   }
   ```

   The other five role specs reuse the same shape with role-appropriate
   widgets. AME view replaces `CurrencyClocks` with a deferral queue;
   CFI view foregrounds the `EvidenceDrillDown` for endorsement evidence;
   DPE view foregrounds the `PendingActionsInbox` filtered to checkride
   tasks; FAA-CAMI view foregrounds the deferral queue with SLA timers;
   registry-admin view is the MDM disposition queue (auto-merge / self-service /
   staff adjudication, per phase2-commitments §B.4 / SF3 §3.1).

4. **Write the component contract.** `specs/dashboard/component-contract.ts`
   defines the TypeScript types every dashboard consumes — Case, PendingAction,
   RequiredInput, CurrencyClock, AirmanIdentity, MedicalCertStatus,
   DigitalCredential. Each type has a JSDoc comment naming its source-of-truth
   service (S5, S8, S6, S9, S11). No type may transitively reference another
   service's internal types; cross-service references go through the
   canonical-entity types only (`airman.identity`, `medical.cert-status`,
   `airman.certification`, `activity.event`, `audit.event`).

5. **Author the USWDS pattern map** at `specs/dashboard/uswds-pattern-map.md`.
   For every widget × role pair, document:
   - The exact `@trussworks/react-uswds` component to import.
   - Which USWDS variants apply (`info` / `warning` / `error` / `success` for
     `Alert`; `lg` / default for `StepIndicator`).
   - The minimum required props for keyboard-accessible operation.
   - The dark-mode / high-contrast handling (USWDS supports `data-theme`).

6. **Author the a11y checklist** at `specs/dashboard/a11y-checklist.md`. One
   row per widget × WCAG 2.1 AA success criterion that applies. Columns:
   widget, criterion (e.g., "1.4.3 Contrast"), test method (axe-core rule
   ID OR manual screen-reader script), expected result, owner. Include the
   following manual scripts (axe-core cannot detect them):
   - **Focus order on route change**: navigate from `/applications` to
     `/dashboard`, assert focus lands on `<h1 id="page-title">`.
   - **Live region announcement**: trigger a `WorkflowTransition` event,
     assert NVDA reads "Stage 3 medical intake — 3 of 12 complete" within
     3 seconds.
   - **Keyboard-only checkout**: complete the entire D2 (medical intake)
     journey using only Tab, Shift+Tab, Enter, Space, Arrow keys.
   - **Skip-link first**: assert the skip link is the first focusable
     element on every page.

7. **Author the SSE wiring spec** at `specs/dashboard/sse-wiring.md`. The
   contract is:

   ```
   PostgreSQL trigger ON write to (cases, certifications, medical_cert_status, designee_cloa, audit_events)
        ↓ NOTIFY <event_name>, JSON payload
   Node/Express subscriber (single-process, per-instance `pg` LISTEN; payload
        contains ftn, role-affected, payload-shape-version, event-id)
        ↓ /api/v1/events/sse?role=<role>&ftn=<ftn> with text/event-stream
   React store (event subscriber per role view; debounced refetch on event id)
        ↓ optimistic UI update with toast if event arrives between fetches
   ```

   Document:
   - The Postgres trigger function template (one trigger per canonical entity
     table; the FSM emits via stored procedure not application code).
   - The Express route structure (one route per role; per-connection role
     authorization via JWT scope check at request time).
   - Heartbeat and reconnection: 30s heartbeat; client retries with
     exponential backoff capped at 60s; falls back to polling at
     `/api/v1/events/since/{event_id}` if SSE disconnects 3× consecutively.
   - The fallback contract: polling endpoint must return identical payload
     shape to SSE so the React store's event handler doesn't branch.

8. **Generate fixture data**. For each role spec, write a JSON fixture
   under `specs/dashboard/fixtures/<role>.json` modeling a realistic case
   in mid-flight. Fixture data must round-trip through the OpenAPI types
   (validate via the `api-contract-validator` skill output). The
   fixtures power the Storybook stories and Playwright tests downstream
   (closes P3-R88: FAA can run the dashboard offline against fixtures).

9. **Emit the role-view wireframes** at `specs/dashboard/wireframes/<role>.mmd`.
   Use Mermaid `block-beta` syntax. Each wireframe is a single block diagram
   showing the grid placement of widgets at desktop (1280+ px) and the
   stack order at mobile (<768 px). Annotate the focus order in comments.

## Validation / acceptance criteria

- [ ] One spec JSON per role in `roles.phase3_in_scope` — no missing roles,
      no surprise roles.
- [ ] Every widget referenced in any spec is listed in the canonical widget
      vocabulary table (procedure step 2).
- [ ] Every `data_source.api` resolves to an endpoint in the listed OpenAPI
      contracts; every `sse_subscriptions` element is in `fsm_events`.
- [ ] `a11y-checklist.md` has at least one row for every widget × every
      WCAG 2.1 AA success criterion that applies (1.1.1, 1.3.1, 1.4.3, 2.1.1,
      2.4.3, 2.4.7, 3.2.2, 3.3.1, 3.3.3, 4.1.2 minimum).
- [ ] No widget displays PHI fields outside the AME, FAA-CAMI, or applicant
      role views. Per Phase 2 §B.4, S6 exposes only `medical.cert-status`
      to S1; the other roles must respect that boundary.
- [ ] SSE wiring spec names the exact Postgres NOTIFY channel name per
      event in `fsm_events`.
- [ ] Fixture JSON validates against the OpenAPI schemas listed in
      `api_contracts`.
- [ ] Component contract `.ts` file compiles under `tsc --noEmit --strict`
      with zero `any` types.
- [ ] Each role's primary nav has between 3 and 5 items — over 5 forces
      a Mega Menu, which is out of USWDS Phase-3 scope.
- [ ] Every spec sets `auth.required_role`; missing → fatal.
- [ ] The duplicate-data-entry pattern (P3-R23a) is wired: at least one
      widget in the applicant spec sources a field via `prefill_from`
      pointing at S8 (FTN single-write authority), proving "enter once,
      reuse downstream."

## Examples

### Example 1: applicant view widget grid (D1 — identity enrollment, Stage 2)

```
Desktop (12-col grid):
+------------------------------------------+
| AnnouncementsBanner (12)                 |
+------------------------------------------+
| RoleKeyedNav | main-content              |
| (3)          | +------------------------+|
|              | | ActiveCaseCard (12)    ||
|              | +------------------------+|
|              | | ProgressTimeline (12)  ||
|              | +------------------------+|
|              | | Pending(6) |Required(6)||
|              | +------------+-----------+|
|              | | Currency (12)          ||
|              | +------------------------+|
|              | | DigitalCredential (6)  ||
|              | +------------------------+|
+------------------------------------------+

Focus order: skip-link → AnnouncementsBanner → RoleKeyedNav (active) → h1
  → ActiveCaseCard primary CTA → ProgressTimeline first interactive step
  → PendingActionsInbox first row → RequiredInputsChecklist first input
  → CurrencyClocks (presentational, skipped) → DigitalCredentialViewer view-button
```

### Example 2: AME console widget grid (D3 — exam, Stage 5)

```
+--------------------------------------------------------+
| RoleKeyedNav (3) | DeferralQueue (9 — primary)         |
|                  | +-----------------------------------+|
|                  | | ActiveCaseCard for selected (12) ||
|                  | +-----------------------------------+|
|                  | | ProgressTimeline (case)     (12) ||
|                  | +-----------------------------------+|
|                  | | EvidenceDrillDown (8500-8 form)(8)||
|                  | +-----------------------------------+|
|                  | | PendingActionsInbox (filtered)(4)||
+--------------------------------------------------------+

PHI handling: form fields surfaced in EvidenceDrillDown read from S6
medical.private; the parent dashboard never proxies these fields. Network
panel during demo shows the call going directly from the AME-role token
holder to S6 — not via S5.
```

### Example 3: SSE event flow for a J08 Stage 3 medical intake submit

```
1. Applicant submits Form 8500-8 in S2 Guided Intake.
2. S2 writes to cases.case_state and inserts a row into activity.event.
3. Postgres trigger fn_emit_workflow_transition fires NOTIFY workflow_transition
   { ftn, role_affected: ["applicant", "ame"], stage: 3, payload_v: 1 }.
4. Node/Express subscriber dispatches to all SSE connections matching ftn or role_affected.
5. Applicant browser receives event, debounces, refetches /api/v1/cases/{ftn}.
6. ProgressTimeline re-renders Stage 3 → "complete"; ActiveCaseCard primary CTA
   transitions to "Schedule AME exam"; PendingActionsInbox adds new row
   "Schedule AME appointment".
7. AME's pending-actions inbox (if AME currently logged in for any case)
   refetches to reflect new pending appointment slot — but only if the
   case_id is in their assigned-AME list (RBAC enforced server-side).
```

## Gotchas

- **The dashboard is the duplicate-entry-elimination headline.** Three of the
  five demo journeys (D1, D2, D5) hinge on the dashboard demonstrating
  "enter once, reuse downstream." The applicant spec MUST surface at least
  one prefill demonstrably populated from S8 (e.g., FTN visible on the
  Active Case Card without the applicant having entered it). Dropping this
  collapses P3-R23a evidence.
- **Roles are JWT scopes, not booleans.** Phase 2 §E commits to FICAM/PIV/CAC
  + Login.gov; the dashboard receives an OIDC token with `roles` and
  `scopes` claims. Every spec must enumerate `required_scopes`, not just
  `required_role`. A DPE has scope `signoff:checkride` but not
  `read:medical-private` — the dashboard has to refuse to fetch PHI even
  if a DPE has the role.
- **PHI never crosses the medical.cert-status boundary.** Phase 2 §B.4
  mandates that S6 expose only `CertValid (bool)` + `expDate` to S1.
  The applicant dashboard MUST consume that boundary type, not the
  underlying PHI. Showing the AME the raw 8500-8 form in S6 is fine;
  showing the applicant their own raw 8500-8 form on the dashboard is
  also fine (it's their own PHI); showing it on the DPE dashboard is a
  PHI leak — the DPE never sees medical findings, only `medical.cert-status`.
- **SSE, not WebSocket.** WebSocket adds bidirectional plumbing the dashboard
  doesn't need. SSE survives FAA proxy stacks (no Upgrade header
  intermediation) and degrades gracefully to polling. WebSocket is a
  Phase 4 concern when collaboration features land.
- **USWDS Step Indicator caps at 8 stages by convention.** Phase 3 implements
  J08 stages 1–12. Use a `lg` Step Indicator with abbreviated labels
  ("ID", "Med", "AME", "Knowledge", "Train", "CFI", "DPE", "Issuance").
  Detail labels appear on hover or via the screen-reader-only label.
- **Fixture data is real-shaped, not real-content.** Fixtures use synthetic
  airmen (FTN A0000001..A0000099), synthetic AME / CFI / DPE names. Don't
  import real GFI data into fixtures — that's the `gfi-integration-stub-generator`
  skill's job at the adapter layer, and it must be opt-in.
- **The "real-time" claim is bounded to ≤ 3s.** P3-R27 says "real-time"; the
  P2 J08 stage 14 "address change propagation" sets the bar at "Registry ✓ 2s,
  MedXPress ✓ 3s, Fulfillment ✓ 5s, PRD ✓ 8s." The dashboard a11y checklist
  should test that a `WorkflowTransition` is reflected on the screen within
  3 seconds of the underlying DB write — that's the demoable bar.

## References

- Closes Phase 3 requirements: P3-R14 (FE UI for Private Pilot certification),
  P3-R15 (role-based interactions), P3-R26 (pilot-facing dashboard exists),
  P3-R27 (real-time status), P3-R28 (completed steps), P3-R29 (pending
  actions), P3-R30 (required inputs/validations), P3-R31 (role-based info),
  P3-R32 (live data, not mocked).
- Phase 2 grounding:
  - §B.1 Layer 1 — "Unified Pilot Dashboard" capability anchor.
  - §B.4 — PHI boundary at `medical.cert-status`; canonical entities.
  - §D.1 — 22-stage J08 journey, stage-to-service mapping.
  - §D.2 — stage-to-service summary; stages 13, 22 dashboard-anchored.
  - §E — 12 roles; Phase 3 in-scope roles align to journey 07 Layer 2
    "applicant, CFI, DPE, AME, FAA-CAMI" (5 named) plus registry admin.
  - §F.1 — duplicate-FTN rate to 0; identity surfaces 6 → 1.
- Build plan: `docs/phase3/build-demo-skills-plan.md` §3 B3 (this skill);
  §6 Day 4 (drop-in date); §2 demo journeys D1–D5.
- Gap matrix: `docs/phase3/skills-gap-matrix.md` §4 NEW-2.
- Adjacent skills:
  - `react-page-generation` (EDIT-4) — consumes the JSON specs this skill
    emits; produces the React + USWDS components.
  - `pilot-certification-workflow-fsm` — emits the SSE events this dashboard
    subscribes to via the channel names in `sse-wiring.md`.
  - `api-specification` (EDIT) — defines the REST endpoints each widget
    binds to; OpenAPI 3.1 contract source-of-truth.
  - `frontend-parity-test-generator` — consumes the fixture data and
    Mermaid wireframes to produce Playwright role-keyed e2e specs.
  - `accessibility-checker` — runs against the rendered dashboards using
    the a11y-checklist as the test plan.

## Anti-patterns

- **Do not** write a "designer's mockup" PDF or Figma export. The output of
  this skill is a machine-readable JSON contract. Mockups belong in the
  written narrative as illustration, not in the build artifact tree.
- **Do not** propose new widget types without updating the canonical
  vocabulary in step 2. A one-off `usa-modal-with-tabs` pattern in one
  role view fragments USWDS consistency and breaks the
  `uswds-role-layout-library` contract.
- **Do not** put PHI fields in the applicant Currency Clocks or Pending
  Actions widgets. Currency is `medical.cert-status.expDate`, not
  `cardiology.diagnosis`. The boundary is at the API, but the spec
  enforces it at the widget level too.
- **Do not** specify polling-only — SSE primary, polling fallback. Polling-only
  fails P3-R27 ("real-time"); the FAA evaluator will count latency.
- **Do not** reference BASE-C, Bedrock, or AWS Step Functions in the SSE
  wiring spec. Phase 3 uses Postgres LISTEN/NOTIFY (build plan §1.1);
  AWS-native event bus is a Phase 4 swap, documented as a deviation in
  `phase-commitment-traceback`.
