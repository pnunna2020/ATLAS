# Java EE Architecture Patterns

Reference for Legacy Architecture Mapper when analyzing Java EE applications.

## Technology Detection

Confirm Java EE by checking for:
- `pom.xml` (Maven) or `build.gradle` (Gradle) or `build.xml` (Ant)
- `web.xml` in `WEB-INF/` (servlet deployment descriptor)
- `ejb-jar.xml` in `META-INF/` (EJB deployment descriptor)
- `application.xml` in `META-INF/` (EAR descriptor)
- Java EE annotations: `@Stateless`, `@Entity`, `@WebServlet`, `@ManagedBean`
- `javax.*` or `jakarta.*` package imports (javax = pre-Jakarta EE 9, jakarta = post)

## Module Boundaries

### Maven Multi-Module Projects
```xml
<!-- Parent pom.xml -->
<modules>
    <module>common</module>      <!-- shared DTOs, utilities -->
    <module>ejb</module>         <!-- business logic EJBs -->
    <module>web</module>         <!-- WAR: servlets, JSPs, REST -->
    <module>ear</module>         <!-- packaging: EAR assembly -->
    <module>batch</module>       <!-- batch jobs -->
</modules>
```
Each `<module>` is a logical boundary. Check `<dependencies>` within each module's
`pom.xml` to map inter-module coupling.

### EAR Packaging Structure
```
myapp.ear
├── META-INF/application.xml    ← declares modules
├── myapp-web.war               ← web tier
│   ├── WEB-INF/web.xml
│   └── WEB-INF/classes/
├── myapp-ejb.jar               ← business tier
│   └── META-INF/ejb-jar.xml
└── lib/                        ← shared libraries
```

### OSGi Bundles
Check for `MANIFEST.MF` with `Bundle-SymbolicName` — indicates OSGi modularization.
Each bundle declares explicit imports/exports, providing stronger boundaries than EAR.

## Import / Dependency Analysis

### Java Imports
```java
import com.myapp.service.UserService;       // direct dependency
import com.myapp.model.User;                // model dependency
import javax.inject.Inject;                 // CDI injection
import javax.ejb.EJB;                       // EJB injection
```
Parse import statements to build a dependency graph. Group by package prefix to
identify module-level dependencies.

### Maven Dependency Tree
```bash
mvn dependency:tree -DoutputType=dot    # generates DOT graph
mvn dependency:analyze                   # finds unused/undeclared deps
```
The `dependency:tree` output reveals transitive dependencies and version conflicts.

### Reflection and Dynamic Loading
```java
Class.forName("com.myapp.plugins." + pluginName);   // dynamic class loading
ServiceLoader.load(MyPlugin.class);                   // service provider interface
```
Grep for `Class.forName`, `ServiceLoader`, and `getClass().getMethod()` — these
create dependencies invisible to static import analysis.

### JNDI Lookups
```java
Context ctx = new InitialContext();
DataSource ds = (DataSource) ctx.lookup("java:comp/env/jdbc/MyDB");
UserService svc = (UserService) ctx.lookup("java:global/myapp/UserServiceBean");
```
JNDI lookups create runtime coupling not visible in imports. Grep for `ctx.lookup`
and `InitialContext` to find hidden cross-module dependencies.

## Build System

### Maven (most common)
- `pom.xml` at project root and in each module
- `mvn clean package` produces WAR/EAR artifacts
- Check `<plugins>` section for build customizations (shade, assembly, etc.)
- `settings.xml` may reference private artifact repositories

### Gradle
- `build.gradle` (Groovy) or `build.gradle.kts` (Kotlin DSL)
- `settings.gradle` lists included subprojects
- Check for `war`, `ear`, `java` plugins

### Ant (legacy)
- `build.xml` at project root
- Targets define compile, package, deploy steps
- Dependencies often managed manually in `lib/` directory (no dependency resolution)
- Migration from Ant → Maven is a significant modernization step itself

## Deployment Topology

### Application Server Detection
- **WebSphere**: Check for `ibm-web-bnd.xml`, `ibm-application-bnd.xml`, `was.policy`
- **JBoss/WildFly**: Check for `jboss-web.xml`, `jboss-deployment-structure.xml`, `*-jboss-beans.xml`
- **WebLogic**: Check for `weblogic.xml`, `weblogic-application.xml`, `weblogic-ejb-jar.xml`
- **Tomcat**: Check for `context.xml` in `META-INF/`, Tomcat-specific JNDI in `server.xml`
- **GlassFish/Payara**: Check for `glassfish-web.xml`, `sun-web.xml`

Server-specific descriptors indicate vendor lock-in that must be addressed during migration.

## God Class Indicators

- Classes exceeding 1000 lines of code
- Service classes with 30+ public methods
- "God EJBs": Stateless session beans that handle multiple unrelated business domains
- Utility classes (`StringUtils`, `CommonHelper`) imported by >50% of other classes
- Controllers/servlets handling 15+ URL patterns or action mappings
- Entity classes with 50+ fields (likely denormalized or multi-purpose)

## Coupling Indicators

### Circular Module Dependencies
```bash
mvn dependency:analyze -DignoreNonCompile
# or use JDepend / ArchUnit to detect cycles
```
Circular dependencies between Maven modules indicate poor boundary design.

### Cross-Module Coupling Signals
- JNDI lookups referencing beans in other modules
- Shared mutable static state (`public static` non-final fields)
- Direct database access from web tier (bypassing service layer)
- Shared DTOs that accumulate fields for multiple consumers
- Event bus or message-driven beans used as a "back channel" between modules

## Database Patterns

### JDBC Direct
```java
Connection conn = dataSource.getConnection();
PreparedStatement ps = conn.prepareStatement("SELECT * FROM users WHERE id = ?");
ps.setInt(1, userId);
ResultSet rs = ps.executeQuery();
```

### JPA / Hibernate
```java
@Entity
@Table(name = "users")
public class User {
    @Id @GeneratedValue
    private Long id;

    @OneToMany(mappedBy = "user", cascade = CascadeType.ALL)
    private List<Order> orders;
}
```
Check `persistence.xml` for JPA configuration and entity scanning packages.

### MyBatis / iBatis
Look for mapper XML files (`*Mapper.xml`) and `SqlMapConfig.xml`. Queries are
defined in XML, mapped to Java interfaces.

### Spring Data (if Spring is present)
```java
public interface UserRepository extends JpaRepository<User, Long> {
    List<User> findByLastName(String lastName);  // derived query
}
```

## Framework Detection Summary

| Framework | Key Indicator Files |
|-----------|-------------------|
| Spring | `applicationContext.xml`, `@SpringBootApplication`, `spring-beans.xml` |
| Struts 1.x | `struts-config.xml`, `ActionForm` classes |
| Struts 2 | `struts.xml`, classes extending `ActionSupport` |
| JSF | `faces-config.xml`, `.xhtml` Facelets, `@ManagedBean` |
| EJB 2.x | `ejb-jar.xml` with `<session>` and `<entity>` descriptors, Home/Remote interfaces |
| EJB 3.x | `@Stateless`, `@Stateful`, `@MessageDriven` annotations |
| JAX-RS | `@Path`, `@GET/@POST`, `Application` subclass or `web.xml` servlet mapping |
| JAX-WS | `@WebService`, WSDL files, `wsimport`-generated code |
| CDI | `beans.xml` in `WEB-INF/` or `META-INF/`, `@Inject` annotations |
