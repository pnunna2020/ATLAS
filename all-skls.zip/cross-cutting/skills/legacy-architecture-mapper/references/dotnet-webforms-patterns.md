# .NET WebForms Architecture Patterns

Reference for Legacy Architecture Mapper when analyzing .NET WebForms applications.

## Technology Detection

Confirm .NET WebForms by checking for:
- `.aspx` files (WebForms pages with server-side markup)
- `.aspx.cs` or `.aspx.vb` files (code-behind classes)
- `.ascx` files (user controls) and `.ascx.cs` / `.ascx.vb` (code-behind)
- `.master` files (master page layout templates)
- `web.config` with `<pages>` section and `<compilation>` referencing `System.Web`
- `Global.asax` / `Global.asax.cs` (application lifecycle handler)
- `App_Code/` directory (dynamically compiled shared code)
- `.csproj` or `.vbproj` with references to `System.Web`, `System.Web.UI`
- `.sln` file (Visual Studio solution — groups all projects)

### Framework Variant Detection

| Variant | Key Indicators |
|---------|---------------|
| Pure WebForms | `.aspx` files, `runat="server"` controls, no MVC references |
| WebForms + Web API | `WebApiConfig.cs` in `App_Start/`, `ApiController` base classes |
| WebForms + MVC hybrid | `RouteConfig.cs`, `Controllers/` folder alongside `.aspx` pages |
| WebForms + SignalR | `Hub` classes, `$.connection.hub` in JavaScript |
| WebForms + WCF | `.svc` files, `[ServiceContract]` interfaces, `system.serviceModel` in config |
| WebForms + ASMX | `.asmx` files, `[WebMethod]` attributes, `[WebService]` class attribute |
| WebForms + OWIN | `Startup.cs` with `OwinStartup` attribute, `IAppBuilder` usage |

### .NET Framework Version Matrix

| Version | Key Capabilities | WebForms Features |
|---------|-----------------|-------------------|
| 2.0 | Generics, nullable types | Master pages, themes, data source controls |
| 3.5 | LINQ, ASP.NET AJAX | ScriptManager, UpdatePanel, LINQ to SQL |
| 4.0 | Dynamic, parallel libs | Routing, output cache profiles, chart control |
| 4.5 | async/await, model binding | Strongly-typed data controls, model binding, bundling |
| 4.5.2 | High DPI, ASP.NET Identity | OWIN middleware support |
| 4.6-4.6.2 | Crypto improvements | HTTP/2, async model binding |
| 4.7-4.7.2 | TLS 1.2 default | Dependency injection support (limited) |
| 4.8 | Final .NET Framework | Last WebForms release, accessibility improvements |

## Solution and Project Structure

### .sln File Parsing

The `.sln` file is the top-level architecture map. Parse it to find all projects:

```
Microsoft Visual Studio Solution File, Format Version 12.00
# Visual Studio Version 17
Project("{FAE04EC0-301F-11D3-BF4B-00C04F79EFBC}") = "MyApp.Web",
    "MyApp.Web\MyApp.Web.csproj", "{GUID-1}"
EndProject
Project("{FAE04EC0-301F-11D3-BF4B-00C04F79EFBC}") = "MyApp.Business",
    "MyApp.Business\MyApp.Business.csproj", "{GUID-2}"
EndProject
Project("{FAE04EC0-301F-11D3-BF4B-00C04F79EFBC}") = "MyApp.Data",
    "MyApp.Data\MyApp.Data.csproj", "{GUID-3}"
EndProject
Project("{FAE04EC0-301F-11D3-BF4B-00C04F79EFBC}") = "MyApp.Common",
    "MyApp.Common\MyApp.Common.csproj", "{GUID-4}"
EndProject
Project("{FAE04EC0-301F-11D3-BF4B-00C04F79EFBC}") = "MyApp.Tests",
    "MyApp.Tests\MyApp.Tests.csproj", "{GUID-5}"
EndProject
```

**Project type GUIDs** reveal technology:
| GUID Prefix | Project Type |
|-------------|-------------|
| `FAE04EC0` | C# |
| `F184B08F` | VB.NET |
| `349C5851` | ASP.NET Web Application |
| `E3E379DF` | ASP.NET MVC |
| `E24C65DC` | Web Site (file-based, no .csproj) |
| `60DC8134` | Unit Test |
| `3AC096D0` | Common Test |

### .csproj Reference Analysis

#### ProjectReference (Source-Level Dependencies)
```xml
<ItemGroup>
  <!-- This project depends on MyApp.Business at compile time -->
  <ProjectReference Include="..\MyApp.Business\MyApp.Business.csproj">
    <Project>{GUID-2}</Project>
    <Name>MyApp.Business</Name>
  </ProjectReference>
  <ProjectReference Include="..\MyApp.Common\MyApp.Common.csproj">
    <Project>{GUID-4}</Project>
    <Name>MyApp.Common</Name>
  </ProjectReference>
</ItemGroup>
```

Build a directed graph from `ProjectReference` entries. This is the compile-time
dependency structure.

#### Package References (NuGet Dependencies)
```xml
<!-- SDK-style .csproj (newer) -->
<ItemGroup>
  <PackageReference Include="EntityFramework" Version="6.4.4" />
  <PackageReference Include="Newtonsoft.Json" Version="13.0.3" />
</ItemGroup>
```

```xml
<!-- packages.config (older) -->
<packages>
  <package id="EntityFramework" version="6.4.4" targetFramework="net48" />
  <package id="log4net" version="2.0.15" targetFramework="net48" />
</packages>
```

#### Assembly References (Binary Dependencies)
```xml
<ItemGroup>
  <!-- Framework assembly (from GAC) -->
  <Reference Include="System.Web" />
  <Reference Include="System.Data.Linq" />

  <!-- Third-party assembly (local copy) -->
  <Reference Include="Telerik.Web.UI, Version=2023.3.1010.45,
      Culture=neutral, PublicKeyToken=121fae78165ba3d4">
    <HintPath>..\packages\Telerik.Web.UI\lib\Telerik.Web.UI.dll</HintPath>
    <Private>True</Private>
  </Reference>

  <!-- Binary reference with no source (checked-in DLL) -->
  <Reference Include="MyApp.Legacy">
    <HintPath>..\lib\MyApp.Legacy.dll</HintPath>
  </Reference>
</ItemGroup>
```

**Key analysis**:
- References without `HintPath` are GAC-deployed — server dependency
- References with `HintPath` pointing to `lib/` or `packages/` are local copies
- `Private=True` means "copy to output" — the assembly ships with the app
- Binary references in `lib/` with no corresponding project are opaque dependencies

#### Shared Projects
```xml
<!-- SharedProject in .sln -->
Project("{D954291E-2A0B-460D-934E-DC6B0785DB48}") = "MyApp.Shared",
    "MyApp.Shared\MyApp.Shared.shproj", "{GUID}"

<!-- Imported in consuming .csproj -->
<Import Project="..\MyApp.Shared\MyApp.Shared.projitems" Label="Shared" />
```

Shared projects compile their code directly into each consuming project (no DLL).
This creates tight coupling — changes to the shared project affect every consumer.

## Assembly Dependency Analysis

### Reference Hierarchy Mapping

Build the full dependency graph:
```
MyApp.Web (presentation)
├── MyApp.Business (BLL)
│   ├── MyApp.Data (DAL)
│   │   ├── MyApp.Common (shared models/utilities)
│   │   └── EntityFramework (NuGet)
│   └── MyApp.Common
├── MyApp.Common
├── Telerik.Web.UI (third-party UI)
└── System.Web (framework)
```

**Healthy hierarchy**: Web → Business → Data → Common, with no upward references.
**Unhealthy signals**: Data referencing Business, Business referencing Web,
circular references between any pair.

### GAC Dependencies

Assemblies resolved from the Global Assembly Cache:
```csharp
// Code referencing GAC-deployed assemblies
using System.EnterpriseServices;        // COM+ services
using Microsoft.Office.Interop.Excel;   // Office automation
using Oracle.DataAccess.Client;          // Oracle ODP.NET (GAC-deployed)
```

GAC dependencies are invisible in the application deployment package. Identify them by:
1. References in `.csproj` with no `HintPath`
2. References with `HintPath` pointing to `C:\Windows\assembly\` or `C:\Windows\Microsoft.NET\assembly\`
3. Strong-named assemblies (`PublicKeyToken` specified) not in `bin/` or `packages/`

### Binding Redirects

```xml
<!-- web.config — assembly version resolution rules -->
<runtime>
  <assemblyBinding xmlns="urn:schemas-microsoft:asm.v1">
    <dependentAssembly>
      <assemblyIdentity name="Newtonsoft.Json"
          publicKeyToken="30ad4fe6b2a6aeed" culture="neutral" />
      <!-- RULE: All versions 6.0-13.0 resolve to 13.0.0.0 -->
      <bindingRedirect oldVersion="0.0.0.0-13.0.0.0"
          newVersion="13.0.0.0" />
    </dependentAssembly>
    <dependentAssembly>
      <assemblyIdentity name="System.Web.Mvc"
          publicKeyToken="31bf3856ad364e35" />
      <bindingRedirect oldVersion="0.0.0.0-5.2.9.0"
          newVersion="5.2.9.0" />
    </dependentAssembly>
  </assemblyBinding>
</runtime>
```

Binding redirects indicate version conflict resolution. Many redirects suggest
a complex dependency graph with version mismatches — a migration risk indicator.

## Layer Identification

### Standard N-Tier Layer Detection

| Layer | Common Project Names | Key Indicators |
|-------|---------------------|----------------|
| Presentation | `*.Web`, `*.UI`, `*.WebApp` | References `System.Web`, contains `.aspx` files |
| Business Logic | `*.Business`, `*.BLL`, `*.Services`, `*.Core`, `*.Domain` | No `System.Web` reference, contains service classes |
| Data Access | `*.Data`, `*.DAL`, `*.DataAccess`, `*.Repository`, `*.Persistence` | References `System.Data`, EF, ADO.NET usage |
| Common/Shared | `*.Common`, `*.Shared`, `*.Utilities`, `*.Infrastructure` | Referenced by multiple layers, contains DTOs and utilities |
| Models/Entities | `*.Models`, `*.Entities`, `*.Domain.Models` | POCOs, EF entity classes, data annotations |
| Tests | `*.Tests`, `*.UnitTests`, `*.IntegrationTests` | References test framework (MSTest, NUnit, xUnit) |

### Anti-Pattern: Presentation Contains Business Logic

Detect by checking if the web project has:
- SQL queries in `.aspx.cs` files (data access in presentation)
- Direct `SqlConnection` or `DbContext` usage in code-behind
- Business calculations in event handlers instead of service calls
- File with more than 200 lines of code in code-behind

```csharp
// Anti-pattern: Business logic and data access in code-behind
protected void btnCalculate_Click(object sender, EventArgs e)
{
    using (var conn = new SqlConnection(connString))
    {
        conn.Open();
        var cmd = new SqlCommand("SELECT Rate FROM Rates WHERE ...", conn);
        decimal rate = (decimal)cmd.ExecuteScalar();

        // Business calculation embedded in UI
        decimal total = quantity * rate * (1 + taxRate);
        if (total > 10000) ApplyBulkDiscount(ref total);

        lblTotal.Text = total.ToString("C");
    }
}
```

## Service Boundaries

### WCF Services (.svc)

```csharp
// IFlightService.cs — service contract
[ServiceContract(Namespace = "http://faa.gov/services/flights")]
public interface IFlightService
{
    [OperationContract]
    FlightInfo GetFlight(int flightId);

    [OperationContract]
    SearchResult SearchFlights(SearchCriteria criteria);

    [OperationContract(IsOneWay = true)]
    void NotifyFlightStatusChange(int flightId, string newStatus);
}
```

Check `web.config` for WCF endpoint configuration:
```xml
<system.serviceModel>
  <services>
    <service name="MyApp.Services.FlightService">
      <endpoint address="" binding="basicHttpBinding"
          contract="MyApp.Services.IFlightService" />
      <endpoint address="mex" binding="mexHttpBinding"
          contract="IMetadataExchange" />
    </service>
  </services>
  <bindings>
    <basicHttpBinding>
      <binding name="SecureBinding">
        <security mode="Transport">
          <transport clientCredentialType="Windows" />
        </security>
      </binding>
    </basicHttpBinding>
  </bindings>
</system.serviceModel>
```

**Analysis points:**
- Each `[ServiceContract]` interface defines a service boundary
- Binding type indicates transport protocol (HTTP, TCP, named pipe, MSMQ)
- Security mode indicates auth requirements
- `IsOneWay = true` indicates fire-and-forget patterns (async messaging)

### ASMX Web Services

```csharp
[WebService(Namespace = "http://faa.gov/services")]
[WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
public class LegacyFlightService : System.Web.Services.WebService
{
    [WebMethod(Description = "Returns flight details")]
    public FlightInfo GetFlight(int flightId) { ... }

    [WebMethod(CacheDuration = 60)]
    public AirportInfo[] GetAirports() { ... }
}
```

ASMX services are the oldest web service technology in .NET. They generate WSDL
automatically and communicate via SOAP XML.

### Web API Controllers (Hybrid Apps)

```csharp
// In WebForms + Web API hybrid apps
public class FlightsApiController : ApiController
{
    [HttpGet]
    [Route("api/flights/{id}")]
    public IHttpActionResult GetFlight(int id) { ... }

    [HttpPost]
    [Route("api/flights/search")]
    public IHttpActionResult SearchFlights(SearchCriteria criteria) { ... }
}
```

Check `App_Start/WebApiConfig.cs` for route configuration:
```csharp
public static class WebApiConfig
{
    public static void Register(HttpConfiguration config)
    {
        config.MapHttpAttributeRoutes();
        config.Routes.MapHttpRoute(
            name: "DefaultApi",
            routeTemplate: "api/{controller}/{id}",
            defaults: new { id = RouteParameter.Optional }
        );
    }
}
```

### SignalR Hubs

```csharp
public class FlightStatusHub : Hub
{
    public void SubscribeToFlight(int flightId)
    {
        Groups.Add(Context.ConnectionId, $"flight-{flightId}");
    }

    public void BroadcastStatusUpdate(int flightId, string newStatus)
    {
        Clients.Group($"flight-{flightId}")
            .updateStatus(flightId, newStatus);
    }
}
```

SignalR hubs define real-time communication boundaries. Map hub methods to
understand the real-time event model.

## Database Coupling

### Connection String Analysis

```xml
<connectionStrings>
  <!-- Primary application database -->
  <add name="MainDB"
       connectionString="Server=SQLPROD01;Database=FlightOps;
           Integrated Security=true;MultipleActiveResultSets=true"
       providerName="System.Data.SqlClient" />

  <!-- Reporting database (read-only) -->
  <add name="ReportDB"
       connectionString="Server=SQLRPT01;Database=FlightOps_Reporting;
           Integrated Security=true"
       providerName="System.Data.SqlClient" />

  <!-- Legacy Oracle database -->
  <add name="LegacyDB"
       connectionString="Data Source=ORAPROD;User Id=app_user;Password=***"
       providerName="Oracle.DataAccess.Client" />

  <!-- Membership database -->
  <add name="MembershipDB"
       connectionString="Server=SQLPROD01;Database=ASPNetMembership;
           Integrated Security=true"
       providerName="System.Data.SqlClient" />
</connectionStrings>
```

**Analysis approach:**
1. Count distinct connection strings — each is a database dependency
2. Note the `providerName` — indicates database vendor (SqlClient = SQL Server,
   Oracle.DataAccess = Oracle, MySql.Data = MySQL, Npgsql = PostgreSQL)
3. Check for `Integrated Security=true` (Windows auth) vs. user/password (SQL auth)
4. Map which code files use which connection string names
5. Flag `MultipleActiveResultSets=true` — indicates multiple open readers, a
   pattern that must be handled carefully in migration

### Multiple Database Targets

Grep for connection string usage across the codebase:
```csharp
// Direct ADO.NET with named connection
var connStr = ConfigurationManager.ConnectionStrings["MainDB"].ConnectionString;

// Entity Framework with named connection
public class MyAppContext : DbContext
{
    public MyAppContext() : base("name=MainDB") { }
}

// LINQ to SQL with named connection
var dc = new MyAppDataContext(
    ConfigurationManager.ConnectionStrings["MainDB"].ConnectionString);
```

### Linked Server Usage

Check stored procedures for cross-database or cross-server queries:
```sql
-- Linked server reference in stored procedures
SELECT * FROM [LINKEDSERVER01].[RemoteDB].[dbo].[ExternalFlights]
SELECT * FROM [ReportDB].[dbo].[FlightMetrics]  -- cross-database reference
```

Linked servers create invisible runtime dependencies between databases.

## Configuration Coupling

### Shared Config Files

```xml
<!-- web.config references external config files -->
<appSettings file="shared.config" />
<connectionStrings configSource="connections.config" />
```

External config files may be shared across multiple applications on the same
server — changing one affects all consumers.

### machine.config Dependencies

Settings that exist only in `C:\Windows\Microsoft.NET\Framework64\v4.0.30319\Config\machine.config`:
```xml
<!-- Machine-level settings invisible in web.config -->
<membership>
  <providers>
    <add name="AspNetSqlMembershipProvider" ... />
  </providers>
</membership>

<machineKey validationKey="AutoGenerate" decryptionKey="AutoGenerate" />
```

If the app relies on machine-level providers, connection strings, or machine keys,
these are deployment-environment dependencies.

### Custom Configuration Sections

```csharp
// Custom config section handler
public class FlightRulesSection : ConfigurationSection
{
    [ConfigurationProperty("rules")]
    public FlightRuleCollection Rules => (FlightRuleCollection)this["rules"];
}

public class FlightRuleCollection : ConfigurationElementCollection
{
    // ...
}
```

```xml
<configSections>
  <section name="flightRules"
           type="MyApp.Config.FlightRulesSection, MyApp.Common" />
</configSections>

<flightRules>
  <rules>
    <add name="MaxDelay" threshold="120" action="Escalate" />
    <add name="MinCrew" threshold="2" action="GroundFlight" />
  </rules>
</flightRules>
```

Custom config sections couple configuration to specific C# types. Map every
custom section, its handler type, and the project containing the handler.

## Build System

### MSBuild Analysis

Check `.csproj` for build customizations:

```xml
<!-- Pre-build events -->
<PropertyGroup>
  <PreBuildEvent>
    call "$(SolutionDir)tools\generate-version.bat"
  </PreBuildEvent>
</PropertyGroup>

<!-- Post-build events -->
<PropertyGroup>
  <PostBuildEvent>
    xcopy "$(TargetDir)*.dll" "$(SolutionDir)lib\" /Y
  </PostBuildEvent>
</PropertyGroup>

<!-- Custom MSBuild targets -->
<Target Name="CopyConfig" AfterTargets="Build">
  <Copy SourceFiles="$(SolutionDir)config\shared.config"
        DestinationFolder="$(OutputPath)" />
</Target>

<!-- T4 templates (code generation) -->
<ItemGroup>
  <None Include="Templates\EntityTemplate.tt">
    <Generator>TextTemplatingFileGenerator</Generator>
    <LastGenOutput>EntityTemplate.cs</LastGenOutput>
  </None>
</ItemGroup>
```

### T4 Templates

Text Template Transformation Toolkit files (`.tt`) generate code at build time:
```
Templates/
├── EntityTemplate.tt          ← generates entity classes from database schema
├── RepositoryTemplate.tt      ← generates repository interfaces
├── DalTemplate.tt             ← generates data access layer code
```

T4 templates indicate code generation patterns that must be understood — the
generated code contains business logic but the template contains the rules for
generating it.

### Web.config Transforms

```xml
<!-- web.Release.config -->
<configuration xmlns:xdt="http://schemas.microsoft.com/XML-Document-Transform">
  <system.web>
    <compilation xdt:Transform="RemoveAttributes(debug)" />
  </system.web>
  <connectionStrings>
    <add name="MainDB"
         connectionString="Server=SQLPROD01;Database=FlightOps;..."
         xdt:Transform="SetAttributes" xdt:Locator="Match(name)" />
  </connectionStrings>
  <appSettings>
    <add key="EnableDebugMode" value="false"
         xdt:Transform="SetAttributes" xdt:Locator="Match(key)" />
  </appSettings>
</configuration>
```

Count the number of transforms and the differences between environments to
understand configuration complexity.

## Deployment Topology

### IIS Site/Application/Virtual Directory Structure

```
IIS Default Web Site
├── /MyApp                    ← IIS Application (separate app pool)
│   ├── /MyApp/Admin          ← Virtual Directory (may be separate app)
│   ├── /MyApp/Reports        ← Virtual Directory
│   └── /MyApp/API            ← IIS Application (Web API, separate pool)
├── /Services                 ← WCF services (separate app pool)
└── /SharedAuth               ← Shared authentication service
```

**Analysis approach:**
1. Check IIS configuration or deployment scripts for site structure
2. Look for `<location>` elements in `web.config` that configure sub-paths
3. Check for virtual directory references in code (`~/Reports/...`)
4. Identify which components share an app pool (shared process, shared failures)

### web.config Transforms Per Environment

```
web.config                 ← base (development defaults)
web.Debug.config           ← local debug overrides
web.Release.config         ← release/staging overrides
web.Production.config      ← production overrides
web.QA.config              ← QA environment (custom)
web.UAT.config             ← UAT environment (custom)
```

More transform files indicate more environments, which indicates more complex
deployment pipelines.

### Publish Profiles

Check `Properties/PublishProfiles/`:
```xml
<!-- Production.pubxml -->
<Project>
  <PropertyGroup>
    <WebPublishMethod>MSDeploy</WebPublishMethod>
    <MSDeployServiceURL>https://deploy.faa.gov:8172/msdeploy.axd</MSDeployServiceURL>
    <DeployIisAppPath>Default Web Site/FlightOps</DeployIisAppPath>
    <ExcludeFilesFromDeployment>web.Debug.config;*.pdb</ExcludeFilesFromDeployment>
  </PropertyGroup>
</Project>
```

## God Class Indicators

### Large Code-Behind Files

Files exceeding 500 lines indicate god-page anti-pattern:
```
FlightManagement.aspx.cs     — 2,400 lines (handles search, CRUD, reports, export)
Dashboard.aspx.cs            — 1,800 lines (multiple panels, charts, data loading)
ApplicationWizard.aspx.cs    — 1,200 lines (multi-step workflow in one page)
Admin.aspx.cs                — 900 lines (user mgmt, config, audit log)
```

### Utility Classes with Excessive Methods

```csharp
// God utility class
public static class CommonHelper  // 50+ static methods, referenced everywhere
{
    public static string FormatDate(DateTime dt) { ... }
    public static bool ValidateSSN(string ssn) { ... }
    public static decimal CalculateTax(decimal amount) { ... }
    public static void SendEmail(string to, string subject, string body) { ... }
    public static DataTable ExecuteQuery(string sql) { ... }
    // ... 45 more methods
}
```

Utility god classes indicate missing domain separation. Group methods by domain
to identify potential service boundaries.

### Indicators to Count

| Indicator | Threshold | Risk |
|-----------|-----------|------|
| Code-behind > 500 lines | Each file | High — mixed concerns |
| Code-behind > 200 lines | Each file | Medium — growing complexity |
| Class with > 30 public methods | Each class | High — god class |
| Static utility class referenced by > 50% of files | Each class | High — tight coupling |
| Single project with > 100 `.aspx` files | Per project | High — monolith |
| `App_Code/` with > 50 files | Per directory | Medium — missing libraries |

## Coupling Indicators

### Circular Project References

Check for circular dependencies in the project reference graph:
```
MyApp.Web → MyApp.Business → MyApp.Data → MyApp.Common  ← healthy
MyApp.Web → MyApp.Business → MyApp.Web                   ← circular!
MyApp.Data → MyApp.Business → MyApp.Data                  ← circular!
```

Visual Studio prevents direct circular `ProjectReference`, but circular coupling
can exist through:
- Shared static state in `Common` assemblies
- Event-based indirect references
- Runtime type loading via reflection

### Shared Static State

```csharp
// Global mutable state — creates hidden coupling
public static class ApplicationState
{
    public static Dictionary<string, object> Cache = new();
    public static int ActiveUserCount = 0;
    public static DateTime LastMaintenanceRun;
}

// HttpContext.Current abuse — tight coupling to ASP.NET pipeline
public class FlightService
{
    public void ProcessFlight()
    {
        // BAD: Service layer reaching into HTTP context
        var userId = HttpContext.Current.Session["UserId"];
        var ipAddress = HttpContext.Current.Request.UserHostAddress;
        HttpContext.Current.Cache["LastFlight"] = flight;
    }
}
```

Grep for `HttpContext.Current` usage outside of `.aspx.cs` files. Every
occurrence in a service or data access class is a coupling violation that
blocks unit testing and migration.

### Ambient Context Pattern (Anti-Pattern)

```csharp
// Thread-static or CallContext-based ambient state
public static class CurrentUser
{
    [ThreadStatic]
    private static UserInfo _current;

    public static UserInfo Current
    {
        get => _current ?? throw new InvalidOperationException("No user context");
        set => _current = value;
    }
}

// Usage across the codebase — invisible dependency
public class AuditService
{
    public void LogAction(string action)
    {
        var entry = new AuditEntry
        {
            Action = action,
            User = CurrentUser.Current.Name,  // ambient dependency
            Timestamp = DateTime.Now
        };
    }
}
```

### Other Coupling Signals

- **Hard-coded file paths**: `@"C:\FlightData\exports\"` or `Server.MapPath("~/Data/")`
- **Assembly.Load / Activator.CreateInstance**: Runtime type loading bypasses
  compile-time dependency analysis
- **Shared session variables**: Multiple pages reading/writing the same session key
  creates invisible inter-page coupling
- **Event-based coupling**: Custom events or delegates that span project boundaries
- **Database-level coupling**: Multiple applications sharing database tables, or
  using database-level triggers that affect other applications

## Database Patterns

### Connection String Inventory

Map every connection string name to its consumers:
```
MainDB          → Used by: FlightService, UserService, ReportService (15 files)
ReportDB        → Used by: ReportGenerator, DashboardService (3 files)
MembershipDB    → Used by: ASP.NET Membership provider (web.config only)
LegacyOracleDB  → Used by: LegacyDataAdapter (2 files)
```

### Data Access Technology Detection

| Technology | Detection Method |
|-----------|-----------------|
| Raw ADO.NET | `SqlConnection`, `SqlCommand`, `SqlDataReader`, `SqlDataAdapter` |
| Typed DataSets | `.xsd` files, `TableAdapter` classes, `DataSet` subclasses |
| Entity Framework DB-First | `.edmx` files, `ObjectContext` base class |
| Entity Framework Code-First | `DbContext` base class, `DbSet<T>` properties |
| LINQ to SQL | `.dbml` files, `DataContext` base class |
| Dapper | `connection.Query<T>()`, `connection.Execute()` |
| NHibernate | `.hbm.xml` mapping files, `ISessionFactory`, `ISession` |
| Stored Procedures | `CommandType.StoredProcedure`, `EXEC sp_` in SQL strings |

### Multi-Technology Data Access

Many legacy WebForms apps use multiple data access technologies simultaneously:
```
FlightService    → Entity Framework 6 (newer code)
ReportService    → Raw ADO.NET DataSets (legacy code)
UserService      → ASP.NET Membership (built-in provider)
AuditService     → Stored Procedures via ADO.NET
ExternalFeed     → LINQ to SQL (one-off integration)
```

Document which technology each service uses — this affects migration strategy
(unified EF Core vs. maintaining multiple approaches).

## Framework Detection Summary

| Technology | Key Indicator Files / Patterns |
|-----------|-------------------------------|
| ASP.NET WebForms | `.aspx` files, `runat="server"`, `System.Web.UI.Page` |
| ASP.NET MVC (hybrid) | `Controllers/` folder, `RouteConfig.cs`, `@model` in `.cshtml` |
| ASP.NET Web API | `WebApiConfig.cs`, `ApiController` base class |
| WCF | `.svc` files, `system.serviceModel` in web.config |
| ASMX | `.asmx` files, `[WebMethod]` attribute |
| SignalR | `Hub` base class, `$.connection` in JavaScript |
| Entity Framework 6 | `DbContext` subclass, `EntityFramework` NuGet package |
| Entity Framework DB-First | `.edmx` file, `ObjectContext` subclass |
| LINQ to SQL | `.dbml` file, `DataContext` subclass |
| ASP.NET Identity | `Microsoft.AspNet.Identity.*` packages, `UserManager<T>` |
| ASP.NET Membership | `<membership>` in web.config, `Membership.GetUser()` |
| OWIN/Katana | `Startup.cs` with `OwinStartup`, `Microsoft.Owin.*` packages |
| Bundling/Optimization | `BundleConfig.cs`, `System.Web.Optimization` |
| Telerik UI | `Telerik.Web.UI` in references, `<telerik:Rad*>` tags |
| DevExpress | `DevExpress.Web.*` in references, `<dx:ASPx*>` tags |
| Infragistics | `Infragistics.Web.UI` in references, `<ig:Web*>` tags |
