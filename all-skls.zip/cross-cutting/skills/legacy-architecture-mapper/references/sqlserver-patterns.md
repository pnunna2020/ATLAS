# SQL Server Architecture Decomposition Patterns

## Purpose

Reference for the Legacy Architecture Mapper skill when decomposing SQL Server
database architectures. SQL Server installations often span multiple instances,
databases, replication topologies, and security models. This guide covers the
full architectural inventory needed for migration planning.

## Database Topology

### Instance Inventory

```sql
-- Get instance-level information
SELECT
    SERVERPROPERTY('MachineName') AS MachineName,
    SERVERPROPERTY('ServerName') AS ServerName,
    SERVERPROPERTY('InstanceName') AS InstanceName,
    SERVERPROPERTY('ProductVersion') AS Version,
    SERVERPROPERTY('ProductLevel') AS ServicePack,
    SERVERPROPERTY('Edition') AS Edition,
    SERVERPROPERTY('EngineEdition') AS EngineEdition,
    SERVERPROPERTY('Collation') AS ServerCollation,
    SERVERPROPERTY('IsHadrEnabled') AS AlwaysOnEnabled,
    SERVERPROPERTY('IsClustered') AS IsClustered,
    SERVERPROPERTY('IsFullTextInstalled') AS FullTextEnabled;
```

### Database Inventory Per Instance

```sql
-- All databases with size and configuration
SELECT
    d.name AS database_name,
    d.database_id,
    d.compatibility_level,
    d.collation_name,
    d.recovery_model_desc AS recovery_model,
    d.is_read_only,
    d.is_auto_close_on,
    d.is_auto_shrink_on,
    d.snapshot_isolation_state_desc,
    d.is_read_committed_snapshot_on AS rcsi_enabled,
    d.is_encrypted AS tde_enabled,
    d.is_broker_enabled AS service_broker,
    -- Size information
    SUM(CASE WHEN mf.type = 0 THEN mf.size END) * 8 / 1024 AS data_size_mb,
    SUM(CASE WHEN mf.type = 1 THEN mf.size END) * 8 / 1024 AS log_size_mb,
    d.create_date,
    -- Last backup info
    (SELECT MAX(backup_finish_date) FROM msdb.dbo.backupset bs
     WHERE bs.database_name = d.name AND bs.type = 'D') AS last_full_backup
FROM sys.databases d
LEFT JOIN sys.master_files mf ON d.database_id = mf.database_id
WHERE d.database_id > 4  -- exclude system databases
GROUP BY
    d.name, d.database_id, d.compatibility_level, d.collation_name,
    d.recovery_model_desc, d.is_read_only, d.is_auto_close_on,
    d.is_auto_shrink_on, d.snapshot_isolation_state_desc,
    d.is_read_committed_snapshot_on, d.is_encrypted,
    d.is_broker_enabled, d.create_date
ORDER BY d.name;
```

### Cross-Database Dependencies

```sql
-- Objects that reference other databases (3-part naming)
SELECT
    DB_NAME() AS source_database,
    OBJECT_SCHEMA_NAME(d.referencing_id) AS source_schema,
    OBJECT_NAME(d.referencing_id) AS source_object,
    d.referenced_database_name AS target_database,
    d.referenced_schema_name AS target_schema,
    d.referenced_entity_name AS target_object,
    o.type_desc AS source_object_type
FROM sys.sql_expression_dependencies d
JOIN sys.objects o ON d.referencing_id = o.object_id
WHERE d.referenced_database_name IS NOT NULL
  AND d.referenced_database_name <> DB_NAME()
ORDER BY d.referenced_database_name, d.referenced_entity_name;
```

### Cross-Database Dependency Summary

```sql
-- Summary: which databases depend on which
SELECT DISTINCT
    DB_NAME() AS source_database,
    d.referenced_database_name AS depends_on_database,
    COUNT(DISTINCT d.referencing_id) AS referencing_object_count,
    COUNT(DISTINCT d.referenced_entity_name) AS referenced_object_count
FROM sys.sql_expression_dependencies d
WHERE d.referenced_database_name IS NOT NULL
  AND d.referenced_database_name <> DB_NAME()
GROUP BY d.referenced_database_name
ORDER BY referencing_object_count DESC;
```

## Replication Topology

### Publication Inventory

```sql
-- Transactional and snapshot publications
SELECT
    p.name AS publication_name,
    p.description,
    CASE p.repl_freq
        WHEN 0 THEN 'Transactional'
        WHEN 1 THEN 'Snapshot'
    END AS replication_type,
    DB_NAME() AS publisher_database,
    p.immediate_sync,
    p.allow_push,
    p.allow_pull,
    p.independent_agent
FROM dbo.syspublications p;

-- Published articles (tables/views/procedures)
SELECT
    p.name AS publication_name,
    a.name AS article_name,
    a.source_owner AS schema_name,
    a.source_object AS object_name,
    CASE a.type
        WHEN 1  THEN 'Log-based'
        WHEN 3  THEN 'Log-based with manual filter'
        WHEN 5  THEN 'Log-based with manual view'
        WHEN 7  THEN 'Log-based with manual filter and view'
        WHEN 8  THEN 'Stored procedure execution'
        WHEN 24 THEN 'Serializable stored procedure'
        WHEN 32 THEN 'Stored procedure (schema only)'
        WHEN 64 THEN 'View (schema only)'
        WHEN 128 THEN 'Function (schema only)'
    END AS article_type,
    a.dest_owner AS destination_schema,
    a.dest_table AS destination_object
FROM dbo.syspublications p
JOIN dbo.sysarticles a ON p.pubid = a.pubid
ORDER BY p.name, a.name;
```

### Subscription Inventory

```sql
-- Subscriptions to transactional publications
SELECT
    p.name AS publication_name,
    s.srvname AS subscriber_server,
    s.dest_db AS subscriber_database,
    CASE s.subscription_type
        WHEN 0 THEN 'Push'
        WHEN 1 THEN 'Pull'
    END AS subscription_type,
    CASE s.sync_type
        WHEN 1 THEN 'Automatic'
        WHEN 2 THEN 'No synchronization'
    END AS sync_type,
    s.status
FROM dbo.syspublications p
JOIN dbo.syssubscriptions s ON p.pubid = s.artid
ORDER BY p.name, s.srvname;
```

### Merge Replication

```sql
-- Merge publications
SELECT
    p.name AS publication_name,
    p.description,
    DB_NAME() AS publisher_database,
    p.retention AS retention_period,
    p.retention_period_unit,
    p.snapshot_ready,
    p.conflict_logging,
    p.conflict_retention
FROM dbo.sysmergepublications p;

-- Merge articles with conflict resolution
SELECT
    p.name AS publication_name,
    a.name AS article_name,
    a.source_object_name,
    a.resolver_info AS conflict_resolver,
    a.column_tracking,
    a.upload_options,
    a.download_only
FROM dbo.sysmergepublications p
JOIN dbo.sysmergearticles a ON p.pubid = a.pubid
ORDER BY p.name, a.name;
```

**Migration impact**: Replication must be replaced by an equivalent mechanism:
- Transactional replication → AWS DMS CDC, Debezium, or application-level events
- Merge replication → Application-level conflict resolution
- Snapshot replication → Scheduled ETL / data sync jobs

## Always On Availability Groups

```sql
-- Availability Group configuration
SELECT
    ag.name AS ag_name,
    ag.automated_backup_preference_desc,
    ag.failure_condition_level,
    ag.health_check_timeout,
    ar.replica_server_name,
    ar.availability_mode_desc,  -- SYNCHRONOUS_COMMIT or ASYNCHRONOUS_COMMIT
    ar.failover_mode_desc,      -- AUTOMATIC or MANUAL
    ar.session_timeout,
    ar.primary_role_allow_connections_desc,
    ar.secondary_role_allow_connections_desc,
    ars.role_desc AS current_role,
    ars.operational_state_desc,
    ars.connected_state_desc,
    ars.synchronization_health_desc
FROM sys.availability_groups ag
JOIN sys.availability_replicas ar ON ag.group_id = ar.group_id
JOIN sys.dm_hadr_availability_replica_states ars
    ON ar.replica_id = ars.replica_id
ORDER BY ag.name, ar.replica_server_name;

-- Databases in Availability Groups
SELECT
    ag.name AS ag_name,
    d.name AS database_name,
    drs.synchronization_state_desc,
    drs.synchronization_health_desc,
    drs.is_suspended,
    drs.log_send_queue_size,
    drs.redo_queue_size
FROM sys.availability_groups ag
JOIN sys.availability_databases_cluster dc ON ag.group_id = dc.group_id
JOIN sys.databases d ON dc.database_name = d.name
LEFT JOIN sys.dm_hadr_database_replica_states drs
    ON d.database_id = drs.database_id
ORDER BY ag.name, d.name;

-- Listener endpoints
SELECT
    agl.dns_name AS listener_name,
    agl.port,
    agl.ip_configuration_string_from_cluster,
    ag.name AS ag_name
FROM sys.availability_group_listeners agl
JOIN sys.availability_groups ag ON agl.group_id = ag.group_id;
```

**Migration impact**: Always On AG provides HA/DR that must be replicated:
- Multi-AZ Aurora for automatic failover
- Aurora read replicas for read scaling
- Cross-region replicas for DR

## Security Architecture

### Login and User Mapping

```sql
-- Server-level logins
SELECT
    sp.name AS login_name,
    sp.type_desc AS login_type,
    sp.is_disabled,
    sp.create_date,
    sp.modify_date,
    sp.default_database_name,
    sp.default_language_name,
    -- Server-level role membership
    STRING_AGG(sr.name, ', ') AS server_roles
FROM sys.server_principals sp
LEFT JOIN sys.server_role_members srm ON sp.principal_id = srm.member_principal_id
LEFT JOIN sys.server_principals sr ON srm.role_principal_id = sr.principal_id
WHERE sp.type IN ('S', 'U', 'G')  -- SQL, Windows, Group
  AND sp.name NOT LIKE '##%'       -- exclude internal
  AND sp.name NOT IN ('sa', 'public')
GROUP BY sp.name, sp.type_desc, sp.is_disabled, sp.create_date,
    sp.modify_date, sp.default_database_name, sp.default_language_name
ORDER BY sp.name;

-- Database-level users mapped to logins
SELECT
    dp.name AS user_name,
    dp.type_desc AS user_type,
    dp.authentication_type_desc,
    sp.name AS login_name,
    dp.default_schema_name,
    -- Database role membership
    STRING_AGG(r.name, ', ') AS database_roles
FROM sys.database_principals dp
LEFT JOIN sys.server_principals sp ON dp.sid = sp.sid
LEFT JOIN sys.database_role_members drm ON dp.principal_id = drm.member_principal_id
LEFT JOIN sys.database_principals r ON drm.role_principal_id = r.principal_id
WHERE dp.type IN ('S', 'U', 'G', 'E', 'X')
  AND dp.name NOT IN ('dbo', 'guest', 'INFORMATION_SCHEMA', 'sys', 'public')
GROUP BY dp.name, dp.type_desc, dp.authentication_type_desc,
    sp.name, dp.default_schema_name
ORDER BY dp.name;
```

### Schema-Level Permissions

```sql
-- Object-level permissions
SELECT
    dp.name AS principal_name,
    dp.type_desc AS principal_type,
    p.permission_name,
    p.state_desc AS grant_type,  -- GRANT, DENY, REVOKE
    SCHEMA_NAME(o.schema_id) AS schema_name,
    o.name AS object_name,
    o.type_desc AS object_type,
    p.class_desc
FROM sys.database_permissions p
JOIN sys.database_principals dp ON p.grantee_principal_id = dp.principal_id
LEFT JOIN sys.objects o ON p.major_id = o.object_id
WHERE p.class IN (0, 1)  -- Database-level and object-level
  AND dp.name NOT IN ('dbo', 'public', 'guest')
ORDER BY dp.name, o.name;

-- Schema-level permissions
SELECT
    dp.name AS principal_name,
    p.permission_name,
    p.state_desc,
    s.name AS schema_name
FROM sys.database_permissions p
JOIN sys.database_principals dp ON p.grantee_principal_id = dp.principal_id
JOIN sys.schemas s ON p.major_id = s.schema_id
WHERE p.class = 3  -- Schema
ORDER BY dp.name, s.name;
```

### Dynamic Data Masking

```sql
-- Columns with dynamic data masking
SELECT
    SCHEMA_NAME(t.schema_id) AS schema_name,
    t.name AS table_name,
    c.name AS column_name,
    c.is_masked,
    mc.masking_function
FROM sys.masked_columns mc
JOIN sys.columns c ON mc.object_id = c.object_id
    AND mc.column_id = c.column_id
JOIN sys.tables t ON c.object_id = t.object_id
WHERE c.is_masked = 1
ORDER BY t.name, c.column_id;
```

### Row-Level Security

```sql
-- Row-Level Security policies
SELECT
    p.name AS policy_name,
    p.is_enabled,
    SCHEMA_NAME(p.schema_id) AS policy_schema,
    pred.target_schema AS target_schema,
    OBJECT_NAME(pred.target_object_id) AS target_table,
    CASE pred.operation
        WHEN 0 THEN 'AFTER INSERT'
        WHEN 1 THEN 'AFTER UPDATE'
        WHEN 2 THEN 'BEFORE UPDATE'
        WHEN 3 THEN 'BEFORE DELETE'
    END AS operation,
    pred.predicate_type_desc,
    OBJECT_NAME(pred.predicate_definition) AS filter_function
FROM sys.security_policies p
JOIN sys.security_predicates pred ON p.object_id = pred.object_id
ORDER BY p.name;
```

### Always Encrypted

```sql
-- Always Encrypted column master keys and column encryption keys
SELECT
    cmk.name AS master_key_name,
    cmk.key_store_provider_name,
    cmk.key_path,
    cek.name AS encryption_key_name,
    c.name AS column_name,
    OBJECT_NAME(c.object_id) AS table_name,
    c.encryption_type_desc,
    c.encryption_algorithm_name
FROM sys.column_master_keys cmk
JOIN sys.column_encryption_key_values cekv
    ON cmk.column_master_key_id = cekv.column_master_key_id
JOIN sys.column_encryption_keys cek
    ON cekv.column_encryption_key_id = cek.column_encryption_key_id
JOIN sys.columns c ON cek.column_encryption_key_id = c.column_encryption_key_id
WHERE c.encryption_type IS NOT NULL
ORDER BY OBJECT_NAME(c.object_id), c.name;
```

**Migration impact**: Security architecture must be mapped to AWS equivalents:
- SQL logins → IAM database authentication or Secrets Manager
- Windows auth → Kerberos trust or IAM
- Role hierarchy → PostgreSQL role grants
- Dynamic data masking → Application-layer masking or pgmasking
- Row-Level Security → PostgreSQL RLS policies
- Always Encrypted → Application-layer encryption or column-level encryption

## Storage Patterns

### Filegroup Analysis

```sql
-- Filegroup and file layout
SELECT
    fg.name AS filegroup_name,
    fg.type_desc,
    fg.is_default,
    fg.is_read_only,
    f.name AS file_name,
    f.physical_name,
    f.type_desc AS file_type,
    CAST(f.size * 8.0 / 1024 AS DECIMAL(18,2)) AS size_mb,
    CAST(f.max_size * 8.0 / 1024 AS DECIMAL(18,2)) AS max_size_mb,
    CAST(f.growth * 8.0 / 1024 AS DECIMAL(18,2)) AS growth_mb,
    f.is_percent_growth
FROM sys.filegroups fg
JOIN sys.database_files f ON fg.data_space_id = f.data_space_id
ORDER BY fg.name, f.name;
```

### Table Partitioning

```sql
-- Partitioned tables with function and scheme details
SELECT
    SCHEMA_NAME(t.schema_id) AS schema_name,
    t.name AS table_name,
    ps.name AS partition_scheme,
    pf.name AS partition_function,
    pf.type_desc AS function_type,
    pf.fanout AS partition_count,
    c.name AS partition_column,
    -- Partition boundary values
    prv.value AS boundary_value,
    p.partition_number,
    p.rows AS row_count,
    CAST(SUM(au.used_pages) * 8.0 / 1024 AS DECIMAL(18,2)) AS size_mb
FROM sys.tables t
JOIN sys.indexes i ON t.object_id = i.object_id AND i.index_id <= 1
JOIN sys.partition_schemes ps ON i.data_space_id = ps.data_space_id
JOIN sys.partition_functions pf ON ps.function_id = pf.function_id
JOIN sys.index_columns ic ON i.object_id = ic.object_id
    AND i.index_id = ic.index_id AND ic.partition_ordinal > 0
JOIN sys.columns c ON t.object_id = c.object_id AND ic.column_id = c.column_id
JOIN sys.partitions p ON i.object_id = p.object_id AND i.index_id = p.index_id
LEFT JOIN sys.partition_range_values prv
    ON pf.function_id = prv.function_id
    AND p.partition_number - pf.boundary_value_on_right = prv.boundary_id
LEFT JOIN sys.allocation_units au ON p.partition_id = au.container_id
GROUP BY SCHEMA_NAME(t.schema_id), t.name, ps.name, pf.name,
    pf.type_desc, pf.fanout, c.name, prv.value, p.partition_number, p.rows
ORDER BY t.name, p.partition_number;
```

### Compression and Columnstore

```sql
-- Tables with data compression
SELECT
    SCHEMA_NAME(t.schema_id) AS schema_name,
    t.name AS table_name,
    i.name AS index_name,
    i.type_desc AS index_type,
    p.data_compression_desc AS compression_type,
    p.rows AS row_count
FROM sys.partitions p
JOIN sys.tables t ON p.object_id = t.object_id
JOIN sys.indexes i ON p.object_id = i.object_id AND p.index_id = i.index_id
WHERE p.data_compression > 0  -- 1=ROW, 2=PAGE, 3=COLUMNSTORE, 4=COLUMNSTORE_ARCHIVE
ORDER BY t.name, i.name;

-- Columnstore indexes
SELECT
    SCHEMA_NAME(t.schema_id) AS schema_name,
    t.name AS table_name,
    i.name AS index_name,
    i.type_desc,
    STRING_AGG(c.name, ', ') WITHIN GROUP (ORDER BY ic.key_ordinal) AS columns
FROM sys.indexes i
JOIN sys.tables t ON i.object_id = t.object_id
JOIN sys.index_columns ic ON i.object_id = ic.object_id AND i.index_id = ic.index_id
JOIN sys.columns c ON ic.object_id = c.object_id AND ic.column_id = c.column_id
WHERE i.type IN (5, 6)  -- 5=Clustered columnstore, 6=Nonclustered columnstore
GROUP BY SCHEMA_NAME(t.schema_id), t.name, i.name, i.type_desc
ORDER BY t.name;
```

## Dependency Analysis

### Object Dependency Graph

```sql
-- Full dependency map using sys.sql_expression_dependencies
SELECT
    OBJECT_SCHEMA_NAME(d.referencing_id) AS referencing_schema,
    OBJECT_NAME(d.referencing_id) AS referencing_object,
    o1.type_desc AS referencing_type,
    COALESCE(d.referenced_schema_name,
        OBJECT_SCHEMA_NAME(d.referenced_id)) AS referenced_schema,
    COALESCE(d.referenced_entity_name,
        OBJECT_NAME(d.referenced_id)) AS referenced_object,
    COALESCE(o2.type_desc, 'UNKNOWN') AS referenced_type,
    d.referenced_database_name,
    d.referenced_server_name,
    d.is_ambiguous
FROM sys.sql_expression_dependencies d
JOIN sys.objects o1 ON d.referencing_id = o1.object_id
LEFT JOIN sys.objects o2 ON d.referenced_id = o2.object_id
WHERE o1.is_ms_shipped = 0
ORDER BY OBJECT_NAME(d.referencing_id), d.referenced_entity_name;
```

### Referencing Entities (What Depends on This Object)

```sql
-- Find all objects that reference a specific table
SELECT
    referencing_schema_name,
    referencing_entity_name,
    referencing_class_desc
FROM sys.dm_sql_referencing_entities('dbo.Orders', 'OBJECT');
```

### Referenced Entities (What This Object Depends On)

```sql
-- Find all objects that a specific stored procedure references
SELECT
    referenced_schema_name,
    referenced_entity_name,
    referenced_minor_name AS referenced_column,
    is_caller_dependent,
    is_ambiguous
FROM sys.dm_sql_referenced_entities('dbo.usp_ProcessOrders', 'OBJECT');
```

## Linked Server Mapping

### Linked Server Inventory

```sql
-- All linked servers with provider details
SELECT
    s.name AS linked_server_name,
    s.product,
    s.provider,
    s.data_source,
    s.catalog AS default_catalog,
    s.provider_string,
    s.is_linked,
    s.is_remote_login_enabled,
    s.is_data_access_enabled,
    s.is_rpc_out_enabled,
    -- Login mappings
    ll.uses_self_credential,
    sp.name AS local_login,
    ll.remote_name AS remote_login
FROM sys.servers s
LEFT JOIN sys.linked_logins ll ON s.server_id = ll.server_id
LEFT JOIN sys.server_principals sp ON ll.local_principal_id = sp.principal_id
WHERE s.is_linked = 1
ORDER BY s.name;
```

### Linked Server Usage Detection

```sql
-- Find all references to linked servers in code
-- Search for 4-part naming: [LinkedServer].[Database].[Schema].[Object]
SELECT
    OBJECT_SCHEMA_NAME(d.referencing_id) AS source_schema,
    OBJECT_NAME(d.referencing_id) AS source_object,
    d.referenced_server_name AS linked_server,
    d.referenced_database_name AS remote_database,
    d.referenced_schema_name AS remote_schema,
    d.referenced_entity_name AS remote_object
FROM sys.sql_expression_dependencies d
WHERE d.referenced_server_name IS NOT NULL
ORDER BY d.referenced_server_name, d.referenced_entity_name;
```

### Distributed Query Patterns

```sql
-- OPENQUERY usage (executes query on remote server)
-- Must be found by text search in stored procedure source code
SELECT
    OBJECT_SCHEMA_NAME(sm.object_id) AS schema_name,
    OBJECT_NAME(sm.object_id) AS object_name,
    sm.definition
FROM sys.sql_modules sm
WHERE sm.definition LIKE '%OPENQUERY%'
   OR sm.definition LIKE '%OPENROWSET%'
   OR sm.definition LIKE '%OPENDATASOURCE%';
```

**Migration impact**: Linked servers represent external system dependencies:
- SQL Server linked servers → postgres_fdw in PostgreSQL
- Oracle linked servers → oracle_fdw or API-based integration
- File-based linked servers → S3 + aws_s3 extension
- Generic ODBC → Application-layer connections or Lambda

## Full-Text Search

```sql
-- Full-text catalogs and indexes
SELECT
    fc.name AS catalog_name,
    SCHEMA_NAME(t.schema_id) AS schema_name,
    t.name AS table_name,
    fi.unique_index_id,
    STRING_AGG(c.name, ', ') AS indexed_columns,
    fi.change_tracking_state_desc,
    fi.is_enabled
FROM sys.fulltext_indexes fi
JOIN sys.fulltext_catalogs fc ON fi.fulltext_catalog_id = fc.fulltext_catalog_id
JOIN sys.tables t ON fi.object_id = t.object_id
JOIN sys.fulltext_index_columns fic ON fi.object_id = fic.object_id
JOIN sys.columns c ON fic.object_id = c.object_id
    AND fic.column_id = c.column_id
GROUP BY fc.name, SCHEMA_NAME(t.schema_id), t.name,
    fi.unique_index_id, fi.change_tracking_state_desc, fi.is_enabled
ORDER BY t.name;
```

**Migration impact**: SQL Server Full-Text Search → PostgreSQL tsvector/tsquery
or Amazon OpenSearch.

## Architecture Decomposition Summary

When mapping a SQL Server architecture, inventory in this order:

1. **Instance topology** — how many instances, versions, editions, clustering
2. **Database catalog** — databases per instance, sizes, compatibility levels
3. **Cross-database dependencies** — 3-part naming references between databases
4. **Replication topology** — publishers, subscribers, replication type
5. **Always On configuration** — replicas, sync mode, failover mode
6. **Security model** — logins, users, roles, permissions, encryption
7. **Storage architecture** — filegroups, partitioning, compression
8. **Linked servers** — remote server connections and their usage
9. **Object dependency graph** — full map of what depends on what
10. **Full-text search** — catalogs and indexed tables
11. **Service Broker** — queues and message types (if used)
12. **SSIS/SSRS/SSAS** — ancillary services and their databases
