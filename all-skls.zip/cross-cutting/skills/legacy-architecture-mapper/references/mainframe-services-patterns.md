# Mainframe Services Patterns

Legacy Architecture Mapper reference for mainframe binding points
beyond COBOL/JCL source. Edges that tie a program to its
deployment reality — do not ignore them.

## RACF (Security)
Source of truth for *who* can run *what*. Dataset profiles, resource
classes (FACILITY, TSOAUTH, DSN for DB2, CICS for TRANs), and group
membership define effective boundaries.
- Each RACF profile is a node.
- Grants are edges from user/group to protected resource (program,
  file, dataset, TRANSID, DB2 plan).
- Missing grants often reveal obsolete programs and hidden callers.

## Control-M (Job Scheduling)
JCL does not reveal when a job runs or what triggers it. Parse
Control-M defs for `JOBNAME`, `SCHED_TABLE`, `IN CONDITION`,
`OUT CONDITION`, `TIME FROM/UNTIL`, predecessors, successors.
- Each job is a node.
- `IN CONDITION` -> job -> `OUT CONDITION` forms a cross-app DAG
  that exposes coupling invisible in code.

## JES2 Output Routing
- `JES2FTP` — FTP transmits spool output to a partner or
  distributed host. Egress edge from producing job to destination.
- `JES2PDF` — PDF converts and routes spool output; same edge.
- Capture destination host, dataset pattern, schedule.

## SAG Broker (EntireX)
Client/server RPC bridge exposing NATURAL/ADABAS or COBOL services
to distributed callers.
- Identify by `BROKER-ID` and service/class/server triples in
  `etbsrv.cfg`, ACI/RPC clients, .NET wrappers.
- Server = mainframe-hosted service node; client = distributed
  caller. Emit cross-platform edges.

## Pitney Bowes Finalist (Address Standardization)
CICS/batch callable module that normalizes US addresses (ZIP+4,
DPV). Invoked via `CALL 'FINLST'` or a CICS LINK.
- External service node. Capture reference data version (monthly
  USPS update) — downstream rules depend on it.

## Output
Nodes: RACF profile, Control-M job, JES2 destination, Broker
service, Finalist. Edges: `grants`, `triggers`, `routes_to`,
`rpc_calls`, `standardizes`.
