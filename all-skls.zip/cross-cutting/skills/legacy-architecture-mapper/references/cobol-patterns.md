# COBOL / Mainframe Patterns

Legacy Architecture Mapper reference for COBOL, CICS, DB2, IMS, JCL.
Each item is a first-class node or edge.

## Technology Detection
- Source: `.cbl`, `.cob`; Copybooks: `.cpy`, `.copy`
- JCL: `.jcl`, `.proc`; CICS maps: `.bms`; DB2 bind: `.dbrm`

## Program Structure
- `PROGRAM-ID.` — unique program id; primary graph node.
- Four divisions drive decomposition:
  - `IDENTIFICATION DIVISION` — metadata.
  - `ENVIRONMENT DIVISION` — `FILE-CONTROL` binds DD names to datasets.
  - `DATA DIVISION` — `FILE`, `WORKING-STORAGE`, `LINKAGE` sections.
  - `PROCEDURE DIVISION` — paragraphs and sections.

## Copybooks (COPY)
- `COPY CUSTREC.` inlines a record layout at compile time.
- One copybook used by N programs = N coupling edges.

## Subprogram Graph (CALL)
- `CALL 'VALIDATE' USING WS-AREA.` — static call.
- `CALL WS-PGM USING ...` — dynamic; flag `edge_type=dynamic_call`.
- Emit `caller -> callee` edges.

## CICS Transactions
- `EXEC CICS ... END-EXEC`: `SEND MAP`, `RECEIVE MAP`, `LINK`, `XCTL`,
  `START TRANSID`, `READ FILE`, `WRITEQ TS/TD`.
- PCT/PPT entries map `TRANSID` -> program. `LINK`/`XCTL` are edges.

## DB2 (EXEC SQL)
- `EXEC SQL SELECT ... END-EXEC` — bound via DBRM/PLAN.
- Each table is a data node; PLAN name is a deployment node.

## IMS DL/I
- `CALL 'CBLTDLI' USING function, PCB, IOAREA, SSA.`
- PSB/PCB in JCL identify DB views; edge to IMS segments.

## JCL and Scheduling
- `//STEP01 EXEC PGM=PAYCALC` — step invokes a program (edge).
- `//STEP02 EXEC PROC=BILLPROC` — step invokes a cataloged PROC
  (compose sub-DAG).
- `//INPUT DD DSN=PROD.CUST.MASTER,DISP=SHR` — DD binds logical name
  to dataset (data edge).
- GDG: `PROD.CUST.HIST(+1)`, `(0)`, `(-1)` — versioned dataset lineage;
  capture the base name.

## Output
Nodes: programs, copybooks, CICS transactions, DB2 tables, IMS
segments, JCL jobs/steps, datasets. Edges: CALL, COPY, LINK/XCTL,
EXEC SQL, DL/I, DD bindings.
