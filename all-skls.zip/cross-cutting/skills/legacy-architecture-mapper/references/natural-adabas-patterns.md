# NATURAL/ADABAS Architecture Patterns

Reference for Legacy Architecture Mapper when analyzing Software AG NATURAL 4GL
applications backed by ADABAS databases. Covers module boundaries, dependencies,
coupling analysis, and deployment topology.

## Technology Detection

Confirm NATURAL/ADABAS by checking for:
- NATURAL source files: `.NSP`, `.NSN`, `.NSS`, `.NSH`, `.NSM`, `.NSL`, `.NSG`, `.NSA`, `.NSC`
- `DEFINE DATA` / `END-DEFINE` blocks in source
- ADABAS DDM references: `DEFINE DATA LOCAL USING ddm-name`
- JCL with `NATBATCH` or `NATRJE` program references
- `CMSYNIN` DD statements in JCL (NATURAL command input)
- `NATPARM` or `NATCONF` configuration modules
- FUSER, FNAT, FDIC file references in JCL or configuration
- Natural Security (NSC) configuration files

## Library Structure Analysis

### SYSLIB Inventory

Every NATURAL application is organized into **libraries** (not directories or packages).
The library is the primary organizational unit and security boundary.

**Inventory approach:**
1. List all NATURAL libraries from the FUSER (user file area)
2. For each library, count: programs, subprograms, subroutines, maps, copycodes, LDAs, GDAs, PDAs
3. Document the steplib chain for each library
4. Note which libraries are "infrastructure" (shared by many) vs "application" (domain-specific)

**Example inventory:**
```
Library     | Programs | Subpgms | Subroutines | Maps | Copycodes | Steplib Chain
------------|----------|---------|-------------|------|-----------|------------------
RMSLIB      |    145   |    89   |     34      |  67  |    52     | SYSLIB, UTILLIB
CAISLIB     |    203   |   127   |     56      |  94  |    71     | SYSLIB, UTILLIB, SHAREDLIB
SYSLIB      |     12   |    45   |     28      |   3  |    38     | SYSTEM
UTILLIB     |      3   |    67   |     15      |   0  |    22     | SYSTEM
SHAREDLIB   |      8   |    34   |     12      |   5  |    18     | SYSLIB, UTILLIB
REPORTLIB   |     78   |    23   |     11      |  42  |    15     | SYSLIB, RMSLIB, CAISLIB
BATCHLIB    |     34   |    19   |      8      |   0  |    12     | SYSLIB, RMSLIB
TESTLIB     |     56   |    31   |     14      |  28  |     9     | RMSLIB (mirrors prod)
```

### Steplib Chain Analysis

Steplib chains define search order for CALLNAT resolution:
```
When RMSLIB calls CALLNAT 'VALIDATE-SSN':
  1. Search RMSLIB          (current library)
  2. Search SYSLIB          (first steplib)
  3. Search UTILLIB         (second steplib)
  4. Search SYSTEM          (implicit last resort)
  5. NAT0082 error if not found
```

**Steplib hazards:**
- **Override shadowing**: A subprogram in RMSLIB with the same name as one in SYSLIB
  overrides it. This may be intentional (library-specific behavior) or a bug.
- **Diamond dependencies**: If RMSLIB steplibs to SYSLIB and UTILLIB, and UTILLIB
  also steplibs to SYSLIB, SYSLIB modules may be found via different paths.
- **Missing steplibs**: If a steplib chain is changed (library removed), programs
  that relied on the transitive dependency will fail at runtime.

**Analysis steps:**
1. For each library, extract the steplib chain from NATPARM or library definition
2. Build a directed graph: Library -> Steplib (dependency)
3. Identify shared infrastructure libraries (high in-degree in the steplib graph)
4. Identify leaf application libraries (zero in-degree)
5. Check for cyclic steplib dependencies (would cause infinite search, NATURAL prevents this)

## Program Call Graph

### CALLNAT / PERFORM Chain Analysis

Build the call graph by extracting all inter-program references:

**CALLNAT** (crosses program boundaries):
```natural
CALLNAT 'VALIDATE-SSN' #SSN #VALID #ERROR-MSG
CALLNAT 'FORMAT-DATE' #INTERNAL-DATE #DISPLAY-DATE
CALLNAT 'LOG-AUDIT' #ACTION #DETAILS #USER #TIMESTAMP
```

**FETCH / FETCH RETURN** (transfers control between programs):
```natural
FETCH 'AIRMAN-DETAIL'           /* One-way transfer; no return */
FETCH RETURN 'CERT-RENEWAL'     /* Transfer with return to caller */
```

**PERFORM** (internal subroutines within same source file):
```natural
PERFORM VALIDATE-INPUT
PERFORM CALCULATE-FEE
PERFORM UPDATE-DATABASE
```

**Graph construction algorithm:**
1. For each source file, extract all `CALLNAT 'name'` references
2. For each source file, extract all `FETCH 'name'` and `FETCH RETURN 'name'` references
3. Resolve target names against library + steplib chain to determine which physical module is called
4. Build directed graph: caller -> callee with edge type (CALLNAT, FETCH, FETCH RETURN)
5. Compute graph metrics:
   - **Fan-in**: Number of distinct callers per module (high = shared service)
   - **Fan-out**: Number of distinct callees per module (high = orchestrator/controller)
   - **Betweenness centrality**: Modules that sit on many call paths (high = critical dependency)

**Example call graph metrics:**
```
Module              | Fan-In | Fan-Out | Type
--------------------|--------|---------|------
VALIDATE-SSN        |    47  |      2  | Shared validation service
FORMAT-DATE         |    83  |      0  | Utility (leaf)
LOG-AUDIT           |   112  |      3  | Infrastructure (logging)
AIRMAN-MAIN-MENU    |     1  |     12  | Orchestrator (high fan-out)
CERT-RENEWAL        |     4  |      8  | Business process controller
DB-ACCESS-AIRMEN    |    28  |      1  | Data access layer
```

### Stack-Based Navigation Analysis
```natural
/* Menu program pushes context onto stack before FETCH */
STACK TOP DATA #AIRMAN-ID #ACTION-CODE #RETURN-MENU
FETCH 'AIRMAN-DETAIL'

/* Target program reads from stack */
INPUT #AIRMAN-ID #ACTION-CODE #RETURN-MENU
/* ... process ... */
FETCH #RETURN-MENU    /* Dynamic return — program name from stack */
```

**Stack navigation hazards:**
- Dynamic FETCH with variable program name breaks static analysis
- Stack data types must match between pusher and popper (no compile-time check)
- Deep stack chains (A->B->C->D) can lose context if any step corrupts the stack
- Grep for `FETCH #variable` to identify dynamic navigation

## Data Coupling Analysis

### Shared GDA (Global Data Area) Coupling

GDAs create tight coupling between all programs that reference them:

```natural
/* GDA-AIRMAN-SESSION.NSG */
DEFINE DATA GLOBAL
  1 GDA-SESSION-INFO
    2 GDA-CURRENT-AIRMAN-ID  (A9)
    2 GDA-CURRENT-CERT-TYPE  (A10)
    2 GDA-USER-ROLE          (A20)
    2 GDA-LAST-ACTION        (A10)
    2 GDA-EDIT-MODE          (L)
  1 GDA-SEARCH-CONTEXT
    2 GDA-SEARCH-TYPE        (A1)
    2 GDA-SEARCH-VALUE       (A50)
    2 GDA-RESULT-COUNT       (I4)
END-DEFINE
```

**GDA coupling analysis:**
1. List all GDAs (`.NSG` files)
2. For each GDA, find all programs that reference it (`GLOBAL USING gda-name`)
3. Build a coupling matrix: GDA -> list of programs
4. For each GDA field, determine which programs WRITE to it vs READ from it
5. Programs that write to the same GDA field are strongly coupled (shared mutable state)

**Example GDA coupling matrix:**
```
GDA: GDA-AIRMAN-SESSION
  Writers:                          Readers:
  GDA-CURRENT-AIRMAN-ID:           
    AIRMAN-SEARCH (writes)          AIRMAN-DETAIL (reads)
    AIRMAN-SELECT (writes)          CERT-DISPLAY (reads)
                                    MED-CHECK (reads)
                                    REPORT-AIRMAN (reads)
  GDA-EDIT-MODE:
    AIRMAN-DETAIL (writes)          AIRMAN-UPDATE (reads)
    AIRMAN-UPDATE (writes)          SAVE-CONFIRM (reads)
```

### LDA (Local Data Area) Reuse

LDAs shared across programs indicate structural coupling:
```natural
/* Multiple programs reference the same LDA */
DEFINE DATA LOCAL USING LDA-AIRMAN-RECORD
```

**LDA coupling analysis:**
1. List all LDAs (`.NSL` files)
2. For each LDA, find all programs that include it (`LOCAL USING lda-name`)
3. LDAs used by many programs represent shared data contracts
4. Changes to an LDA affect all programs that use it (compile-time dependency)

### ADABAS File Sharing

Build a file access matrix showing which programs access which ADABAS files:

**Step 1: Extract DDM references**
Grep for `DEFINE DATA LOCAL` blocks and extract the view definitions:
```natural
DEFINE DATA LOCAL
  1 AIRMEN-VIEW VIEW OF AIRMEN-FILE    /* References DDM AIRMEN-FILE */
    2 AIRMAN-ID
    2 AIRMAN-NAME
    2 CERT-TYPE
  1 CERT-VIEW VIEW OF CERT-FILE        /* References DDM CERT-FILE */
    2 CERT-ID
    2 CERT-STATUS
END-DEFINE
```

**Step 2: Classify access type per file per program**
- READ / FIND / HISTOGRAM = Read access
- GET (without UPDATE/DELETE following) = Read access
- GET + UPDATE = Write access
- GET + DELETE = Write access
- STORE = Write access

**Step 3: Build the access matrix**
```
                  | AIRMEN | CERT | MEDICAL | EXAM | RATE | AUDIT
Program           | FILE   | FILE | FILE    | FILE | TABLE| LOG
------------------|--------|------|---------|------|------|------
AIRMAN-INQUIRY    |   R    |  R   |    R    |      |      |
AIRMAN-UPDATE     |   RW   |  R   |         |      |      |  W
CERT-RENEWAL      |   R    |  RW  |    R    |  R   |  R   |  W
CERT-ISSUE        |   R    |  W   |    R    |  R   |  R   |  W
MED-EXAM-ENTRY    |   R    |      |    RW   |  RW  |      |  W
BATCH-REPORT      |   R    |  R   |    R    |  R   |  R   |
BATCH-ARCHIVE     |   RW   |  RW  |    RW   |  RW  |      |  W
```

**Key insights from file access matrix:**
- **Write coupling**: Programs that write to the same file can conflict (lock contention)
- **Read-only programs**: Candidates for read replica or CQRS pattern
- **Write-heavy programs**: Candidates for async processing or queueing
- **AUDIT-LOG writers**: Every write-path should write to audit (compliance requirement)

## MAP Coupling Analysis

### Program-to-Map Mapping
```
Map Name          | Used By Programs                    | Fields | Shared?
------------------|-------------------------------------|--------|--------
AIRMAN-SEARCH     | AIRMAN-SEARCH-PGM                   |   5    | No
AIRMAN-DETAIL     | AIRMAN-INQ, AIRMAN-UPD              |  22    | Yes
AIRMAN-LIST       | AIRMAN-SEARCH-PGM, REPORT-AIRMAN    |  8x15  | Yes
CERT-DISPLAY      | CERT-INQ, CERT-RENEW                |  18    | Yes
MAIN-MENU         | MAIN-MENU-PGM                       |   6    | No
```

**Map sharing analysis:**
- Maps used by multiple programs indicate shared UI contracts
- Shared maps mean changes affect multiple programs (coupling)
- Map arrays (e.g., 8 fields x 15 rows) indicate list/table screens
- Maps with many fields (>20) may serve multiple purposes (overloaded screen)

### Map-to-DDM Relationship
Maps often mirror database field structures. Trace which map fields correspond
to which DDM fields to understand the data flow from database to screen:
```
Map: AIRMAN-DETAIL
  Map Field          | Source DDM         | Source Field
  -------------------|--------------------|-----------------
  #AIRMAN-ID         | AIRMEN-FILE        | AIRMAN-ID
  #AIRMAN-NAME       | AIRMEN-FILE        | AIRMAN-NAME
  #CERT-TYPE-DISPLAY | CERT-FILE          | CERT-TYPE (lookup)
  #STATUS-TEXT       | (derived)          | (calculated from status code)
```

## ADABAS DDM (Data Definition Module) Analysis

### DDM Structure
DDMs define the NATURAL view of ADABAS file structures:
```
DDM: AIRMEN-FILE     (ADABAS File Number: 157)
  DB  Field Name        Format  Length  Level  Type
  --  ----------------  ------  ------  -----  ----
  AA  AIRMAN-ISN         —       —       —     (ISN, implicit)
  AB  AIRMAN-ID          A       9       1     DE (descriptor)
  AC  SSN                A       11      1     DE,UQ (unique descriptor)
  AD  NAME-GROUP                         1     GR (group)
  AE    LAST-NAME        A       30      2     DE
  AF    FIRST-NAME       A       20      2
  AG    MIDDLE-INITIAL   A       1       2
  AH  ADDRESS-GROUP                      1     GR
  AI    STREET           A       40      2
  AJ    CITY             A       30      2
  AK    STATE            A       2       2     DE
  AL    ZIP              A       10      2
  AM  CERTIFICATES       PE              1     PE (periodic group)
  AN    CERT-TYPE        A       10      2     DE
  AO    CERT-NUMBER      A       15      2
  AP    ISSUE-DATE       D               2
  AQ    EXPIRY-DATE      D               2
  AR    STATUS           A       8       2     DE
  AS  RATINGS            MU      A10     1     MU (multiple value)
  AT  CREATE-DATE        D               1
  AU  LAST-MOD-DATE      D               1
  AV  LAST-MOD-USER      A       8       1
```

**DDM analysis checklist:**
- [ ] Map all DDMs to their ADABAS file numbers
- [ ] Document all descriptors (DE) — these are the indexed fields
- [ ] Document unique descriptors (UQ) — these are unique constraints
- [ ] Document superdescriptors (SU) — composite indexes
- [ ] Document subdescriptors (SB) — partial field indexes
- [ ] Document phonetic descriptors (PH) — fuzzy search support
- [ ] Document hyperdescriptors (HY) — custom index logic
- [ ] Identify periodic groups (PE) — these become child tables
- [ ] Identify multiple-value fields (MU) — these become arrays or child tables
- [ ] Note the 2-character short names (AA, AB, etc.) and their long names
- [ ] Document group fields (GR) — these flatten into parent in relational model

### DDM-to-Program Reference Map
```
DDM: AIRMEN-FILE (FNR 157)
  Referenced by 47 programs across 4 libraries:
    RMSLIB:   AIRMAN-INQ, AIRMAN-UPD, AIRMAN-NEW, CERT-RENEW, ... (23 programs)
    CAISLIB:  CAIS-LOOKUP, CAIS-VERIFY, ... (12 programs)
    BATCHLIB: BATCH-EXTRACT, BATCH-ARCHIVE, ... (8 programs)
    REPORTLIB: RPT-AIRMAN-LIST, RPT-CERT-STATUS, ... (4 programs)
    
DDM: CERT-FILE (FNR 158)
  Referenced by 31 programs across 3 libraries:
    RMSLIB:   CERT-INQ, CERT-ISSUE, CERT-RENEW, CERT-REVOKE, ... (18 programs)
    BATCHLIB: BATCH-CERT-PROC, ... (6 programs)
    REPORTLIB: RPT-CERT-STATUS, RPT-CERT-EXPIRY, ... (7 programs)
```

High reference count DDMs are critical data stores. Plan migration carefully
as many programs depend on them.

## Batch Job Dependencies

### JCL Job Stream Analysis
```jcl
/* Job 1: Extract */
//EXTRACT  JOB (ACCT),'DAILY EXTRACT'
//STEP010  EXEC PGM=NATBATCH
//CMSYNIN  DD *
  LOGON BATCHLIB
  DAILY-EXTRACT
  FIN
/*
//CMWKF01  DD DSN=AIRMEN.DAILY.EXTRACT,DISP=(NEW,CATLG)

/* Job 2: Transform (depends on Job 1) */
//XFORM    JOB (ACCT),'DAILY TRANSFORM',COND=(0,NE,EXTRACT)
//STEP010  EXEC PGM=NATBATCH
//CMSYNIN  DD *
  LOGON BATCHLIB
  DAILY-TRANSFORM
  FIN
/*
//CMWKF01  DD DSN=AIRMEN.DAILY.EXTRACT,DISP=SHR         <- reads Job 1 output
//CMWKF02  DD DSN=AIRMEN.DAILY.TRANSFORMED,DISP=(NEW,CATLG)

/* Job 3: Load (depends on Job 2) */
//LOAD     JOB (ACCT),'DAILY LOAD',COND=(0,NE,XFORM)
//STEP010  EXEC PGM=NATBATCH
//CMSYNIN  DD *
  LOGON BATCHLIB
  DAILY-LOAD
  FIN
/*
//CMWKF01  DD DSN=AIRMEN.DAILY.TRANSFORMED,DISP=SHR     <- reads Job 2 output
```

**Extract as job dependency graph:**
```
DAILY-EXTRACT (02:00)
    |
    v  (output: AIRMEN.DAILY.EXTRACT)
DAILY-TRANSFORM (02:30, after EXTRACT)
    |
    v  (output: AIRMEN.DAILY.TRANSFORMED)
DAILY-LOAD (03:00, after TRANSFORM)
```

**Work file handoff analysis:**
- Map CMWKF DD names to their dataset names
- Trace which job produces a dataset (DISP=NEW or MOD) and which consumes it (DISP=SHR or OLD)
- Build the producer-consumer graph from dataset flow
- Note COND parameters or scheduler dependencies for execution order

### Scheduler Integration
Check for external scheduler job definitions (CA-7, TWS, Control-M):
- Job names and schedule (cron equivalent)
- Predecessor/successor relationships
- Resource dependencies (datasets, ADABAS files, regions)
- Recovery/restart procedures
- SLA definitions (must complete by HH:MM)

## External Interface Analysis

### Natural RPC (Remote Procedure Call)
```
SYSRPC library contains:
  - Server definitions (which NATURAL nodes serve which subprograms)
  - Client stubs (proxy subprograms that route to remote servers)
  - Connection parameters (server name, port, protocol)
```

**RPC analysis:**
1. Inventory SYSRPC library contents
2. For each RPC server definition, document: server name, subprograms served, protocol
3. For each RPC client stub, document: target server, parameters, timeout
4. Map RPC calls in application code (same CALLNAT syntax as local calls)
5. Note: CALLNAT to an RPC subprogram looks identical to a local call in source code.
   Only the SYSRPC configuration reveals that it is remote.

### Natural Connection (Database Middleware)
NATURAL can access non-ADABAS databases through middleware:
- **Entire Connection**: Access to Oracle, DB2, SQL Server from NATURAL
- **SQL Gateway**: Execute SQL statements against relational databases
```natural
/* SQL via Entire Connection */
SELECT * INTO VIEW ORACLE-EMPLOYEES
  FROM EMPLOYEES
  WHERE DEPARTMENT = :DEPT-CODE
```
Look for `SELECT ... INTO VIEW` statements, SQLCA references, or SQL INCLUDE
statements to identify cross-database access.

### Natural ISPF Integration
Some NATURAL programs invoke ISPF panels or are invoked from ISPF:
```natural
/* Call ISPF from NATURAL */
CALL 'ISPLINK' 'DISPLAY' 'PANEL-NAME'

/* NATURAL program invoked from ISPF panel */
/* Entry via NATISPF interface */
```

### External File Interfaces
```
Interface Type       | NATURAL Mechanism          | Detection Pattern
---------------------|----------------------------|-----------------------
Sequential files     | READ/WRITE WORK FILE       | CMWKF DD in JCL
VSAM files           | DEFINE DATA with VSAM view | VSAM DD statements
MQ Series            | CALLNAT to MQ interface    | MQ connection library
TCP/IP sockets       | CALL 'CMTCPI'              | TCP socket calls
HTTP (web services)  | NATURAL for Ajax / XML     | HTTP request objects
FTP transfers        | External JCL step          | FTP DD/EXEC steps
```

## Security Boundary Analysis

### Natural Security (NSC) Controls

NSC enforces access at multiple levels:

**Library-Level Security:**
```
Library   | Allowed Users/Groups | Access Type
----------|---------------------|------------
RMSLIB    | GRP-RMS-USERS       | Execute
RMSLIB    | GRP-RMS-ADMIN       | Execute + Maintain
CAISLIB   | GRP-CAIS-USERS      | Execute
BATCHLIB  | USR-BATCHSRV        | Execute
TESTLIB   | GRP-DEVELOPERS      | Execute + Maintain + Source
```

**Program-Level Security:**
```
Library.Program       | Allowed Users/Groups | Restriction
----------------------|---------------------|------------
RMSLIB.AIRMAN-UPDATE  | GRP-RMS-UPDATE      | Only update group
RMSLIB.AIRMAN-DELETE  | GRP-RMS-ADMIN       | Admin only
RMSLIB.AIRMAN-INQUIRY | GRP-RMS-USERS       | All RMS users
```

**Statement-Level Restrictions:**
```
User/Group    | Restricted Statements
--------------|-----------------------
GRP-RMS-USERS | Cannot use: UPDATE, DELETE, STORE (read-only)
GRP-BATCH     | Cannot use: INPUT (no interactive screens)
```

**DDM-Level Security:**
```
DDM           | Allowed Users/Groups | Access
--------------|---------------------|--------
AIRMEN-FILE   | GRP-RMS-USERS       | Read
AIRMEN-FILE   | GRP-RMS-UPDATE      | Read + Write
MEDICAL-FILE  | GRP-MED-STAFF       | Read + Write
MEDICAL-FILE  | GRP-RMS-USERS       | (no access)
```

**Security analysis checklist:**
- [ ] Extract NSC library-level access rules
- [ ] Extract NSC program-level access rules
- [ ] Extract NSC DDM-level access rules
- [ ] Map NSC groups to business roles
- [ ] Identify programs with no security (accessible to all)
- [ ] Document the security model for target RBAC design

## Transaction Scope Analysis

### Write Coupling Matrix

Identify which programs modify which ADABAS files within a single transaction:

```
Program           | Files Modified in Single ET          | ET Frequency
------------------|--------------------------------------|---------------
AIRMAN-UPDATE     | AIRMEN-FILE, AUDIT-LOG               | Per screen save
CERT-RENEWAL      | CERT-FILE, AIRMEN-FILE, AUDIT-LOG    | Per renewal
BATCH-ARCHIVE     | AIRMEN-FILE, CERT-FILE, MEDICAL-FILE | Every 100 records
EXAM-ENTRY        | EXAM-FILE, CERT-FILE                 | Per exam result
```

**Cross-file transaction implications:**
- Programs that modify multiple files in one ET require distributed transaction
  support in the target (or redesign for eventual consistency)
- Single-file transactions can map directly to single-table updates
- Batch programs with periodic ET need equivalent SAVEPOINT strategy

## Deployment Model Analysis

### FUSER / FNAT / FDIC Architecture

NATURAL uses three key storage areas:

**FUSER (User File Area)**:
- Contains application source and cataloged objects
- One FUSER per NATURAL environment (dev, test, prod)
- Libraries live here: each library is a logical partition within FUSER
- Typically an ADABAS file (e.g., FNR 200)

**FNAT (System File Area)**:
- Contains NATURAL system programs and utilities
- Shared across environments (usually read-only)
- Updated only during NATURAL version upgrades
- Typically an ADABAS file (e.g., FNR 201)

**FDIC (Data Dictionary)**:
- Contains DDMs, metadata, documentation
- Shared reference for all environments
- PREDICT data dictionary if installed
- Typically an ADABAS file (e.g., FNR 202)

**Promotion model:**
```
Development FUSER (FNR 200)
    |  SYSOBJH / NATUNLD + NATLOAD
    v
Test FUSER (FNR 210)
    |  SYSOBJH / NATUNLD + NATLOAD
    v
Production FUSER (FNR 220)
```

Code promotion between environments uses NATURAL utilities:
- `SYSOBJH` (Object Handler): Copies objects between FUSERs
- `NATUNLD` / `NATLOAD`: Unload from one environment, load to another
- Some shops use custom promotion scripts or third-party tools (Predict, Entirex)

**Deployment analysis checklist:**
- [ ] Document FUSER file numbers per environment
- [ ] Document FNAT version (determines NATURAL runtime version)
- [ ] Document FDIC contents (DDMs, documentation)
- [ ] Map the promotion pipeline (dev -> test -> prod)
- [ ] Identify promotion tools and processes
- [ ] Check for environment-specific NATPARM settings
- [ ] Note ADABAS database IDs (DBID) per environment
