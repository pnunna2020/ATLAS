# ColdFusion Architecture Patterns

Reference for Legacy Architecture Mapper when analyzing ColdFusion applications.

## Technology Detection

Confirm ColdFusion by checking for:
- `.cfm` files (templates/pages)
- `.cfc` files (ColdFusion Components — the primary unit of encapsulation)
- `Application.cfc` or `Application.cfm` (application lifecycle handler)
- `Server.cfc` or CF admin config files
- CFML tags in source: `<cfcomponent>`, `<cffunction>`, `<cfquery>`

## Module Boundaries

### Directory-Based Organization
ColdFusion has no formal module system. Boundaries are conventional:
```
/components/          ← shared CFCs
/controllers/         ← request handlers (if MVC framework)
/models/              ← business logic CFCs
/views/               ← display templates (.cfm)
/services/            ← service-layer CFCs
/gateway/             ← data access CFCs
/config/              ← configuration files
```

### Framework Conventions
- **Fusebox**: Circuits defined in `circuit.xml`, each circuit is a logical module.
  Look for `circuit.xml.cfm` and `fusebox.xml.cfm` at the application root.
- **FW/1 (Framework One)**: Convention-based — `controllers/`, `model/services/`,
  `model/beans/`, `views/`, `layouts/`. Application.cfc extends `framework.one`.
- **CFWheels**: Rails-inspired MVC — `controllers/`, `models/`, `views/`.
  Routes in `config/routes.cfm`. Models map to DB tables by convention.
- **ColdBox**: `config/Coldbox.cfc` for configuration, `handlers/` for controllers,
  `models/` for services/beans, `modules/` for self-contained feature bundles.

### Identifying Actual Boundaries
ColdFusion apps frequently have weak boundaries. Check:
- Do CFCs in one directory directly instantiate CFCs in another?
- Are there circular `createObject()` calls between directories?
- Is `Application.cfc` doing routing, auth, error handling, AND business logic?

## Import / Dependency Analysis

### Direct Instantiation
```cfml
<!--- createObject — most common pre-CF9 --->
<cfset userService = createObject("component", "com.myapp.services.UserService")>

<!--- new keyword — CF9+ --->
<cfset userService = new com.myapp.services.UserService()>
```

### Template Inclusion
```cfml
<!--- Static include — inlined at compile time --->
<cfinclude template="header.cfm">

<!--- Dynamic include — resolved at runtime --->
<cfinclude template="#dynamicPath#.cfm">
```
Dynamic includes are a major analysis challenge — grep for variable-based template paths.

### Component Invocation
```cfml
<!--- Tag-based invocation --->
<cfinvoke component="com.myapp.services.OrderService" method="getOrder"
          returnvariable="order" orderID="#url.id#">

<!--- Method call on instance --->
<cfset result = orderService.processOrder(orderData)>
```

### Dependency Injection (Framework-Specific)
- **WireBox (ColdBox)**: Check `config/WireBox.cfc` for binding definitions
- **DI/1 (FW/1)**: Convention-based — beans auto-discovered in configured folders
- **Manual**: Constructor or setter injection patterns in `init()` methods

## Build System

ColdFusion is interpreted — there is no compile step. Key implications:
- No build artifact (no JAR/WAR equivalent by default)
- Deployment = copy files to CF server's webroot
- Some shops package as `.war` for deployment on Tomcat/JBoss
- **CommandBox**: Modern CF CLI tool — check for `box.json` (dependency manifest)
- **CFConfig**: Check for `.cfconfig.json` (server settings as code)

## Deployment Topology

- **Adobe ColdFusion**: Commercial server, often standalone or deployed on J2EE
- **Lucee**: Open-source CFML engine, often on Tomcat or Jetty
- **Standalone**: CF built-in web server (development/small deployments)
- **J2EE deployment**: CF packaged as WAR on Tomcat, JBoss, or WebLogic
- Check `web.xml` or `server.xml` for server configuration clues

## God Class Indicators

- `Application.cfc` exceeding 500 lines — likely handling routing, auth, error
  handling, logging, and business logic all in one file
- Any CFC with 50+ methods — CF doesn't enforce single responsibility
- Single-file controllers handling 20+ actions
- CFCs with mixed concerns: DB queries + business logic + presentation formatting
- Utility CFCs (`Utils.cfc`, `Common.cfc`) that every other component depends on

## Coupling Indicators

### Shared Scope Abuse
```cfml
<!--- Application scope — global mutable state --->
<cfset application.userCount = application.userCount + 1>

<!--- Session scope — often used as a cross-component data bus --->
<cfset session.currentOrder = orderObject>

<!--- Request scope — per-request global state --->
<cfset request.dsn = "myDatabase">
```
Grep for `application.`, `session.`, and `request.` usage across files to map
implicit coupling. These shared scopes create hidden dependencies between components.

### Other Coupling Signals
- `<cfinclude>` chains where Template A includes B includes C — deep nesting
- Multiple CFCs reading/writing the same session or application variables
- Hard-coded DSN names scattered across multiple files (instead of centralized config)

## Database Patterns

### Inline Queries
```cfml
<cfquery name="getUsers" datasource="myDB">
    SELECT u.*, r.roleName
    FROM users u JOIN roles r ON u.roleID = r.roleID
    WHERE u.active = <cfqueryparam value="1" cfsqltype="cf_sql_bit">
</cfquery>
```

### Stored Procedure Calls
```cfml
<cfstoredproc procedure="sp_GetUserOrders" datasource="myDB">
    <cfprocparam type="in" cfsqltype="cf_sql_integer" value="#userID#">
    <cfprocresult name="orders">
</cfstoredproc>
```

### ORM (CF9+)
Check for `this.ormEnabled = true` in Application.cfc and `persistent="true"` in CFCs.

### Key Analysis Points
- Count `<cfquery>` tags per file — high counts indicate data-access-in-view antipattern
- Check for `cfqueryparam` usage — missing parameterization = SQL injection risk
- Map datasource names to identify database connections
- Look for inline SQL in view templates (`.cfm` files) — coupling indicator
