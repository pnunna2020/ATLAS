---
name: legacy-architecture-mapper
description: >
  Reverse-engineer the architecture and structural boundaries of legacy applications.
  Used during Discovery Pass 1 (Structural & Dependency Mapping). Triggers on architecture
  mapping, structural analysis, module decomposition, or legacy reverse engineering.
agent: opus
allowed-tools:
  - Read
  - Write
  - Bash
  - Grep
---

# Legacy Architecture Mapper

## Purpose
Produce a structural map of a legacy application: modules, components, dependencies,
database schemas, external interfaces, and deployment topology. This map becomes
the decomposition boundary for all downstream assembly lines.

## Inputs
- Source code repository (Git URL or local path)
- IaC templates (if available)
- CI/CD configurations (if available)
- Existing documentation (if available)

## Outputs
- Module/component map with dependency relationships
- Call graphs and dependency chains
- Database schema with table relationships
- External system interface inventory
- Configuration and environment dependency map
- Build/deployment pipeline structure

## Methodology
1. Identify primary language, framework, and build tools
2. Traverse source tree — identify module/component boundaries
3. Analyze imports, includes, and code dependencies
4. Map database schema: tables, views, stored procedures, triggers
5. Extract API endpoints and external integration points
6. Document configuration files and environment bindings
7. Analyze build and deployment pipeline structure
8. Produce module decomposition map with coupling indicators

## Tech-Stack Dispatch
Before analyzing, detect the source technology from file extensions and config files, then load the appropriate reference:
- ColdFusion (.cfm, .cfc, Application.cfc) → `references/coldfusion-patterns.md`
- Java EE (.java, pom.xml, web.xml, EAR/WAR) → `references/java-ee-patterns.md`
- .NET/WebForms (.cs, .csproj, .aspx, .sln) → `references/dotnet-webforms-patterns.md`
- NATURAL (NATURAL sources, ADABAS DDMs) → `references/natural-adabas-patterns.md`
- Oracle EBS (APPS schema, concurrent programs) → load the `extraction` skill's Oracle EBS patterns
- PHP (.php, composer.json) → load the `extraction` skill's PHP patterns
- SQL Server (T-SQL, .dtsx, SSIS) → `references/sqlserver-patterns.md`
- COBOL (.cbl, .cob, .cpy, CICS, DB2, IMS, JCL) → `references/cobol-patterns.md`
- Mainframe binding services (RACF, Control-M, JES2 FTP/PDF, SAG Broker, Pitney Bowes Finalist) → `references/mainframe-services-patterns.md`

## Gotchas
- **Pass 1 output drives everything downstream**: The module/component map
  from this skill becomes the decomposition boundaries for Extract, Design,
  and Generate. Getting this wrong cascades through the entire factory.
- **Apparent modules ≠ actual coupling**: Just because code is in separate
  directories doesn't mean it's decoupled. Check for shared state, circular
  dependencies, and god classes that span module boundaries.
- **Database is part of the architecture**: Stored procedures, triggers, and
  views contain business logic and coupling. Don't treat the DB as "just storage."
- **Every finding needs file:line traceability**: Downstream consumers need
  to trace back to exact source locations.

## Quality Rules
- [ ] Module decomposition map includes coupling indicators (tight/loose/none) for every inter-module relationship
- [ ] Every identified component has at least one dependency edge or is explicitly documented as standalone
- [ ] Database schema map covers tables, views, stored procedures, and triggers — not just tables
- [ ] External interface inventory includes protocol, authentication method, and data format for each integration point
- [ ] Call graphs are validated by running static analysis scripts — not generated solely from directory structure
- [ ] Configuration and environment dependencies are separated from code dependencies in the output
- [ ] Decomposition boundaries align with business domains, not technical layers (DDD principle)
- [ ] Every finding has `{file}:{line}` traceability back to the source repository
- [ ] Build/deployment pipeline structure is documented including all CI/CD stages and artifact registries
- [ ] COBOL/CICS/DB2/JCL are first-class dispatch targets — no "future" disclaimers in Tech-Stack Dispatch
- [ ] Mainframe-service binding points (RACF, Control-M, SAG Broker, JES2 routing, Finalist) are modeled as architecture edges, not ignored
- [ ] Module coupling is validated with the `scripts/scan_module_coupling.sh` output, not inferred from directory structure alone

## Common Failure Modes
| Failure Mode | Symptom | Prevention |
|-------------|---------|------------|
| Directory-based decomposition | Modules mapped from folder structure but shared state and circular imports not detected | Run dependency analysis tools; validate boundaries with actual import/include graphs |
| Database treated as passive storage | Stored procedures, triggers, and views with business logic omitted from architecture map | Always include database objects in the structural analysis; treat PL/SQL/T-SQL as first-class code |
| Missing external integrations | Architecture map shows internal structure but external APIs, file feeds, and messaging not cataloged | Scan for HTTP clients, SFTP configs, JMS/MQ connections, and file I/O patterns beyond the main codebase |
| Stale documentation used as truth | Existing documentation describes intended architecture, not actual; map reflects aspirational state | Always validate documentation claims against actual code — use static analysis as the authoritative source |
| Coupling underestimated | Modules appear decoupled but share database tables, global state, or configuration keys | Check for shared DB schemas, global variables, static singletons, and shared config files across module boundaries |
| COBOL-only dispatch misses CICS/JCL coupling | Programs mapped from `.cbl` source but CICS `LINK/XCTL`, JCL step graphs, DD dataset bindings, and Control-M job dependencies are absent | Always run COBOL dispatch alongside `references/cobol-patterns.md` and `references/mainframe-services-patterns.md`; parse JCL steps and Control-M defs as edges, not just code |

## Handoff Summary
When this skill completes, verify:
1. Module decomposition map has coupling indicators for all inter-module relationships
2. Database schema map includes stored procedures, triggers, and views
3. All findings have `{file}:{line}` traceability citations
4. External interface inventory is complete with protocol and auth details
Then proceed to: `extraction` (P4.1) using the decomposition boundaries as extraction scope, and gate `G-DC` for discovery completeness review
