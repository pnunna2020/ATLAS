#!/usr/bin/env bash
# scan_module_coupling.sh
# Emit a CSV of import/include edges from a legacy repository.
# Usage:  scan_module_coupling.sh <repo_path>
# Output: CSV on stdout with header: from_module,to_module,edge_type
# Exits non-zero if the repo path is missing or contains no source.
set -euo pipefail

REPO="${1:-}"
if [[ -z "$REPO" || ! -d "$REPO" ]]; then
  echo "usage: scan_module_coupling.sh <repo_path>" >&2
  exit 2
fi

# Bail out early if there is nothing to scan.
EXT_ARGS=(-name "*.py" -o -name "*.java" -o -name "*.cs" \
  -o -name "*.cpp" -o -name "*.h" -o -name "*.go" \
  -o -name "*.js" -o -name "*.ts" -o -name "*.php" \
  -o -name "*.cfm" -o -name "*.cfc" -o -name "*.cbl" \
  -o -name "*.cob" -o -name "*.cpy")
if ! find "$REPO" -type f \( "${EXT_ARGS[@]}" \) -print -quit | grep -q .; then
  echo "no source files found under $REPO" >&2
  exit 3
fi

# CSV header.
echo "from_module,to_module,edge_type"

# scan <edge_type> <regex> <glob1> [glob2 ...]
# Runs grep across the given globs and emits one CSV row per match.
# Commas in file/target are stripped so the CSV stays well-formed.
scan() {
  local kind="$1" regex="$2"; shift 2
  local includes=()
  for g in "$@"; do includes+=(--include="$g"); done
  grep -RInE "$regex" "$REPO" "${includes[@]}" 2>/dev/null \
    | while IFS=: read -r file _ target; do
        printf '%s,%s,%s\n' "${file//,/}" "${target//,/}" "$kind"
      done || true
}

# Per-language dispatch.
scan python_import      '^(import |from )[A-Za-z0-9_.]+'     '*.py'
scan java_import        '^import [A-Za-z0-9_.]+;'            '*.java'
scan cs_using           '^using [A-Za-z0-9_.]+;'             '*.cs'
scan c_include          '^\s*#include [<"][^>"]+[>"]'        '*.cpp' '*.h'
scan go_import          '^\s*import \"[^"]+\"'               '*.go'
scan js_import          "(from ['\"][^'\"]+['\"])|require\(['\"][^'\"]+['\"]\)" '*.js' '*.ts'
scan php_use            "^(use |require|include)[^;]+;"      '*.php'
scan cfml_include       'cfinclude|createObject\("component"' '*.cfm' '*.cfc'
scan cobol_copy_or_call '^\s*(COPY |CALL )'                  '*.cbl' '*.cob' '*.cpy'
