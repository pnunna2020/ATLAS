#!/usr/bin/env bash
#
# Validate an OpenAPI 3.x specification for schema correctness and FAA
# conventions before handoff to code generation.
#
# Checks performed:
#   1. Schema validity (via redocly/openapi-cli or equivalent)
#   2. OAuth2 security scheme via OKTA is present
#   3. Pagination parameters on list endpoints
#   4. Consistent error response schema (RFC 7807)
#   5. Every operation has at least one example
#
# Usage: validate_openapi.sh <path-to-openapi.yaml>

set -euo pipefail

if [[ $# -lt 1 ]]; then
    echo "Usage: $0 <path-to-openapi.yaml>" >&2
    exit 2
fi

SPEC_PATH="$1"

if [[ ! -f "$SPEC_PATH" ]]; then
    echo "Spec file not found: $SPEC_PATH" >&2
    exit 2
fi

echo "Validating OpenAPI spec: $SPEC_PATH"

# TODO(skill-author): Wire a real linter. Candidates:
#   - redocly lint $SPEC_PATH
#   - spectral lint $SPEC_PATH --ruleset .spectral.yaml
#   - openapi-generator-cli validate -i $SPEC_PATH
# The FAA profile should pin the linter and ruleset so results are reproducible.

if command -v redocly >/dev/null 2>&1; then
    redocly lint "$SPEC_PATH"
elif command -v spectral >/dev/null 2>&1; then
    spectral lint "$SPEC_PATH"
else
    echo "WARNING: No OpenAPI linter installed (redocly or spectral)." >&2
    echo "TODO: install one of the supported linters and re-run." >&2
    exit 1
fi

# TODO(skill-author): Add FAA-specific checks:
#   - grep for OAuth2 security scheme referencing OKTA
#   - verify list endpoints declare cursor/pageSize parameters
#   - verify error responses use RFC 7807 structure
