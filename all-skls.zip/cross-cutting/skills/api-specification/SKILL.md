---
name: api-specification
description: >
  Generate OpenAPI 3.x specifications from extracted business rules and
  module designs. Use during P4.2 for API design. Triggers on OpenAPI,
  API specification, REST API design, or API schema mentions.
agent: sonnet
---

# API Specification Generation

## Purpose
Generate OpenAPI 3.x specs that define the contract between modernized services
and their consumers (internal apps, external agencies, Gravitee gateway).

## Gotchas
- **Every API goes through Gravitee**: The OpenAPI spec must include Gravitee
  security scheme (OAuth2 via OKTA). Don't generate specs with API key auth
  unless it's for an external consumer legacy pattern.
- **Reuse FAA data models**: If a data entity (Flight, Airport, User) already
  has a schema in the data product catalog, reference it. Don't create duplicate
  schemas per API.
- **Pagination is mandatory for list endpoints**: No unbounded result sets.
  Use cursor-based pagination for large datasets.

## Quality Rules
- [ ] OpenAPI spec validates against OpenAPI 3.x schema (run `scripts/validate_openapi.sh` or equivalent linter)
- [ ] All endpoints include Gravitee-compatible OAuth2 security scheme via OKTA — no API key auth unless explicitly justified for legacy consumers
- [ ] Data entity schemas reuse definitions from the data product catalog — no duplicate schema definitions per API
- [ ] Every list endpoint has cursor-based pagination with configurable page size
- [ ] Error responses use a consistent structure (RFC 7807 Problem Details or equivalent) across all endpoints
- [ ] Request/response examples are included for every endpoint (at least one success and one error example)
- [ ] All path parameters, query parameters, and request bodies have descriptions and validation constraints
- [ ] API versioning strategy is documented (URL path versioning or header versioning)

## Common Failure Modes
| Failure Mode | Symptom | Prevention |
|-------------|---------|------------|
| Missing Gravitee security scheme | API spec generated with basic auth or API key; Gravitee gateway rejects it at deployment | Always include OAuth2 security scheme referencing OKTA; validate before handoff |
| Duplicate data schemas | Same entity (Flight, Airport, User) defined differently across multiple API specs; integration breaks | Check data product catalog first; reference shared schemas by $ref |
| Unbounded list endpoints | Consumers fetch all records; API times out or crashes under load | Require pagination on every list endpoint; reject specs without cursor parameters |
| Missing error contract | Consumers cannot programmatically handle errors; error format varies per endpoint | Enforce consistent error response schema (RFC 7807); include error examples |
| No request validation constraints | API accepts malformed inputs; business logic layer must handle all validation | Add format, pattern, min/max, and required constraints to all input schemas |

## Phase 3 — ATLAS ChBA

> **Trace:** Closes P3-R25, P3-R28..R32, P3-R33..R36, P3-R76. Source: `docs/phase3/phase2-commitments.md` §B.2 (11 services S1..S11), §B.3 (OpenAPI 3.1, no shared DB), §B.4 (8 canonical entities); SF3 §2; gap matrix EDIT-5 (B5a in build plan).

### OpenAPI 3.1 is the floor for Phase 3

Phase 2 SF3 §2 commits to OpenAPI 3.1 explicitly. All Phase 3 ATLAS specs MUST emit at OpenAPI 3.1 (not 3.0). Drift to 3.0 is a known issue (DEV-18 in `docs/phase3/skills-gap-matrix.md` §5) and is explicitly rejected by the contract validator.

Required 3.1 features used in the Phase 3 spec set:
- JSON Schema 2020-12 Draft (3.1's underlying schema dialect)
- `webhooks` block where async producers publish to consumers (S3 Notification, S8 AirmanChanged events as documentation)
- `null` types via `type: ["string", "null"]` (3.0's `nullable: true` is replaced)
- Mutually-exclusive request bodies via `oneOf` at the body level

### Phase 2 §B.2 service coverage — one spec per service S1..S11

The Phase 3 prototype materializes specs for the 11 target services. Each spec lives at `services/<svc>/openapi.yaml` and binds to the table:

| # | Service | Spec name | Phase 3 disposition (per build-demo plan §1.2) | Headline endpoints |
|---|---|---|---|---|
| **S1** | Unified Pilot Identity | `s1-identity` | IMPLEMENT | `GET /me`, `POST /sessions`, `GET /certificates/{ftn}/status` |
| **S2** | Guided Intake | `s2-intake` | IMPLEMENT | `POST /applications` (8710), `POST /medicals` (8500-8) |
| **S3** | Notification & Status | `s3-notify` | IMPLEMENT THIN | `POST /notifications`, `GET /inbox/{role}` |
| **S4** | Conversational AI Layer | `s4-conversation` | STUB (canned responses) | `POST /ask` |
| **S5** | Shared Case Workspace | `s5-case` | IMPLEMENT | `POST /cases`, `GET /cases/{id}`, `POST /cases/{id}/transitions` |
| **S6** | Medical Readiness & Case (PHI) | `s6-medical` | IMPLEMENT THIN | `POST /exams`, `GET /cases/{id}/medical-cert-status` (boolean only across boundary) |
| **S7** | Designee & ODA | `s7-designee` | IMPLEMENT THIN | `GET /designees`, `GET /designees/{id}/cloa` |
| **S8** | Registry Canonical API | `s8-registry` | IMPLEMENT | `POST /airmen` (FTN single-write), `GET /airmen/{ftn}`, webhook `airman.changed` |
| **S9** | Digital Credential | `s9-credential` | IMPLEMENT | `POST /credentials` (PKI-sign), `GET /credentials/{id}/verify` |
| **S10** | Compliance | `s10-compliance` | STUB | `POST /reports/61-15` |
| **S11** | Reporting & Analytics Data Plane | `s11-reporting` | IMPLEMENT THIN | `GET /metrics/{topic}` |

The OpenAPI spec template `assets/phase3-openapi-template.yaml` (NEW under this skill) seeds each spec with: federal Banner-compatible info block, Keycloak OIDC security scheme (Phase 3 prototype), error contract using RFC 7807, pagination conventions, and webhooks block stub.

### FE/BE decoupling clauses (P3-R36; SF3 §2 "no service reads from another service's database")

Every Phase 3 spec MUST embed the following decoupling rules in the spec's `info.x-decoupling-rules` extension and in a top-level `## Service Boundary Statement` section of the human-readable Markdown export:

1. **No shared types except via OpenAPI codegen.** Frontend and backend MUST consume types only via codegen output of the spec — no shared `@types/*` package crossing the boundary.
2. **No DB access from the FE service.** The frontend tier never holds DB credentials; all state is fetched through this spec.
3. **No service reads another service's DB.** Cross-service interactions go through the published spec (synchronous) or canonical event (asynchronous), never direct DB access.
4. **No transitive type leakage.** Internal types (e.g., persistence-layer ORM models) MUST NOT appear in spec response bodies. Public types are spec-defined; internal types are not.
5. **Versioning is explicit.** Breaking changes bump the major version in the URL path. Backwards-compatible additions go on the same path with new optional fields.

These five clauses are enforced by the new `--check-decoupling` flag in `cross-cutting/skills/api-contract-validator` (Phase 3 EDIT) and by `cross-cutting/skills/service-layer-decoupling-auditor` (NEW, P1).

### §6.1.1.1.1.3 service-boundary rubric (FAA evaluation)

Phase 3 announcement §6.1.1.1.1.3 grades clarity of service boundaries and FE/BE decoupling. The Phase 3 spec set should expose, per service:

- [ ] **Public API surface size** — number of operations × number of distinct request bodies (a low number is a strong signal).
- [ ] **Internal types declared private** — every schema either appears in a response or is annotated `x-internal: true`.
- [ ] **Cross-service event consumption** documented in the `webhooks` block — explicit inputs.
- [ ] **Bounded ownership** — the spec's `info.x-bounded-context` field names the owning service team.
- [ ] **Backwards-compatibility commitment** — `info.x-compat-policy` declares the breaking-change policy.

The bullet list above doubles as the rubric the FAA evaluator checks against. The `service-layer-decoupling-auditor` produces the quantitative readout for the 10-page narrative.

### Phase 3 acceptance signals

- [ ] Every Phase 3 service spec emits OpenAPI 3.1 (validated: `info.openapi == "3.1.0"`).
- [ ] Each spec has a Service Boundary Statement section with the 5 decoupling clauses.
- [ ] Each spec passes `cross-cutting/skills/api-contract-validator --check-decoupling`.
- [ ] Each spec's request/response schemas reference the 8 canonical entities (P2 §B.4) for cross-service shapes.
- [ ] No two specs duplicate a canonical-entity schema definition; all share via `$ref` to a canonical-entity catalog.

## Handoff Summary
When this skill completes, verify:
1. OpenAPI spec passes schema validation
2. All endpoints have Gravitee OAuth2 security scheme and pagination (for list endpoints)
3. Data schemas reference the shared data product catalog — no duplicates
4. Error responses use a consistent structure with examples
5. **Phase 3:** Spec emits OpenAPI 3.1; Service Boundary Statement present; one spec per S1..S11
Then proceed to: `tdd-generation` (P4.3) to generate code against these API contracts, and gate `G-04b` for design completeness review
