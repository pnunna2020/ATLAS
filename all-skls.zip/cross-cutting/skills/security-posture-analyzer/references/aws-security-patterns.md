# AWS Security Patterns for FAA Applications

Reference for the security-posture-analyzer skill. AWS-specific security
patterns and configurations for applications in the FAA modernization
portfolio, deployed to AWS GovCloud.

---

## VPC Security Group Rules

### Deny-by-Default Pattern

Every security group starts with no inbound rules (implicit deny) and
adds only the minimum required access.

### Application Tier Security Group

```yaml
alb_security_group:
  inbound:
    - protocol: tcp
      port: 443
      source: 0.0.0.0/0          # HTTPS from internet (public-facing)
      description: "HTTPS from internet"
    - protocol: tcp
      port: 443
      source: 10.0.0.0/8         # HTTPS from internal network (internal-facing)
      description: "HTTPS from internal VPC"
  outbound:
    - protocol: tcp
      port: 8080
      destination: app_security_group
      description: "Forward to application tier"

app_security_group:
  inbound:
    - protocol: tcp
      port: 8080
      source: alb_security_group
      description: "Traffic from ALB only"
    - protocol: tcp
      port: 8080
      source: app_security_group   # Service-to-service within tier
      description: "Inter-service communication"
  outbound:
    - protocol: tcp
      port: 5432
      destination: data_security_group
      description: "PostgreSQL to data tier"
    - protocol: tcp
      port: 6379
      destination: cache_security_group
      description: "Redis to cache tier"
    - protocol: tcp
      port: 443
      destination: 0.0.0.0/0      # Via NAT Gateway or VPC endpoints
      description: "AWS API calls and external integrations"

data_security_group:
  inbound:
    - protocol: tcp
      port: 5432
      source: app_security_group
      description: "PostgreSQL from app tier only"
  outbound:
    - protocol: tcp
      port: 5432
      destination: data_security_group  # Aurora replication
      description: "Multi-AZ replication"

cache_security_group:
  inbound:
    - protocol: tcp
      port: 6379
      source: app_security_group
      description: "Redis from app tier only"
  outbound: []  # No outbound required
```

### Key Principles
- Never reference CIDR blocks when security groups can be referenced instead
- Each tier has its own security group; no shared groups across tiers
- Outbound rules are explicit, not the default allow-all
- Description field is mandatory for every rule (audit requirement)

---

## WAF Rule Sets

### Recommended WAF Configuration

```yaml
waf_web_acl:
  name: "{app_name}-waf"
  default_action: ALLOW
  rules:
    # AWS Managed Rules (priority order)
    - name: AWSManagedRulesCommonRuleSet
      priority: 1
      action: BLOCK
      description: "Common attack patterns: XSS, path traversal, etc."

    - name: AWSManagedRulesKnownBadInputsRuleSet
      priority: 2
      action: BLOCK
      description: "Known bad inputs: Log4j, SSRF patterns"

    - name: AWSManagedRulesSQLiRuleSet
      priority: 3
      action: BLOCK
      description: "SQL injection patterns"

    - name: AWSManagedRulesLinuxRuleSet
      priority: 4
      action: BLOCK
      description: "Linux-specific attack patterns"

    # Rate limiting
    - name: RateLimitRule
      priority: 10
      action: BLOCK
      type: RATE_BASED
      rate_limit: 2000           # Requests per 5-minute window per IP
      description: "Rate limit per source IP"

    # Geo-restriction (if required)
    - name: GeoRestriction
      priority: 20
      action: BLOCK
      geo_match:
        not_countries: ["US"]    # Block non-US traffic for CONUS-only apps
      description: "Allow US traffic only"

    # Custom rules (application-specific)
    - name: BlockLargePayloads
      priority: 30
      action: BLOCK
      size_constraint:
        field: BODY
        comparison: GT
        size: 8192               # 8 KB max body size (adjust per app)
      description: "Block oversized request bodies"
```

### WAF Logging
- Log all blocked requests to CloudWatch Logs
- Log sampled allowed requests (10% sample rate) for anomaly detection
- Retain WAF logs for 90 days minimum

---

## KMS Key Policies

### Customer-Managed Key for Application Data

```yaml
kms_key_policy:
  key_alias: "alias/{app_name}-data-key"
  key_rotation: true              # Annual automatic rotation
  key_policy:
    # Key administrators (human operators)
    - principal: "arn:aws-us-gov:iam::{account}:role/KeyAdminRole"
      actions:
        - "kms:Create*"
        - "kms:Describe*"
        - "kms:Enable*"
        - "kms:List*"
        - "kms:Put*"
        - "kms:Update*"
        - "kms:Revoke*"
        - "kms:Disable*"
        - "kms:Get*"
        - "kms:Delete*"
        - "kms:ScheduleKeyDeletion"
        - "kms:CancelKeyDeletion"

    # Application services (encrypt/decrypt only)
    - principal: "arn:aws-us-gov:iam::{account}:role/{app_name}-task-role"
      actions:
        - "kms:Decrypt"
        - "kms:GenerateDataKey"
        - "kms:DescribeKey"
      condition:
        StringEquals:
          "kms:ViaService": "rds.us-gov-west-1.amazonaws.com"

    # Aurora service (for encryption at rest)
    - principal: "arn:aws-us-gov:iam::{account}:role/aws-service-role/rds.amazonaws.com"
      actions:
        - "kms:Decrypt"
        - "kms:GenerateDataKey"
```

### Key-per-Service Pattern
- One CMK for database encryption (Aurora, DynamoDB)
- One CMK for object storage encryption (S3)
- One CMK for secrets encryption (Secrets Manager)
- Separate key policies limit blast radius if one key is compromised

---

## CyberArk Integration

### Privileged Access Management Pattern

```yaml
cyberark_integration:
  use_cases:
    # Human operator access to production
    - name: "Production database access"
      flow: "Operator -> CyberArk PSM -> Aurora endpoint"
      session_recording: true
      max_session_duration: "4 hours"
      approval_required: true

    # Service account credential retrieval
    - name: "Application credential retrieval"
      flow: "Fargate task -> CyberArk CCP API -> Credential"
      rotation_schedule: "Every 30 days"
      cache_ttl: "1 hour"

    # Break-glass emergency access
    - name: "Emergency database access"
      flow: "Operator -> CyberArk (emergency) -> Aurora endpoint"
      approval: "Auto-approved with post-audit"
      notification: "Immediate alert to security team"
```

### Integration Points
- CyberArk Central Credential Provider (CCP) API for automated credential retrieval
- CyberArk Privileged Session Manager (PSM) for human operator access
- Credential rotation managed by CyberArk, not application code
- Audit trail in CyberArk vault for all credential access

---

## OKTA OIDC Configuration

### Authorization Code + PKCE Flow (User-Facing Applications)

```yaml
okta_oidc_config:
  grant_type: "authorization_code"
  pkce: true
  client_type: "public"          # SPA frontend
  redirect_uris:
    - "https://{app_domain}/callback"
    - "https://{app_domain}/silent-renew"
  post_logout_redirect_uris:
    - "https://{app_domain}/"
  scopes:
    - "openid"
    - "profile"
    - "email"
    - "{app_name}:read"
    - "{app_name}:write"
  token_lifetime:
    access_token: "1 hour"
    refresh_token: "8 hours"
    id_token: "1 hour"
  mfa_required: true             # For T1 and T2 applications
  session_idle_timeout: "30 minutes"
  session_max_lifetime: "12 hours"
```

### Client Credentials Flow (Service-to-Service)

```yaml
okta_client_credentials:
  grant_type: "client_credentials"
  client_type: "confidential"
  client_secret_storage: "AWS Secrets Manager"
  scopes:
    - "{target_service}:read"
    - "{target_service}:write"
  token_lifetime:
    access_token: "15 minutes"   # Short-lived for service tokens
  rotation_schedule: "Every 90 days"
```

### Token Validation at API Gateway (Gravitee)

```yaml
gravitee_okta_policy:
  type: "jwt"
  issuer: "https://{okta_domain}/oauth2/{auth_server_id}"
  jwks_uri: "https://{okta_domain}/oauth2/{auth_server_id}/v1/keys"
  audience: "{app_api_identifier}"
  clock_skew: 30                 # seconds
  cache_jwks: true
  cache_ttl: "1 hour"
```

---

## mTLS for Service-to-Service Communication

### Certificate Management via ACM

```yaml
mtls_configuration:
  certificate_authority: "AWS Private CA"
  certificate_lifetime: "365 days"
  auto_renewal: true
  renewal_threshold: "60 days before expiry"

  # Per-service certificate
  service_certificate:
    common_name: "{service_name}.{app_name}.internal"
    san:
      - "{service_name}.{namespace}.svc.cluster.local"
      - "{service_name}.{app_name}.internal"
    key_algorithm: "RSA_2048"

  # Trust chain
  trust_store:
    ca_bundle: "arn:aws-us-gov:acm-pca::{account}:certificate-authority/{ca_id}"
    allowed_issuers:
      - "arn:aws-us-gov:acm-pca::{account}:certificate-authority/{ca_id}"
```

### Enforcement Points
- ALB configured for mutual TLS (client certificate verification)
- Fargate tasks present client certificates for inter-service calls
- Invalid or expired certificates result in connection rejection (no fallback to plain TLS)
- Certificate rotation is automated via ACM; no manual rotation required

---

## S3 Bucket Policies

### Encryption Enforcement

```json
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Sid": "DenyUnencryptedPut",
      "Effect": "Deny",
      "Principal": "*",
      "Action": "s3:PutObject",
      "Resource": "arn:aws-us-gov:s3:::{bucket_name}/*",
      "Condition": {
        "StringNotEquals": {
          "s3:x-amz-server-side-encryption": "aws:kms"
        }
      }
    },
    {
      "Sid": "DenyNonSSLAccess",
      "Effect": "Deny",
      "Principal": "*",
      "Action": "s3:*",
      "Resource": [
        "arn:aws-us-gov:s3:::{bucket_name}",
        "arn:aws-us-gov:s3:::{bucket_name}/*"
      ],
      "Condition": {
        "Bool": {
          "aws:SecureTransport": "false"
        }
      }
    }
  ]
}
```

### Public Access Block (Mandatory)

```yaml
s3_public_access_block:
  block_public_acls: true
  ignore_public_acls: true
  block_public_policy: true
  restrict_public_buckets: true
```

### Versioning and Lifecycle

```yaml
s3_bucket_config:
  versioning: true
  lifecycle:
    - transition:
        days: 90
        storage_class: "STANDARD_IA"
    - transition:
        days: 365
        storage_class: "GLACIER"
    - expiration:
        days: 2555               # 7 years for compliance retention
  logging:
    target_bucket: "{app_name}-access-logs"
    target_prefix: "{bucket_name}/"
```

---

## IAM Role Boundaries

### Permission Boundary for Application Roles

```yaml
iam_permission_boundary:
  name: "{app_name}-boundary"
  policy:
    Version: "2012-10-17"
    Statement:
      # Allow actions within the application's scope
      - Effect: "Allow"
        Action:
          - "s3:GetObject"
          - "s3:PutObject"
          - "s3:ListBucket"
        Resource:
          - "arn:aws-us-gov:s3:::{app_name}-*"

      - Effect: "Allow"
        Action:
          - "secretsmanager:GetSecretValue"
        Resource:
          - "arn:aws-us-gov:secretsmanager:*:*:secret:{app_name}/*"

      - Effect: "Allow"
        Action:
          - "kms:Decrypt"
          - "kms:GenerateDataKey"
        Resource:
          - "arn:aws-us-gov:kms:*:*:key/{app_kms_key_id}"

      # Deny actions outside the application's scope
      - Effect: "Deny"
        Action:
          - "iam:*"
          - "organizations:*"
          - "account:*"
        Resource: "*"

      - Effect: "Deny"
        Action:
          - "s3:*"
        NotResource:
          - "arn:aws-us-gov:s3:::{app_name}-*"
```

### Task Role Pattern (Fargate)

Each Fargate service gets its own IAM task role with:
- Only the permissions required by that specific service
- Permission boundary applied to prevent privilege escalation
- No wildcard resource ARNs (always scoped to specific resources)
- Condition keys to restrict access by VPC or source IP where possible

```yaml
task_role:
  name: "{app_name}-{service_name}-task-role"
  trust_policy:
    principal: "ecs-tasks.amazonaws.com"
    condition:
      StringEquals:
        "aws:SourceAccount": "{account_id}"
  permission_boundary: "arn:aws-us-gov:iam::{account}:policy/{app_name}-boundary"
  inline_policies:
    - name: "{service_name}-policy"
      # Scoped to only what this service needs
```

---

## Security Control Mapping Summary

| Control Area | AWS Service | Configuration |
|-------------|------------|---------------|
| Network segmentation | Security Groups | Per-tier, deny-by-default |
| Web application firewall | AWS WAF | Managed + custom rules on ALB |
| Encryption at rest | KMS + service encryption | CMK per data category |
| Encryption in transit | ACM + TLS 1.2+ | mTLS for service-to-service |
| Identity (users) | OKTA OIDC | Authorization Code + PKCE |
| Identity (services) | IAM Roles + mTLS | Per-service task roles |
| Secrets management | Secrets Manager + CyberArk | Auto-rotation, runtime retrieval |
| Privileged access | CyberArk PSM | Session recording, approval workflow |
| Vulnerability scanning | ECR + Inspector | Scan on push, runtime detection |
| Threat detection | GuardDuty | Continuous monitoring |
| Audit logging | CloudTrail + VPC Flow Logs | Management + data events |
| Compliance aggregation | Security Hub | Centralized findings dashboard |
| Access control | IAM Permission Boundaries | Scoped per-application |
| Object storage security | S3 Bucket Policies | Encryption + public access block |
