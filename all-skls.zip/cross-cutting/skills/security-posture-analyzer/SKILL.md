---
name: security-posture-analyzer
description: >
  Assess security posture, map security controls to architecture components, and
  guide compliance artifact generation. Used during Architecture Step 4 and
  Validation Stream 2. Triggers on security assessment, control mapping, Zero Trust
  design, or cATO artifact generation.
agent: opus
allowed-tools:
  - Read
  - Write
  - Bash
  - Grep
---

# Security Posture Analyzer

## Purpose
Map security controls to architecture components, design identity and Zero Trust
architecture, and generate compliance artifact seeds for cATO/FedRAMP workflows.

## Inputs
- Architecture blueprint from Design step
- Security control framework (OSCAL, NIST RMF, FedRAMP, or client-specific)
- Risk tier classification
- EA security standards from active client profile
- Threat model inputs (for Tier 1 applications)

## Outputs
- Control mapping matrix (control × architecture component)
- Identity and authorization architecture design
- Zero Trust implementation design (microsegmentation, mTLS, encryption)
- Compliance artifact seeds (SSP skeleton, control statements, POA&M template)
- Threat model (Tier 1 only)
- Security assessment report (post-implementation)

## Methodology
1. Map framework controls to specific architecture components
2. Identify inherited controls from shared platform services
3. Design identity architecture (SSO integration, service-to-service auth, conditional access)
4. Design Zero Trust patterns (microsegmentation, mTLS, encryption everywhere)
5. Generate compliance artifact seeds with architecture evidence
6. For Tier 1: conduct formal threat model (STRIDE or equivalent)

## Risk Tier Scaling
| Tier | Control Mapping | Threat Model | Review |
|------|----------------|-------------|--------|
| Tier 1 | Full mapping + formal documentation | Required (STRIDE) | Safety review board |
| Tier 2 | Standard mapping | Peer review | Architecture lead |
| Tier 3 | Standard mapping | Automated verification | Automated |

## Gotchas
- **Inherited controls reduce work but require documentation**: Controls
  inherited from the platform (e.g., encryption at rest via managed DB) still
  need explicit documentation in the SSP.
- **Zero Trust is not optional**: Even Tier 3 apps get microsegmentation and
  mTLS. The difference is the depth of documentation, not the controls.
- **No critical vulnerabilities at G-V2**: The compliance certification gate
  requires zero critical security findings. Plan for remediation time.

## Quality Rules
- [ ] Control mapping covers every applicable control family for the app's FIPS 199 categorization
- [ ] Inherited controls from shared services (OKTA, CyberArk, Gravitee) are documented with explicit inheritance chain
- [ ] Zero Trust design includes microsegmentation AND mTLS AND encryption for all tiers (T1/T2/T3)
- [ ] Threat model (STRIDE or equivalent) is completed for all T1 applications — not optional
- [ ] Compliance artifact seeds reference specific architecture components, not generic descriptions
- [ ] No critical security findings remain at G-V2 gate — zero tolerance for critical vulnerabilities

## Common Failure Modes
| Failure Mode | Symptom | Prevention |
|-------------|---------|------------|
| Inherited controls not documented | SSP missing shared service references; ISSO requires rework | Enumerate all shared services and document inheritance chain per control |
| Zero Trust treated as optional for T3 | T3 app deployed without microsegmentation; lateral movement possible in breach | Apply Zero Trust controls to all tiers; only documentation depth varies by tier |
| Threat model skipped for T1 | Safety board review rejected because threat model is missing; deployment blocked | Require STRIDE threat model as mandatory for all T1 applications |
| Generic compliance artifacts | Artifact seeds say "encryption at rest is implemented" without specifying which component; ISSO rejects | Reference specific architecture components (Aurora KMS key, S3 SSE-S3) in every control statement |

## Handoff Summary
When this skill completes, verify:
1. Control mapping matrix is complete for the app's FIPS 199 baseline
2. Inherited controls are documented with provider references
3. Zero Trust design covers microsegmentation, mTLS, and encryption
4. T1 apps have completed STRIDE threat models
Then proceed to: `cato-compliance` for OSCAL artifact generation, `ea-compliance` for EA alignment, and gate `G-V2` for security validation
