---
name: change-mgmt-coordinator
description: >
  Track user adoption and change management activities across modernization waves. Use during P5.3 for training material preparation, P6.1 for training delivery, and P6.2 for adoption monitoring. Triggers on change management, user adoption, training, or transition communication.
agent: sonnet
---

# Change Management & User Adoption
## Purpose
Ensure modernized applications are actually ADOPTED by FAA workforce.
Technology modernization without user adoption is a failed modernization.

## Workflow
1. Establish adoption baseline (active users, usage patterns) from P0.3
2. Develop training materials aligned to user personas
3. Plan communication schedule (pre-launch, launch, post-launch)
4. Monitor adoption metrics post-deployment
5. Trigger UX remediation if adoption falls below threshold

## Gotchas
- **FAA users span field offices, HQ, and ATC facilities**: Training must
  account for different technology comfort levels and access patterns.
  Not everyone has a desk with a monitor.
- **Resistance to change is real and valid**: Users who've used the same app
  for 15 years have legitimate concerns about a new interface. Address these
  directly, don't dismiss them.
- **Adoption metrics must be defined BEFORE deployment**: "We'll figure out
  how to measure adoption later" means you never will. Define metrics in P0.3.

## Quality Rules
- [ ] Adoption baseline (active users, usage frequency, key workflows) is established from P0.3 data before modernization begins
- [ ] Training materials are tailored to user personas (field staff, HQ analysts, ATC personnel) — no one-size-fits-all
- [ ] Communication plan covers three phases: pre-launch (awareness), launch (instructions), post-launch (support)
- [ ] Adoption metrics are defined before deployment with specific thresholds for success and remediation triggers
- [ ] Post-deployment adoption monitoring is scheduled at 7-day, 30-day, and 90-day intervals
- [ ] UX remediation plan exists for when adoption falls below the defined threshold

## Common Failure Modes
| Failure Mode | Symptom | Prevention |
|-------------|---------|------------|
| Generic training materials | Field staff confused by training designed for HQ desk workers; adoption drops in field offices | Develop persona-specific training that accounts for different access patterns and tech comfort levels |
| Metrics defined after deployment | No baseline to compare against; cannot determine if adoption is successful or failing | Establish adoption baseline in P0.3; define metrics before deployment begins |
| Change resistance dismissed | Users revert to workarounds or shadow IT instead of using the modernized app | Acknowledge legitimate concerns; involve power users as champions; provide direct support channels |
| Post-launch monitoring skipped | Adoption problems not discovered until months later; remediation is expensive | Schedule mandatory monitoring checkpoints at 7, 30, and 90 days post-deployment |

## Handoff Summary
When this skill completes, verify:
1. Adoption baseline is documented with measurable metrics
2. Training materials exist for each user persona
3. Communication plan covers pre-launch, launch, and post-launch phases
4. Monitoring schedule is set with remediation triggers
Then proceed to: `deploy-modernized-app` (P6.1) for deployment, and post-deployment adoption monitoring at P6.2
