---
name: identity-landscape-analyzer
description: >
  Portfolio-wide identity-model inventory and NIST 800-63 assurance-gap analysis.
  Catalogs identity models, detects proliferation, surfaces retire/consolidate
  candidates, recommends broker-federation pattern. Output per
  `schemas/discovery/identity-landscape.schema.json`. Triggers on identity
  landscape, SSO analysis, federation analysis, AAL gap, or
  @identity-landscape-analyzer.
agent: opus
allowed-tools:
  - Read
  - Write
  - Grep
---

# identity-landscape-analyzer

## Purpose
Inventory every identity model in a client portfolio, assign NIST 800-63-3 /
800-63B / 800-63C assurance levels per model, and surface gaps, proliferation
patterns, and retire/consolidate candidates. The output is the evidentiary
basis for Retire/Consolidate disposition reasoning, federated-broker design,
and Zero-Trust readiness — at the portfolio scope, not the per-app scope that
`security-posture-analyzer` operates on.

## Inputs
- Application catalog entries for every app in the portfolio (JSON per `schemas/discovery/application-catalog-entry.schema.json`)
- Authentication and session fragments from architecture diagrams, config files, and SSO integration catalogues
- Identity provider inventory (Login.gov, PIV/MyAccess, AD, Azure AD, Okta, custom IDPs)
- User-class taxonomy from the active client profile (e.g., public-applicant, FAA-staff, AME, designee, contractor)
- Risk tier classification per app (drives required AAL/IAL floors)
- NIST 800-63 mapping heuristics (see `references/nist-800-63-mapping.md`)

## Outputs
- Identity landscape analysis → `schemas/discovery/identity-landscape.schema.json`
- Portfolio identity inventory seed → `assets/identity-landscape-template.yaml`
- Broker-federation design recommendation → `assets/broker-recommendation-template.md`
- Retire-candidate list with migration complexity (embedded in schema `retire_recommendations`)
- Proliferation findings list (embedded in schema `proliferation_findings`)

## Methodology
1. Enumerate every application in the portfolio and extract its authentication
   configuration — IDP, MFA type, session handling, federation protocol — from
   catalog entries and source artifacts.
2. Cluster distinct identity models across the portfolio (e.g., Login.gov,
   PIV/MyAccess, AD/IWA, Username+Password+email-MFA, OAuth social) and record
   `model_name`, `model_type`, and `provider` per cluster.
3. Assign NIST 800-63 assurance levels (IAL, AAL, FAL) per model using the
   heuristics in `references/nist-800-63-mapping.md`. Populate
   `phishing_resistant` and `mfa_type` from observable attributes. Mark
   `unknown` with evidence when the configuration cannot be determined.
4. Detect proliferation patterns with the heuristics in
   `references/proliferation-patterns.md` — same user with multiple accounts,
   same app supporting multiple models redundantly, legacy directories without
   SSO, no broker-federation, identity-model-per-app.
5. Identify assurance gaps per app — enumerate `gap_type` values (below-aal2,
   phishable-mfa, no-identity-proofing, shared-credentials, etc.) with severity
   pinned to the app's risk tier and user class.
6. Produce retire recommendations per `references/retire-recommendations.md`
   — citing the specific criterion (below required AAL, blocks zero-trust,
   not phishing-resistant, superseded by federation) and scoring migration
   complexity low/medium/high/very-high.
7. Recommend a broker-federation pattern (`broker-all`, `broker-public-only`,
   `broker-staff-only`, or `keep-separate`), propose broker technology, list
   fronted IDPs, and document rationale in `assets/broker-recommendation-template.md`.
8. Emit the full `identity-landscape.schema.json` document with evidence
   citations for every model and gap.

## Gotchas
- **AAL is authenticator-scoped, IAL is proofing-scoped, FAL is federation-scoped.** An
  app can be IAL2 + AAL1 (proofed in-person but only password authn) or IAL1 +
  AAL2 (self-asserted identity but FIDO2). Never collapse them into a single
  number — per NIST 800-63-3 they are independent.
- **Email-code MFA does not meet AAL2.** NIST 800-63B §5.1.3.3 restricts
  out-of-band authenticators to the PSTN voice/SMS channel and explicitly
  excludes email. IACRA's email MFA is AAL1 regardless of how the vendor
  markets it.
- **IWA / NTLM blocks zero-trust.** Integrated Windows Auth leaks the
  implicit-trust perimeter into every downstream service. A retire
  recommendation for IWA is mandatory when the target state is zero-trust —
  not optional.
- **Same user, different IDPs is not automatically proliferation.** Public
  applicants using Login.gov AND FAA staff using PIV on the same app is
  intentional segmentation. The proliferation signal is the SAME user class
  holding multiple accounts.
- **PIV/MyAccess is AAL3 only when the cert is on-card and PIN-unlocked.**
  Software certs stored in the OS keystore degrade to AAL2 or AAL1. Check the
  keystore location before assigning AAL3.
- **Phishing-resistant is binary per NIST 800-63B-rev4.** FIDO2, PIV, and
  CAC are phishing-resistant; TOTP, push, SMS, email are not. No middle ground.
- **"SSO enabled" in the catalog does not imply FAL2.** Bearer-token SAML is
  FAL1; holder-of-key or signed assertions are required for FAL2. Confirm the
  binding before assigning FAL.

## Quality Rules
- [ ] Every identity model in `identity_models[]` has an explicit `nist_ial`, `nist_aal`, AND `nist_fal` value — or `unknown` with an evidence citation explaining why it could not be determined
- [ ] Every identity model has `phishing_resistant` populated (true/false) — never omitted
- [ ] Every identity model has `mfa_type` populated from the enum — `multiple` only when the app actually supports more than one concurrently
- [ ] Every `assurance_gap` has severity pinned to the affected app's risk tier — Tier 1 apps below AAL2 are severity `critical`, not `medium`
- [ ] Every `retire_recommendation` cites which criterion from `references/retire-recommendations.md` applies (below-required-AAL, blocks-zero-trust, not-phishing-resistant, or superseded-by-federation)
- [ ] Every `retire_recommendation` has a `migration_complexity` value and a non-empty `affected_apps[]`
- [ ] `broker_recommendation` includes `recommended_pattern`, `broker_technology`, `fronted_idps[]`, and `rationale` — and migration complexity is surfaced in the rationale or the retire list
- [ ] Every proliferation finding references the specific heuristic from `references/proliferation-patterns.md` and lists `affected_apps[]`
- [ ] Every identity model has at least one `evidence_citations[]` entry in `{artifact}:{section}` or `{repo}:{file}:{line}` form
- [ ] Output validates against `schemas/discovery/identity-landscape.schema.json` (no `additionalProperties`, all required fields present)

## Common Failure Modes
| Failure Mode | Symptom | Prevention |
|---|---|---|
| AAL2 claimed despite email-MFA | App marked AAL2 because vendor docs say "MFA enabled" but the second factor is a 6-digit code emailed to the user; NIST 800-63B §5.1.3.3 fails on audit | Inspect the MFA channel (`mfa_type`); email-code → AAL1; require SMS/TOTP minimum for AAL2 and phishing-resistant for AAL3 |
| IWA retirement recommended without account-migration path | Retire recommendation says "retire AD/IWA in DMS" but does not identify replacement IDP, account-linkage strategy, or staff re-provisioning plan; change-mgmt rejects | Every retire recommendation for an on-prem directory must name `replacement_model` and describe account-linkage in the rationale |
| Same-user-multiple-accounts mis-flagged as proliferation | Public applicant with Login.gov account + FAA staff with PIV flagged as "same user" because email address collides in both directories; recommendation to consolidate is impossible to execute | Scope same-user detection to one user class at a time; cross-class account duplication is expected |
| Federation assurance confused with authenticator assurance | App assigned FAL2 because it uses SAML, without inspecting the assertion binding; holder-of-key vs. bearer-token distinction ignored | Follow `references/nist-800-63-mapping.md` federation section; bearer = FAL1, holder-of-key / signed = FAL2, crypto proof-of-possession = FAL3 |
| Retire candidate without migration complexity | Retire list produced but `migration_complexity` left blank; downstream disposition-recommender cannot sequence the wave | Require low/medium/high/very-high per `references/retire-recommendations.md` complexity scoring; block emission if missing |

## Handoff Summary
When this skill completes, verify:
1. Every identity model has IAL+AAL+FAL+phishing_resistant+mfa_type populated, or `unknown` with evidence.
2. Every assurance gap is tied to a specific app with severity aligned to risk tier.
3. Every retire recommendation cites a criterion from `references/retire-recommendations.md` and includes migration complexity.
4. Broker recommendation names a pattern, technology, fronted IDPs, and rationale.
5. Output validates against `schemas/discovery/identity-landscape.schema.json`.

Then proceed to: `disposition-recommender` to consume `retire_recommendations[]`
and `proliferation_findings[]` for Retire/Consolidate dispositions, and
`security-posture-analyzer` to fold the portfolio identity findings into the
per-app Zero-Trust and control-mapping work. Clear gate `G-DC` (Discovery
Completeness) before advancing to Rationalization.
