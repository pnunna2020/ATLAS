# Broker-Federation Recommendation

Source skill: `identity-landscape-analyzer`
Output field: `broker_recommendation` in `schemas/discovery/identity-landscape.schema.json`

## 1. Recommended Pattern

One of:

- `broker-all` — single broker fronts every upstream IDP for every app and user class.
- `broker-public-only` — broker fronts public-facing IDPs (Login.gov, social); staff retain direct IDP integration.
- `broker-staff-only` — broker fronts staff IDPs (PIV/MyAccess, AD); public apps retain direct Login.gov integration.
- `keep-separate` — no broker; apps integrate directly with each IDP.

Selected: `<TODO>`

Rationale for the pattern choice: `<TODO — what problem the pattern solves in THIS portfolio, e.g., "four identity models side-by-side in Phase 2, all sharing the same application surface">`.

## 2. Broker Technology

Recommended: `<TODO — e.g., Keycloak 24.x, ForgeRock Identity Platform, Ping Federate, Okta as broker>`

Decision drivers:
- License model: `<open-source | commercial | gov-cloud-available>`
- Deployment target: `<AWS GovCloud | on-prem | SaaS IL4/IL5>`
- Protocol support required: `<SAML 2.0 | OIDC | WS-Fed | X.509 mutual-TLS>`
- Integration with existing auth stack: `<TODO>`

## 3. Fronted IDPs

List every upstream IDP the broker will federate:

| IDP | User class | Protocol | AAL contribution |
|-----|-----------|----------|------------------|
| `<TODO — e.g., Login.gov>` | public-applicant | OIDC | AAL2 |
| `<TODO — e.g., PIV/MyAccess>` | FAA-staff | SAML 2.0 + X.509 | AAL3 |
| `<TODO>` | `<TODO>` | `<TODO>` | `<TODO>` |

## 4. Apps in Scope

Migration wave assignments:

| Wave | Apps | Target IDP via broker |
|------|------|-----------------------|
| 1 | `<TODO>` | `<TODO>` |
| 2 | `<TODO>` | `<TODO>` |

## 5. Migration Complexity

Overall complexity: `<low | medium | high | very-high>` — match the scoring rubric in `references/retire-recommendations.md`.

Per-app complexity drivers:
- Account linkage across existing directories: `<TODO>`
- Session federation timeout and step-up requirements: `<TODO>`
- Legacy app auth library compatibility (SAML only vs OIDC native): `<TODO>`
- Downtime tolerance during cutover: `<TODO>`

## 6. Risks and Mitigations

| Risk | Impact | Mitigation |
|------|--------|-----------|
| `<TODO — e.g., single-broker outage blast radius>` | `<TODO>` | `<TODO — HA / failover / multi-region>` |
| `<TODO>` | `<TODO>` | `<TODO>` |

## 7. Evidence Citations

- `<TODO — {artifact}:{section} or {repo}:{file}:{line}>`
- `<TODO>`
