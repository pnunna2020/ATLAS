# Proliferation Pattern Detection

Heuristics for the `finding_type` enum in `schemas/discovery/identity-landscape.schema.json`.

## same-user-multiple-accounts

One user holds 2+ accounts in the SAME user class across apps.

- Join directories on normalized email, employee-id, or SSN hash.
- Scope to one `user_class` — cross-class duplication is expected.
- Threshold: >15% of a class holds 2+ accounts → flag.
- `consolidation_candidate: true` if one IDP can serve them.

## same-app-multiple-models

One app integrates with 2+ identity models for the SAME user class.

- Inspect auth middleware for multiple IDP bindings.
- Example: IACRA accepts email+password AND Login.gov for public applicants → redundant.
- Not a finding when models serve different user classes.

## redundant-federation

Two federation IDPs provide the same assurance to the same user class.

- Login.gov + a custom OIDC provider both reach AAL2 for public users on one app → one is redundant.
- Pick the higher-FAL / open-standard one as target.

## legacy-directory-without-sso

App authenticates directly against a legacy directory with no SSO layer.

- Scan for direct `ldap://` binds, NTLM/Kerberos IWA, local `users` table.
- Always a consolidation candidate — target = broker-fronted federated IDP.

## no-broker-federation

Portfolio has 3+ distinct IDPs and no broker fronting them.

- Count distinct `provider` values across `identity_models[]`.
- If >=3 and no single broker integrates them, flag.
- Target = broker (see `assets/broker-recommendation-template.md`).

## identity-model-per-app

Number of identity models ≈ number of apps — each app invented its own.

- Ratio of distinct models to apps > 0.6 → flag.
- Severe anti-pattern; drives broker-all recommendation.

## Required fields

Populate `finding_type`, `description`, `affected_apps[]`, and where measurable `affected_users_estimate`. Set `consolidation_candidate` and `target_model` when a consolidation path exists.
