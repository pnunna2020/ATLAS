# NIST 800-63 Mapping Heuristics

Assign IAL (proofing), AAL (authenticators), FAL (federation) independently. A model can be IAL2+AAL1 or IAL1+AAL2; do not collapse.

## IAL — NIST 800-63A

| Observable | IAL |
|---|---|
| Self-asserted, no proofing | IAL1 |
| Remote proofing with evidence (SSN, address, KBA) | IAL2 |
| In-person or supervised-remote + biometric + 2 strong evidence | IAL3 |

Login.gov default = IAL2. PIV/MyAccess issuance = IAL3. App-native username reg with no ID check = IAL1.

## AAL — NIST 800-63B

| Authenticator | AAL | Phishing-resistant |
|---|---|---|
| Password only | AAL1 | false |
| Password + email-code | AAL1 — §5.1.3.3 excludes email | false |
| Password + SMS | AAL2 | false |
| Password + TOTP | AAL2 | false |
| Password + push | AAL2 | false |
| FIDO2 / WebAuthn hardware | AAL3 | true |
| PIV / CAC, PIN-unlocked, on-card key | AAL3 | true |
| PIV software cert in OS keystore | AAL2 at best | false |

Critical: email-MFA NEVER reaches AAL2. Tier 1 apps require AAL3.

## FAL — NIST 800-63C

| Assertion binding | FAL |
|---|---|
| Bearer token (SAML bearer, OIDC id_token alone) | FAL1 |
| Holder-of-key, signed, or encrypted to RP | FAL2 |
| Crypto proof-of-possession of subscriber key at RP | FAL3 |

Local accounts only (no federation) → `not-applicable`.

## Unknown

When config cannot be determined, emit `unknown` and cite the gap (e.g., `iacra-config.yaml: auth section absent`). Do not guess.

## phishing_resistant field

Set `true` only for: FIDO2, WebAuthn, PIV on-card, CAC on-card, mutual-TLS with hardware key. Everything else — TOTP, push, SMS, email, password — is `false`.
