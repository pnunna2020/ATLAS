# Retire Recommendation Criteria

Every entry in `retire_recommendations[]` MUST cite one of these.

## Criterion 1 — Below required AAL for user class

Retire when the model's `nist_aal` is below the risk-tier floor for any user class in `apps_using`.

| Risk tier | Minimum AAL |
|---|---|
| Tier 1 | AAL3 (phishing-resistant) |
| Tier 2 | AAL2 |
| Tier 3 | AAL1 |

Example: IACRA public is Tier 2 → email-MFA (AAL1) fails → retire.

## Criterion 2 — Blocks zero-trust

Retire when the trust boundary is implicit / perimeter-based, or cannot issue short-lived tokens:

- IWA / NTLM — network-membership trust
- Basic Auth — no session scoping
- Direct LDAP bind without federation — no token lifetime control
- Shared service accounts with static credentials

Example: DMS FAA-side AD/IWA → retire to unblock zero-trust.

## Criterion 3 — Not phishing-resistant when Tier 1 depends on it

Retire when `phishing_resistant: false` AND the model is used by any Tier 1 app. TOTP, push, SMS, email, password-only qualify.

## Criterion 4 — Superseded by federation

Retire when an equivalent or stronger federated IDP already serves the same user class elsewhere. The duplicate app-specific model is redundant.

Example: app-native username+password for public applicants when Login.gov is already integrated for the same user class.

## Migration complexity scoring

| Complexity | Drivers |
|---|---|
| low | OIDC-to-OIDC swap, single app, <1k users, no linkage |
| medium | SAML-to-OIDC, email-match linkage, 1k–10k users |
| high | Legacy auth lib replacement, cross-directory migration, 10k–100k users, downtime window |
| very-high | On-prem directory retirement, cross-class merge, >100k users, staff re-badging |

## Required retire_recommendation fields

- `model_name`, `reason` (name the criterion), `replacement_model`, `migration_complexity`, `affected_apps[]`.
- If `replacement_model` is unknown, use `"TBD — see broker_recommendation"` — do not leave empty.
