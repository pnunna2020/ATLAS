---
name: patch-assessment
description: >
  Evaluate CVE advisories against the sustainment application portfolio and prioritize patching per FAA Order 1370.121 timelines. Use during ST.1. Triggers on CVE, vulnerability assessment, patch prioritization, or security advisory.
agent: sonnet
---

# CVE / Patch Assessment
## Workflow
1. Receive CVE advisory or security scan results
2. Map affected components to application inventory
3. Assess impact per application (critical path? user-facing? data access?)
4. Prioritize per FAA 1370.121 timelines:
   - Critical: 15 days to remediate
   - High: 30 days
   - Medium: 90 days
   - Low: 180 days
5. Check wave plan: Is this app entering modernization soon?
6. If yes: Coordinate with ST.2 (apply patch OR defer to modernization)
7. If no: Apply patch in sustainment

## Gotchas
- **Don't patch apps entering the factory**: If App X is entering Wave 3 next
  month, a medium-severity patch should wait. A critical patch cannot wait.
  Use ST.2 coordination for this decision.
- **Oracle CPU (Critical Patch Update) affects many apps simultaneously**:
  Oracle patches quarterly. Each CPU may affect dozens of apps.

## Quality Rules
- [ ] CVE impact is mapped to specific applications in the portfolio — not just component-level
- [ ] Patching priority follows FAA Order 1370.121 timelines: Critical=15d, High=30d, Medium=90d, Low=180d
- [ ] Apps entering factory within 30 days are flagged for ST.2 coordination before patching
- [ ] Oracle CPU patches are assessed for portfolio-wide impact, not individual app level
- [ ] Patch assessment includes impact classification: critical path, user-facing, data access
- [ ] Deferred patches (for apps entering factory) are logged for post-modernization review

## Common Failure Modes
| Failure Mode | Symptom | Prevention |
|-------------|---------|------------|
| Factory app patched without coordination | Patch changes codebase that factory will extract from; extraction uses stale assumptions | Check wave plan before patching; coordinate with ST.2 for apps entering factory within 30 days |
| Timeline violated | Critical CVE not patched within 15 days; audit finding | Track patch timelines from advisory date; escalate Critical patches immediately |
| Portfolio-wide impact missed | Oracle CPU assessed per-app instead of portfolio-wide; affected apps missed | Check Oracle CPU impact across entire portfolio; assess all apps on affected Oracle versions |
| Deferred patches forgotten | Medium-severity patch deferred for factory intake but never applied post-modernization | Log all deferred patches; review deferred list after modernization wave completes |

## Handoff Summary
When this skill completes, verify:
1. All CVE impacts are mapped to specific applications
2. Patching priority follows FAA 1370.121 timelines
3. Factory-bound apps are coordinated through ST.2
4. Deferred patches are logged for future review
Then proceed to: `change-conflict-resolver` (ST.2) for factory coordination, or direct patch application in sustainment
