# Six-Dimension Readiness Scorecard — {{application_id}}

**Assessed:** {{assessed_date}}
**Composite Readiness Score:** {{composite_readiness_score}} / 5.0
**Tier Hint (advisory):** {{tier_hint}} — risk-classifier is authoritative

---

## Dimension Scores

| Dimension | Score | Band | Rationale |
|---|---|---|---|
| Code Quality | {{code_quality.score}} / 5 | {{band}} | {{code_quality.rationale}} |
| Test Coverage | {{test_coverage.score}} / 5 | {{band}} | {{test_coverage.rationale}} |
| Security Posture | {{security_posture.score}} / 5 | {{band}} | {{security_posture.rationale}} |
| Documentation Coverage | {{documentation_coverage.score}} / 5 | {{band}} | {{documentation_coverage.rationale}} |
| Dependency Health | {{dependency_health.score}} / 5 | {{band}} | {{dependency_health.rationale}} |
| Architectural Clarity | {{architectural_clarity.score}} / 5 | {{band}} | {{architectural_clarity.rationale}} |

**Composite formula:** arithmetic mean of six dimensions, rounded to 1 decimal.

---

## Sub-Signals

- **Test Coverage:** {{test_coverage.coverage_percent}}% (from {{coverage_report_path}}); {{test_coverage.test_count}} test files
- **Security CWE classes detected:** {{security_posture.cwe_classes_detected}}
- **Inline-doc ratio:** {{documentation_coverage.inline_doc_ratio}}
- **EOL runtimes:** {{dependency_health.eol_runtimes}}
- **Stale critical deps:** {{dependency_health.stale_critical_deps}}

---

## Top Risks

| Risk ID | Category | Severity | Likelihood | Description | Mitigation Estimate |
|---|---|---|---|---|---|
{{#each risks}}
| {{risk_id}} | {{category}} | {{severity}} | {{likelihood}} | {{description}} | {{mitigation_effort_estimate}} |
{{/each}}

**Technical debt estimate:** {{technical_debt_estimate_hours}} hours

---

## Handoffs

- **portfolio-scorer** consumes `composite_readiness_score`,
  `security_posture.score`, and `technical_debt_estimate_hours` for
  Rationalization Step 4.
- **security-posture-analyzer** owns deep CWE enumeration, control
  mapping, and threat modeling — this scorecard only rates.
- **ux-accessibility-assessor** owns Section 508 and WCAG — this
  scorecard's `documentation_coverage` is developer/operator docs only.
- **risk-classifier** owns the binding tier assignment; the `tier_hint`
  above is advisory.

---

## Methodology Notes

- Every score requires an evidence citation (file:line or
  artifact:section:finding-id). Scores without evidence fail schema
  validation.
- `test_coverage.score` is capped at 3 when no coverage report is cited
  (honesty clamp).
- `documentation_coverage.score` >= 4 requires README AND
  inline-doc-ratio >= 0.15 AND a runbook reference.
- `architectural_clarity.score` reuses `structural-analysis.json` when
  present, otherwise computes standalone from module count, cycles, and
  layer violations.
- See `references/six-dimension-rubric.md` for full 1-5 band criteria.
