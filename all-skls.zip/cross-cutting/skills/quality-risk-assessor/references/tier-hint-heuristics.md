# Tier Hint Heuristics (Advisory)

`quality-risk-assessor` emits a non-binding `tier_hint` (T1, T2, or T3)
based on the composite readiness score plus hard-fail overrides.
`risk-classifier` downstream owns the binding tier.

## Default Rules

Evaluate in order; first match wins.

1. **Hard T1 triggers** — any of:
   - Any single dimension score = 1
   - `dependency_health.eol_runtimes[]` is non-empty
   - `security_posture.score` = 2 and `cwe_classes_detected[]` contains a
     critical class (injection, auth bypass, crypto failure)
   - At least one risk with `severity = critical`

2. **T3 (low risk)**:
   - `composite_readiness_score` >= 4.0 AND
   - `security_posture.score` >= 4 AND
   - No hard T1 triggers fired

3. **T2 (moderate risk)**:
   - `composite_readiness_score` in [2.5, 4.0)

4. **T1 (high risk)**:
   - `composite_readiness_score` < 2.5
   - OR any hard T1 trigger fired

## Why "Hint" Not "Assignment"

The binding risk tier integrates business criticality, user counts,
compliance scope, and stakeholder input that this skill does not see.
For example:
- A simple cafeteria-menu app can have composite 4.8 and still be T3 —
  but a mission-critical air-traffic radar ops tool at composite 4.8 is
  still T1 because the consequence of failure is catastrophic.
- `quality-risk-assessor` cannot see the business criticality signal.
  `risk-classifier` combines this hint with that signal.

Always record in the rationale: "Advisory hint. risk-classifier is
authoritative."
