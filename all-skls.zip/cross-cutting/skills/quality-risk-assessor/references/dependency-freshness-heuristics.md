# Dependency Freshness Heuristics

How to decide whether Java 7, .NET 3.5, ColdFusion 9, Python 2, or PHP 5
dependencies count as "stale" — and whether that makes the
`dependency_health` dimension a 1, a 2, or something better.

## Core Principle
"Stale" is a date, not a vibe. Every EOL claim must name the runtime
version, its EOL date (with a vendor citation), and whether security
patches are still being issued.

## Runtime EOL Reference Table

Primary source: vendor lifecycle pages. This table is the canonical
reference; prefer vendor URLs in the artifact's evidence array.

### Java
| Runtime | EOL (mainstream) | EOL (security) | Notes |
|---|---|---|---|
| Java 7 | 2015-04 | 2022-07 (paid Oracle) | EOL — no free patches |
| Java 8 | 2019-01 (Oracle) | 2030-12 (paid) | LTS vendors (Temurin, Corretto) still supported |
| Java 11 | 2023-09 | 2032-01 (paid) | Last LTS for many apps |
| Java 17 | 2026-09 | 2029-09 | Current LTS |
| Java 21 | 2028-09 | 2031-09 | Newest LTS |

### .NET
| Runtime | EOL | Notes |
|---|---|---|
| .NET Framework 3.5 | 2029-01 (piggybacks on OS) | Functionally EOL for new work |
| .NET Framework 4.6.2 | 2027-01 | Supported but deprecated for greenfield |
| .NET Core 2.1 | 2021-08 | EOL |
| .NET Core 3.1 | 2022-12 | EOL |
| .NET 5 | 2022-05 | EOL |
| .NET 6 (LTS) | 2024-11 | EOL |
| .NET 7 | 2024-05 | EOL (STS) |
| .NET 8 (LTS) | 2026-11 | Supported |
| .NET 9 | 2026-05 | STS, supported |

### ColdFusion
| Runtime | EOL | Notes |
|---|---|---|
| CF 9 | 2014-12 | EOL |
| CF 10 | 2017-05 | EOL |
| CF 11 | 2019-04 | EOL |
| CF 2016 | 2022-02 | EOL |
| CF 2018 | 2023-07 | EOL |
| CF 2021 | 2025-07 | Near EOL — check patches |
| CF 2023 | 2027-07 | Supported |

### Python
| Runtime | EOL | Notes |
|---|---|---|
| Python 2.x | 2020-01 | EOL |
| Python 3.7 | 2023-06 | EOL |
| Python 3.8 | 2024-10 | EOL |
| Python 3.9 | 2025-10 | Near EOL |
| Python 3.10 | 2026-10 | Supported |
| Python 3.11+ | 2027+ | Supported |

### PHP
| Runtime | EOL | Notes |
|---|---|---|
| PHP 5.x | 2019-01 | EOL |
| PHP 7.x | 2022-11 | EOL |
| PHP 8.0 | 2023-11 | EOL |
| PHP 8.1 | 2025-12 | Security-only |
| PHP 8.2+ | 2026+ | Supported |

### Node.js
| Runtime | EOL | Notes |
|---|---|---|
| Node 10 | 2021-04 | EOL |
| Node 12 | 2022-04 | EOL |
| Node 14 | 2023-04 | EOL |
| Node 16 | 2023-09 | EOL |
| Node 18 (LTS) | 2025-04 | Near EOL |
| Node 20 (LTS) | 2026-04 | Near EOL |
| Node 22 (LTS) | 2027-04 | Supported |

### Mainframe / Legacy
| Runtime | EOL | Notes |
|---|---|---|
| Natural 8.x on mainframe | Vendor-extended; Software AG roadmap ends 2027 | Functionally deprecated |
| Adabas versions <= 8.5 | Vendor-supported with contracts; community support nil | Replatform target |
| COBOL (Micro Focus, IBM) | Long-lived with support contracts | Not EOL but reskill cost is high |

## Dependency (Library) Staleness

Beyond the runtime, individual libraries staleness also factors in. Use
the lockfile and compute:

- `months_behind_latest` per dependency
- `major_versions_behind`
- `has_known_cve` (via OSV, NVD, or GitHub Advisory)
- `archived_upstream` (repo marked archived on GitHub)

### Staleness Bands for Non-Runtime Dependencies

| Condition | Treatment |
|---|---|
| Major version current, minor <= 1 behind | healthy |
| 1 major version behind, no CVEs | acceptable |
| 2+ major versions behind OR any high CVE | stale_critical |
| Upstream archived with no fork adopted | stale_critical |

Populate the artifact's `stale_critical_deps[]` array only with items
meeting the `stale_critical` criteria.

## Scoring Mapping

| Condition | Max `dependency_health.score` |
|---|---|
| Runtime EOL | 1 |
| Runtime near EOL (within 12 months) OR high CVE present | 2 |
| Runtime supported; deps moderately stale; low CVEs | 3 |
| Runtime current; deps within 1 major; CVE scanning active | 4 |
| Runtime current; deps within minor; SBOM in CI; dependabot active | 5 |

## Evidence Required

For score >= 4, the artifact must cite:
- SBOM path (`sbom.spdx.json`, `bom.xml`, etc.)
- CVE scan output (Trivy, Snyk, Grype, OWASP Dependency-Check)
- Lockfile path
- Automated bot configuration (dependabot.yml, renovate.json)

For score <= 2, the artifact must name the specific EOL runtime and EOL
date, plus a vendor lifecycle URL in the evidence citation.
