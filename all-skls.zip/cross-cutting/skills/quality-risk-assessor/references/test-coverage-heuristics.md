# Test Coverage Heuristics for Legacy Apps

Legacy applications rarely emit coverage reports. Use these heuristics to
produce a defensible score when no JaCoCo/Cobertura/Istanbul/Cover.py report
exists. The heuristic score is always capped at 3 — an honest "I don't know
better than partial" rating.

## Step 1: Locate Coverage Reports (Preferred Path)

Search for, in order:

1. `**/jacoco.xml`, `**/jacoco/*.xml`, `**/site/jacoco/index.html` (Java)
2. `**/coverage.cobertura.xml`, `**/coverage.xml` (.NET, Python)
3. `**/coverage/lcov.info`, `**/coverage/index.html` (JavaScript/TypeScript)
4. `**/.coverage`, `**/coverage.py` (Python)
5. `**/clover.xml` (PHP)
6. `**/htmlcov/index.html` (Python alt)

If a report is found, parse it for line coverage percentage and cite the
file path. Map to the score bands in `six-dimension-rubric.md` directly.

## Step 2: Heuristic Signals When No Report Exists

If no coverage report is available, estimate from structural signals. The
score from heuristic signals alone is capped at 3.

### 2a. Test File Ratio

Count test files vs source files:

```
ratio = test_files / source_files
```

Test file patterns by language:
- Java: `**/src/test/**`, `*Test.java`, `*Tests.java`, `*IT.java`
- .NET: `*Tests.cs`, `*.Test.csproj`, `*Spec.cs`
- Python: `test_*.py`, `*_test.py`, `tests/**/*.py`
- JS/TS: `*.test.js`, `*.spec.ts`, `__tests__/**`
- PHP: `*Test.php`, `tests/**`
- ColdFusion: `*Test.cfc`, `tests/**/*.cfc`
- COBOL/Natural: `*-TEST*.cob`, `TST-*.cbl`, unit test JCL
- PL/SQL: `utPLSQL` packages, `*.pck` in test dirs

### 2b. Rough Heuristic Table

| test_files / source_files | Implied band | Max score |
|---|---|---|
| 0 | None | 1 |
| 0 < ratio < 0.05 | Minimal | 2 |
| 0.05 <= ratio < 0.20 | Partial | 3 |
| >=0.20 without coverage report | Partial (honesty clamp) | 3 |

### 2c. Quality Signals That Can Lower the Score

Even with a favorable ratio, apply -1 to the score (floor of 1) for each of:

- `.skip`, `@Ignore`, `@Disabled`, `xit(`, `it.skip(` occurrences >= 10% of total tests
- Test files older than source files (stale tests)
- No CI pipeline running tests (check `.github/workflows/`, `Jenkinsfile`, `.gitlab-ci.yml`, `azure-pipelines.yml`)
- Tests that only assert `true` or `not null` (smoke-only)

### 2d. Signals That Support Raising to 3 (But No Higher Without a Report)

- Integration test directory present with populated tests
- CI config that runs tests on every PR
- Evidence tests have failed in recent history (means they actually exercise code)

## Step 3: Evidence Capture

Record in the `test_coverage` dimension:

- `coverage_percent` — only if parsed from a report; otherwise omit
- `test_count` — integer count of test files discovered
- `rationale` — must explicitly say "no coverage report found; estimated
  from test file ratio" when heuristic
- `evidence[]` — at least one citation of a test file and a CI config (or
  note its absence)

## Step 4: Red Flags to Document as Risks

When found, emit a corresponding entry in the artifact's `risks[]`:

- **No tests at all** — severity: high, category: maintainability
- **Disabled tests >= 20%** — severity: medium, category: maintainability
- **No CI test gate** — severity: medium, category: operational
- **Snapshot-only tests** (no assertions on behavior) — severity: medium,
  category: maintainability

## Worked Example

Legacy ColdFusion app, 842 `.cfc` files, 34 `*Test.cfc` files, no CI, no
coverage report, 3 of 34 tests are `.skip`'d.

- ratio = 34/842 = 0.040 → band Minimal (max score 2)
- No CI test gate → apply -1 → floor at 1? No: Minimal band floor is 2 before penalty; after -1, floor to 1. Score = 1.
- Actually the -1 from "no CI" applies once; skipped tests at 9% under 10% threshold — no additional penalty.
- Final score = 1 (with rationale citing no CI, low ratio, no report).
- Emit risks: "No CI test gate" (medium, operational), "Test coverage
  unknown" (medium, maintainability).
