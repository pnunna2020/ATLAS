# Six-Dimension Readiness Rubric

Each dimension is scored 1-5 integer. Every score requires a rationale and at
least one evidence citation. Half-scores are not allowed; if a candidate sits
between two bands, pick the lower band and record the rationale.

## 1. code_quality

| Score | Band | Criteria |
|---|---|---|
| 1 | Critical | Spaghetti code; no separation of concerns; copy-paste throughout; no naming conventions; functions >500 lines common |
| 2 | Poor | Mixed patterns; some modules cleaner than others; sporadic linting; many functions >200 lines |
| 3 | Typical legacy | Recognizable structure (MVC-ish); inconsistent patterns across modules; linters run but warnings ignored; average function <100 lines |
| 4 | Good | Consistent patterns; linter clean or near-clean; clear separation of concerns; code review culture visible in history |
| 5 | Excellent | Clean architecture; strict linting enforced in CI; SOLID adherence; low cyclomatic complexity across the board |

Evidence sources: lint reports, cyclomatic-complexity scans, function-length
histograms, manual code review samples (cite file:line).

## 2. test_coverage

| Score | Band | Criteria |
|---|---|---|
| 1 | None | No tests, or coverage <5%, or tests disabled |
| 2 | Minimal | 5-20% line coverage; unit tests only; no CI enforcement |
| 3 | Partial | 20-50% coverage; unit + some integration; tests may be flaky |
| 4 | Solid | 50-80% coverage; unit + integration + some E2E; CI enforced |
| 5 | Comprehensive | >80% coverage; unit + integration + E2E + contract; mutation testing |

**Honesty clamp:** when no coverage report is available (no JaCoCo/Cobertura/
Istanbul/Cover.py artifact), the score MUST NOT exceed 3. Heuristic estimates
from test file counts are conservative by definition.

Evidence sources: coverage report path, test file count, test-to-code ratio,
CI config showing coverage gate.

## 3. security_posture

| Score | Band | Criteria |
|---|---|---|
| 1 | Critical | Known critical CWEs live in production; no SAST; secrets in source; EOL runtime with unpatched CVEs |
| 2 | Poor | Ad-hoc scanning; no secrets management; high-severity findings unremediated |
| 3 | Typical | Some scanning (SAST or dependency only); findings tracked but not consistently remediated; secrets managed |
| 4 | Good | Regular SAST + DAST; dependency scanning; no criticals; documented remediation SLAs |
| 5 | Excellent | Full SAST + DAST + IAST + dependency; CI-blocking; zero criticals; threat model current |

**Boundary:** this dimension is a rating only. Full CWE enumeration, STRIDE
threat modeling, and control mapping are delivered by `security-posture-
analyzer`. Surface `cwe_classes_detected[]` only to justify the rating; do
not attempt a comprehensive enumeration here.

Evidence sources: SAST/DAST tool names and last-scan dates, secrets-scan
output, dependency CVE counts, runtime EOL status.

## 4. documentation_coverage

| Score | Band | Criteria |
|---|---|---|
| 1 | None | No README, no runbook, no inline docs, no API docs |
| 2 | Minimal | README exists but stale; inline docs rare; no runbook |
| 3 | Partial | README current; some inline docs; partial runbook; API partially documented |
| 4 | Good | README + runbook + inline-doc-ratio >=15%; API docs generated (OpenAPI/Javadoc); ADRs for key decisions |
| 5 | Excellent | Full operator runbook; inline-doc-ratio >=25%; generated API docs; decision log; onboarding guide |

**Honesty clamp:** score >=4 requires README presence AND
`inline_doc_ratio` >= 0.15 AND a runbook reference. A nice README alone
scores 3.

Evidence sources: README path, runbook path, inline-doc-ratio measurement
(commented-loc / total-loc sampled from 3+ modules), ADR directory listing.

## 5. dependency_health

| Score | Band | Criteria |
|---|---|---|
| 1 | Critical | Runtime is EOL (no security updates); multiple critical CVEs unpatched; dependencies years stale |
| 2 | Poor | Runtime supported but near EOL; high-severity CVEs present; many deps major-version behind |
| 3 | Typical | Runtime supported; deps moderately stale (1-2 major versions behind); low-severity CVEs |
| 4 | Good | Runtime current; deps <1 major version behind; CVE scanning active; SBOM produced |
| 5 | Excellent | Runtime current; deps within latest minor; automated dependency bots; SBOM in CI |

**EOL reference table** (see also `dependency-freshness-heuristics.md`):

| Runtime | EOL date | Disposition |
|---|---|---|
| Java 7 | 2022-07 | EOL |
| Java 8 (non-LTS vendors) | 2023-03 | EOL for non-Temurin/Corretto |
| .NET Framework 3.5 | 2029-01 (mainstream 2016) | EOL |
| .NET Core 2.x / 3.x | 2022-12 | EOL |
| ColdFusion 9 | 2014-12 | EOL |
| ColdFusion 11 | 2019-04 | EOL |
| Python 2.x | 2020-01 | EOL |
| PHP 5.x | 2019-01 | EOL |
| Node 10/12/14 | 2021-2023 | EOL |

Evidence sources: lockfile path, EOL citation (vendor URL), CVE scan output,
SBOM path.

## 6. architectural_clarity

| Score | Band | Criteria |
|---|---|---|
| 1 | Critical | Monolith with cyclic imports; shared mutable state; no module boundaries |
| 2 | Poor | Nominal modules but pervasive coupling; layer violations common |
| 3 | Typical | Clear layers (controller/service/dao) but some coupling across; few cycles |
| 4 | Good | Clean module boundaries; dependency graph acyclic; layer discipline enforced |
| 5 | Excellent | Hexagonal/clean architecture; acyclic; bounded contexts; documented ports and adapters |

**Reuse rule:** when `structural-analysis.json` from `structural-analyzer`
emits an `architectural_clarity_score`, use that number verbatim and cite
the pass in rationale. Recomputing the score from scratch creates drift.

Evidence sources: module graph (from structural-analysis.json), cycle count,
layer-violation count, package/namespace organization.
