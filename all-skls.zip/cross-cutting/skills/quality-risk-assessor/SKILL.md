---
name: quality-risk-assessor
description: >
  Assess application quality and risk across six readiness dimensions (code
  quality, test coverage, security posture, documentation coverage, dependency
  health, architectural clarity) with explicit 1-5 scoring bands, produce a
  composite readiness score, enumerate risks, and emit a schema-validated
  quality-risk.json artifact for Rationalization. Pass 4 of the Foundry-style
  Discovery workflow. Triggers on quality assessment, risk scoring, readiness
  score, six-dimension rubric, or @quality-risk-assessor mentions.
agent: sonnet
allowed-tools:
  - Read
  - Write
  - Grep
  - Bash
validation_commands:
  - "python -m olympus.validators.schema_validator --artifact quality-risk.json"
  - "python -m json.tool schemas/discovery/quality-risk.schema.json"
supported_stacks:
  - java
  - dotnet
  - csharp
  - coldfusion
  - natural
  - cobol
  - python
  - php
  - plsql
  - tsql
anti_target_stacks: []
failure_classes:
  - score-without-evidence
  - dimension-conflation
  - test-coverage-hallucination
  - doc-coverage-overcounting
  - dependency-freshness-stale-data
benchmark_tags:
  - discovery-readiness
  - six-dim-rubric
  - code-quality
  - test-coverage
---

# Quality and Risk Assessor

## Purpose
Produce the authoritative composite readiness signal that Rationalization uses
to rank modernization candidates. The six-dimension rubric (code quality, test
coverage, security posture, documentation coverage, dependency health,
architectural clarity) is scored 1-5 per dimension with explicit evidence
citations. The composite score is the arithmetic mean of the six dimensions,
rounded to one decimal place. Every score without an evidence citation must
fail schema validation — this skill exists because unqualified scores are
indefensible to stakeholders and distort downstream disposition.

## Scope and Boundaries
- **This skill rates security at a dimension level**, not at a deep-scan
  level. For CWE-class enumeration, control-mapping, or Zero Trust design,
  hand off to `security-posture-analyzer`. Only `cwe_classes_detected[]` is
  surfaced here to support the rating rationale.
- **Accessibility is out of scope** — `ux-accessibility-assessor` owns
  Section 508 and WCAG findings. This skill's `documentation_coverage`
  dimension covers developer/operator docs, not end-user docs.
- **Business logic correctness is out of scope** —
  `business-logic-extractor` owns rule extraction. This skill rates whether
  the code is understandable enough to extract rules from, not what the
  rules are.
- **Architectural clarity reuses the `structural-analyzer` signal** when
  present. If Pass 2 structural-analysis.json emits an
  `architectural_clarity_score`, cite it verbatim; otherwise compute a
  standalone rating from module coupling and cyclic-import counts.

## Inputs
- Source code repository (required)
- `catalog.json` from `catalog-application` — archetype, LOC, primary language
- `structural-analysis.json` from `structural-analyzer` (optional but
  preferred) — module graph for architectural clarity signal
- `tech-fingerprint.json` — runtime versions for dependency EOL lookup
- Coverage reports if present (JaCoCo, Cobertura, Istanbul, Cover.py)
- SBOM or dependency manifests (pom.xml, *.csproj, package.json, box-file,
  requirements.txt, composer.json)
- Prior security scan outputs if available

## Outputs
- `quality-risk.json` — validates against
  `schemas/discovery/quality-risk.schema.json`
- `six-dim-scorecard.md` — human-readable scorecard using
  `assets/six-dim-scorecard-template.md`

## Methodology
1. Load upstream catalog and structural analysis. Confirm `application_id`
   and `assessed_date`.
2. For each of the six dimensions, apply the band criteria in
   `references/six-dimension-rubric.md` and record:
   - integer `score` in 1..5,
   - 1-2 sentence `rationale`,
   - at least one `{finding_id, citation}` evidence entry.
3. Compute dimension-specific sub-signals where the schema requires them:
   - `test_coverage.coverage_percent` and `test_count` — use measured values
     when reports exist, otherwise apply
     `references/test-coverage-heuristics.md` to estimate from test file
     counts and assert the score does not exceed 3 (no hallucinated 4/5s).
   - `security_posture.cwe_classes_detected[]` — only when at least one
     detected instance cites a file:line.
   - `documentation_coverage.readme_present` and
     `inline_doc_ratio` — compute the ratio as commented-loc / total-loc
     sampled from at least 3 modules.
   - `dependency_health.stale_critical_deps[]` and `eol_runtimes[]` — use
     `references/dependency-freshness-heuristics.md`; Java 7, .NET 3.5,
     ColdFusion 9, PHP 5, Python 2 all qualify as EOL.
   - `architectural_clarity` — reuse `structural-analysis.json`'s
     `architectural_clarity_score` if present; otherwise score from module
     count, cyclic-import count, and layer violations.
4. Compute `composite_readiness_score` as the arithmetic mean of the six
   integer scores, rounded to one decimal place.
5. Emit a non-binding `tier_hint` using
   `references/tier-hint-heuristics.md`:
   - composite >= 4.0 and security_posture >= 4 → T3
   - composite in [2.5, 4.0) → T2
   - composite < 2.5 OR any dimension = 1 OR EOL runtime → T1
   The hint is advisory only; `risk-classifier` owns the binding tier.
6. Build the `risks[]` array from observed failure patterns. Every risk has a
   `risk_id`, category, severity, likelihood, impact_area, mitigation_effort
   estimate, and a source-code citation.
7. Estimate `technical_debt_estimate_hours` as an integer aggregate for TCO
   rollup. Show-your-work by listing the dominant contributors in the risks
   array — do not emit a single round number without backing risks.
8. Validate the output against the schema before writing. Reject runs where
   any dimension has zero evidence entries.

## Six-Dimension Rubric (Summary)
See `references/six-dimension-rubric.md` for the full 1-5 band criteria per
dimension. Summary bands:

| Dim | 1 (worst) | 3 (typical legacy) | 5 (best) |
|---|---|---|---|
| code_quality | Spaghetti, no separation of concerns | Some structure, inconsistent patterns | Clean layered code, linters clean |
| test_coverage | No tests or <5% | 20-50%, unit only | >80% with integration + E2E |
| security_posture | Known critical CWEs live in prod | Some scanning, stale | SAST/DAST green, zero criticals |
| documentation_coverage | No README, no runbook | README exists, sparse inline docs | Full runbook, API docs, ADRs |
| dependency_health | EOL runtime + CVEs | Some stale deps, runtime supported | Current, CVE-free, SBOM fresh |
| architectural_clarity | Monolith, cyclic imports | Some layering, partial modularity | Clean boundaries, no cycles |

## Consumer Contract — portfolio-scorer
`portfolio-scorer` reads this artifact for its Technical Debt, Security
Posture, and Readiness signals. Specifically:
- `composite_readiness_score` feeds the Readiness dimension directly.
- `six_dim_scorecard.security_posture.score` feeds the Security dimension.
- `technical_debt_estimate_hours` feeds Technical Debt after scale
  normalization.
- Every `evidence[]` entry becomes a `{artifact}:{section}:{finding-id}`
  citation in the scorecard's `dimension_scores[].evidence[]` array.

## Gotchas
- **Do not score without evidence.** A dimension rated 4 with an empty
  `evidence[]` array fails schema validation. Stakeholders cannot challenge
  uncited scores.
- **Test coverage estimates from file counts cap at 3.** No coverage report
  means you cannot honestly claim 80%. Calibrate with
  `references/test-coverage-heuristics.md`.
- **"EOL" has a date, not a vibe.** `dependency_health` must name the EOL
  runtime explicitly (e.g., "Java 7 — EOL Jul 2022, no security updates").
- **Architectural clarity — reuse don't recompute.** When
  `structural-analysis.json` already scored clarity, reuse the number and
  cite it. Recomputing risks drift.
- **Do not overlap with security-posture-analyzer.** Your `security_posture`
  dimension is a 1-5 rating. CWE enumeration, STRIDE threat models, and
  control mapping belong to `security-posture-analyzer`.
- **`tier_hint` is a hint.** `risk-classifier` owns the binding tier. Do not
  emit `tier_hint` as if it were authoritative.

## Quality Rules
- [ ] All six dimensions scored 1-5 integer with rationale and at least one evidence citation
- [ ] `composite_readiness_score` equals the arithmetic mean of the six dimension scores rounded to one decimal
- [ ] Every risk in `risks[]` has a source-code citation in `{file, line}` format
- [ ] `technical_debt_estimate_hours` is backed by at least one risk or finding — no orphan totals
- [ ] `test_coverage.score` does not exceed 3 when no coverage report is cited
- [ ] `dependency_health.eol_runtimes[]` lists explicit runtime versions and EOL dates
- [ ] `security_posture` dimension does NOT duplicate `security-posture-analyzer` output — it references a rating, not a full scan
- [ ] When `structural-analysis.json` is present, `architectural_clarity` rationale cites the structural pass
- [ ] Schema validation passes before the artifact is persisted

## Common Failure Modes
| Failure Mode | Symptom | Prevention |
|---|---|---|
| Score without evidence | Dimensions rated high with empty `evidence[]` | Schema rejects empty evidence arrays; enforce at write time |
| Dimension conflation | Security issues counted under code quality, inflating two scores | Rate each dimension from its own signal set per the rubric |
| Test coverage hallucination | "85% coverage" claimed with no coverage report | Cap score at 3 when heuristic-estimated; require citation for >=4 |
| Doc coverage overcounting | README existence treated as full documentation | Require README + inline-doc-ratio + runbook reference for score >=4 |
| Dependency freshness stale data | Dependency list compared against outdated EOL cache | Refresh EOL table from `references/dependency-freshness-heuristics.md`; do not inherit stale |

## Handoff Summary
When this skill completes, verify:
1. `quality-risk.json` validates against
   `schemas/discovery/quality-risk.schema.json`.
2. Every dimension has a non-empty evidence array and rationale.
3. `composite_readiness_score` is arithmetic-mean correct to one decimal.
4. `tier_hint` is present and marked advisory in the rationale.

Then proceed to: `discovery-synthesizer` (Pass 6 — roll quality-risk into the
synthesis.md) and `portfolio-scorer` (Rationalization Step 4 — consume
readiness and security signals).
