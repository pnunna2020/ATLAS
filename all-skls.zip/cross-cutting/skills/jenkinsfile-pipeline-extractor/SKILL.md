---
name: jenkinsfile-pipeline-extractor
description: >
  Extract the build, test, deploy, and release stages encoded in
  Jenkins pipelines (`Jenkinsfile`, `Jenkinsfile.api`, `Jenkinsfile.ui`,
  `jenkinsfile.jdp`) as structured manifests. Legacy FAA apps
  predominantly use Jenkins as the CI/CD orchestrator, and the
  Jenkinsfile is the authoritative deployment contract — what gets
  built, when, against which environment, with which secrets. Without
  extraction, modernization silently loses: build-step order, env-
  specific conditionals, secret references, parallel stages, matrix
  builds, integration-test infrastructure, artifact-publishing
  semantics. Fires for AMCS (`ci/Jenkinsfile`), MEDXPRESS
  (`ci/Jenkinsfile`), DMS (`ci/jenkinsfile.jdp`), DIWS
  (`ci/Jenkinsfile.api` + `ci/Jenkinsfile.ui`). Runs as a Discovery
  conditional skill when the repo contains a file matching
  `Jenkinsfile*` or `jenkinsfile*`. Triggers on Jenkins pipeline
  extraction, CI/CD inventory, build-pipeline analysis, or
  @jenkinsfile-pipeline-extractor.
agent: sonnet
allowed-tools:
  - Read
  - Write
  - Grep
  - Glob
validation_commands:
  - "python -m olympus.validators.schema_validator jenkins-pipeline-inventory.json"
  - "python -m olympus.validators.schema_validator jenkins-stage-manifest.json"
  - "python -m olympus.validators.schema_validator jenkins-secret-reference-findings.json"
  - "python -m olympus.validators.schema_validator jenkins-modernization-findings.json"
supported_stacks:
  - jenkins
  - groovy
  - declarative-pipeline
  - scripted-pipeline
anti_target_stacks:
  - github-actions
  - gitlab-ci
  - azure-pipelines
  - circleci
failure_classes:
  - scripted-vs-declarative-confused
  - shared-library-dependency-unresolved
  - credential-reference-not-redacted
  - conditional-env-logic-flattened
  - matrix-build-dimensions-missed
  - parallel-stage-serialized
  - post-section-semantics-lost
  - agent-label-platform-dependency-missed
benchmark_tags:
  - discovery-cicd
  - jenkins-pipeline-extraction
  - build-deploy-contract
  - ci-modernization
---

# jenkinsfile-pipeline-extractor

## Purpose
Extract full Jenkinsfile semantics so Design and Modernization can
author equivalent GitHub Actions / GitLab CI / Azure Pipelines
workflows. Jenkinsfiles often encode critical operational knowledge:
env-specific deployment guards, secret references, shared-library
dependencies, matrix-build dimensions, parallel stage compositions,
post-section notification and cleanup logic. A Jenkinsfile parsed as
"just a build script" loses the full contract.

## Inputs
- Repository with `Jenkinsfile` / `Jenkinsfile.*` / `jenkinsfile.*`.
- Application catalog entry from `catalog-application`.
- Optional: Jenkins shared-library repos if `@Library` references
  point outside the app's repo.
- Optional: `JenkinsConfig.groovy` / Jenkins system config references.

## Outputs
- `jenkins-pipeline-inventory.json` — per Jenkinsfile: `{file_path,
  pipeline_style (declarative | scripted | mixed), agent_label,
  triggers (cron | webhook | upstream_job), parameters[], env_vars[],
  tool_versions, shared_libraries[]}`.
- `jenkins-stage-manifest.json` — per stage: `{pipeline_file,
  stage_name, order, parallel_branch, steps[], when_conditions,
  timeout, retry_policy, post_handlers}`.
- `jenkins-secret-reference-findings.json` — per secret:
  `{pipeline_file, line, credential_id, binding_type,
  env_var_name_if_bound}`.
- `jenkins-modernization-findings.json` — `@Library` from on-prem
  Jenkins, Windows agent labels, Jenkins-specific plugins
  (`step([$class: ...])`), shared-lib `vars/` call sites.

## Methodology
1. **Locate Jenkinsfiles** via glob `**/Jenkinsfile*` and
   `**/jenkinsfile*` (match common variants).
2. **Classify pipeline style.** Declarative starts with `pipeline {`;
   scripted starts with `node {` or `node('label') {`. Mixed
   wraps scripted via `script { }` steps inside declarative.
3. **Extract agent and tools.** `agent { label 'X' }`, `agent {
   docker { image 'X' } }`, `tools { jdk 'Y'; maven 'Z' }`.
4. **Extract triggers.** `triggers { cron(...) }`, `pollSCM(...)`,
   `upstream(...)`.
5. **Walk stages.** `stages { stage('Build') { steps { ... } } }`.
   Recurse into `parallel { stage('A') { } stage('B') { } }`.
6. **Extract steps.** `sh`, `bat`, `powershell`, shared-library
   calls, `archiveArtifacts`, `publishHTML`, `junit`, `docker.build`.
7. **Parse `when` directives.** `when { branch '...' }`,
   `when { environment name: 'X', value: 'Y' }`,
   `when { expression { ... } }`.
8. **Parse `post` sections.** `always`, `success`, `failure`,
   `unstable`, `changed`, `fixed`, `regression`, `aborted`,
   `cleanup`.
9. **Detect credential usage.** `withCredentials([usernamePassword(
   credentialsId: 'X', usernameVariable: 'U',
   passwordVariable: 'P')]) { ... }`.
10. **Detect `@Library`.** Top-of-file `@Library('lib') _` imports
    a shared library from a separate git repo.
11. **Emit all four manifests with `{repo}:{file}:{line}`.**

## Tech-Stack Dispatch

| Trigger | Reference loaded |
|---|---|
| Any Jenkinsfile | `references/jenkinsfile-syntax-patterns.md` |

## Gotchas
- **Declarative vs scripted.** Different structures; different
  parsers.
- **Mixed pipelines are common** (declarative + `script { }`
  blocks).
- **Shared libraries hide logic.** `@Library('shared') _` pulls
  `vars/<func>.groovy` from a separate repo.
- **Agent labels are platform-specific.** `label 'windows'`
  requires a Windows Jenkins agent.
- **`step([$class: 'Foo'])` is plugin-specific.** Requires
  equivalent in target CI.
- **Conditional env logic flattened.** Preserve `when` per stage.
- **Matrix builds.** `matrix { axes { axis { ... } } }` runs N
  combinations; don't collapse.
- **Parallel stages.** `parallel { }` runs concurrently;
  serializing slows builds.
- **Post section variants.** `always` / `success` / `failure` /
  `unstable` / `changed` / `fixed` / `regression` / `aborted` /
  `cleanup`.
- **Credential IDs reveal scope.** `prod-db-creds` signals prod
  secrets; flag.
- **`node { }` without a label** uses any available agent.
- **Multibranch job properties.** `properties([...])` sets
  job-level behavior.

## Quality Rules
- [ ] Every Jenkinsfile has an inventory entry.
- [ ] Every stage has a manifest entry with order, parallel
      branch, steps, when conditions.
- [ ] Every credential is captured with ID + binding type;
      values never leaked.
- [ ] Shared-library references emit cross-repo findings.
- [ ] Parallel stages and matrix dimensions preserved.
- [ ] Post-section semantics captured per variant.
- [ ] Every record carries `{repo}:{file}:{line}`.

## Common Failure Modes

| Failure Mode | Symptom | Prevention |
|---|---|---|
| Scripted and declarative conflated | Stage boundaries lost | Detect top-level syntax |
| Parallel stages serialized | Modernized CI runs slow | Preserve parallel grouping |
| Shared-library call unresolved | `buildJava()` reported as unknown | Grep `@Library` and emit cross-repo finding |
| Credential ID leaked in comment | `prod-db-creds` visible in finding body | Redact env markers; keep binding type |
| When conditions flattened | Every stage runs on every branch | Preserve `when` per stage |

## Handoff Summary
When this skill completes, verify:
1. Every Jenkinsfile has a pipeline + stage inventory.
2. Credentials are inventoried without leaking values.
3. Shared-library dependencies emit cross-repo findings.
4. Matrix and parallel semantics preserved.

Then proceed to: `migration-strategy-advisor` (Rationalization
supplementary) — CI migration planning;
`deploy-modernized-app` — target deployment authoring.

## References
- `references/jenkinsfile-syntax-patterns.md` — declarative vs
  scripted pipeline syntax, stage / step / agent / tools / when /
  post anatomy, shared-library usage, credential-binding patterns,
  multibranch job properties, parallel + matrix builds.

## Changelog
- 0.1.0 (2026-05-07) — Initial skill. Authored as ATLAS-R-18.
