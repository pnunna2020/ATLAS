# Jenkinsfile Syntax Patterns

Coverage for declarative and scripted Jenkins pipeline syntax,
with mapping guidance to GitHub Actions / GitLab CI / Azure
Pipelines.

## Declarative Pipeline Shape

```groovy
@Library('jenkins-shared-lib@v1.2.0') _

pipeline {
    agent { label 'dotnet-builder' }

    parameters {
        string(name: 'BRANCH', defaultValue: 'main')
        booleanParam(name: 'DEPLOY', defaultValue: false)
    }

    environment {
        NUGET_FEED = 'https://nuget.internal.faa.gov/v3/index.json'
        DEFAULT_TIMEOUT = '30'
    }

    triggers {
        cron('H 2 * * *')
    }

    options {
        buildDiscarder(logRotator(numToKeepStr: '10'))
        disableConcurrentBuilds()
        timeout(time: 60, unit: 'MINUTES')
    }

    tools {
        msbuild 'MSBuild-17'
        nodejs 'Node-20'
    }

    stages {
        stage('Checkout') {
            steps {
                checkout scm
            }
        }

        stage('Build') {
            steps {
                bat 'msbuild MySolution.sln /p:Configuration=Release'
            }
        }

        stage('Test') {
            parallel {
                stage('Unit') {
                    steps { bat 'dotnet test --logger trx' }
                }
                stage('Integration') {
                    steps { bat 'dotnet test Integration --logger trx' }
                }
            }
        }

        stage('Deploy') {
            when {
                allOf {
                    branch 'main'
                    expression { params.DEPLOY }
                }
            }
            steps {
                withCredentials([usernamePassword(
                    credentialsId: 'prod-deploy-creds',
                    usernameVariable: 'DEPLOY_USER',
                    passwordVariable: 'DEPLOY_PASS')]) {
                    sh './deploy.sh'
                }
            }
        }
    }

    post {
        always {
            junit 'TestResults/*.trx'
            archiveArtifacts artifacts: 'build/*.zip', fingerprint: true
        }
        success {
            mail to: 'team@faa.gov', subject: "Build ${env.BUILD_NUMBER} succeeded"
        }
        failure {
            mail to: 'oncall@faa.gov', subject: "Build ${env.BUILD_NUMBER} FAILED"
        }
    }
}
```

Extract all of: `@Library`, `agent`, `parameters`, `environment`,
`triggers`, `options`, `tools`, every stage (including parallel
groups), every `when` directive, every credential binding, every
post handler.

## Scripted Pipeline Shape

```groovy
node('dotnet-builder') {
    def config = 'Release'

    stage('Checkout') {
        checkout scm
    }

    stage('Build') {
        bat "msbuild MySolution.sln /p:Configuration=${config}"
    }

    stage('Test') {
        parallel unit: {
            bat 'dotnet test --logger trx'
        }, integration: {
            bat 'dotnet test Integration --logger trx'
        }
    }

    if (env.BRANCH_NAME == 'main') {
        stage('Deploy') {
            withCredentials([usernamePassword(
                credentialsId: 'prod-deploy-creds',
                usernameVariable: 'DEPLOY_USER',
                passwordVariable: 'DEPLOY_PASS')]) {
                sh './deploy.sh'
            }
        }
    }
}
```

Key differences from declarative:

- No top-level `pipeline { }` block.
- `if` / `for` / `try/catch` are Groovy — arbitrary control flow.
- `parallel` is a map of closures, not stage blocks.
- No `post` section; use `try { } finally { }` for cleanup.
- No structured `when` directive; use Groovy `if`.

Parse scripted pipelines as Groovy — stages are identified by
`stage(name) { }` calls; control flow is dynamic.

## Shared Libraries

```groovy
@Library('shared-lib@main') _

// After @Library, these become callable steps:
buildJava(
    mavenGoals: 'clean install',
    skipTests: false
)

deployToK8s(
    cluster: 'prod',
    namespace: 'faa'
)
```

Shared libraries live in a separate git repo with structure:

```
shared-lib/
├── vars/
│   ├── buildJava.groovy       # Exposes `buildJava(...)` as a step
│   └── deployToK8s.groovy
├── src/
│   └── org/faa/
│       └── Helper.groovy       # Classpath Groovy classes
└── resources/
    └── templates/
```

Each `vars/<name>.groovy` defines a callable step. `src/` holds
reusable classes. `resources/` holds file assets accessible via
`libraryResource('path/to/file')`.

Modernization implication: the shared library must either be
ported alongside the pipeline OR the pipeline rewritten to
inline the logic.

## Credential Bindings

`withCredentials` binds Jenkins-stored credentials to env vars
for the duration of a block:

| Binding type | Binding function | Env vars produced |
|---|---|---|
| Username + password | `usernamePassword(credentialsId, usernameVariable, passwordVariable)` | USER, PASS |
| SSH private key | `sshUserPrivateKey(credentialsId, keyFileVariable, usernameVariable, passphraseVariable)` | KEY, USER, PASS |
| Secret file | `file(credentialsId, variable)` | FILE (path) |
| Secret text | `string(credentialsId, variable)` | TEXT |
| Certificate | `certificate(credentialsId, keystoreVariable, passwordVariable, aliasVariable)` | KEYSTORE, PASS, ALIAS |
| AWS access key | `aws(credentialsId, accessKeyVariable, secretKeyVariable)` | KEY, SECRET |

Modernization mapping:

| Jenkins binding | GitHub Actions | GitLab CI | Azure Pipelines |
|---|---|---|---|
| usernamePassword | secrets.USER / secrets.PASS | $USER / $PASS via `variables:` | `usernamePassword@1` task |
| sshUserPrivateKey | ssh-agent action | SSH_PRIVATE_KEY var + ssh-agent | InstallSSHKey@0 |
| certificate | Base64-encoded secret | File-type variable | SecureFile asset |

## When Directives

Declarative pipeline conditional stage execution:

```groovy
when {
    allOf {
        branch 'main'
        environment name: 'DEPLOY', value: 'true'
        expression { return params.FORCE_DEPLOY || currentBuild.getPreviousBuild()?.result == 'SUCCESS' }
        anyOf {
            changeset 'src/**'
            tag 'v*'
        }
    }
}
```

Operators: `allOf`, `anyOf`, `not`, `branch`, `environment`,
`changeset`, `tag`, `expression`, `buildingTag`, `changelog`,
`changeRequest`, `equals`, `beforeAgent`, `beforeInput`.

Modernization: GitHub Actions uses `if:` expressions per job/step;
GitLab CI uses `rules:` blocks; Azure Pipelines uses
`condition:` expressions. Mapping is not 1:1 — complex when-
conditions may require rewriting.

## Post-Section Semantics

```groovy
post {
    always       { /* runs regardless */ }
    success      { /* only on success */ }
    failure      { /* only on failure */ }
    unstable     { /* test failures but build compiles */ }
    changed      { /* status differs from previous build */ }
    fixed        { /* previous was failure, this is success */ }
    regression   { /* previous was success, this is failure */ }
    aborted      { /* user aborted */ }
    cleanup      { /* always runs after all post conditions */ }
}
```

Modernization mapping:

| Jenkins post | GitHub Actions | Notes |
|---|---|---|
| always | `if: always()` | Same semantics |
| success | `if: success()` | Same |
| failure | `if: failure()` | Same |
| unstable | — | No direct equivalent; approximate via test-result step conditions |
| changed | — | Custom expression needed |
| fixed | — | Custom expression checking previous run |
| regression | — | Custom expression checking previous run |
| aborted | `if: cancelled()` | Same |
| cleanup | `if: always()` (last step) | Same |

## Matrix Builds

```groovy
matrix {
    axes {
        axis {
            name 'PLATFORM'
            values 'linux', 'windows', 'mac'
        }
        axis {
            name 'JDK'
            values '11', '17', '21'
        }
    }
    excludes {
        exclude {
            axis { name 'PLATFORM'; values 'mac' }
            axis { name 'JDK'; values '11' }
        }
    }
    stages {
        stage('Build') { steps { ... } }
    }
}
```

Produces 3 platforms x 3 JDKs = 9 combinations, minus 1 exclusion
= 8 builds. Modernization: GitHub Actions `strategy.matrix`,
GitLab CI `parallel: matrix`, Azure Pipelines `strategy: matrix`.

## Agent Labels

`agent { label 'dotnet-builder' }` requires a Jenkins worker
agent with that label. Modernization targets have different
compute models:

| Jenkins agent | GitHub Actions | GitLab CI | Azure Pipelines |
|---|---|---|---|
| Static labeled agent | `runs-on: <label>` | `tags:` | `pool:` |
| Docker agent (`agent { docker { image '...' } }`) | `container:` | `image:` | `container:` |
| Kubernetes agent (`agent { kubernetes { ... } }`) | `runs-on` with K8s runner | K8s runner | K8s pool |
| Windows agent (`label 'windows'`) | `runs-on: windows-latest` | Tags + Windows runner | Windows pool |

## Plugin Steps

`step([$class: 'S3Publisher', ...])` uses a Jenkins plugin;
`step([$class: 'SlackSendBuildInfo'])` uses another. Each
requires a target-stack equivalent:

| Jenkins plugin | Target equivalent |
|---|---|
| S3Publisher | `aws-actions/configure-aws-credentials` + `aws s3 cp` |
| SlackSendBuildInfo | Slack webhook action |
| Cobertura / JaCoCo | Coverage upload action (codecov, coveralls) |
| xUnit / JUnit | Test-result publish action |
| HTMLPublisher | Artifact upload or Pages deploy |

Flag plugin-specific steps as per-step modernization work items.
