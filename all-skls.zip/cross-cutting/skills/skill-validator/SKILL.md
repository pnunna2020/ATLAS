---
name: skill-validator
description: >
  Validate skill structure, output schemas, references, and scripts before registry
  entry. Used during Governance line skill lifecycle. Triggers on skill validation,
  skill registration, or new skill review.
agent: sonnet
allowed-tools:
  - Read
  - Write
  - Bash
  - Grep
---

# Skill Validator

## Purpose
Ensure newly created or refined skills meet structural requirements and quality
standards before they enter the skill registry and become available to factory agents.

## Inputs
- SKILL.md file (new or updated)
- references/ directory contents (if present)
- scripts/ directory contents (if present)
- assets/ directory contents (if present)
- config.json (if present)
- Sample inputs/outputs for testing (if available)

## Outputs
- Validation report (pass/fail per check)
- Remediation guidance for any failures
- Skill registration approval or rejection recommendation

## Validation Checks
| Check | What's Validated |
|-------|-----------------|
| Structure | SKILL.md follows required section structure (Purpose, Inputs, Outputs, Methodology, Constraints, Quality Criteria) |
| Output schema | Output format is defined and machine-parseable |
| References | All files referenced in SKILL.md exist in the skill directory |
| Scripts | Validation scripts execute without error on sample inputs |
| Conflict check | No conflicting skill names or overlapping variant criteria in registry |
| Frontmatter | Required fields present: name, description, agent, allowed-tools |

## Gotchas
- **Validation is deterministic and automated**: No subjective judgment — every
  check has a clear pass/fail criterion.
- **Variant criteria must be unambiguous**: If two variants could match the same
  app characteristics, the validator flags a conflict.
- **Missing output schema is a hard fail**: Skills without defined output formats
  produce unpredictable results. Every skill must specify what it produces.

## Quality Rules
- [ ] All validation checks are deterministic — clear pass/fail criteria with no subjective judgment
- [ ] Structure check verifies all required sections: Purpose, Inputs, Outputs, Methodology, Gotchas, Quality Rules, Common Failure Modes, Handoff Summary
- [ ] All file references in SKILL.md resolve to actual files in the skill directory
- [ ] Scripts execute without error on sample inputs (if sample data is available)
- [ ] No conflicting skill names or overlapping variant criteria in the registry
- [ ] Frontmatter has all required fields: name, description, agent, allowed-tools

## Common Failure Modes
| Failure Mode | Symptom | Prevention |
|-------------|---------|------------|
| Missing output schema | Skill produces unpredictable output format; downstream consumers cannot parse | Enforce output schema definition as a hard fail check |
| Broken file references | SKILL.md references files that do not exist; skill fails at runtime | Resolve all references during validation; fail if any file is missing |
| Overlapping variant criteria | Two skills match the same app characteristics; agent loads the wrong one | Check variant criteria against all existing skills in the registry for conflicts |
| Script validation skipped | Validation scripts have syntax errors; discovered only during factory execution | Execute scripts on sample inputs during validation, not just checking file existence |

## Handoff Summary
When this skill completes, verify:
1. Validation report shows pass for all checks
2. Any failures have remediation guidance
3. Skill is approved or rejected for registry entry
Then proceed to: registry entry if approved, or return to `skill-builder` for remediation if rejected
