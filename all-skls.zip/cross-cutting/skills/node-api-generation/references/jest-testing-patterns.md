# Jest Testing Patterns Reference

Standard for `test/unit/` and `test/integration/` in Node API generated
services. Uses Jest 29+ with `ts-jest` (TypeScript projects), supertest
for HTTP, `jest.mock` for module mocking, and Testcontainers for
integration-level databases.

## Test Naming

Method-under-test + scenario + expected outcome, separated by
underscores. Describe blocks add the system-under-test context.

```ts
describe('FlightsService.create', () => {
  it('creates_flight_and_returns_id_when_input_is_valid', async () => { /* ... */ });
  it('throws_domain_error_when_origin_equals_destination', async () => { /* ... */ });
});

describe('POST /api/v1/flights', () => {
  it('returns_201_and_location_when_body_is_valid', async () => { /* ... */ });
  it('returns_400_when_flight_number_is_missing', async () => { /* ... */ });
});
```

File names mirror the system under test:

- `src/modules/flights/flights.service.ts` -> `test/unit/flights.service.test.ts`
- `src/modules/flights/flights.routes.ts` -> `test/integration/flights.routes.test.ts`

## Arrange / Act / Assert

Every test has three sections separated by blank lines. Single-line tests
hide intent — always expand.

```ts
it('creates_flight_and_returns_id_when_input_is_valid', async () => {
  // Arrange
  const repo = {
    insert: jest.fn<Promise<void>, [Flight]>().mockResolvedValue(undefined),
  };
  const service = new FlightsService(pgPoolStub as Pool, repo as unknown as FlightsRepository);
  const input = { flightNumber: 'AA100', origin: 'JFK', destination: 'LAX' };

  // Act
  const result = await service.create(input, { signal: new AbortController().signal });

  // Assert
  expect(result.id).toMatch(/^[0-9a-f-]{36}$/);
  expect(repo.insert).toHaveBeenCalledTimes(1);
  expect(repo.insert).toHaveBeenCalledWith(expect.objectContaining({ flightNumber: 'AA100' }));
});
```

## jest.config.ts

```ts
import type { Config } from 'jest';

const config: Config = {
  preset: 'ts-jest',
  testEnvironment: 'node',
  roots: ['<rootDir>/test'],
  testMatch: ['**/*.test.ts'],
  moduleFileExtensions: ['ts', 'js', 'json'],
  setupFilesAfterEach: ['<rootDir>/test/helpers/teardown.ts'],
  setupFiles: ['<rootDir>/test/helpers/env.ts'],
  clearMocks: true,
  restoreMocks: true,
  resetModules: false,
  testTimeout: 15_000,
  collectCoverageFrom: [
    'src/**/*.ts',
    '!src/**/*.d.ts',
    '!src/server.ts',
  ],
  coverageThreshold: {
    global: { lines: 80, branches: 75, functions: 80, statements: 80 },
  },
  // CI runs with --detectOpenHandles to surface leaked pools / timers.
  reporters: ['default', ['jest-junit', { outputDirectory: 'reports/jest' }]],
};

export default config;
```

For ESM projects, swap `ts-jest` for the `ts-jest/presets/default-esm`
preset and add `"extensionsToTreatAsEsm": [".ts"]`.

## Unit Tests — Mocking Modules

Use `jest.mock('<path>')` to replace a module wholesale. Always declare
the mock at the top of the file so it hoists above the `import` that
pulls in the dependent.

```ts
// test/unit/flights.service.test.ts
import { FlightsService } from '../../src/modules/flights/flights.service';
import { FlightsRepository } from '../../src/modules/flights/flights.repository';

jest.mock('../../src/modules/flights/flights.repository');

const MockedRepo = FlightsRepository as jest.MockedClass<typeof FlightsRepository>;

describe('FlightsService', () => {
  beforeEach(() => {
    MockedRepo.mockClear();
    MockedRepo.prototype.findById.mockResolvedValue(null);
    MockedRepo.prototype.insert.mockResolvedValue(undefined);
  });

  it('returns_not_found_error_when_repository_returns_null', async () => {
    MockedRepo.prototype.findById.mockResolvedValueOnce(null);
    const service = new FlightsService({} as Pool, new MockedRepo({} as Pool));

    await expect(service.getById('missing-id', { signal: new AbortController().signal }))
      .rejects.toMatchObject({ name: 'NotFoundError' });
  });
});
```

For ESM, use `jest.unstable_mockModule` instead of `jest.mock`.

## Integration Tests — supertest

Integration tests boot the app factory with test configuration and make
real HTTP requests over an in-memory server socket (supertest handles
the bind/close lifecycle).

```ts
// test/integration/flights.routes.test.ts
import request from 'supertest';
import { buildApp } from '../../src/app';
import { setupTestDb, teardownTestDb } from '../helpers/db';

describe('POST /api/v1/flights', () => {
  let app: Awaited<ReturnType<typeof buildApp>>;

  beforeAll(async () => {
    await setupTestDb();
    app = await buildApp();
  });

  afterAll(async () => {
    await app.close?.();          // Fastify
    await teardownTestDb();
  });

  it('returns_201_and_location_when_body_is_valid', async () => {
    const response = await request(app.server ?? app)  // Fastify: app.server; Express: app
      .post('/api/v1/flights')
      .set('authorization', 'Bearer ' + testJwt())
      .send({ flightNumber: 'AA100', origin: 'JFK', destination: 'LAX' });

    expect(response.status).toBe(201);
    expect(response.headers.location).toMatch(/\/api\/v1\/flights\/[0-9a-f-]+/);
    expect(response.body).toMatchObject({ flightNumber: 'AA100' });
  });

  it('returns_400_when_flight_number_is_missing', async () => {
    const response = await request(app.server ?? app)
      .post('/api/v1/flights')
      .set('authorization', 'Bearer ' + testJwt())
      .send({ origin: 'JFK', destination: 'LAX' });

    expect(response.status).toBe(400);
    expect(response.headers['content-type']).toMatch(/application\/problem\+json/);
  });
});
```

For Fastify, pass `app.server` (the underlying Node `http.Server`); for
Express, pass the app directly — supertest accepts either.

## Fastify `inject()` Alternative

Fastify ships its own request injector that skips the network stack:

```ts
const response = await app.inject({
  method: 'POST',
  url: '/api/v1/flights',
  headers: { authorization: 'Bearer ' + testJwt() },
  payload: { flightNumber: 'AA100', origin: 'JFK', destination: 'LAX' },
});

expect(response.statusCode).toBe(201);
expect(response.headers['x-correlation-id']).toBeDefined();
```

Use `inject()` when the test does not need HTTP-semantic coverage (e.g.,
unit-style checks of a single route handler). Use `supertest` when you
want to assert on TCP-level behavior (streaming, connection errors).

## Testcontainers for Integration

Never point tests at a shared dev database. Spin up a container per suite
run and tear it down in `afterAll`.

```ts
// test/helpers/db.ts
import { PostgreSqlContainer, StartedPostgreSqlContainer } from '@testcontainers/postgresql';
import { Pool } from 'pg';

let container: StartedPostgreSqlContainer;
let pool: Pool;

export async function setupTestDb() {
  container = await new PostgreSqlContainer('postgres:16-alpine')
    .withDatabase('tests')
    .withUsername('tests')
    .withPassword('tests')
    .start();

  process.env.DATABASE_URL = container.getConnectionUri();
  pool = new Pool({ connectionString: process.env.DATABASE_URL });
  await runMigrations(pool);
}

export async function teardownTestDb() {
  await pool.end();
  await container.stop();
}

export async function truncate(tables: string[]) {
  await pool.query(`TRUNCATE ${tables.join(', ')} RESTART IDENTITY CASCADE`);
}
```

Declare Testcontainers once per CI run with a Jest global setup/teardown
when boot time dominates:

```ts
// jest.config.ts (excerpt)
globalSetup: '<rootDir>/test/helpers/global-setup.ts',
globalTeardown: '<rootDir>/test/helpers/global-teardown.ts',
```

## Mocking the Clock

Jest's fake timers run every scheduled callback synchronously — ideal
for code that uses `setTimeout` / `setInterval` / `setImmediate`.

```ts
beforeEach(() => jest.useFakeTimers({ doNotFake: ['nextTick'] }));
afterEach(() => jest.useRealTimers());

it('retries_after_configured_delay', async () => {
  const promise = service.pollWithBackoff();
  await jest.advanceTimersByTimeAsync(1_000);
  await jest.advanceTimersByTimeAsync(2_000);
  await expect(promise).resolves.toEqual({ ok: true });
});
```

`doNotFake: ['nextTick']` prevents Jest from breaking native promises.

## Async Assertions

Prefer `await expect(...).rejects.toMatchObject(...)` over manual
try/catch. The failure message points at the offending promise.

```ts
// Good
await expect(service.create(invalid)).rejects.toMatchObject({
  name: 'DomainError',
  message: expect.stringContaining('origin equals destination'),
});

// Avoid
try {
  await service.create(invalid);
  fail('expected error');
} catch (err) { /* ... */ }
```

Use `.resolves` / `.rejects` for Promise assertions — not `.then(...)`.

## Snapshot Tests

Use sparingly and only for stable outputs (e.g., OpenAPI spec, generated
migration SQL). Never snapshot HTTP response bodies with timestamps or
UUIDs without a serializer.

```ts
expect.addSnapshotSerializer({
  test: (v) => typeof v === 'string' && /^[0-9a-f-]{36}$/.test(v),
  print: () => '"<uuid>"',
});
```

## Common Leak Sources — Run CI with `--detectOpenHandles`

| Leak | Symptom | Fix |
|---|---|---|
| `pg.Pool` not ended | Suite hangs after all tests pass | `await pool.end()` in `afterAll` |
| Redis client open | Suite exits with `ETIMEDOUT` | `await redis.quit()` in `afterAll` |
| `setInterval` never cleared | `Jest did not exit one second after the test run` | Capture handle and `clearInterval` in teardown |
| HTTP server listening | `EADDRINUSE` on rerun | `await new Promise(r => server.close(r))` |
| Pending timers | Tests pass but CI times out | `jest.useRealTimers()` in `afterEach` |
| Container not stopped | Docker daemon fills with containers | `await container.stop()` in `afterAll` |

CI flag: `jest --ci --runInBand --detectOpenHandles --forceExit=false`.

## Coverage Gates

Block the build when coverage regresses. Numbers below are illustrative
— the client profile sets the actual thresholds.

```ts
coverageThreshold: {
  global: { lines: 80, branches: 75, functions: 80, statements: 80 },
  './src/modules/flights/flights.service.ts': { lines: 95, branches: 90 },
},
```

Report to JUnit + LCOV so CI (GitHub Actions, GitLab, Jenkins) can surface
failing tests and coverage drop:

```ts
reporters: [
  'default',
  ['jest-junit', { outputDirectory: 'reports/jest' }],
],
coverageReporters: ['text-summary', 'lcov', 'cobertura'],
```

## What NOT to Test

- Framework plumbing (Express routing, Fastify schema validation) — the
  frameworks have their own tests
- Third-party library internals (pg query protocol, pino serializer) —
  assert on your outputs instead
- JSON shape in unit tests when the schema is already validated at the
  edge (test the schema once; trust it elsewhere)

## Do / Don't

| Do | Don't |
|---|---|
| Mock modules at the top with `jest.mock` | `require('../service')` and patch `.prototype` mid-test |
| Use supertest against `app.server` (Fastify) or the app itself (Express) | Start the server with `.listen()` and hit `localhost:PORT` |
| Close pools, servers, containers in `afterAll` | Rely on `--forceExit` to mask leaks |
| Prefer `await expect(...).rejects` | Wrap in `try/catch` with `fail()` fallback |
| Spin up Testcontainers per suite | Share a dev database between tests |
| Use `jest.useFakeTimers({ doNotFake: ['nextTick'] })` | Patch `Date.now()` manually |
