# Express and Fastify Patterns Reference

This reference describes the canonical project structure, middleware order,
router composition, plugin registration, error-handler shape, and
dependency-injection wiring used by the `node-api-generation` skill. Pick
ONE framework per project — do not mix Express and Fastify in the same
service.

## Project Layout

```
<module>/
  package.json
  package-lock.json
  tsconfig.json
  jest.config.ts
  .eslintrc.cjs
  .prettierrc.json
  .nvmrc                          # 20
  Dockerfile
  docker-compose.yml
  .dockerignore
  .env.example                    # documented vars; no real secrets
  src/
    server.ts                     # app factory + listen()
    app.ts                        # build & return Express / Fastify instance
    config/
      index.ts                    # Zod-validated Config
    logger.ts                     # pino root logger
    container.ts                  # awilix / tsyringe DI container
    middleware/                   # Express-only (Fastify uses plugins)
      correlation-id.ts
      error-handler.ts
      auth.ts
    plugins/                      # Fastify-only
      correlation-id.ts
      auth.ts
    modules/
      <context>/
        <context>.routes.ts       # Express Router OR Fastify plugin
        <context>.schemas.ts      # Zod / JSON Schema
        <context>.service.ts
        <context>.repository.ts
        <context>.types.ts
    domain/
      <aggregate>/                # pure TS, no framework imports
        <aggregate>.entity.ts
        <aggregate>.events.ts
        <aggregate>.service.ts
    shared/
      errors.ts                   # DomainError, NotFoundError, etc.
      problem-details.ts          # RFC 7807 helpers
  test/
    unit/
    integration/
    helpers/
```

## Canonical Middleware Order (Express)

Applied in `src/app.ts`, in this exact order. Deviating breaks request
bodies, logging context, or error propagation:

```ts
// src/app.ts
import 'express-async-errors';
import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import { correlationIdMiddleware } from './middleware/correlation-id';
import { authMiddleware } from './middleware/auth';
import { errorHandler } from './middleware/error-handler';
import { flightsRouter } from './modules/flights/flights.routes';
import { healthRouter } from './modules/health/health.routes';
import { container } from './container';
import { scopePerRequest } from 'awilix-express';

export function buildApp() {
  const app = express();

  // 1. Observability first — before anything else can log
  app.use(correlationIdMiddleware);

  // 2. Security headers
  app.use(helmet());

  // 3. CORS — before auth so preflight succeeds
  app.use(cors({ origin: process.env.ALLOWED_ORIGINS?.split(',') ?? [] }));

  // 4. Body parsing — BEFORE routers; after CORS
  app.use(express.json({ limit: '1mb' }));
  app.use(express.urlencoded({ extended: false, limit: '1mb' }));

  // 5. Per-request DI scope
  app.use(scopePerRequest(container));

  // 6. Health endpoints — public, BEFORE auth
  app.use('/health', healthRouter);

  // 7. Authentication for everything below
  app.use(authMiddleware);

  // 8. Business routers
  app.use('/api/v1/flights', flightsRouter);

  // 9. 404 for anything else
  app.use((_req, res) => res.status(404).json({
    type: 'about:blank', title: 'Not Found', status: 404,
  }));

  // 10. Error handler — MUST be last and MUST take 4 args
  app.use(errorHandler);

  return app;
}
```

## Canonical Plugin Order (Fastify)

Fastify uses `fastify.register(...)` rather than `app.use(...)`. Plugins
run in registration order and encapsulate their context:

```ts
// src/app.ts
import Fastify from 'fastify';
import cors from '@fastify/cors';
import helmet from '@fastify/helmet';
import sensible from '@fastify/sensible';
import { fastifyAwilixPlugin, diContainer } from '@fastify/awilix';
import { correlationIdPlugin } from './plugins/correlation-id';
import { authPlugin } from './plugins/auth';
import { flightsRoutes } from './modules/flights/flights.routes';
import { healthRoutes } from './modules/health/health.routes';
import { errorHandler } from './shared/problem-details';
import { registerContainer } from './container';

export async function buildApp() {
  const app = Fastify({
    logger: false,  // pino attached via correlation-id plugin instead
    ajv: { customOptions: { removeAdditional: 'all', useDefaults: true } },
  });

  await app.register(correlationIdPlugin);      // must be first
  await app.register(helmet);
  await app.register(cors, { origin: false });  // lock down per profile
  await app.register(sensible);                 // httpErrors.notFound etc.
  await app.register(fastifyAwilixPlugin, { disposeOnClose: true });
  registerContainer(diContainer);

  await app.register(healthRoutes, { prefix: '/health' });   // pre-auth
  await app.register(authPlugin);                            // gates below
  await app.register(flightsRoutes, { prefix: '/api/v1/flights' });

  app.setErrorHandler(errorHandler);
  app.setNotFoundHandler((req, reply) =>
    reply.status(404).type('application/problem+json').send({
      type: 'about:blank', title: 'Not Found', status: 404,
    })
  );

  return app;
}
```

## Routers — Express

One `Router` per bounded context. Every handler is `async` and uses an
`asyncHandler` wrapper so rejections reach the error middleware.

```ts
// src/modules/flights/flights.routes.ts
import { Router } from 'express';
import { z } from 'zod';
import { asyncHandler } from '../../shared/async-handler';
import { CreateFlightSchema, FlightIdParamSchema } from './flights.schemas';

export const flightsRouter = Router();

flightsRouter.post('/', asyncHandler(async (req, res) => {
  const body = CreateFlightSchema.parse(req.body);
  const service = req.scope.resolve('flightsService');
  const created = await service.create(body, { signal: req.signal });
  res.status(201)
     .location(`/api/v1/flights/${created.id}`)
     .json(created);
}));

flightsRouter.get('/:id', asyncHandler(async (req, res) => {
  const { id } = FlightIdParamSchema.parse(req.params);
  const service = req.scope.resolve('flightsService');
  const flight = await service.getById(id, { signal: req.signal });
  res.json(flight);
}));
```

`asyncHandler` is a 10-line wrapper that forwards rejections:

```ts
// src/shared/async-handler.ts
import type { Request, Response, NextFunction, RequestHandler } from 'express';

export function asyncHandler<
  P = unknown, ResB = unknown, ReqB = unknown, ReqQ = unknown
>(
  fn: (req: Request<P, ResB, ReqB, ReqQ>, res: Response<ResB>, next: NextFunction) => Promise<unknown>
): RequestHandler<P, ResB, ReqB, ReqQ> {
  return (req, res, next) => {
    fn(req, res, next).catch(next);
  };
}
```

Alternative: `import 'express-async-errors';` once at the top of
`server.ts` — then plain async handlers propagate automatically. Pick ONE
approach per project.

## Routes — Fastify

One plugin per context. Declare `schema:` so Fastify validates body /
params / querystring before the handler runs; TypeScript types are
inferred from the schema with `json-schema-to-ts`.

```ts
// src/modules/flights/flights.routes.ts
import type { FastifyPluginAsync } from 'fastify';
import type { FromSchema } from 'json-schema-to-ts';

const CreateFlightSchema = {
  type: 'object',
  required: ['flightNumber', 'origin', 'destination'],
  additionalProperties: false,
  properties: {
    flightNumber: { type: 'string', minLength: 2, maxLength: 8 },
    origin: { type: 'string', minLength: 3, maxLength: 3 },
    destination: { type: 'string', minLength: 3, maxLength: 3 },
  },
} as const;

type CreateFlightBody = FromSchema<typeof CreateFlightSchema>;

export const flightsRoutes: FastifyPluginAsync = async (fastify) => {
  fastify.post<{ Body: CreateFlightBody }>(
    '/',
    { schema: { body: CreateFlightSchema } },
    async (request, reply) => {
      const service = fastify.diContainer.cradle.flightsService;
      const created = await service.create(request.body, {
        signal: request.raw.signal,
      });
      return reply
        .status(201)
        .header('location', `/api/v1/flights/${created.id}`)
        .send(created);
    }
  );
};
```

Async handlers propagate errors automatically — do NOT call `reply.send`
and then `throw`. Either `return reply.send(...)` or `throw httpError`.

## Error Handler — Express

```ts
// src/middleware/error-handler.ts
import type { Request, Response, NextFunction } from 'express';
import { ZodError } from 'zod';
import { DomainError, NotFoundError, ConflictError } from '../shared/errors';
import { toProblemDetails } from '../shared/problem-details';

export function errorHandler(
  err: unknown,
  req: Request,
  res: Response,
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  _next: NextFunction,
) {
  const status =
    err instanceof ZodError ? 400
    : err instanceof NotFoundError ? 404
    : err instanceof ConflictError ? 409
    : err instanceof DomainError ? 422
    : 500;

  const problem = toProblemDetails(err, status, req.originalUrl);

  if (status >= 500) req.log.error({ err }, 'request failed');
  else if (status >= 400) req.log.warn({ err }, 'request rejected');

  res.status(status)
     .type('application/problem+json')
     .json(problem);
}
```

The 4-argument signature `(err, req, res, next)` is REQUIRED — Express
detects error middleware by arity, not by name.

## Error Handler — Fastify

```ts
// src/shared/problem-details.ts
import type { FastifyError, FastifyReply, FastifyRequest } from 'fastify';
import { DomainError, NotFoundError, ConflictError } from './errors';

export function errorHandler(
  err: FastifyError,
  request: FastifyRequest,
  reply: FastifyReply,
) {
  const status =
    err.validation ? 400
    : err instanceof NotFoundError ? 404
    : err instanceof ConflictError ? 409
    : err instanceof DomainError ? 422
    : (err.statusCode ?? 500);

  if (status >= 500) request.log.error({ err }, 'request failed');
  else request.log.warn({ err }, 'request rejected');

  return reply.status(status).type('application/problem+json').send({
    type: 'about:blank',
    title: err.name ?? 'Error',
    status,
    detail: err.message,
    instance: request.url,
  });
}
```

## Correlation-ID Middleware (Express)

```ts
// src/middleware/correlation-id.ts
import { randomUUID } from 'node:crypto';
import type { Request, Response, NextFunction } from 'express';
import { logger } from '../logger';

const HEADER = 'x-correlation-id';

export function correlationIdMiddleware(
  req: Request, res: Response, next: NextFunction,
) {
  const id =
    (req.header(HEADER) ?? '').trim() || randomUUID();
  res.setHeader(HEADER, id);
  req.log = logger.child({ correlationId: id, path: req.path });
  next();
}

declare module 'express-serve-static-core' {
  interface Request {
    log: import('pino').Logger;
    scope: import('awilix').AwilixContainer;
    user?: { sub: string; scopes: string[] };
  }
}
```

## Correlation-ID Plugin (Fastify)

```ts
// src/plugins/correlation-id.ts
import fp from 'fastify-plugin';
import { randomUUID } from 'node:crypto';
import { logger } from '../logger';

export const correlationIdPlugin = fp(async (fastify) => {
  fastify.addHook('onRequest', async (request, reply) => {
    const header = (request.headers['x-correlation-id'] as string | undefined)?.trim();
    const id = header || randomUUID();
    reply.header('x-correlation-id', id);
    request.log = logger.child({ correlationId: id, path: request.url });
  });
});

declare module 'fastify' {
  interface FastifyRequest {
    log: import('pino').Logger;
    user?: { sub: string; scopes: string[] };
  }
}
```

## Dependency Injection — awilix (Express)

```ts
// src/container.ts
import { createContainer, asClass, asFunction, InjectionMode } from 'awilix';
import { Pool } from 'pg';
import { loadConfig } from './config';
import { FlightsRepository } from './modules/flights/flights.repository';
import { FlightsService } from './modules/flights/flights.service';

export const container = createContainer({
  injectionMode: InjectionMode.PROXY,
});

const config = loadConfig();

container.register({
  config: asFunction(() => config).singleton(),
  pgPool: asFunction(() => new Pool({ connectionString: config.DATABASE_URL }))
            .singleton()
            .disposer((pool) => pool.end()),
  flightsRepository: asClass(FlightsRepository).scoped(),
  flightsService: asClass(FlightsService).scoped(),
});
```

Handlers resolve via `req.scope.resolve('flightsService')`. Tests swap
dependencies with `container.register({ flightsRepository: asValue(mock) })`.

## Dependency Injection — Fastify

Two accepted patterns. Pick ONE per project.

### Pattern A: `@fastify/awilix`

```ts
// src/container.ts
import { diContainer } from '@fastify/awilix';
import { asClass, asFunction } from 'awilix';
import { Pool } from 'pg';

export function registerContainer(container: typeof diContainer) {
  container.register({
    pgPool: asFunction(() => new Pool({ connectionString: process.env.DATABASE_URL }))
              .singleton()
              .disposer((pool) => pool.end()),
    flightsRepository: asClass(FlightsRepository).scoped(),
    flightsService: asClass(FlightsService).scoped(),
  });
}
```

Handlers access via `fastify.diContainer.cradle.flightsService`.

### Pattern B: `tsyringe`

```ts
// src/container.ts
import 'reflect-metadata';
import { container } from 'tsyringe';
import { Pool } from 'pg';

container.register<Pool>('PgPool', {
  useFactory: () => new Pool({ connectionString: process.env.DATABASE_URL }),
});
container.registerSingleton('FlightsRepository', FlightsRepository);
container.registerSingleton('FlightsService', FlightsService);

// Usage inside a handler / plugin:
// const service = container.resolve<FlightsService>('FlightsService');
```

`tsyringe` requires `reflect-metadata` at the top of `server.ts` and
`experimentalDecorators` + `emitDecoratorMetadata` in `tsconfig.json`.

## Repository Layer

Repositories are thin — parameter binding, query execution, and mapping:

```ts
// src/modules/flights/flights.repository.ts
import type { Pool } from 'pg';
import type { Flight } from './flights.types';

export class FlightsRepository {
  constructor(private readonly pgPool: Pool) {}

  async findById(id: string, opts: { signal: AbortSignal }): Promise<Flight | null> {
    const { rows } = await this.pgPool.query({
      text: 'SELECT id, flight_number, origin, destination FROM flights WHERE id = $1',
      values: [id],
    });
    return rows[0] ? this.toDomain(rows[0]) : null;
  }

  async insert(flight: Flight): Promise<void> {
    await this.pgPool.query({
      text: `INSERT INTO flights (id, flight_number, origin, destination)
             VALUES ($1, $2, $3, $4)`,
      values: [flight.id, flight.flightNumber, flight.origin, flight.destination],
    });
  }

  private toDomain(row: Record<string, unknown>): Flight { /* ... */ }
}
```

## Transaction Scoping

Transactions live in application services, not repositories.

```ts
// src/modules/flights/flights.service.ts
import type { Pool, PoolClient } from 'pg';
import { FlightsRepository } from './flights.repository';

export class FlightsService {
  constructor(
    private readonly pgPool: Pool,
    private readonly flightsRepository: FlightsRepository,
  ) {}

  async createBatch(flights: Flight[]): Promise<void> {
    const client: PoolClient = await this.pgPool.connect();
    try {
      await client.query('BEGIN');
      const txRepo = new FlightsRepository(client as unknown as Pool);
      for (const flight of flights) {
        await txRepo.insert(flight);
      }
      await client.query('COMMIT');
    } catch (err) {
      await client.query('ROLLBACK');
      throw err;
    } finally {
      client.release();
    }
  }
}
```

With Prisma, prefer `prisma.$transaction(async (tx) => { ... })` instead.

## Graceful Shutdown

Every server must close cleanly on `SIGTERM` so orchestrators (Kubernetes,
ECS) roll out new versions without dropping in-flight requests.

```ts
// src/server.ts
import { buildApp } from './app';
import { logger } from './logger';
import { container } from './container';

async function main() {
  const app = await buildApp();
  const server = app.listen(Number(process.env.PORT ?? 8080), () => {
    logger.info({ port: process.env.PORT }, 'server listening');
  });

  const shutdown = async (signal: string) => {
    logger.info({ signal }, 'shutdown starting');
    server.close(async (err) => {
      if (err) logger.error({ err }, 'server close errored');
      await container.dispose();
      process.exit(err ? 1 : 0);
    });
  };

  process.once('SIGTERM', () => void shutdown('SIGTERM'));
  process.once('SIGINT', () => void shutdown('SIGINT'));
}

void main();
```

For Fastify, call `app.close()` in the shutdown hook instead of
`server.close()`.

## Cancellation

Pipe an `AbortSignal` through service / repository calls so a client
disconnect stops the downstream work. Express 5 / Node 20 expose
`req.signal`; for Express 4, synthesize a controller on `res.on('close')`.

## Do / Don't

| Do | Don't |
|---|---|
| Wrap Express handlers in `asyncHandler` OR import `express-async-errors` once | Silently swallow rejections with `.catch(noop)` |
| Declare `schema:` on every Fastify route | Re-validate manually inside Fastify handlers |
| Resolve services from awilix / tsyringe | `require('./service')` inside a handler |
| Put `errorHandler` LAST in Express | Register custom error handlers before routers |
| Use streams for large payloads | Buffer multi-MB JSON in memory |
| Close DB pools on SIGTERM | Rely on `process.exit(0)` without draining |
