# Structured Logging Reference (Node.js)

Every generated Node.js service emits structured JSON logs. Logs are
one-line JSON by default in non-development environments so CloudWatch
Logs Insights, Datadog, OpenSearch, and Loki can ingest them without a
custom parser. Development uses pretty-printed output for readability.

Pino is the default library; winston is supported as a secondary option
for teams with an existing investment.

## Why Structured Logs

- **Searchable fields** — `correlationId`, `userId`, `flightNumber`
  become indexable properties
- **Aggregation** — count failures by `errorCode` without grepping
- **Distributed tracing** — correlation IDs link logs across services
- **Alerting** — threshold alerts fire on a structured metric, not a
  regex over raw text

## Pino (default)

Pino is ~10x faster than winston for JSON and has a smaller dependency
footprint. Choose pino unless the client profile requires winston.

### Root Logger

```ts
// src/logger.ts
import pino from 'pino';
import { loadConfig } from './config';

const config = loadConfig();

export const logger = pino({
  level: config.LOG_LEVEL ?? 'info',
  base: {
    app: config.APP_NAME,
    env: config.NODE_ENV,
    version: config.APP_VERSION,
  },
  timestamp: pino.stdTimeFunctions.isoTime,
  formatters: {
    level(label) {
      return { level: label };  // string, not numeric, for CloudWatch
    },
  },
  redact: {
    paths: [
      'req.headers.authorization',
      'req.headers.cookie',
      'password',
      '*.password',
      'token',
      '*.token',
      'ssn',
      'creditCard',
    ],
    censor: '[REDACTED]',
  },
  // Pretty-print only in development
  transport: config.NODE_ENV === 'development'
    ? {
        target: 'pino-pretty',
        options: {
          colorize: true,
          translateTime: 'SYS:yyyy-mm-dd HH:MM:ss.l',
          ignore: 'pid,hostname,app,env,version',
        },
      }
    : undefined,
});
```

### Child Loggers per Request

Correlation IDs thread through a request so every log line from one HTTP
request can be filtered together. The correlation-ID middleware attaches
a child logger to `req.log` / `request.log`.

```ts
// Express
req.log = logger.child({
  correlationId,
  method: req.method,
  path: req.path,
});

// Fastify
request.log = logger.child({
  correlationId,
  method: request.method,
  path: request.url,
});
```

Handlers and services use `req.log` instead of the root `logger`:

```ts
export class FlightsService {
  constructor(
    private readonly repo: FlightsRepository,
    private readonly baseLogger: pino.Logger,
  ) {}

  async create(input: CreateFlightInput, ctx: { log: pino.Logger }): Promise<Flight> {
    const log = (ctx.log ?? this.baseLogger).child({ service: 'flights.create' });
    log.info({ flightNumber: input.flightNumber }, 'creating flight');
    const flight = await this.repo.insert(input);
    log.info({ flightId: flight.id }, 'flight created');
    return flight;
  }
}
```

### Log Levels

Use levels consistently across the codebase:

| Level   | Use for |
|---------|---------|
| `trace` | Development-only verbose tracing; rarely emitted |
| `debug` | Useful when investigating; off in production |
| `info`  | Normal business events (request start, user created) |
| `warn`  | Recoverable abnormality (retry, rate-limit, 4xx response) |
| `error` | Unrecoverable in this request (500, unhandled exception) |
| `fatal` | Process is about to exit (startup failure, unreachable DB) |

Production default: `info`. Staging default: `debug` during stabilization.

### Request Lifecycle Logging

Log one line per request with duration, status, and key identifiers.
Both frameworks can do this automatically.

#### Express — via `pino-http`

```ts
import pinoHttp from 'pino-http';
import { logger } from './logger';

app.use(pinoHttp({
  logger,
  customLogLevel: (_req, res, err) =>
    err || res.statusCode >= 500 ? 'error'
    : res.statusCode >= 400 ? 'warn'
    : 'info',
  customSuccessMessage: (req, res) =>
    `${req.method} ${req.url} -> ${res.statusCode}`,
  customErrorMessage: (req, res, err) =>
    `${req.method} ${req.url} -> ${res.statusCode} ${err.message}`,
  customProps: (req) => ({ correlationId: req.headers['x-correlation-id'] }),
  serializers: {
    req: (req) => ({ method: req.method, url: req.url }),
    res: (res) => ({ statusCode: res.statusCode }),
  },
}));
```

#### Fastify — built-in

Fastify emits one request log automatically when its logger is configured
with pino. Attach the same pino instance:

```ts
const app = Fastify({
  logger: {
    level: config.LOG_LEVEL,
    base: { app: config.APP_NAME, env: config.NODE_ENV },
    formatters: { level: (label) => ({ level: label }) },
    timestamp: pino.stdTimeFunctions.isoTime,
    redact: pinoRedactConfig,
  },
  genReqId: (req) =>
    (req.headers['x-correlation-id'] as string | undefined)?.trim() ||
    randomUUID(),
});
```

### Message Templates vs String Interpolation

Always pass structured data as the first object argument. Never build the
message with template literals — you lose the property on ingestion.

```ts
// Good — flightNumber becomes a queryable field
req.log.info({ flightNumber, origin, destination }, 'flight created');

// Bad — value is trapped in the message string
req.log.info(`flight created: ${flightNumber} ${origin}->${destination}`);
```

### Logging Errors

Always pass the `Error` under the `err` key so pino's built-in serializer
captures stack + cause:

```ts
try {
  await publishDomainEvent(event);
} catch (err) {
  req.log.error({ err, eventType: event.type }, 'publish failed');
  throw err;
}
```

`pino` has a registered serializer for `err` that produces
`{ type, message, stack }`. Third-party errors with `.cause` chains
serialize recursively.

## winston (secondary)

Use winston only when a profile mandates it — it's slower and noisier in
config, but widely deployed.

```ts
// src/logger.ts
import winston from 'winston';
import { loadConfig } from './config';

const config = loadConfig();

const redactFormat = winston.format((info) => {
  const redact = (obj: Record<string, unknown>): Record<string, unknown> => {
    const out: Record<string, unknown> = {};
    for (const [key, value] of Object.entries(obj)) {
      if (['password', 'token', 'authorization', 'ssn', 'creditCard'].includes(key)) {
        out[key] = '[REDACTED]';
      } else if (value && typeof value === 'object' && !Array.isArray(value)) {
        out[key] = redact(value as Record<string, unknown>);
      } else {
        out[key] = value;
      }
    }
    return out;
  };
  return { ...redact(info as Record<string, unknown>) } as winston.Logform.TransformableInfo;
});

export const logger = winston.createLogger({
  level: config.LOG_LEVEL ?? 'info',
  defaultMeta: {
    app: config.APP_NAME,
    env: config.NODE_ENV,
    version: config.APP_VERSION,
  },
  format: winston.format.combine(
    winston.format.timestamp(),
    winston.format.errors({ stack: true }),
    redactFormat(),
    winston.format.json(),
  ),
  transports: [new winston.transports.Console()],
});
```

winston child loggers per request:

```ts
req.log = logger.child({ correlationId: req.headers['x-correlation-id'] });
```

## Correlation IDs

Every request carries an `X-Correlation-Id` header (case-insensitive).
The middleware / plugin:

1. Reads the inbound header; generates a UUID if missing.
2. Sets the header on the outbound response.
3. Attaches it to the per-request child logger.
4. Propagates it on every outbound HTTP / DB call.

Outbound propagation example (undici):

```ts
import { fetch } from 'undici';

async function callDownstream(req: Request, url: string): Promise<Response> {
  return fetch(url, {
    headers: {
      'x-correlation-id': req.headers['x-correlation-id'] as string,
      'content-type': 'application/json',
    },
  });
}
```

For database queries, include the correlation ID as a SQL comment so it
lands in pg_stat_statements / Performance Insights:

```ts
await pool.query({
  text: `/* correlationId=${correlationId} */ SELECT ...`,
  values: [...],
});
```

## CloudWatch Logs Shipping

Container stdout is scraped by the AWS Fluent Bit / CloudWatch agent;
no application-side configuration is needed. Ensure:

- One JSON object per line — pino default in non-dev
- `timestamp` field in ISO 8601 — `pino.stdTimeFunctions.isoTime`
- `level` field as a string — `formatters.level` override (see root
  logger)
- No ANSI color codes — `pino-pretty` is development-only

CloudWatch Logs Insights query example:

```
fields @timestamp, correlationId, level, msg
| filter level in ["error","warn"]
| filter correlationId = "7ad4b2f6-..."
| sort @timestamp desc
```

### CloudWatch Metric Filters

Promote a structured field to a CloudWatch metric — e.g., count of 500
responses by endpoint:

```
{ $.level = "error" && $.statusCode = 500 }
```

### OpenTelemetry (optional)

When the blueprint calls for distributed tracing, wire pino with
`@opentelemetry/instrumentation-pino`. The instrumentation adds
`trace_id` and `span_id` to every log line so traces and logs correlate
in Datadog / Honeycomb / Jaeger.

```ts
import { PinoInstrumentation } from '@opentelemetry/instrumentation-pino';
import { registerInstrumentations } from '@opentelemetry/instrumentation';

registerInstrumentations({
  instrumentations: [new PinoInstrumentation()],
});
```

## Sensitive-Data Redaction

Never log:

- Passwords, tokens, API keys, JWT bearer headers, cookies
- SSNs, credit card numbers, bank account numbers, passport numbers
- Full request bodies on auth / payment endpoints
- Plaintext query strings containing secrets

Pino `redact` and winston's custom format handle the common cases.
For payload-level masking, introduce a `RedactableRequest` type with a
`toLog()` method:

```ts
class CreatePaymentRequest {
  constructor(
    public readonly cardNumber: string,
    public readonly amount: number,
  ) {}

  toLog() {
    return {
      cardNumber: `****${this.cardNumber.slice(-4)}`,
      amount: this.amount,
    };
  }
}

req.log.info({ payment: payment.toLog() }, 'payment received');
```

Also strip secrets from URLs when logging outbound HTTP requests. Never
log raw authorization headers, cookies, or `password=` query params.

## Health Endpoints and Noise

Readiness probes hit `/health/ready` every few seconds and would flood
logs at `info`. Downgrade them to `debug`:

```ts
app.use(pinoHttp({
  logger,
  customLogLevel: (req, res, err) => {
    if (req.url?.startsWith('/health')) return 'debug';
    if (err || res.statusCode >= 500) return 'error';
    if (res.statusCode >= 400) return 'warn';
    return 'info';
  },
}));
```

## Startup and Shutdown Logs

Log exactly three lines at startup (version, listening, ready) and two
at shutdown (received signal, closed) so a restart loop is easy to spot
in CloudWatch:

```ts
logger.info({ version: config.APP_VERSION, node: process.version }, 'starting');
// ... bind port ...
logger.info({ port: config.PORT }, 'listening');
// ... DB / cache warmup ...
logger.info('ready');

process.once('SIGTERM', () => {
  logger.info({ signal: 'SIGTERM' }, 'shutdown starting');
  // ... drain ...
  logger.info('shutdown complete');
  process.exit(0);
});
```

## Do / Don't

| Do | Don't |
|---|---|
| Use pino (default) — it is faster and simpler than winston | Mix pino and winston in the same service |
| Pass structured fields as the first arg object | Interpolate into the message string |
| Emit one line per request via `pino-http` / Fastify built-in | Log before and after every middleware manually |
| Attach `correlationId` to every line via `child()` | Pass correlation IDs through every function signature |
| Redact `authorization`, `cookie`, `password` paths | Log raw auth headers or PII |
| Use string-level format in non-dev (`level: 'info'`) | Emit numeric levels (`level: 30`) — breaks CloudWatch filters |
| Downgrade `/health` lines to `debug` | Log every readiness probe at `info` |
| Serialize errors with `{ err }` | `logger.error(err.message)` — loses stack |
