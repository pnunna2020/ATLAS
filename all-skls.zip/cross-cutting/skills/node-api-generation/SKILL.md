---
name: node-api-generation
description: >
  Generate production-ready Node.js 20 / TypeScript REST APIs on Express or
  Fastify — routers, middleware, service layers, data-access repositories,
  structured logging, and Jest test scaffolding — from extraction artifacts
  and the abstract scaffold produced by code-generation-abstract. Produces
  compilable, convention-following applications with dependency-injected
  services, Zod / AJV request validation, pino structured logs, and
  supertest-based integration tests — ready for the Ralph Loop
  (tdd-generation) to validate through test-driven iteration. Invoke during
  P4.3 Generate only when the target architecture specifies Node.js /
  Express / Fastify with JavaScript or TypeScript. Triggers on Node API
  generation, Express generation, Fastify generation, TypeScript API
  generation, or @node-api-generation mentions.
agent: sonnet
allowed-tools:
  - Read
  - Write
  - Bash
  - Grep
enrichment_level: Full
phase: P4
validation_commands:
  - "npm run -s typecheck"
  - "npm run -s lint"
  - "npm test -- --ci --runInBand"
  - "npm run -s build"
supported_stacks:
  - node
  - nodejs
  - typescript
  - javascript
  - express
  - fastify
  - jest
  - supertest
  - pino
anti_target_stacks:
  - java
  - spring-boot
  - dotnet
  - csharp
  - python
  - fastapi
  - cobol
  - natural
  - adabas
  - coldfusion
failure_classes:
  - blocking-event-loop
  - unhandled-promise-rejection
  - missing-async-error-handler
  - middleware-order-drift
  - dependency-injection-via-globals
  - logger-plain-text-in-prod
  - hardcoded-secret
  - jest-open-handles
  - commonjs-esm-drift
benchmark_tags:
  - generation-node-api
  - express-fastify-routing
  - typescript-strict-api
  - jest-supertest-suite
  - pino-structured-logging
---

# Node.js API Generation

## Purpose
Generate production-ready Node.js 20 / TypeScript code from extraction
artifacts and the abstract scaffold produced by `code-generation-abstract`.
This skill produces compilable, convention-following Node services on either
Express 4.x or Fastify 4.x, with typed routers, dependency-injected service
layers, data-access repositories, Zod / AJV request validation, pino
structured logging, health endpoints, Dockerized deployment, and Jest +
supertest test scaffolding — ready for the Ralph Loop (tdd-generation) to
validate through test-driven iteration.

Invoke this skill after `code-generation-abstract` has produced the project
scaffold and implementation plan, and only when the target architecture
blueprint specifies Node.js / Express or Fastify. It replaces TODO stubs with
real TypeScript implementation code, following the generation order
specified in the implementation plan (data layer -> domain layer ->
application layer -> API layer -> tests).

## When to Use
Invoke when the architecture blueprint, technology profile, or design
artifacts specify any of the following:

- `target_language` in {`javascript`, `typescript`, `node`, `nodejs`,
  `typescript-node`}
- `target_framework` in {`express`, `express.js`, `fastify`, `node-api`}
- Existing stack is Node.js (legacy Express, hapi, koa, or CommonJS-only
  services) and the disposition is Refactor onto modern Express 4.x or
  Fastify 4.x with TypeScript
- Client profile technology stack lists `Node.js + Express` or
  `Node.js + Fastify` as the Web API archetype

Do NOT invoke this skill when the target is Spring Boot, .NET, or FastAPI.
Verify the tech stack before proceeding.

## Inputs
- `code-generation-abstract` output (project scaffold, implementation plan,
  traceability index)
- Extraction artifact from Step 1 (business rules YAML, test scenarios,
  module inventory)
- Target architecture blueprint from Step 2 (must specify Express or
  Fastify, and TypeScript vs JavaScript)
- OpenAPI 3.x specifications from `api-specification` skill
- Data models and DDL from `data-modeling` skill
- Risk tier (T1, T2, T3) from Rationalization

## Outputs
- Complete Node.js project structure (`src/`, `test/`, `dist/`) with
  `package.json`, `tsconfig.json`, and pinned dependencies
- Express or Fastify server entrypoint (`src/server.ts`) wiring middleware,
  plugins, routers, error handlers, and graceful shutdown
- Router modules per bounded context with full endpoint implementations
- Service layer with business logic from extracted rules, injected via
  awilix (Express) or Fastify's `fastify.decorate` / `fastify-awilix`
- Repository layer over a data source abstraction (pg / Prisma / Knex —
  whichever the blueprint specifies)
- Zod (or AJV schemas) for request/response validation; DTO types derived
  from the schemas (`z.infer<...>`)
- `src/config/index.ts` loading strongly-typed configuration from
  environment variables via `zod` + `dotenv`
- Structured logging with pino; request-scoped child logger and
  correlation-ID middleware
- Global error handler producing RFC 7807 Problem Details responses
- Health endpoints (`/health/live`, `/health/ready`) including DB probe
- Jest config (`jest.config.ts`) plus `test/unit/` and `test/integration/`
  suites using supertest for HTTP and mocked modules for dependencies
- `Dockerfile` (multi-stage, non-root, `node:20-alpine` runtime) and
  `docker-compose.yml` for local dev
- `README.md` with build / run / test commands

## Methodology

### Step 1: Validate Scaffold and Load Inputs
Read the abstract scaffold from `code-generation-abstract`. Validate that:
1. The scaffold specifies Express or Fastify as the target framework
2. Node package layout (`src/`, `test/`, `package.json`, `tsconfig.json`)
   exists
3. The implementation plan lists modules in dependency-respecting order
4. OpenAPI specs are available for all bounded contexts with API endpoints

Load the extraction artifact and map business rules to bounded contexts
using the traceability index from the scaffold.

### Step 2: Generate Data-Access Layer
Generate repository modules per aggregate root over the chosen data source
(pg pool, Prisma client, or Knex). Keep repositories thin: parameter
binding, query execution, and row-to-domain mapping only — no business
rules. Every repository method returns `Promise<T>` and accepts an
`AbortSignal` to support request cancellation.

See `references/express-fastify-patterns.md` for repository wiring and
transaction scoping (`pg.Client`-per-request or Prisma `$transaction`).

### Steps 3-4: Generate Domain and Application Layers
Generate domain services (per aggregate root, pure `async` functions with
no framework imports), domain events (frozen objects with past-tense
names), value objects (readonly classes or branded types), and
application services (orchestration only, no business logic).
Application services are where transaction boundaries belong; domain
services never open or commit transactions.

See `references/express-fastify-patterns.md` for DI container wiring
(awilix for Express, `@fastify/awilix` or `tsyringe` for Fastify) and
the transactional-application-service pattern.

### Steps 5-6: Generate Routers, Schemas, and Error Handling
Generate router modules from OpenAPI specs:
- **Express** — one `Router` per context; handlers declared as
  `async (req, res, next)` with `next(err)` for error propagation or an
  `asyncHandler` wrapper that forwards rejections.
- **Fastify** — one plugin per context registered via
  `fastify.register(routes, { prefix })`; route options declare `schema:
  { body, params, querystring, response }` so Fastify handles validation
  automatically.

Generate Zod schemas (Express) or JSON Schema definitions with
`json-schema-to-ts` (Fastify) for every request/response. Produce a global
error handler middleware (Express) or `setErrorHandler` (Fastify) that
emits RFC 7807 Problem Details.

See `references/express-fastify-patterns.md` for router composition, the
middleware stack order, and error-handler signatures.

### Steps 7-8: Generate Configuration, Build, and Deployment Files
Produce:
- `src/config/index.ts` — a Zod-validated `Config` object loaded from
  environment variables; fails fast on startup when required vars are
  missing.
- `src/logger.ts` — pino root logger with `pino-pretty` transport in
  development and JSON output in staging/production; child-logger helper
  that attaches `correlationId` per request.
- Authentication middleware — JWT bearer verification against OKTA JWKS
  (using `jose` or `fast-jwt`); populates `req.user` / `request.user`.
- `/health/live` and `/health/ready` endpoints; readiness probe executes
  a bounded `SELECT 1` against the primary DB.
- `package.json` scripts — `build`, `start`, `dev`, `test`, `lint`,
  `typecheck`, `format`.
- `tsconfig.json` with `strict: true`, `noUncheckedIndexedAccess: true`,
  `exactOptionalPropertyTypes: true`, ES2022 target, and
  `moduleResolution: "NodeNext"`.
- `Dockerfile` — multi-stage (`node:20-alpine` builder +
  `node:20-alpine` runtime), non-root user, `HEALTHCHECK` hitting
  `/health/live`.
- `.dockerignore`, `.nvmrc` pinning Node 20.

See `references/structured-logging-node.md` for pino and winston
configuration, log levels, redaction policies, and CloudWatch shipping.

### Step 9: Generate Test Scaffolding
Produce `test/unit/` (no network, no DB, mocked modules) and
`test/integration/` (supertest against the in-process app) scaffolding:
- `jest.config.ts` with `testEnvironment: "node"`, `setupFilesAfterEnv`,
  `coverageThreshold` gates, and a `detectOpenHandles` CI flag.
- Per-router integration test using supertest: boot the app factory with
  test configuration and an in-memory or Testcontainers-backed database.
- Per-service unit test with mocked repository module
  (`jest.mock('../repo')`).
- Shared helpers in `test/helpers/` for building HTTP clients, seeding
  fixtures, and closing resources in `afterAll`.

See `references/jest-testing-patterns.md` for supertest composition,
`jest.mock` patterns, async-aware assertions, and the leak-free teardown
checklist.

## Tech-Stack Dispatch
This skill targets a single technology family. Before generating, validate
that the target architecture specifies one of these Node configurations:

| Configuration        | Node Version | Framework   | Language   | Data Layer           |
|----------------------|:------------:|:-----------:|:----------:|:---------------------|
| Express + TypeScript | 20.x LTS     | Express 4.x | TypeScript | pg / Prisma / Knex   |
| Fastify + TypeScript | 20.x LTS    | Fastify 4.x | TypeScript | pg / Prisma / Knex   |
| Express + JavaScript | 20.x LTS     | Express 4.x | JavaScript | pg / Knex            |

TypeScript is the default. Fall back to JavaScript only when the client
profile explicitly disallows a TypeScript build step.

If the architecture blueprint specifies a non-Node target (Spring Boot,
.NET, FastAPI), this skill should NOT be invoked. Check the tech stack
before proceeding.

## Disposition Context
This skill applies to applications dispositioned as:
- **Refactor**: Legacy Node.js (CommonJS Express, hapi, koa, or
  un-typed JavaScript) modernized to TypeScript + Express 4.x or
  Fastify 4.x with strict typing and structured logging.
- **Rearchitect**: Non-Node legacy (ColdFusion, Classic ASP, PHP, Perl)
  rewritten in TypeScript on Express or Fastify when the client profile
  specifies Node as the target stack.

For Refactor dispositions, preserve existing module boundaries and URL
paths where possible. For Rearchitect dispositions, use clean-slate
conventions with no legacy naming carryover.

## Gotchas
- **Event loop is single-threaded**: any synchronous CPU-bound call
  (unbounded JSON parse, `crypto.pbkdf2Sync`, regex backtracking) blocks
  every concurrent request. Use async APIs (`crypto.pbkdf2`,
  `child_process` / worker threads for CPU work) and stream large
  payloads instead of buffering.
- **Unhandled promise rejections crash the process** on Node 20 by
  default (`--unhandled-rejections=throw`). Every `async` route handler
  must either `await` and let errors propagate to the framework error
  handler, or wrap in `try/catch`. For Express, use an `asyncHandler`
  wrapper or register `express-async-errors`. For Fastify, async
  handlers propagate automatically — do NOT call `reply.send` and then
  return a Promise that rejects.
- **Middleware order matters**: body-parser / `express.json()` must be
  registered before routers; error handlers must be the last `app.use`
  call and take four arguments `(err, req, res, next)`; CORS must be
  registered before auth; the correlation-ID middleware must be the
  first application middleware so every later log line includes it.
- **No field injection / service locators**: never `require` a service
  from inside a handler or reach into a module-level singleton. Resolve
  dependencies from the awilix / Fastify container so tests can swap
  them. Singletons hide state and make tests order-dependent.
- **Secrets are never in `.env.production`, `package.json`, or
  `config.json`**: the Config module reads from `process.env` and the
  `.env` file is dev-only. Staging / prod secrets come from AWS Secrets
  Manager or Parameter Store at runtime. Hardcoded secrets fail the
  G-04c security scan.
- **Pino is not console.log**: do not interpolate values into the log
  message. Pass a first-argument object (`logger.info({ userId }, 'user
  created')`) so every field becomes a structured JSON property that
  CloudWatch / Datadog can index.
- **CommonJS vs ESM drift**: the generated project uses either
  `"type": "module"` + ESM everywhere or CommonJS everywhere — never
  mixed. Mixing causes silent import failures (top-level `await`
  unavailable in CJS, `__dirname` missing in ESM). Pick one based on the
  blueprint and enforce via ESLint's `import/no-commonjs` rule.
- **Express has no built-in validation; Fastify does**: Express handlers
  must call `schema.parse(req.body)` explicitly (throws on invalid);
  Fastify handlers declare `schema:` on the route and validation runs
  before the handler executes. Do not duplicate validation on Fastify.
- **Jest open handles**: unclosed database pools, timers, or HTTP
  servers leak between tests and cause the suite to hang in CI. Close
  them in a `afterAll` block and run CI with `--detectOpenHandles`.

## Quality Rules
- [ ] Generated code type-checks with `tsc --noEmit` — zero errors under
      `strict: true` and `noUncheckedIndexedAccess: true`
- [ ] `npm run lint` passes (ESLint + @typescript-eslint with the repo's
      shared config) with zero errors
- [ ] `npm run build` produces a `dist/` directory with source maps; no
      `any` types remain in generated code
- [ ] All route handlers are `async` and errors propagate to the global
      error handler — no silent `.catch(() => {})`
- [ ] Every Express handler is wrapped in `asyncHandler` OR the project
      loads `express-async-errors` at the top of `server.ts`
- [ ] Every Fastify route declares `schema:` for body / params /
      querystring / response
- [ ] Request / response bodies validated by Zod (Express) or Fastify
      JSON Schema — no `req.body as any`
- [ ] Dependency injection via awilix (Express) or `@fastify/awilix` /
      `tsyringe` (Fastify); no `require()` of services inside handlers
- [ ] Global error handler emits RFC 7807 Problem Details with
      `content-type: application/problem+json`
- [ ] pino logger configured as JSON in non-development environments;
      `pino-pretty` only in `NODE_ENV=development`
- [ ] Correlation-ID middleware injects `x-correlation-id` header and
      attaches a child logger to `req.log` / `request.log`
- [ ] No `console.log` / `console.error` calls in application code
- [ ] `Config` object loaded through Zod; process exits with non-zero
      status on missing required env vars
- [ ] `/health/live` and `/health/ready` endpoints exist; readiness
      probes DB connectivity with a bounded timeout
- [ ] JWT bearer verification uses OKTA JWKS via `jose` or `fast-jwt`;
      tokens validated against issuer, audience, and expiry
- [ ] Jest tests run with `--detectOpenHandles --forceExit=false` in CI;
      no leaked timers, sockets, or DB pools
- [ ] Integration tests use supertest against the app factory with a
      Testcontainers-backed or in-memory database
- [ ] Unit tests mock external modules via `jest.mock('<path>')`; no
      tests hit the real network
- [ ] `package.json` pins every direct dependency to an exact version;
      `package-lock.json` committed
- [ ] Dockerfile multi-stage build uses `node:20-alpine`, runs as a
      non-root user, and declares a `HEALTHCHECK`
- [ ] No route handler exceeds 20 lines of logic — business rules are
      in the service layer

## Common Failure Modes
| Failure Mode | Symptom | Prevention |
|--------------|---------|------------|
| blocking-event-loop | p99 latency spikes under modest load; CPU flamegraph shows long sync frames | Ban `Sync` crypto / fs calls in handler code; lint for `fs.readFileSync` in routes; offload CPU work to workers |
| unhandled-promise-rejection | Process crashes / restarts; PM2 / container orchestrator logs uncaught rejection; requests fail with empty response | Use `asyncHandler` wrapper (Express) or rely on Fastify's native async propagation; register `process.on('unhandledRejection', fatalExit)` for defense in depth |
| missing-async-error-handler | Requests hang indefinitely; client timeouts; no 5xx response emitted | Express: 4-arg `(err, req, res, next)` error handler registered last; Fastify: `fastify.setErrorHandler(...)`. Integration test covers the 500 path. |
| middleware-order-drift | Routes cannot read body; CORS preflight fails; errors bypass the custom handler | Document the canonical order in `server.ts`; add a startup assertion that verifies body-parser precedes routers and error handler is last |
| dependency-injection-via-globals | Tests are order-dependent; mocking requires rewriting requires; hot-reload breaks singletons | All services resolved via awilix / tsyringe container; handlers request dependencies from `req.scope.resolve(...)` or `fastify.diContainer` |
| logger-plain-text-in-prod | CloudWatch ingests unparseable text; cannot filter / aggregate by field | Force `PINO_PRETTY=false` in non-dev; assert JSON structure in a smoke test; configure pino with `formatters.level` for numeric levels |
| hardcoded-secret | G-04c security scan fails; rotating a credential requires redeploy | Config module reads only from `process.env`; grep-and-reject literal secrets; no `.env.production` file in the repo |
| jest-open-handles | Suite hangs on CI; `--detectOpenHandles` reports unclosed pools / sockets | Close DB pools, HTTP servers, Redis clients in `afterAll`; prefer `testcontainers` with `container.stop()` in teardown |
| commonjs-esm-drift | `Cannot use import statement outside a module` at runtime; `__dirname is not defined`; silent dual-package hazard | Commit to one module system in `package.json`; add `eslint-plugin-import` rule `import/no-commonjs` (ESM project) or `import/no-import-module-exports` (CJS project) |

## Handoff Summary
When this skill completes, verify:
1. `npm run typecheck` passes with zero errors
2. `npm run lint` passes with zero errors
3. `npm run build` produces `dist/` cleanly
4. `npm test -- --ci` runs the generated test stubs; all suites are
   collected and pass (or fail with TODOs for Ralph Loop)
5. All REST endpoints match the Step 2 OpenAPI specification (paths,
   methods, status codes, response schemas)
6. Repository modules match the Step 2 ER diagram (tables, columns,
   relationships)
7. Every service method cites extraction rule IDs in JSDoc / TSDoc
8. Integration test stubs exist for every router endpoint
9. Authentication middleware matches the api-spec security scheme
10. `/health/live` and `/health/ready` respond 200 / 503 appropriately
11. `Dockerfile` builds and the container starts under `docker run`

Then proceed to: `tdd-generation` (P4.3) for Ralph Loop test-driven
validation, `security-scan-review` for static analysis, and gate `G-04c`
for generation quality review.

## References
- `references/express-fastify-patterns.md` — router structure, middleware
  order, plugin composition, error-handler signatures, DI wiring with
  awilix and tsyringe
- `references/jest-testing-patterns.md` — supertest patterns, mocked
  modules, async assertions, setup/teardown checklist, Testcontainers
  integration
- `references/structured-logging-node.md` — pino vs winston, correlation
  IDs, log levels, redaction, shipping to CloudWatch and Datadog
