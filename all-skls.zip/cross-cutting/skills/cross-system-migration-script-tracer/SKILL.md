---
name: cross-system-migration-script-tracer
description: >
  Detect `db/` directories containing SQL migration scripts that
  target multiple systems — tickets prefixed by different app names
  co-owning the same database. AMCS is the ATLAS case: its
  `db/DB Scripts/` has `AMCS-*.sql`, `DIWS-*.sql`, `CPDSS-*.sql`,
  `USAS-*.sql`, `DHS_*.sql` — each prefix maps to a different team,
  all applied to one shared Oracle schema. Modernization must
  preserve ownership while untangling the schema. Runs as Discovery
  conditional when `db/` has ticket-prefixed files with > 1 distinct
  prefix. Triggers on cross-system migration audit or
  @cross-system-migration-script-tracer.
agent: sonnet
allowed-tools:
  - Read
  - Write
  - Grep
  - Glob
validation_commands:
  - "python -m olympus.validators.schema_validator migration-ownership-inventory.json"
  - "python -m olympus.validators.schema_validator shared-schema-contention-findings.json"
supported_stacks:
  - oracle
  - sqlserver
  - plsql
  - tsql
  - migration-scripts
anti_target_stacks:
  - declarative-schema-only
  - static-site
failure_classes:
  - ticket-prefix-mistaken-for-environment
  - ownership-conflated-with-location
  - chronological-order-broken
  - environment-gated-script-unflagged
benchmark_tags:
  - discovery-database
  - cross-system-migration
  - shared-schema-ownership
---

# cross-system-migration-script-tracer

## Purpose
Inventory migration scripts by originating team (via ticket prefix),
reconstruct chronological apply order across teams, and flag shared-
schema contention.

## Inputs
- Repository `db/` directory with ticket-prefixed `.sql` files.
- Optional: sibling apps' `db/` directories to correlate.

## Outputs
- `migration-ownership-inventory.json` — per script: filename,
  ticket prefix, ticket ID, purpose, host repo, target schema,
  apply-order rank.
- `shared-schema-contention-findings.json` — per object:
  contending teams, contention count, latest change by team.

## Methodology
1. Glob `db/**/*.sql`; parse filenames for ticket prefixes.
2. Group by prefix = originating team.
3. Chronologically rank across prefixes.
4. Detect shared objects modified by multiple teams.

## Tech-Stack Dispatch

No external references.

## Gotchas
- Ticket prefix != environment gate (see
  `environment-guarded-sql-detector`).
- `DHS_*.sql` is both (DHS cross-agency + often `_EpoweOnly`).
- Cross-system prefixes in one repo's `db/` = shared schema
  co-ownership, not a bug.
- Order matters: apply out of order and constraints break.

## Quality Rules
- [ ] Every migration has ticket_prefix + ticket_id.
- [ ] Cross-team co-ownership surfaced.
- [ ] Apply-order rank assigned globally.
- [ ] Every record cites `{repo}:{file}:{line}`.

## Common Failure Modes

| Failure Mode | Symptom | Prevention |
|---|---|---|
| Prefix mistaken for env | DHS_* treated as prod-only | Cross-check with environment-guarded-sql-detector |
| Apply order wrong | Within-team ordering only | Rank by timestamp / ticket ID globally |

## Handoff Summary
Migration ownership cataloged. Proceed to
`oracle-extraction-patterns` / `sqlserver-extraction-patterns`.

## References
None.

## Changelog
- 0.1.0 (2026-05-07) — Initial skill. Authored as ATLAS-R-19.
