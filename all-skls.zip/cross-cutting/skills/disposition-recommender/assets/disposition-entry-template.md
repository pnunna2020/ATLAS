# Disposition Entry — `{application_id}`

> Per-app disposition record. Populate every section. Unsupported fields fail the G-DA gate.

## Identity
- **application_id:** `<APP-ID>`
- **application_name:** `<human-readable name>`
- **wave:** `<W1 | W2 | ...>`
- **generated_at:** `<ISO-8601 timestamp>`
- **skill_version:** `disposition-recommender@<version>`

## Recommendation
- **recommended_disposition:** `<Retire | Retain | Refactor | Rearchitect | Replace | Replatform | Consolidate>`
- **confidence_score:** `<0.00 - 1.00>` (derived from weighted evidence dimensions; see `portfolio-scorer`)
- **primary_rationale:**
  > One paragraph (3-5 sentences). Plain-English "why this disposition". Must reference at least one citation from the evidence package below.

## Evidence Package
Citations use `{artifact}:{section}:{finding-id}` format. See `references/evidence-package-composition.md` for required citations per disposition.

| Dimension | Citation | Value / Finding |
|-----------|----------|-----------------|
| Business Value | `{portfolio-scorecard.json}:business_value:<app-id>` | `<score>` |
| Technical Debt / Readiness | `{portfolio-scorecard.json}:technical_debt:<app-id>` | `<score>` |
| Redundancy | `{redundancy-matrix.json}:overlap:<app-id>` | `<score + partners>` |
| User Impact | `{user-impact-analysis.json}:<section>:<app-id>` | `<affected users, journeys>` |
| TCO (current) | `{tco-analysis.json}:baseline:<app-id>` | `<$>` |
| TCO (target) | `{tco-analysis.json}:<disposition>:<app-id>` | `<$>` |
| Disposition-specific | `<see references/evidence-package-composition.md>` | `<...>` |

### Rearchitect/Refactor only — 60%-threshold math
- `refactor_cost_estimate:` `<$>`
- `rearchitect_cost_estimate:` `<$>`
- `ratio = refactor / rearch =` `<0.XX>`
- `threshold = 0.60`
- `decision:` `<Refactor | Rearchitect>`

## Cost Projection

| Option | 1-Year Cost | 5-Year TCO | Notes |
|--------|-------------|------------|-------|
| **Recommended: `<disposition>`** | `<$>` | `<$>` | `<source citation>` |
| Alternative 1: `<disposition>` | `<$>` | `<$>` | `<source citation>` |
| Alternative 2: `<disposition>` *(optional)* | `<$>` | `<$>` | `<source citation>` |

## Alternatives Considered & Rejected
Minimum 2 alternatives. Each rejection cites evidence.

1. **`<disposition>`** — Rejected because `<rationale>`. Citation: `{artifact}:{section}:{finding-id}`.
2. **`<disposition>`** — Rejected because `<rationale>`. Citation: `{artifact}:{section}:{finding-id}`.

## User Migration Path
*Mandatory for Retire and Replace. Required for Consolidate (redundant apps). Optional otherwise — use "N/A" only when disposition is Retain/Refactor/Rearchitect/Replatform.*

- **successor_system:** `<name or N/A>`
- **affected_personas:** `<list>`
- **migration_mechanism:** `<data migration / retraining / UI cutover / ...>`
- **citation:** `{user-impact-analysis.json}:migration_target:<app-id>`

## Downstream Routing
See `references/downstream-routing-rules.md`. Computed from `recommended_disposition` — do not hand-edit.

```json
"downstream_routing": [
  {"app_id": "<APP-ID>", "disposition": "<disposition>", "route": "<Modernization | Disposition Execution>", "path": "<path string>"}
]
```

For **Consolidate**, emit two records (target → Modernization, redundant → Disposition Execution).
