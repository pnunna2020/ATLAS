# Downstream-Line Routing Rules

Deterministic routing of approved dispositions to downstream lines. Source of truth: `assembly-lines/rationalization/README.md` Step 6. Encode in the disposition entry's `downstream_routing` field.

## Routing table

| Disposition | Route | Path |
|-------------|-------|------|
| Refactor | Modernization | Architecture → Data → Modernization → Validation → Deployment |
| Rearchitect | Modernization | Architecture → Data → Modernization → Validation → Deployment |
| Retire | Disposition Execution | Disposition Execution → Deployment (decommission) |
| Retain | Disposition Execution | Disposition Execution (lightweight, Sustainment) |
| Replace | Disposition Execution | Disposition Execution → Deployment (cutover) |
| Replatform | Disposition Execution | Disposition Execution → Deployment (platform migration) |
| Consolidate | **Both** | Target → Modernization; redundant → Disposition Execution (Retire) |

## Rules

1. One disposition → one route, except Consolidate which emits two records.
2. Consolidate dual routing is mandatory — target → Modernization and redundant → Disposition Execution. Single-entry is invalid.
3. No free-form routes. `route` ∈ {`Modernization`, `Disposition Execution`}. `path` is the table expansion.
4. Route is computed from disposition. Mismatch fails `validate-disposition`.

## Emission format

```json
"downstream_routing": [
  {"app_id": "APP-123", "disposition": "Rearchitect", "route": "Modernization",
   "path": "Architecture → Data → Modernization → Validation → Deployment"}
]
```

Consolidate emits two records: target → Modernization, redundant → Disposition Execution (decommission path).
