# Evidence Package Composition

Every recommendation carries an evidence package. Citations use `{artifact}:{section}:{finding-id}`. Minimum citations depend on disposition.

## Retire
- Usage metric — `{discovery-catalog.json}:usage:metric-id` low/zero activity
- Business value — `{portfolio-scorecard.json}:business_value:app-id`
- Migration path — `{user-impact-analysis.json}:migration_target:app-id` naming successor
- Stakeholder confirmation — `{stakeholder-register.json}:confirmation:app-id`

## Retain
- Clean quality — `{portfolio-scorecard.json}:technical_debt:app-id` >= 75
- Unique value — `{redundancy-matrix.json}:overlap:app-id` no high-overlap partners
- Business value >= 40 (same scorecard section)

## Refactor
- Technical-debt score — `{portfolio-scorecard.json}:technical_debt:app-id`
- 60%-threshold math — `{tco-analysis.json}:refactor_vs_rearch_ratio:app-id` <= 0.6 (see `rearchitect-vs-refactor-threshold.md`)
- Business value justifying preservation

## Rearchitect
- Technical-debt score
- 60%-threshold math (ratio > 0.6), OR architectural constraint — `{discovery-analysis.json}:pass1:finding-id` citing coupling/scalability block

## Replace
- Alternative system — `{tco-analysis.json}:alternative:system-name` with capability parity >= 0.8
- Readiness < 30
- Migration path — `{user-impact-analysis.json}:migration_target:app-id`

## Replatform
- Platform fit — `{discovery-analysis.json}:archetype:finding-id` matches low-code capability
- Readiness < 60
- TCO comparison — `{tco-analysis.json}:replatform:app-id`

## Consolidate
- Target in scope — `{portfolio-scorecard.json}:scope:target-app-id` same portfolio/wave
- Overlap — `{redundancy-matrix.json}:pair:source-target` >= 0.7
- Same user base — `{user-impact-analysis.json}:persona_overlap:pair`

## Universal
- Minimum 2 alternatives, each rejection cites evidence.
- Cost projection for recommended plus one alternative.
- Confidence derived from weighted dimensions, not assigned.
