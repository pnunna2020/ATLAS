# Seven-Disposition Decision Tree

Apply in order. First terminal match wins. Inputs from `portfolio-scorecard.json`, `redundancy-matrix.json`, `user-impact-analysis.json`, `tco-analysis.json`.

## Inputs
- `redundancy_score` (0-1) — redundancy matrix
- `readiness_score` (0-100) — scorecard technical-debt dimension
- `business_value` (0-100) — scorecard
- `tco_delta_pct` — (current - target) / current
- `user_migration_feasible` (bool) — user-impact analysis
- `refactor_vs_rearch_ratio` — refactor_cost / rearchitect_cost

## Decision order

1. **Consolidate** — `redundancy_score >= 0.7` AND target in portfolio/wave AND same user base. Terminal.
2. **Retire** — `business_value < 20` OR inactive usage. Requires `user_migration_feasible == true` with named successor. If infeasible, fall through to Retain.
3. **Replace** — `readiness_score < 30` AND viable COTS/SaaS with capability parity >= 0.8. Cite alternative.
4. **Replatform** — Form-based/workflow/reporting archetype AND fits low-code capability map AND `readiness_score < 60`.
5. **Rearchitect** — `readiness_score < 50` OR coupling blocks scalability OR `refactor_vs_rearch_ratio > 0.6` (see `rearchitect-vs-refactor-threshold.md`).
6. **Refactor** — `readiness_score` 50-75 AND unique business value AND `refactor_vs_rearch_ratio <= 0.6`.
7. **Retain** — Default terminal. `readiness_score >= 75`, `business_value >= 40`, low debt, unique function, no redundancy.

## Tie-breakers
- Two dispositions fire → pick lower 5-year `tco_delta_pct`.
- Confidence < 0.6 → emit flagged recommendation for human review instead of silent guess.
