# Rearchitect vs. Refactor — 60% Cost Threshold

## The rule

If `refactor_cost_estimate > 0.6 * rearchitect_cost_estimate`, recommend **Rearchitect**.

Rationale: when refactor cost approaches rearch cost, the rearchitected system yields significantly better long-term maintainability, scalability, and velocity for a small incremental investment. Paying 90% of the rearch bill for 40% of the benefit is the anti-pattern.

## Cost-components checklist

Both estimates must include all of the following to be comparable:

- [ ] **Effort** — engineer-days per role (backend, frontend, QA, DevOps, data)
- [ ] **Duration** — calendar weeks, accounting for parallelism and dependencies
- [ ] **Integration risk** — upstream/downstream changes, contract-breakage cost, rollback complexity
- [ ] **Testing burden** — regression build-out, parallel-run cost, UAT cycles
- [ ] **Data migration** — schema changes, backfills, dual-write windows (rearch only)
- [ ] **Future maintainability** — 3-year maintenance delta (report in TCO, not refactor/rearch line)
- [ ] **Risk contingency** — Tier-1 +15%, Tier-2 +10%, Tier-3 +5%

## Producing defensible estimates

1. Source effort from Discovery Pass 1 (LOC, modules, complexity) × archetype productivity rates from `tco-analyzer` calibration.
2. Refactor assumes same architecture; effort scales with technical-debt score.
3. Rearchitect assumes target architecture from Architecture line candidate patterns; effort scales with bounded-context count.
4. Cite each number: `{tco-analysis.json}:refactor_estimate:components` and `{tco-analysis.json}:rearchitect_estimate:components`.
5. Show the ratio calculation explicitly: `ratio = refactor / rearch = X.XX`.

## Reporting

Include ratio, threshold (0.6), and decision in the disposition entry. Example:
`ratio = 0.68 > 0.60 → Rearchitect`.

Human reviewers must reproduce the number from cited components alone.
