---
name: disposition-recommender
description: >
  Synthesize Discovery findings and portfolio analysis into evidence-traced disposition
  recommendations for each application (one of 7 dispositions). Used during Rationalization
  Step 3. Triggers on disposition recommendation, portfolio disposition, or scoring synthesis.
agent: opus
allowed-tools:
  - Read
  - Write
  - Grep
---

# Disposition Recommender

## Purpose
Recommend a disposition (Retire, Retain, Refactor, Rearchitect, Replace, Replatform,
Consolidate) for each application based on quantitative scoring, portfolio context,
and evidence-traced justification.

This skill **synthesizes** upstream evidence into a recommendation; it does **not**
compute weighted scores itself. Scoring is owned by `portfolio-scorer`, user-impact
quantification by `assess-user-impact`, and post-recommendation validation by
`validate-disposition`.

## Inputs
- Application catalog entry (from Discovery)
- `portfolio-scorecard.json` — weighted scores across all dimensions (from `portfolio-scorer`)
- `redundancy-matrix.json` — overlap scores with other apps (from `redundancy-analyzer`)
- `user-impact-analysis.json` — affected users, journeys, migration feasibility (from `assess-user-impact`)
- `tco-analysis.json` — per-disposition cost projections (from `tco-analyzer`)
- 4-pass analysis report (from Discovery, for finding-level citations)

## Outputs
- Per-app disposition recommendation with confidence score
- Evidence package citing specific findings ({artifact}:{section}:{finding-id})
- Alternative dispositions considered with reasoning for rejection
- Cost projection per disposition option

## Methodology
1. **Load pre-computed scores.** Read `portfolio-scorecard.json` — do not recompute weighted scores here. Scoring is delegated to `portfolio-scorer`.
2. Check `redundancy-matrix.json` — consolidation candidates first (see `references/seven-disposition-decision-tree.md`).
3. Apply the seven-disposition decision tree against the loaded scores, redundancy, user-migration feasibility, and TCO delta. First terminal match wins.
4. For Refactor vs. Rearchitect, apply the 60% cost threshold (`references/rearchitect-vs-refactor-threshold.md`) and record the ratio math in the evidence package.
5. Compose the evidence package per disposition type using `references/evidence-package-composition.md` (mandatory citations vary by disposition).
6. Compare TCO across feasible options from `tco-analysis.json`; include the recommended disposition and at least one alternative.
7. Compute downstream routing deterministically from the disposition per `references/downstream-routing-rules.md` (Consolidate emits two routing records).
8. Document alternatives considered and why each was rejected; emit per-app record using `assets/disposition-entry-template.md`.

## Gotchas
- **Every recommendation must cite evidence**: Unsupported recommendations
  fail the G-DA gate. No hand-waving — link to specific findings.
- **Consolidate requires both apps in scope**: Don't recommend Consolidate
  if the target app isn't in the current portfolio or wave.
- **Retire requires a user migration path**: "Where do the users go?" must
  be answered before recommending Retire.
- **Rearchitect vs. Refactor is a cost decision**: If refactoring costs >60%
  of rearchitecting, recommend Rearchitect. The modernized version will be
  more maintainable long-term.

## Quality Rules
- [ ] Every disposition recommendation cites specific evidence using `{artifact}:{section}:{finding-id}` format
- [ ] Alternative dispositions considered are documented with reasoning for rejection — minimum 2 alternatives per app
- [ ] Confidence score is calculated from weighted evidence dimensions, not arbitrarily assigned
- [ ] Consolidate recommendations verify that the target app is in scope for the current portfolio or wave
- [ ] Retire recommendations include a user migration path — "where do the users go?" is answered
- [ ] Cost projections are provided for the recommended disposition AND at least one alternative
- [ ] Redundancy matrix scores are checked before individual app disposition — consolidation candidates are identified first
- [ ] Rearchitect vs. Refactor boundary is evaluated against the 60% cost threshold
- [ ] All inputs (4-pass analysis, readiness scores, redundancy matrix, TCO baseline) are present before recommendation
- [ ] Scoring is delegated to `portfolio-scorer` — this skill does not compute weighted scores; it reads `portfolio-scorecard.json`
- [ ] Evidence package uses the composition rules from `references/evidence-package-composition.md` (mandatory citations per disposition type)
- [ ] Rearchitect-vs-Refactor decisions cite the 60%-threshold calculation from `references/rearchitect-vs-refactor-threshold.md`, with the ratio shown explicitly
- [ ] Downstream-line routing matches `references/downstream-routing-rules.md` per disposition (Consolidate emits two routing records)

## Common Failure Modes
| Failure Mode | Symptom | Prevention |
|-------------|---------|------------|
| Unsupported recommendation | Disposition recommendation has no evidence citations; G-DA gate rejects it | Require `{artifact}:{section}:{finding-id}` citations for every recommendation before submission |
| Consolidate without target in scope | App recommended for consolidation but the target app is in a different wave or out of scope | Check portfolio scope and wave membership for both source and target before recommending Consolidate |
| Retire without migration path | App recommended for retirement but active users have no alternative; stakeholders block it | Require explicit user migration plan as a mandatory field in Retire recommendations |
| Missing cost comparison | Single disposition recommended without cost comparison to alternatives; stakeholders cannot evaluate trade-offs | Require cost projections for recommended disposition plus at least one alternative |
| Redundancy overlooked | Two apps with 80% functional overlap both recommended for Rearchitect instead of Consolidate | Run redundancy matrix check first; flag high-overlap pairs before individual disposition analysis |

## Handoff Summary
When this skill completes, verify:
1. Every recommendation has evidence citations in `{artifact}:{section}:{finding-id}` format
2. Alternative dispositions are documented with rejection reasoning
3. Cost projections cover the recommended disposition and at least one alternative
4. Consolidation candidates from the redundancy matrix are addressed
Then proceed to: gate `G-DA` for disposition approval, then the appropriate assembly line for the approved disposition (Modernization, Disposition Execution, or Sustainment)
