---
name: demo-runbook-generator
description: >
  Generate the 75-minute oral presentation script for FAA ATLAS Phase 3 SF1:
  intro 2m, factory 10m, demo journeys D1-D5 38m, cATO 10m, execution
  readiness 8m, fallback 7m, plus the 15-minute Q&A prep block. Output
  includes per-segment talking points, screen-share targets, expected-state
  checkpoints, "if this breaks" recovery paths, presenter assignments, and
  Q&A rehearsal pack. Use during Phase 3 build day 9. Triggers on demo
  runbook, oral presentation script, 75-min runbook, screen-share script,
  Q&A prep, or Phase 3 oral mentions.
agent: sonnet
enrichment_level: Partial
tags:
  - demo-runbook
  - factory-ops
  - evidence-generation
allowed-tools:
  - Read
  - Write
---

# Demo Runbook Generator

## Purpose
Produce the minute-by-minute oral presentation script for the Phase 3 SF1
oral. The oral is the highest-leverage 100 minutes of the entire FAA ATLAS
competition (announcement §6.1.1 weighting; phase 3 carries the most weight
in the Phase 4 best-value tradeoff). Every claim made in the oral must be
backed by code the FAA evaluator can independently verify (P3-R5.2 / EVAL).
This skill writes the script that keeps the oral honest.

The runbook is **not** a slide deck. Per P3-R108, slides are confined to
team intro, agenda, and high-level architecture. The vast majority of the
75 minutes is live screen-share of the running prototype, the pipeline UI,
the code repo, and the compliance evidence directory. This skill scripts
those live actions, second by second.

## When to use

Invoke this skill on Phase 3 build day 9 (per `docs/phase3/build-demo-skills-plan.md`
§6), **after** the five demo journeys (D1–D5) are green on the team's
laptops, the CI pipeline has at least one full successful run with OSCAL
emit, and the cATO Grafana panel shows live telemetry. Re-invoke whenever:

- A journey breaks during dress rehearsal and the screen-share script must
  swap to the fallback MP4.
- A FAA mid-build directive (P3-R5.1) lands and a new segment must be
  inserted (typically replacing slack time in the fallback budget).
- The presenter team changes — re-emit with new presenter assignments.

## Inputs

```yaml
demo_journeys:                       # the 5 stages from build-demo-skills-plan.md §2
  - id: D1
    j08_stage: 2
    title: "One-time identity enrollment, FTN bound for life"
    primary_role: applicant
    integrations: [S1, S8, RMS-adapter]
    time_budget_minutes: 6
    screen_share_targets:
      - { url: "http://localhost:3000/login", description: "Keycloak login screen, applicant tile" }
      - { url: "http://localhost:3000/dashboard", description: "Empty dashboard for new applicant" }
      - { url: "http://localhost:8001/swagger#/identity/post_proof", description: "S1 identity proofing endpoint" }
      - { url: "http://localhost:8002/swagger#/registry/post_ftn_resolve", description: "S8 FTN single-write endpoint" }
      - { url: "http://localhost:3000/dashboard?ftn=NEW", description: "Dashboard re-renders with FTN issued" }
    expected_state_checkpoints:
      - "Login completes within 8 seconds of credential submission"
      - "FTN appears on dashboard ActiveCaseCard within 3 seconds of S8 write"
      - "Network panel shows zero calls to mocked endpoints"
    if_this_breaks:
      - { trigger: "Keycloak login spinner > 15s", recovery: "Switch to fallback MP4 D1.mp4 at 0:00; narrate over." }
      - { trigger: "S8 returns 409 Conflict (duplicate FTN)", recovery: "Treat as feature: narrate the rejection of duplicate FTN as evidence of P3-R23a / Phase 2 §F.1 single-write authority." }
  - id: D2
    j08_stage: 3
    title: "Medical intake — prefilled, mobile-first, no re-entry"
    primary_role: applicant
    integrations: [S2, S6, S8]
    time_budget_minutes: 8
    # ... (D3, D4, D5 follow the same shape, see build-demo-skills-plan.md §2)
factory_model:
  source: assembly-lines/overview.md
  one_pager_path: docs/phase3/factory-model-one-pager.md
  named_lines: [Discovery, Rationalization, Architecture, Data, Modernization, Validation, Deployment]
cato_evidence:
  oscal_evidence_dir: evidence/oscal/
  control_families: [AC-2, AC-3, AC-4, IA-5, AU-2, AU-10, AU-12, SC-12, SC-28, SI-10]
  grafana_url: http://localhost:3001/d/cato-posture
  pipeline_run_summary: evidence/pipeline-run-summary.json
deviations:
  source: docs/phase3/skills-gap-matrix.md  # §5 deviation register
  count_to_acknowledge: 6                    # the six in build-demo-skills-plan.md §1.1
presenters:
  - { name: "TBD-1", role: "lead engineer", assigned_segments: [factory, D1, D2, cato, fallback] }
  - { name: "TBD-2", role: "frontend lead", assigned_segments: [intro, D3, D4] }
  - { name: "TBD-3", role: "backend / cATO lead", assigned_segments: [D5, execution_readiness, qa] }
  - { name: "TBD-4", role: "PM / capture lead (driving)", assigned_segments: [agenda, time_keeping] }
schedule:
  presentation_minutes: 75
  break_minutes: 10
  qa_minutes: 15
  total_minutes: 100
```

## Outputs

| Path | Purpose |
|------|---------|
| `runbook/runbook.md` | Master runbook in Markdown, minute-by-minute. |
| `runbook/runbook.docx` | Same content rendered to .docx for printout (uses the `docx` skill). |
| `runbook/timing.csv` | Per-segment start/end timestamps, presenter, screen-share target. |
| `runbook/screen-share-targets.md` | Per-URL state preconditions, manual pre-load steps, browser-tab order. |
| `runbook/fallback-stills.md` | Per-segment fallback MP4 file name, trigger condition, narration text. |
| `runbook/expected-state-checkpoints.md` | Boolean assertions per segment ("FTN visible on dashboard within 3s"). |
| `runbook/qa-pack.md` | 50 anticipated questions with 30s and 90s answers, artifact pull-up cues. |
| `runbook/presenter-assignments.md` | Per-presenter cue sheet — only their segments. |
| `runbook/dry-run-checklist.md` | Pre-flight checklist for each rehearsal and the live oral. |
| `runbook/recovery-decision-tree.md` | "If X breaks, switch to Y" decision tree; printed and laminated for the live oral. |

## Procedure

1. **Compute the time budget.** Verify total = 75 minutes ± 0.
   Default segment allocation:

   | # | Segment | Duration | Presenter |
   |---|---|---|---|
   | 1 | Intro / team / agenda | 2 min | PM |
   | 2 | Factory model + automation-first narrative | 10 min | lead engineer |
   | 3 | Demo journey D1 (J08 §2 — identity) | 6 min | lead engineer |
   | 4 | Demo journey D2 (J08 §3 — medical intake prefill) | 8 min | lead engineer |
   | 5 | Demo journey D3 (J08 §5 — AME exam, role transition) | 9 min | frontend lead |
   | 6 | Demo journey D4 (J08 §9 — CFI endorsement, signing) | 7 min | frontend lead |
   | 7 | Demo journey D5 (J08 §12 — issuance, full event chain) | 8 min | backend / cATO lead |
   | 8 | cATO + DevSecOps pipeline walkthrough | 10 min | lead engineer |
   | 9 | Execution readiness + risks + transition to prod | 8 min | backend / cATO lead |
   | 10 | Deviations / fallback / closing | 7 min | lead engineer |
   | **Total** | | **75 min** | |

   If the input schedule does not sum to 75, fail loud and ask the
   orchestrator to adjust before generating. Do **not** silently re-allocate.

2. **Author segment 1 (Intro 2 min).**
   - 0:00–0:30 — team intro slide; name, role, what each person built. Per
     P3-R109, presenters are delivery personnel, not BD/exec. Make this
     evident: each presenter shows a snippet of code or IaC they personally
     wrote.
   - 0:30–1:00 — agenda slide: "Factory model → 5 live journeys → cATO
     evidence → execution readiness → Q&A."
   - 1:00–2:00 — high-level architecture slide (the 7-box diagram from
     build-demo-skills-plan.md §1.3); explicitly call out: "BASE-C and
     Bedrock are NOT in scope; Phase 3 is portable to either if FAA
     directs in Phase 4." This pre-empts a Q&A trap.

3. **Author segment 2 (Factory 10 min).**
   - 2:00–4:00 — open the factory model one-pager (PowerPoint slide #3 —
     the only diagram-heavy slide). Walk through the named lines: Discovery,
     Rationalization, Architecture, Data, Modernization, Validation,
     Deployment. Closes P3-R01.
   - 4:00–7:00 — pivot to the live GitHub repo. Show `assembly-lines/`
     directory; open one assembly line's `steps.md`. Show how a single
     skill (`extraction`) is invoked by the factory. Closes P3-R02
     (automation-first).
   - 7:00–10:00 — show a CI run from `.github/workflows/build.yml`. Click
     into a recent green run. Walk through the stages: build → SAST →
     SCA → container scan → IaC scan → policy gate → deploy → smoke
     → e2e → cATO emit. Mention each tool by name (Semgrep, Grype, Trivy,
     tfsec, Checkov, OPA Conftest, ZAP, compliance-trestle). Closes P3-R03,
     R04, R06, R08.
   - 10:00–12:00 — open `evidence/oscal/by-control/AC-3.json`; show that
     the OSCAL fragment references the actual deployed image digest.
     Closes P3-R13, R45, R94.

4. **Author segments 3–7 (Demo journeys D1–D5, 38 min total).**
   For each journey, write:
   - Opening narration (10–20 seconds): the J08 stage, the role, the
     headline outcome.
   - Screen-share sequence: ordered list of URLs, with tab name, viewport
     size (1920×1080), and zoom level (110% for readability). Pre-loaded
     test data ID (e.g., `applicant=A0000042`).
   - Live action script: every click and keystroke, in order, with a
     wall-clock timestamp anchored at segment start. Include reactions to
     expected outcomes ("now you'll see the FTN appear in the
     ActiveCaseCard within 3 seconds — there it is").
   - Expected-state checkpoints: 3–5 boolean assertions per journey
     (network panel shows direct-to-S8 call, no mocked endpoints; FTN
     length 8 chars; dashboard ProgressTimeline highlights stage 2;
     etc.). The presenter narrates these so the FAA evaluator's
     automated code analysis (P3-R5.2) has something to corroborate
     against.
   - Recovery path: 1–3 "if this breaks" rows. Each row has a trigger
     (specific symptom: spinner > 15s, 5xx response, blank screen) and
     a recovery action (switch to fallback MP4 at timestamp X,
     narrate over). Recovery paths must NOT involve trying to fix the
     break live.

   D1 (6 min) — identity enrollment, primary integration S1+S8+RMS adapter.
   D2 (8 min) — medical intake prefill, the headline duplicate-elimination
   evidence (P3-R23a, P3-R65). Side-by-side: legacy MedXPress 8500-8 entry
   vs Phase 3 prefilled. Show network panel: Phase 3 makes 0 calls to
   re-enter fields the applicant already provided.
   D3 (9 min) — AME exam, role transition (applicant → AME), PHI boundary.
   Show the OPA gateway rejecting an S5-side request that tries to read
   PHI fields. Closes P3-R20 (system interactions), P3-R31 (role-based info).
   D4 (7 min) — CFI endorsement, S9 PKI signing, RFC 3161 timestamp via
   freetsa.org. Show the signed PDF in `evidence/credentials/`.
   D5 (8 min) — DPE issuance, full event chain S5 → S8 → S9 → S3 → S11
   visible in Grafana. Closes P3-R23 (data flow between components).

5. **Author segment 8 (cATO 10 min).**
   - 40:00–42:00 — open `.github/workflows/cato-evidence.yml` in GitHub.
     Show the workflow_run trigger (on `deploy.yml` completion) — proves
     OSCAL artifacts always reference the actual running prototype.
   - 42:00–46:00 — open `evidence/oscal/` in the repo. Walk the directory:
     `by-control/AC-2.json`, `by-control/AC-3.json`, … through SI-10.
     Show one fragment open: point to the `prop` entries with the build
     SHA, the deployed image digest, the smoke-test run ID. Closes
     P3-R38, R41, R44, R45, R94.
   - 46:00–49:00 — open the Grafana cATO posture dashboard at
     `http://localhost:3001/d/cato-posture`. Show real-time control
     telemetry: AU-12 audit-log presence rate (target 100%), SI-4 anomaly
     rate (target 0 critical alarms), AC-3 unauthorized-access denials
     (expect non-zero — proves AuthZ is enforced). Closes P3-R39, R40.
   - 49:00–50:00 — ZAP DAST report walkthrough. Open
     `evidence/dast/zap-report-latest.html`. Show 0 critical, 0 high.
     Open Trivy SARIF in VS Code. Show 0 critical.

6. **Author segment 9 (Execution readiness 8 min).**
   - 50:00–53:00 — transition path. Open the 6-month pilot rollout
     sequence (a one-page Mermaid timeline). Name the gates: Wave 0 Tyrion
     ATT, Wave 1 Login.gov sandbox, Wave 2 first PKI-signed 8710 in
     production. Closes P3-R46, R49.
   - 53:00–55:00 — risk register. Open `runbook/qa-pack.md` (just the
     risk section). Walk 3 named risks: R1 IACRA cutover disruption
     (M·H, mitigation: feature flags + parallel reads), R5 conversational
     AI low-confidence (M·H, mitigation: D5 routes to human, never
     autonomous). Closes P3-R47.
   - 55:00–57:00 — operational continuity. Demo `cdk deploy` against
     a previous image-tag context value, showing IaC revert is a 90-second
     operation. Demo blue-green traffic shift via Traefik (10% → 50% →
     100% → on error revert to 0). Closes P3-R51, R52, R53.
   - 57:00–58:00 — enterprise reuse. Show `cross-cutting/skills/`
     directory tree — 110+ skills. Mention "Olympus pattern promoted to
     ATLAS portfolio in Wave 4 — same factory runs against ~200 apps
     and ~3,000 databases." Closes P3-R71, R73.

7. **Author segment 10 (Deviations / fallback / closing 7 min).**
   - 58:00–62:00 — explicit deviations walk. Open
     `docs/phase3/skills-gap-matrix.md` §5. Read the six deviations
     enumerated in build-demo-skills-plan.md §1.1 aloud:
     1. Local docker-compose vs AWS GovCloud (AWS CDK stack set under
        `infra/cdk/` is synth-green; running it requires AWS credentials
        and Tyrion authority).
     2. Local stack vs Tyrion / Horizon (Phase 4 promotion target).
     3. OpenSSL CA + freetsa.org RFC 3161 vs AWS Private CA (Phase 4
        production cutover).
     4. Keycloak vs live Login.gov (federation handshake documented;
        sandbox access gated).
     5. Postgres LISTEN/NOTIFY vs Step Functions / EventBridge (Phase 4
        AWS-native swap path in IaC scaffolding).
     6. **BASE-C and Bedrock are not committed.** "Phase 3 prototype
        does not depend on either; if FAA directs Phase 4 to use BASE-C,
        the container-native architecture ports cleanly. AI/ML is out of
        scope per Phase 2 SF3 §3.3."
     Closes P3-R67, R68, R69, R70.
   - 62:00–65:00 — Q&A prep block (closing remarks, hand-off to break).
     "We have built every demonstrated capability against Phase 2
     commitments. Where we deviated, we have named the deviation and
     the Phase 4 path. We are ready for your questions."

8. **Author the Q&A pack (`runbook/qa-pack.md`).** 50 anticipated
   questions across 7 categories:

   | Category | Question count | Examples |
   |---|---|---|
   | Scope | 7 | "Why didn't you implement Aircraft Registration?" → A1 explicitly out-of-scope. |
   | Security | 8 | "How does CLOA-as-policy-as-code prevent unauthorized DPE signoff?" → OPA bundle at gateway, demo. |
   | Data | 7 | "How is PHI isolated from the applicant dashboard?" → S6 exposes only `medical.cert-status`; demo via network panel. |
   | Scale | 6 | "How does Olympus run on ~200 apps?" → Skills are app-agnostic; per-app config; Wave 4 promotion. |
   | Deviations | 8 | "Why are you not using BASE-C?" → Not a Phase 2 commitment; container-native architecture is portable. |
   | Cost | 6 | "What is the per-app modernization cost?" → Defer to Factor 2 pricing schedule. |
   | Transition | 8 | "When can FAA users sign in via Login.gov?" → Wave 1 cutover; Phase 3 demonstrates Login.gov-compatible OIDC via Keycloak. |

   Each question gets:
   - 30-second answer (the pithy version, suitable for live Q&A pacing).
   - 90-second answer (the detailed version, used if pressed).
   - Pull-up artifact (e.g., "open evidence/oscal/by-control/AC-3.json").
   - Inconsistency-with-oral risk: a one-liner naming what would conflict
     with the runbook if answered carelessly.

   Cross-check: every Q&A answer must be consistent with the runbook
   segments AND the written narrative emitted by `phase-commitment-traceback`.
   If a contradiction is detected (the runbook claims X, the Q&A pack
   admits not-X), fail the build.

9. **Generate per-presenter cue sheets** (`runbook/presenter-assignments.md`).
   Filter the master runbook by presenter; emit one section per presenter
   with only their segments, in order. Each cue sheet has the segment
   header, the time budget, the screen-share preconditions, the talking
   points, and the recovery paths. Print one per presenter; laminate per
   build plan §6 Day 12.

10. **Generate the dry-run checklist** (`runbook/dry-run-checklist.md`).
    Pre-flight items, in order:
    - Zoom.gov session started 30 min ahead (P3-R105).
    - All three browser tabs preloaded with seeded test data.
    - Grafana dashboard at `http://localhost:3001/d/cato-posture` showing
      live data (last refresh < 60s).
    - GitHub repo open at the latest commit on `main`.
    - Fallback MP4s present in `~/Demos/fallback/`.
    - Camera and mic check (per presenter).
    - Stopwatch app open and visible to the PM (time-keeper).
    - Phone on Do Not Disturb.
    - Internet primary + tether ready as backup.
    - Local prototype health: `curl localhost:8000/health` returns 200
      for every service.

11. **Generate the recovery decision tree** (`runbook/recovery-decision-tree.md`).
    Print this on a single laminated page. Tree structure:
    - "Live demo not loading?" → "Check `localhost:8000/health` in
      30s." → "Still failing?" → "Switch to fallback MP4 of the journey
      currently in progress; narrate over."
    - "Pipeline run page 404?" → "Open the cached run URL bookmarked
      in browser tab #5."
    - "Grafana shows no data?" → "Open `evidence/cato-runtime-snapshot.png`
      bookmarked in browser tab #6; narrate."
    - "Total panic?" → "Hand to PM; PM transitions to deviations segment
      early; engineer goes off-camera to recover."

## Validation / acceptance criteria

- [ ] Total minutes in `timing.csv` sum to 75 ± 0. Buffer for breath / Q&A
      transitions is built into segment durations, not added on top.
- [ ] Every demo journey segment has at least 3 expected-state checkpoints
      and at least 1 recovery path.
- [ ] Every screen-share target URL is reachable from the team laptop
      offline (i.e., the prototype runs in docker-compose with no internet
      dependency for the demo path; freetsa.org for RFC 3161 is the
      single exception, and it has a fallback).
- [ ] No segment depends on a slide deck for substance — slides only for
      intro / agenda / architecture diagram (P3-R108).
- [ ] Every presenter is named and assigned to ≥ 1 segment; total
      presenter coverage = 75 minutes; PM owns time-keeping (not a
      content segment).
- [ ] Q&A pack has ≥ 50 questions, ≥ 6 per category, with both 30s and
      90s answers and pull-up artifacts.
- [ ] Cross-consistency check passes: every claim in the runbook appears
      in the written narrative (`phase-commitment-traceback` output) AND
      in the source code / IaC / pipeline evidence (no claims floating).
- [ ] All 6 deviations from build-demo-skills-plan.md §1.1 are explicitly
      named in segment 10 — silent deviations fail the run.
- [ ] BASE-C and Bedrock appear ONLY in segment 10 deviations, framed as
      not-Phase-2-commitments. They do not appear in any demo journey, in
      any architecture description, or in any pull-up artifact.
- [ ] Recovery paths cover every demo journey AND the cATO segment AND
      the pipeline walkthrough — no segment is recovery-orphaned.
- [ ] Per-presenter cue sheet word count ≤ 1,500 words per presenter
      (humans can't read more in real-time).

## Examples

### Example 1: D2 (medical intake prefill) screen-share script

```
Segment 4 — Demo journey D2 — J08 Stage 3, medical intake, prefilled
Time: 8 minutes (12:00 → 20:00 of presentation)
Presenter: lead engineer
Pre-state: applicant A0000042 logged in, S2 Guided Intake at /applications/new

12:00 (segment open)
"This is the headline workflow consolidation evidence. We're showing the
applicant filling out Form 8500-8. The legacy MedXPress flow re-keys 17
fields the airman has already provided to IACRA. Watch what happens here."

12:30
[Click] /applications/new/medical
[Expected] Form 8500-8 page renders with:
  - Name field prefilled (from S8 airman.identity)
  - DOB prefilled
  - Address prefilled (with the address-withheld redaction icon visible
    next to it, per P2 §B.4 §44703(c))
  - 14 other fields prefilled
  - 3 fields blank (medical-history Yes/No, current medications, vision
    correction status — these are net-new for the medical record)

13:00
"17 fields prefilled. The applicant types nothing they've typed before.
Open the network panel."

13:30
[Open browser DevTools, network tab]
[Expected] 1 GET /api/v1/airman/A0000042 (S8) returning 17 fields.
0 calls to /api/v1/medical/import or any "import-from-IACRA" pattern.

14:00
"This isn't a UI trick. It's a single-write architecture. The FTN is
authoritative in S8. When S2 needs the applicant's name, S2 reads from
the canonical record. The applicant entered their name once, when they
created their identity in journey D1."

14:30
[Open second browser tab to legacy-equivalent screenshot]
[Show side-by-side: Phase 3 prefilled vs MedXPress empty fields]
"This is what we're replacing. Same form. 17 re-entries gone. Phase 2
§F.1 commits to duplicate-FTN-rate of zero. We achieve that here."

[15:00–18:00 — applicant fills the 3 net-new fields, submits.]

18:00
"Submit. Watch the dashboard."

18:15
[Switch to /dashboard]
[Expected] ProgressTimeline marks Stage 3 → complete. ActiveCaseCard
primary CTA changes to "Schedule AME exam." This happened via SSE; we
didn't refresh the page. Latency: less than 3 seconds.

19:00
"Two architecture stories in 8 minutes. One: enter once, reuse downstream.
Two: real-time status from event-driven propagation, not polling. We'll
show that propagation chain in detail in journey D5."

20:00 (segment close, hand to D3)

CHECKPOINTS:
- [ ] 17 fields prefilled, visibly populated.
- [ ] Network panel shows 1 GET to S8, 0 import-style calls.
- [ ] Dashboard ProgressTimeline updates within 3 seconds of submit.
- [ ] Address-withheld icon visible next to address field.

IF THIS BREAKS:
- Trigger: Form fails to render → switch to fallback MP4 D2.mp4 at 0:00,
  narrate over.
- Trigger: SSE doesn't update dashboard within 3s → manually refresh
  /dashboard, narrate "in production this would be SSE-driven; we're
  showing the same end state via refresh." Pull up evidence/sse-trace.png
  to show a captured event flow.
- Trigger: 17 fields are blank (S8 didn't seed) → switch to applicant
  A0000043 (pre-seeded backup), restart segment from 12:30.
```

### Example 2: Q&A pack entry — a tough deviations question

```
Q: "You used Keycloak instead of Login.gov. How is this Phase 2 compliant?"

30-second answer:
"Phase 3 demonstrates the OIDC integration shape — Keycloak speaks the
same protocol Login.gov speaks. Phase 2 §C.2 commits Login.gov sandbox
access as a Wave 0 exit gate; we don't have that access yet, so we
demonstrated the federation handshake against an OIDC provider we
control. Flipping the IdP URL when Login.gov sandbox is approved is a
config change, not a code change."

90-second answer (if pressed):
"Login.gov is the production identity provider for applicants per Phase 2
§B.3 row 'Identity — applicants.' We commit to Login.gov in production.
We can't demonstrate live Login.gov in a 75-minute oral because Login.gov
sandbox access is gated on FAA Authority-to-Test (Phase 2 Table 12 A1) —
that ATT is a Wave 0 closing event we're requesting, not something we
can self-provision in 12 days. So we used Keycloak as an OIDC broker
configured to speak Login.gov-compatible OIDC. The redirect URLs, the
JWT claim shape, the scopes — all match what Login.gov sandbox returns.
Our React frontend doesn't know it's not talking to Login.gov; the
backend doesn't know either; only the realm config in Keycloak knows.
Day-one of Wave 0, when ATT is granted, the only change is the OIDC
issuer URL in our environment config."

Pull-up artifact:
- iac/keycloak/realm-export.json (showing the realm is Login.gov-compatible)
- docs/phase3/skills-gap-matrix.md §5 DEV-10

Inconsistency-with-oral risk:
- DON'T claim the federation is live — it isn't.
- DON'T claim Login.gov sandbox is approved — it isn't.
- DO claim the protocol shape and the migration path are real.
```

## Gotchas

- **The runbook is for the presenter's eyes, not the FAA evaluator's.** It
  is not a deliverable in the SF2 submission; it is an internal artifact.
  Keep it operational, terse, and honest. Save polished prose for the
  10-page narrative.
- **Time budget is the budget.** If a segment runs long, the next one must
  run shorter. The PM is the time-keeper. Drift > 60 seconds at the end of
  any segment requires a recovery decision (drop a sub-segment, not the
  whole segment).
- **No live coding.** Every screen-share is reading from pre-seeded state;
  no `cdk deploy` runs against an unseen account; no `git commit`
  during the demo. The pipeline runs the team trusts are the cached green
  ones from the morning of, opened from a bookmarked URL.
- **Recovery paths assume the worst.** Every "if this breaks" path
  terminates in either (a) a fallback MP4 with narration, or (b) skipping
  the sub-segment with a one-sentence explanation. Recovery paths NEVER
  involve "let me try something" live — that path consumes minutes the
  budget doesn't have.
- **Q&A pack must be internally consistent.** A common failure mode: the
  oral runbook claims Login.gov is "demonstrated" while the Q&A pack
  admits it isn't. The cross-consistency check exists for this reason.
  Run it before every dry run.
- **Presenter assignments are sticky.** Once segment-to-presenter mapping
  is locked at end of Day 11, do not re-shuffle. Re-shuffling forces every
  presenter to re-rehearse new segments and the oral fails on delivery
  smoothness, not content.
- **PowerPoint is at most 3 slides.** Per P3-R108. Slide 1: team intro.
  Slide 2: agenda. Slide 3: 7-box architecture. Anything else lives in
  the live prototype, the IDE, the GitHub repo UI, the Grafana dashboard,
  or the OSCAL evidence directory.
- **Deviations are named, not buried.** Segment 10 is mandatory. Skipping
  it because "we ran long on D5" trades a 7-minute gain for a 50-point
  Q&A risk; FAA WILL ask about deviations and finding them via Q&A is
  far worse than naming them on Booz Allen's schedule.

## References

- Closes Phase 3 requirements: P3-R104 (75/10/15 min total), P3-R106
  (live screen-share of working app), P3-R107 (live screen-share of
  digital artifacts: arch diagrams, pipeline UI, code repos, security
  outputs, compliance evidence — every named category covered),
  P3-R108 (PowerPoint minimized), P3-R109 (delivery personnel present).
- Mitigates P3-R5.2 (oral-vs-code consistency check via Q&A cross-check),
  P3-R5.4 (Phase 3 weighting risk).
- Phase 2 grounding:
  - §B.5 — cATO automation, control families.
  - §C.4 — risks R1–R5 referenced in segment 9.
  - §F.1 — duplicate-elimination headline (D2).
  - §H.7 — BASE-C/Bedrock not committed (segment 10).
  - §D — 22-stage J08 (D1–D5 source).
- Build plan: `docs/phase3/build-demo-skills-plan.md` §2 (5 demo
  journeys); §6 Day 9 (this skill drops in); §6 Day 11 dry run.
- Gap matrix: `docs/phase3/skills-gap-matrix.md` §4 NEW-3.
- Adjacent skills:
  - `phase-commitment-traceback` — written narrative; cross-consistency
    target.
  - `pilot-certification-dashboard-spec` — defines the dashboard the
    runbook screen-shares.
  - `devsecops-pipeline-generator` — emits the workflows the runbook
    walks through.
  - `frontend-parity-test-generator` — Playwright specs that pre-record
    fallback MP4s.
  - `submission-package-builder` — the runbook is NOT in the submission;
    this skill ensures it is excluded.

## Anti-patterns

- **Do not** write narration that reads as marketing copy. "Industry-leading"
  / "transformative" / "cutting-edge" all degrade evaluator trust. Be
  specific: "17 fields prefilled" beats "seamless data integration."
- **Do not** include screen-share segments that depend on internet beyond
  freetsa.org (RFC 3161). FAA HQ network can be unreliable; the demo
  laptop runs everything in docker-compose locally.
- **Do not** plan to fix a broken state live. Recovery is fallback MP4 +
  narration, full stop.
- **Do not** mention BASE-C or Bedrock outside segment 10. Not in the
  intro, not in the cATO walkthrough, not in the architecture description.
  Mentioning either implies a Phase 2 commitment that doesn't exist.
- **Do not** allocate slack time at the end of segments. Slack at the
  end of segment N is dead time; absorb it into the segment with a
  longer narration or move it explicitly to segment 10's fallback budget.
- **Do not** under-budget the cATO segment. 10 minutes for cATO+pipeline
  is the floor — under-running cATO loses P3-R37/R38/R44 evidence and
  hands the FAA evaluator the easiest "Some confidence" downgrade in the
  rubric.
