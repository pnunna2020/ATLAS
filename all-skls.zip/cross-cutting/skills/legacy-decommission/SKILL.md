---
name: legacy-decommission
description: >
  Execute legacy system decommission workflow after successful parallel run: DNS cutover, infrastructure teardown, ATO retirement, license reclamation. Use during P6.3. Triggers on decommission, legacy teardown, ATO retirement, @execute-legacy-decommission, or @certify-cost-savings.
agent: sonnet
allowed-tools:
  - Read
  - Write
  - Bash
---

# Legacy System Decommission
## Purpose
Formal process for shutting down a legacy system after modernization is
validated. This is irreversible — the Decommission Gate must clear first.

## Pre-Decommission Checklist
- [ ] Decommission Gate cleared (parity sustained, adoption met, rollback expired)
- [ ] All data archived per NARA retention requirements
- [ ] All external consumers notified and migrated
- [ ] ATO decommission documentation prepared
- [ ] License inventory updated for reclamation
- [ ] Cost savings calculated for certification

## Workflow
1. Verify Decommission Gate status
2. Archive legacy data (DB dumps, file archives, document stores)
3. Update DNS/routes to remove legacy endpoints
4. Tear down infrastructure (VMs, databases, storage)
5. Retire ATO — submit decommission cert to FAA ISSM
6. Reclaim licenses (Oracle, etc.) and update license inventory
7. Generate cost savings certification (compose with tco-analyzer skill)

## Gotchas
- **Data archival must preserve reconstructability**: For the 12-month
  retention period, you must be able to reconstruct the legacy system from
  archives if needed. This means: container images, IaC snapshots, data dumps,
  AND documentation.
- **External consumer notification is legally required**: Airlines and other
  agencies must receive 90-day notice before API endpoints are removed.
- **ATO retirement is a formal security process**: You can't just delete
  servers — the ISSM must formally retire the ATO from the security portfolio.

## Quality Rules
- [ ] Decommission Gate is confirmed cleared before any decommission action begins
- [ ] Data archival preserves full reconstructability for the 12-month retention period (container images, IaC, data dumps, docs)
- [ ] External consumers received 90-day notice before API endpoint removal — legally required
- [ ] ATO decommission documentation is prepared and submitted to FAA ISSM for formal retirement
- [ ] License inventory is updated with reclaimed licenses (Oracle, etc.) and reclamation date
- [ ] Cost savings certification is generated composing with `tco-analyzer` skill

## Common Failure Modes
| Failure Mode | Symptom | Prevention |
|-------------|---------|------------|
| Data not reconstructable | Incident investigation needs legacy system but archives are incomplete; system cannot be rebuilt | Archive container images, IaC snapshots, data dumps, AND documentation — all four are required |
| External consumer not notified | Airline or agency integration breaks after endpoint removal; legal and operational consequences | Verify external consumer notification 90 days before decommission; track acknowledgments |
| ATO not formally retired | Security portfolio shows orphaned ATO; ISSO audit flags the gap | Submit ATO decommission cert to ISSM as part of the decommission workflow |
| Licenses not reclaimed | Oracle licenses still billed months after decommission; cost savings undermined | Update license inventory immediately; verify reclamation with procurement team |

## Handoff Summary
When this skill completes, verify:
1. All data is archived with full reconstructability verified
2. External consumers are confirmed migrated
3. ATO is formally retired with ISSM documentation
4. License reclamation is complete
5. Cost savings certification is generated
Then proceed to: `portfolio-health-check` to update portfolio status, and Governance reporting to log the completed decommission
