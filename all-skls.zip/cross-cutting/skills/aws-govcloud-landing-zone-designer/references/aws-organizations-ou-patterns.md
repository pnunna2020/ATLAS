# AWS Organizations OU Patterns for FAA GovCloud Landing Zone

Scope: multi-account isolation patterns, the SCP catalog (common denies
enforced via Service Control Policies), Control Tower guardrail selection
per FedRAMP tier, Transit Gateway topology options (flat hub-spoke vs
inspection VPC vs centralized egress), and DNS architectures (Route 53
Resolver endpoints, hybrid DNS, split-horizon) for the FAA GovCloud
landing zone that hosts the 8 FAA apps. Consumed by
`aws-govcloud-landing-zone-designer`.

## OU Tree Reference

The FAA landing zone uses a tier-aware OU tree. The root account is the
management account and hosts no workloads.

```
Root (Management Account)
├── Security
│   ├── log-archive
│   ├── audit
│   └── security-tooling
├── Workloads
│   ├── Production
│   │   ├── FedRAMP-High
│   │   │   ├── rms-prod
│   │   │   ├── iacra-prod
│   │   │   └── dms-prod
│   │   └── FedRAMP-Moderate
│   │       ├── amcs-prod
│   │       ├── medxpress-prod
│   │       ├── chaps-prod
│   │       ├── cpdss-prod
│   │       └── diws-prod
│   └── NonProduction
│       ├── FedRAMP-High
│       │   ├── rms-dev, rms-test, rms-staging
│       │   ├── iacra-dev, iacra-test, iacra-staging
│       │   └── dms-dev, dms-test, dms-staging
│       └── FedRAMP-Moderate
│           ├── (MSS apps × 3 environments each)
├── Shared-Services
│   ├── shared-identity
│   ├── shared-letter-generation
│   ├── shared-document-imaging
│   └── network-hub
├── Sandbox
│   └── (ephemeral accounts)
└── Suspended
    └── (decommissioning accounts awaiting deletion)
```

### OU Rules

- **Security** OU gets the strictest SCPs (log-archive immutability,
  deny delete on audit role, etc.). Moving an account out of Security
  requires an explicit change-management ticket.
- **Workloads** OU has `Production` and `NonProduction` children; both
  have tier sub-OUs. Production SCPs are stricter than NonProduction
  (e.g., production denies IAM user creation; non-prod allows with
  attached boundary policies).
- **Shared-Services** OU hosts cross-app services (identity, network-
  hub). It is neither prod nor non-prod; shared services deploy once
  and serve all environments.
- **Sandbox** OU is for throwaway exploration; accounts here have
  spending limits and automatic lifecycle (30-day or 60-day expiry).
- **Suspended** OU holds accounts that have been decommissioned from
  their app but have not yet been deleted (S3 buckets, EBS snapshots,
  etc. being preserved per retention policy).

## SCP Catalog

The following SCPs are common across FAA landing zones. Each entry
lists the purpose, the target OUs, and the deny actions.

### SCP-01 — Deny Leaving Organization

Applied at Root. Denies any action that would remove an account from
the Organization.

Deny actions: `organizations:LeaveOrganization`.

### SCP-02 — Deny Root Activity

Applied at Workloads, Shared-Services, Sandbox, Security. Denies
anything performed by the root principal (root credentials should
never be used for operational work).

Deny actions: all actions when `aws:PrincipalArn` matches the root
user ARN.

### SCP-03 — Deny CloudTrail Disabling

Applied at Root (inherited by all OUs). Denies disabling CloudTrail,
deleting trails, stopping logging, or modifying trail configuration.

Deny actions: `cloudtrail:StopLogging`, `cloudtrail:DeleteTrail`,
`cloudtrail:UpdateTrail` (on the org trail), `cloudtrail:PutEventSelectors`.

### SCP-04 — Deny Config Disabling

Applied at Root. Denies disabling AWS Config, deleting the delivery
channel or configuration recorder.

Deny actions: `config:StopConfigurationRecorder`,
`config:DeleteDeliveryChannel`, `config:DeleteConfigurationRecorder`,
`config:DeleteConfigRule` (on organization rules).

### SCP-05 — Deny GuardDuty Disabling

Applied at Root. Denies disabling GuardDuty detectors, disassociating
members.

Deny actions: `guardduty:DeleteDetector`, `guardduty:DisableOrganizationAdminAccount`,
`guardduty:DisassociateFromMasterAccount`.

### SCP-06 — Deny Log Archive Bucket Modification

Applied at Security OU. Denies modifying the log-archive bucket
policy, the bucket encryption, the object lock configuration, or
deleting objects / versions.

Deny actions: `s3:PutBucketPolicy`, `s3:PutEncryptionConfiguration`,
`s3:PutObjectLockConfiguration`, `s3:DeleteObject`,
`s3:DeleteObjectVersion`, `s3:DeleteBucket` — all scoped to the
log-archive bucket ARNs.

### SCP-07 — Enforce FIPS Endpoints (FedRAMP High Only)

Applied at Workloads/Production/FedRAMP-High and
Workloads/NonProduction/FedRAMP-High. Denies API calls to non-FIPS
service endpoints.

Deny logic: `Deny` when `aws:CalledVia` is a non-FIPS endpoint for a
given service. Implemented via condition on service endpoint
hostname pattern.

### SCP-08 — Deny Region Outside GovCloud

Applied at Root. Denies any action in a region other than
`us-gov-west-1` or `us-gov-east-1`.

Deny actions: all actions when `aws:RequestedRegion` is not in the
approved region list. Global services (IAM, Organizations, Route 53)
are exempt via action-based exception list.

### SCP-09 — Deny Marketplace Non-Approved

Applied at Workloads. Denies subscribing to AWS Marketplace products
not on the agency-approved list.

Deny actions: `aws-marketplace:Subscribe`, `aws-marketplace:AcceptAgreementApprovalRequest` —
with a condition allowlist of approved product IDs.

### SCP-10 — Deny Public S3 Block Public Access Disabling

Applied at Root. Denies disabling the account-level or bucket-level
S3 Block Public Access setting.

Deny actions: `s3:PutAccountPublicAccessBlock`,
`s3:PutBucketPublicAccessBlock` — deny when any of the four settings
would be set to `false`.

### SCP-11 — Deny IMDSv1 Launch

Applied at Workloads. Denies launching EC2 instances without IMDSv2
required.

Deny actions: `ec2:RunInstances` when `ec2:MetadataHttpTokens` is
not `required`.

### SCP-12 — Deny EC2 Key Pair Creation

Applied at Workloads. Denies creating or importing EC2 key pairs
(Session Manager is the only supported access mechanism).

Deny actions: `ec2:CreateKeyPair`, `ec2:ImportKeyPair`.

### SCP-13 — Deny Deletion of Organization Trail

Applied at Security OU. Supplements SCP-03 with specific denies on
the organization trail ARN.

### SCP-14 — Deny KMS Key Deletion Without Waiting Period

Applied at Workloads. Enforces minimum 30-day scheduled deletion
waiting period on KMS keys (FedRAMP High requires review of
cryptographic key decommissioning).

Deny actions: `kms:ScheduleKeyDeletion` when `kms:PendingWindowInDays`
is less than 30.

### SCP Precedence Notes

- SCPs are deny-wins across all levels. A child OU cannot allow what
  a parent OU denies.
- Allow statements in SCPs are not permissions grants; they are a
  filter. An IAM policy still must grant the action.
- Test combined effective policies with the IAM Policy Simulator in
  the target account before deploying.
- Emergency break-glass: a narrowly-scoped SCP exception applied at
  the account level (or a designated emergency role) is the only
  way to work around an organization-wide deny — document and
  time-bound the exception.

## Control Tower Guardrail Selection per FedRAMP Tier

Control Tower guardrails map onto SCPs + Config rules. Guardrails come
in three types:

- **Mandatory** — always on; cannot be disabled.
- **Strongly recommended** — enable by default; deviations require
  documented justification.
- **Elective** — enable based on posture need.

### Mandatory Guardrails (All Tiers)

- Disallow public write access to S3 buckets.
- Disallow deletion of log archive accounts.
- Disallow changes to CloudTrail configuration.
- Enable CloudTrail in all accounts.
- Disallow creation of access keys for root user.

### Strongly Recommended — Enable for Both Moderate and High

- Disallow public read access to S3 buckets.
- Enable encryption for EBS volumes attached to EC2 instances.
- Disallow Internet connection through RDP / SSH.
- Enable encryption for RDS database clusters.
- Disallow Lambda functions with public access.
- Enable MFA for root user.

### Elective — Enable for FedRAMP High

- Disallow public access to DynamoDB tables.
- Require encryption of S3 objects at rest.
- Require encryption for SQS queues.
- Disallow access by non-approved principal types.
- Disallow creation of VPC peering with non-organization accounts.

### Guardrails Missing in GovCloud (as of design time)

Some commercial Control Tower guardrails lag in GovCloud availability.
Track the gap and implement missing guardrails via direct SCP where
possible. Examples historically include certain AI / ML service denies,
some RDS-specific encryption guardrails, and newer preview guardrails
that land commercial-first. Verify availability at deployment time
against AWS's guardrail catalog.

## Transit Gateway Topology Options

### Option A — Flat Hub-Spoke (Not Recommended for Multi-Tier)

Single TGW with one route table; every attached VPC can reach every
other VPC. Simplest, cheapest, insufficient for tier isolation.

### Option B — Routing-Domain-Per-Suite (Recommended)

Single TGW with multiple route tables (routing domains). Each suite
attaches to its own route table; cross-suite routes are explicit and
require exception. High and Moderate tier traffic do not share a
routing domain.

Routing domains:
- `rms-domain` — RMS subsystem VPCs (CAIS, AADOCS, IMS, AR).
- `iacra-domain` — IACRA single VPC.
- `dms-domain` — DMS single VPC.
- `mss-domain` — MSS suite shared VPC (AMCS, MedXPress, CHAPS, CPDSS, DIWS).
- `shared-services-domain` — identity, letter-gen, doc-imaging.
- `egress-inspection-domain` — the egress VPC.
- `on-prem-domain` — Direct Connect attachments.

Default 0.0.0.0/0 in every workload routing domain → egress-inspection.
Shared-services reachable from every workload domain via explicit
route. On-prem reachable via explicit route per-suite.

### Option C — Multi-TGW (Strict Isolation)

Separate TGW per tier (one for FedRAMP High, one for FedRAMP
Moderate). More operational overhead; justify only when policy
requires strict infrastructure separation.

## Egress Inspection VPC Pattern

Single egress VPC in the network-hub account hosts:

- AWS Network Firewall (default for most deployments) or Palo Alto
  VM-Series (for FIPS 140-3 Level 3 egress filtering).
- NAT Gateway cluster (one per AZ).
- Internet Gateway (the only IGW in the landing zone).
- Route 53 Resolver outbound endpoint (for DNS queries leaving to
  on-prem).

All workload VPCs route `0.0.0.0/0` via TGW attachment to the egress
VPC's firewall endpoint, then to the NAT Gateway, then to the IGW.
Inbound public traffic does NOT route through the egress VPC — it
arrives via CloudFront + API Gateway or ALB in the workload account.

## DNS Architecture

### Route 53 Resolver Endpoints

- **Inbound endpoint** in the shared-services account: on-prem DNS
  servers forward queries for AWS-hosted zones (e.g., `*.cloud.faa.gov`)
  to this endpoint. Two ENIs minimum for HA across AZs.
- **Outbound endpoint** in the shared-services account: GovCloud
  workloads forward queries for on-prem zones (e.g., `*.faa.gov`
  internal) to agency DNS servers via this endpoint.
- **Resolver rules** in shared-services, shared via RAM to workload
  accounts. Rules specify forwarding targets per domain.

### Private Hosted Zones

- Per-app PHZs live in the workload account (e.g., `rms.internal.cloud.faa.gov`).
- Shared via RAM to dependent accounts only when cross-account
  resolution is needed.
- Split-horizon: same domain name resolves differently depending on
  where the query originates (on-prem clients see on-prem IPs; cloud
  clients see cloud IPs).

### Public DNS

Public-facing apps (IACRA, MedXPress) use delegated subdomains from
the agency public DNS (`iacra.faa.gov`, `medxpress.faa.gov`). Public
DNS zones live in the agency's commercial Route 53 (or equivalent) —
GovCloud Route 53 typically does not host public zones for FAA.

## Account Factory Pattern

Use Customizations for AWS Control Tower (CfCT) for repeatable
onboarding. The account factory template:

1. Creates the account in the target OU.
2. Applies the baseline SCP set (already at OU level; SCP check is
   a readback).
3. Applies the baseline IAM setup (SSO / Identity Center assignment,
   deny-root-activity confirmation).
4. Deploys VPC per the tier template (High vs Moderate CIDR sizing,
   subnets, TGW attachment, route table association).
5. Deploys Config, CloudTrail, GuardDuty enrollment, Security Hub
   enrollment, Inspector enrollment.
6. Deploys KMS keys per the tier template (CMK with rotation; High
   tier evaluates CloudHSM).
7. Registers the account with Audit Manager assessment scope.
8. Emits an onboarding report with evidence of each step.

Do not click-ops any account onboarding. Drift between accounts is the
number-one source of landing-zone audit findings.

## Deployment Sequence (Summary)

1. Management account + Organizations setup.
2. OU tree creation per the reference tree.
3. Control Tower landing-zone enablement on both governed regions.
4. SCP catalog deployment to OUs.
5. Log-archive + audit + security-tooling account provision.
6. CloudTrail org trail, Config aggregator, Security Hub delegated
   admin, GuardDuty delegated admin, Inspector delegated admin.
7. Network-hub account + Transit Gateway + egress inspection VPC.
8. Direct Connect provisioning + BGP peering.
9. Route 53 Resolver endpoints + resolver rules + RAM shares.
10. Per-suite VPC provisioning via account factory.
11. Per-app account onboarding via account factory.
12. Account baseline validation against the landing-zone schema.

Each step has a validation check documented in the runbook; a step
does not close until the validation passes.
