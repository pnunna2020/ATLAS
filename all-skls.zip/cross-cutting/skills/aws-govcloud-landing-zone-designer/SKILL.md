---
name: aws-govcloud-landing-zone-designer
description: >
  Design the per-portfolio AWS GovCloud (US) landing zone that the 8 FAA
  apps across 4 suites (IACRA, RMS, DMS, and the MSS suite — AMCS,
  MedXPress, CHAPS, CPDSS, DIWS) deploy into. Produces the Organizations
  structure (OUs, accounts), Control Tower configuration (governed
  regions, guardrails, customizations), Transit Gateway + VPC topology,
  Direct Connect design, SCP catalog, shared-services / log-archive /
  audit account layout, IP addressing plan, and hybrid DNS strategy.
  FedRAMP-tier-aware: High suites (RMS, IACRA, DMS) get isolated
  networking; Moderate suites (MSS) can share a suite-VPC. Portfolio-
  scoped, not per-app. Emits two artifacts — aws-govcloud-landing-zone.json
  (machine-readable topology) and landing-zone-runbook.md (human-readable
  deployment runbook). Triggers on landing zone design, Control Tower
  setup, Organizations OU structure, Transit Gateway topology, SCP
  catalog, shared services account layout, or
  @aws-govcloud-landing-zone-designer.
agent: sonnet
allowed-tools:
  - Read
  - Write
  - Grep
  - Bash
validation_commands:
  - "python -m olympus.validators.schema_validator aws-govcloud-landing-zone.json"
  - "markdownlint landing-zone-runbook.md"
supported_stacks:
  - aws-govcloud
  - fedramp-moderate
  - fedramp-high
  - multi-account-aws
anti_target_stacks:
  - commercial-aws
  - on-prem-only
  - azure-gov
failure_classes:
  - ip-collision-with-on-prem
  - scp-precedence-misorder
  - log-archive-not-immutable
  - control-tower-guardrail-missing-in-govcloud
  - fips-endpoint-scp-gap
benchmark_tags:
  - architecture-landing-zone
  - aws-govcloud-multi-account
  - soo-theme-c-foundation
---

# aws-govcloud-landing-zone-designer

## Purpose
Own the foundational landing-zone design step before any app deploys. The
landing zone is the multi-account, multi-OU, multi-VPC topology inside AWS
GovCloud that all 8 FAA apps share. Without this artifact, each app
negotiates its own VPC, its own Direct Connect BGP peers, its own
CloudTrail, and its own egress — producing a portfolio that cannot be
audited coherently. This skill emits a single source-of-truth topology that
`nist-control-automation-mapper` cites (AU-2, AU-9, AU-11 inheritance from
log-archive; SI-4 aggregation from security-tooling; CloudTrail org trail
scope), that `zero-trust-architecture-designer` cites (micro-segmentation
topology, egress inspection VPC, VPC endpoints), and that the deployment
team actually builds from. The runbook companion gives humans the step-by-
step deployment sequence — CloudFormation / Terraform templates produce
the accounts, but the policy calls (SCP order, OU placement, log-archive
lock) are where most landing zones fail in review, and those live in the
design, not the template.

## Inputs
- Per-app `ato-boundary-analyzer.json` — tier map: IACRA, RMS, DMS → High;
  AMCS, MedXPress, CHAPS, CPDSS, DIWS → Moderate. Tier drives OU
  placement (High goes under `Workloads/Production/FedRAMP-High`,
  Moderate under `Workloads/Production/FedRAMP-Moderate`).
- Per-app `target-architecture.json` — service inventory; informs VPC
  sizing (how many subnets, how many interfaces, how many VPC endpoints).
- Per-app `zero-trust-architecture.json` — micro-segmentation requirements
  (RMS needs per-subsystem isolation, shared-suite VPCs for MSS).
- Client profile `profiles/faa/technology.yaml` — reference stack
  decisions (approved compute, data, networking).
- Client profile `profiles/faa/compliance.yaml` — FedRAMP and FISMA
  constraints; Direct Connect peering locations approved for DOT /
  FAA; DNS strategy (internal zones, split-horizon).
- Reference — `references/aws-organizations-ou-patterns.md` (bundled
  with this skill) — OU patterns, SCP catalog, Control Tower guardrail
  selection, Transit Gateway topology options, DNS architectures.
- Existing FAA IP allocation records (10.x.x.x ranges in use on-prem) —
  to avoid collision with GovCloud VPC CIDRs.

## Outputs
- `aws-govcloud-landing-zone.json`:
  - `organization_structure` — `{management_account (account_id, email),
    ous[] (name, path, account_ids[], scp_ids[], purpose)}`.
  - `control_tower_config` — `{governed_regions[], landing_zone_version,
    guardrails[] (guardrail_id, type (mandatory | strongly-recommended |
    elective), enabled, scope_ous[]), customizations[] (cfct_module,
    purpose)}`.
  - `network_topology` — `{transit_gateway_config (tgw_id, asn,
    routing_domains[]), direct_connect_config (peering_location,
    bandwidth, vifs[]), vpc_per_suite[] (suite, cidr, subnets[] (name,
    cidr, type (public | private | isolated | tgw)), az_spread,
    fedramp_tier, vpc_endpoints[])}`.
  - `shared_accounts` — `{shared_services (account_id, purpose,
    services_hosted[]), log_archive (account_id, immutability_config
    (object_lock, vault_lock, deletion_protection)), audit (account_id,
    read_only_role, aggregator_membership), network_hub (account_id,
    tgw_owner)}`.
  - `scp_catalog[]` — `{scp_id, scp_name, purpose, ous_applied[],
    deny_actions[], exceptions[]}`.
  - `ip_addressing_plan` — `{supernet, allocations[] (suite, cidr,
    vpc_ids[]), reserved_for_on_prem_peering}`.
  - `dns_strategy` — `{route53_resolver_config, hybrid_dns_endpoints[]
    (inbound | outbound), internal_zones[], split_horizon (true |
    false)}`.
- `landing-zone-runbook.md` — human-readable deployment runbook with the
  ordered step sequence, the pre-conditions per step, and the validation
  checks per step. Markdown lint-clean.
- Schema-validation reports sibling to the JSON artifact.

## Methodology
1. Read all per-app `ato-boundary-analyzer.json` outputs. Build the
   tier map. Confirm it matches the known FAA portfolio: RMS, IACRA,
   DMS High; AMCS, MedXPress, CHAPS, CPDSS, DIWS Moderate.
2. Design the OU tree. Root is the management account (never hosts
   workloads). Mandatory OUs: `Security` (log-archive, audit, security-
   tooling accounts), `Workloads/Production/FedRAMP-High` (RMS, IACRA,
   DMS accounts), `Workloads/Production/FedRAMP-Moderate` (MSS apps
   accounts), `Workloads/NonProduction` (dev / test / staging per app),
   `Shared-Services` (shared-identity, shared-letter-generation,
   shared-document-imaging), `Sandbox` (throwaway exploration),
   `Suspended` (decommissioned accounts awaiting deletion).
3. Account per app per environment. Prod is its own account. NonProd
   combines dev / test / staging per app into either one account or
   three depending on cost / isolation trade-off — for FAA, 3 accounts
   per app per-env is the default to preserve tier isolation.
4. Select governed regions. GovCloud has `us-gov-west-1` and
   `us-gov-east-1`; enable both for DR scenarios. Customers limited
   to US personnel only — SCP enforces region restriction.
5. Configure Control Tower. Enable the landing-zone with FedRAMP-
   aligned guardrails: mandatory guardrails (always on),
   strongly-recommended (enable all; any deviations documented),
   elective (enable those that match FAA posture — region denial,
   service denial, encryption enforcement). Note: Control Tower
   GovCloud support lags commercial; some guardrails (e.g., certain
   AI / ML service denies) are not yet available in GovCloud — list
   them as gaps in the runbook.
6. Design the Transit Gateway topology. The TGW lives in the
   network-hub account, not the management account. Route tables
   per routing-domain: one per suite for isolation; `egress-inspection`
   attachment routes all 0.0.0.0/0 to the egress-inspection VPC; an
   `on-prem` attachment connects Direct Connect to the agency data
   center. FedRAMP High suites (RMS, IACRA, DMS) each get an isolated
   attachment with no cross-suite routing without explicit exception.
7. Design egress inspection. Dedicated egress VPC in the network-hub
   account hosts AWS Network Firewall (default option) or Palo Alto
   VM-Series (when FIPS 140-3 Level 3 egress filtering is required).
   All outbound traffic from workload VPCs routes to the egress VPC
   via TGW; egress VPC has the NAT Gateways and the only
   `0.0.0.0/0 → IGW` route.
8. Design the IP addressing plan. Pick a supernet that does not
   collide with existing FAA on-prem 10.x.x.x ranges — typically
   something like 10.100.0.0/12 for GovCloud Prod + 10.112.0.0/12
   for NonProd if on-prem uses 10.0.0.0/10. Reserve a contiguous
   range for on-prem peering summary advertisement. Allocate /20 per
   suite VPC with room to grow; High-suite VPCs get larger blocks
   due to per-subsystem VPC counts.
9. Design Direct Connect. Peering location must be a GovCloud-
   capable DX endpoint — limited set vs commercial. Two redundant
   connections minimum. Private VIFs to the network-hub account;
   transit VIFs if TGW-backed connectivity; BGP session parameters
   documented.
10. Design the SCP catalog. Minimum required denies:
    - `deny-leaving-organization` on all OUs.
    - `deny-root-activity` on Workloads OUs.
    - `deny-disabling-cloudtrail` on all OUs.
    - `deny-disabling-config` on all OUs.
    - `deny-disabling-guardduty` on all OUs.
    - `deny-modifying-log-archive-bucket-policy` on Security OU.
    - `deny-log-archive-bucket-deletion` on Security OU.
    - `enforce-fips-endpoints` on FedRAMP-High OU (denies any API
      call to a non-FIPS endpoint).
    - `deny-region-outside-govcloud` on all OUs (east and west only).
    - `deny-marketplace-non-approved` on Workloads OUs.
    - `deny-public-s3-block-public-access-disable` on all OUs.
    - `deny-imdsv1-launch` on Workloads OUs (enforces IMDSv2).
    - `deny-ec2-key-pair-creation` on Workloads OUs (Session Manager
      only; no SSH keys).
    Order matters: SCP precedence is deny-always-wins across OUs and
    the attached SCPs — test the combined effective policy before
    deploying. A cross-OU allow does not override a parent deny.
11. Configure the shared accounts:
    - **Log archive** account: receives the CloudTrail org trail and
      centralized CloudWatch Logs; S3 bucket has Object Lock in
      Compliance mode + vault lock + KMS CMK with delete-protection.
      Root cannot delete — enforce via bucket policy + SCP combo.
    - **Audit** account: read-only IAM role for auditors; Security
      Hub delegated admin in the security-tooling account (not
      audit); Config aggregator membership.
    - **Security-tooling** account: Security Hub delegated admin,
      GuardDuty delegated admin, IAM Access Analyzer delegated admin,
      Macie delegated admin, Inspector delegated admin. Aggregates
      findings from all member accounts; does not ingest from prod
      accounts directly — flows through the delegated-admin pattern.
    - **Shared services** account: IAM Identity Center home for staff
      identity (PIV federation); Login.gov SAML partner config for
      public federation; Route 53 Resolver endpoints for hybrid DNS.
12. Design hybrid DNS. Route 53 Resolver inbound endpoint for on-prem
    → GovCloud name resolution; outbound endpoint for GovCloud →
    on-prem; split-horizon zones where needed (e.g.,
    `internal.faa.gov` resolves differently cloud vs. on-prem).
    Private Hosted Zones per app in the workload account, shared via
    RAM to dependent accounts.
13. Emit the JSON artifact. Emit the markdown runbook with ordered
    deployment steps: (1) management account + Organizations; (2) OU
    creation; (3) Control Tower landing-zone enable; (4) SCP
    deployment; (5) log-archive + audit + security-tooling account
    provision; (6) CloudTrail org trail; (7) Config aggregator; (8)
    Security Hub delegated admin; (9) network-hub account + TGW;
    (10) egress inspection VPC; (11) Direct Connect; (12) Route 53
    Resolver; (13) per-suite VPC provisioning; (14) per-app account
    onboarding via account factory.
14. Validate. Check OU tier placement matches the tier map; every
    SCP in the catalog is referenced by at least one OU; IP plan
    does not overlap FAA on-prem allocations; log-archive bucket
    policy denies delete at every account level.

## Tech-Stack Dispatch

| Trigger | Key patterns |
|---|---|
| FedRAMP High app in portfolio | Mandatory `enforce-fips-endpoints` SCP on High OU; CloudHSM cluster hosted in shared-services or per-suite |
| Multi-region requirement | Both `us-gov-west-1` and `us-gov-east-1` governed; Transit Gateway peering across regions; Route 53 ARC for failover |
| Hybrid (on-prem integration) | Direct Connect two-VIF; Route 53 Resolver inbound + outbound; BGP peering with agency edge |
| Shared suite (MSS) | One suite-VPC with security-group tier isolation; shared services account hosts cross-suite identity |
| Isolated suite (RMS, IACRA, DMS) | Per-suite VPC minimum; RMS further per-subsystem VPC within the suite |

## Companion Considerations

This skill does not cover runtime controls (that's
`nist-control-automation-mapper`) or Zero Trust design (that's
`zero-trust-architecture-designer`). Overlap is explicit — the
topology emitted here is cited as the realization of AC-4, SC-7, and
the Network pillar design in the ZT architecture.

## Gotchas
- **GovCloud billing is separate from commercial.** You cannot
  federate Organizations across GovCloud and commercial partitions;
  the management account is a distinct entity with a distinct
  payer. Plan for two sets of billing / budgets / invoice workflows.
- **Control Tower GovCloud support lags commercial.** Some
  guardrails in commercial Control Tower are not yet available in
  GovCloud. List the missing guardrails in the runbook as gaps and
  implement them via direct SCP where possible.
- **Transit Gateway bandwidth across FedRAMP tiers requires review.**
  Cross-tier traffic patterns (e.g., Moderate → High) are often
  restricted by policy; flatten the topology so Moderate and High
  traffic flows do not share routing domains without explicit
  authorization.
- **IP addressing plan must avoid FAA on-prem collisions.** FAA on-
  prem typically uses large 10.x.x.x spaces. Pull the agency IP
  allocation register before picking supernets; a collision forces
  re-IP and breaks hybrid routing silently.
- **Direct Connect to GovCloud has limited peering locations.** Not
  every commercial DX endpoint is GovCloud-capable. Consult the AWS
  GovCloud direct-connect location list; pick locations with DOT /
  FAA approved carrier presence.
- **Shared-services account is the natural home for cross-account
  identity.** IAM Identity Center, Login.gov SAML config, PIV
  federation — all belong in shared-services so apps can consume
  them. Putting identity in the management account makes
  re-provisioning risky.
- **Log-archive account must be immutable.** S3 Object Lock in
  Compliance mode + vault lock + KMS CMK with delete-protection,
  plus bucket-policy deny on delete, plus SCP deny on the Security
  OU. Three layers; any one alone can be worked around.
- **Audit account is read-only.** Security tooling aggregates from
  log-archive into the security-tooling account, not from prod
  accounts directly. This preserves the log-archive as the single
  source of truth.
- **SCPs deny-always-wins across OUs.** An allow at a child OU does
  not override a deny at the parent. Test the effective combined
  policy using the IAM policy simulator before deploying; a common
  mistake is expecting child-OU allows to re-enable what parent
  denies.
- **Account factory for reproducible onboarding.** Control Tower
  Customizations (CfCT) or Customizations for AWS Control Tower
  make onboarding deterministic. Avoid click-ops provisioning — it
  drifts.
- **FIPS endpoint enforcement via SCP for High OUs.** Most services
  in GovCloud default to FIPS endpoints, but some are opt-in. An
  SCP denying `aws:CalledVia` non-FIPS endpoints on the FedRAMP-
  High OU closes the gap.
- **GovCloud Control Tower Enrollment is account-level.** You
  enroll each account; you do not bulk enroll OUs. Plan the
  enrollment wave to match the app onboarding plan.

## Quality Rules
- [ ] Every app in the portfolio has an account placement in the
      correct tier OU (High → `Workloads/Production/FedRAMP-High`,
      Moderate → `Workloads/Production/FedRAMP-Moderate`).
- [ ] Every SCP in the catalog is referenced by at least one OU in
      `organization_structure.ous[].scp_ids[]`; no orphan SCPs.
- [ ] `enforce-fips-endpoints` SCP is applied to every High-tier OU.
- [ ] Log-archive account immutability config includes all three
      layers: `object_lock`, `vault_lock`, `deletion_protection`;
      SCP denies policy modification.
- [ ] IP addressing plan does not overlap the agency on-prem
      allocation register recorded in
      `ip_addressing_plan.reserved_for_on_prem_peering`.
- [ ] Transit Gateway routing domains segregate tier traffic; no
      cross-tier route tables unless explicitly documented in an
      exception.
- [ ] Egress inspection VPC exists in `network_hub` and all workload
      VPCs route `0.0.0.0/0` through it.
- [ ] Both `us-gov-west-1` and `us-gov-east-1` appear in
      `control_tower_config.governed_regions[]`.
- [ ] The deployment runbook `landing-zone-runbook.md` passes
      markdown-lint and has a numbered step sequence.
- [ ] `aws-govcloud-landing-zone.json` validates against its schema.

## Common Failure Modes
| Failure Mode | Symptom | Prevention |
|---|---|---|
| IP collision with on-prem | Hybrid routing breaks silently on peering; BGP advertises conflicting prefixes | Pull FAA on-prem IP register before picking supernets; reserve a non-overlapping block |
| SCP precedence misorder (child allow expected to override parent deny) | Dev teams file tickets that services they need are blocked | Test combined effective policy in IAM simulator; document precedence in the runbook |
| Log archive not immutable (single layer only) | Audit fails AU-9 protection; evidence challengeable | Three layers: Object Lock + vault lock + SCP; plus bucket policy deny delete |
| Control Tower guardrail missing in GovCloud | Assumption of commercial-equivalent coverage; gap discovered at assessment | List missing guardrails in the runbook; backfill with direct SCP |
| FIPS endpoint SCP gap | High-tier app calls a non-FIPS endpoint; control SC-13 fails | `enforce-fips-endpoints` SCP on FedRAMP-High OU; test with actual API calls |
| Shared-services in management account | Re-provisioning management account for any reason risks identity outage | Identity services in dedicated shared-services account; management account holds only Organizations and billing |
| Per-app click-ops provisioning | Accounts drift; SCP not applied consistently | Account factory (Customizations for AWS Control Tower) mandatory |

## Handoff Summary
When this skill completes, verify:
1. `aws-govcloud-landing-zone.json` exists, passes its schema with
   zero errors, and covers every app in the portfolio.
2. `landing-zone-runbook.md` is markdown-lint clean and provides a
   numbered deployment sequence.
3. Every High-tier app OU has `enforce-fips-endpoints` SCP applied.
4. Log-archive account immutability is a three-layer config.
5. IP addressing plan does not overlap FAA on-prem allocations.
6. Transit Gateway topology segregates High and Moderate tiers.
7. Shared-services account hosts IAM Identity Center, Login.gov,
   Route 53 Resolver; log-archive, audit, security-tooling are
   separate accounts.

Then proceed to: `nist-control-automation-mapper` (which cites this
topology for AU / AC-4 / SC-7 controls), `zero-trust-architecture-
designer` (which cites micro-segmentation topology and egress-
inspection VPC), and the deployment pipeline. The next gate is
**G-04a** (Foundation Architecture Review) where the landing-zone
design and runbook must be accepted before any app account is
provisioned.

## References
- `references/aws-organizations-ou-patterns.md` — multi-account
  isolation strategies, SCP catalog, Control Tower guardrail
  selection per FedRAMP tier, Transit Gateway topology options,
  DNS architectures.
- AWS GovCloud (US) User Guide — `https://docs.aws.amazon.com/govcloud-us/`
- AWS Control Tower GovCloud documentation.
- FedRAMP 2024 guidance on OSCAL and continuous monitoring.
- `profiles/faa/technology.yaml` — FAA approved stack.
- `profiles/faa/compliance.yaml` — FAA compliance overlays.
- `schemas/architecture/aws-govcloud-landing-zone.schema.json`.

## Changelog
- 0.1.0 (2026-05-06) — Initial skill for SOO §6.1.1.1.3 Theme C
  (cATO foundation) + Objective 6 + Objective 7 (governance). Covers
  Organizations OU tree, Control Tower config, Transit Gateway +
  egress-inspection VPC topology, SCP catalog (FIPS endpoints, log
  archive protection, region restriction, IMDSv2 enforcement), and
  hybrid DNS. Designed for the 8 FAA apps across 4 suites with
  explicit FedRAMP tier isolation.
