---
name: factory-capacity-manager
description: >
  Monitor and manage factory capacity across concurrent waves, resolving resource contention and adjusting wave throughput. Use during P7.2. Triggers on factory capacity, wave contention, resource allocation, concurrent waves, or throughput management.
agent: opus
---

# Factory Capacity Management
## Purpose
When multiple waves run concurrently (wave N in P6, wave N+1 in P4,
wave N+2 in P2), manage resource allocation to prevent contention.

## Monitoring
- Claude Code session count vs available capacity
- Batch API request queue depth
- Git worktree count vs storage limits
- Human SME availability per wave
- Review/approval queue depth at gates

## Contention Resolution
1. Priority: Safety-critical (T1) waves always get priority
2. If contention: Delay lower-priority wave's non-critical phases
3. If sustained contention: Recommend wave delay to P1.4 for re-planning
4. Never sacrifice quality gates for throughput

## Gotchas
- **Human bottleneck is real**: SME reviews, stakeholder sign-offs, and safety
  board reviews don't parallelize well. Track human capacity separately.
- **Context window is a per-session resource**: Complex apps consume more context
  per session. Factor app complexity into capacity planning.

## Quality Rules
- [ ] T1 (safety-critical) waves always receive priority in resource allocation — no exceptions
- [ ] Human SME availability is tracked separately from automated capacity (sessions, API quota)
- [ ] Quality gates are never sacrificed for throughput — contention is resolved by delaying, not by skipping gates
- [ ] Capacity metrics are monitored: Claude Code sessions, Batch API queue depth, Git worktree count, gate review queue
- [ ] Contention resolution decisions are logged with justification and impact assessment

## Common Failure Modes
| Failure Mode | Symptom | Prevention |
|-------------|---------|------------|
| Human bottleneck ignored | Automated capacity available but SME reviews and sign-offs backlogged; waves stall at gates | Track human capacity separately; flag when review queues exceed SLA thresholds |
| Quality sacrificed for speed | Gate reviews rushed or skipped to meet wave deadlines; defects found post-deployment | Enforce rule: never sacrifice quality gates for throughput; delay wave if necessary |
| Complex app underestimated | Large app allocated same capacity as small app; context window exhaustion and session failures | Factor app complexity into capacity allocation; use analysis report size as a complexity proxy |
| No contention escalation | Sustained contention not escalated to wave planning; multiple waves degraded simultaneously | Escalate sustained contention to P1.4 for wave re-sequencing after 48 hours |

## Handoff Summary
When this skill completes, verify:
1. All active waves have adequate resource allocation
2. T1 waves have priority access to all resources
3. Contention decisions are logged with impact assessment
4. Human capacity (SME, reviewers) is tracked alongside automated capacity
Then proceed to: wave planning (P1.4) if re-sequencing is needed, or continue monitoring at P7.2
