# CICS → Spring mapping patterns

Reference for `cobol-to-java-generator` covering CICS transaction-processing
constructs: EXEC CICS commands, BMS maps, temporary storage queues, and the
pseudo-conversational programming model. Translates to Spring Web MVC REST
controllers, Thymeleaf views (when the target is HTML) or pure REST
responses (when the target is a headless API), and Spring caching /
messaging abstractions.

## Command inventory

| CICS command | Spring target | Notes |
|---|---|---|
| `EXEC CICS LINK PROGRAM('X') COMMAREA(...)` | Constructor-injected `XService` + typed method call | Return the mutated COMMAREA as a record |
| `EXEC CICS XCTL PROGRAM('X')` | HTTP 302 redirect (when web) or method call + `return` (when backend flow) | No return path to the caller |
| `EXEC CICS READ FILE('X') INTO(...)` | `xRepository.findById(...)` | Map file-status to exception (see table below) |
| `EXEC CICS READNEXT FILE('X')` | `xRepository.findBy<Key>After(key, Pageable)` | See `vsam-to-jpa.md` for START/READNEXT browse |
| `EXEC CICS WRITE FILE('X') FROM(...)` | `xRepository.save(...)` | `save` returns the persisted entity with generated ID |
| `EXEC CICS REWRITE FILE('X') FROM(...)` | `xRepository.save(existing)` | Must be after a prior `findById` / `findBy*` to satisfy optimistic lock version |
| `EXEC CICS DELETE FILE('X') RIDFLD(...)` | `xRepository.deleteById(...)` | Emits exception on missing id |
| `EXEC CICS SEND MAP` | Thymeleaf render OR `ResponseEntity<DTO>` | Choice depends on target architecture (HTML vs REST) |
| `EXEC CICS RECEIVE MAP` | `@PostMapping` / `@PutMapping` method with `@Valid @RequestBody DTO` | Map field names become DTO fields |
| `EXEC CICS START TRANSID('X')` | Message publish (Rabbit/Kafka) to async listener | Never an in-process `@Async` call — different durability guarantees |
| `EXEC CICS RETURN TRANSID('X')` | Return `ResponseEntity` with a header naming the next endpoint (or client-side routing state) | No server-side transaction ID registration |
| `EXEC CICS WRITEQ TS QUEUE('X')` | Redis / `CacheManager.put(...)` or `HttpSession` attribute | Prefer Redis; avoid session unless target architecture requires sticky sessions |
| `EXEC CICS READQ TS QUEUE('X')` | Redis / `CacheManager.get(...)` or `HttpSession.getAttribute` | Paired with WRITEQ; keep the key scheme identical |
| `EXEC CICS DELETEQ TS QUEUE('X')` | Redis `delete` / session invalidation | Required for pseudo-conversational cleanup |
| `EXEC CICS WRITEQ TD QUEUE('X')` | Kafka / Rabbit publish | TDQ is durable async, not cache |
| `EXEC CICS ENQ / DEQ` | `@Lock` on repository or distributed lock (Redisson / ZooKeeper) | Preserve resource name as the lock key |
| `EXEC CICS HANDLE CONDITION` | `@RestControllerAdvice` global handler | Map each condition to an HTTP status |
| `EXEC CICS HANDLE ABEND` | Global `@ExceptionHandler(Throwable.class)` in the advice | Always log with the originating transaction ID |

## LINK → service method

```cobol
EXEC CICS LINK PROGRAM('AIRVALID')
          COMMAREA(WS-COMMAREA)
          LENGTH(LENGTH OF WS-COMMAREA)
END-EXEC.
```

Becomes:

```java
@Service
@RequiredArgsConstructor
public class AirmanInquiryService {
  private final AirvalidService airvalid;

  @Transactional
  public InquiryResult inquire(InquiryCommarea commarea) {
    ValidationResult v = airvalid.check(commarea);  // EXEC CICS LINK AIRVALID
    if (!v.isValid()) {
      throw new BusinessRuleViolationException(v.errorMessage());
    }
    // ...
  }
}
```

Rules:
- `LINK` is synchronous — always a direct method call, never an async
  pattern.
- The COMMAREA is the method's parameter AND return value when CICS code
  mutates it. Prefer returning a new record over mutating the input.
- No `@Transactional` nesting — rely on Spring's `REQUIRED` propagation so
  the LINK target joins the caller's transaction.

## XCTL → redirect or method-and-return

```cobol
EXEC CICS XCTL PROGRAM('AINQMENU') COMMAREA(WS-COMMAREA) END-EXEC.
```

If the target program renders HTML, emit a redirect:

```java
return new RedirectView("/airmen/menu?sessionId=" + commarea.sessionId());
```

If the target is a backend service and the flow is entirely server-side,
emit a call followed by `return;`:

```java
ainqmenu.show(commarea);
return;
```

Never mix the two — the XCTL boundary must be obvious in the generated code.

## READ → repository findById

```cobol
EXEC CICS READ FILE('AIRMEN')
          RIDFLD(WS-AIRMAN-ID)
          INTO(WS-AIRMAN-RECORD)
          RESP(WS-RESP)
END-EXEC.

EVALUATE WS-RESP
    WHEN DFHRESP(NORMAL)   CONTINUE
    WHEN DFHRESP(NOTFND)   PERFORM NOT-FOUND
    WHEN OTHER             PERFORM ABEND-HANDLER
END-EVALUATE.
```

Becomes:

```java
Airman airman = airmanRepository.findById(airmanId)
    .orElseThrow(() -> new EntityNotFoundException(
        "Airman " + airmanId + " not found"));
```

Rules:
- `DFHRESP(NORMAL)` → success path, no additional code.
- `DFHRESP(NOTFND)` → `EntityNotFoundException` (or `Optional.empty()` +
  explicit handling when the caller must continue).
- Other response codes → domain exceptions mapped to HTTP status in the
  global `@RestControllerAdvice`.

## File-status / RESP → exception mapping

| COBOL file status / CICS RESP | Java exception | HTTP status |
|---|---|---|
| `'00'` / `DFHRESP(NORMAL)` | (success) | 200 / 201 |
| `'10'` / end-of-file | `NoSuchElementException` on iterator exhaustion | (none — control flow) |
| `'22'` / `DFHRESP(DUPKEY)` | `DataIntegrityViolationException` | 409 |
| `'23'` / `DFHRESP(NOTFND)` | `EntityNotFoundException` | 404 |
| `'35'` | `IllegalStateException` (file-not-found is a config error in Spring) | 500 |
| `'39'` | `IllegalStateException` (attribute mismatch) | 500 |
| `DFHRESP(ENDFILE)` | end-of-stream (do not throw; return empty page) | (none) |
| `DFHRESP(INVREQ)` | `IllegalArgumentException` | 400 |
| `DFHRESP(NOTAUTH)` | `AccessDeniedException` | 403 |

The global `@RestControllerAdvice` maps these to RFC 7807 Problem Details
responses.

## SEND MAP / RECEIVE MAP → REST endpoint pair

CICS pseudo-conversational pairs a `SEND MAP` (display) with a subsequent
`RECEIVE MAP` (collect input after the user submits). In a stateless REST
world, these become two endpoints threaded by the COMMAREA as request body.

### BMS map → DTO

```
AINQM01  DFHMDI SIZE=(24,80)
AIDINP   DFHMDF POS=(05,13),LENGTH=09,ATTRB=(UNPROT,IC,FSET)
NAMEOUT  DFHMDF POS=(07,13),LENGTH=40,ATTRB=(PROT,NORM)
MSGLNE   DFHMDF POS=(23,02),LENGTH=78,ATTRB=(ASKIP,BRT)
```

Becomes a DTO pair:

```java
public record AirmanInquiryRequest(
    @NotBlank @Size(min = 9, max = 9) String airmanId
) {}

public record AirmanInquiryResponse(
    String airmanId,
    String name,     // was NAMEOUT
    String message   // was MSGLNE
) {}
```

Rules:
- Input fields (BMS attribute `UNPROT`) → request DTO fields with Bean
  Validation annotations derived from `LENGTH=` and `PICIN=`.
- Output fields (BMS attribute `PROT` / `ASKIP`) → response DTO fields;
  no validation on the response side.
- Field names inherit the BMS label, lower-cased and camel-cased
  (`AIDINP` → `aidinp` or, better, a business-meaningful name like
  `airmanId` when the BMS label makes sense).

### SEND MAP → REST response

```cobol
EXEC CICS SEND MAP('AINQM01') MAPSET('AINQMS')
          FROM(AINQ-MAP-DATA)
          ERASE
END-EXEC.
```

When the target is REST / JSON:

```java
@GetMapping("/airmen/{airmanId}")
public ResponseEntity<AirmanInquiryResponse> inquiry(@PathVariable String airmanId) {
  return ResponseEntity.ok(airmanInquiryService.inquire(airmanId));
}
```

When the target is Thymeleaf / HTML:

```java
@GetMapping("/airmen/{airmanId}")
public String inquiry(@PathVariable String airmanId, Model model) {
  model.addAttribute("response", airmanInquiryService.inquire(airmanId));
  return "airmen/inquiry";  // resolves to templates/airmen/inquiry.html
}
```

### RECEIVE MAP → REST request

```cobol
EXEC CICS RECEIVE MAP('AINQM01') MAPSET('AINQMS')
          INTO(AINQ-MAP-DATA)
END-EXEC.
```

```java
@PostMapping("/airmen/search")
public ResponseEntity<AirmanInquiryResponse> search(
    @Valid @RequestBody AirmanInquiryRequest request) {
  return ResponseEntity.ok(airmanInquiryService.search(request));
}
```

## Pseudo-conversational flow → stateless REST + client-side state

CICS pseudo-conversational programs rely on the terminal + CICS transaction
manager to thread state across user interactions via the COMMAREA. A naive
translation introduces server-side sessions, which breaks scale-out.

Correct translation: the COMMAREA becomes a request body that the client
threads across calls. The server is stateless; each endpoint reads the
COMMAREA from the request, mutates it, and returns the new version.

Example flow:

```
User  -> GET /airmen/search-form               (empty commarea)
User  <- AirmanInquiryResponse (commarea v0)
User  -> POST /airmen/search { commarea v0, input } (client echoes commarea)
User  <- AirmanInquiryResponse (commarea v1 with results)
User  -> POST /airmen/update  { commarea v1, updates }
User  <- AirmanInquiryResponse (commarea v2 saved)
```

When the client cannot be trusted to echo the COMMAREA (e.g., browser
tab-switch), store the COMMAREA in Redis keyed by a `sessionId` returned
on the first response. This preserves the COBOL semantics without
introducing HTTP session affinity.

## START TRANSID → message publish

```cobol
EXEC CICS START TRANSID('ARPT')
          FROM(WS-REPORT-REQUEST)
          LENGTH(LENGTH OF WS-REPORT-REQUEST)
          INTERVAL(001500)
END-EXEC.
```

Becomes a message publish to a queue/topic named after the transaction:

```java
@Service
@RequiredArgsConstructor
public class AirmanInquiryService {
  private final RabbitTemplate rabbit;   // or KafkaTemplate
  private final TaskScheduler scheduler; // when INTERVAL is non-zero

  private void scheduleReport(ReportRequest request) {
    scheduler.schedule(
        () -> rabbit.convertAndSend("exchange.arpt", request),
        Instant.now().plusSeconds(15 * 60));  // INTERVAL 001500 = 15 minutes
  }
}
```

Rules:
- Never translate `START TRANSID` as an in-process `@Async` call. CICS
  `START` is durable — the request survives a system restart; `@Async`
  does not.
- The `INTERVAL` clause becomes a scheduled publish via `TaskScheduler`;
  missing it means publish immediately.

## Temporary Storage Queue → Redis

```cobol
EXEC CICS WRITEQ TS QUEUE('AINQ' || WS-TERMINAL-ID)
          FROM(WS-SEARCH-RESULTS)
          ITEM(WS-ITEM-NUMBER)
END-EXEC.
```

Becomes:

```java
private final RedisTemplate<String, SearchResults> redis;

private void writeToTsq(String tsqId, int itemNumber, SearchResults results) {
  redis.opsForList().set("tsq:" + tsqId, itemNumber, results);
}
```

Rules:
- TS queues are short-lived (within a transaction flow). Use Redis, not a
  database table.
- The key must include the terminal / session identifier to preserve the
  per-user isolation CICS provides.
- Set a TTL (typically 30 minutes) to auto-cleanup when the
  pseudo-conversational flow is abandoned.

## HANDLE CONDITION → @RestControllerAdvice

```cobol
EXEC CICS HANDLE CONDITION
          NOTFND(9100-NOT-FOUND)
          DUPKEY(9200-DUPLICATE)
          ERROR(9999-ABEND-HANDLER)
END-EXEC.
```

Becomes a global advice:

```java
@RestControllerAdvice
public class CicsConditionAdvice {

  @ExceptionHandler(EntityNotFoundException.class)  // NOTFND
  public ResponseEntity<ProblemDetail> notFound(EntityNotFoundException e) {
    return ResponseEntity.status(NOT_FOUND)
        .body(ProblemDetail.forStatusAndDetail(NOT_FOUND, e.getMessage()));
  }

  @ExceptionHandler(DataIntegrityViolationException.class)  // DUPKEY
  public ResponseEntity<ProblemDetail> duplicate(DataIntegrityViolationException e) {
    return ResponseEntity.status(CONFLICT)
        .body(ProblemDetail.forStatusAndDetail(CONFLICT, "Duplicate key"));
  }

  @ExceptionHandler(Throwable.class)  // ERROR / ABEND
  public ResponseEntity<ProblemDetail> abend(Throwable t) {
    log.error("Abend: {}", t.getMessage(), t);
    return ResponseEntity.status(INTERNAL_SERVER_ERROR)
        .body(ProblemDetail.forStatusAndDetail(INTERNAL_SERVER_ERROR, "Internal error"));
  }
}
```

## Task state → stateless controller

CICS tasks carry EIB (Execute Interface Block) fields like EIBTRNID (current
transaction ID), EIBTERMID (terminal), EIBAID (AID key pressed). Modern
equivalents:

| EIB field | Spring source |
|---|---|
| `EIBTRNID` | derived from the request mapping (no runtime field) |
| `EIBTERMID` | `HttpServletRequest.getSession().getId()` (only if sessions exist) or an explicit header |
| `EIBAID` | a field in the request body / form (which button was clicked) |
| `EIBTIME` / `EIBDATE` | `Clock` bean (inject for testability) — never `new Date()` inline |
| `EIBCALEN` | DTO length is implicit; do not preserve |

Controllers must be stateless — no instance fields holding per-request
data. All request-specific data flows through method parameters; all
cross-request state lives in Redis or the database.

## Security / authorization

CICS RACF resource checks (`EXEC CICS VERIFY PASSWORD`, `EXEC CICS
SIGNON`) map to Spring Security. The pattern depends on target identity
model (OKTA OAuth2 is the Olympus default):

```java
@PreAuthorize("hasAuthority('AIRMEN:READ')")
@GetMapping("/airmen/{airmanId}")
public ResponseEntity<AirmanInquiryResponse> inquiry(...) { ... }
```

Never translate CICS sign-on as a self-rolled session; always delegate to
the configured OAuth2 resource server.
