# COBOL → Java Spring Boot mapping patterns

Reference for `cobol-to-java-generator` covering the source-language side
of the transformation: COBOL divisions, sections, paragraphs, copybooks,
record layouts, PIC clauses, and control flow. CICS mappings live in
`cics-to-spring.md`; VSAM/DB2 mappings live in `vsam-to-jpa.md`.

## Divisions → class structure

A COBOL program has up to four divisions. One COBOL program produces one
Spring `@Service` class plus any supporting records. The divisions map as
follows:

| COBOL division / section | Java target | Notes |
|---|---|---|
| `IDENTIFICATION DIVISION` | Class Javadoc | Capture `PROGRAM-ID`, `AUTHOR`, `DATE-WRITTEN`, purpose comments verbatim |
| `ENVIRONMENT DIVISION / CONFIGURATION` | `@Configuration` bean (rare) | SOURCE-COMPUTER/OBJECT-COMPUTER are informational; decimal-point / special-names may require a `Locale` bean |
| `ENVIRONMENT DIVISION / INPUT-OUTPUT / FILE-CONTROL` | JPA repositories | Each `SELECT ... ASSIGN TO` becomes a repository; file-status variables become mapped exception types (see `vsam-to-jpa.md`) |
| `DATA DIVISION / FILE SECTION` | JPA entities + DTOs | FD records become `@Entity`; non-persistent record layouts become records |
| `DATA DIVISION / WORKING-STORAGE` | Private fields (stateless) or request-scoped bean (stateful) | Never a singleton-scoped field if the COBOL program is pseudo-conversational |
| `DATA DIVISION / LINKAGE SECTION` | Method parameters (public entry) | The 01-level COMMAREA becomes a Java record DTO parameter |
| `PROCEDURE DIVISION` | Methods on the `@Service` | One method per PERFORM-target paragraph/section |

### Example: program → service

```cobol
IDENTIFICATION DIVISION.
PROGRAM-ID. AIRMAN-INQUIRY.
AUTHOR.     FAA-MODERNIZATION-TEAM.

DATA DIVISION.
LINKAGE SECTION.
01  LS-COMMAREA.
    05  LS-FUNCTION-CODE  PIC X(02).
    05  LS-AIRMAN-ID      PIC X(09).
    05  LS-RETURN-CODE    PIC 9(04).

PROCEDURE DIVISION USING LS-COMMAREA.
0000-MAIN-PROCESS.
    PERFORM 1000-INITIALIZE
    PERFORM 2000-PROCESS-REQUEST
    PERFORM 9000-RETURN
    STOP RUN.
```

Becomes:

```java
/**
 * AIRMAN-INQUIRY
 * Retrieve and display airman certification records.
 * Original author: FAA-MODERNIZATION-TEAM.
 * Source: AIRMAN-INQUIRY.cbl:1-105
 */
@Service
@RequiredArgsConstructor
public class AirmanInquiryService {

  private final AirmanRepository airmanRepository;
  private final AirmanValidationService airmanValidation;

  /**
   * Entry point — corresponds to COBOL paragraph 0000-MAIN-PROCESS.
   */
  @Transactional
  public AirmanInquiryResult process(AirmanInquiryCommarea commarea) {
    initialize(commarea);
    var result = processRequest(commarea);
    return complete(commarea, result);
  }

  private void initialize(AirmanInquiryCommarea commarea) { /* 1000-INITIALIZE */ }
  private AirmanRecord processRequest(AirmanInquiryCommarea commarea) { /* 2000 */ }
  private AirmanInquiryResult complete(AirmanInquiryCommarea c, AirmanRecord r) {
    /* 9000-RETURN */
    return new AirmanInquiryResult(...);
  }
}

public record AirmanInquiryCommarea(
    @Size(min = 2, max = 2) String functionCode,
    @Size(min = 9, max = 9) String airmanId,
    @Min(0) @Max(9999) int returnCode
) {}
```

Rules:
- The public entry method is always `@Transactional` and named after the
  program's purpose, not `main` or `process` unless that is literally the
  paragraph name.
- The COMMAREA record is a sibling DTO, not a nested class — it is reused
  by REST controllers and other services.

## Paragraphs and sections → methods

Each paragraph that is a PERFORM target becomes a method. Access modifier:
- `public` when the paragraph is reachable from outside the current
  compile-unit (another program or subprogram calls it via `CALL`)
- `private` otherwise

### PERFORM variants

| COBOL | Java |
|---|---|
| `PERFORM 1000-X` | `methodX();` |
| `PERFORM 1000-X THRU 1999-X-EXIT` | Ordered sequence of method calls, one per paragraph in range, in the order declared in source |
| `PERFORM 1000-X VARYING I FROM 1 BY 1 UNTIL I > N` | `for (int i = 1; i <= n; i++) methodX(i);` |
| `PERFORM 1000-X UNTIL flag = 'Y'` | `while (!"Y".equals(flag)) methodX();` |
| `PERFORM 1000-X 10 TIMES` | `for (int i = 0; i < 10; i++) methodX();` |

Never translate `PERFORM ... THRU` as a fall-through `switch (true)`; the
paragraph range must be expanded explicitly.

### GO TO translation

- `GO TO <para>` where `<para>` is within the same paragraph block and is
  downstream of the `GO TO`: translate as `return;` (early return).
- `GO TO <para>` across paragraph boundaries: emit a TODO with the
  extracted paragraph name and leave the generated method in a guarded
  branch. The Ralph Loop refactors; do not attempt silent flattening.
- `ALTER` statement: refuse to generate. Emit a `skill-prerequisite-failure`
  artifact and require human review.

## CALL → constructor-injected service dependency

```cobol
CALL 'AIRVALID' USING WS-AIRMAN-ID WS-VALIDATION-RESULT.
```

Becomes:

```java
@Service
@RequiredArgsConstructor
public class AirmanInquiryService {
  private final AirvalidService airvalid;

  private ValidationResult validate(String airmanId) {
    return airvalid.check(airmanId);
  }
}
```

Rules:
- Static CALL (program name is a literal) → constructor-injected dependency.
- Dynamic CALL (`CALL WS-PROGRAM-NAME`) → a registry/factory lookup
  (`Map<String, CobolProgramService>` keyed on the literal program name)
  with a compile-time guard that every literal reachable by data-flow
  analysis is present in the registry.
- If the COBOL CALL passes parameters `BY REFERENCE` and mutates them, the
  Java method MUST return the mutated value as a record — Java primitives
  are pass-by-value.

## COPY → inheritance / imports

A COBOL copybook is a source-level include. The transformation depends on
the copybook's content.

### Data-only copybooks (record layouts)

```cobol
01  AIRMAN-REC.
    COPY AIRMAN-NAME-FIELDS.
    COPY AIRMAN-ADDRESS-FIELDS.
```

Each data-only copybook becomes a shared Java record or class. Programs
that `COPY` it either reuse the same Java class or extend it when
additional fields are declared locally.

Rule: if copybook A is included by two or more programs, generate exactly
one Java class and have both programs reference it. Do not duplicate the
field set per program.

### Procedure-only copybooks (shared paragraphs)

```cobol
PROCEDURE DIVISION.
    COPY DATE-ROUTINES.
```

Becomes a utility `@Component` with static helpers, or an abstract base
`@Service` class when the copybook paragraphs read/write COBOL
working-storage that the includer declares.

### COPY REPLACING

```cobol
COPY AIRMAN-REC REPLACING
    ==:PREFIX:== BY ==WS-==
    ==:TABLE:==  BY ==AIRMEN==.
```

The generator MUST resolve REPLACING at generation time and emit the
substituted field names directly in the Java source. Do NOT emit a
generic template. Record the substitution map in the traceability index so
reviewers can trace back to the un-substituted copybook.

If the same copybook is included with *different* REPLACING maps in two
programs, generate two distinct Java classes with suffixed names
(`AirmanRec_Ws`, `AirmanRec_Ls`) and document the reason in Javadoc.

## 01-level records → POJO / JPA entity

A 01-level record becomes:
- A Java record (`record`) when the layout is immutable and transient (e.g.,
  a COMMAREA, a BMS map data copy, a DTO)
- A JPA `@Entity` when the 01-level is the target of an FD with VSAM
  `ORGANIZATION IS INDEXED` or when it matches a DCLGEN for a DB2 table
- A mutable POJO (class with getters/setters) only when COBOL code mutates
  the record in place and the generator cannot prove immutability

### Group levels → nested records or flat fields

```cobol
01  WS-AIRMAN-RECORD.
    05  WS-AIRMAN-ID    PIC X(09).
    05  WS-NAME-GROUP.
        10  WS-LAST-NAME   PIC X(25).
        10  WS-FIRST-NAME  PIC X(15).
```

Prefer nested records when the group has business meaning:

```java
public record AirmanRecord(
    String airmanId,
    NameGroup name) {}

public record NameGroup(String lastName, String firstName) {}
```

Flatten the group to sibling fields only when the COBOL code treats the
group purely as a byte-addressing convenience (no paragraph operates on
the group as a whole).

### REDEFINES → separate fields

```cobol
01  WS-DATE-FIELD.
    05  WS-DATE-NUM  PIC 9(08).
01  WS-DATE-PARTS REDEFINES WS-DATE-FIELD.
    05  WS-DATE-YYYY PIC 9(04).
    05  WS-DATE-MM   PIC 9(02).
    05  WS-DATE-DD   PIC 9(02).
```

Generate two separate records and a conversion helper. Never emit a union
type in Java (there is no equivalent); the type safety lost by union
overlay is recovered by explicit conversion.

### OCCURS → `List<T>` or fixed array

- `OCCURS n TIMES` (fixed) → `List<T>` with size assertion, not `T[n]`
- `OCCURS n TO m TIMES DEPENDING ON counter` (variable) → `List<T>` where
  `counter` becomes the list's `size()` invariant
- Nested `OCCURS` → `List<List<T>>` or a nested record; choose based on
  whether the inner array has business meaning

## PIC clause → Java type

| PIC clause | Java type | Bean Validation / scale |
|---|---|---|
| `PIC X(n)` | `String` | `@Size(min = n, max = n)` (fixed length) or `@Size(max = n)` (variable) |
| `PIC A(n)` | `String` | `@Size(...)` plus `@Pattern(regexp = "[A-Za-z ]+")` |
| `PIC 9(n)` | `int` if n ≤ 9, `long` if 10 ≤ n ≤ 18, `BigInteger` if n ≥ 19 | `@Min(0)` + `@Max(10^n - 1)` |
| `PIC S9(n)` | `int` / `long` / `BigInteger` (signed) | `@Min(-(10^n-1))` + `@Max(10^n-1)` |
| `PIC 9(n)V9(m)` | `BigDecimal` | `@Digits(integer = n, fraction = m)`, scale = m |
| `PIC S9(n)V9(m)` | `BigDecimal` (signed) | `@Digits(integer = n, fraction = m)`, scale = m |
| `PIC S9(n) COMP` (binary) | `short` if n ≤ 4, `int` if n ≤ 9, `long` if n ≤ 18 | `@Min / @Max` bounds per n |
| `PIC S9(n) COMP-3` (packed decimal) | `BigDecimal` | `@Digits(integer = n, fraction = 0)`, scale = 0 |
| `PIC S9(n)V9(m) COMP-3` | `BigDecimal` | `@Digits(integer = n, fraction = m)`, scale = m |
| `PIC S9(n) COMP-5` (native binary) | `long` (conservative) | As for COMP |

### COMP-3 → BigDecimal is mandatory

COMP-3 (packed decimal) provides exact decimal arithmetic — the sole reason
COBOL dominates financial and regulatory systems. Any mapping to `double`
or `float` introduces rounding errors that break parity with the legacy
system. Even a single conversion through `double` during intermediate
calculation is enough to corrupt downstream results.

The generator's guard:
- Any COBOL source field with `COMP-3` or `PACKED-DECIMAL` clause → Java
  `BigDecimal` field with explicit `scale`.
- Any arithmetic over such fields → `BigDecimal` operators (`add`,
  `subtract`, `multiply`, `divide(... , RoundingMode)`); never intermix
  with `double`.
- The validator checks that no generated source references `Double` or
  `Float` in the context of a COBOL-derived numeric field.

### Numeric rounding (`ROUNDED` clause)

```cobol
COMPUTE WS-TAX ROUNDED = WS-SUBTOTAL * WS-TAX-RATE.
```

The COBOL `ROUNDED` phrase applies banker's rounding (half-even). Java:

```java
tax = subtotal.multiply(taxRate).setScale(TAX_SCALE, RoundingMode.HALF_EVEN);
```

Without `ROUNDED`, COBOL truncates. Map to `RoundingMode.DOWN`:

```java
tax = subtotal.multiply(taxRate).setScale(TAX_SCALE, RoundingMode.DOWN);
```

### ON SIZE ERROR

COBOL's `ON SIZE ERROR` detects overflow. In Java, `BigDecimal` does not
overflow silently — emit the arithmetic inside a `try` block that catches
`ArithmeticException` (from `divide` with no rounding) and checks the
result's `precision()` against the declared PIC precision.

## 88-level condition names → enum or Predicate

Single-value 88-level:

```cobol
05  WS-CERT-STATUS  PIC X(08).
    88  CERT-ACTIVE   VALUE 'ACTIVE'.
    88  CERT-EXPIRED  VALUE 'EXPIRED'.
```

Becomes a Java enum:

```java
public enum CertStatus {
  ACTIVE("ACTIVE"),
  EXPIRED("EXPIRED");

  private final String code;
  CertStatus(String code) { this.code = code; }
  public String code() { return code; }
}
```

Multi-value 88-level:

```cobol
88  CERT-VALID  VALUE 'ACTIVE' 'RENEWED'.
```

Becomes a `Predicate<CertStatus>` constant — NOT a single enum value:

```java
public static final Predicate<CertStatus> CERT_VALID =
    s -> s == CertStatus.ACTIVE || s == CertStatus.RENEWED;
```

Never collapse a multi-value 88 to a single enum value — the COBOL code
was testing set membership.

## EVALUATE → switch expression

Single-subject:

```cobol
EVALUATE WS-REQUEST-TYPE
    WHEN 'INQ' PERFORM 2100-INQUIRY
    WHEN 'UPD' PERFORM 2200-UPDATE
    WHEN OTHER PERFORM 9500-INVALID
END-EVALUATE.
```

Java 21 switch:

```java
switch (requestType) {
  case "INQ" -> inquiry();
  case "UPD" -> update();
  default    -> invalid();
}
```

Multi-subject:

```cobol
EVALUATE WS-TYPE ALSO WS-STATUS
    WHEN 'UPD' ALSO 'ACTIVE'  PERFORM 2200
    WHEN 'UPD' ALSO 'EXPIRED' PERFORM 2201
```

Java 21 pattern switch over a record:

```java
record Key(String type, String status) {}
switch (new Key(type, status)) {
  case Key("UPD", "ACTIVE")  -> update();
  case Key("UPD", "EXPIRED") -> renew();
  default                    -> invalid();
}
```

Never translate a multi-subject EVALUATE to nested `if` chains — the
semantic hint is lost.

## STRING / UNSTRING → Java string APIs

- `STRING ... INTO result` → `result = String.join(delimiter, parts);`
  or a `StringJoiner` if per-field delimiters vary
- `UNSTRING source INTO f1 f2 f3` → `String[] parts = source.split(delim, -1);`
  plus bounds checking matching COBOL `TALLYING` / `COUNT IN` behavior

Preserve the `ON OVERFLOW` semantics as an explicit exception or guard
rather than silently truncating.

## Handoff citation format

Every generated Java file must be listed in the traceability index as:

```
{java-file} <- {program}:{paragraph}:{line}        (service method)
{java-record} <- {copybook}:{level}:{field}         (data record)
{java-entity} <- {dclgen-member}:{column}           (DB2 mapping)
{java-entity} <- {fd-file}:{record-key}             (VSAM mapping)
```

With REPLACING substitutions recorded as:

```
AirmanRec_Ws <- AIRMAN-REC.cpy REPLACING :PREFIX:=WS-, :TABLE:=AIRMEN
```
