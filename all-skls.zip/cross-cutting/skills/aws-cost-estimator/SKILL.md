---
name: aws-cost-estimator
description: >
  Estimate cloud operating costs for modernized applications on AWS GovCloud.
  Compares projected cloud costs against pre-modernization TCO baselines from
  Discovery to quantify net savings. Used during Architecture Step 5 and
  Governance cost reviews. Triggers on cost estimation, cloud cost, TCO
  comparison, AWS pricing, or cost projection mentions.
agent: sonnet
allowed-tools:
  - Read
  - Write
  - Bash
---

# AWS Cloud Cost Estimator

## Purpose
Produce itemized cloud cost projections for each modernized application,
compare them against Discovery TCO baselines, and quantify net savings.
This feeds architecture decision justification (Step 1), blueprint cost
sections (Step 6), and portfolio-level cost governance (P6.2).

## Inputs
- TCO baseline from Discovery (tco-analyzer output)
- Target architecture blueprint (compute, data, integration selections)
- Application archetype and risk tier
- Expected traffic patterns (steady-state, bursty, batch)
- Environment count (dev, staging, prod)

## Outputs
- Itemized monthly cost estimate per AWS service
- Savings plan recommendations
- Current TCO vs projected cloud cost comparison
- Net monthly and annual savings
- ROI percentage
- Cost estimate artifact (`cost-estimate.yaml` from template)

## Methodology
1. Load TCO baseline from Discovery artifacts
2. Estimate compute costs (Fargate hours x size, Lambda invocations x duration) using `references/aws-pricing-reference.md`
3. Estimate data tier costs (Aurora storage + I/O, DynamoDB RCU/WCU, S3 storage classes)
4. Estimate networking costs (data transfer cross-AZ and to internet, NAT Gateway, CloudFront, ALB)
5. Estimate integration costs (EventBridge events, SQS messages, Gravitee licensing)
6. Apply savings optimizations from `references/cost-optimization-patterns.md` (Reserved Instances, Savings Plans, Fargate Spot)
7. Compare: current TCO vs projected cloud cost vs net savings

## Gotchas
- **GovCloud pricing is higher than commercial**: GovCloud typically adds
  5-10% over commercial region pricing. Always use GovCloud price points.
- **Data transfer costs are often underestimated**: Cross-AZ traffic at
  $0.01/GB and NAT Gateway at $0.045/GB add up quickly for chatty
  microservices. Model actual traffic patterns, not just storage.
- **Don't forget non-compute costs**: Monitoring (CloudWatch), secrets
  management (Secrets Manager), and logging (CloudWatch Logs) are real
  costs that are easy to omit.
- **Environment multiplier matters**: Dev and staging environments should
  use smaller instances and scheduled scaling, not prod-equivalent sizing.

## Quality Rules
- [ ] Cost estimate uses GovCloud pricing, not commercial region pricing
- [ ] All architecture services are accounted for — no service in the blueprint is missing from the cost estimate
- [ ] Data transfer costs are modeled with actual traffic patterns, not just storage volume
- [ ] Non-compute costs included: monitoring, logging, secrets management, load balancing
- [ ] Environment multiplier applied: dev/staging use smaller sizing and scheduled scaling
- [ ] Savings plans are recommended with specific commitment terms and projected savings percentages
- [ ] TCO comparison uses the same time horizon (monthly or annual) for both current and projected

## Common Failure Modes
| Failure Mode | Symptom | Prevention |
|-------------|---------|------------|
| Commercial pricing used | Cost estimate 5-10% lower than actual GovCloud bill; budget overrun | Always reference GovCloud pricing; flag any service without GovCloud pricing |
| Data transfer costs omitted | Actual bill 20-40% higher than estimate due to cross-AZ and NAT costs | Model data transfer per service interaction; include NAT Gateway for private subnets |
| Environment costs ignored | Three environments deployed at prod sizing; 3x cost overrun | Apply environment-specific sizing: dev at minimum, staging at 50%, prod at full |
| Savings plans not modeled | On-demand pricing used for steady-state workloads; 30-60% savings left on table | Identify steady-state vs variable workloads; recommend appropriate savings commitment |

## Handoff Summary
When this skill completes, verify:
1. Every service in the architecture blueprint has a corresponding cost line item
2. Data transfer costs reflect actual service interaction patterns
3. Savings plan recommendations match workload characteristics
4. TCO comparison shows clear before/after with net savings
Then proceed to: `blueprint-assembler` (Step 6) for inclusion in the architecture blueprint, and `tco-analyzer` for post-deployment actual cost tracking
