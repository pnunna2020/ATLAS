# AWS GovCloud Pricing Reference

Reference data for the aws-cost-estimator skill. All prices reflect AWS
GovCloud (US) regions as of the latest available pricing. GovCloud pricing
is typically 5-10% above commercial regions.

> **Important**: Verify current pricing against the
> [AWS GovCloud Pricing Page](https://aws.amazon.com/govcloud-us/pricing/)
> before finalizing any cost estimate. Prices change periodically.

---

## Compute Services

### AWS Fargate (ECS)

Fargate pricing is per vCPU-hour and per GB-hour of memory provisioned.

| Resource | On-Demand | Fargate Spot | Savings (Spot) |
|----------|-----------|-------------|----------------|
| vCPU per hour | $0.04656 | $0.01397 | ~70% |
| GB memory per hour | $0.00511 | $0.00153 | ~70% |

**Common task configurations:**

| Profile | vCPU | Memory (GB) | Monthly On-Demand (730h) | Monthly Spot |
|---------|------|-------------|--------------------------|--------------|
| Small API | 0.25 | 0.5 | $15.39 | $4.62 |
| Medium API | 0.5 | 1.0 | $37.99 | $11.40 |
| Standard Service | 1.0 | 2.0 | $71.44 | $21.43 |
| Large Service | 2.0 | 4.0 | $142.88 | $42.86 |
| Compute-Intensive | 4.0 | 8.0 | $285.76 | $85.73 |

**Scaling considerations:**
- Minimum tasks for HA: 2 (multi-AZ)
- Auto-scaling target: 60-70% CPU utilization
- Scale-to-zero not available for Fargate (minimum 1 task unless using scheduled scaling)

### AWS Lambda

| Component | Price |
|-----------|-------|
| Per 1M invocations | $0.20 |
| Per GB-second | $0.0000166667 |
| Free tier | 1M invocations + 400,000 GB-seconds/month |
| Provisioned Concurrency | $0.0000097222 per GB-second |

**Duration cost by memory configuration:**

| Memory (MB) | Cost per 100ms | Monthly cost at 1M invocations (200ms avg) |
|-------------|----------------|---------------------------------------------|
| 128 | $0.000000208 | $0.62 |
| 256 | $0.000000417 | $1.03 |
| 512 | $0.000000833 | $1.87 |
| 1024 | $0.000001667 | $3.53 |
| 2048 | $0.000003333 | $6.87 |
| 3072 | $0.000005000 | $10.20 |

---

## Data Services

### Amazon Aurora PostgreSQL

#### Serverless v2

| Component | Price |
|-----------|-------|
| Per ACU-hour | $0.12 |
| Storage per GB/month | $0.10 |
| I/O per million requests | $0.20 |
| Backup storage (beyond DB size) per GB/month | $0.021 |

**ACU sizing guide:**

| Workload | Min ACU | Max ACU | Monthly Compute (est.) |
|----------|---------|---------|------------------------|
| Low-traffic API | 0.5 | 2 | $43.80 - $175.20 |
| Standard application | 2 | 8 | $175.20 - $700.80 |
| High-traffic service | 4 | 16 | $350.40 - $1,401.60 |
| Heavy analytics | 8 | 64 | $700.80 - $5,606.40 |

#### Provisioned Instances

| Instance Type | vCPU | Memory | Monthly Cost |
|---------------|------|--------|-------------|
| db.r6g.large | 2 | 16 GB | $262.80 |
| db.r6g.xlarge | 4 | 32 GB | $525.60 |
| db.r6g.2xlarge | 8 | 64 GB | $1,051.20 |

**Multi-AZ**: 2x instance cost for synchronous replication.

### Amazon DynamoDB

#### On-Demand Mode

| Component | Price |
|-----------|-------|
| Per 1M write request units (WRU) | $1.25 |
| Per 1M read request units (RRU) | $0.25 |
| Storage per GB/month | $0.25 |
| Global table replication per 1M rWRU | $1.875 |

#### Provisioned Mode

| Component | Price |
|-----------|-------|
| Per WCU/month (provisioned) | $0.00065 |
| Per RCU/month (provisioned) | $0.00013 |
| Storage per GB/month | $0.25 |
| Reserved capacity (1-year): WCU | $0.000128 (~80% savings) |
| Reserved capacity (1-year): RCU | $0.0000256 (~80% savings) |

### Amazon ElastiCache (Redis)

| Node Type | vCPU | Memory | Monthly Cost |
|-----------|------|--------|-------------|
| cache.r6g.large | 2 | 13.07 GB | $219.00 |
| cache.r6g.xlarge | 4 | 26.32 GB | $438.00 |
| cache.r6g.2xlarge | 8 | 52.82 GB | $876.00 |

**Multi-AZ replication**: 2x node cost for automatic failover.

---

## Storage Services

### Amazon S3

| Storage Class | Per GB/month | Retrieval per 1000 requests |
|---------------|-------------|----------------------------|
| S3 Standard | $0.023 | GET: $0.0004, PUT: $0.005 |
| S3 Infrequent Access | $0.0125 | GET: $0.001, PUT: $0.01 |
| S3 Glacier Instant Retrieval | $0.004 | GET: $0.01, PUT: $0.02 |
| S3 Glacier Flexible Retrieval | $0.0036 | GET: $0.01 (3-5h), PUT: $0.03 |
| S3 Intelligent-Tiering | $0.023 (frequent) | Monitoring: $0.0025/1000 objects |

**Lifecycle policy savings**: Move artifacts older than 90 days to IA (45% savings),
older than 365 days to Glacier Instant (83% savings).

---

## Networking

### Data Transfer

| Transfer Type | Cost per GB |
|---------------|-------------|
| Within same AZ | Free |
| Cross-AZ (same region) | $0.01 |
| To internet (first 10 TB/month) | $0.09 |
| To internet (next 40 TB/month) | $0.085 |
| To internet (next 100 TB/month) | $0.07 |
| Between AWS services (same region) | Free (via VPC endpoint) |

### NAT Gateway

| Component | Price |
|-----------|-------|
| Per hour | $0.045 |
| Per GB processed | $0.045 |
| Monthly fixed cost (per gateway) | $32.85 |

**Cost optimization**: Use VPC endpoints for S3 and DynamoDB to avoid NAT
Gateway charges for those services.

### Application Load Balancer (ALB)

| Component | Price |
|-----------|-------|
| Per hour | $0.0225 |
| Per LCU-hour | $0.008 |
| Monthly fixed cost | $16.43 |

**LCU dimensions** (charged on highest):
- 25 new connections/second
- 3,000 active connections/minute
- 1 GB/hour for EC2 targets, 0.4 GB/hour for Lambda
- 1,000 rule evaluations/second

### Amazon CloudFront

| Component | Price |
|-----------|-------|
| First 10 TB/month | $0.085/GB |
| Next 40 TB/month | $0.080/GB |
| HTTPS requests per 10,000 | $0.0100 |

---

## Integration Services

### Amazon EventBridge

| Component | Price |
|-----------|-------|
| Per million custom events published | $1.00 |
| Per million cross-account events | $1.00 |
| Schema discovery | Free |
| Archive per GB stored | $0.023 |
| Replayed events per million | $0.10 |

### Amazon SQS

| Component | Price |
|-----------|-------|
| Standard queue per million requests | $0.40 |
| FIFO queue per million requests | $0.50 |
| Free tier | 1M requests/month |

### AWS Step Functions

| Component | Price |
|-----------|-------|
| Standard per 1,000 state transitions | $0.025 |
| Express per million requests | $1.00 |
| Express per GB-second | $0.00001667 |

---

## Observability

### Amazon CloudWatch

| Component | Price |
|-----------|-------|
| Custom metrics per month | $0.30 |
| API requests per 1,000 (GetMetricData) | $0.01 |
| Logs ingestion per GB | $0.50 |
| Logs storage per GB/month | $0.03 |
| Dashboards per month | $3.00 |
| Alarms (standard) per month | $0.10 |
| Container Insights per task per month | $2.50 |

### AWS X-Ray

| Component | Price |
|-----------|-------|
| Traces recorded per million | $5.00 |
| Traces retrieved per million | $0.50 |
| Free tier | 100,000 traces recorded, 1M retrieved |

---

## Security and Identity

### AWS Secrets Manager

| Component | Price |
|-----------|-------|
| Per secret/month | $0.40 |
| Per 10,000 API calls | $0.05 |

### AWS KMS

| Component | Price |
|-----------|-------|
| Customer-managed key per month | $1.00 |
| API requests per 10,000 | $0.03 |

### AWS WAF

| Component | Price |
|-----------|-------|
| Per web ACL/month | $5.00 |
| Per rule/month | $1.00 |
| Per million requests | $0.60 |

---

## Gravitee API Gateway (Non-AWS)

Gravitee is licensed separately from AWS. Pricing depends on the
enterprise agreement.

| Component | Typical Range |
|-----------|--------------|
| Enterprise license (annual) | $50,000 - $200,000 |
| Per-API overhead | Included in license |
| Infrastructure (runs on Fargate) | See Fargate pricing |

> **Note**: Gravitee licensing costs are shared across all applications
> using the gateway. Apportion per-application cost as:
> `license_cost / number_of_apis_served`.

---

## Cost Ranges by Application Archetype

These ranges assume a single production environment with multi-AZ HA.
Add 30-50% for dev + staging environments with scheduled scaling.

### Tier 3 — Low-Criticality Applications

| Archetype | Monthly Range | Typical |
|-----------|--------------|---------|
| Simple Web App (Fargate) | $150 - $400 | $250 |
| Batch Job (Lambda + Step Functions) | $20 - $100 | $50 |
| Simple API (Fargate) | $120 - $350 | $200 |
| Static Site (S3 + CloudFront) | $5 - $30 | $15 |

### Tier 2 — Standard Applications

| Archetype | Monthly Range | Typical |
|-----------|--------------|---------|
| Web App + API (Fargate, Aurora) | $500 - $1,500 | $900 |
| Event-Driven Service (Lambda, EventBridge) | $100 - $500 | $250 |
| Microservices (3-5 services) | $800 - $2,500 | $1,500 |
| Data Pipeline (Step Functions, Lambda, S3) | $200 - $800 | $400 |

### Tier 1 — Mission-Critical Applications

| Archetype | Monthly Range | Typical |
|-----------|--------------|---------|
| HA Web Platform (multi-AZ, multi-service) | $2,000 - $8,000 | $4,500 |
| Real-Time Processing (Fargate, ElastiCache) | $1,500 - $5,000 | $3,000 |
| Critical API Gateway (multi-AZ, WAF) | $1,000 - $4,000 | $2,200 |

---

## Savings Plans and Reserved Instances

### Compute Savings Plans

| Term | Commitment | Savings vs On-Demand |
|------|-----------|---------------------|
| 1-year, no upfront | Hourly spend commitment | ~20% |
| 1-year, partial upfront | 50% upfront + hourly | ~25% |
| 1-year, all upfront | Full prepayment | ~30% |
| 3-year, no upfront | Hourly spend commitment | ~40% |
| 3-year, partial upfront | 50% upfront + hourly | ~50% |
| 3-year, all upfront | Full prepayment | ~60% |

**Applies to**: Fargate, Lambda, EC2 (if used).

### Aurora Reserved Instances

| Term | Savings vs On-Demand |
|------|---------------------|
| 1-year, no upfront | ~25% |
| 1-year, all upfront | ~35% |
| 3-year, all upfront | ~55% |

### ElastiCache Reserved Nodes

| Term | Savings vs On-Demand |
|------|---------------------|
| 1-year, no upfront | ~25% |
| 3-year, partial upfront | ~50% |
