# AWS Cost Optimization Patterns

Reference for the aws-cost-estimator skill. Strategies for reducing cloud
operating costs without degrading reliability or performance.

---

## Compute Optimization

### Fargate Spot for Non-Critical Workloads

**Savings**: 60-70% vs on-demand.

**Eligible workloads:**
- Batch processing tasks
- Dev and staging environments
- Asynchronous queue consumers
- Data transformation pipelines
- CI/CD build tasks

**Not eligible:**
- Production API services handling live user traffic
- Services with strict latency SLAs
- Singleton tasks that cannot tolerate interruption

**Implementation:**
- Set capacity provider strategy: `FARGATE_SPOT` as primary, `FARGATE` as fallback
- Use `capacityProviderStrategy` in ECS service definition
- Set fallback to on-demand at 20% base for HA during spot reclamation
- Design tasks for graceful shutdown (handle SIGTERM within 120s)

### Compute Savings Plans for Steady-State

**Savings**: 20-60% depending on term and payment option.

**Right-sizing the commitment:**
1. Analyze 30-day Fargate usage via Cost Explorer
2. Identify the baseline (minimum sustained usage, typically p10)
3. Commit to 70-80% of the baseline to allow for fluctuation
4. Cover the remainder with on-demand pricing

**Decision criteria:**
- Workload runs 24/7 with predictable minimum utilization: Savings Plan
- Workload is bursty with low baseline: stay on-demand
- Workload is new with unknown patterns: wait 90 days, then evaluate

### Lambda Right-Sizing

**Strategy**: Match memory allocation to actual usage.

1. Enable Lambda Power Tuning tool to profile functions
2. Target memory where cost-per-invocation is minimized (not necessarily lowest memory)
3. Higher memory allocates proportionally more CPU, reducing duration
4. The cost-optimal point is often 2-3x the minimum required memory

**Example**: A function that runs 500ms at 128 MB might run 150ms at
512 MB. Cost at 128 MB: $0.000001042. Cost at 512 MB: $0.000001250.
But at 1024 MB it runs 80ms: $0.000001333 (diminishing returns).

---

## Data Tier Optimization

### Aurora Serverless v2 for Variable Workloads

**Savings**: Scales to 0.5 ACU during idle periods (vs fixed provisioned instance).

**Best for:**
- Applications with distinct business-hours traffic patterns
- Dev/staging databases that are idle evenings and weekends
- Applications with unpredictable query volume

**Configuration:**
- Set `min_capacity` to 0.5 ACU for dev, 2 ACU for prod
- Set `max_capacity` based on peak load testing results
- Monitor ACU utilization via CloudWatch to right-size over time

**Not recommended when:**
- Workload is consistently high (provisioned instance is cheaper)
- Sub-second query latency is critical during cold start from minimum ACU

### DynamoDB Reserved Capacity

**Savings**: Up to 80% for provisioned mode with reserved capacity.

**Decision tree:**
- Read/write patterns are predictable and stable: use provisioned + reserved
- Patterns are spiky or unpredictable: use on-demand mode
- Patterns are predictable with occasional spikes: provisioned + auto-scaling

### S3 Intelligent-Tiering for Artifacts

**Savings**: Automatic transition between access tiers.

**Configuration:**
- Enable Intelligent-Tiering for artifact storage buckets
- Monitoring fee: $0.0025 per 1,000 objects (negligible for most workloads)
- Objects not accessed for 30 days move to Infrequent Access (45% savings)
- Objects not accessed for 90 days move to Archive Instant (68% savings)

**Lifecycle policy for known patterns:**
- Pipeline artifacts older than 90 days: transition to S3-IA
- Pipeline artifacts older than 365 days: transition to Glacier Instant Retrieval
- Pipeline artifacts older than 3 years: transition to Glacier Flexible Retrieval

---

## Networking Optimization

### VPC Endpoints to Avoid NAT Gateway Costs

**Savings**: Eliminates $0.045/GB NAT Gateway processing fee for
supported services.

**High-value endpoints:**
- S3 Gateway Endpoint (free, no per-GB charges)
- DynamoDB Gateway Endpoint (free, no per-GB charges)
- ECR Interface Endpoint (eliminates image pull NAT charges)
- CloudWatch Logs Interface Endpoint
- Secrets Manager Interface Endpoint

**Cost of interface endpoints**: $0.01/hour per AZ (~$7.30/month per AZ).
Break-even: ~162 GB/month of traffic to that service.

### Cross-AZ Traffic Reduction

**Strategy**: Minimize cross-AZ communication for chatty services.

- Co-locate tightly coupled services in the same AZ when possible
- Use AZ-affinity routing in the ALB for service-to-service calls
- Cache frequently accessed data locally (ElastiCache replica per AZ)
- Batch cross-AZ writes to reduce per-request overhead

**Caveat**: Do not sacrifice HA for cost savings. Always maintain
multi-AZ deployment for production workloads.

---

## Environment-Level Optimization

### Scheduled Scaling for Non-Production

**Savings**: 60-70% on dev/staging compute costs.

**Implementation:**
- Scale dev environments to zero tasks outside business hours (6 PM - 8 AM)
- Scale staging to zero on weekends
- Use AWS Application Auto Scaling scheduled actions
- Provide manual override mechanism for off-hours work

**Sample schedule:**

```yaml
dev_schedule:
  scale_up:    "cron(0 8 ? * MON-FRI *)"   # 8 AM ET weekdays
  scale_down:  "cron(0 18 ? * MON-FRI *)"  # 6 PM ET weekdays
  weekend:     "cron(0 18 ? * FRI *)"       # Scale down Friday 6 PM
  min_tasks:   0
  max_tasks:   1

staging_schedule:
  scale_up:    "cron(0 8 ? * MON-FRI *)"
  scale_down:  "cron(0 20 ? * MON-FRI *)"  # 8 PM ET weekdays
  weekend:     "cron(0 20 ? * FRI *)"
  min_tasks:   0
  max_tasks:   2
```

### Right-Sizing Non-Production Resources

| Resource | Production | Staging | Dev |
|----------|-----------|---------|-----|
| Fargate task size | Per architecture spec | 50% of prod | 25% of prod |
| Aurora ACU range | Per load test results | 0.5-4 ACU | 0.5-2 ACU |
| ElastiCache nodes | Per architecture spec | Single node | Single node |
| Replica count | Multi-AZ (2+) | Single AZ (1) | Single AZ (1) |

---

## Monitoring and Governance

### Cost Allocation Tags

Apply tags to all resources for per-application cost tracking:

```yaml
required_tags:
  - Key: Application
    Value: "{app_name}"
  - Key: Environment
    Value: "dev|staging|prod"
  - Key: CostCenter
    Value: "{cost_center_code}"
  - Key: Wave
    Value: "{wave_number}"
  - Key: RiskTier
    Value: "T1|T2|T3"
```

### Budget Alarms

Set AWS Budgets alarms per application:
- Warning at 80% of projected monthly cost
- Critical at 100% of projected monthly cost
- Anomaly detection enabled for unexpected spikes

### Monthly Cost Review Cadence

1. Compare actual vs estimated costs per application
2. Identify top 3 cost drivers per application
3. Review Savings Plan utilization (target >80% utilization)
4. Check for idle or underutilized resources
5. Update cost estimates for applications entering next wave

---

## Cost Optimization Checklist

- [ ] Fargate Spot enabled for eligible batch and non-production workloads
- [ ] Compute Savings Plan commitment sized to 70-80% of baseline utilization
- [ ] Lambda functions profiled and memory right-sized
- [ ] Aurora Serverless v2 used for variable workloads; provisioned for steady-state
- [ ] S3 lifecycle policies configured for artifact storage
- [ ] VPC endpoints deployed for S3, DynamoDB, ECR, CloudWatch Logs
- [ ] Non-production environments use scheduled scaling and reduced sizing
- [ ] Cost allocation tags applied to all resources
- [ ] Budget alarms configured per application
- [ ] Reserved capacity evaluated for DynamoDB and ElastiCache
