# Well-Architected Pillar: Operational Excellence

Reference checklist for the well-architected-reviewer skill.
Evaluate the architecture blueprint against these best practices.

---

## Pillar Summary

Operational Excellence focuses on running and monitoring systems to deliver
business value and continually improving supporting processes and procedures.

---

## Checklist

### Infrastructure as Code (IaC)

- [ ] All infrastructure defined in code (CloudFormation, CDK, or Terraform)
- [ ] No manual resource creation via console (except for initial account setup)
- [ ] IaC templates are parameterized for multi-environment deployment
- [ ] IaC is version-controlled alongside application code
- [ ] Drift detection is configured to alert on manual changes
- [ ] IaC modules are reusable across applications in the portfolio

**Scoring guide:**
- 1: No IaC; infrastructure created manually
- 3: IaC for core resources; some manual steps remain
- 5: 100% IaC with parameterized, reusable modules and drift detection

### CI/CD Pipeline

- [ ] Automated build pipeline triggered on code push
- [ ] Automated test execution (unit, integration, contract)
- [ ] Automated deployment to all environments (dev, staging, prod)
- [ ] Blue-green or rolling deployment strategy for zero-downtime releases
- [ ] Deployment rollback mechanism tested and documented
- [ ] Pipeline includes security scanning (SAST, dependency audit)
- [ ] Pipeline stages map to Olympus gates (build -> G-V1, deploy -> G-DP-1)

**Scoring guide:**
- 1: Manual build and deploy processes
- 3: Automated build and deploy; manual test or approval steps
- 5: Fully automated pipeline with zero-downtime deploy and tested rollback

### Monitoring and Observability

- [ ] Application metrics exported to CloudWatch (latency, error rate, throughput)
- [ ] Custom business metrics defined (transactions processed, jobs completed)
- [ ] Structured logging in JSON format to CloudWatch Logs
- [ ] Distributed tracing enabled (X-Ray or equivalent)
- [ ] Container Insights enabled for Fargate tasks
- [ ] Centralized dashboard for application health overview
- [ ] Log retention policy configured (30 days minimum, 90 days recommended)

**Scoring guide:**
- 1: No monitoring beyond default CloudWatch metrics
- 3: Custom metrics and structured logging; no tracing
- 5: Full observability: metrics, logs, traces, dashboards, business metrics

### Runbooks and Standard Operating Procedures

- [ ] Runbook exists for common operational tasks (deploy, rollback, scale, restart)
- [ ] Runbook exists for incident response (detection, triage, escalation, resolution)
- [ ] Runbooks are versioned and stored alongside application documentation
- [ ] On-call rotation defined with escalation paths
- [ ] Runbooks tested via tabletop exercises at least quarterly

**Scoring guide:**
- 1: No operational documentation
- 3: Runbooks exist for deploy and incident response but untested
- 5: Comprehensive runbooks tested quarterly with defined on-call rotation

### Incident Response

- [ ] Alerting configured for P1 conditions (service down, error rate spike, latency breach)
- [ ] Alert routing to appropriate team (SNS, PagerDuty, or equivalent)
- [ ] Incident classification criteria defined (P1/P2/P3)
- [ ] Post-incident review process documented
- [ ] Mean Time to Detect (MTTD) target defined
- [ ] Mean Time to Recover (MTTR) target defined

**Scoring guide:**
- 1: No alerting configured; incidents discovered by users
- 3: Alerts for critical conditions; incident process exists but informal
- 5: Comprehensive alerting with automated routing, classification, and post-mortem process

### Post-Mortems and Continuous Improvement

- [ ] Blameless post-mortem process defined
- [ ] Post-mortem template includes timeline, root cause, action items
- [ ] Action items tracked to completion
- [ ] Recurring issues trigger architectural review
- [ ] Operational metrics reviewed monthly (MTTD, MTTR, deployment frequency)

**Scoring guide:**
- 1: No post-mortem process; same incidents recur
- 3: Post-mortems conducted for major incidents; action items sometimes tracked
- 5: Blameless post-mortems for all incidents with tracked action items and trend analysis

### Feature Flags and Progressive Delivery

- [ ] Feature flag system identified (LaunchDarkly, AWS AppConfig, or custom)
- [ ] Strategy for dark launches and canary releases defined
- [ ] Rollback via feature flag (disable feature without redeploy)
- [ ] Flag lifecycle management (cleanup of stale flags)

**Scoring guide:**
- 1: No feature flag capability; all changes are all-or-nothing deploys
- 3: Feature flags available but not consistently used
- 5: Feature flags integrated into deployment strategy with lifecycle management

---

## Evidence Sources in Blueprint

Look for evidence in these blueprint sections:
- Section 10 (Deployment Topology): CI/CD pipeline, deployment strategy
- Section 8 (Observability Design): Monitoring, logging, tracing, alerting
- Section 9 (Resilience Design): Incident response, recovery procedures
