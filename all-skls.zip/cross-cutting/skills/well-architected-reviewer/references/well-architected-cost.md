# Well-Architected Pillar: Cost Optimization

Reference checklist for the well-architected-reviewer skill.
Evaluate the architecture blueprint against these best practices.

---

## Pillar Summary

Cost Optimization focuses on avoiding unnecessary costs, understanding
spending, selecting the most appropriate resource types, analyzing spending
over time, and scaling to meet business needs without overspending.

---

## Checklist

### Right-Sizing

- [ ] Compute resources sized based on actual or estimated workload requirements (not oversized "just in case")
- [ ] Right-sizing review planned after 30 days of production metrics
- [ ] Container Insights enabled to track actual CPU and memory utilization
- [ ] Non-production environments use smaller resource configurations than production
- [ ] Unused or idle resources identified and scheduled for cleanup
- [ ] Graviton (ARM) considered for Fargate tasks (20% better price-performance)

**Scoring guide:**
- 1: Resources oversized with no plan to right-size; no utilization monitoring
- 3: Initial sizing based on estimates; right-sizing review planned but not automated
- 5: Data-driven sizing with automated recommendations and scheduled reviews

### Savings Plans and Reserved Capacity

- [ ] Compute Savings Plan evaluated for steady-state workloads
- [ ] Commitment sized at 70-80% of baseline utilization (not peak)
- [ ] Term and payment option selected based on workload stability and budget
- [ ] Reserved capacity evaluated for Aurora and ElastiCache (if provisioned)
- [ ] DynamoDB reserved capacity evaluated (if provisioned mode)
- [ ] Savings Plan utilization monitored (target > 80%)

**Scoring guide:**
- 1: All on-demand pricing with no savings plan evaluation
- 3: Savings Plan identified as an option but not committed or sized
- 5: Savings Plan committed, sized to baseline, and utilization monitored

### Spot and Preemptible Usage

- [ ] Fargate Spot evaluated for batch, dev/staging, and async workloads
- [ ] Spot strategy includes on-demand fallback (capacity provider strategy)
- [ ] Workloads designed for graceful interruption (handle SIGTERM)
- [ ] Spot savings quantified in cost estimate

**Scoring guide:**
- 1: No Spot usage; all workloads on-demand including batch
- 3: Spot identified as opportunity but not implemented in architecture
- 5: Spot integrated for eligible workloads with fallback and savings quantified

### Lifecycle Policies

- [ ] S3 lifecycle policies configured for artifact and log storage
- [ ] Old artifacts transition to cheaper storage classes (IA, Glacier)
- [ ] Log retention policies set (30-90 days in CloudWatch, archive to S3)
- [ ] Database snapshot retention policy defined (balance cost vs recovery needs)
- [ ] ECR image lifecycle policy (retain last N images, expire untagged)

**Scoring guide:**
- 1: No lifecycle policies; all data retained in hot storage indefinitely
- 3: Some lifecycle policies configured but not comprehensive
- 5: Lifecycle policies on all storage with documented retention rationale

### Unused Resource Detection

- [ ] Process defined for identifying unused resources (unattached EBS volumes, idle NAT Gateways, orphan security groups)
- [ ] AWS Trusted Advisor or Cost Explorer anomaly detection enabled
- [ ] Monthly review cadence for resource cleanup
- [ ] Tagging enforcement ensures all resources are attributable

**Scoring guide:**
- 1: No process for identifying unused resources
- 3: Periodic manual review; some unused resources known but not cleaned up
- 5: Automated detection with monthly cleanup cadence and tagging enforcement

### Cost Allocation Tags

- [ ] Tagging strategy defined (Application, Environment, CostCenter, Wave, RiskTier)
- [ ] Tag enforcement policy configured (AWS Config rule or SCP)
- [ ] Cost allocation tags activated in AWS Billing
- [ ] Per-application and per-environment cost reporting enabled
- [ ] Tags applied consistently across all resource types

**Scoring guide:**
- 1: No tagging strategy; costs not attributable to applications
- 3: Tags defined but not enforced; some resources untagged
- 5: Enforced tagging with activated cost allocation and per-app reporting

### Budget Alarms

- [ ] AWS Budgets configured per application or cost center
- [ ] Warning alarm at 80% of projected monthly cost
- [ ] Critical alarm at 100% of projected monthly cost
- [ ] Anomaly detection enabled for unexpected cost spikes
- [ ] Budget review cadence defined (monthly)
- [ ] Escalation path defined for budget breaches

**Scoring guide:**
- 1: No budgets or alarms configured
- 3: Budget defined but no alarms or anomaly detection
- 5: Budgets with tiered alarms, anomaly detection, and escalation process

---

## Evidence Sources in Blueprint

Look for evidence in these blueprint sections:
- Section 12 (Cost Estimate): Service costs, savings applied, TCO comparison
- Section 4 (Compute Tier Design): Sizing rationale, scaling configuration
- Section 5 (Data Tier Design): Storage lifecycle, capacity mode selection
- Section 10 (Deployment Topology): Environment sizing, scheduled scaling
