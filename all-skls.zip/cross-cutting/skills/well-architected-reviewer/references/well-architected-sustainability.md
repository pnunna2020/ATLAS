# Well-Architected Pillar: Sustainability

Reference checklist for the well-architected-reviewer skill.
Evaluate the architecture blueprint against these best practices.

---

## Pillar Summary

Sustainability focuses on minimizing the environmental impact of running
cloud workloads. This includes maximizing utilization, adopting efficient
hardware and software, reducing the provisioned resources needed, and
selecting regions and services with lower carbon intensity.

---

## Checklist

### Serverless-First Design

- [ ] Serverless services preferred where workload characteristics align (Lambda for event processing, Step Functions for orchestration)
- [ ] Fargate used instead of EC2 to eliminate idle server overhead
- [ ] Managed services preferred over self-hosted alternatives (Aurora over self-managed PostgreSQL, ElastiCache over self-managed Redis)
- [ ] Serverless design reduces over-provisioning by scaling to exact demand
- [ ] Batch processing uses Lambda or Fargate Spot to avoid long-running idle compute

**Scoring guide:**
- 1: Self-hosted services on oversized EC2 instances
- 3: Mix of managed and self-hosted; Fargate used but some EC2 remains
- 5: Serverless-first with managed services; compute scales to zero when idle

### Fargate Spot for Eligible Workloads

- [ ] Fargate Spot used for fault-tolerant workloads (batch, dev, async processing)
- [ ] Spot capacity reduces overall compute footprint by reusing spare capacity
- [ ] Spot usage quantified as percentage of total compute hours
- [ ] Graceful shutdown configured to avoid wasted partial work on spot reclamation

**Scoring guide:**
- 1: No Spot usage; all workloads on dedicated on-demand compute
- 3: Spot identified as opportunity but not yet configured
- 5: Spot used for all eligible workloads; percentage of Spot compute tracked

### S3 Intelligent-Tiering and Lifecycle

- [ ] S3 Intelligent-Tiering enabled for artifact storage with unpredictable access patterns
- [ ] Lifecycle policies transition cold data to IA and Glacier tiers
- [ ] Infrequently accessed data not stored in hot storage tier
- [ ] Storage class selection based on access frequency analysis (not default to Standard)

**Scoring guide:**
- 1: All data in S3 Standard regardless of access pattern
- 3: Lifecycle policies configured but no Intelligent-Tiering
- 5: Intelligent-Tiering for variable access; lifecycle policies for known patterns

### Compute Efficiency

- [ ] Graviton (ARM) processors evaluated for Fargate tasks (20% better energy efficiency per unit of compute)
- [ ] Lambda functions right-sized to minimize wasted allocated memory
- [ ] Container images optimized (multi-stage builds, minimal base images) to reduce build and pull overhead
- [ ] Unnecessary background processes eliminated from container images
- [ ] Cold start optimization for Lambda (SnapStart for Java, provisioned concurrency only where needed)

**Scoring guide:**
- 1: Oversized compute with unoptimized container images
- 3: Some optimization (right-sized Lambda, smaller images) but Graviton not evaluated
- 5: Graviton where possible, optimized images, right-sized functions, minimal waste

### Region Selection

- [ ] Region selected based on data residency requirements, latency, and service availability
- [ ] GovCloud region used for compliance (required for FAA)
- [ ] Single-region deployment where possible to minimize cross-region data transfer
- [ ] Multi-region only when required by DR/RTO requirements (T1 applications)

**Scoring guide:**
- 1: Region selection not documented; unclear rationale
- 3: GovCloud selected for compliance; no discussion of alternatives
- 5: Region selection documented with rationale covering compliance, latency, and carbon impact

### Managed Services

- [ ] Managed services preferred over self-hosted for operational efficiency
- [ ] Aurora Serverless v2 auto-scales compute (no over-provisioned database instances)
- [ ] ElastiCache managed (AWS handles patching, failover, backups)
- [ ] CloudWatch and X-Ray for observability (no self-hosted monitoring stack)
- [ ] Secrets Manager and KMS (no self-managed secret storage)

**Scoring guide:**
- 1: Self-hosted alternatives used when managed services are available
- 3: Most services managed; one or two self-hosted components remain
- 5: All services use AWS managed offerings; zero self-hosted infrastructure

---

## Evidence Sources in Blueprint

Look for evidence in these blueprint sections:
- Section 3 (Cloud Service Selection): Managed vs self-hosted choices
- Section 4 (Compute Tier Design): Fargate vs EC2, Graviton, container optimization
- Section 5 (Data Tier Design): Aurora Serverless vs provisioned, storage tiering
- Section 10 (Deployment Topology): Region selection, environment sizing
- Section 12 (Cost Estimate): Spot usage, scheduled scaling
