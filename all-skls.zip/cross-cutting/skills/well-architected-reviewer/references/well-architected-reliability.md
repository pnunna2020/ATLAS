# Well-Architected Pillar: Reliability

Reference checklist for the well-architected-reviewer skill.
Evaluate the architecture blueprint against these best practices.

---

## Pillar Summary

Reliability focuses on the ability of a workload to perform its intended
function correctly and consistently. This includes the ability to operate
and test the workload through its lifecycle, recover from failures, and
meet demand.

---

## Checklist

### Multi-AZ Deployment

- [ ] All production services deployed across at least 2 Availability Zones
- [ ] Load balancer distributes traffic across AZs
- [ ] Database configured for Multi-AZ (Aurora multi-AZ cluster or read replicas across AZs)
- [ ] ElastiCache configured for multi-AZ with automatic failover (if used)
- [ ] NAT Gateways deployed in each AZ (no single AZ dependency for outbound traffic)
- [ ] Stateless application tier (no AZ-affinity for user sessions)

**Scoring guide:**
- 1: Single-AZ deployment; single point of failure
- 3: Multi-AZ for compute but single-AZ for data tier
- 5: Full multi-AZ across all tiers with no single-AZ dependencies

### Auto-Scaling

- [ ] Auto-scaling configured for compute tier (Fargate service auto-scaling or Lambda concurrency)
- [ ] Scaling metric appropriate for workload (CPU, memory, request count, or custom metric)
- [ ] Scale-out threshold set to prevent degradation under load (target 60-70% utilization)
- [ ] Scale-in threshold set to prevent flapping (cooldown periods configured)
- [ ] Minimum task count >= 2 for production (HA baseline)
- [ ] Maximum capacity tested via load test to confirm it handles peak

**Scoring guide:**
- 1: Fixed capacity; no auto-scaling
- 3: Auto-scaling configured but not load-tested; thresholds are defaults
- 5: Auto-scaling with tuned thresholds validated by load testing

### Health Checks

- [ ] ALB health check configured with appropriate path, interval, and thresholds
- [ ] Health check endpoint verifies application readiness (not just TCP connectivity)
- [ ] Deep health check includes downstream dependency status (database, cache, external services)
- [ ] Unhealthy targets automatically deregistered and replaced
- [ ] Health check distinguishes between liveness (process running) and readiness (ready to serve)

**Scoring guide:**
- 1: No health checks or TCP-only checks
- 3: HTTP health check on a simple endpoint; no dependency verification
- 5: Deep health checks with liveness/readiness separation and dependency verification

### Circuit Breakers and Bulkheads

- [ ] Circuit breaker pattern implemented for all external service calls
- [ ] Circuit breaker thresholds defined: error rate %, timeout, half-open retry interval
- [ ] Fallback behavior defined when circuit is open (cached response, degraded mode, error message)
- [ ] Bulkhead pattern isolates failure domains (separate thread pools or connection pools per integration)
- [ ] Timeout configured for all outbound calls (no indefinite waits)

**Scoring guide:**
- 1: No circuit breakers; cascading failures likely
- 3: Timeouts configured but no circuit breaker pattern; no fallback behavior
- 5: Circuit breakers with fallbacks on all external calls; bulkhead isolation

### Dead Letter Queues (DLQ)

- [ ] DLQ configured for all SQS queues
- [ ] DLQ configured for all Lambda event source mappings
- [ ] DLQ alarm configured to alert when messages arrive
- [ ] DLQ message inspection process documented (how to investigate and reprocess)
- [ ] Maximum receive count set before DLQ routing (typically 3-5 retries)
- [ ] DLQ retention period sufficient for investigation (14 days recommended)

**Scoring guide:**
- 1: No DLQs; failed messages are silently lost
- 3: DLQs configured but no alerting or reprocessing procedure
- 5: DLQs with alerting, documented investigation process, and reprocessing capability

### Backup and Restore

- [ ] Database backup strategy defined (automated snapshots, retention period)
- [ ] Point-in-time recovery enabled for Aurora (35-day retention recommended)
- [ ] S3 versioning enabled for critical data buckets
- [ ] Backup restoration tested and recovery time documented
- [ ] Cross-region backup for T1 applications (if multi-region DR required)
- [ ] Backup encryption matches source encryption (same KMS key or cross-region replica key)

**Scoring guide:**
- 1: No backup strategy defined; reliance on provider defaults
- 3: Automated backups enabled with default retention; restoration untested
- 5: Defined backup strategy with tested restoration, PITR, and cross-region for T1

### Chaos Testing and Resilience Validation

- [ ] Resilience testing strategy defined (chaos engineering, game days, or fault injection)
- [ ] AZ failure scenario tested (or planned for pre-production validation)
- [ ] Service failure scenario tested (database unavailable, cache miss, external service timeout)
- [ ] Recovery automation verified (auto-scaling responds, health checks deregister, circuit breakers trip)
- [ ] RTO/RPO compliance validated through testing, not just design

**Scoring guide:**
- 1: No resilience testing planned
- 3: Resilience testing planned but not yet executed; theoretical RTO/RPO
- 5: Resilience testing executed with documented results confirming RTO/RPO compliance

### RTO/RPO Compliance

- [ ] RTO (Recovery Time Objective) documented and achievable with current architecture
- [ ] RPO (Recovery Point Objective) documented and achievable with current backup strategy
- [ ] RTO/RPO requirements aligned with risk tier expectations
- [ ] Failover procedure documented and tested

**Tier expectations:**
| Tier | Typical RTO | Typical RPO |
|------|-------------|-------------|
| T1 | <= 15 minutes | <= 5 minutes |
| T2 | <= 1 hour | <= 15 minutes |
| T3 | <= 4 hours | <= 1 hour |

**Scoring guide:**
- 1: RTO/RPO not defined; recovery strategy unclear
- 3: RTO/RPO defined but not validated through testing
- 5: RTO/RPO defined, architecture supports them, and testing confirms compliance

---

## Evidence Sources in Blueprint

Look for evidence in these blueprint sections:
- Section 9 (Resilience Design): HA, DR, failover matrix, circuit breakers
- Section 4 (Compute Tier Design): Scaling strategy, minimum capacity
- Section 5 (Data Tier Design): Backup, replication, multi-AZ configuration
- Section 10 (Deployment Topology): AZ distribution, VPC design
