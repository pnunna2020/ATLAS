# Well-Architected Pillar: Security

Reference checklist for the well-architected-reviewer skill.
Evaluate the architecture blueprint against these best practices.

---

## Pillar Summary

Security focuses on protecting information, systems, and assets while
delivering business value through risk assessments and mitigation strategies.
For FAA applications, security has a higher minimum bar than other pillars.

---

## Checklist

### Zero Trust Architecture

- [ ] Microsegmentation implemented: each service has its own security group with deny-by-default rules
- [ ] No service-to-service communication over public internet
- [ ] All internal communication uses mTLS or equivalent mutual authentication
- [ ] Network paths restricted to only required communication flows
- [ ] VPC endpoints used for AWS service access (no NAT Gateway for AWS API calls where possible)
- [ ] Private subnets used for all application and data tier resources

**Scoring guide:**
- 1: Flat network with shared security groups; no microsegmentation
- 3: Security groups per service but no mTLS; some services in public subnets
- 5: Full microsegmentation, mTLS everywhere, private subnets only, VPC endpoints

### Encryption

- [ ] Encryption at rest enabled for all data stores (Aurora, DynamoDB, S3, ElastiCache)
- [ ] KMS customer-managed keys used (not AWS-managed keys) for T1 and T2 applications
- [ ] Key rotation enabled (annual minimum, quarterly for T1)
- [ ] Encryption in transit via TLS 1.2+ for all communications
- [ ] mTLS for service-to-service communication
- [ ] S3 bucket policies enforce encryption on upload (deny unencrypted PutObject)

**Scoring guide:**
- 1: No encryption at rest; HTTP used for some communications
- 3: AWS-managed encryption at rest; TLS in transit but no mTLS
- 5: CMK encryption at rest with rotation, TLS 1.2+ everywhere, mTLS for internal

### IAM and Least Privilege

- [ ] Task-level IAM roles for Fargate (not shared roles across services)
- [ ] IAM policies scoped to minimum required actions and resources
- [ ] No wildcard (*) permissions in IAM policies
- [ ] IAM permission boundaries applied to service roles
- [ ] Cross-account access uses IAM roles, not access keys
- [ ] Service control policies (SCPs) enforce guardrails at the OU level

**Scoring guide:**
- 1: Shared admin role for all services; wildcard permissions
- 3: Per-service roles but some broad permissions; no permission boundaries
- 5: Minimal-privilege per-service roles with boundaries and no wildcards

### Web Application Firewall (WAF)

- [ ] WAF deployed on ALB or CloudFront for public-facing services
- [ ] AWS Managed Rules enabled (common rule set, known bad inputs, SQL injection, XSS)
- [ ] Rate limiting rules configured per client/API key
- [ ] Custom rules for application-specific attack patterns
- [ ] WAF logging enabled to CloudWatch or S3 for incident investigation
- [ ] Bot control enabled for public-facing endpoints (if applicable)

**Scoring guide:**
- 1: No WAF; application directly exposed to internet
- 3: WAF with managed rules but no custom rules or rate limiting
- 5: WAF with managed + custom rules, rate limiting, logging, and bot control

### Security Logging and Monitoring

- [ ] CloudTrail enabled for all API calls (management and data events)
- [ ] VPC Flow Logs enabled for network traffic analysis
- [ ] GuardDuty enabled for threat detection
- [ ] Security Hub aggregates findings from GuardDuty, Inspector, and Config
- [ ] Log retention meets compliance requirements (1 year minimum for audit)
- [ ] Alert on security-relevant events: unauthorized access attempts, privilege escalation, resource changes

**Scoring guide:**
- 1: No security-specific logging; only default CloudWatch
- 3: CloudTrail and VPC Flow Logs enabled but no threat detection or alerting
- 5: Full security monitoring stack with threat detection, aggregation, and alerting

### Secrets Management

- [ ] All secrets stored in AWS Secrets Manager or CyberArk (never in code, config files, or environment variables)
- [ ] Secret rotation enabled with automatic rotation schedule
- [ ] Application retrieves secrets at runtime, not at build time
- [ ] Secrets access audited via CloudTrail
- [ ] Database credentials managed via Secrets Manager with automatic rotation
- [ ] API keys and tokens stored as secrets, not hardcoded

**Scoring guide:**
- 1: Secrets in code or config files; no rotation
- 3: Secrets in Secrets Manager but no rotation; some config file secrets remain
- 5: All secrets in Secrets Manager/CyberArk with rotation, runtime retrieval, and audit trail

### Vulnerability Scanning

- [ ] Container image scanning enabled in ECR (scan on push)
- [ ] Dependency vulnerability scanning in CI/CD pipeline (npm audit, pip-audit, or equivalent)
- [ ] SAST tool integrated into CI/CD pipeline
- [ ] DAST tool run against staging environment before production promotion
- [ ] Inspector enabled for runtime vulnerability detection
- [ ] Remediation SLA defined: critical within 24h, high within 7 days

**Scoring guide:**
- 1: No vulnerability scanning
- 3: Container scanning enabled; no SAST/DAST integration
- 5: Full scanning pipeline (container, dependency, SAST, DAST, runtime) with remediation SLAs

---

## Evidence Sources in Blueprint

Look for evidence in these blueprint sections:
- Section 7 (Identity and Authorization Design): Authentication, authorization, mTLS
- Section 11 (Security Architecture): Network security, encryption, Zero Trust, compliance seeds
- Section 10 (Deployment Topology): VPC design, security groups, private subnets
- Section 3 (Cloud Service Selection): Security-relevant service choices (KMS, WAF, Secrets Manager)
