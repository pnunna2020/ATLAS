# Well-Architected Pillar: Performance Efficiency

Reference checklist for the well-architected-reviewer skill.
Evaluate the architecture blueprint against these best practices.

---

## Pillar Summary

Performance Efficiency focuses on the efficient use of computing resources
to meet requirements and maintaining that efficiency as demand changes
and technologies evolve.

---

## Checklist

### Right-Sized Compute

- [ ] Fargate task sizes based on profiling data or informed estimates (not arbitrary)
- [ ] Lambda memory allocation tuned for cost/performance balance (not default 128 MB)
- [ ] Compute configuration documented with rationale for sizing choices
- [ ] Vertical scaling path identified if horizontal scaling reaches limits
- [ ] Graviton (ARM) instances considered for Fargate (20% better price-performance)
- [ ] Right-sizing review planned post-launch using Container Insights data

**Scoring guide:**
- 1: Default or arbitrary sizing with no justification
- 3: Sizing based on estimates; review planned but not automated
- 5: Sizing based on profiling/benchmarks with automated right-sizing recommendations

### Caching Strategy

- [ ] Caching layer identified for frequently accessed, slowly changing data
- [ ] Cache strategy selected (cache-aside, write-through, or write-behind) with justification
- [ ] TTL policy defined per data type (not a single global TTL)
- [ ] Cache invalidation strategy defined (time-based, event-based, or explicit)
- [ ] Cache hit ratio target defined (typically > 80%)
- [ ] Cache warm-up strategy for cold starts (if applicable)

**Scoring guide:**
- 1: No caching; every request hits the database
- 3: ElastiCache deployed with single TTL; no invalidation strategy
- 5: Multi-layer caching with per-type TTL, invalidation strategy, and hit ratio monitoring

### Content Delivery (CDN)

- [ ] Static assets served via CloudFront (not directly from Fargate/S3)
- [ ] Cache-Control headers configured for static assets (long TTL for versioned assets)
- [ ] Origin shield enabled to reduce origin load (if applicable)
- [ ] Custom error pages configured for CDN-level errors
- [ ] Geographic restrictions applied if required (GovCloud / CONUS-only)

**Scoring guide:**
- 1: No CDN; static assets served from application servers
- 3: CloudFront configured but cache headers not optimized
- 5: CloudFront with optimized cache policy, origin shield, and geographic controls

### Connection Pooling

- [ ] Database connection pooling configured (RDS Proxy, PgBouncer, or application-level)
- [ ] Pool size tuned for expected concurrency (not default)
- [ ] Connection timeout and idle timeout configured
- [ ] Connection pool metrics monitored (active, idle, waiting connections)
- [ ] Pool exhaustion alerts configured

**Scoring guide:**
- 1: No connection pooling; new connection per request
- 3: Connection pooling enabled with default settings
- 5: Tuned connection pool with monitoring, alerting, and documented sizing rationale

### Asynchronous Processing

- [ ] Long-running operations offloaded to async processing (SQS, Step Functions, EventBridge)
- [ ] Request-response pattern used only for operations completing within SLA (typically < 3s)
- [ ] Async operations provide status polling or webhook notification
- [ ] Batch operations use Step Functions or SQS for fan-out, not synchronous loops
- [ ] File processing uses S3 event triggers, not polling

**Scoring guide:**
- 1: All operations synchronous; long-running requests block threads
- 3: Some async processing but inconsistent; some long operations still synchronous
- 5: Clear sync/async boundary; all long operations async with status tracking

### Database Optimization

- [ ] Indexing strategy defined for primary query patterns
- [ ] Query performance baseline established (or planned for post-migration)
- [ ] Read replicas considered for read-heavy workloads
- [ ] Database query patterns avoid N+1 queries
- [ ] Pagination implemented for large result sets (not unbounded queries)
- [ ] Aurora Serverless v2 auto-scaling configured for variable workloads

**Scoring guide:**
- 1: No indexing strategy; default schema deployed
- 3: Primary indexes defined; query optimization planned but not profiled
- 5: Comprehensive indexing, query profiling, read replicas where needed, pagination enforced

### Load Testing

- [ ] Load testing strategy defined (tool, scenarios, target metrics)
- [ ] Performance SLAs defined (p50, p95, p99 latency targets)
- [ ] Load test covers expected peak traffic (not just average)
- [ ] Load test validates auto-scaling behavior (scale-out and scale-in)
- [ ] Performance regression testing integrated into CI/CD (or planned)
- [ ] Baseline performance documented for future comparison

**Scoring guide:**
- 1: No load testing planned
- 3: Load testing planned with defined scenarios but not yet executed
- 5: Load testing executed with documented results confirming SLA compliance

---

## Evidence Sources in Blueprint

Look for evidence in these blueprint sections:
- Section 4 (Compute Tier Design): Task sizing, scaling strategy, container architecture
- Section 5 (Data Tier Design): Database configuration, caching, connection pooling
- Section 6 (Integration Tier Design): Async patterns, event-driven design
- Section 3 (Cloud Service Selection): CDN, caching service choices
