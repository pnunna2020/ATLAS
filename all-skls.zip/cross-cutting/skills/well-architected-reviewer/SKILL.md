---
name: well-architected-reviewer
description: >
  Evaluate the assembled architecture blueprint against the AWS Well-Architected
  Framework's six pillars. Score each pillar 1-5 with evidence, identify top
  risks, and produce a review report. Used after blueprint assembly (Step 6)
  and before gate G-02. Triggers on well-architected review, pillar scoring,
  architecture quality, or WAR mentions.
agent: opus
allowed-tools:
  - Read
  - Write
  - Grep
---

# Well-Architected Reviewer

## Purpose
Provide a structured quality assessment of the architecture blueprint using
the AWS Well-Architected Framework as the evaluation lens. This produces
pillar scores that inform gate G-02 decisions and highlight risks that
should be addressed before modernization begins.

## Inputs
- Assembled architecture blueprint (blueprint-assembler output)
- Application risk tier (T1/T2/T3)
- RTO/RPO requirements
- Client EA standards from active profile

## Outputs
- Well-Architected review report (from `assets/well-architected-review-template.md`)
- Pillar scores (1-5 each with evidence)
- Top 3 risks per pillar
- Recommendations and action items
- Radar chart data for visualization

## Methodology
1. Load the assembled architecture blueprint
2. For each of the 6 pillars, evaluate against the best-practice checklist from the corresponding reference file:
   - `references/well-architected-ops-excellence.md`
   - `references/well-architected-security.md`
   - `references/well-architected-reliability.md`
   - `references/well-architected-performance.md`
   - `references/well-architected-cost.md`
   - `references/well-architected-sustainability.md`
3. Score each pillar 1-5, citing specific evidence from the blueprint
4. For each pillar, identify the top 3 risks with severity and recommended mitigations
5. Calculate weighted overall score
6. Produce the review report with all scores, evidence, and recommendations

## Scoring Scale
| Score | Label | Meaning |
|-------|-------|---------|
| 1 | Critical gaps | Fundamental best practices missing; high risk of failure |
| 2 | Significant gaps | Several important practices missing; moderate risk |
| 3 | Adequate | Core practices present but improvements needed |
| 4 | Strong | Most best practices followed; minor improvements possible |
| 5 | Exemplary | All best practices followed with evidence; production-ready |

## Tier-Adjusted Expectations
| Tier | Minimum Acceptable Average | Security Pillar Minimum |
|------|---------------------------|------------------------|
| T1 | 4.0 | 4.5 |
| T2 | 3.5 | 4.0 |
| T3 | 3.0 | 3.5 |

## Gotchas
- **Score with evidence, not opinion**: Every score must cite a specific
  section or design element in the blueprint. "This looks good" is not
  evidence. "Section 9 defines multi-AZ with automatic failover and 15-minute
  RTO" is evidence.
- **Security pillar has a higher bar**: For T1 applications, the security
  pillar minimum is 4.5. A blueprint with perfect scores elsewhere but a
  3 on security fails the review.
- **Don't penalize N/A items**: If a checklist item is genuinely not applicable
  (e.g., "CDN configuration" for an internal-only batch job), mark it N/A
  rather than scoring it as missing.
- **Risk-tier awareness**: A Tier 3 application does not need the same depth
  of DR design as a Tier 1 application. Score relative to the tier's
  requirements, not an absolute standard.

## Quality Rules
- [ ] All 6 pillars are scored with evidence citations from the blueprint
- [ ] Each score cites specific blueprint sections, not generic assessments
- [ ] Top 3 risks identified per pillar with severity and recommended mitigation
- [ ] Security pillar score meets tier-adjusted minimum (T1: 4.5, T2: 4.0, T3: 3.5)
- [ ] Overall weighted average meets tier-adjusted minimum (T1: 4.0, T2: 3.5, T3: 3.0)
- [ ] N/A items are marked as such and excluded from scoring, not counted as gaps

## Common Failure Modes
| Failure Mode | Symptom | Prevention |
|-------------|---------|------------|
| Unsupported scores | Pillar scored 4 but no evidence cited; reviewer cannot verify | Require blueprint section reference for every score |
| Tier-blind scoring | T3 app scored against T1 standards; fails unnecessarily | Load risk tier and apply tier-adjusted expectations |
| Missing pillar | Sustainability pillar omitted because reviewer forgot it | Use checklist from all 6 reference files; validate completeness |
| Inflated security score | Security scored 4.5 but WAF rules not defined; false confidence | Cross-check security score against the full security checklist |

## Handoff Summary
When this skill completes, verify:
1. All 6 pillars scored with evidence
2. Security pillar meets tier-adjusted minimum
3. Overall score meets tier-adjusted minimum
4. Top risks have actionable mitigations
Then proceed to: gate `G-02` for architecture review with the Well-Architected report as supporting evidence, and `blueprint-assembler` to include scores in Section 15 of the blueprint
