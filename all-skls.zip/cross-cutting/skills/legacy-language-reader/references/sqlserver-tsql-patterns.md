# SQL Server T-SQL Code Patterns — Dispatch Shim

## Purpose
Local dispatch shim for T-SQL source (stored procedures, functions, triggers, SSIS script tasks). Authoritative reference: `cross-cutting/skills/extraction/references/sqlserver-tsql-patterns.md`. For instance- and integration-level view see the sibling `sqlserver-patterns.md` shim.

## Key Constructs
- **Stored program units**: `CREATE PROCEDURE ... AS BEGIN ... END`, `CREATE FUNCTION` (scalar, inline TVF, multi-statement TVF), `CREATE TRIGGER` (AFTER, INSTEAD OF), CLR assemblies (`CREATE ASSEMBLY`).
- **Control flow**: `BEGIN ... END`, `IF ... ELSE`, `WHILE`, `TRY ... CATCH`, `RAISERROR`/`THROW`, `GOTO` labels in older code.
- **Query idioms**: `WITH (NOLOCK)` locking hints, `NVARCHAR`/`NCHAR` Unicode types, `MERGE` statements, window functions, `CROSS APPLY`/`OUTER APPLY`, table variables and temp tables (`@t` vs. `#t`).
- **Dialect markers distinguishing from Oracle**: `GETDATE()` vs. `SYSDATE`, `ISNULL()` vs. `NVL`, `TOP n` vs. `ROWNUM`, `IDENTITY` vs. sequences, `@@IDENTITY`/`SCOPE_IDENTITY()`.
- **SSIS script tasks**: C# or VB.NET code embedded in `.dtsx` Script Tasks/Components.

## Detection Signals (two minimum)
1. `.sql` files with T-SQL-only constructs (`CREATE PROCEDURE ... AS BEGIN`, `NVARCHAR`, `NOLOCK`).
2. `GO` batch separators between statements.
3. `USE [database];` statement at script top.
4. Vendor tooling metadata: Redgate SQL Source Control, SSDT `.sqlproj` projects.

## Typical Modernization Targets
- Rewrite to PostgreSQL PL/pgSQL (or keep as-is on Babelfish-compatible Aurora).
- Move procedural logic to the application tier (Java/Python/Node services); keep set-based SQL in the database.
- Replace `MERGE` with INSERT ... ON CONFLICT (PostgreSQL) or explicit upsert procedures.
- Convert scalar UDFs to inline TVFs (SQL Server 2019+) for performance before any cross-engine port.

## Citations
- Microsoft Learn, "Transact-SQL reference" — https://learn.microsoft.com/en-us/sql/t-sql/
- Microsoft Learn, "SQL Server Data Tools (SSDT)" — https://learn.microsoft.com/en-us/sql/ssdt/
- AWS, "Schema Conversion Tool (SCT) T-SQL -> PL/pgSQL" — https://docs.aws.amazon.com/SchemaConversionTool/
- In-repo companion: `cross-cutting/skills/extraction/references/sqlserver-tsql-patterns.md`.
