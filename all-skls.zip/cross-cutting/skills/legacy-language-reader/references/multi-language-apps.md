# Multi-Language Apps

Most enterprise legacy apps are polyglot. Never collapse to a single primary when two independent codebases exist side-by-side.

## Common combinations

| Combination | Detection signal | Dispatch rows |
|---|---|---|
| .NET WebForms + PL/SQL | `Web.config`+`.aspx` AND `.pks`/`.pkb` | `dotnet-webforms` (frontend), `oracle-plsql` (db) |
| Java EE + T-SQL | `web.xml` AND `.dtsx`/`CREATE PROC` | `java-ee` (frontend), `sql-server-tsql` (db) |
| COBOL batch + Java web | `.cpy` AND `pom.xml` | `cobol` (batch), `java-ee` (web) |
| ColdFusion + Oracle EBS | `Application.cfc` AND `APPS.` schema | `coldfusion` (frontend), `oracle-ebs` (db) |
| PHP + legacy JS | `composer.json` AND `jquery-*.js` | `php` (backend), `legacy-js` (frontend) |

## Dispatch rules

1. Emit one row per detected language with a `scope` field: `frontend`, `backend`, `batch`, `db`, or `shared`.
2. Pass 1 (structural): load all primary references in parallel.
3. Pass 2 (extraction): sequence by scope — `db` first (stored procs are upstream), then `backend`, then `frontend`.
4. Pass 3 (cross-validation): load all dispatched references at once so cross-language contradictions surface.

## Avoiding double-counting

- Shared files count once, under the directory owner.
- Runtime-generated JS (ViewState, server-rendered) is not `legacy-js` — do not dispatch.
- Generated code (`.designer.cs`, `target/generated-sources/`) is excluded from extension counts.
- DB migrations (`db/migrations/*.sql`) count under the dialect they target.

Single-language output for a polyglot tree is a detection failure, not a simplification.
