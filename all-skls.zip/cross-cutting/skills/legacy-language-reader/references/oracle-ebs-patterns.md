# Oracle E-Business Suite Patterns — Dispatch Shim

## Purpose
Local dispatch shim for Oracle E-Business Suite (EBS) estates. Authoritative references: `cross-cutting/skills/extraction/references/oracle-ebs-patterns.md` and `cross-cutting/skills/analyze-application/references/oracle-ebs-patterns.md`.

## Key Constructs
- **Schema layout**: `APPS` public synonym schema fronting module schemas (`GL`, `AP`, `AR`, `HR`, `INV`, `ONT`, ...). All application code binds via `APPS`.
- **Concurrent Manager**: background jobs defined in FND tables (`FND_CONCURRENT_PROGRAMS`, `FND_EXECUTABLES`), launched via `FNDLIBR`; parameters in XML layouts.
- **Oracle Forms/Reports**: `.fmb` (Forms binary), `.fmx` (compiled), `.rdf` (Reports), `.rex`/`.xml` for BI Publisher layouts.
- **Workflow Builder**: `.wft` files, `WF_*` runtime tables.
- **Customization layers**: CEMLIs (Customizations, Extensions, Modifications, Localizations, Integrations); personalization via FND Flexfields.

## Detection Signals (two minimum)
1. `APPS.*` schema references in PL/SQL or view DDL.
2. Files with `.fmb`, `.fmx`, `.rdf`, `.pll`, `.wft` extensions.
3. Concurrent-program XML definitions or `FND_` table references.
4. EBS directory structure markers: `$APPL_TOP`, `$ORACLE_HOME/appsutil/`, `xbol/patch/`.

## Typical Modernization Targets
- Oracle Cloud ERP (Fusion Applications) migration.
- SaaS ERP replacement (Workday, SAP S/4HANA) with integration via Oracle Integration Cloud or bespoke adapters.
- Custom CEMLIs evaluated individually: retire, refactor to extensions, or absorb into SaaS configuration.
- Forms/Reports re-platformed to APEX or replaced by web UIs over REST APIs.

## Citations
- Oracle, "E-Business Suite Documentation Library" — https://docs.oracle.com/en/applications/e-business-suite/
- Oracle Support, "EBS Technical Reference Manuals (TRMs)" — https://support.oracle.com/
- Oracle, "Oracle Cloud ERP Migration Guides" — https://docs.oracle.com/en/cloud/saas/
- In-repo companion: `cross-cutting/skills/extraction/references/oracle-ebs-patterns.md`.
