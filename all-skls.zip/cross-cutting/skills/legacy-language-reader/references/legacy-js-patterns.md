# Legacy JavaScript Patterns — Dispatch Shim

## Purpose
Local dispatch shim for pre-module, pre-bundler JavaScript — jQuery-era scripts, IIFEs, and global-namespace code. Authoritative reference: `cross-cutting/skills/analyze-application/references/legacy-js-patterns.md`.

## Key Constructs
- **Loading**: `<script src="...">` tags in server-rendered templates; no `import`/`require`; concatenated/minified vendor bundles in `vendor/` or `assets/js/`.
- **Libraries**: jQuery 1.x/2.x/3.x, jQuery UI, Bootstrap 3/4 JS plugins, Backbone.js, Knockout, Underscore/Lodash, Moment.js.
- **Idioms**: `$(document).ready(function(){...})`, IIFEs `(function(){...})();`, anonymous callbacks, global `window.App = window.App || {};` namespacing.
- **Async**: XHR via `$.ajax`, callback chains; sparse Promise usage; no async/await.

## Detection Signals (two minimum)
1. `.js` files containing `jquery-*.js` filenames or `$(document).ready(` / `jQuery(` calls.
2. HTML / CFM / ASPX / JSP templates with `<script src="jquery-*.js">` tags.
3. Absence of a `package.json` bundler config (`webpack.config.js`, `rollup.config.js`, `vite.config.js`) at the repo root.
4. Presence of hand-maintained `vendor/` or `assets/js/lib/` directories.

## Typical Modernization Targets
- React + TypeScript SPA with Vite; jQuery selectors rewritten as components.
- Progressive enhancement via esbuild/Vite bundling of existing modules without full rewrite.
- API clients rebuilt with `fetch` / `axios`; jQuery `$.ajax` removed.

## Citations
- OpenJS Foundation, "jQuery API Documentation" — https://api.jquery.com/
- MDN Web Docs, "JavaScript Guide" — https://developer.mozilla.org/en-US/docs/Web/JavaScript/Guide
- Google Chrome team, "Migrating from jQuery" guides — https://web.dev/
- In-repo companion: `cross-cutting/skills/analyze-application/references/legacy-js-patterns.md`.
