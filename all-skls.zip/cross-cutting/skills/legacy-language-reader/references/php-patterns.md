# PHP Patterns — Dispatch Shim

## Purpose
Local dispatch shim for PHP applications, covering both modern (Laravel/Symfony) and legacy (pre-Composer) codebases. Authoritative reference: `cross-cutting/skills/extraction/references/php-patterns.md`.

## Key Constructs
- **Project layout**: `composer.json` + `vendor/` (PSR-4 autoloading) for modern apps; `index.php` + hand-rolled `require_once` chains in legacy.
- **Frameworks**: Laravel (artisan, Eloquent ORM, Blade templates, middleware), Symfony (bundles, Doctrine ORM, Twig, DI container), CodeIgniter, Zend/Laminas, WordPress, Drupal, legacy CakePHP.
- **Request handling**: `.htaccess` rewrite rules, `$_GET`/`$_POST`/`$_REQUEST`/`$_SESSION` superglobals in legacy; PSR-7/PSR-15 in modern.
- **Templating**: Blade (`.blade.php`), Twig (`.twig`), inline PHP in `.phtml` / `.tpl`.
- **Data access**: PDO, mysqli, Doctrine ORM, Eloquent; raw queries common in legacy.

## Detection Signals (two minimum)
1. `.php` files alongside `composer.json`.
2. `.htaccess` with `RewriteRule ^ index.php`.
3. Framework fingerprints: `artisan` file (Laravel), `bin/console` (Symfony), `wp-config.php` (WordPress), `sites/default/` (Drupal).
4. `index.php` at document root with `<?php ... ?>` opening tags and `require`/`include` of other PHP files.

## Typical Modernization Targets
- PHP upgrade within-language (7.x -> 8.x) to get typed properties, union types, attributes, JIT.
- Framework migration: legacy procedural PHP -> Symfony or Laravel; CodeIgniter 3 -> 4 or Laravel.
- Rewrite to Node.js/TypeScript or Java (Spring) for high-throughput services.
- WordPress headless: keep PHP backend for content, front end becomes a Next.js site hitting WP REST API.

## Citations
- The PHP Group, "PHP Manual" — https://www.php.net/manual/en/
- PHP-FIG, "PHP Standards Recommendations (PSRs)" — https://www.php-fig.org/psr/
- Laravel, "Laravel Documentation" — https://laravel.com/docs
- Symfony, "Symfony Documentation" — https://symfony.com/doc/
- In-repo companion: `cross-cutting/skills/extraction/references/php-patterns.md`.
