# SQL Server Architecture Patterns — Dispatch Shim

## Purpose
Local dispatch shim for SQL Server architectural analysis (instance-level and inter-database dependencies). Authoritative reference: `cross-cutting/skills/legacy-architecture-mapper/references/sqlserver-patterns.md`. For T-SQL code patterns see the sibling `sqlserver-tsql-patterns.md` shim.

## Key Constructs
- **Instance-level objects**: logins, server roles, linked servers, endpoints, Service Broker queues, Availability Groups.
- **Cross-database dependencies**: three-part (`db.schema.object`) and four-part (`linkedserver.db.schema.object`) name references; cross-database ownership chaining.
- **Integration artifacts**: SSIS packages (`.dtsx`) deployed to SSISDB or file system, SSRS reports (`.rdl`), SQL Server Agent jobs (stored in `msdb`).
- **Replication and CDC**: transactional/merge/snapshot replication publishers and subscribers; Change Data Capture capture/cleanup jobs.
- **Security surfaces**: AD-integrated logins, contained database users, row-level security policies, Always Encrypted column master keys.

## Detection Signals (two minimum)
1. `.sql` files with T-SQL dialect markers (`NVARCHAR`, `NOLOCK`, `GO` batch separators).
2. `.dtsx` (SSIS) or `.rdl` (SSRS) files in source control.
3. `msdb` references (Agent jobs) or `SQLAGENT` mentions in deployment scripts.
4. SMO/PowerShell (`Invoke-Sqlcmd`, `SqlServer` module) or Redgate tooling metadata.

## Typical Modernization Targets
- SQL Server -> Azure SQL Managed Instance / Azure SQL DB (lift) or Aurora PostgreSQL (shift, via SCT/DMS and Babelfish).
- SSIS packages rebuilt as Azure Data Factory, AWS Glue, or Airflow DAGs.
- SQL Agent jobs re-expressed as Kubernetes CronJobs or managed scheduler services.
- Linked-server calls replaced by event-driven integration (Service Bus, Kafka, SQS).

## Citations
- Microsoft Learn, "SQL Server documentation" — https://learn.microsoft.com/en-us/sql/sql-server/
- Microsoft Learn, "SQL Server Integration Services (SSIS)" — https://learn.microsoft.com/en-us/sql/integration-services/
- AWS, "Migrating from SQL Server to Aurora PostgreSQL" — https://docs.aws.amazon.com/dms/
- In-repo companion: `cross-cutting/skills/legacy-architecture-mapper/references/sqlserver-patterns.md`.
