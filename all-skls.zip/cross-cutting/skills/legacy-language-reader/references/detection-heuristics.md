# Detection Heuristics

`strong` = config match; `medium` = extensions + directory; `weak` = extensions only. Require two signals for primary.

| Language | Extensions | Config / build | Content markers | Directories | Confidence |
|---|---|---|---|---|---|
| NATURAL + ADABAS | `.NSN .NSP .NSD` | FNAT/FUSER listings | `DEFINE DATA`, DDM records | `src/ddms/` | strong if DDM |
| COBOL | `.cbl .cob .cpy` | JCL, `cobc` make | `IDENTIFICATION DIVISION`, `PROGRAM-ID` | `copybooks/`, `jcl/` | strong if marker+`.cpy` |
| ColdFusion | `.cfm .cfc .cfml` | `Application.cfc` | `<cfset>`, `<cffunction>`, `<cfquery>` | `cftags/`, `CFIDE/` | strong if `Application.cfc` |
| VB6 | `.bas .frm .cls .vbp` | `.vbp`, `.vbg` | `VB_Name = "..."`, `Begin VB.Form` | `forms/`, `modules/` | strong if vbp+VB_Name |
| ASP.NET WebForms | `.aspx .ascx .ashx` | `Web.config` net 4.x | `<%@ Page`, `ViewState` | `App_Code/`, `Bin/` | strong if config+`.aspx` |
| ASP.NET Core | `.cs .cshtml .razor` | `csproj` net6+, `Program.cs` | `WebApplication.CreateBuilder` | `Controllers/`, `wwwroot/` | strong if csproj net6+ |
| Java EE | `.java .jsp .xhtml` | `pom.xml`, `web.xml` | `@Stateless`, `@Entity`, `javax.servlet` | `WEB-INF/`, `META-INF/` | strong if `web.xml` |
| PHP | `.php .phtml .inc` | `composer.json`, `.htaccess` | `<?php`, `namespace App\` | `public/`, `src/` | strong if composer |
| Oracle EBS | `.sql .pls .fmb .rdf` | `$APPL_TOP`, concurrent XML | `APPS.`, `FND_`, `XX_CUSTOM_` | `custom/top/` | strong if APPS |
| Oracle PL/SQL | `.sql .pks .pkb` | sqlplus, Liquibase | `CREATE OR REPLACE PACKAGE`, `DBMS_*` | `db/packages/` | strong if pks+pkb |
| T-SQL | `.sql .dtsx` | SSIS, `.sqlproj` | `NVARCHAR`, `NOLOCK`, `CREATE PROC ... AS BEGIN` | `db/stored_procs/` | strong if dtsx |
| Legacy JS (jQuery) | `.js .html` | no bundler | `$(document).ready`, `jquery-*.js` | `assets/js/` | medium unless jquery file |

Exclude `node_modules/`, `vendor/`, `.git/`, `bin/`, `obj/`, `target/` from counts.
