# COBOL Patterns — Dispatch Shim

## Purpose
Local dispatch shim inside `legacy-language-reader`. Detection-time quick reference for COBOL. The authoritative analysis-time reference lives at `cross-cutting/skills/analyze-application/references/cobol-patterns.md` — callers should load that file once dispatch resolves.

## Key Constructs
- **Divisions and sections**: `IDENTIFICATION DIVISION`, `ENVIRONMENT DIVISION`, `DATA DIVISION` (FILE, WORKING-STORAGE, LINKAGE), `PROCEDURE DIVISION` with paragraphs and sections.
- **Copybooks** (`.cpy`, `.CPY`): shared data layouts included via `COPY`. Must be resolved to a single canonical text before parsing programs.
- **Embedded sub-languages**: `EXEC SQL ... END-EXEC` (DB2/Oracle), `EXEC CICS ... END-EXEC` (CICS), `EXEC DLI` (IMS).
- **JCL** (`.jcl`): batch orchestration — STEPs reference load modules by DD name; control files, SYSIN, GDGs.
- **File organizations**: VSAM (KSDS/ESDS/RRDS), QSAM, ISAM, line-sequential.

## Detection Signals (two minimum)
1. Files matching `*.cbl`, `*.cob`, `*.cpy`, `*.CBL`, `*.COB`, `*.CPY`.
2. Content markers: `IDENTIFICATION DIVISION` or `PROGRAM-ID.` in source files.
3. Presence of `.jcl` alongside sources, or `EXEC CICS` / `EXEC SQL` blocks.
4. Build metadata: IBM Enterprise COBOL compiler directives (`CBL`), Micro Focus (`$SET`).

## Typical Modernization Targets
- Java (Spring Boot) with JPA over DB2/Oracle; CICS transactions re-expressed as REST endpoints.
- Rehost on AWS Mainframe Modernization / Micro Focus Enterprise Server.
- Batch chains migrated to Spring Batch or AWS Batch; JCL replaced by Airflow / Step Functions.

## Citations
- IBM, "Enterprise COBOL for z/OS Language Reference", current edition — https://www.ibm.com/docs/en/cobol-zos
- ISO/IEC 1989:2023, "Information technology — Programming languages — COBOL".
- Micro Focus, "Visual COBOL Language Reference" — https://www.microfocus.com/documentation/visual-cobol/
- Authoritative in-repo companion: `cross-cutting/skills/analyze-application/references/cobol-patterns.md`.
