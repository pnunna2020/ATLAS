# Java EE Patterns — Dispatch Shim

## Purpose
Local dispatch shim for Java EE / Jakarta EE detection. Authoritative references: `cross-cutting/skills/analyze-application/references/java-ee-patterns.md` and `cross-cutting/skills/legacy-architecture-mapper/references/java-ee-patterns.md`.

## Key Constructs
- **Packaging**: WAR (web), EAR (enterprise), JAR; `WEB-INF/web.xml`, `META-INF/application.xml`.
- **Build**: `pom.xml` (Maven) or `build.gradle` (Gradle); Ant `build.xml` on older estates.
- **Components**: Servlets, JSP/JSTL, JSF (Mojarra/MyFaces), EJB 3.x session beans (Stateless/Stateful/Singleton), MDBs, JPA entities, JAX-RS resources, CDI beans.
- **App servers**: WebLogic, WebSphere, JBoss/WildFly, GlassFish/Payara, Tomcat + Spring for "Java EE-adjacent" stacks.
- **Legacy sub-stacks**: Struts 1/2, Spring 2.x, Hibernate 3.x, iBATIS.

## Detection Signals (two minimum)
1. `pom.xml` or `build.gradle` with Java-EE-API or Jakarta-EE-API dependencies.
2. `WEB-INF/web.xml` or `META-INF/application.xml` deployment descriptors.
3. Annotations in source: `@Stateless`, `@Entity`, `@Path`, `@ManagedBean`, `@WebServlet`.
4. Vendor descriptors: `weblogic.xml`, `ibm-web-bnd.xml`, `jboss-web.xml`.

## Typical Modernization Targets
- Spring Boot (JPA/Hibernate preserved, EJB rewritten as Spring services).
- Quarkus or Micronaut for GraalVM native images and container density.
- JSF/JSP front ends replaced by React/Angular SPAs consuming REST (JAX-RS -> Spring MVC controllers).
- Container migration to Tomcat/OpenJDK base images; WebLogic-/WebSphere-specific APIs isolated behind adapters.

## Citations
- Oracle, "Java EE 8 Tutorial" — https://javaee.github.io/tutorial/
- Eclipse Foundation, "Jakarta EE Specifications" — https://jakarta.ee/specifications/
- Spring Team, "Spring Boot Reference Documentation" — https://docs.spring.io/spring-boot/
- In-repo companion: `cross-cutting/skills/analyze-application/references/java-ee-patterns.md`.
