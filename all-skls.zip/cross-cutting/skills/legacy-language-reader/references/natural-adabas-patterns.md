# NATURAL / ADABAS Patterns — Dispatch Shim

## Purpose
Local dispatch shim for Software AG NATURAL 4GL programs backed by ADABAS databases. Authoritative references: `cross-cutting/skills/extraction/references/natural-adabas-patterns.md` and `cross-cutting/skills/legacy-architecture-mapper/references/natural-adabas-patterns.md`.

## Key Constructs
- **NATURAL object types**: Programs (`*.NSN`), Subprograms (`*.NSN` invoked via `CALLNAT`), Subroutines (`PERFORM`), Maps (`*.NSM`), Helproutines, GDAs/LDAs/PDAs (Global/Local/Parameter Data Areas).
- **ADABAS artifacts**: DDMs (Data Definition Modules, `*.NSD`) — the schema view; files/fields referenced by two-digit short names; descriptors and super-descriptors for indexing.
- **Control flow**: `DECIDE ON` (value-based dispatch), `DECIDE FOR` (condition dispatch), `READ ... BY ...`, `FIND ... WITH ...`, implicit loops terminated by `END-READ` / `END-FIND`.
- **Implicit behaviors**: automatic looping over read sets, implicit commits on `END TRANSACTION`, edit masks on MOVE, automatic type coercion.

## Detection Signals (two minimum)
1. Files with `.NSN`, `.NSP`, `.NSD`, `.NSM` extensions (Natural Source Program, Subprogram, DDM, Map).
2. Presence of `SAGLIB/` or `FNAT`/`FUSER` environment references.
3. Source content markers: `DEFINE DATA`, `END-DEFINE`, `CALLNAT`, `READ ... BY ISN`.
4. ADABAS control files or `ADAREP` output artifacts.

## Typical Modernization Targets
- Java (Spring Boot) + PostgreSQL or Aurora with ADABAS-to-relational schema conversion (see `cross-cutting/skills/data-modeling/references/adabas-to-postgresql-patterns.md`).
- Subprograms (`CALLNAT`) re-expressed as service methods or REST endpoints.
- DDMs mapped to normalized tables with periodic-group and multi-value-field decomposition.
- Batch programs converted to Spring Batch jobs.

## Citations
- Software AG, "NATURAL for Mainframes" documentation portal — https://documentation.softwareag.com/ (product: Natural).
- Software AG, "ADABAS for Mainframes" documentation — https://documentation.softwareag.com/ (product: Adabas).
- In-repo companion: `cross-cutting/skills/extraction/references/natural-adabas-patterns.md` (the canonical extraction-time reference; this shim exists only so `legacy-language-reader`'s reference set is self-contained for the validator).
