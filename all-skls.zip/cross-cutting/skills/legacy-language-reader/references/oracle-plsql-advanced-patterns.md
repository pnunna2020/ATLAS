# Oracle PL/SQL Advanced Patterns — Dispatch Shim

## Purpose
Local dispatch shim for Oracle PL/SQL codebases outside EBS. Authoritative reference: `cross-cutting/skills/extraction/references/oracle-plsql-advanced-patterns.md`.

## Key Constructs
- **Stored program units**: packages (`CREATE OR REPLACE PACKAGE ... AS ... END;` with matching `PACKAGE BODY`), standalone procedures/functions, triggers (row- and statement-level), types and object types.
- **Cursors and bulk ops**: explicit cursors, cursor FOR loops, `BULK COLLECT`, `FORALL`, pipelined functions (`PIPELINED` keyword with `PIPE ROW`).
- **Advanced features**: autonomous transactions (`PRAGMA AUTONOMOUS_TRANSACTION`), compound triggers, `DBMS_*` built-ins (`DBMS_SCHEDULER`, `DBMS_LOCK`, `DBMS_CRYPTO`, `DBMS_OUTPUT`, `UTL_FILE`).
- **File extensions**: `.sql`, `.pks` (package spec), `.pkb` (package body), `.trg` (trigger), `.prc`/`.fnc` (procedure/function).
- **Oracle-only dialect markers**: `NUMBER`, `VARCHAR2`, `SYSDATE`, `NVL`, `DECODE`, `ROWNUM`, `CONNECT BY PRIOR`.

## Detection Signals (two minimum)
1. `.pks` / `.pkb` file extensions, or `.sql` files containing `CREATE OR REPLACE PACKAGE`.
2. `DBMS_*` package references in source.
3. Oracle dialect types (`VARCHAR2`, `NUMBER(p,s)`, `CLOB`) vs. ANSI SQL equivalents.
4. `PRAGMA` directives: `AUTONOMOUS_TRANSACTION`, `EXCEPTION_INIT`, `RESTRICT_REFERENCES`.

## Typical Modernization Targets
- Rewrite to PostgreSQL PL/pgSQL or Aurora Babelfish — `DBMS_*` calls mapped to pgSQL equivalents (see `cross-cutting/skills/data-modeling/references/` set).
- Move procedural logic to the application tier (Java/Python services) where feasible; keep only set-based SQL in the database.
- Autonomous transactions re-modeled as separate application-level transactions or outbox-pattern messages.
- Oracle-specific functions (`DECODE`, `NVL`) rewritten as ANSI `CASE` and `COALESCE`.

## Citations
- Oracle, "Database PL/SQL Language Reference" — https://docs.oracle.com/en/database/oracle/oracle-database/19/lnpls/
- Oracle, "Database PL/SQL Packages and Types Reference" — https://docs.oracle.com/en/database/oracle/oracle-database/19/arpls/
- AWS, "Babelfish for Aurora PostgreSQL" — https://docs.aws.amazon.com/AmazonRDS/latest/AuroraUserGuide/babelfish.html
- In-repo companion: `cross-cutting/skills/extraction/references/oracle-plsql-advanced-patterns.md`.
