# ColdFusion Patterns — Dispatch Shim

## Purpose
Local dispatch shim for ColdFusion (CFML) detection. Authoritative analysis reference: `cross-cutting/skills/analyze-application/references/coldfusion-patterns.md`; architecture view: `cross-cutting/skills/legacy-architecture-mapper/references/coldfusion-patterns.md`.

## Key Constructs
- **Templates and components**: `.cfm` (page templates), `.cfc` (components — CFC methods, `component`/`cffunction`, implicit `this`/`variables` scopes).
- **Tags vs. script**: tag syntax (`<cfset>`, `<cfquery>`, `<cfif>`, `<cfloop>`) and cfscript blocks.
- **Application lifecycle**: `Application.cfc` (`onApplicationStart`, `onRequestStart`, `onSessionStart`), session/application scopes.
- **Data access**: `<cfquery>` with datasource names resolved at the CF admin layer; `QueryParam` for binding.
- **Frameworks**: ColdBox, FW/1, Fusebox; Mura CMS; CFWheels (convention-over-configuration).

## Detection Signals (two minimum)
1. Files matching `*.cfm`, `*.cfc`, `*.cfml`.
2. Presence of `Application.cfc` or `Application.cfm` at a web root.
3. Tag markers in source: `<cfset`, `<cffunction`, `<cfcomponent`, or cfscript `component { ... }`.
4. Engine markers: `lucee-*.jar`, `railo-*.jar`, Adobe ColdFusion `cfusion/` directories.

## Typical Modernization Targets
- Java (Spring Boot) or Node.js/TypeScript rewrites driven by `extraction` + `module-design`.
- Parallel-run staging with Lucee on containers while services are carved out.
- Database calls rebuilt on JDBC/Hibernate or Knex; datasources replaced by environment-bound connection strings.

## Citations
- Adobe, "ColdFusion Documentation" — https://helpx.adobe.com/coldfusion/user-guide.html
- Lucee Project, "Lucee Documentation" — https://docs.lucee.org/
- CFWheels Project, "CFWheels Guides" — https://guides.cfwheels.org/
- In-repo companion: `cross-cutting/skills/analyze-application/references/coldfusion-patterns.md`.
