# Dispatch Matrix

Paths repo-root-relative. Prefix omitted for brevity: all paths start with `cross-cutting/skills/`. Every row verified via `Read` at emission time — no invented paths.

| Detected | Primary reference | Secondary reference |
|---|---|---|
| `natural-adabas` | `extraction/references/natural-adabas-patterns.md` | `legacy-architecture-mapper/references/natural-adabas-patterns.md` |
| `cobol` | `analyze-application/references/cobol-patterns.md` | — |
| `coldfusion` | `analyze-application/references/coldfusion-patterns.md` | `legacy-architecture-mapper/references/coldfusion-patterns.md` |
| `vb6` | `extraction/references/dotnet-webforms-patterns.md` | — |
| `dotnet-webforms` | `extraction/references/dotnet-webforms-patterns.md` | `legacy-architecture-mapper/references/dotnet-webforms-patterns.md` |
| `dotnet-aspnetcore` | `extraction/references/dotnet-webforms-patterns.md` | `analyze-application/references/dotnet-webforms-patterns.md` |
| `java-ee` | `analyze-application/references/java-ee-patterns.md` | `legacy-architecture-mapper/references/java-ee-patterns.md` |
| `php` | `extraction/references/php-patterns.md` | `analyze-application/references/php-patterns.md` |
| `oracle-ebs` | `extraction/references/oracle-ebs-patterns.md` | `analyze-application/references/oracle-ebs-patterns.md` |
| `oracle-plsql` | `extraction/references/oracle-plsql-advanced-patterns.md` | — |
| `sql-server-tsql` | `extraction/references/sqlserver-tsql-patterns.md` | `legacy-architecture-mapper/references/sqlserver-patterns.md` |
| `legacy-js` | `analyze-application/references/legacy-js-patterns.md` | — |

Rules: prefer `extraction/...` for extraction passes; prefer `legacy-architecture-mapper/...` for structural passes; `analyze-application/...` for Pass 1 discovery. VB6 shares the WebForms reference until a dedicated `vb6-patterns.md` lands.
