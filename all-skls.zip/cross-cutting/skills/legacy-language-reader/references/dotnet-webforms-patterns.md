# .NET WebForms / VB6 / ASP.NET Core — Dispatch Shim

## Purpose
Local dispatch shim covering the three .NET-adjacent dialects routed through this skill: classic VB6 desktop, ASP.NET WebForms, and ASP.NET Core. Authoritative references: `cross-cutting/skills/extraction/references/dotnet-webforms-patterns.md` and `cross-cutting/skills/legacy-architecture-mapper/references/dotnet-webforms-patterns.md`.

## Key Constructs
### ASP.NET WebForms (Framework 2.0–4.8)
- `.aspx` pages with code-behind (`.aspx.cs` / `.aspx.vb`), `Page_Load`, ViewState, Master Pages, UserControls (`.ascx`).
- `Web.config` targeting `.NET Framework`; `Global.asax`; `bin/` assembly output.
- Server controls (`asp:GridView`, `asp:Repeater`); SqlDataSource / ObjectDataSource; Membership / Roles providers.

### ASP.NET Core (6+, 8)
- `Program.cs` / minimal APIs, `Startup.cs` in older templates, DI container (`IServiceCollection`), middleware pipeline, `IConfiguration`.
- `.csproj` with `TargetFramework=net6.0` or higher; `appsettings.json` environment layering.
- Razor Pages / MVC / Blazor; EF Core; authentication via `Microsoft.AspNetCore.Authentication.*`.

### Visual Basic 6
- `.bas` (modules), `.frm` (forms), `.cls` (classes), `.vbp` (project), `.vbw` workspace.
- `VB_Name = "..."` attribute header; `Begin VB.Form` marker; COM references via `TypeLib`.

## Detection Signals (two minimum)
- WebForms: `.aspx` + `Web.config` with `httpRuntime targetFramework="4.x"`.
- ASP.NET Core: `.csproj` TargetFramework `net6.0+` + `Program.cs` builder pattern.
- VB6: `VB_Name` attribute + `.vbp` project file (discriminates from VB.NET which uses `.vbproj`).

## Typical Modernization Targets
- WebForms -> ASP.NET Core MVC/Razor or React SPA + REST API.
- VB6 -> C# WinForms/WPF interim, then web-based rewrite; COM interop wrappers during transition.
- ASP.NET Core already-modern code is typically refactored in place (dependency cleanup, observability, containerization).

## Citations
- Microsoft Learn, "ASP.NET Web Forms Documentation" — https://learn.microsoft.com/en-us/aspnet/web-forms/
- Microsoft Learn, "ASP.NET Core Documentation" — https://learn.microsoft.com/en-us/aspnet/core/
- Microsoft, "Visual Basic 6.0 Resource Center" (archival) — https://learn.microsoft.com/en-us/previous-versions/visualstudio/visual-basic-6/
- In-repo companion: `cross-cutting/skills/extraction/references/dotnet-webforms-patterns.md`.
