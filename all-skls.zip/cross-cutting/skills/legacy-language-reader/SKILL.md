---
name: legacy-language-reader
description: >
  Central multi-language detection and reader-dispatch contract for Olympus agents. Detects primary language from file extensions + config files and dispatches to the correct pattern reference. Covers NATURAL, COBOL, ColdFusion, VB6, T-SQL, PL/SQL, .NET WebForms, ASP.NET Core, Java EE, PHP, and jQuery-era JS. Triggers on language detection, reader dispatch, multi-language codebase, or @legacy-language-reader.
agent: sonnet
allowed-tools:
  - Read
  - Write
  - Grep
  - Bash
---

# legacy-language-reader

## Purpose
Act as the single source of truth for legacy-language detection and pattern-reference dispatch across Olympus assembly lines. Sister skills (`analyze-application`, `extraction`, `legacy-architecture-mapper`, `module-design`) previously duplicated detection heuristics and dispatch tables; that drift produced inconsistent primary-language calls and missed pattern references. This skill centralizes detection rules and dispatch pointers so every pass resolves the same language, framework, and reference file from the same source tree. It does not replace the pattern references themselves — it only points at them.

## Inputs
- Source code repository (Git URL or local clone path)
- Optional tech fingerprint from a prior `analyze-application` Pass 1 (JSON) — used to short-circuit detection when already authoritative
- Optional client profile technology hints (`profiles/<client>/technology.yaml`) — biases detection for shops with a known stack
- Build/config artifacts discoverable in the source tree (`pom.xml`, `composer.json`, `*.csproj`, `Web.config`, `package.json`, `Application.cfc`, `*.sln`, ADABAS DDM files)
- Directory manifests (output of `git ls-files` or an equivalent traversal)

## Outputs
- Language-detection result JSON → `assets/language-detection-output-template.json`
- Dispatch decisions (one row per detected language/framework pointing at a pattern reference) → inline in the output JSON's `evidence[]` block and re-expressed as a markdown table in the agent's handoff message
- Detection heuristics catalog (internal reference) → `references/detection-heuristics.md`
- Dispatch matrix (language/framework → pattern reference path) → `references/dispatch-matrix.md`
- Multi-language dispatch guidance → `references/multi-language-apps.md`

## Methodology
1. Enumerate the source tree and collect: file-extension histogram, config-file presence, directory-pattern matches, top-level build artifacts.
2. Apply the detection heuristics from `references/detection-heuristics.md` — for each candidate language, require at least two independent signals before assigning primary or secondary status.
3. Resolve primary language by signal weight: config-file + directory-pattern + extension-majority beats extension-only. Record `confidence` as `strong`, `medium`, or `weak`.
4. Detect framework-within-language (e.g., ASP.NET WebForms vs. ASP.NET Core, Java EE vs. plain Java, jQuery-era JS vs. modern SPA) using config-file versions and content markers.
5. For every detected language/framework, look up the pattern-reference path in `references/dispatch-matrix.md` and verify the target file exists on disk before emitting the dispatch row.
6. For multi-language apps, apply `references/multi-language-apps.md` — emit one dispatch row per language with a `scope` field (`frontend`, `backend`, `batch`, `db`) and avoid double-counting shared files.
7. Write the detection result to the `assets/language-detection-output-template.json` shape and hand off to the calling skill (`analyze-application` Pass 1, `extraction` pre-pass, or `legacy-architecture-mapper` pre-pass).

## Tech-Stack Dispatch
Detection is mechanical. Each row lists the minimum two signals required to match and the pattern reference to load. For the full heuristic catalog see `references/detection-heuristics.md`; for the complete path table see `references/dispatch-matrix.md`.

| Trigger (any two signals) | Primary reference | Secondary reference | Key patterns |
|---|---|---|---|
| NATURAL source files (`*.NSN`, `*.NSP`) + ADABAS DDM (`*.NSD`) | `cross-cutting/skills/extraction/references/natural-adabas-patterns.md` | `cross-cutting/skills/legacy-architecture-mapper/references/natural-adabas-patterns.md` | DDM parsing, subprogram call graphs, DATA AREA extraction |
| `.cbl`/`.cob`/`.cpy` files + `IDENTIFICATION DIVISION` or `PROGRAM-ID` marker | `cross-cutting/skills/analyze-application/references/cobol-patterns.md` | — | Copybooks, paragraphs, CICS handles, JCL batch |
| `.cfm`/`.cfc` files + `Application.cfc` or `<cfset>`/`<cffunction>` content | `cross-cutting/skills/analyze-application/references/coldfusion-patterns.md` | `cross-cutting/skills/legacy-architecture-mapper/references/coldfusion-patterns.md` | CFC methods, scope chaining, implicit null/type coercion |
| `.bas`/`.frm`/`.cls` files + `VB_Name` attribute or `Begin VB.Form` marker | `cross-cutting/skills/extraction/references/dotnet-webforms-patterns.md` (VB6 section) | — | Form events, COM references, Declare Function, modGlobals |
| `.aspx` + `Web.config` targeting `.NET Framework 2.0–4.8` | `cross-cutting/skills/extraction/references/dotnet-webforms-patterns.md` | `cross-cutting/skills/legacy-architecture-mapper/references/dotnet-webforms-patterns.md` | ViewState, Page lifecycle, code-behind, Master Pages, Global.asax |
| `.cshtml`/`Program.cs`/`Startup.cs` + `*.csproj` targeting `net6.0`+ or `netcoreapp` | `cross-cutting/skills/extraction/references/dotnet-webforms-patterns.md` (ASP.NET Core section) | — | DI container, middleware pipeline, `IConfiguration`, minimal APIs |
| `.java` + `pom.xml`/`build.gradle` + `web.xml` or EAR/WAR packaging | `cross-cutting/skills/analyze-application/references/java-ee-patterns.md` | `cross-cutting/skills/legacy-architecture-mapper/references/java-ee-patterns.md` | EJB session beans, JPA entities, Servlets, JAX-RS, `WEB-INF/` |
| `.php` + `composer.json` or `index.php` + `.htaccess` | `cross-cutting/skills/extraction/references/php-patterns.md` | — | PSR autoload, framework detection (Laravel/Symfony/legacy), `$_GLOBALS` |
| `APPS.*` schema references + concurrent program XML or `.fmb`/`.rdf` | `cross-cutting/skills/extraction/references/oracle-ebs-patterns.md` | `cross-cutting/skills/analyze-application/references/oracle-ebs-patterns.md` | APPS schema, concurrent programs, Forms/Reports, workflows |
| `.sql`/`.pks`/`.pkb` + Oracle dialect markers (`CREATE OR REPLACE PACKAGE`, `DBMS_*`) | `cross-cutting/skills/extraction/references/oracle-plsql-advanced-patterns.md` | — | Packages, triggers, cursors, pipelined functions, autonomous txns |
| `.sql` + T-SQL dialect markers (`CREATE PROCEDURE ... AS BEGIN`, `NVARCHAR`, `NOLOCK`) or `.dtsx` SSIS packages | `cross-cutting/skills/extraction/references/sqlserver-tsql-patterns.md` | `cross-cutting/skills/legacy-architecture-mapper/references/sqlserver-patterns.md` | Stored procs, triggers, SSIS packages, linked servers |
| `.js`/`.html` + `jquery-*.js` or `$(document).ready` markers and no `package.json` bundler | `cross-cutting/skills/analyze-application/references/legacy-js-patterns.md` | — | jQuery plugins, IIFEs, global namespace pollution, script-tag loading |

Detection is **unambiguous** — two independent signals required per row. Overlapping matches (e.g., `.sql` files alone) route through the richer signal (dialect markers) rather than a generic default.

## Gotchas
- **Extension counts lie on polyglot repos.** A single `vendor/` or `node_modules/` directory can outweigh the actual application code. Exclude dependency directories before computing the extension histogram.
- **Config files beat extensions.** `Web.config` + `.aspx` is ASP.NET WebForms even if there are more `.js` files than `.cs` files. Treat build/config presence as the strong signal.
- **Multi-language apps are the norm, not the exception.** A .NET WebForms front end with a PL/SQL back end needs two dispatch rows, not one. Never collapse to a single "primary" when two independent codebases exist.
- **VB6 and VB.NET share `.bas`/`.cls` extensions.** The discriminator is `VB_Name` attribute (VB6) vs. `Imports System` / `.vbproj` (VB.NET). Never dispatch on extension alone.
- **Oracle PL/SQL vs. T-SQL on bare `.sql` files.** Dialect markers (`DBMS_*`, `NVARCHAR`, `NOLOCK`) resolve ambiguity. If neither is present, mark `confidence: weak` and request the caller inspect manually.
- **jQuery-era JS hides inside modern repos.** A `package.json` does not guarantee modern JS — check for `jquery-*.js` in `vendor/` or `<script>` tags in templates. Dispatch to `legacy-js-patterns.md` for those files specifically.
- **Detection must be deterministic.** Two runs on the same tree must produce the same primary language. Avoid heuristics that depend on file-system iteration order.

## Quality Rules
- [ ] Every detected language has at least two independent signals recorded in `evidence[]`.
- [ ] `confidence` is one of `strong`, `medium`, or `weak` — no other values emitted.
- [ ] Dispatch matrix entries all resolve to existing files on disk (validated at emission time).
- [ ] Multi-language apps trigger dispatch for every detected language, each with a `scope` field.
- [ ] Vendor/dependency directories (`node_modules/`, `vendor/`, `packages/`, `.git/`) are excluded from the extension histogram.
- [ ] Primary-language selection is deterministic — running the skill twice on the same tree produces identical output.
- [ ] Framework-within-language is resolved (e.g., `dotnet-webforms` vs. `dotnet-aspnetcore`) — never just the bare language.
- [ ] Output JSON validates against `assets/language-detection-output-template.json` (same keys, same types).
- [ ] No pattern reference is invented — every `reference` field in the output is a copy of a path already in `references/dispatch-matrix.md`.

## Common Failure Modes
| Failure Mode | Symptom | Prevention |
|---|---|---|
| Extension-only detection | Monorepo with `vendor/` reports JavaScript as primary when the real app is PHP | Exclude dependency directories before counting extensions; require config-file signal for primary |
| Collapsing multi-language apps to one primary | .NET + PL/SQL app gets only .NET patterns loaded; database logic missed | Emit one dispatch row per detected language with `scope` field; never hide secondary languages |
| VB6/VB.NET confusion | Skill dispatches VB.NET patterns for a VB6 codebase; runtime-only constructs mis-modeled | Discriminate on `VB_Name` attribute and `.vbp` project file, not extension alone |
| SQL dialect misrouted | Generic `.sql` files dispatched to T-SQL patterns when the source is Oracle | Require dialect-marker signal (`DBMS_*` vs. `NVARCHAR`); mark `weak` when unclear |
| Framework version mis-detected | ASP.NET Core code sent to WebForms patterns because both live in the same solution | Parse `*.csproj` TargetFramework; emit separate rows for Core and Framework projects |
| Stale fingerprint trusted | Prior Pass 1 tech fingerprint used without re-validation; codebase has since added a new language | Always re-run detection; treat supplied fingerprint as a hint, not authoritative |

## Handoff Summary
When this skill completes, verify:
1. Detection output matches the shape in `assets/language-detection-output-template.json` and includes at least two independent signals per detected language.
2. Every dispatch row points at a pattern reference that exists on disk (verified via Read) and is copied verbatim from `references/dispatch-matrix.md`.
3. Multi-language apps have one dispatch row per language with a `scope` field; vendor directories are excluded.
4. `confidence` is assigned for every detected language — no `null` or free-form values.

Then proceed to: `analyze-application` (Pass 1 structural) using the dispatch rows to load the correct pattern references, and — for modernization work — onward to `extraction` and `legacy-architecture-mapper` with the same dispatch set. This skill is a helper; it does not itself pass through a numbered gate, but its output is consumed by the Discovery phase and must be present before gate `G-DC` (Discovery Complete).
