# Rule Category Taxonomy

Canonical rule categories emitted into `business-rule-inventory.json`
(`business_rules[].category`) and `business-logic.json`
(`rule_groupings[].category`). The rule-inventory schema enumerates a stricter
subset; the business-logic schema extends it with three portfolio-level
categories (`pricing`, `data-integrity`, `routing`) that usefully group rules
at the rationalization layer but are stored on individual rules as the nearest
inventory category (often `calculation`, `validation`, or `workflow`).

## Canonical Categories

### validation
Rules that reject or accept input values. Typical shape: "When `<field>` is
`<predicate>`, reject with `<message>`." Severity floor: `minor`. Common
sources: web form validators, ActionMethod guards, NATURAL CHECK statements,
PL/SQL `RAISE_APPLICATION_ERROR`.

Examples:
- "When altitude < 500 or altitude > 60000, reject the flight plan."
- "When the medical class is invalid, block submission."

### calculation
Rules that derive a value from other values. Includes tax calculations,
interest, eligibility thresholds, fee computations, weight-and-balance math.
Severity floor: `major` — calculation errors usually have monetary or safety
impact.

Examples:
- "When the applicant is age 40 or older, the medical certificate validity
  period reduces from 60 to 24 months."
- "When GS-grade × locality-index > threshold, apply the premium pay cap."

### authorization
Rules that gate access to a resource or action based on role, ownership, or
state. Severity floor: `major`. Authorization bugs are disposition-gating.

Examples:
- "When the user lacks the DESIGNEE_APPROVER role, deny the approval action."
- "When the record owner != current_user, hide the edit button."

### workflow
Rules that govern the ordering or triggering of business steps. Includes state
machine transitions, notification triggers, escalation timers.

Examples:
- "When an application sits in PENDING_REVIEW > 14 days, escalate to the
  regional manager."
- "When medical certificate expires within 30 days, email the airman."

### state-transition
Sub-specialization of `workflow`. Rules that define legal transitions of an
entity state. Emit this category when the rule explicitly mentions source and
target states; otherwise prefer `workflow`.

Examples:
- "When status = DRAFT and the user submits, transition to PENDING_REVIEW."

### derivation
Rules that compute a field value from other fields (without the "transaction"
feel of a `calculation`). Often applied at read-time or via a trigger.

Examples:
- "When first_name and last_name are present, derive display_name =
  first_name + ' ' + last_name."

### eligibility
Rules that test whether an entity qualifies for a program, benefit, or
certification. Adjacent to both `validation` and `authorization` — use
`eligibility` when the rule is the primary business determinant, not a
secondary guard.

Examples:
- "When the applicant has held a Class 3 medical for 12 months, they are
  eligible for the experimental-aircraft endorsement."

### pricing (business-logic grouping only)
Category used in `rule_groupings[].category` to roll up rules that set,
adjust, or cap a price/fee/charge. Individual rules store as `calculation` in
the inventory.

### data-integrity (business-logic grouping only)
Category used in `rule_groupings[].category` to roll up rules that enforce
referential integrity, uniqueness, or cross-field consistency beyond simple
`validation`. Individual rules store as `validation` or `derivation`.

### routing (business-logic grouping only)
Category used in `rule_groupings[].category` to roll up rules that route a
record to a queue, reviewer, or downstream system. Individual rules store as
`workflow`.

### other
Escape hatch. Prefer a canonical category whenever possible; `other` should
be < 5% of an inventory. Use `evidence[]` to explain the choice.

## Severity Guidance

| Severity | When to use |
|---|---|
| `blocker` | The rule cannot be violated without production incident (safety, compliance, payment, security). |
| `critical` | Violation causes a visible, material defect but not a safety/compliance breach. |
| `major` | Violation degrades function or causes user-visible wrong output. |
| `minor` | Violation is cosmetic, advisory, or recoverable. |
| `info` | Not a violation at all — the rule is informational / documentation-style. |

Note: the rule-inventory schema carries all five; the UX schema carries only
`blocker|major|minor`. Do not cross-map.

## Confidence Guidance

| Confidence | When to use |
|---|---|
| 0.90 – 1.00 | Direct extraction from source with clear condition/action. |
| 0.70 – 0.89 | Extracted from source with minor inference (e.g., branch in a nested conditional). |
| 0.50 – 0.69 | Pattern-inferred (e.g., typical ActiveRecord callback; not directly proven). |
| 0.30 – 0.49 | Speculative — flagged for reviewer confirmation. |
| < 0.30 | Do not emit; record as an evidence note and skip. |
