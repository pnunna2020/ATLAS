# Capability-to-Code Mapping

Guidance for populating `business-logic.json -> business_capabilities[]`.
A business capability is a distinct business outcome the application
produces. It is NOT a synonym for module, package, namespace, schema, or
route. One capability frequently spans several modules; one module frequently
implements parts of several capabilities.

## Definition

A business capability answers the question: "What outcome does a business
stakeholder buy from this application?" Good capability names are
noun-phrases describing the outcome, not the technical surface that produces
it.

Good names:
- Medical Certificate Issuance
- Airman Knowledge Test Scheduling
- Designee Approval Workflow
- Weight & Balance Computation
- Regulatory Citation Lookup

Poor names (avoid):
- MedicalServiceController (module-named)
- IacraDAO (technical-surface-named)
- api/v2/certs (route-named)
- feat_medcerts (branch-named)

## Derivation Heuristics

1. **Start from user journeys, not the code tree.** If Pass 4 (UX) has
   produced a journey, use the journey's outcome as the capability seed.
2. **Group rules by shared action, not shared module.** If rules
   BR-AUTH-003 (in `SecurityFilter.java`) and BR-AUTH-011 (in `PL/SQL
   package MED_AUTH`) both gate access to the same medical record endpoint,
   they belong to the same authorization capability.
3. **Split at ownership boundaries.** If two sub-capabilities are owned by
   different business stakeholders (e.g., AME Review vs. AME Registration),
   they are separate capabilities even when they live in the same module.
4. **Parent–child is optional and sparing.** Use `parent_capability_id`
   only when the parent is a meaningful outcome of its own. Do not force a
   2-level tree for aesthetics; a flat list is acceptable.

## Owning Module Selection

`owning_module` should be the single module with primary responsibility,
chosen by this precedence:

1. The module containing the highest-confidence rule in
   `representative_rules[]`.
2. The module with the most rules in the capability.
3. The module named in the catalog entry's `primary_owner_module` hint.

If a capability is genuinely split 50/50 across modules, pick the one that
owns user-facing behavior (controllers > services > DAOs > stored procs) and
record the split in `evidence[]`.

## Representative Rules

`representative_rules[]` must be non-empty. Pick 1-5 rule_ids that best
characterize the capability — not every rule that touches it. The inventory
is the full set; this array is the curated exemplar set.

## Anti-Patterns

- **One capability per Java package.** Collapses the capability model into
  the module map and defeats the entire purpose of the artifact.
- **Capability named after a table.** Tables are data, not outcomes.
- **Every capability is a noun from the controller name.** Symptom of
  reading code first, business outcome second.
- **Capability with zero representative rules.** Schema rejects; also a
  sign that the capability is aspirational, not observed.
- **500+ capabilities for a 50-KLOC app.** You are mapping classes, not
  capabilities. Target: roughly 1 capability per 2-10 user journeys.
