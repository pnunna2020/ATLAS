# PL/SQL Business Rule Extraction

Oracle PL/SQL is where 50-70% of business logic lives in legacy FAA
applications (IACRA, DIWS, AVS-MIS, and similar). Skipping the DB layer is
the single largest source of under-counted rules and mis-weighted disposition
recommendations. This reference documents what to scan and how to translate
PL/SQL idioms into the 8-field inventory shape.

## Scope

Walk every object in every schema the application touches:

- `PACKAGE BODY` — the primary home of business logic; each public procedure
  / function typically carries 1-5 rules.
- `PROCEDURE` / `FUNCTION` standalone — legacy style; often the only
  place simple apps carry business logic.
- `TRIGGER` — `BEFORE INSERT`, `BEFORE UPDATE`, `AFTER UPDATE` all commonly
  carry derivation, validation, and state-transition rules.
- `VIEW` with `INSTEAD OF` triggers — same as above, easy to miss.
- `TYPE BODY` — rare but present for object-oriented PL/SQL.

Do NOT skip "utility" packages named `UTIL_*`, `COMMON_*`, `HELPERS_*` — FAA
teams routinely hide business logic in these by accident.

## Rule-Bearing Constructs

| Construct | Typical Category | Extraction Note |
|---|---|---|
| `RAISE_APPLICATION_ERROR(-20xxx, '...')` | validation / authorization | The message text is usually the rule action phrased as an error. |
| `IF ... THEN ... ELSIF ... END IF` with business predicates | validation / workflow | Each branch is a candidate rule. |
| `CASE WHEN ... THEN` | derivation / calculation | Each `WHEN` is a candidate rule. |
| `UPDATE ... SET status = ...` inside a proc | state-transition | Source and target state define the rule. |
| Numeric formulas (`fee := base * multiplier - discount`) | calculation | Extract each independent formula. |
| Role checks via `USER_ROLE_ASSIGNMENTS` or similar | authorization | Extract the role name and the gated action. |
| Triggers enforcing uniqueness, cascade, or derivation | validation / derivation | The trigger body is the rule. |

## Citation Format

Use `{schema}.{object}:{line}` in the `citation` field:

- `IACRA_APP.MED_AUTH_PKG:412` — line 412 of the package body for
  `IACRA_APP.MED_AUTH_PKG`.
- `IACRA_APP.TRG_APPLICATION_STATUS:27` — line 27 of the
  `TRG_APPLICATION_STATUS` trigger.

This form satisfies the inventory schema's 3-segment citation pattern
(`.+:.+:.+`) when treated as `{schema}:{object}:{line}` and still preserves
the object-type hint through the naming convention
(`TRG_*`, `PKG_*`, `PRC_*`, `FN_*`).

## Condition Phrasing

Every condition must start with the literal "When ". Convert PL/SQL idioms:

| PL/SQL | Condition phrasing |
|---|---|
| `IF p_age >= 40 AND p_class = 1` | "When the applicant age >= 40 and medical class is 1" |
| `IF v_status = 'PENDING' AND v_days_open > 14` | "When status is PENDING and days_open > 14" |
| `IF NOT has_role(p_user, 'APPROVER')` | "When the user lacks the APPROVER role" |

Avoid direct transliteration (e.g., "IF v_status = 'PENDING'...") — the
action is for a human reader to re-validate the rule, not to re-execute the
PL/SQL.

## Coverage Reporting

Populate `extraction_coverage.stored_procedure_coverage`:

- `procedures_scanned`: count of distinct PROCEDURE + FUNCTION + TRIGGER
  bodies read.
- `procedures_with_rules`: subset that yielded ≥ 1 rule.

The ratio matters:

- Ratio > 0.7: good; most procs are business logic.
- Ratio 0.3 – 0.7: normal; many utility procs.
- Ratio < 0.3 for an app flagged as Oracle-backed in the catalog: suspicious;
  likely extraction miss. Investigate before handoff.

## Common Mistakes

- **Scanning only the main schema.** Many apps have 2-5 schemas. Walk the
  grant graph in `ALL_TAB_PRIVS` to find every schema the app reads/writes.
- **Treating every `IF` as a rule.** Infrastructure `IF` (e.g.,
  `IF v_count = 0 THEN RETURN NULL`) is not a rule. Filter for business
  predicates — ones that involve a business field, role, status, or money.
- **Missing the trigger layer.** Triggers are the silent business-rule
  carriers. Always run `SELECT * FROM ALL_TRIGGERS WHERE owner = ...`.
- **Ignoring synonyms and DB links.** An app can carry rules in a remote
  schema via a DB link; the link name is the `source_system`.
