---
name: business-logic-extractor
description: >
  Extract and catalog the business rules, capabilities, and duplicated logic
  clusters from a legacy FAA application during Discovery Pass 2. Emits two
  schema-validated artifacts — business-rule-inventory.json (rule-level) and
  business-logic.json (capability + duplicate-cluster + coverage). Every rule
  carries {file}:{line} traceability and the structured 8-field shape enforced
  by olympus.validators.business_rules_validator (rule_id, category, condition,
  action, source_system, citation, confidence, severity). Replaces Pass 2 of
  the legacy analyze-application monolith so business-logic extraction can be
  re-run, diffed, and eval'd independently. Triggers on business rule
  extraction, PL/SQL rule mining, capability mapping, duplicated-logic
  detection, or @business-logic-extractor.
agent: opus
allowed-tools:
  - Read
  - Write
  - Grep
  - Bash
validation_commands:
  - "python -m olympus.validators.schema_validator business-rule-inventory.json"
  - "python -m olympus.validators.schema_validator business-logic.json"
  - "python -m olympus.validators.business_rules_validator business-rule-inventory.json"
supported_stacks:
  - java
  - dotnet
  - csharp
  - coldfusion
  - natural
  - cobol
  - python
  - php
  - plsql
  - tsql
anti_target_stacks:
  - static-site
  - pure-cdn-asset
failure_classes:
  - rule-duplication
  - missing-citation
  - legacy-format-regression
  - capability-miscategorization
  - proc-layer-skipped
benchmark_tags:
  - discovery-business-logic
  - rule-traceability
  - capability-mapping
---

# business-logic-extractor

## Purpose
Own Discovery Pass 2 (Business Logic Extraction) as a first-class, independently
runnable skill. Previously this pass was one of four sessions inside
`analyze-application/SKILL.md`, which made the rule catalog expensive to
re-derive and gave downstream consumers no dedicated schema-validated view.
This skill emits the structured rule-level `business-rule-inventory.json`
(pre-existing schema landed in PR #98) and a complementary `business-logic.json`
that adds capability mapping, duplicate-rule clusters, extraction coverage, and
the business-logic-complexity score — inputs the Rationalization line needs to
recommend Consolidate dispositions and compute the business-logic-clarity
dimension of the Discovery readiness rubric. Both artifacts together give FAA
Phase 2 the "every rule maps to `{file}:{line}`" traceability guarantee without
losing the portfolio-level view.

## Inputs
- Application source tree (Java, .NET, ColdFusion, NATURAL, COBOL, Python, PHP,
  PL/SQL, T-SQL) — scanned for conditionals, validations, calculations,
  authorization guards, and state transitions
- Application catalog entry (`schemas/discovery/application-catalog-entry.schema.json`) —
  supplies `application_id`, module list, and known integration points
- Pass 1 Architecture fingerprint (when available) — bounds the module set and
  highlights entry points
- Oracle DDL / stored procedure sources — `references/plsql-business-rule-extraction.md`
  documents the ~60% of rules that live in the DB layer in some FAA apps
- Rule category taxonomy: `references/rule-category-taxonomy.md`
- Capability mapping heuristics: `references/capability-to-code-mapping.md`

## Outputs
- Rule-level inventory → `schemas/discovery/business-rule-inventory.schema.json`
  (scaffold: `assets/business-rule-inventory-output-template.json`)
  - `application_id`, `extracted_date`, `source_artifact`, `total_rules`
  - `business_rules[]` — each row is the structured 8-field record enforced by
    `olympus.validators.business_rules_validator`: `rule_id` (BR-XXX-NNN),
    `category`, `condition` (must begin with "When "), `action`, `source_system`,
    `citation` (`{artifact}:{section}:{finding-id}` or `{repo}:{file}:{line}`),
    `confidence` (0..1), `severity` (`blocker|critical|major|minor|info`).
    Never emit legacy prose-blob rules.
  - Optional `coverage_summary.by_category` / `by_severity` roll-ups.
- Capability + duplication view → `schemas/discovery/business-logic.schema.json`
  (scaffold: `assets/business-logic-output-template.json`)
  - `business_capabilities[]` — `capability_id` (CAP-XXX-NNN), `name`,
    `description`, optional `parent_capability_id`, `owning_module`,
    `representative_rules[]` (rule_id references into the inventory)
  - `rule_groupings[]` — per-category × per-module counts and confidence totals
  - `duplicate_rule_clusters[]` — `cluster_id`, `rule_ids[]` (≥ 2),
    `similarity_score` (0..1), `duplication_reason`. Feeds Consolidate.
  - `extraction_coverage` — `modules_scanned`, `modules_with_zero_rules` (audit
    flag), `stored_procedure_coverage` (`procedures_scanned`,
    `procedures_with_rules`), `notes`
  - `business_logic_complexity_score` (1-5) — business-logic-clarity dimension
  - `evidence[]` — `finding_id`, `description`, `citation.{file,line,snippet}`
- A schema-validation report is written sibling to each artifact by the generic
  `olympus.validators.schema_validator`; never hand-edit the report files.

## Methodology
1. Read the catalog entry and, when present, the Pass 1 architecture
   fingerprint. Fix the `application_id` from the catalog — do not use the
   display name. Enumerate every module / package / namespace the extraction
   must cover so `extraction_coverage.modules_scanned` is recomputable.
2. Grep the source tree per stack for rule-bearing constructs: conditional
   validation blocks, calculation expressions, authorization guards, workflow
   state machines, derivation formulas. For PL/SQL and T-SQL, walk every stored
   procedure, trigger, package, and function — `references/plsql-business-rule-extraction.md`
   has the patterns for FAA-style Oracle back-ends where 60%+ of business logic
   sits in the DB.
3. For each rule, emit a row into `business_rules[]` in the structured 8-field
   shape. `rule_id` uses `BR-<CATEGORY>-<NNN>`; `condition` MUST start with the
   literal "When "; `citation` MUST be in `{repo}:{file}:{line}` form for source
   rules or `{schema}.{proc}:{line}` for stored procedures. Confidence is a
   numeric 0..1 (not high/medium/low). Severity is one of
   `blocker|critical|major|minor|info` — the validator rejects anything else.
   Never regress to the legacy prose-blob rule format; the validator's
   `legacy-format-regression` failure class exists to catch exactly that.
4. Group rules into business capabilities using
   `references/capability-to-code-mapping.md`. Capabilities roll up rules that
   implement the same business outcome, regardless of module. Every capability
   MUST cite ≥ 1 `representative_rules[]` rule_id present in the inventory.
5. Detect duplicate rule clusters. Two rules are a duplication candidate when
   they share a normalized condition/action pair across modules, or when one
   is a direct port/copy of the other (e.g., service layer duplicating stored
   proc logic). Record `similarity_score` (0..1) and a short
   `duplication_reason`. Clusters with only one rule are not clusters — omit.
6. Compute `extraction_coverage`. `modules_with_zero_rules` is an audit signal,
   not a silent default — if a module was scanned but yielded no rules, list
   it so the reviewer can confirm the gap is real and not an extraction miss
   (the `proc-layer-skipped` failure class).
7. Compute `business_logic_complexity_score` (1-5). Use a weighted assessment
   of: rule count per KLOC, distinct categories present, cross-module duplicate
   density, stored-proc share of rules, and branching depth of guard
   conditions. Cite the math in `evidence[]` with a `finding_id` of the form
   `BLCS-<n>`.
8. Validate both artifacts. `business-rule-inventory.json` MUST pass
   `schemas/discovery/business-rule-inventory.schema.json` AND
   `olympus.validators.business_rules_validator` (the latter enforces
   `condition` starts with "When ", the BR-ID pattern, and severity enum).
   `business-logic.json` MUST pass
   `schemas/discovery/business-logic.schema.json`.
9. Self-check cross-references. Every `representative_rules[]` rule_id and
   every `duplicate_rule_clusters[].rule_ids[]` entry MUST exist in the sibling
   inventory's `business_rules[]`. Dangling references are an auto-reject
   condition — fix them before handing off.

## Gotchas
- **The 8-field structured shape is mandatory.** `olympus.validators.business_rules_validator`
  is run post-write; it checks `rule_id`, `category`, `condition`, `action`,
  `source_system`, `citation`, `confidence`, `severity`. Emitting a legacy
  narrative rule catalog triggers the `legacy-format-regression` failure class.
- **`condition` must start with "When ".** The inventory schema enforces the
  literal prefix via a regex. Use "When the airman submits..." not "If user
  submits..." or "Airman submission triggers...".
- **`citation` must carry three segments.** `{artifact}:{section}:{finding-id}`
  or `{repo}:{file}:{line}`. A bare file path fails schema validation.
  Missing-citation is the most common failure class in Discovery Pass 2.
- **Oracle stored procedures are not optional.** FAA applications routinely
  carry 60%+ of business logic in PL/SQL packages. Skipping the DB layer
  produces a rule count that understates complexity and causes
  disposition-recommender to under-weight Replatform / Rearchitect. See
  `references/plsql-business-rule-extraction.md`.
- **Capability ≠ module.** Do not generate one capability per Java package.
  Capabilities are business outcomes (e.g., "Medical Certificate Issuance"),
  and a single capability frequently spans multiple modules. Over-fitting to
  the package tree is the `capability-miscategorization` failure class.
- **Duplicate clusters need ≥ 2 rules.** A single rule is not a cluster; the
  schema enforces `minItems: 2`. If only one rule matches a pattern, omit the
  cluster — do not pad with a near-miss.
- **`confidence` is a float 0..1, not a label.** The legacy catalog used
  `high|medium|low`. The validator rejects strings in this field. Pick a
  reasonable numeric (e.g., 0.85 for direct source extraction, 0.55 for
  inferred-from-pattern, 0.3 for speculative).
- **`severity` enum differs from UX enum.** Rules use
  `blocker|critical|major|minor|info` — note `critical` and `info` are present,
  which the UX schema does not carry. Do not cross-map.
- **`modules_with_zero_rules` is an audit flag, not a convenience field.** A
  non-empty list signals the reviewer must confirm the gap. Do not suppress
  entries just to produce a cleaner artifact.

## Quality Rules
- [ ] Every row in `business_rules[]` has the 8 required fields and passes
      `olympus.validators.business_rules_validator` with zero errors.
- [ ] Every `citation` resolves to a real `{repo}:{file}:{line}` or
      `{artifact}:{section}:{finding-id}` — no bare file paths, no placeholders.
- [ ] Every `representative_rules[]` and `duplicate_rule_clusters[].rule_ids[]`
      entry exists in the sibling inventory's `business_rules[]`.
- [ ] `business_logic_complexity_score` is an integer in [1, 5] and the
      computation is cited in `evidence[]` with a `BLCS-n` finding_id.
- [ ] `extraction_coverage.stored_procedure_coverage.procedures_with_rules`
      ≤ `procedures_scanned`, and the ratio is sanity-checked against the
      Oracle-DDL finding (if the catalog entry flagged a DB layer).
- [ ] `duplicate_rule_clusters[]` entries have `similarity_score` in [0, 1]
      and `rule_ids[]` length ≥ 2.
- [ ] `business_capabilities[]` `capability_id` matches `CAP-[A-Z0-9]+-[0-9]+`
      and `representative_rules[]` is non-empty.
- [ ] `application_id` equals the catalog entry's `application_id` — not the
      display name and not a path.
- [ ] `business-rule-inventory.json` passes its schema; `business-logic.json`
      passes its schema; both validation reports show `status: pass`.

## Common Failure Modes
| Failure Mode | Symptom | Prevention |
|---|---|---|
| Rule duplication (same logic, multiple rule_ids, no cluster) | Rationalization over-counts rule volume; Consolidate opportunities hidden | Run duplicate-cluster detection as a dedicated step; emit clusters for every near-duplicate pair, not just obvious copies |
| Missing citation (`{file}:{line}` absent or malformed) | Inventory fails `business_rules_validator`; downstream extraction cannot locate originating code | Always capture file path AND line number at extraction time; never post-hoc invent citations; the 3-segment form is mandatory |
| Legacy prose-blob regression | Validator rejects rules that lack the 8-field shape; inventory unusable | Emit the structured shape from the start; never reuse the old `business-rule-catalog.md` template verbatim |
| Capability miscategorization (one capability per package) | Capability model collapses into module map; duplicate logic across capabilities hidden | Capability is a business outcome, not a package name; one capability may span several modules; use `references/capability-to-code-mapping.md` |
| PL/SQL proc layer skipped | Rule count is suspiciously low for an Oracle-backed app; stored_procedure_coverage is zero despite DDL presence | Always walk packages, procedures, triggers, and functions; reference `references/plsql-business-rule-extraction.md` for Oracle patterns |
| `modules_with_zero_rules` silently empty | Reviewer has no audit signal; missed-rules gap hides in the count | Populate the list honestly; a non-empty list is a feature, not a bug |

## Handoff Summary
When this skill completes, verify:
1. `business-rule-inventory.json` exists next to the catalog entry, passes its
   schema with zero errors, and passes `business_rules_validator`.
2. `business-logic.json` exists next to the catalog entry and passes its
   schema with zero errors.
3. Every `representative_rules[]` and duplicate-cluster rule_id resolves to a
   row in `business_rules[]`.
4. `business_logic_complexity_score` math is cited in `evidence[]` and
   recomputable from `rule_groupings[]` + `duplicate_rule_clusters[]`.
5. `extraction_coverage.modules_with_zero_rules` is an honest audit list.

Then proceed to: `portfolio-integration-mapper` (uses duplicate clusters and
capability map to score integration load) and `disposition-recommender` (uses
complexity score and cluster density to weight Consolidate / Rearchitect vs.
Refactor).
