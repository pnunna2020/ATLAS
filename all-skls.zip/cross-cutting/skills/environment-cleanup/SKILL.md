---
name: environment-cleanup
description: >
  Find and clean up orphaned development/test environments from completed modernization waves. Use during P7.2 factory operations. Triggers on environment cleanup, orphaned resources, resource cleanup, or cost waste.
agent: sonnet
---

# Environment Cleanup
## Purpose
Each wave creates dev/test/staging environments for ~15-25 apps. After
deployment and decommission, these environments should be cleaned up.

## Workflow
1. Query Factory Configuration Registry for completed waves
2. List all environments tagged with completed wave IDs
3. Cross-reference with active parallel runs (DON'T delete those)
4. Generate cleanup plan with estimated cost savings
5. Post plan for approval (soak period before deletion)
6. Execute cleanup after approval

## Gotchas
- **Never auto-delete without approval**: Always generate a plan and wait for
  human confirmation. One wrong deletion can destroy production data.
- **Parallel run environments look like test environments**: Check P6.1 status
  before including any environment in the cleanup list.

## Quality Rules
- [ ] Cleanup plan is generated and reviewed by a human before any deletion occurs — no auto-delete
- [ ] Active parallel run environments are excluded from the cleanup list (verified against P6.1 status)
- [ ] Environments are identified by completed wave ID tags — no manual environment selection
- [ ] Cleanup plan includes estimated cost savings for each environment
- [ ] A soak period is enforced between plan approval and execution
- [ ] Cleanup execution is logged with timestamps and resource IDs for audit trail

## Common Failure Modes
| Failure Mode | Symptom | Prevention |
|-------------|---------|------------|
| Parallel run environment deleted | Active parallel run terminated; parity monitoring data lost | Always check P6.1 parallel run status before including any environment in cleanup |
| Auto-delete without approval | Production-adjacent environment deleted by automation; data loss | Enforce human approval gate between plan generation and cleanup execution |
| Missed environments | Untagged resources not included in cleanup; continue incurring costs | Use both tag-based and resource-group-based discovery to find all wave-related resources |
| Premature cleanup | Environment deleted during soak period; team needs it for investigation | Enforce minimum soak period between approval and execution; allow hold requests |

## Handoff Summary
When this skill completes, verify:
1. Cleanup plan was reviewed and approved by a human
2. Active parallel run environments were excluded
3. Execution log documents all deleted resources
4. Cost savings are reported
Then proceed to: `cost-anomaly-investigation` if cost savings are lower than expected, or `factory-capacity-manager` to release capacity for the next wave
