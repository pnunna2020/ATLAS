# PL/SQL Cross-Package Dependencies

Reference for `plsql-package-extractor`. Describes how call edges are
extracted from PL/SQL source into `plsql-call-graph.json`. Every
pattern here corresponds to a `call_kind` value or a resolution rule
the extractor applies.

## Name forms

PL/SQL resolves procedure and function references in up to three
parts:

- **Three-part:** `SCHEMA.PACKAGE.PROCEDURE(...)` — fully qualified.
  Emits `call_kind: static` with explicit schema, package, procedure.
  When `caller.schema != callee.schema`, additionally emit a
  cross-schema finding.
- **Two-part:** `PACKAGE.PROCEDURE(...)` — resolves against the
  caller's current schema. Emits `call_kind: static` with schema
  inherited from the caller.
- **Bare:** `PROCEDURE(...)` — resolves against the enclosing package
  body first, then against the caller's schema standalone procedures,
  then against `PUBLIC` synonyms. The extractor resolves the same-
  package case by looking at `public_procedures[]` and
  `private_procedures[]` of the enclosing package; anything
  unresolved is recorded with `call_kind: static` and `resolution:
  unresolved` for downstream name-resolution.

## Same-package calls

Inside a package body, a procedure calls its sibling procedures by
bare name:

```
PROCEDURE process_order(p_id IN NUMBER) IS
BEGIN
  validate_order(p_id);   -- bare name, same package
  charge_card(p_id);      -- bare name, same package
END;
```

Resolution: match the bare name against the enclosing package's
procedure/function inventory. Matches resolve to same-package edges;
non-matches escalate to schema-standalone resolution.

## Cross-package, same-schema calls

```
PROCEDURE notify_order(p_id IN NUMBER) IS
BEGIN
  pkg_notifications.send_email(p_id);   -- two-part name
END;
```

Resolution: `pkg_notifications` in the caller's schema. The edge
carries the caller's schema on both ends.

## Cross-schema calls

```
PROCEDURE sync_from_diws(p_rec_id IN NUMBER) IS
BEGIN
  DIWS.PKG_MIGRATION.import_record(p_rec_id);   -- three-part
END;
```

Resolution: explicit. Emit an edge with `caller.schema = AMCS` and
`callee.schema = DIWS`, and a finding flagging the cross-schema
dependency. In MSS shared-schema apps these edges are frequent and
normal; price them into the rearchitecture rather than suppress them.

## Dynamic calls via `EXECUTE IMMEDIATE`

PL/SQL can build and execute arbitrary SQL/PLSQL at runtime:

```
EXECUTE IMMEDIATE 'BEGIN pkg_' || v_module || '.run(:1); END;'
  USING p_arg;
```

The target is not statically knowable. Record the edge with
`call_kind: dynamic`, `target: unresolved`, and capture the unresolved
string literal fragment (the static prefix and suffix around the
concatenation points). Dynamic calls are opaque to the call graph but
must be surfaced; they represent coupling that impact analysis would
otherwise miss.

Static `EXECUTE IMMEDIATE` with a fully literal string is resolvable:

```
EXECUTE IMMEDIATE 'BEGIN pkg_cleanup.purge; END;';
```

Here the extractor may parse the literal and emit the edge with
`call_kind: static` and a `resolved_from_dynamic: true` marker for
auditability. Non-literal forms stay `call_kind: dynamic`.

## Java stored procedure calls

Oracle supports Java stored procedures invoked through a PL/SQL
wrapper:

```
PROCEDURE send_fax(p_doc IN BLOB) AS LANGUAGE JAVA
  NAME 'com.faa.fax.Sender.send(oracle.sql.BLOB)';
```

A call to `pkg_fax.send_fax(v_doc)` looks like any other PL/SQL call,
but the implementation jumps to the JVM. Emit `call_kind: java` on
the edge and record the Java class + method signature as a finding.
Rearchitecture must account for the JVM dependency even when the
call site is ordinary PL/SQL.

## External job calls via `DBMS_SCHEDULER`

`DBMS_SCHEDULER.CREATE_JOB` references a PL/SQL block or procedure
that will be invoked by the scheduler outside any caller's stack:

```
DBMS_SCHEDULER.CREATE_JOB(
  job_name   => 'REBUILD_INDEXES',
  job_type   => 'STORED_PROCEDURE',
  job_action => 'PKG_MAINT.REBUILD_ALL'
);
```

Emit `call_kind: scheduled` with caller = the procedure containing
the `CREATE_JOB` call and callee = the `job_action` target. Capture
the schedule string as edge metadata. Scheduled edges are invisible
to static analysis but must be part of the dependency graph.

## Forward references

PL/SQL permits forward-referencing procedures within the same package
body using a stub declaration:

```
PACKAGE BODY pkg_amcs IS
  PROCEDURE b;   -- forward declaration
  PROCEDURE a IS BEGIN b(); END;
  PROCEDURE b IS BEGIN NULL; END;
END;
```

The forward declaration is not a procedure; it is a name-resolution
hint. The extractor must deduplicate: `b` is one procedure, not two.
Resolve against the full body implementation, not the stub.

## Recursive calls

Direct and indirect recursion are legal:

```
PROCEDURE walk(p_node IN NUMBER) IS
BEGIN
  FOR child IN (SELECT id FROM tree WHERE parent = p_node) LOOP
    walk(child.id);   -- direct recursion
  END LOOP;
END;
```

Emit the self-edge normally. Downstream graph traversal should detect
cycles and not diverge — the extractor's job is to emit the edges
faithfully, not to flatten them.

## Package-body state sharing as implicit edges

Two procedures that read/write the same package-body variable are
coupled without any explicit call:

```
PACKAGE BODY pkg_ctx IS
  g_current_user VARCHAR2(30);

  PROCEDURE set_user(p IN VARCHAR2) IS
  BEGIN g_current_user := p; END;

  PROCEDURE audit IS
  BEGIN INSERT INTO audit_log VALUES (g_current_user, SYSTIMESTAMP); END;
END;
```

`audit` depends on `set_user` being called first in the same session.
The extractor does not emit a call edge (there is no call) but
records a `shared_state_coupling` finding naming both procedures and
the variable.

## Synonym resolution

Oracle supports public and private synonyms that alias a schema
object to another name:

```
CREATE PUBLIC SYNONYM order_pkg FOR AMCS.PKG_ORDER;
```

A call to `order_pkg.place_order(...)` is a two-part name that
resolves via the synonym. The extractor's default is to record the
edge as-seen (`order_pkg.place_order`) with `resolution: synonym` and
leave dereferencing to a later pass. When a synonym inventory is
available, emit a second resolved edge with the canonical schema and
package, linked to the original by `resolved_from_synonym`. Private
synonyms (per-schema) require the caller's schema context; public
synonyms resolve globally.

## Invalidation cascade

When a package spec is recompiled, every object that depends on it
is marked `INVALID` and will be recompiled on next reference. The
dependency tree is:

- `.pks` recompile invalidates all bodies of packages that call it
  and all standalone procedures that reference its public types.
- `.pkb` recompile invalidates nothing externally (bodies are leaves).
- View recompile invalidates packages that reference the view.
- Table change (`ALTER TABLE`) invalidates packages that reference
  the table via `%ROWTYPE` or `%TYPE`.

The extractor does not emit invalidation edges directly (they are
derivable from the call graph plus schema references) but surfaces a
finding when a package spec is referenced by more than a threshold of
downstream objects (`downstream_dependents > 20`) so the
rearchitecture prices the ripple cost of a signature change.

## Unresolved edges

When a name cannot be resolved against any available inventory, emit
the edge with `resolution: unresolved` and the raw name. Do not
suppress; an unresolved edge is evidence of a missing inventory
(often a partner-delivered package not in the `db/` drop). Downstream
reconciliation will either supply the inventory or convert the
finding into a delivery-gap issue.

## Edge schema summary

Every edge in `plsql-call-graph.json` carries:

- `caller.schema`, `caller.package` (or `null` for standalone),
  `caller.procedure`
- `callee.schema`, `callee.package` (or `null` for standalone),
  `callee.procedure`
- `call_kind` — one of `static`, `dynamic`, `java`, `scheduled`
- `resolution` — one of `resolved`, `synonym`, `resolved_from_dynamic`,
  `unresolved`
- `call_site` — `{repo}:{file}:{line}` of the statement containing
  the call
- `edge_metadata` — optional call arguments count, schedule string
  for scheduled edges, or raw literal fragment for dynamic edges
