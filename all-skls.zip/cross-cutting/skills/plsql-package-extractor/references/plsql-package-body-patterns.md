# PL/SQL Package Body Patterns

Reference for `plsql-package-extractor`. Covers the anatomy of a `.pkb`
file, the idioms Oracle PL/SQL developers use inside one, and the
signals the extractor captures. Every pattern here drives a field in
`plsql-package-inventory.json`, an edge in `plsql-call-graph.json`, or
a finding in `plsql-findings.json`.

## File header

A well-formed package body opens with:

```
CREATE OR REPLACE PACKAGE BODY [schema.]package_name
[AUTHID { DEFINER | CURRENT_USER }]
{ IS | AS }
  -- declarations
BEGIN
  -- optional initialization block
END [package_name];
/
```

Notes:
- `AUTHID` on the body is ignored; the mode is defined on the spec.
  The extractor reads `authid_mode` from the matching `.pks` and
  defaults to `DEFINER` when absent.
- `IS` and `AS` are interchangeable. Both appear in ATLAS drops.
- The trailing `/` is a SQL*Plus statement terminator, not PL/SQL
  syntax. Its absence in embedded scripts is common and not an error.
- The `schema.` prefix on `PACKAGE BODY` is optional; when absent, the
  package lives in the current schema at compile time. Record `schema`
  as the explicit prefix when present, otherwise as the enclosing
  `.sql` file's schema context if declared, otherwise as `UNKNOWN`.

## Private vs. public procedure bodies

Every procedure declared in the `.pks` spec must have a matching body
in the `.pkb`. A body may additionally contain procedures that are
*not* declared in the spec — these are private helpers, visible only
within the body. The extractor cross-references:

- `public_procedures[]` from the spec vs. the set of `PROCEDURE` /
  `FUNCTION` declarations at the top level of the body.
- Missing bodies → finding (spec promises an API the package cannot
  serve; runtime `PLS-00328` on call).
- Extra bodies → private helpers, recorded in a `private_procedures[]`
  sub-inventory for call-graph resolution but not surfaced on the
  public API record.

Local procedures nested *inside* another procedure are recorded under
the enclosing procedure, not as first-class private helpers.

## Record and collection types

PL/SQL supports three body-local type forms:

```
TYPE t_addr_rec IS RECORD (
  street   VARCHAR2(100),
  city     VARCHAR2(50),
  zip      VARCHAR2(10)
);

TYPE t_addr_tab IS TABLE OF t_addr_rec INDEX BY PLS_INTEGER;

TYPE t_cur      IS REF CURSOR RETURN some_table%ROWTYPE;
```

When these types appear in the spec (`.pks`) they are part of the
public API. When they appear only in the body, they are private. The
extractor flags **API over-exposure**: a type declared public but
never referenced outside the body is a finding (the spec leaks an
implementation detail and widens the modernization surface).

## Cursor declarations

Top-level cursors in the body define session-scoped cursors shared
across procedures in the package body:

```
CURSOR c_active_users IS
  SELECT user_id, email FROM users WHERE active_flag = 'Y';
```

These cursors carry package state across calls unless
`PRAGMA SERIALLY_REUSABLE` is set. Record every top-level cursor as
part of the package body shared-state inventory.

## Exception declarations and `PRAGMA EXCEPTION_INIT`

PL/SQL exceptions are named objects. The canonical pattern for mapping
an Oracle error code to a named exception is:

```
invalid_state EXCEPTION;
PRAGMA EXCEPTION_INIT(invalid_state, -20015);
```

The extractor records:
- Every `EXCEPTION` declaration (public when on the spec, private when
  on the body).
- Every `PRAGMA EXCEPTION_INIT` mapping with the Oracle error code.
  Mappings into the user-defined range (`-20000` .. `-20999`) are
  normal; mappings into the reserved range are findings.

## Initialization block

A package body may end with an initialization block that runs once
per session, on first reference to the package:

```
BEGIN
  g_cache := NULL;
  DBMS_OUTPUT.PUT_LINE('PKG_AMCS initialized');
END;
```

This block is implicit state. Record its presence as an
`initialization_block: true` field on the package record so downstream
dependency analysis knows the package has first-reference side
effects. Under `PRAGMA SERIALLY_REUSABLE` the block runs on every
call, not once per session — compound with the serially-reusable
finding.

## `DBMS_OUTPUT` vs. structured logging

`DBMS_OUTPUT.PUT_LINE` writes to a per-session buffer visible only
when `SERVEROUTPUT` is on; it is not production logging. Surface
every call as an **unstructured-logging** finding. Calls to a
structured logger (`LOG_PKG.LOG`, `FND_LOG.STRING`, `UTL_FILE.PUT_LINE`
to a known log directory) are informational. A package with hundreds
of `DBMS_OUTPUT` calls has no production observability and must grow
one during modernization.

## Package-body shared state

Variables declared at the top of the body, outside any procedure,
persist across calls within a session:

```
PACKAGE BODY pkg_amcs IS
  g_last_user   VARCHAR2(30);
  g_cache       t_addr_tab;
  ...
```

This is hidden coupling: procedure A sets `g_last_user`, procedure B
reads it, and the caller has no visibility. Record every top-level
variable as shared state and emit a finding when the variable is both
written and read by procedures in the public API (the package is
stateful across calls). `PRAGMA SERIALLY_REUSABLE` neutralizes this
state but breaks any code that assumes persistence — record the
mismatch.

## Local (nested) procedures

A procedure body may declare helper procedures in its own declaration
section:

```
PROCEDURE process_batch(p_batch_id IN NUMBER) IS
  PROCEDURE log_step(p_step IN VARCHAR2) IS
  BEGIN
    INSERT INTO batch_log VALUES (p_batch_id, p_step, SYSTIMESTAMP);
  END log_step;
BEGIN
  log_step('start');
  ...
END process_batch;
```

`log_step` is scoped to `process_batch` and invisible to the call
graph at the package level. Record nested procedures on the enclosing
procedure's record; do not emit them as package-level private
helpers. Their call edges resolve within the enclosing procedure.

## Pipelined functions

Pipelined table functions stream rows to a caller without materializing
the full result set:

```
FUNCTION stream_users RETURN t_user_tab PIPELINED IS
  v_row t_user_rec;
BEGIN
  FOR rec IN (SELECT * FROM users) LOOP
    v_row.id := rec.id;
    PIPE ROW(v_row);
  END LOOP;
  RETURN;
END;
```

Record `pipelined: true` on the function inventory entry. Pipelined
functions have different rearchitecture semantics (streaming vs.
batch) than ordinary functions — the flag matters.

## Bulk operations: `FORALL` and `BULK COLLECT`

PL/SQL's bulk operators minimize context switches between SQL and
PL/SQL engines:

```
SELECT user_id BULK COLLECT INTO v_ids FROM users WHERE active = 'Y';

FORALL i IN 1 .. v_ids.COUNT
  UPDATE users SET last_seen = SYSDATE WHERE user_id = v_ids(i);
```

Record the presence of `BULK COLLECT` and `FORALL` on the procedure
record. These are performance-sensitive idioms; any rearchitecture to
a row-at-a-time framework must preserve their semantics or accept
orders-of-magnitude slowdown.

## Autonomous transactions

`PRAGMA AUTONOMOUS_TRANSACTION` declared at the top of a procedure
body means that procedure runs in a nested transaction, independent
of its caller:

```
PROCEDURE log_failure(p_msg IN VARCHAR2) IS
  PRAGMA AUTONOMOUS_TRANSACTION;
BEGIN
  INSERT INTO error_log VALUES (p_msg, SYSTIMESTAMP);
  COMMIT;
END;
```

The autonomous `COMMIT` persists even if the caller later rolls back.
Record every autonomous procedure in `plsql-findings.json` with
severity `high`. Rearchitecture that collapses autonomous transactions
into a single outer transaction silently changes failure semantics.

## `WHEN OTHERS THEN NULL`

The PL/SQL anti-pattern that catches every exception and swallows it:

```
EXCEPTION
  WHEN OTHERS THEN NULL;
```

Record every occurrence. A variant is `WHEN OTHERS THEN
DBMS_OUTPUT.PUT_LINE(...)` — logs to nothing visible in production.
Both are findings.

## Deprecated communication primitives

`DBMS_PIPE` and `DBMS_ALERT` are Oracle's in-memory inter-session
messaging primitives. Both are still supported but are rarely the
right answer in a modern architecture. Record every call site as a
finding so the rearchitecture prices the replacement (typically
Advanced Queueing, a message bus, or an event stream).

## Scheduler calls

`DBMS_SCHEDULER.CREATE_JOB` inside a package schedules work to run
independently of the caller. The scheduled procedure is invoked by
the scheduler, not by any code in the call graph, so the edge is
invisible unless the extractor surfaces it:

```
DBMS_SCHEDULER.CREATE_JOB(
  job_name      => 'NIGHTLY_PURGE',
  job_type      => 'PLSQL_BLOCK',
  job_action    => 'BEGIN pkg_util.purge; END;',
  start_date    => TRUNC(SYSDATE) + 1 + 2/24,
  repeat_interval => 'FREQ=DAILY; BYHOUR=2'
);
```

Record every `CREATE_JOB` call with the referenced procedure as a
`call_kind: scheduled` edge in `plsql-call-graph.json` and as a
finding in `plsql-findings.json` with the schedule text.
