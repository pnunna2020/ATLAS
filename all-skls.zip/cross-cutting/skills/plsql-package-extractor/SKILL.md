---
name: plsql-package-extractor
description: >
  Walk a repo's `db/` directory for Oracle PL/SQL package, body,
  procedure, function, and trigger files (`.pkb`, `.pks`, `.pls`,
  `.prc`, `.fnc`, `.trg`) and produce machine-readable inventories of
  packages, standalone procedures, triggers, cross-procedure call
  edges, and quality findings that `business-logic-extractor` and
  `legacy-architecture-mapper` consume. Discovery-phase supplementary
  skill, distinct from the sibling `oracle-extraction-patterns` which
  runs during Modernization Extract. Elevates PL/SQL from a footnote
  in `oracle-discovery-patterns` to a first-class surface because in
  AAM apps (AMCS, MedXPress) the packages are the primary location of
  business logic, not the C# code. Fires when `database` contains
  `oracle` AND the repo has a `db/` directory with at least one `.pkb`
  or `.pks` file. Also triggers on @plsql-package-extractor.
tier: 1
triggers:
  database: [oracle]
agent: sonnet
enrichment_level: Full
version: 0.1.0
allowed-tools:
  - Read
  - Write
  - Grep
  - Glob
validation_commands:
  - "python -m olympus.validators.schema_validator plsql-package-inventory.json"
  - "python -m olympus.validators.schema_validator plsql-procedure-inventory.json"
  - "python -m olympus.validators.schema_validator plsql-trigger-inventory.json"
  - "python -m olympus.validators.schema_validator plsql-call-graph.json"
  - "python -m olympus.validators.schema_validator plsql-findings.json"
supported_stacks:
  - oracle
  - plsql
  - oracle-ebs
anti_target_stacks:
  - sqlserver
  - postgresql
  - mysql
  - static-site
failure_classes:
  - spec-without-body
  - body-without-spec
  - when-others-then-null-silent-swallow
  - autonomous-transaction-unrecorded
  - cross-schema-call-unresolved
  - migration-create-or-replace-chain-lost
  - serially-reusable-state-assumption
  - filename-typo-normalized
  - list-of-procs-extracted-as-source
benchmark_tags:
  - discovery-business-logic
  - plsql-inventory
  - plsql-call-graph
  - aam-portfolio-extraction
---

# plsql-package-extractor

## Purpose
Recover the complete PL/SQL business-logic surface of an Oracle-backed
application during Discovery so that `business-logic-extractor`,
`legacy-architecture-mapper`, and the G-DC gate can reason about real
behavior instead of a handful of `.pkb` filenames. In ATLAS AAM apps
the C# DAL is a thin pass-through over `PKG_AMCS.pkb` and friends; the
authoritative validation, routing, and state-transition rules live in
PL/SQL packages, standalone procedures, and triggers. Without this
pass, Rationalization prices modernization against the C# surface area
alone and misses a package body an order of magnitude larger than the
code that calls it. This skill emits per-package, per-procedure, per-
trigger, and per-call-edge records with `{repo}:{file}:{line}` for
every claim, surfaces the anti-patterns and pragmas that change
rearchitecture cost (autonomous transactions, silent exception
handlers, serially-reusable packages, `AUTHID CURRENT_USER`), and
reconciles spec/body pairing and ticket-keyed migration-script
overrides so the "latest" body reflects what is actually running.

## Inputs
- Source code repository with a `db/` directory containing `.pkb`,
  `.pks`, `.pls`, `.prc`, `.fnc`, `.trg`, or `.sql` files.
- Application catalog entry stub (per
  `schemas/discovery/application-catalog-entry.schema.json`) with
  `database` including `oracle`.
- Oracle fingerprint from `oracle-discovery-patterns` when available,
  for schema inventory and link references.
- Client-profile `profiles/<client>/risk-classification.yaml` for
  tier banding of the emitted findings.
- Optional: ticket-keyed migration script inventory
  (`AMCS-####_*.sql`, `DIWS-####_*.sql`) delivered alongside the
  `.pkb`/`.pks` drops; used to reconstruct the virtual
  `CREATE OR REPLACE` chain.

## Outputs
- `plsql-package-inventory.json` — one record per package:
  `{schema, package_name, spec_path, body_path, public_procedures[],
  public_functions[], public_types[], public_constants[],
  public_exceptions[], pragma_serially_reusable, authid_mode
  (DEFINER|CURRENT_USER), line_count_spec, line_count_body}`. Every
  record cites the `CREATE OR REPLACE PACKAGE [BODY]` declaration
  site as `{repo}:{file}:{line}`.
- `plsql-procedure-inventory.json` — one record per standalone
  procedure/function (outside any package): `{schema, name,
  parameters[], return_type_if_function, body_path, line_span}`.
- `plsql-trigger-inventory.json` — one record per trigger:
  `{schema, name, target_table, timing (BEFORE|AFTER|INSTEAD OF),
  events (INSERT|UPDATE|DELETE), statement_level_vs_row_level,
  when_clause, body_path}`.
- `plsql-call-graph.json` — call edges: `{caller_package.caller_proc,
  called_package.called_proc, call_site_file_line, call_kind}`.
  Handles three-part (`SCHEMA.PKG.PROC`), two-part (`PKG.PROC`),
  bare same-package, `EXECUTE IMMEDIATE` (`call_kind: dynamic`),
  Java stored-proc (`call_kind: java`), and scheduled
  (`call_kind: scheduled`) forms.
- `plsql-findings.json` — quality findings: spec/body pairing gaps,
  `WHEN OTHERS THEN NULL`, `PRAGMA AUTONOMOUS_TRANSACTION`,
  unhandled public-API exceptions, deprecated features (`DBMS_PIPE`,
  `DBMS_ALERT`), `DBMS_SCHEDULER.CREATE_JOB` sites, cross-schema
  edges, API over-exposure (public types used only privately), and
  filename-gated environment suffixes. Every finding carries
  `{artifact}:{section}:{finding-id}` and at least one
  `{repo}:{file}:{line}` citation.

## Methodology
1. **Enumerate PL/SQL files.** Glob `db/**/*.{pkb,pks,pls,prc,fnc,
   trg,sql}`. Do not filter on the `PKG_` prefix — it is convention.
   Exclude documentation manifests (`LIST_OF_PROCS.sql`) whose
   content is a procedure listing, not DDL. Preserve original
   filename casing and typos verbatim in every citation.
2. **Strip comments for line counts.** Remove `--` and `/* ... */`
   before emitting `line_count_spec` / `line_count_body`. Keep the
   original file untouched; comment-stripped counts feed size
   prioritization, raw counts mislead.
3. **Pair specs and bodies.** Key every `.pks` against every `.pkb`
   by `(schema, package_name)` from the `CREATE OR REPLACE PACKAGE
   [BODY] [schema.]name` declaration line. Emit a finding for every
   unpaired spec and every unpaired body. Never infer pairing from
   filename alone.
4. **Extract the public surface from `.pks`.** Record
   `public_procedures[]`, `public_functions[]` (with return type),
   `public_types[]` (`RECORD`, `TABLE OF`, `REF CURSOR`),
   `public_constants[]`, and `public_exceptions[]`. Capture parameter
   name, mode (`IN`/`OUT`/`IN OUT`), and type on every signature.
5. **Extract the implementation surface from `.pkb`.** Record
   `pragma_serially_reusable`, `authid_mode` (from the matching spec;
   default `DEFINER`), and comment-stripped body line count. Detect
   top-level body variables between `IS` and the first procedure
   block — these are shared session state.
6. **Inventory standalone procedures, functions, and triggers.**
   Every `.prc`, `.fnc`, and top-level `.pls` whose DDL is
   `CREATE OR REPLACE PROCEDURE`/`FUNCTION` (not inside a `PACKAGE
   BODY`) emits one `plsql-procedure-inventory.json` record. Every
   trigger emits one `plsql-trigger-inventory.json` record with
   target table, timing (`BEFORE`/`AFTER`/`INSTEAD OF`), events,
   row-vs-statement level, and `WHEN` clause text.
7. **Build the call graph.** For every procedure and function body,
   classify each call site: `SCHEMA.PKG.PROC(` (three-part),
   `PKG.PROC(` (two-part), bare `PROC(` (resolved against the
   enclosing package's procedures). `EXECUTE IMMEDIATE` emits
   `call_kind: dynamic` with the literal fragment captured but target
   unresolved. Java stored-proc calls emit `call_kind: java`.
   `DBMS_SCHEDULER.CREATE_JOB` emits `call_kind: scheduled` naming
   the `job_action` target. Every edge carries `{repo}:{file}:{line}`
   of the call site.
8. **Reconstruct the virtual `CREATE OR REPLACE` chain.** Ticket-
   keyed migration scripts (`AMCS-1141_*.sql`, `DIWS-0037_*.sql`)
   containing `CREATE OR REPLACE PACKAGE BODY` are sorted by ticket
   key and applied in order. The "latest" body is the highest-
   ticket-key override, not the base `.pkb`. Record the effective
   body path and the override chain as finding evidence.
9. **Parse environment-gating filename suffixes.** `_EpoweOnly`,
   `_RunOnlyOnTEST`, `_RunOnlyOnLowerEnvironment`. Emit a finding
   with the parsed environment scope for each.
10. **Surface anti-patterns as findings.** One per occurrence for
    `WHEN OTHERS THEN NULL`, `PRAGMA AUTONOMOUS_TRANSACTION`,
    `PRAGMA SERIALLY_REUSABLE`, `DBMS_SCHEDULER.CREATE_JOB`,
    `DBMS_PIPE.*`, `DBMS_ALERT.*`, cross-schema call edges, public
    types used only privately, and public procedures with no top-
    level exception handler.
11. **Validate and hand off.** Validate every emitted JSON against
    its schema. Write the five artifacts to the Discovery working
    set; update the catalog entry's `business_logic_surface` and
    `plsql_package_count` fields; signal `business-logic-extractor`
    to consume the package inventory.

## Tech-Stack Dispatch

| Trigger | Key patterns |
|---|---|
| `db/**/*.pkb` present | `CREATE OR REPLACE PACKAGE BODY`, `PRAGMA AUTONOMOUS_TRANSACTION`, `WHEN OTHERS THEN NULL`, `BULK COLLECT`, `FORALL` |
| `db/**/*.pks` present | `CREATE OR REPLACE PACKAGE`, `AUTHID CURRENT_USER`, `PRAGMA SERIALLY_REUSABLE`, public `TYPE` / `CURSOR` / exception declarations |
| `db/**/*.prc` or top-level `.pls` | `CREATE OR REPLACE PROCEDURE`, parameter modes, `RETURN` type for functions |
| `db/**/*.trg` or inline `CREATE OR REPLACE TRIGGER` | `BEFORE`/`AFTER`/`INSTEAD OF`, `FOR EACH ROW`, `WHEN (...)`, `REFERENCING OLD AS`/`NEW AS` |
| Ticket-keyed `.sql` (`AMCS-####_*.sql`, `DIWS-####_*.sql`) | `CREATE OR REPLACE PACKAGE BODY` redefining prior body; chronological ordering required |

Detection is mechanical: presence of one signal triggers the matching
reference pattern. Overlap with `oracle-extraction-patterns` is
explicit — extraction runs later in Modernization and consumes these
findings.

## Gotchas
- **Spec and body are separate compilation units.** A body-only
  package compiles but has no public surface; a spec-only package
  compiles but fails at first call. Both are findings.
- **File naming is convention, not contract.** `PKG_AMCS.pkb` ships
  in AMCS with no `.pks` sibling; may mean the spec lives in a
  separate delivery, may mean the drop is incomplete. Flag, do not
  assume.
- **`PRAGMA AUTONOMOUS_TRANSACTION` commits independently of the
  caller.** A rollback upstream will not undo the autonomous commit.
  Silent data-integrity risk during rearchitecture. Surface every
  occurrence.
- **`WHEN OTHERS THEN NULL` swallows every exception.** Operationally
  invisible failures. Surface every site.
- **`AUTHID CURRENT_USER` vs `AUTHID DEFINER` changes privilege
  evaluation.** Definer rights run as the package owner (the
  default); invoker rights run as the caller. Record the mode on
  every package.
- **Typo-preserving is mandatory.** `Strored Procedures/` (MedXPress),
  `Epowe` (AMCS's `DHS_*_EpoweOnly.sql`), `DataAccesslayer` (lower-
  case `l`). The original spelling is the traceability key; do not
  normalize.
- **Cross-schema references are first-class.** `AMCS.PKG_X` calling
  `DIWS.PKG_Y` is normal in MSS shared-schema apps. Emit cross-schema
  edges as findings so rearchitecture can price schema separation.
- **Ticket-keyed migration scripts override the `.pkb`.**
  `AMCS-1141_UpdatePkgAmcs.sql` carrying `CREATE OR REPLACE PACKAGE
  BODY PKG_AMCS` silently replaces the body delivered in the base
  drop. The "latest" body is the highest-ticket-key migration.
- **`DBMS_SCHEDULER.CREATE_JOB` is an invisible call edge.** Scheduled
  work runs independently of any caller. Record every site.
- **`PRAGMA SERIALLY_REUSABLE` destroys package state between
  calls.** Any code assuming persistent body variables breaks
  silently. Record; flag assumption mismatches.
- **Package bodies can be thousands of lines.** `PKG_AMCS.pkb`
  expands to several thousand lines. Do not cap line counts.
- **`LIST_OF_PROCS.sql` (MedXPress) is documentation, not source.**
  Do not extract it as a package.
- **Environment-gating lives in the filename.** `_EpoweOnly`,
  `_RunOnlyOnTEST`, `_RunOnlyOnLowerEnvironment`. Parse the suffix.
- **`PKG_` prefix is convention, not syntax.** Any file with
  `CREATE OR REPLACE PACKAGE` is a package. Filtering on `PKG_` drops
  unprefixed partner deliveries.

## Quality Rules
- [ ] Every `.pkb` in `db/` has a `plsql-package-inventory.json`
      record with `body_path` and a `{repo}:{file}:{line}` citation
      on the `CREATE OR REPLACE PACKAGE BODY` declaration line.
- [ ] Every `.pks` is paired against its `.pkb` by
      `(schema, package_name)`; unpaired specs and bodies each emit
      a finding.
- [ ] Every package record populates `authid_mode` (defaulting to
      `DEFINER` when the spec has no `AUTHID` clause) and
      `pragma_serially_reusable` (boolean).
- [ ] Every standalone `.prc`, `.fnc`, and top-level `.pls` emits
      one `plsql-procedure-inventory.json` record with parameter
      list and line span.
- [ ] Every trigger emits one `plsql-trigger-inventory.json` record
      with target table, timing, events, and row/statement level.
- [ ] Every call edge carries `{repo}:{file}:{line}` and a
      `call_kind` of `static` | `dynamic` | `java` | `scheduled`.
- [ ] Every `WHEN OTHERS THEN NULL`, `PRAGMA
      AUTONOMOUS_TRANSACTION`, `PRAGMA SERIALLY_REUSABLE`, and
      `DBMS_SCHEDULER.CREATE_JOB` site emits a finding.
- [ ] Every cross-schema edge (caller schema differs from callee
      schema) emits a finding.
- [ ] Ticket-keyed migration scripts containing `CREATE OR REPLACE
      PACKAGE BODY` are folded into the virtual chain; the
      effective body path reflects the highest ticket-key override.
- [ ] Filename suffixes `_EpoweOnly`, `_RunOnlyOnTEST`,
      `_RunOnlyOnLowerEnvironment` each emit a finding with the
      parsed environment scope.
- [ ] Every finding record carries
      `{artifact}:{section}:{finding-id}` and at least one
      `{repo}:{file}:{line}` citation.

## Common Failure Modes
| Failure Mode | Symptom | Prevention |
|---|---|---|
| Filter on `PKG_` prefix | Partner packages without the prefix (e.g., `AUTH_UTIL.pkb`) disappear | Filter on `CREATE OR REPLACE PACKAGE` content, never on filename prefix |
| Trust `.pkb` as the latest body | Ticket-keyed migration fixes ignored; reported business logic is stale | Sort ticket-keyed `.sql` chronologically, apply the virtual `CREATE OR REPLACE` chain |
| Normalize filenames | `Strored Procedures/` corrected to `Stored Procedures/`; traceability breaks | Preserve original casing and spelling verbatim in every citation |
| Skip cross-schema edges | `AMCS.PKG_X` calling `DIWS.PKG_Y` folded into a same-schema edge | Parse three-part names explicitly; schema mismatch emits a finding |
| Collapse `EXECUTE IMMEDIATE` to no edge | Dynamic calls invisible; impact analysis underestimates coupling | Emit `call_kind: dynamic` with the literal captured and target unresolved |
| Drop `LIST_OF_PROCS.sql` as a package | Documentation file parsed as DDL; phantom package appears | Classify by top-level DDL, not by extension |
| Miss `AUTHID` on inherited default | `CURRENT_USER` packages reported as `DEFINER`; privilege-escalation path missed | Default to `DEFINER` only when the spec has no `AUTHID` clause at all |

## Handoff Summary
When this skill completes, verify:
1. All five artifacts (`plsql-package-inventory.json`,
   `plsql-procedure-inventory.json`, `plsql-trigger-inventory.json`,
   `plsql-call-graph.json`, `plsql-findings.json`) exist next to the
   catalog entry and validate against their schemas with zero errors.
2. Every `.pkb` / `.pks` / `.prc` / `.fnc` / `.trg` under `db/` is
   accounted for in exactly one inventory record with the original
   filename preserved.
3. The virtual `CREATE OR REPLACE` chain is applied and
   `effective_body_path` reflects the highest-ticket-key override.
4. Every `WHEN OTHERS THEN NULL`, autonomous transaction, serially-
   reusable pragma, `DBMS_SCHEDULER.CREATE_JOB`, and cross-schema
   edge is surfaced as a finding.

Then proceed to `business-logic-extractor` (mines validation,
routing, and state-transition rules from the inventories),
`legacy-architecture-mapper` (folds the call graph and cross-schema
edges into the per-app architecture), and — for apps dispositioned
Rearchitect or Replatform — `oracle-extraction-patterns` in the
Modernization Extract step. Next gate is **G-DC** (Discovery
Completeness); the five artifacts must be accepted before
Rationalization begins.

## References
- `references/plsql-package-body-patterns.md` — Anatomy of a `.pkb`:
  declaration header, private vs public procedure bodies, record and
  collection types, cursor declarations, exception declarations with
  `PRAGMA EXCEPTION_INIT`, initialization block, `DBMS_OUTPUT` vs
  structured logging, package-body shared state, local procedures,
  pipelined functions, and bulk operations.
- `references/plsql-cross-package-dependencies.md` — Call-graph
  extraction: three-part, two-part, and bare forms; `EXECUTE
  IMMEDIATE` opaque edges; Java stored procs; `DBMS_SCHEDULER`
  scheduled edges; forward references; recursion; synonym
  resolution; invalidation cascade.

## Changelog
- 0.1.0 (2026-05-06) — Initial skill for Discovery-phase PL/SQL
  surface recovery in AAM apps (AMCS, MedXPress, DIWS). Covers
  spec/body pairing, standalone procedure and trigger inventories,
  three-part/two-part/bare call-graph extraction, dynamic and Java
  call edges, virtual `CREATE OR REPLACE` chain reconstruction from
  ticket-keyed migration scripts, and the PL/SQL anti-pattern
  finding set. Feeds `business-logic-extractor`, `legacy-
  architecture-mapper`, and `oracle-extraction-patterns`.
