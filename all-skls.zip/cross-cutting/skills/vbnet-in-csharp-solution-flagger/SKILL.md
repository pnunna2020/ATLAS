---
name: vbnet-in-csharp-solution-flagger
description: >
  Detect VB.NET projects embedded in otherwise-C# Visual Studio
  solutions. Legacy .NET apps occasionally retain a small VB.NET
  project — often a logging utility, an old domain library, or a
  legacy conversion tool — long after the rest of the solution
  migrated to C#. DMS is the ATLAS case: `Dms.Logs` (VB.NET) is the
  only non-C# project among 8 projects in `Dms.sln`. Modernization
  must decide: port the VB.NET project to C# (small, usually fast)
  or preserve. Tiny per-occurrence but across a portfolio these add
  up. Runs as Discovery conditional when a `.sln` contains both
  `.csproj` and `.vbproj` entries. Triggers on mixed-language solution
  detection, VB.NET-in-C#-solution audit, or
  @vbnet-in-csharp-solution-flagger.
agent: sonnet
allowed-tools:
  - Read
  - Write
  - Grep
  - Glob
validation_commands:
  - "python -m olympus.validators.schema_validator mixed-language-solution-inventory.json"
  - "python -m olympus.validators.schema_validator vbnet-project-findings.json"
supported_stacks:
  - csharp
  - vbnet
  - dotnet
anti_target_stacks:
  - fsharp-only
  - cplusplus-only
  - non-dotnet
failure_classes:
  - fsharp-project-misclassified-as-vbnet
  - shared-assembly-confused-with-vb
  - vb6-vs-vbnet-conflated
benchmark_tags:
  - discovery-structure
  - mixed-language-detection
  - vb-to-csharp-port
---

# vbnet-in-csharp-solution-flagger

## Purpose
Inventory solutions with mixed C# + VB.NET projects and recommend
per-project disposition (port to C# or preserve).

## Inputs
- Repository with .sln files and .csproj/.vbproj entries.

## Outputs
- `mixed-language-solution-inventory.json` — per solution:
  `{sln_path, csproj_count, vbproj_count, fsproj_count, mixed
  (true if > 1 language)}`.
- `vbnet-project-findings.json` — per VB.NET project in a
  mixed-language solution: `{project, line_count, recommended
  disposition (port-to-csharp | preserve), rationale}`.

## Methodology
1. Parse each `.sln` for project type GUIDs:
   `{FAE04EC0-...}` = C#, `{F184B08F-...}` = VB.NET, `{F2A71F9B-...}` = F#.
2. Flag solutions with more than one language.
3. For each VB.NET project in a mixed solution, count LOC and
   public API surface.
4. Recommend disposition: < 1000 LOC = port; > 1000 LOC AND no
   active dev = preserve; otherwise team call.

## Tech-Stack Dispatch

No external references.

## Gotchas
- VB.NET != VB6 — `.vbproj` is VB.NET, `.vbp` is VB6. Don't
  conflate.
- F# projects (`.fsproj`) often mistaken for VB.NET because both
  are non-C#; distinguish via GUID.
- Shared assemblies (PCL / .NET Standard) can be consumed by C#
  and VB.NET equally; don't flag those as the language split.
- Small utility VB.NET projects (like `Dms.Logs`) are usually
  inherited from the original framework author's preference; no
  functional reason to retain.

## Quality Rules
- [ ] Every mixed-language solution cataloged.
- [ ] Per VB.NET project: LOC + disposition recommendation.
- [ ] F# not conflated with VB.NET.
- [ ] Every record cites `{repo}:{file}:{line}`.

## Common Failure Modes

| Failure Mode | Symptom | Prevention |
|---|---|---|
| F# misclassified as VB.NET | Non-C# project reported as VB | Check type GUID, not file extension |
| VB6 conflated | `.vbp` VB6 treated as modern | Different skill (`vss-legacy-detector` covers VB6 era) |

## Handoff Summary
Mixed-language solutions inventoried. Proceed to
`disposition-recommender` with per-project VB.NET recommendations.

## References
None.

## Changelog
- 0.1.0 (2026-05-07) — Initial skill. Authored as ATLAS-R-19.
