---
name: ssdt-sqlproj-extractor
description: >
  Extract the declarative SQL Server Data Tools (SSDT) `.sqlproj` project
  surface during Modernization Extract when an application ships its database
  as an MSBuild-driven DACPAC rather than as an imperative migration-script
  repo (Flyway, DbUp, Liquibase, hand-rolled `V001__*.sql`). Parses the
  `.sqlproj` MSBuild XML, enumerates every `<Build Include>` compiled object
  and `<None Include>` carry-only script, walks `.refactorlog` rename history,
  inventories `.publish.xml` deployment profiles and their safety flags,
  records `<ArtifactReference>` cross-database refs (including composite
  projects like DMS's Oda.Database riding next to Dms.Database), and emits a
  migration-conversion plan when the modernization target is an imperative
  tool (Flyway/DbUp/Prisma/Atlas/EF-Core-Migrations). Complements
  `sqlserver-extraction-patterns` which handles both SSDT and migration
  shapes at a high level; this skill is the deeper SSDT-specific extractor
  because declarative and imperative schema management are not interchangeable
  surfaces. Runs as an Extract conditional skill when `database` is
  `sqlserver`/`mssql` AND the repo contains a `.sqlproj`. Triggers on SSDT
  extraction, sqlproj analysis, DACPAC inspection, refactorlog walk,
  publish-profile inventory, declarative-schema conversion planning, or
  @ssdt-sqlproj-extractor.
tier: 1
triggers:
  database: [sqlserver, mssql]
  repo_contains: ["*.sqlproj"]
agent: sonnet
enrichment_level: Full
version: 0.1.0
allowed-tools:
  - Read
  - Write
  - Grep
  - Glob
  - Bash
validation_commands:
  - "python -m olympus.validators.schema_validator ssdt-project-manifest.json"
  - "python -m olympus.validators.schema_validator ssdt-build-item-manifest.json"
  - "python -m olympus.validators.schema_validator ssdt-refactorlog-manifest.json"
  - "python -m olympus.validators.schema_validator ssdt-publish-profile-manifest.json"
  - "python -m olympus.validators.schema_validator ssdt-database-reference-manifest.json"
  - "python -m olympus.validators.schema_validator ssdt-to-migration-conversion-plan.json"
supported_stacks:
  - sqlserver
  - mssql
  - tsql
  - ssdt
  - sqlproj
  - dacpac
anti_target_stacks:
  - oracle
  - postgresql
  - mysql
  - flyway-only
  - dbup-only
  - liquibase-only
failure_classes:
  - sqlproj-parsed-as-code-not-xml
  - dsp-version-misread
  - build-vs-none-confused
  - refactorlog-discarded
  - predeploy-postdeploy-conflated
  - sqlcmd-variable-leaked
  - publish-profile-safety-flag-missed
  - artifactreference-skipped
  - dacpac-zip-not-opened
  - target-platform-mismatch-silent
benchmark_tags:
  - modernization-extract
  - ssdt-declarative
  - dacpac-surface
---

# SSDT `.sqlproj` Extractor

## Purpose
Recover the full declarative shape of an SSDT SQL Server database project so
that Modernization Extract, Design, and Generate have a faithful model of the
target schema, its deployment safety posture, and its rename history. SSDT is
Microsoft's declarative schema-management tooling: a `.sqlproj` is an MSBuild
project, every table/proc/view/function lives as its own `.sql` file, and the
project builds into a `.dacpac` artifact that `sqlpackage.exe` then
diff-applies to the target database. This model is fundamentally different
from the imperative migration-script shape (Flyway, DbUp, Liquibase,
hand-rolled `V001__*.sql`). The higher-level `sqlserver-extraction-patterns`
skill handles both shapes but cannot drill into SSDT specifics such as the
refactorlog rename ledger, `<Build>` vs `<None>` compile-versus-carry
distinction, `.publish.xml` safety flags, or the DACPAC zip anatomy. In the
current ATLAS portfolio, DMS is the only application with SSDT; every other
SQL Server app uses migration scripts. Without this extractor, declarative
renames regress to drop-and-recreate at deploy, composite cross-database
refs get dropped, and migration-to-Flyway/DbUp/Prisma conversion plans have
no diff basis.

## Inputs
- Source repository containing at least one `.sqlproj` file (MSBuild XML),
  its solution `.sln` when present, and the full tree of `.sql` files
  referenced as `<Build Include>` or `<None Include>` items
- Application catalog entry (`schemas/discovery/application-catalog-entry.schema.json`)
  with `database` set to `sqlserver` or `mssql` and the SSDT signal already
  surfaced by `sqlserver-discovery-patterns`
- Any `.refactorlog` files sitting next to the `.sqlproj` (rename/move ledger)
- Any `.publish.xml` deployment profiles in the project tree
- Any `.dacpac` binaries committed to the repo (ZIP files containing
  `model.xml`, `origin.xml`, `dataschema.xml`)
- Modernization-target declaration from the blueprint (one of declarative:
  Prisma/Atlas; or imperative: Flyway/DbUp/EF-Core-Migrations) — drives
  whether the conversion-plan manifest is emitted
- Reference corpus: `references/sqlproj-msbuild-structure.md` and
  `references/declarative-vs-imperative-schema-mgmt.md`

## Outputs
- `ssdt-project-manifest.json` — per `.sqlproj`: project path, target
  database schema, Data-Tier-App Specification (DSP) version, target
  platform moniker (SQL Server 2012/2014/2016/2017/2019/2022/Azure SQL),
  output `.dacpac` path, project style (SDK `Microsoft.Data.Tools.Sql.Sdk`
  vs legacy), and solution membership
- `ssdt-build-item-manifest.json` — every `<Build Include="...sql">`
  compile item classified by object kind (table, view, proc, function,
  trigger, index, user-defined type, synonym, role, schema, assembly,
  certificate); every `<None Include="...sql">` carry item with its
  `<BuildAction>` marker (`PreDeploy`, `PostDeploy`, `None`, seed); every
  `<PreDeploy>` and `<PostDeploy>` root-level element
- `ssdt-refactorlog-manifest.json` — every entry in every `.refactorlog`:
  operation (`Rename`/`Move`), element kind, old name, new name, timestamp,
  author metadata. Authoritative for preserving rename semantics at deploy
- `ssdt-publish-profile-manifest.json` — every `.publish.xml`: target
  connection (redacted), `BlockOnPossibleDataLoss`, `IncludeTransactionalScripts`,
  `DeployDatabaseInSingleUserMode`, `DropObjectsNotInSource`,
  `DoNotAlterChangeDataCaptureObjects`, `IgnorePermissions`, and every
  `<SqlCmdVariable>` with values redacted when they contain credentials or
  connection strings
- `ssdt-database-reference-manifest.json` — every `<ArtifactReference>`:
  referenced project or dacpac, private-vs-same-database semantics,
  variable mapping, and whether the target is a system dacpac
  (`master.dacpac`, `msdb.dacpac`) or an application dacpac (composite
  project — e.g., DMS's `Oda.Database` riding next to `Dms.Database`)
- `ssdt-to-migration-conversion-plan.json` — emitted only when the
  modernization target is an imperative tool: a declarative-snapshot to
  ordered-migration sequence plan, citing the refactorlog for rename
  preservation and the `<PreDeploy>`/`<PostDeploy>` files for lifecycle
  script translation
- Finding records with canonical citation form
  `{artifact}:{section}:{finding-id}` for cross-skill handoff (e.g.,
  `ssdt-project-manifest.json:dsp:F-003`) and `{repo}:{file}:{line}` for
  source evidence

## Methodology
1. **Enumerate `.sqlproj` files.** Walk the repository for `*.sqlproj`.
   For each, parse the MSBuild XML — never as text, never as code. Record
   project style by inspecting the root element: SDK-style when the root
   is `<Project Sdk="Microsoft.Data.Tools.Sql.Sdk">`, legacy otherwise.
   Capture the `<Name>` or derive it from the filename. Emit one project
   record per `.sqlproj` into `ssdt-project-manifest.json`.
2. **Pin DSP and target platform.** Read `<DSP>` (Data-Tier-App
   Specification). Map the moniker to the target platform: `Sql110` =
   SQL Server 2012, `Sql120` = 2014, `Sql130` = 2016, `Sql140` = 2017,
   `Sql150` = 2019, `Sql160` = 2022, `SqlAzureV12` = Azure SQL Database.
   Record both the raw moniker and the resolved platform; downstream
   deployment validation compares the pinned platform to the production
   server version. Use the mapping table in
   `references/sqlproj-msbuild-structure.md` — do not invent.
3. **Classify every compile and carry item.** Walk every `<Build Include>`
   item and classify by inspecting the target `.sql` file header: `CREATE
   TABLE`/`CREATE PROC`/`CREATE VIEW`/`CREATE FUNCTION`/`CREATE TRIGGER`/
   `CREATE INDEX`/`CREATE TYPE`/`CREATE SYNONYM`/`CREATE ROLE`/`CREATE
   SCHEMA`/`CREATE ASSEMBLY`/`CREATE CERTIFICATE`. Walk every `<None
   Include>` item; read its `<BuildAction>` child to decide whether it is
   `PreDeploy`, `PostDeploy`, seed data, or purely carry. Emit one row
   per item into `ssdt-build-item-manifest.json` with
   `{repo}:{file}:{line}` citation for every claim.
4. **Walk the refactorlog.** For each `.refactorlog` sibling of a
   `.sqlproj`, parse the XML. For every `<Operation>` element, record
   the operation kind (`Rename`, `Move`), element kind, old and new
   names, timestamp, and any author tag. The refactorlog is
   authoritative: without it, `sqlpackage` drops and recreates renamed
   objects, losing data. Emit one row per operation into
   `ssdt-refactorlog-manifest.json`. If the project has no refactorlog,
   emit an explicit `no-refactorlog-present` finding — absence is a
   discovery signal, not a silent default.
5. **Inventory publish profiles.** For each `.publish.xml`, parse as XML
   and extract the target connection (redact `Data Source`, `User ID`,
   `Password`, and any SqlCmd variable that looks credential-bearing).
   Record the safety flags: `BlockOnPossibleDataLoss`,
   `IncludeTransactionalScripts`, `DeployDatabaseInSingleUserMode`,
   `DropObjectsNotInSource`, `DoNotAlterChangeDataCaptureObjects`,
   `IgnorePermissions`, `GenerateSmartDefaults`. Record every
   `<SqlCmdVariable>` name with its `<Value>` and `<DefaultValue>` —
   redact when the variable is named `*Password*`, `*Secret*`,
   `*Key*`, or the value pattern matches a connection string.
6. **Catalog database references.** For every `<ArtifactReference>` in
   every `.sqlproj`, record the referenced project or dacpac path, the
   `<HintPath>`, `<Private>` flag, `<SuppressMissingDependenciesErrors>`
   setting, and whether the reference is a system dacpac
   (`master.dacpac`/`msdb.dacpac` — ship with SQL Server) or an
   application dacpac (composite project). DMS's solution with
   `Dms.Database` and `Oda.Database` both present is the canonical
   composite case — emit a `composite-project` finding on that shape.
7. **Unzip any committed DACPAC binaries.** A `.dacpac` is a ZIP
   (same family as `.docx`, `.jar`, `.xlsx`). Walk the repo for
   `*.dacpac`, open offline with the Bash `unzip -l` to list entries,
   extract `model.xml` (declarative schema), `origin.xml`, and
   `dataschema.xml`. Record the model hash; do not bulk-serialize
   `model.xml` into the manifest — cite it by path and hash.
8. **Plan migration-tool conversion when required.** If the blueprint's
   modernization target is an imperative tool (Flyway, DbUp,
   EF-Core-Migrations), emit `ssdt-to-migration-conversion-plan.json`.
   The plan: (a) treat the DACPAC model as the "current snapshot", (b)
   emit an initial migration `V001__baseline.sql` reconstructed from the
   compiled objects, (c) convert every refactorlog operation into a
   corresponding migration entry that preserves the rename, (d)
   translate `<PreDeploy>` scripts to lifecycle hooks and `<PostDeploy>`
   scripts to idempotent seed migrations with `IF NOT EXISTS` guards, (e)
   surface `<SqlCmdVariable>` values as environment-bound parameters.
   For declarative modernization targets (Prisma, Atlas), the plan is
   trivially model-preserving; emit a single-step plan and cite.
9. **Flag target-platform drift.** If the catalog entry records a
   production server version that does not match the pinned DSP
   (e.g., project targets `Sql150` = SQL Server 2019 but production is
   SQL Server 2016 = `Sql130`), emit a `target-platform-mismatch`
   finding — `sqlpackage` will fail at deploy time, and the discrepancy
   must surface before the next gate.
10. **Validate and hand off.** Validate every emitted manifest against
    its schema via `olympus.validators.schema_validator`. Every finding
    must carry both `{artifact}:{section}:{finding-id}` and at least one
    `{repo}:{file}:{line}` source citation. Write all six manifests to
    the Extract working set and update the blueprint's data-tier
    section with the SSDT fingerprint.

## Tech-Stack Dispatch

| Trigger | Key patterns |
|---|---|
| `.sqlproj` root is `<Project Sdk="Microsoft.Data.Tools.Sql.Sdk">` | New-style SDK `.sqlproj`, implicit `<Build>` globbing, `PackageReference`-style composite refs |
| Legacy `.sqlproj` with `<Import Project="$(MSBuildExtensionsPath)\Microsoft\VisualStudio\v$(VisualStudioVersion)\SSDT\Microsoft.Data.Tools.Schema.SqlTasks.targets" />` | Explicit `<Build Include>` lists, `packages.config` style refs, no implicit globbing |
| `.refactorlog` present as sibling | Rename/move ledger authoritative; deploy must honor or lose data |
| `<None Include="*.sql">` with `<BuildAction>PreDeploy</BuildAction>` | Pre-deploy hook — destructive prep before diff-apply |
| `<None Include="*.sql">` with `<BuildAction>PostDeploy</BuildAction>` | Post-deploy hook — idempotent seeds and fixups after diff-apply |
| `<ArtifactReference>` with `HintPath` targeting `master.dacpac` | System dacpac cross-database ref — expected; record but do not flag |
| `<ArtifactReference>` with `HintPath` targeting another project dacpac | Composite project (e.g., DMS's `Oda.Database`) — cross-database ref must travel together |

Detection is mechanical: presence of one signal triggers the matching
reference pattern. Overlap with `sqlserver-extraction-patterns` is
explicit — that skill emits shape-level findings across SSDT and
migration-script repos; this skill emits the deeper SSDT-specific
surface when the shape is declarative.

## Companion Technologies

The core methodology above targets SSDT `.sqlproj` projects producing
DACPACs deployed by `sqlpackage.exe`. Two companion references frame
the declarative-versus-imperative distinction and the MSBuild surface
so extraction stays faithful.

- **`references/sqlproj-msbuild-structure.md`** — `<Project Sdk="Microsoft.Data.Tools.Sql.Sdk">`
  new-style versus legacy `.sqlproj` XML, the `<Build Include>` vs
  `<None Include>` compile-versus-carry distinction, `<PreDeploy>` and
  `<PostDeploy>` hooks, DSP version inventory and target-platform
  mapping, `<SqlCmdVariable>` declaration surface, `.refactorlog`
  anatomy, `.publish.xml` schema, `<ArtifactReference>` cross-database
  refs, and the DACPAC zip structure (`model.xml`, `origin.xml`,
  `dataschema.xml`).
- **`references/declarative-vs-imperative-schema-mgmt.md`** — how SSDT
  diffs (declarative snapshot + sqlpackage diff-apply) versus how
  Flyway/DbUp/Liquibase apply (ordered imperative migrations),
  refactorlog rename semantics versus migration-file rename semantics,
  idempotent post-deploy patterns, `BlockOnPossibleDataLoss` and its
  imperative counterparts, and migration-to-target planning for
  SSDT to Flyway / DbUp / Prisma / Atlas / EF-Core-Migrations, with the
  risk trade-offs of each target.

## Gotchas
- **A `.sqlproj` is MSBuild XML, not T-SQL code.** Parse it as XML.
  Grepping for `CREATE TABLE` in the `.sqlproj` itself will find
  nothing — the DDL lives in the individual `.sql` files referenced by
  `<Build Include>` items. Treating the project file as code is the
  `sqlproj-parsed-as-code-not-xml` failure class.
- **DSP version is pinned, not derived.** `<DSP>Microsoft.Data.Tools.Schema.Sql.Sql130DatabaseSchemaProvider</DSP>`
  says SQL Server 2016 (`Sql130`), regardless of what version the
  developer runs locally. The pinned DSP is authoritative for deploy
  target; do not guess from the developer machine.
- **`<Build Include>` means "compile into the dacpac"; `<None Include>`
  means "don't compile, just carry".** If a developer accidentally
  flips one, the artifact is wrong — objects vanish from the DACPAC
  or side scripts get compiled as DDL. Always cross-check the
  `<BuildAction>` when present; do not assume from the file extension.
- **Pre-deploy and post-deploy hooks surround the diff-apply.**
  Pre-deploy runs before sqlpackage diffs; post-deploy runs after.
  Post-deploy is where idempotent seed data lives — the script must
  tolerate repeated runs (`IF NOT EXISTS` style). Pre-deploy is where
  destructive prep goes (dropping constraints before a diff-apply that
  would not otherwise drop them). Conflating the two produces the
  `predeploy-postdeploy-conflated` failure class.
- **`.refactorlog` is authoritative for renames and must never be
  edited or deleted.** Without a refactorlog entry, `sqlpackage`
  drops-and-recreates the object instead of renaming, losing data.
  Discarding the refactorlog during extraction is the
  `refactorlog-discarded` failure class; always emit every entry.
- **SQLCMD variables (`$(VarName)`) carry environment-specific values.**
  Declared in `<SqlCmdVariable>` with `<Value>` and `<DefaultValue>`.
  Redact any variable whose name or value suggests credentials,
  connection strings, or secrets — publishing the raw value into the
  extracted manifest is the `sqlcmd-variable-leaked` failure class.
- **`.dacpac` is a ZIP — same family as `.docx`, `.jar`, `.xlsx`.**
  `unzip -l` lists the contents. The declarative schema sits in
  `model.xml`. Extract offline; do not require a SQL Server instance
  to inspect a committed DACPAC.
- **Target-platform mismatch silently fails at deploy.** A project
  targeting `Sql150` (2019) will not deploy to a `Sql130` (2016)
  server — sqlpackage raises at apply time. Emit the mismatch as a
  finding at extract time so the disposition step can plan.
- **`<ArtifactReference>` composite projects travel together.** DMS's
  `Dms.Database` depends on `Oda.Database` via `<ArtifactReference>`.
  Extracting `Dms.Database` without `Oda.Database` produces an
  incomplete model; the DACPAC will not build. Always emit a
  composite-project finding when an `<ArtifactReference>` targets
  another project dacpac rather than a system dacpac.
- **Publish-profile safety flags matter for production posture.**
  `BlockOnPossibleDataLoss=false` is a blast-radius risk; emit it as
  a finding rather than silently recording the raw value.
- **Pre-deploy and post-deploy scripts can have their own SQLCMD
  variables.** Do not assume variables only live at the project root;
  scan the hook scripts as well.

## Quality Rules
- [ ] Every `.sqlproj` in the repo has a project record with
      `project_path`, `project_style`, `dsp_moniker`,
      `target_platform_resolved`, and `output_dacpac_path` populated.
- [ ] Every `<Build Include>` and `<None Include>` item has a row in
      `ssdt-build-item-manifest.json` with its classified object kind
      (for `<Build>`) or `<BuildAction>` (for `<None>`) and a
      `{repo}:{file}:{line}` citation to the sqlproj entry.
- [ ] Every `.refactorlog` operation has a row in
      `ssdt-refactorlog-manifest.json` with operation kind, element
      kind, old name, new name, and source citation; projects without
      a refactorlog emit an explicit `no-refactorlog-present` finding.
- [ ] Every `.publish.xml` has a profile record; every SQLCMD variable
      in it is recorded; values are redacted when the name or value
      suggests credentials or connection strings — no raw secrets in
      any manifest.
- [ ] Every `<ArtifactReference>` is recorded as either a system-dacpac
      ref (expected) or a composite-project ref (travels together).
- [ ] When the modernization target is imperative (Flyway, DbUp,
      EF-Core-Migrations), `ssdt-to-migration-conversion-plan.json` is
      emitted with a baseline migration, refactorlog-preserving rename
      migrations, and pre/post-deploy lifecycle translations.
- [ ] Target-platform drift between the pinned DSP and the catalog
      entry's recorded production server version is surfaced as a
      `target-platform-mismatch` finding.
- [ ] Every manifest validates against its schema via
      `olympus.validators.schema_validator` with zero errors; every
      finding carries both `{artifact}:{section}:{finding-id}` and at
      least one `{repo}:{file}:{line}` citation.

## Common Failure Modes
| Failure Mode | Symptom | Prevention |
|---|---|---|
| `.sqlproj` parsed as T-SQL instead of MSBuild XML | Project manifest is empty; DSP and target platform missing; build items not enumerated | Always parse `.sqlproj` as XML; never grep it for DDL — DDL lives in referenced `.sql` files |
| DSP version misread or ignored | Target platform reported as "SQL Server" with no version; deployment drift undetected | Read `<DSP>`; map via the table in `references/sqlproj-msbuild-structure.md`; never infer from the developer machine |
| `<Build>` vs `<None>` confused | Side scripts compiled into dacpac, or DDL objects dropped from dacpac; deployment artifact wrong | Classify each item strictly by its XML element name and `<BuildAction>` child; never infer from file path |
| Refactorlog discarded during extraction | Rename operations at deploy become drop-and-recreate; data loss on production push | Emit every `<Operation>` in every `.refactorlog`; never treat the file as build-output ephemera |
| Pre-deploy and post-deploy conflated | Idempotency guards missing on seed scripts, or destructive prep runs after diff-apply instead of before | Record `<BuildAction>` per script; translate to lifecycle hook semantics, not ordering-by-filename |
| SQLCMD variable value leaked into manifest | Secret scan trips on the emitted Extract artifact; credentials in Git history | Redact values whose variable name matches `*Password*|*Secret*|*Key*` or whose value matches connection-string patterns |
| Publish-profile safety flag missed | `BlockOnPossibleDataLoss=false` shipped to production without review; deploy drops data silently | Record every safety flag explicitly; flag `BlockOnPossibleDataLoss=false` and `DropObjectsNotInSource=true` for gate review |
| `<ArtifactReference>` composite ref skipped | DACPAC build fails with missing-schema errors; DMS's Oda.Database not extracted alongside Dms.Database | Emit one composite-project finding per cross-project `<ArtifactReference>`; extract the referenced project in the same pass |
| DACPAC zip not opened | `model.xml` not inspected; declarative schema opaque; extraction relies on re-parsing every `.sql` file instead | Use `unzip -l` and extract `model.xml`/`origin.xml`/`dataschema.xml` offline; record the model hash |
| Target-platform mismatch silenced | Sqlpackage fails at deploy time; disposition step had no warning | Compare pinned DSP to catalog-recorded production server version; emit `target-platform-mismatch` finding when they differ |

## Handoff Summary
When this skill completes, verify:
1. Every `.sqlproj` has a project-manifest row with DSP, target platform,
   and output dacpac path resolved and cited.
2. Every `<Build Include>` and `<None Include>` item is classified and
   emitted into the build-item manifest with its `<BuildAction>`
   recorded.
3. Every `.refactorlog` operation is preserved in the refactorlog
   manifest; no rename metadata discarded.
4. Every `.publish.xml` has its safety flags recorded and every
   `<SqlCmdVariable>` has credentials redacted.
5. Every `<ArtifactReference>` is classified as system-dacpac or
   composite-project; composite refs travel as a pair.
6. When the modernization target is imperative, the conversion plan is
   emitted with baseline + rename + lifecycle-hook translations.

Then proceed to: `sqlserver-extraction-patterns` for high-level T-SQL
dialect and programmability findings that complement the SSDT surface;
`ef-core-schema-extractor` when the consuming application layer is
EF-Core-bound and a code-first migration path is in scope; and, for
modernization targets with a migration-script shape, the target-tool
generator (Flyway writer, DbUp writer, EF-Core-Migrations writer) which
consumes `ssdt-to-migration-conversion-plan.json`. The next gate is
**G-DT** (Discovery / Extract Traceability) where the six SSDT
manifests must be accepted before Design begins.

## References
- `schemas/discovery/application-catalog-entry.schema.json` — canonical
  `database` enum and SSDT signal surface.
- `references/sqlproj-msbuild-structure.md` — MSBuild XML anatomy for
  `.sqlproj`: SDK-style vs legacy roots, `<Build>` vs `<None>`,
  `<PreDeploy>`/`<PostDeploy>`, DSP version table and target-platform
  mapping, `<SqlCmdVariable>` surface, `.refactorlog` XML anatomy,
  `.publish.xml` schema, `<ArtifactReference>` cross-database refs, and
  DACPAC zip structure.
- `references/declarative-vs-imperative-schema-mgmt.md` — declarative
  (SSDT/Prisma/Atlas) versus imperative (Flyway/DbUp/Liquibase/EF-Core-
  Migrations) schema-management contrast, refactorlog rename semantics,
  idempotent post-deploy patterns, `BlockOnPossibleDataLoss` and its
  counterparts, and migration-target planning trade-offs.

## Changelog
- 0.1.0 (2026-05-06) — Initial skill scaffolded for the SSDT-specific
  extraction surface. Covers `.sqlproj` MSBuild XML parsing, DSP and
  target-platform resolution, `<Build>`/`<None>` item classification,
  `.refactorlog` walk, `.publish.xml` safety-flag and SQLCMD-variable
  inventory, `<ArtifactReference>` composite-project detection, DACPAC
  zip offline inspection, and SSDT-to-migration-tool conversion
  planning. Full enrichment level; feeds `sqlserver-extraction-patterns`
  and the target-tool generators downstream.
