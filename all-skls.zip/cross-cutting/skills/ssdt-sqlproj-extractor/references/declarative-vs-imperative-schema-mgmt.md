# Declarative versus Imperative Schema Management

SSDT is declarative. Flyway, DbUp, Liquibase, and hand-rolled
`V001__*.sql` directories are imperative. Prisma, Atlas, Skeema, and
Sqitch are declarative. EF Core Migrations is imperative. The two
families are not interchangeable surfaces; converting between them
preserves the model but not the operational posture, and the conversion
must be planned. This reference frames the distinction so the extractor
emits faithful conversion plans and the risk trade-offs are explicit.

## Declarative shape

A declarative schema-management tool stores the **current desired
state** of the database. Every table, view, proc, and function is a
first-class file describing what the object should look like right now.
There is no ordered history of migrations; there is a snapshot.

To deploy, the tool:

1. Compares the desired state to the actual state of the target
   database.
2. Computes a diff: which objects to create, alter, or drop.
3. Generates and executes DDL that transforms actual into desired.

SSDT is the canonical example. The `.sqlproj` holds one `.sql` file per
object; the DACPAC is the compiled snapshot; `sqlpackage.exe`
diff-applies. Prisma's `schema.prisma` and Atlas's HCL schemas follow
the same pattern.

Strengths: single source of truth for the desired state; object-level
diffs are easy to review; renames are explicit via a rename ledger
(SSDT's `.refactorlog`, Atlas's rename directives); the snapshot file
tree is the current-state documentation.

Weaknesses: the diff engine decides how to transform actual into
desired, and its choice may not be what the operator wants (e.g., a
column-type change may be implemented as drop-and-recreate rather than
in-place `ALTER`, losing data); out-of-band drift on the server is
reconciled silently at the next deploy; complex data migrations that
span multiple DDL steps have no natural expression in a declarative
snapshot.

## Imperative shape

An imperative schema-management tool stores the **ordered history of
changes**. Every change is a numbered migration file with an explicit
SQL script. The tool tracks which migrations have been applied in a
metadata table; new migrations run forward in order.

To deploy, the tool:

1. Reads the applied-migrations table from the target database.
2. Identifies the next unapplied migration in sequence.
3. Executes that migration's script as-is.
4. Records the applied migration in the metadata table.
5. Repeats until all migrations are applied.

Flyway, DbUp, Liquibase, Sqitch, Alembic, Rails Migrations, EF Core
Migrations, and hand-rolled `V001__*.sql` directories are all
imperative. The migration scripts are authoritative; there is no
declarative snapshot.

Strengths: the deploy is predictable — the script you wrote is the
script that runs; data migrations that need multi-step transformations
are natural; out-of-band drift is detected (Flyway's checksum validation
against the metadata table); every environment sees the same sequence.

Weaknesses: no single source of truth for the current state — the
desired state is the sum of all applied migrations, and reconstructing
it requires replaying every migration; renames are expressed as
`sp_rename`/`ALTER TABLE ... RENAME` in a migration, easy to miss and
trivial to forget; reviewing a migration file tells you what changed,
not what the final object looks like.

## Refactorlog rename semantics versus migration rename

SSDT's `.refactorlog` is a separate ledger from the declarative `.sql`
files. When a rename happens:

- The `.sql` file for the renamed object is updated to the new name.
- The `.refactorlog` gets an `<Operation>` entry mapping old name to
  new name.
- At deploy, `sqlpackage` sees both the name change in the model and
  the refactorlog entry, and emits `sp_rename` instead of drop-and-
  recreate.

Without the refactorlog entry, `sqlpackage` sees only that an object
named `Customers.Customer_ID` no longer exists and an object named
`Customers.CustomerId` now exists — it will drop the old column and
create the new, losing every row's data.

In imperative tools, rename is a first-class DDL statement in a
migration file:

```sql
-- V042__rename_customer_id_to_customerid.sql
EXEC sp_rename 'dbo.Customers.Customer_ID', 'CustomerId', 'COLUMN';
```

Converting SSDT to imperative must translate every refactorlog
operation into an `sp_rename` migration, ordered before the
declarative-snapshot migrations that reference the new name. Losing
this step means the baseline migration has columns that never existed
in production.

## Idempotent post-deploy patterns

SSDT post-deploy scripts run on every deploy. They must tolerate
repeated execution without duplicating data or failing on re-insert.
Canonical patterns:

```sql
-- IF NOT EXISTS guard
IF NOT EXISTS (SELECT 1 FROM dbo.Roles WHERE RoleName = 'Administrator')
  INSERT INTO dbo.Roles (RoleName) VALUES ('Administrator');

-- MERGE with stable natural key
MERGE dbo.ReferenceData AS target
USING (VALUES ('US', 'United States'), ('CA', 'Canada')) AS source (Code, Name)
  ON target.Code = source.Code
WHEN NOT MATCHED THEN INSERT (Code, Name) VALUES (source.Code, source.Name)
WHEN MATCHED AND target.Name <> source.Name THEN UPDATE SET Name = source.Name;
```

Imperative tools achieve the same result by running each seed as its
own migration exactly once — the `V005__seed_roles.sql` migration runs
on first deploy and never again. No idempotency guard is needed, but
schema drift (someone deletes the seed row manually) is not recovered.

When converting SSDT post-deploy to an imperative target, the choice
is explicit: (a) emit the seed as a single `V_seed.sql` migration that
runs once — matches imperative semantics but loses idempotent drift
recovery; (b) emit the seed as a `repeatable` migration (Flyway's
`R__seed_roles.sql`) that runs on every deploy with its checksum
guarded — preserves the idempotent-on-every-deploy behavior.

## `BlockOnPossibleDataLoss` and its counterparts

SSDT's `BlockOnPossibleDataLoss` is a publish-profile flag that halts
the deploy if `sqlpackage` detects any step that might lose data
(narrowing a column, dropping a column with data, converting types
with loss). It is a safety catch — the developer must explicitly lift
the block to proceed.

Imperative tools have no such flag because the operator writes the
migration directly; data loss is a choice made in the script. The
equivalent safety in imperative shape is review: the migration diff is
the artifact the team reviews, and destructive statements (`DROP
COLUMN`, narrowing `ALTER`) are flagged at review time.

When converting SSDT to imperative, preserve the posture by: (a)
generating migrations in two classes — "safe" migrations and "review
required" migrations; (b) annotating the latter with a comment header
listing which SSDT safety flag they would have tripped; (c) requiring
explicit reviewer sign-off on the review-required class in the PR
template.

## Migration-to-target planning trade-offs

When modernization targets a different schema-management tool, the
conversion plan depends on the target's shape:

- **SSDT to Prisma (declarative to declarative).** Model-preserving.
  Emit a single plan step: translate the DACPAC model into
  `schema.prisma`. Rename history is preserved via Prisma's own migrate
  rename mechanism. Post-deploy scripts become seed scripts. Risk: low;
  Prisma's introspection from an existing SSDT-deployed database will
  generate a `schema.prisma` close to the hand-translated version.
- **SSDT to Atlas (declarative to declarative).** Model-preserving.
  Translate the DACPAC model into Atlas HCL. Atlas supports rename
  annotations; map each refactorlog operation to an Atlas rename.
  Risk: low.
- **SSDT to Flyway (declarative to imperative).** Requires a baseline
  migration reconstructed from the DACPAC. Each refactorlog operation
  becomes a pre-baseline rename migration or is encoded into the
  baseline itself if the baseline uses the new name. Post-deploy
  scripts become `R__*.sql` repeatable migrations (for idempotent
  seeds) or `V_*.sql` one-shot migrations. Risk: medium; the baseline
  must be reviewed object-by-object.
- **SSDT to DbUp (declarative to imperative).** Similar to Flyway. DbUp
  has no `repeatable` concept, so idempotent seeds must be translated
  either to one-shot migrations with `IF NOT EXISTS` guards or to
  always-run script classes (DbUp's `Journal` exclusion). Risk:
  medium.
- **SSDT to EF Core Migrations (declarative to imperative).** Requires
  translation of the DACPAC into a first migration via `dotnet ef
  migrations add InitialCreate` against a scaffolded `DbContext`.
  Rename history is preserved only if the scaffolded model explicitly
  uses `[Column("NewName")]` annotations; otherwise renames are lost.
  Risk: high — the fidelity of the first migration depends on the
  scaffolded model, and post-deploy scripts have no natural EF-Core
  equivalent.

The conversion-plan manifest must pick one target, enumerate the plan
steps, and cite the SSDT inputs each step consumes. For any
medium/high-risk target, surface a recommendation for additional human
review before the modernization Generate step runs.
