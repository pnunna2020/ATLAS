# `.sqlproj` MSBuild Structure

This reference documents the MSBuild XML surface of an SSDT `.sqlproj`
project so the extractor parses it faithfully. A `.sqlproj` is not code.
It is an MSBuild project file — XML with a specific schema, a specific
set of item groups, and a specific relationship to the `.sql` files it
references. Parsing strategies that treat a `.sqlproj` as text or as
T-SQL will miss structure and emit a broken manifest.

## Root element: SDK-style versus legacy

New-style SSDT projects (introduced with Visual Studio 2022 17.8+) use
the SDK attribute on the root `<Project>` element:

```xml
<Project Sdk="Microsoft.Data.Tools.Sql.Sdk/0.2.0-preview">
  <PropertyGroup>
    <TargetFramework>netstandard2.1</TargetFramework>
    <DSP>Microsoft.Data.Tools.Schema.Sql.Sql160DatabaseSchemaProvider</DSP>
    ...
  </PropertyGroup>
</Project>
```

Legacy `.sqlproj` files use no SDK attribute and import the SSDT targets
explicitly at the bottom:

```xml
<Project ToolsVersion="Current" DefaultTargets="Build"
         xmlns="http://schemas.microsoft.com/developer/msbuild/2003">
  <Import Project="$(MSBuildExtensionsPath)\Microsoft\VisualStudio\v$(VisualStudioVersion)\SSDT\Microsoft.Data.Tools.Schema.SqlTasks.targets" />
  ...
</Project>
```

Record the style as `sdk-style` or `legacy` in the project manifest.
SDK-style projects default to implicit file globbing — every `.sql`
under the project root is treated as a `<Build>` item unless excluded.
Legacy projects require explicit `<Build Include>` entries. Applying
SDK-style assumptions to a legacy project under-counts compile items;
applying legacy assumptions to an SDK-style project over-counts because
the explicit entries are missing.

## DSP and target platform

The `<DSP>` element inside the first `<PropertyGroup>` pins the Data-Tier-App
Specification version — the target SQL Server engine:

| DSP moniker | Target platform |
|---|---|
| `Sql100DatabaseSchemaProvider` | SQL Server 2008 |
| `Sql105DatabaseSchemaProvider` | SQL Server 2008 R2 |
| `Sql110DatabaseSchemaProvider` | SQL Server 2012 |
| `Sql120DatabaseSchemaProvider` | SQL Server 2014 |
| `Sql130DatabaseSchemaProvider` | SQL Server 2016 |
| `Sql140DatabaseSchemaProvider` | SQL Server 2017 |
| `Sql150DatabaseSchemaProvider` | SQL Server 2019 |
| `Sql160DatabaseSchemaProvider` | SQL Server 2022 |
| `SqlAzureV12DatabaseSchemaProvider` | Azure SQL Database |
| `SqlAzureDwDatabaseSchemaProvider` | Azure Synapse Dedicated Pool |

The DSP is authoritative for deployment target. A project pinned to
`Sql150` will not build a DACPAC that deploys to a SQL Server 2016
instance — `sqlpackage` will raise at apply time. Record both the raw
moniker and the resolved platform; surface mismatches as findings.

## `<Build Include>` versus `<None Include>`

The two item group element types carry fundamentally different
semantics:

- **`<Build Include="path.sql">`** — compile this `.sql` into the
  DACPAC model. Used for every schema object: tables, views, procs,
  functions, triggers, indexes, user-defined types, synonyms, roles,
  schemas, assemblies, certificates.
- **`<None Include="path.sql">`** — carry the file with the project
  but do not compile it into the DACPAC. Used for pre-deploy scripts,
  post-deploy scripts, seed data, ad-hoc scripts, developer notes.

A `<None>` item typically has a child `<BuildAction>`:

```xml
<None Include="Scripts\Post-Deployment\SeedRoles.sql">
  <BuildAction>PostDeploy</BuildAction>
</None>
<None Include="Scripts\Pre-Deployment\DropCdc.sql">
  <BuildAction>PreDeploy</BuildAction>
</None>
```

The `PreDeploy` and `PostDeploy` build actions cause the referenced
script to execute on the target database at the corresponding phase of
the deployment — before the diff-apply for pre-deploy, after for
post-deploy. Only one script per project may carry each of these
actions; multiple scripts chain via `:r` SQLCMD includes.

Confusing `<Build>` and `<None>` is the most common shape error: a
developer flipping one ships a DACPAC that either compiles side scripts
as DDL or omits schema objects entirely.

## Pre-deploy and post-deploy hooks

Pre-deploy runs **before** `sqlpackage` computes and applies the diff.
Use cases: dropping constraints that would otherwise block the
diff-apply; disabling triggers; staging a temporary table for data
preservation across a destructive change.

Post-deploy runs **after** the diff-apply completes. Use cases:
idempotent seed data (roles, reference data, system users); index
rebuilds; permissions fixups that cannot be modeled declaratively.

Post-deploy scripts must be idempotent — they run on every deploy, not
just the first. The canonical pattern is `IF NOT EXISTS (...) INSERT ...`
guards on every row, or a `MERGE` statement with a stable natural key.
Non-idempotent post-deploy scripts duplicate seed data on re-deploy.

## `<SqlCmdVariable>` declaration

SQLCMD variables parameterize scripts for environment-specific values.
Declared in the project's `<ItemGroup>`:

```xml
<ItemGroup>
  <SqlCmdVariable Include="ReportingDbName">
    <DefaultValue>Reporting_Dev</DefaultValue>
    <Value>$(SqlCmdVar__1)</Value>
  </SqlCmdVariable>
</ItemGroup>
```

Referenced in scripts as `$(ReportingDbName)`. Values are overridden at
publish time via `.publish.xml` profiles or command-line `/v:` flags.
Any variable whose name or value suggests credentials must be redacted
during extraction — the default-value field is frequently used for
dev-environment connection strings that were never meant to leave the
repo.

## `.refactorlog` anatomy

When a developer renames an object in the SSDT project (via the Visual
Studio refactor menu), SSDT appends an entry to a `.refactorlog` file
sibling to the `.sqlproj`. This file is the **rename ledger** — it tells
`sqlpackage` that an old name maps to a new name so the deploy issues
`sp_rename` instead of drop-and-recreate.

```xml
<Operations Version="1.0"
            xmlns="http://schemas.microsoft.com/sqlserver/dac/Serialization/2012/02">
  <Operation Name="Rename Refactor"
             Key="abcd1234-..."
             ChangeDateTime="2024-03-15T10:22:11.000">
    <Property Name="ElementName" Value="[dbo].[Customers].[Customer_ID]" />
    <Property Name="ElementType" Value="SqlSimpleColumn" />
    <Property Name="ParentElementName" Value="[dbo].[Customers]" />
    <Property Name="NewName" Value="CustomerId" />
  </Operation>
</Operations>
```

Every `<Operation>` must be recorded. Discarding the refactorlog during
extraction or during migration to another tool means every historical
rename becomes a drop-and-recreate at the next deploy — catastrophic
data loss on columns that hold production data.

## `.publish.xml` profile schema

A publish profile captures target-specific deployment settings:

```xml
<Project ToolsVersion="14.0"
         xmlns="http://schemas.microsoft.com/developer/msbuild/2003">
  <PropertyGroup>
    <TargetDatabaseName>MyApp_Prod</TargetDatabaseName>
    <TargetConnectionString>Data Source=...;Integrated Security=True;</TargetConnectionString>
    <BlockOnPossibleDataLoss>True</BlockOnPossibleDataLoss>
    <IncludeTransactionalScripts>True</IncludeTransactionalScripts>
    <DeployDatabaseInSingleUserMode>False</DeployDatabaseInSingleUserMode>
    <DropObjectsNotInSource>False</DropObjectsNotInSource>
    <DoNotAlterChangeDataCaptureObjects>True</DoNotAlterChangeDataCaptureObjects>
    <IgnorePermissions>False</IgnorePermissions>
    <GenerateSmartDefaults>False</GenerateSmartDefaults>
  </PropertyGroup>
  <ItemGroup>
    <SqlCmdVariable Include="ReportingDbName">
      <Value>Reporting_Prod</Value>
    </SqlCmdVariable>
  </ItemGroup>
</Project>
```

Key safety flags to record:

- `BlockOnPossibleDataLoss` — when `True`, any deploy step that
  `sqlpackage` believes might lose data halts the deploy.
- `IncludeTransactionalScripts` — when `True`, wraps each DDL batch in
  a transaction; rollback on failure.
- `DeployDatabaseInSingleUserMode` — when `True`, switches the DB to
  single-user mode for the deploy.
- `DropObjectsNotInSource` — when `True`, drops any object that exists
  on the server but is not in the project. Destructive; rarely enabled.
- `DoNotAlterChangeDataCaptureObjects` — preserves CDC configuration.
- `IgnorePermissions` — skips GRANT/DENY/REVOKE reconciliation.

Redact `TargetConnectionString`. Redact any `<SqlCmdVariable>` value
that looks credential-bearing.

## `<ArtifactReference>` cross-database refs

Projects can reference other DACPACs for cross-database objects
(synonyms, views that select from another database, three-part-name
stored procedures):

```xml
<ItemGroup>
  <ArtifactReference Include="..\Oda.Database\bin\Debug\Oda.Database.dacpac">
    <HintPath>..\Oda.Database\bin\Debug\Oda.Database.dacpac</HintPath>
    <SuppressMissingDependenciesErrors>False</SuppressMissingDependenciesErrors>
    <DatabaseVariableLiteralValue>Oda</DatabaseVariableLiteralValue>
  </ArtifactReference>
  <ArtifactReference Include="$(DacPacRootPath)\Extensions\Microsoft\SQLDB\Extensions\SqlServer\130\SqlSchemas\master.dacpac">
    <HintPath>$(DacPacRootPath)\...\master.dacpac</HintPath>
    <SuppressMissingDependenciesErrors>True</SuppressMissingDependenciesErrors>
    <DatabaseVariableLiteralValue>master</DatabaseVariableLiteralValue>
  </ArtifactReference>
</ItemGroup>
```

Classify each reference as system (shipped with SQL Server —
`master.dacpac`, `msdb.dacpac`) or composite (another application
dacpac). Composite references travel as a pair — extracting one
without the other produces an incomplete model.

## DACPAC zip structure

A `.dacpac` is a ZIP file. `unzip -l` on a DACPAC lists:

- `model.xml` — the complete declarative schema (every table, view,
  proc, function rendered as XML)
- `origin.xml` — metadata about the origin project, DSP version,
  model hash
- `dataschema.xml` — data-schema metadata separate from the model
- `logicalobjects.xml` — optional, in some DACPACs
- `[Content_Types].xml` — zip package manifest
- `_rels/.rels` — zip package relationships

Extraction can always inspect a committed DACPAC offline via `unzip`;
there is no need for a running SQL Server instance or Visual Studio.
Record the `model.xml` hash as a snapshot identifier — the same
`model.xml` produced from the same source will hash identically.
