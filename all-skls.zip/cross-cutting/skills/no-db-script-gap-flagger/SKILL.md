---
name: no-db-script-gap-flagger
description: >
  Detect repositories that ship a data-access layer (DAL) targeting
  a database but ship NO database scripts (`.sql`, `.pkb`, `.sqlproj`,
  `.bak`, schema dump). The DAL references tables and stored procs
  that must exist somewhere, but the source of truth for that schema
  is not in the repo. CHAPS is the ATLAS case: `DataAccesslayer`
  ships zero DB scripts. Likely target is the shared AAM MSS Oracle
  schema also used by AMCS / MedXPress / DIWS — but without scripts,
  modernization cannot confidently target the schema. Runs as
  Discovery conditional when an app has DAL projects but no `db/`
  directory. Triggers on DB-script gap audit or
  @no-db-script-gap-flagger.
agent: sonnet
allowed-tools:
  - Read
  - Write
  - Grep
  - Glob
validation_commands:
  - "python -m olympus.validators.schema_validator db-script-gap-findings.json"
  - "python -m olympus.validators.schema_validator inferred-schema-dependencies.json"
supported_stacks:
  - any
anti_target_stacks:
  - schema-in-repo
  - static-site
  - no-data-access
failure_classes:
  - shared-schema-in-sibling-repo-missed
  - connection-string-env-var-untraced
  - in-memory-db-mistaken-as-missing
  - schema-via-ef-migrations-missed
benchmark_tags:
  - discovery-database
  - db-script-gap
  - shared-schema-attribution
---

# no-db-script-gap-flagger

## Purpose
Flag apps where the DAL references a schema not present in the
repo. Identify likely canonical home (sibling repo, portfolio-
level schema) so modernization can resolve the dependency.

## Inputs
- Repository tree.
- Optional: sibling repos' `db/` directories for correlation.

## Outputs
- `db-script-gap-findings.json` — `{repo, has_db_directory,
  has_sql_files, has_sqlproj, has_pkb, has_bak, has_ef_migrations,
  dal_present, dal_target_type, likely_canonical_schema_home}`.
- `inferred-schema-dependencies.json` — table/proc/view names
  referenced in DAL code, cross-referenced against sibling repos.

## Methodology
1. Detect DAL presence: project names matching `*DAL*`,
   `*DataAccess*`, `*Repository*`, `*Context*`; ADO.NET or ORM
   references.
2. Check for schema artifacts: `db/**/*.sql`, `*.sqlproj`, `*.pkb`,
   `*.pks`, `*.bak`, `Migrations/` (EF).
3. If DAL + no schema, grep DAL code for table/proc names.
4. Cross-reference against sibling repos' schema artifacts.

## Tech-Stack Dispatch

No external references.

## Gotchas
- EF Core `Migrations/` folder IS the schema source; don't flag if
  present.
- In-memory DBs for testing don't require schema scripts; check
  `UseInMemoryDatabase`.
- Portfolio-level schema: AAM apps share MSS Oracle (MedXPress
  holds the canonical dump).
- Connection string may be env-var-injected; grep ENV / appsettings
  for DB hostnames.

## Quality Rules
- [ ] Every DAL without schema flagged.
- [ ] Inferred canonical home documented when resolvable.
- [ ] EF migrations / in-memory DB not flagged as gaps.
- [ ] Every record cites `{repo}:{file}:{line}`.

## Common Failure Modes

| Failure Mode | Symptom | Prevention |
|---|---|---|
| Shared schema missed | CHAPS flagged "no schema" when MSS is target | Cross-reference sibling repos |
| EF migrations mistaken as missing | App has Migrations/ but flagged | Detect `Migrations/` folder |
| In-memory DB mistaken as missing | Test-only app flagged | Detect `UseInMemoryDatabase` |

## Handoff Summary
Schema gap findings emitted. Proceed to
`legacy-database-archaeologist`.

## References
None.

## Changelog
- 0.1.0 (2026-05-07) — Initial skill. Authored as ATLAS-R-19.
