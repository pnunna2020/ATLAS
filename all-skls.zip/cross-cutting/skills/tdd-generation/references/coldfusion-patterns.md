# TDD Generation — Target: Python/FastAPI (from ColdFusion)

Reference for TDD Generation when producing Python/FastAPI code from ColdFusion source.

## Test Framework Stack

| Tool | Purpose | Install |
|------|---------|---------|
| pytest | Test runner and framework | `pip install pytest` |
| pytest-asyncio | Async test support | `pip install pytest-asyncio` |
| pytest-cov | Coverage reporting | `pip install pytest-cov` |
| httpx | Async HTTP client for API tests | `pip install httpx` |
| pytest-mock | Mockist-style mocking | `pip install pytest-mock` |
| factory-boy | Test data factories | `pip install factory-boy` |

## Coverage Configuration

### Thresholds
- Tier 1 (critical): 90% branch coverage minimum
- Tier 2 (standard): 80% branch coverage minimum

### Commands
```bash
# Run tests with coverage
pytest --cov=src --cov-report=term-missing --cov-branch

# Generate JSON report for programmatic validation
pytest --cov=src --cov-report=json --cov-branch

# Generate HTML report for human review
pytest --cov=src --cov-report=html --cov-branch
```

### Configuration (pyproject.toml)
```toml
[tool.pytest.ini_options]
asyncio_mode = "auto"
testpaths = ["tests"]
addopts = "--strict-markers -ra"

[tool.coverage.run]
branch = true
source = ["src"]
omit = ["*/tests/*", "*/migrations/*"]

[tool.coverage.report]
fail_under = 80
show_missing = true
```

## Project Structure

```
src/
├── {module}/
│   ├── __init__.py
│   ├── router.py          ← FastAPI route handlers
│   ├── service.py         ← business logic
│   ├── models.py          ← SQLAlchemy models
│   ├── schemas.py         ← Pydantic request/response models
│   └── dependencies.py    ← FastAPI dependency injection
tests/
├── conftest.py            ← shared fixtures
├── {module}/
│   ├── __init__.py
│   ├── test_router.py     ← API endpoint tests
│   ├── test_service.py    ← business logic unit tests
│   └── test_models.py     ← model validation tests
```

## Test Patterns

### Unit Test — Service Layer
```python
# tests/users/test_service.py
import pytest
from unittest.mock import AsyncMock
from src.users.service import UserService

@pytest.fixture
def mock_repo():
    repo = AsyncMock()
    repo.get_by_id.return_value = {"id": 1, "name": "Alice", "active": True}
    return repo

async def test_get_user_returns_user_when_found(mock_repo):
    service = UserService(repo=mock_repo)
    user = await service.get_user(1)
    assert user["name"] == "Alice"
    mock_repo.get_by_id.assert_called_once_with(1)

async def test_get_user_raises_not_found_when_missing(mock_repo):
    mock_repo.get_by_id.return_value = None
    service = UserService(repo=mock_repo)
    with pytest.raises(UserNotFoundError):
        await service.get_user(999)
```

### API Test — FastAPI Endpoint
```python
# tests/users/test_router.py
import pytest
from httpx import AsyncClient, ASGITransport
from src.main import app

@pytest.fixture
async def client():
    transport = ASGITransport(app=app)
    async with AsyncClient(transport=transport, base_url="http://test") as ac:
        yield ac

async def test_get_user_endpoint(client):
    response = await client.get("/api/users/1")
    assert response.status_code == 200
    data = response.json()
    assert "id" in data
    assert "name" in data
```

### Database Test — SQLAlchemy Fixtures
```python
# tests/conftest.py
import pytest
from sqlalchemy.ext.asyncio import create_async_engine, AsyncSession
from sqlalchemy.orm import sessionmaker
from src.database import Base

@pytest.fixture(scope="session")
async def engine():
    engine = create_async_engine("sqlite+aiosqlite:///:memory:")
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)
    yield engine
    await engine.dispose()

@pytest.fixture
async def db_session(engine):
    async_session = sessionmaker(engine, class_=AsyncSession, expire_on_commit=False)
    async with async_session() as session:
        yield session
        await session.rollback()
```

### Parametrized Tests (for CF Type Coercion Edge Cases)
```python
# CF silently coerces types — test that Python handles these explicitly
@pytest.mark.parametrize("input_val,expected", [
    ("5", 5),           # string → int (CF does this silently)
    ("true", True),     # string → bool
    ("3.14", 3.14),     # string → float
    ("", None),         # empty string → null (CF treats "" as falsy)
])
def test_input_conversion(input_val, expected):
    result = convert_cf_input(input_val)
    assert result == expected
```

## Mocking Patterns

### unittest.mock (standard library)
```python
from unittest.mock import patch, MagicMock, AsyncMock

# Patch an external service
@patch("src.users.service.email_client")
async def test_send_welcome_email(mock_email):
    mock_email.send = AsyncMock()
    await user_service.create_user({"name": "Bob", "email": "bob@test.com"})
    mock_email.send.assert_called_once()
```

### pytest-mock (fixture-based)
```python
async def test_create_user(mocker):
    mock_send = mocker.patch("src.users.service.email_client.send", new_callable=AsyncMock)
    await user_service.create_user({"name": "Bob", "email": "bob@test.com"})
    mock_send.assert_called_once()
```

## Linting and Type Checking

```bash
# Linting (ruff replaces flake8 + isort + pyupgrade)
ruff check src/ tests/
ruff format src/ tests/

# Type checking (strict mode recommended for CF migrations)
mypy --strict src/
```

### Configuration (pyproject.toml)
```toml
[tool.ruff]
target-version = "py312"
line-length = 100

[tool.ruff.lint]
select = ["E", "F", "I", "N", "W", "UP", "B", "A", "SIM"]

[tool.mypy]
strict = true
plugins = ["pydantic.mypy", "sqlalchemy.ext.mypy.plugin"]
```

## CF-Specific Testing Considerations

1. **Type coercion boundaries**: Every function that previously accepted CF's loosely-typed
   inputs needs explicit type validation tests. Use Pydantic models as the validation layer.
2. **Null handling**: CF treats empty strings, null, and undefined interchangeably.
   Python distinguishes `None`, `""`, and missing keys. Test all three.
3. **Date handling**: CF's `DateFormat()` and `ParseDateTime()` are permissive.
   Python's `datetime` is strict. Test edge cases (ambiguous formats like "01/02/03").
4. **Scope variables**: CF's `application`, `session`, `request` scopes become explicit
   dependencies in Python. Test that dependency injection works correctly.
5. **Query result handling**: CF query objects have unique iteration behavior. Ensure
   SQLAlchemy result handling matches the original CF behavior.
