# TDD Generation -- Target: .NET 8 / ASP.NET Core (from .NET WebForms)

Reference for TDD Generation when producing .NET 8 / ASP.NET Core code from
.NET Framework WebForms source.

## Test Framework Stack

| Tool | Purpose | NuGet Package |
|------|---------|--------------|
| xUnit | Test runner and framework | `xunit` + `xunit.runner.visualstudio` |
| Moq | Mocking framework | `Moq` |
| NSubstitute | Alternative mocking (interface-focused) | `NSubstitute` |
| FluentAssertions | Readable assertion syntax | `FluentAssertions` |
| Coverlet | Cross-platform code coverage | `coverlet.collector` |
| ReportGenerator | Coverage report rendering | `dotnet-reportgenerator-globaltool` |
| Bogus | Test data generation | `Bogus` |
| Respawn | Database reset between tests | `Respawn` |
| WebApplicationFactory | ASP.NET Core integration testing | `Microsoft.AspNetCore.Mvc.Testing` |
| Testcontainers | Real DB/service testing in Docker | `Testcontainers` |
| Playwright | E2E browser testing | `Microsoft.Playwright` |

## Coverage Configuration

### Thresholds
- Tier 1 (critical, FAA safety-related): 90% branch coverage minimum
- Tier 2 (standard): 80% branch coverage minimum

### Commands
```bash
# Run tests with coverage collection
dotnet test --collect:"XPlat Code Coverage" --settings coverlet.runsettings

# Generate human-readable HTML report
dotnet tool run reportgenerator \
    -reports:"**/coverage.cobertura.xml" \
    -targetdir:"coveragereport" \
    -reporttypes:"Html;Cobertura"

# Check coverage threshold (CI gate)
dotnet test --collect:"XPlat Code Coverage" -- \
    DataCollectionRunSettings.DataCollectors.DataCollector.Configuration.Format=cobertura
```

### Configuration (coverlet.runsettings)
```xml
<?xml version="1.0" encoding="utf-8"?>
<RunSettings>
  <DataCollectionRunSettings>
    <DataCollectors>
      <DataCollector friendlyName="XPlat Code Coverage">
        <Configuration>
          <Format>cobertura</Format>
          <ExcludeByFile>**/Migrations/**</ExcludeByFile>
          <ExcludeByAttribute>
            Obsolete,GeneratedCodeAttribute,CompilerGeneratedAttribute
          </ExcludeByAttribute>
        </Configuration>
      </DataCollector>
    </DataCollectors>
  </DataCollectionRunSettings>
</RunSettings>
```

### Configuration (.editorconfig -- enforce thresholds in CI)
```yaml
# .github/workflows/ci.yml
- name: Check coverage threshold
  run: |
    COVERAGE=$(grep -oP 'line-rate="\K[^"]+' coverage.cobertura.xml | head -1)
    THRESHOLD=0.80
    if (( $(echo "$COVERAGE < $THRESHOLD" | bc -l) )); then
      echo "Coverage $COVERAGE below threshold $THRESHOLD"
      exit 1
    fi
```

## Project Structure

```
src/
├── MyApp.Web/                         ← ASP.NET Core web host
│   ├── Program.cs                     ← application entry point + DI setup
│   ├── Pages/                         ← Razor Pages (if using Razor Pages)
│   │   ├── Flights/
│   │   │   ├── Index.cshtml
│   │   │   ├── Index.cshtml.cs
│   │   │   ├── Details.cshtml
│   │   │   └── Details.cshtml.cs
│   │   └── _Layout.cshtml
│   ├── Controllers/                   ← MVC Controllers (if using MVC)
│   │   └── FlightsController.cs
│   ├── Components/                    ← Blazor / View Components
│   │   └── FlightStatusPanel.razor
│   ├── wwwroot/                       ← static files
│   ├── appsettings.json
│   └── appsettings.Development.json
├── MyApp.Application/                 ← application services (use cases)
│   ├── Flights/
│   │   ├── SearchFlightsQuery.cs
│   │   ├── SearchFlightsHandler.cs
│   │   └── CreateFlightCommand.cs
│   ├── Common/
│   │   ├── Interfaces/
│   │   │   └── IFlightRepository.cs
│   │   └── Behaviors/
│   │       └── ValidationBehavior.cs
│   └── DependencyInjection.cs
├── MyApp.Domain/                      ← domain entities and business rules
│   ├── Entities/
│   │   ├── Flight.cs
│   │   └── Airport.cs
│   ├── ValueObjects/
│   │   └── FlightNumber.cs
│   ├── Enums/
│   │   └── FlightStatus.cs
│   └── Exceptions/
│       └── FlightNotFoundException.cs
├── MyApp.Infrastructure/              ← data access, external services
│   ├── Persistence/
│   │   ├── AppDbContext.cs
│   │   ├── Configurations/
│   │   │   └── FlightConfiguration.cs
│   │   ├── Migrations/
│   │   └── Repositories/
│   │       └── FlightRepository.cs
│   ├── Services/
│   │   └── EmailService.cs
│   └── DependencyInjection.cs
tests/
├── MyApp.UnitTests/                   ← unit tests (no external deps)
│   ├── Domain/
│   │   └── FlightTests.cs
│   ├── Application/
│   │   └── SearchFlightsHandlerTests.cs
│   └── TestHelpers/
│       └── FlightBuilder.cs
├── MyApp.IntegrationTests/            ← integration tests (real DB, HTTP)
│   ├── Persistence/
│   │   └── FlightRepositoryTests.cs
│   ├── Api/
│   │   └── FlightsEndpointTests.cs
│   ├── CustomWebApplicationFactory.cs
│   └── DatabaseFixture.cs
└── MyApp.E2ETests/                    ← end-to-end browser tests
    ├── FlightSearchTests.cs
    └── PlaywrightFixture.cs
```

## WebForms to Modern .NET Mapping Table

### Page and Layout Mapping

| WebForms | Razor Pages | Blazor Server | React SPA |
|----------|-------------|---------------|-----------|
| `.aspx` page | `.cshtml` Razor Page | `.razor` component | React component (`.tsx`) |
| `.aspx.cs` code-behind | `.cshtml.cs` PageModel | `@code { }` block | React hooks / state |
| `.master` master page | `_Layout.cshtml` | `MainLayout.razor` | Layout component |
| `ContentPlaceHolder` | `@RenderBody()` / `@RenderSection()` | `@Body` | `{children}` prop |
| `.ascx` user control | Partial view / View Component | Child `.razor` component | React component |
| `Page_Load` | `OnGet()` / `OnGetAsync()` | `OnInitializedAsync()` | `useEffect(() => {}, [])` |
| `Button_Click` | Form POST handler `OnPost()` | `@onclick` handler | `onClick` handler |
| `IsPostBack` check | GET vs POST method separation | N/A (event-driven) | N/A |

### Server Control Mapping

| WebForms Control | Razor Pages / MVC | Blazor | React |
|-----------------|-------------------|--------|-------|
| `asp:GridView` | HTML `<table>` + Tag Helpers | `QuickGrid<T>` component | DataGrid library (AG Grid, MUI) |
| `asp:DetailsView` | Form with model binding | EditForm component | React form |
| `asp:FormView` | Form with Tag Helpers | EditForm with `EditContext` | React Hook Form |
| `asp:Repeater` | `@foreach` loop | `@foreach` with components | `.map()` rendering |
| `asp:ListView` | `@foreach` with layout template | `Virtualize<T>` component | React virtualized list |
| `asp:Wizard` | Multi-step form (manual state) | Stepper component | React multi-step form |
| `asp:TreeView` | Recursive partial view | Recursive Blazor component | Tree view library |
| `asp:Menu` | Nav Tag Helper / `<nav>` | `NavMenu.razor` | React Router nav |
| `asp:LoginView` | `@if (User.Identity.IsAuthenticated)` | `AuthorizeView` component | Auth-conditional render |
| `asp:FileUpload` | `<input type="file">` + `IFormFile` | `InputFile` component | File input + fetch API |
| `asp:Calendar` | Date picker (JS library) | Date input component | React date picker |
| `asp:UpdatePanel` | N/A (use full page or AJAX) | Blazor Server (automatic) | React state update |

### State Management Mapping

| WebForms Mechanism | ASP.NET Core Equivalent |
|-------------------|------------------------|
| ViewState | Explicit form state, hidden fields, TempData, or client-side state |
| Session (InProc) | `IDistributedCache` with in-memory provider |
| Session (SQLServer) | `IDistributedCache` with SQL Server or Redis provider |
| Application state | Singleton service via DI, or `IMemoryCache` |
| Cache (`HttpRuntime.Cache`) | `IMemoryCache` or `IDistributedCache` |
| Query string | Query string (same, via model binding) |
| Cookies | `HttpContext.Response.Cookies` (same API, different impl) |
| Hidden fields | Hidden inputs with anti-forgery tokens |
| Profile properties | Claims in JWT or identity claims |

### Authentication Mapping

| WebForms Auth | ASP.NET Core Equivalent |
|--------------|------------------------|
| Forms Authentication | Cookie authentication middleware |
| ASP.NET Membership | ASP.NET Core Identity |
| Windows Authentication | Negotiate/Kerberos authentication |
| Role-based (`User.IsInRole`) | Policy-based authorization + role policies |
| `<location>` path auth | `[Authorize]` attribute + policy |
| Custom `IHttpModule` | Authentication middleware |
| OWIN/Katana | Built-in middleware pipeline |
| FormsAuthentication.SetAuthCookie | `HttpContext.SignInAsync()` |
| Login.gov / Okta (if federated) | OpenID Connect middleware |

## Entity Framework Core Patterns

### DbContext Configuration

```csharp
// AppDbContext.cs
public class AppDbContext : DbContext
{
    public AppDbContext(DbContextOptions<AppDbContext> options)
        : base(options) { }

    public DbSet<Flight> Flights => Set<Flight>();
    public DbSet<Airport> Airports => Set<Airport>();
    public DbSet<Airline> Airlines => Set<Airline>();

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.ApplyConfigurationsFromAssembly(
            typeof(AppDbContext).Assembly);
    }
}

// FlightConfiguration.cs (Fluent API)
public class FlightConfiguration : IEntityTypeConfiguration<Flight>
{
    public void Configure(EntityTypeBuilder<Flight> builder)
    {
        builder.ToTable("Flights");
        builder.HasKey(f => f.Id);

        builder.Property(f => f.FlightNumber)
            .HasMaxLength(10)
            .IsRequired();

        // Unique constraint: one flight number per airline per date
        builder.HasIndex(f => new { f.AirlineId, f.FlightNumber, f.FlightDate })
            .IsUnique();

        // Soft delete query filter
        builder.HasQueryFilter(f => !f.IsDeleted);

        // Relationships
        builder.HasOne(f => f.Airline)
            .WithMany(a => a.Flights)
            .HasForeignKey(f => f.AirlineId)
            .OnDelete(DeleteBehavior.Restrict);

        // Value conversion for enum
        builder.Property(f => f.Status)
            .HasConversion<string>();
    }
}
```

### Migration from EF6 to EF Core

| EF 6 Pattern | EF Core 8 Equivalent |
|-------------|---------------------|
| `.edmx` designer | Code-First with `IEntityTypeConfiguration<T>` |
| `ObjectContext` | `DbContext` |
| `Database.SqlQuery<T>()` | `Database.SqlQueryRaw<T>()` or `FromSqlRaw()` |
| `DbSet.SqlQuery()` | `FromSqlRaw()` / `FromSqlInterpolated()` |
| Lazy loading (default) | Explicit opt-in via proxies or `ILazyLoader` |
| `Include()` string overload | `Include()` lambda expression only |
| `WillCascadeOnDelete()` | `OnDelete(DeleteBehavior.Cascade)` |
| `HasDatabaseGeneratedOption()` | `ValueGeneratedOnAdd()` / `ValueGeneratedNever()` |
| Complex types | Owned entities (`OwnsOne` / `OwnsMany`) |

### Repository Pattern

```csharp
// IFlightRepository.cs (in Application layer)
public interface IFlightRepository
{
    Task<Flight?> GetByIdAsync(int id, CancellationToken ct = default);
    Task<IReadOnlyList<Flight>> SearchAsync(
        SearchCriteria criteria, CancellationToken ct = default);
    Task AddAsync(Flight flight, CancellationToken ct = default);
    Task SaveChangesAsync(CancellationToken ct = default);
}

// FlightRepository.cs (in Infrastructure layer)
public sealed class FlightRepository : IFlightRepository
{
    private readonly AppDbContext _context;

    public FlightRepository(AppDbContext context) => _context = context;

    public async Task<Flight?> GetByIdAsync(int id, CancellationToken ct)
    {
        return await _context.Flights
            .Include(f => f.Airline)
            .Include(f => f.Segments)
            .FirstOrDefaultAsync(f => f.Id == id, ct);
    }

    public async Task<IReadOnlyList<Flight>> SearchAsync(
        SearchCriteria criteria, CancellationToken ct)
    {
        var query = _context.Flights.AsQueryable();

        if (!string.IsNullOrEmpty(criteria.Origin))
            query = query.Where(f => f.OriginAirport == criteria.Origin);

        if (!string.IsNullOrEmpty(criteria.Destination))
            query = query.Where(f => f.DestAirport == criteria.Destination);

        if (criteria.DateFrom.HasValue)
            query = query.Where(f => f.FlightDate >= criteria.DateFrom.Value);

        return await query
            .OrderBy(f => f.DepartureTime)
            .Take(criteria.MaxResults)
            .ToListAsync(ct);
    }
}
```

## Middleware Pipeline

### Replacing HTTP Modules and Handlers

| WebForms Component | ASP.NET Core Equivalent |
|-------------------|------------------------|
| `IHttpModule` | Middleware class |
| `IHttpHandler` | Endpoint routing / middleware |
| `Global.asax Application_BeginRequest` | `app.Use(...)` middleware |
| `Global.asax Application_Error` | `app.UseExceptionHandler(...)` |
| `Global.asax Session_Start` | Distributed session middleware |
| `web.config <httpHandlers>` | `app.MapGet/MapPost(...)` or controller routes |

```csharp
// Middleware replacing IHttpModule
public class AuditMiddleware
{
    private readonly RequestDelegate _next;
    private readonly ILogger<AuditMiddleware> _logger;

    public AuditMiddleware(RequestDelegate next, ILogger<AuditMiddleware> logger)
    {
        _next = next;
        _logger = logger;
    }

    public async Task InvokeAsync(HttpContext context)
    {
        var stopwatch = Stopwatch.StartNew();
        _logger.LogInformation("Request started: {Path}", context.Request.Path);

        await _next(context);

        stopwatch.Stop();
        _logger.LogInformation("Request completed: {Path} in {Elapsed}ms",
            context.Request.Path, stopwatch.ElapsedMilliseconds);
    }
}

// Registration in Program.cs
app.UseMiddleware<AuditMiddleware>();
```

### Program.cs Pipeline Configuration

```csharp
var builder = WebApplication.CreateBuilder(args);

// Service registration (replaces web.config and Global.asax setup)
builder.Services.AddRazorPages();
builder.Services.AddDbContext<AppDbContext>(options =>
    options.UseSqlServer(builder.Configuration.GetConnectionString("MainDB")));
builder.Services.AddScoped<IFlightRepository, FlightRepository>();
builder.Services.AddScoped<IFlightService, FlightService>();

// Authentication (replaces FormsAuthentication)
builder.Services.AddAuthentication(CookieAuthenticationDefaults.AuthenticationScheme)
    .AddCookie(options =>
    {
        options.LoginPath = "/Account/Login";
        options.AccessDeniedPath = "/Account/AccessDenied";
        options.ExpireTimeSpan = TimeSpan.FromMinutes(30);
    });

builder.Services.AddAuthorization(options =>
{
    options.AddPolicy("AdminOnly", policy => policy.RequireRole("Admin"));
    options.AddPolicy("CanEditFlights", policy =>
        policy.RequireRole("Admin", "Dispatcher"));
});

var app = builder.Build();

// Middleware pipeline (replaces HTTP modules and Global.asax events)
app.UseExceptionHandler("/Error");
app.UseHsts();
app.UseHttpsRedirection();
app.UseStaticFiles();
app.UseRouting();
app.UseAuthentication();
app.UseAuthorization();
app.UseMiddleware<AuditMiddleware>();
app.MapRazorPages();
app.MapControllers();

app.Run();
```

## Configuration: Options Pattern

### Replacing web.config appSettings

```csharp
// FlightSearchOptions.cs (strongly-typed configuration)
public sealed class FlightSearchOptions
{
    public const string SectionName = "FlightSearch";

    public int MaxResults { get; init; } = 100;
    public int DefaultRangeDays { get; init; } = 7;
    public bool IncludeCodeshares { get; init; } = true;
    public string[] AllowedAirlines { get; init; } = [];
}
```

```json
// appsettings.json
{
  "FlightSearch": {
    "MaxResults": 100,
    "DefaultRangeDays": 7,
    "IncludeCodeshares": true,
    "AllowedAirlines": ["AA", "UA", "DL"]
  }
}
```

```csharp
// Registration
builder.Services.Configure<FlightSearchOptions>(
    builder.Configuration.GetSection(FlightSearchOptions.SectionName));

// Usage via IOptions<T>
public class FlightService
{
    private readonly FlightSearchOptions _options;

    public FlightService(IOptions<FlightSearchOptions> options)
    {
        _options = options.Value;
    }

    public async Task<List<Flight>> SearchAsync(SearchCriteria criteria)
    {
        var maxResults = criteria.MaxResults ?? _options.MaxResults;
        // ...
    }
}
```

## API Patterns

### Minimal APIs (Preferred for Simple Endpoints)

```csharp
// Program.cs — minimal API endpoints
var flights = app.MapGroup("/api/flights")
    .RequireAuthorization();

flights.MapGet("/", async (
    [AsParameters] SearchCriteria criteria,
    IFlightService service,
    CancellationToken ct) =>
{
    var results = await service.SearchAsync(criteria, ct);
    return Results.Ok(results);
});

flights.MapGet("/{id:int}", async (
    int id,
    IFlightService service,
    CancellationToken ct) =>
{
    var flight = await service.GetByIdAsync(id, ct);
    return flight is not null ? Results.Ok(flight) : Results.NotFound();
});

flights.MapPost("/", async (
    CreateFlightRequest request,
    IFlightService service,
    CancellationToken ct) =>
{
    var id = await service.CreateAsync(request, ct);
    return Results.Created($"/api/flights/{id}", new { id });
})
.RequireAuthorization("CanEditFlights");
```

### Controllers (For Complex Endpoints)

```csharp
[ApiController]
[Route("api/[controller]")]
[Authorize]
public class FlightsController : ControllerBase
{
    private readonly IFlightService _flightService;

    public FlightsController(IFlightService flightService)
    {
        _flightService = flightService;
    }

    [HttpGet("{id:int}")]
    [ProducesResponseType<FlightDto>(StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async Task<IActionResult> GetById(
        int id, CancellationToken ct)
    {
        var flight = await _flightService.GetByIdAsync(id, ct);
        return flight is not null ? Ok(flight) : NotFound();
    }

    [HttpPost]
    [Authorize(Policy = "CanEditFlights")]
    [ProducesResponseType<CreateFlightResponse>(StatusCodes.Status201Created)]
    [ProducesResponseType<ValidationProblemDetails>(StatusCodes.Status400BadRequest)]
    public async Task<IActionResult> Create(
        [FromBody] CreateFlightRequest request, CancellationToken ct)
    {
        var id = await _flightService.CreateAsync(request, ct);
        return CreatedAtAction(nameof(GetById), new { id }, new { id });
    }
}
```

### OpenAPI Generation

```csharp
// Program.cs
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen(options =>
{
    options.SwaggerDoc("v1", new OpenApiInfo
    {
        Title = "Flight Operations API",
        Version = "v1"
    });
});

// Enable in development
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}
```

## Dependency Injection

### Service Registration Patterns

```csharp
// DependencyInjection.cs in Infrastructure project
public static class DependencyInjection
{
    public static IServiceCollection AddInfrastructure(
        this IServiceCollection services,
        IConfiguration configuration)
    {
        // Database
        services.AddDbContext<AppDbContext>(options =>
            options.UseSqlServer(
                configuration.GetConnectionString("MainDB"),
                b => b.MigrationsAssembly(typeof(AppDbContext).Assembly.FullName)));

        // Repositories
        services.AddScoped<IFlightRepository, FlightRepository>();
        services.AddScoped<IAirportRepository, AirportRepository>();

        // External services
        services.AddScoped<IEmailService, EmailService>();

        // Caching (replaces HttpRuntime.Cache and Session)
        services.AddDistributedSqlServerCache(options =>
        {
            options.ConnectionString =
                configuration.GetConnectionString("CacheDB");
            options.SchemaName = "dbo";
            options.TableName = "DistributedCache";
        });

        return services;
    }
}

// Usage in Program.cs
builder.Services.AddInfrastructure(builder.Configuration);
```

### Lifetime Summary

| WebForms Pattern | Core DI Lifetime | Registration |
|-----------------|------------------|-------------|
| `new Service()` in code-behind | `AddTransient<T>()` | New instance per injection |
| Singleton in `Application_Start` | `AddSingleton<T>()` | One instance for app lifetime |
| Per-request via `HttpContext.Items` | `AddScoped<T>()` | One instance per HTTP request |
| Static helper class | `AddSingleton<T>()` or static methods | Shared state must be thread-safe |

## Test Patterns

### Unit Test -- Domain Entity

```csharp
public class FlightTests
{
    [Fact]
    public void Cancel_ThrowsWhenAlreadyCompleted()
    {
        // Arrange
        var flight = new FlightBuilder()
            .WithStatus(FlightStatus.Completed)
            .Build();

        // Act & Assert
        var act = () => flight.Cancel("dispatcher@faa.gov");
        act.Should().Throw<InvalidOperationException>()
            .WithMessage("*Cannot cancel a completed flight*");
    }

    [Theory]
    [InlineData(FlightStatus.Scheduled, true)]
    [InlineData(FlightStatus.Boarding, true)]
    [InlineData(FlightStatus.Departed, true)]
    [InlineData(FlightStatus.Completed, false)]
    [InlineData(FlightStatus.Cancelled, false)]
    public void CanCancel_ReturnsCorrectResult(
        FlightStatus status, bool expected)
    {
        var flight = new FlightBuilder().WithStatus(status).Build();
        flight.CanCancel.Should().Be(expected);
    }

    [Fact]
    public void MarkDelayed_SetsDelayedFlag_WhenActualDepartureExceeds15Minutes()
    {
        var flight = new FlightBuilder()
            .WithScheduledDeparture(new DateTime(2026, 4, 7, 10, 0, 0))
            .WithActualDeparture(new DateTime(2026, 4, 7, 10, 20, 0))
            .Build();

        flight.EvaluateDelay();

        flight.IsDelayed.Should().BeTrue();
        flight.DelayMinutes.Should().Be(20);
    }
}
```

### Unit Test -- Application Service (Mocked Dependencies)

```csharp
public class SearchFlightsHandlerTests
{
    private readonly Mock<IFlightRepository> _repoMock = new();
    private readonly IOptions<FlightSearchOptions> _options =
        Options.Create(new FlightSearchOptions { MaxResults = 50 });
    private readonly SearchFlightsHandler _handler;

    public SearchFlightsHandlerTests()
    {
        _handler = new SearchFlightsHandler(_repoMock.Object, _options);
    }

    [Fact]
    public async Task Handle_ReturnsFlights_WhenMatchesFound()
    {
        // Arrange
        var flights = new List<Flight>
        {
            new FlightBuilder().WithFlightNumber("AA100").Build(),
            new FlightBuilder().WithFlightNumber("UA200").Build()
        };
        _repoMock.Setup(r => r.SearchAsync(
                It.IsAny<SearchCriteria>(), It.IsAny<CancellationToken>()))
            .ReturnsAsync(flights);

        var query = new SearchFlightsQuery("JFK", "LAX", DateTime.Today);

        // Act
        var result = await _handler.Handle(query, CancellationToken.None);

        // Assert
        result.Should().HaveCount(2);
        result[0].FlightNumber.Should().Be("AA100");
        _repoMock.Verify(r => r.SearchAsync(
            It.Is<SearchCriteria>(c =>
                c.Origin == "JFK" && c.Destination == "LAX"),
            It.IsAny<CancellationToken>()), Times.Once);
    }

    [Fact]
    public async Task Handle_AppliesMaxResultsFromOptions()
    {
        _repoMock.Setup(r => r.SearchAsync(
                It.IsAny<SearchCriteria>(), It.IsAny<CancellationToken>()))
            .ReturnsAsync(new List<Flight>());

        var query = new SearchFlightsQuery("JFK", "LAX", DateTime.Today);

        await _handler.Handle(query, CancellationToken.None);

        _repoMock.Verify(r => r.SearchAsync(
            It.Is<SearchCriteria>(c => c.MaxResults == 50),
            It.IsAny<CancellationToken>()));
    }
}
```

### Integration Test -- API Endpoint (WebApplicationFactory)

```csharp
public class FlightsEndpointTests : IClassFixture<CustomWebApplicationFactory>
{
    private readonly HttpClient _client;

    public FlightsEndpointTests(CustomWebApplicationFactory factory)
    {
        _client = factory.CreateClient();
    }

    [Fact]
    public async Task GetFlight_Returns200_WithFlightJson()
    {
        var response = await _client.GetAsync("/api/flights/1");

        response.StatusCode.Should().Be(HttpStatusCode.OK);

        var flight = await response.Content
            .ReadFromJsonAsync<FlightDto>();
        flight.Should().NotBeNull();
        flight!.Id.Should().Be(1);
        flight.FlightNumber.Should().NotBeNullOrEmpty();
    }

    [Fact]
    public async Task GetFlight_Returns404_WhenNotFound()
    {
        var response = await _client.GetAsync("/api/flights/99999");
        response.StatusCode.Should().Be(HttpStatusCode.NotFound);
    }

    [Fact]
    public async Task CreateFlight_Returns201_WithLocationHeader()
    {
        var request = new CreateFlightRequest
        {
            FlightNumber = "AA999",
            Origin = "JFK",
            Destination = "LAX",
            DepartureTime = DateTime.Today.AddDays(1).AddHours(8)
        };

        var response = await _client.PostAsJsonAsync("/api/flights", request);

        response.StatusCode.Should().Be(HttpStatusCode.Created);
        response.Headers.Location.Should().NotBeNull();
    }

    [Fact]
    public async Task CreateFlight_Returns400_WhenInvalid()
    {
        var request = new CreateFlightRequest
        {
            FlightNumber = "",  // required field missing
            Origin = "JFK"
        };

        var response = await _client.PostAsJsonAsync("/api/flights", request);

        response.StatusCode.Should().Be(HttpStatusCode.BadRequest);
        var problem = await response.Content
            .ReadFromJsonAsync<ValidationProblemDetails>();
        problem!.Errors.Should().ContainKey("FlightNumber");
    }
}
```

### Custom WebApplicationFactory

```csharp
public class CustomWebApplicationFactory
    : WebApplicationFactory<Program>
{
    protected override void ConfigureWebHost(IWebHostBuilder builder)
    {
        builder.ConfigureServices(services =>
        {
            // Remove the real database context
            var descriptor = services.SingleOrDefault(
                d => d.ServiceType == typeof(DbContextOptions<AppDbContext>));
            if (descriptor is not null) services.Remove(descriptor);

            // Add in-memory database for testing
            services.AddDbContext<AppDbContext>(options =>
                options.UseInMemoryDatabase("TestDb"));

            // Seed test data
            var sp = services.BuildServiceProvider();
            using var scope = sp.CreateScope();
            var db = scope.ServiceProvider.GetRequiredService<AppDbContext>();
            db.Database.EnsureCreated();
            SeedTestData(db);
        });
    }

    private static void SeedTestData(AppDbContext db)
    {
        db.Flights.AddRange(
            new Flight { Id = 1, FlightNumber = "AA100",
                OriginAirport = "JFK", DestAirport = "LAX",
                Status = FlightStatus.Scheduled },
            new Flight { Id = 2, FlightNumber = "UA200",
                OriginAirport = "ORD", DestAirport = "SFO",
                Status = FlightStatus.Departed }
        );
        db.SaveChanges();
    }
}
```

### Integration Test -- Database (Real SQL Server via Testcontainers)

```csharp
public class FlightRepositoryTests : IAsyncLifetime
{
    private readonly MsSqlContainer _container = new MsSqlBuilder()
        .WithImage("mcr.microsoft.com/mssql/server:2022-latest")
        .Build();

    private AppDbContext _context = null!;

    public async Task InitializeAsync()
    {
        await _container.StartAsync();
        var options = new DbContextOptionsBuilder<AppDbContext>()
            .UseSqlServer(_container.GetConnectionString())
            .Options;
        _context = new AppDbContext(options);
        await _context.Database.MigrateAsync();
    }

    public async Task DisposeAsync()
    {
        await _context.DisposeAsync();
        await _container.DisposeAsync();
    }

    [Fact]
    public async Task SearchAsync_FiltersOnOriginAirport()
    {
        _context.Flights.AddRange(
            new Flight { FlightNumber = "AA100", OriginAirport = "JFK" },
            new Flight { FlightNumber = "UA200", OriginAirport = "ORD" }
        );
        await _context.SaveChangesAsync();

        var repo = new FlightRepository(_context);
        var criteria = new SearchCriteria { Origin = "JFK" };

        var results = await repo.SearchAsync(criteria);

        results.Should().ContainSingle()
            .Which.FlightNumber.Should().Be("AA100");
    }
}
```

### E2E Test -- Playwright

```csharp
public class FlightSearchE2ETests : IClassFixture<PlaywrightFixture>
{
    private readonly IPage _page;

    public FlightSearchE2ETests(PlaywrightFixture fixture)
    {
        _page = fixture.Page;
    }

    [Fact]
    public async Task SearchFlights_DisplaysResults_WhenMatchesExist()
    {
        await _page.GotoAsync("/flights/search");

        await _page.SelectOptionAsync("#origin", "JFK");
        await _page.SelectOptionAsync("#destination", "LAX");
        await _page.FillAsync("#departure-date", "2026-04-15");
        await _page.ClickAsync("#search-button");

        await _page.WaitForSelectorAsync(".flight-result");
        var results = await _page.QuerySelectorAllAsync(".flight-result");
        results.Should().NotBeEmpty();
    }
}

// PlaywrightFixture.cs
public class PlaywrightFixture : IAsyncLifetime
{
    public IPage Page { get; private set; } = null!;
    private IBrowser _browser = null!;

    public async Task InitializeAsync()
    {
        var playwright = await Playwright.CreateAsync();
        _browser = await playwright.Chromium.LaunchAsync(
            new() { Headless = true });
        Page = await _browser.NewPageAsync();
    }

    public async Task DisposeAsync()
    {
        await _browser.DisposeAsync();
    }
}
```

### Test Data Builder Pattern

```csharp
public class FlightBuilder
{
    private int _id = 1;
    private string _flightNumber = "AA100";
    private string _origin = "JFK";
    private string _destination = "LAX";
    private FlightStatus _status = FlightStatus.Scheduled;
    private DateTime _scheduledDeparture = DateTime.Today.AddHours(10);
    private DateTime? _actualDeparture;

    public FlightBuilder WithId(int id) { _id = id; return this; }
    public FlightBuilder WithFlightNumber(string fn) { _flightNumber = fn; return this; }
    public FlightBuilder WithOrigin(string o) { _origin = o; return this; }
    public FlightBuilder WithDestination(string d) { _destination = d; return this; }
    public FlightBuilder WithStatus(FlightStatus s) { _status = s; return this; }
    public FlightBuilder WithScheduledDeparture(DateTime dt)
        { _scheduledDeparture = dt; return this; }
    public FlightBuilder WithActualDeparture(DateTime? dt)
        { _actualDeparture = dt; return this; }

    public Flight Build() => new()
    {
        Id = _id,
        FlightNumber = _flightNumber,
        OriginAirport = _origin,
        DestAirport = _destination,
        Status = _status,
        ScheduledDeparture = _scheduledDeparture,
        ActualDeparture = _actualDeparture
    };
}
```

## Linting and Static Analysis

### .editorconfig

```ini
[*.cs]
# Naming conventions
dotnet_naming_rule.private_fields_should_be_camel_case.severity = warning
dotnet_naming_rule.private_fields_should_be_camel_case.symbols = private_fields
dotnet_naming_rule.private_fields_should_be_camel_case.style = _camelCase

dotnet_naming_symbols.private_fields.applicable_kinds = field
dotnet_naming_symbols.private_fields.applicable_accessibilities = private

dotnet_naming_style._camelCase.capitalization = camel_case
dotnet_naming_style._camelCase.required_prefix = _

# Code style
csharp_style_var_for_built_in_types = false:suggestion
csharp_prefer_simple_using_statement = true:warning
csharp_style_expression_bodied_methods = when_on_single_line:suggestion
csharp_style_namespace_declarations = file_scoped:warning
```

### Analyzers (NuGet Packages)

```xml
<ItemGroup>
  <!-- Roslyn analyzers -->
  <PackageReference Include="Microsoft.CodeAnalysis.NetAnalyzers"
      Version="8.0.0" PrivateAssets="all" />

  <!-- Security analysis -->
  <PackageReference Include="SecurityCodeScan.VS2019"
      Version="5.6.7" PrivateAssets="all" />

  <!-- Architecture enforcement -->
  <PackageReference Include="NetArchTest.Rules"
      Version="1.3.2" PrivateAssets="all" />
</ItemGroup>
```

### Architecture Tests (Enforcing Layer Boundaries)

```csharp
public class ArchitectureTests
{
    [Fact]
    public void Domain_ShouldNotReference_Infrastructure()
    {
        var result = Types.InAssembly(typeof(Flight).Assembly)
            .ShouldNot()
            .HaveDependencyOn("MyApp.Infrastructure")
            .GetResult();

        result.IsSuccessful.Should().BeTrue();
    }

    [Fact]
    public void Controllers_ShouldNotReference_Repositories_Directly()
    {
        var result = Types.InAssembly(typeof(Program).Assembly)
            .That().HaveNameEndingWith("Controller")
            .ShouldNot()
            .HaveDependencyOn("MyApp.Infrastructure.Persistence")
            .GetResult();

        result.IsSuccessful.Should().BeTrue();
    }
}
```

## Build Configuration (.csproj)

### Solution-Level Directory.Build.props

```xml
<!-- Directory.Build.props (at solution root, inherited by all projects) -->
<Project>
  <PropertyGroup>
    <TargetFramework>net8.0</TargetFramework>
    <Nullable>enable</Nullable>
    <ImplicitUsings>enable</ImplicitUsings>
    <TreatWarningsAsErrors>true</TreatWarningsAsErrors>
  </PropertyGroup>
</Project>
```

### Web Project .csproj

```xml
<Project Sdk="Microsoft.NET.Sdk.Web">
  <PropertyGroup>
    <TargetFramework>net8.0</TargetFramework>
  </PropertyGroup>

  <ItemGroup>
    <ProjectReference Include="..\MyApp.Application\MyApp.Application.csproj" />
    <ProjectReference Include="..\MyApp.Infrastructure\MyApp.Infrastructure.csproj" />
  </ItemGroup>

  <ItemGroup>
    <PackageReference Include="Swashbuckle.AspNetCore" Version="6.5.0" />
  </ItemGroup>
</Project>
```

### Test Project .csproj

```xml
<Project Sdk="Microsoft.NET.Sdk">
  <PropertyGroup>
    <TargetFramework>net8.0</TargetFramework>
    <IsPackable>false</IsPackable>
  </PropertyGroup>

  <ItemGroup>
    <PackageReference Include="xunit" Version="2.7.0" />
    <PackageReference Include="xunit.runner.visualstudio" Version="2.5.6" />
    <PackageReference Include="Moq" Version="4.20.70" />
    <PackageReference Include="FluentAssertions" Version="6.12.0" />
    <PackageReference Include="coverlet.collector" Version="6.0.0" />
    <PackageReference Include="Microsoft.AspNetCore.Mvc.Testing" Version="8.0.0" />
    <PackageReference Include="Microsoft.NET.Test.Sdk" Version="17.9.0" />
  </ItemGroup>

  <ItemGroup>
    <ProjectReference Include="..\src\MyApp.Web\MyApp.Web.csproj" />
    <ProjectReference Include="..\src\MyApp.Application\MyApp.Application.csproj" />
    <ProjectReference Include="..\src\MyApp.Domain\MyApp.Domain.csproj" />
  </ItemGroup>
</Project>
```

## WebForms-Specific Testing Considerations

1. **ViewState elimination**: Every page that relied on ViewState for cross-postback
   state must have explicit state management tests. Verify that form data survives
   page navigation via session, TempData, or client-side storage.

2. **Event lifecycle ordering**: WebForms fired events in a specific order
   (`Page_Load` before button click). In Razor Pages, `OnGet`/`OnPost` handlers
   are separate methods. Test that business rules still execute in the correct
   order when lifecycle is no longer implicit.

3. **Implicit type coercion**: WebForms controls return string values from
   `SelectedValue`, `Text`, etc. Code-behind often used `Convert.ToInt32()` or
   `int.Parse()` without null checking. Test all input conversion edge cases
   (empty strings, null, malformed input) with explicit error handling.

4. **Session dependency replacement**: WebForms apps pass data between pages via
   Session. In the target stack, replace with `TempData`, distributed cache, or
   explicit parameter passing. Test that data flows correctly without Session.

5. **Third-party control behavior**: Telerik/DevExpress controls had built-in
   behaviors (sorting, filtering, paging) that are not replicated by default in
   the target stack. Each behavior must be explicitly implemented and tested.

6. **UpdatePanel async behavior**: UpdatePanel performed full server round-trips
   for partial updates. Modern equivalents (Blazor Server, React) have different
   timing and error characteristics. Test loading states, error handling, and
   concurrent request behavior.

7. **Authentication ticket migration**: Forms auth tickets encrypted with
   `machineKey` cannot be read by ASP.NET Core cookie authentication. Test the
   authentication flow end-to-end, including login, session persistence,
   role-based access, and timeout behavior.

8. **Connection string handling**: WebForms used
   `ConfigurationManager.ConnectionStrings["name"]`. ASP.NET Core uses
   `IConfiguration.GetConnectionString("name")`. Test that all database
   connections resolve correctly in each environment configuration.
