# TDD Generation — Target: Spring Boot (from Java EE)

Reference for TDD Generation when producing Spring Boot code from Java EE source.

## Test Framework Stack

| Tool | Purpose | Maven Artifact |
|------|---------|---------------|
| JUnit 5 | Test runner and framework | `junit-jupiter` |
| Mockito | Mocking framework | `mockito-core` + `mockito-junit-jupiter` |
| Spring Boot Test | Spring integration testing | `spring-boot-starter-test` |
| JaCoCo | Code coverage | `jacoco-maven-plugin` |
| AssertJ | Fluent assertions | `assertj-core` (included in starter-test) |
| Testcontainers | Real DB/service testing | `testcontainers` |

## Coverage Configuration

### Thresholds
- Tier 1 (critical): 90% instruction coverage minimum
- Tier 2 (standard): 80% instruction coverage minimum

### Maven Configuration
```xml
<plugin>
    <groupId>org.jacoco</groupId>
    <artifactId>jacoco-maven-plugin</artifactId>
    <version>0.8.11</version>
    <executions>
        <execution>
            <goals><goal>prepare-agent</goal></goals>
        </execution>
        <execution>
            <id>report</id>
            <phase>test</phase>
            <goals><goal>report</goal></goals>
        </execution>
        <execution>
            <id>check</id>
            <goals><goal>check</goal></goals>
            <configuration>
                <rules>
                    <rule>
                        <element>BUNDLE</element>
                        <limits>
                            <limit>
                                <counter>INSTRUCTION</counter>
                                <value>COVEREDRATIO</value>
                                <minimum>0.80</minimum>
                            </limit>
                            <limit>
                                <counter>BRANCH</counter>
                                <value>COVEREDRATIO</value>
                                <minimum>0.80</minimum>
                            </limit>
                        </limits>
                    </rule>
                </rules>
            </configuration>
        </execution>
    </executions>
</plugin>
```

### Commands
```bash
# Run tests with coverage
mvn test jacoco:report

# Generate CSV for programmatic parsing
mvn test jacoco:report -Djacoco.formats=csv

# Check against thresholds
mvn verify  # runs jacoco:check in verify phase
```

## Project Structure

```
src/
├── main/java/com/example/{module}/
│   ├── controller/        ← @RestController classes
│   ├── service/           ← @Service business logic
│   ├── repository/        ← @Repository / Spring Data interfaces
│   ├── model/             ← @Entity JPA classes
│   ├── dto/               ← Request/Response DTOs
│   └── config/            ← @Configuration classes
├── main/resources/
│   ├── application.yml
│   └── db/migration/      ← Flyway migrations
└── test/java/com/example/{module}/
    ├── controller/        ← @WebMvcTest classes
    ├── service/           ← unit tests with Mockito
    ├── repository/        ← @DataJpaTest classes
    └── integration/       ← @SpringBootTest end-to-end
```

## Test Patterns

### Unit Test — Service Layer (Mockito)
```java
@ExtendWith(MockitoExtension.class)
class UserServiceTest {

    @Mock
    private UserRepository userRepository;

    @InjectMocks
    private UserService userService;

    @Test
    void getUserById_returnsUser_whenFound() {
        User expected = new User(1L, "Alice", "alice@test.com");
        when(userRepository.findById(1L)).thenReturn(Optional.of(expected));

        User result = userService.getUserById(1L);

        assertThat(result.getName()).isEqualTo("Alice");
        verify(userRepository).findById(1L);
    }

    @Test
    void getUserById_throwsNotFound_whenMissing() {
        when(userRepository.findById(999L)).thenReturn(Optional.empty());

        assertThatThrownBy(() -> userService.getUserById(999L))
            .isInstanceOf(UserNotFoundException.class)
            .hasMessageContaining("999");
    }
}
```

### API Test — Controller Layer (@WebMvcTest)
```java
@WebMvcTest(UserController.class)
class UserControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private UserService userService;

    @Test
    void getUser_returns200_withUserJson() throws Exception {
        UserDto dto = new UserDto(1L, "Alice", "alice@test.com");
        when(userService.getUserById(1L)).thenReturn(dto);

        mockMvc.perform(get("/api/users/1"))
            .andExpect(status().isOk())
            .andExpect(jsonPath("$.name").value("Alice"))
            .andExpect(jsonPath("$.email").value("alice@test.com"));
    }

    @Test
    void getUser_returns404_whenNotFound() throws Exception {
        when(userService.getUserById(999L))
            .thenThrow(new UserNotFoundException(999L));

        mockMvc.perform(get("/api/users/999"))
            .andExpect(status().isNotFound());
    }
}
```

### Database Test — Repository Layer (@DataJpaTest)
```java
@DataJpaTest
class UserRepositoryTest {

    @Autowired
    private TestEntityManager entityManager;

    @Autowired
    private UserRepository userRepository;

    @Test
    void findByEmail_returnsUser_whenExists() {
        User user = new User(null, "Alice", "alice@test.com");
        entityManager.persistAndFlush(user);

        Optional<User> found = userRepository.findByEmail("alice@test.com");

        assertThat(found).isPresent();
        assertThat(found.get().getName()).isEqualTo("Alice");
    }
}
```

### Integration Test — Full Stack (@SpringBootTest)
```java
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
class UserIntegrationTest {

    @Autowired
    private TestRestTemplate restTemplate;

    @Test
    void createAndGetUser_fullFlow() {
        // Create
        UserCreateRequest request = new UserCreateRequest("Bob", "bob@test.com");
        ResponseEntity<UserDto> createResponse =
            restTemplate.postForEntity("/api/users", request, UserDto.class);
        assertThat(createResponse.getStatusCode()).isEqualTo(HttpStatus.CREATED);

        Long userId = createResponse.getBody().getId();

        // Get
        ResponseEntity<UserDto> getResponse =
            restTemplate.getForEntity("/api/users/" + userId, UserDto.class);
        assertThat(getResponse.getBody().getName()).isEqualTo("Bob");
    }
}
```

### Parameterized Tests
```java
@ParameterizedTest
@CsvSource({
    "ACTIVE, true",
    "INACTIVE, false",
    "SUSPENDED, false",
    "PENDING, false"
})
void isActive_returnsCorrectStatus(UserStatus status, boolean expected) {
    User user = new User();
    user.setStatus(status);
    assertThat(user.isActive()).isEqualTo(expected);
}
```

## Mocking Patterns

### Mockito (unit tests)
```java
// Argument matchers
when(repo.findByName(anyString())).thenReturn(List.of(user));
when(repo.save(argThat(u -> u.getName().equals("Alice")))).thenReturn(user);

// Verify interactions
verify(repo, times(1)).save(any(User.class));
verify(repo, never()).deleteById(anyLong());
```

### @MockBean (Spring context tests)
```java
@MockBean
private ExternalPaymentService paymentService;  // replaces real bean in context

@BeforeEach
void setup() {
    when(paymentService.charge(any())).thenReturn(new PaymentResult(true));
}
```

## Linting and Static Analysis

```xml
<!-- Checkstyle -->
<plugin>
    <groupId>org.apache.maven.plugins</groupId>
    <artifactId>maven-checkstyle-plugin</artifactId>
    <configuration>
        <configLocation>checkstyle.xml</configLocation>
        <failsOnError>true</failsOnError>
    </configuration>
</plugin>

<!-- SpotBugs -->
<plugin>
    <groupId>com.github.spotbugs</groupId>
    <artifactId>spotbugs-maven-plugin</artifactId>
</plugin>
```

### Commands
```bash
mvn checkstyle:check        # code style
mvn spotbugs:check          # bug detection
mvn verify                  # runs all checks + tests + coverage
```

## Build Configuration (pom.xml)

```xml
<parent>
    <groupId>org.springframework.boot</groupId>
    <artifactId>spring-boot-starter-parent</artifactId>
    <version>3.2.0</version>
</parent>

<dependencies>
    <dependency>
        <groupId>org.springframework.boot</groupId>
        <artifactId>spring-boot-starter-web</artifactId>
    </dependency>
    <dependency>
        <groupId>org.springframework.boot</groupId>
        <artifactId>spring-boot-starter-data-jpa</artifactId>
    </dependency>
    <dependency>
        <groupId>org.springframework.boot</groupId>
        <artifactId>spring-boot-starter-test</artifactId>
        <scope>test</scope>
    </dependency>
</dependencies>
```

## Java EE-Specific Testing Considerations

1. **EJB → Spring bean lifecycle**: EJB container-managed lifecycle differs from Spring.
   Test `@PostConstruct` and `@PreDestroy` behavior explicitly.
2. **Transaction boundaries**: Java EE CMT vs Spring `@Transactional` — test rollback
   behavior, especially for methods that previously relied on container-managed TX.
3. **JNDI dependencies**: Replace `InitialContext.lookup()` with injected beans.
   Test that DI wiring is correct with `@SpringBootTest`.
4. **Vendor-specific APIs**: WebSphere/JBoss APIs must be replaced. Test the Spring
   equivalents produce identical behavior.
5. **Serialization**: EJB Remote interfaces used Java serialization. Spring REST uses
   JSON. Test that all DTOs serialize/deserialize correctly with Jackson.
