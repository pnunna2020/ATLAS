---
name: tdd-generation
description: >
  Generate code using Test-Driven Development with the Ralph Loop (default 3 iterations, configurable per app via Application.ralph_max_iterations or the OLYMPUS_RALPH_MAX_ITERATIONS env var). Write tests first, then generate code to pass them, iterate until convergence or the cap is reached. Use during P4.3. Triggers on TDD generation, code generation, Ralph Loop, @generate-renditions.
agent: sonnet
allowed-tools:
  - Read
  - Write
  - Bash
  - Grep
---

# Tdd Generation

## Purpose
The factory's core code generation engine — test-first, iterate until green.

## Tech-Stack Dispatch
Before generating tests and code, detect the target technology stack and load the
appropriate tooling reference:
- Target Python/FastAPI (from ColdFusion) → Read references/coldfusion-patterns.md
- Target Spring Boot (from Java EE) → Read references/java-ee-patterns.md
- Target .NET 8 (from legacy .NET) → Read references/dotnet-patterns.md
- Target Node.js (from various) → future — coordinate with the client profile Node.js addendum

## Gotchas
- **Tests are written FIRST, not after**: Claude's instinct is to write code
  then tests. This skill MUST enforce test-first. The test IS the spec.
- **Ralph Loop iteration cap is configurable (default 3)**: If tests don't pass
  within the configured cap (`Application.ralph_max_iterations` overrides the
  `OLYMPUS_RALPH_MAX_ITERATIONS` env default of 3), STOP and escalate via the
  `escalation-handler` skill. Don't keep looping. Tier 1 / safety-critical
  apps may raise this to 5-10 per-app; defaults stay at 3 to cap cost.
- **Use templates from assets/**: Don't generate boilerplate from scratch.
  Copy the Lambda/Fargate/React template and customize.
- **Run tests after EVERY iteration**: Don't batch iterations. Test, fail,
  fix, test, pass. Each iteration should fix one category of failures.

## Quality Rules
- [ ] Tests are written BEFORE implementation code in every Ralph Loop iteration — no code-first, test-after
- [ ] Each iteration addresses exactly one category of test failures — no multi-category fixes in a single iteration
- [ ] Ralph Loop completes within the configured iteration cap (`app.ralph_max_iterations` or `OLYMPUS_RALPH_MAX_ITERATIONS`, default 3); if not, escalation is triggered via `escalation-handler`
- [ ] Test coverage meets or exceeds 80% line coverage and 70% branch coverage for generated modules
- [ ] All generated code uses project templates from `assets/` — no boilerplate generated from scratch
- [ ] Generated tests include positive, negative, and boundary-condition cases for each extracted business rule
- [ ] Every generated function/method is traceable to an extracted specification via rule ID
- [ ] Integration tests verify inter-module contracts match the `api-specification` output
- [ ] No hardcoded secrets, credentials, or environment-specific values in generated code
- [ ] Generated code passes linting and static analysis for the target tech stack before marking iteration green

## Common Failure Modes
| Failure Mode | Symptom | Prevention |
|-------------|---------|------------|
| Code-first generation | Claude writes implementation then tests; tests merely assert existing behavior instead of specifying it | Enforce test-first in the prompt; reject iterations where implementation precedes tests |
| Infinite Ralph Loop | Loop exceeds the configured iteration cap without convergence; each fix breaks something else | Set hard stop at the resolved cap (per-app `ralph_max_iterations` or env default 3); escalate to `escalation-handler` with failure context |
| Template bypass | Generated boilerplate diverges from project standards; inconsistent structure across modules | Always copy from `assets/` templates; validate structure matches template skeleton |
| Low branch coverage | Line coverage passes but conditional paths are untested; edge cases slip through | Require branch coverage metric in addition to line coverage; flag untested conditionals |
| Missing traceability | Generated code works but cannot be traced back to extracted specs; gate review fails | Tag every function/class with the rule ID(s) it implements from the extraction output |

## Handoff Summary
When this skill completes, verify:
1. All tests pass (green) and coverage thresholds are met (>=80% line, >=70% branch)
2. Ralph Loop completed within the configured iteration cap (per-app `ralph_max_iterations` or env default 3)
3. Every generated module is traceable to extracted specifications via rule IDs
4. Generated code passes linting and static analysis for the target stack
Then proceed to: `parity-verifier` (P5.1) for behavioral equivalence testing, and gate `G-04c` for generation quality review
