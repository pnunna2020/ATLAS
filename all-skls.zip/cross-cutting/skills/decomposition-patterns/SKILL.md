---
name: decomposition-patterns
description: >
  Select and design strategies for decomposing shared databases used by multiple
  applications. Used during Data line shared database analysis and decomposition
  strategy steps. Triggers on database decomposition, shared DB strategy, or DB facade design.
agent: opus
allowed-tools:
  - Read
  - Write
  - Grep
---

# Decomposition Patterns

## Purpose
Determine the appropriate decomposition strategy for each monolith or shared
database cluster, balancing migration risk against target architecture goals.
Three FAA-committed patterns are first-class:
- **Shared-DB decomposition** — see `references/shared-db-decomposition.md`
  (example: CAIS shared by IACRA and downstream systems)
- **Strangler-fig** — see `references/strangler-fig.md`
  (example: CAIS/AADOCS → ACIS, Summer 2026 FOC)
- **Event-choreography with SQS** — see `references/event-choreography-sqs.md`
  (example: ACIS event backbone extending to DIWS, DMS, IMS)

## Inputs
- Shared database cluster map from Discovery
- DB coupling matrix (which apps read/write which tables)
- Shared DB analysis (stored procedures, triggers, database links)
- Wave plan (which apps are in which wave)

## Outputs
- Decomposition strategy per cluster (database-per-service, strangler fig, or DB facade)
- Co-wave dependency constraints
- Write ownership assignments (singular per table)
- Facade lifecycle plans with sunset dates

## Methodology
Produce a decomposition plan using `assets/decomposition-plan-template.md`.
Steps:

1. **Identify the monolith or cluster** — system name, owner, tech stack,
   criticality tier, consumers. Record source references.
2. **Identify seams** — API boundaries, DB tables, UI routes, background jobs.
   Every seam must cite source code (`file:line` or endpoint).
3. **Classify coupling** — coupling severity, wave alignment, write-ownership
   clarity, consumer count, transactional requirements.
4. **Select pattern(s)** — one or more of shared-DB decomposition,
   strangler-fig, event-choreography via SQS. Justify against the criteria
   from step 3; reference the matching file under `references/`.
5. **Sequence the migration** — ordered, independently releasable steps.
   Reversible until final cutover.
6. **Design data migration and event contracts** — backfill, reconciliation,
   CloudEvents-format events, DLQs, owners.
7. **Define cutover criteria** — binary and checkable (parity tests, drift,
   NFRs, rollback dry-run, sign-off).
8. **Define rollback and sunset** — rollback triggers, time-to-rollback, and
   sunset dates for every interim facade or dual-write.

Legacy decision heuristics for shared-DB clusters:
- **Database-per-service** — ≤3 apps all in the same wave.
- **Strangler-fig** — read-only consumers or clear write ownership; spans waves.
- **DB facade + phased migration** — complex stored procs, 4+ sharing apps, or
  cross-wave dependencies.

## Gotchas
- **Shared databases are the BIGGEST scheduling risk**: Apps sharing a DB must
  be co-waved or have an explicit facade strategy. This drives wave composition.
- **Write ownership must be singular**: No dual-write without an explicit facade.
  Two apps writing to the same table is a data corruption risk.
- **Facades are temporary**: Every facade must have a sunset date. Without one,
  facades become permanent technical debt that's harder to remove than the
  original shared DB.
- **Oracle RAC clusters are the unit of analysis**: Not the instance, not the
  schema — the cluster. All schemas on a cluster share the same decomposition fate.

## Quality Rules
- [ ] Every shared database cluster has an assigned decomposition strategy (database-per-service, strangler fig, or DB facade)
- [ ] Write ownership is singular per table — no dual-write without an explicit facade
- [ ] Every DB facade has a documented sunset date and migration milestones
- [ ] Co-wave dependency constraints are identified and fed to wave planning
- [ ] Decision tree criteria are documented: coupling severity and wave alignment used to select strategy
- [ ] Oracle RAC clusters are treated as the unit of analysis, not individual schemas or instances
- [ ] Every identified seam cites source code in `file:line` format (or a specific endpoint / DB object)
- [ ] Chosen pattern(s) are justified against documented decision criteria (coupling, wave alignment, write ownership, consumer count, transactionality)
- [ ] When event-choreography via SQS is selected, event contracts comply with the CloudEvents 1.0 envelope and every consumer queue has a DLQ with an owner
- [ ] Cutover criteria are binary and checkable — each item is a yes/no determination, not a subjective judgment
- [ ] A decomposition plan exists per monolith/cluster using `assets/decomposition-plan-template.md`

## Common Failure Modes
| Failure Mode | Symptom | Prevention |
|-------------|---------|------------|
| Shared DB ignored in wave planning | Apps sharing a database placed in different waves without facade strategy; migration breaks | Feed co-wave constraints to wave planning; require facade if apps are in different waves |
| Dual-write without coordination | Two apps writing to same table during transition; data corruption or lost updates | Enforce singular write ownership; use facade to coordinate writes during transition |
| Permanent facade | Facade introduced for interim but sunset date never enforced; becomes permanent tech debt | Track facade lifecycle with explicit sunset dates; review at each wave boundary |
| Schema-level analysis instead of cluster-level | Individual schemas decomposed but cluster-level dependencies (RAC, DB links) missed | Analyze at the RAC cluster level; map all cross-schema dependencies within the cluster |
| Database-per-service without migration path | Target architecture declares one DB per service but no plan for extracting data, cutting over writes, or backfilling — teams stall or dual-write indefinitely | Require a sequenced data-migration strategy (CDC, dual-read with reconciliation, cutover) plus event contracts in the plan before approving the pattern |
| Strangler-fig with no cutover criteria | Proxy ships; new service accrues features, but legacy is never retired — both paths run in production forever | Require binary cutover criteria (parity tests, zero drift, NFRs met, rollback dry-run) and a documented sunset date for the proxy before work starts |

## Handoff Summary
When this skill completes, verify:
1. Every shared database cluster has a documented decomposition strategy
2. Write ownership is singular per table
3. Facade sunset dates are set and tracked
4. Co-wave constraints are communicated to wave planning
Then proceed to: `data-modeling` (P4.2) for target schema design, wave planning (P1.4) with co-wave constraints, and gate `G-DT` for data architecture review
