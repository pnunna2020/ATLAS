# Strangler-Fig Pattern

Replace a monolith incrementally by routing traffic through a facade that
forwards per-seam to either the legacy system or the new service.

## Core mechanics

1. **Identify seams** — interception points that don't break clients.
2. **Insert proxy** — facade routes per-seam to legacy or new.
3. **Migrate behavior** — reimplement one seam at a time behind the proxy.
4. **Cut over** — flip routing once feature-parity is met.
5. **Retire** — delete the legacy path and proxy branches.

## Seam identification

- **API boundaries** — REST/SOAP/RPC. Route by path or verb.
- **Database tables** — split read/write ownership. New service owns writes;
  legacy reads via replicated read model or API.
- **UI routes** — per-page migration via reverse proxy with path rules.
- **Background jobs** — migrate one scheduled job at a time.

## Proxy options

- **API Gateway** (AWS API Gateway, Kong) — REST/HTTP seams.
- **Reverse proxy** (nginx, Envoy, ALB rules) — UI route splitting.
- **Feature flags** (LaunchDarkly) — in-process seams.

## Cutover criteria checklist

- [ ] Feature-parity via shared test suite on both paths
- [ ] Data reconciliation shows zero drift over a full business cycle
- [ ] Non-functional targets met (latency p99, error rate, throughput)
- [ ] Rollback path tested end-to-end
- [ ] Stakeholders informed and on-call coverage in place

## Worked example — FAA CAIS/AADOCS to ACIS

CAIS (NATURAL/ADABAS mainframe) and AADOCS are being strangled by ACIS
(Java/Postgres/Tyrion on AWS GovCloud), committed for Summer 2026 FOC.

- **Seams:** airman-cert issuance API, document lookup, imaging endpoints.
- **Proxy:** API Gateway in GovCloud routes per-endpoint to ACIS or legacy.
- **Order:** read-only lookups, then issuance, then document writes. Imaging
  last (largest data volume).
- **Cutover:** per-seam, gated by parity tests against the NATURAL baseline
  and reconciliation against ADABAS extracts.
