# Event-Choreography with Amazon SQS

Decompose a monolith by publishing domain events to SQS (optionally fanned out
via SNS). Aligned with the FAA ACIS event backbone, extending to DIWS, DMS, IMS.

## Orchestration vs. choreography

- **Orchestration** — a central workflow tells services what to do next. Use
  for complex flows, compensating transactions, auditable sagas (Step
  Functions, Temporal).
- **Choreography** — each service reacts to events and decides its own next
  move. Use when services are loosely related and new consumers should join
  without touching publishers.

FAA default: choreography for cross-system notifications; orchestration for
multi-step sagas (new-issuance).

## Event schema — CloudEvents 1.0

```json
{
  "specversion": "1.0",
  "id": "7b2f-uuid",
  "source": "/acis/airmen-cert",
  "type": "gov.faa.airman.cert.issued.v1",
  "subject": "airman/A1234567",
  "time": "2026-04-27T14:32:00Z",
  "datacontenttype": "application/json",
  "data": { "certId": "...", "issuedOn": "..." }
}
```

Rules: versioned `type`, stable `source`, immutable `id`, UTC `time`,
`subject` is the domain key.

## At-least-once + idempotent consumers

SQS is at-least-once. Consumers dedupe by `id` (persisted at least for the
visibility window). Writes must be idempotent: upserts keyed on business
identifiers, not auto-increment IDs.

## Dead-letter queues

- Every consumer queue has a DLQ.
- `maxReceiveCount`: 5 standard; 3 for latency-sensitive.
- DLQ alarms fire within 5 minutes of first message.
- Each DLQ has a documented redrive runbook and owner.

## Worked example — airman-cert events

ACIS publishes `gov.faa.airman.cert.issued.v1` to an SNS topic. Subscribers:

- **DIWS** — updates medical eligibility.
- **DMS** — refreshes examiner authority.
- **IMS** — indexes the new certificate image.

Each subscriber has its own SQS queue + DLQ. New consumers subscribe without
ACIS changes.
