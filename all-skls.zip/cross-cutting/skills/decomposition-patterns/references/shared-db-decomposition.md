# Shared-DB Decomposition

When apps share a DB cluster, match the decomposition strategy to the coupling
pattern.

## Strategies

### Vertical split (schema-per-app)
Each app gets its own schema on the same cluster. Cross-schema reads via views
or grants; writes isolated. Low risk, low payoff — an interim step.

### Horizontal split (table-per-app)
Tables assigned to a single owning app. Consumers migrate to API reads or
replicated read models. Works when ownership is clear and cross-joins are few.

### CQRS read-model split
Owner keeps the write model; consumers get a purpose-built read store populated
by CDC or domain events. Breaks read coupling without forcing write-side
redesign.

### Database-per-service with event sourcing
Full separation: each service owns a private DB; cross-service state propagates
by events. Highest payoff, highest cost — requires event schemas, idempotent
consumers, and replay capability.

## Tradeoffs

| Strategy | Duplication | Consistency | Txn atomicity |
|---|---|---|---|
| Vertical | None | Strong | Preserved |
| Horizontal | Low | Strong within owner | Lost across apps |
| CQRS read | High | Eventual | Preserved (writes) |
| DB-per-service | High | Eventual | Per-service only |

## Worked example — FAA CAIS

CAIS (airmen cert) is shared by IACRA and downstream systems. Migration path:

1. Extract the airmen-cert bounded context into a new service with its own
   Postgres schema (vertical split inside the CAIS cluster).
2. Freeze non-owner writes; route through the new service's API (horizontal
   split of write ownership).
3. Publish `airman.cert.issued` / `airman.cert.revoked` events to SQS;
   retire direct cross-app reads (CQRS + events).
4. Cut over to a private airmen-cert database on a separate cluster once all
   consumers are event-driven. Retire the legacy schema last.

Every step must be reversible until the final cutover.
