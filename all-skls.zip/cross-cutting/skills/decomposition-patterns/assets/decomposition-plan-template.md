# Decomposition Plan — {{system-name}}

> Use this template to document the decomposition plan for a single monolith
> or shared-database cluster. One plan per bounded context being extracted.

## 1. Monolith identification

- **System / cluster name:**
- **Owner / steward:**
- **Current tech stack:** (language, runtime, DB, deployment target)
- **Criticality tier:** (from client profile risk classification)
- **Applications / consumers involved:**
- **Source references:** `{repo}:{path}` or `{artifact}:{section}:{finding-id}`

## 2. Identified seams

List every seam considered. Cite source code for each.

| Seam ID | Seam type (API / table / UI / job) | Location (`file:line` or endpoint) | Selected? | Rationale |
|---|---|---|---|---|
| S-1 |  |  |  |  |
| S-2 |  |  |  |  |

## 3. Chosen pattern(s)

Select one or more and justify against decision criteria.

- [ ] Shared-DB decomposition (vertical / horizontal / CQRS / DB-per-service)
- [ ] Strangler-fig
- [ ] Event-choreography via SQS

**Decision criteria applied:** coupling severity, wave alignment, write
ownership clarity, consumer count, transactional requirements.

**Justification:**

## 4. Migration sequencing

Ordered list — what ships first, next, last. Each step must be independently
releasable and reversible until the final cutover.

1.
2.
3.

## 5. Data-migration strategy

- **Backfill approach:** (dump/restore, CDC, dual-write with reconciliation)
- **Reconciliation method:** (row counts, checksum, sample audits)
- **Acceptable drift window:**
- **Freeze windows required:** yes / no — details

## 6. Event contracts introduced

For each new event, record type, schema location, publisher, subscribers, and
DLQ owner. Events MUST comply with CloudEvents 1.0.

| Event type | Schema | Publisher | Subscribers | DLQ owner |
|---|---|---|---|---|
|  |  |  |  |  |

## 7. Cutover criteria (binary and checkable)

- [ ] Feature-parity test suite green on both paths
- [ ] Data reconciliation drift = 0 over one full business cycle
- [ ] Non-functional targets met (latency p99, error rate, throughput)
- [ ] Rollback path executed in a staging dry-run
- [ ] On-call coverage and stakeholder sign-off recorded

## 8. Rollback plan

- **Trigger conditions:**
- **Rollback steps (ordered):**
- **Maximum time-to-rollback:**
- **Data recovery approach:**
- **Communications plan:**

## 9. Sunset of interim scaffolding

Every facade, proxy, or dual-write has an explicit sunset date and owner.

| Scaffold | Sunset date | Owner |
|---|---|---|
|  |  |  |
