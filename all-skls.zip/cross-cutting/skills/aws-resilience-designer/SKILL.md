---
name: aws-resilience-designer
description: >
  Design high-availability, disaster recovery, and failover patterns matching
  RTO/RPO requirements per risk tier. Use during Architecture (Step 1b).
  Triggers on resilience design, HA architecture, failover, disaster recovery.
agent: opus
allowed-tools:
  - Read
  - Write
  - Grep
---

# AWS Resilience Designer

## Purpose
Design resilience architectures that meet FAA RTO/RPO requirements by risk tier.
Each application gets a resilience matrix mapping every component to its failure
modes, mitigations, and validated recovery times.

## Inputs
- Application risk tier (T1/T2/T3) from Risk Classification
- Architecture pattern from migration-strategy-advisor (microservices, modular monolith, serverless)
- Dependency profile from Discovery (databases, caches, queues, external services)
- RTO/RPO requirements from the active client profile
- Deployment region (GovCloud us-gov-west-1, us-gov-east-1)

## Outputs
- Resilience architecture document with per-component patterns
- Resilience matrix (component x failure mode x mitigation x recovery time)
- Chaos engineering test plan
- Runbook templates for each failure scenario

## Methodology

### Step 1: Load Risk Tier Requirements
Read the active client profile to determine tier-specific resilience targets:
- **T1 (Safety-Critical, NAS)**: RTO 15 minutes, RPO 0 (zero data loss), availability 99.99%
- **T2 (Mission-Support)**: RTO 1 hour, RPO 15 minutes, availability 99.95%
- **T3 (Administrative)**: RTO 4 hours, RPO 1 hour, availability 99.9%

Load `references/resilience-patterns-by-tier.md` and select the pattern set
matching the application's risk tier.

### Step 2: Design Compute Resilience
Select compute resilience patterns based on tier:
- Multi-AZ ECS Fargate deployment (3 AZs for T1, 2 AZs for T2, single AZ acceptable for T3)
- Auto-scaling policies with target tracking (CPU and memory)
- Deep health checks that validate downstream dependencies
- Graceful degradation: circuit breakers on all external calls, fallback to cached or degraded responses
- Container restart policies and task placement constraints

Load `references/circuit-breaker-patterns.md` for implementation details.

### Step 3: Design Data Resilience
Select data resilience patterns based on tier:
- Aurora PostgreSQL: multi-AZ for T1/T2, cross-region read replica for T1
- Backup strategy: automated snapshots, point-in-time recovery window
- ElastiCache Redis: replication group with automatic failover for T1/T2
- S3: versioning enabled, cross-region replication for T1
- Connection management: RDS Proxy for connection pooling and failover transparency

Load `references/database-failover-patterns.md` for failover procedures.

### Step 4: Design Integration Resilience
Apply integration resilience patterns to all external communication:
- Circuit breakers on every external dependency (load `references/circuit-breaker-patterns.md`)
- Retry with exponential backoff and jitter (max 3 retries, base delay 100ms)
- Dead letter queues for asynchronous message processing failures
- Timeout budgets: overall request timeout minus time spent so far equals downstream timeout
- Bulkhead pattern: isolate dependency pools to prevent cascade failures

### Step 5: Design Deployment Resilience
Select deployment resilience patterns based on tier:
- T1: canary deployment (5% -> 25% -> 50% -> 100% over 14 days)
- T2: blue-green deployment with 24-hour validation window
- T3: blue-green deployment with 4-hour validation window
- Rollback automation: CloudWatch alarm triggers automatic rollback via CodeDeploy
- Feature flags for gradual feature rollout independent of deployment

### Step 6: Produce Resilience Matrix
Generate the resilience matrix using `assets/resilience-matrix-template.yaml`:
- List every component in the architecture
- For each component, enumerate failure modes (process crash, AZ failure, region failure, dependency timeout, data corruption)
- For each failure mode, document the mitigation, detection mechanism, and expected recovery time
- Validate that all recovery times meet the tier's RTO requirement
- Flag any component where recovery time exceeds RTO as a design gap requiring resolution

Load `references/chaos-engineering-tests.md` to produce the chaos test plan.

## Gotchas
- **GovCloud region pairs differ from commercial**: us-gov-west-1 and us-gov-east-1 are
  the only GovCloud regions. Cross-region replication targets must use these.
- **Aurora Global Database has replication lag**: Cross-region RPO is ~1 second with
  Global Database, not zero. T1 applications needing RPO=0 must use synchronous
  replication within a single region (multi-AZ).
- **Circuit breaker state is per-instance**: In a multi-task ECS deployment, each task
  has its own circuit breaker state. A dependency failure may trip circuits on some
  tasks but not others. Use centralized circuit state (Redis-backed) for T1 apps.
- **RDS Proxy adds latency**: Approximately 1-2ms per query. Acceptable for most
  workloads but measure impact on latency-sensitive T1 applications.

## Quality Rules
- [ ] Resilience patterns match the application's risk tier requirements exactly
- [ ] Every component in the architecture has at least one failure mode documented with mitigation
- [ ] RTO/RPO targets are validated against the actual recovery mechanisms, not just stated
- [ ] Cross-region patterns use GovCloud region pairs (us-gov-west-1, us-gov-east-1)
- [ ] Circuit breaker configuration specifies failure threshold, wait duration, and fallback strategy
- [ ] Chaos engineering test plan covers AZ failure, dependency failure, and latency injection at minimum
- [ ] Resilience matrix flags any component where recovery time exceeds the tier's RTO target
- [ ] Database failover strategy accounts for connection string management during failover

## Common Failure Modes
| Failure Mode | Symptom | Prevention |
|-------------|---------|------------|
| Tier mismatch | T1 app deployed with T3 resilience patterns; fails to meet RTO during incident | Validate tier assignment before selecting patterns; cross-check with risk classification |
| Single-AZ hidden dependency | Multi-AZ compute but single-AZ cache or queue; AZ failure takes down the app | Audit every component in the dependency chain for AZ redundancy |
| Untested failover | Aurora failover works in theory but application connection pool doesn't reconnect; extended outage | Include connection pool recovery in chaos tests; validate with actual failover |
| Circuit breaker misconfiguration | Threshold too low trips on normal variance; threshold too high doesn't trip during actual failure | Tune thresholds using production traffic patterns; start conservative and adjust |
| Cross-region replication lag ignored | T1 app assumes RPO=0 with async cross-region replication; data loss during region failure | Document actual RPO for each replication mechanism; use synchronous replication for RPO=0 |

## Handoff Summary
When this skill completes, verify:
1. Resilience matrix covers all components with failure modes and mitigations
2. Recovery times for all components meet the tier's RTO/RPO requirements
3. Chaos engineering test plan is actionable with specific test procedures
4. GovCloud region constraints are respected in all cross-region patterns
Then proceed to: `aws-deployment-topology` for infrastructure design, `ea-compliance` for EA alignment verification, and gate `G-02` for architecture review
