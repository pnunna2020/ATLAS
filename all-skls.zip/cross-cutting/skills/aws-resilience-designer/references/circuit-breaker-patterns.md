# Circuit Breaker Implementation Patterns

Reference for aws-resilience-designer when designing integration resilience.

## Circuit Breaker Overview

The circuit breaker pattern prevents cascading failures by detecting downstream
failures and short-circuiting requests to failed dependencies. It operates in
three states:

```
 CLOSED ──(failures exceed threshold)──> OPEN
   ^                                       │
   │                                       │
   └──(success in half-open)──── HALF-OPEN <──(wait duration elapsed)
                                    │
                         (failure in half-open)──> OPEN
```

- **Closed**: requests pass through normally. Failures are counted.
- **Open**: requests are immediately rejected with a fallback response. No calls to downstream.
- **Half-Open**: a limited number of requests are allowed through to test recovery.

## Python Implementation (FastAPI + tenacity + pybreaker)

### Using pybreaker

```python
import pybreaker
from fastapi import FastAPI, HTTPException
from functools import wraps
import logging

logger = logging.getLogger(__name__)

# Circuit breaker configuration per tier
TIER_CONFIG = {
    "T1": {"fail_max": 5, "reset_timeout": 30, "half_open_max": 3},
    "T2": {"fail_max": 10, "reset_timeout": 60, "half_open_max": 5},
    "T3": {"fail_max": 15, "reset_timeout": 120, "half_open_max": 5},
}


class MetricsListener(pybreaker.CircuitBreakerListener):
    """Emit metrics on circuit state changes for Datadog/CloudWatch."""

    def state_change(self, cb, old_state, new_state):
        logger.warning(
            "Circuit breaker '%s' state change: %s -> %s",
            cb.name, old_state.name, new_state.name,
        )
        # Emit CloudWatch metric or Datadog gauge
        # publish_metric("circuit_breaker.state", tags=[f"breaker:{cb.name}", f"state:{new_state.name}"])

    def failure(self, cb, exc):
        logger.error("Circuit breaker '%s' recorded failure: %s", cb.name, exc)

    def success(self, cb):
        logger.debug("Circuit breaker '%s' recorded success", cb.name)


def create_breaker(name: str, tier: str = "T2") -> pybreaker.CircuitBreaker:
    """Create a circuit breaker with tier-appropriate configuration."""
    config = TIER_CONFIG[tier]
    return pybreaker.CircuitBreaker(
        name=name,
        fail_max=config["fail_max"],
        reset_timeout=config["reset_timeout"],
        listeners=[MetricsListener()],
        exclude=[ValueError, KeyError],  # Don't count client errors as failures
    )


# Usage with a dependency client
inventory_breaker = create_breaker("inventory-service", tier="T1")


@inventory_breaker
def call_inventory_service(item_id: str) -> dict:
    """Call inventory service with circuit breaker protection."""
    response = httpx.get(
        f"https://inventory.internal/api/items/{item_id}",
        timeout=5.0,
    )
    response.raise_for_status()
    return response.json()
```

### Using tenacity for Retry with Circuit Breaker

```python
from tenacity import (
    retry,
    stop_after_attempt,
    wait_exponential_jitter,
    retry_if_exception_type,
)
import httpx


# Retry with exponential backoff and jitter
@retry(
    stop=stop_after_attempt(3),
    wait=wait_exponential_jitter(initial=0.1, max=10, jitter=2),
    retry=retry_if_exception_type((httpx.ConnectTimeout, httpx.ReadTimeout, httpx.ConnectError)),
    before_sleep=lambda retry_state: logger.warning(
        "Retrying %s, attempt %d", retry_state.fn.__name__, retry_state.attempt_number
    ),
)
def call_with_retry(url: str, timeout: float = 5.0) -> dict:
    """HTTP call with retry and exponential backoff."""
    response = httpx.get(url, timeout=timeout)
    response.raise_for_status()
    return response.json()
```

### FastAPI Middleware for Circuit Breaker Metrics

```python
from fastapi import Request, Response
from starlette.middleware.base import BaseHTTPMiddleware
import time


class CircuitBreakerMiddleware(BaseHTTPMiddleware):
    """Middleware that exposes circuit breaker state in response headers."""

    def __init__(self, app, breakers: dict[str, pybreaker.CircuitBreaker]):
        super().__init__(app)
        self.breakers = breakers

    async def dispatch(self, request: Request, call_next) -> Response:
        # Add breaker states to request state for handlers to check
        request.state.breaker_states = {
            name: breaker.current_state
            for name, breaker in self.breakers.items()
        }

        response = await call_next(request)

        # Expose circuit states in response headers for observability
        open_circuits = [
            name for name, breaker in self.breakers.items()
            if breaker.current_state == "open"
        ]
        if open_circuits:
            response.headers["X-Degraded-Dependencies"] = ",".join(open_circuits)

        return response
```

## Java Implementation (Spring Boot + Resilience4j)

### Configuration (application.yml)

```yaml
resilience4j:
  circuitbreaker:
    configs:
      tier1:
        slidingWindowType: COUNT_BASED
        slidingWindowSize: 10
        failureRateThreshold: 50
        waitDurationInOpenState: 30s
        permittedNumberOfCallsInHalfOpenState: 3
        slowCallRateThreshold: 80
        slowCallDurationThreshold: 5s
        recordExceptions:
          - java.io.IOException
          - java.net.SocketTimeoutException
          - org.springframework.web.client.HttpServerErrorException
        ignoreExceptions:
          - org.springframework.web.client.HttpClientErrorException
      tier2:
        slidingWindowType: COUNT_BASED
        slidingWindowSize: 20
        failureRateThreshold: 50
        waitDurationInOpenState: 60s
        permittedNumberOfCallsInHalfOpenState: 5
        slowCallRateThreshold: 80
        slowCallDurationThreshold: 10s
      tier3:
        slidingWindowType: COUNT_BASED
        slidingWindowSize: 30
        failureRateThreshold: 60
        waitDurationInOpenState: 120s
        permittedNumberOfCallsInHalfOpenState: 5
    instances:
      inventoryService:
        baseConfig: tier1
      notificationService:
        baseConfig: tier2

  retry:
    configs:
      default:
        maxAttempts: 3
        waitDuration: 100ms
        enableExponentialBackoff: true
        exponentialBackoffMultiplier: 2
        retryExceptions:
          - java.io.IOException
          - java.net.SocketTimeoutException
    instances:
      inventoryService:
        baseConfig: default
      notificationService:
        baseConfig: default

  bulkhead:
    configs:
      default:
        maxConcurrentCalls: 25
        maxWaitDuration: 500ms
    instances:
      inventoryService:
        maxConcurrentCalls: 10
      notificationService:
        maxConcurrentCalls: 25
```

### Service Implementation

```java
@Service
public class InventoryClient {

    private final RestTemplate restTemplate;
    private final InventoryFallback fallback;

    @CircuitBreaker(name = "inventoryService", fallbackMethod = "getInventoryFallback")
    @Retry(name = "inventoryService")
    @Bulkhead(name = "inventoryService")
    @TimeLimiter(name = "inventoryService")
    public CompletableFuture<InventoryResponse> getInventory(String itemId) {
        return CompletableFuture.supplyAsync(() ->
            restTemplate.getForObject(
                "https://inventory.internal/api/items/{id}",
                InventoryResponse.class,
                itemId
            )
        );
    }

    /**
     * Fallback: return cached data or degraded response.
     * Called when circuit is open or all retries exhausted.
     */
    public CompletableFuture<InventoryResponse> getInventoryFallback(
            String itemId, Throwable t) {
        log.warn("Inventory service unavailable, using fallback for item {}: {}",
                 itemId, t.getMessage());
        return CompletableFuture.completedFuture(
            fallback.getCachedInventory(itemId)
        );
    }
}
```

## Fallback Strategies

### Strategy 1: Cached Response
Return the most recently cached successful response. Appropriate when slightly
stale data is acceptable.

```python
from cachetools import TTLCache

# T1: max 5 minutes stale, T2: max 15 minutes stale, T3: max 60 minutes stale
CACHE_TTL = {"T1": 300, "T2": 900, "T3": 3600}

response_cache = TTLCache(maxsize=1000, ttl=CACHE_TTL["T1"])

def get_with_fallback(key: str, fetch_fn, tier: str = "T1"):
    """Fetch with cache fallback on circuit breaker open."""
    try:
        result = fetch_fn(key)
        response_cache[key] = result
        return result
    except pybreaker.CircuitBreakerError:
        cached = response_cache.get(key)
        if cached:
            logger.info("Circuit open, returning cached response for %s", key)
            return cached
        raise ServiceUnavailableError(f"No cached fallback available for {key}")
```

### Strategy 2: Degraded Response
Return a partial or simplified response that allows the application to continue
operating with reduced functionality.

```python
def get_flight_status_with_degradation(flight_id: str) -> FlightStatus:
    """Return flight status with graceful degradation."""
    status = FlightStatus(flight_id=flight_id)

    # Core data: must succeed or fail the request
    status.position = get_position(flight_id)  # No circuit breaker; critical path

    # Enrichment data: degrade gracefully if unavailable
    try:
        status.weather = weather_breaker.call(get_weather, flight_id)
    except pybreaker.CircuitBreakerError:
        status.weather = WeatherData(available=False, message="Weather data temporarily unavailable")

    try:
        status.maintenance = maintenance_breaker.call(get_maintenance_status, flight_id)
    except pybreaker.CircuitBreakerError:
        status.maintenance = None  # Omit from response

    return status
```

### Strategy 3: Queue for Retry
For non-critical operations, queue the request for later retry instead of
failing immediately.

```python
import boto3

sqs = boto3.client("sqs", region_name="us-gov-west-1")

def send_notification_with_queue_fallback(notification: dict):
    """Send notification; queue for retry if service is down."""
    try:
        notification_breaker.call(send_notification, notification)
    except pybreaker.CircuitBreakerError:
        logger.warning("Notification service down, queueing for retry")
        sqs.send_message(
            QueueUrl=NOTIFICATION_RETRY_QUEUE_URL,
            MessageBody=json.dumps(notification),
            MessageAttributes={
                "RetryCount": {"DataType": "Number", "StringValue": "0"},
                "OriginalTimestamp": {"DataType": "String", "StringValue": datetime.utcnow().isoformat()},
            },
        )
```

## Monitoring Circuit Breaker State

### CloudWatch Custom Metrics

```python
import boto3

cloudwatch = boto3.client("cloudwatch", region_name="us-gov-west-1")

def publish_breaker_metrics(breaker: pybreaker.CircuitBreaker):
    """Publish circuit breaker state to CloudWatch."""
    state_value = {"closed": 0, "half-open": 1, "open": 2}
    cloudwatch.put_metric_data(
        Namespace="Olympus/CircuitBreakers",
        MetricData=[
            {
                "MetricName": "CircuitState",
                "Dimensions": [
                    {"Name": "BreakerName", "Value": breaker.name},
                    {"Name": "Application", "Value": APP_NAME},
                ],
                "Value": state_value[breaker.current_state],
                "Unit": "None",
            },
            {
                "MetricName": "FailureCount",
                "Dimensions": [
                    {"Name": "BreakerName", "Value": breaker.name},
                ],
                "Value": breaker.fail_counter,
                "Unit": "Count",
            },
        ],
    )
```

### CloudWatch Alarms

```json
{
  "AlarmName": "CircuitBreakerOpen-InventoryService",
  "Namespace": "Olympus/CircuitBreakers",
  "MetricName": "CircuitState",
  "Dimensions": [{"Name": "BreakerName", "Value": "inventory-service"}],
  "ComparisonOperator": "GreaterThanOrEqualToThreshold",
  "Threshold": 2,
  "EvaluationPeriods": 1,
  "Period": 60,
  "Statistic": "Maximum",
  "AlarmActions": ["arn:aws-us-gov:sns:us-gov-west-1:ACCOUNT:ops-alerts"]
}
```

## Tuning Guidelines

| Parameter | Start With | Adjust Based On |
|-----------|-----------|-----------------|
| Sliding window size | 10 (T1), 20 (T2), 30 (T3) | Traffic volume: higher volume = larger window |
| Failure rate threshold | 50% | Baseline error rate: if normal rate is 2%, threshold at 20% |
| Wait duration (open) | 30s (T1), 60s (T2), 120s (T3) | Dependency recovery time: match typical recovery |
| Half-open requests | 3-5 | Confidence level: more requests = higher confidence |
| Slow call threshold | 5s (T1), 10s (T2), 30s (T3) | SLA requirements: based on acceptable latency |
| Retry max attempts | 3 | Idempotency: only retry idempotent operations |
| Retry base delay | 100ms | Downstream recovery: longer delay if slow recovery |

### Anti-Patterns to Avoid
- **Circuit breaker on database**: use connection pool health checks instead; circuit
  breaker adds latency and hides the real issue (connection pool exhaustion).
- **Retry on non-idempotent operations**: retrying a POST that creates a resource
  can create duplicates. Use idempotency keys.
- **Same timeout for all dependencies**: a fast cache lookup and a slow report
  generation should not share the same timeout value.
- **Ignoring circuit breaker metrics**: an open circuit is a signal that a dependency
  is unhealthy. Alert on it, don't just fall back silently.
