# Chaos Engineering Tests

Reference for aws-resilience-designer when producing chaos test plans.

## Chaos Engineering Principles

1. **Start with a hypothesis**: "If AZ-1 fails, the application continues serving
   requests with degraded latency but no errors."
2. **Minimize blast radius**: Run in staging first; production chaos requires
   explicit approval and a kill switch.
3. **Measure everything**: capture metrics before, during, and after each test.
4. **Automate rollback**: every test must have an automated abort mechanism.

## Test Catalog by Tier

### T1 Tests (Mandatory Quarterly)

#### AZ Failure Simulation
**Hypothesis:** Application continues serving requests when one AZ is lost.

**Method (AWS Fault Injection Simulator):**
```json
{
  "description": "Simulate AZ-1 failure by stopping Fargate tasks in AZ-1",
  "targets": {
    "ecsTasksAz1": {
      "resourceType": "aws:ecs:task",
      "selectionMode": "ALL",
      "resourceTags": {"AvailabilityZone": "us-gov-west-1a"},
      "filters": [
        {"path": "Cluster", "values": ["my-cluster"]}
      ]
    }
  },
  "actions": {
    "stopTasks": {
      "actionId": "aws:ecs:stop-task",
      "targets": {"Tasks": "ecsTasksAz1"},
      "parameters": {}
    }
  },
  "stopConditions": [
    {"source": "aws:cloudwatch:alarm", "value": "arn:aws-us-gov:cloudwatch:...:alarm:ChaosSafetyStop"}
  ]
}
```

**Alternative (manual):**
1. Deregister all targets in AZ-1 from the ALB target group
2. Monitor error rates and latency for 15 minutes
3. Re-register targets
4. Verify tasks reschedule and health checks pass

**Success criteria:**
- Error rate stays below 1% during AZ loss
- Latency p99 increases by no more than 50%
- Auto-scaling replaces lost capacity within 2 minutes
- No manual intervention required

**Abort trigger:** Error rate exceeds 5% or latency p99 exceeds 5x baseline.

---

#### Database Failover Test
**Hypothesis:** Application recovers from Aurora failover within 60 seconds.

**Method:**
```bash
# Trigger Aurora failover
aws rds failover-db-cluster \
  --db-cluster-identifier my-aurora-cluster \
  --region us-gov-west-1

# Monitor application health endpoint during failover
while true; do
  response=$(curl -s -o /dev/null -w "%{http_code}" https://app.internal/api/health)
  echo "$(date +%s) $response"
  sleep 1
done
```

**Success criteria:**
- Application returns errors for no more than 60 seconds
- Connection pool reconnects automatically (no restart required)
- No data loss (verify by checking pre-failover write is readable post-failover)
- Application logs show reconnection, not crash

**Common failures found in testing:**
- Connection pool does not have `pool_pre_ping` enabled; stale connections cause errors for minutes
- Application caches the DNS resolution; failover endpoint change is not picked up
- Long-running transactions are lost; application does not retry them

---

#### Dependency Failure Test
**Hypothesis:** Circuit breaker trips and fallback activates when downstream is unavailable.

**Method (network policy):**
```bash
# Block outbound to dependency using security group
aws ec2 revoke-security-group-egress \
  --group-id sg-fargate-tasks \
  --ip-permissions '[{"IpProtocol":"tcp","FromPort":443,"ToPort":443,"IpRanges":[{"CidrIp":"10.0.100.0/24","Description":"inventory-service"}]}]' \
  --region us-gov-west-1

# Wait for circuit breaker to trip (check metrics)
sleep 60

# Verify fallback responses
curl https://app.internal/api/items/12345
# Should return cached/degraded response, not 5xx

# Restore connectivity
aws ec2 authorize-security-group-egress \
  --group-id sg-fargate-tasks \
  --ip-permissions '[{"IpProtocol":"tcp","FromPort":443,"ToPort":443,"IpRanges":[{"CidrIp":"10.0.100.0/24","Description":"inventory-service"}]}]' \
  --region us-gov-west-1
```

**Success criteria:**
- Circuit breaker trips within the configured sliding window
- Fallback response is returned (cached data or degraded response)
- Application does not return 5xx to end users
- Circuit breaker recovers (half-open -> closed) after connectivity is restored

---

#### Latency Injection Test
**Hypothesis:** Application handles slow dependencies without cascading timeouts.

**Method (AWS FIS network action):**
```json
{
  "description": "Add 5 second latency to database calls",
  "actions": {
    "injectLatency": {
      "actionId": "aws:ecs:task-network-latency",
      "parameters": {
        "duration": "PT10M",
        "delayMilliseconds": "5000",
        "jitterMilliseconds": "1000",
        "sources": "10.0.200.0/24"
      },
      "targets": {"Tasks": "ecsTasks"}
    }
  },
  "stopConditions": [
    {"source": "aws:cloudwatch:alarm", "value": "arn:aws-us-gov:cloudwatch:...:alarm:ChaosSafetyStop"}
  ]
}
```

**Success criteria:**
- Timeout budget limits propagation: downstream timeout fires before overall timeout
- Slow call circuit breaker trips if latency persists
- Application returns degraded response instead of timing out the entire request
- Thread pool / connection pool is not exhausted by blocked calls

---

#### Memory and CPU Pressure Test
**Hypothesis:** Auto-scaling triggers and replaces stressed containers before user impact.

**Method (stress tool in container):**
```bash
# Run stress tool inside a Fargate task via ECS Exec
aws ecs execute-command \
  --cluster my-cluster \
  --task TASK_ARN \
  --container app \
  --interactive \
  --command "stress-ng --cpu 4 --vm 2 --vm-bytes 80% --timeout 300"
```

**Success criteria:**
- CloudWatch alarm triggers when CPU exceeds auto-scaling target
- New tasks are launched within 2 minutes
- Stressed task is eventually replaced by ECS health check
- No out-of-memory kills (OOMKilled) propagate to user-facing errors

---

#### DNS Failure Simulation
**Hypothesis:** Application handles DNS resolution failure gracefully.

**Method:**
```bash
# Override DNS resolution in the container via /etc/hosts
# (requires ECS Exec access)
aws ecs execute-command \
  --cluster my-cluster \
  --task TASK_ARN \
  --container app \
  --interactive \
  --command "echo '127.0.0.1 dependency.internal' >> /etc/hosts"
```

**Success criteria:**
- Dependency calls fail fast (connection refused, not timeout)
- Circuit breaker trips on connection failures
- Fallback activates as expected
- DNS resolution recovers when override is removed

---

#### Redis Failover Test
**Hypothesis:** Application handles cache unavailability during ElastiCache failover.

**Method:**
```bash
# Trigger ElastiCache failover
aws elasticache test-failover \
  --replication-group-id my-redis-group \
  --node-group-id 0001 \
  --region us-gov-west-1
```

**Success criteria:**
- Application falls back to database queries during cache unavailability
- No cache stampede on recovery (jittered TTLs)
- Failover completes within 30 seconds
- Application latency increases but errors stay below 1%

---

### T2 Tests (Recommended Semi-Annually)

Run these tests from the T1 catalog with relaxed success criteria:
- **AZ Failure**: error rate below 5%, recovery within 5 minutes
- **Database Failover**: recovery within 2 minutes, brief errors acceptable
- **Dependency Timeout**: circuit breaker and fallback validation
- **Container Recovery**: auto-scaling within 5 minutes

### T3 Tests (Annual Review)

- **Database Backup Restore**: verify backup can be restored to a new instance
- **Container Failure Recovery**: manually stop tasks, verify ECS restarts them
- **Monitoring Validation**: trigger an alarm condition, verify notification arrives

---

## Test Execution Checklist

```markdown
## Pre-Test
- [ ] Hypothesis documented
- [ ] Success criteria defined with measurable thresholds
- [ ] Abort trigger defined (CloudWatch alarm or manual threshold)
- [ ] Rollback procedure tested
- [ ] Stakeholders notified (operations, application team)
- [ ] Monitoring dashboards open
- [ ] Test runs in staging first (production requires separate approval)

## During Test
- [ ] Monitoring is active and being observed
- [ ] Error rates, latency, and availability are being recorded
- [ ] Abort trigger is active and responsive
- [ ] Communication channel is open with operations team

## Post-Test
- [ ] Rollback executed (or confirmed unnecessary)
- [ ] Metrics collected (before, during, after)
- [ ] Success criteria evaluated against measurements
- [ ] Findings documented (what worked, what failed, what surprised)
- [ ] Action items created for any gaps found
- [ ] Test results stored in resilience matrix (update tested/last_test_date)
```

## Tools

| Tool | Description | Use Case |
|------|-------------|----------|
| AWS Fault Injection Simulator | AWS-native chaos service | AZ failure, network faults, ECS task stop |
| Gremlin | Commercial chaos platform | Advanced failure injection, GameDays |
| Custom Lambda | Self-built chaos functions | Targeted tests (security group manipulation, DNS override) |
| stress-ng | Linux stress testing tool | CPU/memory pressure inside containers |
| toxiproxy | Programmable TCP proxy | Latency injection, connection reset simulation |
| tc (traffic control) | Linux network shaping | Network latency and packet loss |
