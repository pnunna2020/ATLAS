# Database Failover Patterns

Reference for aws-resilience-designer when designing data resilience.

## Aurora PostgreSQL Multi-AZ Failover

### How It Works
Aurora maintains a primary (writer) instance and up to 15 read replicas. In a
multi-AZ deployment, replicas are placed in different Availability Zones. Aurora
uses a shared storage layer (6-way replicated across 3 AZs) that is independent
of the compute instances.

**Failover trigger conditions:**
- Primary instance failure (crash, hang, hardware failure)
- AZ disruption affecting the primary
- Manual failover initiated via CLI or console
- Planned maintenance (patched instances fail over gracefully)

**Failover process:**
1. Aurora detects primary failure (typically within 10-20 seconds)
2. Aurora promotes the highest-priority replica to primary
3. DNS record (cluster endpoint) is updated to point to new primary
4. Application reconnects via the cluster endpoint
5. Total failover time: typically 30-60 seconds

### Connection String Management

**Cluster endpoints (recommended):**
```
# Writer endpoint: always points to current primary
writer: my-cluster.cluster-abc123.us-gov-west-1.rds.amazonaws.com:5432

# Reader endpoint: load balances across read replicas
reader: my-cluster.cluster-ro-abc123.us-gov-west-1.rds.amazonaws.com:5432
```

Never use instance-specific endpoints in application configuration. The cluster
endpoint automatically resolves to the current primary after failover.

**RDS Proxy (recommended for T1/T2):**
```
# Proxy endpoint: connection pooling + automatic failover transparency
proxy: my-proxy.proxy-abc123.us-gov-west-1.rds.amazonaws.com:5432
```

RDS Proxy maintains idle connections and handles failover transparently. The
application sees a brief connection interruption (~1-2 seconds) instead of a
DNS propagation delay.

### Application Connection Pool Configuration

```python
# SQLAlchemy configuration for Aurora failover resilience
from sqlalchemy import create_engine

engine = create_engine(
    "postgresql+psycopg2://user:pass@cluster-endpoint:5432/dbname",
    pool_size=20,
    max_overflow=10,
    pool_timeout=30,
    pool_recycle=1800,          # Recycle connections every 30 minutes
    pool_pre_ping=True,         # Test connection before checkout (critical for failover)
    connect_args={
        "connect_timeout": 5,   # Fail fast on connection attempt
        "options": "-c statement_timeout=30000",  # 30s query timeout
    },
)
```

**Critical: `pool_pre_ping=True`** - Without this, the application will attempt
to use stale connections after failover and receive connection errors. With
pre-ping, SQLAlchemy tests each connection before use and discards dead ones.

```java
// HikariCP configuration for Aurora failover resilience
HikariConfig config = new HikariConfig();
config.setJdbcUrl("jdbc:postgresql://cluster-endpoint:5432/dbname");
config.setMaximumPoolSize(20);
config.setMinimumIdle(5);
config.setConnectionTimeout(5000);      // 5s connection timeout
config.setValidationTimeout(3000);      // 3s validation timeout
config.setMaxLifetime(1800000);         // 30 min max connection lifetime
config.setConnectionTestQuery("SELECT 1"); // Validation query
config.setKeepaliveTime(300000);        // 5 min keepalive
```

### Failover Priority Configuration

```shell
# Set failover priority tiers (0 = highest priority for promotion)
aws rds modify-db-instance \
  --db-instance-identifier my-replica-az1 \
  --promotion-tier 0 \
  --region us-gov-west-1

aws rds modify-db-instance \
  --db-instance-identifier my-replica-az2 \
  --promotion-tier 1 \
  --region us-gov-west-1
```

Always set explicit promotion priorities. Without them, Aurora promotes the
replica with the most recent transaction log position, which may not be the
replica you want (e.g., it might be in a less desirable AZ).

---

## Aurora Cross-Region Failover (Global Database)

### How It Works
Aurora Global Database uses dedicated replication infrastructure for cross-region
replication. The primary region handles writes; secondary regions have read-only
clusters with replication lag typically under 1 second.

**Cross-region failover is a manual process** with these steps:
1. Detach the secondary cluster from the global database
2. The secondary cluster becomes an independent, standalone cluster with read/write capability
3. Update application configuration to point to the promoted cluster
4. Rebuild the global database relationship when the primary region recovers

### RPO and RTO for Cross-Region

| Scenario | RPO | RTO |
|---------|-----|-----|
| Multi-AZ failover (same region) | 0 (shared storage) | 30-60 seconds |
| Global Database managed failover | ~1 second typical | 1-2 minutes |
| Global Database detach + promote | ~1 second typical | 5-10 minutes (manual) |
| Snapshot restore in new region | Hours (last snapshot) | 30-60 minutes |

**Important for T1 applications**: Aurora Global Database replication is
asynchronous. RPO is approximately 1 second, not zero. For true RPO=0, rely
on multi-AZ within a single region where Aurora's shared storage provides
synchronous 6-way replication.

### Cross-Region Failover Runbook

```
AURORA GLOBAL DATABASE FAILOVER RUNBOOK
=========================================

TRIGGER: Primary region (us-gov-west-1) is unavailable or degraded.

PRE-CONDITIONS:
- Global Database is configured with secondary in us-gov-east-1
- Application supports configuration update or DNS-based endpoint switching
- Runbook has been tested in the last quarter

STEPS:
1. CONFIRM primary region failure (not a transient issue)
   - Check AWS Health Dashboard
   - Verify from multiple sources (not just application errors)
   - Escalate to operations lead for approval

2. INITIATE managed failover (preferred) or manual detach
   Managed failover (if primary region API is reachable):
     aws rds failover-global-cluster \
       --global-cluster-identifier my-global-cluster \
       --target-db-cluster-identifier arn:aws:rds:us-gov-east-1:ACCOUNT:cluster:my-secondary

   Manual detach (if primary region is unreachable):
     aws rds remove-from-global-cluster \
       --global-cluster-identifier my-global-cluster \
       --db-cluster-identifier arn:aws:rds:us-gov-east-1:ACCOUNT:cluster:my-secondary \
       --region us-gov-east-1

3. VERIFY secondary cluster is writable
   psql -h secondary-cluster-endpoint -U admin -d dbname -c "SELECT pg_is_in_recovery();"
   -- Should return 'f' (false) indicating primary mode

4. UPDATE application endpoints
   - Update Route53 CNAME or application configuration
   - Restart application instances to pick up new endpoint
   - Verify application connectivity

5. VALIDATE operations
   - Run smoke tests against the promoted cluster
   - Verify write operations succeed
   - Check replication lag (should be 0 as it's now standalone)

6. DOCUMENT
   - Record failover time, data loss assessment, approvals
   - Create incident report

POST-RECOVERY (when primary region returns):
1. Create new global database from the promoted cluster
2. Add the original primary region as a secondary
3. Plan failback during maintenance window
```

---

## DynamoDB Global Tables

### How It Works
DynamoDB Global Tables provide active-active replication across regions. Both
regions can accept writes. Conflicts are resolved using last-writer-wins based
on timestamps.

**Key characteristics:**
- Replication lag: typically under 1 second
- Consistency model: eventually consistent across regions
- Conflict resolution: last-writer-wins (timestamp-based)
- No manual failover needed: both regions are always writable

### When to Use
- Session state storage (each region writes its own sessions)
- Configuration data (infrequent writes, read-heavy)
- Feature flags and toggles

### When NOT to Use
- Financial transactions requiring strong consistency
- Sequence-dependent operations (counter increments)
- Applications that cannot tolerate eventual consistency

---

## ElastiCache Redis Failover

### Replication Group Failover

```
Primary (AZ-1) ←──replication──→ Replica-1 (AZ-2)
                ←──replication──→ Replica-2 (AZ-3)

On primary failure:
1. ElastiCache detects primary failure (within 10-15 seconds)
2. Promotes replica with lowest replication lag
3. Updates DNS endpoint to new primary
4. Other replicas re-point to new primary
5. Total failover: 15-30 seconds
```

### Application Handling

```python
import redis
from redis.sentinel import Sentinel
from redis.exceptions import ConnectionError, ReadOnlyError

class ResilientRedisClient:
    """Redis client with failover handling."""

    def __init__(self, endpoint: str, port: int = 6379):
        self.client = redis.Redis(
            host=endpoint,
            port=port,
            socket_timeout=5,
            socket_connect_timeout=5,
            retry_on_timeout=True,
            retry_on_error=[ConnectionError, ReadOnlyError],
            retry=redis.retry.Retry(
                retries=3,
                backoff=redis.backoff.ExponentialBackoff(base=0.1, cap=2),
            ),
        )

    def get_with_fallback(self, key: str, default=None):
        """Get value with graceful fallback on cache miss or failure."""
        try:
            value = self.client.get(key)
            return value if value is not None else default
        except (ConnectionError, ReadOnlyError):
            # Cache unavailable during failover; return default
            return default
```

### Cache Stampede Prevention
During failover, the cache is temporarily unavailable. When it comes back, all
application instances simultaneously attempt to repopulate the cache, creating
a stampede on the database.

```python
import hashlib
import random

def get_with_stampede_prevention(key: str, fetch_fn, ttl: int = 300):
    """Fetch with jittered TTL and probabilistic early expiry."""
    value = cache.get(key)
    if value is not None:
        return value

    # Add jitter to prevent all instances refreshing at the same time
    lock_key = f"lock:{key}"
    if cache.set(lock_key, "1", ex=10, nx=True):  # Acquire lock for 10s
        try:
            result = fetch_fn()
            jittered_ttl = ttl + random.randint(-30, 30)  # +/- 30 seconds
            cache.set(key, result, ex=jittered_ttl)
            return result
        finally:
            cache.delete(lock_key)
    else:
        # Another instance is refreshing; wait briefly and retry
        import time
        time.sleep(0.5)
        return cache.get(key)  # May still be None; caller handles
```

---

## Split-Brain Prevention

Split-brain occurs when network partitioning causes two nodes to both believe
they are the primary. This can result in conflicting writes and data corruption.

### Aurora
Aurora's shared storage architecture inherently prevents split-brain at the
storage layer. Even if two compute instances both attempt writes, the storage
layer serializes them. Aurora uses a quorum-based protocol (4 of 6 storage
nodes must acknowledge) that prevents divergent writes.

### ElastiCache Redis
Redis replication is asynchronous. During a network partition, a promoted
replica and the original primary may both accept writes temporarily.

**Mitigations:**
- Set `min-replicas-to-write: 1` to require at least one replica acknowledgment
  before accepting writes on the primary
- Set `min-replicas-max-lag: 10` to reject writes if replicas lag more than 10 seconds
- Accept that brief split-brain is possible during partition; design application
  to handle duplicate or conflicting data (idempotency keys)

### General Principles
1. Prefer storage systems with built-in split-brain prevention (Aurora, DynamoDB)
2. For systems without it (Redis), design for eventual consistency
3. Use idempotency keys on all write operations
4. Monitor replication lag as an early warning of partition risk
5. Test split-brain scenarios during chaos engineering exercises
