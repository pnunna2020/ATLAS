# Resilience Patterns by Risk Tier

Reference for aws-resilience-designer when selecting patterns per application risk tier.

## Tier 1: Safety-Critical (NAS)

RTO: 15 minutes | RPO: 0 (zero data loss) | Availability: 99.99% (52.6 min downtime/year)

### Compute Resilience
- **Multi-AZ active-active**: ECS Fargate tasks distributed across 3 Availability Zones
- **Task placement**: spread across AZs using `spread` placement strategy
- **Minimum healthy percent**: 100% during deployments (no capacity reduction)
- **Auto-scaling**: target tracking on CPU (60%) and memory (70%), with scheduled scaling
  for known peak periods; scale-out cooldown 60s, scale-in cooldown 300s
- **Task count**: minimum 3 tasks (one per AZ), maximum based on load testing
- **Health checks**:
  - ALB health check: `/api/health` deep endpoint, interval 10s, threshold 2 unhealthy
  - ECS health check: container-level, interval 15s, retries 3
  - Deep health check validates: process alive, database connection, cache connection,
    critical dependency reachability
- **Graceful shutdown**: SIGTERM handler drains in-flight requests (30s timeout)
- **Container restart**: ECS automatically replaces failed tasks within 30-60 seconds

### Data Resilience
- **Aurora PostgreSQL Multi-AZ**: writer instance + 2 reader replicas across 3 AZs
- **Aurora Global Database**: cross-region read replica in us-gov-east-1 for disaster recovery
  - Replication lag: typically <1 second (asynchronous)
  - Manual promotion for cross-region failover (RPO ~1 second)
  - For true RPO=0: rely on multi-AZ within the primary region (synchronous replication)
- **Point-in-time recovery**: enabled with 35-day retention window
- **Automated snapshots**: daily, retained for 35 days
- **Manual snapshots**: before major deployments, retained indefinitely
- **RDS Proxy**: connection pooling, automatic failover transparency, IAM authentication
  - Pin timeout: 24 hours for session-level state
  - Max connections: 100% of `max_connections` parameter
- **ElastiCache Redis**:
  - Replication group with 1 primary + 2 replicas across 3 AZs
  - Automatic failover enabled (promotion within 30 seconds)
  - Cluster mode enabled for horizontal scaling
  - Backup: daily snapshot, 7-day retention
- **S3**:
  - Versioning enabled on all buckets
  - Cross-region replication to us-gov-east-1
  - Lifecycle rules: transition to IA after 90 days, Glacier after 365 days
  - Object Lock for compliance-critical artifacts

### Integration Resilience
- **Circuit breaker** (all external dependencies):
  - Implementation: Resilience4j (Java) or pybreaker/tenacity (Python)
  - Failure threshold: 50% failure rate over 10-call sliding window
  - Wait duration in open state: 30 seconds
  - Half-open state: allow 3 requests before deciding
  - Fallback: return cached data (max 5 minutes stale) or degraded response
  - State storage: Redis-backed for consistency across tasks
- **Retry policy**:
  - Exponential backoff with jitter: base 100ms, max 10s, max retries 3
  - Retry only on transient errors (5xx, connection timeout, connection reset)
  - Do not retry on 4xx (client errors) or business logic failures
- **Timeout budget**:
  - Overall request timeout: 30 seconds
  - Each downstream call: min(remaining budget, service SLA)
  - Propagate timeout via request headers for distributed tracing
- **Dead letter queues**:
  - SQS DLQ with maxReceiveCount=3
  - DLQ alarm when message count > 0
  - DLQ processing Lambda for automated retry or alert escalation
- **Bulkhead**:
  - Separate thread pools per dependency (Java) or connection pools (Python)
  - Max concurrent calls per dependency: tuned based on downstream capacity
  - Rejection policy: fast-fail with circuit breaker fallback

### Deployment Resilience
- **Canary deployment**: 5% -> 25% -> 50% -> 100% over 14 days
  - Stage 1 (Day 0-3): 5% canary, monitor error rates, latency p99, business metrics
  - Stage 2 (Day 3-7): 25% canary if Stage 1 clean
  - Stage 3 (Day 7-10): 50% canary if Stage 2 clean
  - Stage 4 (Day 10-14): 100% if Stage 3 clean
  - Automatic rollback: CloudWatch alarm triggers if error rate > 1% or latency p99 > 2x baseline
- **Feature flags**: all new features behind flags for kill-switch capability
- **Database migrations**: expand-contract pattern, backward compatible, tested independently

### Observability
- **Metrics**: CloudWatch custom metrics for circuit breaker state, failover events,
  replication lag, DLQ depth; Datadog dashboards for operational view
- **Alarms**: PagerDuty integration for T1 alerts; auto-escalation after 5 minutes
- **Distributed tracing**: X-Ray or OpenTelemetry for request tracing across services
- **Runbooks**: automated runbooks in Systems Manager for common failure scenarios

### Chaos Engineering (Mandatory Quarterly)
- AZ failure simulation (remove AZ from ALB target group)
- Database failover (trigger Aurora failover, measure reconnection time)
- Dependency failure (block outbound to dependency, verify circuit breaker)
- Latency injection (add 5s delay to downstream calls)
- Memory/CPU pressure (stress test containers to auto-scaling threshold)
- DNS failure simulation (verify fallback behavior)
- Redis failover (trigger ElastiCache failover, verify cache miss handling)

---

## Tier 2: Mission-Support

RTO: 1 hour | RPO: 15 minutes | Availability: 99.95% (4.38 hr downtime/year)

### Compute Resilience
- **Multi-AZ**: ECS Fargate tasks across 2 Availability Zones
- **Minimum healthy percent**: 50% during deployments
- **Auto-scaling**: target tracking on CPU (70%), scale-out cooldown 120s, scale-in cooldown 300s
- **Task count**: minimum 2 tasks (one per AZ)
- **Health checks**:
  - ALB health check: `/api/health` basic endpoint, interval 30s, threshold 3 unhealthy
  - Deep health check validates: process alive, database connection
- **Graceful shutdown**: SIGTERM handler with 30s drain

### Data Resilience
- **Aurora PostgreSQL Multi-AZ**: writer instance + 1 reader replica across 2 AZs
- **No cross-region replication** (RPO 15 minutes met by multi-AZ within region)
- **Point-in-time recovery**: enabled with 14-day retention
- **Automated snapshots**: daily, retained for 14 days
- **RDS Proxy**: connection pooling, automatic failover transparency
- **ElastiCache Redis**:
  - Replication group with 1 primary + 1 replica across 2 AZs
  - Automatic failover enabled
  - Backup: daily snapshot, 3-day retention
- **S3**:
  - Versioning enabled
  - No cross-region replication (single region sufficient)
  - Lifecycle rules: transition to IA after 180 days

### Integration Resilience
- **Circuit breaker** (critical dependencies):
  - Failure threshold: 50% failure rate over 20-call sliding window
  - Wait duration in open state: 60 seconds
  - Fallback: degraded response or cached data (max 15 minutes stale)
  - State storage: local (per-task) is acceptable
- **Retry policy**:
  - Exponential backoff with jitter: base 200ms, max 15s, max retries 3
- **Timeout budget**: overall 60 seconds
- **Dead letter queues**: maxReceiveCount=5, alarm on count > 10

### Deployment Resilience
- **Blue-green deployment**: 24-hour validation window
  - Deploy green environment, run smoke tests
  - Shift 100% traffic to green
  - Monitor for 24 hours
  - Automatic rollback if error rate > 5% or latency p99 > 3x baseline
  - Terminate blue after 24 hours if green is clean
- **Feature flags**: recommended for high-risk features
- **Database migrations**: backward compatible, expand-contract pattern

### Observability
- **Metrics**: CloudWatch standard metrics + custom metrics for critical paths
- **Alarms**: email + Slack notification, escalation after 15 minutes
- **Distributed tracing**: X-Ray for request tracing

### Chaos Engineering (Recommended Semi-Annually)
- AZ failure simulation
- Database failover test
- Dependency timeout injection
- Container failure recovery validation

---

## Tier 3: Administrative

RTO: 4 hours | RPO: 1 hour | Availability: 99.9% (8.76 hr downtime/year)

### Compute Resilience
- **Single-AZ acceptable** for non-critical administrative applications
- **Multi-AZ optional** if cost permits
- **Auto-scaling**: target tracking on CPU (70%), simpler configuration
- **Task count**: minimum 1 task (2 if multi-AZ)
- **Health checks**:
  - ALB health check: `/api/health` shallow endpoint, interval 30s, threshold 5 unhealthy
  - Shallow health check: process alive check only

### Data Resilience
- **Aurora PostgreSQL**: single-AZ with automated backups is sufficient
  - Multi-AZ optional if budget allows
- **Point-in-time recovery**: enabled with 7-day retention
- **Automated snapshots**: daily, retained for 7 days
- **ElastiCache Redis**: single node (no replication required)
  - Backup: daily snapshot, 1-day retention
- **S3**: versioning enabled, standard lifecycle rules

### Integration Resilience
- **Basic retry logic**: 3 retries with fixed 1-second delay
- **Circuit breaker**: optional, recommended for external dependencies
- **Timeout**: 120 seconds overall
- **Dead letter queues**: recommended but not required

### Deployment Resilience
- **Blue-green deployment**: 4-hour validation window
  - Deploy green, run smoke tests
  - Shift traffic, monitor for 4 hours
  - Automatic rollback if error rate > 10%
  - Terminate blue after 4 hours
- **Feature flags**: optional

### Observability
- **Metrics**: CloudWatch standard metrics
- **Alarms**: email notification, business-hours response acceptable
- **Distributed tracing**: optional

### Chaos Engineering (Annual Review)
- Database backup restore test
- Container failure recovery validation
- Verify monitoring and alerting works

---

## Cross-Tier Patterns

These patterns apply regardless of tier:

### Security Resilience
- **Secrets rotation**: Secrets Manager with automatic rotation (30 days for T1, 90 days for T2/T3)
- **Certificate management**: ACM with auto-renewal
- **WAF**: AWS WAF on ALB with rate limiting, SQL injection rules, XSS rules
- **VPC security**: security groups (stateful), NACLs (stateless), VPC Flow Logs

### Network Resilience
- **DNS**: Route53 health checks with failover routing (T1 only)
- **CDN**: CloudFront for static assets, with origin failover
- **Load balancing**: ALB with cross-zone load balancing enabled
- **VPC endpoints**: gateway endpoints for S3/DynamoDB, interface endpoints for AWS services
  (reduces NAT Gateway traffic and provides private connectivity)

### Data Protection
- **Encryption at rest**: KMS customer-managed keys (CMK) for all data stores
- **Encryption in transit**: TLS 1.2+ enforced on all endpoints
- **Backup testing**: quarterly restore test for T1, semi-annual for T2, annual for T3

### Cost Optimization
- **Fargate Spot**: acceptable for T3 non-critical workloads, never for T1/T2
- **Reserved capacity**: Savings Plans for predictable T1/T2 workloads
- **Right-sizing**: monthly review of resource utilization, adjust task CPU/memory
