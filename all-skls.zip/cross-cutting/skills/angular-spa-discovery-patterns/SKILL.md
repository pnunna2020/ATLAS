---
name: angular-spa-discovery-patterns
description: >
  Recover the architecture, build tooling, module structure, routing, state
  management, test stack, and migration-debt surface of an Angular SPA
  during Discovery. Parses `angular.json`, per-project `tsconfig.json`,
  `package.json`, `proxy.conf.json`, and custom `webpack.config.js`
  overrides; walks NgModules, components, services, guards, resolvers,
  and HTTP interceptors; inventories RxJS usage and state-management
  style; and flags deprecated tooling (TSLint, Protractor, View Engine,
  HttpModule, `loadChildren` string syntax, Yarn v1 classic) with
  `{repo}:{file}:{line}` traceability for every claim. Runs as a
  Discovery conditional skill when `tech_stack_contains` includes
  angular, angular-cli, typescript, or typescript-spa, or when the repo
  contains `angular.json`. Triggers on Angular discovery, SPA discovery,
  TypeScript SPA discovery, or @angular-spa-discovery-patterns.
tier: 1
triggers:
  tech_stack_contains: [angular, angular-cli, typescript, typescript-spa]
  filesystem_markers: [angular.json]
agent: sonnet
enrichment_level: Full
version: 0.1.0
allowed-tools:
  - Read
  - Grep
  - Glob
  - Write
validation_commands:
  - "python -m olympus.validators.schema_validator angular-workspace-manifest.json"
  - "python -m olympus.validators.schema_validator angular-module-graph.json"
  - "python -m olympus.validators.schema_validator angular-component-manifest.json"
  - "python -m olympus.validators.schema_validator angular-routing-graph.json"
  - "python -m olympus.validators.schema_validator angular-service-inventory.json"
  - "python -m olympus.validators.schema_validator angular-state-management-findings.json"
  - "python -m olympus.validators.schema_validator angular-dependency-inventory.json"
  - "python -m olympus.validators.schema_validator angular-build-tooling-findings.json"
  - "python -m olympus.validators.schema_validator angular-test-tooling-manifest.json"
  - "python -m olympus.validators.schema_validator angular-legacy-migration-findings.json"
supported_stacks:
  - angular
  - angular-cli
  - typescript
  - typescript-spa
  - rxjs
  - ngrx
anti_target_stacks:
  - react
  - next.js
  - vue
  - svelte
  - static-site
  - spa-vanilla
failure_classes:
  - angular-version-misidentified
  - tslint-config-missed
  - protractor-config-missed
  - yarn-v1-vs-berry-confused
  - multi-project-workspace-flattened
  - lazy-load-string-syntax-missed
  - httpinterceptor-chain-not-inventoried
  - rxjs-subscribe-leak-undetected
  - view-engine-vs-ivy-mixed
  - environment-file-unredacted
benchmark_tags:
  - discovery-spa
  - angular-workspace-inventory
  - frontend-migration-debt
  - rxjs-leak-detection
---

# Angular SPA Discovery Patterns

## Purpose
Recover the architecture and runtime shape of an Angular single-page
application from source during Discovery so that `catalog-application`,
`analyze-application`, and `dependency-mapper` can emit a complete,
traceable catalog entry, and so that downstream Rationalization has the
migration-debt surface it needs to score disposition. This skill is the
Angular counterpart to `dotnet-discovery-patterns` on the server side and
the feedstock for `react-page-generation` on the target side: given an
Angular 8+ workspace, it identifies CLI version and builders, walks
NgModules and components, inventories RxJS usage, routing (including
lazy-loaded modules), guards, resolvers, services, HttpClient sites, and
HTTP interceptor chains, and surfaces every deprecated tool wired into
the build (TSLint, Protractor, View Engine, `HttpModule`, `loadChildren`
string syntax, Yarn v1 classic, custom webpack overrides). Without this
pass, an Angular app sinks to an opaque `angular` token and
Rationalization cannot tell an Angular 17 app on Ivy apart from an
Angular 8 app still shipping TSLint and Protractor.

## Inputs
- Source code repository containing `angular.json`, `package.json`,
  one or more `tsconfig*.json`, `.ts`/`.html`/`.scss`/`.css` source,
  and (optionally) `proxy.conf.json`, `webpack.config.js`,
  `karma.conf.js`, `protractor.conf.js`, `tslint.json`,
  `.eslintrc.json`, `yarn.lock`, or `package-lock.json`.
- Application catalog entry stub (per
  `schemas/discovery/application-catalog-entry.schema.json`) with
  `primary_language` populated as `typescript`.
- Tech fingerprint from `analyze-application` Pass 1 when available.
- Client-profile risk-classification config for tier banding of
  emitted findings.
- Optional: backend API contract (`openapi.yaml`, `.proto`, or the
  companion `.NET` discovery fingerprint) to cross-reference
  `proxy.conf.json` targets against backend routes.

## Outputs
- `angular-workspace-manifest.json` — `angular_version`, `cli_version`,
  `default_project`, `schematics`, and `workspace_projects[]` with
  `name`, `project_type` (`application` | `library`), `root_path`,
  `sourceRoot`, `build_config`, `test_config`, `e2e_config`.
- `angular-module-graph.json` — NgModule inventory: `module_name`,
  `file_path`, `declarations[]`, `imports[]`, `providers[]`,
  `exports[]`, `bootstrap[]`, `is_root`, `is_feature`,
  `is_lazy_loaded`, `lazy_load_route`.
- `angular-component-manifest.json` — per component: `selector`,
  `template_url_or_inline`, `styleUrls[]`,
  `change_detection_strategy`, `input_bindings[]`,
  `output_bindings[]`, `lifecycle_hooks_used[]`.
- `angular-routing-graph.json` — eager and lazy routes,
  `loadChildren` syntax style, and
  `CanActivate`/`CanDeactivate`/`Resolve` references per route.
- `angular-service-inventory.json` — `@Injectable` services with
  `providedIn` scope, every `HttpClient.{get,post,put,delete,patch}`
  call site, and the ordered `HTTP_INTERCEPTORS` chain.
- `angular-state-management-findings.json` — state style (`ngrx` |
  `akita` | `ngxs` | `service-behaviorsubject` | `mixed` | `none`),
  RxJS patterns, subscription-leak candidates.
- `angular-dependency-inventory.json` — npm deps and devDeps with
  semver, flagging Angular major (8-17+), TSLint vs. ESLint,
  Protractor vs. Cypress/Playwright, Yarn v1 vs. Berry, webpack
  version, RxJS major.
- `angular-build-tooling-findings.json` — architect targets,
  budgets, custom webpack overrides, `proxy.conf.json` rules,
  source-map config, AOT vs. JIT, `enableIvy`, `browserslist`.
- `angular-test-tooling-manifest.json` — Karma, Jasmine vs. Jest,
  Protractor vs. Cypress vs. Playwright, coverage thresholds.
- `angular-legacy-migration-findings.json` — one finding per
  deprecated tool in use (TSLint, Protractor, View Engine,
  `HttpModule`, `loadChildren` string, template-driven-only forms,
  deprecated RxJS operators, RxJS v5 path imports).
- All findings carry `{artifact}:{section}:{finding-id}` and
  `{repo}:{file}:{line}`.

## Methodology
1. **Enumerate the workspace.** Read `angular.json`. Record workspace
   `version` (1 or 2), `defaultProject`, and one entry per key under
   `projects`. For each project capture `projectType`, `root`,
   `sourceRoot`, `prefix`, and the full `architect` target block
   (`build`, `serve`, `test`, `lint`, `e2e`, `extract-i18n`). Do not
   assume one project per workspace: DMS has three.
2. **Resolve Angular and CLI version.** From `package.json`, read
   `dependencies['@angular/core']` and `devDependencies['@angular/cli']`.
   Record both as integers; use the core version to gate downstream
   flags (e.g., `HttpModule` is a build break on v10+,
   `loadChildren` string syntax on v11+).
3. **Walk NgModules.** Glob `**/*.module.ts`. For each, parse the
   `@NgModule({...})` decorator and record `declarations`, `imports`,
   `providers`, `exports`, and `bootstrap`. Flag the root module
   (`bootstrap: [AppComponent]` or equivalent). Flag modules
   referenced by a route's `loadChildren` as `is_lazy_loaded`, and
   record the triggering route path.
4. **Walk components.** Glob `**/*.component.ts`. For each, parse the
   `@Component({...})` decorator and record `selector`, template URL
   or inline template, `styleUrls`, and `changeDetection`. Walk the
   class body for `@Input()`, `@Output()`, and lifecycle-hook method
   signatures.
5. **Walk routing.** Find every `Routes` array (by type annotation or
   `RouterModule.forRoot`/`forChild` call). Record `path`,
   `component`, `loadChildren` (and syntax style), `canActivate`,
   `canDeactivate`, `canLoad`, `resolve`, and children. Emit a
   finding for every string-form `loadChildren`.
6. **Walk services and interceptors.** Glob `**/*.service.ts` and any
   class with `@Injectable`. Record `providedIn` scope and every
   `this.http.{get,post,put,delete,patch}` call site with its URL.
   Separately walk `HTTP_INTERCEPTORS` multi-provider registrations;
   record the ordered list, because interceptor order is behavior.
7. **Inventory state management.** Check `package.json` for
   `@ngrx/store`, `@datorama/akita`, `@ngxs/store`. If none, grep
   source for `new BehaviorSubject`/`ReplaySubject`/`Subject` inside
   `@Injectable` classes. Pattern-scan for `.subscribe(` without a
   matching `takeUntil(`, `take(1)`, `first()`, or `async` pipe and
   flag each as a subscription-leak candidate.
8. **Pull build tooling.** Extract per-project `architect.build`
   builder, `options.budgets[]`, `fileReplacements[]`, `sourceMap`,
   `aot`, `enableIvy`, and `configurations.*` (production, staging,
   local). When the builder is `@angular-builders/custom-webpack`,
   open the referenced `webpack.config.js` and inventory top-level
   plugins, externals, and DefinePlugin values.
9. **Pull dev-server and test tooling.** Read `proxy.conf.json` if
   present; extract every `target` URL as a backend dependency
   signal. Read `karma.conf.js`, `protractor.conf.js` and any
   `protractor.headless.conf.js` sibling, `cypress.config.ts`,
   and `playwright.config.ts`.
10. **Flag legacy tooling.** For each of the following, emit a finding
    into `angular-legacy-migration-findings.json` with a
    `{repo}:{file}:{line}` citation: `tslint.json` present (TSLint
    deprecated 2019); `protractor.conf.js` or
    `protractor.headless.conf.js` present (Protractor deprecated
    2023); `@angular/http` imported (removed v10);
    `loadChildren: '...#ModuleName'` string form (removed v11);
    `import 'rxjs/add/operator/*'` path imports (deprecated RxJS 6);
    `yarn.lock` with v1 classic header and no `.yarnrc.yml` (EOL);
    `enableIvy: false` on v9+ (View Engine holdout); and
    template-driven-only forms (imports `FormsModule` but not
    `ReactiveFormsModule`).
11. **Pull environment files and redact secrets.** For each project,
    locate `environment.ts`, `environment.prod.ts`, and any other
    `environment.*.ts` referenced by `fileReplacements`. Extract API
    URL keys and feature flags into the build-tooling findings;
    redact anything matching a secrets-scan pattern before writing.
12. **Emit findings and validate.** Every record carries a finding id
    (`{artifact}:{section}:{finding-id}`) and at least one source
    citation (`{repo}:{file}:{line}`); records without citations are
    dropped by the validator. Validate each artifact against its
    schema and update the catalog entry's `tech_stack`,
    `primary_runtime`, and `archetype` (`web-app`; library projects
    within the workspace fold into the consuming app).

## Tech-Stack Dispatch

| Trigger | Key patterns |
|---|---|
| `angular.json` at repo root | Angular CLI workspace; parse `projects`, `architect`, `schematics` |
| `@angular/core` in `package.json` dependencies | Confirm Angular; read major version from semver |
| `tslint.json` present and no `.eslintrc.*` | Pre-v12 lint stack; legacy finding fires |
| `protractor.conf.js` (and/or `protractor.headless.conf.js`) | Pre-v12 e2e stack; legacy finding fires |
| `webpack.config.js` at workspace root with `@angular-builders/custom-webpack` | Custom webpack override; version-coupling finding fires |
| `proxy.conf.json` at workspace root | Dev-server API proxy; extract `target` as backend dependency signal |
| Multiple entries under `angular.json:projects` | Multi-project workspace (DMS pattern); walk each project independently |
| `yarn.lock` with `# yarn lockfile v1` header and no `.yarnrc.yml` | Yarn v1 classic; EOL finding fires |

Detection is mechanical. Overlap with `react-page-generation` is
deliberate — that skill consumes the component manifest and routing
graph emitted here for Rearchitect dispositions.

## Gotchas
- **Angular major version determines the migration path.** v8 to v17
  is a 9-step `ng update` chain; v10 is 7 steps; each step can break.
  Record the exact major version verbatim.
- **TSLint deprecated 2019, dropped in Angular CLI v12.** Repos on
  v8-v11 still ship `tslint.json` because `ng update` never forced
  migration. The ESLint default rule set differs, so day-one reports
  will not match.
- **Protractor deprecated 2023, dropped in Angular CLI v12.** DIWS
  has two configs (`protractor.conf.js` +
  `protractor.headless.conf.js`) — the classic CI-runs-headless
  pattern. Cypress or Playwright both require test rewrites, not
  ports.
- **Yarn v1 classic is EOL.** DMS uses it. Yarn v3/v4 (Berry) has an
  incompatible lockfile; migration is not `yarn set version berry`
  alone — it's a PnP-vs-node_modules decision plus plugin changes.
- **Multi-project workspaces are the rule.** DMS has three projects
  (`dms_web_faa`, `dms_web_designee`, `dms-web-shared`). Walk each
  project's `architect` target separately.
- **`loadChildren` string vs. function syntax.** v8 deprecated the
  string form; v11 removed it. Emit a finding for every string form
  on v8-v10 repos.
- **Typing and lint debt signals.** If > 10% of TS annotations are
  explicit `any`, emit a typing-debt finding. Count
  `// tslint:disable-next-line` suppressions per file; outliers are
  migration hot-spots.
- **Custom `webpack.config.js` ties the repo to specific webpack
  versions.** DIWS ships one via `@angular-builders/custom-webpack`;
  the CLI does not expose webpack by default, so the repo now owns
  webpack upgrades. Flag as migration-coupling.
- **`proxy.conf.json` documents the dev-to-backend contract.** Extract
  `target` URLs as backend dependency signals — they cross-reference
  the `.NET` discovery fingerprint.
- **HttpInterceptors wrap every HTTP call invisibly.** Auth header
  injection, error normalization, logging — none of it is visible at
  call sites. Inventory the chain in declared order; a rebuild that
  drops or reorders them regresses silently.
- **RxJS subscription leaks.** Any `.subscribe(` in a component without
  a matching `takeUntil(destroy$)`, `SubSink.add`, `take(1)`, or
  `async` pipe is a leak. Pattern-scan explicitly.
- **View Engine vs. Ivy.** `enableIvy` in `angular.json` or
  `tsconfig.app.json`; v9+ defaults to Ivy, v13 removed View Engine.
  Record the actual state.
- **`HttpModule` removed in v10; RxJS v5 path imports deprecated in
  RxJS 6.** Build breaks on current Angular; rewrites mechanical but
  must land before the next major bump.
- **`polyfills.ts` signals browser targets.** Uncommented `zone.js`,
  `classlist.js`, `web-animations-js` mean IE11 is preserved.
- **Mixed lockfiles and shared-library build order.** Both
  `package-lock.json` and `yarn.lock` = one is stale. DMS:
  `ng build dms-web-shared` must run before `ng build dms_web_faa`;
  record the dependency edge.

## Quality Rules
- [ ] Every project under `angular.json:projects` has a
      `workspace_projects` record with `project_type`, `root_path`,
      `sourceRoot`, `build_config`, and `test_config` populated.
- [ ] Every NgModule found by glob has a record with `declarations`,
      `imports`, `providers`, `exports`, `bootstrap`, and
      `is_root`/`is_feature`/`is_lazy_loaded` flags set.
- [ ] Every component record cites its selector and at least one
      `{repo}:{file}:{line}` source line.
- [ ] Every route with `loadChildren` records syntax style
      (`string` vs. `function`); string form fires a finding on
      v8-v10 and a build-break finding on v11+.
- [ ] Every `HTTP_INTERCEPTORS` registration is recorded with
      declared order preserved.
- [ ] Angular major version and CLI version are present in the
      workspace manifest and agree with `package.json` semver.
- [ ] Every deprecated-tool finding cites the source line that
      triggers it, not just "file exists".
- [ ] No environment value in any artifact is a raw secret; values
      are redacted.
- [ ] Every artifact validates against its declared schema with no
      `additionalProperties` violations.

## Common Failure Modes
| Failure Mode | Symptom | Prevention |
|---|---|---|
| Assuming one project per workspace | DMS's `dms_web_designee` and `dms-web-shared` missing; DMS looks like a single app | Iterate every key under `angular.json:projects`; do not stop at `defaultProject` |
| Reading Angular version from `@angular/cli` only | Migration path wrong because CLI and core disagree | Read `@angular/core` for app version; `@angular/cli` for CLI version; record both |
| Interceptor chain recorded unordered | Replacement app reorders interceptors; auth fails intermittently | Record `multi: true` providers in source order; preserve order in the artifact |
| Subscription leaks reported only for lambda form | `.subscribe(callback, error, complete)` three-arg form missed | Pattern-match on `.subscribe(` regardless of shape; check enclosing class for `takeUntil` / `async` / `SubSink` |
| Environment secrets leaked into artifact | Secrets-scan review trips on the discovery artifact itself | Redact matched patterns before writing; emit key and location only |
| Custom webpack override ignored | Build fails post-modernization because a `DefinePlugin` value was dropped | When `@angular-builders/custom-webpack` is the builder, inventory plugins, externals, and resolve aliases |

## Handoff Summary
When this skill completes, verify:
1. `angular-workspace-manifest.json` lists every project under
   `angular.json:projects` with build/test/e2e targets populated.
2. Angular major, CLI, RxJS major, and package manager are recorded
   with citations and agree across workspace manifest and
   dependency inventory.
3. Every deprecated tool present in the repo has a finding with a
   source citation.
4. No environment value in any artifact is a raw secret.

Then proceed to: `catalog-application` (folds archetype `web-app`
and tech stack into the catalog entry); `dependency-mapper`
(consumes npm inventory and proxy-config targets); and, for
Rearchitect or Replatform dispositions, `react-page-generation` in
Modernization Generate. The next gate is **G-DC** (Discovery
Completeness).

## References
- `references/angular-workspace-and-cli-config.md` — `angular.json`
  schema, architect targets, builders, schematics, `tsconfig`
  inheritance, budgets, and environment file replacements.
- `references/rxjs-and-module-architecture.md` — RxJS operator
  inventory, subscription-leak patterns, NgModule taxonomy,
  provider scoping, lazy-loading mechanics, guards and resolvers,
  state management, and HttpClient + interceptor chains.
- `references/angular-legacy-tooling-migration.md` — per-tool
  migration guide for TSLint, Protractor, Yarn v1, View Engine,
  `HttpModule`, `loadChildren` string form, forms, and RxJS path
  imports, with a version compatibility matrix.
- `schemas/discovery/application-catalog-entry.schema.json` —
  archetype enum and tech-stack field shape.

## Changelog
- 0.1.0 (2026-05-06) — Initial skill; Angular counterpart to
  `dotnet-discovery-patterns`. Covers `angular.json` parsing,
  per-project architect targets, NgModule/component/route walks,
  service and HTTP interceptor inventory, RxJS and state-management
  detection, and explicit legacy-tooling findings. Feeds
  `catalog-application`, `dependency-mapper`, and
  `react-page-generation` downstream.
