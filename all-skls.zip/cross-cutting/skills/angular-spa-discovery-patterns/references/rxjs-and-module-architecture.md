# RxJS and Module Architecture

Reference for walking NgModules, component hierarchies, RxJS usage,
HttpClient call sites, interceptor chains, guards, resolvers, and
state-management styles. This is where Angular's runtime behavior
actually lives; the workspace config (the other reference) is just
the shell that loads it.

## NgModule fundamentals

An `@NgModule({...})` decorator declares five arrays:

- `declarations` — components, directives, and pipes owned by the
  module. A given component can belong to exactly one module.
- `imports` — other NgModules whose exports become visible inside
  this module. Root-level modules typically import `BrowserModule`;
  feature modules import `CommonModule`.
- `providers` — services registered with the injector. Scoping
  depends on where the module is imported (see below).
- `exports` — the subset of declarations and imports made visible
  to consumers that import this module.
- `bootstrap` — the root component(s) to instantiate at
  application start. Present only on the root module; typically
  `[AppComponent]`.

**Standalone components** (Angular 14+, stabilized v15) let
components, directives, and pipes declare `standalone: true` and
live without a containing NgModule. Standalone is optional; most
pre-v15 apps and many v15+ apps still use NgModules throughout.
Record which style the app uses; mixed style is common during
migration.

## Feature / shared / core pattern

The conventional NgModule taxonomy:

- **Root module** (`AppModule`) — imports `BrowserModule` and
  `AppRoutingModule`, declares and bootstraps `AppComponent`,
  imports feature modules (eager or lazy).
- **Core module** — app-wide singletons: interceptors,
  `AuthService`, `ConfigService`. Imported exactly once by the
  root module; its providers become application-scoped.
- **Shared module** — reusable presentational components,
  directives, pipes, and third-party modules (`CommonModule`,
  `FormsModule`, Material). Imported by every feature module;
  should declare no services.
- **Feature modules** — one per bounded context (`UsersModule`,
  `OrdersModule`). Often lazy-loaded via routing.

Flag any shared module with a non-empty `providers` array — that
is a common footgun: each feature module that imports it gets its
own instance of the service, breaking singleton expectations.

## Provider scoping

Services can be registered in four places, each with different
semantics:

1. **`@Injectable({ providedIn: 'root' })`** — singleton
   application-wide; tree-shakeable. The default since v6 and
   the modern recommendation.
2. **`@Injectable({ providedIn: SomeModule })`** — singleton within
   the module's injector. Tree-shaken when `SomeModule` is not
   imported.
3. **Module `providers: [...]`** — registered when the module is
   loaded. Eager modules register at app start; lazy modules
   register when their route activates, creating a child injector.
   This is how lazy-loaded modules get their own service instances.
4. **Component `providers: [...]`** — a new instance per component
   instance; destroyed with the component.

The `angular-service-inventory.json` output must record the scope
style, because it determines whether a service is a singleton or
a per-route instance.

## Lazy-loading mechanics

Routes with `loadChildren` defer module load until the route
activates. Two syntaxes:

- **Function syntax** (v8+, required v11+):

      { path: 'orders', loadChildren: () => import('./orders/orders.module').then(m => m.OrdersModule) }

- **String syntax** (deprecated v8, removed v11):

      { path: 'orders', loadChildren: './orders/orders.module#OrdersModule' }

On v11+ the string form fails at build time. On v8-v10 it still
works but emits a deprecation warning. Flag every string-form
occurrence; the rewrite is mechanical but must happen before the
v11 upgrade.

Lazy-loaded modules produce their own webpack chunk and get their
own root injector. Any service they register via
`providedIn: <ThisModule>` or in `providers: [...]` is a
per-chunk singleton, not a global singleton. This is a common
source of "why does my service state reset" bugs during
modernization.

## Route guards and resolvers

Guards block or allow route activation:

- `CanActivate` — blocks entering a route (auth check).
- `CanActivateChild` — same, for child routes.
- `CanDeactivate` — blocks leaving a route (unsaved-changes
  prompt). Generic over the component type.
- `CanLoad` — blocks lazy-loading a module.
- `CanMatch` (v14+) — supersedes `CanLoad`; runs before route
  matching.

Resolvers fetch data before activating a route:

- `Resolve<T>` — old class-based interface.
- Functional resolvers (v15+) — plain functions.

Every guard and resolver is a service registered in an injector.
Record which injector owns each one; a guard registered in a
lazy module is not available outside it.

## Component lifecycle hooks

The hooks to record (in invocation order):

- `ngOnChanges(changes)` — inputs bound values changed.
- `ngOnInit()` — after first `ngOnChanges`; canonical place for
  HTTP calls and subscription setup.
- `ngDoCheck()` — custom change-detection; rare.
- `ngAfterContentInit()` — projected content initialized.
- `ngAfterContentChecked()` — projected content checked.
- `ngAfterViewInit()` — view and child views initialized.
- `ngAfterViewChecked()` — view and child views checked.
- `ngOnDestroy()` — component about to be destroyed; canonical
  place for subscription cleanup.

Record which hooks each component uses. Absence of `ngOnDestroy`
on a component that has `.subscribe(` calls is a leak smell.

## Change detection strategy

`@Component({ changeDetection: ChangeDetectionStrategy.OnPush })`
tells Angular to re-render the component only when inputs change
by reference, an `Observable` bound via `async` pipe emits, or a
manually triggered `markForCheck()`. `Default` re-renders on
every tick — simpler but expensive.

Count the ratio of `OnPush` to `Default` components. A repo that
is 100% `Default` is easier to move to signals later but carries
hidden performance debt.

## RxJS basics

RxJS 6+ (required on Angular 8+) uses pipeable operators:

    source$.pipe(
      map(x => x * 2),
      filter(x => x > 10),
      switchMap(x => this.http.get(`/api/${x}`))
    ).subscribe(result => ...);

Record the RxJS major version from `package.json`. Angular 8
shipped RxJS 6; Angular 9-13 support RxJS 6 and 7; Angular 14+
requires RxJS 7. RxJS 8 is the current major.

## RxJS v5 path imports (deprecated)

Legacy code may still carry:

    import 'rxjs/add/operator/map';
    source.map(x => x * 2).subscribe(...);

These patch operators onto `Observable.prototype` globally and
have been deprecated since RxJS 6 (2018). The rewrite:

    import { map } from 'rxjs/operators';
    source.pipe(map(x => x * 2)).subscribe(...);

Flag every `rxjs/add/` import. Preserving this pattern blocks the
RxJS major-version bump.

## Common operators to inventory

- `map`, `filter`, `take`, `tap`, `catchError`, `finalize` —
  straightforward transformations.
- `switchMap`, `concatMap`, `mergeMap`, `exhaustMap` — higher-order
  mapping; semantic differences are load-bearing. Getting them
  wrong is a common bug class.
- `combineLatest`, `forkJoin`, `zip` — combiners. Behavior
  diverges on completion and error.
- `shareReplay({ bufferSize: 1, refCount: true })` — canonical
  HTTP-response caching pattern. The `refCount` argument defaults
  changed in RxJS 6.4; flag `shareReplay(1)` without the options
  object on v6.4+.
- `takeUntil(destroy$)` — the standard leak-prevention pattern;
  paired with a `Subject` that emits in `ngOnDestroy`.
- `debounceTime`, `distinctUntilChanged` — search-box patterns.

## Subscription leaks

Every `.subscribe(` that is not paired with unsubscription is a
leak. Acceptable patterns:

1. `takeUntil(this.destroy$)` in the pipe, with `destroy$` a
   `Subject` that emits in `ngOnDestroy`.
2. `async` pipe in the template (`{{ data$ | async }}`) — the
   pipe subscribes and unsubscribes automatically.
3. `SubSink` or `Subscription` aggregation, with `unsubscribe()`
   in `ngOnDestroy`.
4. `take(1)` or `first()` in the pipe — the observable completes
   after one emission, making unsubscription moot for cold
   observables.
5. Manual `Subscription` captured and `.unsubscribe()`d in
   `ngOnDestroy`.

Anything else is a candidate leak. The scan rule: find every
`.subscribe(` in component classes (`.component.ts`), walk up to
the enclosing class, and check for one of the five patterns
above. A class with `.subscribe(` and no pattern match is a leak
candidate; emit a finding.

## HttpClient and interceptors

`HttpClient` from `@angular/common/http` is the modern API. The
legacy `Http` from `@angular/http` was deprecated in v5 and
removed in v10. Any v8 app importing `@angular/http` is living on
borrowed time; any v10+ app importing it does not build. Flag
every import.

Interceptors are registered as multi-providers:

    { provide: HTTP_INTERCEPTORS, useClass: AuthInterceptor, multi: true }
    { provide: HTTP_INTERCEPTORS, useClass: ErrorInterceptor, multi: true }
    { provide: HTTP_INTERCEPTORS, useClass: LoggingInterceptor, multi: true }

Interceptors run in registration order on outgoing requests and
in reverse order on incoming responses. The order is behavior:
an auth interceptor must run before a logging interceptor that
captures headers, or the logs miss the auth header.

Record the ordered list verbatim. Any rebuild that reorders them
changes behavior invisibly.

Typical interceptor responsibilities:

- **Auth** — injects `Authorization: Bearer <token>` from a token
  service.
- **Error normalization** — remaps `HttpErrorResponse` into the
  app's error-object shape.
- **Logging / telemetry** — records request/response pairs.
- **Retry** — retries 5xx with exponential backoff.
- **Loading indicator** — tracks in-flight requests and toggles
  a global spinner.

## State management

Angular has no built-in store. Four common shapes:

1. **NgRx** (`@ngrx/store`, `@ngrx/effects`) — Redux-style
   store with reducers, actions, selectors, and effects.
   Heavyweight; common on large apps.
2. **Akita** (`@datorama/akita`) — entity-store library;
   smaller than NgRx, OOP flavor.
3. **NgXs** (`@ngxs/store`) — decorator-based store; sits
   between NgRx and Akita on the complexity curve.
4. **Service-with-BehaviorSubject** — hand-rolled. An
   `@Injectable({ providedIn: 'root' })` service holds a
   `BehaviorSubject<State>` and exposes it as an observable.
   Consumers subscribe via `async` pipe. No library, no
   boilerplate, limited tooling.

Detect by `package.json` imports first, then fall back to source
scan for `new BehaviorSubject` inside `@Injectable`. A repo with
none of the libraries and no `BehaviorSubject` pattern is either
doing passive-per-component state (and will hit scaling issues)
or has no client-side state to speak of.

## Forms

Two form styles, both supported and both in use in real apps:

- **Template-driven** — `FormsModule`, `[(ngModel)]` two-way
  binding in the template, validation via HTML attributes. Simple
  forms only.
- **Reactive** — `ReactiveFormsModule`, `FormGroup`/`FormControl`
  constructed in the component class, validation via validator
  functions. Richer; the recommended approach for non-trivial
  forms.

Flag apps that import only `FormsModule` and never
`ReactiveFormsModule` — template-driven-only is a migration
flag, especially for apps planning to move to React Hook Form or
equivalent.

## What to record

For each NgModule, each component, each route, each service, and
each interceptor: file path, class name, decorator metadata,
scope, and at least one `{repo}:{file}:{line}` citation. The
output artifacts together form a fully auditable reconstruction
of the app's runtime behavior from source.
