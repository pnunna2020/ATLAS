# Angular Legacy Tooling Migration

Per-tool migration guide for the deprecated technologies that turn up
in real Angular repos (DIWS on v10 and DMS on v8 are both worked
examples). This reference tells Discovery what to flag, and it tells
Rationalization what the migration actually costs. It does not
execute migrations — that's Modernization's job — but it scopes them.

Every tool in this document is something `ng update` will NOT fix
automatically. Leaving any of them in place blocks future Angular
major upgrades.

## The Angular major-version step chain

`ng update @angular/core @angular/cli` only moves one major version
at a time. Paths to current (v17 assumed; adjust for later majors):

- **v8 to v17** — 9 steps: 8 to 9 to 10 to 11 to 12 to 13 to 14 to
  15 to 16 to 17. Each step can break, and v9 (Ivy), v12 (TSLint
  dropped), v14 (standalone components), v15 (Material MDC), v16
  (signals, required inputs), and v17 (new control-flow syntax)
  each introduce compilation or runtime surprises.
- **v10 to v17** — 7 steps.
- **v11 to v17** — 6 steps.
- **v12 to v17** — 5 steps.

Record the starting version; the step count is deterministic from
it. Skipping steps is unsupported.

## Per-major upgrade compatibility matrix

| Upgrade step | Node required | TypeScript required | RxJS required | Key break |
|---|---|---|---|---|
| 8 to 9 | 10.13+ | 3.6 / 3.7 | 6.5 | Ivy becomes default; View Engine opt-out via `enableIvy: false` |
| 9 to 10 | 10.13+ | 3.9 | 6.5 | `@angular/http` removed; TSLint still bundled |
| 10 to 11 | 10.13+ | 4.0 | 6.6 | `loadChildren` string syntax removed |
| 11 to 12 | 12.14+ | 4.2 | 6.6 / 7.0 | IE11 support deprecated; TSLint and Protractor dropped from CLI |
| 12 to 13 | 12.20+ | 4.4 | 6.6 / 7.4 | IE11 support removed; View Engine removed (Ivy only) |
| 13 to 14 | 14.15+ | 4.6 | 6.6 / 7.4 | Standalone components (optional); typed forms (opt-in) |
| 14 to 15 | 14.20+ / 16 | 4.8 | 7.5 | Material MDC migration; standalone APIs stabilize |
| 15 to 16 | 16 / 18 | 4.9 / 5.0 | 7.5 / 7.8 | Required inputs; signals (dev preview); esbuild-based builder |
| 16 to 17 | 18.13+ / 20 | 5.2 | 7.8 | New control-flow (`@if`, `@for`); `application` builder default; SSR overhaul |

Record the current Angular, TypeScript, RxJS, and Node versions;
the matrix tells Rationalization which step will break first.

## TSLint to ESLint

**Status.** TSLint was deprecated by Palantir in 2019. Angular
bundled TSLint through v11. Angular CLI v12 (2021) dropped
TSLint from `ng new` defaults and stopped generating `tslint.json`.
Existing repos on v8-v11 were never force-migrated; they carry
`tslint.json` indefinitely unless someone runs the conversion.

**Discovery signal.** `tslint.json` present at workspace root or
in any project's `root`. Often paired with suppressions
(`// tslint:disable-next-line`) scattered through source.

**Migration path.** The `@angular-eslint/schematics` package
(Angular Labs) converts `tslint.json` to `.eslintrc.json` and
replaces the lint builder:

    ng add @angular-eslint/schematics
    ng g @angular-eslint/schematics:convert-tslint-to-eslint

**Trade-offs and gotchas.**

- **Rule sets differ.** The TSLint default rule set and the
  `@angular-eslint/recommended` rule set are not equivalent. The
  conversion schematic best-efforts the mapping, but rules like
  `no-use-before-declare` or `member-ordering` have ESLint
  counterparts with subtly different triggers.
- **Suppressions must be rewritten.** `// tslint:disable-next-line`
  becomes `// eslint-disable-next-line <rule>`, and the rule name
  must match an actual ESLint rule — the TSLint rule name is not
  usable.
- **CI scripts reference the old target.** Any `ng lint` in CI is
  fine (the architect target gets rewritten by the schematic), but
  shell-invoked `tslint ...` commands must be changed to
  `eslint ...`.

**Migration cost.** Small-to-medium, assuming the suppression
density is low. A repo with hundreds of `tslint:disable` comments
is carrying real lint debt, and the conversion will surface a
wave of new lint failures as ESLint applies its stricter baseline.

## Protractor to Cypress or Playwright

**Status.** Protractor was deprecated by the Angular team in 2023.
Angular CLI v12 (2021) dropped Protractor from `ng new` defaults.
Repos on v8-v11 typically still have `protractor.conf.js`, and
some (DIWS) have a second `protractor.headless.conf.js` for CI.

**Discovery signal.** `protractor.conf.js` at workspace root;
variant configs like `protractor.headless.conf.js`; an
`architect.e2e` target whose builder is
`@angular-devkit/build-angular:protractor`.

**Migration path.** Two credible replacements, each with
trade-offs:

### Cypress

- `ng add @cypress/schematic` adds the `architect.e2e` target
  and scaffolds `cypress/` folder.
- Rewrites are not mechanical: Protractor's implicit
  promise-chaining model and `element(by.css(...))` API have no
  direct Cypress equivalent. Tests are typically rewritten from
  scratch.
- Cypress does not support multi-tab flows or cross-origin
  iframes without workarounds. Protractor tests that relied on
  popup windows will not port cleanly.
- Cypress uses its own browser launcher; no Selenium / WebDriver
  required.

### Playwright

- `npm init playwright@latest` adds the config and scaffolds
  `tests/` folder.
- Supports multi-tab and cross-origin naturally.
- Closer in model to Protractor (explicit `await` on every
  action) than Cypress.
- No schematic integration with Angular CLI; the `architect.e2e`
  target must be replaced manually or dropped in favor of a
  direct `npx playwright test` in CI.

**Gotchas.**

- **Two configs mean two test environments.** DIWS's
  `protractor.conf.js` (headful, local) and
  `protractor.headless.conf.js` (headless, CI) diverge on
  browser capabilities and baseUrl. Both must port.
- **Page-object-pattern tests port poorly.** Protractor page
  objects lean on WebDriver's synchronous-looking promise model;
  Cypress's chained API and Playwright's `Locator` class both
  require a rewrite, not a refactor.
- **CI changes.** Protractor uses Selenium / WebDriver, which
  must be installed or started in CI. Cypress and Playwright
  bundle their own browsers. The CI pipeline must be edited.

**Migration cost.** High. Plan on rewriting the e2e suite, not
porting it. Record the Protractor test count in the discovery
artifact as an effort-sizing input.

## Yarn v1 to Yarn Berry or npm

**Status.** Yarn v1 (classic) reached end-of-development in 2021.
Yarn v3 and v4 (Berry) are the current majors. Npm 7+ with
workspaces is a credible alternative. DMS pins Node to
`c:\tools\nodejs` and ships a v1 `yarn.lock`.

**Discovery signal.** `yarn.lock` with header
`# yarn lockfile v1` and no `.yarnrc.yml` file in the repo. An
explicit Yarn version pin in the repo (in a `.tool-versions`,
`package.json:engines.yarn`, or `.nvmrc` style) may also be
present. A `yarnPath` entry in `.yarnrc.yml` means Berry.

**Migration paths.** Three options:

### To Yarn Berry with node-modules linker

    yarn set version berry
    echo "nodeLinker: node-modules" > .yarnrc.yml
    yarn install

Keeps `node_modules/` intact, so Angular CLI, webpack, and the
typical build chain work unchanged. The lockfile format changes
(`yarn.lock` v6 vs. v1); CI caches invalidate. Lowest-risk Berry
path.

### To Yarn Berry with PnP

Switches to Plug'n'Play, no `node_modules/`. Dramatically faster
installs, smaller disk footprint, but many tools (Jest
pre-v29, some Angular CLI builders, third-party schematics) do
not support PnP out of the box. Not recommended for Angular apps
without a dedicated migration window.

### To npm

    rm yarn.lock
    npm install

Produces `package-lock.json`. Pragmatic when the team has no
strong preference for Yarn. Caveat: npm `install` vs. `ci` vs.
`install --frozen-lockfile` have subtly different semantics from
Yarn's; CI scripts must be checked.

**Gotchas.**

- **`yarn.lock` and `package-lock.json` both present = broken
  state.** One of them is stale. Flag as a repo-hygiene finding.
- **`resolutions` field in `package.json`** (Yarn-only) has no
  npm equivalent pre-npm-8.3. Document any `resolutions` before
  the migration.
- **Dev script conventions.** Yarn's `yarn <script>` and npm's
  `npm run <script>` differ on argument passing
  (`yarn test --coverage` vs. `npm test -- --coverage`). Any
  CI command that passes flags through yarn must be rewritten.
- **DMS's `c:\tools\nodejs` pin is a Windows-specific
  developer-environment convention.** Record it; modernization
  toward a containerized or Linux-CI build chain will need to
  replace it.

**Migration cost.** Low-to-medium. Primary risk is CI downtime
during the cutover.

## View Engine to Ivy

**Status.** Ivy became the default compiler and runtime in Angular
v9 (2020). View Engine remained opt-out through v12; v13 (2021)
removed View Engine entirely.

**Discovery signal.** `angular.json` with `enableIvy: false` on
v9-v12; `tsconfig.app.json` with
`"angularCompilerOptions": { "enableIvy": false }`. On v8 and
earlier, Ivy is not available; View Engine is the only option.

**Migration path.** Remove the `enableIvy: false` flag and run
`ng build --prod`. The CLI emits Ivy output automatically.

**Gotchas.**

- **Library consumers.** A v9-v12 app on Ivy can consume
  View-Engine-compiled libraries via the `ngcc` post-install
  step. Once the app moves to v13+, View-Engine-only libraries
  stop working; all transitive deps must publish Ivy-compatible
  builds (Angular Package Format v13+).
- **Template type-checking strictness.** Ivy's
  `strictTemplates` flag catches template type errors that View
  Engine silently accepted. Flipping it on a large codebase
  produces hundreds of new compile errors; migrate incrementally.

**Migration cost.** Low on v9-v12; the move is transparent for
most apps. The upgrade to v13 is where View Engine holdouts
finally break.

## `HttpModule` to `HttpClient`

**Status.** `HttpModule` from `@angular/http` was deprecated in
Angular v5 (2017). It was removed in v10 (2020). v8 and v9 apps
can still import it; v10+ apps cannot.

**Discovery signal.** `import { HttpModule, Http } from '@angular/http'`
or `import { Http, Response } from '@angular/http'` anywhere in
source. Corresponding service calls use `Http.get()` and return
an `Observable<Response>` that requires `.json()` parsing.

**Migration path.** Mechanical but not automatable by
`ng update`:

1. Add `HttpClientModule` to `AppModule` imports.
2. Replace `import { Http, ... } from '@angular/http'` with
   `import { HttpClient } from '@angular/common/http'`.
3. Replace `constructor(private http: Http)` with
   `constructor(private http: HttpClient)`.
4. Drop `.map(r => r.json())` from every pipe — `HttpClient`
   parses JSON by default.
5. Update error handling: `HttpClient` surfaces
   `HttpErrorResponse` objects with a different shape.
6. Remove `@angular/http` from `package.json` dependencies.

**Gotchas.**

- **Response typing.** `Http.get()` returned `Observable<Response>`;
  `HttpClient.get<T>()` returns `Observable<T>` with `T`
  defaulting to `Object`. Many existing call sites have implicit
  `any` that must become explicit types for strict mode.
- **Headers and params.** The `Headers` and `URLSearchParams`
  classes (`@angular/http`) are replaced by `HttpHeaders` and
  `HttpParams` (`@angular/common/http`). Immutable; use `.set()`
  and `.append()`.
- **Interceptors.** `HttpModule` had no interceptor API. Migrating
  to `HttpClient` is the prerequisite for the interceptor chain;
  apps often add interceptors at the same time.

**Migration cost.** Medium. Each call site changes; strict
typing surfaces latent bugs.

## `loadChildren` string to function

**Status.** Deprecated in Angular v8 (2019); removed in v11 (2020).

**Discovery signal.**

    { path: 'orders', loadChildren: './orders/orders.module#OrdersModule' }

The `'<path>#<ClassName>'` string form.

**Migration path.** Mechanical:

    { path: 'orders', loadChildren: () => import('./orders/orders.module').then(m => m.OrdersModule) }

Every occurrence converts by pattern. The `ng update @angular/core`
schematic from v7 to v8 offered automatic migration; repos that
skipped the migration step or were authored before it carry the
string form indefinitely on v8-v10.

**Gotchas.** None beyond the mechanical rewrite, but this MUST
ship before the v11 upgrade — v11 fails to compile on the string
form.

**Migration cost.** Low. Fully mechanical.

## Template-driven to reactive forms

**Status.** Both styles are supported and not deprecated. The
flag is only a direction-of-travel signal for modernization
targets that prefer reactive-form equivalents (React Hook Form,
Formik, Tanstack Form).

**Discovery signal.** `imports: [FormsModule]` with no
`ReactiveFormsModule`; `[(ngModel)]` bindings in templates.

**Migration path.** Per-form rewrite. Template-driven:

    <form #f="ngForm" (ngSubmit)="onSubmit(f.value)">
      <input name="email" [(ngModel)]="model.email" required>
    </form>

Reactive equivalent:

    this.form = this.fb.group({
      email: ['', [Validators.required, Validators.email]]
    });

    <form [formGroup]="form" (ngSubmit)="onSubmit(form.value)">
      <input formControlName="email">
    </form>

**Gotchas.**

- **Custom validators** port by shape (`ValidatorFn`) but the
  template-driven directives that wrap them need rewriting.
- **Typed forms (v14+)** give `FormGroup<{ email: FormControl<string | null> }>`;
  the typing is load-bearing and flaky on early v14 releases.

**Migration cost.** Medium-to-high, per form. Usually paired with
the React or alternative-framework rewrite rather than done in
place.

## Deprecated RxJS operators and path imports

**Status.** RxJS v5 path imports deprecated since RxJS 6 (2018).
Various operators (e.g., `combineAll`, `flatMap` alias for
`mergeMap`) deprecated across RxJS 7 and 8.

**Discovery signal.**

- `import 'rxjs/add/operator/<name>'` — path-patching style.
- `Observable.create(...)` — deprecated; use `new Observable(...)`.
- `combineAll`, `flatMap`, `mergeAll` with argument,
  `mergeScan` with buffer arg, etc.

**Migration path.** Pipeable rewrite for path imports; operator
renames for deprecated operators. `rxjs-tslint` or the
`rxjs-migrations` schematic automates some of it.

**Migration cost.** Low. Scan-and-replace.

## What the skill records

The `angular-legacy-migration-findings.json` artifact contains one
finding per deprecated-tool occurrence, each with:

- `tool` — the identifier (`tslint`, `protractor`, `yarn-v1`,
  `view-engine`, `http-module`, `load-children-string`,
  `rxjs-path-imports`, `template-driven-forms`).
- `severity` — `critical` when the tool blocks the next Angular
  major; `high` when it's removed from current Angular;
  `medium` when it's deprecated but still functional;
  `low` when it's a code-hygiene signal.
- `evidence` — `{repo}:{file}:{line}` for the triggering
  occurrence.
- `recommended_action` — one of the migration paths in this
  reference.
- `blocks_upgrade_to` — the Angular major that this tool blocks
  (e.g., `loadChildren` string form blocks v11).

Rationalization reads these findings and scores the
migration-debt dimension; Modernization consumes them as the
to-do list for the Refactor or Rearchitect disposition.
