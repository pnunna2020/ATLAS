# NIST SP 800-53 Rev 5 — High Baseline Automation on AWS GovCloud

Scope: the controls most commonly in scope for FedRAMP Moderate and High
deployments in AWS GovCloud (US), organized by family, with the concrete
automation service and the evidence pattern the
`nist-control-automation-mapper` skill emits into
`nist-control-automation-matrix.json`. Not every control enhancement is
covered — the skill walks this reference in order and overlays architecture-
specific choices on top.

Families follow Rev 5 two-letter codes: AC, AU, AT, CA, CM, CP, IA, IR, MA,
MP, PE, PL, PS, RA, SA, SC, SI, SR, PT.

## AC — Access Control

| Control | Automation | Cadence | Notes |
|---|---|---|---|
| AC-2 Account Management | IAM Identity Center + Cognito; Config rule `iam-user-unused-credentials-check`; custom collector for account-state transitions | continuous | Staff accounts via Identity Center + PIV federation; public accounts via Cognito; mark inactive > 35 days |
| AC-2(1) Automated System Account Management | Identity Center SCIM provisioning from agency IdP | continuous | SCIM 2.0 endpoint mandatory; drift detection via Config |
| AC-3 Access Enforcement | IAM policies + SCPs + resource policies; Access Analyzer | continuous | Access Analyzer scopes external access findings |
| AC-4 Information Flow Enforcement | VPC Flow Logs + NACLs + Config rules for SG changes (`incoming-ssh-disabled`, `restricted-common-ports`); egress inspection via Network Firewall | continuous | Per-VPC inspection decisions from landing-zone designer |
| AC-6 Least Privilege | Access Analyzer unused access findings; IAM Access Advisor; custom collector | periodic (weekly) | Flag any role unused > 90 days for decommission |
| AC-6(9) Log Use of Privileged Functions | CloudTrail management events + CloudWatch metric filters | continuous | Alert on sensitive API calls (IAM, KMS, Config changes) |
| AC-7 Unsuccessful Logon Attempts | Cognito advanced security + CloudTrail ConsoleLogin failures; custom rule for thresholds | continuous | Lockout policy enforced per profile |
| AC-11 Session Lock | Application layer (SessionTimeout in app config); evidence via app config snapshot | periodic (monthly) | AWS has no service; document app-layer enforcement |
| AC-17 Remote Access | Systems Manager Session Manager (no bastion); VPN via Client VPN with MFA | continuous | SCP denies SSH key creation for dev accounts |
| AC-19 Access Control for Mobile Devices | Inherited from FAA agency MDM program | n/a | Document inheritance; no GovCloud surface |

## AU — Audit and Accountability

| Control | Automation | Cadence | Notes |
|---|---|---|---|
| AU-2 Event Logging | CloudTrail org trail (management + data events); app-layer structured logs to CloudWatch | continuous | Trail lives in log-archive account |
| AU-3 Content of Audit Records | CloudTrail default fields + custom fields; structured JSON logs | continuous | Audit that app logs include principal, action, resource, outcome |
| AU-4 Audit Log Storage Capacity | CloudWatch Logs retention + S3 lifecycle to Glacier Deep Archive | continuous | 3-year hot, 7-year cold minimum for FedRAMP |
| AU-6 Audit Record Review | Security Hub + Security Lake → SIEM (Splunk / Chronicle); custom collector for review attestation | continuous + periodic | SIEM integration required for High; weekly review cadence |
| AU-9 Protection of Audit Information | S3 Object Lock on log-archive bucket + KMS CMK + vault lock; bucket policy denies delete | continuous | Root account cannot delete; emit CMK key arn |
| AU-11 Audit Record Retention | S3 lifecycle policy to Glacier with 7+ year retention | continuous | FedRAMP High = 7 years; FISMA overlay may extend |
| AU-12 Audit Record Generation | CloudTrail org trail + app logs; Config rule `cloudtrail-enabled` + `cloudtrail-s3-dataevents-enabled` | continuous | Data events for S3 buckets holding PII |

## AT — Awareness and Training

Most AT controls are programmatic, not technical. Evidence is attestation-
based (LMS completion records from the agency training system).

| Control | Automation | Cadence |
|---|---|---|
| AT-2 Literacy Training and Awareness | Inherited from FAA training program | annually |
| AT-3 Role-Based Training | Inherited; cloud-admin role-based content locally tracked | annually |
| AT-4 Training Records | Inherited LMS evidence collector | annually |

## CA — Assessment, Authorization, and Monitoring

| Control | Automation | Cadence | Notes |
|---|---|---|---|
| CA-2 Control Assessments | Audit Manager FedRAMP framework assessment runs | periodic (quarterly) + on-demand | Pre-built frameworks for FedRAMP Mod and High |
| CA-3 Information Exchange | Interconnection Security Agreements (ISAs) catalog; Direct Connect + Transit Gateway attachments documented | periodic (annually) | Evidence from landing-zone artifacts |
| CA-5 Plan of Action and Milestones | POA&M managed in Audit Manager or GRC tool; custom OSCAL exporter | continuous | OSCAL POA&M per FedRAMP 2024 guidance |
| CA-7 Continuous Monitoring | Security Hub + Config + GuardDuty + Inspector; cATO dashboard | continuous | The whole cATO thread — this is the flagship control |
| CA-8 Penetration Testing | Annual third-party pentest; AWS pre-approved pentest scope | annually | Out of automation scope; evidence is the report |

## CM — Configuration Management

| Control | Automation | Cadence | Notes |
|---|---|---|---|
| CM-2 Baseline Configuration | AWS Config + SSM State Manager; IaC baseline in Terraform state | continuous | Config conformance pack per app |
| CM-3 Configuration Change Control | Change Manager (SSM) + CAB workflow; CloudTrail evidence of change approvals | continuous | Emergency changes flagged for after-action review |
| CM-6 Configuration Settings | Config conformance pack + IaC drift detection custom collector | continuous | Deployed state vs Terraform state diff |
| CM-7 Least Functionality | Inspector network reachability + SCP denies on unused services | continuous | Identify and document any open ports / services |
| CM-8 System Component Inventory | AWS Systems Manager Inventory + Config advanced query | continuous | EC2, RDS, containers inventoried; Inspector for SBOM |
| CM-10 Software Usage Restrictions | SSM Patch Manager + license-approved AMI inventory | periodic | Marketplace AMI restrictions via SCP |

## CP — Contingency Planning

| Control | Automation | Cadence | Notes |
|---|---|---|---|
| CP-2 Contingency Plan | Document stored and version-controlled; evidence collector for last-review date | annually | Review cadence evidence from Git commit metadata |
| CP-4 Contingency Plan Testing | Chaos engineering + DR exercise evidence | annually | Route 53 ARC + recovery time measurement |
| CP-7 Alternate Processing Site | Multi-region GovCloud (us-gov-west-1 + us-gov-east-1) architecture; CloudEndure / DRS | continuous | Architecture-level; validated via DR exercise |
| CP-9 System Backup | AWS Backup vault lock + Aurora PITR + cross-region copy | periodic (daily) | Backup coverage report via Audit Manager |
| CP-9(3) Cryptographic Protection | KMS encryption on AWS Backup vault + S3 backup buckets | continuous | Enforce via Backup policy |
| CP-10 System Recovery and Reconstitution | Tested recovery runbooks + DRS recovery time metrics | annually | RTO/RPO evidence from DR exercise |

## IA — Identification and Authentication

| Control | Automation | Cadence | Notes |
|---|---|---|---|
| IA-2 Identification and Authentication (Organizational Users) | IAM Identity Center + PIV federation; MFA mandatory via Identity Center | continuous | PIV via SAML/OIDC from agency IdP |
| IA-2(1) Multi-Factor Authentication (Privileged Accounts) | Identity Center MFA enforcement + hardware token (YubiKey / PIV) | continuous | Config rule `iam-user-mfa-enabled` for break-glass |
| IA-2(2) Multi-Factor Authentication (Non-Privileged) | MFA via Identity Center for all staff; Cognito MFA for public | continuous | Cognito TOTP or WebAuthn |
| IA-3 Device Identification and Authentication | IAM Roles Anywhere for non-EC2; IAM roles for service accounts (IRSA) | continuous | Short-lived credentials only |
| IA-5 Authenticator Management | Identity Center password policy; Cognito password policy; KMS rotation | continuous | Rotation cadence per authenticator type |
| IA-8 Identification and Authentication (Non-Organizational Users) | Cognito + Login.gov federation; custom evidence collector for federation health | continuous | Login.gov SAML or OIDC; attribute mapping audit |

## IR — Incident Response

| Control | Automation | Cadence | Notes |
|---|---|---|---|
| IR-4 Incident Handling | Security Hub automated response (EventBridge → Lambda / SSM playbooks) | continuous | Playbooks versioned in IaC |
| IR-5 Incident Monitoring | GuardDuty + Security Hub + SIEM correlation | continuous | Finding aggregation in delegated-admin security account |
| IR-6 Incident Reporting | US-CERT reporting workflow; evidence of timely reporting | on-demand | SLA: 1 hour for High; 24 hour Moderate |
| IR-8 Incident Response Plan | Document in Git; annual tabletop exercise evidence | annually | Plan review cadence |

## MA — Maintenance

| Control | Automation | Cadence | Notes |
|---|---|---|---|
| MA-2 Controlled Maintenance | Change Manager approval records; SSM Run Command logs | continuous | Maintenance windows scheduled via SSM |
| MA-4 Nonlocal Maintenance | Session Manager (no SSH/RDP); session logs to S3 | continuous | SCP denies EC2 key pair creation |
| MA-5 Maintenance Personnel | Identity Center group membership + PAM integration | continuous | Privileged-access JIT via Identity Center |

## MP — Media Protection

Predominantly inherited from data-center provider (AWS physical). Logical
media protection via KMS + S3 encryption.

| Control | Automation | Cadence |
|---|---|---|
| MP-2 Media Access | Inherited (AWS physical) + KMS key policies | continuous |
| MP-6 Media Sanitization | Inherited (AWS physical) for disk; cryptographic erasure via KMS CMK deletion | on-demand |
| MP-7 Media Use | SCP denies EC2 USB + snapshot sharing outside org | continuous |

## PE — Physical and Environmental Protection

Fully inherited from AWS for GovCloud data centers. Evidence is AWS SOC 2 +
FedRAMP P-ATO package. No app-layer automation.

## PL — Planning

| Control | Automation | Cadence |
|---|---|---|
| PL-2 System Security and Privacy Plans | OSCAL SSP generated from Audit Manager + custom pipeline | per-release + annually |
| PL-4 Rules of Behavior | Attestation collector from LMS | annually |
| PL-8 Security and Privacy Architectures | Architecture diagrams in Git; custom collector for last-review | per-release |

## PS — Personnel Security

Predominantly inherited from FAA HR. Clearance status is an HR attestation.

## RA — Risk Assessment

| Control | Automation | Cadence | Notes |
|---|---|---|---|
| RA-3 Risk Assessment | Security Hub posture + custom risk register collector | periodic (quarterly) | Risk register in GRC tool |
| RA-5 Vulnerability Monitoring | Inspector (EC2, ECR, Lambda); Config rule `ecr-private-image-scanning-enabled` | continuous | Scan-on-push for ECR |
| RA-5(2) Update Vulnerabilities | Inspector daily rule evaluation + SSM Patch Manager patch cadence | continuous | Patch SLA per severity |
| RA-5(11) Public Disclosure Program | Inherited program; evidence is reporting channel attestation | annually | Coordinated disclosure policy |

## SA — System and Services Acquisition

| Control | Automation | Cadence | Notes |
|---|---|---|---|
| SA-4 Acquisition Process | Contract attestation; evidence out of automation scope | on-demand | Acquisition records |
| SA-9 External System Services | ISAs + FedRAMP-authorized third-party inventory | annually | Third-party vendor cATO status check |
| SA-11 Developer Testing and Evaluation | CodeBuild SAST + SCA + container scan; CodePipeline evidence | continuous | Quality gate in pipeline |
| SA-15 Development Process, Standards, and Tools | SDLC documentation; evidence of tool inventory | annually | |
| SA-22 Unsupported System Components | Inspector + dependency scanning; custom collector for EOL components | continuous | Flag any EOL OS / runtime |

## SC — System and Communications Protection

| Control | Automation | Cadence | Notes |
|---|---|---|---|
| SC-7 Boundary Protection | WAF + Network Firewall + Security Groups; Config rules for public-exposure | continuous | Egress inspection VPC enforced |
| SC-8 Transmission Confidentiality and Integrity | TLS 1.2+ enforcement via ALB/CloudFront; Config rule `alb-http-to-https-redirection-check` | continuous | ACM certs FIPS-compliant |
| SC-8(1) Cryptographic Protection | TLS ciphers restricted to FIPS suite; CloudFront security policy TLSv1.2_2021 minimum | continuous | |
| SC-12 Cryptographic Key Establishment and Management | KMS with automatic rotation; CloudHSM for High-tier keys | continuous | CMK rotation annual for KMS |
| SC-13 Cryptographic Protection | KMS (FIPS 140-2/3) default; CloudHSM (FIPS 140-3 Level 3) for Tier-1 High data | continuous + annually | Annual FIPS module validation |
| SC-17 Public Key Infrastructure Certificates | ACM + ACM Private CA; certificate expiry alerts | continuous | |
| SC-23 Session Authenticity | TLS session management; Cognito session tokens with short TTL | continuous | |
| SC-28 Protection of Information at Rest | KMS encryption on every data service; Config rules `s3-bucket-server-side-encryption-enabled`, `rds-storage-encrypted`, `ebs-encrypted-by-default` | continuous | |
| SC-28(1) Cryptographic Protection | CMK with customer-managed keys for High-tier data | continuous | Key policies restrict cross-account |

## SI — System and Information Integrity

| Control | Automation | Cadence | Notes |
|---|---|---|---|
| SI-2 Flaw Remediation | SSM Patch Manager + Inspector findings → remediation runbooks | continuous | Patch SLAs per severity |
| SI-3 Malicious Code Protection | GuardDuty Malware Protection for EC2 + EBS; ECR image scan | continuous | |
| SI-4 System Monitoring | GuardDuty + Security Hub + CloudWatch alarms; aggregated in security-tooling account | continuous | Flagship monitoring control |
| SI-4(2) Automated Tools | Security Hub automated response; EventBridge rules for findings | continuous | |
| SI-5 Security Alerts, Advisories, and Directives | AWS Health Dashboard + CISA advisory ingestion | continuous | |
| SI-7 Software, Firmware, and Information Integrity | Signed container images (Sigstore / Notary); Config rule for image signature verification | continuous | |
| SI-10 Information Input Validation | App-layer (WAF rules + code review); evidence from WAF metrics | continuous | |
| SI-12 Information Management and Retention | S3 lifecycle + Glacier retention + Macie classification | continuous | Data retention per type |

## SR — Supply Chain Risk Management

| Control | Automation | Cadence | Notes |
|---|---|---|---|
| SR-3 Supply Chain Controls and Processes | SBOM generation via Inspector + CycloneDX; signed artifacts | continuous | |
| SR-6 Supplier Assessments and Reviews | Third-party cATO status checks; FedRAMP marketplace verification | annually | |
| SR-11 Component Authenticity | Signed images + GuardDuty findings for unauthorized binaries | continuous | |

## PT — Personally Identifiable Information Processing and Transparency

Mostly manual / policy-driven; Privacy Impact Assessment (PIA) is the primary
evidence.

| Control | Automation | Cadence |
|---|---|---|
| PT-2 Authority to Process PII | PIA document review | annually |
| PT-3 Processing Purposes | PIA + Macie data classification cross-check | annually + continuous for discovery |
| PT-4 Consent | App-layer consent records; evidence from app data | periodic |
| PT-5 Privacy Notice | Public-facing notice version control in Git | annually |

## FIPS and Audit Manager Notes

- KMS in GovCloud uses FIPS 140-2 validated modules (FIPS 140-3 certification
  in progress per AWS public roadmap). For High-baseline apps with Tier-1
  data (airman PII, medical records), prefer CloudHSM clusters which carry
  FIPS 140-3 Level 3 validation.
- Audit Manager ships pre-built frameworks for FedRAMP Moderate and
  FedRAMP High. Select the framework matching the app's tier; layer custom
  FAA controls (DOT TSMO, FISMA cadence) as a second framework rather than
  forking the FedRAMP one.
- OSCAL export from Audit Manager produces component-definition and SSP
  fragments. A custom pipeline is still needed to merge per-app components
  into a portfolio SSP and emit POA&M per FedRAMP 2024 guidance.
- FIPS endpoints (`*.<region>.amazonaws.com` → `*-fips.<region>.amazonaws.com`)
  should be enforced via SCP on High-baseline OUs; the Config rule
  `service-fips-endpoint-enabled` covers the common services.

## Inheritance Quick Reference

| Source | Controls Fully Inherited |
|---|---|
| AWS GovCloud P-ATO | PE-family, MA-3, MP-2, MP-6 (physical) |
| Log-archive account (shared-control-provider) | AU-9 (S3 Object Lock), AU-11 (retention) |
| Audit account (shared-control-provider) | AU-6 aggregation view, SI-4 finding aggregation |
| Security-tooling account (shared-control-provider) | IR-5 monitoring, IR-4 automated response |
| Agency IdP (FAA) | IA-12 identity proofing (for staff), AT-family |
| Agency HR | PS-family |

Every inherited control still requires an app-layer demonstration of
application. Inheritance is about the implementation surface, not the
evidence burden.
