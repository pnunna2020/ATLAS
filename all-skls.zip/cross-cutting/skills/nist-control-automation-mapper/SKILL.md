---
name: nist-control-automation-mapper
description: >
  For each relevant NIST SP 800-53 Rev 5 control (High baseline for RMS, IACRA,
  DMS; Moderate for the MSS suite apps AMCS, MedXPress, CHAPS, CPDSS, DIWS),
  emit the specific AWS GovCloud automation that validates it. Consumes the
  ato-boundary-analyzer output (FedRAMP tier per app + inheritance statements)
  and target-architecture.json (services in scope), and produces two schema-
  validated artifacts — nist-control-automation-matrix.json (per-control
  validation approach, automation service, cadence, evidence pattern, OSCAL
  component id) and control-coverage-summary.json (per-app coverage roll-up
  with the gap list). Every control_id is cited precisely (AC-2, AU-12, SC-13
  form) and every automation claim traces to a Config rule id, Security Hub
  standard control, Audit Manager assessment, or custom evidence collector.
  This is the basis for the continuous-compliance evidence feed feeding cATO.
  Triggers on NIST control mapping, controls-as-code, continuous compliance
  authoring, OSCAL component emission, Audit Manager framework selection, or
  @nist-control-automation-mapper.
agent: sonnet
allowed-tools:
  - Read
  - Write
  - Grep
  - Bash
validation_commands:
  - "python -m olympus.validators.schema_validator nist-control-automation-matrix.json"
  - "python -m olympus.validators.schema_validator control-coverage-summary.json"
supported_stacks:
  - aws-govcloud
  - fedramp-moderate
  - fedramp-high
anti_target_stacks:
  - commercial-aws
  - on-prem-only
  - azure-gov
failure_classes:
  - control-inheritance-over-claim
  - missing-automation-citation
  - baseline-tier-mismatch
  - manual-control-marked-automated
  - config-rule-over-quota
benchmark_tags:
  - architecture-nist-automation
  - catoready-evidence-feed
  - oscal-component-emission
---

# nist-control-automation-mapper

## Purpose
Own the Architecture-phase step that turns the FedRAMP baseline assigned to an
app (from `ato-boundary-analyzer`) into a concrete, app-specific controls-as-
code matrix: per NIST 800-53 Rev 5 control in scope, which AWS GovCloud
service validates it, at what cadence, and what evidence artifact the
continuous-compliance feed should expect. Without this skill the cATO thread
(SOO §6.1.1.1.3 Theme C + Objective 6) devolves to a prose SSP — reviewable
once, not continuously — and the Audit Manager / Security Hub / Config stack
ends up configured ad hoc per team. The matrix is also the only place where
"inherited from AWS GovCloud P-ATO" is tracked honestly: an inherited control
still needs an app-layer demonstration, and that distinction is the difference
between an accepted package and a POA&M that never closes. Outputs feed
`continuous-compliance-orchestrator` (the runtime feed), `oscal-ssp-writer`
(package generation), and the cATO dashboard under Governance.

## Inputs
- `ato-boundary-analyzer.json` — authoritative per-app FedRAMP tier
  (Moderate | High), system-boundary declaration, and the inheritance
  statements naming which AWS GovCloud P-ATO controls the app relies on.
  IACRA, RMS, DMS are High; MSS suite (AMCS, MedXPress, CHAPS, CPDSS, DIWS)
  is Moderate — do not re-derive, read the tier from the boundary artifact.
- `target-architecture.json` — per-app service inventory (compute, data,
  networking, identity). The matrix only emits controls whose implementation
  surface actually exists in the architecture (e.g., no RA-5 container scan
  finding if the app has no ECR image).
- `aws-govcloud-landing-zone.json` (from `aws-govcloud-landing-zone-designer`)
  — the OU structure and shared accounts; the log-archive / audit / security-
  tooling accounts carry shared-control-provider automation that many apps
  inherit (CloudTrail org trail, GuardDuty delegated admin, Security Hub
  aggregator).
- Client-profile compliance config
  (`profiles/faa/compliance.yaml`) — FAA-specific overlays (PIV identity
  requirements, FISMA reporting cadence, DOT TSMO controls layered on NIST).
- Control-family automation catalog —
  `references/nist-800-53-high-baseline-automation.md` (bundled with this
  skill) mapping each control family to the AWS GovCloud service(s) that
  typically validate it plus the FIPS / Audit-Manager framework nuance.
- Optional — prior-wave `nist-control-automation-matrix.json` for the same
  app, so the skill emits a diff rather than a ground-up regeneration when a
  service changes (e.g., swapping KMS default for CloudHSM changes SC-13).

## Outputs
- `nist-control-automation-matrix.json` — the controls-as-code core artifact,
  one row per in-scope control. Each row carries:
  - `control_id` — NIST 800-53 Rev 5 id in the canonical form (`AC-2`,
    `AU-12`, `SC-13`); enhancements use dotted form (`AC-2(1)`, `AU-12(1)`).
  - `control_family` — two-letter family code (AC, AU, AT, CA, CM, CP, IA,
    IR, MA, MP, PE, PL, PS, RA, SA, SC, SI, SR, PT).
  - `control_name` — the full title from SP 800-53 Rev 5.
  - `baseline` — `low | moderate | high`; when the app is High, rows include
    both the Moderate inheritance and the High-only controls.
  - `applicability_per_app[]` — `{app_id, applicable (true | false),
    inherited_from (aws-govcloud-p-ato | shared-control-provider |
    app-specific | n/a), inheritance_justification}`.
  - `validation_approach` — `continuous | periodic | on-demand | manual`.
    Continuous means every pipeline run plus scheduled drift detection;
    periodic is cadence-bound (daily, weekly, monthly, annually); on-demand
    is runtime-triggered (e.g., change-event); manual is human review.
  - `automation_service` — `aws-config | security-hub | audit-manager |
    inspector | guardduty | macie | cloudtrail | iam-access-analyzer |
    custom | none`. Use `none` only when the control is unambiguously manual.
  - `validation_cadence` — ISO-8601 duration or `continuous` or
    `per-pipeline-run`; for annual controls `P1Y`.
  - `evidence_artifact_pattern` — S3 key template or Audit Manager evidence
    collector id (e.g., `s3://faa-cato-evidence/${app}/AC-2/${yyyymmdd}.json`).
  - `oscal_component_id` — stable identifier referenced by
    `oscal-ssp-writer` when it emits the component-definition model.
- `control-coverage-summary.json` — portfolio-level roll-up:
  - `per_app[]` — `{app_id, fedramp_tier, controls_in_scope,
    controls_automated_continuous, controls_automated_periodic,
    controls_on_demand, controls_manual, automation_ratio,
    coverage_gaps[] (control_id, reason, planned_remediation)}`.
  - `portfolio_totals` — same shape, aggregated across the 8 apps.
  - `audit_manager_frameworks_selected[]` — FedRAMP Moderate and/or High
    pre-built frameworks plus any FAA custom framework id.
- A schema-validation report written sibling to each artifact by
  `olympus.validators.schema_validator`.

## Methodology
1. Read `ato-boundary-analyzer.json` for every app in scope. Build the
   per-app baseline map: `RMS, IACRA, DMS -> high`; `AMCS, MedXPress, CHAPS,
   CPDSS, DIWS -> moderate`. Abort the pass if the analyzer has not run —
   do not re-derive the tier from service selection alone.
2. Pull the High baseline (when any app is High) and the Moderate baseline
   from the Rev 5 control catalog. High is a strict superset of Moderate,
   so iterate the High catalog and mark per-row applicability per app. The
   High delta is ~60 controls — size the effort accordingly; this matrix
   is not a weekend artifact.
3. For each control, determine applicability per app. A control is
   `applicable: false` only when the architecture has no surface to apply
   it (e.g., SA-22 Unsupported System Components does not apply if the
   stack is entirely within vendor-supported versions). Applicability is
   not inheritance — inherited controls remain applicable.
4. Classify `inherited_from`. A control is `aws-govcloud-p-ato` inherited
   only when the entire implementation is under AWS's responsibility
   boundary per the GovCloud P-ATO CRM (Customer Responsibility Matrix);
   `shared-control-provider` applies when the log-archive / audit accounts
   or a shared-services account implements the control on behalf of the
   app; `app-specific` is everything else. Crucially, an inherited control
   still needs an app-layer demonstration in `evidence_artifact_pattern` —
   do not blank-fill inherited rows.
5. Select the automation service. Use the family-to-service mapping in
   `references/nist-800-53-high-baseline-automation.md` as the starting
   point, then override per app. Examples the matrix must handle verbatim:
   - AC-2 Account Management → IAM Identity Center (staff) + Cognito
     (public/airman); Config rule `iam-user-unused-credentials-check`;
     `continuous` cadence (Config records changes plus daily evaluation).
   - AU-12 Audit Record Generation → CloudTrail org trail + CloudWatch
     Logs; Config rule `cloudtrail-enabled`; `continuous`.
   - SC-13 Cryptographic Protection → KMS with FIPS endpoints for most
     data; for High-tier data at rest (airman PII in RMS) upgrade to
     CloudHSM (FIPS 140-3 Level 3); Config rule for encryption enforcement
     plus annual manual FIPS validation.
   - CM-2 Baseline Configuration → AWS Config + Systems Manager State
     Manager; Config baseline conformance pack; `continuous`.
   - SI-4 System Monitoring → GuardDuty findings ingested to Security Hub;
     aggregated to the delegated-admin security-tooling account;
     `continuous`.
   - IA-2 Identification and Authentication → Cognito MFA + PIV
     federation via IAM Identity Center; custom evidence collector for
     MFA-enrollment rate; `continuous`.
   - AC-4 Information Flow Enforcement → VPC Flow Logs + network ACLs +
     Config rules for security-group change alerts; `continuous`.
   - CP-9 System Backup → AWS Backup vault lock + Aurora PITR; Audit
     Manager backup-coverage evidence collector; `periodic` (daily).
   - RA-5 Vulnerability Monitoring → Inspector (EC2 + ECR) + ECR image
     scanning; Config rule for scan-on-push; `continuous`.
6. Choose the Audit Manager framework. For Moderate apps select the
   pre-built FedRAMP Moderate framework; for High apps select FedRAMP High.
   Layer a FAA custom framework for the DOT TSMO and FISMA extras. Record
   the framework id in `audit_manager_frameworks_selected[]`. Do not hand-
   configure controls that the framework already covers — inherit, then
   extend only the delta.
7. Count Config rules before emitting. The default per-region Config quota
   is 150 rules; a High-baseline app often exceeds this on a first pass.
   Prioritize by control weight (High-baseline mandatory first, then
   enhancements), move lower-priority rules into conformance packs, and
   request the quota increase when projected usage exceeds 150 in
   GovCloud. Emit the projected count in the coverage summary so the
   landing-zone team can pre-stage the quota increase.
8. Set `validation_approach` and `validation_cadence` by control nature,
   not by service capability. A rule that could be evaluated continuously
   is still `periodic` if the evidence it produces is only reviewed
   periodically — do not inflate the automation ratio by relabeling.
   Manual controls (PT-3 Processing Purposes; PS-3 Personnel Screening;
   most of PE Physical) stay manual; mark them honestly.
9. Compute the coverage roll-up. Per app, count controls in scope,
   continuous-automated, periodic-automated, on-demand, and manual; divide
   automated / total for the `automation_ratio`. List every manual or
   on-demand control in `coverage_gaps[]` with a `planned_remediation`
   (even if the remediation is "accept as manual — human sign-off cadence
   annual"). Portfolio totals aggregate across all 8 apps.
10. Validate both artifacts against their schemas. Self-check:
    `control_id` is valid SP 800-53 Rev 5; every High-only row is absent
    from Moderate apps; every `applicable: true` row has a non-empty
    `evidence_artifact_pattern`; `automation_ratio` sums add up.

## Tech-Stack Dispatch

| Trigger | Key patterns |
|---|---|
| `fedramp_tier: high` | High baseline + enhancements; CloudHSM for SC-13; FedRAMP High Audit Manager framework; quota review for Config rules |
| `fedramp_tier: moderate` | Moderate baseline only; KMS with FIPS endpoints acceptable; FedRAMP Moderate Audit Manager framework |
| `client_profile: faa` | DOT TSMO overlay controls; PIV/Login.gov hybrid identity; FISMA quarterly reporting cadence |
| `services includes CloudHSM` | SC-13 enhancement (1) applies; FIPS 140-3 Level 3 evidence annually |
| `services includes ECR` | RA-5(2) ECR image scan on push; Config rule `ecr-private-image-scanning-enabled` |

Detection is mechanical: the boundary tier and the architecture service list
drive which rows appear in the matrix. Overlap with
`continuous-compliance-orchestrator` is explicit — the orchestrator is the
runtime, this skill is the design-time matrix.

## Gotchas
- **High baseline is not Moderate + a few extras.** The High baseline adds
  roughly 60 controls over Moderate across families — size estimate roughly
  doubles. If the matrix for a High app has fewer rows than the Moderate
  delta, it is wrong.
- **"Inherited from GovCloud P-ATO" is not automatic evidence.** The P-ATO
  covers AWS's implementation of the control on the underlying service; the
  app still has to show the control is applied at the app layer (e.g.,
  CloudTrail is inheritable for availability and integrity, but the app
  must demonstrate its own trail is enabled and retained). Do not blank-fill
  inherited rows.
- **SC-13 Cryptographic Protection is FIPS-sensitive.** Default KMS is FIPS
  140-2 validated (pending FIPS 140-3); CloudHSM clusters are FIPS 140-3
  Level 3. For High-tier airman PII / medical data, select CloudHSM or
  document the accepted risk; do not claim Level 3 on plain KMS.
- **AC-4 information-flow enforcement requires per-VPC decisions.** Egress
  inspection, default-deny security groups, and VPC endpoint coverage are
  all AC-4 surfaces — list them individually in the evidence pattern, not as
  a single blob. `aws-govcloud-landing-zone-designer` provides the topology
  these rules reference.
- **AU-6 Audit Record Review often requires SIEM integration.** Security Hub
  plus Security Lake plus a third-party SIEM (Splunk, Chronicle) is the
  common FAA pattern; a Config rule alone does not satisfy AU-6 review
  cadence. Note the SIEM in `automation_service` as `custom` with a cite.
- **CM-6 Configuration Settings needs IaC baseline, not just deployed state.**
  Config measures what is deployed; CM-6 requires the authoritative baseline
  (Terraform state, CloudFormation template) to match. Emit a custom
  collector that diffs deployed state against the IaC repo.
- **Config rule quota is 150 per region per account by default.** A
  High-baseline application will exceed this without prioritization. Emit
  the projected rule count and escalate the quota increase before
  deployment — do not discover the limit in prod.
- **Audit Manager FedRAMP frameworks exist — use them.** Pre-built
  assessments for FedRAMP Moderate and FedRAMP High cover the common control
  set. Starting from scratch duplicates work and drifts from the canonical
  control mapping AWS maintains.
- **OSCAL generation is not free.** Audit Manager exports and custom
  pipelines both produce OSCAL, but component ids must be stable across
  waves for cATO continuity. Fix `oscal_component_id` in the matrix and
  never regenerate ids.
- **Some controls are unavoidably manual.** PT-3 Processing Purposes needs
  a Privacy Impact Assessment; PS-3 Personnel Screening is HR; most of PE
  Physical is the data-center provider's SOC 2. Marking these `automated`
  is the `manual-control-marked-automated` failure class.
- **Control-automation-matrix is versioned per modernization wave.** The
  matrix is not a one-time artifact. Version it alongside the architecture,
  diff wave-over-wave, and preserve OSCAL component ids for continuity.

## Quality Rules
- [ ] Every `control_id` matches the NIST 800-53 Rev 5 canonical format
      (`[A-Z]{2}-\d+(\(\d+\))?`); no free-form ids.
- [ ] Every row in the matrix has a non-null `validation_approach`,
      `automation_service`, and `evidence_artifact_pattern`; `none` is only
      acceptable when `validation_approach` is `manual`.
- [ ] For every High-baseline app, the matrix contains the High-only
      delta in addition to the Moderate rows; per-app row count sanity
      checks against the known High control count.
- [ ] `inherited_from` values draw from the enum
      `aws-govcloud-p-ato | shared-control-provider | app-specific | n/a`;
      every inherited row carries an `inheritance_justification`.
- [ ] Projected Config-rule count per region is emitted in
      `control-coverage-summary.json.portfolio_totals`; any app projected
      over 150 is flagged.
- [ ] `oscal_component_id` values are unique across the matrix and stable
      when compared to any prior-wave matrix for the same app.
- [ ] Manual controls (PT-3, PS-3, PE-2..PE-20 except PE-3(3)) are marked
      `validation_approach: manual`; none carry `automation_service` other
      than `none` or `custom`.
- [ ] `control-coverage-summary.json.per_app[].automation_ratio` equals
      `(continuous + periodic) / controls_in_scope`; rounding to three
      decimal places.
- [ ] Both artifacts validate against their schemas; the validator report
      files show `status: pass`.

## Common Failure Modes
| Failure Mode | Symptom | Prevention |
|---|---|---|
| Control inheritance over-claim (inherited but no app-layer demonstration) | Assessor rejects inherited rows; every claim kicked back to POA&M | Fill `evidence_artifact_pattern` on every inherited row; the P-ATO covers AWS, not the app |
| Missing automation citation (Config rule id absent) | Continuous-compliance feed cannot wire evidence collection; cATO dashboard shows gaps | Cite the concrete rule id (`iam-user-unused-credentials-check`) not the service name alone |
| Baseline/tier mismatch (High app missing High-only rows) | POA&M at assessment for ~60 missing controls | Drive the matrix from `ato-boundary-analyzer.json` tier, never from service inspection alone |
| Manual control marked automated (PT-3 / PS-3 flagged as automated) | Assessor rejects automation claim; credibility hit on the package | Keep the manual-control list explicit; mark honestly and cite the annual review cadence |
| Config rule quota exceeded (>150 rules in one region) | Deployment fails; unknown rule count blocks cATO go-live | Project the count in coverage-summary; raise quota pre-deployment |
| OSCAL component id churn (ids regenerated each wave) | cATO continuity breaks; prior evidence orphaned | Fix ids in the matrix; never auto-generate on regen |

## Handoff Summary
When this skill completes, verify:
1. `nist-control-automation-matrix.json` exists per app (or per portfolio
   depending on scope), passes its schema with zero errors, and covers the
   correct baseline tier per the boundary artifact.
2. `control-coverage-summary.json` exists, aggregates correctly, and lists
   every gap with a planned remediation.
3. Audit Manager framework selection is recorded and matches the tier.
4. Projected Config-rule count per region is inside quota or a quota
   increase ticket is referenced.
5. OSCAL component ids are stable versus any prior-wave matrix.

Then proceed to: `continuous-compliance-orchestrator` (runtime evidence
feed), `oscal-ssp-writer` (SSP/SAR/POA&M generation), and the cATO
dashboard in Governance. The next gate is **G-04c** (Architecture Compliance
Review) where the matrix, coverage summary, and Audit Manager framework
selection must be accepted before Modernization begins.

## References
- `references/nist-800-53-high-baseline-automation.md` — per control-family
  (AC, AU, AT, CA, CM, CP, IA, IR, MA, MP, PE, PL, PS, RA, SA, SC, SI, SR,
  PT) the specific AWS GovCloud automation that validates typical controls,
  plus Audit Manager framework coverage and FIPS nuance.
- NIST SP 800-53 Rev 5 — `https://csrc.nist.gov/publications/detail/sp/800-53/rev-5/final`
- FedRAMP Moderate and High baselines — `https://www.fedramp.gov/baselines/`
- AWS Audit Manager FedRAMP frameworks — console catalog under Frameworks.
- `profiles/faa/compliance.yaml` — FAA overlays (DOT TSMO, FISMA cadence).
- `schemas/architecture/nist-control-automation-matrix.schema.json` — matrix
  row shape.
- `schemas/architecture/control-coverage-summary.schema.json` — roll-up.

## Changelog
- 0.1.0 (2026-05-06) — Initial skill for SOO §6.1.1.1.3 Theme C (cATO) +
  Objective 6 (cyber/cATO). Covers Moderate and High baselines for the 8
  FAA apps (IACRA, RMS, DMS at High; AMCS, MedXPress, CHAPS, CPDSS, DIWS
  at Moderate), the AWS GovCloud automation mapping, Audit Manager
  framework selection, and OSCAL component id stability across waves.
