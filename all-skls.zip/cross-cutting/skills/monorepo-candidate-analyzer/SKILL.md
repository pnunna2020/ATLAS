---
name: monorepo-candidate-analyzer
description: >
  Detect repository pairs (or clusters) deployed as a single logical
  application but split across separate git repos. DIWS is the ATLAS
  case: .NET API backend + Angular 10 SPA frontend ship as two
  separate repos but are co-released and co-owned. They behave like
  a monorepo but aren't one — coordination overhead, version skew,
  integration-test fragility. Surfaces monorepo candidacy as a
  modernization-planning finding. Runs as Discovery conditional when
  two or more sibling repos share a client, similar name prefix, or
  declare each other as peers in README/CI. Triggers on monorepo
  candidacy detection, repo consolidation planning, or
  @monorepo-candidate-analyzer.
agent: sonnet
allowed-tools:
  - Read
  - Write
  - Grep
  - Glob
validation_commands:
  - "python -m olympus.validators.schema_validator monorepo-candidacy-inventory.json"
  - "python -m olympus.validators.schema_validator monorepo-consolidation-findings.json"
supported_stacks:
  - multi-repo
  - monorepo
  - polyrepo
anti_target_stacks:
  - single-repo-app
  - static-site
failure_classes:
  - independent-repos-mislabeled-as-pair
  - shared-dep-missed
  - cross-repo-version-skew-unflagged
  - coordinated-release-ignored
benchmark_tags:
  - portfolio-structure
  - monorepo-candidacy
  - cross-repo-consolidation
---

# monorepo-candidate-analyzer

## Purpose
Surface repo pairs/clusters behaving as a single application but
living in separate git repos. Recommend consolidation if coordination
cost is high; preserve separation otherwise.

## Inputs
- Portfolio of repositories (at least 2).
- Per-repo catalog entries.

## Outputs
- `monorepo-candidacy-inventory.json` — per candidate cluster:
  `{cluster_name, repos[], cluster_type (api+ui | microservices |
  shared-lib+consumers | polyrepo-by-language), cross_repo_refs[]}`.
- `monorepo-consolidation-findings.json` — per cluster:
  `{recommendation (consolidate | preserve), rationale,
  migration_effort_hours, coordination_cost_estimate}`.

## Methodology
1. Enumerate all repos available to Discovery.
2. Detect candidacy signals: shared name prefix, README cross-refs,
   CI pipeline cross-calls, same owner + release cadence, cross-
   repo file refs (AMCS's `..\..\DotnetComponents\` to CPDSS).
3. Classify cluster type.
4. Estimate consolidation vs preserve trade-offs.

## Tech-Stack Dispatch

No external references.

## Gotchas
- Shared name prefix isn't always a signal (some orgs prefix all
  repos by domain).
- Independent release cadence = NOT monorepo candidate.
- Consolidation has ongoing costs (larger clone, merge conflicts,
  tooling) — not always the right call.
- Access-control splits (public + internal) flag but don't
  auto-recommend merge.

## Quality Rules
- [ ] Every candidate cluster inventoried.
- [ ] Consolidation recommendation per cluster.
- [ ] Cross-repo refs resolved.
- [ ] Every record cites source repo + file.

## Common Failure Modes

| Failure Mode | Symptom | Prevention |
|---|---|---|
| Unrelated repos paired | Incorrect merge recommendation | Require > 1 candidacy signal |
| Consolidation recommended without cost | Tooling overhead unmentioned | Include trade-offs explicitly |

## Handoff Summary
Monorepo candidates inventoried. Proceed to
`migration-strategy-advisor`.

## References
None.

## Changelog
- 0.1.0 (2026-05-07) — Initial skill. Authored as ATLAS-R-19.
