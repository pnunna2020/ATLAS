---
name: sqlserver-discovery-patterns
description: >
  Extract Microsoft SQL Server / T-SQL specific discovery findings from a legacy
  application corpus: T-SQL stored procedures, functions, triggers, CLR objects,
  SSIS packages, SSRS reports, SSAS cubes, SQL Server Agent jobs, Service Broker
  queues, linked servers, DTC distributed transactions, Always On Availability
  Groups, replication topology, SQL Server-specific data types, and .NET / ODBC
  / ADO driver signatures. Runs as a conditional Discovery skill when the tech
  fingerprint from `analyze-application` reports database in {sqlserver, mssql,
  sql server}. Triggers on SQL Server discovery, T-SQL analysis, SSIS/SSRS/SSAS
  inventory, mssql fingerprint, or @sqlserver-discovery-patterns.
tier: 1
triggers:
  database: [sqlserver, mssql, "sql server"]
agent: sonnet
enrichment_level: Full
version: 0.1.0
allowed-tools:
  - Read
  - Grep
  - Write
---

# SQL Server Discovery Patterns

## Purpose
Produce a SQL Server-specific slice of the Discovery artifact for any
application whose database fingerprint is Microsoft SQL Server. `analyze-application`
and `dependency-mapper` capture generic RDBMS structure, but they do not
enumerate the Microsoft-specific surface area — T-SQL server objects, SSIS /
SSRS / SSAS companions, SQL Agent jobs, Service Broker queues, linked servers
and DTC distributed transactions, Always On replica topology, replication
publications, and the SQL-Server-only data types (`uniqueidentifier`,
`datetime2`, `hierarchyid`, `geography`, `sql_variant`). This skill fills that
gap so Rationalization and downstream Modernization skills can reason about
ownership, parity risk, and licensing before a disposition is chosen.

## Inputs
- Source code repository (Git URL or local path) containing application and
  database artifacts.
- Tech fingerprint from `analyze-application` Pass 1 with `database in
  {sqlserver, mssql, sql server}` (JSON per
  `schemas/discovery/tech-fingerprint.schema.json`).
- Application catalog entry (JSON per
  `schemas/discovery/application-catalog-entry.schema.json`).
- Database object scripts: `*.sql`, `*.tsql`, `schema/*.sql`,
  `sprocs/*.sql`, `migrations/*.sql`, SSDT `.sqlproj` + `*.sql` tree.
- BI / ETL artifacts under the repo: `*.dtsx` (SSIS), `*.rdl` / `*.rds` (SSRS),
  `*.bim` / `*.cube` / `*.dsv` (SSAS multidimensional and tabular).
- Connection-string and config sources: `web.config`, `app.config`,
  `appsettings*.json`, `application.yml`, Terraform / Bicep / ARM / CloudFormation
  templates.
- Operational scripts and job definitions: `sqlagent/*.sql`, `Jobs/*.xml`,
  PowerShell deploy scripts (`*.ps1`) that create jobs or publications.
- Always On / replication / DR config exports when present
  (`*-ag.sql`, `*-publication.sql`, `distributor.sql`).

## Outputs
- SQL Server fingerprint block merged into the tech fingerprint →
  `schemas/discovery/tech-fingerprint.schema.json` (fields under
  `database_details.sqlserver`).
- SQL Server object inventory (stored procs, functions, triggers, CLR
  assemblies with `{repo}:{file}:{line}` citations), emitted as a YAML block
  in the Discovery working set.
- BI / ETL companion inventory (SSIS packages, SSRS reports, SSAS cubes with
  package-level dependencies), emitted as a YAML block in the Discovery
  working set.
- Operational surface inventory (SQL Agent jobs, Service Broker queues,
  linked servers, DTC usage, Always On replicas, replication publications /
  subscriptions), emitted as a YAML block in the Discovery working set.
- Data-type risk report → emitted inline in the fingerprint under
  `database_details.sqlserver.type_risks[]`, flagging every
  `uniqueidentifier`, `datetime2(n)`, `hierarchyid`, `geography`, `geometry`,
  and `sql_variant` column with a `{file}:{line}` citation.
- Driver / auth signature block → `database_details.sqlserver.drivers[]` listing
  every distinct `SqlClient` / ODBC / ADO / JDBC / OLE DB signature and whether
  the connection uses SQL auth, Windows / AD Integrated, Azure AD, or
  Managed Identity.
- Performance / workload hints inline under
  `database_details.sqlserver.workload_hints` (TempDB contention signals,
  columnstore vs rowstore index detection, partition scheme usage).

## Methodology
1. **Gate on fingerprint.** Load the tech fingerprint; if
   `database` is not one of `sqlserver`, `mssql`, `sql server` (case
   insensitive), exit as no-op and emit a `skill-not-applicable` diagnostic.
2. **Enumerate T-SQL server objects.** Walk every `*.sql` / `*.tsql` file and
   every SSDT `.sqlproj` member. Parse `CREATE PROCEDURE`, `CREATE FUNCTION`,
   `CREATE TRIGGER`, `CREATE VIEW`, `CREATE ASSEMBLY`, `CREATE AGGREGATE`,
   and `CREATE TYPE` declarations. For each object emit one inventory entry
   with `object_type`, `schema`, `name`, `citation` as `{repo}:{file}:{line}`,
   and a `is_clr` flag when `FROM ASSEMBLY` or `EXTERNAL NAME` is present.
3. **Catalog BI / ETL companions.** For each `*.dtsx` package record
   connection managers, control-flow tasks, data-flow sources and destinations,
   and any `Execute SQL Task` calling a stored proc (resolve the proc back to
   the object inventory). For each `*.rdl` record the dataset command text and
   parameter list. For each SSAS artifact (`*.bim`, `Model.bim`, `*.cube`,
   `*.dsv`) record cube / model name, data source view, measure groups, and
   processing mode (ROLAP / MOLAP / Tabular).
4. **Catalog operational surface.** Parse SQL Agent job scripts
   (`sp_add_job`, `sp_add_jobstep`, `sp_add_schedule`) and record job name,
   step kind (`TSQL`, `SSIS`, `CmdExec`, `PowerShell`), schedule, and owner.
   Detect Service Broker usage via `CREATE QUEUE`, `CREATE SERVICE`,
   `CREATE CONTRACT`, `BEGIN DIALOG CONVERSATION` and record message types
   and routing. Record every `sp_addlinkedserver` as a linked-server entry
   with target product, provider, and data source.
5. **Detect distributed transactions and DTC.** Grep for
   `BEGIN DISTRIBUTED TRANSACTION`, `SET XACT_ABORT ON`, calls to
   `DTCGetTransactionManagerEx`, `TransactionScope` with `Distributed`
   promotion in .NET callers, and MSDTC configuration in `*.config`. Emit a
   DTC usage block with every citation.
6. **Map Always On and replication.** Parse any availability-group script
   (`CREATE AVAILABILITY GROUP`, `ALTER AVAILABILITY GROUP`, `sys.availability_groups`
   queries, `listener` references). Parse replication setup scripts
   (`sp_addpublication`, `sp_addarticle`, `sp_addsubscription`) and record the
   replication kind (snapshot / transactional / merge) for each publication.
   Record any readable-secondary usage from application connection strings
   (`ApplicationIntent=ReadOnly`).
7. **Fingerprint SQL-Server-only data types.** Grep column definitions and
   `DECLARE` statements for `uniqueidentifier`, `datetime2`, `datetimeoffset`,
   `hierarchyid`, `geography`, `geometry`, `sql_variant`, `xml`, `rowversion`
   / `timestamp`, and `sysname`. Emit one entry per occurrence with a
   `{file}:{line}` citation and a risk note for portability to other RDBMSs.
8. **Fingerprint driver / connection / auth signatures.** Scan configs and
   source files for `System.Data.SqlClient`, `Microsoft.Data.SqlClient`,
   `ODBC`: `SQL Server Native Client 11.0` / `ODBC Driver 17/18 for SQL Server`,
   ADO / OLE DB `SQLOLEDB` / `SQLNCLI`, and JDBC `jdbc:sqlserver://`. For
   each distinct signature, record `auth_mode` as `sql`, `windows_integrated`,
   `azure_ad_password`, `azure_ad_integrated`, or `managed_identity`, using
   the connection-string keywords (`Integrated Security`, `Authentication=`,
   `Trusted_Connection`).
9. **Collect workload / performance hints.** Grep for `#temp` table creation,
   `tempdb..` references, `WITH (RECOMPILE)`, `OPTION (MAXDOP`, `COLUMNSTORE`
   / `CLUSTERED COLUMNSTORE` index declarations, partitioning
   (`PARTITION FUNCTION`, `PARTITION SCHEME`), `sp_WhoIsActive` / trace-flag
   references, and heavy `NOLOCK` usage. Emit these under
   `workload_hints` with counts and citations — do not prescribe remediation,
   that is Rationalization's job.
10. **Merge and validate.** Merge the SQL Server fingerprint block into the
    tech fingerprint, write the three inventory blocks, and validate the
    combined fingerprint against `schemas/discovery/tech-fingerprint.schema.json`.
    Halt on schema errors.

## Tech-Stack Dispatch

Inline citations only; no external reference/asset files at this release.

Detection is mechanical: file extension + presence of specific T-SQL DDL
keywords. Dispatch triggers:

- `database in {sqlserver, mssql, "sql server"}` AND any `*.sql` / `*.tsql`
  in repo → T-SQL object patterns: `CREATE PROCEDURE/FUNCTION/TRIGGER`,
  `CREATE ASSEMBLY` (CLR), `EXTERNAL NAME`, `FOR XML`, `OPENJSON`.
- `*.dtsx`, `*.rdl`, `*.bim` present → SSIS / SSRS / SSAS patterns: SSIS
  connection managers, Execute SQL Task, RDL dataset commands, SSAS
  Tabular `.bim`.
- SQL Agent / Service Broker / linked server scripts → `sp_add_job`,
  `CREATE QUEUE`, `sp_addlinkedserver`, `BEGIN DISTRIBUTED TRANSACTION`.
- Always On / replication scripts → `CREATE AVAILABILITY GROUP`,
  `sp_addpublication`, `sp_addarticle`, `ApplicationIntent=ReadOnly`.

No overlap with `oracle-discovery-patterns` or `dotnet-discovery-patterns` —
those dispatch on `database=oracle` and on `primary_language in
{csharp, vbnet, dotnet}` respectively.

## Gotchas
- **SQL Server stored procedures frequently embed business rules the app
  assumes are "just persistence."** A proc with a `MERGE` or cursor-driven
  rule must land in the extraction inventory or the rule is lost. Every
  `CREATE PROCEDURE` body needs a `{file}:{line}` citation and a one-line
  description of side effects.
- **CLR procedures are not T-SQL.** `CREATE ASSEMBLY` + `CREATE PROCEDURE ...
  EXTERNAL NAME` loads a .NET DLL inside the database. Treat the referenced
  assembly as first-class source — record the DLL path and flag the object
  `is_clr: true`. Downstream extraction needs to inspect the .NET source,
  not the proc shell.
- **SSIS packages hide SQL in three places.** Package-level `Execute SQL
  Task`, `OLE DB Source` SQL command, and `Script Task` code-behind all
  contain T-SQL or .NET. Extracting only the control flow loses the
  business logic. Parse connection managers + every task's command property.
- **`datetime2(n)` and `datetimeoffset` do not map cleanly to PostgreSQL.**
  `datetime2(7)` has 100 ns precision; `TIMESTAMP` in PostgreSQL tops out at
  microseconds. Flag every `datetime2` column for precision review — silent
  truncation on migration is a data-loss bug.
- **`uniqueidentifier` defaults are not portable.** `NEWID()` and
  `NEWSEQUENTIALID()` differ in clustering and fragmentation behavior, and
  neither is a PostgreSQL default. Record which default is used per column.
- **`hierarchyid` and `geography` have no trivial PostgreSQL equivalent.**
  `hierarchyid` → materialized path or `ltree`; `geography` → PostGIS
  `geography(Point,4326)`. Flag each column so Modernization budgets the
  conversion effort.
- **`sql_variant` is a data smell.** It stores any base type with runtime
  dispatch. Every `sql_variant` column needs a usage audit during
  Rationalization — it usually hides an entity-attribute-value pattern.
- **Always On readable secondaries change consistency guarantees.**
  `ApplicationIntent=ReadOnly` routes reads to a replica that can be
  seconds behind. Apps with this flag must be documented as
  eventually-consistent on the read path; skipping this leads to
  "phantom missing row" bugs after the AG is broken.
- **Linked-server queries silently pull the remote schema into scope.**
  A `SELECT ... FROM [REMOTE].[db].[schema].[table]` hides a cross-server
  dependency that Discovery missed. Every `sp_addlinkedserver` and every
  four-part name reference must show up in `dependency-mapper` integration
  output.
- **SQL auth credentials in connection strings are secrets.** Never echo
  `Password=` / `Pwd=` values into the inventory. Record only the
  `auth_mode` and the user name; emit a `{file}:{line}` citation for
  follow-up by the secrets-audit pass.
- **`BEGIN DISTRIBUTED TRANSACTION` requires MSDTC.** If any caller
  promotes to DTC, flag the app as non-trivially cloud-hostile (MSDTC is
  not supported on Azure SQL DB, RDS, or Aurora). This drives disposition.
- **TempDB contention shows up as `#temp` abuse.** Procedures that create
  many `#temp` tables in hot paths are a migration risk (Azure SQL DB and
  RDS behave differently). Count `#temp` creations per procedure; do not
  recommend remediation here — hand the counts to Rationalization.
- **Columnstore indexes change query plans dramatically.** A
  `CLUSTERED COLUMNSTORE INDEX` on a fact table is a workload signal
  (analytical / OLAP) that must be recorded distinctly from rowstore
  indexing — downstream Architecture needs it to pick the right target
  (warehouse vs OLTP).

## Quality Rules
- [ ] Every `CREATE PROCEDURE`, `CREATE FUNCTION`, `CREATE TRIGGER`, and
      `CREATE ASSEMBLY` in the repo appears in the object inventory with a
      `{repo}:{file}:{line}` citation.
- [ ] Every CLR procedure is flagged `is_clr: true` and its backing
      assembly path is recorded.
- [ ] Every `*.dtsx`, `*.rdl`, and SSAS model file in the repo appears in
      the BI / ETL inventory with per-component dependencies enumerated.
- [ ] Every SQL Agent job (`sp_add_job` / `sp_add_jobstep`) is recorded
      with step kind, schedule, and owner.
- [ ] Every `sp_addlinkedserver` appears under `linked_servers[]` with
      the target product and provider.
- [ ] Every `BEGIN DISTRIBUTED TRANSACTION`, MSDTC config reference, or
      `TransactionScope` with distributed promotion is recorded under
      `distributed_transactions[]`.
- [ ] Every availability-group, replication publication, and replication
      subscription statement is recorded under `ha_dr[]` with kind
      (`always_on`, `snapshot`, `transactional`, `merge`).
- [ ] Every column of type `uniqueidentifier`, `datetime2`,
      `datetimeoffset`, `hierarchyid`, `geography`, `geometry`, or
      `sql_variant` appears under `type_risks[]` with a `{file}:{line}`
      citation.
- [ ] Every distinct driver / auth combination appears once under
      `drivers[]` with `auth_mode` drawn from the fixed enum.
- [ ] No connection-string password, API key, or token is written to any
      inventory file — only the `auth_mode` and user name.
- [ ] The merged tech fingerprint validates against
      `schemas/discovery/tech-fingerprint.schema.json`.

## Common Failure Modes
| Failure Mode | Symptom | Prevention |
|---|---|---|
| CLR procedures treated as plain T-SQL | Business logic hidden in a .NET DLL never reaches extraction; generator emits a shell proc with no behavior | Flag every `CREATE PROCEDURE ... EXTERNAL NAME` with `is_clr: true` and attach the assembly path to the inventory |
| SSIS package logic dropped on the floor | ETL rules inside `Execute SQL Task` / `Script Task` absent from the inventory; Rationalization underestimates the migration | Parse every `*.dtsx` control-flow node; follow `Execute SQL Task` back to the stored-proc inventory |
| `datetime2`/`datetimeoffset` mapped to seconds-precision target | Silent timestamp truncation after migration; failed audits for event ordering | Flag every `datetime2(n>=4)` column under `type_risks[]`; Rationalization must require a precision-preservation decision |
| Linked-server references missed | Cross-server data flow absent from `integration-graph.json`; disposition assumes app is standalone | Grep four-part names (`[server].[db].[schema].[object]`) and record every `sp_addlinkedserver` as a `linked_servers[]` entry |
| Distributed transactions invisible | App promoted to MSDTC at runtime but disposition chose Azure SQL DB (no MSDTC); deployments fail post-cutover | Record every `BEGIN DISTRIBUTED TRANSACTION` and every `TransactionScope(TransactionScopeOption.Required)` with multiple DB connections as a DTC signal |
| Passwords leaked into inventory | Connection-string `Password=` copied verbatim into the inventory YAML; secret scan fails; PR blocked | Parse connection strings, record `auth_mode` and user name only, never the secret |
| Columnstore / partitioning ignored | Analytical workload migrated to OLTP-shaped target; query performance collapses | Record every `COLUMNSTORE INDEX` and every `PARTITION SCHEME` under `workload_hints` |

## Handoff Summary
When this skill completes, verify:
1. The tech fingerprint's `database_details.sqlserver` block is present and
   validates against `schemas/discovery/tech-fingerprint.schema.json`.
2. Object, BI/ETL, and Ops inventories exist in the Discovery working set
   and every entry carries a `{repo}:{file}:{line}` citation.
3. No secret (`Password=`, `Pwd=`, `AccessKey=`) appears in any inventory
   file — only `auth_mode` + user name.
4. CLR procedures are flagged `is_clr: true`; distributed transactions,
   linked servers, Always On replicas, and replication publications are
   enumerated.
5. SQL-Server-only data types are recorded under `type_risks[]` and
   workload signals (columnstore, partitioning, TempDB, NOLOCK counts) are
   under `workload_hints`.

Then proceed to: `dependency-mapper` to fold the linked-server and
distributed-transaction signals into the integration graph;
`portfolio-integration-mapper` to expose them at portfolio level; and
`disposition-recommender` so the SQL Server surface area drives the 7R
decision. The next gate is **G-DC** (Discovery Completeness) where the
SQL Server fingerprint must be accepted before Rationalization begins.
