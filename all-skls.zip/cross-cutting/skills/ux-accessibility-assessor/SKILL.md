---
name: ux-accessibility-assessor
description: >
  Assess a legacy application's Section 508 / WCAG 2.1 AA posture AND its UX
  complexity during Discovery, emitting a reviewable ux-accessibility.json
  artifact. Catalogs the UI inventory (page/screen/modal surfaces and their
  interactive elements), user journeys (including cross-application
  swivel-chair patterns), critical accessibility violations with severity and
  WCAG citations, and a UX-debt backlog with remediation effort estimates.
  Produces the compliance_score (0-100) and ux_complexity rating (1-5) that
  feed portfolio-scorer User Impact, disposition-recommender accessibility
  gating, and modernization effort estimates. Triggers on 508 compliance,
  WCAG audit, accessibility review, UX assessment, swivel-chair workflow,
  or @ux-accessibility-assessor.
agent: sonnet
allowed-tools:
  - Read
  - Write
  - Grep
validation_commands:
  - "python -m olympus.validators.schema_validator ux-accessibility.json"
supported_stacks:
  - webforms
  - dotnet
  - csharp
  - java
  - spring-boot
  - coldfusion
  - natural
  - angular
  - react
anti_target_stacks:
  - batch-only
  - headless-service
failure_classes:
  - missed-blocker-violation
  - cross-app-journey-missed
  - compliance-score-without-evidence
  - ux-complexity-conflation
benchmark_tags:
  - discovery-508
  - ux-complexity
  - cross-app-journey
---

# ux-accessibility-assessor

## Purpose
Produce a transparent Section 508 / WCAG 2.1 AA baseline and UX-complexity rating for a legacy application so Rationalization can weight User Impact, Cost, and Technical Debt honestly. Accessibility has historically been inferred during `catalog-application` as an afterthought; this skill makes the assessment a first-class Discovery artifact with a named schema, severity-tagged critical violations, an enumerated UI inventory, and persona-level user journeys that capture swivel-chair cross-application patterns. The compliance_score and ux_complexity it emits are the authoritative signals downstream skills read — raw axe or Lighthouse output alone is not auditable.

## Inputs
- Application source code (HTML/ASPX/JSP/Razor/MAP screens, component trees, templates) — for the UI inventory and violation scans
- Application catalog entry (JSON per `schemas/discovery/application-catalog-entry.schema.json`) — supplies `user_context.personas`, `entry_points`, and prior `accessibility_baseline` hints when present
- Discovery Pass 1 analysis report — surfaces routing tables, role-gated pages, and module boundaries used to bound the UI inventory
- Portfolio catalog (optional) — used to detect cross-application journeys where multiple apps in the portfolio share a persona
- WCAG 2.1 AA baseline: `references/wcag-2-1-aa-baseline.md`
- UX complexity rubric: `references/ux-complexity-rubric.md`

## Outputs
- UX & accessibility assessment → `schemas/discovery/ux-accessibility.schema.json` (scaffold: `assets/ux-accessibility-output-template.json`)
  - `application_id`, `assessed_date`, `compliance_score` (0-100), `ux_complexity` (1-5)
  - `ui_inventory[]` — every page/screen/modal with `page_id`, `title`, `technology`, `interactive_element_count`
  - `user_journeys[]` — `journey_id`, `persona`, ordered `steps[]`, `cross_app` flag for swivel-chair flows
  - `critical_violations[]` — `violation_id`, `wcag_criterion`, `severity` ∈ `{blocker, major, minor}`, `location`, `evidence`
  - `ux_debt_inventory[]` — `debt_id`, `category`, `severity`, `remediation_effort_days`
  - `evidence[]` — top-level citation anchors supporting the assessment

## Methodology
1. Enumerate the UI inventory. Walk the source tree for every routed view, dialog, modal, and report surface. For each surface, record `page_id`, human-readable `title`, UI technology (WebForms, Razor, JSP, Angular, NATURAL MAP, etc.), and a count of interactive elements (inputs, buttons, links, custom controls) — the counts drive the UI surface dimension of the UX complexity rubric.
2. Trace user journeys per persona listed in the catalog entry. For each persona, enumerate the ordered steps that complete their primary tasks and flag `cross_app: true` whenever the persona must leave this application for another to finish. Cross-app journeys are the canonical swivel-chair signal.
3. Run the WCAG 2.1 AA checklist in `references/wcag-2-1-aa-baseline.md`. For each criterion, either cite passing evidence or record a `critical_violations[]` entry with severity `blocker` (prevents task completion for AT users), `major` (significant friction), or `minor` (cosmetic/edge-case).
4. Inventory UX debt. Anything that is not a blocker/major/minor WCAG violation but still degrades experience (dead click paths, cognitive overload, inconsistent terminology, unnecessary modality) lands in `ux_debt_inventory[]` with a `remediation_effort_days` estimate so Cost and Modernization Complexity scoring stay honest.
5. Compute `compliance_score` (0-100). Start at 100, deduct per severity: blocker -12, major -5, minor -2, cap at 0. Document the deduction math in the `evidence[]` array so the score is auditable.
6. Compute `ux_complexity` (1-5) using `references/ux-complexity-rubric.md`. Weighted-average of: UI surface count bucket, unique journey count bucket, swivel-chair presence, accessibility defect density, cognitive load signal. Round to nearest integer and clamp to 1-5.
7. Validate the artifact. It MUST pass `schemas/discovery/ux-accessibility.schema.json`. Use `assets/ux-accessibility-output-template.json` as the scaffold and fill every required field.
8. Self-check: compliance_score math recomputable from critical_violations counts; every cross-app journey references a persona also present in another app's catalog entry; ui_inventory surface count matches the rubric bucket used in ux_complexity.

## Gotchas
- **Blockers are not rare.** Keyboard-inaccessible custom controls, focus traps, and missing programmatic labels each count as blockers per WCAG 2.1 AA. Under-counting blockers silently inflates compliance_score and hides real risk from disposition-recommender.
- **`ux_complexity` is NOT `compliance_score` inverted.** A simple two-page app can be 508-broken (low compliance_score, low ux_complexity). A sprawling swivel-chair workflow can be fully compliant and still be ux_complexity=5. Keep the two signals independent — the rubric enforces it.
- **Cross-app journeys are the swivel-chair signal.** Missing them hides the real user cost and causes disposition-recommender to under-weight Consolidate vs. Refactor. Always cross-reference the portfolio catalog when computing journeys.
- **Count every modal and report surface.** UI inventory is what feeds the UX surface-count bucket; skipping "admin only" screens or print reports undercounts complexity and produces a too-low ux_complexity rating.
- **Severity enum is strict.** `blocker | major | minor` — not `high/medium/low`, not `critical`. The schema rejects anything else and the validator surfaces that as a warn.
- **Remediation effort is engineering days, not story points.** Story-point estimates are not comparable across teams; cost and modernization scoring assume days. Document the estimation basis in `evidence[]`.
- **compliance_score range is 0-100 inclusive integer.** A float or out-of-range value fails the schema. Clamp to 0 on the low end; never emit 101.

## Quality Rules
- [ ] `compliance_score` is an integer in [0, 100]; the deduction math is cited in `evidence[]` and recomputable from `critical_violations[]`.
- [ ] `ux_complexity` is an integer in [1, 5]; the rubric bucket decisions are cited in `evidence[]`.
- [ ] Every `critical_violations[]` entry has a `wcag_criterion`, severity in `{blocker, major, minor}`, a `location`, and at least one `evidence` anchor.
- [ ] `ui_inventory[]` is non-empty for any app that has a UI surface, and `interactive_element_count` is a non-negative integer.
- [ ] Every persona named in `user_journeys[]` is also present in the application catalog entry's `user_context.personas` (or explicitly noted as external in `evidence[]`).
- [ ] Cross-app journeys (`cross_app: true`) reference another application present in the portfolio catalog; the other app's `application_id` is cited in `evidence[]`.
- [ ] `ux_debt_inventory[]` items use the same severity enum as `critical_violations[]` and every `remediation_effort_days` is ≥ 0.
- [ ] The artifact passes `schemas/discovery/ux-accessibility.schema.json` with zero validator errors.
- [ ] `application_id` matches the catalog-entry application id (not the display name).

## Common Failure Modes
| Failure Mode | Symptom | Prevention |
|---|---|---|
| Missed blocker violations | compliance_score near 100 but real users with AT cannot complete primary tasks | Run every criterion in `references/wcag-2-1-aa-baseline.md`; if a custom control has no keyboard handler or programmatic name, that's a blocker |
| Cross-app journeys collapsed into single-app journeys | disposition-recommender under-weights Consolidate because swivel-chair cost is hidden | Cross-reference the portfolio catalog when enumerating journeys; set `cross_app: true` when any step moves the persona to another application |
| compliance_score emitted without evidence | Stakeholders cannot audit why the score is what it is; reruns drift | Record the deduction math (e.g., "100 - 3×12 blocker - 4×5 major - 6×2 minor = 32") in `evidence[]`; recomputable from `critical_violations[]` |
| UX complexity conflated with compliance | A fully compliant but sprawling app rated ux_complexity=1 because there are no violations | Compute `ux_complexity` strictly from the rubric (surfaces, journeys, swivel-chair, defect density, cognitive load); never substitute compliance_score |
| Severity values outside the enum | Schema validation fails with `severity is not one of [...]` | Stick to `blocker | major | minor`; map any legacy "critical/high/medium/low" inputs into the enum before writing |
| Remediation effort missing or unitless | Cost dimension cannot roll up; planning estimates drift | Emit `remediation_effort_days` as a number; document the estimation basis (e.g., "1 dev-day for aria-label retrofit per surface") in `evidence[]` |

## Handoff Summary
When this skill completes, verify:
1. `ux-accessibility.json` exists next to the catalog entry and passes its schema with zero errors.
2. `compliance_score` and `ux_complexity` are both numeric, in range, and their math is cited in `evidence[]`.
3. `critical_violations[]`, `ui_inventory[]`, `user_journeys[]`, and `ux_debt_inventory[]` are populated — empty arrays are legal only for apps genuinely lacking that surface (note it in `evidence[]`).
4. Every cross-app journey references another application in the portfolio.

Then proceed to: `portfolio-scorer` (User Impact + Technical Debt + Cost dimensions ingest these signals) and `disposition-recommender` (accessibility-risk gating for Retire / Refactor / Rearchitect).
