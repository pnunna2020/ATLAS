# UX Complexity Rubric (1-5)

`ux_complexity` is a 1-5 integer rating computed from five independent
signals. Each signal is mapped to a 1-5 bucket using the tables below, and
the overall rating is the weighted average rounded to the nearest integer
(clamped to 1-5). The rubric is deliberately independent of
`compliance_score` — a fully compliant app can still be ux_complexity=5,
and a broken-but-simple app can still be ux_complexity=1.

## Signal 1 — UI Surface Count (weight 0.25)

Count every distinct surface in `ui_inventory[]` (pages, screens, modals,
reports, wizards).

| Surfaces | Bucket |
|---|---|
| 1-5 | 1 |
| 6-15 | 2 |
| 16-30 | 3 |
| 31-60 | 4 |
| 61+ | 5 |

## Signal 2 — Unique User Journey Count (weight 0.20)

Count distinct `user_journeys[]` entries.

| Journeys | Bucket |
|---|---|
| 1 | 1 |
| 2-3 | 2 |
| 4-6 | 3 |
| 7-10 | 4 |
| 11+ | 5 |

## Signal 3 — Swivel-Chair / Cross-App Patterns (weight 0.25)

Let N = number of `user_journeys[]` with `cross_app: true`.

| Cross-app journeys | Bucket |
|---|---|
| 0 | 1 |
| 1 | 3 |
| 2-3 | 4 |
| 4+ | 5 |

Swivel-chair workflows are weighted heavily because the modernization cost
(data-entry duplication, reconciliation, training burden) is
disproportionate to the raw surface count.

## Signal 4 — Accessibility Defect Density (weight 0.15)

Defect density = (`critical_violations` count + `ux_debt_inventory` count) /
(`ui_inventory` count). Divide-by-zero defaults to bucket 1.

| Density | Bucket |
|---|---|
| 0.00 - 0.25 | 1 |
| 0.26 - 0.75 | 2 |
| 0.76 - 1.50 | 3 |
| 1.51 - 3.00 | 4 |
| 3.01+ | 5 |

## Signal 5 — Cognitive Load Signal (weight 0.15)

Observed from source + journey review. Qualitative — pick the single best
match.

| Indicator | Bucket |
|---|---|
| Single-purpose form, <=5 fields, linear flow | 1 |
| Single app, straightforward task, <=10 fields per screen | 2 |
| Multi-step forms, conditional visibility, moderate branching | 3 |
| Wizards + dashboards + inline docs required to complete | 4 |
| External reference documents required; expert user assumption | 5 |

## Aggregation

```
ux_complexity = round(
  0.25 * surface_bucket +
  0.20 * journey_bucket +
  0.25 * swivel_chair_bucket +
  0.15 * defect_density_bucket +
  0.15 * cognitive_load_bucket
)
```

Clamp to `[1, 5]` after rounding. Record each bucket decision and the
weighted sum in `evidence[]` so reviewers can audit the rating — a bare
integer with no math trail is not defensible.

## Tie-breaker

If the weighted sum lands exactly between two integers (e.g., 3.50), round
up. Rounding toward higher complexity surfaces risk earlier rather than
later and aligns with the precautionary stance in gate reviews.
