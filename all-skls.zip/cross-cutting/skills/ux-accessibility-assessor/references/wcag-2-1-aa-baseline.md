# Section 508 / WCAG 2.1 AA Baseline Checklist

Run this list against every UI surface enumerated in `ui_inventory[]`. Each
criterion maps to one or more WCAG 2.1 AA success criteria; where multiple
criteria fold into the same check, the canonical one is named. Severity
guidance is the default — upgrade to `blocker` when the failure prevents
task completion for assistive-technology users, keep at `major` when it
creates significant friction, demote to `minor` only for cosmetic or
edge-case failures.

All references below are WCAG 2.1 AA (https://www.w3.org/TR/WCAG21/) and
Revised 508 Standards (https://www.access-board.gov/ict/). A "pass" needs
at least one evidence citation in the output's `evidence[]` array.

## 1. Perceivable

- [ ] **1.1.1 Non-text Content (A)** — every image, icon, chart has a text
      alternative; decorative images have `alt=""`. Default severity: major;
      blocker when the image conveys primary content.
- [ ] **1.2.2 Captions (Prerecorded) (A)** — synced captions for recorded
      audio/video. Default severity: major.
- [ ] **1.2.4 Captions (Live) (AA)** — live captions for streamed audio.
      Default severity: major.
- [ ] **1.2.5 Audio Description (Prerecorded) (AA)** — audio descriptions
      for video. Default severity: major.
- [ ] **1.3.1 Info and Relationships (A)** — headings, labels, tables use
      programmatic structure (h1-h6, `<th scope>`, `<label for>`). Default
      severity: blocker for forms, major elsewhere.
- [ ] **1.3.2 Meaningful Sequence (A)** — DOM order matches visual order so
      screen-reader linearization stays coherent. Default severity: major.
- [ ] **1.3.3 Sensory Characteristics (A)** — instructions do not rely
      solely on shape, color, or position (e.g., "click the red button").
      Default severity: minor.
- [ ] **1.3.4 Orientation (AA)** — content does not lock to a single
      orientation. Default severity: minor.
- [ ] **1.3.5 Identify Input Purpose (AA)** — common form fields expose
      `autocomplete` tokens. Default severity: minor.
- [ ] **1.4.1 Use of Color (A)** — color is not the sole means of conveying
      status (errors, required fields). Default severity: major.
- [ ] **1.4.3 Contrast (Minimum) (AA)** — 4.5:1 for normal text, 3:1 for
      large text. Default severity: major; blocker if primary CTA fails.
- [ ] **1.4.4 Resize Text (AA)** — content usable at 200% zoom without
      loss. Default severity: major.
- [ ] **1.4.5 Images of Text (AA)** — text rendered as images only when
      customization is not possible. Default severity: minor.
- [ ] **1.4.10 Reflow (AA)** — at 320 CSS pixel width content reflows
      without two-dimensional scrolling. Default severity: major.
- [ ] **1.4.11 Non-text Contrast (AA)** — UI controls and graphical
      objects have 3:1 contrast. Default severity: major.
- [ ] **1.4.12 Text Spacing (AA)** — content survives the WCAG spacing
      overrides. Default severity: minor.
- [ ] **1.4.13 Content on Hover or Focus (AA)** — tooltips are dismissible,
      hoverable, persistent. Default severity: major.

## 2. Operable

- [ ] **2.1.1 Keyboard (A)** — every control is keyboard-reachable and
      operable without a pointer. Default severity: blocker.
- [ ] **2.1.2 No Keyboard Trap (A)** — focus can leave any component via
      keyboard alone. Default severity: blocker.
- [ ] **2.1.4 Character Key Shortcuts (A)** — single-character shortcuts
      can be disabled or remapped. Default severity: minor.
- [ ] **2.4.1 Bypass Blocks (A)** — a skip-link or landmark structure
      lets AT users skip repeated content. Default severity: major.
- [ ] **2.4.2 Page Titled (A)** — every view has a unique `<title>`.
      Default severity: major.
- [ ] **2.4.3 Focus Order (A)** — focus moves in an order matching meaning
      and operation. Default severity: major.
- [ ] **2.4.4 Link Purpose (In Context) (A)** — link text is meaningful on
      its own or with surrounding context. Default severity: major.
- [ ] **2.4.5 Multiple Ways (AA)** — more than one way to locate a page
      (search, sitemap, navigation). Default severity: minor.
- [ ] **2.4.6 Headings and Labels (AA)** — headings and labels describe
      topic or purpose. Default severity: major.
- [ ] **2.4.7 Focus Visible (AA)** — keyboard focus is visibly indicated.
      Default severity: blocker.
- [ ] **2.5.1 Pointer Gestures (A)** — multi-point / path gestures have
      single-pointer alternatives. Default severity: major.
- [ ] **2.5.2 Pointer Cancellation (A)** — activation happens on up-event,
      or down + abort is possible. Default severity: minor.
- [ ] **2.5.3 Label in Name (A)** — the accessible name contains the
      visible label text. Default severity: major.
- [ ] **2.5.4 Motion Actuation (A)** — motion-triggered actions have a
      conventional UI alternative. Default severity: minor.

## 3. Understandable

- [ ] **3.1.1 Language of Page (A)** — `<html lang>` declared correctly.
      Default severity: major.
- [ ] **3.2.1 On Focus (A)** — focus changes do not trigger context
      changes. Default severity: major.
- [ ] **3.2.2 On Input (A)** — input changes do not trigger unexpected
      context changes. Default severity: major.
- [ ] **3.2.3 Consistent Navigation (AA)** — nav structures repeat in the
      same order across pages. Default severity: minor.
- [ ] **3.2.4 Consistent Identification (AA)** — components with the same
      function are labeled consistently. Default severity: minor.
- [ ] **3.3.1 Error Identification (A)** — errors are identified in text.
      Default severity: blocker for blocking forms, major elsewhere.
- [ ] **3.3.2 Labels or Instructions (A)** — every input has a programmatic
      label or instruction. Default severity: blocker.
- [ ] **3.3.3 Error Suggestion (AA)** — suggestions are provided when
      input errors can be described. Default severity: major.
- [ ] **3.3.4 Error Prevention (Legal/Financial/Data) (AA)** — reversible,
      checked, or confirmed submissions. Default severity: blocker.

## 4. Robust

- [ ] **4.1.2 Name, Role, Value (A)** — every custom control exposes
      programmatic name, role, state, and value. Default severity: blocker.
- [ ] **4.1.3 Status Messages (AA)** — status updates announced via
      `aria-live` or equivalent. Default severity: major.

## Recording results

For each criterion above, emit either a passing citation (file / line /
evidence of compliance) into the top-level `evidence[]` array, or a
`critical_violations[]` entry:

```
{
  "violation_id": "V-W212-0001",
  "wcag_criterion": "2.1.2 No Keyboard Trap",
  "severity": "blocker",
  "location": "Pages/Application/Review.aspx modal dialog",
  "evidence": "Pages/Application/Review.aspx.cs:312"
}
```

Long-tail non-blocker debt (inconsistent terminology, color-contrast near
misses that still pass, dead click-paths) belongs in
`ux_debt_inventory[]`, not `critical_violations[]`.
