# Consolidation Patterns

A cross-system capability that spans >=2 applications has three viable
consolidation patterns. The choice is not stylistic — each implies a
different risk profile, sequencing cost, and FAA/gov compliance path.

## strangler-fig

Incrementally route traffic away from the legacy implementations to a new
(or newly-canonicalized) implementation, collapsing duplicate paths one at
a time. Name the canonical target in step 1 of `sequencing[]`.

When to use:
- Any participating application is Tier 1 (safety-critical or mission-critical
  under the client profile). Outage-window risk is unacceptable.
- Live production traffic with strict SLOs or 24/7 availability.
- Data reconciliation must happen in flight because the participating apps
  run different schemas on overlapping identifiers.

FAA-specific considerations:
- ATC-adjacent or SWIM-integrated systems are almost always Tier 1 and
  therefore strangler-fig by default.
- IACRA-style airman-record systems need a reconciliation path that keeps
  `airman_id` canonical throughout the migration; name this in step 1.
- NOTAM or flight-plan capabilities require dual-run validation steps between
  routing reads and routing writes; insert a validation gate (e.g., G-V1)
  between those steps.

Sequencing shape (typical):
1. Stand up canonical service + route reads (feature-flag).
2. Dual-write (legacy + canonical) with drift monitor.
3. Cut writes to canonical; legacy becomes read-only.
4. Retire legacy write paths; cover tests.
5. Retire legacy read paths; remove feature flag.

## bulk-replace

Cut all participating apps over at once to a single canonical implementation.
Cheaper to plan, higher blast radius.

When to use:
- All participating apps already slated for `retire` or `replace` per their
  per-app dispositions.
- An outage window is explicitly permitted by the client profile for the
  capability's business window (e.g., weekend batch-only systems).
- Shared identifiers are already reconciled or not in play.

FAA-specific considerations:
- Almost never acceptable for Tier 1. Bulk-replace at FAA is limited to
  internal reporting overlays, batch reconciliation jobs, and document
  archive systems where downtime is acceptable.
- Requires a documented go/no-go decision citing `profiles/faa/gates.yaml`
  and a rollback plan — name the rollback artifact in `evidence[]`.

Sequencing shape (typical):
1. Cut-over weekend: freeze legacy writes, migrate data, enable canonical
   service.
2. Validation + signoff (often the same step as the cut-over).

## keep-separate

Explicit decision that the capability should not be consolidated even though
it spans multiple apps. The plan still lives for auditability.

When to use:
- Integration graph shows no shared identifier overlap across participating
  apps; consolidation would require a prior data-reconciliation project
  that is out of scope.
- Participating apps are owned by different regulatory or organizational
  boundaries (e.g., one FAA line-of-business, one DOT-enterprise) and
  consolidation would force a political negotiation the rationalization
  line cannot resolve.
- Short-horizon retire for all participants (<18 months) makes consolidation
  wasteful — let them individually retire.

FAA-specific considerations:
- Cross-agency deps (FAA <-> GSA Login.gov, FAA <-> DOT Enterprise Auth)
  default to `keep-separate` unless the profile explicitly authorizes
  consolidation.
- If `keep-separate` is chosen but shared identifiers are present, emit a
  data-drift risk at `severity: high` so the decision is revisited at the
  next portfolio review.

Sequencing is empty for `keep-separate`. Risks and rationale remain
mandatory.

## Decision summary

| Signal | strangler-fig | bulk-replace | keep-separate |
|---|---|---|---|
| Any Tier 1 app | default | discouraged | allowed |
| Outage window permitted | allowed | required | n/a |
| Shared-identifier overlap | required | optional | triggers data-drift risk |
| Cross-agency owners | allowed | discouraged | default |
| All apps `retire`/`replace` | allowed | default | allowed |
