---
name: capability-consolidation-advisor
description: >
  Recommend a unified, capability-level disposition for business capabilities
  that span more than one application. Consumes a cross-portfolio
  integration-graph plus per-app disposition-recommendation artifacts and
  emits a capability-consolidation-plan.json that names the aggregate
  disposition (7R plus keep-separate), a consolidation pattern
  (strangler-fig / bulk-replace / keep-separate), sequencing, risks, and
  rough effort per cross-system capability. Runs as a Rationalization
  post-processing pass, only when >=2 per-app dispositions already exist.
  Triggers on capability consolidation advice, cross-system disposition,
  capability-level 7R, portfolio consolidation plan, or
  @capability-consolidation-advisor.
version: 0.1.0
agent: opus
enrichment_level: partial
allowed-tools:
  - Read
  - Write
  - Grep
---

# Capability Consolidation Advisor

## Purpose
Produce the single `capability-consolidation-plan.json` artifact that turns
portfolio-level observations into executable consolidation guidance. Per-app
Rationalization emits a 7R decision for each application; `portfolio-integration-mapper`
emits an integration graph with `cross_system_capabilities[]` that names the
capabilities spanning multiple systems. Neither artifact alone answers the
question "should these three apps collapse into one capability?"  This skill
sits on top of both, picks an aggregate disposition, names the consolidation
pattern, and orders the work into numbered steps. Without it, consolidation
decisions remain implicit and per-app 7Rs cannot be reconciled against the
integration graph.

## Inputs
- Cross-portfolio integration graph with populated `cross_system_capabilities[]`
  (JSON per `schemas/rationalization/integration-graph.schema.json`).
- Per-app disposition recommendations, one per application in scope
  (JSON per `schemas/rationalization/disposition-recommendation.schema.json`).
  At least two must be available for the skill to fire.
- Client-profile scoring config (`profiles/<client>/scoring.yaml`) for
  effort banding and risk-tier weighting.
- Client-profile risk-classification (`profiles/<client>/risk-classification.yaml`)
  for app tier values feeding severity decisions.

## Outputs
- Capability consolidation plan →
  `schemas/rationalization/capability-consolidation-plan.schema.json`
  (emitted as `capability-consolidation-plan.json` in the Rationalization
  working set).
- Per-capability evidence list citing the integration-graph capability row
  and each per-app disposition that backed the aggregate decision.

## Methodology
1. Enumerate entries in `integration-graph.cross_system_capabilities[]`.
   Fail closed when the array is empty — there is nothing to consolidate.
2. For each capability, collect the `supporting_systems[]` ids and pull the
   per-app disposition for each id from the available
   `disposition-recommendation.json` artifacts. Mark apps without a recommendation
   as `per_app_disposition = "unknown"`.
3. Pick the aggregate disposition by applying these rules, in order:
   - If every per-app disposition is `retire`, aggregate is `retire`.
   - If ≥2 participating apps hold duplicated business logic (signal: shared
     identifiers + overlapping data domains) and at least one is `rearchitect`
     or `replace`, aggregate is `consolidate`.
   - If apps are already on different target platforms and no shared-identifier
     overlap exists, aggregate is `keep-separate`.
   - Otherwise, promote the strongest per-app disposition (strongest order:
     retire → replace → rearchitect → consolidate → replatform → refactor → retain)
     to the capability level, qualified by the rationale.
4. Choose a `consolidation_pattern`:
   - `strangler-fig` when the capability is high-risk (any Tier 1 app) OR the
     participating apps carry live production traffic with zero planned downtime.
   - `bulk-replace` when all participating apps are already slated for `retire`
     or `replace` AND an outage window is acceptable per profile guidance.
   - `keep-separate` whenever `aggregate_disposition == "keep-separate"`.
5. Sequence the work. For `strangler-fig`, the first step routes reads to a
   canonical service, subsequent steps move writes, and the final step retires
   the legacy paths. For `bulk-replace`, a single step names all apps and the
   cut-over action. For `keep-separate`, `sequencing` is an empty array.
6. Score risks. Always include data-drift risk when `shared_identifiers[]`
   contains any identifier referenced by the capability. Always include a
   regulatory-review risk when any participating app is Tier 1. Severity
   bands follow the client profile.
7. Estimate effort using a T-shirt band (S/M/L/XL) + person-weeks band from
   `profiles/<client>/scoring.yaml`. When the profile does not define
   bands, fall back to M / 12 person-weeks with a notes trail explaining
   the default.
8. Validate the assembled document against
   `schemas/rationalization/capability-consolidation-plan.schema.json` before
   emitting. Halt on schema errors — the plan feeds wave planning and
   disposition validation downstream.
9. Write the plan alongside the other Rationalization artifacts and record
   `metadata.generated_date`, `metadata.capabilities_analyzed`, and the
   source-artifact digests so the output is reproducible.

## Gotchas
- **Per-app dispositions lag the integration graph.** Rationalization may have
  run on apps A and B but not yet on C, even though all three appear in the
  capability's `supporting_systems[]`. Use `per_app_disposition = "unknown"`
  instead of dropping the app from `participating_apps[]`; otherwise the
  participating count falls below `minItems: 2` and the entry fails schema
  validation.
- **Consolidation is not the same as Consolidate.** The 7R `consolidate`
  disposition is a per-app choice ("collapse this app into another"); the
  capability-level `aggregate_disposition` can be any 7R value plus
  `keep-separate`. Do not force the aggregate to `consolidate` just because
  the capability spans multiple apps.
- **Strangler-fig needs a canonical target.** Choosing `strangler-fig` without
  naming which participating app (or a new-build target) is the canonical
  implementation in the `sequencing[]` steps produces an un-executable plan.
  Always name the target in the first step's `action`.
- **Shared identifiers gate consolidation feasibility.** If the integration
  graph shows no shared identifier across participating apps, consolidation
  is almost certainly infeasible without a prior data-reconciliation project;
  prefer `keep-separate` or flag a data-drift risk with `severity: high`.
- **Tier-1 apps cannot bulk-replace without an outage-window decision.**
  Default to `strangler-fig` when any participating app is Tier 1 unless the
  profile explicitly permits outages for the capability's business window.
- **Evidence list is load-bearing.** Every plan entry must cite the integration
  graph capability id AND at least one per-app disposition. Plans without
  traceable evidence cannot pass `validate-disposition` downstream.

## Quality Rules
- [ ] Every `capability_plans[]` entry has a non-empty `capability_id` and
      `capability_name` matching (or derived from) an integration-graph
      `cross_system_capabilities[]` row.
- [ ] Every entry has `participating_apps[]` with `minItems: 2`; each app
      carries an `app_id` present in `integration-graph.systems[].id` and a
      `per_app_disposition` drawn from the schema enum.
- [ ] Every entry's `aggregate_disposition` is drawn from the 7R enum
      extended by `keep-separate`; no free-form values.
- [ ] Every entry's `consolidation_pattern` is one of
      `strangler-fig` / `bulk-replace` / `keep-separate`; `keep-separate`
      appears iff `aggregate_disposition == "keep-separate"`.
- [ ] `sequencing[]` is empty for `keep-separate` and non-empty otherwise;
      step numbers are contiguous starting from 1.
- [ ] `risks[]` entries all carry `severity` from the enum; data-drift
      and regulatory-review risks are present when their triggers fire
      (see Methodology step 6).
- [ ] `estimated_effort.tier` is S/M/L/XL and aligned with the client
      profile's banding when available.
- [ ] `evidence[]` cites the source integration-graph capability row and
      at least one per-app disposition recommendation.
- [ ] The emitted JSON validates against
      `schemas/rationalization/capability-consolidation-plan.schema.json`
      under Draft 2020-12.

## Common Failure Modes
| Failure Mode | Symptom | Prevention |
|---|---|---|
| Aggregate forced to `consolidate` | Every cross-system capability emits `aggregate_disposition = consolidate` regardless of evidence | Apply the ordered rules in Methodology step 3; `consolidate` requires duplicated business logic plus a stronger per-app signal |
| Strangler-fig with no target | `consolidation_pattern = strangler-fig` but `sequencing[]` never names the canonical target service | First step of a strangler-fig plan must name the target implementation in `action` |
| Dropping apps with no per-app disposition | Participating apps from the integration graph silently excluded because their disposition-recommendation.json is missing | Mark missing per-app dispositions as `unknown` rather than dropping the app entry |
| Effort band hallucinated | Effort tier unrelated to profile scoring bands or participating-app complexity | Load `profiles/<client>/scoring.yaml` before emitting; fall back to documented defaults with notes |
| Schema drift on `aggregate_disposition` | Plan emits `keep_separate` (underscore) instead of `keep-separate`, failing schema | Use the schema enum verbatim; never rename tokens even if upstream artifacts use a variant |
| Risks list empty when shared identifiers present | No data-drift risk emitted even though the capability shares `airman_id` across three systems | Always emit data-drift risk when the capability's supporting systems overlap with a `shared_identifiers[]` entry |

## Handoff Summary
When this skill completes, verify:
1. `capability-consolidation-plan.json` exists in the Rationalization working
   set and validates against
   `schemas/rationalization/capability-consolidation-plan.schema.json`.
2. Every plan entry's `capability_id` resolves back to a
   `cross_system_capabilities[]` row in the source integration graph.
3. Every plan entry cites at least one per-app disposition in `evidence[]`.
4. Strangler-fig plans name the canonical target in their first sequencing
   step; bulk-replace plans declare a cut-over action.

Then proceed to: `wave-planner` (Rationalization wave-plan) which consumes
the consolidation plan to order cross-capability waves, and onward to
`validate-disposition` for final disposition reconciliation. The next gate
is **G-RR** (Rationalization Review) where the consolidation plan must be
accepted before any capability-level disposition is treated as final.
