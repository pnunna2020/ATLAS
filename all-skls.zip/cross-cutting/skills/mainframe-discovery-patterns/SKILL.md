---
name: mainframe-discovery-patterns
description: >
  Recover the structure, data definitions, and integration surface of a
  mainframe-family application during Discovery. Detects NATURAL programs,
  ADABAS DDMs, JCL jobs, CICS transactions, BMS maps, COBOL copybooks,
  Unisys eWorkflow/InfoImage, and EntireX/ETB broker bridges, and emits a
  single schema-validated artifact with file-level traceability for every
  claim. Runs as a Discovery conditional skill when the application's tech
  stack contains any mainframe-family token (natural, adabas, cobol, jcl,
  cics, bms, copybook, tn3270, broker, infoimage, ewf, unisys, mainframe).
  Output artifact: mainframe-discovery.json conforming to
  schemas/discovery/mainframe-discovery.schema.json. Triggers on mainframe
  discovery, NATURAL/ADABAS discovery, JCL discovery, CICS/BMS discovery,
  copybook analysis, Unisys eWorkflow discovery, or
  @mainframe-discovery-patterns mentions.
agent: opus
allowed-tools:
  - Read
  - Write
  - Grep
  - Bash
---

# mainframe-discovery-patterns

## Purpose
Close the ATLAS-P0-2 gap: without this skill, a NATURAL/ADABAS/JCL/CICS/
Unisys mock application (for example FAA RMS) sinks to an opaque
`mainframe` token in the catalog entry and every downstream skill — the
legacy-database-archaeologist, the rationalization scorer, the
disposition-recommender — has nothing to reason about. This skill produces
an auditable per-application mainframe fingerprint: which platforms are
present, how much of each, which programs talk to which DDMs, which jobs
orchestrate which steps, which transactions and maps are exposed to
end users, and which integration edges bridge the mainframe to
surrounding systems. Every finding carries a `{file}:{line}` citation so
that Rationalization, Modernization Extract, and the G-DC gate can verify
it rather than trust it.

## When to invoke
Fires automatically during Discovery when the application's `tech_stack`
contains any of these tokens (case-insensitive, normalized by the Phase-1
prescan in `olympus/olympus/fsm/prescan.py`):

    natural  adabas  cobol  jcl  cics  bms  copybook
    tn3270   broker  infoimage  ewf  unisys  mainframe

Also fires on explicit mention: `@mainframe-discovery-patterns`.

## Inputs
- Application source tree (NATURAL, COBOL/PL-I, JCL, BMS, copybooks, config)
- Application catalog entry (per `schemas/discovery/application-catalog-entry.schema.json`)
- Tech fingerprint from `structural-analyzer` / `analyze-application` when
  available
- Pre-scan signal from `scripts/detect_mainframe_stack.py` (the same script
  the Phase-1 prescan can invoke to populate `tech_stack_contains`
  tokens); callers may pass its JSON output verbatim

## Passes

### Pass 1 — Platform detection
Run `scripts/detect_mainframe_stack.py <source>` (or re-use the prescan's
cached output). Populate `platforms[]` with one entry per detected
platform (`natural`, `adabas`, `jcl`, `cobol`, `cics`, `bms`, `copybook`,
`tn3270`, `broker`, `unisys-ewf`, `infoimage`, `tiff`). Record
`file_count`, sample `evidence[]` paths, and confidence:
- `high` — extension match plus content match (e.g. `.cbl` with `EXEC CICS`)
- `medium` — extension-only signal
- `low` — ambiguous filename heuristic (broker/EWF config patterns)

### Pass 2 — Structural analysis
For each detected platform, build the shallow inventory blocks per
`references/natural-patterns.md`, `references/adabas-patterns.md`,
`references/jcl-patterns.md`, `references/cics-bms-patterns.md`, and
`references/copybook-patterns.md`:
- `natural_programs[]` — name, kind (program/subprogram/map/copycode),
  line count, CALLNAT targets
- `adabas_ddms[]` — DDM name, field count, periodic groups, multiple-value
  fields, superdescriptors (parity with
  `legacy-database-archaeologist.adabas_ddms`)
- `jcl_jobs[]` — job name, step count, scheduler, inferred purpose
- `cics_transactions[]` — transaction id, backing program, observed
  CICS verbs
- `copybooks[]` — name, consumers

Deep structural detail (every field in every DDM, every step in every
job) does NOT belong in the artifact — cite it in a finding instead.

### Pass 3 — Data and integration analysis
Trace cross-system edges per `references/integration-bus-patterns.md`:
EntireX/ETB broker calls (`etbclient*`, `entirex*`), Unisys eWorkflow
hand-offs (`iwfeng*`, `ecmengine*`), TN3270 screen-scrape targets, MQ
bridges, file-drop patterns, DB links. Emit one `integration_edges[]`
entry per edge with `kind`, `source`, `target`, and an `evidence`
citation.

### Pass 4 — Findings synthesis
Every platform claim, every inventory entry, and every integration edge
needs at least one finding. Findings follow the standard Olympus shape:

    {
      "id": "MFD-NATURAL-001",
      "platform": "natural",
      "severity": "high",
      "message": "NATURAL program LOGIN contains embedded authorization rule …",
      "file_ref": "src/programs/login.nsp",
      "line_ref": 42,
      "recommendation": "Extract as business rule BR-AUTH-001."
    }

Severity bands:
- `critical` — platform is past vendor support AND on a hot path
- `high` — embedded business logic, cross-app coupling, or missing
  integration contract
- `medium` — deprecated feature still in use, or partial traceability
- `low` — informational, cosmetic, or benign
- `info` — platform presence only, no action needed

## Outputs
- `mainframe-discovery.json` — conforms to
  `schemas/discovery/mainframe-discovery.schema.json`
- Feeds: `legacy-database-archaeologist` (ADABAS DDM parity),
  `dependency-mapper` (integration edges), `catalog-application`
  (tech-stack enrichment), and the G-DC gate.

### Quality rules
- [ ] Every `platforms[]` entry has `file_count >= 1` and at least one
      `evidence[]` path (except `tiff`, which may be count-only).
- [ ] Every `natural_programs[]`, `adabas_ddms[]`, `jcl_jobs[]`,
      `cics_transactions[]`, and `copybooks[]` entry has a `file` field or
      is backed by a finding that cites the source.
- [ ] Every `integration_edges[]` entry has `kind`, `source`, `target`,
      and an `evidence` string.
- [ ] Every `findings[]` entry has `id`, `platform`, `severity`,
      `message`, and `file_ref`; `line_ref` is populated when the finding
      is line-scoped.
- [ ] The artifact validates against
      `schemas/discovery/mainframe-discovery.schema.json` with no
      `additionalProperties` violations.

## Reference material
Deep pattern catalogs live in `references/` so the skill body stays
tight. Load the reference that matches the detected platform(s):

- `references/natural-patterns.md` — NATURAL program/subprogram/map
  patterns, CALLNAT resolution, MU/PE field idioms
- `references/adabas-patterns.md` — ADABAS DDM parsing, file numbers,
  superdescriptors, compression classes
- `references/jcl-patterns.md` — JCL job structure, step types,
  scheduler hints, DD/DISP idioms
- `references/cics-bms-patterns.md` — CICS verbs, BMS map structure,
  transaction-to-program mapping
- `references/copybook-patterns.md` — COBOL copybook scoping, level-88
  conditionals, REDEFINES quirks
- `references/integration-bus-patterns.md` — EntireX/ETB broker,
  Unisys eWorkflow, TN3270, file-drop, MQ bridges

## Handoff summary
When this skill completes, verify:
1. `mainframe-discovery.json` exists next to the catalog entry and
   validates against its schema with zero errors.
2. Every platform with non-zero file count has a corresponding finding
   with at least one file-level citation.
3. Integration edges enumerate both endpoints and reference concrete
   config or source evidence.
4. NATURAL/ADABAS entries are consistent with
   `legacy-database-archaeologist.adabas_ddms` when that skill also runs
   (no duplicate data; the archaeologist's block is authoritative for
   DDM field detail).

Then proceed to: `legacy-database-archaeologist` (if ADABAS or a SQL
engine is present), `legacy-architecture-mapper` (to reconcile module
boundaries with the platform inventory), `dependency-mapper` (to fold
integration edges into the per-app dependency graph), and the G-DC gate
for Discovery-completeness review.
