# ADABAS Discovery Patterns

```yaml
part-of: mainframe-discovery-patterns
scope: database-tier
target-stacks:
  - adabas-v8
  - adabas-v9
  - software-ag-natural (DDM consumer — see natural-patterns.md)
example-systems:
  - faa-cais (Comprehensive Airmen Information System)
  - faa-aadocs (Airman Airworthiness Document Capture System)
sibling-refs:
  - natural-patterns.md  (NATURAL application-tier — do not duplicate)
  - jcl-patterns.md      (batch job control)
  - cics-bms-patterns.md (online screen maps)
  - copybook-patterns.md (COBOL/NATURAL record layouts)
downstream-consumers:
  - legacy-database-archaeologist
  - natural-adabas-to-springboot-generator
  - db-schema-mapper
gate: G-DC (Discovery Completeness)
```

## What ADABAS Is

ADABAS (Adaptable Data Base System, Software AG, 1971→present) is an
**inverted-list** database — not relational, not hierarchical. Records
live in **files** (≈ tables) and are accessed through **descriptors**
(inverted indexes). There is no query language: applications — almost
always **NATURAL** — navigate records through a DDM using `FIND BY`,
`READ LOGICAL BY`, and `HISTOGRAM` keyed to descriptors.

Key facts Discovery must internalize:

- Files have **no declared primary key**. Every record has an **ISN**
  (Internal Sequence Number), but ISNs are physical pointers that change
  after reorg (`ADAORD`) — never persist one.
- **No foreign-key metadata.** Cross-file relationships live in NATURAL
  source code, not the database.
- A single record can contain **lists** inside it (MU / PE). Relational
  flatteners break if they assume 1:1 field-to-column mapping.
- Indexes are **descriptors**; descriptor presence changes query shape.
  `FIND BY FTN-KEY` only works if `FTN-KEY` is a descriptor.
- The binary is **not human-readable**. Discovery works from DDM exports,
  `ADAREP` statistics dumps, and compressed unloads (`ADACMP`).

## 1. Detection Signals

Fire this reference pack when any of the following appear during Pass 1:

- File extension `.nsd` (NATURAL Source for a DDM) — strongest signal.
- Directory names: `DDMs/`, `ddm/`, `objects/DDM/`, `FNAT/<lib>/DDMs/`.
- Names referencing `SYSDDM`, `SYSAOS`, `SYSADA`, `SYSAVI`, `SYSAUDIT`.
- Strings: `ADABAS`, `ADARUN`, `DBID=`, `FNR=`, `FDT=`, `ADADBS`,
  `ADAREP`, `ADACMP`, `ADALOD`, `ADAORD`.
- JCL steps invoking `ADARUN`, `ADAREP`, `ADACMP`, `ADALOD`, `ADAORD`,
  `ADABCK`, `ADAINV`, `ADAULD`, `ADARES`, `ADASEL`.
- NATURAL source with `VIEW OF <ddm-name>` inside `DEFINE DATA`.
- Connection params shaped `DB=<n>,FILE=<n>` or `DBID=<n>,FNR=<n>`.
- Copybooks with `OCCURS DEPENDING ON` feeding an MU/PE flattener.

Two or more signals → treat the app as ADABAS-backed and activate the
full `mainframe-discovery-patterns` bundle.

## 2. DDM Anatomy

A **DDM** (Data Definition Module) is the logical schema view over one
ADABAS file. One file can have multiple DDMs (different projections);
one DDM targets exactly one file. DDMs are exported from `SYSDDM` with
`LIST DDM <name>` and land in the repo as `.nsd` files.

### Header
- DDM name (e.g. `AA-BASIC`), DBID + FNR (physical address), owner /
  library, default characterset (EBCDIC on z/OS, ASCII on open-systems).

### Field table (body)
Each row: **Level**, **Short name**, **Long name**, **Length**,
**Format**, **Descriptor flag**, **Options**.

- **Level** — `1` top-level / group header, `2` child, `3` grandchild.
- **Short name** — 2-char ADABAS name (`AA`, `AB`); on-disk only,
  NATURAL never uses it.
- **Long name** — NATURAL-visible (`FIRST-NAME`, `FTN-KEY`).
- **Length** — bytes (alpha) or digits (numeric/packed).
- **Descriptor flag** — blank (not indexed), `D`, `U` (unique), `N`.
- **Options** — `NU` (null-suppressed), `FI` (fixed), `DE` (descriptor
  explicit), `LA` (long alpha).

### Format codes

| Code | Meaning          | Typical length | Notes                                  |
|------|------------------|---------------:|----------------------------------------|
| `A`  | Alphanumeric     | 1–253 (LA=16K) | Space-padded, not null-terminated      |
| `B`  | Binary           | 1–126          | Bit-level; common for flags            |
| `N`  | Unpacked numeric | 1–29 digits    | One digit per byte                     |
| `P`  | Packed decimal   | 1–15 bytes     | BCD; 2 digits/byte + sign nibble       |
| `U`  | Unpacked numeric | 1–29 digits    | Like `N` but treated as unsigned       |
| `F`  | Fixed floating   | 4 or 8 bytes   | Rare; IEEE on open-systems             |
| `G`  | Floating point   | 4 or 8 bytes   | Alias for `F` on some versions         |
| `L`  | Logical          | 1 byte         | Boolean                                |
| `T`  | Time             | 7 bytes        | Internal Software AG timestamp         |
| `D`  | Date             | 4 bytes        | Internal Software AG date              |
| `W`  | Wide alphanumeric| 2–13760 bytes  | UTF-16 / double-byte                   |

Length-and-format appear together, e.g. `8 A`, `6 P`, `18 N`, `60 A LA`.

### Sample DDM snippet

```
DDM NAME: AA-BASIC
DBID:      142      FNR: 17      DEFAULT CHARSET: UTF-8
----- -----------------------------------------------------------------
T L  Short   Long name                Length  Format  Desc  Options
----- -----------------------------------------------------------------
  1  AA      AA-BASIC                                                  (group)
  2  AB      FTN-KEY                     10    A       D    NU
  2  AC      LAST-NAME                   40    A       D    NU
  2  AD      FIRST-NAME                  40    A            NU
  2  AE      MIDDLE-NAME                 20    A            NU
  2  AF      DATE-OF-BIRTH                4    D            NU
  2  AG      RESIDENTIAL-ADDR                                          (PE)
  3  AH        STREET                    60    A            NU
  3  AI        CITY                      30    A            NU
  3  AJ        STATE                      2    A            NU
  3  AK        POSTAL-CODE               10    A            NU
  2  AM      PILOT-CERT-NUMBER           10    A       MU   NU
----- -----------------------------------------------------------------
SUPERDESCRIPTORS
  NAME-DOB    = LAST-NAME(1-40) + FIRST-NAME(1-40) + DATE-OF-BIRTH
SUBDESCRIPTORS
  LAST-NAME-3 = LAST-NAME(1-3)
```

Read that as: an airman master record keyed by FTN (FAA Tracking Number),
with a name-plus-DOB composite index, a 3-char last-name partial index, a
repeating address block (PE), and up to N pilot certificate numbers per
record (MU).

## 3. Indexes & Descriptors

Indexing is the single biggest ADABAS-specific concept. Every descriptor
type changes what NATURAL statements will work against the file.

| Descriptor type  | Flag  | What it indexes                       | NATURAL access pattern            |
|------------------|-------|---------------------------------------|-----------------------------------|
| Descriptor       | `D`   | Single field, exact value             | `FIND BY <field> = value`         |
| Unique descriptor| `U`   | Single field, one record per value    | `FIND UNIQUE`                     |
| Subdescriptor    | `SB`  | Partial field range, e.g. chars 1–3   | `FIND BY <subd> = 'SMI'`          |
| Superdescriptor  | `SU`  | Concatenation of 2+ fields            | `FIND BY <super> = value`         |
| Hyperdescriptor  | `HY`  | Computed by user exit (NATURAL code)  | `FIND BY <hyper> = value`         |
| Phonetic desc.   | `PH`  | Soundex-style equivalence             | `FIND BY <ph> = 'JONZ'`           |
| Inverted desc.   | (any) | Inverse lookup from descriptor value  | Fast reverse-search (e.g. FTN→ISN)|
| Non-descriptor   | blank | **NOT indexed** — full file scan only | Only reachable via `READ PHYSICAL`|

### Migration implications

| Descriptor → relational | Strategy                                                                                              |
|-------------------------|-------------------------------------------------------------------------------------------------------|
| `D`                     | `CREATE INDEX` on column                                                                              |
| `U`                     | `CREATE UNIQUE INDEX` or inline `UNIQUE` constraint                                                   |
| `SB`                    | Functional/expression index on substring: `CREATE INDEX ... ON t (substr(col,1,3))`                   |
| `SU`                    | Composite index on concatenated columns, **or** generated column `GENERATED ALWAYS AS (a||b) STORED` |
| `HY`                    | Generated column + trigger; review user-exit logic before translating                                 |
| `PH`                    | PostgreSQL `pg_trgm` / `fuzzystrmatch` / `soundex`; test recall drift                                |
| Inverted (FTN-KEY style)| Plain B-tree — relational engines already invert all B-trees                                          |
| Non-descriptor          | No action; warn if NATURAL code scans it (`READ PHYSICAL` = full-table-scan pattern)                  |

Every superdescriptor and hyperdescriptor **must** be named in the
inventory. They encode query patterns NATURAL relies on; dropping one
makes the target 100× slower.

## 4. MU / PE — The Migration Pain Point

**MU (multiple-value field)**: a scalar that repeats N times inside one
record. Example: `PILOT-CERT-NUMBER(A10) MU` — one airman carries up to
N certificate numbers in one record.

**PE (periodic group)**: a group of correlated fields repeating N times.
Example: `RESIDENTIAL-ADDR` group with `STREET/CITY/STATE/POSTAL-CODE`,
repeated once per address variant.

Records can have **MU inside PE** (two levels of nesting). Legacy ADABAS
tops at 191 occurrences; v8+ supports up to 65,534.

### Why relational migration breaks
- No 1:1 column mapping — one ADABAS field becomes a child table.
- Occurrence index matters: NATURAL reads `FIELD(3)` — order must be
  preserved.
- Occurrence count varies per record; `NU`-suppressed occurrences are
  not stored, so reconstruction must not introduce empty rows.
- MU-inside-PE requires a grandchild table with composite FK.

### Recommended relational shape
- MU → junction table `(parent_id, occurrence_index, value)`; secondary
  index on `value` if the source had a descriptor on the MU field.
- PE → child entity, composite PK `(parent_id, occurrence_index)`, all
  PE fields as columns.
- PE-containing-MU → grandchild with composite FK to the PE child's PK.

Full JPA materialization lives in
`natural-adabas-to-springboot-generator/references/adabas-to-postgres-mapping.md`.
Discovery only enumerates counts and fields; shape is decided later.

### Data-loss risks
- **Silent truncation** — scripts that read the first N occurrences drop
  records with more. FAA 40-year flying histories hit this.
- **Order loss** — `SELECT` without `ORDER BY occurrence_index`
  non-deterministic; "primary address first" logic breaks.
- **Null-occurrence collapse** — renumbering NU-suppressed occurrences
  diverges historic references.
- **Count-limit spillover** — when max-occurrences hits, NATURAL apps
  open a continuation record (same key, different ISN). Detect it.

## 5. Field Naming Conventions

ADABAS short names are 2 characters (26×36 = 936 possible names per
file). To cope, shops use a **prefix convention** on long names:

- `AA-*` for AirmAn (CAIS/AADOCS main record)
- `AB-*` for Airman activity (audit log)
- `CT-*` for CerTificate
- `ME-*` for MEdical
- `EN-*` for ENforcement
- `AC-*` for AirCraft

The prefix clusters related fields. Cross-DDM collisions — two DDMs using
`AA-` for different domains — are a strong signal of **reuse across
applications** that Discovery must surface (it means the field names
leaked across app boundaries, and migrations must disambiguate).

Finding to emit: `field-prefix-reuse: prefix=AA, ddms=[AA-BASIC, AA-CERT,
AA-ACTIVITY, AC-REGISTRY]` — flag when the same prefix appears in DDMs
whose DBID/FNR pairs differ.

## 6. Batch Utilities

ADABAS batch is driven by standalone utilities — each typically invoked
from JCL. Discovery must catalog every JCL step that calls one, because
the utility calls are the real "ETL" of the legacy system.

| Utility  | What it does                                          | Discovery value                                    |
|----------|-------------------------------------------------------|----------------------------------------------------|
| `ADARUN` | Runtime driver that loads ADABAS nucleus parameters   | Every ADABAS job starts with `ADARUN` — find them  |
| `ADAREP` | Dumps database/file statistics                        | **Canonical source** for record counts, FDT, sizing|
| `ADACMP` | Compresses raw data into ADABAS load format           | Marks bulk-unload pipelines; size hint             |
| `ADALOD` | Loads compressed data into a file                     | Initial-load / full-refresh signal                 |
| `ADAORD` | Reorganizes file (reclaims space, reassigns ISNs)     | Touches ISNs — reveals apps that assume ISN stable |
| `ADAINV` | Creates / rebuilds inverted lists (descriptors)       | Triggered on descriptor changes; use as change log |
| `ADABCK` | Full file backup                                      | Retention/recovery strategy                        |
| `ADAULD` | Unloads records to flat file                          | Feeds downstream systems; latent integration       |
| `ADASEL` | Selective unload based on predicate                   | ETL to reporting DB; reveals reporting integrations|
| `ADARES` | Restore from backup                                   | DR posture                                         |
| `ADADBS` | Database administration (add/delete file, users)      | Schema-change history                              |

Discovery rule: for every batch-job file (JCL/SCL/shell), record the
utility, DBID/FNR touched, and `{repo}:{file}:{line}`. `ADAREP` output
is the best source of **record-count and file-size truth** — prefer it
over guessing from DDM field counts.

## 7. End-of-Life / Migration Risk Signals

Flag as tier T1 (migration-risk-high) when Discovery sees any of:

- **ADABAS v8** or earlier nucleus (lacks many descriptor-rebuild
  optimizations; sunset supported but under Software AG extended-support
  pricing). Detect via `ADARUN` parameters or `ADAREP` header.
- Use of **deprecated field types** — `LB` (pre-v8 long binary, replaced
  by `LA`), legacy phonetic descriptors on pre-Unicode characterset.
- File size **> 500 MB compressed** (approx. 5 GB uncompressed) — ADABAS
  batch utilities bounded by single-threaded I/O; reorg/backup windows
  exceed nightly batch windows at that size.
- **MU field occurrence count > 191** — old `MC` short-form occurrence
  counters overflow; modern alternatives (Postgres arrays, JSONB) are
  fine, but Oracle `VARRAY` caps at 32,767, MSSQL `sparse columns` cap
  lower still.
- **Periodic group with > 10 fields and > 50 occurrences** — the
  child-table row count explodes; plan indexed-organized strategies
  ahead of time.
- **Hyperdescriptor** with user-exit NATURAL code — the index logic lives
  *outside the DDM*; discovery must trace the exit and reproduce its
  semantics or the target index will return different row sets.
- **ETID + HOLD-heavy workloads** — see §10; high-contention locking
  patterns rarely translate cleanly to MVCC databases.
- **No `ADAREP` output available** — statistics are the only honest
  sizing source; without them, sizing estimates are guesses.
- **FDT (Field Description Table) size approaching 32KB** — ADABAS caps
  per-file FDT at ~32KB; wide records (>400 fields) are near the ceiling.
- **Cross-DDM name collisions on same DBID** — implies DDMs are stale /
  out of sync with the live FDT.

## 8. Cross-DDM Integrity Patterns

ADABAS has **no referential integrity** — no FKs, no cascade, no declared
relationships. Cross-file integrity lives in NATURAL code (or nowhere).

Discovery tactics:

1. **Name correlation** — for every `*-KEY` or `*-ID` in one DDM, search
   other DDMs for the same long name. Matches are candidate FKs.
2. **Prefix correlation** — two DDMs sharing a 2-char prefix (`AA-`),
   each with `FTN-KEY`, are almost certainly parent/child.
3. **NATURAL cross-reference** — a program issuing `FIND ... IN DDM-A`
   then `FIND ... IN DDM-B WITH KEY = <A's value>` enforces a runtime FK.
4. **MU-field-of-IDs** — an MU field named `*-ID`/`*-KEY` points at
   another file; target DDM usually has it as unique descriptor.

Emit: `from_ddm:from_field -> to_ddm:to_field | evidence=<source>` at
tier T2 (needs human confirmation). Do **not** treat inferred FKs as
ground truth in Extract — route to the data steward for review.

## 9. Audit / Activity-Log Patterns

Many FAA ADABAS files are **append-only audit logs**: records are
`STORE`d and never `UPDATE`d/`DELETE`d. The airman activity log
(`AA-ACTIVITY`-style DDM) is the canonical example — every cert
issuance, suspension, medical update is a new row. Retention is driven
by **49 USC §44703** (airman cert records must be preserved).

### Recognition patterns

- DDM name ending `-ACTIVITY`, `-LOG`, `-HISTORY`, `-AUDIT`, `-JOURNAL`.
- PE group with a timestamp descriptor as the first field.
- NATURAL code issues `STORE` but never `UPDATE` or `DELETE` against
  this DDM.
- Batch jobs that `ADAULD` the file nightly for reporting, never
  `ADASEL` + `ADALOD` for refresh.
- Record count that grows monotonically (check `ADAREP` over time if
  available).

### Migration implications

- **Treat as event-sourced**. Target design should use append-only table,
  temporal/bitemporal model, or Kafka-backed event log — not a CRUD
  table.
- **Retention requirements** — 49 USC §44703 for airman certs, 14 CFR
  Part 61 for flight reviews, 49 CFR Part 830 for accident reports. Data
  deletion is a compliance violation; mark the finding tier T1.
- **PII handling** — audit logs often contain PII (names, DOBs, SSN
  partial) plus enforcement actions. Route to
  `identity-landscape-analyzer` and the privacy gate.

## 10. Concurrency and Locking

ADABAS has **record-level locking** via `HOLD`. Transactions are bracketed
by **ET** (End Transaction = commit) and **BT** (Back Transaction =
rollback). A session carries an **ETID** — transaction identifier.

| Construct                      | Meaning                                               |
|--------------------------------|-------------------------------------------------------|
| `FIND ... WITH HOLD`           | Read with intent-to-update; record-level exclusive    |
| `GET ... WITH HOLD`            | Read-by-ISN with hold                                 |
| `STORE`                        | Insert new record                                     |
| `UPDATE`                       | Rewrite held record                                   |
| `DELETE`                       | Remove held record                                    |
| `ET`                           | End transaction — commit + release all holds          |
| `BT`                           | Back transaction — rollback + release all holds       |
| `RELEASE`                      | Release a specific hold without commit                |
| `ETID = '<8-char>'`            | Transaction identifier; persists across logins        |
| `MAXHOLDQ` runtime param       | Max concurrent holds per session                      |
| `TT`/`TNA`/`TNAE` params       | Transaction timeout thresholds                        |

### Patterns to detect

- **Read-then-update without HOLD** — NATURAL reads, computes, then
  `UPDATE`s. Without `WITH HOLD`, another session can UPDATE the same
  record mid-flight — lost-update race. Tier T2.
- **Long-held records** — `FIND WITH HOLD` then long `CALLNAT` chain
  before `ET`. Serializes the file; tier T1 for online workloads.
- **Cross-file deadlock corridor** — programs that `FIND WITH HOLD`
  DDM-A-then-B while another does B-then-A.
- **ETID reuse across job streams** — shared ETIDs let jobs commit each
  other's transactions (no per-job isolation). Tier T1.
- **No BT in error paths** — `FIND WITH HOLD` + error-exit without `BT`
  holds records until session timeout.

## 11. Discovery Findings Checklist

The skill must emit at least these findings for every ADABAS-backed
application. Missing any of them halts G-DC.

1. Enumerate every DDM file (`.nsd` or `SYSDDM` export) with
   `{repo}:{file}:{line}` citation.
2. For each DDM, record `(DBID, FNR)` and group DDMs that share the
   address pair (multiple DDMs over one file).
3. Count scalar fields per DDM (exclude group headers).
4. Count MU fields per DDM.
5. Count PE groups per DDM; record depth (PE, PE-containing-MU,
   PE-containing-group).
6. Count descriptors per file, broken down by type: `D`, `U`, `SB`, `SU`,
   `HY`, `PH`, inverted.
7. Name every superdescriptor with its component fields
   (e.g. `NAME-DOB = LAST-NAME + FIRST-NAME + DATE-OF-BIRTH`).
8. Name every hyperdescriptor and cite the user-exit NATURAL subprogram
   that computes it.
9. Flag MU occurrence-count > 191 (legacy `MC` overflow) and PE
   occurrence-count > 50.
10. Flag every file with compressed size > 500 MB (from `ADAREP`).
11. List every NATURAL `VIEW OF <ddm>` consumer with
    `{repo}:{file}:{line}` citation — cross-reference DDM → consumer.
12. List every JCL / batch invocation of ADABAS utilities
    (`ADAREP`, `ADACMP`, `ADALOD`, `ADAORD`, `ADABCK`, `ADAULD`,
    `ADASEL`, `ADAINV`) with file/step citation.
13. Infer cross-DDM FKs by long-name matching; emit candidate list tier
    T2 (review-required).
14. Identify append-only audit files (name suffix, STORE-only NATURAL
    access); flag retention-regulated (cite regulation: §44703, Part 61,
    Part 830).
15. Enumerate every `FIND ... WITH HOLD` site; classify as short-hold
    (single `UPDATE` + `ET`) vs. long-hold (with intervening calls).
16. Enumerate `ETID` assignments (literal strings, config values); flag
    any shared across multiple job streams.
17. Record ADABAS nucleus version from `ADARUN` parameters or `ADAREP`
    header; flag < v9 as T1.
18. Record database and national character set from the DDM header; flag
    non-Unicode (EBCDIC-only, single-byte ASCII) as T1.
19. Emit the target-database mapping plan per §3 and hand off to
    `db-schema-mapper` + `natural-adabas-to-springboot-generator`.
20. Attach the ADABAS findings block (with tier classifications) to the
    Discovery bundle; G-DC cannot pass until present.

## 12. Handoff

- **natural-patterns.md** (sibling) — owns `VIEW OF`, `FIND`/`READ
  LOGICAL`, `CALLNAT` graph. Consume DDM inventory from here; don't
  re-enumerate DDMs there.
- **jcl-patterns.md** (sibling) — references the ADABAS utility calls
  cataloged in §6.
- **copybook-patterns.md** (sibling) — a DDM is not a copybook.
- **legacy-database-archaeologist** (downstream) — consumes DDM +
  descriptor catalog for the neutral schema map.
- **natural-adabas-to-springboot-generator** (downstream) — consumes
  MU/PE counts, superdescriptors, and inferred FKs to generate JPA +
  Flyway.

## 13. Anti-Patterns (Do Not Emit)

- Do **not** label ADABAS as "hierarchical" — it is inverted-list. IMS
  is hierarchical.
- Do **not** treat ISN as a primary key — it is a physical pointer.
- Do **not** assume MU/PE flatten to Postgres arrays without review;
  arrays lose the occurrence-index semantics NATURAL relies on.
- Do **not** omit non-descriptor fields from the inventory — Extract
  needs them to see non-indexed access paths.
- Do **not** treat a zero-field DDM as empty — almost always `SYSDDM`
  truncated at terminal width; re-export with `LS=250`.
