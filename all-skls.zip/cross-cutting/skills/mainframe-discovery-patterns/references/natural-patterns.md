<!--
part-of: mainframe-discovery-patterns
doc: natural-patterns
target-stacks: [natural-4gl, software-ag-natural, adabas, ibm-zos, 3270-bms]
olympus-version: 0.4.x
applies-to-assembly-lines: [discovery]
audience: discovery-agent
-->

# NATURAL (Software AG) — Discovery Patterns

Reference material for Discovery agents when they detect NATURAL source code. NATURAL is a 4GL from Software AG, typically deployed on IBM z/OS against ADABAS databases, with 3270 terminal screens rendered through NATURAL "maps". Code tends to be 1980s-2000s vintage, heavily stateful, and wired together through Global Data Areas (GDAs) rather than parameter passing.

This doc is scoped to **identification, structure, and finding extraction**. Migration/modernization recommendations belong elsewhere.

## Extension-to-artifact map

| Extension | Artifact type                 | Notes                                                          |
|-----------|-------------------------------|----------------------------------------------------------------|
| `.nsn`    | NATURAL program (online)      | Older variant; entry point invoked by a map or menu            |
| `.nsp`    | NATURAL program (online)      | Most common program extension in modern Natural ONE projects   |
| `.nss`    | NATURAL subprogram            | Called via `CALLNAT`; has own `DEFINE DATA` + parameters       |
| `.nsr`    | NATURAL subroutine (external) | Called via `PERFORM`; shares caller's data area                |
| `.nsc`    | NATURAL copycode              | `INCLUDE` source, dropped into the caller at compile           |
| `.nsm`    | NATURAL map (screen)          | 3270 BMS-like screen definition used by `INPUT USING MAP`      |
| `.nsd`    | NATURAL DDM (ADABAS view)     | Data Definition Module — schema for one ADABAS file            |
| `.nsg`    | GDA (Global Data Area)        | Shared mutable state across every program that `GLOBAL USING`s it |
| `.nsl`    | LDA (Local Data Area)         | Named local block, imported with `LOCAL USING`                 |
| `.nsa`    | PDA (Parameter Data Area)     | Named parameter block, imported with `PARAMETER USING`         |
| `.nsh`    | NATURAL helproutine           | Field-level help, invoked from map PF-key                      |
| `.nst`    | NATURAL text object           | External message text (for `SEND MESSAGE` / `REINPUT`)         |

## 1. Detection signals

### File-system signals
- Directory layout commonly seen: `programs/`, `subprograms/`, `subroutines/`, `maps/`, `ddms/`, `gda/` (or `globals/`), `lda/`, `pda/`, `copycode/`, `helproutines/`, `text/`.
- Library-style naming: `AAB*`, `AAM*`, `N-*`, all-caps 8-char program names (mainframe 8.3 legacy).
- NaturalONE projects carry a `.natural` metadata file and a `Natural-Libraries` root.

### Top-of-file signals
- First 3-5 lines typically contain a Software AG source header:
  ```
  * >Natural Source Header 000000
  * :Mode S
  * :CP ISO8859-1
  * <Natural Source Header
  ```
- Lines beginning with `*` are comments. NATURAL is **case-insensitive** but almost always upper-case.
- DDMs start with `DB: nnn   FILE: nnn  - <NAME>` and `TYPE: ADABAS`.

### Keyword signals (high-confidence NATURAL)
- `DEFINE DATA` ... `END-DEFINE` (opens every compilation unit)
- `GLOBAL USING <GDA-name>`, `LOCAL USING <LDA-name>`, `PARAMETER USING <PDA-name>`
- `VIEW OF <DDM-name>`
- `CALLNAT`, `FETCH`, `PERFORM`
- `READ`, `FIND`, `HISTOGRAM`, `GET`, `STORE`, `UPDATE`, `DELETE`, `END-TRANSACTION`, `BACKOUT TRANSACTION`
- `INPUT USING MAP`, `REINPUT`, `SEND MESSAGE`
- `ON ERROR`, `ESCAPE ROUTINE`, `ESCAPE TOP`, `IGNORE`
- `FORMAT PS=` / `FORMAT LS=` (report formatting directives)

## 2. Program structure

Every compilation unit (program, subprogram, subroutine) has the same top-level shape:

```
DEFINE DATA
  GLOBAL USING <GDA>             *  shared mutable state
  PARAMETER                      *  inputs/outputs if subprogram
    1 P-FOO   (A 10) BY VALUE
    1 P-RC    (I 2)  BY VALUE RESULT
  LOCAL USING <LDA>              *  reusable local block (optional)
  LOCAL
    1 #VIEW   VIEW OF <DDM>
      2 FIELD-A
      2 FIELD-B
    1 #WORK   (A 40)
END-DEFINE
*
*   ---- procedure section ----
<statements>
*
END
```

Key conventions:
- **Level numbers** (`1`, `2`, `3`) define group/subgroup hierarchy — similar to COBOL levels.
- **Leading `#`** marks a work variable; **leading `P-`** by convention marks a parameter; **leading `+`** marks AIV (application-independent variable, session-scoped).
- `BY VALUE` vs `BY VALUE RESULT` vs `BY REFERENCE` — `RESULT`/reference means the caller sees mutations.
- Data types: `A n` alpha, `N n[,m]` numeric, `P n[,m]` packed, `I n` integer (1/2/4), `B n` binary, `D` date, `T` time, `L` logical.
- Procedure section has no explicit `BEGIN` — statements follow `END-DEFINE` until `END`.
- Control flow: `IF … THEN … ELSE … END-IF`, `DECIDE ON FIRST VALUE OF`, `FOR … END-FOR`, `REPEAT … UNTIL … END-REPEAT`.
- Arithmetic: `COMPUTE X = Y + Z`, `ADD`, `SUBTRACT`, `MULTIPLY`, `DIVIDE`, `MOVE`.
- Output: `WRITE`, `DISPLAY`, `PRINT` for reports; `SEND MESSAGE` for operator console.

## 3. Inter-program calls

| Construct              | Target               | Data sharing                                       | Call-graph edge type    |
|------------------------|----------------------|----------------------------------------------------|-------------------------|
| `CALLNAT 'NAME' p1 p2` | Subprogram (`.nss`)  | Explicit parameters + GDAs                         | **strong, typed**       |
| `PERFORM NAME`         | Subroutine (inline or external `.nsr`) | Shares caller's data area entirely | **opaque, shared state**|
| `FETCH 'NAME'`         | Another program      | No return; resets stack (transfer of control)      | **terminal, not a call**|
| `FETCH RETURN 'NAME'`  | Another program      | Returns after end; GDA preserved                   | **strong, untyped**     |
| `INPUT USING MAP 'M'`  | Map (`.nsm`)         | Map fields bound to program variables              | **UI edge**             |
| `CALL 'MODULE'`        | External 3GL (COBOL / Assembler / C) | Linked at exec; platform-dependent   | **native boundary**     |
| `STACK TOP COMMAND`    | Next program via session stack | Session-scoped; fragile               | **implicit, investigate**|

Discovery implications:
- Build the call graph from every `CALLNAT 'literal'` and `FETCH RETURN 'literal'`. Watch for variable-driven calls (`CALLNAT #PGM-NAME`) — those require data-flow analysis to resolve.
- `PERFORM` to an external `.nsr` is an edge but carries no interface; treat as "side-effecting".
- `FETCH` (without `RETURN`) is a terminal transition — it's a navigation, not a subroutine call. Model it like a URL redirect.
- Map-to-program edges are the UI-adjacent navigation graph (3270 screen flow).

## 4. Data access patterns (ADABAS via DDMs)

NATURAL reads ADABAS through **views** declared in `DEFINE DATA`:

```
1 #BAS  VIEW OF AA-BASIC
  2 FTN
  2 LAST-NAME
  2 MAIL-ADDR-1
```

The DDM (`.nsd`) maps 2-character ADABAS short names (`FT`, `LN`) to long names (`FTN`, `LAST-NAME`) and carries the DBID/FNR pair (`DB: 042   FILE: 001`).

### Read / search
- `READ #BAS LOGICAL BY FTN-KEY = P-FTN` — descriptor-ordered read
- `READ #BAS PHYSICAL` — file-order scan (typically batch only)
- `READ #BAS BY ISN` — internal sequence number
- `FIND #BAS WITH FTN = P-FTN` — search; may return multiple records
- `FIND FIRST #BAS WITH ...` — one record; sets `*COUNTER`
- `FIND NUMBER #BAS WITH ...` — count only
- `HISTOGRAM #BAS FOR MEDICAL-CLASS` — descriptor value distribution
- `GET #BAS *ISN(READ01.)` — fetch by ISN within a loop

### Write
- `STORE #BAS` inside a processing loop or after `RESET`
- `UPDATE #BAS` must be inside a `READ`/`FIND`/`GET` loop that holds the ISN
- `DELETE #BAS` — same rule as UPDATE
- `END TRANSACTION [<restart-data>]` commits; `BACKOUT TRANSACTION` rolls back
- `END OF TRANSACTION` is a *statement*, not a block terminator

### Loop terminators
- `END-READ`, `END-FIND`, `END-FOR`, `END-REPEAT`, `END-WORK`
- `ESCAPE BOTTOM` exits the loop normally; `ESCAPE ROUTINE` exits the enclosing routine; `ESCAPE TOP` skips to next iteration.

### What to capture
- `<program>` reads / writes `<DDM>` with which descriptors.
- Cross-reference DDM → ADABAS FNR/DBID from the `.nsd` header (useful for DB-footprint inventories).
- Any `UPDATE`/`STORE`/`DELETE` outside a guarded section is a candidate hot spot.

## 5. Globals / GDAs

GDAs (`.nsg`) are declared once and imported by every program that wants the state:

```
DEFINE DATA
  GLOBAL USING G-EXAMINER
END-DEFINE
```

Typical GDA content on an online system:
- `EXAMINER-USER-ID`, `EXAMINER-ROLE`, `EXAMINER-TERMINAL` — set once at logon
- `LAST-KEY-PRESSED`, `LAST-MAP`, `LAST-FTN` — UI scratchpad carried between steps
- Feature flags, environment indicators, sometimes transient buffers

Why Discovery should care:
- **Any program in the GDA's link set can mutate any field.** There is no encapsulation boundary.
- Authorization logic that reads `EXAMINER-ROLE` is scattered — a role rename in a modern rewrite touches every program.
- GDA fields are implicit inputs/outputs to every subprogram; parameter signatures lie about the actual contract.
- Defeats DI in a modern port: you cannot inject a "current user" service without first decomposing the GDA.

Extraction tasks:
- List every field in every GDA.
- For each field, enumerate readers and writers.
- Flag "god GDAs" (>20 fields, >50 programs linking it).

## 6. Error handling

NATURAL has four overlapping error mechanisms; all four are common in legacy code:

1. **Return codes** — convention, not language. Typical pattern is a `P-RC` parameter (`0` OK, `4` warning, `8`/`12`/`16`/`20` error). Callers branch on it.
2. **`ON ERROR` block** — a single program-scoped handler. Fires on un-handled runtime error (NAT nnnn).
   ```
   ON ERROR
     WRITE 'ERROR' *ERROR-NR 'AT LINE' *ERROR-LINE
     BACKOUT TRANSACTION
     TERMINATE 99
   END-ERROR
   ```
   Anti-pattern: `ON ERROR ... IGNORE END-ERROR` — swallows NAT errors, including ADABAS response codes.
3. **`REINPUT`** — re-prompts an `INPUT USING MAP` screen with a message; optionally marks fields in error.
4. **Retry queues** — application-level idiom. When a downstream service (Finalist address standardization, external mainframe, etc.) is unreachable, the program writes a work record to a "queue" ADABAS file (often named `IA-ADD`, `IA-UPD`, `OUT-Q`, etc.) for an overnight batch to re-drive. Shape:
   ```
   IF #FIN-RC NE 0
     CALLNAT 'N-QADD01' #QUEUE-REC     /* queue it */
     MOVE 4 TO P-RC                     /* caller: warning, not error */
     ESCAPE ROUTINE
   END-IF
   ```
   This is *not* a language feature — it is a workaround for unreliable synchronous integrations and needs to be surfaced as a modernization constraint.

`*ERROR-NR`, `*ERROR-LINE`, `*ERROR-TA` are system variables populated inside `ON ERROR`.

## 7. Screen-map integration

`.nsm` files are BMS-style definitions of a 3270 screen:
- Fixed 24×80 grid; fields positioned by `(row, col)` coordinates.
- Each field has attributes: protected/unprotected, alpha/numeric, intensity, justification, color (if extended attributes enabled).
- Input fields bind to NATURAL variables: `P-FTN`, `#FIRST-NAME`, etc.
- Function keys (`PF1`-`PF24`, `PA1`-`PA3`, `ENTR`, `CLR`) are captured and typically written into a GDA field (often `LAST-KEY-PRESSED` or similar).
- Help is routed by PF-key to a `.nsh` helproutine.

Flow:
```
INPUT USING MAP 'ADDR01M' #FTN #MAIL-ADDR-1 ...
IF *PF-KEY = 'PF3'          /* back */
  ESCAPE ROUTINE
END-IF
IF <validation fails>
  REINPUT 'Invalid ZIP' MARK *MAIL-ZIP
END-IF
```

Discovery tasks:
- Each map is a UI node. Build the screen-flow graph from `INPUT USING MAP` occurrences plus any `FETCH` transitions.
- Field coordinates + attributes are needed if the modernization target requires layout parity (often it doesn't — treat as lossy).
- PF-key bindings encode navigation semantics; lose them and users scream.

## 8. Common anti-patterns (flag as findings)

- **God program** — a `.nsp`/`.nsn` over ~2000 physical lines, branching on a single "activity" or "transaction" code parameter. Usually the app's "main menu dispatcher".
- **Activity-code magic numbers** — string literals like `'0501'`, `'0902'`, `'1700'` scattered across programs with no central table. Often denote audit-log categories written to an `*-ACTIVITY` DDM.
- **Inlined business rules** — date arithmetic, regulatory thresholds, rate tables embedded in `IF/DECIDE` chains rather than extracted to a rules module or data.
- **Direct DDM writes** — `STORE`/`UPDATE`/`DELETE` against a "golden" DDM (e.g., `AA-BASIC`) from a program that is not the official update subprogram, bypassing validation.
- **Hardcoded ADABAS FNR/DBID** — `DB: 042 FILE: 001` is fine in a DDM header but occurs sometimes inside code (`CALL 'ADACALL' ...` blocks in old integrations). Flag and enumerate.
- **ON ERROR IGNORE** — swallowed NAT runtime errors; callers see success when the database rolled back.
- **Uncommitted updates on ESCAPE** — `UPDATE` followed by `ESCAPE ROUTINE` without `END TRANSACTION`. ADABAS holds the lock until session timeout.
- **STACK TOP COMMAND 'xxx'** — implicit control flow through the session stack. Breaks static analysis of the call graph.
- **GDA-as-parameter** — subprograms that read a GDA field to decide behavior instead of accepting a parameter. Caller cannot be unit-tested.
- **FETCH without RETURN** — terminal jump that discards the call stack. Hides dead-code detection and complicates modernization.
- **AIV abuse** — `+VAR` variables used as app-wide session globals beyond their intended scope.
- **Mixed-case DDM short names** inconsistent with long names — a maintenance hazard flagged by any ADABAS DBA review.

## 9. Discovery findings checklist

When Discovery detects NATURAL in an application, produce at least the following findings. Each should cite specific artifacts (`{file}:{line-range}`) and roll up into the `Application` record.

1. **Inventory** — count of `.nsp`/`.nsn`, `.nss`, `.nsr`, `.nsm`, `.nsd`, `.nsg`, `.nsl`, `.nsa`, `.nsc`, `.nsh` files per library.
2. **LOC distribution** — physical and executable lines per program; flag programs > 2000 LOC (god programs) and > 5000 LOC (P0 refactor candidate).
3. **Call graph (`CALLNAT`)** — every edge `(caller, callee, is-literal-name)`; list unresolved dynamic calls separately.
4. **Call graph (`PERFORM`/`FETCH`)** — separate edge sets; mark `FETCH` (no return) as terminal transitions.
5. **Map-to-program edges** — every `INPUT USING MAP 'X'` and `FETCH 'Y'` from within a map handler; produce the 3270 screen-flow graph.
6. **DDM usage matrix** — for each program, which DDMs are referenced via `VIEW OF`, and whether access is read-only, read-write, or delete.
7. **Descriptor usage** — which descriptors (keys) are read or searched; flags candidates for indexing discussions in the target RDBMS.
8. **GDA fan-out** — for each `.nsg`, list (a) fields, (b) programs that `GLOBAL USING` it, (c) programs that write to each field.
9. **Shared LDAs/PDAs** — for each `.nsl`/`.nsa`, list consumers.
10. **Activity-code literals** — extract every string literal in `WRITE ... AA-ACTIVITY` or equivalent logging calls; group by program; produce the activity-code catalog.
11. **Authorization checks** — every `IF EXAMINER-ROLE = '...'` (or equivalent GDA role check); tabulate required roles per program.
12. **Error-handling posture** — per program: has `ON ERROR`? does it `IGNORE`? does it `BACKOUT TRANSACTION`?
13. **Retry-queue writes** — every `STORE` or `CALLNAT` into an `IA-*` / `*-QUEUE` DDM, with the triggering condition summarized.
14. **Hardcoded integers/dates in business logic** — numeric literals inside `IF` / `DECIDE` branches that are not `0`/`1`; candidates for rules extraction.
15. **Transaction boundaries** — count `END TRANSACTION` and `BACKOUT TRANSACTION`; flag programs that `UPDATE`/`STORE` without ever committing in the same unit of work.
16. **External 3GL calls** — every `CALL 'MODULE'` with inferred target language (COBOL/C/Assembler) where detectable.
17. **Dead programs** — `.nsp` not referenced by any `CALLNAT`, `FETCH`, or map transition, and not named in any menu driver.
18. **DDMs with no reader** or **DDMs with no writer** — data-footprint anomalies.
19. **Duplicate subprograms** — subprograms with near-identical signatures/bodies (Levenshtein on normalized source); candidates for consolidation.
20. **Unresolved external references** — `CALLNAT`/`FETCH` to a name with no matching artifact in the source corpus; may indicate a missing library or lost code.
21. **Copycode fan-in** — for each `.nsc`, count includers; high fan-in copycode is an implicit API that needs promotion to a real module.
22. **Map complexity** — per `.nsm`: field count, PF-key count, help routine count; flag maps with > 50 input fields.

## 10. Example snippets

### 10.1 DEFINE DATA with GDA + PDA + view

```
DEFINE DATA
GLOBAL USING G-EXAMINER
PARAMETER
  1 P-FTN    (N 7) BY VALUE
  1 P-RC     (I 2) BY VALUE RESULT
LOCAL
  1 #BAS   VIEW OF AA-BASIC
    2 FTN
    2 MAIL-ADDR-1
    2 LAST-UPDATE-USER
  1 #NOW   (T)
END-DEFINE
```

### 10.2 FIND loop with UPDATE and guarded commit

```
FIND FIRST #BAS WITH FTN = P-FTN
  IF *COUNTER(./) = 0
    MOVE 16 TO P-RC                    /* not found */
    ESCAPE ROUTINE
  END-IF
  MOVE P-MAIL-ADDR-1       TO #BAS.MAIL-ADDR-1
  MOVE *TIMX               TO #NOW
  MOVE EXAMINER-USER-ID    TO #BAS.LAST-UPDATE-USER
  UPDATE #BAS
END-FIND
END TRANSACTION
```

### 10.3 CALLNAT chain with retry queue on downstream failure

```
CALLNAT 'N-FINLST1'
  #BAS.MAIL-ADDR-1 #BAS.MAIL-CITY #BAS.MAIL-STATE #BAS.MAIL-ZIP
  #FIN-OUT-ADDR-1  #FIN-OUT-CITY  #FIN-OUT-STATE  #FIN-OUT-ZIP
  #FIN-RC
*
IF #FIN-RC NE 0
  CALLNAT 'N-QADD01' P-FTN P-MAIL-ADDR-1 P-MAIL-CITY
  MOVE 4 TO P-RC                       /* caller: warning, queued */
  ESCAPE ROUTINE
END-IF
*
CALLNAT 'N-ACTLOG1' P-FTN '0501' EXAMINER-USER-ID
```

### 10.4 INPUT USING MAP with REINPUT guard

```
INPUT USING MAP 'ADDR01M'
  #FTN #MAIL-ADDR-1 #MAIL-CITY #MAIL-STATE #MAIL-ZIP
*
IF *PF-KEY = 'PF3'
  ESCAPE ROUTINE
END-IF
*
IF #MAIL-STATE = ' '
  REINPUT 'State is required' MARK *#MAIL-STATE
END-IF
*
IF #MAIL-ZIP = ' '
  REINPUT 'ZIP is required'   MARK *#MAIL-ZIP
END-IF
```

## 11. Gotchas for downstream agents

- NATURAL source files are typically encoded `ISO8859-1` or EBCDIC export; the header line `* :CP ISO8859-1` tells you. Parsers that assume UTF-8 will mangle variable names containing accented characters (rare) or comment text.
- Line continuation is by **hyphen at end of line** inside a literal, and by implicit newline in most statements — do not line-split mechanically.
- `*`-prefixed lines in the **procedure section** are comments; `*` in the **data section** is also a comment, **but** `*<name>` inside `WRITE`/`INPUT` is a system-variable or field-reference operator (`*COUNTER`, `*LINE-COUNT`, `*PF-KEY`, `*TIMX`, `*ERROR-NR`, etc.). Context matters.
- DDM files are not compiled NATURAL — they are catalog artifacts. Do not try to parse them with the program grammar.
- Labels like `READ01.` on a loop are used by `*ISN(READ01.)`, `ESCAPE BOTTOM (READ01.)`; if stripped, references break.
- Comments often contain the only surviving business-rule documentation. Preserve them in extraction output verbatim.
