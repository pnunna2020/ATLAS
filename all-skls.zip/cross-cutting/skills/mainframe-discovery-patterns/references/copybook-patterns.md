---
part-of: mainframe-discovery-patterns
topic: copybooks
scope: COBOL/PL1/NATURAL record-layout sharing across programs, languages, systems
---

# Copybook Patterns

Copybooks are text files containing COBOL record layouts — typically fixed-width,
hierarchical, with PIC clauses defining data types and lengths. Programs `COPY`
them inline at compile time, so a single `.cpy` can define the schema consumed
by dozens of programs + batch jobs + SQL sprocs + downstream .NET/Java clients.
A field-order change cascades silently across every consumer.

Treat every copybook as a **de facto shared contract** — usually undocumented,
usually load-bearing, usually without a version.

## 1. Detection signals

- **Extensions** — `.cpy` (most common), `.cbl`, `.cob`, `.copy`, sometimes
  extensionless members of a PDS (Partitioned Data Set) on z/OS
- **Inclusion statements**
  - COBOL: `COPY FOO.`, `COPY FOO OF SYSLIB.`, `COPY FOO REPLACING ==X== BY ==Y==.`
  - PL/1: `%INCLUDE FOO;`
  - NATURAL: `INCLUDE COPY FOO` or `INCLUDE FOO`
  - Assembler: `COPY FOO`
- **Check-in patterns**
  - On-repo: `shared-copybooks/`, `copy/`, `cpy/`, `copylibs/`, `include/`
  - On-mainframe: PDS datasets like `SYS1.COPYLIB`, `PROJ.PROD.COPYLIB`,
    `MYAPP.COPYBOOK.SOURCE`
  - Mixed repos: copybooks embedded in COBOL source tree (`src/cobol/copy/`)
    or in a separate Git submodule
- **Secondary signals** — `CPY=` in JCL `SYSLIB` concatenations,
  Endevor/ChangeMan package manifests listing `.cpy` members,
  file-transfer scripts pulling `*.cpy` from a PDS to a build server

## 2. COBOL copybook anatomy

### Level numbers

| Level | Purpose |
|-------|---------|
| `01` | Record root (top of hierarchy) |
| `05`, `10`, `15`, `20` | Group and elementary items; conventional indent step |
| `49` | Used for subordinate fields in variable-length strings (e.g., `PIC X OCCURS ...`) |
| `66` | RENAMES — alternate name for a span of fields (rare, legacy) |
| `77` | Standalone elementary item (no hierarchy) — uncommon in copybooks, common in WORKING-STORAGE |
| `88` | Condition name (named value enumeration attached to parent) |

### Data names

- Uppercase by convention, hyphenated (`CUSTOMER-ID`, `AIRMAN-BIRTH-DATE`)
- Group items have no `PIC` clause; elementary items must have one
- Scoped to the program unless `GLOBAL` is specified (rare)

### PIC clauses — the heart of the layout

| Symbol | Meaning |
|--------|---------|
| `X` | Alphanumeric (1 byte per X in DISPLAY) |
| `A` | Alphabetic (rarely enforced) |
| `9` | Numeric digit |
| `V` | Implied decimal point (zero width) |
| `S` | Sign (zero width on DISPLAY/ZONED; held in sign nibble for COMP-3) |
| `P` | Implied scaling zero |
| `Z` | Zero-suppressed digit (used in edited PICs) |
| `.` `,` `$` `-` `+` `CR` `DB` `/` | Edited numeric symbols (for output/display only) |

### Usage / storage clauses

| Clause | Storage |
|--------|---------|
| `USAGE DISPLAY` (default) | One EBCDIC byte per digit/char |
| `USAGE COMP` / `COMP-4` / `BINARY` | Two's-complement binary: 2, 4, or 8 bytes by digit count |
| `USAGE COMP-1` | Single-precision float (4 bytes, hex float on z/OS) |
| `USAGE COMP-2` | Double-precision float (8 bytes) |
| `USAGE COMP-3` / `PACKED-DECIMAL` | Packed decimal: ceil((digits+1)/2) bytes, sign in low nibble |
| `USAGE COMP-5` | Native binary (endianness per platform) |
| `USAGE POINTER` | Address (rare in copybooks) |

### Other clauses

- `OCCURS n TIMES` — fixed-size array
- `OCCURS m TO n TIMES DEPENDING ON field` — variable array (ODO)
- `REDEFINES previous-field` — overlay same bytes with a new layout
- `FILLER` — padding or unnamed filler bytes
- `VALUE "literal"` / `VALUE ZEROS` / `VALUE SPACES` — initializer (meaningful in
  WORKING-STORAGE; in copybooks defining files it is usually ignored)
- `JUSTIFIED RIGHT` — right-justify content (rare)
- `BLANK WHEN ZERO` — display behavior for numerics

## 3. Data-type encoding — migration reality

- **DISPLAY (EBCDIC character)** — `PIC X(n)` and `PIC 9(n) DISPLAY`. On z/OS,
  bytes are EBCDIC (code page 037 / 1140 most often). Migration must transcode
  to ASCII/UTF-8 and watch for currency/accented chars that differ per codepage.
- **Zoned decimal** — `PIC S9(n)` DISPLAY with sign overpunched into the last
  digit (or leading). EBCDIC zoned decimal: digit `5` is `0xF5`; `-5` becomes
  `0xD5` (overpunch). Sign representations: overpunch, separate sign leading,
  separate sign trailing.
- **Packed decimal (COMP-3)** — 2 digits per byte; last nibble holds sign
  (`C` = +, `D` = -, `F` = unsigned). Common on z/OS for monetary and counters.
  Does NOT round-trip through UTF-8 strings — must be parsed as raw bytes.
- **Binary (COMP / COMP-4)** — big-endian two's-complement on z/OS; watch for
  implicit field width (`PIC 9(4) COMP` = 2 bytes; `PIC 9(9) COMP` = 4 bytes;
  `PIC 9(18) COMP` = 8 bytes).
- **Floating-point (COMP-1 / COMP-2)** — historically IBM hex-float on z/OS,
  now IEEE-754 binary float on modern compilers. Files written under old hex
  float will not read correctly as IEEE.

### Migration cheat sheet

| PIC clause | Bytes | Encoding | Target (Postgres) |
|------------|-------|----------|-------------------|
| `PIC X(20)` | 20 | EBCDIC text | `VARCHAR(20)`; transcode EBCDIC→UTF-8 |
| `PIC 9(5)` DISPLAY | 5 | EBCDIC digits | `INT`; strip padding |
| `PIC S9(9)V99` COMP-3 | 6 | Packed BCD, sign nibble | `DECIMAL(11,2)`; unpack + sign |
| `PIC S9(4) COMP` | 2 | Big-endian int16 | `SMALLINT`; byte-swap if needed |
| `PIC S9(9) COMP` | 4 | Big-endian int32 | `INT` |
| `PIC S9(18) COMP` | 8 | Big-endian int64 | `BIGINT` |
| `PIC X(8)` (date YYYYMMDD) | 8 | EBCDIC text | `DATE`; parse + validate |
| `PIC 9(6) COMP-3` (date) | 4 | Packed date | `DATE`; unpack then parse |

## 4. Level-88 condition names

Level-88s declare **named values** attached to a parent field. They are often
the only place a valid-value enumeration is recorded in the entire codebase —
treat them as authoritative enums during Discovery.

```cobol
05 AIRMAN-STATUS         PIC X(1).
   88 STATUS-ACTIVE      VALUE "A".
   88 STATUS-SUSPENDED   VALUE "S".
   88 STATUS-REVOKED     VALUE "R".
   88 STATUS-DECEASED    VALUE "D".
   88 STATUS-TERMINATED  VALUES "T", "X", "Z".
```

Programs test them as boolean: `IF STATUS-ACTIVE ...`. Extract each 88 as a
`(parent-field, constant-name, literal-values)` triple during Discovery.

## 5. OCCURS DEPENDING ON (ODO)

Variable-length arrays whose extent is controlled by another field:

```cobol
05 ITEM-COUNT            PIC 9(3) COMP.
05 ITEM-TABLE OCCURS 1 TO 500 TIMES
              DEPENDING ON ITEM-COUNT.
   10 ITEM-ID            PIC X(10).
   10 ITEM-AMT           PIC S9(9)V99 COMP-3.
```

- Record length is dynamic; naive extraction that assumes fixed width will
  silently truncate or over-read every record.
- Downstream SQL unload scripts that assume `MAX OCCURS * row-size` padding
  often break when the producer stops padding.
- Variably-located trailing fields require computing their offset from the ODO
  field at read time.
- Watch for **multiple ODOs in one record** (Complex ODO) — offsets compound.

## 6. REDEFINES overlays

Same bytes, different view:

```cobol
05 TRANSACTION-AMT-RAW        PIC X(10).
05 TRANSACTION-AMT REDEFINES TRANSACTION-AMT-RAW.
   10 TA-SIGN                 PIC X.
   10 TA-DOLLARS              PIC 9(7).
   10 TA-CENTS                PIC 9(2).
```

Usage patterns:
- **Type-punning** — read field as text, reinterpret as numeric
- **Discriminated records** — one header byte, different layouts depending on a
  type indicator (classic poor-man's union type)
- **Reserved-for-future-use** — a FILLER block reinterpreted later
- **Version coexistence** — v1 and v2 layouts overlaid on the same record

During Discovery, surface every REDEFINES: its controlling discriminator (if
any), which programs use which overlay, and whether they read or write it.

## 7. Cross-platform reuse

The same `.cpy` can be consumed by:

- **COBOL batch / CICS** — direct `COPY`
- **PL/1 programs** — `%INCLUDE` of PL/1-converted copybook, sometimes a hand-
  translated twin
- **NATURAL programs** — `INCLUDE COPY` (NATURAL treats it as a local data area)
- **C/C++** — translated via cbl2c, cb2cpp, or bespoke scripts into `struct`s;
  alignment and endianness must be handled manually
- **Java/.NET** — libraries like JRecord, CobolRecordReader, LegStar,
  NTT-Data's COBOL-IT/JTOpen copybook parser generate POJOs/POCOs
- **SQL loaders** — columnar unloads (FILE-AID, SyncSort, DFSORT) use the
  copybook to drive fixed-width → row conversions
- **SFTP partners** — external systems receive fixed-width files and reimplement
  the copybook in their own stack (Python struct, Informatica, etc.)

Field-order dependencies cascade across **all** consumers. A single reorder
breaks downstream parsers silently — offsets shift, types still parse, values
land in the wrong columns.

## 8. Versioning and compatibility patterns

- **No semver.** Copybook "version" is the date someone last edited it, usually
  tracked in a header comment block.
- **Safe evolution:** add new fields at the end, pad with FILLER, update
  consumers lazily (they ignore trailing bytes).
- **Unsafe evolution:** reorder, resize, change PIC/USAGE, remove fields,
  change REDEFINES discriminators. All of these break every downstream consumer
  that relies on byte offsets.
- **Look for** `*` comment blocks in the copybook header documenting additions:
  `*  2014-06-12  JDOE  ADDED AIRMAN-SUFFIX FIELD`
- **Fork indicators:** multiple copies with version suffixes
  (`CONVEYANCE.cpy`, `CONVEYANCE_V2.cpy`, `CONVEYANCE_NEW.cpy`) — always a red
  flag; assume they have diverged.

## 9. Numeric / storage migration pitfalls

- **COMP-3 packed decimal** — does not round-trip through UTF-8 or JSON. Must
  be unpacked with a byte-level reader before conversion.
- **EBCDIC → ASCII collation** — `A-Z` come before `0-9` in EBCDIC but after in
  ASCII. Sort-order assumptions break silently.
- **Sign representation** — overpunched zoned decimal, separate leading sign,
  separate trailing sign, COMP-3 sign nibble (`C`/`D`/`F`). Each needs its own
  parser branch.
- **Nulls-as-LOW-VALUES** — COBOL does not have SQL-style NULL. Absent values
  are often `LOW-VALUES` (`0x00`), `HIGH-VALUES` (`0xFF`), spaces, zeros, or
  "MISSING" sentinel strings — inconsistent across programs.
- **Implicit decimal (`V`)** — a `PIC S9(7)V99` field is 9 digits wide with no
  physical decimal point. Readers must insert the decimal.
- **Signed zero / reserved nibbles** — `0xF` sign nibble means unsigned; some
  shops use `0xA`/`0xB`/`0xE` by accident. Validate on import.
- **Date encodings** — `YYYYMMDD` text, `YYMMDD` text (Y2K-window risk),
  packed decimal date, Julian `CYYDDD` (century digit + 2-digit year + day).

## 10. Copybook registries and dependency graph

Discovery must build, for every copybook discovered:

- **Producer set** — programs that WRITE records described by this copybook
- **Consumer set** — programs, batch jobs, sprocs, SFTP partners, external
  systems that READ records described by this copybook
- **Schema mirrors** — SQL tables, Java/.NET classes, Python dataclasses,
  Informatica targets, XSDs that claim to mirror this layout
- **Physical files** — GDG bases, VSAM clusters, sequential datasets that hold
  records of this shape
- **Inclusion chain** — copybooks that nest other copybooks (watch for
  circular `COPY` via `REPLACING`)

The output is a **bidirectional graph** keyed by copybook. For FAA RMS, expect
`CONVEYANCE.cpy` to fan out to: NATURAL batch parser, SQL Server sproc, .NET
thick-client reader, SFTP partner loader. All four must move in lockstep if
the copybook changes.

## 11. Anti-patterns to flag

- **Forked copies** — `FOO.cpy` on mainframe vs. `FOO_v2.cpy` in the .NET repo
  that claim to match but have drifted
- **Inline REDEFINES as union type** — no discriminator, reader "just knows"
  which overlay is active from context
- **"DO NOT MOVE THESE FIELDS" comments** — load-bearing field order without a
  test suite; the comment *is* the test suite
- **Status / type codes without level-88** — `PIC X` documented as "status
  code" with no enumeration — valid values scattered across IF statements
- **Signed numeric stored as unsigned** — `PIC 9(5)` used to hold quantities
  that can go negative; negatives wrap or crash
- **COMP-3 exported as string** — packed field stringified to JSON/CSV without
  sign-nibble handling; values silently corrupt
- **ODO read with MAX-size assumption** — parser ignores the ODO field and
  assumes padded max length; works until the producer stops padding
- **Shared copybook with program-specific WORKING-STORAGE overrides** — the
  copybook declares a field; individual programs redefine it locally with
  different PIC — values differ per program
- **Copybook-as-config** — literal values baked into VALUE clauses used as
  lookup tables instead of a database
- **Hardcoded offsets in downstream code** — Java readers using
  `bytes[42..50]` with no reference to the copybook; invisible coupling

## 12. Discovery findings checklist (>= 15)

For every application that touches copybooks, emit findings covering:

1. `F-CPY-001` — Enumerate every copybook file discovered (path, size, LoC,
   last-modified date, hash).
2. `F-CPY-002` — Per-copybook consumer list (programs / jobs / sprocs that
   `COPY` or `INCLUDE` it).
3. `F-CPY-003` — Per-copybook producer list (writers of records of this shape).
4. `F-CPY-004` — Count of REDEFINES clauses; flag overlays without a
   discriminator field.
5. `F-CPY-005` — OCCURS DEPENDING ON fields: controlling field, min/max extent,
   list of consumers that compute dynamic offsets correctly.
6. `F-CPY-006` — Level-88 enums: parent field + constants + values, surfaced as
   authoritative enumerations.
7. `F-CPY-007` — Forked / divergent copies of the same logical record
   (different files claiming the same layout).
8. `F-CPY-008` — Cross-system consumers (batch + SQL + .NET all reading the
   same `.cpy`, or claiming to).
9. `F-CPY-009` — PIC-type distribution: count of COMP-3, COMP, DISPLAY,
   COMP-1/2; COMP-3 count is a migration risk flag.
10. `F-CPY-010` — Hardcoded field offsets in downstream code (non-copybook
    consumers doing raw byte-slicing).
11. `F-CPY-011` — Copybooks with no header comment / no documented authorship
    (stewardship gap).
12. `F-CPY-012` — Copybooks with "DO NOT MOVE" / "LOAD-BEARING" comments
    (explicit order dependencies).
13. `F-CPY-013` — Copybooks with inline REDEFINES used as union types without
    a discriminator.
14. `F-CPY-014` — Copybooks containing `VALUE` literals used as configuration
    (embedded lookup tables).
15. `F-CPY-015` — Copybooks with encoded dates (Y2K-window `PIC 9(6)`,
    Julian `CYYDDD`, packed-decimal dates) — date-migration risk.
16. `F-CPY-016` — Copybooks whose consumer graph crosses trust boundaries
    (external SFTP partner uses same layout) — contract change coordination
    risk.
17. `F-CPY-017` — Inclusion chains / nested `COPY REPLACING` — transitive
    dependencies that are easy to miss.

## 13. Sample copybook snippet

```cobol
      *----------------------------------------------------------------*
      *  CONVEYANCE.CPY  -  FAA AIRCRAFT CONVEYANCE / RECORDATION      *
      *  HISTORICAL FIELD ORDER IS LOAD-BEARING FOR BATCH READ-ROUTINES*
      *  LAST MODIFIED 2019-08-14  C.RAMOS                             *
      *----------------------------------------------------------------*
       01  CONVEYANCE-RECORD.
           05  CV-HEADER.
               10  CV-RECORD-TYPE         PIC X(01).
                   88 CV-TYPE-BILL-OF-SALE   VALUE "B".
                   88 CV-TYPE-SECURITY       VALUE "S".
                   88 CV-TYPE-LIEN-RELEASE   VALUE "R".
                   88 CV-TYPE-ASSIGNMENT     VALUE "A".
               10  CV-RECORD-DATE         PIC 9(08).
               10  CV-SEQUENCE-NO         PIC S9(09) COMP.
           05  CV-AIRCRAFT.
               10  CV-N-NUMBER            PIC X(06).
               10  CV-SERIAL-NO           PIC X(20).
               10  CV-MANUFACTURER        PIC X(30).
           05  CV-PARTY-COUNT             PIC 9(02) COMP.
           05  CV-PARTY-TABLE OCCURS 1 TO 20 TIMES
                               DEPENDING ON CV-PARTY-COUNT.
               10  CV-PARTY-ROLE          PIC X(01).
                   88 CV-ROLE-SELLER        VALUE "S".
                   88 CV-ROLE-BUYER         VALUE "B".
                   88 CV-ROLE-DEBTOR        VALUE "D".
                   88 CV-ROLE-SECURED       VALUE "C".
               10  CV-PARTY-NAME          PIC X(40).
               10  CV-PARTY-ADDRESS       PIC X(60).
           05  CV-AMOUNT-RAW              PIC X(10).
           05  CV-AMOUNT REDEFINES CV-AMOUNT-RAW.
               10  CV-AMOUNT-DOLLARS      PIC S9(07) COMP-3.
               10  CV-AMOUNT-FLAGS        PIC X(06).
           05  FILLER                     PIC X(20).
      *-- 2021-02-03  J.RIVERA  ADDED CV-JURISDICTION AT END --*
           05  CV-JURISDICTION            PIC X(04).
```

Notes for the reader / the Discovery agent:
- The header comment is the version record. There is no semver.
- `CV-RECORD-TYPE` has a level-88 enum — use it as the authoritative value set.
- `CV-PARTY-TABLE` is ODO on `CV-PARTY-COUNT`; record length is dynamic.
- `CV-AMOUNT` is a REDEFINES overlay of `CV-AMOUNT-RAW`; only one view is valid
  at a time and the discriminator is implicit in the program that reads it.
- `FILLER` is padding — but in practice, programs often reinterpret FILLER in
  local WORKING-STORAGE copies. Grep for it.
- `CV-JURISDICTION` was added at the tail — the safe evolution path. Consumers
  that ignore trailing bytes continued to work unchanged.
