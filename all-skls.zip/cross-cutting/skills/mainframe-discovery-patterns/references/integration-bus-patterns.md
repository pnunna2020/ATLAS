---
part-of: mainframe-discovery-patterns
topic: integration-bus-patterns
applies-to: [tn3270, software-ag-broker, unisys-ewf, unisys-infoimage, com-interop]
---

# Integration Bus Patterns

Reference for discovering and classifying the three dominant bridges FAA-era thick clients use to talk to z/OS or Unisys systems-of-record: TN3270 screen-scraping, Software AG Broker (EntireX), and Unisys eWorkflow / InfoImage via COM Interop. All three routinely coexist in a single `.NET 4.5.2 / C#` thick client (e.g., FAA RMS IMS), so discovery must scan for all three in parallel rather than assume a single integration style.

## Section 1: TN3270 Screen-Scraping

Screen-scraping drives a CICS BMS or NATURAL map by embedding a terminal emulator and reading/writing the 3270 presentation-space buffer. It is the most fragile and the easiest to misclassify as "UI code" when it is actually an integration boundary.

### 1.1 Detection signals

- **Vendor DLL / assembly references** in `.csproj`, `packages.config`, GAC, `App.config`:
  - `AttachmatePresent.dll`, `Attachmate.Reflection.*` (Reflection / Rumba)
  - `AvivaSession.ocx`, `AvivaHostConnect.dll` (Aviva / Open Text HostExplorer)
  - `PCOMM` / `pcomm.dll`, `PCSHLL32.DLL`, `EHLAPI32.DLL` (IBM Personal Communications)
  - `QWS3270.exe`, `QWS3270Secure` (Jolly Giant)
  - `NS/ELITE`, `TN3270Plus`, `Micro Focus Rumba+`
- **HLLAPI API surface** (Standard / Enhanced HLLAPI):
  - `ConnectPresentationSpace`, `DisconnectPresentationSpace`
  - `SendString`, `SetCursor`, `CopyPresentationSpace`, `CopyPresentationSpaceToString`
  - `SearchPresentationSpace`, `WaitForString`, `QueryFieldAttribute`
  - `StartKeystrokeIntercept`, `ReleaseKeyboard`, `Pause`
- **Method / class names** (greppable): `SendKeys`, `WaitForScreen`, `ReadScreen`, `ReadField`, `ScrapeScreen`, `HostSession`, `TerminalSession`, `EmulatorClient`
- **Coordinate-addressing patterns**: integer pairs in the 1..24 × 1..80 range passed to `ReadField(row, col, length)` or `GetTextAt(row, col)`
- **Config smells**: `HostAddress`, `Port=23`, `Port=992`, `LUName`, `DeviceName`, `SessionType=TN3270E`, `.ws` / `.edp` session profile files
- **Process / thread names**: `HLLAPI_Thread`, `PS_Worker`, `EmuPool_*`

### 1.2 Typical code patterns

- **Emulator-in-class**: a `TerminalService` / `HostSession` class holds an emulator handle in a field and exposes coarse methods like `SignOn()`, `LookupClaim(id)`, `PostPayment(...)`
- **Hardcoded field coordinates**: `ReadField(12, 18, 8)` — row, col, length baked into code, mirroring a specific BMS or NATURAL map revision
- **Wait-string logic**: `WaitForString("READY", 10_000)` or `WaitForString("ENTER NEXT COMMAND")` to sync with host timing
- **Scripted sign-on**: multi-step SendKeys flow (`USERID[TAB]PASSWORD[ENTER]`), sometimes wrapped in a retry on "PASSWORD EXPIRED"
- **Screen-state machine**: explicit `switch` on current screen title / anchor text to decide next navigation key (`PF3`, `PF7`, `Clear`)
- **Buffer parsing**: fixed-width substring extraction from a full 1920-char PS copy, often using `Substring(offset, len)` where offset = `(row - 1) * 80 + (col - 1)`
- **Polling loops**: `while (!WaitForString("READY")) { Thread.Sleep(250); }` — timing-dependent and race-prone

### 1.3 Fragility signals

- Hardcoded `(row, col, len)` coordinates with no map-version guard — silent breakage when CICS BMS or NATURAL map is re-generated
- No retry / backoff on `KeyboardLocked`, `HostNotReady`, `X-clock` conditions
- Cursor-position assumptions (code assumes cursor lands in a specific field after `Enter`)
- Swallowed exceptions around `SendString` / `WaitForString` — failure shows up later as corrupt data
- Screen-title / anchor-string checks that match on substrings (`"CLAIM"`) rather than unique anchors, causing misrouting when multiple screens share vocabulary
- "Works on my machine" dependence on emulator version, code page, keyboard map
- Wall-clock timeouts tuned for LAN latency, break over WAN / VPN

### 1.4 Session management

- **Emulator-per-thread**: each worker owns its own PS handle; bugs when a handle is shared across threads without locking
- **Shared session pools**: a `SessionPool` / `HostSessionManager` checks out PS handles; common bugs: unreturned sessions, sign-on drift, state contamination across users
- **Sign-on scripts**: often store credentials in `App.config`, `.ini`, or a service-account singleton — see Security below
- **Keyboard-lock handling**: explicit `ResetKeyboard()` / `Reset()` after every input; missing resets cause cascading failures
- **Auto-logoff timers**: host kicks idle sessions; client must detect "SESSION ENDED" and re-sign-on transparently — frequently missing
- **LU allocation**: fixed LU names or LU pools; collisions when two instances run with the same LU

### 1.5 Security concerns

- `SendKeys("PASSWORD")` sends cleartext credentials through the emulator, visible to any in-process hook / accessibility tool
- Session tokens and user IDs cached in shared memory or static fields; leak across tenants in multi-user deployments
- Plain TN3270 (port 23) has **no TLS**; only TN3270E over SSL (port 992) is encrypted, and configurations often fall back silently
- Service-account credentials in plaintext config files, committed to source control
- No mutual auth — host trusts the LU, not the user; combined with shared LU pools this breaks accountability
- PS buffer contains PII (SSN, claim data) and is often logged by emulator trace features enabled in production

## Section 2: Software AG Broker (EntireX)

EntireX Broker is Software AG's pre-SOA RPC / messaging bus. It exposes ADABAS data, NATURAL subprograms, or COBOL CICS programs as Broker services that .NET / Java / C clients call synchronously. It predates modern web services and is on a vendor EOL trajectory.

### 2.1 Detection signals

- **Client DLLs / JARs**: `etbclnt.dll`, `etbcnv.dll`, `entirex.dll`, `EntireX.NetWrapper.dll`, `entirex.jar`, `broker.jar`
- **Namespaces / packages**: `SoftwareAG.EntireX.*`, `com.softwareag.entirex.aci`, `com.softwareag.entirex.rpc`
- **Class names**: `BrokerService`, `EntireXClient`, `BrokerConversation`, `RPCService`, `IDLClient`, `EntireXRPCService`
- **Broker URL patterns**:
  - `ETB://hostname:1971` (classic)
  - `brokername://hostname:3930` (Windows default)
  - `brokername://hostname:9000` (Unix / z/Linux default)
  - `tcp://`, `ssl://` schemes; reliable-messaging variants `reliable://`
- **Config keys**: `BrokerID`, `ServerAddress`, `ServerName`, `ServiceName`, `ClassName`, `UserID`, `Token`, `EncryptionLevel`
- **Artifacts**: `.idl` files (EntireX IDL), `.svm` (server mapping), `.cvm` (client mapping), generated stub files named like `Calc.cs`, `Calc_Client.java`
- **License hints**: `EntireX`, `webMethods EntireX`, `Software AG Designer` in comments or build scripts

### 2.2 Protocol basics

- Call model: **send** request → **receive** reply, one Broker RPC per logical operation
- **Sync**: blocking `Send`/`Receive` pair; default assumption in most client code
- **Async**: `SendNoWait` + later `Receive`; rare in legacy clients
- **Conversation-scoped**: `ConversationID` groups multiple RPCs into a stateful conversation (for units of work that span services); conversations must be explicitly committed / backed out
- **Units of work**: Broker can enlist in distributed UoW with MQ / ADABAS — detection signal is calls to `COMMIT` / `BACKOUT` / `SetCommit` on the Broker object
- **Heartbeats**: client and Broker exchange keepalives; `WAIT` timeouts govern pickup
- Licensing often per-server-CPU or per-concurrent-client — check for license files `etb.lic`, `license.xml` and `SAG_HOME` env var

### 2.3 NATURAL-side counterpart

- Broker-exposed **NATURAL subprograms** (CALLNAT targets) declared in an `.idl` file with parameter directions `IN`, `OUT`, `INOUT`
- IDL types map to NATURAL data definitions: `A20` → `(A20)`, `N10.2` → `(N10.2)`, `B` → binary, groups → redefines
- **RPC server** on the host (EntireX RPC Server for NATURAL) marshals IDL into NATURAL PDA (parameter data area) and invokes the subprogram
- **EBCDIC ↔ ASCII** conversion done in the Broker stub; misconfigured translation tables cause mojibake on accented characters, `$` / `#` / `@` (varying code pages)
- Subprograms often wrap ADABAS `FIND` / `READ` / `STORE` — a single RPC can hide a heavyweight Natural business transaction

### 2.4 Data-type marshaling pitfalls

- **COMP-3 / packed decimal** on COBOL side → IDL `P` or binary bytes; easy to drop sign nibble or truncate
- **Zoned decimal** (`S9(7)V99`) → IDL `N7.2` with sign-overpunch; sign handling varies
- **Character-set boundaries**: single-byte EBCDIC (CP037, CP1047) vs DBCS; client sending UTF-8 to a CP037 server silently corrupts non-ASCII
- **Nulls / low-values**: COBOL / NATURAL fixed-width fields don't have nulls; IDL nullable types are emulated with sentinel values ("spaces" = null, `0` = null) that leak into client code as special-casing
- **Dates**: often string `YYYYMMDD` or packed `PIC S9(7) COMP-3`; Y2K-era shortcuts (`YYMMDD`) still appear
- **Arrays / occurs**: IDL arrays map to COBOL `OCCURS` / NATURAL `(1:N)`; size mismatches cause buffer overruns on the host side
- **Big-endian vs little-endian** binary fields when IDL uses raw `B` types

### 2.5 Anti-patterns

- **Broker as sync API over slow WAN**: every UI click → blocking Broker RPC from a field office to a z/OS Broker in the datacenter; p99 latency dominates UX
- **No circuit breaker**: client keeps calling through a degraded Broker, queues fill, cascading failure
- **No idempotency**: retries on timeout cause duplicate ADABAS writes (double-posted claims, double-mailed notices)
- **ACL-only auth**: Broker ACF / ACL is the only auth layer; "auth-by-network-segment" (see Section 4); user identity forwarded as a parameter rather than a cryptographic token
- **Long-lived conversations**: conversation pinned to a specific Broker worker, which becomes a session-affinity single point of failure
- **Silent truncation**: IDL field length < actual data length; Broker silently truncates rather than erroring

### 2.6 Migration signal

- **EOL risk is P0**: Software AG's roadmap pushes customers to webMethods (itself consolidating) or rewrites to REST / Kafka; EntireX licensing costs and support horizons are contracting
- Common target: thin REST facade in front of a modernized data store, or direct replacement of the NATURAL subprogram with a domain service
- Discovery must enumerate every Broker RPC call site and its IDL — this is the contract surface the modernization must preserve or explicitly deprecate
- Cross-reference with `natural-patterns.md` and `adabas-patterns.md` (other agents own those)

## Section 3: Unisys eWorkflow / InfoImage

Unisys eWorkflow is a document-workflow state-machine engine; InfoImage is the Unisys ECM that stores document images (predominantly TIFF) with metadata in SQL Server. Legacy .NET clients integrate via COM Interop — a late-bound, Windows-only, apartment-threaded surface that is difficult to port.

### 3.1 Detection signals

- **COM ProgIDs** (greppable): `Unisys.eWorkflow`, `Unisys.eWorkflow.Engine`, `InfoImage.*`, `ImageXpress.Document`, `ImageXpress.TIFF`, `Accusoft.ImagXpress`, `BlackIce.TIFF`, `Pegasus.ImagXpress`
- **DLLs**: `iwfeng.dll`, `ecmengine.dll`, `iwf*.dll`, `InfoImage*.dll`, `ImagXpress*.dll`, `BICore*.dll`
- **COM instantiation patterns**:
  - `Type.GetTypeFromProgID("Unisys.eWorkflow")`
  - `Activator.CreateInstance(Type.GetTypeFromProgID(...))`
  - `new Unisys.eWorkflow.EngineClass()`
  - Interop RCW assemblies `Interop.iwfeng.dll`, `Interop.InfoImage.dll`
- **Attributes**: `[ComImport]`, `[Guid("…")]`, `[DispId(…)]`, `[MarshalAs(UnmanagedType.Interface)]` on wrapper classes
- **Namespaces**: `Unisys.ECM.*`, `Unisys.eWorkflow.*`, `InfoImage.Client.*`
- **File / tree artifacts**: `.btr` Btrieve files, hardcoded UNC paths like `\\ECMSRV\ImageTree\…`, GUID-named directories under an "image tree" root

### 3.2 What eWorkflow is

- State-machine engine for document routing: each document instance has a **current state**, a **work queue**, and a **history**
- States are named (e.g., `PENDING_REVIEW`, `ADJUDICATED`, `CLOSED`); transitions driven by **signals** (explicit events) or **conditions** (metadata predicates)
- Queues are assigned to roles or users; work items are pulled or pushed depending on configuration
- Rules authored in a proprietary scripting language or a Visio-like designer — often locked inside a deployed server with no versioned source
- Integration points: client code raises signals (`RaiseSignal(workItemId, "APPROVE")`) and polls queues (`GetWorkItems(queueName)`)

### 3.3 What InfoImage is

- Content repository:
  - **Content** (TIFF bytes, sometimes PDF / JPEG) in a proprietary binary tree on disk, addressed by GUID and sharded across directories
  - **Metadata** (document type, index fields, retention class, state) in SQL Server tables
- **API surface** exposes store / retrieve / search by metadata, annotation, and redaction
- TIFFs are typically Group 4 fax-compressed, multi-page, sometimes with a separate "annotation layer" file
- Audit trail is a separate log table, often out of sync with content moves

### 3.4 Typical C# integration

- **Late-bound COM** via `Type.GetTypeFromProgID` + `InvokeMember` when interop assemblies are not regenerated for each version — extremely brittle and silent on signature drift
- **Early-bound COM** via generated `Interop.*.dll` wrappers — version-pinned; upgrading the COM server requires regenerating and redeploying wrappers
- **TIFF byte marshaling**: content returned as `byte[]` or a `SAFEARRAY` of `VARIANT`; copies are expensive for multi-MB documents
- **Metadata API**: dictionary-shaped `IDictionary<string, object>` or named property accessors; inconsistent types (some fields string, some `DateTime`, some `decimal`)
- **Streaming**: rare — APIs typically require a full in-memory `byte[]`, driving GC pressure and OOM on large batch jobs
- **Transactions**: eWorkflow transitions and InfoImage writes are in separate transactional scopes from SQL Server writes made by the app

### 3.5 Fragility and anti-patterns

- **COM apartment threading**: objects bound to STA; calls from MTA threads marshal through an RPC hop (huge latency) or throw; async / `Task.Run` patterns silently break affinity
- **No async**: every call blocks a thread; thread-pool starvation under load
- **Hardcoded tree paths**: `\\ECMSRV\ImageTree\2018\Q3\…` — when the server is renamed or the tree re-homed, every client breaks
- **GUID proliferation**: every work item, document, and annotation has its own GUID; joining across eWorkflow + InfoImage + SQL requires maintaining GUID-to-business-key maps by hand
- **Transactional boundary mismatch**: app commits SQL Server work, then eWorkflow / InfoImage fails, leaving **orphan images** or **stuck work items** with no compensating transaction
- **COM exceptions mapped to `HRESULT`**: often surfaced as `COMException` with opaque codes; error-handling code frequently just retries or swallows
- **No connection pooling**: one COM object per request, creation cost dominates

### 3.6 Scale concerns

- FAA RMS: **146M TIFFs** in InfoImage. Discovery cannot enumerate — must **sample** by year / type / size and extrapolate
- Average TIFF size / page count drives S3 storage sizing
- Cross-reference the `tiff-corpus-assessor` skill for sampling methodology, corpus statistics, and metadata completeness checks
- Content drift: older TIFFs may use non-standard compression, annotations in a proprietary format, or rely on eWorkflow state for legibility rules

### 3.7 Migration signal

- **EOL-tier platform**: Unisys ECM has a contracting user base and vendor roadmap
- Typical target: **AWS S3** for content (with Glacier for cold retention), **PostgreSQL** (or the app's existing RDBMS) for metadata, and a workflow engine (Temporal, Camunda, or a lightweight state machine) for eWorkflow replacement
- Migration must preserve: document IDs (or issue a stable mapping), retention / legal-hold flags, audit trail, and annotations
- Plan for dual-write / shadow-read during cutover; COM surface cannot be trivially feature-flagged

## Section 4: Cross-cutting Anti-patterns and Discovery Findings

### 4.1 Cross-cutting anti-patterns across all three buses

- **Auth-by-network-segment** ("the firewall is the ACL"): TN3270, Broker, and eWorkflow endpoints exposed without per-user mutual auth, protected only by VPN / DMZ boundary — **P0 risk** under zero-trust mandates
- **No idempotency / at-least-once semantics**: retries on timeout cause duplicate writes in all three — double-posted CICS transactions, duplicate Broker calls, orphan InfoImage documents
- **Hardcoded credentials**: 3270 sign-on user, Broker `UserID`/`Token`, eWorkflow admin account — in `App.config`, `.ini`, embedded resources, or source
- **Shared service accounts**: one "system" user performs all host operations; accountability collapses, audit logs are useless for forensics
- **Sync chains over WAN**: UI → Broker RPC → NATURAL → ADABAS, all synchronous, all blocking a UI thread
- **No circuit breakers / bulkheads**: degraded host saturates client threadpool, UI freezes
- **Swallowed exceptions**: `catch (Exception) { }` around every integration boundary
- **PII in logs**: PS buffers, Broker payloads, and InfoImage metadata routinely logged verbatim
- **Version-pinned clients**: binaries pinned to a specific emulator / Broker stub / COM interop version; server upgrades break clients silently

### 4.2 Discovery findings checklist

Use this checklist verbatim in the discovery artifact. Each item is a finding-producing task.

1. Enumerate every TN3270 session-creation site (`HostSession` / `EmulatorClient` / `new …PresentationSpace()`) and record LU name, host, port, TLS status.
2. Enumerate every HLLAPI call site (`ConnectPS`, `SendString`, `CopyPresentationSpace`, `QueryFieldAttribute`) with file:line.
3. Extract all hardcoded `(row, col, length)` coordinates in screen-scrape code; group by target BMS / NATURAL map.
4. Identify every `WaitForString` / wait-anchor literal; flag those matching on non-unique substrings.
5. Locate sign-on scripts and flag plaintext credentials or `App.config` credential references.
6. Count and classify Broker RPC call sites (`EntireXClient`, `BrokerService.Invoke`, `RPCService.*`); record broker URL, service name, class name, conversation usage.
7. Inventory every `.idl` file and generated stub; map IDL services to source NATURAL subprograms or COBOL programs.
8. Identify Broker calls with no retry / circuit-breaker wrapping.
9. Flag Broker calls over WAN (compare client deployment location vs broker URL).
10. Enumerate all COM Interop call sites into `Unisys.eWorkflow*` and `InfoImage*`; list referenced interop assemblies and ProgIDs.
11. List every hardcoded ECM / image-tree UNC path or server name.
12. Identify transactions spanning SQL Server + eWorkflow + InfoImage without a compensating path.
13. Sample the InfoImage corpus (do not enumerate) for document count, avg TIFF size, year distribution, and annotation prevalence; record methodology.
14. Identify all sync integration calls originating from UI threads (`Button_Click`, `Form_Load`) — candidates for async rework.
15. Locate and classify hardcoded credentials across all three buses (3270 sign-on, Broker UserID/Token, eWorkflow admin).
16. Identify logging statements that write PS buffers, Broker payloads, or InfoImage metadata to disk / stdout.
17. Record every integration endpoint that lacks TLS (TN3270 port 23, Broker `ETB://`/`tcp://`, plaintext eWorkflow).
18. Map each integration surface to its EOL / vendor-roadmap risk tier and prospective modern replacement.
19. Produce a coverage matrix: (bus type) × (call sites found) × (tests covering the site) — surface untested integration code.
20. Flag any integration call reachable from a code path without an authenticated user principal on the stack.

### 4.3 Bus-type → EOL risk → modernization target

| Bus type | EOL / vendor risk | Typical modern replacement |
|---|---|---|
| TN3270 screen-scraping | Deprecating; emulator vendors consolidating, not a strategic integration surface | API facade over CICS (z/OS Connect), or rewrite UI to call new REST/gRPC services; retire emulator |
| Software AG Broker (EntireX) | P0 — vendor pushing webMethods / rewrite; licensing costs rising | REST / gRPC over domain services; Kafka for async; event sourcing where ADABAS was used as a journal |
| Unisys eWorkflow | EOL-tier; shrinking user base; COM Interop blocks modern runtimes | Temporal / Camunda / lightweight state machine on container runtime |
| Unisys InfoImage | EOL-tier; proprietary binary tree is migration bottleneck | AWS S3 (with Glacier for cold) for content; PostgreSQL for metadata; CloudFront / pre-signed URLs for access |
| COM Interop (Windows DCOM) | Constrains runtime to Windows .NET Framework; blocks .NET (Core)+ migration | Out-of-process service wrapping legacy COM; strangler-fig replacement of COM methods with HTTPS endpoints |

Cross-cutting recommendation: treat the three buses as a single **integration surface** during discovery. Modernization plans that fix only one bus at a time leave the thick client pinned to Windows / .NET Framework / legacy LU allocation and defer rather than eliminate the legacy footprint.
