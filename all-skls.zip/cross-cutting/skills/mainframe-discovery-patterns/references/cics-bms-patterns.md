---
part-of: mainframe-discovery-patterns
topic: CICS transaction processing and BMS 3270 mapping
applies-to: [z/OS CICS, BMS mapsets, TN3270 emulator integration, screen-scraping anti-patterns]
related-refs: [natural-patterns.md, adabas-patterns.md, cobol-patterns.md]
---

# CICS + BMS (3270 Green-Screen) Discovery Patterns

Reference for the `mainframe-discovery-patterns` skill when cataloguing IBM
CICS transaction-processing applications and their BMS-defined 3270 screens.
Covers detection, resource inventory, call-flow shape, and the integration
risks that surface when modern systems screen-scrape BMS maps through TN3270
emulators (e.g., FAA RMS thick client driving CAIS via Aviva TN3270).

NATURAL `INPUT USING MAP` and `.nsm` screen semantics live in
`natural-patterns.md`; this document owns BMS, `EXEC CICS`, and the CSD
resource model. Cross-reference only — do not duplicate.

## 1. Detection Signals

Confirm CICS/BMS presence by looking for any of:

- **File extensions**: `.bms`, `.BMS` (BMS source), `.nsm` (NATURAL shops that
  ship BMS-equivalent maps), `.csd` / `DFHCSDUP` control statements, `.cics`
- **Embedded statements** in COBOL / PL1 / Assembler sources: `EXEC CICS …
  END-EXEC`, `EXEC DLI … END-EXEC` (IMS under CICS), `EXEC SQL … END-EXEC`
  (DB2 under CICS)
- **CSD export listings**: `DEFINE TRANSACTION(`, `DEFINE PROGRAM(`,
  `DEFINE MAPSET(`, `DEFINE FILE(`, `DEFINE TDQUEUE(`, `DEFINE TSMODEL(`
- **TRANID conventions**: 1–4 character upper-case IDs in JCL, logs, or
  docs (`CEMT`, `CESN`, `CEDA`, `RMS1`, `AINQ`). Anything matching
  `/^[A-Z][A-Z0-9]{0,3}$/` inside an `EXEC CICS` or CSD context is a
  transaction-id candidate
- **TN3270 emulator config files**: Aviva `*.asu` / `*.avc`, Rumba
  `*.rcz` / `*.wsf`, IBM PCOMM `*.ws`, QWS3270 `*.qws`, Wall Data
  Rumba `*.wdz`, Attachmate Reflection `*.r2w`
- **JCL clues**: `DFHRPL` concatenation, `DFHSIT` startup overrides,
  `DFHCSDUP` utility, `IGYCRCTL` (COBOL) compiler steps feeding a
  CICS translator (`DFHECP1$`, `DFHEAP1$`, `DFHEPP1$`)
- **Library/DD names**: `SDFHLOAD`, `SDFHMAC`, `SDFHCOB`, `SDFHSAMP`,
  `DFHRPL`, `DFHCMACD`, `DFHHTML`, `DFHDOC`
- **Runtime artifacts**: CICS task trace (`DFHTRA*`), CEEDUMP, CICS
  statistics (`DFH0STAT`), transaction dumps in `DFHDMPA` / `DFHDMPB`

## 2. BMS Anatomy

A **mapset** is a compiled deck of one or more **maps**; a **map** is a
collection of **fields**. Three assembler macros define the tree:

### 2.1 DFHMSD (Mapset Header)

```bms
MAPSET1  DFHMSD TYPE=&SYSPARM,                                         X
               MODE=INOUT,                                             X
               LANG=COBOL,                                             X
               STORAGE=AUTO,                                           X
               TIOAPFX=YES,                                            X
               CTRL=(FREEKB,FRSET),                                    X
               TERM=3270-2
```

- `TYPE=&SYSPARM` — emitted twice at assembly (DSECT for symbolic map,
  MAP for physical map)
- `MODE=INOUT` — both `RECEIVE` and `SEND` allowed; `IN` or `OUT`
  restrict direction
- `LANG=` — drives the generated copybook syntax (`COBOL`, `PLI`,
  `ASM`, `C`)
- `CTRL=FREEKB` unlocks the keyboard after SEND; `FRSET` resets MDT
  bits on all fields before merge

### 2.2 DFHMDI (Map Header)

```bms
MAP1     DFHMDI SIZE=(24,80),                                          X
               LINE=1,COLUMN=1,                                        X
               JUSTIFY=(LEFT,FIRST),                                   X
               CTRL=(FREEKB,PRINT,ALARM)
```

- `SIZE=(rows,cols)` — virtually always 24×80 for legacy CICS; 27×132
  for wide screens; 32×80 and 43×80 exist
- `LINE` / `COLUMN` place the map origin on the physical screen
- `ALARM` fires the 3270 beep on SEND

### 2.3 DFHMDF (Field Definition)

```bms
CERTNO   DFHMDF POS=(5,20),LENGTH=7,                                   X
               ATTRB=(UNPROT,NUM,IC,FSET),                             X
               PICIN='9(7)',PICOUT='9(7)',                             X
               INITIAL=' '
```

| Keyword     | Meaning                                                        |
|-------------|----------------------------------------------------------------|
| `POS`       | (row, column) — 1-based, top-left origin                       |
| `LENGTH`    | Visible length; attribute byte occupies `column-1` implicitly  |
| `ATTRB`     | Attribute flags (see §3)                                       |
| `PICIN`     | COBOL-style input edit pattern applied on `RECEIVE MAP`        |
| `PICOUT`    | Output edit pattern applied on `SEND MAP`                      |
| `INITIAL`   | Default literal emitted when no symbolic value is supplied     |
| `JUSTIFY`   | `LEFT` / `RIGHT`, `BLANK` / `ZERO` fill                        |
| `OCCURS`    | Repeats the field for list / tabular screens                   |

### 2.4 Symbolic vs Physical Map

- **Physical map** is a compiled load module in `DFHRPL`; CICS uses it to
  format the 3270 datastream
- **Symbolic map** is a language-specific copybook (`MAP1I`, `MAP1O`);
  COBOL programs `COPY MAP1` and address fields as `CERTNOI` (input),
  `CERTNOO` (output), `CERTNOL` (length), `CERTNOA` (attribute),
  `CERTNOF` (flag)

Discovery MUST capture both artifacts: the BMS source (for coordinates)
and the symbolic copybook (for program-side field names).

## 3. 3270 Field Attributes

Every DFHMDF field owns a one-byte attribute that governs render and input
behavior. The bit semantics matter because they are often the only "access
control" a green-screen app has.

| ATTRB flag | Effect on terminal                                           |
|------------|--------------------------------------------------------------|
| `ASKIP`    | Autoskip — cursor hops to next unprotected field             |
| `PROT`     | Protected — operator cannot type; display-only               |
| `UNPROT`   | Unprotected — accepts keyboard input                         |
| `NUM`      | Numeric lock — only digits, sign, decimal                    |
| `BRT`      | Bright / high-intensity display                              |
| `NORM`     | Normal intensity (default)                                   |
| `DRK`      | Dark — non-display (passwords, PII on a shared screen)       |
| `IC`       | Insert Cursor — initial cursor position                      |
| `FSET`     | Field-Set — MDT on at SEND; field returns even if unchanged  |
| `DET`      | Detectable (light-pen) — rarely used today                   |

**Attribute interactions to flag during discovery:**

- `UNPROT` + `DRK` = free-text input that never renders — 9-in-10 times
  this is a password field; note for secret-scanning rules
- `PROT` + `BRT` on a field that a downstream TSQUEUE write populates is
  the classic "role label" anti-pattern (§8)
- `FSET` without `UNPROT` is typically a bug carried forward; log it
  but do not rewrite

## 4. CICS Transaction Flow

### 4.1 Conversational vs Pseudo-Conversational

- **Conversational**: task holds the terminal across `SEND` / `RECEIVE`
  pairs. Rare in modern CICS — burns task storage and locks resources
- **Pseudo-conversational** (dominant): each `RECEIVE MAP` is a new
  task; state is passed via `COMMAREA` or `CHANNEL/CONTAINER`, and the
  task ends with `EXEC CICS RETURN TRANSID=(next-tranid)` so the terminal
  re-enters the conversation on the next AID (Enter / PF key)

Mixing the two in a single path is a discovery red flag — surfaces as
"TRANID X sometimes LINKs back, sometimes RETURNs" in traces.

### 4.2 Minimal SEND / RECEIVE Pair

```cobol
* Send the initial screen
EXEC CICS SEND MAP('MAP1') MAPSET('MAPSET1')
         FROM(MAP1O)
         ERASE
         CURSOR
         FREEKB
END-EXEC.

EXEC CICS RETURN TRANSID('AINQ')
         COMMAREA(WS-STATE)
         LENGTH(LENGTH OF WS-STATE)
END-EXEC.

* …next task entry (pseudo-conversational)…

EXEC CICS RECEIVE MAP('MAP1') MAPSET('MAPSET1')
         INTO(MAP1I)
         RESP(WS-RESP)
END-EXEC.

IF WS-RESP NOT = DFHRESP(NORMAL)
   PERFORM HANDLE-MAP-ERROR
END-IF.
```

### 4.3 State-Passing Mechanisms

- **DFHCOMMAREA** — up to 32KB block threaded on `RETURN` / `LINK` /
  `XCTL`. Discovery inventory: who writes it, who reads it, what is the
  copybook layout?
- **CHANNEL / CONTAINER** — modern replacement (no 32KB cap, multiple
  named containers per channel). Detect via `PUT CONTAINER` /
  `GET CONTAINER`
- **TSQUEUE** (temporary storage) — keyed queue, auxiliary or main
  storage; commonly abused as a per-user session cache
- **TDQUEUE** (transient data) — queue with a trigger level; classic
  print-spool and interface-file pattern

## 5. CSD Resource Definitions (The Inventory)

The CICS System Definition dataset is the authoritative registry. Every
discovery pass MUST enumerate these resource types and emit one finding
per entry. Expect them as `DEFINE …` statements in a CSD unload.

| Resource      | Keyword               | Purpose                                      |
|---------------|-----------------------|----------------------------------------------|
| Transaction   | `DEFINE TRANSACTION`  | Binds TRANID → initial program               |
| Program       | `DEFINE PROGRAM`      | Load module name + language + concurrency    |
| Mapset        | `DEFINE MAPSET`       | BMS load module name                         |
| File          | `DEFINE FILE`         | VSAM / DATATABLE binding                     |
| TDQUEUE       | `DEFINE TDQUEUE`      | Transient data queue (intra / extra)         |
| TSMODEL       | `DEFINE TSMODEL`      | TS-queue naming + recovery / security model  |
| Connection    | `DEFINE CONNECTION`   | MRO / ISC link to another CICS region        |
| Sessions      | `DEFINE SESSIONS`     | LU6.2 / APPC sessions                        |
| URIMap        | `DEFINE URIMAP`       | HTTP inbound/outbound mapping                |
| Pipeline      | `DEFINE PIPELINE`     | Web services inbound pipeline                |
| DB2Conn       | `DEFINE DB2CONN`      | DB2 attachment facility binding              |

## 6. Call Patterns

| Verb                 | Semantics                                                   |
|----------------------|-------------------------------------------------------------|
| `LINK PROGRAM(x)`    | Synchronous; callee returns to caller; COMMAREA threaded    |
| `XCTL PROGRAM(x)`    | Transfer control; caller is purged; no return               |
| `START TRANSID(x)`   | Async new task; optional `INTERVAL`, `AT`, `FROM` data      |
| `RETURN [TRANSID=]`  | End task; with TRANSID = pseudo-conversational continuation |
| `HANDLE CONDITION`   | Legacy error vectoring; replaced by `RESP` / `RESP2`        |
| `ABEND ABCODE(x)`    | Forced abnormal termination; 4-char abend code              |

Discovery must build a directed graph: `TRANID → PROGRAM → {LINK, XCTL,
START} → PROGRAM*`. XCTL cycles and START fan-out both merit their own
findings (§11).

## 7. Screen-Scraping Integration Risk

The real risk on portfolios like FAA RMS is that a "modern" application
(thick client, Java service, RPA bot) drives the 3270 conversation
through a TN3270 emulator and parses the resulting screen by
coordinates. The BMS field layout then becomes a **hidden contract**
with zero compiler enforcement.

**Detection heuristic**:

1. Extract `POS=(r,c)` + `LENGTH=n` for every DFHMDF field → set
   `S_bms = {(mapset, map, field, row, col_start, col_end) …}`
2. Scan non-CICS source (Java, C#, VB, Python, PowerBuilder, Aviva
   macros, RPA scripts) for numeric literals, regexes, or API calls
   that reference row/column pairs: `getScreen(r, c, n)`,
   `ReadRegion(row, col, length)`, `screen[r][c:c+n]`,
   `ExtractText(row=r, col=c, length=n)`
3. Emit a finding for every `(r, c)` coordinate pair in the modern
   tier that lies inside a BMS field rectangle. Severity HIGH if the
   field is `UNPROT` (writeback path); MEDIUM if read-only

The FAA RMS → CAIS path (`ISSUE-SUM`, `MAINT-UPD`, `PRIVACY` screens)
is the canonical example: Aviva emulator macros reference CAIS
coordinates; a BMS field move of even one column breaks the thick
client silently (no compile error, no runtime error — just wrong data).

## 8. Green-Screen Anti-Patterns

Document each of these explicitly in the discovery report when seen:

- **Hardcoded coordinates in downstream code** — coupling without a
  contract (§7)
- **BMS load modules checked in as binaries** — `.bms` source lives on
  a mainframe LIBDEF concatenation while only the `DFHMAPSET` load
  module is in VCS. Field changes become undiffable
- **TSQUEUE as global state** — a TRANID writes a queue named
  `USER||TERMID`, a later TRANID reads it. Session affinity makes
  horizontal scaling impossible without a sticky router
- **Attribute-based role enforcement** — code toggles `PROT` ↔ `UNPROT`
  or `BRT` ↔ `DRK` to "hide" privileged fields. Any TN3270 client that
  ignores the attribute byte sees the data
- **Transaction chaining via COMMAREA flags** — a 1-byte `NEXT-ACTION`
  field drives a hand-rolled state machine across 20 TRANIDs; changes
  require reading every program
- **MDT-driven logic** — program only processes fields whose MDT bit
  is on; a screen-scraper that sets every field triggers validation
  paths the humans never hit
- **`HANDLE CONDITION ERROR PROGRAM(errpgm)`** at top of every
  program — swallows and rebrands every CICS error; masks root cause
  in logs

## 9. VSAM / IMS / DB2 Access (Shallow Pass)

CICS rarely owns data directly — it brokers reads against:

- **VSAM** — `EXEC CICS READ DATASET('FILEA') INTO(rec) RIDFLD(key)`.
  Inventory every `DATASET`, cross-link to the CSD `FILE` definition
- **IMS DL/I** — `EXEC DLI GU SEGMENT(SEG) WHERE(KEY=x)`. PSB / PCB
  definitions name the databases
- **DB2** — `EXEC SQL SELECT … END-EXEC`. DB2 plan name is bound to
  the CICS transaction via `DEFINE DB2TRAN`
- **Queues** — TDQUEUE for persistent interface files, TSQUEUE for
  ephemeral per-session state

Deep data dictionary work lives in `adabas-patterns.md` and the
forthcoming SQL-dialect reference. Here, emit one finding per DATASET
/ PSB / plan referenced; do not extract schemas.

## 10. Migration-to-Modern Hints

Not a how-to — just the coarse-grained mapping Discovery hands to
Rationalization / Architecture:

| Legacy construct                   | Modern target                                |
|------------------------------------|----------------------------------------------|
| BMS map + symbolic copybook        | HTML form + schema-validated DTO / JSON      |
| DFHMDF `ATTRB=UNPROT,NUM`          | `<input type="number" required>` + validator |
| DFHMDF `ATTRB=PROT,BRT`            | Read-only field with emphasis style          |
| DFHMDF `ATTRB=UNPROT,DRK`          | `<input type="password">`                    |
| DFHMDF `PICOUT='$$$,$$9.99'`       | Locale-aware money formatter                 |
| `EXEC CICS RECEIVE MAP`            | HTTP POST handler                            |
| `EXEC CICS SEND MAP`               | Server-side render or JSON response          |
| Pseudo-conversational + COMMAREA   | Stateless REST + session token / JWT         |
| `LINK PROGRAM`                     | In-process function or synchronous RPC       |
| `XCTL PROGRAM`                     | HTTP 307 redirect or workflow hand-off       |
| `START TRANSID INTERVAL=`          | Scheduled job / message on a queue           |
| TSQUEUE                            | Redis / in-memory cache                      |
| TDQUEUE (intra)                    | SQS / Kafka topic                            |
| CSD resource entry                 | Service catalog entry + OpenAPI spec         |

## 11. Discovery Findings Checklist

Emit at minimum the following findings per application. Each is a
schema-validated row in the discovery artifact (≥15 required):

1. Every TRANID defined in CSD, with its initial program
2. Every PROGRAM defined in CSD, with language + concurrency (`QUASIRENT`
   vs `THREADSAFE`)
3. Every MAPSET and its member MAPS
4. Per map: field count, row range, column range
5. Per field: `(mapset, map, field, row, col, length, attrb, picin,
   picout, initial)` tuple
6. Fields whose coords are referenced by non-CICS code (§7). Severity
   scales with `UNPROT` vs `PROT`
7. PROT / UNPROT asymmetry across maps that share a field name
   (potential data-leak path)
8. `DRK` fields (password / PII candidates) — feed secret-scanning
9. Every CSD FILE entry + the DATASET name; cross-link to VSAM
   catalogue when available
10. TDQUEUE and TSQUEUE references in every program, with direction
    (read / write / both)
11. LINK / XCTL / START call graph edges per program
12. Pseudo-conversational chains: `TRANID_a → (COMMAREA) → TRANID_b …`
13. `HANDLE CONDITION` and `RESP` usage — which errors are handled,
    which swallowed
14. Every embedded `EXEC SQL` / `EXEC DLI` / `EXEC CICS READ DATASET`
    statement — target + operation + keys
15. TN3270 emulator config files present in the source tree + the
    TRANIDs they drive
16. CICS `DEFINE URIMAP` / `DEFINE PIPELINE` entries (HTTP / WS egress)
17. BMS mapsets whose compiled load module is checked in but whose
    `.bms` source is missing (binary-only risk)
18. Any `ABEND ABCODE(x)` literals and the paths that reach them

## 12. Sample Snippets (Minimal, For Anchoring)

### 12.1 DFHMDF Field Definition

```bms
CERTDT   DFHMDF POS=(7,25),LENGTH=10,                                  X
               ATTRB=(UNPROT,NUM,FSET),                                X
               PICIN='9999/99/99',                                     X
               PICOUT='9999/99/99',                                    X
               INITIAL='          '
```

### 12.2 SEND MAP / RECEIVE MAP Pair

```cobol
PROCEDURE DIVISION.
    EXEC CICS SEND MAP('AINQM1') MAPSET('AINQMS')
             FROM(AINQM1O)
             ERASE FREEKB CURSOR
             RESP(WS-RESP)
    END-EXEC.

    EXEC CICS RETURN TRANSID('AINQ')
             COMMAREA(WS-STATE)
             LENGTH(LENGTH OF WS-STATE)
    END-EXEC.

*  … next pseudo-conversational entry …

    EXEC CICS RECEIVE MAP('AINQM1') MAPSET('AINQMS')
             INTO(AINQM1I)
             RESP(WS-RESP)
    END-EXEC.

    EVALUATE WS-RESP
        WHEN DFHRESP(NORMAL)      PERFORM PROCESS-INPUT
        WHEN DFHRESP(MAPFAIL)     PERFORM HANDLE-EMPTY-SCREEN
        WHEN OTHER                PERFORM HANDLE-CICS-ERROR
    END-EVALUATE.
```
