---
part-of: mainframe-discovery-patterns
topic: JCL (IBM z/OS Job Control Language)
scope: detection, anatomy, orchestration, dependency graph, discovery findings
companion-refs: natural-patterns.md (for NATURAL programs invoked by JCL)
---

# JCL Discovery Patterns

Reference for the `mainframe-discovery-patterns` skill when analyzing IBM z/OS
batch suites controlled by JCL (Job Control Language) and enterprise schedulers
(Control-M, CA-7, ESP/Tivoli Workload Scheduler). JCL is the scripting layer
that wires together programs, datasets, libraries, and exit-code logic on the
mainframe. Every z/OS batch job — nightly extracts, SFTP transfers, ADABAS
unloads, replication feeds — is expressed as JCL.

NATURAL programs *invoked by* JCL (NATRTxx, CMSYNIN DD, etc.) are covered in
`natural-patterns.md`. This document covers the JCL wrapper, orchestration,
and the operational control plane around those programs.

## 1. Detection Signals

Confirm a JCL-controlled batch workload by checking for:

- **Extensions**: `.jcl`, `.JCL`, `.job`, `.proc`, `.PROC`, `.prc`
- **PDS members**: JCL often lives in partitioned datasets with no file
  extension — look for 8-char uppercase member names in a `JCLLIB` or
  `PROCLIB` folder when exported from the mainframe
- **JOB card as first non-comment line**: `//JOBNAME  JOB (accounting),...`
- **`EXEC PGM=`** or **`EXEC PROC=`** statements
- **DD (data definition) statements**: `//DDNAME DD DSN=...,DISP=...`
- **Instream data markers**: `//SYSIN DD *` followed by control cards, closed
  by `/*`
- **Continuation**: non-blank in column 72, continuation line starts in cols
  4-16 (fixed-column JCL is the legacy norm)
- **DSN naming conventions** (site-specific; FAA RMS example):
  - `AIT.RMS.PRD.*` — production datasets
  - `AIT.RMS.TST.*` — test datasets
  - `AIT.RMS.DEV.*` — development datasets
  - `AIT.<agency>.<system>.<env>.<qualifier>` is the typical 4-5 node pattern
- **Sidecar scheduler exports**: Control-M XML/JSON job definitions, CA-7
  `.csv` schedule dumps, ESP Event rule files

### Distinguishing JCL from PROCs
- JCL job stream starts with `//JOB`, ends with end-of-file or `//`
- PROC (procedure) starts with `//PROC PROC` and ends with `//PEND`
- PROCs are reusable; JCL invokes them via `EXEC PROC=procname`

## 2. JCL Anatomy

A JCL job is a sequence of **steps**. Each step has a JOB-level prologue,
an `EXEC` statement, and one or more DD statements.

### JOB Card

```
//RMSD05 JOB (AIT,RMS,PRD),'DAILY EXTRACT',
//             CLASS=A,MSGCLASS=X,MSGLEVEL=(1,1),
//             NOTIFY=&SYSUID,REGION=0M,TIME=NOLIMIT
```

Key JOB-card parameters the skill must capture:
- **JOB name** (1-8 chars, uppercase) — primary identifier; correlate to
  Control-M job name and runbook entries
- **Accounting field** — `(AIT,RMS,PRD)` maps to chargeback / business unit
- **Programmer name** / description — often the only human-readable label
- **CLASS=** — job class, selects initiator pool (A/B/X for prod, T for test)
- **MSGCLASS=** — output routing; `X` = JES held, `A` = print queue
- **MSGLEVEL=(1,1)** — controls JCL listing verbosity in JES output
- **NOTIFY=** — user ID for TSO notification on completion
- **REGION=** — address-space memory cap (e.g., `0M` = unlimited, site-allowed)
- **TIME=** — CPU time cap (`NOLIMIT`, `1440`, `(30,0)` = 30 min)
- **TYPRUN=SCAN/HOLD** — submission flags worth flagging (held jobs may be
  disabled; scan-only jobs never execute)

### EXEC Statement

Two forms:
- `//STEP01 EXEC PGM=IEFBR14` — run a program directly
- `//STEP01 EXEC PROC=RMSPROC,PARM1='VALUE'` — run a PROC with symbol overrides

Key fields:
- **Step name** (1-8 chars) — used in `IF STEPNAME.RC` conditional logic
- **PGM=** or **PROC=** — what is executed
- **PARM=** — argument string passed to program (max 100 chars, comma-split)
- **COND=** — step execution gating (see §5)
- **TIME=**, **REGION=** — per-step overrides

### DD Statements

DD (data definition) statements wire datasets, libraries, and streams to
program DDNAMEs that the executable reads/writes.

```
//EXTRACT DD DSN=AIT.RMS.PRD.AIRMAN.EXTRACT(+1),
//             DISP=(NEW,CATLG,DELETE),
//             UNIT=SYSDA,SPACE=(CYL,(100,20),RLSE),
//             DCB=(RECFM=FB,LRECL=4000,BLKSIZE=0)
```

### Special DDs
- **STEPLIB** — program load library concatenation (`DD DSN=RMS.LOAD,DISP=SHR`)
  — programs resolved here before system LINKLIST
- **JOBLIB** — same as STEPLIB but scoped to entire job
- **SYSIN** — instream or dataset-based program input (control cards)
- **SYSOUT** — print/spool output (`SYSOUT=*` = MSGCLASS default)
- **SYSPRINT** — program-generated print output
- **SYSUDUMP** / **SYSABEND** / **CEEDUMP** — abend diagnostic output
- **SYSTSIN** / **SYSTSPRT** — TSO terminal monitor program I/O

## 3. Common Mainframe Batch Programs Invoked From JCL

The skill must classify each `EXEC PGM=` as **business-logic** (holds code
worth extracting) vs **plumbing** (utility, no domain logic).

| Program | Category | Purpose |
|---------|----------|---------|
| `NATRTxx` | Business logic | NATURAL runtime; invokes NATURAL programs via CMSYNIN |
| `ADARUN` | Plumbing (ADABAS) | ADABAS nucleus / utility driver |
| `IDCAMS` | Plumbing | Access Method Services — VSAM define/delete/repro/print |
| `IEBGENER` | Plumbing | Sequential dataset copy, optional reformat |
| `IEBCOPY` | Plumbing | PDS member copy/compress |
| `ICEMAN` / `SORT` / `DFSORT` / `SYNCSORT` | Plumbing or business | Sort/merge/copy; SYSIN often contains business rules (INCLUDE/OMIT/OUTREC) |
| `IEFBR14` | Plumbing | No-op branch-to-register-14; used only for DD allocation side effects |
| `IKJEFT01` / `IKJEFT1B` | Plumbing | TSO Terminal Monitor in batch — runs CLISTs/REXX |
| `DSNUTILB` | Plumbing (Db2) | Db2 utility driver (LOAD, UNLOAD, RUNSTATS) |
| `DSNTIAD` / `DSNTEP2` | Plumbing (Db2) | Dynamic/static SQL execution |
| `FTP` / `BPXBATCH` | Plumbing | z/OS FTP client or USS shell invocation |
| `COBRUN` / `IGZNCALL` | Business logic | COBOL batch runtime |
| `CZZPRMRT` / site runtime | Business logic | Site-specific 4GL launchers |
| `ICEGENER` | Plumbing | DFSORT alternative to IEBGENER |

**Rule of thumb**: if SYSIN contains SQL, SORT control cards, IDCAMS commands,
or NATURAL session input — the business logic is *in the DD stream*, not in
the PGM= binary. Extract and classify SYSIN content, not just program names.

## 4. Control-M Integration

Control-M is the scheduler most common for FAA and large-enterprise z/OS
shops. The JCL by itself is inert — Control-M (or CA-7 / ESP) decides when
and whether it runs.

### Control-M job attributes the skill must capture
- **Job name** — should match JCL JOB card (but often diverges; flag mismatches)
- **Folder / Application / Sub-application** — org grouping
- **Calendar** — `DAILY`, `WEEKDAY`, `MON-FRI`, `WEEKLY-SUN`, `MONTHLY-1ST`,
  `MONTHLY-EOM`, user-defined calendars (`RMS-FY-CLOSE`)
- **Active period** — window in which job is eligible (`FROM 02:00 UNTIL 06:00`)
- **In-conditions** (predecessors) — named flags set by prior jobs
- **Out-conditions** (postdecessors) — named flags set on this job's success
- **Resources** — named semaphores limiting parallelism (`DB-UNLOAD-POOL: 2`)
- **Maximum runs** / retry policy
- **Exit-code interpretation** — mapping from `rc` to OK/WARN/FAIL
- **On-do actions** — notify pager, auto-restart step, run cleanup job

### FAA RMS pattern
RMS batch suite (~35 jobs) names map to function and cadence:
- `D05` / `D10` / `D15` / `D40` / `D48` / `D140` — daily jobs, ordinal indicates
  stream position (D05 first, D140 late-window)
- `W20` / `W74` — weekly jobs, typically run Sun/Sat window
- `M50` — monthly jobs, usually month-end cutover

Typical content: airman cert extract/print, SFTP to TSA/IPC/NARA/Delphi/AOPA/Mayo,
ADABAS → SQL Server replication via dataset stage + network transfer.

### JES2 output disposition
- `SYSOUT=*` goes to MSGCLASS destination (often held for ops)
- `SYSOUT=(A,,PRINTCLASS)` routes to specific printer or JES exit
- `SYSOUT=(X,CONTROL-M)` lets CM harvest output into its console

## 5. Exit Codes & Error Handling

Every step returns a **condition code** (RC, 0-4095). JCL's entire flow-control
surface is `COND=` and `IF/THEN/ELSE` against RC.

### Typical return-code semantics

| RC     | Meaning              | Typical ops action |
|--------|----------------------|--------------------|
| 0      | Normal completion    | Continue pipeline |
| 4      | Warning              | Continue; log to daily review |
| 8      | Soft failure         | Page on-call; manual restart |
| 12     | Hard failure         | Page on-call; investigate before rerun |
| 16+    | Severe failure       | Escalate; likely data corruption |
| S0Cx   | System abend         | Page on-call; potentially infra issue |
| Uxxxx  | User abend           | Program-specific; consult runbook |
| Sxxx   | System-code abend    | `S806` = module not found, `S013` = DCB mismatch, `S322` = time limit, `S878` = storage |

**Site rule (FAA-typical)**: RC >= 8 pages on-call; RC = 4 goes to a morning
review queue; `COND=EVEN` overrides normally skip unless noted.

### COND= on EXEC

```
//STEP02 EXEC PGM=NATRT82,COND=(4,LT,STEP01)
```
Reads: "skip STEP02 if 4 is less-than STEP01.RC" — i.e., skip if STEP01.RC > 4.
The logic is inverted from imperative-language intuition.

`COND=EVEN` — run this step even if a prior step abended. Common for cleanup
and SFTP-failure-notification steps.

`COND=ONLY` — run this step only if a prior step abended. Error-path steps.

### IF/THEN/ELSE (modern JCL, z/OS 1.x+)

```
//IFGOOD IF (STEP01.RC = 0) THEN
//STEP02 EXEC PGM=NATRT82
//        ENDIF
```
Easier to reason about; prefer in new JCL.

### MAXCC / LASTCC
IDCAMS and utility suites expose `MAXCC` (highest code seen) and `LASTCC`
(most recent step) — control-card logic inside SYSIN branches off these.

## 6. Dataset (DD) Patterns

Dataset wiring is load-bearing. Discovery must capture every DSN, its DISP,
and its GDG generation.

### DISP= tuple
`DISP=(status,normal-end,abnormal-end)`

- **status**: `NEW` (create), `OLD` (exclusive read/write), `SHR` (shared),
  `MOD` (append, or NEW if missing)
- **normal-end**: `KEEP` (retain, don't catalog), `CATLG` (retain and catalog),
  `DELETE` (erase), `PASS` (pass to next step without uncatalog)
- **abnormal-end**: same values; what to do on step failure

Common patterns:
- `DISP=(NEW,CATLG,DELETE)` — create output; keep if good, drop if step dies
- `DISP=SHR` — shared read; safe for multiple concurrent readers
- `DISP=(MOD,CATLG,KEEP)` — append, always keep
- `DISP=(OLD,DELETE)` — delete source after read (flag this; fragile!)

### DSN= patterns
- Simple catalog name: `DSN=AIT.RMS.PRD.CONTROL`
- GDG reference: `DSN=AIT.RMS.PRD.AIRMAN.EXTRACT(0)` (current generation),
  `(+1)` (new generation), `(-1)` (prior generation)
- Temporary: `DSN=&&TEMPFILE` — scope = job only, deleted at EOJ
- PDS member: `DSN=RMS.PARMLIB(DAILY)`
- Referback: `DSN=*.STEP01.OUTDD` — re-use DSN from a prior step's DD

### GDG (generation data group)
A catalog-managed rolling window of datasets. Version promotion is automatic:
`(+1)` becomes `(0)` on successful allocation. Base GDG defined via IDCAMS
`DEFINE GDG LIMIT(n) SCRATCH|NOSCRATCH`. Discovery must capture the GDG base
and the retention count — losing a generation silently breaks restart logic.

### SYSOUT routing
- `SYSOUT=*` — follow MSGCLASS
- `SYSOUT=(A,,PRINT1)` — class A, no writer program, form PRINT1
- `SYSOUT=(X,OUTGRP)` — class X, grouped in JES output group OUTGRP

## 7. SFTP / External File Transfer Patterns

RMS batch jobs frequently send files to TSA, IPC, NARA, Delphi, AOPA, Mayo.
Common patterns the skill must identify:

- **z/OS FTP client**: `EXEC PGM=FTP,PARM='(EXIT'` with SYSIN carrying
  `OPEN`/`USER`/`PUT`/`QUIT` commands — plaintext password risk
- **BPXBATCH + USS sftp**:
  ```
  //SFTP EXEC PGM=BPXBATCH,PARM='sh /rms/prod/bin/sftp-tsa.sh'
  ```
  Actual logic in the shell script — discovery must fetch the shell file from
  USS/zFS to analyze
- **Globalscape EFT / managed SFTP**: often a dedicated gateway host; JCL
  writes to staged directory, external daemon picks up and delivers
- **CONNECT:Direct (NDM)**: `EXEC PGM=DMBATCH` with process-statement SYSIN;
  captures src/dst node, file, disposition
- **`.netrc` / password-in-JCL**: flag *any* `PASSWORD=` in SYSIN as a P0
  finding — should be vaulted via RACF keyring, NDM secure+, or Globalscape
  credential store

### Endpoint inventory (RMS example)
Build a table: `{job_name, protocol, remote_host, remote_path, credential_source}`.
Cross-reference Control-M job name to discover which downstream agency owns
the interface (TSA airman vetting, IPC medical, NARA records transfer, Delphi
financial feed, AOPA membership sync, Mayo aeromedical).

## 8. PROC Library Patterns

Reusable JCL templates live in PROC libraries.

- **Cataloged PROC**: stored in a PDS referenced by the JES2 `PROCnn` or
  site JCLLIB concatenation (`SYS1.PROCLIB`, `RMS.PROCLIB`)
- **Instream PROC**: inlined in the JCL between `//NAME PROC` and `// PEND`
- **JCLLIB ORDER=(RMS.PROCLIB,SYS1.PROCLIB)** — search path override at JOB
  level; concatenation order matters (first-found wins)
- **Symbolic substitution**: `&HLQ..DATAFILE` where HLQ is passed on EXEC;
  doubled-dot delimits the symbol from the literal
- **Symbol defaults**: `//STEP PROC HLQ=AIT.RMS.PRD` in the PROC header; overridden by `EXEC PROC=name,HLQ=AIT.RMS.TST`
- **Override a DD inside a PROC step**: `//STEPNAME.DDNAME DD ...` on the
  invoking JCL — surgical replacement of a PROC DD

Discovery tip: dereference PROCs eagerly. A job that looks 10 lines long may
expand to 400 lines across 3 nested PROCs.

## 9. Job Dependency Graph Extraction

Goal: produce a directed graph `(job, step) -> (job, step)` agents can render
and reason about.

### Edge sources (in priority order)
1. **Control-M in/out conditions** — explicit, authoritative
2. **GDG reads/writes across jobs** — Job A writes `(+1)` to GDG `FOO`; Job B
   reads `(0)` from GDG `FOO`. Hard dependency, invisible without catalog walk
3. **Shared non-GDG datasets** — producer writes DISP=(NEW,CATLG), consumer
   reads DISP=SHR. Common but fragile
4. **Time-window coupling** — Job B starts 30 min after Job A; no technical
   edge, but operational dependency. Flag as **soft** edge
5. **External file transfer** — Job A SFTPs to TSA; TSA processes; Job B
   pulls response file. Cross-org dependency, must be labeled

### Graph attributes per node
- Calendar (daily/weekly/monthly/adhoc)
- SLA window (e.g., "must complete by 06:00 ET")
- Criticality tier (Tier 1 = safety-critical, etc.)
- Owner team
- Historical avg / p95 runtime (from JES SMF 30 records or Control-M history)

### Emit format
Recommend DOT / Mermaid for visualization; JSON for programmatic use.

## 10. Common Anti-Patterns

Flag these in discovery findings:

- **Hardcoded DSN prefixes without env symbols** — `AIT.RMS.PRD.*` literal
  in test JCL means test runs are pointed at prod data. Use `&HLQ`
- **Missing `COND=EVEN` on cleanup steps** — cleanup is skipped when prior
  step fails; datasets leak, mounts held
- **STEPLIB concatenation order bugs** — wrong LOADLIB order causes the
  program to resolve to an old binary; symptom is silent wrong-result
- **`DISP=(OLD,DELETE)` on a source dataset** — successful run deletes the
  only copy; restart is impossible without backup
- **Batch window exceeding overnight budget** — a job that runs >4h and
  threatens to collide with the 06:00 online-open window
- **JCL-as-pseudo-scripting via SYSIN instream data** — hundreds of lines of
  IDCAMS or SORT control statements with conditional logic that should be a
  real program
- **Abend-and-resubmit as error handling** — ops knowingly hot-restart from
  a specific step every time; indicates unreliable dependency
- **Plaintext passwords in FTP SYSIN** — any `PASSWORD=` literal is a finding
- **Region=0M without justification** — unbounded memory is a perf-governance red flag
- **TIME=NOLIMIT** — same; disables the CPU-time guardrail
- **Generation skip** — job expects GDG `(0)` to be yesterday's, but the
  prior job silently failed and `(0)` is 3 days old; calculate explicit
  date stamps where possible
- **Conditional operators inverted** — `COND=(0,NE)` reads "skip if RC != 0"
  which is rarely the intent; surface for review
- **PROC flattening absent** — jobs that haven't been dereferenced during
  discovery hide business logic inside 4 levels of `EXEC PROC=`
- **No NOTIFY= or stale NOTIFY= userid** — failure notifications go nowhere
- **Production jobs running under personal TSO user IDs** — should be
  functional/service IDs

## 11. Discovery Findings Checklist

The skill must emit at least 15 discovery findings per JCL batch suite:

1. **Inventory**: every unique JOB name and its JCL source location
2. **Calendar map**: correlate each job to its Control-M calendar / cadence
3. **Dependency graph**: directed graph built from §9 (edges + attributes)
4. **Runtime hot list**: jobs whose p95 runtime > 4h or > 80% of SLA window
5. **SFTP endpoint inventory**: all external hosts, protocols, credential
   sources, and owning agencies (per §7)
6. **External dataset reference list**: all DSNs outside the app HLQ
   (e.g., non-`AIT.RMS.*`) that the suite reads or writes
7. **Abend history summary**: counts of S0Cx / U-abend occurrences per job
   over the last 90 days from SMF / Control-M history
8. **Deprecated-program usage**: jobs calling programs slated for retirement
   (site-maintained list) — typical examples: old NATURAL runtimes,
   ancient SORT, home-grown utilities, EOS'd vendor binaries
9. **Plaintext credentials**: every `PASSWORD=`, `.netrc`, and inline
   secret found in JCL or referenced shell scripts — P0
10. **Over-privileged JOB authorities**: jobs running under USER= that has
    more RACF authority than needed; check for SPECIAL/OPERATIONS attributes
11. **GDG retention gaps**: GDG bases with LIMIT < 5 or SCRATCH that leave
    no restart room
12. **STEPLIB drift**: jobs whose STEPLIB differs from the site-standard
    library concatenation — flags out-of-band program overrides
13. **Dataset-coupling map**: producer/consumer pairs that share datasets
    across jobs (hidden edges to graph in item 3)
14. **Time-window violations**: jobs scheduled to start before their
    predecessors typically complete (calendar/duration conflict)
15. **PROC-depth distribution**: number of nested PROC levels per job —
    flag >3 as maintainability risk
16. **Instream SYSIN complexity**: jobs with >100 lines of SYSIN instream —
    candidates for extracting into a real program
17. **Retired-dataset references**: DSNs that no longer exist in catalog
    but are still referenced (ghost references — will fail on next run)
18. **Owner gaps**: jobs without current NOTIFY= or with orphaned user IDs

## 12. Sample JCL Snippet (Heavily Commented)

```
//RMSD05   JOB (AIT,RMS,PRD),'DAILY AIRMAN EXTRACT',           Job card
//             CLASS=A,                                        Prod initiator class
//             MSGCLASS=X,                                     Held output for ops
//             NOTIFY=&SYSUID,                                 TSO notify
//             REGION=0M,TIME=1440                             1440 CPU-min cap
//*
//* RMS Daily Airman Cert Extract  --  runs 02:15 ET Mon-Sat
//* Reads ADABAS airman file, produces flat file for downstream SFTP
//* Predecessors (Control-M): RMSD00 (nightly online shutdown)
//* Successors:               RMSD10 (SFTP to TSA), RMSD15 (print)
//*
//JOBLIB   DD DSN=AIT.RMS.PRD.LOADLIB,DISP=SHR                 Program library
//         DD DSN=SYS2.NATURAL.LOAD,DISP=SHR                   Runtime library
//*---------------------------------------------------------------*
//STEP010  EXEC PGM=IEFBR14                                    No-op step:
//DELETE   DD DSN=AIT.RMS.PRD.AIRMAN.EXTRACT.WORK,             allocate to force
//             DISP=(MOD,DELETE,DELETE),                       cleanup of yesterday's
//             UNIT=SYSDA,SPACE=(TRK,0)                        working dataset
//*---------------------------------------------------------------*
//STEP020  EXEC PGM=NATRT82,                                   NATURAL runtime
//             PARM='SYS=RMSPROD,LIB=RMSLIB',                  Session parms
//             COND=(0,NE,STEP010)                             Skip if STEP010 != 0
//STEPLIB  DD DSN=AIT.RMS.PRD.NATLOAD,DISP=SHR                 Override JOBLIB
//CMSYNIN  DD DSN=AIT.RMS.PRD.PARMLIB(DAILYEXT),DISP=SHR       Natural input
//CMPRINT  DD SYSOUT=*                                         Natural echo
//EXTRACT  DD DSN=AIT.RMS.PRD.AIRMAN.EXTRACT(+1),              New GDG generation
//             DISP=(NEW,CATLG,DELETE),                        Keep on OK, drop on abend
//             UNIT=SYSDA,                                     Disk volume group
//             SPACE=(CYL,(500,100),RLSE),                     Primary/secondary + release
//             DCB=(RECFM=FB,LRECL=4000,BLKSIZE=0)             System-determined BLKSIZE
//SYSUDUMP DD SYSOUT=*                                         Abend dump target
//*---------------------------------------------------------------*
//STEP030  EXEC PGM=IEBGENER,COND=EVEN                         Always run (cleanup)
//SYSUT1   DD DSN=&&AUDIT,DISP=(OLD,DELETE)                    Temp audit file
//SYSUT2   DD DSN=AIT.RMS.PRD.AUDIT.LOG,DISP=MOD               Append to log
//SYSPRINT DD SYSOUT=*
//SYSIN    DD DUMMY
//
```

Key points the skill should surface from this snippet:
- Business logic is entirely inside NATURAL (STEP020); JCL is the wrapper
- `COND=(0,NE,STEP010)` means STEP020 skips if STEP010 failed (IEFBR14 should
  never fail unless allocation broke — if it does, no point extracting)
- `COND=EVEN` on STEP030 ensures audit log is always updated, including after
  abends
- GDG `EXTRACT(+1)` must have a matching GDG base defined in catalog
- Plaintext runtime parms in PARM= are not secrets here but worth checking

*See `natural-patterns.md` for what happens inside NATRT82 when STEP020 runs.*
