#!/usr/bin/env python3
"""Detect mainframe platforms in a source tree.

Walks a source directory and reports which mainframe-family platforms are
present, with per-platform file counts and a small sample of evidence
paths. Output is a single JSON document printed to stdout so callers (the
mainframe-discovery-patterns skill, and the Phase-1 prescan in
``olympus/olympus/fsm/prescan.py``) can consume it directly.

Detection rules (all case-insensitive for filename matching):
    natural        — ``.nsn``, ``.nsp``, ``.nss``, ``.nsr``, ``.nsb``
    adabas         — ``.nsd``
    jcl            — ``.jcl``
    cobol          — ``.cbl``, ``.cob``, ``.pli``
    cics           — any COBOL/PL-I file containing ``EXEC CICS``
    bms            — ``.bms``, ``.nsm``
    copybook       — ``.cpy``, ``.copy``
    tiff           — ``.tiff``, ``.tif`` (count only; no evidence enumeration)
    broker_config  — filenames matching ``etbclient*``, ``entirex*``,
                     or ``broker*.cfg`` (case-insensitive)
    ewf_config     — filenames matching ``iwfeng*``, ``ecmengine*``,
                     ``ewf*.config``, ``unisys*.config`` (case-insensitive)

Scans are capped by ``--max-files`` (default 5000) to bound cost on very
large corpora. Common build/dep dirs are skipped.

CLI:
    python detect_mainframe_stack.py <source_path> [--max-files N]
"""
from __future__ import annotations

import argparse
import json
import re
import sys
from collections import defaultdict
from pathlib import Path

# Dirs we never descend into — they pollute counts with deps/artifacts.
_SKIP_DIRS = frozenset({
    ".git", "node_modules", "bin", "obj", "target", "dist", "build",
    ".venv", "venv", "__pycache__",
})

# Extension → platform key. Lower-cased suffix lookup.
_EXT_MAP: dict[str, str] = {
    ".nsn": "natural", ".nsp": "natural", ".nss": "natural",
    ".nsr": "natural", ".nsb": "natural",
    ".nsd": "adabas",
    ".jcl": "jcl",
    ".cbl": "cobol", ".cob": "cobol", ".pli": "cobol",
    ".bms": "bms", ".nsm": "bms",
    ".cpy": "copybook", ".copy": "copybook",
    ".tiff": "tiff", ".tif": "tiff",
}

# Config filename patterns — match against the lower-cased filename.
_BROKER_PATTERNS = (
    re.compile(r"^etbclient.*", re.IGNORECASE),
    re.compile(r"^entirex.*", re.IGNORECASE),
    re.compile(r"^broker.*\.cfg$", re.IGNORECASE),
)
_EWF_PATTERNS = (
    re.compile(r"^iwfeng.*", re.IGNORECASE),
    re.compile(r"^ecmengine.*", re.IGNORECASE),
    re.compile(r"^ewf.*\.config$", re.IGNORECASE),
    re.compile(r"^unisys.*\.config$", re.IGNORECASE),
)

# Maximum evidence paths we retain per platform (rest counted, not stored).
_MAX_EVIDENCE_PER_PLATFORM = 10
# Bytes to read when scanning a COBOL file for `EXEC CICS` — ~64 KB is
# more than enough to catch embedded SQL/CICS preludes without slurping
# whole copybook-heavy programs.
_CICS_SCAN_BYTES = 65536
_CICS_MARKER = b"EXEC CICS"


def _is_broker_config(name_lower: str) -> bool:
    return any(p.match(name_lower) for p in _BROKER_PATTERNS)


def _is_ewf_config(name_lower: str) -> bool:
    return any(p.match(name_lower) for p in _EWF_PATTERNS)


def _has_cics_marker(path: Path) -> bool:
    try:
        with path.open("rb") as handle:
            chunk = handle.read(_CICS_SCAN_BYTES)
    except OSError:
        return False
    # Case-insensitive substring check on bytes — `EXEC CICS` is always
    # uppercase in mainframe source, but we normalize to be safe.
    return _CICS_MARKER in chunk.upper()


def scan(source_path: Path, max_files: int) -> dict:
    """Walk ``source_path`` and collect platform evidence. Stops after
    ``max_files`` files (not counting skipped dirs)."""
    file_counts: dict[str, int] = defaultdict(int)
    evidence: dict[str, list[str]] = defaultdict(list)
    total = 0
    for path in source_path.rglob("*"):
        # Skip directories as a whole when they match the deny list.
        if path.is_dir():
            if path.name in _SKIP_DIRS:
                # rglob still descends; we filter children below.
                continue
            continue
        # Filter children of skipped dirs.
        if any(part in _SKIP_DIRS for part in path.parts):
            continue
        if not path.is_file():
            continue
        total += 1
        if total > max_files:
            break

        suffix = path.suffix.lower()
        name_lower = path.name.lower()
        platform = _EXT_MAP.get(suffix)
        if platform:
            file_counts[platform] += 1
            # `tiff` is counted but never enumerated — corpora can hold
            # tens of millions of images and enumeration is wasteful.
            if platform != "tiff" and len(evidence[platform]) < _MAX_EVIDENCE_PER_PLATFORM:
                evidence[platform].append(str(path.relative_to(source_path)))
            # For COBOL/PL-I, check for embedded CICS.
            if platform == "cobol" and _has_cics_marker(path):
                file_counts["cics"] += 1
                if len(evidence["cics"]) < _MAX_EVIDENCE_PER_PLATFORM:
                    evidence["cics"].append(str(path.relative_to(source_path)))

        # Config filename patterns are independent of extension.
        if _is_broker_config(name_lower):
            file_counts["broker_config"] += 1
            if len(evidence["broker_config"]) < _MAX_EVIDENCE_PER_PLATFORM:
                evidence["broker_config"].append(str(path.relative_to(source_path)))
        if _is_ewf_config(name_lower):
            file_counts["ewf_config"] += 1
            if len(evidence["ewf_config"]) < _MAX_EVIDENCE_PER_PLATFORM:
                evidence["ewf_config"].append(str(path.relative_to(source_path)))

    platforms = sorted(k for k, v in file_counts.items() if v > 0)
    return {
        "platforms": platforms,
        "file_counts": dict(file_counts),
        "evidence_paths": {k: sorted(v) for k, v in evidence.items()},
        "total_files_scanned": min(total, max_files),
    }


def _parse_args(argv: list[str]) -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Detect mainframe platforms in a source tree.",
    )
    parser.add_argument("source_path", type=Path, help="Directory to scan")
    parser.add_argument(
        "--max-files", type=int, default=5000,
        help="Cap the number of files scanned (default: 5000)",
    )
    return parser.parse_args(argv)


def main(argv: list[str] | None = None) -> int:
    args = _parse_args(argv or sys.argv[1:])
    root = args.source_path
    if not root.exists() or not root.is_dir():
        print(
            json.dumps({"error": f"not a directory: {root}"}),
            file=sys.stderr,
        )
        return 2
    result = scan(root, max_files=max(1, args.max_files))
    print(json.dumps(result, indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
