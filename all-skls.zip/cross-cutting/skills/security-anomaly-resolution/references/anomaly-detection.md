# Anomaly Detection — George SRS Methodology (Step 2)

Identify requirement-implementation gaps and structural defects that security
scanners cannot detect. These are logic-level anomalies that require semantic
understanding of the specification and its implementation.

## 2a. Requirement-Implementation Gap Analysis

Compare the specification (SRS, user stories, business rules) against the
actual implementation:
- **Missing implementations**: Spec says feature X exists; code does not implement it
- **Contradictory implementations**: Spec says behavior A; code implements behavior B
- **Over-implementations**: Code implements behavior not specified (scope creep or hidden features)
- **Partial implementations**: Spec requires 5 validations; code implements 3

For each gap, record:
```
ANOMALY-{nnn}: Requirement-Implementation Gap
  Spec Reference: {spec-document}:{section}:{requirement-id}
  Code Reference:  {repo}:{file}:{line-range}
  Gap Type:        Missing | Contradictory | Over-implementation | Partial
  Description:     [What the spec says vs. what the code does]
  Security Impact: [None | Low | Medium | High | Critical]
```

## 2b. Trust Boundary Validation

Detect missing input validation at trust boundaries:
- **External input boundaries**: HTTP request parameters, file uploads, API payloads, message queue messages
- **Internal trust boundaries**: Calls between modules with different privilege levels, cross-service calls
- **Data store boundaries**: Data read from databases, caches, or files that may have been tampered with
- **User-to-system boundaries**: Form inputs, URL parameters, cookies, headers

For each boundary, verify:
1. Input length validation exists
2. Input type validation exists (numeric, date, enum, pattern)
3. Input range validation exists (min/max for numbers, allowed values for enums)
4. Output encoding exists (HTML encoding for web output, parameterized queries for SQL)
5. Content-type validation exists (file uploads, API payloads)

## 2c. Authentication/Authorization Bypass Detection

Scan for patterns that enable bypass:
- **Direct object references**: URLs or parameters that reference internal IDs without authorization checks
- **Horizontal privilege escalation**: User A can access User B's data by changing an ID parameter
- **Vertical privilege escalation**: Regular user can access admin functions by knowing the URL
- **Missing authentication on API endpoints**: Endpoints callable without a session or token
- **Role confusion**: Different parts of the code check different role names for the same permission
- **Session state manipulation**: Session values trusted without re-validation after modification

## 2d. Unsafe Data Handling

Identify PII exposure, credential storage, and data leakage:
- **PII in logs**: SSN, email, name, address, phone written to log files
- **Credentials in source**: Hardcoded passwords, API keys, connection strings
- **Credentials in configuration**: Plaintext credentials in config files committed to source control
- **PII in error messages**: Stack traces or error details exposed to end users containing PII
- **Session data exposure**: Sensitive data stored in client-side cookies or local storage
- **Cache poisoning**: Sensitive data stored in shared caches without user isolation

## 2e. Concurrency Issues

Detect race conditions and concurrency problems:
- **TOCTOU (Time of Check to Time of Use)**: Authorization check and data access not atomic
- **Double-spend / double-submit**: Form submission without idempotency tokens
- **Lock contention**: Database row locks held across user interactions (conversational transactions)
- **Stale read**: Decisions made on data that may have been modified by another process

## 2f. Error Handling Gaps

Find missing or insecure error handling:
- **Swallowed exceptions**: catch blocks that log but do not propagate or handle the error
- **Missing error paths**: Happy path implemented but failure path undefined
- **Information leakage in errors**: Stack traces, SQL errors, or internal paths exposed to users
- **Missing rollback**: Transaction started but not rolled back on error
- **Default-allow on error**: System grants access when an authorization check throws an exception
