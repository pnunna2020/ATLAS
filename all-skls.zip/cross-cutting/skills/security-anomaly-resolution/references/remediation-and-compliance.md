# Remediation and Compliance (Steps 4 and 5)

Provides the actionable remediation guidance and compliance gap resolution
workflow invoked after triage (Step 1) and anomaly detection (Step 2).

## Step 4: Remediation Recommendations

Provide actionable, code-level remediation for every finding.

### 4a. Per-Finding Remediation

Each finding receives:
```
FINDING-{nnn}: {title}
  Category:       {OWASP category}
  Severity:       {CVSS score or equivalent}
  Priority:       {P0 | P1 | P2 | P3}
  Source:         {repo}:{file}:{line}
  Control:        {NIST 800-53 control ID}
  Description:    [What is wrong and why it is a risk]
  Remediation:    [Step-by-step fix instructions]
  Code Before:    [Vulnerable code snippet]
  Code After:     [Fixed code snippet]
  Effort:         {S | M | L | XL} — estimated lines of code and complexity
  Test Required:  [Regression test specification for validating the fix]
  Alternative:    [Mitigation if fix is too costly — WAF rule, config change, etc.]
```

### 4b. Remediation Plan (Order of Operations)

Order remediation work for maximum efficiency:
1. **Infrastructure fixes first**: TLS configuration, header policies, secrets rotation — these are zero-code-change fixes that reduce overall exposure immediately
2. **Shared component fixes second**: Fix vulnerable libraries used by many modules once, rather than per-module
3. **Gate-blocking P0 fixes third**: Any finding that blocks the next gate
4. **Module-grouped P1 fixes fourth**: Batch by module so each code review covers multiple findings
5. **P2/P3 fixes last**: Scheduled into sustainment backlog or accepted with risk documentation

### 4c. Effort Estimation

| Size | Lines of Code | Complexity | Example |
|------|--------------|------------|---------|
| S | 1-10 | Trivial | Add CSP header, fix a single SQL injection |
| M | 11-50 | Low | Refactor authentication flow for one module |
| L | 51-200 | Medium | Replace custom crypto with standard library across a module |
| XL | 200+ | High | Redesign session management architecture |

### 4d. Regression Test Requirements

Every remediation must specify its validation test:
- **Unit test**: For function-level fixes (input validation, encoding)
- **Integration test**: For cross-component fixes (authentication flow, authorization chain)
- **Security scan**: Re-run the scanner that detected the original finding to confirm resolution
- **Penetration test**: For P0 findings in Tier 1 applications

## Step 5: Compliance Gap Resolution

Map unresolved findings to compliance control failures and generate artifacts
for gate reviews.

### 5a. Control-Finding Matrix

Build a matrix of compliance controls to security findings:

```
Control   | Status   | Findings                    | Resolution
----------|----------|-----------------------------|-----------
AC-3      | PARTIAL  | FINDING-007, FINDING-012    | In remediation (Sprint 4)
AU-2      | FAIL     | FINDING-023                 | POA&M — target: 30 days post-ATO
SC-8      | PASS     | (none)                      | TLS 1.2+ enforced via ALB
SC-28     | PASS     | (none)                      | AES-256 via Aurora KMS
SI-10     | FAIL     | FINDING-001, FINDING-003    | In remediation (Sprint 3)
IA-5      | PARTIAL  | FINDING-015                 | MFA migration in progress
```

### 5b. Compliance Exception Requests

For accepted risks (findings that will not be remediated before deployment):
```
EXCEPTION-{nnn}: {title}
  Finding:        {FINDING-ID}
  Control:        {NIST control}
  Risk Level:     {Low | Medium | High}
  Justification:  [Why remediation is not feasible before deployment]
  Compensating Controls: [What mitigations are in place]
  Expiration:     [Date by which the finding must be resolved]
  Approver:       [Role required to approve — ISSO, AO, Safety Board]
```

### 5c. Evidence Artifacts for Resolved Findings

For each resolved finding, generate evidence for the gate review package:
- Before/after code diff showing the fix
- Test execution results proving the fix works
- Re-scan results showing the finding is no longer detected
- Traceability link: `{FINDING-ID} → {commit-SHA} → {test-result}`

### 5d. cATO Impact Assessment

Assess impact on the continuous Authority to Operate:
- **New controls satisfied**: Which controls move from FAIL/PARTIAL to PASS
- **Residual risk delta**: How the overall risk posture changes after remediation
- **POA&M updates**: Which Plan of Action and Milestones items are closed
- **Monitoring requirements**: What continuous monitoring must be in place for accepted risks
- **ATO boundary changes**: Does the remediation change what is in/out of the authorization boundary
