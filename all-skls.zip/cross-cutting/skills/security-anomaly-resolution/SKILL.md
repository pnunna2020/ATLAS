---
name: security-anomaly-resolution
description: >
  Triage, prioritize, and resolve security findings and requirement anomalies
  using merged George SRS anomaly resolution methodology with security posture
  analysis. Use during Validation Stream 2 and pre-gate remediation. Triggers
  on security triage, vulnerability resolution, anomaly detection, remediation
  planning, compliance gap resolution, or @security-anomaly-resolution mentions.
agent: opus
allowed-tools:
  - Read
  - Write
  - Bash
  - Grep
---

# Security Anomaly Resolution

## Relationship to Sibling Security Skills
- **security-scan-review** (upstream): consumes raw scanner output (SonarQube,
  SAST, DAST, SCA) and emits a triaged finding list with each item classified
  TRUE_POSITIVE / FALSE_POSITIVE / ACCEPTED_RISK. Runs at the **G-04c** gate.
- **security-anomaly-resolution** (this skill, downstream): consumes the
  triaged finding list plus George SRS anomaly detection results, maps every
  item to OWASP Top 10 and NIST 800-53 Rev 5 controls, prioritizes via
  composite risk score, and emits a remediation plan with effort estimates,
  before/after code samples, a compliance gap matrix, and gate-ready evidence
  artifacts. Runs during **Validation Stream 2** pre-gate remediation ahead of
  **G-V2** (Security Certification).
- Do not invoke this skill before `security-scan-review` has run — this skill
  assumes findings are already deduped and severity-classified. Feeding raw
  scanner output into this skill produces remediation plans dominated by false
  positives and wastes reviewer cycles.
- Downstream of this skill: `gate-review-package`, `cato-compliance`, and re-
  validation via `security-scan-review` on the remediated branch.

## Purpose
Merge George SRS (Software Requirements Specification) anomaly resolution
methodology with security posture analysis to provide a unified approach to
triaging, prioritizing, and resolving security findings and requirement
anomalies. This skill bridges the gap between security scanning output and
actionable remediation — turning raw findings into a prioritized, estimated,
compliance-mapped remediation plan ready for gate review.

## Inputs
- Security posture analysis artifact (from `security-posture-analyzer`)
- Compliance analysis artifact (from `cato-compliance` or `ea-compliance`)
- Source code discovery artifact (from `analyze-application`)
- Extraction artifact — module inventory (from `extraction`)
- Risk tier classification (from client profile)
- Active client compliance profile (e.g., `profiles/faa/compliance.yaml`)

## Outputs
- Security finding triage report (prioritized, categorized by OWASP Top 10)
- Anomaly catalog with requirement-to-implementation traceability
- Remediation plan (ordered by priority, estimated effort, with code examples)
- Compliance gap analysis with resolution status per NIST/FedRAMP control
- Risk acceptance recommendations for gate review
- Metrics summary: total findings, resolved, deferred, accepted risk count

## Process

### Step 1: Vulnerability Triage
Classify and contextualize every security finding against OWASP Top 10, map
CVEs to affected modules, score exploitability in the deployment context,
cross-reference NIST 800-53 controls, and identify false positives with
evidence.

See `references/vulnerability-triage.md` for the full OWASP category table,
the CVE-to-module mapping procedure, the exploitability scoring checklist,
the NIST 800-53 finding-type crosswalk, and the false-positive documentation
format.

### Step 2: Anomaly Detection (George SRS Methodology)
Identify logic-level anomalies that scanners miss: requirement-implementation
gaps, trust boundary violations, auth bypass patterns, unsafe data handling,
concurrency issues, and error-handling gaps.

See `references/anomaly-detection.md` for the six anomaly categories, the
per-anomaly record format, and the detection heuristics for each category.

### Step 3: Risk Prioritization

Score and rank every finding from Steps 1 and 2.

#### 3a. Scoring Formula

Each finding receives a composite score:

```
Priority Score = Severity × Exploitability × Asset Criticality

Where:
  Severity (1-10):        CVSS base score or equivalent for anomalies
  Exploitability (0.1-1): How easy to exploit in the deployed context
  Asset Criticality (1-3): Risk tier from client profile (Tier 1 = 3, Tier 2 = 2, Tier 3 = 1)
```

| Score Range | Priority | Action |
|-------------|----------|--------|
| 20-30 | P0 — Critical | Must fix before any gate. Blocks deployment. |
| 10-19 | P1 — High | Must fix before G-V2 security certification gate. |
| 5-9 | P2 — Medium | Should fix before G-DP-1 deployment gate. Deferral requires risk acceptance. |
| 1-4 | P3 — Low | Fix during sustainment. Document in POA&M. |

#### 3b. Module Grouping

Group findings by module for efficient remediation:
- If Module X has 12 findings, a developer fixing one can fix all 12 in the same code review
- Identify modules with the highest finding density (findings per KLOC)
- Flag modules where findings span multiple OWASP categories (indicates systemic issues)

#### 3c. Quick Win Identification

Flag findings that are low effort and high impact:
- **Configuration changes**: Enabling HTTPS, setting secure cookie flags, disabling debug mode
- **Library upgrades**: Bumping a dependency version to fix a known CVE
- **Header additions**: Adding CSP, X-Frame-Options, X-Content-Type-Options headers
- **One-line fixes**: Replacing `md5()` with `password_hash()`, adding parameterized queries

#### 3d. Deployment Gate Blockers

Flag findings that will block specific gates:
- **G-04c (Code Complete)**: No critical security findings in generated code
- **G-V2 (Security Certification)**: Zero critical vulnerabilities, all NIST controls mapped
- **G-DP-1 (Pre-Production)**: All P0/P1 findings resolved, P2 findings have risk acceptance
- **G-DP-2 (Production)**: ATO boundary transition complete, cATO monitoring active

### Step 4: Remediation Recommendations
Produce per-finding remediation records (category, severity, priority, source
location, NIST control, before/after code, effort, required regression test),
order the remediation plan by infrastructure → shared components → gate
blockers → module-grouped → deferred, and estimate effort with the S/M/L/XL
sizing scale.

See `references/remediation-and-compliance.md` for the per-finding record
template, the order-of-operations rules, the effort-sizing table, and the
regression test requirements.

### Step 5: Compliance Gap Resolution
Build the control-finding matrix, raise compliance exception requests for
accepted risks, attach evidence artifacts to resolved findings, and assess
cATO impact (controls satisfied, residual risk delta, POA&M updates,
monitoring, ATO boundary changes).

See `references/remediation-and-compliance.md` for the control-matrix
template, the exception request format, the evidence artifact checklist, and
the cATO impact assessment framework.

## Tech-Stack Dispatch

Before triage, detect the source technology and load appropriate vulnerability patterns:
- ColdFusion → common: SQL injection in `cfquery`, XSS in `cfoutput`, session fixation
- Java EE → common: JNDI injection, deserialization, XXE, broken access control in EJBs
- .NET WebForms → common: ViewState tampering, event validation bypass, SQL injection in code-behind
- NATURAL/ADABAS → common: batch authorization bypass, GDA data leakage, NATURAL Security gaps
- PHP → common: `eval()`, `unserialize()`, SQL injection, file inclusion (LFI/RFI)
- Node.js → common: prototype pollution, RegExp DoS, insecure `child_process`, npm supply chain

## Risk Tier Scaling

| Tier | Triage Depth | Anomaly Detection | Remediation Review | Gate Requirements |
|------|-------------|-------------------|--------------------|-------------------|
| Tier 1 | Full triage with threat model cross-reference | All 6 anomaly categories + safety-critical analysis | Safety review board + IV&V | Zero P0/P1 findings. Zero accepted risk for safety-critical controls. Formal threat model required. |
| Tier 2 | Full triage | All 6 anomaly categories | Architecture lead review | Zero P0 findings. P1 findings require remediation plan with timeline. |
| Tier 3 | Standard triage (automated + spot-check) | Trust boundary + unsafe data handling | Automated verification + peer review | Zero P0 findings. P1/P2 deferral allowed with POA&M. |

## Gotchas

- **Security scanners produce noise**: Expect 20-40% false positive rates from
  automated scanners. Every finding must be validated against the actual code
  before entering the remediation plan. Do not ship raw scanner output as a
  triage report.
- **Anomaly detection requires specs**: The George SRS methodology compares
  implementation against specification. If specs are missing or incomplete, run
  `srs-from-discovery` first to generate the specification baseline.
- **Remediation order matters**: Fixing a shared library vulnerability before
  fixing individual module issues prevents duplicate work. Infrastructure
  fixes (TLS, headers, secrets) should always precede code fixes.
- **cATO is continuous, not one-time**: Resolving findings for the initial ATO
  is not sufficient. Continuous monitoring must be established for every accepted
  risk and every control that depends on runtime configuration.
- **Tier 1 safety-critical findings cannot be deferred**: For Tier 1 applications,
  findings that affect safety-critical functionality have zero deferral tolerance.
  The safety board will reject any POA&M that defers safety-critical security findings.
- **Code examples must be syntactically valid**: Remediation code snippets are
  consumed by downstream generation skills. Invalid syntax causes generation
  failures. Validate all code examples before including them.

## Quality Rules
- [ ] Every finding has a severity score (CVSS or equivalent) and a priority classification (P0-P3)
- [ ] Every finding has a remediation recommendation with step-by-step instructions
- [ ] Every finding traces to a specific source code location in `{repo}:{file}:{line}` format
- [ ] Remediation code examples (before/after) are syntactically valid for the target language
- [ ] Compliance mappings reference specific NIST 800-53 Rev 5 control IDs (not just control families)
- [ ] False positive determinations include written justification with evidence citations
- [ ] Remediation plan is ordered by priority (P0 first) and grouped by module for efficiency
- [ ] Gate-blocking findings (P0 for any gate, P1 for G-V2) are explicitly flagged with the gate they block
- [ ] All Tier 1 findings that affect safety-critical functionality are flagged as non-deferrable
- [ ] Compliance exception requests include compensating controls and expiration dates
- [ ] Evidence artifacts for resolved findings include before/after diffs and re-scan results
- [ ] Metrics summary includes counts for: total, resolved, deferred, false positive, and accepted risk

## Common Failure Modes

| Failure Mode | Symptom | Prevention |
|-------------|---------|------------|
| Raw scanner output shipped as triage | Report contains 500 findings; 200 are false positives; reviewers lose trust in the process | Validate every finding against actual code; document false positives with evidence |
| Anomaly detection without specs | George SRS methodology produces vague "potential gaps" instead of concrete anomalies | Run `srs-from-discovery` first to establish a specification baseline |
| Remediation plan without ordering | Developers fix easy issues first instead of gate-blockers; G-V2 gate still fails | Order by priority score and flag gate-blocking findings explicitly |
| Library fix skipped; module fixes done individually | Same CVE fixed 12 different ways in 12 modules instead of one library upgrade | Group findings by component; fix shared libraries before individual modules |
| Tier 1 safety findings deferred to POA&M | Safety board rejects the gate review package; deployment blocked | Flag all Tier 1 safety-critical findings as non-deferrable from the start |
| Code examples with syntax errors | Downstream generation skill produces invalid code from remediation snippets | Validate all code examples for syntactic correctness before including in output |
| Compliance mapping at family level only | ISSO rejects SSP because controls are mapped to "AC" instead of "AC-3" | Always map to specific control IDs (e.g., AC-3, SI-10), not just families |
| Evidence artifacts missing re-scan | Gate reviewer cannot confirm the finding is actually resolved | Include re-scan results alongside before/after diffs for every resolved finding |

## Handoff Summary

When this skill completes, verify:
1. Every finding has a severity score, priority, OWASP category, NIST control mapping, and remediation recommendation
2. Anomaly catalog includes all requirement-implementation gaps with bidirectional traceability
3. Remediation plan is ordered, estimated, and grouped by module with explicit gate-blocker flags
4. Compliance gap matrix shows current status for every applicable NIST 800-53 control
5. Evidence artifacts exist for every resolved finding (diff, test result, re-scan)
6. Metrics summary is computed and ready for gate review package

Then proceed to: `gate-review-package` for gate submission, `cato-compliance` for OSCAL artifact generation, `security-scan-review` for re-validation, and gate `G-V2` for security certification
