# AWS GovCloud Constraints and Service Availability

## Overview
AWS GovCloud (US) is an isolated AWS region designed for sensitive workloads. It meets
FedRAMP High, DOD SRG IL2/IL4/IL5, ITAR, and other compliance requirements. However,
not all commercial AWS services are available in GovCloud, and those that are may have
feature limitations.

All FAA production workloads deploy to GovCloud. This reference documents service
availability, feature gaps, and pricing differences for every FAA-approved service.

## GovCloud Regions
| Region | Code | Status |
|--------|------|--------|
| US-Gov-West (Oregon) | us-gov-west-1 | Primary |
| US-Gov-East (Ohio) | us-gov-east-1 | DR / Secondary |

**Cross-region considerations:**
- Data transfer between GovCloud regions is billed
- Not all services support cross-region replication
- Route 53 operates globally but GovCloud-hosted zones are isolated

## FAA-Approved Service Availability Matrix

### Compute

| Service | GovCloud Available | Feature Gaps | Notes |
|---------|-------------------|--------------|-------|
| ECS Fargate | Yes | None significant | Full feature parity |
| Lambda | Yes | Graviton (ARM) support limited | x86_64 default; check arm64 availability |
| EC2 | Yes | Fewer instance types | Graviton instances may lag behind commercial |
| ECR | Yes | Enhanced scanning available | Scan on push recommended |

### Data

| Service | GovCloud Available | Feature Gaps | Notes |
|---------|-------------------|--------------|-------|
| Aurora PostgreSQL | Yes | Serverless v2 available | Verify latest engine version availability |
| Aurora Serverless v2 | Yes | None significant | ACU scaling same as commercial |
| DynamoDB | Yes | Global tables available (between GovCloud regions only) | Cannot replicate to commercial regions |
| S3 | Yes | All storage classes available | S3 Intelligent-Tiering available |
| ElastiCache Redis | Yes | Redis 7.x available | Verify specific minor version |
| Redshift Serverless | Yes | Check RPU limits | May have lower max RPU than commercial |
| RDS Proxy | Yes | PostgreSQL support | Available for Aurora PostgreSQL |

### Integration

| Service | GovCloud Available | Feature Gaps | Notes |
|---------|-------------------|--------------|-------|
| EventBridge | Yes | Pipes available, some sources limited | Verify specific pipe sources |
| SQS | Yes | Standard and FIFO | Full feature parity |
| SNS | Yes | All delivery types | Full feature parity |
| Step Functions | Yes | Standard and Express | Full feature parity |
| API Gateway (REST/HTTP) | Yes | NOT APPROVED - use Gravitee | Available but not to be used |

### Identity and Security

| Service | GovCloud Available | Feature Gaps | Notes |
|---------|-------------------|--------------|-------|
| KMS | Yes | FIPS 140-2 validated | Required for all encryption |
| IAM | Yes | Full feature set | Same as commercial |
| ACM | Yes | Certificate provisioning | For ALB/CloudFront TLS |
| WAF v2 | Yes | All managed rule groups | Attach to CloudFront and ALB |
| Secrets Manager | Yes | NOT APPROVED for privileged creds - use CyberArk | Available but not primary |
| SSM Parameter Store | Yes | For non-sensitive config only | Feature flags, endpoints |

### Monitoring

| Service | GovCloud Available | Feature Gaps | Notes |
|---------|-------------------|--------------|-------|
| CloudWatch | Yes | Full metrics, logs, alarms | Supplemental to Datadog |
| X-Ray | Yes | Tracing for Lambda, Step Functions | Distributed tracing |
| CloudWatch Logs Insights | Yes | Query language available | For ad-hoc log analysis |

### Networking

| Service | GovCloud Available | Feature Gaps | Notes |
|---------|-------------------|--------------|-------|
| VPC | Yes | Full feature set | Private subnets, NAT, flow logs |
| ALB | Yes | Full feature set | Layer 7 load balancing |
| NLB | Yes | Full feature set | Layer 4, if needed |
| CloudFront | Yes | GovCloud-specific edge locations | Fewer edge locations than commercial |
| Route 53 | Yes | Health checks, DNS failover | GovCloud-hosted zones isolated |
| Direct Connect | Yes | Dedicated connections | For on-prem connectivity |
| VPN (Site-to-Site) | Yes | Full feature set | Alternative to Direct Connect |
| Cloud Map | Yes | Service discovery | For inter-service DNS |

### CI/CD

| Service | GovCloud Available | Feature Gaps | Notes |
|---------|-------------------|--------------|-------|
| CodeDeploy | Yes | ECS blue/green supported | For deployment automation |
| CodePipeline | Yes | NOT primary - use GitHub Actions | Available but not FAA standard |
| CodeBuild | Yes | NOT primary - use GitHub Actions | Available but not FAA standard |

### Analytics

| Service | GovCloud Available | Feature Gaps | Notes |
|---------|-------------------|--------------|-------|
| QuickSight | Yes | Enterprise edition | OKTA SSO, RLS, SPICE |
| Athena | Yes | Federated queries available | SQL on S3 |
| Glue | Yes | Catalog, crawlers, ETL | Verify Glue Studio availability |
| DMS | Yes | Full feature set | Database migration service |

### AI/ML (Reference Only)

| Service | GovCloud Available | Feature Gaps | Notes |
|---------|-------------------|--------------|-------|
| Bedrock | Limited | Model availability varies | Check specific model availability |
| SageMaker | Yes | Some features may lag | Verify specific feature availability |
| Comprehend | Yes | Limited feature set | NLP capabilities |
| Textract | Yes | Document processing | OCR and form extraction |
| Rekognition | Yes | Limited | Image analysis |

**Important:** AI/ML service availability changes frequently. Always verify against
the latest AWS GovCloud documentation before including in an architecture blueprint.

## Services NOT Available in GovCloud

The following services commonly referenced in commercial architectures are either
not available or have significant limitations in GovCloud:

| Service | Status | Alternative |
|---------|--------|------------|
| App Runner | Not available | ECS Fargate |
| Amplify | Not available | S3 + CloudFront |
| AppSync | Limited | Custom GraphQL on Fargate |
| Cognito | Available but NOT APPROVED | OKTA (MANDATORY) |
| EKS Anywhere | Not available | EKS on GovCloud or ECS Fargate |
| IoT Core | Limited | EventBridge + Lambda |
| Lex (chatbot) | Not available | Bedrock-based alternative |
| Lightsail | Not available | EC2 or Fargate |
| Managed Grafana | Not available | Datadog (approved) |
| Managed Prometheus | Not available | Datadog (approved) |
| OpenSearch Serverless | Check availability | OpenSearch provisioned or Athena |
| Timestream | Check availability | DynamoDB with TTL |

## FedRAMP High Baseline Implications

All services used in GovCloud must meet FedRAMP High:

**Key controls affecting architecture:**
| Control | Requirement | Architecture Impact |
|---------|------------|-------------------|
| AC-2 | Account management | OKTA for all user accounts |
| AC-17 | Remote access | VPN or Direct Connect for admin access |
| AU-2 | Audit events | CloudWatch + Datadog logging for all actions |
| CM-2 | Baseline configuration | Terraform IaC for all infrastructure |
| IA-2 | Identification and authentication | MFA for all interactive users (OKTA) |
| SC-7 | Boundary protection | VPC with private subnets, WAF, security groups |
| SC-8 | Transmission confidentiality | TLS 1.2+ for all connections |
| SC-13 | Cryptographic protection | KMS FIPS 140-2 validated |
| SC-28 | Protection of information at rest | SSE-KMS for all data stores |

## Pricing Differences

GovCloud pricing is typically 5-15% higher than commercial regions for the same services:

| Service | Approximate Premium | Notes |
|---------|-------------------|-------|
| EC2 / Fargate | ~5-10% | Instance type dependent |
| RDS / Aurora | ~5-10% | Same feature set, higher price |
| S3 | ~5% | Storage and request pricing |
| Lambda | ~5% | Invocation and duration |
| Data Transfer | ~10% | Cross-region and internet egress |
| CloudFront | ~10% | Fewer edge locations in GovCloud |
| NAT Gateway | Same | No premium |
| KMS | Same | No premium |

**Cost estimation guidance:**
- Start with commercial region pricing from AWS calculator
- Apply 10% markup as a safe estimate for GovCloud
- Verify specific service pricing on the GovCloud pricing page
- Include data transfer costs (often underestimated in GovCloud)

## Region Selection Guidance

### Primary Region: us-gov-west-1 (Oregon)
- Default for all workloads
- Broadest service availability
- Most GovCloud customers are here (better peering)

### Secondary Region: us-gov-east-1 (Ohio)
- DR / failover for T1 applications
- Cross-region Aurora replica target
- S3 cross-region replication target
- Route 53 health check failover target

### When to Use Both Regions
- T1 applications: Active-passive across both regions
- T2 applications: Single region with cross-region backup (S3, Aurora snapshots)
- T3 applications: Single region only

## Pre-Blueprint Verification Checklist

Before finalizing any architecture blueprint, verify:
- [ ] Every AWS service is available in us-gov-west-1
- [ ] If T1, every service is available in both GovCloud regions
- [ ] Feature-level availability (not just service-level) is confirmed
- [ ] GovCloud-specific pricing is reflected in cost estimates
- [ ] No commercial-only features are referenced
- [ ] FedRAMP High controls are addressed for each service
- [ ] Data residency requirements are met (no cross-boundary data flow)
- [ ] Cross-region data transfer costs are included for T1 designs
