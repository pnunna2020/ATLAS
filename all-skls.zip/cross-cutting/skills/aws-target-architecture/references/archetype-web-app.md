# Archetype: Web Application (SPA + API + Database)

## Overview
Reference architecture for modernizing legacy web applications (ColdFusion, Oracle Forms,
Classic ASP, PHP, Java EE with JSF/Struts) into a modern SPA + API architecture on AWS
GovCloud.

This is the most common archetype in the FAA portfolio. Approximately 60% of applications
targeted for modernization fall into this category.

## Architecture Diagram (Text)

```
                                    +-----------+
                                    | Login.gov |  (external users only)
                                    +-----+-----+
                                          |
                                    +-----+-----+
                                    |   OKTA    |  (MANDATORY IdP)
                                    +-----+-----+
                                          |
                   +----------------------+----------------------+
                   |                                             |
            +------+------+                               +------+------+
            |  CloudFront |  (CDN + WAF)                  |  CloudFront |
            +------+------+                               +------+------+
                   |                                             |
            +------+------+                               +------+------+
            |   S3 (SPA)  |  (React + USWDS)             |  Gravitee   |  (MANDATORY API GW)
            +-------------+                               +------+------+
                                                                 |
                                                          +------+------+
                                                          |     ALB     |  (internal)
                                                          +------+------+
                                                                 |
                                                    +------------+------------+
                                                    |                         |
                                             +------+------+          +------+------+
                                             | ECS Fargate |          | ECS Fargate |
                                             | (Service A) |          | (Service B) |
                                             +------+------+          +------+------+
                                                    |                         |
                                             +------+------+          +------+------+
                                             |   Aurora    |          | ElastiCache |
                                             | PostgreSQL  |          |   Redis     |
                                             +-------------+          +-------------+
```

## Compute Tier

### ECS Fargate Service Configuration
ECS Fargate is the primary compute platform for web application backends. Fargate
eliminates EC2 instance management while providing container-level isolation.

**Task Definition:**
```
CPU: 0.25 vCPU (T3) | 0.5 vCPU (T2) | 1 vCPU (T1)
Memory: 0.5 GB (T3) | 1 GB (T2) | 2 GB (T1)
Platform version: 1.4.0 (latest)
Network mode: awsvpc
Runtime: Linux/ARM64 (Graviton) where supported
```

**Service Configuration:**
```
Desired count: 1 (T3) | 2 (T2) | 3 (T1)
Min capacity: 1 (T3) | 2 (T2) | 3 (T1)
Max capacity: 2 (T3) | 6 (T2) | 12 (T1)
Health check grace period: 60s
Deployment type: Blue/Green (CodeDeploy)
Circuit breaker: enabled (rollback on failure)
```

**Auto-Scaling Policies:**
- Target tracking: CPU utilization at 70%
- Target tracking: Memory utilization at 80%
- Scheduled scaling: Scale up 30 min before known peak hours
- Scale-in cooldown: 300s (prevent flapping)
- Scale-out cooldown: 60s (respond quickly to load)

**Health Checks:**
- ALB health check: `GET /health` every 30s, 3 consecutive failures = unhealthy
- ECS health check: `CMD-SHELL curl -f http://localhost:8080/health || exit 1`
- Readiness probe: `GET /ready` (checks database connectivity, cache availability)
- Graceful shutdown: SIGTERM handler with 30s drain period

**Blue-Green Deployment:**
- CodeDeploy deployment group with ECS blue/green
- Traffic shifting: AllAtOnce (T3), Linear10PercentEvery1Minute (T2), Canary10Percent5Minutes (T1)
- Automatic rollback on: deployment failure, CloudWatch alarm trigger
- Hook functions: BeforeAllowTraffic (smoke tests), AfterAllowTraffic (integration tests)

### Container Image
```
Base image: python:3.12-slim (FastAPI) | eclipse-temurin:21-jre (Spring Boot)
Multi-stage build: yes (build stage + runtime stage)
Image scanning: ECR enhanced scanning enabled
Image signing: not required for T3, required for T1/T2
Registry: ECR (private, encryption enabled)
```

## Data Tier

### Aurora PostgreSQL Serverless v2
Aurora PostgreSQL is the primary relational database for web applications. Serverless v2
provides auto-scaling without capacity planning.

**Cluster Configuration:**
```
Engine: aurora-postgresql 15.x
Instance class: db.serverless
Min ACU: 0.5 (T3) | 1 (T2) | 2 (T1)
Max ACU: 4 (T3) | 16 (T2) | 64 (T1)
Storage encryption: SSE-KMS (MANDATORY)
Backup retention: 7 days (T3) | 14 days (T2) | 35 days (T1)
Deletion protection: enabled
```

**Multi-AZ Configuration:**
- T3: Single writer instance (no replica) -- single AZ acceptable
- T2: Writer + 1 reader replica in different AZ
- T1: Writer + 2 reader replicas across AZs + cross-region read replica

**Connection Management:**
- PgBouncer sidecar on Fargate task (transaction pooling mode)
- Max connections per task: 20 (prevents connection exhaustion)
- Connection timeout: 5s
- Idle timeout: 300s
- RDS Proxy alternative: acceptable for T2/T1 if PgBouncer complexity is undesirable

**Backup and Recovery:**
- Automated snapshots: daily
- Point-in-time recovery: enabled (5-minute granularity)
- Cross-region backup: T1 only (us-gov-west-1 to us-gov-east-1)
- RTO: 1 hour (T3) | 15 minutes (T2) | 5 minutes (T1)
- RPO: 24 hours (T3) | 1 hour (T2) | 5 minutes (T1)

**Migration from Oracle:**
- AWS Schema Conversion Tool (SCT) for DDL conversion
- AWS Database Migration Service (DMS) for data migration
- PL/SQL to PostgreSQL PL/pgSQL conversion (manual review required)
- Oracle-specific features: CONNECT BY -> recursive CTE, ROWNUM -> ROW_NUMBER()
- Sequence migration: Oracle sequences -> PostgreSQL sequences (auto-mapped by SCT)

### ElastiCache Redis (If Needed)
Only include ElastiCache if the application requires:
- Server-side session storage (when JWT alone is insufficient)
- Application-level caching (frequently read, rarely written data)
- Rate limiting state (if Gravitee rate limiting alone is insufficient)

```
Engine: Redis 7.x
Node type: cache.t4g.micro (T3) | cache.t4g.small (T2) | cache.r7g.large (T1)
Cluster mode: disabled (T3) | disabled (T2) | enabled (T1)
Multi-AZ: no (T3) | yes (T2/T1)
Encryption at rest: yes (KMS)
Encryption in transit: yes (TLS)
Auth: Redis AUTH token from CyberArk
```

## Frontend

### React + USWDS SPA
All modernized FAA web applications use React with the US Web Design System (USWDS)
via the @trussworks/react-uswds component library.

**Technology Stack:**
```
Framework: React 18.x with TypeScript
UI Library: @trussworks/react-uswds 8.x
State management: React Query (server state) + Zustand (client state)
Routing: React Router 6.x
Build tool: Vite
Testing: Vitest + React Testing Library + Playwright (E2E)
```

**FAA Branding Requirements (MANDATORY):**
- USA banner: "An official website of the United States government" (top of every page)
- DOT ribbon: Department of Transportation identifier
- FAA logo: Federal Aviation Administration logo in header
- Font: Source Sans Pro (USWDS default)
- Primary color: #15396c (FAA blue)
- Secondary color: #d83933 (FAA red, accent only)
- Footer: Standard FAA footer with required links

**S3 Static Hosting:**
```
Bucket: private (no public access)
Website hosting: disabled (CloudFront serves content)
Versioning: enabled
Encryption: SSE-KMS
Lifecycle: Delete old versions after 90 days
```

**CloudFront Distribution (SPA):**
```
Origin: S3 bucket (OAC - Origin Access Control)
SSL: ACM certificate (*.app.faa.gov)
TLS: 1.3 minimum
WAF: AWS WAF v2 attached
Default root object: index.html
Error pages: 403/404 -> /index.html (SPA routing)
Cache policy: CachingOptimized for static assets
Origin request policy: CORS-S3Origin
Price class: PriceClass_100 (US, Canada, Europe)
Geo restriction: US only (for GovCloud compliance)
```

**WAF Rules (CloudFront):**
- AWS Managed Rules: Core Rule Set (CRS)
- AWS Managed Rules: Known Bad Inputs
- Rate limiting: 2000 requests per 5 minutes per IP
- IP reputation list: AWS IP reputation list
- Custom: Block non-US geographic origins (if required)

## API Layer

### FastAPI (Python) or Spring Boot (Java)
Target API framework depends on source technology (see Tech-Stack Dispatch in SKILL.md).

**FastAPI Configuration (for ColdFusion, PHP, Classic ASP migrations):**
```python
# Standard project structure
app/
  main.py           # FastAPI app, CORS, middleware
  api/
    v1/
      routes/       # Route modules by domain
      dependencies/ # Auth, DB session, rate limiting
  core/
    config.py       # Settings from environment variables
    security.py     # OKTA JWT validation
  models/
    domain/         # SQLAlchemy ORM models
    schemas/        # Pydantic request/response schemas
  services/         # Business logic layer
  repositories/     # Data access layer
```

**Spring Boot Configuration (for Java EE migrations):**
```
Spring Boot: 3.x
Java: 21 (LTS)
Build: Gradle (Kotlin DSL)
Layers: Controller -> Service -> Repository
ORM: Spring Data JPA (Hibernate)
Validation: Jakarta Bean Validation
Testing: JUnit 5 + Mockito + Testcontainers
```

**OpenAPI Specification:**
- Every API endpoint documented with OpenAPI 3.0
- Generated from code annotations (FastAPI auto-generates; Spring uses springdoc)
- Published to Gravitee developer portal
- Versioning: URL path versioning (`/api/v1/...`)

### Gravitee API Gateway Configuration
Gravitee is the MANDATORY API gateway for all external and cross-system API exposure.

**Route Configuration:**
```
Virtual host: api.{app-name}.faa.gov
Backend: ALB internal DNS
SSL: TLS termination at Gravitee
Auth: OKTA JWT validation (plan-level)
Rate limiting: Per consumer plan
  - Standard: 100 req/min
  - Premium: 1000 req/min
  - Internal: 5000 req/min
CORS: Configured per API (allow SPA origin)
Health check: Backend /health endpoint, 30s interval
Logging: Request/response logging to Datadog
```

**API Plans:**
- **Internal**: For FAA internal consumers, higher rate limits, mTLS optional
- **External**: For external consumers (if applicable), stricter rate limits, API key required
- **System**: For service-to-service calls, client credentials, highest rate limits

## Authentication and Authorization

### OKTA OIDC Flow (SPA)
```
Flow: Authorization Code + PKCE
Client type: SPA (public client)
Redirect URI: https://{app}.faa.gov/callback
Post-logout redirect: https://{app}.faa.gov
Scopes: openid, profile, email, groups
Token storage: In-memory (not localStorage)
Token refresh: Silent refresh via hidden iframe
Session timeout: 30 minutes idle, 8 hours absolute
```

### OKTA for API (Backend)
```
JWT validation: OKTA JWKS endpoint
Issuer: https://faa.okta.com/oauth2/{auth-server-id}
Audience: https://api.{app-name}.faa.gov
Claims mapping:
  - sub -> user_id
  - groups -> roles (RBAC)
  - scp -> permissions
```

### Login.gov (External Users)
For applications with external-facing users:
```
Federation: Login.gov -> OKTA (SAML 2.0)
IAL: IAL2 (identity-proofed) for T1, IAL1 for T2/T3
AAL: AAL2 (MFA required)
User attributes: email, uuid (no PII stored in app)
```

### Role-Based Access Control (RBAC)
```
Roles sourced from: OKTA groups
Role hierarchy: admin > manager > user > viewer
Permission enforcement: Backend middleware (not frontend only)
Audit logging: All role-based access decisions logged to Datadog
```

## Caching Strategy

### Three-Layer Cache
1. **CloudFront (Edge)**: Static assets (JS, CSS, images) with long TTLs (1 year + cache busting)
2. **ElastiCache Redis (API)**: Frequently read data, user session, feature flags (TTL: 5-60 min)
3. **Application (In-Memory)**: Configuration, reference data, OKTA JWKS keys (TTL: 5 min)

**Cache Invalidation:**
- CloudFront: Invalidation on deployment (S3 key changes via content hash)
- Redis: TTL-based expiry + explicit invalidation on write
- Application: TTL-based expiry (no explicit invalidation needed for config)

## Observability

### Datadog APM
```
Agent: Datadog sidecar container in Fargate task
APM: dd-trace (Python) or dd-java-agent (Java)
Service name: {app-name}-api
Environment: dev | staging | prod
Version: git SHA tag
Custom metrics: business KPIs (orders/min, logins/hour)
```

### Structured Logging
```json
{
  "timestamp": "2026-01-15T10:30:00Z",
  "level": "INFO",
  "service": "app-name-api",
  "trace_id": "abc123",
  "span_id": "def456",
  "message": "Request completed",
  "http_method": "GET",
  "http_path": "/api/v1/resources",
  "http_status": 200,
  "duration_ms": 45,
  "user_id": "okta-user-123"
}
```

### CloudWatch Alarms
| Alarm | Threshold | Action | Tier |
|-------|-----------|--------|------|
| CPU High | > 80% for 5 min | Scale out + P2 alert | All |
| Memory High | > 85% for 5 min | Scale out + P2 alert | All |
| 5xx Rate | > 5% for 2 min | P1 alert | All |
| Latency P99 | > 2s for 5 min | P2 alert | T1/T2 |
| DB Connections | > 80% max for 5 min | P2 alert | All |
| ALB Unhealthy Hosts | > 0 for 1 min | P1 alert | T1 |
| Error Log Rate | > 10/min for 5 min | P2 alert | All |

### Health Check Endpoints
```
GET /health -> 200 {"status": "UP"} (liveness - no dependency checks)
GET /ready  -> 200 {"status": "READY", "db": "UP", "cache": "UP"} (readiness)
GET /info   -> 200 {"version": "1.2.3", "commit": "abc123"} (metadata)
```

## Security Architecture

### Network
```
VPC CIDR: 10.{tier}.0.0/16
Public subnets: ALB only (2 AZs minimum)
Private subnets: Fargate tasks, Aurora, ElastiCache (2 AZs minimum)
Isolated subnets: None needed (use private with NAT)
NAT Gateway: 1 (T3) | 2 (T2/T1) for AZ redundancy
VPC Flow Logs: enabled, sent to S3 + CloudWatch
```

**Security Groups:**
- ALB SG: Inbound 443 from Gravitee IPs only
- Fargate SG: Inbound 8080 from ALB SG only
- Aurora SG: Inbound 5432 from Fargate SG only
- ElastiCache SG: Inbound 6379 from Fargate SG only
- Egress: Restricted to required destinations (not 0.0.0.0/0)

### Encryption
- **In transit**: TLS 1.3 everywhere (CloudFront, ALB, Gravitee, Aurora, Redis)
- **At rest**: SSE-KMS for S3, Aurora, ElastiCache, ECR
- **KMS key**: Customer-managed CMK (not AWS-managed) for T1/T2
- **Key rotation**: Annual automatic rotation enabled

### Secrets Management
- Application secrets: CyberArk (MANDATORY for privileged credentials)
- Database passwords: CyberArk, rotated via CyberArk CPM
- API keys: CyberArk, injected via environment variable at task launch
- Never store secrets in: SSM Parameter Store, Secrets Manager (use CyberArk)
- Non-privileged config: SSM Parameter Store (feature flags, endpoints)

## CI/CD Pipeline

### GitHub Actions Workflow
```yaml
# Triggered on: push to main, pull_request
stages:
  - lint: Ruff (Python) or Checkstyle (Java)
  - test: Unit tests + integration tests
  - scan: SonarQube analysis + SAST
  - build: Docker image build + ECR push
  - deploy-staging: ECS blue/green to staging
  - e2e-test: Playwright E2E tests against staging
  - deploy-prod: ECS blue/green to production (manual approval for T1)
```

**Image Build:**
- Multi-stage Dockerfile (build + runtime)
- ECR enhanced scanning on push
- Image tag: git SHA + semantic version
- Cache: GitHub Actions cache for Docker layers

**Deployment:**
- Staging: Automatic on merge to main
- Production T3: Automatic after staging E2E pass
- Production T2: Automatic with 15-minute bake time
- Production T1: Manual approval gate required

## Infrastructure as Code (Terraform)

### Module Inventory
| Module | Purpose | Source |
|--------|---------|--------|
| vpc | VPC, subnets, NAT, flow logs | terraform-aws-modules/vpc |
| ecs-cluster | ECS cluster, capacity providers | custom |
| ecs-service | Fargate service, task def, auto-scaling | custom |
| aurora | Aurora cluster, instances, parameter groups | custom |
| elasticache | Redis cluster/replication group | custom |
| s3-spa | S3 bucket for SPA hosting | custom |
| cloudfront | CloudFront distribution + WAF | custom |
| alb | Application load balancer + target groups | custom |
| ecr | ECR repository + lifecycle policies | custom |
| kms | KMS keys for encryption | custom |
| monitoring | CloudWatch alarms, Datadog integration | custom |

### Environment Promotion
```
environments/
  dev/
    terraform.tfvars    # Dev-specific overrides
  staging/
    terraform.tfvars    # Staging-specific overrides
  prod/
    terraform.tfvars    # Prod-specific overrides
modules/                # Shared module definitions
  vpc/
  ecs-cluster/
  ecs-service/
  aurora/
  ...
```

State: S3 backend with DynamoDB locking (per environment).

## Scaling Patterns

### Auto-Scaling
- **ECS Service**: Target tracking on CPU (70%) and memory (80%)
- **Aurora Serverless v2**: Automatic ACU scaling (no configuration needed)
- **ElastiCache**: Manual scaling (T3) | auto-scaling with CloudWatch (T1/T2)
- **CloudFront**: Automatic (global edge network)

### Scheduled Scaling
For applications with predictable traffic patterns:
- Scale up ECS desired count 30 minutes before peak
- Scale down to minimum 2 hours after peak ends
- Weekend scaling: reduce to minimum for internal-only apps

### Load Testing Baseline
Before production launch, establish:
- Requests per second at P50, P95, P99 latency targets
- Maximum concurrent users before degradation
- Database connection pool saturation point
- Cache hit ratio under load

## FAA-Specific Requirements

### Branding (MANDATORY for all FAA web apps)
- **USA Banner**: "An official website of the United States government" with flag icon
- **DOT Ribbon**: Department of Transportation identifier bar
- **FAA Logo**: Federal Aviation Administration logo (SVG, accessible alt text)
- **Font**: Source Sans Pro (loaded from USWDS, not Google Fonts)
- **Primary Color**: #15396c (FAA blue)
- **Link Color**: #005ea2 (USWDS default)
- **Footer**: Standard FAA footer with Privacy Policy, FOIA, Accessibility, No FEAR Act links

### Accessibility
- WCAG 2.1 AA compliance (MANDATORY)
- Section 508 compliance (MANDATORY)
- Keyboard navigation: all interactive elements focusable
- Screen reader: ARIA labels on all non-text elements
- Color contrast: 4.5:1 minimum ratio
- Testing: axe-core in CI, manual testing with NVDA/JAWS

### 508 Compliance Checklist
- [ ] All images have alt text
- [ ] Form fields have associated labels
- [ ] Color is not the sole means of conveying information
- [ ] Focus order is logical and sequential
- [ ] Page titles are descriptive and unique
- [ ] Skip navigation link is present
- [ ] Tables have proper headers and scope attributes
- [ ] Dynamic content updates are announced to screen readers

## Tier-Specific Variations

### T1 (Mission Critical) Additions
- Cross-region Aurora replica (us-gov-west-1 to us-gov-east-1)
- Route 53 health check with DNS failover
- Enhanced monitoring: 1-second granularity
- 99.99% availability target
- Multi-AZ NAT Gateway
- Production deployment: Manual approval + canary deployment
- Incident response: P1 within 15 minutes
- Disaster recovery: Active-passive cross-region
- Quarterly DR testing required
- Cost range: $2,000-5,000/month

### T2 (Important) Baseline
- Multi-AZ Aurora with 1 read replica
- Standard monitoring: 60-second granularity
- 99.9% availability target
- Single NAT Gateway (with AZ failover plan)
- Production deployment: Automatic with 15-minute bake
- Incident response: P2 within 1 hour
- Cost range: $500-1,500/month

### T3 (Low Impact) Simplifications
- Single-AZ Aurora (no read replica)
- Basic monitoring: 300-second granularity
- 99.5% availability target
- Single NAT Gateway
- Production deployment: Automatic after staging pass
- Incident response: P3 within 4 hours
- Simplified VPC (fewer subnets)
- No ElastiCache (unless session management requires it)
- Cost range: $200-500/month

## Cost Estimate Breakdown

### T3 (~$200-500/month)
| Service | Monthly Cost |
|---------|-------------|
| ECS Fargate (0.25 vCPU, 0.5 GB, 1 task) | $10-15 |
| Aurora Serverless v2 (0.5-4 ACU) | $50-150 |
| S3 (SPA + assets, < 1 GB) | $1-5 |
| CloudFront (< 100 GB transfer) | $10-20 |
| ALB | $25 |
| NAT Gateway | $35 + data transfer |
| ECR | $1-5 |
| KMS | $1-3 |
| CloudWatch | $10-20 |
| Datadog (2 hosts) | $50-100 |
| **Total** | **$193-378** |

### T2 (~$500-1,500/month)
| Service | Monthly Cost |
|---------|-------------|
| ECS Fargate (0.5 vCPU, 1 GB, 2-6 tasks) | $30-100 |
| Aurora Serverless v2 (1-16 ACU, multi-AZ) | $150-500 |
| ElastiCache Redis (cache.t4g.small) | $50-80 |
| S3 + CloudFront | $20-50 |
| ALB | $25-50 |
| NAT Gateway (1) | $35-70 |
| Monitoring (Datadog + CloudWatch) | $100-200 |
| Other (ECR, KMS, etc.) | $20-50 |
| **Total** | **$430-1,100** |

### T1 (~$2,000-5,000/month)
| Service | Monthly Cost |
|---------|-------------|
| ECS Fargate (1 vCPU, 2 GB, 3-12 tasks) | $100-400 |
| Aurora Serverless v2 (2-64 ACU, multi-AZ + cross-region) | $500-1,500 |
| ElastiCache Redis (cache.r7g.large, clustered) | $200-400 |
| S3 + CloudFront | $30-80 |
| ALB | $25-50 |
| NAT Gateway (2, multi-AZ) | $70-140 |
| Route 53 health checks + DNS failover | $10-20 |
| Monitoring (Datadog + CloudWatch, enhanced) | $200-500 |
| Cross-region data transfer | $50-200 |
| Other (ECR, KMS, WAF, etc.) | $50-100 |
| **Total** | **$1,235-3,390** |
