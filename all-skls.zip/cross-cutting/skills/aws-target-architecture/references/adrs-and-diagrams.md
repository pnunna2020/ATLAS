# ADRs and C4 Diagrams

Use this reference when executing Steps 8-9 of the methodology.

## Step 8: Architecture Decision Records

For every non-obvious design choice, produce an ADR using `assets/adr-template.md`:
- Service selection (why Aurora over DynamoDB for this app?)
- Pattern selection (why modular monolith over microservices?)
- Tier-specific decisions (why ElastiCache needed? why not?)
- Migration strategy (why lift-and-shift data first, then refactor?)

Each ADR must trace to a specific Discovery finding:
`{discovery-report}:{section}:{finding-id}`

## Step 9: C4 Diagram Descriptions

Generate text-based C4 diagrams at three levels:
1. **Context**: Application boundary, external actors, external systems
2. **Container**: Internal containers (SPA, API, database, cache, queue)
3. **Component**: Key components within the primary container (routes, services, repositories)

Use Mermaid syntax for diagram descriptions so they render in Markdown.

## Tech-Stack Dispatch (Source → Target Migration)

Before designing the target, detect the source technology and apply the
appropriate migration mapping:

| Source Technology | Target Technology | Migration Notes |
|------------------|------------------|----------------|
| ColdFusion (CFWheels, Fusebox) | FastAPI (Python 3.12) | Full rearchitect; no CF-to-CF migration |
| Java EE (Struts, JSF, EJB) | Spring Boot 3.x (Java 21) | Refactor EJBs to Spring services |
| .NET Framework (4.x) | .NET 8 (minimal API) | Incremental migration via .NET Upgrade Assistant |
| OBIEE | Amazon QuickSight | Dashboard-by-dashboard migration |
| Oracle Forms | React + USWDS + FastAPI | Full rearchitect; screen-by-screen extraction |
| Oracle Reports | QuickSight paginated reports | Report-by-report migration |
| Classic ASP | FastAPI (Python 3.12) | Full rearchitect |
| PHP (legacy) | FastAPI (Python 3.12) | Full rearchitect |

## Archetype Dispatch

Based on the detected archetype, load the appropriate reference file (see
`references/archetype-*.md`) and apply its patterns as the starting point.
Customize based on:
1. Risk tier (T1 adds redundancy, T3 simplifies)
2. Complexity (complex adds service mesh patterns, simple stays minimal)
3. Source tech (determines migration path, not target architecture)
4. Integration surface (SWIM, external consumers, shared databases)
