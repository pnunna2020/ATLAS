# Tier Design (Compute, Data, Integration, Identity, Observability)

Use this reference when executing Steps 3-7 of the methodology.

## Step 3: Compute Tier

Based on archetype and complexity:
- **Serverless-first**: Lambda for stateless, event-triggered workloads
- **Container**: ECS Fargate for stateful, long-running, or complex services
- **EC2**: Only if Fargate/Lambda cannot meet requirements (document why)

Size the compute:
- T3 simple: Minimal Fargate (0.25 vCPU, 0.5 GB) or Lambda
- T2 moderate: Standard Fargate (0.5-1 vCPU, 1-2 GB) with auto-scaling
- T1 complex: Multi-AZ Fargate (1-2 vCPU, 2-4 GB) with cross-region failover

## Step 4: Data Tier

Based on data patterns from Discovery Pass 3:
- **Relational (default)**: Aurora PostgreSQL Serverless v2
- **Key-value/Document**: DynamoDB (only if proven key-value access pattern)
- **File/Object**: S3 with SSE-KMS encryption
- **Cache**: ElastiCache Redis (if session state or hot-data caching needed)
- **Analytics**: Redshift Serverless (if analytical queries required)

Data migration path:
- Oracle → Aurora PostgreSQL (use AWS DMS + SCT)
- SQL Server → Aurora PostgreSQL (use AWS DMS + SCT)
- Access/Excel → Aurora PostgreSQL (custom ETL via Step Functions)
- File shares → S3 (AWS DataSync)

## Step 5: Integration Tier

Map all integration points from Discovery Pass 3:
- **External API exposure**: Gravitee (MANDATORY) → ALB → Service
- **Internal service-to-service**: ALB + Cloud Map service discovery
- **Async events**: EventBridge for domain events
- **Work queues**: SQS Standard or FIFO
- **Notifications**: SNS for fan-out
- **SWIM/NAS data**: Solace PubSub+ (MANDATORY for NAS integration)
- **Batch file transfer**: S3 + EventBridge notification

For each integration point, specify:
- Protocol (REST, gRPC, event, message)
- Auth method (OAuth2, mTLS, API key via Gravitee)
- Data format (JSON, XML, Parquet, CSV)
- SLA (latency, throughput, availability)

## Step 6: Identity and Auth Tier

All applications use the same identity stack:
- **OKTA**: MANDATORY IdP for all authentication
- **Login.gov**: For external-facing applications (public users)
- **CyberArk**: MANDATORY for privileged access management
- **AWS KMS**: MANDATORY for encryption key management (FIPS 140-2)

Auth flow selection:
- SPA (web-app): Authorization Code + PKCE via OKTA
- API (api-service): Client Credentials via OKTA
- Service-to-service: mTLS or OAuth2 client credentials
- Batch (batch-pipeline): IAM roles + CyberArk for credentials
- External users: Login.gov federation through OKTA

Never introduce alternative identity providers. Never use AWS Cognito.

## Step 7: Observability Tier

Standard observability stack for all applications:
- **Datadog APM**: Application performance monitoring (primary)
- **Datadog Logs**: Centralized structured logging (JSON format)
- **CloudWatch**: Supplemental metrics and alarms (auto-configured)
- **X-Ray**: Distributed tracing (for Step Functions and Lambda)
- **Health endpoints**: `/health` (liveness) and `/ready` (readiness)

Alerting thresholds by tier:
- T1: P1 alert within 1 minute, 99.99% availability SLO
- T2: P2 alert within 5 minutes, 99.9% availability SLO
- T3: P3 alert within 15 minutes, 99.5% availability SLO
