# Archetype: Batch Pipeline (Step Functions + Lambda)

## Overview
Reference architecture for modernizing legacy batch processing systems (Oracle DBMS_SCHEDULER,
cron jobs, SQL Server Agent, SSIS packages, Windows Task Scheduler, mainframe JCL) into
serverless batch pipelines on AWS GovCloud.

Batch pipelines are the second most common archetype in the FAA portfolio. Many applications
have hidden batch components that are only discovered during analyze-application Pass 3.

## Architecture Diagram (Text)

```
         +-------------------+           +-------------------+
         | EventBridge       |           | S3 Event          |
         | Scheduler (cron)  |           | Notification      |
         +---------+---------+           +---------+---------+
                   |                               |
                   +---------------+---------------+
                                   |
                          +--------+--------+
                          | Step Functions  |
                          | State Machine   |
                          +--------+--------+
                                   |
                   +---------------+---------------+
                   |               |               |
            +------+------+ +-----+------+ +------+------+
            | Lambda      | | Lambda     | | Lambda      |
            | Extract     | | Transform  | | Load        |
            +------+------+ +-----+------+ +------+------+
                   |               |               |
            +------+------+ +-----+------+ +------+------+
            | S3 Staging  | | S3 Working | | Aurora      |
            | (raw)       | | (processed)| | PostgreSQL  |
            +-------------+ +------------+ +------+------+
                                                  |
                                           +------+------+
                                           | DynamoDB    |
                                           | (job state) |
                                           +-------------+
```

## Step Functions State Machine

### Standard vs Express Workflows
| Criteria | Standard | Express |
|----------|----------|---------|
| Duration | Up to 1 year | Up to 5 minutes |
| Execution rate | 2,000/sec start | 100,000/sec start |
| Pricing | Per state transition | Per request + duration |
| Use when | Long-running ETL, multi-step pipelines | High-volume, short transforms |

**Default choice: Standard Workflow** for most FAA batch migrations. Express only for
sub-5-minute, high-frequency event processors.

### State Machine Design Patterns

**Sequential ETL:**
```
Extract -> Transform -> Validate -> Load -> Notify
```

**Parallel Fan-Out:**
```
                  +-> Process Partition 1 -+
Split Workload -> +-> Process Partition 2 -+-> Merge Results -> Load
                  +-> Process Partition 3 -+
```

**Map State (Dynamic Parallelism):**
```
List Files in S3 -> Map(Process Each File) -> Aggregate Results -> Load
```

**Choice State (Conditional):**
```
Check File Type -> Choice:
  CSV  -> CSV Parser -> Transform
  XML  -> XML Parser -> Transform
  JSON -> JSON Parser -> Transform
  Default -> Error Handler
```

### Error Handling
```json
{
  "Retry": [
    {
      "ErrorEquals": ["States.TaskFailed", "Lambda.ServiceException"],
      "IntervalSeconds": 5,
      "MaxAttempts": 3,
      "BackoffRate": 2.0
    }
  ],
  "Catch": [
    {
      "ErrorEquals": ["States.ALL"],
      "Next": "HandleError",
      "ResultPath": "$.error"
    }
  ]
}
```

**Error handling strategy:**
- Retryable errors (network, throttle): Exponential backoff, 3 attempts
- Data errors (validation failure): Route to DLQ, continue pipeline
- Fatal errors (missing table, auth failure): Halt pipeline, alert immediately
- Partial failure: Checkpoint last successful record, enable resume

## Lambda Functions

### Runtime and Configuration
```
Runtime: Python 3.12 (default) or Java 21 (if Java EE migration)
Architecture: arm64 (Graviton2 - 20% cheaper, better performance)
Handler pattern: Single-purpose functions (one Lambda per step)
```

**Memory and Timeout by Step Type:**
| Step Type | Memory | Timeout | Notes |
|-----------|--------|---------|-------|
| Extract (file read) | 256-512 MB | 5 min | Streaming read for large files |
| Extract (DB query) | 512 MB-1 GB | 10 min | Connection pooling via RDS Proxy |
| Transform | 512 MB-2 GB | 10 min | Memory scales with record size |
| Validate | 256 MB | 5 min | CPU-bound validation |
| Load (DB write) | 512 MB | 10 min | Batch inserts, connection pooling |
| Load (S3 write) | 256-1 GB | 5 min | Multipart upload for large outputs |

### Lambda Layers
Shared code deployed as Lambda layers to reduce deployment size:
```
Layer 1: Common utilities (logging, error handling, metrics)
Layer 2: Database clients (psycopg2, boto3 extensions)
Layer 3: Data processing (pandas, pyarrow for Parquet)
```

### Cold Start Mitigation
- Provisioned concurrency: T1 pipelines (critical batch jobs)
- SnapStart: Java 21 Lambda functions (if Java migration)
- Minimal imports: Lazy-load heavy libraries
- Connection reuse: Keep DB connections outside handler

## Data Architecture

### S3 Staging Layout
```
s3://{app-name}-batch-{env}/
  raw/                     # Inbound files as received
    {date}/{source}/{filename}
  processed/               # Transformed data ready for load
    {date}/{job-id}/{partition}/data.parquet
  archive/                 # Completed runs (lifecycle to Glacier)
    {date}/{job-id}/
  failed/                  # Failed records for reprocessing
    {date}/{job-id}/{error-type}/
```

**S3 Configuration:**
```
Versioning: enabled
Encryption: SSE-KMS (MANDATORY)
Lifecycle:
  - raw -> archive after 30 days
  - archive -> Glacier after 90 days
  - failed -> delete after 180 days
  - processed -> delete after 7 days
Event notifications: EventBridge for new object creation
Block public access: enabled (all 4 settings)
```

**File Formats:**
- Inbound: CSV, XML, fixed-width (whatever the source provides)
- Intermediate: Parquet (columnar, compressed, schema-encoded)
- Output: Parquet for analytics, JSON for API consumption, CSV for legacy consumers

### Aurora PostgreSQL (Target Database)
Same configuration as web-app archetype (see `archetype-web-app.md` Data Tier).
Additional batch-specific considerations:

**Bulk Load Optimization:**
```sql
-- Disable indexes during bulk load
ALTER INDEX idx_name ON table_name DISABLE;
-- Use COPY for bulk insert (10x faster than INSERT)
COPY table_name FROM STDIN WITH (FORMAT csv, HEADER true);
-- Re-enable and rebuild indexes
ALTER INDEX idx_name ON table_name REBUILD;
-- Analyze for query planner
ANALYZE table_name;
```

**Partition Strategy:**
- Time-based partitioning for append-heavy tables (daily/monthly)
- Range partitioning for large lookup tables
- Declarative partitioning (PostgreSQL 13+ native)

### DynamoDB (Job State Tracking)
Track batch job execution state for idempotency and monitoring:

```
Table: {app-name}-job-state
Partition key: job_id (String)
Sort key: step_name (String)
Attributes:
  - status: PENDING | RUNNING | COMPLETED | FAILED
  - started_at: ISO 8601 timestamp
  - completed_at: ISO 8601 timestamp
  - records_processed: Number
  - records_failed: Number
  - checkpoint: String (last processed record ID)
  - error_message: String (if FAILED)
TTL: completed_at + 90 days
```

## Scheduling

### EventBridge Scheduler
Replaces: cron, DBMS_SCHEDULER, SQL Agent, Windows Task Scheduler, SSIS schedules.

**Schedule Types:**
```
Rate-based:  rate(1 hour)       -- Every hour
Cron-based:  cron(0 6 * * ? *)  -- Daily at 6 AM UTC
One-time:    at(2026-01-15T10:00:00) -- Specific datetime
```

**Migration Mapping:**
| Legacy Scheduler | EventBridge Equivalent | Notes |
|-----------------|----------------------|-------|
| crontab `0 6 * * *` | `cron(0 6 * * ? *)` | Add `?` for day-of-week |
| DBMS_SCHEDULER REPEAT_INTERVAL | Rate or cron expression | Convert Oracle interval syntax |
| SQL Agent Job Schedule | Cron expression | Map step sequences to Step Functions |
| SSIS Package Schedule | Cron + Step Functions | Map SSIS data flow to Lambda steps |
| Windows Task Scheduler | Cron expression | Convert Windows triggers |

**Timezone Handling:**
- All schedules in UTC (GovCloud standard)
- Application-level timezone conversion if business requires EST/CST display
- EventBridge Scheduler supports timezone parameter (use America/New_York for EST)

### S3 Event Triggers
For file-arrival-triggered pipelines:
```
S3 bucket -> EventBridge notification -> EventBridge rule -> Step Functions
```

Filter by prefix and suffix:
```json
{
  "source": ["aws.s3"],
  "detail-type": ["Object Created"],
  "detail": {
    "bucket": {"name": ["{app-name}-batch-{env}"]},
    "object": {"key": [{"prefix": "raw/"}]}
  }
}
```

## Error Handling and Resilience

### Dead Letter Queue (DLQ)
```
SQS Queue: {app-name}-batch-dlq
Message retention: 14 days
Visibility timeout: 300 seconds
Encryption: SSE-KMS
Alarm: DLQ depth > 0 triggers P2 alert
```

**DLQ Processing Workflow:**
1. Failed records land in DLQ with error context
2. CloudWatch Alarm triggers on DLQ depth > 0
3. Ops team reviews failed records via SQS console or script
4. Fix data issues (if data error) or fix code (if logic error)
5. Replay records from DLQ back to Step Functions input

### Idempotency
Every batch step must be idempotent (safe to retry without side effects):

**Strategies:**
- **Event ID deduplication**: DynamoDB conditional write with event ID as key
- **Upsert pattern**: `INSERT ON CONFLICT DO UPDATE` for database loads
- **Checkpoint/resume**: Store last processed record ID in DynamoDB job state
- **File-level idempotency**: Hash inbound file content; skip if already processed

### Monitoring and Alerting
| Metric | Alarm Threshold | Severity |
|--------|----------------|----------|
| Step Functions execution failed | > 0 failures | P1 (T1), P2 (T2/T3) |
| Lambda error rate | > 5% for 5 min | P2 |
| Lambda duration | > 80% of timeout | P2 (proactive) |
| DLQ depth | > 0 messages | P2 |
| S3 raw/ file age | > 2x expected interval | P2 (missing feed) |
| Job duration | > 2x historical average | P3 |
| Records processed | < 50% of expected count | P2 |

### Step Functions Observability
```
Logging: ALL events to CloudWatch Logs (for debugging)
X-Ray tracing: enabled (visualize step execution)
Execution history: 90-day retention
Custom metrics:
  - records_processed (per step)
  - records_failed (per step)
  - step_duration_ms (per step)
  - pipeline_duration_ms (total)
Published to: Datadog via CloudWatch metric streams
```

## Migration from Legacy Batch Systems

### Oracle DBMS_SCHEDULER
```
Legacy:
  DBMS_SCHEDULER.CREATE_JOB(
    job_name => 'NIGHTLY_ETL',
    job_type => 'STORED_PROCEDURE',
    job_action => 'PKG_ETL.RUN_NIGHTLY',
    repeat_interval => 'FREQ=DAILY; BYHOUR=2; BYMINUTE=0'
  );

Target:
  EventBridge Scheduler: cron(0 2 * * ? *)
  Step Functions: Orchestrate the ETL steps
  Lambda: Execute each step (extract, transform, load)
  Aurora: Target database (migrated from Oracle)
```

### SSIS Packages
```
Legacy:
  SSIS Package with:
    - Data Flow Task (source -> transform -> destination)
    - Control Flow (sequence, loops, conditionals)
    - Connection Managers (OLE DB, flat file)

Target:
  Step Functions state machine maps to Control Flow
  Lambda functions map to Data Flow Tasks
  S3 maps to flat file connections
  Aurora maps to OLE DB destinations
```

### SQL Server Agent Jobs
```
Legacy:
  SQL Agent Job with:
    - Steps (T-SQL, SSIS, PowerShell)
    - Schedule (daily, weekly)
    - Alerts and notifications

Target:
  EventBridge Scheduler: Schedule
  Step Functions: Job steps orchestration
  Lambda: Individual step execution
  SNS: Alerts and notifications
```

## Security

### IAM Roles
```
Step Functions execution role:
  - lambda:InvokeFunction (specific Lambda ARNs only)
  - states:StartExecution (for nested state machines)
  - logs:CreateLogGroup, logs:PutLogEvents

Lambda execution role (per function):
  - s3:GetObject, s3:PutObject (specific bucket/prefix)
  - rds-data:ExecuteStatement (for Aurora Serverless Data API)
  - dynamodb:PutItem, dynamodb:GetItem (job state table)
  - kms:Decrypt, kms:GenerateDataKey (specific KMS key)
  - sqs:SendMessage (DLQ only)

Principle: Least privilege. Each Lambda gets only the permissions it needs.
```

### Data Encryption
- S3: SSE-KMS (mandatory)
- Aurora: Storage encryption with KMS (mandatory)
- DynamoDB: Encryption at rest with KMS (mandatory)
- Lambda environment variables: Encrypted with KMS
- In-transit: TLS 1.2+ for all connections

### Credential Management
- Database credentials: CyberArk (rotated automatically)
- External system credentials: CyberArk
- AWS credentials: IAM roles (no access keys)
- Encryption keys: KMS with automatic annual rotation

## Tier-Specific Variations

### T1 (Mission Critical) Additions
- Provisioned concurrency for critical Lambda functions
- Multi-AZ Aurora with read replicas
- Cross-region S3 replication for disaster recovery
- Enhanced Step Functions logging
- Quarterly pipeline disaster recovery testing
- Cost range: $800-2,500/month

### T2 (Important) Baseline
- On-demand Lambda (no provisioned concurrency)
- Multi-AZ Aurora (single writer + 1 reader)
- Standard S3 (no cross-region replication)
- Standard Step Functions logging
- Cost range: $200-800/month

### T3 (Low Impact) Simplifications
- On-demand Lambda with minimal memory allocation
- Single-AZ Aurora Serverless
- Standard S3 with lifecycle policies
- Basic Step Functions logging
- Cost range: $50-200/month

## Cost Estimate Breakdown

### T3 (~$50-200/month)
| Service | Monthly Cost |
|---------|-------------|
| Step Functions (< 10K transitions) | $1-5 |
| Lambda (< 1M invocations, 256 MB) | $5-20 |
| S3 (< 50 GB, lifecycle to Glacier) | $2-10 |
| Aurora Serverless v2 (0.5-2 ACU) | $30-100 |
| DynamoDB (on-demand, < 1 GB) | $1-5 |
| EventBridge Scheduler | $0-1 |
| CloudWatch | $5-15 |
| Datadog (1 host + serverless) | $30-60 |
| **Total** | **$74-216** |

### T2 (~$200-800/month)
| Service | Monthly Cost |
|---------|-------------|
| Step Functions (< 100K transitions) | $5-25 |
| Lambda (< 10M invocations, 512 MB) | $20-80 |
| S3 (< 500 GB) | $10-25 |
| Aurora Serverless v2 (1-8 ACU, multi-AZ) | $100-300 |
| DynamoDB (on-demand, < 5 GB) | $5-15 |
| SQS DLQ | $1-5 |
| Monitoring (Datadog + CloudWatch) | $50-150 |
| **Total** | **$191-600** |

### T1 (~$800-2,500/month)
| Service | Monthly Cost |
|---------|-------------|
| Step Functions (< 500K transitions) | $15-50 |
| Lambda (provisioned concurrency, 1 GB) | $80-250 |
| S3 (< 1 TB, cross-region replication) | $25-80 |
| Aurora Serverless v2 (2-16 ACU, multi-AZ) | $200-600 |
| DynamoDB (provisioned, global tables) | $20-80 |
| SQS DLQ + SNS | $5-15 |
| Monitoring (Datadog + CloudWatch, enhanced) | $100-300 |
| Cross-region data transfer | $30-100 |
| **Total** | **$475-1,475** |
