# Archetype: Event-Driven Service

## Overview
Reference architecture for building or modernizing event-driven services on AWS GovCloud.
These are services that react to events rather than serving synchronous requests. Common
in FAA systems that process NAS (National Airspace System) data, sensor feeds, status
updates, and cross-system notifications.

Legacy sources: Oracle Advanced Queuing (AQ), JMS-based messaging, file-based triggers,
database polling patterns, Tibco/MQ integrations, Solace PubSub+ consumers.

## Architecture Diagram (Text)

```
  +-----------+     +-----------+     +-------------+
  | External  |     |  Solace   |     | S3 File     |
  | System    |     | PubSub+  |     | Drop        |
  +-----+-----+     +-----+-----+     +------+------+
        |                 |                   |
        v                 v                   v
  +-----+-----+     +-----+-----+     +------+------+
  | EventBridge|     | EventBridge|     | EventBridge |
  | (custom    |     | Pipe      |     | (S3 event)  |
  |  bus)      |     | (Solace)  |     |             |
  +-----+-----+     +-----+-----+     +------+------+
        |                 |                   |
        +--------+--------+--------+----------+
                 |                 |
          +------+------+   +-----+------+
          | SQS Queue   |   | SQS FIFO   |
          | (standard)  |   | (ordered)  |
          +------+------+   +-----+------+
                 |                 |
          +------+------+   +-----+------+
          | Lambda      |   | ECS        |
          | Handler     |   | Fargate    |
          | (stateless) |   | (stateful) |
          +------+------+   +-----+------+
                 |                 |
          +------+------+   +-----+------+
          | DynamoDB    |   | Aurora     |
          | (event log) |   | PostgreSQL |
          +-------------+   +------------+
```

## EventBridge Architecture

### Custom Event Bus
Every event-driven service gets a dedicated custom event bus:
```
Bus name: {app-name}-events
Archive: enabled (30 days for replay capability)
Schema registry: enabled (auto-discover event schemas)
Dead letter queue: SQS DLQ for failed deliveries
```

**Event Schema Standard:**
```json
{
  "$schema": "http://json-schema.org/draft-07/schema#",
  "type": "object",
  "required": ["version", "id", "source", "detail-type", "time", "detail"],
  "properties": {
    "version": {"const": "1.0"},
    "id": {"type": "string", "format": "uuid"},
    "source": {"type": "string", "pattern": "^[a-z-]+\\.[a-z-]+$"},
    "detail-type": {"type": "string", "pattern": "^[A-Z][a-zA-Z]+\\.[A-Z][a-zA-Z]+$"},
    "time": {"type": "string", "format": "date-time"},
    "detail": {
      "type": "object",
      "required": ["correlation_id"],
      "properties": {
        "correlation_id": {"type": "string"},
        "caused_by": {"type": "string", "description": "ID of the event that triggered this one"}
      }
    }
  }
}
```

### Event Routing Rules
```json
{
  "source": ["app-name.service-name"],
  "detail-type": ["Flight.StatusChanged"],
  "detail": {
    "severity": ["HIGH", "CRITICAL"]
  }
}
```

**Rule targets by pattern:**
- Lambda: Stateless, short-lived event processing (< 15 min)
- SQS -> Lambda: Buffered processing with retry and DLQ
- SQS -> Fargate: Long-running or stateful processing
- Step Functions: Multi-step event-triggered workflows
- SNS: Fan-out to multiple consumers
- CloudWatch Logs: Event auditing

### EventBridge Pipes (Solace Integration)
For connecting Solace PubSub+ to EventBridge:
```
Source: Solace PubSub+ queue (via Amazon MQ or custom connector)
Enrichment: Lambda (optional, for format transformation)
Filter: EventBridge rule pattern
Target: EventBridge custom bus
```

**Solace-to-EventBridge Flow:**
```
Solace Topic -> Solace Queue -> Lambda Poller -> EventBridge Custom Bus
                                  (or)
Solace Topic -> Solace REST Delivery Point -> API Gateway -> EventBridge
```

Note: Direct Solace-to-EventBridge integration may require a custom connector
Lambda function. The pattern depends on Solace deployment model (cloud vs. on-prem).

## SWIM Integration

### System Wide Information Management (SWIM)
SWIM is the FAA's standard for sharing NAS data. If an application consumes or
publishes NAS data, Solace PubSub+ is MANDATORY.

**SWIM Data Types:**
| Data Type | Description | Typical Volume | Latency Requirement |
|-----------|------------|---------------|-------------------|
| STDDS | Surface traffic display data | High (100K+ msg/sec) | < 1s |
| TFMS | Traffic flow management | Medium (1K msg/sec) | < 5s |
| ITWS | Integrated terminal weather | Medium | < 10s |
| ASDE-X | Airport surface detection | High | < 1s |
| NOTAM | Notices to Air Missions | Low (100 msg/day) | Minutes |

**Solace PubSub+ Configuration:**
```
Deployment: Solace Cloud (GovCloud-compatible) or on-prem appliance
Protocol: MQTT or SMF (Solace Message Format)
Topics: Hierarchical topic taxonomy per SWIM standard
QoS: Guaranteed messaging for critical data
Queues: Per-consumer exclusive queues for ordered processing
DTOs: Direct Topic Objects for fan-out
```

**Do NOT replace Solace with:**
- EventBridge (cannot handle SWIM protocol and volume)
- SQS/SNS (no SWIM protocol support)
- Kafka (not FAA-approved)

Solace handles the SWIM protocol layer. EventBridge handles the internal event
routing after data enters the AWS environment.

## Event Processing Patterns

### Pattern 1: Simple Event Handler (Lambda)
For stateless, single-step event processing:
```
EventBridge Rule -> SQS Queue -> Lambda Handler -> DynamoDB/Aurora
```

**Lambda Handler Template:**
```python
def handler(event, context):
    for record in event['Records']:
        body = json.loads(record['body'])
        event_detail = json.loads(body['detail'])

        # Idempotency check
        if already_processed(event_detail['id']):
            continue

        # Process event
        result = process_event(event_detail)

        # Store result
        store_result(result)

        # Publish downstream event (if needed)
        publish_event(result)
```

### Pattern 2: Event Sourcing
Capture all state changes as an immutable sequence of events:
```
Command -> Validate -> Append Event to Event Store -> Update Read Model
```

**Event Store (DynamoDB):**
```
Table: {app-name}-event-store
PK: aggregate_id (String)
SK: version (Number, monotonically increasing)
Attributes:
  - event_type: String
  - event_data: Map (the event payload)
  - timestamp: String (ISO 8601)
  - correlation_id: String
  - caused_by: String (parent event ID)
GSI1: event_type + timestamp (for type-based queries)
Stream: enabled (for projections and downstream consumers)
```

**Projection (Read Model):**
- DynamoDB Stream -> Lambda -> Aurora PostgreSQL (materialized view)
- Read model is disposable and rebuilt from event store if corrupted
- Multiple read models for different query patterns

### Pattern 3: CQRS (Command Query Responsibility Segregation)
Separate write model (event store) from read model (query-optimized):
```
Commands -> Write Service -> Event Store (DynamoDB) -> Stream -> Read Model (Aurora)
Queries  -> Read Service  -> Read Model (Aurora)
```

**When to use CQRS:**
- Different scaling needs for reads vs writes
- Complex query patterns that don't fit DynamoDB
- Multiple consumers need different views of the same data
- Audit trail is a primary requirement

**When NOT to use CQRS:**
- Simple CRUD with balanced read/write ratios
- T3 applications (complexity not justified)
- Small data volumes (< 10K records)

### Pattern 4: Saga Orchestration (Step Functions)
For distributed transactions across multiple services:
```
Step Functions State Machine:
  1. Reserve Inventory -> Success? -> 2. Process Payment
  2. Process Payment -> Success? -> 3. Ship Order
  3. Ship Order -> Success? -> Complete
  Any Step Failure -> Compensating Actions (rollback previous steps)
```

**Compensating Actions:**
- Each step has a corresponding undo/compensate action
- Step Functions Catch block triggers compensating workflow
- All compensating actions are idempotent
- Saga state tracked in DynamoDB for recovery

## Dead Letter Queue Strategy

### DLQ Architecture
Every event-processing queue has a corresponding DLQ:
```
Main Queue: {app-name}-{handler}-queue
DLQ: {app-name}-{handler}-dlq
Redrive policy: maxReceiveCount = 3 (after 3 failures, move to DLQ)
```

**DLQ Monitoring:**
```
CloudWatch Alarm: ApproximateNumberOfMessagesVisible > 0
Action: P2 alert to ops team
Dashboard: DLQ depth trend over time
```

**DLQ Reprocessing:**
1. Investigate: Read DLQ messages, check error logs
2. Fix: Correct data issue or deploy code fix
3. Replay: Move messages from DLQ back to main queue
4. Verify: Confirm successful processing
5. Purge: Clear DLQ after successful replay

**Automated Replay (T1 only):**
- Lambda trigger on DLQ with delay
- Automatic retry after 1 hour for transient errors
- Manual intervention required for data errors

### Poison Message Handling
Messages that repeatedly fail after DLQ replay:
1. Move to permanent error store (S3)
2. Create incident ticket (SNS -> ServiceNow integration)
3. Manual remediation workflow
4. Never silently drop messages

## Ordering and Deduplication

### SQS FIFO for Ordered Processing
When event order matters (e.g., status transitions must be applied in sequence):
```
Queue: {app-name}-{handler}-queue.fifo
Deduplication: Content-based (SHA-256 of message body)
Message group: Partition key (e.g., entity_id)
Throughput: 300 msg/sec per group, 3000 msg/sec per queue (high throughput mode)
```

**Message Group Strategy:**
- Group by entity ID: All events for the same entity processed in order
- Group by partition: Distribute load across consumers while maintaining per-entity order
- Single group: All events globally ordered (low throughput, avoid if possible)

### EventBridge to SQS FIFO Bridge
EventBridge does not guarantee ordering. For ordered processing:
```
EventBridge Rule -> SQS FIFO Queue -> Lambda/Fargate Handler
```

The SQS FIFO queue provides the ordering guarantee that EventBridge cannot.

### At-Least-Once to Exactly-Once
EventBridge and SQS provide at-least-once delivery. For exactly-once semantics:

**DynamoDB Conditional Write:**
```python
try:
    table.put_item(
        Item={'event_id': event['id'], 'processed_at': now(), ...},
        ConditionExpression='attribute_not_exists(event_id)'
    )
    # First time processing - do work
    process(event)
except ConditionalCheckFailedException:
    # Already processed - skip
    pass
```

**PostgreSQL Advisory Lock:**
```sql
SELECT pg_try_advisory_lock(hashtext(:event_id));
-- If lock acquired, process event
-- If not, another instance is processing or has processed it
```

## Observability

### Event-Specific Metrics
| Metric | Description | Alarm |
|--------|------------|-------|
| events.received | Events received per source | Baseline deviation |
| events.processed | Successfully processed events | Drop > 20% from baseline |
| events.failed | Failed event processing | > 0 for T1, > 5% for T2/T3 |
| events.latency | Time from event creation to processing | > SLA threshold |
| events.dlq_depth | Messages in DLQ | > 0 |
| events.duplicate | Deduplicated events (informational) | > 10% of total |

### Event Tracing
Every event carries a correlation ID through the entire processing chain:
```
correlation_id: Original request/event ID
caused_by: Parent event ID (for event chains)
trace_id: Datadog distributed trace ID
```

**Event Flow Visualization:**
- Datadog APM: Service map showing event flow between services
- CloudWatch Logs Insights: Query event processing by correlation ID
- EventBridge Archive: Replay historical events for debugging

## Tier-Specific Variations

### T1 (Mission Critical) Additions
- Multi-AZ SQS FIFO for ordered processing
- DynamoDB global tables for event store (cross-region)
- Automated DLQ replay with exponential backoff
- Real-time event flow monitoring dashboard
- SWIM data: Guaranteed messaging with Solace HA
- Event store retention: Indefinite (regulatory)
- Cost range: $1,000-3,000/month

### T2 (Important) Baseline
- Standard SQS (FIFO where order matters)
- DynamoDB single-region event store
- Manual DLQ replay
- Standard monitoring
- SWIM data: Standard Solace subscription
- Event store retention: 1 year
- Cost range: $300-900/month

### T3 (Low Impact) Simplifications
- Standard SQS (no FIFO unless required)
- DynamoDB on-demand with TTL
- Basic DLQ monitoring
- Minimal custom metrics
- No SWIM (T3 apps rarely integrate with NAS)
- Event store retention: 90 days
- Cost range: $50-250/month

## Cost Estimate Breakdown

### T3 (~$50-250/month)
| Service | Monthly Cost |
|---------|-------------|
| EventBridge (< 1M events) | $1-5 |
| SQS Standard (< 1M messages) | $0-2 |
| Lambda (< 1M invocations, 256 MB) | $5-20 |
| DynamoDB on-demand (< 1 GB) | $1-5 |
| CloudWatch | $5-15 |
| Datadog (serverless monitoring) | $30-60 |
| **Total** | **$42-107** |

### T2 (~$300-900/month)
| Service | Monthly Cost |
|---------|-------------|
| EventBridge (< 10M events) | $5-15 |
| SQS Standard + FIFO | $5-20 |
| Lambda (< 10M invocations, 512 MB) | $20-80 |
| DynamoDB on-demand (< 10 GB) | $10-40 |
| Aurora Serverless v2 (read model) | $100-300 |
| Monitoring (Datadog + CloudWatch) | $50-150 |
| **Total** | **$190-605** |

### T1 (~$1,000-3,000/month)
| Service | Monthly Cost |
|---------|-------------|
| EventBridge (< 100M events) | $15-50 |
| SQS FIFO (high throughput) | $20-60 |
| Lambda (provisioned, 1 GB) | $80-250 |
| DynamoDB (provisioned, global tables) | $50-200 |
| Aurora Serverless v2 (multi-AZ, read model) | $200-600 |
| Solace PubSub+ (SWIM integration) | $200-500 |
| Monitoring (Datadog, enhanced) | $100-300 |
| Cross-region data transfer | $30-100 |
| **Total** | **$695-2,060** |
