# Archetype: Legacy Adapter (Facade / Strangler Fig)

## Overview
Reference architecture for creating adapter services that provide a modern interface
over legacy systems that cannot be immediately modernized. The adapter acts as a facade,
translating between modern consumers (REST, JSON, OAuth2) and legacy systems (SOAP, XML,
legacy auth, direct database access).

This archetype is used when:
- The legacy system is not yet scheduled for modernization
- Modern consumers need to integrate with legacy systems
- A strangler fig migration is underway (gradual endpoint migration)
- Legacy protocols must be bridged to modern standards

## Architecture Diagram (Text)

```
  +-------------------+     +-------------------+
  | Modern Consumer   |     | Modern Consumer   |
  | (SPA, API)        |     | (Event-Driven)    |
  +--------+----------+     +--------+----------+
           |                          |
  +--------+----------+     +--------+----------+
  |     Gravitee      |     |   EventBridge     |
  | (MANDATORY API GW)|     |                   |
  +--------+----------+     +--------+----------+
           |                          |
  +--------+----------+     +--------+----------+
  |       ALB         |     | Lambda Adapter    |
  | (internal)        |     | (event-triggered) |
  +--------+----------+     +--------+----------+
           |                          |
  +--------+--------------------------+----------+
  |              Adapter Layer                   |
  |  (Protocol Translation + Auth Bridge)        |
  +--------+--------------------------+----------+
           |                          |
  +--------+----------+     +--------+----------+
  | Legacy System     |     | Legacy Database   |
  | (SOAP, mainframe) |     | (Oracle, DB2)     |
  +-------------------+     +-------------------+
```

## Adapter Patterns

### Pattern 1: REST-to-SOAP Adapter
For legacy systems that expose SOAP/WSDL web services:

```
Modern Consumer -> Gravitee -> ALB -> Fargate Adapter -> Legacy SOAP Service

Adapter responsibilities:
  1. Receive REST/JSON request
  2. Validate input (Pydantic/JSON Schema)
  3. Transform JSON -> SOAP XML (using Jinja2 templates or XSLT)
  4. Add WS-Security headers (if legacy requires)
  5. Send SOAP request to legacy endpoint
  6. Parse SOAP XML response
  7. Transform XML -> JSON
  8. Return REST/JSON response
```

**Implementation (FastAPI + zeep):**
```python
# Adapter service structure
adapter/
  main.py                 # FastAPI app
  api/
    v1/
      routes/
        resource_a.py     # REST endpoint for resource A
        resource_b.py     # REST endpoint for resource B
  adapters/
    soap_client.py        # SOAP client wrapper (zeep)
    xml_transformer.py    # JSON <-> XML transformation
    auth_bridge.py        # Legacy auth credential injection
  models/
    request_schemas.py    # Modern JSON request schemas
    response_schemas.py   # Modern JSON response schemas
    soap_templates/       # SOAP request XML templates
      get_resource_a.xml
      update_resource_b.xml
```

**SOAP Client Configuration:**
```python
from zeep import Client, Transport
from zeep.wsse.username import UsernameToken

transport = Transport(
    timeout=30,
    operation_timeout=30,
    session=session  # requests Session with TLS cert
)

# Credentials from CyberArk (MANDATORY)
wsse = UsernameToken(
    username=cyberark_client.get_credential("legacy-soap-user"),
    password=cyberark_client.get_credential("legacy-soap-pass")
)

client = Client(
    wsdl="https://legacy-system.faa.gov/service?wsdl",
    transport=transport,
    wsse=wsse
)
```

### Pattern 2: Database Facade (Read-Only API)
For legacy databases that need modern API exposure without modifying the legacy system:

```
Modern Consumer -> Gravitee -> ALB -> Fargate Adapter -> Legacy Oracle DB (read-only)

Adapter responsibilities:
  1. Receive REST/JSON request
  2. Validate input
  3. Execute read-only SQL against legacy database
  4. Transform result set to JSON
  5. Cache response (Gravitee + ElastiCache)
  6. Return REST/JSON response
```

**Read-Only Safeguards:**
```python
# Database connection with read-only safeguards
engine = create_engine(
    oracle_connection_string,
    connect_args={
        "session_role": "READ_ONLY_ROLE"  # Oracle read-only role
    },
    pool_size=5,
    max_overflow=10,
    pool_pre_ping=True
)

# Additional safeguard: Execute only SELECT statements
def execute_query(sql: str, params: dict):
    normalized = sql.strip().upper()
    if not normalized.startswith("SELECT"):
        raise SecurityError("Only SELECT statements allowed on legacy database")
    # Execute with parameterized query (MANDATORY - never concatenate)
    with engine.connect() as conn:
        result = conn.execute(text(sql), params)
        return [dict(row) for row in result]
```

**Caching Strategy:**
```
Layer 1: Gravitee response cache (TTL: 5 min for list endpoints, 1 min for detail)
Layer 2: ElastiCache Redis (TTL: 15 min for reference data, 5 min for transactional)
Layer 3: Application in-memory (TTL: 5 min for configuration, schema metadata)

Cache invalidation:
  - TTL-based (primary, since legacy system changes are not event-driven)
  - Manual purge endpoint (for ops team to force refresh)
  - Scheduled refresh for critical reference data (EventBridge -> Lambda)
```

### Pattern 3: Protocol Bridge (SWIM/Solace)
For bridging SWIM data from Solace PubSub+ to EventBridge for modern consumers:

```
Solace PubSub+ -> Lambda Bridge -> EventBridge Custom Bus -> Modern Consumers

Bridge responsibilities:
  1. Subscribe to Solace topic (SWIM data)
  2. Parse SWIM message format (FIXM/AIXM XML)
  3. Transform to JSON event envelope
  4. Publish to EventBridge custom bus
  5. Handle backpressure (SQS buffer if EventBridge throttles)
```

**Solace-to-EventBridge Bridge:**
```python
# Lambda function triggered by Solace queue (via REST delivery point)
def handler(event, context):
    swim_message = event['body']

    # Parse SWIM XML
    parsed = parse_swim_message(swim_message)

    # Transform to EventBridge event
    eb_event = {
        'Source': 'faa.swim.bridge',
        'DetailType': f'SWIM.{parsed["message_type"]}',
        'Detail': json.dumps({
            'correlation_id': str(uuid.uuid4()),
            'swim_message_id': parsed['message_id'],
            'data': parsed['payload'],
            'received_at': datetime.utcnow().isoformat()
        }),
        'EventBusName': f'{app_name}-events'
    }

    eventbridge.put_events(Entries=[eb_event])
```

### Pattern 4: Strangler Fig Migration
Gradually migrating endpoints from legacy to modern implementation:

```
Gravitee routes:
  /v1/resources          -> Modern Service (migrated)
  /v1/resources/{id}     -> Modern Service (migrated)
  /v1/legacy-endpoint-a  -> Adapter -> Legacy System (not yet migrated)
  /v1/legacy-endpoint-b  -> Adapter -> Legacy System (not yet migrated)
```

**Strangler Fig Implementation:**
```
Phase 1: All traffic -> Adapter -> Legacy System
Phase 2: Migrate read endpoints -> Modern Service (writes still via adapter)
Phase 3: Migrate write endpoints -> Modern Service
Phase 4: Adapter handles only unmigrated endpoints
Phase 5: All endpoints on Modern Service, adapter decommissioned
```

**Gravitee Route Management:**
```
Gravitee API plan:
  - Path-based routing rules
  - Traffic splitting (canary: 10% to modern, 90% to adapter)
  - A/B comparison (log responses from both, compare)
  - Rollback: Instantly reroute back to adapter if modern service fails
```

**Migration Tracking:**
```
Endpoint Migration Status:
  GET  /v1/resources         -> MIGRATED (2026-01-15)
  POST /v1/resources         -> MIGRATED (2026-02-01)
  GET  /v1/resources/{id}    -> MIGRATED (2026-01-15)
  PUT  /v1/resources/{id}    -> IN PROGRESS (target: 2026-03-01)
  GET  /v1/reports           -> NOT STARTED (target: 2026-04-01)
  POST /v1/legacy-action     -> BLOCKED (dependency on legacy batch job)
```

## Compute Tier

### Fargate Adapter Service
```
CPU: 0.25 vCPU (T3) | 0.5 vCPU (T2) | 1 vCPU (T1)
Memory: 0.5 GB (T3) | 1 GB (T2) | 2 GB (T1)
Tasks: 1 (T3) | 2 (T2) | 3 (T1)
Auto-scaling: Based on request count (same as api-service archetype)
```

**Adapter-Specific Configuration:**
- Connection timeout to legacy: 30s (legacy systems are slow)
- Read timeout: 60s (some legacy queries take time)
- Circuit breaker: Open after 5 consecutive failures to legacy
- Retry: 2 retries with exponential backoff for transient errors
- Bulkhead: Limit concurrent connections to legacy system (prevent overload)

### Lambda Adapter (Event-Triggered)
For event-driven protocol bridging (SWIM, file triggers):
```
Runtime: Python 3.12
Memory: 512 MB
Timeout: 60s
Concurrency: Reserved (prevent legacy system overload)
  - T3: 5 concurrent
  - T2: 20 concurrent
  - T1: 50 concurrent
```

## Authentication Bridge

### Modern-to-Legacy Auth Translation
The adapter translates modern auth (OKTA JWT) to legacy auth mechanisms:

| Modern Auth | Legacy Auth | Bridge Strategy |
|------------|------------|----------------|
| OKTA JWT (Bearer) | Basic Auth | Extract user from JWT, inject Basic header from CyberArk |
| OKTA JWT (Bearer) | WS-Security | Extract user from JWT, build WSSE token |
| OKTA JWT (Bearer) | NTLM | Not supported; if NTLM required, use EC2 with domain join |
| OKTA JWT (Bearer) | API Key (legacy) | Map OKTA client to legacy API key from CyberArk |
| OKTA JWT (Bearer) | Database user | Map OKTA user to DB role, use CyberArk credential |

**Auth Bridge Implementation:**
```python
class AuthBridge:
    def __init__(self, cyberark_client):
        self.cyberark = cyberark_client

    def translate_auth(self, okta_jwt: dict, legacy_auth_type: str) -> dict:
        user_id = okta_jwt['sub']

        if legacy_auth_type == 'basic':
            cred = self.cyberark.get_credential(f'legacy-{user_id}')
            return {'Authorization': f'Basic {base64_encode(cred)}'}

        if legacy_auth_type == 'ws-security':
            cred = self.cyberark.get_credential('legacy-soap-service')
            return build_wsse_token(cred['username'], cred['password'])

        if legacy_auth_type == 'api-key':
            key = self.cyberark.get_credential('legacy-api-key')
            return {'X-API-Key': key}
```

All legacy credentials are stored in CyberArk (MANDATORY). Never hardcode credentials.

## Data Transformation

### JSON to XML Transformation
```python
# Using Jinja2 templates for SOAP request generation
from jinja2 import Environment, FileSystemLoader

env = Environment(loader=FileSystemLoader('soap_templates'))

def to_soap_request(template_name: str, data: dict) -> str:
    template = env.get_template(f'{template_name}.xml')
    return template.render(**data)
```

**SOAP Template Example:**
```xml
<?xml version="1.0" encoding="UTF-8"?>
<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/"
                  xmlns:ns="http://legacy.faa.gov/service">
  <soapenv:Header>
    {{ wsse_header }}
  </soapenv:Header>
  <soapenv:Body>
    <ns:GetResource>
      <ns:ResourceId>{{ resource_id }}</ns:ResourceId>
      <ns:IncludeDetails>{{ include_details | lower }}</ns:IncludeDetails>
    </ns:GetResource>
  </soapenv:Body>
</soapenv:Envelope>
```

### XML to JSON Transformation
```python
import xmltodict

def xml_to_json(xml_response: str, root_element: str) -> dict:
    parsed = xmltodict.parse(xml_response)
    # Navigate to the response body
    body = parsed['soapenv:Envelope']['soapenv:Body']
    data = body[root_element]
    # Flatten XML attributes and normalize keys
    return normalize_keys(data)

def normalize_keys(data):
    """Convert XML-style keys to JSON-style (camelCase, remove @attributes)."""
    if isinstance(data, dict):
        return {
            to_camel_case(k.lstrip('@')): normalize_keys(v)
            for k, v in data.items()
            if not k.startswith('#')
        }
    if isinstance(data, list):
        return [normalize_keys(item) for item in data]
    return data
```

## Lifecycle Management

### Adapter Sunset Planning
Every adapter has an explicit sunset date tracked in the architecture blueprint:

```yaml
adapter_lifecycle:
  created: 2026-01-15
  purpose: "REST facade over Legacy System X SOAP services"
  endpoints_count: 12
  sunset_target: 2027-06-30
  sunset_dependency: "Legacy System X modernization (Wave 3)"
  migration_tracking_url: "https://github.com/faa/legacy-x-migration/projects/1"
  status: active  # active | deprecating | sunset
```

**Sunset Checklist:**
- [ ] All consumers migrated to modern service
- [ ] No traffic to adapter endpoints for 30 days
- [ ] Modern service covers 100% of adapter functionality
- [ ] Adapter infrastructure deprovisioned
- [ ] Gravitee routes updated (remove adapter routes)
- [ ] CyberArk credentials for legacy system rotated/removed
- [ ] Documentation updated (adapter removed from architecture diagrams)

### Adapter Metrics (Track Migration Progress)
| Metric | Purpose |
|--------|---------|
| adapter.requests.total | Total traffic through adapter (should decrease over time) |
| adapter.requests.by_endpoint | Per-endpoint traffic (identify high-traffic endpoints to migrate first) |
| adapter.latency.p99 | Legacy system response time (justifies migration urgency) |
| adapter.errors.legacy | Legacy system errors (reliability case for migration) |
| adapter.endpoints.migrated | Count of endpoints moved to modern service |
| adapter.endpoints.remaining | Count of endpoints still on adapter |

## Observability

### Adapter-Specific Monitoring
| Metric | Alarm Threshold | Severity |
|--------|----------------|----------|
| Legacy system response time P99 | > 5s for 5 min | P2 |
| Legacy system error rate | > 10% for 2 min | P1 |
| Adapter transformation errors | > 1% for 5 min | P2 |
| Circuit breaker open | Any circuit open | P1 |
| Legacy system connection pool exhaustion | > 80% for 5 min | P1 |
| Cache hit ratio | < 50% for 30 min | P3 |

### Correlation Tracking
```
Request flow logging:
  1. Gravitee: X-Request-ID assigned
  2. Adapter: Log {request_id, legacy_request_id, transformation_time_ms}
  3. Legacy: Log {legacy_request_id, legacy_response_time_ms}
  4. Adapter: Log {request_id, total_time_ms, transformation_time_ms, legacy_time_ms}

This allows decomposition of latency: adapter overhead vs legacy system time.
```

## Security

### Network
```
Adapter -> Legacy System:
  - VPN or Direct Connect (if legacy is on-premises)
  - VPC peering (if legacy is in a different AWS account)
  - TLS 1.2+ (minimum, even if legacy supports lower)
  - Firewall rules: Allow only adapter security group to legacy IP/port

Legacy Database Access:
  - Read-only database user (MANDATORY for database facade pattern)
  - Connection from private subnet only
  - Parameterized queries only (no string concatenation)
  - Query result size limit (prevent full table dumps)
```

### Input Validation
- Validate all modern consumer inputs before sending to legacy
- Sanitize legacy responses before returning to modern consumers
- Strip internal legacy error details from responses (return generic error)
- Log full legacy errors to Datadog (not exposed to consumers)

## Tier-Specific Variations

### T1 (Mission Critical) Additions
- Multi-AZ adapter with 3 task minimum
- Circuit breaker with automated failover to cached responses
- Real-time legacy health monitoring
- Dual-path validation during strangler fig migration
- Cost range: $800-2,000/month

### T2 (Important) Baseline
- Multi-AZ adapter with 2 task minimum
- Circuit breaker with manual failover
- Standard monitoring
- Single-path routing (adapter or modern, not both)
- Cost range: $200-600/month

### T3 (Low Impact) Simplifications
- Single-AZ adapter with 1 task
- Timeout-based resilience (no circuit breaker)
- Basic monitoring
- No caching (unless performance requires it)
- Cost range: $100-300/month

## Cost Estimate Breakdown

### T3 (~$100-300/month)
| Service | Monthly Cost |
|---------|-------------|
| ECS Fargate (0.25 vCPU, 0.5 GB, 1 task) | $10-15 |
| ALB | $25 |
| NAT Gateway | $35 |
| Datadog (1 host) | $25-50 |
| Other (ECR, KMS, CloudWatch) | $10-20 |
| VPN/Direct Connect (shared, amortized) | $20-50 |
| **Total** | **$125-195** |

### T2 (~$200-600/month)
| Service | Monthly Cost |
|---------|-------------|
| ECS Fargate (0.5 vCPU, 1 GB, 2 tasks) | $30-50 |
| ElastiCache Redis (cache.t4g.micro) | $25-40 |
| ALB + NAT | $60-70 |
| Lambda (event bridge, if needed) | $5-20 |
| Monitoring (Datadog + CloudWatch) | $50-100 |
| VPN/Direct Connect (shared) | $30-80 |
| Other | $15-30 |
| **Total** | **$215-390** |

### T1 (~$800-2,000/month)
| Service | Monthly Cost |
|---------|-------------|
| ECS Fargate (1 vCPU, 2 GB, 3 tasks) | $80-150 |
| ElastiCache Redis (cache.r7g.large) | $200-400 |
| ALB + NAT (multi-AZ) | $70-140 |
| Lambda (event bridge) | $10-40 |
| Monitoring (Datadog, enhanced) | $100-250 |
| VPN/Direct Connect (dedicated) | $100-300 |
| Other | $30-80 |
| **Total** | **$590-1,360** |
