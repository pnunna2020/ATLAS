# Archetype: Analytics Platform (Data Lake + QuickSight)

## Overview
Reference architecture for modernizing legacy reporting and analytics systems on AWS
GovCloud. Targets OBIEE, Oracle Reports, Crystal Reports, SSRS, and custom SQL-based
reporting systems.

Analytics platforms are the third most common archetype. Many FAA applications have
embedded reporting that should be extracted into a dedicated analytics layer during
modernization.

## Architecture Diagram (Text)

```
  +-----------+     +-----------+     +-------------+
  | Aurora    |     | S3 Files  |     | External    |
  | (OLTP DB) |     | (batch)   |     | APIs        |
  +-----+-----+     +-----+-----+     +------+------+
        |                 |                   |
  +-----+-----+     +-----+-----+     +------+------+
  | DMS (CDC) |     | Step Fns  |     | Lambda      |
  |           |     | + Lambda  |     | Ingestion   |
  +-----+-----+     +-----+-----+     +------+------+
        |                 |                   |
        +--------+--------+--------+----------+
                 |
          +------+------+
          | S3 Data Lake|  (Parquet, partitioned)
          | Raw / Clean |
          | / Curated   |
          +------+------+
                 |
          +------+------+
          | Glue Catalog|  (schema registry)
          +------+------+
                 |
       +---------+---------+
       |                   |
+------+------+     +------+------+
| Redshift    |     | Athena      |
| Serverless  |     | (ad-hoc SQL)|
+------+------+     +------+------+
       |
+------+------+
| QuickSight  |  (dashboards, reports)
| SPICE       |
+------+------+
       |
+------+------+
| OKTA SSO    |  (MANDATORY auth)
+-------------+
```

## Data Lake Architecture

### S3 Data Lake Zones
The data lake uses a three-zone architecture:

```
s3://{app-name}-data-lake-{env}/
  raw/                          # Zone 1: Raw data as ingested
    {source}/{date}/
      data.parquet
      _metadata.json
  clean/                        # Zone 2: Validated, deduplicated
    {domain}/{date}/
      data.parquet
      _schema.json
  curated/                      # Zone 3: Business-ready, aggregated
    {domain}/{table-name}/
      year={YYYY}/month={MM}/
        data.parquet
```

**Zone Definitions:**
| Zone | Purpose | Format | Retention | Access |
|------|---------|--------|-----------|--------|
| Raw | Immutable ingest, audit trail | Parquet (compressed) | Indefinite | ETL jobs only |
| Clean | Validated, deduplicated, typed | Parquet (columnar) | 2 years | ETL + analysts |
| Curated | Business-ready, aggregated | Parquet (optimized) | As needed | QuickSight + Athena |

**S3 Configuration:**
```
Encryption: SSE-KMS (MANDATORY, customer-managed CMK)
Versioning: enabled (raw zone only)
Lifecycle:
  - raw: S3 Standard -> S3 IA after 90 days -> Glacier after 1 year
  - clean: S3 Standard -> S3 IA after 180 days
  - curated: S3 Standard (frequently accessed)
Block public access: enabled (all 4 settings)
Bucket policy: Restrict to VPC endpoint + specific IAM roles
```

### Partitioning Strategy
Partition curated data by common query patterns:
```
# Time-based (most common)
s3://bucket/curated/flights/year=2026/month=01/day=15/data.parquet

# Category-based
s3://bucket/curated/airports/region=eastern/state=VA/data.parquet

# Hybrid
s3://bucket/curated/maintenance/aircraft_type=B737/year=2026/data.parquet
```

**Partition guidelines:**
- Partition by the most common WHERE clause dimension
- Aim for 128 MB - 1 GB per partition file
- Too many small files = slow queries (Athena "small files problem")
- Too few large files = unnecessary data scanning

### File Format: Parquet
All data lake storage uses Apache Parquet:
- Columnar storage (read only the columns you query)
- Efficient compression (Snappy or ZSTD)
- Schema embedded in file (self-describing)
- Predicate pushdown support (Athena/Redshift skip irrelevant row groups)
- Type-safe (no CSV parsing ambiguity)

## Data Ingestion

### Pattern 1: CDC from OLTP Database (DMS)
For continuous replication from Aurora or legacy databases:
```
Source DB -> DMS Replication Instance -> S3 Raw Zone (Parquet)
```

**DMS Configuration:**
```
Replication instance: dms.t3.medium (T3) | dms.r5.large (T1)
Source endpoint: Aurora PostgreSQL (or Oracle for legacy)
Target endpoint: S3 bucket (raw zone)
Migration type: Full load + ongoing replication (CDC)
Output format: Parquet
Partition: Date-based (hourly or daily)
```

**CDC Considerations:**
- Full load: Initial snapshot of all tables
- Ongoing changes: INSERT, UPDATE, DELETE captured as change records
- Schema changes: DMS handles ADD COLUMN; DROP COLUMN requires manual intervention
- LOB handling: Full LOB mode for small LOBs, limited LOB for large (set max size)

### Pattern 2: Batch File Ingestion (Step Functions)
For scheduled data loads from files, APIs, or batch exports:
```
EventBridge Schedule -> Step Functions -> Lambda (extract) -> S3 Raw -> Lambda (clean) -> S3 Clean
```

**Step Functions Pipeline:**
```
1. List new files in S3 raw/
2. Map: For each file:
   a. Validate schema (match expected columns, types)
   b. Deduplicate (hash-based on business key)
   c. Transform (rename columns, convert types, apply business rules)
   d. Write to S3 clean/ (Parquet)
3. Update Glue Catalog partitions
4. Trigger Redshift COPY (if warehouse loading)
5. Notify downstream (EventBridge event)
```

### Pattern 3: API Ingestion (Lambda)
For pulling data from external APIs:
```
EventBridge Schedule -> Lambda -> External API -> S3 Raw
```

**API Ingestion Patterns:**
- Full refresh: Replace entire dataset on each run
- Incremental: Fetch only records changed since last run (watermark in DynamoDB)
- Event-driven: Subscribe to webhooks/events for real-time updates

## AWS Glue Data Catalog

### Schema Registry
Glue Catalog serves as the metadata repository for all data lake tables:
```
Database: {app-name}_raw | {app-name}_clean | {app-name}_curated
Tables: Auto-discovered by Glue Crawler or manually defined
Partitions: Registered on each ETL run
Schema versioning: Glue Schema Registry (if strict schema evolution needed)
```

**Glue Crawler Configuration:**
```
Schedule: After each ETL run (triggered by Step Functions)
Classifiers: Parquet (auto-detected)
Update behavior: Update table definition in place
Schema change policy: Log + alert on breaking changes
IAM role: Minimal permissions (S3 read + Glue write)
```

**Manual Table Definition (preferred for curated zone):**
```python
# Define table in Terraform (preferred over crawler for curated)
resource "aws_glue_catalog_table" "flights" {
  database_name = "app_curated"
  name          = "flights"
  table_type    = "EXTERNAL_TABLE"

  parameters = {
    "classification" = "parquet"
    "parquet.compression" = "SNAPPY"
  }

  storage_descriptor {
    location      = "s3://bucket/curated/flights/"
    input_format  = "org.apache.hadoop.hive.ql.io.parquet.MapredParquetInputFormat"
    output_format = "org.apache.hadoop.hive.ql.io.parquet.MapredParquetOutputFormat"

    columns {
      name = "flight_id"
      type = "string"
    }
    # ... additional columns
  }

  partition_keys {
    name = "year"
    type = "string"
  }
}
```

## Redshift Serverless (Data Warehouse)

### When to Use Redshift
Use Redshift Serverless for:
- Complex analytical queries (multi-table joins, window functions, aggregations)
- Pre-computed materialized views for QuickSight
- Historical trend analysis across large datasets (> 100 GB)
- Cross-domain analytics (joining data from multiple sources)

Do NOT use Redshift for:
- Simple queries on < 10 GB data (use Athena instead)
- OLTP workloads (use Aurora)
- Key-value lookups (use DynamoDB)

### Redshift Serverless Configuration
```
Namespace: {app-name}-analytics
Workgroup: {app-name}-wg
Base RPU: 8 (T3) | 32 (T2) | 128 (T1)
Max RPU: 32 (T3) | 128 (T2) | 512 (T1)
Usage limits:
  - T3: 100 RPU-hours/day
  - T2: 500 RPU-hours/day
  - T1: Unlimited
Encryption: KMS (MANDATORY)
VPC: Private subnet (same VPC as data lake)
```

### Data Loading
```sql
-- COPY from S3 (Parquet) - bulk load
COPY flights
FROM 's3://bucket/curated/flights/'
IAM_ROLE 'arn:aws-us-gov:iam::123456789012:role/redshift-s3-role'
FORMAT AS PARQUET;

-- Materialized views for QuickSight SPICE refresh
CREATE MATERIALIZED VIEW mv_daily_flights AS
SELECT
  date_trunc('day', departure_time) as flight_date,
  origin_airport,
  destination_airport,
  COUNT(*) as flight_count,
  AVG(delay_minutes) as avg_delay
FROM flights
WHERE departure_time >= CURRENT_DATE - INTERVAL '365 days'
GROUP BY 1, 2, 3;
```

### Materialized Views
Pre-compute common dashboard queries as materialized views:
- Reduces QuickSight query complexity
- Refreshed on schedule (after each ETL load)
- Auto-refreshed by Redshift (if configured)

## Athena (Ad-Hoc SQL)

### When to Use Athena
Use Athena for:
- Ad-hoc SQL queries directly on S3 data
- Data exploration during development
- Queries that don't justify Redshift cost
- One-time or infrequent analysis

### Athena Configuration
```
Workgroup: {app-name}-athena
Result location: s3://{app-name}-athena-results/
Encryption: SSE-KMS
Query result retention: 90 days
Cost control: Per-query data scan limit (10 GB for T3, 100 GB for T2)
```

### Athena Federated Query
For querying across data sources without ETL:
```sql
-- Query Aurora directly from Athena (via Lambda connector)
SELECT a.flight_id, b.passenger_name
FROM curated.flights a
JOIN aurora_connector.passengers b ON a.flight_id = b.flight_id
WHERE a.flight_date = '2026-01-15';
```

## Amazon QuickSight (Dashboards)

### QuickSight Architecture
QuickSight is the MANDATORY replacement for OBIEE, Oracle Reports, Crystal Reports,
and SSRS in the FAA environment.

**Deployment Configuration:**
```
Edition: Enterprise (required for OKTA SSO + row-level security)
Region: us-gov-west-1 (GovCloud)
SPICE capacity: 10 GB (T3) | 100 GB (T2) | 500 GB (T1)
User provisioning: OKTA SCIM (automatic from OKTA groups)
```

### OKTA SSO Integration
```
Federation: OKTA -> QuickSight (SAML 2.0)
User provisioning: OKTA SCIM -> QuickSight
Groups: Map OKTA groups to QuickSight groups
Roles:
  - Admin: QuickSight administrators (OKTA admin group)
  - Author: Dashboard creators (OKTA author group)
  - Reader: Dashboard viewers (OKTA reader group)
```

### SPICE Datasets
SPICE (Super-fast, Parallel, In-memory Calculation Engine) caches data for
fast dashboard performance:

**Data Source Connections:**
| Source | Connection Type | Refresh Schedule |
|--------|---------------|-----------------|
| Redshift | Direct query or SPICE import | Hourly SPICE refresh |
| Athena | SPICE import (recommended) | Daily SPICE refresh |
| S3 (manifest) | SPICE import | On-demand |
| Aurora | Direct query | Real-time (T1 only) |

**SPICE Refresh:**
```
Schedule: After each ETL completion (EventBridge -> Lambda -> QuickSight API)
Full refresh: Daily (overnight)
Incremental refresh: Hourly (append-only datasets)
Failure alert: SNS notification on refresh failure
```

### Dashboard Design Standards
FAA QuickSight dashboards must follow these standards:

**Branding:**
- QuickSight theme: Custom FAA theme (#15396c primary, Source Sans Pro font)
- Dashboard title: Application name + dashboard purpose
- Footer: Data refresh timestamp, data source, classification level

**Common Dashboard Types:**
| Legacy Report Type | QuickSight Equivalent |
|-------------------|---------------------|
| OBIEE Interactive Dashboard | QuickSight Analysis (interactive) |
| Oracle Reports (paginated) | QuickSight Paginated Report |
| Crystal Reports (formatted) | QuickSight Paginated Report |
| SSRS Report | QuickSight Paginated Report |
| OBIEE Ad-hoc | QuickSight Explore (Q natural language) |
| Custom SQL Export (CSV) | QuickSight Export (CSV/PDF) |

### Row-Level Security (RLS)
Control data visibility based on user identity:
```
RLS Dataset:
  user_name: OKTA username
  region: allowed region filter
  org_code: allowed organization filter

Applied to: All datasets containing sensitive or scoped data
Enforcement: QuickSight applies filter before query execution
```

### Embedded Dashboards
For embedding QuickSight dashboards in other FAA applications:
```
Embedding type: Anonymous (public) or Registered User
Auth: OKTA JWT -> QuickSight AssumeRoleWithWebIdentity
URL: GenerateEmbedUrlForRegisteredUser API
CORS: Allow embedding application origin
```

## Legacy Report Migration

### OBIEE to QuickSight
```
Step 1: Inventory all OBIEE dashboards, analyses, and reports
Step 2: Map OBIEE logical model to Redshift/Athena schema
Step 3: Recreate each dashboard in QuickSight
  - OBIEE Pivot Table -> QuickSight Pivot Table
  - OBIEE Chart -> QuickSight Visual (bar, line, pie, etc.)
  - OBIEE Filter -> QuickSight Parameter + Filter
  - OBIEE Prompt -> QuickSight Control (dropdown, date picker)
Step 4: Set up SPICE refresh schedule
Step 5: Validate data accuracy (compare OBIEE vs QuickSight output)
Step 6: User acceptance testing
Step 7: Redirect users to QuickSight, sunset OBIEE
```

### Oracle Reports to QuickSight Paginated Reports
```
Step 1: Inventory all Oracle Reports (RDF/JSP files)
Step 2: Extract report SQL queries
Step 3: Convert Oracle SQL to PostgreSQL SQL (via SCT or manual)
Step 4: Create QuickSight paginated report with same layout
Step 5: Map Oracle Report parameters to QuickSight parameters
Step 6: Schedule report delivery (email PDF) via QuickSight
```

## Observability

### Data Pipeline Monitoring
| Metric | Source | Alarm |
|--------|--------|-------|
| ETL job duration | Step Functions | > 2x historical average |
| ETL records processed | Custom CloudWatch metric | < 50% of expected |
| DMS replication lag | DMS CloudWatch metrics | > 5 minutes |
| Glue Crawler failures | Glue CloudWatch metrics | Any failure |
| SPICE refresh failure | QuickSight CloudWatch | Any failure |
| Redshift RPU usage | Redshift CloudWatch | > 80% of limit |
| Athena query cost | Athena CloudWatch | > daily budget |
| Data freshness | Custom metric | > SLA threshold |

### Data Quality Monitoring
```
Checks run after each ETL load:
  - Row count: Within expected range (baseline +/- 20%)
  - Null rate: Critical columns have < 1% null
  - Uniqueness: Primary keys are unique
  - Referential integrity: Foreign keys match parent table
  - Value range: Numeric values within business bounds
  - Freshness: Latest record timestamp within expected window
```

## Security

### Data Classification
| Zone | Classification | Access Control |
|------|---------------|---------------|
| Raw | Sensitive (may contain PII) | ETL IAM roles only |
| Clean | Internal | ETL + approved analyst roles |
| Curated | Internal | QuickSight, Athena, approved roles |

### Access Control
- S3: Bucket policy + IAM role-based access
- Glue Catalog: Resource-level IAM policies
- Redshift: Database users mapped to OKTA groups
- QuickSight: OKTA SSO + row-level security
- Athena: Workgroup-level IAM permissions

### Encryption
- S3: SSE-KMS (customer-managed CMK)
- Redshift: KMS encryption
- Glue Catalog: KMS encryption for metadata
- QuickSight SPICE: Encrypted at rest (automatic)
- In-transit: TLS 1.2+ for all connections

## Tier-Specific Variations

### T1 (Mission Critical) Additions
- Redshift Serverless with high RPU allocation (128-512)
- Cross-region S3 replication for data lake
- Real-time QuickSight dashboards (direct query to Aurora)
- DMS multi-AZ replication instance
- Data quality alerts on P1 severity
- Cost range: $1,500-4,000/month

### T2 (Important) Baseline
- Redshift Serverless with moderate RPU (32-128)
- Standard S3 data lake
- Hourly SPICE refresh
- Single-AZ DMS
- Data quality alerts on P2 severity
- Cost range: $400-1,200/month

### T3 (Low Impact) Simplifications
- Athena only (no Redshift)
- Minimal S3 data lake
- Daily SPICE refresh
- Simplified ETL (fewer transformation steps)
- Data quality checks on P3 severity
- Cost range: $100-400/month

## Cost Estimate Breakdown

### T3 (~$100-400/month)
| Service | Monthly Cost |
|---------|-------------|
| S3 (< 50 GB, lifecycle policies) | $2-10 |
| Glue Catalog + Crawler | $1-5 |
| Athena (< 1 TB scanned/month) | $5-20 |
| Step Functions + Lambda (ETL) | $5-20 |
| QuickSight (5 readers) | $25-50 |
| DMS (t3.medium, on-demand) | $30-60 |
| Monitoring | $20-50 |
| **Total** | **$88-215** |

### T2 (~$400-1,200/month)
| Service | Monthly Cost |
|---------|-------------|
| S3 (< 500 GB) | $10-30 |
| Glue Catalog + Crawler | $5-15 |
| Redshift Serverless (32-128 RPU) | $100-400 |
| Athena (supplemental) | $5-20 |
| QuickSight (20 readers, 5 authors) | $75-150 |
| DMS (r5.large) | $80-120 |
| Step Functions + Lambda | $10-30 |
| Monitoring | $50-100 |
| **Total** | **$335-865** |

### T1 (~$1,500-4,000/month)
| Service | Monthly Cost |
|---------|-------------|
| S3 (< 2 TB, cross-region) | $30-80 |
| Glue Catalog + Crawler | $10-25 |
| Redshift Serverless (128-512 RPU) | $500-1,500 |
| Athena (federated queries) | $20-60 |
| QuickSight (50 readers, 10 authors, SPICE 500 GB) | $200-500 |
| DMS (multi-AZ, r5.xlarge) | $200-350 |
| Step Functions + Lambda | $20-60 |
| Monitoring (Datadog + CloudWatch) | $100-300 |
| Cross-region transfer | $30-100 |
| **Total** | **$1,110-2,975** |
