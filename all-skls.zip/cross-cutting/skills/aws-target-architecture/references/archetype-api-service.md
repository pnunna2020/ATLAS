# Archetype: API Service (Headless Microservice)

## Overview
Reference architecture for modernizing or creating headless API services on AWS GovCloud.
These are backend services without a user interface that expose functionality via REST APIs
to other systems, SPAs, mobile clients, or third-party consumers.

Common legacy sources: Java EE EJBs exposed via SOAP, ColdFusion web services, .NET WCF
services, Oracle PL/SQL-based API layers.

## Architecture Diagram (Text)

```
         +-------------------+
         | External Consumer |
         +--------+----------+
                  |
         +--------+----------+
         |     Gravitee      |  (MANDATORY API Gateway)
         |   Rate Limiting   |
         |   Auth Validation |
         +--------+----------+
                  |
         +--------+----------+
         |       ALB         |  (internal, private subnet)
         +--------+----------+
                  |
    +-------------+-------------+
    |                           |
+---+---+                 +-----+-----+
| ECS   |  (Service A)   | ECS       |  (Service B, if decomposed)
|Fargate|                 | Fargate   |
+---+---+                 +-----+-----+
    |                           |
+---+---+                 +-----+-----+
|Aurora |                 | DynamoDB  |
|PgSQL  |                 | (k-v)    |
+-------+                 +-----------+
    |                           |
    +-------------+-------------+
                  |
         +--------+----------+
         |   EventBridge     |  (domain events, async)
         +--------+----------+
                  |
         +--------+----------+
         |  SQS / SNS       |  (work queues, notifications)
         +-------------------+
```

## API Design

### REST API Standards
All API services follow these conventions:

**URL Structure:**
```
https://api.{app-name}.faa.gov/v1/{resource}
https://api.{app-name}.faa.gov/v1/{resource}/{id}
https://api.{app-name}.faa.gov/v1/{resource}/{id}/{sub-resource}
```

**HTTP Methods:**
| Method | Usage | Idempotent | Response Code |
|--------|-------|-----------|---------------|
| GET | Retrieve resource(s) | Yes | 200 |
| POST | Create resource | No | 201 + Location header |
| PUT | Full replace | Yes | 200 |
| PATCH | Partial update | No | 200 |
| DELETE | Remove resource | Yes | 204 |

**Versioning Strategy:**
- URL path versioning: `/v1/`, `/v2/`
- Breaking changes require new version
- Old versions supported for 12 months minimum
- Sunset header on deprecated versions: `Sunset: Sat, 15 Jan 2028 00:00:00 GMT`

**Pagination:**
```json
GET /v1/resources?page=1&size=20&sort=created_at:desc

Response:
{
  "data": [...],
  "pagination": {
    "page": 1,
    "size": 20,
    "total_items": 150,
    "total_pages": 8,
    "links": {
      "self": "/v1/resources?page=1&size=20",
      "next": "/v1/resources?page=2&size=20",
      "last": "/v1/resources?page=8&size=20"
    }
  }
}
```

**Error Response Format (RFC 7807):**
```json
{
  "type": "https://api.faa.gov/errors/validation-error",
  "title": "Validation Error",
  "status": 422,
  "detail": "Field 'email' must be a valid email address",
  "instance": "/v1/users/123",
  "errors": [
    {
      "field": "email",
      "message": "Must be a valid email address",
      "code": "INVALID_EMAIL"
    }
  ],
  "trace_id": "abc-123-def"
}
```

**Content Negotiation:**
- Default: `application/json`
- Accept header: `application/json`, `application/xml` (if legacy consumers need XML)
- Request body: `application/json` only for new APIs
- Character encoding: UTF-8

### OpenAPI 3.0 Specification
Every API service must have a complete OpenAPI spec:
```yaml
openapi: 3.0.3
info:
  title: {App Name} API
  version: 1.0.0
  description: {Description}
  contact:
    name: {Team Name}
    email: {team-email}@faa.gov
servers:
  - url: https://api.{app-name}.faa.gov/v1
    description: Production
  - url: https://api.{app-name}.staging.faa.gov/v1
    description: Staging
security:
  - oauth2: [read, write]
paths:
  /{resource}:
    get:
      summary: List {resources}
      operationId: list{Resources}
      parameters:
        - $ref: '#/components/parameters/Page'
        - $ref: '#/components/parameters/Size'
      responses:
        '200':
          description: Success
          content:
            application/json:
              schema:
                $ref: '#/components/schemas/{Resource}List'
```

## Compute Tier

### ECS Fargate Service
Same base configuration as web-app archetype. API-specific considerations:

**Task Definition:**
```
CPU: 0.25 vCPU (T3) | 0.5 vCPU (T2) | 1 vCPU (T1)
Memory: 0.5 GB (T3) | 1 GB (T2) | 2 GB (T1)
Port: 8080 (HTTP)
Health check: GET /health
```

**Auto-Scaling for API Workloads:**
- Target tracking: Request count per target (ALB metric)
- Target: 1000 requests/minute per task (adjust based on load testing)
- Scale-out: 60s cooldown (respond quickly)
- Scale-in: 300s cooldown (avoid flapping)

**Graceful Shutdown:**
```
SIGTERM received:
  1. Stop accepting new connections
  2. Drain in-flight requests (30s timeout)
  3. Close database connections
  4. Exit cleanly
ALB deregistration delay: 30s (matches drain period)
```

## Service Discovery and Mesh

### AWS Cloud Map (Service Discovery)
For inter-service communication within the same VPC:
```
Namespace: {app-name}.local (private DNS)
Service: {service-name}
DNS record type: A (Fargate task IPs)
Health check: ECS task health
TTL: 10s
```

**Service-to-Service Call Pattern:**
```
Service A -> http://{service-b}.{app-name}.local:8080/v1/{resource}
```

### Inter-Service Authentication
Two approved patterns for service-to-service auth:

**Pattern 1: OAuth2 Client Credentials (preferred)**
```
Service A -> OKTA (client_credentials grant) -> JWT
Service A -> Service B (Authorization: Bearer {jwt})
Service B validates JWT issuer, audience, and scopes
```

**Pattern 2: mTLS (for high-security inter-service)**
```
Each service has: TLS cert issued by internal CA (ACM PCA)
Mutual TLS verification at ALB or application level
Used for T1 services where token-based auth is insufficient
```

Never use shared API keys or static tokens for service-to-service auth.

## Data Tier

### Database Selection Guide
| Access Pattern | Service | When to Use |
|---------------|---------|------------|
| Complex queries, joins, transactions | Aurora PostgreSQL | Default for relational data |
| Simple key-value lookups | DynamoDB | High-throughput, single-table design |
| Full-text search | Aurora + pg_trgm or OpenSearch | If search is a primary feature |
| Hot data cache | ElastiCache Redis | Frequently read, rarely changed |
| Time-series metrics | DynamoDB (or Timestream if approved) | IoT or telemetry data |

### Aurora PostgreSQL (Default)
Same as web-app archetype. API-specific additions:
- Connection pooling: RDS Proxy or PgBouncer sidecar (essential for API workloads)
- Read replicas: Route GET queries to replica (T1/T2)
- Query optimization: Explain analyze for all queries > 100ms

### DynamoDB (When Justified)
Only use DynamoDB when the access pattern is proven to be key-value:

**Single-Table Design:**
```
PK: {entity-type}#{entity-id}
SK: {relationship}#{related-id}
GSI1PK: {index-partition}
GSI1SK: {index-sort}
```

**Capacity:**
- T3: On-demand (pay per request)
- T2: On-demand (unless predictable, then provisioned with auto-scaling)
- T1: Provisioned with auto-scaling + reserved capacity

**DynamoDB Streams:**
- Enable for change data capture (CDC) when downstream consumers need events
- Stream to EventBridge via Lambda for domain event publishing

## Integration Tier

### Gravitee API Gateway
Gravitee is the MANDATORY external API gateway.

**Rate Limiting Policies:**
```
Standard Plan:
  rate_limit: 100 requests/minute
  quota: 10,000 requests/day
  burst: 20 concurrent requests

Premium Plan:
  rate_limit: 1,000 requests/minute
  quota: 100,000 requests/day
  burst: 100 concurrent requests

Internal Plan:
  rate_limit: 5,000 requests/minute
  quota: unlimited
  burst: 500 concurrent requests
```

**API Key Management:**
- Consumer onboarding via Gravitee developer portal
- API keys rotated every 90 days (automated reminder)
- Key per environment (dev, staging, prod)
- Usage analytics visible to consumer and provider

**Request/Response Transformation:**
- JSON ↔ XML transformation (for legacy SOAP consumers)
- Header injection (correlation ID, trace ID)
- Response filtering (remove internal fields from external responses)

### Async Communication

**EventBridge (Domain Events):**
```
Event bus: {app-name}-events
Source: {app-name}.{service-name}
Detail type: {Entity}.{Action} (e.g., Order.Created, User.Updated)
Schema: JSON Schema registered in EventBridge Schema Registry
```

**Event Envelope:**
```json
{
  "version": "1.0",
  "id": "event-uuid",
  "source": "app-name.service-name",
  "detail-type": "Order.Created",
  "time": "2026-01-15T10:30:00Z",
  "detail": {
    "order_id": "ord-123",
    "customer_id": "cust-456",
    "total_amount": 150.00,
    "correlation_id": "trace-789"
  }
}
```

**SQS Work Queues:**
```
Queue: {app-name}-{task-type}-queue
DLQ: {app-name}-{task-type}-dlq
Visibility timeout: 6x Lambda/consumer timeout
Message retention: 14 days
Encryption: SSE-KMS
Redrive policy: maxReceiveCount = 3
```

**SNS (Fan-Out Notifications):**
- Topic per event type for multi-subscriber scenarios
- SQS subscription for durable consumers
- Lambda subscription for real-time processors
- Filter policies to reduce noise per subscriber

## Health and Readiness

### Health Check Endpoints
```
GET /health  -> 200 {"status": "UP"}
  - Liveness check only (no dependency checks)
  - Used by ALB for routing decisions
  - Returns 200 even if downstream dependencies are degraded

GET /ready   -> 200 {"status": "READY", "checks": {...}}
  - Readiness check with dependency verification
  - Database: connection pool health
  - Cache: Redis PING
  - External services: last known status
  - Returns 503 if critical dependencies are down

GET /info    -> 200 {"version": "1.2.3", "commit": "abc123", "build_time": "..."}
  - Build metadata for debugging
  - No sensitive information
```

### Circuit Breaker Pattern
For outbound calls to external services:

**Python (tenacity):**
```python
from tenacity import retry, stop_after_attempt, wait_exponential, CircuitBreaker

circuit_breaker = CircuitBreaker(
    failure_threshold=5,
    recovery_timeout=30,
    expected_exception=ExternalServiceError
)

@retry(
    stop=stop_after_attempt(3),
    wait=wait_exponential(multiplier=1, min=1, max=10)
)
@circuit_breaker
def call_external_service(request):
    ...
```

**Java (Resilience4j):**
```java
CircuitBreakerConfig config = CircuitBreakerConfig.custom()
    .failureRateThreshold(50)
    .waitDurationInOpenState(Duration.ofSeconds(30))
    .slidingWindowSize(10)
    .build();
```

**Timeouts:**
- Internal service calls: 5s timeout
- External service calls: 10s timeout
- Database queries: 30s timeout (alert on > 5s)
- Background tasks: Match Step Functions task timeout

## Authentication and Authorization

### OKTA Integration
Same OKTA patterns as web-app archetype. API-specific:

**Client Credentials Flow (Service-to-Service):**
```
POST https://faa.okta.com/oauth2/{auth-server}/v1/token
Content-Type: application/x-www-form-urlencoded

grant_type=client_credentials
&client_id={service-client-id}
&client_secret={from-cyberark}
&scope=api.{app-name}.read api.{app-name}.write
```

**JWT Validation Middleware:**
```python
# FastAPI dependency
async def validate_jwt(authorization: str = Header(...)):
    token = authorization.replace("Bearer ", "")
    # Validate against OKTA JWKS endpoint
    # Check issuer, audience, expiration, scopes
    # Return decoded claims
```

**Scope-Based Authorization:**
```
Scopes:
  api.{app-name}.read      -> GET endpoints
  api.{app-name}.write     -> POST, PUT, PATCH, DELETE endpoints
  api.{app-name}.admin     -> Administrative endpoints
  api.{app-name}.{domain}  -> Domain-specific scope (e.g., api.flights.write)
```

## Observability

### Datadog APM for API Services
```
Service: {app-name}-api
Tracing: dd-trace-py (Python) or dd-java-agent (Java)
Custom spans: Database queries, external HTTP calls, business operations
Custom metrics:
  - api.request.count (by endpoint, method, status)
  - api.request.duration (P50, P95, P99 by endpoint)
  - api.error.count (by error type)
  - business.{entity}.created (domain metrics)
```

### API-Specific Monitoring
| Metric | Alarm Threshold | Severity |
|--------|----------------|----------|
| Request rate | > 150% of baseline for 5 min | P3 (informational) |
| Error rate (5xx) | > 1% for 2 min | P1 |
| Error rate (4xx) | > 20% for 5 min | P2 (possible attack) |
| Latency P99 | > 1s for 5 min | P2 |
| Latency P50 | > 200ms for 10 min | P3 |
| Gravitee rate limit hits | > 50/min | P3 (consumer needs upgrade) |
| Circuit breaker open | Any circuit open | P2 |
| DB connection pool exhaustion | > 80% for 5 min | P1 |

### Distributed Tracing
Every request gets a trace ID at the Gravitee layer:
```
X-Request-ID: {uuid} (set by Gravitee)
X-Correlation-ID: {uuid} (set by originating service)
```

Trace propagation through: Gravitee -> ALB -> Fargate -> Aurora/DynamoDB/EventBridge

All log entries include trace_id for end-to-end request tracing.

## Security

### Network
Same VPC design as web-app archetype. API-specific:
- Gravitee -> ALB: Allow Gravitee IP range only
- ALB -> Fargate: Security group restricted to ALB SG
- Fargate -> Aurora: Security group restricted to Fargate SG
- Fargate -> External: NAT Gateway for outbound HTTPS only

### Input Validation
```python
# Pydantic models for request validation (FastAPI)
class CreateOrderRequest(BaseModel):
    customer_id: str = Field(..., min_length=1, max_length=50, pattern=r'^[a-zA-Z0-9-]+$')
    items: list[OrderItem] = Field(..., min_length=1, max_length=100)
    total_amount: Decimal = Field(..., ge=0, le=1000000, decimal_places=2)
```

- Validate all inputs at the API layer (Pydantic or Jakarta Validation)
- Sanitize strings for SQL injection (use parameterized queries only)
- Validate content-type header
- Reject oversized payloads (max 10 MB default)
- Rate limit per consumer at Gravitee layer

### API Security Headers
```
Strict-Transport-Security: max-age=31536000; includeSubDomains
X-Content-Type-Options: nosniff
X-Frame-Options: DENY
Content-Security-Policy: default-src 'none'
Cache-Control: no-store (for authenticated responses)
```

## Tier-Specific Variations

### T1 (Mission Critical) Additions
- Multi-AZ with 3 task minimum
- mTLS for all inter-service communication
- DynamoDB global tables for cross-region
- Enhanced Datadog APM with custom business metrics
- Circuit breaker on all external dependencies
- Cost range: $1,500-4,000/month

### T2 (Important) Baseline
- Multi-AZ with 2 task minimum
- OAuth2 client credentials for inter-service
- Standard DynamoDB (single region)
- Standard Datadog APM
- Circuit breaker on critical external dependencies
- Cost range: $400-1,200/month

### T3 (Low Impact) Simplifications
- Single-AZ with 1 task minimum
- OAuth2 client credentials for inter-service
- DynamoDB on-demand (minimal)
- Basic monitoring
- Timeout-based resilience (no circuit breaker)
- Cost range: $150-400/month

## Cost Estimate Breakdown

### T3 (~$150-400/month)
| Service | Monthly Cost |
|---------|-------------|
| ECS Fargate (0.25 vCPU, 0.5 GB, 1 task) | $10-15 |
| Aurora Serverless v2 (0.5-4 ACU) | $50-150 |
| ALB | $25 |
| NAT Gateway | $35 |
| Datadog (1 host) | $25-50 |
| Other (ECR, KMS, CloudWatch) | $10-20 |
| **Total** | **$155-295** |

### T2 (~$400-1,200/month)
| Service | Monthly Cost |
|---------|-------------|
| ECS Fargate (0.5 vCPU, 1 GB, 2-6 tasks) | $30-100 |
| Aurora Serverless v2 (1-16 ACU, multi-AZ) | $150-500 |
| DynamoDB on-demand | $5-30 |
| ElastiCache Redis | $50-80 |
| ALB + NAT | $60-70 |
| Monitoring (Datadog + CloudWatch) | $75-150 |
| Other | $20-50 |
| **Total** | **$390-980** |

### T1 (~$1,500-4,000/month)
| Service | Monthly Cost |
|---------|-------------|
| ECS Fargate (1 vCPU, 2 GB, 3-12 tasks) | $100-400 |
| Aurora Serverless v2 (2-64 ACU, multi-AZ) | $500-1,500 |
| DynamoDB (provisioned + global tables) | $50-200 |
| ElastiCache Redis (clustered) | $200-400 |
| ALB + NAT (multi-AZ) | $70-140 |
| Monitoring (Datadog, enhanced) | $150-350 |
| Cross-region transfer | $30-100 |
| Other | $30-80 |
| **Total** | **$1,130-3,170** |
