---
name: aws-target-architecture
description: >
  Generate complete AWS target architecture blueprint per application archetype.
  Selects services from FAA-approved catalog, designs compute/data/integration/identity/observability
  tiers. Use during Architecture (Step 1). Triggers on target architecture, blueprint generation,
  cloud architecture, AWS design.
agent: opus
allowed-tools:
  - Read
  - Write
  - Grep
  - Bash
---

# AWS Target Architecture Blueprint Generator

## Purpose
Generate a complete, implementable target architecture blueprint that the Modernization
line can build against. This is the bridge between Rationalization ("what disposition")
and Modernization ("build it"). Every service selected, every pattern chosen, every
tier designed must be FAA-approved, GovCloud-compatible, and traceable to Discovery
findings.

The output blueprint is not advisory — it is the authoritative specification that
code generation, infrastructure provisioning, and deployment automation execute against.

## Inputs
- Application archetype from Discovery (web-app, batch-pipeline, api-service, event-driven, analytics, legacy-adapter)
- Risk tier (T1, T2, T3) from Rationalization
- Complexity assessment (simple, moderate, complex) from Discovery
- Disposition recommendation (refactor, rearchitect) from Rationalization
- Source technology stack from Discovery (language, framework, database, integrations)
- Dependency profile (upstream/downstream systems, shared databases)
- SWIM integration flag (does the app consume or publish NAS data?)
- External consumer flag (does the app serve external users via Login.gov?)
- RTO/RPO requirements from risk classification
- Business capability model from analyze-application Pass 2

## Outputs
- Architecture blueprint document (Markdown, using `assets/architecture-blueprint-template.md`)
- Cloud service selection matrix with FAA-approved justification
- Architecture Decision Records (ADRs) for every non-obvious choice
- C4 diagram descriptions (Context, Container, Component levels)
- Cost estimate (monthly, by tier)
- Terraform module inventory (what IaC modules are needed)
- EA compliance pre-check results (from `scripts/validate_service_selection.py`)

## Methodology

### Step 1: Detect Archetype and Load Reference
Read the application's archetype from the Discovery analysis output. Load the
corresponding reference architecture:

| Archetype | Reference File | Pattern |
|-----------|---------------|---------|
| web-app | `references/archetype-web-app.md` | SPA + API + Database |
| batch-pipeline | `references/archetype-batch-pipeline.md` | Step Functions + Lambda |
| api-service | `references/archetype-api-service.md` | Headless Microservice |
| event-driven | `references/archetype-event-driven.md` | EventBridge + Handlers |
| analytics | `references/archetype-analytics.md` | Data Lake + QuickSight |
| legacy-adapter | `references/archetype-legacy-adapter.md` | Facade/Strangler Fig |

If the application spans multiple archetypes (e.g., a web app with a batch pipeline),
use the primary archetype for the main blueprint and compose secondary archetypes
as sub-components.

### Step 2: Select AWS Services
For each tier, select services from the FAA-approved catalog only:
1. Read the FAA-approved services catalog maintained by the `ea-compliance` skill
2. Read `references/aws-govcloud-constraints.md` for GovCloud availability
3. Map each application need to an approved service
4. Document why each service was selected (not just what)

Never select a service not on the approved list. If the archetype reference
mentions a service, verify it against the approved list before including it.

### Steps 3-7: Design the Five Tiers
Design compute, data, integration, identity, and observability tiers — sizing
compute by tier, choosing Aurora PostgreSQL as the default relational store,
routing external APIs through Gravitee (mandatory), enforcing OKTA + CyberArk
for identity, and standardizing on Datadog + CloudWatch + X-Ray observability.

See `references/tier-design.md` for the compute/data/integration/identity/
observability service matrices, tier-sized sizing rules, mandatory services,
and tier-based alerting thresholds.

### Steps 8-9: ADRs and C4 Diagrams
For every non-obvious design choice, write an ADR that traces to a specific
Discovery finding. Produce C4 diagrams at Context, Container, and Component
levels using Mermaid.

See `references/adrs-and-diagrams.md` for ADR triggers, the Discovery
traceability format, and C4 level definitions. That file also contains the
source-to-target migration mapping and the archetype dispatch rules.

## Gotchas
- **Never use non-approved services**: Always check the EA approved list before
  including any AWS service. Common mistakes: AWS API Gateway (use Gravitee),
  Cognito (use OKTA), HashiCorp Vault (use CyberArk), Kafka (use EventBridge/SQS),
  MongoDB Atlas (use DynamoDB).
- **GovCloud has fewer services**: Not all commercial AWS services are available
  in GovCloud. Check `references/aws-govcloud-constraints.md` for every service
  in the blueprint. SageMaker, Bedrock, and some newer services may be limited.
- **Gravitee is mandatory**: All API exposure routes through Gravitee, not AWS
  API Gateway. This includes rate limiting, API key management, and developer
  portal functionality. Design Gravitee route configuration as part of the blueprint.
- **OKTA is mandatory**: All authentication flows use OKTA. For external users,
  Login.gov federates through OKTA. Never introduce Cognito or any alternative IdP.
- **CyberArk for PAM**: All privileged access (database credentials, service
  accounts, SSH keys) goes through CyberArk. Never use HashiCorp Vault or AWS
  Secrets Manager for privileged credentials.
- **Solace for SWIM**: If the application integrates with NAS data (SWIM feeds),
  Solace PubSub+ is mandatory. Do not attempt to replace Solace with EventBridge
  for SWIM-connected data flows.
- **Tier-appropriate design**: T3 applications should not have cross-region
  failover, multi-AZ read replicas, or complex service mesh patterns. T1
  applications must have all of these. Match the architecture to the risk tier.

## Quality Rules
- [ ] Every AWS service in the blueprint appears on the FAA EA approved services list
- [ ] Blueprint covers all 5 tiers: compute, data, integration, identity, observability
- [ ] Each ADR traces to a specific Discovery finding with `{artifact}:{section}:{finding-id}` format
- [ ] Cost estimate is included with monthly ranges by tier (T1/T2/T3)
- [ ] GovCloud availability is verified for every service (cross-reference `references/aws-govcloud-constraints.md`)
- [ ] OKTA is the sole IdP; CyberArk is the sole PAM; Gravitee is the sole API gateway
- [ ] SWIM-facing services use Solace PubSub+ (not EventBridge) for NAS data integration
- [ ] Architecture complexity matches risk tier (no over-engineering T3, no under-engineering T1)
- [ ] Terraform module inventory lists every infrastructure component needed for provisioning
- [ ] C4 diagrams exist at Context, Container, and Component levels
- [ ] `scripts/validate_service_selection.py` returns PASS with zero blocked services
- [ ] Blueprint uses the standard template from `assets/architecture-blueprint-template.md`

## Common Failure Modes
| Failure Mode | Symptom | Prevention |
|-------------|---------|------------|
| Unapproved service selected | Blueprint references AWS API Gateway, Cognito, Vault, Kafka, or MongoDB | Run `scripts/validate_service_selection.py` before finalizing; cross-ref approved list |
| Over-engineered T3 app | Simple internal tool gets multi-region, service mesh, CQRS | Check risk tier first; T3 = single-AZ, minimal scaling, simplified VPC |
| Under-engineered T1 app | Safety-critical system has single-AZ, no failover, no enhanced monitoring | Check risk tier first; T1 = multi-AZ, cross-region replica, 99.99% SLO |
| Missing SWIM integration | App consumes NAS data but blueprint uses EventBridge instead of Solace | Check `has_swim_integration` flag; if true, Solace PubSub+ is mandatory |
| Generic cloud patterns | Blueprint uses standard AWS well-architected but ignores FAA-specific requirements | Start from archetype reference files, not generic AWS documentation |
| No ADR traceability | Architecture decisions say "best practice" instead of citing Discovery findings | Every ADR must include `Traces To:` field with specific artifact reference |
| Missing cost estimate | Blueprint has no cost projection; budget review fails | Include monthly cost ranges from archetype reference; adjust for tier and complexity |
| Ignoring source tech | Blueprint targets Spring Boot for a ColdFusion app without justifying the language change | Check Tech-Stack Dispatch table; document migration rationale in ADR |

## Reference Files
- `references/archetype-web-app.md` — SPA + API reference architecture
- `references/archetype-batch-pipeline.md` — Step Functions + Lambda reference architecture
- `references/archetype-api-service.md` — Headless microservice reference architecture
- `references/archetype-event-driven.md` — Event-driven service reference architecture
- `references/archetype-analytics.md` — Reporting/analytics platform reference architecture
- `references/archetype-legacy-adapter.md` — Facade/adapter pattern reference architecture
- `references/aws-govcloud-constraints.md` — GovCloud service availability matrix
- `references/tier-design.md` — Compute/data/integration/identity/observability tier design
- `references/adrs-and-diagrams.md` — ADR triggers, C4 levels, source-target migration, archetype dispatch
- FAA-approved service catalog — maintained under the `ea-compliance` skill

## Output Templates
- `assets/architecture-blueprint-template.md` — Full blueprint document template
- `assets/adr-template.md` — Architecture Decision Record template

## Validation Scripts
- `scripts/validate_service_selection.py` — Check blueprint against approved service list

## Phase 3 — ATLAS ChBA

> **Trace:** Closes P3-R07 (partial), P3-R09, P3-R66 (partial), P3-R81. Source: `docs/phase3/phase2-commitments.md` §B.2 (11 target services), §B.3 (technology choices), §C.1 Wave 0; gap matrix EDIT-3 (B7b in build plan). Pairs with `cross-cutting/skills/aws-deployment-topology` (Phase 3 EDIT).

### Phase 3 framing

- **Target architecture** = AWS GovCloud (us-gov-west-1) on the FAA Tyrion / Horizon FedRAMP-inheritance landing zone — per P2 §B.3, §C.1 Wave 0.
- **Phase 3 prototype** = local docker-compose + AWS CDK v2 (TypeScript) stubs that synth-green for the GovCloud target. The Tyrion landing zone is unavailable in the 12-day window (DEV-11); Booz Allen-managed sandbox AWS or local-only is the actual prototype host.
- **Authoritative reference architecture:** `docs/phase3/local-first-architecture.md` (locked 2026-05-16). Stack pick = React + USWDS + Vite (frontend), Node 20 + Express + TypeScript (API), Postgres 15 / Aurora Serverless v2 (data), Postgres LISTEN/NOTIFY / EventBridge (events), Keycloak / Cognito (auth), MinIO / S3 (storage), `.env.local` / Secrets Manager (secrets), OTEL/Loki/Grafana / CloudWatch+X-Ray (observability), docker-compose / AWS CDK (IaC).
- **BASE-C is NOT a Phase 2 commitment.** Do not introduce BASE-C as the default deployment substrate for new blueprints. If a downstream team chooses to use BASE-C as a build accelerator, document it as DEV-1 in the 10-page narrative.
- **Bedrock is NOT a Phase 2 commitment.** P2 SF3 §3.3 says "no AI/ML feature is in-scope." Where Phase 3 uses LLM assistance for *building* the prototype, that is documented as DEV-6 — it is not a runtime feature.

### Phase 3 PPC blueprint variant — "Private Pilot Certification Prototype"

Add a new archetype variant `phase3-ppc-prototype` that names the Phase-3-in-scope target services per P2 §A.1 A1 ("PPC scope = IACRA + RMS + MSS + DMS"; Aircraft Registration out-of-scope). The build-demo plan (`docs/phase3/build-demo-skills-plan.md` §1.2) commits to a specific implementation depth per service:

| # | Service | Phase 3 disposition | AWS production-target service mapping | Phase 3 prototype container |
|---|---|---|---|---|
| **S1** | Unified Pilot Identity | IMPLEMENT | Cognito (or Login.gov in production); OKTA + Login.gov federation planned — Phase 3 prototype: **Keycloak** | `keycloak` |
| **S2** | Guided Intake | IMPLEMENT | Lambda + API Gateway; Aurora PostgreSQL Serverless v2 | `s2-intake` (Node 20 + Express + TypeScript) |
| **S3** | Notification & Status | IMPLEMENT THIN | Lambda + API Gateway + SES (email) + EventBridge | `s3-notify` (Node 20 + Express + TypeScript) + Postgres LISTEN/NOTIFY |
| **S4** | Conversational AI Layer | STUB | Lambda + API Gateway (Bedrock not used) — stub returns canned responses | `s4-conversation` (Node 20 + Express + TypeScript stub) |
| **S5** | Shared Case Workspace | IMPLEMENT | Lambda + API Gateway + Aurora PostgreSQL; Postgres LISTEN/NOTIFY (Step Functions deferred to Phase 4) | `s5-case` (Node 20 + Express + TypeScript) |
| **S6** | Medical Readiness & Case (PHI) | IMPLEMENT THIN | Lambda + API Gateway + Aurora PostgreSQL (PHI-isolated schema, separate KMS key) + S3 (encrypted) | `s6-medical` (Node 20 + Express + TypeScript; pgcrypto column-level encryption) |
| **S7** | Designee & ODA | IMPLEMENT THIN | Lambda + API Gateway + Aurora PostgreSQL + OPA layer for CLOA-as-policy | `s7-designee` (Node 20 + Express + TypeScript + `opa` sidecar) |
| **S8** | Registry Canonical API | IMPLEMENT | Lambda + API Gateway + Aurora PostgreSQL; EventBridge for `airman.changed` | `s8-registry` (Node 20 + Express + TypeScript) + Postgres LISTEN/NOTIFY |
| **S9** | Digital Credential | IMPLEMENT | Lambda + API Gateway + AWS Private CA + ACM + RFC 3161 TSA (production); local OpenSSL CA + freetsa.org (Phase 3) | `s9-credential` (Node 20 + Express + TypeScript + OpenSSL signer) |
| **S10** | Compliance | STUB | Lambda + API Gateway + Aurora PostgreSQL | `s10-compliance` (Node 20 + Express + TypeScript stub) |
| **S11** | Reporting & Analytics Data Plane | IMPLEMENT THIN | Lambda + Grafana on Aurora replica + S3 audit log archive | `s11-reporting` (Grafana on Postgres) |

**Cross-cutting infra (production target):** API Gateway (edge), Lambda (compute, Express via `@vendia/serverless-express`), Aurora PostgreSQL Serverless v2 (data), S3 (documents), KMS (keys), Secrets Manager (creds), CloudWatch + X-Ray (observability), IAM (identity bindings).

**Cross-cutting infra (Phase 3 prototype):** Traefik (edge), Docker (compute), Postgres 15 (data), MinIO (documents), `.env.local` (creds), OpenSSL files mounted as Docker secrets (KMS substitute), Loki + Prometheus + Grafana (observability).

> **Adapter discipline:** Per `docs/phase3/local-first-architecture.md` §3, files under `apps/api/src/handlers/`, `apps/api/src/domain/`, and `apps/web/src/` never import from `@aws-sdk/*`. AWS only enters through `apps/api/src/adapters/`. The `cross-cutting/skills/local-cloud-adapter-scaffolder` skill produces and enforces that layer.

### IaC artifact emission (alongside the architecture blueprint)

The blueprint MUST be paired with concrete IaC outputs (not just diagrams):

1. `infra/cdk/` — full AWS CDK v2 (TypeScript) stack set for the GovCloud target (handed off to `cross-cutting/skills/aws-deployment-topology`). **Use CDK, not Terraform** per `local-first-architecture.md` §2.
2. `infra/helm/atlas-phase3/` — Helm chart equivalent (Phase 4 EKS path, not the default).
3. `infra/docker-compose.yml` (Phase 3 live target).
4. `infra/diagrams/` — C4 diagrams keyed to the 11 services and the prototype topology.

Spec ↔ code closure: the blueprint's "compute / data / integration / identity / observability" tier sections MUST resolve to the same stack/construct set the CDK emits. The new `--check-spec-code-loop` mode verifies that every service named in the blueprint has a corresponding construct in the CDK app (e.g., a Lambda function defined in `infra/cdk/lib/api-stack.ts`).

### Phase 3 deviation register (for the 10-page narrative)

The blueprint emits a `## Phase 3 Implementation Deviations` section that the new `cross-cutting/skills/phase-commitment-traceback` skill ingests. Pre-populate with DEV-1, DEV-2, DEV-11, DEV-13, DEV-19 from `docs/phase3/skills-gap-matrix.md` §5.

### Phase 3 acceptance signals

- [ ] Blueprint variant `phase3-ppc-prototype` enumerates S1..S11 with implementation depth + AWS production mapping + Phase 3 container.
- [ ] BASE-C and Bedrock are absent from the blueprint's default service selection.
- [ ] Tyrion landing zone is named as the Phase 4 production target (not the Phase 3 host).
- [ ] IaC outputs (AWS CDK + Helm + docker-compose) are produced and pass spec-code-loop check.
- [ ] Phase 3 deviations section is present and ingested by `phase-commitment-traceback`.

## Handoff Summary
When this skill completes, verify:
1. Blueprint document exists and uses the standard template
2. All services pass `scripts/validate_service_selection.py` (zero BLOCK findings)
3. ADRs exist for every non-obvious decision with Discovery traceability
4. Cost estimate is present with tier-appropriate ranges
5. C4 diagrams exist at Context, Container, and Component levels
6. **Phase 3:** PPC variant lists S1..S11 with prod mapping + prototype container; deviations section emitted
Then proceed to: `ea-compliance` for formal EA alignment verification, then
`blueprint-assembler` (P4.2) for module-level design, and gate `G-02` for
architecture review
