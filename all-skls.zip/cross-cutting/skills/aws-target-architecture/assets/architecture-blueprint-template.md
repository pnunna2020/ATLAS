# Architecture Blueprint: {{APP_NAME}}

## Document Control
| Field | Value |
|-------|-------|
| Application | {{APP_NAME}} |
| Archetype | {{ARCHETYPE}} |
| Risk Tier | {{RISK_TIER}} |
| Disposition | {{DISPOSITION}} |
| Source Technology | {{SOURCE_TECH}} |
| Target Technology | {{TARGET_TECH}} |
| Pipeline Phase | Architecture (Step 1) |
| Date | {{DATE}} |
| Author | {{AGENT_NAME}} |
| Version | 1.0 |

---

## 1. Executive Summary

### 1.1 Application Overview
{{Brief description of the application, its purpose, and its role in the FAA ecosystem.}}

### 1.2 Architecture Pattern
{{Selected architecture pattern (e.g., SPA + API, Serverless Batch, Event-Driven) and
the primary reason for selection. Reference the archetype reference file used.}}

### 1.3 Key Decisions
{{Bulleted list of the 3-5 most significant architecture decisions. Each decision
references an ADR in Section 12.}}

### 1.4 Cost Summary
| Tier | Monthly Estimate | Annual Estimate |
|------|-----------------|----------------|
| {{RISK_TIER}} | ${{MONTHLY_LOW}} - ${{MONTHLY_HIGH}} | ${{ANNUAL_LOW}} - ${{ANNUAL_HIGH}} |

---

## 2. Cloud Service Selection Matrix

| Tier | Service | Justification | GovCloud Verified | FAA Approved |
|------|---------|---------------|-------------------|--------------|
| Compute | {{SERVICE}} | {{WHY}} | Yes/No | Yes |
| Data | {{SERVICE}} | {{WHY}} | Yes/No | Yes |
| Integration | {{SERVICE}} | {{WHY}} | Yes/No | Yes |
| Identity | {{SERVICE}} | {{WHY}} | Yes/No | Yes |
| Observability | {{SERVICE}} | {{WHY}} | Yes/No | Yes |
| Networking | {{SERVICE}} | {{WHY}} | Yes/No | Yes |
| CI/CD | {{SERVICE}} | {{WHY}} | Yes/No | Yes |

**Service Validation:** `scripts/validate_service_selection.py` result: {{PASS/FAIL}}

---

## 3. Compute Tier

### 3.1 Service Selection
{{Selected compute service (Lambda, Fargate, EC2) and justification.}}

### 3.2 Configuration
{{Detailed configuration: CPU, memory, scaling, health checks, deployment strategy.}}

### 3.3 Container/Function Design
{{Container image or Lambda function specification. Runtime, base image, layers.}}

### 3.4 Auto-Scaling
{{Scaling policies, thresholds, cooldowns, scheduled scaling.}}

### 3.5 Deployment Strategy
{{Blue/green, canary, rolling. Traffic shifting percentages and rollback triggers.}}

---

## 4. Data Tier

### 4.1 Primary Database
{{Database selection, configuration, sizing, multi-AZ, backup strategy.}}

### 4.2 Data Migration Path
{{Source database to target database migration strategy. Tools: DMS, SCT, custom ETL.}}

### 4.3 Connection Management
{{Connection pooling, proxy, timeout configuration.}}

### 4.4 Backup and Recovery
| Parameter | Value |
|-----------|-------|
| RTO | {{RTO}} |
| RPO | {{RPO}} |
| Backup frequency | {{FREQUENCY}} |
| Retention | {{RETENTION}} |
| Cross-region backup | {{YES_NO}} |

### 4.5 Caching (If Applicable)
{{Cache service, configuration, TTL strategy, invalidation approach.}}

### 4.6 Object Storage (If Applicable)
{{S3 configuration, lifecycle policies, encryption.}}

---

## 5. Integration Tier

### 5.1 API Gateway (Gravitee)
{{Gravitee route configuration, rate limiting, plans, CORS.}}

### 5.2 Internal Communication
{{Service-to-service patterns: Cloud Map, ALB, direct invocation.}}

### 5.3 Async Communication
{{EventBridge events, SQS queues, SNS topics. Event schemas.}}

### 5.4 External Integrations
| System | Protocol | Direction | Auth Method | SLA |
|--------|----------|-----------|-------------|-----|
| {{SYSTEM}} | {{PROTOCOL}} | {{IN/OUT/BOTH}} | {{AUTH}} | {{SLA}} |

### 5.5 SWIM Integration (If Applicable)
{{Solace PubSub+ configuration for NAS data integration.
Remove this section if has_swim_integration is false.}}

---

## 6. Identity and Auth Tier

### 6.1 Authentication Flow
{{OKTA flow: Authorization Code + PKCE (SPA), Client Credentials (API), etc.}}

### 6.2 Authorization Model
{{RBAC roles, permission model, enforcement point.}}

### 6.3 External Users (If Applicable)
{{Login.gov federation through OKTA. IAL/AAL levels.
Remove this section if has_external_consumers is false.}}

### 6.4 Service-to-Service Auth
{{mTLS or OAuth2 client credentials for inter-service calls.}}

### 6.5 Secrets Management
{{CyberArk for privileged credentials. SSM Parameter Store for non-sensitive config.}}

---

## 7. Observability Tier

### 7.1 APM and Tracing
{{Datadog APM configuration, service name, custom metrics.}}

### 7.2 Logging
{{Structured logging format (JSON), log shipping to Datadog, retention.}}

### 7.3 Alerting
| Alarm | Threshold | Severity | Action |
|-------|-----------|----------|--------|
| {{ALARM}} | {{THRESHOLD}} | {{P1/P2/P3}} | {{ACTION}} |

### 7.4 Health Check Endpoints
| Endpoint | Purpose | Checks |
|----------|---------|--------|
| `/health` | Liveness | App is running |
| `/ready` | Readiness | Dependencies are available |
| `/info` | Metadata | Version, commit, build time |

### 7.5 SLO and SLA
| Metric | Target |
|--------|--------|
| Availability | {{AVAILABILITY_SLO}} |
| Latency P99 | {{LATENCY_TARGET}} |
| Error rate | {{ERROR_RATE_TARGET}} |

---

## 8. Resilience Design

### 8.1 High Availability
{{Multi-AZ strategy, failover approach, redundancy design.}}

### 8.2 Disaster Recovery
{{Cross-region strategy (if T1), backup/restore approach, DR testing cadence.}}

### 8.3 Circuit Breakers
{{External dependency resilience patterns.}}

### 8.4 Graceful Degradation
{{What happens when a dependency is unavailable. Fallback behavior.}}

---

## 9. Deployment Topology

### 9.1 Network Architecture
```
{{Text-based network diagram: VPC, subnets, security groups, NAT, VPN.}}
```

### 9.2 Security Groups
| Security Group | Inbound | Outbound | Attached To |
|----------------|---------|----------|-------------|
| {{SG_NAME}} | {{RULES}} | {{RULES}} | {{RESOURCE}} |

### 9.3 Encryption
| Layer | Method | Key Management |
|-------|--------|---------------|
| At rest | SSE-KMS | Customer-managed CMK |
| In transit | TLS 1.3 | ACM certificates |

---

## 10. Security Architecture

### 10.1 Network Security
{{WAF, security groups, VPC configuration, egress restrictions.}}

### 10.2 Data Protection
{{Encryption at rest and in transit, key rotation, data classification.}}

### 10.3 Access Control
{{IAM roles, least privilege, service roles.}}

### 10.4 Compliance
{{NIST 800-53 Rev 5 control mapping, FedRAMP High, Section 508.}}

---

## 11. Cost Estimate

### 11.1 Monthly Breakdown
| Service | Configuration | Monthly Cost |
|---------|--------------|-------------|
| {{SERVICE}} | {{CONFIG}} | ${{COST}} |
| **Total** | | **${{TOTAL}}** |

### 11.2 Cost Optimization Opportunities
{{Reserved instances, savings plans, right-sizing, scheduled scaling.}}

### 11.3 Cost Comparison with Current State
| Category | Current Monthly | Target Monthly | Savings |
|----------|----------------|---------------|---------|
| Infrastructure | ${{CURRENT}} | ${{TARGET}} | ${{SAVINGS}} |
| Licensing | ${{CURRENT}} | ${{TARGET}} | ${{SAVINGS}} |
| O&M Labor | ${{CURRENT}} | ${{TARGET}} | ${{SAVINGS}} |

---

## 12. Architecture Decision Records

{{Include all ADRs produced during blueprint generation. Each ADR follows
the template in assets/adr-template.md.}}

### ADR-001: {{TITLE}}
{{ADR content...}}

### ADR-002: {{TITLE}}
{{ADR content...}}

---

## 13. C4 Diagrams

### 13.1 Context Diagram (Level 1)
```mermaid
{{Mermaid C4 context diagram}}
```

### 13.2 Container Diagram (Level 2)
```mermaid
{{Mermaid C4 container diagram}}
```

### 13.3 Component Diagram (Level 3)
```mermaid
{{Mermaid C4 component diagram for the primary container}}
```

---

## 14. Terraform Module Inventory

| Module | Purpose | Source | Variables |
|--------|---------|--------|-----------|
| {{MODULE}} | {{PURPOSE}} | {{SOURCE}} | {{KEY_VARS}} |

---

## 15. Traceability Matrix

| Architecture Decision | Discovery Finding | Rationalization Input |
|----------------------|-------------------|----------------------|
| {{DECISION}} | {{FINDING_REF}} | {{RATIONALE_REF}} |

---

## 16. Validation Checklist

### Service Selection
- [ ] All services are FAA EA approved (`scripts/validate_service_selection.py` returns PASS)
- [ ] All services verified available in GovCloud (`references/aws-govcloud-constraints.md`)
- [ ] No blocked services referenced (API Gateway, Cognito, Vault, Kafka, MongoDB)

### Architecture Completeness
- [ ] Compute tier designed and sized
- [ ] Data tier designed with migration path
- [ ] Integration tier designed with all endpoints mapped
- [ ] Identity tier designed with OKTA flows
- [ ] Observability tier designed with alerts and SLOs

### Quality
- [ ] Every ADR traces to a Discovery finding
- [ ] Cost estimate is included with monthly breakdown
- [ ] C4 diagrams exist at Context, Container, and Component levels
- [ ] Tier-appropriate design (no over/under-engineering)
- [ ] SWIM integration addressed (if applicable)
- [ ] External consumer auth addressed (if applicable)

### Handoff
- [ ] Blueprint ready for `ea-compliance` skill verification
- [ ] Blueprint ready for gate `G-02` architecture review
- [ ] Terraform module inventory ready for infrastructure provisioning
