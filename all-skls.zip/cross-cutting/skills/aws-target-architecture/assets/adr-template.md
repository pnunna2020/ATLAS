# ADR-{{NUMBER}}: {{TITLE}}

## Status
{{Proposed | Accepted | Deprecated | Superseded by ADR-XXX}}

## Context
{{Describe the technical or business situation that requires a decision.
Include relevant constraints, requirements, and the forces at play.
Reference specific Discovery findings that motivate this decision.}}

## Decision
{{Clearly state the decision that was made. Be specific about what was
chosen and, equally important, what alternatives were considered and
rejected.}}

### Alternatives Considered
| Alternative | Pros | Cons | Reason Rejected |
|------------|------|------|-----------------|
| {{ALT_1}} | {{PROS}} | {{CONS}} | {{REASON}} |
| {{ALT_2}} | {{PROS}} | {{CONS}} | {{REASON}} |

## Consequences

### Positive
- {{Benefit 1}}
- {{Benefit 2}}

### Negative
- {{Trade-off 1}}
- {{Trade-off 2}}

### Risks
- {{Risk and mitigation strategy}}

## Traces To
- **Discovery Finding:** `{{discovery-report}}:{{section}}:{{finding-id}}`
- **Rationalization Input:** `{{rationalization-report}}:{{section}}:{{finding-id}}`
- **EA Standard:** `{{standard-name}}:{{control-id}}` (if applicable)
- **Requirement:** `{{requirement-id}}` (if applicable)

## Cost Impact
{{Estimated monthly cost impact of this decision, or "Negligible" if minimal.}}
