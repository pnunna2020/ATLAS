#!/usr/bin/env python3
"""
Service Selection Validator for AWS Target Architecture Blueprints.

Reads an architecture blueprint document and validates that all referenced
AWS services are on the FAA-approved list. Reports blocked services,
warnings, and approval status.

Usage: python validate_service_selection.py <blueprint_path>

Output: JSON report with status, approved services, blocked services, and warnings.
"""
import sys
import json
import re
from pathlib import Path

# FAA-approved services (canonical list from ea-compliance/references/faa-ea-approved-services.md)
APPROVED_SERVICES = {
    # Compute
    "lambda": "AWS Lambda",
    "fargate": "AWS Fargate (ECS)",
    "ecs": "Amazon ECS",
    "ec2": "Amazon EC2 (discouraged for new workloads)",
    # Data
    "aurora": "Amazon Aurora PostgreSQL",
    "aurora serverless": "Amazon Aurora Serverless v2",
    "aurora postgresql": "Amazon Aurora PostgreSQL",
    "dynamodb": "Amazon DynamoDB",
    "redshift": "Amazon Redshift",
    "redshift serverless": "Amazon Redshift Serverless",
    "s3": "Amazon S3",
    "elasticache": "Amazon ElastiCache Redis",
    "elasticache redis": "Amazon ElastiCache Redis",
    # Integration
    "gravitee": "Gravitee API Gateway (MANDATORY)",
    "eventbridge": "Amazon EventBridge",
    "sns": "Amazon SNS",
    "sqs": "Amazon SQS",
    "step functions": "AWS Step Functions",
    "solace": "Solace PubSub+ (MANDATORY for SWIM)",
    # Identity & Security
    "okta": "OKTA (MANDATORY IdP)",
    "cyberark": "CyberArk (MANDATORY PAM)",
    "kms": "AWS KMS (MANDATORY encryption)",
    "waf": "AWS WAF v2",
    "acm": "AWS Certificate Manager",
    "iam": "AWS IAM",
    # Monitoring
    "datadog": "Datadog (primary observability)",
    "cloudwatch": "Amazon CloudWatch (supplemental)",
    "x-ray": "AWS X-Ray",
    # Networking
    "vpc": "Amazon VPC",
    "alb": "Application Load Balancer",
    "nlb": "Network Load Balancer",
    "cloudfront": "Amazon CloudFront",
    "route 53": "Amazon Route 53",
    "direct connect": "AWS Direct Connect",
    "cloud map": "AWS Cloud Map",
    "nat gateway": "NAT Gateway",
    # CI/CD
    "github actions": "GitHub Actions (primary CI/CD)",
    "artifactory": "JFrog Artifactory",
    "sonarqube": "SonarQube",
    "terraform": "HashiCorp Terraform",
    "ecr": "Amazon ECR",
    "codedeploy": "AWS CodeDeploy",
    # Analytics
    "quicksight": "Amazon QuickSight",
    "athena": "Amazon Athena",
    "glue": "AWS Glue",
    "dms": "AWS Database Migration Service",
    # Auth (external)
    "login.gov": "Login.gov (external user federation)",
    # Other approved
    "rds proxy": "Amazon RDS Proxy",
    "ssm parameter store": "AWS SSM Parameter Store (non-sensitive config)",
    "secrets manager": "AWS Secrets Manager (non-privileged only)",
}

# Services that are explicitly NOT approved
BLOCKED_SERVICES = {
    "api gateway": {
        "reason": "Use Gravitee instead of AWS API Gateway",
        "approved_alternative": "Gravitee",
    },
    "aws api gateway": {
        "reason": "Use Gravitee instead of AWS API Gateway",
        "approved_alternative": "Gravitee",
    },
    "cognito": {
        "reason": "Use OKTA instead of AWS Cognito",
        "approved_alternative": "OKTA",
    },
    "hashicorp vault": {
        "reason": "Use CyberArk instead of HashiCorp Vault",
        "approved_alternative": "CyberArk",
    },
    "vault": {
        "reason": "Use CyberArk instead of HashiCorp Vault (if referring to secrets management)",
        "approved_alternative": "CyberArk",
    },
    "kafka": {
        "reason": "Use EventBridge + SNS/SQS instead (Solace only for SWIM)",
        "approved_alternative": "EventBridge + SNS/SQS",
    },
    "msk": {
        "reason": "Amazon MSK (Kafka) is not approved; use EventBridge + SNS/SQS",
        "approved_alternative": "EventBridge + SNS/SQS",
    },
    "mongodb": {
        "reason": "Use DynamoDB for document workloads",
        "approved_alternative": "DynamoDB",
    },
    "mongodb atlas": {
        "reason": "Use DynamoDB for document workloads",
        "approved_alternative": "DynamoDB",
    },
    "grafana": {
        "reason": "Use Datadog instead of Grafana/Managed Grafana",
        "approved_alternative": "Datadog",
    },
    "prometheus": {
        "reason": "Use Datadog instead of Prometheus/Managed Prometheus",
        "approved_alternative": "Datadog",
    },
    "jenkins": {
        "reason": "Migrating to GitHub Actions; do not introduce new Jenkins pipelines",
        "approved_alternative": "GitHub Actions",
    },
}

# Mandatory services that should be present in every architecture
MANDATORY_SERVICES = {
    "okta": "All architectures must use OKTA for identity",
    "gravitee": "All API-exposing architectures must use Gravitee",
    "kms": "All architectures must use KMS for encryption",
    "datadog": "All architectures must use Datadog for observability",
}

# Services that require SWIM integration context
SWIM_CONDITIONAL = {
    "solace": "Required if application has SWIM/NAS integration",
}


def extract_services(content: str) -> set:
    """Extract all service references from the blueprint document."""
    content_lower = content.lower()
    found_services = set()

    for service_key in APPROVED_SERVICES:
        if service_key in content_lower:
            found_services.add(service_key)

    return found_services


def check_blocked_services(content: str) -> list:
    """Check for references to blocked/unapproved services."""
    content_lower = content.lower()
    findings = []

    for service_key, details in BLOCKED_SERVICES.items():
        if service_key in content_lower:
            # Context-sensitive check: skip if the reference is in a "NOT approved" section,
            # preceded by "instead of" / "do not use", or the approved alternative is
            # mentioned on the same line (e.g., "Gravitee API Gateway" is not a violation)
            lines = content_lower.split("\n")
            approved_alt_lower = details["approved_alternative"].lower()
            for line_num, line in enumerate(lines, 1):
                if service_key in line:
                    is_negative_context = any(
                        neg in line
                        for neg in [
                            "not approved",
                            "do not use",
                            "instead of",
                            "don't use",
                            "never use",
                            "blocked",
                            "not use",
                            "replaced by",
                            "migrate from",
                            "migrating from",
                        ]
                    )
                    # Skip if the approved alternative appears on the same line
                    # (e.g., "Gravitee API Gateway" is Gravitee, not AWS API Gateway)
                    is_alternative_context = approved_alt_lower in line
                    if not is_negative_context and not is_alternative_context:
                        findings.append(
                            {
                                "severity": "BLOCK",
                                "service": service_key,
                                "line": line_num,
                                "reason": details["reason"],
                                "alternative": details["approved_alternative"],
                            }
                        )

    return findings


def check_mandatory_services(content: str) -> list:
    """Check that mandatory services are referenced in the blueprint."""
    content_lower = content.lower()
    findings = []

    for service_key, requirement in MANDATORY_SERVICES.items():
        if service_key not in content_lower:
            findings.append(
                {
                    "severity": "WARNING",
                    "service": service_key,
                    "reason": f"Mandatory service not found in blueprint: {requirement}",
                }
            )

    return findings


def check_tier_appropriateness(content: str) -> list:
    """Check for tier-inappropriate patterns."""
    content_lower = content.lower()
    findings = []

    # Detect tier from document
    tier = None
    if "risk_tier: t1" in content_lower or "tier 1" in content_lower or "tier: t1" in content_lower:
        tier = "T1"
    elif "risk_tier: t3" in content_lower or "tier 3" in content_lower or "tier: t3" in content_lower:
        tier = "T3"

    if tier == "T3":
        over_engineering_patterns = [
            ("cross-region", "Cross-region replication is unnecessary for T3 applications"),
            ("multi-region", "Multi-region deployment is unnecessary for T3 applications"),
            ("global tables", "DynamoDB global tables are unnecessary for T3 applications"),
            ("service mesh", "Service mesh is unnecessary for T3 applications"),
        ]
        for pattern, warning in over_engineering_patterns:
            if pattern in content_lower:
                findings.append(
                    {
                        "severity": "WARNING",
                        "pattern": pattern,
                        "reason": warning,
                    }
                )

    if tier == "T1":
        under_engineering_patterns = [
            ("single-az", "T1 applications must be multi-AZ"),
            ("single az", "T1 applications must be multi-AZ"),
        ]
        for pattern, warning in under_engineering_patterns:
            # Check if single-AZ is recommended (not just mentioned)
            lines = content_lower.split("\n")
            for line in lines:
                if pattern in line and "not" not in line and "avoid" not in line:
                    findings.append(
                        {
                            "severity": "WARNING",
                            "pattern": pattern,
                            "reason": warning,
                        }
                    )
                    break

    return findings


def validate_blueprint(path: str) -> dict:
    """Main validation function. Returns JSON-serializable report."""
    with open(path, "r", encoding="utf-8") as f:
        content = f.read()

    approved = list(extract_services(content))
    blocked = check_blocked_services(content)
    mandatory_warnings = check_mandatory_services(content)
    tier_warnings = check_tier_appropriateness(content)

    all_warnings = mandatory_warnings + tier_warnings
    has_blocks = len(blocked) > 0

    return {
        "status": "FAIL" if has_blocks else "PASS",
        "blueprint_path": path,
        "summary": {
            "approved_services_found": len(approved),
            "blocked_services_found": len(blocked),
            "warnings": len(all_warnings),
        },
        "approved": sorted(approved),
        "blocked": blocked,
        "warnings": all_warnings,
    }


def main():
    if len(sys.argv) < 2:
        print("Usage: python validate_service_selection.py <blueprint_path>")
        print()
        print("Validates an architecture blueprint against FAA-approved AWS services.")
        print("Returns JSON report with PASS/FAIL status.")
        sys.exit(1)

    blueprint_path = sys.argv[1]

    if not Path(blueprint_path).exists():
        print(json.dumps({"status": "ERROR", "message": f"File not found: {blueprint_path}"}, indent=2))
        sys.exit(1)

    result = validate_blueprint(blueprint_path)
    print(json.dumps(result, indent=2))

    sys.exit(0 if result["status"] == "PASS" else 1)


if __name__ == "__main__":
    main()
