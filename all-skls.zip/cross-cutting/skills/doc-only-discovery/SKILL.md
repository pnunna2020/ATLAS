---
name: doc-only-discovery
description: >
  Discovery variant for when source code is unavailable. Ingests PIAs, user guides, architecture decks, regulations, research packs. Produces provisional application catalog entry with confidence=doc-inferred plus a risk register of gaps. Triggers when has_source_available is false, or on @doc-only-discovery, doc-based discovery, documentation-only analysis.
agent: opus
allowed-tools:
  - Read
  - Write
  - Grep
---

# doc-only-discovery

## Purpose
Run Discovery in degraded mode when the target application has no accessible source tree — only prose artifacts (Privacy Impact Assessments, user guides, architecture decks, regulations, research packs, Q&A transcripts). Produce a provisional `application-catalog-entry.json` whose every unverified field carries `confidence='doc-inferred'`, plus a `risk-register.json` enumerating the evidence gaps that must be closed when source lands. This skill never replaces `analyze-application`; it stands in for `catalog-application` only when `has_source_available == false`, and every field it emits is a hypothesis to be re-verified, not a finding.

## Inputs
- Documentation corpus directory (PDFs, markdown, pptx-exported markdown, HTML, Word docs) — path provided by Discovery orchestrator
- Pre-computed document index (JSON: `{path, type, title, authoritative_tier}`) if the corpus has been triaged; otherwise triage in Methodology Step 1
- Client profile (`profiles/<client>/profile.yaml`) for domain vocabulary, risk tiers, and mandated compliance controls
- Regulatory reference set (14 CFR parts, DOT orders, Privacy Act SORNs, FISMA baselines) cited in the corpus
- Prior Discovery artifacts from sibling applications in the same portfolio, if any (for cross-reference of shared integrations and personas)
- Orchestration flag `has_source_available` (boolean) — this skill must refuse to run when `true`

## Outputs
- Provisional application catalog entry (JSON) validating against `schemas/discovery/application-catalog-entry.schema.json` with every non-schema field carrying `confidence` in `{doc-inferred-low, doc-inferred-medium, doc-inferred-medium-high}` per `references/degraded-mode-confidence.md`
- Risk register (YAML) per `assets/risk-register-template.yaml` — one entry per evidence gap, naming the blocked downstream decision
- Provisional catalog notes (markdown) per `assets/provisional-catalog-notes.md` — per-field annotation recording source doc, page/section, quoted evidence, and assigned confidence tier
- Contradictions log embedded in the catalog entry's `open_questions[]` — each contradiction pins the two conflicting doc citations and the heuristic that prioritized one
- Regulation-derived hard constraints array in `catalog.compliance[]` — items whose source is statutory or regulatory text (never downgraded to `open_question`)

## Methodology
1. Triage the corpus per `references/doc-source-triage.md`. Classify every artifact into authoritative tiers (PIA, architecture deck, user guide, research pack, marketing). Reject marketing-only sources. Record the tier in the document index; downstream steps read tier off the index.
2. Extract regulation-driven hard constraints first per `references/regulation-driven-constraints.md`. Scan cited CFR parts, SORN notices, DOT orders, and FISMA references for retention periods, ATO requirements, airman certification rules, and access controls. These become `catalog.compliance[]` items and are not subject to confidence downgrade — statutory text is ground truth.
3. Harvest business domain, application purpose, and primary mission from the highest-tier artifact that names them (typically PIA or architecture deck). Record the citation as `{doc}:{page}:{quote}`.
4. Infer the technology stack from architecture decks and PIAs. Decks describe *intended* state, not deployed state — annotate every tech-stack entry `confidence='doc-inferred-low'` unless a PIA or ATO package confirms the production system of record.
5. Extract personas from user guides. A user guide's "Roles" or "Audience" section is the authoritative source for user-facing personas. Assign `doc-inferred-medium`. Do not synthesize personas from architecture decks — decks describe systems, not users.
6. Enumerate integrations from architecture decks, system context diagrams, and PIA "Information Sharing" sections. Each integration records `system`, `purpose`, `direction`, and `source_doc`. Direction is often absent from prose — when unclear, set `direction='unknown'` and emit a risk-register entry.
7. Apply multi-doc corroboration per `references/degraded-mode-confidence.md`. A claim asserted by two independent authoritative-tier docs earns `doc-inferred-medium-high`. A claim from one doc stays at `doc-inferred-medium`. A claim extrapolated from a description earns `doc-inferred-low`. A claim from a single speculative mention is not extracted — it becomes a risk-register entry instead.
8. Log contradictions. When two authoritative docs disagree (e.g., PIA says PostgreSQL, architecture deck says Oracle), pick the higher-tier doc, record the rejected claim in `open_questions[]`, and raise a risk-register entry naming the decision that depends on resolution.
9. For every field the skill could not populate (operations inventory, API endpoint count, database schema, test coverage, LOC), emit a risk-register entry per `assets/risk-register-template.yaml`. Each entry names the blocked downstream decision (e.g., "blocks `analyze-application` Pass 2", "blocks complexity classification").
10. Produce the provisional catalog notes file per `assets/provisional-catalog-notes.md`, one annotation per populated field. Validate the catalog entry against the schema, confirm every field has a `confidence` attribute, and hand off.

## Doc-Corpus Dispatch
Extraction behavior depends on which doc types dominate the corpus. Dispatch on artifact tier per `references/doc-source-triage.md`:

| Trigger | Reference file | Key patterns |
|---|---|---|
| PIA present in corpus | `references/doc-source-triage.md` (Tier 1) | Data Inventory tables, Information Sharing, Retention sections, SORN citations |
| Architecture deck or system context diagram present | `references/doc-source-triage.md` (Tier 2) | Actors, logical modules, intended tech, integration topology — cap tech-stack at `doc-inferred-low` |
| User guide or training manual present | `references/doc-source-triage.md` (Tier 3) | Roles, Audience, navigation gating, UI workflow descriptions |
| Regulation or CFR part cited | `references/regulation-driven-constraints.md` | Retention periods, ATO requirements, certification rules, access controls |
| Only research packs or secondary syntheses present | `references/doc-source-triage.md` (Tier 5) | Trace to primaries; emit risk-register entries where primaries are absent |

Dispatch is additive — a corpus with a PIA, a deck, and a user guide loads all three tier sections in sequence.

## Gotchas
- **Architecture decks describe intent, not reality.** A deck that says "microservices on Kubernetes" may predate a pivot to a monolith on EC2. Never mark deck-sourced tech stack higher than `doc-inferred-low` without a PIA or runtime config to confirm.
- **Marketing material is not evidence.** Vendor brochures, portfolio slides, and executive summaries routinely overstate capability. `references/doc-source-triage.md` ignores them by default. If an agent cites a marketing asset as the sole source for a field, the field is a risk-register entry, not a catalog claim.
- **PIA data inventories are authoritative for data handling, not for tech stack.** A PIA accurately describes what PII flows through the system and retention requirements; its technology section is often boilerplate. Use PIAs for `catalog.data_entities[]` and `catalog.compliance[]`, not `technology_stack[]`.
- **Regulation constraints do not degrade with source absence.** 14 CFR Part 61, Privacy Act SORNs, and FISMA controls apply whether or not the source tree is visible. These enter `catalog.compliance[]` at full confidence, cited to the statute.
- **Personas extracted from architecture decks are usually wrong.** Decks name *actors* in a system context diagram (e.g., "External System", "Admin") without real role semantics. User guides are the correct source for personas — they describe who actually uses the UI.
- **Every doc-inferred field must be re-verified when source lands.** The catalog entry this skill produces is a hypothesis set, not a finding set. Downstream skills must not consume it as if `catalog-application` had run — Discovery orchestration keys off the `confidence` attribute to suppress high-assurance decisions.
- **Contradictions that look like errors are often version skew.** A 2019 architecture deck contradicting a 2024 PIA is not a data-quality bug — it is time. Prefer the newer authoritative-tier doc, log the older one, and raise a risk-register entry on the delta.

## Quality Rules
- [ ] Every field in the produced catalog entry carries a `confidence` attribute in `{doc-inferred-low, doc-inferred-medium, doc-inferred-medium-high}` — no field may use `high` or omit the attribute
- [ ] `risk_register.yaml` is non-empty and contains at least one entry — a doc-only Discovery with zero gaps is a validation failure, not a complete run
- [ ] Every authoritative-doc citation uses `{doc-path}:{page-or-section}:{quote}` format; quote is a verbatim excerpt from the source
- [ ] Contradictions between two or more authoritative-tier docs are logged in `open_questions[]` with both citations and the resolution heuristic applied
- [ ] `catalog.compliance[]` items sourced from regulation or statute carry an explicit `statute_citation` field and are not tagged `doc-inferred` — statutory text is ground truth
- [ ] No field's sole source is a marketing asset or vendor brochure — such claims become risk-register entries, not catalog fields
- [ ] Every persona in `user_context.personas[]` cites a user guide section; personas extracted solely from architecture decks are rejected
- [ ] Every risk-register entry names the specific downstream decision or skill it blocks (e.g., "blocks `analyze-application`", "blocks `classify-complexity`")
- [ ] The orchestration flag `has_source_available == false` is confirmed at skill entry; the skill refuses to run when `true` and emits a message directing callers to `catalog-application`
- [ ] `assets/provisional-catalog-notes.md` is populated with one annotation per catalog field, recording source doc, location, and confidence tier

## Common Failure Modes
| Failure Mode | Symptom | Prevention |
|---|---|---|
| Marketing material treated as authoritative | Catalog tech stack cites a vendor brochure or executive summary; downstream complexity classification runs on hype numbers | Apply `references/doc-source-triage.md` tier rules at ingest; reject marketing-only sources; require every field to cite a PIA, architecture deck, user guide, or regulation |
| Doc-inferred fields passed to downstream without risk register | Risk register empty or absent; `analyze-application` consumes the catalog as if `catalog-application` had run | Enforce the quality rule that `risk_register.yaml` is non-empty; Discovery orchestrator must check `confidence` attributes before routing to downstream skills |
| Deck-sourced tech stack promoted to `high` confidence | Architecture deck describing intent is treated as the deployed reality; modernization plans the wrong migration | Cap deck-sourced tech stack at `doc-inferred-low` unless a PIA, ATO package, or runtime config confirms production state |
| Regulation constraints lost in confidence downgrade | 14 CFR Part 61 training requirement or 50-year medical retention flagged as `doc-inferred` and skipped by downstream compliance skills | Regulation-derived constraints are not tagged doc-inferred; they enter `catalog.compliance[]` with `statute_citation` and full confidence per `references/regulation-driven-constraints.md` |
| Contradictions silently resolved by last-write-wins | Two authoritative docs disagree on database engine; agent picks one without logging the loser, downstream decision cannot be audited | Every contradiction must be logged in `open_questions[]` with both citations and the resolution heuristic; raise a risk-register entry naming the dependent decision |

## Handoff Summary
When this skill completes, verify:
1. The provisional catalog entry validates against `schemas/discovery/application-catalog-entry.schema.json` and every non-regulation field carries a `confidence` attribute in the doc-inferred tier set.
2. `risk_register.yaml` is non-empty and every entry names the downstream decision it blocks.
3. `assets/provisional-catalog-notes.md` records source doc, page or section, verbatim quote, and confidence tier for every populated field.
4. Regulation-derived constraints are present in `catalog.compliance[]` with `statute_citation` and are not downgraded to doc-inferred.

Then proceed to: a source-acquisition workstream (portfolio team requests repository access) gated on the risk register's blocking items. Once source lands, re-run `catalog-application` and `analyze-application` against the provisional entry — do not carry doc-inferred fields forward unverified. Gate `G-DC` for Discovery completeness review remains blocked until the risk register's P0 entries are closed by source-backed re-verification.
