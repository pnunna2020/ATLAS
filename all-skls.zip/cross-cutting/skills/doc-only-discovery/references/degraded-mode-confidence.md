# Degraded-Mode Confidence Rules

When to emit doc-inferred data as a catalog field vs. flag as a
risk-register entry. Ceiling for any source-absent field is
`doc-inferred-medium-high` — never `high`.

## Confidence tiers

- **doc-inferred-medium-high** — two+ independent authoritative docs
  state the claim directly. Independent = different authors, dates,
  or artifact types, not two slides of one deck.
- **doc-inferred-medium** — one authoritative doc states the claim
  directly as a first-order assertion (e.g., PIA Data Inventory).
- **doc-inferred-low** — claim extrapolated from a description. Deck-
  sourced tech stack defaults here, because decks describe intent.
- **Not extracted** (risk-register only) — single speculative mention
  ("may use"), hearsay, marketing-only, or contradicts higher tier.

## Ceiling rule
No field extracted from documentation alone may be `high`. `high` is
reserved for source-verified findings from `catalog-application` and
`analyze-application`.

## Corroboration rule
Two docs corroborate only when:
1. Different authors or author teams, and
2. Not transitively derived (a research pack citing the deck does not
   corroborate the deck), and
3. Consistent on the specific claim.

## Contradiction rule
1. Prefer the higher tier (PIA > deck > user guide).
2. Same tier: prefer the newer doc.
3. Record rejected claim in `open_questions[]` with both citations.
4. Raise a risk-register entry naming the dependent decision.

## Decision table

| Evidence shape | Tier | Action |
|---|---|---|
| 2+ authoritative docs corroborate | medium-high | extract |
| 1 authoritative doc, direct claim | medium | extract |
| Description implies value | low | extract with caveat |
| Single speculative mention | none | risk-register |
| Only marketing | none | risk-register |
| Contradicts higher tier | varies | log contradiction |
