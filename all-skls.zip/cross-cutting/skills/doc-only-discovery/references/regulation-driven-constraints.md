# Regulation-Driven Constraints

Patterns for extracting hard constraints from regulatory text. These
enter `catalog.compliance[]` with `statute_citation` and are never
downgraded — statute is ground truth whether or not source is visible.

## Extraction pattern
Scan each regulation cited in the corpus for:
- Retention periods ("records retained for N years")
- ATO / authorization (FISMA Moderate ATO)
- Certification rules (airman certification)
- Access controls (who may access, when)
- Audit/logging requirements; PII + SORN coverage

## Example patterns

### 14 CFR Part 61 — Airman Certification
Certification apps must enforce eligibility per 61.35, medical
validity per 61.23, instructor endorsements per 61.193.
```yaml
compliance:
  - control_family: "airman-certification"
    statute_citation: "14 CFR 61.35(a)(2)"
    requirement: "Eligibility verification before knowledge test"
    confidence: "statute"
```

### Privacy Act SORN notices
Every PII system maps to a published SORN; access, retention, and
disposal follow the SORN. Example: DOT/FAA 856 — 50-year retention on
airman medical files.
```yaml
compliance:
  - control_family: "privacy-act"
    statute_citation: "DOT/FAA 856; 5 U.S.C. 552a(e)(4)"
    requirement: "50-year retention of airman medical records"
    confidence: "statute"
```

### FISMA
Federal systems require an ATO at the appropriate FIPS 199 impact
level. ATO package is a Discovery input.
```yaml
compliance:
  - control_family: "fisma"
    statute_citation: "FISMA 44 U.S.C. 3554; FIPS 199"
    requirement: "ATO at Moderate impact level"
    confidence: "statute"
```

## Rules
1. Never tag a statute-derived constraint `doc-inferred` — use `statute`.
2. Every entry has a `statute_citation` resolvable to a CFR part,
   U.S. Code section, SORN number, or DOT order.
3. Absence of source does not relax statute.
4. If the corpus cites a regulation but the applicable section is
   unclear, emit a risk-register entry rather than guess.
