# Doc Source Triage

Reliability hierarchy for doc-only Discovery. Classify every artifact
at ingest; higher tiers override lower tiers on contradictions.
Marketing is ignored.

## Tier 1 — Privacy Impact Assessment (PIA)
Authoritative for: data entities, PII inventory, data flows,
information-sharing, retention, compliance. Not authoritative for:
deployed tech stack (PIA tech sections are often boilerplate). Use for
`catalog.data_entities[]`, `catalog.compliance[]`, PII integrations.

## Tier 2 — Architecture decks, system context diagrams
Authoritative for: *intended* state — logical modules, target tech,
integration topology, actors. Not for deployed reality. Decks routinely
predate pivots. Cap deck-sourced tech stack at `doc-inferred-low` until
a PIA or runtime config confirms.

## Tier 3 — User guides and training manuals
Authoritative for: user-facing flows, personas, roles, permissions,
UI navigation, business operations as end users see them. Correct
source for `user_context.personas[]`. Not for backend tech.

## Tier 4 — Regulations, CFR parts, SORNs, DOT orders, FISMA
Authoritative for: hard constraints — retention, ATO, certification,
access controls. Statute is ground truth; never downgrade. Feeds
`catalog.compliance[]` with `statute_citation`.

## Tier 5 — Research packs, Q&A transcripts, analyst reports
Secondary synthesis. Never sole source — trace to the primary. If the
primary is unavailable, emit a risk-register entry.

## Tier 6 — Marketing, brochures, executive summaries
Ignored. Sole-source marketing becomes a risk-register entry, never
a catalog field.

## Resolving contradictions
1. Higher tier wins (Tier 1 > Tier 2 > Tier 3).
2. Same tier: newer doc wins (publication date or revision).
3. Same tier and date: log both; escalate to open-question.
4. Every contradiction is recorded in `open_questions[]` with both
   citations and raises a risk-register entry naming the blocked
   downstream decision.
