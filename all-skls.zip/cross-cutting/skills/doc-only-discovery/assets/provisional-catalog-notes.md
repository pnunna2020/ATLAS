# Provisional Catalog Notes — <application-id>

Per-field annotation for every populated field in the provisional
`application-catalog-entry.json`. One row per field. Records the source
document, location within the document, verbatim quote or paraphrase,
and the assigned confidence tier.

Agents fill this in as they populate the catalog entry. A catalog field
without a matching row here is a validation failure.

## Confidence tier legend
- `doc-inferred-low` — single non-authoritative doc, or extrapolation from description
- `doc-inferred-medium` — single authoritative-tier doc (PIA, architecture deck, user guide), direct statement
- `doc-inferred-medium-high` — two or more independent authoritative-tier docs corroborate
- `statute` — derived from regulation or statute; not doc-inferred, not subject to downgrade

## Field annotations

| Catalog field | Value | Source doc | Location | Quote or paraphrase | Confidence | Notes |
|---|---|---|---|---|---|---|
| `application.name` | <value> | <relative path> | <page/section/slide> | "<verbatim excerpt>" | doc-inferred-medium | |
| `application.business_domain` | <value> | <path> | <loc> | "<quote>" | doc-inferred-medium | |
| `application.mission_purpose` | <value> | <path> | <loc> | "<quote>" | doc-inferred-medium | |
| `technology_stack[0].language` | <value> | <path> | <loc> | "<quote>" | doc-inferred-low | deck-sourced; cap at low until PIA confirms |
| `technology_stack[0].framework` | <value> | <path> | <loc> | "<quote>" | doc-inferred-low | |
| `technology_stack[0].database` | <value> | <path> | <loc> | "<quote>" | doc-inferred-low | |
| `data_entities[0].name` | <value> | <path> | <loc> | "<quote>" | doc-inferred-medium | PIA data inventory |
| `external_integrations[0].system` | <value> | <path> | <loc> | "<quote>" | doc-inferred-medium | |
| `external_integrations[0].direction` | <value-or-unknown> | <path> | <loc> | "<quote-or-none>" | doc-inferred-low | if unknown, risk-register entry required |
| `authentication.method` | <value> | <path> | <loc> | "<quote>" | doc-inferred-medium | |
| `user_context.personas[0].role` | <value> | <user-guide-path> | <loc> | "<quote>" | doc-inferred-medium | user guide only — not deck |
| `user_context.business_criticality.rating` | <value-or-null> | <path> | <loc> | "<quote-or-none>" | doc-inferred-low | never mark `high` without source evidence |
| `compliance[0]` | <value> | <statute-citation> | <section> | "<statute text>" | statute | e.g., 14 CFR 61.35 |
| `compliance[1]` | <value> | <statute-citation> | <section> | "<statute text>" | statute | e.g., Privacy Act SORN retention |

## Contradictions observed
List every contradiction between two or more authoritative docs that
was resolved by tier heuristic. Each contradiction must also appear in
the catalog entry's `open_questions[]` and the risk register.

| Field | Doc A (accepted) | Doc B (rejected) | Resolution heuristic | Risk register ID |
|---|---|---|---|---|
| <catalog-field> | <path:loc — claim> | <path:loc — claim> | <e.g., newer PIA overrides older deck> | RR-### |

## Fields intentionally left null
Fields the skill could not populate from the corpus. Each must have a
matching risk-register entry that names the gap and blocked decision.

| Catalog field | Reason null | Risk register ID |
|---|---|---|
| `size_metrics.total_loc` | source tree unavailable | RR-### |
| `size_metrics.api_endpoint_count` | source tree unavailable | RR-### |
| `size_metrics.estimated_test_coverage` | source tree unavailable | RR-### |
