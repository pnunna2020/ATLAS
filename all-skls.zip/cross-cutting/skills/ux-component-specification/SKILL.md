---
name: ux-component-specification
description: >
  Create component-level specifications that map legacy UI elements to modern
  component equivalents with typed interfaces, USWDS mapping, and accessibility
  requirements. Produces implementation-ready specs for code generation. Use during
  Modernization Design phase (P4.2) after ux-page-specification completes. Triggers on
  component specification, UI component design, component library, USWDS mapping,
  component interface, component catalog, reusable components.
agent: opus
allowed-tools:
  - Read
  - Write
  - Grep
  - Bash
---

# UX Component Specification

## Purpose
Produce implementation-ready component specifications that bridge the gap between
page-level UI descriptions and actual code generation. Each component spec defines
a typed interface (props, state, events), maps to modern framework equivalents,
and includes accessibility requirements. Components identified as shared across
pages are deduplicated into a reusable component library.

This skill transforms the page inventories (from ux-page-specification) into
component contracts that the tdd-generation skill can directly consume. Without
component specs, code generation must infer component boundaries, prop types, and
interaction behavior, leading to inconsistent implementations, duplicated components,
and accessibility gaps.

For FAA systems, this skill maps legacy UI elements to USWDS (US Web Design System)
components wherever applicable, ensuring compliance with federal design standards
and Section 508 accessibility requirements out of the box.

This skill is the third and final step in the George methodology's UX pipeline:
1. ux-flow-derivation (flows between pages)
2. ux-page-specification (what each page contains)
3. **ux-component-specification** (how each component works) -- you are here

## Inputs
- UX page specifications (from ux-page-specification): page inventories with
  component tables, data bindings, interaction catalogs, and accessibility assessments
- Extraction artifact (from extraction skill): data models, business rules,
  and validation logic that components must implement
- Technology profile from discovery (from analyze-application or
  legacy-architecture-mapper): source technology stack to understand legacy
  component implementations
- Client profile (from profiles/ directory): target technology stack, USWDS
  requirements, FAA-specific design standards

## Outputs
- **Component inventory with deduplication**: Master list of all unique components
  across all pages, with shared components identified and consolidated
- **Per-component specification**: Typed interface (props schema, state schema,
  event catalog, slots/children), behavior definition, accessibility requirements
- **Legacy-to-modern mapping table**: Every legacy UI pattern mapped to its
  modern equivalent with transformation notes
- **USWDS component mapping**: Legacy components mapped to specific USWDS
  components where applicable, with version references
- **Reuse analysis**: Which components are shared across pages, usage counts,
  and variation analysis
- **Implementation priority matrix**: Components ranked by page count, complexity,
  reuse factor, and risk tier
- **Accessibility specification per component**: ARIA roles, keyboard navigation,
  screen reader behavior, focus management

## Methodology

### Step 1 -- Consolidate Component Inventory
Collect all components from every page specification and build a master list:

1. **Extract**: Pull every component (PG-NNN-CNN) from all page specifications
2. **Normalize types**: Ensure all components use the standardized type taxonomy
   from ux-page-specification
3. **Identify duplicates**: Components that appear on multiple pages with the same
   type, similar data bindings, and compatible behavior are candidate shared components
4. **Merge shared components**: Create a single component spec for shared components.
   Document which pages use it and any per-page variations (different labels,
   different data sources, optional features)
5. **Assign component IDs**: Shared components get IDs in the format CMP-NNN.
   Page-specific components retain their PG-NNN-CNN IDs

**Deduplication rules**:
- Same type + same data shape + same interactions = shared component
- Same type + different data shape = generic component with typed props
- Same type + different behavior = separate components (not shared)
- Same visual appearance + different semantics = separate components (do not merge
  a "Delete" button and a "Submit" button just because they look the same)

### Step 2 -- Define Component Interfaces
For each unique component (shared and page-specific), define the typed interface:

**Props schema** (inputs to the component):
```typescript
interface UserProfileCardProps {
  /** User object to display */
  user: {
    id: number;
    firstName: string;
    lastName: string;
    email: string;
    avatarUrl?: string;
    role: 'admin' | 'analyst' | 'reviewer' | 'public';
    department: { id: number; name: string };
  };
  /** Whether to show edit controls */
  editable: boolean;
  /** Compact mode for sidebar display */
  compact?: boolean;
}
```

**State schema** (internal component state):
```typescript
interface UserProfileCardState {
  /** Whether edit mode is active */
  isEditing: boolean;
  /** Draft values during edit */
  draft: Partial<UserProfileCardProps['user']>;
  /** Validation errors by field name */
  errors: Record<string, string>;
  /** Whether save is in progress */
  isSaving: boolean;
}
```

**Event catalog** (outputs from the component):
```typescript
interface UserProfileCardEvents {
  /** Fired when user saves edits. Payload: updated user fields */
  onSave: (updates: Partial<User>) => void;
  /** Fired when user cancels edit mode */
  onCancel: () => void;
  /** Fired when user clicks the profile link */
  onNavigate: (userId: number) => void;
}
```

**Slots/children** (composition points):
```typescript
interface UserProfileCardSlots {
  /** Additional actions rendered in the card footer */
  actions?: ReactNode;
  /** Custom badge displayed next to the user name */
  badge?: ReactNode;
}
```

Use TypeScript interface notation for props, state, and events regardless of the
target framework. TypeScript interfaces are the most portable way to express typed
component contracts. The code generation skill will translate to the target
framework's idiom (React props, Vue props, Angular @Input/@Output).

### Step 3 -- Map Legacy to Modern Components
For each component, document the legacy implementation and its modern equivalent:

| Legacy Pattern | Source Tech | Modern Equivalent | Transformation Notes |
|---------------|------------|-------------------|---------------------|
| `<cfselect>` with query binding | ColdFusion | React `<Select>` with async options loader | Replace query= with useEffect + API call; handle loading state |
| `<asp:GridView>` with auto-paging | .NET WebForms | React data table with client pagination | Replace ViewState pagination with URL query params; add sort |
| `<s:form>` with Struts validation | Java/Struts | React Hook Form with Yup/Zod schema | Move XML validation config to schema; keep same rules |
| `<table>` with inline `<script>` sort | Raw HTML/JS | React table component with sort state | Replace DOM manipulation with state-driven rendering |
| jQuery `.datepicker()` plugin | jQuery UI | USWDS Date Picker or React date picker | Replace jQuery plugin with controlled component |
| Bootstrap modal with jQuery | Bootstrap 3/4 | USWDS Modal or React portal-based modal | Replace jQuery show/hide with React state; manage focus |

For each mapping, document:
- What changes (DOM structure, event handling, data flow, state management)
- What stays the same (validation rules, business logic, user-facing behavior)
- Migration risks (behavior differences between legacy and modern patterns)

### Step 4 -- Map to USWDS Components
For FAA and federal government modernization projects, map components to USWDS
(US Web Design System) equivalents. This is not optional for FAA systems.

**USWDS component mapping table**:

| Component Type | USWDS Component | USWDS Version | Notes |
|---------------|----------------|---------------|-------|
| text-input | usa-input | 3.x | Use usa-input-group for prefix/suffix |
| textarea | usa-textarea | 3.x | |
| dropdown | usa-select | 3.x | For complex: usa-combo-box |
| checkbox | usa-checkbox | 3.x | |
| radio-group | usa-radio | 3.x | |
| date-picker | usa-date-picker | 3.x | |
| file-upload | usa-file-input | 3.x | |
| data-table | usa-table | 3.x | Add sorting with usa-table--sortable |
| pagination | usa-pagination | 3.x | |
| modal | usa-modal | 3.x | Focus trap built in |
| alert | usa-alert | 3.x | Variants: info, success, warning, error |
| accordion | usa-accordion | 3.x | |
| breadcrumb | usa-breadcrumb | 3.x | |
| button | usa-button | 3.x | Variants: default, secondary, outline |
| tab-group | Not in USWDS core | -- | Use custom tabs following USWDS patterns |
| stepper | usa-step-indicator | 3.x | For multi-step wizards |
| tooltip | usa-tooltip | 3.x | |
| tag/badge | usa-tag | 3.x | |
| sidebar-nav | usa-sidenav | 3.x | |
| card | usa-card | 3.x | usa-card-group for collections |

For components without a direct USWDS equivalent:
- Document the custom component requirement
- Specify that it must follow USWDS design tokens (colors, typography, spacing)
- Ensure it meets the same accessibility standards as USWDS components
- Reference the USWDS design principles for visual consistency

### Step 5 -- Define Accessibility Specifications
For each component, specify accessibility requirements beyond the USWDS defaults:

**ARIA roles and attributes**:
```html
<!-- Data table with sort -->
<table role="grid" aria-label="User accounts">
  <thead>
    <tr>
      <th scope="col" aria-sort="ascending">
        <button>Name</button>
      </th>
    </tr>
  </thead>
</table>
```

**Keyboard navigation**:
| Component | Key | Action |
|-----------|-----|--------|
| Data table | Arrow Up/Down | Move between rows |
| Data table | Enter | Activate row action |
| Data table | Tab | Move to next interactive element |
| Modal | Escape | Close modal, return focus to trigger |
| Modal | Tab | Cycle through focusable elements (focus trap) |
| Dropdown | Arrow Down | Open menu, move to next option |
| Dropdown | Enter/Space | Select highlighted option |
| Dropdown | Escape | Close menu, return focus to trigger |
| Date picker | Arrow keys | Navigate calendar grid |
| Accordion | Enter/Space | Toggle section expand/collapse |

**Screen reader behavior**:
- Dynamic content updates must use `aria-live` regions (polite for non-urgent,
  assertive for errors)
- Loading states must be announced (`aria-busy="true"`, loading announcement)
- Form validation errors must be associated with fields via `aria-describedby`
- Table sort state must be announced via `aria-sort`
- Page/section changes in SPA must announce the new content

**Focus management**:
- Modal open: focus moves to first focusable element inside modal
- Modal close: focus returns to the element that triggered the modal
- Inline edit save: focus moves to the saved value or next logical element
- Delete operation: focus moves to the next item in the list (not to a void)
- Page navigation: focus moves to the main content area or h1
- Error display: focus moves to the first error message or error summary

### Step 6 -- Analyze Reuse Patterns
Produce a reuse analysis across all components:

**Reuse matrix**:
| Component | Type | Pages Used | Variations | Reuse Factor |
|-----------|------|-----------|-----------|-------------|
| CMP-001 SearchBar | autocomplete | 12 pages | 3 (entity-specific data sources) | High |
| CMP-002 DataTable | data-table | 8 pages | 4 (different columns, actions) | High |
| CMP-003 FormSection | form-group | 15 pages | 2 (horizontal, vertical) | High |
| PG-005-C03 FlightScheduleGrid | data-table | 1 page | 0 | None (page-specific) |

**Component library recommendations**:
- Components with reuse factor "High" (3+ pages) should be in the shared component
  library
- Components with reuse factor "Medium" (2 pages) should be shared if variations
  are minor
- Components with reuse factor "None" (1 page) are page-specific unless they
  represent a pattern likely to recur in future development

**Variation handling**:
For shared components with variations, define the props that control variation:
- If variation is data-driven (different columns in a table), use generic typed
  props (column definitions as props)
- If variation is behavioral (some tables sort, others do not), use feature flags
  (sortable: boolean)
- If variation is structural (fundamentally different rendering), consider separate
  components instead of an over-configured shared component

### Step 7 -- Produce Implementation Priority Matrix
Rank components for implementation order based on:

| Factor | Weight | Scoring |
|--------|--------|---------|
| Page count (how many pages use it) | 30% | 1-5 based on usage quartile |
| Complexity (prop count, state, events) | 25% | 1 (simple) to 5 (complex) |
| Reuse factor (shared vs. page-specific) | 20% | 5 (shared, 5+ pages) to 1 (single page) |
| Risk tier alignment | 15% | 5 (Tier 1 critical) to 1 (Tier 3 low) |
| Accessibility complexity | 10% | 1 (simple) to 5 (complex ARIA, focus management) |

**Priority tiers**:
- **P1 -- Build first**: Shared layout components (header, nav, footer), shared
  form components (input groups, validation), shared data table. These unblock
  all page implementations.
- **P2 -- Build second**: Page-specific components for Tier 1 (highest risk) pages.
  These are the most critical user-facing functionality.
- **P3 -- Build third**: Page-specific components for Tier 2/3 pages and
  low-reuse components.
- **P4 -- Build last**: Cosmetic components, progressive enhancements, and
  components for features that may be deferred.

### Step 8 -- Define Data Flow Contracts
For each component, specify exactly how data enters, transforms, and exits:

**Data entry** (how data arrives at the component):
- Props passed from parent (typed, validated by prop schema)
- Data fetched internally (API calls made by the component itself)
- Context/store data (global state injected via React Context, Redux, etc.)
- URL parameters (read from router)

**Data transformation** (what the component does with data):
- Formatting (dates, currency, phone numbers)
- Filtering (which items to display from a list)
- Sorting (column sort in tables)
- Validation (input validation against rules from extraction artifact)
- Aggregation (counts, totals, summaries)

**Data exit** (how data leaves the component):
- Events with typed payloads (onSave, onChange, onDelete)
- Form submission (to a specified endpoint)
- URL updates (query params for sort/filter/page state)
- No side effects (display-only components have no data exit)

**Validation rules** (from extraction artifact):
Map business rules from the extraction artifact to specific components. Each
validation rule extracted during the extraction skill must be assigned to the
component that enforces it:
- Field-level validation (assigned to individual input components)
- Cross-field validation (assigned to form container component)
- Business rule validation (assigned to form submit handler)
- Server-side validation (documented but enforced by backend, not component)

## Gotchas
- **Do not over-generalize**: A shared component with 30 props and 15 feature
  flags is worse than 3 focused components. If variations require fundamentally
  different rendering, they are different components.
- **USWDS is not optional for FAA**: Every component that has a USWDS equivalent
  MUST use it. Custom components are allowed only when USWDS has no equivalent.
  This is a federal compliance requirement.
- **TypeScript interfaces are contracts, not implementation**: The prop schemas
  define what the component accepts. Do not include implementation details
  (internal hooks, effect dependencies, render logic) in the spec.
- **Legacy component boundaries may be wrong**: A legacy page may have one giant
  form where the modern version should have 5 sub-components. Decompose based
  on responsibility, not legacy structure.
- **Accessibility is per-component, not per-page**: Each component must be
  independently accessible. A page that is "mostly accessible" but has one
  inaccessible component fails the page-level assessment.
- **Events must have typed payloads**: Do not define events as
  `onSave: () => void`. Define what data the event carries. The parent component
  depends on this contract.
- **Client profile drives USWDS version**: Check the client profile for the
  target USWDS version. Do not assume the latest version; some agencies are
  pinned to specific releases.
- **Validation rules live in two places**: Client-side validation (immediate
  feedback) and server-side validation (authoritative enforcement). Both must
  be documented, and the rules must match. The extraction artifact is the source
  of truth for validation logic.

## Quality Rules
- [ ] Every component has a typed props schema -- no untyped or `any` props
- [ ] Every event has a documented payload shape -- no `() => void` events that actually carry data
- [ ] USWDS component mapping is complete for all applicable components (FAA systems)
- [ ] USWDS mappings reference specific component names and version numbers
- [ ] Shared components are identified and deduplicated -- no identical components with different IDs
- [ ] Deduplication preserves necessary variations via props, not by creating over-configured mega-components
- [ ] Accessibility specifications include ARIA roles, keyboard navigation, screen reader behavior, and focus management per component
- [ ] Legacy-to-modern mapping documents what changes, what stays the same, and migration risks
- [ ] Validation rules from extraction artifact are assigned to specific components
- [ ] Implementation priority matrix uses the defined scoring factors, not subjective judgment
- [ ] Data flow is documented end-to-end: entry (props/fetch/context) -> transform -> exit (events/submit)
- [ ] Components without USWDS equivalents follow USWDS design tokens for visual consistency
- [ ] Reuse analysis includes variation handling strategy for shared components with per-page differences

## Common Failure Modes

| Failure | Symptom | Prevention |
|---------|---------|------------|
| Mega-component anti-pattern | Shared component has 30+ props and 15 boolean flags; impossible to test or maintain | If a component needs more than ~10 props, decompose into smaller components |
| Missing USWDS mapping | Components use custom styling when USWDS equivalents exist; fails federal compliance | Map every component type against USWDS catalog before designing custom solutions |
| Untyped interfaces | Props defined as `any` or `object`; code generation produces untyped components | Require specific TypeScript types for every prop; reject `any` in review |
| Accessibility bolted on | ARIA attributes added to spec after component design; structural issues (missing focus trap) | Define accessibility requirements as part of the component interface, not after |
| Validation split ignored | Client-side validation rules differ from server-side; users see conflicting error messages | Assign extraction artifact validation rules to both client component and server handler |
| Over-deduplication | Functionally different components merged because they have the same type; behavior conflicts | Deduplication is by type AND behavior AND data shape, not type alone |
| No reuse analysis | Every component is page-specific; shared patterns not identified; massive duplication in generated code | Run cross-page analysis after individual specs; score reuse factor for every component |
| Priority by gut feel | Implementation order is subjective; critical shared components built last | Apply the scoring matrix mechanically; verify P1 components unblock downstream work |
| Legacy boundaries preserved | Modern components mirror legacy page structure (one giant form) instead of proper decomposition | Decompose based on single responsibility; one component = one concern |
| Stale extraction artifact | Component validation rules do not match current extraction artifact; rules were updated but components not | Cross-reference component validation rules against extraction artifact at handoff |

## Handoff Summary
When this skill completes, verify:
1. **Deduplication**: Shared components are identified, consolidated, and variation-handling is defined
2. **Typed interfaces**: Every component has props schema, state schema, event catalog with typed payloads
3. **USWDS compliance**: All applicable components map to specific USWDS components (version-pinned)
4. **Accessibility**: Every component has ARIA, keyboard, screen reader, and focus management specs
5. **Validation traceability**: Every validation rule from extraction maps to a specific component
6. **Priority**: Implementation priority matrix is complete with scored rankings
7. Archive the component specification artifact as a versioned artifact in the artifacts directory
8. Proceed to **tdd-generation** (P4.3) for code generation using these component specs as input contracts
9. Feed USWDS mapping into **design-system** skill for FAA branding and visual consistency validation
10. Feed the reuse analysis into **module-design** to inform service boundary decisions around shared UI
