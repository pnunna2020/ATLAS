---
name: parallel-run-monitor
description: >
  Monitor the parallel run period where legacy and modern systems operate simultaneously, comparing outputs and tracking divergence. Use during P6.1 parallel run. Triggers on parallel run, parallel operations, legacy comparison, or dual-running.
agent: sonnet
allowed-tools:
  - Read
  - Write
  - Bash
---

# Parallel Run Monitoring
## Purpose
During the parallel run period, both legacy and modern systems process real
traffic. This skill monitors both and flags divergences.

## Workflow
1. Configure comparison points (API responses, batch outputs, data writes)
2. Run continuous comparison via `scripts/parallel_compare.sh`
3. Log all divergences with severity classification
4. Generate daily parallel run report
5. When divergence rate drops below threshold for sustained period: clear for decommission

## Gotchas
- **Parallel run duration varies by safety tier**: T1 = 90 days minimum,
  T2 = 30 days, T3 = 14 days. These are MINIMUM periods.
- **User adoption metrics matter as much as technical parity**: If the modern
  system works perfectly but users aren't using it, the parallel run hasn't
  succeeded.
- **Don't write to BOTH systems**: In most cases, only ONE system should be
  the system of record during parallel run. The other is read-only or
  receives replicated data.

## Quality Rules
- [ ] Parallel run duration meets minimum tier requirements: T1>=90 days, T2>=30 days, T3>=14 days
- [ ] Only ONE system is the system of record during parallel run — no dual-write
- [ ] Daily divergence reports are generated and reviewed
- [ ] User adoption metrics are tracked alongside technical parity metrics
- [ ] Divergence severity classification follows the same CRITICAL/ACCEPTABLE scheme as parity verification
- [ ] Decommission clearance requires sustained divergence rate below threshold for the required period

## Common Failure Modes
| Failure Mode | Symptom | Prevention |
|-------------|---------|------------|
| Parallel run too short | T1 app cleared after 30 days instead of 90; latent issues surface post-decommission | Enforce tier-specific minimum durations; do not allow early termination for T1 without safety board approval |
| Dual-write corruption | Both systems write to different databases; data diverges and neither is authoritative | Designate one system as system of record; other is read-only or receives replication |
| Adoption ignored | Technical parity looks good but users still use legacy; modern system unused after decommission | Track adoption metrics (active users, feature usage) alongside technical parity |
| Divergence reports not reviewed | Daily reports accumulate but nobody reviews them; issues discovered too late | Assign reviewer responsibility; escalate if reports go unreviewed for 48 hours |

## Handoff Summary
When this skill completes, verify:
1. Parallel run met the tier-specific minimum duration
2. Divergence rate is below threshold for the required sustained period
3. User adoption metrics meet defined thresholds
4. Daily reports were reviewed throughout the parallel run period
Then proceed to: Decommission Gate review, then `legacy-decommission` (P6.3) for formal system retirement
