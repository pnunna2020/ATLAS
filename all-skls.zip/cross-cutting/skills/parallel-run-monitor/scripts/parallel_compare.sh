#!/usr/bin/env bash
#
# Continuously compare outputs of the legacy and modernized systems during
# the parallel run period.
#
# Consumes comparison points declared in the parallel-run config (API
# responses, batch outputs, data writes) and emits divergence events with
# severity classification (CRITICAL / ACCEPTABLE).
#
# Output: daily divergence report and a rolling divergence-rate metric.
#
# Usage: parallel_compare.sh <config-path>

set -euo pipefail

if [[ $# -lt 1 ]]; then
    echo "Usage: $0 <config-path>" >&2
    exit 2
fi

CONFIG_PATH="$1"

if [[ ! -f "$CONFIG_PATH" ]]; then
    echo "Config file not found: $CONFIG_PATH" >&2
    exit 2
fi

echo "Starting parallel comparison using $CONFIG_PATH"

# TODO(skill-author): Implement the main comparison loop:
#
# 1. Parse the config to enumerate comparison points (API endpoints, batch
#    output files, database tables to snapshot).
# 2. For each comparison point:
#      - Capture legacy output
#      - Capture modern output
#      - Apply normalization rules (from the parity-verifier skill)
#      - Compare and classify any divergence
# 3. Emit events to the divergence log with: timestamp, comparison point,
#    severity, diff summary.
# 4. Roll up to a daily divergence report and a rolling rate.
#
# Use the parity-verifier skill's comparison primitives so legacy/modern
# diffs follow the same classification scheme in both P5.1 parity testing
# and P6.1 parallel run monitoring.

echo "parallel_compare.sh is a stub — no comparisons performed"
exit 0
