# Node Sidecar Integration Patterns

Coverage for the five canonical ways a Node.js sidecar integrates
with a .NET host application in the same repo.

## Pattern 1: IIS URL Rewrite + iisnode

Most common pattern in legacy ASP.NET WebForms apps. IIS hosts
the .NET app; Node.js runs under `iisnode` as an in-process
worker; URL rewrite rules dispatch selected paths to Node.

### `web.config` signature

```xml
<configuration>
  <system.webServer>
    <handlers>
      <add name="iisnode" path="*.js" verb="*" modules="iisnode" />
    </handlers>

    <rewrite>
      <rules>
        <rule name="NodeAuthAPI" stopProcessing="true">
          <match url="^api/auth/(.*)" />
          <action type="Rewrite" url="IACRANodeApi/server.js" />
        </rule>
      </rules>
    </rewrite>

    <iisnode
      node_env="%node_env%"
      nodeProcessCountPerApplication="4"
      maxConcurrentRequestsPerProcess="1024"
      maxNamedPipeConnectionRetry="100"
      namedPipeConnectionRetryDelay="250"
      maxNamedPipeConnectionPoolSize="512" />
  </system.webServer>
</configuration>
```

Extraction targets:

- `<handlers>` entry for `iisnode` module.
- `<rewrite><rules>` mapping URL patterns to sidecar scripts.
- `<iisnode>` config (process pool size, retry policy).

## Pattern 2: Reverse Proxy (ASP.NET Core)

ASP.NET Core apps can reverse-proxy to a Node sidecar via YARP
or Microsoft.AspNetCore.HttpForwarder.

```csharp
// Program.cs
builder.Services.AddReverseProxy()
    .LoadFromConfig(builder.Configuration.GetSection("ReverseProxy"));

app.MapReverseProxy();
```

```json
// appsettings.json
{
  "ReverseProxy": {
    "Routes": {
      "node-auth": {
        "ClusterId": "node-sidecar",
        "Match": { "Path": "/api/auth/{**catch-all}" }
      }
    },
    "Clusters": {
      "node-sidecar": {
        "Destinations": {
          "d1": { "Address": "http://localhost:3001/" }
        }
      }
    }
  }
}
```

Extract routes + cluster destinations.

## Pattern 3: Direct HttpClient Calls

.NET code calls the sidecar directly over HTTP:

```csharp
public class AuthService
{
    private readonly HttpClient _http;
    public AuthService(HttpClient http) { _http = http; }

    public async Task<string> IssueJwt(string userId)
    {
        var response = await _http.PostAsJsonAsync(
            "http://localhost:3001/token",
            new { userId });
        return await response.Content.ReadAsStringAsync();
    }
}
```

Localhost + custom port is the tell. Extract:

- Target URL.
- Request shape (method, body, headers).
- Caller class + method.

## Pattern 4: Process Launch at Startup

The .NET app spawns the Node sidecar as a child process on startup:

```csharp
// Global.asax Application_Start
protected void Application_Start()
{
    var nodePath = @"C:\Program Files\nodejs\node.exe";
    var scriptPath = Server.MapPath("~/IACRANodeApi/server.js");
    _nodeProc = Process.Start(nodePath, $"\"{scriptPath}\"");
}

protected void Application_End()
{
    _nodeProc?.Kill();
}
```

Fragile: process crash leaves sidecar unavailable. Modern
alternative: process manager (pm2, forever) or Windows Service.

## Pattern 5: External Process Manager

The sidecar runs as an independent Windows Service via
`pm2-windows-service` or equivalent:

```javascript
// ecosystem.config.js (pm2 config)
module.exports = {
  apps: [{
    name: 'iacra-node-api',
    script: 'server.js',
    cwd: './IACRANodeApi',
    env: {
      NODE_ENV: 'production',
      PORT: 3001,
      JWT_SECRET: '<set via env; redact>'
    },
    instances: 2,
    exec_mode: 'cluster'
  }]
};
```

The .NET app talks to the sidecar via HttpClient or reverse
proxy; the sidecar lifecycle is managed separately.

## Sidecar Frameworks

| Framework | `package.json` dep | Entry shape |
|---|---|---|
| Express 4.x | `express` | `const app = express(); app.get(...)` |
| Express 5.x | `express@^5` | Same; async handlers supported natively |
| Fastify | `fastify` | `const f = require('fastify')(); f.route({...})` |
| Koa | `koa` | `const app = new Koa(); app.use(...)` |
| Hapi | `@hapi/hapi` | `server.route({ method, path, handler })` |
| NestJS | `@nestjs/core`, `@nestjs/common` | `@Controller() + @Get()` decorators |
| Bare HTTP | `http` builtin | `http.createServer((req, res) => ...)` |

## Auth Library Catalog

| Library | Purpose |
|---|---|
| `jsonwebtoken` | JWT sign / verify (most common) |
| `jose` | Modern JWT/JWE/JWS library (replacement for jsonwebtoken) |
| `passport` | Auth strategy framework |
| `passport-jwt` | JWT strategy for Passport |
| `passport-local` | Local username/password strategy |
| `passport-saml` | SAML strategy |
| `express-jwt` | Express middleware for JWT verification |
| `@auth0/*` | Auth0 SDKs |
| `bcrypt`, `argon2` | Password hashing |
| `crypto` (builtin) | Low-level crypto; flag custom implementations |

Detecting `jsonwebtoken` + an endpoint named `/token` or `/login`
= JWT issuance sidecar.

## Endpoint Extraction

For Express:

```javascript
app.get('/token', async (req, res) => { ... });
app.post('/verify', authMiddleware, async (req, res) => { ... });
app.use('/admin', adminRouter);
```

Capture: method, path, middleware chain, handler location.

For NestJS:

```typescript
@Controller('auth')
export class AuthController {
    @Get('token')
    issueToken() { ... }

    @Post('verify')
    verifyToken(@Body() body: VerifyDto) { ... }
}
```

Capture: controller route prefix + method decorators.

## Secret Detection

Grep for:

- JWT signing keys: `JWT_SECRET`, `JWT_PRIVATE_KEY`, PEM blocks
  (`-----BEGIN RSA PRIVATE KEY-----`).
- API keys: `API_KEY`, `CLIENT_SECRET`.
- Database connection strings in `.env`.
- OAuth redirect URIs that embed secrets.

Redact values; preserve file:line locations.

## Modernization Options

### Option A: Port to .NET

Rewrite the sidecar's logic in .NET (`Microsoft.AspNetCore.Authentication.JwtBearer`
for JWT, `Microsoft.IdentityModel.Tokens` for signing). Eliminates
polyglot deploy complexity.

Effort: ~1-4 days per sidecar depending on surface area.

### Option B: Deploy as container

Keep the sidecar as-is but containerize it. Modern deploy target
runs the container as a sibling service (Docker Compose, Kubernetes
pod with two containers, ECS task).

Effort: ~0.5-1 day per sidecar.

### Option C: Deploy as Lambda / Azure Function

Refactor the sidecar to a serverless function. API Gateway /
Azure API Management routes auth paths to the function.

Effort: ~1-2 days per sidecar; requires retry/cold-start handling.

### Option D: Merge into .NET app auth middleware

If the sidecar is JWT-only, port logic to `AddAuthentication()`
in `Program.cs`. Most efficient for simple auth sidecars.

Effort: ~0.5-1 day.

## Process Managers

| Manager | Detection signal |
|---|---|
| pm2 | `pm2.config.js`, `ecosystem.config.js` |
| forever | `forever.json` |
| systemd | Unit file under `/etc/systemd/system/` |
| Windows Service (pm2-windows-service, nssm) | Service registration scripts |
| IIS + iisnode | `web.config` `<handlers>` entry |
| Docker | `Dockerfile` in sidecar directory |

Record the process manager; modernization target choice depends
on it.

## Deployment Risk Factors

- Node version installed at deploy time must match `engines.node`.
- `npm install` runs at deploy; internet or private-registry access
  required.
- Secrets injection at startup (from Windows Credential Manager,
  AWS Secrets Manager, Azure Key Vault).
- Graceful shutdown handling (SIGTERM) — without it, in-flight
  auth requests are lost on restart.
- Clustered mode: request sticking may be required if the sidecar
  holds session state (rare for JWT but possible).
