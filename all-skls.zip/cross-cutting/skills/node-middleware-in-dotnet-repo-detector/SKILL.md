---
name: node-middleware-in-dotnet-repo-detector
description: >
  Detect Node.js middleware components embedded in predominantly-.NET
  repositories — a polyglot pattern where a legacy .NET monolith ships
  a small Node.js sidecar for a specific concern like JWT token issuance,
  JWT verification, or API gateway middleware. IACRA ships `IACRANodeApi`
  (Node.js JWT auth middleware) alongside its .NET WebForms monolith.
  These sidecars are easy to miss during .NET-centric discovery because
  they have their own `package.json`, their own build tooling, and their
  own runtime — and they are typically wired into the .NET app via
  HTTP callback, reverse-proxy, or IIS URL rewrite. Modernization must
  preserve OR consolidate the sidecar; forgetting it breaks auth
  entirely. Runs as a Discovery conditional skill when the repo contains
  a `package.json` in a sub-directory AND the primary language is
  `csharp`/`vbnet`/`dotnet`. Triggers on polyglot detection, Node.js
  sidecar discovery, JWT middleware analysis, IIS URL-rewrite auth
  pattern, or @node-middleware-in-dotnet-repo-detector.
agent: sonnet
allowed-tools:
  - Read
  - Write
  - Grep
  - Glob
validation_commands:
  - "python -m olympus.validators.schema_validator node-sidecar-inventory.json"
  - "python -m olympus.validators.schema_validator node-dotnet-integration-findings.json"
  - "python -m olympus.validators.schema_validator node-sidecar-modernization-findings.json"
supported_stacks:
  - nodejs
  - node
  - npm
  - express
  - jwt
  - jose
  - passport
  - csharp
  - aspnet
  - aspnet-webforms
anti_target_stacks:
  - deno
  - bun
  - pure-dotnet
  - static-site
failure_classes:
  - node-sidecar-treated-as-unrelated-project
  - jwt-secret-hardcoded-in-sidecar
  - dotnet-to-node-wire-protocol-unresolved
  - iis-url-rewrite-rule-not-captured
  - sidecar-version-pin-missed
  - npm-audit-vulnerabilities-uninventoried
benchmark_tags:
  - discovery-polyglot
  - node-sidecar-detection
  - jwt-middleware-inventory
  - cross-runtime-integration
---

# node-middleware-in-dotnet-repo-detector

## Purpose
Surface Node.js sidecars in .NET-predominant repos as first-class
Discovery artifacts. Modernization teams often miss these because
the sidecar is small (<1% of LOC), has its own tooling, and runs
as a separate process. Missing the sidecar silently breaks auth,
rate-limiting, or API-gateway behavior after cutover.

## Inputs
- Repository with a primary `.NET` stack and one or more
  `package.json` files in sub-directories (not at repo root).
- Application catalog entry from `catalog-application` with
  `primary_language in {csharp, vbnet, dotnet}`.
- IIS config files (`web.config` root + sub-directory), URL
  rewrite rules.
- Optional: `pm2.config.js`, `ecosystem.config.js` (process
  managers for Node sidecars).

## Outputs
- `node-sidecar-inventory.json` — per sidecar: `{sidecar_name,
  path, package_json_path, node_version_pin, main_entry,
  dependencies[] (name, version), devDependencies[], npm_scripts,
  framework (express | fastify | koa | hapi | nest | bare_http),
  exposed_routes[]}`.
- `node-dotnet-integration-findings.json` — per integration
  point: `{finding_type (iis_url_rewrite | reverse_proxy |
  http_callback | process_launch | cron_trigger), sidecar,
  dotnet_integration_file_line, protocol (http | https | ipc |
  stdio), port}`.
- `node-sidecar-modernization-findings.json` — per sidecar:
  `{sidecar, modernization_options[] (port_to_dotnet |
  deploy_as_container | deploy_as_lambda | merge_into_dotnet_auth),
  effort_estimate_hours, risk_factors[]}`.

## Methodology
1. **Find `package.json` files outside the repo root.** A root
   `package.json` in a .NET repo usually means "this is a Node
   project" (not a sidecar); a sub-directory `package.json`
   alongside `.csproj` files signals a sidecar.
2. **Classify sidecar framework.** Read `package.json`
   dependencies: `express`, `fastify`, `koa`, `hapi`, `@nestjs/*`,
   or bare `http.createServer`. Frameworkless sidecars are rare
   but exist.
3. **Extract routes / endpoints.** For Express: `app.get/post/use`
   calls; for Fastify: `fastify.route({...})`; for Nest:
   `@Controller` + `@Get`/`@Post` decorators.
4. **Find .NET-to-Node integration points.**
   - IIS URL rewrite (`web.config` `<rewrite><rules>`) — common
     pattern for ASP.NET Web Forms calling a Node JWT endpoint.
   - Reverse proxy (`app.UseHttpForwarder()`, YARP config) in
     ASP.NET Core.
   - Direct `HttpClient` calls from .NET to `http://localhost:<port>`.
   - Process launch (`Process.Start("node", "path/to/script.js")`)
     — sidecar launched by the .NET app at startup.
   - Sidecar runs as separate Windows Service via `node.exe` +
     pm2-windows-service.
5. **Detect JWT / auth patterns.** Libraries
   (`jsonwebtoken`, `jose`, `passport`, `passport-jwt`,
   `express-jwt`, `@auth0/*`); endpoint names
   (`/token`, `/verify`, `/refresh`, `/login`, `/auth/*`).
6. **Detect secrets.** JWT signing keys, API keys, OAuth client
   secrets. Redact values; emit locations.
7. **Emit all three manifests with `{repo}:{file}:{line}`.**

## Tech-Stack Dispatch

| Trigger | Reference loaded |
|---|---|
| Any `package.json` in sub-dir alongside `.csproj` | `references/node-sidecar-integration-patterns.md` |

## Gotchas
- **Sub-directory `package.json` != root `package.json`.** Root
  means the whole repo is Node; sub-dir means sidecar.
- **IACRA's `IACRANodeApi`** is Node.js JWT auth middleware
  inside an otherwise-.NET monolith. The .NET WebForms app calls
  the Node API for token issuance via IIS URL-rewrite rules.
  Without the rewrite rule, auth fails.
- **Node version pin matters.** `package.json` `engines.node`,
  `.nvmrc`, `.node-version` files. If not pinned, "whatever's
  installed" — fragile.
- **Sidecar secrets live outside source.** JWT signing keys in
  `.env`, `ecosystem.config.js`, Windows Credential Manager.
  Flag locations.
- **IIS hosts Node via `iisnode` module.** `web.config` `<handlers>
  <add name="iisnode" path="*.js" />` delegates `.js` requests to
  Node.exe. Detect.
- **Reverse proxy vs URL rewrite are different patterns.** URL
  rewrite stays client-visible (browser sees path); reverse proxy
  is transparent. Impacts CORS, cookies, redirects.
- **`package-lock.json` missing.** Reproducible builds require
  the lockfile; sidecars without it are fragile.
- **Sidecar can outlive modernization.** An IIS-URL-rewrite JWT
  sidecar can be ported to a .NET Core middleware in the target;
  missing the detection step preserves the sidecar unnecessarily.
- **Polyglot deploy complexity.** Deployments must install Node,
  run `npm install`, start the sidecar — a failure at any step
  kills auth.
- **`npm audit` vulnerabilities accumulate silently.** Sidecars
  rarely get attention; flag high / critical audit warnings as
  security findings.
- **`pm2`, `forever`, `nodemon` process managers.** Each has
  different startup semantics and log destinations.

## Quality Rules
- [ ] Every sub-directory `package.json` has a sidecar inventory
      entry.
- [ ] Node version pin is captured (or `unpinned` finding).
- [ ] Dependencies, devDependencies, npm_scripts captured.
- [ ] Integration points (IIS rewrite, reverse proxy, HttpClient,
      process launch) resolved and cited.
- [ ] Exposed routes enumerated.
- [ ] Secrets redacted; locations preserved.
- [ ] Modernization options per sidecar with effort estimate.
- [ ] Every record carries `{repo}:{file}:{line}`.

## Common Failure Modes

| Failure Mode | Symptom | Prevention |
|---|---|---|
| Sidecar ignored as "unrelated project" | Discovery marks .NET app Rearchitect; sidecar left orphaned | Detect sub-dir package.json alongside csproj as sidecar |
| JWT signing key in package.json | Secrets leaked if manifest includes full package.json | Scan for known secret patterns; redact |
| IIS URL rewrite rule missed | Modernized .NET app has no Node; auth calls 404 | Parse web.config `<rewrite><rules>` |
| Sidecar Node version left unpinned | "Works on my machine" drift | Require engines.node or .nvmrc entry |
| npm audit vulnerabilities uninventoried | Known CVEs ship to prod | Emit audit summary per sidecar |

## Handoff Summary
When this skill completes, verify:
1. Every sub-directory `package.json` has a sidecar inventory
   entry with framework + routes + dependencies.
2. .NET-to-Node integration is resolved per sidecar.
3. Secrets are redacted; locations preserved.
4. Modernization options and effort estimates per sidecar.

Then proceed to: `identity-landscape-analyzer` — if the sidecar
handles auth, consolidate into the app's overall identity
inventory; `migration-strategy-advisor` — plan port-vs-preserve
for each sidecar; `tco-analyzer` — cost of preserving polyglot
deploy vs consolidating.

## References
- `references/node-sidecar-integration-patterns.md` — sidecar
  integration mechanics (IIS URL rewrite, reverse proxy,
  HttpClient, process launch, iisnode), sidecar frameworks
  (Express / Fastify / Nest), auth library catalog, process
  managers.

## Changelog
- 0.1.0 (2026-05-07) — Initial skill. Authored as ATLAS-R-18.
