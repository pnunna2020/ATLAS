---
name: escalation-handler
description: >
  Handle factory escalation when G-04c (code generation gate) fails after max Ralph Loop iterations. Walk through the three escalation paths: re-extract, manual augment, or re-disposition. Triggers on escalation, Ralph Loop failure, G-04c failure, or generation failure.
agent: sonnet
---

# Factory Escalation Handler
## Purpose
When TDD generation fails after 10 Ralph Loop iterations, this skill guides
the team through the decision tree for escalation.

## Escalation Paths
### Path A: Re-Extract (back to P4.1)
- When: Extraction quality was the root cause (specs were incomplete/incorrect)
- Action: Return to P4.1 with focused SME interviews on the failing module
- Timeline impact: +1-2 weeks

### Path B: Manual Augment
- When: AI-generated code is 80%+ correct but specific edge cases fail
- Action: Human developer fixes the specific failing modules, AI continues rest
- Timeline impact: +3-5 days

### Path C: Re-Disposition (back to P1.2)
- When: The application is fundamentally unsuitable for AI-driven modernization
- Action: Change disposition to Replatform (P4-R.4) or Retain (P4-R.2)
- Timeline impact: Significant — removes from current wave, re-sequences

## Workflow
1. Analyze the G-04c failure report (which tests failed, why)
2. Classify the failure root cause using decision tree
3. Recommend escalation path with justification
4. Log the escalation in Factory Configuration Registry (feeds P7.1 pattern learning)
5. Update wave status report with impact

## Gotchas
- **Don't default to Path C too quickly**: Re-disposition is expensive (delays
  modernization by potentially years). Exhaust Path A and B first.
- **Log EVERYTHING for P7.1**: Every escalation is a learning opportunity. The
  failure pattern feeds the anti-pattern catalog and may prevent future failures.
- **Notify the Wave Ops Coordinator**: Escalation may affect concurrent wave
  capacity and require resource reallocation.

## Quality Rules
- [ ] G-04c failure report is analyzed before selecting an escalation path — no path selection without root cause analysis
- [ ] Escalation path is justified with specific failure evidence (which tests failed, why)
- [ ] Path A and Path B are exhausted before Path C (re-disposition) is considered
- [ ] Every escalation is logged in the Factory Configuration Registry for P7.1 pattern learning
- [ ] Wave status report is updated with timeline impact of the escalation
- [ ] Wave Ops Coordinator is notified of any escalation that affects concurrent wave capacity

## Common Failure Modes
| Failure Mode | Symptom | Prevention |
|-------------|---------|------------|
| Premature re-disposition | App sent back to P1.2 when the issue was fixable with re-extraction or manual augment | Require evidence that Path A and B were considered/attempted before allowing Path C |
| Escalation not logged | Same failure pattern recurs across waves because the escalation was not captured for learning | Log every escalation in the Factory Configuration Registry immediately upon decision |
| Timeline impact not communicated | Escalation delays cascade to dependent apps in the wave; stakeholders surprised by delays | Update wave status report and notify Wave Ops Coordinator as part of the escalation workflow |
| Root cause misidentified | Escalation follows Path A (re-extract) but the real issue is spec quality, not extraction completeness | Analyze G-04c failure report thoroughly; categorize failures before selecting path |

## Handoff Summary
When this skill completes, verify:
1. Escalation path is selected with documented justification and root cause evidence
2. Escalation is logged in the Factory Configuration Registry
3. Wave status report reflects the timeline impact
4. Wave Ops Coordinator is notified
Then proceed to: Path A returns to `extraction` (P4.1), Path B engages human developers, Path C returns to `disposition-recommender` (P1.2)
