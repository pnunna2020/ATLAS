# Section 508 / WCAG 2.1 AA Audit Report

## Application: {{APP_NAME}}
## URL/File: {{TARGET}}
## Date: {{DATE}}
## Tool: axe-core + manual review

---

## Summary
| Impact Level | Count |
|-------------|-------|
| Critical | {{CRITICAL}} |
| Serious | {{SERIOUS}} |
| Moderate | {{MODERATE}} |
| Minor | {{MINOR}} |
| **Gate Decision** | **{{PASS_FAIL}}** |

## Violations
{{#each VIOLATIONS}}
### {{IMPACT}}: {{RULE_ID}} — {{DESCRIPTION}}
- WCAG Criteria: {{WCAG_TAGS}}
- Elements affected: {{COUNT}}
- Fix: {{REMEDIATION}}
{{/each}}

## Manual Review Required
- [ ] Logical reading order verified
- [ ] Alt text quality reviewed (meaningful, not just present)
- [ ] Keyboard navigation tested end-to-end
- [ ] Screen reader tested (NVDA/JAWS)
- [ ] Color not used as sole information carrier
