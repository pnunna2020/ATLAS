---
name: accessibility-checker
description: >
  Run automated WCAG 2.1 AA and Section 508 accessibility audits on generated
  UI code. Use during P5.3 validation, P4.2 design review, or any time
  generated HTML/React needs accessibility verification. Triggers on 508 audit,
  WCAG check, accessibility validation, or a11y mentions.
agent: sonnet
allowed-tools:
  - Read
  - Write
  - Bash
---

# Accessibility Verification (508 / WCAG 2.1 AA)

## Purpose
Every FAA modernized application must meet WCAG 2.1 AA. This skill runs
automated checks and generates structured audit reports.

## Workflow
1. Run `scripts/run_axe_audit.sh` on the target HTML/URL
2. Parse results and categorize by WCAG criterion
3. For each violation, generate remediation guidance
4. Produce audit report using `assets/508-audit-report-template.md`
5. Return PASS (0 violations), WARN (minor), or FAIL (critical violations)

## Gotchas
- **Automated tools catch ~30-40% of issues**: axe-core is good but cannot
  test for logical reading order, meaningful alt text quality, or cognitive
  accessibility. Flag that manual review is still needed.
- **Dynamic content needs re-checking**: SPAs with client-side rendering may
  pass initial audit but fail after user interaction. Test multiple states.
- **Color contrast on FAA charts/graphs**: Data visualizations often fail
  contrast requirements. Ensure all chart elements meet 3:1 minimum.
- **Form validation messages**: Error messages must be programmatically
  associated with their input fields via aria-describedby, not just
  visually adjacent.
- **Keyboard focus management in modals**: Opening a modal must trap focus
  inside it. Closing must return focus to the trigger element. React portals
  make this easy to get wrong.

## Reference Files
- `references/common-violations-fixes.md` — Top 20 violations with fixes

## Quality Rules
- [ ] Automated axe-core audit returns zero CRITICAL violations before the skill marks PASS
- [ ] Audit covers all distinct page states (initial load, after user interaction, modal open, error state)
- [ ] Color contrast meets 3:1 minimum for all UI elements including data visualizations and charts
- [ ] All form error messages are programmatically associated with input fields via aria-describedby
- [ ] Keyboard focus management verified: modals trap focus, closing returns focus to trigger element
- [ ] Audit report explicitly notes that automated tools cover ~30-40% of issues and manual review is required
- [ ] Remediation guidance is provided for every violation, not just a pass/fail flag

## Common Failure Modes
| Failure Mode | Symptom | Prevention |
|-------------|---------|------------|
| Initial-state-only audit | SPA passes audit on load but fails after user interaction triggers dynamic content | Test multiple page states: initial, post-interaction, modal, error, and loading states |
| Chart contrast failure | Data visualizations use colors that fail 3:1 contrast ratio; color-blind users cannot read charts | Test all chart/graph elements separately; use patterns or labels in addition to color |
| Missing focus management | Keyboard users get trapped in modals or lose focus position after modal closes | Test tab order and focus management for every modal and overlay component |
| Automated-only confidence | Team treats axe-core PASS as full 508 compliance; manual-only issues ship to production | Always flag that automated audit is partial; require manual review for logical reading order and alt text quality |

## Handoff Summary
When this skill completes, verify:
1. Zero CRITICAL violations in automated audit
2. All page states tested (not just initial load)
3. Audit report includes manual review recommendation
4. Remediation guidance provided for all WARN/MINOR items
Then proceed to: gate `G-V3` for accessibility compliance sign-off, and `deploy-modernized-app` (P6.1) after all validations pass
