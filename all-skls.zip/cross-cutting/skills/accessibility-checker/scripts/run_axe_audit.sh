#!/bin/bash
# Run comprehensive axe-core audit
# Usage: ./run_axe_audit.sh <html_file_or_url> [output_file]
TARGET="$1"
OUTPUT="${2:-axe-results.json}"

if ! command -v axe &> /dev/null; then
    npm install -g @axe-core/cli 2>/dev/null || {
        echo '{"error": "axe-core not available, install with: npm install -g @axe-core/cli"}'
        exit 1
    }
fi

axe "$TARGET" \
    --tags wcag2a,wcag2aa,wcag21aa,section508 \
    --reporter json \
    --save "$OUTPUT" 2>/dev/null

echo "Results saved to $OUTPUT"
cat "$OUTPUT" | python3 -c "
import sys,json
data=json.load(sys.stdin)
violations=data.get('violations',[])
print(json.dumps({
    'total_violations': len(violations),
    'critical': sum(1 for v in violations if v.get('impact')=='critical'),
    'serious': sum(1 for v in violations if v.get('impact')=='serious'),
    'moderate': sum(1 for v in violations if v.get('impact')=='moderate'),
    'minor': sum(1 for v in violations if v.get('impact')=='minor'),
    'gate_decision': 'FAIL' if any(v.get('impact') in ['critical','serious'] for v in violations) else 'PASS'
}, indent=2))
" 2>/dev/null || echo '{"note": "Install python3 for summary"}'
