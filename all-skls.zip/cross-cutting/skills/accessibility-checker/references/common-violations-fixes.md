# Top 20 WCAG Violations & Fixes

## 1. Missing alt text (1.1.1)
Fix: `<img alt="Description of image content">`
NOT: `<img alt="image">` or `<img alt="photo">`

## 2. Insufficient color contrast (1.4.3)
Fix: Use FAA design system colors (all pre-validated for contrast)
Tool: Check with `scripts/check_contrast.py`

## 3. Missing form labels (3.3.2)
Fix: `<label for="inputId">Label Text</label><input id="inputId">`
NOT: Placeholder text as the only label

## 4. Missing language attribute (3.1.1)
Fix: `<html lang="en">`

## 5. Missing skip navigation (2.4.1)
Fix: First focusable element: `<a href="#main" class="skip-link">Skip to main content</a>`

## 6. Empty link text (2.4.4)
Fix: `<a href="...">Descriptive text</a>` or `<a href="..." aria-label="Description">`
NOT: `<a href="..."><img src="icon.png"></a>` without alt

## 7. Missing table headers (1.3.1)
Fix: Use `<th scope="col">` and `<th scope="row">` appropriately

## 8. Non-descriptive page title (2.4.2)
Fix: `<title>Flight Schedule - FAA ATLAS</title>`
NOT: `<title>Page</title>`

## 9. Keyboard trap (2.1.2)
Fix: Ensure Tab/Shift+Tab can exit any focused region
Test: Tab through entire page without using mouse

## 10. Missing focus indicator (2.4.7)
Fix: Never use `outline: none` without providing alternative focus style
