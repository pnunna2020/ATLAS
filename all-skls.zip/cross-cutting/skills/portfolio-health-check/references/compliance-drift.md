# Compliance Drift

**Severity:** Critical
**Detection cadence:** Daily scan; real-time on CVE feed updates.

Degradation of an app's authorization or security posture. Treated as Critical by default — a lapsed ATO or a Critical CVE creates legal, operational, and reputational exposure within hours.

## Signals

### Certification expiry
- **ATO dates**: track issuance, renewal, continuous-monitoring checkpoints. Warning 90 days before expiry, alert at 30, Critical at 7.
- **FedRAMP High continuous monitoring**: verify monthly ConMon reports are submitted on schedule; detect gaps in scan cadence, POA&M updates, annual assessments.
- **508 / accessibility attestations**: re-run after every release; treat regression as compliance drift.

### POA&M aging
Every open POA&M has an age and scheduled closure date.
- **Heuristic:** flag High/Critical POA&M older than 30 days, Moderate older than 90 days.
- **Feed into the Health Index** — aging POA&Ms are a leading indicator of ATO risk.

### CVE aggregation
- Aggregate Critical/High CVEs from SCA (Dependabot, Snyk) and container scans (Trivy, ECR).
- **Heuristic:** any Critical CVE on a production dependency triggers immediate investigation.
- Track mean time to remediate; rising MTTR is a drift signal.

### FIPS 140-3 crypto compliance
- Verify TLS libraries, KMS keys, hashing primitives are FIPS-validated.
- **Heuristic:** inventory crypto modules quarterly; flag any non-validated library in a FedRAMP-scoped app.

## Escalation protocol
1. Critical finding written to the compliance drift log and paged to the compliance lead within 15 minutes.
2. Within 24 hours: triage, containment plan, POA&M entry if not remediable immediately.
3. Never deferred to the quarterly report — that is the defining property of Critical severity.
4. If ATO is at risk of lapse, the app is moved to `incident-response` skill handoff and the AO is notified.
