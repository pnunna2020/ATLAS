# Cost Drift

**Severity:** Low-Medium
**Detection cadence:** Daily (anomaly); monthly (variance); quarterly (efficiency).

Divergence between an app's budgeted run-rate and actual spend. Degrades modernization ROI and, if ignored, erodes the cost-savings case that justified the Replatform or Rearchitect disposition.

## Signals

### Budget variance
- Track monthly actual vs. budgeted spend per app (tags: `app-id`, `env`, `disposition`).
- **Heuristic:** variance >10% = Low drift; >25% = Medium; >50% = High + investigation.
- Variance is computed against the post-modernization TCO baseline, not the legacy cost.

### Cost-anomaly detection (AWS patterns)
- Integrate AWS Cost Anomaly Detection with monitors scoped by `app-id` tag.
- Route findings to SNS → Health Index ingestion topic; de-dupe within a 24-hour window.
- **Heuristic:** any anomaly ≥ $500/day or ≥ 20% of run-rate generates a drift record.
- Tune sensitivity per app: noisy low-spend apps get HIGH threshold; steady high-spend apps get LOW.

### Cost-per-user trend (efficiency)
- Compute `monthly_cost / MAU` for each user-facing app.
- **Heuristic:** cost-per-user rising 2 consecutive months while MAU is flat or declining = drift. Usually indicates orphaned resources, over-provisioning, or autoscaling mis-tuning.
- Especially useful for applicant-facing apps where MAU is a stable business metric.

## Common drivers (triage hints)
- Reserved Instance / Savings Plan expired and reverted to on-demand.
- Storage class drift (S3 objects not transitioning to IA/Glacier).
- Forgotten non-prod environments running 24/7.
- Autoscaling floor set too high after a load test.

## Output contract
Each finding: app ID, driver category, current run-rate, baseline, variance %, anomaly source, recommended action (rightsize | reserve | decommission | tag-cleanup), severity, owner.
