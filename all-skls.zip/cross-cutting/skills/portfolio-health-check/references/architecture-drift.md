# Architecture Drift

**Severity:** Medium
**Detection cadence:** Weekly automated scan; deep-scan quarterly.

Divergence between the approved target architecture (EA repo, Rearchitect artifacts) and the actual runtime topology. Undetected drift invalidates compliance boundaries, breaks dependency assumptions, and silently defeats the modernization investment.

## Sub-categories

### 1. Infrastructure drift
Runtime infrastructure no longer matches declared IaC.
- **Heuristic:** `terraform plan` / `cfn drift-detection` reports non-zero changes vs. last-applied state.
- **Signal:** out-of-band console edits, manual scaling overrides, orphaned resources.
- **Action:** capture delta, open remediation ticket, reconcile IaC or roll back.

### 2. Topology drift
New services, sidecars, or endpoints appear without being registered in the architecture registry.
- **Heuristic:** compare live service-mesh registry (Consul, Istio, App Mesh) against the declared topology.
- **Signal:** services on unexpected ports, new ingress rules, undocumented inter-service calls.
- **Action:** flag unregistered services; require architect review before they stay.

### 3. Dependency drift
App now consumes services, APIs, or data stores not in the approved design.
- **Heuristic:** diff runtime egress logs (VPC flow, API gateway) against the declared dependency list.
- **Signal:** calls to new SaaS, new databases, cross-account traffic.
- **Action:** evaluate security, data-residency, cost; require ATO supplement if the new dependency crosses a compliance boundary.

## Output contract
Each finding: app ID, category, severity, first-seen, diff artifact link, recommended disposition (reconcile | approve | roll back), owner.

## Escalation
Medium by default. Escalate to Critical if drift crosses an ATO boundary, touches FedRAMP-scoped infrastructure, or introduces an unapproved data store.
