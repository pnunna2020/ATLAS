# Performance Drift

**Severity:** Medium
**Detection cadence:** Continuous (streaming); weekly summary for Health Index.

Gradual degradation of an app's latency, throughput, or reliability against its baseline SLOs. Modernized apps drift most — new dependencies, cold starts, and autoscaling mis-tuning are common causes.

## Signals

### SLA-breach trends
- Track rolling 7-day and 30-day breach rate against each declared SLO.
- **Heuristic:** breach rate rising for 3 consecutive weeks is a drift signal even if no single week exceeds the target.

### p95 / p99 latency regression
- Compare current p95 and p99 against the baseline captured at deployment.
- **Heuristic:** p95 up >15% from baseline, or p99 up >25%, sustained over a 7-day window.
- p99 matters more than mean — tail latency is where user pain lives.

### Error-rate regression
- Track HTTP 5xx rate, application error rate (structured logs), and dependency-call failure rate separately.
- **Heuristic:** error rate >2x baseline sustained 1 hour, or >1.25x sustained 24 hours.

## Threshold tuning (avoid false positives)

- **Relative baselines, not absolute thresholds.** A 50ms-baseline app and a 500ms-baseline app need different alerts.
- **Suppress during known events**: deployments, load tests, autoscale-in. Tag windows in the metrics store so they are excluded from drift calc.
- **Require sustained breach.** Single spikes are noise; drift requires ≥3 data points or 24 hours.
- **Seasonality:** week-over-week beats day-over-day for apps with strong daily patterns (e.g., applicant portal weekday peaks).
- **Confirm with a second signal** before paging — latency drift should correlate with error-rate or dependency-latency drift.

## Output contract
Each finding: app ID, metric, baseline, current, delta %, window, confirming secondary signal, severity (Low <15% p95; Medium 15-30%; High >30% or sustained SLA breach).
