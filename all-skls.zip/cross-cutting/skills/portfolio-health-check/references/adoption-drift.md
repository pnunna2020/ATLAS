# Adoption Drift

**Severity:** Low
**Detection cadence:** Monthly; quarterly deep review.

Whether the modernized app is actually used by its target audience at the rate projected in the business case. Low by default, but chronic drift invalidates the modernization ROI story and must escalate if sustained.

## Signals

### User-adoption rate (post-modernization)
- Baseline: the adoption curve from Rearchitect/Replatform planning (e.g., 80% of legacy users migrated within 90 days).
- **Heuristic:** adoption flatlines or trails the plan by >20% at any milestone.
- Source: IdP sign-in logs, session events, API-key usage for programmatic users.

### Training-completion rates
- Track completion of mandatory training for the new system by cohort.
- **Heuristic:** <70% completion 30 days after go-live, or completion declining across cohorts.
- Low completion is a leading indicator of low sustained adoption and support-ticket spikes.

### Feature-usage telemetry
- Instrument major features; track weekly active users per feature.
- **Heuristic:** a feature with <5% WAU of the app's overall WAU is a candidate for removal or redesign.
- Flags "dark features" — shipped but unused — that inflate maintenance cost for zero value.

### Applicant-portal MAU (FAA-specific)
- MAU of the applicant portal is the canonical adoption KPI for FAA public-facing apps.
- **Heuristic:** MAU decline >10% MoM for 2 consecutive months without a known business cause.
- Cross-reference with support-ticket volume: rising tickets + falling MAU = usability regression.

## Escalation
Low by default. Escalate to Medium if:
- Sustained (>2 quarters) adoption below 50% of plan.
- Adoption drift co-occurs with performance drift (users leaving because the app is slow).
- Business case ROI is materially at risk.

## Output contract
Each finding: app ID, metric, plan, actual, variance, window, correlated signals, recommended action (training | UX review | feature retire | business case refresh).
