# Portfolio Health Index — Weighting

The Portfolio Health Index (PHI) is a composite score (0-100) per app and per portfolio, derived from the five drift categories. It is NOT an average — security and compliance are weighted higher because their failures are higher-impact and lower-latency than cost or adoption.

## Default weights

| Category      | Weight | Rationale |
|---------------|-------:|-----------|
| Compliance    |   30%  | ATO lapse, Critical CVEs, FIPS breaches are existential. |
| Security*     |   30%  | Runtime security posture (separate from certification). |
| Performance   |   20%  | User-visible; correlates with SLA credits and adoption. |
| Cost          |   10%  | Recoverable; rarely urgent. |
| Adoption      |   10%  | Slow-moving; low volatility. |

\* If a profile merges Security and Compliance, combine to 60% and keep others unchanged. Weights must sum to 100.

## Re-weighting per client profile

Profiles override defaults in `profile.yaml`:

```yaml
portfolio_health_index:
  weights:
    compliance: 35
    security: 35
    performance: 15
    cost: 10
    adoption: 5
```

Guidance:
- **FAA / high-assurance:** compliance 35-40%, adoption 5%.
- **Internal tools:** compliance 20%, adoption 20%.
- **Cost-optimization:** cost 20%, adoption 5%.

Reweighting is auditable and must be recorded in the governance log.

## Computation from per-category severity counts

For each category, compute a category score (0-100):

```
category_score = 100
              - (critical_count * 25)
              - (high_count     * 10)
              - (medium_count   * 4)
              - (low_count      * 1)
```

Floor at 0. Then:

```
PHI = sum(category_score * weight / 100)  over all categories
```

POA&M age feeds `compliance` counts: any High/Critical POA&M >30 days counts as an added High; Moderate >90 days counts as a Medium. Aging POA&Ms must visibly degrade PHI.

## Bands
≥90 Healthy; 75-89 Watch; 60-74 At Risk; <60 Critical (governance review).
