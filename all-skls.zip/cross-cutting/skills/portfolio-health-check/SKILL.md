---
name: portfolio-health-check
description: >
  Conduct automated health assessments of the entire portfolio, detecting drift,
  compliance degradation, and cost trends. Used in Governance line for continuous
  monitoring. Triggers on portfolio health, governance scan, drift detection, or
  quarterly review.
agent: sonnet
allowed-tools:
  - Read
  - Write
  - Bash
  - Grep
---

# Portfolio Health Check

## Purpose
Assess the health of the entire modernization portfolio on a continuous basis,
producing health reports, drift alerts, and trend analysis for governance review.

## Inputs
- Production metrics (performance, availability, cost) for all apps
- Security scan results and CVE feeds
- Accessibility compliance scores
- Disposition progress tracking data
- Compliance certification status and expiry dates
- Cost data pre- and post-modernization

## Outputs
- Portfolio Health Report (Markdown, quarterly deep-scan + continuous monitoring)
- Drift alerts by category (Architecture, Compliance, Performance, Cost, Adoption)
- Compliance Posture Report
- Disposition Progress Report
- Cost Savings Dashboard data

## Methodology
1. Re-run quality metrics on retained and modernized applications
2. Aggregate security vulnerability status across portfolio
3. Check compliance certification currency (expiry dates, re-assessment needs)
4. Re-scan modernized apps for 508/accessibility regression
5. Track disposition progress against timelines
6. Compare pre/post TCO across completed dispositions
7. Compute Portfolio Health Index (composite score)

## Drift Categories
Each category has a dedicated reference with detection heuristics, thresholds, and escalation. Every drift category MUST be monitored per its reference.

| Category | Detection | Severity | Reference |
|----------|-----------|----------|-----------|
| Architecture | EA compliance re-scan (infra/topology/dependency) | Medium | `references/architecture-drift.md` |
| Compliance | ATO expiry, FedRAMP ConMon, POA&M aging, CVEs, FIPS | Critical | `references/compliance-drift.md` |
| Performance | SLA breach trends, p95/p99 latency, error-rate regression | Medium | `references/performance-drift.md` |
| Cost | Budget variance, AWS Cost Anomaly Detection, cost/user | Low-Medium | `references/cost-drift.md` |
| Adoption | User adoption rates, training, feature usage, MAU | Low | `references/adoption-drift.md` |

## Portfolio Health Index
Composite score weighted per `references/health-index-weighting.md`. Default weights: Compliance 30%, Security 30%, Performance 20%, Cost 10%, Adoption 10% — overridable in the client profile. Computed from per-category severity counts; aging POA&Ms feed into the compliance count.

## Report Template
Use `assets/portfolio-health-report-template.md` for the quarterly Portfolio Health Report.

## Gotchas
- **Critical drift (security/compliance) triggers immediate investigation**:
  Don't wait for the quarterly report. Alert operations and compliance leads.
- **Health Index is a composite, not an average**: Weight security and compliance
  higher than cost or adoption metrics.
- **Retained apps drift too**: Apps with "Retain" disposition still need health
  monitoring. They're in the portfolio until explicitly removed.

## Quality Rules
- [ ] Health check covers ALL apps in the portfolio — retained apps are included in scope, not just modernized
- [ ] Every drift category (Architecture, Compliance, Performance, Cost, Adoption) is monitored per its corresponding reference in `references/`
- [ ] Composite Portfolio Health Index uses the weights cited in `references/health-index-weighting.md` (defaults: Compliance 30%, Security 30%, Performance 20%, Cost 10%, Adoption 10%) or the profile override
- [ ] Critical drift (security/compliance) is escalated within 24h — never deferred to the quarterly report
- [ ] POA&M age is included in the compliance drift signal and feeds the Health Index
- [ ] Pre/post-modernization TCO comparison uses actual cost data, not estimates
- [ ] Compliance certification expiry dates are tracked with advance warning before expiration
- [ ] 508/accessibility re-scan is run on all modernized apps, not just newly deployed

## Common Failure Modes
| Failure Mode | Symptom | Prevention |
|-------------|---------|------------|
| Retained apps excluded | Apps with Retain disposition not monitored; drift detected only during next wave planning | Include all portfolio apps regardless of disposition in the health check scope |
| Critical drift deferred | Security vulnerability trend noticed but not acted on until quarterly report; breach window | Trigger immediate investigation for any critical (security/compliance) drift detection |
| Equal-weight Health Index | Cost drift makes Health Index look bad when security posture is actually strong; misleading signal | Weight security and compliance higher in the composite index calculation |
| Stale TCO comparison | Cost savings reported using pre-modernization estimates instead of actual post-deployment costs | Use actual AWS billing data and operational costs for post-modernization TCO |
| POA&M aging tracked but not fed into Health Index | Security posture degrades silently — open High/Critical POA&Ms age past SLA but PHI still reads "Healthy"; next ATO review surfaces a backlog that should have triggered governance action months earlier | Include POA&M age in the compliance drift signal per `references/compliance-drift.md`; High/Critical >30 days adds a High count, Moderate >90 days adds a Medium count, directly degrading the Compliance category score in PHI |

## Handoff Summary
When this skill completes, verify:
1. Portfolio Health Report covers all apps (retained, modernized, and in-progress)
2. Critical drift items have been escalated for immediate investigation
3. Compliance certifications are current or renewal is scheduled
4. Cost Savings Dashboard data reflects actual (not estimated) figures
Then proceed to: Governance review with the Portfolio Health Report, `incident-response` for any critical drift, and `patch-assessment` for vulnerability trends
