---
name: aws-deployment-topology
description: >
  Design deployment infrastructure: container specs, VPC topology, scaling policies,
  environment tiers, CI/CD pipeline, IaC patterns. Use during Architecture (Step 1b).
  Triggers on deployment topology, infrastructure design, container sizing, VPC design, IaC.
agent: sonnet
allowed-tools:
  - Read
  - Write
  - Grep
---

# AWS Deployment Topology

## Purpose
Design the complete deployment infrastructure for a modernized application, from
container sizing through VPC topology to CI/CD pipeline and Infrastructure as Code.
Produces a deployment topology document that infrastructure teams can implement.

## Inputs
- Application archetype (web/batch/API/job/hybrid) from Discovery
- Risk tier (T1/T2/T3) from Risk Classification
- Expected load profile (concurrent users, requests per second, peak patterns)
- Architecture pattern from migration-strategy-advisor (microservices, modular monolith, serverless)
- Resilience requirements from aws-resilience-designer
- Deployment region (GovCloud us-gov-west-1)

## Outputs
- Fargate task sizing (vCPU, memory, port mapping)
- VPC topology diagram (subnets, NAT, endpoints, security groups)
- Auto-scaling policies (target tracking, scheduled, step)
- Environment tier configuration (dev, staging, prod)
- CI/CD pipeline definition (build, test, scan, deploy)
- Terraform module composition (root module structure)
- Deployment topology YAML (from template)

## Methodology

### Step 1: Size Compute Resources
Determine Fargate task CPU and memory based on the application archetype and
expected load profile.

Load `references/fargate-sizing-guide.md` for sizing heuristics.

- Start with the baseline for the archetype (web, API, batch)
- Adjust upward for complex business logic, large payload processing, or in-memory caching
- Adjust downward for simple CRUD or static-serving workloads
- Document the sizing rationale for future right-sizing reviews

### Step 2: Design VPC Topology
Design the network topology using the standard 3-tier VPC pattern for GovCloud.

Load `references/vpc-topology-patterns.md` for patterns.

- Public subnets: ALB only (no direct internet-facing compute)
- Private subnets: Fargate tasks, Lambda functions
- Isolated subnets: Aurora, ElastiCache (no internet route)
- VPC endpoints for AWS service access from private subnets
- Security groups following least-privilege (ALB -> compute -> database)
- NAT Gateway count based on tier (per-AZ for T1/T2, single for T3)

### Step 3: Design Scaling Policies
Configure auto-scaling policies appropriate for the load profile and tier.

- Target tracking: CPU utilization (primary), memory utilization (secondary)
- Scheduled scaling: for known peak patterns (e.g., business hours, end-of-month)
- Step scaling: for sudden load spikes that target tracking handles too slowly
- Scale-out cooldown: 60-120 seconds (fast reaction)
- Scale-in cooldown: 300 seconds (conservative reduction)
- Minimum task count based on tier (T1: 3, T2: 2, T3: 1)

### Step 4: Design Environment Tiers
Define the environment promotion path with appropriate isolation and gating.

- **dev**: auto-deploy on merge to develop branch, minimal resources, single AZ
- **staging**: deploy on release candidate tag, mirrors prod topology at reduced scale, manual promotion gate
- **prod**: deploy on release tag with approval, full resilience configuration, matches tier requirements

Each environment gets its own VPC, its own database instance, and its own
secrets. No cross-environment resource sharing.

### Step 5: Design CI/CD Pipeline
Design the build, test, scan, and deploy pipeline.

Load `references/cicd-pipeline-patterns.md` for patterns.

- Build: multi-stage Dockerfile, non-root user, distroless or slim base image
- Test: unit tests, integration tests, contract tests
- Scan: Trivy (container image), Snyk (dependencies), SAST (code quality)
- Push: ECR image with SHA and semver tags
- Deploy: ECS blue-green (CodeDeploy) or canary per tier
- Gate: manual approval for staging -> prod promotion

### Step 6: Produce IaC Skeleton
Define the Terraform module composition for the application.

Load `references/iac-module-catalog.md` for available modules.

- Root module: environment-specific configuration (dev/staging/prod)
- Child modules: VPC, ECS, Aurora, ALB, CloudFront, monitoring
- State management: S3 backend with DynamoDB locking
- Variable hierarchy: shared defaults -> environment overrides -> secret injection

## Gotchas
- **GovCloud ECR endpoint differs from commercial**: Use the GovCloud-specific
  ECR endpoint (`dkr.ecr.us-gov-west-1.amazonaws.com`).
- **VPC endpoint costs add up**: Each interface endpoint costs ~$7.30/month per AZ.
  Only create endpoints for services the application actually uses.
- **Fargate Spot is not suitable for T1/T2**: Spot tasks can be interrupted with
  2 minutes notice. Only use for T3 non-critical or batch workloads.
- **NAT Gateway is a single point of failure per AZ**: For T1/T2 applications,
  deploy one NAT Gateway per AZ. A single NAT Gateway means an AZ failure
  takes out outbound internet access for all private subnets.
- **Subnet sizing**: /24 provides 251 usable addresses per subnet. For large
  deployments or many Lambda ENIs, consider /22 (1019 usable addresses).

## Quality Rules
- [ ] Fargate task sizing is justified by archetype and load profile, not default values
- [ ] VPC follows 3-tier pattern: public (ALB), private (compute), isolated (database)
- [ ] Security groups follow least-privilege: only necessary ports between specific tiers
- [ ] VPC endpoints are specified for all AWS services accessed from private subnets
- [ ] Scaling policies include minimum task count appropriate for the risk tier
- [ ] Environment tiers have separate VPCs, databases, and secrets (no cross-env sharing)
- [ ] CI/CD pipeline includes security scanning (container + dependency) before deployment
- [ ] IaC uses module composition, not monolithic configuration
- [ ] Deployment strategy matches the risk tier (canary for T1, blue-green for T2/T3)

## Common Failure Modes
| Failure Mode | Symptom | Prevention |
|-------------|---------|------------|
| Oversized containers | Fargate tasks running at 10% CPU utilization; wasted spend | Start with archetype baseline, right-size after 2 weeks of metrics |
| Undersized containers | OOMKilled events, CPU throttling, degraded latency | Monitor utilization, set CloudWatch alarms at 80% utilization |
| Missing VPC endpoints | High NAT Gateway data processing charges; intermittent timeouts | Audit AWS service usage, create gateway/interface endpoints |
| Single NAT Gateway for T1 | AZ failure takes out NAT, breaking outbound connectivity for all tasks | Deploy per-AZ NAT Gateway for T1/T2 applications |
| No auto-scaling | Fixed capacity cannot handle traffic spikes; degraded performance or outage | Configure target tracking scaling on all production services |
| Cross-environment resource sharing | Staging test corrupts production data or exhausts shared database connections | Enforce separate VPCs, databases, and secrets per environment |
| Monolithic Terraform | Small change requires full infrastructure plan; blast radius too large | Use module composition with targeted plan/apply per module |

## Phase 3 — ATLAS ChBA

> **Trace:** Closes P3-R05, P3-R07, P3-R09, P3-R51, P3-R52, P3-R53, P3-R81, P3-R82, P3-R83, P3-R91. Source: `docs/phase3/phase2-commitments.md` §B.3 (compute model, hosting), §C.1 Wave 0 (Tyrion); gap matrix EDIT-2 (B7a in build plan).

### Phase 3 deviation: docker-compose (local) + AWS CDK (AWS)

> **Hard rule:** AWS GovCloud is the Phase 2 commitment. Phase 3 prototype runs on docker-compose locally because the 75-minute oral cannot tolerate a GovCloud-network dependency. BASE-C is **not** a Phase 2 commitment (P2 §H.7) and is **not** the default for this skill's emission.
>
> **Authoritative architecture:** `docs/phase3/local-first-architecture.md` §2 (stack table — CDK, not Terraform) and §3 (`infra/cdk/` repo layout). This skill emits the AWS-side IaC as **AWS CDK v2 in TypeScript**, matching `cross-cutting/skills/local-cloud-adapter-scaffolder/SKILL.md`.

The Phase 3 prototype emits **two parallel deployment manifests**:

| Mode | Purpose | Audience | Output |
|---|---|---|---|
| `--emit-compose` | Live demo on the team's laptop during the oral | Phase 3 evaluators (live screen-share) | `infra/docker-compose.yml` + per-service `Dockerfile` |
| `--emit-cdk` | Production-target IaC, synth/lint-green, runs when AWS GovCloud creds are provided | Phase 4 builders + FAA evaluator (read-only review) | `infra/cdk/bin/app.ts` + `infra/cdk/lib/<stack>.ts` |

Both modes produce **structurally equivalent** topology (same services, same dependencies, same network policies). The compose mode swaps AWS-managed services for local equivalents:

| Production (CDK → AWS GovCloud) | Phase 3 prototype (docker-compose) |
|---|---|
| API Gateway + ALB | Traefik gateway container |
| Lambda (Express via `@vendia/serverless-express`) | Plain Docker container per service running Node 20 + Express + TypeScript |
| Aurora PostgreSQL Serverless v2 | `postgres:15` container |
| S3 | MinIO container |
| KMS | Local OpenSSL CA + key files mounted as Docker secrets |
| Secrets Manager | `.env.local` + dotenv (no real secrets committed) |
| CloudWatch + X-Ray | Loki + Prometheus + Grafana containers |
| EventBridge | Postgres `LISTEN/NOTIFY` + typed Node/TypeScript event handlers behind the `EventBus` adapter |
| Cognito (or Login.gov in production) | Keycloak container (Login.gov-compatible OIDC) |

The `--emit-cdk` output is **provided** in the Phase 3 submission (closes P3-R81 and P3-R91) but **not run live** during the oral. It must synth-green via `cdk synth` and lint via `npx eslint infra/cdk/`.

### CDK stack set (production target)

Generated under `infra/cdk/lib/`, one stack per concern (matches `local-first-architecture.md` §3):

- `lib/vpc-stack.ts` — VPC + 3-tier subnet pattern (public/private/isolated) for AWS GovCloud (us-gov-west-1)
- `lib/api-stack.ts` — Lambda functions (one per S1..S11) + API Gateway + integration with the Express handler entry point (`apps/api/src/http/lambda-handler.ts`)
- `lib/web-stack.ts` — S3 + CloudFront + WAF for the React + USWDS frontend bundle
- `lib/data-stack.ts` — Aurora PostgreSQL Serverless v2 + RDS Proxy + Secrets Manager for credentials
- `lib/events-stack.ts` — EventBridge bus + rules subscribing the Lambda handlers to typed events
- `lib/storage-stack.ts` — S3 buckets for documents, with KMS encryption
- `lib/kms-stack.ts` — KMS keys per bounded context (per P2 §B.3 key hierarchy)
- `lib/observability-stack.ts` — CloudWatch dashboards + alarms + X-Ray tracing config
- `lib/iam-stack.ts` — IAM roles per Lambda with least-privilege policies (no `*:*`)

### docker-compose layout (Phase 3 prototype)

`infra/docker-compose.yml` composes:

- One service container per implemented S1..S11 (S4 + S10 are stubs that return canned responses) running Node 20 + Express + TypeScript
- `traefik` edge gateway with mTLS between containers
- `postgres` (canonical data) + `keycloak-db` (Keycloak's own metadata)
- `keycloak` (OIDC broker)
- `minio` (S3-compatible object store)
- `loki`, `prometheus`, `grafana` (observability stack)
- `opa` sidecar pattern (policy-as-code at gateway and per-service)

### Container assets (P3-R82) — one Dockerfile per service

Emit a Dockerfile per generated service. Conventions:

- Multi-stage: `builder` → `runtime`
- `runtime` is a slim or distroless base (`node:20-slim` for the Express API services; `nginx:alpine` to serve the React build artifacts)
- `USER nonroot` (UID > 1000) — never run as root
- `HEALTHCHECK` pointing at the service's `/healthz` endpoint
- COPY ordered by change frequency (`package.json` and `package-lock.json` before source) to maximize layer cache hits
- No secrets baked in — secrets mount via Docker secrets or env at runtime

### k8s manifests (Phase 4 stub)

A Helm chart at `infra/helm/atlas-phase3/` is provided but not run in Phase 3. It mirrors the docker-compose service set as Kubernetes Deployments + Services + Ingress (with NetworkPolicies enforcing service-mesh isolation per P2 §B.3). Phase 4 promotion is the path: docker-compose → AWS CDK (Lambda + APIGW the default; Helm-on-EKS as an alternative if the FAA prefers containers over Lambda).

### IaC versioning + rollback (closes P3-R51)

- Every CDK stack is versioned via Git tags; CDK context (`cdk.context.json`) and Lambda image digests pin a specific build.
- `infra/cdk/bin/app.ts` tags every stack with `git-sha` and `build-timestamp` so CloudWatch can correlate a deployed version with a commit.
- Rollback playbook: `cdk deploy <StackName> --context imageTag=<previous-sha>` reverts a single service's Lambda image to its prior digest without touching neighbors. Demo this in the oral.
- For docker-compose: image tags are `<svc>:<git-sha>`; rollback = `docker-compose up -d --no-deps <svc>` after pinning the previous tag.

### Migration path to AWS GovCloud (Phase 4)

Documented for the 10-page narrative as DEV-1 / DEV-11 / DEV-19:

1. Stand up Tyrion landing zone (FAA-side activity, gated on A4 confirmation per P2 §C.2).
2. `cdk bootstrap` + `cdk synth` + `cdk deploy` against the GovCloud account; the stack set is unchanged.
3. Lambda function images push to GovCloud ECR via the pipeline's deploy stage; CDK references them by digest.
4. Cut traffic over via API Gateway stages and weighted aliases (handed off to `cross-cutting/skills/traffic-shift`).
5. Decommission the local docker-compose stack.

The CDK stack set is **already** the migration substrate. There is no rewrite — the deviation is "where it runs," not "what it is."

### BASE-C status (explicit non-default)

BASE-C is BAH's RKE2/Rancher accelerator. It is **not** named in any Phase 2 source (P2 §H.7 verified). This skill does not emit BASE-C-specific configuration. If a downstream team chooses to layer the Phase 3 container set onto BASE-C for a build-acceleration reason, that is documented as a Phase 3 implementation deviation (DEV-1 in the gap matrix). It does not change the Phase 4 production target, which remains AWS GovCloud + Tyrion per Phase 2.

### Phase 3 acceptance signals

- [ ] `docker-compose -f infra/docker-compose.yml up` brings the full implemented service set online on a developer laptop in < 5 min.
- [ ] `cd infra/cdk && npx cdk synth` passes on `infra/cdk/`.
- [ ] Every service has a Dockerfile with non-root user + healthcheck.
- [ ] Helm chart at `infra/helm/atlas-phase3/` is generated but unrun (Phase 4 stub).
- [ ] Rollback demo (single-service revert) runs in < 60 s, suitable for the oral.

## Handoff Summary
When this skill completes, verify:
1. Fargate sizing is documented with rationale and right-sizing review plan
2. VPC topology follows 3-tier pattern with appropriate security groups and endpoints
3. Scaling policies cover expected load patterns with tier-appropriate minimums
4. CI/CD pipeline includes build, test, scan, and gated deployment stages
5. Terraform module composition is defined with state management strategy (legacy paths unchanged for non-Phase-3 consumers)
6. **Phase 3:** Both `--emit-compose` (docker-compose) and `--emit-cdk` (AWS CDK v2 in TypeScript) outputs are produced and structurally equivalent. Source of truth: `docs/phase3/local-first-architecture.md`.
Then proceed to: `ea-compliance` for EA alignment verification, `cost-estimator` for detailed cost projection, and gate `G-02` for architecture review
