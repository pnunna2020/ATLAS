# CI/CD Pipeline Patterns

Reference for aws-deployment-topology when designing build and deployment pipelines.

## Pipeline Overview

All Olympus applications follow a standard pipeline with environment promotion:

```
┌──────┐   ┌──────┐   ┌──────┐   ┌──────────┐   ┌────────┐   ┌────────┐
│ Code │──>│Build │──>│ Test │──>│ Security │──>│  Push  │──>│Deploy  │
│ Push │   │      │   │      │   │   Scan   │   │  ECR   │   │  ECS   │
└──────┘   └──────┘   └──────┘   └──────────┘   └────────┘   └────────┘
                                                                  │
                                                     ┌────────────┼────────────┐
                                                     │            │            │
                                                  ┌──┴──┐    ┌───┴───┐   ┌────┴───┐
                                                  │ Dev │    │Staging│   │  Prod  │
                                                  │Auto │    │Manual │   │Approval│
                                                  └─────┘    └───────┘   └────────┘
```

## GitHub Actions Workflow

### Build and Test

```yaml
name: Build and Deploy
on:
  push:
    branches: [develop, main]
  pull_request:
    branches: [develop, main]

env:
  AWS_REGION: us-gov-west-1
  ECR_REGISTRY: ${{ secrets.ECR_REGISTRY }}
  ECR_REPOSITORY: my-application
  ECS_CLUSTER: my-cluster
  ECS_SERVICE: my-service

jobs:
  build-and-test:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4

      - name: Set up Python
        uses: actions/setup-python@v5
        with:
          python-version: "3.12"
          cache: "pip"

      - name: Install dependencies
        run: pip install -r requirements.txt -r requirements-dev.txt

      - name: Run linting
        run: |
          ruff check .
          ruff format --check .
          mypy src/

      - name: Run unit tests
        run: pytest tests/unit/ --cov=src --cov-report=xml --junitxml=test-results.xml

      - name: Run integration tests
        run: pytest tests/integration/ --junitxml=integration-results.xml
        env:
          DATABASE_URL: postgresql://test:test@localhost:5432/testdb

      - name: Upload test results
        uses: actions/upload-artifact@v4
        if: always()
        with:
          name: test-results
          path: |
            test-results.xml
            integration-results.xml
            coverage.xml

  security-scan:
    runs-on: ubuntu-latest
    needs: build-and-test
    steps:
      - uses: actions/checkout@v4

      - name: Dependency scan (Snyk)
        uses: snyk/actions/python-3.10@master
        env:
          SNYK_TOKEN: ${{ secrets.SNYK_TOKEN }}
        with:
          args: --severity-threshold=high

      - name: SAST scan
        uses: github/codeql-action/analyze@v3
        with:
          languages: python

      - name: Build container image
        run: docker build -t $ECR_REPOSITORY:scan .

      - name: Container image scan (Trivy)
        uses: aquasecurity/trivy-action@master
        with:
          image-ref: "${{ env.ECR_REPOSITORY }}:scan"
          format: "sarif"
          output: "trivy-results.sarif"
          severity: "CRITICAL,HIGH"
          exit-code: "1"

      - name: Upload Trivy results
        uses: github/codeql-action/upload-sarif@v3
        if: always()
        with:
          sarif_file: "trivy-results.sarif"

  push-ecr:
    runs-on: ubuntu-latest
    needs: [build-and-test, security-scan]
    if: github.ref == 'refs/heads/develop' || github.ref == 'refs/heads/main'
    outputs:
      image_tag: ${{ steps.build.outputs.image_tag }}
    steps:
      - uses: actions/checkout@v4

      - name: Configure AWS credentials
        uses: aws-actions/configure-aws-credentials@v4
        with:
          role-to-assume: ${{ secrets.AWS_DEPLOY_ROLE_ARN }}
          aws-region: ${{ env.AWS_REGION }}

      - name: Login to ECR
        uses: aws-actions/amazon-ecr-login@v2

      - name: Build and push image
        id: build
        run: |
          IMAGE_TAG="${{ github.sha }}"
          docker build -t $ECR_REGISTRY/$ECR_REPOSITORY:$IMAGE_TAG .
          docker tag $ECR_REGISTRY/$ECR_REPOSITORY:$IMAGE_TAG $ECR_REGISTRY/$ECR_REPOSITORY:latest
          docker push $ECR_REGISTRY/$ECR_REPOSITORY:$IMAGE_TAG
          docker push $ECR_REGISTRY/$ECR_REPOSITORY:latest
          echo "image_tag=$IMAGE_TAG" >> "$GITHUB_OUTPUT"

  deploy-dev:
    runs-on: ubuntu-latest
    needs: push-ecr
    if: github.ref == 'refs/heads/develop'
    environment: dev
    steps:
      - name: Configure AWS credentials
        uses: aws-actions/configure-aws-credentials@v4
        with:
          role-to-assume: ${{ secrets.AWS_DEV_ROLE_ARN }}
          aws-region: ${{ env.AWS_REGION }}

      - name: Deploy to dev
        run: |
          aws ecs update-service \
            --cluster $ECS_CLUSTER-dev \
            --service $ECS_SERVICE \
            --force-new-deployment \
            --region $AWS_REGION

      - name: Wait for deployment
        run: |
          aws ecs wait services-stable \
            --cluster $ECS_CLUSTER-dev \
            --services $ECS_SERVICE \
            --region $AWS_REGION

      - name: Run smoke tests
        run: |
          curl -f https://dev.app.internal/api/health || exit 1

  deploy-staging:
    runs-on: ubuntu-latest
    needs: push-ecr
    if: github.ref == 'refs/heads/main'
    environment:
      name: staging
      # No auto-deploy; requires manual trigger or release tag
    steps:
      - name: Configure AWS credentials
        uses: aws-actions/configure-aws-credentials@v4
        with:
          role-to-assume: ${{ secrets.AWS_STAGING_ROLE_ARN }}
          aws-region: ${{ env.AWS_REGION }}

      - name: Deploy to staging (blue-green)
        run: |
          aws deploy create-deployment \
            --application-name $ECR_REPOSITORY \
            --deployment-group-name staging \
            --revision '{"revisionType":"AppSpecContent","appSpecContent":{"content":"{\"version\":1,\"Resources\":[{\"TargetService\":{\"Type\":\"AWS::ECS::Service\",\"Properties\":{\"TaskDefinition\":\"arn:aws:ecs:${{ env.AWS_REGION }}:${{ secrets.AWS_ACCOUNT_ID }}:task-definition/${{ env.ECR_REPOSITORY }}\",\"LoadBalancerInfo\":{\"ContainerName\":\"app\",\"ContainerPort\":8000}}}}]}"}}' \
            --region $AWS_REGION

  deploy-prod:
    runs-on: ubuntu-latest
    needs: deploy-staging
    environment:
      name: production
      # Requires manual approval via GitHub environment protection rules
    steps:
      - name: Configure AWS credentials
        uses: aws-actions/configure-aws-credentials@v4
        with:
          role-to-assume: ${{ secrets.AWS_PROD_ROLE_ARN }}
          aws-region: ${{ env.AWS_REGION }}

      - name: Deploy to production (blue-green with CodeDeploy)
        run: |
          aws deploy create-deployment \
            --application-name $ECR_REPOSITORY \
            --deployment-group-name production \
            --revision '{"revisionType":"AppSpecContent","appSpecContent":{"content":"{\"version\":1,\"Resources\":[{\"TargetService\":{\"Type\":\"AWS::ECS::Service\",\"Properties\":{\"TaskDefinition\":\"arn:aws:ecs:${{ env.AWS_REGION }}:${{ secrets.AWS_ACCOUNT_ID }}:task-definition/${{ env.ECR_REPOSITORY }}\",\"LoadBalancerInfo\":{\"ContainerName\":\"app\",\"ContainerPort\":8000}}}}]}"}}' \
            --region $AWS_REGION
```

## Deployment Strategies

### Blue-Green (T2/T3)

```
BEFORE DEPLOYMENT:
[ALB] ──100%──> [Blue (v1)] ── Target Group 1

DURING DEPLOYMENT:
[ALB] ──100%──> [Blue (v1)] ── Target Group 1
                [Green (v2)] ── Target Group 2 (deploying)

VALIDATION:
[ALB] ──100%──> [Green (v2)] ── Target Group 2
                [Blue (v1)] ── Target Group 1 (standby for rollback)

AFTER VALIDATION (24h for T2, 4h for T3):
[ALB] ──100%──> [Green (v2)] ── Target Group 2
                [Blue (v1)] ── TERMINATED
```

**CodeDeploy appspec.yml:**
```yaml
version: 0.0
Resources:
  - TargetService:
      Type: AWS::ECS::Service
      Properties:
        TaskDefinition: "arn:aws:ecs:us-gov-west-1:ACCOUNT:task-definition/my-app"
        LoadBalancerInfo:
          ContainerName: "app"
          ContainerPort: 8000
Hooks:
  - BeforeInstall: "LambdaFunctionToValidateBeforeTrafficShift"
  - AfterInstall: "LambdaFunctionToValidateAfterTrafficShift"
  - AfterAllowTestTraffic: "LambdaFunctionToRunSmokeTests"
  - BeforeAllowTraffic: "LambdaFunctionToValidateBeforeTrafficShift"
  - AfterAllowTraffic: "LambdaFunctionToRunPostDeployTests"
```

### Canary (T1)

```
Stage 1 (Day 0-3):
[ALB] ──95%──> [v1]
       ──5%──> [v2 canary]

Stage 2 (Day 3-7):
[ALB] ──75%──> [v1]
       ──25%──> [v2 canary]

Stage 3 (Day 7-10):
[ALB] ──50%──> [v1]
       ──50%──> [v2 canary]

Stage 4 (Day 10-14):
[ALB] ──0%──> [v1] (terminated)
       ──100%──> [v2]
```

**CloudWatch alarm for automatic rollback:**
```json
{
  "AlarmName": "CanaryErrorRateHigh",
  "Namespace": "AWS/ApplicationELB",
  "MetricName": "HTTPCode_Target_5XX_Count",
  "Dimensions": [
    {"Name": "TargetGroup", "Value": "canary-tg"},
    {"Name": "LoadBalancer", "Value": "my-alb"}
  ],
  "ComparisonOperator": "GreaterThanThreshold",
  "Threshold": 10,
  "EvaluationPeriods": 2,
  "Period": 300,
  "Statistic": "Sum",
  "AlarmActions": ["arn:aws-us-gov:codedeploy:us-gov-west-1:ACCOUNT:..."]
}
```

## Container Image Best Practices

### Multi-Stage Build
```dockerfile
# Stage 1: Build dependencies
FROM python:3.12-slim AS builder
WORKDIR /build
COPY requirements.txt .
RUN pip install --no-cache-dir --prefix=/install -r requirements.txt

# Stage 2: Runtime (minimal image)
FROM python:3.12-slim
WORKDIR /app

# Security: non-root user
RUN groupadd -r app && useradd -r -g app -d /app app
COPY --from=builder /install /usr/local
COPY --chown=app:app src/ ./src/

USER app
EXPOSE 8000
CMD ["uvicorn", "src.main:app", "--host", "0.0.0.0", "--port", "8000"]
```

### Image Tagging Strategy
```
# Every image gets two tags:
# 1. Git SHA (immutable, for traceability)
my-app:a1b2c3d4e5f6

# 2. Semantic version (for human readability)
my-app:1.2.3

# Environment-specific "latest" tags (mutable, for convenience)
my-app:dev-latest
my-app:staging-latest
my-app:prod-latest
```

### ECR Lifecycle Policy
```json
{
  "rules": [
    {
      "rulePriority": 1,
      "description": "Keep last 20 production images",
      "selection": {
        "tagStatus": "tagged",
        "tagPrefixList": ["prod-"],
        "countType": "imageCountMoreThan",
        "countNumber": 20
      },
      "action": {"type": "expire"}
    },
    {
      "rulePriority": 2,
      "description": "Remove untagged images after 7 days",
      "selection": {
        "tagStatus": "untagged",
        "countType": "sinceImagePushed",
        "countUnit": "days",
        "countNumber": 7
      },
      "action": {"type": "expire"}
    }
  ]
}
```

## Security Scanning

### Trivy (Container Image)
Scans for OS package vulnerabilities and application dependency vulnerabilities.

```bash
# Scan local image
trivy image --severity HIGH,CRITICAL --exit-code 1 my-app:latest

# Scan ECR image
trivy image --severity HIGH,CRITICAL $ECR_REGISTRY/my-app:latest
```

**Policy:** Block deployment if HIGH or CRITICAL vulnerabilities are found.
MEDIUM vulnerabilities generate warnings but do not block.

### Snyk (Application Dependencies)
Scans Python/Java/Node.js dependencies for known vulnerabilities.

```bash
# Python
snyk test --severity-threshold=high --file=requirements.txt

# Java
snyk test --severity-threshold=high --file=pom.xml
```

### SAST (Static Application Security Testing)
Scans source code for security patterns (SQL injection, XSS, hardcoded secrets).

```bash
# CodeQL (GitHub native)
# Configured via .github/codeql/codeql-config.yml

# Bandit (Python-specific)
bandit -r src/ -f json -o bandit-results.json
```

## Environment Promotion Gates

| Transition | Gate Type | Criteria |
|-----------|----------|---------|
| Code -> Dev | Automatic | PR merged to develop, all tests pass, scans clean |
| Dev -> Staging | Manual trigger | Release candidate tagged, dev smoke tests pass |
| Staging -> Prod | Manual approval | Staging validation complete (24h T2 / 4h T3), CAB approval for T1 |

### GitHub Environment Protection Rules
```yaml
# Configured in GitHub repo settings, not in workflow file
environments:
  dev:
    deployment_branch_policy:
      protected_branches: false
      custom_branches: ["develop"]
  staging:
    deployment_branch_policy:
      protected_branches: true  # main branch only
    reviewers: []  # No approval needed, just manual trigger
  production:
    deployment_branch_policy:
      protected_branches: true
    reviewers:
      - team: "operations"
      - team: "app-owners"
    wait_timer: 30  # 30-minute wait before deployment can proceed
```

## Database Migration Strategy

### Alembic (Python/SQLAlchemy)
```bash
# Generate migration
alembic revision --autogenerate -m "add_user_preferences_table"

# Run migration (before deployment)
alembic upgrade head

# Rollback (if needed)
alembic downgrade -1
```

### Backward Compatibility (Expand-Contract)
All migrations must be backward compatible. The old application version must
continue to work with the new schema during blue-green or canary deployments.

```
Phase 1 (Expand): Add new column/table, keep old structure
  - Deploy migration
  - Both v1 and v2 work with the schema

Phase 2 (Migrate): Backfill data, update application to use new structure
  - Deploy v2 application
  - v2 writes to both old and new columns
  - Background job backfills existing data

Phase 3 (Contract): Remove old structure (next release)
  - Deploy migration to drop old column/table
  - Only after v1 is fully decommissioned
```

## Feature Flags

### AWS AppConfig Integration
```python
import boto3

appconfig = boto3.client("appconfig", region_name="us-gov-west-1")

def get_feature_flag(flag_name: str) -> bool:
    """Check feature flag value from AppConfig."""
    response = appconfig.get_configuration(
        Application="my-app",
        Environment="production",
        Configuration=flag_name,
        ClientId="instance-1",
    )
    config = json.loads(response["Content"].read())
    return config.get("enabled", False)


# Usage in route handler
@app.get("/api/v2/reports")
async def get_reports():
    if get_feature_flag("new-report-engine"):
        return await new_report_engine()
    return await legacy_report_engine()
```

### Gradual Rollout Pattern
```json
{
  "flag_name": "new-report-engine",
  "enabled": true,
  "rollout_percentage": 25,
  "targeting": {
    "rules": [
      {"attribute": "user_role", "operator": "in", "values": ["admin", "tester"]},
      {"attribute": "region", "operator": "eq", "value": "us-gov-west-1"}
    ]
  }
}
```
