# VPC Topology Patterns

Reference for aws-deployment-topology when designing network infrastructure.

## Standard 3-Tier VPC for GovCloud

The default VPC design for all Olympus applications follows a 3-tier pattern
separating public-facing load balancers, private compute resources, and
isolated data stores.

```
                        Internet
                           │
                     ┌─────┴─────┐
                     │  Internet  │
                     │  Gateway   │
                     └─────┬─────┘
                           │
    ┌──────────────────────┼──────────────────────┐
    │           PUBLIC SUBNETS (ALB only)          │
    │  ┌──────────────┐    │    ┌──────────────┐  │
    │  │  10.0.1.0/24 │    │    │  10.0.2.0/24 │  │
    │  │    AZ-1      │    │    │    AZ-2      │  │
    │  │  [ALB node]  │    │    │  [ALB node]  │  │
    │  └──────┬───────┘    │    └──────┬───────┘  │
    │         │            │           │          │
    │         │     ┌──────┴──────┐    │          │
    │         │     │ NAT Gateway │    │          │
    │         │     │  (per-AZ    │    │          │
    │         │     │  for T1/T2) │    │          │
    │         │     └──────┬──────┘    │          │
    ├─────────┼────────────┼───────────┼──────────┤
    │         PRIVATE SUBNETS (Compute)           │
    │  ┌──────┴───────┐    │    ┌──────┴───────┐  │
    │  │  10.0.11.0/24│    │    │  10.0.12.0/24│  │
    │  │    AZ-1      │    │    │    AZ-2      │  │
    │  │  [Fargate]   │    │    │  [Fargate]   │  │
    │  │  [Lambda]    │    │    │  [Lambda]    │  │
    │  └──────┬───────┘    │    └──────┬───────┘  │
    ├─────────┼────────────┼───────────┼──────────┤
    │        ISOLATED SUBNETS (Database)          │
    │  ┌──────┴───────┐    │    ┌──────┴───────┐  │
    │  │  10.0.21.0/24│    │    │  10.0.22.0/24│  │
    │  │    AZ-1      │    │    │    AZ-2      │  │
    │  │  [Aurora]    │    │    │  [Aurora]    │  │
    │  │  [ElastiCache]    │    │  [ElastiCache]  │
    │  └──────────────┘    │    └──────────────┘  │
    └──────────────────────┴──────────────────────┘
```

## CIDR Allocation Strategy

### Per-Application VPC
```yaml
# CIDR: 10.{app_id}.0.0/16 — 65,536 addresses per application VPC
# This provides room for growth while keeping VPCs non-overlapping

vpc_cidr: "10.1.0.0/16"

subnets:
  public:
    az1: "10.1.1.0/24"    # 251 usable addresses
    az2: "10.1.2.0/24"
    az3: "10.1.3.0/24"    # T1 only (3rd AZ)

  private:
    az1: "10.1.11.0/24"   # 251 usable addresses
    az2: "10.1.12.0/24"
    az3: "10.1.13.0/24"   # T1 only

  isolated:
    az1: "10.1.21.0/24"   # 251 usable addresses
    az2: "10.1.22.0/24"
    az3: "10.1.23.0/24"   # T1 only
```

### Subnet Sizing Considerations
- **/24** (251 usable): sufficient for most applications (<250 ENIs per AZ)
- **/22** (1019 usable): needed if running many Lambda functions (each ENI consumes an address) or large Fargate task counts
- **/20** (4091 usable): only for very large deployments or shared services VPC
- Reserve /24 blocks for future subnets (don't allocate the entire /16 upfront)

## NAT Gateway Configuration

| Tier | NAT Gateway Count | Rationale | Monthly Cost (approx) |
|------|-------------------|-----------|----------------------|
| T1 | 1 per AZ (3 total) | HA: AZ failure does not affect outbound connectivity | ~$100/month + data |
| T2 | 1 per AZ (2 total) | HA: AZ failure does not affect outbound connectivity | ~$67/month + data |
| T3 | 1 (single AZ) | Cost optimization: AZ failure temporarily breaks outbound | ~$33/month + data |

**Data processing charges**: NAT Gateway charges $0.045/GB processed (GovCloud).
Reduce NAT costs by using VPC endpoints for AWS services.

### Route Table Configuration
```yaml
# Public subnets: route to Internet Gateway
public_routes:
  - destination: "0.0.0.0/0"
    target: internet_gateway

# Private subnets: route to NAT Gateway (per-AZ for T1/T2)
private_routes_az1:
  - destination: "0.0.0.0/0"
    target: nat_gateway_az1

private_routes_az2:
  - destination: "0.0.0.0/0"
    target: nat_gateway_az2

# Isolated subnets: no internet route
isolated_routes:
  # No default route — database subnets have no outbound internet
  # AWS service access via VPC endpoints only
```

## VPC Endpoints

### Gateway Endpoints (free, always create)

| Service | Endpoint Type | Why |
|---------|--------------|-----|
| S3 | Gateway | Free; reduces NAT Gateway data charges for S3 access |
| DynamoDB | Gateway | Free; reduces NAT Gateway data charges |

### Interface Endpoints (cost: ~$7.30/month per AZ per endpoint)

Only create interface endpoints for services the application actually uses.
Each endpoint creates an ENI in each specified subnet.

| Service | When to Create | Justification |
|---------|---------------|---------------|
| ECR (ecr.api + ecr.dkr) | Always (Fargate) | Required for Fargate to pull container images |
| CloudWatch Logs | Always | All applications send logs |
| Secrets Manager | When using secrets | Database credentials, API keys |
| STS | When using IAM roles | Required for task role assumption |
| SQS | When using queues | Message queue access from private subnets |
| SNS | When using notifications | Alert and notification publishing |
| KMS | When using encryption | Key access for encrypted resources |
| SSM | When using Parameter Store | Configuration parameters, ECS Exec |
| Execute API (API Gateway) | When exposing private APIs | Private API Gateway access |

### Cost Optimization
At $7.30/month per AZ per endpoint, costs accumulate:
- 5 endpoints x 2 AZs = $73/month
- 5 endpoints x 3 AZs = $109.50/month
- 10 endpoints x 3 AZs = $219/month

Audit endpoint usage quarterly. Remove endpoints for services no longer used.

## Security Groups

### Layered Security Group Design

```yaml
security_groups:
  alb:
    name: "sg-alb"
    description: "Application Load Balancer"
    ingress:
      - protocol: tcp
        port: 443
        source: "0.0.0.0/0"         # HTTPS from internet
        description: "HTTPS from internet"
      - protocol: tcp
        port: 80
        source: "0.0.0.0/0"         # HTTP (redirects to HTTPS)
        description: "HTTP redirect"
    egress:
      - protocol: tcp
        port: 8000
        destination: "sg-fargate"    # Only to Fargate tasks
        description: "To application containers"

  fargate:
    name: "sg-fargate"
    description: "Fargate compute tasks"
    ingress:
      - protocol: tcp
        port: 8000
        source: "sg-alb"            # Only from ALB
        description: "From ALB"
    egress:
      - protocol: tcp
        port: 5432
        destination: "sg-aurora"     # To Aurora
        description: "To database"
      - protocol: tcp
        port: 6379
        destination: "sg-redis"      # To ElastiCache
        description: "To cache"
      - protocol: tcp
        port: 443
        destination: "0.0.0.0/0"    # HTTPS to AWS services and external APIs
        description: "To AWS services and external APIs"

  aurora:
    name: "sg-aurora"
    description: "Aurora PostgreSQL database"
    ingress:
      - protocol: tcp
        port: 5432
        source: "sg-fargate"        # Only from Fargate
        description: "From application containers"
    egress: []                       # No outbound needed

  redis:
    name: "sg-redis"
    description: "ElastiCache Redis"
    ingress:
      - protocol: tcp
        port: 6379
        source: "sg-fargate"        # Only from Fargate
        description: "From application containers"
    egress: []                       # No outbound needed

  rds_proxy:
    name: "sg-rds-proxy"
    description: "RDS Proxy"
    ingress:
      - protocol: tcp
        port: 5432
        source: "sg-fargate"        # Only from Fargate
        description: "From application containers"
    egress:
      - protocol: tcp
        port: 5432
        destination: "sg-aurora"     # To Aurora
        description: "To database"
```

### Network ACLs

Use default VPC NACLs (allow all within VPC) unless regulatory requirements
mandate explicit deny rules. NACLs are stateless and apply to the entire subnet,
making them harder to manage than security groups.

```yaml
# Recommended only if compliance requires explicit NACLs
nacl_isolated:
  inbound:
    - rule: 100
      protocol: tcp
      port: 5432
      source: "10.1.11.0/24"   # Private subnet AZ-1
      action: allow
    - rule: 110
      protocol: tcp
      port: 5432
      source: "10.1.12.0/24"   # Private subnet AZ-2
      action: allow
    - rule: 999
      protocol: all
      source: "0.0.0.0/0"
      action: deny
```

## Transit Gateway (Multi-VPC)

For applications that require connectivity to other VPCs or on-premises
networks:

```
┌─────────────┐     ┌──────────────────┐     ┌──────────────────┐
│  App VPC-1  │─────│  Transit Gateway  │─────│  App VPC-2       │
└─────────────┘     │                  │     └──────────────────┘
                    │                  │
┌─────────────┐     │                  │     ┌──────────────────┐
│  Shared Svc │─────│                  │─────│  On-Premises     │
│  VPC        │     │                  │     │  (VPN/Direct     │
└─────────────┘     └──────────────────┘     │   Connect)       │
                                             └──────────────────┘
```

### When to Use Transit Gateway
- Multiple application VPCs need to communicate
- On-premises connectivity via VPN or Direct Connect
- Centralized shared services (logging, monitoring, security scanning)

### When NOT to Use
- Single application with no cross-VPC needs (VPC peering is simpler and cheaper)
- Cost-sensitive T3 applications (Transit Gateway charges per attachment + per GB)

## DNS Configuration

### Route53 Private Hosted Zones
```yaml
hosted_zones:
  - name: "app.internal"
    vpc: "vpc-app"
    records:
      - name: "db.app.internal"
        type: CNAME
        value: "my-cluster.cluster-abc123.us-gov-west-1.rds.amazonaws.com"
      - name: "cache.app.internal"
        type: CNAME
        value: "my-redis.abc123.0001.usgw1.cache.amazonaws.com"
      - name: "api.app.internal"
        type: A
        alias: "internal-my-alb-123456.us-gov-west-1.elb.amazonaws.com"
```

### Split-Horizon DNS
For T1 applications with cross-region DR, configure split-horizon DNS so the
same hostname resolves to region-local resources:
- us-gov-west-1: `db.app.internal` -> primary Aurora endpoint
- us-gov-east-1: `db.app.internal` -> secondary Aurora endpoint (during failover)

## FAA On-Premises Connectivity

### Site-to-Site VPN
```yaml
vpn:
  type: "site-to-site"
  customer_gateway:
    ip: "203.0.113.1"       # FAA on-premises VPN endpoint
    bgp_asn: 65000
  virtual_private_gateway:
    attached_to: "vpc-app"
  tunnels: 2                 # AWS creates 2 tunnels for HA
  routing: "dynamic"         # BGP preferred over static
  encryption: "AES-256-GCM"
  ike_version: 2
```

### Direct Connect (if available)
For higher bandwidth and lower latency than VPN:
- Dedicated connection: 1 Gbps or 10 Gbps
- Hosted connection: 50 Mbps to 10 Gbps
- Virtual interfaces: private (VPC access) or transit (Transit Gateway access)
- Recommended for T1 applications with significant on-premises data exchange
