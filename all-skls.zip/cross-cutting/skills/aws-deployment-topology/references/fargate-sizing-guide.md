# Fargate Sizing Guide

Reference for aws-deployment-topology when sizing compute resources.

## Fargate Task Size Options

Fargate enforces specific CPU/memory combinations. You cannot choose arbitrary values.

| vCPU | Memory Options |
|------|---------------|
| 0.25 | 512 MB, 1 GB, 2 GB |
| 0.5 | 1 GB, 2 GB, 3 GB, 4 GB |
| 1 | 2 GB, 3 GB, 4 GB, 5 GB, 6 GB, 7 GB, 8 GB |
| 2 | 4 GB - 16 GB (1 GB increments) |
| 4 | 8 GB - 30 GB (1 GB increments) |
| 8 | 16 GB - 60 GB (4 GB increments) |
| 16 | 32 GB - 120 GB (8 GB increments) |

## Sizing Heuristics by Archetype

### Web Application (Light)
**Profile:** Simple CRUD, server-rendered pages, <100 concurrent users.
**Starting size:** 0.25 vCPU, 512 MB

Characteristics:
- Low CPU: simple request/response, minimal computation
- Low memory: small session footprint, no in-memory caching
- Examples: internal admin tools, simple form-based applications, status dashboards

```yaml
cpu: 256       # 0.25 vCPU
memory: 512    # 512 MB
min_tasks: 1   # Single task for dev/staging; 2 for prod T3
max_tasks: 4
scaling_target_cpu: 70
```

### Web Application (Medium)
**Profile:** Moderate business logic, API + server-rendered, 100-500 concurrent users.
**Starting size:** 0.5 vCPU, 1 GB

Characteristics:
- Moderate CPU: business rule evaluation, template rendering, JSON serialization
- Moderate memory: ORM entity caching, session state, template engine
- Examples: case management systems, reporting portals, workflow applications

```yaml
cpu: 512       # 0.5 vCPU
memory: 1024   # 1 GB
min_tasks: 2   # 2 for prod T2/T3; 3 for prod T1
max_tasks: 8
scaling_target_cpu: 70
```

### Web Application (Heavy)
**Profile:** Complex business logic, real-time features, >500 concurrent users.
**Starting size:** 1 vCPU, 2 GB

Characteristics:
- High CPU: complex calculations, data transformations, real-time processing
- High memory: large datasets in memory, complex object graphs, WebSocket connections
- Examples: flight tracking dashboards, real-time monitoring, complex analytics

```yaml
cpu: 1024      # 1 vCPU
memory: 2048   # 2 GB
min_tasks: 3   # T1 requirement (one per AZ)
max_tasks: 12
scaling_target_cpu: 60
```

### API Service
**Profile:** REST or GraphQL API, JSON payload processing, service-to-service communication.
**Starting size:** 0.5-1 vCPU, 1-2 GB (depends on payload size)

Characteristics:
- CPU depends on: serialization complexity, validation logic, transformation depth
- Memory depends on: payload size, concurrent request handling, connection pool size
- Small payloads (<1 KB): 0.5 vCPU, 1 GB
- Medium payloads (1-100 KB): 1 vCPU, 2 GB
- Large payloads (100 KB - 10 MB): 2 vCPU, 4 GB

```yaml
# Medium API service
cpu: 1024      # 1 vCPU
memory: 2048   # 2 GB
min_tasks: 2
max_tasks: 10
scaling_target_cpu: 60
```

### Batch Worker
**Profile:** Background job processing, ETL, report generation.
**Starting size:** 1-4 vCPU, 4-8 GB

Characteristics:
- CPU-intensive: data transformation, file parsing, PDF generation
- Memory-intensive: large dataset processing, in-memory aggregation
- Typically not latency-sensitive; throughput-oriented
- Consider Fargate Spot for T3 batch workloads (cost savings up to 70%)

```yaml
# Standard batch worker
cpu: 2048      # 2 vCPU
memory: 8192   # 8 GB
min_tasks: 0   # Scale to zero when no work
max_tasks: 10
scaling_metric: sqs_queue_depth  # Scale based on queue depth, not CPU
```

### Serverless / Lambda Alternative

For some workloads, Lambda may be more cost-effective than Fargate:

| Criteria | Fargate | Lambda |
|---------|---------|--------|
| Consistent traffic | Preferred (reserved capacity) | Expensive (per-invocation billing) |
| Spiky traffic | Acceptable (auto-scale, but slower) | Preferred (instant scale) |
| Long-running (>15 min) | Required | Not supported |
| Cold start sensitive | Preferred (always running) | Problematic (cold starts 1-10s) |
| VPC-attached | Standard | Adds 1-2s cold start (ENI setup) |
| Cost at 1M req/month | ~$30-100 (depends on size) | ~$0.20 + duration costs |
| Cost at 100M req/month | ~$100-300 | ~$20 + duration costs |

**Lambda sizing:**
```yaml
memory: 256    # 256 MB (also determines CPU allocation proportionally)
timeout: 30    # 30 seconds (max 900 for async)
reserved_concurrency: 100  # Prevent runaway scaling
provisioned_concurrency: 10  # For latency-sensitive (eliminates cold starts)
```

## Right-Sizing Methodology

### Initial Deployment (Week 0-2)
1. Deploy with the archetype baseline size
2. Set up CloudWatch dashboards for CPU and memory utilization
3. Configure alarms at 80% CPU and 80% memory

### Observation Period (Week 2-4)
1. Collect utilization metrics during normal and peak traffic
2. Look for these patterns:
   - **Oversized**: average CPU <30%, average memory <40% -- scale down
   - **Right-sized**: average CPU 40-60%, average memory 50-70% -- keep
   - **Undersized**: average CPU >70%, memory >80%, or OOMKilled events -- scale up

### Adjustment (Week 4+)
1. Adjust to the next size tier up or down
2. Monitor for 1 week after adjustment
3. Repeat until right-sized
4. Schedule quarterly right-sizing reviews

### CloudWatch Dashboard Queries

```
# CPU utilization (average over 5 minutes)
SELECT AVG(CPUUtilization)
FROM SCHEMA("AWS/ECS", ClusterName, ServiceName)
WHERE ClusterName = 'my-cluster' AND ServiceName = 'my-service'
GROUP BY BIN(5m)

# Memory utilization (average over 5 minutes)
SELECT AVG(MemoryUtilization)
FROM SCHEMA("AWS/ECS", ClusterName, ServiceName)
WHERE ClusterName = 'my-cluster' AND ServiceName = 'my-service'
GROUP BY BIN(5m)
```

## Cost Comparison

### Monthly cost estimates (us-gov-west-1, as of 2024)

| Size | vCPU | Memory | Fargate/month | Fargate Spot/month | Lambda equiv (1M req, 200ms avg) |
|------|------|--------|--------------|-------------------|--------------------------------|
| XS | 0.25 | 0.5 GB | ~$9 | ~$3 | ~$0.60 |
| S | 0.5 | 1 GB | ~$18 | ~$6 | ~$2 |
| M | 1 | 2 GB | ~$36 | ~$12 | ~$7 |
| L | 2 | 4 GB | ~$72 | ~$24 | ~$20 |
| XL | 4 | 8 GB | ~$144 | ~$48 | N/A (Lambda max 10 GB) |

**Note:** GovCloud pricing is approximately 10-20% higher than commercial AWS.
Always verify current pricing in the AWS GovCloud pricing calculator.

**Note:** These are per-task costs. Multiply by minimum task count and average
utilization to estimate total monthly cost.

## Container Best Practices

### Dockerfile Pattern
```dockerfile
# Build stage
FROM python:3.12-slim AS builder
WORKDIR /app
COPY requirements.txt .
RUN pip install --no-cache-dir --target=/app/deps -r requirements.txt

# Runtime stage (distroless or slim)
FROM python:3.12-slim
WORKDIR /app

# Non-root user
RUN groupadd -r appuser && useradd -r -g appuser appuser

# Copy dependencies and application
COPY --from=builder /app/deps /usr/local/lib/python3.12/site-packages/
COPY . .

# Security: no root, read-only where possible
USER appuser

EXPOSE 8000
HEALTHCHECK --interval=30s --timeout=5s --retries=3 \
  CMD python -c "import urllib.request; urllib.request.urlopen('http://localhost:8000/api/health')"

CMD ["uvicorn", "app.main:app", "--host", "0.0.0.0", "--port", "8000", "--workers", "2"]
```

### Worker Count Heuristic
- Uvicorn workers: `min(2 * vCPU, 4)` for async apps
- Gunicorn workers: `2 * vCPU + 1` for sync apps
- With 0.25 vCPU: 1 worker (single process)
- With 0.5 vCPU: 1-2 workers
- With 1 vCPU: 2-3 workers
- With 2 vCPU: 4-5 workers
