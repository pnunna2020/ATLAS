# Infrastructure as Code Module Catalog

Reference for aws-deployment-topology when composing Terraform modules.

## Module Composition Pattern

Olympus uses a layered Terraform module structure:

```
infrastructure/
├── environments/
│   ├── dev/
│   │   ├── main.tf          # Root module: dev environment
│   │   ├── variables.tf
│   │   ├── outputs.tf
│   │   ├── terraform.tfvars  # Dev-specific values
│   │   └── backend.tf        # S3 state backend
│   ├── staging/
│   │   ├── main.tf
│   │   ├── variables.tf
│   │   ├── outputs.tf
│   │   ├── terraform.tfvars
│   │   └── backend.tf
│   └── prod/
│       ├── main.tf
│       ├── variables.tf
│       ├── outputs.tf
│       ├── terraform.tfvars
│       └── backend.tf
├── modules/
│   ├── vpc/                   # Network infrastructure
│   ├── ecs/                   # Compute (cluster, service, task)
│   ├── aurora/                # Database
│   ├── alb/                   # Load balancer
│   ├── elasticache/           # Cache
│   ├── cloudfront/            # CDN
│   ├── eventbridge/           # Event bus
│   ├── lambda/                # Serverless functions
│   ├── s3/                    # Object storage
│   ├── monitoring/            # CloudWatch dashboards, alarms
│   └── security/              # WAF, KMS, Secrets Manager
└── shared/
    ├── state-backend/         # S3 + DynamoDB for Terraform state
    └── ecr/                   # Container registry (shared across envs)
```

## State Management

### S3 Backend with DynamoDB Locking

```hcl
# backend.tf (per environment)
terraform {
  backend "s3" {
    bucket         = "olympus-terraform-state-ACCOUNT_ID"
    key            = "my-app/dev/terraform.tfstate"
    region         = "us-gov-west-1"
    encrypt        = true
    kms_key_id     = "alias/terraform-state-key"
    dynamodb_table = "olympus-terraform-locks"
  }
}
```

**State isolation rules:**
- One state file per environment per application
- Never share state between environments
- State bucket has versioning enabled for recovery
- DynamoDB table prevents concurrent modifications

## Module: VPC

```hcl
module "vpc" {
  source = "../../modules/vpc"

  name               = "my-app-${var.environment}"
  cidr               = var.vpc_cidr
  availability_zones = var.availability_zones

  # Subnet CIDRs
  public_subnets   = var.public_subnet_cidrs
  private_subnets  = var.private_subnet_cidrs
  isolated_subnets = var.isolated_subnet_cidrs

  # NAT Gateway
  nat_gateway_per_az = var.tier == "T1" || var.tier == "T2"
  single_nat_gateway = var.tier == "T3"

  # VPC Endpoints
  enable_s3_endpoint         = true   # Gateway (free)
  enable_dynamodb_endpoint   = true   # Gateway (free)
  enable_ecr_endpoints       = true   # Interface (required for Fargate)
  enable_logs_endpoint       = true   # Interface
  enable_secrets_endpoint    = var.use_secrets_manager
  enable_sts_endpoint        = true   # Interface (required for IAM roles)
  enable_sqs_endpoint        = var.use_sqs
  enable_ssm_endpoint        = var.use_ecs_exec

  # DNS
  enable_dns_support   = true
  enable_dns_hostnames = true

  # Flow Logs
  enable_flow_logs     = true
  flow_log_destination = "cloud-watch-logs"  # or "s3"

  tags = var.common_tags
}
```

**Variables:**
```hcl
variable "vpc_cidr" {
  description = "VPC CIDR block"
  type        = string
  default     = "10.1.0.0/16"
}

variable "availability_zones" {
  description = "List of AZs to use"
  type        = list(string)
  default     = ["us-gov-west-1a", "us-gov-west-1b"]
}

variable "public_subnet_cidrs" {
  description = "CIDR blocks for public subnets (one per AZ)"
  type        = list(string)
  default     = ["10.1.1.0/24", "10.1.2.0/24"]
}

variable "private_subnet_cidrs" {
  description = "CIDR blocks for private subnets (one per AZ)"
  type        = list(string)
  default     = ["10.1.11.0/24", "10.1.12.0/24"]
}

variable "isolated_subnet_cidrs" {
  description = "CIDR blocks for isolated subnets (one per AZ)"
  type        = list(string)
  default     = ["10.1.21.0/24", "10.1.22.0/24"]
}
```

## Module: ECS

```hcl
module "ecs" {
  source = "../../modules/ecs"

  # Cluster
  cluster_name = "my-app-${var.environment}"

  # Service
  service_name    = "my-app"
  desired_count   = var.min_tasks
  launch_type     = "FARGATE"
  platform_version = "LATEST"

  # Task Definition
  task_cpu    = var.task_cpu
  task_memory = var.task_memory
  container_definitions = [
    {
      name      = "app"
      image     = "${var.ecr_registry}/${var.ecr_repository}:${var.image_tag}"
      cpu       = var.task_cpu
      memory    = var.task_memory
      essential = true
      port_mappings = [
        {
          containerPort = var.container_port
          protocol      = "tcp"
        }
      ]
      environment = var.environment_variables
      secrets     = var.secret_references
      log_configuration = {
        logDriver = "awslogs"
        options = {
          "awslogs-group"         = "/ecs/my-app-${var.environment}"
          "awslogs-region"        = var.region
          "awslogs-stream-prefix" = "app"
        }
      }
      health_check = {
        command     = ["CMD-SHELL", "curl -f http://localhost:${var.container_port}/api/health || exit 1"]
        interval    = 30
        timeout     = 5
        retries     = 3
        startPeriod = 60
      }
    }
  ]

  # Networking
  subnets         = module.vpc.private_subnet_ids
  security_groups = [module.vpc.fargate_security_group_id]

  # Load Balancer
  target_group_arn = module.alb.target_group_arn

  # Auto Scaling
  min_capacity    = var.min_tasks
  max_capacity    = var.max_tasks
  scaling_policies = {
    cpu = {
      target_value = var.scaling_target_cpu
      scale_in_cooldown  = 300
      scale_out_cooldown = var.tier == "T1" ? 60 : 120
    }
    memory = {
      target_value = var.scaling_target_memory
      scale_in_cooldown  = 300
      scale_out_cooldown = var.tier == "T1" ? 60 : 120
    }
  }

  # Deployment
  deployment_controller = var.tier == "T1" ? "CODE_DEPLOY" : "ECS"
  minimum_healthy_percent = var.tier == "T1" ? 100 : 50
  maximum_percent         = 200

  # ECS Exec (for debugging)
  enable_execute_command = var.environment != "prod"

  tags = var.common_tags
}
```

## Module: Aurora

```hcl
module "aurora" {
  source = "../../modules/aurora"

  cluster_identifier = "my-app-${var.environment}"
  engine             = "aurora-postgresql"
  engine_version     = "15.4"

  # Instances
  instance_class = var.db_instance_class
  instance_count = var.tier == "T1" ? 3 : var.tier == "T2" ? 2 : 1

  # Networking
  subnet_ids      = module.vpc.isolated_subnet_ids
  security_groups = [module.vpc.aurora_security_group_id]

  # Storage
  storage_encrypted = true
  kms_key_id        = var.kms_key_arn

  # Backup
  backup_retention_period      = var.tier == "T1" ? 35 : var.tier == "T2" ? 14 : 7
  preferred_backup_window      = "03:00-04:00"
  preferred_maintenance_window = "sun:04:00-sun:05:00"

  # Parameters
  cluster_parameter_group = {
    shared_preload_libraries = "pg_stat_statements"
    log_min_duration_statement = 1000  # Log slow queries (>1s)
  }

  instance_parameter_group = {
    log_connections    = true
    log_disconnections = true
  }

  # RDS Proxy (T1/T2)
  enable_rds_proxy = var.tier != "T3"
  proxy_config = {
    debug_logging          = false
    idle_client_timeout    = 1800
    max_connections_percent = 100
    max_idle_connections_percent = 50
  }

  # Monitoring
  performance_insights_enabled = true
  monitoring_interval          = var.tier == "T1" ? 1 : 60  # Enhanced monitoring

  # Deletion protection
  deletion_protection = var.environment == "prod"
  skip_final_snapshot = var.environment != "prod"

  tags = var.common_tags
}
```

## Module: ALB

```hcl
module "alb" {
  source = "../../modules/alb"

  name     = "my-app-${var.environment}"
  internal = false  # Internet-facing (or true for internal APIs)

  # Networking
  subnets         = module.vpc.public_subnet_ids
  security_groups = [module.vpc.alb_security_group_id]

  # Listener
  listener_port     = 443
  listener_protocol = "HTTPS"
  certificate_arn   = var.acm_certificate_arn

  # HTTP redirect
  enable_http_redirect = true

  # Target Group
  target_group_port     = var.container_port
  target_group_protocol = "HTTP"
  target_type           = "ip"  # Required for Fargate

  health_check = {
    path                = "/api/health"
    port                = var.container_port
    protocol            = "HTTP"
    healthy_threshold   = var.tier == "T1" ? 2 : 3
    unhealthy_threshold = var.tier == "T1" ? 2 : 3
    timeout             = 5
    interval            = var.tier == "T1" ? 10 : 30
    matcher             = "200"
  }

  # WAF
  waf_web_acl_arn = var.waf_web_acl_arn

  # Access logs
  enable_access_logs = true
  access_logs_bucket = var.logs_bucket

  # Idle timeout
  idle_timeout = 60

  tags = var.common_tags
}
```

## Module: CloudFront

```hcl
module "cloudfront" {
  source = "../../modules/cloudfront"

  # Only for applications with static assets or CDN requirements
  enabled = var.enable_cdn

  # Origins
  origins = {
    alb = {
      domain_name = module.alb.dns_name
      origin_protocol_policy = "https-only"
    }
    s3_static = {
      domain_name = module.s3_static.bucket_regional_domain_name
      origin_access_identity = true
    }
  }

  # Behaviors
  default_cache_behavior = {
    target_origin_id       = "alb"
    viewer_protocol_policy = "redirect-to-https"
    allowed_methods        = ["GET", "HEAD", "OPTIONS", "PUT", "POST", "PATCH", "DELETE"]
    cached_methods         = ["GET", "HEAD"]
    cache_policy_id        = "658327ea-f89d-4fab-a63d-7e88639e58f6"  # CachingOptimized
  }

  ordered_cache_behaviors = [
    {
      path_pattern           = "/static/*"
      target_origin_id       = "s3_static"
      viewer_protocol_policy = "redirect-to-https"
      compress               = true
      cache_policy_id        = "658327ea-f89d-4fab-a63d-7e88639e58f6"
    }
  ]

  # SSL
  acm_certificate_arn = var.acm_certificate_arn_us_east_1  # CloudFront requires us-east-1 cert
  minimum_protocol_version = "TLSv1.2_2021"

  # WAF
  web_acl_id = var.waf_cloudfront_web_acl_arn

  tags = var.common_tags
}
```

## Module: Monitoring

```hcl
module "monitoring" {
  source = "../../modules/monitoring"

  application_name = "my-app"
  environment      = var.environment
  tier             = var.tier

  # CloudWatch Dashboard
  enable_dashboard = true
  dashboard_widgets = [
    "ecs_cpu_utilization",
    "ecs_memory_utilization",
    "alb_request_count",
    "alb_5xx_count",
    "alb_latency_p99",
    "aurora_cpu",
    "aurora_connections",
    "aurora_replication_lag",
    "redis_cache_hits",
    "redis_memory",
  ]

  # Alarms
  alarms = {
    high_cpu = {
      metric    = "CPUUtilization"
      namespace = "AWS/ECS"
      threshold = 80
      period    = 300
      actions   = [var.sns_topic_arn]
    }
    high_5xx = {
      metric    = "HTTPCode_Target_5XX_Count"
      namespace = "AWS/ApplicationELB"
      threshold = var.tier == "T1" ? 10 : 50
      period    = 300
      actions   = [var.sns_topic_arn]
    }
    high_latency = {
      metric    = "TargetResponseTime"
      namespace = "AWS/ApplicationELB"
      threshold = var.tier == "T1" ? 2 : 5
      period    = 300
      statistic = "p99"
      actions   = [var.sns_topic_arn]
    }
    db_high_cpu = {
      metric    = "CPUUtilization"
      namespace = "AWS/RDS"
      threshold = 80
      period    = 300
      actions   = [var.sns_topic_arn]
    }
    db_high_connections = {
      metric    = "DatabaseConnections"
      namespace = "AWS/RDS"
      threshold = 80  # Percent of max_connections
      period    = 300
      actions   = [var.sns_topic_arn]
    }
  }

  # Log Groups
  log_groups = {
    application = {
      name              = "/ecs/my-app-${var.environment}"
      retention_in_days = var.tier == "T1" ? 365 : var.tier == "T2" ? 90 : 30
    }
    access_logs = {
      name              = "/alb/my-app-${var.environment}"
      retention_in_days = 90
    }
  }

  tags = var.common_tags
}
```

## Module: Security

```hcl
module "security" {
  source = "../../modules/security"

  application_name = "my-app"
  environment      = var.environment

  # KMS Key
  enable_kms = true
  kms_key_alias = "my-app-${var.environment}"
  kms_key_administrators = var.kms_admin_role_arns
  kms_key_users          = [module.ecs.task_role_arn]

  # Secrets Manager
  secrets = {
    database_url = {
      description = "Aurora connection string"
      rotation_days = var.tier == "T1" ? 30 : 90
    }
    api_key = {
      description = "External API key"
      rotation_days = var.tier == "T1" ? 30 : 90
    }
  }

  # WAF
  enable_waf = true
  waf_rules = [
    "AWSManagedRulesCommonRuleSet",
    "AWSManagedRulesKnownBadInputsRuleSet",
    "AWSManagedRulesSQLiRuleSet",
  ]
  waf_rate_limit = 2000  # Requests per 5 minutes per IP

  tags = var.common_tags
}
```

## Environment Variable Configuration

### Dev
```hcl
# environments/dev/terraform.tfvars
environment   = "dev"
tier          = "T3"  # Dev always runs as T3
vpc_cidr      = "10.1.0.0/16"
availability_zones = ["us-gov-west-1a"]
task_cpu      = 256
task_memory   = 512
min_tasks     = 1
max_tasks     = 2
db_instance_class = "db.t3.medium"
scaling_target_cpu = 70
enable_cdn    = false
```

### Staging
```hcl
# environments/staging/terraform.tfvars
environment   = "staging"
tier          = "T2"  # Staging mirrors prod topology at reduced scale
vpc_cidr      = "10.2.0.0/16"
availability_zones = ["us-gov-west-1a", "us-gov-west-1b"]
task_cpu      = 512
task_memory   = 1024
min_tasks     = 1
max_tasks     = 4
db_instance_class = "db.t3.medium"
scaling_target_cpu = 70
enable_cdn    = false
```

### Prod (T1 Example)
```hcl
# environments/prod/terraform.tfvars
environment   = "prod"
tier          = "T1"
vpc_cidr      = "10.3.0.0/16"
availability_zones = ["us-gov-west-1a", "us-gov-west-1b", "us-gov-west-1c"]
task_cpu      = 1024
task_memory   = 2048
min_tasks     = 3
max_tasks     = 12
db_instance_class = "db.r6g.large"
scaling_target_cpu = 60
enable_cdn    = true
```
