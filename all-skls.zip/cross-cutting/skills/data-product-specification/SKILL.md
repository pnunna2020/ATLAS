---
name: data-product-specification
description: >
  Define data products with ownership, schemas, SLAs, access patterns, and quality
  guarantees. Used during Data line data product design step. Triggers on data product
  definition, data contract, or data SLA specification.
agent: opus
allowed-tools:
  - Read
  - Write
  - Grep
---

# Data Product Specification

## Purpose
Formally define data products as first-class, versioned, SLA-backed interfaces
for cross-domain data consumption within the data mesh.

## Inputs
- Data domain model from domain discovery
- Discovered data entities and schemas
- Business criticality ratings
- Consumer requirements (who needs what data, how fresh, how fast)

## Outputs
- Data product YAML specification (schema, SLA, ownership, access API)
- Versioned data contracts (semver)
- Quality rules (executable validation checks)
- API gateway route definitions

## Methodology
1. Identify data product boundaries from domain model
2. Define ownership (single domain owner per product)
3. Specify SLA: availability %, latency P99, freshness guarantee
4. Define schema using avro/json-schema/protobuf (versioned)
5. Define access API with authentication and rate limits
6. Define quality rules: completeness ≥99%, accuracy, timeliness
7. Document data lineage: sources, transformations, refresh cadence

## Gotchas
- **Data contracts are versioned like code**: Use semver. Breaking schema
  changes require major version bumps and consumer migration plans.
- **Quality rules must be executable**: Map each rule to a validation script
  or SQL check. Aspirational quality statements are not sufficient.
- **Freshness SLA drives architecture**: Real-time freshness requires CDC/streaming.
  Daily freshness can use batch ETL. Get this wrong and you redesign the pipeline.

## Quality Rules
- [ ] Every data product has a single domain owner — no shared ownership
- [ ] SLA specifies availability %, latency P99, and freshness guarantee with measurable targets
- [ ] Schema is versioned using semver; breaking changes require major version bumps
- [ ] Quality rules are executable: each maps to a validation script or SQL check
- [ ] Data lineage is documented: sources, transformations, and refresh cadence
- [ ] Access API includes authentication (via Gravitee/OKTA) and rate limiting configuration
- [ ] Freshness SLA is aligned with architecture: real-time requires CDC/streaming, daily permits batch ETL

## Common Failure Modes
| Failure Mode | Symptom | Prevention |
|-------------|---------|------------|
| Unversioned schema changes | Breaking change deployed without version bump; downstream consumers break | Enforce semver on all schemas; require migration plan for major version changes |
| Aspirational quality rules | Quality rules documented but never automated; violations not caught until production | Map every quality rule to a validation script; integrate into CI/CD pipeline |
| Freshness mismatch | Real-time freshness SLA but batch ETL pipeline; data is stale when consumers read it | Align architecture to SLA: CDC/streaming for real-time, batch ETL for daily freshness |
| Missing rate limits | High-volume consumer overwhelms data product API; other consumers experience degradation | Configure rate limits per consumer in Gravitee; monitor usage against limits |

## Handoff Summary
When this skill completes, verify:
1. Every data product has owner, SLA, versioned schema, and access API defined
2. Quality rules are executable and integrated into CI/CD
3. Freshness SLA matches the architectural approach (CDC vs batch)
4. Data contracts are version-controlled alongside code
Then proceed to: `data-modeling` (P4.2) for physical schema design, and gate `G-DT` for data architecture review
