---
name: assess-user-impact
description: >
  Quantified per-disposition user-impact analysis: affected users by persona, disrupted journeys with severity, training burden, transition risk, communication-plan threshold, user migration path for Retire/Replace. Output per schemas/rationalization/user-impact-analysis.schema.json. Required for Retire/Replace/Consolidate. Triggers on user impact, persona impact, disposition impact, transition risk, or @assess-user-impact.
agent: opus
allowed-tools:
  - Read
  - Write
  - Grep
---

# assess-user-impact

## Purpose
Quantify the human-side consequences of a proposed disposition so Rationalization recommendations are not made on cost and risk alone. For each candidate disposition, produce a structured analysis of who is affected (by persona and count), which user journeys are disrupted, how much retraining the change demands, how likely users are to adopt the replacement, and — for Retire and Replace — where the displaced users go. The output gates stakeholder communication, HCD review, and Disposition Execution transition planning; no transition plan is produced without a completed user-impact analysis.

## Inputs
- Application catalog entry (JSON per `schemas/discovery/application-catalog-entry.schema.json`) — supplies `user_context` block with persona list and estimated user counts
- Discovery Pass 4 user journey map (markdown or JSON under `artifacts/discovery/<app>/pass-4/user-journeys.*`)
- Disposition recommendation (JSON per `schemas/rationalization/disposition-recommendation.schema.json`) — the disposition being assessed and its replacement target if any
- UX complexity scores for the legacy application and the proposed replacement (Discovery Pass 4 + target-architecture assessment)
- Persona adoption-likelihood and change-tolerance signals from Discovery user interviews or — when absent — role-based heuristics from the application auth model
- Replacement system capability inventory (target architecture or commercial-product spec sheet) for parity assessment

## Outputs
- User impact analysis → `schemas/rationalization/user-impact-analysis.schema.json` (instance template at `assets/user-impact-analysis-template.json`)
- User migration path section (Retire and Replace only) → `assets/user-migration-path-template.md`

## Methodology
1. Resolve the disposition being assessed from the recommendation artifact. If it is `Retain`, still produce an analysis but flag training and transition as `low`/`none`.
2. Enumerate affected personas from Discovery Pass 4 and the catalog `user_context` block. For every persona record `estimated_count` and `evidence_source` as `{artifact}:{section}:{finding-id}`. When Discovery did not identify personas, fall back to role-based heuristics per `references/persona-sourcing-from-discovery.md` and mark `confidence: low`.
3. Walk each journey in the Pass 4 journey map and decide whether the disposition disrupts it. Record disrupted journeys with severity (`critical | high | medium | low`), the affected steps, and whether an alternative path exists.
4. Score training burden by computing the UX complexity delta between legacy and replacement per `references/training-burden-heuristics.md`. Record `level`, `rationale`, and the 1–10 scores with a `delta_explanation`.
5. Score transition risk from adoption likelihood and change tolerance. Unknown signals stay `unknown` — never guess.
6. Compute overall `severity` from the four factor signals using the rubric in `references/severity-rubric.md`. Do not pick a severity by vibe — derive it.
7. Set `transition_plan_required = true` when severity is `critical` or `high`, or when disposition is `Retire`, `Replace`, or `Consolidate`.
8. Build the `communication_plan` block when the threshold in `references/severity-rubric.md` fires; list stakeholders, channels, and a timeline keyed to the disposition cutover date.
9. For `Retire` and `Replace`, fill `user_migration_path` using `assets/user-migration-path-template.md`: target system, data migration required, account migration required, capability parity rating, gap list. Gaps must cite specific missing capabilities — not generic statements.
10. Emit the final JSON and validate against the schema before handoff.

## Gotchas
- **Retire without a migration path is incomplete.** The schema requires `user_migration_path` for Retire and Replace. If the answer is "there is no target system," record that explicitly with `capability_parity: none` and list the capabilities users lose — do not omit the block.
- **Persona counts are estimates, not placeholders.** Every `affected_users` entry needs an `evidence_source` citation. If Discovery lacks persona data, use the role-based fallback from `references/persona-sourcing-from-discovery.md` and mark confidence `low` — do not leave the citation blank.
- **Severity must be computed, not guessed.** Downstream governance uses severity to decide escalation. Derive it mechanically from the four factor signals per `references/severity-rubric.md` and keep the trace in the artifact so reviewers can replay the calculation.
- **UX complexity delta is not "is the new system nicer."** It is a structured comparison of form fields, wizard steps, navigation depth, terminology changes, and removed features. Use the signal checklist in `references/training-burden-heuristics.md`.
- **A disrupted journey with an alternative is still disrupted.** Record `alternative_available: true` but do not zero the severity — the alternative may add friction. Severity reflects the journey change, not the presence of a workaround.
- **Consolidate disrupts two populations.** When the disposition is `Consolidate`, run the analysis for the source application's users *and* note second-order impact on the surviving application's users (training on new data volume, renamed terms, added roles).
- **Retain is not automatically zero impact.** A `Retain` disposition driven by a deprecated runtime, expiring license, or vendor end-of-life still lands on users through forced patches, new auth flows, or dropped integrations. Score those as `low` only after confirming the catalog notes no scheduled runtime change.
- **Communication-plan timing is keyed to cutover, not to the analysis date.** When severity fires the threshold, express `timeline` as offsets from the disposition cutover (`T-90`, `T-30`, `T-7`) so Disposition Execution can sequence announcements correctly.

## Quality Rules
- [ ] Output validates against `schemas/rationalization/user-impact-analysis.schema.json` with zero errors.
- [ ] Every `affected_users` entry has a non-empty `evidence_source` citation in `{artifact}:{section}:{finding-id}` format.
- [ ] When `disposition` is `Retire` or `Replace`, `user_migration_path` is present and includes `target_system`, `capability_parity`, and a `gaps` array (empty array allowed only when parity is `full`).
- [ ] `severity` value traces to the calculation defined in `references/severity-rubric.md` — the rationale fields cite which factor signals drove the result.
- [ ] `transition_plan_required` is `true` whenever `severity` is `critical` or `high`, or disposition is `Retire`, `Replace`, or `Consolidate`.
- [ ] Every `disrupted_journeys` entry names the journey and assigns a severity from the enum — no unlabeled journeys.
- [ ] `training_burden.rationale` references UX complexity delta signals (form fields, wizard steps, navigation depth, terminology, removed features) — not generic adjectives.
- [ ] `transition_risk.adoption_likelihood` and `change_tolerance` are set to `unknown` when source evidence is absent — never guessed.
- [ ] When `communication_plan.required` is `true`, `stakeholders`, `channels`, and `timeline` are all populated.
- [ ] Personas derived from the role-based heuristic fallback are marked `confidence: low` and cite the auth-model artifact as `evidence_source`.

## Common Failure Modes
| Failure Mode | Symptom | Prevention |
|---|---|---|
| Retire recommended without migration path | Disposition Execution cannot build a transition plan; stakeholders learn of cutover with no destination | Enforce the schema's Retire/Replace conditional for `user_migration_path`; record `capability_parity: none` + gap list even when there is no target system |
| Severity guessed rather than computed from factors | Governance escalation fires inconsistently across apps; reviewers cannot replay the decision | Derive severity mechanically from `references/severity-rubric.md`; keep factor-to-severity trace in the `rationale` fields |
| Persona list copied from catalog without evidence citation | Affected-user counts are unchallengeable and often wrong by an order of magnitude | Require `evidence_source` in `{artifact}:{section}:{finding-id}` format for every persona; fall back to the role-based heuristic only with `confidence: low` |
| Training burden scored by impression | Downstream training plans are under- or over-resourced; rollout friction surprises the program | Apply the UX complexity delta checklist in `references/training-burden-heuristics.md` and record both scores + delta explanation |
| Consolidate assessed only for the retiring app's users | Surviving-application user base hit with unannounced terminology and role changes at cutover | For `Consolidate`, produce a second-order impact note covering the surviving app's users in `disrupted_journeys` or a dedicated annotation |

## Evidence Citation Format

All `evidence_source` and `evidence_citation` fields use the Olympus structured citation convention `{artifact}:{section}:{finding-id}` — for example `discovery/payments-app/pass-4/user-journeys.md:personas:persona-03` or `discovery/payments-app/catalog-entry.json:$.user_context`. Citations must resolve to a concrete artifact path; "inferred" or "stakeholder said" without an artifact reference is not acceptable evidence.

## Step-in-Line Context

Rationalization Step 3 runs `assess-user-impact` alongside `recommend-disposition` to fold user impact into the disposition rationale. Step 5 re-runs the skill after `classify-complexity` has assigned an overall complexity, so the transition-plan flag reflects the final disposition set. The two runs may produce different severities if the disposition changed between steps — always emit a fresh artifact rather than editing the earlier one.

## Handoff Summary
When this skill completes, verify:
1. Output validates against `schemas/rationalization/user-impact-analysis.schema.json` with no errors.
2. Every affected-user entry has an evidence citation; Retire/Replace entries include a complete `user_migration_path`.
3. Severity is computed from the rubric (not guessed) and `transition_plan_required` reflects the severity plus disposition rule.
4. Communication plan is populated whenever the threshold is met.

Then proceed to: `recommend-disposition` (Rationalization Step 3) to fold impact into the disposition rationale, and `classify-complexity` (Step 5) to set overall complexity; gate `G-RR` for rationalization review consumes the analysis as required evidence for Retire/Replace/Consolidate dispositions.
