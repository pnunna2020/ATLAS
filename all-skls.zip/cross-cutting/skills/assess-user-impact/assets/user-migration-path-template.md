# User Migration Path

Mandatory section when disposition is `Retire` or `Replace`. Answers: *where do the users go?*

## Application Being Retired / Replaced
- **Name:** `<application-name>`
- **ID:** `<app-id>`
- **Disposition:** `Retire | Replace`

## Target System
- **Target system name:** `<target-system-or-none>`
- **Target system ID or reference:** `<target-app-id | commercial-product | none>`
- **Owner / team:** `<target-owner>`

If there is no target system (pure Retire with no replacement), state `none` and ensure `capability_parity` below is `none` and the `gaps` list enumerates every capability users lose.

## Data Migration
- **Data migration required:** `yes | no`
- **Scope:** `<tables, records, documents, attachments — cite schema/volume>`
- **Owner for data migration:** `<team or skill>`
- **Cutover approach:** `<big-bang | phased | dual-run>`

## Account Migration
- **Account migration required:** `yes | no`
- **Auth source:** `<current IdP / directory>`
- **Target auth source:** `<target IdP / directory>`
- **Access mapping:** `<role-to-role mapping reference or TBD>`

## Capability Parity
- **Rating:** `full | partial | reduced | none`
- **Rationale:** `<one-paragraph comparison grounded in the replacement capability inventory>`

## Gaps
List every capability available in the legacy application that the target system does not cover. Each gap must be specific enough that a stakeholder can decide whether to accept, build, or buy a replacement.

- `<capability-1>` — workaround: `<manual process | other tool | none>`
- `<capability-2>` — workaround: `<...>`
- `<capability-3>` — workaround: `<...>`

If `capability_parity = full`, the gaps list may be empty.

## Evidence Citations
- Replacement capability source: `<artifact>:<section>:<finding-id>`
- Legacy capability source: `<artifact>:<section>:<finding-id>`
