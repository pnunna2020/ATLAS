# Sourcing Personas from Discovery

Personas feed `affected_users[].persona`, `estimated_count`, and `evidence_source`. Every entry needs a citation; never leave `evidence_source` blank.

## Primary: Discovery Pass 4

Pass 4 produces a user-journey map with a `personas` block. Pull:
- Persona name (stable label used across journeys)
- Estimated count (from catalog `user_context` or Pass 4 interview notes)
- Journey participation (maps persona to journeys)

Cite: `discovery/<app>/pass-4/user-journeys.md:personas:<persona-id>`.

## Secondary: Catalog `user_context`

When Pass 4 lacks counts, use `user_context.personas[]` and `user_context.estimated_users`. Cite: `discovery/<app>/catalog-entry.json:$.user_context`.

## Fallback: Role-Based Heuristic

When Discovery did not identify personas, derive from the auth model:

1. Enumerate every role, group, or permission set (Spring Security roles, DB grants, AD groups).
2. Collapse synonyms (`ADMIN`, `Administrator`, `sys_admin` = one persona).
3. Estimate count from the user directory — active accounts per role in the last 90 days.
4. Name after dominant role: `<App> Admin`, `<App> Reviewer`, `<App> Read-Only User`.
5. Mark `confidence: low` and cite `discovery/<app>/auth-model.<ext>:<role-name>`.

## Zero Signal

If no source yields personas, emit:
- `persona: "Unknown user population"`
- `estimated_count: 0`
- `confidence: low`
- `evidence_source: "discovery/<app>:no-user-context-available"`

Flag the gap in handoff so Discovery revisits — schema `minItems` enforces one entry.

## What Not To Do

- Do not invent personas from domain knowledge without a citation.
- Do not reuse personas from a sibling application without verifying overlap.
- Do not collapse distinct roles because counts are similar — training burden differs by role.
