# Training Burden Heuristics

Score training burden from a structured UX complexity delta — not impression. Burden drives `training_burden.level` and feeds `severity`.

## UX Complexity Score (1–10)

Score legacy and replacement. Higher = harder to learn.

| Score | Profile |
|---|---|
| 1–3 | Single-screen, <10 fields, <2 nav levels, no conditional branches |
| 4–6 | Multi-screen, 10–25 fields, 3–5 wizard steps, moderate conditionals |
| 7–8 | Complex, 25–60 fields, multi-role handoffs, nested nav, domain jargon |
| 9–10 | Specialized, 60+ fields, multi-wizard, rule-driven screens |

## Signal Checklist

For each application, record:

- Total form-field count across primary workflows
- Wizard / multi-step-page step count
- Maximum navigation depth (clicks from home to deepest task)
- New domain terminology count (terms absent from legacy)
- Removed features (legacy capabilities missing from replacement)
- Conditional-display rules and role-specific screen count

## Computing the Delta

1. `delta = replacement_score - legacy_score`.
2. Count unfavorable signals: fields added, steps added, depth increased, new terms >5, removed features.

| Burden | Trigger |
|---|---|
| `high` | `delta >= 3`, OR `>= 4` unfavorable signals, OR `>= 1` removed feature without workaround |
| `medium` | `delta` in `[1, 2]`, OR `2–3` unfavorable signals |
| `low` | `delta <= 0` and `<= 1` unfavorable signal |
| `none` | Replacement preserves existing UI (e.g. Replatform, no UX change) |

## Rationale Template

Record `training_burden.rationale` as:

> Legacy `<N>`, replacement `<M>`, delta `<D>`. Unfavorable: fields `<from>→<to>`, steps `<from>→<to>`, depth `<from>→<to>`, new terms `<count>`, removed `<list>`.

## What Not To Do

- Do not score "modern = easier" — modern UIs often add steps.
- Do not score only the happy path — include role-specific and error-recovery flows.
- Do not count renamed-but-equivalent buttons as new terminology.
- Do not use a composite score without recording underlying signals.
