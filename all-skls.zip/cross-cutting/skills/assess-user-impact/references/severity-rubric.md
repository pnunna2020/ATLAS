# Severity Rubric

Compute overall `severity` mechanically from four factor signals: affected-user scale, disrupted-journey severity, training burden, and transition risk. Do not assign by impression.

## Factor Signals

| Factor | High | Medium | Low |
|---|---|---|---|
| Affected-user scale | >1,000 users or any Tier 1 persona | 100–1,000 | <100, internal only |
| Worst disrupted journey | critical | high | medium / low |
| Training burden | high | medium | low / none |
| Transition risk | high | medium | low |

## Severity Calculation

Score each: High=2, Medium=1, Low=0. Sum across four factors (max 8).

| Total | Severity |
|---|---|
| 6–8 | critical |
| 4–5 | high |
| 2–3 | medium |
| 0–1 | low |

## Forced-Critical Triggers

Severity is `critical` regardless of sum when any hold:
- Any disrupted journey has `severity: critical`.
- Disposition is `Retire` and `capability_parity` is `none` or `reduced` with no documented workaround.
- Affected-user scale, training burden, and transition risk are all High.

## Disposition Overrides

- `Retire` or `Replace` with `capability_parity: full` may drop to `medium` if all other factors are Low.
- `Retain` defaults to `low` unless a second-order change (licensing, deprecated runtime) disrupts a journey.

## Communication-Plan Threshold

`communication_plan.required = true` when:
- Severity is `critical` or `high`, OR
- Affected-user scale is High regardless of severity, OR
- Disposition is `Retire` or `Replace` and `capability_parity` is not `full`.

## Transition-Plan Flag

`transition_plan_required = true` when severity is `critical` or `high`, OR disposition is `Retire`, `Replace`, or `Consolidate`.

## Recording the Trace

In `training_burden.rationale` and `transition_risk.rationale`, cite which factor signal levels drove the score so reviewers can replay the calculation.
