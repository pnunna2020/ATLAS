---
name: multi-portal-architecture-analyzer
description: >
  Analyze repositories that host multiple distinct UI portals —
  typically two or three Angular/React/Blazor apps sharing a common
  component library, served to different user populations with
  different auth contexts. DMS is the canonical ATLAS case: an
  `src/ui/` workspace hosts `dms_web_faa` (FAA staff portal),
  `dms_web_designee` (public designee portal), and `dms-web-shared`
  (shared component library). Each portal has its own auth,
  routing, and deploy target; the shared library must build first.
  Modernization must preserve the two-audience separation OR
  consolidate with role-based UI — a strategic decision that
  Discovery must surface explicitly. Runs as a Discovery conditional
  skill when the repo's UI tree has multiple Angular projects in
  one workspace (`angular.json` with >1 application project) or
  equivalent in React/Blazor. Triggers on multi-portal detection,
  shared-component-library analysis, or
  @multi-portal-architecture-analyzer.
agent: sonnet
allowed-tools:
  - Read
  - Write
  - Grep
  - Glob
validation_commands:
  - "python -m olympus.validators.schema_validator portal-inventory.json"
  - "python -m olympus.validators.schema_validator portal-shared-library-graph.json"
  - "python -m olympus.validators.schema_validator portal-auth-context-findings.json"
supported_stacks:
  - angular
  - react
  - blazor
  - typescript
  - monorepo-ui
anti_target_stacks:
  - single-portal
  - server-rendered
  - static-site
failure_classes:
  - portal-consolidation-vs-preserve-decision-missed
  - shared-library-build-order-wrong
  - cross-portal-auth-context-leak
  - public-vs-internal-portal-confused
  - shared-lib-cyclic-dependency
benchmark_tags:
  - discovery-frontend
  - multi-portal-inventory
  - shared-component-library
  - audience-segmented-ui
---

# multi-portal-architecture-analyzer

## Purpose
Inventory multi-portal UI workspaces and surface the strategic
modernization question: keep portals separate (different audiences,
different auth, different URLs) or consolidate to role-based single
portal. Without this finding, Rationalization cannot make the
disposition call correctly.

## Inputs
- Repository with UI workspace config (`angular.json`,
  `package.json` workspaces, `nx.json`, `lerna.json`).
- Application catalog entry.

## Outputs
- `portal-inventory.json` — per portal: `{portal_name, type
  (application | library), root_path, source_root, audience
  (faa_staff | designee | public | admin | internal), auth_mode,
  deploy_target}`.
- `portal-shared-library-graph.json` — library-to-consumer edges.
- `portal-auth-context-findings.json` — per portal: auth mode,
  SSO integration, token storage, cross-portal-leak risks.

## Methodology
1. Parse workspace config (`angular.json` `projects` section).
2. Classify each project (`application` vs `library`).
3. Infer audience from project name + auth config.
4. Build shared-library consumption graph.
5. Detect auth context per portal (interceptors, guards, token
   storage).
6. Emit findings: build order, cross-portal leak risks,
   consolidate-vs-preserve decision points.

## Tech-Stack Dispatch

No external references.

## Gotchas
- Angular workspace can have ANY number of application and library
  projects.
- Shared library must build BEFORE consumers. CI must enforce.
- Two apps in one workspace can accidentally share token storage
  keys — cross-portal leak if keys collide.
- DMS `dms-web-shared` contains layout + services + pipes used by
  both apps; import boundaries are easily crossed.
- Consolidation implies ONE auth provider handling both audiences
  via roles — strategic change.

## Quality Rules
- [ ] Every portal has an inventory entry.
- [ ] Shared library consumers enumerated.
- [ ] Auth context per portal captured.
- [ ] Cross-portal-leak risks flagged.
- [ ] Build order recommendation emitted.
- [ ] Every record cites `{repo}:{file}:{line}`.

## Common Failure Modes

| Failure Mode | Symptom | Prevention |
|---|---|---|
| Portals consolidated without auth plan | Target breaks public access | Emit consolidate-vs-preserve with trade-offs |
| Shared library cyclic dep | Library imports from consumer | Detect imports in lib/* from app/* |
| Build order omitted | Consumer builds before library | Emit explicit build-order recommendation |

## Handoff Summary
Multi-portal workspace inventoried; consolidation decision
surfaced. Proceed to `disposition-recommender` and
`angular-spa-discovery-patterns`.

## References
None.

## Changelog
- 0.1.0 (2026-05-07) — Initial skill. Authored as ATLAS-R-19.
