# OCR Readiness Rubric — 8 Factors

Weighted composite: `overall = round(sum(score_i * weight_i))`. Weights sum to 1.0.

| Factor | What agent measures | 1 (poor) | 3 (fair) | 5 (excellent) | Weight |
|---|---|---|---|---|---|
| scan-resolution | DPI from TIFF header; effective DPI after descaling | <150 DPI | 200–249 DPI | >=300 DPI | 0.15 |
| compression-artifacts | Group IV block noise, speckle density | Heavy speckle, illegible edges | Visible artifacts, readable | Clean; no lossy artifacts | 0.10 |
| color-depth | Bit depth; bitonal vs grayscale vs color | 1-bit w/ thresholding errors | 1-bit clean or 8-bit gray | 8-bit gray or 24-bit color, good contrast | 0.05 |
| skew-and-rotation | Deskew angle; rotation-tag correctness | >5° skew or wrong rotation | 1–3° skew, correctable | <1° skew, correct orientation | 0.10 |
| handwriting-presence | % of page covered by handwriting | >40% | 10–20% | 0% pure machine print | 0.20 |
| form-structure | Consistent form templates, field positions | Free-form; no template | Mixed; partial templates | Fixed templates, known field coords | 0.15 |
| language-consistency | Dominant-language coverage | Mixed langs, many scripts | Mostly English | 100% English, single script | 0.10 |
| text-density | Chars/page vs page area | <200 chars | 500–1500 chars | >1500 chars, full text | 0.15 |

Scoring protocol: two reviewers score each sampled image blind, Cohen's
kappa >= 0.75 per factor, disagreements > 1 point resolved by third reviewer.

Weight tuning: defaults optimize for records-management corpora with mixed
handwriting. Profiles may override weights; override must sum to 1.0 and
be recorded in the assessment `basis` field.

Composite integer 1–5 maps to: 1 = reject, 2 = human-in-loop only,
3 = viable with multi-engine, 4 = viable with single best-fit engine,
5 = viable with any major engine.
