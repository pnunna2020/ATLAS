# Unisys InfoImage Extraction Notes

InfoImage eWorkflow does not store records as PDFs on a file share. The
FAA RMS 146M corpus sits as TIFF Group IV payloads inside a Unisys
proprietary container; "records" are virtual — work packages assembled
on the fly from folio lists (Industry Day Slide 35).

## Storage model
- Physical: TIFF Group IV pages (bitonal, CCITT Fax 4)
- Container: eWorkflow repository; images chunked across folios
- Index: metadata tables map folio_id -> image_path and
  work_package_id -> ordered folio list
- Legacy read path: BlackIce print driver + Accusoft ImageXpress wrapper;
  desktop viewer assembles packages

## Extraction options (preferred first)
1. **Bulk export via Unisys SDK / COTS tool.** Writes raw Group IV TIFFs
   to a staging share with a manifest JSON. Best for migration.
2. **DB-indexed file-share access.** Query metadata DB for folio_id ->
   physical path; read TIFF directly from the storage array.
3. **Vendor API.** Rate-limited; only for targeted retrieval.
4. **Desktop viewer scraping.** Do not use. Re-rasterizes, loses fidelity,
   breaks on driver updates.

## Pitfalls
- **BlackIce print driver** re-rasterizes and loses original Group IV
  bits. Avoid any path through it.
- **Accusoft ImageXpress is read-path only.** The viewer opens
  proprietary-tagged TIFFs; raw file reads from the array give the
  unwrapped Group IV payload.
- **Folio ordering is not filename-sortable.** The DB holds the ordered
  folio list per work package. Without it, records are scrambled.
- **Metadata lives in the DB, not the TIFF.** Tags rarely carry doc-type
  or case-ID. Join eWorkflow tables.
- **No materialized PDF.** Cost model must include PDF assembly (folio
  lookup + concat + OCR) per record, not per image.

## Validation
Round-trip 25 sampled images through the chosen path before declaring
the access method viable. Confirm folio grouping and doc-type lookup
match the viewer render. Any mismatch is a critical risk finding.
