# Migration Sequencing Strategy

Pick `prioritization_basis` deliberately. Basis drives wave composition,
risk exposure, and cost curve. Default for records corpora: retention
first, then business-criticality.

## Picking the basis

| Basis | When to pick | Wave 1 |
|---|---|---|
| regulatory-retention | Corpus spans retention boundaries; past-retention shrinks scope 20–40% | Past-retention -> Disposition. Wave 1 = in-retention near boundary |
| recency | Active caseload cuts over first | Newest N years, desc by date_filed |
| access-frequency | Access logs show long-tail usage | Top decile by access count |
| business-criticality | Some classes block mission workflows | Mission-critical doc types first |
| risk-descending | PII must exit legacy store first | Highest-sensitivity classes; segregated |
| size-ascending | Infra untested; need quick wins | Smallest strata first |

## Wave composition rules
- Wave 1 <=10% of corpus and <=12 weeks. Proves the pipeline.
- Each wave has a homogeneous strata set where engine and cost-per-page
  are stable. Mixing readiness tiers breaks throughput forecasts.
- Every wave declares `dependencies`: prior-wave OCR index, trained
  inference model, destination schema deployed.
- Parallel waves allowed only when `dependencies` is empty. Validator
  rejects implicit ordering.

## Retention-first default (FAA RMS)
Run a retention-boundary filter before wave composition. Past-retention
records route to Disposition Execution. Wave 1 focuses on in-retention
records nearest the boundary to reduce legal exposure.

## Risk-descending exceptions
When `risk-descending` is chosen, Wave 1 needs a dedicated secure
transport path and segregated OCR engine tenancy. Do not mix PII and
non-PII in the same OCR batch.

## Duration sizing
`duration = images/weekly_throughput + 2wk validation + 2wk remediation`.
Throughput is bounded by the slower of engine rate limit and destination
ingest rate.
