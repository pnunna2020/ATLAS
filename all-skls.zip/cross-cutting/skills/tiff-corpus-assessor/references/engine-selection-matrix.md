# OCR Engine Selection Matrix

Pick engine by dominant readiness factor + doc type + cost constraint.
Cite the matrix row in the assessment `recommended_engine` justification.

| Row | Dominant condition | Doc type | Engine | $/page | Notes |
|---|---|---|---|---|---|
| R1 | form-structure >=4, handwriting <=2 | Structured forms | amazon-textract | $0.0015 text / $0.05 forms | FORMS/TABLES shine on fixed templates |
| R2 | form-structure 3–4, semi-structured | Letters, invoices | google-document-ai | $0.005 – $0.065 | Specialized parsers handle semi-structured |
| R3 | MS-heavy stack, hybrid cloud | Office/PDF/receipts | azure-document-intelligence | $0.001 – $0.050 | Use when Azure is the target platform |
| R4 | handwriting >=3 OR 1980s–90s records | Handwritten, signed, ledgers | abbyy | $0.010 – $0.030 | FineReader/FlexiCapture for handwriting, aged paper |
| R5 | open-source mandate OR pilot | Clean machine print | tesseract | ~$0 (compute only) | Only when readiness >=4; high TCO at scale |
| R6 | readiness <=3 OR corpus crosses R1–R4 | Mixed / heterogeneous | multi-engine-ensemble | $0.010 – $0.040 blended | Route per stratum; vote or confidence-weighted merge |

Cost override: if budget < $0.005/page and corpus >100M images, R1 or R3
dominate on unit cost. Drop to R5 only if readiness >=4 across all strata.

Handwriting rule: any stratum with handwriting factor >=3 forces R4 or R6.
Never select R1 or R5 alone for handwriting-heavy corpora.

FAA RMS 146M mixed corpus default: R6 (multi-engine-ensemble) with R4 for
pre-1995 strata, R1 for structured-form strata, R2 for correspondence.
