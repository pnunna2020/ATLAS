# Sampling Plan Worksheet

Fill this worksheet before pulling the sample. The worksheet becomes the
`sampling_strategy` block of the corpus assessment artifact.

## 1. Population
- Corpus ID:
- Total image count (with confidence):
- Year range covered (earliest – latest):
- Source applications contributing to the corpus:

## 2. Strata definitions
List each stratum as `name :: selector :: estimated_population`. A stratum is
a cell of the cross-product {doc-type} x {decade} x {source-app} (default) or
whatever dimensions the corpus actually varies along.

| # | Stratum name | Selector (SQL / index filter) | Population estimate |
|---|---|---|---|
| 1 |  |  |  |
| 2 |  |  |  |
| 3 |  |  |  |

## 3. Confidence level and margin of error
- Confidence level: 0.95 (default) — record the chosen value, 0.80 – 0.99
- Margin of error: e.g., +/- 3% per stratum
- Proportion assumed for sizing: 0.5 (worst case) unless prior data exists

## 4. Sample size per stratum
Compute via `n = (Z^2 * p * (1-p)) / e^2` then adjust for finite population.
Minimum sample size per stratum is 100 (schema floor). For rare strata,
oversample to 100 and note the weight correction in `rationale`.

| # | Stratum | Computed n | Adjusted n | Notes |
|---|---|---|---|---|
| 1 |  |  |  |  |
| 2 |  |  |  |  |

Total sample size (sum of adjusted n): _____

## 5. Sampling method
Pick one and justify:
- [ ] stratified-random — default; works when strata are enumerable
- [ ] temporal — when degradation correlates strongly with year
- [ ] by-doc-type — when doc-type is the dominant source of variance
- [ ] by-source-app — when different source apps used different scanners
- [ ] pure-random — only if a prior stratification study exists

Rationale:

## 6. Observer protocol
- Two independent reviewers score each sampled image against the 8-factor rubric
- Reviewers blind to each other's scores
- Cohen's kappa target: >= 0.75 per factor
- Disagreements > 1 point resolved by a third reviewer
- All scores, reviewer IDs, and timestamps logged to `sample-scoring.jsonl`

## 7. Access path validation
Before pulling the full sample, extract 25 images via the documented
production access path (NOT the vendor viewer) and confirm:
- [ ] Extraction succeeded without manual intervention
- [ ] Folio-to-record grouping preserved
- [ ] Source-app provenance preserved
- [ ] Round-trip view matches vendor viewer render

If any check fails, stop. The access-method assumption is wrong and the
cost model built on it is wrong.
