---
name: tiff-corpus-assessor
description: >
  Feasibility and sequencing analysis for large legacy image corpora. Produces sampling strategy, weighted OCR-readiness score, engine recommendation, metadata inference plan, migration waves with cost projection. Engineered for FAA RMS 146M-TIFF / Unisys InfoImage problem. Output per schemas/discovery/tiff-corpus-assessment.schema.json. Triggers on TIFF corpus, image migration, OCR feasibility, Unisys InfoImage, document archive, or @tiff-corpus-assessor.
agent: opus
allowed-tools:
  - Read
  - Write
  - Grep
  - Bash
---

# tiff-corpus-assessor

## Relationship to OCR Pre-Pass
This skill produces the **feasibility assessment** (sampling plan, readiness score, engine recommendation, cost projection) — it does **not** OCR the corpus itself. When the doc-only Discovery agent encounters a tree of scanned images, the `olympus.tools.ocr_adapter.ocr_tiff_corpus` pre-pass turns the images into `.txt` siblings plus an `ocr-corpus-index.json` artifact before this skill runs; the assessor then consumes that index to characterize readiness and sequence migration waves.

## Purpose
Assess a legacy image corpus end-to-end before any modernization commitment: quantify scale, design a defensible sample, score OCR readiness, recommend an OCR engine, plan metadata inference, and sequence migration into waves with cost projections. This skill is engineered for the FAA RMS Phase 2 problem — 146M+ TIFFs held in Unisys InfoImage eWorkflow where "no PDF of a given record sits on a storage device; work packages are assembled on the fly" (Industry Day Slide 35) and no OCR has been run across the corpus (DeepSearch §2.2). It produces the feasibility artifact that feeds Rationalization disposition for content-heavy apps and Architecture data-line planning.

## Inputs
- Corpus scale inventory (image count, GB, year range, growth rate) — operator-supplied or harvested from source-system DB
- Source-system metadata (system name, store type, wrapper format, access method) — e.g., Unisys InfoImage eWorkflow with proprietary TIFF wrapper
- Structured metadata catalog (if any) exported from the source application (indices, folios, doc-type codes)
- Sample TIFF set (typically 1K–10K images) extracted per the sampling plan, with source-app provenance preserved
- Retention schedule and regulatory-retention boundaries for records classified in the corpus
- Cost constraints and target cutover horizon from program stakeholders
- Tech-stack context from `analyze-application` Pass 1 where the source system is catalogued

## Outputs
- Corpus assessment artifact per `schemas/discovery/tiff-corpus-assessment.schema.json`
- Sampling plan → `assets/sampling-plan-worksheet.md`
- Corpus assessment YAML draft → `assets/corpus-assessment-template.yaml`
- OCR-readiness rubric application trace → `references/ocr-readiness-rubric.md` (weights + per-factor scoring evidence)
- Engine recommendation with decision trace → `references/engine-selection-matrix.md`
- Migration wave plan with prioritization basis and inter-wave dependencies

## Methodology
1. Confirm scale. Read operator-supplied count/size or query the source-system DB. Record `image_count_estimate` with a mandatory `estimate_confidence` (exact / high / medium / low) — never emit a raw count without a confidence attribute.
2. Characterize the source system. Identify `store_type` and `wrapper_format`. If `unisys-infoimage`, load `references/unisys-infoimage-extraction.md` before any sampling — the wrapper is not plain TIFF and naive extraction fails.
3. Design the sampling strategy. Fill `assets/sampling-plan-worksheet.md`: pick `method` (stratified-random default), define strata (doc-type × decade × source-app), set `confidence_level` (0.95 default) and margin of error, compute `sample_size` per stratum. Rationale is mandatory.
4. Pull the sample through the documented access path (not the vendor viewer). Preserve folio grouping and per-image provenance.
5. Apply the 8-factor OCR readiness rubric per `references/ocr-readiness-rubric.md`. Score each factor 1–5 with its documented weight; compute the weighted composite and round to an integer 1–5.
6. Select the OCR engine via `references/engine-selection-matrix.md`. Cite the matrix row that produced the recommendation. If no single engine dominates, pick `multi-engine-ensemble` and record the split.
7. Build the metadata inference plan. List `available_structured_metadata` (fields already populated in the source index) and `inferable_from_content` (must be extracted by OCR + classifier/LLM). Choose `inference_strategy` based on field-type coverage.
8. Sequence migration. Pick `prioritization_basis` per `references/migration-sequencing-strategy.md`. Compose waves with explicit `image_count_estimate`, `selection_criteria`, `estimated_duration_weeks`, and `dependencies` between waves.
9. Project cost. Compute OCR cost (page count × engine $/page), monthly storage, and total migration cost. Record the `basis` string so downstream can recompute under new assumptions.
10. Emit `risk_findings` with severity and mitigation for anything that could invalidate the plan (wrapper access, handwriting density, retention ambiguity, access-frequency data missing).

## Unisys InfoImage TIFF-Group-IV Wrapper Handling
The FAA RMS corpus is not plain TIFF on a file share. Images are stored as TIFF Group IV payloads inside a Unisys proprietary container keyed to eWorkflow work-package definitions. A "record" has no materialized PDF — work packages are assembled on the fly from folio lists. The standard read path uses a BlackIce print driver plus Accusoft ImageXpress on the client, which means treating the vendor viewer as the access API will neither scale nor produce clean extraction. Use the bulk-export / SDK / DB-indexed file-share paths documented in `references/unisys-infoimage-extraction.md`, extract raw Group IV TIFFs, reconstruct the folio-to-record mapping from the eWorkflow metadata tables, and validate a round-trip on the sample before declaring the access method viable. Any plan that depends on the vendor viewer as the extraction channel must be flagged as a `critical` risk finding.

## Gotchas
- **Vendor SDK is never the only access method.** InfoImage exposes bulk-export and DB-indexed file-share paths. If the plan assumes the desktop viewer is the extraction channel, it will not scale past pilot and the cost model is wrong.
- **No PDF exists on disk.** The "record" is virtual. Budget the assembly step (folio lookup + concatenation + OCR) — do not assume one-image-per-record.
- **Scale without confidence is a lie.** 146M is the reported number; treat it as `medium` confidence until a DB count confirms. Missing confidence breaks downstream cost projection.
- **Sample size ≠ sample quality.** A 10K pure-random sample across a 40-year archive hides decade-specific degradation. Stratify by doc-type × decade × source-app.
- **OCR cost without a sample is speculation.** Ballpark $/page × 146M is a 7-figure error bar. Require the sample-based readiness score and engine selection before emitting `cost_projection`.
- **Handwriting collapses accuracy.** Any stratum with handwriting density >20% forces ABBYY or multi-engine ensemble — Textract and Tesseract will not hit target accuracy.
- **Retention boundary beats recency.** Records past the regulatory retention date should be dispositioned (destroy/archive), not migrated. Retention-first prioritization often shrinks the corpus by 20–40%.
- **Wave dependencies are not decorative.** If Wave 2 depends on Wave 1's OCR-derived index to route, declare it — parallel execution will corrupt the metadata index.

## Quality Rules
- [ ] `scale_estimate.image_count_estimate` has an `estimate_confidence` attribute (exact / high / medium / low) — never bare
- [ ] OCR-readiness composite is computed from the 8 documented factors with weights summing to 1.0 per `references/ocr-readiness-rubric.md`
- [ ] `recommended_engine` cites the row of `references/engine-selection-matrix.md` that justifies it
- [ ] `sampling_strategy` has an explicit `confidence_level` in [0.8, 0.99] and a `rationale` string
- [ ] Every wave enumerates its `dependencies` array (empty list allowed for Wave 1, but the field must be present)
- [ ] `prioritization_basis` is one of the enum values and matches the rationale in `references/migration-sequencing-strategy.md`
- [ ] Metadata inference plan separates `available_structured_metadata` from `inferable_from_content` — no field appears in both
- [ ] `cost_projection.basis` string names the $/page, $/GB-month, and sample size used in the estimate
- [ ] If `store_type == unisys-infoimage`, the assessment references `references/unisys-infoimage-extraction.md` and does not list `access_method: unknown`
- [ ] Every risk finding has a `severity` and a concrete `mitigation` — no `TBD` mitigations

## Common Failure Modes
| Failure Mode | Symptom | Prevention |
|---|---|---|
| Vendor SDK treated as only access method | Pilot succeeds on 1K images via desktop viewer; production bulk-export path was never tested; cost model off by 10x | Require the assessment to document bulk-export / DB-indexed file-share path and round-trip a sample through it before sign-off |
| OCR cost estimated without sample | 7-figure cost projection based on marketing $/page × headline image count; actual engine misses target accuracy on handwriting strata | Block `cost_projection` emission until `ocr_readiness.factors` is populated from a real stratified sample |
| Pure-random sampling over a 40-year archive | OCR-readiness score hides decade-specific degradation; Waves designed for avg quality fail on 1980s microfiche-scanned folios | Enforce stratified-random by doc-type × decade × source-app; `pure-random` allowed only when a prior stratification study exists |
| Retention-past records migrated anyway | 20–40% of corpus moved, indexed, OCR'd, then dispositioned for destruction; cost and PII exposure both wasted | Run retention-boundary filter before wave composition; records past retention route to Disposition Execution, not migration |
| Waves run in parallel without declared dependencies | Metadata index corrupted because Wave 2 assumed Wave 1's OCR-derived classifications that weren't yet written | Require every wave to enumerate `dependencies`; validator rejects waves with implicit ordering |

## Handoff Summary
When this skill completes, verify:
1. Assessment artifact validates against `schemas/discovery/tiff-corpus-assessment.schema.json`.
2. OCR-readiness composite is reproducible from the per-factor scores and documented weights.
3. Recommended engine cites a specific row of the engine-selection matrix.
4. Sampling strategy has confidence level, margin of error, and strata definition.
5. Waves have dependencies enumerated and prioritization basis matches the strategy reference.
6. Cost projection includes a `basis` string that names $/page, $/GB-month, and sample size.

Then proceed to: `analyze-application` for the content-heavy-app Rationalization disposition pass, and gate `G-DC` for discovery completeness review. Data-line handoff is to Architecture/Data planning where the chosen OCR engine and wave schedule become inputs to target-state storage and indexing design.
