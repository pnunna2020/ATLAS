# NATURAL/ADABAS Analysis Patterns

Reference for Analyze Application when analyzing Software AG NATURAL 4GL applications
backed by ADABAS databases. NATURAL is a 4GL (fourth-generation language) developed by
Software AG, tightly integrated with the ADABAS inverted-list database. It runs on
mainframe (z/OS, z/VSE, BS2000) and some midrange/Linux environments.

## Technology Detection

Confirm NATURAL/ADABAS by checking for:
- `.NSP` files (NATURAL source programs)
- `.NSN` files (NATURAL subprograms)
- `.NSS` files (NATURAL subroutines)
- `.NSH` files (NATURAL helproutines)
- `.NSM` files (NATURAL maps / screen definitions)
- `.NSL` files (NATURAL Local Data Areas)
- `.NSG` files (NATURAL Global Data Areas)
- `.NSA` files (NATURAL Parameter Data Areas)
- `.NSC` files (NATURAL copycodes)
- `.NS7` files (NATURAL class definitions, newer versions)
- `DEFINE DATA` statements in source (the universal NATURAL program header)
- ADABAS DDM (Data Definition Module) references in source
- `NATPARM` or `NATCONF` configuration files
- JCL referencing `NATBATCH`, `NATRJE`, or `CMSYNIN` DD statements
- Libraries named `SYSLIB`, `SYSTEM`, or matching site naming conventions (e.g., `RMSLIB`, `CAISLIB`)

### Version Detection

NATURAL version determines available features:
- **NATURAL 4.x and earlier**: Tag-based syntax only, no OO features
- **NATURAL 6.x**: Structured mode introduced, objects (NaturalONE IDE)
- **NATURAL 8.x/9.x**: Unicode support, XML handling, web services
- Check `*NATVERS` system variable or `CMSYNIN` PARM for version indicators
- Check for `OPTIONS` statement at top of program: `OPTIONS STRUCTURED` vs `OPTIONS REPORTING`

## NATURAL Program Structure

### Program Types and Their Roles

| Type | Extension | Purpose | Key Characteristic |
|------|-----------|---------|-------------------|
| Program | `.NSP` | Main executable entry point | Can be invoked from command line or menu |
| Subprogram | `.NSN` | Called module with parameter interface | `DEFINE DATA PARAMETER` defines contract |
| Subroutine | `.NSS` | Callable routine, can access caller's data | Shares caller's GDA; looser coupling than subprogram |
| Helproutine | `.NSH` | Context-sensitive help display | Invoked by PF-key from maps; may contain validation |
| Copycode | `.NSC` | Source-level include (like C `#include`) | Inlined at compile time; no separate compilation |
| Map | `.NSM` | 3270 screen definition (layout + field attributes) | Visual layout; can contain processing rules |
| Local Data Area | `.NSL` | Data structure definition scoped to one program | Reusable field definitions; referenced via `DEFINE DATA LOCAL USING` |
| Global Data Area | `.NSG` | Shared data structure across programs in session | Persists across CALLNAT/PERFORM within session |
| Parameter Data Area | `.NSA` | Parameter contract for subprogram interfaces | Defines input/output parameter list |
| Class | `.NS7` | Object-oriented class (NATURAL 6+) | Rare in legacy; indicates partial modernization |
| Function | `.NS8` | Functional module (NATURAL 8+) | Returns a value; newer codebases |

### Library Organization

NATURAL organizes code into **libraries** (logical containers, not directories):
```
SYSLIB          <- site-specific shared library
SYSTEM          <- Natural system library (read-only)
RMSLIB          <- application library (example: RMS system)
CAISLIB         <- application library (example: CAIS system)
TESTLIB         <- development/test library
```

**Steplib chains** determine search order when a CALLNAT references a module not
found in the current library:
```
RMSLIB -> SYSLIB -> SYSTEM
```
This means the same subprogram name in RMSLIB overrides the one in SYSLIB. Steplib
chains are critical for understanding which version of shared code actually executes.
Check `NATPARM` configuration for steplib definitions.

### Detection Indicators in Source

Scan source files for these NATURAL-specific keywords:
```natural
DEFINE DATA                   /* Every NATURAL program starts with this */
  LOCAL                       /* Local variable declarations */
  GLOBAL USING gda-name       /* Global Data Area reference */
  PARAMETER USING pda-name    /* Parameter Data Area reference (subprograms) */
  LOCAL USING lda-name        /* Local Data Area reference */
END-DEFINE                    /* Closes DEFINE DATA block */

CALLNAT 'subprogram-name'    /* Call to external subprogram */
PERFORM subroutine-name      /* Call to internal subroutine */
FETCH 'program-name'         /* Transfer control to another program (no return) */
FETCH RETURN 'program-name'  /* Transfer control with return capability */
STACK TOP DATA               /* Push data onto session stack (inter-program data passing) */
INPUT USING MAP 'map-name'   /* Display 3270 screen */
```

## Where Business Logic Hides

### 1. DECIDE ON / DECIDE FOR (Multi-Branch Logic)
NATURAL's equivalent of switch/case. Often contains core business rules:
```natural
DECIDE ON FIRST VALUE OF AIRCRAFT-TYPE
  VALUE 'FIXED'
    PERFORM PROCESS-FIXED-WING
  VALUE 'ROTOR'
    PERFORM PROCESS-ROTORCRAFT
  VALUE 'BALLOON' 'AIRSHIP'
    PERFORM PROCESS-LIGHTER-THAN-AIR
  NONE VALUE
    PERFORM PROCESS-UNKNOWN-TYPE
END-DECIDE
```
`DECIDE FOR` evaluates conditions (not values) and executes the FIRST or EVERY
matching branch:
```natural
DECIDE FOR FIRST CONDITION
  WHEN FLIGHT-HOURS > 10000
    MOVE 'ATP' TO CERT-LEVEL
  WHEN FLIGHT-HOURS > 1500
    MOVE 'COMMERCIAL' TO CERT-LEVEL
  WHEN FLIGHT-HOURS > 250
    MOVE 'INSTRUMENT' TO CERT-LEVEL
  WHEN FLIGHT-HOURS > 40
    MOVE 'PRIVATE' TO CERT-LEVEL
  WHEN NONE
    MOVE 'STUDENT' TO CERT-LEVEL
END-DECIDE
```
**Critical distinction**: `DECIDE FOR FIRST` stops at first match; `DECIDE FOR EVERY`
executes ALL matching branches (accumulative logic). Misinterpreting this changes
business behavior.

### 2. COMPUTE / MOVE Statements (Calculations and Transformations)
```natural
COMPUTE FEE-AMOUNT = BASE-FEE * WEIGHT-FACTOR + SURCHARGE
MOVE EDITED FEE-AMOUNT (EM=ZZZ,ZZ9.99) TO DISPLAY-FEE
COMPRESS LAST-NAME ',' FIRST-NAME INTO FULL-NAME WITH DELIMITER ' '
EXAMINE FULL-NAME FOR ' ' REPLACE WITH '-'
```
`COMPRESS` and `EXAMINE` are string manipulation verbs that often encode
formatting rules invisible in other analysis approaches.

### 3. AT BREAK (Control Break Processing)
Report generation logic that fires when a sort key value changes:
```natural
READ AIRMEN-FILE BY CERT-TYPE
  DISPLAY AIRMAN-ID CERT-TYPE CERT-STATUS
  AT BREAK OF CERT-TYPE
    WRITE 'Subtotal for' OLD(CERT-TYPE) ':' COUNT(AIRMAN-ID)
  END-BREAK
  AT END OF DATA
    WRITE 'Grand Total:' COUNT(AIRMAN-ID)
  END-ENDDATA
END-READ
```
`AT BREAK` implicitly tracks old values and computes aggregates (`COUNT`, `SUM`,
`AVER`, `MIN`, `MAX`, `NMIN`, `NMAX`). These become explicit GROUP BY / window
functions in SQL.

### 4. IF/ELSE Chains (Conditional Business Rules)
```natural
IF CERT-EXPIRY-DATE < *DATX
  IF GRACE-PERIOD-DAYS > 0
    COMPUTE EFFECTIVE-EXPIRY = CERT-EXPIRY-DATE + GRACE-PERIOD-DAYS
    IF *DATX > EFFECTIVE-EXPIRY
      MOVE 'EXPIRED' TO CERT-STATUS
    ELSE
      MOVE 'GRACE' TO CERT-STATUS
    END-IF
  ELSE
    MOVE 'EXPIRED' TO CERT-STATUS
  END-IF
ELSE
  MOVE 'ACTIVE' TO CERT-STATUS
END-IF
```
Deeply nested IF chains are common in NATURAL because the language lacks early-return
semantics (no `return` statement inside IF blocks).

### 5. CALLNAT to Subprograms (External Modularization)
```natural
CALLNAT 'VALIDATE-SSN' SSN-INPUT SSN-VALID SSN-ERROR-MSG
```
The subprogram's PDA defines the contract. Business rules inside the subprogram
are invisible from the caller's source. Build a CALLNAT graph to trace logic flow.

### 6. PERFORM Subroutines (Internal Modularization)
```natural
DEFINE SUBROUTINE CALCULATE-RENEWAL-FEE
  IF CERT-TYPE = 'ATP'
    COMPUTE RENEWAL-FEE = BASE-ATP-FEE * INFLATION-FACTOR
  ELSE
    COMPUTE RENEWAL-FEE = BASE-FEE * INFLATION-FACTOR
  END-IF
END-SUBROUTINE
```
Subroutines defined with `DEFINE SUBROUTINE ... END-SUBROUTINE` are local to the
source file. They can access all variables in scope (no parameter isolation).

### 7. Copycode (Shared Logic Fragments)
```natural
INCLUDE CC-DATE-VALIDATION    /* Inlined at compile time */
```
Copycodes act like C `#include`. They can contain any NATURAL code: data definitions,
business logic, subroutine definitions. A change to a copycode affects every program
that includes it. Grep for `INCLUDE` to find all copycode dependencies.

### 8. Map Exit Routines (Screen-Triggered Validation)
Maps can define processing rules that execute when a user presses ENTER or a PF-key.
These rules run BEFORE control returns to the program. They contain:
- Field-level validation (range checks, format checks)
- Cross-field validation (field A required when field B has value X)
- Automatic field population (derived fields)
Map processing rules are stored inside the `.NSM` file and are easy to miss.

### 9. Helproutines (Help with Hidden Logic)
```natural
DEFINE DATA
  PARAMETER
    1 #FIELD-VALUE (A20)
    1 #HELP-TEXT   (A80)
END-DEFINE
/* May contain validation or lookup logic alongside help display */
```
Helproutines are nominally for context-sensitive help but may contain validation
logic that must be preserved during modernization.

### 10. NATURAL System Variables (Implicit Behavior)
Programs reference system variables that inject runtime context:
```natural
IF *PROGRAM = 'MAINMENU'     /* Current program name */
IF *LIBRARY = 'RMSLIB'       /* Current library */
IF *USER = 'BATCHUSR'        /* Current user ID */
IF *INIT-USER = 'SCHEDLR'    /* Original login user */
IF *DATX > 20260101          /* Current date (internal format YYYYMMDD) */
IF *TIMX > 170000            /* Current time (internal format HHIISS) */
IF *PID > 0                  /* Process/session ID */
IF *DEVICE = 'BATCH'         /* Terminal type or BATCH */
IF *ERROR-NR = 3009          /* Last ADABAS error code */
IF *ISN(VIEW-NAME) > 0       /* Last record ISN accessed */
```
System variable usage creates **implicit dependencies** on the runtime environment.
Every `*VARIABLE` reference must be mapped to its equivalent in the target platform.

## ADABAS Data Access Patterns

### Core Access Verbs

| Verb | Purpose | Pattern | Locking |
|------|---------|---------|---------|
| `READ` | Sequential access by descriptor or ISN | Loop processing | No lock (shared read) |
| `FIND` | Search by criteria, returns ISN list | Set-based retrieval | No lock (shared read) |
| `GET` | Direct access by ISN | Single record fetch | Places hold (update intent) |
| `STORE` | Insert new record | Single record insert | Exclusive lock |
| `UPDATE` | Modify existing record | Must `GET` first | Requires prior hold |
| `DELETE` | Remove record | Must `GET` first | Requires prior hold |
| `HISTOGRAM` | Read descriptor values and counts | Statistics/lookups | No lock |

### READ Patterns
```natural
/* READ LOGICAL: Sequential read using a descriptor (index-ordered) */
READ AIRMEN-FILE BY CERT-TYPE STARTING FROM 'ATP'
  IF CERT-TYPE <> 'ATP'
    ESCAPE BOTTOM    /* Exit loop when descriptor value changes */
  END-IF
  DISPLAY AIRMAN-ID AIRMAN-NAME CERT-TYPE
END-READ

/* READ PHYSICAL: Sequential read by ISN (physical order, rarely used) */
READ AIRMEN-FILE IN PHYSICAL SEQUENCE
  /* Processes every record in file -- expensive */
END-READ

/* READ with MULTI-FETCH (performance optimization) */
READ (10) AIRMEN-FILE BY CERT-TYPE
  /* Fetches 10 records per ADABAS call, reducing I/O round trips */
END-READ
```

### FIND Patterns
```natural
/* Basic FIND: Search with criteria */
FIND AIRMEN-FILE WITH CERT-TYPE = 'ATP'
     AND CERT-STATUS = 'ACTIVE'
  DISPLAY AIRMAN-ID AIRMAN-NAME CERT-EXPIRY-DATE
END-FIND

/* FIND with SORTED BY */
FIND AIRMEN-FILE WITH HOME-STATE = 'VA'
     SORTED BY LAST-NAME
  DISPLAY LAST-NAME FIRST-NAME AIRMAN-ID
END-FIND

/* FIND NUMBER: Count only, no data retrieval */
FIND NUMBER AIRMEN-FILE WITH CERT-TYPE = 'ATP'
  /* Result in *NUMBER system variable */
WRITE 'Total ATP holders:' *NUMBER

/* FIND FIRST: Retrieve only the first matching record */
FIND (1) AIRMEN-FILE WITH AIRMAN-ID = #INPUT-ID
  IF NO RECORDS FOUND
    WRITE 'Airman not found'
  END-NOREC
  MOVE AIRMAN-NAME TO #DISPLAY-NAME
END-FIND

/* FIND COUPLED: Cross-file query via coupling */
FIND AIRMEN-FILE WITH CERT-TYPE = 'ATP'
     AND COUPLED TO MEDICAL-FILE VIA AIRMAN-ID
     WITH MED-CLASS = '1'
  /* Joins across ADABAS files using coupled descriptors */
END-FIND
```

### GET / UPDATE / DELETE Patterns
```natural
/* GET then UPDATE pattern (required sequence) */
GET AIRMEN-FILE #ISN-VALUE
  /* Record is now held (locked) for update */
  MOVE 'RENEWED' TO CERT-STATUS
  MOVE *DATX TO LAST-RENEWAL-DATE
  UPDATE
  END TRANSACTION    /* Commit the change */

/* GET then DELETE pattern */
GET AIRMEN-FILE #ISN-VALUE
  DELETE
  END TRANSACTION
```
**Critical**: `UPDATE` and `DELETE` operate on the record most recently read by
`GET`, `FIND`, or `READ`. There is no explicit record reference. This implicit
"current record" context is a common source of bugs and must be carefully traced.

### STORE Pattern
```natural
STORE AIRMEN-FILE
  /* All fields in the view must be populated before STORE */
  END TRANSACTION
```

### HISTOGRAM Pattern
```natural
/* Read descriptor values and their occurrence counts */
HISTOGRAM AIRMEN-FILE FOR CERT-TYPE
  DISPLAY CERT-TYPE *NUMBER    /* *NUMBER = count of records with this value */
END-HISTOGRAM
```
HISTOGRAM is used for lookup tables, validation lists, and statistical reporting.
It reads the ADABAS inverted list directly without accessing data records.

### Transaction Control
```natural
END TRANSACTION                /* Commit all changes since last ET */
BACKOUT TRANSACTION            /* Roll back all changes since last ET */
```
**Implicit commit**: If a program terminates normally without an explicit
`END TRANSACTION`, NATURAL issues an automatic commit. If a program abends,
NATURAL issues an automatic `BACKOUT TRANSACTION`.

**Transaction scope spans ADABAS files**: A single `END TRANSACTION` commits
changes across ALL ADABAS files modified since the last ET. There is no
per-file commit.

## Architecture Patterns

### Online Programs (3270 Terminal Interaction)

**Conversational Mode** (session held open):
```natural
/* Program maintains state between screen interactions */
INPUT USING MAP 'SEARCH-MAP'
FIND AIRMEN-FILE WITH LAST-NAME = #SEARCH-NAME
  /* ... display results ... */
END-FIND
INPUT USING MAP 'DETAIL-MAP'
/* User still in same program, same session, same transaction */
```

**Pseudo-Conversational Mode** (session released between screens):
```natural
/* Screen 1: Collect search criteria */
INPUT USING MAP 'SEARCH-MAP'
STACK TOP DATA #SEARCH-NAME #SEARCH-TYPE
FETCH 'RESULT-PGM'
/* Control transfers; session resources released */

/* In RESULT-PGM: */
INPUT #SEARCH-NAME #SEARCH-TYPE  /* Reads from stack */
FIND AIRMEN-FILE WITH LAST-NAME = #SEARCH-NAME
  /* ... display results ... */
END-FIND
```
Pseudo-conversational uses `STACK TOP DATA` / `FETCH` to pass context between
screens, releasing mainframe resources between interactions. This is the dominant
pattern in high-volume NATURAL applications.

**Menu-Driven Navigation**:
```natural
INPUT USING MAP 'MAIN-MENU'
DECIDE ON FIRST VALUE OF #MENU-CHOICE
  VALUE '1' FETCH 'AIRMAN-INQUIRY'
  VALUE '2' FETCH 'AIRMAN-UPDATE'
  VALUE '3' FETCH 'CERT-RENEWAL'
  VALUE '4' FETCH 'REPORT-MENU'
  VALUE 'X' STOP
  NONE      REINPUT 'Invalid selection'
END-DECIDE
```

### Batch Programs

**Work File I/O**:
```natural
/* Reading a sequential input file */
READ WORK FILE 1 #INPUT-RECORD
  /* Process each record from the work file */
  EXAMINE #INPUT-RECORD FOR '|' GIVING POSITION #POS
  /* Parse delimited fields */
END-WORK

/* Writing output */
WRITE WORK FILE 2 #OUTPUT-RECORD

/* Print output */
WRITE (PRINTER) 'Report Title'
  AIRMAN-ID AIRMAN-NAME CERT-STATUS
```

**JCL Integration**:
```jcl
//NATBATCH  EXEC PGM=NATBATCH,REGION=0M
//STEPLIB   DD DSN=NAT.LOAD,DISP=SHR
//CMSYNIN   DD *
  LOGON RMSLIB
  BATCH-RENEWAL
  FIN
/*
//CMWKF01   DD DSN=INPUT.FILE,DISP=SHR
//CMWKF02   DD DSN=OUTPUT.FILE,DISP=(NEW,CATLG,DELETE)
//CMPRT01   DD SYSOUT=A
```
The `CMSYNIN` DD statement tells NATURAL which library to log into and which
program to execute. `CMWKF01`-`CMWKF32` are work file DD names. `CMPRT01`-`CMPRT32`
are print file DD names.

### Natural RPC (Remote Procedure Calls)
```natural
/* Client side: call a subprogram on a remote NATURAL server */
CALLNAT 'REMOTE-LOOKUP' #PARM1 #PARM2
/* The subprogram physically runs on a different system */
```
Natural RPC allows transparent distribution. The same CALLNAT syntax works for
local and remote calls. Check `SYSRPC` library and server definitions to identify
which calls are remote.

### Natural Subprogram API (Parameterized Interfaces)
```natural
/* Subprogram definition with typed parameter contract */
DEFINE DATA
  PARAMETER
    1 #AIRMAN-ID    (A9)       /* Input: airman identifier */
    1 #CERT-INFO    (1:10)     /* Output: array of certificate records */
      2 #CERT-TYPE  (A10)
      2 #CERT-DATE  (D)
      2 #CERT-STATUS (A8)
    1 #CERT-COUNT   (I4)       /* Output: number of certs returned */
    1 #RETURN-CODE  (I4)       /* Output: 0=success, >0=error */
END-DEFINE
```
The PDA is the formal interface contract. Parameter types, lengths, and
array dimensions must match exactly between caller and callee.

## Common Gotchas and Implicit Behaviors

### Automatic Field Formatting
Edit masks control display format but do NOT change stored values:
```natural
DEFINE DATA LOCAL
  1 #AMOUNT (N7.2)           /* Stored as 7-digit number with 2 decimals */
END-DEFINE
MOVE 1234.56 TO #AMOUNT
/* Display: uses edit mask at output time */
WRITE #AMOUNT (EM=ZZZ,ZZ9.99)    /* Shows "  1,234.56" */
WRITE #AMOUNT (EM=$$,$$$9.99)     /* Shows "  $1,234.56" */
```
Edit masks are metadata, not data transformations. In modernized code, these
must become explicit formatting functions.

### Loop Processing (Implicit Iteration)
```natural
READ AIRMEN-FILE BY CERT-TYPE
  /* This body executes once per record automatically */
  /* No explicit "next" or "fetch" needed */
END-READ
```
`READ`, `FIND`, `HISTOGRAM`, and `READ WORK FILE` all create implicit loops.
The loop body executes for each record. This is fundamentally different from
cursor-based iteration in SQL. Every READ/FIND block becomes a loop in the
target language.

### ESCAPE Variants (Flow Control)
```natural
ESCAPE TOP       /* Skip to next iteration (like "continue") */
ESCAPE BOTTOM    /* Exit current loop (like "break") */
ESCAPE ROUTINE   /* Exit current subroutine or main program */
ESCAPE MODULE    /* Exit current subprogram/subroutine, return to caller */
```
`ESCAPE BOTTOM` inside nested loops exits only the innermost loop.
`ESCAPE BOTTOM (2)` exits two levels. This numbered escape must be carefully
mapped to target language equivalents.

### RESET (Field Initialization)
```natural
RESET #COUNTER              /* Sets numeric to 0 */
RESET #NAME                 /* Sets alpha to blanks */
RESET #DATE-FIELD           /* Sets date to 0 (internal) */
RESET INITIAL #EDITED-FIELD /* Resets to initial value from INIT clause */
```
`RESET` sets fields to "natural zeros" (0 for numeric, blanks for alpha).
This is NOT NULL. NATURAL has no concept of NULL for program variables.
ADABAS files can have absent fields (empty MU/PE occurrences), but in
NATURAL program variables, "empty" means zero/blanks.

### Field Truncation (Silent)
```natural
DEFINE DATA LOCAL
  1 #SHORT (A5)
END-DEFINE
MOVE 'ABCDEFGHIJ' TO #SHORT    /* #SHORT = 'ABCDE' — silently truncated */
```
NATURAL truncates alpha fields without error or warning. This is a common
source of data corruption bugs that may be "expected behavior" in the
legacy system.

### Numeric Overflow (Error)
```natural
DEFINE DATA LOCAL
  1 #SMALL (N3)     /* Max value 999 */
END-DEFINE
COMPUTE #SMALL = 500 + 600    /* NAT1305 error: result exceeds field size */
```
Unlike truncation for alpha fields, numeric overflow raises a runtime error.
Check `ON ERROR` blocks to see how the application handles these.

### Session Parameters Affecting Behavior
```natural
SET GLOBALS IM=D     /* Input mode: Delimiter mode */
SET GLOBALS PM=I     /* Print mode: Input mode */
SET GLOBALS LS=132   /* Line size: 132 characters (wide report) */
SET GLOBALS PS=60    /* Page size: 60 lines per page */
SET GLOBALS DC='.'   /* Decimal character */
SET GLOBALS CF=','   /* Comma format character */
SET GLOBALS DF=I     /* Date format: Internal (YYYYMMDD) */
```
Session parameters change how NATURAL interprets input, formats output,
and handles dates. These parameters are often set in `NATPARM` at the
system level and may differ between environments (dev vs prod).

### Error Handling
```natural
ON ERROR
  IF *ERROR-NR = 3009      /* ADABAS response code: end of file */
    ESCAPE ROUTINE
  END-IF
  IF *ERROR-NR = 3113      /* ADABAS response code: record in hold */
    WRITE 'Record locked by another user. Retry.'
    BACKOUT TRANSACTION
    ESCAPE ROUTINE
  END-IF
  /* Unhandled errors: log and terminate */
  WRITE 'Error' *ERROR-NR 'in' *ERROR-LINE 'of' *PROGRAM
  BACKOUT TRANSACTION
  ESCAPE MODULE
END-ERROR
```
`ON ERROR` is a catch-all block. There are no typed exceptions. Error handling
is based on numeric error codes (`*ERROR-NR`). Common ADABAS response codes:
- `3009`: End of file / no records found
- `3113`: Record held by another user (lock contention)
- `3145`: ADABAS timeout
- `3148`: Transaction timeout
- `8072`: ADABAS not active

### NATURAL Security (NSC)
NATURAL Security controls access at multiple levels:
- **Library level**: Which users can access which libraries
- **Program level**: Which users can execute which programs within a library
- **Statement level**: Which NATURAL statements are allowed (e.g., restrict UPDATE)
- **DDM level**: Which users can access which ADABAS files
These security rules may encode authorization business logic that must be
preserved in the target application's access control model.

## 3270 MAP Analysis

### Map Field Types
```
Field Attribute Definitions in .NSM files:
  Input (I)       — user can enter data
  Output (O)      — display only, system populated
  Modifiable (M)  — display and allow modification
  Attribute (A)   — protected (no input), display text/labels
```

### Map Field Attributes
```
AD=MI    /* Modifiable, Intensified (bright) */
AD=OI    /* Output, Intensified */
AD=PI    /* Protected, Intensified (label) */
AD=MD    /* Modifiable, Dark (password field) */
CV=RE    /* Color: Red */
CV=GR    /* Color: Green */
CV=BL    /* Color: Blue */
CV=YE    /* Color: Yellow */
```

### Map Arrays (Tabular Display)
```natural
/* Map definition includes array fields for table-like display */
1 #RESULT-TABLE (1:15)     /* 15 rows displayed on screen */
  2 #AIRMAN-ID  (A9)
  2 #NAME       (A30)
  2 #CERT-TYPE  (A10)
  2 #STATUS     (A8)
```
Array maps display multiple records in a scrollable list. The array size
(e.g., 1:15) is the screen page size. Scrolling logic (PF7/PF8) manages
which page of data is displayed.

### Map Processing
```natural
/* Display a map and wait for input */
INPUT USING MAP 'AIRMAN-SEARCH'

/* Conditional re-display with error message */
REINPUT 'Invalid airman ID format' MARK *#AIRMAN-ID

/* Process page (form processing with automatic loop) */
PROCESS PAGE USING MAP 'RESULT-LIST'
  /* Fires once per array row modified by user */
END-PROCESS
```
`REINPUT` redisplays the current map with an error message and positions
the cursor on the indicated field. This is the primary input validation
mechanism for online programs.

### PF-Key Handling
```natural
INPUT USING MAP 'DETAIL-MAP'
DECIDE ON FIRST VALUE OF *PF-KEY
  VALUE 'PF1'   FETCH 'HELP-PGM'
  VALUE 'PF3'   ESCAPE ROUTINE          /* Back/Exit */
  VALUE 'PF5'   PERFORM SAVE-RECORD     /* Save */
  VALUE 'PF7'   PERFORM PAGE-BACKWARD   /* Scroll up */
  VALUE 'PF8'   PERFORM PAGE-FORWARD    /* Scroll down */
  VALUE 'PF12'  STOP                    /* Cancel */
  VALUE 'ENTR'  PERFORM PROCESS-INPUT   /* Enter key */
  NONE          REINPUT 'Invalid function key'
END-DECIDE
```
PF-key assignments define the user interaction model. Map this to UI
button/action equivalents in the target application.

## Module Boundary Detection

### Library Boundaries
Each NATURAL library (`SYSLIB`) is a logical module boundary:
- Programs within a library share a common business domain
- GDAs are scoped to a library session
- Libraries have independent security profiles
- Steplib chains create explicit dependency declarations

**Inventory approach**: List all libraries, their program counts, and steplib chains.
Libraries with the most incoming steplib references are shared infrastructure.

### Subprogram Interfaces (API Contracts)
```natural
/* PDA defines the formal interface */
DEFINE DATA PARAMETER
  1 #INPUT-GROUP
    2 #AIRMAN-ID   (A9)
    2 #REQUEST-TYPE (A1)    /* 'I'=inquiry, 'U'=update, 'D'=delete */
  1 #OUTPUT-GROUP
    2 #AIRMAN-NAME (A40)
    2 #RETURN-CODE (I4)
    2 #ERROR-MSG   (A80)
END-DEFINE
```
Subprograms with PDAs are the cleanest boundary. Extract all PDAs to
document the existing API surface.

### Copycode Coupling
Copycodes shared across multiple programs create coupling:
```
CC-DATE-ROUTINES   -> used by 47 programs (high coupling)
CC-ERROR-HANDLER   -> used by 92 programs (infrastructure)
CC-AIRMAN-FIELDS   -> used by 23 programs (data structure coupling)
```
Build a matrix of copycode-to-program references. Copycodes used by many programs
indicate shared business logic that should become shared services.

### CALLNAT Graph Construction
1. Grep all source files for `CALLNAT 'name'` references
2. Build a directed graph: caller -> callee
3. Identify clusters (groups of programs that call each other heavily)
4. Identify fan-in hubs (subprograms called by many programs = shared services)
5. Identify fan-out hubs (programs that call many subprograms = orchestrators)

### Steplib Dependencies
```
RMSLIB  steplib: SYSLIB, UTILLIB
CAISLIB steplib: SYSLIB, UTILLIB, SHAREDLIB
REPORTLIB steplib: SYSLIB, RMSLIB, CAISLIB
```
Steplib chains create implicit dependencies. REPORTLIB depends on RMSLIB and
CAISLIB, meaning it can call their subprograms. Map these to dependency arrows
in the architecture diagram.

### Data Coupling via GDA
Programs sharing the same GDA are tightly coupled:
```natural
/* In Program A: */
DEFINE DATA
  GLOBAL USING GDA-AIRMAN-SESSION
END-DEFINE
MOVE 'ATP' TO GDA-CERT-TYPE    /* Sets value in shared memory */
CALLNAT 'PROGRAM-B'

/* In Program B: */
DEFINE DATA
  GLOBAL USING GDA-AIRMAN-SESSION
END-DEFINE
IF GDA-CERT-TYPE = 'ATP'       /* Reads value set by Program A */
```
GDA sharing is the NATURAL equivalent of global mutable state. It creates
invisible coupling between programs that share a session.

### DDM-Based File Access Mapping
Build a matrix of which programs access which ADABAS files (via DDM references):
```
Program       | AIRMEN-FILE | CERT-FILE | MEDICAL-FILE | EXAM-FILE
--------------+-------------+-----------+--------------+-----------
AIRMAN-INQ    | READ        | READ      | READ         |
AIRMAN-UPD    | READ/UPDATE | READ      |              |
CERT-RENEW    | READ        | UPDATE    |              | READ
MED-CHECK     | READ        |           | READ/UPDATE  |
BATCH-REPORT  | READ        | READ      | READ         | READ
```
This matrix reveals write coupling (programs that modify the same files)
and read dependencies (programs that consume data produced by others).
