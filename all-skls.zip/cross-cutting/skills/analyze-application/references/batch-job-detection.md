# Batch Job Detection Guide

## Where to Find Batch Jobs
1. **Cron configs**: `/etc/crontab`, `/var/spool/cron/`, crontab -l
2. **Oracle DBMS_SCHEDULER**: `SELECT * FROM DBA_SCHEDULER_JOBS`
3. **Windows Task Scheduler**: XML exports in System32/Tasks/
4. **Spring Batch**: Look for `@Scheduled`, `JobLauncher`, batch XML configs
5. **Quartz Scheduler**: Look for `quartz.properties`, `@DisallowConcurrentExecution`
6. **Jenkins/CI jobs**: Some "CI" jobs are actually batch processing
7. **AWS Step Functions / Lambda scheduled**: CloudWatch Events rules
8. **Shell scripts**: `/opt/scripts/`, `/home/*/scripts/`, referenced in cron

## What to Capture Per Batch Job
- Schedule (when it runs)
- Input data sources
- Output data targets
- Dependencies (must Job A complete before Job B?)
- Duration (how long does it take?)
- Failure behavior (retry? alert? skip?)
- Business purpose (what does it DO?)
