# PHP Legacy Application Analysis Patterns

## Purpose

Reference for the Analyze Application skill when performing discovery and analysis
of PHP legacy applications. PHP applications span a wide range of quality and
architecture, from well-structured MVC frameworks to unmaintained procedural
spaghetti code. This guide covers framework detection, dependency mapping,
architecture assessment, and security analysis.

## Framework Detection Strategy

### Signature File Detection

Each PHP framework has distinctive files. Check for these in order:

| Signature File | Framework | Confidence |
|----------------|-----------|------------|
| `artisan` | Laravel | High |
| `composer.json` containing `laravel/framework` | Laravel | Definitive |
| `symfony.lock` or `symfony.json` | Symfony | High |
| `composer.json` containing `symfony/` | Symfony | High |
| `index.php` + `BASEPATH` constant | CodeIgniter | High |
| `system/core/CodeIgniter.php` | CodeIgniter | Definitive |
| `config/config.php` + `App.namespace` | CakePHP 4+ | High |
| `src/Controller/` + `config/app.php` | CakePHP 3+ | High |
| `wp-config.php` | WordPress | Definitive |
| `wp-content/` + `wp-admin/` + `wp-includes/` | WordPress | Definitive |
| `yii` (bootstrap script) | Yii | High |
| `protected/config/main.php` | Yii 1.x | High |
| `config/web.php` + `vendor/yiisoft/` | Yii 2.x | High |
| `fuel/app/` | FuelPHP | High |
| `sites/default/settings.php` | Drupal | Definitive |
| `core/lib/Drupal.php` | Drupal 8+ | Definitive |
| `includes/bootstrap.inc` | Drupal 7 | High |
| `configuration.php` + `administrator/` | Joomla | Definitive |
| `framework/main/` + `_config.php` | SilverStripe | High |
| `slim` in `composer.json` | Slim | High |
| `Zend/` or `laminas/` | Zend/Laminas | High |
| `medoo` in `composer.json` | Medoo (micro-ORM) | Medium |

**No-framework detection** — if none of the above match:
```
Check for:
- No composer.json at all (pre-Composer era)
- Manual require/include chains as dependency management
- Custom routing in index.php or .htaccess
- Procedural code structure (no class definitions)
- Mixed HTML/PHP files as the primary page structure
```

### Framework Version Detection

```php
// Laravel: check bootstrap/app.php or vendor/laravel/framework/src/Illuminate/Foundation/Application.php
// Version constant: Illuminate\Foundation\Application::VERSION

// Symfony: check symfony.lock or composer.lock for symfony version
// Also: Symfony\Component\HttpKernel\Kernel::VERSION

// CodeIgniter: check system/core/CodeIgniter.php
// Constant: CI_VERSION

// CakePHP: check vendor/cakephp/cakephp/VERSION.txt
// Or: Cake\Core\Configure::version()

// WordPress: check wp-includes/version.php
// Variable: $wp_version

// Drupal: check core/lib/Drupal.php
// Constant: \Drupal::VERSION
```

## Composer Dependency Analysis

### composer.json Parsing

```json
{
    "name": "acme/legacy-app",
    "require": {
        "php": ">=7.2",
        "ext-pdo": "*",
        "ext-mbstring": "*",
        "ext-gd": "*",
        "monolog/monolog": "^1.25",
        "phpmailer/phpmailer": "^6.0",
        "twig/twig": "^2.0",
        "doctrine/dbal": "^2.10"
    },
    "autoload": {
        "psr-4": {
            "App\\": "src/"
        },
        "classmap": [
            "lib/",
            "legacy/"
        ],
        "files": [
            "src/helpers.php",
            "src/constants.php"
        ]
    }
}
```

**Key analysis points**:
- `"php"` constraint reveals minimum PHP version
- `"ext-*"` entries reveal required PHP extensions
- Autoloader type indicates code organization maturity:
  - `psr-4` — modern, well-organized namespace structure
  - `classmap` — older code with inconsistent naming; Composer scans directories
  - `files` — global function/constant files loaded on every request
- Package versions reveal library age and potential vulnerabilities

### composer.lock Analysis

```
Parse composer.lock for:
1. Exact installed versions of all dependencies (direct + transitive)
2. PHP version the lock was generated on
3. Total dependency count (indicator of complexity)
4. Packages with known security vulnerabilities (cross-reference with
   https://security.symfony.com/check_lock or composer audit)
```

### Common PHP Packages to Flag

| Package | Significance |
|---------|-------------|
| `phpmailer/phpmailer` | Email sending — check for SMTP configuration |
| `monolog/monolog` | Logging — check log destinations and levels |
| `twig/twig` | Template engine — separate from spaghetti templates |
| `doctrine/orm` or `doctrine/dbal` | Database abstraction — may contain schema info |
| `illuminate/database` (Eloquent standalone) | Laravel ORM used outside Laravel |
| `guzzlehttp/guzzle` | HTTP client — external service calls |
| `firebase/php-jwt` | JWT handling — authentication pattern |
| `league/oauth2-*` | OAuth integration — auth architecture |
| `mpdf/mpdf` or `tecnickcom/tcpdf` | PDF generation |
| `phpoffice/phpspreadsheet` | Excel generation/parsing |
| `predis/predis` or `phpredis` | Redis — caching or session store |
| `aws/aws-sdk-php` | AWS services — cloud integration |
| `intervention/image` | Image processing |
| `swiftmailer/swiftmailer` | Email (deprecated, replaced by symfony/mailer) |
| `php-amqplib/php-amqplib` | RabbitMQ — message queue integration |

## Include/Require Graph

### Pre-Autoloader PHP Pattern

Legacy PHP applications use `include`, `require`, `include_once`, and `require_once`
as their dependency mechanism:

```php
// Common legacy entry point pattern
// index.php
require_once 'config/database.php';
require_once 'config/constants.php';
require_once 'includes/functions.php';
require_once 'includes/auth.php';
require_once 'includes/session.php';

// Page routing via include
$page = isset($_GET['page']) ? $_GET['page'] : 'home';
$allowed_pages = ['home', 'search', 'detail', 'admin', 'report'];
if (in_array($page, $allowed_pages)) {
    include "pages/{$page}.php";  // RULE: Each page is a standalone PHP file
} else {
    include 'pages/404.php';
}
```

**Extraction approach**: Build the include tree by tracing all `include`/`require`
statements from the entry points (index.php, cron scripts, API endpoints).

### Include Chain Gotchas

```php
// Conditional includes (branch-dependent dependencies)
if ($config['use_ldap']) {
    require_once 'auth/ldap_handler.php';
} else {
    require_once 'auth/db_handler.php';
}

// Dynamic includes (path determined at runtime)
$module = $_GET['module'];  // SECURITY RISK: Local File Inclusion
include "modules/{$module}/init.php";

// Relative path issues (depends on current working directory)
include '../shared/utilities.php';    // fragile
include dirname(__FILE__) . '/../shared/utilities.php';  // safer
include __DIR__ . '/../shared/utilities.php';  // PHP 5.3+ safest
```

## Global State Mapping

### Superglobal Usage

```php
// $_GET — URL query parameters
$search = $_GET['q'];            // User input from URL
$page = (int)$_GET['page'];     // Pagination state in URL

// $_POST — Form submission data
$username = $_POST['username'];  // Form input
$password = $_POST['password'];  // Sensitive form input

// $_SESSION — Server-side session state
$_SESSION['user_id'] = $userId;       // Authentication state
$_SESSION['cart'] = $cartItems;       // Shopping cart state
$_SESSION['csrf_token'] = $token;     // CSRF protection
$_SESSION['flash_message'] = $msg;    // Cross-request messaging

// $_COOKIE — Client-side persistent state
$theme = $_COOKIE['theme'];           // User preference
$lang = $_COOKIE['language'];         // Localization

// $_SERVER — Server and request metadata
$_SERVER['REQUEST_METHOD'];     // GET, POST, PUT, DELETE
$_SERVER['REMOTE_ADDR'];        // Client IP (may be proxy)
$_SERVER['HTTP_HOST'];           // Hostname
$_SERVER['REQUEST_URI'];         // Full request path
$_SERVER['HTTP_REFERER'];        // Referring page (misspelled per HTTP spec)
$_SERVER['HTTP_USER_AGENT'];     // Browser identification

// $_FILES — File upload data
$_FILES['document']['name'];     // Original filename
$_FILES['document']['tmp_name']; // Temp file path
$_FILES['document']['size'];     // File size
$_FILES['document']['type'];     // MIME type (client-provided, untrusted)
$_FILES['document']['error'];    // Upload error code
```

### Global Keyword Usage

```php
// The `global` keyword imports variables from the global scope
function processOrder() {
    global $db, $config, $logger;  // Hidden dependencies
    // $db, $config, $logger are defined elsewhere — trace their origin
}

// Variable variables (dynamic variable naming)
$field = 'email';
$$field = 'user@example.com';  // Creates $email = 'user@example.com'

// extract() — converts array keys to variables (dangerous)
extract($_POST);  // SECURITY RISK: every POST param becomes a variable
// If POST contains 'isAdmin=1', now $isAdmin === '1'
```

**Extraction checklist**:
1. Grep for `global ` to find all implicit dependencies
2. Grep for `extract(` to find mass variable creation
3. Grep for `$$` to find variable variables
4. Map all `$_SESSION` key names across the codebase

## Mixed HTML/PHP Detection

### Spaghetti Code Pattern

```php
<?php
// File: orders.php — typical legacy pattern
require_once 'includes/header.php';
require_once 'includes/db.php';
require_once 'includes/auth.php';

if (!is_logged_in()) {
    header('Location: login.php');
    exit;
}

$status = isset($_GET['status']) ? $_GET['status'] : 'all';
$query = "SELECT * FROM orders WHERE user_id = " . $_SESSION['user_id'];
if ($status !== 'all') {
    $query .= " AND status = '" . mysql_real_escape_string($status) . "'";
}
$result = mysql_query($query);
?>
<html>
<head><title>My Orders</title></head>
<body>
<h1>Your Orders</h1>
<table>
    <tr><th>Order #</th><th>Date</th><th>Total</th><th>Status</th></tr>
    <?php while ($row = mysql_fetch_assoc($result)): ?>
    <tr>
        <td><?php echo $row['order_number']; ?></td>
        <td><?php echo date('m/d/Y', strtotime($row['order_date'])); ?></td>
        <td>$<?php echo number_format($row['total'], 2); ?></td>
        <td><?php echo htmlspecialchars($row['status']); ?></td>
    </tr>
    <?php endwhile; ?>
</table>
<?php require_once 'includes/footer.php'; ?>
```

**Key indicators of spaghetti code**:
- SQL queries in the same file as HTML output
- Business logic (authentication, authorization) mixed with presentation
- `mysql_*` functions (deprecated since PHP 5.5, removed in PHP 7.0)
- String concatenation in SQL queries (SQL injection risk)
- No separation between data retrieval and rendering

### MVC Template Detection

Compare with proper template usage:

```php
// Twig template (separate file: templates/orders.html.twig)
{% extends 'layout.html.twig' %}
{% block content %}
<h1>Your Orders</h1>
<table>
{% for order in orders %}
    <tr>
        <td>{{ order.number }}</td>
        <td>{{ order.date|date('m/d/Y') }}</td>
        <td>${{ order.total|number_format(2) }}</td>
        <td>{{ order.status }}</td>
    </tr>
{% endfor %}
</table>
{% endblock %}
```

**Detection heuristic**: If `.php` files contain `<html>`, `<table>`, `<div>`,
or other HTML tags intermixed with PHP logic, it is spaghetti code. If templates
use `.twig`, `.blade.php`, `.phtml`, or `.tpl` extensions with limited PHP, the
application has some separation of concerns.

## PHP Version Indicators

### Deprecated Function Usage

| Function / Feature | Deprecated In | Removed In | Replacement |
|-------------------|---------------|------------|-------------|
| `mysql_connect()`, `mysql_query()` | PHP 5.5 | PHP 7.0 | `mysqli_*` or `PDO` |
| `ereg()`, `ereg_replace()` | PHP 5.3 | PHP 7.0 | `preg_match()`, `preg_replace()` |
| `split()` | PHP 5.3 | PHP 7.0 | `preg_split()` or `explode()` |
| `each()` | PHP 7.2 | PHP 8.0 | `foreach` loop |
| `create_function()` | PHP 7.2 | PHP 8.0 | Closures / anonymous functions |
| `__autoload()` | PHP 7.2 | PHP 8.0 | `spl_autoload_register()` |
| Short open tag `<?` | Discouraged | Still valid | Use `<?php` |
| `register_globals` | PHP 5.3 | PHP 5.4 | Direct `$_GET`/`$_POST` access |
| `magic_quotes_gpc` | PHP 5.3 | PHP 5.4 | Manual escaping or parameterized queries |
| `$HTTP_POST_VARS` | PHP 5.0 | PHP 5.4 | `$_POST` |
| `set_magic_quotes_runtime()` | PHP 5.3 | PHP 7.0 | Remove call |
| `mcrypt_*` functions | PHP 7.1 | PHP 7.2 | `openssl_*` functions |

**Version inference rule**: The oldest deprecated function in use indicates the
minimum PHP version the code was written for. If `mysql_*` functions are present,
the code predates PHP 7.0.

### PHP 8+ Feature Detection

If present, these indicate PHP 8+ compatibility:
- Named arguments: `htmlspecialchars(string: $str, encoding: 'UTF-8')`
- Match expression: `match($status) { 'active' => 'Active', default => 'Unknown' }`
- Constructor promotion: `public function __construct(private string $name)`
- Null-safe operator: `$user?->getProfile()?->getAvatar()`
- Union types: `function process(int|string $input): bool|null`
- Attributes: `#[Route('/api/users')]`
- Enums: `enum Status { case Active; case Inactive; }`
- Fibers: `$fiber = new Fiber(function() { ... })`

## Database Access Patterns

### Pattern Detection Strategy

| Pattern | Detection | Version / Era |
|---------|-----------|---------------|
| `mysql_*` | `mysql_connect`, `mysql_query` | Pre-PHP 7.0, insecure |
| `mysqli_*` | `mysqli_connect`, `new mysqli()` | PHP 5+, procedural or OOP |
| PDO | `new PDO()`, `$pdo->prepare()` | PHP 5.1+, recommended |
| Doctrine ORM | `EntityManager`, `@ORM\Entity` | Modern, framework-level |
| Doctrine DBAL | `DriverManager::getConnection()` | Modern, query builder |
| Eloquent ORM | `extends Model`, `DB::table()` | Laravel ecosystem |
| CakePHP ORM | `TableRegistry`, `extends Table` | CakePHP ecosystem |
| Propel | `extends Base*`, `*Query::create()` | Legacy ORM |
| RedBeanPHP | `R::store()`, `R::find()` | Lightweight ORM |

### Raw Query Detection

```php
// DANGEROUS: SQL injection via string concatenation
$sql = "SELECT * FROM users WHERE id = " . $_GET['id'];
$sql = "SELECT * FROM users WHERE name = '" . $name . "'";
$sql = "SELECT * FROM users WHERE name LIKE '%" . $search . "%'";

// SAFE: Parameterized queries
// PDO
$stmt = $pdo->prepare("SELECT * FROM users WHERE id = :id");
$stmt->execute(['id' => $userId]);

// mysqli
$stmt = $mysqli->prepare("SELECT * FROM users WHERE id = ?");
$stmt->bind_param("i", $userId);
$stmt->execute();
```

## Session Management

### Session Configuration

```php
// php.ini settings that affect session behavior:
session.save_handler = files          // files, redis, memcached, user
session.save_path = /tmp              // where session files are stored
session.gc_maxlifetime = 1440         // seconds before garbage collection
session.cookie_lifetime = 0           // 0 = browser session
session.cookie_httponly = 1           // prevent JavaScript access
session.cookie_secure = 1            // HTTPS only
session.use_strict_mode = 1          // reject uninitialized session IDs
session.cookie_samesite = Lax        // CSRF protection

// Custom session handler registration
session_set_save_handler(
    new DatabaseSessionHandler($db),
    true  // register_shutdown = true
);
```

### Session Data Inventory

Build a map of all session keys by searching for `$_SESSION['...']`:
```
Session Key Map:
  $_SESSION['user_id']          → int    → set: login.php, read: *.php
  $_SESSION['user_role']        → string → set: login.php, read: admin/*.php
  $_SESSION['cart_items']       → array  → set: cart.php, read: checkout.php
  $_SESSION['csrf_token']       → string → set: every form, read: form handlers
  $_SESSION['flash_messages']   → array  → set: any controller, read: layout.php
  $_SESSION['search_criteria']  → array  → set: search.php, read: results.php
  $_SESSION['last_activity']    → int    → set: every page, read: auth check
```

## File System Usage

### Common File System Patterns

```php
// File upload handling
$uploadDir = '/var/www/uploads/';
move_uploaded_file($_FILES['doc']['tmp_name'], $uploadDir . $filename);

// Temp file usage
$tmpFile = tempnam(sys_get_temp_dir(), 'report_');
file_put_contents($tmpFile, $csvData);

// Log file writing
error_log("Payment processed: $orderId", 3, '/var/log/app/payments.log');

// Cache files
$cacheFile = '/var/cache/app/' . md5($cacheKey) . '.cache';
if (file_exists($cacheFile) && filemtime($cacheFile) > time() - 3600) {
    $data = unserialize(file_get_contents($cacheFile));
}

// Configuration files
$config = parse_ini_file('/etc/app/config.ini', true);
$config = include '/var/www/config/database.php';  // returns array
```

**Migration impact**: All file system paths are deployment dependencies. Map
every path to determine:
- What needs S3 (uploads, generated files)
- What needs EFS (shared temp files across instances)
- What needs parameterization (environment-specific paths)

## External Service Calls

### cURL Patterns

```php
// Direct cURL (most common in legacy PHP)
$ch = curl_init('https://api.example.com/data');
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_HTTPHEADER, ['Authorization: Bearer ' . $token]);
curl_setopt($ch, CURLOPT_TIMEOUT, 30);
$response = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

// file_get_contents for HTTP (simpler but less control)
$context = stream_context_create([
    'http' => [
        'method' => 'POST',
        'header' => "Content-Type: application/json\r\n",
        'content' => json_encode($data),
        'timeout' => 30
    ]
]);
$response = file_get_contents('https://api.example.com/data', false, $context);

// SOAP client
$client = new SoapClient('https://service.example.com/api?wsdl', [
    'trace' => true,
    'exceptions' => true,
    'cache_wsdl' => WSDL_CACHE_MEMORY
]);
$result = $client->ProcessOrder($orderData);
```

## Security Analysis

### Critical Security Patterns to Flag

```php
// 1. eval() — arbitrary code execution
eval($userInput);                    // CRITICAL: Remote Code Execution
eval('$result = ' . $expression);    // CRITICAL even with "safe" input
assert($userInput);                  // CRITICAL: assert() acts like eval()

// 2. unserialize() on user input — object injection
$data = unserialize($_COOKIE['prefs']);  // CRITICAL: PHP Object Injection
$data = unserialize(base64_decode($_GET['data']));  // CRITICAL

// 3. SQL injection patterns
$sql = "SELECT * FROM users WHERE id = " . $_GET['id'];           // CRITICAL
$sql = "SELECT * FROM users WHERE name = '{$_POST['name']}'";     // CRITICAL

// 4. Cross-Site Scripting (XSS)
echo $_GET['search'];                                              // HIGH
echo "<input value='" . $userInput . "'>";                         // HIGH
// Safe: echo htmlspecialchars($userInput, ENT_QUOTES, 'UTF-8');

// 5. File inclusion vulnerabilities
include $_GET['page'] . '.php';                                    // CRITICAL: LFI
include 'pages/' . $_GET['page'];                                  // CRITICAL: LFI/RFI

// 6. Command injection
exec('ping ' . $_GET['host']);                                     // CRITICAL
system('convert ' . $uploadedFile . ' output.png');                // CRITICAL
shell_exec('grep ' . $searchTerm . ' /var/log/access.log');       // CRITICAL
// Safe: exec('ping ' . escapeshellarg($_GET['host']));

// 7. Open redirect
header('Location: ' . $_GET['redirect_url']);                      // MEDIUM

// 8. Insecure file upload
move_uploaded_file($_FILES['f']['tmp_name'], 'uploads/' . $_FILES['f']['name']);
// CRITICAL: attacker can upload shell.php

// 9. Weak cryptography
md5($password);                          // CRITICAL: use password_hash()
sha1($password);                         // CRITICAL: use password_hash()
mcrypt_encrypt(MCRYPT_DES, $key, ...);  // CRITICAL: DES is broken

// 10. Information disclosure
phpinfo();                               // MEDIUM: exposes server config
ini_set('display_errors', 1);           // MEDIUM in production
var_dump($sensitiveData);                // LOW-MEDIUM depending on context
```

## Error Handling

### Error Configuration

```php
// php.ini or runtime configuration
ini_set('display_errors', 0);         // production: never display
ini_set('log_errors', 1);             // always log
ini_set('error_log', '/var/log/php/app.log');
error_reporting(E_ALL);               // report everything

// Custom error handler
set_error_handler(function ($errno, $errstr, $errfile, $errline) {
    // RULE: Log error and optionally display user-friendly message
    error_log("[$errno] $errstr in $errfile:$errline");
    if ($errno === E_USER_ERROR) {
        http_response_code(500);
        include 'error_pages/500.php';
        exit(1);
    }
    return true;  // prevent default handler
});

// Exception handler
set_exception_handler(function (Throwable $e) {
    error_log($e->getMessage() . "\n" . $e->getTraceAsString());
    http_response_code(500);
    include 'error_pages/500.php';
    exit(1);
});
```

### Error Handling Maturity Assessment

| Pattern | Maturity | Notes |
|---------|----------|-------|
| No error handling | Very Low | Errors displayed to users |
| `@` error suppression operator | Low | Silences errors without handling |
| `die()` / `exit()` on error | Low | Abrupt termination, no cleanup |
| `trigger_error()` + custom handler | Medium | Structured but procedural |
| try/catch with specific exceptions | High | Modern, proper error hierarchy |
| PSR-3 logging (Monolog) | High | Structured, configurable logging |

## Architecture Assessment Checklist

1. **Framework identification** — which framework (if any), which version
2. **PHP version** — check `phpinfo()`, `php -v`, or infer from deprecated functions
3. **Dependency inventory** — parse `composer.json`/`composer.lock`
4. **Autoloading type** — PSR-4, classmap, files, or manual includes
5. **Database access pattern** — PDO, mysqli, mysql_*, ORM
6. **Session management** — handler type, session data map
7. **Authentication mechanism** — custom, framework-provided, OAuth, LDAP
8. **File system dependencies** — uploads, temp, cache, logs, config paths
9. **External service calls** — APIs, SOAP, message queues
10. **Security assessment** — eval, unserialize, SQL injection, XSS vectors
11. **Error handling maturity** — suppression, die, exceptions, logging
12. **Code organization** — MVC separation or spaghetti
13. **Test coverage** — PHPUnit tests present, test configuration
14. **Deployment mechanism** — FTP, rsync, CI/CD, Docker
