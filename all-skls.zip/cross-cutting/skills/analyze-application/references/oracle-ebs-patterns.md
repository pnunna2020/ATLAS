# Oracle E-Business Suite (R12.2.6) Analysis Patterns

## Purpose

Reference for the Analyze Application skill when performing discovery and analysis
of Oracle EBS customizations. EBS is a massive application suite with thousands of
standard objects. The challenge is separating custom work (the migration scope) from
Oracle-delivered standard objects (which are replaced by the target system, not migrated).

## Customization Detection Strategy

### The XX_ Naming Convention

Oracle mandates that all customer-created database objects use the `XX` or `XXX`
prefix (where X is replaced with customer-specific letters, commonly `XX_`). This
is the primary detection signal:

```sql
-- Custom objects follow these naming patterns:
XX_*              -- generic custom prefix
XXFAA_*           -- client-specific prefix (e.g., FAA)
XXCUST_*          -- common alternative prefix

-- Standard EBS objects use module prefixes:
AP_*              -- Accounts Payable
AR_*              -- Accounts Receivable
GL_*              -- General Ledger
PO_*              -- Purchasing
HR_*              -- Human Resources
INV_*             -- Inventory
WF_*              -- Workflow
FND_*             -- Foundation (Application Object Library)
```

**Gotcha**: Not all custom objects follow the convention. Some organizations created
objects directly in the `APPS` schema without prefixes during early EBS versions.
Cross-reference with `FND_CUSTOM_OBJECTS` and check for objects not owned by the
`APPLSYS` or module-specific schemas.

### Forms Personalization vs Customization

Oracle EBS distinguishes two levels of UI modification:

**Forms Personalization** (metadata-driven, stored in `FND_FORM_CUSTOM_RULES`):
- Requires no code changes to the Form module (.fmb)
- Stored as rules in the database, applied at runtime
- Managed via the Forms Personalization UI (Help -> Diagnostics -> Custom Code -> Personalize)
- Scope: function-level, form-level, or user/responsibility-level
- Actions: change field properties, show/hide fields, display messages, execute built-ins

**Form Customization** (code changes to .fmb/.pll files):
- Requires modification of compiled Form modules
- Stored in `$CUSTOM_TOP` or module-specific directories
- Managed via Oracle Forms Builder (Forms 10g)
- Involves custom triggers, program units, PL/SQL libraries
- Must be reapplied after EBS patches that touch the same form

```
Detection priority:
1. Query FND_FORM_CUSTOM_RULES for personalizations (no code needed)
2. Compare .fmb files in $CUSTOM_TOP against standard EBS baseline
3. Check $CUSTOM_TOP/lib/*.pll for custom PL/SQL libraries
4. Check CUSTOM.pll — the global hook library for all forms
```

## CEMLI Taxonomy

Oracle's standard classification for EBS customizations:

### Configuration (C)
Standard setup using delivered functionality — no custom code.

```
Examples:
- Profile option settings (FND_PROFILE_OPTION_VALUES)
- Flexfield segment definitions
- Lookup type values (FND_LOOKUP_VALUES)
- Concurrent program parameter defaults
- Workflow notification preferences
- Security rules for flex value sets
- Organization hierarchy definitions
```

**Analysis approach**: Configurations are not migrated as code. They are re-implemented
as configuration in the target system. Inventory them for completeness but classify
as "configuration migration" not "code migration."

### Extension (E)
New functionality built on top of EBS without modifying delivered objects.

```
Examples:
- Custom concurrent programs (registered in FND_CONCURRENT_PROGRAMS)
- Custom forms (new .fmb files in $CUSTOM_TOP)
- Custom reports (Oracle Reports .rdf files, OBIEE reports)
- Custom OAF pages (Oracle Application Framework — Java-based)
- Custom workflows (new item types in WF_ITEM_TYPES)
- Custom APIs (XX_*_PKG packages that wrap standard APIs)
- Custom alerts (ALR_ALERTS with XX_ prefix)
- Custom interfaces/integrations (new concurrent programs for data load)
```

**Analysis approach**: Extensions contain the bulk of custom business logic. They
are the primary migration scope.

### Modification (M)
Changes to Oracle-delivered objects. The most risky and maintenance-heavy category.

```
Examples:
- Modified standard forms (.fmb files patched with custom triggers)
- Modified standard reports (changed .rdf files)
- Modified standard PL/SQL packages (overridden in APPS schema)
- Modified standard workflows (changed delivered WF processes)
- Modified standard XML Publisher templates
- Modified standard OAF pages (extended or substituted controllers)
```

**Analysis approach**: Modifications are fragile — they break on EBS patches.
Identify the business reason for each modification to determine if the target
system's standard functionality eliminates the need.

### Localization (L)
Region or country-specific adaptations.

```
Examples:
- Country-specific tax calculation logic
- Statutory reporting requirements
- Local language translations (FND_NEW_MESSAGES, FND_LOOKUP_VALUES)
- Country-specific payment formats
- Regulatory compliance extensions
```

### Integration (I)
Interfaces between EBS and external systems.

```
Examples:
- Inbound interfaces (flat file, XML, web service → EBS interface tables)
- Outbound interfaces (EBS data → external systems via concurrent programs)
- SOA composites (BPEL processes, ESB routes)
- Database links to external systems
- Web service endpoints (SOA Gateway, IREP)
- Middleware integration (MQ, Kafka, file-based)
```

**Analysis approach**: Integrations define the boundary of the EBS ecosystem. Every
integration point must be mapped to a target integration pattern.

## Customization Inventory Queries

### Custom Objects by Type and Status

```sql
-- Full inventory of custom database objects
SELECT
    o.owner,
    o.object_type,
    o.object_name,
    o.status,
    o.created,
    o.last_ddl_time,
    CASE
        WHEN o.object_name LIKE 'XX_%' THEN 'CUSTOM_XX'
        WHEN o.object_name LIKE 'XXFAA_%' THEN 'CUSTOM_FAA'
        WHEN o.owner NOT IN ('APPS','APPLSYS','SYS','SYSTEM') THEN 'CUSTOM_SCHEMA'
        ELSE 'REVIEW_NEEDED'
    END AS classification
FROM dba_objects o
WHERE (
    o.object_name LIKE 'XX\_%' ESCAPE '\'
    OR o.object_name LIKE 'XXFAA\_%' ESCAPE '\'
    OR o.owner IN (SELECT oracle_username FROM fnd_oracle_userid
                   WHERE read_only_flag = 'U')  -- custom schemas
)
AND o.object_type IN (
    'PACKAGE', 'PACKAGE BODY', 'PROCEDURE', 'FUNCTION',
    'TRIGGER', 'VIEW', 'TABLE', 'SEQUENCE', 'TYPE', 'TYPE BODY',
    'MATERIALIZED VIEW', 'SYNONYM', 'INDEX'
)
AND o.object_name NOT LIKE 'BIN$%'   -- exclude recyclebin objects
ORDER BY o.object_type, o.object_name;
```

### Custom Objects Summary

```sql
-- Summary counts by object type and status
SELECT
    object_type,
    status,
    COUNT(*) AS object_count,
    MIN(created) AS earliest_created,
    MAX(last_ddl_time) AS latest_modified
FROM dba_objects
WHERE object_name LIKE 'XX\_%' ESCAPE '\'
AND object_name NOT LIKE 'BIN$%'
GROUP BY object_type, status
ORDER BY object_count DESC;
```

### Custom PL/SQL Package Inventory

```sql
-- Custom packages with line counts and dependencies
SELECT
    s.owner,
    s.name AS package_name,
    s.type,
    COUNT(*) AS line_count,
    MIN(s.line) AS first_line,
    MAX(s.line) AS last_line,
    o.status,
    o.last_ddl_time
FROM dba_source s
JOIN dba_objects o ON o.owner = s.owner
    AND o.object_name = s.name
    AND o.object_type = s.type
WHERE s.name LIKE 'XX\_%' ESCAPE '\'
AND s.type IN ('PACKAGE', 'PACKAGE BODY')
GROUP BY s.owner, s.name, s.type, o.status, o.last_ddl_time
ORDER BY line_count DESC;
```

### Custom Concurrent Programs

```sql
-- Custom concurrent programs with execution details
SELECT
    fcp.concurrent_program_name,
    fcpt.user_concurrent_program_name,
    fcp.execution_method_code,
    DECODE(fcp.execution_method_code,
        'I', 'PL/SQL Stored Procedure',
        'H', 'Host (Shell Script)',
        'J', 'Java Concurrent Program',
        'K', 'Java Stored Procedure',
        'L', 'SQL*Loader',
        'M', 'Multi-Language Function',
        'P', 'Oracle Reports',
        'S', 'Spawned Process',
        'A', 'PL/SQL Procedure (using BI Publisher)',
        'X', 'FlexRpt',
        'B', 'Request Set Stage Function',
        fcp.execution_method_code
    ) AS execution_method_desc,
    fe.executable_name,
    fe.execution_file_name,
    fa.application_short_name,
    fcp.enabled_flag,
    fcp.srs_flag,
    fcp.run_alone_flag,
    fcp.creation_date,
    fcp.last_update_date
FROM fnd_concurrent_programs fcp
JOIN fnd_concurrent_programs_tl fcpt
    ON fcp.concurrent_program_id = fcpt.concurrent_program_id
    AND fcp.application_id = fcpt.application_id
    AND fcpt.language = 'US'
JOIN fnd_executables fe
    ON fcp.executable_id = fe.executable_id
    AND fcp.executable_application_id = fe.application_id
JOIN fnd_application fa
    ON fcp.application_id = fa.application_id
WHERE (
    fcp.concurrent_program_name LIKE 'XX\_%' ESCAPE '\'
    OR fa.application_short_name LIKE 'XX%'
)
ORDER BY fcp.concurrent_program_name;
```

### Concurrent Program Classification

Concurrent programs serve different purposes. Classify each by examining its
execution method and naming convention:

| Classification | Typical Naming | Execution Method | Purpose |
|----------------|---------------|------------------|---------|
| Report | XX_RPT_*, XX_*_REPORT | P (Oracle Reports) | Formatted output for users |
| Interface Inbound | XX_*_INT_IN, XX_*_IMPORT | I (PL/SQL), H (Host) | Load data from external systems |
| Interface Outbound | XX_*_INT_OUT, XX_*_EXTRACT | I (PL/SQL), H (Host) | Extract data for external systems |
| Conversion | XX_CNV_*, XX_*_CONV | I (PL/SQL), L (SQL*Loader) | One-time or periodic data migration |
| Extension | XX_*_EXT, XX_*_PROC | I (PL/SQL) | Custom business processing |
| Data Fix | XX_*_FIX, XX_*_PATCH | I (PL/SQL) | Corrective data updates |
| Purge/Archive | XX_*_PURGE, XX_*_ARCHIVE | I (PL/SQL) | Data lifecycle management |
| Alert/Notification | XX_*_ALERT, XX_*_NOTIFY | I (PL/SQL) | Send notifications on conditions |

### Form Personalizations

```sql
-- All form personalizations with conditions and actions
SELECT
    ffcr.rule_type,
    ffcr.enabled,
    ff.form_name,
    ffcr.function_name,
    ffcr.description,
    ffcr.trigger_event,
    ffcr.trigger_object,
    ffcr.condition,
    ffcr.sequence AS rule_sequence,
    ffca.action_type,
    ffca.summary AS action_summary,
    ffca.object_type AS target_object_type,
    ffca.target_object,
    ffca.property_name,
    ffca.property_value,
    ffcr.created_by,
    ffcr.creation_date,
    ffcr.last_update_date
FROM fnd_form_custom_rules ffcr
JOIN fnd_form_custom_actions ffca
    ON ffcr.rule_id = ffca.rule_id
JOIN fnd_form ff
    ON ffcr.form_id = ff.form_id
WHERE ffcr.enabled = 'Y'
ORDER BY ff.form_name, ffcr.sequence;
```

### Form Personalization Rule Types

| Rule Type | Trigger Event | Purpose |
|-----------|--------------|---------|
| A | WHEN-NEW-FORM-INSTANCE | Form-level initialization |
| A | WHEN-NEW-BLOCK-INSTANCE | Block-level initialization |
| A | WHEN-NEW-RECORD-INSTANCE | Record-level initialization |
| A | WHEN-NEW-ITEM-INSTANCE | Field focus event |
| A | WHEN-VALIDATE-RECORD | Record validation |
| A | WHEN-VALIDATE-ITEM | Field validation |
| F | (varies) | Function-level personalization |
| S | (varies) | Special personalization |

### Action Types in Personalizations

| Action Type | Description | Migration Impact |
|-------------|-------------|-----------------|
| P | Set field property (DISPLAYED, ENABLED, REQUIRED) | Map to UI conditional logic |
| M | Display message | Map to validation feedback |
| B | Execute built-in (GO_BLOCK, EXECUTE_QUERY) | Map to UI navigation/action |
| S | Execute PL/SQL (fire_custom_event, execute) | Extract and migrate as business logic |
| E | Raise error/warning | Map to validation rules |

### Custom Value Sets

```sql
-- Custom value sets with validation type
SELECT
    fvs.flex_value_set_name,
    fvs.validation_type,
    DECODE(fvs.validation_type,
        'I', 'Independent',
        'D', 'Dependent',
        'F', 'Table',
        'U', 'Special (PL/SQL)',
        'P', 'Pair',
        'N', 'None (No validation)',
        'X', 'Translatable Independent',
        'Y', 'Translatable Dependent',
        fvs.validation_type
    ) AS validation_type_desc,
    fvs.format_type,
    fvs.maximum_size,
    fvs.number_precision,
    fvs.description,
    -- For table-validated value sets
    fvst.application_table_name,
    fvst.value_column_name,
    fvst.meaning_column_name,
    fvst.id_column_name,
    fvst.additional_where_clause
FROM fnd_flex_value_sets fvs
LEFT JOIN fnd_flex_validation_tables fvst
    ON fvs.flex_value_set_id = fvst.flex_value_set_id
WHERE fvs.flex_value_set_name LIKE 'XX%'
ORDER BY fvs.flex_value_set_name;
```

### Workflow Customizations

```sql
-- Custom workflow item types and processes
SELECT
    wit.name AS item_type,
    wit.display_name,
    wit.wf_selector,
    wp.process_name,
    wpa.display_name AS process_display_name,
    wa.name AS activity_name,
    waa.display_name AS activity_display_name,
    wa.type,
    wa.function AS plsql_function,
    wa.result_type,
    wt.node_type,
    wt.type AS transition_type
FROM wf_item_types_vl wit
JOIN wf_activities wa ON wa.item_type = wit.name
JOIN wf_activities_tl waa ON wa.item_type = waa.item_type
    AND wa.name = waa.name
    AND wa.version = waa.version
    AND waa.language = 'US'
LEFT JOIN wf_process_activities wpa_link
    ON wpa_link.activity_item_type = wa.item_type
    AND wpa_link.activity_name = wa.name
LEFT JOIN wf_activities wp ON wpa_link.process_item_type = wp.item_type
    AND wpa_link.process_name = wp.name
LEFT JOIN wf_activities_tl wpa ON wp.item_type = wpa.item_type
    AND wp.name = wpa.name AND wp.version = wpa.version
    AND wpa.language = 'US'
LEFT JOIN wf_activity_transitions wt
    ON wt.from_process_activity = wpa_link.instance_id
WHERE wit.name LIKE 'XX%'
AND wa.end_date IS NULL  -- only active versions
ORDER BY wit.name, wp.process_name, wpa_link.process_sequence;
```

### Custom Profile Options

```sql
-- Custom profile options with current settings
SELECT
    fpo.profile_option_name,
    fpot.user_profile_option_name,
    fpot.description,
    fpo.sql_validation,
    fpov.level_id,
    DECODE(fpov.level_id,
        10001, 'Site',
        10002, 'Application',
        10003, 'Responsibility',
        10004, 'User',
        10005, 'Server',
        10006, 'Organization',
        fpov.level_id
    ) AS level_name,
    fpov.profile_option_value
FROM fnd_profile_options fpo
JOIN fnd_profile_options_tl fpot
    ON fpo.profile_option_id = fpot.profile_option_id
    AND fpot.language = 'US'
LEFT JOIN fnd_profile_option_values fpov
    ON fpo.profile_option_id = fpov.profile_option_id
    AND fpo.application_id = fpov.application_id
WHERE fpo.profile_option_name LIKE 'XX%'
ORDER BY fpo.profile_option_name, fpov.level_id;
```

## Oracle Forms 10g Analysis

### Form Module Structure

An Oracle Forms .fmb file contains these components:

```
Form Module
├── Triggers (form-level)
│   ├── WHEN-NEW-FORM-INSTANCE
│   ├── KEY-* triggers
│   ├── ON-ERROR
│   └── PRE-FORM / POST-FORM
├── Alerts
├── Attached Libraries (.pll)
├── Data Blocks
│   ├── Database blocks (map to base tables/views)
│   │   ├── Items (fields)
│   │   │   ├── Text items, display items, LOV items
│   │   │   └── Item-level triggers (WHEN-VALIDATE-ITEM, etc.)
│   │   ├── Relations (master-detail)
│   │   └── Block-level triggers (WHEN-* triggers)
│   └── Control blocks (non-database)
│       └── Buttons, checkboxes, radio groups
├── Canvases
│   ├── Content canvases
│   ├── Stacked canvases
│   └── Tab canvases
├── LOVs (List of Values)
│   └── Record groups (SQL queries backing LOVs)
├── Object Groups (reusable component bundles)
├── Parameters (form parameters)
├── Program Units (PL/SQL in the form)
├── Property Classes
├── Record Groups
├── Visual Attributes
└── Windows
```

### What to Analyze in Forms

**Triggers** (where business logic lives):
```
Form-level:
  WHEN-NEW-FORM-INSTANCE    — initialization, parameter processing
  PRE-FORM / POST-FORM      — setup and cleanup
  KEY-COMMIT                 — save behavior override
  KEY-EXIT / KEY-CLRFRM      — exit/clear behavior
  ON-ERROR                   — custom error handling

Block-level:
  WHEN-NEW-BLOCK-INSTANCE    — block initialization
  WHEN-CREATE-RECORD         — new record defaults
  PRE-QUERY / POST-QUERY     — query modification and post-processing
  PRE-INSERT / PRE-UPDATE    — validation before DML
  ON-INSERT / ON-UPDATE      — DML override (API calls instead of base table DML)
  PRE-DELETE / ON-DELETE      — delete validation and override

Item-level:
  WHEN-VALIDATE-ITEM         — field-level validation
  WHEN-LIST-CHANGED          — dropdown change handler
  WHEN-CHECKBOX-CHANGED      — checkbox toggle handler
  WHEN-RADIO-CHANGED         — radio button handler
  WHEN-NEW-ITEM-INSTANCE     — field focus (defaulting, enabling)
  KEY-NEXT-ITEM              — tab-out behavior
```

**Program Units** — PL/SQL procedures/functions defined within the form:
```sql
-- These are compiled INTO the .fmb and are not visible in the database.
-- They must be extracted by opening the .fmb in Forms Builder or using
-- a Forms XML export (frmf2xml utility).
```

**Attached Libraries (.pll)** — Shared PL/SQL libraries:
```
$CUSTOM_TOP/lib/CUSTOM.pll         -- global hook library (every form attaches this)
$CUSTOM_TOP/lib/XX_COMMON.pll      -- shared utility library
$CUSTOM_TOP/lib/XX_SECURITY.pll    -- custom security checks
$AU_TOP/resource/APPCORE.pll       -- Oracle standard library
$AU_TOP/resource/FNDSQF.pll        -- Oracle standard: profiles, messages, flexfields
```

**CUSTOM.pll** — The global hook library:
```sql
-- CUSTOM.pll contains event handlers called by every EBS form.
-- It provides hooks for custom logic WITHOUT modifying standard forms.
-- The key procedure is:
PROCEDURE event(event_name VARCHAR2) IS
BEGIN
    IF event_name = 'WHEN-NEW-FORM-INSTANCE' THEN
        -- Custom form initialization
        IF NAME_IN('system.current_form') = 'POXPOEPO' THEN
            -- Custom logic for Purchase Order form
            XX_PO_CUSTOM.on_form_open;
        END IF;
    ELSIF event_name = 'WHEN-VALIDATE-RECORD' THEN
        -- Custom record validation
        IF NAME_IN('system.current_form') = 'APXINWKB' THEN
            XX_AP_CUSTOM.validate_invoice;
        END IF;
    END IF;
END event;
```

### LOV (List of Values) Analysis

LOVs are query-backed pop-up selection lists:

```sql
-- LOVs are defined in forms with backing record groups.
-- Record groups contain SQL that may encode business rules:

-- Example: Custom LOV filtering by responsibility
SELECT employee_id, employee_name
FROM per_all_people_f
WHERE effective_start_date <= SYSDATE
  AND effective_end_date >= SYSDATE
  AND business_group_id = FND_PROFILE.VALUE('PER_BUSINESS_GROUP_ID')
  AND employee_id IN (
      SELECT employee_id FROM xx_authorized_approvers
      WHERE approval_type = :parameter.approval_type
  )
ORDER BY employee_name;
```

## OBIEE / Oracle Reports Analysis

### Oracle Reports (.rdf Files)

```
Report Module (.rdf)
├── Data Model
│   ├── Queries (SQL statements)
│   ├── Groups (break groups for aggregation)
│   ├── Columns (computed columns with PL/SQL formulas)
│   ├── Summary columns (SUM, COUNT, AVG)
│   ├── Formula columns (PL/SQL functions)
│   └── Parameters
├── Layout Model
│   ├── Frames (repeating and non-repeating)
│   ├── Fields (data-bound display areas)
│   └── Boilerplate (static text, images)
├── Program Units (PL/SQL)
│   ├── Formula functions
│   ├── Validation triggers
│   └── Utility packages
└── Triggers
    ├── Before Report
    ├── After Report
    ├── Between Pages
    └── Before/After Parameter Form
```

**Key analysis points**:
- Report queries may contain complex business logic in WHERE clauses
- Formula columns contain PL/SQL calculations that represent business rules
- Before Report triggers often set up session context (profiles, org context)
- Parameters may have LOV queries with business-rule-based filtering

### OBIEE Analysis

```
OBIEE Components:
├── RPD (Repository) — metadata model
│   ├── Physical Layer (database schema mapping)
│   ├── Business Model and Mapping Layer (business logic)
│   │   ├── Logical table sources
│   │   ├── Calculation measures
│   │   ├── Derived columns
│   │   └── Filters and security
│   └── Presentation Layer (user-facing catalog)
│       ├── Subject areas
│       └── Presentation columns
├── Web Catalog
│   ├── Dashboards
│   ├── Analyses (Answers)
│   ├── Prompts
│   ├── Filters
│   ├── Agents (scheduled deliveries)
│   └── Actions
└── Custom SQL reports (BI Publisher)
    ├── Data model (.xdm)
    ├── Templates (.rtf, .xsl, .pdf)
    └── Data sources (SQL queries, web services)
```

## Integration Points

### SOA Composites and BPEL

```
SOA Suite Integration Layer:
├── BPEL Processes
│   ├── Synchronous request-response
│   ├── Asynchronous fire-and-forget
│   └── Long-running with correlation
├── ESB Routes (Mediator)
│   ├── Content-based routing
│   ├── Message transformation (XSLT)
│   └── Message filtering
├── Web Services (WSDL)
│   ├── EBS exposed via Integration Repository (IREP)
│   └── Custom BPEL/ESB endpoints
└── Adapters
    ├── Database adapter (polling, DML)
    ├── File/FTP adapter
    ├── JMS/AQ adapter
    └── Technology adapters (SAP, Siebel)
```

### Common EBS Integration Patterns

| Pattern | Implementation | Detection |
|---------|---------------|-----------|
| Inbound file interface | SQL*Loader or external table → staging → API call | Concurrent program with .ctl file |
| Outbound file extract | PL/SQL → UTL_FILE or DBMS_OUTPUT → flat file | Concurrent program writing to $XXCUST_TOP/outbound |
| Web service inbound | SOA composite → EBS API | BPEL process calling PL/SQL |
| Web service outbound | EBS business event → SOA → external service | WF_EVENT subscriptions |
| Database link | Direct SQL via DB link | DBA_DB_LINKS, references to @dblink in PL/SQL |
| Interface tables | External system → XX_*_INTERFACE → API validation → base tables | Tables named *_INTERFACE, *_STG, *_STAGING |
| Concurrent request | External system triggers via FND_REQUEST.SUBMIT_REQUEST | Custom programs with SRS flag = 'Y' |

### Database Link Inventory

```sql
-- All database links (potential external system connections)
SELECT
    owner,
    db_link,
    username,
    host,
    created
FROM dba_db_links
ORDER BY owner, db_link;
```

### Interface Table Inventory

```sql
-- Custom interface and staging tables
SELECT
    table_name,
    num_rows,
    last_analyzed,
    tablespace_name
FROM dba_tables
WHERE (
    table_name LIKE 'XX%INTERFACE%'
    OR table_name LIKE 'XX%STG%'
    OR table_name LIKE 'XX%STAGING%'
    OR table_name LIKE 'XX%TEMP%'
)
AND table_name NOT LIKE 'BIN$%'
ORDER BY table_name;
```

## Flexfield Analysis

### Key Flexfields (KFF)

Key Flexfields encode structured identifiers (like GL account codes):

```sql
-- Key Flexfield structure inventory
SELECT
    fif.id_flex_code,
    fif.id_flex_name,
    fa.application_short_name,
    fifs.id_flex_structure_name,
    fifsg.segment_name,
    fifsg.segment_num,
    fifsg.application_column_name,
    fifsg.flex_value_set_id,
    fvs.flex_value_set_name,
    fifsg.display_flag,
    fifsg.required_flag,
    fifsg.default_type,
    fifsg.default_value
FROM fnd_id_flexs fif
JOIN fnd_application fa ON fif.application_id = fa.application_id
JOIN fnd_id_flex_structures_vl fifs
    ON fif.application_id = fifs.application_id
    AND fif.id_flex_code = fifs.id_flex_code
JOIN fnd_id_flex_segments fifsg
    ON fifs.application_id = fifsg.application_id
    AND fifs.id_flex_code = fifsg.id_flex_code
    AND fifs.id_flex_num = fifsg.id_flex_num
LEFT JOIN fnd_flex_value_sets fvs
    ON fifsg.flex_value_set_id = fvs.flex_value_set_id
ORDER BY fif.id_flex_code, fifs.id_flex_structure_name, fifsg.segment_num;
```

**Common Key Flexfields**:
| KFF Code | Name | Purpose |
|----------|------|---------|
| GL# | Accounting Flexfield | Chart of Accounts structure |
| MSTK | System Items | Item (part number) structure |
| MTLL | Stock Locators | Warehouse location coding |
| CT# | Territory Flexfield | Sales territory coding |
| MDSP | Category Flexfield | Item category coding |
| GRP | People Group | Employee group coding |
| POS | Position Flexfield | Position hierarchy coding |

### Descriptive Flexfields (DFF)

DFFs are the primary extension mechanism for adding custom fields to standard forms:

```sql
-- Descriptive Flexfield segments (custom fields)
SELECT
    fdf.descriptive_flexfield_name,
    fdf.application_table_name,
    fdf.title,
    fdfcu.descriptive_flex_context_code,
    fdfcu.descriptive_flex_context_name,
    fdfs.end_user_column_name,
    fdfs.application_column_name,
    fdfs.sequence_number,
    fdfs.flex_value_set_id,
    fvs.flex_value_set_name,
    fdfs.required_flag,
    fdfs.display_flag,
    fdfs.default_type,
    fdfs.default_value
FROM fnd_descriptive_flexs fdf
JOIN fnd_descr_flex_contexts_vl fdfcu
    ON fdf.application_id = fdfcu.application_id
    AND fdf.descriptive_flexfield_name = fdfcu.descriptive_flexfield_name
JOIN fnd_descr_flex_column_usages fdfs
    ON fdfcu.application_id = fdfs.application_id
    AND fdfcu.descriptive_flexfield_name = fdfs.descriptive_flexfield_name
    AND fdfcu.descriptive_flex_context_code = fdfs.descriptive_flex_context_code
LEFT JOIN fnd_flex_value_sets fvs
    ON fdfs.flex_value_set_id = fvs.flex_value_set_id
WHERE fdfs.enabled_flag = 'Y'
AND fdfcu.enabled_flag = 'Y'
ORDER BY fdf.descriptive_flexfield_name, fdfs.sequence_number;
```

**DFF storage pattern**: DFF values are stored in `ATTRIBUTE1` through `ATTRIBUTE15`
(and `ATTRIBUTE_CATEGORY` for context) columns on the base table. For example,
`PO_HEADERS_ALL.ATTRIBUTE1` might store a custom project code.

### Cross-Validation Rules

```sql
-- GL cross-validation rules (business rules for account combinations)
SELECT
    fca.name,
    fca.description,
    fca.error_message,
    fca.enabled_flag,
    fcal.include_exclude_indicator,
    fcal.concatenated_segments_low,
    fcal.concatenated_segments_high
FROM gl_cross_validation_rules fca
JOIN gl_cross_validation_lines fcal
    ON fca.cross_validation_rule_id = fcal.cross_validation_rule_id
WHERE fca.enabled_flag = 'Y'
ORDER BY fca.name;
```

## API Layer Analysis

### Standard EBS APIs

EBS provides public APIs for programmatic access to business objects. Custom code
should call these rather than performing direct DML on base tables:

```sql
-- Common EBS API packages (standard, not custom)
HR_EMPLOYEE_API           -- Employee creation/update
PO_HEADERS_SV             -- Purchase Order header
PO_LINES_SV               -- Purchase Order lines
AP_INVOICES_PKG           -- Accounts Payable invoices
AR_RECEIPT_API_PUB        -- Accounts Receivable receipts
INV_QUANTITY_TREE_PUB     -- Inventory on-hand quantities
WF_ENGINE                 -- Workflow engine operations
FND_REQUEST               -- Concurrent request submission
FND_PROFILE               -- Profile option access
FND_MESSAGE               -- Message dictionary
FND_GLOBAL                -- Session context (user, resp, org)
```

### Custom API Wrapper Detection

```sql
-- Custom packages that wrap standard APIs
SELECT
    object_name,
    object_type,
    status
FROM dba_objects
WHERE object_name LIKE 'XX%PKG%'
AND object_type IN ('PACKAGE', 'PACKAGE BODY')
ORDER BY object_name;

-- Check which standard APIs are called by custom code
SELECT DISTINCT
    referenced_owner,
    referenced_name,
    referenced_type
FROM dba_dependencies
WHERE name LIKE 'XX\_%' ESCAPE '\'
AND type IN ('PACKAGE', 'PACKAGE BODY', 'PROCEDURE', 'FUNCTION')
AND referenced_type IN ('PACKAGE', 'PACKAGE BODY')
AND referenced_name NOT LIKE 'XX%'
ORDER BY referenced_name;
```

## Custom Grants and Responsibilities

```sql
-- Custom responsibilities
SELECT
    fr.responsibility_key,
    frt.responsibility_name,
    fa.application_short_name,
    fm.menu_name,
    fmt.user_menu_name,
    fdg.data_group_name,
    fr.start_date,
    fr.end_date,
    fr.creation_date
FROM fnd_responsibility fr
JOIN fnd_responsibility_tl frt
    ON fr.responsibility_id = frt.responsibility_id
    AND fr.application_id = frt.application_id
    AND frt.language = 'US'
JOIN fnd_application fa
    ON fr.application_id = fa.application_id
JOIN fnd_menus fm
    ON fr.menu_id = fm.menu_id
LEFT JOIN fnd_menus_tl fmt
    ON fm.menu_id = fmt.menu_id AND fmt.language = 'US'
LEFT JOIN fnd_data_groups fdg
    ON fr.data_group_id = fdg.data_group_id
    AND fr.data_group_application_id = fdg.application_id
WHERE fr.responsibility_key LIKE 'XX%'
OR fa.application_short_name LIKE 'XX%'
ORDER BY fr.responsibility_key;
```

## Common Gotchas

### APPS vs Custom Schema Ownership
EBS installs most objects in the `APPS` schema. Custom objects may be created in
`APPS` (common but bad practice) or in a dedicated custom schema (e.g., `XXFAA`).
Objects in `APPS` that start with `XX_` are custom. Objects in `APPS` without the
`XX_` prefix but not in Oracle's standard catalog are also potentially custom —
cross-reference against the EBS standard object list for the installed patchset.

### Shared EBS Patterns That Look Custom
These are standard EBS patterns that may appear custom:
- `_ALL` suffix tables (e.g., `PO_HEADERS_ALL`) — these are multi-org base tables
- `_V` and `_VL` suffix views — these are standard translated views
- `FND_FLEX_VALUES` entries — standard flexfield values, even if content is custom
- `WF_LOCAL_*` tables — local copies of workflow data, not customizations
- `HR_ALL_*` views — standard HR multi-org views

### Forms Personalization Gotchas
- Personalizations fire in sequence order — later rules can override earlier ones
- Condition evaluation uses Forms syntax, not standard PL/SQL
- Some personalizations call PL/SQL that must exist in the database
- Personalizations at the responsibility level override site-level
- Disabled personalizations may still be important (they document past requirements)

### Concurrent Program Gotchas
- Programs with `run_alone_flag = 'Y'` lock the concurrent manager — these are high-impact
- Programs with `srs_flag = 'N'` cannot be submitted from SRS (Standard Request Submission) — they are called by other programs only
- Execution file paths may reference `$XXCUST_TOP/bin/` which is a filesystem dependency
- Host-based concurrent programs (.prog files) may call OS-level utilities
- SQL*Loader programs depend on .ctl (control) files in `$XXCUST_TOP/bin/`

### Upgrade and Patch Impact
- Custom objects referencing standard tables/views may break after EBS patches
- Forms personalizations may reference items that are renamed or removed in patches
- Custom workflows may reference standard functions that change behavior
- CUSTOM.pll hook points may reference forms that are replaced in upgrades
