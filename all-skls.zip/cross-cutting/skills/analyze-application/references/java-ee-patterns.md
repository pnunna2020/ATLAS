# Java EE Analysis Patterns

## Where Business Logic Hides
1. **EJB Session Beans** — Stateless and stateful business logic
2. **JPA/Hibernate entities** — Data access with embedded validation
3. **Servlets/JSP** — Request handling and view logic
4. **Spring beans** — If using Spring (common in newer Java apps)
5. **web.xml / application.xml** — Configuration and routing
6. **Stored procedures** — Called via JDBC/JPA native queries

## Framework Detection
- Check for: `spring-boot-starter`, `javax.ejb`, `javax.faces` (JSF),
  `struts-config.xml`, `web.xml` servlet mappings
- Build system: Maven (pom.xml) vs Gradle (build.gradle)
- App server: WebLogic, JBoss/WildFly, Tomcat, WebSphere

## Common Gotchas
- **JNDI datasources**: DB connections defined at app server level, not in code
- **EAR packaging**: Multiple WARs in one EAR share classes
- **AOP/interceptors**: Business logic in aspects/interceptors is invisible
  to straightforward code scanning
