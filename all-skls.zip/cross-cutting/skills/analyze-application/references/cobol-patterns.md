# COBOL Analysis Patterns

Reference for the Analyze Application skill when performing discovery and analysis
of COBOL legacy applications. COBOL applications are the backbone of many government
and enterprise systems, particularly in batch processing, transaction processing (CICS),
and database-driven (DB2, IMS) workloads. This guide covers program structure analysis,
call graph construction, data analysis, and modernization considerations.

## Technology Detection

Confirm COBOL by checking for:
- `.cbl`, `.cob`, `.CBL`, `.COB` files (COBOL source)
- `.cpy`, `.CPY` files (copybooks)
- `.jcl`, `.JCL` files (Job Control Language)
- `.bms`, `.BMS` files (BMS maps for CICS)
- `IDENTIFICATION DIVISION` or `ID DIVISION` in source files
- `EXEC CICS` or `EXEC SQL` embedded statements
- `EXEC DLI` statements (IMS/DL1)
- `SELECT ... ASSIGN TO` clauses (file control)
- JCL referencing `IKJEFT01`, `IGYCRCTL`, or `IGYWCL` (COBOL compilers)

### Dialect Detection

COBOL implementations vary by vendor and platform:

| Dialect | Platform | Key Indicators |
|---------|----------|----------------|
| IBM Enterprise COBOL | z/OS | `CBL` compiler directive, `EXEC CICS`, `EXEC SQL`, `EXEC DLI` |
| Micro Focus COBOL | Distributed | `.int`, `.gnt` files, `$SET` directives, `COBDIR` env variable |
| ACUCOBOL-GT | Distributed | `ACUCOBOL` in comments, `-Fi` file status, `ACCEPT FROM ENVIRONMENT` |
| GnuCOBOL | Open source | `cobc` compiler, `COB_*` environment variables |
| Fujitsu NetCOBOL | Windows/Linux | `@OPTIONS` directive, `.cob` extension typical |

### COBOL Standard Detection

| Standard | Year | Key Feature |
|----------|------|-------------|
| COBOL-68 | 1968 | `REMARKS` paragraph, `NOTE` statement |
| COBOL-74 | 1974 | No scope terminators (period-delimited) |
| COBOL-85 | 1985 | `END-IF`, `END-PERFORM`, `END-READ` scope terminators, nested programs |
| COBOL 2002 | 2002 | Object-oriented COBOL, `INVOKE`, `METHOD-ID` |
| COBOL 2014 | 2014 | Dynamic tables, conditional compilation |

**Version inference rule**: If the code uses period-delimited IF/PERFORM without
scope terminators, it predates COBOL-85 and is likely COBOL-74 vintage. If
`END-IF` and `END-PERFORM` are present, it is COBOL-85 or later.

## Program Structure Analysis

### The Four Divisions

Every COBOL program has up to four divisions, always in this order:

```cobol
       IDENTIFICATION DIVISION.
       PROGRAM-ID. AIRMAN-INQUIRY.
       AUTHOR. FAA-MODERNIZATION-TEAM.
       DATE-WRITTEN. 2024-01-15.
       DATE-COMPILED.
      *============================================================
      * Program: AIRMAN-INQUIRY
      * Purpose: Retrieve and display airman certification records
      * Called by: CICS transaction AINQ
      *============================================================

       ENVIRONMENT DIVISION.
       CONFIGURATION SECTION.
       SOURCE-COMPUTER. IBM-390.
       OBJECT-COMPUTER. IBM-390.
       INPUT-OUTPUT SECTION.
       FILE-CONTROL.
           SELECT REPORT-FILE
               ASSIGN TO RPTFILE
               ORGANIZATION IS SEQUENTIAL
               FILE STATUS IS WS-FILE-STATUS.

       DATA DIVISION.
       FILE SECTION.
       FD  REPORT-FILE
           RECORDING MODE IS F
           RECORD CONTAINS 132 CHARACTERS.
       01  REPORT-RECORD              PIC X(132).

       WORKING-STORAGE SECTION.
       01  WS-FILE-STATUS             PIC XX.
       01  WS-AIRMAN-RECORD.
           05  WS-AIRMAN-ID           PIC X(09).
           05  WS-AIRMAN-NAME         PIC X(40).
           05  WS-CERT-TYPE           PIC X(10).
           05  WS-CERT-STATUS         PIC X(08).
           05  WS-CERT-EXPIRY         PIC 9(08).

       LINKAGE SECTION.
       01  LS-COMMAREA.
           05  LS-FUNCTION-CODE       PIC X(02).
           05  LS-AIRMAN-ID           PIC X(09).
           05  LS-RETURN-CODE         PIC 9(04).

       PROCEDURE DIVISION USING LS-COMMAREA.
       0000-MAIN-PROCESS.
           PERFORM 1000-INITIALIZE
           PERFORM 2000-PROCESS-REQUEST
           PERFORM 9000-RETURN
           STOP RUN.
```

**Division analysis checklist**:
1. **IDENTIFICATION DIVISION**: Extract program name, author, purpose from comments
2. **ENVIRONMENT DIVISION**: Map all file assignments (`SELECT ... ASSIGN TO`), identify I/O dependencies
3. **DATA DIVISION**: Catalog all record layouts, working storage structures, linkage section parameters
4. **PROCEDURE DIVISION**: Map the paragraph/section call graph starting from the entry point

### Division-Specific Analysis Points

| Division | Analyze For | Business Impact |
|----------|-------------|-----------------|
| IDENTIFICATION | Program name, called-by chain, purpose comments | System inventory, dependency mapping |
| ENVIRONMENT | File assignments, special-names, decimal-point | Infrastructure dependencies, locale settings |
| DATA (FILE SECTION) | FD entries, record layouts, block sizes | File format contracts, storage requirements |
| DATA (WORKING-STORAGE) | 01-levels, condition names (88), constants | Business domain model, enumerations, configuration |
| DATA (LINKAGE SECTION) | Parameter layouts, COMMAREA structures | API contracts between programs |
| PROCEDURE | Paragraph flow, PERFORM graph, error handling | Business logic, workflow, error recovery |

## Paragraph/Section Analysis

### Call Graph Through PERFORM Statements

COBOL programs are structured as paragraphs (or sections containing paragraphs)
connected by PERFORM statements. Build the call graph by tracing PERFORM references:

```cobol
       0000-MAIN-PROCESS.
           PERFORM 1000-INITIALIZE
           PERFORM 2000-PROCESS-REQUEST
           PERFORM 3000-GENERATE-REPORT
           PERFORM 9000-CLEANUP
           STOP RUN.

       1000-INITIALIZE.
           PERFORM 1100-OPEN-FILES
           PERFORM 1200-LOAD-TABLES
           EXIT.

       2000-PROCESS-REQUEST.
           EVALUATE WS-REQUEST-TYPE
               WHEN 'INQ'
                   PERFORM 2100-INQUIRY
               WHEN 'UPD'
                   PERFORM 2200-UPDATE
               WHEN 'DEL'
                   PERFORM 2300-DELETE
               WHEN OTHER
                   PERFORM 9500-ERROR-INVALID-REQUEST
           END-EVALUATE.

       2100-INQUIRY.
           PERFORM 2110-READ-AIRMAN-RECORD
           PERFORM 2120-FORMAT-RESPONSE
           EXIT.
```

**Call graph extraction approach**:
1. Grep all `PERFORM` statements to build a directed graph: caller paragraph -> callee paragraph
2. Identify the entry point (first paragraph in PROCEDURE DIVISION or paragraph named in `PERFORM` from main)
3. Detect unreachable paragraphs (defined but never PERFORMed — may be dead code)
4. Detect PERFORM THRU ranges: `PERFORM 2000-START THRU 2999-EXIT` executes all paragraphs in that range sequentially

### GO TO Tracking

`GO TO` breaks structured flow and must be tracked carefully:

```cobol
       2200-UPDATE.
           IF WS-RECORD-LOCKED
               GO TO 2200-UPDATE-EXIT
           END-IF
           PERFORM 2210-VALIDATE-INPUT
           IF WS-VALIDATION-ERROR
               GO TO 2200-UPDATE-EXIT
           END-IF
           PERFORM 2220-WRITE-RECORD
           EXIT.
       2200-UPDATE-EXIT.
           EXIT.
```

**GO TO patterns**:
- **Forward GO TO to exit**: Used as early return. Common and generally safe.
- **GO TO within a section**: Used for local flow control. Map to if/else or early returns.
- **GO TO across sections**: Creates spaghetti flow. Flag as high-complexity area.
- **ALTER statement**: Dynamically changes GO TO targets at runtime. Extremely rare but extremely dangerous. Flag for manual review.

```cobol
      * ALTER is almost never used but must be detected
       ALTER 2200-UPDATE TO PROCEED TO 2200-UPDATE-V2.
```

### PERFORM VARYING (Loops)

```cobol
       PERFORM 3100-PROCESS-ITEM
           VARYING WS-INDEX FROM 1 BY 1
           UNTIL WS-INDEX > WS-ITEM-COUNT
           OR WS-ERROR-FLAG = 'Y'.
```

This is equivalent to a `for` loop with a compound exit condition. Map the
loop variable, bounds, step, and exit conditions.

## COPY/INCLUDE Resolution

### Copybook Inventory

Copybooks (`.cpy` files) are COBOL's reuse mechanism. They are included at
compile time via the `COPY` statement:

```cobol
       WORKING-STORAGE SECTION.
       COPY AIRMAN-REC.
       COPY DATE-ROUTINES.
       COPY ERROR-CODES.
```

**Copybook analysis approach**:
1. Grep all source files for `COPY` statements
2. Build a matrix: copybook -> list of programs that include it
3. Identify shared data structures (copybooks used by many programs)
4. Identify shared business logic (copybooks containing PROCEDURE DIVISION code)
5. Detect nested copybooks (copybooks that themselves contain `COPY` statements)

### Nested Copybook Chains

Copybooks can include other copybooks, creating dependency chains:

```
AIRMAN-INQUIRY.cbl
  └── COPY AIRMAN-REC.cpy
        └── COPY DATE-FIELDS.cpy
        └── COPY CERT-CODES.cpy
              └── COPY COMMON-CODES.cpy
```

Resolve the entire chain to get the complete data structure. Circular copybook
references are invalid but should be detected as a build issue.

### REPLACING Clauses

The `COPY ... REPLACING` clause substitutes text during inclusion:

```cobol
       COPY AIRMAN-REC REPLACING
           ==:PREFIX:== BY ==WS-==
           ==:TABLE:==  BY ==AIRMEN==.
```

This means the copybook uses generic placeholders (`:PREFIX:`, `:TABLE:`) that
are replaced with specific values when included. The same copybook can produce
different data structures in different programs. Always resolve REPLACING clauses
to understand the actual field names in each program.

### Library Naming Conventions

Copybooks may be in different libraries or directories:
```cobol
       COPY AIRMAN-REC OF COPYLIB.
       COPY DATE-ROUTINES IN SYSLIB.
```

The `OF` or `IN` clause specifies the library. Map library names to physical
directories in the build configuration (JCL SYSLIB DD concatenation).

## CICS Transaction Mapping

### EXEC CICS Commands

CICS (Customer Information Control System) provides online transaction processing.
Key commands to catalog:

```cobol
      * Screen I/O
           EXEC CICS SEND MAP('AINQM01')
                     MAPSET('AINQMS')
                     FROM(AINQ-MAP-DATA)
                     ERASE
           END-EXEC.

           EXEC CICS RECEIVE MAP('AINQM01')
                     MAPSET('AINQMS')
                     INTO(AINQ-MAP-DATA)
           END-EXEC.

      * Program-to-program communication
           EXEC CICS LINK PROGRAM('AIRVALID')
                     COMMAREA(WS-COMMAREA)
                     LENGTH(WS-COMMAREA-LENGTH)
           END-EXEC.

           EXEC CICS XCTL PROGRAM('AINQMENU')
                     COMMAREA(WS-COMMAREA)
           END-EXEC.

      * Asynchronous processing
           EXEC CICS START TRANSID('ARPT')
                     FROM(WS-REPORT-REQUEST)
                     LENGTH(WS-REQUEST-LENGTH)
                     INTERVAL(001500)
           END-EXEC.

      * Temporary storage (cross-transaction data passing)
           EXEC CICS WRITEQ TS QUEUE('AINQ' || WS-TERMINAL-ID)
                     FROM(WS-SEARCH-RESULTS)
                     LENGTH(WS-RESULTS-LENGTH)
                     ITEM(WS-ITEM-NUMBER)
           END-EXEC.

           EXEC CICS READQ TS QUEUE('AINQ' || WS-TERMINAL-ID)
                     INTO(WS-SEARCH-RESULTS)
                     LENGTH(WS-RESULTS-LENGTH)
                     ITEM(WS-ITEM-NUMBER)
           END-EXEC.

      * Error handling
           EXEC CICS HANDLE CONDITION
                     NOTFND(9100-NOT-FOUND)
                     DUPKEY(9200-DUPLICATE)
                     ERROR(9999-ABEND-HANDLER)
           END-EXEC.

           EXEC CICS HANDLE ABEND PROGRAM('ABNDHNDL')
           END-EXEC.
```

### CICS Command Inventory

| Command | Purpose | Modern Equivalent |
|---------|---------|-------------------|
| `SEND MAP` | Display screen to terminal | Render HTML page / API response |
| `RECEIVE MAP` | Read user input from screen | Parse HTTP request / form data |
| `LINK` | Call program with return (synchronous) | REST API call / function call |
| `XCTL` | Transfer control (no return) | HTTP redirect / page navigation |
| `START` | Schedule asynchronous transaction | Message queue publish / async job |
| `RETURN TRANSID` | Return to CICS with next transaction set | Set next route / SPA navigation |
| `WRITEQ TS` | Write to temporary storage queue | Redis/cache write / session store |
| `READQ TS` | Read from temporary storage queue | Redis/cache read / session read |
| `DELETEQ TS` | Delete temporary storage queue | Cache invalidation / session cleanup |
| `WRITEQ TD` | Write to transient data queue | Message queue publish / log write |
| `ENQ` / `DEQ` | Resource locking | Distributed lock / mutex |
| `HANDLE CONDITION` | Register error handler | try/catch or error middleware |
| `HANDLE ABEND` | Register abend handler | Global exception handler |

### BMS Map Analysis

BMS (Basic Mapping Support) maps define 3270 screen layouts:

```
AINQMS   DFHMSD TYPE=MAP,MODE=INOUT,CTRL=(FREEKB,FRSET),         X
               LANG=COBOL,STORAGE=AUTO,TIOAPFX=YES
AINQM01  DFHMDI SIZE=(24,80),LINE=1,COLUMN=1
TITLE    DFHMDF POS=(01,25),LENGTH=30,                            X
               ATTRB=(ASKIP,BRT),                                  X
               INITIAL='AIRMAN CERTIFICATION INQUIRY'
AIDLBL   DFHMDF POS=(05,02),LENGTH=10,                            X
               ATTRB=(ASKIP,NORM),                                 X
               INITIAL='AIRMAN ID:'
AIDINP   DFHMDF POS=(05,13),LENGTH=09,                            X
               ATTRB=(UNPROT,IC,FSET),                             X
               PICIN='X(09)',PICOUT='X(09)'
NAMELBL  DFHMDF POS=(07,02),LENGTH=10,ATTRB=(ASKIP,NORM),        X
               INITIAL='NAME:'
NAMEOUT  DFHMDF POS=(07,13),LENGTH=40,ATTRB=(PROT,NORM)
MSGLNE   DFHMDF POS=(23,02),LENGTH=78,ATTRB=(ASKIP,BRT)
         DFHMSD TYPE=FINAL
         END
```

**BMS analysis checklist**:
1. Extract all field names, positions, lengths, and attributes
2. Identify input fields (`UNPROT`) vs. output fields (`PROT`, `ASKIP`)
3. Map field names to COBOL data names (e.g., `AIDINP` becomes `AIDINPI` for input, `AIDINPO` for output in the generated copybook)
4. Identify the screen flow: which maps are displayed in what sequence (trace `SEND MAP` and `RECEIVE MAP` in the COBOL source)

### Transaction Flow Mapping

Map the complete transaction lifecycle:
```
Transaction: AINQ (Airman Inquiry)
  1. User enters AINQ at terminal
  2. CICS routes to program AINQPGM
  3. AINQPGM sends map AINQM01 (search screen)
  4. AINQPGM returns with TRANSID('AINQ')
  5. User enters airman ID, presses ENTER
  6. CICS routes to AINQPGM again
  7. AINQPGM receives map, reads AIRMAN-ID
  8. AINQPGM LINKs to AIRVALID (validation subprogram)
  9. AINQPGM reads DB2 AIRMEN table
  10. AINQPGM sends map AINQM02 (results screen)
  11. User presses PF3 to exit
  12. AINQPGM XCTLs to MAINMENU
```

## DB2 Embedded SQL

### EXEC SQL Blocks

DB2 SQL is embedded directly in COBOL source between `EXEC SQL` and `END-EXEC`:

```cobol
           EXEC SQL
               SELECT AIRMAN_NAME,
                      CERT_TYPE,
                      CERT_STATUS,
                      CERT_EXPIRY_DATE
               INTO :WS-AIRMAN-NAME,
                    :WS-CERT-TYPE,
                    :WS-CERT-STATUS,
                    :WS-CERT-EXPIRY
               FROM AIRMEN
               WHERE AIRMAN_ID = :WS-AIRMAN-ID
           END-EXEC.

           EVALUATE SQLCODE
               WHEN 0
                   CONTINUE
               WHEN 100
                   MOVE 'NOT FOUND' TO WS-MSG
               WHEN OTHER
                   PERFORM 9100-SQL-ERROR
           END-EVALUATE.
```

### DCLGEN Analysis

DCLGEN (Declaration Generator) produces COBOL data structures from DB2 table definitions:

```cobol
      * DCLGEN TABLE(AIRMEN)
      *   LIBRARY(SYSLIB.DCLGEN(AIRMEN))
      *   LANGUAGE(COBOL)
      *   STRUCTURE(DCL-AIRMEN)
       01  DCL-AIRMEN.
           10  AIRMAN-ID              PIC X(09).
           10  AIRMAN-NAME            PIC X(40).
           10  CERT-TYPE              PIC X(10).
           10  CERT-STATUS            PIC X(08).
           10  CERT-EXPIRY-DATE       PIC X(10).
           10  LAST-UPDATE-TS         PIC X(26).
       01  DCL-AIRMEN-NULL-IND.
           10  AIRMAN-ID-NI           PIC S9(04) COMP.
           10  AIRMAN-NAME-NI         PIC S9(04) COMP.
           10  CERT-TYPE-NI           PIC S9(04) COMP.
           10  CERT-STATUS-NI         PIC S9(04) COMP.
           10  CERT-EXPIRY-DATE-NI    PIC S9(04) COMP.
           10  LAST-UPDATE-TS-NI      PIC S9(04) COMP.
```

**DCLGEN analysis approach**:
1. Collect all DCLGEN members to build a complete database schema inventory
2. Map COBOL PIC clauses to SQL column types
3. Identify nullable columns (presence of null indicator variables)
4. Cross-reference with actual SQL statements to find unused columns

### Cursor Patterns

Cursors handle multi-row result sets:

```cobol
           EXEC SQL
               DECLARE CERT-CURSOR CURSOR FOR
               SELECT CERT_TYPE, CERT_DATE, CERT_STATUS
               FROM CERTIFICATIONS
               WHERE AIRMAN_ID = :WS-AIRMAN-ID
               ORDER BY CERT_DATE DESC
           END-EXEC.

           EXEC SQL OPEN CERT-CURSOR END-EXEC.

           PERFORM UNTIL SQLCODE NOT = 0
               EXEC SQL
                   FETCH CERT-CURSOR
                   INTO :WS-CERT-TYPE,
                        :WS-CERT-DATE,
                        :WS-CERT-STATUS
               END-EXEC
               IF SQLCODE = 0
                   PERFORM 2500-PROCESS-CERT-ROW
               END-IF
           END-PERFORM.

           EXEC SQL CLOSE CERT-CURSOR END-EXEC.
```

**Cursor patterns to detect**:
- `DECLARE CURSOR` — the SQL query definition (may include complex joins and subqueries)
- `WITH HOLD` — cursor survives COMMIT (important for long-running batch)
- `FOR UPDATE OF` — cursor used for positioned UPDATE/DELETE
- `OPEN` / `FETCH` / `CLOSE` lifecycle
- Loop structure around `FETCH` (PERFORM UNTIL SQLCODE NOT = 0)

### Host Variable Mapping

Host variables (prefixed with `:` in SQL) bridge COBOL data to SQL parameters:

```cobol
      * COBOL variable           SQL usage
        :WS-AIRMAN-ID            WHERE AIRMAN_ID = :WS-AIRMAN-ID
        :WS-CERT-TYPE            INTO :WS-CERT-TYPE
        :HV-UPDATE-TS            SET LAST_UPDATE_TS = :HV-UPDATE-TS
```

Build a map of all host variables to understand the data flow between
COBOL working storage and DB2 tables.

### SQLCODE Handling

```cobol
       9100-SQL-ERROR.
           EVALUATE SQLCODE
               WHEN 0
                   CONTINUE
               WHEN +100
                   MOVE 'NO DATA FOUND' TO WS-ERROR-MSG
               WHEN -803
                   MOVE 'DUPLICATE KEY' TO WS-ERROR-MSG
               WHEN -811
                   MOVE 'MULTIPLE ROWS' TO WS-ERROR-MSG
               WHEN -904
                   MOVE 'RESOURCE UNAVAILABLE' TO WS-ERROR-MSG
               WHEN -911
                   MOVE 'DEADLOCK/TIMEOUT' TO WS-ERROR-MSG
               WHEN OTHER
                   STRING 'SQL ERROR: ' SQLCODE
                       DELIMITED BY SIZE INTO WS-ERROR-MSG
           END-EVALUATE.
```

| SQLCODE | Meaning | Modern Equivalent |
|---------|---------|-------------------|
| 0 | Success | Success / 200 OK |
| +100 | No data found / end of cursor | 404 Not Found / empty result set |
| -803 | Duplicate key on INSERT | 409 Conflict |
| -811 | SELECT returned more than one row (expected one) | Data integrity error |
| -904 | Resource unavailable (tablespace full, etc.) | 503 Service Unavailable |
| -911 | Deadlock or timeout | 408 Timeout / retry logic |
| -305 | Null value without indicator variable | NullPointerException equivalent |

## IMS/DL1 Patterns

### DL/I Call Structure

IMS (Information Management System) uses DL/I (Data Language/I) calls for
hierarchical database access:

```cobol
           CALL 'CBLTDLI' USING
               DLI-GU
               PCB-AIRMEN
               IO-AREA-AIRMEN
               SSA-AIRMAN-QUAL.
```

### DL/I Function Codes

| Code | Full Name | Purpose | SQL Equivalent |
|------|-----------|---------|----------------|
| `GU` | Get Unique | Direct access by key | `SELECT ... WHERE key = ?` |
| `GN` | Get Next | Sequential forward access | Cursor FETCH NEXT |
| `GNP` | Get Next within Parent | Sequential within parent segment | `SELECT ... WHERE parent_key = ? ORDER BY ...` |
| `GHU` | Get Hold Unique | Get Unique with update intent | `SELECT ... FOR UPDATE` |
| `GHN` | Get Hold Next | Get Next with update intent | Cursor FETCH NEXT FOR UPDATE |
| `GHNP` | Get Hold Next within Parent | GNP with update intent | Cursor FETCH NEXT FOR UPDATE within parent |
| `ISRT` | Insert | Add new segment occurrence | `INSERT INTO ...` |
| `DLET` | Delete | Remove segment (must hold first) | `DELETE FROM ... WHERE ...` |
| `REPL` | Replace | Update segment (must hold first) | `UPDATE ... SET ... WHERE ...` |

### PSB/PCB Analysis

PSB (Program Specification Block) defines what database segments a program can access.
PCB (Program Communication Block) is the runtime handle:

```
PSB Name: AINQPSB
  PCB 1: AIRMEN database
    Segment: AIRMAN    (sensitivity: READ)
    Segment: CERTIF    (sensitivity: READ)
    Segment: MEDICAL   (sensitivity: READ)
  PCB 2: AIRCRAFT database
    Segment: AIRCRAFT  (sensitivity: READ)
    Segment: MAINT     (sensitivity: READ, UPDATE)
```

**PSB analysis provides**:
- Which databases and segments each program can access
- Read vs. write permissions per segment (sensitivity)
- The effective "API contract" for IMS data access

### Segment Hierarchy

IMS databases are hierarchical (tree structures):

```
AIRMEN Database:
  AIRMAN (root segment)
    ├── CERTIF (dependent segment — certificates held)
    │     └── CERTDET (dependent — certificate details/history)
    ├── MEDICAL (dependent — medical certifications)
    ├── ADDRESS (dependent — mailing addresses)
    └── RATING (dependent — type ratings)
```

Each segment is like a table, but access always traverses the hierarchy from root.
Map the hierarchy to relational tables during modernization (root segment key
becomes the foreign key in all dependent segment tables).

### Segment Search Arguments (SSA)

SSAs filter which segments are retrieved:

```cobol
       01  SSA-AIRMAN-QUAL.
           05  FILLER           PIC X(08) VALUE 'AIRMAN  '.
           05  FILLER           PIC X(01) VALUE '('.
           05  FILLER           PIC X(08) VALUE 'AIRMANID'.
           05  FILLER           PIC X(02) VALUE ' ='.
           05  SSA-AIRMAN-ID    PIC X(09).
           05  FILLER           PIC X(01) VALUE ')'.
```

This is the IMS equivalent of a `WHERE` clause: retrieve the AIRMAN segment
where `AIRMANID = <value>`.

## File I/O Patterns

### FD Entries (File Descriptions)

```cobol
       FILE-CONTROL.
           SELECT AIRMAN-INPUT
               ASSIGN TO AIMINPUT
               ORGANIZATION IS SEQUENTIAL
               FILE STATUS IS WS-AIMIN-STATUS.

           SELECT AIRMAN-INDEXED
               ASSIGN TO AIMINDEX
               ORGANIZATION IS INDEXED
               ACCESS MODE IS DYNAMIC
               RECORD KEY IS AI-AIRMAN-ID
               ALTERNATE RECORD KEY IS AI-LAST-NAME
                   WITH DUPLICATES
               FILE STATUS IS WS-AIMIDX-STATUS.

           SELECT AIRMAN-RELATIVE
               ASSIGN TO AIMREL
               ORGANIZATION IS RELATIVE
               ACCESS MODE IS RANDOM
               RELATIVE KEY IS WS-REL-KEY
               FILE STATUS IS WS-AIMREL-STATUS.

       FILE SECTION.
       FD  AIRMAN-INPUT
           RECORDING MODE IS F
           RECORD CONTAINS 200 CHARACTERS
           BLOCK CONTAINS 0 RECORDS.
       01  AIMIN-RECORD.
           05  AIMIN-AIRMAN-ID       PIC X(09).
           05  AIMIN-NAME            PIC X(40).
           05  AIMIN-CERT-TYPE       PIC X(10).
           05  AIMIN-CERT-STATUS     PIC X(08).
           05  FILLER                PIC X(133).
```

### File Organization Types

| Organization | Access Patterns | Modern Equivalent |
|-------------|----------------|-------------------|
| SEQUENTIAL | READ, WRITE (append) | Flat file, CSV, streaming |
| INDEXED (VSAM KSDS) | READ/WRITE by key, sequential browse | Database table with primary/alternate keys |
| RELATIVE (VSAM RRDS) | READ/WRITE by record number | Array / indexed collection |
| LINE SEQUENTIAL | READ/WRITE line-by-line | Text file |

### READ/WRITE/REWRITE Patterns

```cobol
      * Sequential read loop
           OPEN INPUT AIRMAN-INPUT.
           READ AIRMAN-INPUT INTO WS-AIRMAN-RECORD
               AT END SET WS-END-OF-FILE TO TRUE
           END-READ.
           PERFORM UNTIL WS-END-OF-FILE
               PERFORM 3000-PROCESS-RECORD
               READ AIRMAN-INPUT INTO WS-AIRMAN-RECORD
                   AT END SET WS-END-OF-FILE TO TRUE
               END-READ
           END-PERFORM.
           CLOSE AIRMAN-INPUT.

      * Indexed file random access
           MOVE '123456789' TO AI-AIRMAN-ID.
           READ AIRMAN-INDEXED INTO WS-AIRMAN-RECORD
               INVALID KEY
                   MOVE 'RECORD NOT FOUND' TO WS-ERROR-MSG
               NOT INVALID KEY
                   PERFORM 3100-DISPLAY-RECORD
           END-READ.

      * Indexed file update
           READ AIRMAN-INDEXED INTO WS-AIRMAN-RECORD
               INVALID KEY PERFORM 9100-NOT-FOUND
           END-READ.
           MOVE 'RENEWED' TO WS-CERT-STATUS.
           REWRITE AI-RECORD FROM WS-AIRMAN-RECORD
               INVALID KEY PERFORM 9200-REWRITE-ERROR
           END-REWRITE.

      * Sequential write
           WRITE RPT-RECORD FROM WS-DETAIL-LINE
               AFTER ADVANCING 1 LINES.
```

### File Status Codes

```cobol
       EVALUATE WS-FILE-STATUS
           WHEN '00' CONTINUE
           WHEN '10' SET WS-END-OF-FILE TO TRUE
           WHEN '22' MOVE 'DUPLICATE KEY' TO WS-ERROR-MSG
           WHEN '23' MOVE 'RECORD NOT FOUND' TO WS-ERROR-MSG
           WHEN '30' MOVE 'PERMANENT I/O ERROR' TO WS-ERROR-MSG
           WHEN '35' MOVE 'FILE NOT FOUND' TO WS-ERROR-MSG
           WHEN '39' MOVE 'FILE ATTRIBUTE MISMATCH' TO WS-ERROR-MSG
           WHEN OTHER
               STRING 'FILE ERROR: ' WS-FILE-STATUS
                   DELIMITED BY SIZE INTO WS-ERROR-MSG
       END-EVALUATE.
```

## JCL Job Flow

### JOB/EXEC/DD Parsing

```jcl
//AIRMNRPT JOB (FAA,ACCT),'AIRMAN REPORT',
//         CLASS=A,MSGCLASS=X,NOTIFY=&SYSUID,
//         REGION=0M,TIME=1440
//*
//* STEP 1: EXTRACT AIRMAN DATA FROM DB2
//*
//EXTRACT  EXEC PGM=IKJEFT01,DYNAMNBR=20
//STEPLIB  DD DSN=DB2.SDSNLOAD,DISP=SHR
//SYSTSPRT DD SYSOUT=*
//SYSTSIN  DD *
  DSN SYSTEM(DB2P)
  RUN PROGRAM(AIMEXT01) PLAN(AIMPLAN) -
      PARM('EXTRACT')
  END
/*
//OUTFILE  DD DSN=FAA.AIRMAN.EXTRACT(&DATE),
//            DISP=(NEW,CATLG,DELETE),
//            SPACE=(CYL,(100,50),RLSE),
//            DCB=(RECFM=FB,LRECL=200,BLKSIZE=0)
//*
//* STEP 2: SORT EXTRACTED DATA
//*
//SORTDATA EXEC PGM=SORT
//SORTIN   DD DSN=FAA.AIRMAN.EXTRACT(&DATE),DISP=SHR
//SORTOUT  DD DSN=FAA.AIRMAN.SORTED(&DATE),
//            DISP=(NEW,CATLG,DELETE),
//            SPACE=(CYL,(100,50),RLSE),
//            DCB=(RECFM=FB,LRECL=200,BLKSIZE=0)
//SYSIN    DD *
  SORT FIELDS=(1,9,CH,A)
  INCLUDE COND=(40,8,CH,EQ,C'ACTIVE  ')
/*
//*
//* STEP 3: GENERATE REPORT
//*
//REPORT   EXEC PGM=IKJEFT01,COND=(0,NE,EXTRACT)
//STEPLIB  DD DSN=COBOL.LOADLIB,DISP=SHR
//INFILE   DD DSN=FAA.AIRMAN.SORTED(&DATE),DISP=SHR
//RPTFILE  DD SYSOUT=A
//SYSTSPRT DD SYSOUT=*
//SYSTSIN  DD *
  DSN SYSTEM(DB2P)
  RUN PROGRAM(AIMRPT01) PLAN(RPTPLAN)
  END
/*
```

### JCL Analysis Approach

1. **JOB card**: Extract job name, accounting, class, region (memory), time limit
2. **EXEC statements**: Map each step to its program (`PGM=`), identify COBOL programs vs. utilities
3. **DD statements**: Map all datasets — inputs, outputs, temp files, sysout
4. **COND parameters**: Trace step dependencies (`COND=(0,NE,EXTRACT)` means "skip if EXTRACT had RC != 0")
5. **PROC expansion**: If `EXEC PROC=procname`, find and expand the procedure to see actual steps
6. **Dataset flow**: Build a data flow diagram: Step 1 produces DSN X, Step 2 reads DSN X
7. **Symbolic parameters**: Track `&DATE`, `&SYSUID`, and other symbolic parameters and their substitution

### Common JCL Utilities

| Utility | Purpose | Modern Equivalent |
|---------|---------|-------------------|
| `SORT` (DFSORT/SyncSort) | Sort and filter records | SQL ORDER BY / WHERE, or streaming sort |
| `IEBGENER` | Copy dataset | `cp` / file copy |
| `IEBCOPY` | Copy PDS members | Library deployment |
| `IDCAMS` | VSAM file management | Database DDL / file management |
| `IKJEFT01` | TSO batch (runs DB2 programs) | Application runner |
| `IEFBR14` | Do nothing (create/delete datasets) | Infrastructure setup |
| `FTP` | File transfer | SFTP / S3 upload |
| `IRXJCL` | REXX execution | Script execution |

### PROC Expansion

```jcl
//* Procedure definition (in a procedure library)
//DB2RUN   PROC PROG=,PLAN=,PARM=
//RUN      EXEC PGM=IKJEFT01,DYNAMNBR=20
//STEPLIB  DD DSN=DB2.SDSNLOAD,DISP=SHR
//SYSTSPRT DD SYSOUT=*
//SYSTSIN  DD *
  DSN SYSTEM(DB2P)
  RUN PROGRAM(&PROG) PLAN(&PLAN) -
      PARM('&PARM')
  END
/*
//         PEND

//* Invocation in a job
//STEP1    EXEC PROC=DB2RUN,PROG=AIMEXT01,PLAN=AIMPLAN,PARM=EXTRACT
```

Expand all PROCs to understand the actual execution. Shared PROCs are the JCL
equivalent of shared libraries — a change to a PROC affects every job that uses it.

### Step Dependencies and Conditional Execution

```jcl
//* COND parameter: (code,operator,stepname)
//STEP3    EXEC PGM=AIMRPT01,COND=(0,NE,STEP1)
//*  Meaning: Skip STEP3 if STEP1 return code is NOT EQUAL to 0
//*  (i.e., only run STEP3 if STEP1 succeeded with RC=0)

//* IF/THEN/ELSE (modern JCL)
// IF (STEP1.RC = 0 & STEP2.RC <= 4) THEN
//STEP3    EXEC PGM=AIMRPT01
// ELSE
//ERRPROC  EXEC PGM=AIMERR01
// ENDIF
```

Map all step dependencies to understand the job's execution graph: which steps
run in sequence, which are conditional, and what error handling exists.

## Data Division Analysis

### 01-Level Record Layouts

```cobol
       01  WS-AIRMAN-RECORD.
           05  WS-AIRMAN-ID          PIC X(09).
           05  WS-NAME-GROUP.
               10  WS-LAST-NAME      PIC X(25).
               10  WS-FIRST-NAME     PIC X(15).
               10  WS-MIDDLE-INIT    PIC X(01).
           05  WS-ADDRESS-GROUP.
               10  WS-STREET         PIC X(30).
               10  WS-CITY           PIC X(20).
               10  WS-STATE          PIC X(02).
               10  WS-ZIP            PIC 9(05).
               10  WS-ZIP-PLUS4      PIC 9(04).
           05  WS-CERT-GROUP OCCURS 10 TIMES.
               10  WS-CERT-TYPE      PIC X(10).
               10  WS-CERT-DATE      PIC 9(08).
               10  WS-CERT-STATUS    PIC X(08).
           05  WS-FLAGS.
               10  WS-ACTIVE-FLAG    PIC X(01).
                   88  WS-IS-ACTIVE  VALUE 'Y'.
                   88  WS-IS-INACTIVE VALUE 'N'.
               10  WS-UPDATE-FLAG    PIC X(01).
                   88  WS-NEEDS-UPDATE VALUE 'Y'.
                   88  WS-NO-UPDATE  VALUE 'N'.
```

### REDEFINES Clauses

`REDEFINES` allows the same memory area to be interpreted as different data types:

```cobol
       01  WS-DATE-FIELD.
           05  WS-DATE-NUM           PIC 9(08).
       01  WS-DATE-PARTS REDEFINES WS-DATE-FIELD.
           05  WS-DATE-YYYY          PIC 9(04).
           05  WS-DATE-MM            PIC 9(02).
           05  WS-DATE-DD            PIC 9(02).

       01  WS-AMOUNT-DISPLAY         PIC X(12).
       01  WS-AMOUNT-NUMERIC REDEFINES WS-AMOUNT-DISPLAY
                                      PIC S9(09)V99.
```

**REDEFINES analysis**:
- Map all REDEFINES to understand dual-interpretation fields
- These become union types, type casts, or separate fields in modern code
- Flag REDEFINES involving numeric/alphanumeric mixing (common source of data bugs)

### OCCURS (Arrays)

```cobol
       05  WS-CERT-GROUP OCCURS 10 TIMES.
           10  WS-CERT-TYPE          PIC X(10).
           10  WS-CERT-DATE          PIC 9(08).

       05  WS-VARIABLE-TABLE.
           10  WS-ITEM-COUNT         PIC 9(03).
           10  WS-ITEM OCCURS 1 TO 100 TIMES
               DEPENDING ON WS-ITEM-COUNT.
               15  WS-ITEM-CODE      PIC X(05).
               15  WS-ITEM-DESC      PIC X(30).
```

**OCCURS patterns**:
- Fixed-size arrays: `OCCURS n TIMES` — always allocates n entries
- Variable-size arrays: `OCCURS n TO m TIMES DEPENDING ON counter` — variable length
- Nested OCCURS: multi-dimensional arrays (OCCURS within OCCURS)
- INDEXED BY: `OCCURS 10 TIMES INDEXED BY WS-IDX` — defines loop variable

### PIC Clause Type Mapping

| PIC Clause | COBOL Type | Length | Modern Type |
|------------|-----------|--------|-------------|
| `PIC X(n)` | Alphanumeric | n bytes | `string` (max length n) |
| `PIC A(n)` | Alphabetic | n bytes | `string` (letters only) |
| `PIC 9(n)` | Numeric display | n digits | `int` or `long` |
| `PIC S9(n)` | Signed numeric display | n digits | `int` or `long` (signed) |
| `PIC 9(n)V9(m)` | Decimal (implied) | n+m digits | `decimal(n+m, m)` |
| `PIC S9(n)V9(m)` | Signed decimal | n+m digits | `decimal(n+m, m)` (signed) |
| `PIC S9(n) COMP` | Binary (halfword/fullword) | 2 or 4 bytes | `int16` or `int32` |
| `PIC S9(n) COMP-3` | Packed decimal | ceil((n+1)/2) bytes | `decimal` (exact arithmetic) |
| `PIC S9(n) COMP-5` | Native binary | platform-dependent | `int` (native) |
| `PIC 9(n)V9(m) COMP-3` | Packed decimal with decimals | ceil((n+m+1)/2) bytes | `decimal(n+m, m)` |

**Critical for modernization**: COMP-3 (packed decimal) fields provide exact decimal
arithmetic without floating-point rounding errors. Financial calculations MUST use
`decimal`/`BigDecimal` types in the target language, never `float`/`double`.

## Common Legacy Patterns

### 88-Level Condition Names

```cobol
       05  WS-CERT-STATUS            PIC X(08).
           88  CERT-ACTIVE           VALUE 'ACTIVE'.
           88  CERT-EXPIRED          VALUE 'EXPIRED'.
           88  CERT-REVOKED          VALUE 'REVOKED'.
           88  CERT-SUSPENDED        VALUE 'SUSPEND'.
           88  CERT-VALID            VALUE 'ACTIVE' 'RENEWED'.

      * Usage:
           IF CERT-ACTIVE
               PERFORM PROCESS-ACTIVE-CERT
           END-IF.

           SET CERT-EXPIRED TO TRUE.
```

**88-level mapping**: These become enums, constants, or discriminated unions in
modern code. Note that an 88-level can have multiple values (`CERT-VALID` matches
both 'ACTIVE' and 'RENEWED').

### EVALUATE (Switch/Case)

```cobol
           EVALUATE WS-REQUEST-TYPE
                    ALSO WS-CERT-STATUS
               WHEN 'INQ' ALSO ANY
                   PERFORM 2100-INQUIRY
               WHEN 'UPD' ALSO 'ACTIVE'
                   PERFORM 2200-UPDATE
               WHEN 'UPD' ALSO 'EXPIRED'
                   PERFORM 2201-RENEWAL
               WHEN 'DEL' ALSO 'ACTIVE'
                   PERFORM 2300-DELETE
               WHEN OTHER
                   PERFORM 9500-INVALID-REQUEST
           END-EVALUATE.
```

**EVALUATE patterns**:
- Single-subject: `EVALUATE variable` — standard switch/case
- Multi-subject: `EVALUATE var1 ALSO var2` — matches combinations (like tuple matching)
- Condition-based: `EVALUATE TRUE` with `WHEN condition` — equivalent to if/else chain
- `WHEN ANY` matches all values (wildcard)

### STRING/UNSTRING Operations

```cobol
      * STRING: Concatenate fields with delimiters
           STRING WS-LAST-NAME DELIMITED BY SPACES
                  ', '          DELIMITED BY SIZE
                  WS-FIRST-NAME DELIMITED BY SPACES
                  ' '           DELIMITED BY SIZE
                  WS-MIDDLE-INIT DELIMITED BY SIZE
                  INTO WS-FULL-NAME
                  WITH POINTER WS-NAME-PTR
                  ON OVERFLOW
                      MOVE 'Y' TO WS-OVERFLOW-FLAG
           END-STRING.

      * UNSTRING: Parse delimited input
           UNSTRING WS-INPUT-LINE DELIMITED BY '|' OR ','
               INTO WS-FIELD1 COUNT IN WS-COUNT1
                    WS-FIELD2 COUNT IN WS-COUNT2
                    WS-FIELD3 COUNT IN WS-COUNT3
               WITH POINTER WS-PARSE-PTR
               TALLYING IN WS-FIELD-COUNT
               ON OVERFLOW
                   MOVE 'Y' TO WS-OVERFLOW-FLAG
           END-UNSTRING.
```

STRING/UNSTRING are COBOL's string manipulation primitives. They handle
concatenation and parsing with delimiter-aware logic. Map to modern string
operations (`join`, `split`, regex) but preserve the overflow/truncation behavior.

### COMPUTE Arithmetic

```cobol
      * Basic arithmetic
           COMPUTE WS-TOTAL-FEE =
               WS-BASE-FEE * WS-WEIGHT-FACTOR + WS-SURCHARGE.

      * Rounded arithmetic
           COMPUTE WS-TAX ROUNDED =
               WS-SUBTOTAL * WS-TAX-RATE.

      * ON SIZE ERROR (overflow detection)
           COMPUTE WS-RESULT = WS-VALUE-A ** 3
               ON SIZE ERROR
                   MOVE 'OVERFLOW' TO WS-ERROR-MSG
               NOT ON SIZE ERROR
                   CONTINUE
           END-COMPUTE.

      * Alternative arithmetic verbs
           ADD WS-SURCHARGE TO WS-TOTAL-FEE.
           SUBTRACT WS-DISCOUNT FROM WS-TOTAL-FEE.
           MULTIPLY WS-QUANTITY BY WS-UNIT-PRICE
               GIVING WS-LINE-TOTAL.
           DIVIDE WS-TOTAL BY WS-COUNT
               GIVING WS-AVERAGE REMAINDER WS-LEFTOVER.
```

**Arithmetic considerations**: COBOL arithmetic uses fixed-point decimal. The
`ROUNDED` clause and `ON SIZE ERROR` must be preserved in modern code using
`BigDecimal` or equivalent exact-arithmetic types.

## Modernization Considerations

### Type Conversion Table

| COBOL | Bytes | Java | TypeScript | Python | PostgreSQL |
|-------|-------|------|------------|--------|------------|
| PIC X(n) | n | String | string | str | VARCHAR(n) |
| PIC 9(n) | n | int/long | number | int | INTEGER/BIGINT |
| PIC S9(n) COMP | 2/4/8 | short/int/long | number | int | SMALLINT/INTEGER/BIGINT |
| PIC S9(n) COMP-3 | ceil((n+1)/2) | BigDecimal | Decimal.js | Decimal | NUMERIC(n,0) |
| PIC S9(n)V9(m) COMP-3 | ceil((n+m+1)/2) | BigDecimal | Decimal.js | Decimal | NUMERIC(n+m, m) |
| 88-level | 0 | enum | enum/union | Enum | CHECK constraint |
| OCCURS n | n * element | List/Array | Array | list | ARRAY or child table |
| REDEFINES | 0 (overlay) | Separate fields | Union type | Union | Separate columns |

### Encoding Conversions

- **EBCDIC to UTF-8**: All character data requires EBCDIC-to-UTF-8 conversion. Pay special attention to locale-specific characters and code page variants (CCSID).
- **Packed decimal to numeric**: COMP-3 fields must be unpacked. Use built-in conversion routines or libraries, not manual byte manipulation.
- **Fixed-length records to JSON**: Each FD record layout becomes a JSON schema. Preserve field names as keys, convert PIC types to JSON types.
- **Signed numeric display**: COBOL encodes the sign in the last byte of a display numeric field (overpunch). Modern systems use a sign character or negative number representation.

### Batch to API Transformation

| Batch Pattern | Modern Equivalent |
|---------------|-------------------|
| JCL job with multiple steps | Orchestrated workflow (Step Functions, Temporal) |
| Sequential file read loop | Streaming/chunked API endpoint or queue consumer |
| SORT utility step | Database ORDER BY or in-memory sort |
| Report generation (WRITE to SYSOUT) | PDF/CSV generation API or reporting service |
| File-based inter-step communication | Message queue or database intermediate storage |
| COND-based step dependencies | Workflow conditional branching |
| Scheduled job (JES2/JES3) | Cron job, CloudWatch Events, or scheduler service |
| Restart/checkpoint | Idempotent operations with checkpoint tables |

### CICS to Web Transformation

| CICS Pattern | Modern Equivalent |
|-------------|-------------------|
| 3270 BMS map | HTML form / React component |
| SEND MAP / RECEIVE MAP | HTTP response / HTTP request |
| COMMAREA | Request/response body (JSON) |
| Temporary Storage Queue | Redis/session store |
| LINK (synchronous call) | REST API call / service method |
| XCTL (transfer control) | Client-side routing / redirect |
| START (async transaction) | Message queue publish / async job |
| PF-key actions | Button click handlers |
| HANDLE CONDITION | try/catch / error middleware |
| Transaction ID | URL route / API endpoint |
| Terminal ID | Session ID / user context |
| Pseudo-conversational pattern | Stateless REST + client-side state |
