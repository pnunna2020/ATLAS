# ColdFusion Analysis Patterns

## Where Business Logic Hides
1. **CFC methods** — Components (*.cfc) are the primary code organization unit
   - Check `<cffunction>` tags for method definitions
   - Inheritance chains (`extends=`) can bury logic 3-4 levels deep
2. **cfquery tags** — SQL embedded in CFML templates
   - Named queries: `<cfquery name="getFlights" datasource="...">`
   - Dynamic SQL with `<cfif>` conditionals inside queries
3. **Application.cfc** — Framework-level logic (session mgmt, security)
4. **Custom tags** — Reusable components in `/customtags/` directory
5. **CFScript blocks** — Modern CF uses script syntax mixed with tag syntax

## Common Gotchas
- **Implicit struct creation**: CF creates variables in various scopes
  (variables, session, application, request) implicitly. Scope analysis
  is critical for understanding data flow.
- **Hot-deployed changes**: CF apps can have .cfm files modified directly
  on the server without a build process. Check file timestamps vs repo.
- **Fusebox/ColdBox/FW1 frameworks**: Each has its own routing, DI, and
  lifecycle conventions. Identify the framework before analyzing.
- **cfinclude chains**: CF templates can include other templates which
  include others. Follow the entire chain.
