# jQuery and Legacy JavaScript Frontend Analysis Patterns

## Purpose

Reference for the Analyze Application skill when performing discovery and analysis
of legacy frontend applications built with jQuery, legacy JavaScript frameworks
(Backbone, Knockout, Angular.js 1.x, Ember), or plain DOM manipulation. These
applications represent a significant portion of government and enterprise web
frontends that need modernization to React/USWDS or equivalent modern stacks.

## jQuery Detection and Version Identification

### Detection Indicators

Confirm jQuery usage by checking for:
- `jquery.js`, `jquery.min.js`, or CDN references in HTML files
- `<script>` tags referencing `code.jquery.com` or `ajax.googleapis.com/ajax/libs/jquery`
- `$` or `jQuery` global variable usage in JavaScript files
- `$.fn.` custom plugin definitions
- `$(document).ready()` or `$(function() {` entry points

### Version Detection

```javascript
// Check version in the jQuery source file header comment:
// jQuery JavaScript Library v3.6.0

// Or programmatically (if the app is running):
console.log(jQuery.fn.jquery);  // Returns version string like "3.6.0"
console.log($.fn.jquery);       // Same, using $ alias
```

| Version Range | Era | Key Characteristics |
|--------------|-----|---------------------|
| 1.0 - 1.6 | 2006-2011 | No `.on()`, uses `.bind()`, `.live()`, `.delegate()` |
| 1.7 - 1.12 | 2011-2016 | `.on()` introduced, `.live()` deprecated/removed |
| 2.0 - 2.2 | 2013-2016 | Dropped IE 6/7/8 support, smaller build |
| 3.0 - 3.7 | 2016-2023 | Dropped IE 9/10, Promises/A+ compliant, `$.ajax` returns thenables |

**Version inference rule**: If `.live()` is used, the code targets jQuery < 1.9.
If `.on()` is absent and `.bind()` is used directly, it targets jQuery < 1.7.

## jQuery Pattern Detection

### Document Ready Patterns

```javascript
// Pattern 1: Classic (all versions)
$(document).ready(function() {
    // Application initialization
});

// Pattern 2: Shorthand (all versions)
$(function() {
    // Application initialization
});

// Pattern 3: Named function (better for debugging)
function initApp() {
    // Application initialization
}
$(document).ready(initApp);

// Pattern 4: Deferred ready (jQuery 3+)
jQuery(function($) {
    // $ is guaranteed to be jQuery inside this scope
    // (avoids conflicts with other libraries using $)
});
```

**Modern equivalent**: Module initialization via `useEffect(() => {}, [])` in
React or top-level `<script type="module">` execution.

### Selector Patterns

```javascript
// Element selectors
$('div')                    // All <div> elements
$('#airman-form')           // Element with id="airman-form"
$('.cert-row')              // Elements with class="cert-row"
$('input[type="text"]')     // Attribute selector
$('table.results > tbody > tr')  // Descendant/child combinators

// Context-scoped selectors (performance optimization)
$('.cert-type', '#cert-table')    // .cert-type within #cert-table
$('#cert-table').find('.cert-type')  // Same, method syntax

// Pseudo-selectors (jQuery-specific, not CSS standard)
$(':checked')               // Checked checkboxes/radios
$(':visible')               // Visible elements (jQuery custom)
$(':hidden')                // Hidden elements (jQuery custom)
$(':first')                 // First matched element
$(':eq(3)')                 // Element at index 3
$(':contains("ATP")')       // Elements containing text "ATP"
$(':has(span)')             // Elements containing a <span>
$(':input')                 // All input, textarea, select, button elements
```

**Modern equivalent**: `document.querySelector()` / `document.querySelectorAll()`
for CSS selectors. jQuery-specific pseudo-selectors (`:visible`, `:hidden`,
`:contains`, `:has`, `:input`) require custom logic or CSS `:has()` (modern browsers).

### DOM Manipulation Patterns

```javascript
// Content manipulation
$('#result-name').html('<strong>' + airmanName + '</strong>');
$('#result-name').text(airmanName);  // Safe (no HTML parsing)
$('#cert-list').append('<li>' + certType + '</li>');
$('#cert-list').prepend('<li>Latest: ' + certType + '</li>');
$('#old-notice').remove();
$('#cert-list').empty();  // Remove all children

// Attribute manipulation
$('#airman-form').attr('action', '/api/airman/update');
$('#submit-btn').prop('disabled', true);
$('#search-input').val('');  // Get/set form input value
$('#airman-form').data('airman-id', '123456789');  // jQuery data store

// CSS manipulation
$('.error-field').css('border-color', 'red');
$('.error-field').css({
    'border-color': 'red',
    'background-color': '#fff0f0'
});
```

**Modern equivalents**:

| jQuery | Modern DOM API | React |
|--------|---------------|-------|
| `$.html(str)` | `el.innerHTML = str` | JSX rendering / `dangerouslySetInnerHTML` |
| `$.text(str)` | `el.textContent = str` | JSX `{variable}` |
| `$.append(str)` | `el.insertAdjacentHTML('beforeend', str)` | Array state + `.map()` in JSX |
| `$.prepend(str)` | `el.insertAdjacentHTML('afterbegin', str)` | Array state with unshift |
| `$.remove()` | `el.remove()` | Conditional rendering / filter state |
| `$.empty()` | `el.replaceChildren()` | Set state to empty array |
| `$.attr(k, v)` | `el.setAttribute(k, v)` | JSX attribute `key={value}` |
| `$.prop(k, v)` | `el[k] = v` | JSX attribute `disabled={true}` |
| `$.val()` | `el.value` | Controlled component state |
| `$.data(k, v)` | `el.dataset[k] = v` | Component props or state |
| `$.css(k, v)` | `el.style[k] = v` | CSS modules / `style={{ k: v }}` |

### Chaining Pattern

```javascript
// jQuery chaining (single element, multiple operations)
$('#airman-form')
    .find('.error-field')
    .removeClass('error-field')
    .end()
    .find('#submit-btn')
    .prop('disabled', false)
    .text('Submit')
    .end()
    .show();
```

**Modern equivalent**: Chaining does not have a direct modern equivalent. Break
into individual operations on explicit element references, or manage via
React component state.

## AJAX Call Mapping

### jQuery AJAX Patterns

```javascript
// $.ajax() — full configuration
$.ajax({
    url: '/api/airman/search',
    method: 'POST',           // or 'type' in older jQuery
    data: JSON.stringify({ airmanId: '123456789' }),
    contentType: 'application/json',
    dataType: 'json',
    headers: {
        'X-CSRF-Token': csrfToken
    },
    beforeSend: function(xhr) {
        $('#loading-spinner').show();
    },
    success: function(data) {
        renderResults(data.airmen);
    },
    error: function(xhr, status, error) {
        $('#error-msg').text('Search failed: ' + error).show();
    },
    complete: function() {
        $('#loading-spinner').hide();
    }
});

// $.get() — shorthand for GET requests
$.get('/api/airman/' + airmanId, function(data) {
    displayAirmanDetails(data);
});

// $.post() — shorthand for POST requests
$.post('/api/airman/update', {
    airmanId: airmanId,
    certStatus: 'RENEWED'
}, function(response) {
    showSuccessMessage('Certificate renewed');
});

// $.getJSON() — GET that expects JSON response
$.getJSON('/api/cert-types', function(certTypes) {
    populateCertTypeDropdown(certTypes);
});

// jQuery 3+ with Promises
$.ajax({ url: '/api/airman/search', data: searchParams })
    .then(function(data) {
        return $.ajax({ url: '/api/certs/' + data.airmanId });
    })
    .then(function(certs) {
        renderCertificates(certs);
    })
    .catch(function(error) {
        showError(error);
    });
```

### AJAX Inventory Extraction

For each AJAX call found in the codebase, record:

```
AJAX-{nnn}:
  File:          {file}:{line}
  Method:        GET | POST | PUT | DELETE
  URL:           /api/airman/search (or dynamic: '/api/airman/' + id)
  Request Data:  { airmanId: string }
  Response Type: JSON
  Success Handler: renderResults() in {file}:{line}
  Error Handler:   showError() in {file}:{line}  (or NONE if missing)
  Headers:       X-CSRF-Token
  Auth Required: Yes (session cookie)
```

### Modern Fetch Equivalents

| jQuery | Modern fetch API | Notes |
|--------|-----------------|-------|
| `$.ajax({ url, method: 'GET' })` | `fetch(url)` | fetch defaults to GET |
| `$.ajax({ url, method: 'POST', data: JSON.stringify(d), contentType: 'application/json' })` | `fetch(url, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(d) })` | Must set Content-Type explicitly |
| `$.ajax({ dataType: 'json' })` | `fetch(url).then(r => r.json())` | fetch requires manual JSON parsing |
| `success: fn` | `.then(fn)` | fetch uses Promises natively |
| `error: fn` | `.catch(fn)` | Note: fetch only rejects on network errors, not HTTP 4xx/5xx |
| `complete: fn` | `.finally(fn)` | Always runs |
| `$.ajaxSetup({ headers: { ... } })` | Custom fetch wrapper or interceptor | No global fetch configuration |
| `$.get(url, fn)` | `fetch(url).then(r => r.json()).then(fn)` | |
| `$.post(url, data, fn)` | `fetch(url, { method: 'POST', body: new URLSearchParams(data) }).then(r => r.json()).then(fn)` | Default content type differs |
| `$.getJSON(url, fn)` | `fetch(url).then(r => r.json()).then(fn)` | |

## Event Binding Inventory

### Event Binding Patterns

```javascript
// Modern jQuery event binding (jQuery 1.7+)
$('#search-btn').on('click', function(e) {
    e.preventDefault();
    performSearch();
});

// Delegated events (for dynamically added elements)
$('#cert-table').on('click', '.delete-btn', function() {
    var certId = $(this).data('cert-id');
    deleteCertificate(certId);
});

// Multiple events on same element
$('#search-input')
    .on('keyup', debounce(autoSearch, 300))
    .on('focus', showSearchSuggestions)
    .on('blur', hideSearchSuggestions);

// Legacy event binding (pre-1.7)
$('#search-btn').click(function() { ... });           // Shorthand
$('#search-btn').bind('click', function() { ... });   // Direct bind
$('.cert-row').live('click', function() { ... });      // Deprecated: live
$('#cert-table').delegate('.cert-row', 'click', fn);   // Deprecated: delegate

// Document-level handlers
$(document).on('keydown', function(e) {
    if (e.key === 'Escape') {
        closeModal();
    }
});

// Form events
$('#airman-form').on('submit', function(e) {
    e.preventDefault();
    if (validateForm()) {
        submitForm();
    }
});

$('#cert-type').on('change', function() {
    updateFormFieldsForCertType($(this).val());
});
```

### Event Handler Inventory Format

For each event handler in the codebase, record:

```
EVENT-{nnn}:
  File:       {file}:{line}
  Selector:   #search-btn | .cert-row | document
  Event:      click | submit | change | keyup | focus | blur
  Delegated:  Yes (parent: #cert-table) | No
  Handler:    performSearch() | inline anonymous function
  Action:     Performs AJAX search and renders results
  Prevents Default: Yes | No
```

### Modern Event Equivalents

| jQuery | React | Notes |
|--------|-------|-------|
| `$('#btn').on('click', fn)` | `<button onClick={fn}>` | React uses synthetic events |
| `$('#input').on('change', fn)` | `<input onChange={fn}>` | React onChange fires on every keystroke |
| `$('#form').on('submit', fn)` | `<form onSubmit={fn}>` | Still need `e.preventDefault()` |
| `$(document).on('keydown', fn)` | `useEffect(() => { document.addEventListener('keydown', fn); return () => document.removeEventListener('keydown', fn); }, [])` | Cleanup required |
| Delegated: `$('#table').on('click', '.row', fn)` | Map over data array and attach handler to each row component | React renders components per item |
| `$('#input').on('keyup', debounce(fn, 300))` | `useDebouncedCallback(fn, 300)` or custom hook | Use a debounce hook library |

## DOM Manipulation Patterns

### Show/Hide Patterns

```javascript
// Basic visibility
$('#results-panel').show();           // display: block (or previous display)
$('#results-panel').hide();           // display: none
$('#results-panel').toggle();         // Toggle visibility

// Animated visibility
$('#results-panel').fadeIn(400);      // Fade in over 400ms
$('#results-panel').fadeOut(400);     // Fade out over 400ms
$('#results-panel').slideDown(400);   // Slide down to reveal
$('#results-panel').slideUp(400);     // Slide up to hide
$('#results-panel').slideToggle(400); // Toggle with slide animation
```

**Modern equivalents**:

| jQuery | CSS/React |
|--------|-----------|
| `.show()` | CSS: `display: block` or remove `.hidden` class. React: conditional rendering `{isVisible && <Panel />}` |
| `.hide()` | CSS: `display: none` or add `.hidden` class. React: conditional rendering |
| `.toggle()` | React: toggle boolean state `setVisible(!visible)` |
| `.fadeIn()` | CSS transition: `opacity 0 -> 1` with `transition: opacity 400ms` |
| `.fadeOut()` | CSS transition: `opacity 1 -> 0` with `transition: opacity 400ms` |
| `.slideDown()` | CSS transition: `max-height: 0 -> auto` with `transition: max-height 400ms` |
| `.slideUp()` | CSS transition: `max-height: auto -> 0` |
| `.animate()` | CSS transitions or Web Animations API (`el.animate()`) |

### Class Manipulation

```javascript
$('#cert-row-1').addClass('selected');
$('#cert-row-1').removeClass('selected');
$('#cert-row-1').toggleClass('selected');
$('#cert-row-1').hasClass('selected');

// Multiple classes
$('#cert-row-1').addClass('selected highlighted urgent');
$('#cert-row-1').removeClass('selected highlighted');

// Conditional class
$('#cert-row-1').toggleClass('expired', certDate < today);
```

**Modern equivalents**:

| jQuery | Modern DOM API | React |
|--------|---------------|-------|
| `.addClass('x')` | `el.classList.add('x')` | `className={isSelected ? 'selected' : ''}` or `clsx()` |
| `.removeClass('x')` | `el.classList.remove('x')` | State-driven class computation |
| `.toggleClass('x')` | `el.classList.toggle('x')` | State toggle with `clsx()` |
| `.hasClass('x')` | `el.classList.contains('x')` | Check state variable |

## Plugin Detection

### jQuery UI Components

```javascript
// Datepicker
$('#cert-date').datepicker({
    dateFormat: 'mm/dd/yy',
    minDate: 0,
    maxDate: '+2y'
});

// Dialog (modal)
$('#confirm-dialog').dialog({
    modal: true,
    title: 'Confirm Action',
    buttons: {
        'Confirm': function() { performAction(); $(this).dialog('close'); },
        'Cancel':  function() { $(this).dialog('close'); }
    }
});

// Autocomplete
$('#airport-search').autocomplete({
    source: '/api/airports/search',
    minLength: 2,
    select: function(event, ui) {
        setAirportCode(ui.item.code);
    }
});

// Tabs
$('#cert-tabs').tabs({
    activate: function(event, ui) {
        loadTabContent(ui.newTab.data('cert-type'));
    }
});

// Sortable (drag-and-drop lists)
$('#priority-list').sortable({
    update: function(event, ui) {
        savePriorityOrder();
    }
});

// Draggable / Droppable
$('.cert-card').draggable({ revert: 'invalid' });
$('#drop-zone').droppable({
    accept: '.cert-card',
    drop: function(event, ui) { processDroppedCard(ui.draggable); }
});
```

### Plugin Modernization Map

| jQuery Plugin | Purpose | Modern Alternative |
|--------------|---------|-------------------|
| jQuery UI Datepicker | Date input | Native `<input type="date">` or React DatePicker |
| jQuery UI Dialog | Modal dialogs | USWDS Modal, `<dialog>` element, or Headless UI Dialog |
| jQuery UI Autocomplete | Type-ahead search | Headless UI Combobox, React Select, or Downshift |
| jQuery UI Tabs | Tabbed panels | USWDS Tabs, Headless UI Tabs, or native CSS tabs |
| jQuery UI Sortable | Drag-and-drop reorder | `@dnd-kit/core` or `react-beautiful-dnd` |
| jQuery UI Accordion | Collapsible sections | USWDS Accordion, `<details>/<summary>`, or Headless UI Disclosure |
| jQuery UI Slider | Range input | Native `<input type="range">` |
| jQuery UI Tooltip | Tooltips | CSS tooltips, Floating UI, or USWDS Tooltip |
| DataTables | Data grid with sorting/filtering/pagination | TanStack Table (React Table), AG Grid, or USWDS Table + custom logic |
| Select2 | Enhanced select dropdown | React Select, Downshift, or Headless UI Listbox |
| Bootstrap jQuery plugins | Modals, dropdowns, tooltips, carousels | React Bootstrap or USWDS equivalents |
| jQuery Validate | Form validation | React Hook Form, Formik, or native HTML5 validation |
| jQuery Mask | Input masking | `react-input-mask` or `imask.js` |
| Magnific Popup / Fancybox | Lightbox / image gallery | Headless UI Dialog with image viewer |
| jQuery File Upload | File upload with progress | Native `<input type="file">` with Fetch upload + progress events |
| jQuery Sparkline | Inline charts | D3.js, Chart.js, or Recharts |
| FullCalendar (jQuery) | Calendar UI | FullCalendar React, or custom with `date-fns` |
| jQuery Color Picker | Color selection | Native `<input type="color">` |
| jQuery Waypoints | Scroll-triggered events | Intersection Observer API |
| jQuery Lazy Load | Lazy image loading | Native `loading="lazy"` attribute |

## AJAX Form Submission

### Common Form Patterns

```javascript
// $.serialize() — URL-encoded form data
$('#airman-form').on('submit', function(e) {
    e.preventDefault();
    $.ajax({
        url: $(this).attr('action'),
        method: 'POST',
        data: $(this).serialize(),  // "airmanId=123&certType=ATP&status=ACTIVE"
        success: function(response) {
            showSuccess('Saved');
        }
    });
});

// FormData — for file uploads
$('#upload-form').on('submit', function(e) {
    e.preventDefault();
    var formData = new FormData(this);
    formData.append('uploadedBy', currentUser);
    $.ajax({
        url: '/api/documents/upload',
        method: 'POST',
        data: formData,
        processData: false,     // Don't process FormData
        contentType: false,     // Don't set content-type (browser sets multipart boundary)
        xhr: function() {
            var xhr = new XMLHttpRequest();
            xhr.upload.addEventListener('progress', function(e) {
                if (e.lengthComputable) {
                    var percent = Math.round((e.loaded / e.total) * 100);
                    $('#upload-progress').val(percent);
                }
            });
            return xhr;
        },
        success: function(response) {
            showSuccess('File uploaded: ' + response.filename);
        }
    });
});

// JSON form submission
$('#airman-form').on('submit', function(e) {
    e.preventDefault();
    var formData = {};
    $(this).serializeArray().forEach(function(field) {
        formData[field.name] = field.value;
    });
    $.ajax({
        url: '/api/airman/update',
        method: 'PUT',
        contentType: 'application/json',
        data: JSON.stringify(formData),
        success: handleSuccess,
        error: handleError
    });
});
```

### Modern Form Equivalents

| jQuery Pattern | React/Modern Equivalent |
|---------------|------------------------|
| `$('#form').serialize()` | `new FormData(formRef.current)` or controlled component state |
| `$('#form').serializeArray()` | `Object.fromEntries(new FormData(form))` |
| `new FormData(this)` | `new FormData(formRef.current)` (unchanged in modern JS) |
| `$.ajax({ processData: false })` | `fetch(url, { body: formData })` (fetch handles FormData natively) |
| `xhr.upload.addEventListener('progress', fn)` | `fetch` does not support upload progress natively; use `XMLHttpRequest` or a library like Axios |
| `e.preventDefault() + $.ajax` | React Hook Form `handleSubmit` or `onSubmit` with `fetch` |

## Dynamic Content Loading

### Common Dynamic Loading Patterns

```javascript
// $.load() — load HTML fragment into element
$('#cert-details').load('/api/airman/123/certs #cert-list', function() {
    initCertTable();
});

// Tab content via AJAX
$('#cert-tabs').on('click', '.tab-link', function(e) {
    e.preventDefault();
    var tabUrl = $(this).attr('href');
    var tabTarget = $(this).data('target');
    $(tabTarget).load(tabUrl, function() {
        $(this).trigger('contentLoaded');
    });
});

// Infinite scroll / load more
$(window).on('scroll', function() {
    if ($(window).scrollTop() + $(window).height() >= $(document).height() - 200) {
        if (!isLoading && hasMorePages) {
            loadNextPage();
        }
    }
});

function loadNextPage() {
    isLoading = true;
    currentPage++;
    $.get('/api/airmen?page=' + currentPage, function(data) {
        data.airmen.forEach(function(airman) {
            $('#airman-list').append(renderAirmanRow(airman));
        });
        hasMorePages = data.hasMore;
        isLoading = false;
    });
}

// Polling for updates
var pollInterval = setInterval(function() {
    $.getJSON('/api/status/' + jobId, function(status) {
        updateStatusDisplay(status);
        if (status.complete) {
            clearInterval(pollInterval);
            showResults(status.results);
        }
    });
}, 5000);
```

### Modern Equivalents for Dynamic Loading

| jQuery Pattern | Modern/React Equivalent |
|---------------|------------------------|
| `$('#el').load(url)` | `fetch(url).then(r => r.text())` + state update, or React component with `useEffect` |
| Tab content via AJAX | React Router with lazy-loaded routes, or `React.lazy()` + `Suspense` |
| Infinite scroll | Intersection Observer + paginated state, or `react-virtual` / `@tanstack/react-virtual` |
| `setInterval` polling | `useEffect` with interval, or `react-query` / `SWR` with `refetchInterval` |
| `$.load(url + ' #selector')` | Fetch full HTML, parse with `DOMParser`, extract fragment (or use component architecture) |

## Global State Patterns

### State in Window/Global Scope

```javascript
// Global variables on window
window.APP_CONFIG = {
    apiBaseUrl: '/api',
    environment: 'production',
    maxSearchResults: 50,
    csrfToken: document.querySelector('meta[name="csrf-token"]').content
};

window.currentUser = {
    id: '12345',
    name: 'John Smith',
    role: 'ISSO',
    permissions: ['view', 'edit', 'approve']
};

// Global state tracker
window.appState = {
    selectedAirman: null,
    searchResults: [],
    activeTab: 'certs',
    isDirty: false
};
```

### jQuery Data Store

```javascript
// $.data() — jQuery's per-element data storage
$('#airman-card').data('airman-id', '123456789');
$('#airman-card').data('loaded', true);
var airmanId = $('#airman-card').data('airman-id');

// data-* HTML attributes (read by jQuery)
// <div id="cert-row" data-cert-id="C001" data-cert-type="ATP">
var certId = $('#cert-row').data('cert-id');     // "C001"
var certType = $('#cert-row').data('cert-type');  // "ATP"
```

### Closures as State Containers

```javascript
// IIFE module pattern (pre-ES6 modules)
var AirmanModule = (function() {
    // Private state (closure)
    var airmanCache = {};
    var searchHistory = [];

    // Private function
    function cacheAirman(airman) {
        airmanCache[airman.id] = airman;
    }

    // Public interface
    return {
        search: function(criteria) {
            searchHistory.push(criteria);
            return $.getJSON('/api/airman/search', criteria)
                .then(function(results) {
                    results.forEach(cacheAirman);
                    return results;
                });
        },
        getFromCache: function(id) {
            return airmanCache[id] || null;
        },
        getSearchHistory: function() {
            return searchHistory.slice();  // Return copy
        }
    };
})();

// Revealing module pattern
var CertManager = (function() {
    var certs = [];
    var isDirty = false;

    function loadCerts(airmanId) { /* ... */ }
    function saveCerts() { /* ... */ }
    function addCert(cert) { certs.push(cert); isDirty = true; }
    function removeCert(certId) { /* ... */ isDirty = true; }

    return {
        load: loadCerts,
        save: saveCerts,
        add: addCert,
        remove: removeCert,
        isDirty: function() { return isDirty; }
    };
})();
```

### Modern State Management Equivalents

| Legacy Pattern | Modern Equivalent |
|---------------|-------------------|
| `window.appState` | React `useState` / `useReducer` at app level, or Zustand / Redux store |
| `$.data('key', value)` | Component props or `useContext` |
| `data-*` attributes | Component props (data should live in state, not the DOM) |
| IIFE module pattern | ES6 modules (`export` / `import`) |
| Closure state | React `useState` or `useRef` for mutable values |
| Global event bus (`$(document).trigger('event')`) | React Context, Zustand, or a shared event emitter |
| `localStorage`/`sessionStorage` for state | Same, but wrapped in custom hooks (`useLocalStorage`) |

## Template Patterns

### String Concatenation HTML Building

```javascript
// Inline HTML building (most common in legacy jQuery)
function renderAirmanRow(airman) {
    var html = '<tr class="airman-row" data-id="' + airman.id + '">';
    html += '<td>' + escapeHtml(airman.name) + '</td>';
    html += '<td>' + escapeHtml(airman.certType) + '</td>';
    html += '<td class="' + (airman.isExpired ? 'expired' : 'active') + '">';
    html += escapeHtml(airman.status) + '</td>';
    html += '<td><button class="view-btn" data-id="' + airman.id + '">View</button></td>';
    html += '</tr>';
    return html;
}

// Array join pattern (slightly cleaner)
function renderAirmanCard(airman) {
    return [
        '<div class="airman-card">',
        '  <h3>' + escapeHtml(airman.name) + '</h3>',
        '  <p>ID: ' + escapeHtml(airman.id) + '</p>',
        '  <p>Status: <span class="status-' + airman.status.toLowerCase() + '">',
        '    ' + escapeHtml(airman.status),
        '  </span></p>',
        '</div>'
    ].join('\n');
}
```

### Template Literals (ES6+ Inline Templates)

```javascript
// ES6 template literals (if the app uses ES6)
function renderAirmanRow(airman) {
    return `
        <tr class="airman-row" data-id="${airman.id}">
            <td>${escapeHtml(airman.name)}</td>
            <td>${escapeHtml(airman.certType)}</td>
            <td class="${airman.isExpired ? 'expired' : 'active'}">
                ${escapeHtml(airman.status)}
            </td>
        </tr>
    `;
}
```

### Handlebars/Mustache Templates

```html
<!-- Handlebars template -->
<script id="airman-row-template" type="text/x-handlebars-template">
    <tr class="airman-row" data-id="{{id}}">
        <td>{{name}}</td>
        <td>{{certType}}</td>
        <td class="{{#if isExpired}}expired{{else}}active{{/if}}">
            {{status}}
        </td>
        {{#each certs}}
        <td>{{this.type}} - {{this.date}}</td>
        {{/each}}
    </tr>
</script>

<script>
var template = Handlebars.compile($('#airman-row-template').html());
var html = template(airmanData);
$('#airman-table tbody').append(html);
</script>
```

### Underscore/Lodash Templates

```javascript
// _.template() — Lodash/Underscore micro-templating
var rowTemplate = _.template(
    '<tr><td><%= name %></td><td><%= certType %></td>' +
    '<% if (isExpired) { %><td class="expired"><% } else { %><td><% } %>' +
    '<%= status %></td></tr>'
);

var html = rowTemplate({ name: 'Smith', certType: 'ATP', status: 'EXPIRED', isExpired: true });
```

### Modern Template Equivalents

| Legacy Pattern | React/Modern Equivalent |
|---------------|------------------------|
| String concatenation HTML | JSX components |
| Array `.join()` HTML | JSX with `.map()` |
| ES6 template literals | JSX (preferred) or tagged template literals (lit-html) |
| Handlebars `{{variable}}` | JSX `{variable}` |
| Handlebars `{{#if}}` | JSX `{condition && <Element />}` or ternary |
| Handlebars `{{#each}}` | JSX `{array.map(item => <Component key={item.id} />)}` |
| `_.template()` | JSX components (template logic moves to component functions) |
| `<script type="text/x-handlebars">` in HTML | Separate `.jsx`/`.tsx` component files |

## Legacy Framework Detection

### Backbone.js

**Detection indicators**:
- `backbone.js` or `backbone-min.js` in script tags
- `Backbone.Model.extend()`, `Backbone.View.extend()`, `Backbone.Collection.extend()`
- `Backbone.Router` with `routes` hash
- `this.model.get()`, `this.model.set()`, `this.collection.fetch()`
- `Backbone.sync` override for custom API communication

```javascript
// Backbone Model
var Airman = Backbone.Model.extend({
    urlRoot: '/api/airmen',
    defaults: {
        name: '',
        certType: '',
        status: 'ACTIVE'
    },
    validate: function(attrs) {
        if (!attrs.name) return 'Name is required';
        if (!attrs.certType) return 'Certificate type is required';
    }
});

// Backbone Collection
var AirmanList = Backbone.Collection.extend({
    model: Airman,
    url: '/api/airmen',
    comparator: 'name'
});

// Backbone View
var AirmanView = Backbone.View.extend({
    tagName: 'tr',
    template: _.template($('#airman-template').html()),
    events: {
        'click .edit-btn': 'editAirman',
        'click .delete-btn': 'deleteAirman'
    },
    render: function() {
        this.$el.html(this.template(this.model.toJSON()));
        return this;
    },
    editAirman: function() { /* ... */ },
    deleteAirman: function() { /* ... */ }
});

// Backbone Router
var AppRouter = Backbone.Router.extend({
    routes: {
        '': 'home',
        'airman/:id': 'showAirman',
        'search': 'searchAirmen'
    },
    home: function() { /* ... */ },
    showAirman: function(id) { /* ... */ }
});
```

**Backbone migration path**: Models become React state/hooks, Views become React
components, Collections become arrays in state, Router becomes React Router.
The `events` hash maps directly to JSX event handlers.

### Knockout.js

**Detection indicators**:
- `knockout.js` or `ko.js` in script tags
- `ko.observable()`, `ko.computed()`, `ko.observableArray()`
- `data-bind` attributes in HTML
- `ko.applyBindings()`

```javascript
// Knockout ViewModel
function AirmanViewModel() {
    var self = this;
    self.airmanId = ko.observable('');
    self.name = ko.observable('');
    self.certType = ko.observable('');
    self.status = ko.observable('ACTIVE');
    self.certs = ko.observableArray([]);

    self.fullName = ko.computed(function() {
        return self.firstName() + ' ' + self.lastName();
    });

    self.isExpired = ko.computed(function() {
        return self.status() === 'EXPIRED';
    });

    self.search = function() {
        $.getJSON('/api/airmen/search', { q: self.searchTerm() }, function(data) {
            self.results(data.airmen);
        });
    };
}

ko.applyBindings(new AirmanViewModel());
```

```html
<!-- Knockout HTML bindings -->
<input data-bind="value: airmanId, valueUpdate: 'afterkeydown'" />
<span data-bind="text: fullName"></span>
<div data-bind="visible: isExpired, css: { 'alert-danger': isExpired }">
    Certificate expired
</div>
<ul data-bind="foreach: certs">
    <li data-bind="text: type + ' - ' + date"></li>
</ul>
<button data-bind="click: search, enable: searchTerm().length > 0">Search</button>
```

**Knockout migration path**: Observables become `useState`, computed observables
become `useMemo`, `data-bind` attributes become JSX props, `ko.applyBindings`
becomes `ReactDOM.render`. The reactive model maps closely to React hooks.

### Angular.js 1.x

**Detection indicators**:
- `angular.js` or `angular.min.js` in script tags
- `ng-app`, `ng-controller`, `ng-model`, `ng-repeat`, `ng-click` directives in HTML
- `angular.module()`, `.controller()`, `.service()`, `.factory()`, `.directive()`
- `$scope`, `$http`, `$rootScope` in JavaScript
- `.config()` with `$routeProvider` or `$stateProvider` (ui-router)

```javascript
// Angular.js 1.x Module
angular.module('airmanApp', ['ngRoute', 'ngResource'])
    .controller('AirmanSearchCtrl', function($scope, $http, AirmanService) {
        $scope.searchTerm = '';
        $scope.results = [];

        $scope.search = function() {
            AirmanService.search($scope.searchTerm).then(function(data) {
                $scope.results = data;
            });
        };

        $scope.selectAirman = function(airman) {
            $scope.selectedAirman = airman;
        };
    })
    .service('AirmanService', function($http) {
        this.search = function(term) {
            return $http.get('/api/airmen/search', { params: { q: term } })
                .then(function(response) { return response.data; });
        };
    })
    .directive('certBadge', function() {
        return {
            restrict: 'E',
            scope: { cert: '=' },
            template: '<span class="badge badge-{{cert.status}}">{{cert.type}}</span>'
        };
    });
```

```html
<!-- Angular.js 1.x template -->
<div ng-app="airmanApp" ng-controller="AirmanSearchCtrl">
    <input ng-model="searchTerm" ng-change="search()" />
    <table>
        <tr ng-repeat="airman in results | filter:filterCriteria | orderBy:'name'">
            <td>{{airman.name}}</td>
            <td>{{airman.certType}}</td>
            <td ng-class="{'expired': airman.isExpired}">{{airman.status}}</td>
            <td><button ng-click="selectAirman(airman)">Select</button></td>
        </tr>
    </table>
    <cert-badge cert="selectedAirman.cert"></cert-badge>
</div>
```

**Angular.js 1.x migration path**: Controllers become React components, `$scope`
becomes component state, Services become custom hooks or utility modules,
Directives become React components, `ng-repeat` becomes `.map()` in JSX,
`$http` becomes `fetch` or a data fetching hook.

### Ember.js

**Detection indicators**:
- `ember.js` or references to `emberjs.com` CDN
- `Ember.Application.create()`, `Ember.Object.extend()`
- `Ember.Route`, `Ember.Controller`, `Ember.Component`
- Handlebars templates (`.hbs` files)
- `ember-cli` build artifacts
- `this.get()`, `this.set()`, computed properties with `.property()`

```javascript
// Ember Route
App.AirmanRoute = Ember.Route.extend({
    model: function(params) {
        return this.store.find('airman', params.airman_id);
    }
});

// Ember Controller
App.AirmanController = Ember.Controller.extend({
    isExpired: Ember.computed('model.status', function() {
        return this.get('model.status') === 'EXPIRED';
    }),
    actions: {
        renewCert: function() {
            var airman = this.get('model');
            airman.set('status', 'RENEWED');
            airman.save();
        }
    }
});
```

**Ember migration path**: Routes become React Router routes, Controllers become
React components with hooks, Ember Data models become API hooks (React Query/SWR),
Handlebars templates become JSX, computed properties become `useMemo`.

## Comprehensive Modernization Mapping Table

### Pattern-to-Modern Equivalents

| Category | Legacy Pattern | Modern Equivalent (React/USWDS) |
|----------|---------------|--------------------------------|
| **Entry Point** | `$(document).ready()` | `createRoot().render()` + `useEffect` |
| **DOM Query** | `$('#id')`, `$('.class')` | `useRef()` or state-driven rendering |
| **DOM Manipulation** | `$.html()`, `$.append()` | JSX rendering from state |
| **Event Binding** | `$('#el').on('click', fn)` | `onClick={fn}` in JSX |
| **Delegated Events** | `$('#parent').on('click', '.child', fn)` | Per-component handlers via `.map()` |
| **AJAX GET** | `$.get(url, fn)` | `fetch(url)` + `useEffect` or React Query |
| **AJAX POST** | `$.post(url, data, fn)` | `fetch(url, { method: 'POST', body })` |
| **Form Submission** | `$('#form').serialize()` + `$.ajax()` | React Hook Form or controlled components + `fetch` |
| **File Upload** | `FormData` + `$.ajax({ processData: false })` | `FormData` + `fetch` (same API, no jQuery needed) |
| **Show/Hide** | `$('#el').show()` / `.hide()` | Conditional rendering `{show && <El />}` |
| **Animation** | `$.fadeIn()`, `$.slideDown()`, `$.animate()` | CSS transitions, Framer Motion, or Web Animations API |
| **Class Toggle** | `$.addClass()` / `$.removeClass()` | `className` computed from state, `clsx()` utility |
| **Datepicker** | jQuery UI Datepicker | Native `<input type="date">` or USWDS Date Picker |
| **Modal** | jQuery UI Dialog | USWDS Modal or `<dialog>` element |
| **Autocomplete** | jQuery UI Autocomplete | USWDS Combo Box or Headless UI Combobox |
| **Tabs** | jQuery UI Tabs | USWDS Tabs component |
| **Data Table** | DataTables plugin | TanStack Table + USWDS table styling |
| **Select Enhancement** | Select2 | React Select or USWDS Combo Box |
| **Form Validation** | jQuery Validate | React Hook Form validators or Zod schema |
| **Template Rendering** | Handlebars / `_.template()` | JSX components |
| **Client Routing** | Backbone Router / Angular `$routeProvider` | React Router |
| **State Management** | `window.*` globals / closures | React state / Context / Zustand |
| **Component Model** | Backbone View / Knockout ViewModel / Angular Directive | React functional component with hooks |
| **Data Binding** | `ko.observable()` / `ng-model` / Backbone `model.on('change')` | `useState` + controlled components |
| **Computed Values** | `ko.computed()` / Ember `.property()` | `useMemo()` |
| **HTTP Client** | `$.ajax()` / `$http` / `Backbone.sync` | `fetch` API, Axios, or React Query |
| **Module System** | IIFE / AMD (`require.js`) / Revealing Module | ES6 modules (`import`/`export`) |

### Section 508 / Accessibility Considerations for Migration

When migrating from jQuery/legacy frameworks to React/USWDS, ensure:

| Legacy Behavior | Accessibility Requirement | USWDS Implementation |
|----------------|--------------------------|---------------------|
| jQuery UI Dialog | Focus trap, Escape to close, `aria-modal` | USWDS Modal handles this natively |
| `$.show()` / `$.hide()` | `aria-hidden`, manage focus on reveal | Conditional rendering + `aria-hidden` |
| Custom dropdowns (Select2) | Keyboard navigation, `aria-expanded`, `aria-activedescendant` | USWDS Combo Box |
| Inline error messages | `aria-describedby`, `aria-invalid`, live regions | USWDS Form validation pattern |
| Dynamic content updates | `aria-live` regions for screen reader announcements | USWDS Alert component with `role="alert"` |
| Tab panels | `role="tablist"`, `role="tab"`, `role="tabpanel"`, `aria-selected` | USWDS Tabs component |
| Autocomplete suggestions | `role="listbox"`, `role="option"`, keyboard navigation | USWDS Combo Box |
| Loading spinners | `aria-busy="true"`, live region announcement | Status message with `aria-live="polite"` |

## Analysis Checklist

1. **jQuery version identification** — version determines available APIs and migration complexity
2. **Plugin inventory** — list all jQuery plugins and their modern replacements
3. **AJAX call catalog** — every server call with URL, method, data, and handlers
4. **Event handler inventory** — every event binding with selector, event type, and action
5. **DOM manipulation patterns** — categorize: read, write, create, delete, show/hide
6. **State management audit** — map all global state, closures, `$.data()`, and `data-*` usage
7. **Template pattern detection** — string concatenation, Handlebars, Underscore, or ES6 templates
8. **Legacy framework identification** — Backbone, Knockout, Angular.js 1.x, or Ember
9. **Accessibility gaps** — missing ARIA attributes, keyboard navigation, focus management
10. **Inline CSS/JS detection** — `<style>` tags, `onclick` attributes, `$.css()` calls (should become CSS classes)
11. **Third-party dependency audit** — CDN references, bundled vendor libraries, version currency
12. **Build system identification** — Grunt, Gulp, Webpack, none (manual concatenation), or script tags
