# .NET / ASP.NET WebForms Analysis Patterns

## Technology Detection

Confirm .NET WebForms by checking for:
- `.aspx` files (WebForms pages with markup)
- `.aspx.cs` or `.aspx.vb` files (code-behind classes)
- `.ascx` files (user controls) and `.ascx.cs` / `.ascx.vb` (user control code-behind)
- `.master` files (master pages defining shared layout)
- `.asmx` files (legacy XML web services)
- `.svc` files (WCF service endpoints)
- `.csproj` or `.vbproj` files (project definitions)
- `web.config` (application configuration, routing, auth, connection strings)
- `Global.asax` and `Global.asax.cs` (application lifecycle events)
- `App_Code/` directory (dynamically compiled shared classes)
- `App_Data/` directory (local database files, XML data)
- `packages.config` (legacy NuGet package manifest)
- `.sln` file (Visual Studio solution grouping multiple projects)

### File Extension Quick Reference

| Extension | Purpose | Analysis Priority |
|-----------|---------|-------------------|
| `.aspx` | WebForms page (markup + server controls) | High — UI entry points |
| `.aspx.cs` / `.aspx.vb` | Page code-behind (event handlers) | Critical — primary business logic |
| `.ascx` | User control (reusable UI fragment) | Medium — shared UI components |
| `.master` | Master page (layout template) | Medium — layout hierarchy |
| `.asmx` | ASMX web service | High — API surface |
| `.svc` | WCF service endpoint | High — API surface |
| `.ashx` | HTTP handler (raw request processing) | High — custom endpoints |
| `.asax` | Application/session events | High — lifecycle logic |
| `.config` | XML configuration | Critical — secrets, connection strings |
| `.csproj` / `.vbproj` | Project file (references, build settings) | High — dependency map |
| `.sln` | Solution file (project grouping) | Medium — architecture overview |
| `.resx` | Resource file (localization strings) | Low — i18n catalog |
| `.skin` | Theme skin file (control styling) | Low — presentation |
| `.sitemap` | Navigation structure | Low — site map |
| `.dbml` | LINQ to SQL data model | Medium — data access schema |
| `.edmx` | Entity Framework model (EF < 6 Database First) | High — data access schema |

### .NET Framework Version Detection

Check `.csproj` for `<TargetFrameworkVersion>`:
```xml
<!-- .NET Framework 4.x (most WebForms apps) -->
<TargetFrameworkVersion>v4.8</TargetFrameworkVersion>
<TargetFrameworkVersion>v4.7.2</TargetFrameworkVersion>
<TargetFrameworkVersion>v4.5.2</TargetFrameworkVersion>
<TargetFrameworkVersion>v4.0</TargetFrameworkVersion>

<!-- Older .NET Framework -->
<TargetFrameworkVersion>v3.5</TargetFrameworkVersion>
<TargetFrameworkVersion>v2.0</TargetFrameworkVersion>
```

Check `web.config` for `<httpRuntime>` target:
```xml
<httpRuntime targetFramework="4.8" />
```

Check `web.config` compilation section for language version:
```xml
<system.codedom>
  <compilers>
    <compiler language="c#" extension=".cs"
      compilerOptions="/langversion:6" />
  </compilers>
</system.codedom>
```

## Where Business Logic Hides

### 1. Code-Behind Files (.aspx.cs / .aspx.vb)
The primary location for business logic in WebForms applications. Every `.aspx` page
has a companion code-behind class inheriting from `System.Web.UI.Page`.

```csharp
// FlightSearch.aspx.cs
public partial class FlightSearch : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            // First-load initialization — often contains data loading logic
            BindAirportDropdowns();
            LoadUserPreferences();
        }
    }

    protected void btnSearch_Click(object sender, EventArgs e)
    {
        // Button click handler — business logic entry point
        var criteria = new SearchCriteria
        {
            Origin = ddlOrigin.SelectedValue,
            Destination = ddlDestination.SelectedValue,
            Date = Calendar1.SelectedDate
        };
        var results = FlightService.Search(criteria);
        gvResults.DataSource = results;
        gvResults.DataBind();
    }

    protected void gvResults_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        // GridView event — row-level business logic
        if (e.CommandName == "Select")
        {
            int flightId = Convert.ToInt32(e.CommandArgument);
            Session["SelectedFlight"] = flightId;
            Response.Redirect("BookFlight.aspx");
        }
    }
}
```

**Key analysis points:**
- Every `protected void` method with `(object sender, EventArgs e)` signature is
  an event handler and potential business rule entry point
- `Page_Load` with `if (!IsPostBack)` blocks contain initialization logic
- `Page_Init`, `Page_PreRender`, `Page_Unload` contain lifecycle-dependent logic
- Look for `Page_Error` for page-level error handling

### 2. App_Code Folder
Dynamically compiled classes shared across the application. Common in older
WebForms apps that predate class library separation:
```
App_Code/
├── BusinessRules/
│   ├── FlightValidator.cs
│   └── PricingEngine.cs
├── DataAccess/
│   ├── FlightDAL.cs
│   └── UserDAL.cs
├── Utilities/
│   ├── EmailHelper.cs
│   └── DateConverter.cs
└── BasePage.cs              ← custom base page with shared logic
```

**Gotcha**: `App_Code` classes are compiled at runtime by ASP.NET. They cannot be
referenced by precompiled class library projects — this creates an invisible
dependency boundary.

### 3. Referenced Class Libraries
Business logic separated into `.dll` assemblies referenced by the web project:
```xml
<!-- In .csproj -->
<ProjectReference Include="..\MyApp.Business\MyApp.Business.csproj" />
<ProjectReference Include="..\MyApp.Data\MyApp.Data.csproj" />
<Reference Include="MyApp.Legacy, Version=1.0.0.0, Culture=neutral,
    PublicKeyToken=null">
  <HintPath>..\lib\MyApp.Legacy.dll</HintPath>
</Reference>
```

Check for both `ProjectReference` (source-level) and `Reference` (binary-level)
entries. Binary references to checked-in DLLs are common in older apps and indicate
a component whose source may be unavailable.

### 4. Web Services (ASMX and WCF)
Legacy web services often contain significant business logic:

```csharp
// FlightService.asmx.cs
[WebService(Namespace = "http://faa.gov/flights")]
[WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
public class FlightService : System.Web.Services.WebService
{
    [WebMethod]
    public FlightInfo[] SearchFlights(string origin, string dest, DateTime date)
    {
        // Business logic embedded in web service method
    }
}
```

```csharp
// FlightService.svc.cs (WCF)
[ServiceContract]
public interface IFlightService
{
    [OperationContract]
    FlightInfo[] SearchFlights(string origin, string dest, DateTime date);
}
```

### 5. HTTP Handlers and Modules
Custom request processing often hides cross-cutting business logic:

```csharp
// CustomAuthHandler.ashx.cs
public class CustomAuthHandler : IHttpHandler
{
    public void ProcessRequest(HttpContext context)
    {
        // Authentication/authorization logic
    }
}

// AuditModule.cs (registered in web.config)
public class AuditModule : IHttpModule
{
    public void Init(HttpApplication app)
    {
        app.BeginRequest += OnBeginRequest;
        app.EndRequest += OnEndRequest;
    }
}
```

Check `web.config` for registered handlers and modules:
```xml
<system.webServer>
  <handlers>
    <add name="ReportHandler" path="*.rpt" verb="GET"
         type="MyApp.Handlers.ReportHandler" />
  </handlers>
  <modules>
    <add name="AuditModule" type="MyApp.Modules.AuditModule" />
    <add name="SecurityModule" type="MyApp.Modules.SecurityModule" />
  </modules>
</system.webServer>
```

### 6. Global.asax Events
Application-level lifecycle events contain cross-cutting logic:

```csharp
// Global.asax.cs
public class Global : System.Web.HttpApplication
{
    protected void Application_Start(object sender, EventArgs e)
    {
        // App initialization: route registration, container setup, cache warming
    }

    protected void Application_Error(object sender, EventArgs e)
    {
        // Global error handling, logging, redirect to error page
    }

    protected void Session_Start(object sender, EventArgs e)
    {
        // Per-session initialization: user preferences, shopping cart setup
    }

    protected void Application_BeginRequest(object sender, EventArgs e)
    {
        // Per-request: URL rewriting, request logging, CORS headers
    }

    protected void Application_AuthenticateRequest(object sender, EventArgs e)
    {
        // Custom authentication/authorization logic
    }
}
```

### 7. User Controls (.ascx)
Reusable UI components with their own code-behind often encapsulate domain logic:

```csharp
// FlightStatusPanel.ascx.cs
public partial class FlightStatusPanel : System.Web.UI.UserControl
{
    public int FlightId { get; set; }

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            var status = FlightService.GetStatus(FlightId);
            // Business rules for status display, color coding, alerts
        }
    }
}
```

## Architecture Pattern Detection

### WebForms Page Lifecycle
Understanding the page lifecycle is critical for locating business logic. Events
fire in this order on every request:

```
PreInit → Init → InitComplete → PreLoad → Load → [Control Events] →
LoadComplete → PreRender → PreRenderComplete → SaveStateComplete →
Render → Unload
```

For postback requests, control events (button clicks, selection changes) fire
between `Load` and `LoadComplete`. Business logic can hide in any of these stages.

**Analysis checklist:**
- `Page_PreInit`: Dynamic master page or theme assignment, dynamic control creation
- `Page_Init`: Control initialization, reading control values before ViewState loads
- `Page_Load`: Primary data loading and initialization — most common logic location
- Control event handlers: The core business rule execution points
- `Page_PreRender`: Final adjustments before rendering — conditional UI logic

### MVP / MVC Hybrid Patterns
Some WebForms apps adopt Model-View-Presenter to improve testability:

```csharp
// IFlightSearchView.cs
public interface IFlightSearchView
{
    string Origin { get; }
    string Destination { get; }
    void ShowResults(IEnumerable<Flight> flights);
    void ShowError(string message);
}

// FlightSearch.aspx.cs
public partial class FlightSearch : Page, IFlightSearchView
{
    private FlightSearchPresenter _presenter;

    protected void Page_Load(object sender, EventArgs e)
    {
        _presenter = new FlightSearchPresenter(this, new FlightService());
        if (!IsPostBack) _presenter.Initialize();
    }

    protected void btnSearch_Click(object sender, EventArgs e)
    {
        _presenter.Search();
    }
}
```

**Detection**: Look for interfaces named `I*View` or `I*Presenter`, and pages
that implement view interfaces. If found, the business logic is in Presenter
classes, not code-behind.

### N-Tier with BLL/DAL Layers
The most common pattern in enterprise WebForms apps:

```
WebApp (Presentation)
  └── references → MyApp.BLL (Business Logic Layer)
        └── references → MyApp.DAL (Data Access Layer)
              └── references → MyApp.Entities (shared models)
```

**Detection**: Check `.csproj` `ProjectReference` entries and look for projects
named `*.BLL`, `*.Business`, `*.Services`, `*.DAL`, `*.Data`, `*.DataAccess`,
`*.Entities`, `*.Models`, `*.Common`, `*.Shared`.

### Repository and Unit of Work Patterns
More modern WebForms apps may use Repository pattern:

```csharp
public interface IFlightRepository
{
    Flight GetById(int id);
    IEnumerable<Flight> Search(SearchCriteria criteria);
    void Add(Flight flight);
    void SaveChanges();
}

public class FlightRepository : IFlightRepository
{
    private readonly MyAppDbContext _context;
    // ...
}
```

**Detection**: Grep for `IRepository`, `Repository`, `IUnitOfWork`, `UnitOfWork`
class names.

## ViewState Analysis

ViewState is ASP.NET WebForms' mechanism for persisting page and control state
across postbacks. It is a critical migration concern.

### Detection and Measurement
```html
<!-- ViewState renders as a hidden field -->
<input type="hidden" name="__VIEWSTATE" id="__VIEWSTATE"
       value="/wEPDwUKMTU5MTA2ODYwOQ9kFg..." />
```

**Analysis approach:**
1. Check `web.config` for global ViewState settings:
```xml
<pages enableViewState="true" viewStateEncryptionMode="Always"
       enableViewStateMac="true" maxPageStateFieldLength="4096" />
```

2. Check individual pages for ViewState directives:
```aspx
<%@ Page EnableViewState="false" %>
```

3. Check controls for ViewState override:
```csharp
protected override bool EnableViewState => false;
```

4. Measure ViewState size: In browser dev tools, find `__VIEWSTATE` hidden field
   and measure its base64-encoded length. Divide by 1.37 for approximate byte size.

### ViewState Risk Assessment
| Size Range | Risk Level | Migration Impact |
|-----------|------------|------------------|
| < 10 KB | Low | Standard state management replacement |
| 10-50 KB | Medium | Needs explicit state design in target |
| 50-200 KB | High | Performance bottleneck, requires rearchitecting state |
| > 200 KB | Critical | Likely contains serialized datasets — major refactor needed |

### Where ViewState Bloats
- `GridView` with large datasets bound without paging
- `DataSet` or `DataTable` stored in ViewState (instead of re-queried)
- Nested `Repeater` controls with complex templates
- Third-party controls with built-in ViewState persistence
- Controls with `ViewStateMode="Enabled"` overriding page-level disable

## Postback Patterns

### Standard Postback
```html
<!-- Renders as: __doPostBack('btnSubmit','') -->
<asp:Button ID="btnSubmit" runat="server" OnClick="btnSubmit_Click" />
```

### __doPostBack Analysis
Grep JavaScript for `__doPostBack` calls — these are programmatic postbacks:
```javascript
// Manual postback trigger
__doPostBack('ctl00$ContentPlaceHolder1$ddlStatus', '');

// Postback with argument
__doPostBack('ctl00$ContentPlaceHolder1$gvFlights', 'Select$3');
```

### Cross-Page Postback
```aspx
<!-- Posts to a different page -->
<asp:Button ID="btnNext" runat="server" PostBackUrl="~/Step2.aspx" />
```

In the target page, access previous page data via `PreviousPage`:
```csharp
// Step2.aspx.cs
var step1 = (Step1)PreviousPage;
string name = step1.UserName;
```

**Analysis impact**: Cross-page postback creates hidden coupling between pages.
Map all `PostBackUrl` attributes to build a page dependency graph.

### Navigation Patterns
```csharp
// Server-side redirect (new request, URL changes)
Response.Redirect("Results.aspx?id=" + flightId);

// Server transfer (same request, URL stays)
Server.Transfer("Results.aspx");

// Cross-page postback (POST to different page)
// Via PostBackUrl attribute on buttons
```

`Server.Transfer` preserves the original URL and `HttpContext` — it creates
invisible page coupling. Grep for all `Server.Transfer` calls.

## Session State Analysis

### Session Mode Detection
Check `web.config`:
```xml
<!-- In-process (default, lost on app pool recycle) -->
<sessionState mode="InProc" timeout="20" />

<!-- State Server (out-of-process, requires serializable objects) -->
<sessionState mode="StateServer"
    stateConnectionString="tcpip=127.0.0.1:42424" />

<!-- SQL Server (persistent, requires serializable objects) -->
<sessionState mode="SQLServer"
    sqlConnectionString="data source=.;Integrated Security=true"
    allowCustomSqlDatabase="true" />

<!-- Custom provider -->
<sessionState mode="Custom" customProvider="MySessionProvider">
  <providers>
    <add name="MySessionProvider"
         type="MyApp.CustomSessionStateProvider" />
  </providers>
</sessionState>
```

### Session Variable Inventory
Grep for all session usage across the codebase:
```csharp
// Setting session variables
Session["UserId"] = currentUser.Id;
Session["CartItems"] = cartList;
Session["SearchCriteria"] = criteria;
HttpContext.Current.Session["GlobalFlag"] = true;

// Reading session variables
var userId = (int)Session["UserId"];
var cart = Session["CartItems"] as List<CartItem>;
```

**Analysis approach:**
1. Grep for `Session\[` and `HttpContext.Current.Session` across all `.cs` files
2. Build an inventory of session key names and their types
3. Identify which pages read vs. write each key — this maps cross-page data flow
4. Flag non-serializable objects stored in session (breaks StateServer/SQLServer modes)
5. Check for session used as a cross-request message bus between pages

## Server Controls Analysis

### Standard ASP.NET Controls
```aspx
<asp:GridView>          <!-- Data display grid -->
<asp:DetailsView>       <!-- Single-record view -->
<asp:FormView>          <!-- Templated single-record -->
<asp:Repeater>          <!-- Lightweight list rendering -->
<asp:DataList>          <!-- Repeating data display -->
<asp:ListView>          <!-- Flexible data display -->
<asp:TreeView>          <!-- Hierarchical navigation -->
<asp:Menu>              <!-- Navigation menu -->
<asp:Wizard>            <!-- Multi-step workflow -->
<asp:MultiView>         <!-- Panel switching -->
<asp:LoginView>         <!-- Auth-conditional rendering -->
<asp:CreateUserWizard>  <!-- User registration -->
```

### Third-Party Control Libraries
Detect by checking `web.config` `<tagPrefix>` registrations and NuGet packages:

**Telerik UI for ASP.NET AJAX**:
```xml
<add tagPrefix="telerik" namespace="Telerik.Web.UI" assembly="Telerik.Web.UI" />
```
```aspx
<telerik:RadGrid> <telerik:RadEditor> <telerik:RadScheduler>
<telerik:RadTreeView> <telerik:RadComboBox> <telerik:RadDatePicker>
```

**DevExpress ASP.NET**:
```xml
<add tagPrefix="dx" namespace="DevExpress.Web" assembly="DevExpress.Web.v23.2" />
```
```aspx
<dx:ASPxGridView> <dx:ASPxRoundPanel> <dx:ASPxDateEdit>
<dx:ASPxPopupControl> <dx:ASPxCallbackPanel>
```

**Infragistics WebForms**:
```xml
<add tagPrefix="ig" namespace="Infragistics.Web.UI" assembly="Infragistics..." />
```
```aspx
<ig:WebDataGrid> <ig:WebDialogWindow> <ig:WebDatePicker>
```

**ComponentArt**:
```aspx
<ComponentArt:Grid> <ComponentArt:TreeView> <ComponentArt:Splitter>
```

**Migration impact**: Third-party controls have NO equivalent in ASP.NET Core.
Every third-party control must be replaced with a modern alternative (React
component, Blazor component, or HTML/CSS/JS). Count third-party control instances
per page to estimate migration effort.

### Custom Server Controls
Check for controls in `App_Code/Controls/` or referenced control libraries:
```csharp
[ToolboxData("<{0}:FlightCard runat=server />")]
public class FlightCard : CompositeControl
{
    // Custom rendering and event logic
}
```

Registered via `web.config`:
```xml
<controls>
  <add tagPrefix="faa" namespace="MyApp.Controls" assembly="MyApp.Web" />
</controls>
```

## Data Access Patterns

### ADO.NET with DataSets and DataReaders
The most common data access pattern in legacy WebForms:

```csharp
// DataReader (forward-only, connected)
using (var conn = new SqlConnection(connString))
{
    conn.Open();
    var cmd = new SqlCommand("SELECT * FROM Flights WHERE FlightId = @id", conn);
    cmd.Parameters.AddWithValue("@id", flightId);
    var reader = cmd.ExecuteReader();
    while (reader.Read())
    {
        flight.Number = reader["FlightNumber"].ToString();
    }
}

// DataSet / DataTable (disconnected)
var adapter = new SqlDataAdapter("SELECT * FROM Flights", connString);
var ds = new DataSet();
adapter.Fill(ds, "Flights");
gvFlights.DataSource = ds.Tables["Flights"];
gvFlights.DataBind();

// Typed DataSets (.xsd files)
var ta = new FlightsTableAdapter();
var dt = ta.GetFlightsByDate(selectedDate);
```

### Entity Framework (Database First / Code First)
```csharp
// EF Database First (.edmx model)
using (var ctx = new MyAppEntities())
{
    var flights = ctx.Flights
        .Where(f => f.Origin == origin && f.DepartureDate == date)
        .Include(f => f.Airline)
        .ToList();
}

// EF Code First (EF 4.1+)
public class MyAppDbContext : DbContext
{
    public DbSet<Flight> Flights { get; set; }
    public DbSet<Airport> Airports { get; set; }
}
```

**EF version detection:**
- `.edmx` file present → EF Database First (EF < 6 era)
- `packages.config` has `EntityFramework` → EF 5 or 6
- NuGet reference `Microsoft.EntityFrameworkCore` → EF Core (rare in WebForms)
- Check for `DbContext` base class vs. `ObjectContext` (older EF)

### LINQ to SQL
```csharp
// .dbml file defines the data model
using (var db = new MyAppDataContext())
{
    var flights = from f in db.Flights
                  where f.DepartureDate == date
                  select f;
}
```

**Detection**: Look for `.dbml` files and classes inheriting from `DataContext`.
LINQ to SQL was Microsoft's pre-EF ORM — it is considered legacy.

### Stored Procedures
```csharp
// Direct ADO.NET
var cmd = new SqlCommand("sp_GetFlightsByRoute", conn);
cmd.CommandType = CommandType.StoredProcedure;
cmd.Parameters.AddWithValue("@origin", origin);
cmd.Parameters.AddWithValue("@dest", destination);

// Entity Framework
var flights = ctx.Database.SqlQuery<Flight>(
    "EXEC sp_GetFlightsByRoute @origin, @dest",
    new SqlParameter("@origin", origin),
    new SqlParameter("@dest", destination)
).ToList();
```

### Inline SQL Detection
Grep for SQL keywords in `.cs` files — a major security and maintainability concern:
```csharp
// BAD: string concatenation (SQL injection risk)
string sql = "SELECT * FROM Users WHERE Name = '" + userName + "'";

// OK: parameterized queries
string sql = "SELECT * FROM Users WHERE Name = @name";
cmd.Parameters.AddWithValue("@name", userName);
```

Count queries by location to identify data-access-in-presentation antipattern:
files in the web project with SQL should be flagged for extraction to a DAL.

## Authentication and Authorization

### ASP.NET Membership (Legacy)
```xml
<!-- web.config -->
<membership defaultProvider="SqlMembershipProvider">
  <providers>
    <add name="SqlMembershipProvider"
         type="System.Web.Security.SqlMembershipProvider"
         connectionStringName="MembershipDB" />
  </providers>
</membership>

<roleManager enabled="true">
  <providers>
    <add name="SqlRoleProvider"
         type="System.Web.Security.SqlRoleProvider" />
  </providers>
</roleManager>
```

### ASP.NET Identity (Newer)
```csharp
// Check for OWIN startup
[assembly: OwinStartup(typeof(MyApp.Startup))]
public class Startup
{
    public void Configuration(IAppBuilder app)
    {
        app.UseCookieAuthentication(new CookieAuthenticationOptions { ... });
    }
}
```

### Forms Authentication
```xml
<authentication mode="Forms">
  <forms loginUrl="~/Login.aspx" timeout="30" protection="All"
         slidingExpiration="true" cookieless="UseCookies" />
</authentication>

<authorization>
  <deny users="?" />
  <allow roles="Admin,Operator" />
</authorization>
```

### Windows Authentication
```xml
<authentication mode="Windows" />
<authorization>
  <allow roles="DOMAIN\FlightOps" />
  <deny users="?" />
</authorization>
```

**Detection**: Check `<authentication mode="">` in `web.config`. Possible values:
`None`, `Windows`, `Forms`, `Passport` (obsolete), `Federation`.

### Role-Based Authorization in Code
```csharp
// Page-level
if (!User.IsInRole("Admin"))
{
    Response.Redirect("AccessDenied.aspx");
}

// Method-level attribute (rare in WebForms, more common in MVC)
[PrincipalPermission(SecurityAction.Demand, Role = "Admin")]
public void DeleteFlight(int id) { }

// Web.config location-based
<location path="Admin">
  <system.web>
    <authorization>
      <allow roles="Admin" />
      <deny users="*" />
    </authorization>
  </system.web>
</location>
```

## Configuration Analysis

### web.config Sections to Analyze

```xml
<!-- Connection strings — CRITICAL (contains database credentials) -->
<connectionStrings>
  <add name="MainDB" connectionString="Server=.;Database=MyApp;
       Integrated Security=true" providerName="System.Data.SqlClient" />
</connectionStrings>

<!-- App settings — business configuration values -->
<appSettings>
  <add key="MaxSearchResults" value="100" />
  <add key="SMTPServer" value="mail.faa.gov" />
  <add key="EnableFlightAlerts" value="true" />
  <add key="MaintenanceMode" value="false" />
</appSettings>

<!-- Custom configuration sections -->
<configSections>
  <section name="flightRules"
           type="MyApp.Config.FlightRulesSection, MyApp.Common" />
</configSections>

<!-- Compilation settings (debug mode, target framework) -->
<compilation debug="true" targetFramework="4.8">
  <assemblies>
    <add assembly="System.Data.Linq, Version=4.0.0.0, ..." />
  </assemblies>
</compilation>

<!-- HTTP runtime limits -->
<httpRuntime maxRequestLength="4096" executionTimeout="110"
             enableVersionHeader="false" targetFramework="4.8" />
```

### Config Transforms
Check for environment-specific transforms:
```
web.config                 ← base configuration
web.Debug.config           ← debug overrides
web.Release.config         ← release overrides
web.Staging.config         ← staging overrides (custom)
web.Production.config      ← production overrides (custom)
```

**Migration note**: Config transforms use XSLT-like syntax. In .NET Core, these
become `appsettings.{Environment}.json` files with JSON merge semantics.

### machine.config Dependencies
Some apps rely on machine-level configuration:
```xml
<!-- Often found in code referencing machine.config settings -->
ConfigurationManager.AppSettings["MachineLevel.Setting"]
```
Grep for `machine.config` references and settings not present in `web.config` —
these are invisible dependencies on the server environment.

## Master Pages and Themes

### Master Page Hierarchy
```aspx
<!-- Site.master (top-level layout) -->
<%@ Master Language="C#" %>
<html>
<head><asp:ContentPlaceHolder ID="head" runat="server" /></head>
<body>
  <div class="header">...</div>
  <asp:ContentPlaceHolder ID="MainContent" runat="server" />
  <div class="footer">...</div>
</body>
</html>

<!-- Admin.master (nested master, extends Site.master) -->
<%@ Master Language="C#" MasterPageFile="~/Site.master" %>
<asp:Content ContentPlaceHolderID="MainContent" runat="server">
  <div class="admin-nav">...</div>
  <asp:ContentPlaceHolder ID="AdminContent" runat="server" />
</asp:Content>
```

**Analysis**: Map the master page hierarchy to understand layout inheritance. Check
for dynamic master page assignment in code-behind:
```csharp
protected override void OnPreInit(EventArgs e)
{
    if (User.IsInRole("Admin"))
        MasterPageFile = "~/Admin.master";
    else
        MasterPageFile = "~/Site.master";
}
```

### Themes and Skins
```
App_Themes/
├── Default/
│   ├── Skin.skin           ← default control appearance
│   └── StyleSheet.css
├── HighContrast/
│   ├── Skin.skin
│   └── StyleSheet.css
```

Skin files define default property values for server controls:
```xml
<!-- Skin.skin -->
<asp:Button runat="server" CssClass="btn-primary" />
<asp:GridView runat="server" CssClass="table table-striped"
    AllowPaging="True" PageSize="20" />
```

## AJAX Patterns

### UpdatePanel (Partial Page Rendering)
```aspx
<asp:ScriptManager ID="ScriptManager1" runat="server" />
<asp:UpdatePanel ID="UpdatePanel1" runat="server">
  <ContentTemplate>
    <asp:GridView ID="gvResults" runat="server" />
    <asp:Button ID="btnRefresh" runat="server" OnClick="btnRefresh_Click" />
  </ContentTemplate>
  <Triggers>
    <asp:AsyncPostBackTrigger ControlID="Timer1" EventName="Tick" />
    <asp:PostBackTrigger ControlID="btnExport" />
  </Triggers>
</asp:UpdatePanel>
```

**Migration impact**: UpdatePanel performs full server-side page lifecycle for
partial updates. This is the most expensive AJAX pattern and maps poorly to
modern SPA approaches. Count UpdatePanel instances as a migration complexity
indicator.

### PageMethods (Client-to-Server AJAX)
```csharp
// Code-behind — static method callable from JavaScript
[WebMethod]
public static string GetFlightStatus(int flightId)
{
    return FlightService.GetStatus(flightId).ToString();
}
```

```javascript
// Client-side call
PageMethods.GetFlightStatus(123, onSuccess, onFailure);
```

### ScriptManager and Script Services
```aspx
<asp:ScriptManager runat="server">
  <Services>
    <asp:ServiceReference Path="~/Services/FlightService.asmx" />
  </Services>
</asp:ScriptManager>
```

This generates JavaScript proxy classes for calling ASMX services from the browser.

### jQuery AJAX (Common in Later WebForms)
```javascript
$.ajax({
    type: "POST",
    url: "FlightService.asmx/SearchFlights",
    data: JSON.stringify({ origin: "JFK", dest: "LAX" }),
    contentType: "application/json; charset=utf-8",
    dataType: "json",
    success: function(response) { /* handle response.d */ }
});
```

**Note**: ASMX services called via jQuery wrap responses in a `.d` property for
security. This is an ASP.NET-specific behavior to document.

## NuGet Package Analysis

### packages.config (Legacy Format)
```xml
<packages>
  <package id="EntityFramework" version="6.4.4" targetFramework="net48" />
  <package id="Newtonsoft.Json" version="13.0.3" targetFramework="net48" />
  <package id="Microsoft.AspNet.Identity.Core" version="2.2.3" />
  <package id="Telerik.UI.for.AspNet.Ajax" version="2023.3.1010" />
  <package id="log4net" version="2.0.15" targetFramework="net48" />
</packages>
```

### PackageReference (SDK-Style .csproj)
```xml
<ItemGroup>
  <PackageReference Include="EntityFramework" Version="6.4.4" />
  <PackageReference Include="Newtonsoft.Json" Version="13.0.3" />
</ItemGroup>
```

### Key Packages to Flag
| Package | Significance |
|---------|-------------|
| `EntityFramework` | Data access, version determines migration path |
| `Telerik.*` / `DevExpress.*` | Third-party UI, no Core equivalent |
| `Microsoft.AspNet.Identity.*` | Auth system, maps to ASP.NET Core Identity |
| `Microsoft.Owin.*` | OWIN middleware, partial Core equivalent |
| `log4net` / `NLog` / `Serilog` | Logging, all have Core versions |
| `Unity` / `Autofac` / `Ninject` | DI containers, Core has built-in DI |
| `Microsoft.ReportViewer.*` | SSRS reports, no direct Core equivalent |
| `System.Data.SqlClient` | ADO.NET, maps to `Microsoft.Data.SqlClient` |
| `Microsoft.AspNet.SignalR` | Real-time, maps to ASP.NET Core SignalR |

## IIS Dependencies

### Application Pool Configuration
Not in source code but critical for behavior:
- Managed pipeline mode: Integrated vs. Classic
- .NET CLR version: v2.0 vs. v4.0
- Identity: NetworkService, ApplicationPoolIdentity, custom account
- Idle timeout, recycling schedule, process model settings

### URL Rewrite Rules
```xml
<!-- web.config IIS URL Rewrite module -->
<system.webServer>
  <rewrite>
    <rules>
      <rule name="FriendlyURLs" stopProcessing="true">
        <match url="^flight/(\d+)$" />
        <action type="Rewrite" url="FlightDetail.aspx?id={R:1}" />
      </rule>
      <rule name="ForceHTTPS" stopProcessing="true">
        <match url="(.*)" />
        <conditions>
          <add input="{HTTPS}" pattern="off" />
        </conditions>
        <action type="Redirect" url="https://{HTTP_HOST}/{R:1}" />
      </rule>
    </rules>
  </rewrite>
</system.webServer>
```

### Custom Handlers and Modules (IIS Level)
```xml
<system.webServer>
  <handlers>
    <add name="ReportHandler" path="*.rpt" verb="GET"
         type="MyApp.ReportHandler, MyApp.Web" />
    <remove name="WebDAV" />
  </handlers>
  <modules>
    <remove name="FormsAuthentication" />
    <add name="CustomAuth" type="MyApp.Auth.CustomAuthModule, MyApp.Web" />
  </modules>
</system.webServer>
```

## Common Gotchas

### Partial Trust
Older deployments may run in partial trust:
```xml
<trust level="Medium" />
```
This restricts reflection, file I/O, and network access. Code that works in
Full Trust may fail in Medium Trust — check for try/catch blocks around
security-sensitive operations.

### Code Access Security (CAS) Policies
.NET Framework CAS is not available in .NET Core. Look for:
```csharp
[FileIOPermission(SecurityAction.Demand, Read = @"C:\Data")]
[PrincipalPermission(SecurityAction.Demand, Role = "Admin")]
```
These must be replaced with middleware-based authorization in the target stack.

### Machine Key Dependencies
```xml
<machineKey validationKey="..." decryptionKey="..."
            validation="SHA1" decryption="AES" />
```
Machine keys affect ViewState encryption, Forms auth ticket encryption, and
anonymous identification. Apps in web farms MUST share machine keys. This is
a deployment-level dependency invisible in application code.

### GAC (Global Assembly Cache) Assemblies
```csharp
// Assembly reference with specific version and public key token
[assembly: AssemblyKeyFile("MyApp.snk")]
```
Check `.csproj` for GAC-deployed assemblies (no `HintPath`, or path to
`C:\Windows\assembly\`). GAC assemblies are server-level dependencies not
packaged with the application.

### Precompilation
Some WebForms apps are deployed precompiled:
```
bin/
├── App_Web_*.dll        ← precompiled page assemblies
├── *.compiled           ← precompilation markers
```
If the deployed artifact is precompiled, source `.aspx` files may contain
only a single `<%@ Page %>` directive with no markup. The real source must
be obtained from the development environment or source control.

### Static File Handling
WebForms apps often serve static files through ASP.NET (not IIS directly):
```xml
<!-- Static file handler -->
<handlers>
  <add name="StaticFile" path="*.*" verb="GET,HEAD"
       type="System.Web.StaticFileHandler" />
</handlers>
```
Check for custom static file handling, bundling (`BundleConfig.cs`), and
minification via `System.Web.Optimization`.

### Bundling and Minification
```csharp
// App_Start/BundleConfig.cs
public class BundleConfig
{
    public static void RegisterBundles(BundleCollection bundles)
    {
        bundles.Add(new ScriptBundle("~/bundles/jquery")
            .Include("~/Scripts/jquery-{version}.js"));
        bundles.Add(new StyleBundle("~/Content/css")
            .Include("~/Content/site.css"));
    }
}
```
```aspx
<%: Scripts.Render("~/bundles/jquery") %>
<%: Styles.Render("~/Content/css") %>
```
