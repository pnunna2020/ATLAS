# Business Rule Catalog Template

Template for Pass 2 output of the 4-Pass Application Analysis. Every discovered
business rule is recorded here with full source traceability.

## Purpose
Capture every validation, calculation, conditional, and workflow rule extracted
from the legacy application so downstream extraction and generation have a
complete prescriptive specification to work from.

## Catalog Structure

Each entry in the catalog is a single business rule record.

### Rule Record Fields

- **id** (`BR-NNN`): Unique rule identifier. Stable across re-runs.
- **name**: Short human-readable label.
- **category**: One of `validation`, `calculation`, `conditional`, `workflow`,
  `state-transition`, `authorization`.
- **description**: What the rule enforces, in prescriptive language.
- **source**: Citation in `{file}:{line}` format pointing to the originating
  code location. Stored procedures use `{schema}.{proc}:{line}`.
- **logic**: Pseudocode or structured representation of the rule.
- **inputs**: Named parameters the rule consumes.
- **outputs**: Values the rule produces or fields it modifies.
- **conditions**: Guard conditions under which the rule applies.
- **exceptions**: Error paths the rule can raise.
- **implicit**: `true` if the rule is derived from framework conventions,
  database constraints, or type coercion rather than explicit code.
- **confidence**: `high` / `medium` / `low` — confidence that extraction is
  complete and accurate.
- **test-scenarios**: List of Given/When/Then scenarios covering the rule.

## Example Entry

```yaml
- id: BR-042
  name: Flight plan altitude validation
  category: validation
  description: >
    Flight plans SHALL reject altitudes below 500 feet AGL or above 60000 feet.
  source: src/flight/plan_validator.cfc:118
  logic: |
    IF altitude < 500 OR altitude > 60000 THEN
      REJECT with message "Altitude out of range"
  inputs:
    - altitude: integer (feet AGL)
  outputs:
    - validation_result: boolean
  conditions:
    - flight_type != "EMERGENCY"
  exceptions:
    - AltitudeOutOfRangeException
  implicit: false
  confidence: high
  test-scenarios:
    - name: valid altitude accepted
      given: altitude = 35000
      when: validate_plan is called
      then: returns valid
    - name: below minimum rejected
      given: altitude = 250
      when: validate_plan is called
      then: returns AltitudeOutOfRangeException
```

## TODO for Skill Author

- [ ] Add client-profile-specific rule categories if FAA domain requires
      additional classifications (e.g., `safety-critical` flag).
- [ ] Add cross-reference fields linking rules to Pass 3 data flows and Pass 4
      UX journeys.
- [ ] Add anomaly markers (duplicate, contradictory, dead-code) resolved via the
      anomaly-resolution-rules.yaml from the extraction skill.
- [ ] Decide whether to store the catalog as a single YAML document or one file
      per functional area.
