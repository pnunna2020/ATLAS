# Application Analysis Report — {{APP_NAME}}

## Executive Summary
- **Application**: {{APP_NAME}}
- **Owner**: {{OWNER}}
- **Archetype**: {{ARCHETYPE}} (web/batch/API/hybrid)
- **Primary Language**: {{LANGUAGE}}
- **Lines of Code**: {{LOC}}
- **Database**: {{DB_TYPE}} ({{DB_SIZE}})
- **Active Users**: {{USER_COUNT}}
- **TCO Baseline**: ${{TCO_ANNUAL}}/year

---

## Pass 1: Architecture
{{ARCHITECTURE_FINDINGS}}

## Pass 2: Business Logic
{{BUSINESS_LOGIC_FINDINGS}}

## Pass 3: Data & Integration
{{DATA_INTEGRATION_FINDINGS}}

## Pass 4: UX & User Journey
{{UX_FINDINGS}}

---

## Recommended Disposition: {{DISPOSITION}}
## Complexity: {{COMPLEXITY}}
## Safety Tier: {{SAFETY_TIER}}
## Recommended Wave: {{WAVE}}
