-- Oracle EBS Customization Inventory Script
-- Generates a comprehensive inventory of all custom objects in an EBS instance.
-- Run as a user with DBA privileges or SELECT ANY DICTIONARY grant.
--
-- Usage: @inventory_ebs_customizations.sql
-- Output: Console output suitable for spooling to a file.
--
-- Customize the XX_ prefix below if the client uses a different convention
-- (e.g., XXFAA_, XXCUST_).

SET LINESIZE 200
SET PAGESIZE 999
SET FEEDBACK OFF
SET VERIFY OFF
SET HEADING ON
SET TRIMSPOOL ON

DEFINE custom_prefix = 'XX'

PROMPT ========================================================
PROMPT  Oracle EBS Customization Inventory
PROMPT  Generated: &_DATE
PROMPT ========================================================

-- ============================================================
-- 1. Custom Database Objects by Type and Status
-- Purpose: Full count of custom objects to establish scope.
-- ============================================================
PROMPT
PROMPT === 1. Custom Objects Summary by Type and Status ===
PROMPT

SELECT
    object_type,
    status,
    COUNT(*) AS object_count,
    TO_CHAR(MIN(created), 'YYYY-MM-DD') AS earliest_created,
    TO_CHAR(MAX(last_ddl_time), 'YYYY-MM-DD') AS latest_modified
FROM dba_objects
WHERE object_name LIKE '&custom_prefix\_%' ESCAPE '\'
  AND object_name NOT LIKE 'BIN$%'
  AND object_type IN (
      'PACKAGE', 'PACKAGE BODY', 'PROCEDURE', 'FUNCTION',
      'TRIGGER', 'VIEW', 'TABLE', 'SEQUENCE', 'TYPE', 'TYPE BODY',
      'MATERIALIZED VIEW', 'SYNONYM', 'INDEX'
  )
GROUP BY object_type, status
ORDER BY object_count DESC;

-- ============================================================
-- 2. Custom PL/SQL Packages with Line Counts
-- Purpose: Identify the largest custom packages (most business logic).
-- ============================================================
PROMPT
PROMPT === 2. Custom PL/SQL Packages (Ranked by Size) ===
PROMPT

SELECT
    s.owner,
    s.name AS package_name,
    s.type,
    COUNT(*) AS line_count,
    o.status,
    TO_CHAR(o.last_ddl_time, 'YYYY-MM-DD') AS last_modified
FROM dba_source s
JOIN dba_objects o
    ON o.owner = s.owner
   AND o.object_name = s.name
   AND o.object_type = s.type
WHERE s.name LIKE '&custom_prefix\_%' ESCAPE '\'
  AND s.type IN ('PACKAGE', 'PACKAGE BODY')
GROUP BY s.owner, s.name, s.type, o.status, o.last_ddl_time
ORDER BY line_count DESC;

-- ============================================================
-- 3. Custom Concurrent Programs with Execution Method
-- Purpose: Classify concurrent programs by type and execution method.
-- ============================================================
PROMPT
PROMPT === 3. Custom Concurrent Programs ===
PROMPT

SELECT
    fcp.concurrent_program_name AS prog_name,
    SUBSTR(fcpt.user_concurrent_program_name, 1, 60) AS user_prog_name,
    DECODE(fcp.execution_method_code,
        'I', 'PL/SQL Stored Proc',
        'H', 'Host (Shell)',
        'J', 'Java Concurrent',
        'K', 'Java Stored Proc',
        'L', 'SQL*Loader',
        'P', 'Oracle Reports',
        'S', 'Spawned Process',
        'A', 'BI Publisher',
        fcp.execution_method_code
    ) AS exec_method,
    fe.execution_file_name AS exec_file,
    fa.application_short_name AS app,
    fcp.enabled_flag AS enabled,
    fcp.run_alone_flag AS run_alone,
    TO_CHAR(fcp.last_update_date, 'YYYY-MM-DD') AS last_updated
FROM fnd_concurrent_programs fcp
JOIN fnd_concurrent_programs_tl fcpt
    ON fcp.concurrent_program_id = fcpt.concurrent_program_id
   AND fcp.application_id = fcpt.application_id
   AND fcpt.language = 'US'
JOIN fnd_executables fe
    ON fcp.executable_id = fe.executable_id
   AND fcp.executable_application_id = fe.application_id
JOIN fnd_application fa
    ON fcp.application_id = fa.application_id
WHERE fcp.concurrent_program_name LIKE '&custom_prefix\_%' ESCAPE '\'
   OR fa.application_short_name LIKE '&custom_prefix%'
ORDER BY fcp.concurrent_program_name;

-- ============================================================
-- 4. Form Personalizations (Active Rules with Conditions)
-- Purpose: Inventory all active form personalizations.
-- ============================================================
PROMPT
PROMPT === 4. Active Form Personalizations ===
PROMPT

SELECT
    ff.form_name,
    ffcr.function_name,
    SUBSTR(ffcr.description, 1, 50) AS description,
    ffcr.trigger_event,
    ffcr.trigger_object,
    SUBSTR(ffcr.condition, 1, 80) AS condition,
    ffcr.sequence AS seq,
    ffca.action_type,
    ffca.property_name,
    SUBSTR(ffca.property_value, 1, 40) AS property_value
FROM fnd_form_custom_rules ffcr
JOIN fnd_form_custom_actions ffca
    ON ffcr.rule_id = ffca.rule_id
JOIN fnd_form ff
    ON ffcr.form_id = ff.form_id
WHERE ffcr.enabled = 'Y'
ORDER BY ff.form_name, ffcr.sequence;

-- ============================================================
-- 5. Custom Value Sets and Validation Types
-- Purpose: Identify custom value sets and their validation approach.
-- ============================================================
PROMPT
PROMPT === 5. Custom Value Sets ===
PROMPT

SELECT
    fvs.flex_value_set_name,
    DECODE(fvs.validation_type,
        'I', 'Independent',
        'D', 'Dependent',
        'F', 'Table',
        'U', 'Special (PL/SQL)',
        'P', 'Pair',
        'N', 'None',
        'X', 'Translatable Ind',
        'Y', 'Translatable Dep',
        fvs.validation_type
    ) AS validation_type,
    fvs.format_type,
    fvs.maximum_size,
    SUBSTR(fvs.description, 1, 60) AS description,
    -- For table-validated, show the source table
    fvst.application_table_name AS table_name,
    SUBSTR(fvst.additional_where_clause, 1, 80) AS where_clause
FROM fnd_flex_value_sets fvs
LEFT JOIN fnd_flex_validation_tables fvst
    ON fvs.flex_value_set_id = fvst.flex_value_set_id
WHERE fvs.flex_value_set_name LIKE '&custom_prefix%'
ORDER BY fvs.flex_value_set_name;

-- ============================================================
-- 6. Workflow Customizations
-- Purpose: Identify custom workflow item types and their PL/SQL functions.
-- ============================================================
PROMPT
PROMPT === 6. Custom Workflow Item Types ===
PROMPT

SELECT
    wit.name AS item_type,
    wit.display_name,
    COUNT(DISTINCT wa.name) AS activity_count,
    COUNT(DISTINCT CASE WHEN wa.function IS NOT NULL THEN wa.name END)
        AS function_count
FROM wf_item_types_vl wit
JOIN wf_activities wa
    ON wa.item_type = wit.name
   AND wa.end_date IS NULL
WHERE wit.name LIKE '&custom_prefix%'
GROUP BY wit.name, wit.display_name
ORDER BY wit.name;

-- Custom workflow PL/SQL functions
PROMPT
PROMPT === 6b. Workflow PL/SQL Functions ===
PROMPT

SELECT DISTINCT
    wa.item_type,
    wa.name AS activity_name,
    wa.function AS plsql_function,
    wa.type AS activity_type,
    wa.result_type
FROM wf_activities wa
WHERE wa.item_type LIKE '&custom_prefix%'
  AND wa.function IS NOT NULL
  AND wa.end_date IS NULL
ORDER BY wa.item_type, wa.name;

-- ============================================================
-- 7. Custom Profile Options and Settings
-- Purpose: Identify configuration-as-code via custom profiles.
-- ============================================================
PROMPT
PROMPT === 7. Custom Profile Options ===
PROMPT

SELECT
    fpo.profile_option_name,
    SUBSTR(fpot.user_profile_option_name, 1, 50) AS display_name,
    fpov.level_id,
    DECODE(fpov.level_id,
        10001, 'Site',
        10002, 'Application',
        10003, 'Responsibility',
        10004, 'User',
        10005, 'Server',
        10006, 'Organization',
        TO_CHAR(fpov.level_id)
    ) AS level_name,
    SUBSTR(fpov.profile_option_value, 1, 60) AS value
FROM fnd_profile_options fpo
JOIN fnd_profile_options_tl fpot
    ON fpo.profile_option_id = fpot.profile_option_id
   AND fpot.language = 'US'
LEFT JOIN fnd_profile_option_values fpov
    ON fpo.profile_option_id = fpov.profile_option_id
   AND fpo.application_id = fpov.application_id
WHERE fpo.profile_option_name LIKE '&custom_prefix%'
ORDER BY fpo.profile_option_name, fpov.level_id;

-- ============================================================
-- 8. Interface and Staging Tables
-- Purpose: Identify integration boundaries and data exchange tables.
-- ============================================================
PROMPT
PROMPT === 8. Interface and Staging Tables ===
PROMPT

SELECT
    t.table_name,
    t.num_rows,
    t.tablespace_name,
    TO_CHAR(t.last_analyzed, 'YYYY-MM-DD') AS last_analyzed,
    (SELECT COUNT(*) FROM dba_tab_columns c
     WHERE c.owner = t.owner AND c.table_name = t.table_name) AS column_count,
    (SELECT COUNT(*) FROM dba_indexes i
     WHERE i.table_owner = t.owner AND i.table_name = t.table_name) AS index_count
FROM dba_tables t
WHERE (
    t.table_name LIKE '&custom_prefix\_%INTERFACE%' ESCAPE '\'
    OR t.table_name LIKE '&custom_prefix\_%STG%' ESCAPE '\'
    OR t.table_name LIKE '&custom_prefix\_%STAGING%' ESCAPE '\'
    OR t.table_name LIKE '&custom_prefix\_%TEMP%' ESCAPE '\'
    OR t.table_name LIKE '&custom_prefix\_%XREF%' ESCAPE '\'
)
AND t.table_name NOT LIKE 'BIN$%'
ORDER BY t.table_name;

-- ============================================================
-- 9. Custom Grants and Responsibilities
-- Purpose: Map the security model for custom functionality.
-- ============================================================
PROMPT
PROMPT === 9. Custom Responsibilities ===
PROMPT

SELECT
    fr.responsibility_key,
    SUBSTR(frt.responsibility_name, 1, 50) AS resp_name,
    fa.application_short_name AS app,
    fm.menu_name,
    fr.start_date,
    fr.end_date,
    TO_CHAR(fr.creation_date, 'YYYY-MM-DD') AS created
FROM fnd_responsibility fr
JOIN fnd_responsibility_tl frt
    ON fr.responsibility_id = frt.responsibility_id
   AND fr.application_id = frt.application_id
   AND frt.language = 'US'
JOIN fnd_application fa
    ON fr.application_id = fa.application_id
JOIN fnd_menus fm
    ON fr.menu_id = fm.menu_id
WHERE fr.responsibility_key LIKE '&custom_prefix%'
   OR fa.application_short_name LIKE '&custom_prefix%'
ORDER BY fr.responsibility_key;

-- ============================================================
-- 10. Database Links (External System Connections)
-- Purpose: Map integration boundaries to external systems.
-- ============================================================
PROMPT
PROMPT === 10. Database Links ===
PROMPT

SELECT
    owner,
    db_link,
    username,
    host,
    TO_CHAR(created, 'YYYY-MM-DD') AS created
FROM dba_db_links
ORDER BY owner, db_link;

-- ============================================================
-- 11. Custom Tables with Row Counts
-- Purpose: Identify data volumes for migration planning.
-- ============================================================
PROMPT
PROMPT === 11. Custom Tables (Top 50 by Row Count) ===
PROMPT

SELECT *
FROM (
    SELECT
        t.table_name,
        t.num_rows,
        t.avg_row_len,
        ROUND(t.num_rows * t.avg_row_len / 1024 / 1024, 2) AS est_size_mb,
        t.tablespace_name,
        TO_CHAR(t.last_analyzed, 'YYYY-MM-DD') AS last_analyzed
    FROM dba_tables t
    WHERE t.table_name LIKE '&custom_prefix\_%' ESCAPE '\'
      AND t.table_name NOT LIKE 'BIN$%'
      AND t.num_rows IS NOT NULL
    ORDER BY t.num_rows DESC
)
WHERE ROWNUM <= 50;

-- ============================================================
-- 12. Descriptive Flexfield Customizations
-- Purpose: Identify custom fields added to standard EBS tables.
-- ============================================================
PROMPT
PROMPT === 12. Custom DFF Segments (on Standard Tables) ===
PROMPT

SELECT
    fdf.application_table_name AS base_table,
    fdf.descriptive_flexfield_name AS dff_name,
    fdfcu.descriptive_flex_context_code AS context,
    fdfs.end_user_column_name AS field_label,
    fdfs.application_column_name AS attribute_column,
    fdfs.required_flag AS required,
    fvs.flex_value_set_name AS value_set
FROM fnd_descriptive_flexs fdf
JOIN fnd_descr_flex_contexts_vl fdfcu
    ON fdf.application_id = fdfcu.application_id
   AND fdf.descriptive_flexfield_name = fdfcu.descriptive_flexfield_name
JOIN fnd_descr_flex_column_usages fdfs
    ON fdfcu.application_id = fdfs.application_id
   AND fdfcu.descriptive_flexfield_name = fdfs.descriptive_flexfield_name
   AND fdfcu.descriptive_flex_context_code = fdfs.descriptive_flex_context_code
LEFT JOIN fnd_flex_value_sets fvs
    ON fdfs.flex_value_set_id = fvs.flex_value_set_id
WHERE fdfs.enabled_flag = 'Y'
  AND fdfcu.enabled_flag = 'Y'
  AND fdfcu.descriptive_flex_context_code LIKE '&custom_prefix%'
ORDER BY fdf.application_table_name, fdfs.application_column_name;

-- ============================================================
-- 13. Invalid Objects (Compilation Errors)
-- Purpose: Flag broken custom objects that need repair before migration.
-- ============================================================
PROMPT
PROMPT === 13. Invalid Custom Objects ===
PROMPT

SELECT
    object_type,
    object_name,
    TO_CHAR(last_ddl_time, 'YYYY-MM-DD') AS last_ddl
FROM dba_objects
WHERE object_name LIKE '&custom_prefix\_%' ESCAPE '\'
  AND status = 'INVALID'
  AND object_name NOT LIKE 'BIN$%'
ORDER BY object_type, object_name;

-- ============================================================
-- 14. Dependency Map (Custom Objects Referencing Standard Objects)
-- Purpose: Understand coupling between custom and standard code.
-- ============================================================
PROMPT
PROMPT === 14. Custom-to-Standard Dependencies ===
PROMPT

SELECT
    d.name AS custom_object,
    d.type AS custom_type,
    d.referenced_name AS standard_object,
    d.referenced_type AS standard_type,
    d.referenced_owner AS standard_owner
FROM dba_dependencies d
WHERE d.name LIKE '&custom_prefix\_%' ESCAPE '\'
  AND d.type IN ('PACKAGE', 'PACKAGE BODY', 'PROCEDURE', 'FUNCTION',
                  'TRIGGER', 'VIEW')
  AND d.referenced_name NOT LIKE '&custom_prefix\_%' ESCAPE '\'
  AND d.referenced_type IN ('PACKAGE', 'PACKAGE BODY', 'TABLE', 'VIEW',
                             'SYNONYM', 'SEQUENCE', 'TYPE')
  AND d.referenced_owner NOT IN ('SYS', 'SYSTEM')
ORDER BY d.name, d.referenced_name;

PROMPT
PROMPT ========================================================
PROMPT  Inventory Complete
PROMPT ========================================================

SET FEEDBACK ON
SET VERIFY ON
