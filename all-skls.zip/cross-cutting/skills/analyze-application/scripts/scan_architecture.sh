#!/bin/bash
# Architecture Scanner — Detects framework, patterns, and structure
# Usage: ./scan_architecture.sh <repo_path>
REPO="$1"
if [ -z "$REPO" ]; then echo "Usage: ./scan_architecture.sh <repo_path>"; exit 1; fi

echo "{"
echo '  "repo_path": "'$REPO'",'

# Language detection
echo '  "languages": {'
find "$REPO" -type f -name "*.java" | wc -l | xargs -I{} echo '    "java": {},'
find "$REPO" -type f -name "*.cfm" -o -name "*.cfc" | wc -l | xargs -I{} echo '    "coldfusion": {},'
find "$REPO" -type f -name "*.py" | wc -l | xargs -I{} echo '    "python": {},'
find "$REPO" -type f -name "*.js" -o -name "*.ts" | wc -l | xargs -I{} echo '    "javascript_typescript": {},'
find "$REPO" -type f -name "*.sql" | wc -l | xargs -I{} echo '    "sql": {}'
echo '  },'

# Framework detection
echo '  "frameworks": ['
[ -f "$REPO/pom.xml" ] && echo '    "maven",'
[ -f "$REPO/build.gradle" ] && echo '    "gradle",'
grep -rl "spring-boot" "$REPO" --include="*.xml" --include="*.gradle" -l 2>/dev/null | head -1 | xargs -I{} echo '    "spring-boot",'
grep -rl "Application.cfc" "$REPO" -l 2>/dev/null | head -1 | xargs -I{} echo '    "coldfusion-framework",'
[ -f "$REPO/package.json" ] && echo '    "node",'
echo '    "detected"'
echo '  ],'

# Database connections
echo '  "database_indicators": ['
grep -rl "datasource\|jdbc:\|connection.url\|DATABASE_URL" "$REPO" --include="*.xml" --include="*.properties" --include="*.yaml" --include="*.yml" --include="*.cfm" -l 2>/dev/null | while read f; do echo "    "$f","; done
echo '    "scanned"'
echo '  ],'

# Total files and lines
echo '  "total_files": '$(find "$REPO" -type f | wc -l)','
echo '  "total_lines": '$(find "$REPO" -type f \( -name "*.java" -o -name "*.cfm" -o -name "*.cfc" -o -name "*.py" -o -name "*.js" -o -name "*.ts" \) -exec cat {} + 2>/dev/null | wc -l)
echo "}"
