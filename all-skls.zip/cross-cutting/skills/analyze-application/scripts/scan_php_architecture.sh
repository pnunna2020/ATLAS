#!/bin/bash
# PHP Architecture Scanner
# Scans a PHP project directory and outputs a JSON architecture fingerprint.
#
# Usage: ./scan_php_architecture.sh <repo_path>
#
# Detects:
#   - Framework type and version
#   - Composer dependencies and PHP version constraint
#   - File counts by type (.php, .phtml, .tpl, .blade.php)
#   - Database access pattern (PDO, mysqli, mysql_*, ORM)
#   - Class count, function count, include count
#   - Security concern flags (eval, unserialize, mysql_*)

set -euo pipefail

REPO="${1:-}"
if [ -z "$REPO" ]; then
    echo "Usage: ./scan_php_architecture.sh <repo_path>" >&2
    exit 1
fi

if [ ! -d "$REPO" ]; then
    echo "Error: Directory '$REPO' does not exist" >&2
    exit 1
fi

# --- Helper Functions ---

count_files() {
    local pattern="$1"
    find "$REPO" -type f -iname "$pattern" \
        -not -path "*/vendor/*" \
        -not -path "*/node_modules/*" \
        -not -path "*/.git/*" \
        -not -path "*/cache/*" \
        2>/dev/null | wc -l | tr -d ' '
}

count_lines() {
    local pattern="$1"
    find "$REPO" -type f -iname "$pattern" \
        -not -path "*/vendor/*" \
        -not -path "*/node_modules/*" \
        -not -path "*/.git/*" \
        2>/dev/null -exec cat {} + 2>/dev/null | wc -l | tr -d ' '
}

# Count occurrences of a pattern in PHP files (excluding vendor)
count_pattern() {
    local pattern="$1"
    grep -r "$pattern" "$REPO" \
        --include="*.php" \
        --exclude-dir=vendor \
        --exclude-dir=node_modules \
        --exclude-dir=.git \
        -c 2>/dev/null | \
        awk -F: '{s+=$2} END{print s+0}'
}

escape_json() {
    echo "$1" | sed 's/\\/\\\\/g; s/"/\\"/g; s/\t/\\t/g' | tr '\n' ' '
}

# --- Framework Detection ---

FRAMEWORK="none"
FRAMEWORK_VERSION="unknown"

# Check for Laravel
if [ -f "$REPO/artisan" ] && grep -q "Laravel" "$REPO/artisan" 2>/dev/null; then
    FRAMEWORK="laravel"
    if [ -f "$REPO/vendor/laravel/framework/src/Illuminate/Foundation/Application.php" ]; then
        FRAMEWORK_VERSION=$(grep -oP "const VERSION = '\K[^']+" \
            "$REPO/vendor/laravel/framework/src/Illuminate/Foundation/Application.php" 2>/dev/null || echo "unknown")
    fi
fi

# Check for Symfony
if [ "$FRAMEWORK" = "none" ] && [ -f "$REPO/symfony.lock" ]; then
    FRAMEWORK="symfony"
    if [ -f "$REPO/vendor/symfony/http-kernel/Kernel.php" ]; then
        FRAMEWORK_VERSION=$(grep -oP "const VERSION = '\K[^']+" \
            "$REPO/vendor/symfony/http-kernel/Kernel.php" 2>/dev/null || echo "unknown")
    fi
fi

# Check for CodeIgniter
if [ "$FRAMEWORK" = "none" ] && [ -f "$REPO/system/core/CodeIgniter.php" ]; then
    FRAMEWORK="codeigniter"
    FRAMEWORK_VERSION=$(grep -oP "define\('CI_VERSION',\s*'\K[^']+" \
        "$REPO/system/core/CodeIgniter.php" 2>/dev/null || echo "unknown")
fi

# Check for CakePHP
if [ "$FRAMEWORK" = "none" ] && [ -d "$REPO/vendor/cakephp" ]; then
    FRAMEWORK="cakephp"
    if [ -f "$REPO/vendor/cakephp/cakephp/VERSION.txt" ]; then
        FRAMEWORK_VERSION=$(cat "$REPO/vendor/cakephp/cakephp/VERSION.txt" 2>/dev/null | head -1 | tr -d '[:space:]')
    fi
fi

# Check for WordPress
if [ "$FRAMEWORK" = "none" ] && [ -f "$REPO/wp-config.php" ]; then
    FRAMEWORK="wordpress"
    if [ -f "$REPO/wp-includes/version.php" ]; then
        FRAMEWORK_VERSION=$(grep -oP "\\\$wp_version = '\K[^']+" \
            "$REPO/wp-includes/version.php" 2>/dev/null || echo "unknown")
    fi
fi

# Check for Yii
if [ "$FRAMEWORK" = "none" ] && [ -f "$REPO/yii" ]; then
    FRAMEWORK="yii"
fi

# Check for Drupal
if [ "$FRAMEWORK" = "none" ] && [ -f "$REPO/sites/default/settings.php" ]; then
    FRAMEWORK="drupal"
fi

# Check for Slim
if [ "$FRAMEWORK" = "none" ] && [ -f "$REPO/composer.json" ]; then
    if grep -q '"slim/slim"' "$REPO/composer.json" 2>/dev/null; then
        FRAMEWORK="slim"
    fi
fi

# --- Composer Dependency Analysis ---

PHP_VERSION_CONSTRAINT="unknown"
DEPENDENCY_COUNT=0
AUTOLOAD_TYPE="none"
COMPOSER_PACKAGES="[]"

if [ -f "$REPO/composer.json" ]; then
    # Extract PHP version constraint
    PHP_VERSION_CONSTRAINT=$(grep -oP '"php"\s*:\s*"\K[^"]+' "$REPO/composer.json" 2>/dev/null || echo "unknown")

    # Count direct dependencies
    DEPENDENCY_COUNT=$(grep -c '"[a-z]' "$REPO/composer.json" 2>/dev/null || echo "0")

    # Detect autoload type
    if grep -q '"psr-4"' "$REPO/composer.json" 2>/dev/null; then
        AUTOLOAD_TYPE="psr-4"
    elif grep -q '"classmap"' "$REPO/composer.json" 2>/dev/null; then
        AUTOLOAD_TYPE="classmap"
    elif grep -q '"files"' "$REPO/composer.json" 2>/dev/null; then
        AUTOLOAD_TYPE="files"
    fi

    # Extract package names from require section
    COMPOSER_PACKAGES=$(grep -oP '"([a-z0-9-]+/[a-z0-9-]+)"\s*:' "$REPO/composer.json" 2>/dev/null | \
        grep -oP '"[^"]+' | sed 's/"//' | \
        sort -u | \
        awk 'BEGIN{printf "["} NR>1{printf ","} {printf "\"%s\"", $0} END{printf "]"}')
    if [ -z "$COMPOSER_PACKAGES" ]; then
        COMPOSER_PACKAGES="[]"
    fi
fi

# --- File Counts ---

PHP_COUNT=$(count_files "*.php")
PHTML_COUNT=$(count_files "*.phtml")
TPL_COUNT=$(count_files "*.tpl")
BLADE_COUNT=$(count_files "*.blade.php")
TWIG_COUNT=$(count_files "*.twig")
JS_COUNT=$(count_files "*.js")
CSS_COUNT=$(count_files "*.css")
SQL_COUNT=$(count_files "*.sql")
JSON_COUNT=$(count_files "*.json")
XML_COUNT=$(count_files "*.xml")
INI_COUNT=$(count_files "*.ini")
YAML_COUNT=$(count_files "*.yaml")
YML_COUNT=$(count_files "*.yml")

# --- Lines of Code ---

PHP_LOC=$(count_lines "*.php")
JS_LOC=$(count_lines "*.js")
CSS_LOC=$(count_lines "*.css")
SQL_LOC=$(count_lines "*.sql")
TOTAL_LOC=$((PHP_LOC + JS_LOC + CSS_LOC + SQL_LOC))

# --- Database Access Pattern Detection ---

DB_PATTERN="unknown"
PDO_USAGE=$(count_pattern "new PDO\|PDO::")
MYSQLI_USAGE=$(count_pattern "new mysqli\|mysqli_connect\|mysqli_query")
MYSQL_USAGE=$(count_pattern "mysql_connect\|mysql_query\|mysql_fetch")
DOCTRINE_USAGE=$(count_pattern "EntityManager\|getRepository\|createQueryBuilder")
ELOQUENT_USAGE=$(count_pattern "extends Model\|DB::table\|Eloquent")
RAW_SQL=$(count_pattern "mysql_query\|mysqli_query\|\->query(\|->exec(")

if [ "$DOCTRINE_USAGE" -gt 0 ]; then
    DB_PATTERN="doctrine"
elif [ "$ELOQUENT_USAGE" -gt 0 ]; then
    DB_PATTERN="eloquent"
elif [ "$PDO_USAGE" -gt 0 ]; then
    DB_PATTERN="pdo"
elif [ "$MYSQLI_USAGE" -gt 0 ]; then
    DB_PATTERN="mysqli"
elif [ "$MYSQL_USAGE" -gt 0 ]; then
    DB_PATTERN="mysql_legacy"
fi

# --- Code Metrics ---

CLASS_COUNT=$(grep -r "^class \|^abstract class \|^final class " "$REPO" \
    --include="*.php" \
    --exclude-dir=vendor --exclude-dir=node_modules --exclude-dir=.git \
    -c 2>/dev/null | awk -F: '{s+=$2} END{print s+0}')

FUNCTION_COUNT=$(grep -r "function " "$REPO" \
    --include="*.php" \
    --exclude-dir=vendor --exclude-dir=node_modules --exclude-dir=.git \
    -c 2>/dev/null | awk -F: '{s+=$2} END{print s+0}')

INCLUDE_COUNT=$(count_pattern "include\|require\|include_once\|require_once")

INTERFACE_COUNT=$(grep -r "^interface " "$REPO" \
    --include="*.php" \
    --exclude-dir=vendor --exclude-dir=node_modules --exclude-dir=.git \
    -c 2>/dev/null | awk -F: '{s+=$2} END{print s+0}')

TRAIT_COUNT=$(grep -r "^trait " "$REPO" \
    --include="*.php" \
    --exclude-dir=vendor --exclude-dir=node_modules --exclude-dir=.git \
    -c 2>/dev/null | awk -F: '{s+=$2} END{print s+0}')

# --- Security Concern Flags ---

EVAL_COUNT=$(count_pattern "eval(")
UNSERIALIZE_COUNT=$(count_pattern "unserialize(")
EXEC_COUNT=$(count_pattern "exec(\|system(\|passthru(\|shell_exec(\|popen(")
MYSQL_DEPRECATED_COUNT=$MYSQL_USAGE
SQL_CONCAT_COUNT=$(grep -r "\\\$_\(GET\|POST\|REQUEST\|COOKIE\)" "$REPO" \
    --include="*.php" \
    --exclude-dir=vendor --exclude-dir=node_modules --exclude-dir=.git \
    -c 2>/dev/null | awk -F: '{s+=$2} END{print s+0}')
FILE_INCLUDE_VULN=$(grep -r "include.*\\\$_\|require.*\\\$_" "$REPO" \
    --include="*.php" \
    --exclude-dir=vendor --exclude-dir=node_modules --exclude-dir=.git \
    -c 2>/dev/null | awk -F: '{s+=$2} END{print s+0}')

SECURITY_FLAGS=0
[ "$EVAL_COUNT" -gt 0 ] && SECURITY_FLAGS=$((SECURITY_FLAGS + 1))
[ "$UNSERIALIZE_COUNT" -gt 0 ] && SECURITY_FLAGS=$((SECURITY_FLAGS + 1))
[ "$EXEC_COUNT" -gt 0 ] && SECURITY_FLAGS=$((SECURITY_FLAGS + 1))
[ "$MYSQL_DEPRECATED_COUNT" -gt 0 ] && SECURITY_FLAGS=$((SECURITY_FLAGS + 1))
[ "$FILE_INCLUDE_VULN" -gt 0 ] && SECURITY_FLAGS=$((SECURITY_FLAGS + 1))

# --- Session Usage ---

SESSION_USAGE=$(count_pattern "\\\$_SESSION")
COOKIE_USAGE=$(count_pattern "\\\$_COOKIE")

# --- Template Engine Detection ---

TEMPLATE_ENGINE="none"
if [ "$BLADE_COUNT" -gt 0 ]; then
    TEMPLATE_ENGINE="blade"
elif [ "$TWIG_COUNT" -gt 0 ]; then
    TEMPLATE_ENGINE="twig"
elif [ "$PHTML_COUNT" -gt 0 ]; then
    TEMPLATE_ENGINE="phtml"
elif [ "$TPL_COUNT" -gt 0 ]; then
    TEMPLATE_ENGINE="smarty"
fi

# --- Test Detection ---

TEST_FRAMEWORK="none"
TEST_COUNT=0

if [ -f "$REPO/phpunit.xml" ] || [ -f "$REPO/phpunit.xml.dist" ]; then
    TEST_FRAMEWORK="phpunit"
    TEST_COUNT=$(count_files "*Test.php")
fi

if grep -rq "use Pest" "$REPO" --include="*.php" \
    --exclude-dir=vendor 2>/dev/null; then
    TEST_FRAMEWORK="pest"
fi

# --- Output JSON ---

cat <<EOF
{
  "repo_path": "$(escape_json "$REPO")",
  "scan_date": "$(date -u +%Y-%m-%dT%H:%M:%SZ)",
  "framework": {
    "name": "$FRAMEWORK",
    "version": "$FRAMEWORK_VERSION"
  },
  "php_version_constraint": "$PHP_VERSION_CONSTRAINT",
  "composer": {
    "has_composer_json": $([ -f "$REPO/composer.json" ] && echo "true" || echo "false"),
    "has_composer_lock": $([ -f "$REPO/composer.lock" ] && echo "true" || echo "false"),
    "autoload_type": "$AUTOLOAD_TYPE",
    "direct_dependency_count": $DEPENDENCY_COUNT,
    "packages": $COMPOSER_PACKAGES
  },
  "file_counts": {
    "php": $PHP_COUNT,
    "phtml": $PHTML_COUNT,
    "tpl": $TPL_COUNT,
    "blade_php": $BLADE_COUNT,
    "twig": $TWIG_COUNT,
    "js": $JS_COUNT,
    "css": $CSS_COUNT,
    "sql": $SQL_COUNT,
    "json": $JSON_COUNT,
    "xml": $XML_COUNT,
    "ini": $INI_COUNT,
    "yaml_yml": $((YAML_COUNT + YML_COUNT))
  },
  "lines_of_code": {
    "php": $PHP_LOC,
    "javascript": $JS_LOC,
    "css": $CSS_LOC,
    "sql": $SQL_LOC,
    "total": $TOTAL_LOC
  },
  "code_metrics": {
    "classes": $CLASS_COUNT,
    "interfaces": $INTERFACE_COUNT,
    "traits": $TRAIT_COUNT,
    "functions": $FUNCTION_COUNT,
    "include_require_statements": $INCLUDE_COUNT
  },
  "database_access": {
    "primary_pattern": "$DB_PATTERN",
    "pdo_usages": $PDO_USAGE,
    "mysqli_usages": $MYSQLI_USAGE,
    "mysql_legacy_usages": $MYSQL_USAGE,
    "doctrine_usages": $DOCTRINE_USAGE,
    "eloquent_usages": $ELOQUENT_USAGE,
    "raw_sql_queries": $RAW_SQL
  },
  "template_engine": "$TEMPLATE_ENGINE",
  "state_management": {
    "session_usages": $SESSION_USAGE,
    "cookie_usages": $COOKIE_USAGE
  },
  "testing": {
    "framework": "$TEST_FRAMEWORK",
    "test_file_count": $TEST_COUNT
  },
  "security_concerns": {
    "total_flags": $SECURITY_FLAGS,
    "eval_calls": $EVAL_COUNT,
    "unserialize_calls": $UNSERIALIZE_COUNT,
    "exec_system_calls": $EXEC_COUNT,
    "deprecated_mysql_calls": $MYSQL_DEPRECATED_COUNT,
    "superglobal_in_sql_or_include": $FILE_INCLUDE_VULN,
    "raw_superglobal_access": $SQL_CONCAT_COUNT
  }
}
EOF
