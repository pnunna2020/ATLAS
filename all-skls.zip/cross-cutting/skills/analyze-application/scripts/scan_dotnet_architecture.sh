#!/bin/bash
# .NET / ASP.NET WebForms Architecture Scanner
# Scans a .NET project directory and outputs a JSON architecture fingerprint.
#
# Usage: ./scan_dotnet_architecture.sh <repo_path>
#
# Detects:
#   - File counts by type (.aspx, .ascx, .master, .asmx, .svc, .csproj)
#   - .NET Framework version from .csproj files
#   - NuGet packages from packages.config and .csproj PackageReference
#   - Lines of code per file type
#   - ViewState usage patterns
#   - Entity Framework version and usage style
#   - Authentication pattern from web.config
#   - Solution structure and project references

set -euo pipefail

REPO="${1:-}"
if [ -z "$REPO" ]; then
    echo "Usage: ./scan_dotnet_architecture.sh <repo_path>" >&2
    exit 1
fi

if [ ! -d "$REPO" ]; then
    echo "Error: Directory '$REPO' does not exist" >&2
    exit 1
fi

# --- Helper Functions ---

count_files() {
    local pattern="$1"
    find "$REPO" -type f -iname "$pattern" \
        -not -path "*/bin/*" \
        -not -path "*/obj/*" \
        -not -path "*/packages/*" \
        -not -path "*/.vs/*" \
        -not -path "*/node_modules/*" \
        2>/dev/null | wc -l | tr -d ' '
}

count_lines() {
    local pattern="$1"
    find "$REPO" -type f -iname "$pattern" \
        -not -path "*/bin/*" \
        -not -path "*/obj/*" \
        -not -path "*/packages/*" \
        -not -path "*/.vs/*" \
        2>/dev/null -exec cat {} + 2>/dev/null | wc -l | tr -d ' '
}

escape_json() {
    echo "$1" | sed 's/\\/\\\\/g; s/"/\\"/g; s/\t/\\t/g' | tr '\n' ' '
}

# --- File Counts ---

ASPX_COUNT=$(count_files "*.aspx")
ASPX_CS_COUNT=$(count_files "*.aspx.cs")
ASPX_VB_COUNT=$(count_files "*.aspx.vb")
ASCX_COUNT=$(count_files "*.ascx")
MASTER_COUNT=$(count_files "*.master")
ASMX_COUNT=$(count_files "*.asmx")
SVC_COUNT=$(count_files "*.svc")
ASHX_COUNT=$(count_files "*.ashx")
CSPROJ_COUNT=$(count_files "*.csproj")
VBPROJ_COUNT=$(count_files "*.vbproj")
SLN_COUNT=$(count_files "*.sln")
CONFIG_COUNT=$(count_files "web.config")
EDMX_COUNT=$(count_files "*.edmx")
DBML_COUNT=$(count_files "*.dbml")
XSD_COUNT=$(count_files "*.xsd")
TT_COUNT=$(count_files "*.tt")
RESX_COUNT=$(count_files "*.resx")

# --- Primary Language Detection ---

CS_FILE_COUNT=$(count_files "*.cs")
VB_FILE_COUNT=$(count_files "*.vb")
if [ "$CS_FILE_COUNT" -ge "$VB_FILE_COUNT" ]; then
    PRIMARY_LANG="C#"
else
    PRIMARY_LANG="VB.NET"
fi

# --- Lines of Code ---

CS_LOC=$(count_lines "*.cs")
VB_LOC=$(count_lines "*.vb")
ASPX_LOC=$(count_lines "*.aspx")
ASCX_LOC=$(count_lines "*.ascx")
SQL_LOC=$(count_lines "*.sql")
JS_LOC=$(count_lines "*.js")
TOTAL_LOC=$((CS_LOC + VB_LOC + ASPX_LOC + ASCX_LOC + SQL_LOC + JS_LOC))

# --- .NET Framework Version Detection ---

DOTNET_VERSION="unknown"
FIRST_CSPROJ=$(find "$REPO" -type f -iname "*.csproj" \
    -not -path "*/packages/*" -not -path "*/bin/*" 2>/dev/null | head -1)
if [ -n "$FIRST_CSPROJ" ]; then
    # Try TargetFrameworkVersion (old-style .csproj)
    VERSION=$(grep -oP '<TargetFrameworkVersion>\K[^<]+' "$FIRST_CSPROJ" 2>/dev/null || true)
    if [ -n "$VERSION" ]; then
        DOTNET_VERSION="$VERSION"
    else
        # Try TargetFramework (SDK-style .csproj)
        VERSION=$(grep -oP '<TargetFramework>\K[^<]+' "$FIRST_CSPROJ" 2>/dev/null || true)
        if [ -n "$VERSION" ]; then
            DOTNET_VERSION="$VERSION"
        fi
    fi
fi

# --- NuGet Package Extraction ---

NUGET_PACKAGES="[]"

# Check packages.config files
PACKAGES_CONFIG=$(find "$REPO" -type f -name "packages.config" \
    -not -path "*/bin/*" -not -path "*/obj/*" 2>/dev/null | head -1)
if [ -n "$PACKAGES_CONFIG" ]; then
    NUGET_PACKAGES=$(grep -oP 'id="\K[^"]+' "$PACKAGES_CONFIG" 2>/dev/null | \
        sort -u | \
        awk 'BEGIN{printf "["} NR>1{printf ","} {printf "\"%s\"", $0} END{printf "]"}')
fi

# If no packages.config, check .csproj for PackageReference
if [ "$NUGET_PACKAGES" = "[]" ] && [ -n "$FIRST_CSPROJ" ]; then
    PKG_REFS=$(grep -oP '<PackageReference Include="\K[^"]+' "$FIRST_CSPROJ" 2>/dev/null | \
        sort -u | \
        awk 'BEGIN{printf "["} NR>1{printf ","} {printf "\"%s\"", $0} END{printf "]"}')
    if [ -n "$PKG_REFS" ] && [ "$PKG_REFS" != "[]" ]; then
        NUGET_PACKAGES="$PKG_REFS"
    fi
fi

# --- Entity Framework Detection ---

EF_VERSION="none"
EF_PATTERN="none"

# Check for EF6 in packages.config
if [ -n "$PACKAGES_CONFIG" ]; then
    EF_VER=$(grep -oP 'id="EntityFramework" version="\K[^"]+' "$PACKAGES_CONFIG" 2>/dev/null || true)
    if [ -n "$EF_VER" ]; then
        EF_VERSION="$EF_VER"
    fi
fi

# Check for EF Core in .csproj
if [ -n "$FIRST_CSPROJ" ]; then
    EF_CORE_VER=$(grep -oP 'Include="Microsoft.EntityFrameworkCore" Version="\K[^"]+' \
        "$FIRST_CSPROJ" 2>/dev/null || true)
    if [ -n "$EF_CORE_VER" ]; then
        EF_VERSION="Core $EF_CORE_VER"
    fi
fi

# Determine EF usage pattern
if [ "$EDMX_COUNT" -gt 0 ]; then
    EF_PATTERN="database-first"
elif grep -rq "DbContext" "$REPO" --include="*.cs" \
    --exclude-dir=bin --exclude-dir=obj --exclude-dir=packages 2>/dev/null; then
    EF_PATTERN="code-first"
elif [ "$DBML_COUNT" -gt 0 ]; then
    EF_PATTERN="linq-to-sql"
elif grep -rq "SqlCommand\|SqlConnection\|SqlDataAdapter" "$REPO" --include="*.cs" \
    --exclude-dir=bin --exclude-dir=obj --exclude-dir=packages 2>/dev/null; then
    EF_PATTERN="raw-ado-net"
fi

# --- ViewState Analysis ---

VIEWSTATE_ENABLED="true"
VIEWSTATE_ENCRYPTION="Auto"
VIEWSTATE_DISABLED_PAGES=0

# Check web.config for global ViewState settings
MAIN_WEB_CONFIG=$(find "$REPO" -maxdepth 2 -type f -name "web.config" 2>/dev/null | head -1)
if [ -n "$MAIN_WEB_CONFIG" ]; then
    VS_ENABLED=$(grep -oP 'enableViewState="\K[^"]+' "$MAIN_WEB_CONFIG" 2>/dev/null || true)
    if [ "$VS_ENABLED" = "false" ]; then
        VIEWSTATE_ENABLED="false"
    fi
    VS_ENCRYPT=$(grep -oP 'viewStateEncryptionMode="\K[^"]+' "$MAIN_WEB_CONFIG" 2>/dev/null || true)
    if [ -n "$VS_ENCRYPT" ]; then
        VIEWSTATE_ENCRYPTION="$VS_ENCRYPT"
    fi
fi

# Count pages that disable ViewState
VIEWSTATE_DISABLED_PAGES=$(grep -rl 'EnableViewState="false"\|EnableViewState = false' \
    "$REPO" --include="*.aspx" --include="*.cs" \
    --exclude-dir=bin --exclude-dir=obj 2>/dev/null | wc -l | tr -d ' ')

# --- Authentication Detection ---

AUTH_TYPE="unknown"
USES_ROLES="false"

if [ -n "$MAIN_WEB_CONFIG" ]; then
    # Check authentication mode
    AUTH_MODE=$(grep -oP '<authentication mode="\K[^"]+' "$MAIN_WEB_CONFIG" 2>/dev/null || true)
    case "$AUTH_MODE" in
        Forms) AUTH_TYPE="FormsAuth" ;;
        Windows) AUTH_TYPE="WindowsAuth" ;;
        None) AUTH_TYPE="None" ;;
        *) AUTH_TYPE="unknown" ;;
    esac

    # Check for Membership provider
    if grep -q "<membership" "$MAIN_WEB_CONFIG" 2>/dev/null; then
        AUTH_TYPE="Membership"
    fi

    # Check for ASP.NET Identity (OWIN)
    if grep -rq "Microsoft.AspNet.Identity\|UserManager\|SignInManager" "$REPO" \
        --include="*.cs" --include="*.config" \
        --exclude-dir=bin --exclude-dir=obj --exclude-dir=packages 2>/dev/null; then
        AUTH_TYPE="Identity"
    fi

    # Check for role management
    if grep -q "<roleManager enabled=\"true\"" "$MAIN_WEB_CONFIG" 2>/dev/null; then
        USES_ROLES="true"
    fi
    if grep -rq "User.IsInRole\|Roles.IsUserInRole\|[Authorize(Roles" "$REPO" \
        --include="*.cs" --exclude-dir=bin --exclude-dir=obj 2>/dev/null; then
        USES_ROLES="true"
    fi
fi

# --- Session State Detection ---

SESSION_MODE="InProc"
if [ -n "$MAIN_WEB_CONFIG" ]; then
    SESS_MODE=$(grep -oP '<sessionState mode="\K[^"]+' "$MAIN_WEB_CONFIG" 2>/dev/null || true)
    if [ -n "$SESS_MODE" ]; then
        SESSION_MODE="$SESS_MODE"
    fi
fi

# Count session variable usage
SESSION_USAGE_COUNT=$(grep -rc 'Session\[' "$REPO" --include="*.cs" --include="*.vb" \
    --exclude-dir=bin --exclude-dir=obj --exclude-dir=packages 2>/dev/null | \
    awk -F: '{s+=$2} END{print s+0}')

# --- Third-Party Control Detection ---

THIRD_PARTY_VENDOR="none"
THIRD_PARTY_COUNT=0

if grep -rq "Telerik.Web.UI\|telerik:Rad" "$REPO" \
    --include="*.aspx" --include="*.ascx" --include="*.config" --include="*.cs" \
    --exclude-dir=bin --exclude-dir=obj --exclude-dir=packages 2>/dev/null; then
    THIRD_PARTY_VENDOR="Telerik"
    THIRD_PARTY_COUNT=$(grep -rc "telerik:Rad" "$REPO" --include="*.aspx" --include="*.ascx" \
        --exclude-dir=bin --exclude-dir=obj 2>/dev/null | \
        awk -F: '{s+=$2} END{print s+0}')
elif grep -rq "DevExpress.Web\|dx:ASPx" "$REPO" \
    --include="*.aspx" --include="*.ascx" --include="*.config" --include="*.cs" \
    --exclude-dir=bin --exclude-dir=obj --exclude-dir=packages 2>/dev/null; then
    THIRD_PARTY_VENDOR="DevExpress"
    THIRD_PARTY_COUNT=$(grep -rc "dx:ASPx" "$REPO" --include="*.aspx" --include="*.ascx" \
        --exclude-dir=bin --exclude-dir=obj 2>/dev/null | \
        awk -F: '{s+=$2} END{print s+0}')
elif grep -rq "Infragistics.Web\|ig:Web" "$REPO" \
    --include="*.aspx" --include="*.ascx" --include="*.config" --include="*.cs" \
    --exclude-dir=bin --exclude-dir=obj --exclude-dir=packages 2>/dev/null; then
    THIRD_PARTY_VENDOR="Infragistics"
    THIRD_PARTY_COUNT=$(grep -rc "ig:Web" "$REPO" --include="*.aspx" --include="*.ascx" \
        --exclude-dir=bin --exclude-dir=obj 2>/dev/null | \
        awk -F: '{s+=$2} END{print s+0}')
fi

# --- UpdatePanel Count ---

UPDATE_PANEL_COUNT=$(grep -rc "UpdatePanel\|asp:UpdatePanel" "$REPO" \
    --include="*.aspx" --include="*.ascx" \
    --exclude-dir=bin --exclude-dir=obj 2>/dev/null | \
    awk -F: '{s+=$2} END{print s+0}')

# --- Project Reference Count ---

PROJECT_REF_COUNT=0
if [ -n "$FIRST_CSPROJ" ]; then
    PROJECT_REF_COUNT=$(grep -c "ProjectReference" "$FIRST_CSPROJ" 2>/dev/null || echo "0")
fi

# --- Binding Redirect Count ---

BINDING_REDIRECT_COUNT=0
if [ -n "$MAIN_WEB_CONFIG" ]; then
    BINDING_REDIRECT_COUNT=$(grep -c "bindingRedirect" "$MAIN_WEB_CONFIG" 2>/dev/null || echo "0")
fi

# --- IIS URL Rewrite Rules ---

URL_REWRITE_COUNT=0
if [ -n "$MAIN_WEB_CONFIG" ]; then
    URL_REWRITE_COUNT=$(grep -c "<rule " "$MAIN_WEB_CONFIG" 2>/dev/null || echo "0")
fi

# --- Custom HTTP Handlers and Modules ---

CUSTOM_HANDLER_COUNT=0
CUSTOM_MODULE_COUNT=0
if [ -n "$MAIN_WEB_CONFIG" ]; then
    CUSTOM_HANDLER_COUNT=$(grep -c '<add.*type=.*Handler' "$MAIN_WEB_CONFIG" 2>/dev/null || echo "0")
    CUSTOM_MODULE_COUNT=$(grep -c '<add.*type=.*Module' "$MAIN_WEB_CONFIG" 2>/dev/null || echo "0")
fi

# --- Code-Behind Size Analysis ---

MAX_CB_LINES=0
TOTAL_CB_LINES=0
CB_FILE_COUNT=0

while IFS= read -r file; do
    if [ -f "$file" ]; then
        LINES=$(wc -l < "$file" 2>/dev/null | tr -d ' ')
        TOTAL_CB_LINES=$((TOTAL_CB_LINES + LINES))
        CB_FILE_COUNT=$((CB_FILE_COUNT + 1))
        if [ "$LINES" -gt "$MAX_CB_LINES" ]; then
            MAX_CB_LINES=$LINES
        fi
    fi
done < <(find "$REPO" -type f \( -iname "*.aspx.cs" -o -iname "*.aspx.vb" \) \
    -not -path "*/bin/*" -not -path "*/obj/*" 2>/dev/null)

AVG_CB_LINES=0
if [ "$CB_FILE_COUNT" -gt 0 ]; then
    AVG_CB_LINES=$((TOTAL_CB_LINES / CB_FILE_COUNT))
fi

# --- AppSettings Count ---

APP_SETTINGS_COUNT=0
if [ -n "$MAIN_WEB_CONFIG" ]; then
    APP_SETTINGS_COUNT=$(grep -c '<add key=' "$MAIN_WEB_CONFIG" 2>/dev/null || echo "0")
fi

# --- Connection String Count ---

CONN_STRING_COUNT=0
if [ -n "$MAIN_WEB_CONFIG" ]; then
    CONN_STRING_COUNT=$(grep -c '<add name=.*connectionString=' "$MAIN_WEB_CONFIG" 2>/dev/null || echo "0")
fi

# --- Output JSON ---

cat <<EOF
{
  "repo_path": "$(escape_json "$REPO")",
  "scan_date": "$(date -u +%Y-%m-%dT%H:%M:%SZ)",
  "primary_language": "$PRIMARY_LANG",
  "dotnet_version": "$DOTNET_VERSION",
  "file_counts": {
    "aspx_pages": $ASPX_COUNT,
    "aspx_cs_codebehind": $ASPX_CS_COUNT,
    "aspx_vb_codebehind": $ASPX_VB_COUNT,
    "ascx_user_controls": $ASCX_COUNT,
    "master_pages": $MASTER_COUNT,
    "asmx_web_services": $ASMX_COUNT,
    "svc_wcf_services": $SVC_COUNT,
    "ashx_handlers": $ASHX_COUNT,
    "csproj_files": $CSPROJ_COUNT,
    "vbproj_files": $VBPROJ_COUNT,
    "sln_files": $SLN_COUNT,
    "web_config_files": $CONFIG_COUNT,
    "edmx_files": $EDMX_COUNT,
    "dbml_files": $DBML_COUNT,
    "xsd_typed_datasets": $XSD_COUNT,
    "tt_templates": $TT_COUNT,
    "resx_resources": $RESX_COUNT,
    "cs_files": $CS_FILE_COUNT,
    "vb_files": $VB_FILE_COUNT
  },
  "lines_of_code": {
    "csharp": $CS_LOC,
    "vbnet": $VB_LOC,
    "aspx_markup": $ASPX_LOC,
    "ascx_markup": $ASCX_LOC,
    "sql": $SQL_LOC,
    "javascript": $JS_LOC,
    "total": $TOTAL_LOC
  },
  "code_behind_analysis": {
    "file_count": $CB_FILE_COUNT,
    "max_lines": $MAX_CB_LINES,
    "avg_lines": $AVG_CB_LINES,
    "total_lines": $TOTAL_CB_LINES
  },
  "data_access": {
    "ef_version": "$EF_VERSION",
    "ef_pattern": "$EF_PATTERN",
    "edmx_models": $EDMX_COUNT,
    "dbml_models": $DBML_COUNT,
    "typed_datasets": $XSD_COUNT,
    "connection_strings": $CONN_STRING_COUNT
  },
  "state_management": {
    "viewstate_enabled": $VIEWSTATE_ENABLED,
    "viewstate_encryption": "$VIEWSTATE_ENCRYPTION",
    "viewstate_disabled_pages": $VIEWSTATE_DISABLED_PAGES,
    "session_mode": "$SESSION_MODE",
    "session_variable_usages": $SESSION_USAGE_COUNT
  },
  "authentication": {
    "type": "$AUTH_TYPE",
    "uses_roles": $USES_ROLES
  },
  "third_party_controls": {
    "vendor": "$THIRD_PARTY_VENDOR",
    "control_instances": $THIRD_PARTY_COUNT
  },
  "ajax_patterns": {
    "update_panel_instances": $UPDATE_PANEL_COUNT
  },
  "nuget_packages": $NUGET_PACKAGES,
  "iis_dependencies": {
    "url_rewrite_rules": $URL_REWRITE_COUNT,
    "custom_handlers": $CUSTOM_HANDLER_COUNT,
    "custom_modules": $CUSTOM_MODULE_COUNT
  },
  "configuration": {
    "app_settings_count": $APP_SETTINGS_COUNT,
    "connection_string_count": $CONN_STRING_COUNT,
    "binding_redirects": $BINDING_REDIRECT_COUNT
  },
  "solution_structure": {
    "projects_in_solution": $CSPROJ_COUNT,
    "project_references_from_web": $PROJECT_REF_COUNT
  }
}
EOF
