---
name: analyze-application
description: >
  Perform comprehensive 4-pass analysis on a legacy FAA application: Architecture,
  Business Logic, Data/Integration, and UX. Use at P0.3 for deep analysis,
  business capability mapping, and TCO baselining. Triggers on application
  analysis, legacy assessment, 4-pass analysis, codebase analysis, or
  @analyze-application mentions.
disable-model-invocation: true
agent: opus
allowed-tools:
  - Read
  - Write
  - Bash
  - Grep
---

# 4-Pass Application Analysis

## Purpose
The foundation of the entire factory pipeline. Every downstream decision —
disposition, architecture, extraction, generation — depends on the quality
of this analysis. Get this wrong and everything downstream is wrong.

## 4 Passes

### Pass 1: Architecture Analysis
Understand how the application is built.
- Run `scripts/scan_architecture.sh` to detect framework, patterns, layers
- Identify: monolith vs modular, stateful vs stateless, deployment model
- Map: entry points, service boundaries, configuration sources
- Output: Architecture fingerprint JSON

### Pass 2: Business Logic Extraction
Understand what the application does.
- Scan for business rules in code (conditionals, validations, calculations)
- Map business capabilities to code modules
- Identify duplicated logic across modules
- Output: Business capability model, business rule catalog

### Pass 3: Data & Integration Analysis
Understand what data flows where.
- Map all database access patterns (queries, stored procs, ORM mappings)
- Identify all integration points (APIs, files, messaging, batch feeds)
- Classify data by domain (per data mesh methodology)
- Output: Data domain map, integration inventory, DB coupling analysis

### Pass 4: UX & User Journey Analysis
Understand who uses it and how.
- Map all user-facing screens/pages/views
- Identify user workflows (sequences of actions)
- Detect fragmented or duplicative journeys
- Estimate active user count and usage patterns
- Output: User journey map, fragmented journey analysis, adoption baseline

## Gotchas
- **Don't analyze in a single session**: Each pass should be a separate Claude
  Code session to avoid context window exhaustion. Use git worktrees.
- **ColdFusion apps hide logic in CFCs**: Business rules in ColdFusion are
  often buried in CFC method chains. Check `references/coldfusion-patterns.md`.
- **Oracle stored procedures ARE business logic**: Don't skip PL/SQL analysis.
  Some FAA apps have 60%+ of their business logic in the database layer.
- **Batch jobs are invisible**: Batch jobs often have no UI and only appear in
  cron configs or Oracle DBMS_SCHEDULER. Always check for scheduled jobs.
- **TCO baseline requires infrastructure data**: Application code analysis alone
  won't give you TCO. You need hosting costs (from AWS Cost Explorer or infra
  team), O&M labor allocation, and licensing costs.

## Reference Files
- `references/coldfusion-patterns.md` — ColdFusion-specific analysis patterns
- `references/java-ee-patterns.md` — Java EE analysis patterns
- `references/cobol-patterns.md` — COBOL analysis patterns (mainframe CICS/DB2/IMS/batch)
- `references/legacy-js-patterns.md` — jQuery and legacy JS frontend analysis patterns
- `references/batch-job-detection.md` — How to find and catalog batch jobs

## Output Templates
- `assets/architecture-fingerprint-template.json`
- `assets/business-rule-catalog-template.md`
- `assets/analysis-report-template.md`

## Quality Rules
- [ ] Pass 1 (Architecture): Architecture fingerprint JSON is schema-valid and includes framework, language version, deployment model, and all entry points
- [ ] Pass 1 (Architecture): Every identified module has at least one dependency mapped with direction (inbound/outbound)
- [ ] Pass 2 (Business Logic): Business rule catalog contains at least one rule per identified module — gaps indicate incomplete extraction
- [ ] Pass 2 (Business Logic): Each business rule has a source citation in `{file}:{line}` format traceable to the repository
- [ ] Pass 3 (Data & Integration): All database access patterns are classified (direct SQL, ORM, stored proc, trigger) with table-level lineage
- [ ] Pass 3 (Data & Integration): Integration inventory covers all external touchpoints including batch feeds, file drops, and message queues — not just REST APIs
- [ ] Pass 4 (UX): Every user-facing screen is cataloged with its primary user role and workflow context
- [ ] Pass 4 (UX): Fragmented journey analysis identifies at least one consolidation opportunity or explicitly documents why none exist
- [ ] Cross-pass: All four pass outputs reference a consistent module/component naming scheme
- [ ] Cross-pass: TCO baseline includes hosting, O&M labor, and licensing — not just infrastructure costs

## Common Failure Modes
| Failure Mode | Symptom | Prevention |
|-------------|---------|------------|
| Single-session analysis | Context window exhaustion mid-pass; shallow findings in later passes | Run each pass in a separate Claude Code session using git worktrees |
| Skipped database layer | Business rule catalog has no stored procedure or trigger references | Always run Pass 3 data analysis; check PL/SQL, T-SQL, and trigger definitions explicitly |
| Missing batch jobs | Integration inventory lists only web endpoints; scheduled processes absent | Check cron configs, DBMS_SCHEDULER, Windows Task Scheduler, and CI/CD pipelines for scheduled jobs |
| Overcounting modules | Architecture fingerprint lists directories as modules without verifying decoupling | Validate module boundaries with dependency analysis — shared state or circular imports mean they are not separate modules |
| TCO without infrastructure data | TCO baseline only reflects developer estimates, not actual hosting and licensing costs | Request AWS Cost Explorer exports or infra team cost allocation before completing Pass 3 |

## Handoff Summary
When this skill completes, verify:
1. All four pass outputs exist and are internally consistent (shared module naming, no contradictions)
2. Architecture fingerprint JSON validates against the schema in `assets/architecture-fingerprint-template.json`
3. Business rule catalog has full `{file}:{line}` traceability for every rule
4. TCO baseline includes all three cost categories (hosting, O&M, licensing)
Then proceed to: `disposition-recommender` (Rationalization Step 3) and `legacy-architecture-mapper` (for decomposition boundary refinement)

## Oracle EBS Detection
Oracle E-Business Suite applications have a distinct footprint that differs substantially from custom Oracle database applications. Detect early so the analysis loads EBS-specific patterns instead of treating the codebase as generic PL/SQL.

### Detection Heuristics
Any two or more of the following should route analysis to the EBS pattern reference:

- FND_ / AR_ / AP_ / GL_ / PO_ / INV_ / HR_ schema prefixes in discovered DDL (FND = Foundation, AR = Receivables, AP = Payables, GL = General Ledger, PO = Purchasing, INV = Inventory, HR = Human Resources)
- `.fmb` or `.fmx` files (Oracle Forms source and compiled binaries)
- `.rdf` files (Oracle Reports definitions)
- `.wft` files (Oracle Workflow Builder definitions)
- XML Publisher `.xdo` templates (data templates and layout templates for BI Publisher)
- AOL (Application Object Library) setup patterns — lookups, descriptive flexfields, key flexfields, value sets
- Concurrent program registrations in `FND_CONCURRENT_PROGRAMS` / `FND_EXECUTABLES`
- EBS profile options (`FND_PROFILE_OPTIONS`, `FND_PROFILE_OPTION_VALUES`) driving application behavior

### Dispatch Rule
When 2 or more heuristics match, route downstream analysis steps to `cross-cutting/skills/analyze-application/references/oracle-ebs-patterns.md`. When only one heuristic matches, treat as generic Oracle PL/SQL and note the EBS signal in the architecture fingerprint for follow-up confirmation.
