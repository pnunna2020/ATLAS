---
name: wave-planner
description: >
  Produce quarterly modernization wave assignments via topological-sort-with-constraints.
  Constraints: dependency ordering, shared-DB co-dependencies, risk balancing, factory
  capacity, resource availability, external immovability. Outputs wave assignments,
  critical path, resource loading, compound-growth forecast, concurrent-wave plan.
  Override register for manual adjustments. Output per `schemas/rationalization/wave-plan.schema.json`.
  Triggers on wave planning, wave sequencing, topological sort, factory schedule, or @wave-planner.
agent: opus
allowed-tools:
  - Read
  - Write
  - Grep
---

# wave-planner

## Purpose
Transform a dispositioned portfolio into an executable quarterly wave schedule by running topological-sort-with-constraints across the dependency graph, shared-DB cluster map, risk classification, and factory capacity model. Promotes Rationalization Step 7 logic out of orchestration code into a discoverable, reviewable, overridable skill so planners can audit wave assignments and approvers can sign off on manual overrides instead of black-box reshuffles.

## Inputs
- Dispositioned portfolio — all applications with validated dispositions (JSON per `schemas/rationalization/disposition-validation.schema.json`)
- Dependency graph — application-to-application edges (JSON per `schemas/rationalization/integration-graph.schema.json`)
- Shared-DB cluster map — groups of applications sharing a physical database
- Risk classification — per-application tier assignments (T1/T2/T3) from the client profile
- Factory capacity model — throughput tokens/FTE/quarter, concurrent-wave ceilings
- External interface catalog — immovable integrations (e.g., SWIM, Pay.gov, TSA NTSDB)
- Resource availability calendar — people, environments, funding by quarter
- Optional: prior wave plan (for re-plan / delta mode) and manual override register

## Outputs
- Wave plan → `schemas/rationalization/wave-plan.schema.json` and `assets/wave-plan-template.json`
- Critical-path diagram (apps, length in quarters, blocking dependencies) — embedded in wave plan
- Resource loading by quarter (factory + sustainment FTE) — embedded in wave plan
- Compound-growth forecast (expected reuse %, throughput multiplier per wave) — embedded in wave plan
- Concurrent-wave capacity plan (Wave N in Deployment, N+1 in Modernization, N+2 in Architecture) — embedded
- Override register → `assets/override-register-template.md`
- Sustainment drawdown schedule — derived from retire/replace dispositions by wave

## Methodology
1. Load all inputs and verify each application has a validated disposition — halt if any application is unresolved.
2. Build the directed dependency graph: nodes are applications, edges are `depends_on` relations. Overlay the shared-DB cluster edges as soft-same-wave constraints.
3. Detect cycles and defer to `validate-disposition` for cycle-breaking decisions — never silently drop an edge. Document each break in the override register.
4. Run Kahn's topological sort with deterministic tie-breaking: risk tier descending (T1 first within a layer), then alphabetic by `application_id`. See `references/topological-sort-algorithm.md`.
5. Pack applications into waves of 15–30 apps subject to factory capacity, applying the constraint-resolution priority order from `references/constraint-resolution.md` when constraints conflict.
6. Balance risk per wave — no wave may exceed the T1 ceiling from the factory capacity model. Rebalance by promoting/demoting at layer boundaries only.
7. Mark external-integration-bound apps as immovable per `references/external-immovability.md`; schedule dependent apps around those anchors.
8. Compute critical path (longest dependency chain through the graph) and record length in quarters plus the ordered list of apps and blocking edges.
9. Generate the compound-growth forecast per `references/compound-growth-forecast.md` (Wave 1 baseline, escalating reuse and throughput through Wave 6+).
10. Produce the concurrent-wave orchestration table per `references/concurrent-wave-orchestration.md`, compute per-quarter resource loading, serialize to the wave-plan schema, and attach the override register.

## Gotchas
- **Cycles must be broken before sort, not during.** Kahn's algorithm silently stalls on cycles; a skipped node becomes an invisible dropped dependency downstream. Always run cycle detection as a precondition and route breaks through `validate-disposition`.
- **Shared-DB clusters are NOT hard same-wave constraints.** They are "same or adjacent wave" preferences. A cluster of 40 apps cannot fit in one wave of 30. Split along the weakest intra-cluster coupling, not arbitrarily.
- **Risk balancing fights capacity.** Spreading T1 apps thin inflates wave count; clustering them busts the T1 ceiling. The constraint priority in `references/constraint-resolution.md` is load-bearing — do not reorder without governance approval.
- **External immovability is a hard constraint, not a preference.** SWIM, Pay.gov, ICAO interfaces cannot be rescheduled around internal convenience. Anchor these first, then sort the rest.
- **Compound-growth forecast is a projection, not a guarantee.** Wave 1 actuals should be used to recalibrate the curve before Wave 2 commits resources. A Wave 1 that underperforms baseline is a signal to revise, not to plow ahead.
- **Overrides without justification are wave-shuffles in disguise.** Every override must carry ≥20-character justification and a named approver, else the plan is not reproducible.
- **15–30 apps/wave is a sizing band, not a law.** Mission-critical T1-heavy waves may be 10–15; Retire-heavy waves may be 40+. Capacity utilization, not app count, is the binding check.

## Quality Rules
- [ ] Wave plan validates against `schemas/rationalization/wave-plan.schema.json` with zero errors.
- [ ] Every application in the dispositioned portfolio appears in exactly one wave (no duplicates, no omissions).
- [ ] Critical path is explicitly computed via longest-path traversal — not estimated or guessed — with `length_quarters` and ordered `apps_in_path`.
- [ ] Every wave satisfies the no-dependency-violation property: for every app A in wave N, all apps A depends on are in wave ≤ N.
- [ ] Risk balancing is checked: no wave exceeds the T1 ceiling defined in the factory capacity model.
- [ ] Factory capacity check: `capacity_utilization` ≤ 1.0 for every wave (≤ 1.5 permitted only with documented override).
- [ ] Shared-DB co-dependencies are in the same or adjacent waves; each violation has a justified override entry.
- [ ] External-immovability anchors are honored — no app scheduled before its external-integration window opens.
- [ ] Compound-growth forecast is produced with per-wave `expected_reuse_pct`, `throughput_multiplier`, and `rationale`.
- [ ] Every entry in the override register has `justification` ≥ 20 characters and a named `approver`.

## Common Failure Modes
| Failure Mode | Symptom | Prevention |
|---|---|---|
| Circular dependency not broken before sort | Topological sort silently omits apps in the cycle; downstream waves reference missing predecessors | Run cycle detection as a precondition; route every cycle-break through `validate-disposition` and log it in the override register |
| Overrides without justification | Wave plan appears adjusted but reviewers cannot tell why; audit trail breaks | Enforce the ≥20-char justification and named-approver fields at serialization time; fail validation on empty fields |
| Shared-DB cluster forced into one wave | Single wave balloons past factory capacity; downstream waves starved | Treat shared-DB as "same or adjacent wave"; split clusters at weakest coupling edges, not arbitrarily |
| Risk ceiling busted to hit capacity targets | Wave looks productive but is T1-heavy; quality gates stall the whole wave | Enforce T1 ceiling from factory capacity model before packing; promote/demote at layer boundaries only |
| External integration rescheduled around internal convenience | Plan commits a wave that cannot deploy because the external counterparty window is closed | Anchor external-immovability nodes first; sort all other apps around those anchors |
| Compound-growth forecast accepted as fact | Wave 2 over-commits resources assuming 30–40% reuse that never materialized | Recalibrate the curve from Wave 1 actuals before committing Wave 2; treat the forecast as a hypothesis until measured |

## Handoff Summary
When this skill completes, verify:
1. Wave plan JSON validates against `schemas/rationalization/wave-plan.schema.json`, every app appears in exactly one wave, and no wave violates dependency ordering.
2. Critical path is explicitly computed (apps listed, length in quarters recorded) and risk-ceiling and capacity-utilization checks pass for every wave.
3. Override register has a justified, approved entry for every manual adjustment and every cycle-break.

Then proceed to: `factory-scheduler` for per-wave backlog planning and capacity allocation, and gate `G-RR` (Rationalization Review) for portfolio-level sequencing sign-off.
