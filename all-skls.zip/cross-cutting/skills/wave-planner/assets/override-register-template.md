# Wave Plan Override Register

Every manual adjustment to the topologically-sorted wave plan MUST be recorded here before the plan is accepted.

## Fields (all required)

- `application_id` — canonical application identifier from the catalog
- `original_wave` — wave number produced by the unaltered topological sort
- `overridden_to_wave` — wave the application is being reassigned to
- `justification` — minimum 20 characters; explain the constraint, risk, or business reason driving the override
- `approver` — named individual with authority to approve wave assignment changes (not a group mailbox)

## Usage

- One row per override. Do not batch multiple applications into one row.
- Cycle-breaks routed through `validate-disposition` also belong here — record the broken edge in the `justification` field.
- Approver must be recorded at override time, not after the fact.
- Empty or sub-20-character justifications fail validation.

## Register

| application_id | original_wave | overridden_to_wave | justification | approver |
|---|---|---|---|---|
| TODO-APP-ID | 0 | 0 | TODO — minimum 20 characters explaining the override reason (external integration window, risk concentration, resource conflict, dependency cycle break, etc.) | TODO-Name |

## Audit notes

- This register is consumed by the Rationalization gate review (`G-RR`).
- Reviewers MUST confirm each entry has a plausible justification and an identifiable approver.
- Overrides that move an app across more than two wave boundaries require a second approver signature appended to the justification.
