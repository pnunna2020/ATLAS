# Concurrent Wave Orchestration — Multiple Waves in Flight

Waves do not run sequentially. By design, several are in flight at once, each in a different assembly-line phase. Steady-state:

```
Quarter Q:   Wave N   in Deployment
             Wave N+1 in Modernization (Extract -> Design -> Generate)
             Wave N+2 in Architecture
             Wave N+3 in Rationalization (optional)
```

This pipelines work to keep the factory saturated and feed compound-growth reuse forward.

## Phase handoffs

- Architecture -> Modernization: target architecture and decomposition boundaries for Wave N+2 done; Extract begins.
- Modernization -> Deployment: Wave N+1 passes `G-V2`; deployment planning starts.
- Deployment -> Sustainment: Wave N goes live; sustainment owners take operations; factory recycles to Wave N+3.

## Capacity calculation

Per quarter, total FTE demand = sum over in-flight waves of (app count × phase FTE coefficient). Nominal:

- Architecture: 0.05 FTE/app/quarter
- Modernization: 0.20 FTE/app/quarter (heaviest)
- Deployment: 0.08 FTE/app/quarter
- Sustainment (drawdown): 0.03 FTE/app/quarter

Factory capacity must cover PEAK quarterly FTE, not average. A plan that fits in principle but exceeds peak will stall.

## Handoff checkpoints

Each phase transition is a quality gate with binary accept/reject. Concurrent waves DO NOT hide regressions — a Wave N deployment failure pauses Wave N+1 modernization for the same archetype until root cause is known.

## Shared-library freeze windows

When Wave N enters Deployment, the libraries it depends on freeze. Wave N+1 may consume those libs but cannot modify them until Wave N clears production. Library evolution happens on a branch consumed by Wave N+2 Architecture.

## Typical profile

- Q1: Wave 1 Architecture only.
- Q2: Wave 1 Modernization, Wave 2 Architecture.
- Q3: Wave 1 Deployment, Wave 2 Modernization, Wave 3 Architecture.
- Q4+: steady-state three waves in flight.
