# Compound Growth Forecast — Reuse and Throughput

Wave planning projects compounding returns as reusable patterns and primitives accumulate. The baseline below is the starting hypothesis; Wave 1 actuals MUST recalibrate before Wave 2 commits.

## Baseline curve

| Wave | Reuse % | Throughput | Character |
|---|---|---|---|
| 1 | 10–20% | 1.0x | Library-building. Patterns discovered, shared libs scaffolded, CI/CD hardened. Honest floor. |
| 2–3 | 30–40% | 1.5–2.0x | Core patterns (auth, data, observability, deployment) stabilize and are reused. |
| 4–5 | 50–60% | 2.0–3.0x | Domain patterns (claims, scheduling, messaging) coalesce into the library. |
| 6+ | 70–80% | 3.0–4.0x | Mature library. Most work is composition, not origination. |

## Why the curve exists

- Wave 1 is expensive: primitives new, conventions discovered, tooling gaps filled.
- Waves 2–3 capitalize on core-primitive investment.
- Waves 4–5 benefit from domain-specific reuse unique to the client.
- Wave 6+ plateaus — marginal gains shrink even as base reuse stays high.

## Recalibration rule

After Wave 1:

1. Measure actual reuse % (modules/services reused vs. originated).
2. Measure throughput (apps-complete per quarter per FTE) vs. baseline.
3. Within ±20% of projection — keep the curve.
4. Underperform by >20% — revise Wave 2 downward; investigate before Wave 3.
5. Overperform by >20% — keep Wave 2 as planned; route buffer to sustainment drawdown.

Two successive waves of actuals are needed before the curve is locked. Single-wave variance is signal, not law.

## What breaks the curve

- Heterogeneous tech stacks (each stack is its own Wave 1).
- Staffing churn between waves (library knowledge evaporates).
- Scope creep into bespoke work that cannot be library-ized.
- No library ownership — teams fork instead of reuse.
