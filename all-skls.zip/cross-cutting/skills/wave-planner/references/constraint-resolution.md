# Constraint Resolution — Priority When Constraints Conflict

Six constraints frequently disagree. This priority order is fixed and governance-approved. Deviations require an override register entry.

## Priority order (highest first)

1. **Dependency ordering** — HARD. No app may precede its predecessor.
2. **External immovability** — HARD. SWIM, Pay.gov, TSA NTSDB anchors cannot move.
3. **Risk balancing (T1 ceiling)** — HARD. No wave exceeds the T1 ceiling from the factory capacity model.
4. **Factory capacity** — HARD. `capacity_utilization` ≤ 1.0 per wave; ≤ 1.5 only with override.
5. **Shared-DB co-dependencies** — SOFT. Same or adjacent wave. Violations require justified override.
6. **Resource availability** — SOFT. One-quarter shifts permitted with approver signature.

## Common conflicts

### Shared-DB same-wave vs. dependency ordering
Dependency ordering WINS. Shared-DB relaxes to adjacent wave. Record split in override register. Plan a data-freeze checkpoint at the wave boundary.

### Risk balancing (spread) vs. capacity (cluster)
T1 ceiling WINS. Under-utilize rather than bust the ceiling. A wave at 0.75 with correct risk mix beats 1.1 that stalls at `G-V1`.

### External immovability vs. dependency ordering
External immovability WINS (the window is physical reality). If predecessor can't finish, change the PREDECESSOR's disposition (Retire, interim Replatform) via `validate-disposition` — do NOT slip the anchor.

### Capacity vs. compound-growth forecast
Capacity is measured; forecast is projection. Capacity WINS until two waves of actuals confirm the multiplier.

### Dependency ordering vs. shared-DB cluster splitting
Split the cluster at its weakest coupling edge. Never force a cluster into one wave if that violates dependency ordering or capacity.

## Escalation

If two HARD constraints conflict and no upstream fix exists, halt planning and escalate to gate `G-RR` with the conflict documented. Do not silently relax.
