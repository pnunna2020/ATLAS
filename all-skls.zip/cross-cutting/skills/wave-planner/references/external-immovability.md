# External Immovability — Unchangeable Integration Anchors

External integrations are counterparties the program does not control. Their release calendars, schemas, and cutover windows are FIXED inputs — internal waves flow around them.

## Patterns to mark immovable

### Aviation (FAA profile)

- **SWIM (System Wide Information Management)** — NEMS/TFMS/TFDM. Versioned schemas negotiated months ahead.
- **Airlines / ANSPs via AEEC / ACARS** — carrier-specific integration windows.
- **ICAO / Eurocontrol** — months-long cutover windows with regulatory sign-off.
- **FAA-external consumers** — NOTAM, Flight Service Stations, OAG/FlightAware feeds.

### Cross-agency (federal)

- **TSA NTSDB** — security data bus; strict change windows; interagency testing.
- **Pay.gov** — Treasury-operated; Treasury's release calendar.
- **Login.gov / ID.me** — federation SLAs and breaking-change windows.
- **IRS / SSA / VA exchanges** — bilateral interagency agreements govern cadence.

### Commercial

- **Payment processors** — PCI-DSS scoped; changes require compliance review.
- **Vendor SaaS at end-of-life** — immovable the OTHER way: vanish on the vendor's schedule regardless of internal readiness.

## Encoding immovability

1. Mark app `external_immovability: true` in the catalog.
2. Attach `earliest_start_quarter` and `latest_finish_quarter`.
3. Pack into the first wave whose `end_quarter` fits inside the window.
4. If a predecessor can't finish in time, change the PREDECESSOR's disposition (Retire, interim Replatform) via `validate-disposition` — do NOT slip the anchor.
5. Record the anchor in critical path as a blocking dependency with `reason: external-immovability`.

## Review checklist

- [ ] Every immovability app has a documented anchor window.
- [ ] No anchored app scheduled outside its window.
- [ ] Blocking internal apps have a resolution path, not a wish.
- [ ] Anchors re-verified with counterparty before committing the plan.
