# Topological Sort — Kahn's Algorithm

## Input graph

- Nodes: apps with validated dispositions.
- Edges: `A -> B` means A must precede B.
- Overlays: shared-DB cluster edges (soft, same-or-adjacent wave), external-immovability anchors (hard, quarter-locked).

## Algorithm

1. Compute in-degree for every node.
2. Initialize ready-set with all in-degree-zero nodes.
3. While ready-set non-empty:
   a. Apply tie-break to pick next node.
   b. Emit into current layer.
   c. For each edge `n -> m`, decrement `in-degree[m]`; if zero, add to next ready-set.
4. If any node has non-zero in-degree at end, a cycle exists — HALT, do not skip.

Layers become topological tiers consumed by the wave packer.

## Deterministic tie-breaking

When multiple nodes are ready in one layer, pick by:

1. `risk_tier` descending — T1 before T2 before T3.
2. `complexity_tier` descending — Complex before Moderate before Simple (front-load hard work so reuse compounds).
3. `application_id` alphabetic ascending — final deterministic tiebreaker.

Deterministic ordering is MANDATORY: diff reviews must be attributable to input changes, never sort nondeterminism.

## Cycle handling — integration with `validate-disposition`

On cycle detection:

1. Extract the strongly-connected component (Tarjan's).
2. Emit SCC node list to `validate-disposition` with dependency context.
3. `validate-disposition` returns a revised disposition removing an edge, or a documented decision to break a named edge.
4. Record the break in `assets/override-register-template.md` with justification and approver.
5. Re-run Kahn's on the mutated graph.

Never silently drop an edge. Never skip cycle nodes. Uncaught cycles produce plans that look valid but drop apps downstream.

## Wave packing (post-sort)

Layers are consumed greedily into waves subject to factory capacity, T1 ceiling, shared-DB adjacency, and external-immovability anchors. See `references/constraint-resolution.md` for conflict rules.
