---
name: validate-disposition
description: >
  Automated validation of disposition recommendations before the Disposition Approval gate. Checks evidence completeness, traceability resolution, logical consistency, acyclic disposition dependency graph, and user-impact coverage for Retire/Replace/Consolidate. Output per schemas/rationalization/disposition-validation.schema.json. Triggers on disposition validation, evidence completeness check, traceability validation, or @validate-disposition.
agent: sonnet
allowed-tools:
  - Read
  - Write
  - Grep
---

# validate-disposition

## Purpose
Validate the portfolio's disposition recommendations against the five Rationalization Step 4 automated checks, producing a structured report that the Disposition Approval gate consumes. Every recommendation produced by `recommend-disposition` must pass this skill before stakeholder governance sees it. The validator is the last automated checkpoint that catches evidence gaps, dead traceability links, contradictory logic, circular disposition dependencies, and missing user-impact analysis — failures that, if they reached stakeholders, would either be silently approved or force rework after governance.

## Inputs
- Disposition recommendations for every app in scope (JSON per `schemas/rationalization/disposition.schema.json`, one per app)
- Redundancy matrix and UX overlap matrix from `analyze-portfolio-redundancy` (Rationalization Step 1)
- Portfolio scoring methodology + per-app scores from Step 2
- App-to-app dependency graph from Discovery Step 4 (JSON per `schemas/rationalization/integration-graph.schema.json`)
- Discovery Pass 1-4 analysis reports (for resolving `{repo}:{file}:{line}` citations)
- User impact analyses produced by `assess-user-impact`
- Portfolio manifest (for portfolio_id and app-ID canonicalization)

## Outputs
- Validation report → `schemas/rationalization/disposition-validation.schema.json` (fillable skeleton at `assets/disposition-validation-report-template.json`)
- Dependency graph analysis note → `assets/dependency-graph-check-template.md`
- Gate decision (`proceed-to-governance` | `return-to-recommender` | `escalate-to-portfolio-manager`) — encoded in the report's `gate_decision` field

## Methodology
1. Load all per-app disposition recommendations and normalize application IDs against the portfolio manifest. Reject the batch if any ID cannot be resolved.
2. Run the **evidence-completeness** check: for each recommendation, confirm the presence of code-findings, overlap-data, quality-metrics, business-impact, user-impact, and cost-analysis citations. Record missing evidence classes as `blocker` findings.
3. Run the **traceability-resolution** check: parse every citation string against the two citation regexes in `references/evidence-citation-formats.md`; open each `{repo}:{file}:{line}` to confirm the line exists; resolve each `{artifact}:{section}:{finding-id}` against the referenced artifact. Record unresolved citations as `blocker`; malformed-but-resolvable citations as `major`.
4. Run the **logical-consistency** check against every rule in `references/logical-consistency-checks.md`. Record contradictions as `blocker` (e.g., `Retire` with active surviving consumers) and weak-evidence confidence mismatches as `major`.
5. Run the **dependency-coherence** check using the DFS cycle detection described in `references/cycle-detection-algorithm.md`. Populate `dependency_graph_analysis.is_acyclic` and enumerate each cycle with its `dependency_type` and proposed resolution.
6. Run the **user-impact-coverage** check: every Retire, Replace, and Consolidate disposition must have affected-user counts, disrupted-journey list, training burden, transition risk, and a transition plan. Missing fields are `blocker` findings.
7. Aggregate findings into the report skeleton: set `result` per check, compute `blocker_count`, `major_count`, `minor_count`, and set `overall_result` (FAIL if any blocker; PASS_WITH_WARNINGS if majors/minors only; PASS if clean).
8. Set `gate_decision`: `return-to-recommender` when blockers exist, `proceed-to-governance` when the report is PASS or PASS_WITH_WARNINGS, `escalate-to-portfolio-manager` when cycles cannot be broken without stakeholder intervention.
9. Write the report and the dependency-graph note. Validate the JSON against `schemas/rationalization/disposition-validation.schema.json` before handoff.

## Gotchas
- **Citations can lie by resolving to the wrong line.** A `{repo}:{file}:{line}` that resolves to a blank line or a comment is a red flag — require the cited line to contain substantive content related to the finding.
- **App IDs are case-sensitive across artifacts.** `APP-001` and `app-001` are not the same in the dependency graph; canonicalize against the portfolio manifest before any check runs.
- **Cycles can hide behind transitive dependencies.** Two-node cycles are obvious; three- and four-node cycles crossing `data` and `api` edge types are not. Run DFS over the *union* of edge types, not per-type subgraphs.
- **Consolidate dispositions create a hidden dependency.** The source (absorbed) app's Retire cannot be scheduled before the target app's modernization completes — verify both apps exist in the portfolio and the target itself has a disposition.
- **User-impact checks apply even when users are few.** A Retire with five affected users still requires a transition plan; suppressing the check on small user bases hides adoption risk.
- **WARN is not a synonym for FAIL.** Cycle detections, missing citations, and contradictions must be `blocker`. Use `WARN` only for minor style or confidence-threshold violations that do not block the gate.

## Quality Rules
- [ ] Output validates against `schemas/rationalization/disposition-validation.schema.json` (validator exits clean).
- [ ] All five automated checks (`evidence-completeness`, `traceability-resolution`, `logical-consistency`, `dependency-coherence`, `user-impact-coverage`) appear in the `checks` array with a `PASS`/`FAIL`/`WARN` result — none omitted.
- [ ] Every citation in every recommendation is parsed against the two regexes in `references/evidence-citation-formats.md`; parse failures recorded as findings.
- [ ] `dependency_graph_analysis.is_acyclic` is set to a boolean, and when `false`, every cycle is enumerated with `apps_in_cycle`, `dependency_type`, and `resolution_required`.
- [ ] Every Retire, Replace, and Consolidate disposition has been checked for affected-user count, disrupted-journey list, training burden, transition risk, and transition plan — no exceptions.
- [ ] `overall_result` is `FAIL` whenever `blocker_count > 0`, and `gate_decision` is never `proceed-to-governance` when `overall_result` is `FAIL`.
- [ ] Every finding with severity `blocker` or `major` carries a non-empty `remediation` string telling the recommender what to fix.
- [ ] Every logical-consistency rule in `references/logical-consistency-checks.md` has been executed against the recommendation set and its result recorded (rule ID referenced in finding messages).
- [ ] `apps_checked`, `apps_passing`, `apps_failing` counts reconcile (passing + failing = checked) for every check in the report.
- [ ] `portfolio_id` and `validated_date` are populated; `validator_version` is recorded for reproducibility.

## Common Failure Modes
| Failure Mode | Symptom | Prevention |
|---|---|---|
| Traceability never sampled | Reports `PASS` on traceability-resolution without actually opening any cited file; downstream consumers discover broken citations during Modernization | Require the traceability check to record `apps_checked` matching the input count and to fail the check if any citation could not be resolved |
| Cycle detected but swept under WARN instead of FAIL | `dependency_graph_analysis.is_acyclic: false` but `overall_result: PASS_WITH_WARNINGS`; gate proceeds and cycles surface later as scheduling deadlocks | Hard rule: any cycle forces `dependency-coherence` to `FAIL` and `overall_result` to `FAIL` regardless of other checks |
| App-ID case drift | Recommendations use `App-001`, graph uses `APP-001`; validator reports "app not in graph" as a blocker on every app | Canonicalize all IDs via the portfolio manifest before any check runs; fail the batch loudly if manifest lookup fails |
| Missing user-impact treated as minor | Retire with no transition plan gets `minor` severity; stakeholders approve without realizing | Hard-code user-impact-coverage gaps on Retire/Replace/Consolidate as `blocker` severity |
| Evidence count without evidence quality | Validator confirms six citation strings exist but never checks that they resolve or match the claim; shallow pass | Every citation must parse, resolve, and cite content relevant to the claim — not just exist |
| Confidence inflation unchecked | Recommendation declares `confidence: high` with one citation; no rule enforces evidence-to-confidence ratio | Apply rule-of-thumb thresholds in `references/logical-consistency-checks.md` and flag `major` findings when confidence exceeds evidence support |

## References
- `references/evidence-citation-formats.md` — regexes for `{artifact}:{section}:{finding-id}` and `{repo}:{file}:{line}`, plus the common mistakes the validator must catch.
- `references/logical-consistency-checks.md` — rule IDs LC-01 through LC-08 that the logical-consistency check enforces.
- `references/cycle-detection-algorithm.md` — DFS-with-recursion-stack algorithm and cycle-breaking options for the dependency-coherence check.

## Assets
- `assets/disposition-validation-report-template.json` — fillable skeleton matching `schemas/rationalization/disposition-validation.schema.json`.
- `assets/dependency-graph-check-template.md` — worksheet for recording cycle detection results, DOT-format graph snippet, and proposed cycle-breaking strategies.

## Handoff Summary
When this skill completes, verify:
1. The validation report validates against `schemas/rationalization/disposition-validation.schema.json` and all five checks are present.
2. `dependency_graph_analysis.is_acyclic` is set, and if `false`, every cycle has a documented `resolution_required`.
3. Retire, Replace, and Consolidate dispositions all passed the user-impact-coverage check or are listed as blocker findings.
4. `gate_decision` matches `overall_result` (no `proceed-to-governance` on a FAIL report).

Then proceed to: the Disposition Approval gate for stakeholder governance when the report is `PASS` or `PASS_WITH_WARNINGS`; otherwise return findings to `recommend-disposition` for rework. Gate: **Disposition Approval Gate** (Rationalization Step 4).
