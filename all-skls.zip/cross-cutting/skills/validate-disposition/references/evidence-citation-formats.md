# Evidence Citation Formats

Parse every citation string against one of these two regexes before resolving it.

## 1. Inter-artifact — `{artifact}:{section}:{finding-id}`

For evidence inside another Olympus artifact (redundancy matrix, readiness score, persona map, TCO baseline).

- Regex: `^[a-z][a-z0-9-]*(?:\.[a-z0-9-]+)?:[A-Za-z0-9._ /-]+:[A-Z0-9-]+$`
- Examples:
  - `redundancy-matrix:entity-overlap:FND-0042`
  - `readiness-score.json:quality-dimension:Q-018`
  - `pass4-journey-map:persona-retiree:J-07`
- Section may contain spaces but no colons. Finding-ID is uppercase alphanumeric with optional hyphens.

## 2. Source-code — `{repo}:{file}:{line}`

For evidence inside a source file.

- Regex: `^[A-Za-z0-9_.-]+:[A-Za-z0-9_./\\-]+\.[A-Za-z0-9]+:\d+(?:-\d+)?$`
- Examples:
  - `cfwheels-corpus:app/controllers/Leave.cfc:214`
  - `cfwheels-corpus:app/controllers/Leave.cfc:214-231`
- Line is a single integer or `start-end` range. Normalize `\` to `/` before resolving.

## Common mistakes (flag as `major`)

- Trailing whitespace or smart quotes (Office paste).
- Section/subsection confusion: `entity-overlap.duplicates` is wrong — use a colon when the artifact truly nests findings.
- Wrong-case app IDs: citations use `app-001` but the manifest canonicalizes to `APP-001`. Canonicalize before resolving.
- Line numbers that resolve to a blank line or pure comment — demand substantive content.
- Finding-IDs missing the uppercase prefix (`42` instead of `FND-0042`).
- Reversed ranges (`231-214`).

## Severity mapping

- Regex parse fails — `major` on `traceability-resolution`.
- Regex parses but target cannot be resolved (file missing, section absent, finding-ID not in the artifact) — `blocker` on `traceability-resolution`.
