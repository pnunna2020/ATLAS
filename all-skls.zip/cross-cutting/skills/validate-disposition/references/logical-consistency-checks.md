# Logical Consistency Checks

Apply each rule to every recommendation. Cite the rule ID in findings.

## LC-01 — Retire has no surviving consumers
If `Retire`, every app with an inbound edge must itself be `Retire` or must have a named replacement covering the capability. Severity: `blocker`.

## LC-02 — Consolidate endpoints both exist
If `Consolidate`, both source and named target must appear in the portfolio manifest. Severity: `blocker`.

## LC-03 — Consolidate target has its own disposition
The target must itself be assigned a disposition — typically `Refactor`, `Rearchitect`, or `Retain`. It must not be unassigned or point back to the source. Severity: `blocker`.

## LC-04 — Replace names the replacement
If `Replace`, `replacement_system` (COTS, SaaS, or internal system ID) must be non-empty. Severity: `blocker`.

## LC-05 — Confidence fits the evidence
Thresholds:
- `high` — at least four evidence classes and no missing user-impact field.
- `medium` — at least three classes and resolved user-impact for Retire/Replace/Consolidate.
- `low` — acceptable with two classes; surface for stakeholder attention.

Confidence above the supported threshold is a `major` finding.

## LC-06 — Downstream routing matches disposition
Per Rationalization README Step 6:
- Refactor, Rearchitect → Modernization
- Retire, Retain, Replace, Replatform → Disposition Execution
- Consolidate → target to Modernization, source(s) to Disposition Execution (Retire)

Any mismatch between `disposition` and `factory_routing` is a `blocker`.

## LC-07 — No self-references
An app cannot cite itself as replacement or consolidation target. Severity: `blocker`.

## LC-08 — User-impact fields internally consistent
Retire, Replace, and Consolidate require all five user-impact fields populated. Field presence is enforced by `user-impact-coverage`; LC-08 checks internal consistency (e.g., `affected_users > 0` whenever disrupted journeys are listed). Severity: `major`.
