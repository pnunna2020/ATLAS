# Cycle Detection on the Disposition Dependency Graph

The validator runs DFS with a recursion stack over the dependency graph built by Discovery Step 4 (`schemas/rationalization/integration-graph.schema.json`), overlaid with disposition-action edges.

## Edges
`X -> Y` means "X's disposition action cannot complete until Y's completes." Examples:
- `Retire X -> Replace Y` — X cannot retire until Y's replacement is live.
- `Consolidate X into T -> Rearchitect T` — X cannot fold in until T is rearchitected.
- `Retire X -> Retire Z` — downstream consumers must be gone first.

`dependency_type` comes from the integration-graph classification: `data`, `api`, `shared-db`, `message`, `batch-chain`. Run DFS over the **union** of edge types — cycles crossing multiple types still count.

## Algorithm

```
visited, on_stack, cycles = {}, {}, []

def dfs(node, path):
    visited[node] = True
    on_stack[node] = True
    path.append(node)
    for (target, edge_type) in edges_out(node):
        if not visited.get(target):
            dfs(target, path)
        elif on_stack.get(target):
            start = path.index(target)
            cycles.append((path[start:] + [target], edge_type))
    on_stack[node] = False
    path.pop()

for node in all_nodes:
    if not visited.get(node):
        dfs(node, [])
```

Complexity is `O(V + E)`. For each cycle record `apps_in_cycle`, `dependency_type` (majority vote across the cycle's edges), and `resolution_required`. `is_acyclic = (len(cycles) == 0)`.

## Cycle-breaking options
The validator records the cycle and proposes one of:
- Sequence one disposition ahead of the other with documented interim state.
- Insert a shim/adapter to decouple the cyclic edge.
- Sever the shared database so the `shared-db` edge dissolves.
- Escalate to the Portfolio Manager when no in-line resolution is feasible.

Any detected cycle forces `dependency-coherence` to `FAIL` and `overall_result` to `FAIL` — regardless of cycle size or edge type.
