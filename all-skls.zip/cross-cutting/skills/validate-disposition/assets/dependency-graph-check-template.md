# Disposition Dependency Graph Check

> Fill one of these for every portfolio validation run. The outcome feeds the `dependency_graph_analysis` block of `disposition-validation-report-template.json`.

## Run metadata
- Portfolio ID: `TODO`
- Validated date (ISO-8601): `TODO`
- Validator version: `TODO`
- Edge sources combined: `data`, `api`, `shared-db`, `message`, `batch-chain` (union)

## Cycle detection result
- Algorithm: DFS with recursion stack (see `references/cycle-detection-algorithm.md`)
- Nodes visited: `TODO`
- Edges traversed: `TODO`
- `is_acyclic`: `true` | `false`

## Graph snippet (DOT)

```dot
digraph dispositions {
  rankdir=LR;
  // node format: "APP-ID" [label="APP-ID\n<disposition>"];
  // edge format: "SOURCE-APP" -> "TARGET-APP" [label="<dependency_type>"];

  "TODO-APP-A" [label="TODO-APP-A\nRetire"];
  "TODO-APP-B" [label="TODO-APP-B\nReplace"];

  "TODO-APP-A" -> "TODO-APP-B" [label="data"];
  // include only the edges that participate in cycles plus their 1-hop neighbors
}
```

## Cycles enumerated
Repeat this block for every cycle detected. Skip the section if `is_acyclic` is `true`.

### Cycle 1
- Apps in cycle (ordered along the back-edge): `["TODO-APP-A", "TODO-APP-B", "..."]`
- Dependency type (dominant edge class): `data` | `api` | `shared-db` | `message` | `batch-chain`
- Why the cycle exists: `TODO — one sentence tying the cycle to dispositions (e.g., "Retire A depends on Replace B being deployed, but Replace B pulls data from A.")`
- Resolution required: `TODO — chosen cycle-breaking strategy. Pick one of:
    - Sequence one disposition ahead of the other (which, and why).
    - Insert a shim/adapter to decouple the shared-db or api edge.
    - Escalate to the Portfolio Manager because no in-line resolution is feasible.`
- Owner + decision date: `TODO`

## Sign-off
- Validator: `TODO`
- Portfolio Manager (only when cycles exist): `TODO`
