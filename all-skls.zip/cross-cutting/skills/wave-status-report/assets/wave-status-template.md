# Wave Status Report Template

Template for the wave-level status report aggregated from all applications in
a modernization wave. Generated for the P6.2 portfolio dashboard and executive
stakeholder briefings.

## Wave Identity

- Wave identifier:
- Wave window: <YYYY-MM-DD> to <YYYY-MM-DD>
- Wave sponsor:
- Report as of: <YYYY-MM-DD>
- Reporting analyst:

## Executive Summary

Two to four sentences describing overall wave health, notable risks, and any
decisions required from executives.

## Headline Metrics

| Metric                             | Value | Target | Status |
|------------------------------------|-------|--------|--------|
| Apps in wave                       |       |        |        |
| On-schedule                        |       |        |        |
| At-risk                            |       |        |        |
| Blocked                            |       |        |        |
| Throughput (apps/week)             |       |        |        |
| Apps completed this reporting cycle|       |        |        |

Note: completion percentage is NOT computed as a linear function of pipeline
position because the Ralph Loop adds 1-10 iterations of variability in P4.3.

## Application Detail

For every app in the wave, record one row:

| App ID | Name | Phase | Gate Status | Blockers | Velocity | Owner | Status |
|--------|------|-------|-------------|----------|----------|-------|--------|
|        |      |       |             |          |          |       |        |

Status legend:
- on-schedule: tracking to plan
- at-risk: behind schedule but still advancing
- blocked: stopped by an external dependency (document the dependency)

## Blockers and Escalations

List every blocker with dependency owner, business impact, and escalation
action. Blockers are separated from at-risk items because they require
different interventions.

## Sustainment Health

Include sustainment alongside modernization progress so executives see both
sides. Summarize: open P1 incidents, SLO breaches this cycle, operational
cost trend.

## Decisions Requested

Enumerate any decisions or approvals the wave needs from executives, each
with a recommended option and a due date.

<!-- TODO(skill-author): Add a machine-readable variant of this template
     (YAML or JSON) so dashboards can ingest wave status without markdown
     scraping. Keep the markdown version for human review and briefings. -->
