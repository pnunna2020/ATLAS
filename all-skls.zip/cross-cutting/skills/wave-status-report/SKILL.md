---
name: wave-status-report
description: >
  Aggregate current wave progress across all apps in a wave, generating portfolio dashboard updates and executive summaries. Use for P7.2 factory analytics, P6.2 portfolio dashboard updates, or when asked about wave progress, factory status, or portfolio reporting.
agent: sonnet
---

# Wave Status Report Generator
## Purpose
Aggregate progress from all apps in a wave into a single status report for
the portfolio governance dashboard and executive stakeholders.

## Workflow
1. Read Factory Configuration Registry for current wave apps and their pipeline positions
2. For each app: current phase, gate status, blockers, velocity metrics
3. Aggregate: % complete, on-schedule count, at-risk count, blocked count
4. Calculate factory throughput (apps/week) and compare to projection
5. Generate report using `assets/wave-status-template.md`

## Gotchas
- **Pipeline position ≠ completion percentage**: An app in P4.3 is not "75% done"
  because P4.3 has the Ralph Loop which can iterate 1-10 times.
- **Count blocked apps separately from at-risk**: Blocked = waiting on external
  dependency. At-risk = behind schedule but still moving.
- **Include sustainment status**: Executives want to see BOTH modernization
  progress AND sustainment health in the same report.

## Quality Rules
- [ ] Report includes every app in the wave with current pipeline position, gate status, and blockers
- [ ] Completion percentage accounts for Ralph Loop variability — pipeline position is not a linear % complete
- [ ] Blocked apps are separated from at-risk apps (blocked=waiting on external, at-risk=behind schedule)
- [ ] Factory throughput (apps/week) is compared against the projection from wave planning
- [ ] Sustainment health is included alongside modernization progress in the same report
- [ ] Report uses the standard template from `assets/wave-status-template.md`

## Common Failure Modes
| Failure Mode | Symptom | Prevention |
|-------------|---------|------------|
| Linear completion assumption | App in P4.3 reported as "75% done" but Ralph Loop adds 2 weeks; executives surprised by delay | Use pipeline position categories, not linear percentages; document Ralph Loop variability |
| Blocked and at-risk conflated | All behind-schedule apps grouped together; external blockers not escalated separately | Separate blocked (external dependency) from at-risk (behind schedule) in the report |
| Sustainment omitted | Executives see modernization progress but not sustainment incidents; blind spot on operational health | Include sustainment health section in every wave status report |
| Throughput not compared to projection | Report shows absolute numbers without context; no way to assess if wave is on track | Always compare actual throughput against the wave planning projection |

## Handoff Summary
When this skill completes, verify:
1. Report covers all apps in the wave with accurate pipeline positions
2. Blocked and at-risk apps are separately identified with root causes
3. Factory throughput is compared to projection
4. Sustainment health is included
Then proceed to: portfolio governance dashboard update (P6.2), executive stakeholder briefing, and `factory-capacity-manager` if throughput deviation is significant
