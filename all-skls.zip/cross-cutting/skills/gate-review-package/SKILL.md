---
name: gate-review-package
description: >
  Assemble all required artifacts for a quality gate review (G-04a, G-04b, G-04c, EA Alignment, Safety Assurance, Decommission). Use before any gate review. Triggers on gate review, gate package, gate preparation, or quality gate assembly.
agent: sonnet
---

# Gate Review Package Assembler
## Purpose
Collect and organize all artifacts needed for a gate review into a single
reviewable package. Ensures nothing is missing before the review.

## Gate-Specific Checklists

### G-04a (Extraction)
- [ ] Extracted specifications document
- [ ] Business rule catalog
- [ ] Traceability matrix (must show ≥98%, ≥99% for T1)
- [ ] Coverage report (must show >95%)
- [ ] SME sign-off record

### G-04b (Design)
- [ ] Module designs
- [ ] OpenAPI specifications
- [ ] Data models
- [ ] UX flow designs (web apps)
- [ ] 508 compliance preliminary mapping
- [ ] EA compliance verification (from ea-compliance skill)
- [ ] Forward traceability matrix
- [ ] Formal test plans (MANDATORY for T1)

### G-04c (Generate)
- [ ] Generated code (TDD)
- [ ] Unit test results (must show ≥80% coverage)
- [ ] 508 compliance report
- [ ] Security scan results (SonarQube clean)
- [ ] cATO artifacts (OSCAL SSP update)
- [ ] Ralph Loop iteration log (max 10)

### Decommission Gate
- [ ] Parallel run completion confirmation
- [ ] Behavioral parity sustained for full parallel period
- [ ] User adoption metrics above threshold
- [ ] Rollback window formally expired

## Gotchas
- **Missing artifacts = gate FAIL**: There is no "we'll add it later" for gate
  reviews. Every checklist item must be present.
- **T1 apps have ADDITIONAL requirements at every gate**: Check safety tier
  in config before assembling. T1 adds formal test plans, enhanced traceability,
  and safety case cross-references.

## Quality Rules
- [ ] Every checklist item for the specific gate is present — no "to be added later" items
- [ ] Safety tier is checked in config before assembling — T1 requires additional artifacts at every gate
- [ ] Traceability matrix meets tier-specific thresholds (>=98% standard, >=99% for T1)
- [ ] Test coverage meets tier-specific thresholds (>=80% line coverage, >=70% branch coverage)
- [ ] All artifacts are the current version — no stale or superseded documents in the package
- [ ] Package includes a summary of all gate-specific risks and their mitigation status

## Common Failure Modes
| Failure Mode | Symptom | Prevention |
|-------------|---------|------------|
| Missing artifacts | Gate review fails because required artifacts are not in the package; rework and delay | Validate the complete gate-specific checklist before submitting the package |
| Stale artifacts | Package contains outdated versions; reviewer finds inconsistencies with current code | Verify artifact freshness — compare timestamps against latest code changes |
| T1 requirements missed | Standard package assembled for a T1 safety-critical app; additional evidence missing | Always check safety tier first; load T1-specific checklist additions |
| Threshold not met | Traceability at 95% submitted for review; gate fails on threshold check | Verify all quantitative thresholds before assembling; flag shortfalls for pre-gate remediation |

## Handoff Summary
When this skill completes, verify:
1. All gate-specific checklist items are present and current
2. Safety tier requirements are met (standard or T1-enhanced)
3. Quantitative thresholds (traceability, coverage) are verified
4. Package summary documents any known risks
Then proceed to: the specific gate review (G-04a, G-04b, G-04c, or Decommission Gate) for human reviewer evaluation
