---
name: submission-package-builder
description: >
  Validate and pack the FAA ATLAS Phase 3 HDD submission: enforce the exact
  two-folder layout ("Written Submission" / "Code and Technical Artifacts"),
  bundle source/IaC/pipelines/tests/evidence into a single ZIP under Folder 2,
  emit README.md/PDF + evidence index, scrub secrets, verify license markings,
  and produce a fail-loud compliance report. Use during Phase 3 build day 11
  through day 12 (HDD cut). Triggers on HDD packaging, submission validator,
  Code and Technical Artifacts folder, evidence index, or P3-R98 mentions.
agent: sonnet
enrichment_level: Partial
tags:
  - evidence-generation
  - factory-ops
  - traceability
allowed-tools:
  - Read
  - Write
  - Bash
  - Grep
---

# Submission Package Builder

## Purpose
Assemble the Phase 3 HDD submission and validate it against P3-R74..R98 and
P3-R115. The HDD physical-delivery window is one hour wide on 2026-06-02
3-4PM ET (P3-R101); a layout error discovered at the courier counter cannot
be recovered before the 4PM hard deadline (P3-R102). This skill is the
fail-loud gate that says "the HDD is ready" or "the HDD is not ready and
here's exactly why."

This skill does NOT compose the written narrative (that's
`phase-commitment-traceback`), generate code (that's the build skills), or
script the oral (that's `demo-runbook-generator`). It is the packager and
verifier: it takes a build manifest, copies / scrubs / zips, and validates.

## When to use

Invoke this skill on Phase 3 build day 11 (per `docs/phase3/build-demo-skills-plan.md`
§6 D6) for the first dry run, **after** the prototype repo is code-frozen
and the written narrative .docx exists. Re-invoke daily through Day 12.5:

- **Day 11 evening**: first full pack against a candidate HDD image.
- **Day 12 morning**: pack against a fresh build; CI artifacts retrieved.
- **Day 12 noon**: final pack against the actual physical HDD.
- **Day 12.5 (Tuesday 2026-06-02) 7AM ET**: re-validate the packed HDD
  one final time before courier departs.

If the validator reports any FAIL on the courier-day re-validation, do not
hand off the HDD to the courier — fix and re-pack.

## Inputs

```yaml
build_manifest:
  prototype_root: /repo/faa-atlas-phase3-prototype
  written_narrative_dir: /repo/submission/written-submission
  source_directories:                # what goes into the ZIP under Folder 2
    - apps/                          # apps/api (Node 20 + Express + TypeScript) + apps/web (React + USWDS)
    - services/                      # additional Node services (auth-bff, dashboard-bff, etc.)
    - openapi/                       # OpenAPI 3.1 specs
    - infra/cdk/                     # AWS CDK v2 (TypeScript) stacks (P3-R81)
    - infra/helm/                    # Helm chart, Phase 4 stub only (P3-R83)
    - infra/docker-compose.yml       # local-dev parity
    - infra/policy/                  # OPA / Conftest policy bundles
    - .github/workflows/             # GitHub Actions YAML (P3-R89, R90)
    - "**/Dockerfile"                # per-service Dockerfiles (P3-R82)
    - tests/                         # automated test scripts
    - evidence/                      # pipeline runs, OSCAL, scan outputs (P3-R89..R94)
    - scripts/                       # build scripts (P3-R80)
    - docs/                          # devsecops README, runbooks, etc.
  config_files_glob:                 # P3-R78
    - "**/*.env.example"
    - "**/config/*.yaml"
    - "**/config/*.json"
    - "**/tsconfig*.json"
    - "**/package.json"
    - "**/cdk.json"
  dependency_manifests:              # P3-R79
    - "**/package.json"
    - "**/package-lock.json"
  exclude_globs:                     # never pack these
    - "**/.env"                      # real env, not example
    - "**/.env.local"
    - "**/.env.production"
    - "**/secrets/*"
    - "**/*.pem"
    - "**/*.key"
    - "**/*.p12"
    - "**/*.jks"
    - "**/node_modules/"
    - "**/dist/"
    - "**/build/"
    - "**/cdk.out/"                  # synth output is regenerated; checked-in templates only
    - "**/.DS_Store"
    - "**/*.log"
hdd:
  mount_point: /Volumes/FAA-PHASE3   # macOS; on Windows substitute drive letter
  encryption: bitlocker-or-veracrypt # FAA must be able to read it; document chosen scheme in README
  manifest_filename: manifest.sha256
  zip_name: faa-atlas-phase3-prototype.zip
  primary_dir_name: faa-atlas-phase3-prototype  # what's inside the zip
checks:
  enforce_two_folders: true          # P3-R98 — exactly two folders, exact spelling
  enforce_pdf_searchable: true       # P3-R61 fallback for the narrative
  enforce_no_precompiled_substituting_for_source: true  # P3-R74
  enforce_no_secrets_in_zip: true
  enforce_license_markings: true     # P3-R115
expected_evidence_index_categories: # P3-R96
  - source-code
  - api-specs
  - iac
  - dockerfiles
  - pipelines
  - pipeline-run-output
  - sast
  - sca
  - container-scan
  - iac-scan
  - dast
  - sbom
  - oscal
  - test-reports
  - architecture-diagrams
  - readme
  - written-narrative
```

## Outputs

| Path | Purpose |
|------|---------|
| `submission/staging/Written Submission/` | Folder 1 staging — exact spelling, exact casing. |
| `submission/staging/Code and Technical Artifacts/` | Folder 2 staging — exact spelling, exact casing. |
| `submission/staging/Code and Technical Artifacts/<zip>` | Single ZIP per P3-R97. |
| `submission/staging/Code and Technical Artifacts/<zip>:/README.md` | SF2 root README per P3-R84. |
| `submission/staging/Code and Technical Artifacts/<zip>:/README.pdf` | PDF copy of README per P3-R84 fallback. |
| `submission/staging/Code and Technical Artifacts/<zip>:/EVIDENCE-INDEX.md` | Index of every evidence requirement → file path per P3-R96. |
| `submission/staging/Code and Technical Artifacts/<zip>:/manifest.sha256` | SHA-256 checksums of every file in the zip. |
| `submission/staging/Written Submission/Phase3-Written-Narrative.docx` | The 10-page narrative. |
| `submission/staging/Written Submission/Phase3-Written-Narrative.pdf` | Searchable PDF. |
| `submission/reports/compliance-report.md` | Per-check pass/fail with line-level findings. |
| `submission/reports/secret-scrub-log.txt` | What was redacted, what was excluded. |
| `submission/reports/license-audit.md` | License markings audit per P3-R115. |
| `scripts/build-submission.sh` | Re-runnable bash packing script (POSIX) for the courier-day pack. |
| `scripts/build-submission.ps1` | Windows PowerShell equivalent for cross-platform ops. |

## Procedure

1. **Validate inputs.** Reject if:
   - `build_manifest.prototype_root` does not exist or does not contain
     a `.git/` directory (the submission must be from a real, committed
     state — never an unsaved working tree).
   - `build_manifest.written_narrative_dir` does not contain both
     `Phase3-Written-Narrative.docx` and `Phase3-Written-Narrative.pdf`.
   - `hdd.zip_name` collides with anything in `exclude_globs`.

2. **Scrub-and-stage source tree** to a temp directory `submission/_temp/<zip>/`:
   - `rsync -av --exclude-from=exclude_globs.txt prototype_root/ _temp/<primary_dir>/`
   - For every file containing strings matching the secret patterns
     `(?i)(api[_-]?key|secret|token|password|aws_secret_access_key|private_key)\s*[:=]\s*['\"]?[A-Za-z0-9/+=]{20,}`,
     emit a finding to `secret-scrub-log.txt`. If a finding is in a
     `*.example` file or a test fixture explicitly tagged
     `# scrub-allowed: synthetic`, allow. Otherwise, fail loud — do
     not silently redact secrets in source code; the team must
     decide.
   - For every Dockerfile, verify `USER` directive ≠ root and
     `HEALTHCHECK` is present. Warn (not fail) if either is missing.
   - For the CDK directory `infra/cdk/`, verify no `cdk.out/` synth artifacts
     leaked into the zip (templates are regenerated by `cdk synth`). Verify
     no AWS credentials or `cdk.context.json` entries containing account IDs
     for unintended targets are committed. Fail loud if found.

3. **Verify evidence directory completeness.** Open `evidence/`. Assert:
   - `evidence/oscal/by-control/` contains a fragment per NIST family
     in the build manifest (10 files: AC-2, AC-3, AC-4, IA-5, AU-2,
     AU-10, AU-12, SC-12, SC-28, SI-10).
   - `evidence/sast/` contains at least one Semgrep SARIF file.
   - `evidence/sca/` contains at least one Grype JSON file.
   - `evidence/container-scan/` contains at least one Trivy SARIF file
     per service.
   - `evidence/iac-scan/` contains at least one Trivy + tfsec + Checkov
     report.
   - `evidence/dast/` contains at least one ZAP baseline HTML.
   - `evidence/sbom/` contains at least one Syft SPDX JSON per service.
   - `evidence/pipeline-run-summary.json` validates against the schema
     `evidence/pipeline-run-schema.json`.
   - Any missing item → fail loud; do not pack.

4. **Author the SF2 root README** at `_temp/<primary_dir>/README.md` from
   `references/readme-template.md` with these substitutions filled in:
   - **Project name**: "FAA ATLAS Phase 3 Prototype — Private Pilot
     Certification Workflow."
   - **Layout**: a tree of the top-level directories with one-line
     descriptions.
   - **Environment setup** (P3-R85): step-by-step commands. Targets
     macOS 14+ / Linux. Lists exact required tools (Docker 24+,
     docker-compose, Node 20, AWS CDK v2 — `npm install -g aws-cdk@2`)
     with install verification commands. Per `docs/phase3/local-first-architecture.md`
     §2 the API runtime is Node 20 + Express + TypeScript; no Python runtime
     is required to run the prototype.
   - **Dependency resolution** (P3-R86): for the Node workspaces, run
     `npm ci` at repo root and inside `infra/cdk/`.
   - **Run instructions** (P3-R87): the two-command path —
     `cp .env.example .env.local && docker-compose -f infra/docker-compose.yml up -d` — followed by the
     URL list (frontend at `http://localhost:3000`, API at
     `http://localhost:8080`, Grafana at `http://localhost:3001`).
     Include a verification step ("if you see the dashboard at
     `http://localhost:3000/dashboard?ftn=A0000042`, the prototype is
     up").
   - **Independent FAA static-analysis instructions** (P3-R88): one
     command to re-run the entire pipeline locally
     (`scripts/run-pipeline-locally.sh` produces the same outputs CI
     would; results land in `evidence/`). Include a separate command
     to invoke each scanner standalone (`semgrep --config p/owasp-top-ten`,
     `grype sbom:evidence/sbom/...`, `trivy image ...`).
   - **Architecture overview**: pointer to
     `docs/architecture/7-box-diagram.md` (Mermaid + image).
   - **Service inventory**: table with one row per deployed service,
     with port, OpenAPI spec path, source path, image tag.
   - **Test instructions**: how to run unit, integration, and Playwright
     e2e tests offline.
   - **Evidence overview**: pointer to `EVIDENCE-INDEX.md` and a
     one-paragraph reading guide.
   - **License**: "All work products are FAA's exclusive property per
     P3-R115 / SOO §5 Data Rights" plus a clear statement that
     no third-party license markings restrict FAA reuse. Cite the
     license-audit.md report.

5. **Render README.pdf** via the `docx` skill or `pandoc README.md
   --pdf-engine=xelatex -o README.pdf`. Verify text-selectable
   (round-trip select-all, paste).

6. **Author the EVIDENCE-INDEX.md** at `_temp/<primary_dir>/EVIDENCE-INDEX.md`
   from `references/evidence-index-template.md`. One row per P3-Rxx
   evidence requirement (R74..R94 + R115..R118), columns:
   - Requirement ID (P3-R74, P3-R75, ...).
   - Requirement description (one line).
   - Path to evidence (relative to ZIP root).
   - Status: PRESENT / MISSING / DEFERRED.

   Reject if any row reads MISSING — these are MUST requirements.
   DEFERRED is allowed only with a deviation entry in the written
   narrative §6 (cross-check via deviation-log.json from
   `phase-commitment-traceback`).

7. **Author the license audit** at `submission/reports/license-audit.md`:
   - Run a license scan over all third-party dependencies (Grype JSON
     output already lists licenses; consume that).
   - Reject `GPL-3.0-only`, `AGPL-3.0`, and any license whose terms
     conflict with FAA exclusive ownership (P3-R115).
   - Allow MIT, Apache-2.0, BSD-2/3-Clause, ISC, MPL-2.0, CC0,
     Unlicense.
   - Document any custom-license dependency with a one-paragraph
     analysis.
   - For source files in the prototype itself: confirm no copyright
     notice claims rights inconsistent with FAA exclusive ownership.
     If a file has `Copyright (c) 2026 Booz Allen Hamilton — all
     rights reserved`, flag it; the FAA-ownership boilerplate must
     replace any restrictive notice.

8. **Compute checksum manifest.** `find _temp/<primary_dir> -type f
   -exec sha256sum {} \; > _temp/<primary_dir>/manifest.sha256`. This
   becomes the integrity reference for HDD-arrival verification.

9. **Build the ZIP.** `cd _temp && zip -r9 ../staging/Code\ and\ Technical\ Artifacts/<zip_name>
   <primary_dir>` (POSIX) or
   `Compress-Archive -Path <primary_dir> -DestinationPath ...` (Windows).
   The compression level matters: -9 for size, but verify total ZIP
   size < 4 GB (HDDs are large but the ZIP must not exceed FAT32
   limits in case the FAA reads it on a legacy box). If > 4 GB,
   re-evaluate `evidence/` retention — keep only one ZAP run, one
   Trivy run per scan, etc.

10. **Stage the Written Submission folder.** Copy the .docx and .pdf
    from `build_manifest.written_narrative_dir/` into
    `staging/Written Submission/`. Verify both filenames exactly:
    `Phase3-Written-Narrative.docx`, `Phase3-Written-Narrative.pdf`.

11. **Validate HDD root layout.** Mount the candidate HDD; assert
    that `<mount_point>/` contains exactly two entries:
    `Written Submission` and `Code and Technical Artifacts`. Exact
    spelling, exact casing — case-sensitive comparison.
    - No `.DS_Store`, no `Thumbs.db`, no `System Volume Information`
      (or scrub them).
    - No third folder, no stray ZIP at the root.

    Use this exact bash:
    ```bash
    set -euo pipefail
    mount=/Volumes/FAA-PHASE3
    expected=("Written Submission" "Code and Technical Artifacts")
    actual=()
    while IFS= read -r entry; do
      case "$entry" in
        ".DS_Store"|"System Volume Information"|"\$RECYCLE.BIN") continue;;
        *) actual+=("$entry");;
      esac
    done < <(find "$mount" -mindepth 1 -maxdepth 1 -printf '%f\n' | sort)
    if [[ "${actual[*]}" != "${expected[*]}" ]]; then
      echo "FAIL: HDD root layout mismatch."
      printf "Expected: %s\n" "${expected[@]}"
      printf "Actual:   %s\n" "${actual[@]}"
      exit 1
    fi
    echo "PASS: HDD root contains exactly two folders, exact spelling."
    ```

12. **Run the compliance report**. For each P3-R* check, record
    PASS/FAIL/WARN with line-level findings. Categories:
    - Format checks (P3-R54..R61): delegate to `format-validation-report.txt`
      from `phase-commitment-traceback`.
    - Source completeness (P3-R74..R83): glob-count + spot-check.
    - README content (P3-R84..R88): grep for required headings
      ("Environment setup", "Dependency resolution", "Run", "Independent
      FAA static analysis").
    - Evidence (P3-R89..R94): glob-count under `evidence/`.
    - Layout (P3-R95..R98): from step 11 + step 6 + step 9.
    - License (P3-R115): from step 7.
    - Standards (P3-R116..R118): cross-check against the written
      narrative §9 (these are narrative-bound).

    Emit `submission/reports/compliance-report.md` with:
    ```
    # Phase 3 Submission Compliance Report
    Generated: <utc timestamp>
    HDD: <mount_point>
    Verdict: PASS | FAIL

    ## Per-requirement results
    | P3-R | Description | Status | Finding |
    |---|---|---|---|
    | R54 | Narrative ≤ 10 pages | PASS | 10 pages |
    | R55 | Letter format | PASS | 8.5 × 11 in |
    | ... | ... | ... | ... |
    | R98 | HDD root has exactly two folders, exact spelling | PASS | "Written Submission", "Code and Technical Artifacts" |

    ## Summary
    Total checks: 45
    PASS: <n>
    FAIL: <n>
    WARN: <n>
    ```

    If any FAIL, the verdict is FAIL and the HDD must not ship.

13. **Emit the rerunnable packing scripts.** Write
    `scripts/build-submission.sh` (POSIX) and
    `scripts/build-submission.ps1` (PowerShell). Each:
    - Reads `build_manifest.yaml`.
    - Re-runs steps 2 through 12 deterministically.
    - Exits non-zero on any FAIL.
    - Designed to run on the courier-day morning to produce a fresh,
      identical HDD image for the actual physical hand-off.

## Validation / acceptance criteria

- [ ] HDD root contains exactly two folders, exact spelling and casing
      ("Written Submission", "Code and Technical Artifacts"). No third
      entry. No leading/trailing spaces.
- [ ] `Code and Technical Artifacts/` contains exactly one ZIP (P3-R97).
- [ ] `Written Submission/` contains both .docx and .pdf of the
      narrative.
- [ ] ZIP unpacks cleanly with `unzip -t` exit 0.
- [ ] Unzipped tree has `README.md`, `README.pdf`, `EVIDENCE-INDEX.md`,
      `manifest.sha256` at the primary directory root (P3-R84, R96).
- [ ] EVIDENCE-INDEX.md has one row per requirement P3-R74..R94 +
      R115..R118; no row reads MISSING.
- [ ] No `.env` (real), `.env.local`, `.env.production`, `*.pem`, `*.key`,
      `*.p12`, `*.jks`, or `node_modules/` in the ZIP.
- [ ] Secret scrub log has no unhandled findings (every finding either
      excluded or explicitly allow-listed with `# scrub-allowed:` tag).
- [ ] License audit shows zero GPL-3.0/AGPL-3.0 dependencies; zero
      restrictive Booz Allen copyright notices in source files.
- [ ] `manifest.sha256` covers every file in the ZIP; SHA-256 round-trips.
- [ ] All 10 OSCAL fragments present under `evidence/oscal/by-control/`.
- [ ] At least one SAST, SCA, container-scan, iac-scan, DAST, and SBOM
      report present.
- [ ] All Dockerfiles use non-root `USER` and have `HEALTHCHECK` (warn
      level only — Trivy will catch real failures).
- [ ] Both PowerShell and bash packing scripts exit 0 on a clean run.
- [ ] No reference to BASE-C or Bedrock in README.md or EVIDENCE-INDEX.md
      — the only place either appears is the written narrative §6
      (which is Folder 1, not Folder 2).
- [ ] Final HDD ZIP size ≤ 4 GB.
- [ ] Compliance report verdict is PASS.

## Examples

### Example 1: HDD root layout (correct)

```
/Volumes/FAA-PHASE3/
├── Written Submission/
│   ├── Phase3-Written-Narrative.docx
│   └── Phase3-Written-Narrative.pdf
└── Code and Technical Artifacts/
    └── faa-atlas-phase3-prototype.zip
```

### Example 2: HDD root layout (incorrect — 3 entries)

```
/Volumes/FAA-PHASE3/
├── Written Submission/
├── Code and Technical Artifacts/
└── readme.txt           ← FAIL: third entry at root
```

The validator emits:
```
FAIL: HDD root layout mismatch.
Expected: Code and Technical Artifacts | Written Submission
Actual:   Code and Technical Artifacts | Written Submission | readme.txt
```

### Example 3: EVIDENCE-INDEX.md excerpt

```markdown
# Phase 3 Evidence Index

This index maps each Phase 3 atomic requirement to the artifact in this
ZIP that satisfies it. Paths are relative to the ZIP root.

| P3-R | Requirement | Path |
|---|---|---|
| R74 | Full uncompiled source for custom application logic | `services/`, `web/` |
| R75 | Full uncompiled source for backend services | `services/s1-identity/`, ..., `services/s11-reporting/` |
| R76 | OpenAPI specs | `openapi/s1.yaml` ... `openapi/s11.yaml` |
| R77 | Frontend source | `web/applicant/src/` |
| R78 | Configuration files | `services/*/config/`, `.env.example`, `tsconfig.json`, `pyproject.toml` |
| R79 | Dependency manifests | `web/package.json`, `web/package-lock.json`, `services/*/requirements.txt` |
| R80 | Build scripts | `scripts/build-*.sh`, `Makefile`, `npm scripts in package.json` |
| R81 | IaC templates | `infra/cdk/` (AWS CDK v2 in TypeScript), `infra/docker-compose.yml`, `infra/helm/` (Phase 4 stub) |
| R82 | Containerization | per-service `Dockerfile`s, `infra/docker-compose.yml` |
| R83 | Configuration-management scripts | `infra/helm/templates/`, `scripts/seed-data.sh` |
| R84 | README at root | `README.md`, `README.pdf` |
| R85 | Environment setup in README | `README.md#environment-setup` |
| R86 | Dependency resolution in README | `README.md#dependency-resolution` |
| R87 | Run instructions in README | `README.md#run-instructions` |
| R88 | Independent FAA static analysis | `README.md#independent-faa-review`, `scripts/run-pipeline-locally.sh` |
| R89 | Pipeline execution outputs | `evidence/pipeline-run-summary.json`, `.github/workflows/*.yml` |
| R90 | Deployment workflow evidence | `evidence/deploy/<run-id>-summary.json` |
| R91 | Infrastructure provisioning evidence | `evidence/iac-apply/<run-id>-outputs.json` |
| R92 | Security validation outputs | `evidence/sast/`, `evidence/sca/`, `evidence/container-scan/`, `evidence/iac-scan/`, `evidence/dast/` |
| R93 | Monitoring/logging evidence | `infra/cdk/lib/observability-stack.ts`, `evidence/grafana-snapshots/` |
| R94 | Automated compliance evidence | `evidence/oscal/`, `evidence/sbom/` |
| R115 | All work products belong to FAA | `LICENSE`, `submission/reports/license-audit.md` |
| R117 | NIST 800-53 control mapping | `evidence/oscal/by-control/{AC-2,AC-3,AC-4,IA-5,AU-2,AU-10,AU-12,SC-12,SC-28,SI-10}.json` |
```

### Example 4: secret scrub finding (must be addressed)

```
secret-scrub-log.txt:
[FAIL] services/s1-identity/config/keycloak-admin.json:7
  Pattern matched: api_key
  Line: "api_key": "ABCD1234EFGH5678IJKL"
  Resolution: This is a real-looking secret in a config file. Either:
    (a) Move to .env.example with placeholder, OR
    (b) Confirm this is a synthetic test key and add `# scrub-allowed: synthetic` comment.
  HDD pack BLOCKED until resolved.
```

## Gotchas

- **Exact spelling matters.** `Code and Technical Artifacts` (Title
  Case, ampersand-free, "and" not "&"). `Written Submission` (Title
  Case, no period). Trailing space, leading space, lowercase `code`,
  `Artifact` singular — all fail P3-R98. The validator does
  byte-exact comparison.
- **HDD encryption format must be FAA-readable.** BitLocker Drive
  Encryption with a known recovery key is the safest default for
  Windows-defaulting environments. Document the chosen scheme +
  recovery key in the README's "Independent FAA review" section.
  VeraCrypt is acceptable but document the password handoff
  procedure (presenter list email per P3-R100 is the channel).
- **Don't pack `.git/`.** It bloats the ZIP and may include sensitive
  history. Add `.git/` to `exclude_globs`.
- **Don't pack `node_modules/` or `.venv/`.** Dependency manifests
  (P3-R79) cover reproducibility; the actual installed packages are
  derivable. Including them inflates ZIP size by 100×.
- **`evidence/` is mandatory.** A submission without
  `evidence/oscal/by-control/<10 fragments>` fails P3-R94. The OSCAL
  fragments must reference the running prototype, not a stale
  pre-deploy build (cross-check against `cato-evidence-validator`'s
  `--phase3-acceptance` mode).
- **The narrative .pdf is the fallback for P3-R61, but must be
  searchable.** Some Word-to-PDF exporters dither inline images and
  the resulting PDF fails text-selection. Use `pandoc` with
  `--pdf-engine=xelatex` for guaranteed selectable output.
- **Rerunnable script is a deadline-recovery tool.** On Day 12.5 at
  7AM ET, if the validator FAILs the HDD, the team has roughly 4
  hours to repack and re-courier. The packing script must run
  in < 30 minutes on the team laptop. If packing takes 2+ hours,
  the team has under 2 hours to fix and revalidate — too tight.
  Pre-warm the packing script on Day 11 evening so Day 12.5 is a
  one-command run.
- **Don't run packing through CI.** GitHub Actions runners don't have
  the candidate HDD mounted. Run packing locally on a team laptop
  with the HDD physically attached.
- **No emoji in EVIDENCE-INDEX.md or README.md.** PDF rendering of
  emojis on FAA workstations is unreliable (Calibri may not have the
  glyphs, fallback fonts vary). Use ASCII checkmarks (`[x]`) only
  if needed; bare prose is preferred.
- **Don't copy the runbook into Folder 2.** The oral runbook is
  internal; it is NOT in the SF2 deliverable list. Including it
  exposes presenter notes to the FAA evaluator and introduces a
  P3-R5.2 contradiction surface (runbook mentions fallback MP4s; the
  prototype claims live demo).

## References

- Closes Phase 3 requirements: P3-R78 (config files), R79 (dep
  manifests via inclusion check), R80 (build scripts), R82
  (Dockerfiles via inclusion check), R83 (config-management),
  R84 (README at root), R85 (env setup), R86 (dep resolution),
  R87 (run instructions), R88 (independent FAA review), R89
  (pipeline output evidence packaging), R90 (deploy evidence
  packaging), R91 (IaC provision evidence packaging), R92 (security
  outputs packaging), R93 (monitoring/logging evidence), R94
  (compliance evidence packaging), R95 (single primary dir), R96
  (root README + index), R97 (single ZIP), R98 (HDD root layout),
  R101 (HDD physical-delivery preparation), R115 (license audit).
- Mitigates Risk 5.3 (HDD physical delivery deadline).
- Phase 2 grounding: minimal — this skill is logistics-bound. The
  evidence it packages traces to all Phase 2 §B/§F sections via
  the OSCAL fragments and capability map.
- Build plan: `docs/phase3/build-demo-skills-plan.md` §4 D6 (this
  skill); §6 Day 11 first dry-run, Day 12 cut, Day 12.5 final
  validation.
- Gap matrix: `docs/phase3/skills-gap-matrix.md` §4 NEW-5; §6 RISK-6.
- Adjacent skills:
  - `phase-commitment-traceback` — produces the .docx and .pdf this
    skill stages into Folder 1.
  - `devsecops-pipeline-generator` — produces the workflow YAML and
    `evidence/pipeline-run-summary.json` this skill verifies.
  - `cato-compliance` (EDIT-1) — produces the OSCAL fragments this
    skill expects under `evidence/oscal/`.
  - `cato-evidence-validator` (EDIT-5) — runs the per-control
    pass/fail check on the evidence bundle before packaging.
  - `security-scan-review` (EDIT-7) — produces the normalized
    `evidence/security-evidence/` bundle this skill includes.
  - `docx` (Anthropic skill) — fallback README.pdf renderer.

## Anti-patterns

- **Do not** assume the validator's PASS verdict on Day 11 is durable.
  Re-run on Day 12 and Day 12.5; CI may have produced new artifacts
  that need to be picked up, or a late commit may have introduced a
  secret.
- **Do not** silently rename a folder if a typo is found ("Code and
  Technical Artifact" missing the s) — fail loud and force a human
  decision. Auto-renaming on a deadline-bound deliverable is the
  classic foot-gun.
- **Do not** include the team's `.git-credentials` or
  `~/.aws/credentials` even by accident — the exclude_globs list
  catches the obvious cases, but `git diff` of staging on Day 11 is
  a manual must-do.
- **Do not** use `tar.gz` instead of ZIP. P3-R97 says ZIP. tar.gz on
  a Windows-default FAA workstation requires extra tooling.
- **Do not** pack the runbook (`runbook/runbook.md`,
  `runbook/qa-pack.md`) into Folder 2 ever. These are internal-only.
- **Do not** include any reference to BASE-C or Bedrock in
  README.md, EVIDENCE-INDEX.md, or compliance-report.md. The only
  place either is named in the entire submission is the written
  narrative §6 deviation paragraph.
