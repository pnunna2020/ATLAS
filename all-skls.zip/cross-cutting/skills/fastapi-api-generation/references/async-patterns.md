# Async, Dependency Injection, and Pydantic v2 Patterns

Patterns used by generated `app.api`, `app.application`, and `app.infrastructure`
code. All examples assume Python 3.12, FastAPI 0.115+, Pydantic v2, and
SQLAlchemy 2.x async.

## `async def` Everywhere

Every FastAPI route handler, service method, and repository method is
`async def`. Synchronous (`def`) route handlers are executed in a threadpool;
mixing them with `async def` routes hides which endpoints can actually run
concurrently. The generator emits `async def` uniformly.

```python
from fastapi import APIRouter, Depends, status

from app.<context>.api.schemas import FlightResponse, CreateFlightRequest
from app.<context>.application.services import FlightScheduleService
from app.dependencies import get_flight_service

router = APIRouter(prefix="/flights", tags=["flights"])


@router.post(
    "",
    response_model=FlightResponse,
    status_code=status.HTTP_201_CREATED,
    summary="Create a flight schedule",
)
async def create_flight(
    payload: CreateFlightRequest,
    service: FlightScheduleService = Depends(get_flight_service),
) -> FlightResponse:
    """Create a flight schedule. Implements rule: RULE-FS-001."""
    flight = await service.create(payload)
    return FlightResponse.model_validate(flight)
```

### Banned synchronous calls in `async def` bodies

- `requests.get / post` -> use `httpx.AsyncClient`
- `psycopg2`, `pymssql` -> use SQLAlchemy async + `asyncpg` / `aioodbc`
- `time.sleep` -> `await asyncio.sleep(...)`
- `open(...).read()` for large files -> `aiofiles`
- `subprocess.run` -> `await asyncio.create_subprocess_exec(...)`

If a sync call is unavoidable (e.g., a CPU-bound library), wrap it:

```python
from starlette.concurrency import run_in_threadpool

result = await run_in_threadpool(cpu_bound_function, *args)
```

## Dependency Injection via `Depends`

All collaborators (DB session, settings, service instances, current user)
are passed via `Depends(...)`. This is the seam tests use.

### Layered dependencies

```python
# app/dependencies.py (additions)
from fastapi import Depends
from sqlalchemy.ext.asyncio import AsyncSession

from app.<context>.application.services import FlightScheduleService
from app.<context>.infrastructure.repository import SqlAlchemyFlightRepository


async def get_flight_repository(
    session: AsyncSession = Depends(get_db),
) -> SqlAlchemyFlightRepository:
    return SqlAlchemyFlightRepository(session)


async def get_flight_service(
    repo: SqlAlchemyFlightRepository = Depends(get_flight_repository),
) -> FlightScheduleService:
    return FlightScheduleService(repo)
```

Router code calls only `Depends(get_flight_service)`. The chain from session
-> repository -> service is assembled inside `dependencies.py`, keeping the
router testable.

### Dependency overrides in tests

```python
# tests/conftest.py
from collections.abc import AsyncIterator

import pytest_asyncio
from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker, create_async_engine

from app.dependencies import get_db
from app.main import app


@pytest_asyncio.fixture
async def test_session() -> AsyncIterator[AsyncSession]:
    engine = create_async_engine("sqlite+aiosqlite:///:memory:")
    async with async_sessionmaker(engine, expire_on_commit=False)() as session:
        yield session


@pytest_asyncio.fixture
async def client(test_session: AsyncSession) -> AsyncIterator[object]:
    async def _override() -> AsyncIterator[AsyncSession]:
        yield test_session

    app.dependency_overrides[get_db] = _override
    yield app
    app.dependency_overrides.clear()
```

See `pytest-asyncio-patterns.md` for the `httpx.AsyncClient` wiring that
follows.

## Lifespan Events (NOT `@app.on_event`)

FastAPI 0.110+ deprecated `@app.on_event("startup" | "shutdown")`. The
generator uses `lifespan` contexts exclusively.

```python
from contextlib import asynccontextmanager
from collections.abc import AsyncIterator

from fastapi import FastAPI
from sqlalchemy.ext.asyncio import create_async_engine

from app.dependencies import _session_factory
from app.settings import Settings


@asynccontextmanager
async def lifespan(app: FastAPI) -> AsyncIterator[None]:
    settings = Settings()
    # Warm the engine / pool
    _session_factory()
    # Start background workers, connect message bus, etc.
    yield
    # Dispose engine, close clients, shut down workers
    engine = _session_factory().kw["bind"]
    await engine.dispose()


app = FastAPI(lifespan=lifespan)
```

Startup cost (pool warmup, schema check, cache prime) belongs in `lifespan`
before `yield`. Teardown cost (pool dispose, flush sinks) belongs after
`yield`.

## Background Tasks

Use `BackgroundTasks` for short, fire-and-forget work that must run *after*
the response is sent but does not need durability:

```python
from fastapi import BackgroundTasks


@router.post("/flights", status_code=201)
async def create_flight(
    payload: CreateFlightRequest,
    background: BackgroundTasks,
    service: FlightScheduleService = Depends(get_flight_service),
) -> FlightResponse:
    flight = await service.create(payload)
    background.add_task(service.publish_created_event, flight.id)
    return FlightResponse.model_validate(flight)
```

If the work must survive a pod restart, use a durable outbox / message
queue; do not rely on `BackgroundTasks`.

## Pydantic v2 Request / Response Models

Every request and response body is a Pydantic v2 model. Generator rules:

1. Inherit from `BaseModel`.
2. Use `model_config = ConfigDict(...)` rather than an inner `Config` class.
3. Use `@field_validator("field")` rather than `@validator("field")`.
4. Use `.model_dump()` / `.model_validate()` rather than `.dict()` /
   `.parse_obj()`.
5. For response schemas that map from ORM rows, set
   `model_config = ConfigDict(from_attributes=True)` and call
   `.model_validate(orm_row)`.
6. For mutation-free types, set `frozen=True` in the `ConfigDict`.

```python
from datetime import date
from typing import Annotated

from pydantic import BaseModel, ConfigDict, Field, field_validator


class CreateFlightRequest(BaseModel):
    """Input payload for POST /flights. Implements rule RULE-FS-002."""

    model_config = ConfigDict(extra="forbid", str_strip_whitespace=True)

    flight_number: Annotated[str, Field(min_length=3, max_length=8)]
    origin: Annotated[str, Field(min_length=3, max_length=4)]
    destination: Annotated[str, Field(min_length=3, max_length=4)]
    departure_date: date

    @field_validator("origin", "destination")
    @classmethod
    def uppercase_iata(cls, v: str) -> str:
        return v.upper()

    @field_validator("destination")
    @classmethod
    def origin_not_destination(cls, v: str, info) -> str:
        origin = info.data.get("origin")
        if origin and origin.upper() == v.upper():
            raise ValueError("origin must not equal destination")
        return v


class FlightResponse(BaseModel):
    """Response payload for Flight endpoints."""

    model_config = ConfigDict(from_attributes=True, frozen=True)

    id: str
    flight_number: str
    origin: str
    destination: str
    departure_date: date
    created_at: date
```

### Discriminated unions for polymorphic payloads

Pydantic v2's `Discriminator` + `Tag` replaces the v1 `Literal` hack:

```python
from typing import Annotated, Literal, Union

from pydantic import BaseModel, Discriminator, Tag


class ScheduledEvent(BaseModel):
    kind: Literal["scheduled"] = "scheduled"
    scheduled_at: date


class CancelledEvent(BaseModel):
    kind: Literal["cancelled"] = "cancelled"
    cancelled_at: date
    reason: str


FlightEvent = Annotated[
    Union[
        Annotated[ScheduledEvent, Tag("scheduled")],
        Annotated[CancelledEvent, Tag("cancelled")],
    ],
    Discriminator("kind"),
]
```

## SQLAlchemy 2.x Async Patterns

Generated models use the typed `Mapped[...]` style:

```python
from datetime import datetime
from uuid import UUID, uuid4

from sqlalchemy import String, UniqueConstraint
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column, relationship


class Base(DeclarativeBase):
    pass


class FlightSchedule(Base):
    __tablename__ = "flight_schedule"
    __table_args__ = (UniqueConstraint("flight_number", "departure_date"),)

    id: Mapped[UUID] = mapped_column(primary_key=True, default=uuid4)
    flight_number: Mapped[str] = mapped_column(String(8))
    origin: Mapped[str] = mapped_column(String(4))
    destination: Mapped[str] = mapped_column(String(4))
    created_at: Mapped[datetime]
    updated_at: Mapped[datetime]

    legs: Mapped[list["FlightLeg"]] = relationship(
        back_populates="schedule",
        lazy="raise",        # forces explicit loading
        cascade="all, delete-orphan",
    )
```

`lazy="raise"` turns accidental N+1 loads into errors. Use
`selectinload()` or `joinedload()` when loading relationships explicitly.

### Async repositories

```python
from collections.abc import Sequence
from uuid import UUID

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import selectinload

from app.<context>.infrastructure.models import FlightSchedule


class SqlAlchemyFlightRepository:
    def __init__(self, session: AsyncSession) -> None:
        self._session = session

    async def add(self, flight: FlightSchedule) -> None:
        self._session.add(flight)
        await self._session.flush()

    async def get(self, id: UUID) -> FlightSchedule | None:
        stmt = (
            select(FlightSchedule)
            .options(selectinload(FlightSchedule.legs))
            .where(FlightSchedule.id == id)
        )
        return (await self._session.execute(stmt)).scalar_one_or_none()

    async def list_active(self, limit: int, offset: int) -> Sequence[FlightSchedule]:
        stmt = (
            select(FlightSchedule)
            .order_by(FlightSchedule.departure_date)
            .limit(limit)
            .offset(offset)
        )
        return (await self._session.execute(stmt)).scalars().all()
```

### Transaction scope

The application service owns the transaction, not the repository or the
router:

```python
class FlightScheduleService:
    def __init__(self, repo: SqlAlchemyFlightRepository) -> None:
        self._repo = repo

    async def create(self, payload: CreateFlightRequest) -> FlightSchedule:
        """Implements rule RULE-FS-003 (duplicate-prevention + audit)."""
        flight = FlightSchedule(
            flight_number=payload.flight_number,
            origin=payload.origin,
            destination=payload.destination,
            departure_date=payload.departure_date,
        )
        async with self._repo._session.begin():
            await self._repo.add(flight)
        return flight
```

`async with session.begin()` opens, commits on success, and rolls back on
exception — the generator always uses this form for write paths.

## Structured Logging with `structlog`

```python
# app/logging_config.py
import logging
import sys

import structlog


def configure_logging(level: str = "INFO") -> None:
    logging.basicConfig(
        format="%(message)s",
        stream=sys.stdout,
        level=level,
    )
    structlog.configure(
        processors=[
            structlog.contextvars.merge_contextvars,
            structlog.processors.add_log_level,
            structlog.processors.TimeStamper(fmt="iso", utc=True),
            structlog.processors.dict_tracebacks,
            structlog.processors.JSONRenderer(),
        ],
        wrapper_class=structlog.make_filtering_bound_logger(logging.getLevelName(level)),
        context_class=dict,
        logger_factory=structlog.PrintLoggerFactory(),
        cache_logger_on_first_use=True,
    )


log = structlog.get_logger()
```

Correlation ID middleware pushes per-request context:

```python
# app/middleware/correlation_id.py
import uuid

import structlog
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.requests import Request
from starlette.responses import Response


class CorrelationIdMiddleware(BaseHTTPMiddleware):
    async def dispatch(self, request: Request, call_next) -> Response:
        header = request.headers.get("X-Correlation-Id") or uuid.uuid4().hex
        structlog.contextvars.bind_contextvars(correlation_id=header, path=request.url.path)
        try:
            response = await call_next(request)
        finally:
            structlog.contextvars.clear_contextvars()
        response.headers["X-Correlation-Id"] = header
        return response
```

## RFC 7807 Problem Details Exception Handler

```python
# app/middleware/exception_handler.py
from fastapi.exceptions import RequestValidationError
from fastapi.responses import JSONResponse
from starlette.requests import Request

from app.<context>.domain.errors import DomainError


async def validation_error_handler(
    request: Request,
    exc: RequestValidationError,
) -> JSONResponse:
    return JSONResponse(
        status_code=422,
        media_type="application/problem+json",
        content={
            "type": "https://<module>/errors/validation",
            "title": "Validation failed",
            "status": 422,
            "detail": "One or more fields failed validation.",
            "instance": str(request.url),
            "errors": exc.errors(),
        },
    )


async def domain_error_handler(request: Request, exc: Exception) -> JSONResponse:
    if isinstance(exc, DomainError):
        return JSONResponse(
            status_code=exc.status_code,
            media_type="application/problem+json",
            content={
                "type": f"https://<module>/errors/{exc.code}",
                "title": exc.title,
                "status": exc.status_code,
                "detail": str(exc),
                "instance": str(request.url),
            },
        )
    # Unknown: 500 with no stack trace in the body
    return JSONResponse(
        status_code=500,
        media_type="application/problem+json",
        content={
            "type": "https://<module>/errors/internal",
            "title": "Internal server error",
            "status": 500,
            "detail": "An unexpected error occurred.",
            "instance": str(request.url),
        },
    )
```

## OIDC / JWT Bearer (OKTA-compatible)

```python
# app/auth/oidc.py
from fastapi import Depends, HTTPException, status
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
from jose import JWTError, jwt

from app.dependencies import get_settings
from app.settings import Settings


_bearer = HTTPBearer(auto_error=True)


async def verify_jwt(
    credentials: HTTPAuthorizationCredentials = Depends(_bearer),
    settings: Settings = Depends(get_settings),
) -> dict:
    """Validate an OKTA-issued JWT. Returns decoded claims."""
    try:
        claims = jwt.decode(
            credentials.credentials,
            key=_jwks_for(settings.oidc_issuer),
            audience=settings.oidc_audience,
            issuer=settings.oidc_issuer,
            options={"verify_aud": True, "verify_iss": True},
        )
    except JWTError as exc:
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, detail=str(exc)) from exc
    return claims
```

Routers that need auth declare `verify_jwt` as a dependency:

```python
@router.post("/flights", dependencies=[Depends(verify_jwt)])
async def create_flight(...): ...
```

For scope / role checks, layer a second dependency on top of `verify_jwt`.

## Do / Don't

| Do                                           | Don't                                    |
|----------------------------------------------|------------------------------------------|
| `async def` every route and service method  | Mix `def` / `async def` on the same router |
| Inject DB session via `Depends(get_db)`     | Import a module-level engine / session  |
| Use `.model_dump()` / `.model_validate()`    | Use v1 `.dict()` / `.parse_obj()`       |
| `lazy="raise"` + explicit `selectinload`     | Rely on lazy relationship loading        |
| `async with session.begin()` in service      | Open transactions in the router          |
| Emit structured JSON via `structlog`         | `print()` or `logging.info(f"...")`     |
| Read secrets via `pydantic-settings`         | Hardcode in `settings.toml` or code     |
| `lifespan` for startup / shutdown            | `@app.on_event("startup")`               |
