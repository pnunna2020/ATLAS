# pytest-asyncio Test Patterns

Standard for `tests/unit/` and `tests/integration/`. Stack: pytest 8 +
pytest-asyncio 0.24 + httpx 0.27 + respx (for outbound HTTP mocks).

## Asyncio Mode

The generator pins `asyncio_mode = "auto"` in `pyproject.toml` so every
`async def` test function is automatically wrapped. No
`@pytest.mark.asyncio` decorator is required.

```toml
[tool.pytest.ini_options]
asyncio_mode = "auto"
testpaths = ["tests"]
```

This choice is deliberate: forgetting the marker produces a silent no-op
test (`PASSED` with zero assertions executed). `asyncio_mode = "auto"` is
the mode recommended for new projects.

## Test Naming

All test function names follow `test_<scenario>_<condition>_<expected>`.
Test files follow `test_<module_under_test>.py`. Test classes are avoided —
pytest discovers functions directly.

- `test_create_flight_with_valid_payload_returns_201`
- `test_list_flights_with_no_filter_returns_all_active`
- `test_flight_service_rejects_duplicate_flight_number`

## Fixture Layout

`tests/conftest.py` owns every shared fixture. Per-context test directories
may add a `conftest.py` for context-scoped fixtures.

```python
# tests/conftest.py
from __future__ import annotations

from collections.abc import AsyncIterator

import pytest
import pytest_asyncio
from httpx import ASGITransport, AsyncClient
from sqlalchemy.ext.asyncio import (
    AsyncSession,
    async_sessionmaker,
    create_async_engine,
)

from app.dependencies import get_db, get_settings
from app.infrastructure.base import Base
from app.main import app
from app.settings import Settings


@pytest.fixture(scope="session")
def event_loop_policy():
    """Keep default asyncio policy; override per-platform if needed."""
    import asyncio

    return asyncio.DefaultEventLoopPolicy()


@pytest_asyncio.fixture
async def test_engine():
    """Fresh in-memory SQLite engine per test. Schemas are created on the fly."""
    engine = create_async_engine("sqlite+aiosqlite:///:memory:")
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)
    yield engine
    await engine.dispose()


@pytest_asyncio.fixture
async def test_session(test_engine) -> AsyncIterator[AsyncSession]:
    factory = async_sessionmaker(test_engine, expire_on_commit=False)
    async with factory() as session:
        yield session


@pytest.fixture
def test_settings() -> Settings:
    return Settings(
        APP_ENV="test",
        APP_DATABASE_URL="sqlite+aiosqlite:///:memory:",
        APP_OIDC_ISSUER="https://test.okta.com",
        APP_OIDC_CLIENT_ID="test-client",
        APP_OIDC_CLIENT_SECRET="test-secret",
        APP_OIDC_AUDIENCE="api://test",
    )


@pytest_asyncio.fixture
async def client(test_session: AsyncSession, test_settings: Settings) -> AsyncIterator[AsyncClient]:
    """ASGI client bound to the test session + test settings.

    Uses httpx's ASGITransport so we bypass the network entirely and still
    exercise the real FastAPI lifespan + middleware stack.
    """

    async def _override_db() -> AsyncIterator[AsyncSession]:
        yield test_session

    def _override_settings() -> Settings:
        return test_settings

    app.dependency_overrides[get_db] = _override_db
    app.dependency_overrides[get_settings] = _override_settings

    transport = ASGITransport(app=app)
    async with AsyncClient(transport=transport, base_url="http://testserver") as ac:
        yield ac

    app.dependency_overrides.clear()
```

## Integration Test Shape

```python
# tests/integration/flights/test_flights_router.py
from datetime import date

import pytest
from httpx import AsyncClient


async def test_post_flights_with_valid_payload_returns_201(client: AsyncClient) -> None:
    # Arrange
    payload = {
        "flight_number": "AA100",
        "origin": "JFK",
        "destination": "LAX",
        "departure_date": date.today().isoformat(),
    }

    # Act
    response = await client.post("/api/v1/flights", json=payload)

    # Assert
    assert response.status_code == 201
    body = response.json()
    assert body["flight_number"] == "AA100"
    assert body["origin"] == "JFK"
    assert body["destination"] == "LAX"


async def test_post_flights_with_same_origin_destination_returns_422(
    client: AsyncClient,
) -> None:
    payload = {
        "flight_number": "AA100",
        "origin": "JFK",
        "destination": "JFK",
        "departure_date": date.today().isoformat(),
    }

    response = await client.post("/api/v1/flights", json=payload)

    assert response.status_code == 422
    problem = response.json()
    assert problem["type"].endswith("/validation")
    assert any("origin must not equal destination" in str(e) for e in problem["errors"])
```

Arrange / Act / Assert sections separated by a blank line. No single-line
tests — intent matters more than brevity.

## Unit Test Shape

Unit tests exercise domain + application logic without touching FastAPI,
SQLAlchemy, or the network. A repository is substituted via a fake.

```python
# tests/unit/flights/test_flight_service.py
from dataclasses import dataclass, field
from uuid import UUID, uuid4

import pytest

from app.<context>.application.services import FlightScheduleService
from app.<context>.api.schemas import CreateFlightRequest
from app.<context>.domain.errors import DuplicateFlightError
from app.<context>.infrastructure.models import FlightSchedule


@dataclass
class FakeFlightRepository:
    """In-memory repository double for unit tests."""

    _rows: dict[UUID, FlightSchedule] = field(default_factory=dict)

    async def add(self, flight: FlightSchedule) -> None:
        self._rows[flight.id] = flight

    async def get(self, id: UUID) -> FlightSchedule | None:
        return self._rows.get(id)

    async def find_by_number_and_date(
        self, flight_number: str, departure_date
    ) -> FlightSchedule | None:
        return next(
            (f for f in self._rows.values()
             if f.flight_number == flight_number and f.departure_date == departure_date),
            None,
        )


async def test_create_flight_with_unique_payload_persists_flight() -> None:
    repo = FakeFlightRepository()
    service = FlightScheduleService(repo)
    payload = CreateFlightRequest(
        flight_number="AA100", origin="JFK", destination="LAX",
        departure_date=__import__("datetime").date.today(),
    )

    result = await service.create(payload)

    assert result.flight_number == "AA100"
    assert result.id in repo._rows


async def test_create_flight_with_duplicate_raises_domain_error() -> None:
    repo = FakeFlightRepository()
    existing = FlightSchedule(
        id=uuid4(), flight_number="AA100", origin="JFK", destination="LAX",
        departure_date=__import__("datetime").date.today(),
    )
    repo._rows[existing.id] = existing
    service = FlightScheduleService(repo)
    payload = CreateFlightRequest(
        flight_number="AA100", origin="JFK", destination="LAX",
        departure_date=existing.departure_date,
    )

    with pytest.raises(DuplicateFlightError):
        await service.create(payload)
```

Unit tests stay fast: no Postgres container, no ASGI app, no `AsyncClient`.

## Mocking Outbound HTTP with respx

```python
# tests/integration/flights/test_external_notifier.py
import httpx
import pytest
import respx
from httpx import AsyncClient


@respx.mock
async def test_create_flight_calls_notification_service(client: AsyncClient) -> None:
    route = respx.post("https://notify.test/flights").mock(
        return_value=httpx.Response(202, json={"status": "queued"})
    )

    response = await client.post(
        "/api/v1/flights",
        json={
            "flight_number": "AA100",
            "origin": "JFK",
            "destination": "LAX",
            "departure_date": "2026-05-01",
        },
    )

    assert response.status_code == 201
    assert route.called
    call = route.calls.last
    assert call.request.json() == {"flight_id": response.json()["id"]}
```

respx intercepts `httpx.AsyncClient` calls at the transport level, so the
test never touches the network.

## Overriding Async Dependencies

`app.dependency_overrides` maps a dependency callable to any callable (sync
or async, returning directly or yielding). Rules:

1. If the real dependency is `async def` and yields (e.g. `get_db`), the
   override must also be async and yield.
2. If the real dependency is `async def` and returns, override can be a
   plain `def` that returns the same shape.
3. Always call `app.dependency_overrides.clear()` in a fixture teardown to
   prevent bleed between tests.

```python
# Override a yielding async dependency
async def _override_db() -> AsyncIterator[AsyncSession]:
    yield test_session

app.dependency_overrides[get_db] = _override_db

# Override a plain async dependency
async def _override_verify() -> dict:
    return {"sub": "test-user", "roles": ["admin"]}

app.dependency_overrides[verify_jwt] = _override_verify
```

## Bypassing Auth in Tests

For integration tests that do not exercise auth-policy code, stub
`verify_jwt` to return a canned claims dict:

```python
# tests/conftest.py (addition)
from app.auth.oidc import verify_jwt


@pytest.fixture(autouse=True)
def _bypass_auth():
    async def _claims() -> dict:
        return {"sub": "test-user", "roles": ["flight_ops"]}

    app.dependency_overrides[verify_jwt] = _claims
    yield
    app.dependency_overrides.pop(verify_jwt, None)
```

For the auth suite itself, do not autouse this fixture — exercise the real
dependency with known-good / known-bad tokens.

## Parametrization

`@pytest.mark.parametrize` is the Python equivalent of xUnit's
`[InlineData]` / `[Theory]`. Prefer it over loops inside a single test.

```python
import pytest


@pytest.mark.parametrize(
    "input_code, expected_valid",
    [
        ("AA1", True),
        ("BA9999", True),
        ("", False),
        (None, False),
        ("12345", False),
    ],
)
def test_flight_number_validator_returns_expected(input_code: str | None, expected_valid: bool) -> None:
    from app.<context>.domain.entities import is_valid_flight_number

    assert is_valid_flight_number(input_code) is expected_valid
```

## Database Per Test vs Session Per Test

Two common strategies:

| Strategy            | How                                                                        | When to use                           |
|---------------------|----------------------------------------------------------------------------|---------------------------------------|
| Database per test   | SQLite `:memory:` engine in a fresh `test_engine` fixture                  | Default; fastest; unit + integration  |
| Postgres container  | `testcontainers-python` spins up Postgres per session; Alembic creates schema once; each test runs in a savepoint that rolls back | When dialect-specific SQL must be exercised (jsonb, GIN indexes, stored procedures) |

The generator picks SQLite by default and emits a Postgres-container fixture
only when the target-database profile specifies Postgres-specific features.

Postgres-container fixture skeleton:

```python
# tests/conftest.py (when database=postgresql)
import pytest_asyncio
from sqlalchemy.ext.asyncio import create_async_engine
from testcontainers.postgres import PostgresContainer


@pytest_asyncio.fixture(scope="session")
async def postgres_container():
    with PostgresContainer("postgres:16-alpine") as pg:
        yield pg


@pytest_asyncio.fixture(scope="session")
async def test_engine(postgres_container):
    url = postgres_container.get_connection_url().replace(
        "postgresql+psycopg2", "postgresql+asyncpg"
    )
    engine = create_async_engine(url)
    async with engine.begin() as conn:
        from app.infrastructure.base import Base
        await conn.run_sync(Base.metadata.create_all)
    yield engine
    await engine.dispose()
```

## Cancellation and Timeouts

Route handlers can be cancelled mid-request when the client disconnects.
Service methods should accept and propagate cancellation. Tests assert
that cancellation closes resources:

```python
import asyncio

import pytest


async def test_long_running_operation_cancels_cleanly(service) -> None:
    task = asyncio.create_task(service.long_running_operation())
    await asyncio.sleep(0)       # let the task start
    task.cancel()

    with pytest.raises(asyncio.CancelledError):
        await task
```

## What NOT to Test

- Framework behavior (model binding, routing) — covered by FastAPI's own
  tests.
- SQLAlchemy internals — exercise the DB round-trip, not expression trees.
- Third-party libraries — assert on outputs, not on call counts against
  stable third-party APIs.
- `@lru_cache`-wrapped loaders — they are effectively singletons; test the
  underlying factory function directly.

## Do / Don't

| Do                                                    | Don't                                           |
|-------------------------------------------------------|-------------------------------------------------|
| `async def` test functions with `asyncio_mode=auto`  | Sync test functions calling `.result()` on coros |
| One fake repository per context for unit tests       | Mock SQLAlchemy `Session` with `MagicMock`     |
| `ASGITransport(app=app)` for integration tests       | Run `uvicorn` in a subprocess for tests         |
| `respx` for outbound httpx                            | Monkeypatch `httpx.Client` directly             |
| `app.dependency_overrides[dep] = fake` + clear        | Patch module-level globals                      |
| `pytest.mark.parametrize` for case tables             | Loops inside a single test                      |
| Fresh DB per test (SQLite `:memory:`)                | Shared dev Postgres                             |
