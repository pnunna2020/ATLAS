# FastAPI Project Structure Reference

This reference defines the package layout, module naming, dependency direction,
`pyproject.toml` pinning, and Docker conventions used by the
`fastapi-api-generation` skill.

## Clean Layering

The generated project enforces an inward dependency rule mirroring the
Spring Boot and .NET layering: outer layers depend on inner layers, never the
reverse.

```
app.api  ->  app.application  ->  app.domain
                  ^                    ^
                  |                    |
           app.infrastructure  --------+
```

| Layer             | Knows About                                 | Imports From                                    |
|-------------------|---------------------------------------------|-------------------------------------------------|
| `app.domain`      | Nothing else                                | stdlib only (dataclasses, datetime, enum, uuid) |
| `app.application` | `app.domain`                                | `app.domain`                                    |
| `app.infrastructure` | `app.domain` + external tech (SQLAlchemy, httpx, boto3) | `app.domain`, `app.application` (interface impls only) |
| `app.api`         | `app.application` + cross-cutting (auth, logging) | `app.application`, `app.infrastructure` (composition root only) |

The `app.domain` package imports only from the standard library and Pydantic
v2. It must not import SQLAlchemy, FastAPI, httpx, or any ORM / IO library.

## Top-Level Layout

```
<project>/
  pyproject.toml                # PEP 621 metadata + pinned deps
  poetry.lock / uv.lock         # one and only one lockfile
  README.md
  Dockerfile                    # multi-stage, non-root
  docker-compose.yml            # local dev: api + postgres
  .env.example                  # documented env vars (NO secrets)
  .dockerignore
  .gitignore
  .ruff.toml                    # or ruff section in pyproject.toml
  alembic.ini
  alembic/
    env.py
    script.py.mako
    versions/
      2026_05_01_0001_initial.py
  app/
    __init__.py
    main.py                     # FastAPI() factory + lifespan + router wiring
    dependencies.py             # shared Depends(...) callables
    settings.py                 # pydantic-settings Settings class
    logging_config.py           # structlog wire-up
    middleware/
      __init__.py
      correlation_id.py
      exception_handler.py
    auth/
      __init__.py
      oidc.py                   # OKTA / JWT bearer validation
      security.py               # fastapi.security.HTTPBearer dependency
    <context>/                  # one package per bounded context
      __init__.py
      api/
        __init__.py
        router.py               # APIRouter for the context
        schemas.py              # Pydantic v2 request/response models
      application/
        __init__.py
        services.py             # use-case orchestrators (async)
        commands.py             # command dataclasses / Pydantic models
        queries.py              # query dataclasses / Pydantic models
      domain/
        __init__.py
        entities.py             # pure-Python aggregates / value objects
        events.py               # frozen Pydantic event models
        errors.py               # domain-specific exceptions
      infrastructure/
        __init__.py
        models.py               # SQLAlchemy 2.x declarative models
        repository.py           # async repository implementations
  tests/
    __init__.py
    conftest.py                 # shared fixtures (db, client, settings)
    unit/
      __init__.py
      <context>/
        test_services.py
        test_domain.py
    integration/
      __init__.py
      <context>/
        test_router.py          # httpx.AsyncClient against ASGI app
```

Per-context packages (`app/<context>/`) keep domain, application, API, and
infrastructure concerns co-located so a new bounded context is a single
directory to add or remove.

## `pyproject.toml` (PEP 621 + Ruff + Mypy + pytest-asyncio)

```toml
[project]
name = "<module>"
version = "0.1.0"
description = "<Module> modernized API"
requires-python = ">=3.12,<3.13"
dependencies = [
    "fastapi==0.115.4",
    "uvicorn[standard]==0.32.0",
    "pydantic==2.9.2",
    "pydantic-settings==2.6.1",
    "sqlalchemy[asyncio]==2.0.36",
    "asyncpg==0.30.0",
    "alembic==1.13.3",
    "httpx==0.27.2",
    "structlog==24.4.0",
    "python-jose[cryptography]==3.3.0",
    "authlib==1.3.2",
]

[project.optional-dependencies]
dev = [
    "pytest==8.3.3",
    "pytest-asyncio==0.24.0",
    "pytest-cov==5.0.0",
    "ruff==0.7.2",
    "mypy==1.13.0",
    "types-python-jose==3.3.4.20240106",
    "respx==0.21.1",
    "aiosqlite==0.20.0",
]

[tool.pytest.ini_options]
asyncio_mode = "auto"
testpaths = ["tests"]
addopts = "-ra --strict-markers"

[tool.ruff]
line-length = 100
target-version = "py312"

[tool.ruff.lint]
select = ["E", "F", "W", "I", "B", "UP", "RUF", "ASYNC", "S", "SIM"]
ignore = ["S101"]  # pytest uses assert

[tool.mypy]
python_version = "3.12"
strict = true
plugins = ["pydantic.mypy"]

[[tool.mypy.overrides]]
module = ["alembic.*", "authlib.*"]
ignore_missing_imports = true
```

Pin every direct dependency exactly. Upgrades are deliberate PRs with the
`deps:` conventional-commit prefix.

## `app/main.py` Skeleton

```python
from contextlib import asynccontextmanager
from collections.abc import AsyncIterator

from fastapi import FastAPI
from fastapi.exceptions import RequestValidationError

from app.auth.oidc import verify_jwt
from app.dependencies import get_settings
from app.logging_config import configure_logging
from app.middleware.correlation_id import CorrelationIdMiddleware
from app.middleware.exception_handler import (
    domain_error_handler,
    validation_error_handler,
)
from app.settings import Settings
from app.<context>.api.router import router as <context>_router


@asynccontextmanager
async def lifespan(app: FastAPI) -> AsyncIterator[None]:
    """Application startup / shutdown hooks.

    Startup: configure logging, warm connection pools.
    Shutdown: dispose engine, flush outbound queues.
    """
    settings: Settings = get_settings()
    configure_logging(settings.log_level)
    # Warm DB pool, cache clients, etc.
    yield
    # Dispose engine, close clients, etc.


def create_app() -> FastAPI:
    app = FastAPI(
        title="<Module> API",
        version="0.1.0",
        lifespan=lifespan,
        docs_url="/docs",
        redoc_url="/redoc",
        openapi_url="/openapi.json",
    )
    app.add_middleware(CorrelationIdMiddleware)
    app.add_exception_handler(RequestValidationError, validation_error_handler)
    app.add_exception_handler(Exception, domain_error_handler)

    app.include_router(<context>_router, prefix="/api/v1")

    return app


app = create_app()
```

## `app/dependencies.py` Skeleton

```python
from collections.abc import AsyncIterator
from functools import lru_cache

from fastapi import Depends
from sqlalchemy.ext.asyncio import (
    AsyncSession,
    async_sessionmaker,
    create_async_engine,
)

from app.settings import Settings


@lru_cache(maxsize=1)
def get_settings() -> Settings:
    """Singleton settings loader. Cached because pydantic-settings
    re-parses the environment on every instantiation."""
    return Settings()


@lru_cache(maxsize=1)
def _session_factory() -> async_sessionmaker[AsyncSession]:
    settings = get_settings()
    engine = create_async_engine(
        settings.database_url,
        echo=False,
        pool_pre_ping=True,
        pool_size=10,
        max_overflow=20,
    )
    return async_sessionmaker(engine, expire_on_commit=False)


async def get_db() -> AsyncIterator[AsyncSession]:
    """Request-scoped DB session. Yields then always closes."""
    factory = _session_factory()
    async with factory() as session:
        yield session
```

## `app/settings.py` (pydantic-settings)

```python
from pydantic import Field, SecretStr
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    """Environment-backed application settings.

    Values come from (in priority order):
      1. Environment variables (APP_DATABASE_URL, APP_OIDC_CLIENT_SECRET, ...)
      2. .env file (dev only; never committed)
      3. defaults declared below
    """

    app_env: str = Field(default="dev", alias="APP_ENV")
    log_level: str = Field(default="INFO", alias="APP_LOG_LEVEL")

    database_url: str = Field(alias="APP_DATABASE_URL")

    oidc_issuer: str = Field(alias="APP_OIDC_ISSUER")
    oidc_client_id: str = Field(alias="APP_OIDC_CLIENT_ID")
    oidc_client_secret: SecretStr = Field(alias="APP_OIDC_CLIENT_SECRET")
    oidc_audience: str = Field(alias="APP_OIDC_AUDIENCE")

    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        extra="forbid",
        frozen=True,
    )
```

`SecretStr` keeps secret values out of logs and repr.

## Alembic Wiring

`alembic.ini` (trimmed to what differs from the default template):

```ini
[alembic]
script_location = alembic
sqlalchemy.url = driver://user:pass@host/db  ; overridden in env.py
file_template = %%(year)d_%%(month).2d_%%(day).2d_%%(rev)s_%%(slug)s
```

`alembic/env.py` must import every module that declares SQLAlchemy models so
`--autogenerate` sees them. The generator puts a manifest near the top of
`env.py`:

```python
from app.<context>.infrastructure import models as <context>_models  # noqa: F401
# Repeat for every bounded context.

from app.infrastructure.base import Base  # declarative base
target_metadata = Base.metadata
```

Without this manifest, new tables silently fail to appear in generated
migrations.

## Dockerfile (multi-stage, non-root)

```dockerfile
# ------- build stage -------
FROM python:3.12-slim-bookworm AS build
WORKDIR /src
RUN apt-get update \
 && apt-get install --no-install-recommends -y build-essential \
 && rm -rf /var/lib/apt/lists/*
ENV PIP_NO_CACHE_DIR=1 PIP_DISABLE_PIP_VERSION_CHECK=1
COPY pyproject.toml ./
RUN pip install --prefix /install . \
 && pip install --prefix /install "uvicorn[standard]==0.32.0"

# ------- runtime stage -------
FROM python:3.12-slim-bookworm AS runtime
RUN useradd --system --create-home --uid 10001 appuser
WORKDIR /app
COPY --from=build /install /usr/local
COPY --chown=appuser:appuser app ./app
COPY --chown=appuser:appuser alembic ./alembic
COPY --chown=appuser:appuser alembic.ini ./
USER appuser
EXPOSE 8080
HEALTHCHECK --interval=30s --timeout=3s CMD \
  python -c "import httpx, sys; sys.exit(0 if httpx.get('http://localhost:8080/health').status_code == 200 else 1)"
ENV APP_ENV=prod APP_LOG_LEVEL=INFO
ENTRYPOINT ["uvicorn", "app.main:app", "--host", "0.0.0.0", "--port", "8080"]
```

Note: no `pip install` runs at container start; the wheel layer is fully
baked at build time.

## `.dockerignore`

```
__pycache__/
*.pyc
.pytest_cache/
.mypy_cache/
.ruff_cache/
.venv/
.env
.env.*
tests/
docs/
.git/
```

## `.env.example`

Documented sample for local dev. Must not contain real secrets; treat it as
part of source code.

```
APP_ENV=dev
APP_LOG_LEVEL=DEBUG
APP_DATABASE_URL=postgresql+asyncpg://app:app@localhost:5432/app
APP_OIDC_ISSUER=https://<tenant>.okta.com/oauth2/default
APP_OIDC_CLIENT_ID=<replace>
APP_OIDC_CLIENT_SECRET=<replace>
APP_OIDC_AUDIENCE=api://<module>
```
