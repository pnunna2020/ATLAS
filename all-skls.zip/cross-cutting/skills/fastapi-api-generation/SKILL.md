---
name: fastapi-api-generation
description: >
  Generate production-ready Python 3.12 / FastAPI REST APIs, async service layers,
  SQLAlchemy 2.x data access, Pydantic v2 schemas, and infrastructure configuration
  from extraction artifacts and the abstract scaffold produced by
  code-generation-abstract. Produces compilable, convention-following FastAPI
  applications with routers, dependency-injected services, async repositories,
  Alembic migrations, and pytest-asyncio test stubs — ready for the Ralph Loop
  (tdd-generation) to validate through test-driven iteration. Invoke during P4.3
  Generate only when the target architecture specifies FastAPI / Python. Triggers
  on FastAPI generation, Python API generation, async Python REST, Pydantic model
  generation, or @fastapi-api-generation mentions.
agent: sonnet
allowed-tools:
  - Read
  - Write
  - Bash
  - Grep
enrichment_level: Full
phase: P4
validation_commands:
  - "python -m py_compile $(git ls-files '*.py')"
  - "ruff check ."
  - "mypy app"
  - "pytest -q tests/unit"
  - "pytest -q tests/integration"
supported_stacks:
  - python
  - fastapi
  - pydantic-v2
  - sqlalchemy-async
  - alembic
  - pytest-asyncio
anti_target_stacks:
  - java
  - spring-boot
  - dotnet
  - csharp
  - cobol
  - natural
  - adabas
  - coldfusion
failure_classes:
  - sync-route-blocks-event-loop
  - missing-await
  - pydantic-v1-v2-drift
  - sqlalchemy-session-leak
  - n-plus-one-lazy-load
  - hardcoded-secret
  - missing-dependency-override
  - alembic-autogen-drift
benchmark_tags:
  - generation-fastapi
  - python-async-api
  - pydantic-v2-schemas
  - sqlalchemy-async-repository
  - pytest-asyncio-suite
---

# FastAPI API Generation

## Purpose
Generate production-ready Python 3.12 / FastAPI code from extraction artifacts
and the abstract scaffold produced by `code-generation-abstract`. This skill
produces compilable, convention-following FastAPI applications with routers,
async service layers, SQLAlchemy 2.x async data access, Pydantic v2 request /
response schemas, configuration, and Dockerized deployment — ready for the
Ralph Loop (tdd-generation) to validate through test-driven iteration.

Invoke this skill after `code-generation-abstract` has produced the project
scaffold and implementation plan, and only when the target architecture
blueprint specifies FastAPI / Python. It replaces TODO stubs with real FastAPI
implementation code, following the generation order specified in the
implementation plan (data layer -> domain layer -> application layer ->
API layer -> tests).

## When to Use
Invoke when the architecture blueprint, technology profile, or design artifacts
specify any of the following:

- `target_language` in {`python`, `py`, `python3`}
- `target_framework` in {`fastapi`, `FastAPI`, `starlette`}
- Existing stack is Python 2.x / Flask / Django and the disposition is
  Refactor or Rearchitect onto FastAPI
- Client profile technology stack lists `FastAPI` as the Web API archetype

Do NOT invoke this skill when the target is Spring Boot, .NET, Node.js, or any
non-FastAPI stack. Verify the tech stack before proceeding.

## Inputs
- `code-generation-abstract` output (project scaffold, implementation plan,
  traceability index)
- Extraction artifact from Step 1 (business rules YAML, test scenarios,
  module inventory)
- Target architecture blueprint from Step 2 (must specify FastAPI archetype)
- OpenAPI 3.x specifications from `api-specification` skill
- Data models and DDL from `data-modeling` skill
- Risk tier (T1, T2, T3) from Rationalization

## Outputs
- Complete Python project structure (`app/`, `tests/`, `alembic/`) with
  `pyproject.toml` and pinned dependencies
- FastAPI routers with full endpoint implementations per bounded context
- Async service layer with business logic from extracted rules
- SQLAlchemy 2.x async ORM models, repositories, and Alembic migrations
- Pydantic v2 request / response schemas with field validators
- `app/dependencies.py` with reusable dependency-injection callables
  (DB session, current user, settings)
- `app/main.py` wiring lifespan events, middleware, routers, and OpenAPI
  metadata
- Pydantic-settings `Settings` class backed by environment variables
- OIDC / JWT bearer authentication for OKTA integration
- Structured JSON logging via `structlog` + correlation-ID middleware
- `Dockerfile` (multi-stage, non-root) and `docker-compose.yml` for local dev
- `pytest-asyncio` test stubs (unit + integration) for every endpoint
- `README.md` with build / run / test commands

## Methodology

### Step 1: Validate Scaffold and Load Inputs
Read the abstract scaffold from `code-generation-abstract`. Validate that:
1. The scaffold specifies FastAPI as the target framework
2. Python package layout (`app/`, `tests/`, `alembic/`) exists
3. The implementation plan lists modules in dependency-respecting order
4. OpenAPI specs are available for all bounded contexts with API endpoints

Load the extraction artifact and map business rules to bounded contexts using
the traceability index from the scaffold.

### Step 2: Generate SQLAlchemy Async Data Layer
Generate SQLAlchemy 2.x declarative models, async repositories, and Alembic
migrations per bounded context, with lazy-load guards, typed `Mapped[]`
annotations, and audit-timestamp mixins.

See `references/fastapi-project-structure.md` for the package layout and
module-per-context convention.

### Steps 3-4: Generate Domain and Application Layers
Generate domain services (per aggregate root, async def throughout), domain
events (frozen Pydantic models, past-tense names), value objects (frozen
dataclasses or Pydantic `model_config.frozen = True`), and application
services (orchestration only, no business logic). Application services open
a transactional `AsyncSession` via the DB dependency; domain services never
commit.

See `references/async-patterns.md` for async-def rules, dependency-injection
patterns, background tasks, and lifespan-event handling.

### Steps 5-6: Generate Routers, Pydantic Schemas, and Mappers
Generate APIRouter modules from OpenAPI specs (with pagination, validation,
and response-model declarations), a global exception handler producing RFC
7807 Problem Details responses, Pydantic v2 schemas with field validators,
and `.model_dump()` / `.model_validate()` mapping helpers (Pydantic v2
replaces manual DTO mappers).

See `references/async-patterns.md` for router composition and the
`dependencies.py` pattern.

### Steps 7-8: Generate Configuration, Build, and Deployment Files
Produce pydantic-settings `Settings` class, OIDC / JWT bearer configuration,
structured-logging wire-up, health / readiness endpoints (`/health`,
`/health/ready`), a multi-stage Dockerfile, and `pyproject.toml` with the
pinned dependency set (FastAPI, Pydantic, SQLAlchemy, Alembic, structlog,
httpx, pytest-asyncio).

See `references/fastapi-project-structure.md` for directory layout,
`pyproject.toml` shape, and the Dockerfile template.

### Step 9: Generate Test Scaffolding
Produce `tests/unit/` (pure-Python, no DB) and `tests/integration/`
(`httpx.AsyncClient` + FastAPI lifespan) stubs for every router. Use
`pytest-asyncio` strict mode, monkeypatch dependencies via
`app.dependency_overrides`, and pin `asyncio_mode = "auto"` in
`pyproject.toml`.

See `references/pytest-asyncio-patterns.md` for async fixtures,
`httpx.AsyncClient` usage, and dependency-override patterns.

## Tech-Stack Dispatch
This skill targets a single technology stack. Before generating, validate that
the target architecture specifies one of these FastAPI configurations:

| Configuration | Python Version | FastAPI   | DB Driver          | Notes                            |
|---------------|:--------------:|:---------:|:------------------:|----------------------------------|
| Standard      | 3.12           | 0.115+    | asyncpg (Postgres) | Default for most applications    |
| SQL Server    | 3.12           | 0.115+    | aioodbc (mssql)    | When target_database = sqlserver |
| SQLite (dev)  | 3.12           | 0.115+    | aiosqlite          | Local dev / test fixtures only   |

If the architecture blueprint specifies a non-FastAPI target (Spring Boot,
.NET, Node.js), this skill should NOT be invoked. Check the tech stack
before proceeding.

## Disposition Context
This skill applies to applications dispositioned as:
- **Refactor**: Python 2.x, Flask, or Django monolith modernized to FastAPI
  with clean async layering
- **Rearchitect**: Non-Python legacy (ColdFusion, Classic ASP, PHP, Perl)
  rewritten in FastAPI

For Refactor dispositions, preserve existing Python package structure and
module names where possible. For Rearchitect dispositions, use clean-slate
FastAPI conventions with no legacy naming carryover.

## Gotchas
- **Async all the way down**: Any synchronous blocking call (e.g. `requests`,
  `psycopg2`, `time.sleep`) in a route handler stalls the event loop for every
  concurrent request. Use `httpx.AsyncClient`, `asyncpg` / SQLAlchemy async,
  and `asyncio.sleep`. If a sync call is unavoidable, offload to
  `await run_in_threadpool(...)` from `starlette.concurrency`.
- **Pydantic v2 is not v1**: `.dict()` is replaced by `.model_dump()`,
  `.parse_obj()` by `.model_validate()`, `@validator` by `@field_validator`,
  `Config` inner class by `model_config = ConfigDict(...)`. Mixing the two
  APIs silently works at import time and fails at serialization time.
- **Dependency injection, not globals**: Never import a module-level DB
  engine or session inside a router. Inject `AsyncSession` via
  `Depends(get_db)` so tests can swap it via `app.dependency_overrides`.
- **SQLAlchemy async session scope**: An `AsyncSession` must be closed after
  the request. Use `async_sessionmaker(..., expire_on_commit=False)` and
  yield the session from an async generator dependency. Never store a
  session on a module-level singleton.
- **No business logic in routers**: Routers validate input (via Pydantic),
  call a service, and return a response model. Business rules live in the
  service layer. If a router function exceeds 15 lines of logic, the
  boundary is wrong.
- **Alembic autogenerate needs metadata import**: `alembic/env.py` must
  import every module that declares a model before calling
  `context.configure(target_metadata=...)`, otherwise autogenerate silently
  omits new tables.
- **Secrets are never in `pyproject.toml` or `settings.toml`**: Use
  pydantic-settings with environment variables (`DB_PASSWORD`,
  `OIDC_CLIENT_SECRET`, `JWT_PUBLIC_KEY`). Hardcoded secrets fail security
  scan at G-04c.
- **`async def` vs `def` on routes**: A `def` route is executed on a
  threadpool. Mixing `def` and `async def` on the same router is legal
  but discouraged — it hides which endpoints can actually run concurrently.
  Prefer `async def` uniformly.

## Quality Rules
- [ ] Generated code imports cleanly with `python -c "import app.main"` — syntactically valid Python 3.12
- [ ] All routers declare `response_model=` so OpenAPI and runtime validation agree
- [ ] Every route handler is `async def`; no synchronous blocking I/O
- [ ] Pydantic v2 exclusively — no `.dict()`, `.parse_obj()`, or bare `@validator`
- [ ] All SQLAlchemy models use `Mapped[]` + `mapped_column()` typed style (SQLAlchemy 2.x)
- [ ] All DB access goes through an injected `AsyncSession` from `Depends(get_db)` — no module-level sessions
- [ ] `expire_on_commit=False` on the async sessionmaker
- [ ] Alembic migrations generated and committed for every model change (`alembic revision --autogenerate`)
- [ ] Code passes `ruff check .` with zero errors and `mypy app` with zero errors
- [ ] Every service method has a docstring citing the extraction rule ID(s) it implements
- [ ] `pyproject.toml` pins every direct dependency; no `>=` unbounded ranges
- [ ] Pydantic-settings `Settings` class exists; all secrets read from environment variables via `SettingsConfigDict(env_file=...)`
- [ ] Global exception handler registered via `app.add_exception_handler(...)` produces RFC 7807 JSON
- [ ] OIDC / JWT bearer authentication middleware is present when the api-spec declares a `bearerAuth` scheme
- [ ] `/health` (liveness) and `/health/ready` (readiness, probes DB) endpoints exist
- [ ] `pytest-asyncio` tests run with `asyncio_mode = "auto"` and every integration test uses `httpx.AsyncClient(transport=ASGITransport(app=app))`
- [ ] Dockerfile uses a multi-stage build with a non-root runtime user and slim Python base
- [ ] No router function exceeds 15 lines of logic — business rules are in service layer

## Common Failure Modes
| Failure Mode | Symptom | Prevention |
|--------------|---------|------------|
| sync-route-blocks-event-loop | `requests.get(...)` or `time.sleep` inside an `async def` route; latency spikes under load; worker saturation at low RPS | Ban sync HTTP / DB libs from route modules; use `httpx.AsyncClient`, SQLAlchemy async, `asyncio.sleep`. Offload unavoidable sync via `run_in_threadpool`. |
| missing-await | Coroutine returned as response; `TypeError: object coroutine can't be used in 'await' expression`; or response body is `<coroutine object ...>` string | `mypy --strict` catches most; add `ruff` rule `RUF006` and lint target `asyncio-dangling-task`. Code review: every `async def` call must be `await`ed. |
| pydantic-v1-v2-drift | `.dict()` returns AttributeError at runtime; mixed `@validator` and `@field_validator`; `model_config` ignored because `Config` inner class also present | Grep-and-reject v1 idioms at generation time. Pin `pydantic>=2.6`. Run `pytest` — v2 serialization errors surface immediately. |
| sqlalchemy-session-leak | Connections exhaust after N requests; Postgres logs `too many connections`; `QueuePool limit reached` | Always yield the session from an async generator dependency with a `finally: await session.close()`. Use `AsyncSession` only inside the request scope. |
| n-plus-one-lazy-load | API latency grows linearly with result count; SQL log shows one SELECT per child row | `Mapped` relationships are `lazy="raise"` by default in generated code; load explicitly with `selectinload()` or `joinedload()`. |
| hardcoded-secret | Security scan at G-04c flags credentials in `settings.toml` or `pyproject.toml`; rotation requires a deploy | Use `pydantic_settings.BaseSettings` + environment variables exclusively. Local `.env` is for dev; secrets at runtime come from vault / AWS Secrets Manager. |
| missing-dependency-override | Integration tests hit the real DB; CI fails because of network isolation | Every dependency (DB, settings, auth) must be injected via `Depends(...)`. Tests use `app.dependency_overrides[get_db] = lambda: test_session`. |
| alembic-autogen-drift | `alembic upgrade head` does not match the SQLAlchemy models; runtime queries fail | `alembic/env.py` must import every module under `app.<context>.models`; add a manifest import at the top of `env.py` and verify `alembic check` is green. |

## Handoff Summary
When this skill completes, verify:
1. `python -c "import app.main"` passes with zero errors
2. `ruff check .` and `mypy app` pass with zero issues
3. `pytest -q` runs the generated test stubs; all tests are collected
4. All REST endpoints match the Step 2 OpenAPI specification (paths, methods, status codes, response models)
5. SQLAlchemy models match the Step 2 ER diagram (tables, columns, relationships)
6. Every service method cites extraction rule IDs in its docstring
7. Integration test stubs exist for every router endpoint
8. Authentication middleware matches the api-spec security scheme
9. Alembic migrations generate the target schema (`alembic upgrade head` on a fresh DB)
10. `Dockerfile` builds and the container starts with `uvicorn app.main:app`

Then proceed to: `tdd-generation` (P4.3) for Ralph Loop test-driven validation,
`security-scan-review` for static analysis, and gate `G-04c` for generation
quality review.

## References
- `references/fastapi-project-structure.md` — `app/main.py`, routers, schemas,
  models, `dependencies.py`, tests layout, `pyproject.toml`, Dockerfile
- `references/async-patterns.md` — `async def`, dependency injection,
  background tasks, lifespan events, Pydantic v2 model rules
- `references/pytest-asyncio-patterns.md` — async fixtures,
  `httpx.AsyncClient`, monkeypatching async dependencies,
  `app.dependency_overrides`
