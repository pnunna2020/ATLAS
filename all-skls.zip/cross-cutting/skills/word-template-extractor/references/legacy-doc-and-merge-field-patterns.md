# Legacy `.doc` and Merge-Field Patterns

Coverage for pre-2007 Word formats (`.doc`, `.dot`) stored as
OLE2 compound document binaries. Unlike `.docx`, these cannot be
parsed as XML — they require either a binary OLE2 parser or
conversion to text via external tooling.

## OLE2 Binary Format

Microsoft Compound File Binary Format (MS-CFB) — a hierarchical
FAT-like filesystem inside a single file. Magic bytes at offset 0:

```
D0 CF 11 E0 A1 B1 1A E1
```

Internal storage is a tree of "streams" (files) and "storages"
(directories). A `.doc` has these load-bearing streams:

| Stream | Purpose |
|---|---|
| `WordDocument` | The main body text and formatting (FIB + text blocks) |
| `1Table` or `0Table` | Table stream — character properties, paragraph properties, section properties |
| `Data` | Binary data (embedded objects, pictures) |
| `\x05SummaryInformation` | Core document properties (author, title, subject) |
| `\x05DocumentSummaryInformation` | Extended properties (custom fields, hyperlinks) |
| `Macros` (storage) | Legacy macro layer (Word 95) |
| `VBA` (storage) | VBA 5+/6+ project (`.doc` with macros) |
| `EncryptedSummary` | Present on encrypted docs |

## Extraction Tooling Matrix

No single tool handles every `.doc` case. Choose per context:

| Tool | Platform | Output | Trade-off |
|---|---|---|---|
| `antiword` | Linux/macOS CLI | Plain text | Fast, text-only; loses fields and formatting; cannot extract VBA |
| `python-docx2txt` | Python (`.docx` only) | Plain text | Does not handle `.doc` at all |
| `textract` | Python | Plain text | Wraps antiword; same limits |
| `libreoffice --headless --convert-to txt` | Cross-platform | Plain text | Slow (JVM startup); handles most `.doc` variants; no macro extraction |
| `libreoffice --headless --convert-to docx` | Cross-platform | `.docx` conversion | Best for downstream OOXML extraction; loses some legacy formatting |
| `oletools.olevba` | Python | VBA source extraction | Macro-focused; no text body |
| `compoundfiles` / `olefile` | Python | Raw OLE2 stream access | Low-level; need to parse FIB + piece-table manually |
| Word COM Interop | Windows + Word installed | Full fidelity | Not headless-friendly; licensing |
| Aspose.Words (commercial) | Java/.NET/Python | Full fidelity | License cost |

**Recommendation for ATLAS pipeline:** first-pass `libreoffice
--convert-to docx` to get modern XML, then apply
`docx-template-patterns.md` extraction. Fall back to `olevba` for
macro inventory directly from the original `.doc`. Emit prerequisite
findings if neither tool is available.

## Field-Code Syntax

Field codes in `.doc` are encoded the same way as in `.docx`
(begin / separate / end boundary markers plus instruction text) but
at the binary FIB + character-property level, not XML. After
conversion to `.docx`, field extraction follows the same algorithm
as `docx-template-patterns.md`.

Common field codes relevant to FAA correspondence templates:

### MERGEFIELD

```
{ MERGEFIELD ApplicantName \* MERGEFORMAT }
```
- `\* MERGEFORMAT` — preserve any manual formatting applied to the
  displayed result.
- `\* Upper`, `\* Lower`, `\* Caps`, `\* FirstCap` — case
  transformations.
- `\# "$#,##0.00"` — numeric picture for currency.
- `\@ "MMMM d, yyyy"` — date picture (e.g., "October 14, 2024").
- `\b "text"` — text to insert before the field if non-empty.
- `\f "text"` — text to insert after the field if non-empty.

### IF

```
{ IF { MERGEFIELD Status } = "Denied" "Deny text" "Approve text" }
```

Comparators: `=`, `<>`, `<`, `>`, `<=`, `>=`. Literal operands are
double-quoted. Wildcard matching: `\= "D*"` matches anything
starting with D.

### DOCPROPERTY

```
{ DOCPROPERTY CaseNumber }
```

References a custom property from the document's summary info. In
`.doc`, custom properties live in `\x05DocumentSummaryInformation`.

### REF / ASK / SET

```
{ ASK CaseNumber "Enter the case number:" \d "00000" }
{ SET Greeting "Dear Mr. Smith" }
{ REF Greeting }
```

`ASK` prompts at mail-merge time (interactive mail-merge pattern —
rare in modern use, but present in older FAA templates). `\d
"default"` supplies a default value.

### DATABASE

```
{ DATABASE \d "C:\path\to\source.mdb" \s "SELECT * FROM Applicants WHERE Status = 'Denied'" }
```

Executes SQL against a local Access database or ODBC source at
mail-merge time. **High-severity modernization finding** — hidden
data-access path that modernized letter services must replace with
a structured API call. Also a security concern (embedded
credentials in connection strings).

### INCLUDEIF / INCLUDETEXT

```
{ INCLUDETEXT "C:\templates\boilerplate.doc" }
{ INCLUDEIF { MERGEFIELD Type } = "Renewal" "renewal-clause.doc" }
```

External-file dependency — template references another template.
Emit as dependency edge; resolve the referenced file if it exists
in the repo; flag if it does not (broken template).

## Mail-Merge Data Source

Mail-merge templates are paired with a data source — typically:

- `.mdb` Access database alongside the `.doc`
- `.xls` Excel worksheet
- `.csv` delimited file
- ODBC DSN (reference stored in the doc's `MailMerge` settings)
- Word table inside the same document

The `MailMerge` settings section in the doc's `WordDocument` stream
identifies the source. Extract and inventory as part of the
template's input surface — it is a hidden data contract.

## VBA Macros

VBA lives under the `VBA` storage inside the OLE2 container. Use
`oletools.olevba`:

```
from oletools.olevba import VBA_Parser
vba = VBA_Parser(path_to_doc)
if vba.detect_vba_macros():
    for (filename, stream_path, vba_filename, vba_code) in vba.extract_macros():
        # vba_code is the VBA source
        ...
```

### Module types

- **Standard modules** — global procedures and functions. Name is
  arbitrary; `Module1`, `HelperModule`, etc.
- **Class modules** — types, instantiated with `New`.
- **UserForm modules** — form code-behind.
- **Document module** (`ThisDocument`) — document-level event
  handlers. Named `ThisDocument` in Word.

### Auto-execute handlers

These run automatically when a document is opened, closed, or
certain events fire. Any of these in a letter template is a
modernization blocker because modern letter services do not
execute macros:

| Handler | Trigger |
|---|---|
| `Document_Open` | Document opened |
| `Document_Close` | Document closed |
| `Document_New` | New document created from template |
| `Document_BeforeSave` | Before save |
| `Document_BeforeClose` | Before close |
| `AutoOpen` | Legacy equivalent of `Document_Open` (Word 95) |
| `AutoClose` | Legacy equivalent of `Document_Close` |
| `AutoNew` | Legacy equivalent of `Document_New` |
| `AutoExec` | Runs when Word itself starts (only fires in `normal.dotm`) |
| `AutoExit` | Runs when Word exits |

### External references to flag

Scan VBA source for:

- `Shell(...)` — launches external process. High severity.
- `CreateObject("WScript.Shell")` — WSH access. High severity.
- `CreateObject("Scripting.FileSystemObject")` — file-system writes.
- `Open ... For Output` / `Write #` / `Print #` — native file I/O.
- `Win32 API` declarations (`Declare Function ... Lib "kernel32"`) —
  direct Windows API calls.
- `Registry` access via `CreateObject("WScript.Shell").RegRead/RegWrite`.
- Network access (`MSXML2.XMLHTTP`, `WinHttp.WinHttpRequest`).
- `SendKeys` — keystroke injection.

Emit one finding per external-reference category, with severity
derived from the combination.

## Drift-Copy Detection

`.doc` templates frequently accumulate drift copies — especially in
VSS-era or email-attachment repos. Detection heuristic:

```
pairwise_similarity(template_a, template_b):
    merge_fields_a = set of merge field names in a
    merge_fields_b = set of merge field names in b
    jaccard = |a ∩ b| / |a ∪ b|
    basename_distance = levenshtein(basename_a, basename_b)
    if jaccard > 0.90 and basename_distance < 10:
        flag as drift-copy pair
```

Basename patterns to detect:

- `Letter.doc` vs `Letter - Copy.doc`
- `Letter.doc` vs `Letter v2.doc` vs `Letter v3.doc`
- `Letter.doc` vs `Letter (final).doc`
- `Letter.doc` vs `Letter FINAL.doc` vs `Letter FINAL FINAL.doc`
- `Letter.doc` vs `Letter_backup.doc`

**Never auto-dedupe.** Only the owning team knows which copy is
canonical; emit the pair and let Rationalization decide.

## `.doc` -> `.docx` Migration

If modernization strategy is to upgrade the existing template
format (before further migration), use LibreOffice headless:

```
libreoffice --headless --convert-to docx *.doc
```

Caveats:
- Some legacy formatting features (linked styles from normal.dot,
  certain OLE embeddings) convert imperfectly.
- Macros in `.doc` convert to `.docm`; extract macro inventory
  BEFORE conversion so the original source is preserved.
- Password-protected `.doc` cannot be converted without the
  password.
