# DOCX Template Patterns

Coverage for modern Word template formats (`.docx`, `.docm`, `.dotx`,
`.dotm`) — Office Open XML per ISO/IEC 29500. Unlike legacy `.doc`,
`.docx` is a ZIP archive of XML parts that can be extracted and
parsed offline without Word.

## ZIP Structure

A `.docx` is a ZIP with the following load-bearing parts. Unzip
directly; the MIME magic is `50 4B 03 04` at offset 0.

| Path | Purpose |
|---|---|
| `[Content_Types].xml` | MIME map for every part in the package |
| `_rels/.rels` | Root relationships (package-level) |
| `word/document.xml` | Main document body — the primary extraction target |
| `word/_rels/document.xml.rels` | Relationships from body to images, headers, footers, embedded objects |
| `word/styles.xml` | Named style definitions — load-bearing for `STYLEREF` |
| `word/settings.xml` | Document-level settings (Track Changes enabled, autoHyphenation) |
| `word/theme/theme1.xml` | Theme definition (colors, fonts) |
| `word/numbering.xml` | List numbering definitions |
| `word/fontTable.xml` | Font references |
| `word/header1.xml`, `word/footer1.xml` | Header / footer parts |
| `word/comments.xml` | Tracked comments |
| `word/footnotes.xml`, `word/endnotes.xml` | Footnote / endnote parts |
| `word/media/image1.png` (etc.) | Embedded images |
| `word/embeddings/oleObject1.bin` | Embedded OLE objects (Excel charts, equations) |
| `word/vbaProject.bin` | VBA macros (`.docm` / `.dotm` only) |
| `word/activeX/activeX1.xml` | ActiveX controls (rare; flag as modernization blocker) |
| `docProps/core.xml` | Author, title, subject, created, modified |
| `docProps/app.xml` | Application name, total edit time, template name |
| `docProps/custom.xml` | Custom document properties (often `DOCPROPERTY` field targets) |

## `word/document.xml` Anatomy

Root element is `<w:document>` with the `w:` namespace
(`http://schemas.openxmlformats.org/wordprocessingml/2006/main`).

```
<w:document>
  <w:body>
    <w:p>                        <!-- paragraph -->
      <w:pPr>                    <!-- paragraph properties -->
        <w:pStyle w:val="Heading1"/>
      </w:pPr>
      <w:r>                      <!-- run (contiguous formatted text) -->
        <w:rPr>                  <!-- run properties (bold, italic, font) -->
          <w:b/>
        </w:rPr>
        <w:t>Text goes here</w:t>
      </w:r>
    </w:p>
    <w:sectPr>                   <!-- section properties (page size, orientation) -->
      <w:pgSz w:w="12240" w:h="15840"/>
    </w:sectPr>
  </w:body>
</w:document>
```

Paragraphs are the unit of extraction. Text lives inside `<w:t>`
elements, but fields and content controls bracket the text with
special markers — parse those BEFORE collapsing to text.

## Field-Code Encoding

Word fields are encoded as a triple of `<w:fldChar>` elements bounding
the instruction and result:

```
<w:r>
  <w:fldChar w:fldCharType="begin"/>
</w:r>
<w:r>
  <w:instrText>MERGEFIELD ApplicantName \* MERGEFORMAT</w:instrText>
</w:r>
<w:r>
  <w:fldChar w:fldCharType="separate"/>
</w:r>
<w:r>
  <w:t>[cached display value]</w:t>    <!-- the field RESULT -->
</w:r>
<w:r>
  <w:fldChar w:fldCharType="end"/>
</w:r>
```

Extract the `<w:instrText>` — that is the authored field code. The
text run between `separate` and `end` is the cached rendering and is
not authoritative (may be blank, may be stale).

### Complex / nested fields

Nested fields are encoded as nested fldChar triples. A field can
span multiple runs because Word breaks runs on formatting changes.
Tokenize by accumulating `instrText` across runs between `begin`
and `separate` of the same nesting level.

### Common field codes

| Code | Purpose | Extraction notes |
|---|---|---|
| `MERGEFIELD <Name> [\* switches]` | Mail-merge data binding | Emit as merge-field manifest entry |
| `DOCPROPERTY <Name>` | Custom document property reference | Resolve to `docProps/custom.xml` |
| `IF <cond> "true-text" "false-text"` | Conditional text | Flatten as conditional node |
| `STYLEREF "<style>"` | Dynamic section heading insertion | Emit style-dependency finding |
| `INCLUDETEXT "<path>"` | Embed another document | Emit external-dependency finding |
| `HYPERLINK "<url>"` | URL link | Redact URLs with PII |
| `REF <bookmark>` | Cross-reference to bookmark | Resolve to bookmark anchor |
| `ASK <bookmark> "<prompt>"` | Prompt user at merge time | Emit as required input (with prompt) |
| `SET <bookmark> "<value>"` | Set bookmark at merge time | Emit as computed value |
| `DATABASE \d "<source>" \s "<query>"` | Inline SQL mail-merge | Emit as data-access finding, severity P1 |
| `FORMTEXT`, `FORMCHECKBOX`, `FORMDROPDOWN` | Legacy form controls | Emit as form-field manifest entry |

### Switches

Field switches modify formatting: `\* Upper`, `\* Lower`, `\* FirstCap`,
`\# "#,##0.00"` (numeric format), `\@ "MMMM d, yyyy"` (date format).
Preserve switches in the manifest — they are part of the rendered
contract.

## Structured Document Tags (SDT) / Content Controls

SDT is the modern replacement for merge fields; docx-only. Rendered
as `<w:sdt>` with child `<w:sdtPr>` (properties) and `<w:sdtContent>`
(inner text).

```
<w:sdt>
  <w:sdtPr>
    <w:tag w:val="ApplicantName"/>        <!-- programmatic identifier -->
    <w:alias w:val="Applicant name"/>     <!-- human-readable label -->
    <w:placeholder>
      <w:docPart w:val="DefaultPlaceholder_-1854013440"/>
    </w:placeholder>
    <w:text/>                             <!-- plain text control -->
  </w:sdtPr>
  <w:sdtContent>
    <w:r><w:t>placeholder text</w:t></w:r>
  </w:sdtContent>
</w:sdt>
```

Control types: `<w:text/>` (plain text), `<w:richText/>` (rich text),
`<w:dropDownList/>`, `<w:comboBox/>`, `<w:date/>`, `<w:picture/>`,
`<w:checkbox/>` (via `<w14:checkbox/>` in the w14 namespace),
`<w:repeatingSection/>`, `<w:group/>`.

When BOTH SDT and MERGEFIELD coexist in the same template, SDT
typically wins at runtime when the host uses OpenXML SDK; the merge
field is a display fallback. Extract both, flag the conflict.

## Conditional / Nested IF Extraction

A template's denial-vs-approval paragraph selection typically looks
like:

```
{IF {MERGEFIELD Status} = "Denied"
    "We regret to inform you that your application has been denied for the following reason: {MERGEFIELD DenialReason}."
    "We are pleased to inform you that your application has been approved."
}
```

Extraction output:

```
{
  "node_id": "if_001",
  "parent_node_id": null,
  "field_type": "IF",
  "condition": {
    "lhs": {"type": "MERGEFIELD", "name": "Status"},
    "comparator": "=",
    "rhs": {"type": "literal", "value": "Denied"}
  },
  "true_branch": {
    "text": "We regret to inform you that your application has been denied for the following reason: ",
    "embedded_fields": [{"type": "MERGEFIELD", "name": "DenialReason"}]
  },
  "false_branch": {
    "text": "We are pleased to inform you that your application has been approved."
  },
  "if_depth": 0
}
```

Nested IFs produce child records with `parent_node_id = "if_001"`.
Flag `if_depth > 5` as a complexity finding — deeply nested template
logic is better modeled as a rules engine in the target service.

## Styles and Headings

`word/styles.xml` defines named styles. `STYLEREF` field references
resolve here:

```
<w:style w:type="paragraph" w:styleId="Heading1">
  <w:name w:val="heading 1"/>
  ...
</w:style>
```

Emit a style-dependency graph: every STYLEREF -> styleId -> style
definition. Style rename via `w:name` vs `w:styleId` can silently
break references.

## Document Properties

`docProps/core.xml` (Dublin Core):
`<dc:title>`, `<dc:creator>`, `<cp:lastModifiedBy>`, `<dcterms:created>`,
`<dcterms:modified>`.

`docProps/custom.xml`:
```
<op:properties>
  <op:property fmtid="{...}" pid="2" name="CaseNumber">
    <vt:lpwstr>12345</vt:lpwstr>
  </op:property>
</op:properties>
```

Custom properties are the targets of `DOCPROPERTY` field references.

## Tracked Changes Redaction

Before emitting text extract, strip:
- `<w:ins>` (insertion) — keep the wrapped text, drop the author attribute.
- `<w:del>` with `<w:delText>` — the deleted text; drop entirely unless
  the goal is diff reconstruction.
- `<w:commentRangeStart>` / `<w:commentReference>` markers and
  `word/comments.xml` — entire file contains author + timestamp +
  comment text; redact author + date, retain text only if requested.

## Embedded Objects

`word/embeddings/oleObject1.bin` — binary OLE object (Excel chart,
equation). Preserve as asset; modernization must handle the asset
pipeline separately.

`word/media/image1.png` — embedded image. Catalog paths and sizes.

## VBA Macros in .docm

When `word/vbaProject.bin` exists, the template is `.docm` / `.dotm`
(macro-enabled). The VBA project is itself an OLE2 compound file
nested inside the ZIP. See `legacy-doc-and-merge-field-patterns.md`
for VBA extraction mechanics — the process is identical regardless
of outer container.

## Extraction Algorithm

```
for each .docx/.docm/.dotx/.dotm under scanned directories:
    open as ZIP
    if ZIP root contains EncryptionInfo:
        emit password_protected_unextractable; continue
    read word/document.xml as XML with namespaces preserved
    walk paragraphs in document order
    for each paragraph:
        detect field triples (fldChar begin -> separate -> end)
        detect SDTs (w:sdt elements)
        emit manifest entries with file:line (approximate via XML tree position)
    if word/vbaProject.bin exists:
        parse VBA project; enumerate modules + handlers
    emit inventory, merge-field, conditional-logic, macro manifests
```
