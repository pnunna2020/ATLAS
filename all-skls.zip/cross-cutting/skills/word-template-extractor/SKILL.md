---
name: word-template-extractor
description: >
  Extract Microsoft Word correspondence templates (`.doc` legacy binary,
  `.docx` OOXML) as a first-class modernization input. FAA AAM apps generate
  airman correspondence (denial letters, medical clearance letters,
  suspension notices, follow-up letters) from Word-document templates
  checked into source control as binaries. These templates carry hidden
  business logic: `MERGEFIELD` bindings, nested `IF` conditional
  paragraphs, `ASK`/`SET` field prompts, Structured Document Tag (SDT)
  content controls, and embedded VBA macros with auto-execute handlers.
  Without structured extraction, modernized letter services silently emit
  wrong letters — a 14 CFR Part 67 compliance risk because paragraph
  wording for denial and clearance letters is regulatory-prescribed.
  Runs as a Modernization Extract conditional skill when the repo
  contains a directory of `.doc`/`.docx` files that are not READMEs or
  documentation. Triggers on Word-template extraction, mail-merge
  analysis, correspondence-template migration, or @word-template-extractor.
agent: sonnet
allowed-tools:
  - Read
  - Write
  - Grep
  - Glob
validation_commands:
  - "python -m olympus.validators.schema_validator word-template-inventory.json"
  - "python -m olympus.validators.schema_validator word-merge-field-manifest.json"
  - "python -m olympus.validators.schema_validator word-conditional-logic.json"
  - "python -m olympus.validators.schema_validator word-embedded-macro-findings.json"
  - "python -m olympus.validators.schema_validator word-data-contract.json"
  - "python -m olympus.validators.schema_validator word-modernization-findings.json"
supported_stacks:
  - word-templates
  - docx
  - doc
  - mail-merge
  - ooxml
  - vba
anti_target_stacks:
  - pdf
  - html-templates
  - rdlc
  - static-site
failure_classes:
  - binary-doc-not-extracted
  - field-code-vs-result-confused
  - nested-if-logic-dropped
  - vba-macro-not-flagged
  - pii-in-tracked-changes-unredacted
  - password-protected-silent-skip
  - style-reference-dependency-missed
  - regulatory-wording-normalized
  - drift-copy-double-counted
  - content-control-vs-merge-field-merged
benchmark_tags:
  - modernization-extract
  - correspondence-template-extraction
  - conditional-letter-logic
  - 14-cfr-part-67-letter-parity
---

# word-template-extractor

## Purpose
Extract the data contract, conditional logic, and modernization-risk surface
of Word correspondence templates so a modernized letter-generation service
can emit byte-for-business-logic-identical letters. This is explicitly NOT
a rendering extractor — the goal is not to recreate the document layout,
it is to surface: (a) what inputs must be supplied at call time (merge
fields, content-control tags, prompted ASK values), (b) what conditional
branches exist and under what expressions, (c) what macros or external
resources the template depends on, and (d) what regulatory preservation
constraints apply. Downstream modernization then authors a template in
the target stack (docx templating, markdown + pandoc, HTML-to-PDF, etc.)
with the same contract. Without this extractor, Discovery surfaces Word
templates as opaque binaries and Rationalization cannot assess the
blast radius of replacing them.

## Inputs
- Repository tree containing a directory of `.doc` or `.docx` files
  (CPDSS's `docs/WordDocuments/` is the canonical case).
- Application catalog entry from `catalog-application` with the app's
  correspondence-generating modules flagged (e.g., `CPDSS/Letters/`).
- Client-profile compliance configuration
  (`profiles/<client>/compliance.yaml`) — used to detect
  regulatory-preserved letter categories (14 CFR Part 67 for AAM apps).
- Optional: a sibling `.txt` or `.md` representation of the template (if
  the team has maintained one for diff purposes). Absence is the norm
  and emits a modernization-readiness finding.
- Optional: deployment or code-side code that reads template files at
  runtime (`File.ReadAllBytes("...docx")`,
  `WordprocessingDocument.Open(...)`, `Microsoft.Office.Interop.Word`
  usage) — resolves the runtime host.

## Outputs
- `word-template-inventory.json` — per template: path, format
  (`doc` | `docx` | `docm` | `dot` | `dotx` | `dotm`), size_bytes,
  last_modified_commit, text_extract (docx only, empty string for .doc
  unless converted), macros_present, content_controls_present,
  password_protected, drift_copy_of (another template this appears to
  duplicate).
- `word-merge-field-manifest.json` — per field occurrence:
  `{template_path, field_type (MERGEFIELD | DOCPROPERTY | FORMTEXT |
  FORMCHECKBOX | FORMDROPDOWN | SDT), field_name, switches[],
  sdt_alias, sdt_tag, sdt_placeholder, line, offset}`.
- `word-conditional-logic.json` — per `IF` / `INCLUDEIF` / `ASK` / `SET`
  field with the full condition expression, true-branch text,
  false-branch text, and parent-field nesting depth for chained IFs.
  Decision trees are emitted in flattened form: one record per
  conditional node, with a `parent_node_id` link.
- `word-embedded-macro-findings.json` — per VBA module: module_name,
  module_type (standard | class | form | document), auto_execute_handlers[]
  (`Document_Open`, `Document_Close`, `AutoOpen`, `AutoClose`, `AutoExec`,
  `AutoNew`), external_references[] (Shell commands, Win32 API calls,
  file-system writes, registry reads), macro_size_bytes. Security
  severity set per module based on auto-execute + external references.
- `word-data-contract.json` — consolidated: every unique merge-field
  name + content-control tag becomes a required input to the target
  letter service. Output is a JSON-schema-adjacent shape the Design
  step can consume as the request body for the target service.
- `word-modernization-findings.json` — per-template risk findings:
  `doc`-binary-needs-docx-migration, macros-block-modern-service,
  password-protected-unextractable, style-reference-dependency,
  14-cfr-part-67-regulatory-letter, drift-copy-of-another-template,
  embedded-sql-in-database-field, binary-image-or-oleobject-dependency.

## Methodology
1. **Enumerate template directories.** Walk the repo for any directory
   whose files include any of `.doc`, `.docx`, `.docm`, `.dot`, `.dotx`,
   `.dotm`. Exclude `.git/`, `node_modules/`, `bin/`, `obj/`. Exclude
   files whose basename matches `README`, `ORIGINAL_README`, `CHANGELOG`
   (these are documentation, not templates).
2. **Classify format per file.** Read the first 8 bytes: `D0 CF 11 E0
   A1 B1 1A E1` identifies OLE2 compound-document format (`.doc`);
   `50 4B 03 04` identifies ZIP (`.docx`/`.docm`/`.dotx`/`.dotm`). Flag
   any extension-content mismatch as a finding.
3. **Detect password protection.** OLE2: check for `EncryptedPackage`
   stream. OOXML: check for `EncryptionInfo` stream at ZIP root. Emit
   `password_protected_unextractable` for any protected file and skip
   field extraction.
4. **Extract text + structure from `.docx`.** Unzip in-memory. Parse
   `word/document.xml` with an XML parser that preserves namespaces.
   Enumerate `<w:p>` paragraphs. Within each paragraph enumerate
   `<w:fldChar>`/`<w:instrText>` triples (the field-code encoding) and
   `<w:sdt>` structured document tags.
5. **Parse field codes.** Each field is a begin/separate/end fldChar
   triple bounding an `<w:instrText>` field instruction. Parse the
   instruction string (e.g., `MERGEFIELD Status \* Upper`) into
   field_type, field_name, and switches. Nested fields (an IF whose
   condition references a MERGEFIELD) produce parent-child records.
6. **Flatten nested IFs.** An `IF` field of the form
   `{IF {MERGEFIELD Status} = "Denied" "Deny paragraph" "Approve paragraph"}`
   expands into: one conditional-node record (condition LHS = MERGEFIELD
   ref, RHS = literal, comparator = `=`), two child-text records (true
   branch, false branch). Arbitrarily deep nesting supported; emit an
   `if_depth` finding at depth > 5.
7. **Extract content controls (SDT).** Each `<w:sdt>` has
   `<w:sdtPr>` with `<w:tag>` and `<w:alias>`. These are the modern
   replacement for merge fields and ARE the data contract when both
   exist in the same template. Preserve both representations.
8. **Extract VBA macros.** `.docm` / `.dotm` / `.doc` with VBA have
   a `vbaProject.bin` OLE2 stream. Parse with `oletools.olevba`
   or an equivalent. Inventory modules, handlers, and external
   references.
9. **Detect drift copies.** Two templates are likely drift copies if
   they share > 90% of merge fields + similar basename patterns
   (`Letter.doc` vs `Letter - Copy.doc` vs `Letter v2.doc`). Flag
   pairwise; do not auto-dedupe.
10. **Emit regulatory-preservation findings.** If the template's
    containing directory or its name matches client-profile compliance
    patterns (e.g., `14-cfr-part-67` for AAM apps) tag with
    `regulatory_wording_preserve`.
11. **Write all manifests with `{repo}:{file}:{line}` citations** for
    every field, macro, and finding. Finding records validate against
    the Olympus finding schema.

## Tech-Stack Dispatch

| Trigger | Reference loaded |
|---|---|
| Directory of `.docx`/`.docm`/`.dotx` files | `references/docx-template-patterns.md` |
| Any `.doc` files (OLE2 binary) | `references/legacy-doc-and-merge-field-patterns.md` |
| VBA macros detected | both references (docx macro pattern + legacy VBA pattern) |

## Gotchas
- **`.doc` is OLE2 binary (pre-2007), not XML.** Cannot parse with an
  XML parser. Requires `python-docx2txt`, `antiword`, LibreOffice
  headless (`libreoffice --convert-to txt`), or Word COM automation.
  Emit a prerequisite finding when the repo has `.doc` and none of
  the extraction tools are available in the pipeline runner.
- **`.docx` is a ZIP archive of OOXML.** Unzip and parse
  `word/document.xml` offline — no Word required. Schema is
  ISO/IEC 29500.
- **Field code vs field result.** In both formats, the field carries
  two representations: the instruction (`MERGEFIELD Foo`) and the
  cached displayed value from the last render. Parse the instruction
  only; the result is a rendering artifact and may be stale.
- **Content controls (SDT) ≠ merge fields.** SDT (`.docx` only) is
  the modern data-binding mechanism, with tag + alias + placeholder.
  When both SDT and MERGEFIELD exist in the same template, SDT
  usually wins at runtime; extract both and flag the conflict.
- **Nested IF is conditional logic, not text.** A template with
  `{IF {MERGEFIELD Status} = "Denied" "Paragraph A" "Paragraph B"}`
  is a business-rule surface; modernization must re-encode the same
  branching. Never extract just the rendered text — the decision
  tree is the value.
- **VBA macros can execute arbitrary code.** `Document_Open`,
  `AutoOpen`, `AutoExec` run on template open. Modern letter
  services (docxtpl, Aspose, Open-XML-SDK, Docassemble, Gotenberg)
  do NOT execute macros. If any template depends on a macro for
  its rendered output, it is a hard modernization blocker — flag
  as severity P0.
- **Track Changes / Comments may contain PII.** Revision marks and
  comments can carry developer or reviewer names and substantive
  draft notes. Redact before emitting the text extract.
- **Password-protected templates cannot be extracted.** Emit a
  finding listing every password-protected file; escalate to the
  owning team for the password rather than attempting brute force.
- **Style references create hidden dependencies.**
  `{ STYLEREF "Heading 1" }` inserts the current section's Heading 1
  text dynamically. A rename of the style in `word/styles.xml`
  silently breaks every STYLEREF. Emit a dependency graph: every
  STYLEREF -> named style -> style definition location.
- **Field-code whitespace matters.** Word silently normalizes
  whitespace inside field codes but the authored instruction string
  is what OOXML records. Preserve whitespace for traceability.
- **14 CFR Part 67 denial letters are regulatory-weighted.**
  Paragraph wording for medical-certification denial, suspension,
  and clearance is prescribed by regulation. Modernization must
  preserve verbatim wording, not just contract shape. Flag these
  letters with `regulatory_wording_preserve`.
- **Binary `.doc` accumulates drift copies.** `Letter.doc`,
  `Letter v2.doc`, `Letter - Copy.doc`, `Letter (final).doc`,
  `Letter FINAL FINAL.doc` — classic VSS-era / email-attachment
  pattern. Flag pairwise; do not auto-dedupe, only the owning
  team knows which is canonical.
- **Embedded objects (charts, equations, images).** Word supports
  OLE-embedded objects that are themselves binaries (Excel charts,
  MathML equations, SmartArt diagrams). Preserve as referenced
  asset inventory; modernization must handle the asset pipeline.
- **DATABASE field with embedded SQL.** A `{ DATABASE \d "Foo.mdb"
  \s "SELECT ..." }` field pulls data directly from a database at
  mail-merge time. This is a hidden data-access path; modernization
  must replace it with a structured API call. Emit as severity P1.
- **Mail-merge data source (`.mdb`, `.xls`, `.csv` alongside
  template)** may ship in the same directory. Inventory as part of
  the template's input surface.

## Quality Rules
- [ ] Every `.doc`/`.docx`/`.docm`/`.dot`/`.dotx`/`.dotm` under the
      scanned directories has a record in
      `word-template-inventory.json` with format + size + presence
      flags populated.
- [ ] Every MERGEFIELD, DOCPROPERTY, content control, and form field
      carries `{repo}:{file}:{line}` traceability.
- [ ] Nested IF chains are flattened into parent-child records with
      `if_depth` and `parent_node_id` populated.
- [ ] VBA macro findings emit every auto-execute handler found and
      every Shell / Win32 / file-system external reference.
- [ ] Password-protected templates emit
      `password_protected_unextractable` findings instead of empty
      manifests.
- [ ] Drift copies flagged pairwise, never auto-merged.
- [ ] 14 CFR Part 67 letters (or equivalent regulatory category
      from the client profile) carry `regulatory_wording_preserve`.
- [ ] Text extracts redact PII in Track Changes / Comments before
      emission.
- [ ] Field codes preserve authored whitespace.
- [ ] `word-data-contract.json` enumerates every unique input
      name across all templates; duplicates across templates merge
      to one contract entry with a `templates[]` back-reference.

## Common Failure Modes

| Failure Mode | Symptom | Prevention |
|---|---|---|
| `.doc` parsed as ZIP | Unzip fails with bad magic; extractor emits empty manifest | Detect OLE2 magic bytes first; dispatch to legacy-doc path |
| Field result extracted instead of code | Template shows `[Applicant Name]` placeholder in extract, not `MERGEFIELD ApplicantName` | Parse `<w:instrText>` between fldChar begin/separate, not the text run after separate |
| Nested IF flattened to a single string | Decision tree lost; modernized service emits unconditional paragraph | Parse `IF` field as a conditional node with child true/false branches, recurse |
| VBA auto-exec handler ignored | Template appears safe; modernized service silently skips behavior previously in macro | Enumerate every module's procedures; match names against the auto-execute handler list |
| PII in Track Changes leaked into manifest | Developer names / draft notes exposed in extract | Redact `w:ins`/`w:del`/`w:comments` XML before emitting text |
| Password-protected file silently produces empty record | Downstream Design thinks template has no contract | Detect encryption magic and emit `password_protected_unextractable` finding |

## Handoff Summary
When this skill completes, verify:
1. Every Word template in scanned directories has an inventory record
   with format detected, PII redacted, and password-protection flagged.
2. `word-data-contract.json` enumerates every unique input across all
   templates — this is the contract the target letter service must
   accept.
3. Every macro-bearing template carries auto-execute handler findings
   with severity set per external-reference inventory.
4. Regulatory-preservation findings are set for every template matching
   the client-profile compliance categories.

Then proceed to: `module-design` (Design primary) — which consumes the
data contract and macro findings to shape the target letter service;
`cato-compliance` — which verifies 14 CFR Part 67 wording preservation;
and, for modernization, the target generator skill (HTML-to-PDF,
docxtpl, or equivalent) in the Generation phase.

## References
- `references/docx-template-patterns.md` — OOXML zip structure,
  `word/document.xml` anatomy, SDT content controls, merge-field
  encoding in docx XML, field-code vs field-result distinction,
  conditional / nested IF extraction, styles and headings, document
  properties, tracked changes redaction, embedded objects.
- `references/legacy-doc-and-merge-field-patterns.md` — OLE2 binary
  format overview, extraction-tooling matrix, field-code syntax
  catalog (`MERGEFIELD`, `IF`, `DOCPROPERTY`, `REF`, `HYPERLINK`,
  `INCLUDETEXT`, `ASK`, `SET`, `INCLUDEIF`, `DATABASE`), mail-merge
  data source, VBA macros and auto-execute detection, drift-copy
  detection.

## Changelog
- 0.1.0 (2026-05-07) — Initial skill. Covers `.doc`/`.docx`/`.docm`
  classification, field-code and SDT content-control extraction,
  nested-IF flattening, VBA macro inventory with auto-execute
  detection, data-contract consolidation, drift-copy detection,
  regulatory-preservation flagging. Emits six manifests with
  `{repo}:{file}:{line}` traceability. Authored as ATLAS-R-13.
