---
name: vendor-lock-inventory
description: >
  Inventory vendor-specific commercial dependencies that create
  lock-in beyond the standard commercial-component set
  (`devexpress-serenity-dependency-detector`). Covers: Control-M
  (BMC batch scheduler), Globalscape EFT (SFTP server), Unisys
  eWorkflow / InfoImage (ECM), Finalist / Melissa Data (address
  standardization), IPC (certificate printing), SelectPDF (PDF
  generation). RMS is the most vendor-locked ATLAS app — 5 distinct
  vendor dependencies (Control-M + Globalscape + Finalist +
  Unisys + IPC). Modernization TCO scales with vendor count.
  Runs as Discovery conditional when any of these vendors is
  referenced. Triggers on vendor-lock audit, commercial-dependency
  scoring, or @vendor-lock-inventory.
agent: sonnet
allowed-tools:
  - Read
  - Write
  - Grep
  - Glob
validation_commands:
  - "python -m olympus.validators.schema_validator vendor-lock-inventory.json"
  - "python -m olympus.validators.schema_validator vendor-lock-tco-findings.json"
supported_stacks:
  - control-m
  - globalscape-eft
  - unisys-eworkflow
  - infoimage
  - finalist
  - melissa
  - ipc
  - selectpdf
anti_target_stacks:
  - open-source-only
  - cloud-native-only
  - static-site
failure_classes:
  - vendor-product-misidentified
  - licensing-model-unclear
  - replacement-unavailable
  - integration-point-missed
benchmark_tags:
  - discovery-vendor
  - commercial-dependency
  - tco-analysis
  - modernization-cost-estimation
---

# vendor-lock-inventory

## Purpose
Catalog vendor-specific commercial dependencies that create lock-
in; emit TCO inputs for Rationalization and modernization planning.

## Inputs
- Repository tree.
- Application catalog entry.

## Outputs
- `vendor-lock-inventory.json` — per vendor product: `{vendor,
  product, license_model, evidence[], integration_points[],
  replacement_recommendation}`.
- `vendor-lock-tco-findings.json` — per vendor: `{estimated_annual_license,
  estimated_migration_effort_hours, risk_factors[]}`.

## Methodology
1. Grep for vendor product names across source and config:
   - Control-M: `ctm`, `ControlM`, `.jil`, `BMC`.
   - Globalscape EFT: `EFT`, `GlobalScape`, `EFTClient`.
   - Unisys eWorkflow / InfoImage: `InfoImage`, `eWorkflow`,
     `ewf`, `Unisys`.
   - Finalist: `Finalist`, `FINALIST`.
   - Melissa Data: `Melissa`, `MelissaData`.
   - IPC: `IPC`, cert printing references.
   - SelectPDF: `SelectPdf`, `SelectPDF`.
2. Classify each as strong/weak signal and record integration
   points.
3. Emit TCO findings.

## Tech-Stack Dispatch

No external references.

## Gotchas
- Vendor names often appear in comments, not package refs.
- Some replacements are non-trivial:
  - Control-M → Airflow / Dagster / custom (heavy effort).
  - Globalscape EFT → AWS Transfer Family / Azure Blob / MFT
    service.
  - Unisys InfoImage → SharePoint / S3 + managed search.
  - Finalist / Melissa → Smarty / USPS API.
  - IPC cert printing → in-house print service or commercial
    equivalent.
  - SelectPDF → open-source (QuestPDF, PdfSharp) or cloud
    (DocRaptor).
- Licensing is opaque; commercial is usually annual with
  per-server or per-user pricing.
- Some vendor products have open-source equivalents; others
  don't.

## Quality Rules
- [ ] Every detected vendor product inventoried.
- [ ] Integration points documented per vendor.
- [ ] Replacement recommendation per vendor.
- [ ] TCO finding emitted per vendor.
- [ ] Every record cites `{repo}:{file}:{line}`.

## Common Failure Modes

| Failure Mode | Symptom | Prevention |
|---|---|---|
| Product misidentified | `IPC` treated as generic term, not the vendor | Cross-reference with README and integrations list |
| Replacement suggested without cost | TCO estimate missing | Always include effort + ongoing license cost |

## Handoff Summary
Vendor inventory emitted. Proceed to `tco-analyzer` for
consolidated cost analysis and `disposition-recommender` for
vendor-swap vs preserve decisions.

## References
None.

## Changelog
- 0.1.0 (2026-05-07) — Initial skill. Authored as ATLAS-R-20.
