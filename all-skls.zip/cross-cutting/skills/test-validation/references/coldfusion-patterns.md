# Test Validation — Target: Python (from ColdFusion)

Reference for Test Validation when validating Python test suites produced from ColdFusion migrations.

## Coverage Tool: pytest-cov

### Running Coverage
```bash
# Standard coverage run with branch coverage
pytest --cov=src --cov-report=json --cov-branch

# With terminal output showing missing lines
pytest --cov=src --cov-report=term-missing --cov-branch

# Generate HTML report for visual inspection
pytest --cov=src --cov-report=html --cov-branch

# Multiple report formats simultaneously
pytest --cov=src --cov-report=json --cov-report=term-missing --cov-report=html --cov-branch
```

### Report Parsing

#### JSON Report (coverage.json)
```python
import json

with open("coverage.json") as f:
    data = json.load(f)

# Total coverage percentage
total = data["totals"]["percent_covered"]  # e.g., 85.5
branch_coverage = data["totals"]["percent_covered_branches"]  # e.g., 82.3

# Per-file coverage
for filepath, file_data in data["files"].items():
    pct = file_data["summary"]["percent_covered"]
    missing = file_data["missing_lines"]        # list of line numbers
    missing_branches = file_data["missing_branches"]  # list of [from, to] pairs
```

#### Terminal Report Parsing
```
Name                    Stmts   Miss Branch BrPart  Cover   Missing
---------------------------------------------------------------------
src/users/service.py       45      3     12      2    91%   34-36, 50->52
src/users/router.py        28      0      6      0   100%
---------------------------------------------------------------------
TOTAL                      73      3     18      2    94%
```
Parse the TOTAL line for aggregate coverage. Individual file lines show which
lines and branches are missing.

### Threshold Validation
```python
# Validate against tier thresholds
def validate_coverage(coverage_json_path, tier):
    with open(coverage_json_path) as f:
        data = json.load(f)

    total = data["totals"]["percent_covered"]
    threshold = 90 if tier == 1 else 80

    if total < threshold:
        return False, f"Coverage {total:.1f}% below {threshold}% threshold"
    return True, f"Coverage {total:.1f}% meets {threshold}% threshold"
```

## Assertion Density

### Counting Assertions
Count `assert` statements per test function. Minimum: 2 per test function.

```bash
# Quick assertion count per test file
grep -c "assert" tests/**/*.py

# More precise: count assert per test function
grep -E "^(def test_|    assert)" tests/**/*.py
```

### What Counts as an Assertion
```python
# Standard assertions (count these)
assert result == expected
assert result is not None
assert len(items) == 3

# pytest assertions (count these)
with pytest.raises(ValueError):
    service.process(invalid_input)

# Mock assertions (count these)
mock_repo.save.assert_called_once_with(expected_user)
mock_email.send.assert_not_called()

# NOT assertions (don't count these)
# Bare function calls with no verification
service.process(data)  # calling code without checking result
```

### Assertion Quality Signals
```python
# GOOD: Specific, meaningful assertions
assert user.name == "Alice"
assert response.status_code == 200
assert "error" not in response.json()

# BAD: Tautological or weak assertions
assert True
assert result is not None  # only if None is not a valid error case
assert isinstance(result, dict)  # too permissive
```

## Integration Test Indicators

### Positive Indicators (test IS an integration test)
```python
# Uses httpx AsyncClient with the real app
async with AsyncClient(transport=ASGITransport(app=app)) as client:
    response = await client.get("/api/users/1")

# Uses database fixtures
async def test_create_user(db_session):
    user = User(name="Alice")
    db_session.add(user)
    await db_session.commit()

# Uses external service mocks (mocking at boundary, not internal)
@patch("src.services.payment_client.charge")
async def test_checkout_charges_card(mock_charge):
    mock_charge.return_value = PaymentResult(success=True)
```

### Distinguishing Unit vs Integration
| Signal | Unit Test | Integration Test |
|--------|-----------|-----------------|
| Database | Mocked repository | Real DB (SQLite/test DB) |
| HTTP | No HTTP calls | httpx/TestClient against app |
| External services | Mocked at service layer | Mocked at boundary only |
| Fixtures | Simple objects | DB sessions, app instances |
| Speed | <10ms per test | 50-500ms per test |

## Quality Signals

### Positive Quality Signals
```python
# Parametrized tests — good coverage of edge cases
@pytest.mark.parametrize("input_val,expected", [...])
def test_conversion(input_val, expected):

# Fixtures with proper teardown
@pytest.fixture
async def db_session(engine):
    async with session_factory() as session:
        yield session
        await session.rollback()  # cleanup

# Descriptive test names following given_when_then
def test_get_user_returns_404_when_user_not_found():

# Separate test files per module
tests/users/test_service.py
tests/users/test_router.py
tests/orders/test_service.py
```

### Negative Quality Signals
```python
# NO assertions in test (worthless test)
def test_process_order():
    service.process_order(order_data)
    # test passes but verifies nothing

# Broad exception catch hiding failures
def test_risky_operation():
    try:
        result = service.do_something()
    except Exception:
        pass  # swallows all errors

# Magic numbers without context
def test_calculation():
    assert service.calculate(5, 3) == 17.5  # where does 17.5 come from?

# Testing implementation details instead of behavior
def test_internal_cache():
    service._cache["key"] = "value"  # accessing private state
    assert service._cache_hits == 1

# Duplicate test logic (copy-paste tests)
def test_user_a():
    user = create_user("Alice")
    assert user.name == "Alice"

def test_user_b():  # should be parametrized
    user = create_user("Bob")
    assert user.name == "Bob"
```

## CF Migration-Specific Validation

### Type Safety Tests
ColdFusion silently coerces types. Validate that the Python migration handles these:
```python
# Must have tests for string-to-number conversion boundaries
# Must have tests for empty string vs None vs missing key
# Must have tests for date format parsing (CF is very permissive)
# Must have tests for boolean coercion ("true"/"yes"/"1" → True)
```

### Scope Variable Tests
Verify that CF scope variables were properly converted:
- `application.*` → application state (Redis/config)
- `session.*` → session store
- `request.*` → request-scoped dependencies
- `url.*` / `form.*` → FastAPI query params / request body

### Query Result Tests
CF query objects behave differently from SQLAlchemy results:
- CF queries are iterable with `.recordCount`, `.columnList`
- Verify Python code doesn't assume CF query iteration behavior
- Check that empty result handling matches (CF returns empty query, not None)
