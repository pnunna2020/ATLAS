# Test Validation — Target: Spring Boot (from Java EE)

Reference for Test Validation when validating Spring Boot test suites produced from Java EE migrations.

## Coverage Tool: JaCoCo

### Running Coverage
```bash
# Run tests and generate report
mvn test jacoco:report

# Generate CSV report for programmatic parsing
mvn test jacoco:report -Djacoco.formats=csv

# Run with threshold check (fails build if below threshold)
mvn verify

# Skip tests but keep coverage (useful for CI debugging)
mvn test -Djacoco.skip=false
```

### Report Locations
```
target/site/jacoco/
├── jacoco.csv          ← CSV for programmatic parsing
├── jacoco.xml          ← XML for CI tools (SonarQube, etc.)
├── index.html          ← human-readable HTML report
└── jacoco.exec         ← raw execution data
```

### Report Parsing

#### CSV Report (jacoco.csv)
```
GROUP,PACKAGE,CLASS,INSTRUCTION_MISSED,INSTRUCTION_COVERED,BRANCH_MISSED,BRANCH_COVERED,LINE_MISSED,LINE_COVERED,COMPLEXITY_MISSED,COMPLEXITY_COVERED,METHOD_MISSED,METHOD_COVERED
myapp,com.example.users,UserService,12,145,2,18,3,42,4,22,1,15
myapp,com.example.users,UserController,5,89,0,8,1,28,1,10,0,8
```

```python
import csv

def parse_jacoco_csv(filepath):
    total_missed = 0
    total_covered = 0
    with open(filepath) as f:
        reader = csv.DictReader(f)
        for row in reader:
            total_missed += int(row["INSTRUCTION_MISSED"])
            total_covered += int(row["INSTRUCTION_COVERED"])

    total = total_missed + total_covered
    coverage_pct = (total_covered / total * 100) if total > 0 else 0
    return coverage_pct
```

#### XML Report Parsing
```xml
<!-- jacoco.xml structure -->
<report name="myapp">
  <package name="com/example/users">
    <class name="com/example/users/UserService">
      <counter type="INSTRUCTION" missed="12" covered="145"/>
      <counter type="BRANCH" missed="2" covered="18"/>
      <counter type="LINE" missed="3" covered="42"/>
    </class>
  </package>
  <counter type="INSTRUCTION" missed="17" covered="234"/>  <!-- totals -->
</report>
```

### Threshold Validation
```python
def validate_coverage(jacoco_csv_path, tier):
    coverage = parse_jacoco_csv(jacoco_csv_path)
    threshold = 90 if tier == 1 else 80

    if coverage < threshold:
        return False, f"Coverage {coverage:.1f}% below {threshold}% threshold"
    return True, f"Coverage {coverage:.1f}% meets {threshold}% threshold"
```

## Assertion Density

### Counting Assertions
Count assertion method calls per test method. Minimum: 2 per `@Test` method.

```bash
# Count assertions per test file
grep -cE "(assertThat|assertEquals|assertTrue|assertFalse|assertNotNull|assertThrows|verify\()" src/test/**/*.java

# Count @Test methods
grep -c "@Test" src/test/**/*.java
```

### What Counts as an Assertion
```java
// AssertJ assertions (preferred — count these)
assertThat(result.getName()).isEqualTo("Alice");
assertThat(items).hasSize(3).contains(expected);
assertThatThrownBy(() -> service.get(999L)).isInstanceOf(NotFoundException.class);

// JUnit assertions (count these)
assertEquals("Alice", result.getName());
assertTrue(result.isActive());
assertThrows(NotFoundException.class, () -> service.get(999L));

// Mockito verifications (count these)
verify(repository).save(any(User.class));
verify(emailService, never()).send(any());
verifyNoMoreInteractions(repository);

// MockMvc assertions (count these)
.andExpect(status().isOk())
.andExpect(jsonPath("$.name").value("Alice"))
```

### Assertion Quality
```java
// GOOD: Specific field-level assertions
assertThat(user.getName()).isEqualTo("Alice");
assertThat(user.getEmail()).isEqualTo("alice@test.com");
assertThat(response.getStatusCode()).isEqualTo(HttpStatus.OK);

// BAD: Overly broad assertions
assertNotNull(result);          // verifies existence, not correctness
assertTrue(result instanceof User);  // too permissive
assertEquals(user, result);     // relies on equals() — opaque if it fails
```

## Integration Test Indicators

### Spring Test Annotations
```java
// Full application context — integration test
@SpringBootTest
@SpringBootTest(webEnvironment = RANDOM_PORT)

// Slice tests — partial integration
@WebMvcTest(UserController.class)     // web layer only
@DataJpaTest                           // JPA layer only
@WebFluxTest                           // reactive web layer

// NOT integration tests (pure unit test)
@ExtendWith(MockitoExtension.class)    // no Spring context
```

### Distinguishing Unit vs Integration
| Signal | Unit Test | Integration Test |
|--------|-----------|-----------------|
| Annotation | `@ExtendWith(MockitoExtension)` | `@SpringBootTest` / `@DataJpaTest` |
| Database | `@Mock` repository | H2 in-memory or Testcontainers |
| HTTP | No HTTP | `MockMvc` or `TestRestTemplate` |
| Spring context | No context loaded | Context loaded (slow) |
| Speed | <10ms | 100ms-5s |

### Test Naming Convention
```java
// Expected pattern: methodName_expectedBehavior_condition
void getUserById_returnsUser_whenUserExists()
void getUserById_throwsNotFound_whenUserMissing()
void createUser_savesAndReturnsUser_withValidInput()
void createUser_throwsValidation_withInvalidEmail()
```

## Quality Signals

### Positive Quality Signals
```java
// Parameterized tests — good edge case coverage
@ParameterizedTest
@CsvSource({"ACTIVE,true", "INACTIVE,false", "SUSPENDED,false"})
void isActive_returnsCorrectStatus(UserStatus status, boolean expected)

// Nested test classes for organization
@Nested
class WhenUserExists {
    @Test void returnsUser() { ... }
    @Test void returnsCorrectFields() { ... }
}

@Nested
class WhenUserMissing {
    @Test void throwsNotFoundException() { ... }
}

// Test data builders / factories
User user = UserBuilder.aUser().withName("Alice").withRole(ADMIN).build();

// @Sql for database state setup
@Sql("/test-data/users.sql")
@Test void findActiveUsers_returnsOnlyActiveUsers()
```

### Negative Quality Signals
```java
// Empty test body — worthless
@Test
void testSomething() {
    // TODO: implement
}

// No assertions — test always passes
@Test
void processOrder() {
    service.processOrder(orderData);
    // no assert, no verify — proves nothing
}

// @Disabled without reason — tech debt indicator
@Disabled
@Test
void testComplexScenario() { ... }
// Should be: @Disabled("Blocked by JIRA-1234: payment service mock not ready")

// Catching and ignoring exceptions
@Test
void testEdgeCase() {
    try {
        service.riskyOperation();
    } catch (Exception e) {
        // silently passes
    }
}

// Thread.sleep in tests — flaky test indicator
@Test
void testAsync() throws Exception {
    service.asyncProcess();
    Thread.sleep(5000);  // fragile timing dependency
    assertThat(result).isNotNull();
}
// Use: Awaitility.await().atMost(5, SECONDS).until(() -> result != null);
```

## Java EE Migration-Specific Validation

### Transaction Boundary Tests
EJB container-managed transactions behave differently from Spring `@Transactional`:
```java
// Must have tests verifying rollback behavior
@Test
void createOrder_rollsBack_whenPaymentFails() {
    assertThrows(PaymentException.class, () ->
        orderService.createOrder(orderData));

    // Verify the order was NOT persisted (transaction rolled back)
    assertThat(orderRepository.findAll()).isEmpty();
}
```

### JNDI Replacement Tests
Verify that all JNDI lookups were replaced with proper dependency injection:
```bash
# Should find ZERO matches in migrated code
grep -r "InitialContext\|ctx.lookup\|java:comp/env" src/main/java/
```

### Vendor API Replacement Tests
Test that vendor-specific APIs were properly replaced:
- WebSphere `WorkManager` → Spring `@Async` + `TaskExecutor`
- JBoss-specific annotations → Standard Spring annotations
- Container-managed auth → Spring Security

### Serialization Tests
EJB Remote interfaces used Java serialization. Spring uses JSON (Jackson):
```java
// Must have tests verifying JSON serialization of all DTOs
@Test
void userDto_serializesToJson_correctly() throws Exception {
    UserDto dto = new UserDto(1L, "Alice", "alice@test.com");
    String json = objectMapper.writeValueAsString(dto);
    assertThat(json).contains("\"name\":\"Alice\"");

    UserDto deserialized = objectMapper.readValue(json, UserDto.class);
    assertThat(deserialized.getName()).isEqualTo("Alice");
}
```

### EJB Lifecycle Tests
Verify `@PostConstruct` / `@PreDestroy` behavior is preserved:
```java
@SpringBootTest
@Test
void serviceBean_initializesCorrectly_onContextStartup() {
    // @PostConstruct logic should have run
    assertThat(service.isInitialized()).isTrue();
    assertThat(service.getCacheSize()).isGreaterThan(0);
}
```
