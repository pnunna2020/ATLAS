---
name: test-validation
description: >
  Validate generated code against test specifications, running full test suites and producing coverage reports. Use during P4.3 after generation. Triggers on test validation, test execution, coverage report, or test results.
agent: sonnet
allowed-tools:
  - Read
  - Write
  - Bash
  - Grep
---

# Test Validation

## Purpose
Execute and verify the generated test suite, ensuring coverage thresholds are met.

## Tech-Stack Dispatch
Before validating tests, detect the target technology stack and load the appropriate
coverage tool reference:
- Python/FastAPI (from ColdFusion) → Read references/coldfusion-patterns.md
- Spring Boot (from Java EE) → Read references/java-ee-patterns.md
- .NET 8 (from legacy .NET) → future — coordinate with the client profile .NET addendum
- Node.js (from various) → future — coordinate with the client profile Node.js addendum

## Gotchas
- **80% unit test coverage is the MINIMUM for G-04c**: Below 80% is a gate
  failure, regardless of how clean the code looks.
- **Coverage ≠ quality**: 100% line coverage with no assertions is worthless.
  Check assertion density, not just coverage percentage.
- **Integration tests supplement unit tests**: Unit tests validate modules in
  isolation. Integration tests validate they work together. Both are needed.

## Quality Rules
- [ ] Unit test coverage meets minimum 80% line coverage for G-04c gate passage
- [ ] Branch coverage meets minimum 70% — line coverage alone is insufficient
- [ ] Assertion density is verified — tests with no assertions do not count toward coverage
- [ ] Integration tests exist alongside unit tests — both types are required
- [ ] Test results are reproducible — no flaky tests that pass intermittently
- [ ] Coverage reports are generated in machine-parseable format for gate automation

## Common Failure Modes
| Failure Mode | Symptom | Prevention |
|-------------|---------|------------|
| High coverage, low assertions | 95% line coverage but tests only exercise code paths without verifying behavior; bugs ship | Check assertion density; flag tests with zero assertions |
| Flaky tests | Tests pass locally but fail in CI (or vice versa); build is unreliable | Isolate tests from external dependencies; use mocks consistently; fix flaky tests before gate |
| Unit tests only | Modules pass individually but fail when integrated; inter-module contract violations | Require integration tests alongside unit tests; validate module interaction contracts |
| Coverage below threshold | 75% coverage submitted for G-04c; gate fails; rework cycle | Monitor coverage during generation; address gaps before gate submission |

## Handoff Summary
When this skill completes, verify:
1. Unit test coverage >=80% line, >=70% branch
2. Assertion density is verified (no empty tests)
3. Integration tests exist and pass
4. All tests are reproducible (no flaky tests)
Then proceed to: gate `G-04c` for generation quality review, and `parity-verifier` (P5.1) for behavioral equivalence testing
