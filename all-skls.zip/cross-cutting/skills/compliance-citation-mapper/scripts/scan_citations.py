#!/usr/bin/env python3
"""Scan a source tree for regulatory citations and emit a traceability artifact.

Walks a source directory and detects citations to:

* U.S. Code (e.g. ``49 USC 44107``, ``49 U.S.C. 44107(a)``)
* Code of Federal Regulations (e.g. ``14 CFR Part 61``, ``14 CFR 49.17(b)``)
* Public Laws (e.g. ``Pub. L. 117-58``)
* Federal Register (e.g. ``88 Fed. Reg. 12345``)
* Executive Orders (e.g. ``EO 13526``, ``Executive Order 13526``)
* FAA Orders (e.g. ``FAA Order 8130.2``)

Output is a single JSON document conforming to
``schemas/discovery/compliance-citations.schema.json``, printed to stdout so
the compliance-citation-mapper skill (and any downstream gate / OSCAL
mapper) can consume it directly.

Dependencies: pure standard library. No click/typer/regex-third-party.

CLI::

    python scan_citations.py <source_path> \\
        [--max-files N] \\
        [--min-confidence low|medium|high] \\
        [--application-name NAME] [--application-id ID] \\
        [--output PATH]
"""
from __future__ import annotations

import argparse
import datetime as _dt
import json
import re
import sys
from collections import defaultdict
from pathlib import Path
from typing import Iterable

# ── Walk policy ──────────────────────────────────────────────────────────

# Directories we never descend into — they pollute counts with deps /
# build artifacts / vcs internals.
_SKIP_DIRS = frozenset({
    ".git",
    "node_modules",
    "bin",
    "obj",
    "target",
    "dist",
    "build",
    ".venv",
    "venv",
    "__pycache__",
})

# File extensions that may contain citations. Binary-heavy formats (pdf,
# docx, tiff) are excluded — too expensive to scan in-skill; the gap-
# analysis doc calls out PDFs explicitly.
_SCANNABLE_EXTENSIONS = frozenset({
    ".cs",
    ".vb",
    ".java",
    ".py",
    ".ts",
    ".tsx",
    ".js",
    ".jsx",
    ".sql",
    ".md",
    ".txt",
    ".rst",
    ".cshtml",
    ".asp",
    ".aspx",
    ".asmx",
    ".nsp",
    ".nsn",
    ".nss",
    ".nsr",
    ".nsb",
    ".cpy",
    ".copy",
    ".jcl",
    ".cbl",
    ".cob",
    ".cfc",
    ".cfm",
    ".go",
    ".rb",
    ".php",
})

# Per-file read cap — generous; citations cluster near the top of files
# (doc comments) but we also scan bodies for inline SQL comments. 2 MB is
# well above typical source-file sizes and stops runaway reads on
# binary-adjacent text.
_MAX_FILE_BYTES = 2 * 1024 * 1024

_CONFIDENCE_ORDER = {"low": 0, "medium": 1, "high": 2}

# Comment markers across the scannable languages. If a citation's
# surrounding line begins (after whitespace) with one of these, or the
# nearest preceding non-blank line does, we treat it as "in a comment" —
# the strongest semantic signal.
_COMMENT_PREFIXES = (
    "--",    # SQL, Ada
    "//",    # C-family, Java, C#, JS, TS, Go
    "#",     # Python, Ruby, shell
    "*",     # inside C-block comments, /* ... */
    "/*",    # C-block start
    "'",     # VB / VBScript / Classic ASP
    "rem ",  # Batch / older VB / BASIC
    "!",     # NATURAL / Fortran
    ";",     # JCL / Lisp / asm
    "%",     # LaTeX / Erlang
    "//*",   # JCL comment
    "<!--",  # HTML / XML
)

# Docstring / block-comment opener tokens — the presence of any of these
# on the same line as a cite is strong evidence of "documentation" intent.
_DOCSTRING_MARKERS = ('"""', "'''", "/**", "/*!", "<summary>", "<remarks>")

# Markdown / prose file extensions — a cite in one of these counts as
# medium confidence (documentation, not code).
_DOC_EXTENSIONS = frozenset({".md", ".txt", ".rst"})

# ── Citation patterns ────────────────────────────────────────────────────
#
# Each pattern uses named groups so we can normalize the match without
# re-parsing the text. Patterns are tuned for the common FAA-domain
# citation styles described in references/citation-patterns.md.

# 49 USC §44107 / 49 U.S.C. 44107 / 49 U. S. C. §44107(a) / 49 USC 44107a
_USC_RE = re.compile(
    r"\b(?P<title>\d{1,3})\s+U\.?\s?S\.?\s?C\.?"
    r"\s*(?:§+|[Ss]ec(?:tion|\.)?\s*)?"
    r"\s*(?P<section>\d+[A-Za-z]?)"
    r"(?:\s*\((?P<subsection>[A-Za-z0-9]+)\))?",
)

# 14 CFR Part 61 / 14 CFR §49.17 / 14 C.F.R. 49.17(b) / 14 CFR 107.29
_CFR_RE = re.compile(
    r"\b(?P<title>\d{1,3})\s+C\.?\s?F\.?\s?R\.?"
    r"\s*(?:(?P<part_kw>Part)\s+)?"
    r"\s*(?:§+|[Ss]ec(?:tion|\.)?\s*)?"
    r"\s*(?P<section>\d+(?:\.\d+)?)"
    r"(?:\s*\((?P<subsection>[A-Za-z0-9]+)\))?",
)

# Pub. L. 117-58 / Public Law 117-58
_PL_RE = re.compile(
    r"\b(?:Pub(?:lic)?\.?\s?L(?:aw)?\.?)\s*(?P<title>\d+-\d+)",
    re.IGNORECASE,
)

# 88 Fed. Reg. 12345
_FR_RE = re.compile(
    r"\b(?P<title>\d{1,3})\s+Fed\.?\s*Reg\.?\s*(?P<section>\d{1,6})",
    re.IGNORECASE,
)

# EO 13526 / Executive Order 13526
_EO_RE = re.compile(
    r"\b(?:EO|E\.O\.|Executive\s+Order)\s*(?P<section>\d{3,6})",
    re.IGNORECASE,
)

# FAA Order 8130.2 / FAA Order 8900.1
_FAA_ORDER_RE = re.compile(
    r"\bFAA\s+Order\s+(?P<section>\d{4}\.\d+[A-Z]?)",
    re.IGNORECASE,
)

# Authority aliases — FAA forms whose legal authority is a specific CFR
# citation but which appear in source *without* the CFR literal. Scanning
# the bare form number lets us detect Part 67 / Part 121 / etc. in apps
# that only reference the form (e.g., medxpress-mock uses "Form 8500"
# throughout with no explicit "14 CFR" anchor). Each alias expands to a
# synthetic CFR match at the form's site; confidence is capped at "medium"
# because the alias is indirect.
#
# Keep entries narrow and well-sourced: a form number appearing in code
# means the app is subject to the CFR authority, which is exactly what
# Rationalization and the compliance gate need to see.
_FORM_ALIASES: tuple[tuple[re.Pattern[str], str, str, str], ...] = (
    # FAA Form 8500-8 — Application for Airman Medical Certificate;
    # authorized under 14 CFR Part 67 (Medical Standards). Catch both
    # "Form 8500" and the full "Form 8500-N" variants.
    (
        re.compile(r"\bForm\s+8500(?:-\d+)?\b", re.IGNORECASE),
        "14", "67",
        "Form 8500 → 14 CFR Part 67 (Medical Standards and Certification)",
    ),
)


def _clip(value: str | None, max_len: int = 240) -> str | None:
    if value is None:
        return None
    value = value.strip()
    if len(value) <= max_len:
        return value
    return value[: max_len - 1] + "…"


def _looks_like_comment(line: str) -> bool:
    """Return True if the stripped line appears to start a comment."""
    stripped = line.lstrip()
    if not stripped:
        return False
    lowered = stripped.lower()
    for prefix in _COMMENT_PREFIXES:
        if lowered.startswith(prefix):
            return True
    # Docstring / block-comment fences.
    for marker in _DOCSTRING_MARKERS:
        if marker in stripped[:40]:
            return True
    return False


def _classify_confidence(file_path: Path, line: str, prev_lines: list[str]) -> str:
    """Pick a confidence tier for a citation on ``line``.

    Order of evaluation:

    1. Inside a comment/docstring on the same line → ``high``.
    2. Inside a doc/markdown/txt/rst extension → ``medium``.
    3. Nearest non-blank preceding line is a comment (block-comment
       continuation) → ``high``.
    4. Otherwise → ``low`` (bare string literal, prose inside code).
    """
    if _looks_like_comment(line):
        return "high"
    suffix = file_path.suffix.lower()
    if suffix in _DOC_EXTENSIONS:
        return "medium"
    # Walk up to 3 preceding non-blank lines to detect block-comment
    # continuation (e.g., ``/**   49 USC §44107``).
    for candidate in reversed(prev_lines[-5:]):
        if not candidate.strip():
            continue
        if _looks_like_comment(candidate):
            return "high"
        break
    return "low"


def _normalize_usc(match: re.Match, file_path: Path, line_no: int, line: str, prev: list[str]) -> dict:
    title = match.group("title")
    section = match.group("section")
    subsection = match.group("subsection")
    return {
        "authority": "USC",
        "title": title,
        "section": section,
        "subsection": subsection if subsection else None,
        "raw": match.group(0).strip(),
        "file": str(file_path),
        "line": line_no,
        "context": _clip(line),
        "confidence": _classify_confidence(file_path, line, prev),
    }


def _normalize_cfr(match: re.Match, file_path: Path, line_no: int, line: str, prev: list[str]) -> dict:
    title = match.group("title")
    section = match.group("section")
    subsection = match.group("subsection")
    return {
        "authority": "CFR",
        "title": title,
        "section": section,
        "subsection": subsection if subsection else None,
        "raw": match.group(0).strip(),
        "file": str(file_path),
        "line": line_no,
        "context": _clip(line),
        "confidence": _classify_confidence(file_path, line, prev),
    }


def _normalize_pl(match: re.Match, file_path: Path, line_no: int, line: str, prev: list[str]) -> dict:
    return {
        "authority": "PL",
        "title": match.group("title"),
        "section": match.group("title"),  # PL = identifier only
        "subsection": None,
        "raw": match.group(0).strip(),
        "file": str(file_path),
        "line": line_no,
        "context": _clip(line),
        "confidence": _classify_confidence(file_path, line, prev),
    }


def _normalize_fr(match: re.Match, file_path: Path, line_no: int, line: str, prev: list[str]) -> dict:
    return {
        "authority": "FR",
        "title": match.group("title"),
        "section": match.group("section"),
        "subsection": None,
        "raw": match.group(0).strip(),
        "file": str(file_path),
        "line": line_no,
        "context": _clip(line),
        "confidence": _classify_confidence(file_path, line, prev),
    }


def _normalize_eo(match: re.Match, file_path: Path, line_no: int, line: str, prev: list[str]) -> dict:
    return {
        "authority": "EO",
        "title": "EO",
        "section": match.group("section"),
        "subsection": None,
        "raw": match.group(0).strip(),
        "file": str(file_path),
        "line": line_no,
        "context": _clip(line),
        "confidence": _classify_confidence(file_path, line, prev),
    }


def _normalize_faa(match: re.Match, file_path: Path, line_no: int, line: str, prev: list[str]) -> dict:
    return {
        "authority": "FAA-ORDER",
        "title": "FAA",
        "section": match.group("section"),
        "subsection": None,
        "raw": match.group(0).strip(),
        "file": str(file_path),
        "line": line_no,
        "context": _clip(line),
        "confidence": _classify_confidence(file_path, line, prev),
    }


def _normalize_alias(
    match: re.Match,
    file_path: Path,
    line_no: int,
    line: str,
    prev: list[str],
    *,
    title: str,
    section: str,
    gloss: str,
) -> dict:
    """Build a synthetic CFR citation from a form-number alias match.

    Confidence is clamped to at most ``medium`` — the alias is indirect,
    so we never claim the same certainty as a literal ``14 CFR`` match.
    """
    raw = _classify_confidence(file_path, line, prev)
    if raw == "high":
        confidence = "medium"
    else:
        confidence = raw
    return {
        "authority": "CFR",
        "title": title,
        "section": section,
        "subsection": None,
        "raw": match.group(0).strip(),
        "file": str(file_path),
        "line": line_no,
        "context": _clip(line),
        "confidence": confidence,
        "alias_for": gloss,
    }


# Ordered list of (regex, normalizer) pairs. Order matters: USC / CFR are
# tried before the looser PL/EO/FR patterns because USC/CFR produce more
# structured output when a line could lexically match multiple patterns.
_PATTERNS: tuple[tuple[re.Pattern[str], callable], ...] = (
    (_USC_RE, _normalize_usc),
    (_CFR_RE, _normalize_cfr),
    (_PL_RE, _normalize_pl),
    (_FR_RE, _normalize_fr),
    (_EO_RE, _normalize_eo),
    (_FAA_ORDER_RE, _normalize_faa),
)


def _iter_files(source_root: Path, max_files: int) -> Iterable[Path]:
    """Yield files under ``source_root`` honouring the skip list and cap."""
    count = 0
    for path in source_root.rglob("*"):
        if path.is_dir():
            continue
        if any(part in _SKIP_DIRS for part in path.parts):
            continue
        if not path.is_file():
            continue
        if path.suffix.lower() not in _SCANNABLE_EXTENSIONS:
            continue
        count += 1
        if count > max_files:
            return
        yield path


def _scan_file(path: Path, source_root: Path) -> list[dict]:
    """Return every citation detected in ``path`` (repo-relative)."""
    try:
        # Read up to _MAX_FILE_BYTES — enough for even long SQL scripts.
        with path.open("rb") as handle:
            raw = handle.read(_MAX_FILE_BYTES)
    except OSError:
        return []
    try:
        text = raw.decode("utf-8", errors="replace")
    except Exception:
        return []

    rel_path = path.relative_to(source_root)
    citations: list[dict] = []
    lines = text.splitlines()
    for line_no, line in enumerate(lines, start=1):
        prev = lines[max(0, line_no - 6) : line_no - 1]
        for regex, normalizer in _PATTERNS:
            for match in regex.finditer(line):
                citations.append(
                    normalizer(match, rel_path, line_no, line, prev)
                )
        for alias_re, title, section, gloss in _FORM_ALIASES:
            for match in alias_re.finditer(line):
                citations.append(
                    _normalize_alias(
                        match, rel_path, line_no, line, prev,
                        title=title, section=section, gloss=gloss,
                    )
                )
    return citations


def _canonical_key(cite: dict) -> tuple[str, str, str, str]:
    return (
        cite["authority"],
        cite["title"],
        cite["section"],
        cite.get("subsection") or "",
    )


def scan(
    source_path: Path,
    *,
    max_files: int,
    min_confidence: str,
) -> dict:
    """Walk ``source_path`` and return the full artifact dict."""
    threshold = _CONFIDENCE_ORDER.get(min_confidence, 0)
    all_citations: list[dict] = []
    for file_path in _iter_files(source_path, max_files):
        for cite in _scan_file(file_path, source_path):
            if _CONFIDENCE_ORDER[cite["confidence"]] < threshold:
                continue
            # Clean up None-valued context fields so the artifact is tidy.
            if cite.get("context") is None:
                cite.pop("context", None)
            all_citations.append(cite)

    by_authority: dict[str, int] = defaultdict(int)
    unique_keys: set[tuple[str, str, str, str]] = set()
    for cite in all_citations:
        by_authority[cite["authority"]] += 1
        unique_keys.add(_canonical_key(cite))

    return {
        "citations": all_citations,
        "summary": {
            "total_citations": len(all_citations),
            "unique_citations": len(unique_keys),
            "by_authority": dict(by_authority),
        },
    }


def build_artifact(
    source_path: Path,
    *,
    application_name: str,
    application_id: str,
    max_files: int,
    min_confidence: str,
    assessed_date: str | None = None,
) -> dict:
    """Produce the complete schema-compliant artifact."""
    body = scan(source_path, max_files=max_files, min_confidence=min_confidence)
    return {
        "application": {"name": application_name, "id": application_id},
        "assessed_date": assessed_date or _dt.date.today().isoformat(),
        "source_path": str(source_path),
        "citations": body["citations"],
        "summary": body["summary"],
    }


def _parse_args(argv: list[str]) -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Detect regulatory citations in a source tree.",
    )
    parser.add_argument("source_path", type=Path, help="Directory to scan")
    parser.add_argument(
        "--max-files",
        type=int,
        default=5000,
        help="Cap the number of files scanned (default: 5000).",
    )
    parser.add_argument(
        "--min-confidence",
        choices=("low", "medium", "high"),
        default="low",
        help="Minimum confidence tier to include (default: low).",
    )
    parser.add_argument(
        "--application-name",
        default="unknown",
        help="Application display name (written into the artifact).",
    )
    parser.add_argument(
        "--application-id",
        default="app-unknown",
        help="Application id (written into the artifact).",
    )
    parser.add_argument(
        "--output",
        type=Path,
        default=None,
        help="Write the artifact to this path instead of stdout.",
    )
    return parser.parse_args(argv)


def main(argv: list[str] | None = None) -> int:
    args = _parse_args(argv or sys.argv[1:])
    root = args.source_path
    if not root.exists() or not root.is_dir():
        print(
            json.dumps({"error": f"not a directory: {root}"}),
            file=sys.stderr,
        )
        return 2
    artifact = build_artifact(
        root,
        application_name=args.application_name,
        application_id=args.application_id,
        max_files=max(1, args.max_files),
        min_confidence=args.min_confidence,
    )
    payload = json.dumps(artifact, indent=2, sort_keys=True)
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(payload, encoding="utf-8")
    else:
        print(payload)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
