---
name: compliance-citation-mapper
description: >
  Scan a legacy application's source code and documentation for U.S. Code,
  Code of Federal Regulations, Public Law, Federal Register, Executive Order,
  and FAA Order citations and emit a traceability artifact
  (compliance-citations.json) that links each citation back to the file:line
  where it appears. Produced during Rationalization so modernization work can
  preserve regulatory provenance — every business rule that encodes a
  statutory obligation stays linked to the statute it implements.
  Triggers on regulatory citation detection, compliance traceability,
  USC/CFR mapping, regulation-to-code linkage, statute provenance, or
  @compliance-citation-mapper mentions.
agent: sonnet
allowed-tools:
  - Read
  - Grep
  - Bash
validation_commands:
  - "python cross-cutting/skills/compliance-citation-mapper/scripts/scan_citations.py --help"
  - "python -c \"import jsonschema, json, pathlib; s=json.loads(pathlib.Path('schemas/discovery/compliance-citations.schema.json').read_text()); jsonschema.Draft202012Validator.check_schema(s)\""
supported_stacks:
  - csharp
  - dotnet
  - vbnet
  - java
  - python
  - typescript
  - javascript
  - coldfusion
  - plsql
  - tsql
  - natural
  - cobol
  - classic-asp
anti_target_stacks:
  - static-site
  - single-page-app-no-backend
failure_classes:
  - false-positive-string-match
  - missed-cite-in-pdf
  - citation-normalization-drift
  - comment-context-misread
benchmark_tags:
  - rationalization-compliance
  - regulatory-traceability
  - citation-coverage
---

# compliance-citation-mapper

## Purpose
FAA (and most federal) systems encode regulatory obligations directly in
code: a pilot-eligibility stored procedure enforces 14 CFR Part 61, an
aircraft-title recordation trigger implements 49 USC §44107, a designee
management workflow operationalizes 14 CFR Part 183. When an application
is rationalized and a disposition (Refactor, Rearchitect, Replace,
Consolidate) is chosen, the replacement *must* carry the same regulatory
linkage or the agency loses its audit trail. This skill is the detection
pass: it finds every citation in code + docs and writes a per-app
traceability artifact so cato-compliance, safety-critical-verifier, and
the traceability-checker gate package can reason about coverage without
re-scanning the source tree.

This skill is *detection only*. It does not judge whether a citation is
current, deprecated, or correctly implemented — those decisions belong to
`cato-compliance` (OSCAL mapping) and `safety-critical-verifier` (T1
gate). Detection in this skill, judgment downstream.

## When to invoke
- Every application during Rationalization (registered as a primary
  skill; no tech-stack filter — compliance traceability is universal).
- Before writing a `disposition-recommendation.json` that proposes
  Replace, Consolidate, or Retire — you need the citation map to
  confirm regulatory obligations will be preserved (or reassigned).
- Before the Modernization Extract pass — the citation list pairs with
  `business-rule-inventory.json` so extracted rules carry their
  statutory lineage into the generated code.

## Inputs
- Application source tree (any of the supported_stacks) — scanned via
  `scripts/scan_citations.py`
- Application catalog entry (JSON per
  `schemas/discovery/application-catalog-entry.schema.json`) — supplies
  the `application.name` and `application.id` fields in the output
- Citation grammar reference: `references/citation-patterns.md`
- FAA-specific catalog: `references/faa-citation-catalog.md`

## Process
The skill runs in three short passes.

### Pass 1 — Regex detection (automated, via script)
Invoke `scripts/scan_citations.py` against the application source path:

```
python scripts/scan_citations.py <source_path> \
    --application-name "<app display name>" \
    --application-id "<app id>" \
    --output compliance-citations.json
```

The script walks the source tree (honouring the skip list in
`references/citation-patterns.md` §2), applies the USC / CFR / PL / FR /
EO / FAA Order regex patterns, and classifies each hit into a confidence
tier based on whether the citation appears inside a comment/docstring
(high), in a markdown/documentation file (medium), or as a bare string
literal in code with no surrounding semantic context (low).

### Pass 2 — Catalog cross-check (human-readable review)
Open `references/faa-citation-catalog.md` and for each *unique* citation
in the artifact verify:

1. The citation exists in the curated FAA catalog (expected hit).
2. If not, decide whether it is a new FAA-domain citation (add to
   catalog in a follow-up PR) or a false positive (e.g. a version
   string like `"49 USC 44107"` appearing inside a package manifest).
3. For `other`-authority hits (the script emits `authority: other` only
   via future extensions), add a short gloss to the catalog so
   downstream compliance skills know what the citation means.

### Pass 3 — Output validation (schema round-trip)
Validate the artifact against
`schemas/discovery/compliance-citations.schema.json` using the
draft-2020-12 validator:

```
python -c "import jsonschema, json; jsonschema.Draft202012Validator(
    json.load(open('schemas/discovery/compliance-citations.schema.json'))
).validate(json.load(open('compliance-citations.json')))"
```

An invalid artifact MUST NOT be emitted. Most failures are caused by a
citation where the regex produced an empty `section` (e.g. a truncated
source line); re-run with `--min-confidence medium` to filter noise
from minified JS / generated code.

## Outputs
- `compliance-citations.json` — conforms to
  `schemas/discovery/compliance-citations.schema.json`
  - `application` — `{name, id}` keyed to the application catalog entry
  - `assessed_date` — ISO-8601 scan date
  - `source_path` — repo-relative (or absolute) root of the scanned tree
  - `citations[]` — every hit: `authority` (USC|CFR|PL|FR|EO|FAA-ORDER|other),
    `title`, `section`, optional `subsection`, verbatim `raw` text,
    `file` + `line` provenance, optional `context` snippet, and
    `confidence` (low|medium|high)
  - `summary` — `total_citations`, `unique_citations` (distinct
    authority+title+section+subsection tuples), and a `by_authority`
    histogram

## Gotchas
- **Detection is not compliance.** A citation to 14 CFR Part 61 in a
  comment does not prove the code correctly implements Part 61. That
  judgment is `cato-compliance`'s job. Don't inflate findings.
- **Comments lie.** A stored procedure header may claim it enforces 49
  USC §44107 while the body short-circuits the rule. Flag the
  citation; let `business-logic-extractor` and `safety-critical-verifier`
  verify the behaviour.
- **Low-confidence hits are still useful** — bare string literals often
  occur in generated OpenAPI docs or migration scripts that mention a
  regulation. Keep them in the artifact; downstream consumers filter.
- **PDFs and binary docs are intentionally excluded.** Scanning requires
  OCR/text extraction that is prohibitively expensive per skill run and
  duplicates `tiff-corpus-assessor`. If the app has an authoritative
  reg doc in PDF, link it in the catalog entry, don't scan it here.
- **Citations can span lines.** The regex operates line-by-line for
  simplicity; a citation like `49 USC\n§44107` will miss. This is a
  known trade-off favouring determinism over completeness.

## Quality Rules
- [ ] The emitted artifact passes the
      `schemas/discovery/compliance-citations.schema.json` validator with
      zero errors.
- [ ] Every `citations[]` entry has a `file` + integer `line` >= 1.
- [ ] `summary.total_citations` equals `len(citations)`.
- [ ] `summary.unique_citations` <= `summary.total_citations`.
- [ ] `summary.by_authority` keys are a subset of the `authority` enum
      and sum to `summary.total_citations`.
- [ ] Every unique high-confidence citation either appears in
      `references/faa-citation-catalog.md` or is documented in the PR
      description as a proposed catalog addition.
- [ ] `application.id` matches the catalog-entry application id (not
      the display name).

## Common Failure Modes
| Failure Mode | Symptom | Prevention |
|---|---|---|
| false-positive-string-match | `version: "49.17"` parsed as `14 CFR §49.17` | Context check: the regex requires `CFR` or `USC` as an anchor, but package.json / version strings rarely include `CFR`. If false positives persist, tighten the minimum confidence to `medium`. |
| missed-cite-in-pdf | Authoritative regulation PDF not scanned, cite never appears in artifact | Register the PDF in the catalog entry's supplementary-doc list; scanning PDFs is out of scope here. |
| citation-normalization-drift | Same citation emitted with different `subsection` casing on different runs | Keep `raw` verbatim, but the script normalizes `(A)` → `A` in `subsection`. Do NOT post-process the artifact. |
| comment-context-misread | Cite inside a code literal flagged `high` because the preceding line is a docstring | The script walks up to 5 preceding lines; if the citation is inside a string literal, it may still be labelled `high`. Spot-check top-confidence hits during Pass 2. |

## Handoff Summary
When this skill completes, verify:
1. `compliance-citations.json` exists in the application's discovery
   artifact directory.
2. The artifact passes its schema.
3. `summary.total_citations` is non-zero for any application whose tech
   stack mentions regulatory domains (FAA, DoD, HHS, Treasury). A zero
   result for an FAA app is a red flag — re-run with a lower
   `--min-confidence` threshold.

Then proceed to:
- `cato-compliance` — consumes the citation map to build OSCAL
  control references.
- `safety-critical-verifier` — for T1 apps, checks that every
  high-confidence citation has a corresponding extracted business rule.
- `traceability-checker` (gate package) — ensures each citation links
  to at least one module / entry-point from the structural analysis.

## Reference Files
- `references/citation-patterns.md` — regex grammar, scan policy,
  confidence tiers, normalization rules, cross-skill relationships
- `references/faa-citation-catalog.md` — curated list of FAA-domain
  citations (49 USC, 14 CFR, FAA Orders) with short glosses and the
  ATLAS applications that touch each one
