# FAA Citation Catalog

A hand-curated catalog of U.S. statutory, regulatory, and agency-order
citations relevant to the FAA ATLAS portfolio. Each entry lists the
canonical identifier, a short title, a 1–2 sentence gloss, and the ATLAS
application(s) that encode obligations under the citation. The catalog
is consumed during Pass 2 of the `compliance-citation-mapper` skill to
distinguish legitimate regulatory references from false-positive matches
(e.g., version strings that happen to resemble citations).

Keep entries in numerical order within each section. When a new
application surfaces a citation not already in the catalog, add an entry
in the same PR that updates the application's
`compliance-citations.json`.

---

## 1. United States Code — Title 49 (Transportation)

### 49 USC Subtitle VII — Aviation Programs

#### 49 USC Chapter 401 — General Provisions

- **49 USC §40101** — *Policy*. Declares the federal interest in
  aviation safety and civil aeronautical security. Touched implicitly by
  every ATLAS app; rarely cited directly.
- **49 USC §40103** — *Sovereignty and use of airspace*. Establishes
  FAA's exclusive authority over navigable airspace. Cited in airspace-
  coordination components of legacy mainframe apps.
- **49 USC §40113** — *Administrative*. Grants the Administrator
  general rulemaking authority; commonly cited in preambles to FAA
  rulemakings.

#### 49 USC Chapter 441 — Registration and Recordation of Aircraft

- **49 USC §44101** — *Operation when not registered*. Prohibits
  operating an aircraft without a registration certificate. Referenced
  in aircraft-registration components of rms-mock.
- **49 USC §44107** — *Recordation of conveyances and instruments*.
  Establishes the chronological-order rule for recording aircraft titles,
  mortgages, and security instruments. **Encoded in rms-mock stored
  procedure `usp_Conveyance_Record.sql`.**
- **49 USC §44108** — *Validity of conveyances, leases, and security
  instruments*. Complements §44107 for filing priority rules. Touched
  by rms-mock.
- **49 USC §44109** — *Release from recorded liens*. Stored-procedure
  logic in rms-mock's release workflow cites this section.

#### 49 USC Chapter 447 — Safety Regulation

- **49 USC §44701** — *General requirements*. The FAA's core safety-
  regulation authority. Frequently cited in preambles across rule-
  implementing code.
- **49 USC §44703** — *Airman certificates*. Governs issuance,
  renewal, and revocation of pilot/airman certificates. **Encoded in
  iacra-mock's airman certification workflow.**
- **49 USC §44704** — *Type certificates, production certificates,
  airworthiness certificates, and design organization certificates*.
  Invoked by airworthiness approval code paths.
- **49 USC §44709** — *Amendments, modifications, suspensions, and
  revocations of certificates*. Cited in enforcement-action code.
- **49 USC §44710** — *Revocations of airman certificates for
  controlled substance violations*. Referenced in iacra-mock compliance
  screening.

#### 49 USC Chapter 463 — Penalties

- **49 USC §46301** — *Civil penalties*. Authorizes civil penalties for
  regulatory violations; cited in enforcement subsystems.

---

## 2. Code of Federal Regulations — Title 14 (Aeronautics and Space)

Title 14 CFR is the workhorse regulatory citation in ATLAS. Below are
the parts most commonly encoded in the portfolio, plus specific
sections that surface in stored procedures and business logic.

### Chapter I — Federal Aviation Administration, DOT

#### Part 1 — Definitions and Abbreviations

- **14 CFR Part 1** — Defines the regulatory vocabulary (aircraft,
  airman, airworthy, operate, etc.). Rarely cited by specific section;
  the whole-part reference signals a preamble.

#### Part 13 — Investigative and Enforcement Procedures

- **14 CFR Part 13** — Governs FAA investigations and enforcement
  actions. Cited in enforcement-case-management components.

#### Part 43 — Maintenance, Preventive Maintenance, Rebuilding, and Alteration

- **14 CFR Part 43** — Aircraft maintenance-record rules. Cross-
  references Part 91 operation rules; cited in maintenance-tracking
  code paths.

#### Part 47 — Aircraft Registration

- **14 CFR Part 47** — Aircraft registration procedures. Heavily cited
  in rms-mock registration workflows.
- **14 CFR §47.3** — Registration required. Cited in rms-mock's
  registration-eligibility logic.
- **14 CFR §47.8** — Voting trusts, beneficial ownership. Cited in
  rms-mock compliance subsystems.

#### Part 49 — Recording of Aircraft Titles and Security Documents

- **14 CFR Part 49** — Implements 49 USC §44107 at the regulation
  level. Cited in rms-mock conveyance code.
- **14 CFR §49.17** — *Recording of conveyances in chronological
  order*. **Directly encoded in rms-mock `usp_Conveyance_Record.sql`.**
- **14 CFR §49.31** — *Release of lien*. Cited in rms-mock release
  workflows.

#### Part 61 — Certification: Pilots, Flight Instructors, and Ground Instructors

- **14 CFR Part 61** — The pilot-certification rulebook. **Encoded in
  iacra-mock `sp_Submit_Application_Pilot_61.sql` and related
  workflows.**
- **14 CFR §61.23** — Medical certificate eligibility. Cited in iacra-
  mock prerequisite checks and cross-referenced to Part 67.
- **14 CFR §61.39** — Prerequisites for practical tests. Cited in
  iacra-mock exam-scheduling code.
- **14 CFR §61.109** — Aeronautical experience requirements (private
  pilot). Cited in iacra-mock applicant eligibility calculations.

#### Part 63 — Certification: Flight Crewmembers Other Than Pilots

- **14 CFR Part 63** — Flight engineer, flight navigator certification.
  Touched lightly by iacra-mock.

#### Part 65 — Certification: Airmen Other Than Flight Crewmembers

- **14 CFR Part 65** — Air traffic control tower operators,
  aircraft dispatchers, mechanics, repairmen, parachute riggers.
  Cited in iacra-mock's non-pilot airman workflows.

#### Part 67 — Medical Standards and Certification

- **14 CFR Part 67** — Medical certification standards. **Encoded in
  medxpress-mock form and audit workflows.**
- **14 CFR §67.101** — Eligibility. Cited in medxpress-mock form
  validators.
- **14 CFR §67.401** — Special issuance. Cited in medxpress-mock
  deferral pathways.

#### Part 91 — General Operating and Flight Rules

- **14 CFR Part 91** — The catch-all operation rulebook. Cited
  extensively in training-related ATLAS components.

#### Part 107 — Small Unmanned Aircraft Systems

- **14 CFR Part 107** — sUAS (drone) operations. Likely to appear in
  newer FAA portfolios; not currently encoded in the mock corpus but
  reserved for post-2025 migrations.

#### Part 141 — Pilot Schools

- **14 CFR Part 141** — Certification of pilot schools. Cross-
  referenced from iacra-mock when a student's course-completion graph
  is verified. **Encoded in iacra-mock approved-course workflows.**

#### Part 142 — Training Centers

- **14 CFR Part 142** — Certification of training centers. Cited in
  iacra-mock endorsement and recurrent-training pathways.

#### Part 183 — Representatives of the Administrator

- **14 CFR Part 183** — Designee management (Designated Pilot Examiners,
  Designated Airworthiness Representatives, Aviation Medical Examiners,
  etc.). **Encoded in dms-mock designee-management workflows.**
- **14 CFR §183.11** — Selection. Cited in dms-mock application
  processing.
- **14 CFR §183.15** — Duration of designation. Cited in dms-mock
  renewal workflows.

---

## 3. FAA Orders

FAA Orders are internal agency directives; they do not have regulatory
force but govern how FAA employees and designees operate. They appear
in legacy code as comments explaining *why* a rule is implemented.

- **FAA Order 8130.2** — *Airworthiness Certification of Aircraft*.
  Governs airworthiness-certificate issuance. Cited in airworthiness
  subsystems.
- **FAA Order 8900.1** — *Flight Standards Information Management
  System (FSIMS)*. The reference handbook for flight-standards
  inspectors. Cited in inspector-facing code paths.
- **FAA Order 1100.154** — *Delegated Organization Authorization
  Procedures*. Touches dms-mock (designee delegation flows).

---

## 4. Public Laws Relevant to ATLAS

Public Laws enter ATLAS code through implementation deadlines and
sunset clauses captured in comments or migration notes.

- **Pub. L. 112-95** — *FAA Modernization and Reform Act of 2012*.
  Authorized NextGen work and a raft of airman-certificate changes;
  often cited in legacy comments explaining "why this rule came in".
- **Pub. L. 115-254** — *FAA Reauthorization Act of 2018*. Multi-year
  authorization with numerous small-UAS and certification provisions.
- **Pub. L. 117-103** — *FAA Aircraft Certification Reform and
  Accountability Act* (included in the 2022 omnibus). Tightened
  certification oversight.

---

## 5. Executive Orders Relevant to ATLAS

Most ATLAS code is insulated from EOs, but a few appear in security
and identity-management comments.

- **EO 13526** — *Classified National Security Information*. Governs
  classification of federal records; occasionally cited in rms-mock
  and dms-mock records-retention code.
- **EO 13681** — *Improving the Security of Consumer Financial
  Transactions*. Cited in older payments-adjacent components.

---

## 6. Catalog maintenance

When adding or removing entries:

1. Keep the numerical ordering within each section (USC, CFR, FAA
   Orders, PLs, EOs).
2. Note which ATLAS application touches the citation so Pass 2 of the
   skill can perform a quick sanity-check.
3. If the citation is removed from production code (e.g., a stored
   procedure is retired), strike through the entry with a date and
   the disposition record id, rather than deleting it outright — the
   catalog doubles as audit evidence.
4. Cross-check against the Federal Aviation Regulations (FAR) index at
   <https://www.ecfr.gov/current/title-14> for canonical spelling.

---

## 7. Scope notes

- Citations outside Title 14 CFR, Title 49 USC, and FAA Orders appear
  rarely in ATLAS; when they do (e.g., Title 5 USC §552 for FOIA, Title
  44 USC §3541 for FISMA), log them under Section 1 or a new "Other
  Titles" subsection.
- DoD, DHS, NIST SP-800, and HIPAA citations are explicitly out of
  scope for this catalog — they belong to a parallel catalog keyed to
  the appropriate client profile.
- State and local regulations are not tracked; the detection script
  does not match them.
