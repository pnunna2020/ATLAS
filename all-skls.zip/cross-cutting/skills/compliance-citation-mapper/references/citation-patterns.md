# Citation Grammar and Scan Policy

This reference documents the regex grammar, scan scope, confidence
tiering, normalization rules, and cross-skill relationships used by the
`compliance-citation-mapper` skill and its `scripts/scan_citations.py`
detection script. Read this before tuning the regexes or extending the
authority enum in `schemas/discovery/compliance-citations.schema.json`.

## 1. Citation grammar

Each authority is matched by a single Python `re` pattern so the script
stays stdlib-only. Patterns use **case-insensitive** flags only where
needed (EO, FR, PL) and **named capture groups** so the normalizer can
build the canonical record without a second parse.

### 1.1 United States Code — authority `USC`

Form: `<title> USC [§|Sec|Section] <section>[(<subsection>)]`

```
\b(?P<title>\d{1,3})\s+U\.?\s?S\.?\s?C\.?
\s*(?:§+|[Ss]ec(?:tion|\.)?\s*)?
\s*(?P<section>\d+[A-Za-z]?)
(?:\s*\((?P<subsection>[A-Za-z0-9]+)\))?
```

Accepted inputs:

- `49 USC §44107`
- `49 U.S.C. 44107`
- `49 U. S. C. §44107(a)`
- `49 USC 44107a` (subsection as trailing letter)
- `49 USC Section 44107(a)`
- `49 USC Sec. 44107`

Rejected inputs (by design):

- `49USC44107` — missing whitespace after title
- `U.S.C. 49 §44107` — inverted order

### 1.2 Code of Federal Regulations — authority `CFR`

Form: `<title> CFR [Part] [§|Sec|Section] <section>[(<subsection>)]`

```
\b(?P<title>\d{1,3})\s+C\.?\s?F\.?\s?R\.?
\s*(?:(?P<part_kw>Part)\s+)?
\s*(?:§+|[Ss]ec(?:tion|\.)?\s*)?
\s*(?P<section>\d+(?:\.\d+)?)
(?:\s*\((?P<subsection>[A-Za-z0-9]+)\))?
```

Accepted inputs:

- `14 CFR Part 61`
- `14 CFR §49.17`
- `14 C.F.R. 49.17(b)`
- `14 CFR 107.29`
- `14 CFR Part 183`
- `14 CFR Section 141.55`

Edge cases:

- `14 CFR 61` (a whole-part reference without the word "Part") normalizes
  to `section="61"` with no subsection. Downstream consumers rely on the
  catalog to recognise `{title: "14", section: "61"}` as a Part
  reference.
- `14 CFR §61.23(a)(3)(ii)` captures the first parenthesized group only
  — `subsection` becomes `"a"`. Deeper paragraph navigation is out of
  scope; the verbatim text is preserved in `raw`.

### 1.3 Public Laws — authority `PL`

Form: `Pub. L. <congress>-<number>` or `Public Law <congress>-<number>`.

```
\b(?:Pub(?:lic)?\.?\s?L(?:aw)?\.?)\s*(?P<title>\d+-\d+)
```

Case-insensitive. Examples: `Pub. L. 117-58`, `Public Law 112-95`,
`Pub L 112-95`. Both `title` and `section` fields in the output record
are set to the identifier (e.g. `"117-58"`) because PLs don't have
section numbers at this level of detection.

### 1.4 Federal Register — authority `FR`

Form: `<volume> Fed. Reg. <page>`.

```
\b(?P<title>\d{1,3})\s+Fed\.?\s*Reg\.?\s*(?P<section>\d{1,6})
```

Case-insensitive. Examples: `88 Fed. Reg. 12345`, `88 FED REG 12345`.

### 1.5 Executive Orders — authority `EO`

Form: `EO <number>` or `Executive Order <number>`.

```
\b(?:EO|E\.O\.|Executive\s+Order)\s*(?P<section>\d{3,6})
```

Case-insensitive. `title` is literally `"EO"` in the output; `section`
is the EO number (e.g., `"13526"`).

### 1.6 FAA Orders — authority `FAA-ORDER`

Form: `FAA Order <number>.<sub>[<letter>]`.

```
\bFAA\s+Order\s+(?P<section>\d{4}\.\d+[A-Z]?)
```

Case-insensitive. Examples: `FAA Order 8130.2`, `FAA Order 8900.1B`.
`title` is `"FAA"` and `section` is the order number.

## 2. Scan scope

### 2.1 File extensions

Only files with one of the following extensions are read:

```
.cs  .vb  .java  .py  .ts  .tsx  .js  .jsx  .sql  .md  .txt  .rst
.cshtml  .asp  .aspx  .asmx  .nsp  .nsn  .nss  .nsr  .nsb
.cpy  .copy  .jcl  .cbl  .cob  .cfc  .cfm  .go  .rb  .php
```

PDFs, Word documents, TIFFs, and other binary formats are intentionally
excluded. They demand OCR / text-extraction workflows that are too
expensive to run inside a skill invocation and overlap with
`tiff-corpus-assessor`. Reg docs in PDF should be catalogued in the
application catalog entry's supplementary-doc list.

### 2.2 Skip list

The walker prunes these directories wherever they appear in the tree:

```
.git  node_modules  bin  obj  target  dist  build
.venv  venv  __pycache__
```

### 2.3 Caps

- `--max-files` (default 5000) bounds the total number of files read.
- `_MAX_FILE_BYTES = 2 MB` per file stops runaway reads on generated
  fixtures or minified bundles that slipped past extension filters.

## 3. Confidence tiers

Every emitted citation carries a `confidence` field. The tiering rules:

| Confidence | Condition |
|---|---|
| `high` | The citation appears inside a comment, docstring, or block-comment continuation on the same line, OR the nearest preceding non-blank line (within 5 lines) starts a comment. |
| `medium` | The citation appears in a doc-only file (`.md`, `.txt`, `.rst`). Prose-leaning intent, but no code-adjacent semantics. |
| `low` | The citation is bare text inside a code file (string literal, inline HTML, CSV content, etc.) with no comment context. |

Comment-prefix detection recognises: `//`, `--`, `#`, `*`, `/*`, `'`
(VB/Classic ASP), `rem ` (Batch/BASIC), `!` (NATURAL/Fortran), `;`
(JCL/Lisp), `//*` (JCL), `<!--` (HTML/XML), and the docstring openers
`"""`, `'''`, `/**`, `/*!`, `<summary>`, `<remarks>`.

Tier aside: high-confidence hits flow directly into `cato-compliance`
OSCAL control references. Medium-confidence hits feed documentation
coverage scoring. Low-confidence hits are kept for completeness but most
downstream consumers filter them out with `--min-confidence medium`.

## 4. Normalization

Every match is normalized to a canonical record shape:

```json
{
  "authority": "USC",
  "title": "49",
  "section": "44107",
  "subsection": null,
  "raw": "49 USC §44107",
  "file": "db/sprocs/usp_Conveyance_Record.sql",
  "line": 42,
  "context": "-- Enforces chronological recordation per 49 USC §44107",
  "confidence": "high"
}
```

Rules:

1. `raw` preserves the verbatim substring that matched. **Never** mutate
   `raw` during post-processing — it is the reviewer's reconstruction
   evidence.
2. `title` and `section` are stripped of whitespace and punctuation that
   isn't part of the identifier. Section `49.17` keeps the decimal;
   section `44107a` keeps the trailing letter.
3. `subsection` strips the enclosing parentheses. `(a)` becomes `"a"`,
   `(3)` becomes `"3"`. Multi-level references such as `(a)(3)(ii)`
   keep only the outermost paragraph (`"a"`).
4. `context` is the trimmed source line, clipped to 240 characters with
   a trailing ellipsis if longer.
5. Uniqueness key is the 4-tuple `(authority, title, section, subsection
   or "")`. Two citations to `49 USC §44107(a)` and `49 U.S.C. 44107(a)`
   collapse into one `unique_citations` bucket.

## 5. Cross-reference to other skills

The compliance-citation-mapper is **detection only**. Downstream skills
consume the citation list:

- **`cato-compliance`** — Converts high-confidence citations into
  OSCAL `control-reference` entries for the T2-and-above compliance
  package. It does NOT re-scan source; it reads
  `compliance-citations.json` and the curated `faa-citation-catalog.md`.
- **`safety-critical-verifier`** — For Tier-1 applications, verifies
  that each unique high-confidence citation has a corresponding entry in
  `business-rule-inventory.json` so the modernized output carries the
  regulatory lineage.
- **`traceability-checker`** (gate package) — Asserts that every
  citation's `file` path is reachable from at least one module listed in
  `structural-analysis.json`. Dangling citations (citations in files
  unknown to structural analysis) are surfaced as gate warnings.
- **`disposition-governance`** — When a proposed disposition is Replace
  or Retire, the governance pass checks that every citation in the
  application has a successor system documented or an explicit
  sunset-approval on file.

These consumers are registered in `olympus/olympus/skills/registry.yaml`
under their own phases; no coupling is done at scan time.

## 6. Extending the grammar

To add a new authority (e.g., DoD instructions, NIST SP-800):

1. Add the pattern and a normalizer to `scripts/scan_citations.py`.
2. Add the authority identifier to the `authority` enum in
   `schemas/discovery/compliance-citations.schema.json`.
3. Add a section to this document documenting the new pattern.
4. Document representative citations in
   `references/faa-citation-catalog.md` (or a parallel catalog keyed to
   the client profile).
5. Add test cases in
   `olympus/tests/test_compliance_citation_mapper.py`.

Do **not** introduce a new dependency (regex, click, pyyaml, etc.) —
the script is deliberately stdlib-only so it runs in any profile
bundle without package management.
