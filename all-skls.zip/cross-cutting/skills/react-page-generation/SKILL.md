---
name: react-page-generation
description: >
  Generate React page and component code from UX page specifications with TypeScript,
  hooks, accessibility, and USWDS integration. Use during P4.3 Generate step for
  applications targeting React or Next.js frontend archetype. Triggers on React
  generation, page generation, component generation, frontend code generation,
  USWDS components, or React TypeScript mentions.
agent: sonnet
allowed-tools:
  - Read
  - Write
  - Bash
  - Grep
---

# React Page Generation

## Purpose
Generate modern React code with TypeScript, hooks, and full accessibility compliance
from UX page specifications and component specifications. This skill produces the
complete frontend codebase — pages, components, hooks, state management, routing,
and test stubs — ready for Ralph Loop (tdd-generation) validation.

For FAA profile applications, all generated components use USWDS (U.S. Web Design
System) via `@trussworks/react-uswds`, ensuring Section 508 compliance and visual
consistency across the FAA application portfolio.

This skill is invoked after `code-generation-abstract` has produced the frontend
project scaffold. It replaces TODO stubs with real React/TypeScript implementation
code, following the generation order: shared hooks/utilities -> base components ->
page components -> route configuration -> state management wiring.

## Inputs
- UX page specifications (from `design-system` or UX page specification skill)
- UX component specifications (from component specification skill)
- `code-generation-abstract` output (frontend scaffold, implementation plan, traceability index)
- Target architecture blueprint from Step 2 (must specify React or Next.js)
- Client profile (determines USWDS version, design tokens, accessibility level)
- API contracts (OpenAPI specs from `api-specification` skill — defines data fetching targets)
- Extraction artifact from Step 1 (user journeys, form validations, business rules for client-side logic)

## Outputs
- Component file tree organized by concern:
  - `src/pages/` — page-level components (one per route)
  - `src/components/` — reusable UI components (shared across pages)
  - `src/hooks/` — custom hooks for data fetching, forms, auth, accessibility
  - `src/utils/` — utility functions (formatters, validators, constants)
  - `src/contexts/` — React Context providers for app-level state
  - `src/types/` — shared TypeScript type definitions
- TypeScript source files with JSX (`.tsx` for components, `.ts` for non-JSX)
- CSS Modules (`.module.css`) or styled-components (based on target architecture)
- Route configuration (React Router v6 or Next.js App Router)
- `package.json` with all dependencies and scripts
- Storybook stories for each component (stubs)
- Vitest/Jest test stubs for every component and hook
- README with setup and development instructions

## Methodology

### Step 1: Validate Scaffold and Load Inputs
Read the frontend scaffold from `code-generation-abstract`. Validate that:
1. The scaffold specifies React or Next.js as the frontend framework
2. Project structure exists with `src/pages/`, `src/components/`, `src/hooks/` directories
3. `package.json` includes React, TypeScript, and testing dependencies
4. UX page specifications are available for all routes in the architecture design
5. API contracts (OpenAPI specs) are available for all data-fetching pages

Load the client profile to determine:
- USWDS version and `@trussworks/react-uswds` version
- Design tokens (colors, spacing, typography)
- Accessibility level (WCAG 2.1 AA minimum, AAA where specified)
- Supported browsers and viewport breakpoints

### Step 2: Generate Shared Types and Utilities
Generate foundational code that all components depend on:

**TypeScript type definitions** (`src/types/`):
- API response types generated from OpenAPI specs (one type file per bounded context)
- Shared domain types (enums, union types, branded types for IDs)
- Form field types with validation schemas
- Route parameter types
- Component prop utility types (`PropsWithChildren`, `WithClassName`, etc.)

**Utility functions** (`src/utils/`):
- Date/time formatters matching FAA conventions (UTC, Zulu time for aviation)
- Number formatters (currency, percentages, flight numbers)
- Validation functions mapped to extraction business rules
- API client wrapper (fetch or axios configured with base URL, auth headers, error handling)
- Constants file (API base URLs per environment, route paths, query param keys)

### Step 3: Generate Custom Hooks
Generate reusable hooks before components that consume them:

**Data fetching hooks** (`src/hooks/`):
- `useApi<Resource>` — one per API resource from OpenAPI specs
- Uses `fetch` with React Query (`@tanstack/react-query`) or SWR for caching
- Handles loading, error, and success states
- Pagination support for list endpoints (cursor-based matching API contract)
- Optimistic updates for mutation hooks
- TypeScript generics for request/response types

**Authentication hooks**:
- `useAuth` — current user state from OKTA token (roles, permissions, display name)
- `useRequireAuth` — redirect to login if unauthenticated (wraps route protection)
- `usePermission` — check if current user has a specific permission

**Form hooks**:
- `useFormValidation` — validates form state against extraction business rules
- Uses `react-hook-form` with Zod or Yup schema validation
- Schema definitions generated from extraction validation rules
- Error message mapping from validation rule to user-friendly message
- Dirty state tracking for unsaved changes warnings

**Accessibility hooks**:
- `useFocusTrap` — trap focus within modals and dialogs
- `useAnnounce` — screen reader announcements for dynamic content updates
- `useReducedMotion` — respect user's prefers-reduced-motion setting
- `useKeyboardNavigation` — keyboard shortcut registration and help overlay

### Step 4: Generate Base UI Components
Generate reusable USWDS-wrapped components (AppHeader, DataTable, FormField,
ErrorBoundary, etc.) before the page components that compose them. Enforce a
consistent TypeScript props interface pattern with required accessibility
attributes.

See `references/component-patterns.md` for the full USWDS component catalog,
the canonical props interface pattern, and the per-component requirements.

### Step 5: Generate Page Components
For each page in the UX page specification, generate a route-level page
component with co-located styles, tests, and stories, with loading / error /
empty / success state handling and `react-hook-form` wiring for form pages.

See `references/component-patterns.md` for the page component directory
layout, the internal state handling checklist, and the form-page conventions.

### Step 6: Generate Route Configuration
Wire page components into React Router v6 (for CRA or Vite) or the Next.js
App Router, with protected routes, code splitting, and typed route params.

See `references/routing-and-state.md` for the router-specific configuration
steps and file layouts.

### Step 7: Generate State Management
Wire React Context providers (`AuthContext`, `NotificationContext`,
`ThemeContext`) at the app root, manage URL state for filterable list views,
and use `react-hook-form` for complex form state.

See `references/routing-and-state.md` for the Context, URL-state, and
form-state rules.

### Step 8: Generate Accessibility Infrastructure
Build accessibility into focus management, screen reader support, keyboard
navigation, and color/contrast from the start — not as a bolt-on.

See `references/accessibility-infrastructure.md` for the per-concern
checklists (focus, ARIA, keyboard, contrast).

### Step 9: Generate Test Stubs and Storybook Stories
Produce one `.test.tsx` per component with `jest-axe` accessibility checks
and one `.stories.tsx` per component covering default, loading, error,
empty, and variant states.

See `references/test-and-storybook.md` for the stub structure and state
coverage rules.

## Tech-Stack Dispatch
Before generating, validate the target frontend framework:

| Framework | Router | Styling | State | Build Tool |
|-----------|--------|---------|-------|-----------|
| React 18+ (CRA) | React Router v6 | CSS Modules | React Query + Context | webpack |
| React 18+ (Vite) | React Router v6 | CSS Modules | React Query + Context | Vite |
| Next.js 14+ (App Router) | File-based routing | CSS Modules | React Query + Context | Next.js |
| Next.js 14+ (Pages Router) | File-based routing | CSS Modules | React Query + Context | Next.js |

All configurations use:
- TypeScript 5.x in strict mode
- `@trussworks/react-uswds` for USWDS components (FAA profile)
- `@tanstack/react-query` for server state management
- `react-hook-form` + `zod` for form management and validation
- Vitest or Jest for testing with React Testing Library
- Storybook 7+ for component documentation

## Disposition Context
This skill applies to applications dispositioned as:
- **Refactor**: Legacy web UI (JSF, ASP.NET WebForms, ColdFusion templates) modernized to React
- **Rearchitect**: Legacy UI completely reimagined as modern SPA with React + USWDS

For Refactor dispositions, preserve existing user journey flows (page-for-page mapping
from Discovery Pass 4). For Rearchitect dispositions, optimize user journeys based on
UX research — fewer steps, clearer navigation, streamlined forms.

## Gotchas
- **TypeScript strict mode is non-negotiable**: All generated code must compile
  under `"strict": true` in tsconfig.json. No `any` types, no implicit returns,
  no unchecked index access. Use `unknown` + type guards instead of `any`.
- **USWDS version must match client profile**: The `@trussworks/react-uswds`
  version must match the USWDS version specified in the client profile technology
  configuration. Mismatched versions cause broken styles and missing components.
- **No barrel exports in component directories**: Barrel files (`index.ts` re-exporting
  everything) cause webpack to bundle all components even when only one is imported.
  Import components by direct path.
- **Server state vs. client state**: Data from APIs is server state (managed by
  React Query). UI state (modals open, tabs selected) is client state (managed by
  useState/useReducer). Never put server data in React Context or global state.
- **Accessibility is a build-time requirement**: Run `jest-axe` in every component
  test, not as a separate accessibility testing phase. Catching violations in test
  stubs means the Ralph Loop will flag them immediately.
- **Forms must work without JavaScript**: Progressive enhancement — form submission
  should degrade gracefully. Use native HTML validation attributes (`required`,
  `pattern`, `min`, `max`) alongside JavaScript validation.
- **USWDS grid for layout, not CSS Grid/Flexbox directly**: Use USWDS grid classes
  for page layout to maintain consistency across FAA apps. Custom CSS Grid/Flexbox
  is allowed within components but not for page-level layout.
- **No inline styles**: All styling through CSS Modules or USWDS classes. Inline
  styles bypass the design system and are unmaintainable at scale.

## Quality Rules
- [ ] All code compiles under TypeScript strict mode (`"strict": true`) with zero errors
- [ ] All components have TypeScript props interfaces — no inline types, no `any`, no `as unknown as X`
- [ ] No `any` types anywhere in the codebase — use `unknown` with type guards where type is genuinely unknown
- [ ] Every component has at least one test stub (`.test.tsx`) with a `jest-axe` accessibility check
- [ ] USWDS components match the version specified in the client profile technology configuration
- [ ] All interactive elements are keyboard-accessible (Tab, Enter, Space, Escape, Arrow keys)
- [ ] All interactive elements have `aria-label` or `aria-labelledby` — no unlabeled buttons/inputs/links
- [ ] Section 508 / WCAG 2.1 AA compliance markers present on every page (contrast ratios, focus indicators, alt text)
- [ ] Color is never the sole means of conveying information — icons, patterns, or text labels accompany color
- [ ] Focus management on route changes — focus moves to `<h1>` when navigating between pages
- [ ] Loading, error, and empty states handled for every data-dependent section
- [ ] No barrel exports (`index.ts` re-exports) in component directories
- [ ] All styling uses CSS Modules or USWDS classes — no inline styles
- [ ] Form validation uses `react-hook-form` with Zod schemas derived from extraction business rules
- [ ] API client uses `@tanstack/react-query` for all server state — no API data in React Context
- [ ] Route-based code splitting with `React.lazy` or Next.js dynamic imports for all page components
- [ ] Storybook story stubs exist for every component with default, loading, error, and empty variants
- [ ] Page titles set on every route for screen readers and browser tab identification
- [ ] Skip navigation link is the first focusable element on every page

## Common Failure Modes
| Failure Mode | Symptom | Prevention |
|-------------|---------|------------|
| `any` type creep | TypeScript errors suppressed with `as any`; runtime type errors in production | Enable strict mode; CI blocks on `any`; use `unknown` + type narrowing |
| Missing accessibility | Screen reader users cannot navigate; keyboard users cannot interact; 508 audit fails | Include `jest-axe` in every test stub; require `aria-label` on interactive elements |
| USWDS version mismatch | Components render incorrectly; CSS conflicts; FAA branding inconsistent | Pin `@trussworks/react-uswds` version to client profile; validate on scaffold |
| Server state in Context | Stale data across pages; manual refetch logic; cache inconsistencies | Use React Query for server state; Context only for client state (auth, theme) |
| No loading/error states | White screen during data fetch; unhandled promise rejection; user confusion | Require loading/error/empty handling for every async data dependency |
| Barrel export bundle bloat | Bundle size doubles; initial load time degrades; lazy loading ineffective | Ban `index.ts` re-exports; import by direct file path |
| Focus not managed on navigation | Screen reader users lose context on page change; keyboard users must Tab through entire page | Programmatically move focus to `<h1>` on route change via `useEffect` |
| Inline styles bypass design system | Visual inconsistency across pages; design token changes do not propagate | Lint rule banning inline styles; use CSS Modules or USWDS classes exclusively |
| Form validation mismatch | Client-side validation allows data the API rejects; user submits invalid data | Generate Zod schemas from the same extraction rules that generated API validation |

## Phase 3 — ATLAS ChBA

> **Trace:** Closes P3-R14, P3-R15, P3-R23a, P3-R26..R32, P3-R77. Source: `docs/phase3/phase2-commitments.md` §B.1, §B.3 (USWDS), §D (22-stage J08), §E (12 personas); gap matrix EDIT-4. Pairs with the new `cross-cutting/skills/pilot-certification-dashboard-spec` (NEW skill, P0) which produces the dashboard spec this skill consumes.

### USWDS v3 component coverage (federal default)

The Phase 3 ATLAS prototype renders the Private Pilot Certification UI in USWDS v3 via `@trussworks/react-uswds`. Required component coverage per page archetype:

| Component | Where used | Required for |
|---|---|---|
| **Banner** | Every page header | "An official website of the United States government" — federal-site requirement |
| **Header** (basic + extended) | Application shell | Role-keyed nav surface |
| **Footer** | Every page | Federal links, accessibility statement |
| **Side Nav** | Dashboard inner pages | Sectioned navigation per role |
| **Step Indicator** | Wizards (8710, 8500-8) | J08 stage progress visualization |
| **Alert** (info, warning, error, success) | Validation + status messaging | Required-input prompts (P3-R30) |
| **Summary Box** | Dashboard cards | Currency clocks, completed-steps summary |
| **Button Group** | Form actions | Save Draft / Submit / Cancel patterns |
| **Identifier** | Footer | Agency identifier block |
| **Modal** | Confirmations + dangerous actions | Disposition acknowledgements, withdraw application |
| **Table** (sortable, scrollable) | Inbox views, registry-staff queues | Multi-row case lists |
| **Form patterns** (Memorable date, Address, Name) | Intake wizards | 8710 + 8500-8 + Address-change |
| **Process List** | Onboarding orientation | J08 Stage 1 outcome-driven journey |
| **Tag** | Status pills on case cards | Pending / In-progress / Issued / Deferred |

### Role-based routing (P3-R15, P3-R31)

Phase 3 demoes 5 distinct roles from P2 §E. Generated app shell wires per-role bundle entry points and route guards bound to OIDC claim scopes:

| Role | Bundle entry | Default landing | Route guard claim |
|---|---|---|---|
| **applicant** | `src/roles/applicant/main.tsx` | `/applicant/dashboard` | `roles:applicant` |
| **admin** (Registry-staff) | `src/roles/admin/main.tsx` | `/admin/queue` | `roles:registry-admin` |
| **AME** (Aviation Medical Examiner) | `src/roles/ame/main.tsx` | `/ame/console` | `roles:ame` |
| **DPE** (Designated Pilot Examiner) | `src/roles/dpe/main.tsx` | `/dpe/checkrides` | `roles:dpe` |
| **CFI** (Certified Flight Instructor) | `src/roles/cfi/main.tsx` | `/cfi/endorsements` | `roles:cfi` |

Implementation pattern:

- One React Router v6 `<RoleGuard claim="roles:applicant">` HOC per role.
- JWT claims read from Keycloak (Phase 3 prototype) or Login.gov + FICAM (Phase 2 production target).
- Unauthorized access redirects to `/unauthorized` (USWDS Alert error variant), never silently strips UI.
- `useRole()` hook reads current role from auth context; tested via `tests/roles/test_route_guards.test.tsx`.

### Persona-aware page templates

For each role, generate the following templates as TSX stubs that consume the dashboard spec from `pilot-certification-dashboard-spec`:

- `roles/<role>/Dashboard.tsx` — primary landing
- `roles/<role>/Inbox.tsx` — pending-actions list
- `roles/<role>/Case/[caseId].tsx` — shared case workspace view
- `roles/<role>/Profile.tsx` — identity + contact

Per-role variants differ in:

- Visible widgets (applicant sees currency clocks; AME sees medical-exam queue; DPE sees checkride schedule)
- Action affordances (applicant can submit; AME can sign exam findings; DPE can issue PKI-signed credential)
- Data scope at API layer (S5 case visibility filtered by role; PHI never crosses to non-medical roles per AC-4)

### WCAG 2.1 AA + Section 508 baseline (federal mandate)

All generated code MUST meet WCAG 2.1 AA + Section 508. Beyond the existing accessibility hooks and `jest-axe` test stubs, Phase 3 adds:

- [ ] `@axe-core/playwright` assertions on every E2E spec (handed off to `frontend-parity-test-generator`).
- [ ] USWDS Banner is the first component on every page (508 federal-site requirement).
- [ ] Skip-nav link present and focusable on Tab.
- [ ] Color contrast ≥ 4.5:1 verified against the USWDS v3 token set.
- [ ] All form errors announced via `aria-live="polite"` regions.
- [ ] Focus indicator visible at 3:1 contrast (USWDS default focus ring satisfies).
- [ ] Multi-step wizards announce step changes via screen reader (`aria-current="step"` on active Step Indicator item).

### Eliminate-duplicate-data-entry pattern (P3-R23a)

A demo headline. The generated frontend must enforce single-write, downstream-read for canonical fields:

- Forms read prefilled values from S8 (Registry Canonical) for FTN, name, address, prior certs.
- Forms read prefilled values from S6 (Medical) for medical-cert-status (boolean only — PHI stays in S6).
- A form field may be `defaultValue`-bound to a prefill source ONLY when the field is registered in `prefill-sources.ts` with its source service.
- A new field added to a form without a prefill-source registration fails CI (the new `duplicate-entry-eliminator-verifier` skill, NEW P0, runs the gate).
- The before/after duplicate-entry table is rendered into the 10-page narrative by `phase-commitment-traceback` (NEW skill).

### Evidence-index page (P3-R96)

Generate a top-level `/evidence` route (admin-only) that renders an index of all SF2 deliverables — pipeline runs, OSCAL artifacts, scan reports, runbooks. The page reads from `submission-package-builder`'s evidence manifest and surfaces:

- One row per evidence category (P3-R74..R94)
- Direct links to artifact files
- Last-build hash + timestamp
- Pass/fail badges per category

### Integration with `pilot-certification-dashboard-spec` (NEW skill)

Input contract: this skill consumes the JSON dashboard spec at `assets/dashboards/<role>.json` produced by `cross-cutting/skills/pilot-certification-dashboard-spec`. Each spec lists:

- Widget inventory (currency clocks, status timeline, pending-actions inbox, required-inputs checklist, real-time status banner)
- Data source per widget (`api://s8/...`, `event://activity.event/...`)
- Real-time wiring (SSE / WebSocket / poll-fallback)
- USWDS pattern composition

This skill renders each widget as a TSX component, wires the data source via React Query, and connects real-time updates via the SSE hook.

### Playwright E2E generation hook

Emit a Playwright spec stub per generated page:

- `tests/e2e/<role>/<page>.spec.ts` — covers primary path + at least one error path
- Role-keyed login fixture in `tests/e2e/fixtures/auth.ts`
- Screen-share-friendly viewport (1920×1080) for live oral demo
- Headed-with-narration mode toggle for fallback demo recording

The `frontend-parity-test-generator` (NEW skill) is the downstream consumer of these stubs for the 5 demo journeys D1–D5.

### Phase 3 acceptance signals

- [ ] All 5 roles have a working bundle entry point with route-guarded landing.
- [ ] USWDS v3 Banner, Header, Footer, Identifier render on every page.
- [ ] `prefill-sources.ts` registry exists and is referenced by every form field reading canonical data.
- [ ] `axe` violation count is zero across all pages (Playwright + jest-axe).
- [ ] Evidence-index page renders against a sample manifest.

## Handoff Summary
When this skill completes, verify:
1. TypeScript compiles in strict mode with zero errors (`tsc --noEmit`)
2. All page components render for every route in the architecture design
3. USWDS components render correctly with FAA branding
4. Every component has a test stub with `jest-axe` accessibility assertion
5. Storybook stories exist for every component
6. Route configuration covers all pages with code splitting
7. Custom hooks exist for data fetching, forms, auth, and accessibility
8. Focus management works on route changes (focus moves to `<h1>`)
9. All forms use `react-hook-form` with Zod validation schemas
10. **Phase 3:** Five role bundles built; USWDS v3 coverage matches the table above; prefill registry enforced
Then proceed to: `tdd-generation` (P4.3) for Ralph Loop test-driven validation, `accessibility-checker` for 508 compliance scan, `design-system` for cross-app visual consistency review, and gate `G-04c` for generation quality review
