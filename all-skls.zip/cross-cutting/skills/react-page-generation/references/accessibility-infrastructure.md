# Accessibility Infrastructure (Step 8)

Build accessibility into the application structure, not as a bolt-on.

## Focus management
- Focus moves to page heading (`<h1>`) on route change
- Focus trapped in modals and dialogs (via `useFocusTrap`)
- Focus returned to trigger element when modal closes
- Skip navigation link on every page (first focusable element)

## Screen reader support
- `aria-live="polite"` region for dynamic content updates
- `aria-live="assertive"` for error messages and critical alerts
- Descriptive `aria-label` on all interactive elements
- `role="status"` for loading indicators
- `role="alert"` for error messages

## Keyboard navigation
- All interactive elements reachable via Tab
- Custom keyboard shortcuts documented in help overlay (Shift+?)
- Escape closes modals, dropdowns, and popovers
- Arrow keys for navigation within lists, tables, and menus
- Enter/Space activates buttons and links

## Color and contrast
- All text meets WCAG 2.1 AA contrast ratio (4.5:1 for normal text, 3:1 for large text)
- Information never conveyed by color alone (use icons, patterns, or text labels)
- Focus indicators visible with sufficient contrast (3:1 minimum)
