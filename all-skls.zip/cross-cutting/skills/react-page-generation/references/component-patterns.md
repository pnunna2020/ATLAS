# Base UI and Page Component Patterns (Steps 4-5)

Describes how to generate reusable base components and route-level page
components after shared hooks and utilities are in place.

## Step 4: Generate Base UI Components

Generate reusable components before page components that compose them.

### USWDS-wrapped components (for FAA profile)

Import from `@trussworks/react-uswds` and extend with app-specific props:
- `AppHeader` — USWDS Header with FAA branding, navigation, user menu
- `AppFooter` — USWDS Footer with FAA required links and identifiers
- `AppLayout` — Page layout wrapper (header, navigation, content area, footer)
- `DataTable` — USWDS Table with sorting, pagination, row selection
- `FormField` — USWDS Form components with validation error display
- `AlertBanner` — USWDS Alert with auto-dismiss and screen reader announcement
- `LoadingSpinner` — Accessible loading indicator with aria-live region
- `ErrorBoundary` — Error fallback with retry action and error reporting
- `EmptyState` — Consistent empty state display for zero-data scenarios
- `Breadcrumb` — USWDS Breadcrumb with route-aware auto-generation
- `SkipNav` — Skip navigation link (first focusable element on every page)

### Component props interface pattern

```typescript
interface DataTableProps {
  readonly data: ReadonlyArray<RowData>;
  readonly columns: ReadonlyArray<ColumnDefinition>;
  readonly onSort?: (column: string, direction: SortDirection) => void;
  readonly onPageChange?: (cursor: string) => void;
  readonly isLoading?: boolean;
  readonly emptyMessage?: string;
  readonly "aria-label": string; // Required — no tables without labels
}
```

Every component must have:
- TypeScript props interface (no inline types, no `any`)
- Default props for optional values
- `aria-label` or `aria-labelledby` required prop for interactive elements
- `data-testid` attribute for testing selectors

## Step 5: Generate Page Components

For each page in the UX page specification, generate a page component.

### Page component structure
- File: `src/pages/{PageName}/{PageName}.tsx`
- Co-located files: `{PageName}.module.css`, `{PageName}.test.tsx`, `{PageName}.stories.tsx`
- Page components are route-level: one page per route from the architecture design

### Page component internals
1. **Data fetching**: Call custom hooks from Step 3 at the top of the component
2. **Loading state**: Render `LoadingSpinner` while data is fetching
3. **Error state**: Render `ErrorBoundary` fallback if data fetch fails
4. **Empty state**: Render `EmptyState` if data is empty
5. **Success state**: Render the page content with data
6. **SEO metadata**: Set page title via `document.title` or `<Head>` (Next.js)

### Data-dependent sections
- Each section that depends on API data gets its own loading/error/empty handling
- Use Suspense boundaries where supported (React 18+)
- Skeleton loaders for progressive content display

### Form pages
- Use `react-hook-form` with validation schemas from Step 3 hooks
- Controlled inputs for all form fields
- Client-side validation on blur and submit
- Server-side validation error mapping from API error responses
- Unsaved changes warning on navigation (`beforeunload` + router blocker)
- Accessible form error summary at top of form on submit failure
