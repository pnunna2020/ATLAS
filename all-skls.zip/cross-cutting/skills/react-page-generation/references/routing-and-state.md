# Routing and State Management (Steps 6-7)

Wiring page components into the application routing and managing app-level
state once components exist.

## Step 6: Generate Route Configuration

Wire all page components into the application routing.

### React Router v6 (for Create React App or Vite)
- `src/routes/index.tsx` — route definitions
- Layout routes for shared navigation and footer
- Protected routes using `useRequireAuth` hook
- Route-based code splitting with `React.lazy` and `Suspense`
- 404 catch-all route with helpful navigation links
- Route params typed with TypeScript

### Next.js App Router (for Next.js targets)
- `app/` directory with page.tsx per route
- `layout.tsx` for shared layout components
- `loading.tsx` for route-level loading states
- `error.tsx` for route-level error boundaries
- `not-found.tsx` for 404 pages
- Middleware for authentication checks

## Step 7: Generate State Management

Based on the architecture design's state management requirements.

### React Context (`src/contexts/`)
- `AuthContext` — current user, login/logout actions, token refresh
- `NotificationContext` — toast notifications, alert banners, screen reader announcements
- `ThemeContext` — light/dark mode (if specified), FAA design tokens
- Context providers composed in a root `AppProviders` component

### URL state
- Search params for filterable/sortable list views (preserves state on refresh/sharing)
- URL param hooks for typed access to route params and search params
- Sync URL state with component state bidirectionally

### Form state
- `react-hook-form` for complex forms with multi-step or conditional fields
- Form state persisted to sessionStorage for crash recovery on long forms
- Form state reset on successful submission
