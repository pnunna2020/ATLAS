---
name: temporal-workflow-scaffolder
description: Scaffold Temporal.io workflows + activities with idempotent semantics and retry policies for durable orchestration of long-running multi-step processes (e.g., FAA pilot certification journey).
phase: generate
category: modernization
status: stub-2026-05-27
maturity: minimal
inputs:
  - workflow-design.yaml      # bounded context, steps, signals, queries
  - business-rules.json       # rules to call from activities
  - retry-policies.yaml       # default retries + idempotency keys
outputs:
  - apps/worker/src/workflows/<workflow>.ts
  - apps/worker/src/activities/<workflow>.ts
  - apps/worker/src/task-queues.ts
  - apps/worker/src/index.ts
  - apps/worker/src/db/pool.ts
contract_invariants:
  - "Workflows are deterministic; no Date.now(), Math.random(), I/O — only via activities"
  - "Activities are idempotent — keyed by external request ID or composite business key"
  - "Workflow signals/queries declared in TypeScript types; runtime registration matches types"
  - "Compensation steps defined for any non-idempotent external side-effect"
related_skills:
  - xstate-fsm-generator       # FSM definitions feed into workflow design
  - outbox-pattern-scaffolder  # outbox integration for transactional event emission
  - node-api-generation        # workflow handlers triggered from API
---

# temporal-workflow-scaffolder

## Purpose

Generate the worker-side artifacts for a Temporal.io v1 deployment. Used by the ATLAS Phase 3 prototype to orchestrate the T1–T8 pilot certification journey across multiple bounded contexts (identity, medical, AKTR, endorsement, checkride, application) with at-least-once semantics and human-friendly retry policies.

## When to use

- The target system needs durable, long-running orchestration that survives process restarts.
- Multiple bounded contexts coordinate via signals/queries rather than synchronous calls.
- Human-in-the-loop steps (AME decision, CFI signature, DPE signature) require workflow pause + signal resume.

## Inputs

| Input | Source | Purpose |
|---|---|---|
| `workflow-design.yaml` | `xstate-fsm-generator` output (or hand-authored) | Steps, signals, queries, compensations |
| `business-rules.json` | `business-logic-extractor` output | Rules invoked by activities |
| `retry-policies.yaml` | `decomposition-patterns` output | Per-activity retry + backoff |

## Outputs

```
apps/worker/src/
├── workflows/
│   ├── <workflow>.ts            # workflow definitions (deterministic)
│   └── index.ts                 # workflow registry
├── activities/
│   ├── <workflow>.ts            # activity implementations (I/O side)
│   ├── audit.ts                 # audit-write activity (used by all)
│   ├── workflow-run.ts          # run-record activity
│   └── index.ts                 # activity registry
├── task-queues.ts               # task queue names + worker assignments
├── db/pool.ts                   # shared Postgres pool for activities
└── index.ts                     # worker boot
```

## Contract enforcement

- **Determinism check**: post-generation lint forbids `Date.now()`, `Math.random()`, `setTimeout`, `fetch`, `fs`, `pg`, `axios` inside `workflows/*`.
- **Idempotency key**: each activity must declare its idempotency key in TSDoc; activity-rule lint fails if absent.
- **Type-safe signals**: signal/query types declared in shared interfaces; worker registration validated against types at compile time.

## Phase 3 prototype usage

Used to scaffold:

- `apps/worker/src/workflows/{identity,medical,aktr,endorsement,checkride,application,smoke}.ts`
- `apps/worker/src/activities/{identity,medical,aktr,endorsement,checkride,application,audit,workflow-run}.ts`

## Status

**STUB — 2026-05-27.** Created retroactively to give the existing Phase 3 worker tree a named producer skill. Full implementation (template files, examples, scripts, eval harness) is Phase 4 work.

To upgrade to maturity `built`:

1. Add `references/temporal-v1-determinism-checklist.md`.
2. Add `assets/templates/{workflow,activity,task-queue}.ts.j2`.
3. Add `scripts/scaffold-workflow.sh` driving the templates.
4. Add `eval-harness/evals/skill-evals/temporal-workflow-scaffolder.eval.yaml`.
5. Register in `olympus/olympus/skills/registry.yaml` under `generate.primary`.

## Related work

- ATLAS Phase 3 prototype `apps/worker/` — concrete output of (retroactive) invocation
- Foundry-strategy.md L519 — coverage + zero-finding gate at Generate sign-off
