---
name: per-report-project-antipattern-detector
description: >
  Detect the project-per-report antipattern where each report is
  implemented as its own separate .NET project, inflating solution
  complexity without structural benefit. DIWS is the ATLAS case:
  7 report projects (`MSS.DIWSReports.ApplicantNotesReport`,
  `Diws8500SummaryReport`, `MedicalCertificateReport`, `SodaFormReport`,
  `WorkflowItemHistoryReport`, `Core`, `Data`) where each output is
  one project. Usually the result of team handoffs: each
  contractor/team adds its own project to avoid touching shared
  code. Modernization should consolidate. Runs as Discovery conditional
  when a solution contains > 3 projects named with a `.Report` /
  `.Reports.<Name>` pattern. Triggers on per-report-project audit
  or @per-report-project-antipattern-detector.
agent: sonnet
allowed-tools:
  - Read
  - Write
  - Grep
  - Glob
validation_commands:
  - "python -m olympus.validators.schema_validator report-project-inventory.json"
  - "python -m olympus.validators.schema_validator report-consolidation-recommendation.json"
supported_stacks:
  - csharp
  - vbnet
  - dotnet
  - rdlc
  - reportviewer
anti_target_stacks:
  - ssrs-server-only
  - static-site
failure_classes:
  - legitimate-separate-report-project-misflagged
  - shared-core-project-labeled-as-report
  - one-report-per-team-rationale-ignored
benchmark_tags:
  - discovery-structure
  - antipattern-detection
  - report-consolidation
---

# per-report-project-antipattern-detector

## Purpose
Flag project-per-report patterns; recommend consolidation to a
single reports project hosting N report files.

## Inputs
- Repository with `.sln` files and project names.
- Optional: output of `rdlc-reportviewer-extractor`.

## Outputs
- `report-project-inventory.json` — per report project:
  `{project_name, sln_path, report_file_count, total_code_loc,
  shared_dependencies[]}`.
- `report-consolidation-recommendation.json` —
  `{recommended_consolidated_project_name, projects_to_merge[],
  estimated_migration_effort_hours, risk_factors[]}`.

## Methodology
1. Walk every .sln; list projects matching `*.Reports.*`,
   `*.Report`, `*Reports*`, or projects whose primary content
   is `.rdlc` files.
2. Count projects with ≤ 2 `.rdlc` files as antipattern
   candidates.
3. Identify shared infrastructure (Core / Data / Base) that
   should remain separate.
4. Emit consolidation recommendation listing merge targets.

## Tech-Stack Dispatch

No external references.

## Gotchas
- `*.Reports.Core` and `*.Reports.Data` = shared infrastructure
  (NOT merge candidates).
- Team-handoff history may justify separation; flag but don't
  auto-merge.
- Per-environment variants (`.Reports.Prod`, `.Reports.Test`) are
  a different antipattern (should be config, not projects).

## Quality Rules
- [ ] Every candidate project inventoried.
- [ ] Shared infrastructure excluded from merge list.
- [ ] Consolidation recommendation per group.
- [ ] Every record cites `{repo}:{file}:{line}`.

## Common Failure Modes

| Failure Mode | Symptom | Prevention |
|---|---|---|
| Shared Core merged | Core/Data consolidated into single reports project | Exclude by name suffix |
| Legitimate split ignored | Team-owned reports incorrectly merged | Preserve team-ownership markers |

## Handoff Summary
Per-report-project antipattern inventoried. Proceed to
`rdlc-reportviewer-extractor` for per-report content extraction.

## References
None.

## Changelog
- 0.1.0 (2026-05-07) — Initial skill. Authored as ATLAS-R-19.
