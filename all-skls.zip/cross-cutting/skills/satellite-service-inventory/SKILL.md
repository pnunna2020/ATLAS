---
name: satellite-service-inventory
description: >
  Inventory satellite support applications shipping alongside a primary
  .NET web app — smaller .NET projects deployed separately, often as
  Windows Services or console exes, handling specialized concerns
  (admin tools, messaging, login, CPS-style certification helpers).
  MEDXPRESS is the ATLAS case: `src/support/` contains six satellite
  apps — `AMCS.Net`, `AMEAdmin`, `CPS` (WCF service + client),
  `Login.Net`, `Messaging Service`, `Security`. Without cataloguing,
  modernization plans the web app only and leaves six orphans.
  Runs as Discovery conditional when repo contains `src/support/`
  or multiple sibling solutions outside the main solution. Triggers
  on satellite-service inventory, support-app discovery, or
  @satellite-service-inventory.
agent: sonnet
allowed-tools:
  - Read
  - Write
  - Grep
  - Glob
validation_commands:
  - "python -m olympus.validators.schema_validator satellite-service-inventory.json"
  - "python -m olympus.validators.schema_validator satellite-service-integration-graph.json"
supported_stacks:
  - csharp
  - vbnet
  - dotnet
  - windows-service
  - console-exe
  - wcf
anti_target_stacks:
  - single-service
  - static-site
failure_classes:
  - satellite-treated-as-main-app
  - shared-auth-service-missed
  - messaging-service-deploy-artifact-untracked
  - wcf-service-client-pair-split
benchmark_tags:
  - discovery-structure
  - satellite-service-inventory
  - support-app-portfolio
---

# satellite-service-inventory

## Purpose
Surface every satellite service / support app in a repo and map
integration with the main app so modernization plans all deploy
targets.

## Inputs
- Repository tree with multiple solutions.
- Application catalog entry.

## Outputs
- `satellite-service-inventory.json` — per satellite: `{name, path,
  service_type (windows_service | console_exe | admin_tool |
  wcf_service | messaging | auth), entry_point,
  main_app_relation, deploy_target}`.
- `satellite-service-integration-graph.json` — main-app and
  cross-satellite edges.

## Methodology
1. Enumerate solutions outside the main `src/` primary path;
   `src/support/` is a strong signal.
2. Classify by name heuristic (`*Admin*`, `*Messaging*`, `*.Net*`,
   `*Login*`, `*Security*`).
3. Inspect entry-point code to classify service_type.
4. Map integration (HTTP, WCF, DB shared schema, file drop).
5. Emit graph + inventory.

## Tech-Stack Dispatch

No external references.

## Gotchas
- `AMCS.Net` under MEDXPRESS `src/support/` is MEDXPRESS's
  INTEGRATION TO AMCS, not AMCS itself.
- `CPS` ships two solutions (`Cps.sln` WCF service and
  `Cps.Client.sln` client library) — treat as paired.
- Admin tools (`AMEAdmin`) often have separate auth + deploy.
- Messaging services call SMTP relays — record relay host.
- `Login.Net` shared service is the fanout auth provider for all
  MEDXPRESS support apps.

## Quality Rules
- [ ] Every satellite has an inventory entry.
- [ ] Every integration edge captured.
- [ ] WCF service+client pairs grouped.
- [ ] Every record cites `{repo}:{file}:{line}`.

## Common Failure Modes

| Failure Mode | Symptom | Prevention |
|---|---|---|
| Satellite treated as main app | Modernization plans wrong target | Classify by path + dependency direction |
| WCF service+client split | Client ported without service | Detect paired sln names |
| Shared auth service missed | Each satellite modernized with its own auth | Emit `Login.Net` usage as cross-service finding |

## Handoff Summary
Satellite services inventoried. Proceed to
`portfolio-integration-mapper`.

## References
None.

## Changelog
- 0.1.0 (2026-05-07) — Initial skill. Authored as ATLAS-R-19.
