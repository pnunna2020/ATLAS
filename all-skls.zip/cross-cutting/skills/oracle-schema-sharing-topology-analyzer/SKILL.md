---
name: oracle-schema-sharing-topology-analyzer
description: >
  Build the portfolio-scoped co-tenancy graph for a shared Oracle
  schema — which apps own, read, and co-edit which schema objects.
  Portfolio-level counterpart to the per-app
  `cross-system-migration-script-tracer`. The AAM suite (AMCS,
  MedXPress, CPDSS, CHAPS, DIWS) shares the MSS Oracle schema; 104+
  cross-system migrations touch the shared surface. Without this
  topology, `capability-consolidation-advisor` sees declared
  integrations but not the actual schema co-tenancy, and the
  consolidation-risk estimate is incomplete. Runs as a Rationalization
  supplementary skill; fires when `capability-consolidation-advisor`
  filter matches AND `cross-system-migration-script-tracer` has been
  run for ≥2 apps. Triggers on Oracle schema co-tenancy analysis,
  AAM-suite consolidation sizing, shared-schema portfolio map, or
  @oracle-schema-sharing-topology-analyzer.
agent: sonnet
allowed-tools:
  - Read
  - Write
  - Grep
  - Glob
validation_commands:
  - "python -m olympus.validators.schema_validator oracle-schema-topology.json"
  - "python -m olympus.validators.schema_validator oracle-schema-co-tenancy-findings.json"
  - "python -m olympus.validators.schema_validator oracle-schema-consolidation-sizing.json"
supported_stacks:
  - oracle
  - plsql
  - mss-schema
anti_target_stacks:
  - sqlserver-only
  - postgresql-only
  - schema-per-app
  - static-site
failure_classes:
  - ownership-conflated-with-write-access
  - reader-only-app-tagged-as-owner
  - migration-origin-treated-as-ownership
  - synonym-chain-unresolved
  - cross-schema-fk-dropped
  - dbms-job-dependency-missed
  - package-body-cross-call-ignored
benchmark_tags:
  - rationalization-portfolio
  - oracle-schema-topology
  - aam-suite-consolidation
  - shared-schema-co-tenancy
---

# oracle-schema-sharing-topology-analyzer

## Purpose
Produce a single authoritative topology map for a multi-app Oracle
schema. For every schema object (table, view, package, procedure,
function, trigger, sequence, synonym, materialized view), record
which app owns it, which apps write to it, which apps read from it,
and which cross-system migrations have modified it. This is the
input Capability-Consolidation-Advisor needs to estimate
consolidation risk — specifically whether the AAM suite can collapse
to a single modernized service, or whether cross-ownership forces
per-app retention.

## Inputs
- Per-app `cross-system-migration-script-tracer` outputs
  (`migration-ownership-inventory.json`) for each participating app.
  Minimum 2 apps required.
- Per-app `oracle-extraction-patterns` outputs
  (`oracle-plsql-manifest.json`, `oracle-schema-manifest.json`,
  `oracle-grants-manifest.json`) when available.
- Per-app `plsql-package-extractor` outputs
  (`plsql-package-inventory.json`, `plsql-call-graph.json`) when
  available.
- Application catalog entries with DAL references to schema objects.
- Portfolio integration graph (`integration-graph.json`) from
  `portfolio-integration-mapper`.
- Optional: `mss_all_schemas.dmp` metadata (MEDXPRESS ships the only
  full AAM schema dump in the ATLAS drop).

## Outputs
- `oracle-schema-topology.json` — per schema object: `{schema,
  object_name, object_type (table | view | package | procedure |
  function | trigger | sequence | synonym | materialized_view |
  type | index), owning_app, reader_apps[], writer_apps[],
  co_editor_apps[], dbms_job_dependencies[], cross_package_callers[]}`.
- `oracle-schema-co-tenancy-findings.json` — per object where
  ≥2 apps write or co-edit: `{schema_object, co_tenants[],
  ownership_ambiguity (true/false), migration_origin_mismatch (true/
  false), severity}`. Severity: high if the object is PK-ownership-
  shared; medium if write-shared; low if read-shared.
- `oracle-schema-consolidation-sizing.json` — `{total_objects,
  single_owner_objects, multi_writer_objects, co_edited_objects,
  consolidation_effort_estimate_hours, consolidation_risk_bucket (low |
  medium | high | very_high), narrative}`. Narrative explains which
  apps block clean consolidation and why.

## Methodology
1. **Aggregate per-app migration traces.** Read every
   `migration-ownership-inventory.json`. Each record states an app's
   migrations against specific schema objects. Union by
   `(schema, object_name)`.
2. **Determine owning app per object.** The app whose repo was the
   first to create the object is the owner. If creation is not
   traceable (oldest migration missing from any delivered repo), emit
   `owning_app: unknown` and `ownership_ambiguity: true`.
3. **Classify ownership vs write-access vs read-access per app.** An
   app that appears in migration traces for an object is a writer
   (ran `ALTER`, `CREATE OR REPLACE`, `INSERT`, `UPDATE`, or
   `DELETE` migrations). An app that references the object in its
   DAL or PL/SQL packages but has no migration trace is a reader.
4. **Resolve cross-schema synonym chains.** When an app's DAL
   references `syn_foo` which resolves to `AMCS.FOO`, record the app
   as a reader of `AMCS.FOO`, not `syn_foo`. Synonym resolution is
   one-hop (public and private synonyms).
5. **Extract cross-package callers.** From
   `plsql-call-graph.json`, identify packages that call procedures
   in foreign-schema packages (e.g., `MEDXPRESS.PKG_MX_DIWS_LOOKUPS`
   calling into `DIWS.*`). Record every cross-schema caller as a
   reader of the called object.
6. **Enumerate DBMS_SCHEDULER job dependencies.** From
   `oracle-scheduler-inventory.json`, identify jobs that reference
   the object in `job_action` or chained program steps. Record the
   owning app as a writer via scheduled-job path.
7. **Compute ownership ambiguity per object.** An object with ≥2
   writers AND ambiguous or conflicting migration origins is
   ownership-ambiguous. Flag for human adjudication.
8. **Compute consolidation risk per object.**
   - **Low:** single owner, other apps read-only.
   - **Medium:** single owner, other apps write via migrations.
   - **High:** multiple writers, no single owner (co-editors).
   - **Very high:** multiple writers + DBMS_JOB dependencies +
     cross-package callers + ownership ambiguity.
9. **Aggregate to consolidation sizing.** Count objects per risk
   bucket. Produce an aggregate risk grade for the portfolio.
   Produce an effort-estimate range using configurable rates:
   low-risk ~4 hr/object, medium ~16 hr, high ~40 hr,
   very-high ~80 hr + human review.
10. **Emit narrative.** Human-readable summary naming the apps
    that block clean consolidation, the specific objects driving
    the risk, and the recommended pre-consolidation work (resolve
    ambiguous ownership, break shared-write patterns).

## Tech-Stack Dispatch

| Trigger | Reference loaded |
|---|---|
| ≥2 apps in the portfolio with migration traces | `references/oracle-schema-co-tenancy-patterns.md` |

## Gotchas
- **Ownership ≠ most-recent-writer.** The team whose repo last
  modified an object is not necessarily the owner; owner is defined
  by who first created it.
- **Grants do not establish ownership.** A `GRANT SELECT ON AMCS.FOO
  TO CPDSS_USER` does not mean CPDSS owns FOO; AMCS owns FOO and
  CPDSS has a reader grant.
- **Cross-schema synonyms hide the actual target.** CPDSS
  referencing `syn_am_applicant` that resolves to
  `AMCS.AM_APPLICANT` means CPDSS reads AMCS's table — not a CPDSS
  object.
- **Package bodies can call each other across schemas.** A package
  body `PKG_MX_DIWS_LOOKUPS` living in the MSS / MedXPress schema
  can call `DIWS.SOME_PROC` — record as a cross-schema edge; the
  calling app becomes a reader/writer of the called schema's
  objects.
- **`CREATE OR REPLACE PACKAGE BODY` in a cross-app migration is an
  ownership signal.** If AMCS's repo contains a migration that
  redefines `DIWS.PKG_X`, the AMCS team is a co-editor (and DIWS is
  the owner). The co-editor relationship is itself a finding.
- **DBMS_JOB / DBMS_SCHEDULER jobs are an implicit dependency.**
  A job in schema A that writes to a table in schema B creates
  an implicit co-tenancy edge. Do not omit.
- **Materialized views have two lifecycles.** The MV is in one
  schema; the base tables are in another. Ownership of the MV is
  separate from ownership of its inputs — emit both records.
- **Sequences are not tables.** Sequences (`CREATE SEQUENCE`) are
  owned independently; a table using `seq.NEXTVAL` does not own
  the sequence.
- **Privilege grants drift over time.** Role-based grants can be
  granted and revoked across migrations; the topology at any point
  depends on the latest applied set. Use the latest migration state.
- **ATLAS-specific: `mss_all_schemas.dmp`** (shipped with MEDXPRESS)
  is the canonical portfolio schema snapshot. If available, parse
  its metadata to seed the object inventory; otherwise reconstruct
  from per-app traces only.
- **Typo preservation required.** `DHS_*_EpoweOnly.sql` (AMCS, with
  `Epowe` typo) modifies shared schema objects. Do not normalize
  filenames; preserve the typo for traceability.
- **Empty reader list is not impossible.** A schema object with only
  one owning writer and no readers is legal; it may be an internal
  helper that never leaves the schema.
- **Single-app runs are forbidden.** This skill requires ≥2 apps in
  scope. Emit a no-op artifact if invoked with only one app.

## Quality Rules
- [ ] Every schema object referenced by any participating app has
      a topology entry (no omissions).
- [ ] Every topology entry cites the source migration file or DAL
      reference `{repo}:{file}:{line}` for each owner/writer/reader
      claim.
- [ ] Synonym chains resolved to the terminal object.
- [ ] Cross-schema package-body calls captured as edges.
- [ ] DBMS_JOB / DBMS_SCHEDULER dependencies captured.
- [ ] Ownership-ambiguity findings emitted for every object without
      a determinable first-creator.
- [ ] Consolidation-risk bucket assigned per object.
- [ ] Portfolio-level sizing emits total counts per risk bucket.
- [ ] Narrative names specific apps and specific objects; no hand-
      wavy "AMCS and CPDSS share tables" without citation.

## Common Failure Modes

| Failure Mode | Symptom | Prevention |
|---|---|---|
| Ownership = most-recent-writer | Topology shows AMCS owning DIWS.AM_APPLICANTS_HISTORY because AMCS's latest migration touched it | Use first-creator rule; fall back to `unknown` on ambiguity |
| Reader-only app tagged as writer | CPDSS querying AMCS.FOO via synonym tagged as writer | Resolve synonyms; require migration trace for writer classification |
| Cross-package calls ignored | `PKG_MX_DIWS_LOOKUPS` in MedXPress calling DIWS.PROC not recorded as co-tenancy | Include plsql-call-graph output in input set |
| Synonyms treated as objects | `syn_am_applicant` appears in topology separate from `AMCS.AM_APPLICANT` | Resolve chain; emit only the terminal |
| DBMS_JOB path missed | Nightly job writing to shared table not in topology | Include oracle-scheduler-inventory in input set |
| Single-app invocation produces spurious single-writer output | Topology "valid" but trivial | Guard against <2 apps at the skill entry |

## Handoff Summary
When this skill completes, verify:
1. Every schema object from every participating app is in the
   topology.
2. Ownership designation is grounded in first-creator migration
   evidence; ambiguity flagged explicitly.
3. Synonym and cross-package-call edges are resolved.
4. Consolidation-risk bucket and effort-estimate are populated per
   object and in aggregate.
5. Narrative names specific apps and objects.

Then proceed to: `capability-consolidation-advisor` (Rationalization
supplementary) — which consumes the topology to produce the
consolidation recommendation; `disposition-recommender` — which uses
the co-tenancy findings to constrain per-app dispositions; and, if
consolidation is recommended, `wave-planner` — which sequences the
multi-app migration.

## References
- `references/oracle-schema-co-tenancy-patterns.md` — patterns for
  detecting ownership, cross-app write access, reader-only access,
  synonym chains, cross-schema PL/SQL calls, DBMS_JOB dependencies,
  and materialized-view lifecycles. Includes consolidation-risk
  rubric and effort-estimate heuristics.

## Changelog
- 0.1.0 (2026-05-08) — Initial skill. Authored as FAA-proposal-P1
  (see `docs/testing/faa-proposal-skill-assessment.md` Section 9).
