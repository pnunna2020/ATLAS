# Oracle Schema Co-Tenancy Patterns

Coverage for classifying ownership, write-access, and read-access
across multiple apps sharing a single Oracle schema.

## Ownership Rules

1. **First-creator wins.** The app whose repo contains the oldest
   `CREATE <object>` migration is the owner. Oldest = lowest ticket
   number in the same naming convention OR earliest commit date.
2. **Creation-outside-portfolio.** If no participating app's repo
   contains the `CREATE`, the owner is `unknown` — don't guess.
3. **Reorganization creates ambiguity.** If an object has been
   dropped and recreated, the recreating team becomes the effective
   owner; record both the original and current ownership.

## Writer Classification

An app is a **writer** of an object if any of:

- Its repo contains a `CREATE OR REPLACE` for the object.
- Its repo contains `ALTER TABLE`, `ALTER PROCEDURE`, etc. for the
  object.
- Its PL/SQL packages contain `INSERT`, `UPDATE`, `DELETE`, or
  `MERGE` against the object (DML is write-access).
- Its code contains `EXECUTE IMMEDIATE` with dynamic DDL against
  the object.
- It owns a DBMS_SCHEDULER job whose program writes to the object.

Readers do none of the above but reference the object in SELECT,
synonym resolution, or as an input to a function.

## Synonym Chain Resolution

```
app_1_dal  --references-->  syn_am_applicant  --synonym-->  AMCS.AM_APPLICANT
```

Output: app_1 is a reader of `AMCS.AM_APPLICANT` (not of
`syn_am_applicant`).

Rules:
- Private synonyms (`CREATE SYNONYM foo FOR other.bar`) resolved
  within the owning schema context.
- Public synonyms (`CREATE PUBLIC SYNONYM foo FOR other.bar`)
  resolved globally.
- Synonym chains of depth > 1 (`syn_a -> syn_b -> table_c`) are
  resolved to the terminal.
- Orphaned synonyms (target does not exist in portfolio) emitted
  as findings with `terminal: unknown`.

## Cross-Schema Package Calls

A package body in schema A calling a procedure in schema B creates
an implicit write/read edge depending on the called procedure.

```
MSS.PKG_MX_DIWS_LOOKUPS.FIND_BY_AIRMAN_ID  -->  DIWS.PKG_DIWS.LOOKUP(...)
```

Resolve by:
1. Parsing `plsql-call-graph.json` for schema-qualified calls.
2. Matching caller package to its owning app (via migration origin).
3. Matching callee procedure to its owning schema/app.
4. Emitting: `(caller_app, callee_schema.object)` as a reader edge
   if the called proc only SELECTs; writer edge if it DMLs.

## DBMS_JOB / DBMS_SCHEDULER Dependencies

Jobs create implicit edges:

```
DBMS_SCHEDULER.CREATE_JOB(
    job_name => 'AMCS.NIGHTLY_REFRESH',
    job_action => 'BEGIN AMCS.REFRESH_FROM_MEDX(); END;'
);
```

If `AMCS.REFRESH_FROM_MEDX` reads from `MSS.PKG_MX_AM_QUERIES`, AMCS
(via the scheduled job) is a reader of MedXPress-owned objects.
Traverse `oracle-scheduler-inventory.json` for every job's
program/job_action; resolve the PL/SQL path to reach terminal
objects.

## Grants Create Capability, Not Ownership

```
GRANT SELECT, INSERT, UPDATE ON AMCS.AM_APPLICANT TO CPDSS_USER;
```

This makes `CPDSS_USER` capable of DML against `AMCS.AM_APPLICANT`.
It does NOT make CPDSS an owner. CPDSS becomes a writer only when
its code actually performs DML.

## Materialized Views

```
CREATE MATERIALIZED VIEW DIWS.MV_APPLICANTS_HISTORY
  REFRESH FAST ON DEMAND
  AS SELECT ... FROM AMCS.AM_APPLICANT, MSS.EXAM, DIWS.WORKFLOW_ITEM;
```

Two-tier ownership:
- MV itself: owned by DIWS.
- MV inputs: owned by their respective schemas.

Record both. MV modernization requires coordinating the owner of
each input table.

## Consolidation-Risk Rubric

| Risk | Criteria | Example |
|---|---|---|
| **Low** | Single owner, other apps read-only | AMCS owns `AM_APPLICANT`; CPDSS reads via synonym |
| **Medium** | Single owner, ≥1 app writes via migrations | AMCS owns `AM_APPLICANT`; CPDSS migrations add columns |
| **High** | ≥2 writers, no single owner | DIWS and AMCS both run CREATE OR REPLACE on `DIWS.PKG_WORKFLOW` |
| **Very high** | High + DBMS_JOB deps + cross-package calls + ownership ambiguity | The MSS shared-workflow package cluster |

## Effort Estimate Heuristics

Per-object consolidation effort when modernizing to single-owner
model:

| Bucket | Effort / object |
|---|---|
| Low | 4 hours (grant / synonym cleanup) |
| Medium | 16 hours (break shared-write, route writes through owner API) |
| High | 40 hours (split object, reconcile schemas, add owner service) |
| Very high | 80+ hours (architectural rework, human review required) |

Aggregate portfolio estimate = sum × 1.2 (integration overhead).
Budget includes data-migration audit time; doesn't include ATO
re-certification time.

## Narrative Construction

Template:

```
Of N objects in the shared schema, K are single-owner (low risk),
J are co-edited (high risk), and M are very-high-risk due to
DBMS_JOB / cross-package dependencies.

The following apps block clean consolidation:
- App X writes {objects}... owned by App Y
- Job Z writes {objects}... on behalf of App W

Recommended pre-consolidation work:
- Resolve ownership ambiguity for {N} objects
- Route App X's writes through App Y's owner API
- Remove cross-package calls from {callers} to {callees}
```

Fill with specific object names + app names. No hand-waving.

## Example: AAM Suite

Expected topology (reconstructed from ATLAS-CHALLENGE READMEs):

| Object family | Owner | Writers | Readers |
|---|---|---|---|
| `AM_APPLICANT` and related | AMCS | AMCS, CPDSS (via migrations) | MEDXPRESS, CHAPS, DIWS |
| `PKG_MX_*` packages | MEDXPRESS | MEDXPRESS | AMCS (via call), DIWS (via call) |
| `DIWS.*` workflow tables | DIWS | DIWS, AMCS (via migrations) | CPDSS, MEDXPRESS (via reports) |
| `CP_PENDING` and related | CPDSS | CPDSS, AMCS (via migrations) | DIWS |
| MV `MV_APPLICANTS_HISTORY` | DIWS | DIWS | read-only across all AAM |
| Nightly refresh jobs | varies | varies | N/A |

Risk bucket: **high** for AAM consolidation. Five apps co-tenant
the schema; at least three objects have ≥2 writers; MV inputs span
three schemas; DBMS_SCHEDULER jobs cross ownership boundaries.
