# Test Strategy Templates

This reference supplies the Approach-section content for
`formal-test-plan-generator`. Every test plan is a cross product of
**risk tier** (T1 / T2 / T3) and **disposition** (Retire, Retain,
Refactor, Rearchitect, Replace, Replatform, Consolidate).

The tier template sets the *floor* of what the plan must include. The
disposition template sets the *shape* (parity-heavy, acceptance-heavy,
integration-heavy). Merge them — do not replace. A T2 Refactor is the
T2 tier template PLUS the Refactor overlay; a T1 Replace is the T1
tier template PLUS the Replace overlay.

Copy the matching tier block into the Approach section verbatim, then
apply the matching disposition overlay beneath it, then add any
application-specific notes below.

## Part 1 — Risk Tier Templates

### T1 — Safety-critical / highest risk

T1 applications are safety-critical or carry the highest compliance
obligation. The test plan MUST include every row below.

| Test Type        | Required? | Target / Threshold                         |
|------------------|-----------|--------------------------------------------|
| Unit tests       | Required  | >= 90% line, >= 80% branch coverage        |
| Integration      | Required  | Every cross-component contract verified    |
| Regression       | Required  | Full regression suite — no subset sampling |
| Parity           | Required  | >= 99% match for business-critical outputs |
| Performance      | Required  | p95 latency + throughput within SLO        |
| Security         | Required  | SAST + DAST + dependency scan, zero H/C    |
| Acceptance       | Required  | UAT sign-off from business owner + safety  |
| Chaos / resilience | Required | Fault-injection for every HA component    |
| Compliance       | Required  | Every high-confidence compliance citation has a test item |

T1 plans also require:

- a safety reviewer approver in §14 Approvals
- an explicit `safety-finding-risk` entry in §13 Risks
- an explicit `compliance-citation-gap-risk` entry in §13 Risks
- zero "pass with exception" rows in §7 Pass/Fail Criteria

### T2 — Business-critical / moderate risk

T2 applications are business-critical but not safety-critical. The
bar is regression + smoke + security with optional performance.

| Test Type        | Required? | Target / Threshold                         |
|------------------|-----------|--------------------------------------------|
| Unit tests       | Required  | >= 80% line, >= 70% branch coverage        |
| Integration      | Required  | Every cross-component contract verified    |
| Regression       | Required  | Full regression on high-priority rules; sampling allowed on low-priority |
| Smoke            | Required  | Post-deploy smoke coverage for every entry point |
| Security         | Required  | SAST + dependency scan; DAST if external-facing |
| Performance      | Conditional | Required for user-facing apps; optional for batch |
| Acceptance       | Conditional | Required for user-facing apps            |

T2 plans MAY include "pass with exception" rows in §7 Pass/Fail
Criteria, but every exception must be enumerated and justified.

### T3 — Supporting / lowest risk

T3 applications are internal or non-critical supporting systems. The
bar is smoke testing with regression only on rules marked
high-priority in the business rules catalog.

| Test Type        | Required? | Target / Threshold                         |
|------------------|-----------|--------------------------------------------|
| Unit tests       | Required  | >= 70% line coverage                       |
| Smoke            | Required  | Every entry point hit once post-deploy     |
| Regression       | Conditional | Only for rules flagged `priority: high`  |
| Integration      | Optional  | Recommended when cross-app contracts exist |
| Security         | Required  | Dependency scan only                       |
| Performance      | Not required | -                                       |

T3 plans are lightweight but are still signed. The Approvals section
lists business-owner + validation-lead at minimum.

## Part 2 — Disposition Overlays

### Refactor — parity testing

The modernized application preserves behavior within the same target
stack (e.g. COBOL -> modern COBOL, or Java 8 -> Java 17 same-app).
The validation story is parity: the new implementation must produce
the same outputs for the same inputs.

- Mandatory: parity testing via `parity-verifier` with >= 98% match
  rate (T1: 99%).
- Test data: P3.3 synthetic data used against BOTH legacy and modern
  runtimes; compare normalized outputs.
- Pass/Fail criteria include a parity-match-rate row.
- §9 Test Deliverables cites `parity-report.json` explicitly.
- Features Not to be Tested may include legacy-specific
  implementation details that are irrelevant to behavior.

### Replatform — parity + environment change

Same behavior, different platform (e.g. on-prem -> cloud, mainframe
-> distributed). Parity is still primary but the plan must add an
environment-conformance axis.

- Mandatory: parity testing (same bar as Refactor).
- Mandatory: environment-conformance tests — new-platform-specific
  behavior that didn't exist before (IAM, scaling, observability).
- §10 Environmental Needs enumerates both old and new platform
  prerequisites when dual-running.

### Rearchitect — new architecture, same business outcomes

The application is rewritten on a new architecture. Parity is
measured at the business-outcome level, not the API level.

- Primary: end-to-end acceptance testing against business scenarios
  from the business rules catalog.
- Secondary: parity on business-level outputs (reports, workflow
  completions, notification content) — not wire-level API responses.
- §6 Approach notes that low-level parity is intentionally NOT the
  target; every acceptable-divergence is cited in the acceptance
  scenarios rather than in a parity report.
- Features Not to be Tested includes "legacy API contract" if the new
  API is intentionally different.

### Replace — new implementation, often new capabilities

The legacy application is replaced by a new system (often COTS or
new-build with expanded scope). Acceptance testing dominates.

- Primary: acceptance testing against the business rules catalog,
  organized by business scenario.
- Secondary: data-migration validation — every legacy data element
  lands correctly in the replacement.
- Tertiary: shadow-run or cutover dress-rehearsal tests.
- §9 Test Deliverables cites a `data-migration-report.json` if a
  migration occurred.
- Parity is NOT the primary bar; cite this explicitly in §6 so
  reviewers don't expect a parity-report artifact.

### Consolidate — multiple apps merged into one

Multiple applications fold into a single consolidated system.
Integration testing is the center of gravity: every former-app's
inputs must reach every former-app's outputs inside the consolidated
runtime.

- Primary: integration testing across all merged capabilities.
- Secondary: acceptance testing per source application's business
  scenarios (nothing dropped in the merge).
- Mandatory: a cross-app contract matrix in §3 Test Items listing
  each former-app's surface area and its new consolidated location.
- §4 Features to be Tested groups rules by source application so
  reviewers see per-app coverage even after consolidation.

### Retire — retirement validation

The application is being decommissioned. There is no "test the new
system" axis — the plan instead validates:

- User migration paths are live and verified (for every user role).
- Data retention / archival is complete per compliance schedule.
- Downstream consumers have been notified and cut over.
- Shutdown rehearsal is documented.

Pass/Fail focuses on zero-orphaned-users, zero-data-loss, and clean
reference dropouts. Most IEEE-829 sections still apply (Environmental
Needs still lists the archive destination; Risks still enumerate
"user-migration-incomplete"); the Features lists enumerate the
decommissioning steps rather than code modules.

### Retain — run-as-is validation

The application remains in place unchanged. Validation confirms the
risk classification, compliance posture, and operational health are
still within tolerance.

- Primary: compliance re-certification tests (cato, FISMA, etc.).
- Secondary: operational-health baseline capture (latency, error
  rate, uptime).
- No functional regression is required unless the retention is
  conditional on a specific fix.
- The plan is short — typically 3-4 pages — but every IEEE-829
  section still appears.

## Part 3 — Tier × Disposition Matrix (quick reference)

| Tier \ Disposition | Refactor | Replatform | Rearchitect | Replace | Consolidate | Retire | Retain |
|---|---|---|---|---|---|---|---|
| T1 | Full + parity | Full + parity + env | Full + E2E accept | Full + accept + data-mig | Full + integration | Migration + archive | Compliance + ops |
| T2 | Regression + parity | Regression + parity + env | Regression + accept | Regression + accept | Regression + integration | Migration + archive | Compliance + ops |
| T3 | Smoke + parity (high-priority rules) | Smoke + parity + env | Smoke + accept | Smoke + accept | Smoke + integration | Migration + archive | Compliance only |

"Full" = every row in Part 1's T1 table. "Regression" = regression +
smoke from Part 1's T2 table. "Smoke" = smoke-only from Part 1's T3
table.

## Authoring checklist

Before writing the Approach section:

- [ ] Confirm the application's risk tier from the catalog entry.
- [ ] Confirm the disposition from the disposition-recommendation artifact.
- [ ] Copy the Part 1 tier block verbatim as the baseline.
- [ ] Apply the Part 2 disposition overlay beneath it.
- [ ] Add application-specific notes underneath (test data strategy,
      automation framework versions, special integrations).
- [ ] Cross-reference every row against §4 Features to be Tested so
      every test type has at least one business rule linked to it.
