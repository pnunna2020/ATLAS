# IEEE-829 / ISO 29119 Test Plan Structure

This reference defines the canonical section-by-section layout for the
`test-plan.md` artifact emitted by `formal-test-plan-generator`. The
sections are drawn from IEEE Std 829-2008 (Standard for Software and
System Test Documentation) and aligned with ISO/IEC/IEEE 29119-3:2021
Part 3 (Test documentation).

All fourteen sections are required. Sections with no applicable content
for a given application still appear in the output with a one-line
"not applicable" explanation — silent omission is an audit finding.

Emit each section at level-2 heading (`## Section Name`) so downstream
tooling (`traceability-checker`, `gate-review-package`) can parse the
document by section.

## 1. Test Plan Identifier

A unique identifier for the plan. Use the application id from the
catalog entry plus the plan revision:

```
TP-<application-id>-<revision>
```

Example: `TP-atlas-drs-r1` for the first revision of the DRS test plan.
Increment the revision every time the plan is re-emitted with material
changes. A minor revision (e.g. `r1.1`) is fine for small scope
adjustments; bump the major number on disposition change or tier
change.

## 2. Introduction

One paragraph that names the application, its disposition, its risk
tier, and the modernization wave the plan belongs to. Include a
citation to:

- the application catalog entry (`application-catalog-entry.json`)
- the disposition recommendation (`disposition-recommendation.json`)
- the architecture blueprint (`architecture-blueprint.json`)
- the business rules catalog (`business-rules-catalog.json`)

The Introduction is the first thing a reviewer reads — resist the
temptation to inline test strategy here. That belongs in §6 Approach.

## 3. Test Items

Enumerate the components and artifacts under test. Every target
component listed in the architecture blueprint's component inventory
appears here as a bullet:

```
- <component-name> (<component-type>) — implements rule(s) [rule-id, rule-id, ...]
```

Include version / build identifiers when available. Do NOT list
environmental dependencies here (databases, queues) — those go in §10
Environmental Needs.

## 4. Features to be Tested

Every business rule that is in scope for validation. Emit one bullet
per rule:

```
- [<rule-id>] <one-line rule summary> — verified by <test-strategy-category>
```

`test-strategy-category` is one of: unit, integration, regression,
parity, acceptance, performance, security, smoke. The category must
be consistent with the Approach section's strategy for this tier +
disposition tuple.

Every bullet carries a rule ID anchor — this is the traceability link
`traceability-checker` walks.

## 5. Features Not to be Tested

Every business rule that is NOT being tested in this plan, each with a
one-line reason. Valid reasons:

- `out-of-scope` — the rule belongs to a different application or wave
- `deferred` — will be tested in a later wave with explicit citation
- `covered-elsewhere` — another plan already covers the rule (cite that plan)
- `retired` — the rule was intentionally removed during modernization

```
- [<rule-id>] <one-line summary> — <reason>: <justification>
```

A rule with no reason is a silent exclusion and a gate-level failure.
The union of §4 and §5 MUST cover the entire business rules catalog.

## 6. Approach

The testing strategy. This section receives the strategy template
block from `references/test-strategy-templates.md` matching the
application's `(risk_tier, disposition)` tuple. Quote the template
block verbatim and then add application-specific notes underneath.

Include at minimum:

- the test types being executed (regression, parity, acceptance, etc.)
- the test automation framework(s) in use (pytest, xUnit, jest, etc.)
- the test data strategy (P3.3 synthetic data, production masked data)
- the parity baseline (for Refactor / Replatform dispositions)

## 7. Pass/Fail Criteria

The quantitative bar for declaring a test item or the entire plan
passed. Include:

- line coverage threshold (`>= 80%` for G-04c; `>= 90%` for T1)
- branch coverage threshold (`>= 70%` baseline; `>= 80%` for T1)
- parity match rate (`>= 98%` for business-critical outputs)
- performance SLOs (latency p95, throughput) with targets
- security scan bar (zero critical, zero high for T1/T2)
- acceptance criteria sign-off count per stakeholder role

For T1 applications, every threshold is a hard pass/fail. For T2, the
Pass/Fail Criteria may include a "pass with exception" row — exceptions
must be enumerated here, not tacked on during execution.

## 8. Suspension and Resumption Criteria

The conditions under which testing stops (suspension) and the
conditions for resuming. Typical suspension triggers:

- test environment unavailable > 4 business hours
- blocking defect in an upstream component
- test data corruption
- security incident affecting test systems

Resumption criteria specify what has to be true to restart: env health
green, blocker resolved and re-verified, data reseeded, incident
closed. If the application has no scheduled downtime during
validation, the section still exists:

```
Not applicable — continuous validation window; no scheduled downtime
planned.
```

## 9. Test Deliverables

Artifacts the validation phase produces. Cite the downstream skills
that emit each artifact:

- `test-plan.md` — this document (formal-test-plan-generator)
- `coverage-report.json` — test-validation
- `parity-report.json` — parity-verifier (Refactor / Replatform only)
- `adversarial-review-findings.md` — adversarial-review
- `gate-review-package.zip` — gate-review-package
- `traceability-matrix.json` — traceability-checker

Do not fabricate artifact names — every entry must cite a skill that
actually produces it.

## 10. Environmental Needs

Every infrastructure dependency needed to execute the plan. Pulled
from the architecture blueprint's dependency list:

- databases (engine, version, size, data volume)
- message queues / event buses
- identity / auth providers (stub or live)
- third-party APIs (stubbed, mocked, or live with credentials)
- test data sources (synthetic P3.3 output, masked prod snapshot)
- network topology (VPC peering, firewall rules)
- compute (CI runner sizing, load-test harness)

Every prerequisite listed in the blueprint MUST appear here. An
environment item missing from this section is the single most common
cause of test-schedule slip.

## 11. Responsibilities

The roles (not individuals) accountable for each phase of validation:

- test plan authoring — validation lead
- test execution — test engineer
- test data provisioning — data engineer
- environment readiness — platform engineer
- defect triage — technical lead
- sign-off — business owner, security, (T1: safety reviewer)

Names go in the disposition-governance record, not here. This section
states WHAT roles are needed; the governance record binds specific
people to those roles.

## 12. Schedule

A milestone-level schedule tied to the wave plan. Use the wave
start/end dates from the wave plan artifact and subdivide into:

- Plan approved — T-date
- Test environment ready — T + <days>
- Test data seeded — T + <days>
- Regression complete — T + <days>
- Parity report signed — T + <days>
- Security scan clean — T + <days>
- Stakeholder sign-off — T + <days>
- Plan closed — T + <days>

Cite the wave plan artifact (`wave-plan.json`) so downstream reviewers
can reconcile dates with wave commitments. Do NOT fabricate hour-level
estimates; milestone-day granularity is sufficient.

## 13. Risks

Schedule, scope, and quality risks that could derail validation. At
minimum, address:

- `environment-availability` — will the test environment be ready on time?
- `test-data-readiness` — will P3.3 synthetic data arrive before T-0?
- `dependency-blocker` — any upstream component still in generation?
- `skill-availability` — validation engineer capacity?
- `regression-surprise` — unknown-unknowns in the legacy baseline?

For each risk, include: likelihood (low/medium/high), impact
(low/medium/high), and mitigation. T1 plans MUST address safety and
compliance risks explicitly — include a `safety-finding-risk` and
`compliance-citation-gap-risk` row minimum.

## 14. Approvals

The approver roles required to sign the plan before validation
begins. Driven by risk tier:

- T1: business-owner + security + safety-reviewer + validation-lead
- T2: business-owner + security + validation-lead
- T3: business-owner + validation-lead

Emit one bullet per approver role with placeholders for date and
citation to the disposition-governance record. This section is a
schema — actual sign-offs are captured by `disposition-governance`
and cross-referenced here, never written in place.

## Section ordering and heading format

All fourteen sections MUST appear in the order listed above. Use
level-2 markdown headings (`## Section Name`). Inside each section,
use level-3 (`###`) for subsections. Tables are acceptable (and
preferred) for Risks, Pass/Fail Criteria, and Approvals.
