---
name: formal-test-plan-generator
description: >
  Produce a reviewer-ready formal test plan (test-plan.md) for a modernized
  application by synthesizing extracted business rules, the target
  architecture blueprint, and the application's risk tier into the IEEE-829
  / ISO 29119 canonical structure. Use during Validation when auditors,
  safety reviewers, or a T1 gate reviewer need a signed, traceable test
  plan document — not just the machine-readable test results produced by
  `test-validation` and `parity-verifier`. Triggers on formal test plan,
  IEEE 829, ISO 29119, test plan document, reviewer-ready test plan,
  T1 validation packet, or @formal-test-plan-generator mentions.
agent: sonnet
allowed-tools:
  - Read
  - Write
  - Grep
validation_commands:
  - "python scripts/validate_skills.py"
  - "python -c \"import pathlib, re; body = pathlib.Path('cross-cutting/skills/formal-test-plan-generator/SKILL.md').read_text(encoding='utf-8'); assert 'ieee-829-structure.md' in body and 'test-strategy-templates.md' in body\""
supported_stacks:
  - cobol
  - natural
  - adabas
  - csharp
  - dotnet
  - vbnet
  - webforms
  - classic-asp
  - java
  - spring-boot
  - coldfusion
  - python
  - fastapi
  - typescript
  - javascript
  - oracle-plsql
  - tsql
anti_target_stacks:
  - static-site
  - single-page-app-no-backend
failure_classes:
  - untraceable-test-case
  - risk-tier-strategy-mismatch
  - missing-suspension-criteria
  - silent-feature-exclusion
  - schedule-risk-omission
benchmark_tags:
  - validation-formal-plan
  - ieee-829-conformance
  - risk-tier-strategy
---

# formal-test-plan-generator

## Purpose
The machine-readable outputs from `test-validation` (coverage report) and
`parity-verifier` (behavioral parity report) are sufficient for CI but
insufficient for human auditors, safety reviewers, and T1 validation
gates. Those reviewers expect a **formal test plan document** —
IEEE-829 / ISO 29119 shaped, signable, and traceable from each test
item back to the business rule it exercises. This skill produces that
document.

Inputs are the artifacts already sitting on disk at the start of
Validation: the extracted business rules catalog, the target
architecture blueprint, the application catalog entry (for the risk
tier), and the selected disposition. Output is a single
`test-plan.md` that mirrors the fourteen canonical IEEE-829 sections
and selects the right test strategy template for the risk tier and
disposition.

This skill is *authoring only* — it does not execute tests or gate
approvals. `test-validation` produces the results that get cited from
the Schedule and Test Deliverables sections; `safety-critical-verifier`
reads the emitted plan when the risk tier is T1.

## When to invoke
- Validation step V-01 for every Tier 1 or Tier 2 application — a
  formal plan is mandatory before the G-V1 functional validation gate.
- Tier 3 applications: produce the smoke-test-only plan so Deployment
  reviewers have a signed document in the package, even when the
  content is lightweight.
- Before the G-V1 gate package is assembled by `gate-review-package`,
  so the traceability-checker can link every test item back to a
  business rule.
- Whenever a disposition changes (e.g. Refactor -> Rearchitect) and the
  test strategy must be re-scoped — re-run with the updated
  disposition input so the Approach section picks up the new template.

## Inputs
- `business-rules-catalog.json` — extracted rule inventory per
  `schemas/modernization/business-rule-inventory.schema.json`. Every
  entry carries a stable rule ID used as the anchor for each entry in
  the `Features to be Tested` and `Test Items` sections.
- `architecture-blueprint.json` — target architecture per
  `schemas/architecture/architecture-blueprint.schema.json`. Supplies
  the component list the Test Items section enumerates, and the
  environmental-needs prerequisites (databases, queues, identity
  providers) the Environmental Needs section declares.
- `risk_tier` — the application's risk tier (`T1` | `T2` | `T3`). Read
  from the application catalog entry or supplied directly by the
  orchestrator. Drives which strategy template is selected from
  `references/test-strategy-templates.md`.
- `disposition` — the selected disposition (`Retire`, `Retain`,
  `Refactor`, `Rearchitect`, `Replace`, `Replatform`, `Consolidate`).
  Drives disposition-specific overlays on the strategy template
  (parity testing for Refactor, acceptance testing for Replace,
  integration testing for Consolidate).
- `references/ieee-829-structure.md` — the section-by-section template
  for the output document.
- `references/test-strategy-templates.md` — the risk-tier and
  disposition-specific strategy overlays.

## Process
The skill runs in five short passes.

### Pass 1 — Load inputs and resolve strategy
Read `business-rules-catalog.json`, `architecture-blueprint.json`, and
the risk tier + disposition. Open `references/test-strategy-templates.md`
and select the strategy tuple matching `(risk_tier, disposition)`. If
either input is missing, stop and emit a blocking note — do not guess
the strategy.

### Pass 2 — Build Test Items and Features lists
For every business rule in the catalog, decide whether it is a feature
to be tested or a feature intentionally excluded. Exclusions must cite
the reason (out-of-scope, deferred to next wave, covered by another
application) — a silent exclusion is a schema-level failure. Cross-
reference each test item against the architecture blueprint so every
target component has at least one test item scoped to it.

### Pass 3 — Populate the fourteen IEEE-829 sections
Walk `references/ieee-829-structure.md` top to bottom and fill each
section. The sections are: Test Plan Identifier, Introduction, Test
Items, Features to be Tested, Features Not to be Tested, Approach,
Pass/Fail Criteria, Suspension and Resumption Criteria, Test
Deliverables, Environmental Needs, Responsibilities, Schedule, Risks,
and Approvals. Every section MUST be present. Sections with no content
for this application still include a one-line explanation ("No
suspension criteria — the application has no scheduled downtime
windows during validation.").

### Pass 4 — Apply risk-tier and disposition overlays
Copy the matching strategy template from
`references/test-strategy-templates.md` into the Approach section.
Apply the disposition overlay (Refactor -> parity testing, Replace ->
acceptance testing, Consolidate -> integration testing, others ->
baseline regression). Merge the overlay with the tier template — do
not replace. T1 + Replace still runs full regression AND performance
AND security AND acceptance.

### Pass 5 — Link traceability and write output
Every entry in `Test Items` and `Features to be Tested` MUST cite the
source business rule ID from `business-rules-catalog.json` in the
form `[rule-id]` — this is what `traceability-checker` reads to
verify coverage. Emit `test-plan.md` as a single markdown file with
the IEEE-829 section headers at level-2 (`## Test Plan Identifier`,
etc.) so downstream tooling can parse sections by heading.

## Outputs
- `test-plan.md` — formal test plan in IEEE-829 / ISO 29119 shape.
  Required level-2 sections in order: Test Plan Identifier,
  Introduction, Test Items, Features to be Tested, Features Not to
  be Tested, Approach, Pass/Fail Criteria, Suspension and Resumption
  Criteria, Test Deliverables, Environmental Needs, Responsibilities,
  Schedule, Risks, Approvals.

## Gotchas
- **The plan is authored, not executed.** This skill does not run
  tests. `test-validation` runs tests. Do not inflate the Schedule
  section with results that do not yet exist; cite `test-validation`
  and `parity-verifier` as the source of eventual results.
- **Every test item must cite a rule ID.** A test item with no
  traceability anchor is indistinguishable from a fabrication.
  `traceability-checker` will reject a plan whose items do not link
  back to the business rule catalog.
- **Features Not to be Tested is not optional.** Silent exclusion is
  the single most common audit finding. Every excluded rule needs a
  one-line reason: out-of-scope, deferred, or covered-elsewhere.
- **Risk tier is not the only axis.** Disposition overlays modify the
  strategy. A T2 Refactor is parity-testing-heavy; a T2 Replace is
  acceptance-testing-heavy; a T2 Consolidate is integration-testing-
  heavy. Pick the right overlay before writing Approach.
- **T3 is not "no plan."** T3 applications still get a signed plan,
  even if it is a smoke-test-only plan. Deployment reviewers expect
  a document in the package regardless of tier.
- **Suspension and Resumption Criteria is often empty-but-present.**
  For apps with no scheduled downtime, the section still exists with
  a one-line "not applicable" explanation — do not omit the section.
- **The Approvals list is a schema, not a signature.** This skill
  emits the approver roles and slots. Actual sign-offs are collected
  by `disposition-governance` and cited here by reference, not by
  signature capture.

## Quality Rules
- [ ] All fourteen IEEE-829 sections are present at level-2 headings
      in the emitted `test-plan.md`.
- [ ] Every entry in `Test Items` and `Features to be Tested` cites
      at least one business rule ID from the input catalog.
- [ ] `Features Not to be Tested` lists every excluded rule with a
      one-line reason — no silent drops.
- [ ] The Approach section cites the matching template block from
      `references/test-strategy-templates.md` for the (risk_tier,
      disposition) tuple.
- [ ] T1 plans include regression + performance + security strategy
      lines; T2 plans include regression + smoke; T3 plans include
      smoke only.
- [ ] Disposition overlays are applied on top of the tier template,
      not in place of it. Refactor plans include parity testing;
      Replace plans include acceptance testing; Consolidate plans
      include integration testing.
- [ ] Every target component in the architecture blueprint has at
      least one test item scoped to it in the Test Items section.
- [ ] Environmental Needs enumerates every prerequisite
      (database, queue, identity provider) named in the architecture
      blueprint's dependency list.
- [ ] Schedule and Responsibilities sections cite role names, not
      specific individuals — the governance record owns name binding.
- [ ] The Approvals section lists the approver roles required by the
      risk tier (T1: business-owner + security + safety reviewer;
      T2: business-owner + security; T3: business-owner).

## Common Failure Modes
| Failure Mode | Symptom | Prevention |
|---|---|---|
| untraceable-test-case | Test items in the plan do not link back to the business rule catalog; traceability-checker fails | Every item in Pass 5 must carry `[rule-id]` anchors; drop any item without an anchor or mark it as a new rule requiring catalog addition. |
| risk-tier-strategy-mismatch | A T1 plan reads like a T3 plan — smoke only, no regression or security block | Pass 4 must consult `references/test-strategy-templates.md` — never author Approach from memory. |
| missing-suspension-criteria | Gate reviewers reject the plan because §Suspension and Resumption Criteria is absent | The IEEE-829 walk in Pass 3 is exhaustive; empty-but-present sections include a one-line explanation. |
| silent-feature-exclusion | A business rule is absent from both Features to be Tested and Features Not to be Tested | Pass 2 partitions every rule into one of the two lists; the union covers the full catalog. |
| schedule-risk-omission | Risks section lacks the schedule-slip risks that downstream planning relied on | Always include at least environment-availability, test-data-readiness, and dependency-blocker risks unless an explicit rationale says they do not apply. |

## Handoff Summary
When this skill completes, verify:
1. `test-plan.md` exists in the application's validation artifact
   directory.
2. All fourteen IEEE-829 sections are present at level-2 headings.
3. Every `Test Items` / `Features to be Tested` entry carries a
   business-rule ID anchor.
4. The Approach section matches the `(risk_tier, disposition)` tuple
   and cites the strategy template block by name.

Then proceed to:
- `test-validation` — runs the tests and produces the coverage
  report cited in §Test Deliverables.
- `parity-verifier` — produces the parity report cited in
  §Pass/Fail Criteria for Refactor / Replatform dispositions.
- `safety-critical-verifier` (T1 only) — consumes the emitted plan
  and checks every high-confidence compliance citation has a
  corresponding test item.
- `traceability-checker` (gate package) — verifies every test item
  links back to a business rule and every business rule is covered
  by at least one test item.

## Reference Files
- `references/ieee-829-structure.md` — canonical section-by-section
  template covering all fourteen IEEE-829 / ISO 29119 sections with
  authoring guidance for each.
- `references/test-strategy-templates.md` — strategy overlays per
  risk tier (T1 full regression + performance + security; T2
  regression + smoke; T3 smoke only) and per disposition
  (Refactor -> parity testing; Replace -> acceptance testing;
  Consolidate -> integration testing).
