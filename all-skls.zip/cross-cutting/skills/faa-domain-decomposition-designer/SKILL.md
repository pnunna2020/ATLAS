---
name: faa-domain-decomposition-designer
description: >
  Produce a domain-driven decomposition of the FAA 8-app portfolio into ten
  bounded contexts (Airman Identity, Aircraft Registry, Certificate Issuance,
  Medical Certification, Drug Surveillance, Designee Management, Document
  Imaging, Regulatory Letter Generation, Knowledge Testing, Airman Application
  Workflow). Per bounded context, identifies the authoritative system of
  record, participating apps, canonical entities, API surface, published and
  consumed domain events, recommended target service type
  (microservice / modular-monolith / serverless), and the legacy capabilities
  it absorbs. Emits domain-decomposition.json and a Mermaid context-map
  diagram showing partnership, customer-supplier, conformist, anti-corruption,
  and separate-ways relationships. Triggers on domain decomposition, bounded
  context design, DDD decomposition, FAA portfolio domain model, or
  @faa-domain-decomposition-designer.
agent: sonnet
allowed-tools:
  - Read
  - Write
  - Grep
  - Bash
validation_commands:
  - "python -m olympus.validators.schema_validator domain-decomposition.json"
  - "python -m olympus.validators.bounded_context_sor_uniqueness_validator domain-decomposition.json"
  - "python -m olympus.validators.canonical_entity_ownership_validator domain-decomposition.json"
supported_stacks:
  - faa
  - aviation
  - dotnet
  - java
  - cobol
  - natural
  - mainframe
  - oracle
  - sqlserver
  - adabas
anti_target_stacks:
  - non-aviation
  - generic-saas
failure_classes:
  - context-boundary-leak
  - sor-ambiguity
  - god-service-anti-pattern
  - canonical-entity-ownership-drift
  - missing-anti-corruption-layer
  - one-capability-per-microservice
benchmark_tags:
  - architecture-domain-decomposition
  - ddd-bounded-contexts
  - context-map-accuracy
  - sor-designation
---

# faa-domain-decomposition-designer

## Purpose
Produce the domain-driven decomposition that anchors every downstream
architecture artifact for the FAA 8-app portfolio. Domain-Driven Design gives
Sub-factor 3 of the SOO evaluation the vocabulary evaluators expect:
bounded contexts, authoritative systems of record, ubiquitous language per
context, and context-map relationships. Without this decomposition, the
target architecture degenerates into a legacy-module-mirror — one
microservice per legacy screen, and one authoritative source per app
(including the apps that already duplicate the same canonical entity five
times over). This skill forces ten business-centered bounded contexts over
the portfolio, locks the system-of-record choice per context with evidence,
and emits the context-map relationships downstream skills need to choose
integration style (sync REST vs async event vs batch) and to place
anti-corruption layers where legacy ubiquitous language would otherwise
bleed into the target model.

## Inputs
- Application catalog entries for all eight FAA apps (IACRA, RMS, AMCS,
  MedXPress, CHAPS, CPDSS, DIWS, DMS) per
  `schemas/discovery/application-catalog-entry.schema.json`.
- Discovery Pass 2 business-logic artifacts per app —
  `business-rule-inventory.json` and `business-logic.json` — which already
  cluster rules by capability and name the modules that implement them.
- Portfolio integration mapper output —
  `portfolio-integration-mapper.json` — which shows the legacy cross-app
  integration edges (RMS CAIS feeds IACRA, MSS shared Oracle schema reads,
  DMS designee lookups).
- Rationalization dispositions — `disposition-recommendation.json` per app —
  which drives whether a context is consolidated, rearchitected, or left
  in a legacy carrier through the transition.
- Bounded-context catalog reference —
  `references/faa-bounded-context-catalog.md` — the authoritative list of
  the ten contexts with their SoR designation, participants, ubiquitous
  language, and canonical entities.
- FAA regulation scope (14 CFR Part 61/63/65, Part 67, Part 183,
  49 USC §44107) — not read programmatically, but informs which contexts
  must preserve legal-record semantics.

## Outputs
- `domain-decomposition.json` per portfolio. Required shape:
  - `portfolio_id` — `faa-8-app-portfolio`.
  - `bounded_contexts[]` — one row per context:
    - `name` — from the fixed ten (see reference file).
    - `definition` — one paragraph defining the business outcome the
      context owns.
    - `ubiquitous_language[]` — structured terms with legacy-alias and
      target-term pairs (e.g., legacy `airman file` → target
      `Airman aggregate`).
    - `sor_app_id` — the single authoritative system-of-record application.
    - `participant_app_ids[]` — applications that read or write the
      context's data without owning it.
    - `canonical_entities[]` — named entities this context owns, with the
      lifecycle state machine in prose.
    - `api_surface[]` — candidate endpoints exposed by the target service:
      verb + resource + purpose.
    - `events_published[]` — domain events the context emits when its
      aggregates change state.
    - `events_consumed[]` — domain events the context subscribes to.
    - `target_service_type` — `microservice` | `modular-monolith` |
      `serverless`. Explain why in a one-sentence rationale.
    - `migration_source_capabilities[]` — references into
      `business-logic.json` capabilities per legacy app that will be
      absorbed.
  - `context_map_relationships[]` — one row per edge between two
    contexts: `upstream`, `downstream`, `pattern` (`partnership` |
    `customer-supplier` | `conformist` | `anti-corruption-layer` |
    `separate-ways` | `shared-kernel`), `rationale`.
- `context-map.mmd` — Mermaid diagram (class-diagram or
  flowchart-subgraph form) visualizing the ten contexts and their
  relationships with the pattern labels on each edge.

## Methodology
1. Read all eight catalog entries. Pin the canonical set of portfolio apps:
   IACRA (AFS-760 airman cert), RMS (airman CAIS + aircraft-registry
   dual-SoR), AMCS + MedXPress + CHAPS + CPDSS + DIWS (the AAM five-app
   Medical Support System suite on the shared Oracle schema), DMS (designee
   management).
2. Read `business-logic.json` per app and extract the capability list.
   Capabilities roll up legacy code to business outcomes; they are the raw
   material for context assignment. Do not invent new capabilities in this
   skill; work strictly from the Discovery Pass 2 output.
3. Assign each capability to exactly one of the ten bounded contexts per
   `references/faa-bounded-context-catalog.md`. A capability that spans
   two contexts must be split into two capabilities with a clear boundary,
   or it is a sign that the contexts need re-evaluation (rare — the ten
   contexts have been chosen to match FAA's domain taxonomy with one
   context per business outcome).
4. Designate the authoritative System of Record per context. Use these
   defaults unless the catalog entries give stronger evidence:
   - Airman Identity → RMS (CAIS NATURAL/ADABAS)
   - Aircraft Registry → RMS (aircraft-side Windows SQL Server)
   - Certificate Issuance → IACRA (Temporary Airman Certificates); permanent
     cert records flow back to RMS Airman Identity
   - Medical Certification → AMCS (AAM-authoritative medical record);
     MedXPress is intake, CHAPS is a read-authoritative replica, DIWS is
     imaging, CPDSS is drug-surveillance adjacent
   - Drug Surveillance → CPDSS
   - Designee Management → DMS
   - Document Imaging → DIWS (medical) + RMS (airman files); flag for
     consolidation into a shared imaging service
   - Regulatory Letter Generation → AMCS / CHAPS / CPDSS / IACRA (distributed
     today); flag for consolidation into a shared letter-gen service
   - Knowledge Testing → AKTS / PRD-adjacent (not in the ATLAS 8-app set);
     scope as future, name the participants
   - Airman Application Workflow → IACRA (primary) + AMCS MedXPress (medical
     application intake)
5. For every participant_app_id that writes to a context it does not own,
   emit a `context_map_relationships[]` entry with pattern
   `customer-supplier` (if contract-stable) or `conformist` (if the
   downstream accepts the upstream's model unchanged) or
   `anti-corruption-layer` (if the downstream's target ubiquitous language
   differs from the upstream's legacy).
6. Record the ubiquitous language per context. Include legacy-alias and
   target-term pairs for every term that will differ between legacy and
   target. A target context that keeps the legacy term unchanged (e.g.,
   "registration certificate" — the regulation uses the same phrase)
   should still record the term with legacy-alias = target-term to make
   the decision explicit.
7. Choose `target_service_type` per context. Default decision rule:
   - `microservice` — when the context has independent deployment cadence,
     a small canonical entity set, and async event-driven integration.
   - `modular-monolith` — when two tightly coupled capabilities within the
     context share a data store and share a release cadence (acceptable
     and often correct for Certificate Issuance + Airman Application
     Workflow in the IACRA-absorbing service).
   - `serverless` — when the context is event-triggered batch or
     request/response with low steady-state load (Regulatory Letter
     Generation, TIFF generation for IACRA cert issuance).
   Record a one-sentence rationale per choice; `target_service_type` is a
   design hint, not a runtime constraint — `transition-strategy-designer`
   and `service-interaction-mapper` consume it as input.
8. Enumerate `events_published[]` and `events_consumed[]` per context.
   Events are in past-tense (`airman-certified`, `medical-application-accepted`,
   `designee-authorization-revoked`) and carry a subject identifier plus
   a version. Consumed events include cross-context events
   (Certificate Issuance consumes `airman-identity-updated` from Airman
   Identity) and internal events (serverless letter-gen consumes
   `medical-decision-rendered` from Medical Certification).
9. Populate `api_surface[]` per context. Verb + resource + purpose, not
   URL paths (those come later in `service-interaction-mapper`). The
   surface is the candidate contract; Sub-factor 3 evaluators score
   whether a service has a meaningful boundary, not the HTTP details.
10. Render the Mermaid context map. Use `flowchart LR` with subgraphs per
    context cluster and labeled edges for each relationship pattern.
    Alternative: `classDiagram` form when the relationship density is
    high. Either is acceptable; both are in the reference file.
11. Validate. `domain-decomposition.json` must pass its schema and the
    two custom validators: `bounded_context_sor_uniqueness_validator`
    (each bounded context has exactly one `sor_app_id`) and
    `canonical_entity_ownership_validator` (every canonical entity is
    owned by exactly one context; drift produces the
    `canonical-entity-ownership-drift` failure class).

## Tech-Stack Dispatch

| Signal | Context hint |
|---|---|
| NATURAL + ADABAS (CAIS) | Airman Identity is RMS-owned; migration pattern is anti-corruption-layer around legacy reads during transition |
| Windows SQL Server + aircraft-registry schema in RMS | Aircraft Registry is RMS-owned; SoR remains RMS through transition |
| Oracle shared MSS schema | Medical Certification, Drug Surveillance, and Regulatory Letter Generation share a legacy database; decomposition splits these into domain-scoped databases per bounded context |
| .NET WebForms + VB.NET (IACRA) | Certificate Issuance and Airman Application Workflow are both IACRA-absorbing; they may ship as a modular monolith inside one service |
| ASP.NET Core + Angular 8 + Postgres audit (DMS) | Designee Management is DMS-owned; the Postgres audit store moves to RDS PostgreSQL in the target |
| Unisys InfoImage | Document Imaging — RMS side; migrates to S3 + OpenSearch |

## Gotchas
- Canonical entity ownership drift is the most common failure mode in
  FAA decomposition. The airman record literally sits in five-plus
  places today (RMS CAIS, IACRA airman-profile, AMCS applicant,
  CHAPS applicant-replica, DMS designee-if-also-airman, DIWS imaging
  subject). The target must designate exactly one owner (Airman Identity
  / RMS) and every other context reads the airman record via API or
  CDC-propagated replica.
- Anti-corruption layers are mandatory whenever the target bounded
  context's ubiquitous language differs from a legacy source system's.
  CAIS NATURAL's `airman file` carries fields and semantics that the
  target Airman aggregate does not. A direct read-through of CAIS into
  the target model corrupts the target language; insert an ACL adapter.
- Separate-ways is the correct relationship between RMS airman-side and
  IACRA's historical permanent cert ledger — they share no semantic
  overlap even though they physically coexist. Do not force a
  customer-supplier relationship where none exists.
- Customer-supplier between IACRA (downstream) and RMS Airman Identity
  (upstream) is contract-stable in the target. Record the contract
  stability expectations on the relationship row; the downstream team
  will consume this to pin API versioning posture.
- Bounded context is not microservice. A single bounded context can
  ship as a modular monolith, a microservice, or a serverless handler.
  The `target_service_type` choice is a separate design decision. Do
  not generate ten microservices mechanically — that is the
  `one-capability-per-microservice` failure class.
- God-service anti-pattern: combining Airman Identity and Certificate
  Issuance into one service is tempting because IACRA is certificate-
  centric and CAIS is airman-centric. Keep them separated. The cert
  event `airman-certified` is published by Certificate Issuance and
  consumed by Airman Identity to update the airman's credential set.
  A single service that owns both breaks the ubiquitous-language
  boundary and hides the event contract.
- The AAM-suite (MSS) consolidation target is fewer bounded contexts,
  not more. Do not map MedXPress, CHAPS, and DIWS to three separate
  contexts — they are participants in Medical Certification +
  Document Imaging + Regulatory Letter Generation. The five apps
  collapse into three contexts with shared supporting services.
- Legacy VB.NET and NATURAL code does not map cleanly to DDD tactical
  patterns (aggregates, value objects, domain events). Use the
  strategic patterns (bounded context, context map) everywhere;
  apply tactical patterns selectively to the target code, not to the
  decomposition itself.
- Knowledge Testing (AKTS / PRD-adjacent) is referenced by IACRA and
  AMCS but is not in the ATLAS 8-app set. Record it as a bounded
  context with `sor_app_id = "out-of-scope-akts"` and flag in
  `participant_app_ids[]` the FAA apps that consume it. Do not invent
  a target service for it — that is out of scope.
- Customer-supplier contracts across the shared Oracle MSS schema are
  invisible today (they are all in-database joins). Making them
  explicit as contexts is the whole point of this skill; do not let
  the shared-schema pattern leak into the target architecture.

## Quality Rules
- [ ] `bounded_contexts[]` has exactly ten entries matching the names in
      `references/faa-bounded-context-catalog.md`.
- [ ] Every bounded context has exactly one `sor_app_id` (validator:
      `bounded_context_sor_uniqueness_validator`).
- [ ] Every canonical entity appears in exactly one context's
      `canonical_entities[]` (validator:
      `canonical_entity_ownership_validator`).
- [ ] Every `participant_app_ids[]` entry that is not the `sor_app_id`
      has at least one `context_map_relationships[]` row linking its
      context to the SoR context.
- [ ] Every `ubiquitous_language[]` term has both `legacy_alias` and
      `target_term` fields populated.
- [ ] Every `target_service_type` is one of `microservice` |
      `modular-monolith` | `serverless` with a one-sentence rationale.
- [ ] Every `events_published[]` and `events_consumed[]` entry uses
      past-tense, subject-identifier-bearing event names.
- [ ] `migration_source_capabilities[]` references existing capability
      ids in `business-logic.json` (no invented capabilities).
- [ ] Every anti-corruption-layer relationship cites the ubiquitous-
      language pair that triggered it.
- [ ] The Mermaid diagram parses (Mermaid 10+ syntax) and labels every
      edge with its relationship pattern.

## Common Failure Modes
| Failure Mode | Symptom | Prevention |
|---|---|---|
| Context boundary leak | A single capability appears in two contexts' `migration_source_capabilities[]` | A capability belongs to one context; split the capability in Discovery Pass 2 or re-evaluate the context split |
| SoR ambiguity | A bounded context has `sor_app_id` empty or lists multiple apps | Every context has exactly one authoritative SoR; dual-SoR in RMS is resolved by splitting into Airman Identity and Aircraft Registry as separate contexts |
| God-service anti-pattern | Airman Identity + Certificate Issuance collapsed into one context | Keep them separate; the cert event crosses the boundary; enforce distinct `sor_app_id` |
| Canonical entity ownership drift | The Airman entity appears in multiple contexts' `canonical_entities[]` | Airman is owned exclusively by Airman Identity (RMS); all other contexts read-only replicas via CDC or API |
| Missing anti-corruption layer | Target ubiquitous language copies legacy CAIS terms unchanged for an RMS-feeding context | When target term differs from legacy alias, the downstream context needs an ACL; emit the relationship row |
| One-capability-per-microservice | Ten microservices mapped directly to ten contexts with no modular-monolith or serverless choices | `target_service_type` is a design decision per context; defaults to modular-monolith for tightly coupled capability clusters; microservice is not the default |

## Handoff Summary
When this skill completes, verify:
1. `domain-decomposition.json` exists at the portfolio level and passes
   its schema plus the two custom validators.
2. All ten bounded contexts are present with exactly one `sor_app_id`
   each.
3. Every canonical entity has exactly one owning context.
4. `context-map.mmd` parses in Mermaid 10+ and labels every edge with
   its relationship pattern.
5. Every `migration_source_capabilities[]` reference resolves to a
   capability id in `business-logic.json`.

Then proceed to: `aws-govcloud-target-architecture` (consumes the
decomposition to align per-app service boundaries with the ten
contexts), `service-interaction-mapper` (consumes the context map plus
`events_published[]`/`events_consumed[]` to produce the edge-level
topology), `faa-canonical-entity-modeler` (consumes `canonical_entities[]`
to produce the enterprise canonical data model), and
`data-duplication-resolution-designer` (consumes SoR designations to
produce the target duplicate-resolution plan). The next gate is
**G-DA** (Design Acceptance).

## References
- `references/faa-bounded-context-catalog.md` — authoritative list of
  the ten bounded contexts with SoR, participants, ubiquitous language
  terms, canonical entities, typical interactions, and example
  integration patterns.
- `schemas/architecture/domain-decomposition.schema.json` — canonical
  JSON shape for domain-decomposition.json.
- `/Users/pnunna/Documents/SOO-Announcement/Phase2_Evaluation_Criteria.md`
  §5 Sub-factor 3 — evaluator rubric for domain decomposition.

## Changelog
- 0.1.0 (2026-05-06) — Initial skill. Fixes the ten FAA bounded contexts,
  pins SoR per context, records the context-map relationships
  (partnership, customer-supplier, conformist, ACL, separate-ways),
  emits the Mermaid diagram, and enforces the three quality invariants
  (one-SoR-per-context, one-owner-per-canonical-entity, participant-to-
  SoR-relationship-required). Covers the four FAA app suites collapsed
  into ten business-outcome contexts.
