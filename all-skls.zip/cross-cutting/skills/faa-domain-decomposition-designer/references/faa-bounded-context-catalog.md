# FAA Bounded Context Catalog

The authoritative list of the ten bounded contexts for the FAA 8-app portfolio.
Each context has exactly one System of Record (SoR), a defined set of
participating applications, a ubiquitous language that differs from every
other context, and a canonical entity set. Target architectures must align
to this list; adding a new bounded context requires an architectural
decision record (ADR), not an ad-hoc extension.

Portfolio apps in scope: IACRA, RMS (dual-SoR for airman-side and
aircraft-side), AMCS, MedXPress, CHAPS, CPDSS, DIWS, DMS. Total eight apps
collapsed into ten business-outcome contexts plus one out-of-scope reference
context (Knowledge Testing).

---

## 1. Airman Identity

**Definition.** The authoritative record of an airman: identity, contact
information, credentials held, certificate history, medical certification
status (replicated from Medical Certification context), and document file
references. Every other context that reads airman data reads it from here
via API or CDC-propagated replica.

**SoR.** RMS (CAIS on z/OS NATURAL/ADABAS). The legal airman file lives
in CAIS; transition target is Aurora PostgreSQL.

**Participants (read-only replicas).** IACRA (cert issuance joins), AMCS
(applicant lookup), CHAPS (medical applicant lookup), DMS (designee-if-airman
joins), DIWS (imaging subject lookup), CPDSS (drug-subject lookup).

**Canonical entities.** Airman, AirmanCredential, AirmanCertificate
(permanent record after cert issuance), AirmanContactAddress.

**Ubiquitous language.**
- Legacy `airman file` (CAIS) → Target `Airman aggregate`
- Legacy `pilot certificate number` → Target `airman_id`
- Legacy `airman name` (packed decimal fields) → Target `Airman.name`
  (structured given / family / suffix)

**Typical interactions.**
- `customer-supplier` downstream: IACRA → Airman Identity (cert issuance
  reads airman identity).
- `anti-corruption-layer`: Medical Certification reads airman via an ACL
  to translate CAIS airman-file semantics into the target Airman
  aggregate.
- `conformist`: DIWS Document Imaging indexes documents against
  `airman_id` as published by Airman Identity without reinterpretation.

**Events published.** `airman-registered`, `airman-identity-updated`,
`airman-credential-added`, `airman-certificate-recorded`.

**Events consumed.** `airman-certified` (from Certificate Issuance),
`medical-decision-rendered` (from Medical Certification).

**Target service type.** Microservice. High fan-out read load; independent
release cadence; CDC outbound to replicas.

---

## 2. Aircraft Registry

**Definition.** The authoritative record of US-registered civil aircraft:
N-number, make/model/serial, registered owner, registration class,
airworthiness records. Governed by 49 USC §44107.

**SoR.** RMS (aircraft-registry schema on Windows SQL Server). Transition
target is Aurora PostgreSQL.

**Participants.** No direct read/write participants among the other seven
apps — Aircraft Registry is a separate-ways context relative to the rest.
External consumers (FAA Civil Aircraft Registry public query) are
out-of-scope for this decomposition.

**Canonical entities.** Aircraft, RegisteredOwner, AircraftRegistration
(the authoritative lifecycle record), AirworthinessRecord.

**Ubiquitous language.**
- Legacy `N-number` → Target `aircraft_id` (N-number remains the
  human-readable alternate key).
- Legacy `registration transaction` → Target
  `AircraftRegistrationTransaction`.

**Typical interactions.** `separate-ways` with every other context. This
is the correct relationship: Aircraft and Airman share no operational
semantic overlap in the FAA model (despite both living in the RMS
application). Do not force a customer-supplier relationship where none
exists.

**Events published.** `aircraft-registered`, `aircraft-ownership-transferred`,
`aircraft-deregistered`.

**Events consumed.** None within the portfolio.

**Target service type.** Microservice. Legal-record posture requires
independent release cadence and strict audit. 146M TIFF corpus of
imaging lives in Document Imaging, not here.

---

## 3. Certificate Issuance

**Definition.** The issuance lifecycle for airman certificates under 14 CFR
Part 61, 63, and 65: application intake, qualification verification,
examiner assignment, Temporary Airman Certificate generation, permanent
cert record handoff to Airman Identity.

**SoR.** IACRA (Temporary Airman Certificates; AFS-760-authoritative).
Permanent cert records, once issued, flow back to Airman Identity
(RMS CAIS) as `airman-certificate-recorded` events.

**Participants.** Airman Identity (source of airman lookup), Designee
Management (examiner identity), Medical Certification (medical status
gate for airman-class applicants).

**Canonical entities.** CertificateApplication, TemporaryCertificate,
ExaminerAssignment, QualificationVerification.

**Ubiquitous language.**
- Legacy `AFS-760 application` → Target `CertificateApplication`.
- Legacy `temporary airman certificate` → Target `TemporaryCertificate`
  (with a digital-signature-bearing TIFF render for the public-facing
  copy).

**Typical interactions.** `customer-supplier` downstream of Airman Identity,
Designee Management, and Medical Certification. `anti-corruption-layer`
around RMS CAIS airman reads during transition.

**Events published.** `certificate-application-submitted`,
`certificate-application-approved`, `certificate-application-denied`,
`airman-certified` (consumed by Airman Identity).

**Events consumed.** `airman-identity-updated`, `designee-authorization-active`,
`medical-decision-rendered`.

**Target service type.** Modular monolith with Airman Application Workflow
(next context). IACRA's application intake + certificate issuance share a
release cadence and a data store; they are correctly one deployable unit.

---

## 4. Medical Certification

**Definition.** Airman medical certification under 14 CFR Part 67: medical
application intake, Aviation Medical Examiner (AME) exam results, Aerospace
Medical Certification (AAM) decision rendering, medical certificate
issuance, medical condition tracking, special-issuance authorizations.

**SoR.** AMCS (Aerospace Medical Certification Subsystem; AAM-authoritative).

**Participants.** MedXPress (public-facing application intake), CHAPS
(Comprehensive Airman History and Performance System — read-authoritative
replica for AAM review), Airman Identity (source of airman lookup), DIWS
(imaging of exam forms).

**Canonical entities.** MedicalApplication, AMEExamResult, MedicalDecision,
MedicalCertificate, SpecialIssuanceAuthorization.

**Ubiquitous language.**
- Legacy `MedXPress application` → Target `MedicalApplication` (intake
  channel is MedXPress participation).
- Legacy `FAA Form 8500-8` → Target `AMEExamResult`.
- Legacy `CHAPS view` → read-authoritative replica of
  `MedicalApplication` + `AMEExamResult` + `MedicalDecision` for AAM
  staff.

**Typical interactions.** `customer-supplier` upstream of Certificate
Issuance (airman-class cert gates on medical status). `partnership`
between MedXPress (intake) and AMCS (core) — they share release cadence
during the transition. `conformist` for CHAPS relative to AMCS (CHAPS
accepts AMCS's model unchanged today; in the target this is preserved
via CDC replica).

**Events published.** `medical-application-submitted`,
`medical-application-accepted`, `medical-decision-rendered`,
`medical-special-issuance-authorized`.

**Events consumed.** `airman-identity-updated` (from Airman Identity).

**Target service type.** Modular monolith. AMCS + MedXPress collapse
into one service with a bounded-context-internal application-intake
module; CHAPS becomes a replica-backed read API.

---

## 5. Drug Surveillance

**Definition.** Drug and alcohol testing program for airmen and
safety-sensitive employees of aviation employers. Covers test scheduling,
result intake, random-selection pools, regulatory-letter drug-case
issuance.

**SoR.** CPDSS (Consolidated Pilot Drug Surveillance System).

**Participants.** Airman Identity (airman lookup), Regulatory Letter
Generation (drug-case letters), DIWS (test-result imaging).

**Canonical entities.** DrugTest, RandomSelectionPool, DrugCase,
EmployerProgram.

**Ubiquitous language.**
- Legacy `DOT random pool` → Target `RandomSelectionPool`.
- Legacy `positive test case` → Target `DrugCase` (lifecycle: opened,
  investigated, adjudicated, closed).

**Typical interactions.** `customer-supplier` upstream of Regulatory Letter
Generation for drug-case letters. `conformist` read-only relationship
with Airman Identity.

**Events published.** `drug-test-result-recorded`, `drug-case-opened`,
`drug-case-adjudicated`, `drug-case-closed`.

**Events consumed.** `airman-identity-updated`.

**Target service type.** Microservice. Independent release cadence; low
fan-out; scheduled batch for random-selection runs.

---

## 6. Designee Management

**Definition.** FAA designees under 14 CFR Part 183: Designated Pilot
Examiners (DPE), Designated Medical Examiners (AME), Designated Engineering
Representatives (DER), Designated Airworthiness Representatives (DAR).
Covers designee appointment, surveillance activity tracking, annual renewal,
and authorization revocation.

**SoR.** DMS (Designee Management System).

**Participants.** Certificate Issuance (examiner identity for airman cert
issuance), Medical Certification (AME identity), Airman Identity
(designee-if-also-airman join).

**Canonical entities.** Designee, DesigneeAuthorization, SurveillanceActivity,
DesigneeRenewal.

**Ubiquitous language.**
- Legacy `designee number` → Target `designee_id`.
- Legacy `DPE appointment` → Target `DesigneeAuthorization`
  (authorization_type = `DPE`).

**Typical interactions.** `customer-supplier` upstream of Certificate
Issuance and Medical Certification. `anti-corruption-layer` with
Airman Identity (a designee may or may not be an airman; the join
handles both cases).

**Events published.** `designee-authorized`, `designee-authorization-renewed`,
`designee-authorization-revoked`, `surveillance-activity-recorded`.

**Events consumed.** `airman-identity-updated`.

**Target service type.** Microservice. ASP.NET Core + Angular 8 is
already container-ready; transition is Replatform + limited Rearchitect.

---

## 7. Document Imaging

**Definition.** Long-term archival and retrieval of scanned paper documents
across the FAA portfolio: airman files (RMS), medical exam forms (DIWS),
drug test chain-of-custody (CPDSS), designee surveillance records (DMS),
certificate applications (IACRA). TIFF and PDF content; 146M+ TIFF
corpus on RMS today.

**SoR.** Consolidated target service (new). Today, imaging is split between
DIWS (medical) and RMS (airman files). Target consolidation into a shared
imaging service is a design objective.

**Participants.** Airman Identity, Medical Certification, Drug Surveillance,
Designee Management, Certificate Issuance — all five emit and retrieve
documents through the imaging service.

**Canonical entities.** Document, DocumentVersion, ImagingSession,
RetentionPolicy.

**Ubiquitous language.**
- Legacy `Unisys InfoImage document` → Target `Document` (S3-backed).
- Legacy `TIFF page set` → Target `DocumentVersion.pages[]`.

**Typical interactions.** `customer-supplier` downstream for every
content-producing context. `anti-corruption-layer` around Unisys InfoImage
during transition (the legacy document model uses vendor-specific
metadata fields that do not translate to S3 Object Lock + OpenSearch
directly).

**Events published.** `document-archived`, `document-retrieved`,
`document-retention-triggered`.

**Events consumed.** Various content-producing events from all five
producer contexts (for example, `medical-application-submitted` triggers
an imaging session in the target architecture).

**Target service type.** Microservice. Backed by S3 + OpenSearch;
image-processing workflows as serverless (Lambda).

---

## 8. Regulatory Letter Generation

**Definition.** Generation of regulatory letters to airmen: medical-denial
letters (14 CFR Part 67), drug-case letters (Part 91 drug program),
certificate-denial letters (Parts 61/63/65), special-issuance
authorization letters, and byte-preserved legal-wording letters. The
target is a shared letter-generation service consumed by every producing
context.

**SoR.** Consolidated target service (new). Today, letter generation is
split across AMCS, CHAPS, CPDSS, and IACRA with duplicated templates.

**Participants.** Medical Certification (denial / special-issuance),
Drug Surveillance (drug-case), Certificate Issuance (cert-denial),
Designee Management (designee-action).

**Canonical entities.** LetterTemplate, LetterGenerationRequest,
LetterOutput, LetterRenditionAudit.

**Ubiquitous language.**
- Legacy `letter template #123` (embedded in AMCS) → Target
  `LetterTemplate` with versioned byte-level preservation for
  legal-wording-sensitive templates.
- Legacy `denial letter` → Target `LetterOutput` (typed
  `LetterOutput.type = denial`).

**Typical interactions.** `customer-supplier` downstream for every
producing context. `shared-kernel` for the template registry — the
template set is shared across producers with governance.

**Events published.** `letter-generated`, `letter-sent`,
`letter-return-to-sender-recorded`.

**Events consumed.** `medical-decision-rendered`,
`drug-case-adjudicated`, `certificate-application-denied`,
`designee-authorization-revoked`.

**Target service type.** Serverless (letter generation is event-triggered
with low steady-state load) backed by the shared template store. Byte-
level template preservation is a legal requirement under 14 CFR Part 67
for medical letters.

---

## 9. Knowledge Testing

**Definition.** Written-test administration for airman certification
knowledge tests (AKTS — Airman Knowledge Testing Service) and parallel
PRD-adjacent knowledge-testing data. Out of scope for the ATLAS 8-app
set but referenced by IACRA (test-result validation during cert issuance).

**SoR.** `out-of-scope-akts` (not in the portfolio). Record as
reference-only context.

**Participants.** Certificate Issuance (consumes test-result-validated
events).

**Canonical entities.** KnowledgeTestResult (reference entity — the
portfolio consumes but does not own).

**Ubiquitous language.** Legacy AKTS terminology passes through unchanged.

**Typical interactions.** `conformist` — the portfolio accepts AKTS's
model unchanged.

**Events published.** Out of scope.

**Events consumed.** `knowledge-test-result-recorded` (from the external
AKTS service, flagged for future contract work).

**Target service type.** Not applicable; external system.

---

## 10. Airman Application Workflow

**Definition.** The application-intake workflow across the portfolio:
airman cert applications (IACRA AFS-760), medical applications
(MedXPress), designee-renewal applications (DMS), drug-program
employer registration (CPDSS). Covers intake channels, draft-save
resume, submission, and routing to the appropriate producing context.

**SoR.** IACRA (primary) + MedXPress (medical intake channel).

**Participants.** Certificate Issuance, Medical Certification, Designee
Management, Drug Surveillance — each consumes submitted applications
routed by the workflow.

**Canonical entities.** Application, ApplicationDraft, ApplicationSubmission,
ApplicationRouting.

**Ubiquitous language.**
- Legacy `WebForms form state` → Target `ApplicationDraft`.
- Legacy `submit` action → Target `ApplicationSubmission` event.

**Typical interactions.** `customer-supplier` upstream of every
producing context.

**Events published.** `application-drafted`, `application-submitted`,
`application-routed`.

**Events consumed.** None within the portfolio (inbound from public
user action).

**Target service type.** Modular monolith with Certificate Issuance.
The IACRA-absorbing service owns both application intake and cert
issuance; they share a data store and release cadence.

---

## Summary table

| Context | SoR | Target service type |
|---|---|---|
| Airman Identity | RMS (CAIS) | Microservice |
| Aircraft Registry | RMS (aircraft-side) | Microservice |
| Certificate Issuance | IACRA | Modular monolith (w/ Airman Application Workflow) |
| Medical Certification | AMCS | Modular monolith (w/ MedXPress intake; CHAPS replica) |
| Drug Surveillance | CPDSS | Microservice |
| Designee Management | DMS | Microservice |
| Document Imaging | Consolidated (new) | Microservice |
| Regulatory Letter Generation | Consolidated (new) | Serverless |
| Knowledge Testing | out-of-scope-akts | Not applicable |
| Airman Application Workflow | IACRA + MedXPress | Modular monolith (w/ Certificate Issuance) |

Downstream skills consume this catalog. Adding or renaming a context
requires an ADR in `specifications/decisions.md` and a registry-index
update; do not modify the names casually.
