---
name: environment-guarded-sql-detector
description: >
  Detect SQL migration scripts that encode environment-deployment
  constraints via filename suffix — a filename-as-metadata convention
  where the deployment tool parses the filename to decide which
  environment to apply against. AMCS is the ATLAS case:
  `AMCS-1141_Change_Description_RunOnlyOnLowerEnvironment.sql`,
  `AMCS-1482_Other_RunOnlyOnTEST.sql`,
  `DHS_Auto_Insert_Query_EpoweOnly.sql`,
  `DHS_Entry_Criteria_Query_EPowerOnly.sql` (note the typo `Epowe` in
  some). Modernization tools that don't parse these suffixes will
  apply scripts to the wrong environment, corrupting data. Runs as
  Discovery conditional when `db/` files contain filename patterns
  like `_RunOnlyOn*`, `_EpoweOnly`, `_EPowerOnly`, `_ProdOnly`,
  `_TestOnly`. Triggers on environment-gate audit or
  @environment-guarded-sql-detector.
agent: sonnet
allowed-tools:
  - Read
  - Write
  - Grep
  - Glob
validation_commands:
  - "python -m olympus.validators.schema_validator environment-gated-sql-inventory.json"
  - "python -m olympus.validators.schema_validator environment-matrix-findings.json"
supported_stacks:
  - oracle
  - sqlserver
  - plsql
  - tsql
anti_target_stacks:
  - declarative-schema-only
  - config-based-env-gating
  - static-site
failure_classes:
  - gate-suffix-lost-on-rename
  - typo-normalization-drops-metadata
  - deploy-tool-bypasses-gate
  - environment-matrix-incomplete
benchmark_tags:
  - discovery-database
  - environment-gating
  - filename-metadata-preservation
---

# environment-guarded-sql-detector

## Purpose
Catalog filename-suffix environment-gating conventions so deploy-
tool modernization preserves the behavior.

## Inputs
- Repository `db/` with ticket-keyed `.sql` files.

## Outputs
- `environment-gated-sql-inventory.json` — per script:
  `{filename, gate_suffix, gate_environments (lower | test | prod |
  epower-only | dhs-only), original_case_preserved}`.
- `environment-matrix-findings.json` — per environment: which
  scripts apply and which don't.

## Methodology
1. Glob `db/**/*.sql`.
2. Regex match filename suffixes (case-insensitive):
   `_RunOnlyOn(LowerEnvironment|TEST|PROD|Prod|Test|Dev)`,
   `_(Epowe|EPower|Epower)Only`, `_ProdOnly`, `_TestOnly`,
   `_DevOnly`, `_RunOnce`.
3. Map suffix to environment set.
4. Emit matrix.
5. Preserve original case + typos verbatim.

## Tech-Stack Dispatch

No external references.

## Gotchas
- Typos are real (`Epowe` vs `EPower`). Don't normalize.
- Case-insensitive matching during detection; case-sensitive
  preservation in output.
- Some teams use `_LOWER`, `_TEST`, `_PROD` prefixes instead of
  suffixes.
- Gate suffix can be combined with ticket prefix:
  `AMCS-1141_Description_RunOnlyOnTEST.sql`.
- Deploy tool must be configured to honor the suffix; modernization
  needs explicit env-matrix wiring.

## Quality Rules
- [ ] Every gated filename inventoried.
- [ ] Typos preserved in output.
- [ ] Environment matrix complete.
- [ ] Every record cites `{repo}:{file}:{line}`.

## Common Failure Modes

| Failure Mode | Symptom | Prevention |
|---|---|---|
| Typo normalized | `Epowe` renamed to `Epower` — gate semantics lost | Preserve original filename verbatim |
| Deploy tool bypass | Modernized tool runs ALL scripts regardless of suffix | Emit matrix + explicit deploy-tool wiring requirement |

## Handoff Summary
Environment-gating inventoried. Proceed to `deploy-modernized-app`.

## References
None.

## Changelog
- 0.1.0 (2026-05-07) — Initial skill. Authored as ATLAS-R-19.
