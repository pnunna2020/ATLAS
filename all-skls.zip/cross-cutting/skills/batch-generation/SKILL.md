---
name: batch-generation
description: >
  Generate batch job implementations from batch designs, producing Step Functions state machines, Lambda handlers, and EventBridge rules. Use during P4.3. Triggers on batch generation, batch code, Step Functions code.
agent: sonnet
allowed-tools:
  - Read
  - Write
  - Bash
  - Grep
---

# Batch Generation

## Purpose
Generate cloud-native batch implementations from designs.

## Gotchas
- **Step Functions state machine JSON is easy to get wrong**: Use the
  template in assets/ and validate with `aws stepfunctions validate-state-machine`.
- **Lambda cold starts affect batch timing**: For time-critical batch jobs,
  use provisioned concurrency or Fargate instead of Lambda.
- **Generate the EventBridge rule alongside the Lambda**: They're a pair —
  don't generate one without the other.

## Quality Rules
- [ ] Step Functions state machine JSON validates via `aws stepfunctions validate-state-machine` before deployment
- [ ] EventBridge rules and Lambda handlers are generated as a pair — neither exists without the other
- [ ] Lambda cold start impact is assessed: time-critical batch jobs use provisioned concurrency or Fargate
- [ ] Generated code includes error handling, retry logic, and dead-letter queue configuration matching the batch design
- [ ] Idempotency keys are implemented in every generated batch handler — no re-run side effects
- [ ] Generated tests cover success path, failure/retry path, and idempotent re-run scenario

## Common Failure Modes
| Failure Mode | Symptom | Prevention |
|-------------|---------|------------|
| Invalid state machine JSON | Step Functions deployment fails with syntax or schema errors | Validate all state machine JSON with AWS CLI before committing |
| Orphaned Lambda without trigger | Lambda function generated but EventBridge rule not created; job never executes | Always generate EventBridge rule and Lambda as a pair; validate pairing in tests |
| Cold start timeout | Time-critical batch job fails on first invocation due to Lambda cold start latency | Assess timing requirements; use provisioned concurrency for latency-sensitive jobs |
| Missing idempotency | Re-run after partial failure creates duplicate records; data integrity compromised | Implement deduplication keys and upsert patterns in every batch handler |

## Handoff Summary
When this skill completes, verify:
1. State machine JSON validates with AWS CLI
2. EventBridge rules and Lambda handlers are paired
3. Tests cover success, failure/retry, and idempotent re-run paths
4. Cold start mitigation is configured for time-critical jobs
Then proceed to: `parity-verifier` (P5.1) for batch output comparison, and gate `G-04c` for generation quality review
