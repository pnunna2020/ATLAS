# eWorkflow Definition Extraction

eWorkflow process definitions are business rules, not config.
Extract for migration (FAA Phase 2 target: Camunda 8).

## Where definitions live
Typical eWorkflow schema:
- `WORKFLOW_DEFINITION` — one row per process; `definition_id`,
  `name`, `version`, `active_flag`, `xml_blob` or
  `definition_text`.
- `WORKFLOW_STEP_DEF` — steps; `step_id`, `step_no`, `step_type`
  (manual/auto/decision), `assignee_rule`, `timeout_seconds`.
- `WORKFLOW_ROUTE` — transitions; `from_step`, `to_step`,
  `condition_expr` (stored predicate string).
- `WORKFLOW_ESCALATION` — SLA; `step_id`, `threshold_seconds`,
  `escalate_to_role`.
- `WORKFLOW_ROLE_MAP` — role-to-group bindings.

Some installs store the definition as one XML/JSON blob on
`WORKFLOW_DEFINITION`; others normalize into step/route tables.
Check both — partial normalization is common.

## Extraction for Camunda 8 migration
1. Dump every `active_flag = 1` definition with child rows as
   JSON. One file per `definition_id`.
2. Per step: type, assignee rule, timeout, escalation, data keys.
3. Per route: source, target, predicate verbatim. Do not translate
   here; capture raw text for downstream BPMN authoring.
4. Resolve role-to-group bindings against AD/LDAP so Camunda
   candidate-groups map cleanly.
5. Emit a coverage report: definitions extracted, orphaned steps
   (no incoming route), dead-ends (no outgoing), routes with
   missing `WORKFLOW_STEP_DEF` parents.

## Anti-pattern
Treating eWorkflow steps as opaque routing. They encode SLA
thresholds, assignee logic, and branch predicates — all business
rules. Copying only the happy path loses escalation and decision
logic, which reappears as Camunda-side incidents.

## Output
Per-definition JSON bundles, queued for `extraction` scope. Flag
definitions whose predicates reference tables outside eWorkflow
as `cross-app-sharing`.

## Citation format
`eworkflow:{definition_id}:{step_number}` — e.g.
`eworkflow:WF-CASE-INTAKE-v7:step-3`.
