# Stored Proc Classification

Classify by AST, not top-level verb.

## Categories
- **crud-only**: 1-2 DML; no branches with calculations; no loops beyond fetch-next; no external calls.
- **business-logic**: 2+ of {branches with calculations, multi-step workflow, validation errors, state transitions}. Queue for `extraction`.
- **integration-shim**: calls external systems (HTTP, CLR, dblink writes, MQ).
- **reporting**: SELECT-only with aggregates/windows/temp tables.
- **data-migration**: one-shot ETL; writes staging then truncates.
- **unused**: zero callers in dep views and zero grep hits.

## PL/SQL (Oracle)
- CRUD: `INSERT ... SELECT`, only `WHEN OTHERS THEN RAISE`.
- Business: `FOR` cursors with `IF`, `RAISE_APPLICATION_ERROR` on computed predicates, packaged state, `FORALL` branches.
- Shim: `UTL_HTTP`, `DBMS_PIPE`, `DBMS_AQ`, dblinks in DML.

## T-SQL (SQL Server)
- CRUD: single DML, no `BEGIN TRY`, no temp tables.
- Business: `IF EXISTS ... ELSE`, `WHILE` over driving tables, `THROW` codes, `MERGE WHEN MATCHED` logic.
- Shim: `sp_OACreate`, CLR procs, `OPENQUERY`, Service Broker, linked-server writes.

## NATURAL (ADABAS)
- CRUD: single `READ`/`FIND`/`STORE`/`UPDATE`/`DELETE`.
- Business: nested `DECIDE ON`, `PERFORM` chains, periodic-group arithmetic, MU-field iteration, `CALLNAT` fan-out.
- Shim: `CALL 'external'`, WebIO, Entire-X.

## DB2 SQL PL
- CRUD: single DML in `BEGIN ... END`, no handlers.
- Business: `DECLARE HANDLER FOR`, `ITERATE`/`LEAVE`, `SIGNAL SQLSTATE` on computed conditions.
- Shim: `CALL` external Java/COBOL, federated nicknames.

## PL/pgSQL
- CRUD: single DML, no `EXCEPTION WHEN`.
- Business: `RAISE EXCEPTION` on computed predicates, `LOOP` with conditional writes, triggers writing other tables.
- Shim: FDW writes, `dblink`, `plpython`.

## Counting
- One branch plus one calculation: **business-logic**.
- Handler around single DML: **crud-only**.
- Shim plus business: **integration-shim**, rule count in `business_rules_embedded`.
