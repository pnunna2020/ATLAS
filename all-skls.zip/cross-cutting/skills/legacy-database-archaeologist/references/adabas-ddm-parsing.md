# ADABAS DDM Parsing

NATURAL apps have no SQL DDL. A DDM (Data Definition Module) defines the logical record layout over an ADABAS file. Parse DDMs for FAA apps like CAIS and AADOCS.

## DDM location
- Exported via `SYSDDM` (`LIST DDM <name>`).
- On disk: `$NATURAL_HOME/FNAT/<library>/DDMs/` or inside `.INPL` / `.SAG`.
- Repos keep exports under `ddm/`, `DDMs/`, or `objects/DDM/`.

## DDM layout
Header carries DDM name, ADABAS file number (DBID/FNR), owner. Body is a sequence of field records:

- **Level** (`1` top, `2` child inside a group).
- **Name** (2-char ADABAS short name, e.g. `AA`).
- **Long name** (NATURAL-visible, e.g. `PERSONNEL-ID`).
- **Length / format** (`8 A` alphanumeric, `6 P` packed).
- **Descriptor flag** (`D` descriptor, `U` unique, `N` non-desc).
- **Options** (`NU` null-suppressed, `FI` fixed).

## Structures to count

1. **Fields**: every level-1 row that is not a group header. Count total and by format.
2. **Periodic groups (PE)**: group that repeats N times per record, marked `PE`. Each PE counts once; inner fields still count as fields.
3. **Multiple-value fields (MU)**: single field that repeats, marked `MU`. MU inside PE combines both flags.
4. **Superdescriptors (SU)**: composite indexes over 2+ fields, in a separate section. Subdescriptors (`SB`) and hyperdescriptors (`HY`) are variants — record as superdescriptors.

## Cross-references
- NATURAL subprograms reference DDMs via `VIEW OF <ddm-name>` in DEFINE DATA. Grep source for `VIEW OF`.
- Multiple DDMs may describe the same ADABAS file. Group by `(DBID, FNR)` before reporting.

## Output per DDM
- `ddm_name`, e.g. `PERSONNEL-VIEW`.
- `fields`: total scalar fields (exclude group headers).
- `periodic_groups`: PE count.
- `multiple_value_fields`: MU count.
- `superdescriptors`: SU + SB + HY count.
- `citation`: `{ddm-file}:{line}`.

## Gotcha
A DDM with zero fields usually means the export was truncated by terminal width. Re-export with `LS=250` before reporting empty.
