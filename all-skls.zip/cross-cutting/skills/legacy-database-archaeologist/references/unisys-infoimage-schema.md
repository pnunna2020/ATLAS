# Unisys InfoImage Schema Archaeology

Schema-side archaeology of InfoImage metadata. Corpus extraction
lives in `tiff-corpus-assessor`.

## Metadata layout
Typical SQL Server tables:
- `IMAGE_METADATA` — one row per TIFF; `image_id`, `folio_id`,
  `page_no`, `storage_path`, `checksum`.
- `FOLIO` — doc; `folio_id`, `doc_type`, `case_id`, `created_ts`,
  `retention_class`.
- `FOLIO_ITEM` — ordered pages; `folio_id`, `seq`, `image_id`.
- `WORKFLOW_QUEUE` — active work; `folio_id`, `step_id`,
  `owner_user`, `entered_ts`, `sla_ts`.
- `WORKFLOW_STEP` — step instances → `WORKFLOW_DEFINITION`.
- `USER_BASKET` — per-user inboxes.
- `INDEX_*` — custom index tables per doc-type; column names
  often encode rules (`IDX_CASE_URGENT_FLAG`).

## Join pattern
`FOLIO → FOLIO_ITEM → IMAGE_METADATA` gives ordered binaries.
`FOLIO → WORKFLOW_QUEUE → WORKFLOW_STEP → WORKFLOW_DEFINITION`
gives the process wrapping the doc.

## Where business logic hides
- Trigger tables (`WF_TRIGGER`, `WF_ROUTE_RULE`) encode routing
  predicates in text or bit columns.
- `INDEX_*` columns added in-place; column names are the only
  doc trail.
- Unisys sproc prefixes: `ii_`, `ewf_`, `ux_`. Anything else is
  customer-added, a business-logic candidate.

## Archaeology priorities
1. Orphaned folios — `FOLIO_ITEM` with no `FOLIO` parent.
2. Items without binaries — `FOLIO_ITEM.image_id` not in
   `IMAGE_METADATA`.
3. Stuck workflow — `WORKFLOW_QUEUE.entered_ts` older than
   `retention_class` threshold.
4. Custom `INDEX_*` without DDL history — encoded rules, no spec.
5. Custom sprocs outside Unisys prefixes — classify via
   `stored-proc-classification.md` (T-SQL).

## Detection heuristics
- `sys.objects.name LIKE 'ii_%' OR 'ewf_%'` → vendor.
- FK convention: child tables carry `folio_id`/`image_id` as
  non-null FKs; missing FK + matching column = shadow join.
- `sys.extended_properties` on `INDEX_*` usually empty; parse
  column names, not doc.

Cite `{table}:{column}` or `sys.sql_modules:{object}`.
