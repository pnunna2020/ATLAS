# Unused Table Detection

A table is **unused** only when every signal agrees. Single-signal matches are **deprecated** or **unknown**.

## Signals (all must hold)

1. **Zero writes in audit window.** No INSERT/UPDATE/DELETE in N months (default 12).
   - Oracle: `DBA_AUDIT_OBJECT`, Unified Audit, Flashback.
   - SQL Server: Change Tracking, Extended Events, `sys.dm_db_stats_properties`.
   - DB2: `SYSIBMADM.MON_GET_TABLE` counters since last reset.
   - Postgres: `pg_stat_all_tables.n_tup_ins/upd/del`, `last_autovacuum`.

2. **Zero references in app code.** Grep app repos for bare name and `schema.table`. Cover source, config, migrations, SQL templates, ORM mappings.

3. **Zero references in DB objects.** Check dep views before trusting grep:
   - Oracle: `DBA_DEPENDENCIES`.
   - SQL Server: `sys.sql_expression_dependencies`.
   - DB2: `SYSCAT.TABDEP`, `SYSCAT.PACKAGEDEP`.
   - Postgres: `pg_depend`.

4. **No dynamic-SQL refs.** Grep procs for `EXECUTE IMMEDIATE`, `sp_executesql`, concatenation. Dynamic refs never appear in dep views.

5. **Last-modified stale.** Use `DBA_TAB_MODIFICATIONS`, `sys.dm_db_index_usage_stats`, `pg_stat_user_tables`. Not `LAST_ANALYZED` — stats only.

## Orphan patterns
- **Views over dropped tables**: base table missing. Emit `orphan-object`.
- **FKs to non-existent parents**: self-join `DBA_CONSTRAINTS` r_constraint_name. Emit `orphan-object`.
- **Names `*_BAK`, `*_OLD`, `*_COPY`, `*_TMP`, `*_20xx`**: candidates but still need signals 1-3.
- **Row-count 0, no writes**: may be failover/init targets — check app config first.

## Classification
- All five signals: `usage_status: "unused"`, severity `high` (or `critical` if > 50 GB).
- Signals 1-3 hold, dynamic-SQL risk: `usage_status: "deprecated"`, severity `medium`.
- Name pattern only: `usage_status: "archive-only"`, severity `low`.
- Any signal ambiguous: `usage_status: "unknown"`, no finding.

Every finding cites both audit-view result and grep command.
