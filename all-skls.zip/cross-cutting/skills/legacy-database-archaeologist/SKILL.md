---
name: legacy-database-archaeologist
description: >
  Perform deep archaeology on legacy databases to uncover unused tables, shadow
  schemas, stored-procedure business-logic classification, ADABAS DDMs, cross-app
  schema sharing, and end-of-life engines. Complements `legacy-architecture-mapper`
  by specializing in database-resident logic rather than structural boundaries.
  Runs during Discovery Step 3 Pass 1. Output conforms to
  `schemas/discovery/db-archaeology.schema.json`.
  Triggers on database archaeology, legacy schema analysis, stored procedure
  classification, shadow schema detection, ADABAS DDM parsing, EOL engine audit,
  or @legacy-database-archaeologist.
agent: opus
allowed-tools:
  - Read
  - Write
  - Grep
  - Bash
---

# legacy-database-archaeologist

## Purpose
Dig into a legacy database to expose hidden coupling, dead weight, and database-resident business logic that structural mappers miss. Classify every stored procedure, trigger, and view by intent (CRUD-only, business-logic, integration-shim, reporting, unused), flag shadow schemas that look like production, detect end-of-life engine versions, and catalog cross-application schema sharing that represents undocumented hard dependencies. This skill is how Discovery surfaces the 60%+ of business logic that lives in stored procedures on legacy FAA platforms like RMS (SQL Server 2016 on IMS) and CAIS/AADOCS (NATURAL/ADABAS).

## Inputs
- Application catalog entry (JSON per `schemas/discovery/application-catalog-entry.schema.json`)
- Tech fingerprint from `analyze-application` Pass 1 (JSON per `schemas/discovery/tech-fingerprint.schema.json`)
- Database connection metadata or a read-only metadata dump (DDL, dictionary exports, ADABAS DDM files)
- DBMS audit logs or change-tracking output where available (for write-activity analysis)
- Source code repository (for grep-based usage cross-reference)
- Module/component map from `legacy-architecture-mapper` when available

## Outputs
- Database archaeology report → `schemas/discovery/db-archaeology.schema.json`
- Filled report template → `assets/db-archaeology-report-template.yaml`
- Stored-procedure classification list (feeds `extraction` scope for `business-logic` procs)
- Findings list with severity and remediation hints (feeds `rationalization`)
- List of objects referred into `legacy-architecture-mapper` for cross-coupling updates

## Methodology
1. Detect database engine, version, edition, and end-of-life status from the tech fingerprint and dictionary queries. Flag any engine past vendor de-support as an `eol-engine` finding.
2. Enumerate schemas with owner, object counts, size, and purpose. Mark schemas that share a substantial fraction of tables or naming patterns with another schema as shadow candidates; confirm by comparing DDL hashes and row counts.
3. Inventory tables with row counts, last-modified dates, PK/FK presence, and index counts. Classify `usage_status` using write-activity heuristics from `references/unused-table-detection.md`.
4. Cross-reference every table against source code with grep. Tables with zero app references, zero view references, and no writes in the audit window become `unused` with a `critical` or `high` finding depending on row volume.
5. Extract stored-procedure and function source. Classify each proc by the heuristics in `references/stored-proc-classification.md` into `crud-only`, `business-logic`, `integration-shim`, `reporting`, `data-migration`, or `unused`.
6. For each `business-logic` proc, count embedded business rules (conditional branches with calculations or validations) and record `called_from` relationships. Flag for `extraction` scope.
7. Inventory triggers. Classify each as passive (audit-only, simple copy, cascading integrity) or `contains_business_logic = true` (calculation, routing, side-effecting writes to other tables). Flag business-logic triggers as `high` severity.
8. When the engine is ADABAS, parse DDM files per `references/adabas-ddm-parsing.md`. Record fields, periodic groups, multiple-value fields, and superdescriptors for each DDM.
9. Detect cross-app schema sharing: tables referenced by code or SQL from more than one application repository, or synonyms/dblinks pointing into another app's schema. Record as `cross-app-sharing` findings with the sharing applications enumerated.
10. Sweep for orphaned objects: views over dropped tables, FKs pointing to non-existent parents, procs referencing missing schemas. Emit `orphan-object` findings with affected-object lists and citations.

## Tech-Stack Dispatch
Dispatch is mechanical and mutually exclusive. Apply the first row whose trigger matches `database_engine.type`.

| Trigger | Reference file | Key patterns |
|---|---|---|
| `database_engine.type == "oracle"` | `references/stored-proc-classification.md` (PL/SQL section) | `DBA_OBJECTS`, `DBA_SOURCE`, `DBA_TRIGGERS`, `DBA_DEPENDENCIES`, PL/SQL packages, synonyms, dblinks |
| `database_engine.type == "sql-server"` | `references/stored-proc-classification.md` (T-SQL section) | `sys.procedures`, `sys.sql_modules`, `sys.triggers`, linked servers, `sp_depends`, OPENQUERY |
| `database_engine.type == "adabas"` | `references/adabas-ddm-parsing.md` | DDM files, NATURAL `CALLNAT`, periodic groups, MU fields, superdescriptors, NATURAL system files |
| `database_engine.type == "db2"` | `references/stored-proc-classification.md` (DB2 SQL PL section) | `SYSIBM.ROUTINES`, `SYSIBM.SYSROUTINES`, `SYSCAT.PROCEDURES`, SQL PL vs. external procs |
| `database_engine.type == "postgresql"` | `references/stored-proc-classification.md` (PL/pgSQL section) | `pg_proc`, `pg_trigger`, `information_schema.routines`, inheritance, FDW references |
| `unisys-infoimage detected (IMAGE_METADATA tables, eWorkflow definitions present)` | `references/unisys-infoimage-schema.md`, `references/eworkflow-definitions.md` | `IMAGE_METADATA`, `FOLIO`, `FOLIO_ITEM`, `WORKFLOW_QUEUE`, `WORKFLOW_DEFINITION`, `INDEX_*`, Unisys prefixes `ii_`/`ewf_`/`ux_` |

Also load `references/unused-table-detection.md` unconditionally — the detection heuristics are engine-agnostic.

## Gotchas
- **Shadow schema treated as production.** Test or staging copies with realistic names (e.g., `RMS_CAIS_OLD`, `AADOCS_ARCHIVE`) look like real data. Always compare DDL hashes and write-activity against the canonical schema before classifying a schema as production.
- **EOL engine undetected.** Oracle 11g, SQL Server 2016, and DB2 for z/OS v11 are past vendor de-support but commonly still running. The engine version banner can lie (custom branding, emulated headers) — confirm against the dictionary, not just `SELECT @@VERSION`.
- **CRUD-only on the surface, business logic inside.** A proc that looks like `INSERT ... SELECT` may branch on conditional logic in the `SELECT`. Classify by AST structure and branch/calculation count, not by the top-level statement.
- **Grep misses dynamic SQL.** Tables referenced only through EXECUTE IMMEDIATE, sp_executesql, or string concatenation will appear unused. Cross-check against DBMS-level dependency views (`DBA_DEPENDENCIES`, `sys.sql_expression_dependencies`) before marking a table `unused`.
- **ADABAS DDMs are not DDL.** NATURAL apps do not have SQL DDL; DDMs define the logical record layout. Do not report `table_count = 0` for ADABAS — report DDM count and file counts.
- **Cross-app sharing through synonyms.** Oracle synonyms and SQL Server linked-server views hide the owning schema. Resolve every synonym and linked-server reference before declaring a table app-local.
- **Last-modified dates are not last-write dates.** `USER_TABLES.LAST_ANALYZED` and equivalents reflect stats collection, not DML. Use audit logs, change-tracking, or transaction-log scraping for real write activity.
- **Missing PK/FK is not always a bug.** Some legacy staging tables intentionally omit constraints for load performance. Record the finding but classify severity based on whether the table is a system of record.

## Quality Rules
- [ ] Every stored procedure in `stored_procedures[]` has a non-null `classification` value from the schema enum — no `unknown` placeholders.
- [ ] Every `business-logic` procedure has `business_rules_embedded >= 1` and at least one `called_from` entry or an explicit `orphan` note in `citation`.
- [ ] Every table in `tables[]` has a `usage_status` value; tables marked `unused` have zero hits in both app-code grep and view/proc cross-reference, documented in `citation`.
- [ ] `database_engine.end_of_life` is populated when the engine version is past vendor de-support, and a matching `eol-engine` finding exists in `findings[]`.
- [ ] Every schema with `is_shadow: true` has a paired canonical schema identified in the `purpose` field or in a `shadow-schema` finding.
- [ ] For ADABAS engines, `adabas_ddms[]` is non-empty and every DDM has `fields` populated.
- [ ] Every finding has a `citation` pointing to a DDL file, dictionary view, or source location in `{file}:{line}` or `{dictionary-view}:{object-name}` format.
- [ ] Cross-app sharing findings enumerate both applications in `affected_objects[]` with no placeholder values.
- [ ] Triggers marked `contains_business_logic: true` appear as `logic-in-trigger` findings with severity `high` or `critical`.
- [ ] Output validates against `schemas/discovery/db-archaeology.schema.json` with no `additionalProperties` violations.

## Common Failure Modes
| Failure Mode | Symptom | Prevention |
|---|---|---|
| Shadow schema treated as production | Downstream rationalization recommends keeping a test/archive copy; modernization targets duplicate data | Compare DDL hashes, row counts, and write-activity against the canonical schema before classifying; set `is_shadow: true` when duplication confirmed |
| EOL engine undetected | Migration plan assumes continued vendor support; compliance audit flags a de-supported engine post-cutover | Cross-check engine version against vendor de-support dates; always emit an `eol-engine` finding when past EOL, never rely on the version banner alone |
| Stored procs classified by first statement | Procs with deep conditional logic mislabeled as `crud-only`; extraction skips them and business rules are lost | Classify by AST branch and calculation count per `references/stored-proc-classification.md`, not by the top-level DML verb |
| Dynamic SQL ignored | Tables referenced only through `EXECUTE IMMEDIATE` or `sp_executesql` flagged as unused; production tables recommended for drop | Always cross-check `DBA_DEPENDENCIES` / `sys.sql_expression_dependencies` before emitting `unused-table`; grep is necessary but insufficient |
| ADABAS reported as empty | NATURAL apps report `table_count = 0` and the archaeologist produces a near-empty report | Detect `database_engine.type == "adabas"` early; dispatch to DDM parsing instead of SQL dictionary queries |
| Synonyms hide cross-app coupling | Tables appear app-local; modernization silently breaks a sibling app that read through a synonym | Resolve every synonym and linked-server reference; emit a `cross-app-sharing` finding for every resolved cross-schema dependency |

## Handoff Summary
When this skill completes, verify:
1. Every stored procedure is classified; every `business-logic` proc is queued for `extraction` scope with `business_rules_embedded` populated.
2. Every `eol-engine`, `shadow-schema`, and `cross-app-sharing` finding has severity and remediation hints, and affected objects enumerated.
3. For ADABAS databases, DDM inventory is complete with field counts and superdescriptors.
4. Report validates against `schemas/discovery/db-archaeology.schema.json`.

Then proceed to: `legacy-architecture-mapper` for structural reconciliation of database findings with the module map, and `extraction` for `business-logic` procs and triggers. Findings flow to gate `G-DC` for Discovery completeness review.
