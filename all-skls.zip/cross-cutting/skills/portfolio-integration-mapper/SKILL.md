---
name: portfolio-integration-mapper
description: >
  Synthesize per-app Discovery artifacts for every application in a portfolio
  into a single cross-application integration graph (systems, data flows,
  shared identifiers, external dependencies, and cross-system capabilities).
  Decomposes multi-subsystem applications (e.g., FAA RMS = CAIS + AADOCS +
  IMS + aircraft-registration) into their constituent parts before cross-app
  integration analysis, so internal edges — shared copybooks, Software AG
  Broker calls, TN3270 scraping, SFTP drops, ADABAS->SQL replication — are
  visible in the graph instead of being hidden inside a single opaque node.
  Runs once per portfolio as a cross-app pass AFTER Discovery completes and
  BEFORE Rationalization begins, so Rationalization can make
  capability-level dispositions instead of per-app-only 7R decisions.
  Triggers on portfolio integration mapping, cross-app integration graph,
  integration-graph synthesis, portfolio dependency synthesis,
  multi-subsystem decomposition, or @portfolio-integration-mapper.
version: 0.2.0
agent: sonnet
enrichment_level: partial
allowed-tools:
  - Read
  - Write
  - Grep
---

# Portfolio Integration Mapper

## Purpose
Produce the single `integration-graph.json` artifact that Rationalization and
wave planning consume. Per-app Discovery already maps each application's own
dependencies, catalog entry, and tech fingerprint — but no per-app artifact
sees the whole portfolio. This skill is the cross-app synthesis pass that
joins every app's Discovery output into one directed graph, resolves shared
identifiers, flags external dependencies, and groups systems into the
business capabilities they jointly implement. Without this pass,
disposition decisions collapse to per-app 7Rs and miss consolidation and
capability-level Retire/Replace opportunities.

## Inputs
- Per-app application catalog entries (one JSON per app per
  `schemas/discovery/application-catalog-entry.schema.json`).
- Per-app dependency graphs from `dependency-mapper` (emitted by each
  Discovery run in the template shape shipped by that skill).
- Per-app tech fingerprints produced by `analyze-application` Pass 1.
- Per-app data-flow traces from `legacy-data-flow-tracer` when present
  (multi-system and mainframe-heavy portfolios).
- Per-app identity-landscape findings from `identity-landscape-analyzer`
  when the app is in-scope for SSO/IAM integration.
- Client-profile risk-classification and scoring config
  (`profiles/<client>/risk-classification.yaml`,
  `profiles/<client>/scoring.yaml`) for tier and volume banding.
- Client-profile capability taxonomy, when the profile defines one
  (e.g., `profiles/faa/acis-reference-topology.yaml`).

## Multi-Subsystem Decomposition

Some registered applications span multiple named subsystems with
distinct tech stacks, data stores, and auth models. FAA RMS is the
motivating case: a single catalog entry covering CAIS (z/OS NATURAL
+ ADABAS), AADOCS (z/OS NATURAL workflow engine), IMS (.NET 4.5.2
thick client + SQL Server + Unisys eWorkflow), and aircraft
registration (Classic ASP + ASP.NET Web Forms + SQL Server). Treating
RMS as a single node in the integration graph erases every internal
edge — shared copybooks, Software AG Broker calls, TN3270 scraping,
SFTP drops, nightly ADABAS->SQL replication, AADOCS queue
replication — and inflates cross-app integration complexity because
internal calls look like external ones.

**Decompose** a registered application into its constituent
subsystems when any of these thresholds fire:

- `>= 2` distinct tech-stack families detected in Pass 1 `tech_stack`
  (e.g., both mainframe AND web tokens)
- `>= 3` top-level subsystem directories (detected by
  `scripts/detect_subsystems.py <root>`, which returns a JSON
  `{"subsystems": [...]}` list after applying the naming regex and
  skipping build/vendor/doc dirs)
- README explicitly names `>= 2` subsystems in H1-H3 headings or a
  `# Subsystems` / `## Components` section

When the threshold is met, emit one `systems[]` entry **per subsystem**
(carrying a `parent_app` back-reference), and classify every internal
edge using the 9-kind taxonomy in
`references/multi-subsystem-decomposition.md` §3: `shared-copybook`,
`shared-schema`, `db-link`, `tn3270-scraping`, `sftp-drop`,
`nightly-batch-replication`, `message-bus-broker`, `queue-replication`,
`file-share`. Record the decomposition decision — which app was
split, which subsystems emerged, and why — in
`metadata.decomposed_apps[]` for G-RR audit.

Full detection signals, decomposition heuristics, internal-integration
taxonomy, output shape, anti-patterns, and findings checklist live in
`references/multi-subsystem-decomposition.md`. Invoke
`scripts/detect_subsystems.py` from the skill (or from the Phase-1
prescan) to populate the dir-layout signal without ad-hoc parsing.

## Outputs
- Cross-portfolio integration graph →
  `schemas/rationalization/integration-graph.schema.json`
  (emitted as `integration-graph.json` in the Rationalization working set).
- Integration-graph skeleton template agents fill in →
  `assets/integration-graph-template.json`.
- Unresolved-reference report (flows pointing to unknown system ids,
  external deps with no named owner, duplicate shared-identifier
  declarations) as inline diagnostics in the graph's `metadata` block.

## Methodology
1. Enumerate every application in scope from the portfolio manifest; fail
   closed when fewer than two applications are present (the integration
   graph is a cross-app artifact by construction).
2. For each app, load its catalog entry, dependency graph, tech fingerprint,
   and any optional data-flow or identity artifacts from the Discovery
   output tree.
3. Build the `systems[]` array: one entry per app, carrying `id`, `name`,
   `archetype` (from catalog or inferred by rule), `primary_language`, and
   `tier` from the client-profile risk classification.
4. Fold each app's dependency-graph edges into the `data_flows[]` array;
   deduplicate bidirectional duplicates, preserve every edge's
   `flow_type`, `data_domain`, `cadence`, and `volume_tier`.
5. Scan catalog and schema artifacts for business identifiers appearing
   in more than one app (e.g., `airman_id`, `registration_n_number`);
   emit a `shared_identifiers[]` entry for each, naming the authoritative
   source system and any canonicalization notes.
6. Collect external dependencies (mainframes, partner-gov APIs, SaaS)
   mentioned by any in-scope app; emit `external_deps[]` with a stable
   `id`, `name`, `kind` (alias `type`), `owner`, and `systems_using[]`.
7. Group systems that jointly implement a business capability into
   `cross_system_capabilities[]`; at minimum, infer capability clusters
   from (a) shared identifiers + data flows between the same set of
   systems, and (b) any profile-provided capability taxonomy.
8. Validate the assembled document against
   `schemas/rationalization/integration-graph.schema.json` before
   emitting. Halt on schema errors — downstream skills (`disposition-recommender`,
   `wave-planner`, `validate-disposition`) reject a malformed graph.
9. Write the graph to the Rationalization working set and record the
   `generated_date`, `applications_analyzed`, and source-artifact list in
   `metadata` so the output is reproducible.

## Gotchas
- **Per-app dependency graphs disagree on direction.** App A's graph may
  record "A -> B (API call)" while B's graph records "B <- A (inbound)".
  Canonicalize to a single directed edge keyed by
  `(source_system, target_system, flow_type, data_domain)` and dedupe;
  otherwise the graph doubles every cross-app edge.
- **Catalog ids must match the dependency-graph node ids.** Discovery
  skills occasionally emit app slugs (`iacra`) while dependency-mapper
  emits system ids (`sys-iacra`). Normalize to the catalog id up front
  or the join silently drops edges.
- **Shared identifiers are not always named the same across apps.** One
  app calls it `airman_id`, another `pilot_cert_no`, a third
  `cert_holder_id`. The canonical name must come from the system of
  record; leave a `canonicalization_notes` trail naming every alias seen.
- **External dependencies hide behind generic names.** "SWIM",
  "Login.gov", "Enterprise Auth" are all external deps but only one
  will appear verbatim in the source. Use the profile's external-dep
  catalog to canonicalize names; never invent a new `id` if the client
  profile already has one.
- **Mainframe file-drop flows have no code-level signal.** Apps that
  hand off TIFFs or fixed-width batches over SFTP look independent in
  the per-app graphs. Cross-check filename patterns and scheduler
  exports picked up by `dependency-mapper`'s batch-chain pass.
- **Capability grouping is not clustering for its own sake.** A
  `cross_system_capability` must implement one named business
  capability; if you can't name the capability, do not emit the group.
  `supporting_systems[]` must have `minItems: 2` for this reason.
- **Per-app disposition leaks into per-system disposition.** If
  Rationalization has already run on a subset of apps, copy their
  `disposition` into `systems[].disposition`, but do NOT infer a
  capability-level disposition from one app's value.

## Quality Rules
- [ ] Every `systems[]` entry's `id` matches the `id` in the
  corresponding `application-catalog-entry` — no orphan system ids.
- [ ] Every `data_flows[]` entry references `source_system` and
  `target_system` values that exist in `systems[]` — no dangling edges.
- [ ] Every `data_flows[]` entry has a non-null `flow_type` drawn from
  the enum in the schema; no free-form protocols allowed.
- [ ] Every `shared_identifiers[]` entry has `minItems: 2` in `systems`
  and a named `authoritative_source` that exists in `systems[]`.
- [ ] Every `external_deps[]` entry has `kind` set from the schema enum
  and `systems_using[]` with at least one in-scope system id.
- [ ] Every `cross_system_capabilities[]` entry has a named
  `capability_name` and `supporting_systems` with at least two distinct
  in-scope systems.
- [ ] `metadata.generated_date`, `metadata.applications_analyzed`, and
  `metadata.source_artifacts` are populated; the graph is reproducible
  from the listed source artifacts alone.
- [ ] The emitted JSON validates against
  `schemas/rationalization/integration-graph.schema.json` under both
  draft-07 and draft-2020-12 validators (the repo schema is
  cross-compatible).
- [ ] No schema additionalProperties violations — extension fields go
  into `metadata` or a profile-specific sub-artifact, never inline
  on schema-defined objects.

## Common Failure Modes
| Failure Mode | Symptom | Prevention |
|---|---|---|
| Dangling flow edges | `data_flows[]` references a `source_system` or `target_system` id that does not exist in `systems[]`; Rationalization's topological sort silently drops the node | Build `systems[]` first and validate every edge's endpoints against it before writing the graph |
| Bidirectional duplicates | Every real edge appears twice because both apps' per-app graphs contributed it in opposite directions | Dedupe by `(source_system, target_system, flow_type, data_domain)` after the merge; canonicalize "A inbound from B" to "B -> A" |
| Shared identifiers named inconsistently | Two apps reference the same business identifier but under different column names, so the join never fires | Resolve via the system of record; emit one `shared_identifiers[]` entry with `canonicalization_notes` listing every alias |
| External deps duplicated across apps | Same external system (e.g., SWIM) appears as three separate `external_deps[]` entries because three apps named it differently | Use a profile-level external-dep catalog to canonicalize names and stable ids; fold duplicates under one id |
| Capability clusters invented from data-flow topology | Connected components in the data-flow graph emitted as "capabilities" with no business meaning | Require a named `capability_name` sourced from the catalog or profile capability taxonomy; drop any cluster the skill can't name |
| Schema drift after profile updates | New profile adds an archetype or external-dep kind not in the schema; graph emission fails | Treat the schema enums as the contract; update the schema (and regenerate `skills-lock.json`) before referencing new values |

## Handoff Summary
When this skill completes, verify:
1. `integration-graph.json` exists in the Rationalization working set and
   validates against `schemas/rationalization/integration-graph.schema.json`.
2. Every `systems[]` id is referenced by at least one `data_flows[]` edge
   OR the system is explicitly flagged as isolated in `metadata`.
3. Every `shared_identifiers[]`, `external_deps[]`, and
   `cross_system_capabilities[]` entry has an in-scope `authoritative_source`
   or `systems_using[]`/`supporting_systems[]` reference.
4. `metadata.applications_analyzed` equals the number of per-app Discovery
   bundles that fed the graph.

Then proceed to: `disposition-recommender` (Rationalization Step 3) —
which consumes `integration-graph.json` to score capability-level
dispositions — and onward to `wave-planner` for dependency-aware wave
sequencing. The next gate is **G-RR** (Rationalization Review) where the
integration graph must be accepted before any disposition is marked
final.
