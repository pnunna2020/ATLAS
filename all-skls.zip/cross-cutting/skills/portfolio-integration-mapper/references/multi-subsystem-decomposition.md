---
part-of: portfolio-integration-mapper
topic: multi-subsystem-decomposition
applies-to: [rms, multi-stack, mainframe-plus-web, polyglot-portfolio]
---

# Multi-Subsystem Decomposition

Reference for decomposing a single *registered* application into its
constituent named subsystems **before** folding it into the cross-app
integration graph. The motivating case is FAA RMS (`rms-mock` in the
ATLAS-CHALLENGE corpus): one catalog entry, but four distinct subsystems
— **CAIS** (z/OS NATURAL + ADABAS airman system of record), **AADOCS**
(z/OS NATURAL workflow engine), **IMS** (.NET 4.5.2 thick client +
SQL Server + Unisys eWorkflow image management), and **aircraft
registration** (Classic ASP + ASP.NET Web Forms + SQL Server: ARDB /
EDRS II / Eforms / Foreign / FSDO / RCFax). Treating RMS as a single
node erases every internal edge: shared copybooks, Software AG Broker
calls, TN3270 scraping, SFTP hand-offs, nightly ADABAS->SQL replication,
and AADOCS queue replication. The portfolio graph then silently double-
counts cross-subsystem calls as cross-app, inflating integration
complexity and producing the wrong disposition recommendations.

RMS is the anchor case; generic examples are welcome.

---

## Section 1: Detection Signals

Decompose when *any two* of the following fire. One signal is a hint;
two is evidence.

### 1.1 Mixed tech-stack fingerprint

Pass 1 `tech_stack` on the catalog entry contains two or more distinct
platform families:

- mainframe tokens (`natural`, `adabas`, `cobol`, `jcl`, `cics`, `bms`,
  `copybook`, `tn3270`, `broker`, `infoimage`, `ewf`, `unisys`) *and*
- web tokens (`aspnet`, `webforms`, `mvc`, `classic-asp`, `vb6`,
  `dotnet`, `sqlserver`, `iis`)
- or mainframe *and* modern Java/Node/Python tokens
- or two distinct mainframe platforms with independent deployment units
  (e.g., CAIS on z/OS + IMS on Unisys)

RMS trips all three variants in one catalog row.

### 1.2 Top-level directories suggesting named subsystems

Walk `root` at depth 1 and collect directory names that match
`^[A-Za-z0-9][A-Za-z0-9_-]{2,29}$` and are **not** in the build/vendor
deny list (`bin`, `obj`, `target`, `dist`, `build`, `.venv`, `venv`,
`node_modules`, `.git`, `docs`, `tests`, `test`, `scripts`,
`__pycache__`). Three or more qualifying entries with README / `.sln`
/ `pom.xml` markers = decompose.

RMS: `cais/`, `aadocs/`, `ims/`, `aircraft-registration/` — four
qualifying entries, each with README and build manifest.

### 1.3 README headers name multiple subsystems

Top-level `README.md` has H1-H3 headings naming two or more distinct
subsystems, or an explicit "# Subsystems" / "## Components" section.
RMS reads: "RMS is composed of CAIS, AADOCS, IMS, and Aircraft
Registration." Extract H1-H3 tokens, strip noise verbs, match against
subsystem-style names.

### 1.4 Multiple build manifests at different depths

- Multiple `.sln` files at different subpaths
- Multiple `pom.xml` / `build.gradle` at different depths
- Multiple `package.json` with distinct `name` fields
- Mixed languages implying mixed build systems (Makefile for COBOL
  + `.csproj` for .NET in the same repo)

### 1.5 Per-subsystem auth / data-store divergence

- Each candidate has its own credentials store or SSO config (NATURAL
  security file for CAIS vs Windows Integrated Auth for IMS)
- Each candidate has its own primary data store (ADABAS for CAIS,
  SQL Server for IMS, a separate SQL Server for aircraft-reg)
- Distinct user-facing URLs or terminal/thick-client entry points

### 1.6 Threshold rule (machine-decidable)

Decompose when any of:

- `>= 2` distinct tech-stack families detected (per §1.1)
- `>= 3` top-level subsystem directories (per §1.2)
- README explicitly names `>= 2` subsystems (per §1.3)

The script `scripts/detect_subsystems.py` implements the §1.2 check
and can be invoked from the skill or the Phase-1 prescan.

---

## Section 2: Decomposition Heuristics

Once decomposition is triggered, each subsystem needs its own stable
id, tech fingerprint, auth model, and data store.

### 2.1 Boundaries from directory layout

- Top-level candidate dirs from §1.2 are the first cut.
- If a candidate has nested build manifests with mutually inconsistent
  stacks, split further (rare; RMS aircraft-reg spans multiple sub-
  apps but they share ASP.NET + SQL Server + a common auth boundary
  and belong to one subsystem).
- A candidate with only config/docs and no source is **not** a
  subsystem — it is infrastructure (e.g., `deploy/`, `ansible/`).
- Depth > 1 candidates are **ignored**. Decomposition is top-level-
  only; deeper structure is the subsystem's internal architecture and
  belongs to the per-app structural-analyzer, not the portfolio mapper.

### 2.2 Per-subsystem tech fingerprint

Re-run `analyze-application` Pass 1 / `structural-analyzer` with the
subsystem dir as root. Record:

- `primary_language` (NATURAL, C#, VB.NET, Classic-ASP, COBOL, …)
- `framework_family` (ASP.NET Web Forms 4.0, MVC5, NATURAL 8.x,
  Unisys eWorkflow 4.x, …)
- `data_store` (ADABAS file, SQL Server instance, filesystem share, …)
- `runtime_target` (z/OS LPAR, Windows IIS, Unisys ClearPath, …)

Never collapse per-subsystem fingerprints back into a single app-level
fingerprint — Rationalization needs them separate to score disposition.

### 2.3 Per-subsystem auth model

- NATURAL security file + CICS RACF (CAIS, AADOCS)
- Windows Integrated Auth + service account (IMS thick client)
- Forms auth + ASP.NET membership provider (aircraft-registration)
- PIV-backed SSO at the perimeter, but internal auth varies

Record each subsystem's auth model as a first-class field. Collisions
("IMS uses a different service account than aircraft-reg") are
rationalization inputs, not bugs.

### 2.4 Per-subsystem data store

Distinguish store **ownership** from store **access**. CAIS owns
ADABAS; IMS *reads* replicated copies over the nightly batch. Record
primary store, replication paths, and shared stores (copybooks,
Broker namespace, SFTP vault).

---

## Section 3: Internal-Integration Taxonomy

Every edge between subsystems inside the same registered app is
internal. Classify with one of these nine kinds.

### 3.1 shared-copybook

**Signal:** same `.cpy`/`.COPY` filename referenced in two subsystems.
Detection: grep `COPY <name>.` in NATURAL / `COPY <name>` in COBOL /
`#include <name>.cpy` in PL-I. RMS: `CONVEYANCE.cpy`, `AA-BASIC.cpy`
declare record layout for CAIS NATURAL, AADOCS NATURAL, and IMS T-SQL
(via hand-transliterated DDL). Field order is **load-bearing** for
batch read-routines; a rename breaks all three. Edge:
`source="copybook/CONVEYANCE"`, `target=<consumer>`, `kind="shared-copybook"`.

### 3.2 shared-schema

**Signal:** same table/view referenced in two subsystems. Detection:
enumerate tables referenced in sprocs/EF/SQL per subsystem; diff
overlap. RMS: `airman` table in CAIS-SQL-replica consumed by IMS and
aircraft-reg independently.

### 3.3 DB-link / linked-server

**Signal:** `sp_linkedservers`, `OPENQUERY(...)`,
`servername.db.schema.table`, `[LS_CAIS].airman.dbo....`,
`CREATE DATABASE LINK`, `db_link(...)`. Detection: grep `OPENQUERY`,
`linked_server`, `@@servername`, four-part names, `pg_foreign_server`.
RMS: IMS SQL Server linked-server to the CAIS replica for join
queries during claim processing.

### 3.4 TN3270-scraping

**Signal:** emulator DLLs (Attachmate/Aviva/PCOMM/QWS3270), HLLAPI
calls (`ConnectPresentationSpace`, `SendString`, `WaitForString`),
hardcoded `(row, col, len)` tuples, `HostSession`/`TerminalSession`
classes. Full signal catalog in
`../mainframe-discovery-patterns/references/integration-bus-patterns.md`
§1. RMS: IMS .NET 4.5 thick client embeds Aviva TN3270 to scrape
AADOCS maps for work-packet status. Edge: `source="ims"`,
`target="aadocs"`, `kind="tn3270-scraping"`, `protocol="aviva-tn3270e"`.

### 3.5 SFTP-drop

**Signal:** `sftp`/`scp`/`SSH.NET`/`Renci.SshNet`/`Tamir.SharpSsh`;
`scp`/`sftp` in JCL or shell scripts; Control-M/Cron jobs moving
files between subsystems; known hub hosts (`gblscp-okc.ait.faa.gov`
in RMS). Detection: filename patterns `*.sftp.cfg`, scheduler
manifests, hardcoded SFTP URIs. RMS: nightly export from CAIS ADABAS
dump -> SFTP `gblscp-okc` -> overnight pull by aircraft-reg loader.

### 3.6 nightly-batch-replication

**Signal:** ADABAS dump + replay into SQL Server / Oracle / DB2;
CDC jobs; Informatica / DataStage / SSIS packages from mainframe to
relational. Detection: scheduler entries (RMS `D-series` JCL jobs),
SSIS `.dtsx` packages, CDC trigger definitions, `INSERT INTO <staging>
SELECT FROM OPENROWSET` patterns. RMS: nightly ADABAS->SQL loads the
CAIS mirror that IMS and aircraft-reg read during the day.

### 3.7 message-bus-broker

**Signal:** EntireX / ETB broker config (`etbclient*`, `entirex*`,
`broker*.cfg`), RPC service/subservice names, Software AG Broker
adapters (see the mainframe-discovery integration-bus reference
§2). RMS: CAIS <-> IMS talk over Software AG Broker for synchronous
lookups; AADOCS events publish to broker topics consumed by IMS.

### 3.8 queue-replication

**Signal:** AADOCS-style named queue tables (`WP-INDEX`, `WP-ISSUE`,
`IA-ADD`, `COR`, `REJ`) replicated from NATURAL/ADABAS to SQL Server
as a state-machine mirror; IBM MQ topic replication; Kafka mirror-
maker configs. Detection: table-name patterns, scheduler jobs named
`*_REPL_*` / `*-QMIRROR-*`, MQ-Bridge config. RMS: AADOCS workflow
queues replicated into IMS SQL Server so IMS renders queue state
without round-tripping to z/OS.

### 3.9 file-share

**Signal:** UNC paths (`\\fileshare01\...`), NFS mounts, hardcoded
drive letters to shared drives, filesystem coupling as integration.
Detection: grep for `\\\\`, `/mnt/`, drive-letter constants, file-
watchers, `FileSystemWatcher` subscriptions. RMS: Unisys InfoImage
TIFF store shared between IMS (writer) and aircraft-reg (reader).

---

## Section 4: Output Shape

After decomposition the `integration-graph.json` looks like:

```jsonc
{
  "systems": [
    // one entry PER SUBSYSTEM, not per registered app
    {"id": "rms-cais", "name": "CAIS", "parent_app": "rms",
     "archetype": "mainframe-system-of-record",
     "primary_language": "natural", "tier": 1},
    {"id": "rms-aadocs", "name": "AADOCS", "parent_app": "rms",
     "archetype": "mainframe-workflow-engine",
     "primary_language": "natural", "tier": 1},
    {"id": "rms-ims", "name": "IMS", "parent_app": "rms",
     "archetype": "thick-client-image-management",
     "primary_language": "csharp", "tier": 1},
    {"id": "rms-aircraft-reg", "name": "Aircraft Registration",
     "parent_app": "rms", "archetype": "web-legacy-multi-app",
     "primary_language": "vb-classic-asp", "tier": 1}
  ],
  "data_flows": [
    {"source_system": "rms-cais", "target_system": "rms-ims",
     "flow_type": "nightly-batch-replication", "cadence": "daily",
     "data_domain": "airman", "volume_tier": "high",
     "mechanism": "adabas-to-sqlserver"},
    {"source_system": "rms-ims", "target_system": "rms-aadocs",
     "flow_type": "tn3270-scraping", "cadence": "synchronous",
     "data_domain": "workpacket", "mechanism": "aviva-tn3270e"}
  ],
  "metadata": {
    "decomposed_apps": [
      {"app_id": "rms",
       "subsystems": ["rms-cais", "rms-aadocs", "rms-ims",
                      "rms-aircraft-reg"],
       "reason": "multi-stack; 4 top-level dirs; README enumerates"}
    ]
  }
}
```

Invariants:

- `systems[].id` is globally unique with a `parent_app` back-reference
  so Rationalization knows "these four are one catalog entry" while
  still treating them as independent nodes for edges and disposition.
- `data_flows[].flow_type` uses the 9-kind taxonomy from §3, not free-
  form strings.
- `metadata.decomposed_apps[]` preserves the decomposition decision
  for audit at G-RR: which app was split, which subsystems emerged,
  and why.

---

## Section 5: Anti-Patterns

### 5.1 Treating the whole thing as a monolith

One node per registered app misses every internal integration. RMS
appears as a single vertex with three external edges. Reality: 11
internal + 3 external.

### 5.2 Missing internal edges

Decomposed nodes with only external edges. `rms-cais` and `rms-ims`
are both nodes but no edge connects them, even though the nightly
ADABAS->SQL replication is the dominant data flow inside RMS. Every
subsystem must have an inbound or outbound edge, or be explicitly
flagged as isolated in `metadata`.

### 5.3 Counting cross-subsystem calls as cross-app

If `rms-cais -> rms-ims` is logged as `cais -> ims` without the
`parent_app` back-reference, Rationalization double-counts it: once
as internal RMS, once as cross-app. Integration-complexity scoring
then penalizes RMS for every internal call.

### 5.4 Inventing subsystem boundaries from connectivity alone

Subsystems are named deployment units with their own tech stack and
owner. They are **not** "connected components of the data-flow
graph." A dense sub-graph inside RMS that clusters around
`AA-BASIC.cpy` is not automatically a subsystem; only named
deployment units qualify.

### 5.5 Collapsing per-subsystem fingerprints

Reporting `tech_stack = ["natural", "adabas", "csharp", "vbnet",
"classic-asp"]` on the parent app hides which tech belongs to which
subsystem. Downstream skills (Modernization router, generation-
language router) must see per-subsystem fingerprints to pick the
right generator.

### 5.6 Depth > 1 subsystems

Treating `ims/workpacket-viewer/` as a sibling of `cais/` doubles the
graph. IMS is one subsystem; `workpacket-viewer` is its sub-module.
Keep decomposition to depth 1.

### 5.7 Skipping the decomposition metadata

`metadata.decomposed_apps[]` is how human reviewers at G-RR audit
the split. Omitting it means reviewers cannot verify the
decomposition was correct.

---

## Section 6: Findings Checklist

A decomposition finding set has, at minimum, these ten items:

- [ ] **Enumerate subsystems:** name each (RMS -> CAIS, AADOCS, IMS,
      aircraft-registration).
- [ ] **Map each to tech stack:** per-subsystem `{primary_language,
      framework, data_store, runtime_target}`.
- [ ] **List shared-copybook edges:** every `.cpy` referenced in more
      than one subsystem, with use sites.
- [ ] **Count TN3270 touchpoints:** every `HostSession`-style class,
      every hardcoded `(row, col, len)` tuple.
- [ ] **Detect SFTP flows:** every SFTP URI, every scheduler job
      moving files between subsystems, every hub host.
- [ ] **Identify shared databases:** every table/view consumed in two
      or more subsystems; note ownership vs. read-only access.
- [ ] **List Broker call sites:** every EntireX/ETB service-subservice
      referenced from either side of an internal edge.
- [ ] **Flag queue-table replications:** every AADOCS-style queue
      mirrored into a relational store, with cadence.
- [ ] **Record DB-link / linked-server dependencies:** four-part
      names, `OPENQUERY` calls, linked-server definitions.
- [ ] **Document filesystem-as-integration paths:** every UNC path,
      NFS mount, drive-letter constant used as an inter-subsystem
      data channel.

When all ten populate, the integration graph carries enough signal
for Rationalization to score capability-level dispositions and spot
consolidation opportunities inside the multi-subsystem app (e.g.,
"retire AADOCS, absorb queue state into IMS SQL").

---

## Section 7: Worked Example — RMS Decomposition Sketch

Given `rms-mock/`:

```
rms-mock/
  cais/              # NATURAL programs + ADABAS DDMs + JCL
  aadocs/            # NATURAL queue workflow + JCL
  ims/               # C# .NET 4.5.2 thick client + SQL Server
  aircraft-registration/
    ardb/            # Classic ASP
    edrs2/           # ASP.NET Web Forms
    eforms/          # ASP.NET Web Forms
    foreign/         # ASP.NET Web Forms
    fsdo/            # Classic ASP
    rcfax/           # Classic ASP
  copybooks/         # CONVEYANCE.cpy, AA-BASIC.cpy (shared)
  conf/              # etbclient.cfg, iwfengStart.xml
  docs/              # README and design docs
```

`scripts/detect_subsystems.py rms-mock/` returns:

```json
{"subsystems": ["aadocs", "aircraft-registration", "cais", "conf",
                "copybooks", "ims"]}
```

The skill post-filters: `conf/` and `copybooks/` are *infrastructure*
(config + shared schema), not subsystems. They contribute edges but
do not become nodes. Final subsystem set: **CAIS, AADOCS, IMS,
aircraft-registration**.

| Subsystem | Language | Framework | Data Store | Runtime |
|---|---|---|---|---|
| CAIS | NATURAL | NATURAL 8.x + CICS | ADABAS | z/OS LPAR |
| AADOCS | NATURAL | NATURAL 8.x + queues | ADABAS | z/OS LPAR |
| IMS | C# | .NET 4.5.2 WinForms | SQL Server 2016 + InfoImage | Windows |
| aircraft-reg | VB/C# | Classic-ASP + WebForms | SQL Server 2016 | IIS |

Internal edges (sample):

| Source | Target | Kind | Mechanism |
|---|---|---|---|
| copybook/CONVEYANCE | CAIS, AADOCS, IMS | shared-copybook | include |
| CAIS | IMS | nightly-batch-replication | ADABAS->SQL |
| AADOCS | IMS | queue-replication | queue tables -> SQL |
| IMS | AADOCS | tn3270-scraping | Aviva TN3270E |
| CAIS | IMS | message-bus-broker | EntireX-ETB |
| CAIS | aircraft-reg | sftp-drop | gblscp-okc.ait.faa.gov |
| IMS | aircraft-reg | file-share | UNC: InfoImage TIFF store |

Without decomposition: 1 node, 0 edges for RMS. With decomposition:
4 nodes, 7+ internal edges before external-app connections. The
disposition recommender can now propose, e.g., "retire AADOCS +
absorb queue state into IMS SQL" as a capability-level option
rather than "retain RMS monolith."
