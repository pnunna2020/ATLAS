#!/usr/bin/env python3
"""Detect named subsystems in a multi-subsystem application root.

Used by ``portfolio-integration-mapper`` to decompose a single registered
app (e.g., FAA RMS = CAIS + AADOCS + IMS + aircraft-registration) into its
constituent subsystems before cross-app integration-graph synthesis.
Without this, internal edges (copybook reuse, SFTP drops, TN3270 scraping,
Software AG Broker, nightly ADABAS->SQL replication) never appear.

Rule (top-level dirs only, depth 1):
    A dir ``<root>/<name>`` is a subsystem when all hold:
      * name matches ``^[A-Za-z0-9][A-Za-z0-9_-]{2,29}$``
      * name is not in the deny list (build/vendor/doc dirs)
      * either contains a marker file (README*, *.sln, pom.xml) OR the
        naming regex alone qualifies the dir

CLI: ``python detect_subsystems.py <root>`` -> ``{"subsystems": [...]}``
"""
from __future__ import annotations

import argparse
import json
import re
import sys
from pathlib import Path

_SKIP_DIRS = frozenset({
    "docs", "tests", "test", "scripts", "node_modules", ".git",
    "bin", "obj", "target", "dist", "build", ".venv", "venv",
    "__pycache__", ".idea", ".vscode", ".github", ".gitlab",
})

_NAME_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9_-]{2,29}$")


def _is_marker(name: str) -> bool:
    lower = name.lower()
    return (
        lower == "pom.xml"
        or lower.startswith("readme.")
        or lower == "readme"
        or lower.endswith(".sln")
    )


def _looks_like_subsystem(entry: Path) -> bool:
    name = entry.name
    if name in _SKIP_DIRS or name.startswith("."):
        return False
    if not _NAME_RE.match(name):
        return False
    try:
        for child in entry.iterdir():
            if child.is_file() and _is_marker(child.name):
                return True
    except OSError:
        return False
    # Naming-regex-only fall-through keeps CAIS/AADOCS/IMS-style empty
    # placeholder trees registerable during prescan.
    return True


def detect(root: Path) -> list[str]:
    """Return sorted subsystem names directly under ``root`` (depth 1)."""
    if not root.exists() or not root.is_dir():
        return []
    found: list[str] = []
    for entry in sorted(root.iterdir(), key=lambda p: p.name.lower()):
        if entry.is_dir() and _looks_like_subsystem(entry):
            found.append(entry.name)
    return found


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        description="Detect named subsystems in a multi-subsystem app root.",
    )
    parser.add_argument("root", type=Path, help="Application root directory")
    args = parser.parse_args(argv or sys.argv[1:])
    root: Path = args.root
    if not root.exists() or not root.is_dir():
        print(json.dumps({"error": f"not a directory: {root}"}), file=sys.stderr)
        return 2
    print(json.dumps({"subsystems": detect(root)}, indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
