---
name: in-tree-dead-code-detector
description: >
  Detect project folders that exist on disk but are NOT referenced by
  any `.sln` file — in-tree dead code. Classic legacy-.NET-repo smell:
  CHAPS ships `ClassLibrary1/` (default Visual Studio generated name)
  on disk that is NOT in `ChapsTestWeb.sln`. These folders add build
  noise, confuse developers, and silently accumulate. Also detects
  `.cs` / `.vb` files in a project directory that are on disk but not
  in the project's compile set (legacy `.csproj` with explicit
  `<Compile Include>` declarations that miss a file). Runs as a
  Discovery conditional skill when the repo has `.sln` files.
  Triggers on dead-code inventory, orphan-project detection,
  compile-set audit, or @in-tree-dead-code-detector.
agent: sonnet
allowed-tools:
  - Read
  - Write
  - Grep
  - Glob
validation_commands:
  - "python -m olympus.validators.schema_validator dead-code-inventory.json"
  - "python -m olympus.validators.schema_validator dead-code-findings.json"
supported_stacks:
  - csharp
  - vbnet
  - dotnet
  - visual-studio
anti_target_stacks:
  - aspnet-core-sdk-style
  - static-site
  - non-dotnet
failure_classes:
  - default-vs-project-name-misclassified
  - sdk-style-implicit-compile-ignored
  - solution-folder-virtual-path-confused
  - build-output-mistaken-for-source
benchmark_tags:
  - discovery-dead-code
  - orphan-project-inventory
  - compile-set-audit
---

# in-tree-dead-code-detector

## Purpose
Inventory orphan project folders (on disk, not in any .sln) and
orphan source files (on disk in a project, not in its compile set).
Surface dead-code LOC that inflates Discovery metrics if left
uncorrected.

## Inputs
- Repository tree with `.sln` and project files.
- Optional: `multi-sln-duplicate-solution-detector` output for
  comprehensive .sln coverage.

## Outputs
- `dead-code-inventory.json` — per orphan folder: `{folder_path,
  project_file_present (true/false), project_file_path, source_file_count,
  total_bytes, last_modified, default_vs_generated_name (true/false)}`.
- `dead-code-findings.json` — severity-ranked findings: default-
  name project folders (high suspicion), folders with no activity
  > 180 days, projects referenced but missing, files in project
  dir but excluded from compile.

## Methodology
1. Glob all project-file candidate folders (any folder containing
   `*.csproj`/`*.vbproj`/`*.fsproj`).
2. Parse every `.sln` and collect referenced project paths.
3. Emit every project-file folder NOT referenced by any `.sln` as
   an orphan.
4. Detect default VS-generated names: `ClassLibrary1/`,
   `ClassLibrary2/`, `WindowsFormsApp1/`, `ConsoleApp1/`,
   `WebApplication1/`. These have the highest dead-code
   suspicion — the default name almost always means "never
   finished".
5. For legacy `.csproj` (explicit `<Compile Include>`), check for
   `.cs`/`.vb` files in the project dir that are NOT in the
   compile set. SDK-style projects use implicit globbing; skip
   for those.

## Tech-Stack Dispatch

No external references; logic is inline.

## Gotchas
- SDK-style `.csproj` (root element `<Project Sdk="Microsoft.NET.Sdk">`)
  uses implicit compile globbing — every `.cs` under the project
  dir is in the compile set unless explicitly excluded. Don't flag
  orphans for SDK-style.
- Default VS names (`ClassLibrary1`, `WebApplication1`, etc.) are
  almost always forgotten scaffolds. High-confidence dead code.
- Solution-folder virtual paths are NOT on-disk paths; don't
  cross-reference them against the filesystem.
- `bin/` and `obj/` output folders contain build outputs, not
  source. Exclude.
- A project that exists on disk but has no `.sln` reference may be
  a standalone build target used by ops scripts; check for
  `msbuild <project>.csproj` invocations in `ci/` or scripts
  before marking dead.
- Generated code (e.g., `.designer.cs`, `Reference.cs`) is legit
  source even if not in the compile set explicitly.

## Quality Rules
- [ ] Every project folder not in any .sln is in the inventory.
- [ ] Default-VS-name folders flagged.
- [ ] SDK-style projects skipped in compile-set audit.
- [ ] Activity date (last-modified) recorded per orphan.
- [ ] Every record cites `{repo}:{file}:{line}`.

## Common Failure Modes

| Failure Mode | Symptom | Prevention |
|---|---|---|
| SDK-style false positive | Manifest flags files not in explicit compile set | Skip SDK-style projects |
| Standalone build target dead-flagged | Project used by ops scripts but not in .sln | Grep `ci/` and scripts for project name |
| `bin/` counted as source | Build output inflates dead code | Exclude bin/obj |

## Handoff Summary
Dead-code inventory ready. Proceed to `disposition-recommender`
with LOC corrections; `validate-disposition` confirms findings.

## References
None — logic inline.

## Changelog
- 0.1.0 (2026-05-07) — Initial skill. Authored as ATLAS-R-19.
