---
name: traffic-shift
description: >
  Manage gradual traffic migration from legacy to modern application via Gravitee API gateway route configuration. Use during P6.1 deployment. Triggers on traffic shift, route migration, Gravitee routing, or traffic cutover.
agent: sonnet
allowed-tools:
  - Read
  - Write
  - Bash
---

# Traffic Shift via Gravitee
## Purpose
Gradually shift user traffic from legacy to modern application using Gravitee
weighted routing, with automatic rollback on error threshold breach.

## Workflow
1. Configure Gravitee weighted routes: 100% legacy / 0% modern
2. Shift to 90/10 split, monitor for 1 hour
3. If error rate < threshold: shift to 75/25, monitor
4. Continue shifting in increments per safety tier schedule
5. At 0/100: legacy routes kept but inactive (for rollback capability)

## Gotchas
- **Session stickiness during shift**: Users mid-session must stay on the same
  backend. Configure Gravitee session affinity.
- **Monitor BOTH systems during shift**: Error rate in the modern system AND
  error rate in the legacy system (some legacy issues may be masked).

## Quality Rules
- [ ] Traffic shift follows the safety tier schedule: T1 canary (5/25/50/100% over 14 days), T2 blue-green (24h), T3 blue-green (4h)
- [ ] Gravitee weighted routing is the sole traffic shift mechanism — no DNS changes
- [ ] Session stickiness is configured so users mid-session stay on the same backend
- [ ] Error rate monitoring is active on BOTH legacy and modern systems during the shift
- [ ] Automatic rollback threshold is configured and tested before the shift begins
- [ ] Legacy routes are retained (inactive) after full cutover for rollback capability

## Common Failure Modes
| Failure Mode | Symptom | Prevention |
|-------------|---------|------------|
| Session disruption | Users lose session state mid-request during traffic shift; login loops or data loss | Configure Gravitee session affinity before starting any traffic shift |
| One-sided monitoring | Only modern system monitored; legacy system errors during shift not detected | Monitor error rates on both legacy and modern systems simultaneously |
| Rollback threshold too generous | 5% error rate threshold allows significant user impact before triggering rollback | Set rollback threshold based on safety tier: lower for T1 safety-critical apps |
| Legacy routes deleted | Full cutover completed and legacy routes removed; rollback impossible if post-cutover issue found | Retain legacy routes in inactive state for the full parallel run period |

## Handoff Summary
When this skill completes, verify:
1. Traffic is at the target split (or fully shifted to modern)
2. Error rates are within threshold on both systems
3. Session stickiness is working (no mid-session disruptions)
4. Legacy routes are retained for rollback capability
Then proceed to: `parallel-run-monitor` for ongoing comparison, or `legacy-decommission` (P6.3) after parallel run completes
