---
name: ea-compliance
description: >
  Validate architecture designs against FAA Enterprise Architecture (EA), AMS,
  NIST 800-53 Rev 5, FAA Order 1370.121, and Zero Trust requirements. Use when
  designing target architectures (P2.1), reviewing module designs (P4.2), or
  preparing security certification packages (P5.2). Triggers on mentions of
  EA alignment, AMS compliance, NIST controls, or FAA security orders.
agent: sonnet
allowed-tools:
  - Read
  - Write
  - Bash
---

# EA & Compliance Alignment

## Purpose
Ensure every architecture decision and generated artifact aligns with FAA's
enterprise standards. This skill is the gatekeeper — nothing passes through
P2.1's EA Alignment Gate or P4.2's design gate without verification.

## Quick Reference

| Standard | Key Requirement | Verification Method |
|----------|----------------|-------------------|
| FAA EA | Architecture patterns must use approved service catalog | Cross-ref `references/faa-ea-approved-services.md` |
| AMS | Procurement and lifecycle compliance | Check against AMS T3.2 procurement guidance |
| NIST 800-53 Rev 5 | All applicable control families implemented | Map to `references/nist-800-53-control-mapping.md` |
| FAA Order 1370.121 | IT security policy alignment | Validate per `references/faa-1370-121-checklist.md` |
| Zero Trust | Never trust, always verify architecture | Review network segmentation and identity verification |

## Workflow

1. Read the architecture blueprint or module design under review
2. Load the relevant reference file for the standard being checked
3. Run `scripts/check_ea_alignment.py` with the design document path
4. For each finding, classify as BLOCK (must fix) or ADVISORY (recommend fix)
5. Generate the compliance verification report using `assets/ea-compliance-report-template.md`
6. If any BLOCK findings exist, the gate FAILS — document remediation path

## Gotchas

- **FAA EA ≠ generic cloud EA**: FAA has specific approved service catalogs that
  differ from standard AWS/Azure well-architected. Don't assume a pattern that
  works for commercial cloud is FAA-approved.
- **AMS procurement references are mandatory**: Every architecture decision that
  implies a procurement action (new tool, new SaaS) must reference AMS guidance.
  Claude tends to skip this — always check.
- **NIST 800-53 Rev 5 vs Rev 4**: FAA uses Rev 5. Claude sometimes defaults to
  Rev 4 control families. Watch for deprecated controls like AC-2(13).
- **Inherited controls from shared services**: OKTA, CyberArk, Gravitee provide
  inherited controls. Don't re-implement what's already covered — but DO verify
  the inheritance chain is documented.
- **Zero Trust is not just network segmentation**: FAA expects identity-centric
  Zero Trust, not just microsegmentation. Every service-to-service call needs
  authenticated identity, not just network policy.

## Reference Files
- `references/faa-ea-approved-services.md` — FAA-approved cloud services and patterns
- `references/nist-800-53-control-mapping.md` — Control families mapped to pipeline phases
- `references/faa-1370-121-checklist.md` — Order 1370.121 compliance checklist
- `references/zero-trust-architecture-patterns.md` — FAA Zero Trust reference patterns

## Quality Rules
- [ ] Architecture designs reference FAA-approved service catalog, not generic cloud patterns
- [ ] NIST 800-53 Rev 5 (not Rev 4) control families are used for mapping
- [ ] Inherited controls from shared services (OKTA, CyberArk, Gravitee) are documented with inheritance chain
- [ ] Zero Trust verification covers identity-centric authentication for service-to-service calls, not just network segmentation
- [ ] AMS procurement references are included for every architecture decision that implies a procurement action
- [ ] BLOCK findings prevent gate passage — no overrides without documented exception and approver

## Common Failure Modes
| Failure Mode | Symptom | Prevention |
|-------------|---------|------------|
| Generic cloud patterns used | Architecture references standard AWS well-architected but uses services not on FAA approved list | Always cross-reference against `references/faa-ea-approved-services.md` before finalizing |
| Wrong NIST revision | Controls mapped to Rev 4; deprecated controls like AC-2(13) referenced | Verify NIST 800-53 Rev 5 is used; check for deprecated control references |
| Inherited controls re-implemented | Team builds custom identity management instead of using OKTA-inherited controls; wasted effort | Check shared service catalog first; document inheritance chain for covered controls |
| Network-only Zero Trust | Microsegmentation implemented but service-to-service calls lack authenticated identity | Verify every inter-service call has authenticated identity (mTLS, JWT), not just network policy |

## Handoff Summary
When this skill completes, verify:
1. All BLOCK findings are resolved or have documented exceptions
2. NIST 800-53 Rev 5 control mapping is complete for applicable families
3. Inherited controls are documented with provider references
4. Zero Trust includes identity-centric verification
Then proceed to: gate `G-02` for architecture review (P2.1), or gate `G-04b` for design review (P4.2)
