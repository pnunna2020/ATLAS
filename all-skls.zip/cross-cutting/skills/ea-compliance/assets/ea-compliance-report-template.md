# EA Compliance Verification Report

## Application: {{APP_NAME}}
## Pipeline Phase: {{PHASE}} ({{GATE_NAME}})
## Date: {{DATE}}
## Reviewer: {{AGENT_NAME}}

---

## Summary
| Category | Count |
|----------|-------|
| BLOCK findings | {{BLOCK_COUNT}} |
| ADVISORY findings | {{ADVISORY_COUNT}} |
| **Gate Decision** | **{{PASS_FAIL}}** |

## Findings

{{#each FINDINGS}}
### {{SEVERITY}}: {{CATEGORY}}
**Finding:** {{FINDING}}
**Remediation:** {{REMEDIATION}}
**Standard Reference:** {{STANDARD_REF}}
{{/each}}

## Standards Verified
- [ ] FAA Enterprise Architecture catalog
- [ ] NIST 800-53 Rev 5 applicable controls
- [ ] FAA Order 1370.121 requirements
- [ ] Zero Trust architecture alignment
- [ ] AMS procurement compliance (if applicable)

## Sign-off
Architecture Lead: _______________
EA Compliance Validator: _______________
