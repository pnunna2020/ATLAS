# NIST 800-53 Rev 5 → ATLAS Pipeline Mapping

## Access Control (AC)
| Control | Pipeline Phase | Implementation | Inherited? |
|---------|---------------|----------------|-----------|
| AC-1 Policy | P2.1 | Architecture blueprint | Partial (OKTA) |
| AC-2 Account Mgmt | P3.2 | IaC templates | Yes (OKTA) |
| AC-3 Access Enforcement | P4.3 | Generated code | Partial (OKTA + app) |
| AC-6 Least Privilege | P2.1, P3.2 | Role definitions | No — app-specific |
| AC-17 Remote Access | P3.2 | VPN/Zero Trust config | Yes (enterprise) |

## Audit & Accountability (AU)
| Control | Pipeline Phase | Implementation | Inherited? |
|---------|---------------|----------------|-----------|
| AU-2 Event Logging | P4.3 | Generated logging code | No — app-specific |
| AU-3 Content of Audit Records | P4.3 | Log format standards | Partial (Datadog) |
| AU-6 Audit Review | P6.2 | AIOps monitoring | Yes (Datadog) |
| AU-12 Audit Generation | P4.3 | Instrumentation code | No — app-specific |

## Configuration Management (CM)
| Control | Pipeline Phase | Implementation | Inherited? |
|---------|---------------|----------------|-----------|
| CM-2 Baseline Config | P3.2 | IaC templates | No — per-app |
| CM-6 Config Settings | P3.2 | Hardening scripts | Partial (AMI baseline) |
| CM-8 Component Inventory | P0.1 | Tech fingerprint | No — discovery output |

## System & Communications Protection (SC)
| Control | Pipeline Phase | Implementation | Inherited? |
|---------|---------------|----------------|-----------|
| SC-7 Boundary Protection | P2.1 | Network architecture | Partial (VPC baseline) |
| SC-8 Transmission Confidentiality | P4.3 | TLS enforcement | Partial (ALB/Gravitee) |
| SC-12 Key Management | P3.2 | KMS configuration | Yes (AWS KMS) |
| SC-28 Protection at Rest | P4.3 | Encryption config | Partial (S3/RDS default) |

## NOTE: This is a subset. Full mapping covers all 20 control families.
## See NIST SP 800-53 Rev 5 for complete catalog.
