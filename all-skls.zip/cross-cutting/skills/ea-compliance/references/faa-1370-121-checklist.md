# FAA Order 1370.121 Compliance Checklist

## Section 1: Information Security Program
- [ ] Security plan documented and approved
- [ ] Risk assessment completed within last 12 months
- [ ] Security awareness training current for all personnel
- [ ] Incident response plan tested within last 6 months

## Section 2: System Authorization (ATO/cATO)
- [ ] System categorization (FIPS 199) documented
- [ ] Security controls selected and implemented (NIST 800-53 Rev 5)
- [ ] Security assessment completed (SAR)
- [ ] Plan of Action & Milestones (POA&M) current
- [ ] Authorization decision documented (ATO letter or cATO status)

## Section 3: Continuous Monitoring
- [ ] Continuous monitoring strategy documented
- [ ] Automated scanning schedule established
- [ ] Vulnerability remediation within mandated timeframes:
  - Critical: 15 days
  - High: 30 days
  - Medium: 90 days
  - Low: 180 days
- [ ] Monthly security status reports generated

## Section 4: Data Protection
- [ ] Data classification applied to all data stores
- [ ] Encryption at rest (FIPS 140-2/3 validated modules)
- [ ] Encryption in transit (TLS 1.2+ minimum)
- [ ] PII handling procedures documented and enforced
- [ ] Data retention schedule aligned with NARA requirements

## Section 5: Access Control
- [ ] Role-based access control (RBAC) implemented
- [ ] Multi-factor authentication for privileged access
- [ ] Privileged access management (CyberArk) integrated
- [ ] Account review conducted quarterly
- [ ] Separation of duties enforced for critical functions
