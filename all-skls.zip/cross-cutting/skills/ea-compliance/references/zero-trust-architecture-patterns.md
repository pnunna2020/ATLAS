# FAA Zero Trust Architecture Patterns

## Core Principles
1. Never trust, always verify — every request authenticated regardless of network location
2. Least privilege — minimum access for minimum time
3. Assume breach — design as if perimeter is already compromised

## Identity-Centric Patterns (FAA Required)
### Service-to-Service Authentication
- Use OKTA machine-to-machine tokens (OAuth 2.0 client credentials)
- Every Lambda/Fargate service has its own identity
- No shared service accounts across applications
- Token validation at Gravitee gateway AND at service level

### User Authentication
- OKTA SSO with MFA for all user-facing applications
- Session duration: 8 hours max, re-auth for sensitive operations
- Conditional access policies based on device posture and location

## Network Patterns
### Microsegmentation
- Each app gets dedicated VPC or VPC subnet
- Security groups: deny-all default, explicit allow per dependency
- No VPC peering across application boundaries — use Gravitee/EventBridge

### Encryption Everywhere
- TLS 1.2+ for all internal service communication
- mTLS for service-to-service within same trust boundary
- AWS KMS for all encryption keys (FIPS 140-2 Level 2+)
