# FAA EA Approved Services & Patterns

## Compute
- AWS Lambda (GovCloud) — approved for stateless workloads
- AWS Fargate (GovCloud) — approved for containerized services
- EC2 — approved but discouraged for new workloads (use serverless-first)

## Data
- Aurora Serverless PostgreSQL — primary relational target
- DynamoDB — approved for key-value / document workloads
- Redshift — approved for analytics / warehouse
- S3 — approved for object storage (encryption required: SSE-KMS)

## Integration
- Gravitee API Gateway — MANDATORY for all API exposure
- EventBridge — approved for async event routing
- SNS/SQS — approved for message queuing
- Solace PubSub+ — MANDATORY for SWIM integration (DO NOT replace)

## Identity & Security
- OKTA — MANDATORY IdP (do not introduce alternative IdPs)
- CyberArk — MANDATORY for privileged access management
- AWS KMS — MANDATORY for encryption key management (FIPS 140-2 validated)

## Monitoring
- Datadog — primary observability platform
- CloudWatch — supplemental (auto-configured, not primary)

## CI/CD
- GitHub Actions — primary CI/CD (migrating from Jenkins)
- Artifactory — artifact repository (retain)
- SonarQube — code quality scanning (retain)
- Terraform — IaC (retain alongside CDK for new workloads)

## NOT Approved (common mistakes)
- ❌ API Gateway (AWS) — use Gravitee instead
- ❌ Cognito — use OKTA instead
- ❌ HashiCorp Vault — use CyberArk instead
- ❌ Kafka — use EventBridge + SNS/SQS (unless SWIM requires Solace)
- ❌ MongoDB Atlas — use DynamoDB instead
