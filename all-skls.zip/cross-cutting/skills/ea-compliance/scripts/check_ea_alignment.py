#!/usr/bin/env python3
"""
EA Alignment Checker
Reads an architecture document and checks against FAA EA standards.
Usage: python check_ea_alignment.py <architecture_doc_path>

Output: JSON report with findings categorized as BLOCK or ADVISORY.
"""
import sys
import json

BLOCKED_SERVICES = {
    "API Gateway": "Use Gravitee instead of AWS API Gateway",
    "Cognito": "Use OKTA instead of AWS Cognito",
    "HashiCorp Vault": "Use CyberArk instead of HashiCorp Vault",
    "MongoDB": "Use DynamoDB for document workloads",
    "Kafka": "Use EventBridge + SNS/SQS (Solace only for SWIM)",
}

REQUIRED_PATTERNS = [
    ("encryption at rest", "SC-28: All data stores must encrypt at rest with KMS"),
    ("TLS", "SC-8: All communication must use TLS 1.2+"),
    ("OKTA", "AC-2: Identity must integrate with OKTA"),
    ("Gravitee", "API exposure must route through Gravitee"),
]

def check_document(path):
    with open(path, 'r') as f:
        content = f.read().lower()

    findings = []

    for service, reason in BLOCKED_SERVICES.items():
        if service.lower() in content:
            findings.append({
                "severity": "BLOCK",
                "category": "Unapproved Service",
                "finding": f"Document references '{service}'",
                "remediation": reason
            })

    for pattern, requirement in REQUIRED_PATTERNS:
        if pattern.lower() not in content:
            findings.append({
                "severity": "ADVISORY",
                "category": "Missing Standard",
                "finding": f"No mention of '{pattern}'",
                "remediation": requirement
            })

    return {
        "status": "FAIL" if any(f["severity"] == "BLOCK" for f in findings) else "PASS",
        "total_findings": len(findings),
        "blocks": sum(1 for f in findings if f["severity"] == "BLOCK"),
        "advisories": sum(1 for f in findings if f["severity"] == "ADVISORY"),
        "findings": findings
    }

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: python check_ea_alignment.py <doc_path>")
        sys.exit(1)
    result = check_document(sys.argv[1])
    print(json.dumps(result, indent=2))
