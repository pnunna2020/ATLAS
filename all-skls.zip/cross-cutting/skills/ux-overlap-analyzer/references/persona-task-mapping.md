# Persona-Task Mapping Methodology

Cross-app UX overlap starts with getting two apps to agree on who their users are and what jobs those users are doing. This reference is the join rule.

## Persona join
1. Each apps ux-accessibility.json provides a personas[] list with persona_id (app-local), persona_name, and a roles[] array.
2. Canonical persona grouping: collapse across apps where persona_name matches (case-insensitive, trim) AND roles sets share >= 50 percent overlap by role name. Borderline cases (identical name, different roles) record both groups separately and flag in notes.
3. Preserve every per-app persona_id in evidence citations; the canonical persona_id is synthesized by the analyzer (e.g., persona-pilot).
4. roles_count on the output is the union of roles across all contributing per-app personas.

## Task join
1. Tasks come from the tasks[] or journeys[] block of each ux-accessibility.json.
2. Canonical task_id = the shortest human-readable slug that captures the verb-object pair (e.g., submit-airman-certificate). Two tasks merge when both the verb and object normalize to the same tokens.
3. Personas attached to a canonical task = union of per-app personas that perform it.
4. Keep original per-app task identifiers in evidence citations.

## Severity thresholds (for overlap_findings)
| Severity | Trigger |
|---|---|
| blocker | jumps_count >= 3 on a Tier-1 persona, OR friction_score >= 7, OR conflicting-data finding affects >= 1000 annual users |
| major | jumps_count == 2 on a Tier-1 persona, OR friction_score 4-6, OR duplicate-task across >= 3 apps |
| minor | jumps_count == 1, OR friction_score 1-3, OR redundant-ui with clear UX parity |

blocker counts must be auditable; never assign without a documented jumps_count or friction_score, plus a citation into the originating persona-task pair.
