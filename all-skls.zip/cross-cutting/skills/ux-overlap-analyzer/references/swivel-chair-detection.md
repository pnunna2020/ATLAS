# Swivel-Chair Detection

A swivel chair pattern exists when a single user must stop work in one application, jump to another application to fetch or post data, then return - for one conceptual task. This reference pins the detection rule so the analyzer produces repeatable output.

## Signal sources
1. completion_path from the (persona, task, application) map - each step has an app field.
2. journey annotations in per-app ux-accessibility.json that reference external systems or copy-paste steps.
3. The integration-graph.json produced by portfolio-integration-mapper - if it exists - provides ground truth for cross-app flows; cross-reference whenever available.

## Detection rule
For every (persona, task) group whose combined completion_path spans >= 2 distinct application_ids, emit one swivel_chair_pattern with:
- pattern_id: deterministic slug persona_id-task_id
- apps_involved: unique ordered list of application_ids (order = first-appearance in the completion_path)
- jumps_count: number of app transitions in the path (unique app sequence length minus 1)
- friction_score: computed as below, clamped 0..10

## Friction score formula
friction = two times jumps_count plus manual_rekey_count plus role_switch_count plus delay_hours_log

Where
- manual_rekey_count: journey steps annotated copy-paste or re-enter (weight 1)
- role_switch_count: persona must authenticate as a different role during the journey (weight 1)
- delay_hours_log: log1p of median wait time between steps in hours (weight 1)

Clamp to [0,10]. Round to one decimal. Cite the underlying journey steps in evidence.

## What is NOT a swivel chair
- Two apps serving the same persona independently (redundant-ui, not swivel-chair).
- Automated system-to-system hand-offs with no user action.
- Background cron/batch jobs across apps.
- Intra-app modal workflows - swivel chair requires jumps across application boundaries.
