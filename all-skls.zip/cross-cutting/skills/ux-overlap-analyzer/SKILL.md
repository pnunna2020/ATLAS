---
name: ux-overlap-analyzer
description: >
  Produce a wave-scoped cross-application UX overlap matrix. Reads per-app
  ux-accessibility.json artifacts (ART-P0-1) for every app in the wave,
  clusters personas and tasks, flags swivel-chair patterns, identifies
  fragmented journeys, and emits severity-ranked overlap findings.
  Consumed by wave-envelope Rationalization before per-app dispositions run
  so cross-app UX evidence informs single-app decisions. Triggers on
  UX overlap, swivel chair, persona-task duplication, fragmented journey,
  or @ux-overlap-analyzer.
agent: sonnet
allowed-tools:
  - Read
  - Write
  - Grep
---

# ux-overlap-analyzer

## Purpose
Execute the cross-app UX pass in wave-envelope Rationalization (ART-P1-1). Each applications ux-accessibility.json describes personas, tasks, and journeys in isolation; stakeholders cannot see where Pilot or Registrar has to jump between three apps to finish one task until someone joins those artifacts across the portfolio. This skill does that join at the wave boundary and emits two artifacts: ux-overlap-matrix.json (schema-validated evidence for downstream per-app dispositions) and ux-overlap-matrix.md (human-readable summary for wave review).

## Inputs
- Per-app ux-accessibility.json artifacts for every app in the wave, one per application_id. Schema lives at schemas/discovery/ux-accessibility.schema.json (ART-P0-1).
- Wave scope: wave_id plus the list of applications_analyzed (minimum 2 apps per wave).
- Optional: application-catalog-entry.json per app to resolve readable app names for the summary markdown.

## Outputs
- ux-overlap-matrix.json - wave-scoped artifact matching schemas/rationalization/ux-overlap-matrix.schema.json. Required fields: wave_id, analysis_date, applications_analyzed (>=2), personas, tasks, persona_task_app_map, swivel_chair_patterns, fragmented_journeys, overlap_findings, evidence.
- ux-overlap-matrix.md - human-readable packet mirroring the JSON for wave reviewers. Sections: executive summary, persona/task matrix, swivel-chair hotspots, fragmented journeys, severity-ranked findings. See references/persona-task-mapping.md and references/swivel-chair-detection.md for method details.

## Methodology
1. Load every ux-accessibility.json in the wave. Refuse to run if fewer than 2 apps have one - this skill has no output at wave scope of one.
2. Normalize persona descriptors across apps. A registrar in app A and registrar in app B may have different persona_id values but be the same role; collapse by persona_name + role-list match. Record the canonical persona_id and its roles_count.
3. Normalize tasks similarly. Two apps that both expose application intake as a task belong together; record the canonical task_id and its persona coverage.
4. Build persona_task_app_map. For every (persona, task, app) triple where the app exposes that task for that persona, capture the completion_path (ordered steps with step_id/description/app) and compute swivel_chair_count = number of distinct apps the steps touch minus 1.
5. Emit swivel_chair_patterns. For each (persona, task) group whose completion_path spans two or more apps, record the pattern_id, apps_involved (>=2), jumps_count, and friction_score 0-10 per references/swivel-chair-detection.md.
6. Identify fragmented_journeys. A journey is fragmented when the same persona must finish the same task but no single app contains the full completion path and no formal handoff artifact exists. Record affected_user_count sourced from per-app annual_user_count.
7. Derive overlap_findings. For each (persona, task) group where two or more apps provide equivalent UI: classify as duplicate-task, redundant-ui, or conflicting-data; assign severity blocker/major/minor per the thresholds in persona-task-mapping.md.
8. Populate evidence[] with structured citations - one per finding and pattern. Every per-app ux-accessibility.json read must be cited in the format ux-accessibility:{app_id}:{section}.
9. Emit the JSON and the markdown summary. Self-check: applications_analyzed has >=2 entries, every persona in persona_task_app_map exists in personas, every task exists in tasks, every apps_involved entry has >=2 distinct apps.

## Gotchas
- **Missing ux-accessibility.json is not a crash.** If fewer than 2 apps in the wave have an accessible ux-accessibility.json artifact, the wave-runner skips this skill entirely. Never fabricate inputs to clear the >=2 threshold.
- **Persona IDs across apps do not collide.** Two apps may each use persona_id=p-01 meaning totally different people. Always join by name+role-set before trusting the id.
- **Do not infer swivel chair from UI similarity.** Swivel chair requires an explicit persona/task journey that crosses apps. Two apps serving the same persona separately is redundancy, not swivel chair.
- **Every severity must be defensible.** Use the thresholds in references/persona-task-mapping.md - never assign blocker without an evidence citation and a documented jumps_count >= 3 or friction_score >= 7.
- **Keep the markdown summary short.** One page max - deep analysis lives in the JSON. The markdown exists so wave reviewers can decide whether to open the JSON.

## Quality Rules
- [ ] applications_analyzed has >= 2 app_ids and each id has a corresponding ux-accessibility.json in the wave input bundle.
- [ ] Every persona_task_app_map entry cites a step_id present on its apps journey map.
- [ ] swivel_chair_patterns[*].apps_involved has >= 2 distinct application_ids and jumps_count >= 1.
- [ ] overlap_findings[*].severity is blocker only when jumps_count >= 3 or friction_score >= 7 (see persona-task-mapping.md).
- [ ] evidence[] is non-empty and every citation follows the {artifact}:{section}:{finding-id} format.
- [ ] Matrix JSON validates against schemas/rationalization/ux-overlap-matrix.schema.json.
- [ ] Markdown summary exists in the same run folder as the JSON and mirrors its executive content.

## Common Failure Modes
| Failure Mode | Symptom | Prevention |
|---|---|---|
| Persona IDs collide silently across apps | Two distinct people merged into one entry, inflating persona coverage | Join on persona_name+roles before trusting persona_id; preserve per-app originals in evidence citations |
| Swivel chair claimed without a cross-app journey | Wave reviewer cannot trace the jump; finding is rejected | Every swivel_chair_pattern must cite a completion_path with steps on >= 2 distinct apps |
| Markdown produced but JSON skipped | Downstream per-app rationalization has no evidence to cite | Always emit both; the JSON is the contract, the markdown is the summary |
| Severity assigned by gut feel instead of thresholds | Blocker count explodes and gate reviewers lose confidence | Follow persona-task-mapping.md severity thresholds literally; document threshold references in each findings citation |

## Handoff Summary
When this skill completes, verify:
1. Both artifacts exist: ux-overlap-matrix.json and ux-overlap-matrix.md.
2. The JSON validates against the schema and evidence[] is non-empty.
3. Every swivel-chair and overlap finding has at least one {artifact}:{section}:{finding-id} citation.

Then proceed to: per-app Rationalization receives ux-overlap-matrix.json via wave_context so disposition-recommender can cite cross-app UX evidence.
