# Traceability Check Report — `{artifact_id}`

> Output of the traceability-checker skill. Attach to the gate package. Do not hand-edit the
> machine-generated summary section.

## Summary

| Field | Value |
|-------|-------|
| artifact_path | `<path/to/artifact.json>` |
| repo_root | `<path/to/repo>` |
| validated_at | `<ISO-8601 timestamp>` |
| skill_version | `traceability-checker@<version>` |
| tier | `<T1 | T2 | T3>` |
| threshold | `<0.98 | 0.99>` |

## Machine-generated summary (from `scripts/validate_citations.py`)

```json
{
  "total": 0,
  "resolved": 0,
  "failed": []
}
```

## Coverage

| Direction | Covered | Total | Percentage | Meets threshold |
|-----------|---------|-------|------------|-----------------|
| Forward (Spec -> Design -> Code -> Test) | `<N>` | `<M>` | `<P%>` | `<yes/no>` |
| Backward (Code -> Design -> Spec) | `<N>` | `<M>` | `<P%>` | `<yes/no>` |

## Resolved citations

- Count: `<N>`
- Breakdown by kind:
  - Artifact `{artifact}:{section}:{finding-id}`: `<N>`
  - Source `{repo}:{file}:{line}`: `<N>`

## Failed citations

For each failure, fill one row. Cause must be one of: `malformed-regex`, `wrong-case`,
`wrong-section`, `missing-finding-id`, `file-deleted`, `line-out-of-bounds`, `reversed-range`,
`path-escape`, `blank-target`, `wrong-separator`, `trimmed`.

| Citation | Kind | Cause | Where referenced | Suggested remediation |
|----------|------|-------|------------------|-----------------------|
| `<citation-string>` | `<artifact \| source \| unknown>` | `<cause-code>` | `<artifact-path:pointer>` | `<what the author should change>` |

### Failure details

For each failed citation, record:

- **Citation:** `<raw-string>`
- **What it referenced:** `<parsed target — artifact+section+finding-id or repo+file+line>`
- **Why it failed:** `<cause in plain English>`
- **Suggested remediation:** `<specific fix — e.g., "update file path to src/main/java/OrderService.java", "uppercase the finding-id to FND-0042", "line range 99-102 out of bounds; file has 80 lines, confirm intended line and update">`

## Untraced items (the documented gap)

List every item that did not reach 100% traceability with justification. Gate reviewer needs to
assess the gap even when the threshold is met.

| Item | Kind | Justification | Owner |
|------|------|---------------|-------|
| `<spec-id or code-module>` | `<spec-orphan \| code-orphan \| test-orphan>` | `<why untraced>` | `<name>` |

## Gate decision

- **overall_result:** `<PASS | PASS_WITH_WARNINGS | FAIL>`
- **gate_decision:** `<proceed-to-governance | return-to-author | escalate-to-portfolio-manager>`
- **rationale:** `<one sentence tying result to blocker/major/minor counts>`
