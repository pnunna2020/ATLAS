#!/usr/bin/env python3
"""Validate every citation string in an Olympus artifact.

Usage: python validate_citations.py <artifact-path> <repo-root>

Emits JSON summary to stdout. Exit 0 if all citations resolve, 1 otherwise.
Stdlib only. YAML is regex-scanned (no PyYAML dependency).
"""
from __future__ import annotations

import json
import os
import re
import sys

ARTIFACT_RE = re.compile(
    r"^[a-z][a-z0-9-]*(?:\.[a-z0-9-]+)?:[A-Za-z0-9._ /-]+:[A-Z][A-Z0-9-]*$"
)
SOURCE_RE = re.compile(r"^[A-Za-z0-9_.-]+:[A-Za-z0-9_./\\-]+:\d+(?:-\d+)?$")
CITATION_CANDIDATE_RE = re.compile(r"[A-Za-z][A-Za-z0-9_./\\-]*:[^\s:]+:[^\s]+")


def iter_strings(value):
    """Recursively yield every string leaf in a JSON-like tree."""
    if isinstance(value, str):
        yield value
    elif isinstance(value, dict):
        for key, child in value.items():
            if isinstance(key, str):
                yield key
            yield from iter_strings(child)
    elif isinstance(value, (list, tuple)):
        for child in value:
            yield from iter_strings(child)


def load_artifact(path):
    """Load JSON artifacts; fall back to raw text for YAML/Markdown."""
    with open(path, "r", encoding="utf-8-sig") as handle:
        text = handle.read()
    if path.endswith(".json"):
        return json.loads(text)
    return text


def collect_citations(tree):
    """Scan every string in the tree for citation candidates."""
    found = []
    for string_value in iter_strings(tree):
        for match in CITATION_CANDIDATE_RE.findall(string_value):
            found.append(match.strip())
    return found


def classify(citation):
    """Return 'artifact', 'source', or 'malformed-regex'."""
    if ARTIFACT_RE.match(citation):
        return "artifact"
    if SOURCE_RE.match(citation):
        return "source"
    return "malformed-regex"


def resolve_source(citation, repo_root):
    """Resolve a {repo}:{file}:{line} citation. Returns (ok, cause)."""
    parts = citation.split(":", 2)
    if len(parts) != 3 or not all(parts):
        return False, "malformed-regex"
    _, rel_path, line_spec = parts
    rel_path = rel_path.replace("\\", "/")
    range_match = re.fullmatch(r"(\d+)(?:-(\d+))?", line_spec)
    if not range_match:
        return False, "malformed-regex"
    start = int(range_match.group(1))
    end = int(range_match.group(2)) if range_match.group(2) else start
    if start > end:
        return False, "reversed-range"
    candidate = os.path.realpath(os.path.join(repo_root, rel_path))
    root_real = os.path.realpath(repo_root)
    if not candidate.startswith(root_real):
        return False, "path-escape"
    if not os.path.isfile(candidate):
        return False, "file-deleted"
    with open(candidate, "r", encoding="utf-8", errors="replace") as handle:
        line_count = sum(1 for _ in handle)
    if start < 1 or end > line_count:
        return False, "line-out-of-bounds"
    return True, None


def resolve_artifact(citation, artifact_root):
    """Resolve a {artifact}:{section}:{finding-id} citation. Returns (ok, cause)."""
    parts = citation.split(":", 2)
    if len(parts) != 3 or not all(p.strip() for p in parts):
        return False, "malformed-regex"
    artifact_name, section, finding_id = (p.strip() for p in parts)
    candidates = [artifact_name]
    if "." not in artifact_name:
        candidates += [f"{artifact_name}.json", f"{artifact_name}.yaml", f"{artifact_name}.md"]
    resolved_path = None
    for name in candidates:
        target = os.path.join(artifact_root, name)
        if os.path.isfile(target):
            resolved_path = target
            break
    if resolved_path is None:
        return False, "file-deleted"
    with open(resolved_path, "r", encoding="utf-8-sig", errors="replace") as handle:
        body = handle.read()
    if section not in body and section.lower() not in body.lower():
        return False, "wrong-section"
    if finding_id not in body:
        return False, "missing-finding-id"
    return True, None


def validate(artifact_path, repo_root):
    tree = load_artifact(artifact_path)
    citations = collect_citations(tree)
    artifact_root = os.path.dirname(os.path.abspath(artifact_path))
    total = 0
    resolved = 0
    failed = []
    for citation in citations:
        kind = classify(citation)
        if kind == "malformed-regex":
            total += 1
            failed.append({"citation": citation, "cause": "malformed-regex", "kind": "unknown"})
            continue
        total += 1
        if kind == "source":
            ok, cause = resolve_source(citation, repo_root)
        else:
            ok, cause = resolve_artifact(citation, artifact_root)
        if ok:
            resolved += 1
        else:
            failed.append({"citation": citation, "cause": cause, "kind": kind})
    return {"total": total, "resolved": resolved, "failed": failed}


def main(argv):
    if len(argv) != 3:
        sys.stderr.write("usage: validate_citations.py <artifact-path> <repo-root>\n")
        return 2
    summary = validate(argv[1], argv[2])
    sys.stdout.write(json.dumps(summary, indent=2) + "\n")
    return 0 if not summary["failed"] else 1


if __name__ == "__main__":
    sys.exit(main(sys.argv))
