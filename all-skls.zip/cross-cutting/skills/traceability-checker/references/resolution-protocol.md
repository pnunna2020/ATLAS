# Citation Resolution Protocol

Regex parse is not enough. Every citation must resolve. Returns HIT or MISS plus a cause code.

## Artifact — `{artifact}:{section}:{finding-id}`

1. Split on first two colons: `artifact_path`, `section`, `finding_id`. Empty -> `malformed-regex`.
2. `strip()` each part (whitespace, smart quotes).
3. No extension -> try `.json`, `.yaml`, `.md`.
4. Locate via profile artifact index, then repo root. Missing -> `file-deleted`.
5. Load: JSON -> `json.load`; YAML -> `safe_load` or regex-scan; Markdown -> `##`/`###` headings.
6. Navigate to `section`: case-sensitive first, then case-insensitive (emit `wrong-case`). Absent
   -> `wrong-section`.
7. Find `finding_id` in payload (exact in JSON/YAML; grep in MD). Missing -> `missing-finding-id`.
8. HIT with location; MISS with cause.

## Source — `{repo}:{file}:{line}`

1. Split on first two colons: `repo`, `file`, `line_spec`. Empty -> `malformed-regex`.
2. Parse `line_spec`: int -> `start = end`; `N-M` -> `N`,`M`. `N > M` -> `reversed-range`.
3. Normalize `\` -> `/`. `wrong-separator` (warn) if changed.
4. Resolve `os.path.join(repo_root, file)`; named corpora use profile mount point.
5. `realpath`; outside `repo_root` -> `path-escape`.
6. Missing file -> `file-deleted`.
7. `start < 1` or `end > line_count` -> `line-out-of-bounds`.
8. Need >= 1 substantive line. All blank/comment -> `blank-target` (warn).
9. HIT with range; MISS with cause.

## Edge cases

- Trailing whitespace / smart quotes -> `strip()`; emit `trimmed` (warn).
- `entity-overlap.duplicates` is one section — only a colon separates from finding-id.
- Wrong-case app IDs: normalize via manifest (`app-001` -> `APP-001`); emit `wrong-case`.
- Symlinks: `realpath` follow; refuse outside `repo_root`.
- Deleted files: resolve against current working tree.
- UTF-8 BOM: strip at load.
- Case-insensitive FS: emit `wrong-case` when citation case differs from disk.
