# Citation Format Regexes

Two valid citation formats. The validator uses these regexes verbatim.

## 1. Inter-artifact — `{artifact}:{section}:{finding-id}`

- Regex: `^[a-z][a-z0-9-]*(?:\.[a-z0-9-]+)?:[A-Za-z0-9._ /-]+:[A-Z][A-Z0-9-]*$`
- Artifact: lowercase kebab-case, optional `.json`/`.yaml` extension.
- Section: letters, digits, dots, underscores, spaces, slashes, hyphens — never a colon.
- Finding-ID: starts with an uppercase letter, then uppercase alphanumeric with optional hyphens.

### Valid
- `redundancy-matrix:entity-overlap:FND-0042`
- `portfolio-scorecard.json:business_value:APP-001`
- `readiness-score.json:quality-dimension:Q-018`

### Invalid (cause)
- `RedundancyMatrix:...:FND-0042` — not lowercase (`malformed-regex`).
- `...:entity-overlap.duplicates:FND-0042` — use colon, not dot (`wrong-section`).
- `...:entity-overlap:42` — missing uppercase prefix (`missing-finding-id`).
- `redundancy-matrix::FND-0042` — empty section (`malformed-regex`).
- `...:entity-overlap:fnd-0042` — lowercase ID (`wrong-case`).

## 2. Source-code — `{repo}:{file}:{line}`

- Regex: `^[A-Za-z0-9_.-]+:[A-Za-z0-9_./\\-]+:\d+(?:-\d+)?$`
- Repo: corpus/repository identifier.
- File: relative path; normalize `\` to `/` before resolving.
- Line: integer or `start-end` range (`start <= end`).

### Valid
- `cfwheels-corpus:app/controllers/Leave.cfc:214`
- `cfwheels-corpus:app/controllers/Leave.cfc:214-231`
- `monolith-enterprise:src/main/java/OrderService.java:88`

### Invalid (cause)
- `...:Leave.cfc` — no line (`malformed-regex`).
- `...:Leave.cfc:231-214` — reversed (`reversed-range`).
- `...:Leave.cfc:0` — line 0 (`line-out-of-bounds`).
- `...:app\controllers\Leave.cfc:214` — backslash (`wrong-separator`, warn).

## Disambiguation

Digits trailer -> source. Uppercase finding-ID trailer -> artifact. Colon present but neither regex
matches -> `malformed-regex`. Do not guess.
