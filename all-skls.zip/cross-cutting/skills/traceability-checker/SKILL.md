---
name: traceability-checker
description: >
  Verify every finding in Olympus artifacts carries a resolvable citation in one of the two canonical
  formats (`{artifact}:{section}:{finding-id}` or `{repo}:{file}:{line}`) and that forward and backward
  traceability (Spec -> Design -> Code -> Test and back) meet tier thresholds. Used by the
  discovery-readiness-gate (Check 2) and validate-disposition (evidence-traceability-resolution). Triggers
  on traceability check, citation validation, requirements tracing, or traceability matrix validation.
agent: sonnet
allowed-tools:
  - Read
  - Write
  - Bash
  - Grep
---

# Requirements Traceability Verification

## Purpose
Enforce the two citation formats and the bidirectional-traceability thresholds that make Olympus gates
meaningful: >=98% standard, >=99% for T1 safety-critical. Every finding must be resolvable, not just
well-formed. This skill is the shared checker that discovery-readiness-gate and validate-disposition
delegate to.

## Inputs
- Target artifact (JSON, YAML, or Markdown) containing citations.
- Repo root path used to resolve `{repo}:{file}:{line}` references.
- Optional referenced-artifact set (for resolving `{artifact}:{section}:{finding-id}` hits).
- Tier classification of the owning application (drives 98% vs 99% threshold).

## Outputs
- Machine-parseable traceability report (see `assets/traceability-report-template.md`).
- JSON summary from `scripts/validate_citations.py`: `{"total": N, "resolved": M, "failed": [...]}`.
- Per-failed-citation remediation hint (wrong case, wrong section, file deleted, line out of bounds).
- Forward and backward coverage percentages per tier threshold.

## Methodology
1. Load the target artifact and recursively scan every string field for citation substrings.
2. Classify each citation against the two canonical regexes
   (see `references/citation-format-regexes.md`):
   - Artifact form: `^[a-z][a-z0-9-]*(?:\.[a-z0-9-]+)?:[A-Za-z0-9._ /-]+:[A-Z][A-Z0-9-]*$`
   - Source form:   `^[A-Za-z0-9_.-]+:[A-Za-z0-9_./\\-]+:\d+(?:-\d+)?$`
3. Reject unclassified strings that look like citations (contain `:` but match neither regex) as
   malformed — record as `major`.
4. Resolve artifact citations: parse into `artifact_path`, `section`, `finding_id`; open the artifact;
   navigate to the section; confirm the finding-id exists. Details in `references/resolution-protocol.md`.
5. Resolve source citations: parse into `path`, `line_start`, `line_end`; join against repo root
   (normalizing `\` to `/`); confirm file exists and line(s) are in-bounds.
6. For each failure, categorize cause: `wrong-case`, `wrong-section`, `file-deleted`, `line-out-of-bounds`,
   `malformed-regex`, `missing-finding-id`, `reversed-range`.
7. Build forward trace (Spec -> Design -> Code -> Test) and backward trace (Code -> Design -> Spec) over
   the cited evidence graph.
8. Compute coverage percentages and compare to tier threshold. Emit the markdown report and the JSON
   summary.

## Tech-Stack Dispatch
Citation resolution depends on the artifact encoding, not the source language, but path normalization
differs by repo layout:
- JSON artifacts -> parse with `json.load`, walk keys recursively.
- YAML artifacts -> parse with `yaml.safe_load` (fall back to regex scan if PyYAML unavailable — the
  bundled script is stdlib-only and uses regex scan by design).
- Markdown artifacts -> scan backtick-quoted spans and table cells.
- Windows repos -> normalize path separators to `/` before `os.path.join` against repo root.
- Monorepo profiles (FAA) -> resolve artifact citations against the profile's artifact index first,
  then fall back to repo-root search.

## Gotchas
- **Well-formed != resolvable.** A citation can match the regex and still point at a deleted file, a
  missing section, or a blank line. Resolution is mandatory — regex parse alone is not a pass.
- **Section names can contain spaces** but not colons. Trim whitespace before comparing, and do not
  treat `entity-overlap.duplicates` as a section/subsection split.
- **App IDs drift in case** across artifacts. Canonicalize against the portfolio manifest before
  resolving — `app-001` and `APP-001` must be treated as the same after normalization, but the
  finding should be flagged as `wrong-case`.
- **Line ranges can be reversed.** `231-214` is invalid — flag as `reversed-range`, do not silently swap.
- **Traceability is bidirectional.** Forward (every spec has code) AND backward (every code module has
  a spec). Orphan code with no spec is a finding.
- **Test coverage is not traceability.** A module can have 100% test coverage but 0% traceability if
  the tests do not reference requirement IDs.
- **The 1-2% gap must be documented**. 98.5% traceability means the untraced 0.5% has to be listed with
  justification — silent omission fails the gate.

## Quality Rules
- [ ] Every citation uses one of the two canonical formats — no free-text "see X" references.
- [ ] Citations are resolved via `scripts/validate_citations.py`, not visually inspected.
- [ ] Failures are categorized by cause (wrong case, wrong section, file deleted, line out of bounds,
      malformed regex, missing finding-id, reversed range).
- [ ] Traceability is bidirectional: forward (Spec -> Design -> Code -> Test) AND backward
      (Code -> Design -> Spec).
- [ ] Coverage threshold is tier-specific: >=98% standard, >=99% for T1 safety-critical.
- [ ] Untraced items (the 1-2% gap) are explicitly listed with justification — not silently ignored.
- [ ] Orphan code (code with no spec) is flagged as a finding, not just orphan specs (specs with no code).
- [ ] Test traceability verifies tests reference requirements, not just that tests exist.
- [ ] Traceability matrix is machine-parseable for gate automation.
- [ ] The script's exit code is propagated: 0 = all resolved, 1 = one or more failures.

## Common Failure Modes
| Failure Mode | Symptom | Prevention |
|-------------|---------|------------|
| Visual citation review | Reviewer eyeballs citations and misses broken links; gate passes on citations that do not resolve | Run `scripts/validate_citations.py` and require exit 0 before gate approval |
| Forward-only traceability | Every spec maps to code, but orphan code modules exist with no spec; unrequested features ship | Build both forward AND backward traces; flag untraced code as findings |
| Test coverage confused with traceability | Tests exist but do not reference requirements; traceability appears lower than coverage | Verify tests reference requirement IDs, not just that test files exist |
| T1 threshold not enforced | 98% accepted for T1 app instead of required 99%; safety board rejects | Check safety tier before applying threshold; enforce 99% for T1 with no negotiation |
| Unjustified gap | 97.5% traceability reported but the 2.5% gap is not documented; gate reviewer cannot assess | Require explicit listing and justification for every untraced item |
| Wrong-case app IDs silently normalized | `app-001` cited but manifest has `APP-001`; validator silently rewrites and masks an authoring error | Normalize for resolution but still emit a `wrong-case` finding for the author to fix |
| Well-formed but unresolvable citations | Regex parse succeeds, file was deleted in a later commit, validator reports PASS | Resolution is mandatory — every citation must open the target and confirm substantive content |

## References
- `references/citation-format-regexes.md` — canonical regexes for both citation forms with worked
  valid/invalid examples.
- `references/resolution-protocol.md` — step-by-step resolution procedure for each citation type,
  including edge cases (trailing whitespace, section/subsection ambiguity, wrong-case app IDs,
  symlinks, deleted files).

## Assets
- `assets/traceability-report-template.md` — markdown template for the traceability-check report:
  summary stats, resolved count, failed count, and per-failed-citation detail with remediation.

## Scripts
- `scripts/validate_citations.py` — stdlib-only Python 3 validator. Usage:
  `python validate_citations.py <artifact-path> <repo-root>`. Emits the JSON summary to stdout and
  exits 0 when all citations resolve, 1 on any failure.

## Handoff Summary
When this skill completes, verify:
1. Every citation in the target artifact parsed against one of the two regexes and resolved to a real
   target.
2. The bidirectional traceability matrix is complete (forward and backward).
3. Coverage meets the tier-specific threshold (>=98% standard, >=99% T1).
4. Untraced items and citation failures are listed with cause categories and remediation hints.

Then proceed to: `gate-review-package` to include the traceability report in the gate package, and the
specific gate review — `discovery-readiness-gate` (Check 2), `validate-disposition`
(evidence-traceability-resolution), or `G-04a/b/c` for modernization extraction/design/generation.
