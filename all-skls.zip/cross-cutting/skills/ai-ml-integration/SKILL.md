---
name: ai-ml-integration
description: >
  Design AI/ML capabilities into FAA target architectures. Use when planning
  AI/ML integration architecture (P2.1), designing AI/ML data ecosystems (P2.2),
  or implementing AI governance (P7.2). Triggers on AI/ML architecture, model
  governance, machine learning integration, or predictive analytics mentions.
agent: opus
---

# AI/ML Integration Architecture

## Purpose
Embed AI/ML capabilities into the modernized FAA enterprise — not just as the
factory's tool, but as part of the target applications themselves. This addresses
SF3 Eval Bullet 3: "AI/ML integrated into enterprise architecture and data
ecosystem with governance."

## Workflow
1. Identify AI/ML opportunities in the target application
2. Design the AI/ML component architecture using `references/ai-ml-patterns.md`
3. Define data pipeline requirements (training data, inference data, feedback)
4. Specify model governance requirements per `references/model-governance.md`
5. Integrate with the data mesh (data products as ML training sources)
6. Output: AI/ML integration architecture, data ecosystem blueprint

## Gotchas
- **AI in the TARGET, not just AI in the FACTORY**: Evaluators want to see AI
  capabilities deployed into operational FAA systems, not just AI used to build
  them. Both matter, but the target architecture AI is what SF3 scores.
- **Model governance is non-negotiable for FAA**: Every deployed model needs
  explainability, bias monitoring, drift detection, and human-in-the-loop
  override capability. FAA will not accept black-box ML in safety-adjacent systems.
- **GovCloud AI service limitations**: Not all AWS AI services are available in
  GovCloud. Verify service availability before designing against it. SageMaker
  is available; Bedrock availability varies by region.
- **SWIM data for ML**: SWIM (System Wide Information Management) data is a rich
  source for predictive models. But it flows through Solace, not standard APIs.
  Design ML pipelines that can ingest from Solace subscriptions.

## Reference Files
- `references/ai-ml-patterns.md` — AI/ML architecture patterns for FAA
- `references/model-governance.md` — Model governance framework

## Quality Rules
- [ ] AI/ML components are designed for the TARGET application, not just the factory toolchain
- [ ] Every deployed model has documented explainability, bias monitoring, drift detection, and human-in-the-loop override
- [ ] GovCloud AI service availability is verified before designing against specific AWS AI services
- [ ] SWIM/Solace data ingestion pipeline is designed for ML training data sourced from SWIM feeds
- [ ] Data product catalog is referenced for ML training data sources — no ad-hoc data pipelines
- [ ] Model governance requirements reference `references/model-governance.md` standards

## Common Failure Modes
| Failure Mode | Symptom | Prevention |
|-------------|---------|------------|
| Factory-only AI | SF3 evaluation finds AI used in build process but not in target applications; score reduced | Design AI capabilities for operational use in the target architecture, not just factory tooling |
| Black-box model deployed | Model deployed without explainability; FAA safety review rejects it | Require explainability documentation and human override capability for every deployed model |
| GovCloud service unavailable | Architecture designs against Bedrock or Rekognition but service is not available in GovCloud region | Verify service availability in target GovCloud region before finalizing design |
| SWIM data not accessible | ML pipeline designed for SWIM data but cannot ingest from Solace PubSub+; pipeline fails | Design Solace subscription integration early; test connectivity before building training pipelines |

## Handoff Summary
When this skill completes, verify:
1. AI/ML integration architecture targets operational applications (not just factory tooling)
2. Model governance requirements are documented for every deployed model
3. GovCloud service availability is confirmed for all referenced AWS AI services
4. Data ecosystem blueprint connects to existing data mesh products
Then proceed to: `module-design` (P4.2) to incorporate AI/ML components into service architecture, and gate `G-02` for architecture review
