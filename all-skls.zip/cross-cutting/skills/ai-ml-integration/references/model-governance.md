# AI/ML Model Governance Framework

## Model Registry Requirements
Every deployed model must be registered with:
- Model ID, version, owner, purpose
- Training data lineage (which data products used)
- Performance metrics (accuracy, precision, recall, F1)
- Bias assessment results
- Explainability method (SHAP, LIME, feature importance)

## Monitoring Requirements
- Prediction drift detection (data drift + concept drift)
- Performance degradation alerts
- Fairness metrics monitoring
- Usage patterns and anomaly detection

## Human-in-the-Loop Requirements
For FAA operational systems:
- Models ADVISE, humans DECIDE (for all safety-adjacent systems)
- Override capability must be available at all times
- All overrides logged for model improvement feedback loop
- No autonomous action on safety-critical decisions

## Retraining Policy
- Scheduled: Monthly retraining with latest data
- Triggered: When drift exceeds threshold
- Emergency: When model produces demonstrably wrong outputs
- Approval: Model owner + data steward sign-off required
