---
name: event-contract
description: >
  Design event and message contracts for asynchronous integration patterns (EventBridge, SNS/SQS, Solace). Use during P4.2 for event-driven architecture. Triggers on event contract, message contract, async integration, EventBridge schema, or event-driven design.
agent: sonnet
allowed-tools:
  - Read
  - Write
  - Bash
  - Grep
---

# Event Contract

## Purpose
Define the contracts that govern asynchronous communication between modernized services.

## Gotchas
- **Event schemas MUST be versioned**: Use CloudEvents spec or Avro with
  schema registry. Unversioned events break consumers silently.
- **Solace/SWIM events have their own format**: Don't try to force SWIM data
  into EventBridge schema. SWIM events flow through Solace and have
  FAA-defined schemas.
- **Events are not APIs**: Events are fire-and-forget. If the consumer needs
  to respond, use an API, not a reply event.

## Quality Rules
- [ ] All event schemas are versioned using CloudEvents spec or Avro with schema registry
- [ ] SWIM/Solace events use FAA-defined schemas — not forced into EventBridge format
- [ ] Event contracts include: event type, schema version, producer, expected consumers, and retention policy
- [ ] Each event schema includes sample payloads for producer and consumer testing
- [ ] No request-response patterns implemented via events — synchronous needs use APIs
- [ ] Dead-letter queue configuration is defined for every event consumer

## Common Failure Modes
| Failure Mode | Symptom | Prevention |
|-------------|---------|------------|
| Unversioned event schemas | Schema change breaks consumers silently; no way to identify which version a consumer expects | Enforce versioned schemas with schema registry; require version field in every event |
| SWIM events forced into EventBridge | Solace PubSub+ events reformatted to fit EventBridge; data loss or schema mismatch | Keep SWIM events on Solace with FAA-defined schemas; do not reformat for EventBridge |
| Request-response via events | Event producer waits for reply event; creates tight coupling disguised as async | Identify synchronous needs and route them to API contracts, not event contracts |
| Missing dead-letter queue | Failed event processing is silently dropped; data loss not detected until downstream impact | Require DLQ configuration for every event consumer; monitor DLQ depth |

## Handoff Summary
When this skill completes, verify:
1. All event schemas are versioned and registered
2. SWIM/Solace events are handled separately from EventBridge events
3. Dead-letter queues are configured for all consumers
4. Sample payloads exist for testing
Then proceed to: `tdd-generation` (P4.3) for event handler code generation, and gate `G-04b` for design review
