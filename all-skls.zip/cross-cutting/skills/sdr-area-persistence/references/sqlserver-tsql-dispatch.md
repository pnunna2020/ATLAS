# SQL Server T-SQL — Persistence Dispatch Handoff

This is a focused handoff summary for the persistence skill when the detected dialect is SQL Server. For deeper language-level patterns (T-SQL syntax, set-based idioms, index hints), consult `../../extraction/references/sqlserver-tsql-patterns.md`.

## When To Use
Load this reference when one or more of the following are detected during tech-stack detection:

- Connection strings with `Server=...;Database=...` (ADO.NET style) or `jdbc:sqlserver://`
- `sqljdbc*.jar`, `Microsoft.Data.SqlClient`, or `System.Data.SqlClient` references
- Schema objects using T-SQL-only types (`datetime2`, `datetimeoffset`, `uniqueidentifier`, `hierarchyid`, `sql_variant`, `xml`)
- `.sql`, `.dtsx`, `.rdl`, or `.dacpac` files in the repository
- Use of `GETDATE()`, `NEWID()`, `IDENTITY`, `TOP`, `CROSS APPLY`, `OUTPUT` clause
- SQL Agent jobs (`msdb.dbo.sysjobs`), linked servers, or Service Broker activation procedures

## Pattern Categories

### Stored Procedures
- `CREATE PROCEDURE` with input, output, and `OUTPUT` parameters
- Table-valued parameters (TVPs) bound to user-defined table types
- Return codes (`RETURN n`) separate from result sets — often carry status semantics
- `SET NOCOUNT ON` required for predictable row-count behavior from clients
- `SET XACT_ABORT ON` changes rollback behavior on error
- Nested `TRY...CATCH` with `THROW` (2012+) or `RAISERROR` (legacy)
- Temp tables (`#tmp`) vs table variables (`@tmp`) — different statistics and recompile behavior
- Parameter sniffing hazards and `OPTION (RECOMPILE)` or `OPTIMIZE FOR` mitigations

### CLR Procedures and Functions
- Assemblies registered via `CREATE ASSEMBLY` with `PERMISSION_SET` (`SAFE` / `EXTERNAL_ACCESS` / `UNSAFE`)
- CLR triggers, procedures, functions, aggregates, and user-defined types
- `TRUSTWORTHY ON` or certificate-based trust required for non-SAFE assemblies
- CLR integration is deprecated in Azure SQL — flag for migration impact

### SSIS Packages
- `.dtsx` XML packages with control flow, data flow, event handlers
- Package configurations (XML, environment variable, SQL table) and project parameters
- Deployment model: package deployment vs project deployment (SSISDB catalog)
- Custom script tasks and script components (C#/VB.NET) embedded in packages
- Lookup, merge join, conditional split, data conversion transforms

### SSRS Reports
- `.rdl` report definition files with datasets, parameters, and rendering elements
- Shared data sources and shared datasets
- Subscriptions (standard and data-driven) with delivery extensions
- Linked reports and report parts
- Embedded code (VB.NET) in reports

### Change Data Capture (CDC)
- `sys.sp_cdc_enable_db` and `sys.sp_cdc_enable_table` enablement
- `cdc.<schema>_<table>_CT` change tables and `cdc.fn_cdc_get_all_changes_*` functions
- Capture and cleanup jobs as SQL Agent jobs
- LSN-based change tracking — watch for retention gaps

### Service Broker
- `CREATE MESSAGE TYPE`, `CREATE CONTRACT`, `CREATE QUEUE`, `CREATE SERVICE`
- Activation procedures on queues provide durable messaging
- Conversation groups and dialog handles
- Poison message handling via queue state transitions

### Columnstore Indexes
- Clustered (`CCI`) vs nonclustered (`NCCI`) columnstore — very different use cases
- Delta store and rowgroup compression thresholds
- Batch-mode execution for analytic queries
- Not compatible with all index features (watch for included columns, filtered indexes)

### Temporal Tables
- `PERIOD FOR SYSTEM_TIME` with paired history table
- `SYSTEM_VERSIONING = ON` enables automatic history capture
- `FOR SYSTEM_TIME AS OF / BETWEEN / FROM / CONTAINED IN` query forms
- History table retention policies (2017+)

## Anti-Patterns

- **`WITH (NOLOCK)` abuse** — reads dirty, phantom, and duplicated rows; silently corrupts reports. Use snapshot isolation or accept locking.
- **Cursors in OLTP paths** — row-by-row processing when a set-based statement would do; nearly always a performance smell
- **CLR `PERMISSION_SET = UNSAFE`** without security review — full CAS access to the host process
- **Implicit conversions** causing index scans (e.g., `nvarchar` parameter against `varchar` column)
- **Scalar UDFs in WHERE/SELECT** pre-2019 — force row-at-a-time execution; replace with inline TVFs
- **`SELECT *` into temp tables** hiding schema drift
- **Dynamic SQL built by string concatenation** — both an injection risk and a plan-cache killer; use `sp_executesql` with parameters
- **Missing `SET XACT_ABORT ON`** combined with multi-statement transactions — partial commits on error
- **GUID clustered keys** causing page splits — use `NEWSEQUENTIALID()` or a surrogate int/bigint

## Migration Targets (Postgres Equivalents)

| SQL Server Construct | Postgres Equivalent | Notes |
|---|---|---|
| `datetime2`, `datetimeoffset` | `timestamp`, `timestamptz` | Straight mapping; verify timezone semantics |
| `uniqueidentifier` + `NEWID()` | `uuid` + `gen_random_uuid()` | Requires `pgcrypto` extension for default |
| `IDENTITY(1,1)` | `GENERATED AS IDENTITY` or `serial`/`bigserial` | Prefer identity for 10+ |
| `TOP n` | `LIMIT n` | Syntax change only |
| `CROSS APPLY` / `OUTER APPLY` | `LATERAL` join | Semantically equivalent |
| `OUTPUT` clause | `RETURNING` clause | Simpler in Postgres |
| Table-valued parameters | `unnest(array)` or `jsonb` parameter | No direct TVP type; restructure |
| CLR procedures | PL/pgSQL, PL/Python, or external services | Usually requires rewrite |
| SSIS packages | External ETL (Airbyte, dbt, custom Python) | No in-database ETL engine |
| SSRS reports | External BI (Metabase, Superset, PowerBI) | Report layer moves out of DB |
| CDC | Logical replication + Debezium, or `pgaudit` + triggers | Different model — plan stream consumers |
| Service Broker | External broker (Kafka, RabbitMQ, SQS) or `LISTEN`/`NOTIFY` | Durable messaging leaves the DB |
| Columnstore | Citus columnar, or analytic DB (Redshift, BigQuery, Snowflake) | Postgres core has no native columnstore |
| Temporal tables | Trigger-based audit or `pg_temporal` extension | No native system-versioning in core Postgres |
| Linked servers | Foreign Data Wrappers (`postgres_fdw`, `oracle_fdw`) | Direct analog |
| SQL Agent jobs | `pg_cron`, external scheduler, or app-side | Evaluate per job |

## Handoff Notes
- Flag every CLR object for security and migration review — `UNSAFE` assemblies are blockers.
- SSIS and SSRS artifacts should propagate into the integration inventory, not just the persistence inventory.
- CDC and Service Broker usage indicates event-driven integration — escalate to the integration inventory.
- Cross-reference procedures containing business logic with the business rules catalog from `extraction`.
