# Temporal Table Patterns

Temporal tables preserve a complete row-level history of every change to a
base table, so queries can answer "what did this record look like on
2024-06-01?" without application-level audit code. They are essential for
regulatory reporting, point-in-time reconciliation, and as an alternative
to hand-rolled audit triggers during modernization.

Use this reference when the persistence inventory surfaces audit/history
requirements — especially when the legacy system maintains ad-hoc
`*_HISTORY` or `*_AUDIT` tables that are brittle, under-indexed, or
incomplete.

## SQL Server 2016+ — System-Versioned Temporal Tables

SQL Server has first-class support. A **system-versioned** table keeps the
current row in the base table and every prior version in a paired history
table. The engine maintains `SysStartTime`/`SysEndTime` in `datetime2`.

```sql
CREATE TABLE dbo.Employee (
    EmployeeID   INT PRIMARY KEY,
    Name         NVARCHAR(100) NOT NULL,
    Salary       DECIMAL(12,2) NOT NULL,
    ValidFrom    DATETIME2 GENERATED ALWAYS AS ROW START NOT NULL,
    ValidTo      DATETIME2 GENERATED ALWAYS AS ROW END   NOT NULL,
    PERIOD FOR SYSTEM_TIME (ValidFrom, ValidTo)
)
WITH (SYSTEM_VERSIONING = ON (HISTORY_TABLE = dbo.EmployeeHistory));
```

Query history with `FOR SYSTEM_TIME`:

```sql
SELECT * FROM dbo.Employee FOR SYSTEM_TIME AS OF '2024-06-01T00:00:00';
SELECT * FROM dbo.Employee FOR SYSTEM_TIME BETWEEN @t1 AND @t2;
```

Key operational notes:

- History table is an ordinary clustered table — index it for the queries
  you actually run (typically by PK + ValidFrom).
- Retention can be enforced with `HISTORY_RETENTION_PERIOD = N DAYS` and the
  background cleanup task.
- Cannot `TRUNCATE` or bulk-modify the history table while versioning is on;
  must `ALTER TABLE ... SET (SYSTEM_VERSIONING = OFF)` first.
- Schema changes to the current table propagate to the history table — some
  changes require versioning off.

Docs: Microsoft Learn — "Temporal tables", "Creating a system-versioned
temporal table", "Manage retention of historical data".

## PostgreSQL — Extensions and Manual Patterns

Postgres does not ship SQL:2011 temporal tables in core. Options:

**`temporal_tables` extension** (by Vlad Arkhipov) — provides a
`versioning()` trigger function that writes superseded rows to a paired
history table with `sys_period tstzrange` columns. Install the extension,
declare the history table, attach the trigger.

```sql
CREATE EXTENSION temporal_tables;
CREATE TABLE employee (
    id         int PRIMARY KEY,
    name       text,
    salary     numeric,
    sys_period tstzrange NOT NULL
);
CREATE TABLE employee_history (LIKE employee);
CREATE TRIGGER versioning_trigger
BEFORE INSERT OR UPDATE OR DELETE ON employee
FOR EACH ROW EXECUTE PROCEDURE versioning(
    'sys_period', 'employee_history', true);
```

**Application-level bitemporal** — maintain `valid_from`, `valid_to`, and a
separate `txn_from`, `txn_to` in the base table, with `tstzrange` exclusion
constraints. More code, but no extension dependency and supports both
system time and business time.

**Audit-table alternative** — a generic `audit_log(table_name, row_pk,
operation, changed_at, old_row jsonb, new_row jsonb)` populated by a single
`AFTER` trigger. Cheap to implement across dozens of tables, but
reconstructing point-in-time state is query-expensive.

Docs: PostgreSQL docs — "CREATE TRIGGER", "Range Types"; `temporal_tables`
README on GitHub.

## Choosing A Pattern

| Pattern | Use when | Avoid when |
|---|---|---|
| SQL Server system-versioned | Target is SQL Server 2016+ and the audit needs are row-level history only | Business time (effective dates) matters — use bitemporal instead |
| Postgres `temporal_tables` ext | PG ≥ 11 and ops can install extensions | Managed PG forbids the extension (verify provider catalog) |
| Bitemporal application columns | Need both txn time and business-effective dates (insurance policies, rates) | A simple audit trail is enough — overkill |
| Generic JSONB audit log | Cross-cutting audit across 50+ tables with low query volume | Hot-path point-in-time queries over wide tables |

## What To Record In The Inventory

- For every table with existing `*_HIST`/`*_AUDIT` pair: the mechanism
  (trigger, app code, CDC sink), gaps, and query access patterns.
- Whether regulators or SLAs require **system time** (when the row was
  recorded) or **business time** (when the fact was effective) or both.
- Retention requirement in days/years and whether history tables have
  compliant backup coverage.
- Any queries in the application today that join the base table to its
  history — these become `FOR SYSTEM_TIME` queries in the target.
