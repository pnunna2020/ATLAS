# Partitioning Patterns

Partitioning splits a logically single table into multiple physical segments
so that the query planner, storage engine, and maintenance operations
(`VACUUM`, index rebuild, archive/drop) can operate on one slice at a time.
For large tables migrated out of a legacy system, partitioning is often the
difference between a workable target schema and an unworkable one.

Use this reference when the persistence inventory surfaces tables with
hundreds of millions of rows, aggressive archival requirements, or
multi-tenant isolation needs.

## Partitioning Strategies

### Range Partitioning (by date)

The most common choice. Rows are placed by a monotonic column — typically
`created_at`, `event_date`, or `fiscal_year`. Old partitions are cheap to
drop; query predicates on the partition key prune the scan.

Fits: event stores, audit logs, time-series telemetry, history tables.

```sql
-- PostgreSQL declarative
CREATE TABLE events (
    id         bigserial,
    event_date date NOT NULL,
    payload    jsonb
) PARTITION BY RANGE (event_date);

CREATE TABLE events_2025_q1 PARTITION OF events
    FOR VALUES FROM ('2025-01-01') TO ('2025-04-01');
CREATE TABLE events_2025_q2 PARTITION OF events
    FOR VALUES FROM ('2025-04-01') TO ('2025-07-01');
```

Pitfall: missing a future partition causes insert errors. Use a tool like
`pg_partman` (PostgreSQL) or a SQL Agent job (SQL Server) to pre-create
partitions ahead of the current date.

### Hash Partitioning (by tenant or id)

Distributes rows evenly by hashing a column, usually to balance write load
across partitions or to cap the row count per partition. Fits multi-tenant
SaaS where tenants are numerous and roughly equal in size.

```sql
CREATE TABLE tenant_events (
    tenant_id uuid NOT NULL,
    event_id  bigserial,
    payload   jsonb
) PARTITION BY HASH (tenant_id);

CREATE TABLE tenant_events_p0 PARTITION OF tenant_events
    FOR VALUES WITH (MODULUS 8, REMAINDER 0);
-- ... 7 more partitions
```

Pitfall: cannot drop a whole tenant by partition (hash assignment is
opaque). Use list partitioning if per-tenant drop/rotate is required.

### List Partitioning

Rows are placed by discrete values — region code, tenant id (small fixed
set), status. Fits regulated data with residency constraints ("EU tenants
must live on the EU filegroup").

```sql
CREATE TABLE customers (
    id          bigserial,
    region_code char(2) NOT NULL,
    ...
) PARTITION BY LIST (region_code);

CREATE TABLE customers_us PARTITION OF customers FOR VALUES IN ('US');
CREATE TABLE customers_eu PARTITION OF customers FOR VALUES IN ('DE','FR','NL','IE');
```

### Composite / Subpartitioning

Range-then-hash (PG supports this by `PARTITION BY RANGE (date)` at the
parent, then each partition itself `PARTITION BY HASH (tenant_id)`) — used
when a single date partition still has too many rows for efficient access.

## PostgreSQL Declarative Partitioning

Postgres 10 introduced native declarative partitioning; Postgres 11+ added
hash, default partitions, PK/FK on partition key, and global UNIQUE via
partition key inclusion. Key operational notes:

- Query `pg_partitioned_table` and `pg_inherits` to catalog the layout.
- `ATTACH PARTITION ... USING INDEX` attaches a pre-built table with a
  matching index, avoiding a full rebuild during migration.
- `DETACH PARTITION CONCURRENTLY` (PG 14+) removes a partition without a
  long access-exclusive lock.
- Foreign keys referencing a partitioned table are supported (PG 12+).
- Triggers must be defined on each partition (or use `FOR EACH ROW` at the
  parent in PG 13+).
- `pg_partman` automates partition creation/retention and is the de facto
  standard in production.

Docs: PostgreSQL docs — "5.11. Table Partitioning", "ALTER TABLE" (partition
operations).

## SQL Server — Filegroup-Based Partitioning

SQL Server partitioning is expressed as **partition function** + **partition
scheme** + the filegroups the scheme targets.

```sql
CREATE PARTITION FUNCTION pf_event_date (date)
    AS RANGE RIGHT FOR VALUES ('2025-01-01','2025-04-01','2025-07-01');
CREATE PARTITION SCHEME ps_event_date
    AS PARTITION pf_event_date TO (fg_archive, fg_2025q1, fg_2025q2, fg_2025q3);
CREATE TABLE dbo.Events (...)
    ON ps_event_date (event_date);
```

Maintenance idioms:

- **Sliding window** — `SPLIT RANGE` to add a future partition, `MERGE
  RANGE` to collapse an old one, `SWITCH PARTITION` to move an aged-out
  partition into an archive table in milliseconds (metadata-only).
- Align partitions with **clustered index** on the partition column for
  best scan pruning; misaligned indexes become per-partition local
  indexes automatically.
- `PARTITION BY` with columnstore indexes enables partition-level load +
  `ALTER INDEX ... REBUILD PARTITION = N` without touching the rest.

Docs: Microsoft Learn — "Partitioned tables and indexes", "Create
partitioned tables and indexes", "sys.partition_functions" /
"sys.partition_schemes".

## Local vs Global Indexes

- **Local (partitioned/aligned) index** — one physical index per partition,
  keyed the same way as the table. Fast partition switch/drop, but unique
  enforcement is only per-partition unless the partition key is included in
  the key.
- **Global (non-aligned) index** — a single index spanning all partitions.
  Supports cross-partition unique constraints but blocks fast partition
  switch (must be rebuilt or dropped).

In Postgres, indexes on partitioned parents are automatically local unless
the constraint includes the partition key. In SQL Server, specifying `ON
<partition_scheme>` makes the index aligned (local); `ON [PRIMARY]` makes
it global.

Rule of thumb: prefer aligned/local indexes and include the partition key
in every unique constraint; fall back to global only when the business
rule forces it.

## What To Record In The Inventory

For every candidate or existing partitioned table:

- Partition strategy (range/hash/list/composite) and partition key column(s).
- Partition count, row count per partition (min/median/max), and size.
- Retention policy (how old partitions are archived or dropped).
- Whether indexes are local or global; list any unique constraints.
- Foreign keys in/out of the table and whether they cross partitions.
- Maintenance automation in use (`pg_partman`, SQL Agent jobs, hand scripts)
  and whether next-partition creation is guaranteed.

## Common Pitfalls

- **Forgetting the next partition** → insert failures at midnight on the
  rollover date. Automate ahead-of-time creation.
- **Partition key not in unique constraint** → PG/SQL Server reject the
  constraint or silently weaken uniqueness to per-partition.
- **Query planner can't prune** → predicates use a function on the
  partition key (`WHERE date_trunc('month', event_date) = ...`) or an
  OR-of-ranges. Rewrite predicates to use the raw column.
- **Over-partitioning** → thousands of tiny partitions inflate planning
  time and catalog size. Target partitions in the 10M–100M row range for
  OLTP, larger for analytics.
