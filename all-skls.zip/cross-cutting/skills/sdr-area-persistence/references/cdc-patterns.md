# Change Data Capture (CDC) Patterns

CDC captures row-level INSERT/UPDATE/DELETE events from a source database and
streams them to downstream consumers. During modernization, CDC is the primary
mechanism for running a **live shadow** — the modernized application reads
the same data as the legacy app in near real-time — so that cutover becomes a
routing decision rather than a data migration event.

Use this reference when the persistence inventory surfaces databases that must
remain in sync with a replacement target (new microservice schema, data
warehouse, cloud-native store) for weeks or months during phased cutover.

## When To Use CDC For Migration

- **Parallel run / shadow reads** — modernized app serves read traffic from a
  replica populated by CDC while legacy still owns writes. Compare outputs.
- **Strangler-fig cutover** — individual bounded contexts move to the new
  system one at a time; CDC keeps legacy tables hydrated from the new writes
  (and vice versa) until the old table is retired.
- **Zero-downtime schema evolution** — dual-write via CDC into a reshaped
  target schema, flip reads, then flip writes.
- **Read-replica off-load** — extract reporting workloads off a legacy OLTP
  system without touching application code.

Avoid CDC when a one-shot ETL is cheaper (small table, retired application)
or when the source has no transaction log access (file-based systems,
application-only audit trails).

## SQL Server — CDC and Change Tracking

SQL Server ships two distinct features that are frequently confused.

**CDC (`sys.sp_cdc_enable_db`, `sys.sp_cdc_enable_table`)** reads the
transaction log via the SQL Server Agent and persists row-level before/after
images into `cdc.<schema>_<table>_CT` tables. Consumers poll those change
tables by LSN.

- Requires SQL Server Agent running (Standard+ edition).
- Capture instance name, supported columns, and filegroup must be decided at
  enable time — changing them requires disable+re-enable.
- Retention defaults to 3 days via `sys.sp_cdc_change_job`.
- `sys.fn_cdc_get_all_changes_<capture>` / `sys.fn_cdc_get_net_changes_<capture>`
  are the standard query functions.

**Change Tracking (`ALTER DATABASE ... SET CHANGE_TRACKING = ON`)** is a
lighter-weight mechanism that records only the PK and change type (I/U/D) for
each modified row — no before/after image. Cheaper, but forces consumers to
re-query the base table for current values.

Docs: Microsoft Learn — "About Change Data Capture (SQL Server)",
"Enable and disable change data capture (SQL Server)", "About change tracking
(SQL Server)".

## PostgreSQL — Logical Replication and Debezium

Postgres exposes changes through **logical decoding** on the write-ahead log.
A replication slot plus an output plugin (`pgoutput` built-in, or `wal2json`)
streams INSERT/UPDATE/DELETE as logical messages.

- `wal_level = logical` in `postgresql.conf`.
- `max_replication_slots` and `max_wal_senders` sized for concurrent
  consumers (each slot pins WAL until consumed — unconsumed slots will fill
  the disk).
- `CREATE PUBLICATION pub_core FOR TABLE orders, order_lines;` then
  `CREATE SUBSCRIPTION ... WITH (copy_data = true)` for native PG-to-PG.
- For heterogeneous targets (Kafka, target DB of any type), **Debezium** runs
  as a Kafka Connect connector that attaches to the replication slot and
  publishes canonical change events. Debezium handles schema history,
  snapshot-then-stream, and heartbeat messages.

Docs: PostgreSQL docs — "Chapter 49. Logical Decoding",
"Chapter 31. Logical Replication"; Debezium docs — "Debezium connector for
PostgreSQL".

## Oracle — GoldenGate (and LogMiner for low-volume cases)

Oracle GoldenGate is the enterprise-grade CDC platform for Oracle sources. An
**Extract** process mines the redo log, writes platform-neutral trail files,
and a **Replicat** process applies them to the target (Oracle, Kafka,
PostgreSQL, BigQuery, etc.).

- Supply the source schema to `ADD SCHEMATRANDATA` so GoldenGate captures
  enough information to reconstruct rows.
- Integrated Extract (database-aware) is preferred over Classic Extract on
  modern Oracle versions.
- GoldenGate for Big Data ships events to Kafka/Kinesis; GoldenGate for
  PostgreSQL replicates into a PG target.
- For light workloads, `DBMS_LOGMNR` plus a bespoke poller may suffice, but
  it lacks trail durability, conflict detection, and parallel apply.

Docs: Oracle — "Oracle GoldenGate 21c Documentation" (Using Oracle
GoldenGate for Oracle Database, Administering Oracle GoldenGate).

## CDC In The Persistence Inventory

For every table flagged for CDC-based migration, capture:

- Source dialect and CDC mechanism chosen (and why the lighter option was
  rejected, if applicable).
- Primary key / unique-key availability — CDC targets without PKs require
  either synthetic keys or full-row comparison.
- Expected change volume (rows/sec peak) — drives slot/channel sizing.
- Retention window required on the source (how long consumers may fall
  behind before data is lost).
- Consumer(s) and their tolerance for out-of-order or duplicate events
  (at-least-once vs exactly-once).
- Conflict-resolution policy if the target also accepts writes (last-writer-wins,
  source-wins, application-level merge).

## Common Pitfalls

- **Unconsumed replication slots fill the disk.** Monitor slot lag and
  alarm before WAL retention exhausts.
- **Schema changes break naive consumers.** Debezium emits schema change
  events; downstream jobs must handle them or be versioned.
- **Large transactions delay event visibility.** CDC emits on commit, so a
  10M-row batch appears as one burst after it commits, not incrementally.
- **Initial snapshot must be consistent with the stream start position.**
  Most tools handle this (snapshot then switch to log tail) but custom
  pollers often get it wrong and duplicate or drop rows at the boundary.
