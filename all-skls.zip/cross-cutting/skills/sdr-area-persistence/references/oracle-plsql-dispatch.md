# Oracle PL/SQL — Persistence Dispatch Handoff

This is a focused handoff summary for the persistence skill when the detected dialect is Oracle. For deeper language-level patterns (PL/SQL syntax, advanced control flow, bulk processing idioms), consult `../../extraction/references/oracle-plsql-advanced-patterns.md`.

## When To Use
Load this reference when one or more of the following are detected during tech-stack detection:

- `tnsnames.ora`, `listener.ora`, or Oracle JDBC driver (`ojdbc*.jar`) present
- Connection strings with `jdbc:oracle:thin:`, `Data Source=ORCL`, or `@//host:port/SID`
- Schema objects with Oracle-only types (`NUMBER`, `VARCHAR2`, `CLOB`, `NCLOB`, `RAW`, `ROWID`)
- `.sql` or `.pks`/`.pkb` files containing `CREATE OR REPLACE PACKAGE`, `DBMS_*` calls
- Use of `DUAL`, `ROWNUM`, `SYS_GUID()`, `SYSDATE`, or Oracle hint syntax (`/*+ ... */`)

## Pattern Categories

### Packages and Package Bodies
- `CREATE OR REPLACE PACKAGE` / `PACKAGE BODY` with separate spec and implementation
- Package-level variables persist for the session and are a common hidden-state trap
- Package initialization blocks run once per session — document what they do
- Public vs private procedures/functions — only spec entries are callable externally
- Overloaded procedures and functions by parameter signature
- Package constants and types (record, table, ref cursor)
- Forward declarations inside package bodies
- `PRAGMA SERIALLY_REUSABLE` and `PRAGMA AUTONOMOUS_TRANSACTION` modify runtime semantics

### Triggers
- BEFORE / AFTER / INSTEAD OF with FOR EACH ROW or statement-level firing
- Compound triggers combining multiple timing points into one object
- System triggers (DDL, LOGON, LOGOFF, SERVERERROR) execute outside DML paths
- `:NEW` and `:OLD` row references in row-level triggers
- `WHEN` clause filtering and `UPDATE OF column` restrictions
- Mutating table errors from row-level triggers reading the changing table
- Ordering dependencies via `FOLLOWS` and `PRECEDES`

### Cursors and BULK COLLECT
- Explicit cursors with `OPEN` / `FETCH` / `CLOSE` lifecycle
- Implicit cursors from `SELECT INTO` and cursor FOR loops
- Ref cursors (`SYS_REFCURSOR`) passed between procedures or returned to clients
- BULK COLLECT with `LIMIT` for bounded-memory batch processing
- FORALL for set-based DML bound to BULK COLLECT arrays
- `SAVE EXCEPTIONS` to continue through per-row errors in FORALL
- `%ROWTYPE` and `%TYPE` anchored declarations

### Advanced Queue (AQ)
- `DBMS_AQADM` for queue and queue-table management
- `DBMS_AQ.ENQUEUE` / `DEQUEUE` for message publishing and consumption
- Multi-consumer queues, notification listeners, propagation schedules
- AQ-based workflows are durable messaging — treat as integration, not just storage

### Materialized Views
- `BUILD IMMEDIATE` vs `BUILD DEFERRED`
- `REFRESH COMPLETE` / `FAST` / `FORCE` with `ON COMMIT` or `ON DEMAND`
- Materialized view logs (`MLOG$_*`) required for fast refresh
- Query rewrite flag — queries may silently be redirected to the MV

### Sequences
- `CREATE SEQUENCE` with `START WITH`, `INCREMENT BY`, `CACHE`, `NOCACHE`, `CYCLE`
- `NEXTVAL` vs `CURRVAL` semantics per session
- 12c+ identity columns as a sequence alternative
- Gaps from cached-but-unused values are expected and not a bug

### DBMS_SCHEDULER
- Programs, schedules, jobs, job classes, windows, and chains
- Replaces older `DBMS_JOB` — both may coexist in legacy systems
- Job arguments, credentials, and destinations for remote execution
- Event-based and calendar-string scheduling expressions

## Anti-Patterns

- **Implicit `COMMIT` in triggers** — triggers should never commit; autonomous transactions hide this smell
- **`WHEN OTHERS THEN NULL`** — swallows all errors and is never acceptable without re-raise or logged handling
- **Cursor leaks** from early `RETURN` paths that skip `CLOSE`
- **Unbounded loops over `SELECT`** without BULK COLLECT `LIMIT` — blows up PGA on large tables
- **Using `ROWNUM` without a subquery for pagination** — `ROWNUM` is assigned before `ORDER BY`
- **Rollback segment (RBS) / UNDO contention** from giant single-statement updates — chunk with FORALL + LIMIT
- **Autonomous transactions for logging that then fail silently** — exceptions in autonomous blocks must be captured
- **Package-level mutable state** used as a cache — corrupts correctness under session reuse (especially with connection pools)

## Migration Targets (Postgres Equivalents)

| Oracle Construct | Postgres Equivalent | Notes |
|---|---|---|
| Package (spec + body) | Schema + set of functions, or extension | Postgres has no first-class package — use schema conventions |
| Package-level variables | `CREATE TEMP TABLE` on connect, or GUCs | Must re-architect — no direct equivalent |
| `NUMBER`, `NUMBER(p,s)` | `numeric(p,s)` or `bigint` / `integer` where precision allows | Prefer native integer types when scale = 0 |
| `VARCHAR2(n)` | `varchar(n)` or `text` | Postgres `text` has no length penalty |
| `DATE` (with time) | `timestamp` | Oracle DATE includes time; Postgres DATE does not |
| `DUAL` | Omit — `SELECT 1;` works directly | Postgres needs no dummy table |
| `ROWNUM`-based pagination | `LIMIT` / `OFFSET` or keyset pagination | Keyset preferred for large offsets |
| `CONNECT BY` hierarchies | Recursive CTE (`WITH RECURSIVE`) | Rewrite required |
| `MERGE` | `INSERT ... ON CONFLICT ... DO UPDATE` | Postgres 15+ also has native `MERGE` |
| `DBMS_SCHEDULER` jobs | `pg_cron`, external scheduler, or application-side | Evaluate per job |
| Advanced Queue | External broker (Kafka, RabbitMQ, SQS) or `LISTEN`/`NOTIFY` | Rarely a direct Postgres feature match |
| Materialized views with fast refresh | `CREATE MATERIALIZED VIEW` + `REFRESH CONCURRENTLY` | No automatic fast-refresh — schedule explicitly |
| Sequences | Sequences (compatible) or `GENERATED AS IDENTITY` | Near-1:1 mapping |
| Triggers | Triggers (compatible), but prefer constraints or app logic | Reassess each trigger for necessity |

## Handoff Notes
- Flag every BEFORE/INSTEAD OF trigger for migration review — these are the highest-risk objects to port.
- Cross-reference package-level business logic with the business rules catalog from `extraction`.
- Treat AQ usage as an integration artifact, not a schema artifact — propagate into the integration inventory.
