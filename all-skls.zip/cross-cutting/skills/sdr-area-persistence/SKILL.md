---
name: sdr-area-persistence
description: >
  Map the complete data layer: schemas, stored procedures, views, triggers, ORM
  mappings, raw SQL queries, connection management, transaction boundaries. Use
  during Discovery (D1.3 Pass 3). Triggers on database analysis, schema mapping,
  stored procedure extraction, data layer discovery.
agent: opus
allowed-tools:
  - Read
  - Grep
  - Bash
---

# Structured Discovery Report — Persistence Area

## Purpose
Map every aspect of the application's data layer: database schemas, stored
procedures, views, triggers, materialized views, ORM mappings, raw SQL queries
embedded in application code, connection management, transaction boundaries,
and shared database patterns where multiple applications access the same tables.

The persistence inventory produced here is essential for three downstream
consumers: srs-from-discovery (data requirements), the Architecture line
(database migration strategy), and the Data assembly line (data domain
decomposition). An incomplete persistence inventory means data loss, broken
integrations, or corrupted state in the modernized system.

## Inputs
- Source code repository (local path from config)
- Database connection information (from config, for live schema extraction)
- Interface inventory (from sdr-area-interface — traces endpoints to data access)
- Business rules catalog (from extraction — identifies logic in stored procs)
- Tech-stack detection results

## Outputs
- Complete persistence inventory (assets/persistence-inventory-template.yaml)
- Schema inventory (tables, columns, types, constraints, indexes)
- Stored procedure inventory with business logic classification
- Data access trace (every query mapped to application source with file:line)
- Transaction boundary map
- Shared database pattern documentation

## Methodology

### Step 1 — Detect Database Type and Access Patterns
Identify all databases the application connects to and how it accesses them:
- Scan connection strings, JNDI lookups, data source configurations
- Identify ORM framework (Hibernate, Entity Framework, ActiveRecord, Eloquent)
- Detect raw SQL patterns (JDBC, ADO.NET, PDO, cfquery)
- Check for stored procedure calls (CallableStatement, EXEC, cfprocparam)
- Identify multiple database connections (read replicas, reporting databases)

Classify access patterns for each database:
- ORM-only: All access through object-relational mapper
- Mixed: ORM for CRUD, raw SQL for complex queries, stored procs for batch
- SQL-direct: All access through raw SQL strings in application code
- Stored-proc-heavy: Majority of logic in database procedures

### Step 2 — Extract Schema Inventory
For each database, catalog all schema objects:
- **Tables**: Name, columns (name, type, nullable, default), primary key,
  foreign keys, unique constraints, check constraints
- **Indexes**: Name, columns, type (B-tree, hash, full-text, spatial), unique
- **Views**: Name, underlying query, materialized vs regular
- **Sequences**: Name, current value, increment, used-by references
- **User-defined types**: Name, definition, usage locations

If live database access is available, extract schema from information_schema
or database-specific system catalogs. If not, reconstruct from ORM mappings,
migration files, DDL scripts, and SQL files in the repository.

### Step 3 — Map Stored Procedure Inventory
For each stored procedure, function, and trigger:
- Name, parameter signature, return type
- Business logic classification: Does it contain business rules (not just CRUD)?
- Complexity indicator: Lines of code, branching depth, table count
- Called-by: Which application code calls this procedure (file:line)
- Calls: Which other procedures or functions does it call
- Tables accessed: Read vs write for each table

**Business logic classification is critical.** A stored procedure that only
performs INSERT/UPDATE/DELETE is a data access helper. A stored procedure that
calculates pricing, enforces business rules, or manages state transitions
contains business logic that must be extracted into the business rules catalog.

### Step 4 — Trace Data Access from Application Code
For every SQL query, ORM call, or stored procedure invocation in the application:
- Source file and line number
- SQL statement or ORM method call
- Tables and columns accessed
- Read vs write classification
- Whether inside a transaction boundary
- Parameterized vs string-concatenated (security flag)

Build a complete map: application function -> SQL/ORM call -> tables affected.
This trace enables the Architecture line to assess database coupling and the
Modernization line to know exactly what data each module needs.

### Step 5 — Identify Transaction Boundaries
For each transaction in the application:
- Start point (file:line where transaction begins)
- End point (file:line where commit/rollback occurs)
- Tables modified within the transaction
- Isolation level (if explicitly set)
- Nested transaction patterns
- Distributed transaction patterns (XA, two-phase commit)
- Implicit transactions (auto-commit mode, framework-managed)

Document cases where transaction boundaries are missing for multi-table
operations — these are data integrity risks.

### Step 6 — Document Shared Database Patterns
Identify cases where the database is accessed by multiple applications:
- Other applications with connections to the same database
- Shared tables (multiple apps read/write the same tables)
- Database links or synonyms pointing to other schemas
- Cross-schema queries
- ETL jobs that read from or write to the application's tables

Shared database patterns are critical for migration planning. A table shared
by 5 applications cannot be migrated until all 5 are addressed.

## Tech-Stack Dispatch
Load database-specific analysis patterns based on detected database:
- Oracle (PL/SQL, DBMS_SCHEDULER, materialized views) -> load the `extraction` skill's Oracle PL/SQL advanced patterns
- SQL Server (T-SQL, SQL Agent, linked servers) -> load the `extraction` skill's SQL Server T-SQL patterns
- PostgreSQL (PL/pgSQL, extensions, partitioning) -> handled by the target-data-modeling guidance in the `data-modeling` skill
- MySQL/MariaDB (stored routines, events, partitioning) -> handled by the target-data-modeling guidance in the `data-modeling` skill
- ADABAS/Natural (mainframe data store) -> load the `legacy-architecture-mapper` skill's NATURAL/ADABAS patterns

## Gotchas
- **Views can hide complex joins**: A simple-looking query against a view may
  actually span 10 tables with complex join conditions. Always resolve views
  to their underlying queries.
- **Triggers execute invisible business logic**: BEFORE INSERT and BEFORE UPDATE
  triggers can modify data, enforce rules, and maintain audit trails without
  any visible call from application code. Always check for triggers on every table.
- **ORM lazy loading creates N+1 queries**: An ORM mapping that looks like a
  single object load may execute N+1 queries at runtime. Document lazy vs eager
  loading configuration per relationship.
- **Connection strings differ per environment**: Development, staging, and
  production may point to different databases with different schemas. Document
  which environment the analysis covers.
- **Materialized views have refresh schedules**: They are not just queries —
  they have staleness windows that affect data consistency.
- **Database synonyms and links hide cross-schema access**: A query that appears
  to access a local table may actually reach across database links.
- **Migration files tell the schema evolution story**: Check for Flyway, Liquibase,
  Rails migrations, Alembic, Entity Framework migrations to understand how the
  schema arrived at its current state.

## Quality Rules
Before marking persistence discovery complete, verify:
- [ ] Every table in the database is documented in the schema inventory
- [ ] Every stored procedure is classified (CRUD-only vs business-logic)
- [ ] Every SQL query in application code is traced with file:line reference
- [ ] Transaction boundaries are documented for all multi-table operations
- [ ] Shared database patterns are identified and documented
- [ ] Triggers on all tables are cataloged
- [ ] Views are resolved to underlying queries
- [ ] No TBD or placeholder entries remain

## Common Failure Modes

| Failure | Symptom | Prevention |
|---------|---------|------------|
| Missed triggers | Data integrity rules lost in migration | Query system catalogs for triggers on every table |
| Missed materialized views | Stale data in modernized reporting | Check for materialized views and refresh schedules |
| Incomplete stored proc graph | Broken procedure call chains | Trace inter-procedure dependencies recursively |
| Missed shared DB patterns | Migration breaks other applications | Check for multiple connection sources per table |
| Wrong isolation level | Race conditions in modernized app | Document explicit and implicit isolation levels |
| String-concatenated SQL | SQL injection carried to modernized system | Flag all non-parameterized queries as security anomalies |

## Handoff Summary
After completing the persistence inventory:
1. Verify table count matches the actual database schema object count
2. Confirm every stored procedure with business logic is cross-referenced
   in the business rules catalog from extraction
3. Confirm transaction boundaries cover all multi-table write operations
4. Confirm shared database patterns are documented with impacted applications
5. Save completed inventory to the artifacts directory
6. Proceed to **discovery-readiness-gate** for quality validation

## Advanced Persistence Patterns
Beyond baseline schema/procedure/query inventory, three patterns recur in
every non-trivial modernization and must be captured explicitly when present.
Load the targeted reference whenever the cues listed below appear during
Discovery:

| Pattern | Load when you see | Reference |
|---|---|---|
| Change Data Capture | A need to run the modernized system in shadow, dual-write between legacy and target, or off-load reporting from an OLTP source | `references/cdc-patterns.md` |
| Temporal / history tables | Existing `*_HIST`/`*_AUDIT` pairs, regulatory point-in-time requirements, or SQL Server system-versioned tables already in use | `references/temporal-tables-patterns.md` |
| Partitioning | Tables with hundreds of millions of rows, retention-driven archival, multi-tenant isolation, or existing partition functions/schemes | `references/partitioning-patterns.md` |

For each pattern detected, record the mechanism, operational policy
(retention, rotation, slot lag), and downstream consumers in the persistence
inventory so Architecture and Data lines can plan migration accordingly.

## Database Dialect Dispatch
Route to dialect-specific handoff summaries when the detected database matches. These focused references supplement (not replace) the broader Tech-Stack Dispatch above:

| Dialect | Reference | Key patterns | Common failures |
|---|---|---|---|
| oracle | extraction skill Oracle PL/SQL advanced patterns | Packages, triggers (BEFORE/AFTER/INSTEAD OF), cursors + BULK COLLECT, AQ, materialized views, sequences, DBMS_SCHEDULER | Implicit commits in triggers, cursor leaks, RBS contention |
| sqlserver | extraction skill SQL Server T-SQL patterns | Stored procs, CLR procs, SSIS packages, SSRS reports, CDC, service broker, columnstore, temporal tables | NOLOCK abuse, cursor in OLTP, CLR permission_set mismatch |
