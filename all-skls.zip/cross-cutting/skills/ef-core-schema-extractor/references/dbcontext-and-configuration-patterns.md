# DbContext and Configuration Patterns

Coverage for the entire Entity Framework Core configuration surface:
DbContext subclass shape, DbSet inventory, DI registration, fluent
API in `OnModelCreating`, data annotations, and the precedence rules
between them.

## DbContext Subclass Shape

```csharp
public class AppDbContext : DbContext
{
    public AppDbContext(DbContextOptions<AppDbContext> options)
        : base(options) { }

    public DbSet<Applicant> Applicants => Set<Applicant>();
    public DbSet<Certificate> Certificates => Set<Certificate>();
    public DbSet<AuditEntry> AuditEntries => Set<AuditEntry>();

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.ApplyConfigurationsFromAssembly(typeof(AppDbContext).Assembly);
        base.OnModelCreating(modelBuilder);
    }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
    {
        // Fallback for design-time and tools; NOT the DI path
        if (!optionsBuilder.IsConfigured)
            optionsBuilder.UseSqlServer("fallback-connection-string");
    }
}
```

Key extraction targets:

- Base class: `DbContext` or `IdentityDbContext<TUser>` /
  `IdentityDbContext<TUser, TRole, TKey>`. Identity variant signals
  ASP.NET Core Identity integration.
- Constructor signature: `DbContextOptions<TContext>` parameter
  indicates DI-ready; parameterless constructor + `OnConfiguring`
  with hardcoded connection indicates legacy pattern.
- DbSet properties: can be `{ get; set; }`, `{ get; }`, or
  expression-bodied via `Set<T>()`. Enumerate all three shapes.
- `OnModelCreating` override: mandatory inspection target.
- `OnConfiguring` override: if present with hardcoded values, flag
  as modernization finding.

## DI Registration

Modern pattern in `Program.cs` (ASP.NET Core 6+):

```csharp
builder.Services.AddDbContext<AppDbContext>(options =>
    options.UseSqlServer(builder.Configuration.GetConnectionString("Default"))
           .UseSnakeCaseNamingConvention()
           .LogTo(Console.WriteLine, LogLevel.Information));
```

Legacy pattern in `Startup.ConfigureServices`:

```csharp
services.AddDbContext<AppDbContext>(options =>
    options.UseSqlServer(Configuration.GetConnectionString("Default")),
    contextLifetime: ServiceLifetime.Scoped);
```

Lifetime variants to detect:

- `AddDbContext<T>` — default scope is `Scoped` (per-request in
  web apps). Correct for most cases.
- `AddDbContext<T>(ServiceLifetime.Singleton)` — red flag;
  DbContext is NOT thread-safe. Flag as concurrency bomb.
- `AddDbContext<T>(ServiceLifetime.Transient)` — legal but unusual;
  creates a new DbContext per injection point.
- `AddDbContextFactory<T>` (EF Core 5+) — factory pattern for
  short-lived contexts in Blazor Server, background services.
- `AddPooledDbContextFactory<T>` (EF Core 5+) — pooled variant for
  high-throughput scenarios.

Provider-specific methods to extract:

- `UseSqlServer(connectionString)` — SQL Server
- `UseSqlite(connectionString)` — SQLite
- `UseNpgsql(connectionString)` — PostgreSQL via Npgsql
- `UseMySql(connectionString, serverVersion)` — MySQL via Pomelo
- `UseOracle(connectionString)` — Oracle via devart/Oracle.EntityFrameworkCore
- `UseInMemoryDatabase(name)` — testing only; flag if present in
  production code path
- `UseCosmos(accountEndpoint, accountKey, databaseName)` — Azure
  Cosmos DB
- `UseSqlServerRaw(connection)` — advanced; flag

## OnModelCreating Fluent API

Every call against `modelBuilder.Entity<T>(b => ...)` contributes to
the entity's mapping. Key configuration methods:

### Table and schema

```csharp
entity.ToTable("Applicants", "dbo");
entity.ToTable("Applicants", schema: "dbo", t => t.IsTemporal());
entity.ToView("ApplicantsView");     // keyless query projection
```

### Keys

```csharp
entity.HasKey(e => e.Id);
entity.HasKey(e => new { e.Tenant, e.Id });          // composite
entity.HasAlternateKey(e => e.ExternalCode);
entity.HasNoKey();                                    // keyless entity
```

### Properties

```csharp
entity.Property(e => e.Email)
    .HasColumnName("email_address")
    .HasColumnType("varchar(256)")
    .HasMaxLength(256)
    .IsRequired()
    .HasDefaultValueSql("LOWER(TRIM(email_address))")
    .ValueGeneratedOnAdd()
    .HasConversion<string>()                          // enum-to-string
    .HasField("_email")                               // backing field
    .IsConcurrencyToken();                            // optimistic concurrency
```

Extraction captures: column name, column type override, max length,
is_required (nullability), default value SQL, value-generation
strategy (OnAdd, OnAddOrUpdate, Never), value converter type,
backing field, concurrency token flag.

### Shadow properties

```csharp
entity.Property<DateTime>("LastModified")
    .HasDefaultValueSql("CURRENT_TIMESTAMP");
```

Shadow properties do NOT appear on the entity class — they exist
only in fluent config. Audit-trail pattern:

```csharp
foreach (var entity in modelBuilder.Model.GetEntityTypes())
{
    entity.AddProperty("CreatedAt", typeof(DateTime))
          .SetDefaultValueSql("CURRENT_TIMESTAMP");
    entity.AddProperty("ModifiedAt", typeof(DateTime?));
}
```

### Indexes

```csharp
entity.HasIndex(e => e.Email).IsUnique();
entity.HasIndex(e => new { e.TenantId, e.Code }).IsUnique();
entity.HasIndex(e => e.Status).HasFilter("[Status] = 'Active'");      // filtered (SQL Server)
entity.HasIndex(e => e.Id).IncludeProperties(e => e.Name);            // covering (SQL Server)
entity.HasIndex(e => e.CreatedAt).HasDatabaseName("IX_Custom_Name");
```

### Relationships

Four cardinalities in EF Core:

**One-to-many (required):**
```csharp
entity.HasOne(e => e.Tenant)
      .WithMany(t => t.Applicants)
      .HasForeignKey(e => e.TenantId)
      .OnDelete(DeleteBehavior.Cascade);
```

**One-to-many (optional):**
```csharp
entity.HasOne(e => e.Supervisor)
      .WithMany(s => s.DirectReports)
      .HasForeignKey(e => e.SupervisorId)
      .IsRequired(false)
      .OnDelete(DeleteBehavior.SetNull);
```

**One-to-one:**
```csharp
entity.HasOne(e => e.Profile)
      .WithOne(p => p.User)
      .HasForeignKey<Profile>(p => p.UserId);
```

**Many-to-many (EF Core 5+, no junction entity):**
```csharp
entity.HasMany(e => e.Roles)
      .WithMany(r => r.Users)
      .UsingEntity("UserRoles");
```

**Many-to-many with explicit junction entity:**
```csharp
entity.HasMany(e => e.Roles)
      .WithMany(r => r.Users)
      .UsingEntity<UserRole>(
          j => j.HasOne(ur => ur.Role).WithMany().HasForeignKey(ur => ur.RoleId),
          j => j.HasOne(ur => ur.User).WithMany().HasForeignKey(ur => ur.UserId),
          j => j.HasKey(ur => new { ur.UserId, ur.RoleId }));
```

Cascade behaviors (`OnDelete`):

| Value | SQL equivalent | Semantics |
|---|---|---|
| `Cascade` | `ON DELETE CASCADE` | Delete dependents with principal |
| `Restrict` | `ON DELETE NO ACTION` (no cascade to tracked dependents) | Fail if dependents exist |
| `SetNull` | `ON DELETE SET NULL` | Null the foreign key on dependents |
| `NoAction` | `ON DELETE NO ACTION` | DB-level no-action; EF doesn't cascade |
| `ClientSetNull` | — | EF nulls tracked dependents in memory only |
| `ClientCascade` | — | EF deletes tracked dependents in memory only |
| `ClientNoAction` | — | EF does nothing; DB is untouched |

### Owned entity types

```csharp
entity.OwnsOne(e => e.Address, a =>
{
    a.Property(p => p.Street).HasColumnName("street");
    a.Property(p => p.City).HasColumnName("city");
});

entity.OwnsMany(e => e.Addresses, a =>
{
    a.WithOwner().HasForeignKey("OwnerId");
    a.HasKey("Id");
    a.ToTable("ApplicantAddresses");    // separate table, opt-in
});
```

By default `OwnsOne` projects to the owner's table; `OwnsMany`
creates a dependent table with the owner's key as part of its
composite key.

### Inheritance mappings

**Table-per-hierarchy (TPH, default):**
```csharp
modelBuilder.Entity<Animal>()
    .HasDiscriminator<string>("AnimalType")
    .HasValue<Dog>("D")
    .HasValue<Cat>("C");
```

**Table-per-type (TPT, EF Core 5+):**
```csharp
modelBuilder.Entity<Animal>().ToTable("Animals");
modelBuilder.Entity<Dog>().ToTable("Dogs");
modelBuilder.Entity<Cat>().ToTable("Cats");
```

**Table-per-concrete-class (TPC, EF Core 7+):**
```csharp
modelBuilder.Entity<Animal>().UseTpcMappingStrategy();
```

### Global query filters

```csharp
entity.HasQueryFilter(e => !e.IsDeleted);
entity.HasQueryFilter(e => e.TenantId == _currentTenantId);
```

Every query against this entity implicitly appends the predicate.
Disable per-query with `IgnoreQueryFilters()`.

## Data Annotations

Annotation equivalents of fluent API (fluent wins on conflict):

| Annotation | Fluent equivalent |
|---|---|
| `[Table("Foos", Schema = "dbo")]` | `.ToTable("Foos", "dbo")` |
| `[Column("foo")]` | `.HasColumnName("foo")` |
| `[Column(TypeName = "...")]` | `.HasColumnType("...")` |
| `[Key]` | `.HasKey(e => e.Foo)` |
| `[Required]` | `.IsRequired()` |
| `[MaxLength(n)]` / `[StringLength(n)]` | `.HasMaxLength(n)` |
| `[ForeignKey("PropertyName")]` | `.HasForeignKey(e => e.PropertyName)` |
| `[InverseProperty("PropertyName")]` | `.WithOne(p => p.PropertyName)` |
| `[NotMapped]` | `.Ignore(e => e.Foo)` |
| `[Timestamp]` | `.Property(e => e.RowVersion).IsRowVersion()` |
| `[ConcurrencyCheck]` | `.IsConcurrencyToken()` |
| `[DatabaseGenerated(DatabaseGeneratedOption.Computed)]` | `.ValueGeneratedOnAddOrUpdate()` |

## Conventions and Custom Plugins

`modelBuilder.Conventions.Add(new MyConvention())` — rare but real.
Check for `IConvention` implementations. Third-party pluralizers
(e.g., `EntityFrameworkCore.UseSnakeCaseNamingConvention`) change
entity-to-table naming — extract as a cross-cutting finding.

## Value Converters

```csharp
entity.Property(e => e.Status)
      .HasConversion<string>();                         // enum <-> string

entity.Property(e => e.Metadata)
      .HasConversion(
          v => JsonSerializer.Serialize(v, (JsonSerializerOptions?)null),
          v => JsonSerializer.Deserialize<Dict>(v, (JsonSerializerOptions?)null));

entity.Property(e => e.Tags)
      .HasConversion(
          v => string.Join(',', v),
          v => v.Split(',', StringSplitOptions.RemoveEmptyEntries).ToList());
```

Custom converters are code-paths that modernization must preserve.
Enumerate with full conversion expressions (serialize + deserialize).

## Backing Fields

```csharp
entity.Property(e => e.Name).HasField("_name");
entity.Property(e => e.Name).UsePropertyAccessMode(PropertyAccessMode.Field);
```

Backing fields allow encapsulation — EF reads/writes the field,
ignoring the property accessor. Record the backing-field name per
property.

## Lazy-Loading Proxies

```csharp
services.AddDbContext<AppDbContext>(options =>
    options.UseSqlServer(...)
           .UseLazyLoadingProxies());
```

Requires `virtual` navigation properties. Flag as perf risk (N+1
pattern on iteration).
