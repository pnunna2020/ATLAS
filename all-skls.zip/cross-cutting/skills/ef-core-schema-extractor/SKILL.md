---
name: ef-core-schema-extractor
description: >
  Extract the full Entity Framework Core entity model, relationships,
  indexes, value conversions, global query filters, and migration history
  from C# source — a complete schema inventory produced without a live
  database. `dotnet-discovery-patterns` and `dotnet-extraction-patterns`
  detect EF Core presence at a shallow level; this skill produces the
  deep manifest that downstream Design and Generation consume to author
  the target data model, ORM mapping, and migration strategy. Fires for
  ATLAS DIWS (where `MSS.DIWSWeb.DataModel` ships as a dedicated solution
  — a thick-entity-layer signal) and any modern ASP.NET Core app with a
  DbContext. Runs as a Modernization Extract conditional skill when
  `primary_language in {csharp, vbnet}` AND any project references
  `Microsoft.EntityFrameworkCore` AND a `DbContext` subclass is present.
  Triggers on EF Core extraction, DbContext analysis, entity-model
  recovery, EF migration inventory, or @ef-core-schema-extractor.
agent: sonnet
allowed-tools:
  - Read
  - Write
  - Grep
  - Glob
validation_commands:
  - "python -m olympus.validators.schema_validator ef-core-dbcontext-manifest.json"
  - "python -m olympus.validators.schema_validator ef-core-entity-manifest.json"
  - "python -m olympus.validators.schema_validator ef-core-relationship-graph.json"
  - "python -m olympus.validators.schema_validator ef-core-migration-timeline.json"
  - "python -m olympus.validators.schema_validator ef-core-query-surface.json"
  - "python -m olympus.validators.schema_validator ef-core-tracking-findings.json"
  - "python -m olympus.validators.schema_validator ef-core-modernization-readiness.json"
supported_stacks:
  - csharp
  - vbnet
  - ef-core
  - entity-framework-core
  - entityframeworkcore
  - dbcontext
  - aspnet-core
anti_target_stacks:
  - ef6
  - ef-classic
  - nhibernate
  - dapper
  - ado-net
  - edmx
failure_classes:
  - fluent-api-vs-annotations-precedence-inverted
  - modelsnapshot-drift-vs-runtime-unflagged
  - shadow-property-not-extracted-from-fluent
  - owned-entity-projected-to-separate-table
  - query-filter-soft-delete-ignored
  - n-plus-one-pattern-missed
  - fromsqlraw-injection-unflagged
  - tph-vs-tpt-vs-tpc-misclassified
  - ef-version-mismatched-with-dotnet-target
  - executeupdate-change-tracking-bypass-missed
benchmark_tags:
  - modernization-extract
  - ef-core-entity-model
  - ef-migration-timeline
  - orm-extraction
---

# ef-core-schema-extractor

## Purpose
Produce a complete, citation-traceable inventory of the Entity Framework
Core surface from source alone: DbContexts and their DI registrations,
entities and their mappings (tables, columns, types, nullability,
computed columns, shadow properties), keys (primary, alternate, foreign),
relationships (one-to-one, one-to-many, many-to-many with or without
junction entity, cascade semantics), indexes (including filtered and
covering), value converters, owned-entity projections, global query
filters (soft-delete, multi-tenancy), the migration timeline, the query
surface (LINQ patterns, raw-SQL sites, tracking-disabled calls), and the
modernization-readiness assessment (EF Core major version, .NET target
compatibility, deprecated-feature usage). Downstream Design uses this to
shape the target data model; downstream Generation uses it to author
target ORM mappings; `parity-verifier` uses the relationship graph and
index inventory to certify modernization parity. Without this extractor,
the EF Core layer is treated as an opaque dependency and modernization
loses entity-level precision.

## Inputs
- Repository containing `.csproj`/`.vbproj` that reference
  `Microsoft.EntityFrameworkCore` (any sub-package: `.SqlServer`,
  `.Sqlite`, `.PostgreSQL` via Npgsql, `.InMemory`, etc.).
- Source files under the repo: `.cs` / `.vb`, particularly any class
  that subclasses `DbContext` or `IdentityDbContext<T>`.
- Optional: `Migrations/` folder with migration classes and
  `*ModelSnapshot.cs`.
- Optional: `appsettings.json` / `web.config` / `Program.cs` /
  `Startup.cs` for connection-string discovery and
  `AddDbContext<T>` registration inspection.
- Tech fingerprint from `dotnet-discovery-patterns` to confirm the
  app is a .NET Core/5+ host (EF6 and EF Classic have entirely
  different extractors).

## Outputs
- `ef-core-dbcontext-manifest.json` — per DbContext subclass:
  `{class_name, namespace, file_path, base_class (DbContext or
  IdentityDbContext<T>), dbset_properties[] (property_name,
  entity_type, access_modifier), connection_configuration
  (onconfiguring_code_path | di_addDbContext_site_path),
  modelbuilder_applies[] (typeof(...) arguments to
  ApplyConfiguration), global_query_filters_count,
  database_provider (sqlserver | sqlite | postgresql | inmemory |
  other)}`.
- `ef-core-entity-manifest.json` — per entity type:
  `{class_name, namespace, file_path, table_name (from [Table] or
  fluent .ToTable), schema, is_keyless, properties[] (name,
  clr_type, column_type_override, is_nullable, max_length,
  is_computed, is_shadow, is_row_version, default_value_sql),
  primary_key (composite or single), alternate_keys[], foreign_keys[]
  (principal_entity, principal_key, dependent_property,
  on_delete_behavior), indexes[] (columns, is_unique,
  filter_expression, include_properties), value_converters[]
  (property, converter_type), backing_fields[] (property,
  backing_field)}`.
- `ef-core-relationship-graph.json` — every relationship edge:
  `{principal_entity, dependent_entity, cardinality
  (one-to-one | one-to-many | many-to-many), navigation_property,
  inverse_navigation_property, on_delete
  (Cascade | Restrict | SetNull | NoAction | ClientSetNull |
  ClientCascade | ClientNoAction), is_owned}`.
- `ef-core-migration-timeline.json` — per migration class in
  `Migrations/`: `{migration_id, timestamp, class_name, file_path,
  up_operations[] (CreateTable, AddColumn, DropIndex,
  CreateIndex, AddForeignKey, RenameColumn, etc., with
  arguments), down_operations[]}`. Plus one `ModelSnapshot.cs`
  record with the full `BuildTargetModel` content location
  (the authoritative current-state anchor).
- `ef-core-query-surface.json` — LINQ query sites across the
  solution: `{file_path, line, method_chain (e.g., Where().Include().Select()),
  n_plus_one_heuristic (true if Include inside a loop or SelectMany
  without projection), no_tracking (true if AsNoTracking or
  AsNoTrackingWithIdentityResolution), compiled_query (true if
  EF.CompileQuery), raw_sql_kind (none | FromSqlRaw |
  FromSqlInterpolated | ExecuteSqlRaw | ExecuteSqlInterpolated |
  ExecuteUpdate | ExecuteDelete)}`.
- `ef-core-tracking-findings.json` — SQL-injection risk sites
  (`FromSqlRaw` with string concatenation or interpolation of
  user-controlled values), dynamic-LINQ usage, interceptors
  (`IInterceptor`, `SaveChangesInterceptor`, `IMaterializationInterceptor`),
  concurrency tokens without `[ConcurrencyCheck]` or
  `.IsConcurrencyToken()`, `EnsureCreated` usage (dangerous
  bypass of migration history).
- `ef-core-modernization-readiness.json` — `{ef_core_major_version,
  ef_core_minor_version, dotnet_target_framework,
  end_of_support_status (eol | lts | current),
  deprecated_feature_usage[] (lazy_loading_proxies, string_loadchildren,
  view_engine_equivalent, legacy_many_to_many_with_junction_entity),
  tph_tpt_tpc_mapping_distribution, temporal_tables_used,
  owned_entity_count, global_query_filter_count}`.

## Methodology
1. **Locate every DbContext subclass.** Grep for `class \S+\s*:\s*DbContext`
   or `class \S+\s*:\s*IdentityDbContext` across `.cs`/`.vb` files.
   Also capture generic bases (`: DbContext<T>`).
2. **Enumerate DbSet<T> properties.** For each DbContext, parse
   public `DbSet<Foo>` or `DbSet<Foo, FooKey>` property declarations.
   Each `Foo` is an entity type; capture the type's fully-qualified
   name.
3. **Classify connection configuration.** Look for
   `OnConfiguring(DbContextOptionsBuilder optionsBuilder)` —
   legacy DI bypass; flag as modernization finding. Look for
   `services.AddDbContext<TContext>(options => ...)` in
   `Program.cs`/`Startup.cs` / `ConfigureServices` — modern DI
   registration. Record the provider (`UseSqlServer`, `UseSqlite`,
   `UseNpgsql`, `UseInMemoryDatabase`).
4. **Parse `OnModelCreating` fluent API.** Walk each
   `modelBuilder.Entity<Foo>(b => ...)` block. Within the block:
   - `.ToTable("name", "schema")` — table + schema
   - `.HasKey(e => e.Id)` or `.HasKey(e => new { e.A, e.B })` —
     primary key (single or composite)
   - `.HasAlternateKey(e => e.Code)` — alternate key
   - `.Property(e => e.Foo).HasColumnType("...").HasMaxLength(n).IsRequired()
     .ValueGeneratedOnAdd().HasDefaultValueSql("...").HasConversion<T>()` —
     property configuration
   - `.HasIndex(e => e.Foo).IsUnique().HasFilter("...").IncludeProperties(e => e.Bar)` —
     index configuration
   - `.HasOne(e => e.Parent).WithMany(p => p.Children)
     .HasForeignKey(e => e.ParentId).OnDelete(DeleteBehavior.Cascade)` —
     relationship
   - `.OwnsOne(e => e.Address)` / `.OwnsMany(e => e.Addresses)` —
     owned entities
   - `.HasDiscriminator(e => e.Type).HasValue<Foo>("F")` —
     table-per-hierarchy (TPH)
   - `.ToTable("FooSub")` on a subclass — table-per-type (TPT) or
     table-per-concrete (TPC) depending on EF Core version
   - `.HasQueryFilter(e => !e.IsDeleted)` — global query filter
5. **Detect data annotations.** `[Table]`, `[Column]`, `[Key]`,
   `[Required]`, `[MaxLength]`, `[StringLength]`, `[ForeignKey]`,
   `[InverseProperty]`, `[NotMapped]`, `[Timestamp]`,
   `[ConcurrencyCheck]`. Fluent API wins on conflict — emit a
   `fluent_vs_annotation_conflict` finding when both specify the
   same property.
6. **Extract shadow properties.** Shadow properties live only in
   fluent config (`.Property<DateTime>("LastModified")`) — enumerate
   all such declarations. Common pattern: audit-trail columns
   (`CreatedAt`, `ModifiedBy`) added to every entity via a
   convention in `OnModelCreating`.
7. **Extract owned entity types.** `OwnsOne` / `OwnsMany` project
   to the OWNER's table by default — never a separate table
   unless explicitly `.ToTable()`-ed. Record the owner + property
   name + owned type.
8. **Walk the Migrations/ folder.** Each migration class has
   `Up(MigrationBuilder)` and `Down(MigrationBuilder)` methods
   with operations. Extract operation names and arguments.
   Parse `[Migration("20230101_Foo")]` attribute for migration
   ID and timestamp. Locate `*ModelSnapshot.cs` and record as the
   current-state anchor.
9. **Walk query sites.** Grep for `DbContext.Set<T>()`,
   `.Where(`, `.Select(`, `.Include(`, `.ThenInclude(`,
   `.AsNoTracking(`, `.AsNoTrackingWithIdentityResolution(`,
   `.FromSqlRaw(`, `.FromSqlInterpolated(`, `.ExecuteSqlRaw(`,
   `.ExecuteSqlInterpolated(`, `.ExecuteUpdate(`,
   `.ExecuteDelete(`, `EF.CompileQuery(`. Capture method-chain
   snapshots. Apply N+1 heuristic: `Include` inside a `foreach`
   or `for` loop; lazy-loading property access inside a loop.
10. **Detect interceptors.** Classes implementing `IInterceptor`
    (including `SaveChangesInterceptor`,
    `DbCommandInterceptor`, `IMaterializationInterceptor`). Record
    as cross-cutting behavior that modernization must preserve.
11. **Version classification.** Read the `PackageReference` version
    for `Microsoft.EntityFrameworkCore*` across all `.csproj`.
    Determine EF Core major + minor. Cross-reference with
    `TargetFramework` (`net6.0`, `net8.0`, etc.) — flag
    version-target mismatch.
12. **Emit manifests with `{repo}:{file}:{line}` citations.**

## Tech-Stack Dispatch

| Trigger | Reference loaded |
|---|---|
| DbContext class detected | `references/dbcontext-and-configuration-patterns.md` |
| `Migrations/` folder or `[Migration(...)]` attribute | `references/ef-migrations-and-snapshot-patterns.md` |
| Interceptors, compiled queries, raw SQL, ExecuteUpdate/Delete | Both references |

## Gotchas
- **EF Core major versions are deeply version-pinned.** 3.0 changed
  LINQ evaluation (no more client-side fallback); 5.0 added skip-
  navigation many-to-many without a junction entity; 6.0 added
  temporal tables; 7.0 added `ExecuteUpdate`/`ExecuteDelete`
  bypassing change tracking; 8.0 added primitive collections.
  Emit BOTH the EF Core version AND the .NET target framework.
- **Data annotations vs fluent API.** Fluent wins on conflict.
  A property with `[MaxLength(100)]` AND
  `.Property(e => e.Foo).HasMaxLength(200)` is configured as 200.
  Emit `fluent_vs_annotation_conflict` finding per occurrence.
- **`OnConfiguring` is old-style DI bypass.** Modern apps register
  via `AddDbContext<T>(options => ...)` in `Program.cs`. If a
  DbContext has an `OnConfiguring` override with a hardcoded
  connection string, it's a modernization finding (hard-to-test,
  hard-to-configure-per-environment).
- **`Migrations/` + `ModelSnapshot.cs` is authoritative.** Any
  divergence from the runtime DB is drift. `ModelSnapshot.cs`'s
  `BuildTargetModel` method contains the full current model — use
  it when reconciling against the live schema.
- **`EnsureCreated()` creates the DB without migration history.**
  Dangerous: the DB has no `__EFMigrationsHistory` table, so
  subsequent `Migrate()` calls will try to re-apply every migration
  from scratch. Flag `EnsureCreated` usage as severity P1.
- **Shadow properties live only in fluent config.** A
  `.Property<DateTime>("LastModified")` is NOT declared on the
  entity class — it exists only in `OnModelCreating`. Enumerate
  separately from declared properties.
- **Owned entity types project to the OWNER's table.** `OwnsOne`
  / `OwnsMany` do NOT create separate tables unless `.ToTable()`
  is chained. A naive extractor that emits each owned type as its
  own table is wrong.
- **Query filters (`HasQueryFilter`) apply globally.** Soft-delete
  (`!e.IsDeleted`) and multi-tenancy (`e.TenantId == CurrentTenantId`)
  are the common cases. Every query against that entity silently
  applies the filter — modernization must preserve the predicate.
- **N+1 heuristic: `Include` inside a loop.** A `foreach (var x in
  context.Foos)` followed by `x.Bars` accesses (with lazy loading)
  is one query per row. Flag explicitly — this is the most common
  EF perf bug.
- **`FromSqlRaw` bypasses type safety.** SQL-injection risk when
  user input is concatenated into the query string. Use
  `FromSqlInterpolated` instead — it uses parameterized queries.
  Flag every `FromSqlRaw` call with a string-concatenation
  argument as severity P0 security finding.
- **DbContext is NOT thread-safe.** Scope is per-request in
  ASP.NET Core. A singleton DbContext in DI registration is a
  silent concurrency bomb. Detect registration lifetime and flag
  `AddDbContext(...)` alternatives that aren't `Scoped`.
- **Concurrency tokens are load-bearing.** `[ConcurrencyCheck]`,
  `[Timestamp]`, or `.IsConcurrencyToken()` mark a property as
  the optimistic-concurrency token — EF appends it to UPDATE
  WHERE clauses. Missing tokens = last-write-wins silently.
- **Temporal tables (SQL Server 2016+ / EF Core 6+).** Configured
  via `.ToTable("Foo", b => b.IsTemporal())` — EF generates the
  SYSTEM_VERSIONING setup. Modernization to non-SQL-Server
  targets loses temporal support; flag.
- **TPH, TPT, TPC distinction.** Table-per-hierarchy shares one
  table with a discriminator column (`HasDiscriminator`);
  table-per-type uses a table per subclass with joins; table-per-
  concrete-class (EF Core 7+) uses a table per leaf class with
  no join. Determine per inheritance chain.
- **`ExecuteUpdate` / `ExecuteDelete` (EF Core 7+)** bypass change
  tracking for bulk operations. Interceptors do not fire. Audit
  columns (`ModifiedBy`, `ModifiedAt`) set via interceptor are
  silently skipped. Flag as audit-gap finding.
- **Pluralizer and convention plugins** change entity-to-table
  mapping. `EntityFrameworkCore.UseIdentityColumns` or third-
  party pluralizers can introduce surprises. Check `DbContext`
  for any `ModelBuilder` convention customization.

## Quality Rules
- [ ] Every DbContext subclass has a manifest entry with base
      class, DbSet inventory, and connection configuration.
- [ ] Every entity type (via DbSet or via `ApplyConfiguration`)
      has a manifest entry with table, keys, properties, indexes,
      and relationship participation.
- [ ] Fluent API and data annotations are both extracted; conflicts
      flagged with `fluent_vs_annotation_conflict`.
- [ ] Shadow properties are enumerated separately from declared
      properties.
- [ ] Owned entity types are recorded with their owner and
      target table (default: owner's table).
- [ ] Every migration class has an inventory entry with `Up()` /
      `Down()` operations.
- [ ] `ModelSnapshot.cs` is identified as the current-state anchor.
- [ ] N+1 heuristic applied to every query site.
- [ ] `FromSqlRaw` with string concatenation flagged as P0.
- [ ] `EnsureCreated` usage flagged as P1.
- [ ] EF Core major version + .NET target framework emitted;
      version-target mismatch flagged.
- [ ] Every record carries `{repo}:{file}:{line}` traceability.

## Common Failure Modes

| Failure Mode | Symptom | Prevention |
|---|---|---|
| Fluent API ignored, only annotations extracted | Manifest reports MaxLength=100 from [MaxLength] attribute but runtime behavior is 200 | Parse OnModelCreating lambda blocks; fluent wins on conflict |
| Shadow properties missed | Audit columns (CreatedAt, ModifiedBy) absent from entity manifest | Enumerate .Property<T>("...") declarations in fluent config |
| Owned entity emitted as separate table | OwnsOne(e => e.Address) reported with its own table; target schema creates a foreign key that doesn't exist | Check if .ToTable() is chained on the owned config; default = owner's table |
| N+1 not detected | Include inside a foreach loop reported as normal query | Heuristic: Include, SelectMany without projection, lazy-loaded nav inside a loop |
| FromSqlRaw injection missed | Query with `$"SELECT * FROM Foo WHERE Id = {userInput}"` flagged as safe | Parse argument: literal string = safe, interpolated/concatenated = P0 |
| ModelSnapshot ignored | Manifest uses latest migration's Up() as current state instead of ModelSnapshot.BuildTargetModel | ModelSnapshot.cs is the authoritative current-state; use it |

## Handoff Summary
When this skill completes, verify:
1. Every DbContext in the solution has an inventory record with base
   class, DbSet list, and DI registration location.
2. Every entity type has a manifest entry with keys, properties,
   indexes, and relationship participation.
3. Migrations/ folder is fully inventoried; ModelSnapshot.cs is
   identified as current-state anchor.
4. Query surface identifies N+1 patterns, raw-SQL injection risks,
   and tracking bypasses.
5. EF Core version + .NET target framework are cross-referenced.

Then proceed to: `data-modeling` (Design supplementary) — which
consumes the entity manifest to shape the target schema;
`api-specification` — which consumes DbSet + entity shape to author
target API contracts; and, in Generation, the target ORM skill
(`dotnet-api-generation` for preserving EF Core,
`fastapi-api-generation` for SQLAlchemy port, etc.).

## References
- `references/dbcontext-and-configuration-patterns.md` — DbContext
  class structure, DbSet properties, `OnConfiguring` vs DI
  registration, `OnModelCreating` fluent API
  (`HasKey`/`HasMany`/`WithOne`/`HasForeignKey`/`HasIndex`/
  `HasQueryFilter`/`OwnsOne`/`HasDiscriminator`/`HasConversion`),
  data annotations inventory and precedence, global conventions,
  value converters, backing fields, lazy-loading proxies.
- `references/ef-migrations-and-snapshot-patterns.md` —
  Migrations/ folder structure, migration class anatomy
  (`Up()`/`Down()`/`BuildTargetModel()`), `ModelSnapshot.cs`
  authoritative current state, drift detection vs live DB,
  `EnsureCreated` vs `Migrate` trade-offs, idempotent migration
  patterns, cross-provider migration scripts, rollback planning.

## Changelog
- 0.1.0 (2026-05-07) — Initial skill. Covers DbContext + entity
  extraction, fluent API + data annotations, relationships,
  indexes, value converters, shadow properties, owned entities,
  query filters, migration timeline, `ModelSnapshot.cs`, LINQ
  query surface with N+1 heuristic, `FromSqlRaw` injection
  detection, modernization readiness (EF Core version, deprecated
  features). Emits seven manifests with `{repo}:{file}:{line}`
  traceability. Authored as ATLAS-R-13.
