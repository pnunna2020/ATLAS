---
name: srs-from-discovery
description: >
  Transform descriptive discovery findings into prescriptive Software Requirements
  Specification. Bridges Discovery and Modernization by deciding what the modernized
  system MUST do. Use after discovery-readiness-gate passes. Triggers on SRS generation,
  requirements specification, discovery-to-requirements, prescriptive specification.
agent: opus
allowed-tools:
  - Read
  - Write
  - Grep
---

# SRS from Discovery

## Purpose
Transform the descriptive discovery artifacts (what the legacy system does) into
a prescriptive Software Requirements Specification (what the modernized system
MUST do). This is not a copy operation. Discovery describes observed behavior
including bugs, dead code, security vulnerabilities, and implicit conventions.
The SRS prescribes correct, explicit, secure, and maintainable behavior.

This skill is the bridge between Discovery and Modernization. It feeds directly
into the Architecture line (for decomposition decisions) and the Modernization
Extract step (for code generation specifications). A poor SRS means the
modernized system faithfully reproduces legacy bugs or silently drops valid
business rules.

## Inputs
- Gate-approved interface inventory (from sdr-area-interface, via discovery-readiness-gate)
- Gate-approved business rules catalog (from extraction)
- Gate-approved persistence inventory (from sdr-area-persistence)
- Anomaly resolution rules (from the extraction skill's anomaly resolution rules YAML)

## Outputs
- SRS document composed of modules (assets/srs-module-template.yaml)
- State machine definitions per entity with states and transitions
- Actor model derived from authentication/authorization patterns
- Traceability matrix (every requirement traces to discovery finding)
- Anomaly resolution log (every anomaly has a documented resolution)

## Methodology

### Step 1 — Load and Validate Discovery Artifacts
Load all three discovery inventories and verify they passed the readiness gate:
- Interface inventory: confirms endpoints, classifications, auth mapping
- Business rules catalog: confirms rules, test scenarios, cross-validation
- Persistence inventory: confirms schema, stored procs, transactions

If any artifact lacks the gate-approved stamp, STOP. Return to
discovery-readiness-gate. Do not generate SRS from unvalidated discovery.

### Step 2 — Apply Anomaly Resolution Rules
For every anomaly identified during discovery, apply the resolution from
the extraction skill's anomaly resolution rules YAML:

- **security_violation -> FIX**: Do not carry SQL injection, XSS, or hardcoded
  credentials into the SRS. Instead, prescribe the secure alternative. Example:
  if legacy uses string concatenation for SQL, the SRS requirement specifies
  parameterized queries.
- **dead_code -> OMIT**: Do not generate requirements for unreachable code.
  Document the omission in the anomaly resolution log with justification.
- **duplicate_logic -> CONSOLIDATE**: When the same rule exists in multiple
  places, identify the canonical version. The SRS prescribes a single
  authoritative implementation with a reference used elsewhere.
- **naming_inconsistency -> RENAME**: Prescribe consistent naming following
  target language and framework conventions. Map old names to new names.
- **redundant_validation -> CONSOLIDATE**: Prescribe validation at the system
  boundary. Inner layers trust validated input.
- **implicit_behavior -> MAKE_EXPLICIT**: Every implicit framework behavior
  becomes an explicit requirement. No magic allowed in the modernized system.
- **performance_antipattern -> OPTIMIZE**: Prescribe the efficient alternative.
  Include expected performance characteristics.
- **accessibility_violation -> FIX**: Prescribe WCAG 2.1 AA compliant
  implementation. Reference Section 508 requirements for FAA systems.

Every anomaly must have a resolution. None may be deferred without written
justification approved by a human reviewer.

### Step 3 — Derive State Machines
Identify entities with lifecycle state by scanning for:
- Database columns with constrained value sets (status, state, phase, stage)
- Business rules that modify status fields (state transitions)
- Workflow definitions with sequential steps
- Approval chains with multiple states

For each stateful entity, produce a formal state machine:
- Enumerate all states (including initial and terminal states)
- Map every transition with: from-state, to-state, trigger event, guard
  condition, action performed
- Identify unreachable states (dead states) — these are anomalies to resolve
- Identify states with no exit transitions (terminal states) — verify these
  are intentional
- Verify every state is reachable from the initial state
- Verify every non-terminal state has at least one exit transition

State machines are requirements, not descriptions. They prescribe the ONLY
valid transitions the modernized system may allow.

### Step 4 — Map Actors
Extract the actor model from authentication and authorization patterns:
- System actors: external systems, batch processes, message producers
- User actors: roles identified in authorization checks (admin, reviewer,
  analyst, public user, etc.)
- For each actor, document: name, type (human/system), authentication method,
  permissions, which endpoints they access

Map actors to UML-style actor definitions. Each actor must trace to concrete
authorization checks in the discovery artifacts. Invented actors (not found
in code) are not allowed — every actor must have evidence.

### Step 5 — Produce Prescriptive SRS Modules
Generate one SRS module per logical functional area. Each module contains:

**Requirements**: Derived from business rules with anomaly resolutions applied.
Each requirement has:
- Unique ID (REQ-NNN format)
- Type: functional, non-functional, or constraint
- Description in prescriptive language ("The system SHALL..." not "The system does...")
- Priority: must (essential), should (important), could (nice-to-have)
- Acceptance criteria (derived from test scenarios in business rules catalog)
- Traceability to discovery finding (rule ID, file:line)
- Anomaly resolution applied (if any)

**State machines**: Formal definitions from Step 3.

**Data requirements**: Derived from persistence inventory. Each entity with:
- Attributes (from table columns, with types and constraints)
- Relationships (from foreign keys)
- Constraints (from check constraints, business rules, triggers)

**Actor interactions**: From Step 4, which actors interact with this module.

## Gotchas
- **Descriptive does not equal prescriptive**: The legacy system's behavior
  includes bugs. Do not write "The system SHALL throw a NullPointerException
  when the user submits an empty form." Write "The system SHALL validate
  required fields and return a descriptive error message."
- **State machines may have unreachable states**: Legacy databases often have
  status values that no code path can produce. These are dead states — omit
  them from the SRS state machine but document them in the anomaly log.
- **Some implicit behaviors should become explicit requirements**: ColdFusion's
  implicit type coercion is not a feature to preserve — it is behavior that
  must become an explicit requirement with defined type handling.
- **Actor confusion**: A "system" actor (batch process) and a "user" actor
  (admin) may have overlapping permissions but different authentication paths.
  Do not merge them.
- **Non-functional requirements need evidence too**: Performance requirements
  should trace to observed usage patterns or documented SLAs, not invented
  thresholds.
- **Omitted features need justification**: If a legacy feature is marked OMIT,
  the SRS must document why. Stakeholders will ask.

## Quality Rules
Before marking SRS generation complete, verify:
- [ ] Every SRS requirement traces to a discovery finding (rule ID + file:line)
- [ ] No requirements exist without evidence in discovery artifacts
- [ ] All anomalies from the anomaly log have documented resolutions
- [ ] No anomalies are deferred without written justification
- [ ] State machines are complete (all states reachable, all transitions documented)
- [ ] Actor model traces to concrete authorization checks in discovery
- [ ] Prescriptive language used throughout ("SHALL" / "SHALL NOT")
- [ ] Acceptance criteria are testable (concrete, not vague)
- [ ] Data requirements match persistence inventory with anomaly resolutions applied

## Common Failure Modes

| Failure | Symptom | Prevention |
|---------|---------|------------|
| Copying bugs as requirements | Modernized system reproduces legacy bugs | Apply anomaly resolution before writing requirements |
| Incomplete state machine | Missing edge transitions cause undefined behavior | Verify reachability and exit conditions for all states |
| Actor confusion | System actors treated as human actors or vice versa | Separate actors by authentication method, not just name |
| Vague acceptance criteria | Requirements pass review but fail testing | Derive acceptance criteria from concrete test scenarios |
| Missing non-functional requirements | Modernized system meets functional spec but fails SLAs | Extract NFRs from observed performance and documented SLAs |
| Invented requirements | SRS contains features not in legacy system | Every requirement must trace to a discovery finding |

## Handoff Summary
After completing the SRS:
1. Verify every requirement has bidirectional traceability (SRS -> discovery, discovery -> SRS)
2. Confirm all anomaly resolutions are documented and justified
3. Confirm state machines pass completeness validation (reachability, no dead states in SRS)
4. Confirm actor model is complete and evidence-based
5. Archive SRS as versioned artifact in the artifacts directory
6. Proceed to **Architecture assembly line** (for decomposition decisions)
   and **Modernization Extract step** (for code generation specifications)
