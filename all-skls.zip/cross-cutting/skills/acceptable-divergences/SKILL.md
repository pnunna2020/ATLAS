---
name: acceptable-divergences
description: >
  Define and manage pre-approved behavioral differences between legacy and modernized applications
  that represent intentional improvements, not regressions. Used during Validation Stream 1 parity
  verification. Triggers on parity divergence classification, acceptable difference, or G-V1 review.
agent: sonnet
allowed-tools:
  - Read
  - Write
  - Grep
---

# Acceptable Divergences

## Purpose
Classify behavioral differences between legacy and modernized applications as CRITICAL
(business logic change requiring investigation) or ACCEPTABLE (intentional improvement
that should not fail parity verification).

## Inputs
- Legacy application outputs (response bodies, status codes, headers)
- Modernized application outputs (same input sets)
- Application archetype (web/batch/API)
- Normalization rules from design specifications

## Outputs
- Pre-approved divergence list with justification per entry
- Classification of each detected divergence (CRITICAL vs. ACCEPTABLE)
- Divergence report for gate G-V1 evidence package

## Methodology
1. Load the pre-approved divergence catalog for the application archetype
2. For each detected divergence, check against the catalog
3. Classify uncataloged divergences as CRITICAL by default
4. Document justification for any new ACCEPTABLE classifications

## Common Pre-Approved Divergences
- Error format differences (generic 500 → structured JSON with error codes)
- Date format standardization (mm/dd/yyyy → ISO 8601)
- Pagination improvements (unbounded result sets → paginated responses)
- Character encoding normalization (Latin-1 → UTF-8)
- HTTP status code correctness (200 for errors → proper 4xx/5xx)
- Session handling modernization (server-side sessions → stateless JWT)
- File path normalization (Windows backslash → Unix forward slash)

## Gotchas
- **Undocumented divergences are CRITICAL until proven otherwise**: Don't assume
  a difference is acceptable just because it "looks like an improvement."
- **Divergences must be approved before the G-V1 gate**: Late-discovered
  acceptable divergences require explicit documentation and reviewer sign-off.
- **Batch job divergences are different**: Timing differences, record ordering,
  and rounding precision require archetype-specific tolerance rules.

## Quality Rules
- [ ] Every detected divergence is classified as CRITICAL or ACCEPTABLE — no unclassified items
- [ ] ACCEPTABLE classifications reference a specific entry in the pre-approved catalog or include a new justification
- [ ] New ACCEPTABLE classifications are documented with rationale and approved before the G-V1 gate
- [ ] CRITICAL divergences trigger investigation — they are never silently reclassified as ACCEPTABLE without evidence
- [ ] Divergence report includes the input that triggered each divergence for reproducibility
- [ ] Archetype-specific tolerance rules (web/batch/API) are loaded before classification begins

## Common Failure Modes
| Failure Mode | Symptom | Prevention |
|-------------|---------|------------|
| Assumed-acceptable divergences | Differences marked ACCEPTABLE without catalog reference; real regressions slip through | Default all uncataloged divergences to CRITICAL; require explicit justification for reclassification |
| Late divergence discovery | New divergences found after G-V1 gate; requires re-review and delays deployment | Run parity verification early and often; do not defer divergence analysis to the final gate |
| Wrong archetype tolerance | Batch job timing tolerance applied to API response time comparison; false passes | Verify archetype before loading tolerance rules; use archetype-specific thresholds |
| Missing reproducibility data | Divergence report says "output differs" but does not include the triggering input | Require input payloads alongside divergence entries in the report |

## Handoff Summary
When this skill completes, verify:
1. All divergences are classified (zero unclassified items)
2. ACCEPTABLE items have catalog references or approved justifications
3. Zero unresolved CRITICAL divergences remain
Then proceed to: gate `G-V1` for functional validation sign-off with the divergence report as evidence
