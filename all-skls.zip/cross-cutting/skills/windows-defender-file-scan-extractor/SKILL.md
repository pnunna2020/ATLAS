---
name: windows-defender-file-scan-extractor
description: >
  Extract Windows Defender integration code that performs virus scanning
  on uploaded files before they enter the application's document flow.
  AMCS ships `AMCS.FileScan` as a dedicated project with
  `WindowsDefenderScanner.cs` invoking `MpCmdRun.exe` to scan Form 8500-8
  medical-document uploads before they reach the document queue. This is
  security-critical: modernization must preserve virus-scanning semantics
  because regulated uploads retain compliance only if scanned. Runs as
  a Modernization Extract conditional skill when the repo contains a
  project or file matching `*FileScan*`, `*WindowsDefender*`,
  `*MpCmdRun*`, `*VirusScan*`, or `MpCmdRun.exe` invocation sites.
  Triggers on Windows Defender integration inventory, file-scan
  extraction, MpCmdRun usage, antivirus integration audit, or
  @windows-defender-file-scan-extractor.
agent: sonnet
allowed-tools:
  - Read
  - Write
  - Grep
  - Glob
validation_commands:
  - "python -m olympus.validators.schema_validator file-scan-integration-inventory.json"
  - "python -m olympus.validators.schema_validator file-scan-call-sites.json"
  - "python -m olympus.validators.schema_validator file-scan-modernization-findings.json"
supported_stacks:
  - windows-defender
  - mpcmdrun
  - file-scan
  - virus-scan
  - csharp
anti_target_stacks:
  - linux-only
  - container-no-defender
  - static-site
failure_classes:
  - mpcmdrun-path-hardcoded
  - scan-result-parsing-fragile
  - scan-timeout-unbounded
  - failure-mode-unclear
  - windows-only-dependency-on-linux-target
  - scanner-bypass-via-mv-instead-of-copy
benchmark_tags:
  - modernization-extract
  - file-scan-inventory
  - security-integration
  - document-upload-virus-scan
---

# windows-defender-file-scan-extractor

## Purpose
Extract the Windows Defender virus-scanning integration surface from
legacy .NET apps. File-scan code is usually isolated in a dedicated
project but has non-obvious runtime dependencies (Windows Defender
must be installed and running; `MpCmdRun.exe` must be in PATH; the
service account needs Defender permissions) that break silently in
container or Linux modernization targets. Emitting a clean inventory
lets Design choose the right replacement (ClamAV, AWS GuardDuty file
scanning, Azure Defender for storage, Microsoft Defender for Cloud)
with full context.

## Inputs
- Repository tree with .NET projects.
- `AMCS/src/AMCS.FileScan/` (canonical case).
- Application catalog entry from `catalog-application`.
- Optional: document-upload flow code in the main web app that calls
  the file-scan project.

## Outputs
- `file-scan-integration-inventory.json` — per file-scan project:
  `{project_name, scanner_type (windows_defender | clamav | sophos |
  custom), entry_point_class, mpcmdrun_path_strategy (hardcoded |
  registry_lookup | env_var | path_search), scan_command_args_template}`.
- `file-scan-call-sites.json` — per caller: `{caller_project,
  caller_file, caller_method, input_file_param, blocking_or_async,
  result_parsing_pattern, timeout_ms, error_handling_summary}`.
- `file-scan-modernization-findings.json` — Windows-only dependency,
  hardcoded paths, unbounded timeouts, move-before-scan race risks,
  service-account permission requirements, recommended replacements
  per target environment.

## Methodology
1. **Locate file-scan projects** by name: `*FileScan*`, `*VirusScan*`,
   `*AntiVirus*`, `*Defender*`, `*MpCmdRun*`.
2. **Find `MpCmdRun.exe` invocations.** Grep for `MpCmdRun`,
   `Process.Start`, `ProcessStartInfo` pairings.
3. **Extract scan command semantics.** Parse the args template:
   `MpCmdRun -Scan -ScanType 3 -File <path>` is the standard form.
   Capture scan type constants, path placeholders, output capture
   flags.
4. **Parse result handling.** `Process.ExitCode` branches,
   `StandardOutput.ReadToEnd()` parsing, regex or line-by-line
   analysis of Defender's output.
5. **Detect sync vs async.** `WaitForExit()` (blocking) vs
   `WaitForExitAsync()` / `await Process.StartAsync(...)`.
6. **Find caller sites.** Every invocation of the scan project's
   public API across the solution.
7. **Emit all three manifests with `{repo}:{file}:{line}`.**

## Tech-Stack Dispatch

| Trigger | Reference loaded |
|---|---|
| `MpCmdRun` or `WindowsDefender` references | `references/defender-scan-integration.md` |

## Gotchas
- **MpCmdRun.exe path is version-specific.** Lives under
  `C:\ProgramData\Microsoft\Windows Defender\Platform\4.18.xxx\MpCmdRun.exe`
  — version subfolder changes with Defender updates. Hardcoded paths
  break after auto-update. Registry-based lookup or dynamic PATH
  search is the robust pattern.
- **Defender service must be running.** If disabled or superseded
  by a third-party AV, MpCmdRun returns unexpected exit codes.
- **Scan is blocking.** A 100MB medical-document scan takes seconds.
  Blocking calls in a request thread cause connection timeouts.
  Flag every blocking scan in a web-request path.
- **Exit codes are poorly documented.** 0 = clean, 2 = failed to
  scan, other codes are version-specific. Don't assume non-zero =
  virus found.
- **Container / Linux targets have no Defender.** Breaks silently
  on modernization to Linux containers. Replacements: ClamAV
  daemon (`clamd`), AWS GuardDuty Malware Protection, Azure
  Defender for Storage.
- **Service-account permissions.** Process account needs Defender
  scan permissions. Usually SYSTEM or an explicitly granted account.
- **Scanner bypass via mv before scan.** Move-then-scan flows race:
  malware can land in final folder before the scanner runs. Flag
  flows that move before scanning.
- **Scan timeout unbounded.** `WaitForExit()` without timeout can
  hang forever. Defensive timeout required.
- **Output parsing fragile.** Defender output format changes
  between versions. Regex-based parsing breaks on upgrade; structured
  output (if available) is safer.
- **Cached scans.** Defender caches recent scan results; re-scanning
  a clean file returns instantly. Harmless, but changes perf
  expectations.

## Quality Rules
- [ ] Every file-scan project has an inventory entry.
- [ ] Path strategy (hardcoded / dynamic) recorded.
- [ ] Every scan call site is inventoried with sync/async and
      timeout.
- [ ] Failure-mode handling documented.
- [ ] Modernization findings include container/Linux gaps with
      recommended replacements.
- [ ] Every record carries `{repo}:{file}:{line}` traceability.

## Common Failure Modes

| Failure Mode | Symptom | Prevention |
|---|---|---|
| Hardcoded MpCmdRun path | After Defender update, path no longer exists; scans fail silently | Detect hardcoded paths; recommend dynamic lookup |
| Unbounded timeout | Large scans hang request threads | Flag `WaitForExit()` without timeout |
| Move-before-scan race | Malware lands in final folder if race wins | Flag flows that move before scanning |
| Silent Linux break | Modernized container has no Defender; uploads fail silently | Emit modernization finding listing replacements |
| Exit code non-zero treated as virus | "Service not available" treated as malware detection | Parse output text, not just exit code |

## Handoff Summary
When this skill completes, verify:
1. Every file-scan project and call site is inventoried.
2. Scanner path handling and failure modes are documented.
3. Modernization findings list target-environment gaps.

Then proceed to: `security-scan-review` — target-side scanner
verification; `module-design` — select target scanner
implementation.

## References
- `references/defender-scan-integration.md` — MpCmdRun CLI
  reference, exit-code catalog, modernization-target comparison.

## Changelog
- 0.1.0 (2026-05-07) — Initial skill. Authored as ATLAS-R-18.
