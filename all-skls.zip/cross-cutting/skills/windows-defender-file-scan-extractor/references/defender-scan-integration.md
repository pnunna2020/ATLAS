# Windows Defender Scan Integration

Coverage for `MpCmdRun.exe` invocation patterns, exit-code
parsing, and modernization targets.

## MpCmdRun.exe CLI Reference

Canonical install paths:

```
C:\Program Files\Windows Defender\MpCmdRun.exe
C:\ProgramData\Microsoft\Windows Defender\Platform\<version>\MpCmdRun.exe
```

The Platform subfolder is version-numbered (e.g., `4.18.25010.3-0`)
and changes on every Defender signature update — often daily.
Hardcoded paths break silently after a signature update.

### Common args

| Args | Purpose |
|---|---|
| `-Scan -ScanType 1` | Quick scan |
| `-Scan -ScanType 2` | Full system scan |
| `-Scan -ScanType 3 -File <path>` | Scan single file |
| `-Scan -ScanType 3 -File <path> -DisableRemediation` | Scan without remediating |
| `-SignatureUpdate` | Update virus definitions |
| `-GetFiles` | Collect diagnostic files |

Typical FAA AAM invocation (AMCS `WindowsDefenderScanner.cs`):

```csharp
var psi = new ProcessStartInfo
{
    FileName = mpCmdRunPath,
    Arguments = $"-Scan -ScanType 3 -File \"{filePath}\" -DisableRemediation",
    UseShellExecute = false,
    RedirectStandardOutput = true,
    RedirectStandardError = true,
    CreateNoWindow = true
};
using var proc = Process.Start(psi);
proc.WaitForExit(timeout);
var exitCode = proc.ExitCode;
var output = proc.StandardOutput.ReadToEnd();
return ParseResult(exitCode, output);
```

## Exit Code Catalog (approximate; version-dependent)

| Exit code | Meaning |
|---|---|
| 0 | No malware found |
| 2 | Command-line error |
| -2147213303 | Malware found (specific threats in output) |
| Other non-zero | Scanner error, service unavailable, path not accessible |

**Rule:** NEVER treat non-zero as "malware detected". Parse stdout
for threat-name strings to confirm detection. Legitimate malware
detections include a `Threat` line identifying the detected
signature name.

## Output Parsing

Sample output (threat found):

```
Scan starting...
Scan finished.
Scanning <file>
found 1 threats.
Threat             : Trojan:Win32/SampleThreat.A
Resources          :
     file         : <file>
```

Sample output (clean):

```
Scan starting...
Scan finished.
Scanning <file>
No threats found.
```

Parse:
- `No threats found.` -> clean.
- `found N threats.` -> malware detected; extract threat names.
- Any output matching `Threat\s+:\s+(\S+)` -> threat signature.
- Output absent or malformed -> scanner error.

## Path-Resolution Strategies

### Hardcoded (fragile)

```csharp
const string MpCmdRunPath = @"C:\Program Files\Windows Defender\MpCmdRun.exe";
```

Fails after Defender moves to Platform subfolder. Flag.

### Registry lookup (robust)

```csharp
using var key = Registry.LocalMachine.OpenSubKey(
    @"SOFTWARE\Microsoft\Windows Defender");
var installPath = (string?)key?.GetValue("InstallLocation");
var mpCmdRunPath = Path.Combine(installPath ?? "", "MpCmdRun.exe");
```

### Dynamic Platform version lookup

```csharp
var platformRoot = @"C:\ProgramData\Microsoft\Windows Defender\Platform";
var latestPlatform = Directory.EnumerateDirectories(platformRoot)
                              .OrderByDescending(p => p)
                              .FirstOrDefault();
var mpCmdRunPath = Path.Combine(latestPlatform ?? "", "MpCmdRun.exe");
```

### PATH search

```csharp
var mpCmdRunPath = Environment.GetEnvironmentVariable("PATH")!
    .Split(';')
    .Select(p => Path.Combine(p, "MpCmdRun.exe"))
    .FirstOrDefault(File.Exists);
```

## Service State Dependencies

- **Defender service must be running.** `sc query WinDefend` returns
  `RUNNING`. If the service is disabled (common when a third-party
  AV is installed), `MpCmdRun` returns errors.
- **Tamper Protection** can block programmatic Defender operations
  on modern Windows 10/11. If Tamper Protection is on, some
  MpCmdRun commands silently fail.
- **Service account permissions.** The process account needs
  Defender scan permissions. Usually `NT AUTHORITY\SYSTEM` works;
  non-admin users may not have permission.

## Modernization Target Comparison

| Target | Replacement | Notes |
|---|---|---|
| .NET Framework on Windows Server | Keep Defender | No change |
| .NET Core / 5+ on Windows Server | Keep Defender | Still works |
| .NET Core on Linux container | ClamAV (`clamd` + `clamdscan` / `clamav-rest`) | Open-source; daemon-based; must be installed in container or sidecar |
| .NET Core on Kubernetes | ClamAV DaemonSet or cloud-native scanning | DaemonSet scans node-mounted volumes; cloud-native runs in peer-service mode |
| AWS ECS/EKS/Lambda | GuardDuty Malware Protection or AWS-native (AWS Malware Protection for S3) | Managed; scan-on-upload for S3 |
| Azure App Service / AKS | Microsoft Defender for Cloud - File scan | Managed; scan-on-upload for Blob |
| GCP Cloud Run / GKE | VirusTotal API or third-party integration | No first-party scan service as of 2026-05 |

### ClamAV integration pattern (Linux container)

```csharp
// Call clamd daemon over UNIX socket or TCP
using var socket = new UnixDomainSocket("/var/run/clamav/clamd.ctl");
socket.Send($"nINSTREAM\n");
// Send file bytes in 2KB chunks prefixed with 4-byte length
...
var response = socket.ReceiveUntilNewline();
// Response: "<filename>: OK" or "<filename>: <Threat.Name> FOUND"
```

### AWS GuardDuty Malware Protection for S3

Scan-on-upload via:
1. Upload to a staging S3 bucket.
2. GuardDuty scans asynchronously.
3. Tag-based result: `GuardDutyMalwareScanStatus = NO_THREATS_FOUND | THREATS_FOUND | FAILED`.
4. App polls tag or receives EventBridge notification.
5. On `NO_THREATS_FOUND`, copy to the final bucket; on `THREATS_FOUND`, delete.

### Azure Defender for Storage

Similar model: upload to staging container, Defender scans,
notification published, app acts on result.

## Performance Notes

- Local MpCmdRun scan of a 10MB file: ~1-3 seconds (first scan)
  / ~0.1 seconds (cached).
- ClamAV `clamdscan` of a 10MB file: ~1-2 seconds.
- AWS GuardDuty: ~minutes (asynchronous; not suitable for
  synchronous upload UX).
- Azure Defender for Storage: similar to GuardDuty.

Synchronous scan is only feasible for local scanners. Cloud-native
scanners require async UX adjustments (upload pending, user
notified when scan completes).

## Integration Checklist

- [ ] MpCmdRun path resolution uses dynamic lookup.
- [ ] Scan call has a timeout.
- [ ] Exit code + stdout both parsed.
- [ ] Service-running check before first scan.
- [ ] Error path distinguishes scanner-error from malware-detected.
- [ ] Move-then-scan flows replaced with scan-then-move.
- [ ] Modernization plan lists the chosen target-environment
      replacement.
