# Portfolio Manifest {portfolio_id}

Generated: {generated_date}
Waves included: {waves_included_count} waves ({wave_id_list})
Total applications: {app_count}

## Executive Summary
{one paragraph}

## Disposition Summary
| Disposition | Count | Percent |
|---|---:|---:|
| Retire | X | XX% |
| Retain | X | XX% |
| Refactor | X | XX% |
| Rearchitect | X | XX% |
| Replace | X | XX% |
| Replatform | X | XX% |
| Consolidate | X | XX% |

## Application Inventory
| Application ID | Name | Risk Tier | Disposition | Wave | Business Criticality |
|---|---|---|---|---|---|
| app-001 | App One | T1 | Refactor | W-1 | mission-critical |

## Wave Sequencing
| # | Wave ID | Start | End | Apps |
|---:|---|---|---|---:|
| 1 | W-1 | YYYY-MM-DD | YYYY-MM-DD | N |

## HCD Summary
- Personas served: X
- Journeys mapped: X
- UX complexity average: X.X / 5

## Section 508 Overview
- Compliant: X
- Non-compliant: X
- Waivers: X
- Average score: XX.X / 100

## Exception Register
| Exception ID | Type | Affected Apps | Approver | Decision Date | Citation |
|---|---|---|---|---|---|

## Sources
- wave-outcome-synthesis: ...
- disposition-recommendation: ...
