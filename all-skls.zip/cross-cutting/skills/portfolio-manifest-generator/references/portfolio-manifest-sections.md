# Portfolio Manifest Sections

Use these section headings and ordering when producing portfolio-manifest.md. The markdown is the sponsor deliverable and must stand alone without JSON context.

## 1. Executive Summary
One paragraph. State: portfolio_id, generated_date, waves_included count, total apps, dominant disposition, headline Section 508 posture, total projected sustainment drawdown percentage.

## 2. Disposition Summary
Table: disposition name - count - percent of portfolio. All seven dispositions listed even if count is zero.

## 3. Application Inventory
Table: application_id, name, risk_tier, disposition, wave_id, business_criticality. Sort by wave_id then application_id.

## 4. Wave Sequencing
Table per wave: sequence_order, wave_id, target_start_date, target_end_date, apps count, link to wave-outcome-synthesis.md.

## 5. HCD Summary
Three rows: personas_served, journeys_mapped, ux_complexity_avg. Paragraph note listing per-wave highlights.

## 6. Section 508 Overview
Four rows: compliant_count, non_compliant_count, waiver_count, avg_score. Short paragraph noting blocking-violation hotspots.

## 7. Exception Register
Table: exception_id, exception_type, affected_apps, approver, decision_date, citation. No filtering - every entry shown.

## 8. Sources
Bullet list of evidence[] citations grouped by source artifact type (wave-outcome-synthesis, disposition-recommendation, ux-overlap-matrix, compliance-assessment, exception-log).

Deviation from this ordering requires a documented rationale in the manifest header - audit teams rely on the fixed section order to locate specific data quickly.
