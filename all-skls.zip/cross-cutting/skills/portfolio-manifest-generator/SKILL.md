---
name: portfolio-manifest-generator
description: >
  Produce the portfolio-level manifest after the last wave of Rationalization
  finishes. Packages the full inventory (app_id, risk_tier, disposition,
  wave), HCD summary, Section 508 overview, wave sequencing, and the
  exception register into a single reviewable packet. Emits both
  portfolio-manifest.json (schema-validated) and portfolio-manifest.md
  (sponsor-facing). Triggers on portfolio manifest, wave sequencing,
  exception register, portfolio readout, or @portfolio-manifest-generator.
agent: opus
allowed-tools:
  - Read
  - Write
  - Grep
---

# portfolio-manifest-generator

## Purpose
Execute the final closeout pass of wave-envelope Rationalization (ART-P1-1) after the last wave in the portfolio completes. Individual wave-outcome-synthesis documents answer what happened this wave; sponsors need to know what happened across the whole portfolio: which apps, in which wave, with what disposition, carrying which exceptions. This skill emits the authoritative machine-readable manifest (portfolio-manifest.json) plus a human-readable packet (portfolio-manifest.md) that mirrors the multi-format export standard the dashboard uses.

## Inputs
- Every wave-outcome-synthesis.json in the portfolio (one per wave).
- Per-app disposition-recommendation.json across all waves.
- Per-app catalog entries (application-catalog-entry.json) for names and business_criticality.
- Per-app compliance-assessment artifacts for Section 508 overview.
- HCD/UX evidence: ux-overlap-matrix.json per wave plus per-app ux-accessibility.json.
- Optional: exception-log.json (policy overrides, compliance waivers, risk acceptances) from governance.

## Outputs
- portfolio-manifest.json - schema at schemas/rationalization/portfolio-manifest.schema.json. Required: portfolio_id, generated_date, waves_included (>=1), app_inventory, disposition_summary, hcd_summary, section_508_overview, wave_sequencing, exception_register, evidence.
- portfolio-manifest.md - sponsor packet. Mirrors the JSON in readable form with executive summary, inventory table, disposition stacked-bar description, per-wave timeline, exception register, and evidence appendix. See references/portfolio-manifest-sections.md for layout.
## Methodology
1. Load every wave-outcome-synthesis.json produced during the portfolio run. waves_included = ordered list of wave_ids in sequence order.
2. Build app_inventory from the union of applications across waves. For each app: application_id, name (from catalog), risk_tier (T1/T2/T3), disposition (one of 7), wave_id, business_criticality.
3. Compute disposition_summary by summing disposition_counts from every wave-outcome-synthesis. The 7-keyset shape must be preserved; every key present even if zero.
4. Compile hcd_summary: personas_served = count of distinct canonical personas across ux-overlap-matrix.json files; journeys_mapped = total fragmented_journeys plus non-fragmented task entries; ux_complexity_avg = arithmetic mean of per-app ux_complexity_score (1-5) rounded to one decimal.
5. Compile section_508_overview. compliant_count plus non_compliant_count from rolled-up per-wave rollups (exclude apps without a 508 assessment). waiver_count counts every exception_register entry with exception_type == compliance-waiver. avg_score is the weighted mean across all apps with a 508 assessment.
6. Populate wave_sequencing. For each wave_id in waves_included: sequence_order (1-based, matches wave_outcome order), target_start_date and target_end_date (from wave metadata), apps[] list. The skill does not schedule - it documents the sequence decided by wave-planner.
7. Compile exception_register. Merge entries from governance exception-log.json (if present) plus any compliance waivers, risk acceptances, or policy overrides flagged in per-app artifacts. Each entry: exception_id, exception_type (policy-override, compliance-waiver, risk-acceptance, other), affected_apps, approver, decision_date, citation.
8. Populate evidence[]. Every summary field must cite the wave-outcome-synthesis or per-app artifact it came from. Target at least one citation per major section.
9. Emit JSON and markdown. See references/portfolio-manifest-sections.md for the exact markdown section order and headings. The markdown is the sponsor deliverable and must be standalone (no external context required to read it).
10. Self-check: disposition_summary sums to len(app_inventory); every app in app_inventory appears in exactly one wave_sequencing[].apps; every waiver citation in exception_register resolves to a real artifact.

## Gotchas
- **Do not emit partial portfolio manifests.** If any wave in the portfolio has not produced wave-outcome-synthesis.json, fail closed and log which wave is missing. A manifest with gaps is non-auditable.
- **App names must come from the catalog, not disposition recommendations.** Disposition artifacts carry the application_id but not necessarily the canonical display name. Prefer application-catalog-entry.name; fall back to application_id if absent (and log a warning).
- **Exception register is append-only across the portfolio.** Never drop an exception because it applies to a retired app - the register is the audit trail.
- **HCD summary averages can hide hotspots.** Always include per-wave personas_served and journeys_mapped in the markdown breakdown; the JSON only carries totals.
- **waves_included ordering matters.** Use sequence_order from wave_sequencing, not alphabetical wave_id. Wave 10 before Wave 2 reads as a bug.
- **Exceptions without approvers are issues.** Any entry missing approver or decision_date should block manifest generation with a clear error - the register is a legal artifact.

## Quality Rules
- [ ] waves_included has >= 1 entry and every wave_id resolves to a wave-outcome-synthesis.json.
- [ ] app_inventory has one entry per application in the portfolio (no duplicates, no gaps).
- [ ] disposition_summary values sum to len(app_inventory) across the seven keys.
- [ ] section_508_overview counts plus waiver_count accounting is consistent (compliant + non_compliant + waiver <= len(app_inventory)).
- [ ] wave_sequencing is ordered by sequence_order ascending; dates are valid ISO-8601 YYYY-MM-DD.
- [ ] exception_register entries all carry approver, decision_date (format date), and citation.
- [ ] evidence[] has at least one citation for each major section (inventory, disposition_summary, hcd_summary, section_508_overview, wave_sequencing, exception_register).
- [ ] JSON validates against schemas/rationalization/portfolio-manifest.schema.json.
- [ ] portfolio-manifest.md lands in the same run folder as the JSON and mirrors every section.

## Common Failure Modes
| Failure Mode | Symptom | Prevention |
|---|---|---|
| App appears in two waves | disposition_summary double-counts; sum > len(app_inventory) | Build a single app-to-wave map before aggregating; assert one-to-one |
| wave-outcome-synthesis missing for a wave | Portfolio manifest silently misrepresents coverage | Fail closed if any wave_id in waves_included lacks a synthesis artifact |
| Exception register drops retired-app waivers | Audit cannot reconstruct why a retired app had a waiver | Treat exception_register as append-only; never filter by disposition |
| Markdown lacks evidence appendix | Sponsors can read the summary but not verify claims | Always append a Sources section referencing the citations in evidence[] |

## Handoff Summary
When this skill completes, verify:
1. Both artifacts exist: portfolio-manifest.json and portfolio-manifest.md.
2. JSON validates against the schema and every section has evidence citations.
3. app_inventory totals reconcile with disposition_summary and with per-wave rosters.

Then the manifest is the final Rationalization output for the portfolio. Downstream: Architecture / Modernization / Disposition Execution consume the per-app disposition plus the wave_sequencing[] to decide what to build next. Governance reviews the exception_register at every gate thereafter.
