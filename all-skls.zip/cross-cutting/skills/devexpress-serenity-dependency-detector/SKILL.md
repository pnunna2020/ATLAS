---
name: devexpress-serenity-dependency-detector
description: >
  Detect commercial third-party UI and data-binding dependencies in a
  legacy .NET Windows / WebForms application — DevExpress (commercial
  WinForms/WebForms/ASP.NET component suite), Serenity (Serenity.Data
  DxDataSource wrapper around DevExpress), wwDataBinder (Rick Strahl's
  open-source WebForms data binder), plus variants like
  `DotnetComponents/`-vendored copies. These dependencies are
  modernization blockers because (a) DevExpress is license-gated and
  expensive per seat, (b) Serenity is a Serenity-only wrapper around
  DevExpress, (c) wwDataBinder is pre-MVC WebForms-specific. None port
  cleanly to .NET Core / modern web stacks. Fires for CPDSS (`Serenity 2/`
  with space, `wwDataBinder.sln` + `wwDataBinder1.sln` sibling pair),
  AMCS (references Report.Client / Serenity / wwDataBinder via
  `..\..\DotnetComponents\`). Runs as a Discovery conditional skill.
  Triggers on DevExpress inventory, Serenity detection, wwDataBinder
  identification, commercial-dependency analysis, or
  @devexpress-serenity-dependency-detector.
agent: sonnet
allowed-tools:
  - Read
  - Write
  - Grep
  - Glob
validation_commands:
  - "python -m olympus.validators.schema_validator devexpress-dependency-inventory.json"
  - "python -m olympus.validators.schema_validator serenity-wrapper-usage.json"
  - "python -m olympus.validators.schema_validator wwdatabinder-binding-sites.json"
  - "python -m olympus.validators.schema_validator commercial-component-findings.json"
supported_stacks:
  - devexpress
  - serenity
  - wwdatabinder
  - dotnetcomponents
  - aspnet-webforms
  - csharp
anti_target_stacks:
  - react
  - angular
  - blazor
  - aspnet-core
  - static-site
failure_classes:
  - devexpress-version-mismatch
  - serenity-vs-devexpress-confused
  - wwdatabinder-bypass-via-raw-binding-missed
  - vendored-dotnetcomponents-cross-repo-missed
  - license-status-unknown
  - winforms-vs-webforms-devexpress-ambiguous
  - per-seat-cost-not-flagged
benchmark_tags:
  - discovery-dependency
  - commercial-component-detection
  - modernization-blocker-inventory
  - devexpress-migration
---

# devexpress-serenity-dependency-detector

## Purpose
Inventory and classify every DevExpress / Serenity / wwDataBinder
usage site in a legacy .NET repo so Rationalization can score the
modernization cost correctly. These dependencies don't port to
.NET Core / modern web stacks; they are commercial license-gated
or pre-MVC WebForms-specific. A modernization plan that misses
them blows the cost estimate and the timeline.

## Inputs
- Repository tree with `.csproj` / `.vbproj` project references.
- `packages.config` / `PackageReference` entries.
- `bin/` folder with DLL references (if vendored binaries).
- `DotnetComponents/` sibling tree (CPDSS) or
  `..\..\DotnetComponents\` relative references (AMCS).
- Application catalog entry from `catalog-application`.

## Outputs
- `devexpress-dependency-inventory.json` — per DevExpress
  reference: `{project, reference_type (PackageReference |
  HintPath | GAC | ProjectReference via wrapper),
  devexpress_version, devexpress_surface (WinForms | WebForms |
  ASP.NET | WPF | Reporting | Dashboard | XPF | DevExtreme), usage_sites[]}`
- `serenity-wrapper-usage.json` — per Serenity usage:
  `{project, serenity_version, component (Serenity.Data.DxDataSource |
  Serenity.Web | other), wraps_devexpress (true/false),
  call_site_file_line}`
- `wwdatabinder-binding-sites.json` — per `wwDataBinder` call:
  `{file_path, method (bind | unbind | validation),
  target_property, source_control}`.
- `commercial-component-findings.json` — per finding: `{project,
  component, license_model (per-seat | per-developer | runtime |
  open-source), estimated_migration_effort_hours,
  modernization_blocker (true/false), recommended_replacement}`.

## Methodology
1. **Scan project references.** Every `.csproj` /`.vbproj` for
   `<Reference Include="DevExpress...">`, `<PackageReference
   Include="DevExpress...">`, `<HintPath>...DevExpress.*.dll</HintPath>`.
   Also `<Reference Include="Serenity*">`, `<Reference
   Include="Westwind.DataBinder">` (the proper namespace) /
   `<Reference Include="wwDataBinder">`.
2. **Resolve vendored component tree.** CPDSS ships the authoritative
   `DotnetComponents/` tree; AMCS references it via
   `..\..\DotnetComponents\`. Resolve the reference path and confirm
   the producer repo vs consumer repos.
3. **Detect usage sites per dependency.** Grep `.cs`/`.vb`/`.aspx` for:
   - `DevExpress.Web.*`, `DevExpress.XtraGrid.*`, `DevExpress.Data.*`
   - `Serenity.Data.DxDataSource`, `Serenity.Web.*`
   - `Westwind.DataBinder.wwDataBinder`, `bindingFactory.wwDataBinder.*`
4. **Classify DevExpress surface.** `.Web` = WebForms/ASP.NET,
   `.XtraGrid`/`.XtraEditors` = WinForms, `.WPF` = WPF,
   `.XtraReports` = DevExpress Reporting (separate license).
5. **Detect Serenity-vs-DevExpress.** Serenity is often confused
   with just DevExpress. Serenity wraps DevExpress components with
   its own data-source abstraction. `Serenity.Data.DxDataSource`
   is the tell — it consumes DevExpress under the hood.
6. **Extract version.** Version from PackageReference, from HintPath
   filename (`DevExpress.XtraGrid.v14.2.dll`), from
   `AssemblyInformationalVersionAttribute` on the DLL if vendored.
7. **Estimate migration effort.** Per-component, per-site, based on
   surface area (WinForms grid replacement is ~2h per grid; DxDataSource
   wrapped lookup ~1h per site; wwDataBinder binding ~0.5h per
   site; DevExpress reports ~4-8h per report).
8. **Emit all four manifests with `{repo}:{file}:{line}`.**

## Tech-Stack Dispatch

| Trigger | Reference loaded |
|---|---|
| Any DevExpress / Serenity / wwDataBinder reference | `references/commercial-component-inventory-patterns.md` |

## Gotchas
- **DevExpress is per-seat per-developer licensed.** ~$1.5-3k/dev/year
  at list. Cost implication for modernization: every developer who
  touches the legacy code needs a license.
- **DevExpress WinForms ≠ DevExpress Web.** Same vendor, different
  SKUs, different migration targets. WinForms migrates to MAUI/WPF
  or a web app rewrite; Web migrates to DevExtreme (DevExpress's
  modern JS stack) or a non-DevExpress rewrite.
- **Serenity is NOT DevExpress.** Serenity is an open-source (but
  commercial Serenity Pro) framework that uses DevExpress
  underneath. Detecting Serenity without detecting DevExpress
  misses half the picture.
- **wwDataBinder is open source but dead.** Rick Strahl's WebForms
  data-binding helper; last release ~2013. Ports to modern stacks
  require removal + rewrite.
- **`..\..\DotnetComponents\` references are cross-repo.** AMCS's
  `AMCS.NET/AMCS.sln` references CPDSS's DotnetComponents tree.
  In a CI runner that clones only AMCS, the build fails. Emit
  finding.
- **`Serenity 2/` has a space in the folder name.** CPDSS's
  directory. Legacy from a pre-Serenity-2 rename that was never
  cleaned up. Preserve verbatim.
- **`wwDataBinder.sln` + `wwDataBinder1.sln` coexist.** CPDSS
  DotnetComponents. Intra-repo drift; flag, but do not auto-dedupe.
- **DevExpress version gap.** Repos often carry 2-3 versions of
  DevExpress across projects (v14, v17, v22 — often). Each
  version upgrade has its own migration notes; don't assume all
  are on the same version.
- **License status is rarely in source.** A repo with
  `DevExpress.dll` references may have no valid runtime license;
  modernization must confirm with the licensing owner.
- **DevExtreme vs DevExpress.** DevExtreme is DevExpress's
  JavaScript component suite (React, Angular, Vue). Migrating to
  DevExtreme is the vendor-recommended path for DevExpress Web
  apps, but remains license-gated.

## Quality Rules
- [ ] Every project with a DevExpress reference has an inventory
      entry with version + surface + usage-site count.
- [ ] Serenity detected separately from DevExpress; overlap
      recorded.
- [ ] wwDataBinder sites enumerated.
- [ ] Cross-repo `DotnetComponents/` references flagged with
      producer + consumer repos.
- [ ] License model and modernization blocker status per
      component.
- [ ] Estimated migration effort per component.
- [ ] Every record carries `{repo}:{file}:{line}`.

## Common Failure Modes

| Failure Mode | Symptom | Prevention |
|---|---|---|
| Serenity detected but DevExpress missed | Manifest shows Serenity; DevExpress runtime silently required at deploy | Detect DevExpress via transitive reference (Serenity's DxDataSource wraps DevExpress) |
| DevExpress version hardcoded as one value | Repo has v14 in one project and v22 in another; modernization plans for v22 only | Emit version per project, not per repo |
| Cross-repo DotnetComponents missed | AMCS build fails in CI because CPDSS's `DotnetComponents/` not sibling-cloned | Detect `..\..\DotnetComponents\` relative paths; emit finding with producer repo |
| wwDataBinder bypass via raw binding | Code uses both wwDataBinder AND direct `ctrl.Text = dataRow["foo"]`; only wwDataBinder enumerated | Grep for ADO.NET binding alongside wwDataBinder |

## Handoff Summary
When this skill completes, verify:
1. Every DevExpress reference is inventoried with version and
   surface.
2. Serenity usage is separated from raw DevExpress usage.
3. wwDataBinder sites are counted for migration effort.
4. Cross-repo DotnetComponents dependencies are resolved to
   producer/consumer repos.
5. License model and migration effort per component.

Then proceed to: `tco-analyzer` (Rationalization supplementary) —
which uses the license + migration-effort data for total-cost-of-
ownership projections; `disposition-recommender` — which considers
commercial-dependency load when recommending Rearchitect vs Retain.

## References
- `references/commercial-component-inventory-patterns.md` —
  DevExpress/Serenity/wwDataBinder detection patterns, license
  model matrix, version detection, migration-effort estimation.

## Changelog
- 0.1.0 (2026-05-07) — Initial skill. Covers DevExpress, Serenity,
  wwDataBinder detection. Authored as ATLAS-R-18.
