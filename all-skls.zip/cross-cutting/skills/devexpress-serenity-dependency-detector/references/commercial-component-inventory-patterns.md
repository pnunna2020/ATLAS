# Commercial Component Inventory Patterns

Coverage for detecting and classifying commercial UI/data
components in legacy .NET projects: DevExpress, Serenity,
wwDataBinder, plus ancillary commercial dependencies.

## DevExpress Detection

### Reference patterns

```xml
<!-- PackageReference (modern) -->
<PackageReference Include="DevExpress.Win.Design" Version="22.2.4" />
<PackageReference Include="DevExpress.Web" Version="22.2.4" />

<!-- HintPath (legacy) -->
<Reference Include="DevExpress.XtraGrid.v14.2">
  <HintPath>..\lib\DevExpress.XtraGrid.v14.2.dll</HintPath>
</Reference>

<!-- GAC reference (rare but real) -->
<Reference Include="DevExpress.XtraEditors.v14.2, Version=14.2.4.0, Culture=neutral, PublicKeyToken=b88d1754d700e49a" />
```

### Surface classification

| Namespace | Surface | Modernization target |
|---|---|---|
| `DevExpress.XtraGrid.*` | WinForms | .NET MAUI DataGrid / Syncfusion / community alternatives |
| `DevExpress.XtraEditors.*` | WinForms | .NET MAUI / WPF ModernWpf |
| `DevExpress.XtraBars.*` | WinForms docking / ribbons | WPF RibbonControl / custom |
| `DevExpress.XtraReports.*` | Reporting (separate SKU) | Fast Reports / Telerik Reporting / SSRS |
| `DevExpress.Web.*` | ASP.NET WebForms | React / Blazor / Angular rewrite |
| `DevExpress.ExpressApp.*` | XAF (eXpressApp Framework) | Full rewrite; XAF has no direct migration |
| `DevExpress.Mvvm.*` | MVVM helpers | CommunityToolkit.Mvvm / ReactiveUI |
| `DevExpress.Xpf.*` | WPF | Keep WPF or port to MAUI |
| `DevExpress.Data.*` | Data binding | Replace with EF Core / direct data binding |
| `DevExtreme*` | JavaScript SPA components | DevExtreme modern stack OR community alternatives |

### Version extraction

- From `PackageReference Version="..."`.
- From HintPath filename: `DevExpress.XtraGrid.v14.2.dll` ->
  version 14.2.
- From DLL metadata: `AssemblyInformationalVersionAttribute`.
- From `System.Diagnostics.FileVersionInfo` at runtime.

Common versions in FAA AAM apps: v14.2 (2014), v17.2 (2017),
v22.2 (2022). Emit version per project — a repo may carry
multiple.

### Usage-site counting

Grep for namespace-prefixed types:

```
grep -r "DevExpress\.XtraGrid\." --include="*.cs" --include="*.vb" --include="*.aspx"
grep -r "DevExpress\.Web\." --include="*.cs" --include="*.aspx"
```

Count unique files and unique types. Emit per component.

## Serenity Detection

Serenity is an open-source (MIT) framework that WRAPS DevExpress
for its data-source abstraction. Distinguishing:

```xml
<Reference Include="Serenity.Data" />
<Reference Include="Serenity.Web" />
```

Usage pattern (`Serenity.Data.DxDataSource`):

```csharp
using Serenity.Data;
// Serenity's wrapper around DevExpress GridView with data-binding
public class DxDataSource { ... }
```

**Key insight:** Serenity.Data.DxDataSource REQUIRES DevExpress
at runtime. If a repo uses Serenity but the DevExpress reference
is missing, the build will fail at compile time OR runtime. Emit
as a transitive-DevExpress dependency even if DevExpress is not
explicitly referenced.

CPDSS case: `src/DotnetComponents/Serenity 2/Serenity.sln`
contains a Serenity 2.x version — the folder name has a literal
space, preserved verbatim from the original delivery.

### Serenity Pro

There's also Serenity Pro (commercial, ~$1.5k/dev/year) —
different from the open-source Serenity. Detection:

- Reference to `Serenity.Pro.*` assemblies.
- License file at `Serenity.lic`.

Flag as commercial if Serenity.Pro namespaces appear; otherwise
assume open-source.

## wwDataBinder Detection

Rick Strahl's WebForms data binder. Open-source, dead project
(last update ~2013). Reference:

```xml
<Reference Include="Westwind.wwDataBinder">
  <HintPath>..\lib\Westwind.wwDataBinder.dll</HintPath>
</Reference>
```

Or a project reference to the vendored CPDSS `wwDataBinder/`
tree.

### Usage sites

```csharp
using Westwind.wwDataBinder;

public partial class MyPage : System.Web.UI.Page
{
    wwWebDataBinder Binder = new wwWebDataBinder();

    protected void Page_Load(object sender, EventArgs e)
    {
        Binder.Page = this;
        Binder.AddBinding(txtFirstName, "Text", Applicant, "FirstName");
        Binder.AddBinding(txtLastName, "Text", Applicant, "LastName");

        if (!IsPostBack)
            Binder.DataBind();
    }

    protected void BtnSave_Click(object sender, EventArgs e)
    {
        Binder.Unbind();
        if (Binder.BindingErrors.Count == 0)
            ApplicantRepo.Save(Applicant);
    }
}
```

Sites to extract:

- `new wwWebDataBinder()` instantiations.
- `.AddBinding(control, property, source, sourceProperty)` calls.
- `.DataBind()` / `.Unbind()` / `.BindingErrors.Count` usage.
- Validation patterns (optional regex + error messages per binding).

CPDSS has `wwDataBinder.sln` + `wwDataBinder1.sln` + a `Backup/`
folder — three variants of the same project in one directory.
Intra-repo drift; flag separately from cross-repo drift.

## DotnetComponents Cross-Repo Pattern

CPDSS ships the canonical `src/DotnetComponents/` tree:

```
CPDSS/
└── src/
    └── DotnetComponents/
        ├── Notes.Client/
        ├── Security.Client/
        ├── Serenity 2/             # folder name has a space
        └── wwDataBinder/
            ├── wwDataBinder.sln
            ├── wwDataBinder1.sln    # sibling variant
            └── Backup/              # in-tree VSS-era backup
```

AMCS's `AMCS.NET/AMCS.sln` references these via:

```
..\..\DotnetComponents\Report.Client\Reports.Client.csproj
..\..\DotnetComponents\Serenity 2\Serenity.csproj
..\..\DotnetComponents\wwDataBinder\wwDataBinder.csproj
```

**Rule:** detect every `..\..\DotnetComponents\` reference.
The build assumes CPDSS is a sibling checkout; without it,
the reference fails. Emit finding listing producer (CPDSS) +
consumer (AMCS, etc.) + required checkout layout.

## License Model Matrix

| Component | License model | Approximate cost | Modernization implication |
|---|---|---|---|
| DevExpress (Universal) | Per-developer/year | $1.5-3k | Preserve budget; or rewrite |
| DevExpress (WinForms only) | Per-developer/year | ~$1k | Same |
| DevExpress DevExtreme | Per-developer/year | ~$1k | Migration path for Web apps |
| DevExpress Reporting | Per-developer/year (separate) | ~$1.5k | Often retained alongside modernization |
| Serenity (OSS) | MIT | $0 | Free; still requires DevExpress under the hood |
| Serenity Pro | Per-developer/year | ~$1.5k | Distinguish from OSS Serenity |
| wwDataBinder | OSS (dead) | $0 | No modernization path; remove + rewrite |
| Telerik | Per-developer/year | $1-3k | Possible DevExpress alternative |
| Syncfusion | Free (small teams) to $1-2k/year | Varies | Modern alternative |
| Infragistics | Per-developer/year | $1-2k | Another commercial grid option |

## Migration-Effort Estimation

Rough heuristics per usage site:

| Component | Per-site effort |
|---|---|
| DevExpress XtraGrid | 2-4h (replacement grid + data binding) |
| DevExpress XtraEditors (textbox, combo, date) | 0.25-0.5h each |
| DevExpress Web (GridView, Editors) | 2-4h each |
| DevExpress XtraReports | 4-8h per report (re-author in target) |
| DevExpress XtraCharts | 2-4h (swap charting lib) |
| Serenity DxDataSource | 1-2h per site (replace with EF Core / DTO binding) |
| wwDataBinder binding | 0.25-0.5h per binding (remove; use model binding) |
| wwDataBinder page wiring | 2-4h per page (full binding-logic rewrite) |

Sum per project + per repo. The `tco-analyzer` skill consumes
these estimates.

## Detection Pseudocode

```python
def detect_commercial_components(repo_path):
    for csproj in glob(f"{repo_path}/**/*.{csproj,vbproj}"):
        refs = parse_references(csproj)

        devexpress = [r for r in refs if r.name.startswith("DevExpress")]
        serenity   = [r for r in refs if r.name.startswith("Serenity")]
        wwdb       = [r for r in refs if r.name in ("Westwind.wwDataBinder", "wwDataBinder")]

        if devexpress or serenity or wwdb:
            emit_project_entry(csproj, devexpress, serenity, wwdb)

    # Cross-repo DotnetComponents references
    for csproj in glob(f"{repo_path}/**/*.{csproj,vbproj}"):
        content = read(csproj)
        if re.search(r'\.\.\\\.\.\\DotnetComponents\\', content):
            emit_dotnetcomponents_dep(csproj)

    # Usage sites in source
    for src in glob(f"{repo_path}/**/*.{cs,vb,aspx}"):
        content = read(src)
        for ns in ['DevExpress.', 'Serenity.', 'Westwind.wwDataBinder']:
            for match in re.finditer(rf'{ns}[A-Za-z]+', content):
                emit_usage_site(src, match)
```

## Output Inventory Shape

```json
{
  "projects": [
    {
      "project_path": "CPDSS/src/CPDSS/CPDSS.csproj",
      "references": [
        {"name": "DevExpress.XtraEditors.v14.2", "type": "HintPath", "version": "14.2"},
        {"name": "Serenity.Data", "type": "ProjectReference", "via": "..\\..\\DotnetComponents\\Serenity 2\\Serenity.csproj"}
      ],
      "usage_sites": 87,
      "estimated_migration_hours": 120
    }
  ],
  "findings": [
    {
      "severity": "P1",
      "category": "cross-repo-dependency",
      "message": "AMCS references CPDSS's DotnetComponents tree",
      "consumer": "AMCS/src/AMCS.NET/AMCS.sln",
      "producer": "CPDSS/src/DotnetComponents/"
    }
  ]
}
```
