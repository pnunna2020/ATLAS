# Vendored Shared Library Patterns

Reference for `shared-encryptor-drift-detector`. Catalogs the four ways a
shared library ends up in multiple repos, how to detect each, the drift
mechanics, and the operational trade-offs that drive the consolidation
recommendation.

## The four patterns

### 1. Copy-paste vendoring

A developer copies the project directory from a source repo into each
consumer repo and commits it. No dependency manager is involved. Each
copy evolves under its own history and drifts independently.

Detection markers:
- The same `<ProjectGuid>` appears in 2+ repos with no `<PackageReference>`
  resolving it.
- Consumer `.csproj` files use
  `<ProjectReference Include="Encryptor\Encryptor.csproj" />` pointing to
  a sibling directory in the same repo.
- The shared project lives under the consumer's own `src/` tree
  (e.g. `src/CPDSS/Encryptor/`), not under `lib/` or `packages/`.
- No `.gitmodules` entry names the shared directory.

ATLAS fit: `Encryptor` with GUID `{CDE7B678-E3B9-45D4-8E69-FC33179DDFB5}`
is copy-paste-vendored into CPDSS, CHAPS, AMCS, and MEDXPRESS. No shared
NuGet feed. Four copies, diverged from a common ancestor.

Trade-offs:
- Pro: zero build-time dependency on other repos; self-contained builds.
- Con: bug fixes applied N times; drift guaranteed on first independent
  edit; security-critical code in this pattern cannot be atomically
  patched.

### 2. Git submodule

A shared library repo is referenced as a submodule in each consumer.
The submodule commit SHA pins each consumer to a specific version.

Detection markers:
- `.gitmodules` entry naming the shared directory.
- The submodule directory contains its own `.git` file pointing to a
  separate repo.
- Consumer `.csproj` files reference into the submodule via relative
  path.

Trade-offs:
- Pro: shared history preserved; each consumer's SHA records exactly
  which version it depends on.
- Pro: patches land in the submodule and propagate via SHA bumps.
- Con: SHA bumps are manual; lag is invisible.
- Con: shallow-clone CI breaks the reference.

### 3. Monorepo sibling

Shared library and all consumers live in a single repo. One source of
truth; no copies.

Detection markers:
- All consumers and the shared project live under the same repo root.
- `<ProjectReference Include="..\..\Shared\Encryptor\Encryptor.csproj" />`
  paths resolve within the repo.
- No `.gitmodules` and no duplicated `<ProjectGuid>`.

Trade-offs:
- Pro: atomic patches — one commit updates the library and every
  consumer.
- Pro: no drift.
- Con: requires org-wide monorepo discipline; does not fit multi-team
  independently-deployable units.

### 4. Package feed (internal NuGet)

The library is published as a NuGet package to an internal feed (Azure
Artifacts, MyGet, JFrog). Consumers reference via `<PackageReference>`.

Detection markers:
- `<PackageReference>` entries resolve the library.
- A `nuget.config` names the internal feed.
- No source code for the library appears in any consumer repo.

Trade-offs:
- Pro: atomic patch distribution via publish + version bump.
- Pro: semver discipline possible.
- Pro: the target end state for security-critical libraries.
- Con: feed infrastructure and publish pipeline required.
- Con: private-feed authentication in CI must be configured.

## Detection order

When classifying a shared GUID, apply in order:

1. Any `<PackageReference>` to an internal feed -> `package-feed-mirror`
   (not a drift surface).
2. `.gitmodules` names the shared directory in any consumer ->
   `git-submodule`.
3. All consumers and the producer live under one repo root ->
   `monorepo-sibling`.
4. Otherwise -> `copy-paste` (the drift surface the skill fires on).

## Drift mechanics

### Silent drift

Byte-level divergence that produces observably different runtime
behavior but no compile-time failure. Most dangerous.

Example: one copy of `Encryptor.cs` increases the PBKDF2 iteration count
from 1000 to 10000 to address a 2018 advisory; other copies stay at
1000. Cross-app data written by the new copy may be unreadable by old
copies, or silently readable during a transition then broken later.
Detection requires semantic diff, not byte diff alone.

### Loud drift

Byte-level divergence that breaks the build when copies are merged. A
new method signature added in one copy is called from that consumer's
code; merging copies later breaks consumers on the old copy. Annoying
but visible.

### Cosmetic drift

Byte-level divergence with no semantic impact: comments, whitespace,
XML doc formatting. AST/IL identical. Drift metrics without semantic
diff overstate severity.

### Structural drift

Files added, removed, or renamed in one copy but not others. Reflects
feature branches that landed in one consumer's copy and never propagated
back. Consolidation requires merging the additions to the canonical copy
or accepting the divergence.

## Relative-path cross-repo references

Copy-paste vendoring sometimes coexists with relative-path references
that cross repo boundaries in a multi-repo checkout:

```
<ProjectReference Include="..\..\..\DotnetComponents\Security.Client\Security.Client.csproj" />
```

The `..\..\..\` walks up from the consumer project folder to the parent
of all repos, then down into the producer repo. Works only when repos
are cloned as siblings. CI cloning a single repo breaks.

AAM fit: CPDSS ships `src/DotnetComponents/` with `Notes.Client`,
`Security.Client`, `Serenity 2/`, and `wwDataBinder`. AMCS's
`AMCS.NET/AMCS.sln` references these with `..\..\DotnetComponents\`. The
CPDSS README declares CPDSS the canonical home. A CI runner that clones
only AMCS cannot resolve the reference.

Detection:
- Grep every consumer `.csproj`/`.vbproj` for `ProjectReference` paths
  with 2+ `..\` segments.
- Resolve each hit against the expected sibling layout (parent of the
  consumer repo root).
- Path landing in another portfolio repo -> `consumer -> producer` edge.
- Path not landing in any producer -> `orphaned_consumer` finding.

## Anti-patterns to flag

- **Two `.sln` siblings for one project** (CPDSS's `wwDataBinder.sln`
  and `wwDataBinder1.sln` in the same folder). Intra-repo drift
  precursor — flag at lower severity, do not silence.
- **`HintPath` pointing outside the repo.** Binary vendored as DLL
  under `ThirdPartyDLLs/` or `lib/`. Drift analysis applies via binary
  hash; remediation is different (locate source, rebuild, or replace).
- **Copy under `src/` vs copy under `packages/`.** `src/` contents are
  owned code. `packages/` contents are NuGet restore outputs — not
  drift surfaces.
- **Shared library without a declared owner** (no README, no CODEOWNERS,
  no top-of-file attribution). Consolidation requires an owner; emit a
  process finding.

## Pattern-to-recommendation mapping

| Current pattern | Criticality | Recommendation |
|---|---|---|
| copy-paste | security-critical | publish-to-internal-nuget |
| copy-paste | business-critical | publish-to-internal-nuget or consolidate-to-single-repo |
| copy-paste | utility | consolidate-to-single-repo or accept-drift |
| git-submodule | security-critical | publish-to-internal-nuget (tighter cadence) |
| git-submodule | any other | retain; confirm SHA bump cadence |
| monorepo-sibling | any | retain; no action |
| package-feed-mirror | any | retain; confirm version-pin hygiene |

`accept-drift` is rare and valid only when the copies are provably
independent (shared ancestry but now genuinely separate libraries with
different purposes), the library is not security-critical, and the cost
of consolidation outweighs the drift risk. Most findings should pick a
more active remediation.
