# Project GUID Drift Analysis

Reference for `shared-encryptor-drift-detector`. Defines the mechanics of
joining `.csproj`/`.vbproj` projects across repos by project GUID, the
fallback keys when GUID is unreliable, the diff strategies, the
security-criticality heuristics, and the consolidation effort estimate.

## Project GUID extraction

Every VS project file carries a `<ProjectGuid>` — a 128-bit identifier
assigned at project creation, intended to be stable across the
project's lifetime.

### Legacy `.csproj`/`.vbproj`

Legacy (non-SDK-style) projects declare the GUID explicitly inside a
`<PropertyGroup>`:

```
<ProjectGuid>{CDE7B678-E3B9-45D4-8E69-FC33179DDFB5}</ProjectGuid>
```

Extract with XPath or an anchored regex. Normalize to uppercase-hex
with dashes and surrounding braces.

### SDK-style `.csproj`

SDK-style projects (`<Project Sdk="Microsoft.NET.Sdk">`) frequently
omit `<ProjectGuid>`. The solution file (`*.sln`) holds the GUID in the
project-declaration line. The third GUID in
`Project("{project-type-guid}") = "Name", "path", "{project-guid}"` is
the project's own GUID — the join key.

## Cross-repo join

1. Per-repo index: for every `.csproj`/`.vbproj`, record
   `(project_guid, project_name, project_path, repo_path,
   source_file_count, source_file_hash_list)`.
2. Group by `project_guid` across repos.
3. Any GUID appearing in 2+ distinct `repo_path` values is a cross-repo
   shared-library candidate.

## Secondary-key fallbacks

Primary GUID join is most reliable. Use these only when GUID is
unreliable or absent.

### Name + file-byte-hash

Hash the concatenated content of every `.cs`/`.vb` file under the
project directory, sorted by relative path. Two projects with the same
name and identical aggregate hash are the same project even if GUIDs
diverged. Use when SDK-style projects lack `<ProjectGuid>` and no
sln-file entry, when VS silently re-assigned a GUID, or when a project
was copy-pasted and renamed.

### Name + compile-unit-hash

Hash the IL output after compilation. Catches cosmetic-only edits that
preserve semantics. Requires a build step; mark
`semantic_diff_available = false` when unavailable.

### Top-of-file declarations

`RootNamespace` and `AssemblyName` in the `.csproj` are weak secondary
identifiers, useful to corroborate a GUID-based join.

## GUID-mutation detection

A silent GUID change (typically a buggy VS save) makes the cross-repo
join miss. Emit a diagnostic when:

- The secondary key joins two projects but the primary GUID does not.
- A single repo has two `.csproj` files with the same name but
  different GUIDs in git history.

The diagnostic carries both observed GUIDs and the secondary key. This
is the `guid-collision-false-positive` prevention path.

## Diff strategies

### Byte-level diff

Compare SHA-256 hashes of source files. Fast and mechanical; overstates
severity on comment- or whitespace-only edits. Default first pass.

### AST-level diff

Parse each file into an AST (Roslyn for C#, equivalent for VB.NET) and
compare. Classify drifted files as `cosmetic-only` (AST identical,
bytes different), `structural` (AST differs), or `added`/`removed`
(file in one copy only). When available, set
`semantic_diff_available = true` and emit
`semantic_divergent_file_count`.

### IL-level diff

Build each project and compare emitted IL. Captures any runtime
difference, ignores formatting. Most accurate and most expensive
(requires a successful build). Reserve for the top of the drift
ranking — typically security-critical only.

## Security-criticality classification

Classify as security-critical when any of the following fires.

### Namespace markers

Match `RootNamespace` or any namespace against `*.Encryptor`,
`*.Encryption`, `*.Crypto`, `*.Cryptography`, `*.Security.*`,
`*.Signing`, `*.Signature`, `*.Sanitization`, `*.Sanitizer`,
`*.Input.Validation`, `*.Auth`, `*.Authentication`, `*.Authorization`,
`*.Identity`. Any match fires.

### Crypto-primitive usage

Grep source for: `AesManaged`, `AesCng`, `RijndaelManaged`,
`RSACryptoServiceProvider`, `RSA`, `ECDsa`, `HMACSHA1`/`HMACSHA256`/
`HMACSHA512`, `PasswordDeriveBytes`, `Rfc2898DeriveBytes`,
`System.Security.Cryptography.*`, `ProtectedData`, `ProtectedMemory`,
`X509Certificate2`, `X509Store`. Two or more hits fires even when the
namespace is generic.

### Purpose markers

Top-of-file or class comments containing `// encrypt`, `// decrypt`,
`// cipher`, `// sign`, `// verify`, `// sanitize`, `// password`,
`// credential`, `// secret`. Weakest signal — require corroboration
from namespace or primitive usage.

### Cross-app data-exchange coupling

If the shared project encrypts or signs data persisted to a schema
shared by multiple apps, fire at elevated severity. ATLAS case: four
AAM apps exchange airman records via the shared MSS Oracle schema, and
encrypted fields must be readable by every consumer. Detection: locate
the output of encrypt methods, trace to the persistence call, and
check whether the target table is referenced by any other app in the
portfolio.

## Consolidation-effort estimation

Per-consumer effort to migrate from `<ProjectReference>` to
`<PackageReference>`:

| Step | Typical hours |
|---|---|
| Remove `<ProjectReference>` and add `<PackageReference>` | 0.2 |
| Delete copy of source from consumer repo | 0.2 |
| Verify namespace imports still resolve | 0.5 |
| Fix build breaks | 0.5 to 4 |
| Configure CI to auth to internal feed (one-time per repo) | 1 to 2 |
| Merge consumer's divergent edits back to canonical | 0 to 16 |

Clean case (no divergence): 2-4 hours per consumer. Divergent case
(independently patched copy): 8-24 hours.

For `Encryptor` across the four AAM repos, working estimate is 8-12
hours per consumer: each copy has accumulated edits over years and must
be merged or discarded, and the package must be versioned so every
consumer lands on the same version before atomic patching is real.

## Canonical-home confirmation

The canonical home must be confirmed, not guessed. Signals in decreasing
strength:

1. Explicit declaration in README/team doc ("CPDSS owns DotnetComponents").
2. Project ownership metadata (OWNERS, CODEOWNERS).
3. Commit-date lead: canonical copy has the earliest first-commit date.
4. Reference direction: the copy referenced via `..\..\` from others is
   likely the producer.
5. File count lead: canonical carries the full tree; consumer copies
   often omit tests or docs.

Without an explicit declaration, emit a finding requiring the team to
declare before migration. Picking arbitrarily is the
`canonical-home-guessed` failure class.

## Output field cross-reference

| Output field | Source |
|---|---|
| `guid` | `<ProjectGuid>` or sln-file third GUID |
| `project_name` | `<AssemblyName>` or file stem |
| `repo_paths[]` | per-repo index group-by |
| `last_commit_per_repo` | `git log -n1 -- <project-dir>` per copy |
| `primary_key_source` | `guid` or secondary key |
| `identical_file_count` / `drifted_file_count` | hash comparison per pair |
| `divergent_bytes` | sum of per-file byte differences |
| `security_classification` | namespace + primitive + purpose + coupling |
| `canonical_home_repo` | declaration or diagnostic finding |
| `recommendation` | criticality + vendoring pattern |
| `composite_score` | sum of the four component scores |

Every output field must trace to a concrete `{repo}:{file}:{line}`
citation. Fields without citation are auto-rejected by the validator.
