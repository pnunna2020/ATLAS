---
name: shared-encryptor-drift-detector
description: >
  Detect cross-repo vendored shared libraries in a portfolio by joining
  `.csproj`/`.vbproj` project GUIDs across application manifests, then
  classify and rank the resulting drift. Fires as a Rationalization-phase
  portfolio-scoped skill whenever `analyze-portfolio-redundancy` flags
  the same GUID in two or more repos with no shared package feed. Emits
  shared-project-guid inventory, pairwise drift matrix, security-critical
  drift findings, DotnetComponents reference graph, consolidation plan,
  and drift severity ranking, all carrying `{repo}:{file}:{line}`
  traceability. Built against ATLAS: the `Encryptor` project with GUID
  `{CDE7B678-E3B9-45D4-8E69-FC33179DDFB5}` is vendored into CPDSS, CHAPS,
  AMCS, and MEDXPRESS with no package feed. Triggers on vendored-library
  discovery, shared-GUID detection, cross-repo drift analysis, or
  @shared-encryptor-drift-detector.
agent: sonnet
allowed-tools:
  - Read
  - Write
  - Grep
  - Glob
  - Bash
validation_commands:
  - "python -m olympus.validators.schema_validator shared-project-guid-inventory.json"
  - "python -m olympus.validators.schema_validator vendored-library-drift-matrix.json"
  - "python -m olympus.validators.schema_validator security-critical-drift-findings.json"
  - "python -m olympus.validators.schema_validator dotnetcomponents-reference-graph.json"
  - "python -m olympus.validators.schema_validator consolidation-plan.json"
  - "python -m olympus.validators.schema_validator drift-severity-ranking.json"
supported_stacks:
  - dotnet
  - csharp
  - vbnet
anti_target_stacks:
  - static-site
  - pure-cdn-asset
  - mainframe
failure_classes:
  - guid-collision-false-positive
  - name-only-join
  - cosmetic-drift-overclassified
  - security-classification-missed
  - canonical-home-guessed
  - relative-path-unresolved
benchmark_tags:
  - rationalization-portfolio-redundancy
  - vendored-library-drift
  - security-critical-consolidation
  - cross-repo-guid-join
---

# shared-encryptor-drift-detector

## Purpose
Detect vendored shared libraries whose copies have drifted across a
multi-repo portfolio. When an organization copy-pastes a shared library
into every consumer repo instead of publishing to an internal package
feed, each copy becomes an independent drift surface. For security-
critical libraries — PII encryption, auth, signing, sanitization — an
emergency patch to one copy does not propagate, and cross-app data
exchange can silently produce undecryptable records. This skill joins
`.csproj`/`.vbproj` project GUIDs across every application manifest,
diffs the copies, classifies security criticality, resolves the
producer/consumer graph for relative-path references, and emits a
ranked consolidation plan. ATLAS's `Encryptor` (GUID
`{CDE7B678-E3B9-45D4-8E69-FC33179DDFB5}`) vendored into CPDSS, CHAPS,
AMCS, and MEDXPRESS is the motivating case.

## Inputs
- Portfolio application manifests — one per app in scope.
- Per-app `.NET` fingerprints from `dotnet-discovery-patterns` — the
  GUID-join surface, listing every `.csproj`/`.vbproj` with
  `<ProjectGuid>`, project name, and file list.
- Cross-repo file inventory — path, byte size, SHA-256, last-commit
  metadata per file under every project directory.
- Portfolio-redundancy trigger from `analyze-portfolio-redundancy`.
- Security-criticality classifier: `references/project-guid-drift-analysis.md`.
- Vendoring patterns: `references/vendored-shared-library-patterns.md`.
- Optional: internal NuGet feed inventory to confirm absence of a
  published package.

## Outputs
- `shared-project-guid-inventory.json` — every GUID in 2+ repos:
  `{guid, project_name, repo_paths[], file_count_per_repo,
  last_commit_per_repo, vendoring_pattern, primary_key_source}`.
- `vendored-library-drift-matrix.json` — pairwise diff per GUID:
  `{guid, repo_pair, identical_file_count, drifted_file_count,
  added_in_a[], added_in_b[], divergent_bytes,
  semantic_diff_available, semantic_divergent_file_count}`.
- `security-critical-drift-findings.json` — elevated rows for
  security-classified projects: `{guid, project_name,
  security_classification, classification_evidence[],
  drift_surface_count, max_pairwise_divergent_bytes,
  patch_atomicity_risk, recommended_action}`; always
  `package-feed-migration`.
- `dotnetcomponents-reference-graph.json` — producer/consumer graph
  for `..\..\DotnetComponents\` refs: `{shared_tree_root, producers[],
  consumers[], orphaned_consumers[]}`.
- `consolidation-plan.json` — per-library recommendation
  (`publish-to-internal-nuget | move-to-submodule |
  consolidate-to-single-repo | accept-drift`), per-consumer effort,
  `blocks_atomic_patch`.
- `drift-severity-ranking.json` — composite score per GUID from repo
  count, byte divergence, security, activity components.

## Methodology
1. **Build the portfolio GUID index.** Walk every manifest. Record
   `(guid, project_name, repo_path, project_file_path, last_commit_sha,
   last_commit_date)` per project. Extract GUID from `<ProjectGuid>`
   or the solution file when the `.csproj` is SDK-style. Set
   `primary_key_source = guid`; fall back to `name+file-byte-hash`
   when absent and emit a diagnostic.
2. **Join across repos.** Group by `guid`. Emit inventory rows for
   every GUID in 2+ distinct repos; single-repo GUIDs are omitted.
3. **Classify the vendoring pattern.** Apply in order:
   `package-feed-mirror` (any consumer uses `<PackageReference>` to an
   internal feed — not a drift surface), `git-submodule`
   (`.gitmodules` names the shared directory), `monorepo-sibling` (all
   consumers share a repo root with the producer), else `copy-paste`.
   ATLAS `Encryptor` is `copy-paste` across four repos.
4. **Pairwise drift analysis.** For every unordered pair `(a, b)`
   sharing a GUID, compute SHA-256 per source file. Classify files as
   `identical`, `drifted`, `added_in_a`, or `added_in_b`. Sum byte
   divergence. When semantic diff is available, split `drifted` into
   `cosmetic-only` vs `structural`; otherwise mark
   `semantic_diff_available = false`.
5. **Classify security criticality.** Apply
   `references/project-guid-drift-analysis.md`: namespace match
   (`*.Encryptor`, `*.Security.*`, `*.Crypto`, `*.Signing`),
   crypto-primitive usage (`AesManaged`, `RSACryptoServiceProvider`,
   `PasswordDeriveBytes`, `HMACSHA*`), and cross-app data-exchange
   coupling. Any signal fires; emit with
   `recommended_action = package-feed-migration`.
6. **Resolve DotnetComponents references.** Grep consumer `.csproj`
   for `<ProjectReference>` paths with 2+ `..\` segments and resolve
   against the expected sibling layout. Unresolvable paths become
   `orphaned_consumers` — a blocker since the build is not
   self-contained in CI. Per its README, CPDSS is the canonical home
   of `DotnetComponents/`; AMCS is a consumer.
7. **Estimate consolidation effort.** Security-critical always maps
   to `publish-to-internal-nuget`. Otherwise pick the lightest
   applicable option. Estimate per-consumer hours for the
   `<ProjectReference>` to `<PackageReference>` swap and any
   divergent-source merge-back.
8. **Rank drift severity.** Composite = `repo_count_score` (linear, cap
   6) + `byte_divergence_score` (log-scaled) + `security_score` (25 if
   security-critical else 0) + `activity_score` (elevated on recent
   commits). ATLAS `Encryptor` is expected to rank first.
9. **Validate and hand off.** Run the schema validator on each
   artifact. Every `guid` in the drift matrix must exist in the
   inventory; every security-critical row must cite at least one
   `{repo}:{file}:{line}` evidence item.

## Tech-Stack Dispatch

| Trigger | Key patterns |
|---|---|
| `<ProjectGuid>` in 2+ repos | Shared-GUID join; primary path |
| `<ProjectReference Include="..\..\DotnetComponents\...">` | Cross-repo relative reference; producer/consumer graph |
| Namespace match `*.Encryptor`/`*.Security.*`/`*.Crypto.*` | Security-criticality classifier fires |
| `<PackageReference>` to internal feed | `package-feed-mirror`; not a drift surface |

## Gotchas
- **GUID is the join key, not path or name.** `Encryptor/` in four
  repos could be four unrelated projects; the shared `{CDE7B678-...}`
  GUID confirms common ancestry. Joining on name alone is the
  `name-only-join` failure class.
- **`.csproj` GUIDs can mutate silently on VS save.** A buggy VS
  version rewrites `<ProjectGuid>`, making the same project look
  different. Always cross-reference by `name + file-byte-hash` as a
  secondary key and emit a diagnostic when it forces the match.
- **Drift can be cosmetic.** Comment or whitespace edits produce
  different byte hashes but identical IL. Use semantic diff when
  available; weight `cosmetic-only` lower in the ranking.
- **Security-critical demands package-feed migration, not sync.** Four
  copies of `Encryptor.cs` means patching four times — guaranteed lag.
  Atomic patch requires a feed. Never emit `accept-drift` or
  `consolidate-to-single-repo` for security-critical.
- **Relative-path references assume sibling checkout layout.** In CI cloning one repo, `..\..\DotnetComponents\` fails; flag as not self-contained.
- **Canonical home must be confirmed, not picked.** Per its README, CPDSS owns `DotnetComponents/`. Require declaration, commit-date lead, or reference direction — never guess.
- **Encryption drift is silent until cross-app exchange fails.** AAM
  apps exchange airman records via the shared MSS Oracle schema; an
  IV or iteration-count drift in `Encryptor.cs` can block decryption
  for months. Severity must reflect latent risk.
- **Preserved typos are not drift signals** (e.g. `DataAccesslayer` in CHAPS may be the original, preserved everywhere).
- **Intra-repo `.sln` siblings** (`wwDataBinder.sln` + `wwDataBinder1.sln`) are a drift precursor; flag at lower severity.
- **Binary DLLs** under `lib/`/`ThirdPartyDLLs/` use a separate binary-hash path; do not conflate with source rows.

## Quality Rules
- [ ] Every inventory row has `repo_paths[]` length >= 2 and a
      `vendoring_pattern` set to one of the four enum values.
- [ ] Every drift row names both repos with non-negative
      `divergent_bytes`.
- [ ] Every security-critical finding cites at least one
      `{repo}:{file}:{line}` evidence item.
- [ ] Every `orphaned_consumers[]` entry cites the consumer `.csproj`
      and the unresolvable referenced path.
- [ ] Every consolidation row has `canonical_home_repo` and a
      per-consumer effort estimate.
- [ ] Security-critical maps to `publish-to-internal-nuget`, never
      `accept-drift` or `consolidate-to-single-repo`.
- [ ] Ranking rows carry four component scores summing to the composite.
- [ ] All artifacts pass `schema_validator` with zero errors.
- [ ] Diagnostic row emitted whenever `primary_key_source != guid`.

## Common Failure Modes
| Failure Mode | Symptom | Prevention |
|---|---|---|
| GUID collision false positive | Two unrelated projects share a GUID and get joined | Cross-check name and file-hash; emit diagnostic when names diverge despite GUID match |
| Name-only join | Join on `Encryptor` name alone produces false matches across unrelated apps | Join on GUID primary, name+hash secondary; never name alone |
| Cosmetic drift overclassified | Comment-only edits crowd the ranking top | Use semantic diff when available; weight `cosmetic-only` lower |
| Security classification missed | `Encryptor` classified non-security because of minimal keyword match | Use namespace + primitive + coupling as three independent signals; fire on any one |
| Canonical home guessed | Plan picks AMCS as home when CPDSS is declared authoritative | Require explicit declaration or commit-date lead; flag when absent |
| Relative-path unresolved | Consumer references `..\..\DotnetComponents\Foo\` with no producer; build breaks silently in CI | Emit `orphaned_consumers[]`; flag as blocker; require producer co-clone or package swap |

## Handoff Summary
When this skill completes, verify:
1. Inventory lists every GUID shared across 2+ repos with full
   `repo_paths[]` and commit metadata; drift matrix covers every pair.
2. Security-critical findings each cite
   `recommended_action = package-feed-migration`.
3. The DotnetComponents graph names the canonical home and any
   orphaned consumer; the plan has per-consumer effort and never maps
   security-critical to `accept-drift`.
4. Ranking places ATLAS `Encryptor` first.

Then proceed to: `disposition-recommender` (weights Consolidate /
Replace) and `portfolio-integration-mapper` (refines cross-app surface
using the DotnetComponents graph). The next gate is **G-RR** where
security-critical findings must be accepted before modernization
planning begins.

## References
- `references/vendored-shared-library-patterns.md` — the four vendoring
  patterns, detection markers, drift mechanics, relative-path refs.
- `references/project-guid-drift-analysis.md` — GUID extraction,
  cross-repo join, secondary-key fallbacks, semantic-diff strategies,
  security-criticality heuristics, consolidation-effort estimation.
