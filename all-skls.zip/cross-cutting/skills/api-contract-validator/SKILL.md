---
name: api-contract-validator
description: >
  Validate that generated API implementations match their OpenAPI specifications
  and that external consumer compatibility is preserved. Use during P5.1 validation
  for API contract compliance testing. Triggers on API contract, OpenAPI validation,
  API compliance, consumer compatibility, or Gravitee route testing mentions.
agent: sonnet
allowed-tools:
  - Read
  - Write
  - Bash
---

# API Contract Validation

## Purpose
Verify that modernized APIs conform to their OpenAPI specs and that existing
external consumers (airlines, other agencies, ICAO) won't break.

## Workflow
1. Load the OpenAPI spec from P4.2 outputs
2. Run `scripts/validate_openapi_spec.py` for schema validity
3. Run `scripts/test_api_contract.py` against the running service
4. For external-facing APIs, run `scripts/check_consumer_compat.py`
5. Verify Gravitee route configuration matches the spec
6. Generate contract compliance report

## Gotchas
- **External consumers CANNOT change**: Airlines and other agencies have
  integrations built against specific API contracts. Any breaking change
  requires the external interface preservation plan from P2.1.
- **Gravitee routes must match OpenAPI paths exactly**: A mismatch between
  the OpenAPI spec and Gravitee route configuration means the API is
  unreachable or incorrectly routed.
- **Solace/SWIM interfaces are NOT REST APIs**: Don't try to validate SWIM
  integrations with OpenAPI tooling. SWIM uses publish/subscribe patterns
  through Solace PubSub+. These need their own contract validation.
- **Versioning strategy matters**: If the legacy API was /v1/flights, the
  modern API should also be /v1/flights (same path) OR maintain both
  /v1/flights (legacy compat) and /v2/flights (new).

## Reference Files
- `references/gravitee-route-validation.md` — Gravitee config checks

## Quality Rules
- [ ] OpenAPI spec passes schema validation via `scripts/validate_openapi_spec.py`
- [ ] Running service responses match the OpenAPI spec for all defined endpoints (status codes, schemas, headers)
- [ ] External-facing APIs pass consumer compatibility check — no breaking changes for airlines, agencies, or ICAO
- [ ] Gravitee route configuration matches OpenAPI paths exactly — no mismatches that would cause routing failures
- [ ] SWIM/Solace interfaces are validated separately from REST APIs — not mixed into OpenAPI validation
- [ ] API versioning strategy is verified: legacy paths maintained alongside new paths when required

## Common Failure Modes
| Failure Mode | Symptom | Prevention |
|-------------|---------|------------|
| Breaking external contract | External consumer integration breaks after deployment; airlines or agencies report errors | Run `scripts/check_consumer_compat.py` for all external-facing APIs before deployment |
| Gravitee route mismatch | API is unreachable or incorrectly routed because Gravitee config does not match OpenAPI paths | Validate Gravitee routes against OpenAPI spec as part of every contract check |
| SWIM interface tested with REST tools | Solace PubSub+ interfaces fail or are skipped because OpenAPI tools cannot validate them | Identify SWIM interfaces and use publish/subscribe validation tooling, not REST API tools |
| Version path missing | Legacy consumers call /v1/flights but only /v2/flights exists; backward compatibility broken | Verify both legacy and new version paths are configured when migration is incremental |

## Phase 3 — ATLAS ChBA

> **Trace:** Closes P3-R34, P3-R36 enforcement. Source: `docs/phase3/phase2-commitments.md` §B.3 ("no service reads from another service's database"); gap matrix EDIT-6 (B5b in build plan). Pairs with `cross-cutting/skills/api-specification` (Phase 3 EDIT) and the new `cross-cutting/skills/devsecops-pipeline-generator`.

### Contract-test scaffolding (Schemathesis)

Add per-service contract tests using **Schemathesis** (canonical Python OpenAPI fuzzer). Each Phase 3 service S1..S11 gets a generated test file `tests/contract/test_<svc>_contract.py` that:

1. Loads the spec at `services/<svc>/openapi.yaml`.
2. Spins the service container via docker-compose.
3. Runs Schemathesis `--checks all` (status code, response schema, content type, headers).
4. Reports failures as JUnit XML for CI consumption.

A `scripts/scaffold_contract_tests.py` (NEW under this skill) generates the file from a spec path. Equivalent for non-Python stacks: Dredd or Postman/Newman are acceptable substitutes; the gate is "machine-readable contract verification on every CI run."

### Breaking-change detector

Add a `--detect-breaking-changes` mode that diffs the current spec against the last committed version on `main`. Failure conditions:

- Removed operation
- Removed response code
- Required-to-optional or optional-to-required toggle on a request field
- Removed enum value
- Renamed field at the same path
- `info.version` did not bump per the breaking-change

Implementation: wrap `oasdiff` (`oasdiff/oasdiff` Go binary) and parse its breaking-change report. CI fails the PR until either the spec is reverted or the major version bumps with a documented compat-policy entry.

### `--check-decoupling` flag (P3-R36)

Scan the generated server + client bundles emitted from `cross-cutting/skills/api-specification`. Fails the build if:

- A type from `services/<svc>/internal/**` is referenced from any client-side bundle.
- A schema marked `x-internal: true` appears in a response body.
- The frontend bundle imports any backend module path (e.g., `from services.s5_case.persistence import ...`).
- The `services/<svc>/handlers/**` reads from another service's DB connection string (detected by import-graph + connection-string regex).

Produces a quantitative drift report with a single number: **count of cross-boundary violations**. The new `cross-cutting/skills/service-layer-decoupling-auditor` (NEW skill, P1) consumes this number into the 10-page narrative.

### CI gate hook for `devsecops-pipeline-generator`

The new `cross-cutting/skills/devsecops-pipeline-generator` (NEW, P0) emits CI YAML stages. This skill provides the contract test stage:

```yaml
contract-test:
  needs: [build]
  runs-on: ubuntu-latest
  strategy:
    matrix:
      service: [s1-identity, s2-intake, s3-notify, s5-case, s6-medical, s7-designee, s8-registry, s9-credential, s11-reporting]
  steps:
    - uses: actions/checkout@v4
    - run: docker compose up -d ${{ matrix.service }}
    - run: schemathesis run services/${{ matrix.service }}/openapi.yaml --base-url http://localhost --checks all --report junit
    - run: python -m api_contract_validator --check-decoupling --service ${{ matrix.service }}
    - run: python -m api_contract_validator --detect-breaking-changes --service ${{ matrix.service }} --base-ref origin/main
```

The pipeline generator splices this stage into `.github/workflows/security.yml` (or equivalent). Pass/fail is gating: contract failures block deploy.

### Phase 3 acceptance signals

- [ ] Schemathesis contract tests run for every implemented service S1, S2, S3, S5, S6, S7, S8, S9, S11.
- [ ] `--check-decoupling` reports zero cross-boundary violations on a clean build.
- [ ] `--detect-breaking-changes` exits 0 against `main` for every PR (or fails with a documented major-version bump).
- [ ] CI pipeline integrates the contract-test stage; failure blocks promotion.

## Handoff Summary
When this skill completes, verify:
1. All API endpoints match their OpenAPI specifications
2. External consumer compatibility is confirmed (no breaking changes)
3. Gravitee route configuration is validated
4. SWIM/Solace interfaces are validated separately
5. **Phase 3:** Schemathesis contract tests pass; `--check-decoupling` clean; breaking-change detector wired
Then proceed to: `parity-verifier` (P5.1) for behavioral equivalence testing, and gate `G-V1` for functional validation
