#!/usr/bin/env python3
"""Check external consumer compatibility for a modernized API.

External consumers — airlines, other agencies, ICAO — have integrations built
against specific API contracts. Any breaking change requires the external
interface preservation plan from P2.1 and explicit consumer notification.

This script compares the modernized API's OpenAPI spec against a captured
legacy contract baseline and flags breaking changes.
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from typing import Any

# TODO(skill-author): Replace with actual OpenAPI parser (e.g., openapi-core,
# prance, or jsonschema). This stub only loads JSON.


def load_spec(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8"))


def find_breaking_changes(legacy: dict[str, Any], modern: dict[str, Any]) -> list[str]:
    """Return list of breaking-change descriptions.

    Breaking changes include:
    - Removed endpoints
    - Removed HTTP methods on endpoints
    - Required request parameters added
    - Removed fields from response schemas
    - Type changes on existing fields
    - Tighter validation (min/max, enum restrictions) on request fields
    """
    # TODO(skill-author): Implement real diff logic. Currently returns [].
    return []


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--legacy-spec",
        type=Path,
        required=True,
        help="Captured legacy OpenAPI contract baseline",
    )
    parser.add_argument(
        "--modern-spec",
        type=Path,
        required=True,
        help="Modernized service OpenAPI spec",
    )
    args = parser.parse_args(argv)

    legacy = load_spec(args.legacy_spec)
    modern = load_spec(args.modern_spec)
    breaking = find_breaking_changes(legacy, modern)

    if breaking:
        print("Breaking changes detected:")
        for change in breaking:
            print(f"  - {change}")
        return 1

    print("No breaking changes detected")
    return 0


if __name__ == "__main__":
    sys.exit(main())
