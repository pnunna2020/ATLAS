#!/usr/bin/env python3
"""Validate OpenAPI 3.x specification for correctness."""
import sys
import json
import yaml

def validate(spec_path):
    with open(spec_path) as f:
        if spec_path.endswith('.yaml') or spec_path.endswith('.yml'):
            spec = yaml.safe_load(f)
        else:
            spec = json.load(f)
    errors = []
    if 'openapi' not in spec:
        errors.append("Missing 'openapi' version field")
    elif not spec['openapi'].startswith('3.'):
        errors.append(f"Expected OpenAPI 3.x, got {spec['openapi']}")
    if 'info' not in spec:
        errors.append("Missing 'info' section")
    if 'paths' not in spec:
        errors.append("Missing 'paths' section")
    else:
        for path, methods in spec['paths'].items():
            for method, detail in methods.items():
                if method in ('get','post','put','delete','patch'):
                    if 'responses' not in detail:
                        errors.append(f"{method.upper()} {path}: missing responses")
                    if 'operationId' not in detail:
                        errors.append(f"{method.upper()} {path}: missing operationId")
    return {"status": "PASS" if not errors else "FAIL", "errors": errors,
            "paths_count": len(spec.get('paths',{})),
            "operations_count": sum(len([m for m in methods if m in ('get','post','put','delete','patch')])
                for methods in spec.get('paths',{}).values())}

if __name__ == "__main__":
    print(json.dumps(validate(sys.argv[1]), indent=2))
