# Gravitee Route Validation

Reference checks for ensuring Gravitee route configuration matches the OpenAPI
specification of the modernized service.

## Purpose
Gravitee is the mandatory API gateway in the FAA target architecture. Every
endpoint exposed by a modernized service MUST have a matching Gravitee route.
A mismatch means the API is unreachable, incorrectly routed, or bypassing the
rate limits and auth enforcement that Gravitee provides.

## Required Checks

### Path Alignment
- Every operation path in the OpenAPI spec has a corresponding Gravitee route
  with identical path parameters.
- Path versioning (`/v1/flights` vs `/v2/flights`) matches the spec.
- Trailing slashes are handled consistently.

### Method Alignment
- All HTTP methods declared in the OpenAPI operation exist on the Gravitee route.
- No extra methods on the Gravitee route that are not in the spec.

### Security Scheme Alignment
- OAuth2 (via OKTA) is configured as the primary security scheme.
- Login.gov federation is configured for external-facing routes.
- API key fallback (if any) is allow-listed to specific legacy consumers.

### Rate Limiting and Quotas
- Each route declares a rate limit appropriate to its tier.
- Per-consumer quotas are configured for external-facing routes.

### Policy Chain
- Transformation policies (request/response) do not alter schemas in ways the
  spec does not declare.
- Logging and audit policies are enabled.

## TODO for Skill Author

- [ ] Document how to read Gravitee configuration: REST management API vs
      exported YAML vs Terraform.
- [ ] Add sample diffs showing common mismatches (path typos, missing methods,
      wrong security scheme).
- [ ] Document the Gravitee Management API endpoints the validator should call.
- [ ] Link to the Gravitee version pinned in the FAA tech stack.
