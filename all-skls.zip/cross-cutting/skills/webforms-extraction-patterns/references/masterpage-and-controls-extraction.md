# Master Page and Controls Extraction

This reference covers Master Page inheritance graphs, `ContentPlaceHolder`
inventory, nested masters, `<%@ MasterType %>` directives, programmatic
`MasterPageFile` assignment, user-control (`.ascx`) discovery, and
custom server-control assembly references. Output populates
`webforms-master-hierarchy.json` and the user-control portion of
`webforms-controls-manifest.json`.

## Master Page Basics

A `.master` file is a layout template. It declares regions with
`<asp:ContentPlaceHolder ID="..." />`; pages that bind to the master
fill those regions with `<asp:Content ContentPlaceHolderID="..." />`
blocks. The relationship between a page and its master is:

- Declared via `<%@ Page MasterPageFile="~/Site.Master" %>` in markup,
  or
- Declared app-wide via `<system.web><pages masterPageFile=".."/>` in
  `web.config`, or
- Assigned programmatically in `Page_PreInit` via
  `this.MasterPageFile = "~/Special.Master";`

All three paths must be extracted.

## Master Page Chain Resolution

Masters can inherit from other masters. Capture the full chain.

### Nested master detection
A nested master has a `<%@ Master MasterPageFile="..." %>` directive
at its top. Example:

    <%@ Master Language="C#" MasterPageFile="~/MainMaster.Master"
         AutoEventWireup="true" CodeFile="CPDSSMaster.master.cs"
         Inherits="CPDSS.CPDSSMaster" %>

Here `CPDSSMaster.Master` inherits from `MainMaster.Master`. A page
bound to `CPDSSMaster.Master` is effectively rendered inside
`MainMaster.Master` → `CPDSSMaster.Master` → page content.

### Chain-walking algorithm
1. For each `.master` in the repo, parse its `<%@ Master %>` directive
   and record the `MasterPageFile` attribute (may be null for a root
   master).
2. Build a directed graph: edge `child → parent` when the child
   declares `MasterPageFile=parent`.
3. For each page, start at its declared `MasterPageFile` and walk the
   graph to the root. Emit the chain as an ordered list
   (`[Site.Master, Nested.Master]` means the page sits inside
   `Nested.Master`, which sits inside `Site.Master`).
4. Cycles indicate a broken configuration; emit a finding and stop
   the walk.

### ATLAS depth examples
- **CPDSS** — four-master system: `CPDSSMaster.Master`,
  `MainMaster.Master`, and two others. Depth 2 is common.
- **CHAPS** — four masters: `Site.Master`, `HeaderFooter.Master`,
  `Nested.Master`, `NonSecure.Master`. `Nested.Master` inherits from
  `Site.Master` (depth 2).
- **IACRA** — simpler hierarchy, depth 1 for most pages.
- **MedXPress** — single `SiteMasterPage.Master`, depth 1.
- **AMCS** — two masters, `FAABasePage.Master` and `AMCS.Master`;
  different subfolders bind to different masters.

## `ContentPlaceHolder` Inventory

For each master, enumerate every `<asp:ContentPlaceHolder>` with its
`ID`. These are the named slots that child pages fill. For the
hierarchy manifest, record:

- `master_path`
- `parent_master_path` (for nested masters) or `null`
- `placeholders[]` — list of `{id, default_content_present, line}`
- `inherits_class` from the `<%@ Master Inherits=... %>`
- `codebehind_path` and `codebehind_language`

Default content inside a placeholder is what renders when no page
overrides it; record whether the placeholder has default content (it
may be meaningful for fallback rendering).

When resolving a page's content bindings, match each `<asp:Content
ContentPlaceHolderID="X">` to a placeholder in the master chain. A
page may fill placeholders from **any** master in its chain, not just
the directly declared one. A reference to a placeholder that does
not exist in any chain master flags as an orphan finding.

## `<%@ MasterType %>` Directive

Strongly types the `Master` property:

    <%@ MasterType VirtualPath="~/Site.Master" %>

With this directive, code-behind can access master members with full
typing:

    this.Master.HeaderTitle = "Login";

Without it, the `Master` property is typed as `MasterPage` and access
requires casts. Record the presence and `VirtualPath` of every
`MasterType` directive; correlate with cross-page member accesses
(calls to `this.Master.<Member>` in code-behind) to build the
master-API surface.

## Programmatic Master Assignment

A page may override its master in `Page_PreInit`:

    protected void Page_PreInit(object sender, EventArgs e)
    {
      if (User.IsInRole("Mobile"))
        this.MasterPageFile = "~/Mobile.Master";
    }

This is the only page lifecycle event in which the master can be
reassigned. Scan every `.aspx.cs` / `.aspx.vb` code-behind for
`MasterPageFile =` assignments and emit one finding per site. Record
the conditional context (the containing `if` or `switch`) because the
effective master is runtime-determined — Design cannot assume the
declared master.

## User Control (`.ascx`) Discovery

User controls are reusable markup fragments with code-behind. They
follow the same triad rules as pages with `.ascx` replacing `.aspx`:

- `Header.ascx` — markup with `<%@ Control %>` directive
- `Header.ascx.cs` or `.vb` — code-behind
- `Header.ascx.designer.cs` or `.vb` — auto-generated designer

### Discovery pass
1. Walk the repo for every `.ascx`.
2. Pair with its code-behind and designer using the triad algorithm.
3. Parse the `<%@ Control %>` directive for `Inherits`,
   `CodeFile`/`CodeBehind`, `Language`, `AutoEventWireup`, and
   `ClassName`.
4. Enumerate declared server controls inside the `.ascx` (same rules
   as page markup).
5. Record code-behind event handlers (same rules as page code-behind:
   markup `OnClick`, `AutoEventWireup`, VB.NET `Handles`,
   `AddHandler`).
6. Emit one user-control record per `.ascx` with all of the above.

### Cross-page usage
For each page and each master, scan for usages of registered user
controls. A Register directive binds a tag prefix and tag name:

    <%@ Register TagPrefix="uc" TagName="Header" Src="~/Controls/Header.ascx" %>

Downstream markup uses `<uc:Header ID="HeaderInstance" runat="server" />`.
Build a usage graph: each user control lists the pages and masters
that host it, with `{repo}:{file}:{line}` citations at every usage
site.

## Custom Server Control Assembly References

Custom server controls are compiled into assemblies and registered by
namespace:

    <%@ Register TagPrefix="cc" Namespace="CompanyX.Controls"
                 Assembly="CompanyX.Controls" %>

Markup then uses `<cc:FancyGrid ID="Grid1" runat="server" />`.

### Resolution
- Record the tag prefix, namespace, and assembly name.
- Attempt to locate the assembly in the solution's `bin/` directory,
  the project's output folder, or a referenced project.
- When found, record the assembly path; when not, flag as an info
  finding (likely a third-party library).
- When the solution references the source project, cross-link the
  control to its source `.cs`/`.vb` file for the extraction's
  cross-reference.

### `<%@ Assembly %>` vs. `<%@ Register Assembly=... %>`
- `<%@ Assembly Name="Foo" %>` adds a runtime-loaded assembly to the
  page's AppDomain without tag registration.
- `<%@ Register Assembly="Foo" Namespace="..." TagPrefix="..." %>`
  also registers a tag prefix for the assembly's controls.

Capture both; they contribute to the page's dependency surface.

## Master Code-Behind Extraction

A `.master.cs` or `.master.vb` is code-behind like any other. Extract
with the same rules as page code-behind:

- Event handlers (`Page_Load`, `Page_Init`, and markup-wired handlers
  on controls declared in the master)
- Public properties and methods that pages may access via `this.Master`
- Session / ViewState / Application accesses
- Hard-coded navigation targets that feed the sitemap

Master code-behind is unusually significant because it runs on every
page that inherits the master. Logic that probably belongs in a single
page — role-based UI hiding, session validation, nav menu rendering —
often sits here.

## Programmatic `Controls.Add` in Master or Page

Server controls may also be added programmatically from code-behind:

    Button b = new Button { ID = "DynamicBtn", Text = "Go" };
    b.Click += DynamicBtn_Click;
    Placeholder1.Controls.Add(b);

These controls do not appear in markup or the designer. Scan
code-behind for `new <ControlType>`, `.Controls.Add(`, and
`.Click += ` to find them. Emit as a declared-control record with
`declaration = "programmatic"` and cite the construction line. The
extraction must include these controls or the event graph and
control count are under-reported.

## XML-Driven Left-Nav (CPDSS pattern)

CPDSS has a `LeftNavMenu.xml` that drives its left navigation from
within a master page. While not strictly a server control, the
master renders a navigation tree from the XML. When a master reads
an external XML file (`Server.MapPath(...)`, `XmlDocument.Load(...)`)
and renders it, record:

- The XML file path
- The master that consumes it
- The rendering method or control that produces the output

This is not a WebForms idiom per se, but it is common in ATLAS apps
and the Design step needs to know about these external config
surfaces.

## Master Page Findings

Emit findings for:
- **Cyclic master inheritance** — a master's chain loops back to
  itself (severity: critical; modernization blocker)
- **Orphan `<asp:Content>` placeholder reference** — a page fills a
  placeholder that does not exist in its master chain (severity:
  high; rendering is silently dropped)
- **Programmatic `MasterPageFile` assignment** — runtime master
  selection (severity: medium; migration requires special handling)
- **Master with heavy code-behind logic** — session validation,
  role checks, or navigation rendering in the master rather than a
  dedicated component (severity: medium; refactor target)
- **Nested master depth `>= 3`** — unusual and increases layout
  complexity (severity: low; informational)

## Output Shape Example

    {
      "master_path": "src/.../CPDSSMaster.Master",
      "parent_master_path": "src/.../MainMaster.Master",
      "inherits_class": "CPDSS.CPDSSMaster",
      "codebehind_path": "src/.../CPDSSMaster.master.cs",
      "codebehind_language": "csharp",
      "placeholders": [
        {"id": "MainContent", "default_content_present": false, "line": 42},
        {"id": "LeftNav", "default_content_present": true, "line": 67}
      ],
      "event_handlers": [
        {"name": "Page_Load", "wiring": "auto-event-wireup",
         "citation": "src/.../CPDSSMaster.master.cs:18"}
      ],
      "chain_to_root": [
        "src/.../CPDSSMaster.Master",
        "src/.../MainMaster.Master"
      ],
      "xml_driven_nav": {
        "xml_path": "src/.../LeftNavMenu.xml",
        "consumer_line": 94
      }
    }

Every field carries at least one `{repo}:{file}:{line}` citation.
