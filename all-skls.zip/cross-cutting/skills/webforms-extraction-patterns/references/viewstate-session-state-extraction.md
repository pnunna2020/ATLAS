# ViewState, Session, and Other State Extraction

This reference covers extracting every state surface a WebForms
application uses: ViewState (per-control, per-page round-trip),
Session (per-user across requests), Application (global cache),
`HttpContext.Items` (per-request), cookies (client-side persistence),
and output caching (server-side page caching). Output populates
`webforms-state-manifest.json` and contributes state-related entries
to `webforms-legacy-lifecycle-findings.json`.

## Why State Extraction Matters

WebForms' state model is the single largest modernization blocker:

- **ViewState** is a WebForms-only construct. A target framework
  (MVC, Razor Pages, Blazor, Angular+API) has no direct equivalent.
  Every `ViewState[...]` access must be re-expressed.
- **Session** survives modernization but its usage patterns change.
  Some keys are per-page-scoped (effectively ViewState with a long
  TTL); those must be re-scoped.
- **`HttpContext.Current`** pervades WebForms code. In an ASP.NET
  Core target, `HttpContext` is injected, not global. Every
  `HttpContext.Current` access is a migration edit.
- **ViewState is NOT encrypted by default.** Round-tripping sensitive
  data through ViewState is a security finding.

Without a complete state inventory, Design cannot size the migration
and Generate regenerates pages that compile but fail at runtime
because a key was dropped.

## ViewState Extraction

### What ViewState is
ASP.NET serializes every control's state and certain page-level
values into a hidden `__VIEWSTATE` form field on each render. On the
next post-back, the server deserializes it and rehydrates the page.

### Key forms to detect

**1. Indexed access**

    ViewState["UserId"] = userId;          // write
    int userId = (int)ViewState["UserId"]; // read

Scan every `.aspx.cs` and `.aspx.vb` for `ViewState\[.*\]`. Record:
- Key name (string literal or variable)
- Access mode (`read`, `write`, or `both`)
- Call site (`{repo}:{file}:{line}`)
- Assigned value type (when statically determinable)

**2. LoadViewState / SaveViewState overrides**

    protected override object SaveViewState() { ... }
    protected override void LoadViewState(object savedState) { ... }

These are lifecycle overrides that customize serialization. Emit
as findings (they usually indicate ViewState optimization hacks).

**3. `EnableViewState` overrides**
- `EnableViewState="false"` on the page directive — page opts out.
- `EnableViewState="false"` on a specific control — control opts out
  while the page participates.
- `<pages enableViewState="false" />` in `web.config` — app-wide opt-out.

Capture the effective setting per control:

    effective = control.EnableViewState 
             ?? page.EnableViewState 
             ?? webconfig.pages.enableViewState 
             ?? true

**4. ViewStateMode (ASP.NET 4+)**
Three values: `Enabled`, `Disabled`, `Inherit`. Supersedes
`EnableViewState` for per-control granularity when both are set.
Capture both; emit a finding when they disagree.

### ViewState scope categorization

For every ViewState key, classify:

- **Transient UI state** — selected tab index, pagination offset,
  expanded-tree-node set. Safe; typical use case.
- **Business data** — user IDs, form draft values, calculation inputs.
  Migration cost: re-express as form posts or client-side state.
- **Sensitive data** — social security numbers, medical codes, auth
  tokens. Security finding: ViewState is base64-encoded but NOT
  encrypted unless `ViewStateEncryptionMode="Always"`. Every
  sensitive ViewState key is a modernization blocker.

Detection heuristic: key names containing `SSN`, `Password`, `Token`,
`Secret`, `Key`, `Auth`, or form-specific sensitive tokens
(`MedicalCode`, `ExamResult`) trigger the sensitive classification.

### ViewState anti-patterns to find

- **ViewState-as-session** — storing data that should survive only
  per-user-session in ViewState means it is sent back and forth on
  every post-back, wasting bandwidth.
- **ViewState for collections** — storing a `List<T>` or `DataTable`
  in ViewState bloats the render. Emit as a finding when the assigned
  value's type is a collection.
- **`ViewStateEncryptionMode="Never"`** on pages that carry sensitive
  keys — security finding.

## Session State Extraction

### Key forms

    Session["UserId"] = userId;           // write
    var user = Session["UserProfile"];    // read
    Session.Remove("TempData");           // delete
    Session.Abandon();                    // terminate session

Scan every code-behind and `Global.asax`. Record key, access mode,
scope category, and call site.

### Scope categories

- **Cross-page** — key is read from one page and written in another.
  Typical for navigation state, shared form data.
- **Per-user identity** — key carries user id, role, or permissions.
  Typically written at login (`Session_Start` or login handler) and
  read everywhere.
- **Per-request scratch** — key is written and read within the same
  page lifecycle, then cleared. Should probably be `HttpContext.Items`.

Categorize by cross-referencing the write sites against the read
sites. A key written on page A and read on page B is cross-page. A
key written in `Session_Start` is per-user. A key written at the top
of `Page_Load` and cleared at the bottom is per-request.

### Session configuration from web.config

    <sessionState mode="InProc" timeout="20" cookieless="false" />

Capture `mode` (`Off` | `InProc` | `StateServer` | `SQLServer` |
`Custom`), `timeout`, `cookieless`, `stateConnectionString`,
`sqlConnectionString` (redact credentials). Mode directly affects
modernization: `SQLServer` mode means session state already persists
outside the app process; `InProc` means every server restart drops
state.

### `Session_Start` / `Session_End` handlers

In `Global.asax.cs` or `.vb`:

    void Session_Start(object sender, EventArgs e) { ... }
    void Session_End(object sender, EventArgs e) { ... }

Extract the handler bodies. `Session_End` only fires reliably in
`InProc` mode; flag any logic that depends on it when another mode
is configured.

## Application State Extraction

    Application["ConfigCache"] = LoadConfig();
    var cfg = Application["ConfigCache"];
    Application.Lock(); Application.UnLock();

`Application[...]` is a global, per-AppDomain cache. Unlike Session,
it is shared across all users. Scan for reads and writes; record
each key with access mode and call site. `Application.Lock()` /
`UnLock()` blocks indicate concurrency-sensitive sections — capture
these as regions of interest.

In a load-balanced deployment, `Application[...]` does not share
across servers; emit a finding when the deployment model is not a
single-instance AppDomain.

## `HttpContext.Items` Extraction

    HttpContext.Current.Items["RequestId"] = Guid.NewGuid();

A per-request dictionary, cleared at the end of the request. Used
for passing data through `HttpModule` / `IHttpHandler` chains.

Scan for `HttpContext.Current.Items[...]` and `HttpContext.Items[...]`
reads and writes. Record key, access mode, and call site. Cross-link
with `HttpModule` class definitions (classes implementing
`IHttpModule`) since those are the typical producers.

Any use of `HttpContext.Current` outside a Page or HttpHandler class
is a finding — the pattern does not translate cleanly to ASP.NET
Core, where `HttpContext` is injected per-request.

## Cookie Extraction

### Setting cookies

    Response.Cookies["UserPref"].Value = "dark-mode";
    Response.Cookies["UserPref"].Expires = DateTime.Now.AddDays(30);
    Response.Cookies.Add(new HttpCookie("Auth", token) {
      HttpOnly = true, Secure = true
    });

### Reading cookies

    var pref = Request.Cookies["UserPref"]?.Value;

For every cookie operation, record:
- Cookie name
- Operation (`set`, `read`, `delete`)
- `HttpOnly` flag (security finding when false for auth cookies)
- `Secure` flag (security finding when false on an HTTPS-only app)
- `SameSite` attribute (missing is an info finding)
- Expiration (session-only vs. persistent)
- Call site

### `FormsAuthentication` cookies
When the app uses `FormsAuthentication.SetAuthCookie(...)`,
`FormsAuthentication.GetAuthCookie(...)`, or
`FormsAuthenticationTicket`, extract as a first-class auth-surface
record. The forms-auth cookie is effectively the session identity
for WebForms apps.

## Output Caching

    <%@ OutputCache Duration="120" VaryByParam="id"
                    VaryByCustom="role" Location="Server" %>

Captures:
- `Duration` — seconds
- `VaryByParam` — query-string keys
- `VaryByCustom` — custom vary logic (usually implemented in
  `Global.asax` as `GetVaryByCustomString`)
- `VaryByHeader` — HTTP headers
- `VaryByControl` — server controls (for user controls)
- `Location` — `Any` | `Client` | `Downstream` | `Server` |
  `ServerAndClient` | `None`
- `CacheProfile` — named profile from `web.config`
- `SqlDependency` — database invalidation binding

For each page with an `OutputCache` directive, emit a profile record.
For each `VaryByCustom` value, look up the corresponding
`GetVaryByCustomString` case branch in `Global.asax` and record the
logic.

Cache profiles in `web.config`:

    <caching>
      <outputCacheSettings>
        <outputCacheProfiles>
          <add name="Static60" duration="60" varyByParam="none" />
        </outputCacheProfiles>
      </outputCacheSettings>
    </caching>

Extract once per app; pages referencing a profile link to this record.

## Cache Object

    Cache.Insert("key", value, null,
                 DateTime.Now.AddMinutes(10),
                 Cache.NoSlidingExpiration);
    var v = Cache["key"];

The `System.Web.Caching.Cache` API is distinct from
`Application[...]`. Scan for `Cache.Insert`, `Cache.Add`, `Cache.Get`,
indexer access, and `Cache.Remove`. Record key, TTL, dependencies
(file, SQL, custom), and call site. In ASP.NET Core, this maps to
`IMemoryCache` or `IDistributedCache` — the extraction feeds that
Design decision.

## Legacy Lifecycle Findings

Beyond state-specific findings above, emit findings for:

- **`HttpContext.Current` used outside Page/Handler** — direct
  static access breaks ASP.NET Core migration.
- **`Response.Redirect(url, endResponse: true)`** — `endResponse:
  true` calls `Response.End()` which throws
  `ThreadAbortException`. Deprecated; replace with
  `Response.Redirect(url, false); Context.ApplicationInstance.CompleteRequest();`
- **`Page.IsPostBack` branching depth `>= 3`** — indicates complex
  post-back state machine; modernization target for cleaner state
  machines or SPA migration.
- **DataBound events firing twice** — detect by presence of both
  `Page_Load` databind calls AND `DataSourceID` bindings; the grid
  binds twice.
- **`Request.Form[...]`** direct access — bypasses validation;
  security finding.
- **`Request.QueryString[...]`** concatenated into SQL or HTML
  without encoding — injection risk, but the security-scan-review
  skill is authoritative; emit only a pointer.
- **`<script runat="server">` blocks** — inline code breaks
  separation-of-concerns; extractable but a finding.

## Output Shape Example

    {
      "page_path": "src/.../Applicant/Edit.aspx",
      "viewstate_keys": [
        {
          "key": "ApplicantId",
          "access": "both",
          "sensitive": false,
          "read_sites":  ["src/.../Edit.aspx.cs:42"],
          "write_sites": ["src/.../Edit.aspx.cs:67"]
        },
        {
          "key": "SSN",
          "access": "write",
          "sensitive": true,
          "write_sites": ["src/.../Edit.aspx.cs:91"],
          "finding": "WF-STATE-SSN-001"
        }
      ],
      "session_keys": [
        {"key": "CurrentUserId", "scope": "per-user",
         "read_sites": [...], "write_sites": ["Global.asax.cs:18"]}
      ],
      "cookies_set":  [...],
      "cookies_read": [...],
      "output_cache": {
        "duration": 120,
        "vary_by_param": "id",
        "vary_by_custom": "role"
      },
      "httpcontext_current_uses": [
        {"site": "src/.../Edit.aspx.cs:112", "finding": "WF-HCC-001"}
      ]
    }

Every entry carries a `{repo}:{file}:{line}` citation at every
read/write site.

## Citation Discipline

No state record ships without citations at both the declaration site
(for keys assigned) and at least one use site (for keys read).
Key-with-no-writes is a finding (consumer of an external-process
write). Key-with-no-reads is a finding (dead state). Both flag as
low-severity cleanup findings.
