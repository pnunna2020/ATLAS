# ASPX / Code-Behind / Designer Triad Extraction

This reference covers the mechanics of walking an ASP.NET WebForms page
as a **triad** — the `.aspx` markup, the `.aspx.cs` or `.aspx.vb`
code-behind, and the auto-generated `.aspx.designer.cs` or
`.aspx.designer.vb` — and binding them into a single page-manifest
record. It also covers parsing the page directives, discriminating
orphan triads, detecting code-behind language, extracting event
handlers from both C# and VB.NET surfaces, and resolving
`<%@ Register %>` bindings to their target control files.

## Triad Pairing

A WebForms page is not one file; it is three files that must be treated
as a unit:

| Role | Filename convention | Generated? |
|---|---|---|
| Markup | `Foo.aspx` | Authored |
| Code-behind | `Foo.aspx.cs` or `Foo.aspx.vb` | Authored |
| Designer | `Foo.aspx.designer.cs` or `Foo.aspx.designer.vb` | Auto-generated |

For a user control, the convention is identical with `.ascx` replacing
`.aspx`. For a Master Page, `.master` replaces `.aspx`.

### Pairing algorithm
1. Walk the repo for every `.aspx`, `.ascx`, and `.master`.
2. For each markup file `Foo.aspx`, look for a sibling code-behind by
   trying, in order: `Foo.aspx.cs`, `Foo.aspx.vb`.
3. For each markup file, look for a sibling designer by trying
   `Foo.aspx.designer.cs` then `Foo.aspx.designer.vb`.
4. Confirm the pairing by reading the markup's `<%@ Page %>` directive
   and checking that `CodeFile="Foo.aspx.cs"` (or `.vb`) matches the
   discovered code-behind. When the directive uses `CodeBehind=`
   instead of `CodeFile=`, the project is pre-compiled; trust the
   directive over the filename.
5. Cross-check the code-behind's class name against the `<%@ Page
   Inherits="..." %>` value. Mismatches flag as an orphan finding.

### Orphan triads
Three orphan shapes exist and all are real in ATLAS apps:

- **Designer without code-behind** — a partial VSS/SVN import left the
  designer but dropped the authored code-behind. Extract nothing
  from the designer; emit an orphan finding.
- **Code-behind without designer** — a broken Visual Studio refresh
  left the authored code but dropped the generated designer. Extract
  the code-behind normally; flag the missing designer.
- **Markup without code-behind or designer** — a file-only import
  (rare). Extract the markup's declared controls; emit a
  "pages-without-code" finding.

## Page Directive Parsing

Every `.aspx`, `.ascx`, and `.master` starts with one or more
directives. Parse all of them; subsequent analysis depends on the
attributes.

### `<%@ Page %>`
Attributes to capture:
- `Language` — `C#` or `VB`. Corroborates code-behind extension.
- `CodeFile` / `CodeBehind` — path to code-behind.
- `Inherits` — fully qualified class the code-behind declares.
- `MasterPageFile` — declarative master page binding.
- `AutoEventWireup` — `true` | `false`. Default is `true` when absent.
- `EnableViewState` — `true` | `false`. Default is `true`.
- `ValidateRequest` — `true` | `false`. Default is `true`.
- `Theme` / `StyleSheetTheme` — ASP.NET theme references.
- `EnableSessionState` — `true` | `false` | `ReadOnly`.
- `Trace`, `Debug`, `ClientIDMode` — operational attributes.

### `<%@ Master %>`
Used at the top of a `.master`. Additional attributes:
- `MasterPageFile` — present on **nested** masters only. When set,
  this master inherits from another master; walk the chain.

### `<%@ Control %>`
Used at the top of a `.ascx`. Same shape as `<%@ Page %>` minus
`MasterPageFile`.

### `<%@ Register %>`
Two forms:

    <%@ Register TagPrefix="uc" TagName="Header" Src="~/Controls/Header.ascx" %>
    <%@ Register TagPrefix="cc" Namespace="CompanyX.Controls" Assembly="CompanyX.Controls" %>

- `Src=` — user control. Resolve `~/` to the web root; record the
  bound `.ascx` path.
- `Namespace=` + `Assembly=` — custom server control. Record the
  assembly and namespace; do not fail if the assembly is not in the
  repo (it may be a NuGet package or a binary drop).

### `<%@ Assembly %>` and `<%@ Import %>`
- `Assembly` — adds a runtime assembly reference for the page.
- `Import Namespace="..."` — the equivalent of a `using` statement;
  capture for the namespace-usage inventory.

### `<%@ MasterType %>`
Strongly types the `Master` property:

    <%@ MasterType VirtualPath="~/Site.Master" %>

When present, the code-behind may access master page members via
`this.Master.PublicProperty` with strong typing. Record the
`VirtualPath` and correlate with the master-hierarchy manifest.

### `<%@ OutputCache %>`

    <%@ OutputCache Duration="60" VaryByParam="id" VaryByCustom="user" %>

Capture `Duration`, `VaryByParam`, `VaryByCustom`, `VaryByHeader`,
`Location`, and any `CacheProfile` attribute. These feed the
`output_cache_profile` field in the page manifest.

## Code-Behind Language Detection

Per-page detection is mandatory; a single solution may mix C# and VB.

- File extension — authoritative.
  - `.aspx.cs` → `csharp`
  - `.aspx.vb` → `vbnet`
- `<%@ Page Language="C#" %>` — corroborating.
- `<%@ Page Language="VB" %>` — corroborating.

When the extension and the `Language` attribute disagree, trust the
extension and emit a finding. IACRA is predominantly VB.NET; CPDSS,
CHAPS, AMCS, and MedXPress are C#. A predominantly-VB.NET repo with
a stray `.cs` page is a real pattern (typically a vendor-dropped
component); do not force it to the majority language.

## Event Handler Extraction

WebForms wires events through three mechanisms. Detect all three.

### 1. Markup `OnClick=` (and similar)

    <asp:Button ID="SubmitButton" runat="server" Text="Submit"
                OnClick="SubmitButton_Click" />

Scan the markup for attributes matching `On<EventName>="..."` on any
control with `runat="server"`. The attribute value names the
code-behind method. Common events:
- `OnClick` — buttons, link buttons, image buttons
- `OnCommand` — buttons with `CommandName`
- `OnTextChanged` — text boxes
- `OnSelectedIndexChanged` — drop-downs, list boxes, radio-button lists
- `OnCheckedChanged` — checkboxes, radio buttons
- `OnRowCommand`, `OnRowDataBound`, `OnRowEditing`, `OnRowDeleting` —
  grids
- `OnItemCommand`, `OnItemDataBound` — repeaters, data lists
- `OnInit`, `OnLoad`, `OnPreRender` — control-level lifecycle overrides

Emit one event-graph record per attribute with
`wiring = "markup-onclick"`.

### 2. `AutoEventWireup` implicit binding

When `AutoEventWireup="true"` (the default), methods named `Page_Load`,
`Page_Init`, `Page_PreInit`, `Page_PreRender`, `Page_LoadComplete`,
`Page_Unload`, `Page_Error`, and `Page_DataBind` in the code-behind
are wired by name alone. Scan the code-behind for these method names
and emit one record per match with `wiring = "auto-event-wireup"`.

When `AutoEventWireup="false"`, these methods exist but are NOT wired
unless explicitly hooked in `OnInit`. Scan `OnInit` for
`this.Load += new EventHandler(Page_Load);` (C#) or
`AddHandler Me.Load, AddressOf Page_Load` (VB.NET). Emit with
`wiring = "code-behind-addhandler"`.

### 3. VB.NET `Handles` clause

    Private Sub Button1_Click(sender As Object, e As EventArgs) _
        Handles Button1.Click

The `Handles Control.Event` clause binds the method without any
markup attribute. C# has no equivalent. Scan `.aspx.vb` files for
`Handles\s+[\w.]+(?:\.[\w]+)(\s*,\s*[\w.]+)*` and emit one record
per `Handles` reference with `wiring = "vb-handles"`. A single `Sub`
may handle multiple events via a comma-separated list; emit one
record per listed binding.

The `MyBase.Load` / `Me.Load` form binds the page lifecycle event
itself; treat it as equivalent to `Page_Load` under
`AutoEventWireup="true"`.

## Declared Server Control Extraction

From the markup, emit one record per element with `runat="server"`:

    <asp:TextBox ID="EmailField" runat="server"
                 CausesValidation="true" ValidationGroup="Login" />

Capture:
- `id` — the `ID` attribute
- `type` — element name (e.g., `asp:TextBox`, `asp:GridView`, `uc:Header`)
- `runat` — always `"server"` for server controls
- Containing scope — nearest enclosing `<asp:Content>`, `<asp:Panel>`,
  `<asp:UpdatePanel>`, or `ContentPlaceHolder`
- Validation attributes — `CausesValidation`, `ValidationGroup`
- Declared event wires — any `On<Event>=` attribute
- Data-binding attributes — `DataSourceID`, `DataTextField`,
  `DataValueField`, `DataKeyNames`

Cross-reference the designer file: every `runat="server"` element with
an `ID` should appear as a `protected` field in the designer. An
unmatched declaration flags as a designer-drift finding (common after
a manual markup edit without a Visual Studio refresh).

## Resolving `<%@ Register %>` to Targets

For each Register directive, emit a controls-manifest binding record:

- **Src-form** (user control):
  - Resolve `~/` to the web-root directory.
  - Resolve relative paths against the page's directory.
  - Record the target `.ascx` absolute path.
  - Flag unresolvable `Src=` paths as broken-reference findings.

- **Assembly-form** (custom server control):
  - Record the namespace and assembly name.
  - Attempt to locate the assembly in the repo's `bin/` or referenced
    project output. When found, record the assembly path.
  - When not found, emit an info-severity finding — the control is
    likely a third-party library.

## `<%@ Page %>` vs. inline script distinction

Inline server script breaks naive parsers:

    <% if (User.IsInRole("Admin")) { %>
      <asp:Button ID="AdminButton" runat="server" />
    <% } %>

Detect `<%` and `%>` pairs that are not directives (directives start
with `<%@`). Extract the enclosed script as a finding
(`inline-server-script`); record the language inferred from the
page's `Language` attribute. Do not attempt to bind controls declared
inside such blocks — they are runtime-conditional and the designer
will not have fields for them.

`<script runat="server"> ... </script>` blocks are a related pattern;
capture them under the same finding category.

## Extraction Pseudocode (C# code-behind)

    for each .aspx in repo:
      directive = parse_page_directive(aspx)
      lang = detect_language(aspx, directive)
      cb = find_codebehind(aspx, lang)
      designer = find_designer(aspx, lang)
      page_record = {
        page_path: aspx,
        codebehind_path: cb,
        codebehind_language: lang,
        designer_path: designer,
        master_page: directive.MasterPageFile,
        inherits_class: directive.Inherits,
        auto_event_wireup: directive.AutoEventWireup ?? true,
        ...
      }
      page_record.declared_controls = parse_runat_server(aspx)
      page_record.event_handlers = []
      page_record.event_handlers += markup_onclick(aspx)
      if page_record.auto_event_wireup:
        page_record.event_handlers += wireup_methods(cb, lang)
      if lang == "vbnet":
        page_record.event_handlers += vb_handles_clauses(cb)
      page_record.event_handlers += code_behind_addhandler(cb, lang)
      page_record.viewstate_usage = viewstate_keys(cb, lang)
      page_record.session_keys_referenced = session_keys(cb, lang)
      emit(page_record)

## Citation Discipline

Every emitted field requires a `{repo}:{file}:{line}` citation. The
page directive citation points to line 1 of the `.aspx`; each event
handler points to its code-behind line; each declared control points
to its markup line; each Register resolution points to the Register
directive line and the target control file.
