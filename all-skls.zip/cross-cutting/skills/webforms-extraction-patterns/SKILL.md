---
name: webforms-extraction-patterns
description: >
  Extract a structured representation of an ASP.NET WebForms application —
  the legacy `.NET Framework` web stack where `.aspx`, `.ascx`, and
  `.master` files are paired with code-behind (`.aspx.cs` / `.aspx.vb`) and
  auto-generated designer files (`.aspx.designer.cs` / `.aspx.designer.vb`).
  Walks the page/code-behind/designer triad, resolves Master Page
  inheritance, indexes user controls and server controls, wires the event
  graph from both markup (`OnClick=`, `AutoEventWireup`) and VB.NET
  `Handles` clauses, and inventories ViewState / Session / Application
  state surfaces. Produces seven JSON manifests with `{repo}:{file}:{line}`
  traceability for every claim. Distinct from ASP.NET MVC/Razor/Core
  extraction — WebForms has its own lifecycle, state model, and
  triad-pairing mechanics. Fires during Modernization Extract when
  `tech_stack_contains` includes `aspnet-webforms`, `webforms`, or
  `aspnet` AND the repo contains `.aspx` files. Triggers on WebForms
  extraction, .aspx extraction, Web Forms modernization, or
  @webforms-extraction-patterns.
tier: 1
triggers:
  tech_stack_contains: [aspnet-webforms, webforms, aspnet]
agent: sonnet
enrichment_level: Full
version: 0.1.0
allowed-tools:
  - Read
  - Grep
  - Glob
  - Write
validation_commands:
  - "python -m olympus.validators.schema_validator webforms-page-manifest.json"
  - "python -m olympus.validators.schema_validator webforms-master-hierarchy.json"
  - "python -m olympus.validators.schema_validator webforms-controls-manifest.json"
  - "python -m olympus.validators.schema_validator webforms-event-graph.json"
  - "python -m olympus.validators.schema_validator webforms-state-manifest.json"
  - "python -m olympus.validators.schema_validator webforms-legacy-lifecycle-findings.json"
  - "python -m olympus.validators.schema_validator webforms-data-binding-manifest.json"
supported_stacks:
  - aspnet-webforms
  - webforms
  - aspnet
  - csharp
  - vbnet
  - dotnet-framework
anti_target_stacks:
  - aspnet-core
  - aspnet-mvc
  - razor
  - blazor
  - static-site
  - spa
failure_classes:
  - designer-treated-as-business-logic
  - triad-pairing-broken
  - master-chain-unresolved
  - vbnet-handles-clause-missed
  - autoeventwireup-mode-misdetected
  - inline-server-script-parser-crashed
  - register-directive-unresolved
  - viewstate-abuse-unflagged
  - zero-byte-sentinel-extracted
benchmark_tags:
  - modernization-extract
  - webforms-page-extraction
  - masterpage-resolution
  - viewstate-state-recovery
---

# WebForms Extraction Patterns

## Purpose
Produce a complete, schema-validated representation of an ASP.NET
WebForms application so that Modernization Design and Generate steps can
reason about every page, control, event handler, and state access without
re-parsing `.aspx` markup. Discovery identifies the app as WebForms;
this skill is the Extraction-phase counterpart. Without it, a 433-page
IACRA or a 75-page CPDSS sinks to an opaque token and the Ralph Loop
regenerates pages against hallucinated lifecycle assumptions. The skill
walks the triad (`foo.aspx`, `foo.aspx.cs` or `.aspx.vb`, and
`foo.aspx.designer.cs` or `.vb`) as a single unit, resolves Master Page
inheritance chains, indexes user controls (`.ascx`) and declared server
controls, binds every markup-level event wire and VB.NET `Handles`
clause to its code-behind method, and enumerates ViewState, Session,
Application, and cookie surfaces. Every record carries a
`{repo}:{file}:{line}` citation so that Design can propose a target
topology and Generate can produce a migration the G-04a/b gates can
verify.

## Inputs
- Source repository containing `.aspx`, `.ascx`, `.master`,
  `.aspx.cs`/`.aspx.vb`, `.ascx.cs`/`.ascx.vb`, `.master.cs`/`.master.vb`,
  `.aspx.designer.cs`/`.aspx.designer.vb`, `Global.asax`,
  `Global.asax.cs`/`.vb`, `web.config`, and `.asmx` files.
- Discovery fingerprint from `dotnet-discovery-patterns` (JSON) with the
  archetype `web-app` and `tech_stack` containing `aspnet-webforms` or
  equivalent.
- Application catalog entry (`application-catalog-entry.schema.json`)
  for the app under extraction, providing `primary_language`,
  `primary_runtime`, and per-app overrides.
- Client-profile risk-classification config
  (`profiles/<client>/risk-classification.yaml`) for finding severity
  banding.
- Optional: IIS `applicationHost.config` fragments for routing rules
  that override in-app handlers.

## Outputs
All outputs are JSON; every field carries at least one
`{repo}:{file}:{line}` citation.

- **`webforms-page-manifest.json`** — one record per `.aspx`:
  `page_path`, `codebehind_path`, `codebehind_language`
  (`csharp` | `vbnet`), `designer_path`, `master_page`,
  `inherits_class`, `event_handlers[]`, `declared_controls[]`
  (`id`, `type`, `runat`), `viewstate_usage`,
  `session_keys_referenced`, `output_cache_profile`,
  `auto_event_wireup`.
- **`webforms-master-hierarchy.json`** — Master Page inheritance
  graph, `<%@ MasterType %>` directives, nested-master chains,
  `ContentPlaceHolder[]` inventory, programmatic `MasterPageFile`
  assignments in `Page_PreInit`.
- **`webforms-controls-manifest.json`** — one record per user
  control (`.ascx`) with its code-behind pairing; one record per
  declared server control per page; resolved `<%@ Register %>`
  directives mapping tag prefix to target control file or assembly.
- **`webforms-event-graph.json`** — one record per event wire:
  markup `OnClick="..."`, `AutoEventWireup` implicit wires,
  `AddHandler`/`+=` code-behind subscriptions, and VB.NET
  `Handles Control.Event` clauses. Includes grid `RowCommand`,
  `SelectedIndexChanged`, and custom events.
- **`webforms-state-manifest.json`** — ViewState keys per page,
  `Session[...]` keys with scope category, `Application[...]` global
  cache keys, `HttpContext.Items` slots, and cookie read/write sites.
- **`webforms-legacy-lifecycle-findings.json`** — modernization
  blockers: `HttpContext.Current` use, `Response.Redirect(..., true)`,
  deep `IsPostBack` branching, double-firing DataBound events,
  ViewState-as-session, inline `<% %>` scripts, and
  `<script runat="server">` blocks.
- **`webforms-data-binding-manifest.json`** — `<asp:SqlDataSource>`,
  `<asp:ObjectDataSource>`, `<asp:EntityDataSource>`,
  `<asp:LinqDataSource>`, `<asp:XmlDataSource>`, code-behind
  `DataBind()` calls, and grid column definitions (bound vs.
  template vs. `CommandField`).

## Methodology
1. **Enumerate triads.** Walk the repo for every `.aspx`, `.ascx`,
   `.master`. For each markup file, locate its code-behind by the
   `<%@ Page CodeFile="..." %>` directive (or `CodeBehind=` for
   compiled deployments) and its designer by filename convention.
   Emit one page record; flag orphans (designer without code-behind,
   code-behind without markup) as findings. Detect
   `codebehind_language` from the code-behind file extension
   per-page — a solution may mix C# and VB.NET.
2. **Parse page directives.** Extract `<%@ Page %>`, `<%@ Master %>`,
   `<%@ Control %>`, `<%@ Register %>`, `<%@ Assembly %>`,
   `<%@ Import %>`, `<%@ MasterType %>`, and `<%@ OutputCache %>`.
   Capture `MasterPageFile`, `Inherits`, `AutoEventWireup`,
   `EnableViewState`, `ValidateRequest`, `Theme`. Resolve each
   Register `Src=` to its target `.ascx` or assembly+namespace.
3. **Resolve Master Page chains.** Walk each page's `MasterPageFile`
   through the `<%@ Master %>` directive of each master transitively
   to the root. Record the full chain and every `ContentPlaceHolder`.
   Detect programmatic `MasterPageFile` assignment in `Page_PreInit`.
4. **Discriminate designer files.** Identify `.aspx.designer.cs`/
   `.aspx.designer.vb` by filename plus `<auto-generated>` header or
   `[GeneratedCode]` attribute. Extract only control field
   declarations; never extract method bodies from designer files.
5. **Index declared server controls.** Emit one record per
   `runat="server"` element: `id`, `type`, containing scope,
   validation attributes, and declared `On<Event>=` wires.
6. **Build the event graph.** Detect three wiring paths:
   (a) markup `OnClick="Method"`; (b) `AutoEventWireup="true"`
   name-bound methods (`Page_Load`, `Page_Init`, `Page_PreRender`,
   etc.); (c) VB.NET `Handles Control.Event` clauses. Also scan
   code-behind for `AddHandler`, `+=` subscriptions, and
   `Controls.Add(...)` dynamic wires in `OnInit`. Emit one record per
   wire with the wiring mechanism cited.
7. **Inventory user and custom server controls.** Walk every `.ascx`
   triad; resolve every Register `Src=` to the target `.ascx` and
   every `Namespace`+`Assembly` form to the custom-control assembly.
   Emit one controls-manifest record per control plus one per binding.
8. **Enumerate state surfaces.** Grep code-behind for
   `ViewState["..."]`, `Session["..."]`, `Application["..."]`,
   `HttpContext.Items[...]`, and cookie read/writes. Record key,
   access mode, and call site. Categorize Session keys by scope
   (cross-page, per-user, per-request).
9. **Extract web.config once per app.** Read `<system.web>/<pages>`
   for app-wide defaults (`MasterPageFile`, `ValidateRequest`,
   `EnableViewState`, `Theme`), `<sessionState>` mode,
   `<authentication>`, `<authorization>`, and `<httpHandlers>` /
   `<handlers>` mappings. Emit one app-level record.
10. **Extract Global.asax.** Record `Application_Start`,
    `Session_Start`, `Application_BeginRequest`,
    `Application_AuthenticateRequest`, `Application_Error`, and any
    `RouteCollection` registrations as a first-class manifest entry.
11. **Surface lifecycle findings.** Emit findings for
    `HttpContext.Current` use outside Page/Handler,
    `Response.Redirect(..., true)`, deep `IsPostBack` branching,
    ViewState-as-session, inline `<% %>` scripts,
    `<script runat="server">` blocks, and `[WebMethod]` on `.asmx`.
12. **Validate and hand off.** Every record carries both
    `{artifact}:{section}:{finding-id}` and `{repo}:{file}:{line}`;
    records without citations are dropped. Validate each output
    against its schema and write the seven manifests to the
    Extraction working set.

## Tech-Stack Dispatch

| Trigger | Key patterns |
|---|---|
| `.aspx` + `.aspx.cs` + `.aspx.designer.cs` | C# WebForms triad, `AutoEventWireup`, `OnClick=` wiring |
| `.aspx` + `.aspx.vb` + `.aspx.designer.vb` | VB.NET WebForms triad, `Handles` clauses, `My.*` globals |
| `.master` + `<%@ Master MasterPageFile=... %>` | Nested Master Page, transitive chain resolution |
| `<%@ Register Src=... %>` | User-control binding, `.ascx` resolution |
| `<%@ Register TagPrefix Namespace Assembly %>` | Custom server control from external assembly |
| `.asmx` + `[WebMethod]` | ASMX SOAP/AJAX service endpoint |
| `<asp:SqlDataSource>` / `<asp:ObjectDataSource>` | Declarative data binding, connection-string reference |
| `<%@ OutputCache Duration=... %>` | Page-level output caching |

Detection is mechanical: one signal triggers the matching reference
pattern. Overlap with `dotnet-extraction-patterns` is explicit — this
skill is the WebForms-specific complement; non-WebForms `.NET` extraction
continues through the general `.NET` skill.

## Gotchas
- **The triad is one unit.** `foo.aspx` + `foo.aspx.cs` +
  `foo.aspx.designer.cs` must be treated as a single page. The
  designer is auto-generated; extracting logic from it produces
  phantom methods. Orphan triads (designer without code-behind from
  a partial VSS/SVN import; markup without designer from a broken
  Visual Studio refresh) are real — emit them as findings, never
  silently repair.
- **Code-behind language varies per page.** A solution may mix C#
  and VB.NET. CHAPS/CPDSS/AMCS/MedXPress are C#; IACRA is
  predominantly VB.NET (1,133 `.vb` files). Detect per-page from
  extension and route to the matching parser; a C#-only parser on a
  `.vb` file emits zero event handlers and looks like success.
- **`.aspx.designer.cs` is not business logic.** Identify by
  `<auto-generated>` header or `[GeneratedCode]` attribute; extract
  only control field declarations. Treating designer methods as
  real code-behind surfaces non-existent handlers the Ralph Loop
  then regenerates.
- **`AutoEventWireup` swings half the event graph.** With
  `AutoEventWireup="true"` (the default), `Page_Load` is wired by
  name. With `"false"`, events must be explicitly hooked in `OnInit`
  or via markup. Missing the mode drops or duplicates lifecycle
  wires on every affected page.
- **VB.NET `Handles` clauses wire events without markup.**
  `Private Sub Button1_Click(...) Handles Button1.Click` binds with
  no `OnClick=` attribute. A C#-only parser reports the control as
  dead. IACRA is full of this pattern.
- **Master Page inheritance is transitive.** `CPDSSMaster.Master`
  inherits from `MainMaster.Master`; CHAPS `Nested.Master` lives
  under `Site.Master`. Walk to the root; capturing only the
  immediate parent misses outer layouts and top-level
  `ContentPlaceHolder`s.
- **Two logins, one app.** CHAPS has `LobbyLogin.aspx` AND
  `CHAPSLogin.aspx`. Do not collapse them — two auth entry points is
  a security finding, not a deduplication opportunity.
- **Large pages are real.** AMCS `f8500p1.aspx` is 72 KB of markup;
  its code-behind is 59 KB. Do not cap page size during extraction.
- **Inline server script breaks most parsers.**
  `<% Response.Write(...) %>` and `<script runat="server">` blocks
  appear in ATLAS apps. Extract as findings; do not fail the parse.
- **`web.config` `<pages>` is app-wide.** `MasterPageFile`,
  `ValidateRequest`, `EnableViewState`, and `Theme` set here apply
  to pages that do not override. Extract once per app.
- **ViewState is not secure.** Sensitive data round-tripped through
  ViewState is a security finding. Every `ViewState[...] =` must be
  enumerated so security-scan-review can flag sensitive keys.
- **`Global.asax` is not a page.** Extract it as a first-class file
  with its own handlers and any `RouteCollection` registrations.
  Skipping loses session-lifecycle and global-error surfaces.
- **WebForms + MVC coexist.** A migration-in-flight project may
  have both. Detect `RouteCollection` registration in `Global.asax`
  and emit a hybrid finding; downstream modernization handles both.
- **IACRA zero-byte sentinels.** `forms/*` contains zero-byte files
  preserved from SVN/VSS metadata. Filter triads by non-zero markup
  size after pairing.
- **Secondary web roots are real.** IACRA has a secondary
  `src/IACRA.Web/` with `ChoosePath.aspx`, `COChecklist.aspx`, and
  `Form8060-71.aspx`. Enumerate every web root, not just the
  primary one.

## Quality Rules
- [ ] Every `.aspx` in the repo has a page-manifest record with
      `codebehind_path`, `codebehind_language`, `designer_path`,
      `master_page`, and `inherits_class` populated (or flagged as
      orphan with a finding).
- [ ] Every page-manifest record cites at least one
      `{repo}:{file}:{line}` source line.
- [ ] `codebehind_language` is exactly `csharp` or `vbnet`; no free-form
      values.
- [ ] Every Master Page chain is resolved transitively to the root;
      nested-master depth is recorded.
- [ ] Every `<%@ Register %>` directive is resolved to a target
      `.ascx` file or assembly+namespace; unresolved Registers emit a
      finding.
- [ ] Every event-graph record names the source control, the event
      name, the handler method, and the wiring mechanism
      (`markup-onclick` | `auto-event-wireup` | `vb-handles` |
      `code-behind-addhandler`).
- [ ] VB.NET `Handles` clauses are extracted alongside markup wires;
      parity is verified on at least one predominantly-VB.NET app
      (IACRA).
- [ ] `.aspx.designer.cs` / `.aspx.designer.vb` files contribute only
      control field declarations; no method bodies are extracted as
      code-behind.
- [ ] Every ViewState, Session, Application, and cookie read/write is
      recorded with key name, access mode, and call site.
- [ ] `Global.asax` is extracted as a first-class manifest entry when
      present.
- [ ] Every finding record validates against the finding schema and
      carries both `{artifact}:{section}:{finding-id}` and
      `{repo}:{file}:{line}` citations.
- [ ] Emitted JSON validates against the WebForms extraction schema
      family with no `additionalProperties` violations.

## Common Failure Modes
| Failure Mode | Symptom | Prevention |
|---|---|---|
| Designer file extracted as business logic | Phantom `InitializeComponent` methods and non-existent handlers appear in the event graph; Ralph Loop regenerates stubs for methods that do not exist | Identify designer files by `<auto-generated>` header or filename convention; extract only control field declarations |
| C#-only parser run over VB.NET code-behind | IACRA returns zero event handlers across 433 pages; controls reported as unwired | Detect `codebehind_language` from file extension per-page; route `.vb` through a VB.NET parser that understands `Handles` clauses |
| `AutoEventWireup` ignored | `Page_Load` wires dropped on apps that set `AutoEventWireup="true"`; or spurious `Page_Load` wires emitted on apps that set `AutoEventWireup="false"` | Read the directive and branch the wiring logic; default is `true` when absent |
| Master Page chain truncated at depth 1 | Nested Master layouts lose outer `ContentPlaceHolder`s; pages appear to render in the wrong layout | Walk `<%@ Master MasterPageFile=... %>` transitively to the root |
| Two logins collapsed into one | CHAPS `LobbyLogin.aspx` and `CHAPSLogin.aspx` merged; authentication surface under-reported | Emit one page record per `.aspx`; deduplication based on name similarity is forbidden |
| Inline server script crashes the parse | `<% ... %>` or `<script runat="server">` blocks halt extraction on affected pages | Treat inline server script as an extractable finding, not a fatal parse error |
| `web.config` `<pages>` defaults ignored | Per-page records show `MasterPageFile=null` when in fact the app-wide default applies | Extract `<pages>` once; merge its defaults into each page record where the page does not override |
| Zero-byte sentinel pages emitted | IACRA `forms/*` sentinels counted as real pages; page-count totals doubled | Filter triads by non-zero markup size after pairing |

## Handoff Summary
When this skill completes, verify:
1. Every `.aspx` in every web root has a page-manifest record with
   triad paths, master chain, event handlers, and state accesses
   populated.
2. The event graph wires markup `OnClick`, `AutoEventWireup` implicit
   binds, and VB.NET `Handles` clauses; no control is reported
   unwired when its code-behind handles an event.
3. Every manifest record cites `{repo}:{file}:{line}`; no record
   ships without traceability.
4. `web.config` `<pages>` defaults, `Global.asax` handlers, and
   secondary web roots are represented.

Then proceed to: `dotnet-extraction-patterns` for non-WebForms
portions of a hybrid solution; `legacy-database-archaeologist` for
SQL surfaces referenced by `<asp:SqlDataSource>` and code-behind
`SqlConnection` calls; and the Design step of the Modernization
factory, which consumes these manifests to propose a target
topology. The next gate is **G-04a** (Extraction Completeness),
where every page must be accounted for and every event wire must
resolve to a code-behind method before Design begins.

## References
- `references/aspx-codebehind-triad-extraction.md` — triad pairing,
  page-directive parsing, C# and VB.NET event-handler extraction,
  Register resolution, orphan detection.
- `references/masterpage-and-controls-extraction.md` — Master Page
  chain resolution, `ContentPlaceHolder` inventory, nested masters,
  `<%@ MasterType %>`, programmatic `MasterPageFile` assignment,
  user-control (`.ascx`) discovery, custom server-control assembly
  references.
- `references/viewstate-session-state-extraction.md` — ViewState
  lifecycle, key tracking, `EnableViewState` overrides, Session
  key scope categorization, Application cache, `HttpContext.Items`,
  cookies, and `<%@ OutputCache %>` profiles.

## Changelog
- 0.1.0 (2026-05-06) — Initial skill authored for the WebForms
  extraction gap. Covers triad pairing, page-directive parsing,
  Master Page chain resolution, user-control inventory,
  server-control indexing, C# and VB.NET event graph construction,
  state-surface enumeration, data-binding manifest, and
  legacy-lifecycle findings. Full enrichment; feeds the
  Modernization Design step and the G-04a gate.
