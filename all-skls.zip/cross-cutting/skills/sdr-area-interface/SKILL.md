---
name: sdr-area-interface
description: >
  Structured discovery of application interface layer: controllers, endpoints, routes,
  views, forms, API definitions. Use during Discovery (D1.3 Pass 1).
  Triggers on interface discovery, endpoint analysis, controller mapping, route inventory.
agent: opus
allowed-tools:
  - Read
  - Grep
  - Bash
---

# Structured Discovery Report — Interface Area

## Purpose
Systematically discover every entry point into the application: HTTP routes, form
submissions, REST/SOAP/GraphQL API endpoints, message consumers, batch job entry
points, WebSocket handlers, and scheduled task triggers. This is the first area
pass in structured discovery. No endpoint may be invisible to downstream analysis.

The interface inventory produced here becomes the contract surface that the
Modernization line must preserve or intentionally replace. Missing an endpoint
means silent functional regression in the modernized system.

## Inputs
- Source code repository (local path from config)
- Tech-stack detection results (from legacy-architecture-mapper or manual config)
- Framework documentation references (loaded from parent skill references/)

## Outputs
- Complete interface inventory (assets/interface-inventory-template.yaml)
- Endpoint classification report (user-facing, API, internal, health, admin)
- Authentication/authorization mapping per endpoint
- External service consumption inventory

## Methodology

### Step 1 — Detect Framework and Routing Convention
Read project configuration files to identify the web framework and its routing
model. Check for:
- ColdFusion: Application.cfc, .cfm files, FW/1 or ColdBox routes
- Java EE: web.xml, Spring @RequestMapping, JAX-RS @Path, Struts config
- .NET: Startup.cs route config, ASP.NET WebForms .aspx pages, MVC controllers
- PHP: Laravel routes/, Symfony routing.yaml, WordPress rewrite rules
- Node.js: Express app.use/app.get, Koa router, Fastify routes
- Python: Django urls.py, Flask @app.route, FastAPI decorators

Load the appropriate reference file from the parent skill's references/ directory
based on detected technology.

### Step 2 — Enumerate All Routes and Endpoints
Scan for every route definition using framework-specific patterns:
- Grep for route annotations, decorators, and configuration entries
- Parse route configuration files (web.xml, routes.rb, urls.py, etc.)
- Detect convention-based routes by scanning controller directories
- Check for programmatic route registration in application bootstrap code

Record each endpoint with: HTTP method, URL pattern, handler reference.

### Step 3 — Map Endpoints to Handler Functions
For each discovered route, trace to its handler implementation:
- Resolve the controller class and method with exact file:line
- Follow middleware chains to identify pre/post processing
- Map filter chains (Java EE), middleware stacks (Express), before_action (Rails)
- Document the full request processing pipeline per endpoint

### Step 4 — Identify Request/Response Schemas
For each endpoint, extract:
- Request parameters (query string, path params, headers)
- Request body schema (form fields, JSON structure, XML/SOAP envelope)
- Response format (HTML template, JSON schema, XML schema, binary)
- Content negotiation rules (Accept header handling)
- WSDL definitions for SOAP services

### Step 5 — Classify Each Endpoint
Apply classification labels:
- **user-facing**: Renders HTML, serves pages, handles form submissions
- **api**: Returns structured data (JSON/XML) for programmatic consumption
- **internal**: Called only by other services or internal components
- **health**: Health checks, readiness probes, monitoring endpoints
- **admin**: Administrative functions, configuration endpoints, debug tools

### Step 6 — Map Authentication and Authorization
For each endpoint, determine:
- Whether authentication is required (and type: session, token, certificate, API key)
- Authorization model (role-based, permission-based, attribute-based)
- Specific roles or permissions required
- Anonymous access patterns
- CSRF protection presence

## Tech-Stack Dispatch
Before analysis, detect the source technology from file extensions and config
files, then load the appropriate reference from the `legacy-architecture-mapper`
or `extraction` skill:
- ColdFusion (.cfm, .cfc, Application.cfc) -> legacy-architecture-mapper ColdFusion patterns
- Java EE (.java, pom.xml, web.xml) -> legacy-architecture-mapper Java EE patterns
- .NET (.cs, .csproj, .sln, web.config) -> extraction skill .NET WebForms patterns
- PHP (.php, composer.json) -> extraction skill PHP patterns

## Interface Type Dispatch

Once routes/handlers are enumerated, each endpoint must be classified by
interface *type* and the matching reference file loaded. Type determines
the discovery checklist, error-code model, and downstream contract shape.

| Interface type | Detection signals | Reference |
|---|---|---|
| REST (HTTP+JSON) | `@RestController`, `@app.route`, Express/Koa/Fastify, OpenAPI/Swagger specs, `application/json` response type | (handled by framework references above) |
| gRPC | `.proto` files, `service`/`rpc` blocks, `grpc.Server`, `@GrpcService`, HTTP/2 endpoints, `grpc-gateway` annotations | `references/grpc-patterns.md` |
| GraphQL | `.graphql`/`.gql` files, `type Query`/`Mutation`/`Subscription`, Apollo/graphene/strawberry/graphql-java, single `/graphql` endpoint | `references/graphql-patterns.md` |
| Async messaging | SQS/SNS clients, `@KafkaListener`, `@RabbitListener`, `KafkaProducer`, `basic_publish`, queue/topic/exchange declarations, no HTTP surface | `references/async-messaging-patterns.md` |

Multiple interface types frequently coexist in one application (e.g. a REST
API plus Kafka consumers). Inventory each separately; do not force a single
classification per service.

## Gotchas
- **Convention-based routing is invisible to grep**: Rails, Laravel, and Spring
  Boot generate routes from controller names and method names. You must understand
  the convention to enumerate routes. Scanning controller directories is required,
  not optional.
- **Middleware chains transform requests before controllers**: A route that appears
  simple may pass through authentication, logging, rate limiting, CORS, and
  compression middleware. Document the full chain.
- **WebSocket endpoints don't appear in route tables**: They use upgrade handshakes
  on HTTP endpoints. Check for ws:// handlers, Socket.IO setup, SignalR hubs.
- **SOAP WSDLs define implicit endpoints**: Each WSDL operation becomes an endpoint
  even though the URL is the same. Treat each operation as a separate endpoint.
- **Batch job entry points have no HTTP route**: They are triggered by schedulers,
  cron, or message queues. Check for @Scheduled, cron configs, DBMS_SCHEDULER,
  Windows Task Scheduler references, and message listener annotations.
- **API gateway routes may not be in the application code**: Check for gateway
  configurations (Kong, API Gateway, nginx) that route to the application.
- **gRPC services have no HTTP routes**: Endpoints live in `.proto` `service`
  blocks over HTTP/2. Parse proto files; classify each `rpc` by pattern
  (unary/server-stream/client-stream/bidi). See `references/grpc-patterns.md`.
- **GraphQL hides N endpoints behind one URL**: A single `POST /graphql` URL
  fronts every `Query`/`Mutation`/`Subscription` field. Treat each top-level
  field as an endpoint. See `references/graphql-patterns.md`.
- **Async consumers are endpoints too**: Kafka/SNS/SQS/RabbitMQ handlers
  receive traffic from producers and must be inventoried with their
  topic/queue/exchange, delivery semantics, and DLQ wiring. See
  `references/async-messaging-patterns.md`.

## Quality Rules
Before marking interface discovery complete, verify:
- [ ] Every source file in the repository has been scanned for route definitions
- [ ] Every discovered endpoint has a file:line reference to its handler
- [ ] Every endpoint has been classified (user-facing, api, internal, health, admin)
- [ ] Authentication/authorization mapping is complete for all endpoints
- [ ] External service consumption inventory includes all outbound calls
- [ ] Message consumers and batch entry points are documented
- [ ] No TBD or placeholder entries remain in the inventory

## Common Failure Modes

| Failure | Symptom | Prevention |
|---------|---------|------------|
| Missed convention routes | Modernized app has fewer endpoints than legacy | Scan controller directories, not just route configs |
| Missed middleware | Auth bypass in modernized app | Trace full request pipeline per endpoint |
| Missed SOAP operations | SOAP clients break against modernized service | Parse WSDLs, treat each operation as an endpoint |
| Missed batch triggers | Scheduled jobs don't run in modernized system | Check cron, scheduler configs, message listeners |
| Incomplete auth mapping | Security regression in modernized app | Test every endpoint for auth requirements |
| Missed WebSocket handlers | Real-time features silently break | Search for ws://, Socket.IO, SignalR patterns |

## Handoff Summary
After completing the interface inventory:
1. Verify the total endpoint count matches independent scan results
2. Confirm every endpoint has a handler with file:line traceability
3. Confirm all external service dependencies are documented
4. Save the completed inventory to the artifacts directory
5. Proceed to **extraction** for business rule extraction
