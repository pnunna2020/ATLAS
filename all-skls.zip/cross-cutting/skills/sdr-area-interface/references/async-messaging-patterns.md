# Async Messaging Interface Discovery Patterns

Reference for discovering message-driven interfaces. Unlike REST/gRPC/GraphQL,
async messaging interfaces have no request/response HTTP signature — they are
defined by **producers**, **brokers**, **topics/queues/exchanges**, and
**consumers**. Missing an async consumer during discovery silently drops
business events in the modernized system.

FAA default broker stack (per project memory): **AWS SQS + SNS**. Kafka and
RabbitMQ are covered for parity with broader portfolio patterns.

## 1. AWS SQS and SNS

### SQS (queue, point-to-point)

- **Standard queues**: unlimited throughput, at-least-once delivery, best-effort order.
- **FIFO queues** (`*.fifo`): exactly-once within a `MessageGroupId`, strict order, 300 TPS default.
- **Dead-letter queue (DLQ)**: redrive moves messages after `maxReceiveCount` failed receives. Always inventory DLQs.
- **Visibility timeout**: must exceed worst-case handler time or messages redeliver while still being processed.
- **Long polling** (`WaitTimeSeconds=20`): preferred over short polling; record which is in use.

Grep targets: `SendMessage`, `ReceiveMessage`, `boto3.client("sqs")`, `@SqsListener`, `QueueUrl=`, `.fifo`, `RedrivePolicy`.

### SNS (pub/sub, fan-out)

- **Topics** fan out to multiple subscribers (SQS, Lambda, HTTP, email, SMS).
- **FIFO topics** can only fan out to FIFO queues.
- **Message filtering**: `FilterPolicy` on subscription selects by attribute.
- **Protocols**: `sqs`, `lambda`, `http(s)`, `email`, `sms`, `firehose`.

Inventory every topic ARN, every subscription ARN, filter policies, and the downstream handler. Anti-patterns to flag: producers writing directly to SQS that should be behind SNS (no fan-out); missing DLQs on Lambda SQS triggers; `DeleteMessage` never called on success path (messages redeliver forever).

## 2. Apache Kafka

### Topology primitives

- **Topic** — named, append-only log. Partitioned for parallelism.
- **Partition** — ordered sequence; ordering is guaranteed only within a partition.
- **Producer** — writes to topics; `acks=all` for durability.
- **Consumer group** — parallel consumers across partitions; each partition
  consumed by exactly one member.
- **Offset** — consumer's committed position per partition.

Grep targets: `KafkaProducer`, `KafkaConsumer`, `@KafkaListener`, `topic =`,
`group.id`, `bootstrap.servers`, `acks=`, `auto.offset.reset`.

### Delivery guarantees

- `acks=0`: fire-and-forget (at-most-once). `acks=1`: leader ack (at-least-once, risk of loss on failover).
- `acks=all` + `enable.idempotence=true`: at-least-once with no duplicates per producer session.
- **Transactions** (`transactional.id`) enable exactly-once across topics, including Kafka Streams read-process-write.

### Discovery checklist

- [ ] Every topic's name, partition count, replication factor.
- [ ] Every consumer group's `group.id` and handler.
- [ ] Schema Registry usage (Avro/Protobuf/JSON-Schema) and subject naming.
- [ ] `cleanup.policy=compact|delete` and DLT pattern (`*.DLT`, Spring Kafka).

## 3. RabbitMQ

### AMQP primitives

- **Exchange** — router. Types: `direct`, `topic`, `fanout`, `headers`.
- **Queue** — message buffer.
- **Binding** — exchange-to-queue link with a routing key or pattern.
- **Routing key** — on `direct`/`topic` exchanges, decides which queues receive.

### Patterns to record

- **Work queue**: default exchange, round-robin across consumers.
- **Pub/Sub**: `fanout` exchange — every bound queue gets every message.
- **Topic routing**: `topic` exchange with patterns like `flight.*.weather`.
- **RPC**: `reply_to` + `correlation_id` request/reply over queues.
- **Dead-letter exchange** (`x-dead-letter-exchange` queue arg): redrive path.
- **Quorum queues** (replicated, durable) vs classic queues.

Grep targets: `basic_publish`, `basic_consume`, `@RabbitListener`, `exchange=`, `routing_key=`, `queue_declare`, `x-dead-letter-exchange`.

## 4. Idempotency

At-least-once is the common real-world guarantee. Consumers must be idempotent.

- **Idempotency key**: producer-generated UUID in message header/body.
  Consumer persists processed keys (DynamoDB, Redis with TTL, Postgres
  unique constraint) and skips duplicates.
- **Natural keys**: if the business payload has a unique ID (order number),
  use it as the idempotency key.
- **Outbox pattern**: producer writes message to an `outbox` table in the
  same DB transaction as the state change; a relay publishes asynchronously.
  Prevents dual-write drift between DB and broker.
- **Inbox pattern**: consumer persists the message ID before processing;
  process-and-commit inside one DB transaction.

## 5. Dead-Letter Queues and Poison Messages

Every consumer must handle poison messages. Record per consumer: DLQ/DLT/DLX wiring (SQS `RedrivePolicy`, Kafka `*.DLT`, RabbitMQ `x-dead-letter-exchange`); max retry count before DLQ routing; backoff strategy (immediate vs exponential backoff via retry queue with `x-message-ttl`); alarm on DLQ depth > 0 (CloudWatch, Prometheus).

## 6. Delivery-Semantics Matrix

| Semantics | Meaning | Typical use |
|---|---|---|
| At-most-once | May be lost, never duplicated | Metrics, telemetry |
| At-least-once | May be duplicated, never lost | Most business events |
| Exactly-once | No loss, no duplication | Ledger writes, financial events |

True exactly-once requires broker+consumer cooperation: Kafka transactions + idempotent producer + transactional consumer write; SQS FIFO with `MessageDeduplicationId`; or an idempotency key on at-least-once delivery. Flag any exactly-once claim not backed by one of these mechanisms.

## 7. Schema Evolution and Observability

Async interfaces outlive sync ones — schemas must evolve without breaking consumers. Record:

- Schema registry (Confluent, AWS Glue) and compatibility mode (`BACKWARD`, `FORWARD`, `FULL`, `NONE`).
- Envelope pattern: CloudEvents (`{"specversion": "1.0", "type": ..., "data": ...}`) vs bespoke.
- Versioning: topic-per-version vs in-schema version field.
- Trace context propagation (`traceparent`, OpenTelemetry `messaging.*` attributes).
- Consumer lag metric (Kafka `consumer_lag`, SQS `ApproximateAgeOfOldestMessage`).

## Citations

- AWS SQS developer guide: https://docs.aws.amazon.com/AWSSimpleQueueService/latest/SQSDeveloperGuide/welcome.html
- AWS SQS dead-letter queues: https://docs.aws.amazon.com/AWSSimpleQueueService/latest/SQSDeveloperGuide/sqs-dead-letter-queues.html
- AWS SNS developer guide: https://docs.aws.amazon.com/sns/latest/dg/welcome.html
- SNS subscription filter policies: https://docs.aws.amazon.com/sns/latest/dg/sns-subscription-filter-policies.html
- Apache Kafka documentation: https://kafka.apache.org/documentation/
- Kafka exactly-once & transactions: https://kafka.apache.org/documentation/#semantics
- Confluent Schema Registry: https://docs.confluent.io/platform/current/schema-registry/index.html
- RabbitMQ tutorials: https://www.rabbitmq.com/tutorials
- RabbitMQ DLX: https://www.rabbitmq.com/dlx.html
- RabbitMQ quorum queues: https://www.rabbitmq.com/quorum-queues.html
- CloudEvents spec: https://github.com/cloudevents/spec
- Transactional Outbox: https://microservices.io/patterns/data/transactional-outbox.html
