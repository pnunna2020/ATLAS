# GraphQL Interface Discovery Patterns

Reference for discovering GraphQL service surfaces. Unlike REST, GraphQL
exposes a single HTTP endpoint (usually `POST /graphql`) that accepts an
arbitrary query against a strongly typed schema. Every **field** in the
schema is effectively an endpoint for discovery purposes.

## 1. Locating the Schema

GraphQL schemas are described in the Schema Definition Language (SDL),
stored as `.graphql` or `.gql` files, or assembled programmatically.

```graphql
type Query {
  flightPlan(id: ID!): FlightPlan
  flightPlans(filter: FlightPlanFilter, first: Int, after: String): FlightPlanConnection!
}

type Mutation {
  submitFlightPlan(input: FlightPlanInput!): SubmitFlightPlanPayload!
}

type Subscription {
  weatherUpdates(station: ID!): WeatherUpdate!
}
```

Grep targets: `type Query`, `type Mutation`, `type Subscription`,
`extend type`, `@connection`, `schema {`, `buildSchema`, `makeExecutableSchema`,
`graphene.ObjectType`, `strawberry.type`.

Inventory three root types — each top-level field is an endpoint. Record name, argument schema, return type, and nullability (`!` = non-nullable).

- **Query** — read-only fields. Safe to cache and retry.
- **Mutation** — side-effecting fields. Run sequentially on the server.
- **Subscription** — long-lived streams over WebSocket or SSE.

## 2. Resolvers

Every field has a resolver function that returns the value for that field.
Resolvers form a tree that matches the query shape — one call per field per
parent object. Record the file:line of each resolver so downstream analysis
can trace business logic.

- **Apollo Server (JS/TS)**: nested objects matching the schema —
  `Query.flightPlan(parent, args, ctx, info)`.
- **Graphene (Python)**: `resolve_<field>(self, info, **args)` on `ObjectType`.
- **Strawberry (Python)**: decorated methods on `@strawberry.type` classes.
- **graphql-java**: `DataFetcher` instances in a `RuntimeWiring`.

## 3. The N+1 Problem and DataLoader

The default resolver pattern fires one DB call per field per object. A list
of 100 flight plans that each resolve `pilot { name }` triggers 101 queries.
DataLoader batches and caches calls within a single request.

```js
// Apollo example
const pilotLoader = new DataLoader(async (ids) =>
  db.pilots.findMany({ where: { id: { in: ids } } })
);
// Resolver: parent => pilotLoader.load(parent.pilotId)
```

Discovery checklist:

- [ ] Does the service use DataLoader (JS), `aiodataloader` (Python),
      `graphql-java-dataloader`, or an equivalent?
- [ ] Is a fresh loader created per request? Leaking loaders between
      requests cross-contaminates cache keys — a correctness bug.
- [ ] Are loader keys normalized (e.g. cast IDs to strings)?

## 4. Security Considerations

Record these during discovery — they are commonly missing in legacy gateways:

- **Query depth limiting** (`graphql-depth-limit`) — prevents `user { friends { friends { ... } } }` DOS recursion.
- **Query complexity analysis** (`graphql-query-complexity`) — assigns per-field cost, rejects expensive queries.
- **Persisted queries / APQ** — only pre-approved query hashes allowed (`extensions.persistedQuery.sha256Hash`).
- **Introspection in production** — `__schema` / `__type` leak the API surface; Apollo disables it outside dev by default.
- **Field-level authorization** — in resolvers or via `@auth` directives. Record authz model per field.

## 5. Federation

Apollo Federation composes subgraphs into one supergraph. Markers:

- `@key(fields: "id")` — declares an entity the gateway can resolve.
- `@external`, `@requires`, `@provides` — cross-subgraph field declarations.
- `extend type Query` — gateway stitches to other subgraphs.
- Router/gateway: Apollo Router (`router.yaml`), Apollo Gateway (Node.js with `IntrospectAndCompose`).

Inventory each subgraph's `_service { sdl }` endpoint and federation version (v1 vs v2).

## 6. Subscriptions Transport

- **graphql-ws** (WebSocket, modern) — Apollo and graphql-yoga default.
- **subscriptions-transport-ws** — legacy, deprecated but still common.
- **graphql-sse** (Server-Sent Events) — firewall-friendly alternative.

## 7. Schema Conventions Worth Citing

- **Relay Cursor Connections**: `PageInfo`, `edges[].node`, `edges[].cursor`
  — if you see `Connection!` return types, expect cursor-based pagination.
- **Input / Payload types**: mutations take `input: FooInput!` and return
  `FooPayload` wrappers carrying `clientMutationId`, `errors`, and the entity.
- **Custom scalars**: `DateTime`, `UUID`, `JSON` — each needs a parser/serializer.
  Record the library used (graphql-iso-date, etc.).

## Citations

- GraphQL spec & SDL: https://graphql.org/learn/schema/
- Queries, mutations, subscriptions: https://graphql.org/learn/queries/
- Best practices: https://graphql.org/learn/best-practices/
- Apollo Server docs: https://www.apollographql.com/docs/apollo-server/
- Apollo Federation: https://www.apollographql.com/docs/federation/
- DataLoader: https://github.com/graphql/dataloader
- graphql-ws protocol: https://github.com/enisdenjo/graphql-ws
- Relay Cursor Connections: https://relay.dev/graphql/connections.htm
