# gRPC Interface Discovery Patterns

Reference for discovering gRPC service surfaces in legacy and modernized
systems. gRPC uses HTTP/2 as transport and Protocol Buffers (proto3) as the
interface definition language. Citations at the end of the file.

## 1. Locating Service Definitions

gRPC services are declared in `.proto` files, usually under `proto/`, `idl/`,
`api/`, or `contracts/`. Every `service` block is an interface surface; every
`rpc` inside it is an endpoint.

```proto
syntax = "proto3";
package faa.flightplans.v1;

service FlightPlanService {
  rpc GetPlan (GetPlanRequest) returns (FlightPlan);
  rpc StreamWeather (WeatherRequest) returns (stream WeatherUpdate);
  rpc UploadTrack (stream TrackPoint) returns (TrackSummary);
  rpc LiveTelemetry (stream PingRequest) returns (stream PingResponse);
}
```

Grep targets: `^service `, `^\s*rpc `, `stream `, `import "google/`.

## 2. The Four RPC Patterns

| Pattern | Signature | When to expect |
|---|---|---|
| Unary | `rpc M(R) returns (S);` | CRUD, command dispatch |
| Server streaming | `rpc M(R) returns (stream S);` | Subscriptions, long queries, log tails |
| Client streaming | `rpc M(stream R) returns (S);` | Uploads, aggregation |
| Bidirectional streaming | `rpc M(stream R) returns (stream S);` | Chat, interactive telemetry |

Each streaming mode requires different client and server semantics — record
the pattern per endpoint so generators know which handler shape to emit.

## 3. Status Codes (Never Use HTTP Codes)

gRPC defines a closed enum of 17 status codes. Map errors to this enum, not
HTTP `200`/`500`. Record per endpoint which codes it raises and whether it
uses `google.rpc.Status` with `details[]` for structured error payloads.

| Code | Typical cause |
|---|---|
| `OK` (0), `CANCELLED` (1) | Success; client cancelled / deadline killed |
| `INVALID_ARGUMENT` (3), `FAILED_PRECONDITION` (9) | Bad request; invalid state |
| `DEADLINE_EXCEEDED` (4) | Client-supplied deadline passed |
| `NOT_FOUND` (5), `ALREADY_EXISTS` (6) | Missing entity; idempotency violation |
| `PERMISSION_DENIED` (7), `UNAUTHENTICATED` (16) | AuthZ / AuthN failure |
| `RESOURCE_EXHAUSTED` (8) | Rate/quota throttle, OOM |
| `ABORTED` (10) | Optimistic concurrency conflict |
| `UNIMPLEMENTED` (12), `INTERNAL` (13) | Stub method; uncaught exception |
| `UNAVAILABLE` (14) | Transient (circuit breaker, restart) |

## 4. Interceptors (Middleware Equivalent)

Interceptors wrap every call and are the gRPC analogue of HTTP middleware.
Record them during discovery because they transform request/response:

- Server-side: `grpc.ServerInterceptor` (Java), `grpc.UnaryServerInterceptor`
  (Go), `grpc.aio.ServerInterceptor` (Python).
- Client-side: `ClientInterceptor` chains for auth, retries, deadlines.
- Common uses: auth token propagation, tracing (OpenTelemetry), logging,
  rate limiting, deadline enforcement, metrics.

Grep targets: `Interceptor`, `interceptor`, `UnaryInterceptor`, `StreamInterceptor`.

## 5. Deadlines, Retries, and Keepalive

- **Deadlines** are absolute timestamps propagated via metadata. Every RPC
  should have one. Record the default deadline per service.
- **Retries** are configured in the service config JSON via
  `methodConfig.retryPolicy`. Only retry on `UNAVAILABLE`, `ABORTED`,
  and similar transient codes. Never retry `INVALID_ARGUMENT`.
- **Keepalive** pings keep long-lived streams alive through NAT. Record
  `grpc.keepalive_time_ms` server and client values.

## 6. TLS and Authentication

gRPC recommends TLS for all non-loopback traffic. Discovery should record:

- Whether the server uses `ssl_credentials` / `local_credentials` / `insecure`.
- mTLS: both sides present certs. Common in internal service meshes.
- Token auth: `authorization: Bearer <jwt>` metadata header, or call
  credentials attached to the channel.
- ALTS: Google-only transport auth; rare outside GCP.

## 7. Reflection and Health

Two standard services often co-exist with business services:

- `grpc.reflection.v1alpha.ServerReflection` — enables `grpcurl` and UI tools
  to introspect services at runtime. Record whether reflection is enabled
  (security review surface).
- `grpc.health.v1.Health` — standard health probe. Kubernetes uses this for
  liveness/readiness via `grpc_health_probe`.

## 8. Gateways and Transcoding

- **grpc-gateway** (Go) and **Envoy transcoder** expose gRPC methods as
  REST/JSON. `google.api.http` annotations inside `.proto` files define the
  mapping — treat each annotation as an additional REST endpoint.
- **gRPC-Web** allows browsers to call gRPC servers; it uses a different
  framing and typically runs behind Envoy.

## Citations

- gRPC concepts: https://grpc.io/docs/what-is-grpc/core-concepts/
- Status codes: https://grpc.io/docs/guides/status-codes/
- Deadlines: https://grpc.io/docs/guides/deadlines/
- Retry config: https://grpc.io/docs/guides/retry/
- Authentication: https://grpc.io/docs/guides/auth/
- Health checking: https://github.com/grpc/grpc/blob/master/doc/health-checking.md
- Reflection: https://github.com/grpc/grpc/blob/master/doc/server-reflection.md
- google.api.http (transcoding): https://cloud.google.com/endpoints/docs/grpc/transcoding
