---
name: oracle-extraction-patterns
description: >
  Extract a structured representation of an Oracle database tier from the
  source artifacts delivered with a legacy application during the
  Modernization Extract step. Walks PL/SQL package specs and bodies
  (`.pks`/`.pkb`), standalone procedures/functions (`.prc`/`.fnc`/`.pls`),
  triggers (`.trg`), view and table DDL in `.sql` migration scripts,
  `DBMS_SCHEDULER` job definitions, `GRANT`/`REVOKE` statements, and
  `expdp` dump prerequisites, then emits six schema-validated manifests
  (PL/SQL, schema, migration timeline, scheduler, grants, dialect findings)
  with `{repo}:{file}:{line}` traceability for every record. Runs as a
  Modernization conditional skill when the application catalog entry has
  `database` containing `oracle`. Triggers on Oracle extraction, PL/SQL
  extraction, `expdp`/`impdp` handling, `DBMS_SCHEDULER` inventory, or
  @oracle-extraction-patterns mentions.
tier: 1
triggers:
  database: [oracle]
agent: sonnet
enrichment_level: Full
version: 0.1.0
allowed-tools:
  - Read
  - Write
  - Grep
  - Glob
validation_commands:
  - "python -m olympus.validators.schema_validator oracle-plsql-manifest.json"
  - "python -m olympus.validators.schema_validator oracle-schema-manifest.json"
  - "python -m olympus.validators.schema_validator oracle-migration-timeline.json"
  - "python -m olympus.validators.schema_validator oracle-scheduler-inventory.json"
  - "python -m olympus.validators.schema_validator oracle-grants-manifest.json"
  - "python -m olympus.validators.schema_validator oracle-dialect-findings.json"
supported_stacks:
  - oracle
  - plsql
  - oracle-ebs
  - oracle-apex
anti_target_stacks:
  - sqlserver
  - postgresql
  - mysql
  - sqlite
  - static-site
failure_classes:
  - spec-body-pair-broken
  - expdp-dump-unprocessed
  - migration-timeline-misordered
  - cross-schema-synonym-unresolved
  - environment-gated-script-ignored
  - autonomous-transaction-unflagged
  - dynamic-sql-opaque-unrecorded
  - ticket-key-typo-normalized
benchmark_tags:
  - modernization-extract
  - oracle-source-extraction
  - plsql-recovery
  - migration-timeline-reconstruction
---

# Oracle Extraction Patterns

## Purpose
Produce an auditable, schema-validated extract of an Oracle database tier so
the Modernization Design step can emit a target data model without
re-reading raw PL/SQL. Given a repository that contains package bodies,
package specs, standalone procedures, triggers, ticket-keyed migration
scripts, scheduler job scripts, grants, and optionally an `expdp` dump
file, this skill normalizes every database object into structured
manifests keyed by `(schema, object_name)`, reconstructs the migration
timeline from filename conventions, resolves package-to-package call
edges, flags Oracle-specific dialect constructs that block portable
rewrites, and surfaces prerequisite findings (missing `.pkb`, `.pks`
without body, `expdp` round-trip required, cross-system migrations co-
owned by a neighbouring repo). Without this pass, Design sees an opaque
"oracle" token and cannot plan a migration, rewrite, or consolidation
target.

## Inputs
- Source code repository (Git URL or local path) containing any of
  `.pkb`, `.pks`, `.pls`, `.prc`, `.fnc`, `.trg`, `.vw`, `.sql`, `.dmp`
  files, or a `Scheduler Jobs/` directory with `DBMS_SCHEDULER` scripts.
- Application catalog entry (per
  `schemas/discovery/application-catalog-entry.schema.json`) with
  `database` populated and containing `oracle`.
- Discovery-phase artifacts when available:
  `legacy-database-archaeologist.json` (schema hints from Discovery),
  `dependency-mapper.json` (cross-repo database coupling), and the
  `dotnet-extraction-patterns` or equivalent app-tier extract (for the
  DAL → schema resolution pass).
- Client-profile database configuration
  (`profiles/<client>/technology.yaml`) for schema-naming conventions,
  environment-suffix markers (e.g., `_RunOnlyOnTEST`, `_EpoweOnly`), and
  the list of shared cross-app schemas (for FAA: `MSS`).
- Optional: a live Oracle instance with `impdp` privileges when an
  `expdp` dump is the only schema artifact delivered. The skill does not
  require the instance — if absent, it emits a prerequisite finding.

## Outputs
- `oracle-plsql-manifest.json` — one record per package, package body,
  standalone procedure, function, and trigger. Fields: `schema`,
  `object_name`, `object_type` (`package-spec` | `package-body` |
  `procedure` | `function` | `trigger`), `file_path`, `line_start`,
  `line_end`, `authid` (`DEFINER` | `CURRENT_USER`),
  `serially_reusable` (bool), `pipelined` (bool), `public_signatures[]`
  (for package specs / bodies paired with specs), `dependencies[]`
  (other `SCHEMA.OBJECT` names referenced via `CALL`, package dot
  notation, or DML), `dml_signatures[]` (`{table, ops[]}`),
  `exception_blocks[]` (`{line, handler_kind}`).
- `oracle-schema-manifest.json` — tables, columns, data types,
  constraints (`PK`, `FK`, `UK`, `CHECK`, `NOT NULL`), indexes
  (`UNIQUE`, `BITMAP`, `FUNCTION-BASED`), sequences, synonyms, views,
  materialized views (with refresh group and mode), and the DDL source
  location for each. When only an `expdp` dump is delivered, emits an
  empty objects array and a single prerequisite finding keyed
  `ORA-SCHEMA-IMPDP-REQUIRED`.
- `oracle-migration-timeline.json` — ticket-keyed migration scripts in
  chronological order. Fields: `ticket_id` (parsed from filename prefix,
  e.g., `AMCS-1141`), `title` (slug after the ticket id), `owner_system`
  (the owning app prefix, e.g., `AMCS`, `DIWS`, `CPDSS`, `USAS`), `path`,
  `line_count`, `environment_markers[]` (parsed from filename suffixes),
  `cross_system` (true when owner prefix differs from the repo name).
- `oracle-scheduler-inventory.json` — one record per
  `DBMS_SCHEDULER.CREATE_JOB`, `CREATE_PROGRAM`, `CREATE_CHAIN`, or
  `CREATE_SCHEDULE` call. Fields: `job_name`, `owner_schema`,
  `schedule_expression` (Oracle calendaring syntax or named schedule
  reference), `program_action`, `job_class`, `enabled` (bool),
  `external_trigger` (`control-m` | `cron` | `self-scheduled` | `none`),
  `file_path`, `line_start`.
- `oracle-grants-manifest.json` — every `GRANT` and `REVOKE` statement,
  with `principal`, `object_owner`, `object_name`, `privileges[]`,
  `with_grant_option` (bool), and source citation.
- `oracle-dialect-findings.json` — Oracle-specific constructs that block
  portable rewrites: `CONNECT BY`, `ROWNUM`, `DECODE`, `NVL`/`NVL2`,
  hierarchical pseudo-columns (`LEVEL`, `PRIOR`, `CONNECT_BY_ROOT`),
  optimizer hints (`/*+ ... */`), `MERGE`, `DBMS_OUTPUT.PUT_LINE`, and
  packages calling external Java stored procedures
  (`LANGUAGE JAVA NAME ...`). Each finding cites `{repo}:{file}:{line}`.
- Finding records carry the canonical citation form
  `{artifact}:{section}:{finding-id}` (e.g.,
  `oracle-plsql-manifest.json:packages:F-012`) plus a source citation
  `{repo}:{file}:{line}`. Findings without citations are dropped by the
  validator.

## Methodology
1. **Enumerate Oracle source files.** Walk the repository for
   `*.pkb`, `*.pks`, `*.pls`, `*.prc`, `*.fnc`, `*.trg`, `*.vw`,
   `*.sql`, `*.dmp`, and any path under `Scheduler Jobs/`. Record
   absolute path and extension. Exclude `.docx`, `.pdf`, and binary
   files other than `.dmp`. Exclude any file whose name matches
   `LIST_OF_PROCS*.sql` or `*_INVENTORY.sql` — these are documentation,
   not source.
2. **Pair package specs and bodies.** Group every `.pks` and `.pkb`
   file by `(schema, package_name)` where `schema` is parsed from the
   leading `CREATE OR REPLACE PACKAGE [BODY] <schema>.<name>` statement
   or, if no schema is present, inherited from the containing folder
   convention or `profiles/<client>/technology.yaml`. Emit a missing-
   body finding for every `.pks` without a matching `.pkb`, and a
   missing-spec finding for every `.pkb` without a matching `.pks`.
   Block Design from consuming the package until the pair is complete.
3. **Parse PL/SQL objects.** Use a token-level parser that tracks
   nested `BEGIN`/`END` pairs; never key off `END;` alone, since nested
   blocks produce false closures. For each object, extract name,
   schema, `AUTHID` clause, `PRAGMA SERIALLY_REUSABLE`, pipelined
   function markers, public signatures (for specs), parameter modes
   (`IN`/`OUT`/`IN OUT`), exception blocks (including `WHEN OTHERS`),
   and embedded DML. Record line spans.
4. **Resolve dependencies.** For every parsed body, record references
   to other objects: fully-qualified `SCHEMA.PACKAGE.PROCEDURE` calls,
   `INSERT`/`UPDATE`/`DELETE`/`MERGE`/`SELECT` table and view targets,
   type references, sequence `NEXTVAL`/`CURRVAL` usage, and
   `DBMS_SCHEDULER` job creation. Build the CALL graph keyed by
   `(schema, object_name)`; same package name in two schemas is two
   distinct vertices.
5. **Parse schema DDL.** Walk every `.sql` migration script and
   accumulate `CREATE TABLE`, `ALTER TABLE`, `CREATE INDEX`, `CREATE
   SEQUENCE`, `CREATE VIEW`, `CREATE MATERIALIZED VIEW`, `CREATE
   SYNONYM`, and `CREATE TYPE` statements. Apply them in migration-
   timeline order (Methodology step 7). The authoritative definition
   of a table is the latest `ALTER TABLE`-applied shape, not the first
   `CREATE TABLE`.
6. **Handle `expdp` dumps.** If the only schema artifact is a `.dmp`
   file, emit `ORA-SCHEMA-IMPDP-REQUIRED` with the dump path, size, and
   a prerequisite block: `impdp` round-trip against a target Oracle
   instance is required to extract DDL. Do not attempt to parse the
   binary. If both `.dmp` and `.sql` DDL are present, parse the `.sql`
   and record the dump as a reconciliation source for the design step.
7. **Reconstruct migration timeline.** Parse ticket-keyed filenames
   (e.g., `AMCS-1141_AddColumnXYZ.sql`). Extract the ticket prefix as
   `owner_system`, the numeric suffix as sort key, and any trailing
   `_RunOnlyOn*`, `_EpoweOnly`, `_TEST` markers as
   `environment_markers[]`. Sort chronologically within each owner.
   When a repo contains migrations owned by a neighbouring system
   (e.g., `AMCS/db/DIWS-1024_*.sql`), flag `cross_system: true` and
   preserve the ordering across all contributing repos — do not
   reassign ownership.
8. **Inventory scheduler jobs.** Parse every
   `DBMS_SCHEDULER.CREATE_JOB`, `CREATE_PROGRAM`, `CREATE_CHAIN`, and
   `CREATE_SCHEDULE` call under `Scheduler Jobs/` or anywhere in
   migration scripts. Record job class, schedule expression, program
   action, enabled state, and external-trigger kind. Legacy `DBMS_JOB`
   calls are recorded with `job_class: "legacy-dbms-job"` and flagged
   in dialect findings.
9. **Inventory grants.** Record every `GRANT` / `REVOKE` statement
   with principal, object, privileges, and `WITH GRANT OPTION` flag.
   Include system privileges (`GRANT CREATE SESSION`) and object
   privileges separately.
10. **Emit dialect findings.** Scan PL/SQL bodies and SQL migrations
    for constructs that block portable rewrites. Record one finding per
    construct type per file, with line-level citations. This feeds the
    `portability-gap-analyzer` in Design.
11. **Validate and hand off.** Validate every emitted manifest against
    its schema under `schemas/modernization/`. Write all six manifests
    to the Modernization working set. Update the application catalog
    entry's `database_extract_complete` flag.

## Tech-Stack Dispatch

| Trigger | Key patterns |
|---|---|
| `.pkb` / `.pks` pair present | `CREATE OR REPLACE PACKAGE BODY`, `AUTHID`, `PRAGMA SERIALLY_REUSABLE`, public signatures in spec vs. body match |
| `.pls` / `.prc` / `.fnc` standalone files | Single `CREATE OR REPLACE PROCEDURE` or `FUNCTION`, no package wrapper, loaded via `SQL*Plus` in legacy deploy scripts |
| Ticket-keyed `*.sql` migrations | Filename prefix matches `^[A-Z]+-\d+`, owner system is prefix, migrations apply in timestamp/ticket order |
| `Scheduler Jobs/` directory | `DBMS_SCHEDULER.CREATE_JOB`, `CREATE_PROGRAM`, `CREATE_CHAIN`; legacy `DBMS_JOB.SUBMIT` |
| `.dmp` file >= 1 MB | Binary `expdp` dump, `impdp` round-trip required, do not parse |
| Cross-system migrations (`AMCS/db/DIWS-*.sql`) | Owner prefix differs from repo name, co-ownership signal, preserve original ordering |

Detection is mechanical: one signal fires the matching reference. Package
specs and bodies must both be resolved before Design can consume the
package; standalone PL/SQL files are treated as implicit single-object
packages for the purposes of the manifest.

## Gotchas
- **A `.pkb` without its `.pks` does not compile in Oracle.** Emit a
  missing-spec finding and block Design from loading the package. Do
  not synthesize a spec from the body — the public surface is
  authoritative and must come from the spec.
- **A `.pks` without a `.pkb` is a declared interface with no
  implementation.** Flag as missing-body and block Design. The spec
  alone does not describe behaviour.
- **Package name collisions across schemas are real.** `AMCS.PKG_COMMON`
  and `DIWS.PKG_COMMON` are different objects. Key every manifest entry
  by `(schema, object_name)`, never by `object_name` alone. Folding
  them collapses two bodies into one and corrupts the CALL graph.
- **`END;` is not a reliable closure marker.** PL/SQL blocks nest
  arbitrarily; naive line-based parsers that split on `END;` lose track
  inside nested `BEGIN`/`END` blocks, labelled loops, and anonymous
  blocks inside procedures. Use a token-level parser that counts
  `BEGIN` and `END` pairs with awareness of strings, comments, and
  `END IF`/`END LOOP`/`END CASE` terminators that do not close a block.
- **Environment gating lives in filenames, not schema metadata.**
  `DHS_Auto_Insert_Query_EpoweOnly.sql`, `*_RunOnlyOnLowerEnvironment.sql`,
  and `*_RunOnlyOnTEST.sql` are gated by filename suffix convention; the
  SQL inside is valid everywhere. The skill must parse the suffix into
  `environment_markers[]` and preserve the original spelling —
  `Epowe` is not a typo to normalize, it is the literal environment
  code used by the AMCS team.
- **Cross-system migrations are a governance signal, not a bug.** When
  `AMCS/db/` contains `DIWS-*.sql`, the migration was authored by DIWS
  and applied via the AMCS deploy pipeline because both systems touch
  the shared `MSS` schema. Preserve the owner prefix, flag
  `cross_system: true`, and surface a finding that governance
  ownership crosses repos. Do not reassign to AMCS.
- **`expdp` dumps cannot be parsed.** The `.dmp` file is an Oracle-
  proprietary binary that requires `impdp` against a target instance to
  yield DDL. Emit a prerequisite finding with the dump path and size;
  never pretend to extract schema from a dump.
- **Stored-proc inventory files are documentation, not source.** A file
  named `LIST_OF_PROCS.sql` typically contains `SELECT object_name FROM
  user_objects WHERE object_type = 'PROCEDURE';` — a report generator,
  not a proc definition. Exclude by filename pattern; do not let its
  `SELECT` statements populate the PL/SQL manifest.
- **The `PKG_` prefix is convention, not required.** Packages without
  the prefix exist (`ACCOUNTS`, `MASTER_EDIT`). Filtering on `PKG_`
  drops legitimate objects. Detect packages by the `CREATE OR REPLACE
  PACKAGE` keyword, not the name prefix.
- **`EXCEPTION WHEN OTHERS THEN NULL` silently swallows errors.**
  Record every exception block, and surface `WHEN OTHERS` handlers with
  no re-raise (`RAISE;`, `RAISE_APPLICATION_ERROR`) as high-severity
  findings — they hide bugs from operators.
- **Embedded SQL inside Word templates is not source.** CPDSS delivers
  `.docx` files with illustrative SQL in the body. Exclude Word, PDF,
  and other binaries from the walk. The `.docx` text is not a
  migration script and must not appear in the timeline.
- **Control-M triggers Oracle jobs externally.** When a
  `DBMS_SCHEDULER.CREATE_JOB` call has a program action that only
  exists to be invoked by Control-M (no internal schedule), set
  `external_trigger: "control-m"` and emit a finding that the
  orchestration contract lives outside the Oracle tier. Design needs
  to know the scheduler is not self-contained.

## Quality Rules
- [ ] Every `.pkb` has a matching `.pks` or a missing-spec finding;
      every `.pks` has a matching `.pkb` or a missing-body finding.
- [ ] Every PL/SQL object record is keyed by `(schema, object_name)`
      and cites `file_path`, `line_start`, `line_end`.
- [ ] Every entry in `oracle-plsql-manifest.json` has at least one
      `{repo}:{file}:{line}` citation for its declaration site.
- [ ] The CALL graph contains no dangling edges — every referenced
      `(schema, object_name)` either resolves to a manifest entry or is
      flagged `external: true`.
- [ ] Every `oracle-migration-timeline.json` entry has a parsed
      `ticket_id`, `owner_system`, and position within the owner's
      ordered sequence; cross-system entries set `cross_system: true`.
- [ ] Environment markers are preserved verbatim; no normalization of
      `Epowe`, `TEST`, `LowerEnvironment` casing or spelling.
- [ ] `expdp` dumps yield an `ORA-SCHEMA-IMPDP-REQUIRED` finding when
      they are the only schema artifact; the skill never emits fabricated
      DDL from a dump.
- [ ] Every `DBMS_SCHEDULER` job records `external_trigger` explicitly;
      legacy `DBMS_JOB` submissions are flagged in dialect findings.
- [ ] Every `GRANT`/`REVOKE` records principal, object, privileges, and
      `WITH GRANT OPTION`; values are not redacted but principals that
      are roles vs. users are tagged.
- [ ] `oracle-dialect-findings.json` has one entry per Oracle-specific
      construct type per file, each with a `{repo}:{file}:{line}`
      citation.
- [ ] All six manifests validate against their schemas with no
      `additionalProperties` violations.

## Common Failure Modes
| Failure Mode | Symptom | Prevention |
|---|---|---|
| Naive line-based PL/SQL parsing | Objects truncated at the first nested `END;`; DML in nested blocks missed | Use a token-level parser that tracks nested `BEGIN`/`END` with awareness of `END IF`/`END LOOP`/`END CASE` non-closers |
| Package name collision across schemas collapsed | Two distinct packages reported as one; CALL graph edges point to the wrong body | Key every manifest entry by `(schema, object_name)`; never deduplicate by name alone |
| `PKG_` prefix filter applied | Packages without the prefix dropped; public surface incomplete | Detect by `CREATE OR REPLACE PACKAGE` keyword; prefix is a convention, not a requirement |
| `LIST_OF_PROCS.sql` extracted as procs | Manifest pollutes with report `SELECT`s that mimic proc listings | Exclude filenames matching the inventory-file patterns before parsing |
| Cross-system migrations reassigned to containing repo | Governance ownership lost; AMCS appears to own DIWS migrations | Parse ticket prefix as `owner_system`; set `cross_system: true` when prefix differs from repo name; never rewrite |
| `expdp` dump mistaken for parseable DDL | Skill hangs, corrupts binary, or emits empty schema | Detect `.dmp` extension; emit `ORA-SCHEMA-IMPDP-REQUIRED`; never attempt to parse binary |
| `.docx` SQL extracted as migration | Word-template prose enters the timeline; ordering corrupted | Restrict timeline walk to `.sql` extensions; exclude all Office and PDF files |
| Environment-marker suffixes stripped | `_EpoweOnly` / `_RunOnlyOnTEST` filenames normalized into generic migrations; environment gating lost | Preserve original suffix; parse into `environment_markers[]`; never rename |
| `WHEN OTHERS THEN NULL` not surfaced | Silent error-swallowing handlers ship unnoticed; operators debug blind | Detect `WHEN OTHERS` without `RAISE;` / `RAISE_APPLICATION_ERROR`; emit a high-severity finding |

## Handoff Summary
When this skill completes, verify:
1. All six manifests exist next to the application catalog entry and
   validate against their schemas with zero errors.
2. Every PL/SQL object is keyed by `(schema, object_name)` and has a
   line-scoped citation; package specs and bodies are paired, with
   missing-half findings for any unpaired file.
3. The migration timeline is ordered per owner system; cross-system
   migrations are flagged and their ordering preserved across
   contributing repos.
4. `expdp` dumps have a prerequisite finding when they are the sole
   schema source; no fabricated DDL has been emitted.
5. Dialect findings enumerate Oracle-specific constructs with file:line
   citations, ready for the portability-gap analyzer.

Then proceed to: `legacy-database-archaeologist` (reconciles this
extract with its Discovery-phase ADABAS/Oracle inventory),
`portability-gap-analyzer` (consumes `oracle-dialect-findings.json`
and emits per-construct rewrite guidance), and the Design step which
produces the target data model from `oracle-schema-manifest.json` and
`oracle-plsql-manifest.json`. The next gate is **G-DE-1** (Extract
Completeness) where all six manifests must be accepted before Design
begins.

## References
- `references/plsql-package-extraction.md` — walking the `.pkb`/`.pks`
  family, pairing specs with bodies, extracting public signatures,
  resolving the CALL graph, handling `AUTHID` modes, serially-reusable
  pragmas, pipelined functions, records, collections, and external Java
  stored procedures.
- `references/oracle-schema-extraction.md` — parsing `CREATE TABLE` /
  `ALTER TABLE` sequences across migration history, constraint
  ordering, index coverage, materialized view refresh groups, sequences
  and triggers for surrogate keys, synonyms, and reconciling `expdp`
  round-trip output with source DDL.
- `references/oracle-scheduler-and-jobs.md` —
  `DBMS_SCHEDULER.CREATE_JOB`, `CREATE_PROGRAM`, `CREATE_CHAIN`,
  `CREATE_SCHEDULE`, job-class semantics, legacy `DBMS_JOB`
  compatibility, and Control-M vs. Oracle Scheduler orchestration
  contracts.
- `schemas/modernization/oracle-plsql-manifest.schema.json` — canonical
  shape of the PL/SQL manifest.
- `schemas/modernization/oracle-schema-manifest.schema.json` —
  canonical shape of the schema manifest.
- `schemas/modernization/oracle-migration-timeline.schema.json` —
  canonical shape of the migration timeline.

## Changelog
- 0.1.0 (2026-05-06) — Initial skill scaffolded for the Modernization
  Extract step. Covers PL/SQL package spec/body pairing, standalone
  procedure and function extraction, trigger inventory, ticket-keyed
  migration timeline reconstruction with cross-system ownership
  preservation, `DBMS_SCHEDULER` inventory with Control-M external-
  trigger detection, grants manifest, and Oracle dialect findings
  covering `CONNECT BY`, `ROWNUM`, `DECODE`, `NVL`, optimizer hints,
  `MERGE`, `DBMS_OUTPUT`, and Java stored procedures. Full enrichment
  level; feeds `portability-gap-analyzer`, `legacy-database-
  archaeologist`, and the Design step downstream.
