# PL/SQL Package Extraction

This reference describes how to walk an Oracle PL/SQL source tree —
package bodies (`.pkb`), package specs (`.pks`), standalone procedures
(`.prc`), functions (`.fnc`), scripts (`.pls`), and triggers
(`.trg`) — and produce the entries for `oracle-plsql-manifest.json`.
Every claim made about a package, procedure, function, or trigger must
cite `{repo}:{file}:{line}`; claims without citations are dropped by the
manifest validator.

## File Families and What They Hold

- `.pks` — **package specification**. Contains only declarations:
  `PROCEDURE`, `FUNCTION`, `TYPE`, `CURSOR`, `EXCEPTION`, constants, and
  public variables. No executable bodies. The spec is the public
  surface; anything not in the spec cannot be called from outside the
  package.
- `.pkb` — **package body**. Contains the implementations of every
  spec-declared subprogram plus any private subprograms not declared in
  the spec. A `.pkb` without its matching `.pks` does not compile.
- `.pls` — **standalone PL/SQL script**. Often contains a `CREATE OR
  REPLACE PROCEDURE` or `CREATE OR REPLACE FUNCTION`, occasionally an
  anonymous block. Treat as an implicit single-object package for
  manifest purposes.
- `.prc` — **standalone procedure**. One `CREATE OR REPLACE PROCEDURE`
  statement, no package wrapper.
- `.fnc` — **standalone function**. One `CREATE OR REPLACE FUNCTION`
  statement, no package wrapper.
- `.trg` — **trigger**. One `CREATE OR REPLACE TRIGGER` statement,
  bound to a table or view, with a `BEFORE`/`AFTER`/`INSTEAD OF` event
  and a DML or DDL trigger body.

A `.sql` file may also contain any of the above. Do not assume
extension dictates object kind; always confirm by reading the leading
`CREATE OR REPLACE` statement.

## Spec-to-Body Pairing

Group every `.pks` and `.pkb` by `(schema, package_name)`. The schema
is parsed from the leading statement:

    CREATE OR REPLACE PACKAGE BODY MSS.PKG_MX_ADE_ACCOUNTS AS

where `MSS` is the schema and `PKG_MX_ADE_ACCOUNTS` is the package name.
When no schema qualifier is present, inherit from the client-profile
`default_schema` in `profiles/<client>/technology.yaml`. For the FAA
profile this is `MSS` when the file lives under a MedXPress, AMCS,
DIWS, or CPDSS repo.

Emit one of three outcomes per pair:

- **Paired** — both `.pks` and `.pkb` present. Extract public
  signatures from the spec and match them against implementations in
  the body. Every public signature must appear in the body; any
  mismatch is a finding (`ORA-PLSQL-SIGNATURE-MISMATCH`).
- **Body without spec** — `.pkb` exists, no `.pks`. This is a compile
  error in Oracle. Emit `ORA-PLSQL-MISSING-SPEC` (severity: high) with
  the body path. Do not synthesize a spec from the body.
- **Spec without body** — `.pks` exists, no `.pkb`. This is a declared
  interface with no implementation. Emit `ORA-PLSQL-MISSING-BODY`
  (severity: high) with the spec path. Block Design from emitting the
  package until the body is located.

## Token-Level Parsing

Naive line-based parsing fails on PL/SQL. Nested `BEGIN`/`END` blocks,
labelled loops, `END IF` / `END LOOP` / `END CASE` non-closers, strings
containing `END;`, and comments that mention `END;` all fool a grep-
based walker. Use a token-level parser with the following rules:

1. Tokenize respecting PL/SQL lexical rules: single-quoted strings,
   `q'[...]'` quoted literals, `--` line comments, `/* ... */` block
   comments, identifiers (quoted and unquoted), reserved words,
   numeric literals.
2. Track a `BEGIN` / `END` depth counter. Increment on `BEGIN`,
   decrement on `END` that is **not** followed by `IF`, `LOOP`,
   `CASE`, or a label name that matches the opening.
3. A subprogram's body runs from its `IS`/`AS` keyword through the
   matching `END <name>;` where depth returns to zero.
4. Anonymous blocks (`DECLARE ... BEGIN ... END;` at the top of a
   script) are recorded as `object_type: "anonymous-block"` with no
   name.

Record `line_start` at the `CREATE OR REPLACE` statement, `line_end`
at the terminating `/` or `END <name>;` — whichever comes last in
source.

## Public Signatures

From the spec, extract every `PROCEDURE` and `FUNCTION` declaration.
A signature is `(name, parameters[], return_type?)` where each
parameter has `(name, mode, type, default?)`. Parameter modes are
`IN`, `OUT`, or `IN OUT` — default is `IN` when unspecified. Function
signatures include `return_type`; procedure signatures do not.

Overloading is legal in PL/SQL: two procedures with the same name but
different parameter lists are distinct signatures. Record all
overloads; the manifest key for overloaded subprograms is
`(schema, package_name, procedure_name, parameter_type_list)`.

## AUTHID and Pragma Handling

The spec may declare one of:

- `AUTHID DEFINER` (default) — the package runs with the privileges of
  its owner. Any object it touches resolves against the owner's schema.
- `AUTHID CURRENT_USER` — invoker's rights. Object resolution happens
  in the caller's schema at runtime.

Record the `authid` field on every package-spec manifest entry. When
the spec omits the clause, emit `authid: "DEFINER"` explicitly; do not
leave null.

Package-level pragmas that must be captured:

- `PRAGMA SERIALLY_REUSABLE;` — the package's state is reset between
  calls from the same session. Rewrites that assume persistent session
  state will break.
- `PRAGMA AUTONOMOUS_TRANSACTION;` (procedure-level) — the subprogram
  runs in its own transaction. Flag as a finding because rewrites
  often collapse the transaction boundary.
- `PRAGMA RESTRICT_REFERENCES(...)` — legacy purity declaration, rare
  in modern code but still present in 10g-era packages.

## Pipelined Functions and Collections

Pipelined functions are declared with `PIPELINED` after the return
type:

    FUNCTION get_rows RETURN my_tab PIPELINED IS ...

Flag `pipelined: true`. Pipelined functions return a collection type
row-by-row via `PIPE ROW(...)`; rewrites to languages without
generator semantics (Java, C#) require buffered-collection emulation.
The manifest should record the collection type name and element type.

Collection types — `TABLE OF`, `VARRAY(n) OF`, nested tables — are
first-class. Record the element type and, when present, the backing
SQL type name.

Record types (`TYPE rec IS RECORD(...)`) are per-package or
package-level. Record their field list under the owning package's
`types[]` entry.

## Exception Blocks

Every `EXCEPTION WHEN <condition> THEN ... END;` block is recorded
with `{line, handler_kind}` where `handler_kind` is one of:

- `named` — handles a named exception (`NO_DATA_FOUND`, `DUP_VAL_ON_INDEX`,
  custom declared exceptions).
- `others` — `WHEN OTHERS THEN ...`.
- `user-defined` — `RAISE_APPLICATION_ERROR(-20xxx, ...)` path.

A `WHEN OTHERS` block that does not end with `RAISE;` or
`RAISE_APPLICATION_ERROR` silently swallows errors. Emit
`ORA-PLSQL-SILENT-WHEN-OTHERS` (severity: high) for each occurrence;
these are latent bugs that hide failures from operators.

## DML Signature Extraction

For every subprogram body, record the DML it issues:

- `INSERT INTO <schema.table> (...) VALUES (...)` — record target
  table and column list.
- `UPDATE <schema.table> SET ... WHERE ...` — record target and
  columns updated.
- `DELETE FROM <schema.table> WHERE ...` — record target.
- `MERGE INTO <schema.target> USING <schema.source> ...` — record
  both sides; `MERGE` is also recorded in dialect findings.
- `SELECT ... FROM <schema.table/view>` — record the tables and views
  read. Subqueries in `WHERE` clauses count.

Dynamic SQL (`EXECUTE IMMEDIATE '...'`, `DBMS_SQL`) cannot be
resolved statically. Record the presence of dynamic SQL as a
`dml_signatures[].dynamic: true` flag and cite the site; Design
cannot infer the target.

## Dependency Resolution

Build the CALL graph by scanning each body for:

- `SCHEMA.PACKAGE.PROCEDURE(...)` — fully qualified cross-package
  call. Resolve to `(schema, package, procedure)`.
- `PACKAGE.PROCEDURE(...)` — schema-implicit call; resolve using
  `AUTHID` and the containing package's schema.
- Bare `PROCEDURE(...)` — local call to another subprogram in the
  same package, or a synonym. Resolve against the package's own
  subprogram list first, then public synonyms.
- `DBMS_*`, `UTL_*`, `SYS.*` — Oracle built-in packages. Mark as
  `external: true` with `external_kind: "oracle-builtin"`.
- `DBMS_JOB.SUBMIT(...)` or `DBMS_SCHEDULER.CREATE_JOB(...)` —
  scheduler dependency; cross-reference
  `oracle-scheduler-inventory.json`.

Dangling edges — references to `SCHEMA.PACKAGE.PROCEDURE` that do
not resolve to any manifest entry — are recorded with
`external: true` and `resolution: "unresolved"`, and produce
`ORA-PLSQL-UNRESOLVED-CALL` findings. Do not drop them silently.

## External Java Stored Procedures

Packages occasionally declare:

    PROCEDURE run_job(p_arg VARCHAR2) AS LANGUAGE JAVA
      NAME 'com.example.JobRunner.run(java.lang.String)';

Flag as `implementation: "java"` on the manifest entry and emit a
dialect finding `ORA-PLSQL-EXTERNAL-JAVA` with the Java fully-qualified
method name. The Java class is not parsed by this skill; it is a
handoff signal to the JVM-tier extractor.

## Standalone Procedures, Functions, Triggers

Standalone objects (`.prc`, `.fnc`, `.pls`, `.trg`) are recorded with
`object_type: "procedure"`, `"function"`, or `"trigger"` and no parent
package. Triggers additionally carry:

- `triggering_table` — the table or view the trigger is bound to.
- `event` — `INSERT` / `UPDATE` / `DELETE` / `DDL` / `COMPOUND`.
- `timing` — `BEFORE` / `AFTER` / `INSTEAD OF`.
- `row_level` — `true` for `FOR EACH ROW`, `false` otherwise.
- `when_clause` — the optional `WHEN (condition)` filter.

Cross-reference the trigger's `triggering_table` against
`oracle-schema-manifest.json`; a trigger whose table is not in the
schema manifest indicates missing DDL.

## Citations

Every manifest record carries a `{repo}:{file}:{line}` citation at the
object's `CREATE OR REPLACE` statement. For DML signatures, cite the
line of the `INSERT`/`UPDATE`/`DELETE`/`MERGE` keyword. For exception
blocks, cite the line of the `WHEN` clause. For dependencies, cite the
call site. Findings without citations are invalid.
