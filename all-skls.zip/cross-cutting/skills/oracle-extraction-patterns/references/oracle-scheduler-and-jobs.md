# Oracle Scheduler and Jobs

This reference describes how to populate `oracle-scheduler-inventory.json`
from an Oracle source tree. The skill walks every script under a
`Scheduler Jobs/` directory, every `DBMS_SCHEDULER.*` and `DBMS_JOB.*`
call embedded in migration scripts or package bodies, and every
external trigger hint that indicates a third-party scheduler (Control-M,
cron, Autosys) drives the Oracle job rather than the job self-scheduling
on an Oracle calendaring expression. Every inventory record cites
`{repo}:{file}:{line}` at the creation site.

## The `DBMS_SCHEDULER` Surface

The scheduler API declares four primary object kinds, each via a
dedicated `CREATE_*` procedure:

- **Jobs** (`DBMS_SCHEDULER.CREATE_JOB`) — the runnable unit.
- **Programs** (`DBMS_SCHEDULER.CREATE_PROGRAM`) — reusable action
  definitions that jobs reference.
- **Schedules** (`DBMS_SCHEDULER.CREATE_SCHEDULE`) — reusable
  calendaring expressions.
- **Chains** (`DBMS_SCHEDULER.CREATE_CHAIN`) — DAG of steps with
  rules (`DEFINE_CHAIN_STEP`, `DEFINE_CHAIN_RULE`).

Each kind becomes a distinct record in the inventory with
`object_kind` = `job` | `program` | `schedule` | `chain`. A job may
reference a named program and schedule, or inline both. Record the
reference style per entry (`inline` | `referenced`).

## Parsing `CREATE_JOB`

A representative call:

    BEGIN
      DBMS_SCHEDULER.CREATE_JOB(
        job_name        => 'MSS.REFRESH_MV_SALES',
        job_type        => 'STORED_PROCEDURE',
        job_action      => 'MSS.PKG_MX_REPORT.REFRESH_SALES',
        start_date      => SYSTIMESTAMP,
        repeat_interval => 'FREQ=HOURLY; INTERVAL=4',
        enabled         => TRUE,
        comments        => 'Refresh hourly sales MV'
      );
    END;
    /

Record:

- `job_name` — `MSS.REFRESH_MV_SALES` (split into `owner_schema: "MSS"`
  and `name: "REFRESH_MV_SALES"`).
- `job_type` — one of `PLSQL_BLOCK`, `STORED_PROCEDURE`, `EXECUTABLE`,
  `CHAIN`, `EXTERNAL_SCRIPT`, `BACKUP_SCRIPT`, `SQL_SCRIPT`.
- `job_action` — the body invoked. For `STORED_PROCEDURE`, parse into
  `(schema, package, procedure)` and cross-reference
  `oracle-plsql-manifest.json`.
- `schedule_expression` — the `repeat_interval` calendaring string, or
  the named schedule reference when `schedule_name =>` is used
  instead. Oracle calendaring syntax uses `FREQ=`, `INTERVAL=`,
  `BYHOUR=`, `BYDAY=`, `BYMONTH=`. Store the raw string; do not
  normalize to cron.
- `start_date` — parse as ISO-8601 timestamp when literal; record the
  expression verbatim (`SYSTIMESTAMP`, `TRUNC(SYSDATE)+1/24`) when
  computed.
- `enabled` — boolean, default `FALSE` when omitted from the call.
  Oracle requires an explicit `DBMS_SCHEDULER.ENABLE(job_name)` to
  activate; record whether such a call appears elsewhere in the file
  or in a sibling script.
- `job_class` — from `job_class =>`, or `DEFAULT_JOB_CLASS` when
  omitted. Record the name only; the class definition itself may live
  in a separate script.
- `comments` — verbatim.

When `job_type = 'EXECUTABLE'`, the `job_action` is an OS command, not
a PL/SQL call. Flag `external_trigger: "none"` but set
`runs_external_process: true` and emit a finding so the deployment
step can locate the executable.

## Named Programs and Schedules

`CREATE_PROGRAM` defines a reusable action:

    DBMS_SCHEDULER.CREATE_PROGRAM(
      program_name   => 'MSS.REFRESH_SALES_PROG',
      program_type   => 'STORED_PROCEDURE',
      program_action => 'MSS.PKG_MX_REPORT.REFRESH_SALES',
      number_of_arguments => 0,
      enabled        => TRUE
    );

`CREATE_SCHEDULE` defines a reusable calendaring expression:

    DBMS_SCHEDULER.CREATE_SCHEDULE(
      schedule_name   => 'MSS.HOURLY_4',
      repeat_interval => 'FREQ=HOURLY; INTERVAL=4'
    );

When a `CREATE_JOB` call references these by name (`program_name =>
'MSS.REFRESH_SALES_PROG'`), record both entries and link the job to
them via `program_ref` and `schedule_ref`. The job entry's
`schedule_expression` and `program_action` fields are copied from the
referenced entries at emission time for Design's convenience, but
the source-of-truth citation remains the `CREATE_PROGRAM` /
`CREATE_SCHEDULE` site.

## Chains

A chain is a DAG of steps. Creation requires three calls:

    DBMS_SCHEDULER.CREATE_CHAIN(chain_name => 'MSS.NIGHTLY_CHAIN');
    DBMS_SCHEDULER.DEFINE_CHAIN_STEP(
      chain_name => 'MSS.NIGHTLY_CHAIN',
      step_name  => 'STEP_1',
      program_name => 'MSS.LOAD_STAGING'
    );
    DBMS_SCHEDULER.DEFINE_CHAIN_RULE(
      chain_name => 'MSS.NIGHTLY_CHAIN',
      condition  => 'STEP_1 SUCCEEDED',
      action     => 'START STEP_2'
    );

Record the chain as one inventory entry with `steps[]` and `rules[]`
arrays. Each step references a program by name; cross-reference the
program entries. Rules carry `condition` and `action` verbatim —
Design consumes them to reconstruct the DAG.

## Job Classes

Job classes group jobs for resource allocation:

    DBMS_SCHEDULER.CREATE_JOB_CLASS(
      job_class_name    => 'MSS.REPORTING_JOBS',
      resource_consumer_group => 'LOW_GROUP',
      logging_level     => DBMS_SCHEDULER.LOGGING_FULL,
      log_history       => 30
    );

Record every job class. The `resource_consumer_group` links to the
Oracle Resource Manager — out of scope for this skill, but record the
name for the Rationalization step to flag.

## Legacy `DBMS_JOB` Compatibility

`DBMS_JOB` is the pre-10g scheduler. Many portfolios carry legacy
calls:

    DBMS_JOB.SUBMIT(
      job       => :jobno,
      what      => 'MSS.PKG_MX_REPORT.REFRESH_SALES;',
      next_date => SYSDATE + 1/24,
      interval  => 'SYSDATE + 1/24'
    );

Record with `object_kind: "legacy-job"` and
`job_class: "legacy-dbms-job"`. Emit `ORA-SCHED-LEGACY-DBMS-JOB`
(severity: medium) — `DBMS_JOB` is deprecated and Design should
migrate the job to `DBMS_SCHEDULER` as part of the rewrite. Preserve
the numeric job id when visible (via `SELECT * FROM user_jobs` dumps)
for traceability.

## External Trigger Detection

Not every Oracle job self-schedules. When a `CREATE_JOB` call omits
`repeat_interval` and `schedule_name`, the job runs only when
explicitly invoked via `DBMS_SCHEDULER.RUN_JOB` — typically from an
external scheduler. Detection hints:

- `repeat_interval => NULL` or field omitted entirely, and
  `start_date => NULL` or omitted — job is explicit-run.
- Comments referencing Control-M (`-- Control-M trigger`,
  `-- CTM:job_name`), Autosys (`-- autosys:...`), or cron.
- A sibling `.ctm` / `.job` / `.jil` file in the same directory —
  signals a third-party scheduler definition.
- Deployment scripts that export `CTRLM_*` environment variables.

Set `external_trigger`:

- `"control-m"` — Control-M orchestrates the run.
- `"autosys"` — Autosys orchestrates.
- `"cron"` — OS cron invokes via a `sqlplus` wrapper.
- `"self-scheduled"` — Oracle Scheduler itself schedules the job
  (default when `repeat_interval` or `schedule_name` is present).
- `"none"` — no schedule, no evidence of external trigger; the job
  is dead code unless invoked manually. Emit
  `ORA-SCHED-NO-TRIGGER` (severity: medium).

When `external_trigger` is `"control-m"` or `"autosys"`, emit
`ORA-SCHED-EXTERNAL-CONTRACT` — the orchestration contract lives
outside the Oracle tier, so Design must coordinate with the
enterprise-scheduler team during the rewrite. Record any referenced
scheduler artifact path in `external_trigger_ref`.

## Refresh Groups

`DBMS_REFRESH.MAKE(...)` creates a refresh group for materialized
views:

    DBMS_REFRESH.MAKE(
      name           => 'MSS.NIGHTLY_MV_GROUP',
      list           => 'MSS.MV_SALES, MSS.MV_ACCOUNTS',
      next_date      => TRUNC(SYSDATE)+1,
      interval       => 'TRUNC(SYSDATE)+1'
    );

Record as `object_kind: "refresh-group"` with `members[]` resolved
against `oracle-schema-manifest.json`. Cross-reference from each
materialized view entry.

## Job State vs. Definition

The scheduler distinguishes definition (DDL) from runtime state
(whether a job is enabled, currently running, last error). This
skill extracts only the definition. Runtime state lives in
`DBA_SCHEDULER_JOBS` and `DBA_SCHEDULER_JOB_RUN_DETAILS` views;
those are not consumed here. If a state-export file
(`sched_state.csv`) is delivered, record its path in the inventory
header as `runtime_state_source` but do not parse — that is the
runtime-reconstruction skill's job.

## Enablement Tracking

A `CREATE_JOB` call with `enabled => FALSE` (or omitted) means the
job is defined but not running. Oracle requires an explicit
`DBMS_SCHEDULER.ENABLE('MSS.REFRESH_MV_SALES')` call to activate. The
skill must:

1. Record `enabled_at_creation: false` when the flag is not `TRUE`.
2. Scan all files for `DBMS_SCHEDULER.ENABLE` calls referencing the
   job, and record them in `enable_sites[]`.
3. If no enable site is found, set `effective_state: "disabled"` and
   emit `ORA-SCHED-DISABLED-JOB` — the job is dead weight unless
   enabled externally.

## Citations

Every inventory record carries a `{repo}:{file}:{line}` citation at
the `CREATE_*` call's opening line. Chain rules and steps carry
separate citations at their `DEFINE_CHAIN_STEP` /
`DEFINE_CHAIN_RULE` sites. Enable sites are listed with individual
citations. Findings without citations are dropped by the validator.
