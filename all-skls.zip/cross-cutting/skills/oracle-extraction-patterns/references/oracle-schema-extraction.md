# Oracle Schema Extraction

This reference describes how to reconstruct `oracle-schema-manifest.json`
from the source DDL delivered with a legacy Oracle application. The
skill walks every `.sql` migration script, every inline DDL in
`.pks`/`.pkb` files, and any schema-export artifacts (`expdp` dumps,
metadata-only `.sql` unloads), applies `ALTER TABLE` history in
migration-timeline order, and emits the authoritative final shape of
every table, view, materialized view, index, sequence, synonym, and
type. Every entry cites `{repo}:{file}:{line}` at the DDL statement
that last mutated the object.

## Object Types and What They Require

- **Tables** — `CREATE TABLE <schema.name> (...)`. Fields:
  `schema`, `table_name`, `columns[]`, `constraints[]`, `partitioning`,
  `tablespace`, `organization` (`HEAP` | `INDEX-ORGANIZED` |
  `EXTERNAL`), `temporary` (bool), `compression`.
- **Columns** — `{name, data_type, precision, scale, nullable,
  default_expression, identity_kind}`. Oracle types that must be
  preserved verbatim: `VARCHAR2(n CHAR|BYTE)`, `NVARCHAR2`, `CLOB`,
  `NCLOB`, `BLOB`, `NUMBER(p, s)`, `DATE`, `TIMESTAMP(n) WITH [LOCAL]
  TIME ZONE`, `INTERVAL YEAR TO MONTH`, `INTERVAL DAY TO SECOND`,
  `RAW(n)`, `XMLTYPE`, and user-defined object types. Do not
  normalize `VARCHAR2` to `VARCHAR`.
- **Constraints** — `{kind, name, columns[], reference?, check_expression?,
  deferrable, initially_deferred, enable, validate, rely}`. Kinds are
  `PK`, `FK`, `UK`, `CHECK`, `NOT NULL`. `FK` references carry
  `{schema, table, columns[]}` and `on_delete` (`CASCADE` | `SET NULL`
  | `NO ACTION`).
- **Indexes** — `{name, schema, table, columns[], kind, unique,
  tablespace, partitioning}`. Kinds are `BTREE`, `BITMAP`,
  `FUNCTION-BASED`, `REVERSE`, `DOMAIN`. Function-based indexes store
  the expression, not the column name alone.
- **Sequences** — `{schema, name, start_with, increment_by, min_value,
  max_value, cache, cycle, order}`.
- **Synonyms** — `{schema, name, target_schema, target_name,
  public}`. `PUBLIC SYNONYM` has `public: true` and no owning schema.
- **Views** — `{schema, name, columns[], definition, editioning,
  with_read_only, with_check_option}`. The SQL body of the view is
  stored verbatim for Design to re-parse.
- **Materialized Views** — `{schema, name, refresh_mode, refresh_method,
  refresh_group, build_mode, query_rewrite_enabled, refresh_on,
  next_expression}`. Refresh mode is `ON DEMAND` | `ON COMMIT` |
  `ON STATEMENT`; method is `COMPLETE` | `FAST` | `FORCE`. Record
  materialized view logs (`CREATE MATERIALIZED VIEW LOG ON <table>`)
  as a separate entry.
- **Types** — `CREATE OR REPLACE TYPE <schema.name> AS OBJECT(...)` or
  `AS TABLE OF ...`. Record attribute list and, for collection types,
  the element type.

## Walking Migration Scripts

The authoritative shape of a table is the cumulative result of its
`CREATE TABLE` plus every `ALTER TABLE` that follows. To reconstruct:

1. Order migrations per `oracle-migration-timeline.json` (ticket-keyed,
   owner-scoped, chronological within each owner). Cross-system
   migrations retain their original order relative to the owner's
   sequence.
2. Initialize an empty schema state per `(schema, object_name)`.
3. For each migration in order, apply the statements against the state:
   - `CREATE TABLE` — instantiate the entry.
   - `ALTER TABLE ADD (col...)` — append columns.
   - `ALTER TABLE MODIFY (col ...)` — mutate column type/default/
     nullable. Preserve prior type in a history array if auditing is
     required.
   - `ALTER TABLE DROP COLUMN` — remove from the entry.
   - `ALTER TABLE ADD CONSTRAINT` / `DROP CONSTRAINT` — mutate
     `constraints[]`.
   - `ALTER TABLE RENAME COLUMN` / `RENAME TO` — rename and update all
     references (indexes, FKs from other tables).
   - `DROP TABLE` — remove entry; record tombstone with `dropped_in:
     <migration>` for provenance.
4. When all migrations have been applied, emit the final state.

Record the citation at the **last** DDL that mutated the object. Do
not concatenate citations from every migration; the manifest entry
represents the final shape.

## Constraint Ordering and Naming

Constraints may be named (`CONSTRAINT pk_emp PRIMARY KEY (emp_id)`) or
system-generated (`PRIMARY KEY (emp_id)` — Oracle assigns a
`SYS_C<nnnnn>` name). Record both kinds; for system-generated names,
set `system_generated: true`. Do not synthesize a name.

Primary keys in Oracle automatically create a unique index unless
`USING INDEX` references an existing one. Record the backing index
name in the constraint entry when explicit.

Foreign keys may be declared in-line (`... REFERENCES emp(emp_id)`) or
out-of-line (`CONSTRAINT fk_... FOREIGN KEY (...) REFERENCES ...`).
Both produce identical manifest entries.

`CHECK` constraints store the check expression verbatim; Design
consumes it directly because rewrite logic depends on the exact
expression.

`NOT NULL` is modeled as a `CHECK` constraint internally by Oracle
but must be recorded as `kind: "NOT_NULL"` on the column, not as a
separate constraint row. This preserves column-level semantics for
Design.

## Indexes and Coverage

Every `CREATE INDEX` statement produces an index entry. A `UNIQUE`
index that backs a `PK` or `UK` constraint is recorded once, with a
cross-reference to the constraint.

Function-based indexes:

    CREATE INDEX idx_upper_name ON emp (UPPER(last_name));

Record `kind: "FUNCTION-BASED"` and store the expression
(`UPPER(last_name)`) in `columns[0].expression`.

Bitmap indexes (`CREATE BITMAP INDEX ...`) and reverse-key indexes
(`CREATE INDEX ... REVERSE`) are Oracle-specific. Record in the
schema manifest, and emit a dialect finding for each so the
portability analyzer flags them.

## Sequences and Surrogate Keys

Sequences are recorded standalone. When a sequence is consumed by a
trigger to populate a surrogate key, record the linkage in the
trigger's `oracle-plsql-manifest.json` entry as a dependency edge
`SCHEMA.SEQ_NAME:NEXTVAL`, and in the table's `columns[]` entry as
`identity_kind: "sequence-trigger"` with the sequence and trigger
names referenced. This preserves the surrogate-key mechanism for
Design, which must decide whether to port to `GENERATED AS IDENTITY`
in the target dialect.

Sequences can be shared across tables; do not assume one sequence per
table.

## Views and Materialized Views

Views are extracted verbatim. The view's `SELECT` body is stored
under `definition`. Column aliases in the view projection become the
view's column list; if no alias is given, the column name is
inherited from the source.

Materialized views require the refresh semantics. The statement:

    CREATE MATERIALIZED VIEW mv_sales
      REFRESH FAST ON COMMIT
      AS SELECT ... FROM sales;

produces `refresh_method: "FAST"`, `refresh_mode: "ON COMMIT"`. When
a materialized view log is not present on the source table, `FAST`
refresh will fail at runtime; the schema extraction must not validate
this, but the portability analyzer downstream depends on the log
entry, so emit materialized view logs as distinct entries
(`kind: "mview-log"`).

Refresh groups (`DBMS_REFRESH.MAKE(...)`) are recorded under
`oracle-scheduler-inventory.json` because they are invoked by
scheduler jobs, not DDL. Cross-reference by group name.

## Reconciling with `expdp` Round-Trip Output

When both source DDL and an `expdp` dump are delivered, run `impdp`
against a target Oracle instance with `SQLFILE=unload.sql` to emit
the dump's DDL without loading data:

    impdp user/password DIRECTORY=dp_dir DUMPFILE=mss_all_schemas.dmp \
          SQLFILE=unload.sql FULL=Y

Parse `unload.sql` with the same DDL parser used for migrations,
then diff against the reconstructed state:

- Objects present in the dump but not in migrations — the migration
  history is incomplete. Emit
  `ORA-SCHEMA-MIGRATION-GAP` with the missing object. Treat the
  dump's shape as authoritative.
- Objects present in migrations but not in the dump — the object was
  dropped in the source environment. Record a tombstone and emit
  `ORA-SCHEMA-DROPPED-OBJECT`.
- Column-level disagreements — dump type and migration type differ.
  The dump wins. Emit `ORA-SCHEMA-DDL-DRIFT`.

When only the dump is delivered and no source DDL exists, the
reconstructed state is empty and the dump is the sole source. Emit
`ORA-SCHEMA-IMPDP-REQUIRED` with the dump path, expected size, and a
prerequisite instruction for the operator to run the `impdp`
round-trip before Design can proceed.

## Synonyms and Cross-Schema References

Public synonyms (`CREATE PUBLIC SYNONYM emp FOR hr.emp;`) hide the
schema qualifier from callers. Record every synonym; when resolving
dependencies in `oracle-plsql-manifest.json`, a bare table reference
may resolve through a synonym rather than directly to the table. The
resolution order is: local schema → public synonyms → private
synonyms visible under `AUTHID`.

Synonyms that reference objects in neighbouring repos' schemas (for
FAA: `MSS` is shared across MedXPress, AMCS, DIWS, CPDSS) are a
cross-repo coupling signal. Emit `ORA-SCHEMA-CROSS-REPO-SYNONYM`
findings so `dependency-mapper` can fold them into the portfolio
graph.

## Citations

Every manifest record carries a `{repo}:{file}:{line}` citation at
the DDL statement that produced the object's final shape. For
tables, cite the last `ALTER TABLE` that mutated the object. For
views and materialized views, cite the `CREATE OR REPLACE` statement.
For indexes and constraints, cite the `CREATE INDEX` or `ALTER TABLE
ADD CONSTRAINT` site. Findings without citations are dropped by the
validator.
