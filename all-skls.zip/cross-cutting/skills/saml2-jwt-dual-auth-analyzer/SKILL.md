---
name: saml2-jwt-dual-auth-analyzer
description: >
  Detect .NET applications that carry BOTH SAML2 and JWT auth
  projects/libraries as first-class coexisting stacks — typically a
  mid-migration signature where an old SAML SSO is being replaced
  by API-token JWT auth, but both remain in production. DIWS is the
  ATLAS case: `FAA.JwtAuth` and `FAA.Saml2Auth` ship as two separate
  projects. IACRA also has dual auth (Node.js JWT middleware + legacy
  WebForms auth). Dual-auth has distinct token lifecycles, distinct
  revocation models, and distinct failure modes. Modernization must
  plan which stack wins or how they coexist. Runs as Discovery
  conditional when both SAML2 and JWT are detected. Triggers on
  dual-auth detection, auth stack migration analysis, or
  @saml2-jwt-dual-auth-analyzer.
agent: sonnet
allowed-tools:
  - Read
  - Write
  - Grep
  - Glob
validation_commands:
  - "python -m olympus.validators.schema_validator dual-auth-inventory.json"
  - "python -m olympus.validators.schema_validator dual-auth-flow-graph.json"
  - "python -m olympus.validators.schema_validator dual-auth-consolidation-findings.json"
supported_stacks:
  - saml2
  - saml
  - jwt
  - oauth
  - oidc
  - sso
  - aspnet
  - aspnet-core
anti_target_stacks:
  - single-auth
  - no-auth
  - static-site
failure_classes:
  - stack-role-confused-jwt-vs-saml
  - migration-direction-wrong
  - token-leak-across-stacks
  - revocation-inconsistency-missed
benchmark_tags:
  - discovery-auth
  - dual-auth-migration
  - saml-to-jwt-transition
---

# saml2-jwt-dual-auth-analyzer

## Purpose
Inventory coexisting SAML2 + JWT auth in one application. Surface
the mid-migration state as a deliberate modernization decision.

## Inputs
- Repository with auth-library references.
- Application catalog entry.

## Outputs
- `dual-auth-inventory.json` — per auth stack: stack, library,
  version, entry points, IdP/issuer, config file.
- `dual-auth-flow-graph.json` — which user type authenticates via
  which stack, which endpoints accept which token.
- `dual-auth-consolidation-findings.json` — retire one stack,
  preserve both, or gateway-consolidate.

## Methodology
1. Grep SAML2 libraries: `FAA.Saml2Auth`, `Sustainsys.Saml2`,
   `ITfoxtec.Identity.Saml2`, `Microsoft.IdentityModel.Tokens.Saml2`,
   `WSFederation`.
2. Grep JWT libraries: `FAA.JwtAuth`,
   `Microsoft.IdentityModel.Tokens.Jwt`,
   `System.IdentityModel.Tokens.Jwt`, `jsonwebtoken`, `jose`.
3. Locate entry points per stack.
4. Map user audience to auth stack.
5. Emit consolidation recommendation.

## Tech-Stack Dispatch

No external references.

## Gotchas
- SAML2 != SAML1 (deprecated). Emit version.
- JWT sometimes issued by a Node sidecar — detect cross-process.
- OAuth / OIDC overlap with JWT (OIDC issues JWT id-tokens); don't
  double-count.
- SessionIndex (SAML) vs jti (JWT) = different revocation models.
- SAML-for-login + JWT-for-API is a legit federation pattern
  (preserve-both, not retire-one).

## Quality Rules
- [ ] Both stacks cataloged with library + version.
- [ ] Entry points per stack resolved.
- [ ] Audience mapping documented.
- [ ] Consolidation recommendation with rationale.
- [ ] Every record cites `{repo}:{file}:{line}`.

## Common Failure Modes

| Failure Mode | Symptom | Prevention |
|---|---|---|
| SAML + OIDC merged | OIDC labeled as SAML; ignores OIDC semantics | Distinguish issuance protocol |
| Migration direction wrong | Retire new JWT instead of old SAML | Consider audience, release notes, active dev |

## Handoff Summary
Dual-auth inventoried; consolidation options recommended. Proceed
to `identity-landscape-analyzer`.

## References
None.

## Changelog
- 0.1.0 (2026-05-07) — Initial skill. Authored as ATLAS-R-19.
