# Pre-Approved Parity Divergences

These differences are EXPECTED and should not be flagged as failures:

| Category | Legacy | Modern | Reason |
|----------|--------|--------|--------|
| Error format | Generic 500 | Structured JSON error | Intentional improvement |
| Date format | mm/dd/yyyy | ISO 8601 | Standardization |
| Pagination | All records | Paginated (50/page) | Performance improvement |
| Character encoding | Latin-1 | UTF-8 | Standardization |
| HTTP status codes | 200 for errors | Proper 4xx/5xx | Correctness |
| Session handling | Server-side | Stateless JWT | Architecture modernization |
| File paths | Windows backslash | Unix forward slash | Platform migration |
