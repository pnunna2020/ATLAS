# Output Normalization Rules

## Apply Before Comparison
1. Whitespace: Collapse all whitespace to single space, trim
2. Dates: Normalize to ISO 8601 (YYYY-MM-DD)
3. Numbers: Normalize decimal precision to source precision
4. JSON: Sort keys alphabetically, normalize null vs missing
5. XML: Remove comments, normalize namespace prefixes
6. HTML: Strip non-semantic tags (font, center, br)
7. IDs: Replace auto-generated IDs with placeholder tokens
8. Timestamps: Replace with {{TIMESTAMP}} tokens
9. Encoding: Normalize all to UTF-8
10. Case: Only normalize case for non-user-facing identifiers
