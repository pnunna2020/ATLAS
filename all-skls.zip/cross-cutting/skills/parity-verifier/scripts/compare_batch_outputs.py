#!/usr/bin/env python3
"""
Batch Output Comparator
Compares output files from legacy and modern batch jobs.
Usage: python compare_batch_outputs.py <legacy_output_dir> <modern_output_dir>
"""
import sys
import os
import json
import hashlib

def hash_file(path):
    h = hashlib.sha256()
    with open(path, 'rb') as f:
        for chunk in iter(lambda: f.read(8192), b''):
            h.update(chunk)
    return h.hexdigest()

def compare_dirs(legacy_dir, modern_dir):
    legacy_files = set(os.listdir(legacy_dir))
    modern_files = set(os.listdir(modern_dir))
    results = {
        "only_in_legacy": list(legacy_files - modern_files),
        "only_in_modern": list(modern_files - legacy_files),
        "compared": []
    }
    for f in legacy_files & modern_files:
        lh = hash_file(os.path.join(legacy_dir, f))
        mh = hash_file(os.path.join(modern_dir, f))
        results["compared"].append({"file": f, "match": lh == mh})
    matched = sum(1 for c in results["compared"] if c["match"])
    results["summary"] = {
        "total_compared": len(results["compared"]),
        "matched": matched,
        "mismatched": len(results["compared"]) - matched
    }
    return results

if __name__ == "__main__":
    result = compare_dirs(sys.argv[1], sys.argv[2])
    print(json.dumps(result, indent=2))
