#!/usr/bin/env python3
"""
API Parity Comparator
Calls legacy and modern endpoints with identical payloads, compares responses.
Usage: python compare_api_responses.py <test_cases.json> <legacy_base> <modern_base>
"""
import sys
import json
import urllib.request
import hashlib

def normalize(obj):
    if isinstance(obj, dict):
        return {k: normalize(v) for k, v in sorted(obj.items()) if v is not None}
    elif isinstance(obj, list):
        return [normalize(i) for i in obj]
    elif isinstance(obj, str):
        return ' '.join(obj.split())
    return obj

def compare(test_cases_path, legacy_base, modern_base):
    with open(test_cases_path) as f:
        tests = json.load(f)
    results = []
    for tc in tests:
        legacy_url = f"{legacy_base}{tc['path']}"
        modern_url = f"{modern_base}{tc['path']}"
        try:
            with urllib.request.urlopen(legacy_url) as r:
                legacy = json.loads(r.read())
            with urllib.request.urlopen(modern_url) as r:
                modern = json.loads(r.read())
            norm_legacy = normalize(legacy)
            norm_modern = normalize(modern)
            match = norm_legacy == norm_modern
            results.append({"test": tc["name"], "match": match,
                "legacy_hash": hashlib.md5(json.dumps(norm_legacy).encode()).hexdigest(),
                "modern_hash": hashlib.md5(json.dumps(norm_modern).encode()).hexdigest()})
        except Exception as e:
            results.append({"test": tc["name"], "match": False, "error": str(e)})
    passed = sum(1 for r in results if r["match"])
    return {"total": len(results), "passed": passed, "failed": len(results)-passed,
            "parity_rate": f"{passed/len(results)*100:.1f}%", "results": results}

if __name__ == "__main__":
    result = compare(sys.argv[1], sys.argv[2], sys.argv[3])
    print(json.dumps(result, indent=2))
