#!/usr/bin/env python3
"""Capture legacy application behavior for parity comparison.

Drives the legacy system through a defined set of interactions (URLs, form
submissions, API calls) and records the full response chain — status codes,
headers, body, cookies, and any server-side side effects visible in the DB.

The captured trace is a frozen baseline. The modern system trace is captured
separately (see capture_modern_behavior.py) and the two are compared by the
parity-verifier.
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from typing import Any


def load_interactions(path: Path) -> list[dict[str, Any]]:
    """Load the list of interactions to drive against the legacy system.

    Each interaction is a dict with at least:
      - id: stable identifier
      - method: HTTP verb or "batch" or "db"
      - target: URL, batch job name, or DB query
      - payload: request body, form data, or batch inputs
    """
    return json.loads(path.read_text(encoding="utf-8"))


def drive_interaction(interaction: dict[str, Any], base_url: str) -> dict[str, Any]:
    """Execute a single interaction against the legacy system and record outputs."""
    # TODO(skill-author): Implement real legacy drivers:
    #   - HTTP: requests or httpx with session reuse for cookies
    #   - Batch: trigger and poll the job, capture output files
    #   - DB: execute query, record rows
    return {"id": interaction.get("id"), "captured": False}


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--interactions",
        type=Path,
        required=True,
        help="JSON file defining the interactions to drive",
    )
    parser.add_argument(
        "--base-url",
        required=True,
        help="Base URL of the legacy system",
    )
    parser.add_argument(
        "--output",
        type=Path,
        required=True,
        help="Path to write the captured trace",
    )
    args = parser.parse_args(argv)

    interactions = load_interactions(args.interactions)
    captures = [drive_interaction(item, args.base_url) for item in interactions]
    args.output.write_text(json.dumps(captures, indent=2), encoding="utf-8")
    print(f"Captured {len(captures)} legacy interactions to {args.output}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
