# Behavioral Parity Report

## Application: {{APP_NAME}}
## Archetype: {{ARCHETYPE}}
## Date: {{DATE}}

---

## Summary
| Metric | Value |
|--------|-------|
| Total test cases | {{TOTAL}} |
| Passed (identical) | {{PASSED}} |
| Failed (divergent) | {{FAILED}} |
| Parity rate | {{PARITY_RATE}} |
| Gate decision | {{PASS_FAIL}} |

## Divergences
{{#each DIVERGENCES}}
### {{TEST_NAME}}
- **Severity**: {{CRITICAL|ACCEPTABLE}}
- **Legacy output**: {{LEGACY_SUMMARY}}
- **Modern output**: {{MODERN_SUMMARY}}
- **Root cause**: {{CAUSE}}
- **Remediation**: {{ACTION}}
{{/each}}

## Acceptable Divergences (Pre-Approved)
{{#each ACCEPTABLE}}
- {{DESCRIPTION}} — per acceptable-divergences.md
{{/each}}
