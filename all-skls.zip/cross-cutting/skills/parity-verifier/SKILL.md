---
name: parity-verifier
description: >
  Verify behavioral parity between legacy and modernized applications.
  Use during P5.1 validation to compare legacy vs modern outputs, API responses,
  batch job results, and user workflow outcomes. Triggers on behavioral parity,
  legacy comparison, functional equivalence, regression testing, or output
  comparison mentions.
agent: sonnet
allowed-tools:
  - Read
  - Write
  - Bash
---

# Behavioral Parity Verification

## Purpose
Prove that the modernized application produces identical business outcomes to
the legacy system. This is the core gate for G-04a (extraction completeness)
and P5.1 (functional validation).

## Workflow
1. Load config for app archetype (web/batch/API)
2. For web apps: Run `scripts/capture_legacy_behavior.py` and `scripts/capture_modern_behavior.py`
3. For APIs: Run `scripts/compare_api_responses.py` with test payloads
4. For batch jobs: Run `scripts/compare_batch_outputs.py`
5. Generate parity report using `assets/parity-report-template.md`
6. Flag any divergences as CRITICAL (business logic) or ACCEPTABLE (formatting)

## Gotchas
- **Parity ≠ identical bytes**: Legacy systems may return data in different order,
  with different whitespace, or with legacy-specific formatting. Normalize before
  comparing. The script handles common normalizations but add app-specific ones.
- **Batch job timing differences are expected**: Modern batch jobs will run faster
  but the OUTPUT should be identical. Don't fail parity on execution time.
- **Database-dependent outputs**: If the legacy system reads from the legacy DB
  and the modern system reads from the migrated DB, ensure test data is identical
  in both. Use P3.3 synthetic test data to guarantee this.
- **Error handling may intentionally differ**: Legacy apps may return generic 500
  errors where modern apps return structured error responses. Document these as
  INTENTIONAL IMPROVEMENTS, not parity failures.
- **Date/time formatting**: Legacy apps often use mm/dd/yyyy, modern may use ISO 8601.
  Normalize dates before comparison.

## Reference Files
- `references/normalization-rules.md` — Standard output normalization rules
- `references/acceptable-divergences.md` — Pre-approved differences

## Quality Rules
- [ ] Parity report covers all three archetypes present in the application (web, batch, API) — none skipped
- [ ] Output normalization is applied before comparison (whitespace, date formats, field ordering)
- [ ] Every divergence is classified as CRITICAL (business logic difference) or ACCEPTABLE (formatting/ordering)
- [ ] ACCEPTABLE divergences reference a specific entry in `references/acceptable-divergences.md` or are explicitly justified
- [ ] Test data is identical in legacy and modern databases — verified via checksum or row-count validation
- [ ] Parity threshold meets or exceeds 98% match rate for business-critical outputs
- [ ] Error handling differences are documented as INTENTIONAL IMPROVEMENTS with justification, not silently ignored
- [ ] Batch job outputs are compared on content, not execution timing
- [ ] All parity test payloads include boundary conditions and edge cases, not just happy-path inputs

## Common Failure Modes
| Failure Mode | Symptom | Prevention |
|-------------|---------|------------|
| Byte-level comparison without normalization | False failures on whitespace, field ordering, or date format differences | Apply normalization rules from `references/normalization-rules.md` before comparison |
| Test data mismatch | Parity failures caused by different data in legacy vs modern databases, not logic differences | Verify test data identity via checksums before running comparison; use P3.3 synthetic data |
| Missing archetype coverage | Web app passes parity but batch jobs or APIs were never compared | Check application archetype inventory and run comparison scripts for all present archetypes |
| Threshold too lenient | 90% match rate accepted for Tier 1 safety-critical app; real business logic gaps ship to production | Enforce 98% minimum for T1/T2 apps; require human review for any CRITICAL divergence |
| Intentional improvements misclassified | Error handling improvements classified as CRITICAL divergences, blocking deployment unnecessarily | Pre-document intentional improvements during design phase; reference them in parity config |

## Handoff Summary
When this skill completes, verify:
1. Parity report exists for every archetype (web/batch/API) present in the application
2. All CRITICAL divergences are resolved or escalated — zero unresolved CRITICAL items
3. Parity threshold (>=98%) is met for business-critical outputs
4. ACCEPTABLE divergences are justified and documented
Then proceed to: `cato-compliance` (P5.2) for security certification, and gate `G-V1` for functional validation sign-off
