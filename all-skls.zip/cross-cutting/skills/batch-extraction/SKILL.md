---
name: batch-extraction
description: >
  Extract specifications from batch jobs, ETL pipelines, scheduled tasks, and cron-based workflows. Use during P4.1 for batch/job archetype applications. Triggers on batch extraction, ETL analysis, scheduled job analysis, or batch specification.
agent: opus
allowed-tools:
  - Read
  - Write
  - Bash
  - Grep
---

# Batch Extraction

## Purpose
Specialized extraction for the batch/job archetype — fundamentally different from web app extraction.

## Gotchas
- **Batch jobs have NO UI**: All logic is in code, configs, and schedules.
  There's no user journey to analyze — focus on data flow and timing.
- **Dependencies are temporal**: Job A must complete before Job B starts.
  Capture the execution order, not just the individual job logic.
- **Error handling in batch is critical**: What happens when a batch job fails
  at 2am? Retry? Alert? Skip? This IS a business rule.

## Tech-Stack Dispatch
Before batch extraction, detect the batch technology and load the appropriate reference:
- For SSIS packages (.dtsx, SQL Agent jobs) → `references/ssis-sqlagent-patterns.md`
- For Oracle DBMS_SCHEDULER / cron → load the `extraction` skill's Oracle EBS reference
- For Spring Batch (.java, batch XML configs) → load the `extraction` skill's Java EE reference
- For ColdFusion scheduled tasks → load the `extraction` skill's ColdFusion reference

## Quality Rules
- [ ] Every batch job has its execution schedule captured (cron expression, frequency, time window)
- [ ] Job dependency chains are fully mapped — temporal ordering and conditional triggers documented
- [ ] Error handling behavior is documented for each job: retry policy, alert mechanism, skip behavior, and recovery steps
- [ ] Data flow for each job is captured: input sources, transformations, output destinations, and intermediate staging
- [ ] Job idempotency is assessed — can the job be safely re-run without side effects?
- [ ] Performance characteristics are documented: typical runtime, data volume, resource consumption
- [ ] All configuration sources are identified: environment variables, config files, database parameters, command-line arguments

## Common Failure Modes
| Failure Mode | Symptom | Prevention |
|-------------|---------|------------|
| Web-app extraction strategy applied to batch | Missing schedule, dependency chain, and error recovery logic; only data transformations captured | Verify archetype is batch before extraction; load this skill specifically for batch jobs |
| Missing temporal dependencies | Individual jobs extracted but execution ordering lost; modernized jobs run out of sequence | Map job dependency chains explicitly; capture predecessor/successor relationships |
| Error handling omitted | Modernized batch jobs have no retry or alerting; failures at 2am go unnoticed | Treat error handling as a mandatory business rule; document retry, alert, and skip behaviors |
| Configuration scattered | Job behavior depends on environment-specific configs not captured during extraction | Scan for all config sources: env vars, DB parameters, config files, and CLI arguments |
| Idempotency not assessed | Modernized job re-run corrupts data because legacy job was not idempotent and no guard was added | Assess idempotency during extraction; flag non-idempotent jobs for design-phase mitigation |

## Handoff Summary
When this skill completes, verify:
1. Every batch job has schedule, dependency chain, error handling, and data flow documented
2. Job idempotency assessments are complete
3. Configuration sources are fully cataloged
4. Temporal execution ordering is mapped and validated
Then proceed to: `batch-design` (P4.2) for modernized batch architecture, and gate `G-04a` for extraction completeness review
