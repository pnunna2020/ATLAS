# SSIS and SQL Agent Batch Job Extraction Patterns

## Purpose

Reference for the Batch Extraction skill when analyzing SQL Server Integration
Services (SSIS) packages and SQL Agent jobs. SSIS packages encode ETL business
logic in XML-based .dtsx files. SQL Agent orchestrates scheduled execution across
jobs, steps, and schedules. This guide covers structural analysis, logic extraction,
and migration target mapping.

## SSIS Package Structure

### dtsx XML Anatomy

SSIS packages are XML files with the `.dtsx` extension. The top-level structure:

```xml
<DTS:Executable xmlns:DTS="www.microsoft.com/SqlServer/Dts"
    DTS:refId="Package"
    DTS:ObjectName="ImportVendorData">

  <!-- Package parameters (SSIS 2012+) -->
  <DTS:PackageParameters>
    <DTS:PackageParameter DTS:ObjectName="SourceFilePath"
        DTS:DataType="8">\\share\imports\vendors\</DTS:PackageParameter>
    <DTS:PackageParameter DTS:ObjectName="TargetDatabase"
        DTS:DataType="8">ProductionDB</DTS:PackageParameter>
  </DTS:PackageParameters>

  <!-- Variables (package-scoped state) -->
  <DTS:Variables>
    <DTS:Variable DTS:ObjectName="RecordCount" DTS:DataType="3">0</DTS:Variable>
    <DTS:Variable DTS:ObjectName="ErrorCount" DTS:DataType="3">0</DTS:Variable>
    <DTS:Variable DTS:ObjectName="BatchId" DTS:DataType="8"></DTS:Variable>
  </DTS:Variables>

  <!-- Connection Managers (data source/destination definitions) -->
  <DTS:ConnectionManagers>
    <DTS:ConnectionManager DTS:ObjectName="SourceFile"
        DTS:ConnectionString="\\share\imports\vendors\*.csv" />
    <DTS:ConnectionManager DTS:ObjectName="TargetDB"
        DTS:ConnectionString="Data Source=.;Initial Catalog=ProductionDB;
            Integrated Security=SSPI;" />
  </DTS:ConnectionManagers>

  <!-- Executables (the task tree: Control Flow) -->
  <DTS:Executables>
    <!-- Tasks defined here -->
  </DTS:Executables>

  <!-- Precedence Constraints (execution order and conditions) -->
  <DTS:PrecedenceConstraints>
    <!-- Flow control between tasks -->
  </DTS:PrecedenceConstraints>

  <!-- Event Handlers (error/completion handlers) -->
  <DTS:EventHandlers>
    <!-- OnError, OnPostExecute, etc. -->
  </DTS:EventHandlers>
</DTS:Executable>
```

### Connection Managers

Connection Managers define all external data sources and destinations:

| Connection Type | Provider | Migration Target |
|-----------------|----------|-----------------|
| OLE DB | SQLNCLI / MSOLEDBSQL | PostgreSQL via psycopg2 or SQLAlchemy |
| ADO.NET | System.Data.SqlClient | psycopg2 or application-layer connection |
| Flat File | Text file (CSV, fixed-width) | S3 + Lambda / Python file processing |
| Excel | Microsoft.ACE.OLEDB | pandas / openpyxl in Lambda |
| FTP | FTP connection | S3 Transfer Family or boto3 |
| SMTP | SMTP server | Amazon SES |
| HTTP | HTTP endpoint | Lambda with requests/urllib |
| ODBC | ODBC driver | Application-specific connector |

**Extraction approach**: List all connection managers to map the data topology.
Each connection manager represents an integration point.

## Data Flow Analysis

Data Flow tasks are the heart of SSIS ETL logic. They define source-to-destination
transformations in a pipeline.

### Source Components

```xml
<!-- OLE DB Source — SQL query defines the extraction logic -->
<component name="Extract Orders"
    componentClassID="Microsoft.OLEDBSource">
  <properties>
    <property name="SqlCommand">
      SELECT
          o.OrderId, o.CustomerName, o.OrderDate,
          o.TotalAmount, o.Status,
          -- RULE: Calculate fiscal quarter from order date
          CASE
              WHEN MONTH(o.OrderDate) IN (10,11,12) THEN 'Q1'
              WHEN MONTH(o.OrderDate) IN (1,2,3)    THEN 'Q2'
              WHEN MONTH(o.OrderDate) IN (4,5,6)    THEN 'Q3'
              ELSE 'Q4'
          END AS FiscalQuarter
      FROM Orders o
      WHERE o.OrderDate >= ? AND o.OrderDate &lt; ?
        AND o.Status IN ('Completed', 'Shipped')
    </property>
  </properties>
</component>
```

**Note**: SQL embedded in SSIS source components often contains business logic
in the WHERE clause and calculated columns. Extract these queries carefully.

### Transformation Components

| Transformation | Purpose | Migration Pattern |
|---------------|---------|-------------------|
| Derived Column | Calculate new columns using expressions | Python/SQL computed columns |
| Conditional Split | Route rows to different outputs by condition | Python if/elif or CASE in SQL |
| Lookup | Enrich rows by joining to reference data | SQL JOIN or in-memory dictionary |
| Merge Join | Join two sorted streams | SQL JOIN |
| Union All | Combine multiple streams | SQL UNION ALL |
| Aggregate | SUM, COUNT, AVG by group | SQL GROUP BY |
| Sort | Order rows | SQL ORDER BY |
| Data Conversion | Change data types | CAST in SQL or Python type conversion |
| Character Map | Unicode/string transformations | Python string methods |
| Multicast | Duplicate stream to multiple outputs | Multiple INSERT statements |
| Row Count | Count rows into a variable | COUNT(*) or len() |
| Script Component | Custom C#/VB.NET transformation | Python function |
| Fuzzy Lookup | Approximate matching | pg_trgm extension or custom logic |
| Fuzzy Grouping | Deduplication by similarity | Custom dedup logic |
| Slowly Changing Dimension | SCD Type 1/2/3 processing | Custom SQL merge logic |
| Pivot / Unpivot | Reshape data | SQL PIVOT / crosstab() |
| OLE DB Command | Row-by-row DML | Batch SQL operations |

### Derived Column Expressions

SSIS has its own expression language for Derived Column transformations:

```
// SSIS Expression Language → Target mapping

// String functions
SUBSTRING(ColumnName, 1, 3)         → LEFT(column_name, 3)  -- PostgreSQL
UPPER(ColumnName)                    → UPPER(column_name)
LOWER(ColumnName)                    → LOWER(column_name)
TRIM(ColumnName)                     → TRIM(column_name)
LEN(ColumnName)                      → LENGTH(column_name)
REPLACE(ColumnName, "old", "new")    → REPLACE(column_name, 'old', 'new')
FINDSTRING(ColumnName, "search", 1)  → POSITION('search' IN column_name)
RIGHT(ColumnName, 4)                 → RIGHT(column_name, 4)
LTRIM(RTRIM(ColumnName))            → TRIM(column_name)
REPLICATE("0", 5)                    → REPEAT('0', 5)

// Date functions
GETDATE()                            → NOW()
YEAR(DateColumn)                     → EXTRACT(YEAR FROM date_column)
MONTH(DateColumn)                    → EXTRACT(MONTH FROM date_column)
DAY(DateColumn)                      → EXTRACT(DAY FROM date_column)
DATEADD("dd", 30, DateColumn)        → date_column + INTERVAL '30 days'
DATEDIFF("dd", Date1, Date2)         → DATE_PART('day', date2 - date1)
DATEPART("dw", DateColumn)           → EXTRACT(DOW FROM date_column)

// Type casting
(DT_STR, 10, 1252) NumericColumn     → CAST(numeric_column AS VARCHAR(10))
(DT_I4) StringColumn                 → CAST(string_column AS INTEGER)
(DT_DECIMAL, 2) IntColumn            → CAST(int_column AS NUMERIC(18,2))
(DT_DBTIMESTAMP) StringColumn        → CAST(string_column AS TIMESTAMP)

// Null handling
ISNULL(ColumnName) ? "default" : ColumnName    → COALESCE(column_name, 'default')
REPLACENULL(ColumnName, "default")              → COALESCE(column_name, 'default')

// Conditional
Condition ? TrueValue : FalseValue   → CASE WHEN condition THEN true ELSE false END

// Boolean operators
ColumnA == "value" && ColumnB > 100  → column_a = 'value' AND column_b > 100
ColumnA == "value" || ColumnB > 100  → column_a = 'value' OR column_b > 100
!ISNULL(ColumnName)                  → column_name IS NOT NULL
```

### Conditional Split Rules

Conditional Split encodes row-routing business rules:

```xml
<!-- RULE: Route records based on data quality and type -->
<component name="Route Records" componentClassID="Microsoft.ConditionalSplit">
  <outputs>
    <!-- Output 1: Valid domestic orders -->
    <output name="Valid Domestic">
      <expression>[Country] == "US" &amp;&amp; [TotalAmount] > 0
          &amp;&amp; !ISNULL([CustomerId])</expression>
    </output>
    <!-- Output 2: Valid international orders -->
    <output name="Valid International">
      <expression>[Country] != "US" &amp;&amp; [TotalAmount] > 0
          &amp;&amp; !ISNULL([CustomerId])
          &amp;&amp; !ISNULL([CurrencyCode])</expression>
    </output>
    <!-- Output 3: High-value orders needing review -->
    <output name="High Value Review">
      <expression>[TotalAmount] > 100000</expression>
    </output>
    <!-- Default output: Error/reject records -->
    <output name="Rejected" isDefault="true" />
  </outputs>
</component>
```

### Lookup Transformations

Lookups encode referential business rules:

```xml
<!-- RULE: Enrich order with customer tier from reference table -->
<component name="Lookup Customer Tier"
    componentClassID="Microsoft.Lookup">
  <properties>
    <property name="SqlCommand">
      SELECT CustomerId, CustomerTier, CreditLimit, SalesRep
      FROM CustomerMaster
      WHERE IsActive = 1
    </property>
    <property name="NoMatchBehavior">RedirectToNoMatchOutput</property>
    <!-- RULE: No match = new customer, route to separate handling -->
  </properties>
</component>
```

### Script Component Patterns

Script Components contain C# or VB.NET code for complex transformations:

```csharp
// Common patterns in SSIS Script Components:

// RULE: Custom address parsing
public override void Input0_ProcessInputRow(Input0Buffer Row)
{
    // RULE: Parse compound address field into components
    string[] parts = Row.FullAddress.Split(',');
    Row.Street = parts.Length > 0 ? parts[0].Trim() : "";
    Row.City = parts.Length > 1 ? parts[1].Trim() : "";
    Row.State = parts.Length > 2 ? parts[2].Trim().Substring(0, 2) : "";
    Row.ZipCode = parts.Length > 2 ? ExtractZip(parts[2]) : "";

    // RULE: Validate state code against lookup
    if (!ValidStates.Contains(Row.State))
    {
        Row.IsValid = false;
        Row.ErrorDescription = "Invalid state code: " + Row.State;
    }
}

// RULE: Custom date parsing with multiple format support
private DateTime? ParseFlexibleDate(string dateStr)
{
    string[] formats = {
        "MM/dd/yyyy", "M/d/yyyy", "yyyy-MM-dd",
        "dd-MMM-yyyy", "yyyyMMdd", "MM-dd-yyyy"
    };
    DateTime result;
    if (DateTime.TryParseExact(dateStr, formats, CultureInfo.InvariantCulture,
        DateTimeStyles.None, out result))
        return result;
    return null;
}
```

**Extraction impact**: Script Component code is embedded in the dtsx XML as
Base64-encoded binary. It must be decoded and decompiled, or the SSIS project
source code must be available.

## Control Flow Patterns

### For Loop Container

```xml
<!-- RULE: Process files in date-range batches -->
<DTS:Executable DTS:ExecutableType="STOCK:FORLOOP">
  <DTS:ForEachVariableMapping
      DTS:VariableName="User::CurrentDate" />
  <properties>
    <property name="InitExpression">@[User::CurrentDate] = @[User::StartDate]</property>
    <property name="EvalExpression">@[User::CurrentDate] &lt;= @[User::EndDate]</property>
    <property name="AssignExpression">@[User::CurrentDate] =
        DATEADD("dd", 1, @[User::CurrentDate])</property>
  </properties>
</DTS:Executable>
```

### ForEach Loop Container

```xml
<!-- RULE: Process each file in the import directory -->
<DTS:Executable DTS:ExecutableType="STOCK:FOREACHLOOP">
  <DTS:ForEachEnumerator>
    <!-- File Enumerator: iterate over files matching pattern -->
    <property name="FileSpec">*.csv</property>
    <property name="Folder">\\share\imports\daily\</property>
  </DTS:ForEachEnumerator>
  <DTS:ForEachVariableMapping
      DTS:VariableName="User::CurrentFilePath" />
</DTS:Executable>

<!-- Other ForEach enumerator types -->
<!-- ADO Enumerator: iterate over recordset rows -->
<!-- Variable Enumerator: iterate over list in variable -->
<!-- NodeList Enumerator: iterate over XML nodes -->
<!-- SMO Enumerator: iterate over SQL Server objects -->
```

### Sequence Container

Sequence Containers group tasks for transaction scope and error handling:

```
Package (Control Flow)
├── Sequence: Pre-Processing
│   ├── Execute SQL: Truncate staging tables
│   └── Execute SQL: Create batch record
├── Sequence: Data Load (TransactionOption = Required)
│   ├── Data Flow: Import vendor file
│   ├── Data Flow: Import invoice file
│   └── Execute SQL: Update cross-references
├── Sequence: Validation
│   ├── Execute SQL: Run validation procedures
│   └── Script Task: Generate validation report
└── Sequence: Post-Processing
    ├── Execute SQL: Move data from staging to production
    ├── File System Task: Archive source files
    └── Send Mail Task: Notify operations team
```

### Execute SQL Task

Execute SQL tasks run queries against databases:

```xml
<!-- Common Execute SQL patterns -->

<!-- RULE: Truncate staging table before load -->
<property name="SqlStatementSource">TRUNCATE TABLE dbo.VendorStaging</property>

<!-- RULE: Get configuration value -->
<property name="SqlStatementSource">
    SELECT ConfigValue FROM SystemConfig WHERE ConfigKey = ?
</property>

<!-- RULE: Call stored procedure with output -->
<property name="SqlStatementSource">
    EXEC dbo.usp_CreateImportBatch ?, ?, ? OUTPUT
</property>

<!-- RULE: Record count validation -->
<property name="SqlStatementSource">
    SELECT COUNT(*) AS RecordCount FROM VendorStaging WHERE BatchId = ?
</property>
```

### Execute Package Task

Executes another SSIS package (parent-child orchestration):

```
Master Package
├── Execute Package: 01_ExtractSources.dtsx
├── Execute Package: 02_TransformAndValidate.dtsx
├── Execute Package: 03_LoadTargets.dtsx
└── Execute Package: 04_ReconcileAndNotify.dtsx
```

**Extraction impact**: Package chains define the batch processing workflow.
Map the full execution tree before analyzing individual packages.

## SQL Agent Job Extraction

### Job Inventory Query

```sql
-- Complete SQL Agent job inventory with schedule details
SELECT
    j.name AS job_name,
    j.description,
    j.enabled,
    SUSER_SNAME(j.owner_sid) AS job_owner,
    c.name AS category_name,
    -- Schedule information
    CASE s.freq_type
        WHEN 1  THEN 'Once'
        WHEN 4  THEN 'Daily'
        WHEN 8  THEN 'Weekly'
        WHEN 16 THEN 'Monthly'
        WHEN 32 THEN 'Monthly Relative'
        WHEN 64 THEN 'SQL Agent Start'
        WHEN 128 THEN 'Idle'
    END AS schedule_frequency,
    CASE s.freq_type
        WHEN 4 THEN 'Every ' + CAST(s.freq_interval AS VARCHAR) + ' day(s)'
        WHEN 8 THEN
            CASE WHEN s.freq_interval & 2  = 2  THEN 'Mon ' ELSE '' END +
            CASE WHEN s.freq_interval & 4  = 4  THEN 'Tue ' ELSE '' END +
            CASE WHEN s.freq_interval & 8  = 8  THEN 'Wed ' ELSE '' END +
            CASE WHEN s.freq_interval & 16 = 16 THEN 'Thu ' ELSE '' END +
            CASE WHEN s.freq_interval & 32 = 32 THEN 'Fri ' ELSE '' END +
            CASE WHEN s.freq_interval & 64 = 64 THEN 'Sat ' ELSE '' END +
            CASE WHEN s.freq_interval & 1  = 1  THEN 'Sun ' ELSE '' END
        WHEN 16 THEN 'Day ' + CAST(s.freq_interval AS VARCHAR) + ' of month'
        ELSE ''
    END AS schedule_detail,
    -- Time formatting
    STUFF(STUFF(RIGHT('000000' + CAST(s.active_start_time AS VARCHAR), 6),
        5, 0, ':'), 3, 0, ':') AS start_time,
    j.date_created,
    j.date_modified
FROM msdb.dbo.sysjobs j
LEFT JOIN msdb.dbo.syscategories c ON j.category_id = c.category_id
LEFT JOIN msdb.dbo.sysjobschedules js ON j.job_id = js.job_id
LEFT JOIN msdb.dbo.sysschedules s ON js.schedule_id = s.schedule_id
ORDER BY j.name;
```

### Job Step Details

```sql
-- All job steps with classification
SELECT
    j.name AS job_name,
    js.step_id,
    js.step_name,
    CASE js.subsystem
        WHEN 'TSQL'        THEN 'T-SQL Script'
        WHEN 'CmdExec'     THEN 'OS Command'
        WHEN 'SSIS'        THEN 'SSIS Package'
        WHEN 'PowerShell'  THEN 'PowerShell'
        WHEN 'Distribution' THEN 'Replication'
        WHEN 'Snapshot'    THEN 'Replication Snapshot'
        WHEN 'LogReader'   THEN 'Replication Log Reader'
        WHEN 'QueueReader' THEN 'Replication Queue Reader'
        WHEN 'ANALYSISCOMMAND' THEN 'SSAS Command'
        WHEN 'ANALYSISQUERY'   THEN 'SSAS Query'
        ELSE js.subsystem
    END AS step_type,
    js.database_name,
    -- Truncated command for overview (full command in detail view)
    LEFT(js.command, 200) AS command_preview,
    CASE js.on_success_action
        WHEN 1 THEN 'Quit Reporting Success'
        WHEN 2 THEN 'Quit Reporting Failure'
        WHEN 3 THEN 'Go To Next Step'
        WHEN 4 THEN 'Go To Step ' + CAST(js.on_success_step_id AS VARCHAR)
    END AS on_success,
    CASE js.on_fail_action
        WHEN 1 THEN 'Quit Reporting Success'
        WHEN 2 THEN 'Quit Reporting Failure'
        WHEN 3 THEN 'Go To Next Step'
        WHEN 4 THEN 'Go To Step ' + CAST(js.on_fail_step_id AS VARCHAR)
    END AS on_failure,
    js.retry_attempts,
    js.retry_interval
FROM msdb.dbo.sysjobs j
JOIN msdb.dbo.sysjobsteps js ON j.job_id = js.job_id
ORDER BY j.name, js.step_id;
```

### Job Step Type Classification

| Step Type | Content | Migration Target |
|-----------|---------|-----------------|
| T-SQL | SQL scripts, stored proc calls | PostgreSQL function / Lambda |
| CmdExec | Batch files, executables, scripts | Lambda / ECS task / Step Functions |
| SSIS | SSIS package reference | Step Functions + Lambda / Glue |
| PowerShell | PowerShell scripts | Lambda (Python) / ECS |
| Replication | SQL Server replication tasks | DMS / Custom CDC |
| SSAS | Analysis Services commands | Redshift / Athena |

### Job History Analysis

```sql
-- Job execution history with duration and status
SELECT
    j.name AS job_name,
    h.step_id,
    h.step_name,
    CASE h.run_status
        WHEN 0 THEN 'Failed'
        WHEN 1 THEN 'Succeeded'
        WHEN 2 THEN 'Retry'
        WHEN 3 THEN 'Cancelled'
        WHEN 4 THEN 'In Progress'
    END AS run_status,
    -- Convert run_duration (HHMMSS int) to readable format
    STUFF(STUFF(RIGHT('000000' + CAST(h.run_duration AS VARCHAR), 6),
        5, 0, ':'), 3, 0, ':') AS duration,
    msdb.dbo.agent_datetime(h.run_date, h.run_time) AS run_datetime,
    h.message
FROM msdb.dbo.sysjobhistory h
JOIN msdb.dbo.sysjobs j ON h.job_id = j.job_id
WHERE h.run_date >= CONVERT(INT, CONVERT(VARCHAR(8), DATEADD(DAY, -30, GETDATE()), 112))
ORDER BY j.name, h.run_date DESC, h.run_time DESC;
```

## Schedule Pattern Analysis

### Common Schedule Patterns and Migration Targets

| SQL Agent Pattern | Frequency | AWS Migration Target |
|-------------------|-----------|---------------------|
| Daily at fixed time | Daily 2:00 AM | EventBridge rule with cron |
| Every N minutes | Sub-hourly | EventBridge rate expression |
| Weekly on specific days | Weekly Mon-Fri | EventBridge cron with day-of-week |
| Monthly on day N | Monthly | EventBridge cron with day-of-month |
| On SQL Agent start | Server startup | ECS service / always-running Lambda |
| On idle | Low activity | CloudWatch alarm trigger |
| Event-triggered (alert) | Condition-based | CloudWatch Events / SNS |

### EventBridge Cron Equivalents

```
SQL Agent: Daily at 2:00 AM
EventBridge: cron(0 2 * * ? *)

SQL Agent: Every 15 minutes
EventBridge: rate(15 minutes)

SQL Agent: Monday through Friday at 6:00 AM
EventBridge: cron(0 6 ? * MON-FRI *)

SQL Agent: First day of every month at midnight
EventBridge: cron(0 0 1 * ? *)

SQL Agent: Every 2 hours starting at 6 AM, ending at 10 PM
EventBridge: Multiple rules or Step Functions with Wait states
```

## Job Dependency Mapping

### Within-Job Dependencies (Step Level)

```
Job: DailyDataRefresh
├── Step 1: Truncate staging tables (T-SQL)
│   ├── On Success → Step 2
│   └── On Failure → Quit with failure
├── Step 2: Import source data (SSIS)
│   ├── On Success → Step 3
│   └── On Failure → Step 5 (error handling)
├── Step 3: Validate and transform (T-SQL)
│   ├── On Success → Step 4
│   └── On Failure → Step 5 (error handling)
├── Step 4: Load production tables (T-SQL)
│   ├── On Success → Quit with success
│   └── On Failure → Step 5 (error handling)
└── Step 5: Error notification (CmdExec)
    └── On Success → Quit with failure
```

### Cross-Job Dependencies

Cross-job dependencies are not declarative in SQL Agent. They are implemented as:

**Explicit**: One job starts another via `sp_start_job`:
```sql
-- Step in Job A that triggers Job B
EXEC msdb.dbo.sp_start_job @job_name = 'ProcessInvoices'
```

**Implicit**: Jobs scheduled with timing dependencies:
```
Job: ExtractData       runs at 2:00 AM, takes ~45 minutes
Job: TransformData     runs at 3:00 AM (assumes Extract is done)
Job: LoadWarehouse     runs at 4:00 AM (assumes Transform is done)
```

**Token file**: Jobs check for sentinel files:
```sql
-- Step 1: Check if predecessor completed
IF NOT EXISTS (
    SELECT 1 FROM dbo.JobCompletionLog
    WHERE JobName = 'ExtractData'
      AND CompletionDate = CAST(GETDATE() AS DATE)
      AND Status = 'Success'
)
BEGIN
    RAISERROR('Predecessor job ExtractData has not completed', 16, 1)
    RETURN
END
```

**Migration impact**: Implicit timing dependencies must be converted to explicit
dependencies (Step Functions wait states, EventBridge targets with conditions, or
SNS notifications between jobs).

## Error Handling Patterns

### On Failure Actions

```sql
-- Job step error handling matrix
-- Step-level on_fail_action values:
-- 1 = Quit with success (suppress error)
-- 2 = Quit with failure (propagate error)
-- 3 = Go to next step (continue despite error)
-- 4 = Go to specific step (jump to error handler)
```

### Retry Configuration

```sql
-- Identify steps with retry logic
SELECT
    j.name AS job_name,
    js.step_name,
    js.retry_attempts,
    js.retry_interval  -- minutes between retries
FROM msdb.dbo.sysjobs j
JOIN msdb.dbo.sysjobsteps js ON j.job_id = js.job_id
WHERE js.retry_attempts > 0
ORDER BY j.name, js.step_id;
```

### Operator Notifications

```sql
-- Job notification configuration
SELECT
    j.name AS job_name,
    CASE j.notify_level_eventlog
        WHEN 0 THEN 'Never'
        WHEN 1 THEN 'On Success'
        WHEN 2 THEN 'On Failure'
        WHEN 3 THEN 'Always'
    END AS eventlog_notify,
    o_email.name AS email_operator,
    o_page.name AS page_operator,
    CASE j.notify_level_email
        WHEN 0 THEN 'Never'
        WHEN 1 THEN 'On Success'
        WHEN 2 THEN 'On Failure'
        WHEN 3 THEN 'Always'
    END AS email_notify_level
FROM msdb.dbo.sysjobs j
LEFT JOIN msdb.dbo.sysoperators o_email
    ON j.notify_email_operator_id = o_email.id
LEFT JOIN msdb.dbo.sysoperators o_page
    ON j.notify_page_operator_id = o_page.id
WHERE j.notify_level_email > 0
   OR j.notify_level_eventlog > 0
ORDER BY j.name;
```

## Migration Target Mapping

### SSIS to AWS Step Functions + Lambda

```
SSIS Concept              → AWS Equivalent
─────────────────────────────────────────────
Package                   → Step Functions State Machine
Control Flow              → State Machine definition (ASL)
Data Flow Task            → Lambda function (or Glue ETL job)
Sequence Container        → Parallel or Sequential state group
ForEach Loop              → Map state (parallel) or Iterator
Execute SQL Task          → Lambda calling RDS/Aurora
File System Task          → Lambda with S3 operations
Send Mail Task            → Lambda calling SES
Script Task               → Lambda function
Execute Package Task      → Nested Step Functions execution
Connection Manager        → Secrets Manager + connection config
Package Parameters        → Step Functions input / SSM Parameters
Variables                 → Step Functions result paths
Precedence Constraints    → State transitions with conditions
Event Handlers (OnError)  → Catch/Retry in Step Functions
```

### SQL Agent to EventBridge + Lambda

```
SQL Agent Concept         → AWS Equivalent
─────────────────────────────────────────────
Job                       → EventBridge rule + Step Functions
Job Step (T-SQL)          → Lambda (psycopg2) or RDS stored function
Job Step (CmdExec)        → Lambda or ECS task
Job Step (SSIS)           → Step Functions (nested)
Job Step (PowerShell)     → Lambda (Python equivalent)
Schedule                  → EventBridge cron/rate expression
Operator                  → SNS Topic + subscriptions
Alert                     → CloudWatch Alarm → SNS
Job History               → Step Functions execution history
Proxy                     → IAM Role
```

### T-SQL Batch Jobs to pg_cron

```sql
-- Simple T-SQL batch jobs can migrate to pg_cron in Aurora PostgreSQL
-- SQL Agent:
--   Job: "Nightly Cleanup"
--   Schedule: Daily at 1:00 AM
--   Step 1: EXEC dbo.usp_PurgeOldRecords @DaysToKeep = 90

-- PostgreSQL equivalent:
SELECT cron.schedule(
    'nightly-cleanup',
    '0 1 * * *',
    $$CALL purge_old_records(90)$$
);
```

## Extraction Priority Checklist

1. **SQL Agent job inventory** — complete list of all jobs, schedules, and steps
2. **Job dependency graph** — explicit (sp_start_job) and implicit (timing) dependencies
3. **SSIS package catalog** — all packages in SSISDB or file system
4. **Data Flow transformations** — business rules in Derived Columns, Conditional Splits, Lookups
5. **Script Components** — C#/VB.NET code with custom transformation logic
6. **Connection Managers** — complete data source/destination topology
7. **Error handling** — retry counts, failure actions, notification operators
8. **Schedule patterns** — frequency, timing, maintenance windows
9. **Job history** — average duration, failure rates, trends
10. **Cross-job dependencies** — build the full execution dependency DAG
