# Open-Question Patterns

When to flag for stakeholder input versus extract autonomously. Guessing corrupts the portfolio; prefer an open question to a fabricated value.

## Always flag (never guess)
- **Criticality with zero operational signals.** No SLA, uptime, ATO tier, or monitoring. Emit: `"Confirm criticality — no SLA/ATO/uptime signals in {codebase_location}"`.
- **Active users with no logs or session data.** Do not infer from persona names. Emit: `"Request active-user counts per persona — no access logs or session tables"`.
- **Source-of-truth ambiguity.** Entity has writes in this app's ORM AND another app's ORM. Emit: `"Confirm source-of-truth for X — writes in App-A ({file}:{line}) and App-B"`.
- **Integration without direction evidence.** Hostname present, no HTTP client / listener / producer / consumer signature. Emit: `"Confirm direction for system Y — no producer/consumer signature"`.
- **Personas in UI text but not in auth roles.** UI says "For supervisors" but no `SUPERVISOR` role. Emit: `"Confirm whether 'Supervisor' maps to an auth role"`.
- **Missing runbook or ATO on production.** Default open question when ST.1 artifacts not delivered.

## Extract autonomously (do not flag)
- Tech stack items already in Step 1 fingerprint — import, do not re-ask
- LOC, module, endpoint, table counts — mechanical and reproducible
- Data entities in ORM or DDL — extract by name even if description unclear
- Auth method when middleware clearly present (OAuth, SAML SP metadata, JWT)
- Accessibility ratios — always run markup heuristic; cite ratio as evidence

## Criticality threshold rule
- 0 signals: `rating: null`, open question required
- 1 signal: `medium` with evidence cite
- 2+ agreeing: take strongest (`high` if any High-tier present)
- Conflicting (e.g. 99.9% SLA but idle): record both and flag

## Format
Every open question is one imperative sentence naming the evidence that would resolve it. Store as strings in `open_questions[]`.
