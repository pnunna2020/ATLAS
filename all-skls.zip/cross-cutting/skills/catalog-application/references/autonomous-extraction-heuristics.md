# Autonomous Extraction Heuristics

Pull user context, personas, criticality from code — not from domain stereotypes. Every signal carries a `{file}:{line}` citation.

## Personas (auth and routing)
- Spring Security: `@PreAuthorize("hasRole('ADMIN')")`, `@Secured`, `SecurityConfig` role constants
- ASP.NET: `[Authorize(Roles = "...")]`, `IdentityRole` seed data
- Java EE: `@RolesAllowed`, `web.xml` `<security-role>` / `<auth-constraint>`
- ColdFusion: `<cfif session.user.role EQ ...>`, `Application.cfc onRequestStart`
- Rails/Django/Flask: decorators, Pundit/CanCan policies
- UI guards: React `<ProtectedRoute role=>`, Angular `canActivate`, Vue `meta.roles`
- Each role = persona candidate. Estimate users from session tables, audit logs, `last_login`.

## Entry Points (route tables)
- HTTP: controller annotations, `routes.rb`, `urls.py`, OpenAPI `paths`
- Batch: cron, `@Scheduled`, Quartz, Autosys JIL, DBMS_SCHEDULER
- Forms/portals: `<form action=>` targets, portal home manifests
- Reports: Jasper/Crystal/SSRS/Oracle Reports `.rdf`

## Accessibility Baseline (markup)
- Scan templates for `aria-*`, `<img alt=>` coverage, `<label for=>` to `<input>` ratio, heading hierarchy, `tabindex`, `role=` landmarks
- Features: skip-links, focus traps, keyboard handlers
- Report as ratios ("72% alt coverage") with `{file}:{line}` sample. Never emit `compliance_score` without evidence — use `null` plus open question.

## Business Criticality (ops artifacts)
- SLA: Nagios/PagerDuty rules, Datadog SLOs, doc uptime (`99.9%`, `24x7`, `mission-critical`)
- ATO: authorization tier, FIPS 199 (High/Moderate/Low), FedRAMP boundary
- Code: retry policies, circuit breakers, HA configs, multi-AZ
- Rule of three: `high` requires one of {ATO High, SLA >= 99.9%, explicit mission-critical label}. Fewer = `medium`. Zero signals on a production app = open question, not `low`.

## Mainframe variants
JCL `//STEPNAME`, CICS `TRANID` in `CSD`, IMS PSBs, DD dataset names, NATURAL FSEC groups.
