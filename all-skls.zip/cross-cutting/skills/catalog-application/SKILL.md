---
name: catalog-application
description: >
  Produce a standardized catalog entry for each discovered application per schemas/discovery/application-catalog-entry.schema.json. Captures business domain, tech stack, size metrics, data entities, operations, integrations, auth model, user context, 508 baseline, business criticality. Triggers on catalog application, application catalog, @catalog-application, or Discovery Step 2 mentions.
agent: opus
allowed-tools:
  - Read
  - Write
  - Grep
  - Bash
---

# Catalog Application

## Purpose
Produce the standardized application catalog entry that turns a raw repository into structured, comparable portfolio metadata. Every downstream Discovery step, Rationalization disposition call, Architecture pattern choice, and Data domain mapping keys off fields in this entry. Extract user context and business criticality autonomously from code artifacts (auth roles, UI routes, SLA configs, uptime references); flag gaps as open questions rather than guessing.

## Inputs
- Source code repository (Git URL or local path) for the application being cataloged
- Tech fingerprint from Discovery Step 1 (JSON per `schemas/discovery/tech-fingerprint.schema.json`)
- IaC templates (Terraform, CloudFormation, Ansible) if available
- CI/CD pipeline configs (Jenkins, GitHub Actions, Azure DevOps) if available
- CMDB export row for the application (hosts, datastores, owners) if available
- Existing operational docs, runbooks, SLA agreements, ATO packages from Service Transition (ST.1) if available
- Client profile (`profiles/<client>/profile.yaml`) for domain vocabulary and criticality thresholds

## Outputs
- Application catalog entry (YAML or JSON) validating against `schemas/discovery/application-catalog-entry.schema.json`
- Filled template shape in `assets/catalog-entry-template.yaml` — the canonical skeleton this skill populates
- Open-question list embedded in the entry's `open_questions[]` field — each item references the missing evidence by `{file}:{line}` where a heuristic signal was inconclusive
- Proposed complexity tier (Simple/Moderate/Complex) derived from `size_metrics` for the post-catalog classification checkpoint

## Methodology
1. Load the tech fingerprint from Step 1 and the client profile. Use the fingerprint's `primary_language`, `framework`, `archetype`, and `database` to seed the `technology_stack[]` array — do not re-detect what Step 1 already resolved.
2. Compute `size_metrics`: total LOC, per-language breakdown, module count (from the decomposition map if present, otherwise top-level source directories), API endpoint count (route definitions + OpenAPI + controller annotations), database table count (DDL + migrations + ORM models), test file count, and estimated test coverage (from coverage reports if present; otherwise `test_files / source_files` ratio with an explicit note).
3. Extract data entities from ORM models, DDL, and dominant nouns in service/repository class names. Mark `source_of_truth` as `yes` for entities whose primary CRUD sits in this app, `shared` for entities read/written across multiple apps, `no` for entities this app only reads from an upstream system.
4. Extract business operations from controller/service method names, route handlers, batch job entry points, and CLI commands. Each operation names the entities it acts on.
5. Enumerate external integrations: scan HTTP clients, SOAP stubs, MQ producers/consumers, file watchers, SFTP configs, JDBC connection strings pointing to databases owned by other apps. Record `system`, `interface_type`, `direction`, and `purpose`.
6. Identify the authentication model from auth middleware, filter chains, security configs, and identity-provider references (OAuth client configs, SAML SP metadata, JWT validators, LDAP bind configs). Populate `authentication.method` and `authentication.description`.
7. Run the autonomous user-context extraction pass per `references/autonomous-extraction-heuristics.md`: derive personas from auth roles and route guards, entry points from UI route tables and API specs, accessibility baseline from ARIA/alt/label signals in templates, and business criticality from SLA configs, uptime references, and ATO tier.
8. Where the heuristic evidence threshold is not met, emit an open question per `references/open-question-patterns.md` — never infer criticality or persona from business-domain stereotypes alone.
9. Record notable characteristics: compliance-relevant features (PII handling, FedRAMP boundaries, CUI markings), unusual legacy patterns (custom session stores, homegrown ORMs, inline SQL assembly), and anomalies flagged during scan.
10. Validate the produced document against `schemas/discovery/application-catalog-entry.schema.json` and hand off.

## Tech-Stack Dispatch
Catalog extraction runs on every archetype, but the evidence surfaces differ. Dispatch on the tech fingerprint's `archetype` and `primary_language`:

| Trigger | Reference file | Key patterns |
|---|---|---|
| `archetype == web-app` and UI templates present | `references/autonomous-extraction-heuristics.md` (UI section) | Route tables, auth role attributes, ARIA markers, template engines (Thymeleaf, JSP, Razor, ERB, CFML) |
| `archetype == batch-etl` or `scheduled-job` | `references/autonomous-extraction-heuristics.md` (batch section) | Cron expressions, DBMS_SCHEDULER, Quartz jobs, Spring `@Scheduled`, Autosys/Control-M JIL |
| `archetype == api-service` with OpenAPI/WSDL | `references/autonomous-extraction-heuristics.md` (API section) | OpenAPI `paths`, WSDL `operation`, gRPC `.proto`, auth scopes, rate-limit configs |
| `primary_language in {cobol, natural}` | `references/autonomous-extraction-heuristics.md` (mainframe section) | JCL step names, CICS transaction IDs, IMS PSBs, program-to-dataset bindings |

Detection must be mechanical — route to the section whose trigger unambiguously matches the fingerprint.

## Gotchas
- **Catalog is not analysis.** This skill produces structured inventory, not architectural findings. Do not try to extract business rules, coupling metrics, or readiness scores here — those belong to `analyze-application`. Keep the entry focused on the schema fields.
- **Tech-fingerprint trust, not re-detection.** Step 1's tech fingerprint is the authoritative source for language, framework, and archetype. Re-detecting inflates cost and invites contradictions between the two artifacts. Import and verify, do not overwrite.
- **Business criticality is a code-signal-plus-confirmation pair, not a guess.** A "high" rating from the autonomous pass is provisional until confirmed by stakeholders at the Discovery Complete gate. Always populate `user_context.business_criticality.confirmed_by` as empty until the stakeholder signs off; the presence of evidence is not the same as confirmation.
- **Personas are extracted from code, not imagined from domain.** Derive personas from auth roles, route guards, `@Role`/`@Secured`/`@PreAuthorize` annotations, and UI navigation gating — not from assumptions about who "would use" a billing system. If no role evidence exists, flag as open question.
- **508 baseline requires actual markup inspection.** Skipping this to a generic "unknown" is a failure — run the heuristic extraction (ARIA attributes, alt text coverage, form label ratio) even when no formal audit exists, and cite the scan ratio as evidence.
- **Integration direction matters for wave planning.** `in`, `out`, `both` are not interchangeable. A reverse-direction mistake corrupts the dependency graph that Step 4 builds on. Trace each integration to a consumer-vs-producer code signature.
- **Open questions are first-class outputs.** A catalog entry with zero `open_questions[]` on a legacy app is a red flag — it almost always means the agent guessed. Empty open-question lists require an explicit justification per `references/open-question-patterns.md`.

## Quality Rules
- [ ] Catalog entry validates against `schemas/discovery/application-catalog-entry.schema.json` with no schema errors
- [ ] `application.archetype` matches the `archetype` value in the Step 1 tech fingerprint — zero drift between the two artifacts
- [ ] `technology_stack[]` contains entries for at least `language`, `framework`, and `database` layers unless the fingerprint explicitly asserts absence
- [ ] Every item in `external_integrations[]` has a non-empty `direction` (`in`/`out`/`both`) derived from a code signature, cited as `{file}:{line}` in the evidence notes
- [ ] Every persona in `user_context.personas[]` traces to an auth role, route guard, or UI navigation gating cited as `{file}:{line}`
- [ ] `user_context.business_criticality.rating` is accompanied by an `evidence` string that quotes or cites the source signal (SLA doc, uptime config, ATO tier)
- [ ] `user_context.accessibility_baseline.compliance_score` is either a numeric estimate with a cited scan method or explicitly `null` with an open question recorded
- [ ] `open_questions[]` is non-empty OR contains a single sentinel entry explaining why no stakeholder input is required
- [ ] `size_metrics.estimated_test_coverage` is present for every non-zero `size_metrics.test_files` value — missing coverage on present tests is a failure
- [ ] All artifact citations use the `{artifact}:{section}:{finding-id}` format and all file citations use `{file}:{line}` format

## Common Failure Modes
| Failure Mode | Symptom | Prevention |
|---|---|---|
| Persona invention from domain stereotype | Catalog lists "Billing Clerk" and "Manager" personas on an app with no role annotations and no route guards | Require every persona to cite `{file}:{line}` evidence from an auth role or route guard; otherwise flag as open question |
| Criticality guessed from business domain name | `business_criticality.rating = high` on a "safety-of-flight" app with no SLA config or ATO tier evidence | Populate `evidence` with a concrete code or doc signal; if none exists, set rating to `null` and record open question |
| Integration direction reversed | Dependency graph shows App-A calling App-B when code shows App-B calling App-A; wave plan becomes invalid | Trace each integration to a consumer-vs-producer code signature (HTTP client vs. controller, MQ producer vs. listener) before recording `direction` |
| Tech fingerprint ignored, re-detection drift | Catalog `archetype = api-service` while fingerprint said `web-app`; downstream skills load the wrong patterns | Always import the Step 1 fingerprint; never re-detect language/framework/archetype inside this skill |
| Empty open-questions on a legacy app | `open_questions[]` empty on a 20-year-old ColdFusion app with no runbook or SLA docs | Require an explicit justification when the list is empty; treat a missing runbook or ATO package as a default open question |
| Accessibility defaulted to `unknown` | `accessibility_baseline` left null with no scan attempted | Run the markup heuristic (ARIA/alt/label ratio) on UI templates even when no formal audit exists; cite the ratio as evidence |

## Handoff Summary
When this skill completes, verify:
1. The catalog entry validates against `schemas/discovery/application-catalog-entry.schema.json` and imports the Step 1 tech fingerprint without field drift.
2. Every persona, integration, and criticality rating has a `{file}:{line}` evidence citation or a corresponding entry in `open_questions[]`.
3. A proposed complexity tier (Simple/Moderate/Complex) is recorded from `size_metrics` for the Initial Complexity Classification checkpoint.
4. `open_questions[]` is either populated with stakeholder-input prompts or carries a sentinel entry justifying emptiness.

Then proceed to: `analyze-application` (Discovery Step 3, 4-pass deep analysis) using this catalog entry as the scope definition, and the Initial Complexity Classification internal checkpoint for dispatch-tier assignment before entering gate `G-DC` at the end of Discovery.
