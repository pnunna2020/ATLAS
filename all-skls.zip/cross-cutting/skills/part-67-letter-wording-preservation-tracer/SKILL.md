---
name: part-67-letter-wording-preservation-tracer
description: >
  Trace every 14 CFR Part 67 prescribed-letter-wording string from
  source (Word template, `.aspx` markup, PL/SQL package body,
  hard-coded C# / VB.NET string, resource `.resx` file) to its
  regulatory authority at the phrase grain. Output becomes a
  must-preserve-verbatim contract for modernization: any paraphrase
  of regulator-prescribed text is a compliance violation, and the
  modernized system's letter-generation service must emit each
  traced phrase byte-identically. `word-template-extractor` extracts
  the Word templates; `compliance-citation-mapper` maps citations;
  neither links prescribed-wording phrases to their CFR authority at
  the phrase grain. Runs as a Discovery conditional skill when the
  app is tagged for 14 CFR Part 67 compliance. Triggers on Part-67
  wording inventory, prescribed-letter preservation analysis, or
  @part-67-letter-wording-preservation-tracer.
agent: sonnet
allowed-tools:
  - Read
  - Write
  - Grep
  - Glob
validation_commands:
  - "python -m olympus.validators.schema_validator part-67-wording-inventory.json"
  - "python -m olympus.validators.schema_validator part-67-phrase-authority-graph.json"
  - "python -m olympus.validators.schema_validator part-67-preservation-contract.json"
supported_stacks:
  - word-templates
  - docx
  - doc
  - aspnet-webforms
  - csharp
  - vbnet
  - plsql
  - resource-files
anti_target_stacks:
  - non-faa
  - no-letter-generation
  - static-site
failure_classes:
  - phrase-normalized-on-extraction
  - cfr-section-missed-at-phrase-grain
  - cross-app-phrase-divergence-unflagged
  - whitespace-stripped
  - html-encoding-variance-merged
  - template-vs-runtime-string-conflated
benchmark_tags:
  - discovery-compliance
  - part-67-wording-preservation
  - regulatory-phrase-tracing
  - letter-generation-contract
---

# part-67-letter-wording-preservation-tracer

## Purpose
For every 14 CFR Part 67 letter type — denial, clearance,
suspension, revocation, follow-up, conditional issuance —
enumerate the prescribed phrases, trace each to its CFR section
of origin, and capture every on-disk location where that phrase
is authored (template, page, code, procedure, resource). The
modernized letter-generation service carries a hard contract:
every traced phrase must emit byte-identically. Paraphrase =
compliance violation.

## Inputs
- Per-app `word-template-extractor` outputs
  (`word-template-inventory.json`, `word-merge-field-manifest.json`,
  `word-conditional-logic.json`) for every AAM-suite app.
- `compliance-citation-mapper` output (`citation-validation.json`).
- Application source directories, especially `Letters/`,
  `docs/WordDocuments/`, `Correspondence/`, `.resx` files, and any
  PL/SQL package bodies that assemble letter text.
- Client-profile regulatory taxonomy identifying which citations
  reference prescribed-wording CFR sections.
- Optional: FAA canonical letter templates (when available as
  source material) for parity comparison.

## Outputs
- `part-67-wording-inventory.json` — per phrase: `{phrase_id,
  phrase_text, phrase_hash (sha256), source_locations[] (app,
  file, line, surrounding_context), letter_type (denial |
  clearance | suspension | revocation | follow_up | conditional |
  other), cfr_authority (section, clause)}`.
- `part-67-phrase-authority-graph.json` — per CFR section: which
  phrases cite it, which apps implement those phrases.
- `part-67-preservation-contract.json` — consolidated per-letter-type
  contract: every phrase required in every letter of that type,
  grouped by app. Consumed by target-side letter-generation
  modernization as a byte-identical-output contract.

## Methodology
1. **Enumerate Word templates.** Read
   `word-template-inventory.json` + `word-merge-field-manifest.json`.
   For each template, extract every static text span (non-field,
   non-conditional-branch text).
2. **Enumerate in-code letter text.** Grep source (`.cs`, `.vb`,
   `.aspx`) for large literal string blocks whose content matches
   letter-language signatures (e.g., starts with "You are hereby
   notified" / "Your medical certificate has been" / "Pursuant to
   14 CFR §67."). Include `.resx` resource-file entries.
3. **Enumerate PL/SQL letter-assembly.** In packages like
   `PKG_MX_ADE_EMAIL` or similar, locate string concatenation
   producing letter bodies. Grep for `||` concatenation of long
   literal strings; capture the assembled output where traceable.
4. **Normalize for hashing, NOT for output.** For dedup keying, use
   a normalization that strips whitespace and HTML encoding. For
   the preserved phrase in `phrase_text`, preserve original
   whitespace, punctuation, HTML entities, and line breaks verbatim.
5. **Classify letter type.** Match each template / code block to a
   letter type based on filename, context, CFR citation, and
   triggering condition (denial paragraph vs clearance paragraph).
6. **Link phrase to CFR authority.** For each phrase, cross-reference
   `citation-validation.json` to find CFR sections quoted or
   paraphrased in the phrase. A phrase directly quoting `14 CFR
   §67.103` carries authority strength `verbatim`; a phrase
   substantively paraphrasing it carries `paraphrase`; a phrase
   operationally implementing a section without quoting carries
   `implementation`.
7. **Detect cross-app divergence.** For phrases that appear in
   multiple apps (e.g., denial paragraph in CPDSS, CHAPS, and
   AMCS), compute pairwise hash equality. Any divergence is a
   compliance finding — which version is authoritative must be
   adjudicated.
8. **Emit preservation contract.** Per letter type, consolidate the
   required phrases. The contract is the modernization target's
   byte-identical-output requirement.

## Tech-Stack Dispatch

No external references.

## Gotchas
- **Whitespace matters.** A regulatorily-prescribed phrase with
  a specific paragraph break cannot be collapsed to a single line
  during extraction; preserve original whitespace.
- **HTML encoding matters.** `&amp;` vs `&` vs the literal `&`
  character can differ across apps even for the same phrase.
  Preserve original encoding; dedup on normalized hash.
- **Conditional inserts are part of the phrase.** An `{IF}` field in
  a Word template that inserts "medical certificate" vs "student
  pilot certificate" based on applicant type produces two phrase
  variants — capture both.
- **CFR section at phrase grain.** `compliance-citation-mapper`
  cites at file grain; this skill must cite at phrase grain. A
  single file often contains phrases from multiple sections.
- **Template vs runtime divergence.** A template's authored text
  may differ from the runtime-rendered output due to merge fields
  + mail-merge expansion. Trace both: template-time and render-time.
- **Cross-app divergence is a finding, not a bug to fix here.**
  Emit the divergence; the decision (which version wins) is a
  human governance call.
- **Historical wording drift.** Regulatory text updates over
  revisions; an older letter template may reference an outdated
  section number. Flag as `potentially_obsolete_citation`.
- **Language localization.** English is the authoritative regulatory
  language; any translated versions are operational copies, not
  authoritative. Record locale per phrase.
- **Legal-record status interaction.** A phrase preserved in this
  contract AND present in a `system_of_record` app carries
  additional NARA preservation obligation beyond modernization
  byte-parity.
- **Target-side testability.** The preservation contract must be
  machine-checkable at modernized-system acceptance test time —
  output the phrase hash per letter type so acceptance tests can
  assert byte-identical output.

## Quality Rules
- [ ] Every phrase from Word template, `.aspx`, code literal,
      `.resx`, and PL/SQL letter-assembly is in the inventory.
- [ ] Every phrase carries hash + every source location with
      `{repo}:{file}:{line}`.
- [ ] Letter-type classification is populated per phrase.
- [ ] CFR authority linked per phrase when resolvable; otherwise
      `authority: unknown`.
- [ ] Cross-app divergence findings emitted.
- [ ] Whitespace and HTML encoding preserved verbatim in
      `phrase_text`.
- [ ] Preservation contract is consumable by target-side acceptance
      tests (hash + expected text per letter type).

## Common Failure Modes

| Failure Mode | Symptom | Prevention |
|---|---|---|
| Whitespace stripped | Extract reports phrase as single line but template has paragraph break | Preserve whitespace in phrase_text; normalize only for hash |
| HTML encoding merged | `&amp;` and `&` treated as same phrase | Use normalized hash for dedup but preserve original in phrase_text |
| Conditional variant dropped | IF-true and IF-false branches merged into single phrase | Emit one phrase per conditional branch |
| CFR section at file grain | Every phrase in `DenialLetter.aspx` cited to same section | Analyze each phrase independently |
| Cross-app divergence ignored | CPDSS and CHAPS have subtly different denial paragraphs; manifest shows single phrase | Compute pairwise hashes; emit divergence as finding |

## Handoff Summary
When this skill completes, verify:
1. Every prescribed phrase across every AAM-suite app is
   inventoried with source locations.
2. CFR authority linked at phrase grain.
3. Cross-app divergence findings emitted for pairs with matching
   identity but mismatching hashes.
4. Preservation contract is machine-checkable via phrase hash.

Then proceed to: `compliance-citation-mapper` (Rationalization
primary) — which consumes the phrase-to-CFR graph to enrich
citation-validation artifacts; `cato-compliance` (Compliance phase)
— which validates the modernized system against the preservation
contract; `module-design` — which shapes the target letter-
generation service to carry the phrase hash for acceptance
verification.

## References
None — logic inline.

## Changelog
- 0.1.0 (2026-05-08) — Initial skill. Authored as FAA-proposal-P2
  (see `docs/testing/faa-proposal-skill-assessment.md` Section 9).
