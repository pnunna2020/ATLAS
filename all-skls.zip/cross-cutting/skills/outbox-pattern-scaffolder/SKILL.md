---
name: outbox-pattern-scaffolder
description: Generate transactional outbox + dispatcher for at-least-once event emission tied to DB transactions; emits to a pluggable event-bus adapter (LISTEN/NOTIFY local, EventBridge AWS).
phase: generate
category: modernization
status: stub-2026-05-27
maturity: minimal
inputs:
  - event-catalog.json
  - storage-strategy.yaml      # pg (default), mysql, postgres-citus
outputs:
  - apps/api/src/domain/services/event-dispatcher.ts
  - apps/api/src/handlers/<bc>/handlers/on-<event>.ts
  - db/migrations/<n>_outbox.sql
contract_invariants:
  - "Event row written in same DB transaction as aggregate state change"
  - "Dispatcher is idempotent — keyed by event_id"
  - "Failed dispatch increments retry_count; 5+ moves to dead-letter; alert fires"
  - "Outbox table has (published_at IS NULL) partial index for fast unpublished-scan"
related_skills:
  - sse-broadcaster-scaffolder
  - local-cloud-adapter-scaffolder
  - data-modeling
---

# outbox-pattern-scaffolder

## Purpose

Generate the transactional outbox infrastructure — table, dispatcher, per-event handlers — that lets a service emit domain events as part of the same DB transaction as the state change. Used by ATLAS Phase 3 prototype for event-driven coupling between bounded contexts.

## Outputs

```
apps/api/src/
├── domain/services/event-dispatcher.ts        # outbox poll/notify dispatcher
├── handlers/<bc>/handlers/on-<event>.ts       # event handler stubs
db/migrations/<n>_outbox.sql                   # event_outbox table + indexes
```

## Contract enforcement

- **Same-tx check**: contract test asserts state change + outbox INSERT in single tx.
- **Idempotency**: dispatcher dedups by event_id; replay test verifies no double-emit.

## Phase 3 prototype usage

- `apps/api/src/domain/services/event-dispatcher.ts`
- `apps/api/src/handlers/medical/handlers/on-medical-submitted.ts`
- `db/migrations/0003_outbox.sql`

## Status

**STUB — 2026-05-27.** Full Phase 4.
