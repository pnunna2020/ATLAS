# Composite Overlap Score — Methodology

Composite overlap between an application pair is a weighted sum of four dimension scores produced upstream by `redundancy-analyzer` and `analyze-portfolio-redundancy`. This skill weights those dimensions; it does not recompute them.

## Formula

```
composite = (w_entity     * entity_pct)
          + (w_operation  * operation_pct)
          + (w_technology * technology_pct)
          + (w_persona    * persona_pct)
```

Dimension scores are in [0, 100]. Weights sum to 1.0. Result is bounded to [0, 100] and reported to one decimal.

## Default Weights

Use when no active profile supplies overrides:

| Dimension      | Weight | Rationale |
|----------------|--------|-----------|
| entity_pct     | 0.30   | Shared entities drive SoT conflicts and merge cost |
| operation_pct  | 0.30   | Duplicate operations are the clearest consolidation signal |
| technology_pct | 0.15   | Shared stack lowers merge cost but is not itself redundancy |
| persona_pct    | 0.25   | Same-user-base evidence is required for the consolidation bar |

Record the weight set id (`default` or profile id) in the narrative so runs are reproducible.

## Profile Overrides

Active profiles may override defaults when domain emphasis differs. Load overrides from the profile's scoring config. For FAA, see `profiles/faa/scoring.yaml` — FAA elevates `architecture-clarity` and `security-posture`, which implies a companion override raising `entity_pct` to reflect shared-Oracle-database coupling. Apply overrides only when the profile declares a redundancy-weights block; otherwise use defaults.

## When to Override

- Profile declares redundancy composite weights.
- Uniform tech stack — reduce `technology_pct`, redistribute to entity/operation.
- Domain mandate elevates persona overlap — raise `persona_pct`.

Do not override per-pair. Weights apply uniformly to the run; per-pair tuning invalidates cross-portfolio comparison.
