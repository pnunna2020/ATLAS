# Schema Conformance Rules

Every run must validate against `schemas/rationalization/redundancy-matrix.schema.json`. The schema sets `additionalProperties: false` on every object, so extra keys fail the whole artifact.

## Required Top-Level Keys
- `metadata`, `entity_overlap`, `operation_overlap` — required
- `high_overlap_pairs`, `data_sot_conflicts`, `consolidation_candidates` — optional; emit when evidence exists

## metadata
- `generated_date` — ISO date `YYYY-MM-DD`
- `applications_analyzed` — integer, minimum 2
- `analyst` — non-empty string

## entity_overlap / operation_overlap rows
- Required: `app_1`, `app_2`, `overlap_percentage`
- `overlap_percentage` in [0, 100]
- Optional: `shared_entities` / `shared_operations` (string arrays)
- No other keys permitted

## high_overlap_pairs rows
- Required: `app_1`, `app_2`, `entity_overlap`, `operation_overlap`
- Percentages in [0, 100]
- Include every pair whose composite overlap exceeds 50%

## data_sot_conflicts rows
- Required: `entity`, `app_a`, `app_b`, `conflict_type`
- `conflict_type` enum: `semantic_mismatch | schema_conflict | dual_master`
- Optional: `app_a_definition`, `app_b_definition`, `recommended_sot`

## consolidation_candidates rows
- Required: `group_name`, `applications`, `shared_capability`, `recommendation`
- `applications` array minItems 2
- `recommendation` enum: `merge | shared_service | data_sot`
- `shared_capability` is a single label, not a sentence

## Citation Format
Narrative claims use:

```
{artifact}:{section}:{finding-id}
```

Examples:
- `redundancy-analyzer-report.md:entity-overlap:EO-0142`
- `portfolio-redundancy.json:consolidation-candidates:CC-007`

## Bounds
- Percentages: 0 <= x <= 100
- `applications_analyzed`: integer, x >= 2
- `metadata.analyst`: minLength 1

Reject any violation before writing. Partial matrices must not ship.
