---
name: generate-redundancy-matrix
description: >
  Emit the schema-conformant redundancy-matrix.json artifact from upstream redundancy-analyzer and analyze-portfolio-redundancy findings. Output per schemas/rationalization/redundancy-matrix.schema.json. Enforces same-CAPABILITY-same-USER-BASE consolidation bar. Triggers on redundancy matrix generation, consolidation artifact, or @generate-redundancy-matrix.
agent: sonnet
allowed-tools:
  - Read
  - Write
  - Grep
---

# generate-redundancy-matrix

## Purpose
Shape upstream redundancy-analysis outputs into a single schema-valid `redundancy-matrix.json` artifact that downstream skills (`disposition-recommender`, `wave-planner`) can consume without re-interpretation. This skill does not perform net-new analysis — the entity, operation, UX, and persona overlap work has already been completed by `redundancy-analyzer` and `analyze-portfolio-redundancy`. Its value is schema conformance, composite-score discipline, and carrying the same-CAPABILITY-same-USER-BASE consolidation bar from analysis into the canonical artifact.

## Inputs
- Entity overlap matrix produced by `redundancy-analyzer` (pairs with shared entities and overlap percentages)
- Operation overlap matrix produced by `redundancy-analyzer` (pairs with shared operations and overlap percentages)
- UX overlap matrix from `redundancy-analyzer` (Persona × Task × Apps for swivel-chair detection)
- Portfolio-scale redundancy scoring from `analyze-portfolio-redundancy` (composite overlap per pair)
- Application capability models from P0.3 / 4-pass analysis reports (business capability sections)
- Data source-of-truth inventory (authoritative store per entity, if produced upstream)
- Downstream integration graph (app-to-app dependencies) for consolidation-impact assessment
- Active client profile scoring weights (e.g., `profiles/faa/scoring.yaml`) for composite weighting overrides

## Outputs
- Canonical redundancy matrix → `schemas/rationalization/redundancy-matrix.schema.json`
- Matrix skeleton to fill per run → `assets/redundancy-matrix-template.json`
- Narrative consolidation opportunity report → `assets/consolidation-recommendation-template.md`
- Composite score methodology with defaults and profile overrides → `references/composite-score-methodology.md`
- Schema-conformance rules governing required fields, enums, citations, and bounds → `references/schema-conformance-rules.md`

## Methodology
1. Load upstream analysis outputs from `redundancy-analyzer` and `analyze-portfolio-redundancy` and confirm both are fresh (analysis date within 90 days).
2. Initialize a matrix object from `assets/redundancy-matrix-template.json` and populate `metadata.generated_date`, `metadata.applications_analyzed`, and `metadata.analyst` per schema requirements.
3. Copy entity-overlap pair rows into `entity_overlap[]`, preserving `app_1`, `app_2`, `overlap_percentage`, and `shared_entities` exactly as produced upstream — do not recompute percentages.
4. Copy operation-overlap pair rows into `operation_overlap[]` using the same discipline; reject rows missing `overlap_percentage` rather than inventing values.
5. Compute the composite overlap score per pair from the four dimension scores (entity%, operation%, technology%, persona%) using `references/composite-score-methodology.md` defaults, overridden by active profile weights when present.
6. Promote every pair whose composite or entity overlap exceeds 50% into `high_overlap_pairs[]`, carrying the underlying entity and operation percentages and the shared-entities list.
7. Assemble `data_sot_conflicts[]` from the source-of-truth inventory, classifying each conflict as `semantic_mismatch`, `schema_conflict`, or `dual_master` per schema enum and recording a `recommended_sot` when upstream evidence supports one.
8. Build `consolidation_candidates[]` only for pairs or groups that satisfy the same-CAPABILITY-same-USER-BASE bar; select `recommendation` from `merge`, `shared_service`, or `data_sot` based on upstream evidence of user-base overlap and data dependencies.
9. For every candidate group, generate a narrative using `assets/consolidation-recommendation-template.md` with overlap dimensions, same-user-base evidence, data dependencies, downstream integration impact, recommendation, and confidence.
10. Validate the output against `schemas/rationalization/redundancy-matrix.schema.json` and resolve every violation before handoff — a partial matrix is not acceptable.

## Gotchas
- **This skill does not re-analyze.** Composite scores must trace back to upstream overlap matrices. Recomputing entity or operation percentages in this skill breaks lineage and the audit trail downstream consumers depend on.
- **Schema `additionalProperties: false` is strict.** Extra fields on any object silently invalidate the whole artifact. Populate only the fields named in `schemas/rationalization/redundancy-matrix.schema.json`.
- **Same-CAPABILITY without same-USER-BASE is not a consolidation candidate.** Both sister skills enforce this; `consolidation_candidates[]` must honor it. Pairs with high overlap but different user communities belong in `high_overlap_pairs[]` with an investigation note, not in candidates.
- **`conflict_type` and `recommendation` are enums.** Free-text values fail validation. Use `semantic_mismatch | schema_conflict | dual_master` for conflicts and `merge | shared_service | data_sot` for consolidation recommendations.
- **Citations are required on every narrative claim.** The narrative template expects `{artifact}:{section}:{finding-id}` citations; handoff reviewers reject narratives whose claims cannot be traced back to upstream reports.
- **Composite weights drift silently without a profile source.** If no active profile is loaded, default to the weights in `references/composite-score-methodology.md` and record the weight set used in the narrative so downstream scoring is reproducible.

## Quality Rules
- [ ] Output validates against `schemas/rationalization/redundancy-matrix.schema.json` with zero schema errors.
- [ ] `metadata.generated_date`, `metadata.applications_analyzed` (>=2), and `metadata.analyst` are all populated.
- [ ] Every pair row in `entity_overlap[]` and `operation_overlap[]` includes source citations in `{artifact}:{section}:{finding-id}` format in the accompanying narrative.
- [ ] Composite scores match the documented weighting methodology in `references/composite-score-methodology.md` (or the active profile override) — no ad-hoc weights.
- [ ] Same-CAPABILITY-same-USER-BASE bar is enforced on every entry in `consolidation_candidates[]`; candidates lacking user-base evidence are demoted to `high_overlap_pairs[]`.
- [ ] Every pair with composite overlap greater than 50% appears in `high_overlap_pairs[]` — no silent omissions.
- [ ] `data_sot_conflicts[].conflict_type` values use only `semantic_mismatch | schema_conflict | dual_master`; `consolidation_candidates[].recommendation` uses only `merge | shared_service | data_sot`.
- [ ] `consolidation_candidates[].applications` contains at least two applications and the shared capability is named explicitly.
- [ ] Percentages across entity, operation, and high-overlap sections fall within the 0-100 bounds required by the schema.
- [ ] Narrative consolidation opportunity report accompanies the JSON matrix and uses `assets/consolidation-recommendation-template.md`.

## Common Failure Modes
| Failure Mode | Symptom | Prevention |
|---|---|---|
| Schema validation skipped | Matrix ships with extra fields or missing required keys; downstream `disposition-recommender` and `wave-planner` error on load | Run schema validation as the final step of every run and block handoff on any violation |
| Composite weights ad-hoc instead of per methodology doc | Scores vary across runs for the same inputs; portfolio comparisons are not reproducible | Always source weights from `references/composite-score-methodology.md` or the active profile; record the weight set used in the narrative |
| Same-CAPABILITY-same-USER-BASE bar dropped | `consolidation_candidates[]` includes pairs serving different user communities; false consolidations propagate downstream | Gate every candidate on documented user-base overlap evidence from upstream personas; demote unsupported pairs to `high_overlap_pairs[]` |
| Missing source citations | Narrative claims cannot be traced to upstream findings; gate reviewers reject the artifact | Require `{artifact}:{section}:{finding-id}` citations on every overlap dimension and recommendation in the narrative template |
| Recomputed instead of carried-over percentages | Matrix percentages disagree with the upstream entity/operation overlap matrices; lineage broken | Copy upstream percentages verbatim; this skill shapes, it does not re-analyze |
| Enum free-text values | `conflict_type` or `recommendation` populated with human phrases; schema validation fails on enum mismatch | Restrict values to the schema enums documented in `references/schema-conformance-rules.md` |

## Handoff Summary
When this skill completes, verify:
1. The output JSON validates cleanly against `schemas/rationalization/redundancy-matrix.schema.json`.
2. Every consolidation candidate passes the same-CAPABILITY-same-USER-BASE bar and cites upstream evidence.
3. Composite scores use the methodology doc (or active profile override) and the weight set is recorded in the narrative.
4. Every pair, conflict, and candidate row carries `{artifact}:{section}:{finding-id}` citations traceable to upstream reports.

Then proceed to: `disposition-recommender` (Rationalization Step 3) which consumes the matrix as consolidation evidence, and `wave-planner` which uses consolidation candidates to bundle modernization waves. Gate: `G-RR` (Rationalization Review) for rationalization-evidence completeness.
