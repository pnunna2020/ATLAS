# Consolidation Opportunity — TODO-group-name

Narrative companion to `redundancy-matrix.json` for a single candidate pair or group. Fill every section. Claims without `{artifact}:{section}:{finding-id}` citations are not acceptable.

## Candidate Pair / Group
- **Applications:** TODO-app-id-1, TODO-app-id-2 (add more for multi-app groups)
- **Shared capability:** TODO-capability-label
- **Group name in matrix:** TODO-group-name (must match `consolidation_candidates[].group_name`)

## Overlap Dimensions
| Dimension | Score | Evidence citation |
|---|---|---|
| Entity overlap | TODO-% | `{artifact}:{section}:{finding-id}` |
| Operation overlap | TODO-% | `{artifact}:{section}:{finding-id}` |
| UX / swivel-chair overlap | TODO-% | `{artifact}:{section}:{finding-id}` |
| Persona overlap | TODO-% | `{artifact}:{section}:{finding-id}` |
| Composite overlap | TODO-% | Weight set: TODO-default-or-profile-id |

## Same User Base Evidence
Document the personas, roles, or organizational units that use both applications. List citations to upstream persona inventories and UX overlap findings. If the user bases differ, this candidate must be demoted to `high_overlap_pairs[]` and consolidation must not be recommended.

- Persona / role: TODO — citation: `{artifact}:{section}:{finding-id}`
- Persona / role: TODO — citation: `{artifact}:{section}:{finding-id}`

## Data Dependencies
List authoritative data sources, shared stores, and any data-source-of-truth conflicts from `data_sot_conflicts[]`. Note whether the applications share an authoritative store, duplicate it, or disagree on definitions.

- Entity: TODO — authoritative store: TODO — citation: `{artifact}:{section}:{finding-id}`
- SoT conflict: TODO-entity — type: `semantic_mismatch | schema_conflict | dual_master`

## Downstream Integration Impact
List every downstream system that consumes data or events from either application. Note which integrations would require re-routing, contract changes, or replay under a consolidation scenario.

- Downstream system: TODO — impact: TODO — citation: `{artifact}:{section}:{finding-id}`

## Recommendation
Choose exactly one and justify:
- [ ] **Consolidate** — select schema `recommendation` value: `merge | shared_service | data_sot`. Requires same-CAPABILITY and same-USER-BASE evidence above.
- [ ] **Investigate** — overlap is high but user base, data, or downstream integration evidence is incomplete. Name the missing evidence.
- [ ] **No-action** — overlap is coincidental (different user bases, incompatible data contracts, or prohibitive downstream impact).

Rationale: TODO (two to four sentences grounded in the cited evidence).

## Confidence
- **Confidence level:** High | Medium | Low
- **Rationale:** TODO — tie to evidence completeness and freshness of upstream analysis.
- **Open questions for human reviewer:** TODO (bullet list, or "none").
