---
name: pilot-certification-domain-modeler
description: FAA-specific design skill that models the pilot certification domain (airman identity, medical, application, endorsement, checkride, AKTR, compliance) as a normalized Postgres schema with audit-ready immutability and §61.15 propagation.
phase: design
category: faa-modernization
status: stub-2026-05-27
maturity: minimal
inputs:
  - phase-2-rationalization.json
  - faa-form-catalog.json     # 8710-1 family + 8500-8 + 61.15 form set
  - cp4-target-architecture.json
outputs:
  - db/migrations/<n>_<entity>.sql
  - prototype/docs/contracts/data-model.md
contract_invariants:
  - "audit_event is append-only (CREATE RULE INSTEAD OF UPDATE / DELETE → NOTHING)"
  - "Every PII column has a documented retention rule"
  - "Cross-aggregate references are by canonical UUID; no FK cycles"
  - "Every certificate/endorsement row carries a 3-link attestation chain (SHA-256 → RSA-PSS → RFC 3161)"
related_skills:
  - data-modeling
  - faa-canonical-entity-modeler
  - cross-system-data-integration-designer
---

# pilot-certification-domain-modeler

## Purpose

Specialize generic data-modeling for the FAA pilot certification domain: 16 tables covering S1 Unified Pilot Identity, S2 Guided Intake, S6 Medical, S10 Compliance, with audit-event hash chain and §61.15 / §61.60 propagation.

## Outputs

16 SQL migrations:

| Migration | Entity | Anchor |
|---|---|---|
| `0001_init.sql` | airman_identity, application, audit_event | S1 + S2 + cross |
| `0002_journey.sql` | journey_state | FSM persistence |
| `0003_outbox.sql` | event_outbox | S3 substrate |
| `0004_medical_limitations.sql` | medical_limitations | S6 |
| `0005_logbook_entry.sql` | logbook_entry | S10 |
| `0006_immutability_triggers.ts` | audit append-only | cross |
| `0007_endorsement_unique.sql` | endorsement constraints | S10 |
| `0008_provisional_identity.sql` | provisional identities | S1 |
| `0009_gfi_provenance.sql` | CFI tracking | S5 |
| `0010_medical_submission_unique.sql` | medical PK | S6 |
| `0011_endorsement_pending_unique.sql` | endorsement uniqueness | S10 |
| `0012_airman_identity_idp_subject_unique.sql` | OIDC subject uniqueness | S1 |
| `0013_aktr_result.sql` | AKTR result | S10 |
| `0014_checkride_result.sql` | checkride result | S10 |
| `0015_workflow_run.sql` | Temporal run | S10 |
| `0016_application_intake.sql` | application intake | S2 |
| `0017_student_certificate.sql` | student cert | S10 |
| `0018_compliance_61_15.sql` | §61.15 self-report | S10 |
| `0019_medical_confirmation_number.sql` | MedXPress confirmation | S6 |
| `0020_application_intake_code.sql` | intake FK | S2 |

## Contract enforcement

- **Immutability**: `pgTAP` test verifies `INSERT` works but `UPDATE`/`DELETE` blocked on audit_event.
- **Hash chain**: integration test verifies prev_hash + row_hash chain across 1000-row insert.
- **Retention**: every PII column has a row in `retention_rules` table.

## Phase 3 prototype usage

All 20 migrations under `prototype/db/migrations/` produced by this skill.

## Status

**STUB — 2026-05-27.** Full Phase 4.

## Phase 4 expansion targets

- PTS / ACS / PTRS lookup tables (10+ tables)
- S7 Designee 84-table CP4 surface
- S8 Registry full cert-number allocator
- S9 PKI 17-table substrate
