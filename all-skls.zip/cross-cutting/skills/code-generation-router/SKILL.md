---
name: code-generation-router
description: >
  Resolve which generator skill should produce code for a given modernization
  task. Matches the tuple (primary_language, target_language, target_framework,
  risk_tier, confidence) against a deterministic routing table and per-stack
  fallback chain, returning a RouterDecision with skill_id + confidence, or
  escalating via a BLOCKING human gate when no candidate clears the confidence
  threshold. Paired with the code-side router at
  `olympus/olympus/agents/_generator_router.py` — this skill documents the
  decision protocol so the agent can reason about routing before dispatch.
  Registered as `generation.primary` so it fires on every Generation phase.
  Triggers on generator routing, code generation router, generator selection,
  primary-to-target language routing, or @code-generation-router mentions.
agent: sonnet
allowed-tools:
  - Read
  - Grep
  - Bash
validation_commands:
  - "python -c \"from olympus.agents._generator_router import select_generator, list_supported_pairs; print(list_supported_pairs())\""
  - "python -c \"import yaml, pathlib; yaml.safe_load(pathlib.Path('olympus/olympus/agents/_generator_router_fallbacks.yaml').read_text())\""
supported_stacks:
  - java
  - csharp
  - dotnet
  - vbnet
  - python
  - javascript
  - typescript
  - cobol
  - coldfusion
anti_target_stacks:
  - static-site
  - single-page-app-no-backend
failure_classes:
  - silent-best-of-worst-fallback
  - missing-generator-skill
  - unregistered-language-pair
  - pending-skill-dispatch
  - confidence-threshold-bypass
benchmark_tags:
  - generation-routing
  - router-confidence
  - router-escalation
---

# code-generation-router

## Purpose
Given the modernization inputs — the app's detected **primary language**, the
design's **target language** and **target framework**, the **risk tier**, and
a per-candidate **confidence** score — resolve the single generator skill that
will produce code for the app. The router is deterministic: no LLM voting, no
"closest match" heuristic. Either a candidate clears the confidence threshold
and is dispatched, or the router refuses to pick and escalates to a human
gate.

This skill is the meta-skill paired with the code-side router at
`olympus/olympus/agents/_generator_router.py` (function `select_generator`,
class `RouterDecision`, exception `RouterEscalation`). The router chooses
*which* concrete generator to run; the chosen generator — e.g.
`springboot-api-generation`, `dotnet-api-generation`, `fastapi-api-generation`,
`cobol-to-java-generator` — does the code-producing work.

Registered as `generation.primary`, it loads on every Generation phase so the
agent can narrate the decision and cite the RouterDecision before handing off
to the downstream generator skill.

## Decision Inputs

The router matches five factors, in priority order:

1. **primary_language** — the app's source language detected during Discovery
   (normalized via alias table: `c#` → `csharp`, `cfml` → `coldfusion`, etc.).
   REQUIRED.
2. **target_language** — the target language chosen during Design
   (e.g. `java`, `csharp`, `python`). REQUIRED.
3. **target_framework** — the target framework hint from Design
   (e.g. `spring-boot`, `asp.net-core`, `fastapi`). Optional; used for
   fine-grained scoring when a fallback chain entry specifies it.
4. **risk_tier** — `T1` | `T2` | `T3` from Rationalization. Not a router
   routing key today, but logged on every decision for observability; T1
   dispatches SHOULD be reviewed by a human even when the router returns a
   high-confidence match.
5. **confidence** — deterministic score in `[0.0, 1.0]` computed per
   candidate (not an LLM output):
   - `1.0` — language matches AND framework matches (or request has no
     framework hint and language matches).
   - `0.7` — language matches, framework differs.
   - `0.4` — wildcard framework entry (`framework: "*"`).
   - `0.0` — language does not match.

See `references/router-decision-protocol.md` for the full scoring table and
worked examples for c#, java, python, cobol→java, and unknown stacks.

## Confidence Threshold & Fallback

The router reads the confidence floor from the environment variable
`OLYMPUS_ROUTER_CONFIDENCE_THRESHOLD` at call time. The default is **0.6**
if the variable is unset or not a float.

Per-stack fallback chains live in
`cross-cutting/skills/_generator_router_fallbacks.yaml` (symlink/companion to
`olympus/olympus/agents/_generator_router_fallbacks.yaml` — the router loads
the latter at runtime). Each stack's chain is an ordered list: the first
entry is the primary, subsequent entries are fallbacks tried in order. The
router picks the FIRST candidate whose confidence `>=` the active threshold
and whose `(lang, target)` pair is registered in the router's primary
`_ROUTING_TABLE`.

If no candidate in the chain clears the threshold, the router does NOT fall
back to the best-of-worst candidate. It raises `RouterEscalation` so the
caller writes an Escalation row and opens a human gate.

## Escalation Protocol

Two failure modes end the run without generating code:

1. **No candidate clears the threshold** → raise `RouterEscalation`. The
   agent MUST:
   - Record a BLOCKING Escalation row with fields: `stack`, `target`,
     `framework`, `threshold`, full scored `candidates[]` list, and the
     reason string `"No generator in the fallback chain cleared the
     confidence threshold"`.
   - Halt the Generation phase for this app. Do not attempt to pick the
     highest-confidence (best-of-worst) candidate.
   - Hand off to the reviewer queue; the gate is released only after a
     human adds a matching row to `_ROUTING_TABLE`, creates the new
     skill under `cross-cutting/skills/`, and extends the fallback YAML.

2. **Router returns no candidate at all** (chain empty AND no legacy
   routing-table entry) → `UnsupportedGeneratorError`. Same Escalation
   row shape; the fix is identical (register the pair + add the skill).

3. **Chosen candidate is pending** (`built=False` in `_ROUTING_TABLE`) →
   `PendingGeneratorError`. This is a *known-gap* escalation: the pair
   is registered but the skill has not been authored yet. The reviewer
   creates the skill directory and flips `built=True`.

See `references/router-escalation-flow.md` for the exact Escalation row
schema, the reviewer workflow, and the post-resolution steps that cause
the router to re-dispatch automatically.

## Quality Rules
- [ ] Every generation-phase run logs the `RouterDecision` (skill_id,
      confidence, fallback_used, chain length) before invoking the
      downstream generator.
- [ ] `OLYMPUS_ROUTER_CONFIDENCE_THRESHOLD` is read at call time (not
      cached at import) so tests and ops can override per-run.
- [ ] `RouterEscalation` is ALWAYS caught and turned into a BLOCKING
      Escalation row — never swallowed, never converted to a "best-of-worst"
      dispatch.
- [ ] `PendingGeneratorError` is caught and turned into an Escalation row
      of type `pending-skill`; the fix is to author the missing skill, not
      to degrade to a different target.
- [ ] T1 risk-tier dispatches carry an additional review stamp even when
      the router returns confidence `1.0` — the router's confidence is
      correctness of *match*, not correctness of *output*.
- [ ] When a new `(primary_language, target_language)` pair is added, it
      is added to `_ROUTING_TABLE` in `_generator_router.py` AND the
      corresponding stack's entry in `_generator_router_fallbacks.yaml`
      AND a matching SKILL.md is created under `cross-cutting/skills/`.
- [ ] The router never silently substitutes a different target language
      (e.g. `java` when the design chose `csharp`) — fallback is within a
      stack, not across targets.

## Common Failure Modes
| Failure Mode | Symptom | Prevention |
|---|---|---|
| silent-best-of-worst-fallback | No candidate cleared threshold; pipeline nevertheless dispatched the top-scored candidate and produced non-target-stack code | Treat `RouterEscalation` as blocking; never pick `max(candidates, key=confidence)` when `chosen is None`. |
| missing-generator-skill | Router returns a skill_id whose SKILL.md does not exist; downstream agent can't load it | Every row in `_ROUTING_TABLE` MUST have a matching `cross-cutting/skills/<slug>/SKILL.md`. Validate via the repo's skill validator script and the skills-lock. |
| unregistered-language-pair | `UnsupportedGeneratorError` raised for a pair that a human expected to work (e.g. `perl` → `python`) | Add the pair to `_ROUTING_TABLE` with `built=False` first, then author the skill. The PendingGeneratorError message tells the caller exactly what to build. |
| pending-skill-dispatch | A pending (`built=False`) entry was dispatched because the check was skipped | Never bypass the `built` flag — the flag flips to True only after the skill is authored and validated end-to-end. |
| confidence-threshold-bypass | Someone set `OLYMPUS_ROUTER_CONFIDENCE_THRESHOLD=0.0` to "just make the pipeline work" | Threshold overrides are allowed but logged at WARN level. Code review rejects PRs that lower the threshold globally — per-test overrides are acceptable. |
| framework-mismatch-masked | ColdFusion app routed to `fastapi-api-generation` with framework hint `fastapi` scored 1.0 even though the primary stack is CF, not Python | The fallback YAML intentionally scores a CF-to-Python jump at framework-wildcard confidence (0.4); a design that wants CF→Python MUST set `target_language: python`, not rely on a framework hint. |
| threshold-cached-at-import | Test overrides for the env var had no effect because the value was captured once at module load | The router reads the env var inside `_default_threshold()` on every call; do not refactor that to a module-level constant. |

## Handoff Summary
When this skill has made a decision, verify:
1. A `RouterDecision` has been produced with `skill_id`, `confidence >=
   threshold`, `fallback_used`, and the full scored `fallback_chain`.
2. The chosen `skill_id` resolves to a present, built SKILL.md in
   `cross-cutting/skills/`.
3. If `fallback_used=True`, the reason is recorded in the run log with
   the full chain so reviewers can see which primary was skipped and why.
4. If the router raised `RouterEscalation` or `PendingGeneratorError`,
   NO generator skill was invoked and an Escalation row was written.

Then proceed to:
- The resolved generator skill (e.g. `springboot-api-generation`,
  `dotnet-api-generation`, `fastapi-api-generation`,
  `cobol-to-java-generator`) for code production.
- `tdd-generation` for the Ralph Loop that wraps the generator output.
- `gate G-04c` for generation quality review — the router decision is
  part of the gate package.

## Reference Files
- `references/router-decision-protocol.md` — the exact matching algorithm
  with scoring rules and worked examples for each supported stack.
- `references/router-escalation-flow.md` — what an Escalation row
  contains, how reviewers resolve it, and what happens when they
  register a new skill.
