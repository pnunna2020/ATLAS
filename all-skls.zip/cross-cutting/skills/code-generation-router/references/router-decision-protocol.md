# Router Decision Protocol

This file documents the exact matching algorithm used by
`olympus/olympus/agents/_generator_router.py` to resolve a generator skill
from `(primary_language, target_language, target_framework)` inputs. It is
the canonical reference for the `code-generation-router` skill.

## 1. Normalization

Every input token is lower-cased and de-aliased via `_LANGUAGE_ALIASES`
before lookup:

| Alias (any case) | Canonical |
|---|---|
| `c#`, `cs` | `csharp` |
| `.net`, `dotnet` | `dotnet` |
| `vb.net`, `vb`, `vbasic` | `vbnet` |
| `js`, `node`, `nodejs` | `javascript` |
| `ts` | `typescript` |
| `py`, `py3` | `python` |
| `cobol-85` | `cobol` |
| `cfml`, `cf` | `coldfusion` |

Frameworks are lower-cased and stripped; empty frameworks collapse to
`None`. Empty primary or target language raises
`UnsupportedGeneratorError` before any lookup.

## 2. Routing Table (primary)

The `(primary_language, target_language) -> GeneratorSkill` map in
`_generator_router.py::_ROUTING_TABLE` is the single source of truth for
registered language pairs. Current contents:

| Primary | Target | Skill slug | Built? |
|---|---|---|---|
| java | java | `springboot-api-generation` | yes |
| csharp | csharp | `dotnet-api-generation` | pending |
| csharp | dotnet | `dotnet-api-generation` | pending |
| vbnet | csharp | `dotnet-api-generation` | pending |
| python | python | `fastapi-api-generation` | pending |
| javascript | javascript | `node-api-generation` | pending |
| typescript | typescript | `node-api-generation` | pending |
| typescript | javascript | `node-api-generation` | pending |
| cobol | java | `cobol-to-java-generator` | pending |

Pending means the slug is registered but the skill directory is not yet
authored. Selecting a pending skill raises `PendingGeneratorError` with a
message pointing the caller at the missing file.

## 3. Fallback Chain (secondary)

Per-stack fallback chains live in
`olympus/olympus/agents/_generator_router_fallbacks.yaml`. Each stack's
chain is an ordered list of candidates with:
- `lang` — canonical primary language token
- `framework` — optional framework hint; may be null, a concrete token, or
  the wildcard string `"*"`
- `target` — target language token (resolved against `_ROUTING_TABLE`)
- `skill_id` — generator skill slug

The first entry is the primary; subsequent entries are fallbacks tried in
order.

## 4. Confidence Scoring

For each candidate the router computes a deterministic score:

| Condition | Score |
|---|---|
| `candidate.lang != requested.lang` | `0.0` |
| `candidate.framework == "*"` (wildcard) | `0.4` |
| `requested.framework is None` AND lang matches | `1.0` |
| `candidate.framework is None` AND lang matches | `0.7` |
| `candidate.framework == requested.framework` | `1.0` |
| lang matches, frameworks differ | `0.7` |

Scoring is implemented in `_score_candidate()`. The resulting
`ScoredCandidate` records `(lang, framework, target, skill_id,
confidence, built)`.

## 5. Selection

1. Read `OLYMPUS_ROUTER_CONFIDENCE_THRESHOLD` from the environment at call
   time (default `0.6`). Non-float values log a WARN and fall back to
   `0.6`.
2. Load the fallback chain for `normalized(primary_language)`. If the
   stack has no YAML entry, synthesise a one-candidate chain from
   `_ROUTING_TABLE[(primary, target)]` (or raise
   `UnsupportedGeneratorError` if that row doesn't exist either).
3. Walk the chain in order. Pick the FIRST candidate whose confidence
   `>=` the threshold.
4. If no candidate clears the threshold, raise `RouterEscalation`
   carrying `stack`, `target`, `framework`, `threshold`, and the full
   scored `candidates[]`.
5. If the chosen candidate maps to `built=False`, raise
   `PendingGeneratorError`.
6. Otherwise return a `RouterDecision` with `skill_id`, `confidence`,
   `fallback_used` (True when the chosen entry was not the first one in
   the chain), and the full scored `fallback_chain`.

## 6. Worked Examples

### Example A — `csharp -> csharp`, framework `asp.net-core`
- Normalized: primary=`csharp`, target=`csharp`, framework=`asp.net-core`
- Chain: `csharp` stack (3 entries).
  - entry 0: lang=csharp, fw=`asp.net-core`, target=csharp → **1.0**
  - entry 1: lang=csharp, fw=`*`, target=csharp → 0.4
  - entry 2: lang=csharp, fw=None, target=dotnet → 0.7
- Chosen: entry 0 → `dotnet-api-generation` (pending → raises
  `PendingGeneratorError` until the skill is authored).

### Example B — `java -> java`, framework `spring-boot`
- Normalized: primary=`java`, target=`java`, framework=`spring-boot`
- Chain: `java` stack (2 entries).
  - entry 0: lang=java, fw=`spring-boot`, target=java → **1.0**
  - entry 1: lang=java, fw=`*`, target=java → 0.4
- Chosen: entry 0 → `springboot-api-generation` (built → returns a
  `RouterDecision` with `confidence=1.0`, `fallback_used=False`).

### Example C — `python -> python`, no framework hint
- Normalized: primary=`python`, target=`python`, framework=None
- Chain: `python` stack (2 entries).
  - entry 0: lang=python, fw=`fastapi`, target=python → **1.0** (scoring
    treats a no-framework request as exact on language).
  - entry 1: lang=python, fw=`*`, target=python → 0.4
- Chosen: entry 0 → `fastapi-api-generation` (pending → raises
  `PendingGeneratorError`).

### Example D — `cobol -> java`, no fallback chain for `cobol`
- Normalized: primary=`cobol`, target=`java`, framework=None
- `cobol` has no YAML fallback chain (COBOL modernization is direct, not
  via a chain). The router synthesises a single-candidate chain from
  `_ROUTING_TABLE[("cobol","java")]` → `cobol-to-java-generator`
  (pending).
- Scoring: framework=None, lang-matched → **1.0**.
- Chosen: synthesised entry → raises `PendingGeneratorError` because the
  skill is registered but not yet built.

### Example E — `perl -> python`, unregistered pair
- Normalized: primary=`perl`, target=`python`
- No `perl` key in the fallback YAML AND no `("perl","python")` row in
  `_ROUTING_TABLE`.
- Router raises `UnsupportedGeneratorError` with the sorted list of
  registered pairs and an instruction to add the row + skill.

### Example F — `coldfusion -> python`, framework hint `django`
- Normalized: primary=`coldfusion`, target=`python`, framework=`django`
- Chain: `coldfusion` stack (3 entries).
  - entry 0: lang=coldfusion, fw=`fastapi`, target=python → 0.7
    (lang matches, frameworks differ: `django` vs `fastapi`).
  - entry 1: lang=coldfusion, fw=`*`, target=python → 0.4 (wildcard).
  - entry 2: lang=python, fw=None, target=python → 0.0
    (lang=python != requested `coldfusion`).
- With threshold `0.6`, entry 0 clears (`0.7 >= 0.6`). Chosen:
  `fastapi-api-generation` with `fallback_used=False` and confidence
  `0.7`. The decision log records that a framework mismatch was
  tolerated.

### Example G — `unknown -> ???`, threshold `0.6`, best scored `0.4`
- Normalized: primary=`somethingunknown`, target=`python`
- Synthesised chain of one: the legacy-routing-table lookup fails →
  `UnsupportedGeneratorError` (NOT `RouterEscalation`; escalation is for
  "registered but confidence too low", not "unregistered").

## 7. Diagnostic Helpers

- `list_supported_pairs()` returns every `(primary, target, slug, built)`
  tuple from `_ROUTING_TABLE`. Agents and operator dashboards use this
  for observability.
- `_reset_fallbacks_cache()` is a test hook; production callers do not
  invoke it.

## 8. Rules for Additions

To register a new generator:
1. Add a row to `_ROUTING_TABLE` in
   `olympus/olympus/agents/_generator_router.py` with `built=False`.
2. Add or extend the stack's entry in
   `olympus/olympus/agents/_generator_router_fallbacks.yaml`. Order
   candidates from highest expected confidence to lowest.
3. Create `cross-cutting/skills/<slug>/SKILL.md` for the generator.
4. Flip `built=True` in the routing table once the skill is validated
   end-to-end.
5. Regenerate the skills lockfile via `python
   scripts/generate_skills_lock.py` and run `python
   scripts/validate_skills.py`.
