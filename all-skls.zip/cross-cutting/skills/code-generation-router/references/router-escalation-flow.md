# Router Escalation Flow

When the `code-generation-router` cannot confidently dispatch a generator,
it raises one of three exceptions from
`olympus/olympus/agents/_generator_router.py`:

- `RouterEscalation` — no candidate cleared the confidence threshold.
- `PendingGeneratorError` — chosen candidate maps to an unbuilt skill.
- `UnsupportedGeneratorError` — no chain and no routing-table row.

All three paths write an **Escalation row** and BLOCK the Generation
phase for the app. This reference documents the row shape, the reviewer
workflow, and how the pipeline resumes.

## 1. Escalation Row Schema

An Escalation row is recorded by the orchestrating agent (not by the
router itself). It carries the full router context so a reviewer can
decide the fix without re-running Discovery.

| Field | Type | Source | Notes |
|---|---|---|---|
| `id` | string | generated (UUID or short slug) | Primary key for the reviewer queue. |
| `app_id` | string | pipeline context | Which app is blocked. |
| `phase` | string | `"generation"` | Always `generation` for router escalations. |
| `reason_class` | enum | one of `threshold-miss`, `pending-skill`, `unregistered-pair` | Maps directly to the exception class. |
| `message` | string | `str(exception)` | Human-readable explanation from the router. |
| `stack` | string | `RouterEscalation.stack` | Normalized primary-language token. |
| `target` | string | `RouterEscalation.target` | Normalized target-language token. |
| `framework` | string \| null | `RouterEscalation.framework` | Normalized framework, if any. |
| `threshold` | float | `RouterEscalation.threshold` | The active confidence floor. |
| `candidates` | list[object] | `RouterEscalation.candidates` | Full scored `ScoredCandidate[]` — every candidate the router considered, with `lang`, `framework`, `target`, `skill_id`, `confidence`, `built`. |
| `recommended_fix` | string | computed (see §3) | Canned guidance for the reviewer. |
| `status` | enum | `open` \| `in-review` \| `resolved` \| `rejected` | Reviewer state machine. |
| `created_at` | ISO-8601 | auto | When the escalation was logged. |
| `resolved_at` | ISO-8601 \| null | auto | Set when `status` moves to `resolved` or `rejected`. |
| `resolution_ref` | string \| null | auto | PR URL, commit SHA, or decision-record pointer. |

`UnsupportedGeneratorError` and `PendingGeneratorError` fill the same
schema but their `candidates` list may be empty (unsupported) or contain
a single pending candidate.

## 2. Threshold-Miss vs Pending-Skill vs Unregistered

The three reason classes look similar on the surface but have different
fixes:

| Reason class | Router exception | What's missing | Reviewer action |
|---|---|---|---|
| `threshold-miss` | `RouterEscalation` | Candidate stacks exist but none match the requested stack closely enough | Add a higher-scoring row to the fallback YAML OR accept the best candidate via a documented waiver. |
| `pending-skill` | `PendingGeneratorError` | The chosen slug is registered (`built=False`) but the SKILL.md has not been authored | Create the skill; flip `built=True`. |
| `unregistered-pair` | `UnsupportedGeneratorError` | Neither the YAML chain nor `_ROUTING_TABLE` knows this language pair | Register the pair with `built=False`, then author the skill. |

## 3. Reviewer Workflow

A reviewer picks up an open row from the escalation queue and works
through three checks:

### Step 1 — Confirm the inputs
Verify that Discovery/Design produced the correct `primary_language`,
`target_language`, `target_framework`, and `risk_tier`. A bad
normalization (e.g. a stack detected as `visual-basic` instead of
`vbnet`) manifests as a router escalation; the fix is in Discovery, not
the router.

### Step 2 — Decide the fix
Consult `references/router-decision-protocol.md` §3-5. The candidate
list in the Escalation row tells the reviewer exactly which entries were
considered. Common outcomes:

- **Missing framework candidate** — add an entry to the stack's chain
  with the correct framework token. Re-run.
- **Missing language pair** — add a row to `_ROUTING_TABLE`, add a
  YAML chain entry, author the generator skill. Re-run.
- **Confidence threshold too strict for this app** — rare; requires a
  per-run override via `OLYMPUS_ROUTER_CONFIDENCE_THRESHOLD` and a
  decision-record entry explaining why the global threshold should stay
  at `0.6`. Do NOT lower the global default.
- **Design target is wrong** — kick back to Design with a note; the
  router is not the right place to force-fit an incorrect target.

### Step 3 — Implement and close
For code changes, open a branch `fix/router-escalation-<app_id>-<n>`,
land the change through the normal PR flow, and update the Escalation
row:
- `status` → `resolved`
- `resolved_at` → now
- `resolution_ref` → PR URL or commit SHA

For decision-only closures (waiver, reject), use `status=rejected` with
a reason paragraph.

## 4. Registering a New Skill

The most common resolution is "author a new generator skill". The
minimum change set is:

1. Create `cross-cutting/skills/<new-slug>/SKILL.md` with full
   frontmatter. Use an existing generator SKILL (e.g.
   `springboot-api-generation`) as a template.
2. Add `(primary, target) -> GeneratorSkill("<new-slug>", built=True)`
   to `_ROUTING_TABLE` in
   `olympus/olympus/agents/_generator_router.py`.
3. Add a chain entry to
   `olympus/olympus/agents/_generator_router_fallbacks.yaml` under the
   primary stack. The entry MUST include:
   - `lang: <primary>`
   - `framework: <framework-token>` (or `"*"` for a wildcard, or `null`
     for any)
   - `target: <target>`
   - `skill_id: <new-slug>`
4. Regenerate the skills lockfile: `python
   scripts/generate_skills_lock.py`.
5. Validate: `python scripts/validate_skills.py`.
6. Add unit tests for the new routing pair in
   `olympus/tests/test_generator_router.py` (mirror the existing
   pair-coverage pattern).

Once the PR lands, the Escalation row is marked `resolved` and the
pipeline agent retries the Generation phase automatically. The router
re-scores the candidate list on the retry; because `built=True` and the
confidence clears the threshold, dispatch succeeds.

## 5. What the Router Does NOT Do

The router intentionally refuses several "helpful" behaviours so that
humans keep control over generation safety:

- **No best-of-worst fallback.** A chain with every candidate below
  threshold escalates. The router will not pick `max(candidates)`.
- **No cross-target substitution.** If Design chose `csharp`, the
  router will not silently dispatch a `java` generator even if the
  `java` chain has higher-scoring candidates.
- **No risk-tier gating inside the router.** `risk_tier` is logged but
  not a routing key. T1 apps are additionally reviewed by the
  orchestrating agent; the router's job is resolution, not approval.
- **No ranking across stacks.** Fallback chains are per-stack. The
  router will not borrow a candidate from a different stack's chain.

These constraints are preserved by the escalation flow: when the router
cannot pick, a human picks (or declines) via the Escalation row.
