---
name: tn3270-emulator-inventory
description: >
  Detect TN3270 terminal-emulator configuration and session-profile
  references in mainframe-adjacent repos. RMS is the ATLAS case:
  examiners access CAIS via Aviva Desktop (a TN3270 emulator) — the
  "green screen" UI over a terminal session to z/OS. Discovery must
  inventory the emulator product, session profiles, and macro
  scripts because modernization must replace the TN3270 UI with a
  web-based front end. Runs as Discovery conditional when
  `tech_stack_contains` includes tn3270, aviva, or when the repo
  contains `.kwm` / `.wsh` / `.mac` / `.ws` session-profile files.
  Triggers on TN3270 inventory, mainframe UI modernization, or
  @tn3270-emulator-inventory.
agent: sonnet
allowed-tools:
  - Read
  - Write
  - Grep
  - Glob
validation_commands:
  - "python -m olympus.validators.schema_validator tn3270-inventory.json"
  - "python -m olympus.validators.schema_validator tn3270-macro-findings.json"
supported_stacks:
  - tn3270
  - aviva
  - host-on-demand
  - extra
  - personal-communications
  - mainframe
anti_target_stacks:
  - web-ui
  - spa
  - static-site
failure_classes:
  - emulator-product-misidentified
  - macro-script-not-extracted
  - session-profile-credential-leak
  - pf-key-mapping-lost
benchmark_tags:
  - discovery-mainframe
  - tn3270-inventory
  - green-screen-modernization
---

# tn3270-emulator-inventory

## Purpose
Inventory TN3270 emulator config, session profiles, macros so
modernization can author the replacement web UI with equivalent
behavior (navigation, PF-key mappings, session multiplexing).

## Inputs
- Repository with mainframe integration references.
- Optional: emulator config files (often not in repo).

## Outputs
- `tn3270-inventory.json` — `{emulator_product (aviva | host_on_demand |
  extra | pcomm | ibm_pcomm), session_profile_files[], macro_files[],
  host_ip_or_dns, lu_names[], pf_key_mappings[]}`.
- `tn3270-macro-findings.json` — per macro: purpose, command
  sequence, PF-key invocations.

## Methodology
1. Grep for emulator product markers: `Aviva`, `PCOMM`, `Host
   On-Demand`, `HOD`, `Extra!`, `EE`.
2. Locate `.ws`, `.kwm`, `.mac`, `.wsh`, `.ecl` session-profile
   files.
3. Parse session profiles for host, LU, port, SSL config.
4. Extract macros (typically VBA-flavored automation scripts
   that drive the green-screen UI).

## Tech-Stack Dispatch

No external references.

## Gotchas
- Emulator vendor is often not in source; inferred from
  contractor preference / README.
- PF-key mappings (F1-F24) are application-level; modernization
  must reproduce the keyboard shortcuts.
- Session profiles carry host + LU + credentials; redact
  credentials.
- Macros are scriptable automation (often VBA-like); classify as
  modernization-gap items.

## Quality Rules
- [ ] Every emulator product identified.
- [ ] Session profiles inventoried.
- [ ] Macros extracted with purpose.
- [ ] Credentials redacted.
- [ ] Every record cites `{repo}:{file}:{line}`.

## Common Failure Modes

| Failure Mode | Symptom | Prevention |
|---|---|---|
| Emulator guessed | Wrong vendor named | Emit `emulator-unconfirmed` unless evidence-based |
| Macro ignored | Macro script carries business logic; modernized web UI misses it | Enumerate every `.mac` / `.vbs` alongside profile |

## Handoff Summary
TN3270 inventory emitted. Proceed to `ux-flow-derivation` for
target web UI replacement planning.

## References
None.

## Changelog
- 0.1.0 (2026-05-07) — Initial skill. Authored as ATLAS-R-20.
