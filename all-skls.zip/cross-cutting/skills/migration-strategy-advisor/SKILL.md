---
name: migration-strategy-advisor
description: >
  Recommend cloud patterns and migration strategies based on application characteristics,
  constraints, and enterprise architecture standards. Used during Architecture line
  Step 1. Triggers on cloud pattern selection, migration strategy, or EA compliance review.
agent: opus
allowed-tools:
  - Read
  - Write
  - Grep
---

# Migration Strategy Advisor

## Purpose
Select appropriate cloud architecture patterns and migration strategies for each
application, balancing modernization goals against complexity, risk, and enterprise
architecture constraints. For FAA engagements, recommendations anchor to the
Phase 2 ACIS stack (Angular + Java + PostgreSQL + Tyrion + Amazon SQS on AWS
GovCloud) per `references/faa-cloud-service-matrix.md`.

## Inputs
- Application complexity tier (Simple/Moderate/Complex)
- Archetype (web/batch/API/job/hybrid)
- Dependency profile from Discovery
- Integration surface (external systems, shared databases)
- RTO/RPO requirements
- Client EA standards (from active profile)
- Available cloud services (CSP-specific or CSP-agnostic)

## Outputs
- Cloud service selection matrix (with CSP-specific equivalents)
- Architecture pattern recommendation with justification
- Resilience design (HA patterns, multi-AZ, failover strategies)
- Cost projection for recommended approach
- Migration timeline estimate

## Methodology
Pattern selection uses the formal decision table in
`references/pattern-decision-matrix.md` (complexity tier × archetype → pattern,
with Strangler-Fig and Event-Driven complement rules).

For each recommendation:
1. Pick the primary pattern via `references/pattern-decision-matrix.md`
2. Map every capability to a service via `references/faa-cloud-service-matrix.md`
   (ACIS stack defaults; deviations require stakeholder sign-off)
3. Pick a resilience class via `references/resilience-patterns.md`; confirm the
   class meets or exceeds the minimum for the app's risk tier
4. Validate against EA compliance standards and GovCloud service availability
5. Estimate cost using cloud pricing calculators
6. Document decision rationale with traceability to Discovery findings, using
   `assets/strategy-recommendation-template.md` as the output scaffold

## Tech-Stack Dispatch
Before recommending migration strategies, detect the source technology and load the
appropriate feasibility reference:
- ColdFusion (.cfm, .cfc, Application.cfc) → Read references/coldfusion-patterns.md
- Java EE (.java, pom.xml, web.xml, EAR/WAR) → Read references/java-ee-patterns.md
- COBOL (.cbl, .cpy, JCL) → future — coordinate with the client profile mainframe addendum
- .NET (.cs, .csproj, .sln) → future — coordinate with the client profile .NET addendum

## Gotchas
- **GovCloud service availability varies**: Not all commercial AWS/Azure services
  are available in GovCloud regions. Verify before recommending.
- **Don't over-architect Simple tier apps**: A modular monolith is fine for a
  simple app. Microservices add operational complexity that isn't justified.
- **Architecture decisions must trace to Discovery findings**: "We chose
  microservices because..." needs to reference specific complexity indicators.

## Quality Rules
- [ ] Pattern selected via `references/pattern-decision-matrix.md`; the matching row is cited in the rationale
- [ ] Every capability maps to a service via `references/faa-cloud-service-matrix.md`; each selection has a rationale paragraph; any deviation from default carries a recorded stakeholder sign-off
- [ ] Resilience class selected via `references/resilience-patterns.md`; class meets or exceeds the minimum for the app's risk tier
- [ ] GovCloud service availability is verified for every recommended cloud service before finalizing
- [ ] Architecture decisions trace to specific Discovery findings — not generic justifications
- [ ] Cost projection uses cloud pricing calculators, not estimates — includes compute, storage, data transfer, and monitoring
- [ ] Migration timeline estimate accounts for shared database decomposition and co-wave dependencies

## Common Failure Modes
| Failure Mode | Symptom | Prevention |
|-------------|---------|------------|
| Over-architected simple app | Microservices pattern applied to a single-domain simple app; unnecessary operational complexity | Follow decision matrix — simple tier apps should not be microservices unless justified |
| GovCloud service gap | Design depends on a service not available in GovCloud; last-minute redesign required | Verify GovCloud availability for every AWS service in the architecture before finalizing |
| Untraceable architecture decisions | "We chose X because it's best practice" — no link to Discovery findings; EA review rejects it | Require traceability citation to specific Discovery findings for every pattern selection |
| RTO/RPO mismatch | Single-AZ deployment for an app with 15-minute RTO; disaster recovery fails | Validate resilience design against RTO/RPO requirements before finalizing |
| Recommended service drifts from FAA-committed stack | Downstream Architecture line re-litigates service choices; Phase 2 alignment review rejects the design | Anchor every capability to `references/faa-cloud-service-matrix.md`; document stakeholder sign-off for any deviation from the ACIS defaults |

## Handoff Summary
When this skill completes, verify:
1. Cloud service selection is GovCloud-compatible
2. Architecture pattern matches complexity tier with traceable justification
3. Resilience design meets RTO/RPO requirements
4. Cost projection is calculator-based with all cost categories
Then proceed to: `ea-compliance` for EA alignment verification, `module-design` (P4.2) for detailed service architecture, and gate `G-02` for architecture review
