# Migration Strategy Recommendation

## 1. Application Identification
- **Name**: <app-name>
- **System ID / portfolio ref**: <id>
- **Current stack**: <language / framework / runtime>
- **Source repo / code location**: <repo-url>
- **Discovery artifact ref**: <artifact:section:finding-id>

## 2. Classification
- **Complexity tier**: Simple | Moderate | Complex
- **Archetype**: web | API | batch | ETL | job | hybrid
- **Risk tier**: Tier 1 | Tier 2 | Tier 3
- **Bounded contexts identified**: <count + list>
- **Integration surface**: <external systems, shared DBs>

## 3. Recommended Pattern
- **Primary pattern**: <microservices | modular monolith | serverless | event-driven | strangler-fig>
- **Decision matrix row**: <cite `references/pattern-decision-matrix.md`>
- **Event-driven complement?**: Yes / No — <rationale>
- **Rationale** (1 paragraph, cite Discovery findings):

## 4. Cloud Service Selections (per capability)
Map every capability to a service per `references/faa-cloud-service-matrix.md`. Include a one-line rationale per row.

| Capability | Selected service (CSP-specific name) | Rationale | Deviation from default? |
|---|---|---|---|
| Container platform | Tyrion (FAA k8s) | | No |
| Compute | ECS on Tyrion / EKS / Lambda | | |
| Relational DB | Aurora PostgreSQL / RDS PostgreSQL | | |
| Messaging | Amazon SQS + SNS | | |
| Workflow engine | Camunda 8 | | |
| Object store | S3 | | |
| Search | OpenSearch | | |
| Observability | OpenTelemetry → Datadog \| Grafana Cloud | | |
| CDN / edge | CloudFront + WAF | | |
| Identity (public / internal) | Login.gov / PIV-MyAccess | | |

## 5. Resilience Design
- **Class**: A (mission-critical) | B (standard) | C (best-effort)
- **Class source**: <cite `references/resilience-patterns.md`>
- **Risk-tier minimum met?**: Yes / No — if No, escalate
- **Patterns applied**: <multi-AZ, active-active, cross-region DR, etc.>
- **Chaos-engineering touchpoints**: <quarterly AZ drill, monthly failover, etc.>

## 6. Cost Projection
- **Method**: AWS Pricing Calculator (link or attached export)
- **Assumptions**: <traffic, data volume, retention, egress>
- **Monthly estimate**:
  - Compute: $<x>
  - Storage: $<x>
  - Data transfer: $<x>
  - Observability: $<x>
  - **Total**: $<x>
- **Sensitivity**: <top 2-3 cost drivers + break-even scenarios>

## 7. Timeline Estimate
| Milestone | Duration | Dependencies |
|---|---|---|
| Spec extraction (P4.1) | | |
| Module design (P4.2) | | |
| Generation (P4.3, Ralph Loop) | | |
| Validation / ATO prep | | |
| Cutover / strangler slices | | |
| **Total** | | |

## 8. Gotchas & Risks (per choice)
| Choice | Risk | Mitigation |
|---|---|---|
| <e.g., DynamoDB over Postgres> | Dual-data-store operational load | Require stakeholder sign-off; confirm access patterns |
| GovCloud service gap | Service parity lag vs commercial AWS | Verify every service before finalizing |
| Camunda learning curve | Team unfamiliar with BPMN | Budget training sprint |

## 9. Traceability
- Discovery findings cited: <list>
- Profile constraints applied: <list>
- EA decisions referenced: <list>
