# Archetype Decision Tree

Reference for the migration-strategy-advisor skill. Use this decision tree
to select the appropriate application archetype based on observable
characteristics from Discovery analysis.

---

## Overview

The archetype determines the target architecture pattern, compute model,
and migration approach. Incorrect archetype selection cascades into
suboptimal architecture decisions. This tree uses measurable characteristics
from Discovery artifacts to drive archetype selection objectively.

---

## Primary Decision: Application Type

```
Is the application primarily...
  |
  +-- User-facing with a web UI?
  |     |
  |     +-- YES --> Go to "Web Application Subtype"
  |
  +-- An API consumed by other systems (no direct user UI)?
  |     |
  |     +-- YES --> Go to "API Service Subtype"
  |
  +-- A scheduled or triggered background process?
  |     |
  |     +-- YES --> Go to "Batch/Job Subtype"
  |
  +-- Multiple of the above?
        |
        +-- YES --> Classify as "Hybrid" and decompose into components
```

---

## Web Application Subtype

### Input Characteristics

| Characteristic | Source | How to Measure |
|---------------|--------|----------------|
| Number of UI screens | UX pass in analysis | Count distinct .aspx/.cfm/.jsp pages with user-facing content |
| Number of bounded contexts | Architecture pass | Count distinct business domains with separate data and logic |
| External API count | Integration pass | Count distinct external system integrations |
| User count | Discovery intake | Monthly active users from stakeholder interview |
| Real-time requirements | Business logic pass | Any WebSocket, push notification, or sub-second latency needs |
| Data volume | Data pass | Total database size and growth rate |

### Decision Logic

```
UI Screens <= 10 AND Bounded Contexts = 1 AND External APIs <= 3?
  |
  +-- YES --> SIMPLE WEB APP
  |           Pattern: Modular Monolith (single Fargate service)
  |           Compute: Fargate (0.25 vCPU, 0.5 GB)
  |           Data: Aurora Serverless v2 (0.5-4 ACU)
  |
  +-- NO
        |
        UI Screens <= 50 AND Bounded Contexts 2-5 AND External APIs <= 15?
          |
          +-- YES --> STANDARD WEB APP
          |           Pattern: Modular Monolith (SPA + API on Fargate)
          |           Compute: Fargate (0.5-2 vCPU, 1-4 GB)
          |           Data: Aurora Serverless v2 (2-16 ACU)
          |           Cache: ElastiCache Redis (if read-heavy)
          |
          +-- NO
                |
                UI Screens > 50 OR Bounded Contexts > 5 OR External APIs > 15?
                  |
                  +-- YES --> COMPLEX WEB APP
                              Pattern: Microservices (1 service per bounded context)
                              Compute: Fargate (per-service sizing)
                              Data: Aurora + DynamoDB (polyglot if needed)
                              Cache: ElastiCache Redis (per-context if isolated)
                              Integration: EventBridge for inter-service events

Real-Time Requirements?
  |
  +-- YES --> Add WebSocket support (API Gateway WebSocket or Fargate)
              Consider ElastiCache Pub/Sub for real-time broadcasts
```

---

## API Service Subtype

### Input Characteristics

| Characteristic | Source | How to Measure |
|---------------|--------|----------------|
| Number of API endpoints | Interface inventory | Count distinct API operations (GET, POST, PUT, DELETE) |
| Request volume | Discovery intake | Requests per second (peak and average) |
| Latency SLA | Stakeholder interview | p99 latency requirement in milliseconds |
| Data access pattern | Data pass | Read-heavy, write-heavy, or balanced |
| Search requirements | Business logic pass | Full-text search, faceted search, aggregation queries |
| Payload size | Interface inventory | Average and maximum request/response payload size |

### Decision Logic

```
Endpoints <= 10 AND Requests/sec <= 50 AND No search requirements?
  |
  +-- YES --> SIMPLE API
  |           Pattern: Single Fargate service
  |           Compute: Fargate (0.25-0.5 vCPU)
  |           Data: Aurora Serverless v2
  |
  +-- NO
        |
        Endpoints <= 50 AND Requests/sec <= 500?
          |
          +-- YES AND has search --> SEARCH API
          |           Pattern: Fargate service + search sidecar
          |           Compute: Fargate (0.5-2 vCPU)
          |           Data: Aurora + OpenSearch
          |           Cache: ElastiCache for search result caching
          |
          +-- YES AND no search --> STANDARD API
          |           Pattern: Fargate service behind Gravitee
          |           Compute: Fargate (0.5-1 vCPU)
          |           Data: Aurora Serverless v2
          |           Cache: ElastiCache for hot data
          |
          +-- NO (Endpoints > 50 OR Requests/sec > 500)
                    |
                    +-- HIGH-TRAFFIC API
                        Pattern: Microservices behind Gravitee
                        Compute: Fargate (per-service, auto-scaled)
                        Data: DynamoDB (if key-value) or Aurora (if relational)
                        Cache: ElastiCache with read replicas
                        CDN: CloudFront for cacheable responses
```

---

## Batch/Job Subtype

### Input Characteristics

| Characteristic | Source | How to Measure |
|---------------|--------|----------------|
| Execution frequency | Discovery intake | How often the job runs (hourly, daily, weekly, event-triggered) |
| Execution duration | Operational data | How long a typical run takes |
| Data volume per run | Data pass | Rows/records/files processed per execution |
| Fan-out potential | Architecture pass | Can the job be parallelized? |
| File I/O | Integration pass | Does the job read/write files (SFTP, S3, shared drive)? |
| State requirements | Business logic pass | Does the job need to track progress for resume? |

### Decision Logic

```
Duration <= 15 minutes AND Data volume < 10,000 records AND No state tracking?
  |
  +-- YES --> SIMPLE LAMBDA JOB
  |           Pattern: Lambda triggered by EventBridge schedule or S3 event
  |           Compute: Lambda (512 MB - 3 GB memory)
  |           Data: S3 for input/output, DynamoDB for results
  |
  +-- NO
        |
        Duration <= 4 hours AND Fan-out possible?
          |
          +-- YES --> STEP FUNCTIONS PIPELINE
          |           Pattern: Step Functions orchestrating Lambda fan-out
          |           Compute: Lambda (per-step, parallel execution)
          |           Data: S3 for staging, DynamoDB for state tracking
          |           Queue: SQS for work distribution (if very high fan-out)
          |
          +-- NO
                |
                Duration > 4 hours OR Sequential processing required?
                  |
                  +-- YES --> FARGATE BATCH TASK
                              Pattern: Fargate task triggered by EventBridge
                              Compute: Fargate Spot (1-4 vCPU, batch profile)
                              Data: S3 for input/output, Aurora for complex queries
                              Monitoring: Step Functions for orchestration if multi-step
```

---

## Hybrid Application Decomposition

When an application spans multiple archetypes (e.g., a web app with a batch
component), decompose into constituent services and classify each independently.

### Decomposition Rules

1. **Web UI + Background Job**: Separate into web-app archetype (Fargate) +
   batch archetype (Lambda/Step Functions). Communicate via EventBridge.

2. **Web UI + API for external consumers**: Single web-app archetype with
   Gravitee API Gateway exposing selected endpoints to external consumers.

3. **API + Batch Processing**: Separate into API archetype (Fargate) +
   batch archetype (Lambda/Step Functions). Shared data tier is acceptable
   during initial migration; decompose data later if needed.

4. **Monolith with everything**: Identify bounded contexts first, then
   classify each context as one of the above archetypes. Use Strangler Fig
   pattern for incremental decomposition.

---

## Archetype-to-Pattern Summary

| Archetype | Complexity | Recommended Pattern | Compute | Data |
|-----------|-----------|-------------------|---------|------|
| Simple Web App | Simple | Modular Monolith | Fargate (small) | Aurora Serverless |
| Standard Web App | Moderate | Modular Monolith | Fargate (medium) | Aurora Serverless + Redis |
| Complex Web App | Complex | Microservices | Fargate (per-service) | Polyglot (Aurora + DynamoDB) |
| Simple API | Simple | Single Service | Fargate (small) | Aurora Serverless |
| Search API | Moderate | Service + Search | Fargate + OpenSearch | Aurora + OpenSearch |
| Standard API | Moderate | Single Service | Fargate (medium) | Aurora + Redis |
| High-Traffic API | Complex | Microservices | Fargate (auto-scaled) | DynamoDB or Aurora + Redis |
| Simple Lambda Job | Simple | Serverless | Lambda | S3 + DynamoDB |
| Step Functions Pipeline | Moderate | Serverless Orchestration | Lambda (fan-out) | S3 + DynamoDB |
| Fargate Batch Task | Complex | Container Batch | Fargate Spot | S3 + Aurora |

---

## Decision Tree Validation

After selecting an archetype, validate the choice:

1. Does the selected pattern match the complexity tier from Discovery?
2. Does the compute model handle the expected traffic/throughput?
3. Does the data tier match the access patterns (relational vs key-value)?
4. Are all external integrations accounted for?
5. Does the archetype satisfy the RTO/RPO requirements for the risk tier?

If any validation fails, reconsider the archetype selection or escalate
to a human architect for review.
