# Pattern Decision Matrix

Formal decision table for selecting the primary architecture pattern. Pattern MUST be chosen via this matrix; deviations require documented rationale.

## Primary pattern by complexity tier x archetype

| Complexity | Archetype | Primary pattern | Notes |
|---|---|---|---|
| Complex | web / API / hybrid | **Microservices** | 5+ bounded contexts, independent scaling, multi-team |
| Complex | batch / ETL | **Event-Driven** | Camunda or Step Functions; S3/SQS pipeline |
| Moderate | web / API | **Modular Monolith** | 2-5 contexts; single deployable; clear module boundaries |
| Moderate | hybrid (web + batch) | **Modular Monolith + Serverless side-car** | Web in monolith; batch to Lambda |
| Moderate | batch / ETL | **Serverless (Lambda + Step Functions)** | Event-chained jobs; no always-on |
| Simple | web / API | **Modular Monolith** | Default; avoid microservices (ops cost not justified) |
| Simple | batch / job | **Serverless** | Lambda + EventBridge schedule |
| Any | legacy with strong coupling | **Strangler-Fig** (transitional) | Slice-by-slice via API gateway; retire incrementally |

## When to layer Event-Driven as a complement

Add event-driven (SQS/SNS, EventBridge) on top of the primary pattern when ANY of:

- Async cross-service workflows (e.g., document ingest -> OCR -> index)
- Fan-out to multiple consumers (notifications, audit, analytics)
- Workload smoothing / backpressure (spikes exceed sync capacity)
- Decouple producer/consumer release cadences
- Retry + DLQ semantics required for reliability

Event-driven rarely stands alone; it complements microservices and modular monoliths.

## When Strangler-Fig is mandatory

- Legacy cannot be taken offline for cutover
- Rewrite risk high (large rule set, partial spec coverage)
- Phased ATO preferred over big-bang

## Rule

Document the selected pattern, the row it came from, and any event-driven complement. If deviating, record why.
