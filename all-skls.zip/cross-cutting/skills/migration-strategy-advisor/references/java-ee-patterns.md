# Java EE Migration Strategy Patterns

Reference for Migration Strategy Advisor when source technology is Java EE.

## Migration Path Overview

| Target Stack | Feasibility | Effort Multiplier | Incremental? |
|-------------|-------------|-------------------|--------------|
| Spring Boot | Incremental | ~1.2-1.5x | Yes — same JVM |
| Quarkus | Incremental | ~1.3-1.6x | Yes — same JVM |
| Micronaut | Moderate | ~1.5-1.8x | Partial |
| .NET/C# | Full rewrite | ~2.5x | No |

Spring Boot is the default recommendation for Java EE migrations due to same-JVM
compatibility, annotation-for-annotation mappings, and high strangler-fig feasibility.

## Java EE → Spring Boot (Primary Recommendation)

### Direct Annotation Mappings
```java
// EJB → Spring
@Stateless           → @Service
@Stateful            → @Service @Scope("session")
@Singleton           → @Service (Spring singletons by default)
@MessageDriven       → @JmsListener (or @KafkaListener)
@EJB                 → @Autowired (or constructor injection)
@PersistenceContext   → @Autowired EntityManager (via Spring Data JPA)

// CDI → Spring
@Inject              → @Autowired (or constructor injection, preferred)
@Named               → @Component / @Service / @Repository
@RequestScoped       → @Scope("request")
@SessionScoped       → @Scope("session")
@Produces            → @Bean

// JAX-RS → Spring MVC
@Path                → @RequestMapping / @RestController
@GET                 → @GetMapping
@POST                → @PostMapping
@PathParam           → @PathVariable
@QueryParam          → @RequestParam
@Consumes/@Produces  → produces/consumes in @RequestMapping
```

### JPA / Hibernate Migration
JPA is largely unchanged between Java EE and Spring Boot:
- Move `persistence.xml` configuration to `application.yml`
- Entity classes and annotations remain identical
- Replace `@PersistenceContext EntityManager` with Spring Data repositories
- Hibernate versions may differ — check for deprecated API usage

```yaml
# application.yml (replaces persistence.xml)
spring:
  datasource:
    url: jdbc:postgresql://localhost:5432/mydb
    driver-class-name: org.postgresql.Driver
  jpa:
    hibernate:
      ddl-auto: validate
    properties:
      hibernate.dialect: org.hibernate.dialect.PostgreSQLDialect
```

### JSP → Modern Frontend Migration

| JSP Pattern | Target | Approach |
|------------|--------|----------|
| Simple JSPs with JSTL | Thymeleaf | Template-by-template replacement |
| JSP + heavy JavaScript | React SPA | Full frontend rewrite |
| JSF/Facelets | React SPA | Full frontend rewrite |
| JSP tag libraries | Thymeleaf dialects | Custom dialect per tag library |

Template-by-template replacement is feasible for JSP → Thymeleaf. For JSP → React,
plan a separate frontend workstream.

### Strangler Fig Strategy
Java EE → Spring Boot has the highest strangler-fig feasibility of any migration path.

```
[Client] → [ALB/nginx] → /api/v2/*    → [Spring Boot (new)]
                        → /api/v1/*    → [Java EE (legacy)]
                        ↕              ↕
                   [Shared Database]
```

1. Deploy Spring Boot app alongside legacy Java EE app
2. Both share the same database — JPA entities can be identical
3. Migrate one bounded context at a time to Spring Boot
4. Use shared Maven parent to ensure consistent dependency versions
5. Route migrated endpoints to Spring Boot via reverse proxy
6. Decommission Java EE modules as they're fully migrated

### Spring Boot can call legacy EJBs during transition:
```java
@Configuration
public class LegacyEjbConfig {
    @Bean
    public JndiObjectFactoryBean legacyUserService() {
        JndiObjectFactoryBean bean = new JndiObjectFactoryBean();
        bean.setJndiName("java:global/legacy-app/UserServiceBean");
        return bean;
    }
}
```

## Build System Migration

### Maven → Maven (trivial)
- Update `pom.xml` parent to `spring-boot-starter-parent`
- Replace Java EE dependencies with Spring Boot starters
- Remove app-server-specific Maven plugins
- Add `spring-boot-maven-plugin`

### Ant → Maven (moderate effort)
- Map `build.xml` targets to Maven lifecycle phases
- Convert `lib/` JARs to Maven dependencies (use `mvn dependency:analyze`)
- Create `pom.xml` module structure matching the existing project layout
- Estimated effort: 1-2 sprints for a complex Ant build

### Gradle → Gradle (trivial)
- Update plugins to Spring Boot Gradle plugin
- Replace Java EE dependencies with Spring Boot starters

## Application Server De-coupling

### Audit for Vendor Lock-in
Check for server-specific APIs that must be replaced:

| Vendor API | Spring Boot Replacement |
|-----------|------------------------|
| WebSphere `WorkManager` | Spring `@Async` + `TaskExecutor` |
| WebSphere `DynaCache` | Spring Cache abstraction + Redis |
| JBoss `@Service` (JBoss-specific) | Spring `@Service` |
| WebLogic `T3` protocol | Standard JNDI or REST |
| WebSphere MQ (JMS) | Spring JMS with ActiveMQ/RabbitMQ |
| JAAS (server-managed auth) | Spring Security |
| Server-managed DataSource | Spring Boot DataSource auto-config |
| Server-managed thread pools | Spring `ThreadPoolTaskExecutor` |

### Server Descriptor Elimination
These files are replaced by Spring Boot auto-configuration:
- `web.xml` → Spring Boot auto-configures embedded Tomcat
- `ejb-jar.xml` → Spring component scanning
- `application.xml` → Spring Boot single deployable JAR
- `ibm-web-bnd.xml`, `jboss-web.xml`, `weblogic.xml` → removed entirely
- `persistence.xml` → `application.yml` JPA properties

## Key Risks

1. **App server vendor lock-in** (HIGH): WebSphere/JBoss-specific APIs create hidden
   dependencies. Mitigation: Audit all imports for `com.ibm.*`, `org.jboss.*`,
   `weblogic.*` packages before starting migration.
2. **EJB 2.x complexity** (HIGH): EJB 2.x with Home/Remote interfaces requires
   significant rework. EJB 3.x annotation-based beans map much more directly.
   Mitigation: If EJB 2.x, budget 2x the effort of EJB 3.x migration.
3. **Shared database during transition** (MEDIUM): Both apps writing to the same DB
   can cause conflicts. Mitigation: Migrate read-heavy services first, coordinate
   schema changes carefully.
4. **Transaction management** (MEDIUM): Java EE container-managed transactions (CMT)
   → Spring `@Transactional`. Boundary placement must be verified.
5. **Security model** (MEDIUM): JAAS/container-managed security → Spring Security.
   Role mappings, LDAP integration, and SSO must be re-implemented.
6. **Class loading** (LOW): Java EE app servers have complex class loaders. Spring Boot
   uses flat classpath. This usually simplifies things but can surface hidden
   dependency conflicts.
