# Resilience Patterns by RTO/RPO Class

Every recommendation maps to a resilience class; class must match the app's risk tier.

## Classes

### Class A — Mission-critical (RTO < 1h, RPO < 5min)
- **Data**: Aurora Global Database (multi-region), synchronous multi-AZ, PITR
- **Compute**: Active-active across 2+ AZs; active-passive cross-region when A-A infeasible
- **Failover**: Route 53 health-check DNS failover; leader election via Route 53 or etcd for singletons
- **Messaging**: SQS is multi-AZ by default; S3 CRR for cross-region data
- **Edge**: CloudFront with origin failover
- **Chaos**: quarterly AZ-loss game day, monthly region-failover drill, dependency fault injection (SQS throttle, RDS failover)

### Class B — Standard (RTO < 4h, RPO < 1h)
- **Data**: Multi-AZ RDS PostgreSQL; automated backups + cross-region snapshot copy
- **Compute**: Stateless behind ALB across 2 AZs; ASG with warm pool
- **Failover**: Cross-region cold standby (IaC replay + snapshot restore)
- **Messaging**: SQS with DLQ; idempotent consumers
- **Chaos**: semi-annual failover drill; monthly pod/task kill tests

### Class C — Best-effort (RTO > 4h, RPO > 1h)
- **Data**: Single-AZ with daily snapshots; 7-day retention minimum
- **Compute**: Single AZ, single ASG; re-deploy on failure
- **Failover**: Manual restore from snapshot
- **Chaos**: annual restore-from-backup verification

## Risk-tier mapping

| Risk tier | Minimum class | Notes |
|---|---|---|
| Tier 1 | Class A | Active-active required where dependencies permit |
| Tier 2 | Class B | Class A permitted when cost-justified |
| Tier 3 | Class C | Class B permitted for shared-platform components |

## Rule
Selected class MUST meet or exceed the minimum for the app's risk tier. Record class + chaos touchpoints in every recommendation.
