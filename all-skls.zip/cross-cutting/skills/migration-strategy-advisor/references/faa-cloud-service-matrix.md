# FAA Cloud Service Matrix

Capability-to-service mapping for FAA Phase 2 (ACIS on AWS GovCloud). Every recommendation MUST map capabilities via this matrix with per-selection rationale.

## Matrix

| Capability | Primary service | Rationale | ACIS |
|---|---|---|---|
| Container platform | **Tyrion** (FAA k8s, GovCloud) | FAA baseline; central ATO; pre-hardened images | Default |
| Compute (long-running) | **ECS on Tyrion** | Stateful services; inherits Tyrion controls | Default |
| Compute (k8s-heavy) | **EKS** | Reserve for operators, CRDs, service mesh | Permitted |
| Compute (event-driven) | **AWS Lambda** | Bursts, schedules, S3/SQS triggers; no always-on | Approved |
| Relational DB | **PostgreSQL on RDS or Aurora** | Phase 2 commitment; OSS; JSONB; Aurora for HA | Primary |
| Key-value NoSQL | **DynamoDB** | Only for proven hot-path KV >10k TPS or single-ms p99 | Exception |
| Messaging (default) | **Amazon SQS + SNS** | ACIS async backbone; FIFO where ordered; DLQs required | Default bus |
| Streaming / fan-out | **MSK (Kafka)** | Stakeholder sign-off; replay + multi-consumer | Exception |
| Workflow engine | **Camunda 8** | Declarative BPMN per architecture.html; human-in-loop | Committed |
| Object store | **Amazon S3** | Durable blobs; versioning + object lock for WORM | Base |
| Search / unified doc store | **OpenSearch** | Replaces Unisys InfoImage; S3-backed; FedRAMP High | Committed |
| Observability | **OpenTelemetry -> Datadog or Grafana Cloud** | Both FedRAMP High; OTel keeps portability | Lane |
| CDN / edge | **CloudFront + AWS WAF** | FAA edge overlay; managed rules; TLS termination | Default |
| Identity (public) | **Login.gov** | Federal SSO for public users | Mandated |
| Identity (internal) | **PIV / MyAccess via broker** | FAA employee/contractor SSO; PIV flows | Mandated |

## Rule

Deviation from defaults (e.g., Kafka over SQS, DynamoDB over Postgres) requires stakeholder sign-off and a recorded rationale.
