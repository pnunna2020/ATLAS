# ColdFusion Migration Strategy Patterns

Reference for Migration Strategy Advisor when source technology is ColdFusion.

## Migration Path Overview

| Target Stack | Feasibility | Effort Multiplier | Incremental? |
|-------------|-------------|-------------------|--------------|
| Python/FastAPI | Full rewrite | ~3x | Strangler fig possible |
| Node.js/Express | Full rewrite | ~2.5x | Strangler fig possible |
| Java/Spring Boot | Full rewrite | ~2x | Strangler fig possible |
| .NET/C# | Full rewrite | ~2x | Strangler fig possible |

ColdFusion has no incremental compilation or annotation-for-annotation migration path
to any modern stack. All paths require a full rewrite of business logic.

## ColdFusion → Python/FastAPI (Primary Recommendation)

### What Maps Well
- CFC methods → FastAPI route handlers or service classes
- `<cfquery>` → SQLAlchemy queries or raw SQL with parameterized queries
- CFWheels MVC → FastAPI with Pydantic models (similar request/response pattern)
- FW/1 services → Python service classes (similar DI conventions)
- `Application.cfc` `onRequestStart` → FastAPI middleware
- CF structs/arrays → Python dicts/lists (similar dynamic typing origin)

### What Requires Redesign
- **Implicit type coercion**: CF silently converts between types (string "5" == number 5).
  Python is strictly typed at runtime. Every data boundary needs explicit conversion.
  ```cfml
  <!--- CF: this works silently --->
  <cfset result = "5" + 3>  <!--- result = 8 --->
  ```
  ```python
  # Python: this raises TypeError
  result = "5" + 3  # TypeError: can only concatenate str to str
  ```
- **Session management**: CF's built-in session scope → Redis/database-backed sessions
- **File uploads**: `<cffile>` → Python file handling with cloud storage (S3)
- **Email**: `<cfmail>` → SMTP library (smtplib) or email service (SES)
- **Scheduled tasks**: CF Administrator scheduled tasks → Celery/Temporal workflows
- **PDF generation**: `<cfdocument>` → WeasyPrint or ReportLab

### Strangler Fig Strategy
1. Deploy FastAPI app alongside CF application behind a reverse proxy (nginx/ALB)
2. Identify CF endpoints by analyzing URL patterns in the CF application
3. Rewrite one endpoint at a time in FastAPI
4. Route rewritten endpoints to FastAPI via proxy rules
5. Shared database during transition — both apps read/write the same DB
6. Migrate endpoint-by-endpoint, starting with lowest-coupling endpoints

```
[Client] → [ALB/nginx] → /api/v2/*  → [FastAPI (new)]
                        → /*         → [ColdFusion (legacy)]
                        ↕
                   [Shared Database]
```

### Data Layer Migration
- `<cfquery>` with inline SQL → SQLAlchemy Core (preserves SQL, adds parameterization)
- `<cfquery>` with ORM → SQLAlchemy ORM with mapped classes
- `<cfstoredproc>` → SQLAlchemy `text()` with stored proc calls (migrate independently)
- CF query-of-queries → Pandas DataFrames or SQL CTEs
- CFSpreadsheet → openpyxl or pandas Excel integration

## ColdFusion → Node.js/Express

### Feasibility: Full Rewrite
- Tag-based CFML has no structural mapping to JavaScript
- CFScript (script-based CFML) is closer to JS but still requires full rewrite
- Async paradigm shift: CF is synchronous, Node.js is event-loop async

### What Maps Reasonably
- CFC methods → Express route handlers or NestJS controllers
- CF structs → JavaScript objects (similar dynamic nature)
- `<cfquery>` → Knex.js or Sequelize queries

### Key Risks
- CF developers may not have JavaScript/async experience
- Error handling paradigm shift (CF try/catch → Promise/async-await)
- CF's built-in features (PDF, email, spreadsheet) need npm package equivalents

## Framework-Specific Migration Considerations

### Fusebox Applications
- Circuits are logical modules — map each circuit to a Python package or FastAPI router
- `fusebox.xml.cfm` defines the application structure — use as migration blueprint
- Circuit-to-circuit dependencies map to package-to-package dependencies

### FW/1 Applications
- Convention-based structure maps well to FastAPI convention
- `controllers/` → FastAPI routers
- `model/services/` → Python service classes
- `model/beans/` → Pydantic models or dataclasses
- DI/1 bean factory → Python dependency injection (FastAPI's `Depends()`)

### CFWheels Applications
- Rails-inspired MVC maps cleanly to any MVC framework
- Model validations → Pydantic validators
- ORM models → SQLAlchemy models
- Routes → FastAPI path operations
- Plugins → Python packages

### ColdBox Applications
- Most modular CF framework — modules map to Python packages
- WireBox DI → FastAPI Depends() or dedicated DI library
- Interceptors → FastAPI middleware
- ColdBox modules are the best CF starting point for microservice decomposition

## Key Risks

1. **Implicit type coercion** (HIGH): CF's loose typing masks bugs that surface in Python.
   Mitigation: Add mypy strict mode, comprehensive type annotations, edge-case tests.
2. **Session state** (MEDIUM): CF sessions are server-local and sticky.
   Mitigation: Externalize to Redis from the start.
3. **Feature parity gaps** (MEDIUM): CF has built-in PDF, email, spreadsheet, image
   manipulation. Each needs a Python library equivalent.
4. **Developer retraining** (HIGH): CF developers need Python training.
   Mitigation: Pair programming, code reviews, incremental migration.
5. **Database coupling** (MEDIUM): Inline SQL in CF views creates hidden data dependencies.
   Mitigation: Extract all data access to a service layer before migration.
