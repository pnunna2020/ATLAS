---
name: incident-response
description: >
  Diagnose and respond to incidents in FAA applications (both modernized and in-sustainment). Symptom-driven investigation producing structured incident reports. Use during ST.1 or P6.2 operations. Triggers on incident, outage, error investigation, or service disruption.
agent: sonnet
---

# Incident Response Runbook
## Symptom → Investigation → Resolution

### High CPU / Memory
1. Check Datadog APM for top consumers
2. Identify: Is it a specific request pattern or background process?
3. If request pattern: Check for missing pagination, N+1 queries, memory leaks
4. If background: Check for stuck batch jobs, runaway cron, log accumulation
5. Resolution: Scale up (immediate), fix root cause (follow-up PR)

### API Errors (5xx)
1. Check Gravitee analytics for error rate and affected endpoints
2. Check downstream dependencies (DB, external services)
3. If DB: Check Aurora/Oracle connection pool, query performance
4. If external: Check Solace/SWIM connectivity, external API status
5. Resolution: Circuit breaker activation, fallback response, escalation

### Data Inconsistency
1. Identify affected data domain and products
2. Check last successful data pipeline run
3. Compare source and target record counts
4. If migration-related: Check P4.4 migration logs for errors
5. Resolution: Re-run migration for affected records, validate

## Gotchas
- **Don't restart first, investigate first**: Restarting may destroy evidence
  of the root cause. Collect logs and metrics before any remediation.
- **Sustainment apps have different owners than modernized apps**: Check the
  Factory Configuration Registry for current ownership.

## Quality Rules
- [ ] Investigation follows the symptom-driven order (CPU/memory, API errors, data inconsistency) — not guessing
- [ ] Root cause evidence is collected BEFORE any remediation action (logs, metrics, traces)
- [ ] Incident report is structured: symptom, timeline, root cause, resolution, prevention recommendation
- [ ] App ownership is verified in Factory Configuration Registry before escalating to the wrong team
- [ ] Immediate remediation (scale up, circuit breaker) is separated from root cause fix (follow-up PR)
- [ ] Post-incident review is scheduled for any incident lasting more than 30 minutes

## Common Failure Modes
| Failure Mode | Symptom | Prevention |
|-------------|---------|------------|
| Restart-first investigation | Service restarted before collecting evidence; root cause unknown; incident recurs | Collect logs, metrics, and traces before any remediation action |
| Wrong ownership escalation | Incident for sustainment app escalated to modernization team or vice versa | Check Factory Configuration Registry for current app ownership before escalating |
| Missing downstream impact | Root cause fixed but downstream data consumers received corrupted data; secondary incidents | Trace impact to all downstream systems and data products before closing the incident |
| No post-incident review | Same incident recurs because prevention recommendations were never implemented | Schedule post-incident review for incidents >30 minutes; track prevention action items |

## Handoff Summary
When this skill completes, verify:
1. Root cause is identified with evidence (not just resolved by restart)
2. Incident report is complete with timeline, root cause, and resolution
3. Immediate remediation is in place
4. Follow-up PR for root cause fix is created or scheduled
Then proceed to: post-incident review, `cost-anomaly-investigation` if cost-related, or `patch-assessment` if a patch is needed
