---
name: cost-anomaly-investigation
description: >
  Investigate unexpected AWS cost spikes for modernized applications. Use during P6.2 operations. Triggers on cost spike, billing anomaly, cost investigation, or unexpected AWS charges.
agent: sonnet
---

# Cost Anomaly Investigation
## Purpose
When AWS costs spike for a modernized app, systematically identify the cause.

## Common Causes (check in order)
1. **Lambda concurrency explosion**: Check invocation count and duration
2. **Data transfer spike**: Check NAT Gateway and cross-region transfer
3. **Unoptimized queries**: Check Aurora Performance Insights
4. **Log volume explosion**: Check CloudWatch log ingestion
5. **Forgotten test environments**: Check for non-production resources still running
6. **DDoS or abuse**: Check WAF logs and Gravitee analytics

## Gotchas
- **NAT Gateway costs are the #1 surprise**: Modernized apps using Lambda in
  VPC incur NAT Gateway charges for every external call. This can be 3-5x
  the Lambda compute cost. Use VPC endpoints to avoid.
- **Datadog costs scale with metrics/logs**: Each new modernized app adds
  monitoring overhead. Budget for this in TCO projections.

## Quality Rules
- [ ] Investigation follows the 6-cause checklist in order — no skipping steps
- [ ] Root cause is identified with specific evidence (CloudWatch metrics, Cost Explorer data, or WAF logs)
- [ ] Remediation action is documented with expected cost reduction and timeline
- [ ] NAT Gateway costs are checked for all Lambda-in-VPC deployments — VPC endpoints recommended where applicable
- [ ] Monitoring overhead (Datadog, CloudWatch) is included in TCO projections for newly modernized apps
- [ ] Investigation report includes the anomaly detection trigger, timeline, root cause, and resolution

## Common Failure Modes
| Failure Mode | Symptom | Prevention |
|-------------|---------|------------|
| NAT Gateway cost surprise | Lambda-in-VPC costs 3-5x expected due to NAT Gateway charges for external calls | Use VPC endpoints for AWS services; budget NAT Gateway costs in TCO projections |
| Forgotten test environments | Non-production resources running 24/7 after testing completes; steady cost leak | Include environment cleanup in deployment checklist; tag all resources with environment and expiry |
| Log volume explosion | CloudWatch log ingestion costs spike after new app deployment with verbose logging | Set log levels appropriately for production; use log sampling for high-volume services |
| Root cause not identified | Cost spike attributed to "increased usage" without specific evidence; recurs next month | Require specific metric evidence for every root cause determination; verify with Cost Explorer drill-down |

## Handoff Summary
When this skill completes, verify:
1. Root cause is identified with specific evidence
2. Remediation action is documented with expected savings
3. TCO projections are updated if the anomaly reveals a systematic underestimate
4. Monitoring alerts are tuned to prevent recurrence
Then proceed to: `tco-analyzer` to update cost projections, and `environment-cleanup` if forgotten resources are the cause
