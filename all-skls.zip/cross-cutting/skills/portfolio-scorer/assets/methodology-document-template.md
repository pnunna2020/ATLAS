# Portfolio Scoring Methodology — <portfolio-id>

> Stakeholder-reviewable record of how this portfolio was scored at Rationalization Step 2. Every weight, aggregation choice, and threshold below can be challenged and re-run.

**Portfolio:** `<portfolio-id>`
**Scored date:** `YYYY-MM-DD`
**Methodology version:** `<semver>`
**Profile source:** `profiles/<client>/scoring.yaml` (verbatim path read at run time)

---

## 1. Aggregation Function

| Field | Value |
|---|---|
| Aggregation | `weighted-sum` \| `weighted-average` \| `weighted-geometric-mean` |
| Rationale | Why this aggregation fits the portfolio (see `references/aggregation-functions.md`) |

---

## 2. Dimensions

All dimension weights sum to 1.0 (including any profile-specific extensions). Scale direction below reflects whether a higher raw value is more favorable.

| Dimension | Weight | Scale (min–max) | Higher is better? | Source signal | Scoring rules |
|---|---|---|---|---|---|
| business-value | `<w1>` | 0–1 | yes | `catalog.business_criticality` + stakeholder assessment + user base size | mission-critical=1.0, business-critical=0.75, operational=0.5, admin=0.25 |
| technical-debt | `<w2>` | 0–1 | no | discovery-pass-3 quality + readiness score | normalized readiness, inverted |
| user-impact | `<w3>` | 0–1 | yes | discovery-pass-4 journeys + persona counts + accessibility baseline | weighted journey criticality |
| cost | `<w4>` | 0–1 | no | `tco-analysis.total_annual_cost` | min-max normalized across portfolio, inverted |
| redundancy | `<w5>` | 0–1 | no | `redundancy-matrix.composite_overlap` | per-app max overlap, inverted |
| modernization-complexity | `<w6>` | 0–1 | no | discovery-pass-1 structural analysis + integration surface | normalized complexity, inverted |

---

## 3. Registered Extensions (profile-specific)

Dimensions added via the Scoring Dimension Registry (`cross-cutting/extensibility/`). Leave table empty if none.

| Extension name | Weight | Source | Added by profile |
|---|---|---|---|
| e.g., accessibility-maturity | `<w>` | discovery-pass-4 wcag violation score | faa |

---

## 4. Heat-Map Bucket Thresholds

Default is tercile split across the scored portfolio on each axis. Override per profile if stated below.

| Axis | Low bucket | Medium bucket | High bucket |
|---|---|---|---|
| risk | bottom tercile of weighted `technical-debt + modernization-complexity` | middle tercile | top tercile |
| value | bottom tercile of `business-value + user-impact` | middle tercile | top tercile |
| readiness | bottom tercile of `1 - technical-debt` | middle tercile | top tercile |

---

## 5. Rank-in-Portfolio Rule

Apps are ranked by `weighted_composite` descending. Exact ties are broken by `application_id` ascending so reruns are byte-identical.

---

## 6. Change Log

| Version | Date | Change |
|---|---|---|
| 1.0.0 | `YYYY-MM-DD` | Initial methodology registration |
