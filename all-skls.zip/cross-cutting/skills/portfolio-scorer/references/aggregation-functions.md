# Aggregation Functions

The profile's `methodology.aggregation` field must be one of three values. The choice changes which apps rank highest — pick deliberately.

## weighted-sum (default)

`composite = Σ (weight_i * normalized_score_i)`

All dimensions matter at the margin; strength in one dimension can compensate for weakness in another. Simple, transparent, easiest to explain. Output range matches the weight budget (0–1 if weights sum to 1 and scores are normalized 0–1).

**Choose when:** the portfolio has heterogeneous apps where dimension trade-offs are expected.

## weighted-average

`composite = Σ (weight_i * normalized_score_i) / Σ weight_i`

Mathematically identical to weighted-sum when weights already sum to 1.0. Select explicitly when weights may not sum to 1.0 (e.g., partial dimension coverage across a portfolio subset) and you need normalized comparability across differently-scoped apps.

**Choose when:** some apps are scored on a dimension subset and results must stay comparable.

## weighted-geometric-mean

`composite = Π (normalized_score_i ^ weight_i)`

Penalizes zero or near-zero scores in any dimension — a single 0.0 pulls the composite to 0.0 regardless of other dimensions. Use when every dimension is required-to-pass.

**Choose when:** the client requires minimum thresholds across all dimensions and failure in one should dominate. FAA security-critical portfolios are a candidate.

## Anti-patterns

- **Do not mix aggregation per-app.** The portfolio uses one function; per-app switching makes ranks incomparable.
- **Do not change aggregation mid-wave.** Once a baseline scorecard hits a gate, preserve the aggregation across reruns of the same wave. New aggregation = new methodology version.
- **Do not default to geometric mean without cause.** It surprises stakeholders — apps with one weak dimension vanish from the top even when that dimension has low weight.
