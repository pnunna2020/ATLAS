# Dimension Signal Sourcing

Every scored dimension pulls its raw signal from a Discovery or Rationalization artifact. A score without an evidence citation is not auditable — populate `dimension_scores[].evidence[]` with `{artifact}:{section}:{finding-id}` entries.

| Dimension | Artifact | Field | Citation |
|---|---|---|---|
| business-value | `application-catalog-entry` | `business_criticality` + `user_base_size` + stakeholder notes | `application-catalog:business_criticality:<app-id>` |
| technical-debt | discovery-pass-3 `quality-risk-analysis` | `readiness_score`, vuln density, lint debt | `pass-3:readiness_score:<app-id>` |
| user-impact | discovery-pass-4 `ux-accessibility-analysis` | journey criticality, persona counts, WCAG baseline | `pass-4:journeys:<journey-id>` |
| cost | `tco-analysis` | `total_annual_cost` (license + infra + labor) | `tco-analysis:total_annual_cost:<app-id>` |
| redundancy | `redundancy-matrix` (Step 1) | row-wise max `composite_overlap` | `redundancy-matrix:composite_overlap:<app-id>` |
| modernization-complexity | discovery-pass-1 + integration graph | repo size, module count, integration surface | `pass-1:integration_surface:<app-id>` |

## Sourcing rules

- **One artifact per signal.** Dimensions drawing on two artifacts (business-value uses catalog + stakeholder notes) cite both in `evidence[]`.
- **Null is better than guessed.** When a signal is unavailable, set `raw_score: null` with a `notes` reason. Fabricated defaults poison rankings.
- **Extensions declare their own source.** Registered dimensions (`accessibility-maturity`, `regulatory-exposure`) carry a `source` path in the profile; cite that path at scoring time.
- **Inversions happen in scoring, not sourcing.** Record raw signals as measured (dollars, raw counts). Scale inversion for lower-is-better dimensions happens during normalization.
- **Citations must resolve.** The validator follows every `evidence[]` entry back; stale paths fail the run.
