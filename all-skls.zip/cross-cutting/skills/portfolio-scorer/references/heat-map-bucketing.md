# Heat-Map Bucketing

Every app is placed in `low | medium | high` buckets on three independent axes: risk, value, readiness. The placement rule must be documented in the methodology output so stakeholders can reproduce the bucketing.

## Default: tercile split

For each axis, rank apps on the axis score and split into thirds.

| Bucket | Range |
|---|---|
| low | 0–33.3rd percentile |
| medium | 33.3rd–66.6th percentile |
| high | 66.6th–100th percentile |

Tie-breaking: exact ties at a tercile boundary round toward the lower bucket.

## Axis definitions

| Axis | Composite source |
|---|---|
| risk | weighted sum of `technical-debt` + `modernization-complexity` (both lower-is-better, so higher composite = higher risk) |
| value | weighted sum of `business-value` + `user-impact` (higher-is-better) |
| readiness | `1 - technical-debt`, optionally blended with the discovery readiness score |

Axis composites default to the same weights used in the scorecard; profiles may override.

## Profile overrides

A profile can replace tercile thresholds with fixed cut-points when portfolio size is small and terciles are unstable.

```yaml
heat_map_bucketing:
  strategy: "fixed-thresholds"
  risk: { low: 0.33, high: 0.66 }
  value: { low: 0.33, high: 0.66 }
  readiness: { low: 0.33, high: 0.66 }
```

The methodology document must state which strategy was applied and the exact cut-points used.

## Recompute on portfolio change

Bucket assignments are portfolio-relative. When apps enter or leave, re-run `portfolio-scorer` — do not carry forward stale `heat_map_position` values. `scored_date` is authoritative.

## Anti-patterns

- **Fixed thresholds without profile declaration.** Stakeholders cannot tell whether methodology changed or the portfolio did.
- **Per-axis strategies mixed silently.** If risk uses terciles and value fixed cut-points, say so.
- **Bucketing before ranking completes.** Rank must be final first; otherwise mid-tier apps flap.
