# Extensibility — Registering a New Scoring Dimension

New dimensions are added through the Scoring Dimension Registry, not by editing this skill. See `cross-cutting/extensibility/` (section 4) for the registry contract.

## Required fields

| Field | Purpose |
|---|---|
| `name` | Kebab-case, unique across active dimensions (e.g., `accessibility-maturity`). |
| `weight` | Numeric 0–1. Adding a dimension requires re-weighting — the full set still sums to 1.0. |
| `scale` | `{min, max, higher_is_better}`. Declares normalization range and direction. |
| `source` | Artifact + field feeding the raw signal (e.g., `discovery-pass-4.wcag_violations`). |
| `scoring_function` | Named transform on the raw signal (e.g., `wcag_violation_weighted_score`). |
| `scoring_rules` | Optional threshold → score table for discrete signals. |

## Registration flow

1. Declare the dimension in `profiles/<client>/scoring.yaml` under `dimensions:` (or `extensions:` if supported).
2. Re-balance weights so the total equals 1.0 (validator rejects otherwise).
3. Ensure `source` resolves to an existing artifact schema — add the field to the Discovery pass schema first if the signal is new.
4. Add scoring-rule thresholds for discrete signals; `portfolio-scorer` reads them at run time.
5. Version the profile — `methodology.version` on the scorecard carries it forward for traceability.

## Run-time behavior

- Reads the profile's full dimension list (standard + extensions) and treats them identically.
- Records each extension in `methodology.extensions[]` so the methodology document exposes it explicitly.
- Validates the weight budget after extensions; fails closed if the sum diverges from 1.0 by ±0.001.

## Anti-patterns

- **Do not add a dimension in code.** If it is not registered, stakeholders cannot challenge it.
- **Do not skip re-weighting.** Rebalance or existing weights dilute silently.
- **Do not reuse a name.** Collisions cause ambiguity; the validator rejects duplicates.
