---
name: portfolio-scorer
description: >
  Apply the weighted scoring model to every application and produce transparent
  defensible scores. Extracts scoring from `disposition-recommender` into its own
  reviewable artifact so stakeholders can audit the methodology itself. Dimensions:
  business value, technical debt, user impact, cost, redundancy, modernization
  complexity. Weights read from the active client profile. Emits a portfolio
  scorecard per `schemas/rationalization/portfolio-scorecard.schema.json` and a
  standalone methodology document. Triggers on portfolio scoring, weighted score,
  disposition score, or @portfolio-scorer.
agent: opus
allowed-tools:
  - Read
  - Write
  - Grep
---

# portfolio-scorer

## Purpose
Execute Rationalization Step 2 by applying the weighted scoring model to every application in the portfolio and producing two first-class artifacts: (1) a per-app portfolio scorecard with raw and weighted composite scores, rank-in-portfolio, and heat-map bucket placement, and (2) a standalone methodology document stakeholders can review and challenge. This skill exists because the Rationalization README requires "the methodology itself is a formal artifact" — scoring logic buried inside `disposition-recommender` is not auditable. Extracting it here makes weights, aggregation, and scale direction reviewable before dispositions are proposed.

## Inputs
- Application catalog entries (JSON per `schemas/discovery/application-catalog-entry.schema.json`) — supplies `business_criticality`, user counts, stakeholder assessments
- Discovery Pass 1 structural analysis (JSON per `schemas/discovery/analysis-artifact.schema.json`) — feeds Modernization Complexity and catalog size metrics
- Discovery Pass 3 quality/risk analysis — feeds Technical Debt and readiness score
- Discovery Pass 4 UX/accessibility analysis — feeds User Impact (journeys, persona counts, accessibility baseline)
- TCO analysis (JSON per `schemas/rationalization/tco-analysis.schema.json`) — feeds Cost (TCO)
- Redundancy matrix (JSON per `schemas/rationalization/redundancy-matrix.schema.json`) — feeds Redundancy
- Client profile scoring config (YAML) — e.g., `profiles/faa/scoring.yaml` for FAA. Supplies weights, aggregation choice, scale direction, and registered extension dimensions
- Scoring Dimension Registry (`cross-cutting/extensibility/` — scoring section) — enumerates active and profile-specific dimensions

## Outputs
- Portfolio scorecard → `schemas/rationalization/portfolio-scorecard.schema.json` (scaffold: `assets/portfolio-scorecard-template.json`)
- Scoring methodology document → `assets/methodology-document-template.md` (per-run stakeholder-reviewable markdown)
- Portfolio heat map position per app (`risk_bucket`, `value_bucket`, `readiness_bucket`) — embedded in the scorecard under `apps[].heat_map_position`
- Portfolio summary (top/bottom scoring apps, dimension correlations) — embedded under `portfolio_summary`

## Methodology
1. Load the active client profile scoring config (default: `profiles/faa/scoring.yaml`). Capture `profile_source` path, dimension list, per-dimension `weight`, aggregation function, and scale direction.
2. Validate weight budget — sum of dimension weights plus registered extensions must equal 1.0. Reject the run with a clear error if it does not.
3. For each application in the catalog, source each dimension's raw signal per `references/dimension-signal-sourcing.md`. Every signal must cite its source artifact so the `evidence[]` array on the output is non-empty.
4. Normalize every raw signal onto the scale declared in the profile (typically 0–1, `higher_is_better` per dimension). Invert signals where the profile declares lower-is-better (e.g., TCO, Technical Debt).
5. Apply the aggregation function declared in the profile per `references/aggregation-functions.md` — default `weighted-sum`. Record both `raw_composite` (unweighted mean of normalized signals) and `weighted_composite` on each app.
6. Rank apps deterministically by `weighted_composite` descending. On exact ties, break by `application_id` ascending so reruns produce byte-identical output.
7. Assign heat-map bucket placement per `references/heat-map-bucketing.md`. Default is tercile split across the scored portfolio for each of risk, value, and readiness axes. Profile may override thresholds.
8. Emit the methodology document from `assets/methodology-document-template.md`, filling in `profile_source`, version, every dimension row, aggregation function name, scale direction, and registered extensions. This is the artifact stakeholders review.
9. Emit the portfolio scorecard JSON from `assets/portfolio-scorecard-template.json`. Populate `methodology`, every `apps[].dimension_scores[]` row with `evidence[]` citations, and `portfolio_summary`.
10. Self-check: every dimension in the profile appears in every app's `dimension_scores[]`; weighted composite equals the aggregation formula applied to weighted entries; rank ordering matches weighted composite ordering.

## Gotchas
- **Weights must come from the profile, not the skill.** Hardcoding weights silently drifts from the client's governance decisions. Always read `profiles/<client>/scoring.yaml` and record `profile_source` verbatim in the output methodology.
- **Scale direction matters.** TCO, Technical Debt, and Modernization Complexity are lower-is-better; Business Value, User Impact, and (inverse) Redundancy-avoidance are higher-is-better. Failing to invert the lower-is-better signals produces inverted rankings that look confident and are wrong.
- **Missing evidence breaks auditability.** A dimension score with no `evidence[]` citation cannot be defended to stakeholders. If a signal is unavailable, record `raw_score: null` plus a `notes` explanation — do not fabricate a default.
- **Weighted-geometric-mean punishes zeros hard.** Any dimension score of 0 yields a composite of 0 regardless of other dimensions. Only select geometric mean when that penalty is intentional (usually when every dimension is required-to-pass).
- **Methodology document is not optional.** Skipping the markdown methodology artifact leaves the scorecard looking like a black box even though the JSON contains the same numbers. Stakeholders review the markdown.
- **Rank ties must be broken deterministically.** Downstream `disposition-recommender` joins on `rank_in_portfolio`; non-deterministic ties cause flapping dispositions across reruns.
- **Heat-map buckets are portfolio-relative.** Default tercile splits shift as apps enter or leave the portfolio. Re-run the scorecard when the portfolio set changes; do not carry old bucket assignments forward.

## Quality Rules
- [ ] `methodology.profile_source` is a path that resolves to an existing file (e.g., `profiles/faa/scoring.yaml`) — no hardcoded weights.
- [ ] Sum of `methodology.dimensions[].weight` plus `methodology.extensions[].weight` equals 1.0 (tolerance ±0.001).
- [ ] `methodology.aggregation` is one of `weighted-sum`, `weighted-average`, `weighted-geometric-mean` and the value used is documented in the methodology markdown.
- [ ] Every `apps[].dimension_scores[]` entry has a non-empty `evidence[]` array with at least one `{artifact}:{section}:{finding-id}` citation, or an explicit `notes` reason if the signal is null.
- [ ] Every dimension listed in `methodology.dimensions[]` appears in every app's `dimension_scores[]` — no app skips a dimension.
- [ ] `apps[].weighted_composite` equals the declared aggregation function applied to that app's `dimension_scores[].weighted_score` values (recomputable).
- [ ] `apps[].rank_in_portfolio` is a dense 1-based ranking of apps by `weighted_composite` descending, with ties broken by `application_id` ascending — deterministic on rerun.
- [ ] Every app has `heat_map_position` populated with `risk_bucket`, `value_bucket`, and `readiness_bucket` each in `{low, medium, high}`, and the threshold rule used is stated in the methodology document.
- [ ] A methodology document (`methodology-document-*.md`) is produced alongside the scorecard JSON — both artifacts land in the same run folder.
- [ ] Scorecard validates against `schemas/rationalization/portfolio-scorecard.schema.json`.

## Common Failure Modes
| Failure Mode | Symptom | Prevention |
|---|---|---|
| Weights hardcoded instead of read from profile | Scorecard weights drift from profile governance; FAA-elevated security weight silently reverts to default | Read weights from `profiles/<client>/scoring.yaml` every run; record `profile_source` in the methodology output; fail closed if profile is missing |
| Methodology document not produced — scores look arbitrary to stakeholders | Stakeholders reject Step 2 output because they cannot inspect weights, aggregation, or scale direction without reading JSON | Always emit the methodology markdown alongside the scorecard; list every dimension, weight, scale, and source |
| Scale direction inverted for lower-is-better dimensions | Apps with the highest TCO or technical debt rank as the "best" modernization candidates | Declare `higher_is_better` per dimension in the profile; invert raw signals before weighting; unit-test with a known high-TCO app |
| Non-deterministic tie-breaking on rank | `disposition-recommender` produces different dispositions on successive reruns with the same input | Break exact `weighted_composite` ties by `application_id` ascending; document the rule in the methodology |
| Missing dimension evidence citations | Stakeholders cannot trace a score back to Discovery findings; challenges cannot be adjudicated | Require `dimension_scores[].evidence[]` non-empty or `notes` explaining null signal; validator rejects silent empties |

## Handoff Summary
When this skill completes, verify:
1. Both artifacts exist: the portfolio scorecard JSON and the methodology markdown document.
2. Weight sum equals 1.0, aggregation function is named, and `profile_source` resolves to a real file.
3. Every app has per-dimension scores with evidence citations, a weighted composite, a deterministic rank, and heat-map bucket placement.

Then proceed to: `disposition-recommender` using the scorecard as primary input for Step 3 disposition proposals, and gate `G-RR` for Rationalization review (methodology document is the stakeholder review surface).
