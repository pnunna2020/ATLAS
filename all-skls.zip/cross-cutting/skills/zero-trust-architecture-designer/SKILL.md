---
name: zero-trust-architecture-designer
description: >
  Design the Zero Trust topology per app and per suite across the CISA Zero
  Trust Maturity Model v2 (2023) pillars — Identity, Devices, Networks,
  Applications & Workloads, Data, plus cross-cutting Visibility & Analytics,
  Automation & Orchestration, Governance. Identity-aware, least-privilege,
  encrypted, and continuously verified by design. Runs on every app that
  produces target-architecture.json; no filter trigger. Emits two schema-
  validated artifacts — zero-trust-architecture.json (per-app pillar maturity
  targets + identity/network/application/data/device design + continuous-
  verification stack) and zero-trust-gaps-findings.json (per-pillar gap list
  vs the target maturity level, with closure options). SOO §6.1.1.1.3
  explicitly requires Zero Trust alignment; this skill produces the artifact
  the assessors reference. Triggers on zero trust architecture, ZTMM
  alignment, micro-segmentation design, PEP/PDP pattern, continuous
  verification design, or @zero-trust-architecture-designer.
agent: sonnet
allowed-tools:
  - Read
  - Write
  - Grep
  - Bash
validation_commands:
  - "python -m olympus.validators.schema_validator zero-trust-architecture.json"
  - "python -m olympus.validators.schema_validator zero-trust-gaps-findings.json"
supported_stacks:
  - aws-govcloud
  - fedramp-moderate
  - fedramp-high
  - public-facing
  - internal-agency
anti_target_stacks:
  - static-site
  - pure-cdn-asset
failure_classes:
  - maturity-target-inflation
  - pillar-skip
  - continuous-authn-vs-verification-confusion
  - over-claiming-optimal-data-without-cloudhsm
  - service-mesh-without-justification
benchmark_tags:
  - architecture-zero-trust
  - cisa-ztmm-alignment
  - soo-theme-c-zero-trust
---

# zero-trust-architecture-designer

## Purpose
Own the Zero Trust architecture step in the Architecture phase. Every app
produces a `target-architecture.json`; this skill reads that plus the FedRAMP
tier and converts it into a per-pillar maturity declaration aligned with the
CISA Zero Trust Maturity Model v2 (April 2023). The output fixes target
maturity per pillar (Traditional / Initial / Advanced / Optimal), the AWS
GovCloud service choices that realize each pillar, and a per-pillar gap
list against the target — all of which feed `nist-control-automation-mapper`
(AC-4 information flow, SC-7 boundary, IA-2 authentication maturity land
here), `aws-govcloud-landing-zone-designer` (micro-segmentation at the VPC /
Transit Gateway layer), and the cATO dashboard. SOO §6.1.1.1.3 Theme C
explicitly names Zero Trust alignment; SOO Objective 6 covers the cyber /
cATO thread. Without this skill the ZT story is prose-only and does not
survive independent assessment — the assessors want a pillar-level maturity
declaration, a service-level realization, and a time-bounded remediation
plan for the gaps.

## Inputs
- `target-architecture.json` (per app) — compute, data, networking, identity
  inventory. Drives which pillar options are feasible (e.g., if the app has
  no service-mesh, Applications pillar Optimal via per-request authz needs
  a service-mesh decision added).
- `ato-boundary-analyzer.json` — FedRAMP tier per app. IACRA, RMS, DMS are
  High; AMCS, MedXPress, CHAPS, CPDSS, DIWS (MSS suite) are Moderate. Tier
  drives default maturity targets — High defaults to Advanced or Optimal
  across Identity/Data, Moderate can stop at Advanced.
- `aws-govcloud-landing-zone.json` — OU and VPC topology; Transit Gateway
  attachments inform Network pillar micro-segmentation options.
- Client-profile compliance config (`profiles/faa/compliance.yaml`) — FAA
  identity constraints (PIV for staff, Login.gov for public), endpoint-
  management program (device pillar inheritance).
- CISA ZTMM v2 (2023) mapping reference —
  `references/cisa-ztmm-v2-mapping.md` (bundled) — per-pillar maturity-level
  definitions, the AWS GovCloud services that implement each level, and
  FAA-specific considerations.
- Prior-wave `zero-trust-architecture.json` if any — to diff targets rather
  than regenerate.

## Outputs
- `zero-trust-architecture.json` per app:
  - `app_id`, `fedramp_tier`.
  - `maturity_targets` — per pillar target: `identity`, `devices`,
    `networks`, `applications`, `data`, `visibility_analytics`, `automation`,
    `governance`. Each value is one of `traditional | initial | advanced |
    optimal`. Default rules: High apps target Advanced minimum on all five
    data-path pillars; public-facing High apps (IACRA) target Optimal on
    Identity; Tier-1 data apps (RMS airman PII) target Optimal on Data.
  - `identity_design` — `{primary_idp (iam-identity-center | cognito | both),
    federation[] (login.gov | piv-via-adfs | pingfed), mfa_enforcement
    (mandatory | risk-based | opt-in), privileged_access_mgmt (identity-
    center-jit | cyberark | none), continuous_risk_scoring (cognito-
    advanced-security | none)}`.
  - `network_design` — `{microsegmentation_strategy (transit-gateway-per-
    suite | vpc-per-subsystem | security-group-tiers), east_west_encryption
    (mtls-service-mesh | vpc-lattice-tls | tls-app-layer), egress_inspection
    (network-firewall | palo-alto-vm | cloud-waf-only), vpc_endpoints[]
    (service, routing), zero_trust_network_access (zscaler | cloudflare-
    access | session-manager)}`.
  - `data_design` — `{encryption_rest_service (kms | cloudhsm),
    encryption_transit_policy (tls-1.2-fips | tls-1.3),
    data_classification_scheme (cui | sbu | pii | phi | public),
    dlp_strategy (macie-only | macie-plus-symantec | purview-for-saas),
    key_management (kms-cmk-rotation | cloudhsm-cluster)}`.
  - `application_design` — `{workload_identity (irsa | iam-roles-anywhere),
    service_mesh (istio | app-mesh | none), per_request_authz (opa |
    cognito-custom | amazon-verified-permissions), api_gateway_policy
    (jwt-authorizer | waf-plus-authorizer | none), secret_management
    (secrets-manager | parameter-store)}`.
  - `device_design` — `{mdm_target (agency-intune | jamf | inherited),
    posture_check (session-manager-compliance | none),
    byod_allowed (true | false)}`.
  - `continuous_verification_stack` — `{signals (cloudtrail | guardduty |
    security-hub | custom-app-logs), decision_point (opa | amazon-verified-
    permissions | cognito-risk-engine), enforcement_point (api-gateway |
    app-layer-middleware | service-mesh-sidecar)}`.
- `zero-trust-gaps-findings.json`:
  - `app_id`, `per_pillar_gaps[]` — `{pillar, current_level, target_level,
    gap_description, proposed_closure, estimated_effort_weeks,
    blocks_cato (true | false)}`.
  - `portfolio_hot_spots[]` — pillar × app combinations where multiple apps
    share the same gap (e.g., every app missing a service mesh).
- Schema-validation reports sibling to each artifact.

## Methodology
1. Read `target-architecture.json` and `ato-boundary-analyzer.json` for the
   app. Fix `fedramp_tier` from the boundary analyzer — do not infer from
   service selection.
2. Set `maturity_targets` per pillar using the tier default, then override:
   - Identity: default Advanced; public-facing High (IACRA) override to
     Optimal; internal-only with PIV staff-only can stop at Advanced.
   - Devices: default Initial for agency-managed endpoints (MDM inherited
     from FAA); target Advanced only when endpoint posture signals flow
     into continuous verification — rare today.
   - Networks: default Advanced for Moderate, Optimal for High with multi-
     suite separation (RMS subsystems CAIS/AADOCS/IMS/AR need Optimal via
     VPC-per-subsystem).
   - Applications & Workloads: default Advanced; Optimal requires per-
     request authz and usually a service mesh — only justify for High
     apps with cross-service east-west traffic.
   - Data: default Advanced for Moderate (KMS + FIPS endpoints); Optimal
     for High with Tier-1 data (airman PII, medical) requires CloudHSM
     (FIPS 140-3 Level 3) — target Optimal only when the cost is justified.
   - Visibility & Analytics: default Advanced (Security Hub aggregator +
     GuardDuty + Security Lake); Optimal adds SIEM + behavior analytics.
   - Automation & Orchestration: default Advanced (EventBridge + Lambda
     playbooks for Security Hub findings); Optimal adds SOAR integration.
   - Governance: default Advanced (Audit Manager + cATO dashboard); Optimal
     adds OSCAL continuous feed.
3. Design `identity_design`. For public apps, Cognito as the primary IdP
   with Login.gov federation (SAML or OIDC per Login.gov partner guide).
   For staff, IAM Identity Center with PIV federation from agency ADFS /
   PingFed. MFA is mandatory for all privileged access; risk-based MFA
   (Cognito advanced security) acceptable for low-risk public flows.
   Privileged Access Management via Identity Center Just-In-Time access is
   sufficient for most apps; Tier-1 apps may add a PAM vault (CyberArk,
   out-of-scope for this skill).
4. Design `network_design`. Micro-segmentation strategy depends on the
   suite shape: RMS has four subsystems (CAIS, AADOCS, IMS, AR) and must
   isolate them with per-subsystem VPCs or at minimum per-subsystem Transit
   Gateway attachments; MSS apps can share a suite-VPC with security-group
   tiers. East-west encryption via service mesh mTLS for Optimal; VPC
   Lattice TLS for Advanced; TLS-at-app-layer only acceptable when a mesh
   is not justified. Egress inspection via Network Firewall in the
   dedicated egress VPC (see `aws-govcloud-landing-zone-designer`).
5. Design `data_design`. Encryption at rest uses KMS with CMK and automatic
   rotation for all apps; High-tier apps with Tier-1 data (RMS, IACRA,
   DMS) evaluate CloudHSM cluster for keys wrapping airman PII / medical.
   Encryption in transit policy pins TLS 1.2 with FIPS cipher suite at
   minimum; TLS 1.3 where all clients support it. Data classification
   scheme must align with the FedRAMP data-type taxonomy (CUI / SBU / PII /
   PHI / public) and match what Macie jobs are configured to find. DLP
   strategy depends on where the data lives — Macie handles data in S3;
   SaaS-based editing (SharePoint, O365) needs a separate tool (Purview).
6. Design `application_design`. Workload identity uses IRSA (IAM Roles for
   Service Accounts) for EKS workloads and IAM Roles Anywhere for non-AWS
   compute; never static credentials. Service mesh (Istio on EKS, App Mesh
   for ECS) only when east-west traffic warrants per-request authz — justify
   the operational overhead per app. Per-request authz via OPA (Open Policy
   Agent) sidecars for service mesh, Amazon Verified Permissions for API
   Gateway, or Cognito custom authorizers for simpler cases.
7. Design `device_design`. Device pillar typically inherits from the FAA
   agency endpoint-management program — record inheritance and move on. A
   BYOD flag should always be explicit; most FAA apps will be false.
   Posture-check integration (Session Manager compliance) is optional.
8. Assemble `continuous_verification_stack`. Signals (CloudTrail events,
   GuardDuty findings, custom app logs), decision point (where a policy
   is evaluated — OPA, Verified Permissions, Cognito risk engine), and
   enforcement point (where the decision is applied — API Gateway
   authorizer, app-layer middleware, service-mesh sidecar). Continuous
   verification means per-request evaluation, not per-session; do not
   conflate the two.
9. Compute the gap list. For each pillar where `current_level` is below
   `target_level`, emit a gap finding with a concrete closure (service to
   adopt, config to add, integration to build) and an effort estimate in
   weeks. Flag `blocks_cato: true` only when the gap is a FedRAMP control
   mapped to the cATO dashboard (Identity and Data gaps usually qualify).
10. Validate both artifacts. Check: every pillar in `maturity_targets`
    carries a value; target levels respect tier defaults (Moderate apps
    do not target Optimal across all pillars without justification); any
    Optimal Data target on a High-tier Tier-1 app lists CloudHSM.

## Tech-Stack Dispatch

| Trigger | Key patterns |
|---|---|
| `fedramp_tier: high` + public-facing | Identity Optimal (Cognito + Login.gov + WebAuthn + risk scoring); Network Advanced+ (WAF + CloudFront + API Gateway + VPC endpoints + no direct internet to compute); Applications Advanced (per-request authz via OPA / Verified Permissions) |
| `fedramp_tier: high` + internal (staff-only) | Identity Optimal (PIV for staff + IAM Identity Center + JIT); Networks Optimal (micro-segmented VPCs per subsystem, TGW, zero egress by default); Data Optimal (CloudHSM for FIPS 140-3 Level 3) |
| `fedramp_tier: moderate` + shared suite | Identity Advanced (Cognito shared + shared OPA policies); Applications Advanced (App Mesh or VPC Lattice for east-west); Data Advanced (KMS + FIPS endpoints) |
| `target-architecture includes saas-editing` | Data pillar needs separate DLP (Purview / Symantec) alongside Macie — flag as a finding if missing |
| `target-architecture includes multi-region` | Continuous verification must be region-aware; signals aggregate cross-region in Security Hub |

Detection is mechanical: the tier and architecture shape drive the default
matrix; per-app overrides capture the nuance.

## Companion Technologies

The core methodology above targets AWS GovCloud Zero Trust using native
services. Two external integration patterns recur in the FAA portfolio and
are documented in companion references only if created as distinct files —
for this initial version they are collapsed into
`references/cisa-ztmm-v2-mapping.md`:

- Login.gov federation for public-facing apps (SAML / OIDC attribute map).
- PIV via ADFS / PingFed federation for staff apps (x509 subject extraction).

## Gotchas
- **ZTMM is a maturity model, not a checklist.** Not every app needs Optimal
  across all pillars. Traditional → Initial is already a huge lift for
  legacy; target Advanced realistically for Moderate apps and reserve
  Optimal for High + Tier-1 data combinations.
- **Optimal Data pillar requires CloudHSM for Tier-1 apps.** KMS is
  FIPS 140-2 (Level 1/2 depending on key type); CloudHSM is FIPS 140-3
  Level 3. For airman PII / medical, either deploy CloudHSM or document
  the accepted risk explicitly — do not claim Optimal on plain KMS.
- **Service mesh is operational overhead.** Istio and App Mesh both add a
  control-plane dependency and sidecar CPU / memory overhead. Justify per
  app — an internal-only Moderate app with 2 services does not need a
  mesh; a High app with 15 services and east-west PII flow does.
- **Login.gov integration has specific attributes.** SAML partner must
  request the right attribute set (email, verified-at, IAL/AAL level,
  decorated identifier) and map them to Cognito. A generic SAML config
  misses attributes and breaks continuous verification.
- **PIV via ADFS federation has specific IAM Identity Center config.** The
  x509 subject must map to an Identity Center principal; attribute mapping
  rules differ from SAML-with-email. Test with a dev PIV card before go-
  live.
- **Micro-segmentation in GovCloud has quota constraints.** VPC endpoint
  quotas (50 per VPC default), security group rule counts, Transit Gateway
  route table entries — the Optimal design can bump quotas. Pre-flight the
  quotas with the landing-zone designer.
- **Continuous verification is not continuous authentication.** Continuous
  authentication is about keeping the session alive (re-authenticating);
  continuous verification is per-request evaluation of the access
  decision. The latter is what ZTMM Optimal requires. Confusing the two
  is a common review-comment.
- **Data classification scheme must match the FedRAMP data-type taxonomy.**
  CUI / SBU / PII / PHI / public — use those labels. Inventing a custom
  scheme (e.g., "sensitive", "restricted") disconnects from the Macie
  findings and the SSP data-type inventory.
- **DLP strategy for SaaS-based editing is separate from in-app data.**
  Macie covers S3; SharePoint / O365 needs Microsoft Purview or Symantec.
  If the app reports documents live in SharePoint, the Data pillar design
  must name the SaaS DLP tool or mark it a gap.
- **Device pillar usually inherits from the agency.** FAA endpoint
  management program (Intune / Jamf) is agency-wide; an app-level device
  pillar declaration should cite the inherited program and not re-invent.
- **Workload identity should be preferred universally over static
  credentials.** IRSA for EKS, IAM Roles Anywhere for non-AWS, IAM roles
  on EC2 — never access keys baked in. A single long-lived access key in
  the architecture is a gap regardless of the pillar target.
- **Per-request authz policies must be versioned.** OPA policies and
  Verified Permissions policies go into Git, not a console. The policy
  repository is an artifact `continuous-compliance-orchestrator` hashes
  for evidence.

## Quality Rules
- [ ] Every pillar in `maturity_targets` carries a value from the enum
      `traditional | initial | advanced | optimal`; no blanks.
- [ ] High-tier apps target minimum Advanced on Identity, Networks,
      Applications, Data, and Visibility & Analytics; public-facing High
      apps target Optimal on Identity.
- [ ] Any `data.encryption_rest_service: cloudhsm` appears only on
      High-tier apps with Tier-1 data; any Optimal Data target without
      CloudHSM carries an explicit `accepted_risk` note.
- [ ] Every federation entry in `identity_design.federation[]` lists a
      concrete protocol (SAML 2.0 or OIDC) and the partner
      (`login.gov`, `piv-via-adfs`, `pingfed`).
- [ ] `network_design.microsegmentation_strategy` aligns with
      `aws-govcloud-landing-zone-designer` topology; a mismatch is a
      cross-artifact error.
- [ ] `continuous_verification_stack.decision_point` and
      `enforcement_point` are both filled; a continuous verification stack
      without an enforcement point is not continuous verification.
- [ ] `zero-trust-gaps-findings.json.per_pillar_gaps[]` carries at least
      one gap per pillar where current_level < target_level; no silent
      closures.
- [ ] `blocks_cato` is true only for gaps mapping to a control in the
      cATO dashboard; not every gap blocks cATO.
- [ ] Both artifacts validate against their schemas; validator reports
      show `status: pass`.

## Common Failure Modes
| Failure Mode | Symptom | Prevention |
|---|---|---|
| Maturity target inflation (all Optimal everywhere) | Remediation plan bloats; timelines slip; credibility hit with assessor | Apply tier defaults; justify each Optimal target per pillar in writing |
| Pillar skip (visibility / automation / governance omitted) | SSP and cATO dashboard incomplete | ZTMM v2 has 8 pillars counting cross-cutting; emit all 8 always |
| Continuous-authn vs continuous-verification confusion | Reviewer flags imprecise language; redo | Use ZTMM v2 language verbatim; per-request evaluation is continuous verification |
| Optimal Data without CloudHSM | Cryptographic claim fails FIPS 140-3 Level 3 inspection | Either deploy CloudHSM or downgrade the target; do not claim what is not validated |
| Service mesh in design without justification | Operational overhead assumed but not budgeted; mesh deploy delays the app | Justify mesh per app based on east-west topology; small apps can skip |
| Micro-segmentation without quota pre-flight | Deploy fails on VPC endpoint / SG rule quotas | Coordinate with landing-zone designer on projected quotas before emitting Optimal network targets |

## Handoff Summary
When this skill completes, verify:
1. `zero-trust-architecture.json` exists per app with all 8 pillars covered.
2. `zero-trust-gaps-findings.json` lists every pillar gap versus target
   with a proposed closure and effort estimate.
3. Identity design names the concrete IdP and federation partners.
4. Data design explicitly addresses Tier-1 data encryption strategy
   (CloudHSM or accepted risk).
5. Continuous verification stack names signal source, decision point, and
   enforcement point.
6. Cross-artifact consistency with `aws-govcloud-landing-zone-designer`
   on micro-segmentation topology.

Then proceed to: `nist-control-automation-mapper` (AC-4, SC-7, IA-2, SC-13
rows consume this design), `continuous-compliance-orchestrator` (runtime
ingest of Zero Trust signals), and the cATO dashboard in Governance. The
next gate is **G-04b** (Security Architecture Review) where the Zero Trust
design and gap list must be accepted before the landing-zone build-out.

## References
- `references/cisa-ztmm-v2-mapping.md` — per-pillar maturity-level
  definitions, AWS GovCloud services that enable each level, and
  FAA-specific considerations per pillar.
- CISA Zero Trust Maturity Model v2 (April 2023) — `https://www.cisa.gov/zero-trust-maturity-model`
- FedRAMP Rev 5 Moderate and High baselines — `https://www.fedramp.gov/baselines/`
- Login.gov Partner Guide — `https://developers.login.gov/`
- Amazon Verified Permissions + Cedar — AWS documentation.
- `schemas/architecture/zero-trust-architecture.schema.json`.
- `schemas/architecture/zero-trust-gaps-findings.schema.json`.

## Changelog
- 0.1.0 (2026-05-06) — Initial skill for SOO §6.1.1.1.3 Theme C (ZT
  alignment) + Objective 6. Covers all 8 ZTMM v2 pillars with AWS GovCloud
  service mapping, per-app maturity targets driven from FedRAMP tier, and
  gap list with effort estimates. Supports the 8 FAA apps (IACRA, RMS,
  DMS High; AMCS, MedXPress, CHAPS, CPDSS, DIWS Moderate).
