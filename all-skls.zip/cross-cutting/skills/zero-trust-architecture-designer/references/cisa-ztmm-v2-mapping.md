# CISA Zero Trust Maturity Model v2 — AWS GovCloud Mapping for the FAA Portfolio

Scope: per-pillar maturity-level definitions (Traditional / Initial /
Advanced / Optimal) as published in CISA Zero Trust Maturity Model v2
(April 2023), the AWS GovCloud services that enable each level in an FAA
context, and FAA-specific considerations. Consumed by
`zero-trust-architecture-designer` when setting `maturity_targets` and
drafting the per-pillar design sections.

The model has five data-path pillars (Identity, Devices, Networks,
Applications & Workloads, Data) and three cross-cutting pillars
(Visibility & Analytics, Automation & Orchestration, Governance). All
eight must appear in the architecture artifact.

## Pillar 1 — Identity

### Maturity Levels

| Level | Definition | AWS GovCloud Realization |
|---|---|---|
| Traditional | Static password-based authentication; manual lifecycle | IAM local users; basic Cognito user pool; password-only |
| Initial | Some MFA for privileged; static attribute-based authorization | Cognito + SMS MFA; IAM Identity Center without federation |
| Advanced | Phishing-resistant MFA; centralized identity; federation to agency IdP | IAM Identity Center + SAML federation; Cognito + TOTP/WebAuthn; SCIM provisioning |
| Optimal | Continuous risk-based authentication; per-request authz on identity signals; identity attributes drive policy | Identity Center + PIV + JIT access; Cognito advanced security; Amazon Verified Permissions with identity-aware policies |

### FAA Considerations

- **Public-facing apps (IACRA, MedXPress)**: Cognito as primary IdP with
  Login.gov federation mandatory for SOO Objective 3 (citizen experience).
  Login.gov supports SAML 2.0 and OIDC; the partner configuration must
  request IAL2/AAL2 attributes to satisfy NIST 800-63-3 for the
  applicable data types.
- **Staff apps (RMS internal, CHAPS, CPDSS, DMS admin)**: IAM Identity
  Center federated to agency ADFS / PingFed for PIV-based authentication.
  x509 subject extraction → Identity Center principal. WebAuthn as a
  fallback for break-glass.
- **Privileged access**: JIT via Identity Center is the default pattern;
  Tier-1 apps may add a PAM vault (CyberArk) for ephemeral credentials
  into workload databases.
- **Continuous risk scoring**: Cognito Advanced Security (risk-based MFA)
  covers public flows; staff flows use Identity Center's conditional
  access plus SIEM correlation for anomaly-based step-up.

### Typical Target by App

| App | Target | Rationale |
|---|---|---|
| IACRA | Optimal | Public-facing High-tier; phishing target; citizen trust |
| RMS | Optimal | Dual SoR for airman certification; insider and nation-state threat surface |
| DMS | Advanced | Internal staff-only; PIV federation sufficient; JIT for elevated |
| AMCS | Advanced | Staff medical review; PIV + Login.gov dual path |
| MedXPress | Advanced (Optimal on MFA) | Public medical form submission; IAL2 required |
| CHAPS | Advanced | Staff-facing; PIV federation |
| CPDSS | Advanced | Staff-facing; PIV federation |
| DIWS | Advanced | Internal investigation workbench; PIV federation |

## Pillar 2 — Devices

### Maturity Levels

| Level | Definition | AWS GovCloud Realization |
|---|---|---|
| Traditional | No device inventory; unmanaged access | BYOD-like; no controls |
| Initial | Device inventory exists; some patch management | MDM (Intune / Jamf) inventory; basic posture check |
| Advanced | Posture-based access; managed devices only | MDM integration with Identity Center for access; Session Manager compliance |
| Optimal | Continuous device posture evaluation; device identity as an access signal | Device posture signals into Verified Permissions policies |

### FAA Considerations

- FAA endpoint management is an agency-wide program. Per-app device
  pillar typically inherits from the agency MDM (Intune on Windows,
  Jamf on macOS) rather than declaring its own.
- BYOD is rare for staff apps; public apps do not control the endpoint
  (pillar target should be Initial at best for public flows — device
  posture cannot be enforced on the citizen's device).
- Posture-based conditional access is a roadmap item for most FAA
  agencies; target Initial as baseline, Advanced only where posture
  signals actually flow to the policy engine.

### Typical Target by App

| App | Target | Notes |
|---|---|---|
| IACRA | Initial (public) + Advanced (staff side) | Citizen device unmanageable; staff via agency MDM |
| RMS | Advanced | Staff-only; posture via MDM |
| DMS | Advanced | Staff-only; posture via MDM |
| AMCS, CHAPS, CPDSS, DIWS | Advanced | Staff flows |
| MedXPress | Initial | Public submission; citizen device |

## Pillar 3 — Networks

### Maturity Levels

| Level | Definition | AWS GovCloud Realization |
|---|---|---|
| Traditional | Flat network; perimeter-only security | Single VPC; default SGs |
| Initial | Segmented networks; basic ingress / egress controls | Multi-VPC with VPC peering; Security Groups as tier |
| Advanced | Micro-segmentation; encrypted east-west; egress inspection | Transit Gateway per suite; VPC endpoints; Network Firewall; TLS 1.2 mandatory |
| Optimal | Fully micro-segmented with identity-aware ZTNA; zero implicit trust | VPC-per-subsystem; service-mesh mTLS; Verified Access / ZTNA |

### FAA Considerations

- RMS has four bounded contexts (CAIS, AADOCS, IMS, AR). Optimal network
  design isolates each into its own VPC with explicit TGW attachments
  and deny-by-default routing between.
- MSS suite can share a suite-VPC with security-group tiers for Moderate
  baseline; do not over-design micro-segmentation for Moderate apps.
- Egress inspection lives in a dedicated egress VPC with AWS Network
  Firewall (or Palo Alto VM-Series for FIPS 140-3 Level 3 egress
  filtering if required). See `aws-govcloud-landing-zone-designer`.
- Direct internet access to compute is never allowed; all public flows
  go through CloudFront + WAF + API Gateway.
- VPC Lattice provides application-layer service networking across VPCs
  without a full service mesh — Advanced option when mesh overhead is
  unjustified.
- Zero Trust Network Access (ZTNA) for admin access: AWS Verified Access,
  Systems Manager Session Manager (no SSH), or third-party (Zscaler,
  Cloudflare Access) for hybrid cases.

### Typical Target by App

| App | Target | Rationale |
|---|---|---|
| IACRA | Advanced | Single app; isolated VPC; WAF + API GW + VPC endpoints |
| RMS | Optimal | Multi-subsystem isolation mandatory |
| DMS | Advanced | Document imaging pipeline; VPC endpoints + egress inspection |
| AMCS, MedXPress, CHAPS, CPDSS, DIWS | Advanced | Shared suite-VPC with tier SGs; VPC Lattice for east-west |

## Pillar 4 — Applications & Workloads

### Maturity Levels

| Level | Definition | AWS GovCloud Realization |
|---|---|---|
| Traditional | Monolithic apps; perimeter security; coarse authz | Single EC2 stack; IAM at console only |
| Initial | Some app-level authz; inventoried workloads | ECS / EKS inventory; IAM roles; API Gateway authorizers |
| Advanced | Continuous authorization at session level; workload identity; SCA / SAST in pipeline | IRSA / IAM Roles Anywhere; API GW JWT authorizer; Inspector + CodeBuild SAST |
| Optimal | Per-request authorization; policy-as-code; service-mesh mTLS | OPA sidecars or Verified Permissions; Istio / App Mesh mTLS; signed container images |

### FAA Considerations

- Workload identity: IRSA for EKS, IAM Roles Anywhere for hybrid. Never
  static credentials in code or config.
- Service mesh (Istio on EKS, App Mesh on ECS) justified when east-west
  PII / PHI flow crosses 5+ services; otherwise VPC Lattice with IAM
  auth is sufficient.
- Per-request authz via OPA policies (bundle published to S3, fetched
  by sidecar / middleware) or Amazon Verified Permissions with Cedar
  policies. Policies versioned in Git; policy-hash in evidence feed.
- Supply chain: signed container images (Sigstore / Notary), SBOM
  generated via Inspector in CI, image scan on push to ECR.
- Secrets: Secrets Manager with automatic rotation for DB credentials;
  Parameter Store for non-secret config.

### Typical Target by App

| App | Target | Rationale |
|---|---|---|
| IACRA | Advanced (approaching Optimal) | Single-app surface; JWT authorizer sufficient; OPA optional |
| RMS | Optimal | Multi-subsystem east-west; mesh + OPA mandatory for cross-subsystem authz |
| DMS | Advanced | Pipeline-driven; workload identity + SAST; no mesh needed |
| MSS suite | Advanced | App Mesh or VPC Lattice for east-west between suite apps; Verified Permissions for per-request authz |

## Pillar 5 — Data

### Maturity Levels

| Level | Definition | AWS GovCloud Realization |
|---|---|---|
| Traditional | Limited encryption; no classification | Default encryption only; no Macie |
| Initial | Encryption at rest + transit; ad-hoc classification | KMS + TLS 1.2; manual tagging |
| Advanced | Classification-driven policies; DLP; consistent encryption | Macie automated classification; KMS CMK with rotation; S3 SSE-KMS; bucket policies enforce encryption |
| Optimal | Cryptographic protection matches sensitivity; tokenization / encryption gateways; DLP covers SaaS | CloudHSM (FIPS 140-3 Level 3) for Tier-1 data; Macie + Purview / Symantec; tokenization for PII |

### FAA Considerations

- FIPS compliance: KMS is FIPS 140-2 validated (140-3 pending per AWS
  roadmap); CloudHSM clusters are FIPS 140-3 Level 3. Tier-1 data
  (airman PII in RMS, medical in AMCS / MedXPress) should prefer
  CloudHSM or document accepted risk.
- Data classification scheme aligns with FedRAMP data types: CUI / SBU /
  PII / PHI / public. Macie jobs configured per classification; findings
  feed continuous-compliance evidence.
- DLP for SaaS editing (SharePoint, O365) requires Microsoft Purview or
  Symantec DLP alongside Macie — Macie does not see SaaS.
- Encryption in transit: TLS 1.2 with FIPS cipher suite at minimum;
  TLS 1.3 where supported. CloudFront security policy
  `TLSv1.2_2021` minimum; ALB policy `ELBSecurityPolicy-FS-1-2-Res-2020-10`
  for FIPS suites.
- Key management: CMK per app per environment; automatic rotation
  annually for KMS; CloudHSM cluster shared at suite-level when used.

### Typical Target by App

| App | Target | Key Management |
|---|---|---|
| IACRA | Advanced (Optimal on public PII) | KMS CMK; evaluate CloudHSM for airman PII |
| RMS | Optimal | CloudHSM cluster for airman PII + medical |
| DMS | Advanced (Optimal on documents) | KMS CMK; S3 Object Lock for compliance docs |
| AMCS, MedXPress | Advanced (Optimal on PHI) | CloudHSM for medical data in High environment |
| CHAPS, CPDSS, DIWS | Advanced | KMS CMK |

## Pillar 6 — Visibility & Analytics (cross-cutting)

### Maturity Levels

| Level | Definition | AWS GovCloud Realization |
|---|---|---|
| Traditional | Limited logging; siloed analysis | CloudTrail enabled but no aggregation |
| Initial | Centralized logging; basic dashboards | CloudWatch + CloudTrail org trail |
| Advanced | Cross-pillar correlation; SIEM integration; anomaly detection | Security Hub aggregator + GuardDuty + Security Lake + SIEM |
| Optimal | Behavioral analytics; real-time posture; identity + device + app signals correlated | SIEM + UEBA; cATO dashboard live feed |

### FAA Considerations

- Security Hub delegated admin in security-tooling account aggregates
  findings across all member accounts.
- Security Lake (native) or Splunk / Chronicle (ingested) is the
  SIEM layer. FAA typically layers one SIEM across agency apps.
- cATO dashboard consumes Security Hub findings + Audit Manager
  assessment results + custom app signals.

## Pillar 7 — Automation & Orchestration (cross-cutting)

### Maturity Levels

| Level | Definition | AWS GovCloud Realization |
|---|---|---|
| Traditional | Manual incident response; script-driven | Runbook docs; no automation |
| Initial | Some automated remediation | EventBridge + Lambda for common Security Hub findings |
| Advanced | Orchestrated response across pillars; automated playbooks | Security Hub automated response; SSM playbooks; EventBridge rules |
| Optimal | Self-healing infra; policy-as-code end-to-end; SOAR integration | SOAR (Phantom / XSOAR) + full IaC + pipeline automation |

### FAA Considerations

- EventBridge + Lambda automated response for common findings is baseline.
- SSM playbooks (Automation documents) for operational remediation.
- SOAR adoption is roadmap-level for most FAA agencies; target Advanced
  for most apps.

## Pillar 8 — Governance (cross-cutting)

### Maturity Levels

| Level | Definition | AWS GovCloud Realization |
|---|---|---|
| Traditional | Point-in-time audits; prose SSP | Manual SSP; annual audit |
| Initial | Some continuous monitoring; documented policies | CloudTrail + basic Config |
| Advanced | Continuous compliance feed; versioned policies | Audit Manager + Config conformance packs + cATO dashboard |
| Optimal | Policy-as-code; OSCAL SSP/SAR/POA&M continuously emitted | OSCAL pipeline; cATO dashboard with near-real-time attestation |

### FAA Considerations

- Audit Manager FedRAMP Moderate and High frameworks are pre-built; use
  them as the starting assessment.
- OSCAL component-definition models per app; SSP aggregated at portfolio
  level. FedRAMP 2024 guidance requires OSCAL POA&M.
- cATO dashboard is the Governance pillar's user-facing surface; lives
  under the Governance assembly line.

## Inheritance and Cross-Skill Handoff

| Pillar | Primary Hand-off Skill |
|---|---|
| Identity, Applications & Workloads | `nist-control-automation-mapper` (IA-2, IA-5, AC-3, AC-6) |
| Networks | `aws-govcloud-landing-zone-designer` (VPC topology, TGW, egress) + `nist-control-automation-mapper` (AC-4, SC-7) |
| Data | `nist-control-automation-mapper` (SC-8, SC-13, SC-28, MP family) |
| Devices | Inherited from agency MDM (document inheritance) |
| Visibility & Analytics | `continuous-compliance-orchestrator` (Security Hub, Security Lake) |
| Automation & Orchestration | Runbook registry (out-of-scope for this skill) |
| Governance | `oscal-ssp-writer` + cATO dashboard (under Governance assembly line) |

Each per-pillar design section in `zero-trust-architecture.json` should cite
the hand-off skill so downstream consumers can trace the signal flow end-
to-end.
