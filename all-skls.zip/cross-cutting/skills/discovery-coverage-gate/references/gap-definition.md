# Discovery Coverage Gap Definition

This matrix declares, for each `(token, finding-type)` pair, the Discovery
skill that must fire and the artifact that must be produced. The
`discovery-coverage-gate` uses this to detect silent skips caused by
registry-filter mismatches.

## Matrix

| Token (in `app_context`) | Required skill | Artifact produced | Severity if missing |
|---|---|---|---|
| `natural` or `adabas` or `copybook` | `mainframe-discovery-patterns` | `mainframe-discovery.json` | HIGH |
| `cobol` or `jcl` or `cics` or `bms` | `mainframe-discovery-patterns` | `mainframe-discovery.json` | HIGH |
| `sqlserver` or `tsql` | `sqlserver-discovery-patterns` | `db-archaeology.json` | MEDIUM |
| `oracle` or `plsql` | `oracle-discovery-patterns` | `db-archaeology.json` | MEDIUM |
| `sqlite` | `legacy-database-archaeologist` | `db-archaeology.json` | MEDIUM |
| `adabas` or `db2` | `legacy-database-archaeologist` | `db-archaeology.json` | HIGH |
| `classic-asp` | `dotnet-discovery-patterns` (classic-asp refs) | `application-catalog-entry.json` with archetype=`classic-asp` | MEDIUM |
| `vb6` | `dotnet-discovery-patterns` (vb6 refs) | `application-catalog-entry.json` with archetype=`vb6` | MEDIUM |
| `csharp` or `aspnet` or `aspnet-mvc` or `vbnet` | `dotnet-discovery-patterns` | `application-catalog-entry.json` | HIGH |
| `coldfusion` or `cfwheels` | `coldfusion-discovery-patterns` | `application-catalog-entry.json` | HIGH |
| `tiff` or `infoimage` | `tiff-corpus-assessor` | `tiff-corpus-assessment.json` | MEDIUM |
| `eworkflow` or `unisys` | `eworkflow-queue-validator` (NEW) | `eworkflow-state.json` | HIGH |
| `broker` or `entirex` | `broker-integration-mapper` | `integration-graph.json` has `broker` edge | MEDIUM |
| `tn3270` | `tn3270-flow-tracer` | `integration-graph.json` has `tn3270-scraping` edge | MEDIUM |
| `entity-framework` + `ado.net` (both) | `dual-dal-detector` (NEW) | `data-flow-trace.json` with `dal_style: mixed` | MEDIUM |
| `piv` or `saml` or `oauth` or `sso` or `login.gov` | `identity-landscape-analyzer` | `identity-landscape.json` | HIGH |
| (always) | `catalog-application` | `application-catalog-entry.json` | CRITICAL |
| (always) | `compliance-citation-mapper` | `compliance-citations.json` with `total > 0` OR authoritative `abstain` | HIGH |

## Multi-stack decomposition trigger

If ANY of the following hold, `portfolio-integration-mapper` must fire and
produce `integration-graph.json`:
- `>= 2` distinct tech-stack families detected
- `>= 3` top-level subsystem directories
- README explicitly names `>= 2` subsystems

Severity: HIGH.

## Shared-identity trigger

If the application belongs to a portfolio where a shared identifier
(`FTN`, `N-number`, `airman-cert-number`, etc.) is known to cross at least
two apps, `portfolio-redundancy-analyzer` must emit
`redundancy-matrix.json` with `shared_identities[]` listing the portfolio
peers. Severity: MEDIUM.

## Prescan unresolved (CRITICAL)

If `app_context.tech_stack_unresolved == "true"`, Discovery must not
proceed. All downstream skills would run without accurate filter inputs.
Severity: CRITICAL.

## How to update this matrix

Whenever a new token is added to `olympus/olympus/fsm/prescan.py` or a new
conditional-filter skill is added to `olympus/olympus/skills/registry.yaml`,
add a matching row here. The gate's value is only as good as this matrix.
