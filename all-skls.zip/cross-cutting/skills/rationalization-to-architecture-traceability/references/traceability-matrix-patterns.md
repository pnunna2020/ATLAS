# Traceability Matrix Patterns

Patterns and rules for building the cross-phase Rationalization →
Architecture trace matrix. Consumed by
`rationalization-to-architecture-traceability/SKILL.md`.

## Mapping Rules per Disposition

The seven-disposition taxonomy in CLAUDE.md fixes the mapping arity and
required target-element shape per disposition. Apply these rules in order
when building `trace_entries[]`.

### Retain (1-to-1, unchanged)
- `target_architecture_element` = same logical service name as the source
  capability; implementation unchanged.
- Evidence: disposition citation + architecture citation confirming the
  service is present without structural changes.
- Severity of unmapped case: `major` (Retain with no architecture row is
  a coverage gap, not a blocker — the service may already exist
  out-of-scope).

### Refactor (1-to-1, internal change only)
- `target_architecture_element` = same service name; internal refactor
  does not change the external contract.
- Evidence: disposition citation + architecture citation. If the
  architecture row also names a new stack identifier, that is a
  Rearchitect in disguise — re-route the row.
- Severity of unmapped case: `major`.

### Rearchitect (1-to-1, new service name + new stack)
- `target_architecture_element` = new service name (for example
  `iacra-cert-service` for IACRA's Rearchitect disposition).
- Architecture row MUST name a new stack identifier in its `runtime` or
  `implementation` field. An architecture row with the same stack as the
  source is a Refactor, not a Rearchitect — raise `disposition-stack-mismatch`.
- Severity of unmapped case: `blocker` (Rearchitect is high-cost; losing
  trace is a G-02 failure).

### Replatform (1-to-1, new runtime, same logical service)
- `target_architecture_element` = same logical service name on a new
  runtime (for example COBOL batch → AWS Mainframe Modernization).
- The stack identifier changes; the contract stays the same.
- Severity of unmapped case: `blocker`.

### Replace (1-to-1, replacement product)
- `target_architecture_element` = `replacement_service` (explicit field);
  the value names a COTS/SaaS product, a third-party service, or a retained
  sibling service.
- Evidence: procurement / integration artifact citation in addition to the
  disposition citation.
- Severity of unmapped case: `blocker`. "TBD" or empty is not acceptable.

### Consolidate (many-to-one)
- Multiple source `capability_id`s fan into one target `service_name`.
- Emit one row per source capability; all rows point at the same
  `service_name`.
- Target host MUST be resolved against the bounded-context map from
  `faa-domain-decomposition-designer`. Unresolved target = `unmapped`.
- Example: MSS CHAPS read-only role + MedXPress certain reads + AMCS core
  records → unified `medical-records-service`. Three source capabilities,
  one target, three rows.
- Severity of unmapped case: `blocker`.

### Retire (1-to-0)
- `target_architecture_element` = the literal string `"retired"`.
- Evidence: citation into `retirement-migration-plan.json` describing the
  retirement schedule, data-disposition, and user-migration plan.
- A Retire row with no retirement plan citation is a `retire-plan-missing`
  blocker.
- Source capability MUST NOT appear anywhere in the target service
  inventory — cross-check and raise `retire-leak` if it does.

## Arity Summary

| Disposition | Source : Target | Extra field required |
|---|---|---|
| Retire | 1 : 0 | retirement-plan citation |
| Retain | 1 : 1 | (none) |
| Refactor | 1 : 1 | (none) |
| Rearchitect | 1 : 1 | new stack identifier |
| Replatform | 1 : 1 | new runtime identifier |
| Replace | 1 : 1 | `replacement_service` |
| Consolidate | N : 1 | target host from bounded-context map |

Fan-out (one capability mapping across multiple bounded contexts) is a
separate dimension — the Medical Certification capability spans AMCS +
MedXPress + CHAPS + DIWS and emits four rows, one per contributing app.
Fan-out and Consolidate-fan-in can combine on the same row set; do not
collapse them.

## Severity Table for Gap Findings

| Scenario | Severity |
|---|---|
| Rearchitect / Replatform / Replace / Consolidate unmapped | blocker |
| Refactor / Retain unmapped | major |
| Orphaned architecture with no justification | critical |
| Orphaned architecture with cross-cutting justification | info |
| Retire leak (Retire disposition still ships as a service) | blocker |
| Replace with empty `replacement_service` | blocker |
| Consolidate with unresolved target host | blocker |
| GovCloud availability gap | critical |
| Rearchitect with no new stack identifier | major (→ re-route to Refactor) |
| Confidence below 0.3 floor | info (routed to unmapped) |

## Confidence Propagation Rules

`traceability_confidence = min(disposition_confidence,
architecture_evidence_confidence)`.

Architecture evidence confidence is set by the strength of the match:

| Architecture evidence type | Confidence |
|---|---|
| Named service with `{repo}:{file}:{line}` source citation | 1.0 |
| Named service with architecture-description citation only | 0.8 |
| Inferred-from-description (no named service, match by capability) | 0.7 |
| Reviewer-resolved (human confirmed in governance review) | reviewer-stated (typically 0.9+) |
| No match (unmapped candidate) | n/a — row routed to gaps |

The floor is 0.3. Below the floor, the row is omitted from
`trace_entries[]` and routed to `unmapped_capabilities[]` instead. This
prevents low-confidence noise from polluting the matrix while keeping
the signal visible in the gap file.

Never use `mean()` or `max()`. `min()` is the only defensible choice
when the gate consumes this as a consistency check.

## Evidence-Citation Conventions

Every `trace_entries[]` row carries at least two citations:
- One into the source disposition artifact:
  `disposition-recommendation.json:<line>` or
  `disposition-recommendation.json:capabilities:<capability_id>`.
- One into the target-architecture artifact or the retirement plan:
  `target-architecture.json:services:<service_name>` or
  `retirement-migration-plan.json:schedule:<entry_id>`.

Replace rows need a third citation into the replacement-service
procurement / integration evidence. Consolidate rows need a citation into
the bounded-context map from `faa-domain-decomposition-designer`.

Every finding in `traceability-gap-findings.json` has at least one
citation. Bare entity names without citations are auto-rejected by the
validator — the pattern is the same as
`business_rules_validator`'s citation rule: three segments, no
placeholders.

## Unmapped vs Orphaned Classification

Two disjoint failure modes, often confused:

- **Unmapped capability** — the Rationalization line decided (disposition
  exists) but the Architecture did not honor the decision (no target
  element). Root cause is typically architectural oversight or an
  intentional scope cut that was not documented. Remediation is to either
  add the target element or revise the disposition in Rationalization.
- **Orphaned architecture** — the Architecture line introduced a target
  element with no upstream disposition. Root cause is either legitimate
  cross-cutting scope (observability, audit) or scope creep. Remediation
  is either to cite a cross-cutting justification (reducing severity to
  info) or to add a corresponding disposition in Rationalization.

A `capability_id` or `service_name` must never appear in both arrays.
The validator enforces disjointness.

## Cross-App Fan-Out Example: Medical Certification

Medical Certification spans four apps in the MSS suite:
- AMCS (Aerospace Medical Certification Subsystem) — decision authority
- MedXPress — intake (pre-exam state)
- CHAPS — read-only role access
- DIWS — imaged supporting documents

The Rationalization line's Consolidate disposition for Medical
Certification emits four source capability rows (one per app). The
Architecture line proposes one unified `medical-records-service`. The
trace matrix emits four rows, all pointing at `medical-records-service`;
each carries its own per-app disposition evidence and per-app
integration evidence. Collapsing the four rows into one loses the
per-app audit trail and breaks the SOO §8.1 consistency check.

## GovCloud Availability Gap Detection

AWS GovCloud US does not host the full AWS service catalog. When a
Rearchitect / Replatform / Replace target names a service that is:
- Not available in GovCloud US at all, or
- Available in GovCloud but not at the app's FedRAMP tier (FedRAMP High
  for RMS/IACRA/DMS; FedRAMP Moderate for MSS suite)

then the row is `orphaned_architecture` with `severity: critical` and
failure class `govcloud-availability-gap`. Examples at time of writing
(re-verify at build time — the availability list changes):
- Aurora Serverless v2 — limited GovCloud availability; check region.
- EventBridge Scheduler — region-limited in GovCloud.
- Bedrock — partial model availability in GovCloud.
- Lambda@Edge — not in GovCloud US.

Remediation is to either pick a different target service (revise the
architecture), change the disposition (revise Rationalization), or
document a waiver (requires gate approval). Never silently proceed.

## Governance Gate Integration

This skill's output feeds two gates:

- **G-02 Rationalization Gate** — consumes
  `traceability-gap-findings.json` to confirm every disposition has a
  target (or a retirement plan, or an explicit unmapped waiver). A
  non-empty `unmapped_capabilities[]` with any `blocker` or `critical`
  finding blocks the gate.
- **G-DA Architecture Gate** — consumes
  `rationalization-traceability.json` as the cross-phase linkage
  evidence required by SOO Sub-factor 3 §6.1.1.1.3. Reviewers
  re-derive the matrix from the source artifacts and spot-check
  confidence propagation plus orphaned-architecture justifications.

SOO §8.1 Consistency Check is the authoritative reviewer lens. A
consistency failure is an evaluation-scoring failure, not a simple
re-work item. Treat the matrix as audit-grade evidence from day one.

## Anti-Patterns

- Synonym-mapping dispositions ("Modernize" → Rearchitect silently) —
  breaks the seven-disposition contract.
- Collapsing Consolidate fan-in into one row — loses per-source evidence.
- Absorbing orphaned architecture without justification — breaks §8.1.
- Using `mean(confidence)` instead of `min(confidence)` — inflates risk.
- Treating unmapped and orphaned as the same condition — they have
  different root causes and different remediations.
- Writing a Retire row whose target is the same service name as the
  source capability — that is a retain-in-disguise, not a Retire.
