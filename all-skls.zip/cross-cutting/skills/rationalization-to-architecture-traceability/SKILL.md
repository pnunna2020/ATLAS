---
name: rationalization-to-architecture-traceability
description: >
  Build the cross-phase trace matrix linking every Rationalization disposition
  to its Architecture realization (or its planned absence). Reads
  disposition-recommendation.json and target-architecture.json from the prior
  artifacts set; emits rationalization-traceability.json (one row per source
  capability, with disposition → target-architecture-element mapping) and
  traceability-gap-findings.json (unmapped capabilities plus orphaned
  architecture elements). Enforces the seven-disposition contract: Retire
  must not surface as a persistent service; Consolidate must cite the target
  host; Rearchitect and Replatform must name the new stack; Replace must
  identify the replacement service. Runs in the Architecture phase when both
  prior artifacts are present. Required by SOO Sub-factor 3 §6.1.1.1.3
  (Rationalization-to-architecture traceability). Triggers on cross-phase
  traceability, disposition-to-architecture mapping, rationalization audit,
  orphaned-architecture detection, or @rationalization-to-architecture-traceability.
agent: sonnet
allowed-tools:
  - Read
  - Write
  - Grep
phase: architecture
triggers:
  prior_artifacts_present:
    - disposition-recommendation.json
    - target-architecture.json
validation_commands:
  - "python -m olympus.validators.schema_validator rationalization-traceability.json"
  - "python -m olympus.validators.schema_validator traceability-gap-findings.json"
supported_stacks:
  - any
  - aws-govcloud
  - aws
  - azure-gov
anti_target_stacks:
  - no-rationalization-artifacts
  - no-target-architecture
  - static-site
failure_classes:
  - unmapped-disposition
  - orphaned-architecture
  - retire-leak
  - consolidate-host-missing
  - replacement-service-missing
  - govcloud-availability-gap
  - confidence-propagation-drop
benchmark_tags:
  - architecture-traceability
  - cross-phase-linkage
  - governance-gate-evidence
---

# rationalization-to-architecture-traceability

## Purpose
Produce the cross-phase trace matrix that proves every Rationalization
disposition has been honored (or deliberately excluded) in the target
Architecture, and conversely that every target-architecture element traces
back to a dispositioned source capability. SOO Sub-factor 3 §6.1.1.1.3 names
this as a required evidence artifact under Theme A (Current-State) / Theme B
(Target-State) consistency, and the Consistency Check in §8.1 of the SOO
Evaluation Criteria is the authoritative reviewer lens. Without this skill,
Architecture is free to drift: a Retire disposition can leak back as a
persistent service, a Consolidate decision can lose its target host, a
Rearchitect decision can fail to name the new stack, and reviewers have no
governance artifact to flag the divergence. This skill closes the loop by
emitting a machine-checkable matrix plus a governance-review gap list that
feeds the G-02 Rationalization Gate and the downstream Architecture gates.

## Inputs
- `disposition-recommendation.json` (from Rationalization) — one row per
  source capability with `capability_id`, `app_id`, `disposition` in
  `{Retire, Retain, Refactor, Rearchitect, Replace, Replatform, Consolidate}`,
  `disposition_confidence` (0..1), and disposition-evidence citations.
- `target-architecture.json` (from Architecture) — target service inventory
  with `service_name`, `service_type`, `owning_bounded_context`, `hosting`,
  `data_stores[]`, `integrations[]`, and evidence citations.
- `faa-domain-decomposition-designer` output (when present) — bounded-context
  mapping used to resolve Consolidate many-to-one fan-in.
- `retirement-migration-plan.json` (when present) — required evidence source
  for every Retire disposition's "target = retired" trace row.
- Client profile — `profiles/faa/profile.yaml` supplies the target cloud
  (AWS GovCloud), the FedRAMP tier band per app (High for RMS/IACRA/DMS,
  Moderate for MSS suite), and the disposition-confidence floor policy.
- Reference: `references/traceability-matrix-patterns.md`.

## Outputs
- `rationalization-traceability.json` — one `trace_entries[]` row per source
  capability. Each row carries `capability_id`, `app_id`, `disposition`,
  `disposition_confidence`, `target_architecture_element` (one of
  `service_name` | `"retired"` | `replacement_service`),
  `traceability_status` (one of `mapped | unmapped | orphaned_disposition |
  orphaned_architecture`), `traceability_confidence` (0..1, propagates from
  disposition_confidence per the rules in the reference), and
  `evidence_citations[]` (at least two: one into
  `disposition-recommendation.json:<line>` and one into
  `target-architecture.json:<line>` or the retirement-migration plan).
- `traceability-gap-findings.json` — two disjoint arrays:
  `unmapped_capabilities[]` (disposition exists, no target element) and
  `orphaned_architecture[]` (target element exists, no source disposition).
  Each entry carries `finding_id` (`TG-UM-NNN` / `TG-OA-NNN`), `severity`
  (`blocker|critical|major|minor|info`), `capability_id` or `service_name`,
  and at least one evidence citation. These are the governance-review items
  routed to G-02 and the Architecture acceptance review.
- Validator reports are written sibling to each artifact by
  `olympus.validators.schema_validator`; never hand-edit them.

## Methodology
1. Load `disposition-recommendation.json` and `target-architecture.json`. Pin
   the source-capability set (left side of the matrix) from the disposition
   rows; pin the target-service set (right side) from the architecture
   inventory. Do not attempt traceability if either file is absent — this
   skill is conditional on both.
2. For each row in `disposition-recommendation.json`, apply the mapping rule
   for its disposition (see `references/traceability-matrix-patterns.md`
   §Mapping Rules per Disposition). The seven rules differ by arity:
   Retain → 1-to-1 with unchanged service; Refactor → 1-to-1 with same
   service name, internal change; Rearchitect → 1-to-1 with new service
   name + new stack named; Replatform → 1-to-1 with same logical service on
   a new runtime; Replace → 1-to-1 with `replacement_service` field
   populated; Consolidate → many-to-one (multiple capabilities → one target
   host service); Retire → 1-to-0 with `target_architecture_element =
   "retired"` and evidence citing the retirement-migration plan.
3. Resolve Consolidate fan-in via the bounded-context map. When multiple
   capability_ids fan into one target service, emit one `trace_entries[]`
   row per source capability — each row points to the same
   `service_name` but carries its own disposition evidence. Fan-out is
   allowed only when a single capability maps across multiple bounded
   contexts (for example Medical Certification spanning AMCS + MedXPress +
   CHAPS + DIWS); each fan-out leg gets its own row.
4. Resolve every Retire disposition against `retirement-migration-plan.json`.
   The `target_architecture_element` MUST be the literal string `"retired"`;
   the row MUST cite the retirement plan as evidence. If the retirement plan
   is absent but Retire dispositions exist, emit a blocker finding — do not
   silently drop the rows.
5. Detect unmapped capabilities. A disposition row with no matching target
   element AND a disposition other than Retire is `traceability_status =
   unmapped`. Push it to `traceability-gap-findings.json.unmapped_capabilities[]`
   with severity `blocker` (Rearchitect/Replace/Replatform/Consolidate) or
   `major` (Refactor/Retain) — the reference has the full severity table.
6. Detect orphaned architecture. Every target service with no upstream
   disposition row is `orphaned_architecture`. Push it to
   `orphaned_architecture[]` with severity `critical`. The Architecture
   designer is permitted to introduce cross-cutting infrastructure services
   (for example a shared audit-log service) that legitimately have no
   single source disposition — those rows are `orphaned_architecture` with
   `severity: info` and a `justification` citation into the architecture
   evidence. Do not silently absorb them.
7. Detect the GovCloud availability gap. For every Rearchitect, Replatform,
   or Replace row whose target service names an AWS service that is not
   available in AWS GovCloud US for the app's FedRAMP tier, set
   `traceability_status = orphaned_architecture` and emit a finding with
   severity `critical`. The reference has the current gap list (Aurora
   Serverless v2, EventBridge Scheduler regional availability, etc.) but
   always re-check against the current GovCloud service availability page
   at build time; the list is volatile.
8. Propagate confidence. `traceability_confidence` = min(
   `disposition_confidence`, architecture-evidence confidence). When
   architecture evidence is a named service with a cited `{repo}:{file}:{line}`
   source, architecture-evidence confidence is 1.0; when it is an
   inferred-from-description match, use 0.7; when the match is
   reviewer-resolved, use the reviewer's stated confidence. The floor is
   0.3 — below that, emit the row with `traceability_status = unmapped` and
   route it to governance review.
9. Emit both artifacts. Validate against their schemas. Cross-check: every
   `capability_id` in `rationalization-traceability.json` appears in the
   source disposition file; every `service_name` (non-retired, non-replacement)
   appears in the target architecture file; every citation resolves to a
   real `{artifact}:{section}:{finding-id}` or
   `{repo}:{file}:{line}`. Dangling references are auto-reject.

## Gotchas
- **Retire must not surface as a persistent service.** The single most
  common regression is a Retire disposition whose capability still appears
  as a service in the target architecture (often because the same
  capability name was reused). Enforce the `target_architecture_element =
  "retired"` contract and cross-check the service inventory for the
  capability's historical surface area — if the Retire target still ships
  code, flag a `retire-leak` blocker.
- **Consolidate is many-to-one, not one-to-many.** Multiple source
  capabilities fan into one target host service; emit one row per source
  capability with all rows pointing at the same `service_name`. Collapsing
  the rows into one loses the disposition-evidence audit trail.
- **Rearchitect and Replatform differ in what must be named.** Rearchitect
  requires both a new service name AND a new stack identifier (for example
  "Java 17 on ECS Fargate, Aurora PG backed"). Replatform requires the
  same logical service name on a new runtime (for example COBOL batch on
  AWS Mainframe Modernization). Conflating them hides cost and risk
  signals the Rationalization gate relies on.
- **Replace requires a replacement_service.** The `replacement_service`
  field is mandatory and must cite a third-party product, a COTS/SaaS
  offering, or a retained sibling service. "TBD" is not a valid value;
  emit an `unmapped` finding instead.
- **Orphaned architecture is sometimes legitimate.** Cross-cutting
  infrastructure (observability, audit log, identity federation) may have
  no single source disposition. Those rows are `orphaned_architecture`
  with `severity: info` and a justification — never `blocker`. The
  reviewer must still see the row.
- **GovCloud service availability forces architecture orphaning.** A
  capability dispositioned Rearchitect whose target service is not
  available in AWS GovCloud US (or not available at the app's FedRAMP
  tier) is an architecture gap, not an unmapped capability. The
  `govcloud-availability-gap` failure class captures this; the remediation
  is to change either the disposition or the target service, not to
  silently proceed.
- **Bounded contexts can span multiple apps.** Medical Certification spans
  AMCS + MedXPress + CHAPS + DIWS; the trace must fan-out to one row per
  contributing app even when the target service is the same. Collapsing
  those rows hides the per-app disposition evidence.
- **Confidence propagation is min, not average.** Using the average
  inflates low-confidence dispositions into high-confidence trace rows;
  always use `min(disposition_confidence, architecture_evidence_confidence)`.
- **Disposition enum is the seven dispositions, exactly.** The CLAUDE.md
  file fixes the taxonomy: Retire, Retain, Refactor, Rearchitect, Replace,
  Replatform, Consolidate. Any other value in the disposition field is a
  schema violation — do not synonym-map ("Modernize" is not a
  disposition).
- **SOO §8.1 Consistency Check is the authoritative reviewer lens.**
  Reviewers will re-derive the matrix from the source artifacts and
  compare. Silent inclusions (orphaned architecture with no
  justification) and silent exclusions (unmapped capabilities absent
  from the gap file) both fail the consistency check.

## Quality Rules
- [ ] Every row in `trace_entries[]` has `capability_id` present in
      `disposition-recommendation.json.capabilities[].capability_id`.
- [ ] Every non-retired, non-replacement `target_architecture_element`
      resolves to a `service_name` present in
      `target-architecture.json.services[].service_name`.
- [ ] Every Retire row has `target_architecture_element = "retired"` AND
      at least one citation into `retirement-migration-plan.json`.
- [ ] Every Replace row has a non-empty `replacement_service` field and at
      least one citation into the replacement-service evidence.
- [ ] Every Consolidate row points at a `service_name` that appears at
      least twice in `trace_entries[]` (many-to-one contract).
- [ ] `traceability_confidence` is a float in [0.3, 1.0]; rows below 0.3
      are omitted from `trace_entries[]` and routed to
      `unmapped_capabilities[]` instead.
- [ ] `unmapped_capabilities[]` and `orphaned_architecture[]` are disjoint —
      no `capability_id` or `service_name` appears in both.
- [ ] Every finding in `traceability-gap-findings.json` has a `finding_id`
      matching `TG-UM-[0-9]+` or `TG-OA-[0-9]+`, a severity from the enum,
      and at least one evidence citation.
- [ ] Both artifacts pass their schemas with zero errors; validator reports
      show `status: pass`.

## Common Failure Modes
| Failure Mode | Symptom | Prevention |
|---|---|---|
| Retire leak (dispositioned Retire still ships as a persistent service) | Target architecture contains a service whose logical surface matches a Retire row | Cross-check service inventory against Retire rows; enforce `target_architecture_element = "retired"` and cite the retirement plan |
| Consolidate host missing (target host not named) | Consolidate row with `target_architecture_element` empty or "TBD" | Require a resolved `service_name` from the bounded-context map before emitting the row; fail to `unmapped` otherwise |
| Replacement service missing (Replace row with no product) | `replacement_service` empty; reviewers cannot trace to the procurement artifact | Demand an explicit replacement-service identity citation; "TBD" is not acceptable |
| Orphaned architecture silently absorbed | Target services appear with no upstream disposition; reviewer has no audit signal | Emit every orphan as a finding; use `severity: info` only when a cross-cutting justification citation is present |
| GovCloud availability gap missed | Rearchitect target names a service unavailable in GovCloud US; discovered at deployment time | Cross-check every target service against the GovCloud availability list at build time; emit `govcloud-availability-gap` findings |
| Confidence inflated by averaging | Low-confidence disposition (0.4) paired with high-confidence arch (1.0) produces a trace confidence of 0.7, hiding the risk | Use `min()`, never `mean()`; the reference spells out the rule |
| Fan-out collapsed on cross-app bounded contexts | Medical Certification emits one row instead of four; per-app evidence lost | Emit one trace row per contributing app even when the target service is identical |
| Synonym-mapped disposition ("Modernize" coerced to Rearchitect) | Schema validation passes but disposition semantics drift | Treat any non-seven-disposition value as a schema violation; never silent-map |

## Handoff Summary
When this skill completes, verify:
1. `rationalization-traceability.json` exists next to the architecture
   artifacts, passes its schema, and every `capability_id` resolves into
   `disposition-recommendation.json`.
2. `traceability-gap-findings.json` exists; its two arrays are disjoint;
   every finding has an id, a severity, and at least one evidence citation.
3. No Retire row leaks into the target service inventory; no Consolidate
   row is missing its target host; no Replace row is missing its
   replacement service.
4. Every GovCloud-availability gap has been surfaced as a finding rather
   than silently proceeding.

Then proceed to the G-02 Rationalization Gate for governance review of
`traceability-gap-findings.json`, and to the Architecture acceptance
review (gate G-DA) which consumes `rationalization-traceability.json` as
the cross-phase linkage evidence required by SOO §6.1.1.1.3.

## References
- `references/traceability-matrix-patterns.md` — per-disposition mapping
  rules, severity table, confidence propagation, evidence-citation
  conventions, unmapped vs orphaned classification, and governance-gate
  integration.
- `specifications/decisions.md` — ADRs covering the seven-disposition
  taxonomy and the Rationalization-to-Architecture gate contract.
- `docs/testing/architecture-data-skill-assessment.md` §7 — the
  authoritative gap report identifying cross-phase traceability as a
  required Phase 2 skill.

## Changelog
- 0.1.0 (2026-05-06) — Initial skill. Emits rationalization-traceability.json
  and traceability-gap-findings.json. Enforces the seven-disposition
  mapping contract, Consolidate fan-in, Retire-leak detection,
  replacement-service identity, orphaned-architecture classification,
  GovCloud availability gap detection, and min-confidence propagation.
  Feeds G-02 and G-DA gates; cited by SOO Sub-factor 3 §6.1.1.1.3.
