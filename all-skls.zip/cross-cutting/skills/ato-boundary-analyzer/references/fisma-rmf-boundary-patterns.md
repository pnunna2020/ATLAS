# FISMA / NIST RMF / FedRAMP Boundary Patterns

Coverage for FISMA authorization boundaries, NIST Risk Management
Framework classification, FedRAMP inheritance, and common-control-
provider taxonomy.

## FISMA Impact Level

FIPS 199 categorizes federal systems by impact on confidentiality,
integrity, availability. The overall impact is the HIGHEST of the
three.

| Impact | Confidentiality | Integrity | Availability | Examples |
|---|---|---|---|---|
| **High** | Loss affects national security | Loss disables operations | Loss causes loss of life / major agency failure | Airmen registry (RMS), safety-critical apps |
| **Moderate** | Loss has serious effect | Loss causes significant inefficiency | Loss degrades operations | Most AAM apps, DMS |
| **Low** | Loss has limited effect | Loss minimal impact | Loss tolerable | Internal admin tools |

## NIST RMF 6-Step Cycle

NIST SP 800-37 Rev 2:

1. **Categorize** — determine impact level per FIPS 199.
2. **Select** — choose NIST SP 800-53 controls per impact level.
3. **Implement** — apply controls in the system.
4. **Assess** — independent assessor produces Security Assessment
   Report (SAR).
5. **Authorize** — Authorizing Official grants Authority to Operate
   (ATO) with conditions (POA&M).
6. **Monitor** — continuous monitoring + annual re-assessment.

Timeline: 6-18 months for a new system. Re-authorization (annual
or per OMB A-130 3-year cycle) is shorter.

## ATO Package Composition

Every authorization package contains:

| Artifact | Purpose |
|---|---|
| System Security Plan (SSP) | Narrative of the system + control implementation |
| Security Assessment Report (SAR) | Independent assessment findings |
| Plan of Action & Milestones (POA&M) | Open deficiencies + remediation timeline |
| Contingency Plan (CP) | Operational continuity plan |
| Incident Response Plan (IRP) | Response to security incidents |
| Configuration Management Plan | Baseline + change-control |
| Privacy Impact Assessment (PIA) / SORN | Privacy-covered systems only |
| Authorization Decision Document | Authorizing Official's signed ATO |

## FedRAMP Inheritance

When an app runs on a FedRAMP-authorized cloud service:

- **Platform P-ATO** — FedRAMP Joint Authorization Board (JAB) grants
  an agency-reusable authorization to the cloud service (IaaS, PaaS,
  SaaS). Controls at the infrastructure layer are *inherited* by
  tenant apps.
- **App-layer ATO** — still required. The app authorizes its own
  application-layer controls; platform controls are inherited.
- **Customer Responsibility Matrix (CRM)** — the FedRAMP P-ATO
  lists controls provided by the platform vs controls the customer
  must implement.

Record these three tiers separately:

```json
{
  "app_id": "...",
  "app_ato_package": "AAM-App-Suite-ATO-2024",
  "platform_p_ato": "aws-govcloud-high-p-ato",
  "platform_inheritance_crm_reference": "..."
}
```

## Common-Control-Provider Classification

NIST SP 800-53 Rev 5 distinguishes three control types:

| Type | Who implements | Example |
|---|---|---|
| **Inherited** (common) | Agency CCP or FedRAMP CSP | Physical security of the data center, network perimeter |
| **Shared** | Both CCP and app | Identity management (CCP provides IdP; app implements app-level authorization) |
| **Hybrid** | App for some instances, CCP for others | Backup/recovery (app backs up its DB; CCP backs up infra) |
| **System-Specific** | App only | Application logic, input validation, audit logging |

Emit per app: list of inherited controls, list of shared controls,
identity of the CCP providing them.

## Boundary Types

Possible authorization boundaries:

| Boundary | Scope | Examples |
|---|---|---|
| Agency-managed single-app ATO | One app + its direct dependencies | RMS mainframe may have its own |
| Agency-managed portfolio ATO | Multiple related apps | AAM-suite ATO covering AMCS + MEDXPRESS + CHAPS + CPDSS + DIWS |
| Agency enclave ATO | Network enclave / data center | FAA ATLAS enclave |
| FedRAMP tenant ATO | App + FedRAMP platform P-ATO | Cloud-migrated apps |
| Hybrid | Agency-enclave app with cloud components | Rarely clean |

## Cross-Boundary Modernization Cost Estimates

Crossing an ATO boundary triggers re-authorization work:

| Crossing | Incremental effort |
|---|---|
| Within-boundary consolidation (AAM-suite → single modernized AAM app) | 1-3 months (SSP update, controls re-assessment) |
| Same-agency different-boundary | 3-6 months (new SSP, SAR, POA&M) |
| Agency → FedRAMP | 6-12 months (SAAS ATO if SaaS; tenant ATO if IaaS/PaaS; FedRAMP leverage if P-ATO available) |
| Net-new ATO (no predecessor package) | 6-18 months (full RMF 6-step cycle) |

Costs depend on assessor availability, POA&M depth, CCP readiness.
Report RANGE, not single point estimates.

## CUI Handling Separate From ATO

Controlled Unclassified Information per EO 13556 / 32 CFR Part 2002
has its own handling requirements — separate from FISMA:

| CUI Category | Source | Application |
|---|---|---|
| SP-PRVCY (Privacy) | Privacy Act | Nearly all FAA systems with personal data |
| SP-LEGAL (Legal Proceedings) | Agency legal | Enforcement systems |
| SP-PERS (Personnel) | Privacy Act | Staff records |
| SP-EXPT (Export Control) | ITAR / EAR | Some aviation data |
| SP-HLTH (Health Information) | HIPAA / Privacy Act | Medical certification (AAM) |

Record CUI categories separately in `cui_categories[]` field; these
don't change the ATO boundary but do constrain handling.

## Authorization Expiry Tracking

FISMA requires re-authorization per OMB A-130:
- Continuous monitoring reduces re-assessment frequency.
- Hard expiry every 3 years (or sooner per authorization decision).

Record per ATO package:
- `authorization_date`
- `authorization_expiry`
- `continuous_monitoring_frequency` (monthly / quarterly / annual)

An app with expired authorization is operating in violation; emit
as a high-severity finding.

## ATLAS Portfolio Expected ATO Topology

Reconstruction from READMEs + shared-GUID evidence:

| ATO Package (inferred) | Apps | Basis |
|---|---|---|
| AAM-Suite-ATO | AMCS, MEDXPRESS, CHAPS, CPDSS, DIWS | Shared Encryptor GUID across 4 repos; mission-owner AAM; shared MSS Oracle schema |
| RMS-Mainframe-ATO | RMS (CAIS + AADOCS) | z/OS + RACF + Unisys eWorkflow mainframe; separate ops team (AIT-MF-OPS) |
| RMS-Windows-ATO | RMS (IMS thick-client, AR web apps) | Windows + SQL Server; may roll up to RMS-Mainframe-ATO or be separate |
| IACRA-ATO | IACRA | Public-facing; separate auth (Node JWT middleware) + separate contact (NSD helpdesk) |
| DMS-ATO | DMS | Modern stack; separate mission owner (AFS Flight Standards Service); dual-DB |

All inferred; confirm with FAA Information Systems Security Office.

## Shared-Control-Provider Patterns

Common CCPs for FAA apps:

| CCP | Controls provided |
|---|---|
| FAA enterprise IdP (PIV / MyAccess) | Identity + authentication |
| FAA data center | Physical + environmental + network perimeter |
| Agency SOC | Monitoring + incident response |
| FedRAMP cloud provider (e.g., AWS GovCloud) | Infrastructure + platform (if in use) |

Record per app which CCP provides which control family.
