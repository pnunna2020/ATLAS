---
name: ato-boundary-analyzer
description: >
  For each app, identify the FISMA / NIST RMF / FedRAMP / ATO
  authorization boundary it lives in, which shared authorization
  package covers it, and whether modernization crosses a boundary.
  Rationalization-phase skill that runs earlier than `cato-compliance`
  (which is Compliance-phase). Without ATO-boundary information,
  `disposition-recommender` cannot size the cost of boundary-crossing
  modernizations — e.g., consolidating the AAM suite into a new ATO
  is a fundamentally bigger program than consolidating within the
  existing AAM authorization package. Emits per-app ATO designation
  + cross-boundary findings that feed `rom-cost-estimator` and
  `wave-planner`. Runs as a Rationalization conditional skill when
  the client profile is federal AND ≥1 app has a security posture
  in scope. Triggers on ATO boundary analysis, FISMA authorization
  package mapping, or @ato-boundary-analyzer.
agent: sonnet
allowed-tools:
  - Read
  - Write
  - Grep
  - Glob
validation_commands:
  - "python -m olympus.validators.schema_validator ato-boundary.json"
  - "python -m olympus.validators.schema_validator ato-cross-boundary-findings.json"
supported_stacks:
  - any
anti_target_stacks:
  - non-federal
  - static-site
  - test-fixture
failure_classes:
  - ato-boundary-confused-with-record-custody
  - fedramp-vs-agency-ato-merged
  - modernization-crossing-boundary-unflagged
  - inherited-ato-not-recorded
  - fisma-high-moderate-low-misclassified
  - shared-control-provider-missed
benchmark_tags:
  - rationalization-governance
  - ato-boundary-mapping
  - fisma-authorization
  - modernization-boundary-crossing
---

# ato-boundary-analyzer

## Purpose
Produce a machine-readable ATO (Authorization to Operate) boundary
map so Rationalization decisions can price boundary-crossing
modernization honestly. A disposition that consolidates two apps
across an ATO boundary is a several-hundred-thousand-dollar
authorization effort beyond the code changes; conflating it with
within-boundary consolidation produces ROM estimates that can be
off by 2-5x.

## Inputs
- Application catalog entries.
- Compliance citation inventory
  (`citation-validation.json`) — identifies FISMA / NIST RMF /
  FedRAMP citations.
- Infrastructure-hint artifacts (hosting-model findings from
  `dotnet-discovery-patterns`, deployment-target hints from
  `legacy-architecture-mapper`).
- Client-profile FISMA impact classification
  (`profiles/<client>/risk-classification.yaml`).
- Optional: shared-GUID evidence from
  `shared-encryptor-drift-detector` — shared crypto libraries often
  track with a shared ATO package.
- Optional: portfolio integration graph
  (`integration-graph.json`).

## Outputs
- `ato-boundary.json` — per app: `{app_id, ato_package_id_or_name,
  ato_package_status (known | inferred | unknown),
  fisma_impact_level (low | moderate | high | unknown),
  authorization_date, authorization_expiry, ssp_document_ref,
  control_provider (self | agency_shared | fedramp_csp),
  inherited_controls[], shared_with_apps[], ato_narrative}`.
- `ato-cross-boundary-findings.json` — per potential modernization
  action that crosses a boundary: `{action_description, source_ato,
  target_ato, crossing_type (consolidation | replacement | re-ato),
  incremental_effort_estimate_months, ato_risk_severity}`.

## Methodology
1. **Enumerate ATO-indicating citations.** Filter citations for:
   `FISMA`, `44 USC §3541`, `44 USC §3551-3558`, `NIST SP 800-37`,
   `NIST SP 800-53`, `FedRAMP`, `OMB A-130`, FAA-specific ATO
   references (e.g., FAA Order 1370.121).
2. **Classify ATO package per app.** Evidence sources, in order:
   - Explicit ATO package name in source / docs.
   - Inferred from shared-GUID libraries (AAM Encryptor → shared ATO).
   - Inferred from mission owner (AAM / AVS / AFS) when mission
     grouping typically shares ATO.
   - `unknown` when none of the above.
3. **Determine FISMA impact level.** Use client-profile risk
   classification; `system-of-record` apps typically Moderate or
   High; public-facing transactional apps Moderate or High; internal
   admin tools Low or Moderate.
4. **Identify shared-control providers.** Apps hosted on a common
   FedRAMP platform inherit platform controls. Apps sharing an FAA
   data center inherit the agency's shared physical / network
   controls. Record per app.
5. **Group apps by ATO package.** Emit `shared_with_apps[]` per app.
6. **Detect cross-boundary modernization risk.** For every
   potential disposition (Consolidate, Replace, Replatform):
   - Same-boundary target → low ATO impact; treat as re-accreditation
     at most.
   - Different-agency-ATO target → high ATO impact; full RMF cycle
     (6-12 months typical) required.
   - Cloud / FedRAMP target → requires FedRAMP leverage or net-new
     authorization (3-12 months depending on P-ATO availability).
7. **Cite every claim.** `ato_package_id_or_name` and every
   inherited-control claim cites `{repo}:{file}:{line}` or a
   citation-finding reference.

## Tech-Stack Dispatch

| Trigger | Reference loaded |
|---|---|
| FISMA / NIST RMF citations present | `references/fisma-rmf-boundary-patterns.md` |

## Gotchas
- **ATO boundary ≠ record custody boundary.** FISMA boundary is
  a *security* boundary (controls inherited, ATO granted); record
  custody is established by records-management statutes. Don't
  conflate. Use `federal-systems-of-record-tagger` for custody.
- **FedRAMP is a layer, not a replacement.** An app running on a
  FedRAMP IaaS inherits IaaS controls but still needs its own
  application-layer ATO. Record FedRAMP P-ATO inheritance
  separately from the app's own authorization.
- **Inherited controls vs shared controls vs hybrid controls.** NIST
  SP 800-37 distinguishes these. Inherited = fully provided by a
  common-control provider (CCP). Shared = the app and CCP each
  provide part. Hybrid = app provides for some instances, CCP for
  others. Don't flatten.
- **Re-authorization is annual (or per OMB A-130 3-year cycle).**
  An app with expired authorization is not in ATO; modernization may
  coincide with re-authorization as a cost-reduction opportunity or
  may be forced onto an already-scheduled re-auth. Record expiry.
- **ATO boundary can be broader than the app.** Some agencies
  authorize portfolios or enclaves, not individual apps. Multiple
  apps may share one System Security Plan (SSP).
- **Modernization-crossing-boundary is a first-class finding.**
  Never silently cross an ATO boundary in disposition
  recommendations; emit the finding + incremental cost explicitly.
- **FedRAMP High / Moderate / Low map to FISMA impact.** FedRAMP
  High ≈ FISMA High; FedRAMP Moderate ≈ FISMA Moderate. An
  FAA-specific app hosted on FedRAMP Moderate cannot hold FISMA
  High data.
- **CUI categorization is separate from FISMA impact.** CUI
  (Controlled Unclassified Information) carries its own handling
  requirements under 32 CFR Part 2002 / EO 13556; record separately.
- **`unknown` is a legitimate designation.** If no evidence links
  the app to a specific ATO package, emit `ato_package_status:
  unknown` + a human-review open question. Do not guess.

## Quality Rules
- [ ] Every in-scope app has an ATO boundary record.
- [ ] ATO package status (known / inferred / unknown) assigned per
      app.
- [ ] FISMA impact level populated.
- [ ] Shared-with-apps list reflects actual ATO grouping.
- [ ] Every cross-boundary modernization action has a finding
      with effort estimate.
- [ ] Every claim cites evidence.
- [ ] Unknown designations emit open-question records.

## Common Failure Modes

| Failure Mode | Symptom | Prevention |
|---|---|---|
| ATO boundary confused with record custody | AAM suite tagged both as single ATO and single record-custody group; treated identically | Distinguish via citation type (records vs FISMA) |
| FedRAMP inheritance flattened | App's own ATO needs merged with FedRAMP IaaS P-ATO | Record tiers separately |
| Cross-boundary action unflagged | Disposition recommends consolidating apps across ATOs without cost impact | Always emit cross-boundary finding when ATOs differ |
| Missing authorization date | Expired or lapsed ATO not flagged | Record date + expiry per ATO package |

## Handoff Summary
When this skill completes, verify:
1. Every in-scope app has an ATO-boundary record.
2. Grouped apps carry consistent `shared_with_apps[]` lists.
3. Cross-boundary modernization actions are flagged with effort
   estimates.
4. FedRAMP / FISMA / agency-ATO tiers are recorded separately.

Then proceed to: `disposition-recommender` (Rationalization primary)
— which consumes `ato-boundary.json` to constrain consolidation
recommendations; `rom-cost-estimator` (proposal-artifact generator)
— which consumes `ato-cross-boundary-findings.json` for pricing;
`cato-compliance` (Compliance phase) — for full RMF evidence package.

## References
- `references/fisma-rmf-boundary-patterns.md` — FISMA impact levels,
  NIST RMF 6-step cycle, ATO package composition (SSP + SAR +
  POA&M), FedRAMP P-ATO inheritance, common-control-provider
  classification, inherited / shared / hybrid control taxonomy,
  authorization-expiry tracking, CUI handling separation.

## Changelog
- 0.1.0 (2026-05-08) — Initial skill. Authored as FAA-proposal-P1
  (see `docs/testing/faa-proposal-skill-assessment.md` Section 9).
