# Data Domain Identification Methodology

## Step 1: Start with Business Capabilities (NOT applications)
Map FAA business capabilities first:
- Flight Operations (NAS, SWIM, flow management)
- Airspace Management (SUA, TFR, NOTAMs)
- Safety & Compliance (incident reporting, safety cases)
- Personnel & Training (certifications, training records)
- Procurement & Finance (contracts, billing, budget)
- Infrastructure & Facilities (airports, equipment, maintenance)

## Step 2: Map Applications to Capabilities
Each app serves one or more capabilities. The CAPABILITY is the domain, not the app.

## Step 3: Identify Domain Boundaries
Use these heuristics:
- Data that changes together belongs together
- Data that is queried together belongs together
- Data with the same lifecycle (create/archive) belongs together
- Data with the same security classification belongs together

## Step 4: Handle Cross-Domain Dependencies
When data spans domains:
- Define a data contract between domains
- The producing domain owns the schema
- The consuming domain must handle schema evolution gracefully
