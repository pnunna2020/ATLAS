# Data Product Specification Standard

## Required Fields
```yaml
data-product:
  name: flight-operations-schedule
  domain: flight-operations
  owner: ATO division
  description: Real-time and scheduled flight operation data
  sla:
    availability: 99.95%
    latency-p99: 200ms
    freshness: < 5 minutes
  schema:
    format: avro|json-schema|protobuf
    version: semver
    location: gravitee:/schemas/flight-ops-schedule-v2.avsc
  access:
    api: gravitee://api/flight-ops/schedules
    auth: okta-m2m
    rate-limit: 1000 req/min
  quality:
    completeness: ≥ 99%
    accuracy: validated against NAS source
    timeliness: refreshed every 5 min
  lineage:
    sources:
      - legacy-app: TFMS
      - legacy-db: flight_schedules_oracle
    transformations:
      - deduplicate on flight_id + date
      - normalize airport codes to ICAO
```
