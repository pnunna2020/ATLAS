# Gravitee Configuration for Data APIs

## Standard Data Product API Pattern
```yaml
gravitee-api:
  name: "{{DOMAIN}}-{{PRODUCT}}"
  version: "{{VERSION}}"
  proxy:
    endpoints:
      - target: "https://{{SERVICE_URL}}"
        weight: 1
  plans:
    - name: "internal-consumers"
      security: "oauth2"
      rate-limit: { limit: 1000, period: "1m" }
    - name: "external-consumers"
      security: "api-key"
      rate-limit: { limit: 100, period: "1m" }
  policies:
    - type: "transform-headers"
      configuration:
        add:
          X-Data-Domain: "{{DOMAIN}}"
          X-Data-Product: "{{PRODUCT}}"
          X-Data-Version: "{{VERSION}}"
```

## CRITICAL: All data product APIs MUST go through Gravitee.
## Direct service-to-service data access is NOT permitted.
