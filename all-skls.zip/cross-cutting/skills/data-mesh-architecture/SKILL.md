---
name: data-mesh-architecture
description: >
  Design data mesh and data fabric architectures for FAA enterprise data.
  Use when designing data domains (P2.2), creating data product catalogs,
  defining data contracts, or planning Gravitee-based data API strategies.
  Triggers on data mesh, data fabric, data domain, data product, data contract,
  or data governance mentions.
agent: opus
---

# Data Mesh / Fabric Architecture

## Purpose
Design domain-oriented data ownership that eliminates data silos across FAA's
200+ applications and 3,000 databases. This skill creates the data domain model,
data product definitions, and data contracts that govern how data flows through
the modernized enterprise.

## Quick Reference
- Data domains follow business capability boundaries, NOT application boundaries
- Every data product has an owner, SLA, schema, and API
- Data contracts are versioned and tested like code
- Gravitee is the MANDATORY gateway for data product APIs

## Workflow
1. Load `references/data-domain-patterns.md` for domain identification patterns
2. Analyze the application's data footprint from P0.2/P0.3 outputs
3. Map data entities to business domains (not technical boundaries)
4. Define data products with ownership, schema, SLA, and access patterns
5. Create data contracts using `assets/data-contract-template.yaml`
6. Design Gravitee API routes for data product exposure
7. Output: Data domain model, data product catalog, data contracts

## Gotchas
- **Domains are NOT apps**: Claude defaults to one-domain-per-app. Wrong. A domain
  like "Flight Operations" may span 15 apps. Domain boundaries come from business
  capability mapping, not application inventory.
- **Shared databases break domain boundaries**: When P2.3a identifies shared DB
  clusters, the data mesh design must account for the interim period where data
  ownership is being transferred. Use the façade pattern until migration completes.
- **Gravitee routes for data products**: Every data product API must be registered
  in Gravitee with rate limiting, authentication, and usage tracking. Don't design
  direct service-to-service data access that bypasses the gateway.
- **SWIM data is special**: Solace PubSub+ handles SWIM data feeds. These are NOT
  candidates for data mesh data products — they're external integrations with their
  own contracts and protocols.
- **Data quality rules must be executable**: Don't generate aspirational quality
  rules. Each rule must map to a validation script or SQL check that runs in CI/CD.

## Reference Files
- `references/data-domain-patterns.md` — Domain identification methodology
- `references/data-product-specification.md` — Data product definition standard
- `references/gravitee-data-api-patterns.md` — Gravitee configuration for data APIs

## Quality Rules
- [ ] Domain boundaries follow business capability mapping, not application boundaries
- [ ] Every data product API is registered in Gravitee with rate limiting, authentication, and usage tracking
- [ ] Shared database interim strategies (facade patterns) have documented sunset dates
- [ ] SWIM/Solace data feeds are treated as external integrations, not data mesh products
- [ ] Data quality rules are executable — each maps to a validation script or SQL check runnable in CI/CD
- [ ] Data contracts use semantic versioning with documented migration plans for breaking changes

## Common Failure Modes
| Failure Mode | Symptom | Prevention |
|-------------|---------|------------|
| Domain-per-app mistake | Claude maps one domain per app; cross-app business capabilities like "Flight Operations" are split | Validate domain boundaries against business capability map; expect domains to span multiple apps |
| Direct service-to-service data access | Services bypass Gravitee for data product access; rate limiting and monitoring not applied | Enforce all data product APIs through Gravitee gateway; block direct inter-service data calls |
| Permanent facades | Facade introduced for interim period but never decommissioned; becomes permanent tech debt | Require sunset date for every facade; track facade lifecycle in wave planning |
| Aspirational quality rules | Quality rules are documented but not executable; violations not caught | Map every quality rule to a script or SQL check; run in CI/CD pipeline |

## Handoff Summary
When this skill completes, verify:
1. Data domain model maps to business capabilities (not applications)
2. All data product APIs route through Gravitee with proper configuration
3. Shared database facades have documented sunset dates
4. Data quality rules are executable and integrated into CI/CD
Then proceed to: `data-product-specification` for formal product definitions, `decomposition-patterns` for shared DB strategy, and gate `G-DT` for data architecture review
