---
name: tiff-generator-extractor
description: >
  Extract the contract of a legacy TIFF-generation pipeline — code
  that produces TIFF documents byte-by-byte, typically for legally
  binding certificate artifacts under 14 CFR Part 183 — distinct
  from tiff-corpus-assessor, which evaluates an archive of TIFFs.
  Fires on dedicated TIFF projects (e.g., IacraTifBuilder,
  TiffWriter, IACRATiffAPI), tag-level byte encoders, or
  digital-signature libraries paired with certificate output.
  Emits five schema-validated artifacts (generator surface, byte
  format, signature embedding, parity contract, modernization
  risk) with {repo}:{file}:{line} traceability. Triggers on TIFF
  generator extraction, IACRA TIFF pipeline analysis, digital
  signature embedding audit, airman certificate parity capture,
  or @tiff-generator-extractor.
agent: sonnet
allowed-tools:
  - Read
  - Write
  - Grep
  - Glob
validation_commands:
  - "python -m olympus.validators.schema_validator tiff-generator-surface.json"
  - "python -m olympus.validators.schema_validator tiff-byte-format-manifest.json"
  - "python -m olympus.validators.schema_validator digital-signature-embedding-manifest.json"
  - "python -m olympus.validators.schema_validator certificate-parity-contract.json"
  - "python -m olympus.validators.schema_validator tiff-modernization-risk-findings.json"
supported_stacks:
  - csharp
  - dotnet
  - vbnet
  - java
  - cplusplus
anti_target_stacks:
  - static-site
  - pure-cdn-asset
  - tiff-corpus-archive
failure_classes:
  - corpus-assessor-misfire
  - signature-scheme-guessed
  - tag-inventory-incomplete
  - parity-contract-absent
  - library-swap-risk-unflagged
benchmark_tags:
  - discovery-tiff-generator
  - digital-signature-embedding
  - certificate-parity
  - faa-part-183-compliance
---

# tiff-generator-extractor

## Purpose
Recover the contract of a custom TIFF-generation pipeline during
Discovery Pass 2 when an application generates TIFF documents rather
than consuming a corpus. FAA applications such as IACRA ship dedicated
TIFF-generation projects (`IacraTifBuilder`, `TiffWriter`,
`IACRATiffAPI`) producing Temporary Airman Certificates with embedded
digital signatures; these carry legal force equivalent to a wet-ink FAA
cert under 14 CFR Part 183. Running `tiff-corpus-assessor` here
misfires: the assessor evaluates archive-scale image collections, while
a generator is a per-certificate byte emitter with a signing hook. This
skill extracts input/output shape, tag inventory, signature embedding
strategy, and parity contract, so Rationalization and Modernization can
plan a parity-preserving migration rather than a library swap that
invalidates every previously issued certificate.

## Inputs
- Application source tree — scanned for dedicated TIFF projects
  matching `*Tif*.cs`, `*Tiff*.cs`, `*TiffWriter*`, `*TiffBuilder*`,
  `*TiffAPI*`, and companion signature libraries
  (`*DigitalSignature*`, `*SignatureBLL*`, `*Signer*`).
- Application catalog entry
  (`schemas/discovery/application-catalog-entry.schema.json`) —
  supplies `application_id` and integration points (e.g., IACRA's
  `CAIS Export`).
- `.NET` / Java architecture fingerprint when available — bounds the
  project set so unrelated assemblies referencing a TIFF library are
  not pulled in.
- Deployment notes citing the certificate product (Temporary Airman
  Certificate, examiner cert) — anchors the parity contract.
- Reference guides under `references/`.

## Outputs
- `tiff-generator-surface.json` — per project: `project_path`, `role`
  (`builder | writer | api`), `entry_points[]`, `input_shape` (airman
  data, cert type, rating codes), `output_shape` (file, bytes, base64).
- `tiff-byte-format-manifest.json` — tag inventory (ImageWidth,
  ImageLength, BitsPerSample, Compression, PhotometricInterpretation,
  ResolutionUnit, XResolution, YResolution, Orientation, Software,
  DateTime, Artist, Copyright, FAA private tags), compression (CCITT
  Fax G4 typical), endianness (`MM`/`II`), multi-page IFD chains.
- `digital-signature-embedding-manifest.json` — strategy (`custom-tag |
  appended-bytes | detached-file`), algorithm (`rsa-2048 | rsa-1024 |
  ecdsa-p256 | dsa-legacy`), key source (cert store, HSM, PFX, embedded
  PEM), scope (whole-file, IFD-subset, pixel-only), format (PKCS#7,
  raw, XML-DSig).
- `certificate-parity-contract.json` — legal-force fields (name, cert
  number, ratings, issue date, expiration, examiner signature, control
  number), byte- vs. pixel-reproducibility flag, 14 CFR Part 183
  citations where surfaced.
- `tiff-modernization-risk-findings.json` — each finding: `finding_id`,
  `severity`, `description`, `citation.{file,line,snippet}`,
  `mitigation_options[]`. Library-swap byte-drift is always high.

## Methodology
1. **Enumerate TIFF-generation projects.** Glob for `*Tif*.cs`,
   `*Tiff*.cs`, `*TiffWriter*`, `*TiffBuilder*`, `*TiffAPI*`,
   `*Tif*.java`, `*tiff*.cpp`. Assign each a role: `builder`
   (airman-data orchestration), `writer` (byte encoder), `api`
   (standalone HTTP/WCF surface). IACRA's three-project split
   maps exactly.
2. **Exclude non-generators.** Read-only projects are not
   generators; confirm write paths (`FileStream.Write`,
   `BinaryWriter`, `Save`/`Build` returning bytes). Zero-byte
   `forms/` sentinels are SVN/VSS artifacts — exclude.
3. **Identify entry points.** Enumerate public methods, ASMX/WCF
   operations, controller actions, or Java servlets that trigger
   generation. Record input shape (airman identity, cert type,
   ratings, issue date, examiner) and output shape. Capture batch
   and on-demand paths both.
4. **Walk the byte encoder.** In the writer project, trace every
   tag-setting site. Build the tag inventory: ID, name, field
   type, count, source expression. Record endianness from header
   magic; compression from the Compression tag (`4` = CCITT Fax
   G4, `5` = LZW, `32773` = PackBits). Record the IFD chain for
   multi-page certs.
5. **Extract the signature embedding path.** Read
   `DigitalSignatureLibrary` directly — never infer from naming.
   Classify embedding into `custom-tag | appended-bytes |
   detached-file`. Capture algorithm by API (`RSA`, `RSACng`,
   `ECDsa`, `DSACryptoServiceProvider`), key source (cert-store,
   PFX, HSM), scope (whole-file, IFD-subset, pixel-only), and
   format (`SignedCms` = PKCS#7, `SignHash` = raw, `SignedXml` =
   XML-DSig).
6. **Derive the parity contract.** For each emitted cert field,
   record source (DB column, parameter, constant), destination
   (TIFF tag, pixel overlay, signature payload), and legal-force
   status. Cite 14 CFR Part 183 where it appears; a generator
   with no Part 183 citation is a finding (`parity-contract-absent`).
7. **Emit modernization risk findings.** High-severity triggers:
   custom low-level writer, whole-file-hash signature, detached-
   signature scheme, PII in Software/Artist/DateTime tags,
   standalone TIFF API with unknown consumers.
8. **Do not recommend replacement.** Legal-force-cert
   modernization requires FAA approval. Extract the surface and
   flag decision points; disposition-recommender decides scope
   with regulatory concurrence.
9. **Validate and hand off.** Validate each artifact against its
   schema; every tag, signature, and parity claim must cite a
   real `{repo}:{file}:{line}`.

## Tech-Stack Dispatch

| Trigger | Key patterns |
|---|---|
| `.csproj` matches `*Tif*Builder*` / `*Tiff*Builder*` | Builder role — airman-data orchestration, composes writer + signer |
| `.csproj` matches `*TiffWriter*` or custom `TiffEncoder` subclass | Writer role — direct `BinaryWriter`, tag-level emission, hardcoded endianness |
| `.csproj` matches `*TiffAPI*` or `*TiffService*` | API role — HTTP/WCF/ASMX surface; flag consumer inventory |
| Companion `*DigitalSignature*` / `*SignatureBLL*` | Embedding scheme is load-bearing; read the library, do not infer |
| `CCITT`, `T6`, `Group4`, `Compression = 4` in source | 1-bit fax-compressed cert form, typical for legal-force output |

Detection is mechanical. In the IACRA shape all five fire.

## Gotchas
- **`tiff-corpus-assessor` is for archives, not generators.** The
  assessor measures ingestion against a ~20M-record corpus; running
  it here produces spurious retention findings and misses the
  signature contract entirely.
- **Custom low-level writers are the default for regulated output.**
  Swapping for `libtiff`, `System.Drawing.Tiff`, or `ImageMagick`
  yields byte-different files with identical pixels — every
  previously signed cert fails verification if the scheme hashes
  bytes. Irreversible; high-severity.
- **TIFF endianness is per-file** (`MM` big, `II` little).
  Hardcoding one may fail interop.
- **CCITT Fax G4 is not auto-convertible.** "Modernize to PNG/PDF"
  is not free — receiving FAA systems may be pinned to TIFF by
  regulatory process (cite: IACRA's `processes/CAIS Export`).
- **14 CFR Part 183 is load-bearing.** IACRA certs carry legal
  force equivalent to a wet-ink FAA cert; the skill cannot drop
  fields as "cosmetic".
- **Signature scheme must be read, not guessed.** Read
  `DigitalSignatureLibrary` directly — a filename could cover
  PKCS#7, XML-DSig, or custom raw schemes.
- **Detached-signature schemes break on rename.** A sibling `.sig`
  pairs by filename; renaming the `.tif` breaks verification.
- **SelectPDF is not the TIFF path.** IACRA ships a PDF-alternative
  pipeline alongside TIFF; extract both separately.
- **Multi-page TIFF is native.** An IFD chain may encode form on
  page 1, signature on page 2; single-page formats lose structure.
- **Metadata tags leak PII by default** — `Artist`, `Software`,
  `DateTime` often contain developer-machine values.
- **Batch and on-demand are different entry points** — both count.
- **Standalone TIFF APIs have unknown consumers** — `IACRATiffAPI`
  may be called by non-IACRA systems; flag consumer discovery.

## Quality Rules
- [ ] Every TIFF-generation project has a record in
      `tiff-generator-surface.json` with `role`, `entry_points[]`,
      `input_shape`, and `output_shape` populated.
- [ ] Every tag in `tiff-byte-format-manifest.json` cites a real
      `{repo}:{file}:{line}`; endianness, compression, and
      IFD-chain shape each cite a source line.
- [ ] `digital-signature-embedding-manifest.json` names exactly one
      embedding strategy; algorithm, key source, and signing scope
      each cite the API call.
- [ ] `certificate-parity-contract.json` lists every legal-force
      field with source and destination citations and cites 14 CFR
      Part 183 where surfaced.
- [ ] `tiff-modernization-risk-findings.json` contains a
      `library-swap-byte-drift` finding at `severity: high` when a
      custom writer is detected.
- [ ] Zero-byte `forms/` sentinels are not mistaken for generators;
      SelectPDF pipelines are extracted separately.
- [ ] Every artifact validates; every finding carries both
      `{artifact}:{section}:{finding-id}` and `{repo}:{file}:{line}`.

## Common Failure Modes
| Failure Mode | Symptom | Prevention |
|---|---|---|
| Corpus-assessor misfire | Archive-scale ingestion metrics emitted for a per-cert generator; signature contract missing | Confirm the TIFF path is a writer/builder, not a reader over an archive; dispatch on writer-role filename patterns |
| Signature scheme guessed | Manifest reports PKCS#7 when the library uses raw RSA-SHA256; verification work mis-sized | Read `DigitalSignatureLibrary` directly; cite the API call (e.g., `SignedCms.ComputeSignature`) |
| Tag inventory incomplete | Byte-different modernized output; old-cert verifications fail retroactively | Walk every tag-write site (`.Write`, `PutTag`, `AddDirectoryEntry`); emit one row per tag |
| Parity contract absent | Migration proceeds without a legal-force field list; G-DC blocks | Always emit `certificate-parity-contract.json`; flag missing Part 183 citation, do not skip |
| Library-swap risk unflagged | Disposition-recommender picks Replatform without the byte-drift caveat; signature chain breaks | Always emit `library-swap-byte-drift` high-severity when a custom writer is detected |
| SelectPDF pipeline conflated with TIFF | Generator surface merges two pipelines | Match by project name; extract PDF and TIFF separately |

## Handoff Summary
When this skill completes, verify:
1. Every TIFF-generation project is in `tiff-generator-surface.json`
   with role, entry points, and input/output shapes.
2. The byte-format manifest alone lets a reviewer predict whether a
   library swap preserves byte-identical output.
3. The signature-embedding manifest names scheme, algorithm, key
   source, and signing scope, each with a call-site citation.
4. The parity contract lists every legal-force field, cites Part 183
   where surfaced, and is explicit about byte vs. pixel parity.
5. Risk findings include at minimum one high-severity library-swap-
   byte-drift entry when a custom writer is detected.

Then proceed to `disposition-recommender` — which must weight
Refactor-in-place heavily over Replatform or Replace for legal-force
TIFF generators absent FAA concurrence — and
`portfolio-integration-mapper`, which consumes the standalone-API
surface to discover cross-system consumers. Next gate: **G-DC**.

## References
- `references/tiff-generation-pipeline-patterns.md` — TIFF 6.0 byte
  format, tag catalog, endianness, compression, multi-page IFDs,
  byte-level roundtrip testing.
- `references/digital-signature-in-tiff-patterns.md` — crypto,
  key-store patterns, signature formats, embedding strategies,
  verification chains, Part 183 legal-force parity.

## Changelog
- 0.1.0 (2026-05-06) — Initial skill; distinguishes TIFF generators
  from corpus assessors; emits five manifests; targets IACRA-style
  pipelines under Part 183.
