# Digital Signature in TIFF Patterns

Reference for extracting the digital-signature contract of a TIFF
generator — how the signature is computed, where it lives, and what
must be preserved for verification to keep working across a
modernization. Applies to the IACRA-style shape where a
`DigitalSignatureLibrary` pairs with a TIFF writer to produce
tamper-evident Temporary Airman Certificates under 14 CFR Part 183.

## Why Signatures Matter Here

A legal-force certificate carries the weight of a wet-ink FAA-issued
cert. The signature is the tamper-evidence layer that lets any
future verifier confirm the cert was issued by an authorized party
and has not been altered. For 14 CFR Part 183-governed certs,
verification is the mechanism by which legal force is asserted.

Any modernization that changes the bytes over which the signature
is computed — without re-signing every previously issued cert —
breaks verification for those old certs. Re-signing old certs is
typically not authorized (the original signer may be retired,
deceased, or no longer empowered under Part 183). The signature
contract is effectively immutable for the population of certs in
circulation.

## Crypto Algorithm Catalog

Identify the algorithm by the API called, not by the filename:

- **RSA-2048 + SHA-256 (PKCS#1 v1.5).** Modern baseline. In .NET,
  `RSACng.SignHash` with `HashAlgorithmName.SHA256`, or
  `RSA.Create(2048)` + `SignData`. v1.5 is the default; PSS is
  opt-in via `RSASignaturePadding.Pss`. For Part 183-era certs,
  PSS is rare.
- **RSA-1024 + SHA-1.** Legacy, deprecated, still present in
  long-lived regulated systems. Cannot be upgraded without
  re-issuance. SHA-1 collision weakness does not directly defeat
  verification within the issued context; flag as open risk.
- **ECDSA P-256 + SHA-256.** Modern curve-based. Smaller signatures
  (~64 bytes raw) than RSA-2048 (~256 bytes). In .NET,
  `ECDsa.Create()` with `ECCurve.NamedCurves.nistP256`.
- **DSA.** Legacy FIPS-186-2. Rare in new code, occasional in old
  federal systems.

## Key Source Patterns

Where the signing key lives determines what modernization must
preserve:

- **Windows certificate store.** `new X509Store(StoreName.My,
  StoreLocation.CurrentUser|LocalMachine)`, then
  `Find(FindBySubjectName|FindByThumbprint, ...)`. Non-exportable if
  installed so; moving off Windows requires PKCS#12 export or HSM.
- **HSM.** Key never leaves the device. In .NET, via a CNG KSP or
  PKCS#11. Migration requires same-vendor HSM or a PKCS#11 broker.
- **File-based PFX / PKCS#12.** On-disk, password-protected. Easy
  to deploy, easy to steal. Rare for modern regulated production.
- **Embedded PEM.** Key bytes compiled into the binary or in a
  config file. Highest exfiltration risk; flag severity-high.

Capture the key source for every signing call site.

## Signature Format Shapes

- **Raw signature bytes.** Output of `SignHash` — fixed length
  (256 bytes for RSA-2048, ~64 bytes for ECDSA-P256). No metadata.
- **PKCS#7 / CMS (`SignedCms`).** Envelopes the signature with
  cert chain and signed-attributes. Enables verification without
  out-of-band key lookup. Standard for modern regulated signing.
- **XML-DSig (`SignedXml`).** Rare for binary targets like TIFF;
  common when the workflow is XML-based. Signature almost certainly
  detached from the TIFF, travels in a companion XML document.

Capture by the API called. A method named `SignTiff` could
internally use any of the three.

## Signing Scope

The hash input — the bytes the signature covers — is the
load-bearing choice for modernization planning:

- **Whole-file hash.** Covers every byte of the TIFF. Any byte
  drift invalidates the signature; library-swap byte-drift is a
  direct failure. Most common and strictest.
- **IFD-subset hash.** Covers specific IFDs or tags. Changes
  outside the subset do not break verification. Requires encoding
  which subset was covered, typically via a signed-attributes
  field in PKCS#7.
- **Pixel-only hash.** Covers the decoded pixel buffer, not TIFF
  bytes. Library swaps are safe if the decoded image is pixel-
  identical. Rare for legal-force certs because surrounding
  metadata (cert number in a private tag) is uncovered and could
  be tampered without detection. Flag as anomaly.

Scope must be read out of signing code. A typical pattern:

```
byte[] fileBytes = File.ReadAllBytes(tifPath);
byte[] hash = SHA256.HashData(fileBytes);
byte[] sig = rsa.SignHash(hash, HashAlgorithmName.SHA256,
                          RSASignaturePadding.Pkcs1);
```

This is a whole-file hash. A buffered variant that skips byte
ranges would be a subset hash; capture the skipped ranges.

## Embedding Strategies

Where the signature ends up relative to the TIFF:

- **Custom-tag embedding.** Signature bytes are stored in a
  private IFD tag (often 32768+). File and signature travel in one
  file. The signature tag must be excluded from the signing scope
  (or the signature would depend on its own value — infinite
  recursion). Typical encoding: compute the signature over the
  file without the tag, then rewrite the file with the tag added.
- **Appended-bytes embedding.** Signature is written after the
  last IFD and pixel data, outside the formal TIFF structure. A
  naive reader ignores trailing bytes; a verifier seeks to a known
  offset. Fragile against tools that rewrite the file (strip
  metadata, re-compress) — they drop trailing bytes.
- **Detached-file embedding.** Signature is a sibling `.sig`,
  `.p7s`, or `.pkcs7` alongside the `.tif`. Verifier reads both.
  Breaks if the `.tif` is renamed without the `.sig`. A storage-
  system change (file share to object store) is a risk surface.

Record the embedding strategy in
`digital-signature-embedding-manifest.json` with a citation to the
insertion site.

## Verification-Chain Reconstruction

The chain:

1. Retrieve the signature (tag, appended bytes, or `.sig`).
2. Retrieve the signer's public key or certificate.
3. Validate the cert chain (signer -> intermediate -> root) — every
   cert in validity, not revoked, chained to a trusted root.
4. Compute the hash under the same scope used at signing.
5. Verify the signature against the hash using the signer's key.

For Part 183 certs, step (3) forces long-lived trust-store
management: the signing cert may outlive the signer's employment,
but its issuing CA must remain trusted for the signed artifacts'
lifetime.

## Legal-Force Parity Under 14 CFR Part 183

Part 183 designates Pilot Examiners and governs airman-cert
issuance. A Temporary Airman Certificate issued via a TIFF generator
is legally equivalent to a wet-ink FAA-issued cert. Requirements:

- Every field on the physical form must appear in the output, in
  the specified position and formatting. Compliance requirement,
  not UX preference.
- The signature must be verifiable by FAA downstream acceptance
  systems. A scheme change that invalidates old certs is not
  permitted without FAA concurrence.
- Cert number, ratings, issue date, and expiration must be
  machine-readable. Rendered-text-only encoding forces OCR
  downstream; tag encoding requires tag readers. Capture the
  choice in `certificate-parity-contract.json`.

Cite Part 183 whenever code, comment, or docs reference it. A
generator with no Part 183 citation is a finding — emit as
`parity-contract-absent`; the reviewer decides whether the
citation is missing or the cert class is not Part 183-governed.

## Tamper-Evidence Modes

- **Hash-based.** Signature proves bytes unchanged. Any byte drift
  is a retroactive failure for all old certs.
- **Pixel-fingerprint-based.** Fingerprint of decoded pixels stored
  and compared. Survives lossless library swaps but fails if the
  image is re-rendered differently.
- **Business-logic-based.** Cert number cross-checked against an
  authoritative issuance database; signature is secondary. Survives
  byte-level modernization but creates a DB-availability dependency.

Capture the mode in use. Risk findings enumerate library-swap,
rename, and re-compression behavior under each.

## What to Extract

For each signing call site:

- Crypto algorithm and key length, with API call cited.
- Key source (cert store / HSM / PFX / embedded), retrieval cited.
- Signature format (raw / PKCS#7 / XML-DSig), with API call cited.
- Signing scope (whole-file / IFD-subset / pixel-only), hash cited.
- Embedding strategy (custom-tag / appended / detached), insertion
  site cited.
- Verification-chain assumptions: trust root, intermediate path.
- Part 183 citations in code, comments, or adjacent docs.

Feed into `digital-signature-embedding-manifest.json` and
`certificate-parity-contract.json`. Every claim carries a
`{repo}:{file}:{line}`; inferred values are not permitted for
signature-contract fields.
