# TIFF Generation Pipeline Patterns

Reference for extracting the byte-level contract of a custom TIFF
generator — the code that writes TIFF bytes, not the code that reads
them. Applies to the IACRA-style shape where a dedicated project
(e.g., `TiffWriter`) emits TIFF bytes directly via `BinaryWriter` or
`Stream.Write` rather than delegating to a library.

## TIFF 6.0 Byte Format at a Glance

A TIFF file is three regions: an 8-byte header, one or more Image
File Directories (IFDs) that describe the image, and the pixel data
referenced by those IFDs. Every legal TIFF is a graph of byte
offsets, and a generator that writes bytes directly controls every
node in that graph.

- **Header.** Two bytes of endian magic (`II` = little-endian,
  `MM` = big-endian), version word (always `42` in chosen
  endianness), 32-bit offset to the first IFD. Endianness is
  per-file; readers must honor the header magic.
- **IFD.** 16-bit count of entries, then `count` 12-byte entries,
  then a 32-bit offset to the next IFD (or zero for the last).
  Each entry is `{tag, type, count, value-or-offset}` where the
  last field is either the value (if it fits in 4 bytes) or an
  offset to the value bytes elsewhere.
- **Pixel data.** Arranged as strips (rows grouped by RowsPerStrip)
  or tiles (rectangular blocks). Strip-based is the baseline and
  what cert-generation code almost always uses.

## Baseline Tag Catalog

For 1-bit cert forms, the minimum required set is:

| Tag | Dec | Purpose | Typical value |
|---|---|---|---|
| ImageWidth | 256 | Pixel columns | Form width (e.g., 1700) |
| ImageLength | 257 | Pixel rows | Form height (e.g., 2200) |
| BitsPerSample | 258 | Bits per pixel sample | 1 |
| Compression | 259 | Compression scheme | 4 (CCITT Fax G4) |
| PhotometricInterpretation | 262 | 0 = WhiteIsZero, 1 = BlackIsZero | 0 |
| StripOffsets | 273 | Offsets to strip data | varies |
| RowsPerStrip | 278 | Rows per strip | often all rows in one strip |
| StripByteCounts | 279 | Byte length per strip | varies |
| XResolution | 282 | DPI (rational) | 200 or 300 |
| YResolution | 283 | DPI (rational) | 200 or 300 |
| ResolutionUnit | 296 | 2 = inches, 3 = cm | 2 |

Tags commonly emitted but not strictly baseline, with their
modernization risk:

| Tag | Dec | Modernization risk |
|---|---|---|
| Orientation | 274 | Rotating in modernization invalidates signed bytes |
| Software | 305 | Leaks developer-machine info |
| DateTime | 306 | PII / timestamp drift |
| Artist | 315 | PII |
| Copyright | 33432 | Usually static |

Private tags (32768-65535) may encode FAA-custom metadata — a
control number, an examiner ID, a process-stage marker. Any private
tag the generator emits must be captured in the byte-format
manifest, including its value source. Private tags are not portable
across libraries and are a common source of modernization byte
drift.

## Compression Algorithm Choice

The Compression tag value determines pixel-data encoding. The four
values a generator is likely to use:

- **1 (None).** Raw pixel bytes with row padding to byte
  boundaries. Largest file, simplest roundtrip. Uncommon for cert
  forms.
- **4 (CCITT Fax Group 4, T.6).** 1-bit-per-pixel 2D run-length
  encoding. The default for scanned or generated 1-bit cert forms.
  Byte-deterministic given a fixed encoder implementation; library
  swaps that use a different conformant encoder may produce
  byte-different but pixel-identical output — a blocker for
  signature schemes that hash the whole file.
- **5 (LZW).** Lempel-Ziv-Welch. Byte-deterministic per
  implementation, not across implementations.
- **32773 (PackBits).** Simple run-length encoding,
  byte-deterministic.

Generators for legal-force certs overwhelmingly pick value `4`. A
different value should be documented and treated as higher-risk
for future swaps.

## Strip vs. Tile Layout

Strip layout is the baseline: the image is split into horizontal
strips of `RowsPerStrip` rows, each compressed and written
contiguously. For small cert forms, a common pattern is
`RowsPerStrip = ImageLength` — one strip per image, which
simplifies offset bookkeeping at the cost of requiring the encoder
to buffer the full image before writing.

Tile layout (TileWidth, TileLength, TileOffsets, TileByteCounts)
is an extension for very large images requiring random sub-region
access. Cert-generation pipelines do not typically use tiles; if
tile tags appear, flag the case.

## Multi-Page IFD Chains

TIFF's native multi-page shape is a linked list of IFDs. The header
points to the first IFD; each IFD ends with a 32-bit offset to the
next or zero for the last. A cert with a form on page 1 and a
signature representation on page 2 is a two-IFD chain; each IFD
has its own tag set and pixel data.

Multi-page TIFFs differ from multi-strip: strips sub-divide a
single IFD's pixel data; pages are separate IFDs with independent
tag sets. Losing a page breaks the legal artifact.

## Photometric Interpretation

The PhotometricInterpretation tag defines sample-to-pixel mapping:

- **0 (WhiteIsZero).** Zero = white, max = black. Standard for fax
  and 1-bit cert forms.
- **1 (BlackIsZero).** Zero = black, max = white. Standard for
  most scanned documents.
- **2 (RGB).** Three samples, red/green/blue.
- **3 (Palette).** Single sample indexing a ColorMap tag.
- **4 (TransparencyMask).** Mask image.

A switch between 0 and 1 with identical pixel bytes produces an
inverted image. Modernization cannot silently flip.

## Baseline vs. Extended TIFF

Baseline TIFF is the set of tags every reader must support. Extended
TIFF adds CMYK, YCbCr, JPEG-in-TIFF, tiles, and more. Legal-force
cert generators stay inside baseline because baseline is the interop
guarantee. A generator that strays (e.g., Compression `7` for
JPEG-in-TIFF) has narrowed the reader set — flag in risk findings.

## Byte-Level Roundtrip Testing

A modernization that claims byte-identical output must be tested by
roundtrip: take a known input, generate with the old pipeline,
generate with the new pipeline, and compare byte streams. A single
differing byte fails the test. This is the correct test whenever
the signature scheme hashes bytes.

Pixel-identical testing decodes both outputs and compares pixel
buffers. Two TIFFs may be pixel-identical and byte-different
because they use different encoder implementations, different tag
orderings within an IFD, or different offsets for stripped data.
Pixel-identical is the correct test when the signature scheme
hashes the decoded pixel buffer.

Which test applies depends on the signing scope captured in
`digital-signature-embedding-manifest.json`. The extractor records
the scope; the modernization plan picks the matching test.

## Endianness Quirks

Because endianness is per-file, a generator that hardcodes `II`
has committed every reader to handling `II` output. Most
Windows-based generators emit `II`; some network-protocol-adjacent
code expects `MM`. Capture the generator's choice and which
consumers are known to read the file.

## Common Writer Shapes

Two patterns dominate custom writer code:

- **Buffered tag table then pixel data.** The writer builds tag
  entries in memory, computes offsets once pixel length is known,
  writes header with first-IFD offset, writes tag table, writes
  pixel data. Byte-identical roundtrip is tractable.
- **Streaming with backpatch.** The writer emits a placeholder
  header, streams pixel data, seeks back to fill offsets. Byte-
  identical roundtrip is still tractable but requires reproducing
  the seek-and-backpatch sequence exactly.

A third pattern (two passes over pixel data) usually indicates a
workaround for an old library bug — flag it.

## What to Extract

For each generator project identified:

- Endianness and version-word choice with writer-site citation.
- Full tag inventory: tag ID, type, count, source expression for
  every tag the code sets.
- Compression choice and encoder used (first-party or library
  wrapper).
- Strip vs. tile layout and the `RowsPerStrip` value.
- Multi-page IFD chain: page count, per-page semantics.
- Any private tags with decoded meaning where documented.
- Writer shape: buffered-then-write or streaming-with-backpatch.

Feed the extracted surface into `tiff-byte-format-manifest.json`.
Every row must carry a `{repo}:{file}:{line}` citation; inferred
values are not permitted.
