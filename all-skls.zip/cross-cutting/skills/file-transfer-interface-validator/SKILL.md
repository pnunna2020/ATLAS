---
name: file-transfer-interface-validator
description: >
  Inventory and validate every file-transfer interface in a legacy app:
  Globalscape EFT, secure FTP / SFTP / FTPS, TIFF-over-FTP handoffs,
  USPS batch feeds, Finalist / Melissa address files, IPC certificate
  printing handoffs, nightly D-series batch drops. These interfaces are
  the most overlooked modernization surface because the protocol, the
  schedule, the peer system, and the credential are usually split across
  multiple artifacts (config file for endpoint, JCL or Control-M for
  schedule, separate PL/SQL or .NET for transform, secrets elsewhere).
  Fires for RMS (Globalscape EFT + nightly D48 feed from IACRA + Finalist
  address standardization + IPC cert printing + TIFF corpus over FTP to
  CAIS) and IACRA (outbound side via `processes/CAIS Export`,
  `processes/PTRS Export`, `processes/ApplicationTransferToRMS`). This
  is FAA4-11 G-8 made real on actual ATLAS code. Runs as a Discovery
  conditional skill. Triggers on file-transfer inventory, SFTP
  interface analysis, D-series batch drop discovery, or
  @file-transfer-interface-validator.
agent: sonnet
allowed-tools:
  - Read
  - Write
  - Grep
  - Glob
validation_commands:
  - "python -m olympus.validators.schema_validator file-transfer-inventory.json"
  - "python -m olympus.validators.schema_validator file-transfer-protocol-findings.json"
  - "python -m olympus.validators.schema_validator file-transfer-credential-findings.json"
  - "python -m olympus.validators.schema_validator file-transfer-peer-system-graph.json"
supported_stacks:
  - globalscape-eft
  - sftp
  - ftps
  - ftp
  - tiff-over-ftp
  - winscp
  - usps-batch
  - finalist
  - melissa
  - ipc
anti_target_stacks:
  - rest-api
  - graphql
  - grpc
  - message-queue
  - static-site
failure_classes:
  - credential-hardcoded-in-config
  - protocol-downgrade-ftp-vs-sftp-confused
  - schedule-split-across-artifacts-missed
  - peer-system-unresolved
  - tiff-corpus-vs-individual-handoff-confused
  - retry-retention-policy-not-extracted
  - mutual-tls-vs-password-auth-not-distinguished
  - dropzone-staleness-undetected
benchmark_tags:
  - discovery-integration
  - file-transfer-inventory
  - cross-system-interface
  - secure-ftp-migration
---

# file-transfer-interface-validator

## Purpose
Discover every file-transfer interface in a legacy application and
produce a machine-readable inventory that downstream Design can
consume as an integration contract. These interfaces are the silent
hidden dependency in modernization — a modernized app that forgets
one nightly SFTP drop will break the downstream consumer in a way
that appears days after cutover.

## Inputs
- Repository tree, especially `interfaces/`, `processes/`,
  `ops/runbooks/`, `ci/`, `docs/`, `batch/`, `config/`.
- Application catalog entry from `catalog-application` listing
  the app's external integration points.
- Optional: Control-M JIL / Autosys / cron files from a sibling
  ops repo.
- Optional: secrets-redacted config dumps for endpoints
  (`web.config`, `app.config`, `appsettings.json`, `*.env`).

## Outputs
- `file-transfer-inventory.json` — per interface:
  `{interface_name, direction (inbound | outbound | bidirectional),
  protocol (sftp | ftps | ftp | scp | rsync | aspera | http_upload |
  https_upload | s3 | azure_blob | smb | nfs), peer_system,
  local_path_or_dropzone, remote_path_or_dropzone, schedule
  (cron or oracle or control-m or event-driven or ad-hoc), file_types
  (extensions + MIME + whether TIFF-corpus or individual-handoff),
  estimated_volume, authentication_mode (password | ssh-key |
  certificate | mutual-tls | kerberos | none), retention_policy,
  retry_policy}`
- `file-transfer-protocol-findings.json` — per protocol flag:
  `{interface_name, finding_type (plain_ftp_cleartext |
  weak_cipher | legacy_tls | credential_hardcoded |
  no_integrity_check), severity}`. `plain_ftp_cleartext` is
  always severity P0.
- `file-transfer-credential-findings.json` — every credential
  reference discovered: `{location, credential_type, is_redacted,
  storage_mode (config_file | env_var | windows_credential_manager |
  key_vault | hardcoded)}`. Hardcoded or config-file-plaintext is
  severity P0.
- `file-transfer-peer-system-graph.json` — directed edges between
  this app and external peer systems, with interface metadata. One
  node per peer (CAIS, USPS, IPC, Finalist/Melissa, DMS, AMCS) and
  one edge per inbound / outbound feed.

## Methodology
1. **Enumerate candidate directories** (`interfaces/`, `processes/`,
   `batch/`, `ops/`, `ci/`, `config/`) and candidate filenames
   matching `*sftp*`, `*ftp*`, `*eft*`, `*transfer*`, `*drop*`,
   `*handoff*`, `*export*`, `*interface*`.
2. **Parse config for endpoints.** Grep for `sftp://`, `ftps://`,
   `ftp://`, `scp://`, hostname + port patterns (`:22`, `:21`,
   `:990`), WinSCP scripts (`open sftp://...`), PowerShell
   Posh-SSH / WinSCP session objects.
3. **Resolve per-protocol credentials.** For every endpoint, grep
   co-located config for username, password (flag if present
   verbatim), key_file path, certificate thumbprint, Kerberos SPN.
4. **Cross-reference schedule.** Check `ci/` Jenkinsfiles, Control-M
   JIL files, Oracle `DBMS_SCHEDULER` jobs (via the
   `oracle-scheduler-job-extractor` output if available), Windows
   Task Scheduler XML, cron files.
5. **Peer-system resolution.** For each remote host, cross-reference
   against known peer systems from client-profile config (FAA:
   CAIS, USPS, Melissa/Finalist, IPC, TSA, Login.gov). Emit the
   inferred peer for each edge.
6. **Classify file types.** Per drop directory, sample extensions
   and MIME. Distinguish TIFF-corpus handoffs (bulk image archives)
   from individual-file handoffs (one TIFF per transaction), flat
   file feeds (`.csv`, `.txt`), XML/JSON payloads, ZIP bundles.
7. **Extract retention + retry policies.** Look for comments in
   scripts, `--retry-count` flags, `maxAttempts` in config, explicit
   `.move-to-archive` or `.delete-after` post-transfer operations.
8. **Emit all four manifests with `{repo}:{file}:{line}` citations.**

## Tech-Stack Dispatch

| Trigger | Reference loaded |
|---|---|
| Globalscape EFT / WinSCP / PSFTP references | `references/secure-ftp-patterns.md` |
| D-series batch (`D05`, `D10`, `D48`, …) nightly drops | `references/secure-ftp-patterns.md` (D-series section) |

## Gotchas
- **`ftp://` is cleartext.** Credentials and data visible on the
  wire. Any `ftp://` endpoint is severity P0 — must migrate to
  SFTP or FTPS before modernization.
- **FTPS ≠ SFTP.** FTPS is FTP over TLS (ports 21/990, dual-channel
  control + data, firewall-unfriendly). SFTP is SSH File Transfer
  Protocol (port 22, single channel). Don't conflate.
- **Schedule is split across artifacts.** The endpoint is in config;
  the schedule is in Control-M; the transform is in PL/SQL or .NET;
  the credentials are in Windows Credential Manager or a Key Vault.
  Must gather all four to reconstruct the full interface.
- **Peer system resolution is inferential.** FTP endpoint
  `sftp.usps.gov:22` is USPS; `aviation-finalist.com:22` is
  Finalist; unlabeled corporate IPs need human confirmation.
  Emit `peer_unresolved` finding rather than guessing.
- **TIFF corpus vs individual TIFF handoff.** RMS sends bulk
  145M-image TIFF corpora over SFTP (separate concern, handled
  by `tiff-corpus-assessor`). IACRA sends one TIFF per application
  to CAIS (individual handoff). Two different interfaces with
  different sizing, retry, and modernization implications.
- **Retention policies matter.** Some peer systems expect the
  sender to purge dropzone files after ACK; others expect the
  receiver to purge. Missing retention = disk-space bomb over
  months. Extract per interface.
- **Retry policy + idempotency.** An interface that retries on
  failure but lacks a transaction ID will double-send. Look for
  `messageId` / `transactionId` headers; flag interfaces without
  idempotency keys as severity P1.
- **Dropzone staleness.** A drop folder that hasn't received a
  file in 30+ days may be orphaned — the peer stopped sending
  but nobody turned off the watcher. Record last-observed file
  date per dropzone (when discoverable from logs).
- **Certificate expiry surfaces during cutover, not before.**
  Flag every certificate-based auth interface with the expiry
  date (if extractable) — modernization deployments frequently
  fail at cert-expiry boundaries.
- **Windows Credential Manager is opaque to source scanning.**
  Scripts that call `WinSCP.exe -username $env:USER -password $env:PASS`
  reference credentials that live outside the repo; emit finding
  that credentials are ENV-managed.
- **Globalscape EFT** (RMS) is a commercial SFTP server with
  proprietary event processing. Its advanced workflows (custom
  event handlers written in the EFT admin UI) are invisible to
  source inspection; flag as "EFT workflow extraction requires
  server access".

## Quality Rules
- [ ] Every file-transfer interface has an inventory record with
      direction, protocol, peer, schedule, and authentication.
- [ ] Plain FTP endpoints emit severity P0 findings.
- [ ] Hardcoded credentials emit severity P0 findings.
- [ ] Certificate-based auth interfaces carry expiry-date metadata
      when extractable.
- [ ] Peer systems are resolved or flagged `peer_unresolved`.
- [ ] Retention and retry policies are extracted per interface.
- [ ] Every record carries `{repo}:{file}:{line}` traceability.

## Common Failure Modes

| Failure Mode | Symptom | Prevention |
|---|---|---|
| FTP and SFTP conflated | Manifest lists sftp endpoint on port 21 (impossible — SFTP is port 22) | Parse protocol from URL scheme, not just port |
| Peer inferred from partial hostname | `sftp.ops.local:22` labeled as "USPS" without verification | Emit `peer_unresolved` unless the hostname matches a known peer in the client profile |
| Schedule missed | Interface inventory lacks schedule; operators don't know when to expect the next drop | Cross-reference Control-M / Jenkins / cron / DBMS_SCHEDULER for every endpoint |
| Credentials extracted verbatim into manifest | PII/secrets in the finding artifact itself | Redact credential values; emit locations only |
| Dropzone retention policy missed | Months later the target disk fills up | Extract retention or emit `retention_unknown` finding |

## Handoff Summary
When this skill completes, verify:
1. Every inbound and outbound file transfer has an inventory entry
   with protocol + peer + schedule + auth.
2. Plain FTP endpoints are flagged severity P0.
3. Peer systems are resolved against the client profile's peer
   registry.
4. Schedules are reconciled across Control-M, Jenkins, cron, and
   DBMS_SCHEDULER.

Then proceed to: `portfolio-integration-mapper` (Rationalization
primary) — which consumes the peer-system graph for the overall
integration topology; and `cato-compliance` — which verifies that
cleartext-FTP endpoints are addressed before the authority-to-
operate gate.

## References
- `references/secure-ftp-patterns.md` — SFTP vs FTPS vs FTP
  comparison, Globalscape EFT workflow model, WinSCP / PSFTP /
  OpenSSH `sftp` command patterns, certificate vs key vs password
  auth, common misconfigurations.

## Changelog
- 0.1.0 (2026-05-07) — Initial skill. Covers file-transfer
  inventory, protocol findings, credential findings, peer-system
  graph. Closes FAA4-11 G-8 carry-over. Authored as ATLAS-R-14.
