# Secure-FTP Patterns

Coverage for the four transport mechanisms most common in legacy FAA
integrations: SFTP (SSH File Transfer Protocol), FTPS (FTP over
TLS), FTP (cleartext — deprecated but still present), and
Globalscape EFT's proprietary orchestration.

## SFTP vs FTPS vs FTP

| Feature | SFTP | FTPS | FTP |
|---|---|---|---|
| Underlying protocol | SSH | FTP + TLS | FTP only |
| Default port | 22 | 21 (explicit) / 990 (implicit) | 21 |
| Channels | 1 (multiplexed) | 2 (control + data) | 2 (control + data) |
| Cleartext credentials | no | no (TLS) | **yes** |
| Cleartext data | no | no (TLS) | **yes** |
| Firewall friendliness | good | poor (dynamic data port) | poor |
| Auth: password | yes | yes | yes |
| Auth: public key | yes (SSH keys) | no | no |
| Auth: certificate | no | yes (X.509) | no |
| Auth: keyboard-interactive | yes | no | no |
| Transfer mode | stream | ASCII or binary | ASCII or binary |

**Rule:** SFTP is the modern default. FTPS survives in firewall-
tolerant environments or when a peer requires X.509 mutual auth.
FTP is severity P0.

## Common Endpoint Patterns

### PowerShell Posh-SSH / WinSCP

```powershell
# Posh-SSH
$session = New-SFTPSession -ComputerName sftp.peer.gov -Credential $cred -KeyFile C:\keys\id_rsa
Get-SFTPFile -SessionId $session.SessionId -RemoteFile "/inbox/*.tiff" -LocalPath D:\drop\

# WinSCP .NET assembly
$sessionOptions = New-Object WinSCP.SessionOptions -Property @{
    Protocol = [WinSCP.Protocol]::Sftp
    HostName = "sftp.peer.gov"
    UserName = "faa_upload"
    SshHostKeyFingerprint = "ssh-rsa 2048 xx:yy:zz..."
    SshPrivateKeyPath = "C:\keys\id_rsa.ppk"
}
```

### OpenSSH `sftp` CLI

```
sftp -i /path/to/key -oPort=22 user@sftp.peer.gov:/inbox/
```

Batch mode with `-b`:

```
sftp -b commands.txt user@sftp.peer.gov
```

### .NET `SshNet` / `Renci.SshNet`

```csharp
using (var client = new SftpClient("sftp.peer.gov", 22, "user", new PrivateKeyFile(keyPath)))
{
    client.Connect();
    using (var fs = File.OpenRead(localPath))
    {
        client.UploadFile(fs, remotePath);
    }
    client.Disconnect();
}
```

### Python `paramiko` / `pysftp`

```python
import paramiko
transport = paramiko.Transport(("sftp.peer.gov", 22))
transport.connect(username="user", pkey=paramiko.RSAKey.from_private_key_file(keypath))
sftp = paramiko.SFTPClient.from_transport(transport)
sftp.put(local_path, remote_path)
```

### Classic FTP (flag as P0)

```csharp
var request = (FtpWebRequest)WebRequest.Create("ftp://ftp.peer.gov/inbox/file.tiff");
request.Credentials = new NetworkCredential("user", "password");
request.Method = WebRequestMethods.Ftp.UploadFile;
```

Any `ftp://` URL scheme or `FtpWebRequest` reference = severity P0.

## Globalscape EFT

RMS uses Globalscape EFT Server — a commercial SFTP server with
event-driven workflow orchestration. EFT's advanced behavior is
configured via the EFT admin UI and stored in server-side config
files that are NOT typically in source control. Source-visible
references are typically:

- Shell scripts invoking EFT CLI (`EFTClient.exe -transfer ...`).
- Event triggers referenced by name (e.g.,
  `eft-event:NightlyTiffUpload`) in documentation or JCL.
- SMTP relay config for EFT-generated notifications.

**Rule:** Flag every EFT reference with "EFT workflow extraction
requires server access" — source alone cannot reconstruct the full
workflow.

## Authentication Mode Detection

### Password auth

Grep for plaintext password patterns in config:

```xml
<add key="SftpPassword" value="hunter2" />
```

Severity P0 — flag and redact.

### SSH private key auth

```
SshPrivateKeyPath = "C:\keys\id_rsa.ppk"
```

Flag the key path; emit finding about key-rotation strategy. Keys
committed to source control are severity P0 (impossible to rotate
without git history rewrite).

### X.509 client certificate (FTPS)

```
ClientCertificate = new X509Certificate2("client.pfx", "password")
```

Extract thumbprint + expiry date if PFX is accessible.

### Mutual TLS

Both client and server present certificates; common for government-
to-government FTPS. Extract both thumbprints.

### Kerberos / SSPI

Windows-integrated auth; appears as `UseSSPI = true` or
`AuthenticationType = Kerberos`. Credentials come from the service
account.

## Common Misconfigurations

- **Cleartext FTP with `PASS` command visible** — P0.
- **FTPS with TLS 1.0 / TLS 1.1** — deprecated; P1.
- **SFTP with MD5 or SHA-1 host-key fingerprint verification** —
  weak hash; P1.
- **Blind host-key acceptance** (`StrictHostKeyChecking=no`) — MitM
  risk; P0.
- **Weak ciphers** (`3DES`, `RC4`, `DES`) — P0.
- **Hardcoded private key in source** — P0 (impossible to rotate).
- **Shared service account across multiple peers** — P1; per-peer
  credentials are the correct model.
- **No fingerprint pinning** — allows MitM on first connect; P1.
- **No retention policy** — dropzone grows unbounded; P2.
- **No retry with exponential backoff** — transient failure cascades
  to alerts; P2.
- **Credentials in URL** (`sftp://user:pass@host/`) — logged by
  default in most CLI tools; P0.

## Modernization Targets

Replacements to recommend per current protocol:

| Current | Recommended replacement |
|---|---|
| FTP | SFTP on port 22, SSH-key auth, fingerprint pinning |
| FTPS | Keep FTPS if peer requires; else migrate to SFTP |
| SFTP password auth | SFTP SSH-key auth, keys in secrets manager |
| Globalscape EFT | Keep EFT for Windows peers; consider AWS Transfer Family for cloud migration |
| File-drop-based integrations | REST API or event-driven messaging (Kafka, SQS) if peer supports |
| Custom batch + SFTP | Managed file transfer (MFT) service |

## Orchestration Patterns

### Schedule sources

The schedule that fires the transfer is usually separate from the
transfer code. Reconcile across:

- Control-M JIL files (`JOB: NIGHTLY_TIFF_UPLOAD`).
- Autosys definitions (`JOB_TYPE: c`).
- Windows Task Scheduler XML (`C:\Windows\System32\Tasks\*`).
- Cron / systemd timers on Linux.
- Oracle DBMS_SCHEDULER jobs invoking a PL/SQL proc that calls
  `UTL_FILE` or `DBMS_SCHEDULER.RUN_JOB` against an external
  proc.
- Jenkins pipeline stages.
- Event-driven: Globalscape EFT event handlers, file-watchers
  (`System.IO.FileSystemWatcher`).

### Retry + alerting

Mature interfaces emit alerts on failure:

- Email via SMTP relay (look for `SmtpClient` + to-address
  patterns).
- SNMP traps (`Get-EventLog` forwarding).
- Custom webhook to ops dashboard.
- Log-based alerting (Splunk, ELK).

Record the alerting channel per interface — operators need to
maintain it through modernization.
