# Integration Project Patterns

Coverage for the four canonical shapes of a dedicated integration
project in a legacy .NET portfolio: console exe, Windows Service,
web-app integration, and scheduled-task console.

## Console EXE Integration

Most common shape for overnight batch integrations. Typical layout:

```
CAIS Export/
├── CAIS Export.sln
├── CAIS Export.csproj
├── Program.cs                 # Main entry point
├── Exporter.cs                # Core export logic
├── DataAccess.cs              # DB reader
├── FileWriter.cs              # Output writer
├── App.config                 # Peer endpoint + DB connection
└── packages.config            # NuGet deps
```

### Entry point anatomy

```csharp
static int Main(string[] args)
{
    var config = ConfigurationManager.AppSettings;
    var exporter = new Exporter(config["SourceDB"], config["OutputPath"]);
    try
    {
        var batchId = Guid.NewGuid().ToString();
        var count = exporter.Run(batchId);
        log.Info($"Exported {count} records in batch {batchId}");
        return 0;
    }
    catch (Exception ex)
    {
        log.Error(ex, "Export failed");
        return 1;
    }
}
```

Extraction targets: config keys, entry class + method, error
handling, exit codes.

### Scheduling sources

Console exes are triggered by:

- Windows Task Scheduler (`schtasks.exe` / XML task definitions in
  `C:\Windows\System32\Tasks\*`).
- Control-M JIL (`JOB: CAIS_EXPORT_NIGHTLY ... CMDLINE: C:\apps\CAIS Export\CAIS Export.exe`).
- Jenkins `sh` / `powershell` stage.
- PowerShell-based ops script.
- Sometimes orchestrated by a wrapper batch file that invokes the
  exe with specific args.

## Windows Service Integration

For continuous or event-driven integrations:

```csharp
public partial class ExportService : ServiceBase
{
    protected override void OnStart(string[] args)
    {
        _timer = new Timer(_ => RunExport(), null, 0, 60_000); // every 60s
    }
    protected override void OnStop() { _timer?.Dispose(); }
}
```

Or modern .NET Core:

```csharp
public class ExportWorker : BackgroundService
{
    protected override async Task ExecuteAsync(CancellationToken stopToken)
    {
        while (!stopToken.IsCancellationRequested)
        {
            await DoExport();
            await Task.Delay(TimeSpan.FromMinutes(1), stopToken);
        }
    }
}
```

Installation:
- Classic: `InstallUtil.exe ExportService.exe` or
  `sc.exe create ExportService binPath= "C:\apps\ExportService.exe"`.
- Modern: `dotnet publish` then register as a Windows Service via
  `sc create` or systemd unit on Linux.

## Web-App Integration

Some integrations live inside an ASP.NET web app that exposes
endpoints for peer systems to call (or IACRA's `DMSWebApp` which
is a web front-end IACRA ships for DMS interop).

```
DMSWebApp/
├── DMSWebApp.sln
├── Default.aspx
├── TransferStatus.aspx
├── Web.config
└── bin/
```

Role classification:
- **Inbound endpoint:** peer HTTP-calls this app (e.g., DMS -> IACRA).
- **Outbound via embedded UI:** app hosts a UI consumed by DMS users.
- **Passive viewer:** app displays integration status without executing
  transfers.

Inspect pages for `Response.Redirect` targets, `HttpClient` outbound
calls, and `<asp:SqlDataSource>` DB reads to classify.

## Scheduled-Task Console

Essentially a console exe but wrapped in a project whose only
purpose is the schedule. Often the project name embeds the schedule:

```
NightlyCAISExport/
WeeklyPTRSExport/
HourlySyncRMS/
```

Treat as console exe; extract the frequency from the project name
AND the scheduler config (they should match; discrepancy is a
finding).

## Peer-System Naming Conventions

ATLAS AAM naming:

| Project name suffix or prefix | Peer system |
|---|---|
| `*ToRMS`, `*RMS*` | RMS (airmen registry) |
| `CAIS*`, `*CAIS` | CAIS (NATURAL-on-mainframe airmen system) |
| `AADOCS*` | AADOCS (NATURAL workflow engine) |
| `PTRS*` | PTRS (Program Tracking and Reporting Subsystem) |
| `DMS*` | DMS (Designee Management System) |
| `USAS*` | USAS (US Airmen System, legacy) |
| `ForeignVer*` | Foreign verification cert flow |
| `IPC*` | IPC (certificate printing vendor) |
| `IACRA*` | IACRA (airman cert application) |

Resolve project names against client-profile peer registry. Flag
unresolvable names.

## Data Contract Reconstruction

To reconstruct the data contract for an integration, trace:

1. **Source.** SQL query or stored proc called by the integration.
   Capture column list.
2. **Transform.** LINQ / mapper / string concatenation in code.
   Capture per-field transformation.
3. **Target format.** Flat file (CSV, pipe-delimited, fixed-width),
   XML, JSON, TIFF, EDI, or custom binary.
4. **Target field names.** For flat files, the column header or
   position. For XML/JSON, the element/property name.

Example output:

```json
{
  "integration": "CAIS Export",
  "data_contract": [
    {
      "source_column": "APPLICANT.FIRST_NAME",
      "target_field_name": "AirmanFirst",
      "target_position": 1,
      "transformation": "Trim().ToUpper()",
      "format": "VARCHAR(30)",
      "is_required": true
    },
    {
      "source_column": "APPLICANT.DOB",
      "target_field_name": "DateOfBirth",
      "target_position": 7,
      "transformation": "Format('yyyyMMdd')",
      "format": "NUMERIC(8)",
      "is_required": true
    }
  ]
}
```

## Idempotency and ACK

Mature integrations include:

- **Transaction/batch ID** generated per run (GUID, ULID, timestamp).
- **Peer ACK mechanism:** file rename (`.pending` -> `.processed`),
  database flag update, return-receipt file from peer.
- **Retry with backoff** on transient failure.
- **Dead-letter queue** for poison messages.

Gaps to flag:

- Retry without idempotency key = double-sending on retry.
- No ACK = silent data loss on peer failure.
- No batch ID = cannot reconcile if the peer asks "did you send
  batch X?"

## Transformation Patterns

Observed transforms:

- **Direct passthrough:** `row["FirstName"].ToString()`.
- **Formatting:** `dateField.ToString("yyyyMMdd")`,
  `amount.ToString("F2")`.
- **Lookup enrichment:** `lookupService.GetCode(row["Category"])`.
- **Concatenation:** `row["First"] + " " + row["Last"]`.
- **Splitting:** SSN split into area/group/serial.
- **Mask / redaction:** SSN masked to last-4.
- **Codeset translation:** airport code mapping (IATA <-> ICAO).

Capture the transformation expression per field; modernization
cannot skip these.

## Configuration and Secrets

Every integration has config for:

- Source DB connection string.
- Target endpoint (SFTP host, HTTP URL, file-drop path).
- Credentials (flag if hardcoded).
- Batch size / rate limit.
- Retry policy (max attempts, backoff).
- Output path template (e.g., `{peer}/{yyyy-MM-dd}/{batchId}.dat`).

Extract all from `App.config` / `Web.config` /
`appsettings.{env}.json`. Redact credential values; keep keys.

## Pair with file-transfer-interface-validator

This skill and `file-transfer-interface-validator` cover adjacent
surfaces:

- **`cross-system-integration-export-extractor`** — the project,
  the data contract, the business logic, the schedule.
- **`file-transfer-interface-validator`** — the protocol, the
  endpoint, the credentials, the peer connectivity.

Run both for a complete picture of cross-system integration.
