---
name: cross-system-integration-export-extractor
description: >
  Inventory every cross-system integration and export project in a
  legacy .NET repo — dedicated projects whose sole purpose is to transfer
  data from the host application to another system. These are often named
  by peer system (`CAIS Export`, `PTRS Export`,
  `ApplicationTransferToRMS`, `DMSWebApp`, `ExportForeignVerApps`),
  shipped as a separate solution, scheduled independently, and are the
  first thing to break on cutover if the peer contract is not preserved.
  Fires for IACRA whose `processes/` and `src/` include
  `ApplicationTransferToRMS`, `CAIS Export`, `PTRS Export`, `DMSWebApp`,
  `ExportForeignVerApps`. This is the outbound side of FAA4-11 G-8
  (`file-transfer-interface-validator` handles the mechanics; this
  skill handles the business-logic surface of each integration).
  Runs as a Discovery conditional skill when repo contains a top-level
  `processes/` directory or project names matching `*Export*`,
  `*Transfer*`, `*Integration*`, `*Interface*`, `*Sync*`, `*Feed*`.
  Triggers on cross-system integration inventory, FAA inter-system
  handoff extraction, export-job discovery, or
  @cross-system-integration-export-extractor.
agent: sonnet
allowed-tools:
  - Read
  - Write
  - Grep
  - Glob
validation_commands:
  - "python -m olympus.validators.schema_validator integration-project-inventory.json"
  - "python -m olympus.validators.schema_validator integration-data-contract.json"
  - "python -m olympus.validators.schema_validator integration-peer-system-graph.json"
  - "python -m olympus.validators.schema_validator integration-schedule-findings.json"
supported_stacks:
  - csharp
  - vbnet
  - dotnet
  - aspnet
  - integration
  - export
anti_target_stacks:
  - rest-api
  - graphql
  - grpc
  - event-driven
  - static-site
failure_classes:
  - peer-system-unresolved
  - data-contract-drift-vs-peer
  - schedule-orphaned
  - transaction-id-missing
  - retry-without-idempotency
  - one-way-export-with-no-ack
  - dedicated-project-vs-inlined-logic-confused
  - legacy-dmswebapp-role-misclassified
benchmark_tags:
  - discovery-integration
  - cross-system-export
  - peer-system-topology
  - data-contract-inventory
---

# cross-system-integration-export-extractor

## Purpose
Elevate dedicated integration/export projects to first-class Discovery
artifacts. Legacy .NET portfolios often ship these as separate
projects — named after the peer system — and they encode critical
contracts: what fields are exported, in what format, on what
schedule, with what retry/ack semantics. Modernization that forgets
these projects silently breaks downstream peers after cutover.
`file-transfer-interface-validator` handles the *how* (protocol,
endpoint, credentials); this skill handles the *what* (data
shape, schedule, business logic).

## Inputs
- Repository tree with top-level `processes/`, `interfaces/`,
  `export/`, `sync/`, `feeds/`, or `src/*Export*`/`src/*Transfer*`.
- Application catalog entry from `catalog-application`.
- Optional: related peer-system catalog (if the full portfolio is
  available — RMS, DMS, IACRA, AMCS, MEDXPRESS for the ATLAS case).
- Optional: `file-transfer-inventory.json` from
  `file-transfer-interface-validator` — pairs the mechanics with
  the business logic.

## Outputs
- `integration-project-inventory.json` — per project:
  `{project_name, project_path, direction (outbound-feed |
  inbound-consume | bidirectional), peer_system, project_type
  (console_exe | windows_service | scheduled_task | web_app),
  entry_point_class_method, data_source (DB table / view / proc),
  output_format (flat-file | xml | json | tiff | edi | custom)}`
- `integration-data-contract.json` — per integration: the full
  data shape sent or received: `{field_name, source_column_or_proc,
  target_field_name, transformation, is_required, format}`.
- `integration-peer-system-graph.json` — directed edges per peer:
  `{app_name -> peer_system, cardinality (1:1 | 1:N), frequency
  (continuous | hourly | daily | weekly | on-demand)}`.
- `integration-schedule-findings.json` — how each integration is
  triggered: Control-M JIL, Jenkins pipeline, Windows Task
  Scheduler, DBMS_SCHEDULER, cron, event-driven watcher, or manual.

## Methodology
1. **Enumerate candidate directories.** Walk `processes/`,
   `interfaces/`, `export/`, `sync/`, `feeds/`. Enumerate `src/`
   children matching `*Export*`, `*Transfer*`, `*Integration*`,
   `*Interface*`, `*Sync*`, `*Feed*`, `*DmsApp*`, `*Connector*`.
2. **Classify project type.** `OutputType=Exe` = console exe;
   `ServiceBase` derivation = Windows Service;
   `Microsoft.AspNetCore.App` or `System.Web` reference = web app
   integration (`DMSWebApp` case); standalone `.sln` with
   `BackgroundService` = .NET Core worker.
3. **Identify peer system.** Project name + README + config
   connection strings + code comments. IACRA's `ApplicationTransferToRMS`
   is outbound to RMS; `CAIS Export` outbound to CAIS; `PTRS Export`
   outbound to PTRS; `DMSWebApp` is IACRA-side of a DMS integration.
4. **Resolve entry point.** `Program.Main` for exes;
   `OnStart` / `ExecuteAsync` for services; page class for web apps.
5. **Reconstruct data contract.** Trace data flow from source
   (usually a DB query or stored proc) through transformations
   (LINQ, string concatenation, serialization) to output format
   (flat file, XML, TIFF).
6. **Detect schedule.** Cross-reference Control-M JIL files,
   Jenkins pipelines, Windows Task Scheduler XML, cron files,
   DBMS_SCHEDULER jobs, event watchers.
7. **Detect ack / idempotency semantics.** Look for transaction
   IDs, message IDs, retry logic, exactly-once guards. Missing =
   finding.
8. **Emit all four manifests with `{repo}:{file}:{line}`.**

## Tech-Stack Dispatch

| Trigger | Reference loaded |
|---|---|
| Console exe or Windows Service project | `references/integration-project-patterns.md` |

## Gotchas
- **Dedicated projects hide critical business logic.** A project
  named `CAIS Export` might look like scaffolding but contains
  the full export transform for 30+ fields, with CFR-regulated
  field formats. Don't skim.
- **Peer-system name is inferential.** `DMSWebApp` in IACRA is
  ambiguous: is it IACRA's embed of DMS, or IACRA's outbound
  interface to DMS? Inspect code to determine direction.
- **Schedule lives outside the project.** The `.exe` builds; the
  Control-M JIL or Task Scheduler XML runs it. Miss either side
  and you miss the integration.
- **One-way exports with no ACK are risky.** Downstream peer can
  drop a batch and nobody knows. Flag integrations without
  ACK/receipt confirmation.
- **Transaction ID gaps.** Without per-batch IDs, retries can
  double-send. Extract retry logic AND idempotency key
  (transaction ID, message ID, batch ID).
- **`DmsApp*` naming is ambiguous.** IACRA's `DMSWebApp` could
  be: (a) a web app consumed by DMS users, (b) a service exposing
  data for DMS to pull, (c) an IACRA-side client that pushes to
  DMS. Read the code.
- **`ExportForeignVerApps`** — "export foreign verification
  applications" — foreign-pilot cert verification flow.
  Specialized, low-volume, often regulatory-sensitive. Flag.
- **Config may be per-environment.** `Web.config` /
  `App.config` / `appsettings.{env}.json` — different peer
  endpoints per env. Extract all.
- **Legacy `processes/` convention.** Pre-2010 .NET shops kept
  console-exe integrations in a top-level `processes/` folder
  rather than under `src/`. Detect this convention.
- **Zero-activity projects still matter.** A project that built
  in 2015 and hasn't been run since may still be scheduled in
  Control-M as a no-op; modernization must decide: retire,
  reactivate, or reimplement.

## Quality Rules
- [ ] Every integration project has an inventory record with
      peer system + direction + project type.
- [ ] Every project has a resolved entry point.
- [ ] Every integration has a data contract with source /
      transformation / target per field.
- [ ] Peer systems resolve against the client-profile registry
      or are flagged `peer_unresolved`.
- [ ] Every integration has a schedule entry (or
      `schedule_orphaned` finding).
- [ ] Idempotency and ACK semantics recorded per integration.
- [ ] Every record carries `{repo}:{file}:{line}` traceability.

## Common Failure Modes

| Failure Mode | Symptom | Prevention |
|---|---|---|
| Peer system guessed | `DmsWebApp` labelled as DMS when it's actually IACRA's DMS-facing exporter | Read code, don't guess from name alone |
| Schedule missed | `.exe` inventoried but no trigger; operator cannot tell if/when it runs | Cross-reference Control-M/Jenkins/Task Scheduler/cron |
| Data contract undocumented | Project lists peer + schedule but no field shape | Trace DB query -> transform -> output format |
| Retry without idempotency | Integration retries on failure; duplicates land in peer | Verify transaction/message ID presence |

## Handoff Summary
When this skill completes, verify:
1. Every integration project is catalogued with peer + direction +
   project type + entry point + schedule.
2. Every integration's data contract is reconstructed (field
   shape, transforms, format).
3. The peer-system graph shows every outbound and inbound edge.
4. Idempotency and ACK semantics are recorded.

Then proceed to: `portfolio-integration-mapper` (Rationalization
primary) — which consumes the peer graph for the portfolio-level
topology; `file-transfer-interface-validator` pairs with this
skill to provide the transport-layer mechanics.

## References
- `references/integration-project-patterns.md` — console-exe
  integration shape, Windows Service shape, web-app integration,
  peer-system naming conventions, data-contract reconstruction,
  schedule sources.

## Changelog
- 0.1.0 (2026-05-07) — Initial skill. Covers dedicated integration
  project inventory and data-contract reconstruction. Authored as
  ATLAS-R-17.
