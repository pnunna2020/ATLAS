# PostgreSQL Extensions and Operational Tooling

Detection and extraction reference for the PostgreSQL extension inventory and
the operational surface around a PG deployment: authentication, server
tuning, connection pooling, backup, replication, foreign data wrappers, and
auditing. Used by `postgresql-discovery-patterns` during Discovery.

## Scope
This reference covers:
- Extension inventory with provenance classification (first-party,
  third-party, commercial).
- `.pgpass` credentials file format and redaction rules.
- `pg_hba.conf` per-client authentication rules and the `trust` hazard.
- `postgresql.conf` non-default server tuning settings.
- Connection pool tooling: PgBouncer `pool_mode`, pgcat, impact on feature
  availability.
- Backup and restore: `pg_dump` formats, `pg_basebackup`, `wal-g`,
  `pgbackrest`.
- Replication: WAL archiving, physical streaming, logical replication.
- Foreign data wrappers (`postgres_fdw`, `file_fdw`, `oracle_fdw`, `tds_fdw`).
- `SECURITY DEFINER` privilege escalation and `pgaudit`.

## Extension Inventory
Every `CREATE EXTENSION` statement is a row in `pg-extensions-manifest.json`.
Record:
- `name` — extension identifier.
- `schema` — target schema (default varies per extension).
- `version` — if pinned via `VERSION 'x.y'`; otherwise left unpinned.
- `provenance` — `first-party`, `third-party`, or `commercial`.
- `license_note` — when provenance is `commercial`, cite the license source.
- `pg_min_version` — minimum PG major version required (from extension docs).
- `citation` — `{repo}:{file}:{line}`.

### First-Party (Shipped with `contrib`, No License Surprise)
- `pgcrypto` — cryptographic functions, including `gen_random_uuid()` on
  PG13+ where it is a built-in (no extension needed).
- `uuid-ossp` — UUID v1/v3/v4/v5 generators. Deprecated in favor of
  `gen_random_uuid()` on PG13+; a `uuid-ossp` dependency on PG13+ is a
  modernization candidate.
- `citext` — case-insensitive text type.
- `hstore` — key/value text pairs (pre-`jsonb` legacy).
- `pg_trgm` — trigram similarity, pairs with `gin` indexes for LIKE / ILIKE
  and similarity search.
- `unaccent` — diacritic-insensitive text search helper.
- `pg_stat_statements` — query statistics; load via `shared_preload_libraries`.
- `postgres_fdw` — foreign data wrapper targeting remote PostgreSQL.
- `file_fdw` — foreign data wrapper reading flat files.
- `plpgsql` — the default procedural language; installed by default.
- `intarray`, `ltree`, `earthdistance`, `cube` — specialized data types.

### Third-Party (Open-Source, Installed Separately)
- `plv8` — JavaScript procedural language; build requires V8 toolchain.
- `pgaudit` — session and object-level auditing; load via
  `shared_preload_libraries`.
- `pg_cron` — in-database cron scheduler; requires configuration in
  `postgresql.conf`.
- `pgvector` — vector similarity search (embeddings); increasingly common in
  modernized apps.
- `postgis` — geospatial types and operators; heavyweight, ~400 functions.
- `oracle_fdw` — foreign data wrapper targeting Oracle; community-maintained.
- `tds_fdw` — foreign data wrapper targeting SQL Server / Sybase via FreeTDS.
- `plpython3u` — Python (untrusted) procedural language; `u` = untrusted.

### Commercial / License-Gated
- `timescaledb` — has an Apache-licensed open-source edition and a
  Timescale-licensed community edition (source-available, non-OSS) plus a
  paid tier. Flag any `timescaledb` install with a license note; downstream
  legal review depends on it.
- Other vendor-specific extensions (Citus Enterprise, EDB-specific) — flag
  if detected.

## `.pgpass`
Format: `hostname:port:database:username:password`, one record per line. The
file must be mode `0600` or PG refuses to read it. Presence in a repo is a
critical security finding.

Rules:
- Emit only the file location, line count, and a `credentials_present: true`
  flag. Never copy the password segment into any artifact.
- If the file is world-readable (mode > 0600), flag as an additional
  finding; the PG client will refuse it, but the committed mode reveals
  handling intent.
- `*` wildcards are permitted in any field; record the pattern coverage
  without the password.

## `pg_hba.conf`
Per-client host-based authentication rules. Each non-comment line is:
`type database user address method [options]` where type is one of `local`,
`host`, `hostssl`, `hostnossl`, `hostgssenc`, `hostnogssenc`.

Methods to recognize:
- `trust` — no authentication. Critical finding on every entry, even
  loopback; flag `severity: critical`.
- `reject` — explicit deny; the rule ordering matters.
- `md5` — password hashing; deprecated in favor of `scram-sha-256` on PG10+.
- `scram-sha-256` — preferred password method on PG10+.
- `password` — cleartext password over the wire; critical finding unless
  paired with `hostssl`.
- `peer` / `ident` — OS-level identity mapping; `local` socket typically
  uses `peer`.
- `cert` — client-certificate authentication.
- `gss` / `sspi` — Kerberos / SSPI.
- `ldap`, `radius`, `pam` — external auth backends; record the parameter
  line verbatim (minus any secret).

Rule order matters in `pg_hba.conf`; the first match wins. Record the line
number so downstream review can reason about ordering.

## `postgresql.conf`
The server tuning file. Default values vary per PG major version. Do not
dump the entire file; emit only non-default settings and focus on the
load-bearing shortlist:
- `max_connections` — default 100. Modern apps exceed this without PgBouncer.
- `shared_buffers` — default 128MB. Production tuning typically 25% of RAM.
- `work_mem` — default 4MB. Per-operation memory; too low causes disk
  sorts.
- `maintenance_work_mem` — default 64MB. Used by VACUUM, CREATE INDEX.
- `wal_level` — `minimal`, `replica` (default on recent versions), `logical`.
  Required ≥ `replica` for streaming replication, `logical` for logical
  replication.
- `archive_mode` — `off` (default), `on`, `always`. PITR and WAL shipping
  require `on` or `always`.
- `archive_command` — shell command for archiving each WAL segment.
- `synchronous_commit` — `on` (default), `off`, `local`, `remote_apply`,
  `remote_write`. `off` sacrifices durability for throughput.
- `autovacuum` — on by default; `autovacuum` = `off` is a red flag.
- `shared_preload_libraries` — comma-separated extension preload list;
  `pg_stat_statements`, `pgaudit`, `pg_cron`, `timescaledb` all load here.
- `listen_addresses` — binds. `*` is all interfaces; `localhost` is
  loopback-only.
- `ssl` — on / off.

Cite the PG major version used as the default baseline in the finding.

## Connection Pool Tooling
### PgBouncer
Config: `pgbouncer.ini`, users in `userlist.txt` (hashed with md5 or
scram-sha-256). Key field: `pool_mode`.
- `session` — each client gets a dedicated server connection for the
  session duration. Preserves all session state (prepared statements,
  `SET`, advisory locks, temporary tables).
- `transaction` — server connection is released to the pool at transaction
  end. Breaks prepared statements (unless reprepared), `SET`, advisory
  locks, and session-scoped temporary tables. Most common production mode.
- `statement` — server connection is released at statement end. Rare;
  breaks multi-statement transactions.

Record `pool_mode` because downstream extraction needs to know which
session features survive. Per-database overrides (`pool_mode =` within a
`[databases]` section) override the global default.

### pgcat
Config: `pgcat.toml`. Supports PostgreSQL protocol v3, replica load
balancing, sharding. Record pool mode plus any sharding configuration.

## Backup and Restore
Record every discovered backup tool invocation:
- `pg_dump` — logical dump.
  - `-Fc` custom format; compressed, restorable selectively with
    `pg_restore`.
  - `-Fd` directory format; parallel dump and restore.
  - `-Fp` plain SQL (default); human-readable, single-threaded restore.
  - `-Ft` tar format; legacy.
- `pg_dumpall` — cluster-wide dump including roles and tablespaces.
- `pg_basebackup` — physical base backup for PITR or replica seeding.
- `pg_restore` — restores `-Fc` and `-Fd` dumps.
- `wal-g` — WAL archiving + base backup to object storage.
- `pgbackrest` — enterprise backup manager with incremental support.
- `barman` — alternative backup manager.

Record retention drivers (cron schedule, systemd timer, Kubernetes CronJob,
cloud-native backup operator). A backup tool with no retention driver is an
operational finding.

## Replication
Three replication modes, all valid:
- **Physical streaming.** Primary sends WAL to a standby; standby applies
  directly. Config markers: `primary_conninfo` in standby,
  `standby.signal` file (PG12+) or `recovery.conf` (pre-PG12). Synchronous
  via `synchronous_standby_names` on primary.
- **WAL archiving for PITR.** `archive_mode = on` plus `archive_command`.
  Standby restores WAL from the archive via `restore_command`. Can combine
  with streaming for gap-filling.
- **Logical replication (PG10+).** Publications on publisher
  (`CREATE PUBLICATION pub FOR TABLE t1, t2`), subscriptions on subscriber
  (`CREATE SUBSCRIPTION sub CONNECTION '...' PUBLICATION pub`). Uses
  replication slots; orphaned slots can cause unbounded WAL retention on
  the publisher. Emit a finding for every publication and subscription.

Record replication slot inventory (`pg_replication_slots` view would show
it at runtime; in Discovery infer from publication/subscription config).

## Foreign Data Wrappers
Every `CREATE SERVER` / `CREATE FOREIGN TABLE` is a cross-database
integration surface. Record:
- FDW extension used (`postgres_fdw`, `file_fdw`, `oracle_fdw`, `tds_fdw`,
  etc.).
- Foreign server target (host, port, remote database).
- User mapping count (`CREATE USER MAPPING`); flag if a user mapping
  carries a password in plaintext in the SQL.
- Foreign-table schema; foreign tables are first-class objects and should
  appear in the schema manifest marked `kind: foreign_table`.

FDWs are a modernization-planning signal: any cross-DB query path implies
a dependency that extraction must follow.

## `SECURITY DEFINER` Escalation
`CREATE FUNCTION ... SECURITY DEFINER` means the function executes with the
owner's privileges, not the caller's. Equivalent to Oracle `AUTHID DEFINER`.
Every such function is a privilege-escalation vector; record:
- Function schema + name + signature.
- Owner role.
- Whether `SET search_path` is pinned inside the function (recommended
  defense against search-path hijack; absence is a finding).
- Whether the function is granted to `PUBLIC` (makes the escalation
  accessible to any role; finding).

## Auditing (`pgaudit`)
`pgaudit` enables session-level and object-level audit logging. Detection:
- `pgaudit` in `shared_preload_libraries`.
- `pgaudit.log` settings in `postgresql.conf` (`read`, `write`, `function`,
  `role`, `ddl`, `misc`, `all`).
- `pgaudit.role` for object-audit mode.

Record the configured audit scope; the absence of `pgaudit` on a
regulated workload is itself a finding (Discovery surface only; compliance
mapping happens downstream).

## Output Shape
Every row in the operational findings and extensions manifests carries:
- `finding_id` — `{manifest}:{section}:F-NNN`.
- `severity` — `info`, `minor`, `major`, `critical`.
- `source_citation` — `{repo}:{file}:{line}`.
- `redacted` — true when credentials or secrets were stripped before
  emission.
- `provenance` (extensions only) — `first-party`, `third-party`,
  `commercial`.
- `pool_mode` (connection-pool findings only) — `session`, `transaction`,
  `statement`.

A reviewer must be able to reconstruct the operational posture from these
manifests without opening the source files. Any finding that cannot stand
alone is incomplete.
