---
name: postgresql-discovery-patterns
description: >
  Recover the architecture, schema surface, PL/pgSQL programmability, extension
  footprint, row-level-security posture, operational tooling (`.pgpass`, `psql`
  scripts, `pg_hba.conf` / `postgresql.conf` fragments, backup/restore scripts),
  connection-pool config, and migration timeline of a PostgreSQL deployment
  during Discovery. Companion to `oracle-discovery-patterns` and
  `sqlserver-discovery-patterns`. Modernization target apps increasingly use
  PostgreSQL; detecting it in legacy stacks (often as a secondary audit/log DB
  sidecar alongside the primary Oracle / SQL Server tier, as in ATLAS DMS's
  `db/AuditLog.Database/`) is essential for a complete Discovery pass. Runs as
  a conditional Discovery skill when the tech fingerprint reports
  `database in {postgresql, postgres, pg}` or the repo contains `.pgpass`,
  `pg_hba.conf`, `postgresql.conf`, `*.plpgsql` files, or `.sql` files with
  `CREATE EXTENSION` / `CREATE FUNCTION ... LANGUAGE plpgsql` / `CREATE POLICY`.
  Triggers on PostgreSQL discovery, PL/pgSQL analysis, pgpass / pg_hba audit,
  postgres fingerprint, or @postgresql-discovery-patterns.
tier: 1
triggers:
  database: [postgresql, postgres, pg]
agent: sonnet
enrichment_level: Full
version: 0.1.0
allowed-tools:
  - Read
  - Grep
  - Write
validation_commands:
  - "python -m olympus.validators.schema_validator pg-schema-manifest.json"
  - "python -m olympus.validators.schema_validator pg-indexes-manifest.json"
  - "python -m olympus.validators.schema_validator pg-programmability-manifest.json"
  - "python -m olympus.validators.schema_validator pg-rls-manifest.json"
  - "python -m olympus.validators.schema_validator pg-extensions-manifest.json"
  - "python -m olympus.validators.schema_validator pg-partition-manifest.json"
  - "python -m olympus.validators.schema_validator pg-operational-findings.json"
  - "python -m olympus.validators.schema_validator pg-migration-timeline.json"
  - "python -m olympus.validators.schema_validator pg-backup-restore-manifest.json"
supported_stacks:
  - postgresql
  - postgres
  - pg
  - plpgsql
  - pgbouncer
  - timescaledb
  - pgvector
anti_target_stacks:
  - oracle
  - sqlserver
  - mysql
  - sqlite
  - static-site
failure_classes:
  - pgpass-credentials-leaked
  - pg-version-misidentified
  - rls-policy-orphaned
  - trigger-function-binding-unresolved
  - extension-license-not-flagged
  - timestamptz-vs-timestamp-confused
  - security-definer-escalation-unflagged
  - connection-pool-mode-misdetected
  - wal-archive-off-missed
  - foreign-data-wrapper-edge-missed
benchmark_tags:
  - discovery-database
  - postgresql-inventory
  - plpgsql-programmability
  - pg-operational-posture
---

# PostgreSQL Discovery Patterns

## Purpose
Produce a PostgreSQL-specific slice of the Discovery artifact for any
application whose database fingerprint is PostgreSQL, whether PostgreSQL is the
primary OLTP tier or a secondary audit / log sidecar. Generic RDBMS discovery
captures tables and columns, but it does not enumerate the PostgreSQL-specific
surface: PL/pgSQL functions, trigger function-plus-binding pairs, row-level
security policies, declarative partitioning, materialized views with refresh
scheduling, the extension inventory (`pgcrypto`, `uuid-ossp`, `pg_trgm`,
`postgis`, `pgvector`, `pg_stat_statements`, `pgaudit`, `pg_cron`,
`timescaledb`), and PG-only data types (`jsonb`, `hstore`, `uuid`, `citext`,
arrays, `timestamp with time zone`). This skill fills that gap so
Rationalization and downstream Modernization skills can reason about parity
risk, extension licensing, and operational posture before a disposition is
chosen. The ATLAS DMS audit-log sidecar is the canonical FAA-portfolio example;
the pattern of PG-as-audit-companion recurs in modernization planning for
Oracle- and SQL-Server-primary apps.

## Inputs
- Source code repository (Git URL or local path) containing application and
  database artifacts.
- Tech fingerprint from `analyze-application` Pass 1 with
  `database in {postgresql, postgres, pg}` (JSON per
  `schemas/discovery/tech-fingerprint.schema.json`).
- Application catalog entry (JSON per
  `schemas/discovery/application-catalog-entry.schema.json`).
- Database object scripts: `*.sql`, `*.plpgsql`, `schema/*.sql`,
  `functions/*.sql`, `triggers/*.sql`, `migrations/*.sql`, `Schemas/*.sql`,
  `Scripts/*.sql`.
- Migration trees: Flyway-style `V001__*.sql`, timestamped
  `20260115-*.sql`, Knex / Prisma / Atlas / Alembic / Liquibase-named scripts.
- Connection-string and config sources: `appsettings*.json`, `application.yml`,
  `.env`, `docker-compose.yml`, Terraform / Bicep / Helm templates.
- PostgreSQL operational files when present: `.pgpass`, `pg_hba.conf`,
  `postgresql.conf`, `recovery.conf` / `standby.signal`, `pgbouncer.ini`,
  `userlist.txt`, `pgcat.toml`.
- Backup / restore and deployment scripts: `*.ps1`, `*.sh`, `run.ps1`,
  `CreateUser.Sql`, `build.sql` that invoke `psql`, `pg_dump`, `pg_restore`,
  `pg_basebackup`, or `wal-g` / `pgbackrest`.
- Client-profile risk-classification config (`profiles/<client>/risk-classification.yaml`)
  for tier banding of the emitted findings.

## Outputs
- PostgreSQL fingerprint block merged into the tech fingerprint — server
  version, extensions in use, encoding / locale, replication topology, and PG
  role (`primary` vs `sidecar-audit`).
- `pg-schema-manifest.json` — tables, columns (PG-specific types: `uuid`,
  `jsonb`, `hstore`, arrays, `numeric(p,s)`, `timestamp with time zone`,
  `citext`), constraints (PK, FK, UNIQUE, CHECK, EXCLUDE), primary-key strategy
  (`serial` / `bigserial` / `uuid` via `gen_random_uuid()` or
  `uuid_generate_v4()`).
- `pg-indexes-manifest.json` — indexes with method (btree, hash, gin, gist,
  brin, spgist, bloom), partial / expression / covering flags, concurrent-build
  markers.
- `pg-programmability-manifest.json` — PL/pgSQL functions, SQL functions,
  procedures (PG11+), triggers split into function + binding, rules, regular
  and materialized views.
- `pg-rls-manifest.json` — row-level security: `CREATE POLICY` with
  `USING` / `WITH CHECK`, `ENABLE` vs `FORCE` per table, policy roles, and
  audit flag for silent mismatches.
- `pg-extensions-manifest.json` — every `CREATE EXTENSION` with provenance
  (first-party / third-party / commercial) and minimum PG version.
- `pg-partition-manifest.json` — declarative (PG10+) and legacy
  inheritance-based partitioning, parent plus child inventory.
- `pg-operational-findings.json` — `.pgpass` location (credentials redacted),
  `pg_hba.conf` per-rule auth method, `postgresql.conf` non-defaults focused on
  `max_connections`, `shared_buffers`, `wal_level`, `archive_mode`, `work_mem`,
  `synchronous_commit`, plus connection-pool tooling and auditing state.
- `pg-migration-timeline.json` — ordered `.sql` scripts with detected framework
  style (Flyway, timestamped, Knex, Prisma, Atlas, Alembic, Liquibase).
- `pg-backup-restore-manifest.json` — `pg_dump` / `pg_basebackup` /
  `pg_restore` invocations, dump format (`-Fc` / `-Fd` / plain), WAL
  archiving, logical replication slots.
- Every finding carries `{artifact}:{section}:{finding-id}` for cross-skill
  handoff and `{repo}:{file}:{line}` for source evidence.

## Methodology
1. **Confirm PostgreSQL presence.** Re-read the `analyze-application` tech
   fingerprint. If `database` is not in `{postgresql, postgres, pg}`, fall back
   to direct markers: `.pgpass`, `pg_hba.conf`, `postgresql.conf`, `.plpgsql`
   files, or `.sql` files containing `CREATE EXTENSION`, `LANGUAGE plpgsql`, or
   `CREATE POLICY`. Record the deciding file and line. If the repo carries PG
   as a sidecar (e.g., DMS `db/AuditLog.Database/` alongside a primary SQL
   Server tier), emit a dedicated `pg-role: sidecar-audit` finding; do not
   conflate it with the primary OLTP fingerprint.
2. **Enumerate schema objects.** Walk every `.sql` / `.plpgsql` file plus any
   SSDT-like `Schemas/` tree. For each `CREATE TABLE`, emit a row into
   `pg-schema-manifest.json` with every column's PG type preserved literally
   (never normalize `timestamp with time zone` to `timestamptz`, and never
   drop precision/scale on `numeric`). Record constraints including `EXCLUDE`
   (PG-specific) and primary-key strategy (`serial`, `bigserial`, `uuid` with
   default generator). See `references/pg-schema-and-plpgsql-patterns.md`.
3. **Enumerate indexes.** Parse `CREATE INDEX` statements. Record method
   (`btree` default, `hash`, `gin`, `gist`, `brin`, `spgist`, `bloom`),
   partial predicate (`WHERE` clause), expression (`ON t (lower(col))`),
   covering columns (`INCLUDE`), and whether `CONCURRENTLY` was used. A missing
   method defaults to `btree`; record that explicitly — do not leave the field
   null.
4. **Enumerate programmability.** For each `CREATE FUNCTION` /
   `CREATE OR REPLACE FUNCTION`, capture name, argument signature, return
   type, language (`plpgsql`, `sql`, `plpython3u`, `plv8`, `c`), volatility
   (`IMMUTABLE` / `STABLE` / `VOLATILE`), and `SECURITY DEFINER` vs
   `SECURITY INVOKER`. Triggers are two objects: the trigger function
   (`RETURNS trigger`) and the trigger binding (`CREATE TRIGGER ... EXECUTE
   FUNCTION ...`); emit both rows and cross-link them via `trigger_function_id`.
   Record procedures (PG11+, `CREATE PROCEDURE`) separately from functions.
5. **Enumerate row-level security.** For every `ALTER TABLE ... ENABLE ROW
   LEVEL SECURITY` (and `FORCE`), record table + enabled/forced flag. For every
   `CREATE POLICY`, record `USING` and `WITH CHECK` expressions, roles, and
   command scope (`ALL` / `SELECT` / `INSERT` / `UPDATE` / `DELETE`). Emit an
   audit flag when RLS is enabled without any policy (silent deny-all) or when
   a policy exists but RLS is not enabled on the table (silent policy-bypass).
6. **Enumerate extensions.** For every `CREATE EXTENSION`, emit a row with
   provenance classification: `first-party` (`pgcrypto`, `citext`, `hstore`,
   `pg_trgm`, `unaccent`, `pg_stat_statements`, `postgres_fdw`, `file_fdw`),
   `third-party` (`plv8`, `pgaudit`, `pg_cron`, `pgvector`, `postgis`,
   `timescaledb` OSS edition), or `commercial` (`timescaledb` Community /
   Apache-licensed vs non-OSS editions when detectable). See
   `references/pg-extensions-and-operational-tooling.md` for the full
   provenance table.
7. **Partitioning and materialized views.** Parse `PARTITION BY RANGE / LIST /
   HASH` on parent tables; enumerate `CREATE TABLE ... PARTITION OF` children
   per parent. Parse `CREATE MATERIALIZED VIEW` and search for any refresh
   scheduling — cron, `pg_cron`, application job, or ad-hoc. A materialized
   view with no discoverable refresh driver is an operational finding.
8. **Operational tooling.** Record `.pgpass` locations and flag them as
   credential-bearing; redact the password segment before writing to any
   finding. Parse `pg_hba.conf` and emit one finding per client-auth rule,
   flagging `trust` as a critical security finding. Parse `postgresql.conf` and
   record only the values that differ from the PG default for the relevant
   major version — a non-default list is the finding, not the raw file.
   Connection-pool tooling: detect PgBouncer (`pgbouncer.ini`, `userlist.txt`)
   and pgcat (`pgcat.toml`) and record `pool_mode` (transaction / session /
   statement) because it dictates which PG features (prepared statements,
   session variables) survive the pool.
9. **Migration timeline.** Order `.sql` scripts by filename convention and
   detect the migration-framework style (Flyway `V<nn>__`, timestamped
   `YYYYMMDD`, Knex `NNN_name.js`/`.sql`, Prisma, Atlas, Alembic, Liquibase
   XML/YAML). Emit one row per script with detected object changes (tables
   created, columns added, extensions installed). Inconsistent styles in the
   same repo are a finding; migrations are a source of truth for schema
   history and must be linearizable.
10. **Backup and replication.** Grep for `pg_dump`, `pg_basebackup`,
    `pg_restore`, `wal-g`, `pgbackrest`. Record dump format (`-Fc` custom,
    `-Fd` directory, plain SQL), compression, and retention drivers.
    Continuous archiving: `archive_mode` + `archive_command` in
    `postgresql.conf`. Logical replication: `CREATE PUBLICATION` / `CREATE
    SUBSCRIPTION` / `pg_create_logical_replication_slot`. Physical replication:
    `recovery.conf` / `standby.signal` + `primary_conninfo`.
11. **Validate and hand off.** Validate every emitted manifest against its
    schema (when present) and against the generic
    `olympus.validators.schema_validator`. Every finding must cite both
    `{artifact}:{section}:{finding-id}` and at least one
    `{repo}:{file}:{line}`. Findings without citations are dropped.

## Tech-Stack Dispatch

| Trigger | Key patterns |
|---|---|
| `database in {postgresql, postgres, pg}` | `CREATE TABLE`, PG-specific types (`jsonb`, `uuid`, `hstore`, `citext`), `CREATE EXTENSION` |
| `.plpgsql` files or `LANGUAGE plpgsql` in `.sql` | PL/pgSQL function bodies, `BEGIN ... EXCEPTION WHEN ... THEN ... END`, `RETURN NEXT` / `RETURN QUERY` |
| `CREATE POLICY` / `ROW LEVEL SECURITY` in `.sql` | RLS policies, `USING` / `WITH CHECK` predicates, per-role enforcement |
| `.pgpass`, `pg_hba.conf`, `postgresql.conf` | Auth, per-host rules, server tuning overrides |
| `pgbouncer.ini`, `userlist.txt`, `pgcat.toml` | Connection pooling; `pool_mode` gates feature availability |
| `pg_dump`, `pg_basebackup`, `wal-g`, `pgbackrest` in scripts | Backup / restore / PITR tooling and retention |

Detection is mechanical: presence of one signal loads the matching reference.
Overlap with `oracle-discovery-patterns` and `sqlserver-discovery-patterns` is
expected in audit-sidecar topologies (ATLAS DMS pattern); emit findings under
the PostgreSQL fingerprint and cross-reference the primary DB fingerprint.

## Gotchas
- **`.pgpass` contains credentials.** The file format is
  `hostname:port:database:username:password`. Record the file location as a
  finding and redact the password segment; never copy the raw line into an
  artifact. `.pgpass` committed to a repo is a critical security finding in its
  own right.
- **`pg_hba.conf` `trust` mode is a loaded gun.** A `trust` entry lets any
  client matching the rule connect without authentication. Flag every `trust`
  rule as critical even on loopback — loopback `trust` is often what local
  scripts depend on, which means removing it is a breaking change.
- **`postgresql.conf` defaults are load-bearing.** A default install and a
  tuned install behave radically differently. Surface only the non-default
  settings as findings; focus on `max_connections`, `shared_buffers`,
  `wal_level`, `archive_mode`, `work_mem`, `synchronous_commit`. The PG major
  version changes some defaults, so compare against the matching version
  baseline.
- **Extensions vary per PG major version.** `pgcrypto` is first-party; `plv8`
  is third-party; `timescaledb` has an open-source edition and a commercial
  edition — flag the provenance and any license consequence. `uuid-ossp` is
  deprecated in favor of the built-in `gen_random_uuid()` on PG13+; a
  `uuid-ossp` dependency in new schema is a modernization finding.
- **PL/pgSQL is not PL/SQL.** The exception surface looks similar
  (`BEGIN ... EXCEPTION WHEN ... THEN ... END`) but the internals differ.
  PL/pgSQL has no autonomous transactions (the `dblink`-loopback workaround is
  a smell — emit a finding). PG namespacing is `schema + function`, not Oracle
  packages; a one-to-one Oracle-package-to-PG-schema mapping is a migration
  design decision, not an automatic result.
- **Triggers are two objects.** A trigger is a function
  (`CREATE FUNCTION ... RETURNS trigger`) plus a binding
  (`CREATE TRIGGER ... EXECUTE FUNCTION`). Emit both rows and cross-link;
  emitting only the binding loses the body and only the function loses the
  firing condition.
- **Row-level security needs both halves.** `ENABLE ROW LEVEL SECURITY` with
  no policies silently denies all non-owner access. A policy with RLS not
  enabled silently has no effect. Either half alone is a security finding.
- **Materialized views are stale until refreshed.** Identify the refresh
  driver (cron, `pg_cron`, application-layer, `REFRESH MATERIALIZED VIEW
  CONCURRENTLY` job). No discoverable driver is an operational finding.
- **Generated columns were added in PG12.** `GENERATED ALWAYS AS ... STORED`
  is PG12+; `VIRTUAL` is not yet supported as of PG16. A generated-column
  dependency pins the minimum server version.
- **Declarative partitioning replaced inheritance-based partitioning.**
  PG10+ declarative (`PARTITION BY`) is preferred; legacy inheritance-based
  partitioning still works but is a modernization target. Record the style.
- **`max_connections` is a cliff.** Default is 100; modern apps exceed this
  without PgBouncer. If the connection-pool tooling is absent and the app
  targets PG directly, flag it.
- **PgBouncer `pool_mode` gates features.** `transaction` mode breaks
  prepared statements and session-scoped `SET` / advisory locks; `session`
  mode keeps them but reduces pooling efficiency; `statement` mode is rarely
  safe. Record the mode because downstream extraction depends on it.
- **`timestamp without time zone` vs `timestamp with time zone`.**
  `timestamptz` stores UTC and renders per-session; `timestamp` stores wall
  clock. Mixing them is the single most common PG bug. Record the type
  literally and flag any mixed usage within a single table.
- **`SECURITY DEFINER` functions escalate privileges.** Equivalent to Oracle
  `AUTHID DEFINER`. Record every such function as a security finding; the
  owner's privileges, not the caller's, gate the body.
- **PostgreSQL `MERGE` arrived in PG15.** Earlier versions use
  `INSERT ... ON CONFLICT DO UPDATE`. SQL-standard `MERGE` carries the same
  footguns as T-SQL `MERGE` (non-atomic race conditions with concurrent
  writes); flag any use.
- **Foreign data wrappers are a cross-DB integration surface.**
  `postgres_fdw`, `file_fdw`, `oracle_fdw` (community), `tds_fdw` (SQL Server
  via FreeTDS) — every FDW server is a cross-DB dependency that downstream
  integration-mapping must see.

## Quality Rules
- [ ] Every table in `pg-schema-manifest.json` has a column list with types
      preserved literally and at least one `{repo}:{file}:{line}` citation.
- [ ] Every index in `pg-indexes-manifest.json` has a method field populated
      (default `btree` when omitted in DDL), and partial / expression / covering
      flags set when applicable.
- [ ] Every trigger in `pg-programmability-manifest.json` has both a trigger
      function row and a trigger binding row, cross-linked via
      `trigger_function_id`.
- [ ] Every `CREATE POLICY` has a matching `ENABLE ROW LEVEL SECURITY` on its
      table, and every table with RLS enabled has at least one policy — or the
      mismatch is recorded as an audit finding.
- [ ] Every `CREATE EXTENSION` has a provenance classification
      (`first-party` / `third-party` / `commercial`).
- [ ] `.pgpass` is never copied verbatim; only the path and a
      credentials-present flag appear in findings.
- [ ] Every `pg_hba.conf` rule is recorded and any `trust` entry is flagged
      `severity: critical`.
- [ ] `postgresql.conf` findings list only non-default settings, with the PG
      major version cited.
- [ ] PgBouncer or pgcat detection records the `pool_mode` value.
- [ ] Every `SECURITY DEFINER` function is flagged as a security finding.
- [ ] Every finding record validates against the finding schema and carries
      both `{artifact}:{section}:{finding-id}` and `{repo}:{file}:{line}`.

## Common Failure Modes
| Failure Mode | Symptom | Prevention |
|---|---|---|
| `.pgpass` credentials leaked into the artifact | Secret scan trips on the emitted Discovery artifact | Always redact the password segment; emit only the file location and a credentials-present flag |
| `trust` auth ignored in `pg_hba.conf` | Security review misses a no-auth path; RLS and role model silently bypassed | Flag every `trust` rule as critical even on loopback; emit one finding per rule, never summarize |
| Trigger binding recorded without the function | Downstream extraction has a firing rule but no body to migrate | Emit two rows per trigger (function + binding) and cross-link via `trigger_function_id` |
| RLS enabled without policy, or policy without RLS enabled | Silent deny-all or silent no-op; security posture misrepresented | Audit both directions; emit a finding when either half is present without the other |
| Extension provenance not classified | License / runtime dependency missed; `timescaledb` commercial edition shipped to clients unaware | Classify every extension as `first-party` / `third-party` / `commercial`; cite the source |
| Sidecar PG treated as primary | DMS-style audit DB merged into the primary OLTP fingerprint; capacity and DR plans conflate tiers | Emit a `pg-role: sidecar-audit` finding when the PG deployment is alongside a primary Oracle / SQL Server tier |
| `postgresql.conf` dumped verbatim | Finding noise; reviewer cannot spot the load-bearing overrides | Record only non-default settings for the detected PG major version; keep the focused shortlist |

## Handoff Summary
When this skill completes, verify:
1. Every PG-specific surface in the repo (schema, indexes, programmability,
   RLS, extensions, partitions, materialized views, operational tooling,
   migrations, backup/replication) has a manifest entry with at least one
   `{repo}:{file}:{line}` citation.
2. No raw credentials from `.pgpass` appear anywhere in the emitted artifacts;
   only locations and redacted markers.
3. Every `trust` rule in `pg_hba.conf`, every `SECURITY DEFINER` function,
   every RLS mismatch, and every commercial-edition extension is flagged at
   `severity: critical` or `major` with clear justification.
4. The PG deployment role (`primary` vs `sidecar-audit`) is set, and
   sidecar-audit deployments cross-reference the primary DB fingerprint.

Then proceed to: `catalog-application` (folds the PG fingerprint into the
application catalog entry); `dependency-mapper` (consumes the extension
inventory and FDW list to emit the per-app dependency graph); and for apps
dispositioned as Rearchitect or Replatform, a PostgreSQL extraction pass in
the Modernization Extract step. The next gate is **G-DC** (Discovery
Completeness) where the catalog entry and PG fingerprint must be accepted
before Rationalization begins.

## References
- `schemas/discovery/application-catalog-entry.schema.json` — canonical
  archetype enum and tech-stack field shape.
- `references/pg-schema-and-plpgsql-patterns.md` — table + column + constraint
  extraction (including PG-specific types), indexes with method, PL/pgSQL
  function / trigger anatomy (`LANGUAGE plpgsql` vs `LANGUAGE sql`), trigger
  function-plus-binding, row-level security + policy evaluation, generated
  columns, partitioning (declarative and legacy inheritance), materialized
  views with refresh modes.
- `references/pg-extensions-and-operational-tooling.md` — extension inventory
  (first-party, third-party, commercial), `.pgpass` + `pg_hba.conf` +
  `postgresql.conf` analysis, connection-pool tooling (PgBouncer / pgcat
  modes), backup formats, WAL archiving + streaming + logical replication,
  foreign data wrappers, `SECURITY DEFINER` escalation patterns, auditing
  (`pgaudit`).

## Changelog
- 0.1.0 (2026-05-06) — Initial skill scaffolded as the PostgreSQL companion to
  `oracle-discovery-patterns` and `sqlserver-discovery-patterns`. Covers
  schema + index + programmability extraction with PG-specific types, RLS
  policy audit, extension provenance classification, declarative partitioning,
  materialized-view refresh detection, operational tooling (`.pgpass`,
  `pg_hba.conf`, `postgresql.conf`, PgBouncer / pgcat), migration-timeline
  reconstruction, and backup / replication inventory. Feeds
  `catalog-application`, `dependency-mapper`, and downstream PostgreSQL
  extraction.
