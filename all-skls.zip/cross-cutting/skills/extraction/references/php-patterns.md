# PHP Business Rule Extraction Patterns

## Purpose

Reference for the Extraction skill when performing business rule extraction from
PHP applications. PHP applications store business logic in controllers, models,
services, helper files, configuration arrays, and — in legacy applications — directly
in template files mixed with HTML. This guide maps every extraction point.

## Controller / Action Extraction

### Routing to Handler Mapping

**Laravel routing**:
```php
// routes/web.php — declarative route-to-handler mapping
Route::get('/orders', [OrderController::class, 'index']);
Route::post('/orders', [OrderController::class, 'store']);
Route::get('/orders/{id}', [OrderController::class, 'show']);
Route::put('/orders/{id}', [OrderController::class, 'update']);
Route::delete('/orders/{id}', [OrderController::class, 'destroy']);

// Route with middleware (business rule: authentication required)
Route::middleware(['auth', 'role:admin'])->group(function () {
    Route::get('/admin/reports', [ReportController::class, 'index']);
});
```

**Symfony routing**:
```php
// Via attributes (Symfony 5.2+)
#[Route('/orders', name: 'order_list', methods: ['GET'])]
public function list(): Response { /* ... */ }

#[Route('/orders/{id}', name: 'order_show', requirements: ['id' => '\d+'])]
public function show(int $id): Response { /* ... */ }
```

**CodeIgniter routing**:
```php
// application/config/routes.php
$route['orders'] = 'order/index';
$route['orders/(:num)'] = 'order/view/$1';
$route['api/orders/(:num)'] = 'api/order/detail/$1';
```

**Legacy PHP routing** (no framework):
```php
// index.php — manual routing
$action = $_GET['action'] ?? 'home';
switch ($action) {
    case 'search':
        include 'pages/search.php';   // RULE: search page handler
        break;
    case 'order':
        include 'pages/order.php';    // RULE: order page handler
        break;
    case 'report':
        if (!is_admin()) {            // RULE: reports require admin role
            header('Location: ?action=login');
            exit;
        }
        include 'pages/report.php';
        break;
    default:
        include 'pages/home.php';
}
```

### Request Parameter Processing

```php
// RULE: Extract how the application reads and validates input

// Laravel controller
public function store(Request $request)
{
    // RULE: Validation rules define the data contract
    $validated = $request->validate([
        'customer_id'  => 'required|exists:customers,id',
        'items'        => 'required|array|min:1',
        'items.*.sku'  => 'required|exists:products,sku',
        'items.*.qty'  => 'required|integer|min:1|max:999',
        'shipping'     => 'required|in:standard,express,overnight',
        'notes'        => 'nullable|string|max:500',
        'po_number'    => 'required_if:customer_type,business|regex:/^PO-\d{6}$/',
    ]);

    // RULE: After validation, business logic processes the order
    $order = Order::create([
        'customer_id' => $validated['customer_id'],
        'shipping_method' => $validated['shipping'],
        'status' => 'pending',
    ]);

    // RULE: Calculate shipping cost based on method and weight
    $shippingCost = $this->calculateShipping(
        $validated['shipping'],
        $order->calculateTotalWeight()
    );

    // RULE: Business customers get net-30 terms
    if ($order->customer->type === 'business') {
        $order->payment_terms = 'NET30';
        $order->due_date = now()->addDays(30);
    }
}
```

### Response Generation Rules

```php
// RULE: Response formatting encodes business presentation rules

// Conditional redirect based on business outcome
if ($order->requiresApproval()) {
    return redirect()->route('orders.pending')
        ->with('message', 'Order submitted for approval');
}

// Content negotiation
if ($request->expectsJson()) {
    return response()->json([
        'order_id' => $order->id,
        'status' => $order->status,
        'estimated_delivery' => $order->estimatedDelivery()
    ], 201);
}

return view('orders.confirmation', ['order' => $order]);
```

## Validation Rule Extraction

### Laravel Validation Rules

```php
// RULE: Form request class — centralized validation rules
class CreateApplicationRequest extends FormRequest
{
    public function rules(): array
    {
        return [
            // RULE: Application number auto-generated if not provided
            'application_number' => 'nullable|unique:applications|regex:/^APP-\d{8}$/',

            // RULE: Applicant must be at least 18 years old
            'date_of_birth' => 'required|date|before:' . now()->subYears(18)->format('Y-m-d'),

            // RULE: SSN format validation (masked)
            'ssn' => 'required|regex:/^\d{3}-\d{2}-\d{4}$/',

            // RULE: License type determines required fields
            'license_type' => 'required|in:private,commercial,instrument,atp',
            'medical_certificate' => 'required_if:license_type,commercial,atp',
            'flight_hours' => [
                'required',
                'integer',
                'min:0',
                // RULE: Minimum flight hours depend on license type
                function ($attribute, $value, $fail) {
                    $minimums = [
                        'private' => 40,
                        'instrument' => 50,
                        'commercial' => 250,
                        'atp' => 1500,
                    ];
                    $type = $this->input('license_type');
                    if (isset($minimums[$type]) && $value < $minimums[$type]) {
                        $fail("Minimum {$minimums[$type]} flight hours required for {$type} license.");
                    }
                },
            ],
        ];
    }

    public function messages(): array
    {
        return [
            'date_of_birth.before' => 'Applicant must be at least 18 years old.',
            'flight_hours.min' => 'Flight hours must be a positive number.',
        ];
    }
}
```

### Custom Validators

```php
// RULE: Custom validation registered in service provider
Validator::extend('valid_airport_code', function ($attribute, $value, $parameters) {
    // RULE: Airport code must be a valid 3-letter IATA code
    return Airport::where('iata_code', strtoupper($value))
        ->where('is_active', true)
        ->exists();
});

// RULE: PHP filter functions for input validation
$email = filter_input(INPUT_POST, 'email', FILTER_VALIDATE_EMAIL);
$age = filter_input(INPUT_POST, 'age', FILTER_VALIDATE_INT, [
    'options' => ['min_range' => 18, 'max_range' => 120]
]);
$url = filter_var($input, FILTER_VALIDATE_URL, FILTER_FLAG_SCHEME_REQUIRED);
```

## Business Calculation Extraction

### Service Class Methods

```php
// RULE: Pricing calculation service
class PricingService
{
    // RULE: Calculate order total with tiered pricing
    public function calculateTotal(Order $order): Money
    {
        $subtotal = Money::zero();

        foreach ($order->items as $item) {
            // RULE: Tiered pricing — quantity discounts
            $unitPrice = $this->getTieredPrice(
                $item->product,
                $item->quantity
            );
            $subtotal = $subtotal->add($unitPrice->multiply($item->quantity));
        }

        // RULE: Customer-level discount applied to subtotal
        $discount = $this->getCustomerDiscount($order->customer);
        $discountedTotal = $subtotal->multiply(1 - $discount);

        // RULE: Tax calculation based on shipping destination
        $tax = $this->taxService->calculate(
            $discountedTotal,
            $order->shippingAddress
        );

        // RULE: Shipping cost based on weight and method
        $shipping = $this->shippingService->calculate(
            $order->totalWeight(),
            $order->shippingMethod,
            $order->shippingAddress
        );

        return $discountedTotal->add($tax)->add($shipping);
    }

    // RULE: Tiered pricing thresholds
    private function getTieredPrice(Product $product, int $quantity): Money
    {
        $basePrice = $product->price;

        // RULE: Quantity tiers for bulk pricing
        if ($quantity >= 1000) return $basePrice->multiply(0.70);  // 30% off
        if ($quantity >= 500)  return $basePrice->multiply(0.80);  // 20% off
        if ($quantity >= 100)  return $basePrice->multiply(0.90);  // 10% off
        if ($quantity >= 25)   return $basePrice->multiply(0.95);  // 5% off

        return $basePrice;
    }
}
```

### Utility Functions and Helper Files

```php
// helpers.php — global utility functions containing business rules

// RULE: Format currency based on locale
function formatCurrency(float $amount, string $currency = 'USD'): string
{
    $formatter = new NumberFormatter('en_US', NumberFormatter::CURRENCY);
    return $formatter->formatCurrency($amount, $currency);
}

// RULE: Calculate business days between two dates
function businessDaysBetween(DateTime $start, DateTime $end): int
{
    $days = 0;
    $current = clone $start;
    while ($current <= $end) {
        $dayOfWeek = (int)$current->format('N');
        if ($dayOfWeek <= 5) {  // Monday=1 through Friday=5
            $days++;
        }
        $current->modify('+1 day');
    }
    return $days;
}

// RULE: Generate reference number with check digit
function generateReferenceNumber(string $prefix, int $sequence): string
{
    $base = $prefix . str_pad($sequence, 8, '0', STR_PAD_LEFT);
    $checkDigit = calculateLuhnCheckDigit($base);
    return $base . $checkDigit;
}
```

## Database Query Extraction

### Inline SQL in Controllers (Anti-Pattern)

```php
// Legacy pattern: SQL in controller/page files
// RULE: Get orders eligible for shipment
$sql = "SELECT o.*, c.name as customer_name, c.credit_limit
        FROM orders o
        JOIN customers c ON o.customer_id = c.id
        WHERE o.status = 'approved'
          AND o.payment_status = 'paid'
          AND o.ship_date IS NULL
          AND c.is_active = 1
          AND o.total_amount <= c.credit_limit
        ORDER BY o.priority DESC, o.created_at ASC";
$orders = $db->query($sql)->fetchAll();
```

The WHERE clause encodes business rules:
- Order must be approved
- Payment must be received
- Not yet shipped
- Customer must be active
- Order must be within credit limit
- Processing priority: high-priority first, then FIFO

### Repository / Model Layer

```php
// Laravel Eloquent — query scopes encode business rules
class Order extends Model
{
    // RULE: "Active" orders exclude cancelled and expired
    public function scopeActive($query)
    {
        return $query->whereNotIn('status', ['cancelled', 'expired'])
                     ->where('created_at', '>', now()->subDays(90));
    }

    // RULE: "Ready to ship" orders meet all shipping prerequisites
    public function scopeReadyToShip($query)
    {
        return $query->where('status', 'approved')
                     ->where('payment_status', 'paid')
                     ->whereNull('ship_date')
                     ->whereHas('customer', fn($q) => $q->where('is_active', true))
                     ->whereColumn('total_amount', '<=', 'customers.credit_limit');
    }

    // RULE: Accessor — computed property for display
    public function getStatusLabelAttribute(): string
    {
        return match($this->status) {
            'pending' => 'Awaiting Review',
            'approved' => 'Approved',
            'shipped' => 'In Transit',
            'delivered' => 'Completed',
            'cancelled' => 'Cancelled',
            default => 'Unknown',
        };
    }

    // RULE: Mutator — data transformation on write
    public function setPhoneAttribute($value)
    {
        // RULE: Store phone numbers in E.164 format
        $this->attributes['phone'] = preg_replace('/[^0-9+]/', '', $value);
    }
}
```

### Query Builder Patterns

```php
// Doctrine DBAL query builder
$qb = $connection->createQueryBuilder();
$qb->select('u.id', 'u.name', 'u.email')
   ->from('users', 'u')
   ->where('u.status = :status')
   ->andWhere('u.created_at > :cutoff')
   ->setParameter('status', 'active')
   ->setParameter('cutoff', $cutoffDate)
   ->orderBy('u.name', 'ASC');
```

## Session-Based Workflow Extraction

### Multi-Step Form Patterns

```php
// RULE: Wizard-style form using session to persist state between steps
// Step 1: Personal Information
if ($_POST['step'] === '1') {
    // RULE: Validate step 1 fields
    $errors = validateStep1($_POST);
    if (empty($errors)) {
        $_SESSION['application']['personal'] = [
            'name' => $_POST['name'],
            'dob' => $_POST['dob'],
            'ssn' => $_POST['ssn'],
        ];
        header('Location: ?step=2');
        exit;
    }
}

// Step 2: Employment Information
if ($_POST['step'] === '2') {
    $errors = validateStep2($_POST);
    if (empty($errors)) {
        $_SESSION['application']['employment'] = [
            'employer' => $_POST['employer'],
            'income' => $_POST['income'],
            'years' => $_POST['years'],
        ];
        header('Location: ?step=3');
        exit;
    }
}

// Step 3: Review and Submit
if ($_POST['step'] === 'submit') {
    // RULE: Combine all session data and create the application
    $data = $_SESSION['application'];

    // RULE: Calculate eligibility before saving
    $eligible = checkEligibility($data);

    $applicationId = createApplication($data, $eligible);

    // RULE: Clear session wizard data after successful submission
    unset($_SESSION['application']);

    header('Location: ?action=confirmation&id=' . $applicationId);
    exit;
}
```

### Shopping Cart Pattern

```php
// RULE: Session-based shopping cart
class Cart
{
    public function add(int $productId, int $quantity): void
    {
        $cart = $_SESSION['cart'] ?? [];

        if (isset($cart[$productId])) {
            // RULE: Adding existing item increases quantity
            $cart[$productId]['qty'] += $quantity;
        } else {
            $product = Product::find($productId);
            $cart[$productId] = [
                'name' => $product->name,
                'price' => $product->price,
                'qty' => $quantity,
            ];
        }

        // RULE: Maximum quantity per item is 99
        $cart[$productId]['qty'] = min($cart[$productId]['qty'], 99);

        $_SESSION['cart'] = $cart;
    }

    public function getTotal(): float
    {
        $total = 0;
        foreach ($_SESSION['cart'] ?? [] as $item) {
            $total += $item['price'] * $item['qty'];
        }
        return $total;
    }
}
```

## Configuration-as-Business-Rules

### PHP Config Arrays

```php
// config/pricing.php
return [
    // RULE: Tax rates by state
    'tax_rates' => [
        'CA' => 0.0725,
        'NY' => 0.08,
        'TX' => 0.0625,
        'FL' => 0.06,
        // ... all states
    ],

    // RULE: Shipping rate tiers
    'shipping_rates' => [
        'standard' => [
            ['max_weight' => 1, 'rate' => 5.99],
            ['max_weight' => 5, 'rate' => 8.99],
            ['max_weight' => 20, 'rate' => 12.99],
            ['max_weight' => PHP_INT_MAX, 'rate' => 19.99],
        ],
        'express' => [
            ['max_weight' => 1, 'rate' => 12.99],
            ['max_weight' => 5, 'rate' => 19.99],
            ['max_weight' => PHP_INT_MAX, 'rate' => 29.99],
        ],
    ],

    // RULE: Discount codes
    'promo_codes' => [
        'WELCOME10' => ['type' => 'percent', 'value' => 10, 'min_order' => 50],
        'FLAT20OFF' => ['type' => 'flat', 'value' => 20, 'min_order' => 100],
    ],
];
```

### .ini Configuration

```ini
; config/app.ini
[business_rules]
max_login_attempts = 5
lockout_duration_minutes = 30
password_min_length = 12
session_timeout_minutes = 30
max_upload_size_mb = 25
allowed_file_types = pdf,doc,docx,xls,xlsx,jpg,png

[approval_limits]
supervisor = 5000
manager = 25000
director = 100000
vp = 500000
cfo = 999999999
```

### Environment-Based Behavior Switches

```php
// RULE: Feature flags via environment
if (getenv('FEATURE_NEW_PRICING') === 'true') {
    $price = $newPricingEngine->calculate($order);
} else {
    $price = $legacyPricingEngine->calculate($order);
}

// RULE: Environment-specific behavior
$paymentGateway = match(getenv('APP_ENV')) {
    'production' => new StripeGateway(getenv('STRIPE_LIVE_KEY')),
    'staging' => new StripeGateway(getenv('STRIPE_TEST_KEY')),
    default => new MockPaymentGateway(),
};
```

## eval() and Dynamic Code

```php
// RULE: Dynamic formula evaluation (legacy pattern)
// This MUST be traced by execution path, not static analysis

// Pattern 1: User-defined formulas stored in database
$formula = $db->query(
    "SELECT formula FROM pricing_rules WHERE rule_id = ?", [$ruleId]
)->fetchColumn();
// formula = '$price * 0.85 - $discount'
eval('$result = ' . $formula . ';');

// Pattern 2: Dynamic class instantiation
$handlerClass = 'Handler_' . ucfirst($type);
if (class_exists($handlerClass)) {
    $handler = new $handlerClass();  // Not eval, but still dynamic
    $handler->process($data);
}

// Pattern 3: Callback tables
$callbacks = [
    'validate' => 'Validators::runAll',
    'transform' => 'Transformers::applyRules',
    'persist' => 'Repository::save',
];
call_user_func($callbacks[$action], $data);
```

**Extraction rule**: For `eval()` patterns, the business rule is in the evaluated
string, not the PHP code around it. Check the database, config files, or other
sources where the evaluated strings originate.

## Implicit Type Juggling Rules

PHP's loose typing creates implicit business behavior:

```php
// PHP loose comparison surprises (== vs ===)
0 == "foo"       // true in PHP 7, false in PHP 8
"" == null        // true
"0" == false      // true
"0" == null       // false
[] == false       // true
0 == null         // true

// RULE: Loose comparison can create hidden business logic
if ($status == 0) {
    // This matches status=0, status="", status=null, status=false
    // The developer may have intended only status=0
}

// RULE: Array sorting surprises
$data = [0, '1', '10', '2', '20', 'abc'];
sort($data);
// PHP 7: [0, 'abc', 1, 2, 10, 20]  (mixed comparison)
// PHP 8: [0, '1', '10', '2', '20', 'abc'] (stable, type-separated)

// RULE: Null coalescing behavior
$value = $config['key'] ?? 'default';
// Returns 'default' only if $config['key'] is null or undefined
// Does NOT trigger on empty string '', 0, false, or []
```

## Framework-Specific Extraction

### Laravel Eloquent

```php
// Scopes — reusable query constraints (business rules)
public function scopeExpiringSoon($query, int $days = 30)
{
    return $query->where('expiration_date', '<=', now()->addDays($days))
                 ->where('status', '!=', 'expired');
}

// Accessors — computed read properties
public function getFullNameAttribute(): string
{
    return "{$this->first_name} {$this->last_name}";
}

// Mutators — data transformation on write
public function setEmailAttribute($value)
{
    $this->attributes['email'] = strtolower(trim($value));
}

// Events — lifecycle hooks containing business rules
protected static function booted()
{
    // RULE: Auto-assign order number on creation
    static::creating(function ($order) {
        $order->order_number = 'ORD-' . date('Ymd') . '-' . Str::random(6);
    });

    // RULE: Notify customer when order ships
    static::updated(function ($order) {
        if ($order->isDirty('status') && $order->status === 'shipped') {
            $order->customer->notify(new OrderShipped($order));
        }
    });
}

// Observers — external lifecycle handlers
class OrderObserver
{
    public function created(Order $order): void
    {
        // RULE: Create initial audit log entry
        AuditLog::create([
            'entity_type' => 'order',
            'entity_id' => $order->id,
            'action' => 'created',
            'user_id' => auth()->id(),
        ]);
    }
}
```

### CodeIgniter Callbacks

```php
// CodeIgniter form validation callbacks
$this->form_validation->set_rules(
    'username',
    'Username',
    'required|min_length[5]|max_length[20]|callback_check_username'
);

// Callback function — business rule
public function check_username($username)
{
    // RULE: Username must not be in reserved list
    $reserved = ['admin', 'root', 'system', 'support', 'help'];
    if (in_array(strtolower($username), $reserved)) {
        $this->form_validation->set_message(
            'check_username', 'This username is reserved.'
        );
        return FALSE;
    }

    // RULE: Username must not already exist
    if ($this->user_model->username_exists($username)) {
        $this->form_validation->set_message(
            'check_username', 'This username is already taken.'
        );
        return FALSE;
    }

    return TRUE;
}
```

### WordPress Hooks and Filters

```php
// Action hooks — execute custom logic at specific points
add_action('woocommerce_order_status_completed', function ($order_id) {
    // RULE: Generate certificate when order completes
    $order = wc_get_order($order_id);
    if ($order->get_meta('requires_certificate')) {
        generate_completion_certificate($order);
    }
});

// Filter hooks — modify data as it passes through
add_filter('woocommerce_product_get_price', function ($price, $product) {
    // RULE: Members get 15% discount on all products
    if (is_user_logged_in() && current_user_can('member')) {
        return $price * 0.85;
    }
    return $price;
}, 10, 2);

// RULE: Custom post type registration (business entity definition)
add_action('init', function () {
    register_post_type('flight_record', [
        'labels' => ['name' => 'Flight Records'],
        'public' => true,
        'supports' => ['title', 'editor', 'custom-fields'],
        'has_archive' => true,
    ]);
});
```

## Extraction Priority Checklist

1. **Route definitions** — map all URL endpoints to handlers
2. **Validation rules** — the data contract for every form/API endpoint
3. **Model/Eloquent scopes** — reusable query conditions (business definitions)
4. **Service class methods** — explicit business logic (calculations, workflows)
5. **Config arrays** — rates, thresholds, feature flags, lookup tables
6. **Session state map** — cross-request data flow via session keys
7. **Database queries** — WHERE clauses encode eligibility/filter business rules
8. **Event listeners/hooks** — lifecycle business rules triggered by state changes
9. **Helper/utility functions** — shared business calculations
10. **eval() and dynamic code** — trace to source of evaluated strings
